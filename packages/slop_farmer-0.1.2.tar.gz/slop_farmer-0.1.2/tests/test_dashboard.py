import json
from pathlib import Path

import pytest

from slop_farmer.config import DashboardDataOptions
from slop_farmer.data.parquet_io import write_json, write_parquet
from slop_farmer.reports.dashboard import run_dashboard_data


def test_dashboard_export_writes_frontend_payloads(tmp_path: Path) -> None:
    snapshot_dir = tmp_path / "snapshots" / "20260324T150154Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T150154Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 44940,
                "html_url": "https://github.com/huggingface/transformers/pull/44940",
                "title": "Recent PR",
                "body": "This is the recent PR body.",
                "state": "open",
                "created_at": "2026-03-20T12:00:00Z",
                "updated_at": "2026-03-21T12:00:00Z",
                "merged": False,
                "draft": False,
                "changed_files": 3,
                "additions": 10,
                "deletions": 2,
                "comments_count": 1,
                "review_comments_count": 2,
                "labels": ["bug"],
                "author_login": "alice",
            },
            {
                "repo": "huggingface/transformers",
                "number": 43000,
                "html_url": "https://github.com/huggingface/transformers/pull/43000",
                "title": "Old PR",
                "body": "Old body.",
                "state": "open",
                "created_at": "2026-02-20T12:00:00Z",
                "updated_at": "2026-02-21T12:00:00Z",
                "merged": False,
                "draft": False,
                "changed_files": 1,
                "additions": 1,
                "deletions": 0,
                "comments_count": 0,
                "review_comments_count": 0,
                "labels": [],
                "author_login": "bob",
            },
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 44861,
                "html_url": "https://github.com/huggingface/transformers/issues/44861",
                "title": "Tokenizer bug",
            }
        ],
        snapshot_dir / "issues.parquet",
        "issues",
    )
    (snapshot_dir / "analysis-report.json").write_text(
        json.dumps(
            {
                "meta_bugs": [
                    {
                        "cluster_id": "cluster-44861-3",
                        "summary": "Cluster summary",
                        "status": "open",
                        "confidence": 0.6,
                        "canonical_issue_number": 44861,
                        "canonical_pr_number": 44940,
                        "issue_numbers": [44861],
                        "pr_numbers": [43000, 44940],
                        "evidence_types": ["closing_reference"],
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    (snapshot_dir / "new-contributors-report.json").write_text(
        json.dumps(
            {
                "contributors": [
                    {
                        "author_login": "alice",
                        "name": "Alice",
                        "profile_url": "https://github.com/alice",
                        "repo_pull_requests_url": "https://github.com/huggingface/transformers/pulls?q=author%3Aalice",
                        "repo_issues_url": "https://github.com/huggingface/transformers/issues?q=author%3Aalice",
                        "snapshot_pr_count": 1,
                        "snapshot_issue_count": 0,
                        "repo_association": "CONTRIBUTOR",
                        "first_seen_in_snapshot": True,
                        "follow_through_score": "strong",
                        "breadth_score": "low",
                        "automation_risk_signal": "low",
                        "heuristic_note": "note",
                        "account_age_days": 100,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    (snapshot_dir / "pr-scope-clusters.json").write_text(
        json.dumps(
            {
                "repo": "huggingface/transformers",
                "snapshot_id": "20260324T150154Z",
                "cluster_count": 1,
                "pr_scope_clusters": [
                    {
                        "cluster_id": "pr-scope-44940-2",
                        "pr_numbers": [43000, 44940],
                        "representative_pr_number": 44940,
                        "average_similarity": 0.82,
                        "summary": "2 open PRs share weighted file overlap around `src/tokenizer.py`.",
                        "shared_filenames": ["src/tokenizer.py"],
                        "shared_directories": ["src"],
                        "pairwise": [
                            {
                                "left_pr_number": 43000,
                                "right_pr_number": 44940,
                                "similarity": 0.82,
                                "content_similarity": 0.8,
                                "size_similarity": 0.9,
                                "breadth_similarity": 0.75,
                                "concentration_similarity": 1.0,
                                "shared_filenames": ["src/tokenizer.py"],
                                "shared_directories": ["src"],
                            }
                        ],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    output_dir = tmp_path / "web" / "public" / "data"
    run_dashboard_data(
        DashboardDataOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            analysis_input=None,
            contributors_input=None,
            pr_scope_input=None,
            window_days=14,
        )
    )

    summary = json.loads((output_dir / "summary.json").read_text(encoding="utf-8"))
    clusters = json.loads((output_dir / "clusters.json").read_text(encoding="utf-8"))
    pr_scope_clusters = json.loads(
        (output_dir / "pr_scope_clusters.json").read_text(encoding="utf-8")
    )
    prs = json.loads((output_dir / "prs.json").read_text(encoding="utf-8"))
    contributors = json.loads((output_dir / "contributors.json").read_text(encoding="utf-8"))

    assert summary["pr_count"] == 1
    assert summary["cluster_count"] == 1
    assert summary["contributor_count"] == 1
    assert summary["pr_scope_available"] is True
    assert summary["pr_scope_cluster_count"] == 1
    assert summary["analysis_source"] == "snapshot"
    assert summary["analysis_variant"] == "deterministic"
    assert summary["analysis_snapshot_id"] is None
    assert summary["analysis_id"] is None

    assert clusters == [
        {
            "authors": ["alice"],
            "canonical_issue_number": 44861,
            "canonical_pr_number": 44940,
            "cluster_id": "cluster-44861-3",
            "confidence": 0.6,
            "evidence_types": ["closing_reference"],
            "github_url": "https://github.com/huggingface/transformers/issues/44861",
            "issue_numbers": [44861],
            "last_activity_at": "2026-03-21T12:00:00Z",
            "outside_window_prs": [
                {
                    "additions": 1,
                    "author": "bob",
                    "changed_files": 1,
                    "created_at": "2026-02-20T12:00:00Z",
                    "deletions": 0,
                    "draft": False,
                    "files_url": "https://github.com/huggingface/transformers/pull/43000/files",
                    "html_url": "https://github.com/huggingface/transformers/pull/43000",
                    "merged": False,
                    "number": 43000,
                    "state": "open",
                    "title": "Old PR",
                    "updated_at": "2026-02-21T12:00:00Z",
                }
            ],
            "pairwise_similarity": [],
            "pr_count": 2,
            "pr_numbers": [43000, 44940],
            "pr_similarity": {},
            "recent_pr_count": 1,
            "recent_pr_numbers": [44940],
            "status": "open",
            "summary": "Cluster summary",
            "title": "Tokenizer bug",
        }
    ]
    assert pr_scope_clusters == [
        {
            "authors": ["alice"],
            "average_similarity": 0.82,
            "cluster_id": "pr-scope-44940-2",
            "kind": "pr_scope",
            "last_activity_at": "2026-03-21T12:00:00Z",
            "outside_window_prs": [
                {
                    "additions": 1,
                    "author": "bob",
                    "changed_files": 1,
                    "created_at": "2026-02-20T12:00:00Z",
                    "deletions": 0,
                    "draft": False,
                    "files_url": "https://github.com/huggingface/transformers/pull/43000/files",
                    "html_url": "https://github.com/huggingface/transformers/pull/43000",
                    "merged": False,
                    "number": 43000,
                    "state": "open",
                    "title": "Old PR",
                    "updated_at": "2026-02-21T12:00:00Z",
                }
            ],
            "pairwise": [
                {
                    "breadth_similarity": 0.75,
                    "concentration_similarity": 1.0,
                    "content_similarity": 0.8,
                    "left_pr_number": 43000,
                    "right_pr_number": 44940,
                    "shared_directories": ["src"],
                    "shared_filenames": ["src/tokenizer.py"],
                    "similarity": 0.82,
                    "size_similarity": 0.9,
                }
            ],
            "pr_count": 2,
            "pr_numbers": [43000, 44940],
            "recent_pr_count": 1,
            "recent_pr_numbers": [44940],
            "representative_pr_number": 44940,
            "representative_title": "Recent PR",
            "representative_url": "https://github.com/huggingface/transformers/pull/44940",
            "shared_directories": ["src"],
            "shared_filenames": ["src/tokenizer.py"],
            "summary": "2 open PRs share weighted file overlap around `src/tokenizer.py`.",
            "title": "Scope: Recent PR",
        }
    ]
    assert prs[0]["number"] == 44940
    assert prs[0]["cluster_id"] == "cluster-44861-3"
    assert prs[0]["cluster_role"] == "canonical"
    assert prs[0]["author_association"] is None
    assert contributors[0]["author"] == "alice"
    assert contributors[0]["first_seen_in_snapshot"] is True
    assert contributors[0]["repo_association"] == "CONTRIBUTOR"
    assert contributors[0]["recent_pr_count"] == 1


def test_dashboard_export_resolves_latest_snapshot_from_configured_workspace_root(
    tmp_path: Path,
) -> None:
    snapshots_root = tmp_path / "workspace" / "data" / "snapshots"
    snapshot_dir = snapshots_root / "20260324T150154Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T150154Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_json({"snapshot_dir": str(snapshot_dir)}, snapshots_root / "latest.json")
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 44940,
                "html_url": "https://github.com/huggingface/transformers/pull/44940",
                "title": "Recent PR",
                "body": "This is the recent PR body.",
                "state": "open",
                "created_at": "2026-03-20T12:00:00Z",
                "updated_at": "2026-03-21T12:00:00Z",
                "merged": False,
                "draft": False,
                "changed_files": 3,
                "additions": 10,
                "deletions": 2,
                "comments_count": 1,
                "review_comments_count": 2,
                "labels": ["bug"],
                "author_login": "alice",
            }
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 44861,
                "html_url": "https://github.com/huggingface/transformers/issues/44861",
                "title": "Tokenizer bug",
            }
        ],
        snapshot_dir / "issues.parquet",
        "issues",
    )

    output_dir = tmp_path / "workspace" / "web" / "public" / "data"
    run_dashboard_data(
        DashboardDataOptions(
            snapshot_dir=None,
            output_dir=output_dir,
            analysis_input=None,
            contributors_input=None,
            pr_scope_input=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            window_days=14,
            snapshot_root=snapshots_root,
        )
    )

    summary = json.loads((output_dir / "summary.json").read_text(encoding="utf-8"))
    assert summary["snapshot_id"] == "20260324T150154Z"
    assert summary["repo"] == "huggingface/transformers"


def test_dashboard_export_materializes_hf_snapshot_when_requested(
    monkeypatch, tmp_path: Path
) -> None:
    snapshots_root = tmp_path / "workspace" / "data" / "snapshots"
    snapshot_dir = snapshots_root / "20260324T150154Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T150154Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_parquet([], snapshot_dir / "pull_requests.parquet", "pull_requests")
    write_parquet([], snapshot_dir / "issues.parquet", "issues")
    materialize_calls: list[tuple[str, Path | None, str | None]] = []

    def stub_materialize(*, repo_id: str, local_dir: Path, revision: str | None = None) -> Path:
        materialize_calls.append((repo_id, local_dir, revision))
        return snapshot_dir

    monkeypatch.setattr(
        "slop_farmer.data.snapshot_source.materialize_hf_dataset_snapshot",
        stub_materialize,
    )

    output_dir = tmp_path / "web" / "public" / "data"
    result = run_dashboard_data(
        DashboardDataOptions(
            snapshot_dir=None,
            output_dir=output_dir,
            analysis_input=None,
            contributors_input=None,
            pr_scope_input=None,
            hf_repo_id="evalstate/transformers-pr",
            hf_revision="main",
            hf_materialize_dir=tmp_path / "materialized",
            window_days=14,
            snapshot_root=snapshots_root,
        )
    )

    assert materialize_calls == [("evalstate/transformers-pr", tmp_path / "materialized", "main")]
    assert result == output_dir.resolve()


def test_dashboard_export_prefers_canonical_current_analysis(tmp_path: Path) -> None:
    snapshot_dir = _write_dashboard_snapshot(tmp_path)
    current_dir = snapshot_dir / "analysis" / "current"
    current_dir.mkdir(parents=True)
    write_json(
        {
            "schema_version": 1,
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T150154Z",
            "analysis_id": "hybrid-gpt54mini-v3",
            "variant": "hybrid",
            "channel": "canonical",
            "model": "gpt-5.4-mini",
            "published_at": "2026-03-24T15:30:00Z",
            "artifacts": {
                "hybrid": "analysis/current/analysis-report-hybrid.json",
            },
            "archived_artifacts": {
                "hybrid": (
                    "snapshots/20260324T150154Z/analysis-runs/hybrid-gpt54mini-v3/"
                    "analysis-report-hybrid.json"
                ),
            },
        },
        current_dir / "manifest.json",
    )
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T150154Z",
            "meta_bugs": [
                {
                    "cluster_id": "canonical-cluster",
                    "summary": "Canonical current analysis",
                    "status": "open",
                    "confidence": 0.9,
                    "canonical_issue_number": 44861,
                    "canonical_pr_number": 44940,
                    "issue_numbers": [44861],
                    "pr_numbers": [44940],
                    "evidence_types": ["canonical_current"],
                }
            ],
        },
        current_dir / "analysis-report-hybrid.json",
    )
    write_json(
        {
            "meta_bugs": [
                {
                    "cluster_id": "snapshot-cluster",
                    "summary": "Snapshot fallback analysis",
                    "status": "open",
                    "confidence": 0.1,
                    "canonical_issue_number": 44861,
                    "canonical_pr_number": 44940,
                    "issue_numbers": [44861],
                    "pr_numbers": [44940],
                    "evidence_types": ["snapshot"],
                }
            ]
        },
        snapshot_dir / "analysis-report.json",
    )

    output_dir = tmp_path / "web" / "public" / "data"
    run_dashboard_data(
        DashboardDataOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            analysis_input=None,
            contributors_input=None,
            pr_scope_input=None,
            window_days=14,
        )
    )

    summary = json.loads((output_dir / "summary.json").read_text(encoding="utf-8"))
    clusters = json.loads((output_dir / "clusters.json").read_text(encoding="utf-8"))

    assert summary["analysis_source"] == "current"
    assert summary["analysis_variant"] == "hybrid"
    assert summary["analysis_snapshot_id"] == "20260324T150154Z"
    assert summary["analysis_id"] == "hybrid-gpt54mini-v3"
    assert clusters[0]["cluster_id"] == "canonical-cluster"


def test_dashboard_export_ignores_mismatched_canonical_current_analysis(tmp_path: Path) -> None:
    snapshot_dir = _write_dashboard_snapshot(tmp_path)
    current_dir = snapshot_dir / "analysis" / "current"
    current_dir.mkdir(parents=True)
    write_json(
        {
            "schema_version": 1,
            "repo": "huggingface/transformers",
            "snapshot_id": "20260323T150154Z",
            "analysis_id": "hybrid-gpt54mini-v2",
            "variant": "hybrid",
            "channel": "canonical",
            "model": "gpt-5.4-mini",
            "published_at": "2026-03-23T15:30:00Z",
            "artifacts": {
                "hybrid": "analysis/current/analysis-report-hybrid.json",
            },
            "archived_artifacts": {
                "hybrid": (
                    "snapshots/20260323T150154Z/analysis-runs/hybrid-gpt54mini-v2/"
                    "analysis-report-hybrid.json"
                ),
            },
        },
        current_dir / "manifest.json",
    )
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260323T150154Z",
            "meta_bugs": [
                {
                    "cluster_id": "canonical-cluster",
                    "summary": "Canonical current analysis",
                    "status": "open",
                    "confidence": 0.9,
                    "canonical_issue_number": 44861,
                    "canonical_pr_number": 44940,
                    "issue_numbers": [44861],
                    "pr_numbers": [44940],
                    "evidence_types": ["canonical_current"],
                }
            ],
        },
        current_dir / "analysis-report-hybrid.json",
    )
    write_json(
        {
            "meta_bugs": [
                {
                    "cluster_id": "snapshot-cluster",
                    "summary": "Snapshot fallback analysis",
                    "status": "open",
                    "confidence": 0.1,
                    "canonical_issue_number": 44861,
                    "canonical_pr_number": 44940,
                    "issue_numbers": [44861],
                    "pr_numbers": [44940],
                    "evidence_types": ["snapshot"],
                }
            ]
        },
        snapshot_dir / "analysis-report.json",
    )

    output_dir = tmp_path / "web" / "public" / "data"
    run_dashboard_data(
        DashboardDataOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            analysis_input=None,
            contributors_input=None,
            pr_scope_input=None,
            window_days=14,
        )
    )

    summary = json.loads((output_dir / "summary.json").read_text(encoding="utf-8"))
    clusters = json.loads((output_dir / "clusters.json").read_text(encoding="utf-8"))

    assert summary["analysis_source"] == "snapshot"
    assert summary["analysis_variant"] == "deterministic"
    assert summary["analysis_snapshot_id"] is None
    assert summary["analysis_id"] is None
    assert clusters[0]["cluster_id"] == "snapshot-cluster"


def test_dashboard_export_fails_when_current_analysis_manifest_is_broken(
    tmp_path: Path,
) -> None:
    snapshot_dir = _write_dashboard_snapshot(tmp_path)
    current_dir = snapshot_dir / "analysis" / "current"
    current_dir.mkdir(parents=True)
    write_json(
        {
            "schema_version": 1,
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T150154Z",
            "analysis_id": "hybrid-gpt54mini-v3",
            "variant": "hybrid",
            "channel": "canonical",
            "model": "gpt-5.4-mini",
            "published_at": "2026-03-24T15:30:00Z",
            "artifacts": {
                "hybrid": "analysis/current/analysis-report-hybrid.json",
            },
            "archived_artifacts": {
                "hybrid": (
                    "snapshots/20260324T150154Z/analysis-runs/hybrid-gpt54mini-v3/"
                    "analysis-report-hybrid.json"
                ),
            },
        },
        current_dir / "manifest.json",
    )
    write_json(
        {
            "meta_bugs": [
                {
                    "cluster_id": "snapshot-cluster",
                    "summary": "Snapshot fallback analysis",
                    "status": "open",
                    "confidence": 0.1,
                    "canonical_issue_number": 44861,
                    "canonical_pr_number": 44940,
                    "issue_numbers": [44861],
                    "pr_numbers": [44940],
                    "evidence_types": ["snapshot"],
                }
            ]
        },
        snapshot_dir / "analysis-report.json",
    )

    with pytest.raises(ValueError, match="Published current analysis artifact"):
        run_dashboard_data(
            DashboardDataOptions(
                snapshot_dir=snapshot_dir,
                output_dir=tmp_path / "web" / "public" / "data",
                analysis_input=None,
                contributors_input=None,
                pr_scope_input=None,
                window_days=14,
            )
        )


def _write_dashboard_snapshot(tmp_path: Path) -> Path:
    snapshot_dir = tmp_path / "snapshots" / "20260324T150154Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T150154Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 44940,
                "html_url": "https://github.com/huggingface/transformers/pull/44940",
                "title": "Recent PR",
                "body": "This is the recent PR body.",
                "state": "open",
                "created_at": "2026-03-20T12:00:00Z",
                "updated_at": "2026-03-21T12:00:00Z",
                "merged": False,
                "draft": False,
                "changed_files": 3,
                "additions": 10,
                "deletions": 2,
                "comments_count": 1,
                "review_comments_count": 2,
                "labels": ["bug"],
                "author_login": "alice",
            }
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 44861,
                "html_url": "https://github.com/huggingface/transformers/issues/44861",
                "title": "Tokenizer bug",
            }
        ],
        snapshot_dir / "issues.parquet",
        "issues",
    )
    write_json({"contributors": []}, snapshot_dir / "new-contributors-report.json")
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T150154Z",
            "cluster_count": 0,
            "pr_scope_clusters": [],
        },
        snapshot_dir / "pr-scope-clusters.json",
    )
    return snapshot_dir
