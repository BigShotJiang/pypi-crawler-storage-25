import json
from copy import deepcopy
from pathlib import Path

from slop_farmer.config import NewContributorReportOptions
from slop_farmer.data.parquet_io import read_parquet_rows, write_json, write_parquet
from slop_farmer.reports.new_contributor_report import (
    activity_note,
    run_new_contributor_report,
    score_automation_risk,
)


def test_new_contributor_report_writes_markdown_and_json_with_profile_links(
    monkeypatch, tmp_path: Path
) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = _write_snapshot(output_dir)

    def stub_summary(login: str, days: int, repo: str | None) -> dict:
        assert days == 42
        assert repo is None
        return {
            "login": login,
            "name": login.title(),
            "account": {"created_at": "2026-02-20T00:00:00Z", "age_days": 33},
            "activity": {
                "visible_authored_pr_count": 18,
                "merged_pr_count": 4,
                "closed_unmerged_pr_count": 9,
                "open_pr_count": 5,
                "merged_pr_rate": 0.2222,
                "closed_unmerged_pr_rate": 0.5,
                "still_open_pr_rate": 0.2778,
                "distinct_repos_with_authored_prs": 12,
                "distinct_repos_with_open_prs": 5,
            },
            "stars": {
                "visible_non_self_starred_repositories": 0,
                "recent_pr_repo_star_distribution": {"median": 15000},
            },
            "organization_membership": {
                "public_orgs": [{"login": "org-a", "name": "Org A"}],
            },
        }

    monkeypatch.setattr("slop_farmer.reports.new_contributor_report.summarize_user", stub_summary)

    markdown_path = run_new_contributor_report(
        NewContributorReportOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=None,
            json_output=None,
            window_days=42,
            max_authors=10,
        )
    )

    json_path = snapshot_dir / "new-contributors-report.json"
    parquet_path = snapshot_dir / "new_contributors.parquet"
    assert markdown_path == snapshot_dir / "new-contributors-report.md"
    assert json_path.exists()
    assert parquet_path.exists()

    payload = json.loads(json_path.read_text(encoding="utf-8"))
    assert payload["repo"] == "huggingface/transformers"
    assert payload["instrumentation"]["selected_contributors"] == 2
    assert payload["instrumentation"]["window_anchor"] == "run_time"
    assert payload["instrumentation"]["window_anchor_cacheable"] is False
    assert [row["author_login"] for row in payload["contributors"]] == ["alice", "bob"]
    assert payload["contributors"][0]["profile_url"] == "https://github.com/alice"
    assert payload["contributors"][0]["first_seen_in_snapshot"] is True
    assert payload["contributors"][0]["known_via_prior_merged_pr"] is False
    assert payload["contributors"][0]["enrichment_source"] == "live"
    assert payload["contributors"][0]["repo_association"] == "CONTRIBUTOR"
    assert payload["contributors"][0]["repo_pull_requests_url"].startswith(
        "https://github.com/huggingface/transformers/pulls?q="
    )
    assert (
        payload["contributors"][0]["examples"]["pull_requests"][0]["url"]
        == "https://example.com/pulls/10"
    )
    parquet_rows = read_parquet_rows(parquet_path)
    assert parquet_rows[0]["author_login"] == "alice"
    assert parquet_rows[0]["profile_url"] == "https://github.com/alice"
    assert parquet_rows[0]["snapshot_pr_count"] == 1
    assert parquet_rows[0]["first_seen_in_snapshot"] is True
    assert parquet_rows[0]["repo_association"] == "CONTRIBUTOR"

    text = markdown_path.read_text(encoding="utf-8")
    assert "# New Contributor Report: huggingface/transformers" in text
    assert "[profile](https://github.com/alice)" in text
    assert (
        "[open search](https://github.com/huggingface/transformers/pulls?q=is%3Apr+author%3Aalice)"
        in text
    )
    assert "[PR #10: Add tokenizer fix](https://example.com/pulls/10)" in text
    assert "[Issue #1: Empty input bug](https://example.com/issues/1)" in text
    assert "yes" in text
    assert "open rate **28%**" in text


def test_new_contributor_report_marks_seen_authors_from_previous_snapshot(
    monkeypatch, tmp_path: Path
) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = _write_snapshot(output_dir)
    previous_snapshot_dir = output_dir / "snapshots" / "20260323T000000Z"
    write_parquet(
        [
            _issue_row(1, "Empty input bug", "Tokenizer breaks", "alice"),
        ],
        previous_snapshot_dir / "issues.parquet",
        "issues",
    )
    previous_prs = [
        _pr_row(10, "Add tokenizer fix", "Fixes #1", "alice"),
    ]
    write_parquet(previous_prs, previous_snapshot_dir / "pull_requests.parquet", "pull_requests")
    write_parquet([], previous_snapshot_dir / "comments.parquet", "comments")
    write_parquet([], previous_snapshot_dir / "reviews.parquet", "reviews")
    write_parquet([], previous_snapshot_dir / "review_comments.parquet", "review_comments")
    manifest = json.loads((snapshot_dir / "manifest.json").read_text(encoding="utf-8"))
    manifest["watermark"] = {"previous_snapshot_dir": str(previous_snapshot_dir)}
    write_json(manifest, snapshot_dir / "manifest.json")

    monkeypatch.setattr(
        "slop_farmer.reports.new_contributor_report.summarize_user",
        lambda login, days, repo: _stub_summary(login),
    )

    run_new_contributor_report(
        NewContributorReportOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=None,
            json_output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            window_days=42,
            max_authors=10,
        )
    )

    payload = json.loads(
        (snapshot_dir / "new-contributors-report.json").read_text(encoding="utf-8")
    )
    assert payload["instrumentation"]["selected_overlap_previous_report"] == 0
    assert [row["author_login"] for row in payload["contributors"]] == ["alice", "bob"]
    by_author = {row["author_login"]: row for row in payload["contributors"]}
    assert by_author["alice"]["first_seen_in_snapshot"] is False
    assert by_author["bob"]["first_seen_in_snapshot"] is True


def test_new_contributor_report_reuses_recent_known_merged_contributors(
    monkeypatch, tmp_path: Path
) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = _write_snapshot(output_dir)
    previous_snapshot_dir = output_dir / "snapshots" / "20260323T000000Z"
    previous_pr = _pr_row(10, "Add tokenizer fix", "Fixes #1", "alice")
    previous_pr["state"] = "closed"
    previous_pr["merged"] = True
    previous_pr["merged_at"] = "2026-03-23T00:00:00Z"
    previous_pr["closed_at"] = "2026-03-23T00:00:00Z"
    write_parquet([], previous_snapshot_dir / "issues.parquet", "issues")
    write_parquet([previous_pr], previous_snapshot_dir / "pull_requests.parquet", "pull_requests")
    write_parquet([], previous_snapshot_dir / "comments.parquet", "comments")
    write_parquet([], previous_snapshot_dir / "reviews.parquet", "reviews")
    write_parquet([], previous_snapshot_dir / "review_comments.parquet", "review_comments")
    write_json(
        {
            "schema_version": "1.0",
            "repo": "huggingface/transformers",
            "snapshot_id": "20260323T000000Z",
            "generated_at": "2026-03-23T00:00:00Z",
            "window_days": 42,
            "max_authors": 10,
            "contributors": [
                {
                    "author_login": "alice",
                    "name": "Alice Previous",
                    "profile_url": "https://github.com/alice",
                    "activity": {
                        "visible_authored_pr_count": 99,
                        "merged_pr_count": 88,
                        "closed_unmerged_pr_count": 5,
                        "open_pr_count": 6,
                        "merged_pr_rate": 0.8889,
                        "closed_unmerged_pr_rate": 0.0505,
                        "still_open_pr_rate": 0.0606,
                        "distinct_repos_with_authored_prs": 12,
                        "distinct_repos_with_open_prs": 3,
                    },
                    "account_age_days": 123,
                    "young_account": True,
                    "follow_through_score": "high",
                    "breadth_score": "medium",
                    "automation_risk_signal": "low",
                    "heuristic_note": "previous payload",
                    "public_orgs": ["org-a"],
                    "fetch_error": None,
                }
            ],
        },
        previous_snapshot_dir / "new-contributors-report.json",
    )
    manifest = json.loads((snapshot_dir / "manifest.json").read_text(encoding="utf-8"))
    manifest["watermark"] = {"previous_snapshot_dir": str(previous_snapshot_dir)}
    write_json(manifest, snapshot_dir / "manifest.json")

    calls: list[str] = []

    def stub_summary(login: str, days: int, repo: str | None) -> dict:
        calls.append(login)
        assert days == 42
        assert repo is None
        summary = _stub_summary(login)
        if login == "alice":
            summary["name"] = "Alice Fresh"
            summary["activity"]["merged_pr_count"] = 7
        return summary

    monkeypatch.setattr("slop_farmer.reports.new_contributor_report.summarize_user", stub_summary)

    run_new_contributor_report(
        NewContributorReportOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=None,
            json_output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            window_days=42,
            max_authors=10,
        )
    )

    payload = json.loads(
        (snapshot_dir / "new-contributors-report.json").read_text(encoding="utf-8")
    )
    by_author = {row["author_login"]: row for row in payload["contributors"]}
    assert calls == ["bob"]
    assert by_author["alice"]["known_via_prior_merged_pr"] is True
    assert by_author["alice"]["live_refetch_skipped"] is True
    assert by_author["alice"]["enrichment_source"] == "previous_report"
    assert by_author["alice"]["name"] == "Alice Previous"
    assert by_author["alice"]["activity"]["merged_pr_count"] == 88
    assert by_author["bob"]["enrichment_source"] == "live"
    assert payload["instrumentation"]["known_via_prior_merged_pr"] == 1
    assert payload["instrumentation"]["reused_known_merged_contributors"] == 1
    assert payload["instrumentation"]["reused_previous_report_entries"] == 1
    assert payload["instrumentation"]["live_fetches"] == 1


def test_new_contributor_report_reuses_recent_previous_report_entries(
    monkeypatch, tmp_path: Path
) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = _write_snapshot(output_dir)
    previous_snapshot_dir = output_dir / "snapshots" / "20260323T000000Z"
    write_parquet(
        [
            _issue_row(1, "Empty input bug", "Tokenizer breaks", "alice"),
        ],
        previous_snapshot_dir / "issues.parquet",
        "issues",
    )
    write_parquet(
        [
            _pr_row(10, "Add tokenizer fix", "Fixes #1", "alice"),
        ],
        previous_snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet([], previous_snapshot_dir / "comments.parquet", "comments")
    write_parquet([], previous_snapshot_dir / "reviews.parquet", "reviews")
    write_parquet([], previous_snapshot_dir / "review_comments.parquet", "review_comments")
    write_json(
        {
            "schema_version": "1.0",
            "repo": "huggingface/transformers",
            "snapshot_id": "20260323T000000Z",
            "generated_at": "2026-03-23T12:00:00Z",
            "window_days": 42,
            "max_authors": 10,
            "contributors": [_previous_report_contributor_entry("alice")],
        },
        previous_snapshot_dir / "new-contributors-report.json",
    )
    manifest = json.loads((snapshot_dir / "manifest.json").read_text(encoding="utf-8"))
    manifest["watermark"] = {"previous_snapshot_dir": str(previous_snapshot_dir)}
    write_json(manifest, snapshot_dir / "manifest.json")

    calls: list[str] = []

    def stub_summary(login: str, days: int, repo: str | None) -> dict:
        calls.append(login)
        assert days == 42
        assert repo is None
        return _stub_summary(login)

    monkeypatch.setattr("slop_farmer.reports.new_contributor_report.summarize_user", stub_summary)

    run_new_contributor_report(
        NewContributorReportOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=None,
            json_output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            window_days=42,
            max_authors=10,
        )
    )

    payload = json.loads(
        (snapshot_dir / "new-contributors-report.json").read_text(encoding="utf-8")
    )
    by_author = {row["author_login"]: row for row in payload["contributors"]}
    assert calls == ["bob"]
    assert by_author["alice"]["name"] == "Alice Previous"
    assert by_author["alice"]["enrichment_source"] == "previous_report"
    assert by_author["alice"]["live_refetch_skipped"] is True
    assert by_author["alice"]["activity"]["merged_pr_count"] == 88


def test_new_contributor_report_materializes_hf_snapshot_when_requested(
    monkeypatch, tmp_path: Path
) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = _write_snapshot(output_dir)
    materialize_calls: list[tuple[str, Path | None, str | None]] = []

    def stub_materialize(*, repo_id: str, local_dir: Path, revision: str | None = None) -> Path:
        materialize_calls.append((repo_id, local_dir, revision))
        return snapshot_dir

    monkeypatch.setattr(
        "slop_farmer.data.snapshot_source.materialize_hf_dataset_snapshot",
        stub_materialize,
    )
    monkeypatch.setattr(
        "slop_farmer.reports.new_contributor_report.summarize_user",
        lambda login, days, repo: _stub_summary(login),
    )

    markdown_path = run_new_contributor_report(
        NewContributorReportOptions(
            snapshot_dir=None,
            output_dir=output_dir,
            output=None,
            json_output=None,
            hf_repo_id="evalstate/transformers-pr",
            hf_revision="main",
            hf_materialize_dir=tmp_path / "materialized",
            window_days=42,
            max_authors=10,
        )
    )

    assert materialize_calls == [("evalstate/transformers-pr", tmp_path / "materialized", "main")]
    assert markdown_path == snapshot_dir / "new-contributors-report.md"


def test_new_contributor_report_skips_previous_report_reuse_on_window_mismatch(
    monkeypatch, tmp_path: Path
) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = _write_snapshot(output_dir)
    previous_snapshot_dir = output_dir / "snapshots" / "20260323T000000Z"
    write_parquet(
        [
            _issue_row(1, "Empty input bug", "Tokenizer breaks", "alice"),
        ],
        previous_snapshot_dir / "issues.parquet",
        "issues",
    )
    write_parquet(
        [
            _pr_row(10, "Add tokenizer fix", "Fixes #1", "alice"),
        ],
        previous_snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet([], previous_snapshot_dir / "comments.parquet", "comments")
    write_parquet([], previous_snapshot_dir / "reviews.parquet", "reviews")
    write_parquet([], previous_snapshot_dir / "review_comments.parquet", "review_comments")
    write_json(
        {
            "schema_version": "1.0",
            "repo": "huggingface/transformers",
            "snapshot_id": "20260323T000000Z",
            "generated_at": "2026-03-23T12:00:00Z",
            "window_days": 30,
            "max_authors": 10,
            "contributors": [_previous_report_contributor_entry("alice")],
        },
        previous_snapshot_dir / "new-contributors-report.json",
    )
    manifest = json.loads((snapshot_dir / "manifest.json").read_text(encoding="utf-8"))
    manifest["watermark"] = {"previous_snapshot_dir": str(previous_snapshot_dir)}
    write_json(manifest, snapshot_dir / "manifest.json")

    calls: list[str] = []

    def stub_summary(login: str, days: int, repo: str | None) -> dict:
        calls.append(login)
        assert days == 42
        assert repo is None
        return _stub_summary(login)

    monkeypatch.setattr("slop_farmer.reports.new_contributor_report.summarize_user", stub_summary)

    run_new_contributor_report(
        NewContributorReportOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=None,
            json_output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            window_days=42,
            max_authors=10,
        )
    )

    payload = json.loads(
        (snapshot_dir / "new-contributors-report.json").read_text(encoding="utf-8")
    )
    by_author = {row["author_login"]: row for row in payload["contributors"]}
    assert calls == ["alice", "bob"]
    assert by_author["alice"]["enrichment_source"] == "live"
    assert by_author["alice"]["live_refetch_skipped"] is False
    assert payload["instrumentation"]["reused_previous_report_entries"] == 0
    assert payload["instrumentation"]["live_fetches"] == 2


def test_score_automation_risk_escalates_single_repo_burst_from_low_to_high() -> None:
    summary = deepcopy(_stub_summary("alice"))
    summary["account"]["age_days"] = 368
    summary["activity"].update(
        {
            "visible_authored_pr_count": 44,
            "merged_pr_count": 4,
            "closed_unmerged_pr_count": 34,
            "open_pr_count": 6,
            "merged_pr_rate": 0.0909,
            "closed_unmerged_pr_rate": 0.7727,
            "still_open_pr_rate": 0.1364,
            "distinct_repos_with_authored_prs": 1,
            "distinct_repos_with_open_prs": 1,
        }
    )
    summary["stars"]["visible_non_self_starred_repositories"] = 2

    assert score_automation_risk(summary) == "low"
    assert score_automation_risk(summary, repo_snapshot_pr_count=30) == "high"
    assert "single-repo PR burst" in activity_note(summary, repo_snapshot_pr_count=30)


def test_score_automation_risk_escalates_single_repo_burst_from_medium_to_high() -> None:
    summary = deepcopy(_stub_summary("alice"))
    summary["account"]["age_days"] = 3859
    summary["activity"].update(
        {
            "visible_authored_pr_count": 84,
            "merged_pr_count": 0,
            "closed_unmerged_pr_count": 77,
            "open_pr_count": 7,
            "merged_pr_rate": 0.0,
            "closed_unmerged_pr_rate": 0.9167,
            "still_open_pr_rate": 0.0833,
            "distinct_repos_with_authored_prs": 1,
            "distinct_repos_with_open_prs": 1,
        }
    )
    summary["stars"]["visible_non_self_starred_repositories"] = 100

    assert score_automation_risk(summary) == "medium"
    assert score_automation_risk(summary, repo_snapshot_pr_count=34) == "high"


def _write_snapshot(output_dir: Path) -> Path:
    snapshot_dir = output_dir / "snapshots" / "20260324T000000Z"
    write_parquet(
        [
            _issue_row(1, "Empty input bug", "Tokenizer breaks", "alice"),
            _issue_row(2, "Docs typo", "Minor docs issue", "bob"),
        ],
        snapshot_dir / "issues.parquet",
        "issues",
    )
    write_parquet(
        [
            _pr_row(10, "Add tokenizer fix", "Fixes #1", "alice"),
            _pr_row(20, "Fix docs typo", "Fixes #2", "bob"),
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet([], snapshot_dir / "comments.parquet", "comments")
    write_parquet([], snapshot_dir / "reviews.parquet", "reviews")
    write_parquet([], snapshot_dir / "review_comments.parquet", "review_comments")
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T000000Z",
            "extracted_at": "2026-03-24T00:00:00Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_json(
        {
            "latest_snapshot_id": "20260324T000000Z",
            "snapshot_dir": str(snapshot_dir),
        },
        output_dir / "snapshots" / "latest.json",
    )
    return snapshot_dir


def _read_rows(path: Path) -> list[dict]:
    import pyarrow.parquet as pq

    return pq.read_table(path).to_pylist()


def _issue_row(number: int, title: str, body: str, author_login: str) -> dict:
    return {
        "repo": "huggingface/transformers",
        "github_id": number,
        "github_node_id": f"I_{number}",
        "number": number,
        "html_url": f"https://example.com/issues/{number}",
        "api_url": f"https://api.example.com/issues/{number}",
        "title": title,
        "body": body,
        "state": "open",
        "state_reason": None,
        "locked": False,
        "comments_count": 0,
        "labels": [],
        "assignees": [],
        "created_at": f"2026-03-{number:02d}T00:00:00Z",
        "updated_at": f"2026-03-{number:02d}T00:00:00Z",
        "closed_at": None,
        "author_association": "CONTRIBUTOR",
        "milestone_title": None,
        "snapshot_id": "20260324T000000Z",
        "extracted_at": "2026-03-24T00:00:00Z",
        "author_login": author_login,
        "author_id": number,
        "author_node_id": f"U_{number}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _pr_row(number: int, title: str, body: str, author_login: str) -> dict:
    return {
        "repo": "huggingface/transformers",
        "github_id": number,
        "github_node_id": f"PR_{number}",
        "number": number,
        "html_url": f"https://example.com/pulls/{number}",
        "api_url": f"https://api.example.com/pulls/{number}",
        "title": title,
        "body": body,
        "state": "open",
        "state_reason": None,
        "locked": False,
        "comments_count": 0,
        "labels": [],
        "assignees": [],
        "created_at": f"2026-03-{min(number, 28):02d}T00:00:00Z",
        "updated_at": f"2026-03-{min(number, 28):02d}T00:00:00Z",
        "closed_at": None,
        "author_association": "CONTRIBUTOR",
        "merged_at": None,
        "merge_commit_sha": None,
        "merged": False,
        "mergeable": True,
        "mergeable_state": "clean",
        "draft": False,
        "additions": 1,
        "deletions": 1,
        "changed_files": 1,
        "commits": 1,
        "review_comments_count": 0,
        "maintainer_can_modify": True,
        "head_ref": f"branch-{number}",
        "head_sha": f"head-{number}",
        "head_repo_full_name": "fork/repo",
        "base_ref": "main",
        "base_sha": f"base-{number}",
        "base_repo_full_name": "huggingface/transformers",
        "snapshot_id": "20260324T000000Z",
        "extracted_at": "2026-03-24T00:00:00Z",
        "author_login": author_login,
        "author_id": number,
        "author_node_id": f"U_{number}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _stub_summary(login: str) -> dict:
    return {
        "login": login,
        "name": login.title(),
        "account": {"created_at": "2025-12-01T00:00:00Z", "age_days": 90},
        "activity": {
            "visible_authored_pr_count": 6,
            "merged_pr_count": 3,
            "closed_unmerged_pr_count": 1,
            "open_pr_count": 2,
            "distinct_repos_with_authored_prs": 3,
            "distinct_repos_with_open_prs": 1,
            "merged_pr_rate": 0.5,
            "closed_unmerged_pr_rate": 0.1667,
            "still_open_pr_rate": 0.3333,
        },
        "stars": {
            "visible_non_self_starred_repositories": 2,
            "recent_pr_repo_star_distribution": {"median": 500},
        },
        "organization_membership": {"public_orgs": []},
    }


def _new_contributor_row(author_login: str) -> dict:
    return {
        "repo": "huggingface/transformers",
        "snapshot_id": "20260323T000000Z",
        "report_generated_at": "2026-03-23T00:00:00Z",
        "window_days": 42,
        "author_login": author_login,
        "name": author_login.title(),
        "profile_url": f"https://github.com/{author_login}",
        "repo_pull_requests_url": f"https://github.com/huggingface/transformers/pulls?q=is%3Apr+author%3A{author_login}",
        "repo_issues_url": f"https://github.com/huggingface/transformers/issues?q=is%3Aissue+author%3A{author_login}",
        "repo_first_seen_at": "2026-03-23T00:00:00Z",
        "repo_last_seen_at": "2026-03-23T00:00:00Z",
        "repo_primary_artifact_count": 1,
        "repo_artifact_count": 1,
        "snapshot_issue_count": 0,
        "snapshot_pr_count": 1,
        "snapshot_comment_count": 0,
        "snapshot_review_count": 0,
        "snapshot_review_comment_count": 0,
        "repo_association": "CONTRIBUTOR",
        "new_to_repo": True,
        "first_seen_in_snapshot": True,
        "report_reason": "first_seen_in_snapshot",
        "account_age_days": 90,
        "young_account": True,
        "follow_through_score": "mixed",
        "breadth_score": "low",
        "automation_risk_signal": "low",
        "heuristic_note": "young account",
        "public_orgs": [],
        "visible_authored_pr_count": 6,
        "merged_pr_count": 3,
        "closed_unmerged_pr_count": 1,
        "open_pr_count": 2,
        "merged_pr_rate": 0.5,
        "closed_unmerged_pr_rate": 0.1667,
        "still_open_pr_rate": 0.3333,
        "distinct_repos_with_authored_prs": 3,
        "distinct_repos_with_open_prs": 1,
        "fetch_error": None,
    }


def _previous_report_contributor_entry(author_login: str) -> dict:
    return {
        "author_login": author_login,
        "name": f"{author_login.title()} Previous",
        "profile_url": f"https://github.com/{author_login}",
        "repo_pull_requests_url": f"https://github.com/huggingface/transformers/pulls?q=author%3A{author_login}",
        "repo_issues_url": f"https://github.com/huggingface/transformers/issues?q=author%3A{author_login}",
        "repo_first_seen_at": "2026-03-23T00:00:00Z",
        "repo_last_seen_at": "2026-03-23T00:00:00Z",
        "repo_primary_artifact_count": 1,
        "repo_artifact_count": 1,
        "snapshot_issue_count": 0,
        "snapshot_pr_count": 1,
        "snapshot_comment_count": 0,
        "snapshot_review_count": 0,
        "snapshot_review_comment_count": 0,
        "repo_association": "CONTRIBUTOR",
        "new_to_repo": True,
        "first_seen_in_snapshot": True,
        "known_via_prior_merged_pr": False,
        "report_reason": "first_seen_in_snapshot",
        "enrichment_source": "live",
        "live_refetch_skipped": False,
        "account_age_days": 123,
        "young_account": True,
        "follow_through_score": "high",
        "breadth_score": "medium",
        "automation_risk_signal": "low",
        "heuristic_note": "previous payload",
        "public_orgs": ["org-a"],
        "activity": {
            "visible_authored_pr_count": 99,
            "merged_pr_count": 88,
            "closed_unmerged_pr_count": 5,
            "open_pr_count": 6,
            "merged_pr_rate": 0.8889,
            "closed_unmerged_pr_rate": 0.0505,
            "still_open_pr_rate": 0.0606,
            "distinct_repos_with_authored_prs": 12,
            "distinct_repos_with_open_prs": 3,
        },
        "fetch_error": None,
    }
