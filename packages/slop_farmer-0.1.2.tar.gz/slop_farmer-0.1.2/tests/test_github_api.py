from __future__ import annotations

from email.message import Message
from io import BytesIO
from urllib.error import HTTPError

import pytest

from slop_farmer.data.github_api import GitHubApiRequestError, GitHubClient


def test_get_pull_request_diff_skips_oversized_diff(monkeypatch: pytest.MonkeyPatch) -> None:
    logs: list[str] = []
    client = GitHubClient(token=None, log=logs.append)

    def fake_urlopen(request, timeout=0):  # type: ignore[no-untyped-def]
        headers = Message()
        raise HTTPError(
            request.full_url,
            406,
            "Not Acceptable",
            hdrs=headers,
            fp=BytesIO(
                b'{"message":"Sorry, the diff exceeded the maximum number of lines (20000)",'
                b'"errors":[{"resource":"PullRequest","field":"diff","code":"too_large"}],'
                b'"status":"406"}'
            ),
        )

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

    diff = client.get_pull_request_diff("huggingface", "transformers", 776)

    assert diff == ""
    assert logs == ["Skipping unified diff for pull request #776; GitHub reports diff too large"]


def test_get_pull_request_diff_still_raises_other_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    client = GitHubClient(token=None)

    def fake_urlopen(request, timeout=0):  # type: ignore[no-untyped-def]
        headers = Message()
        raise HTTPError(
            request.full_url,
            500,
            "Server Error",
            hdrs=headers,
            fp=BytesIO(b'{"message":"boom"}'),
        )

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

    with pytest.raises(RuntimeError, match="GitHub API request failed: 500"):
        client.get_pull_request_diff("huggingface", "transformers", 123)


def test_rate_limit_logging_on_successful_response() -> None:
    logs: list[str] = []
    client = GitHubClient(token=None, log=logs.append)

    client._maybe_log_rate_limit(
        "/repos/huggingface/transformers/issues",
        {
            "x-ratelimit-limit": "5000",
            "x-ratelimit-remaining": "4999",
            "x-ratelimit-used": "1",
            "x-ratelimit-reset": "1770000000",
            "x-ratelimit-resource": "core",
        },
    )

    assert logs == [
        "GitHub rate limit: resource=core used=1 remaining=4999/5000 "
        "reset=2026-02-02T02:40:00Z after /repos/huggingface/transformers/issues (request 1)"
    ]


def test_iter_issue_timeline_skips_server_errors() -> None:
    logs: list[str] = []

    class Timeline500Client(GitHubClient):
        def paginate(  # type: ignore[override]
            self,
            path: str,
            params=None,
            accept: str = "application/vnd.github+json",
            limit: int | None = None,
        ):
            del params, accept, limit
            raise GitHubApiRequestError(500, path, '{"message":"boom"}')

    client = Timeline500Client(token=None, log=logs.append)

    assert list(client.iter_issue_timeline("huggingface", "transformers", 45286)) == []
    assert logs == [
        "Skipping timeline fetch for issue #45286 after GitHub 500: "
        "/repos/huggingface/transformers/issues/45286/timeline"
    ]


def test_iter_repo_issues_prefers_recent_items_for_bounded_bootstrap() -> None:
    captured: dict[str, object] = {}

    class RecordingClient(GitHubClient):
        def paginate(  # type: ignore[override]
            self,
            path: str,
            params=None,
            accept: str = "application/vnd.github+json",
            limit: int | None = None,
        ):
            captured["path"] = path
            captured["params"] = dict(params or {})
            captured["accept"] = accept
            captured["limit"] = limit
            return iter(())

    client = RecordingClient(token=None)

    assert list(client.iter_repo_issues("evalstate", "fast-agent", since=None, limit=50)) == []
    assert captured == {
        "path": "/repos/evalstate/fast-agent/issues",
        "params": {"state": "all", "sort": "updated", "direction": "desc"},
        "accept": "application/vnd.github+json",
        "limit": 50,
    }


def test_iter_repo_issues_keeps_ascending_order_for_incremental_syncs() -> None:
    captured: dict[str, object] = {}

    class RecordingClient(GitHubClient):
        def paginate(  # type: ignore[override]
            self,
            path: str,
            params=None,
            accept: str = "application/vnd.github+json",
            limit: int | None = None,
        ):
            captured["path"] = path
            captured["params"] = dict(params or {})
            captured["accept"] = accept
            captured["limit"] = limit
            return iter(())

    client = RecordingClient(token=None)

    since = "2026-04-01T00:00:00Z"
    assert list(client.iter_repo_issues("evalstate", "fast-agent", since=since, limit=50)) == []
    assert captured == {
        "path": "/repos/evalstate/fast-agent/issues",
        "params": {"state": "all", "sort": "updated", "direction": "asc", "since": since},
        "accept": "application/vnd.github+json",
        "limit": 50,
    }
