from __future__ import annotations

from slop_farmer.data.normalize import normalize_issue, normalize_pull_request


def test_normalize_issue_keeps_author_association() -> None:
    row = normalize_issue(
        "huggingface/transformers",
        {
            "id": 1,
            "number": 123,
            "author_association": "CONTRIBUTOR",
            "user": {"login": "alice"},
        },
        "snap",
        "2026-03-24T00:00:00Z",
    )

    assert row["author_association"] == "CONTRIBUTOR"


def test_normalize_pull_request_keeps_author_association() -> None:
    row = normalize_pull_request(
        "huggingface/transformers",
        {
            "id": 1,
            "number": 123,
            "author_association": "MEMBER",
            "user": {"login": "alice"},
        },
        {
            "id": 1,
            "number": 123,
            "author_association": "CONTRIBUTOR",
            "head": {},
            "base": {},
        },
        "snap",
        "2026-03-24T00:00:00Z",
    )

    assert row["author_association"] == "MEMBER"
