from __future__ import annotations

from pathlib import Path
from typing import Any

from slop_farmer.app.deploy import run_deploy_dashboard
from slop_farmer.config import DeployDashboardOptions


def test_run_deploy_dashboard_preserves_default_dashboard_resolution(
    monkeypatch, tmp_path: Path
) -> None:
    captured: dict[str, Any] = {}
    snapshot_dir = tmp_path / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)

    monkeypatch.setattr(
        "slop_farmer.app.deploy.resolve_snapshot_source_dir",
        lambda **_: snapshot_dir,
    )

    def fake_run(command: list[str], *, cwd: Path, env: dict[str, str], check: bool) -> None:
        captured["command"] = command
        captured["cwd"] = cwd
        captured["env"] = env
        captured["check"] = check

    monkeypatch.setattr("subprocess.run", fake_run)

    run_deploy_dashboard(
        DeployDashboardOptions(
            pipeline_data_dir=tmp_path / "data",
            web_dir=tmp_path / "web",
            snapshot_dir=None,
            analysis_input=None,
            contributors_input=None,
            pr_scope_input=None,
            hf_repo_id="evalstate/transformers-pr",
            hf_revision="main",
            hf_materialize_dir=tmp_path / "materialized",
            refresh_contributors=False,
            dashboard_window_days=60,
            contributor_window_days=60,
            contributor_max_authors=0,
            private_space=False,
            commit_message="Deploy dashboard",
            space_id="evalstate/transformers-dashboard",
            space_title="Transformers Dashboard",
            space_emoji="📊",
            space_color_from="indigo",
            space_color_to="blue",
            space_short_description="Static dashboard",
            dataset_id="evalstate/transformers-pr",
            space_tags="dashboard,static,transformers",
        )
    )

    env = captured["env"]
    assert env["SNAPSHOT_DIR"] == str(snapshot_dir)
    assert "ANALYSIS_INPUT" not in env
    assert "CONTRIBUTORS_INPUT" not in env
    assert "PR_SCOPE_INPUT" not in env


def test_run_deploy_dashboard_passes_explicit_overrides(monkeypatch, tmp_path: Path) -> None:
    captured: dict[str, Any] = {}
    snapshot_dir = tmp_path / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)
    analysis_input = snapshot_dir / "analysis-report-hybrid.json"
    contributors_input = snapshot_dir / "new-contributors-report.json"
    pr_scope_input = snapshot_dir / "pr-scope-clusters.json"

    monkeypatch.setattr(
        "slop_farmer.app.deploy.resolve_snapshot_source_dir",
        lambda **_: snapshot_dir,
    )

    def fake_run(command: list[str], *, cwd: Path, env: dict[str, str], check: bool) -> None:
        captured["command"] = command
        captured["cwd"] = cwd
        captured["env"] = env
        captured["check"] = check

    monkeypatch.setattr("subprocess.run", fake_run)

    run_deploy_dashboard(
        DeployDashboardOptions(
            pipeline_data_dir=tmp_path / "data",
            web_dir=tmp_path / "web",
            snapshot_dir=None,
            analysis_input=analysis_input,
            contributors_input=contributors_input,
            pr_scope_input=pr_scope_input,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            refresh_contributors=True,
            dashboard_window_days=60,
            contributor_window_days=60,
            contributor_max_authors=5,
            private_space=True,
            commit_message="Deploy dashboard",
            space_id="evalstate/transformers-dashboard",
            space_title="Transformers Dashboard",
            space_emoji="📊",
            space_color_from="indigo",
            space_color_to="blue",
            space_short_description="Static dashboard",
            dataset_id="evalstate/transformers-pr",
            space_tags="dashboard,static,transformers",
        )
    )

    env = captured["env"]
    assert env["ANALYSIS_INPUT"] == str(analysis_input)
    assert env["CONTRIBUTORS_INPUT"] == str(contributors_input)
    assert env["PR_SCOPE_INPUT"] == str(pr_scope_input)
    assert env["REFRESH_CONTRIBUTORS"] == "1"
    assert env["PRIVATE_FLAG"] == "--private"


def test_run_deploy_dashboard_resolves_relative_override_paths(monkeypatch, tmp_path: Path) -> None:
    captured: dict[str, Any] = {}
    snapshot_dir = tmp_path / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)
    analysis_input = Path("inputs/analysis-report-hybrid.json")
    contributors_input = Path("inputs/new-contributors-report.json")
    pr_scope_input = Path("inputs/pr-scope-clusters.json")

    monkeypatch.chdir(tmp_path)
    for path in (analysis_input, contributors_input, pr_scope_input):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("{}", encoding="utf-8")

    monkeypatch.setattr(
        "slop_farmer.app.deploy.resolve_snapshot_source_dir",
        lambda **_: snapshot_dir,
    )

    def fake_run(command: list[str], *, cwd: Path, env: dict[str, str], check: bool) -> None:
        captured["command"] = command
        captured["cwd"] = cwd
        captured["env"] = env
        captured["check"] = check

    monkeypatch.setattr("subprocess.run", fake_run)

    run_deploy_dashboard(
        DeployDashboardOptions(
            pipeline_data_dir=tmp_path / "data",
            web_dir=tmp_path / "web",
            snapshot_dir=None,
            analysis_input=analysis_input,
            contributors_input=contributors_input,
            pr_scope_input=pr_scope_input,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            refresh_contributors=False,
            dashboard_window_days=60,
            contributor_window_days=60,
            contributor_max_authors=0,
            private_space=False,
            commit_message="Deploy dashboard",
            space_id="evalstate/transformers-dashboard",
            space_title="Transformers Dashboard",
            space_emoji="📊",
            space_color_from="indigo",
            space_color_to="blue",
            space_short_description="Static dashboard",
            dataset_id="evalstate/transformers-pr",
            space_tags="dashboard,static,transformers",
        )
    )

    env = captured["env"]
    assert env["ANALYSIS_INPUT"] == str((tmp_path / analysis_input).resolve())
    assert env["CONTRIBUTORS_INPUT"] == str((tmp_path / contributors_input).resolve())
    assert env["PR_SCOPE_INPUT"] == str((tmp_path / pr_scope_input).resolve())
