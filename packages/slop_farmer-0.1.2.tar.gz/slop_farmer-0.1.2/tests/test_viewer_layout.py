from slop_farmer.app.pipeline import _dataset_card, _merge_rows, _viewer_comment_rows


def test_viewer_comment_rows_split_by_pull_request_numbers() -> None:
    comments = [
        {"github_id": 1, "parent_kind": "issue", "parent_number": 10},
        {"github_id": 2, "parent_kind": "pull_request", "parent_number": 20},
        {"github_id": 3, "parent_kind": "issue_or_pr", "parent_number": 20},
        {"github_id": 4, "parent_kind": "issue_or_pr", "parent_number": 30},
    ]
    pull_requests = [
        {"number": 20},
    ]

    issue_comments, pr_comments = _viewer_comment_rows(comments, pull_requests)

    assert [row["github_id"] for row in issue_comments] == [1, 4]
    assert [row["github_id"] for row in pr_comments] == [2, 3]


def test_dataset_card_declares_viewer_configs() -> None:
    card = _dataset_card("huggingface/transformers", "20260320T000000Z", {})

    assert "configs:" in card
    assert "config_name: issues" in card
    assert "config_name: prs" in card
    assert "config_name: issue_comments" in card
    assert "config_name: pr_comments" in card
    assert "config_name: pr_reviews" in card
    assert "config_name: pr_files" in card
    assert "config_name: pr_diffs" in card
    assert "split: train" in card
    assert "path: pr_files.parquet" in card
    assert "path: pr_diffs.parquet" in card
    assert "file-level patch hunks, and full unified diffs are included" in card


def test_merge_rows_replaces_pr_files_for_rehydrated_pull_request() -> None:
    previous = [
        {
            "repo": "huggingface/transformers",
            "pull_request_number": 10,
            "filename": "src/old.py",
            "sha": "oldsha",
        },
        {
            "repo": "huggingface/transformers",
            "pull_request_number": 11,
            "filename": "src/keep.py",
            "sha": "keepsha",
        },
    ]
    delta = [
        {
            "repo": "huggingface/transformers",
            "pull_request_number": 10,
            "filename": "src/new.py",
            "sha": "newsha",
        }
    ]

    merged = _merge_rows("pr_files", previous, delta)

    assert merged == [
        {
            "repo": "huggingface/transformers",
            "pull_request_number": 10,
            "filename": "src/new.py",
            "sha": "newsha",
        },
        {
            "repo": "huggingface/transformers",
            "pull_request_number": 11,
            "filename": "src/keep.py",
            "sha": "keepsha",
        },
    ]
