from __future__ import annotations

import json
import shutil
import threading
from collections.abc import Mapping
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from fastapi.testclient import TestClient

from slop_farmer.app.pr_search_api import PrSearchApiSettings, create_app
from slop_farmer.config import PrSearchRefreshOptions
from slop_farmer.data.parquet_io import write_json, write_parquet
from slop_farmer.reports.pr_search_service import run_pr_search_refresh

RoutePayload = object | tuple[int, object]


def test_pr_search_api_serves_health_ready_and_read_routes(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
    )
    with TestClient(create_app(settings)) as client:
        assert client.get("/healthz").json() == {"ok": True}
        assert client.get("/readyz").json() == {"ok": True}

        status = client.get("/v1/repos/huggingface/transformers/status")
        assert status.status_code == 200
        assert status.json()["repo"] == "huggingface/transformers"
        assert "settings_json" not in status.json()
        assert isinstance(status.json()["settings"], dict)

        similar = client.get("/v1/repos/huggingface/transformers/pulls/10/similar?limit=3")
        assert similar.status_code == 200
        assert similar.json()["similar_prs"][0]["neighbor_pr_number"] == 11
        assert similar.json()["query"]["mode_used"] == "indexed"
        assert similar.json()["similar_count"] == 1
        assert "shared_filenames_json" not in similar.json()["similar_prs"][0]

        clusters = client.get("/v1/repos/huggingface/transformers/pulls/10/clusters?limit=3")
        assert clusters.status_code == 200
        cluster_payload = clusters.json()
        cluster_id = cluster_payload["candidate_clusters"][0]["cluster_id"]
        assert cluster_payload["assigned_clusters"][0]["cluster_id"] == cluster_id
        assert cluster_payload["query"]["mode_used"] == "indexed"
        assert cluster_payload["assigned_cluster_count"] == 1
        assert cluster_payload["candidate_cluster_count"] == 1
        assert "evidence_json" not in cluster_payload["candidate_clusters"][0]

        cluster = client.get(f"/v1/repos/huggingface/transformers/clusters/{cluster_id}")
        assert cluster.status_code == 200
        assert cluster.json()["cluster"]["cluster_id"] == cluster_id
        assert cluster.json()["member_count"] == 2
        assert "shared_filenames_json" not in cluster.json()["cluster"]

        cluster_list = client.get("/v1/repos/huggingface/transformers/clusters?limit=10")
        assert cluster_list.status_code == 200
        assert cluster_list.json()["clusters"][0]["cluster_id"] == cluster_id
        assert cluster_list.json()["cluster_count"] == 1
        assert cluster_list.json()["clusters"][0]["rank"] == 1
        assert "shared_filenames_json" not in cluster_list.json()["clusters"][0]

        contributor = client.get("/v1/repos/huggingface/transformers/contributors/alice")
        assert contributor.status_code == 200
        assert contributor.json()["contributor"]["author_login"] == "alice"
        assert contributor.json()["contributor"]["automation_risk_signal"] == "low"
        assert "pull_count" not in contributor.json()

        contributor_pulls = client.get(
            "/v1/repos/huggingface/transformers/contributors/alice/pulls?limit=1"
        )
        assert contributor_pulls.status_code == 200
        assert contributor_pulls.json()["pull_count"] == 1
        assert contributor_pulls.json()["pulls"][0]["pr_number"] == 11

        pr_contributor = client.get("/v1/repos/huggingface/transformers/pulls/10/contributor")
        assert pr_contributor.status_code == 200
        assert pr_contributor.json()["contributor"]["author_login"] == "alice"
        assert pr_contributor.json()["pr"]["pr_number"] == 10

        analysis_status = client.get("/v1/repos/huggingface/transformers/analysis/status")
        assert analysis_status.status_code == 200
        assert analysis_status.json() == {
            "repo": "huggingface/transformers",
            "active_snapshot_id": "20260415T000000Z",
            "snapshot_id": "20260415T000000Z",
            "run_id": status.json()["id"],
            "variant_requested": "auto",
            "available": True,
            "variant_used": "hybrid",
            "analysis_source": "snapshot",
            "llm_enrichment": True,
            "generated_at": "2026-04-15T01:00:00Z",
            "counts": {
                "meta_bugs": 1,
                "duplicate_issues": 0,
                "duplicate_prs": 1,
            },
        }

        deterministic_status = client.get(
            "/v1/repos/huggingface/transformers/analysis/status?variant=deterministic"
        )
        assert deterministic_status.status_code == 200
        assert deterministic_status.json()["variant_used"] == "deterministic"
        assert deterministic_status.json()["llm_enrichment"] is False

        pr_analysis = client.get("/v1/repos/huggingface/transformers/pulls/11/analysis")
        assert pr_analysis.status_code == 200
        assert pr_analysis.json()["found"] is True
        assert pr_analysis.json()["meta_bug"]["cluster_id"] == "issue-cluster-100-2"
        assert pr_analysis.json()["duplicate_pr"]["canonical_pr_number"] == 10

        pr_analysis_miss = client.get("/v1/repos/huggingface/transformers/pulls/20/analysis")
        assert pr_analysis_miss.status_code == 200
        assert pr_analysis_miss.json()["found"] is False
        assert pr_analysis_miss.json()["meta_bug"] is None
        assert pr_analysis_miss.json()["duplicate_pr"] is None

        meta_bugs = client.get("/v1/repos/huggingface/transformers/analysis/meta-bugs?limit=10")
        assert meta_bugs.status_code == 200
        assert meta_bugs.json()["meta_bug_count"] == 1
        assert meta_bugs.json()["meta_bugs"][0]["cluster_id"] == "issue-cluster-100-2"
        assert meta_bugs.json()["meta_bugs"][0]["rank"] == 1

        meta_bug = client.get(
            "/v1/repos/huggingface/transformers/analysis/meta-bugs/issue-cluster-100-2"
        )
        assert meta_bug.status_code == 200
        assert meta_bug.json()["meta_bug"]["cluster_id"] == "issue-cluster-100-2"
        assert meta_bug.json()["duplicate_pr"]["target_issue_number"] == 100

        duplicate_prs = client.get(
            "/v1/repos/huggingface/transformers/analysis/duplicate-prs?limit=10"
        )
        assert duplicate_prs.status_code == 200
        assert duplicate_prs.json()["duplicate_pr_count"] == 1
        assert duplicate_prs.json()["duplicate_prs"][0]["cluster_id"] == "issue-cluster-100-2"
        assert duplicate_prs.json()["duplicate_prs"][0]["rank"] == 1

        best = client.get("/v1/repos/huggingface/transformers/analysis/best")
        assert best.status_code == 200
        assert best.json()["best_issue"]["cluster_id"] == "issue-cluster-100-2"
        assert best.json()["best_pr"]["cluster_id"] == "issue-cluster-100-2"


def test_pr_search_api_probe_uses_ghreplica_client(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    routes = {
        "/v1/github/repos/huggingface/transformers/pulls/99": {
            "id": 999,
            "node_id": "PR_probe_99",
            "number": 99,
            "html_url": "https://example.invalid/pr/99",
            "url": "https://api.example.invalid/pr/99",
            "title": "Fix tokenizer edge case live probe",
            "body": "Probe query",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments": 0,
            "labels": [],
            "assignees": [],
            "created_at": "2026-04-15T00:00:00Z",
            "updated_at": "2026-04-15T00:00:00Z",
            "closed_at": None,
            "author_association": "NONE",
            "merged_at": None,
            "merge_commit_sha": None,
            "merged": False,
            "mergeable": True,
            "mergeable_state": "clean",
            "draft": False,
            "additions": 11,
            "deletions": 1,
            "changed_files": 2,
            "commits": 1,
            "review_comments": 0,
            "maintainer_can_modify": True,
            "head": {"ref": "probe", "sha": "headsha", "repo": {"full_name": "probe/repo"}},
            "base": {"ref": "main", "sha": "basesha", "repo": {"full_name": "upstream/repo"}},
            "user": {"login": "probe-user", "id": 1, "node_id": "U_1", "type": "User"},
        },
        "/v1/changes/repos/huggingface/transformers/pulls/99/files": [
            {
                "path": "src/tokenizer.py",
                "status": "modified",
                "additions": 6,
                "deletions": 0,
                "changes": 6,
                "patch": _patch(11, 6),
            },
            {
                "path": "tests/test_tokenizer.py",
                "status": "modified",
                "additions": 4,
                "deletions": 0,
                "changes": 4,
                "patch": _patch(27, 4),
            },
        ],
        "/v1/changes/repos/huggingface/transformers/pulls/99/status": {
            "indexed": True,
            "index_freshness": "stale_head_changed",
            "last_indexed_at": "2026-04-15T18:39:16.306232Z",
        },
    }
    with _json_server(routes) as base_url:
        settings = PrSearchApiSettings(
            default_repo="huggingface/transformers",
            index_path=db_path,
            output_dir=tmp_path,
            ghr_base_url=base_url,
        )
        with TestClient(create_app(settings)) as client:
            response = client.get("/v1/repos/huggingface/transformers/pulls/99/similar?limit=3")

    assert response.status_code == 200
    payload = response.json()
    assert payload["pr"]["pr_number"] == 99
    assert payload["similar_prs"][0]["neighbor_pr_number"] == 10
    assert payload["query"] == {
        "pr_number": 99,
        "mode_requested": "auto",
        "mode_used": "live",
        "source": "ghreplica",
    }
    assert payload["similar_count"] == len(payload["similar_prs"])
    assert payload["similar_prs"][0]["neighbor_pr_number"] == 10
    assert "shared_filenames_json" not in payload["similar_prs"][0]
    assert payload["probe_source"] == {
        "provider": "ghreplica",
        "base_url": base_url,
        "indexed": True,
        "index_freshness": "stale_head_changed",
        "last_indexed_at": "2026-04-15T18:39:16.306232Z",
    }


def test_pr_search_api_clusters_returns_live_candidate_context(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    routes = {
        "/v1/github/repos/huggingface/transformers/pulls/99": {
            "id": 999,
            "node_id": "PR_probe_99",
            "number": 99,
            "html_url": "https://example.invalid/pr/99",
            "url": "https://api.example.invalid/pr/99",
            "title": "Fix tokenizer edge case live probe",
            "body": "Probe query",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments": 0,
            "labels": [],
            "assignees": [],
            "created_at": "2026-04-15T00:00:00Z",
            "updated_at": "2026-04-15T00:00:00Z",
            "closed_at": None,
            "author_association": "NONE",
            "merged_at": None,
            "merge_commit_sha": None,
            "merged": False,
            "mergeable": True,
            "mergeable_state": "clean",
            "draft": False,
            "additions": 11,
            "deletions": 1,
            "changed_files": 2,
            "commits": 1,
            "review_comments": 0,
            "maintainer_can_modify": True,
            "head": {"ref": "probe", "sha": "headsha", "repo": {"full_name": "probe/repo"}},
            "base": {"ref": "main", "sha": "basesha", "repo": {"full_name": "upstream/repo"}},
            "user": {"login": "probe-user", "id": 1, "node_id": "U_1", "type": "User"},
        },
        "/v1/changes/repos/huggingface/transformers/pulls/99/files": [
            {
                "path": "src/tokenizer.py",
                "status": "modified",
                "additions": 6,
                "deletions": 0,
                "changes": 6,
                "patch": _patch(11, 6),
            },
            {
                "path": "tests/test_tokenizer.py",
                "status": "modified",
                "additions": 4,
                "deletions": 0,
                "changes": 4,
                "patch": _patch(27, 4),
            },
        ],
        "/v1/changes/repos/huggingface/transformers/pulls/99/status": {
            "indexed": True,
            "index_freshness": "stale_head_changed",
            "last_indexed_at": "2026-04-15T18:39:16.306232Z",
        },
    }
    with _json_server(routes) as base_url:
        settings = PrSearchApiSettings(
            default_repo="huggingface/transformers",
            index_path=db_path,
            output_dir=tmp_path,
            ghr_base_url=base_url,
        )
        with TestClient(create_app(settings)) as client:
            response = client.get("/v1/repos/huggingface/transformers/pulls/99/clusters?limit=3")

    assert response.status_code == 200
    payload = response.json()
    assert payload["pr"]["pr_number"] == 99
    assert payload["assigned_clusters"] == []
    assert payload["candidate_clusters"][0]["cluster_id"].startswith("pr-scope-10-2")
    assert payload["query"]["mode_used"] == "live"
    assert payload["assigned_cluster_count"] == 0
    assert payload["candidate_cluster_count"] == 1
    assert "evidence_json" not in payload["candidate_clusters"][0]


def test_pr_search_api_similar_returns_informative_replica_error(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    routes = {
        "/v1/github/repos/huggingface/transformers/pulls/99": {
            "id": 999,
            "node_id": "PR_probe_99",
            "number": 99,
            "html_url": "https://example.invalid/pr/99",
            "url": "https://api.example.invalid/pr/99",
            "title": "Fix tokenizer edge case live probe",
            "body": "Probe query",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments": 0,
            "labels": [],
            "assignees": [],
            "created_at": "2026-04-15T00:00:00Z",
            "updated_at": "2026-04-15T00:00:00Z",
            "closed_at": None,
            "author_association": "NONE",
            "merged_at": None,
            "merge_commit_sha": None,
            "merged": False,
            "mergeable": True,
            "mergeable_state": "clean",
            "draft": False,
            "additions": 11,
            "deletions": 1,
            "changed_files": 2,
            "commits": 1,
            "review_comments": 0,
            "maintainer_can_modify": True,
            "head": {"ref": "probe", "sha": "headsha", "repo": {"full_name": "probe/repo"}},
            "base": {"ref": "main", "sha": "basesha", "repo": {"full_name": "upstream/repo"}},
            "user": {"login": "probe-user", "id": 1, "node_id": "U_1", "type": "User"},
        },
        "/v1/changes/repos/huggingface/transformers/pulls/99/files": (
            404,
            {"message": "Not Found"},
        ),
        "/v1/changes/repos/huggingface/transformers/pulls/99/status": {
            "indexed": False,
            "backfill_in_progress": True,
            "changed_files": 0,
            "indexed_file_count": 0,
        },
    }
    with _json_server(routes) as base_url:
        settings = PrSearchApiSettings(
            default_repo="huggingface/transformers",
            index_path=db_path,
            output_dir=tmp_path,
            ghr_base_url=base_url,
        )
        with TestClient(create_app(settings)) as client:
            response = client.get("/v1/repos/huggingface/transformers/pulls/99/similar?limit=3")

    assert response.status_code == 503
    assert response.json() == {
        "detail": (
            "PR #99 is not available in ghreplica yet (indexed=False, "
            "backfill_in_progress=True, changed_files=0, indexed_file_count=0)."
        )
    }


def test_pr_search_api_can_refresh_on_start_from_snapshot(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
        snapshot_dir=snapshot_dir,
        refresh_if_missing=True,
    )

    with TestClient(create_app(settings)) as client:
        ready = client.get("/readyz")
        status = client.get("/v1/repos/huggingface/transformers/status")

    assert ready.status_code == 200
    assert status.status_code == 200
    assert status.json()["repo"] == "huggingface/transformers"


def test_pr_search_api_rejects_other_repos(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
    )
    with TestClient(create_app(settings)) as client:
        response = client.get("/v1/repos/openclaw/openclaw/status")

    assert response.status_code == 400
    assert response.json()["detail"] == (
        "repo huggingface/transformers is the only configured repo for this deployment"
    )


def test_pr_search_api_analysis_status_reports_unavailable_when_missing(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path, include_analysis=False)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
    )
    with TestClient(create_app(settings)) as client:
        status = client.get("/v1/repos/huggingface/transformers/analysis/status")
        detail = client.get("/v1/repos/huggingface/transformers/analysis/meta-bugs")

    assert status.status_code == 200
    assert status.json()["available"] is False
    assert "variant_used" not in status.json()
    assert detail.status_code == 404
    assert detail.json()["detail"] == (
        "No analysis report was found for the current analysis view or active snapshot."
    )


def test_pr_search_api_status_exposes_issue_and_contributor_surfaces(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
    )
    with TestClient(create_app(settings)) as client:
        response = client.get("/v1/repos/huggingface/transformers/status")

    assert response.status_code == 200
    payload = response.json()
    assert payload["surfaces"]["issues"] == {
        "available": True,
        "variant_used": "hybrid",
        "llm_enrichment": True,
        "generated_at": "2026-04-15T01:00:00Z",
        "cluster_count": 1,
        "duplicate_pr_count": 1,
        "available_variants": ["deterministic", "hybrid"],
    }
    assert payload["surfaces"]["contributors"] == {
        "available": True,
        "generated_at": "2026-04-15T01:30:00Z",
        "contributor_count": 1,
    }


def test_pr_search_api_serves_issue_cluster_routes(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
    )
    with TestClient(create_app(settings)) as client:
        status = client.get("/v1/repos/huggingface/transformers/issues/status?variant=auto")
        clusters = client.get("/v1/repos/huggingface/transformers/issues/clusters?limit=10")
        cluster = client.get(
            "/v1/repos/huggingface/transformers/issues/clusters/issue-cluster-100-2"
        )
        by_pr = client.get("/v1/repos/huggingface/transformers/issues/pulls/10")
        membership = client.get(
            "/v1/repos/huggingface/transformers/issues/pulls/10/membership"
            "?cluster_id=issue-cluster-100-2"
        )
        duplicate_prs = client.get(
            "/v1/repos/huggingface/transformers/issues/duplicate-prs?limit=10"
        )
        best = client.get("/v1/repos/huggingface/transformers/issues/best")

    assert status.status_code == 200
    assert status.json()["counts"] == {"meta_bugs": 1, "duplicate_issues": 0, "duplicate_prs": 1}
    assert clusters.status_code == 200
    assert clusters.json()["clusters"][0]["cluster_id"] == "issue-cluster-100-2"
    assert clusters.json()["clusters"][0]["canonical_issue_title"] == "Tokenizer issue"
    assert cluster.status_code == 200
    assert cluster.json()["found"] is True
    assert cluster.json()["pull_requests"][0]["role"] == "canonical"
    assert by_pr.status_code == 200
    assert by_pr.json()["found"] is True
    assert by_pr.json()["clusters"][0]["membership_role"] == "canonical"
    assert membership.status_code == 200
    assert membership.json()["matched"] is True
    assert membership.json()["membership"]["cluster_id"] == "issue-cluster-100-2"
    assert duplicate_prs.status_code == 200
    assert duplicate_prs.json()["duplicate_prs"][0]["duplicate_pr_numbers"] == [11]
    assert best.status_code == 200
    assert best.json()["best_issue"]["issue_number"] == 100
    assert best.json()["best_pr"]["pr_number"] == 10


def test_pr_search_api_returns_404_for_missing_variant_specific_report(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    (snapshot_dir / "analysis-report-hybrid.json").unlink()
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
    )
    with TestClient(create_app(settings)) as client:
        detail = client.get("/v1/repos/huggingface/transformers/analysis/meta-bugs?variant=hybrid")

    assert detail.status_code == 404
    assert (
        detail.json()["detail"]
        == "No analysis report was found for the current analysis view or active snapshot."
    )


def test_pr_search_api_analysis_prefers_materialized_current_analysis(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    materialized_dir = tmp_path / "snapshots" / "hf-evalstate--openclaw-pr"
    shutil.copytree(snapshot_dir, materialized_dir, dirs_exist_ok=True)
    _write_published_current_analysis(
        materialized_dir,
        analysis_id="hybrid-published-v1",
        generated_at="2026-04-15T04:00:00Z",
    )
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=materialized_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
        hf_repo_id="evalstate/openclaw-pr",
        hf_materialize_dir=materialized_dir,
    )
    with TestClient(create_app(settings)) as client:
        status = client.get("/v1/repos/huggingface/transformers/analysis/status")

    assert status.status_code == 200
    assert status.json()["analysis_source"] == "current"
    assert status.json()["analysis_id"] == "hybrid-published-v1"
    assert status.json()["generated_at"] == "2026-04-15T04:00:00Z"


def test_pr_search_api_analysis_resolves_archived_run_by_snapshot_and_analysis_id(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    materialized_dir = tmp_path / "snapshots" / "hf-evalstate--openclaw-pr"
    shutil.copytree(snapshot_dir, materialized_dir, dirs_exist_ok=True)
    _write_published_archived_analysis(
        materialized_dir,
        snapshot_id="20260414T000000Z",
        analysis_id="hybrid-older-v2",
        generated_at="2026-04-14T03:00:00Z",
    )
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=materialized_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
        hf_repo_id="evalstate/openclaw-pr",
        hf_materialize_dir=materialized_dir,
    )
    with TestClient(create_app(settings)) as client:
        status = client.get(
            "/v1/repos/huggingface/transformers/analysis/status"
            "?snapshot_id=20260414T000000Z&analysis_id=hybrid-older-v2"
        )

    assert status.status_code == 200
    assert status.json()["analysis_source"] == "archived"
    assert status.json()["analysis_id"] == "hybrid-older-v2"
    assert status.json()["snapshot_id"] == "20260414T000000Z"
    assert status.json()["generated_at"] == "2026-04-14T03:00:00Z"


def test_pr_search_api_analysis_deterministic_falls_back_to_legacy_snapshot_report(
    tmp_path,
) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    _write_published_current_analysis(
        snapshot_dir,
        analysis_id="hybrid-published-v1",
        generated_at="2026-04-15T04:00:00Z",
    )
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
    )
    with TestClient(create_app(settings)) as client:
        auto_status = client.get("/v1/repos/huggingface/transformers/analysis/status")
        deterministic_status = client.get(
            "/v1/repos/huggingface/transformers/analysis/status?variant=deterministic"
        )
        deterministic_meta_bugs = client.get(
            "/v1/repos/huggingface/transformers/analysis/meta-bugs?variant=deterministic"
        )

    assert auto_status.status_code == 200
    assert auto_status.json()["analysis_source"] == "current"
    assert auto_status.json()["analysis_id"] == "hybrid-published-v1"
    assert auto_status.json()["variant_used"] == "hybrid"

    assert deterministic_status.status_code == 200
    assert deterministic_status.json()["analysis_source"] == "snapshot"
    assert "analysis_id" not in deterministic_status.json()
    assert deterministic_status.json()["variant_used"] == "deterministic"
    assert deterministic_status.json()["llm_enrichment"] is False
    assert deterministic_status.json()["generated_at"] == "2026-04-15T00:30:00Z"

    assert deterministic_meta_bugs.status_code == 200
    assert deterministic_meta_bugs.json()["analysis_source"] == "snapshot"
    assert deterministic_meta_bugs.json()["variant_used"] == "deterministic"
    assert deterministic_meta_bugs.json()["meta_bug_count"] == 1


def test_pr_search_api_analysis_current_manifest_missing_artifact_returns_404(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    materialized_dir = tmp_path / "snapshots" / "hf-evalstate--openclaw-pr"
    shutil.copytree(snapshot_dir, materialized_dir, dirs_exist_ok=True)
    _write_published_current_analysis(
        materialized_dir,
        analysis_id="hybrid-broken-v1",
        generated_at="2026-04-15T04:00:00Z",
    )
    (materialized_dir / "analysis" / "current" / "analysis-report-hybrid.json").unlink()
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=materialized_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
        hf_repo_id="evalstate/openclaw-pr",
        hf_materialize_dir=materialized_dir,
    )
    with TestClient(create_app(settings)) as client:
        detail = client.get("/v1/repos/huggingface/transformers/analysis/meta-bugs")

    assert detail.status_code == 404
    assert "Published current analysis artifact" in detail.json()["detail"]


def test_pr_search_api_serves_contributor_routes(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
    )
    with TestClient(create_app(settings)) as client:
        status = client.get("/v1/repos/huggingface/transformers/contributors/status")
        contributors = client.get("/v1/repos/huggingface/transformers/contributors?limit=10")
        contributor = client.get("/v1/repos/huggingface/transformers/contributors/alice")
        risk = client.get("/v1/repos/huggingface/transformers/contributors/alice/risk")

    assert status.status_code == 200
    assert status.json()["contributor_count"] == 1
    assert contributors.status_code == 200
    assert contributors.json()["contributors"][0]["author_login"] == "alice"
    assert contributor.status_code == 200
    assert contributor.json()["found"] is True
    assert contributor.json()["summary"]["automation_risk_signal"] == "low"
    assert "pull_count" not in contributor.json()
    assert risk.status_code == 200
    assert risk.json()["risk_available"] is True
    assert risk.json()["risk"]["heuristic_note"] == "Looks normal."


def test_pr_search_api_contributor_routes_fall_back_to_materialized_snapshot(
    tmp_path, monkeypatch
) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    (snapshot_dir / "new-contributors-report.json").unlink()
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    materialized_dir = tmp_path / "snapshots" / "hf-evalstate--openclaw-pr"
    materialized_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
        },
        materialized_dir / "manifest.json",
    )
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
            "generated_at": "2026-04-15T01:30:00Z",
            "window_days": 42,
            "contributors": [
                {
                    "author_login": "alice",
                    "name": "Alice",
                    "profile_url": "https://github.com/alice",
                    "repo_pull_requests_url": "https://github.com/huggingface/transformers/pulls?q=author%3Aalice",
                    "repo_issues_url": "https://github.com/huggingface/transformers/issues?q=author%3Aalice",
                    "repo_association": "CONTRIBUTOR",
                    "new_to_repo": True,
                    "first_seen_in_snapshot": True,
                    "snapshot_pr_count": 1,
                    "snapshot_issue_count": 0,
                    "follow_through_score": 3,
                    "breadth_score": 2,
                    "automation_risk_signal": "low",
                    "heuristic_note": "Looks normal.",
                    "account_age_days": 120,
                    "activity": {
                        "visible_authored_pr_count": 5,
                        "distinct_repos_with_authored_prs": 2,
                    },
                    "examples": {"pull_requests": [], "issues": []},
                }
            ],
        },
        materialized_dir / "new-contributors-report.json",
    )

    monkeypatch.setattr(
        "slop_farmer.app.pr_search_api.materialize_hf_dataset_snapshot",
        lambda repo_id, local_dir, revision: local_dir,
    )

    settings = PrSearchApiSettings(
        default_repo="huggingface/transformers",
        index_path=db_path,
        output_dir=tmp_path,
        hf_repo_id="evalstate/openclaw-pr",
        hf_materialize_dir=materialized_dir,
    )
    with TestClient(create_app(settings)) as client:
        status = client.get("/v1/repos/huggingface/transformers/contributors/status")
        contributors = client.get("/v1/repos/huggingface/transformers/contributors?limit=10")
        repo_status = client.get("/v1/repos/huggingface/transformers/status")

    assert status.status_code == 200
    assert status.json()["available"] is True
    assert status.json()["contributor_count"] == 1
    assert contributors.status_code == 200
    assert contributors.json()["contributors"][0]["author_login"] == "alice"
    assert repo_status.status_code == 200
    assert repo_status.json()["surfaces"]["contributors"]["available"] is True


def _write_snapshot(tmp_path, *, include_analysis: bool = True):
    snapshot_dir = tmp_path / "snapshots" / "20260415T000000Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 100,
                "html_url": "https://example.invalid/issues/100",
                "title": "Tokenizer issue",
                "body": "Tokenizer issue body",
                "state": "open",
                "created_at": "2026-04-14T00:00:00Z",
                "updated_at": "2026-04-15T00:00:00Z",
                "author_login": "alice",
            }
        ],
        snapshot_dir / "issues.parquet",
        "issues",
    )
    write_parquet(
        [
            {
                **_pr_row(
                    10,
                    title="Fix tokenizer edge case",
                    state="open",
                    draft=False,
                    additions=10,
                    deletions=2,
                    changed_files=2,
                    author_login="alice",
                ),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_row(
                    11,
                    title="Fix tokenizer cache edge case",
                    state="open",
                    draft=False,
                    additions=9,
                    deletions=3,
                    changed_files=2,
                    author_login="alice",
                ),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_row(
                    20,
                    title="Refactor modeling utils",
                    state="open",
                    draft=False,
                    additions=12,
                    deletions=4,
                    changed_files=1,
                    author_login="bob",
                ),
                "repo": "huggingface/transformers",
            },
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet(
        [
            _contributor_row("alice", snapshot_pr_count=2, risk="low"),
            _contributor_row("bob", snapshot_pr_count=1, risk="medium"),
        ],
        snapshot_dir / "new_contributors.parquet",
        "new_contributors",
    )
    write_parquet(
        [
            {
                **_pr_file_row(10, "src/tokenizer.py", start=10, count=6),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(10, "tests/test_tokenizer.py", start=25, count=4),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(11, "src/tokenizer.py", start=12, count=5),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(11, "tests/test_tokenizer.py", start=28, count=4),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(20, "src/modeling_utils.py", start=180, count=8),
                "repo": "huggingface/transformers",
            },
        ],
        snapshot_dir / "pr_files.parquet",
        "pr_files",
    )
    if include_analysis:
        _write_analysis_reports(snapshot_dir)
    _write_contributor_report(snapshot_dir)
    return snapshot_dir


def _write_contributor_report(snapshot_dir) -> None:
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
            "generated_at": "2026-04-15T01:30:00Z",
            "window_days": 42,
            "contributors": [
                {
                    "author_login": "alice",
                    "name": "Alice",
                    "profile_url": "https://github.com/alice",
                    "repo_pull_requests_url": "https://github.com/huggingface/transformers/pulls?q=author%3Aalice",
                    "repo_issues_url": "https://github.com/huggingface/transformers/issues?q=author%3Aalice",
                    "repo_first_seen_at": "2026-04-14T00:00:00Z",
                    "repo_last_seen_at": "2026-04-15T00:00:00Z",
                    "repo_primary_artifact_count": 1,
                    "repo_artifact_count": 1,
                    "snapshot_issue_count": 0,
                    "snapshot_pr_count": 1,
                    "snapshot_comment_count": 0,
                    "snapshot_review_count": 0,
                    "snapshot_review_comment_count": 0,
                    "repo_association": "CONTRIBUTOR",
                    "new_to_repo": True,
                    "first_seen_in_snapshot": True,
                    "report_reason": "new contributor",
                    "account_age_days": 120,
                    "young_account": False,
                    "follow_through_score": 3,
                    "breadth_score": 2,
                    "automation_risk_signal": "low",
                    "heuristic_note": "Looks normal.",
                    "public_orgs": ["huggingface"],
                    "activity": {
                        "visible_authored_pr_count": 5,
                        "distinct_repos_with_authored_prs": 2,
                    },
                    "examples": {
                        "pull_requests": [
                            {
                                "kind": "pull_request",
                                "number": 10,
                                "title": "Fix tokenizer edge case",
                                "url": "https://example.invalid/pr/10",
                                "state": "open",
                                "merged": False,
                                "draft": False,
                            }
                        ],
                        "issues": [],
                    },
                }
            ],
        },
        snapshot_dir / "new-contributors-report.json",
    )


def _write_analysis_reports(snapshot_dir, *, snapshot_id: str = "20260415T000000Z") -> None:
    base_payload = {
        "schema_version": "1.0",
        "repo": "huggingface/transformers",
        "snapshot_id": snapshot_id,
        "generated_at": "2026-04-15T01:00:00Z",
        "evidence_quality": "partial",
        "meta_bugs": [
            {
                "cluster_id": "issue-cluster-100-2",
                "summary": "Tokenizer issue cluster",
                "status": "open",
                "confidence": 0.93,
                "canonical_issue_number": 100,
                "canonical_pr_number": 10,
                "issue_numbers": [100],
                "pr_numbers": [10, 11],
                "evidence_types": ["closing_reference"],
                "canonical_issue_reason": "Most referenced issue.",
                "canonical_pr_reason": "Best PR for the issue.",
                "best_issue_reason": "Best issue.",
                "best_pr_reason": "Best PR.",
            }
        ],
        "duplicate_issues": [],
        "duplicate_prs": [
            {
                "cluster_id": "issue-cluster-100-2",
                "canonical_pr_number": 10,
                "duplicate_pr_numbers": [11],
                "target_issue_number": 100,
                "reason": "Same fix path.",
            }
        ],
        "best_issue": {
            "cluster_id": "issue-cluster-100-2",
            "issue_number": 100,
            "reason": "Best issue.",
            "score": 0.91,
        },
        "best_pr": {
            "cluster_id": "issue-cluster-100-2",
            "pr_number": 10,
            "reason": "Best PR.",
            "score": 0.92,
        },
    }
    write_json(
        {
            **base_payload,
            "llm_enrichment": False,
            "generated_at": "2026-04-15T00:30:00Z",
        },
        snapshot_dir / "analysis-report.json",
    )
    write_json(
        {
            **base_payload,
            "llm_enrichment": True,
        },
        snapshot_dir / "analysis-report-hybrid.json",
    )


def _write_published_current_analysis(
    snapshot_dir,
    *,
    analysis_id: str,
    generated_at: str,
    snapshot_id: str = "20260415T000000Z",
) -> None:
    current_dir = snapshot_dir / "analysis" / "current"
    current_dir.mkdir(parents=True, exist_ok=True)
    write_json(
        {
            "schema_version": 1,
            "repo": "huggingface/transformers",
            "snapshot_id": snapshot_id,
            "analysis_id": analysis_id,
            "variant": "hybrid",
            "channel": "canonical",
            "model": "gpt-5.4-mini",
            "published_at": generated_at,
            "artifacts": {
                "hybrid": "analysis/current/analysis-report-hybrid.json",
            },
            "archived_artifacts": {
                "hybrid": (
                    f"snapshots/{snapshot_id}/analysis-runs/{analysis_id}/analysis-report-hybrid.json"
                ),
            },
        },
        current_dir / "manifest.json",
    )
    write_json(
        {
            "schema_version": "1.0",
            "repo": "huggingface/transformers",
            "snapshot_id": snapshot_id,
            "generated_at": generated_at,
            "llm_enrichment": True,
            "meta_bugs": [],
            "duplicate_issues": [],
            "duplicate_prs": [],
            "best_issue": None,
            "best_pr": None,
        },
        current_dir / "analysis-report-hybrid.json",
    )


def _write_published_archived_analysis(
    snapshot_dir,
    *,
    snapshot_id: str,
    analysis_id: str,
    generated_at: str,
) -> None:
    archived_dir = snapshot_dir / "snapshots" / snapshot_id / "analysis-runs" / analysis_id
    archived_dir.mkdir(parents=True, exist_ok=True)
    write_json(
        {
            "schema_version": 1,
            "repo": "huggingface/transformers",
            "snapshot_id": snapshot_id,
            "analysis_id": analysis_id,
            "variant": "hybrid",
            "channel": "comparison",
            "model": "gpt-5.4-mini",
            "published_at": generated_at,
            "artifacts": {
                "hybrid": (
                    f"snapshots/{snapshot_id}/analysis-runs/{analysis_id}/analysis-report-hybrid.json"
                ),
            },
        },
        archived_dir / "manifest.json",
    )
    write_json(
        {
            "schema_version": "1.0",
            "repo": "huggingface/transformers",
            "snapshot_id": snapshot_id,
            "generated_at": generated_at,
            "llm_enrichment": True,
            "meta_bugs": [],
            "duplicate_issues": [],
            "duplicate_prs": [],
            "best_issue": None,
            "best_pr": None,
        },
        archived_dir / "analysis-report-hybrid.json",
    )


def _pr_row(
    number: int,
    *,
    title: str,
    state: str,
    draft: bool,
    additions: int,
    deletions: int,
    changed_files: int,
    author_login: str,
) -> dict[str, object]:
    return {
        "number": number,
        "title": title,
        "state": state,
        "draft": draft,
        "merged": False,
        "additions": additions,
        "deletions": deletions,
        "changed_files": changed_files,
        "comments_count": 0,
        "review_comments_count": 0,
        "html_url": f"https://example.invalid/pr/{number}",
        "base_ref": "main",
        "created_at": "2026-04-15T00:00:00Z",
        "updated_at": "2026-04-15T00:00:00Z",
        "merged_at": None,
        "author_login": author_login,
    }


def _pr_file_row(pr_number: int, filename: str, *, start: int, count: int) -> dict[str, object]:
    return {
        "pull_request_number": pr_number,
        "filename": filename,
        "additions": count,
        "deletions": 0,
        "changes": count,
        "patch": _patch(start, count),
    }


def _patch(start: int, count: int) -> str:
    header = f"@@ -1,{count} +{start},{count} @@"
    body = "\n".join(f"+line_{index}" for index in range(count))
    return f"{header}\n{body}"


def _contributor_row(login: str, *, snapshot_pr_count: int, risk: str) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "snapshot_id": "20260415T000000Z",
        "report_generated_at": "2026-04-15T00:00:00Z",
        "window_days": 42,
        "author_login": login,
        "name": login.title(),
        "profile_url": f"https://github.com/{login}",
        "repo_pull_requests_url": f"https://github.com/huggingface/transformers/pulls?q=author%3A{login}",
        "repo_issues_url": f"https://github.com/huggingface/transformers/issues?q=author%3A{login}",
        "repo_first_seen_at": "2026-04-15T00:00:00Z",
        "repo_last_seen_at": "2026-04-15T00:00:00Z",
        "repo_primary_artifact_count": snapshot_pr_count,
        "repo_artifact_count": snapshot_pr_count,
        "snapshot_issue_count": 0,
        "snapshot_pr_count": snapshot_pr_count,
        "snapshot_comment_count": 0,
        "snapshot_review_count": 0,
        "snapshot_review_comment_count": 0,
        "repo_association": "CONTRIBUTOR",
        "new_to_repo": True,
        "first_seen_in_snapshot": True,
        "report_reason": "first_seen_in_snapshot",
        "account_age_days": 120,
        "young_account": True,
        "follow_through_score": "strong",
        "breadth_score": "low",
        "automation_risk_signal": risk,
        "heuristic_note": "note",
        "public_orgs": ["org-a"] if login == "alice" else [],
        "visible_authored_pr_count": snapshot_pr_count,
        "merged_pr_count": 0,
        "closed_unmerged_pr_count": 0,
        "open_pr_count": snapshot_pr_count,
        "merged_pr_rate": 0.0,
        "closed_unmerged_pr_rate": 0.0,
        "still_open_pr_rate": 1.0,
        "distinct_repos_with_authored_prs": 1,
        "distinct_repos_with_open_prs": 1,
        "fetch_error": None,
    }


@contextmanager
def _json_server(routes: Mapping[str, RoutePayload]):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            payload = routes.get(self.path)
            if payload is None:
                self.send_response(404)
                self.end_headers()
                return
            status_code, body_obj = _route_response(payload)
            body = json.dumps(body_obj).encode("utf-8")
            self.send_response(status_code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format: str, *args: object) -> None:
            del format, args

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_address[1]}"
    finally:
        server.shutdown()
        thread.join()
        server.server_close()


def _route_response(payload: RoutePayload) -> tuple[int, object]:
    if isinstance(payload, tuple):
        if len(payload) != 2 or not isinstance(payload[0], int):
            raise TypeError(f"invalid route payload: {payload!r}")
        return payload[0], payload[1]
    return 200, payload
