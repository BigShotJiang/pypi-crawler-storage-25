import asyncio
import json
import shutil
from collections import defaultdict
from pathlib import Path

import pytest

from slop_farmer.config import AnalysisOptions, MarkdownReportOptions
from slop_farmer.data.parquet_io import read_parquet_rows, write_json, write_parquet
from slop_farmer.data.snapshot_materialize import (
    _hf_dataset_parquet_urls,
    _hf_latest_snapshot_candidates,
    _parquet_table_name,
    materialize_hf_dataset_snapshot,
)
from slop_farmer.reports.analysis import (
    LLM_MAX_DIFF_CHARS_PER_ITEM,
    LLM_MAX_FILENAMES_PER_ITEM,
    LLM_MAX_INPUT_TOKENS,
    ArtifactFeature,
    ClusterAnalysisCallResult,
    ClusterAnalystResponse,
    ClusterRecord,
    PacketBudget,
    PreparedLlmPacket,
    SnapshotData,
    SoftEdgeVerdict,
    _accepted_soft_pairs,
    _estimate_packet_size,
    _hybrid_review_cache_manifest,
    _pr_duplicate_candidates,
    _prepare_packet_for_llm,
    _reference_counts,
    _select_issue_anchor_for_pr_cluster,
    _should_run_evaluator,
    _split_packet_for_review,
    _strip_pull_request_template,
    render_markdown_report,
    run_analysis,
)
from slop_farmer.reports.analysis_cache import HybridReviewCacheStore
from slop_farmer.reports.pr_heuristics import build_template_cleanup_settings


def test_analyze_builds_shortlist_with_backfilled_links(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=False)

    output_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=None,
            output_dir=output_dir,
            output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )

    report = json.loads(output_path.read_text())
    assert output_path == snapshot_dir / "analysis-report.json"
    assert report["repo"] == "huggingface/transformers"
    assert report["snapshot_id"] == "20260320T000000Z"
    assert report["evidence_quality"] == "partial"
    assert report["llm_enrichment"] is False
    assert list(report.keys()) == [
        "schema_version",
        "repo",
        "snapshot_id",
        "generated_at",
        "evidence_quality",
        "llm_enrichment",
        "meta_bugs",
        "duplicate_issues",
        "duplicate_prs",
        "best_issue",
        "best_pr",
    ]

    duplicate_prs = {entry["target_issue_number"]: entry for entry in report["duplicate_prs"]}
    assert duplicate_prs[1]["canonical_pr_number"] == 10
    assert duplicate_prs[1]["duplicate_pr_numbers"] == [11]
    assert duplicate_prs[2]["canonical_pr_number"] == 20
    assert duplicate_prs[2]["duplicate_pr_numbers"] == [21]

    duplicate_issue = report["duplicate_issues"][0]
    assert duplicate_issue["canonical_issue_number"] == 1
    assert duplicate_issue["duplicate_issue_numbers"] == [3]

    best_issue = report["best_issue"]
    assert best_issue["issue_number"] == 1

    best_pr = report["best_pr"]
    assert best_pr["pr_number"] == 20

    mixed_cluster = next(
        entry for entry in report["meta_bugs"] if entry["canonical_issue_number"] == 1
    )
    assert mixed_cluster["canonical_pr_number"] == 10
    assert mixed_cluster["issue_numbers"] == [1, 3]
    assert mixed_cluster["pr_numbers"] == [10, 11]
    assert mixed_cluster["pr_comparisons"][0]["shared_filenames"] == ["src/tokenizer.py"]
    assert mixed_cluster["pr_comparisons"][0]["area_overlap"] > 0
    assert all(len(entry["pr_numbers"]) >= 2 for entry in report["meta_bugs"])


def test_analyze_accepts_explicit_snapshot_dir_and_events_file(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=True)
    output_path = tmp_path / "custom-report.json"

    result_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=output_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="deterministic",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=1,
        )
    )

    report = json.loads(result_path.read_text())
    assert result_path == output_path
    assert report["evidence_quality"] == "full"
    assert len(report["meta_bugs"]) == 1


def test_analyze_warns_when_hybrid_falls_back_to_deterministic(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    output_dir = tmp_path / "analysis_data"
    _write_snapshot(output_dir, include_events=False)
    monkeypatch.setattr("slop_farmer.reports.analysis._can_use_fast_agent", lambda: False)

    run_analysis(
        AnalysisOptions(
            snapshot_dir=None,
            output_dir=output_dir,
            output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini",
            max_clusters=10,
        )
    )

    captured = capsys.readouterr()
    assert "ranking-backend=hybrid" in captured.err
    assert "falling back to deterministic-only clustering" in captured.err


def test_analyze_ignores_links_from_comments_on_missing_pull_requests(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=False)
    comments = read_parquet_rows(snapshot_dir / "comments.parquet")
    comments.append(
        _comment_row(102, "pull_request", 6091, "Fixes #1", created_at="2026-03-11T02:00:00Z")
    )
    write_parquet(comments, snapshot_dir / "comments.parquet", "comments")

    output_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "missing-pr-report.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="deterministic",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )

    report = json.loads(output_path.read_text())
    assert report["duplicate_prs"]


def test_analyze_filters_out_single_pr_meta_bug_clusters(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=False)
    pull_requests = [
        row
        for row in read_parquet_rows(snapshot_dir / "pull_requests.parquet")
        if row["number"] != 21
    ]
    write_parquet(pull_requests, snapshot_dir / "pull_requests.parquet", "pull_requests")

    output_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "single-pr-filtered.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="deterministic",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )

    report = json.loads(output_path.read_text())
    assert [entry["canonical_issue_number"] for entry in report["meta_bugs"]] == [1]
    assert report["best_issue"]["issue_number"] == 1
    assert report["best_pr"]["pr_number"] == 10


def test_analyze_open_prs_only_filters_closed_prs_from_report(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=False)

    output_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "open-only-report.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="deterministic",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
            open_prs_only=True,
        )
    )

    report = json.loads(output_path.read_text())
    assert report["meta_bugs"] == []
    assert report["duplicate_prs"] == []
    assert report["best_pr"] is None


def test_analyze_strips_pr_template_boilerplate_from_similarity_tokens(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    template_body = """# What does this PR do?

<!-- Please describe the change. -->

Fixes #123

## Code Agent Policy
The Transformers repo is currently being overwhelmed by a large number of PRs and issue comments written by code agents.
- [ ] I confirm that this is not a pure code agent PR.

## Before submitting
- [ ] Did you read the contributor guideline?
- [ ] Did you write tests?

## Who can review?

Anyone in the community is free to review the PR once the tests have passed.
"""
    snapshot_dir = _write_custom_snapshot(
        output_dir,
        issues=[
            _issue_row(
                1,
                "Alpha issue",
                "Alpha body.",
                state="open",
                comments_count=0,
                created_at="2026-03-01T00:00:00Z",
            ),
            _issue_row(
                2,
                "Beta issue",
                "Beta body.",
                state="open",
                comments_count=0,
                created_at="2026-03-02T00:00:00Z",
            ),
        ],
        pull_requests=[
            _pr_row(
                10,
                "Add Molmo",
                template_body,
                state="open",
                merged=False,
                draft=False,
                created_at="2026-03-03T00:00:00Z",
                closed_at=None,
                merged_at=None,
                additions=5,
                deletions=1,
                changed_files=1,
            ),
            _pr_row(
                11,
                "fix",
                template_body,
                state="open",
                merged=False,
                draft=False,
                created_at="2026-03-04T00:00:00Z",
                closed_at=None,
                merged_at=None,
                additions=4,
                deletions=1,
                changed_files=1,
            ),
        ],
    )

    output_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "template-strip-report.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="deterministic",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )

    report = json.loads(output_path.read_text())
    assert report["meta_bugs"] == []
    assert report["duplicate_prs"] == []


def test_strip_pull_request_template_keeps_explanatory_text_after_fix_reference() -> None:
    body = """# What does this PR do?

Fixes #44960 by normalizing the cache key before lookup.

## Code Agent Policy
This is boilerplate.

## Before submitting
- [ ] Checklist item

The actual explanation is above.
"""

    cleaned = _strip_pull_request_template(body)
    assert "Fixes #44960" not in cleaned
    assert "normalizing the cache key before lookup." in cleaned
    assert "Code Agent Policy" not in cleaned
    assert "Checklist item" not in cleaned


def test_strip_pull_request_template_supports_repo_specific_sections() -> None:
    body = """# What does this PR do?

Useful explanation.

## Release manager checklist
- [ ] bump version
- [ ] publish wheel

## Details
More useful explanation.
"""

    cleaned = _strip_pull_request_template(
        body,
        settings=build_template_cleanup_settings(
            section_patterns=(r"^#{1,6}\s*release manager checklist\s*$",)
        ),
    )

    assert "Useful explanation." in cleaned
    assert "More useful explanation." in cleaned
    assert "bump version" not in cleaned


def test_strip_pull_request_template_can_replace_defaults() -> None:
    body = """# What does this PR do?

## Code Agent Policy
This is boilerplate.

## Release manager checklist
- [ ] bump version

## Release notes
Important release note.
"""

    cleaned = _strip_pull_request_template(
        body,
        settings=build_template_cleanup_settings(
            mode="replace_defaults",
            section_patterns=(r"^#{1,6}\s*release manager checklist\s*$",),
        ),
    )

    assert "What does this PR do?" in cleaned
    assert "Code Agent Policy" in cleaned
    assert "Important release note." in cleaned
    assert "bump version" not in cleaned


def test_analyze_suppresses_configured_routine_post_release_prs(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_custom_snapshot(
        output_dir,
        issues=[
            _issue_row(
                1,
                "Release automation issue",
                "Tracks post-release work.",
                state="open",
                comments_count=0,
                created_at="2026-03-01T00:00:00Z",
            )
        ],
        pull_requests=[
            _pr_row(
                10,
                "post release 0.1.0",
                "Fixes #1\n\nPost-release automation update.",
                state="open",
                merged=False,
                draft=False,
                created_at="2026-03-03T00:00:00Z",
                closed_at=None,
                merged_at=None,
                additions=5,
                deletions=1,
                changed_files=2,
            ),
            _pr_row(
                11,
                "post release 0.1.1",
                "Fixes #1\n\nPost-release automation update.",
                state="open",
                merged=False,
                draft=False,
                created_at="2026-03-04T00:00:00Z",
                closed_at=None,
                merged_at=None,
                additions=4,
                deletions=1,
                changed_files=2,
            ),
        ],
        pr_files=[
            {
                "repo": "huggingface/transformers",
                "pull_request_number": 10,
                "sha": "a",
                "filename": "setup.py",
                "status": "modified",
                "additions": 3,
                "deletions": 1,
                "changes": 4,
                "blob_url": "",
                "raw_url": "",
                "contents_url": "",
                "previous_filename": None,
                "patch": "@@ -1 +1 @@\n-old\n+new\n",
                "snapshot_id": "20260320T000000Z",
                "extracted_at": "2026-03-20T00:00:00Z",
            },
            {
                "repo": "huggingface/transformers",
                "pull_request_number": 11,
                "sha": "b",
                "filename": "setup.py",
                "status": "modified",
                "additions": 3,
                "deletions": 1,
                "changes": 4,
                "blob_url": "",
                "raw_url": "",
                "contents_url": "",
                "previous_filename": None,
                "patch": "@@ -1 +1 @@\n-old\n+new\n",
                "snapshot_id": "20260320T000000Z",
                "extracted_at": "2026-03-20T00:00:00Z",
            },
        ],
        links=[
            {
                "repo": "huggingface/transformers",
                "source_type": "pull_request",
                "source_number": 10,
                "source_github_id": 10,
                "target_owner": "huggingface",
                "target_repo": "transformers",
                "target_number": 1,
                "link_type": "closing_reference",
                "link_origin": "text",
                "snapshot_id": "20260320T000000Z",
                "extracted_at": "2026-03-20T00:00:00Z",
            },
            {
                "repo": "huggingface/transformers",
                "source_type": "pull_request",
                "source_number": 11,
                "source_github_id": 11,
                "target_owner": "huggingface",
                "target_repo": "transformers",
                "target_number": 1,
                "link_type": "closing_reference",
                "link_origin": "text",
                "snapshot_id": "20260320T000000Z",
                "extracted_at": "2026-03-20T00:00:00Z",
            },
        ],
    )

    baseline_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "baseline.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="deterministic",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )
    baseline = json.loads(baseline_path.read_text())
    assert baseline["duplicate_prs"]

    suppressed_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "suppressed.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="deterministic",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
            cluster_suppression_rules=(
                {"id": "post_release", "title_patterns": [r"\bpost[- ]release\b"]},
            ),
        )
    )
    suppressed = json.loads(suppressed_path.read_text())
    assert suppressed["duplicate_prs"] == []


def test_prepare_packet_for_llm_truncates_over_budget_packet() -> None:
    packet = {
        "nodes": ["pull_request:10", "pull_request:11"],
        "items": [
            {
                "node_id": "pull_request:10",
                "filenames": [f"src/file_{index}.py" for index in range(40)],
                "diff_preview": "a" * 180_000,
            },
            {
                "node_id": "pull_request:11",
                "filenames": [f"src/file_{index}.py" for index in range(40)],
                "diff_preview": "b" * 180_000,
            },
        ],
        "pair_evidence": {"pull_request:10|pull_request:11": ["soft_similarity"]},
        "soft_pairs": [
            {
                "left": "pull_request:10",
                "right": "pull_request:11",
                "score": 8.0,
                "jaccard": 0.6,
                "evidence_types": ["soft_similarity"],
                "shared_targets": [1],
                "shared_filenames": ["src/file_0.py"],
                "deterministic_accept": False,
            }
        ],
    }

    prepared = _prepare_packet_for_llm(packet, "gpt-5.4-mini?service_tier=flex", split=False)

    assert prepared is not None
    assert prepared.trimmed is True
    assert prepared.budget.estimated_input_tokens < prepared.original_budget.estimated_input_tokens
    assert all(
        len(item["filenames"]) <= LLM_MAX_FILENAMES_PER_ITEM for item in prepared.packet["items"]
    )
    assert all(
        len(item["diff_preview"]) <= LLM_MAX_DIFF_CHARS_PER_ITEM
        for item in prepared.packet["items"]
    )


def test_split_packet_for_review_uses_token_budget() -> None:
    packet = {
        "nodes": [
            "pull_request:10",
            "pull_request:11",
            "pull_request:12",
            "pull_request:13",
        ],
        "items": [
            {
                "node_id": f"pull_request:{number}",
                "filenames": [f"src/file_{number}.py"],
                "diff_preview": "x" * 65_000,
            }
            for number in range(10, 14)
        ],
        "pair_evidence": {
            "pull_request:10|pull_request:11": ["soft_similarity"],
            "pull_request:11|pull_request:12": ["soft_similarity"],
            "pull_request:12|pull_request:13": ["soft_similarity"],
        },
        "soft_pairs": [
            {
                "left": "pull_request:10",
                "right": "pull_request:11",
                "score": 9.0,
                "jaccard": 0.9,
                "evidence_types": ["soft_similarity"],
                "shared_targets": [1],
                "shared_filenames": ["src/file_10.py"],
                "deterministic_accept": False,
            },
            {
                "left": "pull_request:11",
                "right": "pull_request:12",
                "score": 8.5,
                "jaccard": 0.85,
                "evidence_types": ["soft_similarity"],
                "shared_targets": [1],
                "shared_filenames": ["src/file_11.py"],
                "deterministic_accept": False,
            },
            {
                "left": "pull_request:12",
                "right": "pull_request:13",
                "score": 8.0,
                "jaccard": 0.8,
                "evidence_types": ["soft_similarity"],
                "shared_targets": [1],
                "shared_filenames": ["src/file_12.py"],
                "deterministic_accept": False,
            },
        ],
    }

    full_budget = _estimate_packet_size(packet, "gpt-5.4-mini?service_tier=flex")

    assert full_budget.estimated_input_tokens > LLM_MAX_INPUT_TOKENS

    review_units = _split_packet_for_review(packet, "gpt-5.4-mini?service_tier=flex")

    assert len(review_units) == 2
    assert all(
        _estimate_packet_size(unit, "gpt-5.4-mini?service_tier=flex").estimated_input_tokens
        <= LLM_MAX_INPUT_TOKENS
        for unit in review_units
    )


def test_should_run_evaluator_requires_nontrivial_accept() -> None:
    packet = {
        "soft_pairs": [
            {
                "left": "pull_request:10",
                "right": "pull_request:11",
                "deterministic_accept": True,
            },
            {
                "left": "pull_request:10",
                "right": "pull_request:12",
                "deterministic_accept": False,
            },
        ]
    }
    budget = PacketBudget(
        node_count=3,
        item_count=3,
        soft_pair_count=2,
        serialized_chars=1_000,
        estimated_input_tokens=250,
        estimated_eval_tokens=800,
    )

    trivial_accept = ClusterAnalystResponse(
        summary="summary",
        confidence=0.8,
        soft_edge_verdicts=[
            SoftEdgeVerdict(
                left="pull_request:10",
                right="pull_request:11",
                accept=True,
                reason="already obvious",
            )
        ],
    )
    nontrivial_accept = ClusterAnalystResponse(
        summary="summary",
        confidence=0.8,
        soft_edge_verdicts=[
            SoftEdgeVerdict(
                left="pull_request:10",
                right="pull_request:12",
                accept=True,
                reason="important call",
            )
        ],
    )

    assert (
        _should_run_evaluator(
            packet,
            budget,
            split=False,
            aggressively_trimmed=False,
            analyst_result=trivial_accept,
        )
        is False
    )
    assert _should_run_evaluator(
        packet,
        budget,
        split=False,
        aggressively_trimmed=False,
        analyst_result=nontrivial_accept,
    )
    assert _should_run_evaluator(
        packet,
        budget,
        split=True,
        aggressively_trimmed=False,
        analyst_result=nontrivial_accept,
    )


def test_pr_duplicate_candidates_preserve_shared_target_connectivity_for_large_groups() -> None:
    issue_map = {
        1: _issue_row(
            1,
            "Tracking issue",
            "Tracks duplicate PRs.",
            state="open",
            comments_count=0,
            created_at="2026-03-01T00:00:00Z",
        )
    }
    pr_map = {
        number: _pr_row(
            number,
            f"Candidate {number}",
            "Fixes #1",
            state="open",
            merged=False,
            draft=False,
            created_at=f"2026-03-{index + 1:02d}T00:00:00Z",
            closed_at=None,
            merged_at=None,
            additions=2,
            deletions=1,
            changed_files=1,
        )
        for index, number in enumerate(range(10, 30))
    }
    pr_map[99] = _pr_row(
        99,
        "Different base",
        "Fixes #1",
        state="open",
        merged=False,
        draft=False,
        created_at="2026-03-20T00:00:00Z",
        closed_at=None,
        merged_at=None,
        additions=2,
        deletions=1,
        changed_files=1,
    )
    pr_map[99]["base_ref"] = "release"

    features = {
        f"pull_request:{number}": ArtifactFeature(
            node_id=f"pull_request:{number}",
            kind="pull_request",
            number=number,
            row=row,
            tokens=[],
            title_tokens=set(),
            title_length=len(str(row["title"])),
            body_length=len(str(row["body"])),
            discussion_activity=0,
            review_activity=0,
            inbound_references=0,
            explicit_issue_links=1,
            explicit_issue_targets=[1],
            diff_size=20,
            filenames=["src/tokenizer.py"],
            diff_preview=None,
            file_ranges_by_name={},
            patch_tokens=[],
        )
        for number, row in pr_map.items()
    }

    candidates, pair_target_issues = _pr_duplicate_candidates(
        options=AnalysisOptions(
            snapshot_dir=None,
            output_dir=Path("."),
            output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        ),
        snapshot=None,
        issue_map=issue_map,
        pr_map=pr_map,
        features=features,
    )

    adjacency = defaultdict(set)
    for left, right in candidates:
        adjacency[left].add(right)
        adjacency[right].add(left)

    assert candidates
    assert all("pull_request:99" not in pair for pair in candidates)
    assert all(targets == {1} for targets in pair_target_issues.values())
    assert len(candidates) >= 19
    reachable = set()
    stack = ["pull_request:10"]
    while stack:
        current = stack.pop()
        if current in reachable:
            continue
        reachable.add(current)
        stack.extend(sorted(adjacency[current] - reachable))
    assert reachable == {f"pull_request:{number}" for number in range(10, 30)}


def test_reference_counts_ignore_suppressed_pr_links() -> None:
    inbound_references, explicit_issue_targets = _reference_counts(
        "huggingface/transformers",
        [
            {
                "repo": "huggingface/transformers",
                "source_type": "pull_request",
                "source_number": 10,
                "source_github_id": 10,
                "target_owner": "huggingface",
                "target_repo": "transformers",
                "target_number": 1,
                "link_type": "closing_reference",
                "link_origin": "text",
            }
        ],
        issue_map={
            1: _issue_row(
                1,
                "Tracking issue",
                "Body",
                state="open",
                comments_count=0,
                created_at="2026-03-01T00:00:00Z",
            )
        },
        pr_map={},
        comment_map={},
        review_map={},
        review_comment_map={},
    )

    assert inbound_references == {}
    assert explicit_issue_targets == {}


def test_analyze_writes_llm_review_sidecar_when_hybrid_review_runs(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=False)
    output_path = tmp_path / "report.json"

    async def fake_cluster_analysis(
        prepared: PreparedLlmPacket, model: str
    ) -> ClusterAnalysisCallResult:
        del model
        return ClusterAnalysisCallResult(
            analyst_result=ClusterAnalystResponse(
                summary="LLM summary",
                confidence=0.8,
                soft_edge_verdicts=[
                    SoftEdgeVerdict(
                        left=pair["left"],
                        right=pair["right"],
                        accept=True,
                        reason="same underlying change",
                    )
                    for pair in prepared.packet["soft_pairs"]
                ],
            ),
            evaluator_result=None,
            error_kind=None,
            error_message=None,
            evaluator_used=False,
            retried=False,
        )

    monkeypatch.setattr("slop_farmer.reports.analysis._can_use_fast_agent", lambda: True)
    monkeypatch.setattr(
        "slop_farmer.reports.analysis._fast_agent_cluster_analysis", fake_cluster_analysis
    )

    run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=output_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )

    review_sidecar = tmp_path / "report.llm-reviews.json"
    payload = json.loads(review_sidecar.read_text())
    assert payload["model"] == "gpt-5.4-mini?service_tier=flex"
    assert payload["reviews"]
    assert any(
        review["analyst_result"]["summary"] == "LLM summary" for review in payload["reviews"]
    )


def test_analyze_reuses_hybrid_review_cache_on_unchanged_rerun(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=False)

    class ClusterAnalysisSimulator:
        def __init__(self) -> None:
            self.calls = 0

        async def __call__(
            self, prepared: PreparedLlmPacket, model: str
        ) -> ClusterAnalysisCallResult:
            del model
            self.calls += 1
            return ClusterAnalysisCallResult(
                analyst_result=ClusterAnalystResponse(
                    summary="LLM summary",
                    confidence=0.8,
                    soft_edge_verdicts=[
                        SoftEdgeVerdict(
                            left=pair["left"],
                            right=pair["right"],
                            accept=True,
                            reason="same underlying change",
                        )
                        for pair in prepared.packet["soft_pairs"]
                    ],
                ),
                evaluator_result=None,
                error_kind=None,
                error_message=None,
                evaluator_used=False,
                retried=False,
            )

    simulator = ClusterAnalysisSimulator()
    monkeypatch.setattr("slop_farmer.reports.analysis._can_use_fast_agent", lambda: True)
    monkeypatch.setattr("slop_farmer.reports.analysis._fast_agent_cluster_analysis", simulator)

    first_output = tmp_path / "first.json"
    second_output = tmp_path / "second.json"

    run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=first_output,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )

    first_call_count = simulator.calls
    assert first_call_count > 0
    assert (snapshot_dir / "analysis-state" / "hybrid-review-cache-manifest.json").exists()

    monkeypatch.setattr("slop_farmer.reports.analysis._can_use_fast_agent", lambda: False)
    run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=second_output,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )

    payload = json.loads((tmp_path / "second.llm-reviews.json").read_text())
    report = json.loads(second_output.read_text())

    assert simulator.calls == first_call_count
    assert report["llm_enrichment"] is True
    assert payload["reviews"]
    assert all(
        review["cache_hit"] for review in payload["reviews"] if review["status"] == "reviewed"
    )
    assert all(
        review["source"] == "cache"
        for review in payload["reviews"]
        if review["status"] == "reviewed"
    )


def test_analyze_hybrid_review_cache_misses_when_model_changes(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=False)

    class ClusterAnalysisSimulator:
        def __init__(self) -> None:
            self.calls = 0

        async def __call__(
            self, prepared: PreparedLlmPacket, model: str
        ) -> ClusterAnalysisCallResult:
            del model
            self.calls += 1
            return ClusterAnalysisCallResult(
                analyst_result=ClusterAnalystResponse(
                    summary="LLM summary",
                    confidence=0.8,
                    soft_edge_verdicts=[
                        SoftEdgeVerdict(
                            left=pair["left"],
                            right=pair["right"],
                            accept=True,
                            reason="same underlying change",
                        )
                        for pair in prepared.packet["soft_pairs"]
                    ],
                ),
                evaluator_result=None,
                error_kind=None,
                error_message=None,
                evaluator_used=False,
                retried=False,
            )

    simulator = ClusterAnalysisSimulator()
    monkeypatch.setattr("slop_farmer.reports.analysis._can_use_fast_agent", lambda: True)
    monkeypatch.setattr("slop_farmer.reports.analysis._fast_agent_cluster_analysis", simulator)

    run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "model-a.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )
    first_call_count = simulator.calls

    run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "model-b.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini",
            max_clusters=10,
        )
    )

    assert simulator.calls > first_call_count


def test_analyze_cached_analysis_carries_forward_previous_analysis_state_and_logs_summary(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    output_dir = tmp_path / "analysis_data"
    previous_snapshot_dir = _write_snapshot(output_dir, include_events=False)

    class ClusterAnalysisSimulator:
        def __init__(self) -> None:
            self.calls = 0

        async def __call__(
            self, prepared: PreparedLlmPacket, model: str
        ) -> ClusterAnalysisCallResult:
            del model
            self.calls += 1
            return ClusterAnalysisCallResult(
                analyst_result=ClusterAnalystResponse(
                    summary="LLM summary",
                    confidence=0.8,
                    soft_edge_verdicts=[
                        SoftEdgeVerdict(
                            left=pair["left"],
                            right=pair["right"],
                            accept=True,
                            reason="same underlying change",
                        )
                        for pair in prepared.packet["soft_pairs"]
                    ],
                ),
                evaluator_result=None,
                error_kind=None,
                error_message=None,
                evaluator_used=False,
                retried=False,
            )

    simulator = ClusterAnalysisSimulator()
    monkeypatch.setattr("slop_farmer.reports.analysis._can_use_fast_agent", lambda: True)
    monkeypatch.setattr("slop_farmer.reports.analysis._fast_agent_cluster_analysis", simulator)

    run_analysis(
        AnalysisOptions(
            snapshot_dir=previous_snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "previous.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )
    assert simulator.calls > 0

    new_snapshot_dir = output_dir / "snapshots" / "20260321T000000Z"
    shutil.copytree(previous_snapshot_dir, new_snapshot_dir)
    shutil.rmtree(new_snapshot_dir / "analysis-state")
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260321T000000Z",
            "extracted_at": "2026-03-21T00:00:00Z",
            "watermark": {
                "previous_snapshot_dir": str(previous_snapshot_dir),
            },
        },
        new_snapshot_dir / "manifest.json",
    )

    monkeypatch.setattr("slop_farmer.reports.analysis._can_use_fast_agent", lambda: False)
    run_analysis(
        AnalysisOptions(
            snapshot_dir=new_snapshot_dir,
            output_dir=output_dir,
            output=tmp_path / "carried.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
            cached_analysis=True,
        )
    )

    payload = json.loads((tmp_path / "carried.llm-reviews.json").read_text())
    captured = capsys.readouterr().err

    assert (new_snapshot_dir / "analysis-state" / "hybrid-review-cache-manifest.json").exists()
    assert all(
        review["cache_hit"] for review in payload["reviews"] if review["status"] == "reviewed"
    )
    assert "copied analysis-state" in captured
    assert "Hybrid review cache summary:" in captured


def test_select_issue_anchor_for_pr_cluster_skips_ambiguous_targets() -> None:
    cluster = ClusterRecord(
        cluster_id="cluster-prs",
        nodes=["pull_request:10", "pull_request:11", "pull_request:12"],
        issue_numbers=[],
        pr_numbers=[10, 11, 12],
        evidence_types=["soft_similarity"],
        canonical_issue_number=None,
        canonical_pr_number=10,
        target_issue_number=None,
        summary="",
        status="open",
        confidence=0.5,
        canonical_issue_reason=None,
        canonical_pr_reason=None,
        best_issue_reason=None,
        best_pr_reason=None,
        cluster_score=1.0,
        best_issue_score=None,
        best_pr_score=1.0,
    )
    issue_map = {
        1: _issue_row(
            1,
            "Alpha tracking issue",
            "Alpha.",
            state="open",
            comments_count=0,
            created_at="2026-03-01T00:00:00Z",
        ),
        2: _issue_row(
            2,
            "Beta tracking issue",
            "Beta.",
            state="open",
            comments_count=0,
            created_at="2026-03-02T00:00:00Z",
        ),
    }
    issue_anchor_for_issue = {1: "issue-1", 2: "issue-2"}
    anchor_buckets = {
        "issue-1": {"issue_numbers": {1}},
        "issue-2": {"issue_numbers": {2}},
    }
    explicit_issue_link_targets = defaultdict(set, {10: {1}, 11: {2}})

    assert (
        _select_issue_anchor_for_pr_cluster(
            cluster=cluster,
            explicit_issue_link_targets=explicit_issue_link_targets,
            issue_map=issue_map,
            issue_anchor_for_issue=issue_anchor_for_issue,
            anchor_buckets=anchor_buckets,
        )
        is None
    )


def test_render_markdown_report_includes_headers_links_and_cluster_order(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=True)
    json_path = run_analysis(
        AnalysisOptions(
            snapshot_dir=snapshot_dir,
            output_dir=output_dir,
            output=snapshot_dir / "analysis-report.json",
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="deterministic",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
        )
    )

    markdown_path = render_markdown_report(
        MarkdownReportOptions(
            input=json_path,
            output=None,
            snapshot_dir=None,
        )
    )

    text = markdown_path.read_text()
    first_header = "## Cluster of 2 issues and 2 PRs centered on issue #1."
    second_header = "## Cluster of 1 issues and 2 PRs centered on issue #2."
    first_section = text.split(first_header, 1)[1].split(second_header, 1)[0]
    second_section = text.split(second_header, 1)[1]
    assert markdown_path == snapshot_dir / "analysis-report.md"
    assert first_header in text
    assert second_header in text
    assert text.index(first_header) < text.index(second_header)
    assert "[Issue #1: Fix tokenizer bug](https://example.com/issues/1)" in text
    assert "[PR #10: Fix tokenizer empty input crash](https://example.com/pulls/10)" in text
    assert "### Issues" in first_section
    assert (
        "[Issue #3: Tokenizer crash on empty input](https://example.com/issues/3)" in first_section
    )
    assert "### Issues" not in second_section
    assert "### PRs" in text
    assert "### PR comparison" in text
    assert "shared files: `src/tokenizer.py`" in text


def test_render_markdown_report_breaks_size_ties_by_latest_activity(tmp_path: Path) -> None:
    output_dir = tmp_path / "analysis_data"
    snapshot_dir = _write_snapshot(output_dir, include_events=False)
    report_path = snapshot_dir / "custom-analysis-report.json"
    write_json(
        {
            "schema_version": "1.0",
            "repo": "huggingface/transformers",
            "snapshot_id": "20260320T000000Z",
            "generated_at": "2026-03-20T00:00:00Z",
            "evidence_quality": "partial",
            "llm_enrichment": False,
            "meta_bugs": [
                {
                    "cluster_id": "cluster-old",
                    "summary": "Older cluster",
                    "status": "open",
                    "confidence": 0.8,
                    "canonical_issue_number": 1,
                    "canonical_pr_number": 10,
                    "issue_numbers": [1],
                    "pr_numbers": [10],
                    "evidence_types": ["closing_reference"],
                },
                {
                    "cluster_id": "cluster-new",
                    "summary": "Newer cluster",
                    "status": "open",
                    "confidence": 0.9,
                    "canonical_issue_number": 2,
                    "canonical_pr_number": 20,
                    "issue_numbers": [2],
                    "pr_numbers": [20],
                    "evidence_types": ["closing_reference"],
                },
            ],
            "duplicate_issues": [],
            "duplicate_prs": [],
            "best_issue": None,
            "best_pr": None,
        },
        report_path,
    )

    markdown_path = render_markdown_report(
        MarkdownReportOptions(
            input=report_path,
            output=tmp_path / "custom-analysis-report.md",
            snapshot_dir=snapshot_dir,
        )
    )

    text = markdown_path.read_text()
    assert text.index("## Newer cluster") < text.index("## Older cluster")


def test_materialize_hf_dataset_snapshot_maps_dataset_viewer_parquet(
    monkeypatch, tmp_path: Path
) -> None:
    remote_dir = tmp_path / "remote"
    remote_dir.mkdir()
    _write_remote_parquet_shard(remote_dir / "remote-issues.parquet", "issues")
    _write_remote_parquet_shard(remote_dir / "remote-prs.parquet", "pull_requests")
    _write_remote_parquet_shard(remote_dir / "remote-comments.parquet", "comments")
    _write_remote_parquet_shard(remote_dir / "remote-reviews.parquet", "reviews")
    _write_remote_parquet_shard(remote_dir / "remote-review-comments.parquet", "review_comments")
    _write_remote_parquet_shard(remote_dir / "remote-pr-files.parquet", "pr_files")
    _write_remote_parquet_shard(remote_dir / "remote-pr-diffs.parquet", "pr_diffs")
    _write_remote_parquet_shard(remote_dir / "remote-links.parquet", "links")
    _write_remote_parquet_shard(remote_dir / "remote-events.parquet", "events")
    (remote_dir / "README.md").write_text("# Dataset\n", encoding="utf-8")

    urls = [path.as_uri() for path in sorted(remote_dir.glob("*.parquet"))]
    seen_revisions: list[str | None] = []
    monkeypatch.setattr(
        "slop_farmer.data.snapshot_materialize._hf_dataset_parquet_urls",
        lambda repo_id, revision=None: seen_revisions.append(revision) or urls,
    )

    class StubInfo:
        sha = "hfsha123"
        siblings = ()

    class StubApi:
        def dataset_info(
            self,
            repo_id: str,
            revision: str | None = None,
            files_metadata: bool | None = None,
        ) -> StubInfo:
            return StubInfo()

    monkeypatch.setattr("slop_farmer.data.snapshot_materialize.HfApi", lambda: StubApi())
    monkeypatch.setattr(
        "slop_farmer.data.snapshot_materialize.hf_hub_download",
        lambda repo_id, repo_type, filename, revision=None: str(remote_dir / filename),
    )

    materialized = materialize_hf_dataset_snapshot(
        repo_id="burtenshaw/transformers-pr-slop-dataset",
        local_dir=tmp_path / "materialized",
        revision="main",
    )

    assert sorted(path.name for path in materialized.glob("*.parquet")) == [
        "comments.parquet",
        "events.parquet",
        "issues.parquet",
        "links.parquet",
        "pr_diffs.parquet",
        "pr_files.parquet",
        "pull_requests.parquet",
        "review_comments.parquet",
        "reviews.parquet",
    ]
    manifest = json.loads((materialized / "manifest.json").read_text())
    assert manifest["repo"] == "huggingface/transformers"
    assert manifest["hf_repo_id"] == "burtenshaw/transformers-pr-slop-dataset"
    assert manifest["hf_sha"] == "hfsha123"
    assert seen_revisions == ["hfsha123"]


def test_materialize_hf_dataset_snapshot_reads_root_layout_from_latest_pointer(
    monkeypatch, tmp_path: Path
) -> None:
    remote_dir = tmp_path / "remote-root"
    remote_dir.mkdir()
    for table_name in (
        "issues",
        "pull_requests",
        "comments",
        "reviews",
        "review_comments",
        "pr_files",
        "pr_diffs",
        "links",
        "events",
    ):
        _write_remote_parquet_shard(remote_dir / f"{table_name}.parquet", table_name)
    (remote_dir / "README.md").write_text("# Dataset\n", encoding="utf-8")
    (remote_dir / "manifest.json").write_text(
        json.dumps({"repo": "huggingface/transformers", "snapshot_id": "20260320T010203Z"}),
        encoding="utf-8",
    )
    (remote_dir / "snapshots").mkdir()
    (remote_dir / "snapshots" / "latest.json").write_text(
        json.dumps(
            {
                "repo": "huggingface/transformers",
                "latest_snapshot_id": "20260320T010203Z",
                "snapshot_dir": "snapshots/20260320T010203Z",
                "manifest_path": "manifest.json",
                "next_since": "2026-03-20T01:02:03Z",
            }
        ),
        encoding="utf-8",
    )
    (remote_dir / "new-contributors-report.json").write_text(
        json.dumps({"contributors": [{"author_login": "alice"}]}),
        encoding="utf-8",
    )
    (remote_dir / "new-contributors-report.md").write_text("# Contributors\n", encoding="utf-8")
    (remote_dir / "analysis-state" / "nested").mkdir(parents=True)
    (remote_dir / "analysis-state" / "hybrid-review-cache-manifest.json").write_text(
        json.dumps({"schema_version": 1, "entries": []}),
        encoding="utf-8",
    )
    (remote_dir / "analysis-state" / "nested" / "reviews.json").write_text(
        json.dumps({"reviews": []}),
        encoding="utf-8",
    )
    (remote_dir / "pr-scope-clusters.json").write_text(
        json.dumps({"cluster_count": 0, "pr_scope_clusters": []}),
        encoding="utf-8",
    )
    _write_remote_parquet_shard(remote_dir / "new_contributors.parquet", "new_contributors")
    current_analysis_dir = remote_dir / "analysis" / "current"
    current_analysis_dir.mkdir(parents=True)
    (current_analysis_dir / "manifest.json").write_text(
        json.dumps(
            {
                "schema_version": 1,
                "repo": "huggingface/transformers",
                "snapshot_id": "20260320T010203Z",
                "analysis_id": "hybrid-gpt54mini-v3",
                "variant": "hybrid",
                "channel": "canonical",
                "model": "gpt-5.4-mini",
                "published_at": "2026-03-20T01:05:00Z",
                "artifacts": {"hybrid": "analysis/current/analysis-report-hybrid.json"},
                "archived_artifacts": {
                    "hybrid": (
                        "snapshots/20260320T010203Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.json"
                    )
                },
            }
        ),
        encoding="utf-8",
    )
    (current_analysis_dir / "analysis-report-hybrid.json").write_text(
        json.dumps({"repo": "huggingface/transformers", "llm_enrichment": True}),
        encoding="utf-8",
    )
    archived_run_dir = (
        remote_dir / "snapshots" / "20260320T010203Z" / "analysis-runs" / "hybrid-gpt54mini-v3"
    )
    archived_run_dir.mkdir(parents=True)
    (archived_run_dir / "manifest.json").write_text(
        json.dumps(
            {
                "schema_version": 1,
                "repo": "huggingface/transformers",
                "snapshot_id": "20260320T010203Z",
                "analysis_id": "hybrid-gpt54mini-v3",
                "variant": "hybrid",
                "channel": "canonical",
                "model": "gpt-5.4-mini",
                "published_at": "2026-03-20T01:05:00Z",
                "artifacts": {
                    "hybrid": (
                        "snapshots/20260320T010203Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.json"
                    )
                },
            }
        ),
        encoding="utf-8",
    )
    (archived_run_dir / "analysis-report-hybrid.json").write_text(
        json.dumps({"repo": "huggingface/transformers", "llm_enrichment": True}),
        encoding="utf-8",
    )

    class StubSibling:
        def __init__(self, path: str) -> None:
            self.rfilename = path

    class StubInfo:
        sha = "stable123"

        def __init__(self) -> None:
            self.siblings = [
                StubSibling(str(path.relative_to(remote_dir)))
                for path in sorted(remote_dir.rglob("*"))
                if path.is_file()
            ]

    class StubApi:
        def dataset_info(
            self,
            repo_id: str,
            revision: str | None = None,
            files_metadata: bool | None = None,
        ) -> StubInfo:
            return StubInfo()

    monkeypatch.setattr("slop_farmer.data.snapshot_materialize.HfApi", lambda: StubApi())
    monkeypatch.setattr(
        "slop_farmer.data.snapshot_materialize.hf_hub_download",
        lambda repo_id, repo_type, filename, revision=None: str(remote_dir / filename),
    )

    materialized = materialize_hf_dataset_snapshot(
        repo_id="burtenshaw/transformers-pr-slop-dataset",
        local_dir=tmp_path / "materialized-root",
        revision="main",
    )

    assert (materialized / "issues.parquet").exists()
    assert (materialized / "new_contributors.parquet").exists()
    assert (materialized / "new-contributors-report.json").exists()
    assert (materialized / "pr-scope-clusters.json").exists()
    assert (materialized / "analysis-state" / "hybrid-review-cache-manifest.json").exists()
    assert (materialized / "analysis-state" / "nested" / "reviews.json").exists()
    assert (materialized / "analysis" / "current" / "manifest.json").exists()
    assert (materialized / "analysis" / "current" / "analysis-report-hybrid.json").exists()
    assert (
        materialized
        / "snapshots"
        / "20260320T010203Z"
        / "analysis-runs"
        / "hybrid-gpt54mini-v3"
        / "manifest.json"
    ).exists()
    manifest = json.loads((materialized / "manifest.json").read_text())
    assert manifest["source_type"] == "hf_snapshot_repo"
    assert manifest["snapshot_id"] == "20260320T010203Z"
    assert manifest["hf_sha"] == "stable123"


def test_materialize_hf_dataset_snapshot_reads_raw_root_layout(monkeypatch, tmp_path: Path) -> None:
    remote_dir = tmp_path / "remote-root-raw"
    remote_dir.mkdir()
    for table_name in (
        "issues",
        "pull_requests",
        "comments",
        "reviews",
        "review_comments",
        "pr_files",
        "pr_diffs",
        "links",
        "events",
    ):
        _write_remote_parquet_shard(remote_dir / f"{table_name}.parquet", table_name)
    (remote_dir / "README.md").write_text("# Dataset\n", encoding="utf-8")
    (remote_dir / "manifest.json").write_text(
        json.dumps({"repo": "huggingface/transformers", "snapshot_id": "20260320T010203Z"}),
        encoding="utf-8",
    )
    (remote_dir / "analysis-state").mkdir(parents=True)
    (remote_dir / "analysis-state" / "hybrid-review-cache-manifest.json").write_text(
        json.dumps({"schema_version": 1, "entries": []}),
        encoding="utf-8",
    )
    (remote_dir / "analysis" / "current").mkdir(parents=True)
    (remote_dir / "analysis" / "current" / "manifest.json").write_text(
        json.dumps(
            {
                "schema_version": 1,
                "repo": "huggingface/transformers",
                "snapshot_id": "20260320T010203Z",
                "analysis_id": "hybrid-gpt54mini-v3",
                "variant": "hybrid",
                "channel": "canonical",
                "model": "gpt-5.4-mini",
                "published_at": "2026-03-20T01:05:00Z",
                "artifacts": {"hybrid": "analysis/current/analysis-report-hybrid.json"},
                "archived_artifacts": {
                    "hybrid": (
                        "snapshots/20260320T010203Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.json"
                    )
                },
            }
        ),
        encoding="utf-8",
    )
    (remote_dir / "analysis" / "current" / "analysis-report-hybrid.json").write_text(
        json.dumps({"repo": "huggingface/transformers", "llm_enrichment": True}),
        encoding="utf-8",
    )
    archived_run_dir = (
        remote_dir / "snapshots" / "20260320T010203Z" / "analysis-runs" / "hybrid-gpt54mini-v3"
    )
    archived_run_dir.mkdir(parents=True)
    (archived_run_dir / "manifest.json").write_text(
        json.dumps(
            {
                "schema_version": 1,
                "repo": "huggingface/transformers",
                "snapshot_id": "20260320T010203Z",
                "analysis_id": "hybrid-gpt54mini-v3",
                "variant": "hybrid",
                "channel": "canonical",
                "model": "gpt-5.4-mini",
                "published_at": "2026-03-20T01:05:00Z",
                "artifacts": {
                    "hybrid": (
                        "snapshots/20260320T010203Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.json"
                    )
                },
            }
        ),
        encoding="utf-8",
    )
    (archived_run_dir / "analysis-report-hybrid.json").write_text(
        json.dumps({"repo": "huggingface/transformers", "llm_enrichment": True}),
        encoding="utf-8",
    )

    class StubSibling:
        def __init__(self, path: str) -> None:
            self.rfilename = path

    class StubInfo:
        sha = "raw123"

        def __init__(self) -> None:
            self.siblings = [
                StubSibling(str(path.relative_to(remote_dir)))
                for path in sorted(remote_dir.rglob("*"))
                if path.is_file()
            ]

    class StubApi:
        def dataset_info(
            self,
            repo_id: str,
            revision: str | None = None,
            files_metadata: bool | None = None,
        ) -> StubInfo:
            return StubInfo()

    monkeypatch.setattr("slop_farmer.data.snapshot_materialize.HfApi", lambda: StubApi())
    monkeypatch.setattr(
        "slop_farmer.data.snapshot_materialize.hf_hub_download",
        lambda repo_id, repo_type, filename, revision=None: str(remote_dir / filename),
    )
    monkeypatch.setattr(
        "slop_farmer.data.snapshot_materialize._hf_dataset_parquet_urls",
        lambda repo_id, revision=None: (_ for _ in ()).throw(
            AssertionError("viewer parquet export should not be used")
        ),
    )

    materialized = materialize_hf_dataset_snapshot(
        repo_id="evalstate/transformers-pr",
        local_dir=tmp_path / "materialized-root-raw",
        revision="main",
    )

    assert (materialized / "issues.parquet").exists()
    assert (materialized / "pull_requests.parquet").exists()
    assert (materialized / "analysis-state" / "hybrid-review-cache-manifest.json").exists()
    assert (materialized / "analysis" / "current" / "manifest.json").exists()
    assert (materialized / "analysis" / "current" / "analysis-report-hybrid.json").exists()
    assert (
        materialized
        / "snapshots"
        / "20260320T010203Z"
        / "analysis-runs"
        / "hybrid-gpt54mini-v3"
        / "analysis-report-hybrid.json"
    ).exists()
    manifest = json.loads((materialized / "manifest.json").read_text())
    assert manifest["source_type"] == "hf_root_snapshot"
    assert manifest["snapshot_id"] == "20260320T010203Z"
    assert manifest["hf_sha"] == "raw123"


def test_materialize_hf_dataset_snapshot_prunes_stale_root_analysis_reports(
    monkeypatch, tmp_path: Path
) -> None:
    remote_dir = tmp_path / "remote-root-stale"
    remote_dir.mkdir()
    for table_name in (
        "issues",
        "pull_requests",
        "comments",
        "reviews",
        "review_comments",
        "pr_files",
        "pr_diffs",
        "links",
        "events",
    ):
        _write_remote_parquet_shard(remote_dir / f"{table_name}.parquet", table_name)
    (remote_dir / "README.md").write_text("# Dataset\n", encoding="utf-8")
    (remote_dir / "manifest.json").write_text(
        json.dumps({"repo": "huggingface/transformers", "snapshot_id": "20260320T010203Z"}),
        encoding="utf-8",
    )
    (remote_dir / "snapshots").mkdir()
    (remote_dir / "snapshots" / "latest.json").write_text(
        json.dumps(
            {
                "repo": "huggingface/transformers",
                "latest_snapshot_id": "20260320T010203Z",
                "snapshot_dir": "snapshots/20260320T010203Z",
                "manifest_path": "manifest.json",
                "next_since": "2026-03-20T01:02:03Z",
            }
        ),
        encoding="utf-8",
    )

    class StubSibling:
        def __init__(self, path: str) -> None:
            self.rfilename = path

    class StubInfo:
        sha = "stable123"

        def __init__(self) -> None:
            self.siblings = [
                StubSibling(str(path.relative_to(remote_dir)))
                for path in sorted(remote_dir.rglob("*"))
                if path.is_file()
            ]

    class StubApi:
        def dataset_info(
            self,
            repo_id: str,
            revision: str | None = None,
            files_metadata: bool | None = None,
        ) -> StubInfo:
            return StubInfo()

    monkeypatch.setattr("slop_farmer.data.snapshot_materialize.HfApi", lambda: StubApi())
    monkeypatch.setattr(
        "slop_farmer.data.snapshot_materialize.hf_hub_download",
        lambda repo_id, repo_type, filename, revision=None: str(remote_dir / filename),
    )

    materialized_dir = tmp_path / "materialized-stale"
    materialized_dir.mkdir()
    (materialized_dir / "analysis-report.json").write_text(
        json.dumps(
            {
                "repo": "huggingface/transformers",
                "snapshot_id": "20260319T000000Z",
                "llm_enrichment": True,
            }
        ),
        encoding="utf-8",
    )
    (materialized_dir / "analysis-report.llm-reviews.json").write_text(
        json.dumps({"reviews": []}),
        encoding="utf-8",
    )

    materialize_hf_dataset_snapshot(
        repo_id="evalstate/transformers-pr",
        local_dir=materialized_dir,
        revision="main",
    )

    assert not (materialized_dir / "analysis-report.json").exists()
    assert not (materialized_dir / "analysis-report.llm-reviews.json").exists()


def test_hf_dataset_parquet_urls_include_requested_revision(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    seen: dict[str, str] = {}

    class StubResponse:
        def __enter__(self) -> "StubResponse":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            del exc_type, exc, tb

        def read(self) -> bytes:
            return json.dumps(
                {"default": {"train": ["https://example.com/export/issues.parquet"]}}
            ).encode("utf-8")

    def stub_urlopen(url: str, *, timeout: int, label: str) -> StubResponse:
        seen["url"] = url
        seen["label"] = label
        assert timeout == 120
        return StubResponse()

    monkeypatch.setattr("slop_farmer.data.snapshot_materialize.urlopen_with_retry", stub_urlopen)

    urls = _hf_dataset_parquet_urls("evalstate/transformers-pr", revision="refs/pr/123")

    assert urls == ["https://example.com/export/issues.parquet"]
    assert seen["label"] == seen["url"]
    assert "revision=refs%2Fpr%2F123" in seen["url"]


def test_parquet_table_name_recognizes_each_schema(tmp_path: Path) -> None:
    for table_name in (
        "issues",
        "pull_requests",
        "comments",
        "reviews",
        "review_comments",
        "pr_files",
        "pr_diffs",
        "links",
        "events",
    ):
        path = tmp_path / f"{table_name}.parquet"
        _write_remote_parquet_shard(path, table_name)
        assert _parquet_table_name(path) == f"{table_name}.parquet"


def test_hf_latest_snapshot_candidates_cover_root_and_nested_layouts() -> None:
    assert _hf_latest_snapshot_candidates({"manifest_path": "manifest.json"}, "issues.parquet") == [
        "issues.parquet"
    ]
    assert _hf_latest_snapshot_candidates(
        {
            "snapshot_dir": "snapshots/20260320T010203Z",
            "manifest_path": "snapshots/20260320T010203Z/manifest.json",
        },
        "issues.parquet",
    ) == [
        "snapshots/20260320T010203Z/issues.parquet",
        "issues.parquet",
    ]


def test_accepted_soft_pairs_respects_shared_concurrency_and_allows_issue_pr_overlap(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    inflight = 0
    max_inflight = 0
    active_labels: defaultdict[str, int] = defaultdict(int)
    overlapped = False
    lock = asyncio.Lock()

    async def fake_cluster_analysis(
        prepared: PreparedLlmPacket, model: str
    ) -> ClusterAnalysisCallResult:
        del model
        nonlocal inflight, max_inflight, overlapped
        label = "issue" if prepared.packet["nodes"][0].startswith("issue:") else "pull_request"
        async with lock:
            inflight += 1
            max_inflight = max(max_inflight, inflight)
            active_labels[label] += 1
            overlapped = overlapped or len(active_labels) > 1
        await asyncio.sleep(0.02)
        async with lock:
            inflight -= 1
            active_labels[label] -= 1
            if active_labels[label] <= 0:
                active_labels.pop(label, None)
        return _accept_all_cluster_result(prepared)

    monkeypatch.setattr(
        "slop_farmer.reports.analysis._fast_agent_cluster_analysis",
        fake_cluster_analysis,
    )

    issue_result, pr_result = asyncio.run(
        _run_shared_review_passes(
            tmp_path=tmp_path,
            issue_pairs=[(1, 2), (3, 4), (5, 6)],
            pr_pairs=[(10, 11), (20, 21), (30, 31)],
            concurrency=2,
        )
    )

    assert max_inflight <= 2
    assert max_inflight == 2
    assert overlapped is True
    assert len(issue_result[0]) == 3
    assert len(pr_result[0]) == 3


def test_accepted_soft_pairs_preserves_review_record_order_on_out_of_order_completion(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    delays = {
        ("issue:1", "issue:2"): 0.03,
        ("issue:3", "issue:4"): 0.02,
        ("issue:5", "issue:6"): 0.01,
    }

    async def fake_cluster_analysis(
        prepared: PreparedLlmPacket, model: str
    ) -> ClusterAnalysisCallResult:
        del model
        await asyncio.sleep(delays[tuple(prepared.packet["nodes"])])
        return _accept_all_cluster_result(prepared)

    monkeypatch.setattr(
        "slop_farmer.reports.analysis._fast_agent_cluster_analysis",
        fake_cluster_analysis,
    )

    accepted, llm_used, review_records = asyncio.run(
        _run_single_review_pass(
            tmp_path=tmp_path,
            pairs=[(1, 2), (3, 4), (5, 6)],
            label="issue",
            concurrency=3,
        )
    )

    assert llm_used is True
    assert len(accepted) == 3
    assert [record["component_index"] for record in review_records] == [1, 2, 3]
    assert all(record["review_unit_index"] == 1 for record in review_records)
    assert [record["nodes"] for record in review_records] == [
        ["issue:1", "issue:2"],
        ["issue:3", "issue:4"],
        ["issue:5", "issue:6"],
    ]


def test_accepted_soft_pairs_cache_hits_bypass_llm_work_for_mixed_runs(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = 0

    async def fake_cluster_analysis(
        prepared: PreparedLlmPacket, model: str
    ) -> ClusterAnalysisCallResult:
        del model
        nonlocal calls
        calls += 1
        return _accept_all_cluster_result(prepared)

    monkeypatch.setattr(
        "slop_farmer.reports.analysis._fast_agent_cluster_analysis",
        fake_cluster_analysis,
    )

    asyncio.run(
        _run_single_review_pass(
            tmp_path=tmp_path,
            pairs=[(1, 2), (3, 4)],
            label="issue",
            concurrency=2,
        )
    )
    first_calls = calls

    accepted, llm_used, review_records = asyncio.run(
        _run_single_review_pass(
            tmp_path=tmp_path,
            pairs=[(1, 2), (3, 4), (5, 6)],
            label="issue",
            concurrency=2,
        )
    )

    assert first_calls == 2
    assert calls == first_calls + 1
    assert llm_used is True
    assert len(accepted) == 3
    assert [record["source"] for record in review_records] == ["cache", "cache", "llm"]


def test_accepted_soft_pairs_with_concurrency_one_matches_parallel_results(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    inflight = 0
    max_inflight = 0

    async def fake_cluster_analysis(
        prepared: PreparedLlmPacket, model: str
    ) -> ClusterAnalysisCallResult:
        del model
        nonlocal inflight, max_inflight
        inflight += 1
        max_inflight = max(max_inflight, inflight)
        await asyncio.sleep(0.01)
        inflight -= 1
        return _accept_all_cluster_result(prepared)

    monkeypatch.setattr(
        "slop_farmer.reports.analysis._fast_agent_cluster_analysis",
        fake_cluster_analysis,
    )

    sequential = asyncio.run(
        _run_single_review_pass(
            tmp_path=tmp_path / "sequential",
            pairs=[(1, 2), (3, 4), (5, 6)],
            label="issue",
            concurrency=1,
        )
    )
    sequential_calls = max_inflight

    inflight = 0
    max_inflight = 0
    parallel = asyncio.run(
        _run_single_review_pass(
            tmp_path=tmp_path / "parallel",
            pairs=[(1, 2), (3, 4), (5, 6)],
            label="issue",
            concurrency=3,
        )
    )

    assert sequential_calls == 1
    assert sequential[0] == parallel[0]
    assert sequential[1] is True
    assert parallel[1] is True
    assert [record["soft_pairs"] for record in sequential[2]] == [
        record["soft_pairs"] for record in parallel[2]
    ]


def _minimal_snapshot(tmp_path: Path) -> SnapshotData:
    return SnapshotData(
        repo="huggingface/transformers",
        snapshot_id="20260320T000000Z",
        snapshot_dir=tmp_path,
        manifest={},
        issues=[],
        pull_requests=[],
        comments=[],
        reviews=[],
        review_comments=[],
        pr_files=[],
        pr_diffs=[],
        links=[],
        events=[],
        evidence_quality="partial",
    )


def _minimal_analysis_options(tmp_path: Path, *, concurrency: int) -> AnalysisOptions:
    return AnalysisOptions(
        snapshot_dir=tmp_path,
        output_dir=tmp_path,
        output=None,
        hf_repo_id=None,
        hf_revision=None,
        hf_materialize_dir=None,
        ranking_backend="hybrid",
        model="gpt-5.4-mini?service_tier=flex",
        max_clusters=10,
        hybrid_llm_concurrency=concurrency,
    )


def _minimal_feature(node_id: str) -> ArtifactFeature:
    kind, raw_number = node_id.split(":", 1)
    number = int(raw_number)
    return ArtifactFeature(
        node_id=node_id,
        kind=kind,
        number=number,
        row={"number": number, "title": node_id, "state": "open"},
        tokens=["shared", raw_number],
        title_tokens={"shared", raw_number},
        title_length=2,
        body_length=10,
        discussion_activity=0,
        review_activity=0,
        inbound_references=0,
        explicit_issue_links=0,
        explicit_issue_targets=[],
        diff_size=0,
        filenames=[],
        diff_preview=None,
        file_ranges_by_name={},
        patch_tokens=[],
    )


def _soft_pair_candidates(
    *,
    label: str,
    pairs: list[tuple[int, int]],
) -> tuple[dict[str, ArtifactFeature], dict[tuple[str, str], dict[str, object]]]:
    kind = "issue" if label == "issue" else "pull_request"
    features: dict[str, ArtifactFeature] = {}
    soft_candidates: dict[tuple[str, str], dict[str, object]] = {}
    for left_number, right_number in pairs:
        left = f"{kind}:{left_number}"
        right = f"{kind}:{right_number}"
        features[left] = _minimal_feature(left)
        features[right] = _minimal_feature(right)
        soft_candidates[(left, right)] = {
            "left": left,
            "right": right,
            "kind": kind,
            "score": 1.0,
            "jaccard": 0.5,
            "evidence_types": {"soft_similarity"},
            "shared_targets": [],
            "shared_filenames": [],
            "deterministic_accept": False,
        }
    return features, soft_candidates


def _accept_all_cluster_result(prepared: PreparedLlmPacket) -> ClusterAnalysisCallResult:
    return ClusterAnalysisCallResult(
        analyst_result=ClusterAnalystResponse(
            summary="LLM summary",
            confidence=0.8,
            soft_edge_verdicts=[
                SoftEdgeVerdict(
                    left=pair["left"],
                    right=pair["right"],
                    accept=True,
                    reason="same underlying change",
                )
                for pair in prepared.packet["soft_pairs"]
            ],
        ),
        evaluator_result=None,
        error_kind=None,
        error_message=None,
        evaluator_used=False,
        retried=False,
    )


async def _run_single_review_pass(
    *,
    tmp_path: Path,
    pairs: list[tuple[int, int]],
    label: str,
    concurrency: int,
) -> tuple[dict[tuple[str, str], dict[str, object]], bool, list[dict[str, object]]]:
    features, soft_candidates = _soft_pair_candidates(label=label, pairs=pairs)
    cache = HybridReviewCacheStore(
        tmp_path / "analysis-state",
        _hybrid_review_cache_manifest(),
        enabled=True,
    )
    return await _accepted_soft_pairs(
        options=_minimal_analysis_options(tmp_path, concurrency=concurrency),
        snapshot=_minimal_snapshot(tmp_path),
        features=features,
        hard_pairs={},
        soft_candidates=soft_candidates,
        label=label,
        hybrid_review_cache=cache,
        llm_available=True,
        review_semaphore=asyncio.Semaphore(concurrency),
    )


async def _run_shared_review_passes(
    *,
    tmp_path: Path,
    issue_pairs: list[tuple[int, int]],
    pr_pairs: list[tuple[int, int]],
    concurrency: int,
) -> tuple[
    tuple[dict[tuple[str, str], dict[str, object]], bool, list[dict[str, object]]],
    tuple[dict[tuple[str, str], dict[str, object]], bool, list[dict[str, object]]],
]:
    semaphore = asyncio.Semaphore(concurrency)
    issue_features, issue_candidates = _soft_pair_candidates(label="issue", pairs=issue_pairs)
    pr_features, pr_candidates = _soft_pair_candidates(label="pull_request", pairs=pr_pairs)
    issue_cache = HybridReviewCacheStore(
        tmp_path / "issue-analysis-state",
        _hybrid_review_cache_manifest(),
        enabled=True,
    )
    pr_cache = HybridReviewCacheStore(
        tmp_path / "pr-analysis-state",
        _hybrid_review_cache_manifest(),
        enabled=True,
    )
    options = _minimal_analysis_options(tmp_path, concurrency=concurrency)
    snapshot = _minimal_snapshot(tmp_path)
    return await asyncio.gather(
        _accepted_soft_pairs(
            options=options,
            snapshot=snapshot,
            features=issue_features,
            hard_pairs={},
            soft_candidates=issue_candidates,
            label="issue",
            hybrid_review_cache=issue_cache,
            llm_available=True,
            review_semaphore=semaphore,
        ),
        _accepted_soft_pairs(
            options=options,
            snapshot=snapshot,
            features=pr_features,
            hard_pairs={},
            soft_candidates=pr_candidates,
            label="pull_request",
            hybrid_review_cache=pr_cache,
            llm_available=True,
            review_semaphore=semaphore,
        ),
    )


def _write_snapshot(output_dir: Path, *, include_events: bool) -> Path:
    snapshot_dir = output_dir / "snapshots" / "20260320T000000Z"
    issues = [
        _issue_row(
            1,
            "Fix tokenizer bug",
            "Tokenizer crashes on empty input.",
            state="open",
            comments_count=2,
            created_at="2026-03-01T00:00:00Z",
        ),
        _issue_row(
            2,
            "Fix generation docs",
            "Generation docs typo in examples.",
            state="open",
            comments_count=1,
            created_at="2026-03-10T00:00:00Z",
        ),
        _issue_row(
            3,
            "Tokenizer crash on empty input",
            "Tokenizer throws on empty input.",
            state="open",
            comments_count=1,
            created_at="2026-03-05T00:00:00Z",
        ),
    ]
    pull_requests = [
        _pr_row(
            10,
            "Fix tokenizer empty input crash",
            "Fixes #1",
            state="closed",
            merged=True,
            draft=False,
            created_at="2026-03-06T00:00:00Z",
            closed_at="2026-03-07T00:00:00Z",
            merged_at="2026-03-07T00:00:00Z",
            additions=8,
            deletions=1,
            changed_files=1,
        ),
        _pr_row(
            11,
            "Fix tokenizer crash on empty input",
            "Fixes #1",
            state="closed",
            merged=False,
            draft=False,
            created_at="2026-03-07T00:00:00Z",
            closed_at="2026-03-08T00:00:00Z",
            merged_at=None,
            additions=30,
            deletions=5,
            changed_files=3,
        ),
        _pr_row(
            20,
            "Fix generation docs typo",
            "Fixes #2",
            state="open",
            merged=False,
            draft=False,
            created_at="2026-03-11T00:00:00Z",
            closed_at=None,
            merged_at=None,
            additions=2,
            deletions=1,
            changed_files=1,
        ),
        _pr_row(
            21,
            "Fix docs typo in generation examples",
            "Fixes #2",
            state="closed",
            merged=False,
            draft=False,
            created_at="2026-03-12T00:00:00Z",
            closed_at="2026-03-13T00:00:00Z",
            merged_at=None,
            additions=6,
            deletions=3,
            changed_files=2,
        ),
    ]
    comments = [
        _comment_row(100, "issue", 3, "Duplicate of #1", created_at="2026-03-05T01:00:00Z"),
        _comment_row(
            101, "pull_request", 20, "This follows issue #2.", created_at="2026-03-11T01:00:00Z"
        ),
    ]
    reviews = []
    review_comments = []
    pr_files = [
        _pr_file_row(10, "src/tokenizer.py", "@@ -10,2 +10,2 @@\n-old\n+new\n"),
        _pr_file_row(11, "src/tokenizer.py", "@@ -11,2 +11,2 @@\n-older\n+newer\n"),
        _pr_file_row(20, "docs/generation.md", "@@ -20,2 +20,2 @@\n-old\n+new\n"),
        _pr_file_row(21, "docs/generation.md", "@@ -21,2 +21,2 @@\n-older\n+newer\n"),
    ]
    pr_diffs = []
    links = []
    events = [
        _event_row("pull_request", 10, 1, "cross-referenced", "2026-03-06T01:00:00Z"),
    ]

    write_parquet(issues, snapshot_dir / "issues.parquet", "issues")
    write_parquet(pull_requests, snapshot_dir / "pull_requests.parquet", "pull_requests")
    write_parquet(comments, snapshot_dir / "comments.parquet", "comments")
    write_parquet(reviews, snapshot_dir / "reviews.parquet", "reviews")
    write_parquet(review_comments, snapshot_dir / "review_comments.parquet", "review_comments")
    write_parquet(pr_files, snapshot_dir / "pr_files.parquet", "pr_files")
    write_parquet(pr_diffs, snapshot_dir / "pr_diffs.parquet", "pr_diffs")
    write_parquet(links, snapshot_dir / "links.parquet", "links")
    if include_events:
        write_parquet(events, snapshot_dir / "events.parquet", "events")
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260320T000000Z",
            "extracted_at": "2026-03-20T00:00:00Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_json(
        {
            "latest_snapshot_id": "20260320T000000Z",
            "snapshot_dir": str(snapshot_dir),
        },
        output_dir / "snapshots" / "latest.json",
    )
    return snapshot_dir


def _write_custom_snapshot(
    output_dir: Path,
    *,
    issues: list[dict],
    pull_requests: list[dict],
    comments: list[dict] | None = None,
    reviews: list[dict] | None = None,
    review_comments: list[dict] | None = None,
    pr_files: list[dict] | None = None,
    pr_diffs: list[dict] | None = None,
    links: list[dict] | None = None,
    events: list[dict] | None = None,
) -> Path:
    snapshot_dir = output_dir / "snapshots" / "20260320T000000Z"
    write_parquet(issues, snapshot_dir / "issues.parquet", "issues")
    write_parquet(pull_requests, snapshot_dir / "pull_requests.parquet", "pull_requests")
    write_parquet(comments or [], snapshot_dir / "comments.parquet", "comments")
    write_parquet(reviews or [], snapshot_dir / "reviews.parquet", "reviews")
    write_parquet(
        review_comments or [], snapshot_dir / "review_comments.parquet", "review_comments"
    )
    write_parquet(pr_files or [], snapshot_dir / "pr_files.parquet", "pr_files")
    write_parquet(pr_diffs or [], snapshot_dir / "pr_diffs.parquet", "pr_diffs")
    write_parquet(links or [], snapshot_dir / "links.parquet", "links")
    write_parquet(events or [], snapshot_dir / "events.parquet", "events")
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260320T000000Z",
            "extracted_at": "2026-03-20T00:00:00Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_json(
        {
            "latest_snapshot_id": "20260320T000000Z",
            "snapshot_dir": str(snapshot_dir),
        },
        output_dir / "snapshots" / "latest.json",
    )
    return snapshot_dir


def _write_remote_parquet_shard(path: Path, table_name: str) -> None:
    if table_name == "issues":
        rows = [
            _issue_row(
                1,
                "Issue",
                "Body",
                state="open",
                comments_count=1,
                created_at="2026-03-01T00:00:00Z",
            )
        ]
    elif table_name == "pull_requests":
        rows = [
            _pr_row(
                10,
                "PR",
                "Fixes #1",
                state="open",
                merged=False,
                draft=False,
                created_at="2026-03-02T00:00:00Z",
                closed_at=None,
                merged_at=None,
                additions=1,
                deletions=1,
                changed_files=1,
            )
        ]
    elif table_name == "comments":
        rows = [_comment_row(100, "issue", 1, "Comment", "2026-03-01T01:00:00Z")]
    elif table_name == "reviews":
        rows = [
            {
                "repo": "huggingface/transformers",
                "github_id": 200,
                "github_node_id": "R_200",
                "pull_request_number": 10,
                "html_url": "https://example.com/reviews/200",
                "api_url": "https://api.example.com/reviews/200",
                "body": "Looks good",
                "state": "APPROVED",
                "submitted_at": "2026-03-02T01:00:00Z",
                "commit_id": "abc",
                "author_association": "CONTRIBUTOR",
                "snapshot_id": "snap",
                "extracted_at": "2026-03-20T00:00:00Z",
                "author_login": "reviewer",
                "author_id": 200,
                "author_node_id": "U_200",
                "author_type": "User",
                "author_site_admin": False,
            }
        ]
    elif table_name == "review_comments":
        rows = [
            {
                "repo": "huggingface/transformers",
                "github_id": 300,
                "github_node_id": "RC_300",
                "pull_request_number": 10,
                "review_id": 200,
                "html_url": "https://example.com/review-comments/300",
                "api_url": "https://api.example.com/review-comments/300",
                "pull_request_api_url": "https://api.example.com/pulls/10",
                "body": "nit",
                "path": "file.py",
                "commit_id": "abc",
                "original_commit_id": "abc",
                "position": 1,
                "original_position": 1,
                "line": 1,
                "start_line": None,
                "side": "RIGHT",
                "start_side": None,
                "subject_type": "line",
                "created_at": "2026-03-02T01:10:00Z",
                "updated_at": "2026-03-02T01:10:00Z",
                "author_association": "CONTRIBUTOR",
                "snapshot_id": "snap",
                "extracted_at": "2026-03-20T00:00:00Z",
                "author_login": "reviewer",
                "author_id": 300,
                "author_node_id": "U_300",
                "author_type": "User",
                "author_site_admin": False,
            }
        ]
    elif table_name == "pr_files":
        rows = [
            {
                "repo": "huggingface/transformers",
                "pull_request_number": 10,
                "sha": "deadbeef",
                "filename": "src/example.py",
                "status": "modified",
                "additions": 5,
                "deletions": 1,
                "changes": 6,
                "blob_url": "https://example.com/blob/src/example.py",
                "raw_url": "https://example.com/raw/src/example.py",
                "contents_url": "https://api.example.com/contents/src/example.py",
                "previous_filename": None,
                "patch": "@@ -1 +1 @@\n-old\n+new\n",
                "snapshot_id": "snap",
                "extracted_at": "2026-03-20T00:00:00Z",
            }
        ]
    elif table_name == "pr_diffs":
        rows = [
            {
                "repo": "huggingface/transformers",
                "pull_request_number": 10,
                "html_url": "https://example.com/pulls/10",
                "api_url": "https://api.example.com/pulls/10",
                "diff": "diff --git a/src/example.py b/src/example.py\nindex 111..222 100644\n--- a/src/example.py\n+++ b/src/example.py\n@@ -1 +1 @@\n-old\n+new\n",
                "snapshot_id": "snap",
                "extracted_at": "2026-03-20T00:00:00Z",
            }
        ]
    elif table_name == "links":
        rows = [
            {
                "repo": "huggingface/transformers",
                "source_type": "pull_request",
                "source_number": 10,
                "source_github_id": 10,
                "target_owner": "huggingface",
                "target_repo": "transformers",
                "target_number": 1,
                "link_type": "closing_reference",
                "link_origin": "text",
                "snapshot_id": "snap",
                "extracted_at": "2026-03-20T00:00:00Z",
            }
        ]
    elif table_name == "events":
        rows = [_event_row("pull_request", 10, 1, "cross-referenced", "2026-03-02T01:20:00Z")]
    elif table_name == "new_contributors":
        rows = [
            {
                "repo": "huggingface/transformers",
                "snapshot_id": "20260320T010203Z",
                "report_generated_at": "2026-03-20T01:30:00Z",
                "window_days": 42,
                "author_login": "alice",
                "name": "Alice",
                "profile_url": "https://github.com/alice",
                "repo_pull_requests_url": "https://github.com/huggingface/transformers/pulls?q=author%3Aalice",
                "repo_issues_url": "https://github.com/huggingface/transformers/issues?q=author%3Aalice",
                "repo_first_seen_at": "2026-03-20T00:00:00Z",
                "repo_last_seen_at": "2026-03-20T00:00:00Z",
                "repo_primary_artifact_count": 1,
                "repo_artifact_count": 1,
                "snapshot_issue_count": 0,
                "snapshot_pr_count": 1,
                "snapshot_comment_count": 0,
                "snapshot_review_count": 0,
                "snapshot_review_comment_count": 0,
                "repo_association": "CONTRIBUTOR",
                "new_to_repo": True,
                "first_seen_in_snapshot": True,
                "report_reason": "first_seen_in_snapshot",
                "account_age_days": 90,
                "young_account": True,
                "follow_through_score": "mixed",
                "breadth_score": "low",
                "automation_risk_signal": "low",
                "heuristic_note": "young account",
                "public_orgs": [],
                "visible_authored_pr_count": 6,
                "merged_pr_count": 3,
                "closed_unmerged_pr_count": 1,
                "open_pr_count": 2,
                "merged_pr_rate": 0.5,
                "closed_unmerged_pr_rate": 0.1667,
                "still_open_pr_rate": 0.3333,
                "distinct_repos_with_authored_prs": 3,
                "distinct_repos_with_open_prs": 1,
                "fetch_error": None,
            }
        ]
    else:
        raise AssertionError(table_name)
    write_parquet(rows, path, table_name)


def _issue_row(
    number: int,
    title: str,
    body: str,
    *,
    state: str,
    comments_count: int,
    created_at: str,
) -> dict:
    return {
        "repo": "huggingface/transformers",
        "github_id": number,
        "github_node_id": f"I_{number}",
        "number": number,
        "html_url": f"https://example.com/issues/{number}",
        "api_url": f"https://api.example.com/issues/{number}",
        "title": title,
        "body": body,
        "state": state,
        "state_reason": None,
        "locked": False,
        "comments_count": comments_count,
        "labels": [],
        "assignees": [],
        "created_at": created_at,
        "updated_at": created_at,
        "closed_at": None,
        "milestone_title": None,
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
        "author_login": f"user{number}",
        "author_id": number,
        "author_node_id": f"U_{number}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _pr_row(
    number: int,
    title: str,
    body: str,
    *,
    state: str,
    merged: bool,
    draft: bool,
    created_at: str,
    closed_at: str | None,
    merged_at: str | None,
    additions: int,
    deletions: int,
    changed_files: int,
) -> dict:
    return {
        "repo": "huggingface/transformers",
        "github_id": number,
        "github_node_id": f"PR_{number}",
        "number": number,
        "html_url": f"https://example.com/pulls/{number}",
        "api_url": f"https://api.example.com/pulls/{number}",
        "title": title,
        "body": body,
        "state": state,
        "state_reason": None,
        "locked": False,
        "comments_count": 1,
        "labels": [],
        "assignees": [],
        "created_at": created_at,
        "updated_at": created_at,
        "closed_at": closed_at,
        "merged_at": merged_at,
        "merge_commit_sha": None,
        "merged": merged,
        "mergeable": True,
        "mergeable_state": "clean",
        "draft": draft,
        "additions": additions,
        "deletions": deletions,
        "changed_files": changed_files,
        "commits": 1,
        "review_comments_count": 0,
        "maintainer_can_modify": True,
        "head_ref": f"branch-{number}",
        "head_sha": f"head-{number}",
        "head_repo_full_name": "fork/repo",
        "base_ref": "main",
        "base_sha": f"base-{number}",
        "base_repo_full_name": "huggingface/transformers",
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
        "author_login": f"user{number}",
        "author_id": number,
        "author_node_id": f"U_{number}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _pr_file_row(pr_number: int, filename: str, patch: str) -> dict:
    return {
        "repo": "huggingface/transformers",
        "pull_request_number": pr_number,
        "sha": f"sha-{pr_number}",
        "filename": filename,
        "status": "modified",
        "additions": 1,
        "deletions": 1,
        "changes": 2,
        "blob_url": f"https://example.com/blob/{filename}",
        "raw_url": f"https://example.com/raw/{filename}",
        "contents_url": f"https://api.example.com/contents/{filename}",
        "previous_filename": None,
        "patch": patch,
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
    }


def _comment_row(
    github_id: int, parent_kind: str, parent_number: int, body: str, created_at: str
) -> dict:
    return {
        "repo": "huggingface/transformers",
        "github_id": github_id,
        "github_node_id": f"C_{github_id}",
        "parent_kind": parent_kind,
        "parent_number": parent_number,
        "html_url": f"https://example.com/comments/{github_id}",
        "api_url": f"https://api.example.com/comments/{github_id}",
        "issue_api_url": f"https://api.example.com/issues/{parent_number}",
        "body": body,
        "created_at": created_at,
        "updated_at": created_at,
        "author_association": "CONTRIBUTOR",
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
        "author_login": f"user{github_id}",
        "author_id": github_id,
        "author_node_id": f"U_{github_id}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _event_row(
    parent_kind: str, parent_number: int, source_issue_number: int, event: str, created_at: str
) -> dict:
    return {
        "repo": "huggingface/transformers",
        "parent_kind": parent_kind,
        "parent_number": parent_number,
        "event": event,
        "created_at": created_at,
        "actor_login": "maintainer",
        "source_issue_number": source_issue_number,
        "source_issue_title": f"Issue {source_issue_number}",
        "source_issue_url": f"https://example.com/issues/{source_issue_number}",
        "commit_id": None,
        "label_name": None,
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
    }
