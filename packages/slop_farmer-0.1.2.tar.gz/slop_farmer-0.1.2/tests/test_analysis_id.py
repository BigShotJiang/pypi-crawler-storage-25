from __future__ import annotations

from pathlib import Path

from slop_farmer.app.analysis_id import (
    analysis_id_from_config,
    analysis_id_from_snapshot,
    build_analysis_id,
    model_slug,
)
from slop_farmer.data.parquet_io import write_json


def test_model_slug_discards_query_and_punctuation() -> None:
    assert model_slug("gpt-5.4-mini?service_tier=flex") == "gpt54mini"


def test_build_analysis_id_uses_short_format() -> None:
    assert (
        build_analysis_id(
            snapshot_id="20260419T072034Z",
            model="gpt-5.4-mini?service_tier=flex",
            ranking_backend="hybrid",
        )
        == "hybrid-gpt54mini-20260419t072034z"
    )


def test_analysis_id_from_snapshot_reads_manifest_snapshot_id(tmp_path: Path) -> None:
    snapshot_dir = tmp_path / "snapshots" / "20260419T072034Z"
    snapshot_dir.mkdir(parents=True)
    write_json({"snapshot_id": "20260419T072034Z"}, snapshot_dir / "manifest.json")

    assert (
        analysis_id_from_snapshot(
            snapshot_dir=snapshot_dir,
            model="gpt-5.4-mini?service_tier=flex",
            ranking_backend="hybrid",
        )
        == "hybrid-gpt54mini-20260419t072034z"
    )


def test_analysis_id_from_config_uses_latest_snapshot_pointer(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\nversion='0.0.0'\n")
    config_path = tmp_path / "configs" / "openclaw.yaml"
    config_path.parent.mkdir()
    config_path.write_text(
        """
repo: openclaw/openclaw
workspace: runs/openclaw
dataset_id: evalstate/openclaw-pr
analysis:
  ranking_backend: hybrid
  model: gpt-5.4-mini?service_tier=flex
""".strip()
        + "\n",
        encoding="utf-8",
    )
    latest_json = tmp_path / "runs" / "openclaw" / "data" / "snapshots" / "latest.json"
    latest_json.parent.mkdir(parents=True)
    snapshot_dir = tmp_path / "runs" / "openclaw" / "data" / "snapshots" / "20260419T072034Z"
    snapshot_dir.mkdir()
    write_json({"snapshot_id": "20260419T072034Z"}, snapshot_dir / "manifest.json")
    write_json({"snapshot_dir": str(snapshot_dir)}, latest_json)

    assert analysis_id_from_config(config_path=config_path) == "hybrid-gpt54mini-20260419t072034z"
