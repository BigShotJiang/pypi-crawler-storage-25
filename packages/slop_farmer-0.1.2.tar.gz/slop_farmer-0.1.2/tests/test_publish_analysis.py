from __future__ import annotations

import json
from pathlib import Path

import pytest

from slop_farmer.app.publish_analysis import (
    _publish_analysis_artifacts_api,
    _resolve_publish_snapshot_dir,
)
from slop_farmer.config import PublishAnalysisArtifactsOptions
from slop_farmer.data.parquet_io import write_json
from slop_farmer.data.snapshot_paths import resolve_snapshot_dir_from_output


class FakeHfApi:
    def __init__(self) -> None:
        self.calls: list[tuple[str, tuple, dict]] = []

    def create_repo(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        self.calls.append(("create_repo", args, kwargs))

    def create_commit(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        self.calls.append(("create_commit", args, kwargs))

    def upload_folder(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        self.calls.append(("upload_folder", args, kwargs))


def test_publish_analysis_artifacts_creates_atomic_commit(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    snapshot_dir = _write_snapshot(tmp_path, include_reviews=True)
    api = FakeHfApi()
    logs: list[str] = []
    monkeypatch.setattr(
        "slop_farmer.app.publish_analysis.hf_hub_download",
        lambda **kwargs: (_ for _ in ()).throw(FileNotFoundError()),
    )

    result = _publish_analysis_artifacts_api(
        api,
        snapshot_dir=snapshot_dir,
        hf_repo_id="evalstate/transformers-pr",
        analysis_id="hybrid-gpt54mini-v3",
        canonical=True,
        private=False,
        log=logs.append,
    )

    assert result["analysis_id"] == "hybrid-gpt54mini-v3"
    assert result["canonical"] is True
    assert api.calls[0] == (
        "create_repo",
        ("evalstate/transformers-pr",),
        {"repo_type": "dataset", "private": False, "exist_ok": True},
    )
    commit_call = api.calls[1]
    assert commit_call[0] == "create_commit"
    assert commit_call[1][0] == "evalstate/transformers-pr"
    operations = list(commit_call[1][1])
    paths = sorted(operation.path_in_repo for operation in operations)
    assert paths == [
        "analysis/current/analysis-report-hybrid.json",
        "analysis/current/analysis-report-hybrid.llm-reviews.json",
        "analysis/current/manifest.json",
        "snapshots/20260415T000000Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.json",
        "snapshots/20260415T000000Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.llm-reviews.json",
        "snapshots/20260415T000000Z/analysis-runs/hybrid-gpt54mini-v3/manifest.json",
        "snapshots/20260415T000000Z/manifest.json",
    ]
    snapshot_manifest_op = next(
        operation
        for operation in operations
        if operation.path_in_repo == "snapshots/20260415T000000Z/manifest.json"
    )
    snapshot_manifest = json.loads(snapshot_manifest_op.path_or_fileobj.decode("utf-8"))
    assert snapshot_manifest["published_analysis"]["canonical_analysis_id"] == "hybrid-gpt54mini-v3"
    assert "hybrid-gpt54mini-v3" in snapshot_manifest["published_analysis"]["runs"]
    assert logs == [
        "Ensuring Hub dataset repo exists: evalstate/transformers-pr",
        "Publishing analysis hybrid-gpt54mini-v3 for snapshot 20260415T000000Z",
        "Published analysis artifacts to evalstate/transformers-pr",
    ]


def test_publish_analysis_artifacts_skips_optional_reviews_and_preserves_existing_manifest(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    snapshot_dir = _write_snapshot(tmp_path, include_reviews=False)
    api = FakeHfApi()
    remote_manifest = tmp_path / "remote-manifest.json"
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
            "published_analysis": {
                "schema_version": 1,
                "canonical_analysis_id": "old-run",
                "runs": {
                    "old-run": {
                        "analysis_id": "old-run",
                        "manifest_path": "snapshots/20260415T000000Z/analysis-runs/old-run/manifest.json",
                    }
                },
            },
        },
        remote_manifest,
    )
    monkeypatch.setattr(
        "slop_farmer.app.publish_analysis.hf_hub_download",
        lambda **kwargs: str(remote_manifest),
    )

    _publish_analysis_artifacts_api(
        api,
        snapshot_dir=snapshot_dir,
        hf_repo_id="evalstate/transformers-pr",
        analysis_id="comparison-v2",
        canonical=False,
        private=False,
    )

    commit_call = api.calls[1]
    operations = list(commit_call[1][1])
    paths = sorted(operation.path_in_repo for operation in operations)
    assert paths == [
        "snapshots/20260415T000000Z/analysis-runs/comparison-v2/analysis-report-hybrid.json",
        "snapshots/20260415T000000Z/analysis-runs/comparison-v2/manifest.json",
        "snapshots/20260415T000000Z/manifest.json",
    ]
    snapshot_manifest_op = next(
        operation
        for operation in operations
        if operation.path_in_repo == "snapshots/20260415T000000Z/manifest.json"
    )
    snapshot_manifest = json.loads(snapshot_manifest_op.path_or_fileobj.decode("utf-8"))
    assert snapshot_manifest["published_analysis"]["canonical_analysis_id"] == "old-run"
    assert set(snapshot_manifest["published_analysis"]["runs"]) == {"old-run", "comparison-v2"}


def test_publish_analysis_artifacts_uses_explicit_analysis_input_and_sidecar_reviews(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    snapshot_dir = _write_snapshot(tmp_path, include_reviews=False)
    analysis_output = tmp_path / "exports" / "custom-hybrid-report.json"
    analysis_output.parent.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
            "model": "gpt-5.4-mini",
            "llm_enrichment": True,
            "generated_at": "2026-04-15T01:00:00Z",
            "meta_bugs": [],
            "duplicate_issues": [],
            "duplicate_prs": [],
            "best_issue": None,
            "best_pr": None,
        },
        analysis_output,
    )
    write_json(
        {"model": "gpt-5.4-mini", "reviews": []},
        analysis_output.with_name("custom-hybrid-report.llm-reviews.json"),
    )
    api = FakeHfApi()
    monkeypatch.setattr(
        "slop_farmer.app.publish_analysis.hf_hub_download",
        lambda **kwargs: (_ for _ in ()).throw(FileNotFoundError()),
    )

    _publish_analysis_artifacts_api(
        api,
        snapshot_dir=snapshot_dir,
        analysis_input=analysis_output,
        hf_repo_id="evalstate/transformers-pr",
        analysis_id="hybrid-gpt54mini-v3",
        canonical=True,
        private=False,
    )

    commit_call = api.calls[1]
    operations = list(commit_call[1][1])
    paths = sorted(operation.path_in_repo for operation in operations)
    assert "analysis/current/analysis-report-hybrid.json" in paths
    assert "analysis/current/analysis-report-hybrid.llm-reviews.json" in paths


def test_publish_analysis_artifacts_can_save_cache(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    snapshot_dir = _write_snapshot(tmp_path, include_reviews=True)
    cache_dir = snapshot_dir / "analysis-state"
    cache_dir.mkdir()
    write_json({"cache_schema_version": "1.0"}, cache_dir / "hybrid-review-cache-manifest.json")
    (cache_dir / "hybrid-review-cache.jsonl").write_text("{}", encoding="utf-8")
    api = FakeHfApi()
    monkeypatch.setattr(
        "slop_farmer.app.publish_analysis.hf_hub_download",
        lambda **kwargs: (_ for _ in ()).throw(FileNotFoundError()),
    )

    result = _publish_analysis_artifacts_api(
        api,
        snapshot_dir=snapshot_dir,
        hf_repo_id="evalstate/transformers-pr",
        analysis_id="hybrid-gpt54mini-v3",
        canonical=True,
        save_cache=True,
        private=False,
    )

    assert result["save_cache"] is True
    assert result["cache"]["artifact_paths"] == [
        "analysis-state/hybrid-review-cache-manifest.json",
        "analysis-state/hybrid-review-cache.jsonl",
    ]
    assert [call[0] for call in api.calls] == [
        "create_repo",
        "create_commit",
        "create_repo",
        "upload_folder",
    ]
    upload_call = api.calls[-1]
    assert upload_call[2] == {
        "repo_id": "evalstate/transformers-pr",
        "folder_path": cache_dir,
        "path_in_repo": "analysis-state",
        "repo_type": "dataset",
        "commit_message": "Save analysis cache for snapshot 20260415T000000Z",
    }


def test_publish_analysis_artifacts_derives_analysis_id_when_omitted(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    snapshot_dir = _write_snapshot(tmp_path, include_reviews=True)
    api = FakeHfApi()
    monkeypatch.setattr(
        "slop_farmer.app.publish_analysis.hf_hub_download",
        lambda **kwargs: (_ for _ in ()).throw(FileNotFoundError()),
    )

    result = _publish_analysis_artifacts_api(
        api,
        snapshot_dir=snapshot_dir,
        hf_repo_id="evalstate/transformers-pr",
        analysis_id=None,
        canonical=True,
        private=False,
    )

    assert result["analysis_id"] == "hybrid-gpt54mini-20260415t000000z"
    commit_call = api.calls[1]
    operations = list(commit_call[1][1])
    paths = sorted(operation.path_in_repo for operation in operations)
    assert (
        "snapshots/20260415T000000Z/analysis-runs/hybrid-gpt54mini-20260415t000000z/manifest.json"
        in paths
    )


def test_publish_analysis_artifacts_discovers_hybrid_report_from_analysis_report_json(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    snapshot_dir = _write_snapshot(tmp_path, include_reviews=True)
    (snapshot_dir / "analysis-report-hybrid.json").unlink()
    (snapshot_dir / "analysis-report-hybrid.llm-reviews.json").unlink()
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
            "model": "gpt-5.4-mini",
            "llm_enrichment": True,
            "generated_at": "2026-04-15T01:00:00Z",
            "meta_bugs": [],
            "duplicate_issues": [],
            "duplicate_prs": [],
            "best_issue": None,
            "best_pr": None,
        },
        snapshot_dir / "analysis-report.json",
    )
    write_json(
        {"model": "gpt-5.4-mini", "reviews": []},
        snapshot_dir / "analysis-report.llm-reviews.json",
    )
    api = FakeHfApi()
    monkeypatch.setattr(
        "slop_farmer.app.publish_analysis.hf_hub_download",
        lambda **kwargs: (_ for _ in ()).throw(FileNotFoundError()),
    )

    _publish_analysis_artifacts_api(
        api,
        snapshot_dir=snapshot_dir,
        hf_repo_id="evalstate/transformers-pr",
        analysis_id=None,
        canonical=True,
        private=False,
    )

    commit_call = api.calls[1]
    operations = list(commit_call[1][1])
    report_op = next(
        operation
        for operation in operations
        if operation.path_in_repo == "analysis/current/analysis-report-hybrid.json"
    )
    published_report = json.loads(Path(report_op.path_or_fileobj).read_text(encoding="utf-8"))
    assert published_report["llm_enrichment"] is True


def test_publish_analysis_artifacts_prefers_existing_local_materialized_snapshot(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = output_dir / "snapshots" / "hf-evalstate--transformers-pr"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
            "model": "gpt-5.4-mini",
            "llm_enrichment": True,
        },
        snapshot_dir / "analysis-report.json",
    )
    monkeypatch.setattr(
        "slop_farmer.app.publish_analysis.resolve_snapshot_source_dir",
        lambda **kwargs: (_ for _ in ()).throw(AssertionError("should not rematerialize")),
    )

    resolved = _resolve_publish_snapshot_dir(
        PublishAnalysisArtifactsOptions(
            output_dir=output_dir,
            snapshot_dir=None,
            analysis_input=None,
            hf_repo_id="evalstate/transformers-pr",
            hf_revision=None,
            hf_materialize_dir=None,
            analysis_id=None,
        )
    )

    assert resolved == snapshot_dir.resolve()


def test_resolve_snapshot_dir_uses_latest_pointer(tmp_path: Path) -> None:
    output_dir = tmp_path / "data"
    latest_path = output_dir / "snapshots" / "latest.json"
    latest_path.parent.mkdir(parents=True)
    write_json({"snapshot_dir": str(output_dir / "snapshots" / "20260407T090028Z")}, latest_path)

    resolved = resolve_snapshot_dir_from_output(output_dir, None)

    assert resolved == (output_dir / "snapshots" / "20260407T090028Z").resolve()


def test_resolve_snapshot_dir_uses_relative_latest_pointer(tmp_path: Path) -> None:
    output_dir = tmp_path / "data"
    latest_path = output_dir / "snapshots" / "latest.json"
    latest_path.parent.mkdir(parents=True)
    write_json({"snapshot_dir": "snapshots/20260407T090028Z"}, latest_path)

    resolved = resolve_snapshot_dir_from_output(output_dir, None)

    assert resolved == (output_dir / "snapshots" / "20260407T090028Z").resolve()


def _write_snapshot(tmp_path: Path, *, include_reviews: bool) -> Path:
    snapshot_dir = tmp_path / "snapshots" / "20260415T000000Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
            "model": "gpt-5.4-mini",
            "llm_enrichment": True,
            "generated_at": "2026-04-15T01:00:00Z",
            "meta_bugs": [],
            "duplicate_issues": [],
            "duplicate_prs": [],
            "best_issue": None,
            "best_pr": None,
        },
        snapshot_dir / "analysis-report-hybrid.json",
    )
    if include_reviews:
        write_json(
            {"model": "gpt-5.4-mini", "reviews": []},
            snapshot_dir / "analysis-report-hybrid.llm-reviews.json",
        )
    return snapshot_dir
