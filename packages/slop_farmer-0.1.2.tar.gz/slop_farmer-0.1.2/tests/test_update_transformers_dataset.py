from __future__ import annotations

import json
from pathlib import Path

import slop_farmer.app.dataset_refresh as module
from slop_farmer.config import DatasetRefreshOptions, RepoRef
from slop_farmer.data.parquet_io import read_parquet_rows, write_json, write_parquet, write_text


def test_materialize_previous_snapshot_dir_writes_previous_snapshot_for_reports(
    monkeypatch,
    tmp_path: Path,
) -> None:
    previous_root = tmp_path / "previous"
    remote_root = tmp_path / "remote"
    previous_root.mkdir()
    remote_root.mkdir()

    snapshot_dir = remote_root / "snapshots" / "20260324T000000Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {"repo": "huggingface/transformers", "snapshot_id": "20260324T000000Z"},
        snapshot_dir / "manifest.json",
    )
    write_text(
        json.dumps({"contributors": [{"author_login": "alice"}]}) + "\n",
        snapshot_dir / "new-contributors-report.json",
    )
    write_text("# Contributors\n", snapshot_dir / "new-contributors-report.md")
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "snapshot_id": "20260324T000000Z",
                "report_generated_at": "2026-03-24T00:00:00Z",
                "window_days": 42,
                "author_login": "alice",
                "name": "Alice",
                "profile_url": "https://github.com/alice",
                "repo_pull_requests_url": "https://github.com/huggingface/transformers/pulls?q=author%3Aalice",
                "repo_issues_url": "https://github.com/huggingface/transformers/issues?q=author%3Aalice",
                "repo_first_seen_at": "2026-03-24T00:00:00Z",
                "repo_last_seen_at": "2026-03-24T00:00:00Z",
                "repo_primary_artifact_count": 1,
                "repo_artifact_count": 1,
                "snapshot_issue_count": 0,
                "snapshot_pr_count": 1,
                "snapshot_comment_count": 0,
                "snapshot_review_count": 0,
                "snapshot_review_comment_count": 0,
                "repo_association": "CONTRIBUTOR",
                "new_to_repo": True,
                "first_seen_in_snapshot": True,
                "report_reason": "first_seen_in_snapshot",
                "account_age_days": 100,
                "young_account": True,
                "follow_through_score": "strong",
                "breadth_score": "low",
                "automation_risk_signal": "low",
                "heuristic_note": "note",
                "public_orgs": [],
                "visible_authored_pr_count": 1,
                "merged_pr_count": 1,
                "closed_unmerged_pr_count": 0,
                "open_pr_count": 0,
                "merged_pr_rate": 1.0,
                "closed_unmerged_pr_rate": 0.0,
                "still_open_pr_rate": 0.0,
                "distinct_repos_with_authored_prs": 1,
                "distinct_repos_with_open_prs": 0,
                "fetch_error": None,
            }
        ],
        snapshot_dir / "new_contributors.parquet",
        "new_contributors",
    )

    def stub_load_remote_file(api, repo_id: str, path_in_repo: str, local_dir: Path):
        del api, repo_id, local_dir
        candidate = remote_root / path_in_repo
        return candidate if candidate.exists() else None

    monkeypatch.setattr(module, "load_remote_file", stub_load_remote_file)

    previous_tables = {table_name: [] for table_name in module.SCHEMAS}
    previous_tables["issues"] = [
        {
            "repo": "huggingface/transformers",
            "github_id": 1,
            "github_node_id": "I_1",
            "number": 1,
            "html_url": "https://example.com/issues/1",
            "api_url": "https://api.example.com/issues/1",
            "title": "Issue",
            "body": "Body",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments_count": 0,
            "labels": [],
            "assignees": [],
            "created_at": "2026-03-24T00:00:00Z",
            "updated_at": "2026-03-24T00:00:00Z",
            "closed_at": None,
            "milestone_title": None,
            "snapshot_id": "20260324T000000Z",
            "extracted_at": "2026-03-24T00:00:00Z",
            "author_login": "alice",
            "author_id": 1,
            "author_node_id": "U_1",
            "author_type": "User",
            "author_site_admin": False,
        }
    ]

    materialized = module.materialize_previous_snapshot_dir(
        api=object(),
        repo_id="evalstate/transformers-pr",
        previous_root=previous_root,
        stable_snapshot_id="20260324T000000Z",
        latest_pointer={
            "latest_snapshot_id": "20260324T000000Z",
            "snapshot_dir": "snapshots/20260324T000000Z",
            "manifest_path": "snapshots/20260324T000000Z/manifest.json",
        },
        previous_tables=previous_tables,
    )

    assert materialized is not None
    assert read_parquet_rows(materialized / "issues.parquet")[0]["author_login"] == "alice"
    assert json.loads((materialized / "manifest.json").read_text(encoding="utf-8"))[
        "snapshot_id"
    ] == ("20260324T000000Z")
    assert (materialized / "new-contributors-report.json").exists()
    assert (materialized / "new_contributors.parquet").exists()


def test_dataset_refresh_parser_uses_configured_comment_and_review_caps(tmp_path: Path) -> None:
    config_path = tmp_path / "diffusers.yaml"
    config_path.write_text(
        """
repo: huggingface/diffusers
dataset_id: evalstate/diffusers-pr
scrape:
  max-issue-comments: 123
  max-reviews-per-pr: 17
  max-review-comments-per-pr: 31
""".strip()
        + "\n",
        encoding="utf-8",
    )

    args = module._build_argument_parser(config_path=config_path).parse_args([])

    assert args.max_issue_comments == 123
    assert args.max_reviews_per_pr == 17
    assert args.max_review_comments_per_pr == 31


def test_run_dataset_refresh_writes_manifest_before_contributor_report(
    monkeypatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("GITHUB_TOKEN", "test-token")

    report_manifest: dict | None = None
    uploaded_manifest: dict | None = None
    pr_scope_manifest: dict | None = None

    class StubApi:
        def __init__(self, token=None):
            self.token = token

        def create_repo(self, **kwargs) -> None:
            del kwargs

        def upload_folder(
            self,
            *,
            folder_path: str,
            repo_id: str,
            repo_type: str,
            commit_message: str,
        ) -> None:
            del repo_id, repo_type, commit_message
            nonlocal uploaded_manifest
            uploaded_manifest = json.loads(
                (Path(folder_path) / "manifest.json").read_text(encoding="utf-8")
            )

    class StubGitHubClient:
        def __init__(self, **kwargs) -> None:
            del kwargs

        def get_json(self, path: str) -> dict:
            del path
            return {"resources": {"core": {"limit": 5000, "remaining": 4999, "reset": 0}}}

        def iter_repo_issues(
            self,
            owner: str,
            repo: str,
            since: str | None,
            limit: int | None,
        ):
            del owner, repo, since, limit
            return iter(())

    def stub_load_remote_json_file(api, repo_id, path_in_repo, root, revision=None):
        del api, repo_id, root, revision
        if path_in_repo == "state/watermark.json":
            return {
                "last_successful_snapshot_id": "20260324T000000Z",
                "next_since": "2026-03-24T00:00:00Z",
            }
        return None

    def stub_run_new_contributor_report(options):
        nonlocal report_manifest
        report_manifest = json.loads(
            (options.snapshot_dir / "manifest.json").read_text(encoding="utf-8")
        )
        module.write_text(
            json.dumps({"contributors": []}) + "\n",
            options.snapshot_dir / "new-contributors-report.json",
        )
        module.write_text(
            "# New Contributor Report\n", options.snapshot_dir / "new-contributors-report.md"
        )
        module.write_parquet(
            [], options.snapshot_dir / "new_contributors.parquet", "new_contributors"
        )
        return options.snapshot_dir / "new-contributors-report.md"

    def stub_run_pr_scope_report(options):
        nonlocal pr_scope_manifest
        pr_scope_manifest = json.loads(
            (options.snapshot_dir / "manifest.json").read_text(encoding="utf-8")
        )
        path = options.output or (options.snapshot_dir / "pr-scope-clusters.json")
        module.write_text(
            json.dumps(
                {
                    "repo": "huggingface/transformers",
                    "snapshot_id": "20260325T000000Z",
                    "generated_at": "2026-03-25T00:00:00Z",
                    "cluster_count": 0,
                    "pr_scope_clusters": [],
                }
            )
            + "\n",
            path,
        )
        return path

    monkeypatch.setattr(module, "HfApi", StubApi)
    monkeypatch.setattr(module, "GitHubClient", StubGitHubClient)
    monkeypatch.setattr(module, "list_remote_paths", lambda api, repo_id: set())
    monkeypatch.setattr(module, "load_remote_json_file", stub_load_remote_json_file)
    monkeypatch.setattr(module, "load_remote_file", lambda *args, **kwargs: None)
    monkeypatch.setattr(module, "snapshot_id", lambda: "20260325T000000Z")
    monkeypatch.setattr(module, "iso_now", lambda: "2026-03-25T00:00:00Z")
    monkeypatch.setattr(module, "run_new_contributor_report", stub_run_new_contributor_report)
    monkeypatch.setattr(module, "run_pr_scope_report", stub_run_pr_scope_report)

    result = module.run_dataset_refresh(
        DatasetRefreshOptions(
            repo=RepoRef.parse("huggingface/transformers"),
            hf_repo_id="evalstate/transformers-pr",
            private_hf_repo=False,
            max_issues=None,
            max_prs=None,
            max_issue_comments=None,
            max_reviews_per_pr=None,
            max_review_comments_per_pr=None,
            fetch_timeline=False,
            new_contributor_report=True,
            new_contributor_window_days=42,
            new_contributor_max_authors=10,
            http_timeout=30,
            http_max_retries=2,
            checkpoint_every_comments=1000,
            checkpoint_every_prs=25,
            cluster_suppression_rules=(),
        )
    )

    assert pr_scope_manifest is not None
    assert pr_scope_manifest["watermark"]["previous_snapshot_dir"].endswith("20260324T000000Z")
    assert report_manifest is not None
    assert report_manifest["watermark"]["previous_snapshot_dir"].endswith("20260324T000000Z")
    assert uploaded_manifest is not None
    assert "previous_snapshot_dir" not in uploaded_manifest["watermark"]
    assert uploaded_manifest["artifacts"]["pr_scope_clusters_json"] == "pr-scope-clusters.json"
    assert result["counts"]["new_contributors"] == 0


def test_run_dataset_refresh_bootstraps_effective_since_from_root_manifest(
    monkeypatch,
) -> None:
    monkeypatch.setenv("GITHUB_TOKEN", "test-token")

    observed_since: str | None = None

    class StubApi:
        def __init__(self, token=None):
            self.token = token

        def create_repo(self, **kwargs) -> None:
            del kwargs

        def upload_folder(self, **kwargs) -> None:
            del kwargs

    class StubGitHubClient:
        def __init__(self, **kwargs) -> None:
            del kwargs

        def get_json(self, path: str) -> dict:
            del path
            return {"resources": {"core": {"limit": 5000, "remaining": 4999, "reset": 0}}}

        def iter_repo_issues(
            self,
            owner: str,
            repo: str,
            since: str | None,
            limit: int | None,
        ):
            del owner, repo, limit
            nonlocal observed_since
            observed_since = since
            return iter(())

    def stub_load_remote_json_file(api, repo_id, path_in_repo, root, revision=None):
        del api, repo_id, root, revision
        if path_in_repo == "manifest.json":
            return {
                "repo": "huggingface/transformers",
                "snapshot_id": "20260324T000000Z",
                "watermark": {
                    "next_since": "2026-03-24T12:34:56Z",
                },
            }
        return None

    monkeypatch.setattr(module, "HfApi", StubApi)
    monkeypatch.setattr(module, "GitHubClient", StubGitHubClient)
    monkeypatch.setattr(module, "list_remote_paths", lambda api, repo_id: {"manifest.json"})
    monkeypatch.setattr(module, "load_remote_json_file", stub_load_remote_json_file)
    monkeypatch.setattr(module, "load_remote_file", lambda *args, **kwargs: None)
    monkeypatch.setattr(module, "snapshot_id", lambda: "20260325T000000Z")
    monkeypatch.setattr(module, "iso_now", lambda: "2026-03-25T00:00:00Z")

    module.run_dataset_refresh(
        DatasetRefreshOptions(
            repo=RepoRef.parse("huggingface/transformers"),
            hf_repo_id="evalstate/transformers-pr",
            private_hf_repo=False,
            max_issues=None,
            max_prs=None,
            max_issue_comments=None,
            max_reviews_per_pr=None,
            max_review_comments_per_pr=None,
            fetch_timeline=False,
            new_contributor_report=False,
            new_contributor_window_days=42,
            new_contributor_max_authors=10,
            http_timeout=30,
            http_max_retries=2,
            checkpoint_every_comments=1000,
            checkpoint_every_prs=25,
            cluster_suppression_rules=(),
        )
    )

    assert observed_since == "2026-03-24T12:34:56Z"
