from __future__ import annotations

import os
import subprocess
from pathlib import Path

from slop_farmer.config import DeployDashboardOptions
from slop_farmer.data.snapshot_source import resolve_snapshot_source_dir


def run_deploy_dashboard(options: DeployDashboardOptions) -> None:
    repo_root = Path(__file__).resolve().parents[3]
    script_path = repo_root / "scripts" / "deploy_dashboard_space.sh"
    if not script_path.exists():
        raise FileNotFoundError(f"Could not find deploy script at {script_path}")
    env = os.environ.copy()
    env.update(
        {
            "PIPELINE_DATA_DIR": str(options.pipeline_data_dir),
            "WEB_DIR": str(options.web_dir),
            "SNAPSHOT_DIR": str(
                resolve_snapshot_source_dir(
                    snapshot_dir=options.snapshot_dir,
                    local_snapshots_root=options.pipeline_data_dir.resolve() / "snapshots",
                    hf_repo_id=options.hf_repo_id,
                    hf_revision=options.hf_revision,
                    hf_materialize_dir=options.hf_materialize_dir,
                    hf_output_dir=options.pipeline_data_dir,
                )
            ),
            "DASHBOARD_WINDOW_DAYS": str(options.dashboard_window_days),
            "CONTRIBUTOR_WINDOW_DAYS": str(options.contributor_window_days),
            "CONTRIBUTOR_MAX_AUTHORS": str(options.contributor_max_authors),
            "COMMIT_MESSAGE": options.commit_message,
            "SPACE_ID": options.space_id,
            "SPACE_EMOJI": options.space_emoji,
            "SPACE_COLOR_FROM": options.space_color_from,
            "SPACE_COLOR_TO": options.space_color_to,
            "SPACE_SHORT_DESCRIPTION": options.space_short_description,
        }
    )
    if options.analysis_input is not None:
        env["ANALYSIS_INPUT"] = str(options.analysis_input.resolve())
    if options.contributors_input is not None:
        env["CONTRIBUTORS_INPUT"] = str(options.contributors_input.resolve())
    if options.pr_scope_input is not None:
        env["PR_SCOPE_INPUT"] = str(options.pr_scope_input.resolve())
    if options.refresh_contributors:
        env["REFRESH_CONTRIBUTORS"] = "1"
    if options.private_space:
        env["PRIVATE_FLAG"] = "--private"
    if options.space_title:
        env["SPACE_TITLE"] = options.space_title
    if options.dataset_id:
        env["DATASET_ID"] = options.dataset_id
    if options.space_tags:
        env["SPACE_TAGS"] = options.space_tags
    subprocess.run([str(script_path)], cwd=repo_root, env=env, check=True)
