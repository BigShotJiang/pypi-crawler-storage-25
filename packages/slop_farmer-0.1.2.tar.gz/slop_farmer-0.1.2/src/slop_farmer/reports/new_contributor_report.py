from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from slop_farmer.config import NewContributorReportOptions, resolve_github_token
from slop_farmer.data.http import urlopen_with_retry
from slop_farmer.data.parquet_io import read_json, read_parquet_rows, write_parquet, write_text
from slop_farmer.data.snapshot_source import resolve_snapshot_source_dir
from slop_farmer.reports.user_activity import summarize_user

GRAPHQL_URL = "https://api.github.com/graphql"
PROFILE_QUERY = """
query UserActivityProfile($login: String!, $from: DateTime!, $to: DateTime!) {
  rateLimit { cost remaining resetAt }
  user(login: $login) {
    login
    name
    createdAt
    organizations(first: 100) {
      nodes {
        login
        name
      }
    }
    starredRepositories(first: 100, orderBy: {field: STARRED_AT, direction: DESC}) {
      totalCount
      nodes {
        nameWithOwner
        stargazerCount
        owner {
          login
        }
      }
    }
    contributionsCollection(from: $from, to: $to) {
      contributionCalendar {
        totalContributions
        weeks {
          contributionDays {
            date
            contributionCount
          }
        }
      }
      totalIssueContributions
      totalPullRequestContributions
      pullRequestContributionsByRepository(maxRepositories: 10) {
        repository { nameWithOwner }
        contributions { totalCount }
      }
      issueContributionsByRepository(maxRepositories: 10) {
        repository { nameWithOwner }
        contributions { totalCount }
      }
    }
  }
}
""".strip()
SEARCH_PRS_QUERY = """
query SearchPullRequests($query: String!, $cursor: String) {
  search(type: ISSUE, query: $query, first: 100, after: $cursor) {
    issueCount
    pageInfo { hasNextPage endCursor }
    nodes {
      ... on PullRequest {
        number
        title
        url
        state
        merged
        createdAt
        updatedAt
        repository { nameWithOwner stargazerCount }
      }
    }
  }
}
""".strip()
SEARCH_ISSUES_QUERY = """
query SearchIssues($query: String!, $cursor: String) {
  search(type: ISSUE, query: $query, first: 100, after: $cursor) {
    issueCount
    pageInfo { hasNextPage endCursor }
    nodes {
      ... on Issue {
        number
        title
        url
        state
        createdAt
        updatedAt
        repository { nameWithOwner }
      }
    }
  }
}
""".strip()
PREVIOUS_REPORT_REUSE_MAX_AGE = timedelta(days=2)


def run_new_contributor_report(options: NewContributorReportOptions) -> Path:
    snapshot_dir = _resolve_snapshot_dir(options)
    snapshot = _load_snapshot(snapshot_dir)
    _report_log(f"Building contributor report for {snapshot['repo']} from {snapshot_dir}")
    contributors, instrumentation = _report_contributors(snapshot, options)
    report = {
        "schema_version": "1.0",
        "repo": snapshot["repo"],
        "snapshot_id": snapshot["snapshot_id"],
        "generated_at": _iso_now(),
        "window_days": options.window_days,
        "max_authors": options.max_authors,
        "instrumentation": instrumentation,
        "contributors": contributors,
    }
    markdown_path = (options.output or (snapshot_dir / "new-contributors-report.md")).resolve()
    json_path = (options.json_output or (snapshot_dir / "new-contributors-report.json")).resolve()
    parquet_path = snapshot_dir / "new_contributors.parquet"
    write_text(json.dumps(report, indent=2) + "\n", json_path)
    write_text(_markdown_report_text(report), markdown_path)
    write_parquet(_parquet_rows(report), parquet_path, "new_contributors")
    _report_log(f"Wrote contributor report for {len(contributors)} authors to {json_path}")
    return markdown_path


def _resolve_snapshot_dir(options: NewContributorReportOptions) -> Path:
    return resolve_snapshot_source_dir(
        snapshot_dir=options.snapshot_dir,
        local_snapshots_root=options.output_dir.resolve() / "snapshots",
        hf_repo_id=options.hf_repo_id,
        hf_revision=options.hf_revision,
        hf_materialize_dir=options.hf_materialize_dir,
        hf_output_dir=options.output_dir,
    )


def _load_snapshot(snapshot_dir: Path) -> dict[str, Any]:
    manifest_path = snapshot_dir / "manifest.json"
    manifest = read_json(manifest_path) if manifest_path.exists() else {}
    issues = read_parquet_rows(snapshot_dir / "issues.parquet")
    pull_requests = read_parquet_rows(snapshot_dir / "pull_requests.parquet")
    comments = read_parquet_rows(snapshot_dir / "comments.parquet")
    reviews = read_parquet_rows(snapshot_dir / "reviews.parquet")
    review_comments = read_parquet_rows(snapshot_dir / "review_comments.parquet")
    repo = (
        manifest.get("repo")
        or (issues[0]["repo"] if issues else None)
        or (pull_requests[0]["repo"] if pull_requests else None)
        or ""
    )
    snapshot_id = manifest.get("snapshot_id") or snapshot_dir.name
    return {
        "repo": repo,
        "snapshot_id": snapshot_id,
        "manifest": manifest,
        "issues": issues,
        "pull_requests": pull_requests,
        "comments": comments,
        "reviews": reviews,
        "review_comments": review_comments,
    }


def _report_contributors(
    snapshot: dict[str, Any], options: NewContributorReportOptions
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    author_rows = _author_rows(snapshot)
    previous_snapshot_dir = _previous_snapshot_dir(snapshot)
    previous_primary_authors = _snapshot_primary_authors(previous_snapshot_dir)
    previous_merged_pr_authors = _snapshot_merged_pr_authors(previous_snapshot_dir)
    previous_report_payload = _previous_report_payload(previous_snapshot_dir)
    previous_report_contributors = _previous_report_contributors(previous_report_payload)
    previous_report_entries = _previous_report_contributor_entries(previous_report_payload)
    snapshot_reference_time = _snapshot_reference_time(snapshot)
    previous_report_reusable = _previous_report_reuse_allowed(
        previous_report_payload,
        window_days=options.window_days,
        reference_time=snapshot_reference_time,
    )
    cutoff = snapshot_reference_time - timedelta(days=options.window_days)
    selected = []
    for row in author_rows:
        if row["pr_count"] == 0:
            continue
        recent_pr_count = 0
        for pr in row["pull_requests"]:
            created_at = _coerce_datetime(pr.get("created_at"))
            if created_at is not None and created_at >= cutoff:
                recent_pr_count += 1
        row["recent_pr_count"] = recent_pr_count
        if row["recent_pr_count"] == 0:
            continue
        selected.append(row)
    selected.sort(
        key=lambda row: (
            -int(row["recent_pr_count"]),
            -int(row["pr_count"]),
            -int(row["issue_count"]),
            row["author_login"].casefold(),
        )
    )
    if options.max_authors > 0:
        selected = selected[: options.max_authors]
    selected_logins = [str(row["author_login"]) for row in selected]
    selected_login_set = set(selected_logins)
    selected_seen_in_previous_primary = selected_login_set & previous_primary_authors
    selected_seen_in_previous_report = selected_login_set & previous_report_contributors
    selected_known_merged = selected_login_set & previous_merged_pr_authors
    first_seen_count = sum(
        1 for row in selected if row["author_login"] not in previous_primary_authors
    )
    _report_log(
        f"Selected {len(selected)} contributor authors for enrichment "
        f"(window={options.window_days}d, max_authors={'unlimited' if options.max_authors == 0 else options.max_authors})"
    )
    _report_log(
        "Contributor cacheability estimate: "
        f"selected={len(selected)}, "
        f"first_seen={first_seen_count}, "
        f"known_via_prior_merged_pr={len(selected_known_merged)}, "
        f"seen_in_previous_primary={len(selected_seen_in_previous_primary)}, "
        f"overlap_previous_report={len(selected_seen_in_previous_report)}/"
        f"{len(selected)}"
        f" ({(100.0 * len(selected_seen_in_previous_report) / len(selected) if selected else 0.0):.1f}%), "
        f"window_anchor=run_time"
    )
    contributors: list[dict[str, Any]] = []
    total_selected = len(selected)
    started = time.perf_counter()
    reused_previous_report = 0
    live_fetches = 0
    reused_known_merged = 0
    for index, row in enumerate(selected, start=1):
        first_seen_in_snapshot = row["author_login"] not in previous_primary_authors
        known_via_prior_merged_pr = row["author_login"] in previous_merged_pr_authors
        previous_entry = previous_report_entries.get(row["author_login"])
        if index == 1 or index == total_selected or index % 10 == 0:
            _report_log(
                f"Enriching contributors: {index}/{total_selected} "
                f"(current={row['author_login']}, first_seen={str(first_seen_in_snapshot).lower()}, "
                f"known_via_prior_merged_pr={str(known_via_prior_merged_pr).lower()})"
            )
        if (
            previous_report_reusable
            and previous_entry is not None
            and not previous_entry.get("fetch_error")
        ):
            contributors.append(
                _reused_previous_report_entry(
                    snapshot["repo"],
                    row,
                    previous_entry,
                    first_seen_in_snapshot=first_seen_in_snapshot,
                    known_via_prior_merged_pr=known_via_prior_merged_pr,
                )
            )
            reused_previous_report += 1
            if known_via_prior_merged_pr:
                reused_known_merged += 1
            continue
        try:
            summary = summarize_user(row["author_login"], options.window_days, None)
            fetch_error = None
            live_fetches += 1
        except (
            Exception
        ) as exc:  # pragma: no cover - network failures are exercised via monkeypatch in tests
            summary = None
            fetch_error = str(exc)
            _report_log(f"Contributor enrichment failed for {row['author_login']}: {fetch_error}")
            live_fetches += 1
        contributors.append(
            _contributor_entry(
                snapshot["repo"],
                row,
                summary,
                fetch_error,
                first_seen_in_snapshot=first_seen_in_snapshot,
                known_via_prior_merged_pr=known_via_prior_merged_pr,
            )
        )
    elapsed = time.perf_counter() - started
    avg_seconds = elapsed / total_selected if total_selected else 0.0
    failures = sum(1 for contributor in contributors if contributor.get("fetch_error"))
    _report_log(
        "Contributor enrichment timing: "
        f"authors={total_selected}, "
        f"failures={failures}, "
        f"elapsed={elapsed:.2f}s, "
        f"avg={avg_seconds:.2f}s/author"
    )
    instrumentation = {
        "selected_contributors": total_selected,
        "first_seen_in_snapshot": first_seen_count,
        "known_via_prior_merged_pr": len(selected_known_merged),
        "previous_primary_author_count": len(previous_primary_authors),
        "selected_seen_in_previous_primary": len(selected_seen_in_previous_primary),
        "previous_report_contributor_count": len(previous_report_contributors),
        "selected_overlap_previous_report": len(selected_seen_in_previous_report),
        "selected_overlap_previous_report_rate": round(
            (len(selected_seen_in_previous_report) / total_selected) if total_selected else 0.0,
            4,
        ),
        "reused_previous_report_entries": reused_previous_report,
        "reused_known_merged_contributors": reused_known_merged,
        "live_fetches": live_fetches,
        "window_anchor": "run_time",
        "window_anchor_cacheable": False,
        "enrichment_elapsed_seconds": round(elapsed, 3),
        "enrichment_avg_seconds_per_author": round(avg_seconds, 3),
        "enrichment_failures": failures,
    }
    return contributors, instrumentation


def _author_rows(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    authors: dict[str, dict[str, Any]] = {}

    def ensure(login: str, author_id: int | None) -> dict[str, Any]:
        row = authors.get(login)
        if row is not None:
            return row
        row = {
            "author_login": login,
            "author_id": author_id,
            "issue_count": 0,
            "pr_count": 0,
            "comment_count": 0,
            "review_count": 0,
            "review_comment_count": 0,
            "first_seen_at": None,
            "last_seen_at": None,
            "issues": [],
            "pull_requests": [],
            "repo_association_values": set(),
        }
        authors[login] = row
        return row

    def touch(row: dict[str, Any], timestamp: str | None) -> None:
        if not timestamp:
            return
        if row["first_seen_at"] is None or timestamp < row["first_seen_at"]:
            row["first_seen_at"] = timestamp
        if row["last_seen_at"] is None or timestamp > row["last_seen_at"]:
            row["last_seen_at"] = timestamp

    for issue in snapshot["issues"]:
        login = str(issue.get("author_login") or "").strip()
        if not login:
            continue
        row = ensure(login, _coerce_int(issue.get("author_id")))
        row["issue_count"] += 1
        row["issues"].append(issue)
        _track_repo_association(row, issue.get("author_association"))
        touch(row, issue.get("created_at") or issue.get("updated_at"))

    for pr in snapshot["pull_requests"]:
        login = str(pr.get("author_login") or "").strip()
        if not login:
            continue
        row = ensure(login, _coerce_int(pr.get("author_id")))
        row["pr_count"] += 1
        row["pull_requests"].append(pr)
        _track_repo_association(row, pr.get("author_association"))
        touch(row, pr.get("created_at") or pr.get("updated_at"))

    for comment in snapshot["comments"]:
        login = str(comment.get("author_login") or "").strip()
        if not login:
            continue
        row = ensure(login, _coerce_int(comment.get("author_id")))
        row["comment_count"] += 1
        _track_repo_association(row, comment.get("author_association"))
        touch(row, comment.get("created_at") or comment.get("updated_at"))

    for review in snapshot["reviews"]:
        login = str(review.get("author_login") or "").strip()
        if not login:
            continue
        row = ensure(login, _coerce_int(review.get("author_id")))
        row["review_count"] += 1
        _track_repo_association(row, review.get("author_association"))
        touch(row, review.get("submitted_at") or review.get("created_at"))

    for review_comment in snapshot["review_comments"]:
        login = str(review_comment.get("author_login") or "").strip()
        if not login:
            continue
        row = ensure(login, _coerce_int(review_comment.get("author_id")))
        row["review_comment_count"] += 1
        _track_repo_association(row, review_comment.get("author_association"))
        touch(row, review_comment.get("created_at") or review_comment.get("updated_at"))

    rows = []
    for row in authors.values():
        row["primary_artifact_count"] = row["issue_count"] + row["pr_count"]
        row["artifact_count"] = (
            row["primary_artifact_count"]
            + row["comment_count"]
            + row["review_count"]
            + row["review_comment_count"]
        )
        row["repo_association_values"] = sorted(
            str(value) for value in row["repo_association_values"]
        )
        row["repo_association"] = _select_repo_association(row["repo_association_values"])
        row["issues"] = sorted(
            row["issues"],
            key=lambda item: (
                str(item.get("created_at") or ""),
                int(item.get("number") or 0),
            ),
            reverse=True,
        )[:3]
        row["pull_requests"] = sorted(
            row["pull_requests"],
            key=lambda item: (
                str(item.get("created_at") or ""),
                int(item.get("number") or 0),
            ),
            reverse=True,
        )[:3]
        rows.append(row)
    return sorted(
        rows,
        key=lambda row: (
            -row["pr_count"],
            -row["issue_count"],
            row["primary_artifact_count"],
            str(row["last_seen_at"] or ""),
            row["author_login"].casefold(),
        ),
        reverse=False,
    )


def _previous_snapshot_dir(snapshot: dict[str, Any]) -> Path | None:
    manifest = snapshot.get("manifest") or {}
    watermark = manifest.get("watermark") or {}
    raw = watermark.get("previous_snapshot_dir")
    if not raw:
        return None
    path = Path(str(raw))
    if not path.exists():
        return None
    return path.resolve()


def _snapshot_primary_authors(snapshot_dir: Path | None) -> set[str]:
    if snapshot_dir is None:
        return set()
    authors = set()
    for table_name in ("issues", "pull_requests"):
        for row in read_parquet_rows(snapshot_dir / f"{table_name}.parquet"):
            login = str(row.get("author_login") or "").strip()
            if login:
                authors.add(login)
    return authors


def _snapshot_merged_pr_authors(snapshot_dir: Path | None) -> set[str]:
    if snapshot_dir is None:
        return set()
    authors = set()
    for row in read_parquet_rows(snapshot_dir / "pull_requests.parquet"):
        login = str(row.get("author_login") or "").strip()
        if login and bool(row.get("merged")):
            authors.add(login)
    return authors


def _previous_report_payload(snapshot_dir: Path | None) -> dict[str, Any] | None:
    if snapshot_dir is None:
        return None
    path = snapshot_dir / "new-contributors-report.json"
    if not path.exists():
        return None
    try:
        payload = read_json(path)
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _previous_report_contributors(payload: dict[str, Any] | None) -> set[str]:
    if payload is None:
        return set()
    contributors = payload.get("contributors")
    if not isinstance(contributors, list):
        return set()
    return {
        str(row.get("author_login")).strip()
        for row in contributors
        if isinstance(row, dict) and str(row.get("author_login") or "").strip()
    }


def _previous_report_contributor_entries(
    payload: dict[str, Any] | None,
) -> dict[str, dict[str, Any]]:
    if payload is None:
        return {}
    contributors = payload.get("contributors")
    if not isinstance(contributors, list):
        return {}
    return {
        login: row
        for row in contributors
        if isinstance(row, dict) and (login := str(row.get("author_login") or "").strip())
    }


def _previous_report_reuse_allowed(
    payload: dict[str, Any] | None,
    *,
    window_days: int,
    reference_time: datetime,
) -> bool:
    if payload is None:
        return False
    if _coerce_int(payload.get("window_days")) != window_days:
        return False
    generated_at = _coerce_datetime(payload.get("generated_at"))
    if generated_at is None:
        return False
    return abs(reference_time - generated_at) <= PREVIOUS_REPORT_REUSE_MAX_AGE


def _reused_previous_report_entry(
    repo: str,
    row: dict[str, Any],
    previous_entry: dict[str, Any],
    *,
    first_seen_in_snapshot: bool,
    known_via_prior_merged_pr: bool,
) -> dict[str, Any]:
    login = row["author_login"]
    age_days = _coerce_int(previous_entry.get("account_age_days"))
    return {
        "author_login": login,
        "name": previous_entry.get("name"),
        "profile_url": _profile_url(login),
        "repo_pull_requests_url": _repo_search_url(repo, login, is_pr=True),
        "repo_issues_url": _repo_search_url(repo, login, is_pr=False),
        "repo_first_seen_at": row["first_seen_at"],
        "repo_last_seen_at": row["last_seen_at"],
        "repo_primary_artifact_count": row["primary_artifact_count"],
        "repo_artifact_count": row["artifact_count"],
        "snapshot_issue_count": row["issue_count"],
        "snapshot_pr_count": row["pr_count"],
        "snapshot_comment_count": row["comment_count"],
        "snapshot_review_count": row["review_count"],
        "snapshot_review_comment_count": row["review_comment_count"],
        "repo_association": row.get("repo_association"),
        "new_to_repo": first_seen_in_snapshot,
        "first_seen_in_snapshot": first_seen_in_snapshot,
        "known_via_prior_merged_pr": known_via_prior_merged_pr,
        "report_reason": "first_seen_in_snapshot" if first_seen_in_snapshot else None,
        "enrichment_source": "previous_report",
        "live_refetch_skipped": True,
        "account_age_days": age_days,
        "young_account": age_days is not None and age_days <= 365,
        "follow_through_score": previous_entry.get("follow_through_score"),
        "breadth_score": previous_entry.get("breadth_score"),
        "automation_risk_signal": previous_entry.get("automation_risk_signal"),
        "heuristic_note": previous_entry.get("heuristic_note"),
        "public_orgs": _previous_report_public_orgs(previous_entry),
        "activity": _previous_report_activity(previous_entry),
        "examples": {
            "pull_requests": [
                _artifact_example(item, "pull_request") for item in row["pull_requests"]
            ],
            "issues": [_artifact_example(item, "issue") for item in row["issues"]],
        },
        "fetch_error": None,
    }


def _previous_report_public_orgs(previous_entry: dict[str, Any]) -> list[str]:
    values = previous_entry.get("public_orgs")
    if not isinstance(values, list):
        return []
    public_orgs: list[str] = []
    for value in values:
        if isinstance(value, str) and value.strip():
            public_orgs.append(value.strip())
        elif isinstance(value, dict):
            login = str(value.get("login") or "").strip()
            if login:
                public_orgs.append(login)
    return public_orgs


def _previous_report_activity(previous_entry: dict[str, Any]) -> dict[str, Any]:
    activity = previous_entry.get("activity")
    if not isinstance(activity, dict):
        activity = previous_entry
    return {
        "visible_authored_pr_count": activity.get("visible_authored_pr_count"),
        "merged_pr_count": activity.get("merged_pr_count"),
        "closed_unmerged_pr_count": activity.get("closed_unmerged_pr_count"),
        "open_pr_count": activity.get("open_pr_count"),
        "merged_pr_rate": activity.get("merged_pr_rate"),
        "closed_unmerged_pr_rate": activity.get("closed_unmerged_pr_rate"),
        "still_open_pr_rate": activity.get("still_open_pr_rate"),
        "distinct_repos_with_authored_prs": activity.get("distinct_repos_with_authored_prs"),
        "distinct_repos_with_open_prs": activity.get("distinct_repos_with_open_prs"),
    }


def _contributor_entry(
    repo: str,
    row: dict[str, Any],
    summary: dict[str, Any] | None,
    fetch_error: str | None,
    *,
    first_seen_in_snapshot: bool,
    known_via_prior_merged_pr: bool,
) -> dict[str, Any]:
    login = row["author_login"]
    account = (summary or {}).get("account") or {}
    activity = (summary or {}).get("activity") or {}
    orgs = ((summary or {}).get("organization_membership") or {}).get("public_orgs") or []
    return {
        "author_login": login,
        "name": (summary or {}).get("name"),
        "profile_url": _profile_url(login),
        "repo_pull_requests_url": _repo_search_url(repo, login, is_pr=True),
        "repo_issues_url": _repo_search_url(repo, login, is_pr=False),
        "repo_first_seen_at": row["first_seen_at"],
        "repo_last_seen_at": row["last_seen_at"],
        "repo_primary_artifact_count": row["primary_artifact_count"],
        "repo_artifact_count": row["artifact_count"],
        "snapshot_issue_count": row["issue_count"],
        "snapshot_pr_count": row["pr_count"],
        "snapshot_comment_count": row["comment_count"],
        "snapshot_review_count": row["review_count"],
        "snapshot_review_comment_count": row["review_comment_count"],
        "repo_association": row.get("repo_association"),
        "new_to_repo": first_seen_in_snapshot,
        "first_seen_in_snapshot": first_seen_in_snapshot,
        "known_via_prior_merged_pr": known_via_prior_merged_pr,
        "report_reason": "first_seen_in_snapshot" if first_seen_in_snapshot else None,
        "enrichment_source": "live",
        "live_refetch_skipped": False,
        "account_age_days": account.get("age_days"),
        "young_account": _coerce_int(account.get("age_days")) is not None
        and int(account["age_days"]) <= 365,
        "follow_through_score": score_follow_through(summary),
        "breadth_score": score_breadth(summary),
        "automation_risk_signal": score_automation_risk(
            summary, repo_snapshot_pr_count=row["pr_count"]
        ),
        "heuristic_note": activity_note(summary, repo_snapshot_pr_count=row["pr_count"]),
        "public_orgs": [org["login"] for org in orgs if isinstance(org, dict) and org.get("login")],
        "activity": {
            "visible_authored_pr_count": activity.get("visible_authored_pr_count"),
            "merged_pr_count": activity.get("merged_pr_count"),
            "closed_unmerged_pr_count": activity.get("closed_unmerged_pr_count"),
            "open_pr_count": activity.get("open_pr_count"),
            "merged_pr_rate": activity.get("merged_pr_rate"),
            "closed_unmerged_pr_rate": activity.get("closed_unmerged_pr_rate"),
            "still_open_pr_rate": activity.get("still_open_pr_rate"),
            "distinct_repos_with_authored_prs": activity.get("distinct_repos_with_authored_prs"),
            "distinct_repos_with_open_prs": activity.get("distinct_repos_with_open_prs"),
        },
        "examples": {
            "pull_requests": [
                _artifact_example(item, "pull_request") for item in row["pull_requests"]
            ],
            "issues": [_artifact_example(item, "issue") for item in row["issues"]],
        },
        "fetch_error": fetch_error,
    }


def _artifact_example(row: dict[str, Any], kind: str) -> dict[str, Any]:
    return {
        "kind": kind,
        "number": _coerce_int(row.get("number")),
        "title": row.get("title"),
        "url": row.get("html_url"),
        "state": row.get("state"),
        "merged": row.get("merged"),
        "draft": row.get("draft"),
        "created_at": row.get("created_at"),
    }


def _markdown_report_text(report: dict[str, Any]) -> str:
    lines = [
        f"# New Contributor Report: {report['repo']}",
        "",
        f"- Snapshot: `{report['snapshot_id']}`",
        f"- Generated: `{report['generated_at']}`",
        f"- Activity window: `{report['window_days']}d`",
        f"- Contributors: `{len(report['contributors'])}`",
        "",
        "## Summary",
        "",
        "| Author | Profile | First seen? | Association | Account age | Repo first seen | Snapshot PRs | Snapshot issues | Follow-through | Breadth | Automation risk | Notes |",
        "| --- | --- | --- | --- | ---: | --- | ---: | ---: | --- | --- | --- | --- |",
    ]
    for contributor in report["contributors"]:
        lines.append(
            "| "
            f"`{contributor['author_login']}` | "
            f"[profile]({contributor['profile_url']}) | "
            f"{'yes' if contributor['first_seen_in_snapshot'] else 'no'} | "
            f"{contributor.get('repo_association') or 'unknown'} | "
            f"{_display_int(contributor['account_age_days'])}d | "
            f"`{contributor['repo_first_seen_at'] or 'unknown'}` | "
            f"{contributor['snapshot_pr_count']} | "
            f"{contributor['snapshot_issue_count']} | "
            f"{contributor['follow_through_score']} | "
            f"{contributor['breadth_score']} | "
            f"{contributor['automation_risk_signal']} | "
            f"{contributor['heuristic_note']} |"
        )
    lines.extend(["", "## Contributors", ""])
    if not report["contributors"]:
        lines.extend(["No new contributors found.", ""])
        return "\n".join(lines).rstrip() + "\n"
    for contributor in report["contributors"]:
        lines.extend(_contributor_markdown_lines(report["repo"], contributor))
    return "\n".join(lines).rstrip() + "\n"


def _parquet_rows(report: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for contributor in report["contributors"]:
        activity = contributor["activity"]
        rows.append(
            {
                "repo": report["repo"],
                "snapshot_id": report["snapshot_id"],
                "report_generated_at": report["generated_at"],
                "window_days": report["window_days"],
                "author_login": contributor["author_login"],
                "name": contributor["name"],
                "profile_url": contributor["profile_url"],
                "repo_pull_requests_url": contributor["repo_pull_requests_url"],
                "repo_issues_url": contributor["repo_issues_url"],
                "repo_first_seen_at": contributor["repo_first_seen_at"],
                "repo_last_seen_at": contributor["repo_last_seen_at"],
                "repo_primary_artifact_count": contributor["repo_primary_artifact_count"],
                "repo_artifact_count": contributor["repo_artifact_count"],
                "snapshot_issue_count": contributor["snapshot_issue_count"],
                "snapshot_pr_count": contributor["snapshot_pr_count"],
                "snapshot_comment_count": contributor["snapshot_comment_count"],
                "snapshot_review_count": contributor["snapshot_review_count"],
                "snapshot_review_comment_count": contributor["snapshot_review_comment_count"],
                "repo_association": contributor.get("repo_association"),
                "new_to_repo": contributor["new_to_repo"],
                "first_seen_in_snapshot": contributor["first_seen_in_snapshot"],
                "report_reason": contributor["report_reason"],
                "account_age_days": contributor["account_age_days"],
                "young_account": contributor["young_account"],
                "follow_through_score": contributor["follow_through_score"],
                "breadth_score": contributor["breadth_score"],
                "automation_risk_signal": contributor["automation_risk_signal"],
                "heuristic_note": contributor["heuristic_note"],
                "public_orgs": contributor["public_orgs"],
                "visible_authored_pr_count": activity.get("visible_authored_pr_count"),
                "merged_pr_count": activity.get("merged_pr_count"),
                "closed_unmerged_pr_count": activity.get("closed_unmerged_pr_count"),
                "open_pr_count": activity.get("open_pr_count"),
                "merged_pr_rate": activity.get("merged_pr_rate"),
                "closed_unmerged_pr_rate": activity.get("closed_unmerged_pr_rate"),
                "still_open_pr_rate": activity.get("still_open_pr_rate"),
                "distinct_repos_with_authored_prs": activity.get(
                    "distinct_repos_with_authored_prs"
                ),
                "distinct_repos_with_open_prs": activity.get("distinct_repos_with_open_prs"),
                "fetch_error": contributor.get("fetch_error"),
            }
        )
    return rows


def _contributor_markdown_lines(repo: str, contributor: dict[str, Any]) -> list[str]:
    orgs = ", ".join(f"`{org}`" for org in contributor["public_orgs"]) or "none visible"
    activity = contributor["activity"]
    lines = [
        f"### `{contributor['author_login']}`",
        "",
        f"- profile: [github.com/{contributor['author_login']}]({contributor['profile_url']})",
        f"- repo PR search: [open search]({contributor['repo_pull_requests_url']})",
        f"- repo issue search: [open search]({contributor['repo_issues_url']})",
        f"- repo first seen: `{contributor['repo_first_seen_at'] or 'unknown'}`",
        f"- repo last seen: `{contributor['repo_last_seen_at'] or 'unknown'}`",
        f"- first seen in snapshot: **{'yes' if contributor['first_seen_in_snapshot'] else 'no'}**",
        f"- repo association: **{contributor.get('repo_association') or 'unknown'}**",
        f"- repo primary artifacts: **{contributor['repo_primary_artifact_count']}**",
        f"- snapshot authored PRs/issues: **{contributor['snapshot_pr_count']} PRs / {contributor['snapshot_issue_count']} issues**",
        f"- snapshot discussion activity: **{contributor['snapshot_comment_count']} comments / {contributor['snapshot_review_count']} reviews / {contributor['snapshot_review_comment_count']} review comments**",
        f"- account age: **{_display_int(contributor['account_age_days'])} days**",
        (
            "- recent public PR activity: "
            f"**{_display_int(activity.get('visible_authored_pr_count'))} PRs** "
            f"({_display_int(activity.get('merged_pr_count'))} merged / "
            f"{_display_int(activity.get('closed_unmerged_pr_count'))} closed-unmerged / "
            f"{_display_int(activity.get('open_pr_count'))} open; "
            f"merged rate **{_display_rate(activity.get('merged_pr_rate'))}**, "
            f"closed-unmerged rate **{_display_rate(activity.get('closed_unmerged_pr_rate'))}**, "
            f"open rate **{_display_rate(activity.get('still_open_pr_rate'))}**)"
        ),
        f"- public orgs: {orgs}",
        f"- compact scores: follow-through **{contributor['follow_through_score']}**, breadth **{contributor['breadth_score']}**, automation risk **{contributor['automation_risk_signal']}**",
        f"- heuristic read: **{contributor['heuristic_note']}**",
    ]
    if contributor.get("fetch_error"):
        lines.append(f"- enrichment fetch error: `{contributor['fetch_error']}`")
    lines.extend(["", "Example artifacts:"])
    examples = contributor["examples"]["pull_requests"] + contributor["examples"]["issues"]
    if not examples:
        lines.append("- none")
    for example in examples:
        prefix = "PR" if example["kind"] == "pull_request" else "Issue"
        suffix_parts = [str(example["state"] or "unknown")]
        if example["kind"] == "pull_request" and example.get("merged"):
            suffix_parts.append("merged")
        if example["kind"] == "pull_request" and example.get("draft"):
            suffix_parts.append("draft")
        lines.append(
            f"- [{prefix} #{example['number']}: {example['title']}]({example['url']})"
            f" — {', '.join(suffix_parts)}"
        )
    lines.append("")
    return lines


def _legacy_summarize_user(login: str, days: int, repo: str | None) -> dict[str, Any]:
    now = datetime.now(tz=UTC)
    start = (now - timedelta(days=days)).replace(microsecond=0)
    from_iso = start.isoformat().replace("+00:00", "Z")
    from_date = start.date().isoformat()
    to_iso = now.replace(microsecond=0).isoformat().replace("+00:00", "Z")
    profile = _post_graphql(PROFILE_QUERY, {"login": login, "from": from_iso, "to": to_iso})["user"]
    if profile is None:
        raise RuntimeError(f"unknown user {login!r}")
    contributions = profile["contributionsCollection"]
    calendar = contributions["contributionCalendar"]
    repo_term = f" repo:{repo}" if repo else ""
    pr_query = f"author:{login} is:pr created:>={from_date}{repo_term} sort:created-desc"
    open_pr_query = (
        f"author:{login} is:pr is:open created:>={from_date}{repo_term} sort:created-desc"
    )
    issue_query = f"author:{login} is:issue created:>={from_date}{repo_term} sort:created-desc"
    pr_count, prs = _search_all(pr_query, prs=True)
    open_pr_count, open_prs = _search_all(open_pr_query, prs=True)
    issue_count, issues = _search_all(issue_query, prs=False)
    merged_prs = [pr for pr in prs if pr.get("merged")]
    closed_unmerged_prs = [pr for pr in prs if pr.get("state") == "CLOSED" and not pr.get("merged")]
    still_open_prs = [pr for pr in prs if pr.get("state") == "OPEN"]
    pr_repos = sorted({pr["repository"]["nameWithOwner"] for pr in prs if pr.get("repository")})
    open_pr_repos = sorted(
        {pr["repository"]["nameWithOwner"] for pr in open_prs if pr.get("repository")}
    )
    starred = profile.get("starredRepositories") or {}
    starred_nodes = [row for row in starred.get("nodes") or [] if isinstance(row, dict)]
    non_self_starred = [
        row
        for row in starred_nodes
        if ((row.get("owner") or {}).get("login") or "").casefold() != login.casefold()
    ]
    created_at = datetime.fromisoformat(profile["createdAt"].replace("Z", "+00:00"))
    account_age_days = (now - created_at).days
    return {
        "login": profile["login"],
        "name": profile.get("name"),
        "repo_scope": repo,
        "window": {"days": days, "from": from_iso, "to": to_iso},
        "account": {"created_at": profile["createdAt"], "age_days": account_age_days},
        "activity": {
            "visible_contributions_total": calendar["totalContributions"],
            **_contribution_calendar_summary(calendar["weeks"]),
            "authored_issues": contributions["totalIssueContributions"],
            "authored_pull_requests": contributions["totalPullRequestContributions"],
            "visible_authored_issue_count": len(issues),
            "visible_authored_pr_count": len(prs),
            "search_authored_issue_count": issue_count,
            "search_authored_pr_count": pr_count,
            "search_open_pr_count": open_pr_count,
            "distinct_repos_with_authored_prs": len(pr_repos),
            "distinct_repos_with_open_prs": len(open_pr_repos),
            "open_pr_count": len(open_prs),
            "merged_pr_count": len(merged_prs),
            "closed_unmerged_pr_count": len(closed_unmerged_prs),
            "still_open_pr_count": len(still_open_prs),
            "merged_pr_rate": _rate(len(merged_prs), len(prs)),
            "closed_unmerged_pr_rate": _rate(len(closed_unmerged_prs), len(prs)),
            "still_open_pr_rate": _rate(len(still_open_prs), len(prs)),
        },
        "stars": {
            "starred_repositories_total": starred.get("totalCount"),
            "visible_non_self_starred_repositories": len(non_self_starred),
            "recent_pr_repo_star_distribution": _star_distribution(
                [int((pr.get("repository") or {}).get("stargazerCount") or 0) for pr in prs]
            ),
        },
        "organization_membership": {
            "public_orgs": _public_orgs(login),
        },
    }


def _has_single_repo_burst(
    summary: dict[str, Any] | None, *, repo_snapshot_pr_count: int | None
) -> bool:
    if not summary or repo_snapshot_pr_count is None:
        return False
    activity = summary["activity"]
    closed_rate = activity.get("closed_unmerged_pr_rate")
    repo_count = activity.get("distinct_repos_with_authored_prs")
    return (
        repo_snapshot_pr_count >= 25
        and closed_rate is not None
        and closed_rate >= 0.7
        and repo_count is not None
        and repo_count <= 2
    )


def activity_note(
    summary: dict[str, Any] | None, *, repo_snapshot_pr_count: int | None = None
) -> str:
    if not summary:
        return "summary unavailable"
    activity = summary["activity"]
    stars = summary["stars"]
    notes = []
    if summary["account"]["age_days"] < 90:
        notes.append("very new account")
    elif summary["account"]["age_days"] < 365:
        notes.append("young account")
    if _has_single_repo_burst(summary, repo_snapshot_pr_count=repo_snapshot_pr_count):
        notes.append("very high single-repo PR burst")
    if activity["visible_authored_pr_count"] >= 100:
        notes.append("extremely high recent PR volume")
    elif activity["visible_authored_pr_count"] >= 25:
        notes.append("high recent PR volume")
    if activity["distinct_repos_with_authored_prs"] >= 25:
        notes.append("very broad repo spread")
    elif activity["distinct_repos_with_authored_prs"] >= 10:
        notes.append("broad repo spread")
    if (
        activity["closed_unmerged_pr_rate"] is not None
        and activity["closed_unmerged_pr_rate"] >= 0.4
    ):
        notes.append("many recent closed-unmerged PRs")
    if activity["still_open_pr_rate"] is not None and activity["still_open_pr_rate"] >= 0.4:
        notes.append("high open PR share")
    if stars["visible_non_self_starred_repositories"] == 0:
        notes.append("no visible non-self stars")
    median = stars["recent_pr_repo_star_distribution"]["median"]
    if median is not None and median >= 10000:
        notes.append("targets high-star repos")
    return "; ".join(notes) or "—"


def score_follow_through(summary: dict[str, Any] | None) -> str:
    if not summary:
        return "n/a"
    activity = summary["activity"]
    rate = activity["merged_pr_rate"]
    if rate is None:
        return "n/a"
    if rate >= 0.7 and (activity["closed_unmerged_pr_rate"] or 0.0) <= 0.1:
        return "strong"
    if rate >= 0.35:
        return "mixed"
    return "weak"


def score_breadth(summary: dict[str, Any] | None) -> str:
    if not summary:
        return "n/a"
    repos = summary["activity"]["distinct_repos_with_authored_prs"]
    if repos >= 25:
        return "very high"
    if repos >= 10:
        return "high"
    if repos >= 4:
        return "moderate"
    return "low"


def automation_risk_score(
    summary: dict[str, Any] | None, *, repo_snapshot_pr_count: int | None = None
) -> int | None:
    if not summary:
        return None
    activity = summary["activity"]
    stars = summary["stars"]
    risk = 0
    if summary["account"]["age_days"] < 30:
        risk += 3
    elif summary["account"]["age_days"] < 180:
        risk += 2
    if activity["visible_authored_pr_count"] >= 200:
        risk += 3
    elif activity["visible_authored_pr_count"] >= 50:
        risk += 2
    if activity["distinct_repos_with_authored_prs"] >= 50:
        risk += 3
    elif activity["distinct_repos_with_authored_prs"] >= 15:
        risk += 2
    if (
        activity["closed_unmerged_pr_rate"] is not None
        and activity["closed_unmerged_pr_rate"] >= 0.4
    ):
        risk += 2
    if activity["still_open_pr_rate"] is not None and activity["still_open_pr_rate"] >= 0.4:
        risk += 2
    if stars["visible_non_self_starred_repositories"] == 0:
        risk += 1
    if _has_single_repo_burst(summary, repo_snapshot_pr_count=repo_snapshot_pr_count):
        risk = max(risk, 8)
    return risk


def score_automation_risk(
    summary: dict[str, Any] | None, *, repo_snapshot_pr_count: int | None = None
) -> str:
    risk = automation_risk_score(summary, repo_snapshot_pr_count=repo_snapshot_pr_count)
    if risk is None:
        return "n/a"
    if risk >= 8:
        return "high"
    if risk >= 4:
        return "medium"
    return "low"


def _post_graphql(query: str, variables: dict[str, Any]) -> dict[str, Any]:
    token = resolve_github_token()
    if not token:
        raise RuntimeError("missing GITHUB_TOKEN/GRAPHQL_TOKEN/GH_TOKEN")
    body = json.dumps({"query": query, "variables": variables}).encode()
    request = urllib.request.Request(
        GRAPHQL_URL,
        data=body,
        headers={
            "Authorization": f"bearer {token}",
            "User-Agent": "slop-farmer",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen_with_retry(
            request,
            timeout=120,
            log=_report_log,
            label="GitHub GraphQL contributor report",
        ) as response:
            payload = json.load(response)
    except urllib.error.HTTPError as exc:  # pragma: no cover - exercised only in live use
        detail = exc.read().decode("utf-8", "replace")
        raise RuntimeError(f"graphql request failed: {exc.code} {detail}") from exc
    errors = payload.get("errors") or []
    if errors:
        raise RuntimeError(json.dumps(errors))
    return payload["data"]


def _search_all(query: str, *, prs: bool) -> tuple[int, list[dict[str, Any]]]:
    nodes: list[dict[str, Any]] = []
    cursor: str | None = None
    issue_count = 0
    search_query = SEARCH_PRS_QUERY if prs else SEARCH_ISSUES_QUERY
    while True:
        data = _post_graphql(search_query, {"query": query, "cursor": cursor})
        search = data["search"]
        issue_count = search["issueCount"]
        nodes.extend(node for node in search["nodes"] if isinstance(node, dict))
        if not search["pageInfo"]["hasNextPage"] or len(nodes) >= 1000:
            break
        cursor = search["pageInfo"]["endCursor"]
    return issue_count, nodes


def _public_orgs(login: str) -> list[dict[str, Any]]:
    token = resolve_github_token()
    if not token:
        return []
    request = urllib.request.Request(
        f"https://api.github.com/users/{login}/orgs",
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": "slop-farmer",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    with urlopen_with_retry(
        request,
        timeout=120,
        log=_report_log,
        label=f"https://api.github.com/users/{login}/orgs",
    ) as response:  # pragma: no cover - exercised only in live use
        payload = json.load(response)
    if not isinstance(payload, list):
        return []
    return [
        {"login": row.get("login"), "name": row.get("name")}
        for row in payload
        if isinstance(row, dict) and row.get("login")
    ]


def _contribution_calendar_summary(weeks: list[dict[str, Any]]) -> dict[str, Any]:
    daily = [day for week in weeks for day in week["contributionDays"]]
    active_days = sum(1 for day in daily if day["contributionCount"] > 0)
    weekly = [sum(day["contributionCount"] for day in week["contributionDays"]) for week in weeks]
    return {
        "active_days": active_days,
        "weekly_totals": weekly,
    }


def _star_distribution(values: list[int]) -> dict[str, Any]:
    if not values:
        return {
            "count": 0,
            "min": None,
            "median": None,
            "max": None,
        }
    ordered = sorted(values)
    mid = len(ordered) // 2
    median = ordered[mid] if len(ordered) % 2 else round((ordered[mid - 1] + ordered[mid]) / 2, 1)
    return {
        "count": len(values),
        "min": min(values),
        "median": median,
        "max": max(values),
    }


def _rate(numerator: int, denominator: int) -> float | None:
    if denominator == 0:
        return None
    return round(numerator / denominator, 4)


def _profile_url(login: str) -> str:
    return f"https://github.com/{login}"


def _repo_search_url(repo: str, login: str, *, is_pr: bool) -> str:
    path = "pulls" if is_pr else "issues"
    query = f"is:{'pr' if is_pr else 'issue'} author:{login}"
    return f"https://github.com/{repo}/{path}?q={urllib.parse.quote_plus(query)}"


def _coerce_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _display_int(value: Any) -> str:
    number = _coerce_int(value)
    return str(number) if number is not None else "?"


def _display_rate(value: Any) -> str:
    if value is None:
        return "n/a"
    try:
        return f"{float(value):.0%}"
    except (TypeError, ValueError):
        return "n/a"


def _report_reason_label(value: str) -> str:
    if value == "first_seen_in_snapshot":
        return "first seen this snapshot"
    return value or "unknown"


def _snapshot_reference_time(snapshot: dict[str, Any]) -> datetime:
    snapshot_id = str(snapshot.get("snapshot_id") or "")
    try:
        return datetime.strptime(snapshot_id, "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
    except ValueError:
        pass
    manifest = snapshot.get("manifest") or {}
    extracted_at = manifest.get("extracted_at")
    if isinstance(extracted_at, str):
        parsed = _coerce_datetime(extracted_at)
        if parsed is not None:
            return parsed
    timestamps = [
        timestamp
        for row in snapshot.get("pull_requests", [])
        for timestamp in (
            _coerce_datetime(row.get("created_at")),
            _coerce_datetime(row.get("updated_at")),
        )
        if timestamp is not None
    ]
    return max(timestamps, default=datetime.now(tz=UTC))


def _coerce_datetime(value: Any) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _track_repo_association(row: dict[str, Any], value: Any) -> None:
    if not value:
        return
    row["repo_association_values"].add(str(value))


def _select_repo_association(values: list[str]) -> str | None:
    if not values:
        return None
    priority = {
        "OWNER": 70,
        "MEMBER": 60,
        "COLLABORATOR": 50,
        "CONTRIBUTOR": 40,
        "FIRST_TIME_CONTRIBUTOR": 30,
        "FIRST_TIMER": 20,
        "NONE": 10,
    }
    return max(values, key=lambda value: (priority.get(value, 0), value))


def _iso_now() -> str:
    return datetime.now(tz=UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _report_log(message: str) -> None:
    stamp = datetime.now(tz=UTC).strftime("%H:%M:%SZ")
    print(f"[{stamp}] {message}", flush=True)
