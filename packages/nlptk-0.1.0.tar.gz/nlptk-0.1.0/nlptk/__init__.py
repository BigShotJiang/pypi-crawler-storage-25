"""nlpk - NLP Lab Programs"""

import os

_NOTEBOOKS_DIR = os.path.join(os.path.dirname(__file__), "notebooks")

NOTEBOOKS = {
    "expt2_collocations": "expt2_collocations.ipynb",
    "expt3_wsd": "expt3_wsd.ipynb",
    "expt4_hindle_rooth": "expt4_hindle_rooth.ipynb",
    "expt5_hmm_backward": "expt5_hmm_backward.ipynb",
    "expt5_hmm_forward": "expt5_hmm_forward.ipynb",
    "expt6_viterbi": "expt6_viterbi.ipynb",
    "expt8_bow_tfidf": "expt8_bow_tfidf.ipynb",
    "expt9_w2v": "expt9_w2v.ipynb",
    "expt10_lstm": "expt10_lstm.ipynb",
    "expt11_rnn_mt": "expt11_rnn_mt.ipynb",
}


def get_notebook_path(name):
    """Return the absolute path to a notebook by key name."""
    filename = NOTEBOOKS.get(name)
    if filename is None:
        raise KeyError(f"Unknown notebook '{name}'. Available: {list(NOTEBOOKS)}")
    return os.path.join(_NOTEBOOKS_DIR, filename)


def list_notebooks():
    """Print all available notebook names."""
    for key, fname in NOTEBOOKS.items():
        print(f"  {key}: {fname}")
