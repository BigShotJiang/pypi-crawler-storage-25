"""jdcodec — thin Python wrapper that delegates to the JD Codec connector.

``pip install jdcodec`` ships only this shim. Two surfaces:

  * ``jdcodec`` (no args, or with MCP-proxy args) → fetches and runs the
    npm ``jdcodec`` package via ``npx``. That binary is the MCP stdio
    server. Pin the connector version with ``JDC_CONNECTOR_VERSION``
    (e.g. ``JDC_CONNECTOR_VERSION=0.3.1``).
  * ``jdcodec start`` / ``jdcodec login`` / ``jdcodec audit`` → invokes
    the local Python onboarding auth + environment-audit flow.

Design boundary: connector operations delegate to npx; onboarding
operations (which are Python-only and live in this package) stay local."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys

# Subcommands handled by the local onboarding audit script.
# Anything not in this set delegates to ``npx jdcodec ...`` unchanged.
_ONBOARDING_COMMANDS = frozenset({"start", "login", "audit"})


def _resolve_npx() -> str:
    npx = shutil.which("npx")
    if npx:
        return npx
    sys.stderr.write(
        "jdcodec: Node.js (and `npx`) is required but was not found on PATH.\n"
        "        The Python `jdcodec` package is a thin wrapper around the\n"
        "        TypeScript connector, which runs on Node 22+. Install Node\n"
        "        from https://nodejs.org/ (or `brew install node` on macOS,\n"
        "        `apt install nodejs npm` on Debian/Ubuntu) and retry.\n"
    )
    sys.exit(127)


def main() -> int:
    args = sys.argv[1:]

    if args and args[0] in _ONBOARDING_COMMANDS:
        # Onboarding surface: dispatch locally to audit.main(). Imported
        # lazily so the connector path doesn't pay for `rich` / `requests`
        # import time on every invocation.
        from . import audit
        result = audit.main()
        return result if isinstance(result, int) else 0

    npx = _resolve_npx()
    version = os.environ.get("JDC_CONNECTOR_VERSION", "").strip()
    pkg_spec = f"jdcodec@{version}" if version else "jdcodec"
    cmd = [npx, "--yes", pkg_spec, *args]
    try:
        return subprocess.run(cmd).returncode
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
