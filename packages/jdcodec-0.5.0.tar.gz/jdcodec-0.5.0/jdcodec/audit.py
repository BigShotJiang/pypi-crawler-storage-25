import hashlib
import json
import os
import platform
import random
import sys
import time
import uuid
import webbrowser
import requests
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.theme import Theme

from . import __version__

# Set up UI theme
custom_theme = Theme({
    "info": "cyan",
    "warning": "yellow",
    "danger": "bold red",
    "success": "green",
})
console = Console(theme=custom_theme)

API_BASE = "https://jdcodec.com/api"

MACHINE_ID_PATH = os.path.expanduser("~/.jdcodec/machine-id")


def stable_machine_id() -> str:
    """Return a stable per-machine id, persisted on first run.

    Read from ``~/.jdcodec/machine-id`` if present. Otherwise derive from
    ``platform.node()`` + ``uuid.getnode()``, hash, persist (mode 0600), and
    return. Persisting matters because ``uuid.getnode()`` falls back to a
    random 48-bit value when the platform's MAC lookup fails — without the
    file, that re-randomisation would defeat dedup on the affected systems.

    Cross-platform: ``platform.node()`` and ``uuid.getnode()`` work on
    macOS / Linux / Windows; ``os.chmod(..., 0o600)`` is a no-op on Windows
    (silently ignored), which is acceptable since the file content is not
    secret — it's a stable telemetry id, not a credential.
    """
    if os.path.exists(MACHINE_ID_PATH):
        try:
            mid = open(MACHINE_ID_PATH).read().strip()
            if mid:
                return mid
        except OSError:
            pass

    seed = f"{platform.node()}|{uuid.getnode()}".encode()
    mid = "py-node-" + hashlib.sha256(seed).hexdigest()[:12]

    try:
        os.makedirs(os.path.dirname(MACHINE_ID_PATH), exist_ok=True)
        with open(MACHINE_ID_PATH, "w") as f:
            f.write(mid)
        try:
            os.chmod(MACHINE_ID_PATH, 0o600)
        except OSError:
            pass
    except OSError:
        # Read-only home / sandboxed env — fall back to in-process id. The
        # caller still gets a stable value within a single invocation.
        pass

    return mid

# Consent text shown in the CLI before browser-based OAuth captures the user's
# email. Wording matches the web waitlist form so the CLI flow has the same
# legal posture. The server-side completion handler records the same wording
# alongside the email at OAuth completion time.
CONSENT_TEXT = (
    "By continuing, you agree to receive JD Codec waitlist and early-access "
    "emails. Unsubscribe anytime via the link in any email."
)

LOGO_ASCII = r"""       _
      / \
     //\ \
    //  \ \
         \ \
  // \\   \ \
 //  //    \ \
 =============
 JD CODEC   ==
 @ 2026"""

def main():
    args = sys.argv[1:]
    command = args[0] if args else "audit"

    if command in ["start", "login"]:
        run_login()
    elif command == "audit":
        run_audit()
    else:
        print_help()

def print_help():
    console.print(f"[info]{LOGO_ASCII}[/info]")
    console.print("\n[bold] JD Codec CLI[/bold]")
    console.print(" Just the deltas, nothing more.\n")
    console.print(" Commands:")
    console.print("  [info]start[/info]   Register your node and join the Private Alpha")
    console.print("  [info]audit[/info]   Analyze your local agent environment\n")
    console.print(" Usage:")
    console.print("  jdcodec start\n")

def run_login():
    console.print(f"[info]{LOGO_ASCII}[/info]")
    console.print("\n[bold info] 🔐 JD Codec Cloud Authentication[/bold info]\n")
    
    # Generate random session ID
    import string
    session_id = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
    auth_url = f"https://jdcodec.com/login?sid={session_id}"

    # 1. Register the session with the backend. machine_id is passed so
    # the server-side completion handler can link the OAuth-completed
    # contact row back to this machine's audit telemetry row (server
    # reads cli_auth_sessions.machine_id at completion time and writes
    # it onto the contact upsert). Without this the OAuth contact row
    # has machine_id: null even though the audit path persisted one.
    try:
        requests.post(
            f"{API_BASE}/auth/session",
            json={"session_id": session_id, "machine_id": stable_machine_id()},
            timeout=10,
        )
    except:
        pass # Continue even if creation fails

    console.print(" To authenticate your local node, please visit:")
    console.print(f"[cyan underline]{auth_url}[/cyan underline]\n")
    console.print(f"[dim] {CONSENT_TEXT}[/dim]\n")
    console.print("[dim] Press Enter to agree and open browser, or Ctrl+C to cancel...[/dim]")

    # Wait for keypress (Enter = explicit consent acknowledgement; Ctrl+C
    # exits before any email is captured server-side, so a non-consenting
    # user never has a contact row created).
    if sys.stdin.isatty():
        sys.stdin.read(1)

    console.print("[info]Opening browser...[/info]")
    webbrowser.open(auth_url)

    # 2. Poll for authentication completion
    email = None
    waitlist_pos = None
    POLL_INTERVAL = 2
    POLL_TIMEOUT = 300
    start_time = time.time()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task(description="Waiting for authentication...", total=None)

        while time.time() - start_time < POLL_TIMEOUT:
            try:
                res = requests.get(f"{API_BASE}/auth/session?sid={session_id}", timeout=5)
                data = res.json()
                if data.get("status") == "completed":
                    email = data.get("email")
                    waitlist_pos = data.get("waitlist_pos")
                    break
            except:
                pass
            time.sleep(POLL_INTERVAL)

    if email:
        machine_id = stable_machine_id()
        console.print("\n[bold success] ✅ NODE REGISTERED [/bold success]\n")
        if waitlist_pos is not None:
            console.print(f" Welcome — your waitlist position is [bold info]#{waitlist_pos}[/bold info]")
        console.print(f" Account:    [info]{email}[/info]")
        console.print(f" Machine ID: [white]{machine_id}[/white]\n")
        console.print("[dim]──────────────────────────────────────────────[/dim]")
        console.print(" Want to skip the queue?")
        console.print(" Reply to [info]hello@jdcodec.com[/info] with what you're building.")
        console.print(" We prioritize early users with concrete use cases.")
        console.print("[dim]──────────────────────────────────────────────[/dim]\n")
    else:
        console.print("[danger]Authentication timed out.[/danger]")
        console.print("[dim]Try again with: jdcodec start[/dim]\n")

def run_audit():
    console.print(f"[info]{LOGO_ASCII}[/info]")
    console.print(f"\n[bold info] 🚀 JD Codec v{__version__} initializing...[/bold info]\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        progress.add_task(description="Analyzing local agent environment...", total=None)
        
        audit_results = {
            "langchain": os.path.exists("requirements.txt") and "langchain" in open("requirements.txt").read(),
            "playwright": os.path.exists("requirements.txt") and "playwright" in open("requirements.txt").read(),
            "browser_use": os.path.exists("requirements.txt") and "browser-use" in open("requirements.txt").read(),
            "keys_found": 0
        }
        
        if os.environ.get("OPENAI_API_KEY"): audit_results["keys_found"] += 1
        if os.environ.get("ANTHROPIC_API_KEY"): audit_results["keys_found"] += 1
        
        time.sleep(1.0)

    # 3. Telemetry (Optional)
    try:
        requests.post(f"{API_BASE}/intent-logger", json={
            "machine_id": stable_machine_id(),
            "source": "pip",
            "audit_results": audit_results
        }, timeout=5)
    except:
        pass

    # Reporting
    if audit_results["playwright"] or audit_results["browser_use"]:
        console.print("[success] ✅ System Check: COMPATIBLE[/success]")
        console.print("[dim] Detected: Python Agent framework found.[/dim]\n")
    else:
        console.print("[warning] ⚠️ System Check: PARTIAL COMPATIBILITY[/warning]")
        console.print("[dim] Note: No active Python agent framework detected in current directory.[/dim]\n")

    # Surface the Machine ID so users hitting support pre-OAuth (no email
    # captured yet) have an identifier they can quote — same value the
    # intent-logger POST persisted to contact.machine_id above.
    console.print(f" Machine ID: [white]{stable_machine_id()}[/white]\n")
    console.print("To finish registration and join the Alpha, run:")
    console.print("[bold info] jdcodec start[/bold info]\n")

if __name__ == "__main__":
    main()
