"""Regression tests for BUG-004 (jdcodec start broken post-PROD-027).

Pre-PROD-027, ``pip install jdcodec`` shipped a single console_script that
dispatched on argv[1] (``start`` / ``login`` / ``audit``) and triggered the
Python painted-door auth flow. PROD-027 split into two scripts:

  * ``jdcodec`` (jdcodec/cli.py)  → shells to ``npx jdcodec`` (MCP proxy)
  * ``jdcodec-audit`` (jdcodec/audit.py) → painted-door subcommand dispatcher

But ``audit.py:54`` and ``audit.py:159`` still print ``jdcodec start`` (without
the ``-audit`` suffix) as the recommended next step. So users following the
audit's own instructions ran a command that silently launched the MCP proxy
with ``start`` as a no-op argv string instead of triggering OAuth — the
conversion funnel from audit-ping to email signup was broken from the moment
PROD-027 shipped until BUG-004 lands.

These tests pin three guarantees:

  1. ``jdcodec start`` / ``login`` / ``audit`` dispatch to ``audit.main()``
     and DO NOT shell to npx.
  2. ``jdcodec`` with no args (or with non-painted-door args) DOES shell to
     ``npx jdcodec ...``.
  3. ``JDC_CONNECTOR_VERSION`` pinning still works for the npx path and is
     NOT applied to the painted-door dispatch (audit calls jdcodec.com APIs
     directly, not via npm).

Run with: ``python3 -m pytest tests/ -v`` from the package directory.
"""

from __future__ import annotations

import sys
import unittest
from unittest import mock


class CliDispatchTests(unittest.TestCase):
    """``jdcodec.cli.main()`` must route painted-door subcommands locally
    and everything else through ``npx``."""

    def _run(self, argv, env=None, audit_returns=None):
        """Invoke cli.main() with mocked argv + env + audit + subprocess.

        Returns a dict of probe values describing what cli.main did.
        """
        from jdcodec import cli  # imported inside test for clean reload semantics

        probe = {"audit_called": False, "subprocess_cmd": None}

        def fake_audit_main():
            probe["audit_called"] = True
            return audit_returns

        fake_audit_module = mock.MagicMock()
        fake_audit_module.main = fake_audit_main

        def fake_subprocess_run(cmd, *args, **kwargs):
            probe["subprocess_cmd"] = list(cmd)
            result = mock.MagicMock()
            result.returncode = 0
            return result

        with mock.patch.dict("sys.modules", {"jdcodec.audit": fake_audit_module}):
            with mock.patch.object(sys, "argv", ["jdcodec", *argv]):
                with mock.patch.dict("os.environ", env or {}, clear=False):
                    with mock.patch("jdcodec.cli.subprocess.run", side_effect=fake_subprocess_run):
                        with mock.patch("jdcodec.cli.shutil.which", return_value="/usr/local/bin/npx"):
                            rc = cli.main()
        return rc, probe

    # --- BUG-004 regression: painted-door dispatch ---

    def test_jdcodec_start_dispatches_to_audit(self):
        rc, probe = self._run(["start"])
        self.assertTrue(probe["audit_called"], "start must dispatch to audit.main()")
        self.assertIsNone(probe["subprocess_cmd"], "start must NOT shell to npx")
        self.assertEqual(rc, 0)

    def test_jdcodec_login_dispatches_to_audit(self):
        rc, probe = self._run(["login"])
        self.assertTrue(probe["audit_called"], "login must dispatch to audit.main()")
        self.assertIsNone(probe["subprocess_cmd"], "login must NOT shell to npx")
        self.assertEqual(rc, 0)

    def test_jdcodec_audit_dispatches_to_audit(self):
        rc, probe = self._run(["audit"])
        self.assertTrue(probe["audit_called"], "audit must dispatch to audit.main()")
        self.assertIsNone(probe["subprocess_cmd"], "audit must NOT shell to npx")

    def test_painted_door_returns_int_when_audit_returns_none(self):
        # audit.main() returns None today; the wrapper must coerce to 0 so
        # the OS exit code is well-formed.
        rc, _probe = self._run(["start"], audit_returns=None)
        self.assertEqual(rc, 0)

    def test_painted_door_propagates_audit_int_return(self):
        rc, _probe = self._run(["start"], audit_returns=42)
        self.assertEqual(rc, 42)

    # --- npx delegation path (unchanged behaviour) ---

    def test_no_args_shells_to_npx_jdcodec(self):
        _rc, probe = self._run([])
        self.assertFalse(probe["audit_called"], "no-args invocation must NOT call audit.main()")
        self.assertIsNotNone(probe["subprocess_cmd"], "no-args invocation must shell to npx")
        self.assertIn("jdcodec", probe["subprocess_cmd"])
        self.assertIn("--yes", probe["subprocess_cmd"])
        self.assertNotIn("start", probe["subprocess_cmd"])

    def test_unknown_subcommand_shells_to_npx_unchanged(self):
        # Anything not in the painted-door allow-list must pass through to
        # npx exactly as today (e.g. future connector subcommands).
        _rc, probe = self._run(["--version"])
        self.assertFalse(probe["audit_called"])
        self.assertIsNotNone(probe["subprocess_cmd"])
        self.assertIn("--version", probe["subprocess_cmd"])

    def test_jdc_connector_version_pins_npx_spec_only(self):
        _rc, probe = self._run([], env={"JDC_CONNECTOR_VERSION": "0.3.1"})
        self.assertIsNotNone(probe["subprocess_cmd"])
        self.assertIn("jdcodec@0.3.1", probe["subprocess_cmd"])

    def test_jdc_connector_version_does_not_affect_painted_door(self):
        # Painted-door subcommands should never touch npx, regardless of
        # JDC_CONNECTOR_VERSION (which only governs the connector pin).
        _rc, probe = self._run(["start"], env={"JDC_CONNECTOR_VERSION": "0.3.1"})
        self.assertTrue(probe["audit_called"])
        self.assertIsNone(probe["subprocess_cmd"])


if __name__ == "__main__":
    unittest.main()
