"""PROD-029 PR-B regression tests for audit.py display + machine_id capture.

Three guarantees this PR shipped that future changes shouldn't regress:

  1. Version banner reads from ``__version__``, not a hardcoded literal.
  2. The session-create POST to ``/api/auth/session`` includes the stable
     ``machine_id`` so the OAuth-completed contact row gets it linked
     (closes the gap surfaced by BUG-006 verification: pip-side OAuth row
     had ``machine_id: null``).
  3. The post-OAuth display shows the unified block (welcome + position +
     account + machine ID + skip-the-queue CTA) — and crucially, no random
     ``jdc-node-<random>`` cosmetic suffix that doesn't match the
     persisted ``~/.jdcodec/machine-id``.

Run with: ``python3 -m pytest tests/test_audit_display.py -v`` from the
package directory.
"""

from __future__ import annotations

import io
import sys
import tempfile
import unittest
from unittest import mock


class _NoopProgress:
    """Drop-in replacement for ``rich.progress.Progress`` in tests.

    The real Progress class spawns a render thread for the spinner that
    can block test exit when console.print is mocked. This stand-in
    satisfies the ``with Progress(...) as progress: progress.add_task(...)``
    contract without any threading.
    """

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def add_task(self, *args, **kwargs):
        return 0


class VersionBannerTests(unittest.TestCase):
    """Banner must reflect the installed version, not a hardcoded string."""

    def test_audit_banner_uses_dunder_version(self):
        from jdcodec import audit, __version__

        # Capture rich console output by patching console.print to record.
        # Progress is mocked to a no-op context manager so the spinner
        # thread doesn't block test exit.
        captured = []
        with mock.patch.object(audit.console, "print", side_effect=lambda *a, **kw: captured.append(" ".join(str(x) for x in a))), \
             mock.patch.object(audit, "Progress", new=lambda *a, **kw: _NoopProgress()), \
             mock.patch.object(audit.requests, "post"), \
             mock.patch("jdcodec.audit.time.sleep"):
            audit.run_audit()

        banner_lines = [line for line in captured if "initializing" in line]
        self.assertTrue(banner_lines, "expected a banner line containing 'initializing'")
        self.assertIn(f"v{__version__}", banner_lines[0],
                      f"banner must include actual __version__ ({__version__}), got: {banner_lines[0]}")
        self.assertNotIn("v0.1.0-alpha", banner_lines[0],
                         "hardcoded v0.1.0-alpha banner must be gone")


class MachineIdCaptureTests(unittest.TestCase):
    """run_login() must POST machine_id at session-create time so the
    OAuth-completed contact row gets it linked back to the audit telemetry."""

    def test_session_create_post_includes_machine_id(self):
        from jdcodec import audit

        captured = {"post_calls": []}

        def fake_post(url, **kwargs):
            captured["post_calls"].append({"url": url, "json": kwargs.get("json")})
            res = mock.MagicMock()
            res.json.return_value = {}
            res.ok = True
            return res

        def fake_get(url, **kwargs):
            res = mock.MagicMock()
            # Return a completed session immediately so polling exits fast.
            res.json.return_value = {
                "status": "completed",
                "email": "test@example.com",
                "waitlist_pos": 38,
            }
            return res

        # Avoid actually opening the browser, sleeping, or reading stdin.
        # Progress is mocked so the spinner thread doesn't block test exit.
        with mock.patch.object(audit.requests, "post", side_effect=fake_post), \
             mock.patch.object(audit.requests, "get", side_effect=fake_get), \
             mock.patch.object(audit.webbrowser, "open"), \
             mock.patch.object(audit.time, "sleep"), \
             mock.patch.object(audit.sys.stdin, "isatty", return_value=False), \
             mock.patch.object(audit, "Progress", new=lambda *a, **kw: _NoopProgress()), \
             mock.patch.object(audit.console, "print"):
            audit.run_login()

        # First POST is the session-create call.
        self.assertGreaterEqual(len(captured["post_calls"]), 1)
        create_call = captured["post_calls"][0]
        self.assertIn("/auth/session", create_call["url"])
        body = create_call["json"]
        self.assertIn("session_id", body)
        self.assertIn("machine_id", body, "session-create POST must include machine_id")
        self.assertTrue(
            body["machine_id"].startswith("py-node-"),
            f"machine_id should match stable_machine_id() format, got: {body['machine_id']}"
        )


class PostOAuthDisplayTests(unittest.TestCase):
    """The post-OAuth output must include the unified display block:
    welcome + position + account + machine_id + skip-the-queue CTA. The
    legacy 'Node ID: jdc-node-<random>' line must be gone."""

    def _run_login_capturing_print(self, poll_response):
        """Run run_login() with a mocked poll response and return the
        concatenated console output."""
        from jdcodec import audit

        captured = []

        def fake_post(*args, **kwargs):
            res = mock.MagicMock()
            res.json.return_value = {}
            return res

        def fake_get(*args, **kwargs):
            res = mock.MagicMock()
            res.json.return_value = poll_response
            return res

        with mock.patch.object(audit.requests, "post", side_effect=fake_post), \
             mock.patch.object(audit.requests, "get", side_effect=fake_get), \
             mock.patch.object(audit.webbrowser, "open"), \
             mock.patch.object(audit.time, "sleep"), \
             mock.patch.object(audit.sys.stdin, "isatty", return_value=False), \
             mock.patch.object(audit, "Progress", new=lambda *a, **kw: _NoopProgress()), \
             mock.patch.object(audit.console, "print", side_effect=lambda *a, **kw: captured.append(" ".join(str(x) for x in a))):
            audit.run_login()

        return "\n".join(captured)

    def test_post_oauth_includes_position_account_and_machine_id(self):
        out = self._run_login_capturing_print({
            "status": "completed",
            "email": "user@example.com",
            "waitlist_pos": 42,
        })
        self.assertIn("NODE REGISTERED", out)
        self.assertIn("waitlist position is", out)
        self.assertIn("#42", out)
        self.assertIn("user@example.com", out)
        self.assertIn("Machine ID:", out)
        self.assertIn("py-node-", out)

    def test_post_oauth_includes_skip_the_queue_cta(self):
        out = self._run_login_capturing_print({
            "status": "completed",
            "email": "user@example.com",
            "waitlist_pos": 42,
        })
        self.assertIn("skip the queue", out.lower())
        self.assertIn("hello@jdcodec.com", out)
        self.assertIn("what you're building", out)

    def test_post_oauth_omits_legacy_random_node_id(self):
        out = self._run_login_capturing_print({
            "status": "completed",
            "email": "user@example.com",
            "waitlist_pos": 42,
        })
        self.assertNotIn("Node ID:", out, "legacy cosmetic 'Node ID:' line must be gone")
        # The stable machine_id starts with `py-node-`; the legacy line
        # used `jdc-node-<6 random chars>`. Make sure we don't accidentally
        # print the legacy format alongside the new one.
        self.assertNotIn("jdc-node-", out, "legacy 'jdc-node-' suffix must not appear in post-OAuth output")

    def test_post_oauth_renders_without_position_when_server_omits_it(self):
        """If the server response is missing waitlist_pos (e.g. older
        deploy, transient lookup failure), the display must still render
        the rest of the block — position line is conditionally suppressed."""
        out = self._run_login_capturing_print({
            "status": "completed",
            "email": "user@example.com",
            # no waitlist_pos key
        })
        self.assertIn("NODE REGISTERED", out)
        self.assertIn("user@example.com", out)
        self.assertIn("Machine ID:", out)
        # No "#" + number combination (the position line should not appear).
        self.assertNotIn("waitlist position is", out)


class AuditDisplayTests(unittest.TestCase):
    """Audit-only path (no OAuth) must surface Machine ID as a support
    handle, since no email is captured on this path."""

    def test_audit_output_includes_machine_id(self):
        from jdcodec import audit

        captured = []
        with mock.patch.object(audit.requests, "post"), \
             mock.patch.object(audit.time, "sleep"), \
             mock.patch.object(audit, "Progress", new=lambda *a, **kw: _NoopProgress()), \
             mock.patch.object(audit.console, "print", side_effect=lambda *a, **kw: captured.append(" ".join(str(x) for x in a))):
            audit.run_audit()

        joined = "\n".join(captured)
        self.assertIn("Machine ID:", joined)
        self.assertIn("py-node-", joined)


if __name__ == "__main__":
    unittest.main()
