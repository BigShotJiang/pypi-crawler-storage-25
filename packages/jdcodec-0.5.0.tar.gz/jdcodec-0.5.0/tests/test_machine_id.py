"""Regression tests for BUG-003 (random machine_id inflates waitlist).

Pre-fix, ``audit.py`` posted ``"py-node-" + str(random.randint(1000, 9999))``
to the painted-door intent-logger on every invocation. The
``contact.machine_id`` UNIQUE constraint + ``Prefer: resolution=merge-duplicates``
header should have deduped re-runs, but with a fresh random id every run the
collision rate was 1/9000 — effectively zero — so each run inserted a new
row and waitlist counts were silently inflated.

These tests pin three guarantees:

  1. ``stable_machine_id()`` is stable across calls within a process when
     ``~/.jdcodec/machine-id`` is writable.
  2. The persisted file is created on first call, mode 0600 (POSIX), and
     the second call short-circuits to the cached value rather than
     re-deriving from ``platform.node()`` / ``uuid.getnode()``.
  3. When the file already exists with hand-edited content, that content
     wins — supports a user resetting the id by editing the file directly.

Run with: ``python3 -m pytest tests/test_machine_id.py -v`` from the
package directory.
"""

from __future__ import annotations

import os
import stat
import sys
import tempfile
import unittest
from unittest import mock


class StableMachineIdTests(unittest.TestCase):
    """``audit.stable_machine_id()`` must produce a stable, persisted id."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="jdc-bug003-")
        self.path = os.path.join(self.tmpdir, ".jdcodec", "machine-id")
        # Patch the module constant rather than monkeying with HOME — the
        # function reads MACHINE_ID_PATH directly, and patching at module
        # scope is the surface the function actually depends on.
        from jdcodec import audit
        self._patcher = mock.patch.object(audit, "MACHINE_ID_PATH", self.path)
        self._patcher.start()

    def tearDown(self):
        self._patcher.stop()
        # Best-effort cleanup; tests don't share the tmpdir, so a stale
        # leftover is benign.
        try:
            if os.path.exists(self.path):
                os.unlink(self.path)
            os.rmdir(os.path.dirname(self.path))
            os.rmdir(self.tmpdir)
        except OSError:
            pass

    def test_first_call_creates_file_and_returns_id(self):
        from jdcodec import audit
        self.assertFalse(os.path.exists(self.path))
        mid = audit.stable_machine_id()
        self.assertTrue(mid.startswith("py-node-"))
        # 8-char prefix + 12 hex chars = 20 chars total.
        self.assertEqual(len(mid), len("py-node-") + 12)
        self.assertTrue(os.path.exists(self.path))
        with open(self.path) as f:
            self.assertEqual(f.read().strip(), mid)

    def test_second_call_returns_same_id(self):
        from jdcodec import audit
        first = audit.stable_machine_id()
        second = audit.stable_machine_id()
        self.assertEqual(first, second)

    def test_persisted_id_survives_changing_node_inputs(self):
        """If the file exists, its contents win — even if platform.node()
        and uuid.getnode() would now return different values (e.g. on a
        system where uuid.getnode() falls back to a random 48-bit value
        per the Python docs). This is the whole reason we persist."""
        from jdcodec import audit

        # Seed the file with a hand-edited value.
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as f:
            f.write("py-node-handedited01")

        with mock.patch.object(audit, "platform") as fake_platform, \
             mock.patch.object(audit, "uuid") as fake_uuid:
            fake_platform.node.return_value = "different-host"
            fake_uuid.getnode.return_value = 0xDEADBEEFCAFE
            mid = audit.stable_machine_id()

        self.assertEqual(mid, "py-node-handedited01")

    def test_file_mode_is_0600_on_posix(self):
        from jdcodec import audit
        if sys.platform == "win32":
            self.skipTest("POSIX mode bits don't apply on Windows")
        audit.stable_machine_id()
        st = os.stat(self.path)
        # Owner-read + owner-write only.
        self.assertEqual(stat.S_IMODE(st.st_mode), 0o600)

    def test_empty_file_is_treated_as_uninitialised(self):
        """A zero-byte file (interrupted previous write) should not be
        returned as the id — re-derive and overwrite."""
        from jdcodec import audit
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        open(self.path, "w").close()
        mid = audit.stable_machine_id()
        self.assertTrue(mid.startswith("py-node-"))
        self.assertNotEqual(mid, "")
        with open(self.path) as f:
            self.assertEqual(f.read().strip(), mid)

    def test_id_is_deterministic_for_given_inputs(self):
        """Same node + uuid inputs must hash to the same id. Anchors the
        contract for anyone who later wants to derive the id server-side
        for cross-checks."""
        from jdcodec import audit
        with mock.patch.object(audit, "platform") as fake_platform, \
             mock.patch.object(audit, "uuid") as fake_uuid:
            fake_platform.node.return_value = "fixed-host"
            fake_uuid.getnode.return_value = 0x1122334455
            first = audit.stable_machine_id()

        # Wipe the persisted file so the next call re-derives.
        os.unlink(self.path)

        with mock.patch.object(audit, "platform") as fake_platform, \
             mock.patch.object(audit, "uuid") as fake_uuid:
            fake_platform.node.return_value = "fixed-host"
            fake_uuid.getnode.return_value = 0x1122334455
            second = audit.stable_machine_id()

        self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main()
