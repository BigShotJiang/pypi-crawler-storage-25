#!/usr/bin/env bash
# Publish-surface grep-gate for the pip wrapper (`packages/jdcodec-py/`).
#
# `pip install jdcodec` ships everything under `jdcodec/` to PyPI. This
# gate fails if internal-only terminology has leaked into that surface.
#
# Mirrors the connector's `packages/jdcodec-connector/scripts/grep-gate.sh`
# so the two public packages stay in lock-step. Banned categories:
#
#   1. Codec-internal terminology (parse_snapshot, parseSnapshot,
#      compactIframe, I-Frame, P-Frame, etc.) — Rule 0.
#   2. Internal product / methodology terms (painted door, pip wrapper).
#   3. Work-tracking IDs (PROD-/BUG-/FOPS-/GROW-/INFRA-/IN###).
#   4. Sibling-package paths inside this monorepo (packages/jdcodec-*,
#      server-ts/, spikes/, backlog/, internal_notes).
#   5. Legacy product name (DeltaVision / DV_).
#
# The canonical list lives in `scripts/audit/audit-patterns.json` at
# the monorepo root; that's the source of truth shared with the
# weekly post-publish audit. The regex below is a hand-built mirror —
# keep them in sync.
#
# Exit non-zero on any violation. Fast, no deps — works in any CI.

set -euo pipefail

cd "$(dirname "$0")/.."

# ---------------------------------------------------------------------------
# Banned regex (groups 1–5 above, ORed together).
# ---------------------------------------------------------------------------

CODEC_TERMS='parse_snapshot|parseSnapshot|diff_snapshots|diffSnapshots|compact_full|compactFull|compact_iframe|compactIframe|compact_pframe|compactPframe|CodecSessionState|snapshot_to_ref_map|I-Frame|P-Frame|i-frame|p-frame'

INTERNAL_TERMS='painted.?door|pip.wrapper|(PROD|FOPS|GROW|INFRA|BUG)-[0-9]+|\bIN[0-9]{3,}\b|packages/jdcodec-py|packages/jdcodec-py-internal|packages/jdcodec-cli|packages/jdcodec-connector|packages/jdcodec-schemas|server-ts/|spikes/|backlog/|internal_notes|deltavision|DV_|monorepo'

BANNED="(${CODEC_TERMS})|(${INTERNAL_TERMS})"

BAD=$(grep -rEn -i "$BANNED" jdcodec \
        --include='*.py' \
        --include='*.txt' \
        --include='*.md' \
        --include='*.json' \
        --include='*.toml' \
      2>/dev/null || true)

if [ -n "$BAD" ]; then
  echo "ERROR: grep-gate failed — pip wrapper source references internal-only terms." >&2
  echo "These belong in backlog/ tickets and internal docs, not the published wheel." >&2
  echo "Source of truth for the banned list: scripts/audit/audit-patterns.json (monorepo root)." >&2
  echo "" >&2
  echo "$BAD" >&2
  exit 1
fi

echo "OK: grep-gate passed — pip wrapper source is free of internal-only terminology."
