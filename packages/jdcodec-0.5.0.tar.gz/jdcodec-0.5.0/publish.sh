#!/bin/bash

# JD Codec Python Publishing Script
# Ensures build/twine are available and handles the upload safely.
#
# Strict mode: any failing command aborts the script. Without this,
# `twine upload` returning a 4xx (e.g. version already exists on PyPI)
# was silently swallowed and the script printed "✅ Done!" on a failed
# upload, masking the real outcome — the cause of the BUG-003 publish
# false-positive on 2026-04-29.

set -euo pipefail

echo "🚀 Starting JD Codec Python Publish..."

# 1. Ensure build tools are present
echo "🔍 Checking for build tools..."
python3 -m pip install build twine --break-system-packages --quiet

# 2. Cleanup old build artifacts
echo "🧹 Cleaning dist/ folder..."
rm -rf dist/
rm -rf *.egg-info

# 3. Build the package
echo "📦 Building $(grep -E '^version' pyproject.toml | head -1)..."
python3 -m build

# 4. Upload to PyPI
echo "⬆️ Uploading to PyPI..."
echo "------------------------------------------------"
echo "Username: __token__"
echo "Password: (Paste your pypi- token)"
echo "------------------------------------------------"

python3 -m twine upload dist/*

echo "✅ Done! Visit https://pypi.org/project/jdcodec/ to verify."
