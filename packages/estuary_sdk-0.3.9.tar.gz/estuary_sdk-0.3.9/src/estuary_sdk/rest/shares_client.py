from __future__ import annotations

from typing import Any, Optional

from estuary_sdk.rest.rest_client import RestClient


class SharesClient:
    """Client for the Estuary Shares REST API.

    Covers both share_anchors (long-lived redirectors for NFC/QR) and
    share_tokens (short-lived one-shot links).

    Base paths:
      - ``/api/v1/share-anchors``  — anchor family (5 endpoints)
      - ``/api/v1/share``          — token family (4 endpoints)

    Authentication matrix:
      - ``create_anchor``         — mixed auth. The SDK injects
        ``Authorization: Bearer {api_key}`` as a per-request header
        because the backend's ``_resolve_mixed_auth`` only reads the
        Bearer header and does not fall back to ``X-API-Key``.
      - ``open_anchor``           — unauthenticated.
      - ``exchange_share_token``  — unauthenticated.
      - All 7 other methods       — require a Firebase ID token on the
        backend. They are implemented for API completeness and will
        raise ``EstuaryError`` (HTTP 401) if called with only an
        ``est_`` API key. A future task will thread a first-class
        ``firebase_token`` through ``EstuaryConfig``.
    """

    def __init__(self, rest: RestClient) -> None:
        self._rest = rest
        self._anchors_base = "/api/v1/share-anchors"
        self._tokens_base = "/api/v1/share"

    # ── Share Anchors ──────────────────────────────────────────

    async def create_anchor(
        self,
        character_id: str,
        memory_sharing: str = "isolated",
        max_interactions: Optional[int] = None,
    ) -> dict[str, Any]:
        """Create a share anchor.

        Works with API key auth (injects Bearer header) or Firebase auth.

        Args:
            character_id: Owning character id.
            memory_sharing: ``"isolated"`` or ``"shared"``.
            max_interactions: Optional per-session interaction cap. When
                ``None``, the backend uses its default (no client-side
                cap sent).

        Returns:
            ``{"id": str, "anchorUrl": str}``.
        """
        body: dict[str, Any] = {
            "characterId": character_id,
            "memorySharing": memory_sharing,
        }
        if max_interactions is not None:
            body["maxInteractions"] = max_interactions
        # Per-request Bearer header workaround: backend _resolve_mixed_auth
        # reads Authorization: Bearer only, not X-API-Key (which RestClient
        # sets as a session default). See CONTEXT.md D-03 / RESEARCH.md §G1.
        headers = {"Authorization": f"Bearer {self._rest.api_key}"}
        return await self._rest.post(self._anchors_base, body=body, headers=headers)

    async def open_anchor(self, anchor_id: str) -> dict[str, Any]:
        """Redeem an anchor for a short-lived session token.

        Unauthenticated endpoint.

        Args:
            anchor_id: 32-char url-safe anchor id.

        Returns:
            ``{"sessionToken", "characterId", "playerId", "serverUrl",
            "character", "memorySharing"}``.
        """
        return await self._rest.post(f"{self._anchors_base}/{anchor_id}/open")

    async def list_anchors(
        self, character_id: Optional[str] = None
    ) -> dict[str, Any]:
        """List owned anchors, optionally filtered by character.

        Requires Firebase auth — will 401 with api_key only.

        Args:
            character_id: Optional filter. When ``None`` no filter is
                applied.

        Returns:
            ``{"anchors": [ShareAnchor.to_dict(), ...]}``.
        """
        params: Optional[dict[str, Any]] = None
        if character_id is not None:
            params = {"character_id": character_id}
        return await self._rest.get(self._anchors_base, params=params)

    async def revoke_anchor(self, anchor_id: str) -> dict[str, Any]:
        """Revoke a single anchor by id.

        Requires Firebase auth — will 401 with api_key only.

        Returns:
            ``{"revoked": bool, "killedSessions": int,
            "removedSessionBlobs": int}``.
        """
        return await self._rest.delete(f"{self._anchors_base}/{anchor_id}")

    async def bulk_revoke_anchors_by_api_key(
        self, api_key_id: str
    ) -> dict[str, Any]:
        """Bulk-revoke all anchors minted by a given api_key id.

        Requires Firebase auth — will 401 with api_key only.

        Args:
            api_key_id: UUID of the api_key whose anchors should be
                revoked.

        Returns:
            ``{"revoked": int, "killedSessions": int,
            "removedSessionBlobs": int}``.
        """
        return await self._rest.delete(
            f"{self._anchors_base}/by-api-key/{api_key_id}"
        )

    # ── Share Tokens ───────────────────────────────────────────

    async def create_share_token(
        self,
        character_id: str,
        ttl: str = "7d",
        memory_sharing: str = "isolated",
        max_exchanges: int = 5,
    ) -> dict[str, Any]:
        """Create a share token (short-lived one-shot link).

        Requires Firebase auth — will 401 with api_key only.

        Args:
            character_id: Owning character id.
            ttl: One of ``"24h" | "7d" | "30d" | "90d"``.
            memory_sharing: ``"isolated"`` or ``"shared"``.
            max_exchanges: Max redemptions (1-100).

        Returns:
            ``{"token": str, "shareUrl": str, "expiresAt": str}``.
        """
        body: dict[str, Any] = {
            "characterId": character_id,
            "ttl": ttl,
            "memorySharing": memory_sharing,
            "maxExchanges": max_exchanges,
        }
        return await self._rest.post(self._tokens_base, body=body)

    async def exchange_share_token(
        self, token: str, recipient_id: Optional[str] = None
    ) -> dict[str, Any]:
        """Exchange a share token for a session token.

        Unauthenticated endpoint. ``recipient_id`` is required when the
        underlying share is in isolated mode; for shared mode it may be
        omitted.

        Args:
            token: The share token string.
            recipient_id: Client-provided recipient identifier for
                isolated shares.

        Returns:
            ``{"sessionToken", "characterId", "playerId", "serverUrl",
            "character"}``. Note: unlike ``open_anchor``, the response
            does NOT include a top-level ``memorySharing`` field.
        """
        body: dict[str, Any] = {}
        if recipient_id is not None:
            body["recipientId"] = recipient_id
        return await self._rest.post(
            f"{self._tokens_base}/{token}/exchange", body=body
        )

    async def list_character_shares(
        self, character_id: str
    ) -> dict[str, Any]:
        """List active (non-revoked, non-expired) share tokens for a character.

        Requires Firebase auth — will 401 with api_key only.

        Returns:
            ``{"shares": [ShareToken.to_dict(), ...]}``.
        """
        return await self._rest.get(
            f"{self._tokens_base}/character/{character_id}"
        )

    async def revoke_share_token(
        self, share_token_id: str
    ) -> dict[str, Any]:
        """Revoke a share token by its DB row id (not the token string).

        Requires Firebase auth — will 401 with api_key only.

        Returns:
            ``{"revoked": bool, "killedSessions": int,
            "removedSessionBlobs": int}``.
        """
        return await self._rest.delete(f"{self._tokens_base}/{share_token_id}")
