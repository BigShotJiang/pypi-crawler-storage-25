# Copyright (c) Ralph Meijer.
# See LICENSE for details.

from twisted.application.service import ServiceMaker

TxXMPPComponentServer = ServiceMaker(
    "XMPP Component Server",
    "tx_xmpp.componentservertap",
    "An XMPP Component Server",
    "tx_xmpp-component-server",
)
