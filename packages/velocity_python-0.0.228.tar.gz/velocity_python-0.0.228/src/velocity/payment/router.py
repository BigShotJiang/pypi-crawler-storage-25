"""
Payment Processor Router

Routes payment processing requests to the appropriate processor adapter
based on client configuration and feature flags.

Selection Hierarchy:
1. Form-level override (form_builder_template.payment_processor_override)
2. Client-level selection (customers.payment_processor)
3. Platform default (sys_feature_flags.default_payment_processor)
"""

import os
from typing import Dict, Any, Optional
from .base_adapter import PaymentProcessorAdapter
from .stripe_adapter import StripeAdapter
from .braintree_adapter import BraintreeAdapter
from .profiles import money_to_cents

try:
    from .authorizenet_adapter import AuthorizeNetAdapter
except ImportError:
    AuthorizeNetAdapter = None


def get_processor_adapter(
    tx, client_id: str, form_sys_id: Optional[int] = None
) -> PaymentProcessorAdapter:
    """
    Get the appropriate payment processor adapter for a client/form.

    Selection logic follows hierarchy:
    1. Check form_builder_template.payment_processor_override (if form_sys_id provided)
    2. Check customers.payment_processor
    3. Fall back to sys_feature_flags.default_payment_processor

    Args:
        tx: velocity-python transaction object
        client_id: Client identifier
        form_sys_id: Optional form identifier for form-level overrides

    Returns:
        Configured PaymentProcessorAdapter instance (StripeAdapter or BraintreeAdapter)

    Raises:
        ValueError: If processor type is invalid or not enabled
        ProcessorError: If processor configuration is invalid
    """
    processor_type = _determine_processor_type(tx, client_id, form_sys_id)

    # Verify processor is enabled
    if not _is_processor_enabled(tx, processor_type):
        raise ValueError(
            f"Payment processor '{processor_type}' is not enabled in feature flags"
        )

    return _build_adapter(processor_type)


def _build_adapter(processor_type: str) -> PaymentProcessorAdapter:
    config = get_processor_config(processor_type)

    if processor_type == "stripe":
        return StripeAdapter(config)
    if processor_type == "braintree":
        return BraintreeAdapter(config)
    if processor_type in ("authorize_net", "authorize.net", "authorizenet"):
        if AuthorizeNetAdapter is None:
            raise ValueError(
                "AuthorizeNet SDK (authorizenet, xmltodict) is not installed"
            )
        return AuthorizeNetAdapter(config)
    raise ValueError(f"Unsupported payment processor type: {processor_type}")


def _determine_processor_type(
    tx, client_id: str, form_sys_id: Optional[int] = None
) -> str:
    """
    Determine which payment processor to use following configuration hierarchy.

    Returns:
        Processor type string ('stripe', 'braintree', etc.)
    """
    # 1. Check form-level override (most specific)
    if form_sys_id:
        form = tx.table("form_builder_template").find(form_sys_id)
        if form and form.get("payment_processor_override"):
            return form["payment_processor_override"].lower()

    # 2. Check client-level configuration
    customer = tx.table("customers").find_one({"client_id": client_id})
    if customer and customer.get("payment_processor"):
        return customer["payment_processor"].lower()

    # 3. Fall back to platform default
    branch = os.environ.get("USER_BRANCH", "demo")
    feature_flags = tx.table("sys_feature_flags").find_one({"applied_system": branch})

    if feature_flags and feature_flags.get("default_payment_processor"):
        return feature_flags["default_payment_processor"].lower()

    # 4. Ultimate fallback (should never reach here if feature flags are configured)
    return "braintree"


def _is_processor_enabled(tx, processor_type: str) -> bool:
    """
    Check if a payment processor is enabled in feature flags.

    Args:
        tx: velocity-python transaction object
        processor_type: Processor type string ('stripe', 'braintree', etc.)

    Returns:
        True if processor is enabled, False otherwise
    """
    branch = os.environ.get("USER_BRANCH", "demo")
    feature_flags = tx.table("sys_feature_flags").find_one({"applied_system": branch})

    if not feature_flags:
        # No feature flags found - default to braintree only
        return processor_type == "braintree"

    # Check processor-specific flag
    flag_name = f"{processor_type}_enabled"
    return feature_flags.get(flag_name, False)


def get_processor_config(processor_type: str) -> Dict[str, Any]:
    """
    Get configuration dictionary for a payment processor from environment variables.

    Args:
        processor_type: Processor type string ('stripe', 'braintree', etc.)

    Returns:
        Configuration dictionary with processor-specific keys

    Raises:
        ValueError: If required configuration is missing
    """
    if processor_type == "stripe":
        return _get_stripe_config()
    elif processor_type == "braintree":
        return _get_braintree_config()
    elif processor_type in ("authorize_net", "authorize.net", "authorizenet"):
        return _get_authorizenet_config()
    else:
        raise ValueError(f"Unknown processor type: {processor_type}")


def _get_stripe_config() -> Dict[str, Any]:
    """
    Get Stripe configuration from environment variables.

    Expected environment variables:
    - STRIPE_SECRET_KEY or StripeSecretKey
    - STRIPE_PUBLISHABLE_KEY or StripePublishableKey (optional)
    - STRIPE_WEBHOOK_SECRET (optional)
    - STRIPE_ENVIRONMENT or USER_BRANCH (test/live)

    Returns:
        Stripe configuration dictionary
    """
    api_key = os.environ.get("STRIPE_SECRET_KEY") or os.environ.get("StripeSecretKey")

    if not api_key:
        raise ValueError(
            "Stripe API key not found. Set STRIPE_SECRET_KEY or StripeSecretKey environment variable."
        )

    # Determine environment from key prefix or explicit setting
    environment = os.environ.get("STRIPE_ENVIRONMENT")
    if not environment:
        # Infer from key prefix (sk_test_ or sk_live_)
        environment = "test" if api_key.startswith("sk_test_") else "live"

    return {
        "api_key": api_key,
        "publishable_key": os.environ.get("STRIPE_PUBLISHABLE_KEY")
        or os.environ.get("StripePublishableKey"),
        "webhook_secret": os.environ.get("STRIPE_WEBHOOK_SECRET"),
        "environment": environment,
    }


def _get_braintree_config() -> Dict[str, Any]:
    """
    Get Braintree configuration from environment variables.

    Expected environment variables:
    - BRAINTREE_MERCHANT_ID or BraintreeMerchantId
    - BRAINTREE_PUBLIC_KEY or BraintreePublicKey
    - BRAINTREE_PRIVATE_KEY or BraintreePrivateKey
    - BRAINTREE_ENVIRONMENT (sandbox/production, default: sandbox)

    Returns:
        Braintree configuration dictionary
    """
    merchant_id = os.environ.get("BRAINTREE_MERCHANT_ID") or os.environ.get(
        "BraintreeMerchantId"
    )
    public_key = os.environ.get("BRAINTREE_PUBLIC_KEY") or os.environ.get(
        "BraintreePublicKey"
    )
    private_key = os.environ.get("BRAINTREE_PRIVATE_KEY") or os.environ.get(
        "BraintreePrivateKey"
    )

    if not all([merchant_id, public_key, private_key]):
        raise ValueError(
            "Braintree configuration incomplete. Required: "
            "BRAINTREE_MERCHANT_ID, BRAINTREE_PUBLIC_KEY, BRAINTREE_PRIVATE_KEY"
        )

    environment = os.environ.get("BRAINTREE_ENVIRONMENT", "sandbox")

    return {
        "merchant_id": merchant_id,
        "public_key": public_key,
        "private_key": private_key,
        "environment": environment,
    }


def _get_authorizenet_config() -> Dict[str, Any]:
    """
    Get Authorize.Net configuration from environment variables.

    Expected environment variables:
    - AN_API_LOGIN_ID or ANApiLoginId
    - AN_API_TRANSACTION_KEY or ANApiTransactionKey
    - AN_ENDPOINT or ANEndPoint (SDK endpoint URL)

    Returns:
        Authorize.Net configuration dictionary
    """
    api_login_id = os.environ.get("AN_API_LOGIN_ID") or os.environ.get("ANApiLoginId")
    api_transaction_key = os.environ.get("AN_API_TRANSACTION_KEY") or os.environ.get(
        "ANApiTransactionKey"
    )
    endpoint = os.environ.get("AN_ENDPOINT") or os.environ.get("ANEndPoint")

    if not all([api_login_id, api_transaction_key, endpoint]):
        raise ValueError(
            "Authorize.Net configuration incomplete. Required: "
            "AN_API_LOGIN_ID, AN_API_TRANSACTION_KEY, AN_ENDPOINT"
        )

    return {
        "api_login_id": api_login_id,
        "api_transaction_key": api_transaction_key,
        "endpoint": endpoint,
    }


def get_revenue_split_percentage(
    tx, client_id: str, form_sys_id: Optional[int] = None
) -> float:
    """
    Get applicable revenue split percentage following configuration hierarchy.

    Hierarchy:
    1. Form-level (form_builder_template.revenue_split_percentage)
    2. Client-level (customers.revenue_split_percentage)
    3. Platform default (sys_feature_flags.default_revenue_split_percentage)
    4. Hardcoded fallback (15.00)

    Args:
        tx: velocity-python transaction object
        client_id: Client identifier
        form_sys_id: Optional form identifier

    Returns:
        Revenue split percentage as float (e.g., 15.00 for 15%)
    """
    # 1. Try form-level (most specific)
    if form_sys_id:
        form = tx.table("form_builder_template").find(form_sys_id)
        if form and form.get("revenue_split_percentage") is not None:
            return float(form["revenue_split_percentage"])

    # 2. Try client-level
    customer = tx.table("customers").find_one({"client_id": client_id})
    if customer and customer.get("revenue_split_percentage") is not None:
        return float(customer["revenue_split_percentage"])

    # 3. Platform default from feature flags
    branch = os.environ.get("USER_BRANCH", "demo")
    feature_flags = tx.table("sys_feature_flags").find_one({"applied_system": branch})

    if (
        feature_flags
        and feature_flags.get("default_revenue_split_percentage") is not None
    ):
        return float(feature_flags["default_revenue_split_percentage"])

    # 4. Hardcoded fallback (should never reach here if setup ran correctly)
    return 15.00


def get_processor_account_id(
    tx, client_id: str, processor_type: Optional[str] = None
) -> Optional[str]:
    """
    Get the processor-specific account ID for a client.

    Args:
        tx: velocity-python transaction object
        client_id: Client identifier
        processor_type: Optional processor type (if None, uses routing logic)

    Returns:
        Processor account ID string, or None if not configured
    """
    if not processor_type:
        processor_type = _determine_processor_type(tx, client_id)

    payment_account = tx.table("client_payment_accounts").find_one(
        {"client_id": client_id, "processor_type": processor_type}
    )

    return payment_account["processor_account_id"] if payment_account else None


def charge_stored_payment_method(
    tx,
    client_id: str,
    payment_profile: Dict[str, Any],
    amount,
    *,
    donor_email: Optional[str] = None,
    donor_name: Optional[str] = None,
    description: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    processor_type: Optional[str] = None,
    descriptor: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Charge a stored payment profile using the routed processor adapter."""
    resolved_processor = processor_type or _determine_processor_type(tx, client_id)
    if not _is_processor_enabled(tx, resolved_processor):
        raise ValueError(
            f"Payment processor '{resolved_processor}' is not enabled in feature flags"
        )

    adapter = _build_adapter(resolved_processor)
    amount_cents = money_to_cents(amount)

    return adapter.charge_stored_payment_method(
        tx,
        {
            "amount": amount_cents,
            "currency": "usd",
            "payment_method": payment_profile["payment_profile_id"],
            "customer_profile_id": payment_profile.get("customer_profile_id"),
            "client_id": client_id,
            "processor_account_id": get_processor_account_id(
                tx, client_id, resolved_processor
            ),
            "revenue_split_percentage": get_revenue_split_percentage(tx, client_id),
            "donor_email": donor_email,
            "donor_name": donor_name,
            "description": description,
            "descriptor": descriptor,
            "metadata": metadata or {},
        },
    )


def get_or_create_customer_profile(
    tx, processor_type: str, customer_data: Dict[str, Any]
) -> Dict[str, Any]:
    """Get or create a vaulted processor customer profile."""
    if not _is_processor_enabled(tx, processor_type):
        raise ValueError(
            f"Payment processor '{processor_type}' is not enabled in feature flags"
        )
    adapter = _build_adapter(processor_type)
    return adapter.get_or_create_customer_profile(tx, customer_data)


def attach_payment_method(
    tx,
    processor_type: str,
    customer_profile_id: str,
    payment_method_id: str,
    payment_data: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Attach a payment method to a vaulted processor customer profile."""
    if not _is_processor_enabled(tx, processor_type):
        raise ValueError(
            f"Payment processor '{processor_type}' is not enabled in feature flags"
        )
    adapter = _build_adapter(processor_type)
    return adapter.attach_payment_method(
        tx, customer_profile_id, payment_method_id, payment_data
    )


def detach_payment_method(
    tx, processor_type: str, payment_method_id: str
) -> Dict[str, Any]:
    """Detach a payment method from a vaulted processor customer profile."""
    if not _is_processor_enabled(tx, processor_type):
        raise ValueError(
            f"Payment processor '{processor_type}' is not enabled in feature flags"
        )
    adapter = _build_adapter(processor_type)
    return adapter.detach_payment_method(tx, payment_method_id)


def delete_customer_profile(
    tx, processor_type: str, customer_profile_id: str
) -> Dict[str, Any]:
    """Delete a vaulted processor customer profile."""
    if not _is_processor_enabled(tx, processor_type):
        raise ValueError(
            f"Payment processor '{processor_type}' is not enabled in feature flags"
        )
    adapter = _build_adapter(processor_type)
    return adapter.delete_customer_profile(tx, customer_profile_id)


# ============================================================================
# UNIFIED ENTRY POINTS
# ============================================================================


def process_payment(
    tx,
    client_id: str,
    token: str,
    amount,
    *,
    payment_type: str = "card",
    device_data: Optional[str] = None,
    donor_email: Optional[str] = None,
    donor_name: Optional[str] = None,
    form_sys_id: Optional[int] = None,
    metadata: Optional[Dict[str, Any]] = None,
    capture: bool = False,
) -> Dict[str, Any]:
    """
    Single entry point for processing a payment from a frontend token.

    Resolves the correct processor adapter for the client/form, then delegates to
    ``adapter.authorize_payment()`` (or immediate charge when *capture* is True).

    This function is intended to replace direct SDK calls (e.g. ``btree.transaction.sale()``)
    scattered across Lambda handlers.  The caller receives a **uniform return dict** regardless
    of which processor is selected.

    Args:
        tx: velocity-python transaction object
        client_id: Client identifier (used for processor routing + revenue split)
        token: Payment token from the frontend PaymentCollector component.
               Braintree → nonce, Stripe → payment_method_id.
        amount: Amount to charge — dollars (str/Decimal/float) or cents (int).
                Converted to cents via ``money_to_cents`` when not already int.
        payment_type: One of 'card', 'paypal', 'venmo', 'apple_pay' (informational).
        device_data: Braintree Kount device data string (optional).
        donor_email: Donor email address (optional).
        donor_name: Donor full name (optional).
        form_sys_id: Form builder template sys_id for form-level overrides (optional).
        metadata: Additional key/value metadata forwarded to the processor (optional).
        capture: If True, submit for immediate settlement instead of pre-auth only.
                 Default is False (authorize, capture later).

    Returns:
        Standardised dict with at least:
            - processor_transaction_id: str
            - status: 'authorized' | 'captured' | 'failed'
            - amount: int (cents)
            - currency: str
            - processor: str ('stripe', 'braintree', ...)
            - error_message: str | None

    Raises:
        ValueError: If processor is not enabled or configuration is invalid.
        ProcessorError: If the processor rejects the payment.
    """
    adapter = get_processor_adapter(tx, client_id, form_sys_id)
    amount_cents = money_to_cents(amount)
    processor_account_id = get_processor_account_id(tx, client_id, adapter.processor_name)
    revenue_split = get_revenue_split_percentage(tx, client_id, form_sys_id)

    payment_data = {
        "amount": amount_cents,
        "currency": "usd",
        "payment_method": token,
        "client_id": client_id,
        "processor_account_id": processor_account_id,
        "revenue_split_percentage": revenue_split,
        "donor_email": donor_email,
        "donor_name": donor_name,
        "form_sys_id": form_sys_id,
        "device_data": device_data,
        "payment_type": payment_type,
        "metadata": metadata or {},
    }

    if capture:
        # For Braintree, submit_for_settlement is controlled inside the adapter.
        # For Stripe, capture_method is set inside the adapter.
        # We pass a hint so the adapter can act accordingly.
        payment_data["capture"] = True

    result = adapter.authorize_payment(tx, payment_data)
    result["processor"] = adapter.processor_name
    return result


def vault_payment_method(
    tx,
    client_id: str,
    token: str,
    customer_data: Dict[str, Any],
    *,
    form_sys_id: Optional[int] = None,
    processor_type: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Vault (save) a payment method for future use.

    Resolves the processor, ensures a customer profile exists, attaches the payment
    method, and returns a normalised result with ``payment_profile_id`` suitable for
    storing in the ``payment_profiles`` table.

    Args:
        tx: velocity-python transaction object
        client_id: Client identifier
        token: Payment method token from frontend PaymentCollector.
               Braintree → nonce, Stripe → payment_method_id.
        customer_data: Dict with at least:
            - email: str (required)
            - first_name: str (optional)
            - last_name: str (optional)
            - customer_id: str (optional — external customer id, e.g. md5 hash)
        form_sys_id: Optional form sys_id for processor routing overrides.
        processor_type: Explicit processor override (skips routing hierarchy).

    Returns:
        Dict with:
            - processor: str
            - customer_profile_id: str (processor's customer id)
            - payment_profile_id: str (processor's payment method id)
            - payment_method_type: str ('card', 'paypal', 'venmo', ...)
            - card_brand: str | None
            - card_last4: str | None
            - expiration_date: str | None ('YYYY-MM')
            - metadata: dict

    Raises:
        ValueError: If processor is not enabled.
        ProcessorError: If vaulting fails.
    """
    resolved = processor_type or _determine_processor_type(tx, client_id, form_sys_id)
    if not _is_processor_enabled(tx, resolved):
        raise ValueError(
            f"Payment processor '{resolved}' is not enabled in feature flags"
        )

    adapter = _build_adapter(resolved)

    # Step 1: ensure customer profile exists
    customer_result = adapter.get_or_create_customer_profile(tx, customer_data)
    customer_profile_id = customer_result.get(
        "customer_profile_id"
    ) or customer_result.get("customer_id")

    # Step 2: attach payment method to customer
    attach_result = adapter.attach_payment_method(
        tx, customer_profile_id, token, customer_data
    )

    # Step 3: normalise return
    return {
        "processor": resolved,
        "customer_profile_id": customer_profile_id,
        "payment_profile_id": attach_result.get("payment_method_id", token),
        "payment_method_type": attach_result.get("payment_method_type", "card"),
        "card_brand": attach_result.get("card_brand"),
        "card_last4": attach_result.get("card_last4"),
        "expiration_date": attach_result.get("expiration_date"),
        "metadata": attach_result.get("metadata", {}),
    }
