# AI Agent Detector

_This is a Python port of [pushpak1300](https://github.com/pushpak1300)'s PHP library [agent-detector](https://github.com/shipfastlabs/agent-detector)._

A small library to tell you if Python is run in the context of an AI agent.

## Installation

```bash
pip install ai-agent-detector
```

## Usage

```python
from ai_agent_detector import detect_agent
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ai_agent_detector import Result

result: Result = detect_agent()

result.is_agent # True
result.name # "codex"
result.is_known_agent # True
```

## Local installation

```bash
uv sync
```

### Testing

```bash
uv run mypy src
```

```bash
uv run pytest
```
