import os
from pathlib import Path

from ai_agent_detector.models import KnownAgent, Result


def _detect_custom_agent() -> Result | None:
    value = os.environ.get("AI_AGENT", "")
    value = value.strip()

    if not value:
        return None

    return Result(is_agent=True, name=value)


def _detect_known_agent() -> Result | None:
    for known_agent in KnownAgent:
        for env_var in known_agent.env_vars:
            value = os.environ.get(env_var)

            if value is not None:
                return Result(is_agent=True, name=known_agent.value)

    return None


def _has_devin_file() -> bool:
    p = Path("/opt/.devin")

    return p.is_file()


def _detect_devin_agent() -> Result | None:
    if not _has_devin_file():
        return None

    return Result(is_agent=True, name=KnownAgent.DEVIN.value)


def detect_agent() -> Result:
    custom_agent = _detect_custom_agent()
    if custom_agent:
        return custom_agent

    known_agent = _detect_known_agent()
    if known_agent:
        return known_agent

    devin_agent = _detect_devin_agent()
    if devin_agent:
        return devin_agent

    return Result(is_agent=False)
