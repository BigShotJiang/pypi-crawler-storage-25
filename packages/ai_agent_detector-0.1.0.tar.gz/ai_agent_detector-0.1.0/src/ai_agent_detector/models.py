from dataclasses import dataclass
from enum import Enum


class KnownAgent(Enum):
    AMP = "amp"
    ANTIGRAVITY = "antigravity"
    AUGMENTCLI = "augment-cli"
    CLAUDE = "claude"
    CODEX = "codex"
    COPILOT = "copilot"
    CURSOR = "cursor"
    DEVIN = "devin"
    GEMINI = "gemini"
    OPENCODE = "opencode"
    REPLIT = "replit"

    @property
    def env_vars(self) -> list[str]:
        match self:
            case KnownAgent.AMP:
                env_vars = ["AMP_CURRENT_THREAD_ID"]
            case KnownAgent.ANTIGRAVITY:
                env_vars = ["ANTIGRAVITY_AGENT"]
            case KnownAgent.AUGMENTCLI:
                env_vars = ["AUGMENT_AGENT"]
            case KnownAgent.CLAUDE:
                env_vars = ["CLAUDECODE", "CLAUDE_CODE"]
            case KnownAgent.CODEX:
                env_vars = ["CODEX_SANDBOX", "CODEX_THREAD_ID"]
            case KnownAgent.COPILOT:
                env_vars = ["COPILOT_CLI"]
            case KnownAgent.CURSOR:
                env_vars = ["CURSOR_AGENT"]
            # Devin doesn't use env vars
            case KnownAgent.DEVIN:
                env_vars = []
            case KnownAgent.GEMINI:
                env_vars = ["GEMINI_CLI"]
            case KnownAgent.OPENCODE:
                env_vars = ["OPENCODE_CLIENT", "OPENCODE"]
            case KnownAgent.REPLIT:
                env_vars = ["REPL_ID"]

        return env_vars


@dataclass
class Result:
    is_agent: bool
    name: str | None = None

    @property
    def is_known_agent(self) -> bool:
        try:
            _ = KnownAgent(self.name)

            return True
        except ValueError:
            return False
