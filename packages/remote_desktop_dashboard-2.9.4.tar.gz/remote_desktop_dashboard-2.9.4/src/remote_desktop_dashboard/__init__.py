"""Remote Desktop Dashboard — monitor and connect to machines via Windows App."""

__version__ = "2.9.4"
