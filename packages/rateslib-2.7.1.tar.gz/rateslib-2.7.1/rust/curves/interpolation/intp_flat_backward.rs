// SPDX-License-Identifier: LicenseRef-Rateslib-Dual
//
// Copyright (c) 2026 Siffrorna Technology Limited
// This code cannot be used or copied externally
//
// Dual-licensed: Free Educational Licence or Paid Commercial Licence (commercial/professional use)
// Source-available, not open source.
//
// See LICENSE and https://rateslib.com/py/en/latest/i_licence.html for details,
// and/or contact info (at) rateslib (dot) com
////////////////////////////////////////////////////////////////////////////////////////////////////

use crate::curves::nodes::NodesTimestamp;
use crate::curves::CurveInterpolation;
use crate::dual::Number;
use bincode::config::legacy;
use bincode::serde::{decode_from_slice, encode_to_vec};
use chrono::NaiveDateTime;
use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyTuple};
use pyo3::{pyclass, pymethods, Bound, PyResult, Python};
use serde::{Deserialize, Serialize};
use std::cmp::PartialEq;

/// Define flat backward interpolation of nodes.
#[pyclass(module = "rateslib.rs", from_py_object)]
#[derive(Clone, Debug, PartialEq, Deserialize, Serialize)]
pub struct FlatBackwardInterpolator {}

#[pymethods]
impl FlatBackwardInterpolator {
    #[new]
    pub fn new() -> Self {
        FlatBackwardInterpolator {}
    }

    // Pickling
    pub fn __setstate__(&mut self, state: Bound<'_, PyBytes>) -> PyResult<()> {
        *self = decode_from_slice(state.as_bytes(), legacy()).unwrap().0;
        Ok(())
    }
    pub fn __getstate__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyBytes>> {
        Ok(PyBytes::new(py, &encode_to_vec(&self, legacy()).unwrap()))
    }
    pub fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        Ok(PyTuple::empty(py))
    }
}

impl CurveInterpolation for FlatBackwardInterpolator {
    fn interpolated_value(&self, nodes: &NodesTimestamp, date: &NaiveDateTime) -> Number {
        let x = date.and_utc().timestamp();
        let index = self.node_index(nodes, x);
        macro_rules! interp {
            ($Variant: ident, $indexmap: expr) => {{
                let (x1, y1) = $indexmap.get_index(index).unwrap();
                let (_x2, y2) = $indexmap.get_index(index + 1_usize).unwrap();
                if x <= *x1 {
                    Number::$Variant(y1.clone())
                } else {
                    Number::$Variant(y2.clone())
                }
            }};
        }
        match nodes {
            NodesTimestamp::F64(m) => interp!(F64, m),
            NodesTimestamp::Dual(m) => interp!(Dual, m),
            NodesTimestamp::Dual2(m) => interp!(Dual2, m),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::curves::nodes::Nodes;
    use crate::scheduling::ndt;
    use indexmap::IndexMap;

    fn nodes_timestamp_fixture() -> NodesTimestamp {
        let nodes = Nodes::F64(IndexMap::from_iter(vec![
            (ndt(2000, 1, 1), 1.0_f64),
            (ndt(2001, 1, 1), 0.99_f64),
            (ndt(2002, 1, 1), 0.98_f64),
        ]));
        NodesTimestamp::from(nodes)
    }

    #[test]
    fn test_flat_backward() {
        let nts = nodes_timestamp_fixture();
        let li = FlatBackwardInterpolator::new();
        let result = li.interpolated_value(&nts, &ndt(2000, 7, 1));
        assert_eq!(result, Number::F64(0.99));
    }

    #[test]
    fn test_flat_backward_left_out_of_bounds() {
        let nts = nodes_timestamp_fixture();
        let li = FlatBackwardInterpolator::new();
        let result = li.interpolated_value(&nts, &ndt(1999, 7, 1));
        assert_eq!(result, Number::F64(1.0));
    }

    #[test]
    fn test_flat_backward_right_out_of_bounds() {
        let nts = nodes_timestamp_fixture();
        let li = FlatBackwardInterpolator::new();
        let result = li.interpolated_value(&nts, &ndt(2005, 7, 1));
        assert_eq!(result, Number::F64(0.98));
    }

    #[test]
    fn test_flat_backward_equals_interval_value() {
        let nts = nodes_timestamp_fixture();
        let li = FlatBackwardInterpolator::new();
        let result = li.interpolated_value(&nts, &ndt(2001, 1, 1));
        assert_eq!(result, Number::F64(0.99));
    }
}
