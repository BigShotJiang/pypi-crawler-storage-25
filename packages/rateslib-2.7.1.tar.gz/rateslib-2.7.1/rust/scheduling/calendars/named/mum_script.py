# SPDX-License-Identifier: LicenseRef-Rateslib-Dual
#
# Copyright (c) 2026 Siffrorna Technology Limited
#
# Dual-licensed: Free Educational Licence or Paid Commercial Licence (commercial/professional use)
# Source-available, not open source.
#
# See LICENSE and https://rateslib.com/py/en/latest/i_licence.html for details,
# and/or contact info (at) rateslib (dot) com
####################################################################################################

import pandas as pd
from pandas.tseries.holiday import (
    AbstractHolidayCalendar,
    Day,
    Easter,
    Holiday,
)
from pandas.tseries.offsets import CustomBusinessDay

RULES = [
    # Days defined by the national stock exchange
    Holiday("Republic Day", month=1, day=26),
    Holiday("Good Friday", month=1, day=1, offset=[Easter(), Day(-2)]),
    Holiday("Ambedkar Jayanti", month=4, day=14),
    Holiday("May Day", month=5, day=1),
    Holiday("Independence Day", month=8, day=15),
    Holiday("Gandhi Jayanti", month=10, day=2),
    Holiday("Christmas Day", month=12, day=25),
    # Additional Adhoc holidays identified from fixings publications
    Holiday("adhoc0", year=2019, month=2, day=19),
    Holiday("adhoc1", year=2019, month=3, day=4),
    Holiday("adhoc2", year=2019, month=3, day=21),
    Holiday("adhoc3", year=2019, month=4, day=1),
    Holiday("adhoc4", year=2019, month=4, day=17),
    Holiday("adhoc5", year=2019, month=4, day=29),
    Holiday("adhoc6", year=2019, month=6, day=5),
    Holiday("adhoc7", year=2019, month=8, day=12),
    Holiday("adhoc8", year=2019, month=9, day=2),
    Holiday("adhoc9", year=2019, month=9, day=10),
    Holiday("adhoc10", year=2019, month=10, day=8),
    Holiday("adhoc11", year=2019, month=10, day=21),
    Holiday("adhoc12", year=2019, month=10, day=28),
    Holiday("adhoc13", year=2019, month=11, day=12),
    Holiday("adhoc14", year=2020, month=2, day=19),
    Holiday("adhoc15", year=2020, month=2, day=21),
    Holiday("adhoc16", year=2020, month=3, day=10),
    Holiday("adhoc17", year=2020, month=3, day=25),
    Holiday("adhoc18", year=2020, month=4, day=1),
    Holiday("adhoc19", year=2020, month=4, day=2),
    Holiday("adhoc20", year=2020, month=4, day=6),
    Holiday("adhoc21", year=2020, month=5, day=7),
    Holiday("adhoc22", year=2020, month=5, day=25),
    Holiday("adhoc23", year=2020, month=10, day=30),
    Holiday("adhoc24", year=2020, month=11, day=16),
    Holiday("adhoc25", year=2020, month=11, day=30),
    Holiday("adhoc26", year=2021, month=2, day=19),
    Holiday("adhoc27", year=2021, month=3, day=11),
    Holiday("adhoc28", year=2021, month=3, day=29),
    Holiday("adhoc29", year=2021, month=4, day=1),
    Holiday("adhoc30", year=2021, month=4, day=13),
    Holiday("adhoc31", year=2021, month=4, day=21),
    Holiday("adhoc32", year=2021, month=5, day=13),
    Holiday("adhoc33", year=2021, month=5, day=26),
    Holiday("adhoc34", year=2021, month=7, day=21),
    Holiday("adhoc35", year=2021, month=8, day=16),
    Holiday("adhoc36", year=2021, month=8, day=19),
    Holiday("adhoc37", year=2021, month=9, day=10),
    Holiday("adhoc38", year=2021, month=10, day=15),
    Holiday("adhoc39", year=2021, month=10, day=19),
    Holiday("adhoc40", year=2021, month=11, day=4),
    Holiday("adhoc41", year=2021, month=11, day=5),
    Holiday("adhoc42", year=2021, month=11, day=19),
    Holiday("adhoc43", year=2022, month=2, day=7),
    Holiday("adhoc44", year=2022, month=3, day=1),
    Holiday("adhoc45", year=2022, month=3, day=18),
    Holiday("adhoc46", year=2022, month=4, day=1),
    Holiday("adhoc47", year=2022, month=5, day=3),
    Holiday("adhoc48", year=2022, month=5, day=16),
    Holiday("adhoc49", year=2022, month=8, day=9),
    Holiday("adhoc50", year=2022, month=8, day=16),
    Holiday("adhoc51", year=2022, month=8, day=31),
    Holiday("adhoc52", year=2022, month=10, day=5),
    Holiday("adhoc53", year=2022, month=10, day=24),
    Holiday("adhoc54", year=2022, month=10, day=26),
    Holiday("adhoc55", year=2022, month=11, day=8),
    Holiday("adhoc56", year=2023, month=3, day=7),
    Holiday("adhoc57", year=2023, month=3, day=22),
    Holiday("adhoc58", year=2023, month=3, day=30),
    Holiday("adhoc59", year=2023, month=4, day=4),
    Holiday("adhoc60", year=2023, month=5, day=5),
    Holiday("adhoc61", year=2023, month=6, day=29),
    Holiday("adhoc62", year=2023, month=8, day=16),
    Holiday("adhoc63", year=2023, month=9, day=19),
    Holiday("adhoc64", year=2023, month=10, day=24),
    Holiday("adhoc65", year=2023, month=11, day=14),
    Holiday("adhoc66", year=2023, month=11, day=27),
    Holiday("adhoc67", year=2024, month=1, day=22),
    Holiday("adhoc68", year=2024, month=2, day=19),
    Holiday("adhoc69", year=2024, month=3, day=8),
    Holiday("adhoc70", year=2024, month=3, day=25),
    Holiday("adhoc71", year=2024, month=4, day=1),
    Holiday("adhoc72", year=2024, month=4, day=9),
    Holiday("adhoc73", year=2024, month=4, day=11),
    Holiday("adhoc74", year=2024, month=4, day=17),
    Holiday("adhoc75", year=2024, month=5, day=20),
    Holiday("adhoc76", year=2024, month=5, day=23),
    Holiday("adhoc77", year=2024, month=6, day=17),
    Holiday("adhoc78", year=2024, month=7, day=17),
    Holiday("adhoc79", year=2024, month=9, day=18),
    Holiday("adhoc80", year=2024, month=11, day=1),
    Holiday("adhoc81", year=2024, month=11, day=15),
    Holiday("adhoc82", year=2024, month=11, day=20),
]

CALENDAR = CustomBusinessDay(
    calendar=AbstractHolidayCalendar(rules=RULES),
    weekmask="Mon Tue Wed Thu Fri",
)

### RUN THE SCRIPT TO EXPORT HOLIDAY LIST
ts = pd.to_datetime(CALENDAR.holidays)
strings = ['"' + _.strftime("%Y-%m-%d %H:%M:%S") + '"' for _ in ts]
line = ",\n".join(strings)
print(line)
