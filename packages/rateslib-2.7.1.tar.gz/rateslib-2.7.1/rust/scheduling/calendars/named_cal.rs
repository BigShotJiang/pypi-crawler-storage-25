// SPDX-License-Identifier: LicenseRef-Rateslib-Dual
//
// Copyright (c) 2026 Siffrorna Technology Limited
// This code cannot be used or copied externally
//
// Dual-licensed: Free Educational Licence or Paid Commercial Licence (commercial/professional use)
// Source-available, not open source.
//
// See LICENSE and https://rateslib.com/py/en/latest/i_licence.html for details,
// and/or contact info (at) rateslib (dot) com
////////////////////////////////////////////////////////////////////////////////////////////////////

use chrono::prelude::*;
use pyo3::exceptions::PyValueError;
use pyo3::{pyclass, PyErr};
use serde::{Deserialize, Serialize};
use std::sync::Arc;

use crate::scheduling::{Cal, CalendarAdjustment, DateRoll, UnionCal};

#[derive(Clone, Debug)]
pub(crate) enum CalWrapper {
    Cal(Cal),
    UnionCal(UnionCal),
}

impl DateRoll for CalWrapper {
    fn is_weekday(&self, date: &NaiveDateTime) -> bool {
        match self {
            CalWrapper::Cal(c) => c.is_weekday(date),
            CalWrapper::UnionCal(c) => c.is_weekday(date),
        }
    }

    fn is_holiday(&self, date: &NaiveDateTime) -> bool {
        match self {
            CalWrapper::Cal(c) => c.is_holiday(date),
            CalWrapper::UnionCal(c) => c.is_holiday(date),
        }
    }

    fn is_settlement(&self, date: &NaiveDateTime) -> bool {
        match self {
            CalWrapper::Cal(c) => c.is_settlement(date),
            CalWrapper::UnionCal(c) => c.is_settlement(date),
        }
    }
}

impl CalendarAdjustment for CalWrapper {}

/// A wrapper for a UnionCal struct specified by a string representation.
#[pyclass(module = "rateslib.rs", from_py_object)]
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(from = "NamedCalDataModel")]
pub struct NamedCal {
    pub name: String,
    #[serde(skip)]
    pub(crate) inner: Arc<CalWrapper>,
}

#[derive(Deserialize)]
struct NamedCalDataModel {
    name: String,
}

impl std::convert::From<NamedCalDataModel> for NamedCal {
    fn from(model: NamedCalDataModel) -> Self {
        Self::try_new(&model.name).expect("NamedCal data model contains bad data.")
    }
}

impl NamedCal {
    /// Create a new [`NamedCal`].
    ///
    /// # Notes
    /// `name` must be a string that contains pre-defined calendars separated by commas, additionally
    /// separating business day calendars with associated settlement calendars by a pipe operator.
    ///
    /// # Examples
    /// ```rust
    /// # use rateslib::scheduling::{NamedCal, ndt, DateRoll};
    /// let named_cal = NamedCal::try_new("ldn,tgt|fed");
    /// # let named_cal = named_cal.unwrap();
    /// assert!(named_cal.is_bus_day(&ndt(2026, 2, 12)));
    /// ```
    pub fn try_new(name: &str) -> Result<Self, PyErr> {
        let name_ = name.to_lowercase();
        let parts: Vec<&str> = name_.split("|").collect();
        if parts.len() > 2 {
            Err(PyValueError::new_err(
                "Cannot use more than one pipe ('|') operator in `name`.",
            ))
        } else if parts.len() == 1 {
            let cals: Vec<Cal> = parse_cals(parts[0])?;
            Ok(Self {
                name: name_,
                inner: Arc::new(CalWrapper::UnionCal(UnionCal {
                    calendars: cals,
                    settlement_calendars: None,
                })),
            })
        } else {
            let cals: Vec<Cal> = parse_cals(parts[0])?;
            let settle_cals: Vec<Cal> = parse_cals(parts[1])?;
            Ok(Self {
                name: name_,
                inner: Arc::new(CalWrapper::UnionCal(UnionCal {
                    calendars: cals,
                    settlement_calendars: Some(settle_cals),
                })),
            })
        }
    }
}

impl DateRoll for NamedCal {
    fn is_weekday(&self, date: &NaiveDateTime) -> bool {
        self.inner.is_weekday(date)
    }

    fn is_holiday(&self, date: &NaiveDateTime) -> bool {
        self.inner.is_holiday(date)
    }

    fn is_settlement(&self, date: &NaiveDateTime) -> bool {
        self.inner.is_settlement(date)
    }
}

impl CalendarAdjustment for NamedCal {}

fn parse_cals(name: &str) -> Result<Vec<Cal>, PyErr> {
    let mut cals: Vec<Cal> = Vec::new();
    for cal in name.split(",") {
        cals.push(Cal::try_from_name(cal)?)
    }
    Ok(cals)
}

// UNIT TESTS
#[cfg(test)]
mod tests {
    use super::*;
    use crate::scheduling::ndt;

    #[test]
    fn test_named_cal() {
        let ncal = NamedCal::try_new("tgt,nyc").unwrap();

        assert!(ncal.is_non_bus_day(&ndt(1970, 2, 16))); // NYC holiday
        assert!(ncal.is_non_bus_day(&ndt(1970, 5, 1))); // TGT holiday
        assert!(ncal.is_bus_day(&ndt(1970, 2, 17)));
    }

    #[test]
    fn test_named_cal_pipe() {
        let ncal = NamedCal::try_new("tgt,nyc|ldn").unwrap();

        assert!(ncal.is_non_bus_day(&ndt(1970, 2, 16))); // NYC holiday
        assert!(ncal.is_non_bus_day(&ndt(1970, 5, 1))); // TGT holiday
        assert!(ncal.is_bus_day(&ndt(1970, 2, 17)));

        assert!(!ncal.is_settlement(&ndt(1970, 5, 4))); // LDN holiday
        assert!(ncal.is_settlement(&ndt(1970, 5, 1))); // not LDN holiday
    }

    #[test]
    fn test_named_cal_error() {
        let ncal = NamedCal::try_new("tgt,nyc|ldn|");
        assert!(ncal.is_err());

        let ncal = NamedCal::try_new("");
        assert!(ncal.is_err());
    }
}
