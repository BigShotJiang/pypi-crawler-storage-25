// SPDX-License-Identifier: LicenseRef-Rateslib-Dual
//
// Copyright (c) 2026 Siffrorna Technology Limited
// This code cannot be used or copied externally
//
// Dual-licensed: Free Educational Licence or Paid Commercial Licence (commercial/professional use)
// Source-available, not open source.
//
// See LICENSE and https://rateslib.com/py/en/latest/i_licence.html for details,
// and/or contact info (at) rateslib (dot) com
////////////////////////////////////////////////////////////////////////////////////////////////////

//! Wrapper module to export Rust linalg operations to Python using pyo3 bindings.

use crate::dual::dual::{Dual, Dual2};
use crate::dual::linalg::{dsolve, fdsolve};
use ndarray::{Array1, ArrayView2};
use num_traits::identities::Zero;
use num_traits::Signed;
use numpy::{PyArray2, PyArrayMethods};
use pyo3::prelude::*;
use std::cmp::PartialOrd;
use std::iter::Sum;
use std::ops::{Div, Mul, Sub};

fn dsolve_py<T>(a: Vec<T>, b: Vec<T>, allow_lsq: bool) -> Vec<T>
where
    T: PartialOrd + Signed + Clone + Sum + Zero,
    for<'a> &'a T: Sub<&'a T, Output = T> + Mul<&'a T, Output = T> + Div<&'a T, Output = T>,
{
    // requires row major order of numpy.
    // &'py PyArray1<Dual>
    let a1 = Array1::from_vec(a);
    let b_ = Array1::from_vec(b);
    let (r, c) = (a1.len() / b_.len(), b_.len());
    let a2 = a1
        .into_shape_with_order((r, c))
        .expect("Inputs `a` and `b` for dual solve were incorrect shapes");
    let out = dsolve(&a2.view(), &b_.view(), allow_lsq);
    out.into_raw_vec_and_offset().0
}

/// Wrapper to solve ax = b, when `a` and `b` contain `Dual` data types.
#[pyfunction]
#[pyo3(name = "_dsolve1")]
pub fn dsolve1_py(
    _py: Python<'_>,
    a: Vec<Dual>,
    b: Vec<Dual>,
    allow_lsq: bool,
) -> PyResult<Vec<Dual>> {
    Ok(dsolve_py(a, b, allow_lsq))
}

/// Wrapper to solve ax = b, when `a` and `b` contain `Dual2` data types.
#[pyfunction]
#[pyo3(name = "_dsolve2")]
pub fn dsolve2_py(
    _py: Python<'_>,
    a: Vec<Dual2>,
    b: Vec<Dual2>,
    allow_lsq: bool,
) -> PyResult<Vec<Dual2>> {
    Ok(dsolve_py(a, b, allow_lsq))
}

fn fdsolve_py<T>(a: ArrayView2<f64>, b: Vec<T>, allow_lsq: bool) -> Vec<T>
where
    T: PartialOrd + Signed + Clone + Sum + Zero,
    for<'a> &'a T: Sub<&'a T, Output = T>,
    for<'a> &'a f64: Mul<&'a T, Output = T>,
{
    let b_ = Array1::from_vec(b);
    let out = fdsolve(&a.view(), &b_.view(), allow_lsq);
    out.into_raw_vec_and_offset().0
}

/// Wrapper to solve ax = b, when `b` contains `Dual` data types.
#[pyfunction]
#[pyo3(name = "_fdsolve1")]
pub fn fdsolve1_py(
    _py: Python<'_>,
    a: &Bound<'_, PyArray2<f64>>,
    b: Vec<Dual>,
    allow_lsq: bool,
) -> PyResult<Vec<Dual>> {
    unsafe { Ok(fdsolve_py(a.as_array(), b, allow_lsq)) }
}

/// Wrapper to solve ax = b, when `b` contains `Dual2` data types.
#[pyfunction]
#[pyo3(name = "_fdsolve2")]
pub fn fdsolve2_py(
    _py: Python<'_>,
    a: &Bound<'_, PyArray2<f64>>,
    b: Vec<Dual2>,
    allow_lsq: bool,
) -> PyResult<Vec<Dual2>> {
    unsafe { Ok(fdsolve_py(a.as_array(), b, allow_lsq)) }
}
