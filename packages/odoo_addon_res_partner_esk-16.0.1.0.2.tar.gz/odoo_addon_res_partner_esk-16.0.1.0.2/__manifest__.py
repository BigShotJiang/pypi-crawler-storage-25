{
    "name": "Res Partner ESK",
    "summary": """
        Res Partner customizations for ESK
    """,
    "author": "Coopdevs",
    "website": "https://git.coopdevs.org/talaios/addons/esk/odoo-esk",
    "category": "Base",
    "version": "16.0.1.0.2",
    "depends": ["contacts"],
    "data": [
        "views/res_partner_view.xml",
        "views/working_group_view.xml",
        "security/ir.model.access.csv",
    ],
    "installable": True,
    "auto_install": False,
    "license": "AGPL-3",
}
