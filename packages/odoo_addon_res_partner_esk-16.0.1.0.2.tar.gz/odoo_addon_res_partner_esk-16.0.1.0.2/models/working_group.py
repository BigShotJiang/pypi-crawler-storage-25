from random import randint

from odoo import fields, models


class WorkingGroup(models.Model):
    _name = "working.group"

    def _get_default_color(self):
        return randint(1, 11)

    name = fields.Char(string="Name", required=True, translate=True)
    color = fields.Integer(string="Color", default=_get_default_color)
    active = fields.Boolean(
        string="Active",
        default=True,
        help="The active field allows you to hide the working group without removing it.",  # noqa
    )
