from odoo import fields, models


class ResPartner(models.Model):
    _inherit = "res.partner"

    organizer = fields.Boolean(
        string="Organizer",
        default=False,
    )

    national_committee = fields.Boolean(
        string="National Committee",
        default=False,
    )

    coordinator = fields.Boolean(
        string="Coordinator",
        default=False,
    )

    working_group = fields.Many2many(
        "working.group",
        "res_partner_working_group_rel",
        "partner_id",
        "working_group_id",
    )

    province = fields.Selection(
        [
            ("araba", "Araba"),
            ("bizkaia", "Bizkaia"),
            ("gipuzkoa", "Gipuzkoa"),
            ("nafarroa", "Nafarroa"),
        ],
    )
