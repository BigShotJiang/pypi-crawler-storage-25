from . import res_partner, working_group
