{{/*
Expand the name of the chart.
*/}}
{{- define "shenron-caddy.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a fully qualified app name.
*/}}
{{- define "shenron-caddy.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "shenron-caddy.name" . -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart metadata label.
*/}}
{{- define "shenron-caddy.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels.
*/}}
{{- define "shenron-caddy.labels" -}}
helm.sh/chart: {{ include "shenron-caddy.chart" . }}
app.kubernetes.io/name: {{ include "shenron-caddy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Labels used to select pods.
*/}}
{{- define "shenron-caddy.selectorLabels" -}}
app.kubernetes.io/name: {{ include "shenron-caddy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Resource name for Caddy Deployment/Service/ConfigMap.
*/}}
{{- define "shenron-caddy.caddyName" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Resolve Caddy FQDN. Returns empty string when not set.
*/}}
{{- define "shenron-caddy.caddyFqdn" -}}
{{- $caddy := .Values.caddy | default dict -}}
{{- $fqdn := "" -}}
{{- if hasKey $caddy "fqdn" -}}
{{- $fqdn = printf "%v" (get $caddy "fqdn") -}}
{{- end -}}
{{- trim $fqdn -}}
{{- end -}}

{{/*
Resolve optional Caddy TLS contact email.
*/}}
{{- define "shenron-caddy.caddyTlsEmail" -}}
{{- $caddy := .Values.caddy | default dict -}}
{{- $tls := get $caddy "tls" | default dict -}}
{{- if and (hasKey $caddy "tls") (not (kindIs "map" $tls)) -}}
{{- fail "values.caddy.tls must be an object" -}}
{{- end -}}
{{- if hasKey $tls "email" -}}
{{- trim (printf "%v" (get $tls "email")) -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{/*
Resolve optional Caddy ACME CA URL.
*/}}
{{- define "shenron-caddy.caddyTlsAcmeCA" -}}
{{- $caddy := .Values.caddy | default dict -}}
{{- $tls := get $caddy "tls" | default dict -}}
{{- if and (hasKey $caddy "tls") (not (kindIs "map" $tls)) -}}
{{- fail "values.caddy.tls must be an object" -}}
{{- end -}}
{{- if hasKey $tls "acmeCA" -}}
{{- trim (printf "%v" (get $tls "acmeCA")) -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{/*
Resolve the replica-manager upstream host.
*/}}
{{- define "shenron-caddy.replicaManagerHost" -}}
{{- $replicaManager := .Values.replicaManager | default dict -}}
{{- $service := get $replicaManager "service" | default dict -}}
{{- $name := get $service "name" | default "shenron-replica-manager" -}}
{{- $namespace := get $service "namespace" | default "shenron" -}}
{{- if eq (trim (printf "%v" $namespace)) "" -}}
{{- printf "%v" $name -}}
{{- else -}}
{{- printf "%v.%v.svc.cluster.local" $name $namespace -}}
{{- end -}}
{{- end -}}

{{/*
Resolve the replica-manager upstream port.
*/}}
{{- define "shenron-caddy.replicaManagerPort" -}}
{{- $replicaManager := .Values.replicaManager | default dict -}}
{{- $service := get $replicaManager "service" | default dict -}}
{{- int (get $service "port" | default 8081) -}}
{{- end -}}

{{/*
Generate the Caddyfile content for the ConfigMap.
*/}}
{{- define "shenron-caddy.caddyfile" -}}
{{- $fqdn := include "shenron-caddy.caddyFqdn" . -}}
{{- $tlsEmail := include "shenron-caddy.caddyTlsEmail" . -}}
{{- $tlsAcmeCA := include "shenron-caddy.caddyTlsAcmeCA" . -}}
{{- $host := ternary $fqdn ":80" (ne $fqdn "") }}
{{- if or (ne $tlsEmail "") (ne $tlsAcmeCA "") }}
{
{{- if ne $tlsEmail "" }}
    email {{ $tlsEmail | quote }}
{{- end }}
{{- if ne $tlsAcmeCA "" }}
    acme_ca {{ $tlsAcmeCA | quote }}
{{- end }}
}

{{- end }}
{{ $host }} {
{{- if (get (.Values.replicaManager | default dict) "enabled" | default true) }}
    handle_path /replica/* {
        reverse_proxy {{ include "shenron-caddy.replicaManagerHost" . }}:{{ include "shenron-caddy.replicaManagerPort" . }}
    }
{{- end }}
{{- range .Values.caddy.extraRoutes }}
    handle {{ .path }} {
        reverse_proxy {{ .service }}:{{ .port }}
    }
{{- end }}
}
{{- end -}}
