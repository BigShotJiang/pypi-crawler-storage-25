#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHART_DIR="$ROOT_DIR/helm/caddy"

if ! command -v helm >/dev/null 2>&1; then
  echo "helm not available, skipping caddy chart lint/render test"
  exit 0
fi

helm lint "$CHART_DIR" -f "$CHART_DIR/node-piccolo.yaml"

rendered="$(mktemp)"
trap 'rm -f "$rendered"' EXIT

helm template caddy "$CHART_DIR" -f "$CHART_DIR/node-piccolo.yaml" >"$rendered"

if [[ "$(grep -c '^kind: Deployment$' "$rendered")" -ne 1 ]]; then
  echo "expected only the caddy deployment to be rendered" >&2
  exit 1
fi

if [[ "$(grep -c '^kind: Service$' "$rendered")" -ne 1 ]]; then
  echo "expected only the caddy service to be rendered" >&2
  exit 1
fi

if [[ "$(grep -c '^kind: ConfigMap$' "$rendered")" -ne 1 ]]; then
  echo "expected only the caddy configmap to be rendered" >&2
  exit 1
fi

if [[ "$(grep -c '^kind: PersistentVolumeClaim$' "$rendered")" -ne 1 ]]; then
  echo "expected the caddy pvc to be rendered" >&2
  exit 1
fi

if ! grep -q "app.kubernetes.io/component: caddy" "$rendered"; then
  echo "expected caddy resources to be labeled as caddy" >&2
  exit 1
fi

if ! grep -q 'hostNetwork: true' "$rendered"; then
  echo "expected host networking to be enabled for the piccolo profile" >&2
  exit 1
fi

if ! grep -q 'reverse_proxy shenron-replica-manager.shenron.svc.cluster.local:8081' "$rendered"; then
  echo "expected caddy to proxy replica-manager across namespaces by default" >&2
  exit 1
fi

if grep -q 'name: shenron-replica-manager' "$rendered"; then
  echo "did not expect replica-manager resources in the standalone caddy chart" >&2
  exit 1
fi

echo "standalone caddy helm chart lint/template succeeded"
