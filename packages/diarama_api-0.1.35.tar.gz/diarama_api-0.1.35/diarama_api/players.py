class Players:
    def __init__(self, client):
        self.client = client

    def list(self, page=None, per_page=None, search=None, banned=None, role_id=None):
        params = {}
        if page is not None:
            params['page'] = page
        if per_page is not None:
            params['per_page'] = per_page
        if search is not None:
            params['search'] = search
        if banned is not None:
            params['banned'] = 'true' if banned else 'false'
        if role_id is not None:
            params['role_id'] = role_id
        return self.client._get("/players/", params=params)

    def list_all(self):
        """Получить ВСЕХ игроков (автопагинация)"""
        all_players = []
        page = 1
        while True:
            data = self.list(page=page, per_page=100)
            players = data.get('players', [])
            all_players.extend(players)
            pagination = data.get('pagination', {})
            if not pagination.get('has_next', False):
                break
            page += 1
        return {'players': all_players, 'total': len(all_players)}

    def get(self, identifier):
        return self.client._get(f"/players/{identifier}")

    def create(self, username, password, email, role_id=None, avatar_id=None):
        data = {"username": username, "password": password, "email": email}
        if role_id:
            data["role_id"] = role_id
        if avatar_id:
            data["avatar_id"] = avatar_id
        return self.client._post("/players/", data)

    def login(self, username, password):
        data = {"username": username, "password": password}
        return self.client._post("/players/login", data)

    def update(self, identifier, **kwargs):
        # We pass all kwargs directly to allow for maximum flexibility
        # (e.g. updating username, creation date, etc.)
        return self.client._put(f"/players/{identifier}", kwargs)

    def delete(self, identifier):
        return self.client._delete(f"/players/{identifier}")

    def get_stats(self, identifier):
        return self.client._get(f"/players/{identifier}/stats")

    def update_playtime(self, identifier, game_id, hours):
        data = {"game_id": game_id, "hours": hours}
        return self.client._post(f"/players/{identifier}/update-playtime", data)

    def get_games(self, identifier):
        return self.client._get(f"/players/{identifier}/games")