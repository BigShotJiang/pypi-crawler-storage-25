"""ExecutionAgent — automated project building and testing in Docker."""

from pathlib import Path

__version__ = "0.1.0"

package_dir = Path(__file__).resolve().parent
prompt_files_dir = package_dir / "prompt_files"