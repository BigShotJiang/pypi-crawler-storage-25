"""Allow running as `python -m execution_agent`."""

from execution_agent.main import main

raise SystemExit(main())
