"""fyrnheim -- Define typed Python entities, generate transformations, run anywhere."""

from fyrnheim.components.computed_column import ComputedColumn as ComputedColumn
from fyrnheim.core import (
    ActivityDefinition as ActivityDefinition,
    AnalyticsEntity as AnalyticsEntity,
    BaseTableSource as BaseTableSource,
    Divide as Divide,
    EventOccurred as EventOccurred,
    EventSource as EventSource,
    Field as Field,
    FieldChanged as FieldChanged,
    IdentityGraph as IdentityGraph,
    IdentitySource as IdentitySource,
    Join as Join,
    Measure as Measure,
    MetricField as MetricField,
    MetricsModel as MetricsModel,
    Multiply as Multiply,
    Rename as Rename,
    RowAppeared as RowAppeared,
    RowDisappeared as RowDisappeared,
    SourceTransforms as SourceTransforms,
    StateField as StateField,
    StateSource as StateSource,
    TableSource as TableSource,
    TypeCast as TypeCast,
)
from fyrnheim.core.staging_view import StagingView as StagingView
from fyrnheim.primitives import (
    account_id_from_domain as account_id_from_domain,
    any_value as any_value,
    avg_ as avg_,
    boolean_to_int as boolean_to_int,
    categorize as categorize,
    categorize_contains as categorize_contains,
    concat_hash as concat_hash,
    count_ as count_,
    count_distinct as count_distinct,
    cumulative_sum as cumulative_sum,
    date_diff_days as date_diff_days,
    date_trunc_month as date_trunc_month,
    date_trunc_quarter as date_trunc_quarter,
    date_trunc_year as date_trunc_year,
    days_since as days_since,
    earliest_date as earliest_date,
    extract_day as extract_day,
    extract_email_domain as extract_email_domain,
    extract_month as extract_month,
    extract_year as extract_year,
    first_value as first_value,
    hash_email as hash_email,
    hash_id as hash_id,
    hash_md5 as hash_md5,
    hash_sha256 as hash_sha256,
    is_personal_email_domain as is_personal_email_domain,
    json_extract_scalar as json_extract_scalar,
    json_value as json_value,
    lag_value as lag_value,
    last_value as last_value,
    latest_date as latest_date,
    lead_value as lead_value,
    lifecycle_flag as lifecycle_flag,
    max_ as max_,
    min_ as min_,
    parse_iso8601_duration as parse_iso8601_duration,
    row_number_by as row_number_by,
    sum_ as sum_,
    to_json_struct as to_json_struct,
)
from fyrnheim.quality import (
    CheckResult as CheckResult,
    NotNull as NotNull,
    QualityCheck as QualityCheck,
    QualityRunner as QualityRunner,
    Unique as Unique,
)

# Manually synced with pyproject.toml on every release.
# TODO(future): derive from importlib.metadata("fyrnheim").version to
# prevent drift (was "0.1.0" across v0.8.0–v0.12.0 PyPI releases).
__version__ = "0.12.1"

__all__ = [
    # Core types
    "AnalyticsEntity",
    "Measure",
    "StateField",
    "Field",
    # Sources
    "BaseTableSource",
    "TableSource",
    "EventSource",
    "StateSource",
    "SourceTransforms",
    "StagingView",
    "TypeCast",
    "Rename",
    "Divide",
    "Multiply",
    "Join",
    # Identity
    "IdentityGraph",
    "IdentitySource",
    # Activities
    "ActivityDefinition",
    "RowAppeared",
    "FieldChanged",
    "RowDisappeared",
    "EventOccurred",
    # Analytics (legacy removed -- AnalyticsEntity replaces StreamAnalyticsModel)
    # Metrics
    "MetricsModel",
    "MetricField",
    # Components
    "ComputedColumn",
    # Quality
    "QualityCheck",
    "NotNull",
    "Unique",
    "QualityRunner",
    "CheckResult",
    # Primitives: Hashing
    "concat_hash",
    "hash_email",
    "hash_id",
    "hash_md5",
    "hash_sha256",
    # Primitives: Dates
    "date_diff_days",
    "date_trunc_month",
    "date_trunc_quarter",
    "date_trunc_year",
    "days_since",
    "extract_year",
    "extract_month",
    "extract_day",
    "earliest_date",
    "latest_date",
    # Primitives: Categorization
    "categorize",
    "categorize_contains",
    "lifecycle_flag",
    "boolean_to_int",
    # Primitives: JSON
    "to_json_struct",
    "json_extract_scalar",
    "json_value",
    # Primitives: Aggregations
    "sum_",
    "count_",
    "count_distinct",
    "avg_",
    "min_",
    "max_",
    "row_number_by",
    "cumulative_sum",
    "lag_value",
    "lead_value",
    "first_value",
    "last_value",
    "any_value",
    # Primitives: Strings
    "extract_email_domain",
    "is_personal_email_domain",
    "account_id_from_domain",
    # Primitives: Time
    "parse_iso8601_duration",
]
