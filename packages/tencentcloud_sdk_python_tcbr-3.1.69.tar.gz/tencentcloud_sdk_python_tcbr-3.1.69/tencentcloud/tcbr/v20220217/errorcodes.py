# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# CAM签名/鉴权错误。
AUTHFAILURE = 'AuthFailure'

# 操作失败。
FAILEDOPERATION = 'FailedOperation'

# 内部错误。
INTERNALERROR = 'InternalError'

# 参数错误。
INVALIDPARAMETER = 'InvalidParameter'

# 超过配额限制。
LIMITEXCEEDED = 'LimitExceeded'

# 缺少参数错误。
MISSINGPARAMETER = 'MissingParameter'

# 请求的次数超过了频率限制。
REQUESTLIMITEXCEEDED = 'RequestLimitExceeded'

# 资源被占用。
RESOURCEINUSE = 'ResourceInUse'

# 资源不足。
RESOURCEINSUFFICIENT = 'ResourceInsufficient'

# 资源不存在。
RESOURCENOTFOUND = 'ResourceNotFound'

# 请求的云托管服务未找到
RESOURCENOTFOUND_SERVERNOTFOUND = 'ResourceNotFound.ServerNotFound'

# 请求参数中的云托管版本未找到
RESOURCENOTFOUND_VERSIONNOTFOUND = 'ResourceNotFound.VersionNotFound'

# 资源不可用。
RESOURCEUNAVAILABLE = 'ResourceUnavailable'

# 资源被封禁
RESOURCEUNAVAILABLE_RESOURCEBANNED = 'ResourceUnavailable.ResourceBanned'

# 资源已冻结
RESOURCEUNAVAILABLE_RESOURCEFROZEN = 'ResourceUnavailable.ResourceFrozen'

# 资源已隔离
RESOURCEUNAVAILABLE_RESOURCEISOLATED = 'ResourceUnavailable.ResourceIsolated'

# 未授权操作。
UNAUTHORIZEDOPERATION = 'UnauthorizedOperation'

# 操作不支持。
UNSUPPORTEDOPERATION = 'UnsupportedOperation'
