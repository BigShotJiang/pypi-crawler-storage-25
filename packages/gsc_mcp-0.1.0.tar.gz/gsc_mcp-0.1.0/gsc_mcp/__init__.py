"""Google Search Console MCP server.

Exposes GSC read operations as MCP tools: search analytics queries,
URL inspection, sitemap listing, and site enumeration. OAuth-based
authentication with per-user credential isolation.
"""

__version__ = "0.1.0"
