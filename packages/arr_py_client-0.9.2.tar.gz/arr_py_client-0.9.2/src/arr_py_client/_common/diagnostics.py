"""Connection diagnostics for arr servers.

Three public primitives that downstream apps (CLIs, web UIs, config wizards)
compose into user-facing connection-test flows:

- :data:`DEFAULT_PORTS` — default HTTP ports for each arr product.
- :func:`normalize_base_url` — pure sync URL-shape validator / normalizer.
- :func:`identify_arr_server` — async HTTP probe that detects which arr (if
  any) answers at a given URL and whether the API key is accepted.

These return factual data only. They do not produce localized suggestion
strings, rendering directives, or "fix buttons" — caller apps own that layer
(they know their UX, locale, and runtime context like Docker/VPN).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Final, Literal, cast
from urllib.parse import urlsplit, urlunsplit

import httpx

if TYPE_CHECKING:
    from collections.abc import Mapping

ArrKind = Literal["sonarr", "radarr", "prowlarr"]
Scheme = Literal["http", "https"]

DEFAULT_PORTS: Final[Mapping[ArrKind, int]] = MappingProxyType(
    {"sonarr": 8989, "radarr": 7878, "prowlarr": 9696}
)
"""Default HTTP ports for each arr product, matching upstream defaults."""


# Matches trailing ``/api/vN`` or ``/api/vN/`` at the end of a URL path.
_API_VERSION_TAIL = re.compile(r"/api/v(\d+)/?$")


@dataclass(frozen=True, slots=True)
class NormalizedBaseUrl:
    """Parsed, canonical arr base URL.

    The :attr:`url` field is always safe to pass as ``base_url`` to
    :class:`AsyncRadarrClient` / :class:`AsyncSonarrClient` /
    :class:`AsyncProwlarrClient`. The other fields expose what was detected
    or changed during normalization — callers use them to warn the user
    ("you included ``/api/v3`` — stripped it", "your URL had no port, using
    default 8989", etc.).
    """

    url: str
    """Canonical base URL — no trailing slash, no ``/api/vN`` tail."""

    original: str
    """Exactly the string the caller passed in."""

    scheme: Scheme
    host: str
    port: int | None
    """``None`` means the scheme default (80 for http, 443 for https)."""

    path: str
    """Path prefix with leading slash, or ``""``. Never trailing-slashed."""

    stripped_api_path: str | None
    """If the input ended in ``/api/vN``, the exact tail that was removed."""

    had_trailing_slash: bool
    """Whether the input had a trailing slash (after the host or path)."""

    def __str__(self) -> str:
        return self.url


def normalize_base_url(url: str) -> NormalizedBaseUrl:
    """Parse and normalize a user-supplied arr base URL.

    Accepts URLs shaped like ``http[s]://host[:port][/prefix][/api/vN][/]``
    and returns a canonical form suitable to hand straight to the arr
    clients' ``base_url=`` parameter.

    Raises:
        ValueError: if ``url`` is empty, missing a scheme, uses an
            unsupported scheme, or is missing a host. Callers translate
            these into their own user-facing error messages.
    """
    original = url
    stripped = url.strip()
    if not stripped:
        raise ValueError("base_url is empty")

    parsed = urlsplit(stripped)
    if not parsed.scheme:
        raise ValueError(
            f"base_url missing scheme (expected http:// or https://): {url!r}"
        )
    if parsed.scheme not in ("http", "https"):
        raise ValueError(
            f"base_url has unsupported scheme {parsed.scheme!r}; expected http or https"
        )
    # urlsplit lowercases the scheme only if the host follows ``//`` — which
    # it always does for valid input. Narrow the type for pyright.
    scheme: Scheme = "https" if parsed.scheme == "https" else "http"

    host = parsed.hostname
    if not host:
        raise ValueError(f"base_url missing host: {url!r}")

    try:
        port = parsed.port
    except ValueError as exc:
        raise ValueError(f"base_url has invalid port: {url!r}") from exc

    raw_path = parsed.path
    had_trailing_slash = len(raw_path) > 0 and raw_path.endswith("/")

    # Strip ``/api/vN`` or ``/api/vN/`` tail if present.
    match = _API_VERSION_TAIL.search(raw_path)
    stripped_api_path: str | None = None
    if match is not None:
        stripped_api_path = raw_path[match.start() :].rstrip("/")
        raw_path = raw_path[: match.start()]

    # Drop any lingering trailing slash on the path.
    path = raw_path.rstrip("/")

    # Re-assemble. urlunsplit preserves an explicit port only if we keep it
    # in the netloc; rebuild netloc deterministically.
    netloc = host
    if port is not None:
        netloc = f"{host}:{port}"
    canonical = urlunsplit((scheme, netloc, path, "", ""))

    return NormalizedBaseUrl(
        url=canonical,
        original=original,
        scheme=scheme,
        host=host,
        port=port,
        path=path,
        stripped_api_path=stripped_api_path,
        had_trailing_slash=had_trailing_slash,
    )


# --- identify_arr_server -------------------------------------------------


AuthStatus = Literal["ok", "rejected", "not_checked"]
ErrorKind = Literal[
    "dns",
    "connect_refused",
    "tls",
    "timeout",
    "http_error",
    "not_arr",
]


@dataclass(frozen=True, slots=True)
class ArrServerInfo:
    """Result of a single ``identify_arr_server`` probe.

    All fields are factual. Callers map this into their own UX — which error
    kinds get which suggestion copy, which fix buttons to show, etc.
    """

    normalized_base_url: str
    """Base URL that was actually probed (after normalization + scheme flip)."""

    scheme_used: Scheme
    """Scheme that was actually probed. Differs from the input when
    ``try_both_schemes=True`` and the original scheme failed to connect."""

    http_reachable: bool
    """True iff some HTTP response came back (any status). False means we
    never got past the transport layer."""

    detected_kind: ArrKind | None
    """Which arr identified itself via ``appName``, if we could tell.
    ``None`` when unreachable, auth-rejected without a product hint, or
    answering but not shaped like an arr."""

    api_version: str | None
    """The ``version`` string reported by ``/api/vN/system/status``, or
    ``None`` if we couldn't get an authenticated read."""

    auth_status: AuthStatus
    """``"ok"`` — API key accepted. ``"rejected"`` — server returned 401/403.
    ``"not_checked"`` — no API key supplied, or we never reached the server."""

    error_kind: ErrorKind | None
    """Coarse bucket of why the probe failed. ``None`` on success (where
    ``success`` = we got a response, even a 401 — reachability is the
    point). Callers use this to pick suggestion copy."""

    error_detail: str | None
    """Raw httpx / status-code string for logs. Not for localization or
    end-user display."""


# Hostname paths we probe, in order. Sonarr/Radarr expose v3; Prowlarr v1.
_STATUS_PATHS: tuple[str, ...] = ("/api/v3/system/status", "/api/v1/system/status")

# Maps upstream ``appName`` → our canonical lowercase kind.
_APP_NAME_TO_KIND: dict[str, ArrKind] = {
    "sonarr": "sonarr",
    "radarr": "radarr",
    "prowlarr": "prowlarr",
}


def _classify_transport_error(exc: Exception) -> tuple[ErrorKind, str]:
    """Map an httpx exception to a coarse ``error_kind`` bucket + detail."""
    detail = str(exc) or exc.__class__.__name__
    if isinstance(exc, httpx.TimeoutException):
        return "timeout", detail
    # httpx.ConnectError wraps the underlying OSError; inspect the message.
    # This is fragile by nature — the detail string is authoritative, the
    # bucket is a hint.
    lowered = detail.lower()
    if "ssl" in lowered or "certificate" in lowered or "tls" in lowered:
        return "tls", detail
    if (
        "name or service not known" in lowered
        or "nodename nor servname" in lowered
        or "getaddrinfo" in lowered
        or "temporary failure in name resolution" in lowered
    ):
        return "dns", detail
    if "refused" in lowered:
        return "connect_refused", detail
    # Fall through — unknown transport failure.
    return "connect_refused", detail


def _classify_appname(payload: object) -> tuple[ArrKind | None, str | None]:
    """Extract ``(detected_kind, api_version)`` from a ``/system/status`` body."""
    if not isinstance(payload, dict):
        return None, None
    body = cast("dict[str, Any]", payload)
    app_name_raw: object = body.get("appName")
    version_raw: object = body.get("version")
    kind: ArrKind | None = None
    if isinstance(app_name_raw, str):
        kind = _APP_NAME_TO_KIND.get(app_name_raw.strip().lower())
    version = version_raw if isinstance(version_raw, str) else None
    return kind, version


async def _probe_once(
    client: httpx.AsyncClient,
    *,
    base_url: str,
    api_key: str | None,
) -> ArrServerInfo:
    """Run the HTTP portion of one probe against a single base URL.

    Assumes ``base_url`` is already normalized. Does not handle scheme-flip —
    that's the caller's job.
    """
    scheme_used: Scheme = "https" if base_url.startswith("https://") else "http"
    headers = {"Accept": "application/json"}
    if api_key is not None:
        headers["X-Api-Key"] = api_key

    response: httpx.Response | None = None
    for path in _STATUS_PATHS:
        url = f"{base_url}{path}"
        try:
            response = await client.get(url, headers=headers)
        except httpx.HTTPError as exc:
            # Transport-layer failure on the first path is very likely to
            # repeat on the second; bail out with a classified error.
            kind, detail = _classify_transport_error(exc)
            return ArrServerInfo(
                normalized_base_url=base_url,
                scheme_used=scheme_used,
                http_reachable=False,
                detected_kind=None,
                api_version=None,
                auth_status="not_checked",
                error_kind=kind,
                error_detail=detail,
            )
        if response.status_code == 404:
            continue
        break

    if response is None:
        # Unreachable: _STATUS_PATHS is non-empty, so either a response is
        # assigned and we break, or we return early from the except branch.
        raise RuntimeError("identify_arr_server: no probe paths configured")

    status = response.status_code
    if status in (401, 403):
        return ArrServerInfo(
            normalized_base_url=base_url,
            scheme_used=scheme_used,
            http_reachable=True,
            detected_kind=None,
            api_version=None,
            auth_status="rejected",
            error_kind=None,
            error_detail=f"HTTP {status} {response.reason_phrase}",
        )

    if 200 <= status < 300:
        try:
            payload = response.json()
        except ValueError:
            payload = None
        detected, api_version = _classify_appname(payload)
        if detected is None:
            return ArrServerInfo(
                normalized_base_url=base_url,
                scheme_used=scheme_used,
                http_reachable=True,
                detected_kind=None,
                api_version=None,
                auth_status="not_checked" if api_key is None else "ok",
                error_kind="not_arr",
                error_detail=(
                    f"HTTP {status} but response missing 'appName' "
                    "(body is not a /system/status payload)"
                ),
            )
        return ArrServerInfo(
            normalized_base_url=base_url,
            scheme_used=scheme_used,
            http_reachable=True,
            detected_kind=detected,
            api_version=api_version,
            auth_status="ok" if api_key is not None else "not_checked",
            error_kind=None,
            error_detail=None,
        )

    # Other HTTP status (404 on both paths, 5xx, etc.).
    return ArrServerInfo(
        normalized_base_url=base_url,
        scheme_used=scheme_used,
        http_reachable=True,
        detected_kind=None,
        api_version=None,
        auth_status="not_checked",
        error_kind="http_error",
        error_detail=f"HTTP {status} {response.reason_phrase}",
    )


def _flip_scheme(base_url: str) -> str:
    if base_url.startswith("https://"):
        return "http://" + base_url[len("https://") :]
    if base_url.startswith("http://"):
        return "https://" + base_url[len("http://") :]
    return base_url


async def identify_arr_server(
    base_url: str,
    *,
    api_key: str | None = None,
    try_both_schemes: bool = False,
    timeout: float = 2.0,
    http_client: httpx.AsyncClient | None = None,
) -> ArrServerInfo:
    """Probe ``base_url`` and report which arr product answers.

    Hits ``/api/v3/system/status`` (Sonarr / Radarr) and falls back to
    ``/api/v1/system/status`` (Prowlarr) if the first returns 404. Returns
    an :class:`ArrServerInfo` with factual fields — never raises on
    transport or HTTP failures; those surface in ``error_kind`` /
    ``error_detail``.

    Args:
        base_url: Raw user-supplied URL. Will be normalized internally via
            :func:`normalize_base_url`; pass the ``original`` string, not
            a :class:`NormalizedBaseUrl`.
        api_key: If given, sent as ``X-Api-Key``. Without it, the probe
            can still identify which arr is there (via unauthenticated 200
            paths), but ``auth_status`` will be ``"not_checked"``.
        try_both_schemes: On transport failure (connect-refused / TLS
            error / DNS failure), flip http↔https and retry once. Only
            applies to transport failures — a reachable 401 does not
            trigger a flip.
        timeout: Per-request timeout in seconds. Default 2s — diagnostics
            should be snappy, not the default 30s httpx timeout.
        http_client: Optional caller-owned ``AsyncClient``. If provided,
            the caller owns its lifecycle and ``timeout`` is ignored
            (caller configures their client). Useful to inject a mocked
            client in tests or share a connection pool.

    Raises:
        ValueError: only if :func:`normalize_base_url` rejects the input
            outright (missing scheme, missing host, etc.). Transport and
            HTTP failures do not raise.
    """
    normalized = normalize_base_url(base_url)
    probe_url = normalized.url

    owns_client = http_client is None
    client = http_client or httpx.AsyncClient(timeout=timeout)
    try:
        result = await _probe_once(client, base_url=probe_url, api_key=api_key)
        if (
            try_both_schemes
            and not result.http_reachable
            and result.error_kind in ("connect_refused", "tls", "dns")
        ):
            flipped = _flip_scheme(probe_url)
            if flipped != probe_url:
                result = await _probe_once(client, base_url=flipped, api_key=api_key)
        return result
    finally:
        if owns_client:
            await client.aclose()
