"""Ping / health-check resource for Prowlarr v1.

Prowlarr exposes ``/ping`` outside the ``/api/v1`` prefix; this resource calls
it via ``transport.request(..., absolute=True)`` so the client hits ``/ping``
instead of ``/api/v1/ping`` (which 404s).

Mirrors the Radarr/Sonarr curated facade so ``await client.ping()`` returns
``True`` and ``await client.ping.list_()`` returns the structured payload.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client.prowlarr.v1._generated import models as _models
from arr_py_client.prowlarr.v1.resources._auto.ping import (
    AsyncPingResource as _AutoAsync,
)
from arr_py_client.prowlarr.v1.resources._auto.ping import (
    PingResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class PingResource(_AutoSync):
    """Sync Prowlarr ping resource; callable as ``client.ping()`` for a bool health check."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def __call__(self) -> bool:
        self._transport.request("GET", "/ping", absolute=True, timeout=5.0)
        return True

    def list_(self) -> _models.PingResource:
        response = self._transport.request("GET", "/ping", absolute=True)
        return _models.PingResource.model_validate(response.json())


class AsyncPingResource(_AutoAsync):
    """Async Prowlarr ping resource; callable as ``await client.ping()``."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def __call__(self) -> _PingAwaitable:
        return _PingAwaitable(self)

    async def list_(self) -> _models.PingResource:
        response = await self._transport.request("GET", "/ping", absolute=True)
        return _models.PingResource.model_validate(response.json())


class _PingAwaitable:
    """Makes ``await client.ping()`` work while keeping ``client.ping.list_()`` subresource form."""

    def __init__(self, resource: AsyncPingResource) -> None:
        super().__init__()
        self._resource = resource

    def __await__(self):
        return self._check().__await__()

    async def _check(self) -> bool:
        await self._resource._transport.request(  # pyright: ignore[reportPrivateUsage]
            "GET", "/ping", absolute=True, timeout=5.0
        )
        return True
