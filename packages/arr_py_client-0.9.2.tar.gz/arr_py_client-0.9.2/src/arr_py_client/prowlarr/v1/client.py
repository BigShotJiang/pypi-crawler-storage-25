"""Prowlarr v1 client implementations (sync + async).

Prowlarr is the indexer aggregator in the *arr stack: it hosts the canonical
indexer list and pushes them to registered applications (Radarr, Sonarr,
Lidarr, etc.). Unlike Radarr/Sonarr, it has no library/movies/series/queue;
its curated facades focus on indexers, applications, tags, history,
notifications, and system.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client._common.client_base import (
    build_async_transport,
    build_sync_transport,
    wire_resources,
)
from arr_py_client._common.settings import ProwlarrSettings
from arr_py_client.prowlarr.v1.resources._auto import (
    ASYNC_RESOURCES as _AUTO_ASYNC_RESOURCES,
)
from arr_py_client.prowlarr.v1.resources._auto import (
    SYNC_RESOURCES as _AUTO_SYNC_RESOURCES,
)
from arr_py_client.prowlarr.v1.resources._auto._attrs import (
    ProwlarrV1AsyncResourceAttrs,
    ProwlarrV1SyncResourceAttrs,
)
from arr_py_client.prowlarr.v1.resources.applications import (
    ApplicationsResource,
    AsyncApplicationsResource,
)
from arr_py_client.prowlarr.v1.resources.indexers import (
    AsyncIndexersResource,
    IndexersResource,
)
from arr_py_client.prowlarr.v1.resources.ping import (
    AsyncPingResource,
    PingResource,
)
from arr_py_client.prowlarr.v1.resources.tags import (
    AsyncTagsResource,
    TagsResource,
)

if TYPE_CHECKING:
    import httpx

    from arr_py_client._common.retry import RetryPolicy
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


_APP_NAME = "Prowlarr"
_API_VERSION = 1

_CURATED_SYNC: dict[str, type] = {
    "indexers": IndexersResource,
    "applications": ApplicationsResource,
    "ping": PingResource,
    "tags": TagsResource,
}
_CURATED_ASYNC: dict[str, type] = {
    "indexers": AsyncIndexersResource,
    "applications": AsyncApplicationsResource,
    "ping": AsyncPingResource,
    "tags": AsyncTagsResource,
}


class ProwlarrClientV1(ProwlarrV1SyncResourceAttrs):
    """Synchronous Prowlarr v1 client."""

    transport: SyncTransport
    indexers: IndexersResource
    applications: ApplicationsResource
    ping: PingResource
    tags: TagsResource

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float | None = 30.0,
        url_base: str | None = None,
        verify: bool | str = True,
        retry: RetryPolicy | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        super().__init__()
        self.transport = build_sync_transport(
            settings_cls=ProwlarrSettings,
            app_name=_APP_NAME,
            api_version=_API_VERSION,
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            url_base=url_base,
            verify=verify,
            retry=retry,
            http_client=http_client,
        )
        wire_resources(self, self.transport, _AUTO_SYNC_RESOURCES)
        wire_resources(self, self.transport, _CURATED_SYNC)

    def close(self) -> None:
        self.transport.close()

    def __enter__(self) -> ProwlarrClientV1:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"ProwlarrClientV1(base_url={self.transport.base_url!r}, api_version=1)"


class AsyncProwlarrClientV1(ProwlarrV1AsyncResourceAttrs):
    """Asynchronous Prowlarr v1 client."""

    transport: AsyncTransport
    indexers: AsyncIndexersResource
    applications: AsyncApplicationsResource
    ping: AsyncPingResource
    tags: AsyncTagsResource

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float | None = 30.0,
        url_base: str | None = None,
        verify: bool | str = True,
        retry: RetryPolicy | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__()
        self.transport = build_async_transport(
            settings_cls=ProwlarrSettings,
            app_name=_APP_NAME,
            api_version=_API_VERSION,
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            url_base=url_base,
            verify=verify,
            retry=retry,
            http_client=http_client,
        )
        wire_resources(self, self.transport, _AUTO_ASYNC_RESOURCES)
        wire_resources(self, self.transport, _CURATED_ASYNC)

    async def aclose(self) -> None:
        await self.transport.aclose()

    async def __aenter__(self) -> AsyncProwlarrClientV1:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()

    def __repr__(self) -> str:
        return (
            f"AsyncProwlarrClientV1(base_url={self.transport.base_url!r}, "
            "api_version=1)"
        )
