"""CLI entry point for the arr-py-client MCP server."""

from __future__ import annotations

import argparse
import logging
import os
import sys
import warnings

from arr_py_client.mcp.provider import EnvClientProvider
from arr_py_client.mcp.server import build_server


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="arr-py-mcp",
        description=(
            "Run an MCP server exposing Radarr, Sonarr, and/or Prowlarr as tools."
        ),
    )
    parser.add_argument(
        "--radarr-only",
        action="store_true",
        help="Expose only Radarr tools.",
    )
    parser.add_argument(
        "--sonarr-only",
        action="store_true",
        help="Expose only Sonarr tools.",
    )
    parser.add_argument(
        "--prowlarr-only",
        action="store_true",
        help="Expose only Prowlarr tools.",
    )
    parser.add_argument(
        "--with-prowlarr",
        action="store_true",
        help="Also expose Prowlarr tools alongside Radarr/Sonarr.",
    )
    parser.add_argument(
        "--transport",
        choices=("stdio", "http", "sse"),
        default="stdio",
        help=(
            "MCP transport (default: stdio for client integrations). "
            "'http' is streamable-http (MCP 2025-11 preferred). "
            "'sse' is deprecated and will be removed in 0.9."
        ),
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Bind host for HTTP transports (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=3000,
        help="Bind port for HTTP transports (default: 3000).",
    )
    args = parser.parse_args()

    onlies = [args.radarr_only, args.sonarr_only, args.prowlarr_only]
    if sum(1 for flag in onlies if flag) > 1:
        sys.stderr.write(
            "--radarr-only, --sonarr-only, and --prowlarr-only are mutually exclusive.\n"
        )
        return 2

    if args.prowlarr_only:
        want_radarr, want_sonarr, want_prowlarr = False, False, True
    elif args.radarr_only:
        want_radarr, want_sonarr = True, False
        want_prowlarr = args.with_prowlarr
    elif args.sonarr_only:
        want_radarr, want_sonarr = False, True
        want_prowlarr = args.with_prowlarr
    else:
        want_radarr, want_sonarr = True, True
        want_prowlarr = args.with_prowlarr or bool(os.environ.get("PROWLARR_BASE_URL"))

    if args.transport == "sse":
        warnings.warn(
            (
                "--transport sse is deprecated in MCP 2025-11; use"
                " --transport http (streamable-http) for remote deployments."
                " 'sse' will be removed in the next minor release."
            ),
            DeprecationWarning,
            stacklevel=2,
        )

    provider = EnvClientProvider(
        want_radarr=want_radarr,
        want_sonarr=want_sonarr,
        want_prowlarr=want_prowlarr,
    )

    server = build_server(provider=provider)

    # The SDK takes host/port via FastMCP settings not run(); set them here
    # so HTTP transports bind where the user asked. stdio ignores both.
    if args.transport in ("http", "sse"):
        server.settings.host = args.host
        server.settings.port = args.port
        if args.host not in ("127.0.0.1", "localhost", "::1"):
            logging.getLogger("arr_py_client.mcp").warning(
                (
                    "binding to non-local host %s without token_verifier= —"
                    " remote deployments should configure OAuth 2.1 via"
                    " build_server()"
                ),
                args.host,
            )

    sdk_transport = "streamable-http" if args.transport == "http" else args.transport
    server.run(transport=sdk_transport)
    return 0


if __name__ == "__main__":
    sys.exit(main())
