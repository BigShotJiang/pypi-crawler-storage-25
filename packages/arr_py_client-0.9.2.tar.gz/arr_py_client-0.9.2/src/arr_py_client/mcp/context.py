"""Library-owned per-request context types.

These are the types ``ClientProvider.resolve_*`` and ``list_instances``
receive — deliberately separate from FastMCP's ``Context`` so downstream
provider code never imports from ``mcp.server.auth.middleware.auth_context``
or other SDK internals. The ``Context`` is still available via
:attr:`RequestContext.mcp_context` for advanced integrations that need it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from mcp.server.fastmcp import Context as _SDKContext

if TYPE_CHECKING:
    from collections.abc import Mapping

# ``Context`` is generic — pre-parametrized for the boundary type so we
# don't sprinkle ``Context[Any, Any, Any]`` through every tool signature.
MCPContext = _SDKContext[Any, Any, Any]
Context = _SDKContext  # public re-export for callers that want the raw class


Transport = Literal["stdio", "http", "sse"]


def _empty_claims() -> Mapping[str, object]:
    """Typed default for ``Principal.claims``.

    A bare ``dict`` default factory yields ``dict[Unknown, Unknown]`` to
    basedpyright; this gives an explicit ``Mapping[str, object]`` instead.
    """
    return {}


@dataclass(frozen=True, slots=True)
class Principal:
    """The authenticated caller for a single MCP request.

    ``id`` is the stable caller identifier — used as the cache key for any
    per-tenant resource (DB rows, decrypted credentials, client instances).
    ``scopes`` is a frozen set so membership checks are O(1) and the value
    itself is hashable. ``claims`` carries any additional JWT / introspection
    fields the verifier chose to forward (e.g. ``preferred_username``,
    ``org_id``). ``raw_token`` is the escape hatch for OAuth-passthrough
    flows where the provider needs to forward the token upstream.
    """

    id: str
    scopes: frozenset[str] = frozenset()
    claims: Mapping[str, object] = field(default_factory=_empty_claims)
    raw_token: str | None = None


@dataclass(frozen=True, slots=True)
class RequestContext:
    """Library-owned context passed to every ``ClientProvider`` method.

    ``transport`` indicates where the request came from. ``request_id`` is
    the MCP-level request id (useful for log correlation). ``principal`` is
    ``None`` only for unauthenticated stdio — when ``token_verifier=`` or
    ``dev_auth=`` is set on ``build_server``, every request that reaches a
    provider will have a populated ``principal``. ``headers`` is the
    request's HTTP headers (empty for stdio). ``mcp_context`` is the raw
    FastMCP ``Context`` — kept as an escape hatch for advanced needs (e.g.
    ``await ctx.mcp_context.report_progress(...)``); provider code that
    sticks to the documented surface should never need it.
    """

    transport: Transport
    request_id: str
    principal: Principal | None
    headers: Mapping[str, str]
    mcp_context: MCPContext
