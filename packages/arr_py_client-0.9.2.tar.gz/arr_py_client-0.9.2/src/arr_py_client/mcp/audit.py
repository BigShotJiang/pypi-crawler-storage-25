"""Audit event types and the default logger-backed sink.

Every tool invocation emits one :class:`AuditEvent` — successes AND
failures (auth, scope, client-not-configured, provider exceptions). The
status enum has six distinct values so a security-conscious deployment
can distinguish "user X tried mutate without scope" from "tool genuinely
errored upstream" — both are interesting, both are auditable.

``error_class`` is the exception type name only — never the message, never
a traceback. A 401 from upstream Radarr might surface a URL or token
fragment in its message; the class name ``HTTPStatusError`` is safe.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Literal

logger = logging.getLogger("arr_py_client.mcp.audit")

AuditStatus = Literal[
    "ok",
    "tool_error",
    "auth_required",
    "scope_denied",
    "client_not_configured",
    "provider_error",
]


@dataclass(frozen=True, slots=True)
class ScopeCheckSummary:
    """Outcome of a per-tool scope check.

    ``required`` is what the tool declared. ``granted`` is what the
    principal carried. ``result`` is ``"passed"`` when granted is a
    superset of required, ``"failed"`` when it isn't, and ``"skipped"``
    when no scope check ran (no auth configured).
    """

    required: tuple[str, ...]
    granted: frozenset[str]
    result: Literal["passed", "skipped", "failed"]


@dataclass(frozen=True, slots=True)
class AuditEvent:
    """Structured event emitted after every tool invocation.

    Args summarization is decorator's responsibility — full payloads
    (release bodies, sync plans) are truncated to length-or-shape
    placeholders so audit sinks don't accumulate PII / credentials.
    """

    request_id: str
    tool_name: str
    principal_id: str | None
    instance_id: str | None
    args_summary: Mapping[str, object]
    started_at: float
    duration_ms: float
    status: AuditStatus
    scope_check: ScopeCheckSummary | None = None
    error_class: str | None = None


AuditCallback = Callable[[AuditEvent], None] | Callable[[AuditEvent], Awaitable[None]]


def default_log_sink(event: AuditEvent) -> None:
    """Default sink: logs each event at INFO via stdlib logging.

    Active when ``build_server(audit=...)`` is omitted, so baseline
    observability works out-of-the-box. Drops to DEBUG for ``ok``
    events, INFO for everything else — successful tool calls are
    high-volume and uninteresting compared to failures.
    """
    extra = {
        "request_id": event.request_id,
        "tool_name": event.tool_name,
        "principal_id": event.principal_id,
        "instance_id": event.instance_id,
        "args_summary": dict(event.args_summary),
        "duration_ms": event.duration_ms,
        "status": event.status,
        "scope_check": (
            {
                "required": list(event.scope_check.required),
                "granted": sorted(event.scope_check.granted),
                "result": event.scope_check.result,
            }
            if event.scope_check is not None
            else None
        ),
        "error_class": event.error_class,
    }
    if event.status == "ok":
        logger.debug("arr_mcp.tool_invoke", extra=extra)
    else:
        logger.info("arr_mcp.tool_invoke", extra=extra)
