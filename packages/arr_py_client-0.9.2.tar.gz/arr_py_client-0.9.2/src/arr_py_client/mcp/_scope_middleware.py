"""ASGI middleware that translates ``insufficient_scope`` envelopes
into RFC 6750 §3.1 compliant ``403 + WWW-Authenticate`` HTTP responses.

The decorator layer always returns a structured envelope (rather than
raising) so FastMCP's generic ``-32603`` handler doesn't strip our
``action_hints``. For HTTP transports we ALSO want the spec-compliant
``WWW-Authenticate`` header so client agents can programmatically
detect "I need to re-auth with escalated scopes" rather than guess.

This middleware sits between the bearer auth middleware and the MCP
dispatcher. It buffers the JSON-RPC response body, looks for the
``insufficient_scope`` shape, and rewrites the HTTP envelope on a hit.

For stdio there is no HTTP layer so this middleware is never mounted —
the JSON envelope alone is the response. The decorator-layer body
shape is identical between transports.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

    from pydantic import AnyHttpUrl
    from starlette.types import ASGIApp, Message, Receive, Scope, Send


def _build_www_authenticate(
    *,
    scopes: list[str],
    description: str,
    resource_metadata_url: str | None,
) -> str:
    """Compose the RFC 6750 §3.1 ``WWW-Authenticate`` header value.

    Quoting matches the BNF in the spec — values are quoted-strings and
    the ``scope`` parameter joins multiple scopes with single spaces.
    """
    parts: list[str] = ['Bearer error="insufficient_scope"']
    parts.append(f'scope="{" ".join(scopes)}"')
    parts.append(f'error_description="{description}"')
    if resource_metadata_url:
        parts.append(f'resource_metadata="{resource_metadata_url}"')
    return ", ".join(parts)


def make_scope_middleware(
    *,
    resource_metadata_url: AnyHttpUrl | str | None,
) -> Callable[[ASGIApp], ASGIApp]:
    """Return an ASGI middleware factory.

    ``resource_metadata_url`` becomes the ``resource_metadata`` parameter
    in the ``WWW-Authenticate`` header — this is what an MCP client
    follows to discover the auth server. ``None`` is acceptable but
    leaves clients with less to discover; pass it whenever PRM is
    configured.
    """
    rmu = str(resource_metadata_url) if resource_metadata_url is not None else None

    def factory(app: ASGIApp) -> ASGIApp:
        async def middleware(scope: Scope, receive: Receive, send: Send) -> None:
            if scope["type"] != "http":
                await app(scope, receive, send)
                return

            response_started = False
            response_status = 200
            response_headers: list[tuple[bytes, bytes]] = []
            body_chunks: list[bytes] = []

            async def buffered_send(message: Message) -> None:
                nonlocal response_started, response_status, response_headers
                if message["type"] == "http.response.start":
                    response_started = True
                    response_status = message["status"]
                    response_headers = list(message.get("headers", []))
                    return
                if message["type"] == "http.response.body":
                    body_chunks.append(message.get("body", b""))
                    if message.get("more_body"):
                        return
                    full_body = b"".join(body_chunks)
                    rewritten = _maybe_rewrite(
                        status=response_status,
                        headers=response_headers,
                        body=full_body,
                        resource_metadata_url=rmu,
                    )
                    if rewritten is None:
                        # Pass through unchanged.
                        await send(
                            {
                                "type": "http.response.start",
                                "status": response_status,
                                "headers": response_headers,
                            }
                        )
                        await send(
                            {
                                "type": "http.response.body",
                                "body": full_body,
                                "more_body": False,
                            }
                        )
                        return
                    new_status, new_headers, new_body = rewritten
                    await send(
                        {
                            "type": "http.response.start",
                            "status": new_status,
                            "headers": new_headers,
                        }
                    )
                    await send(
                        {
                            "type": "http.response.body",
                            "body": new_body,
                            "more_body": False,
                        }
                    )
                    return

            await app(scope, receive, buffered_send)
            if not response_started:
                # Nothing to rewrite; downstream never sent a response.
                return

        return middleware

    return factory


def _maybe_rewrite(
    *,
    status: int,
    headers: list[tuple[bytes, bytes]],
    body: bytes,
    resource_metadata_url: str | None,
) -> tuple[int, list[tuple[bytes, bytes]], bytes] | None:
    """Detect an insufficient-scope envelope inside a JSON-RPC response.

    Returns ``None`` if the body doesn't match (pass-through). Returns
    new ``(status, headers, body)`` if it should be rewritten to a 403
    with the ``WWW-Authenticate`` header.
    """
    if not body:
        return None
    try:
        parsed: Any = json.loads(body)
    except (json.JSONDecodeError, ValueError):
        return None

    envelope = _find_insufficient_scope(parsed)
    if envelope is None:
        return None

    err: Any = envelope["error"]
    required_raw: Any = err.get("required") or []
    required: list[str] = [str(s) for s in required_raw]
    description = str(
        err.get("message", "the supplied token lacks the required scopes")
    )
    challenge = _build_www_authenticate(
        scopes=required,
        description=description,
        resource_metadata_url=resource_metadata_url,
    )

    new_headers = [(k, v) for k, v in headers if k.lower() != b"www-authenticate"]
    new_headers.append((b"www-authenticate", challenge.encode("latin-1")))

    new_status = 403 if status < 400 else status
    return new_status, new_headers, body


def _find_insufficient_scope(parsed: Any) -> dict[str, Any] | None:
    """Walk a JSON-RPC response shape looking for the structured envelope.

    JSON-RPC responses can be objects or batch arrays; tool results live
    at ``result.structuredContent`` for the official Python SDK. We
    accept either shape and look for the ``error.type == "insufficient_scope"``
    marker our decorator emits.
    """
    from typing import cast as _cast

    if isinstance(parsed, list):
        items = _cast("list[Any]", parsed)
        for item in items:
            found = _find_insufficient_scope(item)
            if found is not None:
                return found
        return None
    if not isinstance(parsed, dict):
        return None
    direct = _cast("dict[str, Any]", parsed)
    err = _cast("Any", direct.get("error"))
    if (
        isinstance(err, dict)
        and _cast("dict[str, Any]", err).get("type") == "insufficient_scope"
    ):
        return direct
    result = _cast("Any", direct.get("result"))
    if isinstance(result, dict):
        sc = _cast("Any", _cast("dict[str, Any]", result).get("structuredContent"))
        if isinstance(sc, dict):
            sc_dict = _cast("dict[str, Any]", sc)
            inner_err = _cast("Any", sc_dict.get("error"))
            if (
                isinstance(inner_err, dict)
                and _cast("dict[str, Any]", inner_err).get("type")
                == "insufficient_scope"
            ):
                return sc_dict
    return None
