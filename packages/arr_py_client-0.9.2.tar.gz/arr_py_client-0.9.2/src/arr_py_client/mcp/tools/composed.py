"""Cross-brand composed MCP tools (``arr_*`` prefix).

These collapse multi-step workflows into one tool call and return structured
payloads with ``_meta.action_hints`` — the next most useful tool calls from
here — so LLMs can chain operations without guessing.

Each tool resolves its Arr client(s) via the ``ClientProvider`` per request.
Single-brand tools take one ``instance_id``; cross-brand tools take
per-brand ``{brand}_instance_id`` kwargs. ``ctx`` is FastMCP-injected and
used for progress / log messages on long-running tools.
"""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

import contextlib
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, Literal, cast

# ``MCPContext`` must be importable at runtime — FastMCP evaluates tool-param
# annotations via ``inspect.signature(eval_str=True)`` to build schemas. We
# import the pre-parametrized alias so tool signatures don't need explicit
# generic args (which basedpyright would otherwise complain about).
from arr_py_client.mcp.context import MCPContext as Context  # noqa: TC001
from arr_py_client.mcp.projection import project
from arr_py_client.mcp.tools._shared import error, resolve_or_error

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.mcp._decorators import ToolDeps
    from arr_py_client.mcp.provider import ClientProvider


def _library_health_dict(summary: Any) -> dict[str, Any]:
    """Flatten a ``LibraryHealth`` into a JSON-ready dict for MCP payloads."""
    out = asdict(summary)
    out["disks"] = [
        {
            **d,
            "free_percent": (
                round(100.0 * d["free_bytes"] / d["total_bytes"], 2)
                if d.get("free_bytes") is not None
                and d.get("total_bytes")
                and d["total_bytes"] > 0
                else None
            ),
        }
        for d in out.get("disks", [])
    ]
    return out


def _request_context_from(mcp_ctx: Context):
    """Build a minimal :class:`RequestContext` for composed-tool use.

    Brand tools get a full context built by the decorator; composed tools
    call ``resolve_or_error`` directly so we re-run the adaptation here.
    Keeps composed tools decoupled from ``_decorators.py``.
    """
    from arr_py_client.mcp._decorators import build_request_context

    return build_request_context(mcp_ctx, dev_auth=None)


async def _safe_info(mcp_ctx: Context, message: str) -> None:
    """Call ``ctx.info`` without failing when there's no live request.

    ``Context.info`` requires a live request context (has a session to
    send log messages to). Tests call tools directly via
    ``server.call_tool`` which doesn't set one up, so we silently
    no-op rather than propagate. In real request flow the message
    reaches the MCP client as a log notification.
    """
    with contextlib.suppress(ValueError, AttributeError, RuntimeError):
        await mcp_ctx.info(message)


def attach_composed_tools(
    server: FastMCP,
    provider: ClientProvider,
    deps: ToolDeps,
    *,
    journal: Any | None = None,
) -> None:
    """Register the high-level, chat-friendly composed tools.

    ``deps.dev_auth`` is threaded into the RequestContext builder so
    scope metadata reflects dev-auth principals. ``deps.audit`` is NOT
    wired into composed tools directly — these tools produce their own
    structured responses and rely on the top-level server audit path
    only via the brand tools they delegate to. (Future: uniform audit
    for composed too; deferred — these tools are pure orchestration.)
    """

    def _ctx(mcp_ctx: Context):
        """Build the RequestContext threaded to provider.resolve_*.

        Carries dev_auth principal through so scope metadata is
        consistent with what brand tools see.
        """
        from arr_py_client.mcp._decorators import build_request_context

        return build_request_context(mcp_ctx, dev_auth=deps.dev_auth)

    @server.tool()
    async def arr_add(
        title: str,
        app: Literal["auto", "radarr", "sonarr"] = "auto",
        quality: str | None = None,
        folder: str | None = None,
        tags: list[str] | None = None,
        monitored: bool = True,
        search_on_add: bool = True,
        if_exists: Literal["skip", "update", "error"] = "skip",
        radarr_instance_id: str | None = None,
        sonarr_instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Add a movie or series to Radarr/Sonarr by title, with name-based options.

        ``app="auto"`` uses whichever brand's lookup returns a match (Radarr
        first). ``quality`` accepts a profile name like ``"HD-1080p"`` or
        ``"4K-HDR"``. ``folder`` is a root-folder path; if omitted and only
        one is configured, it's auto-picked. ``tags`` accepts labels; missing
        ones are created. ``if_exists`` defaults to ``"skip"`` for chat safety
        — re-running the tool won't 409.
        """
        rctx = _ctx(ctx)
        chosen_app: str | None = None
        resource: dict[str, Any] | None = None
        already_existed = False

        async def try_radarr() -> tuple[bool, dict[str, Any] | None]:
            radarr, err = await resolve_or_error(
                provider.resolve_radarr,
                rctx,
                radarr_instance_id,
                brand="radarr",
            )
            if err is not None:
                return False, None
            results = await radarr.movies.lookup(term=title)
            if not results:
                return False, None
            movie = await radarr.movies.add(
                title=title,
                quality=quality,
                root_folder=folder,
                tags=list(tags) if tags is not None else None,
                monitored=monitored,
                search_on_add=search_on_add,
                if_exists=if_exists,
            )
            return True, project(movie, "all")

        async def try_sonarr() -> tuple[bool, dict[str, Any] | None]:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr,
                rctx,
                sonarr_instance_id,
                brand="sonarr",
            )
            if err is not None:
                return False, None
            results = await sonarr.series.lookup(term=title)
            if not results:
                return False, None
            series = await sonarr.series.add(
                title=title,
                quality=quality,
                root_folder=folder,
                tags=list(tags) if tags is not None else None,
                monitored=monitored,
                search_on_add=search_on_add,
                if_exists=if_exists,
            )
            return True, project(series, "all")

        attempts: list[tuple[str, Any]] = []
        if app in ("auto", "radarr"):
            attempts.append(("radarr", try_radarr))
        if app in ("auto", "sonarr"):
            attempts.append(("sonarr", try_sonarr))

        errors: list[str] = []
        for brand, fn in attempts:
            try:
                hit, data = await fn()
            except Exception as exc:
                errors.append(f"{brand}: {exc}")
                continue
            if hit:
                chosen_app = brand
                resource = data
                break

        if chosen_app is None:
            return {
                "ok": False,
                "error": f"no lookup match for {title!r}",
                "errors": errors,
                "_meta": {
                    "action_hints": [
                        "arr_list_instances()",
                        "arr_list_resources()",
                        "radarr_movies_lookup(term=...)",
                        "sonarr_series_lookup(term=...)",
                    ]
                },
            }

        return {
            "ok": True,
            "app": chosen_app,
            "already_existed": already_existed,
            "data": resource,
            "_meta": {
                "action_hints": [
                    f"{chosen_app}_command_post(name='RescanMovie' | 'RescanSeries')",
                    "arr_health()",
                ],
            },
        }

    @server.tool()
    async def arr_health(
        app: Literal["both", "radarr", "sonarr", "all"] = "both",
        radarr_instance_id: str | None = None,
        sonarr_instance_id: str | None = None,
        prowlarr_instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """One-shot cross-app health dashboard.

        Brands the caller can't resolve are silently skipped — this is a
        health check, not an error condition. ``app="all"`` also includes
        Prowlarr (indexer + application test summary). Per-brand
        ``instance_id`` kwargs select a specific instance when the caller
        has multiple.
        """
        rctx = _ctx(ctx)
        out: dict[str, Any] = {}
        hints: list[str] = []
        include_radarr = app in ("both", "all", "radarr")
        include_sonarr = app in ("both", "all", "sonarr")
        include_prowlarr = app == "all"

        if include_radarr:
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, radarr_instance_id, brand="radarr"
            )
            if err is None:
                summary = await radarr.library.health_summary()
                out["radarr"] = _library_health_dict(summary)
                if summary.queue.stalled > 0:
                    hints.append("arr_cleanup_queue(app='radarr', dry_run=True)")
                if not summary.healthy:
                    hints.append("radarr_system_status(fields='all')")
        if include_sonarr:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, sonarr_instance_id, brand="sonarr"
            )
            if err is None:
                summary = await sonarr.library.health_summary()
                out["sonarr"] = _library_health_dict(summary)
                if summary.queue.stalled > 0:
                    hints.append("arr_cleanup_queue(app='sonarr', dry_run=True)")
                if not summary.healthy:
                    hints.append("sonarr_system_status(fields='all')")
        if include_prowlarr:
            prowlarr, err = await resolve_or_error(
                provider.resolve_prowlarr,
                rctx,
                prowlarr_instance_id,
                brand="prowlarr",
            )
            if err is None:
                status = await prowlarr.system.list_status()
                indexers = await prowlarr.indexers.list()
                apps = await prowlarr.applications.list()
                out["prowlarr"] = {
                    "version": getattr(status, "version", None),
                    "indexer_count": len(indexers),
                    "application_count": len(apps),
                }
                hints.append("prowlarr_indexer_test_all()")
        out["_meta"] = {"action_hints": hints}
        return out

    @server.tool()
    async def arr_upcoming(
        days: int = 7,
        app: Literal["both", "radarr", "sonarr"] = "both",
        radarr_instance_id: str | None = None,
        sonarr_instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Upcoming (or recently aired) calendar items across one or both apps."""
        from datetime import UTC, datetime, timedelta

        rctx = _ctx(ctx)
        now = datetime.now(UTC)
        start = now if days > 0 else now + timedelta(days=days)
        end = now + timedelta(days=days) if days > 0 else now
        items: dict[str, Any] = {}
        if app in ("both", "radarr"):
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, radarr_instance_id, brand="radarr"
            )
            if err is None:
                radarr_items = await radarr.calendar.list(start=start, end=end)
                items["radarr"] = [project(m, "summary") for m in radarr_items]
        if app in ("both", "sonarr"):
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, sonarr_instance_id, brand="sonarr"
            )
            if err is None:
                sonarr_items = await sonarr.calendar.list(start=start, end=end)
                items["sonarr"] = [project(e, "summary") for e in sonarr_items]
        return {
            "data": items,
            "_meta": {
                "window_days": days,
                "action_hints": [
                    "arr_health()",
                    "arr_find_release(title=..., app=...)",
                ],
            },
        }

    @server.tool()
    async def arr_find_release(
        title: str,
        app: Literal["radarr", "sonarr"],
        min_seeders: int | None = None,
        prefer_codec: str | None = None,
        limit: int = 10,
        indexers: list[int] | None = None,
        include_prowlarr: bool = False,
        instance_id: str | None = None,
        prowlarr_instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Look up a title, then query indexers for candidate releases.

        ``instance_id`` selects which Radarr or Sonarr instance to query
        (based on ``app``); ``prowlarr_instance_id`` picks the Prowlarr
        for fan-out when ``include_prowlarr=True``.
        """
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return error(
                    f"no movie lookup match for {title!r}",
                    hints=["radarr_movies_lookup(term=...)"],
                )
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == hits[0].tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return error(
                    "movie not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='radarr')"],
                )
            candidates: list[Any] = list(
                await radarr.releases.search(movie_id=target.id)
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            hits_s = await sonarr.series.lookup(term=title)
            if not hits_s or not hits_s[0].tvdb_id:
                return error(
                    f"no series lookup match for {title!r}",
                    hints=["sonarr_series_lookup(term=...)"],
                )
            resolved_s = await sonarr.series.list()
            target_s = next(
                (s for s in resolved_s if s.tvdb_id == hits_s[0].tvdb_id and s.id),
                None,
            )
            if target_s is None or target_s.id is None:
                return error(
                    "series not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='sonarr')"],
                )
            candidates = list(await sonarr.releases.search(series_id=target_s.id))

        if indexers is not None:
            indexer_ids = set(indexers)
            candidates = [
                c for c in candidates if getattr(c, "indexer_id", None) in indexer_ids
            ]

        prowlarr_added = 0
        if include_prowlarr:
            prowlarr, err = await resolve_or_error(
                provider.resolve_prowlarr,
                rctx,
                prowlarr_instance_id,
                brand="prowlarr",
            )
            if err is None:
                prowlarr_raw = await prowlarr.search.list_(
                    query=title, indexer_ids=list(indexers) if indexers else None
                )
                known_guids = {
                    str(getattr(c, "guid", "") or "") for c in candidates
                } - {""}
                for item in prowlarr_raw:
                    guid = str(getattr(item, "guid", "") or "")
                    if guid and guid in known_guids:
                        continue
                    candidates.append(item)
                    if guid:
                        known_guids.add(guid)
                    prowlarr_added += 1

        if min_seeders is not None:
            candidates = [
                c
                for c in candidates
                if (getattr(c, "seeders", None) or 0) >= min_seeders
            ]

        def _k(r: Any) -> tuple[int, int, int]:
            seeders = int(getattr(r, "seeders", None) or 0)
            title_str = str(getattr(r, "title", "") or "").lower()
            codec = 1 if prefer_codec and prefer_codec.lower() in title_str else 0
            size = int(getattr(r, "size", None) or 0)
            return (-seeders, -codec, size)

        candidates.sort(key=_k)
        trimmed = candidates[:limit]
        return {
            "ok": True,
            "app": app,
            "candidates": [project(c, "summary") for c in trimmed],
            "_meta": {
                "count": len(trimmed),
                "prowlarr_added": prowlarr_added,
                "indexers_filter": list(indexers) if indexers else None,
                "action_hints": [
                    "arr_grab_release(guid=..., indexer_id=..., app=...)",
                ],
            },
        }

    @server.tool()
    async def arr_grab_release(
        guid: str,
        indexer_id: int,
        app: Literal["radarr", "sonarr"],
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Grab a specific release from :func:`arr_find_release`'s candidates."""
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            await radarr.releases.grab(guid=guid, indexer_id=indexer_id)
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            await sonarr.releases.grab(guid=guid, indexer_id=indexer_id)
        return {
            "ok": True,
            "app": app,
            "_meta": {
                "action_hints": [
                    f"{app}_queue_list()",
                    "arr_health()",
                ]
            },
        }

    @server.tool()
    async def arr_cleanup_queue(
        app: Literal["radarr", "sonarr"],
        dry_run: bool = True,
        blocklist: bool = True,
        search: bool = True,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Find stuck downloads and (optionally) nuke + blocklist + re-search.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            result = await radarr.queue.clear_stuck(
                blocklist=blocklist, search=search, dry_run=dry_run
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            result = await sonarr.queue.clear_stuck(
                blocklist=blocklist, search=search, dry_run=dry_run
            )
        hints: list[str] = []
        if dry_run and result.ids:
            hints.append(f"arr_cleanup_queue(app={app!r}, dry_run=False)")
        if not result.ids:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "dry_run": result.dry_run,
            "ids": result.ids,
            "count": len(result.ids),
            "blocklisted": result.blocklisted,
            "redownload": result.redownload,
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_janitor_run(
        app: Literal["radarr", "sonarr"],
        dry_run: bool = True,
        protected_trackers: list[str] | None = None,
        bundle: Literal[
            "default", "conservative", "aggressive", "ratio_preserving"
        ] = "default",
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Policy-based queue cleanup. More flexible than :func:`arr_cleanup_queue`.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        from arr_py_client import POLICIES

        rctx = _ctx(ctx)
        protected = tuple(protected_trackers or ())
        policies = getattr(POLICIES, bundle)
        await _safe_info(ctx, f"arr_janitor_run: resolving {app} (dry_run={dry_run})")
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            await _safe_info(
                ctx, f"arr_janitor_run: scanning radarr queue with bundle={bundle}"
            )
            report = await radarr.queue.janitor(
                policies=policies,
                dry_run=dry_run,
                protected_trackers=protected,
                journal=journal,
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            await _safe_info(
                ctx, f"arr_janitor_run: scanning sonarr queue with bundle={bundle}"
            )
            report = await sonarr.queue.janitor(
                policies=policies,
                dry_run=dry_run,
                protected_trackers=protected,
                journal=journal,
            )
        hints: list[str] = []
        if dry_run and report.total_matches:
            hints.append(f"arr_janitor_run(app={app!r}, dry_run=False)")
        if not report.total_matches:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "dry_run": report.dry_run,
            "total_matches": report.total_matches,
            "protected_skips": report.protected_skips,
            "executed_blocklist_ids": report.executed_blocklist_ids,
            "executed_remove_ids": report.executed_remove_ids,
            "matches": [
                {
                    "id": m.item_id,
                    "title": m.item_title,
                    "policy": m.policy_name,
                    "action": m.action.value,
                    "indexer": m.indexer,
                }
                for m in report.matches
            ],
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_explain_grab(
        title: str,
        app: Literal["radarr", "sonarr"],
        episode_id: int | None = None,
        season_number: int | None = None,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Answer "why didn't it grab the better version?" for a library item."""
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return error(
                    f"no movie lookup match for {title!r}",
                    hints=["radarr_movies_lookup(term=...)"],
                )
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == hits[0].tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return error(
                    "movie not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='radarr')"],
                )
            explanation = await radarr.releases.explain(movie_id=target.id)
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            hits_s = await sonarr.series.lookup(term=title)
            if not hits_s or not hits_s[0].tvdb_id:
                return error(
                    f"no series lookup match for {title!r}",
                    hints=["sonarr_series_lookup(term=...)"],
                )
            resolved_s = await sonarr.series.list()
            target_s = next(
                (s for s in resolved_s if s.tvdb_id == hits_s[0].tvdb_id and s.id),
                None,
            )
            if target_s is None or target_s.id is None:
                return error(
                    "series not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='sonarr')"],
                )
            explanation = await sonarr.releases.explain(
                series_id=target_s.id,
                episode_id=episode_id,
                season_number=season_number,
            )
        hints = (
            [f"arr_grab_release(guid=..., indexer_id=..., app={app!r})"]
            if explanation.accepted
            else ["arr_health()"]
        )
        return {
            "ok": True,
            "app": app,
            "item_id": explanation.item_id,
            "item_title": explanation.item_title,
            "current_quality": explanation.current_quality,
            "current_custom_format_score": explanation.current_custom_format_score,
            "summary": explanation.summary(),
            "advice": explanation.advice(),
            "verdicts": [
                {
                    "title": v.title,
                    "indexer": v.indexer,
                    "quality": v.quality,
                    "quality_weight": v.quality_weight,
                    "custom_format_score": v.custom_format_score,
                    "size": v.size,
                    "seeders": v.seeders,
                    "age_hours": v.age_hours,
                    "languages": v.languages,
                    "release_group": v.release_group,
                    "status": v.status,
                    "rejections": v.rejections,
                    "guid": v.guid,
                    "indexer_id": v.indexer_id,
                }
                for v in explanation.verdicts
            ],
            "_meta": {
                "accepted_count": len(explanation.accepted),
                "rejected_count": len(explanation.rejected),
                "action_hints": hints,
            },
        }

    @server.tool()
    async def arr_backfill(
        app: Literal["radarr", "sonarr"],
        source: Literal["missing", "cutoff_unmet", "both"] = "missing",
        batch_size: int | None = None,
        delay_between_batches: float = 30.0,
        max_items: int | None = None,
        pause_if_queue_over: int | None = None,
        monitored_only: bool = True,
        dry_run: bool = True,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Rate-limited safe missing-content search loop (Huntarr-shaped).

        **Defaults to ``dry_run=True``** for chat safety.
        """
        rctx = _ctx(ctx)
        effective_batch = (
            batch_size if batch_size is not None else (5 if app == "radarr" else 20)
        )
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            report = await radarr.library.backfill(
                source=source,
                batch_size=effective_batch,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=dry_run,
                journal=journal,
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            report = await sonarr.library.backfill(
                source=source,
                batch_size=effective_batch,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=dry_run,
                journal=journal,
            )
        from arr_py_client._common.backfill import estimate as _estimate

        hints: list[str] = []
        if dry_run and report.searched_count:
            hints.append(f"arr_backfill(app={app!r}, dry_run=False)")
        if report.stopped_reason == "queue_saturated":
            hints.append(f"{app}_queue_list()")
        est = _estimate(
            report.searched_count,
            batch_size=effective_batch,
            delay_between_batches=delay_between_batches,
        )
        return {
            "ok": True,
            "app": app,
            "source": report.source,
            "dry_run": report.dry_run,
            "searched_count": report.searched_count,
            "batches_sent": report.batches_sent,
            "stopped_reason": cast("Any", report.stopped_reason).value,
            "queue_checks": report.queue_checks,
            "searched_ids": report.searched_ids,
            "_meta": {
                "action_hints": hints,
                "estimate": {
                    "batches": est.batches,
                    "duration_seconds": int(est.duration.total_seconds()),
                    "eta_iso": est.eta.isoformat(),
                    "summary": est.summary(),
                },
            },
        }

    @server.tool()
    async def arr_sync_plan(
        app: Literal["radarr", "sonarr"],
        desired: dict[str, Any],
        strict: bool = False,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Preview config-sync changes: diff ``desired`` against the live server."""
        from arr_py_client.config_sync import plan_async as _plan_async

        rctx = _ctx(ctx)
        await _safe_info(ctx, f"arr_sync_plan: resolving {app}")
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        if err is not None:
            return err
        await _safe_info(ctx, f"arr_sync_plan: diffing desired against {app}")
        plan_ = await _plan_async(client, desired, strict=strict)
        hints: list[str] = []
        if plan_.changes:
            hints.append(f"arr_sync_apply(app={app!r}, desired=..., dry_run=False)")
        else:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "strict": plan_.strict,
            "is_noop": plan_.is_noop,
            "summary": plan_.summary(),
            "changes": [
                {
                    "resource": c.resource,
                    "name": c.name,
                    "action": c.action,
                    "existing_id": c.existing_id,
                    "detail": c.detail,
                }
                for c in plan_.changes
            ],
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_sync_apply(
        app: Literal["radarr", "sonarr"],
        desired: dict[str, Any],
        strict: bool = False,
        dry_run: bool = True,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Plan + apply a config-sync desired state. **Defaults to ``dry_run=True``.**"""
        from arr_py_client.config_sync import apply_async as _apply_async
        from arr_py_client.config_sync import plan_async as _plan_async

        rctx = _ctx(ctx)
        await _safe_info(ctx, f"arr_sync_apply: resolving {app} (dry_run={dry_run})")
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        if err is not None:
            return err
        await _safe_info(ctx, f"arr_sync_apply: planning against {app}")
        plan_ = await _plan_async(client, desired, strict=strict)
        await _safe_info(
            ctx,
            f"arr_sync_apply: applying {len(plan_.changes)} changes (dry_run={dry_run})",
        )
        report = await _apply_async(client, plan_, dry_run=dry_run, journal=journal)
        hints: list[str] = []
        if dry_run and plan_.changes:
            hints.append(f"arr_sync_apply(app={app!r}, desired=..., dry_run=False)")
        if report.errors:
            hints.append("arr_list_resources()")
        return {
            "ok": not report.errors,
            "app": app,
            "dry_run": report.dry_run,
            "summary": plan_.summary(),
            "applied_count": len(report.applied),
            "skipped_count": len(report.skipped),
            "error_count": len(report.errors),
            "applied": [
                {"resource": c.resource, "name": c.name, "action": c.action}
                for c in report.applied
            ],
            "errors": [
                {
                    "resource": c.resource,
                    "name": c.name,
                    "action": c.action,
                    "error": err,
                }
                for c, err in report.errors
            ],
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_sync_dump(
        app: Literal["radarr", "sonarr", "prowlarr"],
        include: list[str] | None = None,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Serialize live server state into the dict shape ``arr_sync_plan`` consumes."""
        from arr_py_client.config_sync import dump_async as _dump_async

        rctx = _ctx(ctx)
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        elif app == "sonarr":
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_prowlarr, rctx, instance_id, brand="prowlarr"
            )
        if err is not None:
            return err
        scope = cast("list[Any] | None", list(include) if include else None)
        dumped = await _dump_async(client, include=scope)
        counts: dict[str, int] = {}
        for k, v in dumped.items():
            if isinstance(v, list):
                counts[k] = len(cast("list[Any]", v))
            elif isinstance(v, dict):
                counts[k] = len(cast("dict[str, Any]", v))
            else:
                counts[k] = 1
        return {
            "ok": True,
            "app": app,
            "data": dumped,
            "_meta": {
                "resource_counts": counts,
                "action_hints": [
                    f"arr_sync_plan(app={app!r}, desired=<dumped>)",
                ],
            },
        }

    @server.tool()
    async def arr_bulk_edit(
        app: Literal["radarr", "sonarr"],
        ids: list[int],
        monitored: bool | None = None,
        quality: str | None = None,
        root_folder: str | None = None,
        tags: list[str] | None = None,
        apply_tags: Literal["add", "remove", "replace"] = "add",
        move_files: bool | None = None,
        season_folder: bool | None = None,
        series_type: Literal["standard", "daily", "anime"] | None = None,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Bulk-edit many movies/series in one call."""
        rctx = _ctx(ctx)
        if not ids:
            return error(
                "ids must be non-empty",
                hints=[f"{app}_{'movies' if app == 'radarr' else 'series'}_list()"],
            )
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            await radarr.movies.bulk_edit(
                ids=list(ids),
                monitored=monitored,
                quality=quality,
                root_folder=root_folder,
                tags=list(tags) if tags is not None else None,
                apply_tags=apply_tags,
                move_files=move_files,
                journal=journal,
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            await sonarr.series.bulk_edit(
                ids=list(ids),
                monitored=monitored,
                quality=quality,
                root_folder=root_folder,
                tags=list(tags) if tags is not None else None,
                apply_tags=apply_tags,
                move_files=move_files,
                season_folder=season_folder,
                series_type=series_type,
                journal=journal,
            )
        return {
            "ok": True,
            "app": app,
            "ids": list(ids),
            "count": len(ids),
            "_meta": {
                "action_hints": [
                    f"{app}_{'movies' if app == 'radarr' else 'series'}_list(fields='id,title,tags,monitored')",
                ],
            },
        }

    @server.tool()
    async def arr_trash_import(
        app: Literal["radarr", "sonarr"],
        custom_formats: list[str] | None = None,
        release_profiles: list[str] | None = None,
        quality_definitions: str | None = None,
        ref: str = "master",
        dry_run: bool = True,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> dict[str, Any]:
        """Pull TRaSH-Guides custom formats, release profiles, and/or quality sizes.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        from arr_py_client.config_sync import apply_async as _apply_async
        from arr_py_client.config_sync import plan_async as _plan_async
        from arr_py_client.trash import fetch_desired_state

        rctx = _ctx(ctx)
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        if err is not None:
            return err
        if not custom_formats and not release_profiles and not quality_definitions:
            return error(
                "pass at least one of custom_formats=, release_profiles=, or quality_definitions=",
                hints=[
                    f"arr_trash_import(app={app!r}, custom_formats=[...])",
                    f"arr_trash_import(app={app!r}, release_profiles=[...])",
                    f"arr_trash_import(app={app!r}, quality_definitions='movie')",
                ],
            )
        try:
            desired = fetch_desired_state(
                app,
                custom_formats=custom_formats,
                release_profiles=release_profiles,
                quality_definitions=quality_definitions,
                ref=ref,
            )
        except Exception as exc:
            return error(
                f"trash fetch failed: {exc}",
                hints=[f"arr_trash_import(app={app!r}, custom_formats=[...])"],
            )
        plan_ = await _plan_async(client, desired)
        hints: list[str] = []
        if dry_run and plan_.changes:
            hints.append(
                f"arr_trash_import(app={app!r}, custom_formats={custom_formats!r}, release_profiles={release_profiles!r}, quality_definitions={quality_definitions!r}, ref={ref!r}, dry_run=False)"
            )
        if not plan_.changes:
            hints.append("arr_health()")
        applied_count = 0
        error_count = 0
        if not dry_run and plan_.changes:
            report = await _apply_async(client, plan_, dry_run=False, journal=journal)
            applied_count = len(report.applied)
            error_count = len(report.errors)
        return {
            "ok": error_count == 0,
            "app": app,
            "ref": ref,
            "dry_run": dry_run,
            "fetched_custom_formats": len(desired.get("custom_formats") or {}),
            "fetched_release_profiles": len(desired.get("release_profiles") or {}),
            "fetched_quality_definitions": len(
                desired.get("quality_definitions") or {}
            ),
            "plan_summary": plan_.summary(),
            "applied_count": applied_count,
            "error_count": error_count,
            "_meta": {"action_hints": hints},
        }

    # Silence unused-warnings for function scope; they're registered via decorator.
    _ = (
        arr_add,
        arr_health,
        arr_upcoming,
        arr_find_release,
        arr_grab_release,
        arr_cleanup_queue,
        arr_janitor_run,
        arr_explain_grab,
        arr_backfill,
        arr_sync_plan,
        arr_sync_apply,
        arr_sync_dump,
        arr_bulk_edit,
        arr_trash_import,
    )
