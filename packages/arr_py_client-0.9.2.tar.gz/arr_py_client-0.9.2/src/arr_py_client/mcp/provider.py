"""``ClientProvider`` protocol and built-in implementations.

The provider is the only way to supply Radarr/Sonarr/Prowlarr clients to
the MCP server. Tools never close over a static client — every invocation
goes through ``provider.resolve_*(ctx, instance_id=...)``.

Built-ins:

- :class:`EnvClientProvider` — single-tenant, env-var-backed. What the
  CLI wires up; what local-dev / Claude Desktop / Cursor users get.
- :class:`InMemoryCachedProvider` — abstract base for downstream apps
  that need per-tenant credential lookups with bounded caching.
"""

from __future__ import annotations

import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, Protocol, runtime_checkable

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from arr_py_client.mcp.context import RequestContext
    from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1
    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3
    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3


Brand = Literal["radarr", "sonarr", "prowlarr"]


class ClientNotConfiguredError(LookupError):
    """No client available for this (brand, instance_id, caller).

    Tools convert this into an MCP error envelope with action_hints
    rather than letting it bubble as a JSON-RPC ``-32603``.
    """


@dataclass(frozen=True, slots=True)
class InstanceInfo:
    """One resolvable instance for the current caller.

    Returned by :meth:`ClientProvider.list_instances` so an LLM can
    discover valid ``instance_id`` values before passing them on brand
    tools. ``tags`` is provider-defined opaque metadata that lets agents
    filter ("only the 4k Radarrs") without probing each instance first.
    """

    brand: Brand
    instance_id: str
    label: str | None = None
    is_default: bool = False
    tags: tuple[str, ...] = ()


@runtime_checkable
class ClientProvider(Protocol):
    """Resolves async Arr clients per MCP request.

    Semantics (locked in, not provider-choice):

    - ``instance_id=None`` → resolve the caller's default instance.
      Providers MUST pick deterministically — never fan out.
    - An unknown ``instance_id`` MUST raise
      :class:`ClientNotConfiguredError`.
    - Resolution SHOULD be idempotent per (ctx, instance_id) within a
      single request and SHOULD NOT mutate external state.
    - ``ctx.principal`` is ``None`` only on unauthenticated stdio. When
      auth is configured (``token_verifier=`` or ``dev_auth=`` on
      ``build_server``), it will always be populated.
    """

    async def resolve_radarr(
        self,
        ctx: RequestContext,
        *,
        instance_id: str | None = None,
    ) -> AsyncRadarrClientV3: ...

    async def resolve_sonarr(
        self,
        ctx: RequestContext,
        *,
        instance_id: str | None = None,
    ) -> AsyncSonarrClientV3: ...

    async def resolve_prowlarr(
        self,
        ctx: RequestContext,
        *,
        instance_id: str | None = None,
    ) -> AsyncProwlarrClientV1: ...

    async def list_instances(
        self,
        ctx: RequestContext,
        *,
        brand: Brand | None = None,
    ) -> list[InstanceInfo]:
        """Enumerate instances visible to the current caller.

        Powers the ``arr_list_instances`` tool. Single-instance providers
        SHOULD still return one :class:`InstanceInfo` per configured brand
        with ``is_default=True``.
        """
        ...


class EnvClientProvider:
    """Provider backed by ``RADARR_/SONARR_/PROWLARR_`` env vars.

    Ignores ``ctx`` and ``instance_id`` — returns the same env-configured
    client for every caller. This is what the CLI wires up out-of-the-box.

    Lifecycle: holds the constructed clients for the lifetime of the
    server. Call :meth:`aclose` (or let ``build_server``'s lifespan call
    it on shutdown) to release transports cleanly.
    """

    def __init__(
        self,
        *,
        want_radarr: bool = True,
        want_sonarr: bool = True,
        want_prowlarr: bool = False,
    ) -> None:
        super().__init__()
        # Lazy imports so importing this module doesn't pay for httpx
        # client construction when only the protocol types are needed.
        from arr_py_client import (
            AsyncProwlarrClient,
            AsyncRadarrClient,
            AsyncSonarrClient,
        )

        self._radarr: AsyncRadarrClientV3 | None = (
            AsyncRadarrClient() if want_radarr else None
        )
        self._sonarr: AsyncSonarrClientV3 | None = (
            AsyncSonarrClient() if want_sonarr else None
        )
        self._prowlarr: AsyncProwlarrClientV1 | None = (
            AsyncProwlarrClient() if want_prowlarr else None
        )

    def _check_no_instance_id(self, brand: Brand, instance_id: str | None) -> None:
        if instance_id is not None:
            msg = (
                f"EnvClientProvider has only one {brand} instance; "
                f"instance_id={instance_id!r} is not recognized. "
                f"Call arr_list_instances() to see available instance ids."
            )
            raise ClientNotConfiguredError(msg)

    async def resolve_radarr(
        self,
        ctx: RequestContext,  # noqa: ARG002 — provider-protocol signature
        *,
        instance_id: str | None = None,
    ) -> AsyncRadarrClientV3:
        self._check_no_instance_id("radarr", instance_id)
        if self._radarr is None:
            raise ClientNotConfiguredError(
                "radarr is not configured. Set RADARR_BASE_URL + RADARR_API_KEY."
            )
        return self._radarr

    async def resolve_sonarr(
        self,
        ctx: RequestContext,  # noqa: ARG002
        *,
        instance_id: str | None = None,
    ) -> AsyncSonarrClientV3:
        self._check_no_instance_id("sonarr", instance_id)
        if self._sonarr is None:
            raise ClientNotConfiguredError(
                "sonarr is not configured. Set SONARR_BASE_URL + SONARR_API_KEY."
            )
        return self._sonarr

    async def resolve_prowlarr(
        self,
        ctx: RequestContext,  # noqa: ARG002
        *,
        instance_id: str | None = None,
    ) -> AsyncProwlarrClientV1:
        self._check_no_instance_id("prowlarr", instance_id)
        if self._prowlarr is None:
            raise ClientNotConfiguredError(
                "prowlarr is not configured. Set PROWLARR_BASE_URL + PROWLARR_API_KEY."
            )
        return self._prowlarr

    async def list_instances(
        self,
        ctx: RequestContext,  # noqa: ARG002
        *,
        brand: Brand | None = None,
    ) -> list[InstanceInfo]:
        out: list[InstanceInfo] = []
        if (brand is None or brand == "radarr") and self._radarr is not None:
            out.append(
                InstanceInfo(brand="radarr", instance_id="default", is_default=True)
            )
        if (brand is None or brand == "sonarr") and self._sonarr is not None:
            out.append(
                InstanceInfo(brand="sonarr", instance_id="default", is_default=True)
            )
        if (brand is None or brand == "prowlarr") and self._prowlarr is not None:
            out.append(
                InstanceInfo(brand="prowlarr", instance_id="default", is_default=True)
            )
        return out

    async def aclose(self) -> None:
        for c in (self._radarr, self._sonarr, self._prowlarr):
            if c is not None:
                await c.aclose()


_CacheKey = tuple[str, Brand, str | None]


class InMemoryCachedProvider:
    """Optional base class with a tenant-scoped, bounded, TTL'd cache.

    Subclass and implement :meth:`identity` and :meth:`build_client`. The
    base handles cache-key derivation (always includes caller identity),
    LRU eviction at ``max_size``, TTL expiry, and an
    :meth:`invalidate` hook for credential-rotation events.

    **Per-process only.** Multi-worker deployments need external
    invalidation — broadcast invalidate events via Redis pub/sub or pin
    one user to one worker via sticky sessions. The library can't solve
    coordination across workers it doesn't own.

    Subclasses still implement :meth:`list_instances` themselves — that
    one is application-specific and not amenable to caching at this
    layer.
    """

    def __init__(
        self,
        *,
        max_size: int = 256,
        ttl_seconds: float = 600.0,
    ) -> None:
        super().__init__()
        self._cache: OrderedDict[_CacheKey, tuple[Any, float]] = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl_seconds

    async def identity(self, ctx: RequestContext) -> str:
        """Stable per-caller identity used as the cache key prefix.

        Default: ``ctx.principal.id`` if present, else ``"__anon__"``.
        Override if your scheme keys on something else (org id, JWT
        claim, etc.).
        """
        if ctx.principal is None:
            return "__anon__"
        return ctx.principal.id

    async def build_client(
        self,
        ctx: RequestContext,
        brand: Brand,
        instance_id: str | None,
        identity: str,
    ) -> Any:
        """Build a fresh client. Called only on cache miss.

        Subclasses implement: look up credentials in your store, decrypt,
        return ``AsyncRadarrClient(base_url=..., api_key=...)`` etc.
        Raise :class:`ClientNotConfiguredError` if there's no such instance.
        """
        raise NotImplementedError

    def invalidate(
        self,
        identity: str,
        *,
        brand: Brand | None = None,
        instance_id: str | None = None,
    ) -> None:
        """Evict cached clients matching the given scope.

        Call from your app when:

        - A user rotates credentials → ``invalidate(user_id, brand=...)``
        - A user deletes an instance → ``invalidate(user_id, brand=..., instance_id=...)``
        - A user is deleted entirely → ``invalidate(user_id)``
        - An upstream returns 401 → ``invalidate(user_id, brand=..., instance_id=...)``
          and let the next call rebuild.
        """
        keys_to_drop = [
            k
            for k in self._cache
            if k[0] == identity
            and (brand is None or k[1] == brand)
            and (instance_id is None or k[2] == instance_id)
        ]
        for k in keys_to_drop:
            self._cache.pop(k, None)

    async def _cached(
        self,
        ctx: RequestContext,
        brand: Brand,
        instance_id: str | None,
    ) -> Any:
        identity = await self.identity(ctx)
        key: _CacheKey = (identity, brand, instance_id)
        now = time.monotonic()
        entry = self._cache.get(key)
        if entry is not None:
            client, expires_at = entry
            if expires_at > now:
                self._cache.move_to_end(key)
                return client
            self._cache.pop(key, None)
        client = await self.build_client(ctx, brand, instance_id, identity)
        self._cache[key] = (client, now + self._ttl)
        self._cache.move_to_end(key)
        while len(self._cache) > self._max_size:
            self._cache.popitem(last=False)
        return client

    async def resolve_radarr(
        self,
        ctx: RequestContext,
        *,
        instance_id: str | None = None,
    ) -> AsyncRadarrClientV3:
        return await self._cached(ctx, "radarr", instance_id)

    async def resolve_sonarr(
        self,
        ctx: RequestContext,
        *,
        instance_id: str | None = None,
    ) -> AsyncSonarrClientV3:
        return await self._cached(ctx, "sonarr", instance_id)

    async def resolve_prowlarr(
        self,
        ctx: RequestContext,
        *,
        instance_id: str | None = None,
    ) -> AsyncProwlarrClientV1:
        return await self._cached(ctx, "prowlarr", instance_id)

    async def list_instances(
        self,
        ctx: RequestContext,
        *,
        brand: Brand | None = None,
    ) -> list[InstanceInfo]:
        msg = (
            "InMemoryCachedProvider subclasses must implement list_instances"
            " to enumerate instances visible to the current caller."
        )
        raise NotImplementedError(msg)


# A simple closure-based provider factory for tests / dev. Lets you spin
# up a provider from existing client instances without subclassing.
def static_provider(
    *,
    radarr: AsyncRadarrClientV3 | None = None,
    sonarr: AsyncSonarrClientV3 | None = None,
    prowlarr: AsyncProwlarrClientV1 | None = None,
    list_instances: (
        Callable[[RequestContext, Brand | None], Awaitable[list[InstanceInfo]]] | None
    ) = None,
) -> ClientProvider:
    """Build a ``ClientProvider`` from pre-constructed clients.

    Convenience for tests and one-off scripts that want to drive the MCP
    server with already-built clients (the way 0.7.x did it). Useful in
    test_mcp_*.py to avoid repeating the same wrapper boilerplate.
    """

    class _Static:
        async def resolve_radarr(
            self,
            ctx: RequestContext,  # noqa: ARG002
            *,
            instance_id: str | None = None,
        ) -> AsyncRadarrClientV3:
            if instance_id is not None:
                raise ClientNotConfiguredError(
                    f"static_provider has no radarr instance {instance_id!r}"
                )
            if radarr is None:
                raise ClientNotConfiguredError("radarr is not configured")
            return radarr

        async def resolve_sonarr(
            self,
            ctx: RequestContext,  # noqa: ARG002
            *,
            instance_id: str | None = None,
        ) -> AsyncSonarrClientV3:
            if instance_id is not None:
                raise ClientNotConfiguredError(
                    f"static_provider has no sonarr instance {instance_id!r}"
                )
            if sonarr is None:
                raise ClientNotConfiguredError("sonarr is not configured")
            return sonarr

        async def resolve_prowlarr(
            self,
            ctx: RequestContext,  # noqa: ARG002
            *,
            instance_id: str | None = None,
        ) -> AsyncProwlarrClientV1:
            if instance_id is not None:
                raise ClientNotConfiguredError(
                    f"static_provider has no prowlarr instance {instance_id!r}"
                )
            if prowlarr is None:
                raise ClientNotConfiguredError("prowlarr is not configured")
            return prowlarr

        async def list_instances(
            self,
            ctx: RequestContext,
            *,
            brand: Brand | None = None,
        ) -> list[InstanceInfo]:
            if list_instances is not None:
                return await list_instances(ctx, brand)
            out: list[InstanceInfo] = []
            if (brand is None or brand == "radarr") and radarr is not None:
                out.append(
                    InstanceInfo(brand="radarr", instance_id="default", is_default=True)
                )
            if (brand is None or brand == "sonarr") and sonarr is not None:
                out.append(
                    InstanceInfo(brand="sonarr", instance_id="default", is_default=True)
                )
            if (brand is None or brand == "prowlarr") and prowlarr is not None:
                out.append(
                    InstanceInfo(
                        brand="prowlarr", instance_id="default", is_default=True
                    )
                )
            return out

    return _Static()
