"""Default per-tool scope assignments.

The library opinion is two-tier: ``mcp:arr:read`` for anything that only
observes upstream state, ``mcp:arr:mutate`` for anything that changes it
(or kicks off a command that will). Deployments that want a finer
taxonomy (``mcp:arr:radarr:queue:janitor``, etc.) override the whole map
via ``build_server(scope_overrides=...)``.

The defaults exist so an opinionated ship is possible — they are NOT a
canonical MCP scope vocabulary. Treat them as a sensible starting point
to remap from.
"""

from __future__ import annotations

from typing import Final

SCOPE_READ: Final = "mcp:arr:read"
SCOPE_MUTATE: Final = "mcp:arr:mutate"


# Default scopes for every tool the library ships. Keys must match the
# exact tool name registered with FastMCP. Tools not in this map fall
# back to ``[SCOPE_READ]`` (safer default — fail closed on mutation).
DEFAULT_TOOL_SCOPES: Final[dict[str, tuple[str, ...]]] = {
    # ---- Radarr brand tools ----
    "radarr_ping": (SCOPE_READ,),
    "radarr_system_status": (SCOPE_READ,),
    "radarr_movies_list": (SCOPE_READ,),
    "radarr_movies_get": (SCOPE_READ,),
    "radarr_movies_lookup": (SCOPE_READ,),
    "radarr_queue_list": (SCOPE_READ,),
    "radarr_history_list": (SCOPE_READ,),
    "radarr_command_post": (SCOPE_MUTATE,),  # kicks off arbitrary upstream commands
    "radarr_tags_list": (SCOPE_READ,),
    "radarr_blocklist_list": (SCOPE_READ,),
    "radarr_blocklist_delete": (SCOPE_MUTATE,),
    "radarr_log_list": (SCOPE_READ,),
    "radarr_backup_list": (SCOPE_READ,),
    "radarr_backup_restore": (SCOPE_MUTATE,),
    "radarr_manual_import_list": (SCOPE_READ,),
    "radarr_rename_list": (SCOPE_READ,),
    "radarr_release_push": (SCOPE_MUTATE,),  # forces a download
    "radarr_download_clients_list": (SCOPE_READ,),
    # ---- Sonarr brand tools ----
    "sonarr_ping": (SCOPE_READ,),
    "sonarr_system_status": (SCOPE_READ,),
    "sonarr_series_list": (SCOPE_READ,),
    "sonarr_series_get": (SCOPE_READ,),
    "sonarr_series_lookup": (SCOPE_READ,),
    "sonarr_episodes_list": (SCOPE_READ,),
    "sonarr_queue_list": (SCOPE_READ,),
    "sonarr_history_list": (SCOPE_READ,),
    "sonarr_command_post": (SCOPE_MUTATE,),
    "sonarr_blocklist_list": (SCOPE_READ,),
    "sonarr_log_list": (SCOPE_READ,),
    "sonarr_backup_list": (SCOPE_READ,),
    "sonarr_backup_restore": (SCOPE_MUTATE,),
    "sonarr_manual_import_list": (SCOPE_READ,),
    "sonarr_rename_list": (SCOPE_READ,),
    "sonarr_release_push": (SCOPE_MUTATE,),
    "sonarr_download_clients_list": (SCOPE_READ,),
    # ---- Prowlarr brand tools ----
    "prowlarr_ping": (SCOPE_READ,),
    "prowlarr_system_status": (SCOPE_READ,),
    "prowlarr_indexers_list": (SCOPE_READ,),
    "prowlarr_indexer_test_all": (SCOPE_READ,),  # test == probe, no mutation
    "prowlarr_apps_list": (SCOPE_READ,),
    "prowlarr_app_test_all": (SCOPE_READ,),
    "prowlarr_history_list": (SCOPE_READ,),
    "prowlarr_logs_list": (SCOPE_READ,),
    # ---- Composed cross-brand tools ----
    "arr_add": (SCOPE_MUTATE,),
    "arr_health": (SCOPE_READ,),
    "arr_upcoming": (SCOPE_READ,),
    "arr_find_release": (SCOPE_READ,),  # search only
    "arr_grab_release": (SCOPE_MUTATE,),  # actually downloads
    "arr_cleanup_queue": (SCOPE_MUTATE,),
    "arr_janitor_run": (SCOPE_MUTATE,),
    "arr_explain_grab": (SCOPE_READ,),
    "arr_backfill": (SCOPE_MUTATE,),
    "arr_sync_plan": (SCOPE_READ,),  # plan only — no apply
    "arr_sync_apply": (SCOPE_MUTATE,),
    "arr_sync_dump": (SCOPE_READ,),
    "arr_bulk_edit": (SCOPE_MUTATE,),
    "arr_trash_import": (SCOPE_MUTATE,),
    # ---- Describe / metadata tools ----
    "arr_describe_fields": (SCOPE_READ,),
    "arr_list_resources": (SCOPE_READ,),
    "arr_list_instances": (SCOPE_READ,),
    "arr_journal_list": (SCOPE_READ,),
    "arr_agent_status": (SCOPE_READ,),
    "arr_agent_preview": (SCOPE_READ,),  # dry-run only
}


def resolve_scopes(
    tool_name: str,
    overrides: dict[str, tuple[str, ...]] | None = None,
) -> tuple[str, ...]:
    """Return the scopes required for ``tool_name``.

    Order of precedence: caller overrides → library defaults → fallback
    to ``(SCOPE_READ,)``. Tools not present in either map fall back to
    read — never to "no scope required" — so a future tool added without
    explicit scope assignment fails closed in scope-enforcing deployments.
    """
    if overrides is not None and tool_name in overrides:
        return overrides[tool_name]
    return DEFAULT_TOOL_SCOPES.get(tool_name, (SCOPE_READ,))


def all_default_scopes() -> tuple[str, ...]:
    """Sorted unique list of every scope in :data:`DEFAULT_TOOL_SCOPES`.

    Used by ``build_server`` to populate ``AuthSettings.required_scopes``
    and the PRM document's ``scopes_supported`` field.
    """
    seen: set[str] = set()
    for scopes in DEFAULT_TOOL_SCOPES.values():
        seen.update(scopes)
    return tuple(sorted(seen))
