"""MCP server adapter for arr-py-client.

Install with the ``mcp`` extra::

    pip install 'arr-py-client[mcp]'

Local / single-tenant (stdio)::

    arr-py-mcp                            # Radarr + Sonarr via env vars;
                                          # also Prowlarr if PROWLARR_BASE_URL set
    arr-py-mcp --with-prowlarr            # force Prowlarr on
    arr-py-mcp --radarr-only              # Radarr only
    arr-py-mcp --sonarr-only              # Sonarr only
    arr-py-mcp --prowlarr-only            # Prowlarr only

Remote / multi-tenant — build the server programmatically and mount it in
your own FastAPI / ASGI app::

    from arr_py_client.mcp import build_server, CallbackTokenVerifier
    from mcp.server.auth.settings import AuthSettings

    mcp = build_server(
        provider=MyDBProvider(...),
        token_verifier=CallbackTokenVerifier(verify=my_auth.to_principal),
        auth=AuthSettings(issuer_url=..., resource_server_url=...),
    )
    app.mount("/mcp", mcp.streamable_http_app())

Environment variables (for :class:`EnvClientProvider`):
``RADARR_BASE_URL`` / ``RADARR_API_KEY``, ``SONARR_BASE_URL`` /
``SONARR_API_KEY``, ``PROWLARR_BASE_URL`` / ``PROWLARR_API_KEY``.
"""

from arr_py_client.mcp.audit import AuditEvent, AuditStatus, ScopeCheckSummary
from arr_py_client.mcp.auth import (
    CallbackTokenVerifier,
    DevAuth,
    HeaderPassthroughVerifier,
    StaticBearerVerifier,
)
from arr_py_client.mcp.context import Principal, RequestContext, Transport
from arr_py_client.mcp.provider import (
    Brand,
    ClientNotConfiguredError,
    ClientProvider,
    EnvClientProvider,
    InMemoryCachedProvider,
    InstanceInfo,
    static_provider,
)
from arr_py_client.mcp.scopes import DEFAULT_TOOL_SCOPES, SCOPE_MUTATE, SCOPE_READ
from arr_py_client.mcp.server import build_server

__all__ = [
    "DEFAULT_TOOL_SCOPES",
    "SCOPE_MUTATE",
    "SCOPE_READ",
    "AuditEvent",
    "AuditStatus",
    "Brand",
    "CallbackTokenVerifier",
    "ClientNotConfiguredError",
    "ClientProvider",
    "DevAuth",
    "EnvClientProvider",
    "HeaderPassthroughVerifier",
    "InMemoryCachedProvider",
    "InstanceInfo",
    "Principal",
    "RequestContext",
    "ScopeCheckSummary",
    "StaticBearerVerifier",
    "Transport",
    "build_server",
    "static_provider",
]
