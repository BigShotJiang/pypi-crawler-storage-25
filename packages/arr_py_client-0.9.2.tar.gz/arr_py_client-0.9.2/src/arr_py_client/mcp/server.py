"""Build an MCP server exposing curated Radarr/Sonarr/Prowlarr operations as tools.

Every list/get tool returns ``{"data": ..., "_meta": {fields_mode, resource[, hint]}}``.
``fields`` accepts ``"summary"`` (default for lists) | ``"all"`` (default for
single-record gets) | comma-separated subset like ``"id,title,year"``.

When ``fields="summary"``, the ``_meta.hint`` tells the calling LLM how to ask
for more — either ``fields='all'`` or via :func:`arr_describe_fields`.

Paged tools take ``limit`` (max records to return, default 20) and ``offset``
(records to skip, default 0). They return ``_meta.total`` and
``_meta.next_offset`` (``None`` when there are no more rows). ``offset`` is
rounded down to the nearest ``limit`` boundary because the upstream API is
page-based.

Clients are resolved per-request through a :class:`ClientProvider`. For local
single-tenant use pass :class:`EnvClientProvider`; for multi-tenant
deployments supply your own credential-store-backed provider and the
``token_verifier=`` / ``auth=`` kwargs to plumb OAuth 2.1.

Tool implementations live in :mod:`arr_py_client.mcp.tools`, split by group:
one module per brand (``radarr``, ``sonarr``, ``prowlarr``) plus ``composed``
(cross-brand ``arr_*`` tools) and ``describe`` (reference/metadata tools).
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from mcp.server.fastmcp import FastMCP

from arr_py_client.mcp._decorators import ToolDeps
from arr_py_client.mcp.auth import DevAuth, assert_dev_auth_allowed
from arr_py_client.mcp.tools import (
    attach_composed_tools,
    attach_describe_tool,
    attach_prowlarr_tools,
    attach_radarr_tools,
    attach_sonarr_tools,
)

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Mapping, Sequence

    from mcp.server.auth.provider import TokenVerifier
    from mcp.server.auth.settings import AuthSettings

    from arr_py_client.agent import Agent
    from arr_py_client.mcp.audit import AuditCallback
    from arr_py_client.mcp.provider import ClientProvider


logger = logging.getLogger("arr_py_client.mcp")


def build_server(
    *,
    provider: ClientProvider,
    name: str = "arr-py-client",
    journal: Any | None = None,
    agent: Agent | None = None,
    token_verifier: TokenVerifier | None = None,
    auth: AuthSettings | None = None,
    dev_auth: DevAuth | None = None,
    scope_overrides: Mapping[str, Sequence[str]] | None = None,
    audit: AuditCallback | None = None,
    stateless_http: bool = True,
    json_response: bool = True,
    debug: bool = False,
) -> FastMCP:
    """Build a FastMCP server backed by ``provider``.

    ``provider``
        Resolves clients per-request. Use
        :class:`~arr_py_client.mcp.provider.EnvClientProvider` for local
        single-tenant setups or implement :class:`ClientProvider` for
        multi-tenant deployments.

    ``token_verifier`` / ``auth``
        Optional MCP 2025-11 OAuth 2.1 plumbing. When set, the SDK
        enforces bearer validation before any tool runs; the decorator
        layer then reads :func:`get_access_token` to build
        :class:`Principal`. Required for any remote HTTP deployment.

    ``dev_auth``
        Test / local-dev shortcut — pre-fills every request's
        :class:`Principal`. Mutually exclusive with ``token_verifier``.
        Refuses unless ``ARR_PY_MCP_ALLOW_DEV_AUTH=1`` is set in env so
        it can't accidentally ship in production.

    ``scope_overrides``
        Override the library's default tool-to-scopes map. Keys are
        tool names; values are scopes required. Only enforced when the
        caller's :class:`Principal` is populated (i.e., auth or
        ``dev_auth`` is configured). Unauthenticated stdio treats
        scope declarations as advisory metadata.

    ``audit``
        Callback invoked after every tool invocation with an
        :class:`AuditEvent`. Fires on every outcome (success, scope
        denial, provider error, etc.). If omitted, a default logger-
        backed sink still emits INFO records so baseline observability
        works out-of-the-box.

    ``stateless_http`` / ``json_response``
        Recommended production defaults for streamable-http. Ignored
        for stdio.

    Pass ``journal=`` (:class:`arr_py_client.journal.Journal`) to enable
    persistent audit logging of every mutating composed tool
    (``arr_sync_apply``, ``arr_janitor_run``, ``arr_bulk_edit``, etc.).

    Pass ``agent=`` (:class:`arr_py_client.agent.Agent`) to expose
    read-only agent-introspection tools (``arr_agent_status``,
    ``arr_agent_preview``).
    """
    if dev_auth is not None and token_verifier is not None:
        msg = "dev_auth= is mutually exclusive with token_verifier="
        raise ValueError(msg)
    if dev_auth is not None:
        assert_dev_auth_allowed()

    # Normalize scope_overrides into the tuple-of-str shape the decorator expects.
    normalized_overrides: dict[str, tuple[str, ...]] | None = (
        {k: tuple(v) for k, v in scope_overrides.items()}
        if scope_overrides is not None
        else None
    )

    @asynccontextmanager
    async def _lifespan(_server: FastMCP) -> AsyncGenerator[dict[str, Any]]:
        try:
            yield {}
        finally:
            aclose = getattr(provider, "aclose", None)
            if aclose is not None:
                try:
                    await aclose()
                except Exception:
                    logger.warning("provider.aclose raised", exc_info=True)

    fastmcp_kwargs: dict[str, Any] = {
        "name": name,
        "stateless_http": stateless_http,
        "json_response": json_response,
        "debug": debug,
    }
    # Under stateless streamable-http the MCP SDK invokes the session lifespan
    # per request, which would aclose the provider's httpx clients between
    # tool calls and break every subsequent request with "client has been
    # closed". Only wire the shutdown hook for transports where the lifespan
    # actually represents server lifetime (stdio + stateful HTTP); in
    # stateless HTTP the container exit cleans up on its own.
    if not stateless_http:
        fastmcp_kwargs["lifespan"] = _lifespan
    if token_verifier is not None:
        fastmcp_kwargs["token_verifier"] = token_verifier
    if auth is not None:
        fastmcp_kwargs["auth"] = auth

    server = FastMCP(**fastmcp_kwargs)

    deps = ToolDeps(
        audit=audit,
        scope_overrides=normalized_overrides,
        dev_auth=dev_auth,
    )

    attach_radarr_tools(server, provider, deps)
    attach_sonarr_tools(server, provider, deps)
    attach_prowlarr_tools(server, provider, deps)
    attach_composed_tools(server, provider, deps, journal=journal)
    attach_describe_tool(server, provider, deps, journal=journal, agent=agent)
    return server
