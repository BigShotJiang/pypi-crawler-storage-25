"""``TokenVerifier`` adapters and dev/test auth helpers.

Three real classes (not just docs) so an embedding app writes 4 lines,
not 40, of bearer-token plumbing. ``DevAuth`` skips token verification
entirely for tests and local CLI work — guarded by an env var so it
can't be left on accidentally in production.
"""

from __future__ import annotations

import inspect
import os
from typing import TYPE_CHECKING

from mcp.server.auth.provider import AccessToken, TokenVerifier

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from arr_py_client.mcp.context import Principal

    pass


_DEV_AUTH_ENV = "ARR_PY_MCP_ALLOW_DEV_AUTH"


class CallbackTokenVerifier(TokenVerifier):
    """The 90% case. Wraps an async callable that validates a token.

    Usage in an embedding FastAPI app::

        verifier = CallbackTokenVerifier(verify=app_auth.to_principal)
        build_server(provider=..., token_verifier=verifier, auth=AuthSettings(...))

    Where ``app_auth.to_principal(token)`` is an ``async def`` returning
    a :class:`Principal` for the validated token, or ``None`` to reject.
    """

    def __init__(
        self,
        *,
        verify: Callable[[str], Awaitable[Principal | None]],
    ) -> None:
        super().__init__()
        self._verify = verify

    async def verify_token(self, token: str) -> AccessToken | None:
        principal = await self._verify(token)
        if principal is None:
            return None
        return AccessToken(
            token=token,
            client_id=principal.id,
            scopes=list(principal.scopes),
            resource=None,
        )


class HeaderPassthroughVerifier(TokenVerifier):
    """For deployments behind a trusted auth gateway.

    Use when an upstream gateway (Authelia, Cloudflare Access, an
    app-owns-auth proxy) has already validated the user and re-emits
    identity via a header. The library trusts the header and derives a
    :class:`Principal` from it.

    ONLY safe when the gateway strips-and-replaces the header on every
    request — otherwise a client can spoof identity. Document this
    constraint loudly when you wire it up.

    Despite the name, this is implemented as a ``TokenVerifier`` for API
    consistency: the "token" is the header value. The MCP client must
    still send ``Authorization: Bearer <header_value>`` for the SDK's
    bearer middleware to pick it up.
    """

    def __init__(
        self,
        *,
        to_principal: Callable[[str], Principal | Awaitable[Principal | None]],
    ) -> None:
        super().__init__()
        self._to_principal = to_principal

    async def verify_token(self, token: str) -> AccessToken | None:
        result = self._to_principal(token)
        if inspect.isawaitable(result):
            principal = await result
        else:
            principal = result
        if principal is None:
            return None
        return AccessToken(
            token=token,
            client_id=principal.id,
            scopes=list(principal.scopes),
            resource=None,
        )


class StaticBearerVerifier(TokenVerifier):
    """Dev / CI. Accepts exactly one (token, principal) pair.

    Useful in tests where you don't want the indirection of
    :class:`CallbackTokenVerifier`. For production, use one of the others.
    """

    def __init__(self, *, token: str, principal: Principal) -> None:
        super().__init__()
        self._token = token
        self._principal = principal

    async def verify_token(self, token: str) -> AccessToken | None:
        if token != self._token:
            return None
        return AccessToken(
            token=token,
            client_id=self._principal.id,
            scopes=list(self._principal.scopes),
            resource=None,
        )


class DevAuth:
    """Test / local-dev shortcut. Every request gets the same principal.

    Mutually exclusive with ``token_verifier=`` on ``build_server``.
    ``build_server`` refuses to construct unless the env var
    ``ARR_PY_MCP_ALLOW_DEV_AUTH=1`` is set — prevents accidental
    production use.

    Plumbs the principal into :attr:`RequestContext.principal` across
    any transport, including stdio. Eliminates the per-test boilerplate
    of mocking ``TokenVerifier.verify_token`` whenever a test wants to
    exercise scope enforcement.
    """

    def __init__(self, *, principal: Principal) -> None:
        super().__init__()
        self.principal = principal


def assert_dev_auth_allowed() -> None:
    """Raise unless the dev-auth env-var guard is set.

    Called by ``build_server`` when ``dev_auth=`` is supplied. Provides
    a single, explicit kill-switch a deployment can audit at startup.
    """
    if os.environ.get(_DEV_AUTH_ENV) != "1":
        msg = (
            "DevAuth was passed to build_server but the safety env var "
            f"{_DEV_AUTH_ENV}=1 is not set. DevAuth is for tests and local "
            "development only — never enable it in production. If you really "
            f"intend to use it here, set {_DEV_AUTH_ENV}=1 explicitly."
        )
        raise RuntimeError(msg)
