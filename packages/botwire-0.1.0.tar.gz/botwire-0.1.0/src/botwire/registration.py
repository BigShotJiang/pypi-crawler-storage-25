"""Agent registration — explicit, one-time, with terms acceptance."""

import os
import sys

import httpx

from botwire.errors import BotWireError, RegistrationRequired

BASE_URL = os.getenv("BOTWIRE_URL", "https://botwire.dev")
_registered: set[str] = set()


def register(
    agent_id: str,
    accept_terms: bool = False,
    description: str = "",
    capabilities: list[str] | None = None,
    wallet_address: str = "",
) -> dict:
    """
    Register an agent with BotWire. One-time.

    You MUST read the terms at https://botwire.dev/terms
    and set accept_terms=True. This constitutes legal acceptance
    on behalf of the agent's owner/operator.
    """
    if not accept_terms:
        raise RegistrationRequired(agent_id)

    if _debug():
        print(f"[botwire] Registering agent: {agent_id}", file=sys.stderr)

    r = httpx.post(
        f"{BASE_URL}/identity/register",
        json={
            "name": agent_id,
            "description": description,
            "wallet_address": wallet_address,
            "capabilities": capabilities or [],
            "accept_terms": True,
        },
        timeout=15,
    )

    if r.status_code != 200:
        raise BotWireError(f"Registration failed: {r.status_code} {r.text[:200]}")

    _registered.add(agent_id)

    if _debug():
        print(f"[botwire] Registered: {r.json()}", file=sys.stderr)

    return r.json()


def ensure_registered(agent_id: str) -> None:
    """Check if agent is registered. Raises RegistrationRequired if not."""
    if agent_id in _registered:
        return

    # Check server
    r = httpx.get(f"{BASE_URL}/identity/search?capability=", timeout=10)
    if r.status_code == 200:
        results = r.json().get("results", [])
        for agent in results:
            if agent.get("name") == agent_id or agent.get("agent_id") == agent_id:
                _registered.add(agent_id)
                return

    raise RegistrationRequired(agent_id)


def _debug() -> bool:
    return os.getenv("BOTWIRE_DEBUG", "").strip() in ("1", "true", "yes")
