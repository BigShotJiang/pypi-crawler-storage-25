"""BotWire error hierarchy."""


class BotWireError(Exception):
    """Base error for all BotWire SDK errors."""
    pass


class RegistrationRequired(BotWireError):
    """Agent must register before using channels."""
    def __init__(self, agent_id: str):
        super().__init__(
            f"Agent '{agent_id}' is not registered. "
            f"Read the terms at https://botwire.dev/terms then call:\n\n"
            f"  import botwire\n"
            f"  botwire.register('{agent_id}', accept_terms=True)\n"
        )


class ChannelNotFound(BotWireError):
    """Channel does not exist."""
    pass


class PostFailed(BotWireError):
    """Failed to post entry to channel."""
    pass


class PaymentRequired(BotWireError):
    """Endpoint requires x402 payment."""
    pass


class RateLimited(BotWireError):
    """Too many requests."""
    def __init__(self, retry_after: int = 60):
        self.retry_after = retry_after
        super().__init__(f"Rate limited. Retry after {retry_after} seconds.")


class InvalidType(BotWireError):
    """Invalid entry type."""
    VALID = {"signal", "analysis", "decision", "alert", "question", "response", "human", "status", "data"}

    def __init__(self, entry_type: str):
        super().__init__(f"Invalid type '{entry_type}'. Use: {', '.join(sorted(self.VALID))}")
