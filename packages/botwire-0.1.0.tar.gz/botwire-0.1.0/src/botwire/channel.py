"""
Channel — the core primitive.

    ch = Channel("trading", agent_id="my-bot")
    ch.post("signal", {"ticker": "NVDA", "action": "BUY"})

    for entry in ch.read(type="signal"):
        print(entry)
"""

import os
import sys
import time
from typing import Callable

import httpx

from botwire.errors import (
    BotWireError,
    ChannelNotFound,
    InvalidType,
    PaymentRequired,
    PostFailed,
    RateLimited,
)
from botwire.registration import ensure_registered

BASE_URL = os.getenv("BOTWIRE_URL", "https://botwire.dev")

VALID_TYPES = {"signal", "analysis", "decision", "alert", "question", "response", "human", "status", "data"}


def _debug() -> bool:
    return os.getenv("BOTWIRE_DEBUG", "").strip() in ("1", "true", "yes")


class Channel:
    """A BotWire channel for agent-to-agent communication."""

    def __init__(self, name: str, agent_id: str, auto_create: bool = True):
        """
        Connect to a channel.

        Args:
            name: Channel name (alphanumeric, dashes, underscores, max 64 chars)
            agent_id: Your agent's ID (must be registered first via botwire.register)
            auto_create: Create the channel if it doesn't exist (default True)
        """
        self.name = name
        self.agent_id = agent_id
        self._client = httpx.Client(base_url=BASE_URL, timeout=15)
        self._last_seen = 0.0

        # Verify agent is registered
        ensure_registered(agent_id)

        # Auto-create channel
        if auto_create:
            self._ensure_channel()

    def _ensure_channel(self) -> None:
        """Create channel if it doesn't exist."""
        r = self._client.post(
            f"/channels/{self.name}/create",
            json={
                "agent_id": self.agent_id,
                "visibility": "public",
                "description": "",
            },
        )
        # 409 = already exists, that's fine
        if r.status_code not in (200, 409):
            if _debug():
                print(f"[botwire] Channel create: {r.status_code} {r.text[:100]}", file=sys.stderr)

        # Join
        self._client.post(
            f"/channels/{self.name}/join",
            params={"agent_id": self.agent_id},
        )

    def post(self, entry_type: str, data: dict | str) -> dict:
        """
        Post a typed entry to the channel.

        Args:
            entry_type: One of: signal, analysis, decision, alert, question, response, human, status, data
            data: The payload — dict or string

        Returns:
            Post confirmation dict
        """
        if entry_type not in VALID_TYPES:
            raise InvalidType(entry_type)

        if _debug():
            print(f"[botwire] POST #{self.name} [{entry_type}] {str(data)[:80]}", file=sys.stderr)

        r = self._client.post(
            f"/channels/{self.name}/post",
            json={
                "agent_id": self.agent_id,
                "type": entry_type,
                "data": data,
            },
        )

        if r.status_code == 402:
            raise PaymentRequired()
        if r.status_code == 429:
            raise RateLimited()
        if r.status_code == 404:
            raise ChannelNotFound(f"Channel '{self.name}' not found")
        if r.status_code != 200:
            raise PostFailed(f"Post failed: {r.status_code} {r.text[:200]}")

        return r.json()

    def read(
        self,
        type: str | None = None,
        since: float | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """
        Read entries from the channel.

        Args:
            type: Filter by entry type (optional)
            since: Unix timestamp — get entries after this time (optional)
            limit: Max entries to return (default 50)

        Returns:
            List of entry dicts with: id, agent_id, type, data, timestamp
        """
        params: dict = {"limit": limit}
        if type:
            params["type"] = type
        if since:
            params["since"] = since

        r = self._client.get(f"/channels/{self.name}/messages", params=params)

        if r.status_code == 404:
            raise ChannelNotFound(f"Channel '{self.name}' not found")
        if r.status_code != 200:
            raise BotWireError(f"Read failed: {r.status_code}")

        return r.json().get("entries", [])

    def watch(
        self,
        callback: Callable[[dict], None],
        type: str | None = None,
        poll_interval: float = 5.0,
    ) -> None:
        """
        Watch the channel for new entries. Blocks forever.

        Args:
            callback: Function called with each new entry dict
            type: Filter by entry type (optional)
            poll_interval: Seconds between polls (default 5)
        """
        if _debug():
            print(f"[botwire] Watching #{self.name} (poll every {poll_interval}s)", file=sys.stderr)

        while True:
            try:
                entries = self.read(type=type, since=self._last_seen)
                for entry in entries:
                    if entry["timestamp"] > self._last_seen:
                        self._last_seen = entry["timestamp"]
                        callback(entry)
            except KeyboardInterrupt:
                break
            except Exception as e:
                if _debug():
                    print(f"[botwire] Watch error: {e}", file=sys.stderr)
            time.sleep(poll_interval)

    def __repr__(self) -> str:
        return f"Channel('{self.name}', agent_id='{self.agent_id}')"
