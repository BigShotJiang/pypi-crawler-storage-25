"""
Velt Python SDK

A Python SDK for integrating Velt comments, reactions, attachments, and user management
into Django applications with MongoDB backend.
"""

__version__ = '0.1.5'

from .sdk import VeltSDK
from .exceptions import (
    VeltSDKError,
    VeltDatabaseError,
    VeltValidationError,
    VeltTokenError
)
from .models import (
    GetCommentResolverRequest,
    SaveCommentResolverRequest,
    DeleteCommentResolverRequest,
    GetReactionResolverRequest,
    SaveReactionResolverRequest,
    DeleteReactionResolverRequest,
    SaveAttachmentResolverRequest,
    DeleteAttachmentResolverRequest,
    SaveAttachmentResolverData,
    AttachmentResolverMetadata,
    ResolverAttachment,
    GetRecorderResolverRequest,
    SaveRecorderResolverRequest,
    DeleteRecorderResolverRequest,
    PartialRecorderAnnotation,
    PartialRecorderAnnotationEditVersion,
    GetNotificationResolverRequest,
    SaveNotificationResolverRequest,
    DeleteNotificationResolverRequest,
    PartialNotification,
    GetActivityResolverRequest,
    SaveActivityResolverRequest,
    PartialActivityRecord,
    ResolverActions,
    ResolverResponse,
    BaseMetadata,
    ResolverDeleteMetadata,
    PartialCommentAnnotation,
    PartialComment,
    PartialAttachment,
    PartialReactionAnnotation,
    PartialUser,
    PartialTaggedUserContacts,
    GetUserResolverRequest,
    User
)

__all__ = [
    'VeltSDK',
    'VeltSDKError',
    'VeltDatabaseError',
    'VeltValidationError',
    'VeltTokenError',
    'GetCommentResolverRequest',
    'SaveCommentResolverRequest',
    'DeleteCommentResolverRequest',
    'GetReactionResolverRequest',
    'SaveReactionResolverRequest',
    'DeleteReactionResolverRequest',
    'SaveAttachmentResolverRequest',
    'DeleteAttachmentResolverRequest',
    'SaveAttachmentResolverData',
    'AttachmentResolverMetadata',
    'ResolverAttachment',
    'ResolverActions',
    'ResolverResponse',
    'BaseMetadata',
    'ResolverDeleteMetadata',
    'PartialCommentAnnotation',
    'PartialComment',
    'PartialAttachment',
    'PartialReactionAnnotation',
    'PartialUser',
    'PartialTaggedUserContacts',
    'GetUserResolverRequest',
    'User',
    'GetRecorderResolverRequest',
    'SaveRecorderResolverRequest',
    'DeleteRecorderResolverRequest',
    'PartialRecorderAnnotation',
    'PartialRecorderAnnotationEditVersion',
    'GetNotificationResolverRequest',
    'SaveNotificationResolverRequest',
    'DeleteNotificationResolverRequest',
    'PartialNotification',
    'GetActivityResolverRequest',
    'SaveActivityResolverRequest',
    'PartialActivityRecord',
]

