"""
Activity models for Velt SDK
"""
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field
from .base import BaseMetadata


@dataclass
class PartialActivityRecord:
    """
    Partial activity record model

    extra_fields captures arbitrary additional fields not explicitly defined.
    """
    id: str
    changes: Optional[Dict[str, Any]] = None
    entityData: Optional[Any] = None
    entityTargetData: Optional[Any] = None
    displayMessageTemplateData: Optional[Dict[str, Any]] = None
    metadata: Optional[BaseMetadata] = None
    extra_fields: Optional[Dict[str, Any]] = field(default=None)

    _KNOWN_KEYS = {
        'id', 'changes', 'entityData', 'entityTargetData',
        'displayMessageTemplateData', 'metadata'
    }

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, merging extra_fields into result"""
        result: Dict[str, Any] = {
            'id': self.id
        }
        if self.changes is not None:
            result['changes'] = self.changes
        if self.entityData is not None:
            result['entityData'] = self.entityData
        if self.entityTargetData is not None:
            result['entityTargetData'] = self.entityTargetData
        if self.displayMessageTemplateData is not None:
            result['displayMessageTemplateData'] = self.displayMessageTemplateData
        if self.metadata is not None:
            result['metadata'] = self.metadata.to_dict() if isinstance(self.metadata, BaseMetadata) else self.metadata
        if self.extra_fields:
            result.update(self.extra_fields)
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PartialActivityRecord':
        """Create from dictionary, capturing unknown keys into extra_fields"""
        extra_fields = {k: v for k, v in data.items() if k not in cls._KNOWN_KEYS}
        if not extra_fields:
            extra_fields = None

        metadata = data.get('metadata')
        if isinstance(metadata, dict):
            metadata = BaseMetadata.from_dict(metadata)

        return cls(
            id=data.get('id', ''),
            changes=data.get('changes'),
            entityData=data.get('entityData'),
            entityTargetData=data.get('entityTargetData'),
            displayMessageTemplateData=data.get('displayMessageTemplateData'),
            metadata=metadata,
            extra_fields=extra_fields
        )


@dataclass
class GetActivityResolverRequest:
    """Request model for GetActivityResolver endpoint"""
    organizationId: str
    activityIds: Optional[List[str]] = None
    documentIds: Optional[List[str]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GetActivityResolverRequest':
        """Create from dictionary"""
        return cls(
            organizationId=data.get('organizationId', ''),
            activityIds=data.get('activityIds'),
            documentIds=data.get('documentIds')
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {
            'organizationId': self.organizationId
        }
        if self.activityIds is not None:
            result['activityIds'] = self.activityIds
        if self.documentIds is not None:
            result['documentIds'] = self.documentIds
        return result


@dataclass
class SaveActivityResolverRequest:
    """Request model for SaveActivityResolver endpoint"""
    activity: Dict[str, PartialActivityRecord]
    event: Optional[str] = None
    metadata: Optional[BaseMetadata] = None
    organizationId: str = ''

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SaveActivityResolverRequest':
        """Create from dictionary"""
        activity = {}
        if 'activity' in data and data['activity']:
            for activity_id, activity_data in data['activity'].items():
                if isinstance(activity_data, dict):
                    activity[activity_id] = PartialActivityRecord.from_dict(activity_data)
                elif isinstance(activity_data, PartialActivityRecord):
                    activity[activity_id] = activity_data

        metadata = data.get('metadata')
        if isinstance(metadata, dict):
            metadata = BaseMetadata.from_dict(metadata)

        return cls(
            activity=activity,
            event=data.get('event'),
            metadata=metadata,
            organizationId=data.get('organizationId', '')
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {
            'activity': {
                k: v.to_dict() if isinstance(v, PartialActivityRecord) else v
                for k, v in self.activity.items()
            }
        }
        if self.event is not None:
            result['event'] = self.event
        if self.metadata is not None:
            result['metadata'] = self.metadata.to_dict() if isinstance(self.metadata, BaseMetadata) else self.metadata
        if self.organizationId:
            result['organizationId'] = self.organizationId
        return result
