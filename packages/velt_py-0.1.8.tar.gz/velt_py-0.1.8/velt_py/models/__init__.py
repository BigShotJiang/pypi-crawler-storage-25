"""
Velt SDK Models

All models are exported from this module for easy importing.
"""
from .base import BaseMetadata, ResolverDeleteMetadata, ResolverResponse
from .enums import ResolverActions
from .user import PartialUser, PartialTaggedUserContacts, User, GetUserResolverRequest
from .comment import (
    PartialComment,
    PartialCommentAnnotation,
    GetCommentResolverRequest,
    SaveCommentResolverRequest,
    DeleteCommentResolverRequest
)
from .reaction import (
    PartialReactionAnnotation,
    GetReactionResolverRequest,
    SaveReactionResolverRequest,
    DeleteReactionResolverRequest
)
from .recorder import (
    PartialRecorderAnnotation,
    PartialRecorderAnnotationEditVersion,
    GetRecorderResolverRequest,
    SaveRecorderResolverRequest,
    DeleteRecorderResolverRequest
)
from .notification import (
    PartialNotification,
    GetNotificationResolverRequest,
    SaveNotificationResolverRequest,
    DeleteNotificationResolverRequest
)
from .activity import (
    PartialActivityRecord,
    GetActivityResolverRequest,
    SaveActivityResolverRequest
)
from .attachment import (
    PartialAttachment,
    ResolverAttachment,
    AttachmentResolverMetadata,
    SaveAttachmentResolverRequest,
    DeleteAttachmentResolverRequest,
    SaveAttachmentResolverData
)

__all__ = [
    # Base models
    'BaseMetadata',
    'ResolverDeleteMetadata',
    'ResolverResponse',
    # Enums
    'ResolverActions',
    # User models
    'PartialUser',
    'PartialTaggedUserContacts',
    'User',
    'GetUserResolverRequest',
    # Comment models
    'PartialComment',
    'PartialCommentAnnotation',
    'GetCommentResolverRequest',
    'SaveCommentResolverRequest',
    'DeleteCommentResolverRequest',
    # Reaction models
    'PartialReactionAnnotation',
    'GetReactionResolverRequest',
    'SaveReactionResolverRequest',
    'DeleteReactionResolverRequest',
    # Recorder models
    'PartialRecorderAnnotation',
    'PartialRecorderAnnotationEditVersion',
    'GetRecorderResolverRequest',
    'SaveRecorderResolverRequest',
    'DeleteRecorderResolverRequest',
    # Notification models
    'PartialNotification',
    'GetNotificationResolverRequest',
    'SaveNotificationResolverRequest',
    'DeleteNotificationResolverRequest',
    # Activity models
    'PartialActivityRecord',
    'GetActivityResolverRequest',
    'SaveActivityResolverRequest',
    # Attachment models
    'PartialAttachment',
    'ResolverAttachment',
    'AttachmentResolverMetadata',
    'SaveAttachmentResolverRequest',
    'DeleteAttachmentResolverRequest',
    'SaveAttachmentResolverData',
]
