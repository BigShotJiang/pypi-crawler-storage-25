"""
Notification models for Velt SDK
"""
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field


@dataclass
class PartialNotification:
    """
    Partial notification model

    extra_fields captures arbitrary additional fields not explicitly defined.
    """
    notificationId: str
    displayHeadlineMessageTemplate: Optional[str] = None
    displayHeadlineMessageTemplateData: Optional[Dict[str, Any]] = None
    displayBodyMessage: Optional[str] = None
    displayBodyMessageTemplate: Optional[str] = None
    displayBodyMessageTemplateData: Optional[Dict[str, Any]] = None
    notificationSourceData: Optional[Any] = None
    extra_fields: Optional[Dict[str, Any]] = field(default=None)

    _KNOWN_KEYS = {
        'notificationId', 'displayHeadlineMessageTemplate',
        'displayHeadlineMessageTemplateData', 'displayBodyMessage',
        'displayBodyMessageTemplate', 'displayBodyMessageTemplateData',
        'notificationSourceData'
    }

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, merging extra_fields into result"""
        result: Dict[str, Any] = {
            'notificationId': self.notificationId
        }
        if self.displayHeadlineMessageTemplate is not None:
            result['displayHeadlineMessageTemplate'] = self.displayHeadlineMessageTemplate
        if self.displayHeadlineMessageTemplateData is not None:
            result['displayHeadlineMessageTemplateData'] = self.displayHeadlineMessageTemplateData
        if self.displayBodyMessage is not None:
            result['displayBodyMessage'] = self.displayBodyMessage
        if self.displayBodyMessageTemplate is not None:
            result['displayBodyMessageTemplate'] = self.displayBodyMessageTemplate
        if self.displayBodyMessageTemplateData is not None:
            result['displayBodyMessageTemplateData'] = self.displayBodyMessageTemplateData
        if self.notificationSourceData is not None:
            result['notificationSourceData'] = self.notificationSourceData
        if self.extra_fields:
            result.update(self.extra_fields)
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PartialNotification':
        """Create from dictionary, capturing unknown keys into extra_fields"""
        extra_fields = {k: v for k, v in data.items() if k not in cls._KNOWN_KEYS}
        if not extra_fields:
            extra_fields = None

        return cls(
            notificationId=data.get('notificationId', ''),
            displayHeadlineMessageTemplate=data.get('displayHeadlineMessageTemplate'),
            displayHeadlineMessageTemplateData=data.get('displayHeadlineMessageTemplateData'),
            displayBodyMessage=data.get('displayBodyMessage'),
            displayBodyMessageTemplate=data.get('displayBodyMessageTemplate'),
            displayBodyMessageTemplateData=data.get('displayBodyMessageTemplateData'),
            notificationSourceData=data.get('notificationSourceData'),
            extra_fields=extra_fields
        )


@dataclass
class GetNotificationResolverRequest:
    """Request model for GetNotificationResolver endpoint"""
    organizationId: str
    notificationIds: Optional[List[str]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GetNotificationResolverRequest':
        """Create from dictionary"""
        return cls(
            organizationId=data.get('organizationId', ''),
            notificationIds=data.get('notificationIds')
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {
            'organizationId': self.organizationId
        }
        if self.notificationIds is not None:
            result['notificationIds'] = self.notificationIds
        return result


@dataclass
class SaveNotificationResolverRequest:
    """Request model for SaveNotificationResolver endpoint"""
    notifications: Dict[str, PartialNotification]
    organizationId: str = ''

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SaveNotificationResolverRequest':
        """Create from dictionary"""
        notifications = {}
        if 'notifications' in data and data['notifications']:
            for notif_id, notif_data in data['notifications'].items():
                if isinstance(notif_data, dict):
                    notifications[notif_id] = PartialNotification.from_dict(notif_data)
                elif isinstance(notif_data, PartialNotification):
                    notifications[notif_id] = notif_data

        return cls(
            notifications=notifications,
            organizationId=data.get('organizationId', '')
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {
            'notifications': {
                k: v.to_dict() if isinstance(v, PartialNotification) else v
                for k, v in self.notifications.items()
            }
        }
        if self.organizationId:
            result['organizationId'] = self.organizationId
        return result


@dataclass
class DeleteNotificationResolverRequest:
    """Request model for DeleteNotificationResolver endpoint"""
    notificationId: str
    organizationId: str = ''

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DeleteNotificationResolverRequest':
        """Create from dictionary"""
        return cls(
            notificationId=data.get('notificationId', ''),
            organizationId=data.get('organizationId', '')
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {
            'notificationId': self.notificationId
        }
        if self.organizationId:
            result['organizationId'] = self.organizationId
        return result
