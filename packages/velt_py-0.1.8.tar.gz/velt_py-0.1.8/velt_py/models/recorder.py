"""
Recorder models for Velt SDK

Based on Velt API documentation:
https://docs.velt.dev/api-reference/sdk/models/data-models
"""
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field

from .base import BaseMetadata, ResolverDeleteMetadata
from .enums import ResolverActions


@dataclass
class PartialRecorderAnnotationEditVersion:
    """Partial recorder annotation edit version model"""
    from_: Optional[Dict[str, Any]] = None
    attachment: Optional[Dict[str, Any]] = None
    attachments: Optional[List[Dict[str, Any]]] = None
    transcription: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {}
        if self.from_ is not None:
            result['from'] = self.from_
        if self.attachment is not None:
            result['attachment'] = self.attachment
        if self.attachments is not None:
            result['attachments'] = self.attachments
        if self.transcription is not None:
            result['transcription'] = self.transcription
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PartialRecorderAnnotationEditVersion':
        """Create from dictionary"""
        return cls(
            from_=data.get('from'),
            attachment=data.get('attachment'),
            attachments=data.get('attachments'),
            transcription=data.get('transcription')
        )


@dataclass
class PartialRecorderAnnotation:
    """
    Partial recorder annotation model

    extra_fields captures arbitrary additional fields not explicitly defined.
    """
    annotationId: str
    metadata: Optional[BaseMetadata] = None
    from_: Optional[Dict[str, Any]] = None
    transcription: Optional[Dict[str, Any]] = None
    attachment: Optional[Dict[str, Any]] = None
    attachments: Optional[List[Dict[str, Any]]] = None
    chunkUrls: Optional[Dict[str, str]] = None
    recordingEditVersions: Optional[Dict[str, PartialRecorderAnnotationEditVersion]] = None
    extra_fields: Optional[Dict[str, Any]] = field(default=None)

    _KNOWN_KEYS = {
        'annotationId', 'metadata', 'from', 'transcription', 'attachment',
        'attachments', 'chunkUrls', 'recordingEditVersions'
    }

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, merging extra_fields into result"""
        result: Dict[str, Any] = {
            'annotationId': self.annotationId
        }
        if self.metadata is not None:
            result['metadata'] = self.metadata.to_dict() if isinstance(self.metadata, BaseMetadata) else self.metadata
        if self.from_ is not None:
            result['from'] = self.from_
        if self.transcription is not None:
            result['transcription'] = self.transcription
        if self.attachment is not None:
            result['attachment'] = self.attachment
        if self.attachments is not None:
            result['attachments'] = self.attachments
        if self.chunkUrls is not None:
            result['chunkUrls'] = self.chunkUrls
        if self.recordingEditVersions is not None:
            result['recordingEditVersions'] = {
                k: v.to_dict() if isinstance(v, PartialRecorderAnnotationEditVersion) else v
                for k, v in self.recordingEditVersions.items()
            }
        if self.extra_fields:
            result.update(self.extra_fields)
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PartialRecorderAnnotation':
        """Create from dictionary, capturing unknown keys into extra_fields"""
        metadata = None
        if 'metadata' in data and data['metadata']:
            if isinstance(data['metadata'], dict):
                metadata = BaseMetadata.from_dict(data['metadata'])
            elif isinstance(data['metadata'], BaseMetadata):
                metadata = data['metadata']

        recording_edit_versions = None
        if 'recordingEditVersions' in data and data['recordingEditVersions']:
            recording_edit_versions = {}
            for k, v in data['recordingEditVersions'].items():
                if isinstance(v, dict):
                    recording_edit_versions[k] = PartialRecorderAnnotationEditVersion.from_dict(v)
                elif isinstance(v, PartialRecorderAnnotationEditVersion):
                    recording_edit_versions[k] = v

        # Capture unknown keys into extra_fields
        extra_fields = {k: v for k, v in data.items() if k not in cls._KNOWN_KEYS}
        if not extra_fields:
            extra_fields = None

        return cls(
            annotationId=data.get('annotationId', ''),
            metadata=metadata,
            from_=data.get('from'),
            transcription=data.get('transcription'),
            attachment=data.get('attachment'),
            attachments=data.get('attachments'),
            chunkUrls=data.get('chunkUrls'),
            recordingEditVersions=recording_edit_versions,
            extra_fields=extra_fields
        )


@dataclass
class GetRecorderResolverRequest:
    """Request model for GetRecorderResolver endpoint"""
    organizationId: str
    recorderAnnotationIds: Optional[List[str]] = None
    documentIds: Optional[List[str]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GetRecorderResolverRequest':
        """Create from dictionary"""
        return cls(
            organizationId=data.get('organizationId', ''),
            recorderAnnotationIds=data.get('recorderAnnotationIds'),
            documentIds=data.get('documentIds')
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {
            'organizationId': self.organizationId
        }
        if self.recorderAnnotationIds is not None:
            result['recorderAnnotationIds'] = self.recorderAnnotationIds
        if self.documentIds is not None:
            result['documentIds'] = self.documentIds
        return result


@dataclass
class SaveRecorderResolverRequest:
    """Request model for SaveRecorderResolver endpoint"""
    recorderAnnotation: Dict[str, PartialRecorderAnnotation]
    metadata: Optional[BaseMetadata] = None
    event: Optional[ResolverActions] = None

    @property
    def organizationId(self) -> Optional[str]:
        """Get organizationId from metadata if available"""
        return self.metadata.organizationId if self.metadata else None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SaveRecorderResolverRequest':
        """Create from dictionary"""
        recorder_annotation = {}
        if 'recorderAnnotation' in data and data['recorderAnnotation']:
            for ann_id, ann_data in data['recorderAnnotation'].items():
                if isinstance(ann_data, dict):
                    recorder_annotation[ann_id] = PartialRecorderAnnotation.from_dict(ann_data)
                elif isinstance(ann_data, PartialRecorderAnnotation):
                    recorder_annotation[ann_id] = ann_data

        metadata = None
        if 'metadata' in data and data['metadata']:
            if isinstance(data['metadata'], dict):
                metadata = BaseMetadata.from_dict(data['metadata'])
            elif isinstance(data['metadata'], BaseMetadata):
                metadata = data['metadata']

        event = None
        if 'event' in data and data['event']:
            if isinstance(data['event'], str):
                try:
                    event = ResolverActions(data['event'])
                except ValueError:
                    event = data['event']
            elif isinstance(data['event'], ResolverActions):
                event = data['event']
            else:
                event = data['event']

        return cls(
            recorderAnnotation=recorder_annotation,
            metadata=metadata,
            event=event
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {
            'recorderAnnotation': {
                k: v.to_dict() if isinstance(v, PartialRecorderAnnotation) else v
                for k, v in self.recorderAnnotation.items()
            }
        }
        if self.metadata is not None:
            result['metadata'] = self.metadata.to_dict() if isinstance(self.metadata, BaseMetadata) else self.metadata
        if self.event is not None:
            if isinstance(self.event, ResolverActions):
                result['event'] = self.event.value
            else:
                result['event'] = self.event
        return result


@dataclass
class DeleteRecorderResolverRequest:
    """
    Request model for DeleteRecorderResolver endpoint.

    Metadata uses the slim ResolverDeleteMetadata shape. For backward
    compatibility, from_dict() accepts both the old full BaseMetadata shape
    and the new slim shape. metadata is now always populated by the SDK
    (previously it could be undefined for recorder deletes).
    """
    recorderAnnotationId: str
    metadata: Optional[ResolverDeleteMetadata] = None
    event: Optional[ResolverActions] = None

    @property
    def organizationId(self) -> Optional[str]:
        """Get organizationId from metadata if available"""
        return self.metadata.organizationId if self.metadata else None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DeleteRecorderResolverRequest':
        """Create from dictionary"""
        metadata = None
        if 'metadata' in data and data['metadata']:
            metadata = ResolverDeleteMetadata.from_any(data['metadata'])

        event = None
        if 'event' in data and data['event']:
            if isinstance(data['event'], str):
                try:
                    event = ResolverActions(data['event'])
                except ValueError:
                    event = data['event']
            elif isinstance(data['event'], ResolverActions):
                event = data['event']
            else:
                event = data['event']

        return cls(
            recorderAnnotationId=data.get('recorderAnnotationId', ''),
            metadata=metadata,
            event=event
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result: Dict[str, Any] = {
            'recorderAnnotationId': self.recorderAnnotationId
        }
        if self.metadata is not None:
            result['metadata'] = self.metadata.to_dict() if isinstance(self.metadata, (ResolverDeleteMetadata, BaseMetadata)) else self.metadata
        if self.event is not None:
            if isinstance(self.event, ResolverActions):
                result['event'] = self.event.value
            else:
                result['event'] = self.event
        return result
