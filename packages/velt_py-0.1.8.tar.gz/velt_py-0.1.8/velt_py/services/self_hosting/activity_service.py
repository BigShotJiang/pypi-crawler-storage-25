"""
Activity service for managing activities
"""
from typing import Dict, Any, Optional
from pymongo.errors import PyMongoError

from .base_service import BaseService
from ...exceptions import VeltValidationError
from ...models import (
    GetActivityResolverRequest,
    SaveActivityResolverRequest,
    ResolverResponse,
    PartialActivityRecord
)
from ...config import Config


class ActivityService(BaseService):
    """Service for managing activities"""

    def __init__(self, database, config: Optional[Config] = None):
        """
        Initialize activity service

        Args:
            database: DatabaseAdapter instance
            config: Optional Config instance
        """
        super().__init__(database)
        self.collection_name = config.get_collection_name('activities') if config else 'activities'
        self.config = config

    def getActivities(
        self,
        request: GetActivityResolverRequest
    ) -> Dict[str, Any]:
        """
        Get activities based on GetActivityResolverRequest

        Query logic:
        - Filter by top-level organizationId
        - If activityIds provided, filter by id in activityIds
        - If documentIds provided, filter by metadata.documentId in documentIds

        Args:
            request: GetActivityResolverRequest object containing query parameters

        Returns:
            Response dictionary with 'data', 'success', and 'statusCode' keys
        """
        try:
            if not request.organizationId:
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'organizationId is required',
                    'errorCode': 'INVALID_INPUT'
                }

            self._validate_organization_id(request.organizationId)

            # Build query with top-level organizationId
            query: Dict[str, Any] = {'organizationId': request.organizationId}

            # Filter by activityIds if provided
            if request.activityIds:
                query['id'] = {'$in': request.activityIds}

            # Filter by documentIds if provided (mutually exclusive with activityIds)
            elif request.documentIds:
                query['metadata.documentId'] = {'$in': request.documentIds}

            # Execute query using adapter
            activities = self.database.find(self.collection_name, query)

            # Convert to Record<string, PartialActivityRecord> format keyed by id
            result: Dict[str, Dict[str, Any]] = {}
            for activity in activities:
                activity_id = activity.get('id')
                if activity_id:
                    activity.pop('_id', None)
                    partial_activity = PartialActivityRecord.from_dict(activity)
                    result[activity_id] = partial_activity.to_dict()

            return ResolverResponse(data=result, success=True, statusCode=200).to_dict()

        except VeltValidationError as e:
            return {
                'success': False,
                'statusCode': 400,
                'error': str(e),
                'errorCode': 'VALIDATION_ERROR'
            }
        except PyMongoError as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Database error while getting activities: {str(e)}",
                'errorCode': 'DATABASE_ERROR'
            }
        except Exception as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Unexpected error while getting activities: {str(e)}",
                'errorCode': 'INTERNAL_ERROR'
            }

    def saveActivities(
        self,
        request: SaveActivityResolverRequest
    ) -> Dict[str, Any]:
        """
        Save activities based on SaveActivityResolverRequest

        Args:
            request: SaveActivityResolverRequest object containing activities and organizationId

        Returns:
            ResolverResponse format: { 'success': bool, 'statusCode': int }
        """
        try:
            # Get organizationId from top-level or fall back to metadata
            organization_id = request.organizationId
            if not organization_id and request.metadata:
                organization_id = request.metadata.organizationId

            if not organization_id:
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'organizationId is required',
                    'errorCode': 'INVALID_INPUT'
                }

            self._validate_organization_id(organization_id)

            if not request.activity or not isinstance(request.activity, dict):
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'activity must be a non-empty dictionary',
                    'errorCode': 'INVALID_INPUT'
                }

            for activity_id, activity in request.activity.items():
                if not activity_id:
                    continue

                # Convert PartialActivityRecord to dict for saving
                if isinstance(activity, PartialActivityRecord):
                    activity_data = activity.to_dict()
                else:
                    activity_data = activity.copy() if isinstance(activity, dict) else {}

                activity_data['id'] = activity_id
                activity_data['organizationId'] = organization_id

                # Enrich metadata with organizationId and apiKey from config
                if 'metadata' not in activity_data or activity_data['metadata'] is None:
                    activity_data['metadata'] = {}
                if isinstance(activity_data['metadata'], dict):
                    activity_data['metadata']['organizationId'] = organization_id
                    if self.config:
                        api_key = self.config.get_api_key()
                        if api_key:
                            activity_data['metadata']['apiKey'] = api_key

                # Upsert by id + organizationId
                filter_query = {
                    'id': activity_id,
                    'organizationId': organization_id
                }
                update_query = {'$set': activity_data}
                self.database.update_one(
                    self.collection_name,
                    filter_query,
                    update_query,
                    upsert=True
                )

            return {
                'success': True,
                'statusCode': 200
            }

        except VeltValidationError as e:
            return {
                'success': False,
                'statusCode': 400,
                'error': str(e),
                'errorCode': 'VALIDATION_ERROR'
            }
        except PyMongoError as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Database error while saving activities: {str(e)}",
                'errorCode': 'DATABASE_ERROR'
            }
        except Exception as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Unexpected error while saving activities: {str(e)}",
                'errorCode': 'INTERNAL_ERROR'
            }
