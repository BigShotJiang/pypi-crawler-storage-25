"""
Notification service for managing notifications
"""
from typing import Dict, Any, Optional
from pymongo.errors import PyMongoError

from .base_service import BaseService
from ...exceptions import VeltValidationError
from ...models import (
    GetNotificationResolverRequest,
    SaveNotificationResolverRequest,
    DeleteNotificationResolverRequest,
    ResolverResponse,
    PartialNotification
)
from ...config import Config


class NotificationService(BaseService):
    """Service for managing notifications"""

    def __init__(self, database, config: Optional[Config] = None):
        """
        Initialize notification service

        Args:
            database: DatabaseAdapter instance
            config: Optional Config instance
        """
        super().__init__(database)
        self.collection_name = config.get_collection_name('notifications') if config else 'notifications'
        self.config = config

    def getNotifications(
        self,
        request: GetNotificationResolverRequest
    ) -> Dict[str, Any]:
        """
        Get notifications based on GetNotificationResolverRequest

        Query logic:
        - Filter by top-level organizationId (not metadata.organizationId)
        - If notificationIds provided, filter by notificationId in notificationIds
        - No apiKey filtering

        Args:
            request: GetNotificationResolverRequest object containing query parameters

        Returns:
            Response dictionary with 'data', 'success', and 'statusCode' keys
        """
        try:
            if not request.organizationId:
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'organizationId is required',
                    'errorCode': 'INVALID_INPUT'
                }

            self._validate_organization_id(request.organizationId)

            # Build query with top-level organizationId
            query: Dict[str, Any] = {'organizationId': request.organizationId}

            # Filter by notificationIds if provided
            if request.notificationIds:
                query['notificationId'] = {'$in': request.notificationIds}

            # Execute query using adapter
            notifications = self.database.find(self.collection_name, query)

            # Convert to Record<string, PartialNotification> format keyed by notificationId
            result: Dict[str, Dict[str, Any]] = {}
            for notification in notifications:
                notification_id = notification.get('notificationId')
                if notification_id:
                    notification.pop('_id', None)
                    partial_notification = PartialNotification.from_dict(notification)
                    result[notification_id] = partial_notification.to_dict()

            return ResolverResponse(data=result, success=True, statusCode=200).to_dict()

        except VeltValidationError as e:
            return {
                'success': False,
                'statusCode': 400,
                'error': str(e),
                'errorCode': 'VALIDATION_ERROR'
            }
        except PyMongoError as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Database error while getting notifications: {str(e)}",
                'errorCode': 'DATABASE_ERROR'
            }
        except Exception as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Unexpected error while getting notifications: {str(e)}",
                'errorCode': 'INTERNAL_ERROR'
            }

    def saveNotifications(
        self,
        request: SaveNotificationResolverRequest
    ) -> Dict[str, Any]:
        """
        Save notifications based on SaveNotificationResolverRequest

        Args:
            request: SaveNotificationResolverRequest object containing notifications and organizationId

        Returns:
            ResolverResponse format: { 'success': bool, 'statusCode': int }
        """
        try:
            if not request.organizationId:
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'organizationId is required',
                    'errorCode': 'INVALID_INPUT'
                }

            self._validate_organization_id(request.organizationId)

            if not request.notifications or not isinstance(request.notifications, dict):
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'notifications must be a non-empty dictionary',
                    'errorCode': 'INVALID_INPUT'
                }

            for notification_id, notification in request.notifications.items():
                if not notification_id:
                    continue

                # Convert PartialNotification to dict for saving
                if isinstance(notification, PartialNotification):
                    notification_data = notification.to_dict()
                else:
                    notification_data = notification.copy() if isinstance(notification, dict) else {}

                notification_data['notificationId'] = notification_id
                notification_data['organizationId'] = request.organizationId

                # Upsert by notificationId + organizationId
                filter_query = {
                    'notificationId': notification_id,
                    'organizationId': request.organizationId
                }
                update_query = {'$set': notification_data}
                self.database.update_one(
                    self.collection_name,
                    filter_query,
                    update_query,
                    upsert=True
                )

            return {
                'success': True,
                'statusCode': 200
            }

        except VeltValidationError as e:
            return {
                'success': False,
                'statusCode': 400,
                'error': str(e),
                'errorCode': 'VALIDATION_ERROR'
            }
        except PyMongoError as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Database error while saving notifications: {str(e)}",
                'errorCode': 'DATABASE_ERROR'
            }
        except Exception as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Unexpected error while saving notifications: {str(e)}",
                'errorCode': 'INTERNAL_ERROR'
            }

    def deleteNotification(self, request: DeleteNotificationResolverRequest) -> Dict[str, Any]:
        """
        Delete a notification based on DeleteNotificationResolverRequest

        Scopes the delete by organizationId when available, falling back to
        notificationId-only if the scoped query finds nothing.

        Args:
            request: DeleteNotificationResolverRequest object containing notificationId

        Returns:
            ResolverResponse format: { 'success': bool, 'statusCode': int }
        """
        try:
            if not request.notificationId:
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'notificationId is required',
                    'errorCode': 'INVALID_INPUT'
                }

            base_filter: Dict[str, Any] = {
                'notificationId': request.notificationId
            }

            # Try scoped delete first (notificationId + organizationId)
            if request.organizationId:
                scoped_filter = dict(base_filter)
                scoped_filter['organizationId'] = request.organizationId
                result = self.database.delete_one(self.collection_name, scoped_filter)
                deleted_count = getattr(result, 'deleted_count', 1 if result else 0)
                if deleted_count > 0:
                    return {'success': True, 'statusCode': 200}

            # Fallback: delete by notificationId only
            result = self.database.delete_one(self.collection_name, base_filter)
            deleted_count = getattr(result, 'deleted_count', 1 if result else 0)
            if deleted_count == 0:
                return {
                    'success': False,
                    'statusCode': 404,
                    'error': 'Notification not found',
                    'errorCode': 'NOT_FOUND'
                }

            return {
                'success': True,
                'statusCode': 200
            }

        except PyMongoError as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Database error while deleting notification: {str(e)}",
                'errorCode': 'DATABASE_ERROR'
            }
        except Exception as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Unexpected error while deleting notification: {str(e)}",
                'errorCode': 'INTERNAL_ERROR'
            }
