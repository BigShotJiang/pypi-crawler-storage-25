"""
Recorder service for managing recorder annotations
"""
from typing import Dict, Any, Optional
from pymongo.errors import PyMongoError

from .base_service import BaseService
from ...exceptions import VeltValidationError
from ...models import (
    GetRecorderResolverRequest,
    SaveRecorderResolverRequest,
    DeleteRecorderResolverRequest,
    ResolverResponse,
    PartialRecorderAnnotation
)
from ...config import Config


class RecorderService(BaseService):
    """Service for managing recorder annotations"""

    def __init__(self, database, config: Optional[Config] = None):
        """
        Initialize recorder service

        Args:
            database: DatabaseAdapter instance
            config: Optional Config instance for accessing API key
        """
        super().__init__(database)
        self.collection_name = config.get_collection_name('recorder_annotations') if config else 'recorder_annotations'
        self.config = config

    def getRecorderAnnotations(
        self,
        request: GetRecorderResolverRequest
    ) -> Dict[str, Any]:
        """
        Get recorder annotations based on GetRecorderResolverRequest

        Query logic:
        1. If organizationId + documentIds: filter by metadata.organizationId, metadata.documentId in documentIds, metadata.apiKey
        2. If organizationId + recorderAnnotationIds: filter by metadata.organizationId, annotationId in recorderAnnotationIds, metadata.apiKey
        3. If organizationId only: filter by metadata.organizationId, metadata.apiKey

        Args:
            request: GetRecorderResolverRequest object containing query parameters

        Returns:
            Response dictionary with 'data', 'success', and 'statusCode' keys
        """
        try:
            if not request.organizationId:
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'organizationId is required',
                    'errorCode': 'INVALID_INPUT'
                }

            self._validate_organization_id(request.organizationId)

            # Get API key from config if available
            api_key = None
            if self.config:
                api_key = self.config.get_api_key()

            # Build base query with organizationId
            query: Dict[str, Any] = {'metadata.organizationId': request.organizationId}

            # Add apiKey filter if available
            if api_key:
                query['metadata.apiKey'] = api_key

            # Query scenario 1: organizationId + documentIds
            if request.documentIds:
                query['metadata.documentId'] = {'$in': request.documentIds}

            # Query scenario 2: organizationId + recorderAnnotationIds
            elif request.recorderAnnotationIds:
                query['annotationId'] = {'$in': request.recorderAnnotationIds}

            # Scenario 3: organizationId only (no additional filters)

            # Execute query using adapter
            annotations = self.database.find(self.collection_name, query)

            # Convert to Record<string, PartialRecorderAnnotation> format
            result: Dict[str, Dict[str, Any]] = {}
            for annotation in annotations:
                annotation_id = annotation.get('annotationId')
                if annotation_id:
                    annotation.pop('_id', None)
                    partial_annotation = PartialRecorderAnnotation.from_dict(annotation)
                    result[annotation_id] = partial_annotation.to_dict()

            return ResolverResponse(data=result, success=True, statusCode=200).to_dict()

        except VeltValidationError as e:
            return {
                'success': False,
                'statusCode': 400,
                'error': str(e),
                'errorCode': 'VALIDATION_ERROR'
            }
        except PyMongoError as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Database error while getting recorder annotations: {str(e)}",
                'errorCode': 'DATABASE_ERROR'
            }
        except Exception as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Unexpected error while getting recorder annotations: {str(e)}",
                'errorCode': 'INTERNAL_ERROR'
            }

    def saveRecorderAnnotation(
        self,
        request: SaveRecorderResolverRequest
    ) -> Dict[str, Any]:
        """
        Save recorder annotations based on SaveRecorderResolverRequest

        Args:
            request: SaveRecorderResolverRequest object containing recorderAnnotation and metadata

        Returns:
            ResolverResponse format: { 'success': bool, 'statusCode': int }
        """
        try:
            organization_id = None
            if request.metadata:
                organization_id = request.metadata.organizationId

            if not organization_id:
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'organizationId is required in metadata',
                    'errorCode': 'INVALID_INPUT'
                }

            self._validate_organization_id(organization_id)

            if not request.recorderAnnotation or not isinstance(request.recorderAnnotation, dict):
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'recorderAnnotation must be a non-empty dictionary',
                    'errorCode': 'INVALID_INPUT'
                }

            # Get API key from config if available
            api_key = None
            if self.config:
                api_key = self.config.get_api_key()

            # Extract metadata from request
            request_metadata = request.metadata
            document_id = request_metadata.documentId if request_metadata else None

            for annotation_id, annotation in request.recorderAnnotation.items():
                if not annotation_id:
                    continue

                # Convert PartialRecorderAnnotation to dict for saving
                if isinstance(annotation, PartialRecorderAnnotation):
                    annotation_data = annotation.to_dict()
                else:
                    annotation_data = annotation.copy() if isinstance(annotation, dict) else {}

                annotation_data['annotationId'] = annotation_id

                # Initialize metadata if not present
                if 'metadata' not in annotation_data:
                    annotation_data['metadata'] = {}

                # Set organizationId in metadata
                annotation_data['metadata']['organizationId'] = organization_id

                # Set documentId in metadata
                if document_id:
                    annotation_data['metadata']['documentId'] = document_id

                # Set apiKey in metadata if available
                if api_key:
                    annotation_data['metadata']['apiKey'] = api_key
                elif request_metadata and request_metadata.apiKey:
                    annotation_data['metadata']['apiKey'] = request_metadata.apiKey

                # Upsert by annotationId
                filter_query = {'annotationId': annotation_id, 'metadata.organizationId': organization_id}
                update_query = {'$set': annotation_data}
                self.database.update_one(
                    self.collection_name,
                    filter_query,
                    update_query,
                    upsert=True
                )

            return {
                'success': True,
                'statusCode': 200
            }

        except VeltValidationError as e:
            return {
                'success': False,
                'statusCode': 400,
                'error': str(e),
                'errorCode': 'VALIDATION_ERROR'
            }
        except PyMongoError as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Database error while saving recorder annotations: {str(e)}",
                'errorCode': 'DATABASE_ERROR'
            }
        except Exception as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Unexpected error while saving recorder annotations: {str(e)}",
                'errorCode': 'INTERNAL_ERROR'
            }

    def deleteRecorderAnnotation(self, request: DeleteRecorderResolverRequest) -> Dict[str, Any]:
        """
        Delete a recorder annotation based on DeleteRecorderResolverRequest

        Scopes the delete by metadata.organizationId when available to prevent
        cross-org collisions, falling back to annotationId-only if the scoped
        query finds nothing (handles legacy data or ID format mismatches).

        Args:
            request: DeleteRecorderResolverRequest object containing recorderAnnotationId

        Returns:
            ResolverResponse format: { 'success': bool, 'statusCode': int }
        """
        try:
            if not request.recorderAnnotationId:
                return {
                    'success': False,
                    'statusCode': 400,
                    'error': 'recorderAnnotationId is required',
                    'errorCode': 'INVALID_INPUT'
                }

            base_filter: Dict[str, Any] = {
                'annotationId': request.recorderAnnotationId
            }

            # Try scoped delete first (annotationId + organizationId)
            if request.metadata and request.metadata.organizationId:
                scoped_filter = dict(base_filter)
                scoped_filter['metadata.organizationId'] = request.metadata.organizationId
                result = self.database.delete_one(self.collection_name, scoped_filter)
                deleted_count = getattr(result, 'deleted_count', 1 if result else 0)
                if deleted_count > 0:
                    return {'success': True, 'statusCode': 200}

            # Fallback: delete by annotationId only
            result = self.database.delete_one(self.collection_name, base_filter)
            deleted_count = getattr(result, 'deleted_count', 1 if result else 0)
            if deleted_count == 0:
                return {
                    'success': False,
                    'statusCode': 404,
                    'error': 'Recorder annotation not found',
                    'errorCode': 'NOT_FOUND'
                }

            return {
                'success': True,
                'statusCode': 200
            }

        except PyMongoError as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Database error while deleting recorder annotation: {str(e)}",
                'errorCode': 'DATABASE_ERROR'
            }
        except Exception as e:
            return {
                'success': False,
                'statusCode': 500,
                'error': f"Unexpected error while deleting recorder annotation: {str(e)}",
                'errorCode': 'INTERNAL_ERROR'
            }
