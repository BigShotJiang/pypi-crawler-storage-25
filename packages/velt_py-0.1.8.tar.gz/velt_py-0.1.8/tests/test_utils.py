"""Test utilities and mongomock setup"""
import mongomock
from pymongo.database import Database
from velt_py.database.mongodb_adapter import MongoDBAdapter


def get_mock_adapter():
    """
    Get a mock MongoDB adapter and raw database for testing.

    Returns:
        Tuple of (MongoDBAdapter, raw mongomock Database).
        Use the adapter when constructing services, and the raw DB
        for inserting test fixtures and verifying results.
    """
    client = mongomock.MongoClient()
    db = client['test_db']
    adapter = MongoDBAdapter(db)
    return adapter, db


def get_mock_database() -> Database:
    """Get a raw mock MongoDB database using mongomock."""
    client = mongomock.MongoClient()
    return client['test_db']


def get_mock_config():
    """Get a mock configuration for testing."""
    from velt_py.config import Config
    return Config({
        'database': {
            'host': 'localhost:27017',
            'username': 'test_user',
            'password': 'test_pass',
            'auth_database': 'admin',
            'database_name': 'test_db'
        },
        'apiKey': 'test-api-key',
        'authToken': 'test-auth-token'
    })


def cleanup():
    """Reset connection state for testing."""
    try:
        from velt_py.database import reset_connection
        reset_connection()
    except ImportError:
        pass
