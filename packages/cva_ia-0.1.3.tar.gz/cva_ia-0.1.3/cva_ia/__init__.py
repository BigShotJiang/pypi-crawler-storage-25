def display_code(choice):
    def display_code(choice):
        module = __import__(f"cva_ia.p{choice}", fromlist=["display_code"])
        module.display_code()