from setuptools import setup, find_packages

setup(
    name="cva-ia",
    version="0.1.3",
    packages=find_packages(),
)