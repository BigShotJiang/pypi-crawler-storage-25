# picocalc-mcp

MCP server for [PicoCalc](https://github.com/LofiFren/PicoCalc) MicroPython hardware development.

Gives AI coding assistants (Claude Code, Claude Desktop, Cursor) direct access to a PicoCalc device over USB via the [Model Context Protocol](https://modelcontextprotocol.io/).

<!-- mcp-name: io.github.LofiFren/picocalc-mcp -->

## Install

```bash
pip install picocalc-mcp
```

Requires [mpremote](https://docs.micropython.org/en/latest/reference/mpremote.html) (installed automatically as a dependency).

## Setup

### Claude Code

Add to `.mcp.json`:

```json
{
  "mcpServers": {
    "picocalc": {
      "command": "picocalc-mcp"
    }
  }
}
```

### Claude Desktop

Open **Settings > Developer > Edit Config**:

```json
{
  "mcpServers": {
    "picocalc": {
      "command": "picocalc-mcp"
    }
  }
}
```

### Any MCP Client

```bash
picocalc-mcp
```

Or: `python -m picocalc_mcp`

## Tools

| Tool | Description |
|------|-------------|
| `picocalc_status` | Check connection, firmware version, free RAM, SD card space |
| `picocalc_exec` | Run MicroPython code on the device (30s timeout) |
| `picocalc_list_files` | List files at a device path |
| `picocalc_read_file` | Read a file from the device |
| `picocalc_push` | Push a local file to the device |
| `picocalc_reset` | Soft reset (re-runs boot.py and main.py) |

## Requirements

- PicoCalc connected via USB
- Python 3.7+

## Links

- [PicoCalc Project](https://github.com/LofiFren/PicoCalc)
- [Full MCP Setup Guide](https://github.com/LofiFren/PicoCalc/blob/main/MicroPython/tools/MCP_README.md)
- [Claude Code Skills for PicoCalc](https://github.com/LofiFren/code-skills)

## License

MIT
