"""Allow running as: python -m picocalc_mcp"""
from picocalc_mcp.server import main

main()
