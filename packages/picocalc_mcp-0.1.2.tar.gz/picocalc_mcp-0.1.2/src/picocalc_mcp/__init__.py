"""PicoCalc MCP Server -- AI assistant access to PicoCalc hardware over USB."""

__version__ = "0.1.1"
