"""Container registry for the dsm daemon.

Defines the persistent data structures and the ContainerRegistry class used by
the daemon. Models are serialized to JSON files under ~/.dsm/registry/ for
persistence across daemon restarts.

The dataclasses here are pure data — they carry no process handles or runtime
state. This separates them from ports.py's ForwardHandle (which holds a live
subprocess.Popen) and ListeningPort (which is a transient scan result).
"""

from __future__ import annotations

import datetime
import json
import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class PortInfo:
    """A listening port detected inside a container (persistent record)."""

    port: int
    bind_address: str
    protocol: str  # "tcp" or "tcp6"

    def to_dict(self) -> dict:
        return {
            "port": self.port,
            "bind_address": self.bind_address,
            "protocol": self.protocol,
        }

    @classmethod
    def from_dict(cls, data: dict) -> PortInfo:
        return cls(
            port=data["port"],
            bind_address=data["bind_address"],
            protocol=data["protocol"],
        )


@dataclass
class ForwardInfo:
    """A port forward record (persistent — no live process handle)."""

    container_port: int
    host_port: int
    socat_pid: int
    alive: bool = True

    def to_dict(self) -> dict:
        return {
            "container_port": self.container_port,
            "host_port": self.host_port,
            "socat_pid": self.socat_pid,
            "alive": self.alive,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ForwardInfo:
        return cls(
            container_port=data["container_port"],
            host_port=data["host_port"],
            socat_pid=data["socat_pid"],
            alive=data.get("alive", True),
        )


@dataclass
class ContainerEntry:
    """Full registry entry for a container tracked by the daemon."""

    container_name: str
    container_id: str
    container_ip: str
    status: str  # "running", "stopped", "unknown"
    created_at: str  # ISO 8601
    updated_at: str  # ISO 8601
    ports: list[PortInfo] = field(default_factory=list)
    forwards: list[ForwardInfo] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "container_name": self.container_name,
            "container_id": self.container_id,
            "container_ip": self.container_ip,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "ports": [p.to_dict() for p in self.ports],
            "forwards": [f.to_dict() for f in self.forwards],
        }

    @classmethod
    def from_dict(cls, data: dict) -> ContainerEntry:
        return cls(
            container_name=data["container_name"],
            container_id=data["container_id"],
            container_ip=data["container_ip"],
            status=data["status"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            ports=[PortInfo.from_dict(p) for p in data.get("ports", [])],
            forwards=[ForwardInfo.from_dict(f) for f in data.get("forwards", [])],
        )


class ContainerRegistry:
    """In-memory container state backed by per-container JSON files.

    Each container is persisted as ``{container_name}.json`` inside
    *registry_dir*. Writes use atomic rename (write to ``.tmp``, then
    ``os.rename``) to prevent corruption on crash.
    """

    def __init__(self, registry_dir: Path) -> None:
        self._registry_dir = registry_dir
        self._entries: dict[str, ContainerEntry] = {}

    # -- Loading ---------------------------------------------------------------

    def load(self) -> None:
        """Read all ``*.json`` files from *registry_dir* into memory.

        Creates the directory if it does not exist.
        """
        os.makedirs(self._registry_dir, exist_ok=True)
        self._entries.clear()
        for path in self._registry_dir.glob("*.json"):
            with open(path) as fh:
                data = json.load(fh)
            entry = ContainerEntry.from_dict(data)
            self._entries[entry.container_name] = entry

    # -- Queries ---------------------------------------------------------------

    def get(self, container_name: str) -> ContainerEntry | None:
        """Return the entry for *container_name*, or ``None``."""
        return self._entries.get(container_name)

    def list(self) -> list[ContainerEntry]:
        """Return all registered entries."""
        return list(self._entries.values())

    # -- Mutations -------------------------------------------------------------

    def register(
        self, container_name: str, container_id: str, ip: str
    ) -> ContainerEntry:
        """Create a new entry with current timestamps and add it to the registry."""
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        entry = ContainerEntry(
            container_name=container_name,
            container_id=container_id,
            container_ip=ip,
            status="running",
            created_at=now,
            updated_at=now,
        )
        self._entries[container_name] = entry
        return entry

    def update(self, container_name: str, **fields: object) -> ContainerEntry:
        """Update *fields* on an existing entry and bump ``updated_at``.

        Raises ``KeyError`` if the container is not registered.
        """
        entry = self._entries[container_name]
        for key, value in fields.items():
            if not hasattr(entry, key):
                raise AttributeError(
                    f"ContainerEntry has no field {key!r}"
                )
            setattr(entry, key, value)
        entry.updated_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        return entry

    def remove(self, container_name: str) -> None:
        """Remove an entry from memory and delete its JSON file on disk."""
        self._entries.pop(container_name, None)
        path = self._registry_dir / f"{container_name}.json"
        if path.exists():
            path.unlink()

    # -- Persistence -----------------------------------------------------------

    def persist(self, container_name: str) -> None:
        """Atomically write a single entry to disk.

        Writes to ``{name}.json.tmp`` first, then renames to ``{name}.json``
        so a crash mid-write never leaves a corrupt file.
        """
        entry = self._entries[container_name]
        os.makedirs(self._registry_dir, exist_ok=True)
        target = self._registry_dir / f"{container_name}.json"
        tmp = self._registry_dir / f"{container_name}.json.tmp"
        with open(tmp, "w") as fh:
            json.dump(entry.to_dict(), fh, indent=2)
            fh.write("\n")
        os.rename(tmp, target)

    def persist_all(self) -> None:
        """Persist every entry currently in memory."""
        for name in self._entries:
            self.persist(name)
