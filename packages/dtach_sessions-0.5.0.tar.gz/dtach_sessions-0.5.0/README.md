# dsm — dtach session manager

Manage persistent detachable terminal sessions using dtach, with Docker container and git worktree support.

## Session Types

dsm has three session types that differ by where and how they run:

| | **local** | **ssh** | **container** |
|---|---|---|---|
| **no repo** | `dsm local -t title -- cmd` | `dsm ssh host` | — |
| **repo only** | — | — | `dsm container repo` |
| **repo + branch (worktree)** | — | — | `dsm container repo branch` |

The **recommended default** for development is **container + worktree** — it isolates each branch in its own worktree and runs it in a container.

## Quick Start

```bash
# Set up a worktree-based repo
dsm init-worktree https://github.com/org/repo.git

# Start a container session on a branch (creates worktree automatically)
dsm container repo feature-x

# Detach with ctrl+\, then manage sessions
dsm ls                    # list all sessions
dsm resume feature-x      # reattach
dsm rm feature-x          # remove
```

## Commands

### Session Creation

**`dsm local`** (alias: `l`) — run a command locally under dtach

```
dsm local -t TITLE [-d DESC] [-C DIR] -- <command...>
```

- `-t TITLE` (required) — session title, used to generate session ID
- `-d DESCRIPTION` — optional description
- `-C DIR` — working directory (default: cwd)
- `-- <command...>` (required) — command to run

**`dsm ssh`** — persistent SSH session under dtach

```
dsm ssh HOST [-t TITLE] [-d DESC] [SSH_ARGS...]
```

- `HOST` (required) — `user@host` or a saved alias
- `-t TITLE` — session title (default: auto-incrementing `session-N`)
- `-d DESCRIPTION` — optional description
- `SSH_ARGS` — passed through to ssh (e.g. `-p 2222`, `-i ~/.ssh/key`)

**`dsm container`** (alias: `con`) — Docker container with repo mounted

```
dsm container [-t TITLE] REPO_PATH [BRANCH] [--image IMG] [-p PORT] [-v VOL] [-- CMD]
```

- `REPO_PATH` (required) — path to a git repo
- `BRANCH` — if provided, creates/uses a git worktree at `repo/branch`
- `-t TITLE` — session title (default: `repo/branch` or `repo`)
- `--image IMAGE` — Docker image (default: `patricksulin/devcontainer:latest`)
- `-p PORT` — port mapping `host:container` (repeatable)
- `-v VOLUME` — extra volume mount `host:container` (repeatable)
- `-- <command...>` — command to run (default: `claude --dangerously-skip-permissions`)

With a branch, only that branch's worktree is mounted at `/workspace` (isolation). Without a branch, the repo root is mounted at `/workspace`. The Anthropic API key is auto-injected from environment, Claude config, or shell rc files.

**SSH Access to Containers:**

To enable SSH access to a container (for remote development with Claude Code UI or other tools):

```bash
# Create container with SSH port exposed and authorized keys mounted
dsm container -t myproject ~/repos/myproject feature-x \
  -p 2222:22 \
  -v ~/.ssh/authorized_keys:/home/ubuntu/.ssh/authorized_keys:ro

# Connect via SSH from another machine
ssh -p 2222 ubuntu@hostname

# Or configure Claude Code UI for remote SSH development
```

The devcontainer image includes SSH server configured for key-based auth only.

**Readonly Mounts for Code Visibility:**

To reference other repos from within an isolated worktree container without breaking isolation:

```bash
# Mount other repos as readonly for reference
dsm container -t myproject ~/repos/myproject feature-x \
  -v ~/repos/shared-lib:/mnt/shared-lib:ro \
  -v ~/repos/docs:/mnt/docs:ro

# Inside container:
# /workspace        - your isolated worktree (read-write)
# /mnt/shared-lib   - other repo (readonly, for reference)
# /mnt/docs         - other repo (readonly, for reference)
```

This replaces the need for copying code (wgx) while maintaining worktree isolation.

## Configuration

Create `~/.dsm/config.json` to define named configurations for container sessions:

```json
{
  "version": "1.0",
  "default_config": "default",
  "configs": {
    "default": {
      "repos_dir": "~/repos/dev",
      "exclude_current_main": true,
      "default_access": "ro",
      "ssh": {
        "enabled": true,
        "port": 2222,
        "authorized_keys": "~/.ssh/authorized_keys"
      },
      "env": {
        "GITHUB_TOKEN": "${GITHUB_TOKEN}",
        "DATABASE_URL": "sqlite:////workspace/.app/app.db"
      },
      "image": "patricksulin/devcontainer:latest"
    }
  }
}
```

**Config fields:**
- `repos_dir` - Auto-discover and mount all git repos in this directory
- `repos` - List of specific repos to mount
- `exclude_current_main` - Skip mounting `main` branch of current repo (maintains isolation)
- `default_access` - Default mount mode: `ro` (readonly) or `rw` (read-write)
- `ssh.enabled` - Enable SSH server in container
- `ssh.port` - Host port to map to container's port 22
- `ssh.authorized_keys` - Path to SSH keys file
- `env` - Environment variables (supports `${VAR}` expansion from host)
- `image` - Default Docker image

**Usage with config:**
```bash
# Use default config
dsm container -t myproject ~/repos/myproject feature-x

# Use specific config
dsm container -t myproject ~/repos/myproject feature-x --config minimal

# Override access mode
dsm container -t myproject ~/repos/myproject feature-x --access rw

# Add extra repos
dsm container -t myproject ~/repos/myproject feature-x --mount ~/repos/extra-lib

# Add extra env vars
dsm container -t myproject ~/repos/myproject feature-x -e DEBUG=0

# No config (isolated)
dsm container -t myproject ~/repos/myproject feature-x --config none
```

See `config.example.json` for a complete example.

### Port Forwarding

When containers are created via `dsm container`, they use `docker exec` for transport rather than SSH, so no port mappings (`-p`) are created by default. If a service starts inside the container (e.g., a dev server on port 8787), it's unreachable from the host.

`dsm ports` solves this by detecting listening ports inside the container and forwarding them to the host via [socat](https://linux.die.net/man/1/socat).

**Commands:**

```bash
# See what's listening inside a container
dsm ports dsm_myproject

# Forward a container port to the host
dsm forward dsm_myproject 8787

# Forward to a specific host port
dsm forward dsm_myproject 8787 --host-port 9000

# Stop forwarding
dsm unforward dsm_myproject 8787

# Show all ports across all running containers
dsm ports
```

**Example output:**

```
Container: dsm_myproject
  8787/tcp  0.0.0.0          -> forwarded to host:8787 (pid 12345)
  3000/tcp  0.0.0.0          (not forwarded)
  5432/tcp  127.0.0.1        (loopback only — not forwardable)
```

**How it works:**

1. **Detection** — Reads `/proc/$PID/net/tcp` from the host using the container's init PID. This accesses the container's network namespace with zero overhead (pure file read, no `docker exec`). Filters for LISTEN state, excludes ephemeral ports.

2. **Forwarding** — Spawns a `socat` process on the host that bridges `host_port` to `container_ip:container_port`. The container's bridge IP is directly routable on Linux.

3. **Port selection** — Tries the same port number on the host first, increments on conflict (same pattern as VS Code Dev Containers).

**Requirements:** `socat` must be installed on the host (`apt install socat`).

**Watch mode** — auto-detect and forward ports as services start/stop:

```bash
# Watch all running containers
dsm ports --watch

# Watch a specific container, exclude SSH port
dsm ports --watch dsm_myproject --exclude-port 22
```

Output:
```
Watching 1 container(s): dsm_myproject
Press Ctrl+C to stop.

[10:00:02] dsm_myproject: + 8787/tcp 0.0.0.0 -> forwarded to host:8787
[10:00:10] dsm_myproject: - 8787/tcp (service stopped, forward removed)
```

The watcher polls every 2 seconds, diffs against previous state, and automatically starts/stops socat forwards. It also detects container restarts (IP changes) and re-establishes forwards transparently.

**Limitations:**
- Services binding to `127.0.0.1` inside the container are not reachable from the host — they must bind `0.0.0.0`.

#### Platform Support

Port forwarding currently supports **Linux only**. The implementation is cleanly separated in `src/dsm/ports.py` with documented seams for platform extension.

| Concern | Linux (current) | macOS / Windows (future) |
|---------|-----------------|--------------------------|
| **Detection** | Host `/proc/$PID/net/tcp` | `docker exec cat /proc/net/tcp` |
| **Container IP** | Directly routable (bridge) | Not routable (VM) |
| **Forwarding** | `socat` on host | `docker exec socat` in container, or sidecar |

To add macOS/Windows support, a new backend would implement the same three operations (`scan_container_ports`, `start_forward`, `stop_forward`) using Docker Desktop-compatible mechanisms. See the module docstring in `src/dsm/ports.py` for detailed notes.

### Setup

**`dsm init-worktree`** (alias: `iw`) — set up a bare-clone repo for worktree workflows

```
dsm init-worktree URL [BRANCH]
```

- `URL` (required) — git clone URL
- `BRANCH` — main branch name (auto-detected from remote if omitted)

Creates this layout:

```
project/
  .bare/          bare repo (shared object store)
  .git            pointer to .bare
  <branch>/       initial worktree
```

**`dsm alias`** — manage SSH host aliases

```
dsm alias set NAME USER@HOST
dsm alias ls
dsm alias rm NAME
```

### Session Management

| Command | Description |
|---|---|
| `dsm ls` | List all sessions with type, status, title, command |
| `dsm resume ID` | Reattach (auto-restarts if dead). Prefix match supported. |
| `dsm tail ID [ID...]` | Follow output logs (local/ssh only) |
| `dsm rm ID` | Remove session (confirms if still live) |
| `dsm clean` | Remove all dead sessions |
| `dsm ports [CONTAINER] [--watch]` | List detected listening ports and active forwards |
| `dsm forward CONTAINER PORT` | Forward a container port to the host via socat |
| `dsm unforward CONTAINER PORT` | Stop forwarding a container port |

## Workflow

```
1. dsm local/ssh/container     create and attach
2. ctrl+\                      detach (session keeps running)
3. dsm ls                      see all sessions
4. dsm resume <id>             reattach
5. dsm tail <id>               follow output (local/ssh only)
```

## Worktree Branch Resolution

When `dsm container repo branch` creates a new worktree, it resolves the branch in three tiers:

1. Remote branch `origin/<branch>` (if it exists)
2. Local branch `<branch>` (if it exists)
3. New branch from the default branch (detected from `origin/HEAD`, fallback: `main`)
