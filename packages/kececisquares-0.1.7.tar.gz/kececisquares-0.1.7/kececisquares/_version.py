# _version.py

__version__ = "0.1.7"
__license__ = "AGPL3.0-or-later"
__description__ = "Keçeci Binomial Squares (Keçeci Binom Kareleri): The Keçeci Binomial Square is a series of binomial coefficients forming a square region within Khayyam (مثلث خیام), Pascal, Binomial Triangle, selected from a specified starting row with defined size and alignment."
__author__ = "Mehmet Keçeci"
__url__ = "https://github.com/WhiteSymmetry/kececisquares"
__docs__ = "https://github.com/WhiteSymmetry/kececisquares"  # Opsiyonel: Dokümantasyon linki
__dependencies__ = ["python>=3.11"]  # Diğer bağımlılıkları da ekleyebilirsiniz
