"""Testcases for full masking pipeline"""

import unittest
from pathlib import Path

import cv2
import matplotlib.pyplot as plt
import numpy as np
import tifffile
from shapely.geometry import Point, Polygon, shape
from tqdm.auto import tqdm

import dart_mlci
from dart_mlci import (
    DEFAULT_MODEL_PATH,
    MarkerDetectionModel,
    RoIMasker,
    SingleStructureRoIMasker,
)
from dart_mlci.io import load_roi_structures
from dart_mlci.mask import RoIPolygon, SAKRoIStructureLibrary
from dart_mlci.match import marker_group_to_pixel_coordinates, match_markers
from dart_mlci.rotation import (
    compute_marker_group_angles,
    rotate_image_and_markers,
)
from dart_mlci.utils import normalize_image
from dart_mlci.visualization import plot_marker_paris, plot_markers

# Dedicated folder for test results
TEST_RESULTS_DIR = Path(__file__).parent / "test_results"
TEST_RESULTS_DIR.mkdir(exist_ok=True)


def build_polygon(pixel_size):
    chamber_width = 60
    chamber_height = 60

    interior = Point(30, 30).buffer(5)

    chamber_polygon = Polygon(
        [
            (0, 0),
            (chamber_width, 0),
            (chamber_width, chamber_height),
            (0, chamber_height),
        ]
    ).difference(interior)

    rp = RoIPolygon(chamber_polygon)

    rp = rp.scale(1.0 / pixel_size)
    xmin, ymin, _, _ = rp.roi_polygon.bounds

    # move polygon into positive coordinates
    rp = rp.translate(x=-xmin, y=-ymin)

    return rp


class TestFullPipeline(unittest.TestCase):
    """Test cases for full masking pipeline"""

    @staticmethod
    def test_all_pipeline_steps():
        """test the full pipeline step-by-step"""
        # Create subfolder for this test
        output_dir = TEST_RESULTS_DIR / "all_pipeline_steps"
        output_dir.mkdir(exist_ok=True)

        # config
        pixel_size = 0.065789
        marker_group = {
            "cross": np.array((4, 8), dtype=float),
            "circle": np.array((56, 8), dtype=float),
        }

        marker_group_pixels = marker_group_to_pixel_coordinates(marker_group, pixel_size)

        roi_polygon = build_polygon(pixel_size)

        # 1. Load yolo model

        model = MarkerDetectionModel(DEFAULT_MODEL_PATH)

        # 2. Load image
        image = cv2.imread(Path(dart_mlci.__file__).parent.parent / "artifacts/images/sak/0000.png")

        plt.imshow(image, cmap="gray")
        plt.tight_layout()
        plt.axis("off")
        plt.savefig(output_dir / "step_1_input.png")

        # 3. Detect markers
        markers = model.predict_markers(image)

        plot_markers(image, markers)

        plt.savefig(output_dir / "step_2_markers.png")

        # plt.save()

        print(markers)

        # 4. Match markers
        matched_marker_indices = match_markers(
            markers, marker_group=marker_group_pixels, tolerance=60
        )

        print(matched_marker_indices)

        plot_marker_paris(image, matched_marker_indices, markers)
        plt.savefig(output_dir / "step_3_matched.png")

        # 5. Compute angle
        angles = compute_marker_group_angles(markers, matched_marker_indices, marker_group_pixels)
        mean_angle = np.mean(angles)

        print("angles", angles)

        image = np.moveaxis(image, [0, 1, 2], [1, 2, 0])

        # 6. Rotate image

        rotated_image, rotated_markers = rotate_image_and_markers(image, markers, mean_angle)

        # rotated_image = np.stack([rotate_image(im, mean_angle) for im in image], axis=0)
        # rotated_markers = rotate_markers(markers, image, mean_angle)
        plot_marker_paris(
            np.moveaxis(rotated_image, [0, 1, 2], [2, 0, 1]),
            matched_marker_indices,
            rotated_markers,
        )
        plt.savefig(output_dir / "step_4_rotated.png")

        # 7. Apply mask

        masks = []
        polygons = []
        im_height, im_width = rotated_image.shape[-2:]

        for cross_index, circle_index in matched_marker_indices:
            cross_marker = rotated_markers[cross_index]
            circle_marker = rotated_markers[circle_index]

            print(cross_marker["bbox_center"][0])

            # correct for difference in expected width
            width = np.abs(cross_marker["bbox_center"][0] - circle_marker["bbox_center"][0])
            expected_width = np.abs(
                marker_group_pixels["cross"][0] - marker_group_pixels["circle"][0]
            )
            diff = width - expected_width

            # translate roi polygon
            rp = roi_polygon.translate(
                x=cross_marker["bbox_center"][0] - marker_group_pixels["cross"][0] + diff,
                y=cross_marker["bbox_center"][1] + marker_group_pixels["cross"][1],
            )

            # check whether roi polygon in image
            xmin, ymin, xmax, ymax = rp.roi_polygon.bounds

            if xmin < 0 or xmax > im_width or ymin < 0 or ymax > im_height:
                # roi is out of image bounds
                continue

            polygons.append(rp)
            masks.append(~rp.to_mask(height=im_height, width=im_width).astype(bool))
            break

        if len(masks) == 0:
            raise ValueError("No roi lies completely inside the image")

        mask = masks[0]  # np.bitwise_or.reduce(np.stack(masks, axis=-1).astype(bool), axis=-1)
        polygon: RoIPolygon = polygons[0]

        # 8. Cropping

        minx, miny, maxx, maxy = tuple(map(int, map(np.round, polygon.roi_polygon.bounds)))
        cropped_image = rotated_image[..., miny:maxy, minx:maxx]
        cropped_mask = mask[miny:maxy, minx:maxx]

        _, axes = plt.subplots(1, 2, figsize=(15, 15))
        axes[0].imshow(np.moveaxis(rotated_image, [0, 1, 2], [2, 0, 1]))
        axes[0].imshow(mask, alpha=0.5)

        axes[1].imshow(np.moveaxis(cropped_image, [0, 1, 2], [2, 0, 1]))
        axes[1].imshow(cropped_mask, alpha=0.2)
        plt.savefig(output_dir / "step_5_comparison.jpg")

        plt.figure()
        plt.imshow(np.moveaxis(rotated_image, [0, 1, 2], [2, 0, 1]), cmap="gray")
        plt.imshow(np.stack((mask * 255, mask * 0, mask * 0), axis=-1), alpha=0.2)
        plt.tight_layout()
        plt.axis("off")

        print(rotated_image.shape, mask.shape)

        # output phase-contrast and mask
        tifffile.imwrite(output_dir / "rotated_raw.tif", rotated_image[0])
        tifffile.imwrite(output_dir / "rotated_mask.tif", mask)

        tifffile.imwrite(output_dir / "cropped_raw.tif", cropped_image[0])
        tifffile.imwrite(output_dir / "cropped_mask.tif", cropped_mask)

        plt.savefig(output_dir / "step_6_masked.png")

        plt.figure()
        plt.imshow(np.moveaxis(cropped_image, [0, 1, 2], [2, 0, 1]), cmap="gray")
        plt.imshow(
            np.stack((cropped_mask * 255, cropped_mask * 0, cropped_mask * 0), axis=-1), alpha=0.2
        )
        plt.tight_layout()
        plt.axis("off")

        plt.savefig(output_dir / "step_7_cropped.png")

    @staticmethod
    def test_roi_masker():
        """testing the roi masker class."""
        # Create subfolder for this test
        output_dir = TEST_RESULTS_DIR / "roi_masker"
        output_dir.mkdir(exist_ok=True)

        # general information
        pixel_size = 0.065789
        marker_group = {
            "cross": np.array((4, 8), dtype=float),
            "circle": np.array((56, 8), dtype=float),
        }

        # convert info to pixel coordinates
        marker_group_pixel = marker_group_to_pixel_coordinates(marker_group, pixel_size)
        roi_polygon = build_polygon(pixel_size)

        # create the masker
        rm = RoIMasker(
            model_path=DEFAULT_MODEL_PATH,
            roi_polygon=roi_polygon,
            marker_group_pixel=marker_group_pixel,
        )

        image = cv2.imread(Path(dart_mlci.__file__).parent.parent / "artifacts/images/sak/0007.png")

        # apply the masker
        cropped_image, cropped_mask = rm(np.moveaxis(image[None], [1, 2, 3], [2, 3, 1]))

        # plot
        _, axes = plt.subplots(1, 2, figsize=(10, 10))
        axes[0].imshow(np.moveaxis(cropped_image[0], [0, 1, 2], [2, 0, 1]))
        axes[0].imshow(cropped_mask[0], alpha=0.25)
        axes[1].imshow(image)

        plt.savefig(output_dir / "result.jpg")

    @staticmethod
    def test_roi_masker_sak():
        """testing the roi masker class."""
        # Create subfolder for this test
        output_dir = TEST_RESULTS_DIR / "roi_masker_sak"
        output_dir.mkdir(exist_ok=True)

        # general information
        pixel_size = 0.065789

        # pylint: disable=too-many-function-args
        sakl = SAKRoIStructureLibrary(
            Path(dart_mlci.__file__).parent.parent / "artifacts/chamber_structure.json",
            pixel_size,
        )

        # create the masker
        rm = RoIMasker(
            model_path=DEFAULT_MODEL_PATH,
            roi_polygon=None,
            marker_group_pixel=None,
        )

        image = cv2.imread(Path(dart_mlci.__file__).parent.parent / "artifacts/images/sak/0007.png")

        print(image.shape)

        # make it TxCxHxW
        image = np.moveaxis(image[None, ...], [1, 2, 3], [2, 3, 1])

        # pylint: disable=unbalanced-tuple-unpacking
        _, sp, sc = sakl("0000")

        # apply the masker
        cropped_image, cropped_mask = rm(image, roi_polygon=sp, marker_group_pixel=sc)

        # plot
        _, axes = plt.subplots(1, 2, figsize=(10, 10))
        axes[0].imshow(np.moveaxis(cropped_image[0], [0, 1, 2], [2, 0, 1]))
        axes[0].imshow(cropped_mask[0], alpha=0.25)
        axes[1].imshow(np.moveaxis(image[0], [0, 1, 2], [2, 0, 1]))

        plt.savefig(output_dir / "result.jpg")

    @staticmethod
    def test_sak_chip():
        """Test SAK chip masking for various chamber types."""
        # Create subfolder for this test
        output_dir = TEST_RESULTS_DIR / "sak_chip"
        output_dir.mkdir(exist_ok=True)

        configs = [
            {
                "file_name": "0000.png",
                "chamber_type": "NormaleBox-pillar-inner",
            },
            {
                "file_name": "0001.png",
                "chamber_type": "BigBox-pillar-inner",
            },
            {
                "file_name": "0003.png",
                "chamber_type": "OpenBox-inner",
            },
            {
                "file_name": "0004.png",
                "chamber_type": "NormaleBox-pillar-inner",
            },
            {
                "file_name": "0005.png",
                "chamber_type": "OpenBox-collector-inner",
            },
            {
                "file_name": "0006.png",
                "chamber_type": "BigBox-inner",
            },
            {
                "file_name": "0007.png",
                "chamber_type": "NormaleBox-inner",
            },
            {
                "file_name": "0008.png",
                "chamber_type": "Mothermachine-2x-inner",
            },
            {
                "file_name": "0009.tif",
                "chamber_type": "Mothermachine-inner",
            },
        ]

        marker_group_configs = {
            "NormaleBox-pillar-inner": {
                "cross": np.array((4, 8), dtype=float),
                "circle": np.array((56, 8), dtype=float),
            },
            "BigBox-pillar-inner": {
                "cross": np.array((4, 8), dtype=float),
                "circle": np.array((56, 8), dtype=float),
            },
            "OpenBox-inner": {
                "cross": np.array((14, 8), dtype=float),
                "circle": np.array((66, 8), dtype=float),
            },
            "OpenBox-collector-inner": {
                "cross": np.array((14, 8), dtype=float),
                "circle": np.array((66, 8), dtype=float),
            },
            "BigBox-inner": {
                "cross": np.array((4, 8), dtype=float),
                "circle": np.array((56, 8), dtype=float),
            },
            "NormaleBox-inner": {
                "cross": np.array((4, 8), dtype=float),
                "circle": np.array((56, 8), dtype=float),
            },
            "Mothermachine-2x-inner": {
                "cross": np.array((14, 8), dtype=float),
                "circle": np.array((66, 8), dtype=float),
            },
            "Mothermachine-inner": {
                "cross": np.array((14, 8), dtype=float),
                "circle": np.array((66, 8), dtype=float),
            },
        }

        # load structures
        roi_structures = load_roi_structures(
            Path(dart_mlci.__file__).parent.parent / "artifacts/chamber_structure.json"
        )

        # general information
        pixel_size = 0.065789

        # create the masker
        rm = RoIMasker(
            model_path=DEFAULT_MODEL_PATH,
            roi_polygon=None,
            marker_group_pixel=None,
        )

        for i, conf in enumerate(tqdm(configs)):
            image_file = (
                Path(dart_mlci.__file__).parent.parent / "artifacts/images/sak" / conf["file_name"]
            )
            chamber_type = conf["chamber_type"]

            marker_group = marker_group_configs[chamber_type]
            marker_group_pixel = marker_group_to_pixel_coordinates(marker_group, pixel_size)

            rp = RoIPolygon(shape(roi_structures[chamber_type]))

            rp = rp.scale(1.0 / pixel_size)
            xmin, ymin, _, _ = rp.roi_polygon.bounds

            # move polygon into positive coordinates
            rp = rp.translate(x=-xmin, y=-ymin)

            print(image_file.suffix)

            if image_file.suffix == ".tif":
                print("Hello")
                image = tifffile.imread(image_file)
                # norm image
                image = normalize_image(image)
                # make it three channels
                image = np.stack((image,) * 3, axis=-1)
                print(image.shape, image.dtype)
            else:
                image = cv2.imread(image_file)

            image = np.moveaxis(image, [0, 1, 2], [1, 2, 0])[None]

            # apply the masker
            cropped_image, cropped_mask = rm(
                image,
                roi_polygon=rp,
                marker_group_pixel=marker_group_pixel,
                return_uncropped=False,
            )
            rotated_image, rotated_mask = rm(
                image,
                roi_polygon=rp,
                marker_group_pixel=marker_group_pixel,
                return_uncropped=True,
            )

            # plot
            _, axes = plt.subplots(1, 3, figsize=(20, 10))
            axes[0].imshow(np.moveaxis(image[0], [0, 1, 2], [2, 0, 1]), cmap="gray")
            axes[1].imshow(np.moveaxis(rotated_image[0], [0, 1, 2], [2, 0, 1]), cmap="gray")
            axes[1].imshow(rotated_mask[0], alpha=0.5)

            # Save just the portion _inside_ the second axis's boundaries
            # extent = axes[1].get_window_extent().transformed(fig.dpi_scale_trans.inverted())
            # fig.savefig('test_{i}_inner.png', bbox_inches=extent)

            axes[2].imshow(np.moveaxis(cropped_image[0], [0, 1, 2], [2, 0, 1]))
            axes[2].imshow(cropped_mask[0], alpha=0.2)

            plt.tight_layout()

            plt.savefig(output_dir / f"chip_{i}_overview.jpg")
            plt.close("all")

            plt.imshow(
                np.moveaxis(
                    normalize_image(rotated_image[0], high_quantile=0.95), [0, 1, 2], [2, 0, 1]
                ),
                cmap="gray",
            )

            rgb_mask = np.stack((rotated_mask * 255, rotated_mask * 0, rotated_mask * 0), axis=-1)[
                0
            ]

            plt.imshow(rgb_mask, alpha=0.5)
            plt.tight_layout()
            plt.axis("off")
            plt.savefig(output_dir / f"chip_{i}_masked.png", dpi=300)

    def test_ssrm(self):
        """test cropping of an image stack with a single structure masker"""
        # Create subfolder for this test
        output_dir = TEST_RESULTS_DIR / "ssrm"
        output_dir.mkdir(exist_ok=True)

        ssrm = SingleStructureRoIMasker()

        image_path = Path(dart_mlci.__file__).parent.parent / "artifacts/images/sak" / "0003.png"

        image = cv2.imread(image_path)

        image_stack = np.stack((np.moveaxis(image, [0, 1, 2], [1, 2, 0]),) * 10, axis=0)

        cropped_images, _ = ssrm(image_stack=image_stack, roi_id="0000")

        self.assertEqual(len(cropped_images), 10)

        cropped_images = np.moveaxis(cropped_images, [1, 2, 3], [3, 1, 2])

        # plot
        _, axes = plt.subplots(1, 3, figsize=(20, 10))
        axes[0].imshow(cropped_images[0])
        axes[1].imshow(cropped_images[1])
        axes[2].imshow(cropped_images[2])

        plt.tight_layout()

        plt.savefig(output_dir / "result.jpg")


if __name__ == "__main__":
    unittest.main()
