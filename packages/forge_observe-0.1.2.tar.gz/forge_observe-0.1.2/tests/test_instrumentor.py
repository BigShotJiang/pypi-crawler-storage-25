
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from forge_observe.config import ForgeObserveConfig, _reset_config
from forge_observe.instrumentor import (
    instrument,
    is_instrumented,
    uninstrument,
)


@pytest.fixture(autouse=True)
def _cleanup():
    """Ensure instrumentation state is clean before and after each test."""
    uninstrument()
    _reset_config()
    yield
    uninstrument()
    _reset_config()


class TestInstrumentGuards:
    def test_not_instrumented_initially(self):
        assert is_instrumented() is False

    def test_disabled_config_skips_patching(self):
        config = ForgeObserveConfig(enabled=False)
        instrument(config=config)
        assert is_instrumented() is False

    @patch("forge_observe.instrumentor._setup_tracer_provider")
    @patch("forge_observe.instrumentor._setup_meter_provider")
    def test_instrument_raises_without_qwen_think(self, mock_meter, mock_tracer):
        with patch.dict("sys.modules", {
            "qwen_think": None,
            "qwen_think.session": None,
            "qwen_think.router": None,
            "qwen_think.budget": None,
            "qwen_think.backends": None,
            "qwen_think.backends.base": None,
        }):
            with pytest.raises(ImportError, match="qwen-think"):
                instrument()

    def test_double_instrument_is_noop(self):
        """Calling instrument() twice does not re-patch."""
        config = ForgeObserveConfig(console_export=True)
        try:
            instrument(config=config)
        except ImportError:
            pytest.skip("qwen-think not installed")
        first_state = is_instrumented()

        instrument(config=config)
        assert is_instrumented() == first_state


class TestUninstrument:
    def test_uninstrument_when_not_instrumented_is_safe(self):
        """uninstrument() is a no-op when not instrumented."""
        uninstrument()
        assert is_instrumented() is False

    def test_uninstrument_restores_state(self):
        config = ForgeObserveConfig(console_export=True)
        try:
            instrument(config=config)
        except ImportError:
            pytest.skip("qwen-think not installed")

        assert is_instrumented() is True
        uninstrument()
        assert is_instrumented() is False


class TestPatchFunctions:
    """Test the patch wrapper functions in isolation (without qwen-think)."""

    def test_patch_chat_wraps_callable(self):
        from forge_observe.instrumentor import _patch_chat

        call_log = []

        def fake_chat(self, message, **kwargs):
            call_log.append(message)
            return "response"

        wrapped = _patch_chat(fake_chat)
        assert callable(wrapped)
        # The wrapper preserves the function name
        assert wrapped.__wrapped__ is fake_chat

    def test_patch_route_wraps_callable(self):
        from forge_observe.instrumentor import _patch_route

        def fake_route(self, query, **kwargs):
            return MagicMock(
                mode=MagicMock(value="think"),
                reasoning="test",
                complexity=MagicMock(value="complex"),
                confidence=0.9,
            )

        wrapped = _patch_route(fake_route)
        assert callable(wrapped)
        assert wrapped.__wrapped__ is fake_route

    def test_patch_check_budget_wraps_callable(self):
        from forge_observe.instrumentor import _patch_check_budget

        def fake_check(self, messages):
            return MagicMock(
                total_tokens=200000,
                used_tokens=50000,
                available_tokens=150000,
                action=MagicMock(value="ok"),
            )

        wrapped = _patch_check_budget(fake_check)
        assert callable(wrapped)
        assert wrapped.__wrapped__ is fake_check

    def test_patch_build_payload_wraps_callable(self):
        from forge_observe.instrumentor import _patch_build_payload

        def fake_build(self, **kwargs):
            return MagicMock(
                enable_thinking=True,
                preserve_thinking=True,
            )

        wrapped = _patch_build_payload(fake_build)
        assert callable(wrapped)
        assert wrapped.__wrapped__ is fake_build


class TestPatchChatExecution:
    def test_wrapped_chat_emits_session_span(self):
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import SimpleSpanProcessor
        from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
            InMemorySpanExporter,
        )

        exporter = InMemorySpanExporter()
        provider = TracerProvider()
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        trace.set_tracer_provider(provider)

        from forge_observe.instrumentor import _patch_chat

        mock_msg = MagicMock(
            role="assistant",
            thinking_content="Let me think about this...",
            content="Here is the answer.",
        )
        mock_self = MagicMock()
        mock_self.backend.value = "vllm"
        mock_self.model = "Qwen3.6-35B"
        mock_self._thinking_mode.value = "thinking"
        mock_self._messages = [mock_msg]
        mock_self.preserve_thinking = False
        mock_self.budget_manager.check_budget.return_value = MagicMock(
            total_tokens=200000,
            used_tokens=50000,
            available_tokens=150000,
            action=MagicMock(value="ok"),
        )

        def fake_chat(self, message, **kwargs):
            return "response"

        wrapped = _patch_chat(fake_chat)
        result = wrapped(mock_self, "hello")

        assert result == "response"

        spans = exporter.get_finished_spans()
        span_names = {s.name for s in spans}
        assert "forge.session" in span_names
        assert "forge.session.budget_check" in span_names
        assert "forge.backend.response" in span_names

        session = [s for s in spans if s.name == "forge.session"][0]
        assert dict(session.attributes)["forge.session.model"] == "Qwen3.6-35B"

        response_span = [s for s in spans if s.name == "forge.backend.response"][0]
        attrs = dict(response_span.attributes)
        assert attrs["forge.response.has_thinking"] is True
        assert attrs["forge.response.thinking_tokens"] > 0

        provider.shutdown()


class TestPatchRouteExecution:
    """Test that wrapped route actually calls through and emits spans."""

    def test_wrapped_route_calls_original(self):
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import SimpleSpanProcessor
        from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
            InMemorySpanExporter,
        )

        exporter = InMemorySpanExporter()
        provider = TracerProvider()
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        trace.set_tracer_provider(provider)

        from forge_observe.instrumentor import _patch_route

        mock_decision = MagicMock(
            mode=MagicMock(value="think"),
            reasoning="classified as complex",
            complexity=MagicMock(value="complex"),
            confidence=0.92,
        )

        def fake_route(self, query, **kwargs):
            return mock_decision

        wrapped = _patch_route(fake_route)
        result = wrapped(MagicMock(), "implement a sorting algorithm")

        assert result is mock_decision

        spans = exporter.get_finished_spans()
        assert len(spans) == 1
        assert spans[0].name == "forge.session.think_decision"
        attrs = dict(spans[0].attributes)
        assert attrs["forge.decision.mode"] == "think"
        assert attrs["forge.decision.complexity"] == "complex"
        assert attrs["forge.decision.confidence"] == 0.92

        provider.shutdown()


class TestPatchBudgetExecution:
    """Test that wrapped check_budget calls through and emits spans."""

    def test_wrapped_check_budget_calls_original(self):
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import SimpleSpanProcessor
        from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
            InMemorySpanExporter,
        )

        exporter = InMemorySpanExporter()
        provider = TracerProvider()
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        trace.set_tracer_provider(provider)

        from forge_observe.instrumentor import _patch_check_budget

        mock_status = MagicMock(
            total_tokens=200000,
            used_tokens=60000,
            available_tokens=140000,
            action=MagicMock(value="ok"),
        )

        def fake_check(self, messages):
            return mock_status

        wrapped = _patch_check_budget(fake_check)
        result = wrapped(MagicMock(), [])

        assert result is mock_status

        spans = exporter.get_finished_spans()
        assert len(spans) == 1
        assert spans[0].name == "forge.session.budget_check"
        attrs = dict(spans[0].attributes)
        assert attrs["forge.budget.total"] == 200000
        assert attrs["forge.budget.available"] == 140000
        assert attrs["forge.budget.action"] == "ok"

        provider.shutdown()


class TestConfigIntegration:
    def test_config_env_override(self, monkeypatch):
        monkeypatch.setenv("FORGE_OBSERVE_SERVICE_NAME", "my-service")
        monkeypatch.setenv("FORGE_OBSERVE_ENABLED", "false")
        cfg = ForgeObserveConfig()
        assert cfg.service_name == "my-service"
        assert cfg.enabled is False

    def test_config_defaults(self):
        cfg = ForgeObserveConfig()
        assert cfg.service_name == "forge-observe"
        assert cfg.otlp_endpoint == "http://localhost:4317"
        assert cfg.enabled is True
        assert cfg.console_export is False
