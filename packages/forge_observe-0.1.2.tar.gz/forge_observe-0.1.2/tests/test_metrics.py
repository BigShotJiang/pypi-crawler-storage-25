
from __future__ import annotations

import pytest
from opentelemetry import metrics
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import InMemoryMetricReader

from forge_observe.metrics import ForgeMetrics, forge_metrics


@pytest.fixture()
def metric_reader():
    """Set up an in-memory metric reader and return it."""
    reader = InMemoryMetricReader()
    provider = MeterProvider(metric_readers=[reader])
    metrics.set_meter_provider(provider)
    fm = ForgeMetrics()
    fm.setup()
    yield fm, reader
    provider.shutdown()
    fm.reset()


class TestForgeMetricsSetup:
    def test_is_setup_false_initially(self):
        fm = ForgeMetrics()
        assert fm.is_setup is False

    def test_is_setup_true_after_setup(self, metric_reader):
        fm, _ = metric_reader
        assert fm.is_setup is True


class TestThinkingTokensCounter:
    def test_records_thinking_tokens(self, metric_reader):
        fm, reader = metric_reader
        fm.record_thinking_tokens(500)
        fm.record_thinking_tokens(300)

        data = reader.get_metrics_data()
        metric_map = {}
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for m in scope_metric.metrics:
                    metric_map[m.name] = m

        thinking = metric_map["forge.session.thinking_tokens"]
        points = list(thinking.data.data_points)
        assert len(points) == 1
        assert points[0].value == 800


class TestResponseTokensCounter:
    def test_records_response_tokens(self, metric_reader):
        fm, reader = metric_reader
        fm.record_response_tokens(200)
        fm.record_response_tokens(150)

        data = reader.get_metrics_data()
        metric_map = {}
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for m in scope_metric.metrics:
                    metric_map[m.name] = m

        response = metric_map["forge.session.response_tokens"]
        points = list(response.data.data_points)
        assert len(points) == 1
        assert points[0].value == 350


class TestModeSwitchesCounter:
    def test_records_mode_switches(self, metric_reader):
        fm, reader = metric_reader
        fm.record_mode_switch()
        fm.record_mode_switch()
        fm.record_mode_switch()

        data = reader.get_metrics_data()
        metric_map = {}
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for m in scope_metric.metrics:
                    metric_map[m.name] = m

        switches = metric_map["forge.session.mode_switches"]
        points = list(switches.data.data_points)
        assert len(points) == 1
        assert points[0].value == 3


class TestBudgetRemainingGauge:
    def test_reports_last_value(self, metric_reader):
        fm, reader = metric_reader
        fm.record_budget_remaining(150000)
        fm.record_budget_remaining(140000)

        data = reader.get_metrics_data()
        metric_map = {}
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for m in scope_metric.metrics:
                    metric_map[m.name] = m

        budget = metric_map["forge.session.budget_remaining"]
        points = list(budget.data.data_points)
        assert len(points) == 1
        # Observable gauge returns the last recorded value
        assert points[0].value == 140000


class TestPreserveReuseRate:
    def test_reuse_rate_calculation(self, metric_reader):
        fm, reader = metric_reader
        # 3 turns: 2 reused, 1 not
        fm.record_preserve_reuse(reused=True)
        fm.record_preserve_reuse(reused=True)
        fm.record_preserve_reuse(reused=False)

        data = reader.get_metrics_data()
        metric_map = {}
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for m in scope_metric.metrics:
                    metric_map[m.name] = m

        reuse = metric_map["forge.session.preserve_reuse_rate"]
        points = list(reuse.data.data_points)
        assert len(points) == 1
        # 2 / 3 = 0.6667
        assert abs(points[0].value - (2.0 / 3.0)) < 0.001

    def test_reuse_rate_zero_when_no_data(self, metric_reader):
        fm, reader = metric_reader

        data = reader.get_metrics_data()
        metric_map = {}
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for m in scope_metric.metrics:
                    metric_map[m.name] = m

        reuse = metric_map["forge.session.preserve_reuse_rate"]
        points = list(reuse.data.data_points)
        assert len(points) == 1
        assert points[0].value == 0.0


class TestMtpAcceptanceRate:
    def test_reports_last_rate(self, metric_reader):
        fm, reader = metric_reader
        fm.record_mtp_acceptance_rate(0.85)

        data = reader.get_metrics_data()
        metric_map = {}
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for m in scope_metric.metrics:
                    metric_map[m.name] = m

        mtp = metric_map["forge.mtp.acceptance_rate"]
        points = list(mtp.data.data_points)
        assert len(points) == 1
        assert points[0].value == 0.85


class TestForgeMetricsReset:
    def test_reset_clears_state(self):
        fm = ForgeMetrics()
        fm._last_budget_remaining = 100000
        fm._preserve_reuse_total = 10
        fm._preserve_reuse_hits = 5
        fm._last_mtp_acceptance = 0.9

        fm.reset()

        assert fm._last_budget_remaining == 0
        assert fm._preserve_reuse_total == 0
        assert fm._preserve_reuse_hits == 0
        assert fm._last_mtp_acceptance == 0.0


class TestModuleLevelSingleton:
    def test_forge_metrics_is_instance(self):
        assert isinstance(forge_metrics, ForgeMetrics)
