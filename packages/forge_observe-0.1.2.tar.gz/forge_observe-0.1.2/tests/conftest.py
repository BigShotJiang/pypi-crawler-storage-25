from __future__ import annotations

import opentelemetry.metrics._internal as metrics_internal
import opentelemetry.trace as trace_api
import pytest


@pytest.fixture(autouse=True)
def _reset_otel_globals():
    """Reset OTel global providers between tests so each test can
    set its own TracerProvider / MeterProvider without the SDK
    rejecting it as an override."""
    yield
    # Accesses private OTel SDK internals; may break on SDK upgrades
    # Tracer
    prov = trace_api.get_tracer_provider()
    if hasattr(prov, "shutdown"):
        try:
            prov.shutdown()
        except Exception:
            pass
    trace_api._TRACER_PROVIDER_SET_ONCE._done = False
    trace_api._TRACER_PROVIDER = None

    # Meter
    mprov = metrics_internal._METER_PROVIDER
    if mprov is not None and hasattr(mprov, "shutdown"):
        try:
            mprov.shutdown()
        except Exception:
            pass
    metrics_internal._METER_PROVIDER_SET_ONCE._done = False
    metrics_internal._METER_PROVIDER = None
