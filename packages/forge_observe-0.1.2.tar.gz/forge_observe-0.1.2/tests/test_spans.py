
from __future__ import annotations

import pytest
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from forge_observe.spans import (
    SPAN_BACKEND_CALL,
    SPAN_BACKEND_NORMALIZE,
    SPAN_BACKEND_RESPONSE,
    SPAN_BUDGET_CHECK,
    SPAN_MTP_CONFIG,
    SPAN_PARAM_SWAP,
    SPAN_PRESERVE_CHECK,
    SPAN_SESSION,
    SPAN_THINK_DECISION,
    backend_call_span,
    backend_normalize_span,
    backend_response_span,
    budget_check_span,
    mtp_config_span,
    param_swap_span,
    preserve_check_span,
    record_error,
    session_span,
    think_decision_span,
)


@pytest.fixture(autouse=True)
def _setup_tracer():
    """Set up an in-memory tracer for each test."""
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    yield exporter
    provider.shutdown()


def _get_spans(exporter: InMemorySpanExporter):
    return exporter.get_finished_spans()


class TestSpanNames:
    """Verify span name constants have the expected values."""

    def test_session_name(self):
        assert SPAN_SESSION == "forge.session"

    def test_think_decision_name(self):
        assert SPAN_THINK_DECISION == "forge.session.think_decision"

    def test_param_swap_name(self):
        assert SPAN_PARAM_SWAP == "forge.session.param_swap"

    def test_budget_check_name(self):
        assert SPAN_BUDGET_CHECK == "forge.session.budget_check"

    def test_backend_call_name(self):
        assert SPAN_BACKEND_CALL == "forge.session.backend_call"

    def test_backend_normalize_name(self):
        assert SPAN_BACKEND_NORMALIZE == "forge.backend.normalize"

    def test_backend_response_name(self):
        assert SPAN_BACKEND_RESPONSE == "forge.backend.response"

    def test_preserve_check_name(self):
        assert SPAN_PRESERVE_CHECK == "forge.session.preserve_check"

    def test_mtp_config_name(self):
        assert SPAN_MTP_CONFIG == "forge.mtp.config_decision"


class TestSessionSpan:
    def test_creates_span_with_name(self, _setup_tracer):
        with session_span():
            pass
        spans = _get_spans(_setup_tracer)
        assert len(spans) == 1
        assert spans[0].name == "forge.session"

    def test_includes_custom_attributes(self, _setup_tracer):
        with session_span(attributes={"forge.session.model": "Qwen3.6-35B"}):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.session.model"] == "Qwen3.6-35B"


class TestThinkDecisionSpan:
    def test_records_mode_and_reason(self, _setup_tracer):
        with think_decision_span(
            mode="think", reason="complex query",
            complexity="complex", confidence=0.85,
        ):
            pass
        spans = _get_spans(_setup_tracer)
        assert len(spans) == 1
        attrs = dict(spans[0].attributes)
        assert attrs["forge.decision.mode"] == "think"
        assert attrs["forge.decision.reason"] == "complex query"
        assert attrs["forge.decision.complexity"] == "complex"
        assert attrs["forge.decision.confidence"] == 0.85

    def test_span_name(self, _setup_tracer):
        with think_decision_span(mode="no_think", reason="simple"):
            pass
        spans = _get_spans(_setup_tracer)
        assert spans[0].name == "forge.session.think_decision"


class TestParamSwapSpan:
    def test_records_mode_transition(self, _setup_tracer):
        with param_swap_span(
            from_mode="think", to_mode="no_think",
            params={"temperature": 0.7, "top_p": 0.8},
        ):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.swap.from_mode"] == "think"
        assert attrs["forge.swap.to_mode"] == "no_think"
        assert attrs["forge.swap.temperature"] == 0.7
        assert attrs["forge.swap.top_p"] == 0.8


class TestBudgetCheckSpan:
    def test_records_budget_values(self, _setup_tracer):
        with budget_check_span(
            total_tokens=200000, used_tokens=50000,
            available_tokens=150000, action="ok",
        ):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.budget.total"] == 200000
        assert attrs["forge.budget.used"] == 50000
        assert attrs["forge.budget.available"] == 150000
        assert attrs["forge.budget.action"] == "ok"


class TestBackendCallSpan:
    def test_records_backend_info(self, _setup_tracer):
        with backend_call_span(
            backend="vllm", model="Qwen3.6-35B", enable_thinking=True,
        ):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.backend.type"] == "vllm"
        assert attrs["forge.backend.model"] == "Qwen3.6-35B"
        assert attrs["forge.backend.enable_thinking"] is True


class TestBackendNormalizeSpan:
    def test_records_normalize_flags(self, _setup_tracer):
        with backend_normalize_span(
            backend="dashscope",
            flags={"enable_thinking": True, "preserve_thinking": False},
        ):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.normalize.backend"] == "dashscope"
        assert attrs["forge.normalize.enable_thinking"] is True
        assert attrs["forge.normalize.preserve_thinking"] is False


class TestBackendResponseSpan:
    def test_records_token_split(self, _setup_tracer):
        with backend_response_span(
            thinking_tokens=1200, response_tokens=450, has_thinking=True,
        ):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.response.thinking_tokens"] == 1200
        assert attrs["forge.response.response_tokens"] == 450
        assert attrs["forge.response.has_thinking"] is True


class TestPreserveCheckSpan:
    def test_records_preserve_state(self, _setup_tracer):
        with preserve_check_span(
            preserve_enabled=True, reused=True, thinking_content_length=500,
        ):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.preserve.enabled"] is True
        assert attrs["forge.preserve.reused"] is True
        assert attrs["forge.preserve.thinking_length"] == 500

    def test_preserve_not_reused(self, _setup_tracer):
        with preserve_check_span(
            preserve_enabled=True, reused=False, thinking_content_length=0,
        ):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.preserve.reused"] is False
        assert attrs["forge.preserve.thinking_length"] == 0


class TestMtpConfigSpan:
    def test_records_mtp_decision(self, _setup_tracer):
        with mtp_config_span(
            enabled=True, reason="crossover at 4 tokens",
            num_speculative_tokens=4, acceptance_rate=0.78,
        ):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.mtp.enabled"] is True
        assert attrs["forge.mtp.reason"] == "crossover at 4 tokens"
        assert attrs["forge.mtp.num_speculative_tokens"] == 4
        assert attrs["forge.mtp.acceptance_rate"] == 0.78

    def test_mtp_disabled(self, _setup_tracer):
        with mtp_config_span(enabled=False, reason="backend unsupported"):
            pass
        spans = _get_spans(_setup_tracer)
        attrs = dict(spans[0].attributes)
        assert attrs["forge.mtp.enabled"] is False


class TestRecordError:
    def test_sets_error_status(self, _setup_tracer):
        tracer = trace.get_tracer("test")
        with tracer.start_as_current_span("test.error") as span:
            exc = ValueError("something broke")
            record_error(span, exc)
        spans = _get_spans(_setup_tracer)
        assert spans[0].status.status_code.name == "ERROR"
        assert "something broke" in spans[0].status.description


class TestSpanNesting:
    def test_session_contains_child_spans(self, _setup_tracer):
        with session_span():
            with think_decision_span(mode="think", reason="test"):
                pass
            with budget_check_span(
                total_tokens=200000, used_tokens=10000,
                available_tokens=190000, action="ok",
            ):
                pass
        spans = _get_spans(_setup_tracer)
        assert len(spans) == 3
        # Child spans should reference the root as parent
        root_span = [s for s in spans if s.name == "forge.session"][0]
        children = [s for s in spans if s.name != "forge.session"]
        for child in children:
            assert child.parent.span_id == root_span.context.span_id

    def test_backend_call_contains_normalize_and_response(self, _setup_tracer):
        with backend_call_span(backend="vllm", model="test"):
            with backend_normalize_span(backend="vllm"):
                pass
            with backend_response_span(
                thinking_tokens=100, response_tokens=50,
            ):
                pass
        spans = _get_spans(_setup_tracer)
        assert len(spans) == 3
        parent = [s for s in spans if s.name == SPAN_BACKEND_CALL][0]
        children = [s for s in spans if s.name != SPAN_BACKEND_CALL]
        for child in children:
            assert child.parent.span_id == parent.context.span_id
