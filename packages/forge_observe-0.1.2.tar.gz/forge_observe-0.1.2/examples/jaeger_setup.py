"""Example: forge-observe exporting to Jaeger via OTLP.

Prerequisites:
    pip install qwen-think forge-observe opentelemetry-exporter-otlp

    # Run Jaeger with OTLP collector enabled:
    docker run -d --name jaeger \
        -p 16686:16686 \
        -p 4317:4317 \
        jaegertracing/all-in-one:latest

Usage:
    python examples/jaeger_setup.py

Then open http://localhost:16686 and search for service "forge-observe".
"""

from forge_observe import configure, instrument

# Configure to point at local Jaeger OTLP endpoint
configure(
    service_name="forge-observe",
    otlp_endpoint="http://localhost:4317",
    otlp_protocol="grpc",
)

# One line to auto-instrument qwen-think
instrument()

# Now use qwen-think as normal -- spans are emitted automatically.
# from qwen_think import ThinkingSession
# session = ThinkingSession(client=your_openai_client)
# response = session.chat("Implement a binary search tree")

print("forge-observe configured for Jaeger at localhost:4317")
print("Open http://localhost:16686 to view traces")
