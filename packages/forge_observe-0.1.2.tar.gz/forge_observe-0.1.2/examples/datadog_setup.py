"""Example: forge-observe exporting to Datadog via OTLP.

Prerequisites:
    pip install qwen-think forge-observe opentelemetry-exporter-otlp

    # The Datadog Agent must be running with OTLP ingestion enabled.
    # In datadog.yaml or via env vars:
    #   otlp_config:
    #     receiver:
    #       protocols:
    #         grpc:
    #           endpoint: 0.0.0.0:4317

Usage:
    python examples/datadog_setup.py
"""

from forge_observe import configure, instrument

# Datadog Agent OTLP receiver (default gRPC port)
configure(
    service_name="forge-observe",
    otlp_endpoint="http://localhost:4317",
    otlp_protocol="grpc",
    resource_attributes={
        "deployment.environment": "development",
        "service.version": "0.1.0",
    },
)

instrument()

# Now use qwen-think as normal.
# from qwen_think import ThinkingSession
# session = ThinkingSession(client=your_openai_client)
# response = session.chat("Refactor this module to use dependency injection")

print("forge-observe configured for Datadog Agent at localhost:4317")
