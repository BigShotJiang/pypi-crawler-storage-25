"""Example: forge-observe exporting to Grafana Tempo via OTLP.

Prerequisites:
    pip install qwen-think forge-observe opentelemetry-exporter-otlp

    # Run Grafana Tempo (or Grafana Cloud) with OTLP receiver enabled.
    # Default OTLP gRPC port is 4317, HTTP is 4318.

Usage:
    python examples/grafana_setup.py
"""

from forge_observe import configure, instrument

# Grafana Tempo typically listens on port 4317 (gRPC) or 4318 (HTTP)
configure(
    service_name="forge-observe",
    otlp_endpoint="http://localhost:4317",
    otlp_protocol="grpc",
    resource_attributes={
        "deployment.environment": "development",
    },
)

instrument()

# Now use qwen-think as normal.
# from qwen_think import ThinkingSession
# session = ThinkingSession(client=your_openai_client)
# response = session.chat("Design a REST API for a todo app")

print("forge-observe configured for Grafana Tempo at localhost:4317")
