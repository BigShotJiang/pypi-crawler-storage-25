"""Metric instruments and recording helpers."""

from __future__ import annotations

from typing import Dict, Optional

from opentelemetry import metrics

METER_NAME = "forge-observe"


class ForgeMetrics:
    """Manages all forge-observe metric instruments."""

    def __init__(self) -> None:
        self._meter: Optional[metrics.Meter] = None
        self._budget_remaining: Optional[metrics.ObservableGauge] = None
        self._thinking_tokens: Optional[metrics.Counter] = None
        self._response_tokens: Optional[metrics.Counter] = None
        self._mode_switches: Optional[metrics.Counter] = None
        self._preserve_reuse_rate: Optional[metrics.ObservableGauge] = None
        self._mtp_acceptance_rate: Optional[metrics.ObservableGauge] = None

        # Internal state for observable gauges
        self._last_budget_remaining: int = 0
        self._preserve_reuse_total: int = 0
        self._preserve_reuse_hits: int = 0
        self._last_mtp_acceptance: float = 0.0

    def setup(self) -> None:
        """Create all metric instruments from the global MeterProvider."""
        self._meter = metrics.get_meter(METER_NAME)

        self._budget_remaining = self._meter.create_observable_gauge(
            name="forge.session.budget_remaining",
            description="Tokens remaining in the context budget",
            unit="tokens",
            callbacks=[self._observe_budget_remaining],
        )

        self._thinking_tokens = self._meter.create_counter(
            name="forge.session.thinking_tokens",
            description="Total thinking tokens emitted",
            unit="tokens",
        )

        self._response_tokens = self._meter.create_counter(
            name="forge.session.response_tokens",
            description="Total response tokens emitted",
            unit="tokens",
        )

        self._mode_switches = self._meter.create_counter(
            name="forge.session.mode_switches",
            description="Number of think/instruct mode switches",
            unit="switches",
        )

        self._preserve_reuse_rate = self._meter.create_observable_gauge(
            name="forge.session.preserve_reuse_rate",
            description="Fraction of turns that reused prior thinking",
            unit="ratio",
            callbacks=[self._observe_preserve_reuse_rate],
        )

        self._mtp_acceptance_rate = self._meter.create_observable_gauge(
            name="forge.mtp.acceptance_rate",
            description="Speculative token acceptance rate",
            unit="ratio",
            callbacks=[self._observe_mtp_acceptance_rate],
        )

    @property
    def is_setup(self) -> bool:
        return self._meter is not None

    def record_budget_remaining(self, tokens: int) -> None:
        """Update the budget remaining gauge value."""
        self._last_budget_remaining = tokens

    def record_thinking_tokens(
        self, count: int, attributes: Optional[Dict[str, str]] = None,
    ) -> None:
        """Increment the thinking tokens counter."""
        if self._thinking_tokens is not None:
            self._thinking_tokens.add(count, attributes=attributes or {})

    def record_response_tokens(
        self, count: int, attributes: Optional[Dict[str, str]] = None,
    ) -> None:
        """Increment the response tokens counter."""
        if self._response_tokens is not None:
            self._response_tokens.add(count, attributes=attributes or {})

    def record_mode_switch(
        self, attributes: Optional[Dict[str, str]] = None,
    ) -> None:
        """Increment the mode switches counter."""
        if self._mode_switches is not None:
            self._mode_switches.add(1, attributes=attributes or {})

    def record_preserve_reuse(self, reused: bool) -> None:
        """Record whether a turn reused prior thinking content."""
        self._preserve_reuse_total += 1
        if reused:
            self._preserve_reuse_hits += 1

    def record_mtp_acceptance_rate(self, rate: float) -> None:
        """Update the MTP acceptance rate gauge value."""
        self._last_mtp_acceptance = rate

    def _observe_budget_remaining(
        self, options: metrics.CallbackOptions,
    ) -> list:
        return [
            metrics.Observation(value=self._last_budget_remaining),
        ]

    def _observe_preserve_reuse_rate(
        self, options: metrics.CallbackOptions,
    ) -> list:
        if self._preserve_reuse_total == 0:
            rate = 0.0
        else:
            rate = self._preserve_reuse_hits / self._preserve_reuse_total
        return [
            metrics.Observation(value=rate),
        ]

    def _observe_mtp_acceptance_rate(
        self, options: metrics.CallbackOptions,
    ) -> list:
        return [
            metrics.Observation(value=self._last_mtp_acceptance),
        ]

    def reset(self) -> None:
        """Reset all internal state (for tests)."""
        self._last_budget_remaining = 0
        self._preserve_reuse_total = 0
        self._preserve_reuse_hits = 0
        self._last_mtp_acceptance = 0.0


# Module-level singleton
forge_metrics = ForgeMetrics()
