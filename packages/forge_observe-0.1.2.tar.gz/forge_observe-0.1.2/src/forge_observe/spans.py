"""Span definitions and creation helpers."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional

from opentelemetry import trace
from opentelemetry.trace import Span, StatusCode

TRACER_NAME = "forge-observe"

SPAN_SESSION = "forge.session"
SPAN_THINK_DECISION = "forge.session.think_decision"
SPAN_PARAM_SWAP = "forge.session.param_swap"
SPAN_BUDGET_CHECK = "forge.session.budget_check"
SPAN_BACKEND_CALL = "forge.session.backend_call"
SPAN_BACKEND_NORMALIZE = "forge.backend.normalize"
SPAN_BACKEND_RESPONSE = "forge.backend.response"
SPAN_PRESERVE_CHECK = "forge.session.preserve_check"
SPAN_MTP_CONFIG = "forge.mtp.config_decision"


def _get_tracer() -> trace.Tracer:
    return trace.get_tracer(TRACER_NAME)


@contextmanager
def session_span(
    attributes: Optional[Dict[str, Any]] = None,
) -> Generator[Span, None, None]:
    """Root span for a ThinkingSession.chat() call."""
    tracer = _get_tracer()
    with tracer.start_as_current_span(
        SPAN_SESSION, attributes=attributes or {}
    ) as span:
        yield span


@contextmanager
def think_decision_span(
    mode: str,
    reason: str,
    complexity: str = "",
    confidence: float = 0.0,
) -> Generator[Span, None, None]:
    """Span for a router think/instruct decision."""
    tracer = _get_tracer()
    attrs = {
        "forge.decision.mode": mode,
        "forge.decision.reason": reason,
        "forge.decision.complexity": complexity,
        "forge.decision.confidence": confidence,
    }
    with tracer.start_as_current_span(
        SPAN_THINK_DECISION, attributes=attrs
    ) as span:
        yield span


@contextmanager
def param_swap_span(
    from_mode: str,
    to_mode: str,
    params: Optional[Dict[str, Any]] = None,
) -> Generator[Span, None, None]:
    """Span for a sampling parameter swap event."""
    tracer = _get_tracer()
    attrs: Dict[str, Any] = {
        "forge.swap.from_mode": from_mode,
        "forge.swap.to_mode": to_mode,
    }
    if params:
        attrs["forge.swap.temperature"] = params.get("temperature", 0.0)
        attrs["forge.swap.top_p"] = params.get("top_p", 0.0)
    with tracer.start_as_current_span(SPAN_PARAM_SWAP, attributes=attrs) as span:
        yield span


@contextmanager
def budget_check_span(
    total_tokens: int,
    used_tokens: int,
    available_tokens: int,
    action: str,
) -> Generator[Span, None, None]:
    """Span for a budget evaluation."""
    tracer = _get_tracer()
    attrs = {
        "forge.budget.total": total_tokens,
        "forge.budget.used": used_tokens,
        "forge.budget.available": available_tokens,
        "forge.budget.action": action,
    }
    with tracer.start_as_current_span(
        SPAN_BUDGET_CHECK, attributes=attrs
    ) as span:
        yield span


@contextmanager
def backend_call_span(
    backend: str,
    model: str,
    enable_thinking: bool = True,
) -> Generator[Span, None, None]:
    """Span for a backend API call (parent for normalize + response)."""
    tracer = _get_tracer()
    attrs = {
        "forge.backend.type": backend,
        "forge.backend.model": model,
        "forge.backend.enable_thinking": enable_thinking,
    }
    with tracer.start_as_current_span(
        SPAN_BACKEND_CALL, attributes=attrs
    ) as span:
        yield span


@contextmanager
def backend_normalize_span(
    backend: str,
    flags: Optional[Dict[str, Any]] = None,
) -> Generator[Span, None, None]:
    """Span for backend flag normalization."""
    tracer = _get_tracer()
    attrs: Dict[str, Any] = {"forge.normalize.backend": backend}
    if flags:
        for k, v in flags.items():
            if isinstance(v, (str, int, float, bool)):
                attrs[f"forge.normalize.{k}"] = v
    with tracer.start_as_current_span(
        SPAN_BACKEND_NORMALIZE, attributes=attrs
    ) as span:
        yield span


@contextmanager
def backend_response_span(
    thinking_tokens: int = 0,
    response_tokens: int = 0,
    has_thinking: bool = False,
) -> Generator[Span, None, None]:
    """Span for a backend response with token split info."""
    tracer = _get_tracer()
    attrs = {
        "forge.response.thinking_tokens": thinking_tokens,
        "forge.response.response_tokens": response_tokens,
        "forge.response.has_thinking": has_thinking,
    }
    with tracer.start_as_current_span(
        SPAN_BACKEND_RESPONSE, attributes=attrs
    ) as span:
        yield span


@contextmanager
def preserve_check_span(
    preserve_enabled: bool,
    reused: bool = False,
    thinking_content_length: int = 0,
) -> Generator[Span, None, None]:
    """Span for preserve_thinking reuse evaluation."""
    tracer = _get_tracer()
    attrs = {
        "forge.preserve.enabled": preserve_enabled,
        "forge.preserve.reused": reused,
        "forge.preserve.thinking_length": thinking_content_length,
    }
    with tracer.start_as_current_span(
        SPAN_PRESERVE_CHECK, attributes=attrs
    ) as span:
        yield span


@contextmanager
def mtp_config_span(
    enabled: bool,
    reason: str = "",
    num_speculative_tokens: int = 0,
    acceptance_rate: float = 0.0,
) -> Generator[Span, None, None]:
    """Span for MTP speculative decoding config decision."""
    tracer = _get_tracer()
    attrs = {
        "forge.mtp.enabled": enabled,
        "forge.mtp.reason": reason,
        "forge.mtp.num_speculative_tokens": num_speculative_tokens,
        "forge.mtp.acceptance_rate": acceptance_rate,
    }
    with tracer.start_as_current_span(
        SPAN_MTP_CONFIG, attributes=attrs
    ) as span:
        yield span


def record_error(span: Span, error: Exception) -> None:
    """Record an exception on a span and set status to ERROR."""
    span.set_status(StatusCode.ERROR, str(error))
    span.record_exception(error)
