"""Configuration for tracing and metrics export."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ForgeObserveConfig:
    """Configuration for forge-observe instrumentation."""

    service_name: str = "forge-observe"
    otlp_endpoint: str = "http://localhost:4317"
    otlp_protocol: str = "grpc"
    enabled: bool = True
    console_export: bool = False
    export_timeout_ms: int = 30000
    max_export_batch_size: int = 512
    resource_attributes: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        env = os.environ.get
        self.service_name = env(
            "FORGE_OBSERVE_SERVICE_NAME", self.service_name
        )
        self.otlp_endpoint = env(
            "FORGE_OBSERVE_OTLP_ENDPOINT", self.otlp_endpoint
        )
        self.otlp_protocol = env(
            "FORGE_OBSERVE_OTLP_PROTOCOL", self.otlp_protocol
        )
        enabled = env("FORGE_OBSERVE_ENABLED")
        if enabled is not None:
            self.enabled = enabled.lower() in ("1", "true", "yes")
        console = env("FORGE_OBSERVE_CONSOLE_EXPORT")
        if console is not None:
            self.console_export = console.lower() in ("1", "true", "yes")


_current_config: Optional[ForgeObserveConfig] = None


def configure(**kwargs) -> ForgeObserveConfig:
    """Create or update the global configuration."""
    global _current_config
    _current_config = ForgeObserveConfig(**kwargs)
    return _current_config


def get_config() -> ForgeObserveConfig:
    """Return the current config, creating a default if needed."""
    global _current_config
    if _current_config is None:
        _current_config = ForgeObserveConfig()
    return _current_config


def _reset_config() -> None:
    """Reset global config to None (mainly for tests)."""
    global _current_config
    _current_config = None
