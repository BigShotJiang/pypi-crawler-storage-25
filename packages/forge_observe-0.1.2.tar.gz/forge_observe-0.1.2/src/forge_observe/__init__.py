"""OpenTelemetry instrumentation for qwen-think reasoning sessions."""

from __future__ import annotations

from .config import ForgeObserveConfig, configure, get_config
from .instrumentor import instrument, is_instrumented, uninstrument
from .metrics import forge_metrics
from .spans import (
    SPAN_BACKEND_CALL,
    SPAN_BACKEND_NORMALIZE,
    SPAN_BACKEND_RESPONSE,
    SPAN_BUDGET_CHECK,
    SPAN_MTP_CONFIG,
    SPAN_PARAM_SWAP,
    SPAN_PRESERVE_CHECK,
    SPAN_SESSION,
    SPAN_THINK_DECISION,
    backend_call_span,
    backend_normalize_span,
    backend_response_span,
    budget_check_span,
    mtp_config_span,
    param_swap_span,
    preserve_check_span,
    session_span,
    think_decision_span,
)

__version__ = "0.1.2"


class ForgeTracer:
    """Manual tracing API -- context managers that create named spans."""

    @staticmethod
    def session(attributes=None):
        """Create a root ``forge.session`` span."""
        return session_span(attributes=attributes)

    @staticmethod
    def think_decision(mode, reason, complexity="", confidence=0.0):
        """Create a ``forge.session.think_decision`` span."""
        return think_decision_span(
            mode=mode, reason=reason,
            complexity=complexity, confidence=confidence,
        )

    @staticmethod
    def param_swap(from_mode, to_mode, params=None):
        """Create a ``forge.session.param_swap`` span."""
        return param_swap_span(
            from_mode=from_mode, to_mode=to_mode, params=params,
        )

    @staticmethod
    def budget_check(total_tokens, used_tokens, available_tokens, action):
        """Create a ``forge.session.budget_check`` span."""
        return budget_check_span(
            total_tokens=total_tokens,
            used_tokens=used_tokens,
            available_tokens=available_tokens,
            action=action,
        )

    @staticmethod
    def backend_call(backend, model, enable_thinking=True):
        """Create a ``forge.session.backend_call`` span."""
        return backend_call_span(
            backend=backend, model=model,
            enable_thinking=enable_thinking,
        )

    @staticmethod
    def backend_normalize(backend, flags=None):
        """Create a ``forge.backend.normalize`` span."""
        return backend_normalize_span(backend=backend, flags=flags)

    @staticmethod
    def backend_response(
        thinking_tokens=0, response_tokens=0, has_thinking=False,
    ):
        """Create a ``forge.backend.response`` span."""
        return backend_response_span(
            thinking_tokens=thinking_tokens,
            response_tokens=response_tokens,
            has_thinking=has_thinking,
        )

    @staticmethod
    def preserve_check(
        preserve_enabled, reused=False, thinking_content_length=0,
    ):
        """Create a ``forge.session.preserve_check`` span."""
        return preserve_check_span(
            preserve_enabled=preserve_enabled,
            reused=reused,
            thinking_content_length=thinking_content_length,
        )

    @staticmethod
    def mtp_config(
        enabled, reason="", num_speculative_tokens=0, acceptance_rate=0.0,
    ):
        """Create a ``forge.mtp.config_decision`` span."""
        return mtp_config_span(
            enabled=enabled, reason=reason,
            num_speculative_tokens=num_speculative_tokens,
            acceptance_rate=acceptance_rate,
        )


__all__ = [
    # Auto-instrumentation
    "instrument",
    "uninstrument",
    "is_instrumented",
    # Manual tracing
    "ForgeTracer",
    # Configuration
    "configure",
    "get_config",
    "ForgeObserveConfig",
    # Metrics
    "forge_metrics",
    # Span name constants (for filtering/querying)
    "SPAN_SESSION",
    "SPAN_THINK_DECISION",
    "SPAN_PARAM_SWAP",
    "SPAN_BUDGET_CHECK",
    "SPAN_BACKEND_CALL",
    "SPAN_BACKEND_NORMALIZE",
    "SPAN_BACKEND_RESPONSE",
    "SPAN_PRESERVE_CHECK",
    "SPAN_MTP_CONFIG",
    # Span context managers (low-level)
    "session_span",
    "think_decision_span",
    "param_swap_span",
    "budget_check_span",
    "backend_call_span",
    "backend_normalize_span",
    "backend_response_span",
    "preserve_check_span",
    "mtp_config_span",
]
