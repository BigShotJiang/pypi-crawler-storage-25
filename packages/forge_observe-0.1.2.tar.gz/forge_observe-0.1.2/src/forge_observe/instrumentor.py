"""Auto-instrumentation patches for qwen-think."""

from __future__ import annotations

import functools
import logging
from typing import Any, Optional

from opentelemetry import trace
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor

from .config import ForgeObserveConfig, get_config
from .exporters import get_span_exporter
from .metrics import forge_metrics
from .spans import (
    backend_normalize_span,
    backend_response_span,
    budget_check_span,
    param_swap_span,
    preserve_check_span,
    record_error,
    session_span,
    think_decision_span,
)

logger = logging.getLogger("forge-observe")

_instrumented = False
_original_chat = None
_original_route = None
_original_check_budget = None
_original_build_payload = None


def _patch_chat(original_chat: Any) -> Any:
    """Wrap ThinkingSession.chat() with tracing spans and metrics."""

    @functools.wraps(original_chat)
    def wrapped_chat(self: Any, message: str, **kwargs: Any) -> Any:
        session_attrs = {
            "forge.session.backend": self.backend.value,
            "forge.session.model": self.model,
            "forge.session.mode": self._thinking_mode.value,
            "forge.session.message_count": len(self._messages),
        }

        with session_span(attributes=session_attrs) as root:
            try:
                # Track mode before call for switch detection
                mode_before = self._thinking_mode.value

                result = original_chat(self, message, **kwargs)

                mode_after = self._thinking_mode.value

                # Record mode switch
                if mode_before != mode_after:
                    with param_swap_span(
                        from_mode=mode_before, to_mode=mode_after
                    ):
                        pass
                    forge_metrics.record_mode_switch(
                        attributes={
                            "forge.swap.from": mode_before,
                            "forge.swap.to": mode_after,
                        }
                    )

                # Record budget status after call
                budget_status = self.budget_manager.check_budget(self._messages)
                with budget_check_span(
                    total_tokens=budget_status.total_tokens,
                    used_tokens=budget_status.used_tokens,
                    available_tokens=budget_status.available_tokens,
                    action=budget_status.action.value,
                ):
                    pass
                forge_metrics.record_budget_remaining(
                    budget_status.available_tokens
                )

                # Record token counts from the last assistant message
                if self._messages:
                    last_msg = self._messages[-1]
                    if last_msg.role == "assistant":
                        has_thinking = last_msg.thinking_content is not None
                        thinking_len = len(last_msg.thinking_content or "")
                        response_len = len(last_msg.content or "")

                        # matches qwen-think's AVG_TOKENS_PER_CHAR (0.5)
                        thinking_toks = max(1, int(thinking_len * 0.5)) if thinking_len else 0
                        response_toks = max(1, int(response_len * 0.5)) if response_len else 0

                        with backend_response_span(
                            thinking_tokens=thinking_toks,
                            response_tokens=response_toks,
                            has_thinking=has_thinking,
                        ):
                            pass

                        if thinking_toks > 0:
                            forge_metrics.record_thinking_tokens(thinking_toks)
                        if response_toks > 0:
                            forge_metrics.record_response_tokens(response_toks)

                        # preserve_thinking reuse: if the session has
                        # preserve_thinking on and the response includes
                        # thinking content, the model had access to its
                        # prior chain of thought.
                        reused = (
                            self.preserve_thinking
                            and has_thinking
                            and len(self._messages) > 2
                        )
                        forge_metrics.record_preserve_reuse(reused=reused)
                        with preserve_check_span(
                            preserve_enabled=self.preserve_thinking,
                            reused=reused,
                            thinking_content_length=thinking_len,
                        ):
                            pass

                return result

            except Exception as exc:
                record_error(root, exc)
                raise

    return wrapped_chat


def _patch_route(original_route: Any) -> Any:
    """Wrap ComplexityRouter.route() with a think_decision span."""

    @functools.wraps(original_route)
    def wrapped_route(self: Any, query: str, **kwargs: Any) -> Any:
        decision = original_route(self, query, **kwargs)

        with think_decision_span(
            mode=decision.mode.value,
            reason=decision.reasoning,
            complexity=decision.complexity.value,
            confidence=decision.confidence,
        ):
            pass

        return decision

    return wrapped_route


def _patch_check_budget(original_check: Any) -> Any:
    """Wrap BudgetManager.check_budget() with a budget_check span."""

    @functools.wraps(original_check)
    def wrapped_check(self: Any, messages: Any) -> Any:
        status = original_check(self, messages)

        with budget_check_span(
            total_tokens=status.total_tokens,
            used_tokens=status.used_tokens,
            available_tokens=status.available_tokens,
            action=status.action.value,
        ):
            pass

        forge_metrics.record_budget_remaining(status.available_tokens)
        return status

    return wrapped_check


def _patch_build_payload(original_build: Any) -> Any:
    """Wrap BaseBackend.build_payload() with a backend_normalize span."""

    @functools.wraps(original_build)
    def wrapped_build(self: Any, *args: Any, **kwargs: Any) -> Any:
        payload = original_build(self, *args, **kwargs)

        flags = {
            "enable_thinking": payload.enable_thinking,
            "preserve_thinking": payload.preserve_thinking,
        }
        with backend_normalize_span(
            backend=self.backend.value, flags=flags
        ):
            pass

        return payload

    return wrapped_build


def _setup_tracer_provider(config: ForgeObserveConfig) -> TracerProvider:
    """Create and register a TracerProvider from config."""
    resource = Resource.create(
        {"service.name": config.service_name, **config.resource_attributes}
    )
    provider = TracerProvider(resource=resource)

    exporter = get_span_exporter(config)

    if config.console_export:
        provider.add_span_processor(SimpleSpanProcessor(exporter))
    else:
        provider.add_span_processor(
            BatchSpanProcessor(
                exporter,
                max_export_batch_size=config.max_export_batch_size,
            )
        )

    trace.set_tracer_provider(provider)
    return provider


def _setup_meter_provider(config: ForgeObserveConfig) -> None:
    """Create a MeterProvider and initialize forge metrics."""
    resource = Resource.create(
        {"service.name": config.service_name, **config.resource_attributes}
    )
    provider = MeterProvider(resource=resource)
    metrics_mod = __import__("opentelemetry", fromlist=["metrics"])
    metrics_mod.metrics.set_meter_provider(provider)
    forge_metrics.setup()


def instrument(config: Optional[ForgeObserveConfig] = None) -> None:
    """Patch qwen-think to emit OTel traces and metrics."""
    global _instrumented, _original_chat, _original_route
    global _original_check_budget, _original_build_payload

    if _instrumented:
        logger.debug("forge-observe already instrumented, skipping")
        return

    cfg = config or get_config()
    if not cfg.enabled:
        logger.info("forge-observe disabled via config")
        return

    # Import qwen-think components
    try:
        from qwen_think.backends.base import BaseBackend
        from qwen_think.budget import BudgetManager
        from qwen_think.router import ComplexityRouter
        from qwen_think.session import ThinkingSession
    except ImportError as exc:
        raise ImportError(
            "forge-observe requires qwen-think to be installed. "
            "Install with: pip install qwen-think"
        ) from exc

    # Set up OTel providers
    _setup_tracer_provider(cfg)
    _setup_meter_provider(cfg)

    # Monkey-patch
    _original_chat = ThinkingSession.chat
    ThinkingSession.chat = _patch_chat(ThinkingSession.chat)

    _original_route = ComplexityRouter.route
    ComplexityRouter.route = _patch_route(ComplexityRouter.route)

    _original_check_budget = BudgetManager.check_budget
    BudgetManager.check_budget = _patch_check_budget(BudgetManager.check_budget)

    _original_build_payload = BaseBackend.build_payload
    BaseBackend.build_payload = _patch_build_payload(BaseBackend.build_payload)

    _instrumented = True
    logger.info("forge-observe instrumentation active")


def uninstrument() -> None:
    """Remove monkey-patches and restore original methods."""
    global _instrumented, _original_chat, _original_route
    global _original_check_budget, _original_build_payload

    if not _instrumented:
        return

    try:
        from qwen_think.backends.base import BaseBackend
        from qwen_think.budget import BudgetManager
        from qwen_think.router import ComplexityRouter
        from qwen_think.session import ThinkingSession
    except ImportError:
        _instrumented = False
        return

    if _original_chat is not None:
        ThinkingSession.chat = _original_chat
    if _original_route is not None:
        ComplexityRouter.route = _original_route
    if _original_check_budget is not None:
        BudgetManager.check_budget = _original_check_budget
    if _original_build_payload is not None:
        BaseBackend.build_payload = _original_build_payload

    _instrumented = False
    _original_chat = None
    _original_route = None
    _original_check_budget = None
    _original_build_payload = None

    forge_metrics.reset()
    logger.info("forge-observe instrumentation removed")


def is_instrumented() -> bool:
    """Return True if forge-observe patches are currently active."""
    return _instrumented
