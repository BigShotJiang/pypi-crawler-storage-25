"""OTLP span exporter with gRPC/HTTP fallback."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from opentelemetry.sdk.trace.export import SpanExporter

from ..config import ForgeObserveConfig, get_config


def create_otlp_exporter(
    config: ForgeObserveConfig | None = None,
) -> "SpanExporter":
    """Create an OTLP exporter using gRPC or HTTP based on config."""
    cfg = config or get_config()

    if cfg.otlp_protocol == "grpc":
        try:
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
                OTLPSpanExporter,
            )

            return OTLPSpanExporter(
                endpoint=cfg.otlp_endpoint,
                timeout=cfg.export_timeout_ms / 1000,
            )
        except ImportError:
            import warnings

            warnings.warn(
                "grpc exporter not available, falling back to HTTP",
                stacklevel=2,
            )

    # Fall back to HTTP
    try:
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter,
        )

        endpoint = cfg.otlp_endpoint
        if not endpoint.endswith("/v1/traces"):
            endpoint = endpoint.rstrip("/") + "/v1/traces"
        return OTLPSpanExporter(
            endpoint=endpoint,
            timeout=cfg.export_timeout_ms / 1000,
        )
    except ImportError as exc:
        raise ImportError(
            "OTLP export requires opentelemetry-exporter-otlp-proto-grpc "
            "or opentelemetry-exporter-otlp-proto-http. "
            "Install with: pip install opentelemetry-exporter-otlp"
        ) from exc
