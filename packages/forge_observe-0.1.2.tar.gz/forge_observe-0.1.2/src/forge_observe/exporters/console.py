"""Console/stdout span exporter for debugging."""

from __future__ import annotations

from opentelemetry.sdk.trace.export import ConsoleSpanExporter, SpanExporter


def create_console_exporter() -> SpanExporter:
    """Create a console exporter that prints spans to stdout."""
    return ConsoleSpanExporter()
