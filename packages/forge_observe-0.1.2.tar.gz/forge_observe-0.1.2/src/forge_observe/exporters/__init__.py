"""Exporter registry."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from opentelemetry.sdk.trace.export import SpanExporter

from ..config import ForgeObserveConfig, get_config


def get_span_exporter(
    config: Optional[ForgeObserveConfig] = None,
) -> "SpanExporter":
    """Return a span exporter matching the config."""
    cfg = config or get_config()

    if cfg.console_export:
        from .console import create_console_exporter

        return create_console_exporter()

    from .otlp import create_otlp_exporter

    return create_otlp_exporter(cfg)


__all__ = ["get_span_exporter"]
