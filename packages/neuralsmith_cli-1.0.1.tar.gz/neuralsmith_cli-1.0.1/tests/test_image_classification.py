"""Tests for image classification wizard."""

import pytest
import subprocess
import sys
from pathlib import Path


@pytest.mark.slow
def test_image_classification_synthetic_dataset(test_outputs_dir, synthetic_image_dataset):
    """Test image classification on synthetic dataset."""
    data_path = synthetic_image_dataset
    output_dir = test_outputs_dir / "image_clf_test"
    
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "neuralsmith",
            "image-classification",
            "--data-path",
            str(data_path),
            "--output-dir",
            str(output_dir),
            "--epochs",
            "1",  # Minimal epochs for testing
        ],
        cwd=str(Path(__file__).parent.parent),
        capture_output=True,
        text=True,
    )
    
    assert result.returncode == 0, f"Command failed: {result.stderr}"
    assert output_dir.exists()
    assert (output_dir / "processed").exists() or (data_path / "processed").exists()


def test_image_classification_preprocessing(test_outputs_dir, synthetic_image_dataset):
    """Test image preprocessing logic."""
    from neuralsmith.image_classification.preprocess import preprocess_image_dataset
    
    data_path = synthetic_image_dataset
    
    try:
        preprocess_image_dataset(
            data_path=str(data_path),
            processed_dir=str(test_outputs_dir / "preprocess_test"),
            target_size=(64, 64),
            seed=42,
        )
        assert True  # If no exception, preprocessing worked
    except Exception as e:
        pytest.fail(f"Preprocessing failed: {e}")
