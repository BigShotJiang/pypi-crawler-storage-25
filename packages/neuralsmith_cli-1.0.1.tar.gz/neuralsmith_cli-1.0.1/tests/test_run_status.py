"""Tests for neuralsmith.run_status and output progress callbacks."""

from pathlib import Path
from unittest.mock import patch

import pytest

from neuralsmith.run_status import (
    STATUS_FILENAME,
    append_event,
    discover_status_files,
    finish_run,
    read_status,
    start_run,
    status_path,
    update_run,
    update_image_training_progress,
)
from neuralsmith.output import set_progress_callback, step, set_verbosity


def test_start_update_finish_run(tmp_path: Path) -> None:
    od = tmp_path / "models"
    od.mkdir()
    rid = start_run(od, "image-classification", extra={"foo": "bar"})
    assert len(rid) == 36
    data = read_status(od)
    assert data is not None
    assert data["command"] == "image-classification"
    assert data["state"] == "running"
    assert data["foo"] == "bar"

    update_run(od, phase="training", last_message="Training…")
    data2 = read_status(od)
    assert data2["phase"] == "training"
    assert data2["last_message"] == "Training…"

    finish_run(od, success=True)
    data3 = read_status(od)
    assert data3["state"] == "completed"

    finish_run(od, success=False, error="boom")
    data4 = read_status(od)
    assert data4["state"] == "failed"
    assert data4["error"] == "boom"


def test_read_status_corrupt_file(tmp_path: Path) -> None:
    p = status_path(tmp_path)
    tmp_path.mkdir(parents=True, exist_ok=True)
    p.write_text("not json {{{", encoding="utf-8")
    assert read_status(tmp_path) is None


def test_discover_status_files_order(tmp_path: Path) -> None:
    a = tmp_path / "a"
    b = tmp_path / "b"
    a.mkdir()
    b.mkdir()
    start_run(a, "tabular-classification")
    import time

    time.sleep(0.02)
    start_run(b, "image-classification")
    found = discover_status_files(tmp_path, max_depth=2)
    names = [p.name for p in found]
    assert STATUS_FILENAME in names
    # Newest first (b after a)
    assert found[0].parent == b


def test_update_image_training_progress_epoch(tmp_path: Path) -> None:
    start_run(tmp_path, "image-classification")
    payload = {
        "epoch": 2,
        "train_accuracy": 0.5,
        "val_accuracy": 0.6,
    }
    update_image_training_progress(tmp_path, line_prefix="EPOCH_JSON", payload=payload)
    data = read_status(tmp_path)
    assert data["progress"] == payload
    assert "Epoch 2" in (data["last_message"] or "")


def test_output_progress_callback() -> None:
    seen: list[tuple[str, str]] = []

    def cb(msg: str, kind: str) -> None:
        seen.append((msg, kind))

    set_verbosity(0, quiet=False)
    set_progress_callback(cb)
    try:
        step("hello step")
    finally:
        set_progress_callback(None)
    assert ("hello step", "step") in seen


def test_append_event_creates_file(tmp_path: Path) -> None:
    start_run(tmp_path, "x")
    ep = tmp_path / "neuralsmith_run_events.jsonl"
    assert ep.is_file()
    text = ep.read_text(encoding="utf-8")
    assert "start" in text


def test_watch_status_max_iterations(tmp_path: Path) -> None:
    from neuralsmith.copilot.status import watch_status

    start_run(tmp_path, "timeseries-classification")
    with patch("neuralsmith.copilot.status.time.sleep"):
        watch_status(tmp_path, interval_sec=0.01, max_iterations=3)
