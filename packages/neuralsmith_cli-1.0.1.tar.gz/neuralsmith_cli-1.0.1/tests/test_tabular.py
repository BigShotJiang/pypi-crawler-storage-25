"""Tests for tabular classification and regression wizards."""

import pytest
import subprocess
import sys
from pathlib import Path


@pytest.mark.slow
def test_tabular_classification_iris(test_outputs_dir):
    """Test tabular classification on iris-like dataset."""
    data_path = Path(__file__).parent / "data" / "tabular_classification" / "iris_like_100.csv"
    output_dir = test_outputs_dir / "tabular_clf_test"
    
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "neuralsmith",
            "tabular-classification",
            "--data-path",
            str(data_path),
            "--target-column",
            "species",
            "--output-dir",
            str(output_dir),
            "--mode",
            "fast++",  # Fastest mode for testing
            "--no-eda",  # Skip EDA for speed
        ],
        cwd=str(Path(__file__).parent.parent),
        capture_output=True,
        text=True,
    )
    
    assert result.returncode == 0, f"Command failed: {result.stderr}"
    assert output_dir.exists()


@pytest.mark.slow
def test_tabular_regression_housing(test_outputs_dir):
    """Test tabular regression on housing-like dataset."""
    data_path = Path(__file__).parent / "data" / "tabular_regression" / "housing_like_100.csv"
    output_dir = test_outputs_dir / "tabular_reg_test"
    
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "neuralsmith",
            "tabular-regression",
            "--data-path",
            str(data_path),
            "--target-column",
            "medv",
            "--output-dir",
            str(output_dir),
            "--mode",
            "fast++",
            "--no-eda",
        ],
        cwd=str(Path(__file__).parent.parent),
        capture_output=True,
        text=True,
    )
    
    assert result.returncode == 0, f"Command failed: {result.stderr}"
    assert output_dir.exists()


def test_tabular_eda_wrapper():
    """Test EDA wrapper function."""
    from neuralsmith.tabular.eda import run_eda
    import tempfile
    
    data_path = Path(__file__).parent / "data" / "tabular_classification" / "iris_like_100.csv"
    
    with tempfile.TemporaryDirectory() as tmpdir:
        success = run_eda(
            csv_path=str(data_path),
            target_column="species",
            task="classification",
            output_dir=tmpdir,
        )
        # EDA may fail if dependencies are missing, but should not crash
        assert isinstance(success, bool)


def test_tabular_train_wrapper():
    """Test training wrapper function."""
    from neuralsmith.tabular.train import train_models
    import tempfile
    
    data_path = Path(__file__).parent / "data" / "tabular_classification" / "iris_like_100.csv"
    
    with tempfile.TemporaryDirectory() as tmpdir:
        success = train_models(
            csv_path=str(data_path),
            target_column="species",
            task="classification",
            output_dir=tmpdir,
            mode="fast++",
        )
        # Training may fail if dependencies are missing, but should not crash
        assert isinstance(success, bool)
