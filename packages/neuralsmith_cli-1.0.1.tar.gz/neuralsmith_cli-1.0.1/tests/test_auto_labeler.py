"""Tests for auto-labeler wizard."""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
import tempfile


@pytest.fixture
def sample_tabular_csv_with_labels(tmp_path):
    """Create a sample tabular CSV with labeled/unlabeled samples."""
    n_samples = 50
    np.random.seed(42)
    
    # Generate features
    X = np.random.randn(n_samples, 5)
    y = (X[:, 0] > 0).astype(int)  # Binary labels
    
    df = pd.DataFrame(X, columns=[f"feature_{i}" for i in range(5)])
    df["is_labeled"] = False
    df["label"] = -1
    
    # Label first 20 samples
    df.loc[:19, "is_labeled"] = True
    df.loc[:19, "label"] = y[:20]
    
    csv_path = tmp_path / "tabular_labeled.csv"
    df.to_csv(csv_path, index=False)
    return csv_path


def test_auto_labeler_tabular(sample_tabular_csv_with_labels, test_outputs_dir):
    """Test auto-labeler on tabular data."""
    from neuralsmith.auto_labeler.cli_wrapper import run_auto_labeler
    
    output_path = test_outputs_dir / "auto_labeled_output.csv"
    
    success = run_auto_labeler(
        data_path=str(sample_tabular_csv_with_labels),
        data_type="tabular",
        labeled_column="is_labeled",
        label_column="label",
        output_path=str(output_path),
        k=5,
        min_confidence=0.3,
    )
    
    assert success
    assert output_path.exists()
    
    # Check output
    df_out = pd.read_csv(output_path)
    assert "label" in df_out.columns
    assert "label_confidence" in df_out.columns


def test_weighted_knn():
    """Test weighted KNN labeling logic."""
    from neuralsmith.auto_labeler.weighted_knn import weighted_knn_label
    
    # Create simple test data
    features = np.array([[0, 0], [1, 1], [2, 2], [10, 10], [11, 11]])
    labels = np.array([0, 1, 0, -1, -1])  # Last two unlabeled
    mask = np.array([True, True, True, False, False])
    
    predicted, confidences = weighted_knn_label(
        features=features,
        labels=labels,
        mask=mask,
        k=2,
    )
    
    assert len(predicted) == len(features)
    assert len(confidences) == len(features)
    assert predicted[3] != -1  # Should be labeled
    assert predicted[4] != -1  # Should be labeled


def test_feature_extractors_tabular(sample_tabular_csv_with_labels):
    """Test tabular feature extraction."""
    from neuralsmith.auto_labeler.feature_extractors import extract_features
    
    features, labels, mask = extract_features(
        data_path=str(sample_tabular_csv_with_labels),
        data_type="tabular",
        labeled_column="is_labeled",
        tabular_reducer="pca",
    )
    
    assert features.shape[0] == len(labels)
    assert len(mask) == len(labels)
    assert mask.sum() == 20  # 20 labeled samples
