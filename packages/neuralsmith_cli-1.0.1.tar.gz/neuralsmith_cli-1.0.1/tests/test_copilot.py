"""Tests for CoPilot CLI module."""

import sys
import pytest
from pathlib import Path
from unittest.mock import MagicMock, Mock, patch


@pytest.fixture
def mock_gemini_model():
    """Mock Gemini model for testing."""
    model = MagicMock()
    
    # Mock streaming response
    class MockChunk:
        def __init__(self, text):
            self.text = text
    
    mock_response = [
        MockChunk("Hello"),
        MockChunk("! "),
        MockChunk("How"),
        MockChunk(" can"),
        MockChunk(" I"),
        MockChunk(" help"),
        MockChunk("?"),
    ]
    
    model.generate_content.return_value = mock_response
    return model


@pytest.fixture
def mock_gemini_api(mock_gemini_model):
    """Mock Gemini API configuration."""
    with patch('neuralsmith.copilot.cli.genai') as mock_genai:
        mock_genai.configure = Mock()
        mock_genai.GenerativeModel.return_value = mock_gemini_model
        yield mock_genai


def test_copilot_imports():
    """Test that CoPilot module imports correctly."""
    from neuralsmith.copilot import start_copilot_interactive
    from neuralsmith.copilot.system_prompt import SYSTEM_PROMPT
    from neuralsmith.copilot.validators import validate_csv
    
    assert callable(start_copilot_interactive)
    assert isinstance(SYSTEM_PROMPT, str)
    assert len(SYSTEM_PROMPT) > 0
    assert callable(validate_csv)


def test_copilot_missing_api_key():
    """Test CoPilot behavior when API key is missing."""
    from neuralsmith.copilot.cli import start_copilot_interactive
    
    with patch('neuralsmith.copilot.cli.get_api_key', return_value=None):
        result = start_copilot_interactive()
        assert result == 1


def test_copilot_api_configuration_error():
    """Test CoPilot behavior when API configuration fails."""
    from neuralsmith.copilot.cli import start_copilot_interactive
    
    with patch('neuralsmith.copilot.cli.get_api_key', return_value="test_key"):
        with patch('neuralsmith.copilot.cli.genai.configure', side_effect=Exception("API Error")):
            result = start_copilot_interactive()
            assert result == 1


def test_build_prompt():
    """Test prompt building with history."""
    from neuralsmith.copilot.cli import build_prompt
    
    system_prompt = "You are a helpful assistant."
    history = [
        {"role": "user", "text": "Hello"},
        {"role": "assistant", "text": "Hi there!"},
    ]
    user_input = "How are you?"
    
    prompt = build_prompt(system_prompt, history, user_input)
    
    assert system_prompt in prompt
    assert "Hello" in prompt
    assert "Hi there!" in prompt
    assert user_input in prompt
    assert "Assistant:" in prompt


def test_print_help():
    """Test help command output."""
    from neuralsmith.copilot.cli import print_help
    from io import StringIO
    
    output = StringIO()
    with patch('sys.stdout', output):
        print_help()
    
    help_text = output.getvalue()
    assert "help" in help_text.lower()
    assert "exit" in help_text.lower()


def test_validate_csv(tmp_path):
    """Test CSV validation."""
    from neuralsmith.copilot.validators import validate_csv
    import pandas as pd
    from io import StringIO
    
    # Create test CSV
    csv_path = tmp_path / "test.csv"
    df = pd.DataFrame({
        "feature1": [1, 2, 3],
        "feature2": [4, 5, 6],
        "target": ["A", "B", "A"],
    })
    df.to_csv(csv_path, index=False)
    
    output = StringIO()
    with patch('sys.stdout', output):
        validate_csv(str(csv_path), target_column="target")
    
    output_text = output.getvalue()
    assert "✓ CSV file found" in output_text
    assert "✓ Contains 3 rows" in output_text
    assert "✓ Target column 'target' found" in output_text


def test_validate_image_folder(tmp_path):
    """Test image folder validation."""
    from neuralsmith.copilot.validators import validate_image_folder
    from io import StringIO
    
    # Create test image folder structure
    class_folder = tmp_path / "class1"
    class_folder.mkdir()
    
    # Create dummy image files (just text files with .png extension for testing)
    (class_folder / "img1.png").write_text("dummy")
    (class_folder / "img2.png").write_text("dummy")
    
    output = StringIO()
    with patch('sys.stdout', output):
        # This will fail on actual image reading, but structure check should work
        try:
            validate_image_folder(str(tmp_path))
        except Exception:
            pass  # Expected if PIL can't read dummy files
    
    output_text = output.getvalue()
    # Should at least detect the folder
    assert "Image folder" in output_text or "image" in output_text.lower()


def test_handle_validation_command(tmp_path):
    """Test validation command handler."""
    from neuralsmith.copilot.cli import handle_validation
    import pandas as pd
    from io import StringIO
    
    # Create test CSV
    csv_path = tmp_path / "test.csv"
    df = pd.DataFrame({"col1": [1, 2, 3], "col2": [4, 5, 6]})
    df.to_csv(csv_path, index=False)
    
    output = StringIO()
    with patch('sys.stdout', output):
        handle_validation(str(csv_path))
    
    output_text = output.getvalue()
    assert "Validating CSV" in output_text or "CSV" in output_text


def test_system_prompt_content():
    """Test that system prompt contains expected content."""
    from neuralsmith.copilot.system_prompt import SYSTEM_PROMPT
    
    assert "NeuralSmith CoPilot" in SYSTEM_PROMPT
    assert "image-classification" in SYSTEM_PROMPT
    assert "tabular-classification" in SYSTEM_PROMPT
    assert "CLI" in SYSTEM_PROMPT or "command" in SYSTEM_PROMPT.lower()
    assert "!status" in SYSTEM_PROMPT
    assert "neuralsmith_run_status.json" in SYSTEM_PROMPT


def test_resolve_status_directory_explicit(tmp_path):
    from neuralsmith.copilot.status import resolve_status_directory
    from neuralsmith.run_status import start_run

    models = tmp_path / "models"
    models.mkdir()
    start_run(models, "image-classification")
    assert resolve_status_directory(str(models), tmp_path) == models.resolve()
    assert resolve_status_directory(str(models / "subdir"), tmp_path) is None


def test_handle_run_status_prints(tmp_path, capsys):
    from neuralsmith.copilot.cli import handle_run_status
    from neuralsmith.run_status import start_run

    od = tmp_path / "out"
    od.mkdir()
    start_run(od, "tabular-regression")
    handle_run_status(str(od))
    captured = capsys.readouterr().out
    assert "tabular-regression" in captured
    assert "running" in captured or "completed" in captured


def test_build_neuralsmith_argv_tabular(tmp_path):
    from neuralsmith.copilot.neuralsmith_argv import build_neuralsmith_argv

    csv_path = tmp_path / "d.csv"
    csv_path.write_text("a,b\n1,2\n")
    argv, err = build_neuralsmith_argv(
        "tabular-classification",
        {
            "data-path": str(csv_path),
            "target-column": "b",
            "mode": "fast++",
            "no-eda": True,
        },
        cwd=str(tmp_path),
    )
    assert err is None
    assert argv is not None
    assert argv[:4] == [
        sys.executable,
        "-m",
        "neuralsmith",
        "tabular-classification",
    ]
    assert "--data-path" in argv
    assert str(csv_path.resolve()) in argv
    assert "--target-column" in argv
    assert "--mode" in argv and "fast++" in argv
    assert "--no-eda" in argv


def test_build_neuralsmith_argv_unknown_flag():
    from neuralsmith.copilot.neuralsmith_argv import build_neuralsmith_argv

    argv, err = build_neuralsmith_argv(
        "image-classification",
        {"data-path": "/tmp/x", "evil-flag": "1"},
    )
    assert argv is None
    assert err and "Unknown flag" in err


def test_extract_tool_calls():
    from neuralsmith.copilot.agent_loop import extract_tool_calls

    text = """Here goes.
```tool-json
{"tools": [{"tool": "list_path", "args": {"path": "."}}]}
```
Done."""
    visible, calls = extract_tool_calls(text)
    assert "Here goes" in visible
    assert "```" not in visible
    assert len(calls) == 1
    assert calls[0]["tool"] == "list_path"


def test_inspect_numpy_folder_tool(tmp_path):
    from neuralsmith.copilot.agent_tools import dispatch_readonly_tool
    import numpy as np

    np.save(tmp_path / "a.npy", np.arange(12).reshape(3, 4))
    np.savez(tmp_path / "b.npz", x=np.array([1, 2, 3]), y=np.array([[1.0, 2.0]]))

    out = dispatch_readonly_tool("inspect_numpy_folder", {"path": str(tmp_path)})
    assert "inspect_numpy_folder:" in out
    assert "numpy_file_count:" in out
    assert ".npy=1" in out
    assert ".npz=1" in out
    assert "shape=(3, 4)" in out
    assert "npz arrays=" in out


def test_execute_run_neuralsmith_declined():
    from neuralsmith.copilot.agent_loop import _execute_run_neuralsmith
    from unittest.mock import patch

    with patch("neuralsmith.copilot.agent_loop.subprocess.Popen") as popen_mock:
        out = _execute_run_neuralsmith(
            {
                "subcommand": "tabular-classification",
                "flags": {
                    "data-path": "missing.csv",
                    "target-column": "y",
                },
            },
            require_confirm=True,
            confirm_fn=lambda _argv: False,
        )
    popen_mock.assert_not_called()
    assert "declined" in out.lower()


def test_execute_run_neuralsmith_agent_plus(tmp_path):
    from neuralsmith.copilot.agent_loop import _execute_run_neuralsmith
    from unittest.mock import patch, MagicMock
    import io

    csv_path = tmp_path / "d.csv"
    csv_path.write_text("x,y\n1,0\n")
    proc = MagicMock()
    proc.stdout = io.StringIO("training started\ntraining finished\n")
    proc.wait = MagicMock()
    proc.returncode = 0
    with patch("neuralsmith.copilot.agent_loop.subprocess.Popen", return_value=proc) as popen_mock:
        out = _execute_run_neuralsmith(
            {
                "subcommand": "tabular-classification",
                "flags": {
                    "data-path": str(csv_path.name),
                    "target-column": "y",
                    "no-eda": True,
                },
                "cwd": str(tmp_path),
            },
            require_confirm=False,
            confirm_fn=lambda _argv: False,
        )
    popen_mock.assert_called_once()
    assert "exit_code=0" in out
    assert "stdout_summary:" in out
    assert "training finished" in out
    assert "stderr_summary:" in out


def test_agent_prompt_import():
    from neuralsmith.copilot.agent_prompt import AGENT_SYSTEM_PROMPT

    assert "run_neuralsmith" in AGENT_SYSTEM_PROMPT
    assert "tool-json" in AGENT_SYSTEM_PROMPT
