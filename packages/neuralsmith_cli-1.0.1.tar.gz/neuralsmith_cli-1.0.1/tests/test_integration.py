"""Integration tests for full CLI workflows."""

import pytest
import subprocess
import sys
from pathlib import Path


@pytest.mark.integration
@pytest.mark.slow
def test_full_image_classification_workflow(test_outputs_dir, synthetic_image_dataset):
    """Test complete image classification workflow."""
    data_path = synthetic_image_dataset
    output_dir = test_outputs_dir / "integration_image_clf"
    
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "neuralsmith",
            "image-classification",
            "--data-path",
            str(data_path),
            "--output-dir",
            str(output_dir),
            "--epochs",
            "1",
            "--seed",
            "42",
        ],
        cwd=str(Path(__file__).parent.parent),
        capture_output=True,
        text=True,
        timeout=300,  # 5 minute timeout
    )
    
    assert result.returncode == 0, f"Command failed:\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
    assert output_dir.exists()


@pytest.mark.integration
@pytest.mark.slow
def test_full_tabular_classification_workflow(test_outputs_dir):
    """Test complete tabular classification workflow."""
    data_path = Path(__file__).parent / "data" / "tabular_classification" / "iris_like_100.csv"
    output_dir = test_outputs_dir / "integration_tabular_clf"
    
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "neuralsmith",
            "tabular-classification",
            "--data-path",
            str(data_path),
            "--target-column",
            "species",
            "--output-dir",
            str(output_dir),
            "--mode",
            "fast++",
            "--no-eda",
        ],
        cwd=str(Path(__file__).parent.parent),
        capture_output=True,
        text=True,
        timeout=300,
    )
    
    assert result.returncode == 0, f"Command failed:\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
    assert output_dir.exists()


@pytest.mark.integration
@pytest.mark.slow
def test_full_timeseries_classification_workflow(test_outputs_dir):
    """Test complete time series classification workflow."""
    data_path = Path(__file__).parent / "data" / "timeseries_classification" / "sample_ts_classification.csv"
    output_dir = test_outputs_dir / "integration_timeseries_clf"
    
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "neuralsmith",
            "timeseries-classification",
            "--data-path",
            str(data_path),
            "--time-column",
            "time",
            "--target-column",
            "target",
            "--window-size",
            "10",
            "--output-dir",
            str(output_dir),
            "--mode",
            "fast",
            "--epochs",
            "2",
        ],
        cwd=str(Path(__file__).parent.parent),
        capture_output=True,
        text=True,
        timeout=300,
    )
    
    assert result.returncode == 0, f"Command failed:\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
    assert output_dir.exists()
