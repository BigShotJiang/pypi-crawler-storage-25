"""Tests for configuration management."""

import pytest
import tempfile
import json
from pathlib import Path
from unittest.mock import patch, mock_open

from neuralsmith import config


def test_config_file_creation(tmp_path):
    """Test that config file is created correctly."""
    config_path = tmp_path / "config.json"
    
    config.save_api_key("test_key_123", explicit_path=str(config_path))
    
    assert config_path.exists()
    with open(config_path) as f:
        data = json.load(f)
        assert data["gemini_api_key"] == "test_key_123"


def test_config_file_loading(tmp_path):
    """Test loading config from file."""
    config_path = tmp_path / "config.json"
    config_data = {"gemini_api_key": "test_key_456"}
    
    with open(config_path, "w") as f:
        json.dump(config_data, f)
    
    loaded_config = config.load_config(explicit_path=str(config_path))
    assert loaded_config["gemini_api_key"] == "test_key_456"


def test_get_api_key(tmp_path):
    """Test getting API key from config."""
    config_path = tmp_path / "config.json"
    config_data = {"gemini_api_key": "test_key_789"}
    
    with open(config_path, "w") as f:
        json.dump(config_data, f)
    
    api_key = config.get_api_key(explicit_path=str(config_path))
    assert api_key == "test_key_789"


def test_get_api_key_missing(tmp_path):
    """Test getting API key when config doesn't exist."""
    config_path = tmp_path / "nonexistent_config.json"
    
    api_key = config.get_api_key(explicit_path=str(config_path))
    assert api_key is None


def test_check_api_key(tmp_path):
    """Test checking if API key exists."""
    config_path = tmp_path / "config.json"
    config_data = {"gemini_api_key": "test_key_check"}
    
    with open(config_path, "w") as f:
        json.dump(config_data, f)
    
    has_key = config.check_api_key(explicit_path=str(config_path))
    assert has_key is True
    
    # Test with missing key
    config_data_no_key = {}
    with open(config_path, "w") as f:
        json.dump(config_data_no_key, f)
    
    has_key = config.check_api_key(explicit_path=str(config_path))
    assert has_key is False
