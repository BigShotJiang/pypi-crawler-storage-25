"""Tests for time series classification and regression wizards."""

import pytest
import pandas as pd
import numpy as np


@pytest.fixture
def sample_timeseries_csv(tmp_path):
    """Create a sample time series CSV for testing."""
    # Generate synthetic time series data
    n_samples = 100
    time_steps = np.arange(n_samples)
    feature1 = np.sin(time_steps * 0.1) + np.random.randn(n_samples) * 0.1
    feature2 = np.cos(time_steps * 0.1) + np.random.randn(n_samples) * 0.1
    target = (feature1 > 0).astype(int)  # Binary classification
    
    df = pd.DataFrame({
        "time": time_steps,
        "feature1": feature1,
        "feature2": feature2,
        "target": target,
    })
    
    csv_path = tmp_path / "timeseries_test.csv"
    df.to_csv(csv_path, index=False)
    return csv_path


@pytest.mark.slow
def test_timeseries_classification(sample_timeseries_csv, test_outputs_dir):
    """Test time series classification."""
    from neuralsmith.timeseries.train import train_timeseries_models
    
    result = train_timeseries_models(
        data_path=str(sample_timeseries_csv),
        time_column="time",
        target_column="target",
        window_size=10,
        output_dir=str(test_outputs_dir / "ts_clf_test"),
        task="classification",
        mode="fast",
        epochs=2,  # Minimal epochs for testing
        split_method="temporal",
    )
    
    assert "best_model" in result
    assert "best_model_index" in result
    assert "val_accuracy" in result["best_model"]
    assert "test_accuracy" in result["best_model"]


@pytest.mark.slow
def test_timeseries_regression(sample_timeseries_csv, test_outputs_dir):
    """Test time series regression."""
    from neuralsmith.timeseries.train import train_timeseries_models
    
    # Modify target to be continuous
    df = pd.read_csv(sample_timeseries_csv)
    df["target"] = df["feature1"] + df["feature2"]  # Continuous target
    df.to_csv(sample_timeseries_csv, index=False)
    
    result = train_timeseries_models(
        data_path=str(sample_timeseries_csv),
        time_column="time",
        target_column="target",
        window_size=10,
        output_dir=str(test_outputs_dir / "ts_reg_test"),
        task="regression",
        mode="fast",
        epochs=2,
        split_method="temporal",
    )
    
    assert "best_model" in result
    assert "best_model_index" in result
    assert "val_mse" in result["best_model"]
    assert "test_mse" in result["best_model"]


def test_timeseries_preprocessing(sample_timeseries_csv, test_outputs_dir):
    """Test time series preprocessing."""
    from neuralsmith.timeseries.preprocess import preprocess_timeseries
    
    X_train, y_train, X_val, y_val, X_test, y_test, metadata = preprocess_timeseries(
        data_path=str(sample_timeseries_csv),
        time_column="time",
        target_column="target",
        window_size=10,
        output_dir=str(test_outputs_dir / "ts_preprocess_test"),
        split_method="temporal",
    )
    
    assert len(X_train) > 0
    assert len(y_train) > 0
    assert len(X_test) > 0
    assert len(y_test) > 0
    assert metadata["split_method"] == "temporal"


@pytest.mark.slow
def test_timeseries_mode_model_selection(sample_timeseries_csv, test_outputs_dir):
    """Test mode model selection ordering for time series classification."""
    from neuralsmith.timeseries.train import train_timeseries_models

    mode_to_models = {}
    for mode in ["fast++", "fast", "exhaustive"]:
        result = train_timeseries_models(
            data_path=str(sample_timeseries_csv),
            time_column="time",
            target_column="target",
            window_size=10,
            output_dir=str(test_outputs_dir / f"ts_mode_{mode.replace('+', 'p')}"),
            task="classification",
            mode=mode,
            epochs=1,
            split_method="temporal",
        )
        mode_to_models[mode] = [entry["model"] for entry in result["all_results"]]

    # fast++ is intentionally the fastest mode.
    assert len(mode_to_models["fast++"]) <= len(mode_to_models["fast"]) <= len(mode_to_models["exhaustive"])

    exhaustive_models = mode_to_models["exhaustive"]
    if any(name.startswith("MOMENT-1-") for name in exhaustive_models):
        assert mode_to_models["fast++"] == ["MOMENT-1-small"]
        assert mode_to_models["fast"] == ["MOMENT-1-small", "MOMENT-1-base", "SimpleLSTM"]
        assert "MOMENT-1-small" in exhaustive_models
        assert "MOMENT-1-base" in exhaustive_models
        assert "MOMENT-1-large" in exhaustive_models
        assert "SimpleLSTM" in exhaustive_models
        assert "SimpleCNN1D" in exhaustive_models
        assert "SimpleLSTM-Large" in exhaustive_models
        assert "SimpleCNN1D-Large" in exhaustive_models
    else:
        # Fallback path when momentfm is unavailable.
        assert mode_to_models["fast++"] == ["SimpleLSTM"]


@pytest.mark.slow
def test_timeseries_architectures_match_between_tasks(sample_timeseries_csv, test_outputs_dir):
    """Classification and regression should use the same architecture lineup per mode."""
    from neuralsmith.timeseries.train import train_timeseries_models

    # Classification data
    clf_csv = sample_timeseries_csv

    # Regression data
    reg_csv = test_outputs_dir / "ts_reg_for_arch_check.csv"
    df = pd.read_csv(sample_timeseries_csv)
    df["target"] = df["feature1"] + df["feature2"]
    df.to_csv(reg_csv, index=False)

    for mode in ["fast++", "fast", "exhaustive"]:
        clf_result = train_timeseries_models(
            data_path=str(clf_csv),
            time_column="time",
            target_column="target",
            window_size=10,
            output_dir=str(test_outputs_dir / f"ts_arch_clf_{mode.replace('+', 'p')}"),
            task="classification",
            mode=mode,
            epochs=1,
            split_method="temporal",
        )
        reg_result = train_timeseries_models(
            data_path=str(reg_csv),
            time_column="time",
            target_column="target",
            window_size=10,
            output_dir=str(test_outputs_dir / f"ts_arch_reg_{mode.replace('+', 'p')}"),
            task="regression",
            mode=mode,
            epochs=1,
            split_method="temporal",
        )
        clf_models = [entry["model"] for entry in clf_result["all_results"]]
        reg_models = [entry["model"] for entry in reg_result["all_results"]]
        assert clf_models == reg_models


def test_timeseries_numpy_input_path(tmp_path, test_outputs_dir):
    """Pre-windowed numpy directory should be accepted as input."""
    from neuralsmith.timeseries.preprocess import preprocess_timeseries

    rng = np.random.default_rng(123)
    X = rng.normal(size=(60, 8, 3)).astype(np.float32)
    y = rng.integers(0, 2, size=(60,), endpoint=False).astype(np.int64)
    np.save(tmp_path / "X_train.npy", X[:40])
    np.save(tmp_path / "y_train.npy", y[:40])
    np.save(tmp_path / "X_val.npy", X[40:50])
    np.save(tmp_path / "y_val.npy", y[40:50])
    np.save(tmp_path / "X_test.npy", X[50:])
    np.save(tmp_path / "y_test.npy", y[50:])

    X_train, y_train, X_val, y_val, X_test, y_test, metadata = preprocess_timeseries(
        data_path=str(tmp_path),
        time_column=None,
        target_column="target",
        window_size=None,
        output_dir=str(test_outputs_dir / "ts_numpy_input"),
        task="classification",
    )
    assert X_train.shape == (40, 8, 3)
    assert y_test.shape == (10,)
    assert metadata["source"] == "numpy"


def test_temporal_split_no_overlap(sample_timeseries_csv, test_outputs_dir):
    """Temporal split should keep order and avoid overlap by index."""
    from neuralsmith.timeseries.preprocess import preprocess_timeseries

    X_train, y_train, X_val, y_val, X_test, y_test, _ = preprocess_timeseries(
        data_path=str(sample_timeseries_csv),
        time_column="time",
        target_column="target",
        window_size=10,
        output_dir=str(test_outputs_dir / "ts_temporal_split"),
        split_method="temporal",
        task="classification",
    )
    assert len(X_train) > 0
    assert len(X_test) > 0
    # Last train sample should be earlier window content than first test sample.
    assert np.any(X_train[-1] != X_test[0])
    assert len(y_train) + len(y_val) + len(y_test) == len(X_train) + len(X_val) + len(X_test)


def test_timestamp_duplicates_raise(sample_timeseries_csv, test_outputs_dir):
    """Duplicate time column values should fail preprocessing."""
    from neuralsmith.timeseries.preprocess import preprocess_timeseries

    df = pd.read_csv(sample_timeseries_csv)
    df.loc[1, "time"] = df.loc[0, "time"]
    bad_csv = test_outputs_dir / "ts_bad_time.csv"
    df.to_csv(bad_csv, index=False)

    with pytest.raises(ValueError, match="duplicate"):
        preprocess_timeseries(
            data_path=str(bad_csv),
            time_column="time",
            target_column="target",
            window_size=5,
            output_dir=str(test_outputs_dir / "ts_bad_time_out"),
            split_method="temporal",
            task="classification",
        )
