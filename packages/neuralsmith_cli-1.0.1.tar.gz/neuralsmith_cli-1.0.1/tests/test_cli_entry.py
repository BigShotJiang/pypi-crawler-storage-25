"""Test CLI entry point and argument parsing."""

import subprocess
import sys
from pathlib import Path


def test_cli_help():
    """Test that --help works."""
    result = subprocess.run(
        [sys.executable, "-m", "neuralsmith", "--help"],
        cwd=str(Path(__file__).parent.parent),
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0
    assert "NeuralSmith CLI" in result.stdout
    assert "image-classification" in result.stdout
    assert "tabular-classification" in result.stdout


def test_cli_version():
    """Test that --version works."""
    result = subprocess.run(
        [sys.executable, "-m", "neuralsmith", "--version"],
        cwd=str(Path(__file__).parent.parent),
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0
    assert "neuralsmith" in result.stdout.lower()
