# #!/usr/bin/env python3
# import argparse
# import json
# import os
# import time
# from datetime import datetime
# from typing import Dict

# import torch
# import torch.nn as nn
# from torch.utils.data import DataLoader, TensorDataset
# import torchvision.models as models

# # Reuse data loader from nas_train.py
# from nas_train import load_and_preprocess_data


# def build_baseline(model_name: str, num_classes: int):
#     model_name = model_name.strip()
#     if model_name == 'ResNet50':
#         base_model = models.resnet50(weights='IMAGENET1K_V2' if num_classes >= 2 else None)
#         in_features = base_model.fc.in_features
#         base_model.fc = nn.Linear(in_features, num_classes)
#     elif model_name == 'DenseNet201':
#         base_model = models.densenet201(weights='IMAGENET1K_V1' if num_classes >= 2 else None)
#         in_features = base_model.classifier.in_features
#         base_model.classifier = nn.Linear(in_features, num_classes)
#     elif model_name == 'ConvNeXtTiny':
#         base_model = models.convnext_tiny(weights='IMAGENET1K_V1' if num_classes >= 2 else None)
#         in_features = base_model.classifier[2].in_features
#         base_model.classifier[2] = nn.Linear(in_features, num_classes)
#     elif model_name == 'MobileNetV2':
#         base_model = models.mobilenet_v2(weights='IMAGENET1K_V2' if num_classes >= 2 else None)
#         in_features = base_model.classifier[1].in_features
#         base_model.classifier[1] = nn.Linear(in_features, num_classes)
#     else:
#         raise ValueError(f"Unknown baseline model: {model_name}")
#     return base_model


# def train_baseline(
#     model_name: str,
#     data: Dict,
#     epochs: int = 50,
#     batch_size: int | None = None,
#     learning_rate: float = 1e-3,
#     output_dir: str = 'nas_search_results',
#     early_stopping_patience: int = 7,
#     reduce_lr_patience: int = 5,
#     device: str | None = None
# ) -> Dict:
#     if device is None:
#         device = 'cuda' if torch.cuda.is_available() else 'cpu'

#     model = build_baseline(model_name, data['num_classes']).to(device)

#     total_params = sum(p.numel() for p in model.parameters())

#     if batch_size is None:
#         # simple heuristic
#         batch_size = min(32, max(4, int(12800000 / max(1, total_params)) * 4))

#     train_loader = DataLoader(TensorDataset(data['X_train'], data['y_train']), batch_size=batch_size, shuffle=True, num_workers=0)
#     val_loader = DataLoader(TensorDataset(data['X_val'], data['y_val']), batch_size=batch_size, shuffle=False, num_workers=0)
#     test_loader = DataLoader(TensorDataset(data['X_test'], data['y_test']), batch_size=batch_size, shuffle=False, num_workers=0)

#     optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
#     criterion = nn.CrossEntropyLoss()
#     scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=reduce_lr_patience, min_lr=1e-7)

#     best_val_acc = 0.0
#     patience_counter = 0
#     best_state = None
#     start_time = time.time()
#     epoch_metrics = []

#     for epoch in range(epochs):
#         model.train()
#         train_loss = 0.0
#         train_correct = 0
#         train_total = 0
#         for batch_idx, (inputs, targets) in enumerate(train_loader):
#             inputs, targets = inputs.to(device), targets.to(device)
#             optimizer.zero_grad()
#             outputs = model(inputs)
#             loss = criterion(outputs, targets)
#             loss.backward()
#             optimizer.step()
#             train_loss += loss.item()
#             _, pred = outputs.max(1)
#             train_total += targets.size(0)
#             train_correct += pred.eq(targets).sum().item()
#             try:
#                 print("BATCH_JSON:" + json.dumps({
#                     'epoch': epoch + 1,
#                     'batch': batch_idx + 1,
#                     'total_batches': len(train_loader),
#                     'batch_loss': float(loss.item()),
#                     'running_accuracy': float(train_correct) / float(train_total) if train_total > 0 else 0.0
#                 }), flush=True)
#             except Exception:
#                 pass

#         train_loss /= max(1, len(train_loader))
#         train_acc = train_correct / max(1, train_total)

#         # validate
#         model.eval()
#         val_loss = 0.0
#         val_correct = 0
#         val_total = 0
#         with torch.no_grad():
#             for inputs, targets in val_loader:
#                 inputs, targets = inputs.to(device), targets.to(device)
#                 outputs = model(inputs)
#                 loss = criterion(outputs, targets)
#                 val_loss += loss.item()
#                 _, pred = outputs.max(1)
#                 val_total += targets.size(0)
#                 val_correct += pred.eq(targets).sum().item()
#         val_loss /= max(1, len(val_loader))
#         val_acc = val_correct / max(1, val_total)

#         metrics = {
#             'epoch': epoch + 1,
#             'train_loss': float(train_loss),
#             'train_accuracy': float(train_acc),
#             'val_loss': float(val_loss),
#             'val_accuracy': float(val_acc),
#             'learning_rate': optimizer.param_groups[0]['lr'],
#             'epoch_time': f"{int(time.time()-start_time)}s"
#         }
#         epoch_metrics.append(metrics)
#         try:
#             print("EPOCH_JSON:" + json.dumps(metrics), flush=True)
#         except Exception:
#             pass

#         scheduler.step(val_loss)
#         if val_acc > best_val_acc:
#             best_val_acc = val_acc
#             patience_counter = 0
#             best_state = model.state_dict()
#         else:
#             patience_counter += 1
#         if patience_counter >= early_stopping_patience:
#             try:
#                 print("EARLY_STOP_JSON:" + json.dumps({'epoch': int(epoch + 1)}), flush=True)
#             except Exception:
#                 pass
#             if best_state is not None:
#                 model.load_state_dict(best_state)
#             break

#     # evaluate
#     model.eval()
#     test_correct = 0
#     test_total = 0
#     test_loss = 0.0
#     with torch.no_grad():
#         for inputs, targets in test_loader:
#             inputs, targets = inputs.to(device), targets.to(device)
#             outputs = model(inputs)
#             loss = criterion(outputs, targets)
#             test_loss += loss.item()
#             _, pred = outputs.max(1)
#             test_total += targets.size(0)
#             test_correct += pred.eq(targets).sum().item()
#     test_loss /= max(1, len(test_loader))
#     test_acc = test_correct / max(1, test_total)

#     training_time = time.time() - start_time

#     os.makedirs(output_dir, exist_ok=True)
#     model_file = os.path.join(output_dir, f'baseline_{model_name}.pth')
#     torch.save({
#         'model_state_dict': model.state_dict(),
#         'architecture': model_name,
#         'num_classes': data['num_classes'],
#         'total_params': total_params
#     }, model_file)
#     print(f"Model saved to: {model_file}")

#     results = {
#         'model_type': 'baseline',
#         'architecture': model_name,
#         'test_accuracy': float(test_acc),
#         'test_loss': float(test_loss),
#         'max_val_accuracy': float(best_val_acc),
#         'total_params': int(total_params),
#         'epochs_trained': len(epoch_metrics),
#         'training_time_seconds': float(training_time),
#         'epoch_metrics': epoch_metrics,
#         'timestamp': datetime.now().isoformat(),
#         'model_file': model_file,
#         'num_classes': int(data['num_classes']),
#         'image_size': [int(data['X_train'].shape[2]), int(data['X_train'].shape[3])]
#     }
#     try:
#         print("RESULT_JSON:" + json.dumps(results), flush=True)
#     except Exception:
#         pass
#     return results


# def main():
#     p = argparse.ArgumentParser(description='Train a single baseline model')
#     p.add_argument('--x_train', required=True)
#     p.add_argument('--y_train', required=True)
#     p.add_argument('--x_test', required=True)
#     p.add_argument('--y_test', required=True)
#     p.add_argument('--model_name', required=True, choices=['ResNet50','DenseNet201','ConvNeXtTiny','MobileNetV2'])
#     p.add_argument('--epochs', type=int, default=50)
#     p.add_argument('--batch_size', type=int, default=None)
#     p.add_argument('--lr', type=float, default=1e-3)
#     p.add_argument('--val_split', type=float, default=0.1)
#     p.add_argument('--target_size', type=str, default='32,32')
#     p.add_argument('--output_dir', type=str, default='nas_search_results')
#     p.add_argument('--dataset_name', type=str, default=None)
#     p.add_argument('--early_stopping_patience', type=int, default=7)
#     p.add_argument('--reduce_lr_patience', type=int, default=5)
#     p.add_argument('--device', type=str, default=None, choices=['cuda','cpu'])
#     args = p.parse_args()

#     # parse target size
#     try:
#         H, W = [int(x.strip()) for x in args.target_size.split(',')]
#         target_size = (H, W)
#     except:
#         target_size = (32, 32)

#     # output dir
#     if args.dataset_name:
#         output_dir = os.path.join(args.output_dir, args.dataset_name)
#     else:
#         output_dir = args.output_dir

#     data = load_and_preprocess_data(
#         x_train_path=args.x_train,
#         y_train_path=args.y_train,
#         x_test_path=args.x_test,
#         y_test_path=args.y_test,
#         target_size=target_size,
#         val_split=args.val_split
#     )

#     train_baseline(
#         model_name=args.model_name,
#         data=data,
#         epochs=args.epochs,
#         batch_size=args.batch_size,
#         learning_rate=args.lr,
#         output_dir=output_dir,
#         early_stopping_patience=args.early_stopping_patience,
#         reduce_lr_patience=args.reduce_lr_patience,
#         device=args.device
#     )

# if __name__ == '__main__':
#     main()


import argparse
import json
import os
import sys
import time
from datetime import datetime
from typing import Dict

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

# Conditional import for torchvision
try:
    import torchvision.models as models
    TORCHVISION_AVAILABLE = True
except (ImportError, RuntimeError) as e:
    TORCHVISION_AVAILABLE = False
    print(f"Error: torchvision not available ({e})")
    print("Please reinstall compatible PyTorch/torchvision versions:")
    print("  pip uninstall torch torchvision torchaudio")
    print("  pip install torch torchvision torchaudio")
    models = None
    import sys
    sys.exit(1)

# Reuse data loader from nas_train.py
from nas_train import load_and_preprocess_data


def build_baseline(model_name: str, num_classes: int):
    model_name = model_name.strip()
    if model_name == 'ResNet50':
        base_model = models.resnet50(weights='IMAGENET1K_V2' if num_classes >= 2 else None)
        in_features = base_model.fc.in_features
        base_model.fc = nn.Linear(in_features, num_classes)
    elif model_name == 'DenseNet201':
        base_model = models.densenet201(weights='IMAGENET1K_V1' if num_classes >= 2 else None)
        in_features = base_model.classifier.in_features
        base_model.classifier = nn.Linear(in_features, num_classes)
    elif model_name == 'ConvNeXtTiny':
        base_model = models.convnext_tiny(weights='IMAGENET1K_V1' if num_classes >= 2 else None)
        in_features = base_model.classifier[2].in_features
        base_model.classifier[2] = nn.Linear(in_features, num_classes)
    elif model_name == 'MobileNetV2':
        base_model = models.mobilenet_v2(weights='IMAGENET1K_V2' if num_classes >= 2 else None)
        in_features = base_model.classifier[1].in_features
        base_model.classifier[1] = nn.Linear(in_features, num_classes)
    else:
        raise ValueError(f"Unknown baseline model: {model_name}")
    return base_model


def safe_normalize_path(path):
    """Safely normalize file paths, handling various input types."""
    if path is None:
        return None
    if isinstance(path, (list, tuple, dict)):
        # Return as-is for non-path types
        return path
    if not isinstance(path, str):
        path = str(path)
    if not path.strip():
        return None
    # Only process string paths
    return os.path.abspath(os.path.expanduser(path.replace("\\", os.sep)))


def get_optimal_batch_size(dataset_size: int, total_params: int, device: str) -> int:
    """
    Calculate optimal batch size based on dataset size and model complexity.
    Ensures batch size >= 2 for batch normalization.
    """
    if dataset_size <= 10:
        # Very small dataset - use all data but ensure batch >= 2
        return max(2, min(4, dataset_size))
    
    # Heuristic based on model size and dataset
    base_batch = max(2, min(32, int(12800000 / max(1, total_params)) * 4))
    
    # Adjust based on dataset size
    if dataset_size < 100:
        batch_size = max(2, min(base_batch, dataset_size // 2))
    elif dataset_size < 1000:
        batch_size = max(2, min(base_batch, dataset_size // 4))
    else:
        batch_size = base_batch
    
    # Ensure batch size is not too large for the dataset
    return max(2, min(batch_size, dataset_size // 2))


def detect_device(device: str | None = None) -> str:
    """Detect the best available device, with improved Linux GPU detection."""
    # If explicitly set, use it
    if device is not None:
        if device == 'cuda' and not torch.cuda.is_available():
            print(f"Warning: CUDA requested but not available. Falling back to CPU.", file=sys.stderr)
            return 'cpu'
        return device
    
    # Try to detect CUDA availability with multiple methods
    try:
        # Method 1: Standard PyTorch check
        if torch.cuda.is_available():
            # Verify we can actually create a tensor on GPU
            try:
                test_tensor = torch.zeros(1).cuda()
                del test_tensor
                torch.cuda.empty_cache()
                return 'cuda'
            except Exception:
                pass
        
        # Method 2: Check for CUDA devices directly (Linux-specific)
        if hasattr(torch.cuda, 'device_count') and torch.cuda.device_count() > 0:
            try:
                # Try to get device name to verify it's accessible
                device_name = torch.cuda.get_device_name(0)
                if device_name:
                    return 'cuda'
            except Exception:
                pass
        
        # Method 3: Check environment variables (Linux often sets these)
        if os.environ.get('CUDA_VISIBLE_DEVICES') is not None:
            # If CUDA_VISIBLE_DEVICES is set, try to use CUDA
            try:
                if torch.cuda.is_available() and torch.cuda.device_count() > 0:
                    return 'cuda'
            except Exception:
                pass
    except Exception:
        pass
    
    # Fallback to CPU
    return 'cpu'


def train_baseline(
    model_name: str,
    data: Dict,
    epochs: int = 50,
    batch_size: int | None = None,
    learning_rate: float = 1e-3,
    output_dir: str = 'nas_search_results',
    early_stopping_patience: int = 7,
    reduce_lr_patience: int = 5,
    device: str | None = None,
    normalize: bool = True
) -> Dict:
    """Train a baseline model with proper batch handling."""
    
    # Setup device with improved detection
    device = detect_device(device)
    
    print(f"Training on device: {device}", file=sys.stderr)
    print(f"Dataset sizes - Train: {len(data['X_train'])}, Val: {len(data['X_val'])}, Test: {len(data['X_test'])}", file=sys.stderr)
    
    # Build model
    model = build_baseline(model_name, data['num_classes']).to(device)

    total_params = sum(p.numel() for p in model.parameters())
    
    # Determine batch size
    train_size = len(data['X_train'])
    if batch_size is None:
        batch_size = get_optimal_batch_size(train_size, total_params, device)
    
    # Ensure batch_size >= 2 for batch normalization
    if batch_size < 2:
        print(f"Warning: batch_size {batch_size} < 2. Setting to minimum 2.", file=sys.stderr)
        batch_size = 2
    
    # Ensure batch_size doesn't exceed dataset size
    if batch_size > train_size:
        print(f"Warning: batch_size {batch_size} > train_size {train_size}. Reducing to {train_size}.", file=sys.stderr)
        batch_size = max(2, train_size)
    
    print(f"Using batch_size: {batch_size}", file=sys.stderr)
    
    # Create data loaders with drop_last=True to avoid batches of size 1
    train_loader = DataLoader(
        TensorDataset(data['X_train'], data['y_train']),
        batch_size=batch_size,
        shuffle=True,
        num_workers=0,
        drop_last=True  # This ensures all batches have exactly batch_size samples
    )
    
    # For validation/test, we don't need drop_last since we're not training
    val_loader = DataLoader(
        TensorDataset(data['X_val'], data['y_val']),
        batch_size=batch_size,
        shuffle=False,
        num_workers=0
    )
    
    test_loader = DataLoader(
        TensorDataset(data['X_test'], data['y_test']),
        batch_size=batch_size,
        shuffle=False,
        num_workers=0
    )
    
    # Check if any batches would be of size 1
    if train_size % batch_size == 1:
        print(f"Warning: Last batch would be size 1. Consider adjusting batch_size from {batch_size}.", file=sys.stderr)
    
    # Training setup
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss()
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, 
        patience=reduce_lr_patience, min_lr=1e-7
    )
    
    best_val_acc = 0.0
    patience_counter = 0
    best_state = None
    start_time = time.time()
    epoch_metrics = []
    
    # Training loop
    for epoch in range(epochs):
        model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0
        
        for batch_idx, (inputs, targets) in enumerate(train_loader):
            inputs, targets = inputs.to(device), targets.to(device)
            
            # Debug: Print batch size
            if batch_idx == 0:
                print(f"Epoch {epoch+1}, Batch 0 size: {inputs.size()}", file=sys.stderr)
            
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
            _, pred = outputs.max(1)
            train_total += targets.size(0)
            train_correct += pred.eq(targets).sum().item()
            
            try:
                print("BATCH_JSON:" + json.dumps({
                    'epoch': epoch + 1,
                    'batch': batch_idx + 1,
                    'total_batches': len(train_loader),
                    'batch_loss': float(loss.item()),
                    'running_accuracy': float(train_correct) / float(train_total) if train_total > 0 else 0.0,
                    'batch_size': int(targets.size(0))
                }), flush=True)
            except Exception:
                pass
        
        train_loss /= max(1, len(train_loader))
        train_acc = train_correct / max(1, train_total)
        
        # Validation
        model.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0
        
        with torch.no_grad():
            for inputs, targets in val_loader:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                val_loss += loss.item()
                _, pred = outputs.max(1)
                val_total += targets.size(0)
                val_correct += pred.eq(targets).sum().item()
        
        val_loss /= max(1, len(val_loader))
        val_acc = val_correct / max(1, val_total)
        
        metrics = {
            'epoch': epoch + 1,
            'train_loss': float(train_loss),
            'train_accuracy': float(train_acc),
            'val_loss': float(val_loss),
            'val_accuracy': float(val_acc),
            'learning_rate': optimizer.param_groups[0]['lr'],
            'epoch_time': f"{int(time.time()-start_time)}s"
        }
        epoch_metrics.append(metrics)
        
        try:
            print("EPOCH_JSON:" + json.dumps(metrics), flush=True)
        except Exception:
            pass
        
        scheduler.step(val_loss)
        
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            patience_counter = 0
            best_state = model.state_dict().copy()
        else:
            patience_counter += 1
        
        if patience_counter >= early_stopping_patience:
            try:
                print("EARLY_STOP_JSON:" + json.dumps({'epoch': int(epoch + 1)}), flush=True)
            except Exception:
                pass
            
            if best_state is not None:
                model.load_state_dict(best_state)
            break
    
    # Final evaluation
    model.eval()
    test_correct = 0
    test_total = 0
    test_loss = 0.0
    
    with torch.no_grad():
        for inputs, targets in test_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            test_loss += loss.item()
            _, pred = outputs.max(1)
            test_total += targets.size(0)
            test_correct += pred.eq(targets).sum().item()
    
    test_loss /= max(1, len(test_loader))
    test_acc = test_correct / max(1, test_total)

    training_time = time.time() - start_time
    
    # Save model
    os.makedirs(output_dir, exist_ok=True)
    model_file = os.path.join(output_dir, f'baseline_{model_name}.pth')
    
    torch.save({
        'model_state_dict': model.state_dict(),
        'architecture': model_name,
        'num_classes': data['num_classes'],
        'total_params': total_params,
        'best_val_accuracy': float(best_val_acc),
        'input_channels': int(data['X_train'].shape[1]),
        'image_size': [int(data['X_train'].shape[2]), int(data['X_train'].shape[3])],
        'normalize': normalize,
        'training_config': {
            'batch_size': batch_size,
            'learning_rate': learning_rate,
            'epochs_trained': len(epoch_metrics)
        }
    }, model_file)
    
    print(f"Model saved to: {model_file}", file=sys.stderr)
    
    results = {
        'model_type': 'baseline',
        'architecture': model_name,
        'test_accuracy': float(test_acc),
        'test_loss': float(test_loss),
        'max_val_accuracy': float(best_val_acc),
        'total_params': int(total_params),
        'epochs_trained': len(epoch_metrics),
        'training_time_seconds': float(training_time),
        'epoch_metrics': epoch_metrics,
        'timestamp': datetime.now().isoformat(),
        'model_file': model_file,
        'num_classes': int(data['num_classes']),
        'image_size': [int(data['X_train'].shape[2]), int(data['X_train'].shape[3])],
        'batch_size_used': batch_size,
        'dataset_sizes': {
            'train': int(train_size),
            'val': int(len(data['X_val'])),
            'test': int(len(data['X_test']))
        }
    }
    
    try:
        print("RESULT_JSON:" + json.dumps(results), flush=True)
    except Exception:
        pass
    
    return results


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description='Train a single baseline model')
    parser.add_argument('--x_train', required=True, help='Path to training features')
    parser.add_argument('--y_train', required=True, help='Path to training labels')
    parser.add_argument('--x_test', required=True, help='Path to test features')
    parser.add_argument('--y_test', required=True, help='Path to test labels')
    parser.add_argument('--model_name', required=True, 
                       choices=['ResNet50', 'DenseNet201', 'ConvNeXtTiny', 'MobileNetV2'],
                       help='Model architecture')
    parser.add_argument('--epochs', type=int, default=50, help='Number of epochs')
    parser.add_argument('--batch_size', type=int, default=None, 
                       help='Batch size (auto-calculated if None)')
    parser.add_argument('--lr', type=float, default=1e-3, help='Learning rate')
    parser.add_argument('--val_split', type=float, default=0.1, 
                       help='Validation split ratio')
    parser.add_argument('--target_size', type=str, default='32,32',
                       help='Target image size as H,W')
    parser.add_argument('--output_dir', type=str, default='nas_search_results',
                       help='Output directory')
    parser.add_argument('--dataset_name', type=str, default=None,
                       help='Dataset name for subdirectory')
    parser.add_argument('--early_stopping_patience', type=int, default=7,
                       help='Early stopping patience')
    parser.add_argument('--reduce_lr_patience', type=int, default=5,
                       help='Reduce LR patience')
    parser.add_argument('--device', type=str, default=None, 
                       choices=['cuda', 'cpu'], help='Device to use')
    parser.add_argument('--normalize', type=int, default=1, choices=[0, 1],
                        help='Whether to normalize images (1=enabled/default, 0=disabled)')
    
    args = parser.parse_args()
    
    # Parse target size
    try:
        H, W = [int(x.strip()) for x in args.target_size.split(',')]
        target_size = (H, W)
    except Exception as e:
        print(f"Error parsing target_size: {e}. Using default (32, 32)", file=sys.stderr)
        target_size = (32, 32)
    
    # Create output directory
    if args.dataset_name:
        output_dir = os.path.join(args.output_dir, args.dataset_name)
    else:
        output_dir = args.output_dir
    
    # Parse normalize flag
    normalize = bool(args.normalize)
    print(f"Normalization: {'enabled' if normalize else 'disabled'}", file=sys.stderr)
    
    # Load data
    print(f"Loading data with target_size: {target_size}", file=sys.stderr)
    data = load_and_preprocess_data(
        x_train_path=safe_normalize_path(args.x_train),
        y_train_path=safe_normalize_path(args.y_train),
        x_test_path=safe_normalize_path(args.x_test),
        y_test_path=safe_normalize_path(args.y_test),
        target_size=target_size,
        val_split=args.val_split,
        normalize=normalize
    )
    
    print(f"Data loaded successfully. Train shape: {data['X_train'].shape}, "
          f"Num classes: {data['num_classes']}", file=sys.stderr)
    
    # Train model
    results = train_baseline(
        model_name=args.model_name,
        data=data,
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        output_dir=output_dir,
        early_stopping_patience=args.early_stopping_patience,
        reduce_lr_patience=args.reduce_lr_patience,
        device=args.device,
        normalize=normalize
    )
    
    print(f"Training completed. Test accuracy: {results['test_accuracy']:.4f}", file=sys.stderr)
    return results


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\nTraining interrupted by user.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)






