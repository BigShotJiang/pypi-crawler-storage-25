#!/usr/bin/env python3
"""
Weighted Random Architecture Sampler
Uses NAS-Bench-201 benchmark data to generate better random architectures
"""

import json
import os
import random
import numpy as np
from typing import List, Dict, Tuple
from pathlib import Path


STRUCT_DICT = ['none', 'skip_connect', 'nor_conv_1x1', 'nor_conv_3x3', 'avg_pool_3x3']


def parse_search_id(search_id: str) -> List[int]:
    """Parse NAS-Bench-201 search ID to get operation list"""
    # Format: |op0~0|+|op1~0|op2~1|+|op3~0|op4~1|op5~2|
    ops = []
    for op_name in STRUCT_DICT:
        ops.append(search_id.count(op_name))
    
    # Extract actual operations in order
    parts = search_id.split('|')
    operations = []
    for part in parts:
        if '~' in part:
            op_name = part.split('~')[0]
            if op_name in STRUCT_DICT:
                operations.append(STRUCT_DICT.index(op_name))
    
    return operations[:6] if len(operations) >= 6 else None


def load_benchmark_data(benchmark_dir: str = None) -> Dict:
    """Load all NAS-Bench-201 benchmark files"""
    if benchmark_dir is None:
        # Try to find benchmark directory
        current_dir = Path(__file__).parent
        benchmark_dir = current_dir.parent / 'benchmark'
        if not benchmark_dir.exists():
            print(f"Warning: Benchmark directory not found at {benchmark_dir}")
            return {}
    
    benchmark_files = [
        'nasbench201_cifar10.json',
        'nasbench201_cifar100.json',
        'nasbench201_imagenet.json'
    ]
    
    all_data = {}
    
    for filename in benchmark_files:
        filepath = Path(benchmark_dir) / filename
        if filepath.exists():
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                    all_data[filename] = data
                    print(f"Loaded {len(data)} architectures from {filename}")
            except Exception as e:
                print(f"Warning: Could not load {filename}: {e}")
    
    return all_data


def analyze_top_architectures(benchmark_data: Dict, top_k: int = 1000) -> Dict:
    """Analyze top-performing architectures to find patterns"""
    
    all_archs = []
    
    # Collect all architectures with their performance
    for dataset, data in benchmark_data.items():
        for search_id, metrics in data.items():
            arch = parse_search_id(search_id)
            if arch and len(arch) == 6:
                all_archs.append({
                    'arch': arch,
                    'acc': float(metrics.get('test_acc_200', 0)),
                    'rank': int(metrics.get('rank', 99999)),
                    'dataset': dataset
                })
    
    # Sort by rank (lower is better)
    all_archs.sort(key=lambda x: x['rank'])
    top_archs = all_archs[:top_k]
    
    # Analyze operation frequencies
    op_counts = {i: [0] * 6 for i in range(5)}  # op_id -> [count at pos0, pos1, ...]
    
    for arch_data in top_archs:
        arch = arch_data['arch']
        for pos, op in enumerate(arch):
            op_counts[op][pos] += 1
    
    # Convert to probabilities
    op_probs = {}
    for op_id in range(5):
        op_probs[op_id] = {}
        for pos in range(6):
            total = sum(op_counts[i][pos] for i in range(5))
            op_probs[op_id][pos] = op_counts[op_id][pos] / total if total > 0 else 0.2
    
    return {
        'op_probabilities': op_probs,
        'top_architectures': top_archs[:100],  # Store top 100
        'analysis': {
            'total_analyzed': len(all_archs),
            'top_k_used': len(top_archs)
        }
    }


def generate_weighted_random_architecture(analysis: Dict) -> List[int]:
    """
    Generate architecture using weighted random sampling
    based on what works well in NAS-Bench-201
    """
    if not analysis or 'op_probabilities' not in analysis:
        # Fallback to uniform random
        return [random.randint(0, 4) for _ in range(6)]
    
    op_probs = analysis['op_probabilities']
    architecture = []
    
    for pos in range(6):
        # Get probabilities for this position
        probs = [op_probs[op_id][pos] for op_id in range(5)]
        
        # Add some smoothing to avoid zero probabilities
        probs = [p + 0.05 for p in probs]
        probs = [p / sum(probs) for p in probs]  # Normalize
        
        # Sample operation based on probabilities
        op = np.random.choice(5, p=probs)
        architecture.append(int(op))
    
    return architecture


def print_operation_statistics(analysis: Dict):
    """Print operation statistics from benchmark analysis"""
    if not analysis or 'op_probabilities' not in analysis:
        return
    
    print("\n" + "="*80)
    print("OPERATION STATISTICS FROM NAS-BENCH-201 TOP ARCHITECTURES")
    print("="*80)
    
    op_probs = analysis['op_probabilities']
    
    print(f"\nAnalyzed: {analysis['analysis']['total_analyzed']} total architectures")
    print(f"Top performers used: {analysis['analysis']['top_k_used']}")
    
    print("\nOperation Preferences by Position:")
    print("-"*80)
    print(f"{'Position':<12} {'none':<10} {'skip':<10} {'conv1x1':<10} {'conv3x3':<10} {'avgpool':<10}")
    print("-"*80)
    
    for pos in range(6):
        probs = [op_probs[op][pos] for op in range(5)]
        print(f"Position {pos}   {probs[0]:>8.1%}  {probs[1]:>8.1%}  {probs[2]:>8.1%}  {probs[3]:>8.1%}  {probs[4]:>8.1%}")
    
    print("-"*80)
    
    # Overall preferences
    overall_probs = [sum(op_probs[op][pos] for pos in range(6)) / 6 for op in range(5)]
    print(f"\nOverall:     {overall_probs[0]:>8.1%}  {overall_probs[1]:>8.1%}  {overall_probs[2]:>8.1%}  {overall_probs[3]:>8.1%}  {overall_probs[4]:>8.1%}")
    print("="*80 + "\n")


if __name__ == '__main__':
    # Test the weighted sampler
    print("Loading NAS-Bench-201 benchmarks...")
    benchmark_data = load_benchmark_data()
    
    if benchmark_data:
        print("\nAnalyzing top architectures...")
        analysis = analyze_top_architectures(benchmark_data, top_k=1000)
        
        print_operation_statistics(analysis)
        
        print("Generating 5 weighted random architectures:")
        for i in range(5):
            arch = generate_weighted_random_architecture(analysis)
            print(f"  {i+1}. {arch} - Ops: {[STRUCT_DICT[op] for op in arch]}")
    else:
        print("No benchmark data found - using uniform random")
        print("\nGenerating 5 uniform random architectures:")
        for i in range(5):
            arch = [random.randint(0, 4) for _ in range(6)]
            print(f"  {i+1}. {arch}")

