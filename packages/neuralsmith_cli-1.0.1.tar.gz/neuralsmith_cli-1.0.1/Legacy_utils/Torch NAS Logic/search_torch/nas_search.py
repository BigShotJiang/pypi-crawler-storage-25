#!/usr/bin/env python3
"""
Automated NAS Search with Gemini (PyTorch Version)
Uses Google Gemini AI to intelligently search the NAS-Bench-201 architecture space.

Usage:
    python nas_search.py --x_train data/X_train.npy --y_train data/y_train.npy \\
                         --x_test data/X_test.npy --y_test data/y_test.npy \\
                         --api_key YOUR_GEMINI_API_KEY \\
                         --iterations 10
"""

import argparse
import json
import os
import sys
import random
from datetime import datetime
from typing import List, Dict
import re
import numpy as np
from sklearn.metrics import f1_score, precision_score, recall_score

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

# Conditional import for torchvision (only needed for baseline models)
try:
import torchvision.models as models
    TORCHVISION_AVAILABLE = True
except (ImportError, RuntimeError) as e:
    TORCHVISION_AVAILABLE = False
    print(f"Warning: torchvision not available ({e}). Baseline models will be disabled.")
    models = None

# Import our training function
from nas_train import train_nas_model, load_and_preprocess_data, parse_architecture, detect_optimal_batch_size

# Import weighted sampler
try:
    from weighted_sampler import load_benchmark_data, analyze_top_architectures, generate_weighted_random_architecture, print_operation_statistics
    WEIGHTED_SAMPLING_AVAILABLE = True
except ImportError:
    WEIGHTED_SAMPLING_AVAILABLE = False
    print("Warning: weighted_sampler not available, using uniform random")

# Gemini API
try:
    import google.generativeai as genai
except ImportError:
    print("Error: google-generativeai package not installed")
    print("Install with: pip install google-generativeai")
    sys.exit(1)


STRUCT_DICT = ['none', 'skip_connect', 'nor_conv_1x1', 'nor_conv_3x3', 'avg_pool_3x3']


def generate_random_architecture(benchmark_analysis: Dict = None) -> List[int]:
    """
    Generate a random architecture
    Uses weighted sampling based on benchmark data if available
    """
    if benchmark_analysis and WEIGHTED_SAMPLING_AVAILABLE:
        return generate_weighted_random_architecture(benchmark_analysis)
    else:
        # Uniform random fallback
        return [random.randint(0, 4) for _ in range(6)]


def format_experiments_prompt(architectures: List[List[int]], accuracies: List[float]) -> str:
    """Format previous experiments for Gemini prompt"""
    prompt = "Previous architectures and test accuracies:\n\n"
    for i, (arch, acc) in enumerate(zip(architectures, accuracies), 1):
        ops_str = ', '.join([STRUCT_DICT[op] for op in arch])
        prompt += f"{i}. {arch} ({ops_str}) → {acc*100:.2f}%\n"
    return prompt


def create_gemini_prompt(architectures: List[List[int]], accuracies: List[float]) -> str:
    """Create Gemini prompt for architecture generation"""
    
    # Show top performing architectures
    if len(architectures) >= 3:
        top_indices = sorted(range(len(accuracies)), key=lambda i: accuracies[i], reverse=True)[:3]
        results_str = "\n".join([f"Architecture {architectures[i]} achieved {accuracies[i]*100:.1f}% accuracy" 
                                for i in top_indices])
    else:
        results_str = "\n".join([f"Architecture {arch} achieved {acc*100:.1f}% accuracy" 
                                for arch, acc in zip(architectures, accuracies)])
    
    # Detailed prompt with operation explanations
    prompt = f"""Task: Generate a neural network cell configuration.

A cell is defined by 6 operations. Each operation is an integer from 0 to 4:
- Operation 0: Skip (pass through zeros)
- Operation 1: Identity (direct connection)
- Operation 2: Small convolution (1x1 filter)
- Operation 3: Large convolution (3x3 filter)
- Operation 4: Average pooling (downsampling)

Cell structure with operations [op0, op1, op2, op3, op4, op5]:
- Stage 1 output = op0(input)
- Stage 2 output = op1(input) + op2(stage1)
- Stage 3 output = op3(input) + op4(stage1) + op5(stage2)

Previous results:
{results_str}

Design tips:
- Identity connections (1) help information flow
- Convolutions (2,3) extract features
- Later operations have more impact on output
- Mix different operations for better performance

Generate one new configuration as a list of 6 integers (0-4).
Output only the list in this format: [a,b,c,d,e,f]

New configuration:"""
    
    return prompt


def extract_architecture(response_text: str) -> List[int] | None:
    """Extract architecture list from Gemini response"""
    pattern = r'\[(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\]'
    match = re.search(pattern, response_text)
    
    if match:
        arch = [int(match.group(i)) for i in range(1, 7)]
        if all(0 <= op <= 4 for op in arch):
            return arch
    return None


def generate_architecture_with_gemini(
    model: genai.GenerativeModel,
    architectures: List[List[int]],
    accuracies: List[float]
) -> List[int] | None:
    """Use Gemini to generate a new architecture"""
    try:
        prompt = create_gemini_prompt(architectures, accuracies)
        
        # Debug: Print prompt
        print(f"  DEBUG: Prompt: {prompt}")
        
        # Try with minimal configuration
        response = model.generate_content(prompt)
        
        # Debug: Check response
        print(f"  DEBUG: Got response from Gemini")
        if response.candidates:
            print(f"  DEBUG: finish_reason = {response.candidates[0].finish_reason}")
        else:
            print(f"  DEBUG: No candidates in response!")
        
        # Try to get text with better error handling
        try:
            if hasattr(response, 'text'):
                response_text = response.text
                print(f"  DEBUG: Got text via response.text")
            elif hasattr(response, 'parts') and response.parts:
                response_text = response.parts[0].text
                print(f"  DEBUG: Got text via response.parts")
            elif response.candidates and response.candidates[0].content.parts:
                response_text = response.candidates[0].content.parts[0].text
                print(f"  DEBUG: Got text via candidates")
            else:
                print(f"  WARNING: No text in response (likely blocked)")
                return None
            
            print(f"  DEBUG: Response text: {response_text}")
            
        except (ValueError, AttributeError, IndexError) as e:
            print(f"  WARNING: Cannot access response text: {e}")
            return None
        
        # Extract and validate architecture
        architecture = extract_architecture(response_text)
        
        if architecture:
            print(f"  DEBUG: Extracted architecture: {architecture}")
            if architecture not in architectures:
                print(f"  DEBUG: Architecture is unique - SUCCESS!")
                return architecture
            else:
                print(f"  WARNING: Duplicate architecture: {architecture}")
                return None
        else:
            print(f"  WARNING: Cannot parse architecture from: {response_text[:80]}...")
            return None
            
    except Exception as e:
        print(f"  API Error: {str(e)[:100]}")
        return None


def calculate_detailed_metrics(model: nn.Module, loader: DataLoader, device: str) -> Dict:
    """Calculate comprehensive evaluation metrics"""
    model.eval()
    all_preds = []
    all_targets = []
    
    with torch.no_grad():
        for inputs, targets in loader:
            inputs = inputs.to(device)
            outputs = model(inputs)
            _, predicted = outputs.max(1)
            all_preds.extend(predicted.cpu().numpy())
            all_targets.extend(targets.numpy())
    
    all_preds = np.array(all_preds)
    all_targets = np.array(all_targets)
    
    return {
        'accuracy': float(np.mean(all_preds == all_targets)),
        'f1_score_macro': float(f1_score(all_targets, all_preds, average='macro', zero_division=0)),
        'f1_score_weighted': float(f1_score(all_targets, all_preds, average='weighted', zero_division=0)),
        'precision_macro': float(precision_score(all_targets, all_preds, average='macro', zero_division=0)),
        'precision_weighted': float(precision_score(all_targets, all_preds, average='weighted', zero_division=0)),
        'recall_macro': float(recall_score(all_targets, all_preds, average='macro', zero_division=0)),
        'recall_weighted': float(recall_score(all_targets, all_preds, average='weighted', zero_division=0))
    }


def train_baseline_model(
    model_name: str,
    data: Dict,
    epochs: int = 50,
    batch_size: int = None,
    learning_rate: float = 1e-3,
    output_dir: str = 'nas_search_results',
    early_stopping_patience: int = 7,
    reduce_lr_patience: int = 5,
    device: str = None
) -> Dict:
    """Train a pretrained baseline model"""
    
    if not TORCHVISION_AVAILABLE:
        raise RuntimeError("torchvision is not available. Cannot train baseline models. "
                         "Please reinstall compatible PyTorch/torchvision versions: "
                         "pip uninstall torch torchvision torchaudio && "
                         "pip install torch torchvision torchaudio")
    
    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    print(f"\nBuilding {model_name} baseline model...")
    
    num_classes = data['num_classes']
    
    # Auto-detect batch size
    if batch_size is None:
        batch_size = detect_optimal_batch_size(data['X_train'].shape[0], 10000000)
        print(f"Auto-detected batch size: {batch_size}")
    
    # Build model
    if model_name == 'ResNet50':
        base_model = models.resnet50(weights='IMAGENET1K_V2' if data['X_train'].shape[2] >= 32 else None)
        in_features = base_model.fc.in_features
        base_model.fc = nn.Linear(in_features, num_classes)
    elif model_name == 'DenseNet201':
        base_model = models.densenet201(weights='IMAGENET1K_V1' if data['X_train'].shape[2] >= 32 else None)
        in_features = base_model.classifier.in_features
        base_model.classifier = nn.Linear(in_features, num_classes)
    elif model_name == 'ConvNeXtTiny':
        base_model = models.convnext_tiny(weights='IMAGENET1K_V1' if data['X_train'].shape[2] >= 32 else None)
        in_features = base_model.classifier[2].in_features
        base_model.classifier[2] = nn.Linear(in_features, num_classes)
    elif model_name == 'MobileNetV2':
        base_model = models.mobilenet_v2(weights='IMAGENET1K_V2' if data['X_train'].shape[2] >= 32 else None)
        in_features = base_model.classifier[1].in_features
        base_model.classifier[1] = nn.Linear(in_features, num_classes)
    else:
        raise ValueError(f"Unknown model: {model_name}")
    
    model = base_model.to(device)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Total parameters: {total_params:,}")
    
    # Freeze early layers
    for name, param in model.named_parameters():
        param.requires_grad = True  # Fine-tune all layers
    
    # Create dataloaders
    train_loader = DataLoader(TensorDataset(data['X_train'], data['y_train']), 
                             batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(TensorDataset(data['X_val'], data['y_val']), 
                           batch_size=batch_size, shuffle=False, num_workers=0)
    test_loader = DataLoader(TensorDataset(data['X_test'], data['y_test']), 
                            batch_size=batch_size, shuffle=False, num_workers=0)
    
    # Optimizer and scheduler
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss()
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=reduce_lr_patience, min_lr=1e-7,
    )
    
    # Training loop
    print(f"\nTraining {model_name}...")
    best_val_acc = 0.0
    patience_counter = 0
    start_time = datetime.now()
    
    for epoch in range(epochs):
        # Train
        model.train()
        train_loss = 0.0
        for inputs, targets in train_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        # Validate
        model.eval()
        val_loss = 0.0
        val_correct = 0
        with torch.no_grad():
            for inputs, targets in val_loader:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                val_loss += loss.item()
                _, pred = outputs.max(1)
                val_correct += pred.eq(targets).sum().item()
        
        val_loss /= len(val_loader)
        val_acc = val_correct / len(data['y_val'])
        
        print(f"Epoch {epoch+1}/{epochs} - val_loss: {val_loss:.4f} - val_acc: {val_acc:.4f}")
        
        scheduler.step(val_loss)
        
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            patience_counter = 0
            best_state = model.state_dict()
        else:
            patience_counter += 1
        
        if patience_counter >= early_stopping_patience:
            print(f"Early stopping at epoch {epoch+1}")
            model.load_state_dict(best_state)
            break
    
    training_time = (datetime.now() - start_time).total_seconds()
    
    # Evaluate
    test_metrics = calculate_detailed_metrics(model, test_loader, device)
    val_metrics = calculate_detailed_metrics(model, val_loader, device)
    
    # Save
    model_file = os.path.join(output_dir, f'baseline_{model_name}.pth')
    torch.save(model.state_dict(), model_file)
    
    result = {
        'model_type': 'baseline',
        'model_name': model_name,
        'architecture': model_name,
        'operations': [model_name],
        'test_accuracy': test_metrics['accuracy'],
        'test_f1_macro': test_metrics['f1_score_macro'],
        'test_f1_weighted': test_metrics['f1_score_weighted'],
        'test_precision_macro': test_metrics['precision_macro'],
        'test_precision_weighted': test_metrics['precision_weighted'],
        'test_recall_macro': test_metrics['recall_macro'],
        'test_recall_weighted': test_metrics['recall_weighted'],
        'val_accuracy': val_metrics['accuracy'],
        'max_val_accuracy': best_val_acc,
        'val_f1_macro': val_metrics['f1_score_macro'],
        'total_params': int(total_params),
        'epochs_trained': epoch + 1,
        'training_time_seconds': training_time,
        'timestamp': datetime.now().isoformat()
    }
    
    result_file = os.path.join(output_dir, f'results_baseline_{model_name}.json')
    with open(result_file, 'w') as f:
        json.dump(result, f, indent=2)
    
    print(f"✓ {model_name}: Test Acc={test_metrics['accuracy']*100:.2f}%, F1={test_metrics['f1_score_macro']:.4f}")
    
    return result


def nas_search(
    data: Dict,
    api_key: str,
    total_iterations: int = 10,
    initial_random: int = 3,
    epochs: int = 50,
    batch_size: int = None,
    learning_rate: float = 1e-3,
    output_dir: str = 'nas_search_results',
    early_stopping_patience: int = 7,
    reduce_lr_patience: int = 5,
    include_baselines: bool = True,
    device: str = None
):
    """Perform automated NAS search using Gemini"""
    
    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    # Initialize Gemini
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel('gemini-2.5-flash-lite')
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Load benchmark data for weighted sampling
    benchmark_analysis = None
    if WEIGHTED_SAMPLING_AVAILABLE:
        print("\nLoading NAS-Bench-201 benchmark data for intelligent random sampling...")
        try:
            benchmark_data = load_benchmark_data()
            if benchmark_data:
                benchmark_analysis = analyze_top_architectures(benchmark_data, top_k=1000)
                print_operation_statistics(benchmark_analysis)
                print("✓ Weighted random sampling enabled (based on top 1000 architectures)")
            else:
                print("⚠️  No benchmark data found - using uniform random")
        except Exception as e:
            print(f"⚠️  Error loading benchmarks: {e}")
            print("   Using uniform random sampling")
    
    all_results = []
    architectures = []
    accuracies = []
    
    print("\n" + "="*80)
    print("AUTOMATED NAS SEARCH (PyTorch) + BASELINE COMPARISON")
    print("="*80)
    print(f"NAS Iterations: {total_iterations}")
    print(f"  - Random: {initial_random}")
    print(f"  - Gemini: {total_iterations - initial_random}")
    if include_baselines:
        print(f"Baselines: 4 (ResNet50, DenseNet201, ConvNeXtTiny, MobileNetV2)")
        print(f"Total: {total_iterations + 4}")
    print(f"Device: {device.upper()}")
    if device == 'cuda':
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    print("="*80 + "\n")
    
    # Phase 1: Random
    print(f"PHASE 1: RANDOM EXPLORATION ({initial_random} architectures)")
    print("="*80 + "\n")
    
    for i in range(initial_random):
        print(f"ITERATION {i+1}/{total_iterations} - Random (Weighted)")
        print("─"*80)
        
        architecture = generate_random_architecture(benchmark_analysis)
        print(f"Architecture: {architecture}")
        print(f"Operations: {', '.join([STRUCT_DICT[op] for op in architecture])}\n")
        
        try:
            result = train_nas_model(
                architecture=architecture,
                data=data,
                epochs=epochs,
                batch_size=batch_size,
                learning_rate=learning_rate,
                output_dir=output_dir,
                early_stopping_patience=early_stopping_patience,
                reduce_lr_patience=reduce_lr_patience,
                device=device
            )
            
            architectures.append(architecture)
            accuracies.append(result['test_accuracy'])
            all_results.append(result)
            
            print(f"✓ Complete - Test Acc: {result['test_accuracy']*100:.2f}%\n")
        except Exception as e:
            print(f"✗ Error: {e}\n")
            continue
    
    # Phase 2: Gemini
    gemini_iterations = total_iterations - initial_random
    
    if gemini_iterations > 0:
        print(f"\nPHASE 2: GEMINI-GUIDED SEARCH ({gemini_iterations} architectures)")
        print("="*80 + "\n")
        
        for i in range(gemini_iterations):
            iter_num = initial_random + i + 1
            print(f"ITERATION {iter_num}/{total_iterations} - Gemini")
            print("─"*80)
            
            architecture = None
            for attempt in range(3):
                print(f"Generating with Gemini (attempt {attempt+1}/3)...")
                architecture = generate_architecture_with_gemini(model, architectures, accuracies)
                if architecture:
                    print("✓ Gemini generated architecture")
                    break
            
            if not architecture:
                print("⚠️  Gemini failed, using weighted random fallback")
                for _ in range(100):
                    architecture = generate_random_architecture(benchmark_analysis)
                    if architecture not in architectures:
                        break
                print("✓ Generated unique weighted random architecture")
            
            print(f"Architecture: {architecture}")
            print(f"Operations: {', '.join([STRUCT_DICT[op] for op in architecture])}\n")
            
            try:
                result = train_nas_model(
                    architecture=architecture,
                    data=data,
                    epochs=epochs,
                    batch_size=batch_size,
                    learning_rate=learning_rate,
                    output_dir=output_dir,
                    early_stopping_patience=early_stopping_patience,
                    reduce_lr_patience=reduce_lr_patience,
                    device=device
                )
                
                architectures.append(architecture)
                accuracies.append(result['test_accuracy'])
                all_results.append(result)
                
                best_so_far = max(accuracies)
                if result['test_accuracy'] == best_so_far:
                    print(f"🎉 NEW BEST!")
                
                print(f"✓ Complete - Test Acc: {result['test_accuracy']*100:.2f}%\n")
            except Exception as e:
                print(f"✗ Error: {e}\n")
                continue
    
    # Phase 3: Baselines
    if include_baselines:
        if not TORCHVISION_AVAILABLE:
            print(f"\n⚠️  PHASE 3: BASELINE MODELS SKIPPED")
            print("="*80)
            print("torchvision is not available. Baseline models require torchvision.")
            print("To fix: pip uninstall torch torchvision torchaudio && pip install torch torchvision torchaudio")
            print("="*80 + "\n")
        else:
        baseline_models = ['ResNet50', 'DenseNet201', 'ConvNeXtTiny', 'MobileNetV2']
        
        print(f"\nPHASE 3: BASELINE MODELS ({len(baseline_models)} models)")
        print("="*80 + "\n")
        
        for i, model_name in enumerate(baseline_models, 1):
            print(f"BASELINE {i}/{len(baseline_models)} - {model_name}")
            print("─"*80)
            
            try:
                result = train_baseline_model(
                    model_name=model_name,
                    data=data,
                    epochs=epochs,
                    batch_size=batch_size,
                    learning_rate=learning_rate,
                    output_dir=output_dir,
                    early_stopping_patience=early_stopping_patience,
                    reduce_lr_patience=reduce_lr_patience,
                    device=device
                )
                all_results.append(result)
                print()
            except Exception as e:
                print(f"✗ Error training {model_name}: {e}\n")
                continue
    
    # Final Analysis
    print("\n" + "="*120)
    print("COMPREHENSIVE MODEL COMPARISON")
    print("="*120)
    
    if not all_results:
        print("No successful results.")
        return
    
    sorted_results = sorted(all_results, key=lambda x: x['test_accuracy'], reverse=True)
    nas_results = [r for r in sorted_results if r.get('model_type') == 'nas']
    baseline_results = [r for r in sorted_results if r.get('model_type') == 'baseline']
    
    # Print table
    print(f"{'Rank':<6} {'Type':<12} {'Architecture/Model':<25} {'Test Acc':<10} {'F1':<10} {'Val Acc':<10} {'Params':<15} {'Epochs':<8}")
    print("="*120)
    
    for i, result in enumerate(sorted_results, 1):
        model_type = result.get('model_type', 'nas')
        if model_type == 'baseline':
            arch_str = result['model_name']
        else:
            arch_str = str(result['architecture'])[:25]
        
        mark = "🏆" if i == 1 else "  "
        print(f"{mark}{i:<4} {model_type.upper():<12} {arch_str:<25} "
              f"{result['test_accuracy']*100:>8.2f}% {result.get('test_f1_macro', 0):>8.4f} "
              f"{result['max_val_accuracy']*100:>8.2f}% {result['total_params']:>13,} {result['epochs_trained']:<8}")
    
    print("="*120)
    
    # Save summary
    summary = {
        'search_config': {
            'total_nas_iterations': total_iterations,
            'baseline_models': len(baseline_results),
            'epochs_per_model': epochs,
            'device': device,
            'timestamp': datetime.now().isoformat()
        },
        'all_results': sorted_results,
        'best_overall': sorted_results[0],
        'best_nas': nas_results[0] if nas_results else None,
        'best_baseline': baseline_results[0] if baseline_results else None
    }
    
    with open(os.path.join(output_dir, 'search_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"\n🏆 WINNER: ", end='')
    best = sorted_results[0]
    if best.get('model_type') == 'baseline':
        print(f"{best['model_name']} - {best['test_accuracy']*100:.2f}%")
    else:
        print(f"NAS {best['architecture']} - {best['test_accuracy']*100:.2f}%")
    
    print("="*120 + "\n")


def main():
    parser = argparse.ArgumentParser(description='Automated NAS Search (PyTorch)')
    
    parser.add_argument('--x_train', required=True)
    parser.add_argument('--y_train', required=True)
    parser.add_argument('--x_test', required=True)
    parser.add_argument('--y_test', required=True)
    parser.add_argument('--api_key', required=True, help='Gemini API key')
    
    parser.add_argument('--iterations', type=int, default=10)
    parser.add_argument('--initial_random', type=int, default=3)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--batch_size', type=int, default=None)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--val_split', type=float, default=0.1)
    parser.add_argument('--target_size', type=str, default='32,32')
    parser.add_argument('--output_dir', type=str, default='nas_search_results',
                        help='Base output directory (default: nas_search_results)')
    parser.add_argument('--dataset_name', type=str, default=None,
                        help='Dataset/experiment name (creates subfolder in output_dir)')
    parser.add_argument('--early_stopping_patience', type=int, default=7)
    parser.add_argument('--reduce_lr_patience', type=int, default=5)
    parser.add_argument('--no_baselines', action='store_true')
    parser.add_argument('--device', type=str, default=None, choices=['cuda', 'cpu'])
    
    args = parser.parse_args()
    
    # Parse target size
    try:
        target_h, target_w = [int(x.strip()) for x in args.target_size.split(',')]
        target_size = (target_h, target_w)
    except:
        target_size = (32, 32)
    
    # Setup output directory with dataset name
    if args.dataset_name:
        output_dir = os.path.join(args.output_dir, args.dataset_name)
        print(f"Results will be saved to: {output_dir}")
    else:
        output_dir = args.output_dir
    
    # Load data
    data = load_and_preprocess_data(
        x_train_path=args.x_train,
        y_train_path=args.y_train,
        x_test_path=args.x_test,
        y_test_path=args.y_test,
        target_size=target_size,
        val_split=args.val_split
    )
    
    # Run search
    nas_search(
        data=data,
        api_key=args.api_key,
        total_iterations=args.iterations,
        initial_random=args.initial_random,
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        output_dir=output_dir,
        early_stopping_patience=args.early_stopping_patience,
        reduce_lr_patience=args.reduce_lr_patience,
        include_baselines=not args.no_baselines,
        device=args.device
    )


if __name__ == '__main__':
    main()

