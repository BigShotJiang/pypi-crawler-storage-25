#!/usr/bin/env python3
"""
NAS-Bench-201 Training CLI (PyTorch Version)
Neural Architecture Search training script for 5G experiments.

This script implements NAS-Bench-201 architecture search space in PyTorch.
It trains models on custom datasets provided as numpy arrays.

Usage:
    python nas_train.py --x_train path/to/X_train.npy --y_train path/to/y_train.npy \\
                        --x_test path/to/X_test.npy --y_test path/to/y_test.npy \\
                        --architecture 3,2,3,1,2,4 --epochs 50 --batch_size 16
"""

import argparse
import json
import numpy as np
import os
import sys
from datetime import datetime
from typing import List, Tuple, Dict
import time
import psutil
from sklearn.metrics import f1_score, precision_score, recall_score

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, TensorDataset
import torchvision.transforms as transforms


# NAS-Bench-201 operation dictionary
STRUCT_DICT = ['none', 'skip_connect', 'nor_conv_1x1', 'nor_conv_3x3', 'avg_pool_3x3']


# ==================== NAS Operations ====================

class Zeroize(nn.Module):
    """Operation that breaks gradient flow - returns zeros"""
    def __init__(self):
        super(Zeroize, self).__init__()
    
    def forward(self, x):
        return torch.zeros_like(x)


class Identity(nn.Module):
    """Identity/Skip connection operation"""
    def __init__(self):
        super(Identity, self).__init__()
    
    def forward(self, x):
        return x


class ReLUConvBN(nn.Module):
    """ReLU -> Conv2D -> BatchNorm composite operation"""
    def __init__(self, channels, kernel_size, padding):
        super(ReLUConvBN, self).__init__()
        self.relu = nn.ReLU(inplace=False)
        self.conv = nn.Conv2d(channels, channels, kernel_size=kernel_size, 
                             stride=1, padding=padding, bias=False)
        self.bn = nn.BatchNorm2d(channels, momentum=0.1, eps=1e-5)
    
    def forward(self, x):
        x = self.relu(x)
        x = self.conv(x)
        x = self.bn(x)
        return x


def get_operation(op_id: int, channels: int) -> nn.Module:
    """Get NAS operation by ID"""
    if op_id == 0:
        return Zeroize()
    elif op_id == 1:
        return Identity()
    elif op_id == 2:
        return ReLUConvBN(channels, kernel_size=1, padding=0)
    elif op_id == 3:
        return ReLUConvBN(channels, kernel_size=3, padding=1)
    elif op_id == 4:
        return nn.AvgPool2d(kernel_size=3, stride=1, padding=1)
    else:
        raise ValueError(f"Invalid operation ID: {op_id}")


class NAS201Cell(nn.Module):
    """NAS-Bench-201 Cell with 6 operations"""
    def __init__(self, op_vector: List[int], channels: int):
        super(NAS201Cell, self).__init__()
        self.op_vector = op_vector
        self.channels = channels
        
        # Create 6 operations based on op_vector
        self.ops = nn.ModuleList([get_operation(op_id, channels) for op_id in op_vector])
    
    def forward(self, x):
        """
        NAS-Bench-201 cell computation graph:
        s0 = input
        s1 = op0(s0)
        s2 = op1(s0) + op2(s1)
        s3 = op3(s0) + op4(s1) + op5(s2)
        output = s3
        """
        s0 = x
        s1 = self.ops[0](s0)
        s2 = self.ops[1](s0) + self.ops[2](s1)
        s3 = self.ops[3](s0) + self.ops[4](s1) + self.ops[5](s2)
        return s3


class ResidualBlock(nn.Module):
    """Residual downsampling block"""
    def __init__(self, in_channels, out_channels):
        super(ResidualBlock, self).__init__()
        
        # Shortcut path
        # ceil_mode=True ensures output spatial size matches the main branch
        # (Conv2d stride=2 with padding=1 ceils; AvgPool2d without ceil_mode floors)
        self.shortcut = nn.Sequential(
            nn.AvgPool2d(kernel_size=2, stride=2, padding=0, ceil_mode=True),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(out_channels)
        )
        
        # Main path
        self.main = nn.Sequential(
            nn.ReLU(inplace=False),
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(out_channels)
        )
    
    def forward(self, x):
        return self.main(x) + self.shortcut(x)


class NASBench201Network(nn.Module):
    """NAS-Bench-201 Network"""
    def __init__(self, op_vector: List[int], num_classes: int = 10, input_channels: int = 3):
        super(NASBench201Network, self).__init__()
        
        # Stem
        self.stem = nn.Sequential(
            nn.Conv2d(input_channels, 16, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(16)
        )
        
        # Stage 1: 5 cells, 16 channels, no downsampling
        self.stage1 = nn.Sequential(*[NAS201Cell(op_vector, 16) for _ in range(5)])
        
        # Reduction 1
        self.reduction1 = ResidualBlock(16, 32)
        
        # Stage 2: 5 cells, 32 channels
        self.stage2 = nn.Sequential(*[NAS201Cell(op_vector, 32) for _ in range(5)])
        
        # Reduction 2
        self.reduction2 = ResidualBlock(32, 64)
        
        # Stage 3: 5 cells, 64 channels
        self.stage3 = nn.Sequential(*[NAS201Cell(op_vector, 64) for _ in range(5)])
        
        # Classification head
        self.global_avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(64, num_classes)
    
    def forward(self, x):
        x = self.stem(x)
        x = self.stage1(x)
        x = self.reduction1(x)
        x = self.stage2(x)
        x = self.reduction2(x)
        x = self.stage3(x)
        x = self.global_avg_pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x


def build_nas201_model(
    op_vector: List[int],
    num_classes: int = 10,
    input_channels: int = 3
) -> nn.Module:
    """Build NAS-Bench-201 model"""
    return NASBench201Network(op_vector, num_classes, input_channels)


# ==================== Data Loading ====================

def load_and_preprocess_data(
    x_train_path: str,
    y_train_path: str,
    x_test_path: str,
    y_test_path: str,
    target_size: Tuple[int, int] = (32, 32),
    val_split: float = 0.1,
    device: str = 'cuda',
    normalize: bool = True
) -> Dict:
    """
    Load and preprocess numpy data files
    
    Supports both channel orderings:
    - NHWC (channels-last): [N, H, W, C] e.g., [100, 64, 64, 3]
    - NCHW (channels-first): [N, C, H, W] e.g., [100, 3, 64, 64]
    """
    print("Loading data files...")
    
    # Load numpy arrays
    X_train_full = np.load(x_train_path)
    y_train_full = np.load(y_train_path)
    X_test = np.load(x_test_path)
    y_test = np.load(y_test_path)
    
    print(f"Loaded shapes: X_train={X_train_full.shape}, y_train={y_train_full.shape}, "
          f"X_test={X_test.shape}, y_test={y_test.shape}")
    
    def preprocess_images(X, target_size, normalize=True):
        """Preprocess images: ensure NCHW format, resize, normalize"""
        # Ensure 4D
        if len(X.shape) == 3:
            X = np.expand_dims(X, axis=0)
        
        if len(X.shape) != 4:
            raise ValueError(f"Expected 4D array, got shape {X.shape}")
        
        # Detect and convert to NCHW (PyTorch format)
        if X.shape[-1] in [1, 3] and X.shape[-1] < X.shape[1]:
            # NHWC format detected
            print(f"  Detected NHWC format (channels-last): {X.shape}")
            print(f"  Converting to NCHW format (channels-first)...")
            X = np.transpose(X, (0, 3, 1, 2))  # NHWC -> NCHW
            print(f"  New shape: {X.shape}")
        
        N, C, H, W = X.shape
        
        # Convert grayscale to RGB
        if C == 1:
            X = np.repeat(X, 3, axis=1)
            C = 3
        elif C != 3:
            raise ValueError(f"Expected 1 or 3 channels, got {C}")
        
        # Resize if needed
        if (H, W) != target_size:
            print(f"Resizing images from ({H}, {W}) to {target_size}...")
            X_resized = np.zeros((N, 3, target_size[0], target_size[1]), dtype=X.dtype)
            for i in range(N):
                # Convert to tensor, resize, convert back
                img_tensor = torch.from_numpy(X[i]).float()
                img_resized = F.interpolate(img_tensor.unsqueeze(0), size=target_size, mode='bilinear', align_corners=False)
                X_resized[i] = img_resized.squeeze(0).numpy()
            X = X_resized
        
        # Normalize to [0, 1] if enabled
        if normalize:
            min_val = float(X.min())
            max_val = float(X.max())
            if min_val < -0.1 or max_val > 255.5:
                # Custom range data (e.g. standardized, z-scored, negative values)
                # Do NOT divide by 255 — it would destroy the distribution
                print(f"Custom value range [{min_val:.2f}, {max_val:.2f}] detected. Skipping /255 normalization — keeping original range.")
                X = X.astype(np.float32)
            elif X.dtype == np.uint8 or max_val > 1.0:
                print(f"Normalizing images from [0, 255] to [0, 1] range...")
                X = X.astype(np.float32) / 255.0
            else:
                X = X.astype(np.float32)
        else:
            print(f"Normalization disabled. Keeping original value range.")
            X = X.astype(np.float32)
        
        return X
    
    def preprocess_labels(y):
        """Ensure labels are 1D integer array"""
        while len(y.shape) > 1 and y.shape[-1] == 1:
            y = np.squeeze(y, axis=-1)
        
        if len(y.shape) == 2:
            y = np.argmax(y, axis=1)
        
        if len(y.shape) != 1:
            raise ValueError(f"Expected 1D labels, got shape {y.shape}")
        
        return y.astype(np.int64)
    
    # Preprocess all data
    X_train_full = preprocess_images(X_train_full, target_size, normalize)
    X_test = preprocess_images(X_test, target_size, normalize)
    y_train_full = preprocess_labels(y_train_full)
    y_test = preprocess_labels(y_test)
    
    # Create validation split
    val_count = max(1, int(val_split * len(X_train_full)))
    X_val = X_train_full[:val_count]
    y_val = y_train_full[:val_count]
    X_train = X_train_full[val_count:]
    y_train = y_train_full[val_count:]
    
    num_classes = max(int(y_train.max()), int(y_test.max())) + 1
    
    print(f"Preprocessed data:")
    print(f"  Training: {X_train.shape}, labels: {y_train.shape}")
    print(f"  Validation: {X_val.shape}, labels: {y_val.shape}")
    print(f"  Test: {X_test.shape}, labels: {y_test.shape}")
    print(f"  Number of classes: {num_classes}")
    
    return {
        'X_train': torch.from_numpy(X_train).float(),
        'y_train': torch.from_numpy(y_train).long(),
        'X_val': torch.from_numpy(X_val).float(),
        'y_val': torch.from_numpy(y_val).long(),
        'X_test': torch.from_numpy(X_test).float(),
        'y_test': torch.from_numpy(y_test).long(),
        'num_classes': num_classes,
        'input_channels': X_train.shape[1]
    }


def detect_optimal_batch_size(num_samples: int, num_params: int, available_memory_gb: float = None) -> int:
    """Automatically detect optimal batch size"""
    if available_memory_gb is None:
        memory = psutil.virtual_memory()
        available_memory_gb = memory.available / (1024 ** 3)
    
    has_gpu = torch.cuda.is_available()
    
    if has_gpu:
        if available_memory_gb > 12:
            base_batch_size = 64
        elif available_memory_gb > 8:
            base_batch_size = 32
        elif available_memory_gb > 4:
            base_batch_size = 16
        else:
            base_batch_size = 8
    else:
        if available_memory_gb > 8:
            base_batch_size = 32
        elif available_memory_gb > 4:
            base_batch_size = 16
        else:
            base_batch_size = 8
    
    # Adjust based on model size
    if num_params > 10_000_000:
        base_batch_size = max(8, base_batch_size // 4)
    elif num_params > 5_000_000:
        base_batch_size = max(8, base_batch_size // 2)
    elif num_params > 1_000_000:
        base_batch_size = max(8, int(base_batch_size * 0.75))
    
    max_reasonable_batch = min(num_samples // 4, 128)
    batch_size = min(base_batch_size, max_reasonable_batch)
    batch_size = max(4, batch_size)
    
    return batch_size


# ==================== Training ====================

def detect_device(device: str | None = None) -> str:
    """Detect the best available device, with improved Linux GPU detection."""
    # If explicitly set, use it
    if device is not None:
        if device == 'cuda' and not torch.cuda.is_available():
            print(f"Warning: CUDA requested but not available. Falling back to CPU.", file=sys.stderr)
            return 'cpu'
        return device
    
    # Try to detect CUDA availability with multiple methods
    try:
        # Method 1: Standard PyTorch check
        if torch.cuda.is_available():
            # Verify we can actually create a tensor on GPU
            try:
                test_tensor = torch.zeros(1).cuda()
                del test_tensor
                torch.cuda.empty_cache()
                return 'cuda'
            except Exception:
                pass
        
        # Method 2: Check for CUDA devices directly (Linux-specific)
        if hasattr(torch.cuda, 'device_count') and torch.cuda.device_count() > 0:
            try:
                # Try to get device name to verify it's accessible
                device_name = torch.cuda.get_device_name(0)
                if device_name:
                    return 'cuda'
            except Exception:
                pass
        
        # Method 3: Check environment variables (Linux often sets these)
        if os.environ.get('CUDA_VISIBLE_DEVICES') is not None:
            # If CUDA_VISIBLE_DEVICES is set, try to use CUDA
            try:
                if torch.cuda.is_available() and torch.cuda.device_count() > 0:
                    return 'cuda'
            except Exception:
                pass
    except Exception:
        pass
    
    # Fallback to CPU
    return 'cpu'


def train_nas_model(
    architecture: List[int],
    data: Dict,
    epochs: int = 50,
    batch_size: int = None,
    learning_rate: float = 1e-3,
    output_dir: str = 'results',
    early_stopping_patience: int = 7,
    reduce_lr_patience: int = 5,
    device: str = None,
    normalize: bool = True
) -> Dict:
    """Train NAS-Bench-201 model"""
    
    # Setup device with improved detection
    device = detect_device(device)
    
    print("\n" + "="*80)
    print(f"Training NAS-Bench-201 Model (PyTorch)")
    print(f"Architecture: {architecture}")
    print(f"Operations: {[STRUCT_DICT[op] for op in architecture]}")
    print(f"Device: {device.upper()}")
    if device == 'cuda':
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    print("="*80 + "\n")
    
    # Build model
    print("Building model...")
    model = build_nas201_model(
        op_vector=architecture,
        num_classes=data['num_classes'],
        input_channels=data['input_channels']
    )
    model = model.to(device)
    
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total parameters: {total_params:,}")
    print(f"Trainable parameters: {trainable_params:,}")
    
    # Auto-detect batch size if needed
    if batch_size is None:
        num_samples = data['X_train'].shape[0]
        batch_size = detect_optimal_batch_size(num_samples, total_params)
        print(f"Auto-detected optimal batch size: {batch_size}")
        memory = psutil.virtual_memory()
        print(f"  Available memory: {memory.available / (1024**3):.1f} GB")
        print(f"  Hardware: {'GPU' if device == 'cuda' else 'CPU'}")
    
    # Create data loaders
    train_dataset = TensorDataset(data['X_train'], data['y_train'])
    val_dataset = TensorDataset(data['X_val'], data['y_val'])
    test_dataset = TensorDataset(data['X_test'], data['y_test'])
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=0)
    
    # Optimizer and scheduler
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss()
    
    # Learning rate scheduler
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=reduce_lr_patience,
        min_lr=1e-7,
    )
    
    # Training configuration
    print(f"\nTraining Configuration:")
    print(f"  Epochs: {epochs} (max)")
    print(f"  Batch size: {batch_size}")
    print(f"  Learning rate: {learning_rate:.2e}")
    print(f"  Early stopping patience: {early_stopping_patience} epochs")
    print(f"  ReduceLR patience: {reduce_lr_patience} epochs")
    print("-" * 80 + "\n")
    
    # Training loop
    best_val_loss = float('inf')
    best_val_acc = 0.0
    patience_counter = 0
    epoch_metrics = []
    start_time = time.time()
    
    # Initialize best_model_state with initial model state
    # This ensures it's always available even if early stopping triggers before any improvement
    best_model_state = model.state_dict()
    
    for epoch in range(epochs):
        epoch_start = time.time()
        
        # Training phase
        model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0
        
        for batch_idx, (inputs, targets) in enumerate(train_loader):
            inputs, targets = inputs.to(device), targets.to(device)
            
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
            _, predicted = outputs.max(1)
            train_total += targets.size(0)
            train_correct += predicted.eq(targets).sum().item()
            # Emit batch progress for UI streaming
            try:
                running_acc = float(train_correct) / float(train_total) if train_total > 0 else 0.0
                print("BATCH_JSON:" + json.dumps({
                    'epoch': epoch + 1,
                    'batch': batch_idx + 1,
                    'total_batches': len(train_loader),
                    'batch_loss': float(loss.item()),
                    'running_accuracy': running_acc
                }), flush=True)
            except Exception:
                pass
        
        train_loss /= len(train_loader)
        train_acc = train_correct / train_total
        
        # Validation phase
        model.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0
        
        with torch.no_grad():
            for inputs, targets in val_loader:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                
                val_loss += loss.item()
                _, predicted = outputs.max(1)
                val_total += targets.size(0)
                val_correct += predicted.eq(targets).sum().item()
        
        val_loss /= len(val_loader)
        val_acc = val_correct / val_total
        
        epoch_time = time.time() - epoch_start
        current_lr = optimizer.param_groups[0]['lr']
        
        # Store metrics
        metrics = {
            'epoch': epoch + 1,
            'train_loss': train_loss,
            'train_accuracy': train_acc,
            'val_loss': val_loss,
            'val_accuracy': val_acc,
            'learning_rate': current_lr,
            'epoch_time': f"{int(epoch_time)}s"
        }
        epoch_metrics.append(metrics)
        
        # Print progress (human readable)
        print(f"Epoch {epoch+1}/{epochs} - {int(epoch_time)}s - "
              f"loss: {train_loss:.4f} - acc: {train_acc:.4f} - "
              f"val_loss: {val_loss:.4f} - val_acc: {val_acc:.4f} - "
              f"lr: {current_lr:.2e}")
        
        # Emit machine-readable JSON line for streaming in the extension
        try:
            print("EPOCH_JSON:" + json.dumps(metrics), flush=True)
        except Exception:
            pass
        
        # Learning rate scheduling
        scheduler.step(val_loss)
        
        # Early stopping logic
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            patience_counter = 0
            # Save best model
            best_model_state = model.state_dict()
        else:
            patience_counter += 1
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
        
        if patience_counter >= early_stopping_patience:
            try:
                print("EARLY_STOP_JSON:" + json.dumps({'epoch': int(epoch + 1)}), flush=True)
            except Exception:
                pass
            print(f"\nEarly stopping triggered at epoch {epoch+1}")
            print(f"Restoring best model weights (val_acc={best_val_acc:.4f})")
            model.load_state_dict(best_model_state)
            break
    
    training_time = time.time() - start_time
    
    # Evaluate on test set
    print("\n" + "-" * 80)
    print("Evaluating on test set...")
    model.eval()
    
    all_preds = []
    all_targets = []
    test_loss = 0.0
    
    with torch.no_grad():
        for inputs, targets in test_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            test_loss += loss.item()
            
            _, predicted = outputs.max(1)
            all_preds.extend(predicted.cpu().numpy())
            all_targets.extend(targets.cpu().numpy())
    
    test_loss /= len(test_loader)
    all_preds = np.array(all_preds)
    all_targets = np.array(all_targets)
    
    # Calculate comprehensive metrics
    test_acc = float(np.mean(all_preds == all_targets))
    test_f1_macro = float(f1_score(all_targets, all_preds, average='macro', zero_division=0))
    test_f1_weighted = float(f1_score(all_targets, all_preds, average='weighted', zero_division=0))
    test_precision_macro = float(precision_score(all_targets, all_preds, average='macro', zero_division=0))
    test_precision_weighted = float(precision_score(all_targets, all_preds, average='weighted', zero_division=0))
    test_recall_macro = float(recall_score(all_targets, all_preds, average='macro', zero_division=0))
    test_recall_weighted = float(recall_score(all_targets, all_preds, average='weighted', zero_division=0))
    
    print(f"Test Loss: {test_loss:.4f}")
    print(f"Test Accuracy: {test_acc:.4f} ({test_acc*100:.2f}%)")
    print(f"Test F1 (macro): {test_f1_macro:.4f}")
    print(f"Test F1 (weighted): {test_f1_weighted:.4f}")
    
    # Prepare results
    results = {
        'model_type': 'nas',
        'architecture': architecture,
        'operations': [STRUCT_DICT[op] for op in architecture],
        'test_accuracy': test_acc,
        'test_loss': test_loss,
        'test_f1_macro': test_f1_macro,
        'test_f1_weighted': test_f1_weighted,
        'test_precision_macro': test_precision_macro,
        'test_precision_weighted': test_precision_weighted,
        'test_recall_macro': test_recall_macro,
        'test_recall_weighted': test_recall_weighted,
        'max_val_accuracy': best_val_acc,
        'total_params': int(total_params),
        'epochs_trained': len(epoch_metrics),
        'training_time_seconds': training_time,
        'epoch_metrics': epoch_metrics,
        'timestamp': datetime.now().isoformat()
    }
    
    # Save results
    os.makedirs(output_dir, exist_ok=True)
    
    search_id = generate_search_id(architecture)
    results['search_id'] = search_id
    
    # Save JSON results
    result_file = os.path.join(output_dir, f'results_{search_id.replace("|", "_")}.json')
    with open(result_file, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to: {result_file}")
    
    # Save model
    model_file = os.path.join(output_dir, f'model_{search_id.replace("|", "_")}.pth')
    torch.save({
        'model_state_dict': model.state_dict(),
        'architecture': architecture,
        'num_classes': data['num_classes'],
        'total_params': total_params,
        'input_channels': int(data['X_train'].shape[1]),
        'image_size': [int(data['X_train'].shape[2]), int(data['X_train'].shape[3])],
        'normalize': normalize
    }, model_file)
    print(f"Model saved to: {model_file}")
    
    # Attach auxiliary fields BEFORE emitting RESULT_JSON so the UI receives them
    results['model_file'] = model_file
    results['num_classes'] = int(data['num_classes'])
    results['image_size'] = [int(data['X_train'].shape[2]), int(data['X_train'].shape[3])]

    # Emit final machine-readable summary JSON (must be after all fields are added)
    try:
        print("RESULT_JSON:" + json.dumps(results), flush=True)
    except Exception:
        pass

    return results


def generate_search_id(operations: List[int]) -> str:
    """Generate NAS-Bench-201 search space ID"""
    return (f"|{STRUCT_DICT[operations[0]]}~0|+"
            f"|{STRUCT_DICT[operations[1]]}~0|{STRUCT_DICT[operations[2]]}~1|+"
            f"|{STRUCT_DICT[operations[3]]}~0|{STRUCT_DICT[operations[4]]}~1|{STRUCT_DICT[operations[5]]}~2|")


def parse_architecture(arch_str: str) -> List[int]:
    """Parse architecture string to list of operation IDs"""
    try:
        ops = [int(x.strip()) for x in arch_str.split(',')]
        if len(ops) != 6:
            raise ValueError(f"Architecture must have exactly 6 operations, got {len(ops)}")
        if not all(0 <= op <= 4 for op in ops):
            raise ValueError("All operation IDs must be between 0 and 4")
        return ops
    except Exception as e:
        raise ValueError(f"Invalid architecture format: {e}")
def normalize_path(path):
    return os.path.abspath(os.path.expanduser(path.replace("\\", os.sep)))


def main():
    parser = argparse.ArgumentParser(
        description='NAS-Bench-201 Training CLI (PyTorch)',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    # Required arguments
    parser.add_argument('--x_train', type=str, required=True, help='Path to X_train.npy')
    parser.add_argument('--y_train', type=str, required=True, help='Path to y_train.npy')
    parser.add_argument('--x_test', type=str, required=True, help='Path to X_test.npy')
    parser.add_argument('--y_test', type=str, required=True, help='Path to y_test.npy')
    parser.add_argument('--architecture', type=str, required=True,
                        help='Architecture vector as comma-separated operation IDs')
    
    # Optional arguments
    parser.add_argument('--epochs', type=int, default=50, help='Training epochs (default: 50)')
    parser.add_argument('--batch_size', type=int, default=None, help='Batch size (default: auto-detect)')
    parser.add_argument('--lr', type=float, default=1e-3, help='Learning rate (default: 0.001)')
    parser.add_argument('--val_split', type=float, default=0.1, help='Validation split (default: 0.1)')
    parser.add_argument('--target_size', type=str, default='32,32', help='Target image size (default: 32,32)')
    parser.add_argument('--output_dir', type=str, default='results', help='Output directory (default: results)')
    parser.add_argument('--dataset_name', type=str, default=None,
                        help='Dataset/experiment name (creates subfolder in output_dir)')
    parser.add_argument('--early_stopping_patience', type=int, default=7, help='Early stopping patience')
    parser.add_argument('--reduce_lr_patience', type=int, default=5, help='ReduceLR patience')
    parser.add_argument('--device', type=str, default=None, choices=['cuda', 'cpu'],
                        help='Device to use (default: auto-detect)')
    parser.add_argument('--normalize', type=int, default=1, choices=[0, 1],
                        help='Whether to normalize images (1=enabled/default, 0=disabled)')
    
    args = parser.parse_args()
    
    # Check PyTorch CUDA
    print(f"PyTorch version: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"CUDA version: {torch.version.cuda}")
        print(f"GPU count: {torch.cuda.device_count()}")
        for i in range(torch.cuda.device_count()):
            print(f"  GPU {i}: {torch.cuda.get_device_name(i)}")
    
    # Parse architecture
    architecture = parse_architecture(args.architecture)
    
    # Parse target size
    try:
        target_h, target_w = [int(x.strip()) for x in args.target_size.split(',')]
        target_size = (target_h, target_w)
        print(f"Target image size: {target_size}")
    except:
        print(f"Warning: Invalid target_size, using default (32, 32)")
        target_size = (32, 32)
    
    # Setup output directory with dataset name
    if args.dataset_name:
        output_dir = os.path.abspath(os.path.expanduser(output_dir))
        print(f"Results will be saved to: {output_dir}")
    else:
        output_dir = args.output_dir

    x_train_path = normalize_path(args.x_train)
    y_train_path = normalize_path(args.y_train)
    x_test_path = normalize_path(args.x_test)
    y_test_path = normalize_path(args.y_test)

    # Parse normalize flag
    normalize = bool(args.normalize)
    print(f"Normalization: {'enabled' if normalize else 'disabled'}")
    
    # Load data
    data = load_and_preprocess_data(
        x_train_path=x_train_path,
        y_train_path=y_train_path,
        x_test_path=x_test_path,
        y_test_path=y_test_path,
        target_size=target_size,
        val_split=args.val_split,
        normalize=normalize
)

    
    # Train model
    results = train_nas_model(
        architecture=architecture,
        data=data,
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        output_dir=output_dir,
        early_stopping_patience=args.early_stopping_patience,
        reduce_lr_patience=args.reduce_lr_patience,
        device=args.device,
        normalize=normalize
    )
    
    # Print final summary
    print("\n" + "="*80)
    print("TRAINING COMPLETE")
    print("="*80)
    print(f"Architecture: {results['architecture']}")
    print(f"Test Accuracy: {results['test_accuracy']*100:.2f}%")
    print(f"Test F1 (macro): {results['test_f1_macro']:.4f}")
    print(f"Parameters: {results['total_params']:,}")
    print(f"Epochs: {results['epochs_trained']}")
    print(f"Time: {results['training_time_seconds']:.0f}s ({results['training_time_seconds']/60:.1f}min)")
    print("="*80 + "\n")


if __name__ == '__main__':
    main()
