#!/usr/bin/env python3
"""
Test script to verify IC-xApp dataset compatibility with NAS search code
"""
import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))

# Change to project root
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
os.chdir(project_root)

print("="*80)
print("Testing IC-xApp Dataset Compatibility")
print("="*80)
print(f"Project root: {project_root}")
print(f"Working directory: {os.getcwd()}\n")

# Test 1: Check if data files exist
print("Test 1: Checking data files...")
data_files = [
    'IC-xApp/X_train.npy',
    'IC-xApp/y_train.npy',
    'IC-xApp/X_test.npy',
    'IC-xApp/y_test.npy'
]

for file in data_files:
    if os.path.exists(file):
        print(f"  ✓ {file} exists")
    else:
        print(f"  ✗ {file} NOT FOUND")
        sys.exit(1)

# Test 2: Load and inspect data
print("\nTest 2: Loading and inspecting data...")
try:
    import numpy as np
    X_train = np.load('IC-xApp/X_train.npy')
    y_train = np.load('IC-xApp/y_train.npy')
    X_test = np.load('IC-xApp/X_test.npy')
    y_test = np.load('IC-xApp/y_test.npy')
    
    print(f"  ✓ Data loaded successfully")
    print(f"    X_train: shape={X_train.shape}, dtype={X_train.dtype}")
    print(f"    y_train: shape={y_train.shape}, dtype={y_train.dtype}")
    print(f"    X_test: shape={X_test.shape}, dtype={X_test.dtype}")
    print(f"    y_test: shape={y_test.shape}, dtype={y_test.dtype}")
except Exception as e:
    print(f"  ✗ Error loading data: {e}")
    sys.exit(1)

# Test 3: Test nas_train imports (without torchvision)
print("\nTest 3: Testing nas_train module imports...")
try:
    # Test if we can import without torchvision issues
    from nas_train import load_and_preprocess_data, parse_architecture, detect_optimal_batch_size
    print("  ✓ nas_train imports successful")
except Exception as e:
    print(f"  ✗ Error importing nas_train: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 4: Test data preprocessing
print("\nTest 4: Testing data preprocessing...")
try:
    data = load_and_preprocess_data(
        x_train_path='IC-xApp/X_train.npy',
        y_train_path='IC-xApp/y_train.npy',
        x_test_path='IC-xApp/X_test.npy',
        y_test_path='IC-xApp/y_test.npy',
        target_size=(32, 32),
        val_split=0.1
    )
    print("  ✓ Data preprocessing successful")
    print(f"    Training samples: {data['X_train'].shape[0]}")
    print(f"    Validation samples: {data['X_val'].shape[0]}")
    print(f"    Test samples: {data['X_test'].shape[0]}")
    print(f"    Number of classes: {data['num_classes']}")
    print(f"    Input shape: {data['X_train'].shape}")
    print(f"    Input channels: {data['input_channels']}")
except Exception as e:
    print(f"  ✗ Error preprocessing data: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 5: Check PyTorch
print("\nTest 5: Checking PyTorch installation...")
try:
    import torch
    print(f"  ✓ PyTorch version: {torch.__version__}")
    print(f"    CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"    GPU: {torch.cuda.get_device_name(0)}")
except Exception as e:
    print(f"  ✗ Error with PyTorch: {e}")
    sys.exit(1)

# Test 6: Check torchvision
print("\nTest 6: Checking torchvision (for baseline models)...")
TORCHVISION_AVAILABLE = False
try:
    import torchvision.models as models
    print(f"  ✓ torchvision.models import successful")
    TORCHVISION_AVAILABLE = True
    # Test a baseline model
    test_model = models.resnet50(weights=None)
    print(f"  ✓ ResNet50 instantiation successful")
except Exception as e:
    print(f"  ✗ torchvision import failed: {e}")
    print(f"    Solution: Reinstall compatible versions:")
    print(f"      pip uninstall torch torchvision torchaudio")
    print(f"      pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu")

# Test 7: Check other dependencies
print("\nTest 7: Checking other dependencies...")
dependencies = {
    'numpy': 'np',
    'sklearn': 'sklearn.metrics',
    'psutil': 'psutil'
}

for dep_name, import_name in dependencies.items():
    try:
        __import__(import_name)
        print(f"  ✓ {dep_name} installed")
    except ImportError:
        print(f"  ✗ {dep_name} NOT installed")
        print(f"    Install with: pip install {dep_name}")

# Test 8: Check Gemini API (optional)
print("\nTest 8: Checking Gemini API (optional for nas_search.py)...")
try:
    import google.generativeai as genai
    print(f"  ✓ google-generativeai installed")
except ImportError:
    print(f"  ⚠ google-generativeai NOT installed (required for nas_search.py)")
    print(f"    Install with: pip install google-generativeai")

print("\n" + "="*80)
print("SUMMARY")
print("="*80)
print("✓ Data files exist and can be loaded")
print("✓ nas_train module imports successfully")
print("✓ Data preprocessing works correctly")
if 'models' in dir() or TORCHVISION_AVAILABLE:
    print("✓ torchvision working - baseline models available")
else:
    print("⚠ torchvision has issues - baseline models not available")
print("="*80)

