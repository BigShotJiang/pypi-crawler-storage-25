#!/usr/bin/env python3
"""
Wrapper script for running EDA on tabular data.
Called from TypeScript tabularRunner.ts
"""
import sys
import json
import argparse
import re
import shutil
from pathlib import Path

# Add the Tabular Concepts directory to the path
script_dir = Path(__file__).parent
extension_root = script_dir.parent.parent
tabular_concepts_dir = extension_root / 'Tabular Concepts'
sys.path.insert(0, str(tabular_concepts_dir))

try:
    from neuralsmith_tabular_cli import TabularDataAnalyzer
except ImportError as e:
    print(f"ERROR: Failed to import TabularDataAnalyzer: {e}", file=sys.stderr)
    print(f"Looking in: {tabular_concepts_dir}", file=sys.stderr)
    sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description='Run EDA on tabular CSV data')
    parser.add_argument('--csv', required=True, help='Path to CSV file')
    parser.add_argument('--target', required=True, help='Target column name')
    parser.add_argument('--task', choices=['classification', 'regression'], required=True, help='Task type')
    parser.add_argument('--output', required=True, help='Output directory for EDA report')
    parser.add_argument('--sample-eda', action='store_true', help='Force sampling for EDA on large datasets')
    
    args = parser.parse_args()
    
    csv_path = Path(args.csv)
    if not csv_path.exists():
        print(f"ERROR: CSV file not found: {csv_path}", file=sys.stderr)
        sys.exit(1)
    
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Loading data from {csv_path}...")
    analyzer = TabularDataAnalyzer()
    
    if not analyzer.load_data(str(csv_path), target_column=args.target):
        print(f"ERROR: Failed to load data from {csv_path}", file=sys.stderr)
        sys.exit(1)
    
    print(f"Running EDA for {args.task} task...")
    print(f"Target column: {args.target}")
    
    try:
        eda_insights = analyzer.perform_eda(
            target_column=args.target,
            force_sample=args.sample_eda
        )
        
        # The EDA report is saved to 'eda_report.json' in the current directory
        # Move it to the output directory and validate JSON
        eda_report_path = Path('eda_report.json')
        if eda_report_path.exists():
            output_report_path = output_dir / 'eda_report.json'
            
            # Validate JSON before moving
            try:
                with open(eda_report_path, 'r') as f:
                    json.load(f)  # Validate JSON is parseable
                # Use shutil.move instead of rename to support cross-device moves on Linux
                shutil.move(str(eda_report_path), str(output_report_path))
                print(f"EDA report saved to {output_report_path}")
            except json.JSONDecodeError as e:
                print(f"ERROR: EDA report contains invalid JSON: {e}", file=sys.stderr)
                # Try to fix by replacing NaN values
                with open(eda_report_path, 'r') as f:
                    content = f.read()
                # Replace NaN, Infinity with null
                content = re.sub(r':\s*NaN\s*([,}])', r': null\1', content)
                content = re.sub(r':\s*Infinity\s*([,}])', r': null\1', content)
                content = re.sub(r':\s*-Infinity\s*([,}])', r': null\1', content)
                try:
                    json.loads(content)  # Validate fixed JSON
                    with open(output_report_path, 'w') as f:
                        f.write(content)
                    print(f"EDA report saved to {output_report_path} (NaN values replaced)")
                except json.JSONDecodeError as e2:
                    print(f"ERROR: Could not fix JSON: {e2}", file=sys.stderr)
                    sys.exit(1)
        else:
            print(f"WARNING: EDA report not found at {eda_report_path}", file=sys.stderr)
        
        print("EDA completed successfully!")
        sys.exit(0)
        
    except Exception as e:
        print(f"ERROR: EDA failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()

