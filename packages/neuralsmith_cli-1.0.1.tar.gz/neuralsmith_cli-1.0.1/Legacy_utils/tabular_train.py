#!/usr/bin/env python3
"""
Wrapper script for training models on tabular data.
Called from TypeScript tabularRunner.ts
"""
import sys
import json
import argparse
from pathlib import Path

# Add the Tabular Concepts directory to the path.
# Prefer the in-repo copy under CLI/Legacy_utils, with a fallback to the
# legacy sibling location used by older layouts.
script_dir = Path(__file__).parent
repo_tabular_concepts_dir = script_dir / 'Tabular Concepts'
legacy_tabular_concepts_dir = script_dir.parent.parent / 'Tabular Concepts'
tabular_concepts_dir = (
    repo_tabular_concepts_dir if repo_tabular_concepts_dir.exists() else legacy_tabular_concepts_dir
)
sys.path.insert(0, str(tabular_concepts_dir))

try:
    from neuralsmith_tabular_cli import TabularDataAnalyzer
except ImportError as e:
    print(f"ERROR: Failed to import TabularDataAnalyzer: {e}", file=sys.stderr)
    print(f"Looking in: {tabular_concepts_dir}", file=sys.stderr)
    sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description='Train ML models on tabular CSV data')
    parser.add_argument('train_csv', help='Path to train CSV file')
    parser.add_argument('--target', help='Target column name (default: auto-detect)')
    parser.add_argument('--task', choices=['classification', 'regression'], help='Task type (default: auto-detect)')
    parser.add_argument('--output', required=True, help='Output directory for models')
    parser.add_argument('--downsample', action='store_true', help='Downsample to 100k rows')
    parser.add_argument('--no-stratify', action='store_true', help='Disable stratification for classification')
    parser.add_argument('--drop-columns', type=str, default='', help='Comma-separated list of columns to drop')
    parser.add_argument('--sample-eda', action='store_true', help='Force sampling for EDA')
    parser.add_argument(
        '--no-eda',
        action='store_true',
        help='Skip automated EDA (no feature drops / outlier caps from EDA insights; preprocessing uses defaults)',
    )
    
    # Split configuration
    parser.add_argument('--train-percent', type=float, default=80.0, help='Percentage of data for training (default: 80.0)')
    parser.add_argument('--val-percent', type=float, default=0.0, help='Percentage of data for validation (default: 0.0)')
    parser.add_argument('--test-percent', type=float, default=20.0, help='Percentage of data for testing (default: 20.0)')
    parser.add_argument('--random-state', type=int, default=42, help='Random state for data splitting (default: 42)')
    
    # Mode selection (mutually exclusive)
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument('--fastpp', action='store_true', help='Fast++ mode: only LightGBM')
    mode_group.add_argument('--fast', action='store_true', help='Fast mode: LightGBM + 2 others')
    mode_group.add_argument('--exhaustive', action='store_true', help='Exhaustive mode: all models (default)')
    
    args = parser.parse_args()
    
    csv_path = Path(args.train_csv)
    if not csv_path.exists():
        print(f"ERROR: CSV file not found: {csv_path}", file=sys.stderr)
        sys.exit(1)
    
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Determine mode
    if args.fastpp:
        mode = 'fast++'
    elif args.fast:
        mode = 'fast'
    else:
        mode = 'exhaustive'
    
    print(f"Training mode: {mode}")
    print(f"Loading data from {csv_path}...")
    
    analyzer = TabularDataAnalyzer(random_search_iters=5)
    
    if not analyzer.load_data(str(csv_path), downsample=args.downsample, target_column=args.target):
        print(f"ERROR: Failed to load data from {csv_path}", file=sys.stderr)
        sys.exit(1)
    
    # Auto-detect task type if not specified
    is_classification = None
    if args.task:
        is_classification = args.task == 'classification'
    else:
        # Auto-detect based on target column
        target_col = args.target or analyzer.target_column
        if target_col:
            if target_col in analyzer.data.columns:
                if analyzer.data[target_col].dtype in ['object', 'category'] or analyzer.data[target_col].nunique() < 20:
                    is_classification = True
                    print("Auto-detected task: classification")
                else:
                    is_classification = False
                    print("Auto-detected task: regression")
    
    # Run EDA first (unless disabled — must match neuralsmith CLI --no-eda)
    eda_target = args.target or analyzer.target_column
    if args.no_eda:
        print("Skipping EDA (--no-eda).")
        eda_insights = None
    elif eda_target:
        print("Running EDA...")
        try:
            eda_insights = analyzer.perform_eda(
                target_column=eda_target,
                force_sample=args.sample_eda
            )
        except Exception as e:
            print(f"WARNING: EDA failed: {e}", file=sys.stderr)
            eda_insights = None
    else:
        eda_insights = None
    
    # Preprocess data
    print("Preprocessing data...")
    try:
        analyzer.preprocess_data(
            target_column=args.target,
            is_classification=is_classification,
            stratify=not args.no_stratify,
            drop_columns=args.drop_columns,
            eda_insights=eda_insights,
            train_percent=args.train_percent,
            val_percent=args.val_percent,
            test_percent=args.test_percent,
            random_state=args.random_state
        )
    except Exception as e:
        print(f"ERROR: Preprocessing failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # Train models
    print(f"Training models in {mode} mode...")
    try:
        analyzer.train_models(mode=mode)
    except Exception as e:
        print(f"ERROR: Training failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # Save best model
    print("Saving best model...")
    try:
        # Change to output directory for saving
        import os
        original_cwd = os.getcwd()
        os.chdir(str(output_dir))
        
        save_path = analyzer.save_best_model(output_dir='models')
        print(f"Best model saved to {save_path}")
        
        os.chdir(original_cwd)
        sys.exit(0)
        
    except Exception as e:
        print(f"ERROR: Failed to save model: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()


