"""
Comprehensive model summary report generator for NeuralSmith.

Generates detailed reports after training completes, including:
- All model performance metrics
- Best model identification
- Model usage code snippets
- Training statistics
"""

import json
import pandas as pd
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

from neuralsmith.output import report


def _tabular_float_cell(val: object) -> Optional[float]:
    """Parse numeric cells from comparison_table.csv; missing/NaN values become None."""
    if val in ("-", "", None):
        return None
    try:
        x = float(val)
    except (ValueError, TypeError):
        return None
    return None if pd.isna(x) else x


def _format_metric(val: object, *, decimals: int = 4, percent: bool = False) -> str:
    """Format numeric metric for markdown tables/details, using '-' for missing values."""
    if val is None:
        return "-"
    try:
        x = float(val)
    except (ValueError, TypeError):
        return "-"
    if pd.isna(x):
        return "-"
    if percent:
        return f"{x * 100:.{decimals}f}%"
    return f"{x:.{decimals}f}"


def _sort_metric(val: object, default: float = -1.0) -> float:
    """Sortable numeric value with safe fallback for missing cells."""
    if val is None:
        return default
    try:
        x = float(val)
    except (ValueError, TypeError):
        return default
    return default if pd.isna(x) else x


def generate_training_summary_report(
    output_dir: Path,
    task_type: str,
    results: Optional[Dict[str, Any]] = None,
    model_files: Optional[List[str]] = None,
) -> Path:
    """
    Generate a comprehensive training summary report.
    
    Args:
        output_dir: Directory where training outputs are stored
        task_type: Type of task ('image-classification', 'tabular-classification', etc.)
        results: Training results dictionary (if available)
        model_files: List of model file paths (if available)
        
    Returns:
        Path to the generated report file
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    report_path = output_dir / "training_summary_report.md"
    
    # Collect all model results
    all_results = []
    best_model = None
    best_score = None
    
    if task_type == "image-classification":
        all_results, best_model, best_score = _collect_image_results(output_dir, results)
    elif task_type in ["tabular-classification", "tabular-regression"]:
        all_results, best_model, best_score = _collect_tabular_results(output_dir)
    elif task_type in ["timeseries-classification", "timeseries-regression"]:
        all_results, best_model, best_score = _collect_timeseries_results(output_dir)
    
    # Generate markdown report
    report_content = _generate_markdown_report(
        task_type=task_type,
        output_dir=output_dir,
        all_results=all_results,
        best_model=best_model,
        best_score=best_score,
        timestamp=datetime.now().isoformat()
    )
    
    # Save report
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_content)
    
    # Also save JSON version for programmatic access
    json_report_path = output_dir / "training_summary_report.json"
    json_report = {
        "task_type": task_type,
        "timestamp": datetime.now().isoformat(),
        "output_dir": str(output_dir),
        "total_models": len(all_results),
        "best_model": best_model,
        "best_score": best_score,
        "all_results": all_results,
    }
    with open(json_report_path, 'w', encoding='utf-8') as f:
        json.dump(json_report, f, indent=2)
    
    report(f"\n{'='*80}")
    report("TRAINING SUMMARY REPORT GENERATED")
    report(f"{'='*80}")
    report(f"Report saved to: {report_path}")
    report(f"JSON report saved to: {json_report_path}")
    report(f"{'='*80}\n")
    
    return report_path


def _collect_image_results(output_dir: Path, results: Optional[Dict]) -> tuple:
    """Collect results from image classification training."""
    all_results = []
    best_model = None
    best_score = -1.0
    
    # Collect from results JSON files
    result_files = list(output_dir.glob("results_*.json"))
    
    for result_file in result_files:
        try:
            with open(result_file, 'r') as f:
                data = json.load(f)
                
            model_info = {
                "model_file": result_file.name.replace("results_", "model_").replace(".json", ".pth"),
                "result_file": result_file.name,
                "model_type": data.get("model_type", "unknown"),
                "test_accuracy": data.get("test_accuracy", 0.0),
                "test_f1_macro": data.get("test_f1_macro", 0.0),
                "total_params": data.get("total_params", 0),
                "epochs_trained": data.get("epochs_trained", 0),
                "training_time_seconds": data.get("training_time_seconds", 0.0),
            }
            
            if data.get("model_type") == "nas":
                model_info["architecture"] = data.get("architecture", [])
                model_info["operations"] = data.get("operations", [])
            else:
                model_info["model_name"] = data.get("model_name", "unknown")
            
            all_results.append(model_info)
            
            # Track best model
            acc = model_info["test_accuracy"]
            if acc > best_score:
                best_score = acc
                best_model = model_info
                
        except Exception as e:
            print(f"Warning: Could not parse {result_file}: {e}")
    
    # Sort by accuracy
    all_results.sort(key=lambda x: x.get("test_accuracy", 0.0), reverse=True)
    
    return all_results, best_model, best_score


def _collect_tabular_results(output_dir: Path) -> tuple:
    """Collect results from tabular training."""
    all_results = []
    best_model = None
    best_score = -1.0

    # Prefer comparison_table.csv as the canonical list of trained models (exhaustive mode).
    # metadata.json is merged in so paths / features appear once (avoids duplicate rows).
    best_model_dirs = sorted(output_dir.glob("models/best_model_*"))
    best_dir = best_model_dirs[-1] if best_model_dirs else None
    metadata = {}
    if best_dir:
        metadata_file = best_dir / "metadata.json"
        if metadata_file.exists():
            with open(metadata_file, "r", encoding="utf-8") as f:
                metadata = json.load(f)

    meta_enriched = {}
    if metadata:
        perf = metadata.get("performance", {}) or {}
        meta_enriched = {
            "model_dir": str(best_dir) if best_dir else "",
            "model_file": str(best_dir / "model.joblib") if best_dir else "",
            "model_name": metadata.get("model_name", "unknown"),
            "test_accuracy": perf.get("accuracy", 0.0),
            "test_f1_macro": perf.get("f1_macro", 0.0),
            "cv_mean": perf.get("cv_mean", 0.0),
            "target_column": metadata.get("target_column", ""),
            "feature_names": metadata.get("feature_names", []),
        }

    comparison_files = list(output_dir.glob("models/best_model_*/comparison_table.csv"))
    if comparison_files:
        try:
            df = pd.read_csv(comparison_files[0])
            for _, row in df.iterrows():
                name = row.get("model", "unknown")
                entry = {
                    "model_name": name,
                    "test_accuracy": _tabular_float_cell(row.get("accuracy")),
                    "test_f1_macro": _tabular_float_cell(row.get("f1_macro")),
                    "cv_mean": _tabular_float_cell(row.get("cv_mean")),
                }
                # Attach artifact paths only for the saved best model (names should match).
                if meta_enriched and name == meta_enriched.get("model_name"):
                    merged = {**meta_enriched, **entry}
                    all_results.append(merged)
                else:
                    all_results.append(entry)
        except Exception:
            all_results = []

    if not all_results and meta_enriched:
        all_results = [meta_enriched]

    all_results.sort(key=lambda x: _sort_metric(x.get("test_accuracy")), reverse=True)

    if all_results:
        best_model = all_results[0]
        best_score = best_model.get("test_accuracy", 0.0)

    return all_results, best_model, best_score


def _collect_timeseries_results(output_dir: Path) -> tuple:
    """Collect results from time series training."""
    all_results = []
    best_model = None
    best_score = None
    
    results_file = output_dir / "results.json"
    if results_file.exists():
        with open(results_file, 'r') as f:
            data = json.load(f)
            
        all_results = data.get("results", [])
        best_model = data.get("best_model", {})
        if "val_accuracy" in best_model:
            best_score = best_model.get("val_accuracy")
        elif "val_mse" in best_model:
            best_score = best_model.get("val_mse")
        else:
            best_score = best_model.get("test_accuracy", best_model.get("test_mse", 0.0))
    
    return all_results, best_model, best_score


def _generate_markdown_report(
    task_type: str,
    output_dir: Path,
    all_results: List[Dict],
    best_model: Optional[Dict],
    best_score: Optional[float],
    timestamp: str,
) -> str:
    """Generate markdown report content."""
    
    lines = []
    lines.append("# NeuralSmith Training Summary Report")
    lines.append("")
    lines.append(f"**Generated:** {timestamp}")
    lines.append(f"**Task Type:** {task_type}")
    lines.append(f"**Output Directory:** `{output_dir}`")
    lines.append("")
    lines.append("---")
    lines.append("")
    
    # Executive Summary
    lines.append("## Executive Summary")
    lines.append("")
    lines.append(f"- **Total Models Trained:** {len(all_results)}")
    if best_model:
        lines.append(
            f"- **Best Model:** {best_model.get('model', best_model.get('model_name', best_model.get('model_file', 'Unknown')))}"
        )
        if best_score is not None:
            if task_type in ["tabular-regression", "timeseries-regression"]:
                metric_label = "Best Validation MSE" if best_model and "val_mse" in best_model else "Best Test MSE"
                lines.append(f"- **{metric_label}:** {best_score:.4f}")
            else:
                metric_label = "Best Validation Accuracy" if best_model and "val_accuracy" in best_model else "Best Test Accuracy"
                lines.append(f"- **{metric_label}:** {best_score:.4f}")
    lines.append("")
    
    # Model Comparison Table
    if all_results:
        lines.append("## Model Performance Comparison")
        lines.append("")
        
        if task_type == "image-classification":
            lines.append("| Rank | Model Type | Architecture | Test Accuracy | F1 Macro | Params | Training Time |")
            lines.append("|------|------------|-------------|---------------|----------|--------|---------------|")
            
            for idx, result in enumerate(all_results[:10], 1):  # Top 10
                model_type = result.get("model_type", "unknown")
                if model_type == "nas":
                    arch = str(result.get("architecture", []))[:30]
                else:
                    arch = result.get("model_name", "N/A")
                
                acc = result.get("test_accuracy", 0.0) * 100
                f1 = result.get("test_f1_macro", 0.0)
                params = result.get("total_params", 0)
                time_sec = result.get("training_time_seconds", 0.0)
                
                lines.append(f"| {idx} | {model_type} | {arch} | {acc:.2f}% | {f1:.4f} | {params:,} | {time_sec:.1f}s |")
        
        elif task_type in ["tabular-classification", "tabular-regression"]:
            lines.append("| Rank | Model Name | Test Accuracy | F1 Macro | CV Mean |")
            lines.append("|------|------------|---------------|----------|---------|")
            
            for idx, result in enumerate(all_results[:10], 1):
                name = result.get("model_name", "unknown")
                acc = _format_metric(result.get("test_accuracy"), decimals=2, percent=True)
                f1 = _format_metric(result.get("test_f1_macro"), decimals=4)
                cv = _format_metric(result.get("cv_mean"), decimals=4)

                lines.append(f"| {idx} | {name} | {acc} | {f1} | {cv} |")
        elif task_type in ["timeseries-classification", "timeseries-regression"]:
            if task_type == "timeseries-classification":
                lines.append("| Rank | Model Name | Val Accuracy | Test Accuracy | Test Loss | Time (s) |")
                lines.append("|------|------------|--------------|---------------|-----------|----------|")
                ranked = sorted(all_results, key=lambda x: x.get("val_accuracy", -1.0), reverse=True)
                for idx, result in enumerate(ranked[:10], 1):
                    lines.append(
                        f"| {idx} | {result.get('model', 'unknown')} | "
                        f"{result.get('val_accuracy', 0.0):.4f} | {result.get('test_accuracy', 0.0):.4f} | "
                        f"{result.get('test_loss', 0.0):.4f} | {result.get('train_time_sec', 0.0):.2f} |"
                    )
            else:
                lines.append("| Rank | Model Name | Val MSE | Test MSE | Test Loss | Time (s) |")
                lines.append("|------|------------|---------|----------|-----------|----------|")
                ranked = sorted(all_results, key=lambda x: x.get("val_mse", float("inf")))
                for idx, result in enumerate(ranked[:10], 1):
                    lines.append(
                        f"| {idx} | {result.get('model', 'unknown')} | "
                        f"{result.get('val_mse', 0.0):.4f} | {result.get('test_mse', 0.0):.4f} | "
                        f"{result.get('test_loss', 0.0):.4f} | {result.get('train_time_sec', 0.0):.2f} |"
                    )
        
        lines.append("")
    
    # Best Model Details
    if best_model:
        lines.append("## Best Model Details")
        lines.append("")
        
        if task_type == "image-classification":
            lines.append(f"- **Model File:** `{best_model.get('model_file', 'N/A')}`")
            lines.append(f"- **Model Type:** {best_model.get('model_type', 'unknown')}")
            if best_model.get("architecture"):
                lines.append(f"- **Architecture:** {best_model.get('architecture')}")
            if best_model.get("model_name"):
                lines.append(f"- **Model Name:** {best_model.get('model_name')}")
            lines.append(f"- **Test Accuracy:** {best_model.get('test_accuracy', 0.0) * 100:.2f}%")
            lines.append(f"- **Test F1 (Macro):** {best_model.get('test_f1_macro', 0.0):.4f}")
            lines.append(f"- **Total Parameters:** {best_model.get('total_params', 0):,}")
            lines.append(f"- **Training Time:** {best_model.get('training_time_seconds', 0.0):.1f} seconds")
        
        elif task_type in ["tabular-classification", "tabular-regression"]:
            lines.append(f"- **Model Directory:** `{best_model.get('model_dir', 'N/A')}`")
            lines.append(f"- **Model File:** `{best_model.get('model_file', 'N/A')}`")
            lines.append(f"- **Model Name:** {best_model.get('model_name', 'unknown')}")
            lines.append(f"- **Target Column:** {best_model.get('target_column', 'N/A')}")
            lines.append(f"- **Features Used:** {', '.join(best_model.get('feature_names', []))}")
            lines.append(f"- **Test Accuracy:** {_format_metric(best_model.get('test_accuracy'), decimals=2, percent=True)}")
            lines.append(f"- **Test F1 (Macro):** {_format_metric(best_model.get('test_f1_macro'), decimals=4)}")
            lines.append(f"- **CV Mean:** {_format_metric(best_model.get('cv_mean'), decimals=4)}")
        elif task_type in ["timeseries-classification", "timeseries-regression"]:
            lines.append(f"- **Model Name:** {best_model.get('model', 'unknown')}")
            if task_type == "timeseries-classification":
                lines.append(f"- **Validation Accuracy:** {best_model.get('val_accuracy', 0.0):.4f}")
                lines.append(f"- **Test Accuracy:** {best_model.get('test_accuracy', 0.0):.4f}")
            else:
                lines.append(f"- **Validation MSE:** {best_model.get('val_mse', 0.0):.4f}")
                lines.append(f"- **Test MSE:** {best_model.get('test_mse', 0.0):.4f}")
            lines.append(f"- **Test Loss:** {best_model.get('test_loss', 0.0):.4f}")
            lines.append(f"- **Training Time:** {best_model.get('train_time_sec', 0.0):.2f} seconds")
        
        lines.append("")
    
    # Model Usage Instructions
    lines.append("## Using Your Trained Model")
    lines.append("")
    lines.append("### Quick Start")
    lines.append("")
    lines.append("You can load and use your trained model with NeuralSmith utilities:")
    lines.append("")
    lines.append("```python")
    
    if task_type == "image-classification":
        lines.append("from neuralsmith import load_model")
        lines.append("import numpy as np")
        lines.append("from PIL import Image")
        lines.append("")
        lines.append("# Load the model")
        if best_model:
            model_path = output_dir / best_model.get("model_file", "")
            lines.append(f"model = load_model('{model_path}')")
        else:
            lines.append(f"model = load_model('{output_dir}/model_*.pth')")
        lines.append("")
        lines.append("# Preprocess an image")
        lines.append("image = Image.open('your_image.jpg')")
        lines.append("image = image.resize((64, 64))  # Match your training size")
        lines.append("img_array = np.array(image).astype(np.float32) / 255.0")
        lines.append("img_array = np.transpose(img_array, (2, 0, 1))  # HWC -> CHW")
        lines.append("img_tensor = torch.FloatTensor(img_array).unsqueeze(0)")
        lines.append("")
        lines.append("# Make prediction")
        lines.append("model.eval()")
        lines.append("with torch.no_grad():")
        lines.append("    prediction = model(img_tensor)")
        lines.append("    predicted_class = torch.argmax(prediction, dim=1).item()")
        lines.append("    probabilities = torch.softmax(prediction, dim=1)[0]")
        lines.append("")
        lines.append("print(f'Predicted class: {predicted_class}')")
        lines.append("print(f'Probabilities: {probabilities.numpy()}')")
    
    elif task_type in ["tabular-classification", "tabular-regression"]:
        lines.append("from neuralsmith import load_model, preprocess_data")
        lines.append("import pandas as pd")
        lines.append("")
        lines.append("# Load the model and preprocessing pipeline")
        if best_model:
            model_dir = best_model.get("model_dir", str(output_dir / "models" / "best_model_*"))
            lines.append(f"model, preprocessor = load_model('{model_dir}')")
        else:
            lines.append(f"model, preprocessor = load_model('{output_dir}/models/best_model_*/')")
        lines.append("")
        lines.append("# Load your new data")
        lines.append("new_data = pd.read_csv('new_data.csv')")
        lines.append("")
        lines.append("# Preprocess using the same pipeline")
        lines.append("X_processed = preprocessor.transform(new_data)")
        lines.append("")
        lines.append("# Make predictions")
        lines.append("predictions = model.predict(X_processed)")
        lines.append("")
        lines.append("# For classification, get probabilities")
        lines.append("if hasattr(model, 'predict_proba'):")
        lines.append("    probabilities = model.predict_proba(X_processed)")
        lines.append("")
        lines.append("print(f'Predictions: {predictions}')")
    
    lines.append("```")
    lines.append("")
    lines.append("### Ask CoPilot for Help")
    lines.append("")
    lines.append("You can also ask NeuralSmith CoPilot for customized code:")
    lines.append("")
    lines.append("```bash")
    lines.append("neuralsmith copilot")
    lines.append("")
    lines.append("# Then ask:")
    lines.append("# > How do I use the model I just trained?")
    lines.append("# > Generate code to load my model from {output_dir}")
    lines.append("# > Show me how to make predictions on new images")
    lines.append("```")
    lines.append("")
    
    lines.append("---")
    lines.append("")
    lines.append(f"*Report generated by NeuralSmith CLI*")
    
    return "\n".join(lines)
