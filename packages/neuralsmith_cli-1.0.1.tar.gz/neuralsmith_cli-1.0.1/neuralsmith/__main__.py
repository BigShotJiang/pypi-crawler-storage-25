"""
Module entry point for ``python -m neuralsmith`` when run inside ``CLI/``.
"""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())

