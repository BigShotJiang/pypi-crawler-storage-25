"""Weighted KNN for auto-labeling."""

import numpy as np
from sklearn.neighbors import NearestNeighbors
from typing import Optional


def weighted_knn_label(
    features: np.ndarray,
    labels: np.ndarray,
    mask: np.ndarray,
    k: int = 5,
    min_confidence: float = 0.5,
    exclude_low_confidence: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Label unlabeled samples using weighted KNN.
    
    Args:
        features: Feature matrix (n_samples, n_features)
        labels: Labels for all samples (n_samples,); -1 for unlabeled
        mask: Boolean mask indicating labeled samples (n_samples,)
        k: Number of neighbors
        min_confidence: Minimum confidence threshold
        exclude_low_confidence: Exclude predictions below min_confidence
        
    Returns:
        Tuple of (predicted_labels, confidences)
    """
    labeled_features = features[mask]
    labeled_labels = labels[mask]
    unlabeled_mask = ~mask
    
    if len(labeled_features) == 0:
        raise ValueError("No labeled samples found")
    
    if len(labeled_features) < k:
        k = len(labeled_features)
    
    # Fit KNN on labeled data
    knn = NearestNeighbors(n_neighbors=k, metric="euclidean")
    knn.fit(labeled_features)
    
    # Find neighbors for unlabeled samples
    unlabeled_features = features[unlabeled_mask]
    if len(unlabeled_features) == 0:
        # All samples are already labeled
        return labels.copy(), np.ones(len(labels))
    
    distances, indices = knn.kneighbors(unlabeled_features)
    
    # Compute weighted labels
    predicted_labels = labels.copy()
    confidences = np.zeros(len(labels))
    
    for i, (dist_row, idx_row) in enumerate(zip(distances, indices)):
        # Avoid division by zero
        dist_row = np.maximum(dist_row, 1e-10)
        weights = 1.0 / dist_row
        weights = weights / weights.sum()
        
        # Weighted voting
        neighbor_labels = labeled_labels[idx_row]
        unique_labels = np.unique(neighbor_labels)
        
        label_scores = {}
        for label in unique_labels:
            score = weights[neighbor_labels == label].sum()
            label_scores[label] = score
        
        # Get best label and confidence
        best_label = max(label_scores, key=label_scores.get)
        confidence = label_scores[best_label]
        
        # Map back to original index
        unlabeled_idx = np.where(unlabeled_mask)[0][i]
        predicted_labels[unlabeled_idx] = best_label
        confidences[unlabeled_idx] = confidence
    
    # Set confidences for already-labeled samples
    confidences[mask] = 1.0
    
    # Filter low confidence if requested
    if exclude_low_confidence:
        low_conf_mask = confidences < min_confidence
        predicted_labels[low_conf_mask] = -1
    
    return predicted_labels, confidences
