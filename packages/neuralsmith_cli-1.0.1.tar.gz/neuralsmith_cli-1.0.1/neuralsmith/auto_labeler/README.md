# Auto Labeler

This module runs the `neuralsmith auto-labeler` workflow to infer missing labels with weighted KNN.

## What It Does

- Extracts features for image, tabular, or time-series inputs.
- Uses existing labeled rows/samples as references.
- Predicts labels for unlabeled samples.
- Writes confidence scores and prediction provenance to output CSV.

## Command

```bash
neuralsmith auto-labeler \
  --data-path <path> \
  --data-type image|tabular|timeseries \
  --labeled-column <name> \
  --label-column <name> \
  --output-path <output.csv> \
  [--k 5] \
  [--min-confidence 0.5] \
  [--exclude-low-confidence] \
  [--image-model mobilenet_v2|resnet18] \
  [--tabular-reducer pca|umap|incremental_pca] \
  [--timeseries-use-minirocket]
```

## Parameters

- `--data-path` (required): source data path.
- `--data-type` (required): `image`, `tabular`, or `timeseries`.
- `--labeled-column` (required): boolean/indicator column for known labels.
- `--label-column` (required): target label column name.
- `--output-path` (required): destination CSV.
- `--k`: number of neighbors. Default `5`.
- `--min-confidence`: confidence threshold for accepted predictions. Default `0.5`.
- `--exclude-low-confidence`: omit predictions below threshold.
- `--image-model`: image embedding backbone.
- `--tabular-reducer`: dimensionality reduction for tabular features.
- `--timeseries-use-minirocket`: use MiniRocket features for time-series.

## Output Columns

The output CSV contains:

- updated `label_column` with original + predicted values,
- `<label_column>_confidence`,
- `<label_column>_predicted` (True where labels were inferred).

## Workflow

1. Load/scan data.
2. Extract features according to data type.
3. Run weighted KNN over labeled subset.
4. Assign predicted labels to unlabeled samples.
5. Save enriched CSV and run-status artifacts.

## Example

```bash
neuralsmith auto-labeler \
  --data-path ./partial_labels.csv \
  --data-type tabular \
  --labeled-column is_labeled \
  --label-column species \
  --output-path ./labeled_output.csv \
  --k 7 \
  --min-confidence 0.6
```

## Notes

- Ensure enough labeled examples exist for each class.
- Higher `--min-confidence` improves precision but may reduce coverage.
- For image inputs, expected behavior is one record per discovered image file.
