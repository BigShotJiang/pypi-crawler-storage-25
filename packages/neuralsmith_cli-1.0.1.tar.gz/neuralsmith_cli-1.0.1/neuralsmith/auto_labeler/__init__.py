"""Auto-labeler wizard: automatically label unlabeled data using weighted KNN."""

from .feature_extractors import extract_features
from .weighted_knn import weighted_knn_label
from .cli_wrapper import run_auto_labeler

__all__ = ["extract_features", "weighted_knn_label", "run_auto_labeler"]
