"""CLI wrapper for auto-labeler."""

import sys

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Optional

from neuralsmith.output import step

from .feature_extractors import extract_features
from .weighted_knn import weighted_knn_label


def run_auto_labeler(
    data_path: str,
    data_type: str,
    labeled_column: str,
    label_column: str,
    output_path: str,
    k: int = 5,
    min_confidence: float = 0.5,
    exclude_low_confidence: bool = False,
    image_model: str = "mobilenet_v2",
    tabular_reducer: str = "pca",
    timeseries_use_minirocket: bool = False,
) -> bool:
    """
    Run auto-labeler pipeline.
    
    Args:
        data_path: Path to data file/folder
        data_type: 'image', 'tabular', or 'timeseries'
        labeled_column: Column indicating if sample is labeled
        label_column: Column with labels (for labeled samples)
        output_path: Output CSV path
        k: Number of neighbors
        min_confidence: Minimum confidence threshold
        exclude_low_confidence: Exclude low-confidence predictions
        image_model: Model for image features
        tabular_reducer: Dimensionality reduction method
        timeseries_use_minirocket: Use MiniRocket for time series
        
    Returns:
        True if successful, False otherwise
    """
    try:
        step("Loading data...")
        # Extract features
        step("Extracting features...")
        features, labels_raw, mask = extract_features(
            data_path=data_path,
            data_type=data_type,
            labeled_column=labeled_column,
            image_model=image_model,
            tabular_reducer=tabular_reducer,
            timeseries_use_minirocket=timeseries_use_minirocket,
        )
        
        # Load original data to preserve structure
        if data_type in ["tabular", "timeseries"]:
            df = pd.read_csv(data_path)
        else:
            # For images, create a simple DataFrame
            data_path_obj = Path(data_path)
            if data_path_obj.is_file():
                image_files = [data_path_obj]
            else:
                image_files = list(data_path_obj.glob("*.jpg")) + \
                             list(data_path_obj.glob("*.png")) + \
                             list(data_path_obj.glob("*.jpeg"))
            df = pd.DataFrame({"image_path": [str(f) for f in image_files]})
        
        step("Running weighted KNN...")
        predicted_labels, confidences = weighted_knn_label(
            features=features,
            labels=labels_raw,
            mask=mask,
            k=k,
            min_confidence=min_confidence,
            exclude_low_confidence=exclude_low_confidence,
        )
        
        # Update DataFrame with predictions
        df[label_column] = predicted_labels
        df[f"{label_column}_confidence"] = confidences
        df[f"{label_column}_predicted"] = ~mask  # Mark which were predicted
        
        step("Writing output...")
        output_path_obj = Path(output_path)
        output_path_obj.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path_obj, index=False)
        
        step(f"Auto-labeling complete. Output saved to {output_path}")
        step(f"Labeled {np.sum(~mask)} samples with confidence >= {min_confidence}")
        
        return True
        
    except Exception as e:
        print(f"ERROR: Auto-labeling failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return False
