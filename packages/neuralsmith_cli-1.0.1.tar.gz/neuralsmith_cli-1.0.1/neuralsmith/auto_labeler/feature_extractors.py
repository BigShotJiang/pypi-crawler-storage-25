"""Feature extractors for different data types."""

import numpy as np
import pandas as pd
from pathlib import Path
from typing import Union, Optional
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.decomposition import IncrementalPCA


def extract_features(
    data_path: str,
    data_type: str,
    labeled_column: Optional[str] = None,
    image_model: str = "mobilenet_v2",
    tabular_reducer: str = "pca",
    timeseries_use_minirocket: bool = False,
) -> tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """
    Extract features from data based on type.
    
    Args:
        data_path: Path to data (CSV or image folder)
        data_type: 'image', 'tabular', or 'timeseries'
        labeled_column: Column name indicating if sample is labeled (for CSV)
        image_model: Model to use for image features ('mobilenet_v2' or 'resnet18')
        tabular_reducer: Dimensionality reduction method ('pca', 'umap', 'incremental_pca')
        timeseries_use_minirocket: Use MiniRocket features for time series
        
    Returns:
        Tuple of (features, labels, mask) where:
        - features: Feature matrix (n_samples, n_features)
        - labels: Labels for labeled samples (n_labeled,)
        - mask: Boolean mask indicating which samples are labeled (n_samples,)
    """
    if data_type == "image":
        return _extract_image_features(data_path, image_model)
    elif data_type == "tabular":
        return _extract_tabular_features(data_path, labeled_column, tabular_reducer)
    elif data_type == "timeseries":
        return _extract_timeseries_features(data_path, labeled_column, timeseries_use_minirocket)
    else:
        raise ValueError(f"Unknown data type: {data_type}")


def _extract_image_features(data_path: str, model_name: str = "mobilenet_v2") -> tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """Extract features from images using a pretrained CNN."""
    try:
        import torch
        import torchvision.models as models
        import torchvision.transforms as transforms
        from PIL import Image
    except ImportError:
        raise ImportError("torch and torchvision are required for image feature extraction")
    
    # Load pretrained model
    if model_name == "mobilenet_v2":
        model = models.mobilenet_v2(pretrained=True)
        model.classifier = torch.nn.Identity()  # Remove classifier
    elif model_name == "resnet18":
        model = models.resnet18(pretrained=True)
        model.fc = torch.nn.Identity()  # Remove classifier
    else:
        raise ValueError(f"Unknown image model: {model_name}")
    
    model.eval()
    
    # Image preprocessing
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    
    # Load images
    data_path_obj = Path(data_path)
    if data_path_obj.is_file():
        # Single image
        image_files = [data_path_obj]
    else:
        # Directory of images
        image_files = list(data_path_obj.glob("*.jpg")) + list(data_path_obj.glob("*.png")) + \
                     list(data_path_obj.glob("*.jpeg"))
    
    features_list = []
    labels_list = []
    mask_list = []
    
    for img_file in image_files:
        try:
            img = Image.open(img_file).convert("RGB")
            img_tensor = transform(img).unsqueeze(0)
            
            with torch.no_grad():
                feat = model(img_tensor).squeeze().numpy()
            
            features_list.append(feat)
            # For now, assume all images are unlabeled (mask=False)
            # In real usage, this would come from metadata
            mask_list.append(False)
            labels_list.append(-1)  # Placeholder
        except Exception as e:
            print(f"Warning: Failed to process {img_file}: {e}")
            continue
    
    if not features_list:
        raise ValueError("No images could be processed")
    
    features = np.array(features_list)
    labels = np.array(labels_list)
    mask = np.array(mask_list)
    
    return features, labels, mask


def _extract_tabular_features(
    data_path: str,
    labeled_column: Optional[str],
    reducer: str = "pca",
) -> tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """Extract features from tabular CSV data."""
    df = pd.read_csv(data_path)
    
    if labeled_column is None:
        raise ValueError("labeled_column is required for tabular data")
    
    # Separate features and labels
    feature_cols = [c for c in df.columns if c != labeled_column]
    X = df[feature_cols].values.astype(np.float32)
    
    # Handle missing values
    X = np.nan_to_num(X, nan=0.0)
    
    # Standardize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Dimensionality reduction
    if reducer == "pca":
        reducer_obj = PCA(n_components=min(50, X_scaled.shape[1]))
        X_reduced = reducer_obj.fit_transform(X_scaled)
    elif reducer == "incremental_pca":
        reducer_obj = IncrementalPCA(n_components=min(50, X_scaled.shape[1]))
        X_reduced = reducer_obj.fit_transform(X_scaled)
    elif reducer == "umap":
        try:
            import umap
        except ImportError:
            raise ImportError("umap-learn is required for UMAP reduction")
        reducer_obj = umap.UMAP(n_components=min(50, X_scaled.shape[1]))
        X_reduced = reducer_obj.fit_transform(X_scaled)
    else:
        raise ValueError(f"Unknown reducer: {reducer}")
    
    # Get labels and mask
    if labeled_column in df.columns:
        labeled_col = df[labeled_column]
        
        # Check if labeled_column is boolean type (flag column)
        if labeled_col.dtype == bool:
            # For boolean columns, True means labeled
            mask = labeled_col == True
            # Try to find a 'label' column for actual label values
            if 'label' in df.columns:
                labels = df['label'].values.copy()
                labels[~mask] = -1  # Placeholder for unlabeled
            else:
                # If no 'label' column, use the boolean values as labels (0/1)
                labels = labeled_col.astype(int).values
                labels[~mask] = -1
        else:
            # For non-boolean columns, use notna() to detect labeled samples
            # This handles cases where NaN means unlabeled
            mask = labeled_col.notna()
            labels = labeled_col.values.copy()
            labels[~mask] = -1  # Placeholder for unlabeled
    else:
        mask = np.zeros(len(df), dtype=bool)
        labels = np.full(len(df), -1)
    
    return X_reduced, labels, mask


def _extract_timeseries_features(
    data_path: str,
    labeled_column: Optional[str],
    use_minirocket: bool = False,
) -> tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """Extract features from time series CSV data."""
    df = pd.read_csv(data_path)
    
    if labeled_column is None:
        raise ValueError("labeled_column is required for timeseries data")
    
    # For now, use simple statistical features
    # In production, would use MiniRocket or other time series feature extractors
    feature_cols = [c for c in df.columns if c != labeled_column]
    
    features_list = []
    for col in feature_cols:
        series = df[col].values
        features_list.extend([
            np.mean(series),
            np.std(series),
            np.min(series),
            np.max(series),
            np.median(series),
        ])
    
    features = np.array(features_list).reshape(1, -1)
    
    # Get labels and mask
    if labeled_column in df.columns:
        mask = df[labeled_column].notna()
        labels = df[labeled_column].values
        labels[~mask] = -1
    else:
        mask = np.zeros(len(df), dtype=bool)
        labels = np.full(len(df), -1)
    
    return features, labels, mask
