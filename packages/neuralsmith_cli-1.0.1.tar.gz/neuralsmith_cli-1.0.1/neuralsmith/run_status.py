"""
Shared run status for NeuralSmith CLI — written by training commands and read by CoPilot.

Uses atomic JSON snapshot writes plus optional append-only event log for watch-mode diffs.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

STATUS_FILENAME = "neuralsmith_run_status.json"
EVENTS_FILENAME = "neuralsmith_run_events.jsonl"


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def status_path(output_dir: Path) -> Path:
    return Path(output_dir).expanduser().resolve() / STATUS_FILENAME


def events_path(output_dir: Path) -> Path:
    return Path(output_dir).expanduser().resolve() / EVENTS_FILENAME


def _atomic_write_json(path: Path, data: Dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    payload = json.dumps(data, indent=2, ensure_ascii=False)
    tmp.write_text(payload, encoding="utf-8")
    tmp.replace(path)


def read_status(output_dir: Path) -> Optional[Dict[str, Any]]:
    """Load status snapshot, or None if missing/unreadable."""
    p = status_path(output_dir)
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def start_run(
    output_dir: Path,
    command: str,
    *,
    extra: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Create a new run status file in output_dir. Returns run_id.
    """
    output_dir = Path(output_dir).expanduser().resolve()
    run_id = str(uuid.uuid4())
    now = _utc_now_iso()
    data: Dict[str, Any] = {
        "run_id": run_id,
        "command": command,
        "phase": "starting",
        "state": "running",
        "started_at": now,
        "updated_at": now,
        "current_step": "",
        "last_message": "",
        "progress": None,
        "error": None,
    }
    if extra:
        for k, v in extra.items():
            if k not in data or v is not None:
                data[k] = v
    _atomic_write_json(status_path(output_dir), data)
    append_event(output_dir, {"ts": now, "type": "start", "command": command})
    return run_id


def update_run(output_dir: Path, **fields: Any) -> None:
    """Merge fields into the status snapshot and bump updated_at."""
    output_dir = Path(output_dir).expanduser().resolve()
    current = read_status(output_dir)
    if not current:
        current = {
            "run_id": str(uuid.uuid4()),
            "command": "unknown",
            "phase": "unknown",
            "state": "running",
            "started_at": _utc_now_iso(),
            "current_step": "",
            "last_message": "",
            "progress": None,
            "error": None,
        }
    current.update(fields)
    current["updated_at"] = _utc_now_iso()
    _atomic_write_json(status_path(output_dir), current)


def append_event(output_dir: Path, event: Dict[str, Any]) -> None:
    """Append one JSON line to the event log (best-effort)."""
    output_dir = Path(output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    ep = events_path(output_dir)
    line = json.dumps(event, ensure_ascii=False) + "\n"
    try:
        with ep.open("a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def finish_run(
    output_dir: Path,
    *,
    success: bool,
    error: Optional[str] = None,
    phase: str = "done",
) -> None:
    """Mark run completed or failed."""
    output_dir = Path(output_dir).expanduser().resolve()
    now = _utc_now_iso()
    update_run(
        output_dir,
        state="completed" if success else "failed",
        phase=phase if success else "error",
        error=error,
    )
    append_event(
        output_dir,
        {
            "ts": now,
            "type": "complete" if success else "failed",
            "success": success,
            "error": error,
        },
    )


def update_image_training_progress(
    output_dir: Path,
    *,
    line_prefix: str,
    payload: Dict[str, Any],
) -> None:
    """Update status from parsed BATCH_JSON / EPOCH_JSON lines (image training)."""
    output_dir = Path(output_dir).expanduser().resolve()
    if line_prefix == "EPOCH_JSON":
        msg = (
            f"Epoch {payload.get('epoch', '?')}: "
            f"train_acc={payload.get('train_accuracy', 0):.4f} "
            f"val_acc={payload.get('val_accuracy', 0):.4f}"
        )
        update_run(
            output_dir,
            phase="training",
            progress=payload,
            last_message=msg,
            current_step=msg,
        )
        append_event(output_dir, {"ts": _utc_now_iso(), "type": "epoch", "data": payload})
    elif line_prefix == "BATCH_JSON":
        # Throttle: only update snapshot every ~20 batches to reduce I/O
        batch = int(payload.get("batch", 0) or 0)
        if batch % 20 != 0 and batch != 1:
            return
        epoch = payload.get("epoch", "?")
        tb = payload.get("total_batches", "?")
        msg = f"Epoch {epoch}: batch {batch}/{tb}"
        update_run(
            output_dir,
            phase="training",
            progress=payload,
            last_message=msg,
            current_step=msg,
        )


def discover_status_files(root: Path, max_depth: int = 6) -> List[Path]:
    """
    Find neuralsmith_run_status.json under root up to max_depth directory levels.
    Returns paths sorted by file mtime (newest first).
    """
    root = Path(root).expanduser().resolve()
    if not root.is_dir():
        return []

    found: List[Path] = []
    # BFS with depth
    queue: List[tuple[Path, int]] = [(root, 0)]
    seen = set()
    while queue:
        d, depth = queue.pop(0)
        key = str(d.resolve())
        if key in seen:
            continue
        seen.add(key)

        sp = d / STATUS_FILENAME
        if sp.is_file():
            found.append(sp)

        if depth >= max_depth:
            continue
        try:
            for child in d.iterdir():
                if child.is_dir():
                    # Skip huge / hidden noise
                    name = child.name
                    if name.startswith(".") and name not in (".", ".."):
                        continue
                    if name in ("__pycache__", "node_modules", ".git"):
                        continue
                    queue.append((child, depth + 1))
        except OSError:
            continue

    found.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return found
