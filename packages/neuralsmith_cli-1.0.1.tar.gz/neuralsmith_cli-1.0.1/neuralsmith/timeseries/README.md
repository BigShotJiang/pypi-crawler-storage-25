# Time Series Models

This module powers:

- `neuralsmith timeseries-classification`
- `neuralsmith timeseries-regression`

It supports both CSV-based preprocessing and pre-windowed NumPy inputs.

## Supported Input Styles

1. CSV input:
   - Requires `--time-column` and `--window-size`.
   - Windows are generated before training.
2. Pre-windowed NumPy directory:
   - Uses `X_train.npy`, `y_train.npy`, `X_val.npy`, `y_val.npy`, `X_test.npy`, `y_test.npy`.
   - `--time-column` and `--window-size` are ignored.

## Commands

### Classification

```bash
neuralsmith timeseries-classification \
  --data-path <csv-or-numpy-dir> \
  --target-column <name> \
  [--time-column <name>] \
  [--window-size <n>] \
  [--output-dir <dir>] \
  [--mode fast++|fast|exhaustive] \
  [--split-method temporal|random] \
  [--train-percent 70.0] \
  [--val-percent 15.0] \
  [--test-percent 15.0] \
  [--random-state 42] \
  [--epochs 10] \
  [--batch-size 32] \
  [--no-normalize]
```

### Regression

```bash
neuralsmith timeseries-regression \
  --data-path <csv-or-numpy-dir> \
  --target-column <name> \
  [same options as classification]
```

## Key Parameters

- `--mode` controls model set size:
  - `fast++` (default): quickest run,
  - `fast`: moderate run,
  - `exhaustive`: broadest run.
- `--split-method`:
  - `temporal` (default): preserves chronology and helps avoid overlap leakage.
  - `random`: random window split.
- `--no-normalize`: disables train-fit normalization.
- `--epochs`, `--batch-size`: training controls for torch-based models.

## Model Selection Notes

Depending on environment support, the pipeline may train:

- MOMENT foundation-model variants,
- lightweight fallback neural models (for example, SimpleLSTM).

Final candidates depend on chosen mode and runtime availability.

## Outputs

Within `--output-dir`:

- trained model checkpoints/artifacts,
- preprocessing metadata and split artifacts (as applicable),
- run monitoring files:
  - `neuralsmith_run_status.json`
  - `neuralsmith_run_events.jsonl`
- summary reports:
  - `training_summary_report.md`
  - `training_summary_report.json`

## Example

```bash
neuralsmith timeseries-regression \
  --data-path ./series.csv \
  --time-column timestamp \
  --target-column y \
  --window-size 24 \
  --mode fast \
  --split-method temporal \
  --epochs 20 \
  --output-dir ./results_ts
```

## Practical Tips

- Prefer `temporal` splits for forecasting-like problems.
- Start with `fast++` for quick sanity checks, then scale to `fast` or `exhaustive`.
- Keep `window-size` aligned with sequence dynamics in your domain.
