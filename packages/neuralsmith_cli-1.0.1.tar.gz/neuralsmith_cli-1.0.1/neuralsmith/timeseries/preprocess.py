"""Time series preprocessing: windowing, splitting, and optional normalization."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

from neuralsmith.output import step, verbose


def _load_numpy_splits(data_dir: Path) -> Optional[Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
    required = ["X_train.npy", "y_train.npy", "X_val.npy", "y_val.npy", "X_test.npy", "y_test.npy"]
    if not all((data_dir / name).exists() for name in required):
        return None
    return (
        np.load(data_dir / "X_train.npy", allow_pickle=False),
        np.load(data_dir / "y_train.npy", allow_pickle=False),
        np.load(data_dir / "X_val.npy", allow_pickle=False),
        np.load(data_dir / "y_val.npy", allow_pickle=False),
        np.load(data_dir / "X_test.npy", allow_pickle=False),
        np.load(data_dir / "y_test.npy", allow_pickle=False),
    )


def _validate_split_percents(train_percent: float, val_percent: float, test_percent: float) -> None:
    total = train_percent + val_percent + test_percent
    if not np.isclose(total, 100.0):
        raise ValueError(f"train_percent + val_percent + test_percent must equal 100.0 (got {total:.4f})")
    if any(p < 0 for p in [train_percent, val_percent, test_percent]):
        raise ValueError("Split percentages must be non-negative")


def _apply_normalization(
    X_train: np.ndarray,
    X_val: np.ndarray,
    X_test: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, StandardScaler]:
    scaler = StandardScaler()
    n_train, seq_len, n_features = X_train.shape
    X_train_2d = X_train.reshape(n_train * seq_len, n_features)
    scaler.fit(X_train_2d)
    X_train = scaler.transform(X_train_2d).reshape(X_train.shape).astype(np.float32, copy=False)
    if len(X_val) > 0:
        X_val = scaler.transform(X_val.reshape(-1, n_features)).reshape(X_val.shape).astype(np.float32, copy=False)
    if len(X_test) > 0:
        X_test = scaler.transform(X_test.reshape(-1, n_features)).reshape(X_test.shape).astype(np.float32, copy=False)
    return X_train, X_val, X_test, scaler


def preprocess_timeseries(
    data_path: str,
    time_column: Optional[str],
    target_column: str,
    window_size: Optional[int],
    output_dir: str,
    train_percent: float = 70.0,
    val_percent: float = 15.0,
    test_percent: float = 15.0,
    random_state: int = 42,
    split_method: str = "temporal",
    normalize: bool = True,
    task: str = "classification",
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict]:
    """Preprocess time series from CSV or load pre-windowed NumPy splits."""
    step("Preprocessing time series...")
    _validate_split_percents(train_percent, val_percent, test_percent)
    if split_method not in {"temporal", "random"}:
        raise ValueError("split_method must be 'temporal' or 'random'")
    if task not in {"classification", "regression"}:
        raise ValueError("task must be 'classification' or 'regression'")

    input_path = Path(data_path).expanduser().resolve()
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    metadata: Dict = {
        "source": "csv",
        "split_method": split_method,
        "normalize": normalize,
        "task": task,
        "time_column": time_column,
        "target_column": target_column,
    }

    npy_splits = _load_numpy_splits(input_path) if input_path.is_dir() else None
    if npy_splits is not None:
        X_train, y_train, X_val, y_val, X_test, y_test = npy_splits
        if X_train.ndim != 3:
            raise ValueError("Expected X_train.npy to have shape (samples, window_size, features)")
        metadata.update(
            {
                "source": "numpy",
                "window_size": int(X_train.shape[1]),
                "n_features": int(X_train.shape[2]),
            }
        )
    else:
        if not input_path.exists() or not input_path.is_file():
            raise ValueError(
                "data_path must be a CSV file or a directory containing X_train/y_train/X_val/y_val/X_test/y_test npy files"
            )
        if not time_column:
            raise ValueError("time_column is required when data_path is a CSV file")
        if not window_size or window_size <= 0:
            raise ValueError("window_size must be a positive integer when data_path is a CSV file")

        df = pd.read_csv(input_path)
        if time_column not in df.columns:
            raise ValueError(f"Time column '{time_column}' not found in CSV")
        if target_column not in df.columns:
            raise ValueError(f"Target column '{target_column}' not found in CSV")

        # Parse datetime if possible, but fall back to original values when parsing is not meaningful.
        if not np.issubdtype(df[time_column].dtype, np.number):
            parsed = pd.to_datetime(df[time_column], errors="coerce")
            if parsed.notna().all():
                df[time_column] = parsed
            elif parsed.isna().all():
                raise ValueError(
                    f"Time column '{time_column}' is non-numeric and cannot be parsed as datetime."
                )
        if df[time_column].isna().any():
            raise ValueError(f"Time column '{time_column}' contains missing values")

        df = df.sort_values(by=time_column).reset_index(drop=True)
        if df[time_column].duplicated().any():
            raise ValueError(f"Time column '{time_column}' contains duplicate values; provide unique timestamps/order keys")

        feature_cols = [c for c in df.columns if c not in [time_column, target_column]]
        if not feature_cols:
            raise ValueError("No feature columns found (only time and target columns present)")

        X = df[feature_cols].values.astype(np.float32, copy=False)
        y = df[target_column].values

        X_windows = []
        y_windows = []
        for i in range(len(X) - window_size + 1):
            X_windows.append(X[i : i + window_size])
            y_windows.append(y[i + window_size - 1])
        X_windows = np.asarray(X_windows, dtype=np.float32)
        y_windows = np.asarray(y_windows)
        if len(X_windows) == 0:
            raise ValueError(f"Not enough data to create windows of size {window_size}")

        if task == "classification":
            label_encoder = LabelEncoder()
            y_windows = label_encoder.fit_transform(y_windows.astype(str))
            metadata["label_classes"] = label_encoder.classes_.tolist()
        else:
            y_windows = y_windows.astype(np.float32, copy=False)

        if split_method == "temporal":
            n = len(X_windows)
            train_end = int(n * train_percent / 100.0)
            val_end = train_end + int(n * val_percent / 100.0)
            if train_end <= 0 or (n - val_end) <= 0:
                raise ValueError("Split settings produce empty train or test set. Increase dataset size or adjust percentages.")
            X_train, y_train = X_windows[:train_end], y_windows[:train_end]
            X_val, y_val = X_windows[train_end:val_end], y_windows[train_end:val_end]
            X_test, y_test = X_windows[val_end:], y_windows[val_end:]
        else:
            stratify = y_windows if (task == "classification" and len(np.unique(y_windows)) > 1) else None
            train_size = train_percent / 100.0
            X_train, X_temp, y_train, y_temp = train_test_split(
                X_windows,
                y_windows,
                test_size=1.0 - train_size,
                random_state=random_state,
                shuffle=True,
                stratify=stratify,
            )
            if val_percent > 0 and test_percent > 0:
                val_size = val_percent / (val_percent + test_percent)
                stratify_temp = y_temp if (task == "classification" and len(np.unique(y_temp)) > 1) else None
                X_val, X_test, y_val, y_test = train_test_split(
                    X_temp,
                    y_temp,
                    test_size=1.0 - val_size,
                    random_state=random_state,
                    shuffle=True,
                    stratify=stratify_temp,
                )
            elif val_percent > 0:
                X_val, y_val = X_temp, y_temp
                X_test = np.array([]).reshape(0, *X_windows.shape[1:])
                y_test = np.array([])
            else:
                X_test, y_test = X_temp, y_temp
                X_val = np.array([]).reshape(0, *X_windows.shape[1:])
                y_val = np.array([])

        metadata.update(
            {
                "window_size": int(X_train.shape[1]),
                "n_features": int(X_train.shape[2]),
                "feature_columns": feature_cols,
            }
        )

    if task == "classification":
        y_train = y_train.astype(np.int64, copy=False)
        y_val = y_val.astype(np.int64, copy=False)
        y_test = y_test.astype(np.int64, copy=False)
    else:
        y_train = y_train.astype(np.float32, copy=False)
        y_val = y_val.astype(np.float32, copy=False)
        y_test = y_test.astype(np.float32, copy=False)

    if normalize:
        X_train, X_val, X_test, scaler = _apply_normalization(X_train, X_val, X_test)
        metadata["scaler"] = {
            "mean": scaler.mean_.tolist(),
            "scale": scaler.scale_.tolist(),
        }
    else:
        X_train = X_train.astype(np.float32, copy=False)
        X_val = X_val.astype(np.float32, copy=False)
        X_test = X_test.astype(np.float32, copy=False)

    np.save(output_path / "X_train.npy", X_train)
    np.save(output_path / "y_train.npy", y_train)
    np.save(output_path / "X_val.npy", X_val)
    np.save(output_path / "y_val.npy", y_val)
    np.save(output_path / "X_test.npy", X_test)
    np.save(output_path / "y_test.npy", y_test)
    with open(output_path / "preprocessing_metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    step("Preprocessing complete.")
    verbose(f"Input source: {metadata['source']}")
    verbose(f"Window shape: {X_train.shape[1:]}")
    verbose(f"Train: {len(X_train)}, Val: {len(X_val)}, Test: {len(X_test)}")
    return X_train, y_train, X_val, y_val, X_test, y_test, metadata
