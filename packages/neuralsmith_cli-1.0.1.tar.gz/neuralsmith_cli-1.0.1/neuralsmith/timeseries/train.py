"""Time series model training."""

from __future__ import annotations

import torch
import torch.nn as nn
import numpy as np
from pathlib import Path
from typing import Dict, Optional, List, Tuple
import json
from time import perf_counter

from neuralsmith.output import step


class SimpleLSTM(nn.Module):
    """Simple LSTM model for time series."""
    def __init__(self, input_size: int, hidden_size: int = 64, num_layers: int = 2, num_classes: int = 2):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, num_classes)
    
    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])  # Use last timestep
        return out


class SimpleCNN1D(nn.Module):
    """Simple 1D CNN for time series."""
    def __init__(self, input_size: int, num_classes: int = 2):
        super().__init__()
        self.conv1 = nn.Conv1d(input_size, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(64, num_classes)
    
    def forward(self, x):
        # x: (batch, seq_len, features) -> (batch, features, seq_len)
        x = x.transpose(1, 2)
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = self.pool(x).squeeze(-1)
        x = self.fc(x)
        return x


class MomentModel(nn.Module):
    """Thin wrapper around a MOMENT backbone used for both tasks."""

    def __init__(self, model_id: str, input_size: int, num_outputs: int, task: str = "classification"):
        super().__init__()
        from momentfm import MOMENTPipeline  # type: ignore

        self.model_id = model_id
        self.task = task
        model_kwargs = {
            "task_name": "classification" if task == "classification" else "forecasting",
            "n_channels": input_size,
            "num_class": num_outputs,
        }
        try:
            self.pipeline = MOMENTPipeline.from_pretrained(model_id, model_kwargs=model_kwargs)
        except Exception:  # pragma: no cover - depends on momentfm capabilities
            # Fallback to classification-style head with one output for regression.
            fallback_kwargs = {
                "task_name": "classification",
                "n_channels": input_size,
                "num_class": num_outputs,
            }
            self.pipeline = MOMENTPipeline.from_pretrained(model_id, model_kwargs=fallback_kwargs)
        self.pipeline.init()

        # Most MOMENT versions expose an nn.Module at .model.
        if hasattr(self.pipeline, "model") and isinstance(self.pipeline.model, nn.Module):
            self.model = self.pipeline.model
        elif isinstance(self.pipeline, nn.Module):
            self.model = self.pipeline
        else:
            raise RuntimeError(f"MOMENT pipeline from '{model_id}' does not expose a torch model.")

    def forward(self, x):
        # Input arrives as (batch, seq_len, features). MOMENT commonly expects (batch, channels, length).
        x_ch_first = x.transpose(1, 2)
        outputs = None
        last_error = None

        # Try common signature variants to support multiple momentfm versions.
        candidate_calls = [
            lambda: self.model(x_ch_first),
            lambda: self.model(x_enc=x_ch_first),
            lambda: self.model(inputs=x_ch_first),
        ]
        for call in candidate_calls:
            try:
                outputs = call()
                break
            except Exception as exc:  # pragma: no cover - depends on momentfm API variant
                last_error = exc

        if outputs is None:
            raise RuntimeError(
                f"Unable to run MOMENT model '{self.model_id}' forward pass."
            ) from last_error

        if isinstance(outputs, torch.Tensor):
            return outputs
        if isinstance(outputs, dict) and "logits" in outputs:
            return outputs["logits"]
        if hasattr(outputs, "logits"):
            return outputs.logits
        if isinstance(outputs, (tuple, list)) and len(outputs) > 0:
            first = outputs[0]
            if isinstance(first, torch.Tensor):
                return first
        raise RuntimeError(f"Unexpected MOMENT output type from '{self.model_id}': {type(outputs)}")


def _select_models(
    task: str,
    mode: str,
    input_size: int,
    num_classes: int,
) -> List[Tuple[str, nn.Module]]:
    """Select models based on mode with optional MOMENT support."""
    simple_fastpp = [("SimpleLSTM", SimpleLSTM(input_size, num_classes=num_classes))]
    simple_fast = [
        ("SimpleLSTM", SimpleLSTM(input_size, num_classes=num_classes)),
        ("SimpleCNN1D", SimpleCNN1D(input_size, num_classes=num_classes)),
    ]
    simple_exhaustive = [
        ("SimpleLSTM", SimpleLSTM(input_size, num_classes=num_classes)),
        ("SimpleCNN1D", SimpleCNN1D(input_size, num_classes=num_classes)),
        ("SimpleLSTM-Large", SimpleLSTM(input_size, hidden_size=128, num_classes=num_classes)),
        ("SimpleCNN1D-Large", SimpleCNN1D(input_size, num_classes=num_classes)),
    ]

    try:
        import momentfm  # noqa: F401

        step(f"Using MOMENT foundation models for time-series {task}.")
        if mode == "fast++":  # fastest
            moment_ids = ["AutonLab/MOMENT-1-small"]
            simple_models = []
        elif mode == "fast":
            moment_ids = ["AutonLab/MOMENT-1-small", "AutonLab/MOMENT-1-base"]
            simple_models = [("SimpleLSTM", SimpleLSTM(input_size, num_classes=num_classes))]
        else:  # exhaustive
            moment_ids = [
                "AutonLab/MOMENT-1-small",
                "AutonLab/MOMENT-1-base",
                "AutonLab/MOMENT-1-large",
            ]
            simple_models = simple_exhaustive
        moment_models = [(mid.split("/")[-1], MomentModel(mid, input_size, num_classes, task=task)) for mid in moment_ids]
        return moment_models + simple_models
    except ImportError:
        step("momentfm not installed; falling back to local PyTorch time-series baselines.")

    # Baseline fallback (also used for regression).
    if mode == "fast++":  # fastest fallback
        return simple_fastpp
    if mode == "fast":
        return simple_fast
    return simple_exhaustive


def _build_dataloaders(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    task: str,
    batch_size: int,
) -> Tuple[torch.utils.data.DataLoader, Optional[torch.utils.data.DataLoader], torch.utils.data.DataLoader]:
    from torch.utils.data import DataLoader, TensorDataset

    y_dtype = torch.long if task == "classification" else torch.float32
    train_ds = TensorDataset(torch.FloatTensor(X_train), torch.tensor(y_train, dtype=y_dtype))
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)

    val_loader: Optional[DataLoader] = None
    if len(X_val) > 0:
        val_ds = TensorDataset(torch.FloatTensor(X_val), torch.tensor(y_val, dtype=y_dtype))
        val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

    test_ds = TensorDataset(torch.FloatTensor(X_test), torch.tensor(y_test, dtype=y_dtype))
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)
    return train_loader, val_loader, test_loader


def _evaluate_model(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    task: str,
    criterion: nn.Module,
    device_obj: torch.device,
) -> Dict[str, float]:
    model.eval()
    total_loss = 0.0
    total_samples = 0
    preds = []
    targets = []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device_obj)
            yb = yb.to(device_obj)
            outputs = model(xb)
            if task == "regression":
                outputs = outputs.squeeze(-1) if outputs.dim() > 1 and outputs.shape[-1] == 1 else outputs
                yb = yb.float()
            loss = criterion(outputs, yb)
            batch_size = xb.shape[0]
            total_loss += loss.item() * batch_size
            total_samples += batch_size
            if task == "classification":
                preds.extend(torch.argmax(outputs, dim=1).cpu().tolist())
                targets.extend(yb.cpu().tolist())
            else:
                preds.extend(outputs.detach().cpu().numpy().tolist())
                targets.extend(yb.detach().cpu().numpy().tolist())

    avg_loss = total_loss / max(total_samples, 1)
    if task == "classification":
        preds_arr = np.asarray(preds, dtype=np.int64)
        targets_arr = np.asarray(targets, dtype=np.int64)
        accuracy = float((preds_arr == targets_arr).mean()) if len(targets_arr) else 0.0
        return {"loss": avg_loss, "accuracy": accuracy}

    preds_arr = np.asarray(preds, dtype=np.float32)
    targets_arr = np.asarray(targets, dtype=np.float32)
    mse = float(np.mean((preds_arr - targets_arr) ** 2)) if len(targets_arr) else 0.0
    return {"loss": avg_loss, "mse": mse}


def train_timeseries_models(
    data_path: str,
    time_column: Optional[str],
    target_column: str,
    window_size: Optional[int],
    output_dir: str,
    task: str = "classification",
    mode: str = "fast++",
    train_percent: float = 70.0,
    val_percent: float = 15.0,
    test_percent: float = 15.0,
    random_state: int = 42,
    split_method: str = "temporal",
    normalize: bool = True,
    epochs: int = 10,
    batch_size: int = 32,
    device: Optional[str] = None,
) -> Dict:
    """
    Train time series models.
    
    Args:
        data_path: Path to CSV file OR directory with split npy files
        time_column: Name of time column
        target_column: Name of target column
        window_size: Window size
        output_dir: Output directory
        task: 'classification' or 'regression'
        mode: 'fast++', 'fast', or 'exhaustive'
        train_percent: Training split percentage
        val_percent: Validation split percentage
        test_percent: Test split percentage
        random_state: Random seed
        split_method: 'temporal' or 'random'
        normalize: Whether to normalize features using train split stats
        epochs: Number of training epochs
        batch_size: Batch size
        device: Device ('cpu' or 'cuda')
        
    Returns:
        Dictionary with training results
    """
    from .preprocess import preprocess_timeseries
    
    # Set device
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    device_obj = torch.device(device)
    
    # Preprocess data
    X_train, y_train, X_val, y_val, X_test, y_test, preprocess_metadata = preprocess_timeseries(
        data_path=data_path,
        time_column=time_column,
        target_column=target_column,
        window_size=window_size,
        output_dir=output_dir,
        train_percent=train_percent,
        val_percent=val_percent,
        test_percent=test_percent,
        random_state=random_state,
        split_method=split_method,
        normalize=normalize,
        task=task,
    )
    
    # Determine number of classes/outputs
    if task == "classification":
        num_classes = len(np.unique(y_train))
    else:
        num_classes = 1
    
    input_size = X_train.shape[2]  # Number of features
    
    # Select models based on mode
    models_to_train = _select_models(
        task=task,
        mode=mode,
        input_size=input_size,
        num_classes=num_classes,
    )
    
    train_loader, val_loader, test_loader = _build_dataloaders(
        X_train, y_train, X_val, y_val, X_test, y_test, task, batch_size
    )
    
    results = []
    total_models = len(models_to_train)

    for i, (model_name, model) in enumerate(models_to_train):
        step(f"Training {model_name} ({i + 1}/{total_models})...")
        model = model.to(device_obj)
        criterion: nn.Module = nn.CrossEntropyLoss() if task == "classification" else nn.MSELoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        best_state = None
        best_val_metric = -np.inf if task == "classification" else np.inf
        metric_name = "accuracy" if task == "classification" else "mse"
        model_start = perf_counter()

        for epoch in range(epochs):
            model.train()
            for xb, yb in train_loader:
                xb = xb.to(device_obj)
                yb = yb.to(device_obj)
                optimizer.zero_grad()
                outputs = model(xb)
                if task == "regression":
                    outputs = outputs.squeeze(-1) if outputs.dim() > 1 and outputs.shape[-1] == 1 else outputs
                    yb = yb.float()
                loss = criterion(outputs, yb)
                loss.backward()
                optimizer.step()

            if val_loader is not None:
                val_metrics = _evaluate_model(model, val_loader, task, criterion, device_obj)
                current_val = val_metrics[metric_name]
                improved = current_val > best_val_metric if task == "classification" else current_val < best_val_metric
                if improved:
                    best_val_metric = current_val
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            else:
                # Fall back to train metric if val split is empty.
                train_metrics = _evaluate_model(model, train_loader, task, criterion, device_obj)
                current_val = train_metrics[metric_name]
                improved = current_val > best_val_metric if task == "classification" else current_val < best_val_metric
                if improved:
                    best_val_metric = current_val
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        if best_state is not None:
            model.load_state_dict(best_state)

        test_metrics = _evaluate_model(model, test_loader, task, criterion, device_obj)
        elapsed = perf_counter() - model_start

        result_entry: Dict[str, float | str] = {
            "model": model_name,
            "train_time_sec": round(elapsed, 4),
        }
        if task == "classification":
            result_entry["val_accuracy"] = float(best_val_metric)
            result_entry["test_accuracy"] = float(test_metrics["accuracy"])
            result_entry["test_loss"] = float(test_metrics["loss"])
        else:
            result_entry["val_mse"] = float(best_val_metric)
            result_entry["test_mse"] = float(test_metrics["mse"])
            result_entry["test_loss"] = float(test_metrics["loss"])
        results.append(result_entry)

        model_path = Path(output_dir) / f"{model_name}.pth"
        torch.save(model.state_dict(), model_path)
    
    # Find best model
    if task == "classification":
        best_idx = max(range(len(results)), key=lambda i: float(results[i]["val_accuracy"]))  # type: ignore[index]
        best_result = results[best_idx]
    else:
        best_idx = min(range(len(results)), key=lambda i: float(results[i]["val_mse"]))  # type: ignore[index]
        best_result = results[best_idx]
    
    # Save results
    results_path = Path(output_dir) / "results.json"
    with open(results_path, "w") as f:
        json.dump(
            {
                "results": results,
                "best_model": best_result,
                "selection_metric": "val_accuracy" if task == "classification" else "val_mse",
                "preprocess_metadata": preprocess_metadata,
            },
            f,
            indent=2,
        )
    
    return {
        "best_model_index": best_idx,
        "best_model": best_result,
        "all_results": results,
    }
