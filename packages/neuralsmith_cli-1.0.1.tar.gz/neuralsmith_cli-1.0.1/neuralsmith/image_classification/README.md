# Image Classification

This module runs Neural Architecture Search (NAS) and baseline models for image classification from the `neuralsmith image-classification` command.

## What It Does

- Accepts either:
  - an image dataset folder (class-per-subdirectory style), or
  - a directory containing pre-split NumPy arrays (`X_train.npy`, `y_train.npy`, `X_test.npy`, `y_test.npy`).
- Trains multiple candidate models.
- Tracks live progress through run-status snapshots.
- Produces training artifacts and final summary report files.

## CLI Command

```bash
neuralsmith image-classification \
  --data-path <path> \
  --output-dir <dir> \
  [--target-size H,W] \
  [--val-split 0.1] \
  [--epochs 50] \
  [--batch-size N] \
  [--learning-rate 0.001] \
  [--early-stopping-patience 7] \
  [--reduce-lr-patience 5] \
  [--normalize | --no-normalize] \
  [--device cpu|cuda] \
  [--seed 42]
```

## Parameters

- `--data-path` (required): image root directory or NumPy split directory.
- `--output-dir`: where model outputs and reports are written. Defaults to `./models`.
- `--target-size`: resize dimensions as `H,W` (for example `128,128`).
- `--val-split`: validation split from training data. Defaults to `0.1`.
- `--epochs`: maximum epochs per model. Defaults to `50`.
- `--batch-size`: batch size override.
- `--learning-rate`: optimizer learning rate.
- `--early-stopping-patience`: early stopping patience. Defaults to `7`.
- `--reduce-lr-patience`: LR scheduler patience. Defaults to `5`.
- `--normalize` / `--no-normalize`: explicit normalization toggle.
- `--device`: choose `cpu` or `cuda`; omitted means auto-detect.
- `--seed`: random seed. Defaults to `42`.

## Typical Workflow

1. Prepare a class-labeled image dataset.
2. Run training with `image-classification`.
3. Watch progress in terminal and run status file.
4. Review `training_summary_report.md` in the output folder.
5. Load/use the best model for inference.

## Outputs

Inside `--output-dir`, expect:

- model artifacts produced by NAS/baseline scripts,
- `neuralsmith_run_status.json` for live status,
- `neuralsmith_run_events.jsonl` for detailed updates,
- `training_summary_report.md` and `training_summary_report.json`.

## Example

```bash
neuralsmith image-classification \
  --data-path ./my_images \
  --output-dir ./results_image \
  --target-size 128,128 \
  --epochs 30 \
  --val-split 0.2 \
  --device cuda
```

## Notes

- In test mode (`NEURALSMITH_TEST_MODE`), fewer models/epochs may run.
- If using NumPy pre-splits, preprocessing from raw images is skipped.
- Ensure image dimensions/channels match the trained model configuration when doing inference later.
