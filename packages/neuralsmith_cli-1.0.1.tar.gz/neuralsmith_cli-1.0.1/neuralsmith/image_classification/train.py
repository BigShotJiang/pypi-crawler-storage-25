"""
Training orchestration for the NeuralSmith image classification wizard.

This CLI-local version calls the NAS and baseline training scripts located
under ``CLI/Legacy_utils/Torch NAS Logic/search_torch``.
"""

from __future__ import annotations

import json
import os
import random
import subprocess
import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from neuralsmith.output import step
from neuralsmith.run_status import update_image_training_progress, update_run

from .preprocess import preprocess_image_dataset


NAS_SCRIPT_REL = Path("CLI") / "Legacy_utils" / "Torch NAS Logic" / "search_torch" / "nas_train.py"
BASELINE_SCRIPT_REL = Path("CLI") / "Legacy_utils" / "Torch NAS Logic" / "search_torch" / "baseline_train.py"


@dataclass
class ImageTrainConfig:
    data_path: Path
    output_dir: Path
    target_size: Optional[Tuple[int, int]]
    val_split: float
    epochs: int
    batch_size: Optional[int]
    learning_rate: Optional[float]
    early_stopping_patience: int
    reduce_lr_patience: int
    normalize: Optional[bool]
    device: Optional[str]
    seed: int


def parse_target_size(arg: Optional[str]) -> Optional[Tuple[int, int]]:
    if not arg:
        return None
    try:
        h_str, w_str = arg.split(",")
        h = int(h_str.strip())
        w = int(w_str.strip())
        if h <= 0 or w <= 0:
            raise ValueError("Dimensions must be positive")
        return (h, w)
    except Exception as exc:
        raise ValueError(f"Invalid target size '{arg}'; expected H,W") from exc


def _python_executable() -> str:
    return os.environ.get("NEURALSMITH_PYTHON", sys.executable)


def _repo_root() -> Path:
    """
    Return the repository root (directory that contains ``CLI/``).

    This file lives at ``<repo>/CLI/neuralsmith/image_classification/train.py``,
    so ``parents[3]`` is the repo root.
    """
    return Path(__file__).resolve().parents[3]


def _run_python_script(
    script_rel: Path,
    args: Sequence[str],
    *,
    status_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    repo_root = _repo_root()
    script_path = repo_root / script_rel
    if not script_path.exists():
        raise FileNotFoundError(f"Training script not found at {script_path}")

    cmd = [_python_executable(), str(script_path), *args]
    env = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"}
    proc = subprocess.Popen(
        cmd,
        cwd=str(repo_root),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env=env,
    )

    stderr_chunks: List[str] = []

    def _drain_stderr() -> None:
        assert proc.stderr is not None
        for line in proc.stderr:
            stderr_chunks.append(line)

    stderr_thread = threading.Thread(target=_drain_stderr, daemon=True)
    stderr_thread.start()

    stdout_lines: List[str] = []
    assert proc.stdout is not None
    for raw_line in proc.stdout:
        line = raw_line.rstrip("\n")
        stdout_lines.append(line)
        print(line, flush=True)

        if status_dir is not None:
            if line.startswith("BATCH_JSON:"):
                try:
                    payload = json.loads(line[len("BATCH_JSON:") :])
                    update_image_training_progress(
                        status_dir, line_prefix="BATCH_JSON", payload=payload
                    )
                except Exception:
                    pass
            elif line.startswith("EPOCH_JSON:"):
                try:
                    payload = json.loads(line[len("EPOCH_JSON:") :])
                    update_image_training_progress(
                        status_dir, line_prefix="EPOCH_JSON", payload=payload
                    )
                except Exception:
                    pass
            elif line.startswith("EARLY_STOP_JSON:"):
                update_run(
                    status_dir,
                    phase="training",
                    last_message="Early stopping triggered",
                    current_step="early_stopping",
                )

    proc.wait()
    stderr_thread.join(timeout=30)
    stderr = "".join(stderr_chunks)

    if proc.returncode != 0:
        raise RuntimeError(
            f"Training script failed with code {proc.returncode}.\nSTDERR:\n{stderr}"
        )

    result_payload: Dict[str, Any] = {}
    for line in stdout_lines:
        if line.startswith("RESULT_JSON:"):
            json_str = line[len("RESULT_JSON:") :]
            try:
                result_payload = json.loads(json_str)
            except Exception:
                result_payload = {}
            break

    if not result_payload:
        result_payload = {"stdout": stdout_lines, "stderr": stderr}

    return result_payload


def _generate_weighted_random_op_list(rng: random.Random) -> List[int]:
    ops = [0, 1, 2, 3, 4]
    while True:
        vec = [rng.choice(ops) for _ in range(6)]
        if any(op in (2, 3) for op in vec):
            return vec


def _weighted_optimization_op_list(
    history: Sequence[Dict[str, Any]],
    rng: random.Random,
) -> List[int]:
    if not history:
        return _generate_weighted_random_op_list(rng)

    op_scores: Dict[int, float] = {i: 1.0 for i in range(5)}
    for record in history:
        acc = float(record.get("result", {}).get("test_accuracy", 0.0))
        for op in record.get("architecture", []):
            op_scores[op] = op_scores.get(op, 1.0) + max(acc, 0.0)

    total = sum(op_scores.values())
    probs = {op: score / total for op, score in op_scores.items()}

    def sample_op() -> int:
        r = rng.random()
        cumulative = 0.0
        for op, p in probs.items():
            cumulative += p
            if r <= cumulative:
                return op
        return 3

    for _ in range(10):
        vec = [sample_op() for _ in range(6)]
        if any(op in (2, 3) for op in vec):
            return vec
    return _generate_weighted_random_op_list(rng)


def train_image_models(cfg: ImageTrainConfig) -> Dict[str, Any]:
    step("Preparing image data...")
    x_train, y_train, x_test, y_test = preprocess_image_dataset(
        data_path=cfg.data_path,
        processed_dir=cfg.data_path / "processed",
        target_size=cfg.target_size,
        seed=cfg.seed,
    )

    x_train_str = str(x_train)
    y_train_str = str(y_train)
    x_test_str = str(x_test)
    y_test_str = str(y_test)

    def build_nas_args(arch: List[int]) -> List[str]:
        args: List[str] = [
            "--x_train",
            x_train_str,
            "--y_train",
            y_train_str,
            "--x_test",
            x_test_str,
            "--y_test",
            y_test_str,
            "--architecture",
            ",".join(str(o) for o in arch),
            "--epochs",
            str(cfg.epochs),
            "--output_dir",
            str(cfg.output_dir),
            "--val_split",
            str(cfg.val_split),
        ]
        if cfg.batch_size is not None:
            args.extend(["--batch_size", str(cfg.batch_size)])
        if cfg.learning_rate is not None:
            args.extend(["--lr", str(cfg.learning_rate)])
        if cfg.device:
            args.extend(["--device", cfg.device])
        if cfg.target_size is not None:
            h, w = cfg.target_size
            args.extend(["--target_size", f"{h},{w}"])
        args.extend(
            [
                "--early_stopping_patience",
                str(cfg.early_stopping_patience),
                "--reduce_lr_patience",
                str(cfg.reduce_lr_patience),
            ]
        )
        if cfg.normalize is not None:
            args.extend(["--normalize", "1" if cfg.normalize else "0"])
        return args

    def build_baseline_args(model_name: str) -> List[str]:
        args: List[str] = [
            "--x_train",
            x_train_str,
            "--y_train",
            y_train_str,
            "--x_test",
            x_test_str,
            "--y_test",
            y_test_str,
            "--model_name",
            model_name,
            "--epochs",
            str(cfg.epochs),
            "--output_dir",
            str(cfg.output_dir),
        ]
        if cfg.batch_size is not None:
            args.extend(["--batch_size", str(cfg.batch_size)])
        if cfg.learning_rate is not None:
            args.extend(["--lr", str(cfg.learning_rate)])
        if cfg.device:
            args.extend(["--device", cfg.device])
        if cfg.target_size is not None:
            h, w = cfg.target_size
            args.extend(["--target_size", f"{h},{w}"])
        args.extend(
            [
                "--early_stopping_patience",
                str(cfg.early_stopping_patience),
                "--reduce_lr_patience",
                str(cfg.reduce_lr_patience),
            ]
        )
        if cfg.normalize is not None:
            args.extend(["--normalize", "1" if cfg.normalize else "0"])
        return args

    rng = random.Random(cfg.seed)
    results: List[Dict[str, Any]] = []

    test_mode = os.getenv("NEURALSMITH_TEST_MODE", "0") == "1"

    nas_models_to_run = 3 if not test_mode else 1
    nas_total = nas_models_to_run + (7 if not test_mode else 0)
    for i in range(nas_models_to_run):
        step(f"Training NAS model {i + 1}/{nas_total}...")
        arch = _generate_weighted_random_op_list(rng)
        payload = _run_python_script(
            NAS_SCRIPT_REL, build_nas_args(arch), status_dir=cfg.output_dir
        )
        results.append({"kind": "nas", "architecture": arch, "result": payload})

    if not test_mode:
        for i in range(7):
            step(f"Training NAS model {nas_models_to_run + i + 1}/{nas_total}...")
            arch = _weighted_optimization_op_list(results, rng)
            payload = _run_python_script(
                NAS_SCRIPT_REL, build_nas_args(arch), status_dir=cfg.output_dir
            )
            results.append({"kind": "nas", "architecture": arch, "result": payload})

    baseline_models = ["ResNet50", "DenseNet201", "ConvNeXtTiny", "MobileNetV2"]
    baseline_to_run = baseline_models if not test_mode else baseline_models[:1]
    for i, model_name in enumerate(baseline_to_run):
        step(f"Training baseline {model_name} ({i + 1}/{len(baseline_to_run)})...")
        payload = _run_python_script(
            BASELINE_SCRIPT_REL,
            build_baseline_args(model_name),
            status_dir=cfg.output_dir,
        )
        results.append({"kind": "baseline", "model_name": model_name, "result": payload})

    best_idx = None
    best_acc = float("-inf")
    for idx, record in enumerate(results):
        acc = float(record.get("result", {}).get("test_accuracy", 0.0))
        if acc > best_acc:
            best_acc = acc
            best_idx = idx

    summary: Dict[str, Any] = {
        "results": results,
        "best_model_index": best_idx,
        "best_test_accuracy": best_acc if best_idx is not None else None,
    }
    return summary


def train_image_models_from_args(args: Any) -> Dict[str, Any]:
    cfg = ImageTrainConfig(
        data_path=Path(args.data_path).expanduser().resolve(),
        output_dir=Path(args.output_dir).expanduser().resolve(),
        target_size=parse_target_size(getattr(args, "target_size", None)),
        val_split=float(getattr(args, "val_split", 0.1)),
        epochs=int(getattr(args, "epochs", 50)),
        batch_size=getattr(args, "batch_size", None),
        learning_rate=getattr(args, "learning_rate", None),
        early_stopping_patience=int(
            getattr(args, "early_stopping_patience", 7)
        ),
        reduce_lr_patience=int(
            getattr(args, "reduce_lr_patience", 5)
        ),
        normalize=(
            True
            if getattr(args, "normalize", False)
            else False
            if getattr(args, "no_normalize", False)
            else None
        ),
        device=getattr(args, "device", None),
        seed=int(getattr(args, "seed", 42)),
    )
    cfg.output_dir.mkdir(parents=True, exist_ok=True)
    return train_image_models(cfg)

