"""Image classification wizard for NeuralSmith CLI (CLI-local package)."""

