"""
Image preprocessing pipeline for the NeuralSmith image classification wizard.

This is the same deterministic fallback logic described in ``CLI/overview.md``,
implemented as a reusable Python module under ``CLI/``.
"""

from __future__ import annotations

import gc
import os
import re
from pathlib import Path
from typing import List, Sequence, Tuple

import numpy as np
import psutil
from PIL import Image
from sklearn.model_selection import train_test_split

from neuralsmith.output import step, verbose


def _check_memory_usage() -> dict:
    memory = psutil.virtual_memory()
    return {
        "total": memory.total,
        "available": memory.available,
        "percent": memory.percent,
        "used": memory.used,
    }


def _estimate_memory_requirement(num_images: int, target_shape: Sequence[int]) -> int:
    pixels_per_image = int(target_shape[0]) * int(target_shape[1]) * int(target_shape[2])
    bytes_per_image = pixels_per_image * 4  # float32
    total_bytes = int(num_images * bytes_per_image * 1.5)  # overhead
    return total_bytes


def _get_optimal_image_shape(
    image_files: List[Path],
    memory_limit_gb: float = 4.0,
) -> Tuple[int, int, int]:
    if not image_files:
        return (64, 64, 3)

    memory_info = _check_memory_usage()
    available_memory_bytes = memory_info["available"]
    memory_limit_bytes = int(memory_limit_gb * 1024**3)
    max_memory_bytes = min(available_memory_bytes, memory_limit_bytes)

    sample_size = min(50, len(image_files))
    widths: List[int] = []
    heights: List[int] = []
    for img_path in image_files[:sample_size]:
        try:
            with Image.open(img_path) as img:
                w, h = img.size
                widths.append(w)
                heights.append(h)
        except Exception:
            continue

    if not widths:
        return (64, 64, 3)

    target_width = sum(widths) // len(widths)
    target_height = sum(heights) // len(heights)

    estimated_memory = _estimate_memory_requirement(
        len(image_files), (target_height, target_width, 3)
    )

    while estimated_memory > max_memory_bytes * 0.8:
        target_width = max(32, target_width // 2)
        target_height = max(32, target_height // 2)
        estimated_memory = _estimate_memory_requirement(
            len(image_files), (target_height, target_width, 3)
        )

    return (target_height, target_width, 3)


def _discover_images(root: Path) -> List[Path]:
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".tiff"}
    files: List[Path] = []
    for dirpath, _, filenames in os.walk(root):
        for name in filenames:
            if Path(name).suffix.lower() in exts:
                files.append(Path(dirpath) / name)
    return files


def _infer_class_id(path: Path) -> int:
    filename = path.name
    class_id = 0

    m = re.search(r"class(\d+)", filename)
    if m:
        return int(m.group(1))
    m = re.search(r"img_\d+_class(\d+)", filename)
    if m:
        return int(m.group(1))

    for part in path.parts:
        if part.isdigit():
            return int(part)

    return class_id


def preprocess_image_dataset(
    data_path: str | Path,
    processed_dir: str | Path | None = None,
    target_size: Tuple[int, int] | None = None,
    seed: int = 42,
):
    """
    Preprocess image dataset or use existing numpy files.
    
    This function supports two modes:
    1. If numpy files (X_train.npy, y_train.npy, X_test.npy, y_test.npy) exist in data_path,
       it uses them directly (skips preprocessing).
    2. Otherwise, it processes images from data_path and creates numpy files.
    
    Note: NeuralSmith works primarily with numpy arrays. The image preprocessing step
    is optional - if you already have numpy files, NeuralSmith can use them directly.
    
    Validation split: The --val-split parameter controls how the training data is split
    into train/validation sets during training. The test split (20%) is done during
    preprocessing if processing images, or should already be in your X_test.npy/y_test.npy
    if using existing numpy files.
    """
    root = Path(data_path).expanduser().resolve()
    proc_dir = Path(processed_dir).expanduser().resolve() if processed_dir else root / "processed"
    proc_dir.mkdir(parents=True, exist_ok=True)
    
    # Check if numpy files already exist (either in data_path or processed_dir)
    x_train_path = proc_dir / "X_train.npy"
    y_train_path = proc_dir / "y_train.npy"
    x_test_path = proc_dir / "X_test.npy"
    y_test_path = proc_dir / "y_test.npy"
    
    # Also check in root directory (in case user points directly to numpy files)
    root_x_train = root / "X_train.npy"
    root_y_train = root / "y_train.npy"
    root_x_test = root / "X_test.npy"
    root_y_test = root / "y_test.npy"
    
    # Check if all numpy files exist in root
    if all(p.exists() for p in [root_x_train, root_y_train, root_x_test, root_y_test]):
        step("Using existing numpy files in data directory...")
        verbose(f"  X_train: {root_x_train}")
        verbose(f"  y_train: {root_y_train}")
        verbose(f"  X_test: {root_x_test}")
        verbose(f"  y_test: {root_y_test}")
        
        # Load to verify and show info
        X_train = np.load(root_x_train)
        y_train = np.load(root_y_train)
        X_test = np.load(root_x_test)
        y_test = np.load(root_y_test)
        
        verbose(f"X_train shape: {X_train.shape}, dtype: {X_train.dtype}")
        verbose(f"y_train shape: {y_train.shape}, dtype: {y_train.dtype}")
        verbose(f"X_test shape: {X_test.shape}, dtype: {X_test.dtype}")
        verbose(f"y_test shape: {y_test.shape}, dtype: {y_test.dtype}")
        verbose(f"Classes in y_train: {sorted(set(int(v) for v in y_train))}")
        verbose(f"Classes in y_test: {sorted(set(int(v) for v in y_test))}")
        verbose("Validation split (--val-split) will be applied during training.")
        
        return root_x_train, root_y_train, root_x_test, root_y_test
    
    # Check if numpy files exist in processed directory
    if all(p.exists() for p in [x_train_path, y_train_path, x_test_path, y_test_path]):
        step("Using existing numpy files in processed directory...")
        verbose(f"  X_train: {x_train_path}")
        verbose(f"  y_train: {y_train_path}")
        verbose(f"  X_test: {x_test_path}")
        verbose(f"  y_test: {y_test_path}")
        
        # Load to verify and show info
        X_train = np.load(x_train_path)
        y_train = np.load(y_train_path)
        X_test = np.load(x_test_path)
        y_test = np.load(y_test_path)
        
        verbose(f"X_train shape: {X_train.shape}, dtype: {X_train.dtype}")
        verbose(f"y_train shape: {y_train.shape}, dtype: {y_train.dtype}")
        verbose(f"X_test shape: {X_test.shape}, dtype: {X_test.dtype}")
        verbose(f"y_test shape: {y_test.shape}, dtype: {y_test.dtype}")
        verbose(f"Classes in y_train: {sorted(set(int(v) for v in y_train))}")
        verbose(f"Classes in y_test: {sorted(set(int(v) for v in y_test))}")
        verbose("Validation split (--val-split) will be applied during training.")
        
        return x_train_path, y_train_path, x_test_path, y_test_path
    
    # No numpy files found - proceed with image preprocessing
    step("Processing images...")
    image_files = _discover_images(root)
    verbose(f"Found {len(image_files)} image files under {root}")

    if not image_files:
        rng = np.random.default_rng(seed)
        X_dummy = rng.random((10, 64, 64, 3), dtype=np.float32)
        y_dummy = rng.integers(0, 3, size=10)
        X_train, X_test, y_train, y_test = train_test_split(
            X_dummy, y_dummy, test_size=0.2, random_state=seed
        )
    else:
        if target_size is None:
            h, w, c = _get_optimal_image_shape(image_files)
            target_size = (h, w)
        else:
            h, w = target_size
            c = 3

        mem = _check_memory_usage()
        verbose(f"Optimal image shape: ({h}, {w}, {c})")
        verbose(f"Available memory: {mem['available'] / (1024**3):.2f} GB")

        X_list: List[np.ndarray] = []
        y_list: List[int] = []
        batch_size = 100

        for idx, path in enumerate(image_files):
            try:
                class_id = _infer_class_id(path)
                with Image.open(path) as img:
                    if img.mode != "RGB":
                        img = img.convert("RGB")
                    img = img.resize((w, h), Image.Resampling.LANCZOS)
                    arr = np.asarray(img, dtype=np.float32) / 255.0
                X_list.append(arr)
                y_list.append(class_id)
                if (idx + 1) % batch_size == 0:
                    step(f"Processed {idx + 1}/{len(image_files)} images...")
                    gc.collect()
            except Exception as exc:
                verbose(f"Error processing {path}: {exc}")
                continue

        if X_list:
            X_full = np.stack(X_list).astype(np.float32)
            y_full = np.asarray(y_list, dtype=np.int64)
            verbose(f"Final dataset shape: {X_full.shape}")
            verbose(f"Classes found: {sorted(set(int(v) for v in y_full))}")

            if len(X_full) >= 2:
                X_train, X_test, y_train, y_test = train_test_split(
                    X_full, y_full, test_size=0.2, random_state=seed
                )
            else:
                X_train, y_train = X_full, y_full
                X_test = np.empty((0, *X_full.shape[1:]), dtype=np.float32)
                y_test = np.empty((0,), dtype=np.int64)
        else:
            rng = np.random.default_rng(seed)
            X_dummy = rng.random((10, 64, 64, 3), dtype=np.float32)
            y_dummy = rng.integers(0, 3, size=10)
            X_train, X_test, y_train, y_test = train_test_split(
                X_dummy, y_dummy, test_size=0.2, random_state=seed
            )

    # Save numpy files
    np.save(x_train_path, X_train)
    np.save(y_train_path, y_train)
    np.save(x_test_path, X_test)
    np.save(y_test_path, y_test)

    step("Preprocessing complete.")
    verbose(f"X_train shape: {X_train.shape}")
    verbose(f"y_train shape: {y_train.shape}")
    verbose(f"X_test shape: {X_test.shape}")
    verbose(f"y_test shape: {y_test.shape}")
    verbose(f"Processed data saved under: {proc_dir}")
    verbose("Validation split (--val-split) will be applied during training from X_train/y_train.")

    return x_train_path, y_train_path, x_test_path, y_test_path

