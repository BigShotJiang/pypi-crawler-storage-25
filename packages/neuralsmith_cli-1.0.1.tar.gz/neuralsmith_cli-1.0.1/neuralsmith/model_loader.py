"""
Model loading utilities for NeuralSmith.

Provides easy-to-use functions for loading trained models and preprocessing pipelines.
"""

import json
import joblib
import torch
import torch.nn as nn
from pathlib import Path
from typing import Tuple, Optional, Dict, Any, Union
import sys

# Add NAS training script path for model architecture
NAS_TRAIN_PATH = Path(__file__).parent.parent.parent / "Legacy_utils" / "Torch NAS Logic" / "search_torch" / "nas_train.py"
if NAS_TRAIN_PATH.exists():
    sys.path.insert(0, str(NAS_TRAIN_PATH.parent))
    try:
        from nas_train import NASBench201Network, build_nas201_model
    except ImportError:
        NASBench201Network = None
        build_nas201_model = None
else:
    NASBench201Network = None
    build_nas201_model = None


def load_model(
    model_path: Union[str, Path],
    device: Optional[str] = None
) -> Union[nn.Module, Tuple[Any, Any]]:
    """
    Load a trained NeuralSmith model.
    
    For image classification: Returns the PyTorch model
    For tabular: Returns (model, preprocessor) tuple
    
    Args:
        model_path: Path to model file or directory
        device: Device to load model on ('cpu' or 'cuda', default: auto-detect)
        
    Returns:
        For image models: PyTorch model
        For tabular models: (model, preprocessor) tuple
    """
    model_path = Path(model_path)
    
    if not model_path.exists():
        raise FileNotFoundError(f"Model path not found: {model_path}")
    
    # Determine model type
    if model_path.is_dir():
        # Tabular model (directory with model.joblib and preprocessing artifacts)
        return _load_tabular_model(model_path)
    elif model_path.suffix == '.pth':
        # Image classification model (PyTorch checkpoint)
        return _load_image_model(model_path, device)
    else:
        raise ValueError(f"Unknown model format: {model_path}")


def _load_image_model(model_path: Path, device: Optional[str]) -> nn.Module:
    """Load image classification model."""
    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    device_obj = torch.device(device)
    
    # Load checkpoint
    checkpoint = torch.load(model_path, map_location=device_obj)
    
    # Extract model parameters
    if isinstance(checkpoint, dict):
        architecture = checkpoint.get('architecture')
        num_classes = checkpoint.get('num_classes')
        input_channels = checkpoint.get('input_channels', 3)
    else:
        raise ValueError("Invalid model checkpoint format")
    
    if architecture is None or num_classes is None:
        raise ValueError("Model checkpoint missing required parameters")
    
    # Build model
    if build_nas201_model is None:
        raise ImportError("Could not import NAS model builder. Ensure Legacy_utils is available.")
    
    model = build_nas201_model(
        op_vector=architecture,
        num_classes=num_classes,
        input_channels=input_channels
    )
    
    # Load weights
    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    else:
        model.load_state_dict(checkpoint)
    
    model = model.to(device_obj)
    model.eval()
    
    return model


def _load_tabular_model(model_dir: Path) -> Tuple[Any, Dict[str, Any]]:
    """Load tabular model and preprocessing pipeline."""
    model_file = model_dir / "model.joblib"
    if not model_file.exists():
        raise FileNotFoundError(f"Model file not found: {model_file}")
    
    # Load model
    model = joblib.load(model_file)
    
    # Load preprocessing artifacts
    preprocessor = {
        'imputer': None,
        'scaler': None,
        'selector': None,
        'label_encoder': None,
    }
    
    imputer_file = model_dir / "imputer.joblib"
    scaler_file = model_dir / "scaler.joblib"
    selector_file = model_dir / "selector.joblib"
    label_encoder_file = model_dir / "label_encoder.joblib"
    metadata_file = model_dir / "metadata.json"
    preproc_metadata_file = model_dir / "preprocessing_metadata.json"
    
    if imputer_file.exists():
        preprocessor['imputer'] = joblib.load(imputer_file)
    if scaler_file.exists():
        preprocessor['scaler'] = joblib.load(scaler_file)
    if selector_file.exists():
        preprocessor['selector'] = joblib.load(selector_file)
    if label_encoder_file.exists():
        preprocessor['label_encoder'] = joblib.load(label_encoder_file)
    
    # Load metadata
    metadata = {}
    if metadata_file.exists():
        with open(metadata_file, 'r') as f:
            metadata = json.load(f)
    if preproc_metadata_file.exists():
        with open(preproc_metadata_file, 'r') as f:
            preprocessor['metadata'] = json.load(f)
    
    return model, preprocessor


def preprocess_data(
    data: Any,
    preprocessor: Dict[str, Any],
    feature_names: Optional[list] = None
) -> Any:
    """
    Preprocess data using a loaded preprocessing pipeline.
    
    Args:
        data: Input data (pandas DataFrame for tabular, numpy array for images)
        preprocessor: Preprocessor dictionary from load_model()
        feature_names: Feature names (for tabular data)
        
    Returns:
        Preprocessed data ready for model prediction
    """
    import pandas as pd
    import numpy as np
    
    if isinstance(data, pd.DataFrame):
        # Tabular preprocessing
        X = data.copy()
        
        # Get original feature names from metadata
        if feature_names is None and 'metadata' in preprocessor:
            feature_names = preprocessor['metadata'].get('original_feature_names', list(X.columns))
        
        # Ensure correct column order
        if feature_names:
            X = X[feature_names]
        
        # Impute
        if preprocessor['imputer'] is not None:
            X = pd.DataFrame(
                preprocessor['imputer'].transform(X),
                columns=feature_names,
                index=X.index
            )
        
        # Scale
        if preprocessor['scaler'] is not None:
            X = pd.DataFrame(
                preprocessor['scaler'].transform(X),
                columns=feature_names,
                index=X.index
            )
        
        # Select features
        if preprocessor['selector'] is not None:
            X = preprocessor['selector'].transform(X)
        
        return X
    else:
        # Image preprocessing (basic normalization)
        if isinstance(data, np.ndarray):
            if data.max() > 1.0:
                data = data.astype(np.float32) / 255.0
            return data
        else:
            raise ValueError(f"Unsupported data type: {type(data)}")
