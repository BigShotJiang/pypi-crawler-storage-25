"""
NeuralSmith CLI - main entry point (CLI-local package in ``CLI/``).

This defines the top-level ``neuralsmith`` command, handles argument parsing,
configuration, and dispatches to sub-command implementations.
"""

from __future__ import annotations

import argparse
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, Optional

from . import config as ns_config


@contextmanager
def _neural_run_status_context(
    output_dir: Path,
    command: str,
    *,
    extra: Optional[Dict[str, Any]] = None,
) -> Iterator[Path]:
    """Start run-status file + wire step/verbose/report to snapshot updates."""
    from .output import set_progress_callback
    from .run_status import start_run, update_run

    od = Path(output_dir).expanduser().resolve()
    od.mkdir(parents=True, exist_ok=True)
    start_run(od, command, extra=extra or {})

    def _cb(msg: str, kind: str) -> None:
        update_run(od, last_message=msg[:4000], current_step=msg[:800])

    set_progress_callback(_cb)
    try:
        yield od
    finally:
        set_progress_callback(None)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="neuralsmith",
        description="NeuralSmith CLI - Automated Neural Architecture Search",
    )

    parser.add_argument(
        "--version",
        action="store_true",
        help="Show version and exit",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="count",
        default=0,
        help="Increase verbosity (can be specified multiple times)",
    )
    parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Quiet mode (minimal output)",
    )
    parser.add_argument(
        "--config",
        type=str,
        help="Path to an explicit config file (overrides default location)",
    )
    parser.add_argument(
        "--skip-welcome",
        action="store_true",
        help="Skip welcome screen",
    )
    parser.add_argument(
        "--no-auto-copilot",
        action="store_true",
        help="Do not auto-start CoPilot when no sub-command is given",
    )
    parser.add_argument(
        "--config-key",
        action="store_true",
        help="Configure Gemini API key and exit",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Image Classification command
    ic_parser = subparsers.add_parser(
        "image-classification",
        help="Train image classification models (NAS + baselines)",
    )
    ic_parser.add_argument(
        "--data-path",
        required=True,
        help="Path to image dataset folder OR directory containing numpy files (X_train.npy, y_train.npy, X_test.npy, y_test.npy). If numpy files exist, they will be used directly (skips image preprocessing)."
    )
    ic_parser.add_argument(
        "--output-dir",
        default="./models",
        help="Directory to store models and results (default: ./models)",
    )
    ic_parser.add_argument(
        "--target-size",
        type=str,
        help='Target image size in "H,W" format, e.g. "64,64"',
    )
    ic_parser.add_argument(
        "--val-split",
        type=float,
        default=0.1,
        help="Validation split ratio from training data (default: 0.1). Applied during training: X_train is split into train/val sets. Test split is already done (X_test/y_test provided).",
    )
    ic_parser.add_argument(
        "--epochs",
        type=int,
        default=50,
        help="Maximum epochs per model (default: 50)",
    )
    ic_parser.add_argument(
        "--batch-size",
        type=int,
        help="Batch size (default: auto)",
    )
    ic_parser.add_argument(
        "--learning-rate",
        type=float,
        help="Learning rate (default: 0.001)",
    )
    ic_parser.add_argument(
        "--early-stopping-patience",
        type=int,
        default=7,
        help="Early stopping patience (default: 7)",
    )
    ic_parser.add_argument(
        "--reduce-lr-patience",
        type=int,
        default=5,
        help="LR reduction patience (default: 5)",
    )
    norm_group = ic_parser.add_mutually_exclusive_group()
    norm_group.add_argument(
        "--normalize",
        action="store_true",
        help="Enable normalization",
    )
    norm_group.add_argument(
        "--no-normalize",
        action="store_true",
        help="Disable normalization",
    )
    ic_parser.add_argument(
        "--device",
        choices=["cpu", "cuda"],
        help="Computation device (default: auto-detect)",
    )
    ic_parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed (default: 42)",
    )

    # Tabular Classification command
    tc_parser = subparsers.add_parser(
        "tabular-classification",
        help="Train tabular classification models",
    )
    tc_parser.add_argument(
        "--data-path",
        required=True,
        help="Path to CSV file",
    )
    tc_parser.add_argument(
        "--target-column",
        required=True,
        help="Name of target column",
    )
    tc_parser.add_argument(
        "--output-dir",
        default="./models",
        help="Directory to store models and results (default: ./models)",
    )
    tc_parser.add_argument(
        "--mode",
        choices=["fast++", "fast", "exhaustive"],
        default="exhaustive",
        help="Training mode (default: exhaustive)",
    )
    tc_parser.add_argument(
        "--train-percent",
        type=float,
        default=80.0,
        help="Train split percentage (default: 80.0)",
    )
    tc_parser.add_argument(
        "--val-percent",
        type=float,
        default=0.0,
        help="Validation split percentage (default: 0.0)",
    )
    tc_parser.add_argument(
        "--test-percent",
        type=float,
        default=20.0,
        help="Test split percentage (default: 20.0)",
    )
    tc_parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed (default: 42)",
    )
    eda_group = tc_parser.add_mutually_exclusive_group()
    eda_group.add_argument(
        "--run-eda",
        action="store_true",
        help="Run EDA before training (default: enabled)",
    )
    eda_group.add_argument(
        "--no-eda",
        action="store_true",
        help="Skip EDA step",
    )

    # Tabular Regression command (shares same options)
    tr_parser = subparsers.add_parser(
        "tabular-regression",
        help="Train tabular regression models",
    )
    tr_parser.add_argument(
        "--data-path",
        required=True,
        help="Path to CSV file",
    )
    tr_parser.add_argument(
        "--target-column",
        required=True,
        help="Name of target column",
    )
    tr_parser.add_argument(
        "--output-dir",
        default="./models",
        help="Directory to store models and results (default: ./models)",
    )
    tr_parser.add_argument(
        "--mode",
        choices=["fast++", "fast", "exhaustive"],
        default="exhaustive",
        help="Training mode (default: exhaustive)",
    )
    tr_parser.add_argument(
        "--train-percent",
        type=float,
        default=80.0,
        help="Train split percentage (default: 80.0)",
    )
    tr_parser.add_argument(
        "--val-percent",
        type=float,
        default=0.0,
        help="Validation split percentage (default: 0.0)",
    )
    tr_parser.add_argument(
        "--test-percent",
        type=float,
        default=20.0,
        help="Test split percentage (default: 20.0)",
    )
    tr_parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed (default: 42)",
    )
    eda_group_r = tr_parser.add_mutually_exclusive_group()
    eda_group_r.add_argument(
        "--run-eda",
        action="store_true",
        help="Run EDA before training (default: enabled)",
    )
    eda_group_r.add_argument(
        "--no-eda",
        action="store_true",
        help="Skip EDA step",
    )
    # Time Series Classification command
    ts_c_parser = subparsers.add_parser(
        "timeseries-classification",
        help="Train time series classification models",
    )
    ts_c_parser.add_argument(
        "--data-path",
        required=True,
        help="Path to time series CSV file",
    )
    ts_c_parser.add_argument(
        "--time-column",
        required=False,
        help="Name of time column (required for CSV input; ignored for NumPy input)",
    )
    ts_c_parser.add_argument(
        "--target-column",
        required=True,
        help="Name of target column",
    )
    ts_c_parser.add_argument(
        "--window-size",
        type=int,
        required=False,
        help="Window size (required for CSV input; ignored for NumPy input)",
    )
    ts_c_parser.add_argument(
        "--output-dir",
        default="./models",
        help="Directory to store models and results (default: ./models)",
    )
    ts_c_parser.add_argument(
        "--mode",
        choices=["fast++", "fast", "exhaustive"],
        default="fast++",
        help="Training mode (fast++ fastest, default: fast++)",
    )
    ts_c_parser.add_argument(
        "--train-percent",
        type=float,
        default=70.0,
        help="Train split percentage (default: 70.0)",
    )
    ts_c_parser.add_argument(
        "--val-percent",
        type=float,
        default=15.0,
        help="Validation split percentage (default: 15.0)",
    )
    ts_c_parser.add_argument(
        "--test-percent",
        type=float,
        default=15.0,
        help="Test split percentage (default: 15.0)",
    )
    ts_c_parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed (default: 42)",
    )
    ts_c_parser.add_argument(
        "--epochs",
        type=int,
        default=10,
        help="Number of training epochs (default: 10)",
    )
    ts_c_parser.add_argument(
        "--batch-size",
        type=int,
        default=32,
        help="Batch size (default: 32)",
    )
    ts_c_parser.add_argument(
        "--split-method",
        choices=["temporal", "random"],
        default="temporal",
        help="Split strategy for windowed samples (default: temporal)",
    )
    ts_c_parser.add_argument(
        "--no-normalize",
        action="store_true",
        help="Disable train-fit normalization of features",
    )

    # Time Series Regression command (shares same options)
    ts_r_parser = subparsers.add_parser(
        "timeseries-regression",
        help="Train time series regression models",
    )
    ts_r_parser.add_argument(
        "--data-path",
        required=True,
        help="Path to time series CSV file",
    )
    ts_r_parser.add_argument(
        "--time-column",
        required=False,
        help="Name of time column (required for CSV input; ignored for NumPy input)",
    )
    ts_r_parser.add_argument(
        "--target-column",
        required=True,
        help="Name of target column",
    )
    ts_r_parser.add_argument(
        "--window-size",
        type=int,
        required=False,
        help="Window size (required for CSV input; ignored for NumPy input)",
    )
    ts_r_parser.add_argument(
        "--output-dir",
        default="./models",
        help="Directory to store models and results (default: ./models)",
    )
    ts_r_parser.add_argument(
        "--mode",
        choices=["fast++", "fast", "exhaustive"],
        default="fast++",
        help="Training mode (fast++ fastest, default: fast++)",
    )
    ts_r_parser.add_argument(
        "--train-percent",
        type=float,
        default=70.0,
        help="Train split percentage (default: 70.0)",
    )
    ts_r_parser.add_argument(
        "--val-percent",
        type=float,
        default=15.0,
        help="Validation split percentage (default: 15.0)",
    )
    ts_r_parser.add_argument(
        "--test-percent",
        type=float,
        default=15.0,
        help="Test split percentage (default: 15.0)",
    )
    ts_r_parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed (default: 42)",
    )
    ts_r_parser.add_argument(
        "--epochs",
        type=int,
        default=10,
        help="Number of training epochs (default: 10)",
    )
    ts_r_parser.add_argument(
        "--batch-size",
        type=int,
        default=32,
        help="Batch size (default: 32)",
    )
    ts_r_parser.add_argument(
        "--split-method",
        choices=["temporal", "random"],
        default="temporal",
        help="Split strategy for windowed samples (default: temporal)",
    )
    ts_r_parser.add_argument(
        "--no-normalize",
        action="store_true",
        help="Disable train-fit normalization of features",
    )
    # Auto-labeler command
    al_parser = subparsers.add_parser(
        "auto-labeler",
        help="Automatically label unlabeled data using weighted KNN",
    )
    al_parser.add_argument(
        "--data-path",
        required=True,
        help="Path to data file/folder",
    )
    al_parser.add_argument(
        "--data-type",
        choices=["image", "tabular", "timeseries"],
        required=True,
        help="Type of data",
    )
    al_parser.add_argument(
        "--labeled-column",
        required=True,
        help="Column indicating if sample is labeled",
    )
    al_parser.add_argument(
        "--label-column",
        required=True,
        help="Column with labels (for labeled samples)",
    )
    al_parser.add_argument(
        "--output-path",
        required=True,
        help="Output CSV file path",
    )
    al_parser.add_argument(
        "--k",
        type=int,
        default=5,
        help="Number of neighbors (default: 5)",
    )
    al_parser.add_argument(
        "--min-confidence",
        type=float,
        default=0.5,
        help="Minimum confidence threshold (default: 0.5)",
    )
    al_parser.add_argument(
        "--exclude-low-confidence",
        action="store_true",
        help="Exclude low-confidence predictions",
    )
    al_parser.add_argument(
        "--image-model",
        choices=["mobilenet_v2", "resnet18"],
        default="mobilenet_v2",
        help="Model for image features (default: mobilenet_v2)",
    )
    al_parser.add_argument(
        "--tabular-reducer",
        choices=["pca", "umap", "incremental_pca"],
        default="pca",
        help="Dimensionality reduction method (default: pca)",
    )
    al_parser.add_argument(
        "--timeseries-use-minirocket",
        action="store_true",
        help="Use MiniRocket features for time series",
    )
    copilot_parser = subparsers.add_parser(
        "copilot",
        help="Start NeuralSmith CoPilot (interactive assistant)",
    )
    copilot_parser.add_argument(
        "--gemini-key",
        type=str,
        help="Override Gemini API key from config",
    )
    _copilot_mode = copilot_parser.add_mutually_exclusive_group()
    _copilot_mode.add_argument(
        "--agent",
        action="store_true",
        help="Agent mode: model can run read-only tools and propose neuralsmith commands (requires 'yes' to execute training)",
    )
    _copilot_mode.add_argument(
        "--agent-plus",
        action="store_true",
        help="Experimental: like --agent but runs proposed commands without confirmation",
    )

    return parser


def _handle_version() -> int:
    try:
        from importlib.metadata import version, PackageNotFoundError
    except Exception:  # pragma: no cover
        print("neuralsmith (version unknown)")
        return 0

    try:
        pkg_version = version("neuralsmith")
    except PackageNotFoundError:
        pkg_version = "0.0.0"
    print(f"neuralsmith {pkg_version}")
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    from .output import set_verbosity, step, report
    set_verbosity(
        verbose=getattr(args, "verbose", 0),
        quiet=getattr(args, "quiet", False),
    )

    if getattr(args, "version", False):
        return _handle_version()

    if getattr(args, "config_key", False):
        ok = ns_config.configure_api_key_interactive(explicit_path=args.config)
        return 0 if ok else 1

    _cfg = ns_config.load_config(explicit_path=args.config)

    if args.command is None:
        if not args.skip_welcome:
            ns_config.show_welcome_screen()
        if not args.no_auto_copilot:
            # Auto-start CoPilot if no command is given and not skipped
            api_key = ns_config.get_api_key(explicit_path=args.config)
            if not api_key:
                # Prompt user to configure API key
                try:
                    print()
                    response = input("Would you like to configure your Gemini API key now? (y/n): ").strip().lower()
                    if response in ['y', 'yes']:
                        if ns_config.configure_api_key_interactive(explicit_path=args.config):
                            api_key = ns_config.get_api_key(explicit_path=args.config)
                            print()
                            # Start CoPilot after successful configuration
                            if api_key:
                                from .copilot.cli import start_copilot_interactive
                                return start_copilot_interactive(api_key=api_key)
                        else:
                            print("\nAPI key configuration cancelled.")
                    else:
                        print("\nSkipping API key configuration.")
                except (EOFError, KeyboardInterrupt):
                    print("\n\nExiting...")
                    return 0
                
                # If still no API key, show exit message
                if not api_key:
                    print("\nOr press Ctrl+C to exit.")
                    try:
                        # Wait for user input (Ctrl+C will be caught)
                        input()
                    except (EOFError, KeyboardInterrupt):
                        print("\nExiting...")
                        return 0
            else:
                # Start CoPilot immediately if configured
                from .copilot.cli import start_copilot_interactive
                return start_copilot_interactive(api_key=api_key)
        return 0

    cmd = args.command

    if cmd == "image-classification":
        from .image_classification.train import train_image_models_from_args
        from .reporting import generate_training_summary_report
        from .run_status import finish_run, update_run

        with _neural_run_status_context(
            Path(args.output_dir),
            "image-classification",
            extra={"data_path": str(Path(args.data_path).expanduser().resolve())},
        ) as od:
            try:
                update_run(od, phase="training")
                summary = train_image_models_from_args(args)
                best_idx = summary.get("best_model_index")
                best_acc = summary.get("best_test_accuracy")
                step("Image classification experiment complete.")
                step(f"Best model index: {best_idx}, test_accuracy={best_acc}")
                update_run(od, phase="summary")
                generate_training_summary_report(
                    output_dir=Path(args.output_dir),
                    task_type="image-classification",
                    results=summary,
                )
                finish_run(od, success=True)
            except Exception as e:
                finish_run(od, success=False, error=str(e))
                raise
        return 0

    if cmd == "tabular-classification":
        from .tabular.train import train_models as train_tabular
        from .tabular.eda import run_eda
        from .run_status import finish_run, update_run

        with _neural_run_status_context(
            Path(args.output_dir),
            "tabular-classification",
            extra={
                "data_path": str(Path(args.data_path).expanduser().resolve()),
                "target_column": args.target_column,
            },
        ) as od:
            try:
                run_eda_flag = not getattr(args, "no_eda", False)
                if run_eda_flag:
                    update_run(od, phase="eda")
                    step("Running EDA...")
                    eda_ok = run_eda(
                        csv_path=args.data_path,
                        target_column=args.target_column,
                        task="classification",
                        output_dir=args.output_dir,
                    )
                    if not eda_ok:
                        print(
                            "WARNING: EDA failed, continuing with training...",
                            file=sys.stderr,
                        )

                update_run(od, phase="training")
                step("Training models...")

                def _tabular_line(line: str) -> None:
                    update_run(
                        od,
                        last_message=line[-2000:],
                        current_step=line[-500:],
                    )

                train_ok = train_tabular(
                    csv_path=args.data_path,
                    target_column=args.target_column,
                    task="classification",
                    output_dir=args.output_dir,
                    mode=args.mode,
                    train_percent=args.train_percent,
                    val_percent=args.val_percent,
                    test_percent=args.test_percent,
                    random_state=args.random_state,
                    no_eda=getattr(args, "no_eda", False),
                    on_stdout_line=_tabular_line,
                )
                if train_ok:
                    step("Tabular classification experiment complete.")
                    update_run(od, phase="summary")
                    from .reporting import generate_training_summary_report

                    generate_training_summary_report(
                        output_dir=Path(args.output_dir),
                        task_type="tabular-classification",
                    )
                    finish_run(od, success=True)
                    return 0
                print("Tabular classification failed.", file=sys.stderr)
                finish_run(od, success=False, error="Training subprocess failed")
                return 1
            except Exception as e:
                finish_run(od, success=False, error=str(e))
                raise
    
    if cmd == "tabular-regression":
        from .tabular.train import train_models as train_tabular
        from .tabular.eda import run_eda
        from .run_status import finish_run, update_run

        with _neural_run_status_context(
            Path(args.output_dir),
            "tabular-regression",
            extra={
                "data_path": str(Path(args.data_path).expanduser().resolve()),
                "target_column": args.target_column,
            },
        ) as od:
            try:
                run_eda_flag = not getattr(args, "no_eda", False)
                if run_eda_flag:
                    update_run(od, phase="eda")
                    step("Running EDA...")
                    eda_ok = run_eda(
                        csv_path=args.data_path,
                        target_column=args.target_column,
                        task="regression",
                        output_dir=args.output_dir,
                    )
                    if not eda_ok:
                        print(
                            "WARNING: EDA failed, continuing with training...",
                            file=sys.stderr,
                        )

                update_run(od, phase="training")
                step("Training models...")

                def _tabular_line_r(line: str) -> None:
                    update_run(
                        od,
                        last_message=line[-2000:],
                        current_step=line[-500:],
                    )

                train_ok = train_tabular(
                    csv_path=args.data_path,
                    target_column=args.target_column,
                    task="regression",
                    output_dir=args.output_dir,
                    mode=args.mode,
                    train_percent=args.train_percent,
                    val_percent=args.val_percent,
                    test_percent=args.test_percent,
                    random_state=args.random_state,
                    no_eda=getattr(args, "no_eda", False),
                    on_stdout_line=_tabular_line_r,
                )
                if train_ok:
                    step("Tabular regression experiment complete.")
                    update_run(od, phase="summary")
                    from .reporting import generate_training_summary_report

                    generate_training_summary_report(
                        output_dir=Path(args.output_dir),
                        task_type="tabular-regression",
                    )
                    finish_run(od, success=True)
                    return 0
                print("Tabular regression failed.", file=sys.stderr)
                finish_run(od, success=False, error="Training subprocess failed")
                return 1
            except Exception as e:
                finish_run(od, success=False, error=str(e))
                raise
    if cmd == "timeseries-classification":
        from .timeseries.train import train_timeseries_models
        from .run_status import finish_run, update_run

        with _neural_run_status_context(
            Path(args.output_dir),
            "timeseries-classification",
            extra={
                "data_path": str(Path(args.data_path).expanduser().resolve()),
                "time_column": args.time_column,
                "target_column": args.target_column,
                "window_size": args.window_size,
            },
        ) as od:
            try:
                update_run(od, phase="training")
                result = train_timeseries_models(
                    data_path=args.data_path,
                    time_column=args.time_column,
                    target_column=args.target_column,
                    window_size=args.window_size,
                    output_dir=args.output_dir,
                    task="classification",
                    mode=args.mode,
                    train_percent=args.train_percent,
                    val_percent=args.val_percent,
                    test_percent=args.test_percent,
                    random_state=args.random_state,
                    split_method=args.split_method,
                    normalize=not getattr(args, "no_normalize", False),
                    epochs=args.epochs,
                    batch_size=args.batch_size,
                )
                step("Time series classification experiment complete.")
                step(f"Best model: {result['best_model']['model']}")
                if "test_accuracy" in result["best_model"]:
                    step(
                        f"Test accuracy: {result['best_model']['test_accuracy']:.4f}"
                    )
                update_run(od, phase="summary")
                from .reporting import generate_training_summary_report

                generate_training_summary_report(
                    output_dir=Path(args.output_dir),
                    task_type="timeseries-classification",
                    results=result,
                )
                finish_run(od, success=True)
            except Exception as e:
                finish_run(od, success=False, error=str(e))
                raise
        return 0
    
    if cmd == "timeseries-regression":
        from .timeseries.train import train_timeseries_models
        from .run_status import finish_run, update_run

        with _neural_run_status_context(
            Path(args.output_dir),
            "timeseries-regression",
            extra={
                "data_path": str(Path(args.data_path).expanduser().resolve()),
                "time_column": args.time_column,
                "target_column": args.target_column,
                "window_size": args.window_size,
            },
        ) as od:
            try:
                update_run(od, phase="training")
                result = train_timeseries_models(
                    data_path=args.data_path,
                    time_column=args.time_column,
                    target_column=args.target_column,
                    window_size=args.window_size,
                    output_dir=args.output_dir,
                    task="regression",
                    mode=args.mode,
                    train_percent=args.train_percent,
                    val_percent=args.val_percent,
                    test_percent=args.test_percent,
                    random_state=args.random_state,
                    split_method=args.split_method,
                    normalize=not getattr(args, "no_normalize", False),
                    epochs=args.epochs,
                    batch_size=args.batch_size,
                )
                step("Time series regression experiment complete.")
                step(f"Best model: {result['best_model']['model']}")
                if "test_mse" in result["best_model"]:
                    step(f"Test MSE: {result['best_model']['test_mse']:.4f}")
                update_run(od, phase="summary")
                from .reporting import generate_training_summary_report

                generate_training_summary_report(
                    output_dir=Path(args.output_dir),
                    task_type="timeseries-regression",
                    results=result,
                )
                finish_run(od, success=True)
            except Exception as e:
                finish_run(od, success=False, error=str(e))
                raise
        return 0
    if cmd == "auto-labeler":
        from .auto_labeler.cli_wrapper import run_auto_labeler
        from .run_status import finish_run

        out_csv = Path(args.output_path).expanduser().resolve()
        success = False
        with _neural_run_status_context(
            out_csv.parent,
            "auto-labeler",
            extra={
                "output_path": str(out_csv),
                "data_path": str(Path(args.data_path).expanduser().resolve()),
                "data_type": args.data_type,
            },
        ) as od:
            try:
                success = bool(
                    run_auto_labeler(
                        data_path=args.data_path,
                        data_type=args.data_type,
                        labeled_column=args.labeled_column,
                        label_column=args.label_column,
                        output_path=args.output_path,
                        k=args.k,
                        min_confidence=args.min_confidence,
                        exclude_low_confidence=args.exclude_low_confidence,
                        image_model=args.image_model,
                        tabular_reducer=args.tabular_reducer,
                        timeseries_use_minirocket=args.timeseries_use_minirocket,
                    )
                )
                finish_run(
                    od,
                    success=success,
                    error=None if success else "auto-labeler reported failure",
                )
            except Exception as e:
                finish_run(od, success=False, error=str(e))
                raise
        return 0 if success else 1
    if cmd == "copilot":
        from .copilot.cli import start_copilot_interactive

        if not args.skip_welcome:
            ns_config.show_welcome_screen()
        step("Starting CoPilot...")
        api_key = getattr(args, "gemini_key", None) or ns_config.get_api_key(explicit_path=args.config)
        if not api_key:
            print("❌ Gemini API key not configured.")
            print("   Run 'neuralsmith --config-key' to configure your API key.")
            return 1
        copilot_mode = (
            "agent_plus"
            if getattr(args, "agent_plus", False)
            else ("agent" if getattr(args, "agent", False) else "ask")
        )
        return start_copilot_interactive(api_key=api_key, mode=copilot_mode)

    print(f"Unknown command: {cmd}", file=sys.stderr)
    return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())

