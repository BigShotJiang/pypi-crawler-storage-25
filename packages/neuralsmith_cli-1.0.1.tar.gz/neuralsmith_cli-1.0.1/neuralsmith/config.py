"""
Configuration and welcome utilities for the NeuralSmith CLI (CLI-local).

This module is the same concept as the root-level config, but lives
entirely under ``CLI/`` so the CLI package is self-contained here.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

DEFAULT_CONFIG_DIR = Path.home() / ".neuralsmith"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.json"


def _resolve_config_path(explicit_path: Optional[str] = None) -> Path:
    if explicit_path:
        return Path(explicit_path).expanduser()
    return DEFAULT_CONFIG_PATH


def load_config(explicit_path: Optional[str] = None) -> Dict[str, Any]:
    """Load configuration from disk."""
    path = _resolve_config_path(explicit_path)
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(data: Dict[str, Any], explicit_path: Optional[str] = None) -> None:
    """Persist configuration to disk, creating directories as needed."""
    path = _resolve_config_path(explicit_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf8") as f:
        json.dump(data, f, indent=2)


def get_api_key(explicit_path: Optional[str] = None) -> Optional[str]:
    """Return the configured Gemini API key, if any."""
    env_key = os.getenv("NEURALSMITH_GEMINI_API_KEY")
    if env_key:
        return env_key
    cfg = load_config(explicit_path=explicit_path)
    return cfg.get("gemini_api_key")


def save_api_key(api_key: str, explicit_path: Optional[str] = None) -> None:
    """Save API key to config file."""
    cfg = load_config(explicit_path=explicit_path)
    cfg["gemini_api_key"] = api_key
    save_config(cfg, explicit_path=explicit_path)


def check_api_key(explicit_path: Optional[str] = None) -> bool:
    """Check if API key is configured."""
    api_key = get_api_key(explicit_path=explicit_path)
    return api_key is not None and len(api_key.strip()) > 0


def validate_api_key(api_key: str) -> Tuple[bool, str]:
    """
    Validate a Gemini API key by checking format and testing with API.
    
    Returns:
        (is_valid, error_message)
    """
    # Basic format validation
    if not api_key:
        return False, "API key cannot be empty."
    
    api_key = api_key.strip()
    
    # Gemini API keys typically start with "AIza" and are 39 characters
    if len(api_key) < 30 or len(api_key) > 50:
        return False, "Invalid API key format: length should be between 30-50 characters."
    
    if not api_key.startswith("AIza"):
        return False, "Invalid API key format: should start with 'AIza'."
    
    # Test the API key by making a simple API call
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        # Try to create a model instance (this validates the API key)
        # Using Gemma-3-27B instruction-tuned model
        model = genai.GenerativeModel('gemma-3-27b-it')
        # Make a minimal test call with a very short prompt
        try:
            response = model.generate_content(
                "Hi",
                request_options={"timeout": 10}
            )
            # We intentionally avoid using the `.text` quick accessor here,
            # because it can raise if the response has no valid Parts (for
            # example, when fully filtered by safety). For the purposes of
            # validating the API key, the important signal is simply that the
            # call succeeds without an authentication error.
            if hasattr(response, "candidates") and response.candidates:
                candidate = response.candidates[0]
                _ = getattr(candidate, "finish_reason", None)
            # If we get here without an exception, treat the key as valid.
            return True, ""
        except Exception as api_error:
            error_str = str(api_error).lower()
            # Check for various invalid API key indicators
            invalid_keywords = [
                "api_key", "invalid", "unauthorized", "permission", 
                "403", "401", "api key not valid", "authentication",
                "invalid api key", "api key invalid"
            ]
            if any(keyword in error_str for keyword in invalid_keywords):
                return False, f"Invalid API key: Authentication failed. Please check your API key."
            elif "not found" in error_str or "does not exist" in error_str or "model" in error_str:
                # Model not found - might be API key issue or model name issue
                return False, f"Model validation failed: {str(api_error)}. Please check your API key and model name."
            elif "timeout" in error_str or "timed out" in error_str:
                return False, "API key validation timed out. Please check your internet connection."
            else:
                # For any other error, we should fail validation to be safe
                return False, f"API validation error: {str(api_error)}"
    except ImportError:
        return False, "google-generativeai package not installed. Please install it with: pip install google-generativeai"
    except Exception as e:
        error_str = str(e).lower()
        if "api_key" in error_str or "invalid" in error_str or "unauthorized" in error_str:
            return False, f"Invalid API key: {str(e)}"
        else:
            return False, f"Error validating API key: {str(e)}"


def configure_api_key_interactive(explicit_path: Optional[str] = None) -> bool:
    """
    Interactively prompt the user for a Gemini API key, validate it, and save it.
    
    Returns True on success, False if input was empty, invalid, or write failed.
    """
    max_attempts = 3
    
    for attempt in range(max_attempts):
        try:
            if attempt == 0:
                print("To use NeuralSmith CoPilot, you need a Gemini API key.")
                print("You can get one from: https://aistudio.google.com/app/apikey")
            else:
                print(f"\nAttempt {attempt + 1} of {max_attempts}")
            
            api_key = input("Enter your Gemini API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nAPI key configuration cancelled.")
            return False

        if not api_key:
            print("❌ API key cannot be empty. Please try again.")
            continue

        # Validate the API key
        print("Validating API key...")
        is_valid, error_msg = validate_api_key(api_key)
        
        if is_valid:
            # Save the API key
            cfg = load_config(explicit_path=explicit_path)
            cfg["gemini_api_key"] = api_key
            save_config(cfg, explicit_path=explicit_path)
            print("✓ API key validated and saved successfully.")
            return True
        else:
            print(f"❌ {error_msg}")
            if attempt < max_attempts - 1:
                print("Please try again.\n")
            else:
                print(f"\nMaximum attempts ({max_attempts}) reached. Please run 'neuralsmith --config-key' again later.")
                return False
    
    return False


# ANSI color codes for purple and white
PURPLE = "\033[95m"
WHITE = "\033[97m"
GRAY = "\033[90m"
RESET = "\033[0m"

ASCII_ART = f"""{PURPLE}
+==============================================================+
|                                                              |
| {GRAY}##{PURPLE} ███╗   ██╗███████╗██╗   ██╗██████╗  █████╗ ██╗      {GRAY}##{PURPLE}    |
| {GRAY}##{PURPLE} ████╗  ██║██╔════╝██║   ██║██╔══██╗██╔══██╗██║      {GRAY}##{PURPLE}    |
| {GRAY}##{PURPLE} ██╔██╗ ██║█████╗  ██║   ██║██████╔╝███████║██║      {GRAY}##{PURPLE}    |
| {GRAY}##{PURPLE} ██║╚██╗██║██╔══╝  ██║   ██║██╔══██╗██╔══██║██║      {GRAY}##{PURPLE}    |
| {GRAY}##{PURPLE} ██║ ╚████║███████╗╚██████╔╝██║  ██║██║  ██║███████╗ {GRAY}##{PURPLE}    |
| {GRAY}##{PURPLE} ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ {GRAY}##{PURPLE}    |
|                                                              |
| {GRAY}##{WHITE}  ██████╗███╗   ███╗██╗████████╗██╗  ██╗             {GRAY}##{PURPLE}    |
| {GRAY}##{WHITE} ██╔════╝████╗ ████║██║╚══██╔══╝██║  ██║             {GRAY}##{PURPLE}    |
| {GRAY}##{WHITE} ╚█████╗ ██╔████╔██║██║   ██║   ███████║             {GRAY}##{PURPLE}    |
| {GRAY}##{WHITE}  ╚═══██╗██║╚██╔╝██║██║   ██║   ██╔══██║             {GRAY}##{PURPLE}    |
| {GRAY}##{WHITE} ██████╔╝██║ ╚═╝ ██║██║   ██║   ██║  ██║             {GRAY}##{PURPLE}    |
| {GRAY}##{WHITE} ╚═════╝ ╚═╝     ╚═╝╚═╝   ╚═╝   ╚═╝  ╚═╝             {GRAY}##{PURPLE}    |
|                                                              |
+==============================================================+
{RESET}"""

def show_welcome_screen() -> None:
    """Display a clean welcome screen with config status."""
    print(ASCII_ART)
    
    # Header Section
    print(f"{PURPLE}┌{'─' * 62}┐{RESET}")
    print(f"{PURPLE}│{RESET}  {WHITE}SYSTEM: NeuralSmith CLI v1.0{RESET}{' ' * 32}{PURPLE}│{RESET}")
    print(f"{PURPLE}│{RESET}  {GRAY}The AI-Powered Assistant for Automated Machine Learning{RESET}   {PURPLE}  │{RESET}")
    print(f"{PURPLE}└{'─' * 62}┘{RESET}")
    print()

    # Status Section
    api_key_configured = check_api_key()
    
    status_label = f"{WHITE}Configuration Status:{RESET}"
    if api_key_configured:
        status_msg = f"{PURPLE}[ OK ]{RESET}  System Configured"
    else:
        status_msg = f"\033[91m[ !! ]{RESET}  API Key Missing"

    print(f"  {status_label} {status_msg}")
    
    if not api_key_configured:
        print(f"  {GRAY}╰─> Run {WHITE}'neuralsmith --config-key'{GRAY} to setup Gemini API{RESET}")
    
    print(f"\n{'─' * 64}\n")
