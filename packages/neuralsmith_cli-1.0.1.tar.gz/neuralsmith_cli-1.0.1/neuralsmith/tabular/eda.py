"""EDA wrapper for tabular data."""

import subprocess
import sys
from pathlib import Path
from typing import Optional


def run_eda(
    csv_path: str,
    target_column: str,
    task: str,
    output_dir: str,
    sample_eda: bool = False,
) -> bool:
    """
    Run EDA on tabular CSV data.
    
    Args:
        csv_path: Path to CSV file
        target_column: Name of target column
        task: 'classification' or 'regression'
        output_dir: Output directory for EDA report
        sample_eda: Force sampling for EDA on large datasets
        
    Returns:
        True if EDA completed successfully, False otherwise
    """
    script_dir = Path(__file__).parent.parent.parent
    eda_script = script_dir / "Legacy_utils" / "tabular_eda.py"
    
    if not eda_script.exists():
        print(f"ERROR: EDA script not found at {eda_script}", file=sys.stderr)
        return False
    
    args = [
        sys.executable,
        str(eda_script),
        "--csv", str(csv_path),
        "--target", target_column,
        "--task", task,
        "--output", str(output_dir),
    ]
    
    if sample_eda:
        args.append("--sample-eda")
    
    try:
        result = subprocess.run(
            args,
            cwd=str(script_dir),
            capture_output=False,
            text=True,
        )
        return result.returncode == 0
    except Exception as e:
        print(f"ERROR: Failed to run EDA: {e}", file=sys.stderr)
        return False
