"""Tabular data classification and regression wizards."""

from .eda import run_eda
from .train import train_models

__all__ = ["run_eda", "train_models"]
