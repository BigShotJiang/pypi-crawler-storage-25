# Tabular Models

This module powers `neuralsmith tabular-classification` and `neuralsmith tabular-regression`.

## What It Does

- Trains tabular ML models from a CSV file.
- Supports classification and regression tasks.
- Optionally runs EDA before training.
- Saves best-model artifacts and report summaries.

## Commands

### Classification

```bash
neuralsmith tabular-classification \
  --data-path <csv> \
  --target-column <name> \
  [--output-dir <dir>] \
  [--mode fast++|fast|exhaustive] \
  [--train-percent 80.0] \
  [--val-percent 0.0] \
  [--test-percent 20.0] \
  [--random-state 42] \
  [--run-eda | --no-eda]
```

### Regression

```bash
neuralsmith tabular-regression \
  --data-path <csv> \
  --target-column <name> \
  [same options as classification]
```

## Parameters

- `--data-path` (required): source CSV.
- `--target-column` (required): prediction target column.
- `--output-dir`: output root, default `./models`.
- `--mode`:
  - `fast++` -> shortest candidate list,
  - `fast` -> moderate list,
  - `exhaustive` -> broadest search (default).
- `--train-percent`, `--val-percent`, `--test-percent`: split configuration.
- `--random-state`: reproducibility seed.
- `--run-eda` / `--no-eda`: force EDA on/off (default behavior runs EDA unless explicitly disabled).

## EDA Behavior

When enabled, EDA runs first and writes exploratory outputs into the output directory.  
If EDA fails, training still continues with a warning.

## Training Flow

1. Parse/validate command options.
2. Optionally run EDA.
3. Train candidate models based on `--mode`.
4. Select and persist best-performing model artifacts.
5. Generate training summary report files.

## Outputs

Common outputs under `--output-dir`:

- `models/best_model_*/` artifact folder (model + preprocessors/metadata),
- `comparison_table.csv` and related model comparison assets,
- `neuralsmith_run_status.json` and `neuralsmith_run_events.jsonl`,
- `training_summary_report.md` and `training_summary_report.json`.

## Example

```bash
neuralsmith tabular-classification \
  --data-path ./dataset.csv \
  --target-column label \
  --mode fast \
  --output-dir ./results_tabular
```

## Tips

- Keep split percentages sensible and consistent for fair evaluation.
- Use `--no-eda` for rapid iteration when you already trust data quality.
- For production inference, load both trained model and saved preprocessing artifacts.
