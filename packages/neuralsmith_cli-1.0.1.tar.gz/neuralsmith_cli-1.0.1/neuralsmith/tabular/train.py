"""Training wrapper for tabular data."""

import os
import subprocess
import sys
from pathlib import Path
from typing import Callable, Optional


_ASCII_FALLBACK_MAP = str.maketrans(
    {
        "█": "#",
        "▓": "#",
        "▒": "=",
        "░": "-",
        "±": "+/-",
        "×": "x",
        "→": "->",
        "•": "*",
    }
)


def _to_console_safe_text(text: str) -> str:
    """Downgrade common unicode UI glyphs for legacy Windows code pages."""
    return text.translate(_ASCII_FALLBACK_MAP)


def train_models(
    csv_path: str,
    target_column: str,
    task: str,
    output_dir: str,
    mode: str = "exhaustive",
    train_percent: float = 80.0,
    val_percent: float = 0.0,
    test_percent: float = 20.0,
    random_state: int = 42,
    downsample: bool = False,
    no_stratify: bool = False,
    drop_columns: Optional[str] = None,
    sample_eda: bool = False,
    no_eda: bool = False,
    on_stdout_line: Optional[Callable[[str], None]] = None,
) -> bool:
    """
    Train ML models on tabular CSV data.
    
    Args:
        csv_path: Path to CSV file
        target_column: Name of target column
        task: 'classification' or 'regression'
        output_dir: Output directory for models
        mode: Training mode ('fast++', 'fast', 'exhaustive')
        train_percent: Percentage of data for training
        val_percent: Percentage of data for validation
        test_percent: Percentage of data for testing
        random_state: Random seed
        downsample: Downsample to 100k rows
        no_stratify: Disable stratification for classification
        drop_columns: Comma-separated list of columns to drop
        sample_eda: Force sampling for EDA
        no_eda: Skip EDA inside the legacy training script (matches CLI --no-eda)

    Returns:
        True if training completed successfully, False otherwise
    """
    script_dir = Path(__file__).parent.parent.parent
    train_script = script_dir / "Legacy_utils" / "tabular_train.py"
    
    if not train_script.exists():
        print(f"ERROR: Training script not found at {train_script}", file=sys.stderr)
        return False
    
    args = [
        sys.executable,
        str(train_script),
        str(csv_path),
        "--target", target_column,
        "--task", task,
        "--output", str(output_dir),
        "--train-percent", str(train_percent),
        "--val-percent", str(val_percent),
        "--test-percent", str(test_percent),
        "--random-state", str(random_state),
    ]
    
    # Mode flags (mutually exclusive)
    if mode == "fast++":
        args.append("--fastpp")
    elif mode == "fast":
        args.append("--fast")
    else:
        args.append("--exhaustive")
    
    if downsample:
        args.append("--downsample")
    if no_stratify:
        args.append("--no-stratify")
    if drop_columns:
        args.append("--drop-columns")
        args.append(drop_columns)
    if sample_eda:
        args.append("--sample-eda")
    if no_eda:
        args.append("--no-eda")
    
    try:
        child_env = {
            **os.environ,
            "PYTHONUNBUFFERED": "1",
            # Force UTF-8 stdio in the legacy tabular process so symbols in
            # progress/log lines don't crash on Windows code pages.
            "PYTHONIOENCODING": "utf-8",
        }
        if on_stdout_line is None:
            result = subprocess.run(
                args,
                cwd=str(script_dir),
                capture_output=False,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=child_env,
            )
            return result.returncode == 0

        proc = subprocess.Popen(
            args,
            cwd=str(script_dir),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            env=child_env,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            try:
                sys.stdout.write(line)
            except UnicodeEncodeError:
                # Some Windows terminals still use legacy code pages that cannot
                # render Unicode progress glyphs; degrade gracefully instead of
                # crashing the run monitor.
                enc = getattr(sys.stdout, "encoding", None) or "utf-8"
                safe_line = _to_console_safe_text(line)
                safe_line = safe_line.encode(enc, errors="replace").decode(enc, errors="replace")
                sys.stdout.write(safe_line)
            sys.stdout.flush()
            stripped = line.rstrip("\n\r")
            if stripped:
                try:
                    on_stdout_line(stripped)
                except Exception:
                    pass
        proc.wait()
        return proc.returncode == 0
    except Exception as e:
        print(f"ERROR: Failed to run training: {e}", file=sys.stderr)
        return False
