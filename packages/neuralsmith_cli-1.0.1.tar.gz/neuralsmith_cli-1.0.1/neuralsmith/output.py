"""
Shared output helper for CLI verbosity.

Step and report messages respect --quiet; verbose messages require -v.
State is set once at CLI entry via set_verbosity(); modules import step/verbose/report from here.
"""

from __future__ import annotations

import sys
from typing import IO, Callable, Optional

_verbose: int = 0
_quiet: bool = False

# Optional callback for live run status / tooling: (message, kind) where kind is
# "step" | "verbose" | "report".
_progress_callback: Optional[Callable[[str, str], None]] = None


def set_progress_callback(cb: Optional[Callable[[str, str], None]]) -> None:
    """Register or clear a callback invoked for each step/verbose/report line."""
    global _progress_callback
    _progress_callback = cb


def _emit_progress(msg: str, kind: str) -> None:
    if _progress_callback is None:
        return
    try:
        _progress_callback(msg, kind)
    except Exception:
        pass


def set_verbosity(verbose: int = 0, quiet: bool = False) -> None:
    """Set global verbosity. Call once from cli.main() after parsing args."""
    global _verbose, _quiet
    _verbose = verbose
    _quiet = quiet


def verbosity() -> int:
    """Current verbosity level (0 = normal, 1+ = verbose)."""
    return _verbose


def is_quiet() -> bool:
    """Whether quiet mode is enabled."""
    return _quiet


def step(msg: str) -> None:
    """Print one-line step message if not quiet."""
    if not _quiet:
        print(msg, flush=True)
    _emit_progress(msg, "step")


def verbose(msg: str) -> None:
    """Print only if verbose >= 1 and not quiet."""
    if _verbose >= 1 and not _quiet:
        print(msg, flush=True)
    if _verbose >= 1:
        _emit_progress(msg, "verbose")


def report(msg: str, file: Optional[IO[str]] = None) -> None:
    """Print report/final block if not quiet. Default stdout."""
    if not _quiet:
        out = file if file is not None else sys.stdout
        print(msg, file=out, flush=True)
    _emit_progress(msg, "report")
