"""Read-only CoPilot agent tools (filesystem / status / validation)."""

from __future__ import annotations

import contextlib
import io
import os
from pathlib import Path
from typing import Any, Dict, Optional


def _resolve_under_cwd(path: str, cwd: Path) -> Path:
    p = Path(path).expanduser()
    if not p.is_absolute():
        p = (cwd / p).resolve()
    else:
        p = p.resolve()
    return p


def tool_list_path(
    path: str = ".",
    max_depth: int = 2,
    max_entries: int = 100,
    cwd: Optional[str] = None,
) -> str:
    max_depth = max(0, min(int(max_depth), 8))
    max_entries = max(1, min(int(max_entries), 500))
    base = Path(cwd or os.getcwd()).resolve()
    root = _resolve_under_cwd(path, base)
    if not root.exists():
        return f"list_path: path does not exist: {root}"
    lines: list[str] = [f"list_path: {root} (max_depth={max_depth}, cap={max_entries})"]
    n = 0

    def walk(d: Path, depth: int) -> None:
        nonlocal n
        if depth > max_depth or n >= max_entries:
            return
        try:
            entries = sorted(d.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
        except OSError as e:
            lines.append(f"{'  ' * depth}[error reading {d}: {e}]")
            return
        for e in entries:
            if n >= max_entries:
                lines.append(f"{'  ' * depth}... (truncated, max_entries)")
                return
            sym = "/" if e.is_dir() else ""
            lines.append(f"{'  ' * depth}{e.name}{sym}")
            n += 1
            if e.is_dir() and depth < max_depth:
                walk(e, depth + 1)

    if root.is_dir():
        walk(root, 0)
    else:
        lines.append(f"  (file) {root.name}")
    return "\n".join(lines)


def tool_inspect_csv(
    path: str,
    target_column: Optional[str] = None,
    sample_rows: int = 5,
    cwd: Optional[str] = None,
) -> str:
    import pandas as pd

    base = Path(cwd or os.getcwd()).resolve()
    p = _resolve_under_cwd(path, base)
    if not p.is_file():
        return f"inspect_csv: not a file: {p}"
    try:
        df = pd.read_csv(p, nrows=min(max(1, int(sample_rows)), 50))
        full = pd.read_csv(p, nrows=0)
        ncols = len(full.columns)
        # row count without loading all
        with open(p, "rb") as f:
            row_guess = sum(1 for _ in f) - 1
        lines = [
            f"inspect_csv: {p}",
            f"columns ({ncols}): {list(full.columns)}",
            f"approx_row_count_by_newlines: {max(0, row_guess)}",
        ]
        if target_column:
            if target_column in full.columns:
                lines.append(f"target_column {target_column!r}: present")
            else:
                lines.append(f"target_column {target_column!r}: NOT in columns")
        lines.append("sample:")
        lines.append(df.head(sample_rows).to_string())
        return "\n".join(lines)
    except Exception as e:
        return f"inspect_csv: error: {e}"


def tool_inspect_image_folder(path: str, cwd: Optional[str] = None) -> str:
    base = Path(cwd or os.getcwd()).resolve()
    folder = _resolve_under_cwd(path, base)
    if not folder.is_dir():
        return f"inspect_image_folder: not a directory: {folder}"
    image_exts = {".jpg", ".jpeg", ".png", ".bmp", ".tiff"}
    files: list[Path] = []
    for ext in image_exts:
        files.extend(folder.rglob(f"*{ext}"))
        files.extend(folder.rglob(f"*{ext.upper()}"))
    files = list({f.resolve() for f in files})
    subdirs = [d for d in folder.iterdir() if d.is_dir()]
    lines = [
        f"inspect_image_folder: {folder}",
        f"image_file_count: {len(files)}",
        f"immediate_subdirs: {[d.name for d in subdirs[:20]]}{'...' if len(subdirs) > 20 else ''}",
    ]
    if files[:5]:
        lines.append("sample paths:")
        for f in files[:5]:
            lines.append(f"  {f}")
    return "\n".join(lines)


def tool_inspect_numpy_folder(path: str, cwd: Optional[str] = None) -> str:
    try:
        import numpy as np
    except Exception as e:
        return f"inspect_numpy_folder: numpy unavailable: {e}"

    base = Path(cwd or os.getcwd()).resolve()
    folder = _resolve_under_cwd(path, base)
    if not folder.is_dir():
        return f"inspect_numpy_folder: not a directory: {folder}"

    npy_files = sorted(folder.rglob("*.npy"))
    npz_files = sorted(folder.rglob("*.npz"))
    total = len(npy_files) + len(npz_files)
    lines = [
        f"inspect_numpy_folder: {folder}",
        f"numpy_file_count: {total} (.npy={len(npy_files)}, .npz={len(npz_files)})",
    ]
    if total == 0:
        lines.append("No .npy or .npz files found.")
        return "\n".join(lines)

    sample_files = [*npy_files[:3], *npz_files[:3]]
    lines.append("sample details:")
    for p in sample_files:
        rel = p.relative_to(folder)
        try:
            if p.suffix.lower() == ".npy":
                arr = np.load(p, mmap_mode="r", allow_pickle=False)
                lines.append(f"  {rel} -> npy shape={arr.shape} dtype={arr.dtype}")
            else:
                with np.load(p, allow_pickle=False) as z:
                    keys = list(z.files)
                    key_preview = keys[:8]
                    extra = "..." if len(keys) > 8 else ""
                    lines.append(f"  {rel} -> npz arrays={key_preview}{extra} (count={len(keys)})")
        except Exception as e:
            lines.append(f"  {rel} -> error reading file: {e}")
    return "\n".join(lines)


def tool_run_validation(
    kind: str,
    path: str,
    target_column: Optional[str] = None,
    time_column: Optional[str] = None,
    cwd: Optional[str] = None,
) -> str:
    from .validators import validate_csv, validate_image_folder, validate_timeseries_csv

    base = Path(cwd or os.getcwd()).resolve()
    p = _resolve_under_cwd(path, base)
    buf = io.StringIO()
    k = kind.lower().strip()
    with contextlib.redirect_stdout(buf):
        try:
            if k == "csv":
                if not p.is_file():
                    print(f"Not a file: {p}")
                else:
                    validate_csv(str(p), target_column=target_column)
            elif k == "image":
                if not p.is_dir():
                    print(f"Not a directory: {p}")
                else:
                    validate_image_folder(str(p))
            elif k in ("timeseries", "ts"):
                if not p.is_file():
                    print(f"Not a file: {p}")
                elif not time_column:
                    print("time_column is required for timeseries validation")
                else:
                    validate_timeseries_csv(str(p), time_column, target_column)
            else:
                print(f"Unknown kind {kind!r}; use csv, image, or timeseries")
        except Exception as e:
            print(f"Validation error: {e}")
    return buf.getvalue().strip() or "(no validation output)"


def tool_read_run_status(path: Optional[str] = None, cwd: Optional[str] = None) -> str:
    from .status import format_status_summary, read_status_safe, resolve_status_directory

    root = Path(cwd or os.getcwd()).resolve()
    od = resolve_status_directory(path, root)
    if od is None:
        return "read_run_status: no neuralsmith_run_status.json found for that path."
    data, err = read_status_safe(od)
    if err or not data:
        return f"read_run_status: {err or 'could not read status'}"
    return f"read_run_status: directory={od}\n{format_status_summary(data)}"


def tool_watch_run_status(
    path: Optional[str] = None,
    max_iterations: int = 30,
    interval_sec: float = 2.0,
    cwd: Optional[str] = None,
) -> str:
    from .status import resolve_status_directory, watch_status

    root = Path(cwd or os.getcwd()).resolve()
    od = resolve_status_directory(path, root)
    if od is None:
        return "watch_run_status: no neuralsmith_run_status.json found for that path."
    buf = io.StringIO()
    mi = max(1, min(int(max_iterations), 120))
    with contextlib.redirect_stdout(buf):
        watch_status(od, interval_sec=float(interval_sec), max_iterations=mi)
    return buf.getvalue().strip() or "(watch finished with no output)"


def dispatch_readonly_tool(name: str, args: Dict[str, Any], cwd: Optional[str] = None) -> str:
    if not isinstance(args, dict):
        return f"Tool {name}: args must be an object, got {type(args).__name__}"
    try:
        if name == "list_path":
            return tool_list_path(
                str(args.get("path", ".")),
                max_depth=int(args.get("max_depth", 2)),
                max_entries=int(args.get("max_entries", 100)),
                cwd=cwd,
            )
        if name == "inspect_csv":
            if "path" not in args:
                return "inspect_csv: missing required args.path"
            return tool_inspect_csv(
                str(args["path"]),
                target_column=args.get("target_column"),
                sample_rows=int(args.get("sample_rows", 5)),
                cwd=cwd,
            )
        if name == "inspect_image_folder":
            if "path" not in args:
                return "inspect_image_folder: missing required args.path"
            return tool_inspect_image_folder(str(args["path"]), cwd=cwd)
        if name == "inspect_numpy_folder":
            if "path" not in args:
                return "inspect_numpy_folder: missing required args.path"
            return tool_inspect_numpy_folder(str(args["path"]), cwd=cwd)
        if name == "run_validation":
            if "kind" not in args or "path" not in args:
                return "run_validation: requires kind and path"
            return tool_run_validation(
                str(args["kind"]),
                str(args["path"]),
                target_column=args.get("target_column"),
                time_column=args.get("time_column"),
                cwd=cwd,
            )
        if name == "read_run_status":
            return tool_read_run_status(args.get("path"), cwd=cwd)
        if name == "watch_run_status":
            return tool_watch_run_status(
                args.get("path"),
                max_iterations=int(args.get("max_iterations", 30)),
                interval_sec=float(args.get("interval_sec", 2.0)),
                cwd=cwd,
            )
        return f"Unknown read-only tool: {name!r}"
    except Exception as e:
        return f"Tool {name} failed: {e}"
