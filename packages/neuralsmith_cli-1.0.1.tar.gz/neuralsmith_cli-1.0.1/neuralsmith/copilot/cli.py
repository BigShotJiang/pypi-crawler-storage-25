"""Interactive CoPilot CLI implementation."""

import sys
from typing import Optional, List, Dict
import google.generativeai as genai

from ..config import get_api_key
from .system_prompt import SYSTEM_PROMPT
from .validators import validate_csv, validate_image_folder, validate_timeseries_csv
from .ui import box, rule, style
from .status import (
    format_status_summary,
    read_status_safe,
    resolve_status_directory,
    watch_status,
)


def start_copilot_interactive(
    api_key: Optional[str] = None,
    *,
    mode: str = "ask",
) -> int:
    """
    Start interactive CoPilot CLI.

    Args:
        api_key: Optional API key override (if None, loads from config)
        mode: ``ask`` (default), ``agent``, or ``agent_plus`` (experimental)

    Returns:
        Exit code (0 for success, 1 for error)
    """
    if not api_key:
        api_key = get_api_key()
        if not api_key:
            print(style("ERROR: API key not configured. Run 'neuralsmith --config-key' first.", color="red", bold=True))
            return 1
    
    try:
        # Configure Gemini API (works with both Gemini and Gemma models)
        genai.configure(api_key=api_key)
        # Using Gemma-3-27B instruction-tuned model
        model = genai.GenerativeModel('gemma-3-27b-it')
        
        # Actually test the API key by making a test call
        print(style("Validating API key...", color="muted"))
        try:
            test_response = model.generate_content(
                "Hi",
                request_options={"timeout": 10}
            )
            # We don't rely on the .text convenience accessor here because it can
            # raise if the response was fully filtered (no valid Parts). If the
            # API call completed without raising, we treat the key as valid.
            #
            # Still, we lightly inspect the structure so we can detect clearly
            # broken responses in the future if needed.
            if hasattr(test_response, "candidates") and test_response.candidates:
                candidate = test_response.candidates[0]
                # Accessing finish_reason is safe even when content is filtered.
                _ = getattr(candidate, "finish_reason", None)
            # If we reach this point without an exception, consider the key valid.
        except Exception as test_error:
            error_str = str(test_error).lower()
            if any(keyword in error_str for keyword in ["api_key", "invalid", "unauthorized", "permission", "403", "401", "api key not valid"]):
                print(style("ERROR: Invalid API key (authentication failed).", color="red", bold=True))
                print(style("Please run 'neuralsmith --config-key' to configure a valid API key.", color="muted"))
                return 1
            elif "not found" in error_str or "does not exist" in error_str:
                print(style("ERROR: Model 'gemma-3-27b-it' not found or unavailable.", color="red", bold=True))
                print(style(f"Details: {str(test_error)}", color="muted"))
                return 1
            else:
                print(style(f"ERROR: Failed to validate API key: {test_error}", color="red", bold=True))
                return 1
    except Exception as e:
        error_str = str(e).lower()
        if any(keyword in error_str for keyword in ["api_key", "invalid", "unauthorized"]):
            print(style(f"ERROR: Invalid API key: {e}", color="red", bold=True))
            print(style("Please run 'neuralsmith --config-key' to configure a valid API key.", color="muted"))
        else:
            print(style(f"ERROR: Failed to configure API: {e}", color="red", bold=True))
        return 1

    print(rule("NeuralSmith CoPilot", color="cyan"))
    print(style("API authenticated (gemma-3-27b-it)", color="green", bold=True))
    if mode in ("agent", "agent_plus"):
        print(style("Agent tools enabled", color="green"))
        print()
        from .agent_loop import run_agent_loop

        return run_agent_loop(model, mode=mode)

    # Ask mode (default)
    conversation_history: List[Dict[str, str]] = []

    print(style("Streaming enabled", color="green"))
    print(style("Ready for conversations.", color="green"))
    print(style("Type 'help' for commands, 'exit' to quit.", color="muted"))
    print()

    while True:
        try:
            # Read user input
            user_input = input(style("You > ", color="blue", bold=True)).strip()
            
            if not user_input:
                continue
            
            # Handle special commands
            if user_input.lower() in ['exit', 'quit', 'q']:
                print(style("Session ended.", color="muted"))
                break
            
            if user_input.lower() == 'help':
                print_help()
                continue
            
            if user_input.lower().startswith('!validate '):
                # Handle validation commands
                path = user_input[10:].strip()
                handle_validation(path)
                continue

            if user_input.lower().startswith("!status"):
                rest = user_input[len("!status") :].strip()
                handle_run_status(rest or None)
                continue

            if user_input.lower().startswith("!watch"):
                rest = user_input[len("!watch") :].strip()
                handle_run_watch(rest or None)
                continue
            
            # Build prompt with history
            prompt = build_prompt(SYSTEM_PROMPT, conversation_history, user_input)
            
            # Stream response
            print(style("Assistant", color="magenta", bold=True))
            print(rule(color="magenta"))
            sys.stdout.flush()
            
            response_text = ""
            try:
                response = model.generate_content(
                    prompt,
                    stream=True
                )
                
                # Stream chunks to stdout
                for chunk in response:
                    # NOTE:
                    # The google-generativeai client exposes a `.text` convenience
                    # property, but that accessor can raise when there are no
                    # valid Parts (e.g. when fully filtered by safety). To avoid
                    # crashing the CLI with "Invalid operation: response.text",
                    # we *only* read from candidates/content.parts here.

                    if hasattr(chunk, "candidates") and chunk.candidates:
                        for candidate in chunk.candidates:
                            # Stream out any text parts
                            if hasattr(candidate, "content") and hasattr(candidate.content, "parts"):
                                for part in candidate.content.parts:
                                    if hasattr(part, "text") and part.text:
                                        chunk_text = part.text
                                        sys.stdout.write(chunk_text)
                                        sys.stdout.flush()
                                        response_text += chunk_text
                
                if not response_text:
                    # If no text was generated, check the full response
                    try:
                        # Try to get the full response
                        full_response = model.generate_content(prompt)
                        # Avoid the `.text` quick accessor for the same reason as
                        # in the streaming case; instead, pull from candidates.
                        if hasattr(full_response, "candidates") and full_response.candidates:
                            for candidate in full_response.candidates:
                                if hasattr(candidate, "content") and hasattr(candidate.content, "parts"):
                                    for part in candidate.content.parts:
                                        if hasattr(part, "text") and part.text:
                                            part_text = part.text
                                            response_text += part_text
                                            print(part_text, end="")
                    except Exception:
                        pass
                
                print()
                print(rule(color="magenta"))
                print()
                
            except Exception as e:
                print(style(f"\nERROR: Failed to generate response: {e}", color="red", bold=True))
                # Try to provide more helpful error messages
                error_str = str(e).lower()
                if "safety" in error_str or "filter" in error_str:
                    print(style("The response was blocked by content filters. Try rephrasing your question.", color="yellow"))
                elif "quota" in error_str or "rate limit" in error_str:
                    print(style("API quota or rate limit exceeded. Please try again later.", color="yellow"))
                continue
            
            # Save to history (keep last 10 exchanges to avoid token limits)
            conversation_history.append({"role": "user", "text": user_input})
            conversation_history.append({"role": "assistant", "text": response_text})
            if len(conversation_history) > 20:  # Keep last 10 exchanges
                conversation_history = conversation_history[-20:]
            
        except KeyboardInterrupt:
            print("\n" + style("Session ended.", color="muted"))
            break
        except EOFError:
            print("\n" + style("Session ended.", color="muted"))
            break
        except Exception as e:
            print(style(f"\nERROR: {e}", color="red", bold=True))
    
    return 0


def build_prompt(system_prompt: str, history: List[Dict[str, str]], user_input: str) -> str:
    """Build prompt with system prompt and conversation history."""
    if not history:
        return f"{system_prompt}\n\nUser: {user_input}\nAssistant:"
    
    conversation = "\n".join([
        f"{msg['role'].capitalize()}: {msg['text']}"
        for msg in history
    ])
    return f"{system_prompt}\n\n{conversation}\nUser: {user_input}\nAssistant:"


def print_help() -> None:
    """Print help message with available commands."""
    help_text = """help              - Show this help message
exit / quit / q   - Exit CoPilot
!validate <path>  - Validate a data file/folder
!status [path]    - Show live run status (neuralsmith_run_status.json)
!watch [path]     - Poll run status every 2s until finished (Ctrl+C to stop)

Example Questions:
- "How do I train an image classification model?"
- "What options does tabular-classification support?"
- "How do I preprocess time series data?"
- "What's the difference between fast and exhaustive modes?"
"""
    print(box("CoPilot Commands", help_text, color="cyan"))


def handle_run_status(user_path: Optional[str]) -> None:
    """Print snapshot from neuralsmith_run_status.json."""
    from pathlib import Path

    root = Path.cwd()
    od = resolve_status_directory(user_path, root)
    if od is None:
        if user_path:
            print(style(f"No {user_path!r} run status found (expected neuralsmith_run_status.json).", color="yellow"))
        else:
            print(style("No neuralsmith_run_status.json found under the current directory tree.", color="yellow"))
        return
    data, err = read_status_safe(od)
    if err or not data:
        print(style(err or "Could not read status.", color="red"))
        return
    print(box("Run Status", f"Status directory: {od}\n\n{format_status_summary(data)}", color="cyan"))


def handle_run_watch(user_path: Optional[str]) -> None:
    """Poll run status until completed/failed."""
    from pathlib import Path

    root = Path.cwd()
    od = resolve_status_directory(user_path, root)
    if od is None:
        if user_path:
            print(style(f"No {user_path!r} run status found (expected neuralsmith_run_status.json).", color="yellow"))
        else:
            print(style("No neuralsmith_run_status.json found under the current directory tree.", color="yellow"))
        return
    print(box("Status Watch", f"Watching: {od}\nPress Ctrl+C to stop.", color="cyan"))
    print()
    watch_status(od, interval_sec=2.0)


def handle_validation(path: str) -> None:
    """Handle validation command."""
    from pathlib import Path
    
    path_obj = Path(path)
    
    if not path_obj.exists():
        print(style(f"ERROR: Path does not exist: {path}", color="red", bold=True))
        return
    
    if path_obj.is_file():
        if path_obj.suffix.lower() == '.csv':
            print(box("Validation", f"Validating CSV: {path}", color="cyan"))
            validate_csv(str(path_obj))
        else:
            print(style(f"ERROR: Unsupported file type: {path_obj.suffix}", color="red", bold=True))
    elif path_obj.is_dir():
        # Check if it looks like an image folder
        image_exts = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff'}
        has_images = any(f.suffix.lower() in image_exts for f in path_obj.rglob('*') if f.is_file())
        
        if has_images:
            print(box("Validation", f"Validating image folder: {path}", color="cyan"))
            validate_image_folder(str(path_obj))
        else:
            print(style("Directory does not appear to contain images. Checking as time series.", color="yellow"))
            # Could be time series - would need CSV files
            csv_files = list(path_obj.glob('*.csv'))
            if csv_files:
                print(style("Found CSV files. Please specify which one to validate.", color="yellow"))
            else:
                print(style("ERROR: Directory does not appear to contain images or CSVs.", color="red", bold=True))
    else:
        print(style(f"ERROR: Invalid path type: {path}", color="red", bold=True))
