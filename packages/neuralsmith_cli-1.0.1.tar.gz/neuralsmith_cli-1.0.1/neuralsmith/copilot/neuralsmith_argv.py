"""
Build argv for `python -m neuralsmith <subcommand> ...` from allowlisted flags only.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, FrozenSet, List, Optional, Tuple, Union

# Subcommand -> allowed flag names (without leading --), matching argparse dest hyphenation.
SUBCOMMAND_ALLOWED_FLAGS: Dict[str, FrozenSet[str]] = {
    "image-classification": frozenset(
        {
            "data-path",
            "output-dir",
            "target-size",
            "val-split",
            "epochs",
            "batch-size",
            "learning-rate",
            "early-stopping-patience",
            "reduce-lr-patience",
            "normalize",
            "no-normalize",
            "device",
            "seed",
        }
    ),
    "tabular-classification": frozenset(
        {
            "data-path",
            "target-column",
            "output-dir",
            "mode",
            "train-percent",
            "val-percent",
            "test-percent",
            "random-state",
            "run-eda",
            "no-eda",
        }
    ),
    "tabular-regression": frozenset(
        {
            "data-path",
            "target-column",
            "output-dir",
            "mode",
            "train-percent",
            "val-percent",
            "test-percent",
            "random-state",
            "run-eda",
            "no-eda",
        }
    ),
    "timeseries-classification": frozenset(
        {
            "data-path",
            "time-column",
            "target-column",
            "window-size",
            "output-dir",
            "mode",
            "train-percent",
            "val-percent",
            "test-percent",
            "random-state",
            "epochs",
            "batch-size",
            "split-method",
            "no-normalize",
        }
    ),
    "timeseries-regression": frozenset(
        {
            "data-path",
            "time-column",
            "target-column",
            "window-size",
            "output-dir",
            "mode",
            "train-percent",
            "val-percent",
            "test-percent",
            "random-state",
            "epochs",
            "batch-size",
            "split-method",
            "no-normalize",
        }
    ),
    "auto-labeler": frozenset(
        {
            "data-path",
            "data-type",
            "labeled-column",
            "label-column",
            "output-path",
            "k",
            "min-confidence",
            "exclude-low-confidence",
            "image-model",
            "tabular-reducer",
            "timeseries-use-minirocket",
        }
    ),
}

SUBCOMMAND_REQUIRED_FLAGS: Dict[str, FrozenSet[str]] = {
    "image-classification": frozenset({"data-path"}),
    "tabular-classification": frozenset({"data-path", "target-column"}),
    "tabular-regression": frozenset({"data-path", "target-column"}),
    "timeseries-classification": frozenset({"data-path", "target-column"}),
    "timeseries-regression": frozenset({"data-path", "target-column"}),
    "auto-labeler": frozenset(
        {
            "data-path",
            "data-type",
            "labeled-column",
            "label-column",
            "output-path",
        }
    ),
}

MODE_CHOICES = frozenset({"fast++", "fast", "exhaustive"})
DEVICE_CHOICES = frozenset({"cpu", "cuda"})
SPLIT_METHOD_CHOICES = frozenset({"temporal", "random"})
DATA_TYPE_CHOICES = frozenset({"image", "tabular", "timeseries"})
IMAGE_MODEL_CHOICES = frozenset({"mobilenet_v2", "resnet18"})
TABULAR_REDUCER_CHOICES = frozenset({"pca", "umap", "incremental_pca"})

BOOL_ONLY_FLAGS = frozenset(
    {
        "normalize",
        "no-normalize",
        "run-eda",
        "no-eda",
        "exclude-low-confidence",
        "timeseries-use-minirocket",
    }
)


def _resolve_path_value(raw: Union[str, Path], base: Path) -> str:
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = (base / p).resolve()
    else:
        p = p.resolve()
    return str(p)


def _is_path_like_flag(key: str) -> bool:
    return key in ("data-path", "output-dir", "output-path")


def build_neuralsmith_argv(
    subcommand: str,
    flags: Dict[str, Any],
    *,
    cwd: Optional[Union[str, Path]] = None,
) -> Tuple[Optional[List[str]], Optional[str]]:
    """
    Returns (argv, error). argv starts with sys.executable, '-m', 'neuralsmith', subcommand.
    """
    if subcommand not in SUBCOMMAND_ALLOWED_FLAGS:
        return None, f"Unknown or disallowed subcommand: {subcommand!r}"

    allowed = SUBCOMMAND_ALLOWED_FLAGS[subcommand]
    required = SUBCOMMAND_REQUIRED_FLAGS[subcommand]
    base = Path(cwd or Path.cwd()).resolve()

    if not isinstance(flags, dict):
        return None, "flags must be a JSON object mapping flag names to values"

    unknown = set(flags.keys()) - allowed
    if unknown:
        return None, f"Unknown flag(s) for {subcommand}: {sorted(unknown)}"

    missing = required - set(flags.keys())
    if missing:
        return None, f"Missing required flag(s) for {subcommand}: {sorted(missing)}"

    if flags.get("normalize") and flags.get("no-normalize"):
        return None, "Cannot set both normalize and no-normalize"

    if flags.get("run-eda") and flags.get("no-eda"):
        return None, "Cannot set both run-eda and no-eda"

    for key, val in flags.items():
        if key == "mode" and val not in MODE_CHOICES:
            return None, f"Invalid mode: {val!r} (allowed: {sorted(MODE_CHOICES)})"
        if key == "device" and val not in DEVICE_CHOICES:
            return None, f"Invalid device: {val!r}"
        if key == "split-method" and val not in SPLIT_METHOD_CHOICES:
            return None, f"Invalid split-method: {val!r}"
        if key == "data-type" and val not in DATA_TYPE_CHOICES:
            return None, f"Invalid data-type: {val!r}"
        if key == "image-model" and val not in IMAGE_MODEL_CHOICES:
            return None, f"Invalid image-model: {val!r}"
        if key == "tabular-reducer" and val not in TABULAR_REDUCER_CHOICES:
            return None, f"Invalid tabular-reducer: {val!r}"

    argv: List[str] = [sys.executable, "-m", "neuralsmith", subcommand]

    # Stable order: required keys first, then sorted rest
    ordered_keys = sorted(flags.keys(), key=lambda k: (k not in required, k))
    for key in ordered_keys:
        val = flags[key]
        opt = f"--{key}"

        if key in BOOL_ONLY_FLAGS:
            if val is True:
                argv.append(opt)
            elif val is False or val is None:
                continue
            else:
                return None, f"Flag {key!r} expects a boolean, got {val!r}"
        else:
            if val is True or val is False:
                return None, f"Flag {key!r} expects a value, not boolean {val}"
            if val is None:
                return None, f"Missing value for {key!r}"
            sval = str(val).strip()
            if not sval:
                return None, f"Empty value for {key!r}"
            if _is_path_like_flag(key):
                sval = _resolve_path_value(sval, base)
            argv.extend([opt, sval])

    return argv, None


def format_argv_for_display(argv: List[str]) -> str:
    try:
        import shlex

        return shlex.join(argv)
    except Exception:
        return " ".join(argv)
