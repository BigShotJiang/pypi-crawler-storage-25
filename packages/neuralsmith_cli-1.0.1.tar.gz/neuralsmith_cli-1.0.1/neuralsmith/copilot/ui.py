"""Lightweight terminal UI helpers for CoPilot output."""

from __future__ import annotations

import os
import shutil
import sys
import textwrap
from typing import Optional

RESET = "\033[0m"
COLORS = {
    "muted": "\033[90m",
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "magenta": "\033[35m",
    "cyan": "\033[36m",
    "white": "\033[37m",
}


def _supports_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("TERM", "").lower() == "dumb":
        return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


USE_COLOR = _supports_color()


def style(text: str, *, color: Optional[str] = None, bold: bool = False, dim: bool = False) -> str:
    """Apply ANSI style if the terminal supports it."""
    if not USE_COLOR:
        return text
    prefix = ""
    if bold:
        prefix += "\033[1m"
    if dim:
        prefix += "\033[2m"
    if color in COLORS:
        prefix += COLORS[color]
    if not prefix:
        return text
    return f"{prefix}{text}{RESET}"


def rule(label: str = "", *, color: str = "muted") -> str:
    """Horizontal rule with optional centered label."""
    width = max(60, min(110, shutil.get_terminal_size((100, 20)).columns))
    if not label:
        line = "─" * width
        return style(line, color=color)

    marker = f" {label} "
    pad = max(0, width - len(marker))
    left = "─" * (pad // 2)
    right = "─" * (pad - len(left))
    return style(f"{left}{marker}{right}", color=color, bold=True)


def box(title: str, body: str, *, color: str = "cyan") -> str:
    """Render a simple boxed section with wrapped content."""
    width = max(60, min(110, shutil.get_terminal_size((100, 20)).columns))
    inner = max(20, width - 4)
    # Keep the top border width equal to `width`; previous math was one char short.
    top = f"┌─ {title} " + "─" * max(0, inner - len(title) - 1) + "┐"
    bottom = "└" + ("─" * (width - 2)) + "┘"
    rows = []
    for raw_line in (body or "").splitlines() or [""]:
        wrapped = textwrap.wrap(
            raw_line,
            width=inner,
            replace_whitespace=False,
            drop_whitespace=False,
        )
        if not wrapped:
            wrapped = [""]
        for line in wrapped:
            rows.append(f"│ {line.ljust(inner)} │")
    return "\n".join([style(top, color=color, bold=True), *rows, style(bottom, color=color, bold=True)])
