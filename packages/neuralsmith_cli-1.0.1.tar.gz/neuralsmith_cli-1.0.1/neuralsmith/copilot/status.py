"""CoPilot helpers to read NeuralSmith run status files."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..run_status import (
    STATUS_FILENAME,
    discover_status_files,
    read_status,
    status_path,
)


def resolve_status_directory(user_path: Optional[str], search_root: Path) -> Optional[Path]:
    """
    Resolve directory that should contain neuralsmith_run_status.json.
    If user_path is a file, use its parent. If it's a directory, use it.
    If None, pick newest status under search_root.
    """
    if user_path:
        p = Path(user_path).expanduser().resolve()
        if p.is_file():
            p = p.parent
        if not p.is_dir():
            return None
        if status_path(p).is_file():
            return p
        # Maybe user passed parent — walk up a few levels
        cur = p
        for _ in range(4):
            if status_path(cur).is_file():
                return cur
            if cur.parent == cur:
                break
            cur = cur.parent
        return None

    found = discover_status_files(search_root, max_depth=8)
    if not found:
        return None
    return found[0].parent


def format_status_summary(data: Dict[str, Any]) -> str:
    """Human-readable block from status snapshot."""
    lines = [
        f"command: {data.get('command', '?')}",
        f"state: {data.get('state', '?')}",
        f"phase: {data.get('phase', '?')}",
        f"updated_at: {data.get('updated_at', '?')}",
        f"current_step: {data.get('current_step', '')}",
        f"last_message: {data.get('last_message', '')}",
    ]
    err = data.get("error")
    if err:
        lines.append(f"error: {err}")
    prog = data.get("progress")
    if isinstance(prog, dict) and prog:
        try:
            lines.append("progress: " + json.dumps(prog, ensure_ascii=False)[:500])
        except Exception:
            lines.append(f"progress: {prog!r}"[:500])
    return "\n".join(lines)


def read_status_safe(output_dir: Path) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    data = read_status(output_dir)
    if data is None:
        return None, f"No readable {STATUS_FILENAME} under {output_dir}"
    return data, None


def watch_status(
    output_dir: Path,
    *,
    interval_sec: float = 2.0,
    max_iterations: Optional[int] = None,
) -> None:
    """Poll status file until completed/failed or interrupted."""
    last_sig: Optional[str] = None
    n = 0
    while True:
        data, err = read_status_safe(output_dir)
        if err:
            print(err)
            return
        sig = json.dumps(
            {
                "state": data.get("state"),
                "phase": data.get("phase"),
                "updated_at": data.get("updated_at"),
                "last_message": data.get("last_message"),
            },
            sort_keys=True,
        )
        if sig != last_sig:
            print("\n--- run status ---")
            print(format_status_summary(data))
            last_sig = sig
        state = data.get("state")
        if state in ("completed", "failed"):
            return
        n += 1
        if max_iterations is not None and n >= max_iterations:
            print("(watch ended: max iterations)")
            return
        try:
            time.sleep(interval_sec)
        except KeyboardInterrupt:
            print("\n(watch stopped)")
            return
