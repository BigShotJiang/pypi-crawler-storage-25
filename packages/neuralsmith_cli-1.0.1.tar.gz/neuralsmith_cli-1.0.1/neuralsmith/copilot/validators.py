"""Validation helpers for CoPilot."""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Optional


def validate_csv(csv_path: str, target_column: Optional[str] = None) -> None:
    """
    Validate a CSV file and print results.
    
    Args:
        csv_path: Path to CSV file
        target_column: Optional target column name to check
    """
    try:
        df = pd.read_csv(csv_path)
        
        print(f"✓ CSV file found: {csv_path}")
        print(f"✓ Contains {len(df)} rows, {len(df.columns)} columns")
        print(f"✓ Columns: {', '.join(df.columns[:10])}{'...' if len(df.columns) > 10 else ''}")
        
        if target_column:
            if target_column in df.columns:
                print(f"✓ Target column '{target_column}' found")
                missing = df[target_column].isna().sum()
                if missing > 0:
                    print(f"⚠️  {missing} missing values in target column")
                else:
                    print(f"✓ No missing values in target column")
                
                # Check data type
                dtype = df[target_column].dtype
                print(f"✓ Target column type: {dtype}")
                
                if dtype in ['object', 'category'] or df[target_column].nunique() < 20:
                    print(f"✓ Appears to be classification task ({df[target_column].nunique()} unique values)")
                else:
                    print(f"✓ Appears to be regression task")
            else:
                print(f"❌ Target column '{target_column}' not found")
        
        # Check for missing values
        missing_cols = df.isna().sum()
        if missing_cols.sum() > 0:
            print(f"⚠️  Missing values found in {missing_cols[missing_cols > 0].count()} columns")
        else:
            print(f"✓ No missing values")
        
        print("✓ CSV validation complete")
        
    except Exception as e:
        print(f"❌ Error validating CSV: {e}")


def validate_image_folder(folder_path: str) -> None:
    """
    Validate an image folder and print results.
    
    Args:
        folder_path: Path to image folder
    """
    try:
        from PIL import Image
        
        folder = Path(folder_path)
        image_exts = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff'}
        
        # Find all images
        image_files = []
        for ext in image_exts:
            image_files.extend(folder.rglob(f'*{ext}'))
            image_files.extend(folder.rglob(f'*{ext.upper()}'))
        
        if not image_files:
            print(f"❌ No image files found in {folder_path}")
            return
        
        print(f"✓ Image folder found: {folder_path}")
        print(f"✓ Found {len(image_files)} image files")
        
        # Check folder structure
        subdirs = [d for d in folder.iterdir() if d.is_dir()]
        if subdirs:
            print(f"✓ Found {len(subdirs)} subdirectories (likely class folders)")
            for subdir in subdirs[:5]:
                subdir_images = [f for f in subdir.rglob('*') if f.suffix.lower() in image_exts]
                print(f"  - {subdir.name}: {len(subdir_images)} images")
        else:
            print(f"✓ Flat folder structure (all images in root)")
        
        # Sample a few images to check format
        sample_size = min(5, len(image_files))
        sizes = []
        for img_file in image_files[:sample_size]:
            try:
                with Image.open(img_file) as img:
                    sizes.append(img.size)
            except Exception as e:
                print(f"⚠️  Warning: Could not read {img_file.name}: {e}")
        
        if sizes:
            avg_size = (sum(s[0] for s in sizes) // len(sizes), sum(s[1] for s in sizes) // len(sizes))
            print(f"✓ Average image size (sample): {avg_size[0]}x{avg_size[1]}")
        
        print("✓ Image folder validation complete")
        
    except ImportError:
        print("❌ PIL/Pillow not available for image validation")
    except Exception as e:
        print(f"❌ Error validating image folder: {e}")


def validate_timeseries_csv(csv_path: str, time_column: str, target_column: Optional[str] = None) -> None:
    """
    Validate a time series CSV file and print results.
    
    Args:
        csv_path: Path to CSV file
        time_column: Name of time column
        target_column: Optional target column name
    """
    try:
        df = pd.read_csv(csv_path)
        
        print(f"✓ Time series CSV found: {csv_path}")
        print(f"✓ Contains {len(df)} rows, {len(df.columns)} columns")
        
        if time_column not in df.columns:
            print(f"❌ Time column '{time_column}' not found")
            return
        
        print(f"✓ Time column '{time_column}' found")
        
        # Check if time column is sorted
        if df[time_column].is_monotonic_increasing:
            print(f"✓ Time column is sorted (monotonic increasing)")
        else:
            print(f"⚠️  Time column is not sorted - will be sorted during preprocessing")
        
        if target_column:
            if target_column in df.columns:
                print(f"✓ Target column '{target_column}' found")
            else:
                print(f"❌ Target column '{target_column}' not found")
        
        # Check for feature columns
        feature_cols = [c for c in df.columns if c not in [time_column, target_column] if target_column]
        print(f"✓ Found {len(feature_cols)} feature columns")
        
        print("✓ Time series CSV validation complete")
        
    except Exception as e:
        print(f"❌ Error validating time series CSV: {e}")
