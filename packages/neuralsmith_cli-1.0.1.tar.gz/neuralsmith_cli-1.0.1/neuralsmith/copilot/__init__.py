"""CoPilot interactive assistant for NeuralSmith CLI."""

from .cli import start_copilot_interactive

__all__ = ["start_copilot_interactive"]
