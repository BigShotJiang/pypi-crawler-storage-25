# CoPilot

NeuralSmith CoPilot is an interactive assistant exposed by:

```bash
neuralsmith copilot
```

It supports chat-based guidance plus utility commands for validation and run monitoring.

## Modes

- `ask` (default): conversational help only.
- `agent`: enables read-only tools and command proposals; training execution requires explicit `yes`.
- `agent_plus` (experimental): similar to agent mode, but runs proposed commands without confirmation.

CLI flags:

```bash
neuralsmith copilot [--gemini-key <key>] [--agent | --agent-plus]
```

## Exactly How `--agent` Mode Works

When you start `neuralsmith copilot --agent`, CoPilot switches from plain chat to a tool-driven loop:

1. Your message is sent with an agent-specific system prompt.
2. The model may emit one or more tool calls in a strict JSON fence format.
3. CoPilot executes those calls and feeds tool output back to the model.
4. This repeats for up to 15 internal tool turns, or until the model returns a normal answer without tool JSON.

### Tools Available In Agent Mode

Read-only tools (run immediately, no confirmation):

- `list_path`
- `inspect_csv`
- `inspect_image_folder`
- `inspect_numpy_folder`
- `run_validation`
- `read_run_status`
- `watch_run_status`

Training tool:

- `run_neuralsmith` (subprocess runner for NeuralSmith commands)

### `run_neuralsmith` Confirmation Behavior (Important)

In `--agent` mode, every `run_neuralsmith` request pauses for approval:

- Terminal prompt: `Approve command? Type 'yes' to run:`
- Only `yes` or `y` executes the command.
- Any other input cancels execution.
- CoPilot then reports whether command was executed and the resulting exit code.

In `--agent-plus`, the same `run_neuralsmith` call runs without this confirmation prompt.

### Allowed Training Subcommands In Agent Mode

`run_neuralsmith` is allowlisted to these subcommands only:

- `image-classification`
- `tabular-classification`
- `tabular-regression`
- `timeseries-classification`
- `timeseries-regression`
- `auto-labeler`

Flags are passed as a JSON object (`flag-name-without-dashes -> value`).  
Boolean switches are included with `true` (for example `"no-eda": true`).

### Prompting + History Behavior In Agent Mode

- Conversation history is retained as the last 10 exchanges (20 messages max).
- Built-in bang commands (`!validate`, `!status`, `!watch`) still work directly in agent mode.
- If the model has enough info, it can respond directly without any tool call.

## Built-in Commands Inside CoPilot

- `help` - show command help.
- `exit`, `quit`, `q` - end session.
- `!validate <path>` - validate CSV/image folder/time-series input hints.
- `!status [path]` - read latest run snapshot.
- `!watch [path]` - poll live run status every ~2 seconds.

## API Key and Model

- API key comes from:
  - `--gemini-key`, or
  - configured value in NeuralSmith config.
- Session startup validates API credentials before entering chat loop.
- Current implementation uses `gemma-3-27b-it` via `google-generativeai`.

## How Prompting Works

- CoPilot prepends a system prompt and recent conversation history.
- In ask mode, responses stream incrementally to terminal.
- History is kept to a bounded window to limit context growth.

## Agent Safety Behavior

- Agent modes are intended to assist workflow automation.
- `--agent` is safer for most use since it requires explicit confirmation for training execution.
- `--agent-plus` should only be used in trusted local environments.

## Example Session

```text
neuralsmith copilot --agent
!validate tests/data/tabular_classification/iris_like_100.csv
Train a quick tabular classification model on tests/data/tabular_classification/iris_like_100.csv using target column species and mode fast.
```

## Troubleshooting

- If startup says API key is missing/invalid, run:
  - `neuralsmith --config-key`
- If no run status is found for `!status` or `!watch`, verify the command used an expected output directory and that `neuralsmith_run_status.json` exists.
