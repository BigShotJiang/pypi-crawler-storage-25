"""
NeuralSmith CLI Python package (CLI-local version).

This package lives entirely under the ``CLI/`` directory and reuses the
Python assets in ``CLI/Legacy_utils`` for training logic.
"""

from .model_loader import load_model, preprocess_data

__all__ = ['load_model', 'preprocess_data']

