# NeuralSmith Package Docs

This folder contains the implementation for all NeuralSmith CLI features.

## Functionality Guides

- `image_classification/README.md` - image training pipeline, inputs, flags, outputs, and troubleshooting.
- `tabular/README.md` - tabular classification/regression, EDA behavior, modes, and artifacts.
- `timeseries/README.md` - time series preprocessing/training flow for classification and regression.
- `auto_labeler/README.md` - weighted KNN auto-labeling for image/tabular/time-series datasets.
- `copilot/README.md` - interactive CoPilot usage, commands, agent modes, and safety notes.

## Core Files In This Folder

- `cli.py` - top-level argument parsing and command dispatch.
- `config.py` - API key and local configuration handling.
- `model_loader.py` - utilities for loading trained artifacts.
- `reporting.py` - generates `training_summary_report.md` and `training_summary_report.json`.
- `run_status.py` - live run snapshots written to `neuralsmith_run_status.json`.
- `output.py` - structured terminal output helpers used by workflows.

## How These Pieces Work Together

1. `neuralsmith <command> ...` is parsed by `cli.py`.
2. Command-specific modules run training/labeling.
3. Progress snapshots are updated via run status helpers.
4. A training summary report is generated after successful runs.

For command examples and end-to-end quick starts, see the repository-level `README.md`.
