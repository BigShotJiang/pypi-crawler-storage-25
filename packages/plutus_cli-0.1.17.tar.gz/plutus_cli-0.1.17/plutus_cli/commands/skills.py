"""Skills management commands."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("skills", invoke_without_command=True)
@click.pass_context
def skills_cmd(ctx: click.Context) -> None:
    """Browse, import, and export Plutus skills."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@skills_cmd.command("list")
@click.option("--category", "-c", default=None, help="Filter by category")
def list_skills(category: str | None) -> None:
    """List available skills."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_skills(category=category)
            skills = data if isinstance(data, list) else data.get("skills", [])
            if not skills:
                display.muted("No skills found.")
                return
            rows = []
            for s in skills:
                rows.append(
                    {
                        "name": s.get("name", ""),
                        "category": s.get("category", ""),
                        "description": (s.get("description", "") or "")[:50],
                    }
                )
            display.print_table(
                rows,
                [("name", "Name"), ("category", "Category"), ("description", "Description")],
                title="Skills",
            )
        finally:
            await client.close()

    _run(_run_it())


@skills_cmd.command("info")
@click.argument("name")
def skill_info(name: str) -> None:
    """Show details for a specific skill."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_skill_detail(name)
            pairs = [
                ("Name", data.get("name", "")),
                ("Category", data.get("category", "")),
                ("Description", data.get("description", "")),
            ]
            display.print_kv(pairs, title=f"Skill: {name}")
        finally:
            await client.close()

    _run(_run_it())


@skills_cmd.command("export")
@click.argument("name")
@click.option("--output", "-o", default=None, help="Output file path")
def export_skill(name: str, output: str | None) -> None:
    """Export a skill to a JSON file."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.export_skill(name)
            out_path = output or f"{name}.skill.json"
            Path(out_path).write_text(json.dumps(data, indent=2), encoding="utf-8")
            display.success(f"Skill exported to {out_path}")
        finally:
            await client.close()

    _run(_run_it())


@skills_cmd.command("import")
@click.argument("file_path", type=click.Path(exists=True))
def import_skill(file_path: str) -> None:
    """Import a skill from a JSON file."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = json.loads(Path(file_path).read_text(encoding="utf-8"))
            result = await client.import_skill(data)
            display.success(f"Skill imported: {result.get('name', file_path)}")
        finally:
            await client.close()

    _run(_run_it())


@skills_cmd.command("delete")
@click.argument("name")
@click.confirmation_option(prompt="Delete this skill?")
def delete_skill(name: str) -> None:
    """Delete a skill."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.delete_skill(name)
            display.success(f"Skill '{name}' deleted.")
        finally:
            await client.close()

    _run(_run_it())
