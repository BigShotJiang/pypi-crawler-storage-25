"""Configuration, settings, guardrails, and billing commands."""

from __future__ import annotations

import asyncio

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("config", invoke_without_command=True)
@click.pass_context
def config_cmd(ctx: click.Context) -> None:
    """Manage Plutus settings, model routing, API keys, and guardrails."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ---------------------------------------------------------------------------
# Model routing
# ---------------------------------------------------------------------------


@config_cmd.command("model")
@click.option("--provider", "-p", default=None, help="Set AI provider (anthropic, openai)")
@click.option("--model", "-m", default=None, help="Set model name")
def model_routing(provider: str | None, model: str | None) -> None:
    """View or update model routing configuration."""

    async def _run_it():
        client = PlutusClient()
        try:
            if provider or model:
                patch = {}
                if provider:
                    patch["provider"] = provider
                if model:
                    patch["model"] = model
                await client.update_model_routing(patch)
                display.success("Model routing updated.")
            data = await client.get_model_routing()
            pairs = [
                ("Provider", data.get("provider", "")),
                ("Model", data.get("model", data.get("default_model", ""))),
            ]
            display.print_kv(pairs, title="Model Routing")
        finally:
            await client.close()

    _run(_run_it())


# ---------------------------------------------------------------------------
# API keys
# ---------------------------------------------------------------------------


@config_cmd.command("keys")
def list_keys() -> None:
    """Show configured API key status."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_key_status()
            providers = data.get("providers", {})
            rows = []
            for name, configured in providers.items():
                rows.append(
                    {
                        "provider": name,
                        "status": "Configured" if configured else "Not set",
                    }
                )
            display.print_table(
                rows,
                [("provider", "Provider"), ("status", "Status")],
                title="API Keys",
            )
        finally:
            await client.close()

    _run(_run_it())


@config_cmd.command("set-key")
@click.argument("provider")
@click.argument("key")
def set_key(provider: str, key: str) -> None:
    """Set an API key for a provider."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.set_key(provider, key)
            display.success(f"API key for '{provider}' saved.")
        finally:
            await client.close()

    _run(_run_it())


@config_cmd.command("delete-key")
@click.argument("provider")
@click.confirmation_option(prompt="Delete this API key?")
def delete_key(provider: str) -> None:
    """Delete an API key for a provider."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.delete_key(provider)
            display.success(f"API key for '{provider}' removed.")
        finally:
            await client.close()

    _run(_run_it())


# ---------------------------------------------------------------------------
# Guardrails
# ---------------------------------------------------------------------------


@click.group("guardrails", invoke_without_command=True)
@click.pass_context
def guardrails_cmd(ctx: click.Context) -> None:
    """Manage tool guardrails and approval settings."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@guardrails_cmd.command("show")
def show_guardrails() -> None:
    """Show current guardrail configuration."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_guardrails()
            pairs = [("Tier", data.get("tier", "standard"))]
            overrides = data.get("tool_overrides", {})
            if overrides:
                for tool, cfg in overrides.items():
                    enabled = cfg.get("enabled", True)
                    approval = cfg.get("require_approval", False)
                    status = "disabled" if not enabled else ("approval" if approval else "allowed")
                    pairs.append((f"  {tool}", status))
            display.print_kv(pairs, title="Guardrails")
        finally:
            await client.close()

    _run(_run_it())


@guardrails_cmd.command("set-tier")
@click.argument("tier", type=click.Choice(["minimal", "standard", "strict"]))
def set_tier(tier: str) -> None:
    """Set the guardrail tier (minimal, standard, strict)."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.set_guardrail_tier(tier)
            display.success(f"Guardrail tier set to '{tier}'.")
        finally:
            await client.close()

    _run(_run_it())


@guardrails_cmd.command("approvals")
def list_approvals() -> None:
    """List pending tool approvals."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_approvals()
            approvals = data if isinstance(data, list) else []
            if not approvals:
                display.muted("No pending approvals.")
                return
            rows = []
            for a in approvals:
                rows.append(
                    {
                        "id": str(a.get("id", ""))[:16],
                        "tool": a.get("tool_name", ""),
                        "details": (a.get("details", "") or "")[:40],
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("tool", "Tool"), ("details", "Details")],
                title="Pending Approvals",
            )
        finally:
            await client.close()

    _run(_run_it())


@guardrails_cmd.command("approve")
@click.argument("approval_id")
def approve(approval_id: str) -> None:
    """Approve a pending tool call."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.resolve_approval(approval_id, approved=True)
            display.success("Approved.")
        finally:
            await client.close()

    _run(_run_it())


@guardrails_cmd.command("deny")
@click.argument("approval_id")
def deny(approval_id: str) -> None:
    """Deny a pending tool call."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.resolve_approval(approval_id, approved=False)
            display.success("Denied.")
        finally:
            await client.close()

    _run(_run_it())


# ---------------------------------------------------------------------------
# Usage / Billing
# ---------------------------------------------------------------------------


@config_cmd.command("usage")
@click.option("--month", "-m", default=None, help="Billing month (YYYY-MM)")
def usage(month: str | None) -> None:
    """Show token usage and billing info."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_usage(month=month)
            pairs = [
                ("Plan", data.get("plan", "")),
                ("Billing month", data.get("billing_month", "")),
                ("Input tokens", f"{data.get('total_input_tokens', 0):,}"),
                ("Output tokens", f"{data.get('total_output_tokens', 0):,}"),
                ("Normalized tokens", f"{data.get('total_normalized_tokens', 0):,}"),
                ("Limit", f"{data.get('limit', 0):,}"),
                ("Limit reached", str(data.get("limit_reached", False))),
            ]
            display.print_kv(pairs, title="Usage")
        finally:
            await client.close()

    _run(_run_it())


# ---------------------------------------------------------------------------
# Heartbeat
# ---------------------------------------------------------------------------


@config_cmd.command("heartbeat")
@click.option("--start", "action", flag_value="start", help="Start heartbeat")
@click.option("--stop", "action", flag_value="stop", help="Stop heartbeat")
def heartbeat(action: str | None) -> None:
    """View or control the heartbeat service."""

    async def _run_it():
        client = PlutusClient()
        try:
            if action == "start":
                await client.start_heartbeat()
                display.success("Heartbeat started.")
            elif action == "stop":
                await client.stop_heartbeat()
                display.success("Heartbeat stopped.")
            else:
                data = await client.get_heartbeat()
                display.print_kv(
                    [
                        ("Enabled", str(data.get("enabled", False))),
                    ],
                    title="Heartbeat",
                )
        finally:
            await client.close()

    _run(_run_it())
