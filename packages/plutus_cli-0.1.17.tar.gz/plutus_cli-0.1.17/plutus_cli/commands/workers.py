"""Worker and scheduler management commands."""

from __future__ import annotations

import asyncio

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("workers", invoke_without_command=True)
@click.pass_context
def workers_cmd(ctx: click.Context) -> None:
    """Manage background workers and tasks."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workers_cmd.command("list")
def list_workers() -> None:
    """List all workers and their status."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_workers()
            tasks = data.get("tasks", data.get("running", []))
            if not tasks:
                display.muted("No active workers.")
                return
            rows = []
            for t in tasks:
                rows.append(
                    {
                        "id": str(t.get("task_id", t.get("id", "")))[:16],
                        "status": t.get("status", ""),
                        "prompt": (t.get("prompt", t.get("description", "")) or "")[:50],
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("status", "Status"), ("prompt", "Task")],
                title="Workers",
            )
        finally:
            await client.close()

    _run(_run_it())


@workers_cmd.command("cancel")
@click.argument("task_id")
def cancel_worker(task_id: str) -> None:
    """Cancel a running worker task."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.cancel_worker(task_id)
            display.success(f"Worker {task_id[:16]} cancelled.")
        finally:
            await client.close()

    _run(_run_it())


# ---------------------------------------------------------------------------
# Scheduler sub-group
# ---------------------------------------------------------------------------


@click.group("schedule", invoke_without_command=True)
@click.pass_context
def schedule_cmd(ctx: click.Context) -> None:
    """Manage scheduled jobs (cron tasks)."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@schedule_cmd.command("list")
def list_jobs() -> None:
    """List all scheduled jobs."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_scheduled_jobs()
            jobs = data if isinstance(data, list) else data.get("jobs", [])
            if not jobs:
                display.muted("No scheduled jobs.")
                return
            rows = []
            for j in jobs:
                rows.append(
                    {
                        "id": str(j.get("id", ""))[:16],
                        "name": j.get("name", ""),
                        "schedule": j.get("schedule", ""),
                        "status": "Paused" if j.get("paused") else "Active",
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("name", "Name"), ("schedule", "Schedule"), ("status", "Status")],
                title="Scheduled Jobs",
            )
        finally:
            await client.close()

    _run(_run_it())


@schedule_cmd.command("create")
@click.option("--name", "-n", required=True, help="Job name")
@click.option("--schedule", "-s", "cron", required=True, help="Cron expression (e.g. '0 9 * * *')")
@click.option("--prompt", "-p", required=True, help="What Plutus should do")
def create_job(name: str, cron: str, prompt: str) -> None:
    """Create a new scheduled job."""

    async def _run_it():
        client = PlutusClient()
        try:
            result = await client.create_job(name, cron, prompt)
            display.success(f"Job '{name}' created (ID: {result.get('id', 'unknown')}).")
        finally:
            await client.close()

    _run(_run_it())


@schedule_cmd.command("delete")
@click.argument("job_id")
@click.confirmation_option(prompt="Delete this job?")
def delete_job(job_id: str) -> None:
    """Delete a scheduled job."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.delete_job(job_id)
            display.success(f"Job {job_id[:16]} deleted.")
        finally:
            await client.close()

    _run(_run_it())


@schedule_cmd.command("pause")
@click.argument("job_id")
def pause_job(job_id: str) -> None:
    """Pause a scheduled job."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.pause_job(job_id)
            display.success(f"Job {job_id[:16]} paused.")
        finally:
            await client.close()

    _run(_run_it())


@schedule_cmd.command("resume")
@click.argument("job_id")
def resume_job(job_id: str) -> None:
    """Resume a paused scheduled job."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.resume_job(job_id)
            display.success(f"Job {job_id[:16]} resumed.")
        finally:
            await client.close()

    _run(_run_it())


@schedule_cmd.command("history")
@click.option("--limit", "-n", default=50, help="Number of entries to show")
def job_history(limit: int) -> None:
    """Show scheduler execution history."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_scheduler_history(limit=limit)
            entries = data if isinstance(data, list) else data.get("history", [])
            if not entries:
                display.muted("No history entries.")
                return
            rows = []
            for e in entries:
                rows.append(
                    {
                        "date": str(e.get("executed_at", e.get("created_at", "")))[:16],
                        "job": e.get("job_name", e.get("name", "")),
                        "status": e.get("status", ""),
                    }
                )
            display.print_table(
                rows,
                [("date", "Date"), ("job", "Job"), ("status", "Status")],
                title="Scheduler History",
            )
        finally:
            await client.close()

    _run(_run_it())
