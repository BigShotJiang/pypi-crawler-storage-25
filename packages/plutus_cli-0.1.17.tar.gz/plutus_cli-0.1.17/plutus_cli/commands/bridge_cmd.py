"""CLI commands for the Plutus Bridge daemon.

Usage:
    plutus bridge start              # run bridge in foreground
    plutus bridge install            # install as systemd service + start
    plutus bridge uninstall          # stop and remove systemd service
    plutus bridge status             # show bridge connection status
    plutus bridge label <name>       # set the machine label
"""

from __future__ import annotations

import asyncio
import platform
import subprocess

import click
from rich.console import Console

from plutus_cli.bridge import (
    DEFAULT_SERVER,
    PlutusBridge,
    get_bridge_config,
    get_system_info,
    install_systemd_service,
    save_bridge_config,
    uninstall_systemd_service,
)
from plutus_cli.config import load_config

console = Console()


@click.group("bridge", invoke_without_command=True)
@click.pass_context
def bridge(ctx: click.Context):
    """Manage the persistent bridge to Plutus Cloud.

    The bridge keeps a WebSocket connection open so the cloud agent
    can execute commands on this machine in real-time.
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@bridge.command("start")
@click.option("--label", default="", help="Machine label (default: hostname)")
def bridge_start(label: str):
    """Start the bridge daemon in the foreground."""
    cfg = load_config()
    api_key = cfg.get("api_key", "")
    if not api_key:
        console.print("[red]No API key configured. Run `plutus login` first.[/red]")
        raise SystemExit(1)

    bridge_cfg = get_bridge_config()
    machine_label = label or bridge_cfg.get("machine_label", "")

    # Save label if provided
    if label:
        save_bridge_config({"machine_label": label})

    server_url = cfg.get("api_url", DEFAULT_SERVER)
    # Strip /api suffix if present
    if server_url.endswith("/api"):
        server_url = server_url[:-4]
    server_url = server_url.rstrip("/") or DEFAULT_SERVER

    console.print("[bold green]Starting Plutus Bridge[/bold green]")
    console.print(f"  Server:  {server_url}")
    console.print(f"  Machine: {machine_label or platform.node()}")
    console.print("  Press Ctrl+C to stop\n")

    b = PlutusBridge(
        api_key=api_key,
        server_url=server_url,
        machine_label=machine_label,
    )
    try:
        asyncio.run(b.run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Bridge stopped.[/yellow]")


@bridge.command("install")
@click.option("--label", default="", help="Machine label (default: hostname)")
def bridge_install(label: str):
    """Install the bridge as a system service and start it.

    On Linux, creates a systemd service that auto-starts on boot.
    On other platforms, shows manual instructions.
    """
    cfg = load_config()
    api_key = cfg.get("api_key", "")
    if not api_key:
        console.print("[red]No API key configured. Run `plutus login` first.[/red]")
        raise SystemExit(1)

    if label:
        save_bridge_config({"machine_label": label})

    system = platform.system()

    if system == "Linux":
        console.print("[bold]Installing Plutus Bridge as systemd service…[/bold]")
        if install_systemd_service():
            console.print("[green]✓ Service installed and started![/green]")
            console.print("  View logs:  sudo journalctl -u plutus-bridge -f")
            console.print("  Stop:       sudo systemctl stop plutus-bridge")
            console.print("  Uninstall:  plutus bridge uninstall")
        else:
            console.print("[yellow]Could not install systemd service.[/yellow]")
            console.print("You can run the bridge manually instead:")
            console.print("  plutus bridge start")
    elif system == "Darwin":
        console.print("[yellow]macOS detected — auto-install not yet supported.[/yellow]")
        console.print("Run the bridge manually:")
        console.print("  plutus bridge start")
        console.print("\nOr create a launchd plist manually for auto-start.")
    elif system == "Windows":
        console.print("[yellow]Windows detected — auto-install not yet supported.[/yellow]")
        console.print("Run the bridge manually:")
        console.print("  plutus bridge start")
        console.print("\nOr use Task Scheduler to run on startup:")
        console.print(f"  {platform.python_version()} -m plutus_cli.bridge")
    else:
        console.print("Run the bridge manually:")
        console.print("  plutus bridge start")


@bridge.command("uninstall")
def bridge_uninstall():
    """Stop and remove the bridge system service."""
    if platform.system() != "Linux":
        console.print("[yellow]Service uninstall is only supported on Linux.[/yellow]")
        return

    if uninstall_systemd_service():
        console.print("[green]✓ Service stopped and removed.[/green]")
    else:
        console.print("[yellow]No service found or removal failed.[/yellow]")


def _is_bridge_process_running() -> bool:
    """Check if a plutus bridge process is running locally."""
    system = platform.system()

    if system == "Linux":
        # Check systemd service first
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "plutus-bridge.service"],
                capture_output=True,
                text=True,
            )
            if result.stdout.strip() == "active":
                return True
        except Exception:
            pass

        # Check for running process
        try:
            result = subprocess.run(
                ["pgrep", "-f", "plutus_cli.bridge"],
                capture_output=True,
                text=True,
            )
            return result.returncode == 0
        except Exception:
            pass

    elif system == "Darwin":
        try:
            result = subprocess.run(
                ["pgrep", "-f", "plutus_cli.bridge"],
                capture_output=True,
                text=True,
            )
            return result.returncode == 0
        except Exception:
            pass

    elif system == "Windows":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq python*"],
                capture_output=True,
                text=True,
            )
            return "plutus_cli.bridge" in result.stdout or "plutus_cli" in result.stdout
        except Exception:
            pass

    return False


def _get_local_machine_id() -> str:
    """Get the machine_id that this machine would use when connecting."""
    bridge_cfg = get_bridge_config()
    label = bridge_cfg.get("machine_label", "") or platform.node()
    return label.strip().lower().replace(" ", "-") or "default"


@bridge.command("status")
def bridge_status():
    """Check the bridge connection status.

    Shows whether the local bridge process is running and whether
    this machine is registered and connected in Plutus Cloud.
    """
    from plutus_cli.client import PlutusClient

    # First check if the bridge process is running locally
    local_running = _is_bridge_process_running()
    local_machine_id = _get_local_machine_id()
    local_info = get_system_info(get_bridge_config().get("machine_label", ""))

    async def _check():
        async with PlutusClient() as client:
            try:
                result = await client.get("/bridge/status")
                machines = result.get("machines", [])

                # Find THIS machine in the cloud's machine list
                this_machine = None
                for m in machines:
                    if m.get("machine_id") == local_machine_id:
                        this_machine = m
                        break

                # Display local process status
                if local_running:
                    console.print("[bold green]● Bridge process running[/bold green]")
                else:
                    console.print("[bold red]● Bridge process not running[/bold red]")

                # Display cloud connection status for THIS machine
                if this_machine and this_machine.get("connected"):
                    console.print("[bold green]● Connected to cloud[/bold green]")
                    console.print(f"  Machine ID: {this_machine.get('machine_id', '')}")
                    console.print(f"  Label:      {this_machine.get('machine_label', '')}")
                    console.print(f"  Hostname:   {this_machine.get('hostname', '')}")
                    console.print(f"  OS:         {this_machine.get('os', '')}")
                    console.print(f"  Type:       {this_machine.get('client_type', 'unknown')}")
                    console.print(f"  Version:    {this_machine.get('bridge_version', '')}")
                elif this_machine:
                    console.print("[yellow]● Registered but not connected[/yellow]")
                    console.print(f"  Machine ID: {this_machine.get('machine_id', '')}")
                    console.print(f"  Last seen:  {this_machine.get('last_seen_at', 'unknown')}")
                    if not local_running:
                        console.print("\n  Start with: plutus bridge start")
                        console.print("  Or install: plutus bridge install")
                else:
                    console.print("[yellow]● Not registered in cloud[/yellow]")
                    console.print(f"  Expected machine ID: {local_machine_id}")
                    if not local_running:
                        console.print("\n  The bridge process is not running.")
                        console.print("  Start with: plutus bridge start")
                        console.print("  Or install: plutus bridge install")
                    else:
                        console.print("\n  Bridge is running but not appearing in cloud.")
                        console.print("  Check logs: ~/.plutus/bridge.log")

                # Show other connected machines for context
                other_machines = [
                    m
                    for m in machines
                    if m.get("machine_id") != local_machine_id and m.get("connected")
                ]
                if other_machines:
                    console.print(f"\n  Other connected machines: {len(other_machines)}")
                    for m in other_machines:
                        label = m.get("machine_label") or m.get("hostname", "unknown")
                        mtype = m.get("client_type", "unknown")
                        console.print(f"    • {label} ({mtype})")

            except Exception as e:
                # Fallback: show local info only
                if local_running:
                    console.print(
                        "[bold yellow]● Bridge process running"
                        " (cloud status unavailable)[/bold yellow]"
                    )
                else:
                    console.print("[bold red]● Bridge not running[/bold red]")
                console.print(f"  Error checking cloud: {e}")
                console.print("\n  Local machine info:")
                console.print(f"    Hostname: {local_info.get('hostname', '')}")
                console.print(f"    OS:       {local_info.get('os', '')}")
                console.print("    Type:     cli")

    asyncio.run(_check())


@bridge.command("label")
@click.argument("name")
def bridge_label(name: str):
    """Set the machine label for this bridge.

    The label helps identify this machine in the cloud dashboard
    when multiple machines are connected.
    """
    save_bridge_config({"machine_label": name})
    console.print(f"[green]✓ Machine label set to: {name}[/green]")
