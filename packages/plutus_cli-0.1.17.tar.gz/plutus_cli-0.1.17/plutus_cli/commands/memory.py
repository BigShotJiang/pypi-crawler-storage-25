"""Memory management commands — Supermemory."""

from __future__ import annotations

import asyncio

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("memory", invoke_without_command=True)
@click.pass_context
def memory_cmd(ctx: click.Context) -> None:
    """View and manage Plutus memory (powered by Supermemory)."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@memory_cmd.command("profile")
@click.option(
    "--scope",
    "-s",
    type=click.Choice(["personal", "org"]),
    default="personal",
    help="Memory scope",
)
@click.option("--org-id", default="", help="Organisation ID (required for org scope)")
@click.option("--query", "-q", default=None, help="Optional search query to combine")
def profile(scope: str, org_id: str, query: str | None) -> None:
    """Show your Supermemory profile (known facts + recent context)."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.supermemory_profile(scope=scope, org_id=org_id, query=query)
            if data.get("error"):
                display.error(data["error"])
                return

            prof = data.get("profile", {})
            static = prof.get("static", [])
            dynamic = prof.get("dynamic", [])

            if not static and not dynamic:
                display.muted("No profile data yet.")
                return

            if static:
                display.heading(f"Known Facts ({scope})")
                for i, fact in enumerate(static, 1):
                    click.echo(f"  {i}. {fact}")

            if dynamic:
                click.echo()
                display.heading(f"Recent Context ({scope})")
                for i, ctx_item in enumerate(dynamic, 1):
                    click.echo(f"  {i}. {ctx_item}")

            # Show search results if a query was provided
            search_results = data.get("searchResults", {}).get("results", [])
            if search_results:
                click.echo()
                display.heading("Related Memories")
                for i, r in enumerate(search_results, 1):
                    mem = r.get("memory") or r.get("chunk") or ""
                    if mem:
                        click.echo(f"  {i}. {mem}")
        finally:
            await client.close()

    _run(_run_it())


@memory_cmd.command("search")
@click.argument("query")
@click.option(
    "--scope",
    "-s",
    type=click.Choice(["personal", "org"]),
    default="personal",
    help="Memory scope",
)
@click.option("--org-id", default="", help="Organisation ID (required for org scope)")
@click.option("--limit", "-n", default=10, help="Max results")
def search(query: str, scope: str, org_id: str, limit: int) -> None:
    """Search your memories via Supermemory."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.supermemory_search(
                query=query, scope=scope, org_id=org_id, limit=limit
            )
            if data.get("error"):
                display.error(data["error"])
                return

            results = data.get("results", [])
            if not results:
                display.muted("No matching memories found.")
                return

            display.heading(f"Search Results ({scope})")
            for i, r in enumerate(results, 1):
                mem = r.get("memory") or r.get("chunk") or ""
                if mem:
                    click.echo(f"  {i}. {mem}")
        finally:
            await client.close()

    _run(_run_it())


@memory_cmd.command("save")
@click.argument("content")
@click.option(
    "--scope",
    "-s",
    type=click.Choice(["personal", "org"]),
    default="personal",
    help="Memory scope",
)
@click.option("--org-id", default="", help="Organisation ID (required for org scope)")
def save(content: str, scope: str, org_id: str) -> None:
    """Save a memory to Supermemory."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.supermemory_save(content=content, scope=scope, org_id=org_id)
            if data.get("error"):
                display.error(data["error"])
                return
            doc_id = data.get("document_id", "")
            display.success(
                f"Memory saved to {scope} container." + (f" (id: {doc_id})" if doc_id else "")
            )
        finally:
            await client.close()

    _run(_run_it())
