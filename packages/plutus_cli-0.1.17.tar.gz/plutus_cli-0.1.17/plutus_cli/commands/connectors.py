"""Connector management commands."""

from __future__ import annotations

import asyncio
import json

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("connectors", invoke_without_command=True)
@click.pass_context
def connectors_cmd(ctx: click.Context) -> None:
    """Manage Plutus connectors (Notion, GitHub, WhatsApp, etc.)."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@connectors_cmd.command("list")
def list_connectors() -> None:
    """List all available connectors and their status."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_connectors()
            connectors = data if isinstance(data, list) else data.get("connectors", [])
            if not connectors:
                display.muted("No connectors found.")
                return
            rows = []
            for c in connectors:
                status = "Connected" if c.get("configured") else "Not configured"
                rows.append(
                    {
                        "name": c.get("name", ""),
                        "category": c.get("category", ""),
                        "status": status,
                        "auto": "Yes" if c.get("auto_start") else "No",
                    }
                )
            display.print_table(
                rows,
                [
                    ("name", "Name"),
                    ("category", "Category"),
                    ("status", "Status"),
                    ("auto", "Auto"),
                ],
                title="Connectors",
            )
        finally:
            await client.close()

    _run(_run_it())


@connectors_cmd.command("info")
@click.argument("name")
def connector_info(name: str) -> None:
    """Show details for a specific connector."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_connector(name)
            pairs = [
                ("Name", data.get("name", "")),
                ("Category", data.get("category", "")),
                ("Configured", str(data.get("configured", False))),
                ("Description", data.get("description", "")),
            ]
            config_schema = data.get("config_schema", {})
            if config_schema:
                fields = config_schema.get("fields", [])
                for f in fields:
                    fname = f.get("name", "")
                    ftype = f.get("type", "string")
                    pairs.append((f"  Config: {fname}", f"({ftype})"))
            display.print_kv(pairs, title=f"Connector: {name}")
        finally:
            await client.close()

    _run(_run_it())


@connectors_cmd.command("setup")
@click.argument("name")
@click.option(
    "--config", "-c", "config_json", help='JSON config string, e.g. \'{"api_token": "..."}\''
)
def setup_connector(name: str, config_json: str | None) -> None:
    """Configure a connector. Pass --config as JSON or be prompted interactively."""

    async def _run_it():
        client = PlutusClient()
        try:
            # Get the connector schema first
            data = await client.get_connector(name)
            config_schema = data.get("config_schema", {})
            fields = config_schema.get("fields", [])

            if config_json:
                config = json.loads(config_json)
            else:
                config = {}
                for f in fields:
                    fname = f.get("name", "")
                    f.get("type", "string")
                    required = f.get("required", False)
                    secret = f.get("secret", False)
                    label = f.get("label", fname)

                    prompt_text = f"  {label}"
                    if not required:
                        prompt_text += " (optional)"
                    prompt_text += ": "

                    if secret:
                        import getpass

                        val = getpass.getpass(prompt_text)
                    else:
                        val = input(prompt_text)

                    if val:
                        config[fname] = val
                    elif required:
                        display.error(f"Field '{fname}' is required.")
                        return

            await client.update_connector_config(name, config)
            display.success(f"Connector '{name}' configured.")

            # Test the connection
            display.info("Testing connection...")
            test = await client.test_connector(name)
            if test.get("success") or test.get("ok"):
                display.success("Connection test passed!")
            else:
                display.warning(f"Test result: {test.get('error', 'unknown')}")
        finally:
            await client.close()

    _run(_run_it())


@connectors_cmd.command("test")
@click.argument("name")
def test_connector(name: str) -> None:
    """Test a connector's connection."""

    async def _run_it():
        client = PlutusClient()
        try:
            result = await client.test_connector(name)
            if result.get("success") or result.get("ok"):
                display.success(f"Connector '{name}' is working.")
            else:
                display.error(f"Test failed: {result.get('error', 'unknown')}")
        finally:
            await client.close()

    _run(_run_it())


@connectors_cmd.command("disconnect")
@click.argument("name")
@click.confirmation_option(prompt="Are you sure you want to disconnect?")
def disconnect_connector(name: str) -> None:
    """Disconnect and remove configuration for a connector."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.disconnect_connector(name)
            display.success(f"Connector '{name}' disconnected.")
        finally:
            await client.close()

    _run(_run_it())
