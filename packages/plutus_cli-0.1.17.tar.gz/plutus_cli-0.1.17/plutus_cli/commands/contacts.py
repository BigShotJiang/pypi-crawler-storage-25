"""Contact management commands."""

from __future__ import annotations

import asyncio

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("contacts", invoke_without_command=True)
@click.pass_context
def contacts_cmd(ctx: click.Context) -> None:
    """Manage your contacts."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@contacts_cmd.command("list")
@click.option("--query", "-q", default=None, help="Search query")
@click.option("--limit", "-n", default=50, help="Number of contacts to show")
def list_contacts(query: str | None, limit: int) -> None:
    """List contacts, optionally filtered by search query."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.list_contacts(q=query, limit=limit)
            contacts = data if isinstance(data, list) else data.get("contacts", [])
            if not contacts:
                display.muted("No contacts found.")
                return
            rows = []
            for c in contacts:
                rows.append(
                    {
                        "id": str(c.get("id", "")),
                        "name": c.get("name", c.get("display_name", "")),
                        "email": c.get("email", ""),
                        "phone": c.get("phone", ""),
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("name", "Name"), ("email", "Email"), ("phone", "Phone")],
                title="Contacts",
            )
        finally:
            await client.close()

    _run(_run_it())


@contacts_cmd.command("info")
@click.argument("contact_id", type=int)
def contact_info(contact_id: int) -> None:
    """Show details for a specific contact."""

    async def _run_it():
        client = PlutusClient()
        try:
            c = await client.get_contact(contact_id)
            pairs = [
                ("ID", str(c.get("id", ""))),
                ("Name", c.get("name", c.get("display_name", ""))),
                ("Email", c.get("email", "")),
                ("Phone", c.get("phone", "")),
                ("Company", c.get("company", "")),
                ("Tags", ", ".join(c.get("tags", []))),
                ("Source", c.get("source", "")),
                ("Notes", c.get("notes", "")),
            ]
            display.print_kv(pairs, title=f"Contact #{contact_id}")
        finally:
            await client.close()

    _run(_run_it())


@contacts_cmd.command("delete")
@click.argument("contact_id", type=int)
@click.confirmation_option(prompt="Delete this contact?")
def delete_contact(contact_id: int) -> None:
    """Delete a contact."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.delete_contact(contact_id)
            display.success(f"Contact #{contact_id} deleted.")
        finally:
            await client.close()

    _run(_run_it())
