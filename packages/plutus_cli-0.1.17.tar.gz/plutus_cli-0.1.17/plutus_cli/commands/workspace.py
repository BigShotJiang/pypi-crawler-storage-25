"""Workspace file management commands."""

from __future__ import annotations

import asyncio

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("workspace", invoke_without_command=True)
@click.pass_context
def workspace_cmd(ctx: click.Context) -> None:
    """Manage workspace files."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_cmd.command("ls")
def list_files() -> None:
    """List workspace files."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_workspace_files()
            files = data if isinstance(data, list) else data.get("files", [])
            if not files:
                display.muted("Workspace is empty.")
                return
            rows = []
            for f in files:
                if isinstance(f, str):
                    rows.append({"path": f, "size": ""})
                else:
                    rows.append(
                        {
                            "path": f.get("path", f.get("name", "")),
                            "size": f.get("size", ""),
                        }
                    )
            display.print_table(
                rows,
                [("path", "Path"), ("size", "Size")],
                title="Workspace Files",
            )
        finally:
            await client.close()

    _run(_run_it())


@workspace_cmd.command("download")
@click.argument("path")
@click.option("--output", "-o", default=None, help="Local output path")
def download_file(path: str, output: str | None) -> None:
    """Download a workspace file."""

    async def _run_it():
        client = PlutusClient()
        try:
            dest = output or path.split("/")[-1]
            encoded = "/".join(part for part in path.split("/") if part)
            await client.download(f"/workspace/download/{encoded}", dest)
            display.success(f"Downloaded to {dest}")
        finally:
            await client.close()

    _run(_run_it())


@workspace_cmd.command("delete")
@click.argument("path")
@click.confirmation_option(prompt="Delete this file?")
def delete_file(path: str) -> None:
    """Delete a workspace file."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.delete_workspace_file(path)
            display.success(f"Deleted: {path}")
        finally:
            await client.close()

    _run(_run_it())
