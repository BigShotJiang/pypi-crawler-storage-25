"""Chat command — interactive REPL and one-shot mode."""

from __future__ import annotations

import asyncio
import sys

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient, stream_chat


def _run(coro):
    """Run an async coroutine in the event loop."""
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


async def _one_shot(message: str, verbose: bool) -> None:
    """Send a single message and stream the response."""
    display.console.print()
    try:
        async for msg in stream_chat(message):
            _handle_stream_msg(msg, verbose)
    except Exception as e:
        display.error(f"Connection error: {e}")
        sys.exit(1)
    display.console.print()


def _handle_stream_msg(msg: dict, verbose: bool) -> None:
    """Process a single WebSocket message for display."""
    msg_type = msg.get("type", "")

    if msg_type == "text":
        content = msg.get("content", "")
        role = msg.get("role", "")
        if role == "assistant":
            display.stream_token(content)
        elif role == "tool":
            # Tool result
            name = msg.get("tool_name", msg.get("name", "tool"))
            display.stream_newline()
            display.tool_call_result(content, verbose=verbose)

    elif msg_type == "thinking":
        display.thinking_indicator()

    elif msg_type == "tool_call":
        name = msg.get("name", msg.get("tool_name", "unknown"))
        display.stream_newline()
        display.tool_call_start(name)
        result = msg.get("result", msg.get("output", ""))
        if result:
            display.tool_call_result(str(result), verbose=verbose)

    elif msg_type == "error":
        display.stream_newline()
        display.error(msg.get("message", "Unknown error"))

    elif msg_type == "done":
        display.stream_newline()

    elif msg_type == "approval_required":
        tool_name = msg.get("tool_name", "unknown")
        details = msg.get("details", "")
        display.stream_newline()
        display.approval_prompt(tool_name, details)


async def _interactive_repl(verbose: bool) -> None:
    """Run an interactive chat REPL."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory

    from plutus_cli.config import CONFIG_DIR

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    history_file = CONFIG_DIR / "chat_history"

    session = PromptSession(
        history=FileHistory(str(history_file)),
        multiline=False,
    )

    display.print_panel(
        "Welcome to Plutus Chat\n"
        "Type your message and press Enter. Use Ctrl+D or 'exit' to quit.\n"
        "Commands: /history, /new, /verbose, /help",
        title="Plutus CLI",
        border_style="magenta",
    )

    conversation_id = None
    client = PlutusClient()

    while True:
        try:
            user_input = session.prompt("\n[You] > ").strip()
        except (EOFError, KeyboardInterrupt):
            display.muted("\nGoodbye!")
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit", "/quit", "/exit"):
            display.muted("Goodbye!")
            break

        if user_input.lower() == "/help":
            display.print_panel(
                "/history  — show recent conversations\n"
                "/new      — start a new conversation\n"
                "/verbose  — toggle verbose tool output\n"
                "/exit     — quit the REPL",
                title="Commands",
            )
            continue

        if user_input.lower() == "/new":
            conversation_id = None
            display.success("Starting new conversation.")
            continue

        if user_input.lower() == "/verbose":
            verbose = not verbose
            display.info(f"Verbose mode: {'on' if verbose else 'off'}")
            continue

        if user_input.lower() == "/history":
            try:
                convs = await client.get_conversations(limit=10)
                if not convs:
                    display.muted("No conversations yet.")
                else:
                    rows = []
                    for c in convs[:10]:
                        rows.append(
                            {
                                "id": c.get("id", "")[:12],
                                "title": (c.get("title") or "Untitled")[:50],
                                "updated": c.get("updated_at", ""),
                            }
                        )
                    display.print_table(
                        rows,
                        [("id", "ID"), ("title", "Title"), ("updated", "Updated")],
                        title="Recent Conversations",
                    )
            except Exception as e:
                display.error(f"Failed to load history: {e}")
            continue

        # Send message via REST (simpler for REPL, gets full response)
        display.console.print()
        try:
            with display.console.status("[muted]Thinking…[/muted]", spinner="dots"):
                result = await client.chat(user_input, conversation_id)
            conversation_id = result.get("conversation_id", conversation_id)
            response = result.get("response", "")
            display.print_markdown(response)
        except Exception as e:
            display.error(f"Error: {e}")

    await client.close()


@click.command("chat")
@click.argument("message", nargs=-1, required=False)
@click.option("--verbose", "-v", is_flag=True, help="Show full tool call output")
@click.option("--stream", "-s", is_flag=True, help="Force WebSocket streaming mode")
def chat_cmd(message: tuple[str, ...], verbose: bool, stream: bool) -> None:
    """Chat with Plutus. Pass a message for one-shot, or omit for interactive REPL.

    Examples:

      plutus chat "deploy my app to vercel"

      plutus chat  (opens interactive mode)
    """
    if message:
        full_message = " ".join(message)
        _run(_one_shot(full_message, verbose))
    else:
        _run(_interactive_repl(verbose))
