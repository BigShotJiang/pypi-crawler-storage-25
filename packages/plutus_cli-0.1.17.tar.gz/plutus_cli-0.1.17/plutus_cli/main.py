"""Plutus CLI — main entry point."""

from __future__ import annotations

import os
import signal
import sys
from pathlib import Path

import click

from plutus_cli import __version__, display
from plutus_cli.config import CONFIG_DIR, save_config

# ---------------------------------------------------------------------------
# Root group
# ---------------------------------------------------------------------------


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="plutus")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """Plutus CLI — your AI assistant in the terminal.

    \b
    Quick start:
      plutus login            Set up your API key
      plutus chat             Interactive chat with Plutus
      plutus "do something"   One-shot command
      plutus email inbox      Check your email
      plutus connectors list  View connectors
    """
    if ctx.invoked_subcommand is None:
        # If no subcommand, check if there are remaining args to treat as one-shot chat
        click.echo(ctx.get_help())


# ---------------------------------------------------------------------------
# Bridge auto-start helper
# ---------------------------------------------------------------------------


def _kill_existing_bridge() -> None:
    """Kill any existing bridge process so the new one starts fresh."""
    import subprocess as _sp

    try:
        # Find and kill existing plutus_cli.bridge processes (excluding ourselves)
        result = _sp.run(
            ["pgrep", "-f", "plutus_cli.bridge"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            for pid in result.stdout.strip().split("\n"):
                pid = pid.strip()
                if pid and pid != str(os.getpid()):
                    try:
                        os.kill(int(pid), signal.SIGTERM)
                    except (ProcessLookupError, PermissionError):
                        pass
            # Give processes a moment to exit
            import time

            time.sleep(0.5)
    except Exception:
        pass


def _auto_start_bridge() -> None:
    """Automatically install/start the bridge after login."""
    import platform as _platform
    import subprocess as _sp

    from plutus_cli.bridge import install_systemd_service

    system = _platform.system()

    # Kill any existing bridge process first so we start fresh
    _kill_existing_bridge()

    if system == "Linux":
        # Try systemd service first
        display.info("Installing bridge as background service...")
        if install_systemd_service():
            display.success("Bridge service installed and started!")
            display.info("  View logs:  sudo journalctl -u plutus-bridge -f")
            display.info("  Stop:       sudo systemctl stop plutus-bridge")
            display.info("  Manage:     plutus bridge status")
            return
        # Fallback: start bridge in background via nohup
        display.info("Systemd not available, starting bridge in background...")
        try:
            _sp.Popen(
                [sys.executable, "-m", "plutus_cli.bridge"],
                stdout=open(str(Path.home() / ".plutus" / "bridge.log"), "a"),
                stderr=_sp.STDOUT,
                start_new_session=True,
            )
            display.success("Bridge started in background!")
            display.info("  Logs: ~/.plutus/bridge.log")
            display.info("  Manage: plutus bridge status")
        except Exception as e:
            display.warning(f"Could not auto-start bridge: {e}")
            display.info("Start manually with: plutus bridge start")
    elif system == "Darwin":
        # macOS: start bridge in background
        display.info("Starting bridge in background...")
        try:
            _sp.Popen(
                [sys.executable, "-m", "plutus_cli.bridge"],
                stdout=open(str(Path.home() / ".plutus" / "bridge.log"), "a"),
                stderr=_sp.STDOUT,
                start_new_session=True,
            )
            display.success("Bridge started in background!")
            display.info("  Logs: ~/.plutus/bridge.log")
            display.info("  Manage: plutus bridge status")
        except Exception as e:
            display.warning(f"Could not auto-start bridge: {e}")
            display.info("Start manually with: plutus bridge start")
    elif system == "Windows":
        # Windows: start bridge in background
        display.info("Starting bridge in background...")
        try:
            _sp.Popen(
                [sys.executable, "-m", "plutus_cli.bridge"],
                stdout=open(str(Path.home() / ".plutus" / "bridge.log"), "a"),
                stderr=_sp.STDOUT,
                creationflags=_sp.CREATE_NO_WINDOW if hasattr(_sp, "CREATE_NO_WINDOW") else 0,
            )
            display.success("Bridge started in background!")
            display.info("  Logs: ~/.plutus/bridge.log")
            display.info("  Manage: plutus bridge status")
        except Exception as e:
            display.warning(f"Could not auto-start bridge: {e}")
            display.info("Start manually with: plutus bridge start")
    else:
        display.info("Start the bridge manually with: plutus bridge start")


# ---------------------------------------------------------------------------
# Login command
# ---------------------------------------------------------------------------


@cli.command("login")
@click.option("--key", "-k", default=None, help="API key (or paste interactively)")
@click.option("--api-url", default=None, help="Custom API base URL")
def login(key: str | None, api_url: str | None) -> None:
    """Authenticate with your Plutus Cloud API key.

    \b
    Get your API key from: https://app.useplutus.ai/?tab=machines
    """
    # Show the banner
    display.print_banner(version=__version__)

    if not key:
        display.print_panel(
            "Get your API key from:\n"
            "  https://app.useplutus.ai/?tab=machines\n\n"
            "Paste it below (input is hidden):",
            title="Plutus Login",
            border_style="magenta",
        )
        try:
            import getpass

            key = getpass.getpass("  API Key: ").strip()
        except (EOFError, KeyboardInterrupt):
            display.muted("\nCancelled.")
            sys.exit(0)

    if not key:
        display.error("No API key provided.")
        sys.exit(1)

    config: dict = {"api_key": key}
    if api_url:
        config["api_url"] = api_url

    save_config(config)
    display.success(f"API key saved to {CONFIG_DIR / 'config.toml'}")

    # Quick validation
    import asyncio

    from plutus_cli.client import PlutusClient

    async def _validate():
        try:
            client = PlutusClient(api_key=key, base_url=api_url)
            await client.get_status()
            await client.close()
            display.success("Connection verified — you're all set!")
        except Exception as e:
            display.warning(f"Could not verify connection: {e}")
            display.info("The key has been saved. You can test later with `plutus status`.")

    asyncio.run(_validate())

    # Auto-start bridge after login
    display.info("\nSetting up bridge connection to Plutus Cloud...")
    _auto_start_bridge()


# ---------------------------------------------------------------------------
# Logout command
# ---------------------------------------------------------------------------


@cli.command("logout")
def logout() -> None:
    """Remove stored API key and configuration."""
    config_file = CONFIG_DIR / "config.toml"
    if config_file.exists():
        config_file.unlink()
        display.success("Logged out. API key removed.")
    else:
        display.muted("No configuration found.")


# ---------------------------------------------------------------------------
# Status command
# ---------------------------------------------------------------------------


@cli.command("status")
def status() -> None:
    """Check connection status and account info."""
    import asyncio

    from plutus_cli.client import PlutusClient

    async def _run():
        try:
            client = PlutusClient()
            data = await client.get_status()
            await client.close()
            pairs = [
                ("Status", "Connected"),
                ("API URL", client.base_url),
            ]
            for k, v in data.items():
                if k not in ("ok", "status"):
                    pairs.append((k.replace("_", " ").title(), str(v)))
            display.print_kv(pairs, title="Plutus Status")
        except RuntimeError as e:
            display.error(str(e))
            sys.exit(1)
        except Exception as e:
            display.error(f"Connection failed: {e}")
            sys.exit(1)

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# Quick one-shot chat (plutus "do something")
# ---------------------------------------------------------------------------


@cli.command("ask", hidden=False)
@click.argument("message", nargs=-1, required=True)
@click.option("--verbose", "-v", is_flag=True, help="Show full tool output")
def ask(message: tuple[str, ...], verbose: bool) -> None:
    """Send a one-shot message to Plutus.

    \b
    Example:
      plutus ask "What emails did I get today?"
    """
    import asyncio

    from plutus_cli.commands.chat import _one_shot

    full_message = " ".join(message)
    asyncio.run(_one_shot(full_message, verbose))


# ---------------------------------------------------------------------------
# Register sub-command groups
# ---------------------------------------------------------------------------

from plutus_cli.commands.bridge_cmd import bridge  # noqa: E402
from plutus_cli.commands.chat import chat_cmd  # noqa: E402
from plutus_cli.commands.config_cmd import config_cmd, guardrails_cmd  # noqa: E402
from plutus_cli.commands.connectors import connectors_cmd  # noqa: E402
from plutus_cli.commands.contacts import contacts_cmd  # noqa: E402
from plutus_cli.commands.conversations import history_cmd  # noqa: E402
from plutus_cli.commands.email import email_cmd  # noqa: E402
from plutus_cli.commands.memory import memory_cmd  # noqa: E402
from plutus_cli.commands.skills import skills_cmd  # noqa: E402
from plutus_cli.commands.tools import tools_cmd  # noqa: E402
from plutus_cli.commands.workers import schedule_cmd, workers_cmd  # noqa: E402
from plutus_cli.commands.workspace import workspace_cmd  # noqa: E402

cli.add_command(chat_cmd)
cli.add_command(connectors_cmd)
cli.add_command(email_cmd)
cli.add_command(memory_cmd)
cli.add_command(skills_cmd)
cli.add_command(tools_cmd)
cli.add_command(workers_cmd)
cli.add_command(schedule_cmd)
cli.add_command(config_cmd)
cli.add_command(guardrails_cmd)
cli.add_command(contacts_cmd)
cli.add_command(history_cmd)
cli.add_command(workspace_cmd)
cli.add_command(bridge)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    cli()
