"""Plutus CLI Bridge Daemon.

Lightweight persistent bridge that connects a server/machine to Plutus Cloud
via WebSocket.  The cloud agent can then execute commands, read/write files,
and manage the machine remotely.

This module is a self-contained daemon that can run as:
  - A foreground process: ``plutus bridge start``
  - A systemd service:    ``plutus bridge install`` (auto-creates the unit)
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import logging.handlers
import os
import platform
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Lazy dependency bootstrap
# ---------------------------------------------------------------------------
try:
    import websockets
    import websockets.exceptions
except ImportError:
    print("Installing websockets…")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", "websockets>=12.0"])
    import websockets
    import websockets.exceptions

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
VERSION = "2.0.0"
CONFIG_DIR = Path.home() / ".plutus"
CONFIG_FILE = CONFIG_DIR / "config.toml"
BRIDGE_LOG = CONFIG_DIR / "bridge.log"

HEARTBEAT_INTERVAL = 25  # seconds
RECONNECT_DELAY_INIT = 3
RECONNECT_DELAY_MAX = 120
OUTPUT_LIMIT = 50_000  # max chars for stdout/stderr

DEFAULT_SERVER = "https://api.useplutus.ai"


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def setup_bridge_logging() -> logging.Logger:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("plutus_bridge")
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    fh = logging.handlers.RotatingFileHandler(
        str(BRIDGE_LOG), maxBytes=2 * 1024 * 1024, backupCount=2, encoding="utf-8"
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    return logger


log = setup_bridge_logging()


# ---------------------------------------------------------------------------
# Config helpers (reuse CLI config.toml)
# ---------------------------------------------------------------------------
def _load_toml() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    if sys.version_info >= (3, 11):
        import tomllib
    else:
        import tomli as tomllib  # type: ignore[no-redef]
    return tomllib.loads(CONFIG_FILE.read_text("utf-8"))


def _save_toml(cfg: dict) -> None:
    import tomli_w

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_bytes(tomli_w.dumps(cfg).encode("utf-8"))


def get_bridge_config() -> dict:
    """Return the [bridge] section of config.toml."""
    return _load_toml().get("bridge", {})


def save_bridge_config(patch: dict) -> None:
    """Merge *patch* into the [bridge] section and save."""
    cfg = _load_toml()
    bridge = cfg.setdefault("bridge", {})
    bridge.update(patch)
    _save_toml(cfg)


# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------
def derive_ws_url(server_url: str) -> str:
    """Convert an HTTP(S) server URL to the bridge WebSocket URL."""
    ws = server_url.replace("https://", "wss://").replace("http://", "ws://")
    ws = ws.rstrip("/")
    return f"{ws}/api/bridge/ws"


# ---------------------------------------------------------------------------
# System info
# ---------------------------------------------------------------------------
def get_system_info(machine_label: str = "") -> dict[str, Any]:
    return {
        "os": platform.system(),
        "os_version": platform.version(),
        "hostname": platform.node(),
        "python": platform.python_version(),
        "arch": platform.machine(),
        "user": os.getenv("USER") or os.getenv("USERNAME", "unknown"),
        "bridge_version": VERSION,
        "client_type": "cli",
        "machine_label": machine_label or platform.node(),
    }


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------
async def handle_tool_call(tool: str, args: dict[str, Any]) -> dict[str, Any]:
    """Execute a tool call from the cloud agent."""
    try:
        if tool == "shell_exec":
            return await _tool_shell(args)
        if tool == "python_exec":
            return await _tool_python(args)
        if tool == "file_read":
            return _tool_file_read(args)
        if tool == "file_write":
            return _tool_file_write(args)
        if tool == "file_list":
            return _tool_file_list(args)
        if tool == "file_pull":
            return _tool_file_pull(args)
        if tool == "ping":
            return {"success": True, "message": "pong", "system": get_system_info()}
        return {"success": False, "error": f"Unknown tool: {tool}"}
    except Exception as exc:
        return {"success": False, "error": f"{type(exc).__name__}: {exc}"}


def _build_env() -> dict[str, str]:
    """Build environment with proper PATH for non-interactive shells (systemd)."""
    env = os.environ.copy()
    home = str(Path.home())
    extra_paths = [
        f"{home}/.local/bin",
        f"{home}/bin",
        "/usr/local/bin",
        "/usr/local/sbin",
        "/usr/bin",
        "/usr/sbin",
        "/bin",
        "/sbin",
    ]
    current_path = env.get("PATH", "")
    # Prepend user paths that aren't already present
    for p in reversed(extra_paths):
        if p not in current_path:
            current_path = f"{p}:{current_path}"
    env["PATH"] = current_path
    env.setdefault("HOME", home)
    env.setdefault("USER", os.getenv("USER", "root"))
    return env


async def _tool_shell(args: dict[str, Any]) -> dict[str, Any]:
    cmd = args.get("command", "")
    timeout = min(args.get("timeout", 60), 300)
    cwd = args.get("cwd")
    if not cmd:
        return {"success": False, "error": "Empty command"}
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=cwd,
        env=_build_env(),
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except TimeoutError:
        proc.kill()
        return {"success": False, "error": f"Command timed out after {timeout}s"}
    return {
        "success": proc.returncode == 0,
        "stdout": stdout.decode(errors="replace")[:OUTPUT_LIMIT],
        "stderr": stderr.decode(errors="replace")[:OUTPUT_LIMIT],
        "exit_code": proc.returncode,
    }


async def _tool_python(args: dict[str, Any]) -> dict[str, Any]:
    code = args.get("code", "")
    timeout = min(args.get("timeout", 60), 300)
    if not code:
        return {"success": False, "error": "Empty code"}
    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-c",
        code,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except TimeoutError:
        proc.kill()
        return {"success": False, "error": f"Python timed out after {timeout}s"}
    return {
        "success": proc.returncode == 0,
        "stdout": stdout.decode(errors="replace")[:OUTPUT_LIMIT],
        "stderr": stderr.decode(errors="replace")[:OUTPUT_LIMIT],
        "exit_code": proc.returncode,
    }


def _tool_file_read(args: dict[str, Any]) -> dict[str, Any]:
    raw = args.get("path", "")
    if not raw:
        return {"success": False, "error": "No path provided"}
    path = Path(raw).expanduser()
    if not path.exists():
        return {"success": False, "error": f"File not found: {path}"}
    if not path.is_file():
        return {"success": False, "error": f"Not a file: {path}"}
    max_size = args.get("max_size", 100_000)
    try:
        content = path.read_text(errors="replace")[:max_size]
        return {"success": True, "content": content, "size": path.stat().st_size}
    except Exception as exc:
        return {"success": False, "error": str(exc)}


def _tool_file_write(args: dict[str, Any]) -> dict[str, Any]:
    raw = args.get("path", "")
    content = args.get("content", "")
    if not raw:
        return {"success": False, "error": "No path provided"}
    path = Path(raw).expanduser()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return {"success": True, "path": str(path), "size": len(content)}
    except Exception as exc:
        return {"success": False, "error": str(exc)}


def _tool_file_list(args: dict[str, Any]) -> dict[str, Any]:
    raw = args.get("path", ".")
    path = Path(raw).expanduser()
    if not path.exists():
        return {"success": False, "error": f"Path not found: {path}"}
    if not path.is_dir():
        return {"success": False, "error": f"Not a directory: {path}"}
    try:
        entries = []
        for item in sorted(path.iterdir()):
            try:
                stat = item.stat()
                entries.append(
                    {
                        "name": item.name,
                        "type": "dir" if item.is_dir() else "file",
                        "size": stat.st_size if item.is_file() else 0,
                    }
                )
            except PermissionError:
                entries.append({"name": item.name, "type": "unknown", "size": 0})
        return {"success": True, "entries": entries[:500]}
    except Exception as exc:
        return {"success": False, "error": str(exc)}


def _tool_file_pull(args: dict[str, Any]) -> dict[str, Any]:
    raw = args.get("path", "")
    if not raw:
        return {"success": False, "error": "No path provided"}
    path = Path(raw).expanduser()
    if not path.exists():
        return {"success": False, "error": f"File not found: {path}"}
    if not path.is_file():
        return {"success": False, "error": f"Not a file: {path}"}
    max_bytes = 50 * 1024 * 1024
    size = path.stat().st_size
    if size > max_bytes:
        return {
            "success": False,
            "error": (
                f"File too large: {size / (1024 * 1024):.1f} MB"
                f" (limit {max_bytes // (1024 * 1024)} MB)"
            ),
        }
    try:
        data = path.read_bytes()
        return {
            "success": True,
            "filename": path.name,
            "size": size,
            "data_b64": base64.b64encode(data).decode("ascii"),
        }
    except Exception as exc:
        return {"success": False, "error": f"Read failed: {exc}"}


# ---------------------------------------------------------------------------
# Bridge daemon
# ---------------------------------------------------------------------------
class PlutusBridge:
    """Persistent WebSocket bridge to Plutus Cloud."""

    def __init__(
        self,
        api_key: str,
        server_url: str = DEFAULT_SERVER,
        machine_label: str = "",
    ) -> None:
        self.api_key = api_key
        self.server_url = server_url.rstrip("/")
        self.machine_label = machine_label or platform.node()
        self._ws_url = f"{derive_ws_url(self.server_url)}/{api_key}"
        self._shutdown = asyncio.Event()
        self._reconnect_now = asyncio.Event()
        self._ws = None
        self._last_close_code: int | None = None
        self._last_close_reason: str = ""

    async def run(self) -> None:
        """Start the bridge and block until shutdown."""
        self._install_signal_handlers()
        log.info("Plutus Bridge v%s starting…", VERSION)
        log.info("Server:  %s", self.server_url)
        log.info("Machine: %s", self.machine_label)
        log.info("Log:     %s", BRIDGE_LOG)
        await self._connection_loop()
        log.info("Plutus Bridge stopped.")

    def _install_signal_handlers(self) -> None:
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, self._shutdown.set)
            except NotImplementedError:
                signal.signal(sig, lambda *_: self._shutdown.set())
        # SIGHUP = reload config and reconnect immediately
        try:
            loop.add_signal_handler(signal.SIGHUP, self._request_reconnect)
        except (NotImplementedError, AttributeError):
            pass  # SIGHUP not available on Windows

    def _request_reconnect(self) -> None:
        """Signal handler for SIGHUP — force immediate reconnect."""
        log.info("Received SIGHUP — reconnecting immediately")
        self._reconnect_now.set()

    async def _connection_loop(self) -> None:
        delay = RECONNECT_DELAY_INIT
        while not self._shutdown.is_set():
            self._last_close_code = None
            self._last_close_reason = ""
            try:
                log.info("Connecting to %s …", self.server_url)
                async with websockets.connect(
                    self._ws_url,
                    ping_interval=None,
                    ping_timeout=None,
                    close_timeout=10,
                    max_size=10 * 1024 * 1024,
                    open_timeout=30,
                ) as ws:
                    self._ws = ws
                    log.info("Connected")
                    delay = RECONNECT_DELAY_INIT

                    # Handshake — include machine label
                    await self._send(
                        ws,
                        {
                            "type": "handshake",
                            "system": get_system_info(self.machine_label),
                            "version": VERSION,
                        },
                    )

                    hb = asyncio.create_task(self._heartbeat(ws), name="bridge_heartbeat")
                    recv = asyncio.create_task(self._receiver(ws), name="bridge_receiver")
                    shutdown = asyncio.create_task(self._shutdown.wait(), name="bridge_shutdown")

                    done, pending = await asyncio.wait(
                        [hb, recv, shutdown],
                        return_when=asyncio.FIRST_COMPLETED,
                    )

                    for t in done:
                        if t.exception():
                            log.error(
                                "Task '%s' error: %s",
                                t.get_name(),
                                t.exception(),
                            )

                    for t in pending:
                        t.cancel()
                    await asyncio.gather(*pending, return_exceptions=True)

                    if self._shutdown.is_set():
                        return

                    # If server says machine was removed, wait longer before retry
                    # (the server blocklist expires after ~2 min)
                    if self._last_close_code == 4010:
                        log.warning(
                            "Machine removed by user (%s). "
                            "Will retry in 180s in case machine is re-added.",
                            self._last_close_reason,
                        )
                        delay = 180  # 3 minutes — outlast the server's 2-min block

            except asyncio.CancelledError:
                log.info("Bridge cancelled — exiting")
                return
            except Exception as exc:
                # websockets v13+ uses InvalidStatus; older uses InvalidStatusCode
                exc_name = type(exc).__name__
                if exc_name in ("InvalidStatusCode", "InvalidStatus"):
                    status = getattr(exc, "status_code", None)
                    if status is None:
                        # websockets v13+: status is in response.status_code
                        resp = getattr(exc, "response", None)
                        status = getattr(resp, "status_code", "?") if resp else "?"
                    log.error(
                        "Server rejected connection (HTTP %s) — check API key. Retrying in %ds",
                        status,
                        delay,
                    )
                elif isinstance(exc, websockets.exceptions.ConnectionClosed):
                    if exc.code == 4010:
                        log.warning(
                            "Machine removed by user. "
                            "Will retry in 180s in case machine is re-added.",
                        )
                        delay = 180
                    else:
                        log.warning(
                            "Connection closed: code=%s — retrying in %ds",
                            exc.code,
                            delay,
                        )
                elif isinstance(exc, ConnectionRefusedError):
                    log.warning("Connection refused — retrying in %ds", delay)
                elif isinstance(exc, OSError):
                    log.warning("Network error: %s — retrying in %ds", exc, delay)
                else:
                    log.error(
                        "Unexpected error: %s\n%s",
                        exc,
                        traceback.format_exc(),
                    )

            if self._shutdown.is_set():
                return
            log.info("Reconnecting in %ds…", delay)
            await self._sleep(delay)
            delay = min(delay * 2, RECONNECT_DELAY_MAX)

    async def _heartbeat(self, ws) -> None:
        while not self._shutdown.is_set():
            await self._sleep(HEARTBEAT_INTERVAL)
            if self._shutdown.is_set():
                return
            try:
                await self._send(ws, {"type": "heartbeat", "ts": time.time()})
            except Exception:
                return

    async def _receiver(self, ws) -> None:
        try:
            async for raw in ws:
                if self._shutdown.is_set():
                    return
                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                msg_type = data.get("type", "")

                if msg_type == "tool_call":
                    asyncio.create_task(self._handle_tool_call(ws, data))
                elif msg_type == "handshake_ack":
                    log.info("Handshake acknowledged by server")
                elif msg_type == "heartbeat_ack":
                    pass
                elif msg_type == "error":
                    log.error("Server error: %s", data.get("message", data))
                else:
                    log.debug("Unknown message type: %s", msg_type)
        except websockets.exceptions.ConnectionClosed as exc:
            self._last_close_code = exc.code
            self._last_close_reason = getattr(exc, "reason", "") or ""
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.error("Receiver error: %s", exc)

    async def _handle_tool_call(self, ws, data: dict) -> None:
        call_id = data.get("call_id", "unknown")
        tool = data.get("tool", "")
        args = data.get("args", {})
        log.info("Tool call: %s [%s]", tool, call_id[:8])
        t0 = time.monotonic()

        result = await handle_tool_call(tool, args)

        elapsed = time.monotonic() - t0
        log.info("Tool %s done in %.1fs — success=%s", tool, elapsed, result.get("success"))
        try:
            await self._send(
                ws,
                {"type": "tool_result", "call_id": call_id, "result": result},
            )
        except Exception as exc:
            log.warning("Failed to send tool result: %s", exc)

    @staticmethod
    async def _send(ws, data: dict) -> None:
        await ws.send(json.dumps(data))

    async def _sleep(self, seconds: float) -> None:
        """Sleep that can be interrupted by shutdown OR reconnect signal."""
        wake = asyncio.create_task(self._wait_any_event(self._shutdown, self._reconnect_now))
        try:
            await asyncio.wait_for(wake, timeout=seconds)
        except (TimeoutError, asyncio.TimeoutError):
            pass
        finally:
            wake.cancel()
            # Clear reconnect flag so it doesn't fire again immediately
            self._reconnect_now.clear()

    @staticmethod
    async def _wait_any_event(*events: asyncio.Event) -> None:
        """Wait until any of the given events is set."""
        tasks = [asyncio.create_task(e.wait()) for e in events]
        try:
            await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        finally:
            for t in tasks:
                t.cancel()


# ---------------------------------------------------------------------------
# Systemd service installer
# ---------------------------------------------------------------------------
SYSTEMD_UNIT = """\
[Unit]
Description=Plutus Bridge — connects this machine to Plutus Cloud
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={python} -m plutus_cli.bridge
Restart=always
RestartSec=5
User={user}
Environment=HOME={home}
WorkingDirectory={home}

[Install]
WantedBy=multi-user.target
"""


def install_systemd_service() -> bool:
    """Create and enable a systemd user service for the bridge.

    Always writes the latest unit file and restarts the service so that
    code upgrades and config changes take effect immediately.

    Returns True on success, False if systemd is not available.
    """
    if platform.system() != "Linux":
        return False

    # Check if systemd is available
    if not Path("/run/systemd/system").exists():
        return False

    python = sys.executable
    user = os.getenv("USER", "root")
    home = str(Path.home())

    unit_content = SYSTEMD_UNIT.format(
        python=python,
        user=user,
        home=home,
    )

    unit_dir = Path("/etc/systemd/system")
    unit_path = unit_dir / "plutus-bridge.service"

    try:
        # Try to write the unit file (needs sudo for system-wide)
        if os.geteuid() == 0:
            unit_path.write_text(unit_content, encoding="utf-8")
        else:
            subprocess.run(
                ["sudo", "tee", str(unit_path)],
                input=unit_content.encode(),
                stdout=subprocess.DEVNULL,
                check=True,
            )

        subprocess.run(["sudo", "systemctl", "daemon-reload"], check=True)
        subprocess.run(["sudo", "systemctl", "enable", "plutus-bridge.service"], check=True)
        # Use restart (not start) so running services pick up new code/config
        subprocess.run(
            ["sudo", "systemctl", "restart", "plutus-bridge.service"],
            check=True,
        )
        return True
    except Exception:
        return False


def uninstall_systemd_service() -> bool:
    """Stop and remove the systemd service."""
    if platform.system() != "Linux":
        return False

    unit_path = Path("/etc/systemd/system/plutus-bridge.service")
    if not unit_path.exists():
        return False

    try:
        subprocess.run(
            ["sudo", "systemctl", "stop", "plutus-bridge.service"],
            check=False,
        )
        subprocess.run(
            ["sudo", "systemctl", "disable", "plutus-bridge.service"],
            check=False,
        )
        if os.geteuid() == 0:
            unit_path.unlink(missing_ok=True)
        else:
            subprocess.run(["sudo", "rm", "-f", str(unit_path)], check=True)
        subprocess.run(["sudo", "systemctl", "daemon-reload"], check=True)
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Direct entry point (python -m plutus_cli.bridge)
# ---------------------------------------------------------------------------
def main() -> None:
    """Run the bridge daemon directly (used by systemd service)."""
    cfg = _load_toml()
    api_key = cfg.get("api_key", "")
    bridge_cfg = cfg.get("bridge", {})
    server_url = cfg.get("api_url", DEFAULT_SERVER).rstrip("/")
    if server_url.endswith("/api"):
        server_url = server_url[:-4]
    if not server_url or server_url == "/":
        server_url = DEFAULT_SERVER
    machine_label = bridge_cfg.get("machine_label", "")

    if not api_key:
        print("Error: No API key configured. Run `plutus login` first.")
        sys.exit(1)

    bridge = PlutusBridge(
        api_key=api_key,
        server_url=server_url,
        machine_label=machine_label,
    )
    try:
        asyncio.run(bridge.run())
    except KeyboardInterrupt:
        log.info("Interrupted — exiting.")


if __name__ == "__main__":
    main()
