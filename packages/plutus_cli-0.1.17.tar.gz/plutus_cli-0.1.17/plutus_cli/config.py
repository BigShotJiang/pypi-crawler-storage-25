"""Configuration management — API key and settings stored in ~/.plutus/config.toml."""

from __future__ import annotations

import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # type: ignore[no-redef]

import tomli_w

CONFIG_DIR = Path.home() / ".plutus"
CONFIG_FILE = CONFIG_DIR / "config.toml"

DEFAULT_API_BASE = "https://api.useplutus.ai/api"
DEFAULT_WS_BASE = "wss://api.useplutus.ai/ws"


def _ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Load the config file, returning an empty dict if it doesn't exist."""
    if not CONFIG_FILE.exists():
        return {}
    return tomllib.loads(CONFIG_FILE.read_text("utf-8"))


def save_config(cfg: dict) -> None:
    """Write the full config dict to disk."""
    _ensure_dir()
    CONFIG_FILE.write_bytes(tomli_w.dumps(cfg).encode("utf-8"))


def get_api_key() -> str | None:
    """Return the stored API key, or None."""
    return load_config().get("api_key")


def set_api_key(key: str) -> None:
    """Persist the API key."""
    cfg = load_config()
    cfg["api_key"] = key
    save_config(cfg)


def get_api_base() -> str:
    """Return the API base URL."""
    return load_config().get("api_base", DEFAULT_API_BASE)


def set_api_base(url: str) -> None:
    """Override the API base URL (for self-hosted instances)."""
    cfg = load_config()
    cfg["api_base"] = url
    save_config(cfg)


def get_ws_base() -> str:
    """Return the WebSocket base URL."""
    return load_config().get("ws_base", DEFAULT_WS_BASE)


def get_default_model() -> str | None:
    """Return the user's preferred model, if set."""
    return load_config().get("default_model")


def set_default_model(model: str) -> None:
    cfg = load_config()
    cfg["default_model"] = model
    save_config(cfg)


def clear_config() -> None:
    """Remove the config file entirely."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
