class RetrievalBaseError(Exception):
    """Base exception for retrievalbase package."""


class RerankerError(RetrievalBaseError):
    """Generic reranker error."""


class RerankerHTTPError(RerankerError):
    """HTTP error when calling reranker."""

    def __init__(self, status_code: int, message: str, payload: dict | None = None):
        self.status_code = status_code
        self.message = message
        self.payload = payload
        super().__init__(f"[RerankerHTTPError] {status_code}: {message}")


class RerankerValidationError(RerankerError):
    """Raised when reranker rejects input (e.g., 422)."""

    def __init__(self, message: str, payload: dict | None = None):
        self.message = message
        self.payload = payload
        super().__init__(f"[RerankerValidationError] {message}")


class RerankerResponseFormatError(RerankerError):
    """Invalid response format from reranker."""

    def __init__(self, response: object):
        self.response = response
        super().__init__(f"[RerankerResponseFormatError] Invalid response: {response}")


class DatasetError(RetrievalBaseError):
    pass


class DatasetSplitError(DatasetError, ValueError):
    """Raised when dataset split parameters are invalid."""


class DatasetSchemaError(DatasetError):
    def __init__(
        self,
        missing_columns: set[str],
        available_columns: list[str],
        flattened_columns: list[str],
    ) -> None:
        self.missing_columns = missing_columns
        self.available_columns = available_columns
        self.flattened_columns = flattened_columns

        message = (
            f"Missing columns: {missing_columns}\n"
            f"Available columns (top-level): {available_columns}\n"
            f"Available columns (flattened): {flattened_columns}"
        )

        super().__init__(message)


class EvaluationError(RetrievalBaseError):
    """Base error for evaluation pipeline."""


class MetricError(EvaluationError):
    """Base error for metric computation."""


class MetricConfigurationError(MetricError, ValueError):
    """Raised when a metric is misconfigured (e.g., missing required inputs)."""

    def __init__(self, metric_name: str, message: str):
        self.metric_name = metric_name
        self.message = message
        super().__init__(f"[MetricConfigurationError][{metric_name}] {message}")


class EvaluationConfigurationError(EvaluationError, ValueError):
    """Raised when evaluation settings are inconsistent."""

    def __init__(self, message: str):
        self.message = message
        super().__init__(f"[EvaluationConfigurationError] {message}")


class LimitRerankerMismatchError(EvaluationConfigurationError):
    """Raised when limit and reranker configuration are inconsistent."""

    def __init__(self, limit: int | None, reranker: object | None):
        self.limit = limit
        self.reranker = reranker

        super().__init__(
            "`limit` and `retriever.reranker` must either both be "
            "None or both be configured. "
            f"Received limit={limit!r}, "
            f"reranker={'configured' if reranker is not None else None}."
        )
