from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest

from retrievalbase.dataset.polars import PolarsDataset, PolarsTextDataset
from retrievalbase.exceptions import DatasetSplitError
from tests.fixtures.data import make_documents


def test_polars_dataset_supports_basic_dataframe_operations(
    sample_text_df: pl.DataFrame,
) -> None:
    dataset = PolarsDataset.from_polars(sample_text_df)

    augmented = dataset.with_columns(pl.lit("ok").alias("status"))
    filtered = dataset.filter(pl.col("page_content") == "alpha")
    dropped = augmented.drop("status")

    assert len(dataset) == 3
    assert dataset.polars_shape == (3, 2)
    assert dataset.schema == sample_text_df.schema
    assert augmented.polars["status"].to_list() == ["ok", "ok", "ok"]
    assert filtered.polars["page_content"].to_list() == ["alpha"]
    assert dropped.polars.to_dict(as_series=False) == sample_text_df.to_dict(as_series=False)


def test_polars_dataset_train_test_split_preserves_order_when_shuffle_is_false() -> None:
    dataset = PolarsDataset.from_polars(pl.DataFrame({"id": list(range(8))}))

    train, test = dataset.train_test_split(test_size=0.25, shuffle=False)

    assert train.polars["id"].to_list() == [0, 1, 2, 3, 4, 5]
    assert test.polars["id"].to_list() == [6, 7]


def test_polars_dataset_train_test_split_is_seeded_and_repeatable() -> None:
    dataset = PolarsDataset.from_polars(pl.DataFrame({"id": list(range(10))}))

    train_a, test_a = dataset.train_test_split(test_size=0.3, seed=7)
    train_b, test_b = dataset.train_test_split(test_size=0.3, seed=7)
    train_c, test_c = dataset.train_test_split(test_size=0.3, seed=99)

    assert len(train_a) == 7
    assert len(test_a) == 3
    assert train_a.polars["id"].to_list() == train_b.polars["id"].to_list()
    assert test_a.polars["id"].to_list() == test_b.polars["id"].to_list()
    assert train_a.polars["id"].to_list() != train_c.polars["id"].to_list()
    assert test_a.polars["id"].to_list() != test_c.polars["id"].to_list()
    assert sorted(train_a.polars["id"].to_list() + test_a.polars["id"].to_list()) == list(range(10))


def test_polars_dataset_train_test_split_returns_train_and_test() -> None:
    dataset = PolarsDataset.from_polars(pl.DataFrame({"id": list(range(5))}))

    train, test = dataset.train_test_split(test_size=0.4, shuffle=False)

    assert train.polars["id"].to_list() == [0, 1, 2]
    assert test.polars["id"].to_list() == [3, 4]


@pytest.mark.parametrize("test_size", [0.0, 1.0, -0.1])
def test_polars_dataset_train_test_split_rejects_invalid_test_size(test_size: float) -> None:
    dataset = PolarsDataset.from_polars(pl.DataFrame({"id": list(range(5))}))

    with pytest.raises(DatasetSplitError, match="test_size"):
        dataset.train_test_split(test_size=test_size)


def test_polars_text_dataset_supports_document_helpers(tmp_path: Path) -> None:
    docs = make_documents(
        [
            {"page_content": "hello", "metadata": {"doc_id": "1"}},
            {"page_content": "world", "metadata": {"doc_id": "2"}},
        ]
    )
    dataset = PolarsTextDataset.from_documents(docs)

    records_dataset = PolarsTextDataset.from_records([("hello", {"doc_id": "1"}), ("world", {"doc_id": "2"})])
    dumped_dir = tmp_path / "docs"
    dataset.dump_documents(str(dumped_dir), prefix="sample")

    assert dataset.to_langchain_documents() == docs
    assert list(dataset.iter_documents()) == docs
    assert list(dataset.iter_rows(named=True))[0]["page_content"] == "hello"
    assert records_dataset.polars.to_dict(as_series=False) == dataset.polars.to_dict(as_series=False)
    assert (dumped_dir / "sample_00000.md").read_text(encoding="utf-8").startswith("###PAGE_CONTENT###")


def test_text_dataset_requires_page_content_and_metadata_columns() -> None:
    with pytest.raises(ValueError, match="requires columns"):
        PolarsTextDataset.from_polars(pl.DataFrame({"page_content": ["only text"]}))
    with pytest.raises(ValueError, match="requires columns"):
        PolarsTextDataset.from_polars(pl.DataFrame({"metadata": [{"doc_id": "1"}]}))
