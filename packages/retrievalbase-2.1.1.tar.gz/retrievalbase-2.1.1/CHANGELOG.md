## [2.1.1](https://gitlab.com/efysent/agentic-core/retrievalbase/compare/v2.1.0...v2.1.1) (2026-05-13)


### Bug Fixes

* update torch, hf packages version ([5995e72](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/5995e721ccc0135f625beece2a78600931515834))

# [2.1.0](https://gitlab.com/efysent/agentic-core/retrievalbase/compare/v2.0.0...v2.1.0) (2026-05-09)


### Features

* **dataset:** add polars schema ([25a9d09](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/25a9d09e49cf619b39a8dac1a4caa78cfad484ac))
* **dataset:** add train_test_split method ([e18c2c9](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/e18c2c94d67d053cd0161576f7208d6b4125eb28))

# [2.0.0](https://gitlab.com/efysent/agentic-core/retrievalbase/compare/v1.0.0...v2.0.0) (2026-05-08)


* feat!: refactor chunk matching and rename retriever parameters ([6cd809d](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/6cd809db72e5f97539d415a6d66cfed3403f6b6b))


### BREAKING CHANGES

* - Renamed retriever method parameters
- Updated chunk-to-retrieval point matching logic in evaluation pipeline

# 1.0.0 (2026-04-19)


### Bug Fixes

* fix deps in ci ([dc69d67](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/dc69d67cc33794c6cd477c7391576db3cf317800))


### Features

* first commit, setup ci ([47b9e29](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/47b9e29b747b07eef2689a6c332c7107d84abc2d))
