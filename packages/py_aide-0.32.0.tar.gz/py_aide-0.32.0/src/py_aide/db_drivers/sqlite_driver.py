import sqlite3
import os
import json
from typing import Any, Optional, Union, List
from ..response import ok, error, Response
from ..sqlite import JSONParser
from ..db_base import BaseDbDriver

# Register adapters at module level for SQLite
sqlite3.register_adapter(dict, lambda d: json.dumps(d, ensure_ascii=False))
sqlite3.register_adapter(list, lambda l: json.dumps(l, ensure_ascii=False))
sqlite3.register_adapter(tuple, lambda t: json.dumps(t, ensure_ascii=False))
sqlite3.register_converter("JSON", lambda b: json.loads(b.decode("utf-8")))

class SqliteDriver(BaseDbDriver):
    """
    SQLite driver implementation for py_aide.
    """

    def __init__(
        self,
        db_path: str,
        readonly: bool = True,
        wal_mode: bool = True,
        tables: Optional[dict] = None,
        attachments: Optional[list] = None
    ):
        self.db_path = os.path.abspath(db_path)
        self.readonly = readonly
        self.wal_mode = wal_mode
        self.tables = tables or {}
        self.attachments = attachments or []
        self.conn = None
        self.cursor = None
        self._wal_configured = False

    def connect(self):
        if self.conn is None:
            # Ensure the directory exists
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)

            self.conn = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
                detect_types=sqlite3.PARSE_DECLTYPES,
            )
            self.conn.row_factory = sqlite3.Row
            self.cursor = self.conn.cursor()
            
            if self.wal_mode and not self.readonly and not self._wal_configured:
                self._configure_wal()
            
            
            if self.tables:
                self._create_tables()

            if self.attachments:
                for attachment in self.attachments:
                    att_path = attachment.get("path")
                    att_alias = attachment.get("alias")
                    if att_path and att_alias:
                        self.cursor.execute(f"ATTACH DATABASE '{att_path}' AS {att_alias}")
        return self.conn

    def disconnect(self):
        if self.conn:
            self.cursor.close()
            self.conn.close()
            self.conn = None
            self.cursor = None

    def _configure_wal(self):
        try:
            self.conn.executescript("PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL;")
            self._wal_configured = True
        except:
            pass

    def _create_tables(self):
        for table, definition in self.tables.items():
            self.cursor.execute(f'CREATE TABLE IF NOT EXISTS "{table}" ({definition})')
        self.conn.commit()

    def insert(self, *, table: str, data: list) -> Response:
        try:
            if not data: return ok()
            
            if isinstance(data[0], dict):
                columns = data[0].keys()
                cols_str = ", ".join([f'"{c}"' for c in columns])
                placeholders = ", ".join(["?" for _ in columns])
                query = f'INSERT INTO "{table}" ({cols_str}) VALUES ({placeholders})'
                values = [tuple(row.values()) for row in data]
                if len(values) == 1:
                    self.cursor.execute(query, values[0])
                else:
                    self.cursor.executemany(query, values)
            else:
                placeholders = ", ".join(["?" for _ in range(len(data[0]))])
                query = f'INSERT INTO "{table}" VALUES ({placeholders})'
                if len(data) == 1:
                    self.cursor.execute(query, data[0])
                else:
                    self.cursor.executemany(query, data)
                
            return ok(data=self.cursor.lastrowid)
        except Exception as e:
            return error(message=str(e))

    def update(self, *, table: str, columns: list, column_data: list, condition: str, condition_data: list) -> Response:
        try:
            parsed_cols, new_values = JSONParser.parse_write_columns(columns=columns, values=column_data)
            set_clause = ", ".join(parsed_cols)
            parsed_condition = JSONParser.parse_condition(condition)
            query = f'UPDATE "{table}" SET {set_clause} WHERE {parsed_condition}'
            self.cursor.execute(query, new_values + condition_data)
            return ok(data={"affected_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def delete(self, *, table: str, condition: str, condition_data: list) -> Response:
        try:
            parsed_condition = JSONParser.parse_condition(condition)
            query = f'DELETE FROM "{table}" WHERE {parsed_condition}'
            self.cursor.execute(query, condition_data)
            return ok(data={"deleted_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def fetch(self, *, table: str, columns: list, condition: Optional[str] = None, condition_data: Optional[list] = None, limit: int = 1000, offset: int = 0) -> Response:
        try:
            parsed_columns = [JSONParser.parse_read_column(column_string=c) for c in columns]
            cols = ", ".join(parsed_columns)
            query = f'SELECT {cols} FROM "{table}"'
            if condition:
                query += f" WHERE {JSONParser.parse_condition(condition)}"
            query += " LIMIT ? OFFSET ?"
            params = (condition_data or []) + [limit, offset]
            self.cursor.execute(query, params)
            rows = [dict(row) for row in self.cursor.fetchall()]
            return ok(data=self._parse_json_results(rows))
        except Exception as e:
            return error(message=str(e))

    def execute(self, *, query: str, data: Optional[list] = None) -> Response:
        try:
            is_select = query.strip().lower().startswith("select")
            self.cursor.execute(JSONParser.parse_condition(query), data or [])
            if is_select:
                rows = [dict(row) for row in self.cursor.fetchall()]
                return ok(data=self._parse_json_results(rows))
            return ok(data={"affected_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def create_index(self, *, table: str, columns: list, unique: bool = False, index_name: Optional[str] = None) -> Response:
        try:
            if not index_name:
                # Sanitize columns for the index name
                safe_cols = [c.replace("->", "_").replace(">", "").replace(" ", "") for c in columns]
                index_name = f"idx_{table}_{'_'.join(safe_cols)}"
                
            parsed_cols = []
            for c in columns:
                if "::" in c:
                    # Translate DSL (data::name) to SQLite JSON path (data ->> '$.name')
                    parsed_cols.append(JSONParser.parse_read_column(column_string=c))
                else:
                    parsed_cols.append(f'"{c}"')

            cols_str = ", ".join(parsed_cols)
            unique_str = "UNIQUE " if unique else ""
            query = f'CREATE {unique_str}INDEX IF NOT EXISTS "{index_name}" ON "{table}" ({cols_str})'
            
            self.cursor.execute(query)
            return ok(data={"index_name": index_name})
        except Exception as e:
            return error(message=str(e))

    def database_exists(self, db_name: str) -> bool:
        # For SQLite, the database is a file that is auto-created on connect.
        # We always return True to skip the manual 'create_database' phase.
        return True

    def create_database(self, db_name: str) -> Response:
        # SQLite auto-creates files, so this is a no-op.
        return ok()

    def commit(self) -> Response:
        try:
            self.conn.commit()
            return ok()
        except Exception as e:
            return error(message=str(e))

    def rollback(self) -> None:
        try:
            self.conn.rollback()
        except:
            pass

    def _parse_json_results(self, rows: list[dict]) -> list[dict]:
        for row in rows:
            for key, value in row.items():
                if isinstance(value, str):
                    stripped = value.strip()
                    if stripped.startswith(("[", "{")) and stripped.endswith(("]", "}")):
                        try:
                            row[key] = json.loads(stripped)
                        except:
                            pass
        return rows
