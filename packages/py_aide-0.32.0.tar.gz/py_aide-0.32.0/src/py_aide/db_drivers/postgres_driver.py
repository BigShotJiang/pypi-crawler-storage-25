import json
import logging
import importlib
from typing import Any, Optional, Union, List
from ..response import ok, error, Response
from ..db_base import BaseDbDriver
from ..postgres import PostgresJSONParser

logger = logging.getLogger(__name__)

class PostgresDriver(BaseDbDriver):
    """
    Postgres driver implementation for py_aide.
    Requires 'psycopg2' or 'psycopg' library.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        user: str = "postgres",
        password: str = "",
        database: str = "postgres",
        readonly: bool = True,
        tables: Optional[dict] = None,
        **kwargs
    ):
        self.readonly = readonly
        self.tables = tables or {}
        self.config = {
            "host": host,
            "port": port,
            "user": user,
            "password": password,
            "database": database,
            **kwargs
        }
        self.conn = None
        self.cursor = None
        
        try:
            import psycopg2
            from psycopg2.extras import RealDictCursor
            self.lib = psycopg2
            self.version = 2
            self.cursor_factory = RealDictCursor
        except ImportError:
            try:
                psycopg = importlib.import_module("psycopg")
                self.lib = psycopg
                self.version = 3
                self.cursor_factory = None 
            except ImportError:
                self.lib = None
                self.version = 0

    def _ensure_lib(self):
        if self.lib is None:
            raise ImportError("Postgres library (psycopg2 or psycopg) is required. Install with 'pip install psycopg2-binary'.")

    def connect(self):
        self._ensure_lib()
        if self.conn is None:
            # Note: Basic connection logic. In production, we'd use a pool.
            # 1. Connection
            self.conn = self.lib.connect(**self.config)
            
            # 2. Cursor Factory (v2 only)
            if self.version == 2:
                self.cursor = self.conn.cursor(cursor_factory=self.cursor_factory)
                
                # Enable automatic JSONB support for psycopg2
                from psycopg2.extras import register_default_jsonb, Json
                from psycopg2.extensions import register_adapter
                
                # Reading: JSONB -> Python dict
                register_default_jsonb(conn_or_curs=self.conn)
                
                # Writing: Python dict/list -> JSONB
                register_adapter(dict, Json)
                register_adapter(list, Json)
            
            elif self.version == 3:
                # psycopg3 handles JSONB natively if configured, 
                # or we use the dict_row for dictionary-like access
                rows_mod = importlib.import_module("psycopg.rows")
                self.cursor = self.conn.cursor(row_factory=rows_mod.dict_row)
                
                # v3 doesn't need register_adapter for JSON usually, 
                # but we can force it if needed. For now, v3 is more modern.
                pass

            if self.readonly:
                self.conn.set_session(readonly=True)

            if self.tables:
                self._create_tables()
        return self.conn

    def _create_tables(self):
        for table, definition in self.tables.items():
            self.cursor.execute(f'CREATE TABLE IF NOT EXISTS "{table}" ({definition})')
        self.conn.commit()

    def disconnect(self):
        if self.conn:
            self.cursor.close()
            self.conn.close()
            self.conn = None
            self.cursor = None

    def _translate_query(self, query: str) -> str:
        """
        Translates SQLite-style queries and JSON paths to Postgres.
        Uses PostgresJSONParser for DSL parsing, and replaces ? with %s.
        """
        # 1. Handle DSL syntax (e.g. table::path[+=])
        translated = PostgresJSONParser.parse_condition(query)
        
        # 2. Replace SQLite positional placeholders with Postgres
        translated = translated.replace("?", "%s")
        
        return translated

    def insert(self, *, table: str, data: list) -> Response:
        try:
            if not data: return ok()
            columns = data[0].keys() if isinstance(data[0], dict) else None
            
            if columns:
                cols_str = ", ".join([f'"{c}"' for c in columns])
                placeholders = ", ".join(["%s" for _ in columns])
                query = f'INSERT INTO "{table}" ({cols_str}) VALUES ({placeholders})'
                values = [tuple(row.values()) for row in data]
            else:
                placeholders = ", ".join(["%s" for _ in range(len(data[0]))])
                query = f'INSERT INTO "{table}" VALUES ({placeholders})'
                values = data

            self.cursor.executemany(query, values)
            return ok()
        except Exception as e:
            return error(message=str(e))

    def update(self, *, table: str, columns: list, column_data: list, condition: str, condition_data: list) -> Response:
        try:
            parsed_cols, new_values = PostgresJSONParser.parse_write_columns(columns=columns, values=column_data)
            set_clause = ", ".join(parsed_cols)
            parsed_condition = self._translate_query(condition)
            query = f'UPDATE "{table}" SET {set_clause} WHERE {parsed_condition}'
            
            # The flattened_values now have lists json.dump'ed
            self.cursor.execute(query, new_values + condition_data)
            return ok(data={"affected_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def delete(self, *, table: str, condition: str, condition_data: list) -> Response:
        try:
            translated_condition = self._translate_query(condition)
            query = f'DELETE FROM "{table}" WHERE {translated_condition}'
            self.cursor.execute(query, condition_data)
            return ok(data={"deleted_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def fetch(self, *, table: str, columns: list, condition: Optional[str] = None, condition_data: Optional[list] = None, limit: int = 1000, offset: int = 0) -> Response:
        try:
            parsed_columns = [PostgresJSONParser.parse_read_column(column_string=c) for c in columns]
            cols = ", ".join(parsed_columns)
            query = f'SELECT {cols} FROM "{table}"'
            
            if condition:
                query += f" WHERE {self._translate_query(condition)}"
                
            query += " LIMIT %s OFFSET %s"
            params = (condition_data or []) + [limit, offset]
            
            self.cursor.execute(query, params)
            
            # psycopg2 RealDictCursor already returns dict-like objects
            rows = [dict(row) for row in self.cursor.fetchall()]
            
            return ok(data=self._parse_json_results(rows))
        except Exception as e:
            return error(message=str(e))

    def execute(self, *, query: str, data: Optional[list] = None) -> Response:
        try:
            translated_query = self._translate_query(query)
            is_select = translated_query.strip().lower().startswith("select")
            
            self.cursor.execute(translated_query, data or [])
            
            if is_select:
                rows = [dict(row) for row in self.cursor.fetchall()]
                return ok(data=self._parse_json_results(rows))
            return ok(data={"affected_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def create_index(self, *, table: str, columns: list, unique: bool = False, index_name: Optional[str] = None) -> Response:
        try:
            if not index_name:
                # Sanitize columns for the index name
                safe_cols = [c.replace("::", "_").replace("[", "").replace("]", "").replace(" ", "") for c in columns]
                index_name = f"idx_{table}_{'_'.join(safe_cols)}"
                
            parsed_cols = []
            for c in columns:
                if "::" in c:
                    # Functional Index in Postgres requires double parentheses: (( expression ))
                    # parse_read_column returns something like 'data #>> '{name}''
                    expr = PostgresJSONParser.parse_read_column(column_string=c)
                    parsed_cols.append(f"({expr})")
                else:
                    parsed_cols.append(f'"{c}"')

            cols_str = ", ".join(parsed_cols)
            unique_str = "UNIQUE " if unique else ""
            query = f'CREATE {unique_str}INDEX IF NOT EXISTS "{index_name}" ON "{table}" ({cols_str})'
            
            self.cursor.execute(query)
            return ok(data={"index_name": index_name})
        except Exception as e:
            return error(message=str(e))

    def database_exists(self, db_name: str) -> bool:
        self.cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", [db_name])
        return self.cursor.fetchone() is not None

    def create_database(self, db_name: str) -> Response:
        try:
            # Ensure any open transaction from 'database_exists' is closed
            if self.conn:
                self.conn.rollback()

            # Postgres requires autocommit=True for CREATE DATABASE commands
            old_autocommit = self.conn.autocommit
            self.conn.autocommit = True
            try:
                # Use double quotes for identifiers like database names
                self.cursor.execute(f'CREATE DATABASE "{db_name}"')
                return ok()
            finally:
                self.conn.autocommit = old_autocommit
        except Exception as e:
            return error(message=str(e))

    def commit(self) -> Response:
        try:
            self.conn.commit()
            return ok()
        except Exception as e:
            return error(message=str(e))

    def rollback(self) -> None:
        try:
            self.conn.rollback()
        except:
            pass

    def _parse_json_results(self, rows: list[dict]) -> list[dict]:
        """Auto-parse JSON strings back to dict/list if they look like JSON."""
        for row in rows:
            for key, value in row.items():
                if isinstance(value, str):
                    stripped = value.strip()
                    if stripped.startswith(("[", "{")) and stripped.endswith(("]", "}")):
                        try:
                            row[key] = json.loads(stripped)
                        except:
                            pass
        return rows
