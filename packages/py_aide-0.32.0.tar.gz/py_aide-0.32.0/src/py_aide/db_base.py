from abc import ABC, abstractmethod
from typing import Any, Optional, Union, List
from .response import Response

class BaseDbDriver(ABC):
    """
    Abstract Base Class for all py_aide database drivers.
    """

    @abstractmethod
    def connect(self) -> Any:
        pass

    @abstractmethod
    def disconnect(self) -> None:
        pass

    @abstractmethod
    def insert(self, *, table: str, data: list) -> Response:
        pass

    @abstractmethod
    def update(
        self,
        *,
        table: str,
        columns: list,
        column_data: list,
        condition: str,
        condition_data: list,
    ) -> Response:
        pass

    @abstractmethod
    def delete(self, *, table: str, condition: str, condition_data: list) -> Response:
        pass

    @abstractmethod
    def fetch(
        self,
        *,
        table: str,
        columns: list,
        condition: Optional[str] = None,
        condition_data: Optional[list] = None,
        limit: int = 1000,
        offset: int = 0,
    ) -> Response:
        pass

    @abstractmethod
    def execute(self, *, query: str, data: Optional[list] = None) -> Response:
        pass

    @abstractmethod
    def create_index(self, *, table: str, columns: list, unique: bool = False, index_name: Optional[str] = None) -> Response:
        pass

    @abstractmethod
    def database_exists(self, db_name: str) -> bool:
        pass

    @abstractmethod
    def create_database(self, db_name: str) -> Response:
        pass

    @abstractmethod
    def commit(self) -> Response:
        pass

    @abstractmethod
    def rollback(self) -> None:
        pass
