from dataclasses import dataclass, field
from typing import Any, Optional, Union, Dict, List
import logging
from .database import Api
from .response import Response, ok, error
from .codes import generate_code, CodeType
from .dates import DateUtils

logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class Permission:
    """
    A Permission definition.
    Explicitly defines the action (e.g. 'delete') and the group (e.g. 'user').
    """
    action: str
    group: str = "general"
    description: str = ""

    @property
    def name(self) -> str:
        """The unique identifier used in database lookups."""
        return f"{self.group}.{self.action}"

    @property
    def display_name(self) -> str:
        """
        Converts 'user.delete' into 'Delete User'.
        """
        return f"{self.action.replace('_', ' ').capitalize()} {self.group.replace('_', ' ').capitalize()}"

    def __repr__(self) -> str:
        return f"Permission({self.name})"


class PermissionRegistry:
    """
    Singleton registry to harvest all permissions used in the application.
    """
    _permissions: Dict[str, Permission] = {}

    @classmethod
    def register(cls, *, action: str, group: str = "general", description: str = "") -> Permission:
        """
        Register a permission in the system.
        """
        perm_obj = Permission(action=action, group=group, description=description)
        cls._permissions[perm_obj.name] = perm_obj
        return perm_obj

    @classmethod
    def get_all(cls) -> List[Permission]:
        """Return all registered permissions."""
        return list(cls._permissions.values())

    @classmethod
    def get(cls, name: str) -> Optional[Permission]:
        """Get a permission by its machine name."""
        return cls._permissions.get(name)


class PermissionsManager:
    """
    Manages roles, permissions, and hierarchical access control.
    Supports both SQLite and Postgres via the document-style (tstamp, id, data) schema.
    """
    
    TABLE_DEFINITION = "tstamp TEXT, id TEXT, data JSON"

    @staticmethod
    def get_blueprint() -> Dict[str, str]:
        """Returns the engine-agnostic schema blueprint for all permission tables."""
        return {
            "permissions": PermissionsManager.TABLE_DEFINITION,
            "contexts": PermissionsManager.TABLE_DEFINITION,
            "roles": PermissionsManager.TABLE_DEFINITION,
            "role_permissions": PermissionsManager.TABLE_DEFINITION,
            "user_roles": PermissionsManager.TABLE_DEFINITION,
            "user_permissions": PermissionsManager.TABLE_DEFINITION
        }

    def __init__(self, db: Api):
        self.db = db
        self._provision()

    def _provision(self):
        """Provision tables using the internal setup_databases mechanism."""
        # Identify the database identifier (file path for SQLite, db name for Postgres)
        engine_val = self.db.engine.value if hasattr(self.db.engine, "value") else str(self.db.engine)
        if engine_val == "sqlite":
            db_id = self.db.driver.db_path
        else:
            db_id = self.db.driver.config.get("database")
        
        # Prepare configuration for setup_databases
        config = {"engine": self.db.engine}
        if engine_val == "sqlite":
            config["db_path"] = db_id
        if hasattr(self.db.driver, "config"):
            config.update(self.db.driver.config)
        
        # Ensure readonly is False for provisioning
        config["readonly"] = False
        
        try:
            # 1. Create Tables
            Api.setup_databases({db_id: self.get_blueprint()}, **config)

            # 2. Create Functional Indexes for performance
            # We use with self.db here to get a connection context for the indexing calls
            with self.db as api:
                # permissions: name
                api.create_index(table="permissions", columns=["data::name"], unique=True)
                
                # contexts: parent_id
                api.create_index(table="contexts", columns=["data::parent_id"])
                
                # roles: name, context_id
                api.create_index(table="roles", columns=["data::name"])
                api.create_index(table="roles", columns=["data::context_id"])
                
                # role_permissions: role_id, permission_name
                api.create_index(table="role_permissions", columns=["data::role_id"])
                api.create_index(table="role_permissions", columns=["data::permission_name"])
                
                # user_roles: user_id, role_id, context_id
                api.create_index(table="user_roles", columns=["data::user_id"])
                api.create_index(table="user_roles", columns=["data::role_id"])
                api.create_index(table="user_roles", columns=["data::context_id"])
                
                # user_permissions: user_id, permission_name, context_id
                api.create_index(table="user_permissions", columns=["data::user_id"])
                api.create_index(table="user_permissions", columns=["data::permission_name"])
                api.create_index(table="user_permissions", columns=["data::context_id"])

        except Exception as e:
            logger.error(f"PermissionsManager: Provisioning failed: {e}")

    def sync_catalog(self, *, registry: List[Permission]) -> Response:
        """
        Synchronize the code-level permissions with the database catalog.
        Adds new permissions and updates descriptions.
        """
        try:
            with self.db as api:
                ts = DateUtils.current_timestamp()
                for perm in registry:
                    # UPSERT logic using JSON paths
                    check = api.fetch(
                        table="permissions", 
                        columns=["id"], 
                        condition="data::name = ?", 
                        condition_data=[perm.name]
                    )
                    
                    if check.data:
                        # Update
                        res = api.update(
                            table="permissions",
                            columns=["data::description", "data::group_name", "data::action", "data::last_seen", "data::is_active", "tstamp"],
                            column_data=[perm.description, perm.group, perm.action, ts, 1, ts],
                            condition="id = ?",
                            condition_data=[check.data[0]["id"]]
                        )
                        if not res.status:
                            return res
                    else:
                        # Insert
                        res = api.insert(
                            table="permissions",
                            data=[{
                                "id": generate_code(16),
                                "tstamp": ts,
                                "data": {
                                    "name": perm.name,
                                    "group_name": perm.group,
                                    "action": perm.action,
                                    "description": perm.description,
                                    "is_active": 1,
                                    "last_seen": ts
                                }
                            }]
                        )
                        if not res.status:
                            return res
                
                # Mark missing permissions as inactive
                all_names = [p.name for p in registry]
                if all_names:
                    placeholders = ",".join(["?"] * len(all_names))
                    res = api.update(
                        table="permissions",
                        columns=["data::is_active", "tstamp"],
                        column_data=[0, ts],
                        condition=f"data::name NOT IN ({placeholders})",
                        condition_data=all_names
                    )
                    if not res.status:
                        return res
            return ok(data="Permissions catalog synced successfully")
        except Exception as e:
            logger.error(f"Failed to sync permissions catalog: {e}")
            return error(message=str(e))

    def get_all_permissions(self) -> Dict[str, List[Dict[str, str]]]:
        """
        Returns all permissions grouped by 'group' for frontend consumption.
        """
        with self.db as api:
            res = api.fetch(
                table="permissions", 
                columns=["data::name as name", "data::group_name as group_name", "data::action as action", "data::description as description"], 
                condition="data::is_active = ?",
                condition_data=[1]
            )
            if not res.status or not res.data:
                if not res.status:
                    logger.warning(f"Failed to fetch permissions: {res.log}")
                return {}

            grouped = {}
            for row in res.data:
                group = row["group_name"] or "general"
                action = row["action"] or row["name"]
                
                perm_obj = Permission(action=action, group=group, description=row["description"] or "")
                
                if group not in grouped:
                    grouped[group] = []
                    
                grouped[group].append({
                    "perm_name": perm_obj.display_name,
                    "perm": perm_obj.name,
                    "description": perm_obj.description
                })
                
            return grouped

    def has_permission(self, *, user_id: str, permission_name: str, context_id: Optional[Union[int, str]] = None) -> bool:
        """
        Check if a user has a specific permission in a given context (or its parents).
        Implements 'The Climb' logic.
        """
        current_context = context_id
        
        while True:
            # 1. Check for direct permission or role-based permission at this level
            if self._check_direct_access(user_id, permission_name, current_context):
                return True
                
            # 2. Check Global Access if we hit the top
            if current_context is None:
                break
                
            # 3. Climb up to the parent
            parent = self._get_parent_context(current_context)
            current_context = parent # Could be None (Root)
            
        return False

    def _check_direct_access(self, user_id: str, permission_name: str, context_id: Optional[Union[int, str]]) -> bool:
        """Helper to check if user has permission at a specific context level."""
        u_id = str(user_id)
        c_id = str(context_id) if context_id is not None else None
        
        with self.db as api:
            logger.debug(f"[_check_direct_access] user={u_id} perm={permission_name} context={c_id}")
            # 1. Check user_permissions (Overrides)
            res = api.fetch(
                table="user_permissions",
                columns=["1"],
                condition="data::user_id = ? AND data::permission_name = ? AND (data::context_id = ? OR (data::context_id IS NULL AND ? IS NULL))",
                condition_data=[u_id, permission_name, c_id, c_id]
            )
            if res.status and res.data:
                logger.debug(f"Found direct override for {u_id} in context {c_id}")
                return True

            # 2. Check role_permissions via user_roles
            role_res = api.fetch(
                table="user_roles",
                columns=["data::role_id as role_id"],
                condition="data::user_id = ? AND (data::context_id = ? OR (data::context_id IS NULL AND ? IS NULL))",
                condition_data=[u_id, c_id, c_id]
            )
            
            if not role_res.status or not role_res.data:
                logger.debug(f"No roles found for {u_id} in context {c_id}. Status: {role_res.status}, Log: {role_res.log}")
                return False

            role_ids = [str(r["role_id"]) for r in role_res.data]
            logger.debug(f"Found roles for {u_id} in context {c_id}: {role_ids}")
            placeholders = ",".join(["?"] * len(role_ids))
            
            perm_res = api.fetch(
                table="role_permissions",
                columns=["1"],
                condition=f"data::role_id IN ({placeholders}) AND data::permission_name = ?",
                condition_data=role_ids + [permission_name]
            )
            found = bool(perm_res.status and perm_res.data)
            logger.debug(f"Role permission match for {role_ids} + {permission_name}: {found}")
            return found

    def _get_parent_context(self, context_id: Union[int, str]) -> Optional[Union[int, str]]:
        """Fetch the parent_id for a given context."""
        with self.db as api:
            res = api.fetch(table="contexts", columns=["data::parent_id as parent_id"], condition="id = ?", condition_data=[context_id])
            if res.status and res.data:
                return res.data[0]["parent_id"]
        return None

    def get_user_permissions(self, *, user_id: str, context_id: Optional[Union[int, str]] = None) -> List[str]:
        """
        Returns all effective permissions for a user in a given context (including inheritance).
        """
        u_id = str(user_id)
        effective_perms = set()
        current_context = context_id
        visited = set()

        with self.db as api:
            while current_context not in visited:
                visited.add(current_context)
                c_id = str(current_context) if current_context is not None else None
                
                # 1. Get from roles
                role_res = api.fetch(
                    table="user_roles",
                    columns=["data::role_id as role_id"],
                    condition="data::user_id = ? AND (data::context_id = ? OR (data::context_id IS NULL AND ? IS NULL))",
                    condition_data=[u_id, c_id, c_id]
                )
                
                if role_res.status and role_res.data:
                    role_ids = [str(r["role_id"]) for r in role_res.data]
                    placeholders = ",".join(["?"] * len(role_ids))
                    perms = api.fetch(
                        table="role_permissions",
                        columns=["data::permission_name as name"],
                        condition=f"data::role_id IN ({placeholders})",
                        condition_data=role_ids
                    )
                    if perms.status and perms.data:
                        for row in perms.data:
                            effective_perms.add(row["name"])
                    
                # 2. Get from direct permissions
                direct = api.fetch(
                    table="user_permissions",
                    columns=["data::permission_name as name"],
                    condition="data::user_id = ? AND (data::context_id = ? OR (data::context_id IS NULL AND ? IS NULL))",
                    condition_data=[u_id, c_id, c_id]
                )
                if direct.status and direct.data:
                    for row in direct.data:
                        effective_perms.add(row["name"])
                    
                if current_context is None:
                    break
                    
                current_context = self._get_parent_context(current_context)
            
        return sorted(list(effective_perms))

    # --- Management API ---

    def create_context(self, *, name: str, context_id: Optional[Union[int, str]] = None, parent_id: Optional[Union[int, str]] = None) -> Response:
        """Create a new context with a text ID."""
        with self.db as api:
            if parent_id:
                # Validate parent context exists
                parent_check = api.fetch(table="contexts", columns=["id"], condition="id = ?", condition_data=[parent_id])
                if not parent_check.status or not parent_check.data:
                    return error(message=f"Parent context '{parent_id}' not found")

            rec_id = str(context_id) if context_id else generate_code(16)
            p_id = str(parent_id) if parent_id else None
            ts = DateUtils.current_timestamp()
            api.insert(table="contexts", data=[{
                "id": rec_id,
                "tstamp": ts,
                "data": {"name": name, "parent_id": p_id}
            }])
            return ok(data=rec_id)

    def create_role(self, *, name: str, role_id: Optional[Union[int, str]] = None, description: str = "", context_id: Optional[Union[int, str]] = None) -> Response:
        """Create a new role with a text ID."""
        with self.db as api:
            rec_id = str(role_id) if role_id else generate_code(16)
            c_id = str(context_id) if context_id else None
            ts = DateUtils.current_timestamp()
            api.insert(table="roles", data=[{
                "id": rec_id,
                "tstamp": ts,
                "data": {"name": name, "description": description, "context_id": c_id}
            }])
            return ok(data=rec_id)

    def assign_permission_to_role(self, *, role_id: Union[int, str], permission_names: Union[str, List[str]]) -> Response:
        """Link one or more permissions to a role."""
        names = permission_names if isinstance(permission_names, list) else [permission_names]
        if not names: return ok()

        with self.db as api:
            # 1. Validate Role exists
            role_check = api.fetch(table="roles", columns=["id"], condition="id = ? OR data::name = ?", condition_data=[role_id, role_id])
            if not role_check.status or not role_check.data:
                return error(message=f"Role '{role_id}' not found")

            # 2. Validate Permissions exist
            placeholders = ",".join(["?"] * len(names))
            perm_res = api.fetch(
                table="permissions", 
                columns=["id", "data::name as name"], 
                condition=f"data::name IN ({placeholders})", 
                condition_data=names
            )
            if not perm_res.status or not perm_res.data:
                return error(message="None of the specified permissions were found")
            
            ts = DateUtils.current_timestamp()
            records = []
            for row in perm_res.data:
                records.append({
                    "id": generate_code(16),
                    "tstamp": ts,
                    "data": {
                        "role_id": str(role_id), 
                        "permission_id": row["id"],
                        "permission_name": row["name"]
                    }
                })
            return api.insert(table="role_permissions", data=records)

    def assign_role_to_user(self, *, user_id: str, role_ids: Union[str, List[str]], context_id: Optional[Union[int, str]] = None) -> Response:
        """Assign one or more roles to a user in a context."""
        ids = role_ids if isinstance(role_ids, list) else [role_ids]
        if not ids: return ok()

        with self.db as api:
            # 1. Validate Roles exist
            placeholders = ",".join(["?"] * len(ids))
            role_check = api.fetch(
                table="roles", 
                columns=["id"], 
                condition=f"id IN ({placeholders}) OR data::name IN ({placeholders})", 
                condition_data=ids + ids
            )
            if not role_check.status or len(role_check.data) < len(ids):
                logger.debug(f"Role validation failed for ids {ids}. Found: {role_check.data if role_check.status else role_check.log}")
                return error(message="One or more specified roles were not found")

            ts = DateUtils.current_timestamp()
            records = [{
                "id": generate_code(16),
                "tstamp": ts,
                "data": {
                    "user_id": str(user_id), 
                    "role_id": str(rid), 
                    "context_id": str(context_id) if context_id is not None else None
                }
            } for rid in ids]
            logger.debug(f"Inserting user_roles: {records}")
            return api.insert(table="user_roles", data=records)

    def assign_permission_to_user(self, *, user_id: str, permission_names: Union[str, List[str]], context_id: Optional[Union[int, str]] = None) -> Response:
        """Assign one or more direct permission overrides to a user."""
        names = permission_names if isinstance(permission_names, list) else [permission_names]
        if not names: return ok()

        with self.db as api:
            placeholders = ",".join(["?"] * len(names))
            perm_res = api.fetch(
                table="permissions", 
                columns=["id", "data::name as name"], 
                condition=f"data::name IN ({placeholders})", 
                condition_data=names
            )
            if not perm_res.status or not perm_res.data:
                return error(message="None of the specified permissions were found")
                
            ts = DateUtils.current_timestamp()
            records = []
            for row in perm_res.data:
                records.append({
                    "id": generate_code(16),
                    "tstamp": ts,
                    "data": {
                        "user_id": str(user_id), 
                        "permission_id": row["id"], 
                        "permission_name": row["name"],
                        "context_id": str(context_id) if context_id is not None else None
                    }
                })
            return api.insert(table="user_permissions", data=records)

    def revoke_permission_from_role(self, *, role_id: Union[int, str], permission_names: Union[str, List[str]]) -> Response:
        """Remove one or more permissions from a role's definition."""
        names = permission_names if isinstance(permission_names, list) else [permission_names]
        if not names: return ok()

        with self.db as api:
            placeholders = ",".join(["?"] * len(names))
            return api.delete(
                table="role_permissions",
                condition=f"data::role_id = ? AND data::permission_name IN ({placeholders})",
                condition_data=[role_id] + names
            )

    def revoke_role_from_user(self, *, user_id: str, role_ids: Union[str, List[str]], context_id: Optional[Union[int, str]] = None) -> Response:
        """Remove one or more role assignments from a user in a specific context."""
        ids = role_ids if isinstance(role_ids, list) else [role_ids]
        if not ids: return ok()

        with self.db as api:
            placeholders = ",".join(["?"] * len(ids))
            # Use null-safe context check
            return api.delete(
                table="user_roles",
                condition=f"data::user_id = ? AND data::role_id IN ({placeholders}) AND (data::context_id = ? OR (data::context_id IS NULL AND ? IS NULL))",
                condition_data=[user_id] + ids + [context_id, context_id]
            )

    def revoke_permission_from_user(self, *, user_id: str, permission_names: Union[str, List[str]], context_id: Optional[Union[int, str]] = None) -> Response:
        """Remove one or more direct permission overrides from a user."""
        names = permission_names if isinstance(permission_names, list) else [permission_names]
        if not names: return ok()

        with self.db as api:
            placeholders = ",".join(["?"] * len(names))
            # Use null-safe context check
            return api.delete(
                table="user_permissions",
                condition=f"data::user_id = ? AND data::permission_name IN ({placeholders}) AND (data::context_id = ? OR (data::context_id IS NULL AND ? IS NULL))",
                condition_data=[user_id] + names + [context_id, context_id]
            )

    def delete_role(self, *, role_id: Union[int, str]) -> Response:
        """Delete a role and all its associated permissions and user assignments."""
        with self.db as api:
            # 1. Remove role definition
            api.delete(table="roles", condition="id = ? OR data::name = ?", condition_data=[role_id, role_id])
            # 2. Remove permissions linked to this role
            api.delete(table="role_permissions", condition="data::role_id = ?", condition_data=[role_id])
            # 3. Remove user assignments to this role
            return api.delete(table="user_roles", condition="data::role_id = ?", condition_data=[role_id])

    def delete_context(self, *, context_id: Union[int, str]) -> Response:
        """Delete a context and all its roles, assignments, and child contexts."""
        with self.db as api:
            # Find all child contexts recursively (simplified for now: direct children)
            children = api.fetch(table="contexts", columns=["id"], condition="data::parent_id = ?", condition_data=[context_id])
            if children.status and children.data:
                for child in children.data:
                    self.delete_context(context_id=child["id"])

            # 1. Remove context definition
            api.delete(table="contexts", condition="id = ?", condition_data=[context_id])
            # 2. Remove roles tied to this context
            api.delete(table="roles", condition="data::context_id = ?", condition_data=[context_id])
            # 3. Remove user assignments in this context
            api.delete(table="user_roles", condition="data::context_id = ?", condition_data=[context_id])
            # 4. Remove direct user permissions in this context
            return api.delete(table="user_permissions", condition="data::context_id = ?", condition_data=[context_id])
