import time
import json
from typing import Any, List, Optional
from ..database import Api
from ..response import Response, ok, error
from ..enums import QueueEngine

class TaskResultStore:
    """
    Manages persistence for task results and hook execution status.
    Ensures that side effects (hooks) can be retried independently of the main task.
    """
    
    TABLE_NAME = "py_aide_task_results"
    SCHEMA = (
        "id TEXT PRIMARY KEY, "
        "queue_name TEXT, "
        "task_type TEXT, "
        "payload JSON, "
        "result JSON, "
        "hook_status TEXT DEFAULT 'pending', "
        "completed_at INTEGER"
    )

    def __init__(self, *, engine: QueueEngine | str, db_path: str = "_py_aide_queues.db", **kwargs):
        self.engine = engine if isinstance(engine, QueueEngine) else QueueEngine(str(engine).lower())
        self.db_path = db_path
        self.kwargs = kwargs
        
        if self.engine == QueueEngine.INTERNAL:
            self._db_config = {
                "db_path": self.db_path,
                "tables": {self.TABLE_NAME: self.SCHEMA},
                "readonly": False,
                "transactionMode": True,
                "wal_mode": True
            }

    def store(self, *, task_id: str, queue_name: str, task_type: str, payload: Any, result: Any, hook_status: str = "pending") -> Response:
        """Stores a task result for hook processing."""
        if self.engine == QueueEngine.INTERNAL:
            # Ensure JSON serialization for SQLite
            payload_str = json.dumps(payload) if not isinstance(payload, str) else payload
            result_str = json.dumps(result) if not isinstance(result, str) else result
            
            data = [[
                task_id,
                queue_name,
                task_type,
                payload_str,
                result_str,
                hook_status,
                int(time.time())
            ]]
            with Api(**self._db_config) as db:
                res = db.insert(table=self.TABLE_NAME, data=data)
                if res and res.status:
                    db.commit_transaction()
                    return res
                else:
                    err = res.log if res else "Unknown database error"
                    import logging
                    logging.error(f"TaskResultStore.store failed: {err}")
                    return res or error(message=err)
        
        # Redis implementation could go here
        return ok()

    def get_pending(self, limit: int = 10, min_age_seconds: int = 0) -> Response:
        """Retrieves tasks with pending hooks, optionally filtering by age."""
        if self.engine == QueueEngine.INTERNAL:
            condition = "hook_status = ?"
            condition_data = ["pending"]
            
            if min_age_seconds > 0:
                limit_time = int(time.time()) - min_age_seconds
                condition += " AND completed_at < ?"
                condition_data.append(limit_time)
                
            with Api(**self._db_config) as db:
                return db.fetch(
                    table=self.TABLE_NAME,
                    columns=["id", "task_type", "payload", "result", "hook_status"],
                    condition=condition,
                    condition_data=condition_data,
                    limit=limit
                )
        return ok(data=[])

    def mark_complete(self, task_id: str) -> Response:
        """Marks a hook as successfully completed."""
        if self.engine == QueueEngine.INTERNAL:
            with Api(**self._db_config) as db:
                res = db.update(
                    table=self.TABLE_NAME,
                    columns=["hook_status"],
                    column_data=["complete"],
                    condition="id = ?",
                    condition_data=[task_id]
                )
                if res:
                    db.commit_transaction()
                return res
        return ok()

    def cleanup(self, max_age_days: int = 7) -> Response:
        """Purges old results."""
        limit_time = int(time.time()) - (max_age_days * 86400)
        if self.engine == QueueEngine.INTERNAL:
            with Api(**self._db_config) as db:
                res = db.delete(
                    table=self.TABLE_NAME,
                    condition="completed_at < ?",
                    condition_data=[limit_time]
                )
                if res:
                    db.commit_transaction()
                return res
        return ok()
