import asyncio
import functools
import logging
from typing import Any, Callable, Coroutine, TypeVar

T = TypeVar("T")

logger = logging.getLogger("py_aide.threading")

def bridge_async(async_func: Callable[..., Coroutine[Any, Any, T]]) -> Callable[..., T]:
    """
    Bridges the gap between synchronous execution contexts (like background threads)
    and asynchronous handlers.
    
    ### The Problem: The "Silent Killer"
    In modern Python frameworks (FastAPI, etc.), many handlers are defined as `async`.
    However, background worker systems like `TaskBuffer` or `Scheduler` often run 
    in standard OS threads. If you pass an `async` function directly to a thread, 
    one of two failures occurs:
    
    1. **Silent Failure**: The function returns a 'coroutine object' immediately 
       without actually executing the logic. The system marks the task as 'Success', 
       but no work was done.
    2. **Runtime Error**: The program crashes because no event loop is running 
       in the background thread to drive the coroutine.
    
    ### The Solution
    `bridge_async` wraps your asynchronous function in a synchronous "shell". When
    the shell is called:
    
    1. It detects if an event loop is already running in the current thread.
    2. If not, it creates and configures a new one for that specific thread.
    3. It uses `loop.run_until_complete()` to drive the coroutine and wait for the 
       actual result (e.g., a `Response` object).
    
    ### Example Usage
    ```python
    async def send_email(data):
        # async logic here...
        return ok()
        
    # Wrap it for the sync TaskBuffer
    sync_handler = bridge_async(send_email)
    
    buffer = TaskBuffer(
        name="email_sender",
        handlers={"send": sync_handler}
    )
    ```
    
    Returns:
        A synchronous wrapper function that safely executes the async code.
    """
    @functools.wraps(async_func)
    def wrapper(*args, **kwargs) -> T:
        try:
            # Check if this thread already has an active running loop
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop in this thread, create a fresh one
            logger.debug(f"Creating new event loop for thread: {async_func.__name__}")
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
        # Execute and block until finished
        return loop.run_until_complete(async_func(*args, **kwargs))
        
    return wrapper
