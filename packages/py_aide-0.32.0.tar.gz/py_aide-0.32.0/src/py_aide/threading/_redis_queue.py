import time
import uuid
import json
from typing import Any, Optional
from ..response import Response, ok, error
from .base_queue import BaseQueue

class RedisQueue(BaseQueue):
    """
    A high-performance, Redis-backed persistent queue for py_aide.
    
    This driver implements a 'Reliable Queue' pattern using three Redis structures:
    1. Hash (data): Mapping of task_id -> task_json.
    2. Sorted Set (pending): Priority queue of task_ids.
    3. Hash (processing): Trackers for tasks currently being handled by workers.
    
    Attributes:
        queue_name (str): The identifier for this specific queue.
        key_data (str): Redis key for the task storage hash.
        key_pending (str): Redis key for the priority sorted set.
        key_processing (str): Redis key for the active task tracker.
    """

    def __init__(self, *, queue_name: str = "default", **kwargs):
        """
        Initializes the Redis driver with lazy-loading for the redis library.
        
        Args:
            queue_name: Unique name for the queue (namespaces the Redis keys).
            **kwargs: Connection parameters (host, port, password, db).
        """
        self.queue_name = queue_name
        self.kwargs = kwargs
        self._client = None
        
        # Build Namespaced Keys: This prevents 'task1' in 'email_queue' 
        # from colliding with 'task1' in 'image_queue'.
        self.key_prefix = f"pa:q:{queue_name}"
        self.key_data = f"{self.key_prefix}:data"
        self.key_pending = f"{self.key_prefix}:pending"
        self.key_processing = f"{self.key_prefix}:processing"
        
        # Lazy import allows py_aide to load even if 'redis' isn't installed.
        try:
            import redis
            self.redis_lib = redis
        except ImportError:
            self.redis_lib = None

    def _get_client(self):
        """Internal helper to manage the Redis connection singleton."""
        if self.redis_lib is None:
            return None
        
        if self._client is None:
            try:
                self._client = self.redis_lib.Redis(
                    host=self.kwargs.get("host", "localhost"),
                    port=self.kwargs.get("port", 6379),
                    password=self.kwargs.get("password"),
                    db=self.kwargs.get("db", 0),
                    decode_responses=True # Returns strings instead of bytes
                )
            except Exception:
                return None
        return self._client

    def _ensure_client(self):
        """Guards methods to ensure Redis is available before proceeding."""
        client = self._get_client()
        if client is None:
            if self.redis_lib is None:
                raise ImportError("The 'redis' library is required for RedisQueue. Install it with 'pip install redis'.")
            raise ConnectionError("Failed to connect to Redis server.")
        return client

    def push(self, *, payload: Any, priority: int = 0) -> Response:
        """
        Adds a task to the queue with a specific priority.
        
        Using a Redis Pipeline ensures that both the task data and the 
        priority index are updated atomically in one network round-trip.
        """
        try:
            client = self._ensure_client()
            task_id = str(uuid.uuid4())
            
            task_data = {
                "id": task_id,
                "payload": payload,
                "priority": priority,
                "attempts": 0,
                "error": None,
                "created_at": int(time.time()),
                "retry_after": None
            }
            
            pipe = client.pipeline()
            # Store the actual object
            pipe.hset(self.key_data, task_id, json.dumps(task_data))
            # Add to priority index. We use negative priority because ZSet 
            # pops the smallest value first (e.g., -10 comes before -1).
            pipe.zadd(self.key_pending, {task_id: -priority}) 
            pipe.execute()
            
            return ok(data={"task_id": task_id})
        except Exception as e:
            return error(message=str(e))

    def pop(self) -> Response:
        """
        Retrieves the highest priority task and marks it as 'processing'.
        
        This implementation handles 'stale' tasks: if a worker grabbed a task
        but never finished it (due to a crash), this method will automatically
        re-queue it after 1 hour.
        """
        try:
            client = self._ensure_client()
            now = int(time.time())
            
            # 1. Recovery Logic: Re-queue tasks that have been 'processing' for > 1 hour
            stale_threshold = now - 3600
            processing_tasks = client.hgetall(self.key_processing)
            for tid, locked_at in processing_tasks.items():
                if int(locked_at) < stale_threshold:
                    raw_data = client.hget(self.key_data, tid)
                    if raw_data:
                        task = json.loads(raw_data)
                        # Move from 'processing' back to 'pending' pool
                        client.hdel(self.key_processing, tid)
                        client.zadd(self.key_pending, {tid: -task.get("priority", 0)})

            # 2. Retrieval Logic: Get the highest priority ID
            result = client.zpopmin(self.key_pending)
            if not result:
                return error(message="Queue is empty")
            
            task_id, _score = result[0]
            
            # 3. Locking: Record that this task is now being handled
            client.hset(self.key_processing, task_id, now)
            
            # 4. Data Delivery
            raw_data = client.hget(self.key_data, task_id)
            if not raw_data:
                return error(message="Task data missing in Redis")
            
            task = json.loads(raw_data)
            return ok(data=[task]) # Returning as a list to match SQLite behavior
            
        except Exception as e:
            return error(message=str(e))

    def complete(self, task_id: str) -> Response:
        """Removes a task from all Redis structures once finished."""
        try:
            client = self._ensure_client()
            pipe = client.pipeline()
            pipe.hdel(self.key_data, task_id)
            pipe.hdel(self.key_processing, task_id)
            pipe.zrem(self.key_pending, task_id)
            pipe.execute()
            return ok()
        except Exception as e:
            return error(message=str(e))

    def fail(self, *, task_id: str, err: str = None, retry: bool = True, max_retries: int = 5) -> Response:
        """
        Handles task failure. If retry is enabled, it implements exponential backoff
        by calculating a 'retry_after' timestamp.
        """
        try:
            client = self._ensure_client()
            now = int(time.time())
            import random
            
            raw_data = client.hget(self.key_data, task_id)
            if not raw_data:
                return error(message="Task not found")
            
            task = json.loads(raw_data)
            task["error"] = err
            attempts = task.get("attempts", 0)
            
            if retry and attempts < max_retries:
                # Exponential backoff with 20% Jitter
                backoff = (2 ** attempts) * random.uniform(0.8, 1.2)
                task["retry_after"] = now + backoff
                task["attempts"] = attempts + 1
                
                # Update task state and return to pending pool
                client.hset(self.key_data, task_id, json.dumps(task))
                client.hdel(self.key_processing, task_id)
                client.zadd(self.key_pending, {task_id: -task.get("priority", 0)})
            else:
                # Final failure (DLQ): keep data but don't re-queue
                task["status"] = "failed"
                if attempts >= max_retries:
                    task["error"] = f"Max retries ({max_retries}) exceeded: {err}"
                client.hset(self.key_data, task_id, json.dumps(task))
                client.hdel(self.key_processing, task_id)
            
            return ok()
        except Exception as e:
            return error(message=str(e))

    def size(self) -> Response:
        """Returns the number of tasks currently in the 'pending' state."""
        try:
            client = self._ensure_client()
            count = client.zcard(self.key_pending)
            return ok(data=[{"count": count}])
        except Exception as e:
            return error(message=str(e))

    def clear(self) -> Response:
        """Wipes all data associated with this specific queue name."""
        try:
            client = self._ensure_client()
            client.delete(self.key_data, self.key_pending, self.key_processing)
            return ok()
        except Exception as e:
            return error(message=str(e))

    def peek(self, *, limit: int = 1) -> Response:
        """Allows inspection of pending tasks without locking or removing them."""
        try:
            client = self._ensure_client()
            # Get IDs
            task_ids = client.zrange(self.key_pending, 0, limit - 1)
            if not task_ids:
                return ok(data=[])
            
            # Get full data
            raw_tasks = client.hmget(self.key_data, task_ids)
            tasks = [json.loads(t) for t in raw_tasks if t]
            return ok(data=tasks)
        except Exception as e:
            return error(message=str(e))

    def cleanup(self, *, max_age_days: int = 7) -> Response:
        """Placeholder for cleaning up ancient logs (not yet utilized in Redis driver)."""
        return ok()
