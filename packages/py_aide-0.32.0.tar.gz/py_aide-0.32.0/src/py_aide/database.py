import threading
import os
from typing import Any, Optional, Union, List
from .response import ok, error, Response
from .enums import DbEngine
from .db_drivers.sqlite_driver import SqliteDriver
from .db_drivers.postgres_driver import PostgresDriver
from .sqlite import JSONParser  # Re-exported for backward compatibility
from weakref import WeakKeyDictionary

FETCH_LIMIT: int = 90 * 1024

class Api:
    """
    A Thread-Local Multiton Database Manager that supports multiple engines.
    """

    _lock: threading.Lock = threading.Lock()
    _thread_registries = WeakKeyDictionary()

    def __new__(cls, *args, **kwargs) -> "Api":
        db_path = kwargs.get("db_path")
        engine = kwargs.get("engine", DbEngine.SQLITE)
        if isinstance(engine, str):
            engine = DbEngine(engine.lower())

        if engine == DbEngine.SQLITE and db_path is None:
            raise TypeError("db_path is required for SQLite engine")

        # Create a unique key for the instance
        if engine == DbEngine.SQLITE:
            # Normalize path to ensure same file always returns same instance
            normalized_path = os.path.abspath(db_path)
            
            attachments = kwargs.get("attachments", [])
            tables = kwargs.get("tables", {})
            # Hash the attachments and tables so different contexts mean a different connection context
            att_hash = tuple((a.get("path"), a.get("alias")) for a in attachments)
            tbl_hash = tuple(sorted(tables.keys())) if tables else ()
            config_hash = hash((
                kwargs.get("readonly"), 
                kwargs.get("wal_mode"), 
                kwargs.get("transactionMode"), 
                att_hash, 
                tbl_hash
            ))
            db_key = f"sqlite:{normalized_path}:{config_hash}"
        else:
            host = kwargs.get("host", "localhost")
            port = kwargs.get("port", 5432)
            database = kwargs.get("database", "postgres")
            tables = kwargs.get("tables", {})
            tbl_hash = tuple(sorted(tables.keys())) if tables else ()
            config_hash = hash((
                kwargs.get("readonly"), 
                kwargs.get("transactionMode"), 
                tbl_hash
            ))
            db_key = f"postgres:{host}:{port}:{database}:{config_hash}"

        current_thread = threading.current_thread()

        with cls._lock:
            if current_thread not in cls._thread_registries:
                cls._thread_registries[current_thread] = {}
            
            thread_registry = cls._thread_registries[current_thread]
            
            if db_key in thread_registry:
                return thread_registry[db_key]["instance"]
            
            instance = super().__new__(cls)
            thread_registry[db_key] = {
                "instance": instance,
                "reference_count": 0,
            }
            return instance

    def __init__(
        self,
        *,
        engine: DbEngine | str = DbEngine.SQLITE,
        db_path: Optional[str] = None,
        tables: Optional[dict] = None,
        readonly: bool = True,
        wal_mode: bool = True,
        attachments: Optional[list] = None,
        transactionMode: bool = False,
        **kwargs
    ) -> None:
        if getattr(self, "_initialized", False):
            return

        self.engine = engine if isinstance(engine, DbEngine) else DbEngine(str(engine).lower())
        self.transactionMode = transactionMode
        self.readonly = readonly
        self.withCounts = 0
        self._errors = []

        if self.engine == DbEngine.SQLITE:
            self.driver = SqliteDriver(
                db_path=db_path,
                readonly=readonly,
                wal_mode=wal_mode,
                tables=tables,
                attachments=attachments or []
            )
        else:
            if attachments:
                import logging
                logging.getLogger("py_aide").warning("The 'attachments' feature is only supported for SQLite and will be ignored.")

            self.driver = PostgresDriver(
                readonly=readonly,
                tables=tables,
                **kwargs
            )

        self._initialized = True

    def __enter__(self) -> "Api":
        current_thread = threading.current_thread()
        with self._lock:
            for db_key, data in self._thread_registries.get(current_thread, {}).items():
                if data["instance"] is self:
                    data["reference_count"] += 1
                    break

        self.withCounts += 1
        self.driver.connect()

        if self.transactionMode and self.withCounts == 1:
            self.driver.execute(query="BEGIN")
            self._errors = []

        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        is_top_level = (self.withCounts == 1)

        if self.transactionMode and exc_type is not None:
            self.driver.rollback()
            self._errors.append({"type": "CRASH", "error": str(exc_value)})

        self.withCounts -= 1
        current_thread = threading.current_thread()
        
        with self._lock:
            if current_thread in self._thread_registries:
                for db_key, data in self._thread_registries[current_thread].items():
                    if data["instance"] is self:
                        data["reference_count"] -= 1
                        if data["reference_count"] <= 0:
                            self.driver.disconnect()
                        break

    def insert(self, /, *, table: str, data: list) -> Response:
        if self.readonly: return error(message="Read-only mode active")
        res = self.driver.insert(table=table, data=data)
        if res.status and not self.transactionMode and self.withCounts == 1:
            self.driver.commit()
        if not res.status: self._errors.append({"op": "insert", "table": table, "error": res.log})
        return res

    def update(self, /, *, table: str, columns: list, column_data: list, condition: str, condition_data: list) -> Response:
        if self.readonly: return error(message="Read-only mode active")
        res = self.driver.update(table=table, columns=columns, column_data=column_data, condition=condition, condition_data=condition_data)
        if res.status and not self.transactionMode and self.withCounts == 1:
            self.driver.commit()
        if not res.status: self._errors.append({"op": "update", "table": table, "error": res.log})
        return res

    def delete(self, /, *, table: str, condition: str, condition_data: list) -> Response:
        if self.readonly: return error(message="Read-only mode active")
        res = self.driver.delete(table=table, condition=condition, condition_data=condition_data)
        if res.status and not self.transactionMode and self.withCounts == 1:
            self.driver.commit()
        if not res.status: self._errors.append({"op": "delete", "table": table, "error": res.log})
        return res

    def fetch(self, /, *, table: str, columns: list, condition: Optional[str] = None, condition_data: Optional[list] = None, limit: int = FETCH_LIMIT, offset: int = 0) -> Response:
        return self.driver.fetch(table=table, columns=columns, condition=condition, condition_data=condition_data, limit=limit, offset=offset)

    def execute(self, /, *, query: str, data: Optional[list] = None) -> Response:
        is_select = query.strip().lower().startswith("select")
        if not is_select and self.readonly: return error(message="Read-only mode active")
        res = self.driver.execute(query=query, data=data)
        if res.status and not is_select and not self.transactionMode and self.withCounts == 1:
            self.driver.commit()
        if not res.status: self._errors.append({"op": "execute", "query": query, "error": res.log})
        return res

    def create_index(self, /, *, table: str, columns: list, unique: bool = False, index_name: Optional[str] = None) -> Response:
        if self.readonly: return error(message="Read-only mode active")
        res = self.driver.create_index(table=table, columns=columns, unique=unique, index_name=index_name)
        if res.status and not self.transactionMode and self.withCounts == 1:
            self.driver.commit()
        if not res.status: self._errors.append({"op": "create_index", "table": table, "error": res.log})
        return res

    def commit_transaction(self) -> Response:
        if not self.transactionMode: return error(message="transactionMode must be True")
        if self.withCounts > 1: return error(message="Cannot commit in nested context")
        
        if self._errors:
            self.driver.rollback()
            failure_count = len(self._errors)
            return error(
                message=f"Transaction Rollback: {failure_count} operations failed.", 
                errorLogs={"failures": self._errors}
            )
            
        return self.driver.commit()

    @property
    def conn(self):
        """Backward-compatible access to the underlying DB connection."""
        return getattr(self.driver, "conn", None)

    @property
    def cursor(self):
        """Backward-compatible access to the underlying DB cursor."""
        return getattr(self.driver, "cursor", None)

    @property
    def db_path(self):
        """Backward-compatible access to the database file path (SQLite only)."""
        return getattr(self.driver, "db_path", None)

    @classmethod
    def cleanup_thread(cls, thread_id: int | None = None) -> None:
        """Clean up database connections for a specific thread or the current thread."""
        with cls._lock:
            target_thread = None
            if thread_id is None:
                current_thread = threading.current_thread()
                if current_thread in cls._thread_registries:
                    target_thread = current_thread
            else:
                for thread in list(cls._thread_registries.keys()):
                    if getattr(thread, "ident", id(thread)) == thread_id:
                        target_thread = thread
                        break

            if target_thread and target_thread in cls._thread_registries:
                registry = cls._thread_registries[target_thread]
                for db_key, data in registry.items():
                    instance = data["instance"]
                    if hasattr(instance, "driver"):
                        instance.driver.disconnect()
                        instance._initialized = False
                del cls._thread_registries[target_thread]

    @classmethod
    def cleanup_all(cls) -> None:
        """Force close all database connections across all threads."""
        with cls._lock:
            for thread, registry in list(cls._thread_registries.items()):
                for db_key, data in registry.items():
                    instance = data["instance"]
                    if hasattr(instance, "driver"):
                        instance.driver.disconnect()
            cls._thread_registries.clear()

    @classmethod
    def get_open_databases(cls) -> dict:
        """Get a snapshot of open database instances across all threads."""
        with cls._lock:
            result = {}
            for thread, registry in cls._thread_registries.items():
                thread_id = thread.ident if hasattr(thread, "ident") else id(thread)
                result[str(thread_id)] = {
                    db_key: data["reference_count"]
                    for db_key, data in registry.items()
                }
            return result

    @classmethod
    def setup_databases(cls, db_blueprint: dict, **admin_config) -> None:
        """
        Automated multi-database and table schema provisioning.
        1. Ensures all databases in the blueprint exist.
        2. Ensures all tables in each database are synced.
        """
        # Step 1: Ensure Databases Exist (The "Lobby" Phase)
        with cls(**admin_config) as admin:
            for db_name in db_blueprint.keys():
                if not admin.driver.database_exists(db_name):
                    admin.driver.create_database(db_name)

        # Step 2: Ensure Tables Exist (The "Application" Phase)
        for db_name, tables in db_blueprint.items():
            spec_config = admin_config.copy()
            
            # Identify the engine to determine if we use 'db_path' or 'database'
            engine = spec_config.get("engine", DbEngine.SQLITE)
            if isinstance(engine, str):
                engine = DbEngine(engine.lower())

            if engine == DbEngine.SQLITE:
                spec_config["db_path"] = db_name
            else:
                spec_config["database"] = db_name
                
            spec_config["tables"] = tables
            
            # Initializing a temporary Api instance triggers table creation logic
            with cls(**spec_config):
                pass