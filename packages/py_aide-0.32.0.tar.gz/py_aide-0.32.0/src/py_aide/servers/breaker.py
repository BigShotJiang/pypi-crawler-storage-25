"""
CUSTOM CIRCUIT BREAKER IMPLEMENTATION — v2 (Hardened)

Improvements over v1:
1.  Sliding-window failure counter (deque of timestamps, not a bare int).
2.  Dedicated _metrics_lock — counter increments are now thread-safe.
3.  Bounded ThreadPoolExecutor for timed calls (no unbounded thread spawning).
4.  _half_open_test_count always reset on HALF_OPEN entry (no counter leak).
5.  CircuitMonitor stores weakrefs (no strong-reference memory leak).
6.  call_async() for native coroutine support (FastAPI / asyncio).
7.  self.logger assigned before registry block (no fragile init order).
8.  force_open() always resets _state_change_time (timer override works).
9.  Fallback context extraction is robust (name-based, not positional-only).
"""

import asyncio
import inspect
import logging
import threading
import time
import weakref
from collections import deque
from concurrent.futures import ThreadPoolExecutor as _TPE, wait as _fut_wait, FIRST_COMPLETED
from enum import Enum
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


# ============================================================================
# ENUMS
# ============================================================================

class CircuitState(Enum):
    CLOSED    = "closed"
    OPEN      = "open"
    HALF_OPEN = "half_open"


class CircuitEvent(Enum):
    SUCCESS             = "success"
    FAILURE             = "failure"
    TIMEOUT             = "timeout"
    CIRCUIT_OPEN        = "circuit_open"
    CIRCUIT_CLOSED      = "circuit_closed"
    CIRCUIT_HALF_OPEN   = "circuit_half_open"
    FALLBACK_CALLED     = "fallback_called"


# ============================================================================
# EXCEPTIONS
# ============================================================================

class CircuitOpenError(Exception):
    """Raised when a call is attempted while the circuit is OPEN."""
    def __init__(self, message: str, **kwargs):
        super().__init__(message)
        self.circuit_info = kwargs


class CircuitBreakerError(Exception):
    """Base exception for circuit breaker errors."""


# ============================================================================
# CORE CIRCUIT BREAKER
# ============================================================================

class CircuitBreaker:
    """
    Thread-safe circuit breaker with sliding-window failure counting.

    Usage:
        cb = CircuitBreaker(failure_threshold=5, recovery_timeout=60, name="auth")

        @cb
        def call_service(): ...

        # or programmatically:
        result = cb.call(call_service)

        # async:
        result = await cb.call_async(async_call_service)
    """

    # Fix 3: class-level bounded pool — shared across all instances.
    _timeout_executor: _TPE = _TPE(max_workers=32, thread_name_prefix="cb_timeout")

    # Weakref registry
    _registry: Dict[str, weakref.ref] = {}
    _registry_lock = threading.RLock()

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_max_requests: int = 1,
        name: Optional[str] = None,
        expected_exceptions: Optional[Set] = None,
        failure_timeout: Optional[float] = None,
        failure_window: float = 60.0,          # Fix 1: sliding window duration
        logger: Optional[logging.Logger] = None,
    ):
        """
        Args:
            failure_threshold:      Failures within the window before opening.
            recovery_timeout:       Seconds in OPEN before attempting HALF_OPEN.
            half_open_max_requests: Probe requests allowed in HALF_OPEN.
            name:                   Unique name (auto-generated if None).
            expected_exceptions:    Exception types that count as failures.
            failure_timeout:        Per-call timeout in seconds (None = disabled).
            failure_window:         Rolling window (seconds) for failure counting.
            logger:                 Custom logger instance.
        """
        self.failure_threshold     = max(1, failure_threshold)
        self.recovery_timeout      = max(0.0, recovery_timeout)
        self.half_open_max_requests = max(1, half_open_max_requests)
        self.failure_timeout       = failure_timeout
        self.failure_window        = failure_window
        self.expected_exceptions   = expected_exceptions or {Exception}
        self.name                  = name or f"circuit_{id(self)}"

        # Fix 7: assign self.logger BEFORE the registry block so it can be
        # used safely inside the warning call below.
        self.logger = logger or logging.getLogger(f"circuit_breaker.{self.name}")

        # State
        self._state                 = CircuitState.CLOSED
        self._half_open_test_count  = 0
        self._state_change_time     = time.time()
        self._last_exception: Optional[Exception] = None

        # Fix 1: deque of failure timestamps replaces a bare integer counter.
        self._failure_times: deque = deque()

        # Thread safety
        self._lock         = threading.RLock()
        self._metrics_lock = threading.Lock()   # Fix 2: dedicated metrics lock

        # Metrics (all mutations go through _metrics_lock)
        self.metrics: Dict[str, Any] = {
            "total_calls":       0,
            "successful_calls":  0,
            "failed_calls":      0,
            "circuit_open_calls": 0,
            "fallback_calls":    0,
            "state_changes":     0,
            "last_state_change": time.time(),
        }

        # Callbacks & fallback
        self._event_callbacks: Dict[CircuitEvent, List[Callable]] = {}
        self._fallback_func: Optional[Callable] = None

        # Registry — weakref so GC can collect unused breakers.
        with self._registry_lock:
            existing = self._registry.get(self.name)
            if existing is not None and existing() is not None:
                self.logger.warning(          # Fix 7: self.logger is set above
                    "CircuitBreaker '%s' already exists and is live — replacing. "
                    "Call .close() explicitly to suppress this warning.",
                    self.name,
                )
            self._registry[self.name] = weakref.ref(self)

        self.logger.info(
            "Circuit '%s' initialised: threshold=%d, window=%.0fs, timeout=%.1fs",
            self.name, failure_threshold, failure_window, recovery_timeout,
        )

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _current_failure_count(self) -> int:
        """Fix 1: count failures within the sliding window, expiring old ones."""
        cutoff = time.time() - self.failure_window
        while self._failure_times and self._failure_times[0] < cutoff:
            self._failure_times.popleft()
        return len(self._failure_times)

    def _record_failure(self) -> None:
        """Append current timestamp to the failure window."""
        self._failure_times.append(time.time())

    # -----------------------------------------------------------------------
    # Decorator interface
    # -----------------------------------------------------------------------

    def __call__(self, func: Callable) -> Callable:
        """Allow @cb decoration."""
        @wraps(func)
        def wrapper(*args, **kwargs):
            return self.call(func, *args, **kwargs)
        return wrapper

    # -----------------------------------------------------------------------
    # Synchronous call
    # -----------------------------------------------------------------------

    def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute *func* with circuit-breaker protection (synchronous).
        
        Args:
            func: The function to execute.
            failure_predicate: Optional callable that takes the result and 
                              returns True if it should be treated as a failure.
        """
        failure_predicate = kwargs.pop("failure_predicate", None)
        
        with self._metrics_lock:                        # Fix 2
            self.metrics["total_calls"] += 1

        if not self._allow_request():
            with self._metrics_lock:
                self.metrics["circuit_open_calls"] += 1
            self._trigger_event(CircuitEvent.CIRCUIT_OPEN)

            if self._fallback_func:
                with self._metrics_lock:
                    self.metrics["fallback_calls"] += 1
                self._trigger_event(CircuitEvent.FALLBACK_CALLED)
                return self._fallback_func(*args, **kwargs)

            raise CircuitOpenError(
                f"Circuit '{self.name}' is OPEN",
                circuit_name=self.name,
                state=self._state.value,
                last_exception=str(self._last_exception) if self._last_exception else None,
                recovery_in=self._recovery_time_remaining(),
            )

        try:
            result = (
                self._call_with_timeout(func, *args, **kwargs)
                if self.failure_timeout
                else func(*args, **kwargs)
            )
            
            # Check for masked failure via predicate
            if failure_predicate and failure_predicate(result):
                self._on_failure(None)
                with self._metrics_lock:
                    self.metrics["failed_calls"] += 1
                self._trigger_event(CircuitEvent.FAILURE, result=result)
                return result

            self._on_success()
            with self._metrics_lock:
                self.metrics["successful_calls"] += 1
            self._trigger_event(CircuitEvent.SUCCESS)
            return result

        except Exception as e:
            if any(isinstance(e, exc) for exc in self.expected_exceptions):
                self._on_failure(e)
                with self._metrics_lock:
                    self.metrics["failed_calls"] += 1
                self._trigger_event(CircuitEvent.FAILURE, exception=e)
            raise

    # -----------------------------------------------------------------------
    # Async call — Fix 6
    # -----------------------------------------------------------------------

    async def call_async(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute *func* with circuit-breaker protection (async-native).
        
        Args:
            func: The async function to execute.
            failure_predicate: Optional callable that takes the result and 
                              returns True if it should be treated as a failure.
        """
        if not inspect.iscoroutinefunction(func):
            return self.call(func, *args, **kwargs)

        failure_predicate = kwargs.pop("failure_predicate", None)

        with self._metrics_lock:
            self.metrics["total_calls"] += 1

        if not self._allow_request():
            with self._metrics_lock:
                self.metrics["circuit_open_calls"] += 1
            self._trigger_event(CircuitEvent.CIRCUIT_OPEN)

            if self._fallback_func:
                with self._metrics_lock:
                    self.metrics["fallback_calls"] += 1
                self._trigger_event(CircuitEvent.FALLBACK_CALLED)
                result = self._fallback_func(*args, **kwargs)
                return (await result) if asyncio.iscoroutine(result) else result

            raise CircuitOpenError(
                f"Circuit '{self.name}' is OPEN",
                circuit_name=self.name,
                state=self._state.value,
                last_exception=str(self._last_exception) if self._last_exception else None,
                recovery_in=self._recovery_time_remaining(),
            )

        try:
            result = await func(*args, **kwargs)
            
            # Check for masked failure via predicate
            if failure_predicate and failure_predicate(result):
                self._on_failure(None)
                with self._metrics_lock:
                    self.metrics["failed_calls"] += 1
                self._trigger_event(CircuitEvent.FAILURE, result=result)
                return result

            self._on_success()
            with self._metrics_lock:
                self.metrics["successful_calls"] += 1
            self._trigger_event(CircuitEvent.SUCCESS)
            return result

        except Exception as e:
            if any(isinstance(e, exc) for exc in self.expected_exceptions):
                self._on_failure(e)
                with self._metrics_lock:
                    self.metrics["failed_calls"] += 1
                self._trigger_event(CircuitEvent.FAILURE, exception=e)
            raise

    # -----------------------------------------------------------------------
    # Timeout helper — Fix 3
    # -----------------------------------------------------------------------

    def _call_with_timeout(self, func: Callable, *args, **kwargs) -> Any:
        """Execute *func* via the shared bounded pool with a hard timeout."""
        future = self._timeout_executor.submit(func, *args, **kwargs)
        done, _ = _fut_wait([future], timeout=self.failure_timeout, return_when=FIRST_COMPLETED)
        if not done:
            self._trigger_event(CircuitEvent.TIMEOUT)
            raise TimeoutError(f"Call exceeded timeout of {self.failure_timeout}s")
        return future.result()   # re-raises any worker exception cleanly

    # -----------------------------------------------------------------------
    # State machine
    # -----------------------------------------------------------------------

    def _allow_request(self) -> bool:
        with self._lock:
            now = time.time()
            if self._state == CircuitState.CLOSED:
                return True
            if self._state == CircuitState.OPEN:
                if now - self._state_change_time >= self.recovery_timeout:
                    self._transition_to(CircuitState.HALF_OPEN)
                    return True
                return False
            # HALF_OPEN
            if self._half_open_test_count < self.half_open_max_requests:
                self._half_open_test_count += 1
                return True
            return False

    def _on_success(self) -> None:
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._transition_to(CircuitState.CLOSED)
                self._reset_counters()
            elif self._state == CircuitState.CLOSED:
                # Decay: a success sheds one failure from the window.
                if self._failure_times:
                    self._failure_times.popleft()

    def _on_failure(self, exception: Optional[Exception]) -> None:
        with self._lock:
            self._last_exception = exception
            self._record_failure()             # Fix 1: timestamp-based

            if self._state == CircuitState.HALF_OPEN:
                self._transition_to(CircuitState.OPEN)
            elif self._state == CircuitState.CLOSED:
                if self._current_failure_count() >= self.failure_threshold:
                    self._transition_to(CircuitState.OPEN)

    def _transition_to(self, new_state: CircuitState) -> None:
        if self._state == new_state and new_state != CircuitState.OPEN:
            return  # allow OPEN→OPEN to fall through for force_open timer reset

        old_state = self._state
        self._state = new_state
        self._state_change_time = time.time()

        # Fix 4: always reset the probe counter on HALF_OPEN entry.
        if new_state == CircuitState.HALF_OPEN:
            self._half_open_test_count = 0

        if old_state != new_state:
            with self._metrics_lock:
                self.metrics["state_changes"] += 1
                self.metrics["last_state_change"] = self._state_change_time

            self.logger.info(
                "Circuit '%s': %s → %s", self.name, old_state.value, new_state.value
            )

        event_map = {
            CircuitState.CLOSED:    CircuitEvent.CIRCUIT_CLOSED,
            CircuitState.OPEN:      CircuitEvent.CIRCUIT_OPEN,
            CircuitState.HALF_OPEN: CircuitEvent.CIRCUIT_HALF_OPEN,
        }
        self._trigger_event(event_map[new_state])

    def _reset_counters(self) -> None:
        with self._lock:
            self._failure_times.clear()        # Fix 1: clear the deque
            self._half_open_test_count = 0
            self._last_exception = None

    def _recovery_time_remaining(self) -> float:
        if self._state != CircuitState.OPEN:
            return 0.0
        return max(0.0, self.recovery_timeout - (time.time() - self._state_change_time))

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def get_state(self) -> CircuitState:
        with self._lock:
            return self._state

    @property
    def is_open(self) -> bool:
        """Helper for checking if the circuit is currently OPEN."""
        return self.get_state() == CircuitState.OPEN

    @property
    def is_closed(self) -> bool:
        """Helper for checking if the circuit is currently CLOSED."""
        return self.get_state() == CircuitState.CLOSED

    @property
    def is_half_open(self) -> bool:
        """Helper for checking if the circuit is currently HALF_OPEN."""
        return self.get_state() == CircuitState.HALF_OPEN

    def get_metrics(self) -> Dict:
        with self._lock:
            with self._metrics_lock:
                snapshot = self.metrics.copy()
            snapshot.update({
                "state":                   self._state.value,
                "failure_count":           self._current_failure_count(),  # Fix 1
                "half_open_test_count":    self._half_open_test_count,
                "last_failure_time":       self._failure_times[-1] if self._failure_times else 0.0,
                "state_change_time":       self._state_change_time,
                "recovery_time_remaining": self._recovery_time_remaining(),
                "is_closed":               self._state == CircuitState.CLOSED,
                "is_open":                 self._state == CircuitState.OPEN,
                "is_half_open":            self._state == CircuitState.HALF_OPEN,
            })
            return snapshot

    def force_close(self) -> None:
        """Force CLOSED state and clear all counters."""
        with self._lock:
            self._transition_to(CircuitState.CLOSED)
            self._reset_counters()

    def force_open(self) -> None:
        """Force OPEN state. Always resets the recovery timer — Fix 8."""
        with self._lock:
            # Bypass the same-state guard so the timer always resets.
            self._state = CircuitState.OPEN
            self._state_change_time = time.time()
            with self._metrics_lock:
                self.metrics["state_changes"] += 1
                self.metrics["last_state_change"] = self._state_change_time
            self.logger.info("Circuit '%s': force_open() — timer reset", self.name)
            self._trigger_event(CircuitEvent.CIRCUIT_OPEN)

    def reset(self) -> None:
        """Reset to initial CLOSED state with cleared counters."""
        with self._lock:
            self._transition_to(CircuitState.CLOSED)
            self._reset_counters()

    def set_fallback(self, func: Callable) -> None:
        self._fallback_func = func

    def on_event(self, event: CircuitEvent, callback: Callable) -> None:
        with self._lock:
            self._event_callbacks.setdefault(event, []).append(callback)

    def _trigger_event(self, event: CircuitEvent, **kwargs) -> None:
        for cb in self._event_callbacks.get(event, []):
            try:
                cb(self, event, **kwargs)
            except Exception as exc:
                self.logger.error("Event callback error for %s: %s", event, exc)

    def close(self) -> None:
        """Deregister from the class-level registry immediately."""
        with self._registry_lock:
            ref = self._registry.get(self.name)
            if ref is not None and ref() is self:
                del self._registry[self.name]

    # -----------------------------------------------------------------------
    # Class methods
    # -----------------------------------------------------------------------

    @classmethod
    def _prune_registry(cls) -> None:
        dead = [n for n, r in cls._registry.items() if r() is None]
        for n in dead:
            del cls._registry[n]

    @classmethod
    def get_all_circuits(cls) -> Dict[str, Dict]:
        with cls._registry_lock:
            cls._prune_registry()
            return {
                name: ref().get_metrics()
                for name, ref in cls._registry.items()
                if ref() is not None
            }

    @classmethod
    def get_circuit(cls, name: str) -> Optional['CircuitBreaker']:
        with cls._registry_lock:
            ref = cls._registry.get(name)
            if ref is None:
                return None
            obj = ref()
            if obj is None:
                del cls._registry[name]
                return None
            return obj

    @classmethod
    def close_all(cls) -> None:
        with cls._registry_lock:
            for ref in list(cls._registry.values()):
                obj = ref()
                if obj is not None:
                    obj.close()
            cls._registry.clear()


# ============================================================================
# FACTORY HELPERS
# ============================================================================

def circuit_breaker(
    failure_threshold: int = 5,
    recovery_timeout: float = 60.0,
    name: Optional[str] = None,
    **kwargs,
):
    """
    Decorator factory:

        @circuit_breaker(failure_threshold=3, recovery_timeout=30)
        def my_function(): ...
    """
    def decorator(func: Callable) -> Callable:
        cb = CircuitBreaker(
            failure_threshold=failure_threshold,
            recovery_timeout=recovery_timeout,
            name=name or func.__name__,
            **kwargs,
        )
        return cb(func)
    return decorator


def create_circuit_breaker(
    name: str,
    failure_threshold: int = 5,
    recovery_timeout: float = 60.0,
    **kwargs,
) -> CircuitBreaker:
    """Convenience factory for named circuit breakers."""
    return CircuitBreaker(
        name=name,
        failure_threshold=failure_threshold,
        recovery_timeout=recovery_timeout,
        **kwargs,
    )


# ============================================================================
# MONITORING
# ============================================================================

class CircuitMonitor:
    """Monitor for multiple circuit breakers — Fix 5: uses weakrefs."""

    def __init__(self):
        self._circuits: Dict[str, weakref.ref] = {}   # Fix 5

    def add_circuit(self, circuit: CircuitBreaker) -> None:
        self._circuits[circuit.name] = weakref.ref(circuit)   # Fix 5

        def on_state_change(cb, event, **kwargs):
            self._log_state_change(cb, event)

        circuit.on_event(CircuitEvent.CIRCUIT_OPEN,      on_state_change)
        circuit.on_event(CircuitEvent.CIRCUIT_CLOSED,    on_state_change)
        circuit.on_event(CircuitEvent.CIRCUIT_HALF_OPEN, on_state_change)

    def _live_circuits(self) -> Dict[str, CircuitBreaker]:
        """Return live instances, pruning dead weakrefs in-place."""
        live, dead = {}, []
        for name, ref in self._circuits.items():
            obj = ref()
            if obj is not None:
                live[name] = obj
            else:
                dead.append(name)
        for name in dead:
            del self._circuits[name]
        return live

    def _log_state_change(self, circuit: CircuitBreaker, event: CircuitEvent) -> None:
        m = circuit.get_metrics()
        logger.info(
            "[CircuitMonitor] %s: %s | state=%s failures=%d/%d total=%d failed=%d",
            circuit.name, event.value, m["state"],
            m["failure_count"], circuit.failure_threshold,
            m["total_calls"], m["failed_calls"],
        )

    def get_health_report(self) -> Dict:
        live = self._live_circuits()
        report: Dict[str, Any] = {
            "timestamp":          time.time(),
            "total_circuits":     len(live),
            "healthy_circuits":   0,
            "unhealthy_circuits": 0,
            "circuits":           {},
        }
        for name, circuit in live.items():
            m = circuit.get_metrics()
            healthy = m["is_closed"]
            report["healthy_circuits" if healthy else "unhealthy_circuits"] += 1
            report["circuits"][name] = {
                "state":                  m["state"],
                "healthy":                healthy,
                "failure_count":          m["failure_count"],
                "total_calls":            m["total_calls"],
                "failed_calls":           m["failed_calls"],
                "last_state_change":      m["last_state_change"],
                "recovery_time_remaining": m["recovery_time_remaining"],
            }
        return report

    def close_all(self) -> None:
        for circuit in self._live_circuits().values():
            circuit.close()
        self._circuits.clear()


# ============================================================================
# GATE INTEGRATION
# ============================================================================

class CircuitProtectedGate:
    """
    Mixin that wraps any BaseGate with circuit breaker protection.

    Usage:
        class ProtectedAuthenticationGate(CircuitProtectedGate, AuthenticationGate):
            def __init__(self, token_manager):
                super().__init__(
                    token_manager,
                    circuit_config={'failure_threshold': 3, 'recovery_timeout': 60}
                )
    """

    def __init__(self, *args, circuit_config: Optional[Dict] = None, **kwargs):
        # Fix: Avoid re-triggering original gate constructors if we are 
        # being dynamically wrapped (protect_gate).
        if not hasattr(self, "name"):
            super().__init__(*args, **kwargs)

        cfg = {
            "failure_threshold":  5,
            "recovery_timeout":   30.0,
            "expected_exceptions": {ConnectionError, TimeoutError, RuntimeError},
        }
        if circuit_config:
            cfg.update(circuit_config)

        self.circuit = CircuitBreaker(name=f"gate_{self.__class__.__name__}", **cfg)
        self.circuit.set_fallback(self._circuit_fallback)
        self.circuit.on_event(CircuitEvent.CIRCUIT_OPEN,   self._on_circuit_open)
        self.circuit.on_event(CircuitEvent.CIRCUIT_CLOSED, self._on_circuit_closed)

    # Synchronous gate execution
    def execute(self, context, config):
        """Gate execution wrapped in the circuit breaker (sync)."""
        return self.circuit.call(
            super().execute, 
            context, 
            config,
            failure_predicate=lambda res: res.error.get("code") == "gate_internal_error"
        )

    # Async gate execution — Fix 6
    async def execute_async(self, context, config):
        """Gate execution wrapped in the circuit breaker (async)."""
        return await self.circuit.call_async(
            super().execute, 
            context, 
            config,
            failure_predicate=lambda res: res.error.get("code") == "gate_internal_error"
        )

    def _circuit_fallback(self, *args, **kwargs) -> Any:
        """
        Fix 9: robust context extraction — try kwargs first, then positional.
        Returns a well-formed GateResult so the pipeline never crashes.
        """
        from .gate import GateResult  # avoid circular import

        # Try name-based extraction first (most robust), then positional.
        context = kwargs.get("context") or (args[0] if args else None)
        if context is None:
            self.circuit.logger.warning(
                "Circuit fallback for '%s' could not resolve 'context' — "
                "returning anonymous GateResult.",
                self.__class__.__name__,
            )

        return GateResult.error(
            "service_unavailable",
            "Service temporarily unavailable (circuit open)",
            context,
            {
                "circuit_name": self.circuit.name,
                "state":        self.circuit.get_state().value,
                "recovery_in":  self.circuit._recovery_time_remaining(),
            },
        )

    def _on_circuit_open(self, circuit, event, **kwargs):
        logger.warning("Gate '%s' circuit OPEN — failing fast", self.__class__.__name__)

    def _on_circuit_closed(self, circuit, event, **kwargs):
        logger.info("Gate '%s' circuit CLOSED — back to normal", self.__class__.__name__)

    def get_circuit_metrics(self) -> Dict:
        return self.circuit.get_metrics()