import pytest
from py_aide.structures import Validator

def test_validate_simple_types():
    """Test primitive type validation."""
    assert Validator.validate(5, int).status is True
    assert Validator.validate("5", int).status is False
    assert Validator.validate(3.14, float).status is True

def test_validate_unions():
    """Test modern pipe union validation (|)."""
    assert Validator.validate(5, int | float).status is True
    assert Validator.validate(5.5, int | float).status is True
    assert Validator.validate("5", int | float).status is False

def test_validate_list_of_types():
    """Test validation of lists containing specific types."""
    # List of ints
    assert Validator.validate([1, 2, 3], [int]).status is True
    
    # List with wrong type at index 1
    res = Validator.validate([1, "2", 3], [int])
    assert res.status is False
    assert "data[1]" in res.log

def test_validate_dict_schema():
    """Test recursive dictionary schema validation."""
    schema = {
        "name": str,
        "age": int,
        "active": bool
    }
    
    valid_data = {"name": "Alice", "age": 25, "active": True}
    assert Validator.validate(valid_data, schema).status is True
    
    invalid_data = {"name": "Alice", "age": "25", "active": True}
    res = Validator.validate(invalid_data, schema)
    assert res.status is False
    assert "data::age" in res.log

def test_validate_nested_structures():
    """Test validation of deep nested structures (list of dicts)."""
    schema = {
        "users": [{"name": str, "id": int}]
    }
    
    valid_data = {"users": [{"name": "Admin", "id": 1}]}
    assert Validator.validate(valid_data, schema).status is True
    
    invalid_data = {"users": [{"name": "Admin", "id": "1"}]}
    res = Validator.validate(invalid_data, schema)
    assert res.status is False
    assert "id" in res.log

def test_validate_optional_types():
    """Test validation of optional fields (Type | None)."""
    assert Validator.validate(None, str | None).status is True
    assert Validator.validate("hello", str | None).status is True
    assert Validator.validate(123, str | None).status is False
