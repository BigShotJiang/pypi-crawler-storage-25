import unittest
import os
import shutil
import time
from py_aide.threading.buffers import TaskBuffer
from py_aide.response import ok, error

class TestHardening(unittest.TestCase):
    STORAGE = "test_storage_hardening"
    QUEUE_DB = f"{STORAGE}/tasks.db"

    def setUp(self):
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)
        os.makedirs(self.STORAGE)
        self.error_count = 0

    def tearDown(self):
        if hasattr(self, 'buffer'):
            self.buffer.stop()
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)

    def test_max_retries_dlq(self):
        # 1. Setup buffer with max_retries=2
        def failing_handler(data):
            self.error_count += 1
            return error(message="Permanent failure")

        self.buffer = TaskBuffer(
            handlers={"FAIL": failing_handler},
            queue_db=self.QUEUE_DB,
            engine="INTERNAL",
            max_retries=2,
            worker_interval=0.1
        )
        self.buffer.start()

        # 2. Push task
        self.buffer.push(task_type="FAIL", data={})

        # 3. Wait for all retries to exhaust
        # Initial call (0) + Retry 1 (1s) + Retry 2 (2s) = ~3s + jitter
        # We wait longer to be safe
        for _ in range(10):
            time.sleep(1)
            if self.error_count >= 3:
                break
        
        print(f"DEBUG: Final error count: {self.error_count}")

        # 5. Verify status in DB is 'failed'
        from py_aide.database import Api
        with Api(**self.buffer.queue.driver._db_config) as db:
            res = db.execute(query=f"SELECT * FROM {self.buffer.queue.driver.TABLE_NAME}")
            task = res.data[0]
            print(f"DEBUG: Task status: {task['status']}, attempts: {task['attempts']}, error: {task['error']}")
            
        self.assertEqual(self.error_count, 3)
        self.assertEqual(task["status"], "failed")
        self.assertTrue("Max retries (2) exceeded" in task["error"])
        self.assertEqual(task["status"], "failed")
        self.assertTrue("Max retries (2) exceeded" in task["error"])

if __name__ == "__main__":
    unittest.main()
