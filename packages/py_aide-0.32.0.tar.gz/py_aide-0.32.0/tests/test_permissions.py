import unittest
import os
import sqlite3
from py_aide.permissions import Permission, PermissionRegistry, PermissionsManager
from py_aide.database import Api
from py_aide.servers.flask import ServicePortal
from py_aide.servers.gate import GateConfig, RequestContext
from flask import Flask

class TestPermissions(unittest.TestCase):
    def setUp(self):
        self.db_path = "test_perms.db"
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        self.db = Api(db_path=self.db_path, engine="sqlite", readonly=False)
        self.manager = PermissionsManager(self.db)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_display_name(self):
        p1 = Permission(action="delete", group="user")
        self.assertEqual(p1.display_name, "Delete User")
        
        p2 = Permission(action="financial_view", group="reports")
        self.assertEqual(p1.name, "user.delete")
        self.assertEqual(p2.display_name, "Financial view Reports")
        
        p3 = Permission(action="save")
        self.assertEqual(p3.display_name, "Save General")

    def test_catalog_sync_and_grouping(self):
        perms = [
            Permission(action="create", group="user", description="Create a user"),
            Permission(action="delete", group="user", description="Delete a user"),
            Permission(action="invoice", group="billing", description="Generate invoice")
        ]
        self.manager.sync_catalog(registry=perms)
        
        grouped = self.manager.get_all_permissions()
        self.assertIn("user", grouped)
        self.assertIn("billing", grouped)
        self.assertEqual(len(grouped["user"]), 2)
        self.assertEqual(grouped["user"][0]["perm_name"], "Create User")

    def test_hierarchical_climb(self):
        # Setup Hierarchy: Institution (1) -> Branch (2) -> Dept (3)
        self.manager.create_context(name="Institution A", context_id=1)
        self.manager.create_context(name="Branch London", context_id=2, parent_id=1)
        self.manager.create_context(name="IT Dept", context_id=3, parent_id=2)
        
        # Setup Permissions
        p = Permission(action="delete", group="user")
        self.manager.sync_catalog(registry=[p])
        
        # 1. Assign to Branch (2)
        self.manager.assign_permission_to_user(user_id="alice", permission_names=p.name, context_id=2)
        
        # Alice should have access in Dept (3) via inheritance
        self.assertTrue(self.manager.has_permission(user_id="alice", permission_name=p.name, context_id=3))
        # Alice should have access in Branch (2) directly
        self.assertTrue(self.manager.has_permission(user_id="alice", permission_name=p.name, context_id=2))
        # Alice should NOT have access in Institution (1) (Parents don't inherit from children)
        self.assertFalse(self.manager.has_permission(user_id="alice", permission_name=p.name, context_id=1))
        
        # 2. Assign to Global (None)
        self.manager.assign_permission_to_user(user_id="admin", permission_names=p.name, context_id=None)
        self.assertTrue(self.manager.has_permission(user_id="admin", permission_name=p.name, context_id=3))
        self.assertTrue(self.manager.has_permission(user_id="admin", permission_name=p.name, context_id=None))

    def test_role_based_access(self):
        self.manager.create_context(name="Institution A", context_id=1)
        p = Permission(action="edit", group="user")
        self.manager.sync_catalog(registry=[p])
        
        role_res = self.manager.create_role(name="Editor", context_id=1)
        role_id = role_res.data[0] if isinstance(role_res.data, list) else role_res.data
        
        self.manager.assign_permission_to_role(role_id=role_id, permission_names=p.name)
        self.manager.assign_role_to_user(user_id="bob", role_ids=role_id, context_id=1)
        
        self.assertTrue(self.manager.has_permission(user_id="bob", permission_name=p.name, context_id=1))

    def test_portal_integration(self):
        # This tests the auto-harvesting and sync logic in ServicePortal
        PermissionRegistry._permissions = {} # Reset
        
        portal = ServicePortal(
            permissions_manager_factory=lambda cid: self.manager
        )
        
        P_TEST = PermissionRegistry.register(action="access", group="test", description="Testing portal sync")
        
        @portal.endpoint("/test", gate=GateConfig(required_permissions=[P_TEST]))
        def test_endpoint() -> dict:
            """A test endpoint for permission verification."""
            return {"ok": True}
            
        # Manually trigger sync (usually happens in run())
        portal._sync_permissions()
        
        # Check if DB has the permission
        all_perms = self.manager.get_all_permissions()
        self.assertIn("test", all_perms)
        self.assertEqual(all_perms["test"][0]["perm"], "test.access")

if __name__ == "__main__":
    unittest.main()
