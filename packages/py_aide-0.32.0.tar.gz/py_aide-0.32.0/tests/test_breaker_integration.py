import unittest
import time
from py_aide.servers.breaker import CircuitBreaker, CircuitState
from py_aide.threading.buffers import TaskBuffer

class TestBreakerIntegration(unittest.TestCase):
    def test_breaker_properties(self):
        cb = CircuitBreaker(name="test_cb")
        
        # Initial state should be CLOSED
        self.assertTrue(cb.is_closed)
        self.assertFalse(cb.is_open)
        self.assertFalse(cb.is_half_open)
        
        # Force OPEN
        cb.force_open()
        self.assertTrue(cb.is_open)
        self.assertFalse(cb.is_closed)
        
        # Force CLOSED
        cb.force_close()
        self.assertTrue(cb.is_closed)
        self.assertFalse(cb.is_open)

    def test_buffer_circuit_awareness(self):
        cb = CircuitBreaker(name="buffer_cb")
        processed = []
        
        def handler(data):
            processed.append(data)
            return True

        buffer = TaskBuffer(
            handlers={"TASK": handler},
            engine="INTERNAL",
            queue_db="test_storage_cb/tasks.db",
            circuit_breaker=cb,
            worker_interval=0.1
        )
        
        try:
            buffer.start()
            
            # 1. Force circuit OPEN
            cb.force_open()
            self.assertTrue(cb.is_open)
            
            # Synchronization: Ensure worker sees the OPEN state
            time.sleep(0.2)
            
            # 2. Push task
            buffer.push(task_type="TASK", data={"id": 1})
            
            # 3. Wait - should NOT be processed
            time.sleep(0.5)
            self.assertEqual(len(processed), 0)
            
            # 4. Force circuit CLOSED
            cb.force_close()
            self.assertTrue(cb.is_closed)
            
            # 5. Wait - should BE processed now
            time.sleep(0.5)
            self.assertEqual(len(processed), 1)
            
        finally:
            buffer.stop()
            import shutil
            import os
            if os.path.exists("test_storage_cb"):
                shutil.rmtree("test_storage_cb")

if __name__ == "__main__":
    unittest.main()
