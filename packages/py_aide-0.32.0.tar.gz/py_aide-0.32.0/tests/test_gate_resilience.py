import unittest
import time
from py_aide.servers.breaker import CircuitProtectedGate, CircuitState
from py_aide.servers.gate import BaseGate, GateResult, GateConfig, RequestContext

# Mock Request object
class MockRequest:
    def __init__(self):
        self.headers = {}
        self.remote_addr = "127.0.0.1"

# 1. A gate that simulates an internal system crash
class CrashingGate(BaseGate):
    def __init__(self):
        super().__init__("crashing_gate")
    
    def _execute(self, context, config):
        # In reality, BaseGate.execute catches the crash and returns this:
        return GateResult.error("gate_internal_error", "System exploded", context)

# 2. A gate that simulates a normal business logic failure
class LogicGate(BaseGate):
    def __init__(self):
        super().__init__("logic_gate")
    
    def _execute(self, context, config):
        return GateResult.error("invalid_params", "Missing email", context)

# 3. Protected versions using the mixin
class ProtectedCrashingGate(CircuitProtectedGate, CrashingGate):
    def __init__(self):
        super().__init__(circuit_config={"failure_threshold": 2, "recovery_timeout": 60})

class ProtectedLogicGate(CircuitProtectedGate, LogicGate):
    def __init__(self):
        super().__init__(circuit_config={"failure_threshold": 2, "recovery_timeout": 60})

class TestGateResilience(unittest.TestCase):
    def setUp(self):
        self.context = RequestContext(MockRequest())
        self.config = GateConfig()

    def test_trips_on_internal_error(self):
        gate = ProtectedCrashingGate()
        
        # 1st failure (internal_error)
        res = gate.execute(self.context, self.config)
        self.assertEqual(res.error["code"], "gate_internal_error")
        self.assertEqual(gate.circuit.get_state(), CircuitState.CLOSED)
        
        # 2nd failure (internal_error) -> Should TRIP
        res = gate.execute(self.context, self.config)
        self.assertEqual(gate.circuit.get_state(), CircuitState.OPEN)
        
        # 3rd call -> Should FAIL FAST via Fallback
        res = gate.execute(self.context, self.config)
        self.assertEqual(res.error["code"], "service_unavailable")
        self.assertTrue("circuit open" in res.error["message"])

    def test_stays_closed_on_logic_error(self):
        gate = ProtectedLogicGate()
        
        # Multiple logic failures
        for _ in range(5):
            res = gate.execute(self.context, self.config)
            self.assertEqual(res.error["code"], "invalid_params")
            
        # Circuit should still be CLOSED (logic errors are not system failures)
        self.assertEqual(gate.circuit.get_state(), CircuitState.CLOSED)

if __name__ == "__main__":
    unittest.main()
