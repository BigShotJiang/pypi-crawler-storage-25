import pytest
import sys
from unittest.mock import MagicMock, patch

# Mock psycopg2 before importing Api
mock_psycopg2 = MagicMock()
sys.modules["psycopg2"] = mock_psycopg2
sys.modules["psycopg2.extras"] = MagicMock()

from py_aide.database import Api
from py_aide.enums import DbEngine
from py_aide.response import ok

def test_setup_databases_sqlite(tmp_path):
    """Verify setup_databases handles SQLite gracefully as a no-op for creation."""
    db_file = str(tmp_path / "sqlite_infra.db")
    
    # SQLite uses the path as the 'database' name essentially
    blueprint = {
        db_file: {
            "users": "id INTEGER PRIMARY KEY, name TEXT"
        }
    }
    
    # For SQLite, setup_databases should just work without errors
    Api.setup_databases(blueprint, db_path=db_file)
    
    # Verify table was created
    with Api(db_path=db_file) as db:
        res = db.execute(query="SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        assert len(res.data) == 1

@patch("psycopg2.connect")
def test_setup_databases_postgres_logic(mock_connect):
    """Verify the multi-phase logic of setup_databases for Postgres."""
    # Mocking the complex nested structure of psycopg2
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_connect.return_value = mock_conn
    mock_conn.cursor.return_value = mock_cursor
    
    # Setup: db1 exists, db2 does not
    # First call to database_exists(db1) -> returns True
    # Second call to database_exists(db2) -> returns False
    mock_cursor.fetchone.side_effect = [True, None, True] # True for db1, None for db2, then True for table sync
    
    blueprint = {
        "existing_db": {"t1": "col1 TEXT"},
        "new_db": {"t2": "col2 TEXT"}
    }
    
    admin_config = {
        "engine": DbEngine.POSTGRES,
        "host": "localhost",
        "user": "postgres",
        "password": "password",
        "database": "postgres" # The Lobby
    }
    
    # Execution
    Api.setup_databases(blueprint, **admin_config)
    
    # Verification
    # 1. Verify existence checks were performed
    # (Note: Api instantiation also does some checks, so we check the calls)
    exists_calls = [
        call for call in mock_cursor.execute.call_args_list 
        if "SELECT 1 FROM pg_database" in call[0][0]
    ]
    assert len(exists_calls) >= 2
    
    # 2. Verify CREATE DATABASE was called for new_db
    create_db_calls = [
        call for call in mock_cursor.execute.call_args_list 
        if "CREATE DATABASE \"new_db\"" in call[0][0]
    ]
    assert len(create_db_calls) == 1
    
    # 3. Verify CREATE DATABASE was NOT called for existing_db
    create_existing_calls = [
        call for call in mock_cursor.execute.call_args_list 
        if "CREATE DATABASE \"existing_db\"" in call[0][0]
    ]
    assert len(create_existing_calls) == 0
