import pytest
from py_aide.customTypes import Definition, Options
from py_aide.enforcer import enforce_requirements

@enforce_requirements
def user_info(user: Definition[{
    "name": str,
    "age": int
}], /) -> str:
    """Return user info string."""
    return f"User {user['name']} is {user['age']} years old."

def test_user_info_success():
    """Test standard dictionary definition validation."""
    data = {"name": "Alice", "age": 30}
    assert user_info(data) == "User Alice is 30 years old."

def test_user_info_failure_wrong_type():
    """Test definition validation fails on wrong internal value type."""
    # age should be int, given as str
    data = {"name": "Alice", "age": "30"}
    with pytest.raises(TypeError) as excinfo:
        user_info(data)
    assert "data::age" in str(excinfo.value)

def test_user_info_failure_missing_field():
    """Test definition validation fails on missing required field."""
    data = {"name": "Alice"}
    with pytest.raises(TypeError):
        user_info(data)

@enforce_requirements
def set_priority(level: Options[str, ["high", "medium", "low"]], /) -> str:
    """Set the system priority level."""
    return f"Priority set to {level}"

def test_options_success():
    """Test successful value selection from Options."""
    assert set_priority("high") == "Priority set to high"
    assert set_priority("medium") == "Priority set to medium"
    assert set_priority("low") == "Priority set to low"

def test_options_failure():
    """Test that selecting an invalid option raises TypeError."""
    with pytest.raises(TypeError) as excinfo:
        set_priority("critical")
    assert "not in expected options" in str(excinfo.value).lower()
