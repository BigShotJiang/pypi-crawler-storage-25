import unittest
import os
import time
import shutil
from py_aide.threading import PersistentQueue
from py_aide.enums import QueueEngine

class TestPersistentQueue(unittest.TestCase):
    DB_PATH = "test_storage/test_queues.db"

    def setUp(self):
        # Ensure clean state
        if os.path.exists("test_storage"):
            shutil.rmtree("test_storage")
        os.makedirs("test_storage")
        self.queue = PersistentQueue(engine=QueueEngine.INTERNAL, queue_name="test_queue", db_path=self.DB_PATH)

    def tearDown(self):
        if os.path.exists("test_storage"):
            shutil.rmtree("test_storage")

    def test_push_pop(self):
        # 1. Push
        payload = {"action": "send_email", "to": "user@example.com"}
        res = self.queue.push(payload=payload)
        self.assertTrue(res.status)
        task_id = res.data["task_id"]

        # 2. Check size
        size_res = self.queue.size()
        self.assertEqual(size_res.data[0]["count"], 1)

        # 3. Pop
        pop_res = self.queue.pop()
        self.assertTrue(pop_res.status)
        self.assertEqual(pop_res.data[0]["id"], task_id)
        self.assertEqual(pop_res.data[0]["payload"], payload)

        # 4. Size should be 0 (since it's in 'processing' status)
        size_res = self.queue.size()
        self.assertEqual(size_res.data[0]["count"], 0)

        # 5. Complete
        comp_res = self.queue.complete(task_id)
        self.assertTrue(comp_res.status)

    def test_priority(self):
        self.queue.push(payload={"msg": "low"}, priority=0)
        self.queue.push(payload={"msg": "high"}, priority=10)
        self.queue.push(payload={"msg": "med"}, priority=5)

        # High should come first
        res1 = self.queue.pop()
        self.assertEqual(res1.data[0]["payload"]["msg"], "high")

        # Then Med
        res2 = self.queue.pop()
        self.assertEqual(res2.data[0]["payload"]["msg"], "med")

    def test_peek(self):
        self.queue.push(payload={"msg": "first"})
        peek_res = self.queue.peek()
        self.assertTrue(peek_res.status)
        self.assertEqual(peek_res.data[0]["payload"]["msg"], "first")
        
        # Size should still be 1
        size_res = self.queue.size()
        self.assertEqual(size_res.data[0]["count"], 1)

    def test_failure_retry(self):
        self.queue.push(payload={"msg": "fail_me"})
        pop_res = self.queue.pop()
        task_id = pop_res.data[0]["id"]
        
        # Fail with retry
        self.queue.fail(task_id=task_id, err="Something went wrong", retry=True)
        
        # Size should be 1 again
        size_res = self.queue.size()
        self.assertEqual(size_res.data[0]["count"], 1)
        
        # Check attempts
        peek_res = self.queue.peek()
        self.assertEqual(peek_res.data[0]["attempts"], 1)

    def test_persistence(self):
        self.queue.push(payload={"msg": "survive"})
        
        # Destroy queue object and create new one pointing to same DB
        del self.queue
        new_queue = PersistentQueue(engine=QueueEngine.INTERNAL, queue_name="test_queue", db_path=self.DB_PATH)
        
        size_res = new_queue.size()
        self.assertEqual(size_res.data[0]["count"], 1)
        
        pop_res = new_queue.pop()
        self.assertEqual(pop_res.data[0]["payload"]["msg"], "survive")

if __name__ == "__main__":
    unittest.main()
