import time
import pytest
from py_aide.threading.executor import ThreadPoolExecutor

def sample_task(n):
    """Simple math task for thread test."""
    time.sleep(0.1)
    return n * 2

def failing_task():
    """Task that raises a deliberate exception."""
    raise ValueError("System Failure")

def test_executor_submit_success():
    """Test successful task submission and result retrieval."""
    with ThreadPoolExecutor(min_workers=1, max_workers=2) as pool:
        future = pool.submit(func=sample_task, args=[5])
        result = future.result(timeout=2)
        assert result == 10

def test_executor_multiple_submissions():
    """Test standard parallel execution of multiple tasks."""
    with ThreadPoolExecutor(min_workers=2, max_workers=4) as pool:
        futures = [pool.submit(func=sample_task, args=[i]) for i in range(5)]
        results = [f.result(timeout=2) for f in futures]
        assert results == [0, 2, 4, 6, 8]

def test_executor_task_failure():
    """Test that task exceptions are correctly captured in futures."""
    with ThreadPoolExecutor(min_workers=1) as pool:
        future = pool.submit(func=failing_task)
        with pytest.raises(ValueError) as excinfo:
            future.result(timeout=2)
        assert "System Failure" in str(excinfo.value)

def test_executor_retry_logic():
    """Test task retry mechanism for transient failures."""
    # Counter must be mutable across workers
    import threading
    attempts = threading.local()
    attempts.count = 0 
    
    def retry_task():
        # This is a bit tricky with threads. We use a shared list.
        nonlocal call_count
        call_count += 1
        if call_count < 2:
            raise ConnectionError("Try again")
        return "OK"

    call_count = 0
    with ThreadPoolExecutor(min_workers=1, max_retries=3) as pool:
        future = pool.submit(func=retry_task)
        assert future.result(timeout=5) == "OK"
        assert call_count == 2

def test_executor_callback():
    """Test standard done callback execution."""
    callback_fired = False
    def my_callback(fut):
        nonlocal callback_fired
        callback_fired = True
        
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(func=sample_task, args=[1])
        future.add_done_callback(my_callback)
        future.result(timeout=1)
        # Give it a tiny bit of time to fire if it hasn't
        time.sleep(0.1)
        assert callback_fired is True
