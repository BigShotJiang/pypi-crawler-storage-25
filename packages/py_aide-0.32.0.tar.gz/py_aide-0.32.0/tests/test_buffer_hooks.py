import unittest
import os
import time
import shutil
from py_aide.threading import DatabaseBuffer, TaskBuffer
from py_aide.database import Api
from py_aide.response import ok, error
from py_aide.enums import QueueEngine

class TestBufferHooks(unittest.TestCase):
    STORAGE = "test_storage_hooks"
    MAIN_DB = f"{STORAGE}/main.db"
    QUEUE_DB = f"{STORAGE}/queue.db"

    def setUp(self):
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)
        os.makedirs(self.STORAGE)
        
        # Setup main DB
        with Api(db_path=self.MAIN_DB, tables={"logs": "id INTEGER PRIMARY KEY, msg TEXT"}, readonly=False) as db:
            pass

        self.error_caught = []

        def error_hook(task_type, payload, err, tb):
            self.error_caught.append({
                "type": task_type,
                "payload": payload,
                "error": err,
                "traceback": tb
            })

        self.db_buffer = DatabaseBuffer(
            main_db=self.MAIN_DB, 
            engine=QueueEngine.INTERNAL,
            queue_db=self.QUEUE_DB, 
            on_error=error_hook
        )
        self.db_buffer.start()

        def crashing_handler(data):
            raise ValueError("Boom!")

        self.task_buffer = TaskBuffer(
            handlers={"CRASH": crashing_handler},
            engine=QueueEngine.INTERNAL,
            queue_db=self.QUEUE_DB,
            on_error=error_hook
        )
        self.task_buffer.start()

    def tearDown(self):
        self.db_buffer.stop()
        self.task_buffer.stop()
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)

    def test_database_error_hook(self):
        # Force a database error by inserting duplicate ID or invalid table
        self.db_buffer.insert(table="non_existent", data=[[1, "test"]])
        
        time.sleep(2)
        
        self.assertTrue(len(self.error_caught) > 0)
        err = self.error_caught[0]
        self.assertEqual(err["type"], "insert")
        self.assertIn("no such table: non_existent", err["error"])
        self.assertIsNone(err["traceback"]) # logic error usually doesn't have a traceback in our code, it's a caught Response error

    def test_task_crash_hook(self):
        self.task_buffer.push(task_type="CRASH", data={"foo": "bar"})
        
        time.sleep(2)
        
        self.assertTrue(len(self.error_caught) > 0)
        err = self.error_caught[0]
        self.assertEqual(err["type"], "CRASH")
        self.assertEqual(err["error"], "Boom!")
        self.assertIsNotNone(err["traceback"])
        self.assertIn("ValueError: Boom!", err["traceback"])
        self.assertIn("crashing_handler", err["traceback"])

if __name__ == "__main__":
    unittest.main()
