import unittest
import httpx
import respx
import asyncio
from py_aide.requests import send_request, send_request_async
from py_aide.servers.breaker import CircuitBreaker
from py_aide.response import Response

class TestUniversalRequests(unittest.IsolatedAsyncioTestCase):
    @respx.mock
    def test_form_data_handling(self):
        """Verify that 'data' kwarg triggers form-encoding."""
        route = respx.post("https://api.test.com/form").mock(return_value=httpx.Response(200, json={"status": "ok"}))
        
        res = send_request(
            method="POST",
            endpoint="https://api.test.com/form",
            data={"key": "value"}
        )
        
        self.assertTrue(res.status)
        # Check that httpx received form data
        self.assertEqual(route.calls.last.request.content, b"key=value")
        self.assertEqual(route.calls.last.request.headers["content-type"], "application/x-www-form-urlencoded")

    @respx.mock
    def test_native_auth_handling(self):
        """Verify that 'auth' kwarg works correctly."""
        route = respx.get("https://api.test.com/auth").mock(return_value=httpx.Response(200, json={"auth": "ok"}))
        
        res = send_request(
            method="GET",
            endpoint="https://api.test.com/auth",
            auth=("user", "pass")
        )
        
        self.assertTrue(res.status)
        # httpx encodes Basic Auth in the Authorization header
        self.assertIn("Authorization", route.calls.last.request.headers)
        self.assertTrue(route.calls.last.request.headers["Authorization"].startswith("Basic "))

    @respx.mock
    def test_circuit_breaker_integration(self):
        """Verify that 'circuit_breaker' wraps the request."""
        from py_aide.requests import RequestConfig
        RequestConfig.max_retries = 0  # Speed up tests
        
        breaker = CircuitBreaker(name="test_breaker", failure_threshold=2)
        
        # Mock a failure
        route = respx.get("https://api.test.com/fail").mock(return_value=httpx.Response(500))
        
        # Default predicate: trip on any Response with status=False
        predicate = lambda res: isinstance(res, Response) and not res.status

        # First call
        res1 = send_request(
            method="GET",
            endpoint="https://api.test.com/fail",
            circuit_breaker=breaker,
            failure_predicate=predicate
        )
        self.assertFalse(res1.status)
        
        # Second call to trip the breaker
        res2 = send_request(
            method="GET",
            endpoint="https://api.test.com/fail",
            circuit_breaker=breaker,
            failure_predicate=predicate
        )
        
        self.assertTrue(breaker.is_open)
        # Third call should fail immediately via breaker
        res3 = send_request(
            method="GET",
            endpoint="https://api.test.com/fail",
            circuit_breaker=breaker
        )
        self.assertIn("is OPEN", res3.log)

    @respx.mock
    async def test_async_universal_engine(self):
        """Verify the async version handles everything correctly."""
        route = respx.post("https://api.test.com/async").mock(return_value=httpx.Response(200, json={"async": "ok"}))
        
        res = await send_request_async(
            method="POST",
            endpoint="https://api.test.com/async",
            data={"async_key": "val"},
            use_interceptors=False
        )
        
        self.assertTrue(res.status)
        self.assertEqual(route.calls.last.request.content, b"async_key=val")

if __name__ == "__main__":
    unittest.main()
