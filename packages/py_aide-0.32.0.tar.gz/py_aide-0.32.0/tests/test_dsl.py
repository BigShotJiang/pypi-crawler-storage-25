import pytest
from py_aide.database import JSONParser

def test_parse_read_column_simple_path():
    """Test standard column string parsing."""
    # Should handle simple column name
    assert "profile" in JSONParser.parse_read_column(column_string="profile")

def test_parse_read_column_complex_json_path():
    """Test complex JSON path strings in SELECT clauses."""
    # profile::stats::score as score
    # Expected: profile ->> '$.stats.score' AS score
    parsed = JSONParser.parse_read_column(column_string="profile::stats::score as score")
    assert "->>" in parsed
    assert "stats" in parsed
    assert "AS score" in parsed

def test_parse_condition_simple():
    """Test simple equality conditions in WHERE clauses."""
    parsed = JSONParser.parse_condition("id = ?")
    assert parsed == "id = ?"

def test_parse_condition_json_path():
    """Test JSON path strings within WHERE conditions."""
    # profile::status = ?
    # Expected: json_extract(profile, '$.status') = ?
    parsed = JSONParser.parse_condition("profile::status = ?")
    assert "->>" in parsed
    assert "status" in parsed

def test_parse_write_columns_updates():
    """Test parsing for UPDATE SET clauses."""
    columns = ["settings::theme", "count[+=]"]
    values = ["dark", 5]
    
    formatted_cols, new_values = JSONParser.parse_write_columns(columns=columns, values=values)
    
    assert len(formatted_cols) == 2
    # settings::theme -> json_set(settings, '$.theme', ?)
    assert "json_set" in formatted_cols[0]
    # count[+=] -> json_set(count, '$', json_extract(count, '$') + ?)
    assert "+" in formatted_cols[1]
    assert new_values == ["dark", 5]

def test_parse_write_columns_list_append():
    """Test parsing for list appends within JSON objects."""
    columns = ["tags[+]"]
    values = ["new_tag"]
    
    formatted_cols, new_values = JSONParser.parse_write_columns(columns=columns, values=values)
    
    # tags[+] -> json_insert(tags, '$[#]', ?)
    assert "json_insert" in formatted_cols[0]
    assert "$[#]" in formatted_cols[0]
    assert new_values == ["new_tag"]
