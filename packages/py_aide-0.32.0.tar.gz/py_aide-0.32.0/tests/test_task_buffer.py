import unittest
import os
import time
import shutil
from py_aide.threading import TaskBuffer
from py_aide.response import ok, error
from py_aide.enums import QueueEngine

class TestTaskBuffer(unittest.TestCase):
    QUEUE_DB = "test_storage/task_queue.db"

    def setUp(self):
        # Ensure clean state
        if os.path.exists("test_storage"):
            shutil.rmtree("test_storage")
        os.makedirs("test_storage")
        
        self.processed_tasks = []

        def email_handler(payload):
            self.processed_tasks.append(f"email:{payload['to']}")
            return ok()

        def error_handler(payload):
            if payload.get("should_fail"):
                # Simulate a failure
                return error(message="Failed intentionally")
            self.processed_tasks.append("success")
            return ok()

        self.buffer = TaskBuffer(
            handlers={
                "SEND_EMAIL": email_handler,
                "ERROR_TEST": error_handler
            },
            engine=QueueEngine.INTERNAL,
            queue_db=self.QUEUE_DB,
            worker_interval=1.0
        )
        self.buffer.start()

    def tearDown(self):
        self.buffer.stop()
        if os.path.exists("test_storage"):
            shutil.rmtree("test_storage")

    def test_task_execution(self):
        # 1. Push task
        self.buffer.push(task_type="SEND_EMAIL", data={"to": "alice@test.com"})
        
        # 2. Wait for worker
        time.sleep(1.5)
        
        # 3. Verify execution
        self.assertIn("email:alice@test.com", self.processed_tasks)

    def test_task_retry(self):
        # 1. Push failing task
        self.buffer.push(task_type="ERROR_TEST", data={"should_fail": True})
        
        # 2. Wait for worker to try and fail
        # Short sleep to catch it during the 1s backoff (status='pending')
        time.sleep(0.5)
        self.assertEqual(len(self.processed_tasks), 0)
        
        # 3. Check queue size (should still be 1 because it retries)
        size_res = self.buffer.queue.size()
        self.assertEqual(size_res.data[0]["count"], 1)

    def test_priority(self):
        self.buffer.stop() # Stop worker so we can enqueue in order
        
        self.buffer.push(task_type="SEND_EMAIL", data={"to": "low"}, priority=0)
        self.buffer.push(task_type="SEND_EMAIL", data={"to": "high"}, priority=10)
        
        self.buffer.start()
        time.sleep(2)
        
        # High should be processed first
        self.assertEqual(self.processed_tasks[0], "email:high")
        self.assertEqual(self.processed_tasks[1], "email:low")

if __name__ == "__main__":
    unittest.main()
