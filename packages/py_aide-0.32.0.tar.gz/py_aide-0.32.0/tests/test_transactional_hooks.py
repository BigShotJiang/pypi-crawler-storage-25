import unittest
import os
import time
import shutil
from py_aide.threading import TaskBuffer
from py_aide.response import ok, error
from py_aide.enums import QueueEngine

class TestTransactionalHooks(unittest.TestCase):
    STORAGE = "test_storage_transactional"
    QUEUE_DB = f"{STORAGE}/tasks.db"

    def setUp(self):
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)
        os.makedirs(self.STORAGE)
        
        self.hook_calls = 0

        def failing_hook(task_type, data, result):
            self.hook_calls += 1
            if self.hook_calls < 2:
                raise ValueError("Temporary hook failure")

        self.buffer = TaskBuffer(
            handlers={"JOB": lambda d: ok(data="done")},
            engine=QueueEngine.INTERNAL,
            queue_db=self.QUEUE_DB,
            on_success=failing_hook,
            sync_interval=1.0,
            min_age_seconds=3
        )
        self.buffer.start()

    def tearDown(self):
        self.buffer.stop()
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)

    def test_hook_retry_on_failure(self):
        # 1. Push task
        self.buffer.push(task_type="JOB", data={"foo": "bar"})
        
        # 2. Wait for main task to finish and first hook attempt to fail
        # We wait 1.5s to ensure completion, but SyncWorker might retry in this window
        time.sleep(1.5)
        
        # Main task should be gone from active queue
        size_res = self.buffer.queue.size()
        self.assertEqual(size_res.data[0]["count"], 0)
        
        # Hook should have been called exactly once (immediate failure)
        self.assertEqual(self.hook_calls, 1)
        
        # Verify it is in results table as pending
        res = self.buffer.results.get_pending()
        self.assertEqual(len(res.data), 1)
        self.assertEqual(res.data[0]["hook_status"], "pending")

        # 3. Wait for sync worker to retry
        # (Sync loop sleeps 5s if empty, 1s between batches. 
        # Since it was empty initially, it might take ~5-6s)
        time.sleep(6)
        
        # Hook should have been called again
        self.assertTrue(self.hook_calls >= 2)
        
        # Verify it is now marked as complete
        res = self.buffer.results.get_pending()
        self.assertEqual(len(res.data), 0)

if __name__ == "__main__":
    unittest.main()
