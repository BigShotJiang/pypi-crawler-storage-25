import unittest
import threading
import asyncio
from py_aide.threading import bridge_async
from py_aide.response import ok, error

class TestAsyncBridge(unittest.TestCase):
    def test_basic_bridge(self):
        """Verify that a simple async function can be run through the bridge."""
        async def sample_async(val: int):
            await asyncio.sleep(0.01)
            return val * 2
            
        sync_func = bridge_async(sample_async)
        result = sync_func(10)
        self.assertEqual(result, 20)

    def test_bridge_in_thread(self):
        """
        Verify that the bridge works correctly when called from a background thread
        that has no pre-existing event loop.
        """
        async def async_task(data: str):
            await asyncio.sleep(0.05)
            return f"processed {data}"
            
        sync_bridge = bridge_async(async_task)
        
        results = []
        def thread_worker():
            # In a fresh OS thread, there is usually no event loop
            try:
                res = sync_bridge("input")
                results.append(res)
            except Exception as e:
                results.append(e)
                
        t = threading.Thread(target=thread_worker)
        t.start()
        t.join()
        
        self.assertEqual(results[0], "processed input")

    def test_bridge_exception_propagation(self):
        """Verify that exceptions in the async function propagate through the bridge."""
        async def failing_async():
            await asyncio.sleep(0.01)
            raise ValueError("Async failure")
            
        sync_bridge = bridge_async(failing_async)
        
        with self.assertRaises(ValueError) as cm:
            sync_bridge()
            
        self.assertEqual(str(cm.exception), "Async failure")

    def test_bridge_with_complex_objects(self):
        """Verify the bridge works with Response objects (common py_aide pattern)."""
        async def get_response():
            await asyncio.sleep(0.01)
            return ok(data={"status": "ready"})
            
        sync_bridge = bridge_async(get_response)
        res = sync_bridge()
        
        self.assertTrue(res.status)
        self.assertEqual(res.data["status"], "ready")

if __name__ == "__main__":
    unittest.main()
