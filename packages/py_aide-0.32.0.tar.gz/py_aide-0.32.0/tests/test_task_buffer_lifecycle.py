import unittest
import os
import time
import shutil
from py_aide.threading import TaskBuffer
from py_aide.response import ok, error
from py_aide.enums import QueueEngine

class TestTaskBufferLifecycle(unittest.TestCase):
    STORAGE = "test_storage_lifecycle"
    QUEUE_DB = f"{STORAGE}/tasks.db"

    def setUp(self):
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)
        os.makedirs(self.STORAGE)
        
        self.events = []

        def on_start(task_type, data):
            self.events.append(f"start:{task_type}")

        def on_success(task_type, data, result):
            self.events.append(f"success:{task_type}")

        def on_error(task_type, data, err, tb):
            self.events.append(f"error:{task_type}")

        def on_complete(task_type, data):
            self.events.append(f"complete:{task_type}")

        def success_handler(data):
            return ok(data="done")

        def fail_handler(data):
            return error(message="failed")

        self.buffer = TaskBuffer(
            handlers={
                "SUCCESS": success_handler,
                "FAIL": fail_handler
            },
            engine=QueueEngine.INTERNAL,
            queue_db=self.QUEUE_DB,
            on_start=on_start,
            on_success=on_success,
            on_error=on_error,
            on_complete=on_complete
        )
        self.buffer.start()

    def tearDown(self):
        self.buffer.stop()
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)

    def test_success_lifecycle(self):
        self.buffer.push(task_type="SUCCESS", data={})
        time.sleep(1.5)
        
        # Expected sequence: start -> success -> complete
        self.assertEqual(self.events, ["start:SUCCESS", "success:SUCCESS", "complete:SUCCESS"])

    def test_failure_lifecycle(self):
        self.buffer.push(task_type="FAIL", data={})
        time.sleep(1.5)
        
        # Expected sequence: start -> error -> complete
        # Note: on_success should NOT be called
        self.assertIn("start:FAIL", self.events)
        self.assertIn("error:FAIL", self.events)
        self.assertIn("complete:FAIL", self.events)
        self.assertNotIn("success:FAIL", self.events)

    def test_hook_resilience(self):
        """Verify that a failing hook doesn't crash the worker."""
        def broken_hook(task_type, data):
            raise ValueError("Hook crash!")

        # Create a new buffer with a broken on_start hook
        self.buffer.stop()
        self.buffer = TaskBuffer(
            handlers={"SUCCESS": lambda d: ok()},
            engine=QueueEngine.INTERNAL,
            queue_db=self.QUEUE_DB,
            on_start=broken_hook
        )
        self.buffer.start()
        
        self.buffer.push(task_type="SUCCESS", data={})
        time.sleep(1.5)
        
        # If we get here without a crash and the task is processed, it works
        size_res = self.buffer.queue.size()
        self.assertEqual(size_res.data[0]["count"], 0)

if __name__ == "__main__":
    unittest.main()
