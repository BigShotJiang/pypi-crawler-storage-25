import os
import pytest
import base64
from unittest.mock import MagicMock
from py_aide.images import ImageHandler
from py_aide.storage import Path

# Small 1x1 base64 transparent PNG
IMAGE_DATA_B64 = (
    "iVBORw0KGgoKCgoNSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
)

@pytest.fixture
def test_image_dir(tmp_path):
    """Fixture to provide a temporary directory for image tests."""
    img_dir = tmp_path / "images"
    img_dir.mkdir()
    return str(img_dir)

def test_save_base64_images_success(test_image_dir):
    """Test successful image saving from base64."""
    images = [
        {"img": IMAGE_DATA_B64, "name": "test_pixel_b64"}
    ]
    
    saved_paths = ImageHandler.save_base64_images(images, test_image_dir)
    
    assert len(saved_paths) == 1
    assert os.path.exists(saved_paths[0])
    assert saved_paths[0].lower().endswith(".png")
    assert "test_pixel_b64" in saved_paths[0]

def test_save_images_deprecated_alias(test_image_dir):
    """Test that the old save_images still works as an alias."""
    images = [
        {"img": IMAGE_DATA_B64, "name": "test_pixel_alias"}
    ]
    
    saved_paths = ImageHandler.save_images(images, test_image_dir)
    
    assert len(saved_paths) == 1
    assert os.path.exists(saved_paths[0])
    assert "test_pixel_alias" in saved_paths[0]

def test_save_binary_images_bytes(test_image_dir):
    """Test successful image saving from raw bytes."""
    png_data = base64.b64decode(IMAGE_DATA_B64)
    images = [
        {"data": png_data, "name": "test_pixel_binary"}
    ]
    
    saved_paths = ImageHandler.save_binary_images(images, test_image_dir)
    
    assert len(saved_paths) == 1
    assert os.path.exists(saved_paths[0])
    assert saved_paths[0].lower().endswith(".png")
    assert "test_pixel_binary" in saved_paths[0]

def test_save_binary_images_uploadfile(test_image_dir):
    """Test successful image saving from a mocked FastAPI UploadFile."""
    png_data = base64.b64decode(IMAGE_DATA_B64)
    
    # Mocking FastAPI UploadFile structure
    mock_upload = MagicMock()
    mock_upload.file.read.return_value = png_data
    
    images = [
        {"data": mock_upload, "name": "test_pixel_uploadfile"}
    ]
    
    saved_paths = ImageHandler.save_binary_images(images, test_image_dir)
    
    assert len(saved_paths) == 1
    assert os.path.exists(saved_paths[0])
    assert "test_pixel_uploadfile" in saved_paths[0]
    mock_upload.file.read.assert_called_once()

def test_save_binary_images_file_like(test_image_dir):
    """Test successful image saving from a file-like object (with .read())."""
    png_data = base64.b64decode(IMAGE_DATA_B64)
    
    from io import BytesIO
    file_like = BytesIO(png_data)
    
    images = [
        {"data": file_like, "name": "test_pixel_file_like"}
    ]
    
    saved_paths = ImageHandler.save_binary_images(images, test_image_dir)
    
    assert len(saved_paths) == 1
    assert os.path.exists(saved_paths[0])
    assert "test_pixel_file_like" in saved_paths[0]

def test_save_images_collision(test_image_dir):
    """Test image saving handles filename collisions."""
    images = [
        {"img": IMAGE_DATA_B64, "name": "duplicate"}
    ]
    
    # Save first time
    path1 = ImageHandler.save_base64_images(images, test_image_dir)[0]
    # Save second time with same name
    path2 = ImageHandler.save_base64_images(images, test_image_dir)[0]
    
    assert path1 != path2
    assert "copy" in path2
    assert os.path.exists(path1)
    assert os.path.exists(path2)

def test_is_base64_image_valid():
    """Test base64 image validation."""
    assert ImageHandler.is_base64_image(IMAGE_DATA_B64) is True

def test_is_base64_image_invalid():
    """Test validation with non-image base64 content."""
    invalid_b64 = base64.b64encode(b"not an image").decode()
    assert ImageHandler.is_base64_image(invalid_b64) is False

def test_detect_ext_png():
    """Test extension detection for PNG."""
    png_data = base64.b64decode(IMAGE_DATA_B64)
    assert ImageHandler.detect_ext(png_data) == "png"

def test_detect_ext_jpg():
    """Test extension detection for JPG (via magic numbers)."""
    jpg_data = b"\xff\xd8\xff\xe0" # Start of JPG header
    assert ImageHandler.detect_ext(jpg_data) == "jpg"
