from logging import getLogger

import django
from asgiref.typing import ASGIReceiveCallable
from asgiref.typing import ASGIReceiveEvent
from asgiref.typing import ASGISendCallable
from asgiref.typing import LifespanShutdownCompleteEvent
from asgiref.typing import LifespanShutdownFailedEvent
from asgiref.typing import LifespanStartupCompleteEvent
from asgiref.typing import LifespanStartupFailedEvent
from django.core.handlers.asgi import ASGIHandler

from ..utils import lazy_import_classproperty

logger = getLogger(__name__)


class WorkerLifespanASGIHandler(ASGIHandler):
    async def __call__(self, scope, receive: ASGIReceiveCallable, send) -> None:
        if scope["type"] == "lifespan":
            await self.handle_lifespan(receive, send)
        else:
            await super().__call__(scope, receive, send)

    engine_registry = lazy_import_classproperty("csu.worker.registry.REGISTRY")

    async def handle_start_engines(self):
        registry = self.engine_registry
        logger.info("Found %s registered engines.", len(registry))
        for module_name, engine in registry.items():
            logger.info("Starting engine for %s: %s...", module_name, engine)
            if engine.shutdown_on:
                raise RuntimeError(f"Engine {type(engine)} shutdown_on should be empty, not {engine.shutdown_on}!")
            await engine.start()
        logger.info(
            "Started %s engines: \n   %s",
            len(registry),
            "\n   ".join(f"{module_name}: {engine}" for module_name, engine in registry.items()),
        )

    async def handle_stop_engines(self):
        registry = self.engine_registry
        logger.info("Stopping %s registered engines.", len(registry))
        for engine in registry.values():
            await engine.stop(graceful=True)

    async def handle_lifespan(self, receive: ASGIReceiveCallable, send: ASGISendCallable) -> None:
        while True:
            message: ASGIReceiveEvent = await receive()
            match message["type"]:
                case "lifespan.startup":
                    try:
                        await self.handle_start_engines()
                    except Exception as exc:
                        await send(LifespanStartupFailedEvent(type="lifespan.startup.failed", message=str(exc)))
                        raise
                    else:
                        await send(LifespanStartupCompleteEvent(type="lifespan.startup.complete"))
                case "lifespan.shutdown":
                    try:
                        await self.handle_stop_engines()
                    except Exception as exc:
                        await send(LifespanShutdownFailedEvent(type="lifespan.shutdown.failed", message=str(exc)))
                        raise
                    else:
                        await send(LifespanShutdownCompleteEvent(type="lifespan.shutdown.complete"))
                        return
                case _:
                    raise ValueError(f"Unexpected message type: {message['type']!r}", message)


def get_worker_lifespan_application() -> WorkerLifespanASGIHandler:
    django.setup(set_prefix=False)
    return WorkerLifespanASGIHandler()
