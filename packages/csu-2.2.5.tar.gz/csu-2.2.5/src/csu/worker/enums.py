from enum import Enum
from enum import auto


class WorkerState(Enum):
    UNKNOWN = auto()

    WAITING = auto()
    READY = auto()
    WORKING = auto()
    SAVING = auto()
    BEFORE = auto()
    AFTER = auto()
    COOLDOWN = auto()
    SLEEPING = auto()
    CANCELED = auto()
    FAILED = auto()
    EXITED = auto()
    SHUTDOWN = auto()
