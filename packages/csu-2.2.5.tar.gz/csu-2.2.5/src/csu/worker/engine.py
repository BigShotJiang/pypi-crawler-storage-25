import asyncio
import signal
import sys
import traceback
from abc import ABC
from abc import abstractmethod
from asyncio import CancelledError
from asyncio import Future
from asyncio import Queue
from asyncio import Semaphore
from collections import defaultdict
from collections.abc import AsyncIterator
from collections.abc import Iterable
from contextlib import asynccontextmanager
from datetime import datetime
from datetime import time
from datetime import timedelta
from enum import Flag
from enum import auto
from functools import partial
from logging import getLogger
from random import randint
from typing import ClassVar
from typing import Protocol

from datetimerange import DateTimeRange

from ..exceptions import InternalServiceError
from ..timezones import naivenow
from .enums import WorkerState
from .job import Job

logger = getLogger(__name__)


class TaskProtocol(Protocol):
    job_kwargs: dict

    async def done_watchdog(self, job: Job):
        pass


class ResultTypeProtocol(Protocol):
    PENDING: object
    SUCCESS: object
    ABSENT: object
    ERROR: object


class AbstractWorker(ABC):
    state: WorkerState = WorkerState.UNKNOWN
    runner: asyncio.Task | None = None
    shutdown_requested = False
    id_counter: ClassVar = 0
    id = "?"

    def __str__(self):
        return f"{type(self).__name__}({self.id}/{self.state.name})"

    def report(self, inspect: defaultdict[str, int]):
        inspect[self.state.name] += 1

    def start(self):
        cls = type(self)
        cls.id_counter += 1
        self.id = cls.id_counter
        self.runner = asyncio.create_task(self.run())
        # noinspection PyTypeChecker
        self.runner.add_done_callback(self.on_exit)
        logger.info("%s started.", self)

    def on_exit(self, future: Future):
        try:
            result = future.result()
        except CancelledError as exc:
            logger.info("%s.on_exit(%s) %r", self, future, exc)
            self.state = WorkerState.CANCELED
        except Exception as exc:
            logger.exception("%s.on_exit(%s) unexpected failure: %r", self, future, exc)
            self.state = WorkerState.FAILED
        else:
            logger.info("%s.on_exit(%s) exit with result: %r", self, future, result)
            self.state = WorkerState.EXITED

    @abstractmethod
    async def run(self):
        pass

    async def before(self):  # noqa: B027
        """
        Called before a unit of work is performed.
        """

    async def after(self, *, idle):  # noqa: B027
        """
        Called before after a unit of work is performed.
        :param idle: True if run would have a spin-loop condition.
        """


class SleepingTimeRangeMixin:
    state: WorkerState
    sleeping_timerange: tuple[time, time]

    async def before(self):
        # noinspection PyUnresolvedReferences
        await super().before()

        now = naivenow()
        today = now.date()
        start, end = self.sleeping_timerange
        sleep_range = DateTimeRange(
            datetime.combine(today, start),
            datetime.combine(today if start <= end else today + timedelta(days=1), end),
        )
        if now in sleep_range:
            self.state = WorkerState.SLEEPING
            delta = (sleep_range.end_datetime - now).total_seconds()
            logger.info("%s.before() sleeping until %s (%s seconds)", self, sleep_range.end_datetime, delta)
            await asyncio.sleep(delta)


class SleepingCooldown(Flag):
    IDLE = auto()
    BUSY = auto()


class SleepingCooldownMixin:
    """
    Mixin that can be used on both Producers and Consumers.
    Ideally cooldown_on=IDLE for Producers, and cooldown_on=BUSY for Consumers.
    """

    state: WorkerState
    cooldown_min_seconds: int
    cooldown_max_seconds: int
    cooldown_on: SleepingCooldown

    async def after(self, *, idle):
        # noinspection PyUnresolvedReferences
        await super().after(idle=idle)
        if self.cooldown_on & (SleepingCooldown.IDLE if idle else SleepingCooldown.BUSY):
            self.state = WorkerState.COOLDOWN
            if self.cooldown_min_seconds == self.cooldown_max_seconds:
                sleep_seconds = self.cooldown_min_seconds
            else:
                sleep_seconds = randint(self.cooldown_min_seconds, self.cooldown_max_seconds)  # noqa: S311
                logger.info("%s.after() having a cooldown of %s seconds.", self, sleep_seconds)
            await asyncio.sleep(sleep_seconds)


class AbstractProducer(AbstractWorker):
    state = WorkerState.UNKNOWN
    engine: AbstractEngine

    @property
    @abstractmethod
    def job_class(self) -> type[Job]:
        pass

    @abstractmethod
    async def fetch_task(self) -> TaskProtocol | None:
        """
        Should raise error if there would be a spin-loop condition.
        """

    def __init__(self, engine: AbstractEngine):
        self.engine = engine

    async def run(self):
        task: TaskProtocol | None
        logger.info("%s.run() started.", self)
        while True:
            self.state = WorkerState.BEFORE
            await self.before()
            if self.shutdown_requested:
                break
            self.state = WorkerState.WAITING
            await self.engine.before_produce()
            if self.shutdown_requested:
                break
            try:
                self.state = WorkerState.WORKING
                task = await self.fetch_task()
            except InternalServiceError as exc:
                logger.error("%s.run() failed %r", self, exc)
                task = None
            except Exception as exc:
                logger.exception("%s.run() failed %r", self, exc)
                task = None
            if task:
                # noinspection PyArgumentList
                job = self.job_class(**task.job_kwargs)
                await self.engine.push(job)
                logger.info("%s.run() awaiting %s.done of %s.", self, job, task)
                await task.done_watchdog(job)
            if self.shutdown_requested:
                break
            self.engine.after_produce(idle=not task)
            self.state = WorkerState.AFTER
            await self.after(idle=not task)


class AbstractConsumer(AbstractWorker):
    engine: AbstractEngine

    @property
    @abstractmethod
    def result_type_enum(self) -> type[ResultTypeProtocol]:
        pass

    @abstractmethod
    async def save_result(self, job: Job, /, **kwargs):
        pass

    def __init__(self, engine: AbstractEngine):
        self.engine = engine

    async def run(self):
        while True:
            if self.shutdown_requested:
                self.state = WorkerState.SHUTDOWN
            else:
                self.state = WorkerState.BEFORE
                await self.before()
                self.state = WorkerState.READY
            job: Job | None
            async with self.engine.consume() as job:
                if job is None:
                    break
                job.started.set_result(True)
                logger.info("%s.run() working on: %s", self, job)
                self.state = WorkerState.WORKING
                logger.info("%s.run() - performing...", self)
                try:
                    fields = await self.perform_work(job)
                except Exception as exc:
                    self.state = WorkerState.SAVING
                    logger.error("%s.perform_work(%s) failed: %r", self, job, exc)
                    result = await self.save_result(
                        job,
                        result_type=self.result_type_enum.ERROR,
                        result_details=f"{exc!r}\n{traceback.format_exc()}",
                    )
                    idle = True
                else:
                    self.state = WorkerState.SAVING
                    result = await self.save_result(
                        job,
                        result_type=self.result_type_enum.SUCCESS if fields else self.result_type_enum.ABSENT,
                        result_details=None if fields else repr(fields),
                        **fields or {},
                    )
                    idle = False
                if job.done.cancelled():
                    logger.warning("%s.run() - %s is cancelled.", self, job)
                else:
                    job.done.set_result(result)

            if self.shutdown_requested:
                continue
            else:
                self.state = WorkerState.AFTER
                await self.after(idle=idle)

    @abstractmethod
    async def perform_work(self, job: Job) -> dict:
        pass


class AbstractEngine(ABC):
    workers: list[AbstractWorker]
    queue: Queue = None
    queue_sem: Semaphore
    shutdown_on: Iterable[signal.Signals] = (signal.SIGINT, signal.SIGTERM)
    shutdown_requested = False
    shutdown_tasks: ClassVar[dict[bool, asyncio.Task]] = {}
    if sys.platform == "win32":
        shutdown_on += (signal.SIGBREAK,)

    def __init__(self):
        self.workers = []
        self.queue = Queue()
        self.queue_sem = Semaphore(value=0)

    def __str__(self):
        return f"{type(self).__name__}({len(self.workers)}w/{self.queue.qsize() if self.queue else '-'}q)"

    def is_work_pending(self):
        if any(worker for worker in self.workers if worker.state == WorkerState.WORKING):
            return True
        if self.queue.qsize() > 0:
            return True
        return not self.shutdown_requested

    async def push(self, job: Job | None) -> None:
        logger.info("%s.push(%s)", self, job)
        await self.queue.put(job)

    @asynccontextmanager
    async def consume(self) -> AsyncIterator[Job | None]:
        self.queue_sem.release()
        yield await self.queue.get()
        # if raised then there's no task to mark as done (this won't be reached on exception)
        self.queue.task_done()

    async def before_produce(self):
        # event set after consuming, cleared right before there's a task
        await self.queue_sem.acquire()

    def after_produce(self, *, idle):
        if idle:
            self.queue_sem.release()

    def add_worker(self, worker: AbstractWorker):
        self.workers.append(worker)

    async def start(self):
        for worker in self.workers:
            assert worker.runner is None, f"{worker=} should not be started"
            worker.start()

        loop = asyncio.get_event_loop()
        for sig in self.shutdown_on:
            loop.add_signal_handler(sig, self.shutdown_handler, sig)

    def shutdown_handler(self, sig: signal.Signals) -> None:
        sig_name = sig.name
        graceful = not self.shutdown_requested
        logger.info("%s.shutdown_handler(%s) %s", self, sig_name, "GRACEFUL" if graceful else "FORCED")
        if not graceful:
            self.shutdown_tasks[True].cancel()
        if graceful in self.shutdown_tasks:
            logger.warn("%s.shutdown_handler(%s) already requested", self, sig_name)
        else:
            self.shutdown_tasks[graceful] = asyncio.create_task(self.stop(graceful=graceful))
        self.shutdown_requested = True

    async def stop(self, graceful=False):
        logger.info("%s.stop(graceful=%s)", self, graceful)
        logger.info("%s stats: %s", self, self.inspect())
        for i, worker in enumerate(self.workers, 1):
            logger.info("%s worker %s: %r", self, i, worker)
        if graceful:
            for worker in self.workers:
                worker.shutdown_requested = True

            producers = [worker.runner for worker in self.workers if isinstance(worker, AbstractProducer)]
            logger.info("%s requesting workers to stop and awaiting %s producers...", self, len(producers))
            await asyncio.gather(
                *producers,
                return_exceptions=True,
            )
            logger.info("%s flushing queue (%s items) and awaiting consumers...", self, self.queue.qsize())
            for worker in self.workers:
                if isinstance(worker, AbstractConsumer):
                    self.queue.put_nowait(None)
        else:
            while self.queue.qsize() > 0:
                item = self.queue.get_nowait()
                if item is not None:
                    logger.critical("%s unprocessed queue item: %r", self, item)
            for worker in self.workers:
                worker.runner.cancel()
        await asyncio.gather(*[worker.runner for worker in self.workers], return_exceptions=True)
        logger.info("%s shutdown complete.", self)

    def report(self, inspect: defaultdict[str, object]):
        inspect.update(
            QSIZE="UNSTARTED" if self.queue is None else self.queue.qsize(),
            SEMVAL=self.queue_sem._value,
        )

    def inspect(self) -> dict[str, dict[str, int]]:
        result = defaultdict(partial(defaultdict, int))
        for worker in self.workers:
            worker.report(result[type(worker).__name__])
        self.report(result[type(self).__name__])
        return {name: {counter: value for counter, value in sorted(counters.items())} for name, counters in result.items()}  # noqa: C416
