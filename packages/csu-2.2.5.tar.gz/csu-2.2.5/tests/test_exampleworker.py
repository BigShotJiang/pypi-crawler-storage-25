import signal
import sys
import time

from process_tests import TestProcess
from process_tests import dump_on_error
from process_tests import wait_for_strings


def test_noskip():
    with TestProcess(sys.executable, "-mexampleworker", "3", "0", "1000", "4") as target, dump_on_error(target.read):
        wait_for_strings(
            target.read,
            5,
            "INFO:csu.worker.engine:ExampleConsumer(1/UNKNOWN) started.",
            "INFO:csu.worker.engine:ExampleConsumer(2/UNKNOWN) started.",
            "INFO:csu.worker.engine:ExampleConsumer(3/UNKNOWN) started.",
            "INFO:csu.worker.engine:ExampleProducer(1/UNKNOWN) started.",
            "INFO:csu.worker.engine:ExampleProducer(1/UNKNOWN).run() started.",
            "PRODUCER fetch_task @ 1 RETURN",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=1))",
            "INFO:csu.worker.engine:ExampleProducer(1/WORKING).run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=1).done of NoOpTask(id=1).",
            "PRODUCER fetch_task @ 2 RETURN",
            "INFO:csu.worker.engine:ExampleEngine(4w/1q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=2))",
            "INFO:csu.worker.engine:ExampleProducer(1/WORKING).run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=2).done of NoOpTask(id=2).",
            "PRODUCER fetch_task @ 3 RETURN",
            "INFO:csu.worker.engine:ExampleEngine(4w/2q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=3))",
            "INFO:csu.worker.engine:ExampleProducer(1/WORKING).run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=3).done of NoOpTask(id=3).",
            "INFO:csu.worker.engine:ExampleConsumer(1/READY).run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=1)",
            "INFO:csu.worker.engine:ExampleConsumer(1/WORKING).run() - performing...",
            "CONSUMER 0 perform_work JOB 1 START",
            "INFO:csu.worker.engine:ExampleConsumer(2/READY).run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=2)",
            "INFO:csu.worker.engine:ExampleConsumer(2/WORKING).run() - performing...",
            "CONSUMER 1 perform_work JOB 2 START",
            "INFO:csu.worker.engine:ExampleConsumer(3/READY).run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=3)",
            "INFO:csu.worker.engine:ExampleConsumer(3/WORKING).run() - performing...",
            "CONSUMER 2 perform_work JOB 3 START",
            "CONSUMER 0 perform_work JOB 1 DONE",
            "CONSUMER 0 save_result JOB 1",
            "CONSUMER 1 perform_work JOB 2 DONE",
            "CONSUMER 1 save_result JOB 2",
            "CONSUMER 2 perform_work JOB 3 DONE",
            "CONSUMER 2 save_result JOB 3",
            "PRODUCER fetch_task @ 4 RETURN",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=4))",
            "INFO:csu.worker.engine:ExampleProducer(1/WORKING).run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=4).done of NoOpTask(id=4).",
            "PRODUCER fetch_task @ 5 EXHAUSTED",
            "INFO:csu.worker.engine:ExampleConsumer(1/READY).run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=4)",
            "INFO:csu.worker.engine:ExampleConsumer(1/WORKING).run() - performing...",
            "CONSUMER 0 perform_work JOB 4 START",
            "PRODUCER fetch_task @ 6 EXHAUSTED",
            "CONSUMER 0 perform_work JOB 4 DONE",
            "CONSUMER 0 save_result JOB 4",
            "PRODUCER fetch_task @ 7 EXHAUSTED",
        )


def test_skip():
    with TestProcess(sys.executable, "-mexampleworker", "3", "2", "100", "4") as target, dump_on_error(target.read):
        wait_for_strings(
            target.read,
            5,
            "INFO:csu.worker.engine:ExampleConsumer(1/UNKNOWN) started.",
            "INFO:csu.worker.engine:ExampleConsumer(2/UNKNOWN) started.",
            "INFO:csu.worker.engine:ExampleConsumer(3/UNKNOWN) started.",
            "INFO:csu.worker.engine:ExampleProducer(1/UNKNOWN) started.",
            "INFO:csu.worker.engine:ExampleProducer(1/UNKNOWN).run() started.",
            "PRODUCER fetch_task @ 1 RETURN",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=1))",
            "INFO:csu.worker.engine:ExampleProducer(1/WORKING).run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=1).done of NoOpTask(id=1).",
            "PRODUCER fetch_task @ 2 SKIP",
            "INFO:csu.worker.engine:ExampleConsumer(1/READY).run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=1)",
            "INFO:csu.worker.engine:ExampleConsumer(1/WORKING).run() - performing...",
            "CONSUMER 0 perform_work JOB 1 START",
            "CONSUMER 0 perform_work JOB 1 DONE",
            "CONSUMER 0 save_result JOB 1",
            "PRODUCER fetch_task @ 3 RETURN",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=3))",
            "INFO:csu.worker.engine:ExampleProducer(1/WORKING).run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=3).done of NoOpTask(id=3).",
            "PRODUCER fetch_task @ 4 SKIP",
            "INFO:csu.worker.engine:ExampleConsumer(2/READY).run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=3)",
            "INFO:csu.worker.engine:ExampleConsumer(2/WORKING).run() - performing...",
            "CONSUMER 1 perform_work JOB 3 START",
            "CONSUMER 1 perform_work JOB 3 DONE",
            "CONSUMER 1 save_result JOB 3",
            "PRODUCER fetch_task @ 5 EXHAUSTED",
        )


def test_graceful_shutdown():
    with TestProcess(sys.executable, "-mexampleworker", "3", "0", "1000", "100") as target, dump_on_error(target.read):
        wait_for_strings(
            target.read,
            15,
            "PRODUCER fetch_task @ 1 RETURN",
        )
        target.proc.send_signal(signal.SIGINT)
        wait_for_strings(
            target.read,
            15,
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).shutdown_handler(SIGINT) GRACEFUL",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).stop(graceful=True)",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) stats: {'ExampleConsumer': {'WORKING': 3}, 'ExampleProducer': {'WAITING': 1}, 'ExampleEngine': {'JOBS': 3, 'QSIZE': 0, 'SEMVAL': 0}}",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) worker 1: <__main__.ExampleConsumer object at ",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) worker 2: <__main__.ExampleConsumer object at ",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) worker 3: <__main__.ExampleConsumer object at ",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) worker 4: <__main__.ExampleProducer object at ",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) requesting workers to stop and awaiting 1 producers...",
            "CONSUMER 0 perform_work JOB 1 DONE",
            "CONSUMER 0 save_result JOB 1",
            "INFO:csu.worker.engine:ExampleProducer(1/WAITING).on_exit(",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) flushing queue (0 items) and awaiting consumers...",
            "INFO:csu.worker.engine:ExampleConsumer(1/SHUTDOWN).on_exit(",
            "INFO:csu.worker.engine:ExampleConsumer(2/SHUTDOWN).on_exit(",
            "INFO:csu.worker.engine:ExampleConsumer(3/SHUTDOWN).on_exit(",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) shutdown complete.",
            "DONE: {'ExampleConsumer': {'EXITED': 3}, 'ExampleProducer': {'EXITED': 1}, 'ExampleEngine': {'JOBS': 3, 'QSIZE': 0, 'SEMVAL': 2}}",
        )


def test_forced_shutdown():
    with TestProcess(sys.executable, "-mexampleworker", "3", "0", "2000", "100") as target, dump_on_error(target.read):
        wait_for_strings(
            target.read,
            15,
            "PRODUCER fetch_task @ 1 RETURN",
        )
        target.proc.send_signal(signal.SIGINT)
        time.sleep(1)
        target.proc.send_signal(signal.SIGTERM)
        wait_for_strings(
            target.read,
            15,
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).shutdown_handler(SIGINT) GRACEFUL",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).stop(graceful=True)",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q) requesting workers to stop and awaiting 1 producers...",
            "INFO:csu.worker.engine:ExampleEngine(4w/0q).shutdown_handler(SIGTERM) FORCED",
            "CONSUMER 0 perform_work JOB 1 DONE",
            "CONSUMER 1 perform_work JOB 2 DONE",
            "CONSUMER 2 perform_work JOB 3 DONE",
            "DONE: {'ExampleConsumer': {'CANCELED': 3}, 'ExampleProducer': {'CANCELED': 1}, 'ExampleEngine': {'JOBS': 3, 'QSIZE': 0, 'SEMVAL': 0}}",
        )


def test_sem_rollback():
    with TestProcess(sys.executable, "-mexampleworker", "1", "2", "10", "10") as target, dump_on_error(target.read):
        wait_for_strings(
            target.read,
            15,
            "PRODUCER fetch_task @ 1 RETURN",
            "CONSUMER 0 perform_work JOB 1 START",
            "CONSUMER 0 perform_work JOB 1 DONE",
            "CONSUMER 0 save_result JOB 1",
            "PRODUCER fetch_task @ 2 SKIP",
            "PRODUCER fetch_task @ 3 RETURN",
            "CONSUMER 0 perform_work JOB 3 START",
            "CONSUMER 0 perform_work JOB 3 DONE",
            "CONSUMER 0 save_result JOB 3",
            "PRODUCER fetch_task @ 4 SKIP",
            "PRODUCER fetch_task @ 5 RETURN",
            "CONSUMER 0 perform_work JOB 5 START",
            "CONSUMER 0 perform_work JOB 5 DONE",
            "CONSUMER 0 save_result JOB 5",
        )
