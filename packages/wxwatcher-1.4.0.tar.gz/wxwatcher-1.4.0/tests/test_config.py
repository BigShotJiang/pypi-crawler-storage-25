"""Unit tests for wxwatcher config module."""
import os
import argparse
from unittest import mock

from wxwatcher.config import load_config, AppConfig


def _make_args(**overrides):
    defaults = dict(dir=None, push_url="http://example.com/push", to_user=None, interval=None,
                    max_batch=None, log_file=None, ext=None, ignore=None)
    defaults.update(overrides)
    return argparse.Namespace(**defaults)


class TestLoadConfig:
    def test_defaults(self):
        cfg = load_config(_make_args())
        assert isinstance(cfg, AppConfig)
        assert cfg.poll_interval == 30
        assert cfg.max_batch == 50
        assert cfg.to_user == "@all"

    def test_cli_args_override(self):
        cfg = load_config(_make_args(dir="/tmp", interval=10, max_batch=20))
        assert cfg.watch_dir == "/tmp"
        assert cfg.poll_interval == 10
        assert cfg.max_batch == 20

    def test_env_vars_override(self):
        with mock.patch.dict(os.environ, {"WXWATCHER_INTERVAL": "5", "WXWATCHER_MAX_BATCH": "99"}):
            cfg = load_config(_make_args())
            assert cfg.poll_interval == 5
            assert cfg.max_batch == 99

    def test_cli_overrides_env(self):
        with mock.patch.dict(os.environ, {"WXWATCHER_INTERVAL": "5"}):
            cfg = load_config(_make_args(interval=15))
            assert cfg.poll_interval == 15

    def test_ignore_env(self):
        with mock.patch.dict(os.environ, {"WXWATCHER_IGNORE": "dist,build"}):
            cfg = load_config(_make_args())
            assert "dist" in cfg.ignore_patterns
            assert "build" in cfg.ignore_patterns

    def test_ext_env(self):
        with mock.patch.dict(os.environ, {"WXWATCHER_EXT": "py,md"}):
            cfg = load_config(_make_args())
            assert ".py" in cfg.monitor_exts
            assert ".md" in cfg.monitor_exts

    def test_ext_cli_arg(self):
        cfg = load_config(_make_args(ext="go,rs"))
        assert ".go" in cfg.monitor_exts
        assert ".rs" in cfg.monitor_exts

    def test_watch_dir_defaults_to_cwd(self):
        cfg = load_config(_make_args())
        assert cfg.watch_dir == os.path.abspath(os.getcwd())

    def test_ignore_cli_arg(self):
        cfg = load_config(_make_args(ignore="dist,build"))
        assert "dist" in cfg.ignore_patterns
        assert "build" in cfg.ignore_patterns

    def test_ignore_cli_merges_with_env(self):
        with mock.patch.dict(os.environ, {"WXWATCHER_IGNORE": "vendor"}):
            cfg = load_config(_make_args(ignore="dist"))
            assert "vendor" in cfg.ignore_patterns
            assert "dist" in cfg.ignore_patterns

    def test_config_file_poll_interval(self):
        """Config file value used when CLI/env not set."""
        cfg = load_config(_make_args(), config_file_data={"poll_interval": 60})
        assert cfg.poll_interval == 60

    def test_cli_overrides_config_file(self):
        """CLI arg takes precedence over config file."""
        cfg = load_config(
            _make_args(interval=10),
            config_file_data={"poll_interval": 60}
        )
        assert cfg.poll_interval == 10

    def test_env_overrides_config_file(self):
        """Env var takes precedence over config file."""
        with mock.patch.dict(os.environ, {"WXWATCHER_INTERVAL": "5"}):
            cfg = load_config(_make_args(), config_file_data={"poll_interval": 60})
            assert cfg.poll_interval == 5

    def test_ignore_patterns_merged_across_layers(self):
        """Ignore patterns merged from defaults + config file + CLI."""
        cfg = load_config(
            _make_args(ignore="dist"),
            config_file_data={"ignore": ["*.log", "tmp"]}
        )
        assert "dist" in cfg.ignore_patterns
        assert "*.log" in cfg.ignore_patterns
        assert "tmp" in cfg.ignore_patterns
        # defaults still present
        assert ".git" in cfg.ignore_patterns

    def test_ext_merged_from_config_file(self):
        """Extensions merged from config file list."""
        cfg = load_config(
            _make_args(),
            config_file_data={"ext": ["py", ".md"]}
        )
        assert ".py" in cfg.monitor_exts
        assert ".md" in cfg.monitor_exts

    def test_push_url_from_config_file(self):
        """Push URL can come from config file."""
        cfg = load_config(
            _make_args(push_url=None),
            config_file_data={"push_url": "http://config.com/push"}
        )
        assert cfg.push_url == "http://config.com/push"

    def test_config_file_push_overridden_by_cli(self):
        """CLI push_url overrides config file."""
        cfg = load_config(
            _make_args(push_url="http://cli.com/push"),
            config_file_data={"push_url": "http://config.com/push"}
        )
        assert cfg.push_url == "http://cli.com/push"
