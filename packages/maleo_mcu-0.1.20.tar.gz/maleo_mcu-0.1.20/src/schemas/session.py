from pydantic import BaseModel, Field
from typing import Annotated, Literal, overload
from uuid import UUID

from nexo.schemas.mixins.identity import (
    Ids,
    UUIDs,
    UUIDOrganizationId,
    UUIDOrganizationIds,
    UUIDUserId,
    UUIDUserIds,
    UUIDPrincipalId,
    Name,
    UUIDPrincipalIds,
)
from nexo.schemas.mixins.parameter import IncludeURL
from nexo.schemas.security.enums import (
    Domain,
    DomainMixin,
    OptListOfDomains,
    DomainsMixin,
)
from nexo.schemas.parameter import (
    ReadPaginatedMultipleParameter,
    ReadSingleParameter as BaseReadSingleParameter,
    DeleteSingleParameter as BaseDeleteSingleParameter,
)
from nexo.types.uuid import OptListOfUUIDs
from nexo.types.integer import OptListOfInts, OptInt
from nexo.types.dict import StrToAnyDict
from nexo.types.string import OptStr
from ..enums.session import IdentifierType
from ..types.session import IdentifierValueType
from ..mixins.common import ClientId, ClientIds
from ..mixins.session import (
    SessionIdentifier,
)


class CreateData(
    Name[OptStr],
    ClientId[OptInt],
    UUIDOrganizationId[UUID],
    UUIDUserId[UUID],
    UUIDPrincipalId[UUID],
    DomainMixin[Domain],
):
    pass


class CreateDataMixin(BaseModel):
    data: CreateData = Field(..., description="Create data")


class CreateParameter(CreateDataMixin):
    pass


class ReadMultipleParameter(
    ReadPaginatedMultipleParameter,
    Ids[OptListOfInts],
    UUIDs[OptListOfUUIDs],
    UUIDOrganizationIds[OptListOfUUIDs],
    UUIDUserIds[OptListOfUUIDs],
    ClientIds[OptListOfInts],
    DomainsMixin[OptListOfDomains],
    UUIDPrincipalIds[OptListOfUUIDs],
):
    ids: Annotated[OptListOfInts, Field(None, description="IDs")] = None
    uuids: Annotated[OptListOfUUIDs, Field(None, description="UUIDs")] = None
    organization_ids: Annotated[
        OptListOfUUIDs, Field(None, description="Organization IDs")
    ] = None
    user_ids: Annotated[OptListOfUUIDs, Field(None, description="User IDs")] = None
    client_ids: Annotated[OptListOfInts, Field(None, description="Client's Ids")] = None

    @property
    def _query_param_fields(self) -> set[str]:
        return {
            "ids",
            "uuids",
            "organization_ids",
            "user_ids",
            "client_ids",
            "search",
            "page",
            "limit",
            "use_cache",
        }

    def to_query_params(self) -> StrToAnyDict:
        return self.model_dump(
            mode="json",
            include=self._query_param_fields,
            exclude_none=True,
        )


class ReadSingleParameter(
    BaseReadSingleParameter[SessionIdentifier],
):
    @classmethod
    def from_identifier(
        cls,
        identifier: SessionIdentifier,
        use_cache: bool = True,
    ) -> "ReadSingleParameter":
        return cls(
            identifier=identifier,
            use_cache=use_cache,
        )

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: int,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.UUID],
        identifier_value: UUID,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...

    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        use_cache: bool = True,
    ) -> "ReadSingleParameter":
        return cls.from_identifier(
            SessionIdentifier(
                type=identifier_type,
                value=identifier_value,
            ),
            use_cache=use_cache,
        )

    def to_query_params(self) -> StrToAnyDict:
        return self.model_dump(
            mode="json",
            include={"use_cache"},
            exclude_none=True,
        )


class DeleteSingleParameter(BaseDeleteSingleParameter[SessionIdentifier]):
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: int,
    ) -> "DeleteSingleParameter": ...

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.UUID],
        identifier_value: UUID,
    ) -> "DeleteSingleParameter": ...

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
    ) -> "DeleteSingleParameter": ...

    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
    ) -> "DeleteSingleParameter":
        return cls(
            identifier=SessionIdentifier(
                type=identifier_type,
                value=identifier_value,
            )
        )
