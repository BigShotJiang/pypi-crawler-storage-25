from pydantic import BaseModel, Field
from typing import Annotated, Generic, Literal, TypeGuard
from uuid import UUID

from nexo.schemas.mixins.identity import Identifier
from nexo.types.integer import OptIntT

from ..enums.session import IdentifierType
from ..types.session import IdentifierValueType


class TotalCheckups(BaseModel, Generic[OptIntT]):
    total_checkups: Annotated[OptIntT, Field(..., description="Total Checkup")]


class ProcessedCheckups(BaseModel, Generic[OptIntT]):
    processed_checkups: Annotated[OptIntT, Field(..., description="Process Checkup")]


class SessionIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdSessionIdentifier(Identifier[Literal[IdentifierType.ID], int]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier type"),
    ] = IdentifierType.ID

    value: Annotated[int, Field(..., ge=1, description="Identifier value")]


class UUIDSessionIdentifier(Identifier[Literal[IdentifierType.UUID], UUID]):
    type: Annotated[
        Literal[IdentifierType.UUID],
        Field(IdentifierType.UUID, description="Identifier type"),
    ] = IdentifierType.UUID

    value: Annotated[UUID, Field(..., description="Identifier value")]


AnySessionIdentifier = SessionIdentifier | IdSessionIdentifier | UUIDSessionIdentifier


def is_id_identifier(
    identifier: AnySessionIdentifier,
) -> TypeGuard[IdSessionIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, int)


def is_uuid_identifier(
    identifier: AnySessionIdentifier,
) -> TypeGuard[UUIDSessionIdentifier]:
    return identifier.type is IdentifierType.UUID and isinstance(identifier.value, UUID)
