from nexo.schemas.resource import Resource, ResourceIdentifier

SESSION_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(
            key="session",
            name="Session",
            slug="sessions",
        )
    ],
    details=None,
)
