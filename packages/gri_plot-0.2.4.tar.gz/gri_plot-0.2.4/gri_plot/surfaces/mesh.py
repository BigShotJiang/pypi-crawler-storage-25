"""Core mesh utilities for 3D surface visualization.

Provides functions for creating Plotly Mesh3d traces from vertex/face arrays
and for building triangular meshes from parametric 2D grids.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import plotly.graph_objects as go

if TYPE_CHECKING:
    from collections.abc import Callable

    from numpy.typing import NDArray


def vertices_to_mesh3d(  # noqa: PLR0913 - mesh rendering needs many options
    vertices: NDArray[np.floating],
    faces: NDArray[np.integer],
    *,
    intensity_fn: Callable[[NDArray[np.floating]], NDArray[np.floating]] | None = None,
    color: str | None = None,
    opacity: float = 0.7,
    name: str | None = None,
    colorscale: str | list = "Viridis",
    colorbar_title: str | None = None,
    showscale: bool = False,
    **kwargs,
) -> go.Mesh3d:
    """Create a Plotly Mesh3d trace from vertices and faces.

    This is the core rendering function. All shape and surface classes should
    use this to generate their Plotly traces.

    Args:
        vertices: Vertex positions, shape (N, 3).
        faces: Triangle indices, shape (M, 3).
        intensity_fn: Optional function to compute vertex intensities for coloring.
            Takes vertices (N, 3) and returns intensities (N,). If None and color
            is None, defaults to distance from mesh centroid (works well in any
            coordinate frame).
        color: Uniform surface color. Mutually exclusive with intensity_fn.
        opacity: Surface opacity (0-1).
        name: Trace name for legend.
        colorscale: Plotly colorscale name or custom colorscale list
            (used with intensity_fn).
        colorbar_title: Title for colorbar (used with intensity_fn).
        showscale: Whether to show the colorbar.
        **kwargs: Additional arguments for go.Mesh3d.

    Returns:
        Plotly Mesh3d trace.
    """
    vertices = np.asarray(vertices)
    faces = np.asarray(faces)

    trace_kwargs: dict = {
        "x": vertices[:, 0],
        "y": vertices[:, 1],
        "z": vertices[:, 2],
        "i": faces[:, 0],
        "j": faces[:, 1],
        "k": faces[:, 2],
        "opacity": opacity,
    }

    if color is not None:
        trace_kwargs["color"] = color
    else:
        if intensity_fn is not None:
            intensity = intensity_fn(vertices)
        else:
            centroid = vertices.mean(axis=0)
            intensity = np.linalg.norm(vertices - centroid, axis=-1)

        trace_kwargs["intensity"] = intensity
        trace_kwargs["colorscale"] = colorscale
        trace_kwargs["showscale"] = showscale
        if colorbar_title is not None:
            trace_kwargs["colorbar"] = {"title": colorbar_title}

    if name is not None:
        trace_kwargs["name"] = name
        trace_kwargs["showlegend"] = True

    trace_kwargs.update(kwargs)
    return go.Mesh3d(**trace_kwargs)


def grid_to_mesh(
    x: NDArray[np.floating],
    y: NDArray[np.floating],
    z: NDArray[np.floating],
) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
    """Convert a 2D grid of 3D points to vertices and triangular faces.

    Used for parametric surfaces where x, y, z are 2D arrays defining
    a surface patch.

    Args:
        x: X coordinates, 2D array of shape (M, N).
        y: Y coordinates, 2D array of shape (M, N).
        z: Z coordinates, 2D array of shape (M, N).

    Returns:
        Tuple of (vertices, faces) where:
            - vertices: shape (M*N, 3)
            - faces: shape ((M-1)*(N-1)*2, 3)
    """
    m, n = x.shape
    vertices = np.column_stack([x.ravel(), y.ravel(), z.ravel()])

    faces = []
    for i in range(m - 1):
        for j in range(n - 1):
            idx00 = i * n + j
            idx01 = i * n + (j + 1)
            idx10 = (i + 1) * n + j
            idx11 = (i + 1) * n + (j + 1)

            faces.append([idx00, idx10, idx11])
            faces.append([idx00, idx11, idx01])

    return vertices, np.array(faces, dtype=np.int64)


__all__ = [
    "grid_to_mesh",
    "vertices_to_mesh3d",
]
