"""Plotting utilities for GeoSol Research.

This package provides utilities for 2D and 3D visualization using Plotly,
including scatter plots, geographic maps, and parametric 3D shapes for
geolocation observables.

Main components:
    - scatter: 2D scatter plots with Plotly
    - scatter_map: Geographic scatter maps
    - Figure3D: 3D figure for combining surfaces
    - shapes: Geometric shapes (Ellipsoid, Sphere, Cone, Cylinder)
    - observables: Parametric geolocation surfaces (AOA, LOS, Range)
    - surfaces: ImplicitShape ABC and mesh trace utilities
    - frames: Coordinate frame handling
"""

# 2D plotting
# 3D plotting infrastructure
from .figure3d import DEFAULT_COLORS, Figure3D, plot_surfaces
from .figure_map import FigureMap, MapStyle
from .frames import Bounds, Frame, FrameTransformer

# Observables
from .observables import (
    AoaSurface,
    LosSurface,
    RangeSphere,
)
from .plot_ellipse import plot_ellipse
from .scatter import scatter
from .scatter_map import scatter_map

# Shapes
from .shapes import Cone, Cylinder, Ellipse, Ellipsoid, Sphere

# Shape mesh generators
from .shapes.meshgen import cone_mesh, cylinder_mesh, ellipsoid_mesh, sphere_mesh

# Surface utilities
from .surfaces import (
    ImplicitShape,
    expand_bounds,
    merge_bounds,
)
from .surfaces.mesh import grid_to_mesh, vertices_to_mesh3d

__all__ = [
    "DEFAULT_COLORS",
    "AoaSurface",
    "Bounds",
    "Cone",
    "Cylinder",
    "Ellipse",
    "Ellipsoid",
    "Figure3D",
    "FigureMap",
    "Frame",
    "FrameTransformer",
    "ImplicitShape",
    "LosSurface",
    "MapStyle",
    "RangeSphere",
    "Sphere",
    "cone_mesh",
    "cylinder_mesh",
    "ellipsoid_mesh",
    "expand_bounds",
    "grid_to_mesh",
    "merge_bounds",
    "plot_ellipse",
    "plot_surfaces",
    "scatter",
    "scatter_map",
    "sphere_mesh",
    "vertices_to_mesh3d",
]
