"""Tests for frames module."""

import numpy as np
import pytest
from gri_utils.conversion import lla_to_xyz, xyz_to_lla

from gri_plot.frames import Bounds, Frame, FrameTransformer


def test_xyz_lla_roundtrip():
    """XYZ to LLA and back preserves coordinates."""
    xyz_original = np.array([4e6, 3e6, 4e6])
    lla = xyz_to_lla(xyz_original)
    xyz_recovered = lla_to_xyz(lla)

    np.testing.assert_allclose(xyz_recovered, xyz_original, rtol=1e-6)


def test_enu_requires_origin():
    """ENU frame transformer requires origin_xyz."""
    with pytest.raises(ValueError):
        FrameTransformer(Frame.ENU)


def test_enu_roundtrip():
    """ENU frame transformer roundtrip preserves coordinates."""
    origin = np.array([4e6, 3e6, 4e6])
    transformer = FrameTransformer(Frame.ENU, origin)

    xyz_original = origin + np.array([100.0, 200.0, 50.0])
    enu = transformer.to_display(xyz_original)
    xyz_recovered = transformer.from_display(enu)

    np.testing.assert_allclose(xyz_recovered, xyz_original, rtol=1e-6)


def test_axis_labels():
    """Frame transformers return correct axis labels."""
    assert FrameTransformer(Frame.XYZ).get_axis_labels() == ("X (m)", "Y (m)", "Z (m)")
    assert FrameTransformer(Frame.LLA).get_axis_labels() == (
        "Latitude (deg)",
        "Longitude (deg)",
        "Altitude (m)",
    )


def test_axis_labels_enu():
    """ENU transformer returns East/North/Up labels."""
    origin = np.array([4e6, 3e6, 4e6])
    assert FrameTransformer(Frame.ENU, origin).get_axis_labels() == (
        "East (m)",
        "North (m)",
        "Up (m)",
    )


def test_xyz_to_display_is_identity():
    """XYZ display frame returns input coordinates unchanged."""
    transformer = FrameTransformer(Frame.XYZ)
    xyz = np.array([4e6, 3e6, 4e6])
    np.testing.assert_array_equal(transformer.to_display(xyz), xyz)
    np.testing.assert_array_equal(transformer.from_display(xyz), xyz)


def test_lla_roundtrip_via_transformer():
    """LLA FrameTransformer round-trips XYZ coordinates."""
    transformer = FrameTransformer(Frame.LLA)
    xyz_original = np.array([4e6, 3e6, 4e6])

    lla = transformer.to_display(xyz_original)
    xyz_recovered = transformer.from_display(lla)

    np.testing.assert_allclose(xyz_recovered, xyz_original, rtol=1e-6)
    # Sanity: latitude in degrees is within range.
    assert -90.0 <= lla[0] <= 90.0
    assert -180.0 <= lla[1] <= 180.0


def test_transform_bounds_xyz_passthrough():
    """XYZ transform_bounds returns input corners untouched."""
    transformer = FrameTransformer(Frame.XYZ)
    min_c = np.array([-1.0, -2.0, -3.0])
    max_c = np.array([1.0, 2.0, 3.0])

    bounds = transformer.transform_bounds((min_c, max_c))

    assert isinstance(bounds, Bounds)
    assert bounds.frame == Frame.XYZ
    np.testing.assert_array_equal(bounds.min_corner, min_c)
    np.testing.assert_array_equal(bounds.max_corner, max_c)
    assert bounds.origin_xyz is None


def test_transform_bounds_enu_orders_corners():
    """ENU transform_bounds returns min < max and carries origin."""
    origin = np.array([4e6, 3e6, 4e6])
    transformer = FrameTransformer(Frame.ENU, origin)
    # Offsets chosen so translating to ENU may reverse some axes; the
    # transformer must still return sorted corners.
    min_xyz = origin + np.array([-100.0, 200.0, -50.0])
    max_xyz = origin + np.array([100.0, -200.0, 50.0])

    bounds = transformer.transform_bounds((min_xyz, max_xyz))

    assert bounds.frame == Frame.ENU
    assert np.all(bounds.min_corner <= bounds.max_corner)
    np.testing.assert_array_equal(bounds.origin_xyz, origin)


def test_transform_bounds_lla_samples_all_corners():
    """LLA transform_bounds covers every corner of the XYZ box."""
    # Box around a point well away from the origin/poles.
    center = np.array([4e6, 3e6, 4e6])
    half = 10_000.0
    min_xyz = center - half
    max_xyz = center + half

    bounds = FrameTransformer(Frame.LLA).transform_bounds((min_xyz, max_xyz))

    assert bounds.frame == Frame.LLA
    # Verify every XYZ corner maps inside the reported LLA bounds.
    corners = np.array(
        [
            [min_xyz[0], min_xyz[1], min_xyz[2]],
            [min_xyz[0], min_xyz[1], max_xyz[2]],
            [min_xyz[0], max_xyz[1], min_xyz[2]],
            [min_xyz[0], max_xyz[1], max_xyz[2]],
            [max_xyz[0], min_xyz[1], min_xyz[2]],
            [max_xyz[0], min_xyz[1], max_xyz[2]],
            [max_xyz[0], max_xyz[1], min_xyz[2]],
            [max_xyz[0], max_xyz[1], max_xyz[2]],
        ],
    )
    lla_corners = np.array([xyz_to_lla(c) for c in corners])
    assert np.all(lla_corners.min(axis=0) >= bounds.min_corner - 1e-9)
    assert np.all(lla_corners.max(axis=0) <= bounds.max_corner + 1e-9)
