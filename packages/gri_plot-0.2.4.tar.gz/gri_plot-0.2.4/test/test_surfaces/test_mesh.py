"""Tests for gri_plot.surfaces.mesh utilities."""

import numpy as np
import plotly.graph_objects as go

from gri_plot.surfaces.mesh import grid_to_mesh, vertices_to_mesh3d


def test_vertices_to_mesh3d_returns_mesh3d():
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
    faces = np.array([[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]])

    trace = vertices_to_mesh3d(vertices, faces)

    assert isinstance(trace, go.Mesh3d)
    assert len(np.asarray(trace.x)) == 4
    assert len(np.asarray(trace.i)) == 4


def test_vertices_to_mesh3d_uniform_color():
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=float)
    faces = np.array([[0, 1, 2]])

    trace = vertices_to_mesh3d(vertices, faces, color="red", name="tri")

    assert trace.color == "red"
    assert trace.intensity is None
    assert trace.name == "tri"


def test_vertices_to_mesh3d_intensity_fn_applied():
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=float)
    faces = np.array([[0, 1, 2]])

    trace = vertices_to_mesh3d(vertices, faces, intensity_fn=lambda v: v[:, 2])

    assert trace.intensity is not None
    assert np.allclose(np.asarray(trace.intensity), vertices[:, 2])


def test_grid_to_mesh_produces_expected_shape():
    u = np.linspace(0, 1, 3)
    v = np.linspace(0, 1, 4)
    x, y = np.meshgrid(u, v, indexing="ij")
    z = np.zeros_like(x)

    vertices, faces = grid_to_mesh(x, y, z)

    assert vertices.shape == (12, 3)
    assert faces.shape == ((3 - 1) * (4 - 1) * 2, 3)
    assert faces.max() < len(vertices)
