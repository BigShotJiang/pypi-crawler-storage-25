"""Tests for figure3d module."""

import numpy as np
import plotly.graph_objects as go
import pytest

from gri_plot import Figure3D, Frame, plot_surfaces
from gri_plot.shapes import Cone, Cylinder, Ellipsoid, Sphere


def test_enu_requires_origin():
    """ENU frame requires origin_xyz."""
    with pytest.raises(ValueError):
        Figure3D(display_frame=Frame.ENU)


def test_build_returns_plotly_figure():
    """build() returns a Plotly Figure with traces."""
    fig = Figure3D()
    fig.add_surface(Sphere(np.zeros(3), 100.0))

    plotly_fig = fig.build()

    assert isinstance(plotly_fig, go.Figure)
    assert len(list(plotly_fig.data)) > 0


def test_plot_surfaces_convenience():
    """plot_surfaces() creates a figure from multiple surfaces."""
    sphere1 = Sphere(np.zeros(3), 100.0)
    sphere2 = Sphere(np.array([200.0, 0.0, 0.0]), 50.0)

    fig = plot_surfaces(sphere1, sphere2)

    assert isinstance(fig, go.Figure)
    assert len(list(fig.data)) >= 2


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_ellipsoid_enu():
    """Visual: Ellipsoid in ENU frame."""
    center = np.array([4e6, 3e6, 4e6])
    cov = np.diag([10000.0, 5000.0, 2500.0])
    ellipsoid = Ellipsoid(center, covariance=cov, label="1-sigma")

    fig = Figure3D(display_frame=Frame.ENU, origin_xyz=center, title="Ellipsoid (ENU)")
    fig.add_surface(ellipsoid)
    fig.add_points(center.reshape(1, 3), labels=["Center"])
    fig.show()


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_multiple_spheres():
    """Visual: Multiple spheres."""
    fig = Figure3D(title="Multiple Spheres")

    for i in range(5):
        center = np.array([i * 300.0, 0.0, 0.0])
        fig.add_surface(Sphere(center, 100.0, label=f"Sphere {i + 1}"), opacity=0.6)

    fig.show()


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_combined_surfaces():
    """Visual: Combined shapes in one figure."""
    fig = Figure3D(title="Combined Shapes")

    fig.add_surface(Sphere(np.zeros(3), 50.0, label="Sphere"))
    fig.add_surface(
        Cone(np.array([150.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0]), 0.4, 100.0),
        label="Cone",
    )
    fig.add_surface(
        Cylinder(np.array([300.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0]), 30.0, 100.0),
        label="Cylinder",
    )

    fig.show()
