# syncware

A CLI tool to sync selective folders from Git repositories to a target directory.

## Installation

```bash
pip install syncware
```

## Usage

```bash
# List configured skills
syncware list

# Sync skills to target directory
syncware sync

# Preview sync (dry run)
syncware sync --dry

# Update repos and sync
syncware update

# Use custom config
syncware -c myconfig.yaml list
```

## Configuration

Create a `skills.yaml` file:

```yaml
repos:
  - name: claude
    path: /path/to/claude-skills
    entry: skills
    skills:
      - docx
      - xlsx
      - pdf

target: ./skills
```

## How it works

- **repo**: Local Git repository
- **entry**: Subdirectory where skills are located
- **skill**: Subdirectory under entry
- **target**: Directory where skills are copied

Resolved path: `<repo.path>/<entry>/<skill>` → copied to `<target>/<skill>`
