#!/usr/bin/env python3
"""
syncware CLI

A CLI tool for syncing skills from local Git repositories to a target directory.

Usage:
    syncware list
    syncware sync [--dry]
    syncware update
"""

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import yaml
from pathlib import Path

try:
    from termcolor import colored

    HAS_TERMCOLOR = True
except ImportError:
    HAS_TERMCOLOR = False


def c(text, c_name):
    if not HAS_TERMCOLOR:
        return text
    colors_map = {
        "header": "\033[95m",
        "blue": "\033[94m",
        "cyan": "\033[96m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "red": "\033[91m",
        "bold": "\033[1m",
    }
    return f"{colors_map.get(c_name, '')}{text}\033[0m"


def print_msg(msg, level="info", verbose=False):
    if verbose and level == "debug":
        return
    prefixes = {
        "info": c("[*]", "blue"),
        "success": c("[+]", "green"),
        "warning": c("[!]", "yellow"),
        "error": c("[x]", "red"),
        "debug": c("[D]", "cyan"),
    }
    print(f"{prefixes.get(level, '')} {msg}")


def load_config(config_path="skills.yaml"):
    path = Path(config_path)
    if not path.exists():
        print_msg(f"Config file not found: {config_path}", "error")
        sys.exit(1)
    with open(path) as f:
        return yaml.safe_load(f)


def get_all_skills(repo_path, entry):
    entry_path = Path(repo_path) / entry
    if not entry_path.exists():
        return []
    return [d.name for d in entry_path.iterdir() if d.is_dir()]


def dir_hash(path):
    """Compute a hash of all files in a directory (recursive)."""
    path = Path(path)
    if not path.exists():
        return None
    hasher = hashlib.sha256()
    for item in sorted(path.rglob("*")):
        if item.is_file():
            hasher.update(item.name.encode())
            hasher.update(item.read_bytes())
    return hasher.hexdigest()


def has_changed(src, dst):
    """Check if source directory has changed compared to destination."""
    src_hash = dir_hash(src)
    dst_hash = dir_hash(dst)
    if src_hash is None:
        return False
    if dst_hash is None:
        return True
    return src_hash != dst_hash


def resolve_skills(repo_config):
    skills = repo_config.get("skills", [])
    if skills == "*" or (
        isinstance(skills, list) and "*" in skills and len(skills) == 1
    ):
        return get_all_skills(repo_config["path"], repo_config["entry"])
    return skills


def cmd_list(config, verbose=False):
    print_msg("Configured skills:", "info", verbose)
    print()

    for repo in config.get("repos", []):
        repo_path = Path(repo["path"])
        entry = repo["entry"]
        repo_name = repo["name"]

        if not repo_path.exists():
            print_msg(f"Repo not found: {repo_path}", "warning")
            continue

        for skill in resolve_skills(repo):
            skill_path = repo_path / entry / skill
            source = skill_path.resolve()
            print(f"{c(skill, 'green')} -> {source}")


def cmd_sync(config, dry=False, verbose=False):
    target_str = config.get("target", "./skills")
    target = Path(os.path.expanduser(target_str))
    target.mkdir(parents=True, exist_ok=True)

    all_configured = []

    for repo in config.get("repos", []):
        repo_path = Path(repo["path"])
        entry = repo["entry"]
        repo_name = repo["name"]

        if not repo_path.exists():
            print_msg(f"Repo not found: {repo_path}", "warning")
            continue

        for skill in resolve_skills(repo):
            skill_path = repo_path / entry / skill

            if not skill_path.exists():
                print_msg(f"Skill directory not found: {skill_path}", "warning")
                continue

            dest = target / skill
            dest_display = f"{target_str}/{skill}"
            all_configured.append((dest, skill_path))

            if dry:
                if not dest.exists():
                    print_msg(f"create: {dest_display}", "success")
                elif has_changed(skill_path, dest):
                    print_msg(f"update: {dest_display}", "warning")
                else:
                    print_msg(f"unchanged: {dest_display}", "info")
            else:
                if not dest.exists():
                    print_msg(f"create: {dest_display}", "success")
                elif has_changed(skill_path, dest):
                    print_msg(f"update: {dest_display}", "warning")
                else:
                    print_msg(f"unchanged: {dest_display}", "info")

                if not dest.exists() or has_changed(skill_path, dest):
                    shutil.copytree(skill_path, dest, dirs_exist_ok=True)

    existing_dirs = []
    if target.exists():
        for item in target.iterdir():
            if item.is_dir():
                existing_dirs.append(item)

    for existing in existing_dirs:
        is_configured = any(dest.name == existing.name for dest, _ in all_configured)
        if not is_configured:
            if dry:
                print_msg(f"remove {target_str}/{existing.name}", "warning")
            else:
                print_msg(f"remove {target_str}/{existing.name}", "warning")
                shutil.rmtree(existing)

    if dry:
        print_msg("Dry run complete - no changes made", "info")


def cmd_update(config, dry=False, verbose=False):
    for repo in config.get("repos", []):
        repo_path = Path(repo["path"])
        repo_name = repo["name"]

        if not repo_path.exists():
            print_msg(f"Repo not found: {repo_path}", "warning")
            continue

        print_msg(f"Updating {repo_name}...", "info")

        try:
            result = subprocess.run(
                ["git", "pull", "--ff-only"],
                cwd=repo_path,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                print_msg(f"Updated {repo_name}", "success")
                if verbose:
                    print(result.stdout.strip())
            else:
                print_msg(
                    f"Git pull failed for {repo_name}: {result.stderr.strip()}", "error"
                )
        except Exception as e:
            print_msg(f"Error updating {repo_name}: {e}", "error")

    print()
    cmd_sync(config, dry=dry, verbose=verbose)


def main():
    parser = argparse.ArgumentParser(
        description="Skills Manager CLI - Sync skills from local Git repositories"
    )
    parser.add_argument(
        "-c",
        "--config",
        default="skills.yaml",
        help="Path to config file (default: skills.yaml)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose output"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser("list", help="List all configured skills")

    sync_parser = subparsers.add_parser("sync", help="Sync skills to target directory")
    sync_parser.add_argument(
        "--dry",
        action="store_true",
        help="Show what would happen without modifying filesystem",
    )

    update_parser = subparsers.add_parser("update", help="Update repos and sync skills")
    update_parser.add_argument(
        "--dry",
        action="store_true",
        help="Show what would happen without modifying filesystem",
    )

    args = parser.parse_args()

    config = load_config(args.config)

    if args.command == "list":
        cmd_list(config, verbose=args.verbose)
    elif args.command == "sync":
        cmd_sync(config, dry=args.dry, verbose=args.verbose)
    elif args.command == "update":
        cmd_update(config, dry=args.dry, verbose=args.verbose)


if __name__ == "__main__":
    main()
