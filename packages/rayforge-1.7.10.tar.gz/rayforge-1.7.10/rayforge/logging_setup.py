import logging
import sys
from datetime import datetime
from typing import Optional, List
from pathlib import Path
from blinker import Signal
from .config import LOG_DIR

_ui_formatter_instance: Optional[logging.Formatter] = None
_ui_log_records: List[logging.LogRecord] = []

LOG_FILES_TO_KEEP = 5

# Global signal for UI log events
ui_log_event_received = Signal()


class UILogFilter(logging.Filter):
    """
    This filter only allows log records that are intended for the user-facing
    log dialog, such as machine events, warnings, and errors.

    Log Categories:
    - MACHINE_EVENT: Important machine responses and events
    - ERROR: Error messages
    - WARNING: Warning messages
    - STATE_CHANGE: Device state changes
    - USER_COMMAND: Commands entered by user in console
    - MACHINE_RESPONSE: Responses to user commands
    - STATUS_POLL: Frequent status poll responses (filtered by default)

    UI_CATEGORIES: Always shown in UI
    VERBOSE_CATEGORIES: Shown only when verbose mode is enabled
    """

    UI_CATEGORIES = {
        "MACHINE_EVENT",
        "ERROR",
        "WARNING",
        "STATE_CHANGE",
        "USER_COMMAND",
    }

    VERBOSE_CATEGORIES = {"STATUS_POLL", "MACHINE_RESPONSE"}

    def filter(self, record: logging.LogRecord) -> bool:
        category = record.__dict__.get("log_category")
        return (
            category in self.UI_CATEGORIES
            or category in self.VERBOSE_CATEGORIES
        )


class ConsoleFormatter(logging.Formatter):
    """
    A formatter for the console UI that formats messages based on their
    category for better readability.

    Format by category:
    - USER_COMMAND: "> {message}" (no timestamp)
    - ERROR: "ERROR {message}"
    - WARNING: "WARN {message}"
    - STATUS_POLL: "{timestamp} {message}"
    - Others: "{timestamp} {message}"
    """

    def format(self, record: logging.LogRecord) -> str:
        category = record.__dict__.get("log_category")
        message = record.getMessage()

        if category == "USER_COMMAND":
            return f"> {message}"
        elif category == "ERROR":
            return f"ERROR {message}"
        elif category == "WARNING":
            return f"WARN {message}"
        elif category == "STATUS_POLL":
            timestamp = self.formatTime(record, self.datefmt)
            return f"{timestamp} {message}"
        else:
            timestamp = self.formatTime(record, self.datefmt)
            return f"{timestamp} {message}"


class ConsoleLogFilter(logging.Filter):
    """
    This filter rejects log records that are categorized as 'RAW_IO'
    to prevent spamming the console with low-level communication data.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        return record.__dict__.get("log_category") != "RAW_IO"


class SessionFileFormatter(logging.Formatter):
    """
    Formatter for the session log file that enriches each line with extra
    attributes (log_category, machine_id) when present on the LogRecord.
    """

    def format(self, record: logging.LogRecord) -> str:
        category = record.__dict__.get("log_category")
        machine_id = record.__dict__.get("machine_id")
        parts = []
        if category:
            parts.append(category)
        if machine_id:
            parts.append(machine_id)
        tag = f" [{' | '.join(parts)}]" if parts else ""
        original = super().format(record)
        if tag:
            level = record.levelname
            original = original.replace(f" {level} - ", f" {level}{tag} - ", 1)
        return original


class UILogHandler(logging.Handler):
    """
    A custom logging handler that forwards filtered log records to the UI
    via a blinker signal and stores them in a buffer for console history.
    """

    def emit(self, record: logging.LogRecord):
        _ui_log_records.append(record)
        log_entry = self.format(record)
        category = record.__dict__.get("log_category")
        machine_id = record.__dict__.get("machine_id")
        ui_log_event_received.send(
            self, message=log_entry, category=category, machine_id=machine_id
        )


def _cleanup_old_logs(log_dir: Path, keep_count: int):
    """
    Deletes old log files, keeping only the most recent 'keep_count' number
    of logs.
    """
    try:
        # Find all log files that match our session pattern
        log_files: List[Path] = sorted(
            log_dir.glob("session-*.log"),
            key=lambda p: p.stat().st_mtime,  # Sort by modification time
            reverse=True,  # Newest first
        )

        # If we have more logs than we want to keep, delete the oldest ones
        if len(log_files) > keep_count:
            files_to_delete = log_files[keep_count:]
            logging.debug(
                f"Log cleanup: Deleting {len(files_to_delete)} old log files."
            )
            for f in files_to_delete:
                try:
                    f.unlink()
                except OSError as e:
                    logging.warning(f"Could not delete old log file {f}: {e}")
    except Exception as e:
        # We don't want a logging failure to crash the app startup
        logging.error(f"An unexpected error occurred during log cleanup: {e}")


def get_ui_log_records() -> List[logging.LogRecord]:
    """
    Returns the buffered UI log records.
    Used by the Console widget to populate history.
    """
    return _ui_log_records


def get_ui_formatter() -> Optional[logging.Formatter]:
    """
    Returns the global instance of the Formatter used for the UI Log.
    """
    return _ui_formatter_instance


def setup_logging(loglevel_str: str):
    """
    Configures the root logger with console, file, and in-memory handlers.
    This replaces the need for logging.basicConfig().

    Args:
        loglevel_str: The desired logging level for the console as a string
                      (e.g., "INFO", "DEBUG").
    """
    global _ui_formatter_instance

    log_level = getattr(logging, loglevel_str.upper(), logging.INFO)
    root_logger = logging.getLogger()

    # Clear any handlers already configured (e.g., by basicConfig)
    if root_logger.hasHandlers():
        root_logger.handlers.clear()

    # Set root logger to the lowest level to capture everything.
    # Handlers will then filter messages by their own specific levels.
    root_logger.setLevel(logging.DEBUG)

    # 1. Add the console handler IMMEDIATELY after clearing.
    # This prevents logging calls in helper functions (like _cleanup_old_logs)
    # from implicitly re-triggering basicConfig.
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    console_handler.setFormatter(console_formatter)
    console_handler.addFilter(ConsoleLogFilter())
    root_logger.addHandler(console_handler)

    # Now it is safe to run functions that might log things.
    _cleanup_old_logs(LOG_DIR, LOG_FILES_TO_KEEP)

    # 2. Session File Handler (for persistent, detailed logs)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_file = LOG_DIR / f"session-{timestamp}.log"
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        SessionFileFormatter(
            "%(asctime)s - %(process)d - %(threadName)s - %(name)s - "
            "%(levelname)s - %(message)s"
        )
    )
    root_logger.addHandler(file_handler)

    # 3. UI Log Handler (for the MachineLogDialog)
    ui_handler = UILogHandler()
    ui_handler.setLevel(logging.INFO)  # Don't show DEBUG messages in UI log
    ui_handler.addFilter(UILogFilter())
    # Create the formatter and store it in our global instance
    _ui_formatter_instance = ConsoleFormatter(datefmt="%Y-%m-%d %H:%M:%S")
    ui_handler.setFormatter(_ui_formatter_instance)
    root_logger.addHandler(ui_handler)

    # Silence noisy third-party loggers
    pyvips_loggers = [
        "pyvips",
        "pyvips.vobject",
        "pyvips.voperation",
        "pyvips.error",
    ]
    for name in pyvips_loggers:
        logger = logging.getLogger(name)
        logger.setLevel(logging.WARNING)
        logger.propagate = False
        logger.handlers = []

    logging.info(f"Logging configured. Console level: {loglevel_str}")
    logging.info(f"Session log file: {log_file}")
