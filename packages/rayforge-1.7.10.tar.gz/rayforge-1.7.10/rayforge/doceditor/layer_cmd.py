from __future__ import annotations
import logging
from typing import TYPE_CHECKING, Dict, Optional, List
from gettext import gettext as _
from ..core.group import Group
from ..core.layer import Layer
from ..core.item import DocItem
from ..core.undo import (
    Command,
    ChangePropertyCommand,
    CompositeCommand,
)
from ..core.undo.list_cmd import ReorderListCommand
from ..core.workpiece import WorkPiece
from ..core.color import pick_unused_color

if TYPE_CHECKING:
    from ..ui_gtk.canvas2d.surface import WorkSurface
    from .editor import DocEditor

logger = logging.getLogger(__name__)


class MoveWorkpiecesLayerCommand(Command):
    """
    An undoable command to move one or more workpieces to a different layer.
    """

    def __init__(
        self,
        workpieces: List[WorkPiece],
        new_layer: Layer,
        old_layer: Layer,
        name: Optional[str] = None,
    ):
        super().__init__(name)
        self.workpieces = workpieces
        self.new_layer = new_layer
        self.old_layer = old_layer
        if not name:
            self.name = _("Move to another layer")

    def _move(self, from_layer: Layer, to_layer: Layer):
        """The core logic for moving workpieces, model-only."""
        # The UI will react to the model changes automatically through signals.
        # The DocItem.add_child() method handles removing the child from its
        # previous parent.
        for wp in self.workpieces:
            to_layer.add_child(wp)

    def execute(self):
        """Executes the command, moving workpieces to the new layer."""
        self._move(self.old_layer, self.new_layer)

    def undo(self):
        """Undoes the command, moving workpieces back to the old layer."""
        self._move(self.new_layer, self.old_layer)


class MoveItemsLayerCommand(Command):
    """
    An undoable command to move one or more DocItems (workpieces or groups)
    to a different layer.
    """

    def __init__(
        self,
        items: List[DocItem],
        new_layer: Layer,
        old_layer: Layer,
        name: Optional[str] = None,
    ):
        super().__init__(name)
        self.items = items
        self.new_layer = new_layer
        self.old_layer = old_layer
        if not name:
            self.name = _("Move to another layer")

    def _move(self, from_layer: Layer, to_layer: Layer):
        for item in self.items:
            to_layer.add_child(item)

    def execute(self):
        self._move(self.old_layer, self.new_layer)

    def undo(self):
        self._move(self.new_layer, self.old_layer)


class AddLayerAndSetActiveCommand(Command):
    """
    An undoable command to add a new layer and set it as the active layer.
    """

    def __init__(
        self,
        editor: "DocEditor",
        new_layer: Optional[Layer] = None,
        name: str = "Add layer",
    ):
        super().__init__(name=name)
        self._editor = editor
        self.new_layer = new_layer or self._create_default_layer()
        self._old_active_layer: Optional[Layer] = None

    def _create_default_layer(self) -> Layer:
        """Creates a new layer with a default, unique name and color."""
        # Find a unique default name for the new layer
        base_name = _("Layer")
        existing_names = {layer.name for layer in self._editor.doc.layers}
        highest_num = 0
        for name in existing_names:
            if name.startswith(base_name):
                try:
                    num_part = name[len(base_name) :].strip()
                    if num_part.isdigit():
                        highest_num = max(highest_num, int(num_part))
                except ValueError:
                    continue  # Ignore names that don't parse correctly

        new_name = f"{base_name} {highest_num + 1}"
        layer = Layer(name=new_name)

        used = {layer.color for layer in self._editor.doc.layers}
        layer.set_color(pick_unused_color(used))

        return layer

    def execute(self):
        """Adds the layer and makes it active."""
        self._old_active_layer = self._editor.doc.active_layer
        new_list = self._editor.doc.layers + [self.new_layer]
        cmd = ReorderListCommand(
            target_obj=self._editor.doc,
            list_property_name="layers",
            new_list=new_list,
            setter_method_name="set_layers",
        )
        cmd.execute()
        self._editor.doc.active_layer = self.new_layer

    def undo(self):
        """Removes the layer and restores the previous active layer."""
        new_list = [
            g for g in self._editor.doc.layers if g is not self.new_layer
        ]
        cmd = ReorderListCommand(
            target_obj=self._editor.doc,
            list_property_name="layers",
            new_list=new_list,
            setter_method_name="set_layers",
        )
        cmd.execute()
        if self._old_active_layer in self._editor.doc.layers:
            self._editor.doc.active_layer = self._old_active_layer


class LayerCmd:
    """Handles commands related to layer manipulation."""

    def __init__(self, editor: "DocEditor"):
        self._editor = editor

    def move_workpieces_to_layer(
        self, workpieces: List[WorkPiece], target_layer: Layer
    ):
        """
        Creates an undoable command to move workpieces to a specific layer.

        Args:
            workpieces: The workpieces to move.
            target_layer: The layer to move them to.
        """
        if not workpieces:
            return
        source_layer = workpieces[0].layer
        if not source_layer or source_layer is target_layer:
            return
        cmd = MoveWorkpiecesLayerCommand(
            workpieces, target_layer, source_layer
        )
        self._editor.history_manager.execute(cmd)

    def move_selected_to_adjacent_layer(
        self, surface: "WorkSurface", direction: int
    ):
        """
        Creates an undoable command to move selected workpieces to the
        next or previous valid (non-stock) layer, preserving the selection.

        Args:
            surface: The WorkSurface instance containing the selection.
            direction: 1 for the next layer (down), -1 for the previous (up).
        """
        selected_wps = surface.get_selected_workpieces()
        if not selected_wps:
            return

        doc = self._editor.doc
        workpiece_layers = list(doc.layers)

        if len(workpiece_layers) <= 1:
            # Not enough valid layers to move between.
            return

        # Assume all selected workpieces are on the same layer, which is a
        # reasonable constraint for this operation.
        current_layer = selected_wps[0].layer
        if not current_layer:
            return

        try:
            # Find the index of the current layer within the *filtered* list.
            current_index = workpiece_layers.index(current_layer)

            # Wrap around the filtered layer list.
            new_index = (
                current_index + direction + len(workpiece_layers)
            ) % len(workpiece_layers)
            new_layer = workpiece_layers[new_index]

            # 1. Create the model-only command.
            cmd = MoveWorkpiecesLayerCommand(
                selected_wps, new_layer, current_layer
            )

            # 2. Execute the command. The history manager updates the model,
            #    which triggers signals that cause the UI to destructively
            #    rebuild the moved elements in a new layer element.
            self._editor.history_manager.execute(cmd)

            # 3. After the model and UI have been updated, explicitly
            #    re-apply the selection to the newly created UI elements by
            #    telling the surface to select the same model objects again.
            surface.select_items(selected_wps)

        except ValueError:
            # This can happen if the current layer is not in the filtered list,
            # which would be an inconsistent state, but we should handle it.
            logger.warning(
                f"Layer '{current_layer.name}' not found in document's "
                "workpiece layer list."
            )

    def add_layer_and_set_active(self, new_layer: Optional[Layer] = None):
        """Adds a new layer to the document and sets it as the active layer."""
        cmd = AddLayerAndSetActiveCommand(self._editor, new_layer)
        self._editor.history_manager.execute(cmd)

    def rename_layer(self, layer: Layer, new_name: str):
        """Renames a layer with an undoable command."""
        if new_name == layer.name:
            return
        cmd = ChangePropertyCommand(
            target=layer,
            property_name="name",
            new_value=new_name,
            setter_method_name="set_name",
            name=_("Rename layer"),
        )
        self._editor.history_manager.execute(cmd)

    def set_layer_visibility(self, layer: Layer, visible: bool):
        """Sets the visibility of a layer with an undoable command."""
        if visible == layer.visible:
            return
        cmd = ChangePropertyCommand(
            target=layer,
            property_name="visible",
            new_value=visible,
            setter_method_name="set_visible",
            name=_("Toggle layer visibility"),
        )
        self._editor.history_manager.execute(cmd)

    def set_active_layer(self, layer: Layer):
        """Sets the active layer."""
        if self._editor.doc.active_layer is layer:
            return
        old_layer = self._editor.doc.active_layer
        cmd = ChangePropertyCommand(
            target=self._editor.doc,
            property_name="active_layer",
            new_value=layer,
            old_value=old_layer,
            name=_("Set active layer"),
        )
        self._editor.history_manager.execute(cmd)

    def delete_layer(self, layer: Layer):
        """Deletes a layer with an undoable command."""
        new_list = [g for g in self._editor.doc.layers if g is not layer]
        cmd = ReorderListCommand(
            target_obj=self._editor.doc,
            list_property_name="layers",
            new_list=new_list,
            setter_method_name="set_layers",
            name=_("Remove layer '{name}'").format(name=layer.name),
        )
        self._editor.history_manager.execute(cmd)

    def reorder_layers(self, new_order: List[Layer]):
        """Reorders layers with an undoable command."""
        base_name = _("Layer")
        commands: List[Command] = [
            ReorderListCommand(
                target_obj=self._editor.doc,
                list_property_name="layers",
                new_list=new_order,
                setter_method_name="set_layers",
            )
        ]
        for i, layer in enumerate(new_order):
            expected_name = f"{base_name} {i + 1}"
            if layer.name != expected_name:
                commands.append(
                    ChangePropertyCommand(
                        target=layer,
                        property_name="name",
                        new_value=expected_name,
                        setter_method_name="set_name",
                    )
                )
        cmd = CompositeCommand(commands, name=_("Reorder layers"))
        self._editor.history_manager.execute(cmd)

    def reorder_workpieces(self, layer: Layer, new_order: List[WorkPiece]):
        """Reorders workpieces within a layer with an undoable command."""
        cmd = ReorderListCommand(
            target_obj=layer,
            list_property_name="workpieces",
            new_list=new_order,
            setter_method_name="reorder_workpieces",
            name=_("Reorder workpieces"),
        )
        self._editor.history_manager.execute(cmd)

    def move_items_to_layer(self, items: List[DocItem], target_layer: Layer):
        """Creates an undoable command to move items to a specific layer."""
        if not items:
            return

        by_layer: Dict[Layer, List[DocItem]] = {}
        for item in items:
            if isinstance(item, (WorkPiece, Group)):
                layer = item.layer
            else:
                continue
            if not layer or layer is target_layer:
                continue
            by_layer.setdefault(layer, []).append(item)

        if not by_layer:
            return

        history = self._editor.history_manager
        with history.transaction(_("Move to another layer")) as t:
            for source_layer, layer_items in by_layer.items():
                cmd = MoveItemsLayerCommand(
                    layer_items, target_layer, source_layer
                )
                t.execute(cmd)

    def reorder_content_items(self, layer: Layer, new_order: List[DocItem]):
        """Reorders content items within a layer with an undoable command."""
        cmd = ReorderListCommand(
            target_obj=layer,
            list_property_name="content_items",
            new_list=new_order,
            setter_method_name="reorder_content_items",
            name=_("Reorder items"),
        )
        self._editor.history_manager.execute(cmd)
