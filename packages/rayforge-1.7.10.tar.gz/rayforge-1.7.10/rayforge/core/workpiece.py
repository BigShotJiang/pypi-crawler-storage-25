from __future__ import annotations
import logging
import cairo
from typing import (
    Generator,
    Optional,
    Tuple,
    cast,
    Dict,
    Any,
    TYPE_CHECKING,
    List,
    NamedTuple,
    Union,
)
from pathlib import Path
import warnings
from dataclasses import asdict
from copy import deepcopy
import math
import numpy as np

with warnings.catch_warnings():
    warnings.simplefilter("ignore", DeprecationWarning)
    import pyvips

from raygeo import Geometry, Rect, Point
from ..context import get_context
from .asset_registry import asset_type_registry
from .geometry_provider import IGeometryProvider
from .item import DocItem
from .matrix import Matrix
from .source_asset_segment import SourceAssetSegment
from .tab import Tab
from .vectorization_spec import TraceSpec

if TYPE_CHECKING:
    from ..image.base_renderer import Renderer, RenderSpecification
    from ..image.structures import FillRenderData
    from .asset import IAsset
    from .layer import Layer
    from .source_asset import SourceAsset


logger = logging.getLogger(__name__)

CAIRO_MAX_DIMENSION = 16384


class RenderContext(NamedTuple):
    """Encapsulates the resources required for rendering."""

    data: Union[bytes, Any]
    original_data: Optional[bytes]
    renderer: "Renderer"
    source_pixel_dims: Optional[Tuple[int, int]]
    metadata: Dict[str, Any]
    boundaries: Optional[Geometry]
    fills: Optional[List["FillRenderData"]]


class WorkPiece(DocItem):
    """
    Represents a real-world workpiece. It is a lightweight data container,
    holding its transformation matrix and a link to its source and shape
    definition.
    """

    def __init__(
        self,
        name: str,
        source_segment: Optional[SourceAssetSegment] = None,
    ):
        super().__init__(name=name)
        self._source_segment = source_segment
        self._boundaries_cache: Optional[Geometry] = None
        self._fills_cache: Optional[List["FillRenderData"]] = None

        # Natural (untransformed) dimensions of the workpiece content.
        self.natural_width_mm: float = 0.0
        self.natural_height_mm: float = 0.0

        # An optional override for the workpiece geometry. If set, this takes
        # precedence over the source_segment's geometry. It allows for
        # non-destructive editing (like splitting) without modifying the
        # shared source segment.
        self._edited_boundaries: Optional[Geometry] = None

        # The cache for rendered vips images. Key is (width, height).
        self._render_cache: Dict[Tuple[int, int], pyvips.Image] = {}

        # Transient attributes for deserialized instances in subprocesses
        self._data: Optional[bytes] = None
        self._original_data: Optional[bytes] = None
        self._renderer: Optional["Renderer"] = None
        self._transient_source_px_dims: Optional[Tuple[int, int]] = None

        self.geometry_provider_uid: Optional[str] = None
        self._geometry_provider_params: Dict[str, Any] = {}
        self._transient_geometry_provider: Optional["IGeometryProvider"] = None
        self._geometry_provider_connection: Optional[Any] = None

        self._resolved_text_cache: Dict = {}

        self.source_asset_uid: Optional[str] = None

        self._tabs: List[Tab] = []
        self._tabs_enabled: bool = True

        # Transient cache for UI view artifacts (Cairo surfaces, etc.)
        # This persists across view element destruction/creation
        # (e.g. Grouping) but is not serialized to disk.
        self._view_cache: Dict[str, Any] = {}

        # Forward compatibility: store unknown attributes
        self.extra: Dict[str, Any] = {}

    def depends_on_asset(self, asset: "IAsset") -> bool:
        """
        Checks if this workpiece depends on the given asset, either through
        its geometry provider or its source file.
        """
        if (
            self.geometry_provider_uid
            and self.geometry_provider_uid == asset.uid
        ):
            return True
        if (
            self.source_segment
            and self.source_segment.source_asset_uid == asset.uid
        ):
            return True
        return False

    @classmethod
    def from_geometry_provider(
        cls, provider: "IGeometryProvider"
    ) -> "WorkPiece":
        """
        Factory method to create a WorkPiece from an IGeometryProvider.

        This method generates geometry from the provider to determine
        its natural dimensions and initialize the WorkPiece's transformation
        matrix correctly before it is added to the document.
        """
        geometry = None
        fill_data = []
        min_x, min_y = 0.0, 0.0

        instance_cache: Dict = {}

        try:
            geometry, fill_data = provider.get_geometry(
                resolved_text_cache=instance_cache
            )

            geometry.upgrade_to_scalable()
            for fd in fill_data:
                fd.geometry.upgrade_to_scalable()

            if not geometry.is_empty():
                min_x, min_y, max_x, max_y = geometry.rect()
                width = max(max_x - min_x, 1e-9)
                height = max(max_y - min_y, 1e-9)
            else:
                width, height = 0.0, 0.0
        except Exception as e:
            logger.warning(
                f"Failed to calculate initial geometry for provider "
                f"{provider.provider_type_name}: {e}"
            )
            width, height = 0.0, 0.0

            geometry = Geometry()
            fill_data = []

        # 2. Create the instance
        instance = cls(
            name=provider.name or provider.provider_type_name.capitalize()
        )
        instance.geometry_provider_uid = provider.uid
        instance.natural_width_mm = width
        instance.natural_height_mm = height

        # 3. Set the transformation matrix scale to match natural size.
        if width > 1e-6 and height > 1e-6:
            instance.set_size(width, height)

        # 4. Pre-populate caches to avoid immediate re-solve on first render.
        # We perform the same normalization here that the boundaries property
        # does.
        if geometry and not geometry.is_empty():
            norm_matrix = Matrix.scale(
                1.0 / width, 1.0 / height
            ) @ Matrix.translation(-min_x, -min_y)
            geometry.transform(norm_matrix.to_4x4_numpy())
            for fd in fill_data:
                fd.geometry.transform(norm_matrix.to_4x4_numpy())

        # Cache the results (even if empty) to ensure fast rendering
        instance._boundaries_cache = geometry
        instance._fills_cache = fill_data
        instance._resolved_text_cache = instance_cache

        return instance

    @property
    def source_segment(self) -> Optional[SourceAssetSegment]:
        """The source data definition for this workpiece."""
        return self._source_segment

    @source_segment.setter
    def source_segment(self, new_segment: Optional[SourceAssetSegment]):
        """
        Sets a new source segment, clearing caches and signaling an update.
        This is the correct way to modify a workpiece's source data.
        """
        if self._source_segment != new_segment:
            self._source_segment = new_segment
            # Invalidate all cached data that depends on the source.
            self.clear_render_cache()
            # Signal that the workpiece's content has changed. This is crucial
            # for triggering the pipeline to re-process the geometry.
            self.updated.send(self)

    @property
    def natural_size(self) -> Tuple[float, float]:
        """
        Returns the natural (untransformed) size of the content in mm.
        This is the authoritative source for the workpiece's intrinsic size.
        """
        return (self.natural_width_mm, self.natural_height_mm)

    def get_local_bbox(self) -> Optional[Rect]:
        """
        WorkPieces are geometrically defined as a unit square (0,0,1,1) that is
        scaled by their matrix.
        """
        return (0.0, 0.0, 1.0, 1.0)

    def clear_render_cache(self):
        """
        Invalidates and clears all cached renders for this workpiece.
        Should be called if the underlying data or geometry changes.
        """
        logger.debug(
            f"WP {self.uid[:8]}: Clearing all caches (render and boundaries)."
        )
        self._render_cache.clear()
        self._boundaries_cache = None
        self._fills_cache = None

    @property
    def source(self) -> "Optional[SourceAsset]":
        """
        Convenience property to retrieve the full SourceAsset object from the
        document's central registry.
        """
        if self.doc and self.source_segment:
            return self.doc.get_source_asset_by_uid(
                self.source_segment.source_asset_uid
            )
        return None

    @property
    def original_data(self) -> Optional[bytes]:
        """
        Retrieves the original, unmodified data from the source asset.
        """
        # Prioritize transient data for isolated/subprocess instances
        if self._original_data is not None:
            return self._original_data
        source = self.source
        return source.original_data if source else None

    @property
    def data(self) -> Optional[bytes]:
        """
        Retrieves the appropriate source data for rendering.

        This property intelligently selects the correct data:
        1. Prioritizes transient data for isolated/subprocess instances.
        2. Prioritizes the `base_render_data` (e.g., a trimmed SVG or
           cropped PDF) if it exists, as this is what the workpiece's size
           is based on.
        3. Falls back to the `original_data` if no specific render data
           is available.
        """
        # Prioritize transient data for isolated/subprocess instances
        if self._data is not None:
            return self._data
        source = self.source
        if not source:
            return None

        # Prioritize the processed render data if it exists.
        if source.base_render_data is not None:
            return source.base_render_data

        # Fall back to the original data.
        return source.original_data

    @property
    def source_file(self) -> Optional[Path]:
        """
        Retrieves the source file path from the linked SourceAsset.

        For workpieces with a source_segment, this retrieves the source file
        from the segment's SourceAsset. For sketches and other workpieces
        without a source_segment, this retrieves the source file from the
        directly linked SourceAsset via source_asset_uid.
        """
        source = self.source
        if source:
            return source.source_file
        if self.source_asset_uid and self.doc:
            asset = self.doc.get_source_asset_by_uid(self.source_asset_uid)
            return asset.source_file if asset else None
        return None

    @property
    def _active_renderer(self) -> "Optional[Renderer]":
        """Retrieves the renderer (internal use)."""
        if self._renderer is not None:
            return self._renderer

        # If we have a geometry provider, use its renderer.
        provider = self.get_geometry_provider()
        if provider:
            return provider.renderer

        source = self.source
        return source.renderer if source else None

    @property
    def boundaries(self) -> Optional[Geometry]:
        """
        The normalized vector geometry defining the workpiece shape.

        This `Geometry` object represents the workpiece's intrinsic shape,
        normalized to fit within a 1x1 unit reference box. This separation of
        intrinsic shape from its world transformation is crucial for
        preventing rendering and processing errors.

        If `_edited_boundaries` is set (e.g. from a split operation), it is
        returned. Otherwise, the geometry from the `source_segment` is used.

        The local coordinate space of this normalized geometry has the
        following properties:

        - **Coordinate System**: Y-up, where (0, 0) is the bottom-left corner.
        - **Reference Size**: The geometry is scaled to fit within a box
          that is 1 unit wide by 1 unit tall.
        - **Origin (0,0)**: The anchor point is the bottom-left corner of the
          geometry's bounding box.
        - **Transformation**: The vector data itself is static. All physical
          sizing, positioning, and rotation are handled by applying the
          `WorkPiece.matrix` to this normalized shape.
        """
        logger.debug("boundaries called")
        if self._edited_boundaries is not None:
            return self._edited_boundaries

        if self._boundaries_cache is not None:
            logger.debug("Cache hit: boundaries present")
            return self._boundaries_cache
        logger.debug("Cache miss: boundaries not present")

        # --- GeometryProvider-based Geometry Generation ---
        if self.geometry_provider_uid:
            provider = self.get_geometry_provider()
            if not provider:
                return None

            logger.debug(
                f"WP {self.uid[:8]}: Getting geometry with "
                f"params: {self._geometry_provider_params}"
            )
            unnormalized_geo, unnormalized_fills = provider.get_geometry(
                self._geometry_provider_params,
                resolved_text_cache=self._resolved_text_cache,
            )

            # Upgrade all generated geometry to be fully scalable
            unnormalized_geo.upgrade_to_scalable()
            for fill_data in unnormalized_fills:
                fill_data.geometry.upgrade_to_scalable()

            # Cache the geometry even if it is empty, to prevent
            # re-solving on every render frame.
            if unnormalized_geo.is_empty():
                self._boundaries_cache = unnormalized_geo
                self._fills_cache = unnormalized_fills
                return self._boundaries_cache

            # Normalize the geometry to a 0-1 box (Y-Up) based on
            # the boundaries (strokes).
            min_x, min_y, max_x, max_y = unnormalized_geo.rect()
            width = max(max_x - min_x, 1e-9)
            height = max(max_y - min_y, 1e-9)

            # Detect natural size change and update metadata
            old_w = self.natural_width_mm
            old_h = self.natural_height_mm

            if abs(width - old_w) > 1e-5 or abs(height - old_h) > 1e-5:
                # Update natural dimensions to match the actual geometry.
                self.natural_width_mm = width
                self.natural_height_mm = height
                logger.debug(
                    f"WP {self.uid[:8]}: Natural size changed to "
                    f"{width:.2f}x{height:.2f}"
                )

            norm_matrix = Matrix.scale(
                1.0 / width, 1.0 / height
            ) @ Matrix.translation(-min_x, -min_y)

            # Apply same normalization to both strokes and fills
            unnormalized_geo.transform(norm_matrix.to_4x4_numpy())
            for fill_data in unnormalized_fills:
                fill_data.geometry.transform(norm_matrix.to_4x4_numpy())

            self._boundaries_cache = unnormalized_geo
            self._fills_cache = unnormalized_fills
            return self._boundaries_cache

        # --- SourceAssetSegment-based Geometry ---
        if not self.source_segment:
            logger.warning(
                f"WP {self.uid[:8]}: Cannot get boundaries, no source_segment."
            )
            return None

        # The authoritative path for vector imports
        if (
            self.source_segment.pristine_geometry
            and self.source_segment.normalization_matrix is not None
        ):
            # Path for UI rendering: normalize the pristine data
            norm_geo = self.source_segment.pristine_geometry.copy()
            norm_matrix = self.source_segment.normalization_matrix
            norm_geo.transform(norm_matrix.to_4x4_numpy())
            self._boundaries_cache = norm_geo
            return self._boundaries_cache

        # If there's no pristine geometry, there's nothing to show.
        logger.debug(
            f"WP {self.uid[:8]}: No pristine geometry available in segment."
        )
        return None

    @property
    def fills(self) -> Optional[List["FillRenderData"]]:
        """
        The fill geometry data for this workpiece, if any.

        Returns a list of FillRenderData objects for geometry-provider-based
        workpieces (e.g., sketches), or None for workpieces where fills are
        not tracked (images, imported SVGs).

        Accessing this property triggers boundary computation, which also
        populates the fills cache.
        """
        self.boundaries
        return self._fills_cache

    @property
    def world_space_boundaries(self) -> Optional[Geometry]:
        """
        The geometry scaled to world-space dimensions (millimeters).

        This transforms the normalized `boundaries` geometry back to
        actual physical dimensions using natural_width_mm and
        natural_height_mm.

        Returns None if boundaries is None or empty.
        """
        geo = self.boundaries
        if geo is None or geo.is_empty():
            return None
        scaled = geo.copy()
        w = self.natural_width_mm or 1.0
        h = self.natural_height_mm or 1.0
        scale_matrix = Matrix.scale(w, h)
        scaled.transform(scale_matrix.to_4x4_numpy())
        return scaled

    @property
    def _boundaries_y_down(self) -> Optional[Geometry]:
        """
        Internal helper to get the Y-DOWN normalized geometry for use in
        image masking, which operates in a Y-down pixel space.
        """
        # This property *always* derives the Y-down geometry from the
        # canonical Y-up `boundaries` property.
        y_up_geo = self.boundaries
        if not y_up_geo:
            return None

        y_down_geo = y_up_geo.copy()
        # Flip Y-up (0,0 at bottom) to Y-down (0,0 at top) in a 0-1 box
        flip_matrix = Matrix.translation(0, 1) @ Matrix.scale(1, -1)
        y_down_geo.transform(flip_matrix.to_4x4_numpy())
        return y_down_geo

    @property
    def tabs(self) -> List[Tab]:
        """The list of Tab objects for this workpiece."""
        return self._tabs

    @tabs.setter
    def tabs(self, new_tabs: List[Tab]):
        if self._tabs != new_tabs:
            self._tabs = new_tabs
            self.updated.send(self)

    @property
    def tabs_enabled(self) -> bool:
        return self._tabs_enabled

    @tabs_enabled.setter
    def tabs_enabled(self, new_value: bool):
        if self._tabs_enabled != new_value:
            self._tabs_enabled = new_value
            self.updated.send(self)

    @property
    def layer(self) -> Optional["Layer"]:
        """Traverses the hierarchy to find the parent Layer."""
        from .layer import Layer  # Local import to avoid circular dependency

        ancestor = self.get_ancestor_by_type(Layer)
        return ancestor if isinstance(ancestor, Layer) else None

    def in_world(self) -> "WorkPiece":
        """
        Returns a new, unparented WorkPiece instance whose local
        transformation matrix is the world transformation matrix of this one.
        This effectively "bakes" the parent transformations into the object,
        making it suitable for serialization or use in contexts without a
        document hierarchy. It also hydrates the instance with the necessary
        data for rendering in isolated environments like subprocesses.
        """
        # Create a new instance to avoid side effects with signals,
        # parents, etc.
        world_wp = WorkPiece(self.name, deepcopy(self.source_segment))
        world_wp.uid = self.uid
        world_wp.matrix = self.get_world_transform()
        world_wp.tabs = deepcopy(self.tabs)
        world_wp.tabs_enabled = self.tabs_enabled
        world_wp.geometry_provider_uid = self.geometry_provider_uid
        world_wp.geometry_provider_params = deepcopy(
            self._geometry_provider_params
        )
        world_wp.source_asset_uid = self.source_asset_uid
        world_wp._resolved_text_cache = dict(self._resolved_text_cache)

        # Ensure any edited boundaries are carried over.
        if self._edited_boundaries is not None:
            world_wp._edited_boundaries = self._edited_boundaries.copy()

        # Hydrate with data and renderer for use in isolated contexts
        # like subprocesses where the document link is lost.
        source = self.source
        if source:
            world_wp._data = self.data
            world_wp._original_data = self.original_data
            world_wp._renderer = source.renderer
            if source.width_px is not None and source.height_px is not None:
                world_wp._transient_source_px_dims = (
                    source.width_px,
                    source.height_px,
                )

        # Hydrate the transient geometry provider if it exists
        if self.geometry_provider_uid and self.doc:
            provider = self.doc.get_asset_by_uid(self.geometry_provider_uid)
            if provider:
                provider_dict = provider.to_dict()
                provider_type = provider_dict.get("type")
                if provider_type:
                    provider_cls = asset_type_registry.get(provider_type)
                    if provider_cls:
                        hydrated = provider_cls.from_dict(provider_dict)
                        if isinstance(hydrated, IGeometryProvider):
                            world_wp._transient_geometry_provider = hydrated

        return world_wp

    def get_geometry_provider(self) -> Optional["IGeometryProvider"]:
        """
        Retrieves the geometry provider for this workpiece, if applicable.
        Prioritizes the transient provider (subprocesses), then checks
        the document registry.
        Returns None if the provider is missing or is an UnknownAsset.
        """
        if self._transient_geometry_provider:
            return self._transient_geometry_provider
        if self.geometry_provider_uid and self.doc:
            provider = self.doc.get_asset_by_uid(self.geometry_provider_uid)
            if not isinstance(provider, IGeometryProvider):
                return None
            if provider and self._geometry_provider_connection is None:
                self._subscribe_to_geometry_provider(provider)
            return provider
        return None

    def _subscribe_to_geometry_provider(
        self, provider: "IGeometryProvider"
    ) -> None:
        """
        Subscribe to geometry provider updates.
        When the provider changes, we clear caches and emit updated.
        """
        self._geometry_provider_connection = provider.updated.connect(
            self._on_geometry_provider_updated
        )

    def _on_geometry_provider_updated(self, sender, **kwargs) -> None:
        """Handler for when the geometry provider changes."""
        self.clear_render_cache()
        self._boundaries_cache = None
        self._fills_cache = None
        self._resolved_text_cache = {}
        self.updated.send(self)

    def _resolve_render_context(self) -> Optional[RenderContext]:
        """
        Resolves the data, renderer, and metadata needed for rendering.
        Unifies logic for transient (subprocess) vs. managed (document) states.
        """
        # Calling self.boundaries here ensures that the geometry is computed
        # and cached, which populates both _boundaries_cache and _fills_cache.
        boundaries = self.boundaries
        fills = self._fills_cache

        # For geometry providers, the "data" is not needed, as the geometry
        # is generated by the `boundaries` property. We pass empty bytes.
        if self.geometry_provider_uid:
            provider = self.get_geometry_provider()
            renderer = provider.renderer if provider else None
            if not renderer:
                return None

            return RenderContext(
                data=b"",
                original_data=None,
                renderer=renderer,
                source_pixel_dims=None,
                metadata={"is_vector": True},
                boundaries=boundaries,
                fills=fills,
            )

        # --- Fallback to standard SourceAsset logic ---

        # 1. Renderer
        renderer = self._active_renderer
        if not renderer:
            return None

        # 2. Data
        data_to_render = self.data
        if data_to_render is None:
            return None

        # 3. Source Pixel Dimensions
        source_px_dims = self._transient_source_px_dims
        if not source_px_dims and self.source:
            if (
                self.source.width_px is not None
                and self.source.height_px is not None
            ):
                source_px_dims = (
                    self.source.width_px,
                    self.source.height_px,
                )

        # 4. Original Data (for cropping)
        original_data = self.original_data

        # 5. Metadata
        metadata = self.source.metadata if self.source else {}

        return RenderContext(
            data=data_to_render,
            original_data=original_data,
            renderer=renderer,
            source_pixel_dims=source_px_dims,
            metadata=metadata,
            boundaries=boundaries,
            fills=fills,
        )

    def _process_rendered_image_from_spec(
        self,
        image: pyvips.Image,
        spec: "RenderSpecification",
        target_size: Tuple[int, int],
        source_px_dims: Optional[Tuple[int, int]],
    ) -> Optional[pyvips.Image]:
        """
        Applies post-processing based on a RenderSpecification.
        """
        from ..image import util

        processed_image = image
        target_w, target_h = target_size

        # 1. Apply Crop
        if (
            spec.crop_rect
            and self.source_segment
            and self.source_segment.crop_window_px
        ):
            # Re-calculate the crop rect based on the actual rendered image
            # dimensions to handle any rounding from the renderer.
            crop_x, crop_y, crop_w, crop_h = map(
                float, self.source_segment.crop_window_px
            )
            actual_w = processed_image.width
            actual_h = processed_image.height

            scale_x = 1.0
            scale_y = 1.0
            if source_px_dims and source_px_dims[0] > 0:
                scale_x = actual_w / source_px_dims[0]
            if source_px_dims and source_px_dims[1] > 0:
                scale_y = actual_h / source_px_dims[1]

            scaled_x = int(crop_x * scale_x)
            scaled_y = int(crop_y * scale_y)
            scaled_w = int(crop_w * scale_x)
            scaled_h = int(crop_h * scale_y)

            processed_image = util.safe_crop(
                processed_image, scaled_x, scaled_y, scaled_w, scaled_h
            )
            if not processed_image:
                return None

        # 2. Apply Mask
        if spec.apply_mask:
            mask_geo = self._boundaries_y_down
            if mask_geo and not mask_geo.is_empty():
                processed_image = util.apply_mask_to_vips_image(
                    processed_image, mask_geo
                )
                if not processed_image:
                    return None

        # 3. Apply Inversion for traced imports
        if self.source_segment and self.source_segment.vectorization_spec:
            vspec = self.source_segment.vectorization_spec
            if isinstance(vspec, TraceSpec) and vspec.invert:
                bands = processed_image.bands
                if bands == 2:
                    background = [255]
                else:
                    background = [255, 255, 255]
                processed_image = processed_image.flatten(
                    background=background
                ).invert()

        # 4. Final Resize Check
        if (
            processed_image.width != target_w
            or processed_image.height != target_h
        ):
            if processed_image.width > 0 and processed_image.height > 0:
                h_scale = target_w / processed_image.width
                v_scale = target_h / processed_image.height
                processed_image = util.resize_linear(
                    processed_image, h_scale, vscale=v_scale
                )

        return processed_image

    def get_vips_image(
        self, width: int, height: int
    ) -> Optional[pyvips.Image]:
        """
        The central hub for rendering a vips image for this workpiece.
        Orchestrates data retrieval, rendering, cropping, and masking.
        """
        key = (width, height)
        if key in self._render_cache:
            return self._render_cache[key]

        # 1. Resolve Context
        ctx = self._resolve_render_context()
        if not ctx:
            logger.warning(
                f"WP {self.uid[:8]}: Could not resolve render context."
            )
            return None

        # 2. Compute Render Specification from Renderer
        spec = ctx.renderer.compute_render_spec(
            self.source_segment, (width, height), ctx
        )

        # 3. Render (with SourceAsset-level cache for shared base images)
        source = self.source
        raw_image = None

        if source is not None and not spec.kwargs:
            raw_image = source.get_cached_base_image(
                id(spec.data), spec.width, spec.height
            )

        if raw_image is None:
            raw_image = ctx.renderer.render_base_image(
                spec.data, spec.width, spec.height, **spec.kwargs
            )
            if not raw_image:
                logger.warning(f"WP {self.uid[:8]}: Renderer returned None.")
                return None
            if source is not None and not spec.kwargs:
                source.cache_base_image(
                    id(spec.data), spec.width, spec.height, raw_image
                )

        # 4. Process (Crop/Mask/Resize) based on the spec
        final_image = self._process_rendered_image_from_spec(
            raw_image, spec, (width, height), ctx.source_pixel_dims
        )

        if final_image:
            self._render_cache[key] = final_image

        return final_image

    def get_local_size(self) -> Tuple[float, float]:
        """
        The local-space size (width, height) in mm, as absolute values,
        decomposed from the local transformation matrix. This is used for
        determining rasterization resolution.
        """
        return self.matrix.get_abs_scale()

    def to_dict(self) -> Dict[str, Any]:
        """
        Serializes the WorkPiece state to a dictionary. Includes transient
        data if it has been hydrated.
        """
        state = {
            "uid": self.uid,
            "type": "workpiece",
            "name": self.name,
            "matrix": self._matrix.to_list(),
            "width_mm": self.natural_width_mm,
            "height_mm": self.natural_height_mm,
            "tabs": [asdict(t) for t in self._tabs],
            "tabs_enabled": self._tabs_enabled,
            "source_segment": (
                self.source_segment.to_dict() if self.source_segment else None
            ),
            "edited_boundaries": (
                self._edited_boundaries.to_dict()
                if self._edited_boundaries is not None
                else None
            ),
            "geometry_provider_uid": self.geometry_provider_uid,
            "geometry_provider_params": self._geometry_provider_params,
            "source_asset_uid": self.source_asset_uid,
        }
        if self._resolved_text_cache:
            cache = {
                str(k): v
                for k, v in self._resolved_text_cache.items()
                if v is not None
            }
            if cache:
                state["resolved_text_cache"] = cache
        if self._data is not None:
            state["data"] = self._data
        if self._original_data is not None:
            state["original_data"] = self._original_data
        if self._renderer is not None:
            state["renderer_name"] = self._renderer.__class__.__name__
        if self._transient_source_px_dims is not None:
            state["source_px_dims"] = self._transient_source_px_dims
        if self._transient_geometry_provider is not None:
            state["transient_geometry_provider"] = (
                self._transient_geometry_provider.to_dict()
            )
        # Include unknown attributes for forward compatibility
        state.update(self.extra)
        return state

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkPiece":
        """
        Restores a WorkPiece instance from a dictionary.
        """
        known_keys = {
            "uid",
            "type",
            "name",
            "matrix",
            "width_mm",
            "height_mm",
            "tabs",
            "tabs_enabled",
            "source_segment",
            "edited_boundaries",
            "geometry_provider_uid",
            "geometry_provider_params",
            "source_asset_uid",
            "resolved_text_cache",
            "data",
            "original_data",
            "source_px_dims",
            "renderer_name",
            "transient_geometry_provider",
            "_geometry_provider_params",
            # Legacy keys for backward compatibility
            "sketch_uid",
            "sketch_params",
            "transient_sketch_definition",
            "_sketch_params",
        }
        extra = {k: v for k, v in data.items() if k not in known_keys}

        config_data = data.get("source_segment")
        source_segment = (
            SourceAssetSegment.from_dict(config_data) if config_data else None
        )

        wp = cls(
            name=data["name"],
            source_segment=source_segment,
        )
        wp.uid = data["uid"]
        wp.matrix = Matrix.from_list(data["matrix"])
        wp.natural_width_mm = data.get("width_mm", 0.0)
        wp.natural_height_mm = data.get("height_mm", 0.0)

        loaded_tabs = [Tab(**t_data) for t_data in data.get("tabs", [])]
        wp.tabs = loaded_tabs
        wp.tabs_enabled = data.get("tabs_enabled", True)

        if "edited_boundaries" in data and data["edited_boundaries"]:
            wp._edited_boundaries = Geometry.from_dict(
                data["edited_boundaries"]
            )

        wp.geometry_provider_uid = data.get(
            "geometry_provider_uid"
        ) or data.get("sketch_uid")
        wp._geometry_provider_params = data.get(
            "geometry_provider_params", {}
        ) or data.get("sketch_params", {})
        wp.source_asset_uid = data.get("source_asset_uid")
        raw_cache = data.get("resolved_text_cache")
        if raw_cache:
            wp._resolved_text_cache = {int(k): v for k, v in raw_cache.items()}

        # Hydrate with transient data if provided for subprocesses
        if "data" in data:
            wp._data = data["data"]
        if "original_data" in data:
            wp._original_data = data["original_data"]
        if "source_px_dims" in data:
            wp._transient_source_px_dims = tuple(data["source_px_dims"])
        if "renderer_name" in data:
            renderer_name = data["renderer_name"]
            from ..image import renderer_registry

            renderer = renderer_registry.get(renderer_name)
            if renderer:
                wp._renderer = renderer

        transient_data = data.get("transient_geometry_provider") or data.get(
            "transient_sketch_definition"
        )
        if transient_data:
            provider_type = transient_data.get("type")
            if provider_type:
                provider_cls = asset_type_registry.get(provider_type)
                if provider_cls:
                    hydrated = provider_cls.from_dict(transient_data)
                    if isinstance(hydrated, IGeometryProvider):
                        wp._transient_geometry_provider = hydrated

        wp.extra = extra

        return wp

    @property
    def geometry_provider_params(self) -> Dict[str, Any]:
        """Get the geometry provider parameters for this workpiece."""
        return self._geometry_provider_params

    @geometry_provider_params.setter
    def geometry_provider_params(self, new_params: Dict[str, Any]):
        """
        Set the geometry provider parameters and trigger regeneration if
        needed.
        """
        if self._geometry_provider_params != new_params:
            self._geometry_provider_params = new_params
            if self.geometry_provider_uid:
                # Regenerate the internal geometry and natural size
                self.regenerate_from_geometry_provider()

    def get_natural_aspect_ratio(self) -> Optional[float]:
        size = self.natural_size
        if size:
            w, h = size
            if w and h and h > 0:
                return w / h
        return None

    def set_pos(self, x_mm: float, y_mm: float):
        """Legacy method, use property `pos` instead."""
        self.pos = (x_mm, y_mm)

    def set_angle(self, angle: float):
        """Legacy method, use property `angle` instead."""
        self.angle = angle

    def get_default_size(
        self, bounds_width: float, bounds_height: float
    ) -> Tuple[float, float]:
        """Calculates a sensible default size based on the content's aspect
        ratio and the provided container bounds."""
        size = self.natural_size
        if size and size[0] > 0 and size[1] > 0:
            return cast(Tuple[float, float], size)

        aspect = self.get_natural_aspect_ratio()
        if aspect is None:
            return bounds_width, bounds_height

        width_mm = bounds_width
        height_mm = width_mm / aspect
        if height_mm > bounds_height:
            height_mm = bounds_height
            width_mm = height_mm * aspect

        return width_mm, height_mm

    def render_to_pixels(
        self, width: int, height: int
    ) -> Optional[cairo.ImageSurface]:
        from ..image import util

        # This now uses the central hub for rendering.
        final_image = self.get_vips_image(width, height)
        if not final_image:
            return None
        normalized_image = util.normalize_to_rgba(final_image)
        if not normalized_image:
            return None
        return util.vips_rgba_to_cairo_surface(normalized_image)

    def render_for_ops(
        self,
        pixels_per_mm_x: float,
        pixels_per_mm_y: float,
    ) -> Optional[cairo.ImageSurface]:
        """Renders to a pixel surface at the workpiece's current size.
        Returns None if size is not valid."""
        # Use the final world-space size for rendering resolution.
        current_size = self.size
        if not current_size or current_size[0] <= 0 or current_size[1] <= 0:
            return None

        width_mm, height_mm = current_size
        target_width_px = int(width_mm * pixels_per_mm_x)
        target_height_px = int(height_mm * pixels_per_mm_y)

        return self.render_to_pixels(target_width_px, target_height_px)

    def _calculate_chunk_layout(
        self,
        real_width: int,
        real_height: int,
        max_chunk_width: Optional[int],
        max_chunk_height: Optional[int],
        max_memory_size: Optional[int],
    ) -> Tuple[int, int, int, int]:
        bytes_per_pixel = 4
        effective_max_width = min(
            max_chunk_width
            if max_chunk_width is not None
            else CAIRO_MAX_DIMENSION,
            CAIRO_MAX_DIMENSION,
        )
        chunk_width = min(real_width, effective_max_width)
        possible_heights = []
        effective_max_height = min(
            max_chunk_height
            if max_chunk_height is not None
            else CAIRO_MAX_DIMENSION,
            CAIRO_MAX_DIMENSION,
        )
        possible_heights.append(effective_max_height)
        if max_memory_size is not None and chunk_width > 0:
            height_from_mem = math.floor(
                max_memory_size / (chunk_width * bytes_per_pixel)
            )
            possible_heights.append(height_from_mem)
        chunk_height = min(real_height, *possible_heights)
        chunk_width = max(1, chunk_width)
        chunk_height = max(1, chunk_height)
        cols = math.ceil(real_width / chunk_width)
        rows = math.ceil(real_height / chunk_height)
        return chunk_width, cols, chunk_height, rows

    def render_chunk(
        self,
        pixels_per_mm_x: float,
        pixels_per_mm_y: float,
        max_chunk_width: Optional[int] = None,
        max_chunk_height: Optional[int] = None,
        max_memory_size: Optional[int] = None,
    ) -> Generator[Tuple[cairo.ImageSurface, Tuple[float, float]], None, None]:
        """Renders in chunks at the workpiece's current size.
        Yields nothing if size is not valid."""
        from ..image import util

        # Use the final world-space size for rendering resolution.
        current_size = self.size
        if not current_size or current_size[0] <= 0 or current_size[1] <= 0:
            return

        width_px = current_size[0] * pixels_per_mm_x
        height_px = current_size[1] * pixels_per_mm_y

        if all(
            arg is None
            for arg in [max_chunk_width, max_chunk_height, max_memory_size]
        ):
            raise ValueError(
                "At least one of max_chunk_width, max_chunk_height, "
                "or max_memory_size must be provided."
            )

        vips_image = self.get_vips_image(round(width_px), round(height_px))
        if not vips_image or not isinstance(vips_image, pyvips.Image):
            logger.warning("Failed to load image for chunking.")
            return

        real_width = cast(int, vips_image.width)
        real_height = cast(int, vips_image.height)
        if not real_width or not real_height:
            return

        chunk_width, cols, chunk_height, rows = self._calculate_chunk_layout(
            real_width,
            real_height,
            max_chunk_width,
            max_chunk_height,
            max_memory_size,
        )

        overlap_x, overlap_y = 1, 0  # Default overlap values

        for row in range(rows):
            for col in range(cols):
                left = col * chunk_width
                top = row * chunk_height
                width = min(chunk_width + overlap_x, real_width - left)
                height = min(chunk_height + overlap_y, real_height - top)

                if width <= 0 or height <= 0:
                    continue

                chunk: pyvips.Image = vips_image.crop(left, top, width, height)

                normalized_chunk = util.normalize_to_rgba(chunk)
                if not normalized_chunk:
                    logger.warning(
                        f"Could not normalize chunk at ({left},{top})"
                    )
                    continue

                surface = util.vips_rgba_to_cairo_surface(normalized_chunk)
                yield surface, (left, top)

    def get_geometry_world_bbox(
        self,
    ) -> Optional[Rect]:
        """
        Calculates the bounding box of the workpiece's geometry in world
        coordinates.

        This is achieved by creating a temporary copy of the geometry,
        transforming it by the workpiece's world matrix, and then calculating
        the bounding box of the transformed shape.

        Returns:
            A tuple (min_x, min_y, max_x, max_y) representing the bounding
            box, or None if the workpiece has no vector geometry.
        """
        boundaries = self.boundaries
        if boundaries is None or boundaries.is_empty():
            return None

        # Create a copy to avoid modifying the original normalized vectors
        world_geometry = boundaries.copy()

        # Apply the full world transformation
        world_matrix = self.get_world_transform()
        world_geometry.transform(world_matrix.to_4x4_numpy())

        # Return the bounding box of the transformed geometry
        return world_geometry.rect()

    def get_world_geometry(self) -> Optional["Geometry"]:
        """
        Returns the final, world-space geometry of the workpiece in
        millimeters.
        This is the definitive geometry for pipeline processing, composing all
        transformations (normalization, local, and parent) before applying
        them to the pristine source geometry.
        """
        # --- Path for direct vector imports (SVG, DXF, etc.) ---
        if (
            self.source_segment
            and self.source_segment.pristine_geometry
            and self.source_segment.normalization_matrix is not None
        ):
            pristine_geo = self.source_segment.pristine_geometry.copy()
            norm_matrix = self.source_segment.normalization_matrix
            world_transform = self.get_world_transform()

            # The key insight: compose all matrices BEFORE transforming
            # geometry
            final_transform = world_transform @ norm_matrix
            pristine_geo.transform(final_transform.to_4x4_numpy())
            return pristine_geo

        # --- Path for generated geometry (e.g., sketches) ---
        # This path uses the `boundaries` property which returns a
        # normalized 1x1 geometry.
        boundaries = self.boundaries
        if boundaries and not boundaries.is_empty():
            world_geo = boundaries.copy()
            world_transform = self.get_world_transform()
            world_geo.transform(world_transform.to_4x4_numpy())
            return world_geo

        return None

    def get_tab_direction(self, tab: Tab) -> Optional[Tuple[float, float]]:
        """
        Calculates the "outside" direction vector for a given tab in world
        coordinates.

        The direction is a normalized 2D vector representing the outward
        normal of the geometry at the tab's location, transformed by the
        workpiece's rotation and scaling.

        Args:
            tab: The Tab object for which to find the direction.

        Returns:
            A tuple (dx, dy) representing the direction vector, or None if
            the workpiece has no vector data or the path is open.
        """
        boundaries = self.boundaries
        if boundaries is None:
            return None

        # 1. Get the normal vector in the geometry's local space.
        local_normal = boundaries.get_outward_normal_at(
            tab.segment_index, tab.pos
        )
        if local_normal is None:
            return None

        # For non-uniform scaling, the normal must be transformed by the
        # inverse transpose of the world matrix to remain perpendicular.
        world_matrix_3x3 = self.get_world_transform().to_numpy()
        try:
            # Get the top-left 2x2 part for the normal transformation
            m_2x2 = world_matrix_3x3[:2, :2]
            m_inv_T = np.linalg.inv(m_2x2).T
            transformed_vector = m_inv_T @ np.array(local_normal)
        except np.linalg.LinAlgError:
            # Fallback for non-invertible matrices (e.g., zero scale)
            return self.get_world_transform().transform_vector(local_normal)

        tx, ty = transformed_vector
        norm = math.sqrt(tx**2 + ty**2)
        if norm < 1e-9:
            return (1.0, 0.0)  # Fallback

        return (tx / norm, ty / norm)

    def dump(self, indent=0):
        source_file = self.source_file
        renderer = self._active_renderer
        renderer_name = renderer.__class__.__name__ if renderer else "None"
        print("  " * indent, source_file, renderer_name)

    @property
    def pos_machine(self) -> Optional[Point]:
        """
        Gets the workpiece's anchor position in the machine's native
        coordinate system.
        """
        if not self.pos or not self.size:
            return None

        context = get_context()
        if not context.config or not context.machine:
            return None

        machine = context.machine
        model_x, model_y = self.pos
        width, height = self.size
        mach_w, mach_h = machine.axis_extents

        # Calculate Machine X
        machine_x = (
            (mach_w - model_x - width) if machine.x_axis_right else model_x
        )

        # Calculate Machine Y
        machine_y = (
            (mach_h - model_y - height) if machine.y_axis_down else model_y
        )

        return machine_x, machine_y

    @pos_machine.setter
    def pos_machine(self, pos: Point):
        """
        Sets the workpiece's position from the machine's native
        coordinate system.
        """
        if not pos or not self.size:
            return

        context = get_context()
        if not context.config or not context.machine:
            return

        machine = context.machine
        machine_x, machine_y = pos
        width, height = self.size
        mach_w, mach_h = machine.axis_extents

        # Handle X Axis
        if machine.x_axis_right:
            model_x = mach_w - machine_x - width
        else:
            model_x = machine_x

        # Handle Y Axis
        if machine.y_axis_down:
            model_y = mach_h - machine_y - height
        else:
            model_y = machine_y

        self.pos = (model_x, model_y)

    def apply_split(self, fragments: List[Geometry]) -> List["WorkPiece"]:
        """
        Creates new WorkPiece instances from a list of normalized geometry
        fragments. Each fragment represents a subset of this workpiece's
        current geometry.

        The new workpieces inherit the source segment but override their
        geometry with the specific fragment.

        Args:
            fragments: A list of Geometry objects. Each must be a subset of
                       self.boundaries, defined in the same 0-1 Y-up
                       normalized coordinate space.

        Returns:
            A list of new WorkPiece instances.
        """
        if not fragments or len(fragments) <= 1:
            return []

        new_workpieces = []
        original_matrix = self.matrix
        source = self.source

        # Get current physical dimensions to filter noise.
        phys_w, phys_h = self.size

        for frag_geo in fragments:
            # 1. Calculate bounding box of the fragment in the local 0-1 space.
            min_x, min_y, max_x, max_y = frag_geo.rect()
            w = max(max_x - min_x, 1e-9)
            h = max(max_y - min_y, 1e-9)

            # 2. Filter out noise / dust.
            if (w * phys_w < 0.1) and (h * phys_h < 0.1):
                continue

            # 3. Normalize the fragment geometry to its own 1x1 box.
            # This becomes the new canonical shape for this piece.
            normalized_frag = frag_geo.copy()
            norm_matrix = Matrix.scale(1.0 / w, 1.0 / h) @ Matrix.translation(
                -min_x, -min_y
            )
            normalized_frag.transform(norm_matrix.to_4x4_numpy())

            # 4. Create a lightweight copy of the segment
            #    containing only metadata.
            # This avoids the expensive deepcopy of the large
            # pristine_geometry.
            new_segment = None
            if self.source_segment:
                # Manually construct a new segment instead of deepcopying.
                # We explicitly set pristine_geometry to None because the new
                # workpiece will use _edited_boundaries for its shape.
                mtx = self.source_segment.normalization_matrix
                new_segment = SourceAssetSegment(
                    source_asset_uid=self.source_segment.source_asset_uid,
                    vectorization_spec=self.source_segment.vectorization_spec,
                    layer_id=self.source_segment.layer_id,
                    pristine_geometry=None,  # Prevents massive array copy
                    normalization_matrix=mtx,
                    crop_window_px=self.source_segment.crop_window_px,
                )

            new_wp = WorkPiece(self.name, new_segment)
            new_wp.tabs_enabled = self.tabs_enabled

            # 5. Set the edited_boundaries override. This gives the workpiece
            # its final, correct, Y-Up geometry directly.
            new_wp._edited_boundaries = normalized_frag

            # 6. Update the new segment's crop window to match the fragment.
            # This ensures the renderer draws the correct background portion.
            if new_segment and source and self.source_segment:
                parent_crop = self.source_segment.crop_window_px
                pc_x, pc_y, pc_w, pc_h = 0, 0, 0, 0

                if parent_crop:
                    pc_x, pc_y, pc_w, pc_h = parent_crop
                elif source.width_px and source.height_px:
                    pc_x, pc_y, pc_w, pc_h = (
                        0,
                        0,
                        source.width_px,
                        source.height_px,
                    )

                # Calculate new crop window relative to the parent's.
                # The geometry is Y-Up (0 at bottom), but the pixel crop window
                # is Y-Down (0 at top), so we must invert the Y calculation.
                new_crop_x_px = pc_x + (min_x * pc_w)
                new_crop_y_px = pc_y + ((1 - max_y) * pc_h)
                new_crop_w_px = w * pc_w
                new_crop_h_px = h * pc_h

                new_segment.crop_window_px = (
                    new_crop_x_px,
                    new_crop_y_px,
                    new_crop_w_px,
                    new_crop_h_px,
                )
                new_segment.cropped_width_mm = w * phys_w
                new_segment.cropped_height_mm = h * phys_h

            # 7. Set natural size and calculate the matrix for the new piece.
            new_wp.natural_width_mm = w * phys_w
            new_wp.natural_height_mm = h * phys_h

            # The new matrix must position and scale the new 1x1 workpiece
            # to match where the fragment was in the original object.
            offset_matrix = original_matrix @ Matrix.translation(min_x, min_y)
            final_matrix = offset_matrix @ Matrix.scale(w, h)

            new_wp.matrix = final_matrix
            new_workpieces.append(new_wp)

        return new_workpieces

    def regenerate_from_geometry_provider(self) -> None:
        """
        Regenerates the workpiece from its geometry provider.

        This method:
        1. Fetches the geometry provider.
        2. Gets geometry with instance-specific parameter overrides.
        3. Calculates the new natural size from the geometry.
        4. Updates the instance's `natural_width/height_mm`.
        5. It resizes the on-canvas item.
        6. Invalidates caches and signals the UI to redraw.
        """
        if not self.geometry_provider_uid:
            logger.warning(
                f"WP {self.uid[:8]}: No geometry_provider_uid to "
                f"regenerate from"
            )
            return

        provider = self.get_geometry_provider()
        if not provider:
            logger.warning(
                f"WP {self.uid[:8]}: Could not find geometry provider "
                f"{self.geometry_provider_uid}"
            )
            return

        logger.debug(
            f"WP {self.uid[:8]}: Regenerating from geometry provider "
            f"{self.geometry_provider_uid[:8]}"
        )

        # Get geometry with current parameter overrides.
        variable_overrides = self._geometry_provider_params or {}
        logger.debug(
            f"WP {self.uid[:8]}: Getting geometry with params: "
            f"{variable_overrides}"
        )
        self._resolved_text_cache = {}
        geometry, _ = provider.get_geometry(
            params=variable_overrides,
            resolved_text_cache=self._resolved_text_cache,
        )

        if geometry.is_empty():
            logger.warning(
                f"WP {self.uid[:8]}: Geometry is empty. "
                "Natural size not updated."
            )
        else:
            # Calculate bounding box in mm
            min_x, min_y, max_x, max_y = geometry.rect()
            width = max(max_x - min_x, 1e-9)  # Prevent zero size
            height = max(max_y - min_y, 1e-9)  # Prevent zero size

            self.natural_width_mm = width
            self.natural_height_mm = height

            logger.debug(
                f"WP {self.uid[:8]}: New natural size: "
                f"{width:.2f}x{height:.2f}mm"
            )
            # Update the workpiece's actual size to match its new natural size.
            self.set_size(width, height)

        # Invalidate the geometry cache to force regeneration on next render
        self.clear_render_cache()

        # Send updated signal to trigger UI updates
        self.updated.send(self)
