"""Shared utility functions for platform CLI commands."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from osmosis_ai.cli.console import Console, console
from osmosis_ai.cli.errors import CLIError
from osmosis_ai.cli.output.display import format_local_datetime
from osmosis_ai.platform.api.models import (
    RUN_STATUSES_ERROR,
    RUN_STATUSES_IN_PROGRESS,
    RUN_STATUSES_STOPPED,
    RUN_STATUSES_SUCCESS,
    STATUSES_ERROR,
    STATUSES_IN_PROGRESS,
    STATUSES_SUCCESS,
)
from osmosis_ai.platform.auth import (
    AuthenticationExpiredError,
    load_credentials,
)
from osmosis_ai.platform.cli.workspace_directory_context import (
    GitWorkspaceDirectoryContext,
    LocalWorkspaceDirectoryContext,
    resolve_git_workspace_directory_context,
    resolve_local_workspace_directory_context,
)
from osmosis_ai.platform.constants import DEFAULT_PAGE_SIZE

if TYPE_CHECKING:
    from osmosis_ai.platform.auth.credentials import Credentials


def platform_call[T](
    message: str,
    call: Callable[[], T],
    *,
    output_console: Console | None = None,
) -> T:
    """Run a platform request while showing a consistent CLI loading status."""
    status_console = output_console or console
    with status_console.spinner(message):
        return call()


def require_credentials() -> Credentials:
    """Load valid credentials, raising if not available or expired."""
    from osmosis_ai.platform.constants import MSG_NOT_LOGGED_IN

    credentials = load_credentials()
    if credentials is None:
        raise CLIError(MSG_NOT_LOGGED_IN)
    if credentials.is_expired():
        raise AuthenticationExpiredError()
    return credentials


def require_git_workspace_directory_context() -> GitWorkspaceDirectoryContext:
    """Resolve the current Git-scoped Osmosis workspace directory for platform commands."""
    return resolve_git_workspace_directory_context()


def require_local_workspace_directory_context(
    *, require_scaffold: bool = True
) -> LocalWorkspaceDirectoryContext:
    """Resolve the current Git workspace directory for local-only commands."""
    return resolve_local_workspace_directory_context(require_scaffold=require_scaffold)


def format_dataset_status(d: Any, *, for_prompt: bool = False) -> str:
    """Format a dataset status string with optional color styling.

    When *for_prompt* is True, returns a plain text string suitable for
    interactive prompt choices.
    """
    status_info = f"[{d.status}]"
    if for_prompt:
        return status_info
    color = entity_status_style(d.status)
    if color:
        return console.format_styled(status_info, color)
    return console.escape(status_info)


def entity_status_style(status: str) -> str | None:
    """Return the Rich style name for a dataset/model status, or None if unstyled."""
    if status in STATUSES_SUCCESS:
        return "green"
    if status in STATUSES_IN_PROGRESS:
        return "yellow"
    if status in STATUSES_ERROR:
        return "red"
    return None


def run_status_style(status: str) -> str | None:
    """Return the Rich style name for a training run status, or None if unstyled."""
    if status in RUN_STATUSES_SUCCESS:
        return "green"
    if status in RUN_STATUSES_IN_PROGRESS:
        return "yellow"
    if status in RUN_STATUSES_ERROR:
        return "red"
    if status in RUN_STATUSES_STOPPED:
        return "dim"
    return None


def format_run_status(r: Any, *, for_prompt: bool = False) -> str:
    """Format a training run status string with optional color styling.

    When *for_prompt* is True, returns a plain text string suitable for
    interactive prompt choices.
    """
    status_info = f"[{r.status}]"

    if for_prompt:
        return status_info

    style = run_status_style(r.status)
    if style:
        return console.format_styled(status_info, style)
    return console.escape(status_info)


def format_date(iso_str: str | None) -> str:
    """Extract YYYY-MM-DD from an ISO 8601 string, or return '' if empty."""
    if not iso_str:
        return ""
    return iso_str[:10]


def format_dim_date(iso_str: str | None) -> str:
    """Format a date as dim-styled text for list displays, or '' if empty."""
    if not iso_str:
        return ""
    return console.format_styled(format_date(iso_str), "dim")


def build_dataset_detail_rows(ds: Any) -> list[tuple[str, str]]:
    """Build common detail rows for a dataset."""
    rows: list[tuple[str, str]] = [
        ("File", console.escape(ds.file_name)),
        ("ID", ds.id),
        ("Status", ds.status.replace("_", " ").title()),
    ]
    file_format = getattr(ds, "file_format", None)
    original_format = getattr(ds, "original_file_format", None)
    if file_format:
        fmt = file_format.upper()
        if original_format and original_format != file_format:
            fmt += f" (uploaded as {original_format.upper()})"
        rows.append(("File Format", fmt))
    if getattr(ds, "row_count", None) is not None:
        rows.append(("Total Rows", f"{ds.row_count:,}"))
    size_str = format_size(ds.file_size)
    original_size = getattr(ds, "original_file_size", None)
    if original_size:
        size_str += f" (uncompressed: {format_size(original_size)})"
    rows.append(("Size", size_str))
    if ds.created_at:
        rows.append(("Uploaded", format_local_datetime(ds.created_at)))
    if getattr(ds, "creator_name", None):
        rows.append(("Uploaded By", console.escape(ds.creator_name)))
    return rows


def build_run_detail_rows(r: Any) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = [
        ("Name", console.escape(r.name) if r.name else "(unnamed)"),
        ("ID", r.id),
        ("Status", r.status.replace("_", " ").title()),
    ]
    if r.created_at:
        rows.append(("Submitted", format_local_datetime(r.created_at)))
    if r.creator_name:
        rows.append(("Submitted By", console.escape(r.creator_name)))
    rows.append(("Dataset", console.escape(r.dataset_name) if r.dataset_name else "—"))
    rows.append(("Base Model", console.escape(r.model_name) if r.model_name else "—"))
    rows.append(("Rollout", console.escape(r.rollout_name) if r.rollout_name else "—"))
    return rows


def format_size(size_bytes: int | float) -> str:
    """Format file size as human-readable string."""
    for unit in ("B", "KB", "MB", "GB"):
        if size_bytes < 1024:
            return (
                f"{size_bytes:.1f} {unit}"
                if unit != "B"
                else f"{int(size_bytes)} {unit}"
            )
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def fetch_all_pages(
    fetch_fn: Callable[[int, int], Any],
    *,
    items_attr: str,
    page_size: int = DEFAULT_PAGE_SIZE,
) -> tuple[list[Any], int]:
    """Iterate through API pages using server-provided ``next_offset``.

    *fetch_fn(limit, offset)* must return an object with a ``next_offset``
    (int | None), a ``total_count`` int, and an attribute named *items_attr*
    (a list).

    Returns ``(all_items, total_count)``.
    """
    all_items: list[Any] = []
    offset = 0
    total_count = 0
    while True:
        result = fetch_fn(page_size, offset)
        items = getattr(result, items_attr)
        all_items.extend(items)
        total_count = result.total_count
        if result.next_offset is None or not items:
            break
        offset = result.next_offset
    return all_items, total_count


def paginated_fetch(
    fetch_fn: Callable[[int, int], Any],
    *,
    items_attr: str,
    limit: int,
    fetch_all: bool,
) -> tuple[list[Any], int, bool]:
    """Fetch items from a paginated API, respecting ``--all`` / ``--limit``.

    When *fetch_all* is True, exhaustively paginates via :func:`fetch_all_pages`.
    Otherwise, issues a single request with the given *limit*.

    Returns ``(items, total_count, has_more)``.
    """
    if fetch_all:
        items, total_count = fetch_all_pages(fetch_fn, items_attr=items_attr)
        return items, total_count, False
    result = fetch_fn(limit, 0)
    return getattr(result, items_attr), result.total_count, result.has_more


def print_pagination_footer(shown: int, total: int, entity_name: str) -> None:
    """Print a dim hint when a list command truncated its output."""
    if shown >= total:
        return
    console.print(
        f"\nShowing {shown} of {total} {entity_name}."
        " Use --all to show all, or --limit to adjust.",
        style="dim",
    )


def validate_list_options(
    *,
    limit: int,
    all_: bool,
) -> tuple[int, bool]:
    """Validate mutual exclusion between ``--all`` and ``--limit``.

    Returns ``(limit, fetch_all)`` on success, or raises :class:`CLIError`.
    """
    if all_ and limit != DEFAULT_PAGE_SIZE:
        raise CLIError("--all and --limit are mutually exclusive.")
    return limit, all_
