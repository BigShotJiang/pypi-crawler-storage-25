from __future__ import annotations

import asyncio
import contextlib
import os
import signal
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import httpx

USER_SERVER_PORT = 8000


def build_user_server_command(entrypoint: str) -> list[str]:
    return ["uv", "run", "python", entrypoint]


def build_user_server_env(
    *,
    workspace_directory: Path,
    rollout_dir: Path,
    rollout_name: str,
    entrypoint: str,
    invocation_id: str,
) -> dict[str, str]:
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH")
    path_parts = [str(rollout_dir), str(workspace_directory)]
    if existing_pythonpath:
        path_parts.append(existing_pythonpath)
    env.update(
        {
            "_OSMOSIS_ENTRYPOINT_SCRIPT": entrypoint,
            "_OSMOSIS_REPOSITORY_PATH": str(rollout_dir),
            "_OSMOSIS_TRAINING_RUN_ID": invocation_id,
            "_OSMOSIS_ROLLOUT_NAME": rollout_name,
            "_OSMOSIS_ROLLOUT_PORT": str(USER_SERVER_PORT),
            "PYTHONPATH": os.pathsep.join(path_parts),
        }
    )
    return env


@dataclass
class UserServerProcess:
    process: asyncio.subprocess.Process
    log_path: Path

    async def terminate(self, *, grace_sec: float = 5.0) -> None:
        if self.process.returncode is not None:
            return
        try:
            if sys.platform != "win32":
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(self.process.pid, signal.SIGTERM)
            else:
                with contextlib.suppress(ProcessLookupError):
                    self.process.terminate()
            await asyncio.wait_for(self.process.wait(), timeout=grace_sec)
        except TimeoutError:
            if sys.platform != "win32":
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(self.process.pid, signal.SIGKILL)
            else:
                with contextlib.suppress(ProcessLookupError):
                    self.process.kill()
            await self.process.wait()


def _user_server_returncode(
    process: UserServerProcess | asyncio.subprocess.Process | object,
) -> int | None:
    raw_process = process.process if isinstance(process, UserServerProcess) else process
    return getattr(raw_process, "returncode", None)


def _raise_if_user_server_exited(
    process: UserServerProcess | asyncio.subprocess.Process | None,
) -> None:
    if process is None:
        return
    returncode = _user_server_returncode(process)
    if returncode is None:
        return

    message = (
        "User rollout server exited before becoming healthy on "
        f"127.0.0.1:{USER_SERVER_PORT} (exit code {returncode})."
    )
    if isinstance(process, UserServerProcess):
        message += f" See log: {process.log_path}"
    raise RuntimeError(message)


async def start_user_server_process(
    *,
    workspace_directory: Path,
    rollout_dir: Path,
    rollout_name: str,
    entrypoint: str,
    invocation_id: str,
    log_dir: Path,
) -> UserServerProcess:
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"user-server-{invocation_id}.log"
    kwargs = {}
    if sys.platform != "win32":
        kwargs["start_new_session"] = True

    log_file = log_path.open("ab")
    try:
        process = await asyncio.create_subprocess_exec(
            *build_user_server_command(entrypoint),
            cwd=rollout_dir,
            env=build_user_server_env(
                workspace_directory=workspace_directory,
                rollout_dir=rollout_dir,
                rollout_name=rollout_name,
                entrypoint=entrypoint,
                invocation_id=invocation_id,
            ),
            stdout=log_file,
            stderr=asyncio.subprocess.STDOUT,
            **kwargs,
        )
    except Exception:
        log_file.close()
        raise
    else:
        log_file.close()
    return UserServerProcess(process=process, log_path=log_path)


async def wait_for_user_server_health(
    *,
    timeout_sec: float = 30.0,
    process: UserServerProcess | asyncio.subprocess.Process | None = None,
) -> None:
    deadline = time.monotonic() + timeout_sec
    last_error: Exception | None = None
    async with httpx.AsyncClient() as client:
        while time.monotonic() < deadline:
            _raise_if_user_server_exited(process)
            try:
                response = await client.get(
                    f"http://127.0.0.1:{USER_SERVER_PORT}/health",
                    timeout=0.5,
                )
            except Exception as exc:
                last_error = exc
            else:
                if response.status_code == 200:
                    _raise_if_user_server_exited(process)
                    return
            await asyncio.sleep(0.1)
    raise TimeoutError(
        "User rollout server did not become healthy on "
        f"127.0.0.1:{USER_SERVER_PORT} within {timeout_sec:.1f}s: {last_error}"
    )


__all__ = [
    "USER_SERVER_PORT",
    "UserServerProcess",
    "build_user_server_command",
    "build_user_server_env",
    "start_user_server_process",
    "wait_for_user_server_health",
]
