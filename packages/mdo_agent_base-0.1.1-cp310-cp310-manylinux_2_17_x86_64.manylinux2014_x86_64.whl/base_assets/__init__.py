# Shared base assets for compiled mdo_agent_base skills.
