#!/bin/bash
#SBATCH --time=1:00:00               # walltime limit (HH:MM:SS)
#SBATCH --nodes=1                    # number of nodes
#SBATCH --ntasks-per-node=36         # core(s)(CPU cores) per node
#SBATCH --job-name="myJob"           # job name
#SBATCH --output="log-%j.txt"        # job standard output file (%j replaced by job id)
#SBATCH --constraint=intel           # intel nodes

./Allrun.sh
