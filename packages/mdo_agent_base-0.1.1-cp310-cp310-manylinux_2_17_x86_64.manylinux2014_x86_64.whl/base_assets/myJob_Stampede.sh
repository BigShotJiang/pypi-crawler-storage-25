#!/bin/bash
#SBATCH -A TG-ATM140019       # project ID
#SBATCH -J myJob              # job name
#SBATCH -o log-%j.txt         # output and error file name (%j expands to jobID)
#SBATCH -n 48                 # total number of mpi tasks requested
#SBATCH -N 1                  # total number of nodes
#SBATCH -p skx-dev            # queue (partition) -- normal, development, etc.
#SBATCH -t 2:00:00            # run time (hh:mm:ss)
#SBATCH --mail-type=ALL       # setup email alert
#SBATCH --mail-user=xxx@gmail.com

# Set up the environment to avoid MPI seg fault on the HPC. DO NOT delete this line
export PSM2_MULTI_EP=0

./Allrun.sh
