from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class SQLException(Exception):
    """Base exception for all Ocient exceptions.

    Attributes:

    - sql_state: The SQLSTATE defined in the SQL standard
    - reason: A string description of the exception
    - vendor_code: An Ocient specific error code
    """

    reason: str = "The operation completed successfully"
    sql_state: str = "00000"
    vendor_code: int = 0

    def __str__(self) -> str:
        return f"State: {self.sql_state} Code: {self.vendor_code} Reason: {self.reason}"


#########################################################################
# Database API 2.0 exceptions.  These are required by PEM 249
#########################################################################


class Error(SQLException):
    """Exception that is the base class of all other error exceptions."""

    def __init__(self, reason: str, sql_state: str = "58005", vendor_code: int = -100) -> None:
        super().__init__(reason, sql_state=sql_state, vendor_code=vendor_code)


class Warning(SQLException, UserWarning):  # pylint: disable=redefined-builtin
    """Exception that is the base class of all other warning exceptions."""


class InterfaceError(Error):
    """Exception raised for errors that are related to the
    database interface rather than the database itself.
    """


class DatabaseError(Error):
    """Exception raised for errors that are related to the database."""


class InternalError(DatabaseError):
    """Exception raised when the database encounters an internal error,
    e.g. the cursor is not valid anymore
    """


class OperationalError(DatabaseError):
    """Exception raised for errors that are related to the database's
    operation and not necessarily under the control of the programmer,
    e.g. an unexpected disconnect occurs, the data source name is not found.
    """


class ProgrammingError(DatabaseError):
    """Exception raised for programming errors, e.g. table not found,
    syntax error in the SQL statement, wrong number of parameters
    specified, etc.
    """


class IntegrityError(DatabaseError):
    """Exception raised when the relational integrity of the database
    is affected, e.g. a foreign key check fails
    """


class DataError(DatabaseError):
    """Exception raised for errors that are due to problems with the
    processed data like division by zero, numeric value out of range, etc.
    """


class NotSupportedError(DatabaseError):
    """Exception raised in case a method or database API was used which is not
    supported by the database
    """


class MalformedURL(DatabaseError):
    """Exception raised in case a malformed DSN is received"""

    def __init__(self, reason: str) -> None:
        super().__init__(sql_state="08001", vendor_code=-200, reason=reason)


class SSORedirection(Exception):
    """Exception raised when SSO redirection is required

    It contains the URL from which to request authentication
    The response will redirect back to the sso_redirect_url, and
    will contain `code` and `state` fields, which in turn should be

    passed back into a new connect call as the sso_code and sso_state
    paramters.
    """

    def __init__(self, authURL: str, state: Dict[Any, Any], use_ssl: bool = False):  # type: ignore [explicit-any]
        self.authURL = authURL
        self.state = state
        self.use_ssl = use_ssl
