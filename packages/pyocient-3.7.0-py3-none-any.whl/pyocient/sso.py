# SSO related functions for pyocient
# mypy: disallow_any_explicit=false
import base64
import ipaddress
import json
import logging
import ssl
import tempfile
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from textwrap import dedent
from time import monotonic, sleep
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlencode, urlparse

import pkce
import requests

import pyocient.ocient_protocol_pb2 as proto
from pyocient import api

logger = logging.getLogger(__name__)

# when we are handing an SSO authenticaction flow callback,
# this is the path and port we listen on.  This is consistent
# with JDBC.  We only open this port for the duration of the
# authentication flow
LOCAL_SSO_CALLBACK_PATH = "/ocient/oauth2/v1/callback"
LOCAL_SSO_CALLBACK_PORT = 7050


def sso_local_callback_url(use_ssl: bool = False) -> str:
    protocol = "https" if use_ssl else "http"
    return f"{protocol}://127.0.0.1:{LOCAL_SSO_CALLBACK_PORT}{LOCAL_SSO_CALLBACK_PATH}"


def _generate_self_signed_cert() -> Tuple[bytes, bytes]:
    """
    Generate a self-signed certificate for localhost.
    Returns a tuple of (cert_pem_bytes, key_pem_bytes).
    """
    try:
        import datetime

        from cryptography import x509
        from cryptography.hazmat.backends import default_backend
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
    except ImportError:
        raise api.Error("SSL callback requires 'cryptography' package. Install with: pip install cryptography")

    # Generate private key
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())

    # Create certificate
    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "CA"),
            x509.NameAttribute(NameOID.LOCALITY_NAME, "Local"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Ocient"),
            x509.NameAttribute(NameOID.COMMON_NAME, "localhost"),
        ]
    )

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.utcnow())
        .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=1))
        .add_extension(
            x509.SubjectAlternativeName(
                [
                    x509.DNSName("localhost"),
                    x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
                ]
            ),
            critical=False,
        )
        .sign(private_key, hashes.SHA256(), default_backend())
    )

    # Return certificate and key as PEM-encoded bytes
    cert_pem = cert.public_bytes(serialization.Encoding.PEM)
    key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    )

    return cert_pem, key_pem


def sso_get_credentials_from_code(
    sso_code: str, sso_state: Optional[str], sso_redirect_state: Optional[Dict[Any, Any]]
) -> Tuple[str, str]:
    """
    Given a "code" and "state" returned from an SSO authenticator, turn it into the user and password that
    the Ocient Hyperscale Data Warehouse expects
    """
    logger.debug("Starting sso_get_credentials_from_code")
    if not sso_state:
        raise api.Error("Received SSO code without matching state")

    if not sso_redirect_state:
        raise api.Error("Missing SSO redirect state")

    if uuid.UUID(sso_state) != sso_redirect_state["correlation_id"]:
        raise api.Error("Session and sso state mismatch")

    if sso_redirect_state.get("server_side_token_exchange", False):
        # Use server side token exchange if rolehostd supports it
        payload = {
            "code": sso_code,
            "code_verifier": sso_redirect_state["code_verifier"],
            "redirect_uri": sso_redirect_state["redirect_url"],
        }
        user = "oauth_code"
        js = json.dumps(payload)
        password = base64.urlsafe_b64encode(js.encode("utf-8")).decode("utf-8")
        return user, password
    else:
        # Fall back on local token exchange if server version doesn't support it: Use the authentication server's token endpoint, turn the code into an actual access token
        response = requests.post(
            sso_redirect_state["token_endpoint"],
            data={
                "grant_type": "authorization_code",
                "client_id": sso_redirect_state["client_id"],
                "code": sso_code,
                "code_verifier": sso_redirect_state["code_verifier"],
                "scope": sso_redirect_state["scopes"],
                "redirect_uri": sso_redirect_state["redirect_url"],
            },
            verify=api.Connection.SSO_SERVER_CERTIFICATE_VERIFICATION,
        )

        logger.debug(f"Received token_endpoint response {response.json()}")

        # This is a magic value understood by the Ocient Hyperscale Data Warehouse server indicating that
        # the password contains a base64 encoded json document with tokens (likely
        # access, id, and refresh tokens, depending on the flow)
        user = "oauth_tokens"

        js = json.dumps(response.json())

        # and base64 encode the string representation of the JSON
        # document
        password = base64.b64encode(js.encode("utf-8")).decode("utf-8")

        return user, password


def _sso_authorization_flow(
    auth: proto.Authenticator,  # type: ignore[name-defined]
    sso_callback_url: Optional[str],
    scopes: str,
    config_data: Dict[str, str],
    sso_timeout: float,
) -> None:
    """
    Perform the authorization flow with the SSO server.  this routine raises an SSORedirection exception
    """
    logger.debug("starting sso authorization flow")

    # Determine if SSL should be used based on the authenticator's redirectSSL flag
    use_ssl = auth.openidauthenticator.redirectSSL if auth.openidauthenticator.HasField("redirectSSL") else False
    callback_url = sso_callback_url or sso_local_callback_url(use_ssl)

    code_verifier, code_challenge = pkce.generate_pkce_pair()

    # Create the state we will return in the SSORedirection exception
    state = {
        "client_id": auth.openidauthenticator.clientId,
        "scopes": scopes,
        "redirect_url": callback_url,
        "token_endpoint": config_data.get("token_endpoint"),
        "correlation_id": uuid.uuid4(),
        "code_verifier": code_verifier,
        "server_side_token_exchange": getattr(auth.openidauthenticator, "serverSideTokenExchangeSupport", False),
    }

    # Construct the authorization URI and return it our caller in an
    # SSORedirection exception
    auth_url = (
        config_data["authorization_endpoint"]
        + "?"
        + urlencode(
            {
                "client_id": auth.openidauthenticator.clientId,
                "state": str(state["correlation_id"]),
                "response_mode": "query",
                "response_type": "code",
                "redirect_uri": callback_url,
                "scope": scopes,
                "code_challenge": code_challenge,
                "code_challenge_method": "S256",
                "consent": "prompt",
            },
        )
    )

    logger.debug(f"raising SSORedirection exception with url {auth_url}")

    # Raise the SSO redirection exception
    raise api.SSORedirection(authURL=auth_url, state=state, use_ssl=use_ssl)


def _sso_device_flow(
    auth: proto.Authenticator,  # type: ignore[name-defined]
    scopes: str,
    config_data: Dict[str, str],
    sso_timeout: float,
    server_side_polling: bool = False,
    sso_integration_database: Optional[str] = None,
) -> Tuple[str, str]:
    """
    This is the device authorization flow. Rather than launching a browser,
    we print a messsage to stdout telling the caller what link to go to

    Args:
        sso_integration_database: Database where SSO integration is defined (for cross-database SSO).
            If set, the returned username will be suffixed with @<database>.
    """
    logger.debug("starting sso device flow")
    response = requests.post(
        config_data["device_authorization_endpoint"],
        data={
            "client_id": auth.openidauthenticator.clientId,
            "scope": scopes,
        },
        verify=api.Connection.SSO_SERVER_CERTIFICATE_VERIFICATION,
    )

    # This should definitely have:
    # - device_code
    # - user_code
    # - verification_uri ** This now seems to be not strictly required and some IdPs use verification_url instead
    #
    # it may have
    # - verification_uri_complete ** This sometimes is also of the form verification_url_complete
    # - interval
    js = response.json()

    logger.debug(f"Received device_authorization response {js}")

    interval = float(js.get("interval", "5"))
    device_code = js.get("device_code")
    expires_in = int(js.get("expires_in", 600))
    verification_uri = js.get("verification_uri") or js.get("verification_url")
    verification_uri_complete = js.get("verification_uri_complete") or js.get("verification_url_complete")

    # This message is consistent with the JDBC driver
    print(
        dedent(
            f"""
                Please enter the following code at the verification_uri:
                    verification_uri_complete: {verification_uri_complete or "n/a"}
                    verification_uri: {verification_uri}
                    user_code: {js.get("user_code")}
                    """
        )
    )

    # This exact message is looked for in system tests
    logger.info(f"[pyocient] Please authenticate at: {js.get('verification_uri_complete', 'n/a')}")

    # For cross-database SSO, append @<database> to the username
    db_suffix = f"@{sso_integration_database}" if sso_integration_database else ""

    if server_side_polling:
        # Use server side token exchange if rolehostd supports it
        payload = {
            "device_code": device_code,
            "interval": int(interval) if interval else 5,
            "expires_in": expires_in,
        }
        user = f"oauth_device_code{db_suffix}"
        password = base64.urlsafe_b64encode(json.dumps(payload).encode("utf-8")).decode("utf-8")
        return user, password
    else:
        # Fall back on local polling if server version doesn't support it: Now we start polling the token endpoint to see if the user entered the URL
        start_time = monotonic()
        while True:
            if monotonic() - start_time > sso_timeout:
                raise api.Error("Timeout waiting for SSO response")

            response = requests.post(
                config_data["token_endpoint"],
                data={
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    "client_id": auth.openidauthenticator.clientId,
                    "device_code": device_code,
                },
                verify=api.Connection.SSO_SERVER_CERTIFICATE_VERIFICATION,
            )

            js = response.json()

            logger.debug(f"Received token_endpoint response {js}")

            # If we actually got an access token, we are done
            if "access_token" in js:
                # This is a magic value understood by the server
                user = f"oauth_tokens{db_suffix}"

                # Convert the json response to a string
                js = json.dumps(response.json())

                # and base64 encode the string representation of the JSON
                # document
                password = base64.b64encode(js.encode("utf-8")).decode("utf-8")

                return user, password

            if "error" in js:
                if js["error"] == "authorization_pending":
                    interval += 5
                    sleep(interval)
                    continue

                if js["error"] == "slow_down":
                    sleep(interval)
                    continue

            raise api.Error(
                f"{js.get('error', 'general error')} : {js.get('error_description', 'something went wrong')}"
            )

    raise api.Error("Unable to execute SSO device flow")


def sso_get_credentials(
    authenticators: List[proto.Authenticator],  # type: ignore[name-defined]
    sso_oauth_flow: Optional[str],
    sso_callback_url: Optional[str],
    sso_timeout: float,
    identity_provider: Optional[str],
    sso_redirect_host: Optional[str] = None,
    sso_redirect_ssl: Optional[bool] = None,
    sso_integration_database: Optional[str] = None,
) -> Tuple[str, str]:
    """
    Get SSO credentials. We will either do an authorization flow or a device flow based on
    the `sso_oauth_flow` value or whether we have the capability to launch a browser

    Args:
        authenticators: List of authenticators from the server
        sso_oauth_flow: OAuth flow type
        sso_callback_url: Callback URL for SSO
        sso_timeout: Timeout for SSO operations
        identity_provider: Identity provider name
        sso_redirect_host: Override for redirect host (command-line override)
        sso_redirect_ssl: Override for redirect SSL (command-line override)
        sso_integration_database: Database where SSO integration is defined (for cross-database SSO)
    """

    # Decide if we should try to launch a browser.  If the sso_oauth_flow is 'deviceGrant'
    # we don't want to.  Otherwise, see if the `webbrowser` module thinks it can launch
    # a browser
    browser_launcher = None
    if sso_oauth_flow != "deviceGrant":
        try:
            browser_launcher = webbrowser.get()
        except webbrowser.Error:
            pass

    # if user specified an identity provider, try that one first
    if isinstance(identity_provider, str):
        for auth in authenticators:
            if auth.openidauthenticator.identityProvider == identity_provider:
                if auth.openidauthenticator.disabled:
                    raise api.Error("The requested security integration is disabled", "08001", -1200)

                # First get the authenticator URL
                response = requests.get(
                    auth.openidauthenticator.issuer + "/.well-known/openid-configuration",
                    verify=api.Connection.SSO_SERVER_CERTIFICATE_VERIFICATION,
                )
                if response.status_code >= 400:
                    break
                config_data = response.json()
                scopes = " ".join(auth.openidauthenticator.scope)

                # Use command-line override for SSL if provided, otherwise use authenticator setting
                if sso_redirect_ssl is not None:
                    use_ssl = sso_redirect_ssl
                else:
                    use_ssl = (
                        auth.openidauthenticator.redirectSSL
                        if auth.openidauthenticator.HasField("redirectSSL")
                        else False
                    )
                redirect_ssl_str = "https" if use_ssl else "http"

                # Use command-line override for host if provided, otherwise use authenticator setting
                redirect_host = (
                    sso_redirect_host if sso_redirect_host is not None else auth.openidauthenticator.redirectHost
                )

                redirect_uri = (
                    f"{redirect_ssl_str}://{redirect_host}:{LOCAL_SSO_CALLBACK_PORT}{LOCAL_SSO_CALLBACK_PATH}"
                    if redirect_host
                    else sso_callback_url
                )
                logging.log(logging.DEBUG, f"Redirect URI: {redirect_uri}")

                # If we should launch a browser or if we have been handed an explicit callback URL,
                # do the authorization flow
                if (browser_launcher or redirect_uri) and sso_oauth_flow != "deviceGrant":
                    _sso_authorization_flow(auth, redirect_uri, scopes, config_data, sso_timeout)
                else:
                    server_side_token_exchange_support = getattr(
                        auth.openidauthenticator, "serverSideTokenExchangeSupport", False
                    )
                    return _sso_device_flow(
                        auth,
                        scopes,
                        config_data,
                        sso_timeout,
                        server_side_token_exchange_support,
                        sso_integration_database,
                    )

    disabled = False
    # Try each of the authenticators in turn
    for auth in authenticators:
        # If disabled skip the authenticator but mark disabled as true
        if auth.openidauthenticator.disabled:
            disabled = True
            continue

        # First get the authenticator URL
        response = requests.get(
            auth.openidauthenticator.issuer + "/.well-known/openid-configuration",
            verify=api.Connection.SSO_SERVER_CERTIFICATE_VERIFICATION,
        )
        if response.status_code >= 400:
            continue
        config_data = response.json()

        scopes = " ".join(auth.openidauthenticator.scope)

        # Use command-line override for SSL if provided, otherwise use authenticator setting
        if sso_redirect_ssl is not None:
            use_ssl = sso_redirect_ssl
        else:
            use_ssl = (
                auth.openidauthenticator.redirectSSL if auth.openidauthenticator.HasField("redirectSSL") else False
            )
        redirect_ssl_str = "https" if use_ssl else "http"

        # Use command-line override for host if provided, otherwise use authenticator setting
        redirect_host = sso_redirect_host if sso_redirect_host is not None else auth.openidauthenticator.redirectHost

        redirect_uri = (
            f"{redirect_ssl_str}://{redirect_host}:{LOCAL_SSO_CALLBACK_PORT}{LOCAL_SSO_CALLBACK_PATH}"
            if redirect_host
            else sso_callback_url
        )

        # If we should launch a browser or if we have been handed an explicit callback URL,
        # do the authorization flow
        if sso_oauth_flow != "deviceGrant":
            _sso_authorization_flow(auth, redirect_uri, scopes, config_data, sso_timeout)
        else:
            server_side_token_exchange_support = getattr(
                auth.openidauthenticator, "serverSideTokenExchangeSupport", False
            )
            return _sso_device_flow(
                auth, scopes, config_data, sso_timeout, server_side_token_exchange_support, sso_integration_database
            )

    if disabled:
        raise api.Error("The security integration is disabled", "08001", -1200)

    raise api.Error("No SSO credentials found")


def local_sso_callback(auth_url: str, sso_timeout: float, use_ssl: bool = False) -> Tuple[str, str]:
    """
    This function starts up a web server and waits for the browser
    to call us back after an SSO authentication flow.  All in all
    this is a terrible implementation, since we can't use ephemeral
    ports for reasons described here:
    https://community.auth0.com/t/random-local-ports-on-redirect-uri/28623/9

    In general, a much better model is generally for some higher level caller
    to handle the callback

    Args:
        auth_url: The SSO authentication URL to open in the browser
        sso_timeout: Timeout in seconds for the callback
        use_ssl: If True, use HTTPS with a self-signed certificate
    """

    class ContextHTTPServer(HTTPServer):
        """
        This class implements an HTTP server, with some context
        that can be updated when a request is received
        """

        def __init__(self, *args: Any, **kwargs: Any):
            HTTPServer.__init__(self, *args, **kwargs)
            self.oidc_code: Optional[str] = None
            self.state: Optional[str] = None

        def handle_timeout(self) -> None:
            raise TimeoutError("SSO callback timed out")

    class SingleRequestHandler(BaseHTTPRequestHandler):
        """
        Handler for a single request that basically just
        stores the `code` and `state` parameters in
        the server
        """

        def do_GET(self) -> None:
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"SSO Authentication complete!")

            parsed = urlparse(self.path)

            if parsed.path != LOCAL_SSO_CALLBACK_PATH:
                raise api.Error("Invalid SSO Callback path")

            qs = parse_qs(parsed.query)

            if "code" not in qs:
                raise api.Error("Malformed SSO callback. Missing OIDC code parameter")

            if "state" not in qs:
                raise api.Error("Malformed SSO callback. Missing state parameter")

            assert isinstance(self.server, ContextHTTPServer)
            self.server.oidc_code = " ".join(qs["code"])
            self.server.state = " ".join(qs["state"])

    with ContextHTTPServer(("localhost", LOCAL_SSO_CALLBACK_PORT), SingleRequestHandler) as server:
        # Wrap socket with SSL if needed
        if use_ssl:
            cert_pem, key_pem = _generate_self_signed_cert()

            # Write cert and key to temporary files that will be auto-deleted
            # Note: We need actual files because ssl.SSLContext.load_cert_chain() requires file paths
            with tempfile.NamedTemporaryFile(
                mode="wb", delete=False, suffix=".pem"
            ) as cert_file, tempfile.NamedTemporaryFile(mode="wb", delete=False, suffix=".pem") as key_file:
                cert_file.write(cert_pem)
                cert_file.flush()
                cert_file_path = cert_file.name

                key_file.write(key_pem)
                key_file.flush()
                key_file_path = key_file.name

            try:
                context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                context.load_cert_chain(cert_file_path, key_file_path)
                server.socket = context.wrap_socket(server.socket, server_side=True)
            finally:
                # Clean up temporary files immediately after loading
                try:
                    Path(cert_file_path).unlink(missing_ok=True)
                except Exception:
                    pass
                try:
                    Path(key_file_path).unlink(missing_ok=True)
                except Exception:
                    pass

        server.timeout = sso_timeout
        # Open the browser to send a request to the server
        if webbrowser.open_new(auth_url):
            # Wait for a single request
            try:
                server.handle_request()
            except TimeoutError:
                raise api.Error("SSO callback timed out w/ browser")

            if not server.oidc_code:
                raise api.Error("Missing OIDC authentication code in SSO callback")

            if not server.state:
                raise api.Error("Missing state in SSO callback")

            return server.oidc_code, server.state
        else:
            auth_str = f"Could not open default browser with Desktop library. Please authenticate at: {auth_url}"
            logger.warning(auth_str)
            print(auth_str)

            # Wait for a single request
            try:
                server.handle_request()
            except TimeoutError:
                raise api.Error("SSO callback timed out")

            if not server.oidc_code:
                raise api.Error("Missing OIDC authentication code in SSO callback")

            if not server.state:
                raise api.Error("Missing state in SSO callback")

            return server.oidc_code, server.state
