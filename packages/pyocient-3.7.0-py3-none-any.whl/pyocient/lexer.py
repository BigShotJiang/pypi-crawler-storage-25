# mypy: disallow_any_explicit=false
"""
Ocient SQL Lexer for Pygments.

This module provides a custom Pygments lexer for Ocient SQL syntax,
extending the standard SqlLexer with Ocient-specific keywords, operators,
and constructs like dollar-quoted strings and variable identifiers.
"""

import re
from typing import Any, Iterator, Tuple

from pygments.lexer import RegexLexer, bygroups, words
from pygments.lexers.sql import SqlLexer
from pygments.token import (
    Comment,
    Keyword,
    Name,
    Number,
    Operator,
    Punctuation,
    String,
    Text,
    Token,
    Whitespace,
)

# Ocient-specific keywords extracted from libxgantlr/command/command.g4
# These are keywords that are specific to Ocient or have special meaning in Ocient SQL
OCIENT_KEYWORDS = (
    # DDL keywords
    "add",
    "advertised_address",
    "advertised_port",
    "age",
    "alter",
    "anti",
    "backup",
    "bad_data_target",
    "balance",
    "begin",
    "bucket",
    "cache",
    "call",
    "cancel",
    "cascade",
    "class",
    "cluster",
    "clusters",
    "clustering",
    "completion",
    "compression",
    "compression_level",
    "connectivity_pool",
    "constraint",
    "create",
    "dataflow",
    "declare",
    "dictionary_size",
    "directory",
    "disable",
    "do",
    "drain",
    "drop",
    "dynamic",
    "enable",
    "end",
    "enqueue",
    "error",
    "execute",
    "explain",
    "export",
    "external",
    "extract",
    "filename",
    "files",
    "filter",
    "finally",
    "force",
    "function",
    "gdc",
    "grant",
    "hint",
    "if",
    "import",
    "imports",
    "index",
    "index_advisor",
    "inline",
    "invalidate",
    "iterations",
    "jdbc",
    "json",
    "key",
    "kill",
    "language",
    "lateral",
    "listen_address",
    "listen_port",
    "load",
    "loaders",
    "local",
    "location",
    "lookup",
    "lts_properties",
    "lz4",
    "map",
    "mapping",
    "max",
    "mlmodel",
    "monitor",
    "move",
    "node",
    "noindex",
    "none",
    "ocient",
    "openapi_port",
    "option",
    "options",
    "orphans",
    "pages",
    "participant",
    "participants",
    "pipeline",
    "pipeline_schema",
    "policy",
    "pragma",
    "preview",
    "priority",
    "procedure",
    "proto",
    "purge",
    "quarantine",
    "queries",
    "query",
    "redacted",
    "redundancy",
    "refresh",
    "remote",
    "remove",
    "rename",
    "replace",
    "reset",
    "restore",
    "retention",
    "return",
    "returns",
    "revoke",
    "role",
    "sample",
    "schema",
    "scope",
    "segment",
    "segmentsize",
    "semi",
    "service",
    "show",
    "skip_cache",
    "skip_cache_read",
    "skip_cache_write",
    "sleep_in_optimizer",
    "source",
    "source_address",
    "source_port",
    "sso integration",
    "start",
    "statistics",
    "stats",
    "stop",
    "storage_device",
    "storagespace",
    "streamloader_properties",
    "summary_stats",
    "sysauth",
    "system",
    "table_with_rowids",
    "tag",
    "task",
    "trace",
    "transform",
    "truncate",
    "type",
    "use",
    "user",
    "uuid",
    "view",
    "zstd",
    # Dataflow keywords
    "while",
    "for",
    "finally",
    # Data types
    "array",
    "bigint",
    "binary",
    "boolean",
    "colvector",
    "date",
    "decimal",
    "double",
    "float",
    "hash",
    "int",
    "ip",
    "ipv4",
    "ipv6",
    "matrix",
    "rowvector",
    "smallint",
    "st_linestring",
    "st_point",
    "st_polygon",
    "time",
    "timestamp",
    "tinyint",
    "tuple",
    "varbinary",
    "varchar",
    "varying",
    # Time intervals
    "millisecond",
    "milliseconds",
    "second",
    "seconds",
    "minute",
    "minutes",
    "hour",
    "hours",
    "day",
    "days",
    "week",
    "weeks",
)

# Standard SQL keywords (subset that SqlLexer may not highlight properly)
SQL_KEYWORDS = (
    "all",
    "and",
    "any",
    "as",
    "asc",
    "between",
    "by",
    "case",
    "cast",
    "check",
    "column",
    "count",
    "cross",
    "current",
    "current_database",
    "current_date",
    "current_schema",
    "current_time",
    "current_timestamp",
    "current_user",
    "data",
    "database",
    "debug",
    "default",
    "delete",
    "desc",
    "describe",
    "distinct",
    "else",
    "except",
    "exists",
    "false",
    "first",
    "following",
    "foreign",
    "from",
    "full",
    "group",
    "having",
    "ignore",
    "in",
    "inner",
    "insert",
    "intersect",
    "interval",
    "into",
    "is",
    "join",
    "last",
    "left",
    "like",
    "ilike",
    "limit",
    "not",
    "null",
    "nulls",
    "offset",
    "on",
    "or",
    "order",
    "outer",
    "over",
    "partition",
    "preceding",
    "precision",
    "primary",
    "range",
    "references",
    "regex",
    "right",
    "row",
    "rows",
    "select",
    "set",
    "similar",
    "some",
    "table",
    "then",
    "to",
    "true",
    "unbounded",
    "union",
    "unique",
    "using",
    "values",
    "when",
    "where",
    "with",
)

# All keywords combined
ALL_KEYWORDS = OCIENT_KEYWORDS + SQL_KEYWORDS


class OcientLexer(RegexLexer):
    """
    Lexer for Ocient SQL dialect.

    Extends standard SQL syntax with Ocient-specific constructs:
    - Dollar-quoted strings ($$...$$)
    - Variable identifiers (@variable)
    - Temp table identifiers (#table)
    - Escape strings (e'...')
    - Ocient-specific operators and keywords
    """

    name = "Ocient SQL"
    aliases = ["ocient", "ocientsql"]
    filenames = ["*.sql"]
    mimetypes = ["text/x-ocient-sql"]

    flags = re.IGNORECASE

    tokens = {
        "root": [
            # Whitespace
            (r"\s+", Whitespace),
            # Single-line comments
            (r"--.*$", Comment.Single),
            # Multi-line comments
            (r"/\*", Comment.Multiline, "multiline-comments"),
            # Dollar-quoted strings (Ocient-specific: $$...$$)
            (r"\$\$.*?\$\$", String),
            # Escape strings (e'...')
            (r"[eE]'([^'\\]|\\.)*'", String),
            # Variable identifiers (@var)
            (r"@[a-zA-Z0-9_]+", Name.Variable),
            # Temp table identifiers (#table)
            (r"#[a-zA-Z0-9_]+", Name.Variable),
            # Ocient-specific operators
            (r"<<->>", Operator),  # centroid distance
            (r"<->", Operator),  # distance
            (r"<#>", Operator),  # bounding box distance
            (r"@>", Operator),  # contains
            (r"<@", Operator),  # contained
            (r"~=", Operator),  # bounding box equal
            (r"&&", Operator),  # overlap
            (r"->", Operator),  # maps to
            (r"::", Operator),  # cast
            (r"\|\|", Operator),  # concatenate
            (r"<<", Punctuation),  # tuple start
            (r">>", Punctuation),  # tuple end
            # Standard operators
            (r"[+*/<>=~!@#%^&|`?-]+", Operator),
            # Keywords (Ocient + SQL)
            (words(ALL_KEYWORDS, suffix=r"\b"), Keyword),
            # Numbers
            (r"[0-9]*\.[0-9]+([eE][+-]?[0-9]+)?", Number.Float),
            (r"[0-9]+", Number.Integer),
            # Quoted identifiers
            (r'"([^"]|"")*"', Name),
            # Single-quoted strings
            (r"'([^']|'')*'", String.Single),
            # Identifiers
            (r"[a-zA-Z_][a-zA-Z0-9_]*", Name),
            # Punctuation
            (r"[;:()\[\]{},.]", Punctuation),
        ],
        "multiline-comments": [
            (r"/\*", Comment.Multiline, "#push"),
            (r"\*/", Comment.Multiline, "#pop"),
            (r"[^/*]+", Comment.Multiline),
            (r"[/*]", Comment.Multiline),
        ],
    }


# For backwards compatibility, also export as SqlLexer replacement
OcientSqlLexer = OcientLexer
