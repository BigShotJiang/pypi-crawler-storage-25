# -*- coding: utf-8 -*-
"""
Type descriptor system for tai-sql V2 syntax.

Each supported type implements TypeDescriptor, providing a driver-agnostic
abstraction that knows how to map to SQLAlchemy types per driver,
generate filter fields for DTOs, and validate compatibility.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type
from datetime import datetime, date, time
from enum import Enum

from sqlalchemy import (
    Integer, String, Text, Boolean, DateTime,
    Date, Time, Float, Numeric, LargeBinary,
    BigInteger, Enum as SQLAlchemyEnum
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.mysql import JSON as MySQLJSON
from sqlalchemy import JSON as GenericJSON


class TypeDescriptor(ABC):
    """
    Abstract base for all supported column types.
    
    Each type in the system (int, str, bigint, dict, vector, etc.)
    is backed by a TypeDescriptor that encapsulates:
    - How to map to SQLAlchemy types per driver
    - What Python/Pydantic type it corresponds to
    - What filter fields to generate in DTOs
    - Which drivers support this type
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Canonical name used internally (e.g. 'int', 'str', 'bigint', 'vector')"""
        ...

    @property
    @abstractmethod
    def python_type(self) -> type:
        """The native Python type (e.g. int, str, float, list)"""
        ...

    @property
    @abstractmethod
    def pydantic_type(self) -> str:
        """String representation for Pydantic DTOs (e.g. 'int', 'str', 'Dict[str, Any]', 'List[float]')"""
        ...

    @abstractmethod
    def to_sqlalchemy(self, driver: str) -> Any:
        """
        Return the SQLAlchemy type class for the given driver.
        
        Args:
            driver: Driver name ('postgresql', 'mysql', 'sqlserver')
            
        Returns:
            SQLAlchemy type class or instance
        """
        ...

    def supports_driver(self, driver: str) -> bool:
        """
        Check if this type is supported on the given driver.
        Override to restrict types to specific drivers.
        """
        return True

    def filter_fields(self) -> List[str]:
        """
        Return the list of filter field patterns this type generates in DTOs.
        
        Patterns:
        - 'exact'    → field: Optional[T]
        - 'in'       → in_field: Optional[List[T]]
        - 'range'    → min_field, max_field: Optional[T]
        - 'like'     → ilike support for string matching
        - 'none'     → no filter fields
        
        Returns:
            List of filter pattern strings
        """
        return ['exact']

    @property
    def sqlalchemy_type_name(self) -> Optional[str]:
        """
        The SQLAlchemy type name string for column info (e.g. 'BigInteger', 'JSONB').
        Return None if no explicit SQLAlchemy type is needed.
        """
        return None


# =============================================================================
# Concrete type descriptors
# =============================================================================

class IntType(TypeDescriptor):
    name = 'int'
    python_type = int
    pydantic_type = 'int'

    def to_sqlalchemy(self, driver: str) -> Any:
        return Integer

    def filter_fields(self) -> List[str]:
        return ['exact', 'in', 'range']


class BigIntType(TypeDescriptor):
    name = 'bigint'
    python_type = int
    pydantic_type = 'int'

    def to_sqlalchemy(self, driver: str) -> Any:
        return BigInteger

    @property
    def sqlalchemy_type_name(self) -> str:
        return 'BigInteger'

    def filter_fields(self) -> List[str]:
        return ['exact', 'in', 'range']


class StrType(TypeDescriptor):
    name = 'str'
    python_type = str
    pydantic_type = 'str'

    def to_sqlalchemy(self, driver: str) -> Any:
        return String

    def filter_fields(self) -> List[str]:
        return ['exact', 'in', 'like']


class TextType(TypeDescriptor):
    name = 'text'
    python_type = str
    pydantic_type = 'str'

    def to_sqlalchemy(self, driver: str) -> Any:
        return Text

    @property
    def sqlalchemy_type_name(self) -> str:
        return 'Text'

    def filter_fields(self) -> List[str]:
        return ['exact', 'in', 'like']


class BoolType(TypeDescriptor):
    name = 'bool'
    python_type = bool
    pydantic_type = 'bool'

    def to_sqlalchemy(self, driver: str) -> Any:
        return Boolean

    def filter_fields(self) -> List[str]:
        return ['exact']


class FloatType(TypeDescriptor):
    name = 'float'
    python_type = float
    pydantic_type = 'float'

    def to_sqlalchemy(self, driver: str) -> Any:
        return Float

    def filter_fields(self) -> List[str]:
        return ['range']


class NumericType(TypeDescriptor):
    name = 'numeric'
    python_type = float
    pydantic_type = 'float'

    def to_sqlalchemy(self, driver: str) -> Any:
        return Numeric

    @property
    def sqlalchemy_type_name(self) -> str:
        return 'Numeric'

    def filter_fields(self) -> List[str]:
        return ['range']


class DateTimeType(TypeDescriptor):
    name = 'datetime'
    python_type = datetime
    pydantic_type = 'datetime'

    def to_sqlalchemy(self, driver: str) -> Any:
        return DateTime

    def filter_fields(self) -> List[str]:
        return ['range']


class DateType(TypeDescriptor):
    name = 'date'
    python_type = date
    pydantic_type = 'date'

    def to_sqlalchemy(self, driver: str) -> Any:
        return Date

    def filter_fields(self) -> List[str]:
        return ['exact', 'in', 'range']


class TimeType(TypeDescriptor):
    name = 'time'
    python_type = time
    pydantic_type = 'time'

    def to_sqlalchemy(self, driver: str) -> Any:
        return Time

    def filter_fields(self) -> List[str]:
        return ['range']


class BytesType(TypeDescriptor):
    name = 'bytes'
    python_type = bytes
    pydantic_type = 'bytes'

    def to_sqlalchemy(self, driver: str) -> Any:
        return LargeBinary

    def filter_fields(self) -> List[str]:
        return ['none']


class LargeBinaryType(TypeDescriptor):
    name = 'largebinary'
    python_type = bytes
    pydantic_type = 'bytes'

    def to_sqlalchemy(self, driver: str) -> Any:
        return LargeBinary

    @property
    def sqlalchemy_type_name(self) -> str:
        return 'LargeBinary'

    def filter_fields(self) -> List[str]:
        return ['none']


class DictType(TypeDescriptor):
    name = 'dict'
    python_type = dict
    pydantic_type = 'Dict[str, Any]'

    def to_sqlalchemy(self, driver: str) -> Any:
        if driver == 'postgresql':
            return JSONB
        elif driver == 'mysql':
            return MySQLJSON
        return GenericJSON

    @property
    def sqlalchemy_type_name(self) -> Optional[str]:
        return 'JSON'

    def filter_fields(self) -> List[str]:
        return ['none']


class vector:
    """Sentinel type for vector column annotations. Use in schemas: ``embedding: vector = vector_column(...)``"""
    pass


class VectorType(TypeDescriptor):
    """Descriptor for pgvector embedding columns (PostgreSQL only)."""

    name = 'vector'
    python_type = list
    pydantic_type = 'List[float]'

    def to_sqlalchemy(self, driver: str) -> Any:
        try:
            from pgvector.sqlalchemy import Vector
        except ImportError:
            raise ImportError(
                "pgvector is required for vector columns. "
                "Install it with: pip install 'tai-sql[vectors]'"
            )
        return Vector

    def supports_driver(self, driver: str) -> bool:
        return driver == 'postgresql'

    def filter_fields(self) -> List[str]:
        return ['none']

    @property
    def sqlalchemy_type_name(self) -> Optional[str]:
        return 'VECTOR'


class EnumType(TypeDescriptor):
    """
    Descriptor for Enum-based columns.
    Instantiated per-column with the specific Enum class.
    """

    def __init__(self, enum_class: Type[Enum]):
        self._enum_class = enum_class
        # Determine native type from enum values
        types = list(set(type(item.value) for item in enum_class))
        if len(types) != 1:
            raise TypeError(
                f"Enum '{enum_class.__name__}' has multiple value types: {types}. "
                "Must have a single value type."
            )
        self._native_type = types[0]

    @property
    def name(self) -> str:
        return self._native_type.__name__

    @property
    def python_type(self) -> type:
        return self._native_type

    @property
    def pydantic_type(self) -> str:
        return self._native_type.__name__

    @property
    def enum_class(self) -> Type[Enum]:
        return self._enum_class

    def to_sqlalchemy(self, driver: str) -> Any:
        return SQLAlchemyEnum

    def filter_fields(self) -> List[str]:
        return ['exact']


# =============================================================================
# Type Registry
# =============================================================================

class TypeRegistry:
    """
    Central registry mapping Python types / aliases to TypeDescriptor instances.
    
    Supports lookup by:
    - name: canonical type name ('int', 'str', 'bigint', 'dict')
    - python_type: native Python type class (int, str, dict)
    - sqlalchemy_type: SQLAlchemy type class (Integer, String, JSONB)
    - sqlalchemy_type_name: SA type name string ('BigInteger', 'Text', 'JSON', 'JSONB')
    """

    def __init__(self):
        self._by_name: Dict[str, TypeDescriptor] = {}
        self._by_python_type: Dict[type, TypeDescriptor] = {}
        self._by_sqlalchemy_type: Dict[type, TypeDescriptor] = {}
        self._by_sa_name: Dict[str, TypeDescriptor] = {}

    def register(self, descriptor: TypeDescriptor, *sqlalchemy_types: type) -> None:
        """Register a type descriptor with optional SQLAlchemy type mappings.
        First registration for a python_type wins (primary types take precedence over aliases)."""
        self._by_name[descriptor.name] = descriptor
        if descriptor.python_type not in self._by_python_type:
            self._by_python_type[descriptor.python_type] = descriptor
        for sa_type in sqlalchemy_types:
            self._by_sqlalchemy_type[sa_type] = descriptor
        # Also register by sqlalchemy_type_name for Column._resolve_sqlalchemy_type()
        if descriptor.sqlalchemy_type_name:
            self._by_sa_name[descriptor.sqlalchemy_type_name] = descriptor

    def get_by_name(self, name: str) -> Optional[TypeDescriptor]:
        """Lookup by canonical name, then by SA type name as fallback."""
        return self._by_name.get(name) or self._by_sa_name.get(name)

    def get_by_python_type(self, python_type: type) -> Optional[TypeDescriptor]:
        return self._by_python_type.get(python_type)

    def get_by_sqlalchemy_type(self, sa_type: type) -> Optional[TypeDescriptor]:
        return self._by_sqlalchemy_type.get(sa_type)

    def is_registered(self, type_hint) -> bool:
        """Check if a type hint corresponds to a registered type."""
        return (
            type_hint in self._by_python_type
            or type_hint in self._by_sqlalchemy_type
            or (isinstance(type_hint, str) and type_hint in self._by_name)
        )

    @property
    def names(self) -> List[str]:
        return list(self._by_name.keys())


# =============================================================================
# Default registry with all built-in types
# =============================================================================

_registry = TypeRegistry()

# Register all built-in types
_registry.register(IntType(), Integer)
_registry.register(BigIntType(), BigInteger)
_registry.register(StrType(), String)
_registry.register(TextType(), Text)
_registry.register(BoolType(), Boolean)
_registry.register(FloatType(), Float)
_registry.register(NumericType(), Numeric)
_registry.register(DateTimeType(), DateTime)
_registry.register(DateType(), Date)
_registry.register(TimeType(), Time)
_registry.register(BytesType(), LargeBinary)
_registry.register(LargeBinaryType())
_registry.register(DictType(), JSONB, MySQLJSON, GenericJSON)
_registry.register(VectorType(), vector)


def get_type_registry() -> TypeRegistry:
    """Get the global type registry."""
    return _registry


def register_type(descriptor: TypeDescriptor, *sqlalchemy_types: type) -> None:
    """Register a custom type descriptor in the global registry."""
    _registry.register(descriptor, *sqlalchemy_types)
