from __future__ import annotations
from typing import Any, Dict, ClassVar, List, Union, get_type_hints, get_origin, get_args, TYPE_CHECKING
from abc import ABC, abstractmethod
from sqlalchemy import MetaData
from datetime import datetime

from tai_sql import pm
from .columns import Column, ColumnConstraints
from .annotations import _ColType, _RelationType, is_col_type, is_relation_type, is_v1_column_type
from .types import get_type_registry, EnumType

if TYPE_CHECKING:
    from .table import Table  # Evitar circular imports
    from .view import View    # Evitar circular imports


class DatabaseObject(ABC):
    """
    Clase base abstracta para objetos de base de datos (Tables y Views).
    
    Proporciona funcionalidad común para análisis de type hints,
    manejo de columnas y conversión a SQLAlchemy.
    """
    
    __abstract__ = True
    __name__: ClassVar[str]  # Nombre del objeto (tabla o vista)
    __is_view__: ClassVar[bool] = False  # Indica si es una vista
    __operative_fields__: ClassVar[bool] = False  # Si es True, se agregarán campos created_at y updated_at automáticamente
    __description__: ClassVar[str] = ""  # Descripción opcional del objeto
    __examples__: ClassVar[tuple] = ()  # Ejemplos de datos para el objeto
    # Registro centralizado de todos los objetos de BD
    registry: ClassVar[List[DatabaseObject]] = []
    
    # Columnas comunes a tablas y vistas
    columns: ClassVar[Dict[str, Column]] = {}

    def __init__(self, **kwargs):
        """
        Permite instanciar objetos de esquema para uso en feed().
        Almacena los atributos pasados como kwargs.
        """
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def __init_subclass__(cls) -> None:
        """Inicialización común para subclases"""
        super().__init_subclass__()
        
        # Inicializar diccionarios para esta clase específica
        cls.columns = {}
        
        if not hasattr(cls, '__name__'):
            raise ValueError(f"El objeto {cls.__name__} debe definir un atributo __name__")
        
        cls._name = cls.__name__
        cls._description = cls.__description__ or cls.__doc__ or ""
        cls._examples = cls.__examples__ or ()

        if not cls.__is_view__ and (cls.__operative_fields__ or (pm.db and pm.db.operative_fields)):
            cls.operative_fields = True
        else:
            cls.operative_fields = False

        if cls._name == 'Base':
            raise ValueError(f"El objeto {cls.__name__} no puede llamarse 'Base'")
        
        # Solo añadir al registro si no es una clase abstracta
        if cls._should_register():
            DatabaseObject.registry.append(cls)

    @classmethod
    def _should_register(cls) -> bool:
        """
        Determina si la clase debe ser registrada.
        
        Returns:
            bool: True si debe registrarse, False si es una clase base o abstracta
        """
        # Clases que nunca deben registrarse (clases base del framework)
        framework_classes = {
            'DatabaseObject',
            'Table', 
            'View'
        }
        
        # No registrar clases del framework
        if cls.__name__ in framework_classes:
            return False

        # if cls.__name__ in [cls.__name__ for cls in cls.registry]:
        #     return False
        
        # Si llegamos aquí, es una clase concreta que debe registrarse
        return True
    
    @classmethod
    def analyze_columns(cls) -> None:
        """
        Analiza los type hints de la clase para descubrir columnas.
        Método común para Tables y Views.
        Dispatches to V1 or V2 logic based on syntax version.
        """
        syntax = pm.db.syntax if pm.db else 'v1'
        if syntax == 'v2':
            cls._analyze_columns_v2()
        else:
            cls._analyze_columns_v1()
            
        cls._add_calculated_columns()
        cls._add_operative_fields()
        

    @classmethod
    def _add_calculated_columns(cls) -> None:
        """Create physical Column entries for each CalculatedColumn descriptor."""
        calculated = getattr(cls, 'calculated_columns', None)
        if not calculated:
            return

        from .types import get_type_registry
        registry = get_type_registry()

        for name, calc_col in calculated.items():
            type_desc = registry.get_by_name(calc_col.return_type)
            if type_desc is None:
                raise TypeError(
                    f"Unrecognized return type '{calc_col.return_type}' for "
                    f"calculated column '{name}' in '{cls.__name__}'."
                )
            sa_type = type_desc.sqlalchemy_type_name
            column = Column(
                name=name,
                type=calc_col.return_type,
                sa_type=sa_type,
                model=cls,
                nullable=calc_col.nullable,
                is_calculated=True,
                description=calc_col.docstring or f'Columna calculada {name}',
            )
            column.register(cls)

    @classmethod
    def _analyze_columns_v1(cls) -> None:
        """V1 column analysis — coerces bare type hints to _ColType and delegates to V2."""
        type_hints = get_type_hints(cls)
        coerced = cls._coerce_v1_hints(type_hints)
        cls._analyze_columns_v2(coerced)

    @staticmethod
    def _coerce_v1_hints(type_hints: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert V1-style type hints to V2 _ColType instances.
        
        V1: name: str, name: Optional[str], data: BigInteger, status: MyEnum
        V2: _ColType(inner=str), _ColType(inner=str, nullable=True), _ColType(inner=BigInteger), ...
        
        Non-column hints (custom classes for relations, etc.) are passed through unchanged.
        """
        coerced = {}
        for name, hint in type_hints.items():
            if not is_v1_column_type(hint):
                coerced[name] = hint
                continue
            
            # Unwrap Optional[T] → inner=T, nullable=True
            nullable = False
            inner = hint
            origin = get_origin(hint)
            if origin is Union:
                args = get_args(hint)
                if len(args) == 2 and type(None) in args:
                    inner = args[0] if args[1] is type(None) else args[1]
                    nullable = True
            
            coerced[name] = _ColType(inner=inner, nullable=nullable)
        
        return coerced

    @classmethod
    def _analyze_columns_v2(cls, type_hints: Dict[str, Any] = None) -> None:
        """
        V2 column analysis — uses col[T] annotations (_ColType instances).
        
        Only processes attributes whose hint is a _ColType.
        Relation annotations (onetomany, manytoone, onetoone) are skipped here
        and handled by analyze_relations().
        
        Args:
            type_hints: Pre-resolved hints dict. If None, resolves from class annotations.
                        V1 path passes coerced hints here; V2 path lets it resolve natively.
        """
        from enum import Enum as BaseEnum
        registry = get_type_registry()

        # If no hints provided, resolve from class annotations (V2 native path).
        # V1 path provides pre-coerced hints.
        if type_hints is None:
            type_hints = get_type_hints(cls, include_extras=True)

        for name, hint in type_hints.items():
            if name.startswith('__') or name.startswith('_') or name in cls.get_ignored_attributes():
                continue
            
            # Skip non-column annotations (relation types, etc.)
            if not is_col_type(hint):
                continue

            col_type: _ColType = hint
            inner_type = col_type.inner
            value = getattr(cls, name, None)

            # Resolve type descriptor from the registry
            type_desc = None
            
            # Check if it's an Enum subclass
            if isinstance(inner_type, type) and issubclass(inner_type, BaseEnum):
                type_desc = EnumType(inner_type)
                mappedtype = type_desc.name
                sa_type = None
                options = [item.value for item in inner_type]
            else:
                # Look up in type registry
                type_desc = registry.get_by_python_type(inner_type) or registry.get_by_sqlalchemy_type(inner_type)
                
                if type_desc is None:
                    # Try by name
                    type_name = inner_type.__name__ if hasattr(inner_type, '__name__') else str(inner_type)
                    type_desc = registry.get_by_name(type_name.lower())
                
                if type_desc is None:
                    raise TypeError(
                        f"Unrecognized type '{inner_type}' for column '{name}' in '{cls.__name__}'. "
                        f"Registered types: {registry.names}"
                    )
                
                mappedtype = type_desc.name
                sa_type = type_desc.sqlalchemy_type_name
                options = None

            # Process column value
            if isinstance(value, Column):
                # Explicit column() call
                column = value
                column.name = name
                column.type = mappedtype
                column.sa_type = sa_type
                column.options = options
                column.model = cls
                column.nullable = col_type.nullable
                column.register(cls)

            elif value is None:
                # Implicit column (no default, no column() call)
                column = Column(
                    name=name,
                    type=mappedtype,
                    sa_type=sa_type,
                    model=cls,
                    options=options,
                    nullable=col_type.nullable
                )
                column.register(cls)

            elif not isinstance(value, Column) and not cls.__is_view__:
                # Column with default value
                column = Column(
                    name=name,
                    type=mappedtype,
                    sa_type=sa_type,
                    model=cls,
                    options=options,
                    nullable=col_type.nullable
                )
                column.constraints.default = value
                column.register(cls)

    @classmethod
    def _add_operative_fields(cls) -> None:
        """Add operative fields (created_at, updated_at, etc.) if enabled."""
        if not cls.operative_fields:
            return

        created_at = Column(
            name='created_at',
            type='datetime',
            model=cls,
            nullable=False,
            constraints=ColumnConstraints(default=datetime.now),
            description=f'Fecha y hora de creación del registro en {cls._name}',
            is_operative=True
        )
        created_at.register(cls)

        created_by = Column(
            name='created_by',
            type='str',
            model=cls,
            nullable=False,
            constraints=ColumnConstraints(default='triplealpha'),
            description=f'Usuario que creó el registro en {cls._name}',
            is_operative=True
        )
        created_by.register(cls)

        updated_at = Column(
            name='updated_at',
            type='datetime',
            model=cls,
            nullable=False,
            constraints=ColumnConstraints(default=datetime.now),
            description=f'Fecha y hora de la última actualización del registro en {cls._name}',
            is_operative=True
        )
        updated_at.register(cls)

        updated_by = Column(
            name='updated_by',
            type='str',
            model=cls,
            nullable=False,
            constraints=ColumnConstraints(default='triplealpha'),
            description=f'Usuario que realizó la última actualización del registro en {cls._name}',
            is_operative=True
        )
        updated_by.register(cls)


    @classmethod
    @abstractmethod
    def get_ignored_attributes(cls) -> set:
        """Retorna los atributos que deben ser ignorados durante el análisis"""
        pass

    @classmethod
    @abstractmethod
    def reset(cls) -> None:
        """Reinicia el estado de la clase para permitir reanálisis"""
        pass
    
    @classmethod
    def info(cls) -> Dict[str, Any]:
        """Información básica común"""
        return {
            'name': cls.__name__,
            'object_name': cls._name,
            'columns': [col.info() for col in cls.columns.values()],
            'description': cls._description,
        }
    
    @classmethod
    @abstractmethod
    def validate(cls) -> None:
        """Validación específica del tipo de objeto"""
        pass
    
    @classmethod
    @abstractmethod
    def to_sqlalchemy_object(cls, metadata: MetaData):
        """Conversión a objeto SQLAlchemy"""
        pass

    @classmethod
    def get_registered_tables(cls) -> List[Table]:
        """Retorna solo las tablas registradas"""
        from .table import Table  # Import local para evitar circular imports
        return [obj for obj in cls.registry if isinstance(obj, type) and issubclass(obj, Table)]
    
    @classmethod
    def get_registered_views(cls) -> List[View]:
        """Retorna solo las vistas registradas"""
        from .view import View  # Import local para evitar circular imports
        return [obj for obj in cls.registry if isinstance(obj, type) and issubclass(obj, View)]
    