# -*- coding: utf-8 -*-
"""
Relation and ForeignKey definitions for tai-sql ORM.

Provides Relation (logical relationship between tables) and
ForeignKey (physical constraint) dataclasses, plus the relation()
factory function for declarative schema definitions.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, List, Literal, Set, TYPE_CHECKING
from sqlalchemy import ForeignKeyConstraint

from tai_sql import pm

if TYPE_CHECKING:
    from .table import Table
    from .columns import Column


Direction = Literal['one-to-many', 'many-to-one', 'one-to-one']
CascadeAction = Literal['cascade', 'set null', 'restrict']


# ─────────────────────────────────────────────────────────────────────────────
# Relation
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Relation:
    """
    Logical relationship between two Tables.

    Attributes:
        name:       Attribute name in the local model (set during analysis).
        local:      The Table class that owns this relation (set during analysis).
        target:     The Table class on the other end (set during analysis).
        direction:  'one-to-many', 'many-to-one', or 'one-to-one'.
        implicit:   True when inferred from a bare type hint (no relation() call).
        fields:     FK column names in the local table.
        references: PK/unique column names in the target table.
        backref:    Name of the inverse relation attribute on the target.
        on_delete:  Cascade action on delete.
        on_update:  Cascade action on update.
    """

    name: str = None
    local: Table = None
    target: Table = None
    direction: Optional[Direction] = None
    implicit: bool = False
    fields: List[str] = field(default_factory=list)
    references: List[str] = field(default_factory=list)
    backref: Optional[str] = None
    on_delete: CascadeAction = 'cascade'
    on_update: CascadeAction = 'cascade'

    def __post_init__(self) -> None:
        if not self.implicit and self.backref is None:
            raise ValueError(
                "Explicit relations require a 'backref' attribute"
            )

    # ── Public API ───────────────────────────────────────────────────────

    def validate(self) -> None:
        """Validate field/reference consistency and type compatibility."""
        if len(self.fields) != len(self.references):
            raise ValueError(
                f"Relation '{self.name}': fields and references must have the same length"
            )
        if not self.fields or not self.references:
            raise ValueError(
                f"Relation '{self.name}': must have at least one field and one reference"
            )

        for fld, ref in zip(self.fields, self.references):
            if fld not in self.local.columns:
                raise ValueError(
                    f"Field '{fld}' not found in '{self.local.__name__}'"
                )
            if ref not in self.target.columns:
                raise ValueError(
                    f"Reference '{ref}' not found in '{self.target.__name__}'"
                )

            local_col = self.local.columns[fld]
            target_col = self.target.columns[ref]
            local_t = local_col.sa_type or local_col.type
            target_t = target_col.sa_type or target_col.type

            if local_t != target_t:
                raise ValueError(
                    f"Type mismatch in relation '{self.name}':\n"
                    f"  {self.local.__name__}.{fld} ({local_t}) != "
                    f"{self.target.__name__}.{ref} ({target_t})"
                )

    def register_explicit(self) -> None:
        """
        Register an explicit relation (with relation() call).
        Validates, stores in model, creates ForeignKey, marks FK columns.
        """
        self.validate()
        self._store()
        fk = ForeignKey(relation=self)
        self.local.foreign_keys.append(fk)
        for fld in self.fields:
            if fld in self.local.columns:
                self.local.columns[fld].is_foreign_key = True

    def register_implicit(self) -> None:
        """
        Register an implicit relation (bare type hint, no relation() call).
        Only stores in model — no FK is created.
        """
        self._store()

    def resolve_inverse(self) -> None:
        """
        Resolve an implicit relation by finding its explicit counterpart
        on the target table. Copies FK config from the inverse relation.
        Does NOT create a FK — implicit relations are read-only backrefs.
        """
        for target_rel in self.target.relations.values():
            if target_rel.implicit:
                continue
            if target_rel.backref == self.name and self.local is target_rel.target:
                self.fields = target_rel.references
                self.references = target_rel.fields
                self.on_delete = target_rel.on_delete
                self.on_update = target_rel.on_update
                self.backref = target_rel.name
                return

        raise ValueError(
            f"No inverse relation found for '{self.name}' "
            f"in '{self.target.__name__}'"
        )

    @property
    def is_composite(self) -> bool:
        """True if the FK spans multiple columns."""
        return len(self.fields) > 1

    @property
    def fk_columns(self) -> List[Column]:
        """Return the Column objects in local table that form the FK."""
        return sorted(
            [col for name, col in self.local.columns.items() if name in self.fields],
            key=lambda c: c.name,
        )

    def info(self) -> Dict[str, Any]:
        """Serialize relation metadata for generators and templates."""
        if self.direction == 'one-to-many':
            target_type = f"List[{self.target.__name__}]"
        else:
            target_type = self.target.__name__

        return {
            'name': self.name,
            'local': self.local.__name__,
            'target': self.target.__name__,
            'target_tablename': self.target.tablename,
            'target_type': target_type,
            'fields': self.fields,
            'references': self.references,
            'on_delete': self.on_delete,
            'on_update': self.on_update,
            'backref': self.backref,
            'direction': self.direction,
            'is_list': self.direction == 'one-to-many',
            'is_one_to_one': self.direction == 'one-to-one',
            'description': self.target.__doc__ or "",
            'target_has_create_triggers': _has_create_triggers(self.target),
        }

    # ── Internal ─────────────────────────────────────────────────────────

    def _store(self) -> None:
        """Add this relation to the local model's relations dict."""
        if not self.name:
            raise ValueError("Relation name cannot be empty")
        if self.local is None:
            raise ValueError("Relation local model cannot be None")
        if self.target is None:
            raise ValueError("Relation target model cannot be None")
        if self.name in self.local.relations:
            raise ValueError(
                f"Relation '{self.name}' already defined in '{self.local.__name__}'"
            )
        self.local.relations[self.name] = self


# ─────────────────────────────────────────────────────────────────────────────
# ForeignKey
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ForeignKey:
    """
    Physical foreign key constraint derived from a Relation.

    Created automatically when an explicit Relation is registered.
    The FK is always on the Relation's local table.
    """

    relation: Relation

    def __post_init__(self) -> None:
        if not self.relation.fields or not self.relation.references:
            raise ValueError(
                "Cannot create ForeignKey: relation must have fields and references"
            )

    # ── Properties ───────────────────────────────────────────────────────

    @property
    def model(self) -> Table:
        """The table that owns this FK (always relation.local)."""
        return self.relation.local

    @property
    def constraint_name(self) -> str:
        return f"fk_{self.model.tablename}_{self.relation.target.tablename}"

    @property
    def on_delete(self) -> str:
        return self.relation.on_delete.upper()

    @property
    def on_update(self) -> str:
        return self.relation.on_update.upper()

    @property
    def is_composite(self) -> bool:
        return self.relation.is_composite

    @property
    def local_columns(self) -> List[Column]:
        return self.relation.fk_columns

    @property
    def local_columns_names(self) -> List[str]:
        return [col.name for col in self.local_columns]

    @property
    def target_columns(self) -> List[Column]:
        return sorted(
            [col for name, col in self.relation.target.columns.items()
             if name in self.relation.references],
            key=lambda c: c.name,
        )

    @property
    def target_columns_names(self) -> List[str]:
        result = []
        for col in self.target_columns:
            if pm.db.provider.drivername == 'postgresql':
                result.append(
                    f"{pm.db.schema_name}.{self.relation.target.tablename}.{col.name}"
                )
            else:
                result.append(f"{self.relation.target.tablename}.{col.name}")
        return result

    # ── Public API ───────────────────────────────────────────────────────

    def info(self) -> Dict[str, Any]:
        """Serialize FK metadata for generators and templates."""
        return {
            'local_columns': self.local_columns_names,
            'target_columns': self.target_columns_names,
            'constraint_name': self.constraint_name,
            'is_simple': not self.is_composite,
            'is_composite': self.is_composite,
            'ondelete': self.on_delete,
            'onupdate': self.on_update,
        }

    def to_sqlalchemy_foreign_key(self) -> ForeignKeyConstraint:
        """Convert to a SQLAlchemy ForeignKeyConstraint."""
        return ForeignKeyConstraint(
            columns=self.local_columns_names,
            refcolumns=self.target_columns_names,
            name=self.constraint_name,
            ondelete=self.on_delete,
            onupdate=self.on_update,
        )


# ─────────────────────────────────────────────────────────────────────────────
# relation() factory
# ─────────────────────────────────────────────────────────────────────────────

def relation(
    fields: List[str],
    references: List[str],
    backref: str,
    onDelete: CascadeAction = 'cascade',
    onUpdate: CascadeAction = 'cascade',
) -> Relation:
    """
    Factory to define an explicit relation in declarative schemas.

    Must be used on the table that holds the FK columns.

    Examples:
        author: User = relation(fields=['author_id'], references=['id'], backref='posts')
    """
    return Relation(
        fields=fields,
        references=references,
        backref=backref,
        on_delete=onDelete,
        on_update=onUpdate,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _has_create_triggers(model: Table, visited: Optional[Set] = None) -> bool:
    """Check if model or any descendant has @on_create triggers (BFS, cycle-safe)."""
    if visited is None:
        visited = set()
    if model in visited:
        return False
    visited.add(model)

    if model.triggers.get('create'):
        return True

    for rel in model.relations.values():
        if _has_create_triggers(rel.target, visited):
            return True

    return False
