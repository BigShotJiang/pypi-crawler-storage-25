# -*- coding: utf-8 -*-
"""
Encoder configuration layer for vector columns.

THIS MODULE IS FOR SCHEMA DECLARATION ONLY.
It provides encoder descriptors used inside vector_column() to annotate which
encoder should be associated with a column. No actual encoding happens here.

The actual encoder classes (BaseEncoder, SentenceTransformerEncoder) are
generated into _shared/utils/encoders.py by PythonClientGenerator and are
completely self-contained — they do not import from tai_sql.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import List, Literal


class BaseEncoder(ABC):
    """
    Abstract encoder descriptor. Used only at schema-definition time to declare
    what encoder model should be associated with a vector column.

    The get_config() method provides the serializable config that generators use
    to emit the correct encoder instantiation in _shared/utils/encoders.py.
    """

    @abstractmethod
    def get_config(self) -> dict:
        """Return serializable config used by generators to reconstruct this encoder."""
        ...

    @property
    @abstractmethod
    def dimensions(self) -> int:
        """Number of dimensions this encoder produces (used for column validation)."""
        ...


ModelTypes = Literal[
    'all-MiniLM-L6-v2',
    'all-MiniLM-L12-v2',
    'paraphrase-MiniLM-L6-v2',
    'paraphrase-MiniLM-L12-v2',
    'all-mpnet-base-v2',
    'paraphrase-mpnet-base-v2',
    'paraphrase-multilingual-MiniLM-L12-v2',
    'paraphrase-multilingual-mpnet-base-v2',
    'distiluse-base-multilingual-cased-v2',
    'all-distilroberta-v1',
    'multi-qa-MiniLM-L6-cos-v1',
    'multi-qa-mpnet-base-cos-v1',
    'multi-qa-mpnet-base-dot-v1',
    'msmarco-MiniLM-L-6-v3',
    'msmarco-distilbert-base-v4',
]


class SentenceTransformerEncoder(BaseEncoder):
    """
    Configuration descriptor for sentence-transformers encoder columns.

    Use inside vector_column() to declare which model encodes the column:

        embedding: VectorColumn = vector_column(
            source='content',
            encoder=SentenceTransformerEncoder('all-MiniLM-L6-v2'),
        )

    This class does NOT load sentence-transformers at import time and does NOT
    perform any encoding. Its sole purpose is to carry the model name and
    dimension information for the generator to emit the correct code.
    """

    # Known models → output dimensions. Avoids loading the model just to know
    # how many dimensions it produces, which is needed for column validation.
    KNOWN_MODELS: dict[str, int] = {
        # ── MiniLM family ─────────────────────────────────────────────
        'all-MiniLM-L6-v2':        384,
        'all-MiniLM-L12-v2':       384,
        'paraphrase-MiniLM-L6-v2': 384,
        'paraphrase-MiniLM-L12-v2':384,
        # ── MPNet family ──────────────────────────────────────────────
        'all-mpnet-base-v2':       768,
        'paraphrase-mpnet-base-v2':768,
        # ── Multilingual ──────────────────────────────────────────────
        'paraphrase-multilingual-MiniLM-L12-v2': 384,
        'paraphrase-multilingual-mpnet-base-v2': 768,
        'distiluse-base-multilingual-cased-v2':  512,
        # ── Large / specialized ───────────────────────────────────────
        'all-distilroberta-v1':    768,
        'multi-qa-MiniLM-L6-cos-v1':  384,
        'multi-qa-mpnet-base-cos-v1': 768,
        'multi-qa-mpnet-base-dot-v1': 768,
        'msmarco-MiniLM-L-6-v3':     384,
        'msmarco-distilbert-base-v4': 768,
    }

    def __init__(self, model: ModelTypes = 'all-MiniLM-L6-v2'):
        self._model_name = model
        self._dimensions: int | None = self.KNOWN_MODELS.get(model)

    @property
    def dimensions(self) -> int:
        if self._dimensions is not None:
            return self._dimensions
        raise ValueError(
            f"Unknown model '{self._model_name}'. Provide dimensions= explicitly in vector_column()."
        )

    def get_config(self) -> dict:
        return {'class': 'SentenceTransformerEncoder', 'model': self._model_name}

