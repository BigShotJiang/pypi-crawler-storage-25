# -*- coding: utf-8 -*-
"""
V2 type annotations for tai-sql declarative syntax.

Provides generic bracket-notation types for columns and relations:
    - col[T]           → Column with type T
    - col[T | None]    → Nullable column with type T
    - onetomany[Model] → One-to-many relation
    - manytoone[Model] → Many-to-one relation
    - onetoone[Model]  → One-to-one relation
"""
from __future__ import annotations
from typing import Any, Generic, Union, TypeVar, TYPE_CHECKING, get_args, get_origin
import types

_T = TypeVar('_T')


# =============================================================================
# Resolved type containers — always available (both runtime and type-checking)
# =============================================================================

class _ColType:
    """
    Resolved type from col[T]. Carries the inner type and nullable flag.
    Used by analyze_columns() to extract type info.
    """
    __slots__ = ('inner', 'nullable')

    def __init__(self, inner: Any, nullable: bool = False):
        self.inner = inner
        self.nullable = nullable

    def __repr__(self) -> str:
        if self.nullable:
            return f"col[{self.inner.__name__ if hasattr(self.inner, '__name__') else self.inner} | None]"
        return f"col[{self.inner.__name__ if hasattr(self.inner, '__name__') else self.inner}]"

    def __eq__(self, other):
        if isinstance(other, _ColType):
            return self.inner == other.inner and self.nullable == other.nullable
        return NotImplemented

    def __hash__(self):
        return hash((self.inner, self.nullable))


if TYPE_CHECKING:
    # At type-check time (Pylance, mypy), the metaclass __getitem__ trick
    # is invisible — the checker never executes it. We provide Generic[_T]
    # stubs so that col[str], onetomany[Post], etc. are recognized as valid
    # subscript expressions. At runtime the else-branch metaclass versions
    # handle the actual bracket resolution.

    class col(Generic[_T]):
        """
        Declaración tipada de columna de base de datos.

        El parámetro de tipo ``T`` determina el tipo de dato de la columna.
        Acepta tipos Python nativos (``str``, ``int``, ``float``, ``bool``,
        ``datetime``, ``dict``, …), tipos SQLAlchemy registrados (``bigint``,
        ``text``, …) y subclases de ``Enum``.

        Soporta nullable mediante unión con ``None``: ``col[T | None]``
        indica que la columna admite valores nulos.

        Puede combinarse con ``column()`` para añadir restricciones
        (primary key, unique, default, autoincrement, encrypt, …)
        o usarse sin ella para columnas simples sin configuración adicional.
        """

    class onetomany(Generic[_T]):
        """
        Relación uno-a-muchos (lado inverso / implícito).

        Se coloca en la tabla padre — la que **no** contiene la foreign key.
        No requiere ``relation()``; la resolución de campos se realiza
        automáticamente a partir de la relación explícita definida
        en la tabla hija mediante ``manytoone``.
        """

    class manytoone(Generic[_T]):
        """
        Relación muchos-a-uno (lado propietario con foreign key).

        Se coloca en la tabla que **contiene** la columna foreign key.
        Requiere una llamada a ``relation()`` que declare los campos
        locales (``fields``), las referencias en la tabla destino
        (``references``) y el nombre de la relación inversa (``backref``).
        """

    class onetoone(Generic[_T]):
        """
        Relación uno-a-uno.

        El lado que contiene la foreign key se declara con ``relation()``,
        igual que ``manytoone``. El lado inverso es implícito y no necesita
        ``relation()``. Ambos lados usan ``onetoone[T]``; la presencia o
        ausencia de ``relation()`` determina cuál es el propietario de la FK.
        """

else:

    # =========================================================================
    # Sentinel markers — these are what get_type_hints() sees
    # =========================================================================

    class _ColMeta(type):
        """
        Metaclass for col that supports col[T] bracket syntax.
        
        col[str]        → _ColType(inner=str, nullable=False)
        col[str | None] → _ColType(inner=str, nullable=True)
        col[Optional[str]] → _ColType(inner=str, nullable=True)
        """
        def __getitem__(cls, item) -> _ColType:
            # Handle col[T | None] / col[Optional[T]]
            origin = get_origin(item)
            if origin is Union or isinstance(item, types.UnionType):
                args = get_args(item)
                if len(args) == 2 and type(None) in args:
                    inner = args[0] if args[1] is type(None) else args[1]
                    return _ColType(inner=inner, nullable=True)
            return _ColType(inner=item, nullable=False)


    class col(metaclass=_ColMeta):
        pass


    # =========================================================================
    # Relation type annotations
    # =========================================================================

    class _RelationMeta(type):
        """
        Metaclass for relation type annotations.
        Supports bracket syntax: onetomany[Model], manytoone[Model], onetoone[Model]
        """
        def __getitem__(cls, item) -> _RelationType:
            # Handle Optional: onetomany[Model | None] → nullable
            origin = get_origin(item)
            nullable = False
            target = item

            if origin is Union or isinstance(item, types.UnionType):
                args = get_args(item)
                if len(args) == 2 and type(None) in args:
                    target = args[0] if args[1] is type(None) else args[1]
                    nullable = True

            return _RelationType(
                target=target,
                direction=cls._direction,
                nullable=nullable
            )


    class onetomany(metaclass=_RelationMeta):
        _direction = 'one-to-many'


    class manytoone(metaclass=_RelationMeta):
        _direction = 'many-to-one'


    class onetoone(metaclass=_RelationMeta):
        _direction = 'one-to-one'


class _RelationType:
    """
    Resolved type from onetomany[T] / manytoone[T] / onetoone[T].
    Carries the target model, direction, and nullable flag.
    Used by analyze_relations() to extract relation info.
    """
    __slots__ = ('target', 'direction', 'nullable')

    def __init__(self, target: Any, direction: str, nullable: bool = False):
        self.target = target
        self.direction = direction
        self.nullable = nullable

    def __repr__(self) -> str:
        name = self.target.__name__ if hasattr(self.target, '__name__') else str(self.target)
        direction_name = {
            'one-to-many': 'onetomany',
            'many-to-one': 'manytoone',
            'one-to-one': 'onetoone',
        }[self.direction]
        return f"{direction_name}[{name}]"

    def __eq__(self, other):
        if isinstance(other, _RelationType):
            return self.target == other.target and self.direction == other.direction
        return NotImplemented

    def __hash__(self):
        return hash((self.target, self.direction))


# =============================================================================
# Helpers for detection
# =============================================================================

def is_col_type(type_hint) -> bool:
    """Check if a type hint is a V2 col[T] annotation."""
    return isinstance(type_hint, _ColType)


def is_relation_type(type_hint) -> bool:
    """Check if a type hint is a V2 relation annotation (onetomany/manytoone/onetoone)."""
    return isinstance(type_hint, _RelationType)


def is_v1_column_type(type_hint) -> bool:
    """
    Check if a V1-style type hint represents a column type (not a relation).
    
    Recognizes native Python types, time types, SQLAlchemy types, and Enums.
    Unwraps Optional[T] and List[T] wrappers.
    """
    from enum import Enum as BaseEnum
    from datetime import datetime, date, time
    from sqlalchemy import (
        Integer, String, Text, Boolean, DateTime,
        Date, Time, Float, Numeric, LargeBinary,
        BigInteger, Enum as SAEnum,
    )
    from sqlalchemy.dialects.postgresql import JSONB
    from sqlalchemy.dialects.mysql import JSON as MySQLJSON
    from sqlalchemy import JSON as GenericJSON

    _NATIVE = {
        int, str, float, bool, bytes, list, dict, set, tuple,
        type(None), complex, frozenset, bytearray, memoryview,
    }
    _TIME = {datetime, date, time}
    from .types import vector as _VectorSentinel

    _SA = {
        Integer, String, Text, Boolean, DateTime,
        Date, Time, Float, Numeric, LargeBinary,
        BigInteger, SAEnum, JSONB, MySQLJSON, GenericJSON,
        _VectorSentinel,
    }

    origin = get_origin(type_hint)

    # Unwrap Optional
    if origin is Union:
        args = get_args(type_hint)
        if len(args) == 2 and type(None) in args:
            inner = args[0] if args[1] is type(None) else args[1]
            return is_v1_column_type(inner)

    # Unwrap List[T]
    if origin in (list,):
        args = get_args(type_hint)
        if args:
            return is_v1_column_type(args[0])

    if type_hint in _NATIVE or type_hint in _TIME or type_hint in _SA:
        return True

    if isinstance(type_hint, type) and issubclass(type_hint, BaseEnum):
        return True

    return False
