# -*- coding: utf-8 -*-
"""
Feed Runner: descubre y ejecuta los métodos feed() definidos en los modelos
para poblar la base de datos con datos iniciales o de prueba.
"""
from __future__ import annotations
import sys
import os
import base64
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING
import click
from sqlalchemy import MetaData, text

if TYPE_CHECKING:
    from sqlalchemy import Engine
    from tai_sql.drivers.base import DatabaseDriver
    from tai_sql.orm.table import Table


@dataclass
class FeedEntry:
    """Entrada de feed: tabla + datos extraídos de feed()"""
    table_cls: type  # Clase Table del schema
    tablename: str
    records: List[Dict[str, Any]]  # Datos planos (columnas directas)
    nested: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)   # relation_name -> records con FK pendientes


@dataclass
class FeedPlan:
    """Plan de inserción para una tabla, ya en orden topológico"""
    tablename: str
    table_cls: type
    records: List[Dict[str, Any]]
    pk_columns: List[str]
    unique_columns: List[str]


class FeedRunner:
    """
    Descubre métodos feed() en los modelos del schema, extrae los datos,
    resuelve dependencias FK y ejecuta inserciones (upsert) en la BD.
    """

    def __init__(
        self,
        engine: Engine,
        schema_name: str,
        driver: DatabaseDriver,
        tables: List[Table],
        secret_key_name: str = 'SECRET_KEY',
    ):
        self.engine = engine
        self.schema_name = schema_name
        self.driver = driver
        self.tables = tables

        self.feeds: List[FeedEntry] = []
        self._plan: List[FeedPlan] = []
        self._table_map: Dict[str, type] = {}  # tablename -> Table cls
        self._column_map: Dict[str, Dict[str, Any]] = {}  # tablename -> {col_name: Column}
        self._relation_map: Dict[str, Dict[str, Any]] = {}  # tablename -> {relation_name: info}

        self._secret_key_name = secret_key_name
        self._cipher = self._build_cipher(secret_key_name)

    def _build_cipher(self, secret_key_name: str):
        """Construye el cifrador Fernet. Devuelve None si la variable de entorno no está definida."""
        try:
            from cryptography.fernet import Fernet
        except ImportError:
            return None

        secret_key = os.getenv(secret_key_name)
        if not secret_key:
            return None

        fernet_key = base64.urlsafe_b64encode(secret_key.encode()[:32].ljust(32, b'\0'))
        return Fernet(fernet_key)

    def _check_encryption(self) -> None:
        """
        Verifica que la SECRET_KEY esté disponible si el schema tiene columnas encrypt=True.
        Detiene la ejecución si faltan columnas encriptadas sin clave definida.
        """
        if self._cipher is not None:
            return

        encrypted_cols: Dict[str, List[str]] = {}
        for tablename, columns in self._column_map.items():
            cols = [name for name, col in columns.items() if getattr(col, 'encrypt', False)]
            if cols:
                encrypted_cols[tablename] = cols

        if not encrypted_cols:
            return

        lines = [
            f"❌ El schema tiene columnas encriptadas pero la variable de entorno "
            f"'{self._secret_key_name}' no está definida.",
            f"   Los valores se insertarían en texto plano, lo cual es un riesgo de seguridad.",
            f"",
            f"   Columnas afectadas:",
        ]
        for tablename, cols in encrypted_cols.items():
            lines.append(f"      • {tablename}: {', '.join(cols)}")
        lines += [
            f"",
            f"   Define la variable antes de ejecutar el feed:",
            f"   export {self._secret_key_name}='tu-clave-secreta-de-al-menos-32-caracteres'",
        ]

        for line in lines:
            click.echo(line, err=True)

        sys.exit(1)

    def _encrypt_value(self, value: str) -> str:
        """Encripta un valor usando Fernet. Devuelve el valor sin modificar si no hay cifrador."""
        if self._cipher is None or value is None:
            return value
        return self._cipher.encrypt(str(value).encode()).decode()

    def _encrypt_record(self, tablename: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """Encripta los campos marcados como encrypt=True antes de insertar."""
        if self._cipher is None:
            return record

        columns = self._column_map.get(tablename, {})
        encrypted = {}
        for col_name, value in record.items():
            col = columns.get(col_name)
            if col is not None and getattr(col, 'encrypt', False) and value is not None:
                encrypted[col_name] = self._encrypt_value(value)
            else:
                encrypted[col_name] = value
        return encrypted

    def _encode_vectors(self, tablename: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """Auto-encode vector columns that have an encoder and a source field."""
        from tai_sql.orm.columns import VectorColumn

        columns = self._column_map.get(tablename, {})
        for col_name, col in columns.items():
            if not isinstance(col, VectorColumn):
                continue
            if col.encoder is None or col.source is None:
                continue
            # Only encode if vector is not already provided
            if record.get(col_name) is not None:
                continue
            source_value = record.get(col.source)
            if source_value is not None:
                record[col_name] = col.encoder.encode(str(source_value))
        return record

    # ──────────────────────────────────────────────
    # 1. Discovery
    # ──────────────────────────────────────────────

    def discover(self, table_filter: Optional[str] = None) -> None:
        """
        Descubre todas las tablas con método feed() y extrae los datos.
        
        Args:
            table_filter: si se especifica, solo procesa la tabla con ese nombre
        """
        # Construir mapas de referencia
        for table_cls in self.tables:
            self._table_map[table_cls.tablename] = table_cls
            self._column_map[table_cls.tablename] = {
                col_name: col for col_name, col in table_cls.columns.items()
            }
            self._relation_map[table_cls.tablename] = {
                rel_name: rel for rel_name, rel in table_cls.relations.items()
            }

        # Verificar encriptación antes de proceder
        self._check_encryption()

        # Descubrir feeds en orden topológico
        ordered_tables = self._topological_sort()

        for table_cls in ordered_tables:
            if table_filter and table_cls.tablename != table_filter:
                continue

            # Verificar si la clase tiene su propio método feed (no heredado)
            if 'feed' not in table_cls.__dict__:
                continue

            feed_fn = table_cls.__dict__['feed']
            # Invocar feed() - self no se usa, pasamos None
            try:
                raw_instances = feed_fn(None)
            except Exception as e:
                click.echo(f"⚠️  Error al ejecutar {table_cls.__name__}.feed(): {e}", err=True)
                continue

            if not raw_instances:
                continue

            # Validar tipo de retorno
            if not isinstance(raw_instances, list):
                click.echo(
                    f"⚠️  {table_cls.__name__}.feed() debe retornar List[{table_cls.__name__}], "
                    f"pero retornó {type(raw_instances).__name__}",
                    err=True,
                )
                continue

            invalid = [
                (i, type(item).__name__)
                for i, item in enumerate(raw_instances)
                if not isinstance(item, table_cls)
            ]
            if invalid:
                positions = ", ".join(f"[{i}] {t}" for i, t in invalid)
                click.echo(
                    f"⚠️  {table_cls.__name__}.feed() contiene elementos que no son "
                    f"instancias de {table_cls.__name__}: {positions}",
                    err=True,
                )
                sys.exit(1)

            entry = self._extract_feed_entry(table_cls, raw_instances)
            if entry.records:
                self.feeds.append(entry)

        # Construir plan de inserción
        self._build_plan()

    def _extract_feed_entry(self, table_cls, instances: list) -> FeedEntry:
        """Extrae datos de las instancias retornadas por feed()"""
        column_names = set(self._column_map[table_cls.tablename].keys())
        relation_names = set(self._relation_map[table_cls.tablename].keys())

        records = []
        nested_records: Dict[str, list] = {}  

        for instance in instances:
            record = {}
            instance_attrs = vars(instance) if hasattr(instance, '__dict__') else {}

            # Extraer columnas directas
            for attr_name, attr_value in instance_attrs.items():
                if attr_name.startswith('_'):
                    continue
                if attr_name in column_names:
                    record[attr_name] = attr_value

            records.append(record)

            # Extraer relaciones anidadas (cascada)
            for attr_name, attr_value in instance_attrs.items():
                if attr_name in relation_names and isinstance(attr_value, list):
                    rel = self._relation_map[table_cls.tablename][attr_name]
                    target_cls = rel.target
                    target_tablename = target_cls.tablename

                    if target_tablename not in nested_records:
                        nested_records[target_tablename] = []

                    # Necesitamos inyectar la FK del padre
                    fk_mapping = self._get_fk_mapping(table_cls, rel)

                    target_column_names = set(self._column_map.get(target_tablename, {}).keys())

                    for child_instance in attr_value:
                        child_record = {}
                        child_attrs = vars(child_instance) if hasattr(child_instance, '__dict__') else {}

                        for child_attr, child_val in child_attrs.items():
                            if child_attr.startswith('_'):
                                continue
                            if child_attr in target_column_names:
                                child_record[child_attr] = child_val

                        # Inyectar FK: el padre aún no tiene PK (se genera en BD),
                        # así que marcamos con un placeholder que se resolverá en execute()
                        for local_col, ref_col in fk_mapping.items():
                            # Si el usuario ya proporcionó un valor explícito para la FK, respetarlo
                            if local_col in child_record and child_record[local_col] is not None:
                                continue
                            child_record[f'__fk_ref__{local_col}'] = {
                                'parent_table': table_cls.tablename,
                                'parent_column': ref_col,
                                'parent_record_index': len(records) - 1,
                            }

                        # Procesar sub-relaciones recursivamente
                        # El índice del child en nested_records[target_tablename] (global)
                        child_index_in_nested = len(nested_records[target_tablename])
                        nested_records[target_tablename].append(child_record)

                        self._extract_nested_into(
                            target_cls, child_instance,
                            nested_records,
                            parent_table=target_tablename,
                            parent_index=child_index_in_nested,
                        )

        return FeedEntry(
            table_cls=table_cls,
            tablename=table_cls.tablename,
            records=records,
            nested=nested_records,
        )

    def _extract_nested_into(
        self,
        table_cls,
        instance,
        nested_records: Dict[str, list],
        parent_table: str,
        parent_index: int,
    ) -> None:
        """
        Recursivamente extrae hijos anidados y los inserta directamente en nested_records (global).
        Esto garantiza que parent_record_index siempre referencia el índice correcto.
        
        Args:
            table_cls: Clase Table del padre actual
            instance: Instancia del padre
            nested_records: dict global {tablename: [records]} (se modifica in-place)
            parent_table: tablename del padre directo de esta instancia
            parent_index: índice del padre en nested_records[parent_table]
        """
        relation_names = set(self._relation_map.get(table_cls.tablename, {}).keys())
        instance_attrs = vars(instance) if hasattr(instance, '__dict__') else {}

        for attr_name, attr_value in instance_attrs.items():
            if attr_name in relation_names and isinstance(attr_value, list):
                rel = self._relation_map[table_cls.tablename][attr_name]
                target_cls = rel.target
                target_tablename = target_cls.tablename
                target_column_names = set(self._column_map.get(target_tablename, {}).keys())
                fk_mapping = self._get_fk_mapping(table_cls, rel)

                if target_tablename not in nested_records:
                    nested_records[target_tablename] = []

                for child_instance in attr_value:
                    child_record = {}
                    child_attrs = vars(child_instance) if hasattr(child_instance, '__dict__') else {}

                    for child_attr, child_val in child_attrs.items():
                        if child_attr.startswith('_'):
                            continue
                        if child_attr in target_column_names:
                            child_record[child_attr] = child_val

                    # FK apunta al padre en nested_records con su índice global
                    for local_col, ref_col in fk_mapping.items():
                        # Si el usuario ya proporcionó un valor explícito para la FK, respetarlo
                        if local_col in child_record and child_record[local_col] is not None:
                            continue
                        child_record[f'__fk_ref__{local_col}'] = {
                            'parent_table': table_cls.tablename,
                            'parent_column': ref_col,
                            'parent_record_index': parent_index,
                        }

                    child_index = len(nested_records[target_tablename])
                    nested_records[target_tablename].append(child_record)

                    # Recurse
                    self._extract_nested_into(
                        target_cls, child_instance,
                        nested_records,
                        parent_table=target_tablename,
                        parent_index=child_index,
                    )

    def _get_fk_mapping(self, parent_cls, relation) -> Dict[str, str]:
        """
        Devuelve {child_fk_column -> parent_pk_column} para una relación.
        Si la relación es one-to-many (backref), los fields/references están en el hijo.
        """
        # Para relaciones 1:N con backref, la FK está definida en la relación inversa
        target_cls = relation.target
        
        # Buscar en las foreign_keys del target que apunten al parent
        for fk in target_cls.foreign_keys:
            if fk.relation.target == parent_cls or fk.relation.target.__name__ == parent_cls.__name__:
                return dict(zip(fk.relation.fields, fk.relation.references))

        # Fallback: buscar si la relación tiene fields/references directos
        if hasattr(relation, 'fields') and hasattr(relation, 'references') and relation.fields:
            return dict(zip(relation.fields, relation.references))

        return {}

    # ──────────────────────────────────────────────
    # 2. Topological sort
    # ──────────────────────────────────────────────

    def _topological_sort(self) -> List[type]:
        """
        Ordena las tablas topológicamente por dependencias FK.
        Tablas sin dependencias primero (padres antes que hijos).
        """
        # Construir grafo de dependencias
        in_degree = {t.tablename: 0 for t in self.tables}
        graph: Dict[str, List[str]] = {t.tablename: [] for t in self.tables}

        for table_cls in self.tables:
            for fk in table_cls.foreign_keys:
                parent_table = fk.relation.target.tablename
                if parent_table in in_degree and parent_table != table_cls.tablename:
                    graph[parent_table].append(table_cls.tablename)
                    in_degree[table_cls.tablename] += 1

        # BFS (Kahn's algorithm)
        queue = [name for name, deg in in_degree.items() if deg == 0]
        ordered = []

        while queue:
            current = queue.pop(0)
            ordered.append(current)
            for neighbor in graph.get(current, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Fallback: agregar tablas restantes (ciclos)
        for t in self.tables:
            if t.tablename not in ordered:
                ordered.append(t.tablename)

        return [self._table_map[name] for name in ordered if name in self._table_map]

    # ──────────────────────────────────────────────
    # 3. Build Plan
    # ──────────────────────────────────────────────

    def _build_plan(self) -> None:
        """Construye el plan de inserción a partir de los feeds descubiertos"""
        # Recopilar todos los registros por tabla, incluyendo nested
        all_records: Dict[str, List[Dict[str, Any]]] = {}
        
        for entry in self.feeds:
            if entry.tablename not in all_records:
                all_records[entry.tablename] = []
            all_records[entry.tablename].extend(entry.records)

            for nested_table, nested_recs in entry.nested.items():
                if nested_table not in all_records:
                    all_records[nested_table] = []
                all_records[nested_table].extend(nested_recs)

        # Crear plan en orden topológico
        ordered = self._topological_sort()
        self._plan = []

        for table_cls in ordered:
            if table_cls.tablename not in all_records:
                continue

            records = all_records[table_cls.tablename]
            if not records:
                continue

            pk_columns = [
                col_name for col_name, col in table_cls.columns.items()
                if col.constraints.primary_key
            ]
            unique_columns = [
                col_name for col_name, col in table_cls.columns.items()
                if col.constraints.unique
            ]

            self._plan.append(FeedPlan(
                tablename=table_cls.tablename,
                table_cls=table_cls,
                records=records,
                pk_columns=pk_columns,
                unique_columns=unique_columns,
            ))

    # ──────────────────────────────────────────────
    # 4. Show
    # ──────────────────────────────────────────────

    def show(self, verbose: bool = False) -> None:
        """Muestra el plan de inserción"""
        click.echo("📋 Plan de Feed:")
        click.echo()

        for plan in self._plan:
            has_fk_refs = any(
                any(k.startswith('__fk_ref__') for k in record)
                for record in plan.records
            )
            cascade_label = " (cascada)" if has_fk_refs else ""

            click.echo(f"   📦 {plan.tablename}: {len(plan.records)} registro(s){cascade_label}")
            if verbose:
                for i, record in enumerate(plan.records):
                    # Mostrar solo columnas directas (sin __fk_ref__)
                    display = {k: v for k, v in record.items() if not k.startswith('__fk_ref__')}
                    click.echo(f"      [{i+1}] {display}")

                    if verbose:
                        # Mostrar columnas de referencia FK
                        fk_display = {k: v for k, v in record.items() if k.startswith('__fk_ref__')}
                        if fk_display:
                            click.echo(f"         🔗 FK refs: {fk_display}")

    # ──────────────────────────────────────────────
    # 5. Clean
    # ──────────────────────────────────────────────

    def clean(self) -> None:
        """TRUNCATE CASCADE las tablas que serán alimentadas"""
        click.echo("🧹 Limpiando tablas...")
        click.echo()

        # Limpiar en orden inverso (hijos antes que padres)
        tables_to_clean = [plan.tablename for plan in reversed(self._plan)]

        with self.engine.connect() as conn:
            for tablename in tables_to_clean:
                full_name = f"{self.schema_name}.{tablename}"
                try:
                    conn.execute(text(f'TRUNCATE TABLE {full_name} CASCADE'))
                    conn.commit()
                    click.echo(f"   🗑️  TRUNCATE {full_name} CASCADE")
                except Exception as e:
                    conn.rollback()
                    click.echo(f"   ⚠️  Error al truncar {full_name}: {e}", err=True)

    # ──────────────────────────────────────────────
    # 6. Execute
    # ──────────────────────────────────────────────

    def execute(self) -> None:
        """Ejecuta el plan de inserción (upsert) en la BD"""
        # Almacén de registros insertados: {tablename -> [{col: val, ...}]}
        # Incluye PKs generadas + columnas del record original para resolver FKs
        generated_pks: Dict[str, List[Dict[str, Any]]] = {}

        metadata = MetaData(schema=self.schema_name)
        metadata.reflect(bind=self.engine, schema=self.schema_name)

        with self.engine.connect() as conn:
            for plan in self._plan:
                full_tablename = f"{self.schema_name}.{plan.tablename}"
                sa_table = metadata.tables.get(full_tablename)

                if sa_table is None:
                    click.echo(f"   ⚠️  Tabla {full_tablename} no encontrada en la BD, saltando", err=True)
                    continue

                generated_pks[plan.tablename] = []
                inserted_count = 0
                updated_count = 0

                for record in plan.records:
                    # Resolver FK references
                    resolved_record = self._resolve_fk_refs(record, generated_pks)

                    # Rellenar defaults para columnas faltantes que no son nullable
                    resolved_record = self._fill_defaults(plan.tablename, resolved_record)

                    # Filtrar columnas autoincrement de la inserción
                    insert_record = {}
                    for col_name, col_value in resolved_record.items():
                        col_meta = self._column_map.get(plan.tablename, {}).get(col_name)
                        if col_meta and col_meta.constraints.autoincrement:
                            # Solo incluir autoincrement si el usuario proporcionó un valor explícito
                            if col_value is not None:
                                insert_record[col_name] = col_value
                        else:
                            insert_record[col_name] = col_value

                    # Encriptar columnas marcadas como encrypt=True
                    insert_record = self._encrypt_record(plan.tablename, insert_record)

                    # Auto-encode vector columns with encoder
                    insert_record = self._encode_vectors(plan.tablename, insert_record)

                    # Ejecutar upsert
                    result_pk = self._upsert_record(
                        conn, sa_table, plan, insert_record
                    )

                    # Combinar PKs generadas con el record insertado para que
                    # los hijos puedan resolver FKs a cualquier columna del padre
                    full_record = {**insert_record, **result_pk}
                    generated_pks[plan.tablename].append(full_record)
                    if result_pk.get('__was_update'):
                        updated_count += 1
                    else:
                        inserted_count += 1

                conn.commit()

                parts = []
                if inserted_count:
                    parts.append(f"{inserted_count} insertado(s)")
                if updated_count:
                    parts.append(f"{updated_count} actualizado(s)")
                summary = ", ".join(parts) if parts else "0 cambios"

                click.echo(f"   ✅ {plan.tablename}: {summary}")

    def _resolve_fk_refs(
        self,
        record: Dict[str, Any],
        generated_pks: Dict[str, List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        """Resuelve las FK pendientes (placeholders __fk_ref__) con los PKs generados"""
        resolved = {}

        for key, value in record.items():
            if key.startswith('__fk_ref__'):
                actual_col = key.replace('__fk_ref__', '')
                ref_info = value
                parent_table = ref_info['parent_table']
                parent_col = ref_info['parent_column']
                parent_idx = ref_info['parent_record_index']

                pks = generated_pks.get(parent_table, [])
                if 0 <= parent_idx < len(pks):
                    resolved[actual_col] = pks[parent_idx].get(parent_col)
                elif pks:
                    # Fallback: usar el último PK generado para esa tabla
                    resolved[actual_col] = pks[-1].get(parent_col)
                # Si no hay PKs disponibles, no incluir la FK (NULL o error)
            else:
                resolved[key] = value

        return resolved

    def _fill_defaults(self, tablename: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        Rellena valores por defecto del schema para columnas faltantes en el registro.
        Solo aplica a columnas NOT NULL que no son autoincrement y tienen default definido.
        """
        from datetime import datetime as dt

        columns = self._column_map.get(tablename, {})

        for col_name, col in columns.items():
            if col_name in record:
                continue  # Ya tiene valor, no tocar

            if col.constraints.autoincrement:
                continue  # Lo genera la BD

            if col.nullable:
                continue  # NULL es válido

            # Tiene default en el schema
            if col.constraints.default is not None:
                default_val = col.constraints.default

                # Resolver callables (datetime.now, etc.)
                if callable(default_val):
                    try:
                        default_val = default_val()
                    except Exception:
                        continue

                # Resolver string representations de datetime
                if isinstance(default_val, str):
                    if default_val in ('datetime.now', 'datetime.today'):
                        default_val = dt.now()

                record[col_name] = default_val

        return record

    def _upsert_record(
        self,
        conn,
        sa_table,
        plan: FeedPlan,
        record: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Ejecuta un upsert para un registro individual.
        Devuelve un dict con las PKs del registro insertado/actualizado.
        """
        dialect_name = self.engine.dialect.name

        # Determinar columnas de conflicto (PK o UNIQUE)
        conflict_columns = plan.pk_columns.copy()
        # Solo usar PK si el registro tiene esas columnas
        has_conflict_cols = all(col in record and record[col] is not None for col in conflict_columns)

        if not has_conflict_cols and plan.unique_columns:
            conflict_columns = plan.unique_columns
            has_conflict_cols = all(col in record and record[col] is not None for col in conflict_columns)

        result_pk = {}

        if dialect_name in ('postgresql', 'sqlite') and has_conflict_cols:
            result_pk = self._upsert_postgresql(conn, sa_table, plan, record, conflict_columns)
        elif dialect_name == 'mysql' and has_conflict_cols:
            result_pk = self._upsert_mysql(conn, sa_table, plan, record)
        elif dialect_name == 'mssql' and has_conflict_cols:
            result_pk = self._upsert_mssql(conn, sa_table, plan, record, conflict_columns)
        else:
            # Fallback: insert simple
            result_pk = self._insert_simple(conn, sa_table, plan, record)

        return result_pk

    def _upsert_postgresql(self, conn, sa_table, plan, record, conflict_columns):
        """Upsert para PostgreSQL usando INSERT ... ON CONFLICT DO UPDATE"""
        from sqlalchemy.dialects.postgresql import insert as pg_insert

        stmt = pg_insert(sa_table).values(**record)

        update_cols = {k: v for k, v in record.items() if k not in conflict_columns}

        if update_cols:
            stmt = stmt.on_conflict_do_update(
                index_elements=conflict_columns,
                set_=update_cols,
            )
        else:
            stmt = stmt.on_conflict_do_nothing(index_elements=conflict_columns)

        # RETURNING para obtener PKs
        pk_cols = [sa_table.c[pk] for pk in plan.pk_columns if pk in sa_table.c]
        if pk_cols:
            stmt = stmt.returning(*pk_cols)

        result = conn.execute(stmt)

        if pk_cols:
            row = result.fetchone()
            if row:
                pk_dict = {plan.pk_columns[i]: row[i] for i in range(len(plan.pk_columns))}
                if update_cols:
                    pk_dict['__was_update'] = True
                return pk_dict

        return {pk: record.get(pk) for pk in plan.pk_columns}

    def _upsert_mysql(self, conn, sa_table, plan, record):
        """Upsert para MySQL usando INSERT ... ON DUPLICATE KEY UPDATE"""
        from sqlalchemy.dialects.mysql import insert as mysql_insert

        stmt = mysql_insert(sa_table).values(**record)

        update_cols = {k: stmt.inserted[k] for k in record if k not in plan.pk_columns}
        if update_cols:
            stmt = stmt.on_duplicate_key_update(**update_cols)

        result = conn.execute(stmt)

        pk_dict = {}
        for pk in plan.pk_columns:
            if pk in record and record[pk] is not None:
                pk_dict[pk] = record[pk]
            elif result.inserted_primary_key:
                pk_dict[pk] = result.inserted_primary_key[0]

        return pk_dict

    def _upsert_mssql(self, conn, sa_table, plan, record, conflict_columns):
        """Upsert para SQL Server usando MERGE"""
        full_name = f"{self.schema_name}.{plan.tablename}"
        columns = list(record.keys())
        values = list(record.values())

        on_clause = " AND ".join(
            f"target.[{col}] = source.[{col}]" for col in conflict_columns
        )
        update_set = ", ".join(
            f"target.[{col}] = source.[{col}]" 
            for col in columns if col not in conflict_columns
        )
        insert_cols = ", ".join(f"[{c}]" for c in columns)
        insert_vals = ", ".join(f"source.[{c}]" for c in columns)
        source_cols = ", ".join(f":{c} AS [{c}]" for c in columns)

        merge_sql = f"""
        MERGE {full_name} AS target
        USING (SELECT {source_cols}) AS source
        ON {on_clause}
        WHEN MATCHED THEN
            UPDATE SET {update_set}
        WHEN NOT MATCHED THEN
            INSERT ({insert_cols}) VALUES ({insert_vals})
        OUTPUT inserted.*;
        """

        params = {columns[i]: values[i] for i in range(len(columns))}
        result = conn.execute(text(merge_sql), params)

        row = result.fetchone()
        if row:
            return {pk: getattr(row, pk, None) for pk in plan.pk_columns}

        return {pk: record.get(pk) for pk in plan.pk_columns}

    def _insert_simple(self, conn, sa_table, plan, record):
        """Insert simple cuando no hay columnas de conflicto"""
        stmt = sa_table.insert().values(**record)

        pk_cols = [sa_table.c[pk] for pk in plan.pk_columns if pk in sa_table.c]
        
        # RETURNING para PostgreSQL/SQLite
        if self.engine.dialect.name in ('postgresql', 'sqlite') and pk_cols:
            stmt = stmt.returning(*pk_cols)
            result = conn.execute(stmt)
            row = result.fetchone()
            if row:
                return {plan.pk_columns[i]: row[i] for i in range(len(plan.pk_columns))}
        else:
            result = conn.execute(stmt)
            if result.inserted_primary_key:
                return {plan.pk_columns[0]: result.inserted_primary_key[0]}

        return {pk: record.get(pk) for pk in plan.pk_columns}
