import sys
import click
from sqlalchemy import text
from sqlalchemy.exc import OperationalError, ProgrammingError

from .connectivity import db_exist, schema_exists
from tai_sql import pm
from tai_sql.core import Provider
from tai_sql.drivers import DatabaseDriver


def createdb(provider: Provider) -> bool:
    """
    Crea una base de datos usando el driver específico
    
    Args:
        provider: Proveedor de la base de datos
        
    Returns:
        bool: True si se creó exitosamente o ya existía
    """
    try:

        if db_exist(provider):
            return True
        
        click.echo(f"🚀 Creando base de datos: {provider.database}")

        # Usar la sentencia específica del driver
        create_statement = provider.driver.create_database_statement(provider.database)
        
        with provider.adminengine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            conn.execute(text(create_statement))
        
        click.echo(f"✅ Base de datos '{provider.database}' creada exitosamente")
        return True
        
    except ValueError as e:
        # Error de driver no soportado
        click.echo(f"❌ {e}", err=True)
        sys.exit(1)
    except OperationalError as e:
        if "already exists" in str(e) or "exists" in str(e):
            click.echo(f"ℹ️  La base de datos '{provider.database}' ya existe")
            return True
        else:
            click.echo(f"❌ Error al crear base de datos: {e}", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error inesperado al crear base de datos: {e}", err=True)
        sys.exit(1)


def createschema(provider: Provider) -> bool:
    """
    Crea un schema usando el driver específico
    
    Args:
        provider: Proveedor de la base de datos
        
    Returns:
        bool: True si se creó exitosamente o ya existía
    """
    try:
        
        # Verificar si el driver soporta schemas
        if not provider.driver.supports_schemas():
            click.echo(f"ℹ️  El motor {provider.driver.name} no requiere schemas separados")
            return True
        
        # Verificar si ya existe
        if schema_exists(provider):
            return True
        
        click.echo(f"🚀 Creando schema: {provider.schema_name}")
        
        # Usar la sentencia específica del driver
        create_statement = provider.driver.create_schema_statement(provider.schema_name)
        
        with provider.engine.connect() as conn:
            conn = conn.execution_options(autocommit=True)
            conn.execute(text(create_statement))
            conn.execute(text("COMMIT"))
        
        click.echo(f"✅ Schema '{provider.schema_name}' creado exitosamente")
        return True
        
    except ValueError as e:
        # Error de driver no soportado
        click.echo(f"❌ {e}", err=True)
        return False
    except (OperationalError, ProgrammingError) as e:
        if "already exists" in str(e) or "exists" in str(e):
            click.echo(f"ℹ️  El schema '{provider.schema_name}' ya existe")
            return True
        else:
            click.echo(f"❌ Error al crear schema: {e}", err=True)
            return False
    except Exception as e:
        click.echo(f"❌ Error inesperado al crear schema: {e}", err=True)
        return False
