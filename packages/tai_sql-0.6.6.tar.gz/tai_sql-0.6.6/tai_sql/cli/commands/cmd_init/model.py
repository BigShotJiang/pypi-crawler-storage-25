import subprocess
import sys
import os
from pathlib import Path
from textwrap import dedent
import click

from tai_sql import pm
from ..cmd_schema import NewSchemaCommand

PYPROJECT_TEMPLATE = dedent('''\
    [project]
    name = "{name}"
    version = "0.1.0"
    description = ""
    readme = "README.md"
    requires-python = "<4.0,>=3.10"
    dependencies = [
        "sqlalchemy (>=2.0.42,<3.0)",
        "pydantic (>=2.11.7,<3.0)",
        "tai-alphi (>=2.0.1,<3.0)",
        "rich (>=14.0.0,<15.0)"
    ]

    [project.optional-dependencies]
    # Drivers síncronos (elige según tu base de datos)
    postgresql = ["psycopg2-binary (>=2.9.10,<3.0)"]
    mysql = ["pymysql (>=1.1.1,<2.0)"]
    sqlserver = ["pyodbc (>=5.2.0,<6.0)"]

    # Drivers asíncronos
    postgresql-async = ["asyncpg (>=0.30.0,<1.0)"]
    mysql-async = ["aiomysql (>=0.2.0,<1.0)"]
    sqlserver-async = ["aioodbc (>=0.5.0,<1.0)"]

    # Funcionalidades opcionales
    encryption = ["cryptography (>=45.0.4,<46.0)"]
    vectors = ["pgvector (>=0.4.0,<1.0)"]
    vectors-encoding = ["pgvector (>=0.4.0,<1.0)", "sentence-transformers (>=3.0.0,<4.0)"]

    [build-system]
    requires = ["poetry-core>=2.0.0,<3.0.0"]
    build-backend = "poetry.core.masonry.api"
''')

README_TEMPLATE = dedent('''\
    # {name}

    Proyecto generado con [tai-sql](https://github.com/triplealpha-innovation/tai-sql).

    ## Setup

    ```bash
    cd {name}
    poetry install
    ```
''')


class InitCommand:

    def __init__(self, namespace: str, schema_name: str):
        self.namespace = namespace
        self.schema_name = schema_name
    
    @property
    def subnamespace(self) -> str:
        """Retorna el subnamespace basado en el namespace"""
        return self.namespace.replace('-', '_')
    
    def check_directory_is_avaliable(self):
        """Verifica que el directorio del proyecto no exista"""
        if os.path.exists(self.namespace):
            click.echo(f"❌ Error: el directorio '{self.namespace}' ya existe", err=True)
            sys.exit(1)
    
    def create_project(self):
        """Crea la estructura del proyecto y genera el pyproject.toml"""
        click.echo(f"🚀 Creando '{self.namespace}'...")
        
        project_root = Path(self.namespace)
        project_root.mkdir(parents=True)
        
        # Crear paquete Python
        package_dir = project_root / self.subnamespace
        package_dir.mkdir()
        (package_dir / '__init__.py').write_text('', encoding='utf-8')
        
        # Generar pyproject.toml
        pyproject_content = PYPROJECT_TEMPLATE.format(name=self.namespace)
        (project_root / 'pyproject.toml').write_text(pyproject_content, encoding='utf-8')
        
        # Generar README.md
        readme_content = README_TEMPLATE.format(name=self.namespace)
        (project_root / 'README.md').write_text(readme_content, encoding='utf-8')
        
        click.echo(f"   ✅ Estructura del proyecto creada")
    
    def add_folders(self) -> None:
        """Crea la estructura adicional del proyecto"""
        new_schema = NewSchemaCommand(self.namespace, self.schema_name)
        new_schema.create()
        # Crear directorio para los diagramas
        diagrams_dir = Path(self.namespace) / 'diagrams'
        diagrams_dir.mkdir(parents=True, exist_ok=True)

    def create_project_config(self) -> None:
        """Crea el archivo .taisqlproject con la configuración inicial"""
        try:
            project_root = Path(self.namespace)
            pm.create_config(
                name=self.namespace,
                project_root=project_root,
                default_schema=self.schema_name
            )
            
        except Exception as e:
            click.echo(f"❌ Error al crear configuración del proyecto: {e}", err=True)
            sys.exit(1)

    def install_dependencies(self) -> bool:
        """Instala las dependencias del proyecto con poetry install. Retorna True si tuvo éxito."""
        # Verificar Poetry
        try:
            result = subprocess.run(['poetry', '--version'], check=True, capture_output=True, text=True)
            version_output = result.stdout.strip()
            version_str = version_output.split('(version ')[-1].rstrip(')')
            version_parts = version_str.split('.')
            major, minor, patch = int(version_parts[0]), int(version_parts[1]), int(version_parts[2])
            
            if (major, minor, patch) < (2, 2, 1):
                click.echo(f"   ⚠️  Poetry versión {version_str} encontrada, se requiere >= 2.2.1", err=True)
                return False
                
        except (subprocess.CalledProcessError, FileNotFoundError):
            click.echo("   ⚠️  Poetry no está instalado o no está en el PATH", err=True)
            return False
        except (IndexError, ValueError):
            click.echo("   ⚠️  No se pudo determinar la versión de Poetry", err=True)
            return False
        
        # Verificar virtualenv
        if 'VIRTUAL_ENV' not in os.environ:
            click.echo("   ⚠️  No hay entorno virtual activo", err=True)
            click.echo("   Puedes crear uno con 'pyenv virtualenv <env_name>' y asignarlo con 'pyenv local <env_name>'", err=True)
            return False
        
        # Ejecutar poetry install
        click.echo("📦 Instalando dependencias...")
        try:
            subprocess.run(
                ['poetry', 'install'],
                cwd=self.namespace,
                check=True,
                capture_output=True,
            )
            click.echo("   ✅ Dependencias instaladas")
            return True
        except subprocess.CalledProcessError as e:
            click.echo(f"   ❌ Error al instalar dependencias: {e}", err=True)
            return False

    def msg(self, deps_installed: bool):
        """Muestra el mensaje de éxito y next steps con información del proyecto"""
        project_root = Path(self.namespace)
        project_config = pm.load_config(project_root)
        
        click.echo()
        click.echo(f'🎉 ¡Proyecto "{self.namespace}" creado exitosamente!')
        
        # Mostrar información del proyecto
        if project_config:
            click.echo()
            click.echo("📋 Información del proyecto:")
            click.echo(f"   Nombre: {project_config.name}")
            click.echo(f"   Schema por defecto: {project_config.default_schema}")
        
        click.echo()
        click.echo("📋 Próximos pasos:")
        if not deps_installed:
            click.echo(f"   1. Instalar dependencias:")
            click.echo(f"      cd {self.namespace} && poetry install")
            click.echo("   2. Configurar MAIN_DATABASE_URL en tu entorno:")
        else:
            click.echo("   1. Configurar MAIN_DATABASE_URL en tu entorno:")
        click.echo("      export MAIN_DATABASE_URL='postgresql://user:pass@host:5432/dbname'")
        click.echo(f"   {'3' if not deps_installed else '2'}. Definir tus modelos en schemas/{self.schema_name}.py")
        click.echo(f"   {'4' if not deps_installed else '3'}. Crear recursos:")
        click.echo("      tai-sql generate    # Usa schema por defecto automáticamente")
        click.echo("      tai-sql push       # Aplica los cambios a la base de datos (generate implícito)")
        click.echo()
        click.echo("🔧 Comandos útiles:")
        click.echo("   tai-sql info                       # Ver info del proyecto")
        click.echo("   tai-sql new-schema <nombre>        # Crear nuevo schema")
        click.echo("   tai-sql set-default-schema <path>  # Cambiar schema por defecto")
        click.echo()
        click.echo("🔗 Documentación: https://github.com/triplealpha-innovation/tai-sql")
        