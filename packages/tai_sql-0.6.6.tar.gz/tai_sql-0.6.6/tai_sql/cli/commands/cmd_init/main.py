import sys
import click
from .model import InitCommand

@click.command()
@click.option('--name', '-n', default='database', help='Nombre del proyecto a crear')
@click.option('--schema', '-s', default='public', help='Nombre del primer esquema a crear')
@click.option('--install/--no-install', default=None, help='Instalar dependencias al finalizar')
def init(name: str, schema: str, install: bool | None):
    """Inicializa un nuevo proyecto tai-sql"""
    command = InitCommand(namespace=name, schema_name=schema)
    try:
        command.check_directory_is_avaliable()
        command.create_project()
        command.add_folders()
        command.create_project_config()
        
        # Decidir si instalar dependencias
        deps_installed = False
        if install is None:
            install = click.confirm("¿Quieres instalar las dependencias ahora?", default=True)
        
        if install:
            deps_installed = command.install_dependencies()
        
        command.msg(deps_installed)
    except Exception as e:
        click.echo(f"❌ Error al inicializar el proyecto: {str(e)}", err=True)
        sys.exit(1)