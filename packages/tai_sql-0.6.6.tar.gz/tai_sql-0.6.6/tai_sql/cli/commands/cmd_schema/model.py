import sys
from pathlib import Path
import click
from textwrap import dedent

from tai_sql import pm

class NewSchemaCommand:

    def __init__(self, namespace: str, schema_name: str):
        self.namespace = namespace
        self.schema_name = schema_name

    @property
    def subnamespace(self) -> str:
        """Retorna el subnamespace basado en el namespace"""
        return self.namespace.replace('-', '_')
    
    def exists(self) -> bool:
        """Verifica si el esquema ya existe"""
        schemas_dir = Path(self.namespace) / 'schemas'
        return (schemas_dir / f'{self.schema_name}.py').exists()
    
    def create(self):
        """Crea el esquema con la estructura básica"""
        click.echo(f"🚀 Creando esquema '{self.schema_name}' en '{self.namespace}/schemas'...")

        if self.exists():
            click.echo(f"❌ Error: El esquema '{self.schema_name}' ya existe en '{self.namespace}/schemas'.", err=True)
            sys.exit(1)
        
        # Verificar si estamos en un proyecto existente
        project_root = Path(self.namespace)
        existing_config = None
        
        if project_root.exists():
            existing_config = pm.load_config(project_root)
        
        # Crear directorio para el esquema
        schemas_dir = Path(self.namespace) / 'schemas'
        schemas_dir.mkdir(parents=True, exist_ok=True)
        
        # Crear modulo con el contenido exacto del ejemplo
        (schemas_dir / f'{self.schema_name}.py').write_text(self.get_content(), encoding='utf-8')

        # Crear directorio para las vistas
        views_dir = Path(self.namespace) / 'views' / self.schema_name
        views_dir.mkdir(parents=True, exist_ok=True)

        self.view_example()
        
        # Actualizar configuración del proyecto si existe
        if existing_config:
            # Si es el primer schema o queremos cambiar el default
            if not existing_config.default_schema:
                pm.update_config(
                    project_root,
                    default_schema=f'schemas/{self.schema_name}.py'
                )
                click.echo(f"   📄 Schema '{self.schema_name}' establecido como default")
        
        click.echo(f"   ✅ '{self.schema_name}.py' creado en '{self.namespace}/schemas/'")
    
    def view_example(self) -> None:
        """Crea los archivos SQL de ejemplo para las vistas"""
        views_dir = Path(self.namespace) / 'views' / self.schema_name

        if self.schema_name == 'chatbot':
            self._chatbot_views(views_dir)
        else:
            self._default_views(views_dir)

    def _default_views(self, views_dir: Path) -> None:
        """Vistas SQL para el schema por defecto (blog)"""
        sql_content = dedent('''
            SELECT
                usuario.id AS user_id,
                usuario.name AS user_name,
                COUNT(post.id) AS post_count
            FROM usuario
            LEFT JOIN post ON usuario.id = post.author_id
            GROUP BY usuario.id, usuario.name
        ''').strip()

        (views_dir / 'user_stats.sql').write_text(sql_content, encoding='utf-8')

    def _chatbot_views(self, views_dir: Path) -> None:
        """Vistas SQL para el schema chatbot"""
        user_stats_sql = dedent('''\
            -- Vista para estadísticas de usuarios
            SELECT 
                u.username,
                u.email,
                COUNT(DISTINCT c.id) as total_chats,
                COUNT(DISTINCT CASE WHEN c.is_active = true THEN c.id END) as active_chats,
                COUNT(DISTINCT m.id) as total_messages,
                u.created_at,
                MAX(m.timestamp) as last_activity
            FROM usuario u
            LEFT JOIN chat c ON u.username = c.username
            LEFT JOIN mensaje m ON c.id = m.chat_id
            GROUP BY u.username, u.email, u.created_at
            ORDER BY last_activity DESC NULLS LAST;
        ''').rstrip()

        token_consumption_sql = dedent('''\
            -- Vista para estadísticas de consumo de tokens por usuario y fecha
            SELECT 
                u.username,
                DATE(tu.timestamp) as date,
                SUM(tu.prompt_tokens) as total_prompt_tokens,
                SUM(tu.completion_tokens) as total_completion_tokens,
                SUM(tu.total_tokens) as total_tokens,
                SUM(tu.cost_usd) as total_cost_usd,
                COUNT(DISTINCT m.chat_id) as chat_count,
                MODE() WITHIN GROUP (ORDER BY tu.model_name) as most_used_model,
                MODE() WITHIN GROUP (ORDER BY tu.provider) as most_used_provider
            FROM usuario u
            LEFT JOIN chat c ON u.username = c.username
            LEFT JOIN mensaje m ON c.id = m.chat_id
            LEFT JOIN token_usage tu ON m.id = tu.message_id
            WHERE tu.timestamp IS NOT NULL
            GROUP BY u.username, DATE(tu.timestamp)
            ORDER BY date DESC, total_tokens DESC;
        ''').rstrip()

        chat_activity_sql = dedent('''\
            -- Vista para actividad de chats
            SELECT 
                c.id as chat_id,
                c.title as chat_title,
                u.username,
                COUNT(m.id) as message_count,
                MAX(m.timestamp) as last_message_timestamp,
                COALESCE(SUM(tu.total_tokens), 0) as total_tokens_consumed,
                c.is_active
            FROM chat c
            INNER JOIN usuario u ON c.username = u.username
            LEFT JOIN mensaje m ON c.id = m.chat_id
            LEFT JOIN token_usage tu ON m.id = tu.message_id
            GROUP BY c.id, c.title, u.username, c.is_active
            ORDER BY last_message_timestamp DESC NULLS LAST;
        ''').rstrip()

        (views_dir / 'user_stats.sql').write_text(user_stats_sql, encoding='utf-8')
        (views_dir / 'token_consumption_stats.sql').write_text(token_consumption_sql, encoding='utf-8')
        (views_dir / 'chat_activity.sql').write_text(chat_activity_sql, encoding='utf-8')
    
    def get_content(self) -> str:
        """Retorna el contenido del archivo schema según el nombre del esquema"""
        if self.schema_name == 'chatbot':
            return self._chatbot_content()
        return self._default_content()

    def _default_content(self) -> str:
        """Contenido por defecto: blog con Usuario, Post, Comment, vistas"""
        return dedent(f'''
            # -*- coding: utf-8 -*-
            """
            Fuente principal para la definición de esquemas y generación de modelos CRUD.
            Usa el contenido de tai_sql para definir tablas, relaciones, vistas y generar automáticamente modelos y CRUDs.
            Usa tai_sql.generators para generar modelos y CRUDs basados en las tablas definidas.
            Ejecuta por consola tai-sql generate para generar los recursos definidos en este esquema.
            """
            from __future__ import annotations
            from tai_sql import *
            from tai_sql.generators import *


            # Configurar el datasource
            datasource(
                provider=env('MAIN_DATABASE_URL'), # Además de env, también puedes usar (para testing) connection_string y params
                schema='{self.schema_name}', # Esquema del datasource
                syntax='v2', # Sintaxis V2: col[type], onetomany[Model], manytoone[Model]
                operative_fields=False, # Añade created_at, updated_at, created_by, updated_by a todas las tablas
            )

            # Configurar los generadores
            generate(
                PythonClientGenerator(
                    output_dir='{self.namespace}/{self.subnamespace}' # Directorio donde se generarán los recursos
                ),
                ERDiagramGenerator(
                    output_dir='{self.namespace}/diagrams', # Directorio donde se generarán los diagramas
                )
            )

            # Definición de tablas y relaciones

            # Ejemplo de definición de tablas y relaciones. Eliminar estos modelos y definir los tuyos propios.
            class Usuario(Table):
                """Tabla que almacena información de los usuarios del sistema"""
                __tablename__ = "usuario"

                id: col[int] = column(primary_key=True, autoincrement=True)
                name: col[str] = column(unique=True, description='Nombre del usuario')
                pwd: col[str] = column(encrypt=True) # Contraseña encriptada
                email: col[str | None] # Nullable
                last_post_date: col[datetime | None] # Nullable, se actualizará con un trigger al crear un nuevo post

                posts: onetomany[Post] # Relación one-to-many (implícita) con la tabla Post

                def feed(self) -> List[Usuario]:
                    """Datos iniciales para poblar la tabla. Ejecutar con: tai-sql feed"""
                    return [
                        Usuario(
                            name="John Doe",
                            pwd="hashed_password",
                            email="john.doe@example.com",
                            posts=[
                                Post(title="First Post", content="Hello World!", comments=[
                                    Comment(content="Great post!"),
                                    Comment(content="Thanks for sharing"),
                                ]),
                                Post(title="Second Post", content="Another day, another post"),
                            ],
                        ),
                        Usuario(
                            name="Jane Smith",
                            pwd="hashed_password",
                            email="jane.smith@example.com",
                            posts=[
                                Post(title="Jane's Post", content="My first post here"),
                            ],
                        ),
                    ]


            class ContentType(Enum):
                """Tipos de contenido para los posts"""
                TEXT = 'text'
                IMAGE = 'image'
                VIDEO = 'video'


            class Post(Table):
                """Tabla que almacena los posts de los usuarios"""
                __tablename__ = "post"

                id: col[bigint] = column(primary_key=True, autoincrement=True) # Tipo bigint para PostgreSQL
                title: col[str] = column(default='Post Title') # Valor por defecto
                content: col[str] = column(description='Contenido del post')
                content_type: col[ContentType] = column(default=ContentType.TEXT) # Tipo de contenido con valor por defecto
                timestamp: col[datetime] = column(default=datetime.now, description='Fecha y hora del post') # Timestamp con generador de valor por defecto
                author_id: col[int]

                comments: onetomany[Comment]

                author: manytoone[Usuario] = relation(fields=['author_id'], references=['id'], backref='posts') # Relación many-to-one con la tabla User

                @on_create(timing='after')
                def modify_user_last_post_date(self, t: TriggerAPI):
                    """Trigger que actualiza el campo last_post_date del usuario al crear un nuevo post"""
                    t.update(Usuario, self.author_id, last_post_date=self.timestamp)


            class Comment(Table):
                """Tabla que almacena los comentarios de los posts"""
                __tablename__ = "comment"

                id: col[int] = column(primary_key=True, autoincrement=True)
                content: col[str] = column(description='Contenido del comentario')
                post_id: col[bigint]

                post: manytoone[Post] = relation(fields=['post_id'], references=['id'], backref='comments') # Relación many-to-one con la tabla Post


            # Definición de vistas

            class UserStats(View):
                """Vista que muestra estadísticas de usuarios y sus posts"""
                __tablename__ = "user_stats"
                __query__ = query('user_stats.sql') # Esto es necesario para usar tai-sql push

                user_id: col[int]
                user_name: col[str]
                post_count: col[int]
        ''').strip()

    def _chatbot_content(self) -> str:
        """Contenido para schema chatbot: Usuario, Chat, Mensaje, TokenUsage, ToolCall, vistas"""
        return dedent(f'''
            # -*- coding: utf-8 -*-
            """
            Esquema de base de datos para un chatbot con soporte de mensajes, tokens y herramientas.
            Usa tai_sql para definir tablas, relaciones, vistas y generar automáticamente modelos y CRUDs.
            Ejecuta por consola tai-sql generate para generar los recursos definidos en este esquema.
            """
            from __future__ import annotations
            import os
            from tai_sql import *
            from tai_sql.generators import *


            # Configurar el datasource
            datasource(
                provider=env('MAIN_DATABASE_URL'), # Además de env, también puedes usar (para testing) connection_string y params
                schema='{self.schema_name}', # Esquema del datasource
                syntax='v2', # Sintaxis V2: col[type], onetomany[Model], manytoone[Model]
                operative_fields=True, # Añade created_at, updated_at, created_by, updated_by a todas las tablas
            )

            # Configurar los generadores
            generate(
                PythonClientGenerator(
                    output_dir='{self.namespace}/{self.subnamespace}' # Directorio donde se generarán los recursos
                ),
                ERDiagramGenerator(
                    output_dir='{self.namespace}/diagrams', # Directorio donde se generarán los diagramas
                )
            )

            # Definición de tablas y relaciones

            class Usuario(Table):
                """Tabla que almacena información de los usuarios del chatbot"""
                __tablename__ = "usuario"

                username: col[str] = column(primary_key=True, description='Nombre de usuario único')
                password: col[str] = column(encrypt=True, description='Contraseña encriptada')
                email: col[str | None] = column(description='Correo electrónico del usuario')
                avatar: col[str | None] = column(description='URL del avatar del usuario')
                session_id: col[str | None] = column(description='ID de la sesión activa del usuario')
                is_active: col[bool] = column(default=True, description='Estado activo del usuario')

                chats: onetomany[Chat] # Relación one-to-many con la tabla Chat

                def feed(self):
                    return [
                        Usuario(
                            username='admin',
                            password=os.getenv('USER_PWD', '123456'),
                            email='admin@triplealpha.in'
                        ),
                    ]


            class Chat(Table):
                """Tabla que almacena las conversaciones del chatbot"""
                __tablename__ = "chat"

                id: col[bigint] = column(primary_key=True, autoincrement=True, description='UUID del chat')
                title: col[str] = column(description='Título de la conversación')
                username: col[str] = column(description='ID del usuario propietario del chat')
                is_active: col[bool] = column(default=True, description='Estado activo del chat')
                last_message_timestamp: col[datetime | None] = column(description='Timestamp del último mensaje del chat')

                messages: onetomany[Mensaje] # Relación one-to-many con la tabla Mensaje

                usuario: manytoone[Usuario] = relation(fields=['username'], references=['username'], backref='chats') # Relación many-to-one con Usuario


            class Feedback(Enum):
                """Enum para el feedback de los mensajes"""
                GOOD = 'good'
                BAD = 'bad'


            class MessageRole(Enum):
                """Roles de los mensajes en el chat"""
                USER = 'usuario'
                ASSISTANT = 'asistente'
                SYSTEM = 'sistema'


            class Mensaje(Table):
                """Tabla que almacena los mensajes individuales de cada chat"""
                __tablename__ = "mensaje"

                id: col[bigint] = column(primary_key=True, autoincrement=True, description='UUID del mensaje')
                content: col[str] = column(description='Contenido del mensaje')
                role: col[MessageRole] = column(description='Rol del mensaje (user, assistant, system)')
                timestamp: col[datetime] = column(default=datetime.now, description='Timestamp del mensaje')
                feedback: col[Feedback] = column(default=Feedback.GOOD, description='Feedback del mensaje')
                feedback_comment: col[str | None] = column(description='Comentario adicional del feedback')
                chat_id: col[bigint] = column(description='ID del chat al que pertenece el mensaje')

                token_usage: onetomany[TokenUsage] # Relación one-to-many con la tabla TokenUsage
                tool_calls: onetomany[ToolCall] # Relación one-to-many con la tabla ToolCall

                chat: manytoone[Chat] = relation(fields=['chat_id'], references=['id'], backref='messages') # Relación many-to-one con Chat

                @on_create(timing='after')
                def update_last_message_timestamp(self, t: TriggerAPI):
                    """Actualiza el timestamp del último mensaje en el chat"""
                    t.update(Chat, self.chat_id, last_message_timestamp=self.timestamp)


            class TokenUsage(Table):
                """Tabla que almacena el consumo de tokens para métricas y facturación"""
                __tablename__ = "token_usage"

                id: col[bigint] = column(primary_key=True, autoincrement=True)
                prompt_tokens: col[int] = column(default=0, description='Tokens consumidos en el prompt')
                completion_tokens: col[int] = column(default=0, description='Tokens consumidos en la respuesta')
                total_tokens: col[int] = column(default=0, description='Total de tokens consumidos')
                model_name: col[str] = column(description='Nombre del modelo utilizado')
                provider: col[str] = column(description='Proveedor del modelo (OpenAI, Anthropic, etc.)')
                cost_usd: col[float | None] = column(description='Costo estimado en USD')
                timestamp: col[datetime] = column(default=datetime.now, description='Timestamp del consumo')
                message_id: col[bigint] = column(description='ID del mensaje asociado')

                message: manytoone[Mensaje] = relation(fields=['message_id'], references=['id'], backref='token_usage') # Relación one-to-one con Mensaje


            class ToolCall(Table):
                """Tabla que almacena las llamadas a herramientas realizadas por el agente durante la generación de respuestas"""
                __tablename__ = "tool_call"

                id: col[bigint] = column(primary_key=True, autoincrement=True, description='ID de la llamada a herramienta')
                tool_name: col[str] = column(description='Nombre de la herramienta invocada')
                tool_args: col[dict | None] = column(description='Argumentos de entrada en formato JSON')
                tool_result: col[dict | None] = column(description='Resultado de la herramienta en formato JSON')
                duration_ms: col[int | None] = column(description='Duración de la ejecución en milisegundos')
                success: col[bool] = column(default=True, description='Si la llamada fue exitosa')
                timestamp: col[datetime] = column(default=datetime.now, description='Timestamp de la llamada')
                message_id: col[bigint] = column(description='ID del mensaje asociado')

                message: manytoone[Mensaje] = relation(fields=['message_id'], references=['id'], backref='tool_calls') # Relación many-to-one con Mensaje


            # Definición de vistas

            class UserStats(View):
                """Vista que muestra estadísticas de usuarios y sus chats"""
                __tablename__ = "user_stats"
                __query__ = query('user_stats.sql') # Esto es necesario para usar tai-sql push

                username: col[str]
                email: col[str]
                total_chats: col[int]
                active_chats: col[int]
                total_messages: col[int]
                created_at: col[datetime]
                last_activity: col[datetime | None]


            class TokenConsumptionStats(View):
                """Vista que muestra estadísticas de consumo de tokens por usuario y período"""
                __tablename__ = "token_consumption_stats"
                __query__ = query('token_consumption_stats.sql')

                username: col[str]
                date: col[datetime]
                total_prompt_tokens: col[int]
                total_completion_tokens: col[int]
                total_tokens: col[int]
                total_cost_usd: col[float | None]
                chat_count: col[int]
                most_used_model: col[str]
                most_used_provider: col[str]


            class ChatActivity(View):
                """Vista que muestra la actividad reciente de chats"""
                __tablename__ = "chat_activity"
                __query__ = query('chat_activity.sql')

                chat_id: col[str]
                chat_title: col[str]
                username: col[str]
                message_count: col[int]
                last_message_timestamp: col[datetime]
                total_tokens_consumed: col[int]
                is_active: col[bool]
        ''').strip()
