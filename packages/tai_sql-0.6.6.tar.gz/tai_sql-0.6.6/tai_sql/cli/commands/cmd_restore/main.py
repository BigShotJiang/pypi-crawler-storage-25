import sys
import click

from tai_sql import pm
from ..utils import verify_server_connection, createdb, createschema
from ...services.backup import BackupService


@click.command()
@click.argument('filename', required=False)
@click.option('--schema', '-s', help='Nombre del esquema')
@click.option('--latest', is_flag=True, help='Restaurar el último backup disponible')
@click.option('--clean', is_flag=True, help='Eliminar objetos existentes antes de restaurar')
@click.option('--dry-run', '-d', is_flag=True, help='Mostrar qué se restauraría sin ejecutar')
def restore(filename: str = None, schema: str = None, latest: bool = False,
            clean: bool = False, dry_run: bool = False):
    """Restaura la base de datos desde un backup"""

    if schema:
        pm.set_current_schema(schema)

    if not schema and not pm.db:
        click.echo("❌ No existe ningún esquema por defecto", err=True)
        click.echo("   Puedes definir uno con: tai-sql set-default-schema <nombre>", err=True)
        click.echo("   O usar la opción: --schema <nombre_esquema>", err=True)
        sys.exit(1)

    try:
        service = BackupService(pm.db)

        # Resolver qué archivo restaurar
        target = _resolve_target(service, filename, latest)
        if target is None:
            sys.exit(1)

        click.echo()
        target_provider = pm.db.restore_provider

        click.echo(f"🔄 Restore schema: {pm.db.schema_name}")
        click.echo()
        click.echo(f"   Motor: {pm.db.provider.driver.name}")
        click.echo(f"   Base de datos destino: {target_provider.database}")
        click.echo(f"   Host destino: {target_provider.host}:{target_provider.port}")
        click.echo(f"   Archivo: {target}")
        if clean:
            click.echo("   Modo: clean (DROP + CREATE)")
        if target_provider != pm.db.provider:
            click.echo("   ⚡ Restore a BD diferente del origen")
        click.echo()

        if dry_run:
            click.echo("🔍 Modo dry-run: no se ejecutaron cambios")
            return

        if not verify_server_connection(target_provider):
            sys.exit(1)
        
        click.echo()
        
        createdb(target_provider)

        click.echo()

        createschema(target_provider)

        click.echo()

        # Confirmación
        if not click.confirm("⚠️  ¿Deseas restaurar este backup? Los datos actuales pueden ser sobrescritos"):
            click.echo("   Operación cancelada")
            return

        click.echo()
        click.echo("🚀 Ejecutando restore...")

        service.restore(filename=target, clean=clean)

        click.echo()
        click.echo("✅ Restore completado exitosamente")

    except FileNotFoundError as e:
        click.echo(f"❌ {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error durante restore: {e}", err=True)
        sys.exit(1)


def _resolve_target(service: BackupService, filename: str = None,
                    latest: bool = False) -> str | None:
    """Resuelve el archivo de backup a restaurar."""

    if filename:
        return filename

    if latest:
        name = service.get_latest_backup()
        if not name:
            click.echo("❌ No se encontraron backups disponibles", err=True)
            return None
        return name

    # Modo interactivo: listar y elegir
    backups = service.list_backups()
    if not backups:
        click.echo("❌ No se encontraron backups disponibles", err=True)
        return None

    click.echo()
    click.echo(f"📋 Backups disponibles para schema: {service.sm.schema_name}")
    click.echo()

    for i, b in enumerate(backups, 1):
        size_str = ""
        if b.get('size') is not None:
            size_mb = b['size'] / (1024 * 1024)
            size_str = f" ({size_mb:.1f} MB)"
        click.echo(f"   {i}. {b['name']}{size_str}")

    click.echo()
    choice = click.prompt("Selecciona un backup (número)", type=int)

    if choice < 1 or choice > len(backups):
        click.echo("❌ Selección fuera de rango", err=True)
        return None

    return backups[choice - 1]['name']
