from __future__ import annotations

import subprocess
import sys
import os
from dataclasses import dataclass, field

import click

from tai_sql import pm
from tai_sql.orm.columns import VectorColumn


# ─────────────────────────────────────────────────────────────────────────────
# Mapa de extras → descripción para el usuario
# ─────────────────────────────────────────────────────────────────────────────

DRIVER_EXTRAS: dict[str, str] = {
    'postgresql': 'postgresql',
    'mysql': 'mysql',
    'sqlserver': 'sqlserver',
}

ASYNC_EXTRAS: dict[str, str] = {
    'postgresql': 'postgresql-async',
    'mysql': 'mysql-async',
    'sqlserver': 'sqlserver-async',
}


@dataclass
class Dependency:
    """Representa una dependencia detectada con su motivo"""
    extra: str
    reason: str


@dataclass
class SchemaAnalysis:
    """Resultado del análisis de dependencias del schema"""
    dependencies: list[Dependency] = field(default_factory=list)

    @property
    def extras(self) -> list[str]:
        return [d.extra for d in self.dependencies]


def analyze_schema() -> SchemaAnalysis:
    """Analiza el schema cargado y determina las dependencias necesarias"""
    analysis = SchemaAnalysis()
    db = pm.db

    # 1. Driver síncrono según la base de datos configurada
    driver_name = db.provider.driver.name
    if driver_name in DRIVER_EXTRAS:
        analysis.dependencies.append(Dependency(
            extra=DRIVER_EXTRAS[driver_name],
            reason=f"Driver síncrono para {driver_name} (definido en datasource)",
        ))

    # 2. Analizar tablas para detectar features
    has_encryption = False
    has_vectors = False
    has_encoders = False
    encrypted_tables: list[str] = []
    vector_tables: list[str] = []
    encoder_tables: list[str] = []

    for table in db.tables:
        for col in table.columns.values():
            if col.encrypt and not has_encryption:
                has_encryption = True
            if col.encrypt:
                if table.tablename not in encrypted_tables:
                    encrypted_tables.append(table.tablename)

            if isinstance(col, VectorColumn):
                if not has_vectors:
                    has_vectors = True
                if table.tablename not in vector_tables:
                    vector_tables.append(table.tablename)
                if col.encoder is not None:
                    if not has_encoders:
                        has_encoders = True
                    if table.tablename not in encoder_tables:
                        encoder_tables.append(table.tablename)

    if has_encryption:
        tables_str = ', '.join(encrypted_tables)
        analysis.dependencies.append(Dependency(
            extra='encryption',
            reason=f"Columnas encriptadas en: {tables_str}",
        ))

    if has_vectors and not has_encoders:
        tables_str = ', '.join(vector_tables)
        analysis.dependencies.append(Dependency(
            extra='vectors',
            reason=f"Columnas vector en: {tables_str}",
        ))
    elif has_encoders:
        tables_str = ', '.join(encoder_tables)
        analysis.dependencies.append(Dependency(
            extra='vectors-encoding',
            reason=f"Columnas vector con encoder en: {tables_str}",
        ))

    return analysis


def check_poetry_available() -> bool:
    """Verifica que Poetry esté instalado y con versión >= 2.2.1"""
    try:
        result = subprocess.run(['poetry', '--version'], check=True, capture_output=True, text=True)
        version_output = result.stdout.strip()
        version_str = version_output.split('(version ')[-1].rstrip(')')
        parts = version_str.split('.')
        major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])

        if (major, minor, patch) < (2, 2, 1):
            click.echo(f"❌ Poetry versión {version_str} encontrada, se requiere >= 2.2.1", err=True)
            return False
        return True

    except (subprocess.CalledProcessError, FileNotFoundError):
        click.echo("❌ Poetry no está instalado o no está en el PATH", err=True)
        return False
    except (IndexError, ValueError):
        click.echo("❌ No se pudo determinar la versión de Poetry", err=True)
        return False


@click.command()
@click.option('--async', 'include_async', is_flag=True, default=False, help='Incluir driver asíncrono')
@click.option('--yes', '-y', is_flag=True, default=False, help='No pedir confirmación')
def install(include_async: bool, yes: bool):
    """Analiza el schema y guía la instalación de dependencias del proyecto"""
    if not pm.db or not pm.db.is_loaded:
        click.echo("❌ No se encontró un schema cargado. Verifica tu .taisqlproject", err=True)
        sys.exit(1)

    project_root = pm.find_project_root()
    if project_root is None:
        click.echo("❌ No se encontró proyecto TAI-SQL", err=True)
        sys.exit(1)

    # Analizar schema
    analysis = analyze_schema()

    # Añadir async si se solicita
    if include_async:
        driver_name = pm.db.provider.driver.name
        if driver_name in ASYNC_EXTRAS:
            analysis.dependencies.append(Dependency(
                extra=ASYNC_EXTRAS[driver_name],
                reason=f"Driver asíncrono para {driver_name} (--async)",
            ))

    if not analysis.dependencies:
        click.echo("✅ No se detectaron dependencias opcionales necesarias")
        click.echo("   Las dependencias base (sqlalchemy, pydantic, tai-alphi) ya están en pyproject.toml")
        return

    # Mostrar resumen
    click.echo("📋 Dependencias detectadas desde el schema:\n")
    for dep in analysis.dependencies:
        click.echo(f"   • {dep.extra}")
        click.echo(f"     └─ {dep.reason}")
    click.echo()

    extras_str = ','.join(analysis.extras)
    command = f"poetry install --extras \"{extras_str}\""

    click.echo(f"   Comando: {command}")
    click.echo(f"   Directorio: {project_root}")
    click.echo()

    if not yes and not click.confirm("¿Continuar con la instalación?", default=True):
        click.echo("Instalación cancelada")
        return

    # Verificar requisitos
    if not check_poetry_available():
        sys.exit(1)

    if 'VIRTUAL_ENV' not in os.environ:
        click.echo("❌ No hay entorno virtual activo", err=True)
        click.echo("   Puedes crear uno con 'pyenv virtualenv <env_name>' y asignarlo con 'pyenv local <env_name>'", err=True)
        sys.exit(1)

    # Ejecutar
    click.echo("📦 Instalando dependencias...")
    try:
        subprocess.run(
            ['poetry', 'install', '--extras', extras_str],
            cwd=str(project_root),
            check=True,
        )
        click.echo("\n✅ Dependencias instaladas correctamente")
    except subprocess.CalledProcessError as e:
        click.echo(f"\n❌ Error al instalar dependencias: {e}", err=True)
        sys.exit(1)
