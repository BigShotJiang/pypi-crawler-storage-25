"""
Declarative models for SQLAlchemy.
This module provides the base classes and utilities to define
models using SQLAlchemy's declarative system.
"""
from __future__ import annotations
from sqlalchemy.types import (
    BigInteger as bigint,
    Text as text,
    Numeric as numeric,
    LargeBinary as largebinary,
)

from datetime import datetime, date, time
from typing import List, Optional

from .project import ProjectManager as pm
from .core import datasource, generate, env, connection_string, params, query
from .orm import (
    # Core ORM components
    Table, View, Enum, column, vector, vector_column, VectorColumn,
    relation, TriggerAPI, on_create, on_update, on_delete,
    trigger_api, col, onetomany, manytoone, onetoone, get_type_registry,
    register_type, TypeDescriptor, BaseEncoder, SentenceTransformerEncoder,
    calculated_column,
)

from .drivers import postgresql, mysql, sqlserver

# Exportar los elementos principales
__all__ = [
    'datasource', 
    'generate',
    'env',
    'connection_string',
    'params',
    'Table',
    'column',
    'relation',
    'List',
    'Optional',
    'datetime',
    'date',
    'time',
    'bigint',
    'text',
    'numeric',
    'largebinary',
    'TriggerAPI',
    'on_create',
    'on_update',
    'on_delete',
    'trigger_api',
    'calculated_column',
    'query',
    'View',
    'Enum',
    # V2 annotations
    'col',
    'onetomany',
    'manytoone',
    'onetoone',
    # Type system
    'get_type_registry',
    'register_type',
    'TypeDescriptor',
    # Vectors
    'vector',
    'vector_column',
    'VectorColumn',
    'BaseEncoder',
    'SentenceTransformerEncoder',
]