"""Tests for _auth_headers function."""

from goodmem.client import _auth_headers


def test_gm_prefix_uses_x_api_key():
    headers = _auth_headers("gm_abc123")
    assert headers == {"x-api-key": "gm_abc123"}


def test_gm_underscore_boundary():
    headers = _auth_headers("gm_")
    assert headers == {"x-api-key": "gm_"}


def test_any_string_uses_x_api_key():
    """All values are sent as x-api-key (Bearer tokens not supported yet)."""
    headers = _auth_headers("sk-proj-abc123")
    assert headers == {"x-api-key": "sk-proj-abc123"}
