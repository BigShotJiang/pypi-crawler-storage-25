"""GoodMem Python SDK.

The main entry points are :class:`Goodmem` (synchronous) and
:class:`AsyncGoodmem` (async). Both expose the same namespace attributes
(``embedders``, ``memories``, ``spaces``, etc.) and raise typed exceptions
from :mod:`goodmem.errors` on non-2xx responses.

See https://docs.goodmem.ai for the full tutorial and API reference.
"""

from importlib.metadata import version as _pkg_version, PackageNotFoundError

try:
    __version__ = _pkg_version("goodmem")
except PackageNotFoundError:
    # Fallback: read from pyproject.toml (editable dev install or bare checkout)
    try:
        from pathlib import Path as _Path
        import tomllib as _tomllib
        _pyproject = _Path(__file__).resolve().parent.parent / "pyproject.toml"
        with open(_pyproject, "rb") as _f:
            __version__ = _tomllib.load(_f)["project"]["version"]
    except Exception:
        __version__ = "0.0.0-dev"

try:
    from goodmem._build_info import BASED_ON_GOODMEM_COMMIT as __based_on_goodmem_commit__
except ImportError:
    # Dev mode (editable install): compute lazily on first access to avoid
    # spawning a subprocess on every import.
    __based_on_goodmem_commit__: str  # type: ignore[no-redef]

    def __getattr__(name: str):
        if name == "__based_on_goodmem_commit__":
            try:
                import subprocess
                from pathlib import Path as _Path

                val = subprocess.check_output(
                    ["git", "merge-base", "HEAD", "main"],
                    cwd=_Path(__file__).resolve().parent,
                    stderr=subprocess.DEVNULL,
                    text=True,
                ).strip()
            except Exception:
                val = "dev"
            globals()["__based_on_goodmem_commit__"] = val
            return val
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

from goodmem.client import AsyncGoodmem, Goodmem
from goodmem.pagination import AsyncPage, Page
from goodmem.streaming import AsyncRetrieveMemoryStream, RetrieveMemoryStream
from goodmem._overrides import MemoryCreationRequest
from goodmem.errors import (
    APIError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    GoodMemError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)

__all__ = [
    "__version__",
    "__based_on_goodmem_commit__",
    "Goodmem",
    "AsyncGoodmem",
    "Page",
    "AsyncPage",
    "RetrieveMemoryStream",
    "AsyncRetrieveMemoryStream",
    "MemoryCreationRequest",
    "GoodMemError",
    "APIError",
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "UnprocessableEntityError",
    "RateLimitError",
    "InternalServerError",
]
