from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ocr_input_format import OcrInputFormat
from goodmem.models.ocr_page_result import OcrPageResult
from goodmem.models.document_timings import DocumentTimings


class OcrDocumentResponse(BaseModel):
    """Response containing page-ordered OCR results."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    detected_format: OcrInputFormat = Field(description='Detected input format', alias="detectedFormat")
    page_count: int = Field(description='Number of pages processed after applying the range', alias="pageCount")
    pages: list[OcrPageResult] = Field(description='Ordered per-page OCR results')
    timings: DocumentTimings = Field(description='Aggregate timing statistics')

