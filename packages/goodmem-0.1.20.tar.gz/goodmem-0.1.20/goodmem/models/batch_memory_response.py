from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.batch_memory_result import BatchMemoryResult


class BatchMemoryResponse(BaseModel):
    """Response containing per-item results for a batch memories operation"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    results: list[BatchMemoryResult] = Field(description='Array of per-item results')
    total_deleted: Optional[int] = Field(default=None, description='Total number of memories deleted across all selectors', alias="totalDeleted")

