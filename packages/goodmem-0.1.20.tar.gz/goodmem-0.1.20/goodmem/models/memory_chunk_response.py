from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class MemoryChunkResponse(BaseModel):
    """Memory chunk information"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    chunk_id: str = Field(description='Unique identifier of the memory chunk', alias="chunkId")
    memory_id: str = Field(description='ID of the memory this chunk belongs to', alias="memoryId")
    chunk_sequence_number: int = Field(description='Sequence number of this chunk within the memory', alias="chunkSequenceNumber")
    chunk_text: str = Field(description='The text content of this chunk', alias="chunkText")
    vector_status: str = Field(description='Status of vector processing for this chunk', alias="vectorStatus")
    start_offset: Optional[int] = Field(default=None, description='Start offset of this chunk in the original content', alias="startOffset")
    end_offset: Optional[int] = Field(default=None, description='End offset of this chunk in the original content', alias="endOffset")
    metadata: Optional[dict[str, Any]] = Field(default=None, description='Additional metadata for the memory chunk')
    created_at: int = Field(description='Creation timestamp (milliseconds since epoch)', alias="createdAt")
    updated_at: int = Field(description='Last update timestamp (milliseconds since epoch)', alias="updatedAt")
    created_by_id: str = Field(description='ID of the user who created the chunk', alias="createdById")
    updated_by_id: str = Field(description='ID of the user who last updated the chunk', alias="updatedById")

