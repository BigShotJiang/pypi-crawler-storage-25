from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.space import Space


class ListSpacesResponse(BaseModel):
    """Response containing a list of spaces and optional pagination token."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    spaces: list[Space] = Field(description='The list of spaces matching the query criteria.')
    next_token: Optional[str] = Field(default=None, description='Pagination token for retrieving the next set of results. Only present if there are more results available.', alias="nextToken")

