from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import Base64Bytes, BaseModel, ConfigDict, Field

from goodmem.models.chunking_configuration import ChunkingConfiguration
from goodmem.models.processing_history import ProcessingHistory


class Memory(BaseModel):
    """Memory object containing stored content and metadata"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    memory_id: str = Field(description='Unique identifier of the memory', alias="memoryId")
    space_id: str = Field(description='ID of the space containing this memory', alias="spaceId")
    original_content: Optional[Base64Bytes] = Field(default=None, description='Original content (only included if requested)', alias="originalContent")
    original_content_length: Optional[int] = Field(default=None, description='Size in bytes of the inline original content', alias="originalContentLength")
    original_content_sha256: Optional[str] = Field(default=None, description='SHA-256 digest of the inline original content, hex encoded', alias="originalContentSha256")
    original_content_ref: Optional[str] = Field(default=None, description='Reference to external content location', alias="originalContentRef")
    content_type: str = Field(description='MIME type of the content', alias="contentType")
    processing_status: str = Field(description='Processing status of the memory', alias="processingStatus")
    page_image_status: str = Field(description='Processing status of page-image extraction for this memory', alias="pageImageStatus")
    page_image_count: int = Field(description='Number of extracted page-image renditions linked to this memory', alias="pageImageCount")
    metadata: Optional[dict[str, Any]] = Field(default=None, description='Additional metadata for the memory')
    created_at: int = Field(description='Timestamp when the memory was created (milliseconds since epoch)', alias="createdAt")
    updated_at: int = Field(description='Timestamp when the memory was last updated (milliseconds since epoch)', alias="updatedAt")
    created_by_id: str = Field(description='ID of the user who created this memory', alias="createdById")
    updated_by_id: str = Field(description='ID of the user who last updated this memory', alias="updatedById")
    chunking_config: Optional[ChunkingConfiguration] = Field(default=None, description='Chunking strategy used for this memory', alias="chunkingConfig")
    processing_history: Optional[ProcessingHistory] = Field(default=None, description='Background job processing history associated with this memory', alias="processingHistory")

