from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class CreateApiKeyRequest(BaseModel):
    """Request parameters for creating a new API key."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    labels: Optional[dict[str, str]] = Field(default=None, description='Key-value pairs of metadata associated with the API key. Used for organization and filtering.')
    expires_at: Optional[int] = Field(default=None, description='Expiration timestamp in milliseconds since epoch. If not provided, the key does not expire.', alias="expiresAt")
    api_key_id: Optional[str] = Field(default=None, description='Optional client-provided UUID for idempotent creation. If not provided, server generates a new UUID. Returns ALREADY_EXISTS if ID is already in use.', alias="apiKeyId")

