from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.llm_provider_type import LLMProviderType
from goodmem.models.modality import Modality
from goodmem.models.endpoint_authentication import EndpointAuthentication
from goodmem.models.llm_capabilities import LLMCapabilities
from goodmem.models.llm_sampling_params import LLMSamplingParams


class LLMResponse(BaseModel):
    """LLM configuration information"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    llm_id: str = Field(description='Unique identifier of the LLM', alias="llmId")
    display_name: str = Field(description='User-facing name of the LLM', alias="displayName")
    description: Optional[str] = Field(default=None, description='Description of the LLM')
    provider_type: LLMProviderType = Field(description='Type of LLM provider', alias="providerType")
    endpoint_url: str = Field(description='API endpoint base URL', alias="endpointUrl")
    api_path: Optional[str] = Field(default=None, description='API path for chat/completions request', alias="apiPath")
    model_identifier: str = Field(description='Model identifier', alias="modelIdentifier")
    supported_modalities: list[Modality] = Field(description='Supported content modalities', alias="supportedModalities")
    credentials: Optional[EndpointAuthentication] = Field(default=None, description='Structured credential payload used for upstream authentication')
    labels: dict[str, str] = Field(description='User-defined labels for categorization')
    version: Optional[str] = Field(default=None, description='Version information')
    monitoring_endpoint: Optional[str] = Field(default=None, description='Monitoring endpoint URL', alias="monitoringEndpoint")
    capabilities: LLMCapabilities = Field(description='LLM capabilities defining supported features and modes')
    default_sampling_params: Optional[LLMSamplingParams] = Field(default=None, description='Default sampling parameters for generation requests', alias="defaultSamplingParams")
    max_context_length: Optional[int] = Field(default=None, description='Maximum context window size in tokens', alias="maxContextLength")
    client_config: Optional[dict[str, Any]] = Field(default=None, description='Provider-specific client configuration', alias="clientConfig")
    owner_id: str = Field(description='Owner ID of the LLM', alias="ownerId")
    created_at: int = Field(description='Creation timestamp (milliseconds since epoch)', alias="createdAt")
    updated_at: int = Field(description='Last update timestamp (milliseconds since epoch)', alias="updatedAt")
    created_by_id: str = Field(description='ID of the user who created the LLM', alias="createdById")
    updated_by_id: str = Field(description='ID of the user who last updated the LLM', alias="updatedById")

