from __future__ import annotations

from enum import Enum


class CredentialKind(str, Enum):
    """Credential kinds supported for upstream endpoint authentication."""

    CREDENTIAL_KIND_UNSPECIFIED = 'CREDENTIAL_KIND_UNSPECIFIED'
    CREDENTIAL_KIND_API_KEY = 'CREDENTIAL_KIND_API_KEY'
    CREDENTIAL_KIND_GCP_ADC = 'CREDENTIAL_KIND_GCP_ADC'

