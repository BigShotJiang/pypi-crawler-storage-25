from __future__ import annotations

from enum import Enum


class SortOrder(str, Enum):
    """SortOrder"""

    ASCENDING = 'ASCENDING'
    DESCENDING = 'DESCENDING'
    SORT_ORDER_UNSPECIFIED = 'SORT_ORDER_UNSPECIFIED'

