from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class SpaceEmbedder(BaseModel):
    """Associates an embedder with a space, including retrieval configuration."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    space_id: str = Field(description='The UUID for the space.', alias="spaceId")
    embedder_id: str = Field(description='The UUID for the embedder.', alias="embedderId")
    default_retrieval_weight: float = Field(description='The default weight for this embedder during retrieval operations.', alias="defaultRetrievalWeight")
    created_at: int = Field(description='Timestamp when this association was created (milliseconds since epoch).', alias="createdAt")
    updated_at: int = Field(description='Timestamp when this association was last updated (milliseconds since epoch).', alias="updatedAt")
    created_by_id: str = Field(description='The ID of the user who created this association.', alias="createdById")
    updated_by_id: str = Field(description='The ID of the user who last updated this association.', alias="updatedById")

