from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.background_job_summary import BackgroundJobSummary
from goodmem.models.background_job_attempt import BackgroundJobAttempt


class ProcessingHistory(BaseModel):
    """Background job execution history associated with a memory"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    latest_job: Optional[BackgroundJobSummary] = Field(default=None, description='Summary of the most recent background job', alias="latestJob")
    attempts: Optional[list[BackgroundJobAttempt]] = Field(default=None, description='Attempt-level telemetry captured for the latest job')

