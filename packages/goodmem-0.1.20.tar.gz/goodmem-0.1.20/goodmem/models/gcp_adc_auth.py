from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class GcpAdcAuth(BaseModel):
    """Configuration for Google Application Default Credentials (ADC)."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    scopes: Optional[list[str]] = Field(default=None, description='Additional OAuth scopes. Empty list falls back to the default cloud-platform scope.')
    quota_project_id: Optional[str] = Field(default=None, description='Optional quota project used for billing', alias="quotaProjectId")

