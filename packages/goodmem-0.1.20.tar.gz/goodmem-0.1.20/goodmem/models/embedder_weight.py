from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class EmbedderWeight(BaseModel):
    """Per-embedder weight override for retrieval operations."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    embedder_id: str = Field(description='The UUID for the embedder.', alias="embedderId")
    weight: float = Field(description="The weight to apply to this embedder's results. Can be positive, negative, or zero.")

