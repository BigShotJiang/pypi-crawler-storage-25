from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class UserResponse(BaseModel):
    """User information response"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    user_id: str = Field(description='The UUID of the user', alias="userId")
    email: str = Field(description="The user's email address")
    display_name: str = Field(description="The user's display name", alias="displayName")
    username: Optional[str] = Field(default=None, description="The user's username (optional)")
    created_at: int = Field(description='Timestamp when the user was created (milliseconds since epoch)', alias="createdAt")
    updated_at: int = Field(description='Timestamp when the user was last updated (milliseconds since epoch)', alias="updatedAt")

