from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.hnsw_iterative_scan import HnswIterativeScan


class HnswOptions(BaseModel):
    """Optional request-level overrides for pgvector HNSW search settings. Unset fields inherit server defaults."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    ef_search: Optional[int] = Field(default=None, description='HNSW candidate list size (1..1000).', alias="efSearch")
    iterative_scan: Optional[HnswIterativeScan] = Field(default=None, description='HNSW iterative scan mode. Use POST retrieve for this advanced tuning control.', alias="iterativeScan")
    max_scan_tuples: Optional[int] = Field(default=None, description='Maximum tuples to scan during iterative filtering (1..2147483647).', alias="maxScanTuples")
    scan_mem_multiplier: Optional[float] = Field(default=None, description='Multiplier on work_mem for iterative scanning (1.0..1000.0).', alias="scanMemMultiplier")

