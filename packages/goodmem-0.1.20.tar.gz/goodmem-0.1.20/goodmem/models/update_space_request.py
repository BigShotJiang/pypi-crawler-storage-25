from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator



class UpdateSpaceRequest(BaseModel):
    """Request parameters for updating a space."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    name: Optional[str] = Field(default=None, description='The new name for the space.')
    public_read: Optional[bool] = Field(default=None, description='Whether the space is publicly readable by all users.', alias="publicRead")
    replace_labels: Optional[dict[str, str]] = Field(default=None, description='Labels to replace all existing labels. Mutually exclusive with mergeLabels.', alias="replaceLabels")
    merge_labels: Optional[dict[str, str]] = Field(default=None, description='Labels to merge with existing labels. Mutually exclusive with replaceLabels.', alias="mergeLabels")

    @model_validator(mode='after')
    def _check_mutual_exclusion(self) -> 'UpdateSpaceRequest':
        _fields = ['replace_labels', 'merge_labels']
        _set = [f for f in _fields if getattr(self, f) is not None]
        if len(_set) > 1:
            raise ValueError('replace_labels and merge_labels are mutually exclusive' + f": got {_set}")
        return self

