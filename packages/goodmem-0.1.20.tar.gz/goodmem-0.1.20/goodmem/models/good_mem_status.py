from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class GoodMemStatus(BaseModel):
    """Warning or non-fatal status with granular codes (operation continues)"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    code: str = Field(description='Status code for the warning or informational message')
    message: str = Field(description='Human-readable status message')
    details: Optional[dict[str, str]] = Field(default=None, description='Additional contextual details')

