from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from goodmem.models.binary_content import BinaryContent


class ContextItem(BaseModel):
    """Context item with either text or binary content."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    text: Optional[str] = Field(default=None, description='Text content for this context item.')
    binary: Optional[BinaryContent] = Field(default=None, description='Binary content for this context item.')

    @model_validator(mode='after')
    def _check_exactly_one_variant(self) -> 'ContextItem':
        _variant_fields = ['text', 'binary']
        _set = [f for f in _variant_fields if getattr(self, f) is not None]
        if len(_set) != 1:
            raise ValueError(
                f"Exactly one of text, binary must be set, "
                f"got {len(_set)}: {_set or 'none'}"
            )
        return self

