from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class ResultSetBoundary(BaseModel):
    """Boundary marker for logical result sets in streaming memory retrieval"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    result_set_id: str = Field(description='Unique identifier for this result set (UUID)', alias="resultSetId")
    kind: Literal['BEGIN', 'END'] = Field(description='Type of boundary marker')
    stage_name: str = Field(description='Free-form label describing the pipeline stage', alias="stageName")
    expected_items: Optional[int] = Field(default=None, description='Hint for progress tracking - expected number of items in this result set', alias="expectedItems")

