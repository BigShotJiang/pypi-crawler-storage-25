from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.memory import Memory


class MemoryListResponse(BaseModel):
    """Response containing a list of memories within a space"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    memories: list[Memory] = Field(description='Array of memories in the space')
    next_token: Optional[str] = Field(default=None, description='Token for retrieving the next page of results', alias="nextToken")

