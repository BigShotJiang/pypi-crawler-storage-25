from __future__ import annotations

from enum import Enum


class HnswIterativeScan(str, Enum):
    """Iterative scan modes for HNSW index search."""

    ITERATIVE_SCAN_UNSPECIFIED = 'ITERATIVE_SCAN_UNSPECIFIED'
    ITERATIVE_SCAN_OFF = 'ITERATIVE_SCAN_OFF'
    ITERATIVE_SCAN_RELAXED_ORDER = 'ITERATIVE_SCAN_RELAXED_ORDER'
    ITERATIVE_SCAN_STRICT_ORDER = 'ITERATIVE_SCAN_STRICT_ORDER'

