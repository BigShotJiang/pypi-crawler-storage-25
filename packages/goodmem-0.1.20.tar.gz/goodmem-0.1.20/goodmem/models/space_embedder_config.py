from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class SpaceEmbedderConfig(BaseModel):
    """Configuration for associating an embedder with a space."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    embedder_id: str = Field(description='The UUID for the embedder to associate with the space.', alias="embedderId")
    default_retrieval_weight: Optional[float] = Field(default=None, description='Relative weight for this embedder used by default during retrieval. If omitted, defaults to 1.0; values need not sum to 1 and can be overridden per request.', alias="defaultRetrievalWeight")

