from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ocr_cell import OcrCell


class OcrLayout(BaseModel):
    """Parsed OCR layout output for a page."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    cells: list[OcrCell] = Field(description='Layout cells in reading order')

