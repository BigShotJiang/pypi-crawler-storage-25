from __future__ import annotations

from enum import Enum


class SeparatorKeepStrategy(str, Enum):
    """Strategy for handling separators after text splitting. KEEP_NONE is deprecated and treated as KEEP_END."""

    KEEP_NONE = 'KEEP_NONE'
    KEEP_START = 'KEEP_START'
    KEEP_END = 'KEEP_END'

