from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.bounding_box import BoundingBox
from goodmem.models.ocr_category import OcrCategory


class OcrCell(BaseModel):
    """Single OCR layout element."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    bbox: Optional[BoundingBox] = Field(default=None, description='Bounding box in page coordinates')
    category_label: str = Field(description='Raw category label emitted by OCR', alias="categoryLabel")
    category: OcrCategory = Field(description='Normalized OCR category')
    text: str = Field(description='OCR text content')

