from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.json_memory_creation_request import JsonMemoryCreationRequest


class JsonBatchMemoryCreationRequest(BaseModel):
    """Request body for creating multiple memories via application/json."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    requests: list[JsonMemoryCreationRequest] = Field(description='Array of memory creation requests.')

