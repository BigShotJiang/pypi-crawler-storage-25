from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class ErrorDetail(BaseModel):
    """Structured error details for an individual batch operation result"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    code: int = Field(description='Numeric error code (typically an HTTP or gRPC-derived status code)')
    message: str = Field(description='Human-readable error message')

