from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.api_key_response import ApiKeyResponse


class ListApiKeysResponse(BaseModel):
    """Response containing a list of API keys."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    keys: list[ApiKeyResponse] = Field(description='List of API keys belonging to the authenticated user.')

