from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class AdminDrainRequest(BaseModel):
    """AdminDrainRequest"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    timeout_sec: Optional[int] = Field(default=None, description='Maximum seconds to wait for the server to quiesce before returning.', alias="timeoutSec")
    reason: Optional[str] = Field(default=None, description='Human-readable reason for initiating drain mode.')
    wait_for_quiesce: Optional[bool] = Field(default=None, description='If true, wait for in-flight requests to complete and the server to reach QUIESCED before responding.', alias="waitForQuiesce")

