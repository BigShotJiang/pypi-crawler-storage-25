from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.length_measurement import LengthMeasurement


class SentenceChunkingConfiguration(BaseModel):
    """Sentence-based chunking strategy with language detection support"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    max_chunk_size: int = Field(description='Maximum size of a chunk', alias="maxChunkSize")
    min_chunk_size: int = Field(description='Minimum size before creating a new chunk', alias="minChunkSize")
    enable_language_detection: Optional[bool] = Field(default=None, description='Whether to detect language for better segmentation', alias="enableLanguageDetection")
    length_measurement: LengthMeasurement = Field(description='How to measure chunk length', alias="lengthMeasurement")

