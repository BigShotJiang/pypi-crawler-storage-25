from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class SecretReference(BaseModel):
    """SecretReference"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    uri: str = Field(description='URI identifying where the secret can be resolved (e.g., vault://, env://)')
    hints: Optional[dict[str, str]] = Field(default=None, description='Optional metadata to help resolvers decode the secret (e.g., {"encoding":"base64"})')

