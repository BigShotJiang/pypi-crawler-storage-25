from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.provider_type import ProviderType
from goodmem.models.modality import Modality
from goodmem.models.endpoint_authentication import EndpointAuthentication


class RerankerResponse(BaseModel):
    """Reranker configuration information"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    reranker_id: str = Field(description='Unique identifier of the reranker', alias="rerankerId")
    display_name: str = Field(description='User-facing name of the reranker', alias="displayName")
    description: Optional[str] = Field(default=None, description='Description of the reranker')
    provider_type: ProviderType = Field(description='Type of reranking provider', alias="providerType")
    endpoint_url: str = Field(description='API endpoint URL', alias="endpointUrl")
    api_path: Optional[str] = Field(default=None, description='API path for reranking request', alias="apiPath")
    model_identifier: str = Field(description='Model identifier', alias="modelIdentifier")
    supported_modalities: list[Modality] = Field(description='Supported content modalities', alias="supportedModalities")
    credentials: Optional[EndpointAuthentication] = Field(default=None, description='Structured credential payload used for upstream authentication')
    labels: dict[str, str] = Field(description='User-defined labels for categorization')
    version: Optional[str] = Field(default=None, description='Version information')
    monitoring_endpoint: Optional[str] = Field(default=None, description='Monitoring endpoint URL', alias="monitoringEndpoint")
    owner_id: str = Field(description='Owner ID of the reranker', alias="ownerId")
    created_at: int = Field(description='Creation timestamp (milliseconds since epoch)', alias="createdAt")
    updated_at: int = Field(description='Last update timestamp (milliseconds since epoch)', alias="updatedAt")
    created_by_id: str = Field(description='ID of the user who created the reranker', alias="createdById")
    updated_by_id: str = Field(description='ID of the user who last updated the reranker', alias="updatedById")

