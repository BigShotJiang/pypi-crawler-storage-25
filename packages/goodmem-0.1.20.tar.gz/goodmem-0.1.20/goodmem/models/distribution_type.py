from __future__ import annotations

from enum import Enum


class DistributionType(str, Enum):
    """Type of embedding distribution produced by the embedder"""

    DENSE = 'DENSE'
    SPARSE = 'SPARSE'

