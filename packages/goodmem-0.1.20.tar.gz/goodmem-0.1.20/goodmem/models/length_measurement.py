from __future__ import annotations

from enum import Enum


class LengthMeasurement(str, Enum):
    """Strategy for measuring chunk length during text splitting"""

    CHARACTER_COUNT = 'CHARACTER_COUNT'
    TOKEN_COUNT = 'TOKEN_COUNT'
    CUSTOM = 'CUSTOM'

