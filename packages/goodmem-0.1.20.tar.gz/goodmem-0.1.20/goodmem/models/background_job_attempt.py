from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class BackgroundJobAttempt(BaseModel):
    """Telemetry captured for a single execution attempt of a background job"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    attempt_id: int = Field(description='Identifier of the attempt', alias="attemptId")
    job_id: int = Field(description='Identifier of the job that owns this attempt', alias="jobId")
    started_at: Optional[int] = Field(default=None, description='Attempt start timestamp (milliseconds since epoch)', alias="startedAt")
    finished_at: Optional[int] = Field(default=None, description='Attempt completion timestamp (milliseconds since epoch)', alias="finishedAt")
    ok: Optional[bool] = Field(default=None, description='Indicates whether the attempt succeeded (null if still running)')
    worker_id: Optional[str] = Field(default=None, description='Identifier of the worker processing the attempt', alias="workerId")
    status_message: Optional[str] = Field(default=None, description='Latest status message reported by the worker', alias="statusMessage")
    progress_current: int = Field(description='Current progress counter value', alias="progressCurrent")
    progress_total: Optional[int] = Field(default=None, description='Total progress target when known', alias="progressTotal")
    progress_unit: Optional[str] = Field(default=None, description='Unit label associated with the progress counters', alias="progressUnit")
    progress_updated_at: Optional[int] = Field(default=None, description='Timestamp when progress was last updated (milliseconds since epoch)', alias="progressUpdatedAt")
    error_message: Optional[str] = Field(default=None, description='Short error message recorded when the attempt failed', alias="errorMessage")
    error_stacktrace: Optional[str] = Field(default=None, description='Stack trace captured when the attempt failed, if available', alias="errorStacktrace")

