from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ocr_layout import OcrLayout
from goodmem.models.page_timings import PageTimings
from goodmem.models.image_info import ImageInfo


class OcrPage(BaseModel):
    """OCR output for a single page."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    raw_json: Optional[str] = Field(default=None, description='Raw OCR JSON payload when requested', alias="rawJson")
    markdown: Optional[str] = Field(default=None, description='Markdown rendering when requested')
    layout: OcrLayout = Field(description='Parsed layout output')
    timings: PageTimings = Field(description='Timing breakdown for the page')
    image: ImageInfo = Field(description='Rendered image metadata')

