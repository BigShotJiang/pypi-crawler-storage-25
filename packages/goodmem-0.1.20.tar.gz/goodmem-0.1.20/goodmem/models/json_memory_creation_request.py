from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.chunking_configuration import ChunkingConfiguration


class JsonMemoryCreationRequest(BaseModel):
    """Request body for creating a new Memory. A Memory represents content stored in a space."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    memory_id: Optional[str] = Field(default=None, description='Optional client-provided UUID for the memory. If omitted, the server generates one. Returns ALREADY_EXISTS if the ID is already in use.', alias="memoryId")
    space_id: str = Field(description='ID of the space where this memory will be stored', alias="spaceId")
    original_content: Optional[str] = Field(default=None, description='Original content as plain text (use either this or originalContentB64)', alias="originalContent")
    original_content_b64: Optional[str] = Field(default=None, description='Original content as base64-encoded binary data (use either this or originalContent)', alias="originalContentB64")
    original_content_ref: Optional[str] = Field(default=None, description='Reference to external content location', alias="originalContentRef")
    content_type: str = Field(description='MIME type of the content', alias="contentType")
    metadata: Optional[dict[str, Any]] = Field(default=None, description='Additional metadata for the memory')
    chunking_config: Optional[ChunkingConfiguration] = Field(default=None, description='Chunking strategy for this memory (if not provided, uses space default)', alias="chunkingConfig")
    extract_page_images: Optional[bool] = Field(default=None, description='Optional hint to extract page images for eligible document types (for example, PDFs)', alias="extractPageImages")
    file_field: Optional[str] = Field(default=None, description='Optional multipart file field name to bind binary content; required when multiple files are uploaded in a batch multipart request.', alias="fileField")

