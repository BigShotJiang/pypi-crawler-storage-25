from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class ApiKeyResponse(BaseModel):
    """API key metadata without sensitive information."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    api_key_id: str = Field(description='Unique identifier for the API key.', alias="apiKeyId")
    user_id: str = Field(description='ID of the user that owns this API key.', alias="userId")
    key_prefix: str = Field(description='First few characters of the key for display/identification purposes.', alias="keyPrefix")
    status: str = Field(description='Current status of the API key: ACTIVE, INACTIVE, or STATUS_UNSPECIFIED.')
    labels: dict[str, str] = Field(description='User-defined labels for organization and filtering.')
    expires_at: Optional[int] = Field(default=None, description='Expiration timestamp in milliseconds since epoch. If not provided, the key does not expire.', alias="expiresAt")
    last_used_at: Optional[int] = Field(default=None, description='Last time this API key was used, in milliseconds since epoch.', alias="lastUsedAt")
    created_at: int = Field(description='When the API key was created, in milliseconds since epoch.', alias="createdAt")
    updated_at: int = Field(description='When the API key was last updated, in milliseconds since epoch.', alias="updatedAt")
    created_by_id: str = Field(description='ID of the user that created this API key.', alias="createdById")
    updated_by_id: str = Field(description='ID of the user that last updated this API key.', alias="updatedById")

