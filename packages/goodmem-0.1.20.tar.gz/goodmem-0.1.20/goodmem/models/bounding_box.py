from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class BoundingBox(BaseModel):
    """Bounding box coordinates in page space."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    x1: float = Field(description='Left coordinate')
    y1: float = Field(description='Top coordinate')
    x2: float = Field(description='Right coordinate')
    y2: float = Field(description='Bottom coordinate')

