from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.api_key_response import ApiKeyResponse


class CreateApiKeyResponse(BaseModel):
    """Response returned when creating a new API key."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    api_key_metadata: Optional[ApiKeyResponse] = Field(default=None, description='Metadata for the created API key.', alias="apiKeyMetadata")
    raw_api_key: Optional[str] = Field(default=None, description='The actual API key value. This is only returned once and cannot be retrieved again.', alias="rawApiKey")

