"""Public API namespace classes."""
