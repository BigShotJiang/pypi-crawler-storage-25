"""Model registries for auto-inferring provider_type, dimensions, etc.

Source of truth: goodmem/registries/embedders.json, llms.json, rerankers.json.
Edit those files directly to add or update models.
Run `python render.py` for a human-readable markdown view.

Dimensions are capped at 1536 (largest supported value <= 1536).
"""

import json
from pathlib import Path

_REG_DIR = Path(__file__).parent / "registries"


def _load_registry(name: str) -> dict[str, dict]:
    path = _REG_DIR / f"{name}.json"
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        raise RuntimeError(
            f"Failed to load {name} registry from {path}. "
            f"Is the goodmem package installed correctly? ({e})"
        ) from e


EMBEDDER_MODEL_REGISTRY: dict[str, dict] = _load_registry("embedders")
LLM_MODEL_REGISTRY: dict[str, dict] = _load_registry("llms")
RERANKER_MODEL_REGISTRY: dict[str, dict] = _load_registry("rerankers")

# Provider metadata — single source of truth loaded from providers.json.
PROVIDER_REGISTRY: dict[str, dict] = _load_registry("providers")

# Provider type → default base endpoint URL (derived from PROVIDER_REGISTRY).
PROVIDER_ENDPOINTS: dict[str, str] = {}
for _k, _v in PROVIDER_REGISTRY.items():
    if "default_base_url" not in _v:
        raise RuntimeError(
            f"Provider '{_k}' in providers.json is missing 'default_base_url'. "
            f"Is the goodmem package installed correctly?"
        )
    PROVIDER_ENDPOINTS[_k] = _v["default_base_url"]
