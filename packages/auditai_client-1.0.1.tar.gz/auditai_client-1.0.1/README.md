# 🛡️ AuditAI Client

Python SDK for **AuditAI** — a production-grade AI Reliability, Compliance, and SLA Observability platform ("Datadog for LLM Agents").

## 🚀 Installation

Install the official package directly from PyPI:

```bash
pip install auditai-client
```

## ⚡ Quick Start

Log an LLM execution trace in just a few lines of code:

```python
from auditai import AuditAI

# 1. Initialize the client
client = AuditAI(api_key="your-jwt-token", base_url="http://localhost:8000")

# 2. Log trace with prompt, response, and retrieved context
result = client.log_execution(
    project_name="support-agent",
    prompt="What is the capital of France?",
    response="The capital of France is Paris.",
    retrieval_docs=["France is a country in Europe. Its capital is Paris."]
)
print(f"Logged trace ID: {result['id']}")
```

## 🔗 Repository & Documentation

For full setup guides, Docker deployment templates, Kubernetes manifests, and evaluation configurations, visit the main repository:

👉 **[AuditAI Main GitHub Repository](https://github.com/TechNxt05/AuditAI)**
