import os
from setuptools import setup, find_packages

this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="auditai-client",
    version="1.0.1",
    description="AuditAI – AI Reliability & Compliance Auditor SDK",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="AuditAI Team",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.9",
)
