"""Quantum-vs-classical Conway's Game of Life side-by-side comparison.

Left panel: classical Conway evolution from a glider seed.
Right panel: a "quantum" variant in which each cell's birth/survival
rule is decided by sampling a Bell pair — agreement keeps the cell
alive, disagreement kills it. The quantum noise produces blurred,
breathing patterns that are visually distinct from the deterministic
classical evolution.

The output is a single GIF stacking the two grids so the eye can
compare frame-by-frame.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path


def _classical_step(grid: "object") -> "object":
    import numpy as np

    g = np.asarray(grid, dtype=np.uint8)
    neigh = sum(
        np.roll(np.roll(g, dx, axis=0), dy, axis=1)
        for dx in (-1, 0, 1) for dy in (-1, 0, 1)
        if not (dx == 0 and dy == 0)
    )
    birth = (g == 0) & (neigh == 3)
    survive = (g == 1) & ((neigh == 2) | (neigh == 3))
    return (birth | survive).astype(np.uint8)


def _quantum_step(grid: "object", rng: "object") -> "object":
    """Conway-like rule with a quantum-noisy decision per cell."""
    import numpy as np

    g = np.asarray(grid, dtype=np.uint8)
    neigh = sum(
        np.roll(np.roll(g, dx, axis=0), dy, axis=1)
        for dx in (-1, 0, 1) for dy in (-1, 0, 1)
        if not (dx == 0 and dy == 0)
    )

    # Quantum-noise-modulated rule: take the Bell-state agreement
    # probability (cos^2(theta/2)) as a per-cell threshold. We avoid
    # actually invoking Aer per cell — that would dominate runtime —
    # and use the analytic distribution instead.
    theta = math.pi * 0.18  # tuned so the quantum world is visually distinct
    p_agree = math.cos(theta / 2.0) ** 2
    noise = rng.random(g.shape)
    keep = noise < p_agree

    birth = (g == 0) & (neigh == 3) & keep
    survive = (g == 1) & ((neigh == 2) | (neigh == 3)) & keep
    return (birth | survive).astype(np.uint8)


def _glider_seed(rows: int, cols: int) -> "object":
    import numpy as np

    g = np.zeros((rows, cols), dtype=np.uint8)
    pattern = [(1, 0), (2, 1), (0, 2), (1, 2), (2, 2)]
    for dr, dc in pattern:
        g[2 + dr, 2 + dc] = 1
    return g


def render(
    record: object | None = None,
    output: str | Path = "gallery/game_of_life.gif",
    *,
    rows: int = 48,
    cols: int = 48,
    n_frames: int = 80,
    fps: float = 12.0,
    seed: int = 42,
) -> Path:
    """Render the side-by-side GIF. ``record`` is accepted but unused."""
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.figure import Figure

    from quantum_flex.core import style
    from quantum_flex.core.visualize import save_animation

    style.apply()
    palette = style.palette()
    rng = np.random.default_rng(seed)

    classical = _glider_seed(rows, cols)
    quantum = classical.copy()

    frames = []
    for _ in range(n_frames):
        fig: Figure = plt.figure(figsize=(8, 4.5))
        ax_c = fig.add_subplot(1, 2, 1)
        ax_q = fig.add_subplot(1, 2, 2)
        for ax, grid, title, color in (
            (ax_c, classical, "Classical Conway", palette["classical"]),
            (ax_q, quantum, "Quantum-noisy Conway", palette["accent"]),
        ):
            ax.imshow(grid, cmap="binary_r", interpolation="nearest")
            ax.set_xticks([])
            ax.set_yticks([])
            ax.set_title(title, color=color, fontsize=11)
            for spine in ax.spines.values():
                spine.set_edgecolor(color)
        fig.tight_layout()
        fig.canvas.draw()
        rgba = np.asarray(fig.canvas.buffer_rgba())
        frames.append(rgba.copy())
        plt.close(fig)

        classical = _classical_step(classical)
        quantum = _quantum_step(quantum, rng)

    return save_animation(frames, output, fps=fps)


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="quantum-flex art game_of_life")
    p.add_argument("--out", type=Path, default=Path("gallery/game_of_life.gif"))
    p.add_argument("--rows", type=int, default=48)
    p.add_argument("--cols", type=int, default=48)
    p.add_argument("--frames", type=int, default=80)
    p.add_argument("--fps", type=float, default=12.0)
    p.add_argument("--seed", type=int, default=42)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)
    render(
        output=args.out,
        rows=args.rows, cols=args.cols,
        n_frames=args.frames, fps=args.fps, seed=args.seed,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
