"""Quantum interference field as a 3-D terrain heightmap.

We sample the magnitude of a small entangled state on a 2-D grid by
varying two RY angles, and render the resulting probability surface as
a hill-shaded relief map. Areas where amplitudes cancel show up as
valleys; constructive interference produces ridges.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path


def _interference_field(resolution: int = 192) -> "object":
    """Compute the 2-D probability field over (theta_a, theta_b).

    Closed-form derivation (avoids per-pixel Statevector construction):

      |ψ⟩ = (RY(θa) ⊗ RY(θb)) · CX · (H ⊗ I) |00⟩
          = (RY(θa) ⊗ RY(θb)) · (|00⟩ + |11⟩) / √2

    Then ``P(|00⟩) - P(|11⟩) = cos²(θa/2) cos²(θb/2) - sin²(θa/2) sin²(θb/2)``,
    which collapses to ``[cos(θa) + cos(θb)] / 2`` — vectorized below.
    """
    import numpy as np

    axis = np.linspace(0.0, 2.0 * math.pi, resolution, endpoint=False)
    theta_a, theta_b = np.meshgrid(axis, axis, indexing="ij")
    field = (np.cos(theta_a) + np.cos(theta_b)) / 2.0
    return field.astype(np.float32)


def render(
    record: object | None = None,
    output: str | Path = "gallery/terrain.png",
    *,
    resolution: int = 192,
) -> Path:
    """Render the interference-field terrain. ``record`` is accepted but unused."""
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.colors import LightSource

    from quantum_flex.core import style
    from quantum_flex.core.visualize import save_still

    style.apply()
    palette = style.palette()

    field = _interference_field(resolution)

    fig, ax = plt.subplots(figsize=(9, 7))
    ls = LightSource(azdeg=315, altdeg=45)
    cmap = plt.get_cmap("twilight_shifted")
    rgb = ls.shade(field, cmap=cmap, vert_exag=2.0, blend_mode="soft")
    ax.imshow(
        rgb,
        extent=(0, 2 * math.pi, 0, 2 * math.pi),
        origin="lower",
        interpolation="bilinear",
    )
    ax.contour(
        np.linspace(0, 2 * math.pi, resolution),
        np.linspace(0, 2 * math.pi, resolution),
        field,
        levels=10,
        colors=[palette["accent"]],
        alpha=0.35,
        linewidths=0.6,
    )
    ax.set_xlabel(r"$\theta_a$")
    ax.set_ylabel(r"$\theta_b$")
    ax.set_title(
        "Bell-state interference field  ·  "
        r"$P(|00\rangle) - P(|11\rangle)$",
        color=palette["accent"],
    )
    ax.set_xticks([0, math.pi, 2 * math.pi])
    ax.set_xticklabels(["0", r"$\pi$", r"$2\pi$"])
    ax.set_yticks([0, math.pi, 2 * math.pi])
    ax.set_yticklabels(["0", r"$\pi$", r"$2\pi$"])

    fig.tight_layout()
    out = save_still(fig, output)
    plt.close(fig)
    return out


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="quantum-flex art terrain")
    p.add_argument("--out", type=Path, default=Path("gallery/terrain.png"))
    p.add_argument("--resolution", type=int, default=192)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)
    render(output=args.out, resolution=args.resolution)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
