"""Two-slit-style superposition moire from a parameterized circuit.

We sweep a single rotation angle and stack the resulting probability
distributions row-by-row. The resulting image looks like the
Davisson-Germer interference fringes — except every column is a real
quantum-mechanical probability, not a synthesized gradient.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path


def _build_distribution_stack(n_qubits: int = 6, n_steps: int = 200) -> "object":
    """Return ``(n_steps, 2**n_qubits)`` probability stack."""
    import numpy as np
    from qiskit import QuantumCircuit
    from qiskit.quantum_info import Statevector

    dim = 1 << n_qubits
    stack = np.empty((n_steps, dim), dtype=np.float32)
    for i in range(n_steps):
        theta = 2.0 * math.pi * i / n_steps
        qc = QuantumCircuit(n_qubits)
        for q in range(n_qubits):
            qc.h(q)
        for q in range(n_qubits - 1):
            qc.cx(q, q + 1)
        for q in range(n_qubits):
            qc.rz(theta * (q + 1), q)
        for q in range(n_qubits):
            qc.h(q)
        sv = Statevector.from_instruction(qc)
        stack[i] = (np.abs(sv.data) ** 2).astype(np.float32)
    return stack


def render(
    record: object | None = None,
    output: str | Path = "gallery/interference.png",
    *,
    n_qubits: int = 6,
    n_steps: int = 200,
) -> Path:
    """Render the moire image. ``record`` is accepted but unused."""
    import matplotlib.pyplot as plt

    from quantum_flex.core import style
    from quantum_flex.core.visualize import save_still

    style.apply()
    palette = style.palette()

    stack = _build_distribution_stack(n_qubits=n_qubits, n_steps=n_steps)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.imshow(
        stack.T,
        aspect="auto",
        origin="lower",
        cmap="magma",
        extent=(0, 2 * math.pi, 0, 1 << n_qubits),
        interpolation="bilinear",
    )
    ax.set_xlabel(r"$\theta$")
    ax.set_ylabel("Bitstring index")
    ax.set_xticks([0, math.pi, 2 * math.pi])
    ax.set_xticklabels(["0", r"$\pi$", r"$2\pi$"])
    ax.set_title(
        f"{n_qubits}-qubit interference moiré  ·  "
        f"H⊗ then CX-chain then RZ(θ·k)",
        color=palette["accent"],
    )

    fig.tight_layout()
    out = save_still(fig, output)
    plt.close(fig)
    return out


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="quantum-flex art interference")
    p.add_argument("--out", type=Path, default=Path("gallery/interference.png"))
    p.add_argument("--n-qubits", type=int, default=6)
    p.add_argument("--n-steps", type=int, default=200)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)
    render(output=args.out, n_qubits=args.n_qubits, n_steps=args.n_steps)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
