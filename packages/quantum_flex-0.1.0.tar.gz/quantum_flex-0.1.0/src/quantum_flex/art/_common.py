"""Shared helpers for the ``art/*`` modules.

The art pieces accept either a ``RunRecord`` instance or a path to a
committed RunRecord JSON. ``load_record_or_none`` centralizes that
"either/or/missing" logic so each art module does not re-implement it.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from quantum_flex.core.record import RunRecord


def load_record_or_none(record: RunRecord | str | Path | None) -> RunRecord | None:
    """Resolve ``record`` into a ``RunRecord`` instance, or return ``None``.

    Accepted inputs:

      * ``None`` — returns ``None`` (the caller will generate synthetic data).
      * ``RunRecord`` — returned as-is.
      * ``str`` / ``Path`` — loaded via :meth:`RunRecord.load`.
    """
    if record is None:
        return None
    from quantum_flex.core.record import RunRecord

    if isinstance(record, RunRecord):
        return record
    return RunRecord.load(Path(record))


def counts_to_amplitude_array(counts: dict[str, int], n_bits: int) -> list[float]:
    """Map a ``{bitstring: count}`` dict to a length-``2^n_bits`` array of probs."""
    total = sum(counts.values())
    if total == 0:
        return [0.0] * (1 << n_bits)
    arr = [0.0] * (1 << n_bits)
    for bitstring, cnt in counts.items():
        clean = bitstring.replace(" ", "")
        if not clean:
            continue
        try:
            idx = int(clean, 2)
        except ValueError:
            continue
        if 0 <= idx < len(arr):
            arr[idx] = cnt / total
    return arr
