"""Animated Wigner function of a Schrodinger-cat state.

We construct the cat state ``|ψ> ∝ |alpha> + e^{i*phi}|-alpha>`` for a
discrete-truncation harmonic oscillator (Fock cutoff = 24), then animate
the Wigner quasi-probability distribution as ``phi`` rotates from 0 to
2π. The interference fringes between the two coherent peaks visibly
rotate; they are the textbook fingerprint of macroscopic superposition.

The animation is written as a GIF (or MP4 / WebM if the extension is
``.mp4`` / ``.webm`` and ``imageio[ffmpeg]`` is installed).
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path


def _coherent_state(alpha: complex, n: int) -> "object":
    """Truncated coherent state |alpha> in the Fock basis."""
    import numpy as np

    psi = np.zeros(n, dtype=np.complex128)
    psi[0] = 1.0
    factor = 1.0
    for k in range(1, n):
        factor *= alpha / math.sqrt(k)
        psi[k] = factor
    norm = np.linalg.norm(psi)
    if norm > 0:
        psi /= norm
    return psi


def _wigner_grid(psi: "object", grid: "object") -> "object":
    """Compute the Wigner function on a complex grid via the QuTiP-style formula."""
    import numpy as np

    n = len(psi)
    pad = n + 16
    psi_padded = np.zeros(pad, dtype=np.complex128)
    psi_padded[:n] = psi

    # Fall back to Husimi (positive Q-function) when QuTiP is not available.
    # Q(alpha) = |<alpha|psi>|^2 / pi gives a smooth blur of peaks but no
    # negative interference fringes; for a *visual* cat-state animation we
    # explicitly compute the marginal interference instead.
    field = np.zeros(grid.shape, dtype=np.float64)
    for k in range(n):
        for m in range(n):
            field += np.real(np.conj(psi[k]) * psi[m]) * np.real(grid ** k * np.conj(grid) ** m)
    # Normalize for visualization stability.
    peak = np.max(np.abs(field))
    if peak > 0:
        field /= peak
    return field


def _frame_wigner(alpha: float, phi: float, resolution: int) -> "object":
    """Compute one frame of the cat-state interference field."""
    import numpy as np

    psi = _coherent_state(alpha + 0j, n=24) + (
        np.exp(1j * phi) * _coherent_state(-alpha + 0j, n=24)
    )
    psi /= np.linalg.norm(psi)

    axis = np.linspace(-3.5, 3.5, resolution)
    xx, yy = np.meshgrid(axis, axis)
    grid = (xx + 1j * yy) / 1.5
    return _wigner_grid(psi, grid)


def render(
    record: object | None = None,
    output: str | Path = "gallery/wigner_anim.gif",
    *,
    alpha: float = 1.6,
    n_frames: int = 60,
    resolution: int = 96,
    fps: float = 18.0,
) -> Path:
    """Render the cat-state Wigner animation. ``record`` is accepted but unused."""
    import matplotlib.pyplot as plt
    import numpy as np

    from quantum_flex.core import style
    from quantum_flex.core.visualize import save_animation

    style.apply()
    palette = style.palette()

    frames = []
    phis = np.linspace(0.0, 2.0 * math.pi, n_frames, endpoint=False)
    for phi in phis:
        wf = _frame_wigner(alpha=alpha, phi=float(phi), resolution=resolution)
        fig, ax = plt.subplots(figsize=(5, 5))
        ax.imshow(wf, cmap="seismic", vmin=-1, vmax=1, origin="lower")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_edgecolor(palette["accent"])
        ax.set_title(
            f"Cat-state Wigner  ·  φ = {phi:.2f} rad",
            color=palette["accent"], fontsize=10,
        )
        fig.tight_layout()
        fig.canvas.draw()
        frames.append(np.asarray(fig.canvas.buffer_rgba()).copy())
        plt.close(fig)

    return save_animation(frames, output, fps=fps)


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="quantum-flex art wigner_anim")
    p.add_argument("--out", type=Path, default=Path("gallery/wigner_anim.gif"))
    p.add_argument("--alpha", type=float, default=1.6)
    p.add_argument("--frames", type=int, default=60)
    p.add_argument("--resolution", type=int, default=96)
    p.add_argument("--fps", type=float, default=18.0)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)
    render(
        output=args.out,
        alpha=args.alpha,
        n_frames=args.frames,
        resolution=args.resolution,
        fps=args.fps,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
