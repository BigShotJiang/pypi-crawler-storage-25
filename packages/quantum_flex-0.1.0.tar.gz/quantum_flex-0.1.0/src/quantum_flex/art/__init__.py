"""Visualizations driven by ``RunRecord`` JSON files.

Every module here exposes a ``render(record, output, **kwargs)`` function
that takes a :class:`quantum_flex.core.record.RunRecord` (or a path to one
on disk) and writes a figure or animation to ``output``.

Shipped modules (v0.1.0):

  * :mod:`quantum_flex.art.mandala`        — interference-pattern mandala
  * :mod:`quantum_flex.art.terrain`        — interference-field 3-D heightmap
  * :mod:`quantum_flex.art.interference`   — superposition moiré
  * :mod:`quantum_flex.art.game_of_life`   — quantum vs. classical Conway
  * :mod:`quantum_flex.art.wigner_anim`    — cat-state Wigner animation
  * :mod:`quantum_flex.art.pinball`        — 2-D quantum-walk pinball

All modules pull the shared style palette from
:mod:`quantum_flex.core.style` so that the gallery as a whole stays
visually coherent.
"""

from __future__ import annotations
