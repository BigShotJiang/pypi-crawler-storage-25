"""2-D quantum-walk pinball — a Galton-board analogue with interference.

A discrete-time quantum walk on a 2-D lattice produces a probability
distribution whose envelope spreads ballistically (linearly in time)
rather than diffusively (sqrt-time, like a classical random walk). We
animate the walker's probability as a heatmap; the diamond-shaped
"caustics" at the front of the wavefunction are the visual signature
of the interference.
"""

from __future__ import annotations

import argparse
from pathlib import Path


def _coin_step(state: "object", coin_op: "object") -> "object":
    """Apply the coin operator on every site, then shift along (x, y)."""
    import numpy as np

    rows, cols, _ = state.shape
    coined = np.einsum("ij,xyj->xyi", coin_op, state)

    shifted = np.zeros_like(coined)
    # Each component of the coin (0..3) shifts in one of the four cardinal
    # directions: 0 = +x, 1 = -x, 2 = +y, 3 = -y.
    shifted[:, :, 0] = np.roll(coined[:, :, 0], +1, axis=0)
    shifted[:, :, 1] = np.roll(coined[:, :, 1], -1, axis=0)
    shifted[:, :, 2] = np.roll(coined[:, :, 2], +1, axis=1)
    shifted[:, :, 3] = np.roll(coined[:, :, 3], -1, axis=1)

    # Hard-wall reflection at the edges (zero out the wrapped contributions).
    shifted[0, :, 0] = 0.0
    shifted[-1, :, 1] = 0.0
    shifted[:, 0, 2] = 0.0
    shifted[:, -1, 3] = 0.0
    return shifted


def render(
    record: object | None = None,
    output: str | Path = "gallery/pinball.gif",
    *,
    grid_size: int = 81,
    n_frames: int = 60,
    fps: float = 16.0,
) -> Path:
    """Render the quantum-walk animation. ``record`` is accepted but unused."""
    import matplotlib.pyplot as plt
    import numpy as np

    from quantum_flex.core import style
    from quantum_flex.core.visualize import save_animation

    style.apply()
    palette = style.palette()

    n = grid_size
    state = np.zeros((n, n, 4), dtype=np.complex128)
    center = n // 2
    state[center, center, :] = 0.5  # symmetric superposition

    # Grover coin (4x4) — gives the most isotropic spread.
    grover = (np.full((4, 4), 0.5, dtype=np.complex128) - np.eye(4, dtype=np.complex128))

    frames = []
    for _ in range(n_frames):
        prob = np.sum(np.abs(state) ** 2, axis=2)
        fig, ax = plt.subplots(figsize=(5, 5))
        ax.imshow(prob, cmap="inferno", origin="lower", interpolation="bilinear")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_edgecolor(palette["accent"])
        ax.set_title(
            f"Quantum walk  ·  total prob = {np.sum(prob):.3f}",
            color=palette["accent"], fontsize=10,
        )
        fig.tight_layout()
        fig.canvas.draw()
        frames.append(np.asarray(fig.canvas.buffer_rgba()).copy())
        plt.close(fig)
        state = _coin_step(state, grover)

    return save_animation(frames, output, fps=fps)


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="quantum-flex art pinball")
    p.add_argument("--out", type=Path, default=Path("gallery/pinball.gif"))
    p.add_argument("--grid-size", type=int, default=81)
    p.add_argument("--frames", type=int, default=60)
    p.add_argument("--fps", type=float, default=16.0)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)
    render(
        output=args.out,
        grid_size=args.grid_size,
        n_frames=args.frames,
        fps=args.fps,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
