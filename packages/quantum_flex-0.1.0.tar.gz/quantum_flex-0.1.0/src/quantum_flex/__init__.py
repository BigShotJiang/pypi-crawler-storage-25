"""quantum-flex: real-hardware Qiskit experiments and quantum visualizations.

The public surface is intentionally small. Most users want one of:

  * ``quantum_flex.core.RunRecord`` — load/save committed run records.
  * ``quantum_flex.core.runner`` — run a circuit on Aer or IBM Quantum.
  * ``quantum_flex.art`` — render figures and animations from RunRecords.
  * ``quantum_flex.experiments.<name>`` — a specific experiment module.

The CLI entry point ``quantum-flex`` (defined in :mod:`quantum_flex.cli`)
is the supported way to scaffold and promote new experiments.
"""

from __future__ import annotations

__version__ = "0.1.0"
__all__ = ["__version__"]
