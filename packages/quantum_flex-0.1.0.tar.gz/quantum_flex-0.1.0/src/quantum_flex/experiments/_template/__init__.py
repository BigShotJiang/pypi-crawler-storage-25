"""Experiment scaffold copied by ``quantum-flex new <name>``.

This package is intentionally not a runnable experiment. Editing it changes
the template that future ``new`` invocations will produce.
"""

from __future__ import annotations
