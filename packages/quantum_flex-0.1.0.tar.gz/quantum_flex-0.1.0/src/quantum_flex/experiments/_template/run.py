"""Execute ``<EXPERIMENT_NAME>`` on Aer or IBM Quantum and persist a RunRecord.

Usage::

    python -m quantum_flex.experiments.<EXPERIMENT_NAME>.run --backend aer
    python -m quantum_flex.experiments.<EXPERIMENT_NAME>.run --backend ibm_fez --shots 4000

Real-hardware execution requires ``QISKIT_IBM_TOKEN`` to be set in the
environment. The token is never written to disk by this script.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Imports below are deferred to keep ``--help`` instant and to avoid importing
# qiskit at module-load time when the user only wants documentation.


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex run <EXPERIMENT_NAME>",
        description="Execute the <EXPERIMENT_NAME> circuit and write a RunRecord JSON.",
    )
    p.add_argument(
        "--backend",
        default="aer",
        help="'aer' for the Aer simulator, or an IBM device name like 'ibm_fez'.",
    )
    p.add_argument("--shots", type=int, default=1024, help="Number of shots.")
    p.add_argument(
        "--out",
        type=Path,
        default=None,
        help="Output JSON path (default: data/runs/<date>_<EXPERIMENT_NAME>.json).",
    )
    p.add_argument(
        "--notes",
        default="",
        help="Free-text notes to attach to the RunRecord.",
    )
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    # Deferred imports — see module docstring.
    from quantum_flex.core import runner
    from quantum_flex.core.record import default_output_path

    from .circuit import build_circuit

    qc = build_circuit()

    record = runner.run(
        circuit=qc,
        backend=args.backend,
        shots=args.shots,
        experiment="<EXPERIMENT_NAME>",
        notes=args.notes,
    )

    # Compute experiment-specific metrics and attach to record.
    # Replace this block with the actual analysis for your experiment.
    record.metrics = {"shots": args.shots, "n_unique_outcomes": len(record.raw_counts)}

    output = args.out or default_output_path("<EXPERIMENT_NAME>")
    record.save(output)

    print(f"wrote {output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
