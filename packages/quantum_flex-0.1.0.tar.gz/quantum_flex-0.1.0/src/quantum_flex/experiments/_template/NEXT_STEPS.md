# Next steps for `<EXPERIMENT_NAME>`

A short, dated list of follow-ups. Update as you learn more. Examples:

  - [ ] Sweep `shots` from 256 → 16 384 to check that the metric stabilizes.
  - [ ] Re-run on a second backend (e.g. `ibm_kingston`) to check device
        dependence.
  - [ ] Add a noise-mitigation pass (`M3` or `T-REx`) and compare.
  - [ ] If the result disconfirms the hypothesis, write `LESSONS_LEARNED.md`
        and *do not delete the failing run*.
  - [ ] Promote out of `_wip/` once the metric is stable across two re-runs
        on at least two backends.

When the list is empty and the experiment is mature, run
`quantum-flex promote <EXPERIMENT_NAME>` to graduate it from `_wip/` to
`experiments/`.
