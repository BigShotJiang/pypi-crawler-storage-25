# `<EXPERIMENT_NAME>` (template)

> **You are looking at the experiment template.** It is what
> `quantum-flex new <name>` copies from. Do not edit the files here unless
> you intend to change the scaffold for *every future experiment*.

After scaffolding, replace this README with the four sections below.

---

## Hypothesis

What do you expect to see, and why?

(One paragraph. Cite a paper or a Qiskit textbook section if relevant.)

## Method

  - Backend: `aer_simulator` / `ibm_fez` / etc.
  - Number of qubits: ...
  - Shots: ...
  - Circuit summary: gates used, depth.
  - Any noise mitigation, transpilation flags, or session settings worth
    mentioning.

Pseudo-code or an OpenQASM excerpt is welcome.

## Observed result

  - Numerical metric(s): ...
  - Plot or animation: see `data/runs/<date>_<name>.json` and
    `quantum_flex.art.<module>` for the rendering.
  - Compared to the hypothesis: confirmed / disconfirmed / inconclusive.

## Interpretation

What did we learn? What is the next thing you would try?

If this experiment **failed** (i.e. did not confirm the hypothesis), keep
the data anyway and add a `LESSONS_LEARNED.md` next to this file. The
failure museum is a feature, not a bug.

---

## Reproduce

```bash
# Aer
python -m quantum_flex.experiments.<EXPERIMENT_NAME>.run --backend aer

# IBM real hardware (requires QISKIT_IBM_TOKEN)
python -m quantum_flex.experiments.<EXPERIMENT_NAME>.run --backend ibm_fez --shots 4000

# Render
python -m quantum_flex.experiments.<EXPERIMENT_NAME>.visualize \
    --record data/runs/<date>_<EXPERIMENT_NAME>.json \
    --out gallery/<EXPERIMENT_NAME>.png
```
