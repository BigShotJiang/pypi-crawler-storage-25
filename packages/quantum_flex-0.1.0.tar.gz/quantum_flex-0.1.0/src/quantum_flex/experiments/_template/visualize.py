"""Render a figure (or animation) from a committed RunRecord JSON.

Usage::

    python -m quantum_flex.experiments.<EXPERIMENT_NAME>.visualize \\
        --record data/runs/2026-04-18_<EXPERIMENT_NAME>.json \\
        --out gallery/<EXPERIMENT_NAME>.png

The default implementation below produces a measurement-counts bar chart.
Replace it with whatever visualization is meaningful for your experiment.
The whole point of separating ``visualize.py`` from ``run.py`` is that
re-rendering never re-executes circuits.
"""

from __future__ import annotations

import argparse
from pathlib import Path


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex visualize <EXPERIMENT_NAME>",
        description="Render a figure from a committed RunRecord JSON.",
    )
    p.add_argument(
        "--record",
        type=Path,
        required=True,
        help="Path to the RunRecord JSON to render.",
    )
    p.add_argument(
        "--out",
        type=Path,
        required=True,
        help="Output figure path (.png, .svg, .mp4, .gif).",
    )
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    # Deferred imports.
    import matplotlib.pyplot as plt

    from quantum_flex.core import style
    from quantum_flex.core.record import RunRecord

    record = RunRecord.load(args.record)

    style.apply()  # shared matplotlib theme

    fig, ax = plt.subplots(figsize=(8, 4.5))
    counts = record.raw_counts
    keys = sorted(counts.keys())
    ax.bar(keys, [counts[k] for k in keys], color=style.PALETTE["accent"])
    ax.set_title(f"{record.experiment}  ·  {record.backend['name']}  ·  shots={record.execution['shots']}")
    ax.set_xlabel("Bitstring")
    ax.set_ylabel("Count")
    fig.tight_layout()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.out, dpi=180)
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
