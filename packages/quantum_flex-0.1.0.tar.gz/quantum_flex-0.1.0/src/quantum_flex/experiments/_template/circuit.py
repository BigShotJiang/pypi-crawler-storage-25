"""Circuit definition for ``<EXPERIMENT_NAME>``.

Replace this docstring with a one-paragraph description of the circuit
you are building (which gates, why, and what the measurement basis is).

The function below is intentionally pure: it constructs and returns a
``qiskit.QuantumCircuit`` and does not execute or transpile it. Execution
lives in ``run.py``; transpilation lives in ``quantum_flex.core.runner``.
This separation is what lets ``visualize.py`` re-render results from
committed JSON without ever touching Qiskit's runtime.
"""

from __future__ import annotations

from qiskit import QuantumCircuit


def build_circuit() -> QuantumCircuit:
    """Construct and return the experiment's circuit.

    Edit this function. The default below is a trivial Bell-pair example
    so that the scaffold runs end-to-end without further changes.
    """
    qc = QuantumCircuit(2, 2, name="<EXPERIMENT_NAME>_template")
    qc.h(0)
    qc.cx(0, 1)
    qc.measure([0, 1], [0, 1])
    return qc
