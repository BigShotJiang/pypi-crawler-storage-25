"""Mermin-Peres "magic square" pseudo-telepathy game.

Two players (Alice and Bob) cooperate to fill in a 3x3 grid: Alice gets
a row index, Bob gets a column index, neither tells the other which one.
Their answers must agree on the shared cell *and* satisfy parity
constraints on each row / column. The classical optimum is exactly
8/9 ≈ 88.9 %; quantum strategies using two shared Bell pairs reach
9/9 = 100 % in the noiseless limit. This experiment runs all nine
``(row, col)`` instances and reports the empirical win rate.
"""

from __future__ import annotations
