"""Render the Mermin-Peres experiment as a 3x3 win-rate heatmap.

Each cell shows the empirical win rate for the corresponding ``(row,
col)`` instance. The cell color is taken from the house palette: cyan
when above the classical 8/9 line, amber when within ±2 percentage
points of it, magenta-pink-failure when clearly below.
"""

from __future__ import annotations

import argparse
from pathlib import Path


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex visualize mermin_peres",
        description="Render the magic-square experiment as a 3x3 heatmap.",
    )
    p.add_argument("--record", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    import matplotlib.pyplot as plt

    from quantum_flex.core import style
    from quantum_flex.core.record import RunRecord
    from quantum_flex.core.visualize import save_still

    record = RunRecord.load(args.record)
    metrics = record.metrics
    palette = style.palette()
    classical = float(metrics["classical_bound"])

    style.apply()
    fig, ax = plt.subplots(figsize=(6.5, 6.5))

    grid = [[0.0] * 3 for _ in range(3)]
    for entry in metrics["per_instance"]:
        grid[int(entry["row"])][int(entry["col"])] = float(entry["rate"])

    def color_for(rate: float) -> str:
        if rate >= classical + 0.02:
            return palette["accent"]
        if abs(rate - classical) <= 0.02:
            return palette["accent3"]
        return palette["failure"]

    for r in range(3):
        for c in range(3):
            rate = grid[r][c]
            ax.add_patch(plt.Rectangle(
                (c, 2 - r), 1, 1,
                facecolor=color_for(rate), edgecolor=palette["fg_muted"], linewidth=1.5,
            ))
            ax.text(
                c + 0.5, 2 - r + 0.55, f"{rate*100:.1f}%",
                ha="center", va="center", fontsize=18, color=palette["bg"],
            )
            ax.text(
                c + 0.5, 2 - r + 0.20, f"({r}, {c})",
                ha="center", va="center", fontsize=9, color=palette["bg"],
            )

    ax.set_xlim(0, 3)
    ax.set_ylim(0, 3)
    ax.set_aspect("equal")
    ax.set_xticks([0.5, 1.5, 2.5])
    ax.set_xticklabels(["col 0", "col 1", "col 2"])
    ax.set_yticks([2.5, 1.5, 0.5])
    ax.set_yticklabels(["row 0", "row 1", "row 2"])
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)

    avg = float(metrics["average_rate"])
    beats = bool(metrics["beats_classical"])
    title_color = palette["accent"] if beats else palette["failure"]
    ax.set_title(
        f"Mermin-Peres on {record.backend.get('name', '?')}  ·  "
        f"avg {avg*100:.2f}%  vs  classical {classical*100:.2f}%",
        color=title_color,
    )

    fig.tight_layout()
    save_still(fig, args.out)
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
