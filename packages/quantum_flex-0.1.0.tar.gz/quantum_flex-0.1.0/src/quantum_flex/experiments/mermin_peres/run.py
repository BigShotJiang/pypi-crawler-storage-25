"""Execute the Mermin-Peres pseudo-telepathy game on Aer or IBM Quantum.

Usage::

    python -m quantum_flex.experiments.mermin_peres.run --backend aer
    python -m quantum_flex.experiments.mermin_peres.run --backend ibm_fez --shots 4096

The score reported is the average win rate over the nine game instances.
The classical maximum is exactly ``8/9 ≈ 0.8889``; ideal quantum is
``1.0``. A run is "successful" if the average exceeds the classical
bound by more than the per-instance statistical error.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qiskit import QuantumCircuit

EXPERIMENT_NAME = "mermin_peres"
CLASSICAL_BOUND = 8.0 / 9.0  # ≈ 0.8889


def _check_win(row: int, col: int, m0: int, m1: int, m2: int, m3: int) -> bool:
    """Score the agreement between Alice's row-answer and Bob's column-answer.

    The third entry on each side is determined by the parity rule (even
    for rows, odd for column 2, even otherwise), which is why it does
    not need a measurement of its own.
    """
    if row == 0:
        alice = [m0, m1, m0 ^ m1]
    elif row == 1:
        alice = [m1, m0, m0 ^ m1]
    else:
        alice = [m1, m0, m0 ^ m1]

    if col == 0:
        bob = [m2, m3, m2 ^ m3]
    elif col == 1:
        bob = [m3, m2, m2 ^ m3]
    else:
        bob = [m3, m2, m3 ^ m2 ^ 1]

    return alice[col] == bob[row]


def _score_counts(row: int, col: int, counts: dict[str, int]) -> tuple[int, int]:
    """Return (wins, total) for one (row, col) game instance."""
    wins = total = 0
    for bitstring, cnt in counts.items():
        bits = bitstring.replace(" ", "")[::-1]
        if len(bits) < 4:
            continue
        m = [int(bits[i]) for i in range(4)]
        if _check_win(row, col, *m):
            wins += cnt
        total += cnt
    return wins, total


def _run_one(
    circuit: QuantumCircuit, *, backend: str, shots: int, label: str
) -> tuple[dict[str, int], float]:
    from quantum_flex.core import runner

    record = runner.run(
        circuit=circuit,
        backend=backend,
        shots=shots,
        experiment=f"{EXPERIMENT_NAME}/{label}",
    )
    return record.raw_counts, float(record.execution.get("duration_seconds", 0.0))


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex run mermin_peres",
        description="Mermin-Peres magic-square pseudo-telepathy game.",
    )
    p.add_argument("--backend", default="aer")
    p.add_argument("--shots", type=int, default=4096)
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--notes", default="")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    from quantum_flex.core.record import RunRecord, default_output_path

    from .circuit import build_circuits

    circuits = build_circuits()

    per_instance = []
    total_duration = 0.0
    total_wins = total_total = 0
    for (row, col), qc in circuits.items():
        counts, duration = _run_one(
            qc, backend=args.backend, shots=args.shots, label=f"{row}{col}"
        )
        wins, total = _score_counts(row, col, counts)
        rate = wins / total if total > 0 else 0.0
        per_instance.append({
            "row": row, "col": col,
            "wins": wins, "total": total, "rate": rate,
            "raw_counts": counts,
        })
        total_wins += wins
        total_total += total
        total_duration += duration
        print(f"  ({row},{col}): {rate*100:5.2f}%  ({wins}/{total})", file=sys.stderr)

    average_rate = total_wins / total_total if total_total > 0 else 0.0

    summary_record = RunRecord(
        experiment=EXPERIMENT_NAME,
        backend={"name": args.backend, "category": "aer" if args.backend == "aer" else "ibm"},
        circuit={
            "qasm": "# nine magic-square circuits, see metrics['per_instance']",
            "depth": int(max(qc.depth() for qc in circuits.values())),
            "gate_count": int(sum(qc.size() for qc in circuits.values())),
            "n_qubits_used": 4,
        },
        execution={"shots_per_instance": args.shots, "duration_seconds": total_duration},
        raw_counts={},
        metrics={
            "per_instance": per_instance,
            "average_rate": average_rate,
            "classical_bound": CLASSICAL_BOUND,
            "beats_classical": average_rate > CLASSICAL_BOUND,
            "shots_per_instance": args.shots,
        },
        notes=args.notes,
    )

    output = args.out or default_output_path(EXPERIMENT_NAME)
    summary_record.save(output)
    verdict = "BEATS classical" if average_rate > CLASSICAL_BOUND else "below classical"
    print(
        f"avg = {average_rate*100:.2f}%  vs classical {CLASSICAL_BOUND*100:.2f}%  ({verdict})",
        file=sys.stderr,
    )
    print(f"wrote {output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
