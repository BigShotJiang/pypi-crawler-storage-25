# `mermin_peres` — Magic-Square Pseudo-Telepathy

## Hypothesis

The Mermin-Peres magic square is a 3×3 grid of ±1 values where every
row product is +1 and every column product is +1 *except* the third
column, which is -1. This contradiction makes it impossible for any
classical strategy — including unlimited shared randomness — to win
the game with probability greater than ``8/9 ≈ 88.89 %``. Two shared
Bell pairs raise that ceiling to ``1.0``.

## Method

  - **Backend**: Aer simulator by default; ``--backend ibm_fez`` for
    real hardware.
  - **Qubits**: 4 (Alice on ``q0, q1``; Bob on ``q2, q3``).
  - **Shots**: 4096 per instance × 9 instances = 36 864 total.
  - **Bell pairs**: ``(q0, q2)`` and ``(q1, q3)``, prepared at the
    start of every circuit.
  - **Basis selection**: Alice rotates ``(q0, q1)`` based on her
    assigned row; Bob rotates ``(q2, q3)`` based on his assigned
    column. The third grid entry on each side is determined by the
    parity rule and is therefore not measured.

## Observed result

  - Per-instance and overall win rate.
  - The figure is a 3×3 heatmap colored by whether each cell beats the
    classical bound.
  - On Aer: every cell ≈ 100 %. On real hardware: typically 92–97 % per
    cell, average ≈ 94 % — *above* the classical 88.89 % line.

## Interpretation

This is the cleanest "no-classical-strategy-can-do-this" demonstration
in the gallery. Unlike CHSH, which is a *statistical* violation of an
inequality, the magic-square game is a *deterministic* contradiction
that classical players literally cannot win every time, regardless of
prior agreement.

A real-hardware run that *does not* exceed 88.89 % usually means
two-qubit gate noise has destroyed enough of the entanglement that the
quantum strategy degraded to (worse than) the classical maximum.

---

## Reproduce

```bash
# Aer
python -m quantum_flex.experiments.mermin_peres.run --backend aer

# IBM real hardware (requires QISKIT_IBM_TOKEN)
python -m quantum_flex.experiments.mermin_peres.run --backend ibm_fez --shots 4096

# Render
python -m quantum_flex.experiments.mermin_peres.visualize \
    --record data/runs/<date>_mermin_peres.json \
    --out gallery/mermin_peres.png
```
