"""Magic-square circuits for all nine (row, column) game instances.

Layout (qubits ``q0..q3``):

  * ``q0, q1`` — Alice's two qubits.
  * ``q2, q3`` — Bob's two qubits.
  * Two shared Bell pairs: ``(q0, q2)`` and ``(q1, q3)``.

Alice's measurement basis depends on her row, Bob's on his column. Both
sides return a 2-bit answer; the third bit each fills in is determined
by the row / column parity constraint and is therefore not measured.
"""

from __future__ import annotations

from qiskit import QuantumCircuit


def build_magic_square_circuit(row: int, col: int) -> QuantumCircuit:
    """Return the circuit for the ``(row, col)`` game instance."""
    if not 0 <= row < 3 or not 0 <= col < 3:
        raise ValueError(f"row and col must be in 0..2, got ({row}, {col})")

    qc = QuantumCircuit(4, name=f"magic_{row}{col}")
    # Two Bell pairs: (q0 <-> q2), (q1 <-> q3).
    qc.h(0)
    qc.cx(0, 2)
    qc.h(1)
    qc.cx(1, 3)
    qc.barrier()

    # Alice's basis change for her row.
    if row == 0:
        # Row 0 is already Z-Z; nothing to do.
        pass
    elif row == 1:
        qc.h(0)
        qc.h(1)
    else:
        # Row 2: diagonalize {Z⊗X, X⊗Z, Y⊗Y}.
        qc.h(1)
        qc.cx(0, 1)
        qc.h(0)

    # Bob's basis change for his column.
    if col == 0:
        qc.h(3)
    elif col == 1:
        qc.h(2)
    else:
        qc.cx(2, 3)
        qc.h(2)

    qc.measure_all()
    return qc


def build_circuits() -> dict[tuple[int, int], QuantumCircuit]:
    """Return all nine ``(row, col)`` game circuits keyed by index pair."""
    return {(r, c): build_magic_square_circuit(r, c) for r in range(3) for c in range(3)}
