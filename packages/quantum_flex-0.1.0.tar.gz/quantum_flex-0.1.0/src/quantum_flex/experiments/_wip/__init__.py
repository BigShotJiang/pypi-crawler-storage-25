"""The failure museum.

Modules under :mod:`quantum_flex.experiments._wip` are *not* a temporary
staging area; they are a permanent, public record of honest attempts that
either failed outright or are still in flight.

Each ``_wip/<name>/`` directory must contain at minimum:

  * ``README.md``           — original hypothesis, observed result.
  * ``LESSONS_LEARNED.md``  — post-mortem; why it failed; what could fix it.
  * ``circuit.py``, ``run.py``, ``visualize.py`` — the same four-file layout
    as a mature experiment.
  * At least one entry under ``data/runs/`` capturing the failing run.

Promoting a directory out of ``_wip/`` is done with::

    quantum-flex promote <name>

which moves it to :mod:`quantum_flex.experiments.<name>`. We never
``git rm`` a failure: the corrected version goes next to it (with a
``_v2`` suffix or similar), the original stays as historical record.
"""

from __future__ import annotations
