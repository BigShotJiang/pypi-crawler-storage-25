# Post-mortem: why the quantum walk lost to the Hungarian algorithm

## What we predicted

A walk-based heuristic that would land within 5 % of the Hungarian
optimum, with comparable end-to-end wall time at `n = 24`.

## What actually happened

  - **31 % worse** than the optimum (best-of-2048 shots).
  - **~3 × 10⁶ × slower** than the Hungarian algorithm.
  - The decoder fell back to the identity assignment on **64 %** of
    shots because the measurement bitstring did not respect the
    bipartite-matching constraint.

## Root causes

  1. **Wrong encoding for the constraint.**
     One qubit per vertex makes the matching constraint
     ("each worker maps to exactly one task and vice-versa") an
     *implicit* condition that the measurement violates with very high
     probability. A `log2(n!)` encoding into the symmetric group
     subspace would respect the constraint by construction, but
     constructing that subspace ansatz at `n = 24` is its own research
     project. We picked the easy encoding and paid for it at
     measurement time.

  2. **Mixer doesn't learn from costs.**
     A uniform mixer ``sum(X_i)`` on the task register does no
     gradient-following: it just diffuses uniformly across all task
     assignments. The walk-based heuristics that *do* beat classical
     methods (e.g. Childs-Schulman 2009 for spatial search on the
     hypercube) all use mixers that already encode some structure of
     the problem. We did not.

  3. **The Hungarian algorithm is the optimum.**
     This is the part that is most embarrassing in retrospect. The
     classical assignment problem has a **polynomial-time exact**
     algorithm (`O(n^3)`) — there is no asymptotic ceiling for the
     quantum walk to push through. The most quantum can do is shave a
     constant factor, and we were never going to do that with a
     Trotterized 48-qubit walk on Aer.

## What would actually be interesting to try

  - **NP-hard variants**: extend to the *quadratic* assignment problem
    (cost depends on the *pair* of assignments), which is genuinely
    intractable classically.
  - **Constraint-respecting ansatz**: a Hamming-weight-preserving QAOA
    on the symmetric-group encoding.
  - **Different problem entirely**: the assignment problem is a poor
    quantum-advantage candidate. Vertex cover, max independent set,
    and graph coloring on dense random instances are not solved
    exactly by classical polynomial-time algorithms and are better
    targets.

## What we keep on the record

This run, intact. The next attempt — if there is one — will live in
its own directory with its own README, not as an "edit" of this one.
The boundary between "interesting toy" and "actually useful" is exactly
where this experiment landed, and removing it would erase that data.
