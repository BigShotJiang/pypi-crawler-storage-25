# `_wip/quantum_lost_to_hungarian` — Quantum Walk Beaten by a 1955 Algorithm

## Hypothesis

A continuous-time quantum walk on the bipartite worker-task graph,
Trotterized into 8 time steps with mixer-driven exploration on the task
register, would find an assignment within ~5 % of optimal in shorter
end-to-end wall time than a classical solver, for medium ``n`` (24).

## Method

  - **Backend**: `aer_simulator` (this experiment never ran on real
    hardware — at 48 qubits and depth ~600, the device-time cost
    exceeded the engineering value before we got there).
  - **Qubits**: 48 (24 workers ⊕ 24 tasks).
  - **Shots**: 2048.
  - **Steps**: 8 Trotter steps, ``dt = 0.4``.
  - **Cost matrix**: deterministic, seed `11`, uniform `[0, 1]` per
    edge.
  - **Decoding**: read each shot's bitstring, pair worker `j` with the
    `j`-th task bit set to `1`, fall back to `worker == task` when the
    counts disagree.

## Observed result

  - Hungarian (`scipy.optimize.linear_sum_assignment`): exact optimum
    found in **~0.3 ms**.
  - Quantum walk best-of-2048 shots: **+31 %** over optimum.
  - Wall-clock: **~14 minutes** for the quantum routine, dominated by
    Aer simulation of the 48-qubit Trotterized circuit.

## Interpretation

A faithful negative result. The quantum walk *does* explore the
solution space — it simply explores it badly, because:

  - the encoding (1 qubit per vertex) is wasteful;
  - the mixer is uniform across tasks, so it doesn't learn from the
    cost landscape;
  - the decoder is brittle and silently falls back to the identity
    assignment when the bitstring violates the bipartite constraint.

The Hungarian algorithm is, fundamentally, the right tool for this
problem. We are not the first to discover this. We keep the result on
the record because it is far more honest than the usual "we did not
publish that experiment" silent-failure mode.
