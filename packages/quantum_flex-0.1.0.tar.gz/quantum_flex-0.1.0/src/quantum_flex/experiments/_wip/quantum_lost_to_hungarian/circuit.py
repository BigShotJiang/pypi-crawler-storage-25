"""Continuous-time quantum walk on a bipartite assignment graph.

We model a 24-task / 24-worker assignment problem with a bipartite graph
``K_{n,n}`` whose edge weights are the assignment costs. The quantum
walk Hamiltonian is the negative of the cost matrix lifted to the
adjacency matrix of the graph, and we Trotterize the evolution into
fixed time steps.

The qubit encoding is simple-minded — *one qubit per vertex* — which is
why we run out of width fast (2*n=48 qubits for n=24). A more efficient
encoding would use ``log2(n!)`` qubits, but constructing the
constraint-respecting subspace ansatz is the part of the experiment we
never made work; see ``LESSONS_LEARNED.md``.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qiskit import QuantumCircuit

WORKERS = 24
TASKS = 24


def _toy_cost_matrix(n: int = WORKERS, seed: int = 11) -> list[list[float]]:
    """Generate a deterministic toy cost matrix (uniform on [0, 1])."""
    import numpy as np

    rng = np.random.default_rng(seed)
    return [list(map(float, row)) for row in rng.uniform(0.0, 1.0, size=(n, n))]


def build_qwalk_circuit(
    n: int = WORKERS, n_steps: int = 8, dt: float = 0.4
) -> QuantumCircuit:
    """Trotterized continuous-time quantum walk on a bipartite ``K_{n,n}``."""
    from qiskit import QuantumCircuit

    qc = QuantumCircuit(2 * n, 2 * n, name="qwalk_assignment")
    # Uniform superposition on the worker register.
    for q in range(n):
        qc.h(q)

    cost = _toy_cost_matrix(n)
    for _ in range(n_steps):
        # Edge unitaries: e^{-i dt c_ij Z_i Z_j} between worker i and task j+n.
        for i in range(n):
            for j in range(n):
                qc.rzz(2.0 * dt * cost[i][j], i, j + n)
        # Mixer on the task register.
        for q in range(n, 2 * n):
            qc.rx(2.0 * dt * math.pi / n_steps, q)

    qc.measure(list(range(2 * n)), list(range(2 * n)))
    return qc
