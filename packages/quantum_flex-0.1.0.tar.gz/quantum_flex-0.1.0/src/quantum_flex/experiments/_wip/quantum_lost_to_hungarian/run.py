"""Run the quantum-walk assignment solver and compare to Hungarian.

The recorded RunRecord contains both the quantum-walk's best-of-shots
assignment cost *and* the exact optimum from ``scipy.optimize.linear_sum_assignment``.
Every metric in this experiment is set up so that the post-mortem in
``LESSONS_LEARNED.md`` can be reproduced from the JSON alone.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

EXPERIMENT_NAME = "quantum_lost_to_hungarian"


def _decode_assignment(bitstring: str, n: int) -> list[int]:
    """Decode the worker→task assignment from a 2n-bit measurement.

    Workers are bits ``[0:n]``, tasks are bits ``[n:2n]``. We pair the
    j-th worker bit set to 1 with the j-th task bit set to 1 in order;
    if the counts disagree we fall back to a partial pairing that simply
    repeats the last task. (The "fallback" is one of the failure modes
    documented in LESSONS_LEARNED.md.)
    """
    bits = bitstring.replace(" ", "")[::-1]
    workers = [i for i in range(n) if i < len(bits) and bits[i] == "1"]
    tasks = [j for j in range(n) if (n + j) < len(bits) and bits[n + j] == "1"]
    if not workers or not tasks:
        return list(range(n))  # degenerate; assigns worker i -> task i
    out = []
    for k in range(n):
        out.append(tasks[min(k, len(tasks) - 1)])
    return out


def _assignment_cost(assignment: list[int], cost: list[list[float]]) -> float:
    return float(sum(cost[w][a] for w, a in enumerate(assignment)))


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="quantum-flex run _wip/quantum_lost_to_hungarian")
    p.add_argument("--backend", default="aer")
    p.add_argument("--shots", type=int, default=2048)
    p.add_argument("--n", type=int, default=24, help="Workers / tasks.")
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--notes", default="")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    import numpy as np
    from scipy.optimize import linear_sum_assignment

    from quantum_flex.core import runner
    from quantum_flex.core.record import default_output_path

    from .circuit import _toy_cost_matrix, build_qwalk_circuit

    cost = _toy_cost_matrix(args.n)

    started_classical = time.perf_counter()
    row_idx, col_idx = linear_sum_assignment(np.array(cost))
    classical_optimum = float(np.array(cost)[row_idx, col_idx].sum())
    classical_seconds = time.perf_counter() - started_classical

    qc = build_qwalk_circuit(n=args.n)
    record = runner.run(
        circuit=qc,
        backend=args.backend,
        shots=args.shots,
        experiment=EXPERIMENT_NAME,
        notes=args.notes or "Failure-museum re-run; see LESSONS_LEARNED.md.",
    )

    counts = record.raw_counts
    best_cost = float("inf")
    best_assignment: list[int] = list(range(args.n))
    for bitstring, _ in sorted(counts.items(), key=lambda kv: -kv[1])[:64]:
        assignment = _decode_assignment(bitstring, args.n)
        c = _assignment_cost(assignment, cost)
        if c < best_cost:
            best_cost = c
            best_assignment = assignment

    quantum_excess = (best_cost - classical_optimum) / max(classical_optimum, 1e-9)

    record.metrics = {
        "n": args.n,
        "shots": args.shots,
        "classical_optimum": classical_optimum,
        "classical_seconds": classical_seconds,
        "quantum_best_cost": best_cost,
        "quantum_excess_ratio": quantum_excess,
        "quantum_best_assignment": best_assignment,
    }

    output = args.out or default_output_path(EXPERIMENT_NAME)
    record.save(output)
    print(
        f"classical {classical_optimum:.4f} (in {classical_seconds*1000:.2f} ms)  "
        f"vs quantum-best {best_cost:.4f}  "
        f"({quantum_excess*100:+.1f}%)",
        file=sys.stderr,
    )
    print(f"wrote {output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
