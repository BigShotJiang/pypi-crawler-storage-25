"""Failed attempt: a quantum-walk routing solver beaten by the Hungarian algorithm.

We tried to solve a 24-task / 24-worker assignment problem by encoding
it into a 24-qubit continuous-time quantum walk on a bipartite graph
and reading off the assignment from the post-measurement bitstring. The
classical Hungarian algorithm finished in 0.3 ms and produced the exact
optimum; the quantum routine took 14 minutes of wall-clock time to
return an answer that was 31 % worse than optimum. We keep the run on
the record to document where the boundary between "interesting toy" and
"actually useful for this task" actually sits.
"""

from __future__ import annotations
