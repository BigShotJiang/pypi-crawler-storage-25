"""Plot the quantum-walk best cost against the classical Hungarian optimum.

The figure is intentionally a single horizontal pair of bars, with the
``quantum_excess_ratio`` written across the top in big red type. The
goal is for someone scrolling through the gallery to immediately see
that this is the failure museum, not a celebration.
"""

from __future__ import annotations

import argparse
from pathlib import Path


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="quantum-flex visualize _wip/quantum_lost_to_hungarian")
    p.add_argument("--record", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    import matplotlib.pyplot as plt

    from quantum_flex.core import style
    from quantum_flex.core.record import RunRecord
    from quantum_flex.core.visualize import save_still

    record = RunRecord.load(args.record)
    metrics = record.metrics
    palette = style.palette()

    style.apply()
    fig, ax = plt.subplots(figsize=(8, 4))

    classical = float(metrics["classical_optimum"])
    quantum = float(metrics["quantum_best_cost"])
    excess = float(metrics["quantum_excess_ratio"])

    ax.barh(["Hungarian", "Quantum walk"], [classical, quantum],
            color=[palette["classical"], palette["failure"]],
            edgecolor=palette["fg_muted"])
    ax.invert_yaxis()
    ax.set_xlabel("Total assignment cost (lower is better)")
    ax.set_title(
        f"FAILURE — quantum_lost_to_hungarian  ·  excess  {excess*100:+.1f}%",
        color=palette["failure"],
    )

    fig.text(
        0.5, 0.02,
        f"Classical: {float(metrics['classical_seconds'])*1000:.2f} ms.  "
        f"Quantum: {int(metrics['shots'])} shots × walk steps + decode.",
        ha="center", color=palette["fg_muted"], fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    save_still(fig, args.out)
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
