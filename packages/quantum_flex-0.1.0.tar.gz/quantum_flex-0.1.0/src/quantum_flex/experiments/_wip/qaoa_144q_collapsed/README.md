# `_wip/qaoa_144q_collapsed` — 144-qubit QAOA Max-Cut, collapsed under noise

## Hypothesis

A two-layer (p=2) QAOA Max-Cut ansatz, parameter-warm-started from a
32-qubit run, transferred onto a random 3-regular graph at 144 vertices
should produce an output distribution mildly biased toward bitstrings
that achieve large cuts. The asymptotic optimum for a random 3-regular
graph at this size is roughly `0.9326 * 216 ≈ 201 cuts` out of 216
edges; we expected to see a measurable lift in the empirical mean cut
size relative to a random sampler.

## Method

  - **Backend**: `ibm_fez` (156-qubit Heron r2).
  - **Qubits**: 144.
  - **Layers (p)**: 2.
  - **Shots**: 4096.
  - **Parameters**: `(γ₁, β₁, γ₂, β₂) = (0.42, 0.31, 0.78, 0.19)`,
    obtained by 200 COBYLA iterations on a 32-qubit warm-start with the
    same edge density. **Not** retuned at scale.
  - **Edges**: random 3-regular graph, seed `1729`, 216 edges total.

## Observed result

  - The output distribution collapsed onto a small number of
    low-Hamming-weight bitstrings, with the top-1 outcome alone
    accounting for ~30 % of all shots. The empirical mean cut was
    *worse* than uniform-random sampling — the QAOA actively destroyed
    information.
  - The shape of the distribution matches the readout-error fingerprint
    we measure independently with a calibration sweep, which means the
    measurement step is dominating.

## Interpretation

This is a faithful negative result. It does **not** prove anything
about QAOA — only about this specific parameter-transfer recipe at
this specific width on this specific device. See `LESSONS_LEARNED.md`
for the post-mortem.
