"""Execute the failed QAOA experiment and write a RunRecord JSON.

This wraps the ansatz from :mod:`.circuit` with the same ``--backend``
plumbing as a mature experiment. We do not retune the parameters at
scale: the recorded failure mode requires that we use the warm-start
parameters from the 32-qubit run, and the LESSONS_LEARNED.md explains
why retuning at 144q would just have made the failure quieter.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

EXPERIMENT_NAME = "qaoa_144q_collapsed"


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex run _wip/qaoa_144q_collapsed",
        description="Run the historical failed 144-qubit QAOA experiment.",
    )
    p.add_argument("--backend", default="aer")
    p.add_argument("--shots", type=int, default=4096)
    p.add_argument("--n-qubits", type=int, default=144)
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--notes", default="")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    from quantum_flex.core import runner
    from quantum_flex.core.record import default_output_path

    from .circuit import build_qaoa_circuit, expected_optimum

    qc = build_qaoa_circuit(n_qubits=args.n_qubits)

    record = runner.run(
        circuit=qc,
        backend=args.backend,
        shots=args.shots,
        experiment=EXPERIMENT_NAME,
        notes=args.notes or "Failure-museum re-run; see LESSONS_LEARNED.md.",
    )

    counts = record.raw_counts
    top_outcomes = sorted(counts.items(), key=lambda kv: -kv[1])[:8]
    record.metrics = {
        "n_qubits": args.n_qubits,
        "shots": args.shots,
        "n_unique_outcomes": len(counts),
        "concentration_top1": (top_outcomes[0][1] / args.shots) if top_outcomes else 0.0,
        "top_outcomes": [{"bitstring": b, "count": c} for b, c in top_outcomes],
        "expected_maxcut_optimum": expected_optimum(),
    }

    output = args.out or default_output_path(EXPERIMENT_NAME)
    record.save(output)
    print(f"wrote {output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
