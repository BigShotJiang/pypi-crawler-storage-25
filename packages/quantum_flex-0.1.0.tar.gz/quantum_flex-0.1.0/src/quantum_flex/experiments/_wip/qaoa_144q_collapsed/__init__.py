"""Failed attempt: a 144-qubit QAOA Max-Cut that collapsed under noise.

This experiment ran successfully end-to-end on ibm_fez but produced a
distribution indistinguishable from the all-zeros readout-error
fingerprint: the QAOA layer count required to reach the optimum on a
144-vertex random 3-regular graph exceeded what the device's two-qubit
gate fidelity could sustain. We keep the run on the record because the
*shape* of the failure (mass concentrated on a single low-Hamming-weight
bitstring) is itself diagnostic of decoherence-dominated QAOA, and is a
useful baseline for future error-mitigation work.
"""

from __future__ import annotations
