# Post-mortem: why qaoa_144q_collapsed failed

## What we predicted

A modest QAOA bias toward bitstrings with large cut values, transferable
from 32 qubits to 144 because the per-edge cost contribution is local.

## What actually happened

Distribution collapsed onto low-Hamming-weight bitstrings. The mean
empirical cut was *below* uniform-random, meaning the protocol was
actively worse than not running QAOA at all.

## Three reasons the parameter-transfer recipe failed

  1. **Transferred parameters are not noise-aware.**
     The 32-qubit warm-start was performed on Aer with no noise model.
     At 144 qubits on real hardware, the entangling-gate count for a
     single QAOA layer scales linearly with the number of edges (216),
     so the effective ``γ`` "rotates" through a much larger error
     budget than the noiseless gradient predicted. The optimal ``γ``
     under noise is consistently smaller than the noiseless one
     (Streif & Leib 2020 §4); we were too far from the noise-aware
     optimum to recover.

  2. **Brick-wall transpilation inflates the depth far beyond p × edges.**
     Each ``RZZ`` decomposes into 2 × ``CX`` + 2 × ``RZ`` on Heron r2.
     ``optimization_level=1`` (the default) does not aggressively
     re-route, which left several edges going through 4-hop SWAP
     chains. Total transpiled depth was 312, not the ~70 we anticipated
     from the gate-count alone.

  3. **No readout error mitigation.**
     We did not apply M3 / TREX / MCM-based readout mitigation. With
     144 qubits and a per-qubit readout error of ~1.5 %, the *expected*
     fraction of shots with at least one bit flipped is
     ``1 - (1 - 0.015)^144 ≈ 89 %`` — almost no shot survives unmangled.

## What would fix this

  - **Refit parameters under a depolarizing-noise simulator** at the
    target width before transferring. Even a coarse single-qubit
    depolarizing model is enough to bring the noiseless optimum into
    the right neighborhood (Marwaha & Hadfield 2022).
  - **Use ``optimization_level=3``** plus an explicit qubit layout that
    matches the graph's edges to physical-coupling edges.
  - **Add M3 readout mitigation** as a second pass on the counts dict.
    For a 144-qubit experiment this is non-negotiable.
  - Consider switching from p=2 to p=1 — at this device fidelity, more
    layers are doing more harm than good. The sub-optimal p=1
    distribution is at least *informative*.

## What we keep on the record

This run, intact. The corrected version (when it lands) will live next
to it as `qaoa_144q_v2/`, not in place of it. The readout-fingerprint
shape is itself a valuable baseline for anyone evaluating mitigation
schemes against this hardware.
