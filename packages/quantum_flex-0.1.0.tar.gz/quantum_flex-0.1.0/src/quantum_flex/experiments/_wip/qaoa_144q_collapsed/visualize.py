"""Render the collapsed-QAOA distribution alongside its noiseless reference.

The intended visualization is *not* the bar chart that a healthy QAOA
distribution would warrant. We instead show the count concentration on
the all-zeros bitstring — the readout-error fingerprint — overlaid on
the much flatter Aer reference distribution. The contrast is the point.
"""

from __future__ import annotations

import argparse
from pathlib import Path


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="quantum-flex visualize _wip/qaoa_144q_collapsed")
    p.add_argument("--record", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    import matplotlib.pyplot as plt

    from quantum_flex.core import style
    from quantum_flex.core.record import RunRecord
    from quantum_flex.core.visualize import save_still

    record = RunRecord.load(args.record)
    metrics = record.metrics
    palette = style.palette()

    style.apply()
    fig, ax = plt.subplots(figsize=(9, 5))

    top = metrics.get("top_outcomes", [])
    labels = [t["bitstring"][:8] + "…" + t["bitstring"][-4:] for t in top]
    counts = [int(t["count"]) for t in top]
    ax.barh(
        list(reversed(labels)), list(reversed(counts)),
        color=palette["failure"], edgecolor=palette["fg_muted"],
    )
    ax.set_xlabel("Count")
    ax.set_title(
        "FAILURE — qaoa_144q_collapsed  ·  "
        f"top-1 concentration {float(metrics.get('concentration_top1', 0.0))*100:.1f}%",
        color=palette["failure"],
    )
    fig.text(
        0.5, 0.02,
        "Distribution mass concentrated on a single low-Hamming-weight bitstring is\n"
        "the readout-error fingerprint, not a successful Max-Cut sample.",
        ha="center", color=palette["fg_muted"], fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    save_still(fig, args.out)
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
