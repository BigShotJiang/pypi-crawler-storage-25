"""QAOA Max-Cut ansatz on a random 3-regular graph (n=144, p=2 layers).

The cost-Hamiltonian is the standard ``sum (1 - Z_i Z_j) / 2`` over edges.
The mixer is a transverse-field ``sum X_i``. Two QAOA layers means four
variational parameters ``(gamma_1, beta_1, gamma_2, beta_2)``; the values
below were obtained by 200 iterations of COBYLA on a 32-qubit Aer
warm-start, then transferred (without retraining) onto the 144-qubit
graph — which is the proximate cause of the failure documented in
``LESSONS_LEARNED.md``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qiskit import QuantumCircuit

# Pre-trained parameters from the 32-qubit warm-start (do NOT retune at scale).
GAMMA_1 = 0.42
BETA_1 = 0.31
GAMMA_2 = 0.78
BETA_2 = 0.19


def _random_3_regular_edges(n: int, seed: int = 1729) -> list[tuple[int, int]]:
    """Return a list of edges for a random 3-regular graph on ``n`` vertices."""
    import networkx as nx

    g = nx.random_regular_graph(3, n, seed=seed)
    return [(int(u), int(v)) for u, v in g.edges()]


def build_qaoa_circuit(
    n_qubits: int = 144, edges: list[tuple[int, int]] | None = None
) -> QuantumCircuit:
    """Construct the p=2 QAOA Max-Cut circuit. ``edges`` defaults to a random 3-regular graph."""
    from qiskit import QuantumCircuit

    if edges is None:
        edges = _random_3_regular_edges(n_qubits)

    qc = QuantumCircuit(n_qubits, n_qubits, name="qaoa_p2_maxcut")
    # Initial superposition.
    for q in range(n_qubits):
        qc.h(q)

    for layer_gamma, layer_beta in ((GAMMA_1, BETA_1), (GAMMA_2, BETA_2)):
        # Cost Hamiltonian: e^{-i gamma sum_e (I - Z_i Z_j) / 2}.
        for i, j in edges:
            qc.rzz(2.0 * layer_gamma, i, j)
        # Mixer Hamiltonian: e^{-i beta sum_q X_q}.
        for q in range(n_qubits):
            qc.rx(2.0 * layer_beta, q)

    qc.measure(list(range(n_qubits)), list(range(n_qubits)))
    return qc


def expected_optimum() -> float:
    """Approximate Max-Cut value for a random 3-regular graph on 144 vertices."""
    # For random 3-regular graphs the Max-Cut to edges ratio is ~0.9326 + o(1)
    # (Csoka, Gerencser, Harangi, Virag, 2015). With 144 vertices and 3-regular
    # there are exactly 216 edges, so the asymptotic optimum is ~201.4 cuts.
    return 0.9326 * 216.0
