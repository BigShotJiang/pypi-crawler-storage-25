"""Render the teleportation experiment as a per-state fidelity bar chart."""

from __future__ import annotations

import argparse
from pathlib import Path


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex visualize teleportation",
        description="Render the teleportation experiment from a RunRecord JSON.",
    )
    p.add_argument("--record", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    import matplotlib.pyplot as plt

    from quantum_flex.core import style
    from quantum_flex.core.record import RunRecord
    from quantum_flex.core.visualize import save_still

    record = RunRecord.load(args.record)
    metrics = record.metrics
    per_state = metrics["per_state"]
    palette = style.palette()

    style.apply()
    fig, ax = plt.subplots(figsize=(8, 4.5))

    labels = list(per_state.keys())
    fidelities = [float(per_state[k]["fidelity"]) for k in labels]

    def color_for(fid: float) -> str:
        if fid > 0.85:
            return palette["accent"]
        if fid > 0.7:
            return palette["accent3"]
        return palette["failure"]

    bars = ax.bar(
        labels, fidelities,
        color=[color_for(f) for f in fidelities],
        edgecolor=palette["fg_muted"],
    )
    for bar, fid in zip(bars, fidelities, strict=True):
        ax.text(
            bar.get_x() + bar.get_width() / 2, fid + 0.02,
            f"{fid:.3f}", ha="center", va="bottom",
            color=palette["fg"], fontsize=11,
        )

    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("Fidelity (1 − |P1 − P1_expected|)")
    ax.set_title(
        f"Teleportation on {record.backend.get('name', '?')}  ·  "
        f"avg = {float(metrics['average_fidelity']):.3f}"
    )

    fig.tight_layout()
    save_still(fig, args.out)
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
