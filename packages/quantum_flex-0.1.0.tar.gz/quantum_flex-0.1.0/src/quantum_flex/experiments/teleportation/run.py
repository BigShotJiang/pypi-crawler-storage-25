"""Execute the teleportation experiment and write a RunRecord JSON.

Usage::

    python -m quantum_flex.experiments.teleportation.run --backend aer
    python -m quantum_flex.experiments.teleportation.run --backend ibm_fez --shots 4096
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qiskit import QuantumCircuit

EXPERIMENT_NAME = "teleportation"

#: ``{label: P(Bob = |1>) for the corresponding ideal input}``.
EXPECTED_P1: dict[str, float] = {
    "|0>": 0.0,
    "|1>": 1.0,
    "|psi>": math.sin(math.pi / 8) ** 2,
}


def _score(counts: dict[str, int]) -> tuple[dict[str, int], float]:
    """Apply the X-correction in software and tally Bob's bit."""
    corrected = {0: 0, 1: 0}
    total = 0
    for bitstring, cnt in counts.items():
        bits = bitstring.replace(" ", "")[::-1]
        if len(bits) < 3:
            continue
        a1, bob = int(bits[1]), int(bits[2])
        if a1 == 1:
            bob ^= 1
        corrected[bob] += cnt
        total += cnt
    p1 = corrected[1] / total if total > 0 else 0.0
    return {"|0>": corrected[0], "|1>": corrected[1]}, p1


def _run_one(
    circuit: QuantumCircuit, *, backend: str, shots: int, label: str
) -> tuple[dict[str, int], float]:
    from quantum_flex.core import runner

    record = runner.run(
        circuit=circuit,
        backend=backend,
        shots=shots,
        experiment=f"{EXPERIMENT_NAME}/{label}",
    )
    return record.raw_counts, float(record.execution.get("duration_seconds", 0.0))


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex run teleportation",
        description="Quantum teleportation experiment on Aer or IBM Quantum.",
    )
    p.add_argument("--backend", default="aer")
    p.add_argument("--shots", type=int, default=4096)
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--notes", default="")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    from quantum_flex.core.record import RunRecord, default_output_path

    from .circuit import build_circuits

    circuits = build_circuits()

    per_state: dict[str, dict[str, object]] = {}
    total_duration = 0.0
    for label, qc in circuits.items():
        counts, duration = _run_one(qc, backend=args.backend, shots=args.shots, label=label)
        bob_counts, p1 = _score(counts)
        expected = EXPECTED_P1[label]
        fidelity = 1.0 - abs(p1 - expected)
        per_state[label] = {
            "raw_counts": counts,
            "bob_counts": bob_counts,
            "p1": p1,
            "expected_p1": expected,
            "fidelity": fidelity,
        }
        total_duration += duration
        print(f"  {label}: fidelity = {fidelity:.4f}  (P1={p1:.3f}, expected {expected:.3f})", file=sys.stderr)

    avg_fidelity = sum(float(p["fidelity"]) for p in per_state.values()) / len(per_state)

    summary_record = RunRecord(
        experiment=EXPERIMENT_NAME,
        backend={"name": args.backend, "category": "aer" if args.backend == "aer" else "ibm"},
        circuit={
            "qasm": "# three teleportation circuits, see metrics['per_state']",
            "depth": int(max(qc.depth() for qc in circuits.values())),
            "gate_count": int(sum(qc.size() for qc in circuits.values())),
            "n_qubits_used": 3,
        },
        execution={"shots_per_state": args.shots, "duration_seconds": total_duration},
        raw_counts={},
        metrics={
            "per_state": per_state,
            "average_fidelity": avg_fidelity,
            "shots_per_state": args.shots,
        },
        notes=args.notes,
    )

    output = args.out or default_output_path(EXPERIMENT_NAME)
    summary_record.save(output)
    print(f"avg fidelity = {avg_fidelity:.4f}", file=sys.stderr)
    print(f"wrote {output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
