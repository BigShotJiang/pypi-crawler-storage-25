"""Teleportation circuits for the three input states.

We use the textbook protocol with a Bell pair on ``(q1, q2)`` and the
sender's qubit on ``q0``. The two classical bits from Alice's Bell-basis
measurement on ``(q0, q1)`` determine which Pauli correction to apply on
``q2``; here we apply the correction *in software* during analysis,
because mid-circuit conditional gates push transpilation complexity for
no extra physics. ``run.py`` undoes the X correction by XOR'ing Bob's bit
with Alice's ``a1`` bit before scoring.
"""

from __future__ import annotations

import math

from qiskit import QuantumCircuit

#: ``{label: theta}`` for ``RY(theta) |0>``.
INPUTS: dict[str, float] = {
    "|0>": 0.0,
    "|1>": math.pi,
    "|psi>": math.pi / 4,  # cos(pi/8)|0> + sin(pi/8)|1>
}


def build_teleport_circuit(theta: float) -> QuantumCircuit:
    """Prepare ``RY(theta) |0>`` on q0 and teleport it to q2 via q1."""
    qc = QuantumCircuit(3, 3, name="teleport")
    qc.ry(theta, 0)
    qc.h(1)
    qc.cx(1, 2)
    qc.cx(0, 1)
    qc.h(0)
    qc.measure([0, 1, 2], [0, 1, 2])
    return qc


def build_circuits() -> dict[str, QuantumCircuit]:
    """Return one teleportation circuit per input state."""
    return {label: build_teleport_circuit(theta) for label, theta in INPUTS.items()}
