"""Quantum teleportation of three input states.

We teleport ``|0>``, ``|1>``, and a non-trivial superposition
``cos(pi/8)|0> + sin(pi/8)|1>`` from Alice's qubit to Bob's qubit using a
shared Bell pair and two classical bits. Reported metric is the per-state
fidelity of the post-correction outcome distribution.
"""

from __future__ import annotations
