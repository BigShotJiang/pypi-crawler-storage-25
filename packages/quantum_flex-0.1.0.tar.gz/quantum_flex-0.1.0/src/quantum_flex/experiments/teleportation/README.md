# `teleportation` — Quantum Teleportation of Three Input States

## Hypothesis

The standard teleportation protocol perfectly transfers an arbitrary
single-qubit state from Alice (``q0``) to Bob (``q2``) using a shared
Bell pair on ``(q1, q2)`` and two classical bits. Real hardware should
match the ideal output to within the device's two-qubit error rate.

## Method

  - **Backend**: Aer simulator by default; ``--backend ibm_fez`` for
    real hardware.
  - **Qubits**: 3.
  - **Shots**: 4096 per input state × 3 states = 12 288 total.
  - **Inputs**: ``RY(0)|0> = |0>``, ``RY(π)|0> = |1>``, and
    ``RY(π/4)|0> = cos(π/8)|0> + sin(π/8)|1>``.
  - **Correction**: applied in software (XOR with Alice's ``a1`` bit)
    rather than mid-circuit, because conditional gates inflate
    transpilation depth without changing the physics.

## Observed result

  - Per-state fidelities reported as ``1 − |P(Bob = 1) − P_expected|``.
  - Average fidelity across the three states printed at end of run.
  - Aer: all three states ≥ 0.99. Real hardware: typically 0.85–0.95.

## Interpretation

A failed run (any state ≪ 0.85 on hardware) usually points to one of
two things: an unfortunate qubit mapping with a noisy two-qubit gate on
the chosen ``(q0, q1)`` link, or a calibration drift since the last
characterization. Re-transpile with ``optimization_level=3`` and check
the routing.

---

## Reproduce

```bash
# Aer
python -m quantum_flex.experiments.teleportation.run --backend aer

# IBM real hardware (requires QISKIT_IBM_TOKEN)
python -m quantum_flex.experiments.teleportation.run --backend ibm_fez --shots 4096

# Render
python -m quantum_flex.experiments.teleportation.visualize \
    --record data/runs/<date>_teleportation.json \
    --out gallery/teleportation.png
```
