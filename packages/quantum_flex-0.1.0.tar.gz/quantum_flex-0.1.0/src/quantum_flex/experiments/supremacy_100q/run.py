"""Execute the wide-random-circuit experiment and write a RunRecord JSON.

Usage::

    python -m quantum_flex.experiments.supremacy_100q.run --backend aer
    python -m quantum_flex.experiments.supremacy_100q.run \\
        --backend ibm_fez --n-qubits 156 --depth 6 --shots 4096

On Aer with default ``--n-qubits 100 --depth 6``, runtime is dominated by
the matrix-product-state simulator and lands around 30-60 s on a modern
CPU; reduce ``--depth`` if you need a quick smoke test.
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

EXPERIMENT_NAME = "supremacy_100q"


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex run supremacy_100q",
        description="Wide random-circuit sampling on Aer or IBM Quantum.",
    )
    p.add_argument("--backend", default="aer")
    p.add_argument("--n-qubits", type=int, default=100)
    p.add_argument("--depth", type=int, default=6)
    p.add_argument("--shots", type=int, default=4096)
    p.add_argument("--seed", type=int, default=42, help="Circuit-generation seed.")
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--notes", default="")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    from quantum_flex.core import runner
    from quantum_flex.core.record import default_output_path

    from .circuit import build_supremacy_circuit

    qc = build_supremacy_circuit(
        n_qubits=args.n_qubits, depth=args.depth, seed=args.seed
    )

    record = runner.run(
        circuit=qc,
        backend=args.backend,
        shots=args.shots,
        experiment=EXPERIMENT_NAME,
        notes=args.notes,
        seed_simulator=args.seed,
    )

    counts = record.raw_counts
    n_unique = len(counts)
    top_outcomes = sorted(counts.items(), key=lambda kv: -kv[1])[:8]
    hilbert_dim = 2 ** args.n_qubits

    record.metrics = {
        "n_qubits": args.n_qubits,
        "depth": args.depth,
        "shots": args.shots,
        "n_unique_outcomes": n_unique,
        "concentration_top8": sum(c for _, c in top_outcomes) / max(args.shots, 1),
        "top_outcomes": [{"bitstring": b, "count": c} for b, c in top_outcomes],
        "hilbert_dim_log10": float(args.n_qubits) * math.log10(2.0),
        "hilbert_dim_repr": f"2^{args.n_qubits} ≈ {hilbert_dim:.3e}",
        "circuit_seed": args.seed,
    }

    output = args.out or default_output_path(EXPERIMENT_NAME)
    record.save(output)
    print(
        f"{n_unique} unique outcomes / {args.shots} shots "
        f"on {args.n_qubits} qubits (dim 2^{args.n_qubits})",
        file=sys.stderr,
    )
    print(f"wrote {output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
