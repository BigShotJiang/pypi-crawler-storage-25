"""Random ``RZ-SX-RZ`` + brick-wall ``CX`` circuit.

The structure mimics Google's "quantum supremacy" benchmark family:
each layer applies a Haar-random single-qubit gate on every qubit
(decomposed as ``RZ(α) SX RZ(β)``), followed by an alternating-pattern
two-qubit entangler that links every neighboring pair across two layers.

Reproducibility is enforced by seeding the random generator at function
entry; the resulting circuit is deterministic given ``(n_qubits, depth, seed)``.
"""

from __future__ import annotations

import math

from qiskit import QuantumCircuit


def build_supremacy_circuit(
    n_qubits: int = 100, depth: int = 6, seed: int = 42
) -> QuantumCircuit:
    """Return an ``n_qubits``-wide, ``depth``-layer brick-wall random circuit.

    Layers alternate between even-index and odd-index neighbor pairs so
    that consecutive ``CX`` rounds do not commute, ensuring the unitary
    explores the Hilbert space rather than collapsing into a trivial
    tensor product.
    """
    import numpy as np

    rng = np.random.default_rng(seed)
    qc = QuantumCircuit(n_qubits, name=f"supremacy_{n_qubits}q_d{depth}")
    two_pi = 2.0 * math.pi
    for layer in range(depth):
        for q in range(n_qubits):
            qc.rz(float(rng.uniform(0.0, two_pi)), q)
            qc.sx(q)
            qc.rz(float(rng.uniform(0.0, two_pi)), q)
        for q in range(layer % 2, n_qubits - 1, 2):
            qc.cx(q, q + 1)
    qc.measure_all()
    return qc
