"""Render the wide-random-circuit experiment as a top-outcomes bar chart.

The full counts dictionary on a 100-qubit experiment has thousands of
unique entries with count 1 each — plotting all of them is meaningless.
We instead show the top 8 most frequent bitstrings (truncated for
readability) and overlay the count concentration as a single number.
"""

from __future__ import annotations

import argparse
from pathlib import Path


def _truncate(bitstring: str, head: int = 12, tail: int = 6) -> str:
    if len(bitstring) <= head + tail + 3:
        return bitstring
    return f"{bitstring[:head]}…{bitstring[-tail:]}"


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex visualize supremacy_100q",
        description="Render the wide-random-circuit experiment.",
    )
    p.add_argument("--record", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    import matplotlib.pyplot as plt

    from quantum_flex.core import style
    from quantum_flex.core.record import RunRecord
    from quantum_flex.core.visualize import save_still

    record = RunRecord.load(args.record)
    metrics = record.metrics
    palette = style.palette()

    style.apply()
    fig, ax = plt.subplots(figsize=(9, 5))

    top = metrics.get("top_outcomes", [])
    labels = [_truncate(item["bitstring"]) for item in top]
    counts = [int(item["count"]) for item in top]
    ax.barh(
        list(reversed(labels)), list(reversed(counts)),
        color=palette["accent"], edgecolor=palette["fg_muted"],
    )
    ax.set_xlabel("Count")
    ax.set_title(
        f"Top outcomes  ·  {metrics.get('n_qubits', '?')}q × depth "
        f"{metrics.get('depth', '?')}  ·  "
        f"{metrics.get('n_unique_outcomes', '?')} unique / "
        f"{metrics.get('shots', '?')} shots"
    )

    fig.text(
        0.5, 0.02,
        f"Hilbert space: {metrics.get('hilbert_dim_repr', '?')}  ·  "
        f"Top-8 concentration: {float(metrics.get('concentration_top8', 0.0))*100:.2f}%",
        ha="center", color=palette["fg_muted"], fontsize=9,
    )

    fig.tight_layout(rect=(0, 0.05, 1, 1))
    save_still(fig, args.out)
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
