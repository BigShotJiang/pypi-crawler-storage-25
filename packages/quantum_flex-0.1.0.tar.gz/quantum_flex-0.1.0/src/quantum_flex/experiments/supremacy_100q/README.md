# `supremacy_100q` — Wide Random-Circuit Sampling

## Hypothesis

A 100-qubit random circuit at depth 6 produces a distribution over a
Hilbert space of size ``2^100 ≈ 1.27e30``. With only 4096 shots the
useful observables are statistical: number of unique bitstrings, count
concentration on the most probable outcomes, and (in principle)
linear-cross-entropy benchmarking against a classical reference.

## Method

  - **Backend**: Aer simulator by default (matrix-product-state mode is
    automatic on width ≥ 64). ``--backend ibm_fez`` runs on real
    hardware (and at ``--n-qubits 156`` exercises the full ``ibm_fez``
    or ``ibm_kingston`` width).
  - **Qubits**: 100 (default) — chosen as the boundary where the bitstring
    space already exceeds the number of atoms in the human body.
  - **Depth**: 6 layers of ``RZ(α) SX RZ(β)`` + brick-wall ``CX``.
  - **Shots**: 4096.
  - **Seed**: 42 (deterministic circuit; matches the legacy
    ``quantum_3demos.py`` baseline).

## Observed result

  - ``n_unique_outcomes``: ~3500–4096 on Aer (essentially all unique).
  - ``concentration_top8``: <0.5 % on Aer. On real hardware this rises
    to ~1–2 % from coherent-error correlations.
  - The figure shows the eight most frequent bitstrings.

## Interpretation

This is *not* a refutation-style experiment. It demonstrates a workload
that is polynomial-time on quantum hardware but exponential-memory on
any classical computer that does not exploit special structure (the
matrix-product-state simulator only works because the depth is short).

The observable at depth 6 stays close to the Porter-Thomas distribution;
much deeper random circuits would be needed to claim a "supremacy" gap
in the Google-2019 sense.

---

## Reproduce

```bash
# Aer (≈ 30-60 s on a modern CPU at default settings)
python -m quantum_flex.experiments.supremacy_100q.run --backend aer

# IBM real hardware (default 100q)
python -m quantum_flex.experiments.supremacy_100q.run --backend ibm_fez --shots 4096

# Full-width 156q on ibm_fez / ibm_kingston
python -m quantum_flex.experiments.supremacy_100q.run \
    --backend ibm_fez --n-qubits 156 --depth 6 --shots 4096

# Render
python -m quantum_flex.experiments.supremacy_100q.visualize \
    --record data/runs/<date>_supremacy_100q.json \
    --out gallery/supremacy_100q.png
```
