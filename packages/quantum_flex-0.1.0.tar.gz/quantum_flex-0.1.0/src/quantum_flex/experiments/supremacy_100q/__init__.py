"""Wide random-circuit "supremacy-style" sampling experiment.

The default 100-qubit, depth-6 random circuit produces a distribution
over a Hilbert space of size ``2**100 ~ 1.27e30``. With 4096 shots, the
useful observable is *not* the per-bitstring count (essentially all are
unique) but the structure of the distribution: cross-entropy benchmarking,
the number of unique outcomes, and the count concentration on the most
probable outcomes.

A 100-qubit width is chosen to be runnable on Aer with stabilizer or
matrix-product-state simulation in reasonable time, while remaining
"interestingly wide" — the bitstring space is already ten orders of
magnitude beyond the number of atoms in the human body.
"""

from __future__ import annotations
