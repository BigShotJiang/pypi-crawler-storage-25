"""Concrete quantum experiments.

Every subpackage of :mod:`quantum_flex.experiments` follows the same
four-file convention (see ``_template/``):

  * ``circuit.py``    — pure-function circuit construction
  * ``run.py``        — Aer/IBM execution; writes a ``RunRecord`` to ``data/runs/``
  * ``visualize.py``  — turns a ``RunRecord`` into PNG/MP4
  * ``README.md``     — hypothesis, method, observed result, interpretation

Mature experiments live directly under this package
(``quantum_flex.experiments.bell_chsh``, etc.).

In-flight or honestly-failed experiments live under
:mod:`quantum_flex.experiments._wip` and stay there permanently — see the
"failure museum" section of the project README and CONTRIBUTING.md.
"""

from __future__ import annotations
