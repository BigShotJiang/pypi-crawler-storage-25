"""CHSH circuits for the four (Alice, Bob) measurement settings.

We prepare ``|Phi+> = (|00> + |11>) / sqrt(2)`` once, then apply ``RY``
rotations on each qubit to select the measurement basis. With
``RY(theta)`` followed by a Z-basis measurement, the effective observable
is ``cos(theta) Z + sin(theta) X``; for ``|Phi+>`` this gives the
correlator ``E(theta_a, theta_b) = cos(theta_a - theta_b)``.

The S parameter we report is the standard form

    S = E(a, b) - E(a, b') + E(a', b) + E(a', b')

which is maximized at ``2 * sqrt(2)`` by the Tsirelson choice

    (a, a') = (0, pi/2),  (b, b') = (pi/4, 3*pi/4).

(The historical run preserved in ``data/runs/2026-04-04_bell_chsh.json``
used ``b' = -pi/4`` instead, which makes ``S`` collapse to ``0`` —
a genuine code bug we keep on the record as an example of how easy it is
to mis-pair the ``S`` sign convention with the angle choice.)

We return four named circuits rather than one giant parameterized circuit
because :class:`SamplerV2` accepts a list of unrelated circuits in a single
job, and that's the simplest reproducible packaging.
"""

from __future__ import annotations

import math

from qiskit import QuantumCircuit

#: ``{label: (alice_angle, bob_angle)}`` for the four CHSH settings.
SETTINGS: dict[str, tuple[float, float]] = {
    "a1_b1": (0.0, math.pi / 4),
    "a1_b2": (0.0, 3 * math.pi / 4),
    "a2_b1": (math.pi / 2, math.pi / 4),
    "a2_b2": (math.pi / 2, 3 * math.pi / 4),
}


def build_chsh_circuit(theta_a: float, theta_b: float) -> QuantumCircuit:
    """Bell pair followed by RY rotations on each qubit, then measurement."""
    qc = QuantumCircuit(2, 2, name="chsh")
    qc.h(0)
    qc.cx(0, 1)
    qc.ry(theta_a, 0)
    qc.ry(theta_b, 1)
    qc.measure([0, 1], [0, 1])
    return qc


def build_circuits() -> dict[str, QuantumCircuit]:
    """Return the four CHSH circuits keyed by setting label."""
    return {label: build_chsh_circuit(a, b) for label, (a, b) in SETTINGS.items()}
