"""CHSH Bell inequality test (2022 Nobel Prize in Physics).

Four measurement settings on a Bell pair give an ``S`` parameter bounded by
``|S| <= 2`` for any local-hidden-variable theory. Quantum mechanics predicts
``S = 2*sqrt(2) ~ 2.828``. Real hardware lands somewhere in between depending
on noise; the experiment is "successful" whenever ``|S| > 2`` survives by a
margin that exceeds the per-shot statistical error.
"""

from __future__ import annotations
