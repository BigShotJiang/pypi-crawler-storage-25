"""Execute the CHSH experiment and write a RunRecord JSON.

Usage::

    python -m quantum_flex.experiments.bell_chsh.run --backend aer --shots 8000
    python -m quantum_flex.experiments.bell_chsh.run --backend ibm_fez --shots 8000

The recorded ``metrics`` block contains the four correlators ``E(a,b)``, the
derived ``S`` parameter, and a per-setting ``counts`` dump so that
``visualize.py`` can re-render without re-executing the circuits.
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qiskit import QuantumCircuit

EXPERIMENT_NAME = "bell_chsh"


def _correlator(counts: dict[str, int]) -> float:
    """Compute ``E(a, b) = P(same) - P(different)`` from a counts dict."""
    same = counts.get("00", 0) + counts.get("11", 0)
    diff = counts.get("01", 0) + counts.get("10", 0)
    total = same + diff
    if total == 0:
        return 0.0
    return (same - diff) / total


def _run_one(
    circuit: QuantumCircuit, *, backend: str, shots: int, label: str
) -> tuple[dict[str, int], float]:
    from quantum_flex.core import runner

    record = runner.run(
        circuit=circuit,
        backend=backend,
        shots=shots,
        experiment=f"{EXPERIMENT_NAME}/{label}",
    )
    return record.raw_counts, float(record.execution.get("duration_seconds", 0.0))


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex run bell_chsh",
        description="CHSH Bell-inequality test on Aer or IBM Quantum.",
    )
    p.add_argument("--backend", default="aer")
    p.add_argument("--shots", type=int, default=8000)
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--notes", default="")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    from quantum_flex.core.record import RunRecord, default_output_path

    from .circuit import SETTINGS, build_circuits

    circuits = build_circuits()

    counts_per_setting: dict[str, dict[str, int]] = {}
    correlators: dict[str, float] = {}
    total_duration = 0.0
    for label, qc in circuits.items():
        counts, duration = _run_one(qc, backend=args.backend, shots=args.shots, label=label)
        counts_per_setting[label] = counts
        correlators[label] = _correlator(counts)
        total_duration += duration
        print(f"  {label}: E = {correlators[label]:+.4f}", file=sys.stderr)

    s_value = (
        correlators["a1_b1"]
        - correlators["a1_b2"]
        + correlators["a2_b1"]
        + correlators["a2_b2"]
    )
    classical_bound = 2.0
    quantum_bound = 2.0 * math.sqrt(2.0)

    summary_record = RunRecord(
        experiment=EXPERIMENT_NAME,
        backend={"name": args.backend, "category": "aer" if args.backend == "aer" else "ibm"},
        circuit={
            "qasm": "# four CHSH circuits, see metrics['settings']",
            "depth": int(max(qc.depth() for qc in circuits.values())),
            "gate_count": int(sum(qc.size() for qc in circuits.values())),
            "n_qubits_used": 2,
        },
        execution={"shots_per_setting": args.shots, "duration_seconds": total_duration},
        raw_counts={},
        metrics={
            "S": s_value,
            "classical_bound": classical_bound,
            "quantum_bound": quantum_bound,
            "violated": abs(s_value) > classical_bound,
            "correlators": correlators,
            "counts_per_setting": counts_per_setting,
            "settings": {
                k: {"theta_a": float(v[0]), "theta_b": float(v[1])}
                for k, v in SETTINGS.items()
            },
            "shots_per_setting": args.shots,
        },
        notes=args.notes,
    )

    output = args.out or default_output_path(EXPERIMENT_NAME)
    summary_record.save(output)
    print(f"S = {s_value:+.4f}  (classical {classical_bound:.2f}, Tsirelson {quantum_bound:.4f})", file=sys.stderr)
    print(f"wrote {output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
