"""Render the CHSH experiment as a four-panel figure.

Top: per-setting correlator bar chart with the Tsirelson bound overlaid.
Bottom: a single big-typography ``S = ...`` callout with the violated /
not-violated verdict colored from the house palette.
"""

from __future__ import annotations

import argparse
from pathlib import Path


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex visualize bell_chsh",
        description="Render the CHSH experiment from a committed RunRecord JSON.",
    )
    p.add_argument("--record", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_argparser().parse_args(argv)

    import matplotlib.pyplot as plt

    from quantum_flex.core import style
    from quantum_flex.core.record import RunRecord
    from quantum_flex.core.visualize import save_still

    record = RunRecord.load(args.record)
    metrics = record.metrics

    style.apply()
    palette = style.palette()

    fig, (ax_top, ax_bot) = plt.subplots(
        2, 1, figsize=(9, 6), gridspec_kw={"height_ratios": [3, 2]}
    )

    correlators = metrics["correlators"]
    labels = list(correlators.keys())
    values = [correlators[k] for k in labels]
    colors = [palette["accent"] if v >= 0 else palette["accent2"] for v in values]
    ax_top.bar(labels, values, color=colors, edgecolor=palette["fg_muted"])
    ax_top.axhline(0.0, color=palette["fg_muted"], linewidth=0.8)
    ax_top.set_ylim(-1.05, 1.05)
    ax_top.set_ylabel("Correlator E(a, b)")
    ax_top.set_title(
        f"CHSH on {record.backend.get('name', '?')}  ·  "
        f"shots/setting={metrics.get('shots_per_setting', '?')}"
    )

    s_value = float(metrics["S"])
    classical = float(metrics["classical_bound"])
    quantum = float(metrics["quantum_bound"])
    violated = bool(metrics["violated"])
    verdict_color = palette["accent"] if violated else palette["failure"]
    verdict_text = (
        f"S = {s_value:+.4f}\n"
        f"classical bound  |S| ≤ {classical:.2f}\n"
        f"Tsirelson bound  |S| ≤ {quantum:.4f}"
    )
    ax_bot.axis("off")
    ax_bot.text(
        0.5, 0.6, verdict_text, ha="center", va="center",
        fontsize=18, color=verdict_color, transform=ax_bot.transAxes,
    )
    ax_bot.text(
        0.5, 0.1,
        "BELL INEQUALITY VIOLATED" if violated else "no violation in this run",
        ha="center", va="center",
        fontsize=14, color=verdict_color, transform=ax_bot.transAxes,
    )

    fig.tight_layout()
    save_still(fig, args.out)
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
