# `bell_chsh` — CHSH Bell Inequality on Real Hardware

## Hypothesis

A Bell pair measured at the CHSH-optimal angles produces an
``S`` parameter that exceeds the local-hidden-variable bound of ``2``.
This is the experiment that won the
[2022 Nobel Prize in Physics](https://www.nobelprize.org/prizes/physics/2022/).

## Method

  - **Backend**: Aer simulator by default; ``--backend ibm_fez`` (or
    similar) for real hardware.
  - **Qubits**: 2 (``q0`` Alice, ``q1`` Bob).
  - **Shots**: 8000 per setting × 4 settings = 32 000 total.
  - **Circuit**: ``H(0) → CX(0,1) → RY(θa, 0) → RY(θb, 1) → measure``.
  - **Settings**: ``(θa, θb) ∈ {0, π/2} × {π/4, -π/4}`` — the angles that
    maximize ``|S|`` for the ideal ``|Φ+⟩`` state.

## Observed result

  - ``|S|`` printed at the end of the run.
  - The figure produced by ``visualize.py`` shows the four correlators
    and the violation verdict.
  - On Aer with default noise: ``S ≈ 2.828``. On real hardware: typically
    ``2.6 < S < 2.8`` depending on the device.

## Interpretation

A run with ``|S| > 2`` cannot be explained by any local-hidden-variable
theory. The bigger the margin, the lower the noise contribution.

If a real-hardware run *does not* exceed ``2``, treat it as a calibration
diagnostic — check the device's two-qubit gate error in the latest
calibration JSON.

---

## Reproduce

```bash
# Aer
python -m quantum_flex.experiments.bell_chsh.run --backend aer --shots 8000

# IBM real hardware (requires QISKIT_IBM_TOKEN)
python -m quantum_flex.experiments.bell_chsh.run --backend ibm_fez --shots 8000

# Render
python -m quantum_flex.experiments.bell_chsh.visualize \
    --record data/runs/<date>_bell_chsh.json \
    --out gallery/bell_chsh.png
```
