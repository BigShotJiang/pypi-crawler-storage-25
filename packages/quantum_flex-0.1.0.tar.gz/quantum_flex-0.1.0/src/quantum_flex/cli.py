"""``quantum-flex`` command-line entry point.

Subcommands
-----------

``quantum-flex new <name>``
    Scaffold a new experiment under
    ``src/quantum_flex/experiments/_wip/<name>/`` from the
    ``experiments/_template/`` skeleton.

``quantum-flex promote <name>``
    Move an experiment from ``experiments/_wip/<name>/`` to
    ``experiments/<name>/`` once it is mature. The git history of any
    earlier raw runs stays — we never ``git rm`` a failure.

``quantum-flex version``
    Print the installed quantum-flex version.

The subcommands operate on the *source tree of a checkout* of
quantum-flex, not on installed-package state. Run them from inside the
repository root.
"""

from __future__ import annotations

import argparse
import shutil
import sys
from importlib import resources
from pathlib import Path

from . import __version__

# Identifiers that ``new`` will reject so we never collide with reserved
# template names or with the failure-museum convention.
_RESERVED_NAMES = frozenset({"_template", "_wip", "__init__", "core", "art", "cli"})


def _slug_is_valid(slug: str) -> bool:
    """A valid experiment slug is snake_case, ASCII, and not reserved."""
    if not slug or slug in _RESERVED_NAMES:
        return False
    if not slug[0].isalpha():
        return False
    return all(ch == "_" or ch.isalnum() for ch in slug) and slug.islower()


def _experiments_root(repo_root: Path) -> Path:
    return repo_root / "src" / "quantum_flex" / "experiments"


def _detect_repo_root(start: Path | None = None) -> Path:
    """Walk up from ``start`` (or cwd) to find the quantum-flex repo root.

    The repo root is identified by having both ``pyproject.toml`` and
    ``src/quantum_flex/`` underneath it. We do not rely on ``.git`` so that
    the CLI also works inside a worktree or a tarball checkout.
    """
    here = (start or Path.cwd()).resolve()
    for candidate in [here, *here.parents]:
        if (candidate / "pyproject.toml").is_file() and (
            candidate / "src" / "quantum_flex"
        ).is_dir():
            return candidate
    raise SystemExit(
        "quantum-flex CLI must be run from inside a checkout of the "
        "quantum-flex repository (no pyproject.toml + src/quantum_flex "
        "found by walking upward from the current directory)."
    )


def _copy_template(template_root: Path, target: Path, slug: str) -> None:
    """Copy ``_template/`` to ``target`` and rewrite the ``<EXPERIMENT_NAME>`` placeholder."""
    if target.exists():
        raise SystemExit(f"refusing to overwrite existing directory: {target}")

    shutil.copytree(template_root, target)

    for path in target.rglob("*"):
        if path.is_file() and path.suffix in {".py", ".md"}:
            text = path.read_text(encoding="utf-8")
            if "<EXPERIMENT_NAME>" in text:
                path.write_text(text.replace("<EXPERIMENT_NAME>", slug), encoding="utf-8")


def cmd_new(args: argparse.Namespace) -> int:
    slug = args.name
    if not _slug_is_valid(slug):
        raise SystemExit(
            f"invalid experiment name: {slug!r}. "
            "Use snake_case ASCII (e.g. 'my_quantum_test'). "
            f"Reserved names: {sorted(_RESERVED_NAMES)}"
        )

    repo = _detect_repo_root()
    template = _experiments_root(repo) / "_template"
    target = _experiments_root(repo) / "_wip" / slug

    if not template.is_dir():
        raise SystemExit(f"template directory missing: {template}")

    _copy_template(template, target, slug)

    print(f"created experiment scaffold: {target.relative_to(repo)}")
    print()
    print("next steps:")
    print(f"  edit   {target.relative_to(repo)}/circuit.py")
    print(f"  run    python -m quantum_flex.experiments._wip.{slug}.run --backend aer")
    print(f"  render python -m quantum_flex.experiments._wip.{slug}.visualize "
          f"--record data/runs/<file>.json --out gallery/{slug}.png")
    return 0


def cmd_promote(args: argparse.Namespace) -> int:
    slug = args.name
    if not _slug_is_valid(slug):
        raise SystemExit(f"invalid experiment name: {slug!r}.")

    repo = _detect_repo_root()
    src = _experiments_root(repo) / "_wip" / slug
    dst = _experiments_root(repo) / slug

    if not src.is_dir():
        raise SystemExit(f"no _wip experiment found at {src}")
    if dst.exists():
        raise SystemExit(f"refusing to overwrite existing experiment at {dst}")

    src.rename(dst)
    print(f"promoted: {src.relative_to(repo)} → {dst.relative_to(repo)}")
    print(
        "Reminder: prior raw runs in data/runs/ stay where they are. "
        "We never rewrite history just because an experiment matured."
    )
    return 0


def cmd_version(_args: argparse.Namespace) -> int:
    print(__version__)
    return 0


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantum-flex",
        description="Scaffold, promote, and inspect quantum-flex experiments.",
    )
    sub = p.add_subparsers(dest="command", required=True)

    p_new = sub.add_parser("new", help="Scaffold a new experiment under _wip/.")
    p_new.add_argument("name", help="Experiment slug (snake_case).")
    p_new.set_defaults(func=cmd_new)

    p_promote = sub.add_parser(
        "promote", help="Promote a _wip/ experiment to experiments/."
    )
    p_promote.add_argument("name", help="Experiment slug to promote.")
    p_promote.set_defaults(func=cmd_promote)

    p_version = sub.add_parser("version", help="Print the installed quantum-flex version.")
    p_version.set_defaults(func=cmd_version)

    # Marker import so static checkers do not flag ``resources`` as unused —
    # it is reserved for a future ``packaged-template`` mode that copies the
    # template out of the installed wheel rather than the source checkout.
    _ = resources

    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
