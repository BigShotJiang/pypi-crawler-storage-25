"""Shared matplotlib theme for every figure in the gallery.

All ``art/*.py`` modules call :func:`apply` exactly once before drawing, and
look up colors from :data:`PALETTE` rather than hard-coding them. That gives
the gallery a recognizable visual identity (deep-space background, neon
accent line, restrained type) without requiring per-figure tweaking.

If you want to publish a figure that *deviates* from the house style — for
example, a black-on-white version for a printed paper — call
``apply(theme="paper")`` instead, or build your own ``rcParams`` overlay.
"""

from __future__ import annotations

from typing import Final

#: House palette. Hex strings, intentionally not converted to tuples so that
#: matplotlib accepts them in any color-position argument.
PALETTE: Final[dict[str, str]] = {
    # Deep-space backgrounds, layered from darkest to lightest.
    "bg":         "#050510",
    "bg_panel":   "#0a0a1a",
    "bg_grid":    "#15152a",
    # Foreground typography.
    "fg":         "#e0e0f0",
    "fg_muted":   "#9090a8",
    # Accents, in order of preference for "the one important line".
    "accent":     "#7af0ff",  # cyan / interference-pattern color
    "accent2":    "#ff66e0",  # magenta / quantum-cat counterpoint
    "accent3":    "#ffd166",  # warm amber / for the rare "this is the answer" highlight
    # Failure-museum red — used for `_wip/` failure traces only.
    "failure":    "#ff5070",
    # Classical-comparison color — used for "old algorithm beat us" overlays.
    "classical":  "#80c080",
}

# Paper-style overrides: black ink on white, no neon, suitable for print.
_PAPER_PALETTE: Final[dict[str, str]] = {
    "bg":         "#ffffff",
    "bg_panel":   "#fafafa",
    "bg_grid":    "#e0e0e0",
    "fg":         "#101015",
    "fg_muted":   "#606070",
    "accent":     "#103080",
    "accent2":    "#a01060",
    "accent3":    "#806010",
    "failure":    "#a01030",
    "classical":  "#306030",
}


def palette(theme: str = "deep_space") -> dict[str, str]:
    """Return the palette for the requested theme.

    Themes
    ------
    ``"deep_space"`` (default)
        Dark neon palette used throughout the gallery.
    ``"paper"``
        High-contrast monochrome with restrained accents, suitable for
        print or for embedding in academic papers.
    """
    if theme == "deep_space":
        return dict(PALETTE)
    if theme == "paper":
        return dict(_PAPER_PALETTE)
    raise ValueError(f"unknown style theme: {theme!r}")


def apply(theme: str = "deep_space") -> None:
    """Apply the requested theme as the current matplotlib ``rcParams``.

    Idempotent: calling it twice with the same theme is a no-op for the
    second call. Calling it with a different theme overrides the previous
    settings entirely.

    The function imports matplotlib lazily so that ``import quantum_flex``
    on a fresh interpreter does not pay matplotlib's startup cost.
    """
    import matplotlib.pyplot as plt  # local import: see docstring

    p = palette(theme)
    plt.rcParams.update(
        {
            "figure.facecolor": p["bg"],
            "axes.facecolor": p["bg_panel"],
            "savefig.facecolor": p["bg"],
            "savefig.edgecolor": p["bg"],
            "axes.edgecolor": p["fg_muted"],
            "axes.labelcolor": p["fg"],
            "axes.titlecolor": p["fg"],
            "xtick.color": p["fg_muted"],
            "ytick.color": p["fg_muted"],
            "text.color": p["fg"],
            "grid.color": p["bg_grid"],
            "grid.alpha": 0.6,
            "axes.grid": True,
            "axes.grid.axis": "y",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.titlesize": 12,
            "axes.titleweight": "regular",
            "figure.titlesize": 14,
            "figure.titleweight": "regular",
            "axes.prop_cycle": plt.cycler(
                color=[p["accent"], p["accent2"], p["accent3"], p["classical"], p["failure"]]
            ),
        }
    )
