"""Uniform Aer / IBM Quantum execution wrapper.

The single entry point :func:`run` accepts a :class:`qiskit.QuantumCircuit`,
a backend specification, and a shot count, and returns a fully-populated
:class:`quantum_flex.core.record.RunRecord`.

Why funnel everything through one function?

  * Every experiment ends up writing the same boilerplate (build, transpile,
    submit, collect counts, package versions) — moving that into one place
    keeps experiment files small and uniform.
  * Provenance fields (qiskit version, backend metadata, timestamps) are
    captured automatically. Authors of new experiments cannot forget them.
  * The Aer-vs-IBM branch is the *only* place in the library that decides
    whether real-hardware time will be spent. That makes audit easy.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from .record import RunRecord

if TYPE_CHECKING:
    from qiskit import QuantumCircuit


def run(
    *,
    circuit: QuantumCircuit,
    backend: str,
    shots: int,
    experiment: str,
    notes: str = "",
    optimization_level: int = 1,
    seed_simulator: int | None = 42,
) -> RunRecord:
    """Execute ``circuit`` on ``backend`` and return a populated RunRecord.

    Parameters
    ----------
    circuit
        The quantum circuit to execute. Must contain measurement
        instructions; otherwise the resulting ``raw_counts`` will be empty.
    backend
        ``"aer"`` for the local Aer simulator, or any IBM Quantum backend
        name (``"ibm_fez"``, ``"ibm_kingston"``, etc.). IBM execution
        requires the ``[ibm]`` extra and ``QISKIT_IBM_TOKEN`` to be set.
    shots
        Number of measurement shots. Aer accepts essentially anything;
        IBM real hardware is rate-limited and shots over a few thousand
        typically need a paid plan.
    experiment
        A short slug for this experiment (used as the ``experiment`` field
        in the resulting :class:`RunRecord`).
    notes
        Optional free-text annotation, attached to the RunRecord.
    optimization_level
        Transpilation optimization level (0–3) passed through to qiskit.
        Default ``1`` is a sensible balance between fidelity and runtime.
    seed_simulator
        Reproducibility seed for Aer. Ignored on real hardware.
    """
    if backend == "aer":
        return _run_aer(
            circuit=circuit,
            shots=shots,
            experiment=experiment,
            notes=notes,
            optimization_level=optimization_level,
            seed_simulator=seed_simulator,
        )
    return _run_ibm(
        circuit=circuit,
        backend_name=backend,
        shots=shots,
        experiment=experiment,
        notes=notes,
        optimization_level=optimization_level,
    )


# ---------------------------------------------------------------------------
# Aer
# ---------------------------------------------------------------------------


def _run_aer(
    *,
    circuit: QuantumCircuit,
    shots: int,
    experiment: str,
    notes: str,
    optimization_level: int,
    seed_simulator: int | None,
) -> RunRecord:
    from qiskit import transpile
    from qiskit_aer import AerSimulator

    sim = AerSimulator()
    transpiled = transpile(circuit, sim, optimization_level=optimization_level)

    started = time.perf_counter()
    job = sim.run(transpiled, shots=shots, seed_simulator=seed_simulator)
    result = job.result()
    elapsed = time.perf_counter() - started

    counts = _coerce_counts(result.get_counts(transpiled))

    return RunRecord.from_aer_job(
        experiment=experiment,
        circuit_qasm=_qasm_of(circuit),
        circuit_depth=int(transpiled.depth()),
        circuit_gate_count=int(sum(transpiled.count_ops().values())),
        n_qubits_used=int(circuit.num_qubits),
        shots=shots,
        raw_counts=counts,
        notes=notes,
        duration_seconds=elapsed,
    )


# ---------------------------------------------------------------------------
# IBM real hardware
# ---------------------------------------------------------------------------


def _run_ibm(
    *,
    circuit: QuantumCircuit,
    backend_name: str,
    shots: int,
    experiment: str,
    notes: str,
    optimization_level: int,
) -> RunRecord:
    from qiskit import transpile

    from . import ibm

    backend = ibm.get_backend(backend_name)

    transpiled = transpile(circuit, backend, optimization_level=optimization_level)

    # We use the legacy "submit a job and wait" pattern rather than Sessions
    # because it is the simplest reproducible path for one-off runs. Power
    # users who want batched / session-based execution can call qiskit-ibm-
    # runtime directly and then construct a RunRecord with
    # `RunRecord.from_ibm_job(...)`.
    started = time.perf_counter()
    sampler = _sampler_for(backend)
    job = sampler.run([transpiled], shots=shots)
    result = job.result()
    elapsed = time.perf_counter() - started

    counts = _coerce_counts(_extract_counts_from_sampler_result(result))
    job_id = getattr(job, "job_id", lambda: None)()
    backend_qubits = int(getattr(backend, "num_qubits", 0))
    backend_version = str(getattr(backend, "version", "unknown"))

    return RunRecord.from_ibm_job(
        experiment=experiment,
        backend_name=backend_name,
        backend_qubits=backend_qubits,
        backend_version=backend_version,
        circuit_qasm=_qasm_of(circuit),
        circuit_depth=int(transpiled.depth()),
        circuit_gate_count=int(sum(transpiled.count_ops().values())),
        n_qubits_used=int(circuit.num_qubits),
        shots=shots,
        session_id=None,  # populated when SessionRunner lands in v0.2
        job_id=job_id,
        raw_counts=counts,
        notes=notes,
        duration_seconds=elapsed,
    )


def _sampler_for(backend: Any) -> Any:
    """Return a ``SamplerV2`` instance bound to ``backend``."""
    from qiskit_ibm_runtime import SamplerV2

    return SamplerV2(mode=backend)


def _extract_counts_from_sampler_result(result: Any) -> dict[str, int]:
    """Pull a ``{bitstring: count}`` mapping out of a SamplerV2 result.

    SamplerV2 returns one ``PrimitiveResult`` per circuit; counts live under
    the ``c`` (default classical register) data field. We tolerate either
    dict or histogram-shaped data because the API has shifted between
    qiskit-ibm-runtime versions.
    """
    pub_result = result[0]
    data = pub_result.data
    # Common case: data is a dict-like with one classical-register key.
    for register_name in ("c", "meas", "measure"):
        if hasattr(data, register_name):
            container = getattr(data, register_name)
            if hasattr(container, "get_counts"):
                return _coerce_counts(container.get_counts())
    # Fallback: walk attributes looking for something that quacks like a
    # counts dict.
    for attr in dir(data):
        if attr.startswith("_"):
            continue
        candidate = getattr(data, attr)
        if hasattr(candidate, "get_counts"):
            return _coerce_counts(candidate.get_counts())
    raise RuntimeError(
        "Could not locate a measurement-counts container in the SamplerV2 "
        "result. This is usually a version mismatch between qiskit and "
        "qiskit-ibm-runtime; please open an issue."
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _coerce_counts(raw: Any) -> dict[str, int]:
    """Normalize qiskit's various counts representations into ``dict[str, int]``."""
    if hasattr(raw, "items"):
        return {str(k): int(v) for k, v in raw.items()}
    raise TypeError(f"unexpected counts container: {type(raw).__name__}")


def _qasm_of(circuit: QuantumCircuit) -> str:
    """Render ``circuit`` as OpenQASM 3 source.

    qiskit 2.x deprecated ``QuantumCircuit.qasm`` in favor of the
    ``qasm3.dumps`` function; we go through the new API but fall back
    gracefully if a future version moves it again.
    """
    try:
        from qiskit import qasm3

        return qasm3.dumps(circuit)
    except Exception:  # noqa: BLE001 — defensive; QASM serialization is non-critical
        return f"# QASM serialization failed for circuit named {circuit.name!r}"
