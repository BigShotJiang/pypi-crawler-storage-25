"""Common helpers for writing PNG / GIF / MP4 outputs.

The ``art/*.py`` modules build sequences of matplotlib frames; this module
turns those sequences into files on disk in a way that is consistent across
the gallery.

Format selection follows the file extension of ``output``:

  * ``.png`` / ``.svg`` / ``.pdf`` — single-figure save via matplotlib.
  * ``.gif``                       — multi-frame GIF (Pillow).
  * ``.mp4`` / ``.webm``           — multi-frame video (imageio + ffmpeg).

Any other extension raises :class:`ValueError`.

Why a separate module instead of letting each art piece do its own I/O?
Because mp4 vs. gif vs. png each carries a different optional-dependency
chain, and centralizing that chain here means we can give one good error
message instead of six different obscure ones.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Sequence

if TYPE_CHECKING:
    from matplotlib.figure import Figure


_STILL_EXTENSIONS = frozenset({".png", ".svg", ".pdf"})
_GIF_EXTENSION = ".gif"
_VIDEO_EXTENSIONS = frozenset({".mp4", ".webm"})


class ArtExtraMissing(RuntimeError):
    """Raised when an animation format is requested but the ``[art]`` extra is missing."""


def save_still(figure: Figure, output: str | Path, *, dpi: int = 180) -> Path:
    """Persist a single matplotlib figure as PNG / SVG / PDF."""
    out = Path(output)
    if out.suffix.lower() not in _STILL_EXTENSIONS:
        raise ValueError(
            f"save_still expected one of {sorted(_STILL_EXTENSIONS)}, "
            f"got {out.suffix!r}"
        )
    out.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(out, dpi=dpi)
    return out


def save_animation(
    frames: Sequence[Any],
    output: str | Path,
    *,
    fps: float = 24.0,
    loop: int = 0,
) -> Path:
    """Persist a sequence of frames as GIF or MP4 / WebM.

    ``frames`` can be either:

      * A sequence of ``numpy.ndarray`` (H × W × 3 or H × W × 4, dtype uint8),
        or
      * A sequence of ``PIL.Image.Image`` instances.

    Both Pillow and imageio handle either form; we normalize internally.

    Parameters
    ----------
    fps
        Frames per second for video output. For GIF, the per-frame delay
        is computed as ``1000 / fps`` milliseconds.
    loop
        GIF loop count (``0`` means infinite). Ignored for video output.
    """
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    suffix = out.suffix.lower()

    if not frames:
        raise ValueError("save_animation requires at least one frame.")

    if suffix == _GIF_EXTENSION:
        return _save_gif(frames, out, fps=fps, loop=loop)
    if suffix in _VIDEO_EXTENSIONS:
        return _save_video(frames, out, fps=fps)
    raise ValueError(
        f"save_animation expected .gif / .mp4 / .webm, got {suffix!r}. "
        f"Use save_still() for {_STILL_EXTENSIONS}."
    )


# ---------------------------------------------------------------------------
# GIF
# ---------------------------------------------------------------------------


def _save_gif(
    frames: Sequence[Any], output: Path, *, fps: float, loop: int
) -> Path:
    try:
        from PIL import Image
    except ImportError as exc:  # pragma: no cover — exercised in install test
        raise ArtExtraMissing(
            "Saving GIFs requires Pillow. Install with: "
            "pip install 'quantum-flex[art]'"
        ) from exc

    pil_frames = [_as_pil(f, Image) for f in frames]
    duration_ms = max(1, int(round(1000.0 / max(fps, 1e-6))))

    pil_frames[0].save(
        output,
        save_all=True,
        append_images=pil_frames[1:],
        duration=duration_ms,
        loop=loop,
        optimize=True,
        disposal=2,
    )
    return output


# ---------------------------------------------------------------------------
# MP4 / WebM
# ---------------------------------------------------------------------------


def _save_video(frames: Sequence[Any], output: Path, *, fps: float) -> Path:
    try:
        import imageio.v3 as iio
    except ImportError as exc:  # pragma: no cover
        raise ArtExtraMissing(
            "Saving MP4/WebM requires imageio + imageio-ffmpeg. "
            "Install with: pip install 'quantum-flex[art]'"
        ) from exc

    arrays = [_as_uint8_array(f) for f in frames]
    iio.imwrite(output, arrays, fps=fps)
    return output


# ---------------------------------------------------------------------------
# Frame normalization
# ---------------------------------------------------------------------------


def _as_pil(frame: Any, image_module: Any) -> Any:
    """Convert a frame into a ``PIL.Image.Image``."""
    if hasattr(frame, "save"):  # already a PIL image
        return frame
    arr = _as_uint8_array(frame)
    return image_module.fromarray(arr)


def _as_uint8_array(frame: Any) -> Any:
    """Convert a frame into an ``H × W × {3,4}`` uint8 numpy array."""
    import numpy as np

    if hasattr(frame, "save") and hasattr(frame, "convert"):
        # PIL image → numpy
        return np.asarray(frame.convert("RGBA" if frame.mode == "RGBA" else "RGB"), dtype=np.uint8)

    arr = np.asarray(frame)
    if arr.dtype != np.uint8:
        # matplotlib usually hands us float [0, 1] arrays from the agg buffer;
        # rescale to uint8 if so.
        if arr.dtype.kind == "f":
            arr = (np.clip(arr, 0.0, 1.0) * 255.0).round().astype(np.uint8)
        else:
            arr = arr.astype(np.uint8)
    return arr
