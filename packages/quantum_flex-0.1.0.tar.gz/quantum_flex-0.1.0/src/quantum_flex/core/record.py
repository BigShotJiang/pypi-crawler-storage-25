"""``RunRecord`` — the JSON schema that every experiment in quantum-flex emits.

A ``RunRecord`` captures **everything needed to reproduce or re-render a
quantum run** without re-executing the circuit: the qiskit / qflex versions
in use, the backend, the shot count, the full OpenQASM source, the raw
measurement counts, and any experiment-specific metrics.

JSON files committed under ``data/runs/`` are serialized ``RunRecord``
instances. The schema is forward-compatible: ``schema_version`` is bumped
on breaking changes, and old loader paths are kept indefinitely.

Security
--------

``RunRecord`` is **deliberately defensive about credentials**:

  * The IBM Quantum API token is *never* written into the record. Only the
    public job/session identifiers are kept (those carry no credentials and
    are needed for IBM-side audit trails).
  * The user's IBM account email / hub / group / project are not captured.
  * ``RunRecord.save`` re-validates the record before writing and will refuse
    to serialize anything that looks like a token (a 60+ character alnum/
    underscore/hyphen string) anywhere in the record.

These guarantees are enforced by :func:`_validate_no_secrets` and exercised
in the test suite.
"""

from __future__ import annotations

import datetime as _dt
import json
import os
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

# Bumped only on breaking schema changes. New optional fields do NOT bump it.
SCHEMA_VERSION = "1.0"

# Heuristic for "this looks like an IBM Quantum token". Real tokens are
# 64+ chars of alphanumerics/underscore/hyphen. We reject anything matching
# that shape from being serialized into a RunRecord — defense in depth in
# case a future code path accidentally captures one in `notes` or `metrics`.
_TOKEN_LIKE_RE = re.compile(r"[A-Za-z0-9_\-]{60,}")

# Where data/runs/ lives in this repository, *relative to the package root*.
# Used by `default_output_path` when callers do not supply an explicit path.
_DATA_RUNS_RELATIVE = Path("data") / "runs"


@dataclass
class RunRecord:
    """A single (experiment, backend, shots) execution snapshot.

    Construct from one of:

      * :func:`from_aer_job` — for Aer simulator results.
      * :func:`from_ibm_job` — for IBM Runtime real-hardware results.
      * :func:`load`         — for re-reading a committed JSON file.

    All fields are JSON-serializable. ``backend`` / ``execution`` / ``circuit``
    / ``raw_counts`` / ``metrics`` are plain ``dict`` objects (not dataclasses)
    so that experiment authors can attach arbitrary, schema-free metric data
    without having to subclass anything.
    """

    experiment: str
    backend: dict[str, Any]
    execution: dict[str, Any]
    circuit: dict[str, Any]
    raw_counts: dict[str, int]
    metrics: dict[str, Any] = field(default_factory=dict)
    notes: str = ""

    qflex_version: str = ""
    qiskit_version: str = ""
    qiskit_aer_version: str = ""
    schema_version: str = SCHEMA_VERSION

    # ---- Construction helpers ------------------------------------------------

    @classmethod
    def from_aer_job(
        cls,
        *,
        experiment: str,
        circuit_qasm: str,
        circuit_depth: int,
        circuit_gate_count: int,
        n_qubits_used: int,
        shots: int,
        raw_counts: dict[str, int],
        metrics: dict[str, Any] | None = None,
        notes: str = "",
        duration_seconds: float | None = None,
    ) -> RunRecord:
        """Build a record from an Aer simulator run."""
        return cls(
            experiment=experiment,
            backend={
                "name": "aer_simulator",
                "type": "simulator",
                "qubits": n_qubits_used,
                "version": _qiskit_aer_version(),
            },
            execution={
                "shots": shots,
                "session_id": None,
                "job_id": None,
                "timestamp_jst": _now_jst_isoformat(),
                "duration_seconds": duration_seconds,
            },
            circuit={
                "qasm": circuit_qasm,
                "depth": circuit_depth,
                "gate_count": circuit_gate_count,
                "n_qubits_used": n_qubits_used,
            },
            raw_counts=dict(raw_counts),
            metrics=dict(metrics or {}),
            notes=notes,
            qflex_version=_qflex_version(),
            qiskit_version=_qiskit_version(),
            qiskit_aer_version=_qiskit_aer_version(),
        )

    @classmethod
    def from_ibm_job(
        cls,
        *,
        experiment: str,
        backend_name: str,
        backend_qubits: int,
        backend_version: str,
        circuit_qasm: str,
        circuit_depth: int,
        circuit_gate_count: int,
        n_qubits_used: int,
        shots: int,
        session_id: str | None,
        job_id: str | None,
        raw_counts: dict[str, int],
        metrics: dict[str, Any] | None = None,
        notes: str = "",
        duration_seconds: float | None = None,
    ) -> RunRecord:
        """Build a record from an IBM Runtime real-hardware run."""
        return cls(
            experiment=experiment,
            backend={
                "name": backend_name,
                "type": "real_hardware",
                "qubits": backend_qubits,
                "version": backend_version,
            },
            execution={
                "shots": shots,
                "session_id": session_id,
                "job_id": job_id,
                "timestamp_jst": _now_jst_isoformat(),
                "duration_seconds": duration_seconds,
            },
            circuit={
                "qasm": circuit_qasm,
                "depth": circuit_depth,
                "gate_count": circuit_gate_count,
                "n_qubits_used": n_qubits_used,
            },
            raw_counts=dict(raw_counts),
            metrics=dict(metrics or {}),
            notes=notes,
            qflex_version=_qflex_version(),
            qiskit_version=_qiskit_version(),
            qiskit_aer_version=_qiskit_aer_version(),
        )

    # ---- Serialization -------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Plain-dict form, ready for ``json.dumps``."""
        return asdict(self)

    def save(self, path: str | Path) -> Path:
        """Validate and write this record as pretty-printed JSON.

        Raises :class:`ValueError` if any field looks like it might contain
        a credential (see module docstring on the security guarantees).
        """
        _validate_no_secrets(self.to_dict())
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(
            json.dumps(self.to_dict(), indent=2, ensure_ascii=False, sort_keys=False) + "\n",
            encoding="utf-8",
        )
        return out

    @classmethod
    def load(cls, path: str | Path) -> RunRecord:
        """Read a JSON record from disk and validate its schema version."""
        text = Path(path).read_text(encoding="utf-8")
        data = json.loads(text)
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RunRecord:
        """Build a record from a parsed JSON ``dict``.

        Older ``schema_version``s are accepted; we may transform them in-place
        as the schema evolves. For now (1.0 → 1.0) it is identity.
        """
        version = str(data.get("schema_version", SCHEMA_VERSION))
        if version != SCHEMA_VERSION:
            data = _migrate(data, from_version=version, to_version=SCHEMA_VERSION)

        return cls(
            experiment=str(data["experiment"]),
            backend=dict(data.get("backend", {})),
            execution=dict(data.get("execution", {})),
            circuit=dict(data.get("circuit", {})),
            raw_counts={str(k): int(v) for k, v in data.get("raw_counts", {}).items()},
            metrics=dict(data.get("metrics", {})),
            notes=str(data.get("notes", "")),
            qflex_version=str(data.get("qflex_version", "")),
            qiskit_version=str(data.get("qiskit_version", "")),
            qiskit_aer_version=str(data.get("qiskit_aer_version", "")),
            schema_version=SCHEMA_VERSION,
        )

    # ---- Convenience ---------------------------------------------------------

    @property
    def shots(self) -> int:
        return int(self.execution.get("shots", 0))

    @property
    def total_counts(self) -> int:
        return sum(self.raw_counts.values())


# ---- Module-level helpers ----------------------------------------------------


def default_output_path(experiment: str, when: _dt.date | None = None) -> Path:
    """Return ``data/runs/<YYYY-MM-DD>_<experiment>.json``.

    Used by :func:`run` callers that do not supply an explicit ``--out`` flag.
    The path is *relative to the current working directory* — i.e. you should
    invoke experiments from the repository root.
    """
    when = when or _dt.date.today()
    return _DATA_RUNS_RELATIVE / f"{when.isoformat()}_{experiment}.json"


def _validate_no_secrets(payload: Any) -> None:
    """Refuse to serialize anything that looks like a credential.

    The check walks the payload depth-first, examining every string value and
    every dict key, and matches against ``_TOKEN_LIKE_RE``. Field names are
    not enough — we want defense in depth in case a future code path stuffs
    a token into ``metrics`` or ``notes``.
    """
    if isinstance(payload, dict):
        for k, v in payload.items():
            if isinstance(k, str) and k.lower() in {"token", "api_key", "secret", "password"}:
                raise ValueError(f"refusing to serialize forbidden key: {k!r}")
            _validate_no_secrets(v)
    elif isinstance(payload, list | tuple):
        for item in payload:
            _validate_no_secrets(item)
    elif isinstance(payload, str):
        if _TOKEN_LIKE_RE.search(payload):
            # Whitelist OpenQASM source: it can be very long but is not a
            # credential and is required in `circuit.qasm`. We detect it by
            # the OPENQASM keyword.
            if "OPENQASM" in payload:
                return
            # Whitelist measurement bitstrings: 60+ qubit experiments
            # legitimately produce 60- to 156-character "0"/"1" strings as
            # dict keys in `raw_counts` and `metrics.top_outcomes`. They
            # carry no credential entropy.
            if payload and all(ch in "01" for ch in payload):
                return
            raise ValueError(
                "refusing to serialize a token-like string (60+ alnum/_/- chars). "
                "If this is legitimate (e.g. a long base-64 measurement encoding), "
                "split it into structured fields instead."
            )


def _migrate(data: dict[str, Any], *, from_version: str, to_version: str) -> dict[str, Any]:
    """Schema upgrade path. Today it is a no-op; this is the seam for v1.1+."""
    # When 1.1 ships, add an `if from_version == "1.0":` block here that
    # applies whatever rewrite is needed and returns the upgraded dict.
    raise ValueError(
        f"unknown RunRecord schema_version {from_version!r}; "
        f"this build understands {to_version!r}. "
        "Please upgrade quantum-flex to read this record."
    )


# ---- Version detection (deferred so import is cheap) -------------------------

_QFLEX_VERSION: str | None = None
_QISKIT_VERSION: str | None = None
_QISKIT_AER_VERSION: str | None = None


def _qflex_version() -> str:
    global _QFLEX_VERSION
    if _QFLEX_VERSION is None:
        from quantum_flex import __version__ as v

        _QFLEX_VERSION = v
    return _QFLEX_VERSION


def _qiskit_version() -> str:
    global _QISKIT_VERSION
    if _QISKIT_VERSION is None:
        try:
            import qiskit

            _QISKIT_VERSION = str(getattr(qiskit, "__version__", "unknown"))
        except ImportError:
            _QISKIT_VERSION = "not-installed"
    return _QISKIT_VERSION


def _qiskit_aer_version() -> str:
    global _QISKIT_AER_VERSION
    if _QISKIT_AER_VERSION is None:
        try:
            import qiskit_aer

            _QISKIT_AER_VERSION = str(getattr(qiskit_aer, "__version__", "unknown"))
        except ImportError:
            _QISKIT_AER_VERSION = "not-installed"
    return _QISKIT_AER_VERSION


def _now_jst_isoformat() -> str:
    """Current time in JST (UTC+9), ISO-8601, second precision."""
    jst = _dt.timezone(_dt.timedelta(hours=9))
    return _dt.datetime.now(tz=jst).replace(microsecond=0).isoformat()


# ---- CLI: ``python -m quantum_flex.core.record verify <path>`` ---------------


def _main_verify(argv: list[str] | None = None) -> int:
    import argparse

    p = argparse.ArgumentParser(
        prog="python -m quantum_flex.core.record",
        description="Verify a committed RunRecord JSON file.",
    )
    sub = p.add_subparsers(dest="command", required=True)
    p_v = sub.add_parser("verify", help="Re-load and re-validate a RunRecord JSON.")
    p_v.add_argument("path", type=Path)
    args = p.parse_args(argv)

    if args.command == "verify":
        record = RunRecord.load(args.path)
        _validate_no_secrets(record.to_dict())
        print(
            f"OK  {args.path}  "
            f"experiment={record.experiment!r} "
            f"backend={record.backend.get('name')!r} "
            f"shots={record.shots} "
            f"unique_outcomes={len(record.raw_counts)}"
        )
        return 0
    return 1


# Mark module-level constants as deliberately unused by linters that flag
# them — they are part of the documented public surface.
_PUBLIC = (SCHEMA_VERSION, default_output_path, _DATA_RUNS_RELATIVE)
del _PUBLIC

# Module loader sanity: never run this file as a top-level script through
# anything other than the documented `python -m` invocation.
if __name__ == "__main__":
    raise SystemExit(_main_verify())

# Keep environment-variable-name documentation visible even when this module
# is imported only via the CLI: tools that introspect `os.environ` references
# can find it here.
_EXPECTED_ENV = ("QISKIT_IBM_TOKEN",)
assert os is not None  # silence "imported but unused" if a future refactor drops the os import
