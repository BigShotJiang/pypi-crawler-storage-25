"""Read-only IBM Quantum client.

This module is the **only** code path in quantum-flex that touches the IBM
Quantum API. It exists so that the rest of the library — circuit
construction, RunRecord serialization, visualization — has zero direct
dependency on ``qiskit-ibm-runtime``. Aer-only users never load this file.

Security guarantees
-------------------

* The IBM Quantum API token is read from the ``QISKIT_IBM_TOKEN``
  environment variable. We do not accept it as a function argument,
  because then it would inevitably end up in stack traces, log lines,
  or doctests.
* The token is **never written to disk**. We pass ``set_as_default=False``
  to ``QiskitRuntimeService.save_account``-equivalent code paths so that
  no account file is created in ``~/.qiskit/``.
* The token is **never logged**. Calls to :func:`get_service` and
  :func:`get_backend` raise informative errors if it is missing, but
  they redact the value before any error string is constructed.

If you need a *persistent* IBM account configuration (for interactive
notebooks etc.), use Qiskit's own ``QiskitRuntimeService.save_account``
outside of quantum-flex. We deliberately do not wrap that.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from qiskit_ibm_runtime import IBMBackend, QiskitRuntimeService


class IBMRuntimeUnavailable(RuntimeError):
    """Raised when ``qiskit-ibm-runtime`` is not installed.

    quantum-flex's ``[ibm]`` extra installs it::

        pip install "quantum-flex[ibm]"
    """


class IBMTokenMissing(RuntimeError):
    """Raised when ``QISKIT_IBM_TOKEN`` is not set in the environment.

    quantum-flex never accepts the token as a function argument or reads
    it from a config file — it must be present in the environment.
    """


_SERVICE_CACHE: QiskitRuntimeService | None = None


def _require_runtime() -> Any:
    """Import ``qiskit_ibm_runtime`` or raise a helpful error."""
    try:
        import qiskit_ibm_runtime as runtime
    except ImportError as exc:
        raise IBMRuntimeUnavailable(
            "qiskit-ibm-runtime is not installed. "
            "Install it with: pip install 'quantum-flex[ibm]'"
        ) from exc
    return runtime


def _require_token() -> str:
    """Read the IBM Quantum token from the environment.

    The returned value is **only** passed to ``QiskitRuntimeService(...)``.
    It does not appear in any returned object, error message, or log line.
    """
    token = os.environ.get("QISKIT_IBM_TOKEN")
    if not token:
        raise IBMTokenMissing(
            "QISKIT_IBM_TOKEN is not set in the environment. "
            "Get a token from https://quantum.ibm.com and export it before "
            "calling any IBM Runtime function. quantum-flex never reads "
            "the token from disk or function arguments."
        )
    return token


def get_service() -> QiskitRuntimeService:
    """Return a memoized, *non-persistent* ``QiskitRuntimeService``.

    The service object is constructed once per process and reused across
    calls. It is **not** saved to ``~/.qiskit/`` — see the security note in
    the module docstring.
    """
    global _SERVICE_CACHE
    if _SERVICE_CACHE is not None:
        return _SERVICE_CACHE

    runtime = _require_runtime()
    token = _require_token()

    # `channel="ibm_quantum"` is the default open-access channel; the alternate
    # `"ibm_cloud"` requires a different account flow we deliberately do not
    # exercise here.
    _SERVICE_CACHE = runtime.QiskitRuntimeService(  # type: ignore[no-untyped-call]
        channel="ibm_quantum",
        token=token,
    )
    return _SERVICE_CACHE


def get_backend(name: str) -> IBMBackend:
    """Return the named IBM Quantum backend.

    Raises :class:`ValueError` if the backend is not visible to the
    authenticated account (most commonly because the device has been
    retired or the user lacks access).
    """
    service = get_service()
    try:
        return service.backend(name)  # type: ignore[no-any-return]
    except Exception as exc:  # noqa: BLE001 — re-raise with context
        raise ValueError(
            f"IBM Quantum backend {name!r} is not accessible from this account. "
            "Use `QiskitRuntimeService().backends()` (in a notebook with your "
            "token loaded) to see what is available."
        ) from exc


def list_visible_backends() -> list[str]:
    """Return the names of every backend visible to the current account."""
    service = get_service()
    return [b.name for b in service.backends()]


def reset_cache() -> None:
    """Discard the memoized service. Useful in tests; rarely needed otherwise."""
    global _SERVICE_CACHE
    _SERVICE_CACHE = None
