"""Shared infrastructure for every quantum-flex experiment and art module.

What lives here:

  * :mod:`quantum_flex.core.record` — the ``RunRecord`` JSON schema and its
    load/save/verify helpers. Every committed file under ``data/runs/`` is a
    serialized ``RunRecord``.
  * :mod:`quantum_flex.core.runner` — a thin wrapper that submits a
    :class:`qiskit.QuantumCircuit` to either an Aer simulator backend or an
    IBM Quantum runtime backend, and returns a populated :class:`RunRecord`.
  * :mod:`quantum_flex.core.style` — the shared matplotlib palette and
    figure presets. All ``art/*.py`` modules import from here so that
    figures across the gallery feel coherent.
  * :mod:`quantum_flex.core.visualize` — common helpers for writing PNG/MP4/
    GIF outputs from a sequence of matplotlib frames.
  * :mod:`quantum_flex.core.ibm` — read-only IBM Quantum client. Reads
    ``QISKIT_IBM_TOKEN`` from the environment; never persists it to disk;
    never logs it.

Anything that is genuinely shared between two or more experiments belongs
here. Anything experiment-specific belongs in
``quantum_flex.experiments.<name>`` instead.
"""

from __future__ import annotations
