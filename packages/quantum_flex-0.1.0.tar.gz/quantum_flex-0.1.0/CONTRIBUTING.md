# Contributing to quantum-flex

Thank you for considering a contribution. quantum-flex deliberately accepts
two categories of contribution that many other research repositories do not:

  1. **New experiments that did not work** — see "The failure museum" below.
  2. **Re-renderings of existing data** with no new run attached.

Both are first-class. The single non-negotiable requirement is honest
reproducibility.

---

## Quickest possible contribution

Found a typo or a broken link? Open a PR directly. No issue needed.

## Reporting a bug

Use the **Bug report** issue template. Include:

  - Python version and OS
  - `pip show quantum-flex` output
  - Whether the failure is on Aer or real hardware (and which backend)
  - The smallest snippet that reproduces it
  - Full stack trace

## Proposing a new experiment

Use the **Experiment request** issue template. Even a one-line idea is
welcome — we will help you scaffold it.

If you already have working code:

```bash
git clone https://github.com/hinanohart/quantum-flex
cd quantum-flex
pip install -e ".[dev,all]"

quantum-flex new my_experiment_name
# Edit src/quantum_flex/experiments/_wip/my_experiment_name/
# Open a draft PR — review starts there.
```

---

## What goes where

| You changed... | Where it lives |
|---|---|
| A shared helper (style, JSON schema, IBM client) | `src/quantum_flex/core/` |
| A new experiment, still rough | `src/quantum_flex/experiments/_wip/<name>/` |
| A mature experiment with a stable API | `src/quantum_flex/experiments/<name>/` |
| A pure visualization driven by an existing record | `src/quantum_flex/art/` |
| Real-hardware measurement counts | `data/runs/<date>_<exp>_<verdict>.json` |
| A rendered figure or animation | `gallery/` (small only — large via Release assets) |
| A Jupyter walkthrough | `notebooks/` |
| Tests | `tests/` (Aer-only; real-hardware tests gate on the `real_hardware` marker) |

---

## The RunRecord JSON schema

Every file under `data/runs/` is a `RunRecord`:

```json
{
  "schema_version": "1.0",
  "experiment": "bell_chsh",
  "qflex_version": "0.1.0",
  "qiskit_version": "2.3.1",
  "qiskit_aer_version": "0.17.2",
  "backend": {
    "name": "ibm_fez",
    "type": "real_hardware",
    "qubits": 156,
    "version": "Heron r2"
  },
  "execution": {
    "shots": 4000,
    "session_id": "...",
    "job_id": "...",
    "timestamp_jst": "2026-04-04T11:59:00+09:00",
    "duration_seconds": 12.3
  },
  "circuit": {
    "qasm": "OPENQASM 3.0; ...",
    "depth": 5,
    "gate_count": 18,
    "n_qubits_used": 4
  },
  "raw_counts": {"00": 1023, "01": 877, "10": 882, "11": 1218},
  "metrics": {
    "S_chsh": 2.6967,
    "violated_bell": true,
    "classical_max": 2.0
  },
  "notes": "Optional human commentary."
}
```

Helpers live in `quantum_flex.core.record`:

```python
from quantum_flex.core.record import RunRecord

record = RunRecord.from_aer_job(job, experiment="my_test", metrics={...})
record.save("data/runs/2026-04-18_my_test.json")

# Roundtrip for re-rendering
loaded = RunRecord.load("data/runs/2026-04-18_my_test.json")
```

If you change the schema, **bump `schema_version`** and add a backward-
compatible loader path. We never silently break old records.

---

## The failure museum

A directory under `experiments/_wip/` is *not* a temporary staging area.
It is a permanent, public record of an honest attempt that did not succeed.
Every `_wip/` entry must include:

  - `README.md` — hypothesis, method, what you expected, what you got.
  - `LESSONS_LEARNED.md` — the post-mortem. Why did it fail? What is the
    minimal change that could rescue it?
  - `circuit.py`, `run.py`, `visualize.py` — like any other experiment.
  - At least one `data/runs/*.json` from the failing run.

The `_wip/` rule is **never `git rm` a failure**. If a hypothesis is
disproved, write up why and keep the data. The corrected version goes next to
the buggy one with a `_v2` suffix; the original stays as `*_buggy_v1.json`.

This convention is borrowed wholesale from the
[`yuragi`](https://github.com/hinanohart/yuragi) project, which has
articulated it more thoroughly than we have.

---

## Style and tooling

  - **Formatter**: `ruff format` (replaces black). Run before committing.
  - **Linter**: `ruff check`.
  - **Types**: `mypy`. New code under `core/` should pass `--strict`. Inside
    individual experiments we are more permissive because circuit code uses
    short symbol names by physics convention.
  - **Tests**: `pytest`. New `core/` helpers must include unit tests; new
    experiments must include at least one Aer-backend smoke test.
  - **Notebooks**: keep outputs **stripped** before commit (run
    `nbstripout --install` once, or strip manually). Outputs are reproducible
    from `data/runs/`, so they do not need to live in the diff.

```bash
# What CI runs:
ruff check .
ruff format --check .
bandit -r src/quantum_flex -ll
mypy src/quantum_flex/core
pytest -q
```

## Real-hardware tests

Real-hardware tests carry the `real_hardware` pytest marker and are
deselected by default:

```python
@pytest.mark.real_hardware
def test_chsh_on_ibm_fez(...):
    ...
```

They run only when explicitly requested:

```bash
pytest -m real_hardware
```

CI never runs them — the IBM Quantum API token does not exist in CI secrets,
and we do not want CI silently spending your account's minutes.

---

## License of contributions

By submitting a contribution you agree that:

  - **Source-code contributions** are licensed under
    [Apache License 2.0](LICENSE), the project's main license.
  - **Data contributions** (RunRecord JSONs, rendered figures, notebook
    outputs) are licensed under [CC BY 4.0](LICENSE-DATA).

We do not require a CLA. The license headers in the source tree and the
`LICENSE` / `LICENSE-DATA` files are sufficient.

---

## Code of conduct

This project follows the
[Contributor Covenant](CODE_OF_CONDUCT.md). Be kind, especially to anyone
asking a "basic" quantum-computing question — we have all been there.
