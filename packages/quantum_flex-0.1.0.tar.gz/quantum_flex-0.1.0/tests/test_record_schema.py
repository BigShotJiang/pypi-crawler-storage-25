"""``RunRecord`` schema, security, and round-trip tests.

These cover three things:

  * Round-trip: build → save → load → identical record.
  * Secret-rejection: any 60+ char alnum/_/- string that is **not** a
    bitstring or QASM source must be rejected.
  * Bitstring whitelist: 100+ qubit experiments must round-trip.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from quantum_flex.core.record import RunRecord


def _aer_record(experiment: str = "smoke", counts: dict[str, int] | None = None) -> RunRecord:
    return RunRecord.from_aer_job(
        experiment=experiment,
        circuit_qasm="OPENQASM 3;\ninclude \"stdgates.inc\";\nqubit[2] q;\nh q[0];\ncx q[0], q[1];\n",
        circuit_depth=2,
        circuit_gate_count=2,
        n_qubits_used=2,
        shots=1024,
        raw_counts=counts or {"00": 512, "11": 512},
    )


def test_round_trip(tmp_path: Path) -> None:
    record = _aer_record()
    target = tmp_path / "smoke.json"
    record.save(target)
    loaded = RunRecord.load(target)
    assert loaded.experiment == record.experiment
    assert loaded.raw_counts == record.raw_counts
    assert loaded.circuit["qasm"] == record.circuit["qasm"]


def test_default_path_is_under_data_runs() -> None:
    from quantum_flex.core.record import default_output_path

    p = default_output_path("smoke")
    assert p.parts[:2] == ("data", "runs")
    assert p.name.endswith("_smoke.json")


def test_save_rejects_token_like_string(tmp_path: Path) -> None:
    record = _aer_record()
    record.notes = "ABCD" * 25  # 100-char alnum string
    with pytest.raises(ValueError, match="token-like"):
        record.save(tmp_path / "bad.json")


def test_save_rejects_forbidden_key(tmp_path: Path) -> None:
    record = _aer_record()
    record.metrics = {"token": "x" * 80}
    with pytest.raises(ValueError, match="forbidden key"):
        record.save(tmp_path / "bad.json")


def test_save_accepts_long_bitstring(tmp_path: Path) -> None:
    """A 100-qubit experiment's bitstring keys must not be flagged as tokens."""
    big_bitstring = "0" * 100
    record = _aer_record(experiment="wide", counts={big_bitstring: 4096})
    target = tmp_path / "wide.json"
    record.save(target)
    payload = json.loads(target.read_text())
    assert big_bitstring in payload["raw_counts"]


def test_save_accepts_qasm_in_metrics(tmp_path: Path) -> None:
    record = _aer_record()
    record.metrics = {"alt_qasm": "OPENQASM 3;\n" + ("h q[0];\n" * 200)}
    record.save(tmp_path / "qasm_in_metrics.json")  # must not raise


def test_unknown_schema_version_is_rejected(tmp_path: Path) -> None:
    target = tmp_path / "vfuture.json"
    target.write_text(json.dumps({
        "experiment": "x",
        "backend": {}, "execution": {}, "circuit": {},
        "raw_counts": {}, "metrics": {}, "notes": "",
        "schema_version": "9.9",
    }))
    with pytest.raises(ValueError, match="unknown RunRecord schema_version"):
        RunRecord.load(target)
