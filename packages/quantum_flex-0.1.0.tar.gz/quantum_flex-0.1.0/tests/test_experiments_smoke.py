"""Aer-only smoke tests for every published experiment.

These tests:

  * Build the circuits from each ``experiments/<name>/circuit.py``.
  * Run them on Aer with very small shot counts.
  * Verify the resulting RunRecord round-trips through ``save`` / ``load``.

We intentionally do *not* test the IBM-runtime path here — that requires
network credentials and would make the test suite flaky.
"""

from __future__ import annotations

from pathlib import Path

import pytest

# Skip the whole module if qiskit-aer is not installed; the rest of the
# package can still be tested independently.
pytest.importorskip("qiskit_aer")


def test_bell_chsh_runs_on_aer(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    from quantum_flex.experiments.bell_chsh.run import main

    rc = main(["--backend", "aer", "--shots", "200"])
    assert rc == 0
    out = next((tmp_path / "data" / "runs").glob("*_bell_chsh.json"))
    assert out.stat().st_size > 200

    from quantum_flex.core.record import RunRecord

    record = RunRecord.load(out)
    assert record.experiment == "bell_chsh"
    assert "S" in record.metrics
    # Aer with the corrected angles should clearly violate the classical bound.
    assert abs(float(record.metrics["S"])) > 2.0


def test_teleportation_runs_on_aer(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    from quantum_flex.experiments.teleportation.run import main

    rc = main(["--backend", "aer", "--shots", "256"])
    assert rc == 0
    out = next((tmp_path / "data" / "runs").glob("*_teleportation.json"))

    from quantum_flex.core.record import RunRecord

    record = RunRecord.load(out)
    assert record.metrics["average_fidelity"] > 0.85  # Aer should be near-perfect.


def test_supremacy_100q_smoke(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    from quantum_flex.experiments.supremacy_100q.run import main

    # Use 12 qubits and depth 2 to keep the test fast.
    rc = main(["--backend", "aer", "--n-qubits", "12", "--depth", "2", "--shots", "256"])
    assert rc == 0
    out = next((tmp_path / "data" / "runs").glob("*_supremacy_100q.json"))

    from quantum_flex.core.record import RunRecord

    record = RunRecord.load(out)
    assert record.metrics["n_qubits"] == 12


def test_mermin_peres_runs_on_aer(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    from quantum_flex.experiments.mermin_peres.run import main

    rc = main(["--backend", "aer", "--shots", "256"])
    assert rc == 0
    out = next((tmp_path / "data" / "runs").glob("*_mermin_peres.json"))

    from quantum_flex.core.record import RunRecord

    record = RunRecord.load(out)
    # Aer should beat the classical bound clearly.
    assert record.metrics["average_rate"] > 0.95
