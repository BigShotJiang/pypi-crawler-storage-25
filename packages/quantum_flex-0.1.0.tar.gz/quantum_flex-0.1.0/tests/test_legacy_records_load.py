"""Verify the committed ``data/runs/*.json`` legacy & seed records all load.

This catches schema-drift regressions before they break gallery rendering.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from quantum_flex.core.record import RunRecord

REPO_ROOT = Path(__file__).resolve().parent.parent
DATA_RUNS = REPO_ROOT / "data" / "runs"


@pytest.mark.parametrize(
    "record_path",
    sorted(DATA_RUNS.glob("*.json")) if DATA_RUNS.exists() else [],
    ids=lambda p: p.name if isinstance(p, Path) else str(p),
)
def test_legacy_record_loads(record_path: Path) -> None:
    record = RunRecord.load(record_path)
    assert record.experiment, f"empty experiment field in {record_path.name}"
    assert isinstance(record.metrics, dict)
    assert isinstance(record.raw_counts, dict)
    # Save round-trip — also re-validates the no-secrets check on every file.
    target = record_path.with_suffix(".roundtrip.json")
    try:
        record.save(target)
    finally:
        target.unlink(missing_ok=True)
