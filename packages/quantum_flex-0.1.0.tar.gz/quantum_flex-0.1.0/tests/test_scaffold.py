"""Smoke tests covering the package scaffolding.

These tests exist to ensure that the *shape* of the package — version
string, top-level imports, CLI subcommand wiring — is sane on every PR,
without yet depending on the not-implemented core helpers.
"""

from __future__ import annotations

import importlib

import pytest


def test_package_imports() -> None:
    pkg = importlib.import_module("quantum_flex")
    assert isinstance(pkg.__version__, str)
    assert pkg.__version__.count(".") >= 2  # X.Y.Z


def test_subpackages_import() -> None:
    for name in ("quantum_flex.core", "quantum_flex.experiments", "quantum_flex.art"):
        importlib.import_module(name)


def test_cli_help_does_not_crash() -> None:
    cli = importlib.import_module("quantum_flex.cli")
    parser = cli._build_parser()
    with pytest.raises(SystemExit):
        # ``-h`` exits with code 0; argparse raises SystemExit either way.
        parser.parse_args(["-h"])


def test_cli_rejects_reserved_names() -> None:
    cli = importlib.import_module("quantum_flex.cli")
    for bad in ("_template", "_wip", "core", "art", "cli", "1abc", "Abc", "with-dash"):
        assert not cli._slug_is_valid(bad), f"slug should be invalid: {bad!r}"


def test_cli_accepts_valid_names() -> None:
    cli = importlib.import_module("quantum_flex.cli")
    for good in ("bell_chsh", "ghz_state", "my_test", "h2_vqe"):
        assert cli._slug_is_valid(good), f"slug should be valid: {good!r}"
