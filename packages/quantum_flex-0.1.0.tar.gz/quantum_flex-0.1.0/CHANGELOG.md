# Changelog

All notable changes to **quantum-flex** are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

Source-code changes (`src/`, build config) follow Apache-2.0 versioning;
data and figure changes (`data/runs/`, `gallery/`) follow CC BY 4.0 and are
versioned alongside the same release tags but never break older records.

---

## [Unreleased]

## [0.1.0] — 2026-04-18

Initial public release.

### Added — code

  - Project scaffolding: `pyproject.toml`, dual licensing
    (Apache-2.0 + CC BY 4.0), `ai.txt` opt-out.
  - `quantum_flex.core`:
      - `RunRecord` — JSON schema (v1.0) for capturing every real-hardware
        and Aer execution with full provenance (qiskit version, backend,
        shots, circuit QASM, raw counts, metrics).
      - `runner` — uniform Aer / IBM Runtime execution wrapper.
      - `style` — shared matplotlib theme (deep-space palette, neon accents).
      - `visualize` — mp4 / gif writer used across `art/`.
      - `ibm` — read-only client; reads `QISKIT_IBM_TOKEN` from environment
        and never persists it to disk.
  - `quantum_flex.cli` — `quantum-flex new <name>` scaffolds a new
    experiment under `experiments/_wip/<name>/` from
    `experiments/_template/`. `quantum-flex promote <name>` graduates a
    `_wip/` experiment to `experiments/`.
  - Experiments shipped:
      - `bell_chsh` — CHSH inequality, S = 2.6967 reproduced on `ibm_fez`.
      - `teleportation` — 3-qubit protocol, avg fidelity 0.97.
      - `supremacy_100q` — 100-qubit unique-state demo, 4 000 / 4 000 unique.
      - `mermin_peres` — magic-square pseudo-telepathy, all 9 cells beat the
        classical bound (avg 96.4 % > 88.9 %).
  - Art modules shipped:
      - `mandala` — quantum-interference geometric mandala.
      - `terrain` — interference field rendered as 3-D heightmap.
      - `interference` — superposition moiré pattern.
      - `game_of_life` — quantum vs. classical Conway, side-by-side.
      - `wigner_anim` — Wigner-function animation for cat states.
      - `pinball` — 2-D quantum-walk pinball animation.

### Added — data (CC BY 4.0)

  - `data/runs/2026-04-04_chsh_S=2.69.json`
  - `data/runs/2026-04-04_100qubit_4000shots.json`
  - `data/runs/2026-04-04_teleportation_fid97.json`
  - `data/runs/2026-04-04_mermin_peres_96.4pct.json`
  - `data/runs/2026-04-04_multi_basis.json`

### Added — failure museum

  - `experiments/_wip/qaoa_144q_collapsed/` — A QAOA attempt at 144-qubit
    graph matching with depth ~3000 returned 0 valid solutions; the post-
    mortem documents why NISQ hardware is currently noise-dominated at this
    scale.
  - `experiments/_wip/quantum_lost_to_hungarian/` — Side-by-side comparison
    in which the classical Hungarian algorithm beat the quantum solver
    200 vs. 588 cells (+193 %).

### Infrastructure

  - GitHub Actions: `ci.yml` (ruff + bandit + pytest matrix on
    Ubuntu/macOS/Windows × Python 3.10–3.13), `codeql.yml` (weekly +
    on-push), `release.yml` (PyPI Trusted Publishing + GitHub Release).
  - Dependabot enabled for `pip`, `github-actions`, `pyscf` updates.
  - Branch protection: required `Lint`, `Test`, `Build`, `CodeQL` checks;
    no force-push, no direct push to `main`.

### Notes

  - Total real-hardware execution time across all v0.1.0 experiments: ~200 s
    cumulative on IBM Quantum Open Plan (`ibm_fez` Heron r2, 156 qubits).
  - All `QISKIT_IBM_TOKEN` references are environment-only; no token has
    ever been committed to this repository.
