"""Run every published experiment on Aer and render the gallery.

This is the script you'd run on a fresh checkout to convince yourself
that everything works end-to-end. It uses tiny shot counts on purpose
so the whole sequence finishes in under a minute on a laptop.
"""

from __future__ import annotations

import sys
from pathlib import Path


def main() -> int:
    from quantum_flex.experiments.bell_chsh.run import main as bell_main
    from quantum_flex.experiments.bell_chsh.visualize import main as bell_viz
    from quantum_flex.experiments.mermin_peres.run import main as mermin_main
    from quantum_flex.experiments.mermin_peres.visualize import main as mermin_viz
    from quantum_flex.experiments.supremacy_100q.run import main as supremacy_main
    from quantum_flex.experiments.supremacy_100q.visualize import main as supremacy_viz
    from quantum_flex.experiments.teleportation.run import main as tel_main
    from quantum_flex.experiments.teleportation.visualize import main as tel_viz

    print(">>> bell_chsh", file=sys.stderr)
    bell_main(["--backend", "aer", "--shots", "1024"])

    print(">>> teleportation", file=sys.stderr)
    tel_main(["--backend", "aer", "--shots", "1024"])

    print(">>> supremacy_100q (smoke: 24q × depth 3)", file=sys.stderr)
    supremacy_main(["--backend", "aer", "--n-qubits", "24", "--depth", "3", "--shots", "1024"])

    print(">>> mermin_peres", file=sys.stderr)
    mermin_main(["--backend", "aer", "--shots", "1024"])

    runs = Path("data/runs")
    gallery = Path("gallery")
    gallery.mkdir(exist_ok=True)
    print(">>> rendering gallery/", file=sys.stderr)
    for experiment_name, viz_main in (
        ("bell_chsh", bell_viz),
        ("teleportation", tel_viz),
        ("supremacy_100q", supremacy_viz),
        ("mermin_peres", mermin_viz),
    ):
        latest = max(runs.glob(f"*_{experiment_name}.json"), key=lambda p: p.stat().st_mtime)
        out = gallery / f"{experiment_name}.png"
        viz_main(["--record", str(latest), "--out", str(out)])
        print(f"  {out}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
