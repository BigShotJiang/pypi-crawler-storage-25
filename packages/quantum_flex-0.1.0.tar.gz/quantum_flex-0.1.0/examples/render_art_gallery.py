"""Generate the six art-module outputs into ``gallery/``.

Useful as a smoke test for the ``art/*`` modules. The mandala and
animated outputs are the slow ones (~1 minute each); the static art is
under 10 seconds combined.
"""

from __future__ import annotations

import sys
from pathlib import Path


def main() -> int:
    gallery = Path("gallery")
    gallery.mkdir(exist_ok=True)

    from quantum_flex.art import (
        game_of_life, interference, mandala, pinball, terrain, wigner_anim,
    )

    targets = (
        ("interference",  gallery / "interference.png",   interference.render),
        ("terrain",       gallery / "terrain.png",        terrain.render),
        ("mandala",       gallery / "mandala.png",        mandala.render),
        ("game_of_life",  gallery / "game_of_life.gif",   game_of_life.render),
        ("wigner_anim",   gallery / "wigner_anim.gif",    wigner_anim.render),
        ("pinball",       gallery / "pinball.gif",        pinball.render),
    )
    for name, out, render in targets:
        print(f">>> {name} -> {out}", file=sys.stderr)
        render(output=out)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
