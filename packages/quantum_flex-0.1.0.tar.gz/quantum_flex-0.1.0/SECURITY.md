# Security policy

## Reporting a vulnerability

quantum-flex is a research-and-visualization library. Most of the surface
area touches local files, matplotlib, and outbound IBM Quantum API calls.
Even so, several classes of issue do warrant a coordinated disclosure:

  - Code paths that could exfiltrate an IBM Quantum API token from a user's
    environment (e.g. a logger, a JSON writer, or an exception path that
    leaks `QISKIT_IBM_TOKEN` to disk or stdout).
  - Deserialization issues in `RunRecord.load` or in the `data/runs/`
    parsers.
  - Supply-chain issues in our pinned dependencies.
  - Anything that lets a malicious notebook escape the user's local
    workspace.

Please report these privately to **hinanohart@proton.me**. We will:

  1. Acknowledge within 72 hours.
  2. Confirm the issue and prepare a fix in a private branch.
  3. Coordinate a disclosure window (default 90 days, shorter if active
     exploitation is observed).
  4. Publish a GitHub Security Advisory and credit the reporter (unless
     they prefer to remain anonymous).

For non-security bugs, please open a regular GitHub issue.

## What we do NOT consider a vulnerability

  - Numerical noise in IBM Quantum results — that is the physics, not a bug.
  - Failed experiments under `experiments/_wip/`. Those are *deliberately*
    preserved failures (see the failure-museum policy in CONTRIBUTING.md).
  - Differences between Aer simulation and real-hardware execution.
  - Notebook cells that render slowly on a low-memory machine.

## Scope

The scope of this policy is the contents of this repository: source code
under `src/`, tests, build configuration, GitHub Actions workflows,
JSON schema parsers, and committed datasets.

We do not provide security guarantees for third-party Qiskit plugins or
IBM Quantum services themselves — those have their own disclosure channels:

  - Qiskit: https://github.com/Qiskit/qiskit/security
  - IBM Quantum: https://www.ibm.com/trust/security-psirt
