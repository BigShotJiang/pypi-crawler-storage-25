from __future__ import annotations

import sys

from PyQt5.QtWidgets import QApplication, QLabel


def main() -> int:
    app = QApplication(sys.argv)
    label = QLabel("pyslow2fast PyQt5 test OK")
    label.resize(320, 80)
    label.show()
    return app.exec_()


if __name__ == "__main__":
    raise SystemExit(main())

