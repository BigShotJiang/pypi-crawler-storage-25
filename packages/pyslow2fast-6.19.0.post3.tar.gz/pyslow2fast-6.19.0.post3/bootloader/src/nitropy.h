#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Fonction principale pour lancer un EXE directement en mémoire
int __stdcall RunExeProjected(const char* targetPath);

#ifdef __cplusplus
}
#endif