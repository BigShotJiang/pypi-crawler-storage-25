from pathlib import Path

import pandas as pd

from litgenemap.extract import apply_gene_blacklist
from litgenemap.pipeline import run_pipeline


def test_minimal_title_abstract_pipeline(tmp_path: Path):
    lit = pd.DataFrame(
        {
            "title": ["TP53 in cancer", "EGFR signaling"],
            "abstract": ["TP53 and BRCA1 are important", "EGFR interacts with ERBB2"],
            "year": [2020, 2021],
        }
    )
    lit_path = tmp_path / "lit.csv"
    lit.to_csv(lit_path, index=False)

    dic = pd.DataFrame(
        {
            "raw_term": ["TP53", "BRCA1", "EGFR", "ERBB2"],
            "standard_symbol": ["TP53", "BRCA1", "EGFR", "ERBB2"],
        }
    )
    dic_path = tmp_path / "dic.csv"
    dic.to_csv(dic_path, index=False)

    out_dir = tmp_path / "out"
    results = run_pipeline(
        literature_file=str(lit_path),
        gene_file=str(dic_path),
        output_dir=str(out_dir),
        gene_input="dictionary",
        analysis_level="frequency",
    )

    assert not results["detail"].empty
    assert (out_dir / "gene_frequency.csv").exists()
    assert "mean_year" in results["frequency"].columns
    assert results["active_text_columns"] == ["title", "abstract", "keyword"]


def test_keyword_column_is_used_by_default(tmp_path: Path):
    lit = pd.DataFrame(
        {
            "title": ["No explicit gene in title"],
            "abstract": ["No explicit gene in abstract"],
            "keyword": ["TP53; BRCA1"],
        }
    )
    lit_path = tmp_path / "lit_kw.csv"
    lit.to_csv(lit_path, index=False)

    dic = pd.DataFrame(
        {
            "raw_term": ["TP53", "BRCA1"],
            "standard_symbol": ["TP53", "BRCA1"],
        }
    )
    dic_path = tmp_path / "dic_kw.csv"
    dic.to_csv(dic_path, index=False)

    out_dir = tmp_path / "out_kw"
    results = run_pipeline(
        literature_file=str(lit_path),
        gene_file=str(dic_path),
        output_dir=str(out_dir),
        gene_input="dictionary",
        analysis_level="frequency",
    )

    assert set(results["frequency"]["gene_symbol"].tolist()) == {"TP53", "BRCA1"}


def test_blacklist_removes_gene():
    detail = pd.DataFrame(
        {
            "article_id": ["A00001", "A00001"],
            "gene_symbol": ["TP53", "CAT"],
            "matched_terms": ["TP53", "CAT"],
        }
    )
    cleaned = apply_gene_blacklist(detail, gene_symbols=["CAT"])
    assert cleaned["gene_symbol"].tolist() == ["TP53"]


def test_default_blacklist_removes_ambiguous_term(tmp_path):
    literature = tmp_path / "lit.csv"
    literature.write_text("title,abstract,keyword\nStudy of of,Nothing here,\n", encoding="utf-8")

    dictionary = tmp_path / "dict.csv"
    dictionary.write_text("raw_term,standard_symbol\nOF,BRIP1\nBRIP1,BRIP1\n", encoding="utf-8")

    outdir = tmp_path / "out"
    results = run_pipeline(
        literature_file=str(literature),
        gene_file=str(dictionary),
        output_dir=str(outdir),
        gene_input="dictionary",
        analysis_level="frequency",
    )

    detail = results["detail"]
    assert detail.empty


def test_no_default_blacklist_keeps_raw_matching(tmp_path):
    literature = tmp_path / "lit.csv"
    literature.write_text("title,abstract,keyword\nStudy of of,Nothing here,\n", encoding="utf-8")

    dictionary = tmp_path / "dict.csv"
    dictionary.write_text("raw_term,standard_symbol\nOF,BRIP1\n", encoding="utf-8")

    outdir = tmp_path / "out"
    results = run_pipeline(
        literature_file=str(literature),
        gene_file=str(dictionary),
        output_dir=str(outdir),
        gene_input="dictionary",
        analysis_level="frequency",
        use_default_blacklist=False,
    )

    detail = results["detail"]
    assert not detail.empty
    assert "BRIP1" in set(detail["gene_symbol"])
