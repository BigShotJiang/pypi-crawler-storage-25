from __future__ import annotations

from pathlib import Path

import pandas as pd


REQUIRED_HGNC_COLUMNS = [
    "hgnc_id",
    "symbol",
    "name",
    "status",
    "locus_group",
    "locus_type",
    "alias_symbol",
    "prev_symbol",
    "entrez_id",
    "ensembl_gene_id",
]


def _split_terms(value: str) -> list[str]:
    if not isinstance(value, str) or not value.strip():
        return []
    value = value.strip()
    replacements = {
        "', '": "|",
        '", "': "|",
        "'": "",
        '"': "",
        ";": "|",
        ",": "|",
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    return [part.strip() for part in value.split("|") if part.strip()]


def build_hgnc_dictionary(
    hgnc_path: str | Path,
    *,
    approved_only: bool = True,
    protein_coding_only: bool = True,
    include_alias: bool = True,
    include_prev_symbol: bool = True,
    min_term_length: int = 2,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    hgnc_path = Path(hgnc_path)
    df = pd.read_csv(hgnc_path, sep="\t", dtype=str).fillna("")

    missing = [c for c in REQUIRED_HGNC_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"HGNC file missing required columns: {missing}")

    df = df[REQUIRED_HGNC_COLUMNS].copy()
    if approved_only:
        df = df[df["status"].str.strip().str.lower() == "approved"].copy()
    if protein_coding_only:
        df = df[df["locus_group"].str.strip().str.lower() == "protein-coding gene"].copy()

    df = df[df["symbol"].str.strip() != ""].copy()
    df = df.drop_duplicates(subset=["symbol"]).reset_index(drop=True)

    rows: list[dict[str, str]] = []
    for _, row in df.iterrows():
        base = {
            "standard_symbol": row["symbol"],
            "hgnc_id": row["hgnc_id"],
            "entrez_id": row["entrez_id"],
            "ensembl_gene_id": row["ensembl_gene_id"],
        }
        rows.append({**base, "raw_term": row["symbol"], "term_type": "symbol"})
        if include_alias:
            for term in _split_terms(row["alias_symbol"]):
                rows.append({**base, "raw_term": term, "term_type": "alias_symbol"})
        if include_prev_symbol:
            for term in _split_terms(row["prev_symbol"]):
                rows.append({**base, "raw_term": term, "term_type": "prev_symbol"})

    expanded = pd.DataFrame(rows)
    expanded["raw_term"] = expanded["raw_term"].astype(str).str.strip()
    expanded = expanded[expanded["raw_term"] != ""].copy()
    expanded = expanded[expanded["raw_term"].str.len() >= min_term_length].copy()
    expanded = expanded[~expanded["raw_term"].str.fullmatch(r"\d+")].copy()
    expanded = expanded.drop_duplicates(subset=["raw_term", "standard_symbol"]).reset_index(drop=True)

    minimal = expanded[["raw_term", "standard_symbol"]].drop_duplicates().reset_index(drop=True)
    return df.reset_index(drop=True), expanded, minimal


def read_dictionary(path: str | Path) -> pd.DataFrame:
    """Read a species-agnostic mapping table with raw_term and standard_symbol.

    This is the preferred input for non-human analyses.
    """
    path = Path(path)
    if path.suffix.lower() in {".xlsx", ".xls"}:
        df = pd.read_excel(path, dtype=str)
    else:
        df = pd.read_csv(path, dtype=str)
    df = df.fillna("")
    required = {"raw_term", "standard_symbol"}
    if not required.issubset(df.columns):
        raise ValueError("Dictionary must contain raw_term and standard_symbol columns")
    keep_cols = [c for c in ["raw_term", "standard_symbol", "species", "term_type"] if c in df.columns]
    df = df[keep_cols].copy()
    df["raw_term"] = df["raw_term"].astype(str).str.strip()
    df["standard_symbol"] = df["standard_symbol"].astype(str).str.strip()
    df = df[(df["raw_term"] != "") & (df["standard_symbol"] != "")].drop_duplicates().reset_index(drop=True)
    return df
