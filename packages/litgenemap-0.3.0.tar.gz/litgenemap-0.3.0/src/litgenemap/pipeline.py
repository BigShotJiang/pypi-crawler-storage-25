from __future__ import annotations

from pathlib import Path
from typing import Sequence
from importlib import resources

from .export import write_table
from .extract import apply_gene_blacklist, extract_gene_hits, load_blacklist
from .hgnc import build_hgnc_dictionary, read_dictionary
from .io import DEFAULT_TEXT_COLUMNS, read_literature_table
from .network import build_gene_network, detect_modules, score_genes
from .stats import compute_gene_statistics, compute_temporal_metrics


ANALYSIS_LEVELS = {"frequency", "cooccurrence", "full"}


def _load_default_blacklist() -> set[str]:
    with resources.files("litgenemap").joinpath("data/default_blacklist.txt").open("r", encoding="utf-8") as f:
        return {line.strip() for line in f if line.strip()}


def _apply_dictionary_blacklist(dictionary, blocked_values: set[str]):
    if dictionary.empty or not blocked_values:
        return dictionary
    blocked_upper = {str(x).strip().upper() for x in blocked_values if str(x).strip()}
    out = dictionary.copy()
    out = out[~out["raw_term"].astype(str).str.upper().isin(blocked_upper)].copy()
    return out.reset_index(drop=True)


def run_pipeline(
    literature_file: str,
    gene_file: str,
    output_dir: str,
    *,
    gene_input: str = "hgnc",
    text_columns: Sequence[str] | None = None,
    analysis_level: str = "full",
    blacklist_file: str | None = None,
    use_default_blacklist: bool = True,
    edge_metric: str = "sqrt",
    edge_threshold: float = 0.15,
    approved_only: bool = True,
    protein_coding_only: bool = True,
    min_term_length: int = 2,
) -> dict[str, object]:
    if analysis_level not in ANALYSIS_LEVELS:
        raise ValueError(f"analysis_level must be one of {sorted(ANALYSIS_LEVELS)}")

    active_text_columns = list(text_columns) if text_columns is not None else list(DEFAULT_TEXT_COLUMNS)

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    articles = read_literature_table(literature_file, text_columns=active_text_columns)

    if gene_input == "hgnc":
        standard_table, expanded_dictionary, dictionary = build_hgnc_dictionary(
            gene_file,
            approved_only=approved_only,
            protein_coding_only=protein_coding_only,
            min_term_length=min_term_length,
        )
    elif gene_input == "dictionary":
        dictionary = read_dictionary(gene_file)
        standard_table = None
        expanded_dictionary = None
    else:
        raise ValueError("gene_input must be 'hgnc' or 'dictionary'")

    blocked_values: set[str] = set()
    if use_default_blacklist:
        blocked_values |= _load_default_blacklist()
    if blacklist_file:
        blocked_values |= load_blacklist(blacklist_file)

    dictionary = _apply_dictionary_blacklist(dictionary, blocked_values)

    if gene_input == "hgnc":
        write_table(standard_table, output_path / "hgnc_standard_gene_table.csv")
        if expanded_dictionary is not None:
            expanded_dictionary = _apply_dictionary_blacklist(expanded_dictionary, blocked_values)
            write_table(expanded_dictionary, output_path / "hgnc_gene_dictionary_expanded.csv")
        write_table(dictionary, output_path / "hgnc_gene_dictionary_minimal.csv")

    detail_df = extract_gene_hits(articles, dictionary, fields=active_text_columns)
    if blocked_values:
        detail_df = apply_gene_blacklist(detail_df, gene_symbols=blocked_values, matched_terms=blocked_values)

    matrix_df, freq_df, cooc_df = compute_gene_statistics(detail_df)
    temporal_df = compute_temporal_metrics(detail_df)
    if not freq_df.empty and not temporal_df.empty:
        freq_df = freq_df.merge(temporal_df, on="gene_symbol", how="left")

    write_table(articles, output_path / "articles_normalized.csv")
    write_table(detail_df, output_path / "article_gene_hits.csv")
    write_table(matrix_df, output_path / "article_gene_matrix.csv")
    write_table(freq_df, output_path / "gene_frequency.csv")

    results: dict[str, object] = {
        "articles": articles,
        "dictionary": dictionary,
        "detail": detail_df,
        "matrix": matrix_df,
        "frequency": freq_df,
        "cooccurrence": cooc_df,
        "active_text_columns": active_text_columns,
        "blocked_values": sorted(blocked_values),
    }

    if analysis_level in {"cooccurrence", "full"}:
        write_table(cooc_df, output_path / "gene_cooccurrence.csv")

    if analysis_level == "full":
        graph, network_edges = build_gene_network(
            freq_df[["gene_symbol", "article_count", "total_mentions"]],
            cooc_df,
            edge_metric=edge_metric,
            edge_threshold=edge_threshold,
        )
        module_df = detect_modules(graph)
        gene_table = score_genes(freq_df[[c for c in freq_df.columns if c != "module"]], module_df, graph)
        top_genes_by_module = gene_table.groupby("module", dropna=False).head(15).reset_index(drop=True)

        write_table(network_edges, output_path / "gene_network_edges.csv")
        write_table(module_df, output_path / "gene_modules.csv")
        write_table(gene_table, output_path / "gene_module_evidence_table.csv")
        write_table(top_genes_by_module, output_path / "top_genes_by_module.csv")

        results.update(
            {
                "network_edges": network_edges,
                "modules": module_df,
                "gene_table": gene_table,
                "top_genes_by_module": top_genes_by_module,
                "graph": graph,
            }
        )

    return results
