from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import pandas as pd


@dataclass(frozen=True)
class PatternEntry:
    raw_term: str
    standard_symbol: str
    pattern: re.Pattern[str]


def build_dictionary_patterns(dictionary: pd.DataFrame) -> list[PatternEntry]:
    dic = dictionary.copy()
    dic["term_len"] = dic["raw_term"].astype(str).str.len()
    dic = dic.sort_values(["term_len", "raw_term"], ascending=[False, True]).reset_index(drop=True)
    patterns: list[PatternEntry] = []
    for _, row in dic.iterrows():
        term = str(row["raw_term"]).strip()
        symbol = str(row["standard_symbol"]).strip()
        escaped = re.escape(term)
        pattern = re.compile(rf"(?<![A-Za-z0-9]){escaped}(?![A-Za-z0-9])", flags=re.IGNORECASE)
        patterns.append(PatternEntry(raw_term=term, standard_symbol=symbol, pattern=pattern))
    return patterns


def load_blacklist(path: str | Path) -> set[str]:
    path = Path(path)
    if path.suffix.lower() in {".xlsx", ".xls"}:
        df = pd.read_excel(path)
        values = df.iloc[:, 0].astype(str).tolist()
    else:
        with open(path, "r", encoding="utf-8") as f:
            values = [line.strip() for line in f]
    return {v.strip() for v in values if str(v).strip()}


def apply_gene_blacklist(
    detail_df: pd.DataFrame,
    *,
    gene_symbols: Iterable[str] | None = None,
    matched_terms: Iterable[str] | None = None,
) -> pd.DataFrame:
    if detail_df.empty:
        return detail_df.copy()
    out = detail_df.copy()
    if gene_symbols:
        blocked = {str(x).strip() for x in gene_symbols if str(x).strip()}
        out = out[~out["gene_symbol"].isin(blocked)].copy()
    if matched_terms:
        blocked_terms = {str(x).strip().lower() for x in matched_terms if str(x).strip()}
        out = out[
            ~out["matched_terms"].fillna("").astype(str).str.lower().apply(
                lambda s: any(term in {p.strip().lower() for p in s.split(';') if p.strip()} for term in blocked_terms)
            )
        ].copy()
    return out.reset_index(drop=True)


def extract_gene_hits(
    articles: pd.DataFrame,
    dictionary: pd.DataFrame,
    *,
    fields: Sequence[str] | None = None,
) -> pd.DataFrame:
    if fields is None:
        fields = ["title", "abstract"]

    patterns = build_dictionary_patterns(dictionary)
    rows: list[dict[str, object]] = []

    for _, article in articles.iterrows():
        article_id = article["article_id"]
        hit_map: dict[tuple[str, str], dict[str, object]] = {}
        for entry in patterns:
            field_hits: dict[str, int] = {}
            total_hits = 0
            for field in fields:
                text = str(article.get(field, "") or "")
                n_hits = len(entry.pattern.findall(text))
                field_hits[field] = n_hits
                total_hits += n_hits
            if total_hits == 0:
                continue
            key = (article_id, entry.standard_symbol)
            if key not in hit_map:
                hit_map[key] = {
                    "article_id": article_id,
                    "source_ref": article.get("source_ref", ""),
                    "year": article.get("year", pd.NA),
                    "doi": article.get("doi", ""),
                    "title": article.get("title", ""),
                    "gene_symbol": entry.standard_symbol,
                    "matched_terms": [entry.raw_term],
                    "total_hits_in_article": total_hits,
                }
                for field in fields:
                    hit_map[key][f"{field}_hit"] = field_hits[field]
            else:
                hit_map[key]["matched_terms"].append(entry.raw_term)
                hit_map[key]["total_hits_in_article"] += total_hits
                for field in fields:
                    hit_map[key][f"{field}_hit"] += field_hits[field]
        for payload in hit_map.values():
            payload["matched_terms"] = "; ".join(sorted(set(payload["matched_terms"])))
            rows.append(payload)

    detail_df = pd.DataFrame(rows)
    if detail_df.empty:
        base_cols = [
            "article_id", "source_ref", "year", "doi", "title", "gene_symbol", "matched_terms", "total_hits_in_article",
        ] + [f"{field}_hit" for field in fields]
        return pd.DataFrame(columns=base_cols)

    return detail_df.sort_values(["article_id", "gene_symbol"]).reset_index(drop=True)
