from __future__ import annotations

from pathlib import Path
from typing import Iterable, Sequence

import pandas as pd


DEFAULT_FIELD_CANDIDATES = {
    "article_id": ["article_id", "UT"],
    "source_ref": ["source_ref", "SR_FULL", "SR"],
    "title": ["title", "TI_raw", "TI"],
    "abstract": ["abstract", "AB_raw", "AB"],
    "keyword": ["keyword", "keywords", "author_keywords", "DE_raw", "DE"],
    "keywords_plus": ["keywords_plus", "ID"],
    "year": ["year", "PY"],
    "doi": ["doi", "DI"],
}


REQUIRED_TEXT_COLUMNS = ["title", "abstract"]
DEFAULT_TEXT_COLUMNS = ["title", "abstract", "keyword"]
OPTIONAL_COLUMNS = ["keyword", "keywords_plus", "year", "doi", "source_ref", "article_id"]


def _pick_column(columns: Iterable[str], candidates: list[str]) -> str | None:
    colset = list(columns)
    for name in candidates:
        if name in colset:
            return name
    return None


def _read_tabular(path: Path) -> pd.DataFrame:
    if path.suffix.lower() in {".xlsx", ".xls"}:
        return pd.read_excel(path, sheet_name=0)
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() in {".tsv", ".txt"}:
        return pd.read_csv(path, sep=None, engine="python")
    raise ValueError(f"Unsupported literature file format: {path.suffix}")


def read_literature_table(
    path: str | Path,
    *,
    text_columns: Sequence[str] | None = None,
) -> pd.DataFrame:
    """Read any tabular literature file with at least title and abstract columns.

    The function auto-maps common bibliometrix/WoS field names, but does not require
    bibliometrix-formatted input.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)

    df = _read_tabular(path)

    rename_map: dict[str, str] = {}
    for target, candidates in DEFAULT_FIELD_CANDIDATES.items():
        chosen = _pick_column(df.columns, candidates)
        if chosen is not None:
            rename_map[chosen] = target

    out = df.rename(columns=rename_map).copy()

    if text_columns is None:
        text_columns = DEFAULT_TEXT_COLUMNS

    missing_required = [col for col in REQUIRED_TEXT_COLUMNS if col not in out.columns]
    if missing_required:
        raise ValueError(
            "Literature table must contain title and abstract columns, or recognizable "
            f"equivalents. Missing: {missing_required}"
        )

    if "article_id" not in out.columns:
        out["article_id"] = [f"A{i + 1:05d}" for i in range(len(out))]

    for col in [*REQUIRED_TEXT_COLUMNS, *OPTIONAL_COLUMNS]:
        if col not in out.columns:
            out[col] = ""

    text_like = ["title", "abstract", "keyword", "keywords_plus", "doi", "source_ref"]
    for col in text_like:
        out[col] = out[col].fillna("").astype(str)

    out["year"] = pd.to_numeric(out["year"], errors="coerce").astype("Int64")

    keep_order = [
        "article_id",
        "source_ref",
        "title",
        "abstract",
        "keyword",
        "keywords_plus",
        "year",
        "doi",
    ]
    out = out[keep_order].copy()
    out["combined_text"] = out["title"] + " || " + out["abstract"] + " || " + out["keyword"]
    return out
