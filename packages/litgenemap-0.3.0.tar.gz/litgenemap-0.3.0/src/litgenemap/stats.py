from __future__ import annotations

import itertools
from collections import Counter

import pandas as pd


def compute_gene_statistics(detail_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if detail_df.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    matrix_df = (
        detail_df.assign(present=1)
        .pivot_table(index="article_id", columns="gene_symbol", values="present", aggfunc="max", fill_value=0)
        .reset_index()
    )

    freq_df = (
        detail_df.groupby("gene_symbol", as_index=False)
        .agg(
            article_count=("article_id", "nunique"),
            total_mentions=("total_hits_in_article", "sum"),
        )
        .sort_values(["article_count", "total_mentions", "gene_symbol"], ascending=[False, False, True])
        .reset_index(drop=True)
    )

    article_to_genes = detail_df.groupby("article_id")["gene_symbol"].apply(lambda s: sorted(set(s))).to_dict()
    cooccur_counter: Counter[tuple[str, str]] = Counter()
    for genes in article_to_genes.values():
        if len(genes) < 2:
            continue
        for g1, g2 in itertools.combinations(genes, 2):
            cooccur_counter[(g1, g2)] += 1

    cooc_df = pd.DataFrame(
        [
            {"gene1": g1, "gene2": g2, "cooccur_article_count": count}
            for (g1, g2), count in cooccur_counter.items()
        ]
    )
    if not cooc_df.empty:
        cooc_df = cooc_df.sort_values(["cooccur_article_count", "gene1", "gene2"], ascending=[False, True, True]).reset_index(drop=True)

    return matrix_df, freq_df, cooc_df


def compute_temporal_metrics(detail_df: pd.DataFrame) -> pd.DataFrame:
    if detail_df.empty or "year" not in detail_df.columns:
        return pd.DataFrame()
    temp = detail_df.copy()
    temp["year"] = pd.to_numeric(temp["year"], errors="coerce")
    temp = temp[temp["year"].notna()].copy()
    if temp.empty:
        return pd.DataFrame()
    current_year = int(temp["year"].max())
    grouped = (
        temp.groupby("gene_symbol", as_index=False)
        .agg(
            first_year=("year", "min"),
            last_year=("year", "max"),
            mean_year=("year", "mean"),
            median_year=("year", "median"),
            year_span=("year", lambda s: s.max() - s.min() if s.notna().any() else pd.NA),
        )
    )
    recent_cutoff = current_year - 4
    recent = (
        temp.assign(is_recent=temp["year"] >= recent_cutoff)
        .groupby("gene_symbol", as_index=False)
        .agg(
            recent_article_count=("is_recent", "sum"),
            total_article_count=("article_id", "nunique"),
        )
    )
    recent["recent_5y_ratio"] = recent["recent_article_count"] / recent["total_article_count"]
    grouped = grouped.merge(recent[["gene_symbol", "recent_5y_ratio"]], on="gene_symbol", how="left")
    return grouped
