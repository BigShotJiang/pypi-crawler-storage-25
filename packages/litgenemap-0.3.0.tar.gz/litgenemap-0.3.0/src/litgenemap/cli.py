from __future__ import annotations

import argparse

from .io import DEFAULT_TEXT_COLUMNS
from .pipeline import run_pipeline


class SmartFormatter(argparse.ArgumentDefaultsHelpFormatter, argparse.RawTextHelpFormatter):
    """Formatter that preserves newlines and appends defaults."""


TOP_LEVEL_DESCRIPTION = (
    "Extract genes from literature tables and perform frequency, co-occurrence, "
    "or full network analysis."
)

RUN_DESCRIPTION = """Run the main LitGeneMap pipeline.

Minimum required literature columns:
  - title
  - abstract

Default analyzed text columns:
  - title
  - abstract
  - keyword

Default blacklist behavior:
  - A built-in blacklist of highly ambiguous terms is applied automatically
  - Use --blacklist to add your own blocked terms
  - Use --no-default-blacklist to disable the built-in blacklist

Supported literature file formats:
  - .xlsx
  - .csv
  - .tsv

Accepted column aliases are mapped automatically when possible:
  title         <- title / TI / TI_raw
  abstract      <- abstract / AB / AB_raw
  keyword       <- keyword / keywords / author_keywords / DE / DE_raw
  keywords_plus <- keywords_plus / ID
  year          <- year / PY
  doi           <- doi / DI

Notes:
  - Human HGNC input can be downloaded from https://www.genenames.org/
  - Literature tables exported from the R package bibliometrix are recommended,
    but any table with title and abstract columns can be used.
"""

RUN_EPILOG = """Examples:
  Human HGNC, full analysis
    litgenemap run --literature my_literature.xlsx --genes hgnc_complete_set.txt --gene-input hgnc --output results/

  Custom species dictionary, full analysis
    litgenemap run --literature my_literature.csv --genes rice_dictionary.csv --gene-input dictionary --output results_rice/

  Frequency only
    litgenemap run --literature my_literature.xlsx --genes hgnc_complete_set.txt --gene-input hgnc --analysis-level frequency --output results_freq/

  Use a blacklist for ambiguous terms
    litgenemap run --literature my_literature.xlsx --genes hgnc_complete_set.txt --gene-input hgnc --blacklist blacklist.txt --output results_clean/

  Disable the built-in default blacklist
    litgenemap run --literature my_literature.xlsx --genes hgnc_complete_set.txt --gene-input hgnc --no-default-blacklist --output results_raw/
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="litgenemap",
        description=TOP_LEVEL_DESCRIPTION,
        formatter_class=SmartFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser(
        "run",
        help="Run gene extraction and bibliometric analysis",
        description=RUN_DESCRIPTION,
        epilog=RUN_EPILOG,
        formatter_class=SmartFormatter,
    )
    run_parser.add_argument(
        "--literature",
        required=True,
        help=(
            "Path to literature table (.xlsx/.csv/.tsv). Minimum required columns: "
            "title and abstract. bibliometrix/WoS-style column aliases are auto-mapped."
        ),
    )
    run_parser.add_argument(
        "--genes",
        required=True,
        help=(
            "Path to gene input file. Use HGNC complete set for --gene-input hgnc, "
            "or a custom mapping table for --gene-input dictionary."
        ),
    )
    run_parser.add_argument(
        "--gene-input",
        choices=["hgnc", "dictionary"],
        default="hgnc",
        help=(
            "Gene input type. hgnc: human HGNC raw table; dictionary: custom mapping "
            "table with at least raw_term and standard_symbol columns."
        ),
    )
    run_parser.add_argument(
        "--output",
        required=True,
        help="Output directory. Created automatically if it does not exist.",
    )
    run_parser.add_argument(
        "--text-columns",
        nargs="+",
        default=list(DEFAULT_TEXT_COLUMNS),
        help=(
            "Text columns to search for gene terms. Missing optional columns are skipped. "
            "title and abstract should always be present."
        ),
    )
    run_parser.add_argument(
        "--analysis-level",
        choices=["frequency", "cooccurrence", "full"],
        default="full",
        help=(
            "Analysis depth. frequency: gene hits, matrix, frequency table, and temporal "
            "metrics when year is available; cooccurrence: add gene-gene co-occurrence; "
            "full: add network edges, modules, and evidence scores."
        ),
    )
    run_parser.add_argument(
        "--blacklist",
        help=(
            "Optional blacklist file (.txt/.csv/.xlsx). One blocked gene symbol or term per "
            "row or line. A built-in default blacklist of highly ambiguous terms is applied "
            "automatically; this option adds user-defined blocked values on top of it."
        ),
    )
    run_parser.add_argument(
        "--no-default-blacklist",
        action="store_true",
        help=(
            "Disable the built-in default blacklist of highly ambiguous terms. "
            "Use this only when you need raw matching behavior."
        ),
    )

    run_parser.add_argument(
        "--edge-metric",
        choices=["sqrt", "raw", "jaccard"],
        default="sqrt",
        help=(
            "Edge weighting method for network construction. sqrt: cooccur/sqrt(freq1*freq2); "
            "raw: raw co-occurrence count; jaccard: intersection/union."
        ),
    )
    run_parser.add_argument(
        "--edge-threshold",
        type=float,
        default=0.15,
        help=(
            "Minimum edge weight retained in the network stage. Applies to full analysis only."
        ),
    )
    run_parser.add_argument(
        "--min-term-length",
        type=int,
        default=2,
        help=(
            "Minimum length allowed for a matched term when building the searchable dictionary."
        ),
    )
    run_parser.add_argument(
        "--keep-non-approved",
        action="store_true",
        help=(
            "HGNC mode only. Keep genes whose HGNC status is not approved. Ignored for "
            "--gene-input dictionary."
        ),
    )
    run_parser.add_argument(
        "--keep-non-protein-coding",
        action="store_true",
        help=(
            "HGNC mode only. Keep non-protein-coding entries. Ignored for --gene-input dictionary."
        ),
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.command == "run":
        run_pipeline(
            literature_file=args.literature,
            gene_file=args.genes,
            output_dir=args.output,
            gene_input=args.gene_input,
            text_columns=args.text_columns,
            analysis_level=args.analysis_level,
            blacklist_file=args.blacklist,
            use_default_blacklist=not args.no_default_blacklist,
            edge_metric=args.edge_metric,
            edge_threshold=args.edge_threshold,
            approved_only=not args.keep_non_approved,
            protein_coding_only=not args.keep_non_protein_coding,
            min_term_length=args.min_term_length,
        )


if __name__ == "__main__":
    main()
