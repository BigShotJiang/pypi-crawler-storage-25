from __future__ import annotations

import math

import networkx as nx
import pandas as pd
from community import community_louvain


ALLOWED_EDGE_METRICS = {"sqrt", "raw", "jaccard"}


def build_gene_network(
    freq_df: pd.DataFrame,
    cooc_df: pd.DataFrame,
    *,
    edge_metric: str = "sqrt",
    edge_threshold: float = 0.15,
) -> tuple[nx.Graph, pd.DataFrame]:
    if edge_metric not in ALLOWED_EDGE_METRICS:
        raise ValueError(f"edge_metric must be one of {sorted(ALLOWED_EDGE_METRICS)}")

    freq_dict = dict(zip(freq_df["gene_symbol"], freq_df["article_count"])) if not freq_df.empty else {}
    edge_table = cooc_df.copy()

    def compute_weight(row: pd.Series) -> float:
        g1, g2, c = row["gene1"], row["gene2"], row["cooccur_article_count"]
        f1 = max(freq_dict.get(g1, 1), 1)
        f2 = max(freq_dict.get(g2, 1), 1)
        if edge_metric == "raw":
            return float(c)
        if edge_metric == "jaccard":
            denom = f1 + f2 - c
            return float(c / denom) if denom else 0.0
        return float(c / math.sqrt(f1 * f2))

    G = nx.Graph()
    if not freq_df.empty:
        for _, row in freq_df.iterrows():
            G.add_node(
                row["gene_symbol"],
                article_count=row["article_count"],
                total_mentions=row.get("total_mentions", 0),
            )

    if edge_table.empty:
        return G, edge_table

    edge_table["weight"] = edge_table.apply(compute_weight, axis=1)
    edge_table = edge_table[edge_table["weight"] >= edge_threshold].copy().reset_index(drop=True)

    for _, row in edge_table.iterrows():
        G.add_edge(
            row["gene1"],
            row["gene2"],
            weight=row["weight"],
            cooccur_article_count=row["cooccur_article_count"],
        )
    return G, edge_table


def detect_modules(graph: nx.Graph, *, resolution: float = 1.0) -> pd.DataFrame:
    if graph.number_of_nodes() == 0:
        return pd.DataFrame(columns=["gene_symbol", "module"])
    if graph.number_of_edges() == 0:
        return pd.DataFrame({"gene_symbol": list(graph.nodes()), "module": list(range(graph.number_of_nodes()))})
    partition = community_louvain.best_partition(graph, weight="weight", resolution=resolution)
    return pd.DataFrame({"gene_symbol": list(partition.keys()), "module": list(partition.values())})


def _zscore(series: pd.Series) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce").fillna(0)
    std = s.std(ddof=0)
    if std == 0:
        return pd.Series([0.0] * len(s), index=s.index)
    return (s - s.mean()) / std


def score_genes(freq_df: pd.DataFrame, module_df: pd.DataFrame, graph: nx.Graph) -> pd.DataFrame:
    gene_table = freq_df.merge(module_df, on="gene_symbol", how="left")
    degree_dict = dict(graph.degree(weight="weight")) if graph.number_of_nodes() else {}
    betweenness_dict = nx.betweenness_centrality(graph, weight="weight") if graph.number_of_nodes() else {}
    gene_table["degree"] = gene_table["gene_symbol"].map(degree_dict).fillna(0.0)
    gene_table["betweenness"] = gene_table["gene_symbol"].map(betweenness_dict).fillna(0.0)
    gene_table["evidence_score"] = (
        0.35 * _zscore(gene_table["article_count"])
        + 0.25 * _zscore(gene_table["total_mentions"])
        + 0.25 * _zscore(gene_table["degree"])
        + 0.15 * _zscore(gene_table["betweenness"])
    )
    return gene_table.sort_values(["module", "evidence_score"], ascending=[True, False]).reset_index(drop=True)
