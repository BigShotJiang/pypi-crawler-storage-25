from dataclasses import dataclass, field

@dataclass(slots=True)
class ExperimentSession:
    setup: ExperimentSetup
    frames: list[int] = field(default_factory=list)

    def apply_frame(self, frame_id: int, scanner_pose: CS3D, camera_poses: dict[str, CS3D]) -> None:
        self.frames.append(frame_id)
        self.setup.set_scanner_pose(scanner_pose)
        for name, pose in camera_poses.items():
            self.setup.set_camera_pose(name, pose)
