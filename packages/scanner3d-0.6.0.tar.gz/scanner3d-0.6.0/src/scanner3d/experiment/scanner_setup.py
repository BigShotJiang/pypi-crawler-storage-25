from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping
from scanner3d.scanner.scanner import Scanner

@dataclass(frozen=True, slots=True)
class ScannerSetup:
    """Связка 'описание сканера' + 'установка в пространстве'."""
    scanner: Scanner
    rig: Rig
    camera_spaces: Mapping[str, Space]  # имя камеры -> space в rig

    @property
    def graph(self) -> TransformGraph:
        return self.rig.graph

    def world_to_camera(self, cam_name: str):
        cam_sp = self.camera_spaces[cam_name]
        return self.graph.world_to(cam_sp)

    def between_cameras(self, a: str, b: str):
        return self.graph.between(self.camera_spaces[a], self.camera_spaces[b])
