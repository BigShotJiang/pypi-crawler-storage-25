from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping

@dataclass(slots=True)
class ExperimentSetup:
    scanner: Scanner
    rig: Rig
    scanner_space: Space
    camera_spaces: Mapping[str, Space]

    # IDs/ключи для линков, которые мы хотим менять во время эксперимента
    link_world_to_scanner: str
    link_scanner_to_camera: Mapping[str, str]  # cam_name -> link_id

    def set_scanner_pose(self, cs_world_to_scanner: CS3D) -> None:
        """Движение сканера в мировом пространстве."""
        self.rig.graph.set_link_cs(self.link_world_to_scanner, cs_world_to_scanner)

    def set_camera_pose(self, cam_name: str, cs_scanner_to_camera: CS3D) -> None:
        """Калибровка/сдвиг отдельной камеры относительно базы сканера."""
        link_id = self.link_scanner_to_camera[cam_name]
        self.rig.graph.set_link_cs(link_id, cs_scanner_to_camera)

    def world_to_camera(self, cam_name: str):
        return self.rig.graph.world_to(self.camera_spaces[cam_name])
