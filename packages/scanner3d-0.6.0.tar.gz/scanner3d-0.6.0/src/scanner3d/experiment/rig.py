from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Tuple
from geopto.space.space import Space
from geopto.cs.cs_3d import CS3D
from geopto.space.transform_graph import TransformGraph
from geopto.space.fixed_link import FixedLink

@dataclass(slots=True)
class Rig:
    """
    Scene/installation object.
    Owns:
      - world space
      - graph of transforms
      - references to physical objects (scanner, cameras, etc.)
    Responsibility:
      - build/maintain TransformGraph from current configuration
    """
    world: Space
    graph: TransformGraph

    # optional: store your physical objects (keep as Any to not constrain)
    scanner: object | None = None
    cameras: Tuple[object, ...] = ()

    @classmethod
    def from_scanner_and_cameras(
        cls,
        *,
        scanner_space: Space,
        scanner_base_cs_world_to_scanner: CS3D,
        camera_items: Iterable[Tuple[Space, CS3D]],
        # camera_items: (camera_space, scanner_to_camera_cs)
        scanner_obj: object | None = None,
        camera_objs: Iterable[object] = (),
        world: Space | None = None,
    ) -> Rig:
        from geopto.space.space_kind import SpaceKind
        world_space = world or Space(kind=SpaceKind.WORLD, label="world")
        graph = TransformGraph(world=world_space)

        # world -> scanner
        graph.add_link(FixedLink(parent=world_space, child=scanner_space, cs=scanner_base_cs_world_to_scanner))

        # scanner -> each camera
        for cam_space, scanner_to_cam in camera_items:
            graph.add_link(FixedLink(parent=scanner_space, child=cam_space, cs=scanner_to_cam))

        return cls(
            world=world_space,
            graph=graph,
            scanner=scanner_obj,
            cameras=tuple(camera_objs))
