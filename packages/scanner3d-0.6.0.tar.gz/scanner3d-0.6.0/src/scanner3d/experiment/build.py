def build_experiment_setup(scanner: Scanner) -> ExperimentSetup:
    world = Space(kind=SpaceKind.WORLD, label="world")
    scanner_sp = Space(kind=SpaceKind.SCANNER, label=scanner.name)

    camera_spaces = {c.name: Space(kind=SpaceKind.CAMERA, label=c.name) for c in scanner.cameras}

    # graph:
    # world -> scanner_sp : scanner.base_cs
    # scanner_sp -> camera_sp : cam.position.cs

    rig = Rig.from_scanner_and_cameras(
        scanner_space=scanner_sp,
        scanner_base_cs_world_to_scanner=scanner.base_cs,
        camera_items=tuple((camera_spaces[c.name], c.position.cs) for c in scanner.cameras),
        scanner_obj=scanner,
        camera_objs=scanner.cameras,
        world=world,
    )

    return ExperimentSetup(
        scanner=scanner,
        rig=rig,
        scanner_space=scanner_sp,
        camera_spaces=camera_spaces,
        # + сохранить link_id для world->scanner и scanner->camera если хочешь менять их “ручками”
    )
