from __future__ import annotations
from dimetra.geo import Length, LengthUnit
from scanner3d.afs.album_settings.major_frames import MajorFramesAlbumSettings
from scanner3d.afs.album_settings.radial import RadialAlbumSettings
from scanner3d.afs.album_settings.sparse_grid import SparseGridAlbumSettings
from scanner3d.afs.album_settings.radila_focus_only import RadialFocusOnlyAlbumSettings



album_major_frames_5x5 = MajorFramesAlbumSettings(
    name="Major Frames 5x5",
    dx=5,
    dy=5,
    dz=None)

album_major_frames_3x3 = MajorFramesAlbumSettings(
    name="Major Frames 3x3",
    dx=3,
    dy=3,
    dz=None)

album_radial_detailed = RadialAlbumSettings(
    name="Radial Detailed 5 mm 50 um",
    dx=Length(50, LengthUnit.UM),
    dz=Length(5, LengthUnit.MM))

album_radial_coarse = RadialAlbumSettings(
    name="Radial Coarse 50 mm 500 um",
    dx=Length(500, LengthUnit.UM),
    dz=Length(50, LengthUnit.MM))

album_sparse_grid_detailed = SparseGridAlbumSettings(
    name="Sparse Grid Detailed",
    dx=50,
    dy=50,
    dz=Length(5, LengthUnit.MM))

album_sparse_grid_coarse = SparseGridAlbumSettings(
    name="Sparse Grid Coarse",
    dx=500,
    dy=500,
    dz=Length(50, LengthUnit.MM))

album_radial_focus_only = RadialFocusOnlyAlbumSettings(
    name="Radial Focus Only Δx=1000 um",
    dx=Length(1000, LengthUnit.UM))