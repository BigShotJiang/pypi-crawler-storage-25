from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
from dimetra.geo import LengthSeq
from scanner3d.afs.album_settings.album_template import AlbumTemplate
from scanner3d.afs.album_settings.album_types import AlbumTypes

TemplateFactory = Callable[..., AlbumTemplate]

@dataclass(frozen=True)
class AlbumTypeSpec:
    album_type: AlbumTypes
    factory: TemplateFactory
    has_fixed_axes: bool = False

    def make_template(
        self,
        *,
        x_axis: LengthSeq | None = None,
        y_axis: LengthSeq | None = None,
        z_axis: LengthSeq | None = None,
    ) -> AlbumTemplate:
        if self.has_fixed_axes:
            if x_axis is None or y_axis is None or z_axis is None:
                raise ValueError(f"{self.album_type.value}: x_axis, y_axis and z_axis are required")
            return self.factory(x_axis=x_axis, y_axis=y_axis, z_axis=z_axis)
        return self.factory()