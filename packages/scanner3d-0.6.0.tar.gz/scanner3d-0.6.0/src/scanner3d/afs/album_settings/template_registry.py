from __future__ import annotations
from scanner3d.afs.album_settings.album_template import AlbumTemplate
from scanner3d.afs.album_settings.album_type_spec import AlbumTypeSpec
from scanner3d.afs.album_settings.album_types import AlbumTypes
from scanner3d.afs.album_settings.axis_strategies import (
    FixedXAxis,
    FixedYAxis,
    FixedZ,
    Radial,
    SparseQuadrantX,
    SparseQuadrantY,
    WdSequence,
    X1dN,
    Y1dN,
    ZMajor, ZFocusOnly)

ALBUM_TYPES_REG: dict[AlbumTypes, AlbumTypeSpec] = {
    AlbumTypes.MAJOR_FRAMES: AlbumTypeSpec(
        album_type=AlbumTypes.MAJOR_FRAMES,
        factory=lambda: AlbumTemplate(
            x=X1dN(),
            y=Y1dN(),
            z=ZMajor(),
            save_image=True,
            save_h5=True)),
    AlbumTypes.RADIAL: AlbumTypeSpec(
        album_type=AlbumTypes.RADIAL,
        factory=lambda: AlbumTemplate(
            x=Radial(),
            y=None,
            z=WdSequence(),
            save_image=False,
            save_h5=True)),
    AlbumTypes.RADIAL_FOCUS_ONLY: AlbumTypeSpec(
        album_type=AlbumTypes.RADIAL,
        factory=lambda: AlbumTemplate(
            x=Radial(),
            y=None,
            z=ZFocusOnly(),
            save_image=False,
            save_h5=True)),
    AlbumTypes.SPARSE_GRID: AlbumTypeSpec(
        album_type=AlbumTypes.SPARSE_GRID,
        factory=lambda: AlbumTemplate(
            x=SparseQuadrantX(),
            y=SparseQuadrantY(),
            z=WdSequence(),
            save_image=False,
            save_h5=True)),
    AlbumTypes.FIELD_GRID_RECT: AlbumTypeSpec(
        album_type=AlbumTypes.FIELD_GRID_RECT,
        has_fixed_axes=True,
        factory=lambda x_axis, y_axis, z_axis: AlbumTemplate(
            x=FixedXAxis(x_axis),
            y=FixedYAxis(y_axis),
            z=FixedZ(z_axis),
            save_image=False,
            save_h5=True))}