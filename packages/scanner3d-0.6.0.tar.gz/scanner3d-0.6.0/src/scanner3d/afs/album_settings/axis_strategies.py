from __future__ import annotations
from dataclasses import dataclass
from dimetra.geo import Length, LengthSeq
from isensor.sensor import Grid
from scanner3d.geo.z_range import ZRange

@dataclass(frozen=True)
class X1dN:
    def build(self, g: Grid, step: object = None) -> LengthSeq:
        if not isinstance(step, int):
            raise TypeError("X1dN expects IndexStep (int)")
        return g.x1d_n(step)


@dataclass(frozen=True)
class Y1dN:
    def build(self, g: Grid, step: object = None) -> LengthSeq:
        if not isinstance(step, int):
            raise TypeError("Y1dN expects IndexStep (int)")
        return g.y1d_n(step)

@dataclass(frozen=True)
class Radial:
    def build(self, g: Grid, step: object = None) -> LengthSeq:
        if not isinstance(step, Length):
            raise TypeError("Radial expects PhysicalStep (Length)")
        return g.get_radial(step)

@dataclass(frozen=True)
class SparseQuadrantX:
    def build(self, g: Grid, step: object = None) -> LengthSeq:
        if not isinstance(step, int):
            raise TypeError("SparseQuadrantX expects int")
        return g.sparse_quadrant(step)[0]

@dataclass(frozen=True)
class SparseQuadrantY:
    def build(self, g: Grid, step: object = None) -> LengthSeq:
        if not isinstance(step, int):
            raise TypeError("SparseQuadrantY expects int")
        return g.sparse_quadrant(step)[1]

@dataclass(frozen=True)
class ZFocusOnly:
    def build(self, zr: ZRange, step: object = None) -> LengthSeq: return zr.focus_only()


@dataclass(frozen=True)
class ZMajor:
    def build(self, zr: ZRange, step: object = None) -> LengthSeq: return zr.major_sequence()

@dataclass(frozen=True)
class WdSequence:
    def build(self, zr: ZRange, step: object = None) -> LengthSeq:
        if step is not None and not isinstance(step, Length):
            raise TypeError("WdSequence expects Length | None")
        return zr.wd_sequence(step)

@dataclass(frozen=True)
class FixedXAxis:
    values: LengthSeq
    def build(self, g: Grid, step: object = None) -> LengthSeq: return self.values

@dataclass(frozen=True)
class FixedYAxis:
    values: LengthSeq
    def build(self, g: Grid, step: object = None) -> LengthSeq: return self.values

@dataclass(frozen=True)
class FixedZ:
    values: LengthSeq
    def build(self, zr: ZRange, step: object = None) -> LengthSeq: return self.values