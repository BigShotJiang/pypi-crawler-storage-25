from __future__ import annotations
from dataclasses import dataclass
from typing import ClassVar
from dimetra.geo import Length, LengthSeq
from isensor.sensor import Grid
from scanner3d.afs.album_settings.album_types import AlbumTypes
from scanner3d.afs.album_settings.typed import TypedAlbumSettings
from scanner3d.geo.z_range import ZRange


@dataclass(frozen=True)
class RadialFocusOnlyAlbumSettings(TypedAlbumSettings):
    dx: Length

    ALBUM_TYPE: ClassVar[AlbumTypes] = AlbumTypes.RADIAL_FOCUS_ONLY

    def get_x_seq(self, grid: Grid) -> LengthSeq:
        return self.template.build_x(grid, self.dx)

    def get_y_seq(self, grid: Grid) -> LengthSeq | None:
        return None

    def get_z_seq(self, z_range: ZRange) -> LengthSeq:
        return self.template.build_z(z_range)