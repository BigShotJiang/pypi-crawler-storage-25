from __future__ import annotations
from typing import Protocol
from dimetra.geo import LengthSeq
from isensor.sensor import Grid
from scanner3d.geo.z_range import ZRange

class XAxisStrategy(Protocol):
    def build(self, g: Grid, step: object = None) -> LengthSeq: ...

class YAxisStrategy(Protocol):
    def build(self, g: Grid, step: object = None) -> LengthSeq: ...

class ZAxisStrategy(Protocol):
    def build(self, zr: ZRange, step: object = None) -> LengthSeq: ...