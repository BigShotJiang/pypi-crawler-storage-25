from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from dimetra.geo import LengthSeq
from isensor.sensor import Grid
from scanner3d.afs.album_settings.album_template import AlbumTemplate
from scanner3d.geo.z_range import ZRange

@dataclass(frozen=True)
class AlbumSettings(ABC):
    name: str
    template: AlbumTemplate = field(init=False)

    @property
    def enable_image_save(self) -> bool:
        return self.template.save_image

    @property
    def enable_h5_save(self) -> bool:
        return self.template.save_h5

    @abstractmethod
    def get_x_seq(self, grid: Grid) -> LengthSeq:
        raise NotImplementedError

    @abstractmethod
    def get_y_seq(self, grid: Grid) -> LengthSeq:
        raise NotImplementedError

    @abstractmethod
    def get_z_seq(self, z_range: ZRange) -> LengthSeq:
        raise NotImplementedError