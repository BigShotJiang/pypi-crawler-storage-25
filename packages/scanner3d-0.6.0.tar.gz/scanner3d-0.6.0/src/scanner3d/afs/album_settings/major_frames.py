from __future__ import annotations
from dataclasses import dataclass
from typing import ClassVar
from scanner3d.afs.album_settings.album_types import AlbumTypes
from scanner3d.afs.album_settings.xy_index import XYIndexAlbumSettings


@dataclass (frozen=True)
class MajorFramesAlbumSettings(XYIndexAlbumSettings):
    ALBUM_TYPE: ClassVar[AlbumTypes] = AlbumTypes.MAJOR_FRAMES
