from __future__ import annotations
from abc import ABC
from dataclasses import dataclass
from dimetra.geo import Length, LengthSeq
from isensor.sensor import Grid
from scanner3d.afs.album_settings.typed import TypedAlbumSettings
from scanner3d.geo.z_range import ZRange


@dataclass(frozen=True)
class XYIndexAlbumSettings(TypedAlbumSettings, ABC):
    dx: int
    dy: int
    dz: Length | None

    def get_x_seq(self, grid: Grid) -> LengthSeq:
        return self.template.build_x(grid, self.dx)

    def get_y_seq(self, grid: Grid) -> LengthSeq | None:
        return self.template.build_y(grid, self.dy)

    def get_z_seq(self, z_range: ZRange) -> LengthSeq:
        return self.template.build_z(z_range, self.dz)