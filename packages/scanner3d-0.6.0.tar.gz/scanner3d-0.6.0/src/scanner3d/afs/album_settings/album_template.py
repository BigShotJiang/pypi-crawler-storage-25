from __future__ import annotations
from dataclasses import dataclass
from dimetra.geo import LengthSeq
from isensor.sensor import Grid
from scanner3d.geo.z_range import ZRange
from scanner3d.afs.album_settings.axis_strategies_protocol import XAxisStrategy, YAxisStrategy, ZAxisStrategy

@dataclass(frozen=True)
class AlbumTemplate:
    x: XAxisStrategy
    y: YAxisStrategy | None
    z: ZAxisStrategy
    save_image: bool
    save_h5: bool

    def build_x(self, g: Grid, step: object = None) -> LengthSeq:
        return self.x.build(g, step)

    def build_y(self, g: Grid, step: object = None) -> LengthSeq | None:
        if self.y is None:
            return None
        return self.y.build(g, step)

    def build_z(self, zr: ZRange, step: object = None) -> LengthSeq:
        return self.z.build(zr, step)