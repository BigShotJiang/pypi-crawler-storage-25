from __future__ import annotations

from enum import Enum


class AlbumTypes(str, Enum):
    MAJOR_FRAMES = "major_frames"
    RADIAL = "radial"
    SPARSE_GRID = "sparse_grid"
    FIELD_GRID_RECT = "field_grid_rect"
    RADIAL_FOCUS_ONLY = "radial Z in focus only"
