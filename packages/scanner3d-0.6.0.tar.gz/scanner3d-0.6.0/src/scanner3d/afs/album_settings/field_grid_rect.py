from __future__ import annotations
from dataclasses import dataclass
from typing import ClassVar
from dimetra.geo import LengthSeq
from isensor.sensor import Grid
from scanner3d.afs.album_settings.album_types import AlbumTypes
from scanner3d.afs.album_settings.template_registry import ALBUM_TYPES_REG
from scanner3d.afs.album_settings.typed import TypedAlbumSettings
from scanner3d.geo.z_range import ZRange


@dataclass(frozen=True)
class FieldGridRectAlbumSettings(TypedAlbumSettings):
    x_axis: LengthSeq
    y_axis: LengthSeq
    z_axis: LengthSeq

    ALBUM_TYPE: ClassVar[AlbumTypes] = AlbumTypes.FIELD_GRID_RECT

    def __post_init__(self) -> None:
        template = ALBUM_TYPES_REG[self.ALBUM_TYPE].make_template(
            x_axis=self.x_axis,
            y_axis=self.y_axis,
            z_axis=self.z_axis,
        )
        object.__setattr__(self, "template", template)

    def get_x_seq(self, grid: Grid) -> LengthSeq:
        return self.template.build_x(grid)

    def get_y_seq(self, grid: Grid) -> LengthSeq | None:
        return self.template.build_y(grid)

    def get_z_seq(self, z_range: ZRange) -> LengthSeq:
        return self.template.build_z(z_range)