from __future__ import annotations
from abc import ABC
from dataclasses import dataclass
from typing import ClassVar
from scanner3d.afs.album_settings.album_settings import AlbumSettings
from scanner3d.afs.album_settings.album_types import AlbumTypes
from scanner3d.afs.album_settings.template_registry import ALBUM_TYPES_REG


@dataclass(frozen=True)
class TypedAlbumSettings(AlbumSettings, ABC):
    ALBUM_TYPE: ClassVar[AlbumTypes]

    def __post_init__(self) -> None:
        template = ALBUM_TYPES_REG[self.ALBUM_TYPE].make_template()
        object.__setattr__(self, "template", template)