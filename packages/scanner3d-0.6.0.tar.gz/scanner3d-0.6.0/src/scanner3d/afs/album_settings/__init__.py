from __future__ import annotations
from scanner3d.afs.album_settings.album_settings import AlbumSettings
from scanner3d.afs.album_settings.album_type_spec import AlbumTypeSpec
from scanner3d.afs.album_settings.album_types import AlbumTypes
from scanner3d.afs.album_settings.field_grid_rect import FieldGridRectAlbumSettings
from scanner3d.afs.album_settings.major_frames import MajorFramesAlbumSettings
from scanner3d.afs.album_settings.presets import (
    album_major_frames_3x3,
    album_major_frames_5x5,
    album_radial_coarse,
    album_radial_detailed,
    album_sparse_grid_coarse,
    album_sparse_grid_detailed,
    album_radial_focus_only
)
from scanner3d.afs.album_settings.radial import RadialAlbumSettings
from scanner3d.afs.album_settings.sparse_grid import SparseGridAlbumSettings
from scanner3d.afs.album_settings.template_registry import ALBUM_TYPES_REG
from scanner3d.afs.album_settings.typed import TypedAlbumSettings
from scanner3d.afs.album_settings.xy_index import XYIndexAlbumSettings

__all__ = [
    "album_major_frames_3x3",
    "album_major_frames_5x5",
    "album_radial_coarse",
    "album_radial_detailed",
    "album_sparse_grid_coarse",
    "album_sparse_grid_detailed",
    "album_radial_focus_only",
    "ALBUM_TYPES_REG",
    "AlbumSettings",
    "AlbumTypeSpec",
    "AlbumTypes",
    "FieldGridRectAlbumSettings",
    "MajorFramesAlbumSettings",
    "RadialAlbumSettings",
    "SparseGridAlbumSettings",
    "TypedAlbumSettings",
    "XYIndexAlbumSettings",
    ]