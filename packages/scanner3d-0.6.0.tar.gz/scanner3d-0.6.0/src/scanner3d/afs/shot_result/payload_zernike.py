from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from numpy.typing import NDArray
from zemod.iar.zernike import ZernikeMeta


@dataclass(slots=True)
class PayloadZernike:
    coefficients: NDArray[np.float64]
    meta: ZernikeMeta

    def __post_init__(self) -> None:
        self.coefficients = np.asarray(self.coefficients, dtype=float)