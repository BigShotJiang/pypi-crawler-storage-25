from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from scanner3d.afs.shot_result.payload_analysis import PaylodAnalysis


class ShotResultArray:
    __slots__ = ("_payload",)

    def __init__(self, payload: PaylodAnalysis) -> None:
        self._payload = payload

    @classmethod
    def from_native_result(cls, native_result) -> ShotResultArray:
        return cls(
            PaylodAnalysis(
                values=np.asarray(native_result.get_raw(), dtype=float),
                metas=[native_result.meta],
            )
        )

    @property
    def payload(self) -> PaylodAnalysis:
        return self._payload

    @property
    def metas(self):
        if not self._payload.metas:
            return None
        if len(self._payload.metas) == 1:
            return self._payload.metas[0]
        return self._payload.metas

    @property
    def meta(self):
        if not self._payload.metas:
            return None
        return self._payload.metas[0]

    def preview(self) -> NDArray[np.float64]:
        return self._payload.values

    @property
    def preview_shape(self) -> tuple[int, ...]:
        return self._payload.values.shape

    def finite_min(self) -> float:
        arr = self._payload.values
        vals = arr[np.isfinite(arr)]
        return float(np.nanmin(vals)) if vals.size else float("nan")

    def finite_max(self) -> float:
        arr = self._payload.values
        vals = arr[np.isfinite(arr)]
        return float(np.nanmax(vals)) if vals.size else float("nan")