from __future__ import annotations
import numpy as np
from numpy.typing import NDArray
from allytools.types import validate_cast
from zemod.iar.zernike import ZernikeData
from scanner3d.afs.shot_result.payload_zernike import PayloadZernike


class ShotResultZernike:
    __slots__ = ("_payload",)

    def __init__(self, payload: PayloadZernike) -> None:
        self._payload = payload

    @classmethod
    def from_native_result(cls, native_result) -> ShotResultZernike:
        zernike_data = validate_cast(native_result, ZernikeData)
        return cls(
            PayloadZernike(
                coefficients=np.asarray(zernike_data.get_coefficients(), dtype=float),
                meta=native_result.meta))

    @property
    def payload(self) -> PayloadZernike:
        return self._payload

    @property
    def meta(self):
        return self._payload.meta

    @property
    def metas(self):
        return self._payload.meta

    def preview(self) -> NDArray[np.float64]:
        return self._payload.coefficients

    @property
    def preview_shape(self) -> tuple[int, ...]:
        return self._payload.coefficients.shape

    def finite_min(self) -> float:
        arr = self._payload.coefficients
        vals = arr[np.isfinite(arr)]
        return float(np.nanmin(vals)) if vals.size else float("nan")

    def finite_max(self) -> float:
        arr = self._payload.coefficients
        vals = arr[np.isfinite(arr)]
        return float(np.nanmax(vals)) if vals.size else float("nan")