from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from gosti.batch_raytrace.ray_batch import RayBatch


class ShotResultRayBatch:
    __slots__ = ("_batch",)

    def __init__(self, batch: RayBatch) -> None:
        self._batch = batch

    @property
    def payload(self) -> RayBatch:
        return self._batch

    @property
    def metas(self):
        return None

    @property
    def meta(self):
        return None

    def preview(self) -> NDArray[np.float64]:
        return np.empty((0,), dtype=float)

    @property
    def preview_shape(self) -> tuple[int, ...]:
        return (0,)

    def finite_min(self) -> float:
        return float("nan")

    def finite_max(self) -> float:
        return float("nan")