from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import numpy as np
from numpy.typing import NDArray


@dataclass(slots=True)
class PaylodAnalysis:
    values: NDArray[np.float64]
    metas: list[Any]

    def __post_init__(self) -> None:
        self.values = np.asarray(self.values, dtype=float)

        if self.metas is None:
            self.metas = []
        elif isinstance(self.metas, list):
            pass
        elif isinstance(self.metas, tuple):
            self.metas = list(self.metas)
        else:
            self.metas = [self.metas]