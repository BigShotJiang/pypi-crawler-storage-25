from __future__ import annotations

from collections.abc import Sequence
from typing import Any
import numpy as np
from dimetra.geo import LengthSeq
from scanner3d.afs.shot.shot import Shot
from scanner3d.afs.shot.shot_factory import shot_result_from_payload


class Shots:
    __slots__ = ("_items", "_values")

    def __init__(self, *, items: list[Shot], _internal: bool = False) -> None:
        if not _internal:
            raise RuntimeError("Direct construction of Shots is not allowed. Use from_list() or from_components().")
        if not items:
            raise ValueError("Shots must contain at least one Shot")

        shapes = {shot.raw_data.shape for shot in items}
        if len(shapes) != 1:
            raise ValueError(f"All shots in Shots must have the same raw_data.shape, got: {shapes}")

        self._items = list(items)
        self._values = np.stack([np.asarray(shot.raw_data, dtype=float) for shot in self._items])

    @classmethod
    def from_list(cls, items: list[Shot]) -> Shots:
        return cls(items=items, _internal=True)

    @classmethod
    def from_components(
        cls,
        *,
        payloads: list[Any],
        field_x_seq: LengthSeq,
        field_y_seq: LengthSeq,
    ) -> Shots:
        n = len(payloads)
        if len(field_x_seq) != n:
            raise ValueError(f"Expected {n} field_x values, got {len(field_x_seq)}")
        if len(field_y_seq) != n:
            raise ValueError(f"Expected {n} field_y values, got {len(field_y_seq)}")

        items: list[Shot] = []
        for payload, x, y in zip(payloads, field_x_seq, field_y_seq):
            result = shot_result_from_payload(payload)
            items.append(Shot.from_components(result=result, field_x=x, field_y=y))
        return cls(items=items, _internal=True)

    @property
    def items(self) -> Sequence[Shot]:
        return tuple(self._items)

    @property
    def values(self):
        return self._values

    @property
    def payloads(self) -> list[Any]:
        return [shot.payload for shot in self._items]

    @property
    def field_x_seq(self) -> LengthSeq:
        return LengthSeq.from_lengths([shot.field_x for shot in self._items])

    @property
    def field_y_seq(self) -> LengthSeq:
        return LengthSeq.from_lengths([shot.field_y for shot in self._items])

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, idx: int) -> Shot:
        return self._items[idx]