from __future__ import annotations

from typing import Any, Protocol, runtime_checkable
from numpy.typing import NDArray
import numpy as np


@runtime_checkable
class ShotResultLike(Protocol):
    @property
    def payload(self) -> Any:
        """Canonical full payload object to serialize for this shot."""
        ...

    def preview(self) -> NDArray[np.float64]:
        """
        Numeric preview used only for frame stats / lightweight runtime operations.
        For payloads without a natural numeric preview, this may be an empty array.
        """
        ...

    @property
    def preview_shape(self) -> tuple[int, ...]:
        ...

    def finite_min(self) -> float:
        ...

    def finite_max(self) -> float:
        ...

    @property
    def metas(self) -> Any:
        ...

    @property
    def meta(self) -> Any:
        ...
