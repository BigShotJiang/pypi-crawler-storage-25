from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from numpy.typing import NDArray

@dataclass(frozen=True, slots=True)
class ShotView:
    data: NDArray[np.float64]

    def __post_init__(self):
        object.__setattr__(self, "data", np.asarray(self.data, dtype=float))

    @property
    def shape(self) -> tuple[int, ...]:
        return self.data.shape

    @property
    def finite_min(self) -> float:
        vals = self.data[np.isfinite(self.data)]
        return float(np.nanmin(vals)) if vals.size else float("nan")

    @property
    def finite_max(self) -> float:
        vals = self.data[np.isfinite(self.data)]
        return float(np.nanmax(vals)) if vals.size else float("nan")