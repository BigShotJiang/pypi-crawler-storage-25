from __future__ import annotations
from typing import cast, Any
from numpy.typing import NDArray
from zemod.iar.grid_meta import GridMeta
from zemod.iar.data_grid.data_grid import DataGrid
from zemod.iar.base import AnalysisResultMetaLike, AnalysisResultLike
from zemod.iar.zernike import ZernikeMeta, ZernikeData
from gosti.batch_raytrace.ray_batch import RayBatch
from scanner3d.afs.shot_result.payload_analysis import PaylodAnalysis
from scanner3d.afs.shot_result.payload_zernike import PayloadZernike
from scanner3d.afs.shot_result.shot_result_array import ShotResultArray
from scanner3d.afs.shot_result.shot_result_ray_batch import ShotResultRayBatch
from scanner3d.afs.shot_result.shot_result_zernike import ShotResultZernike


def shot_result_from_raw_and_meta(
    raw: NDArray,
    meta: AnalysisResultMetaLike,
) -> AnalysisResultLike[AnalysisResultMetaLike]:
    if isinstance(meta, GridMeta):
        result = DataGrid.from_components(raw, cast(GridMeta, meta))
        return cast(AnalysisResultLike[AnalysisResultMetaLike], result)

    if isinstance(meta, ZernikeMeta):
        result = ZernikeData.from_components(coefficients=raw, meta=meta)
        return cast(AnalysisResultLike[AnalysisResultMetaLike], result)
    raise TypeError(f"Unsupported meta type {type(meta)!r}; no factory registered().")

def shot_result_from_payload(payload: Any):
    if isinstance(payload, PaylodAnalysis):
        return ShotResultArray(payload)

    if isinstance(payload, PayloadZernike):
        return ShotResultZernike(payload)

    if isinstance(payload, RayBatch):
        return ShotResultRayBatch(payload)

    raise TypeError(f"Unsupported payload type {type(payload)!r}")