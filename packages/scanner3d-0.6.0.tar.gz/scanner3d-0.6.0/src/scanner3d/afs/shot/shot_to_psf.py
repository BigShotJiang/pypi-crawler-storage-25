from allytools.logger import get_logger
from gosti.wavelength import Wavelength
from scanner3d.afs.shot import Shot
from gosti.psf import PSF, PsfBuilder
from zemod.iar.i_grid_meta import IGridMeta
from allytools.types import validate_cast

log = get_logger(__name__)

#connection between Gosti PSF and Shot for Scanner3DTest
def shot_to_psf(
        *,
        shot: Shot, wavelength: Wavelength) -> PSF:
    meta:IGridMeta = validate_cast(shot.meta,IGridMeta)
    psf = PsfBuilder.from_physical_grid(
        values=shot.raw_data,
        field_x=shot.field_x,
        field_y=shot.field_y,
        min_x=meta.min_x,
        min_y=meta.min_y,
        dx=meta.dx,
        dy=meta.dy,
        wavelength=wavelength)
    log.debug(" FFT PSF created from Shot: shape=%s",shot.shape)
    return psf
