from __future__ import annotations
import logging
from typing import TYPE_CHECKING
from numpy.typing import NDArray
from dimetra.geo import Length
from scanner3d.analysis.analysis_definition.analysis_definition import AnalysisDefinition
from zemod.iar.i_grid_meta import IGridMeta
from scanner3d.afs.shot_result.shot_result_like import ShotResultLike

if TYPE_CHECKING:
    from zemod.zemod import ZeMod
    from zemod.zemod_field import ZeModField

log = logging.getLogger(__name__)
class Shot:
    __slots__ = ("_result", "_field_x", "_field_y")

    def __init__(
        self,
        *,
        result: ShotResultLike,
        field_x: Length,
        field_y: Length,
        _internal: bool = False,
    ) -> None:
        if not _internal:
            raise RuntimeError("Direct construction of Shot is not allowed."
                "Use compute(...) to calculate it from Zemax, "
                "or from_components() to reconstruct it.")
        self._result = result
        self._field_x = field_x
        self._field_y = field_y

    @classmethod
    def from_components(cls, *, result: ShotResultLike, field_x: Length, field_y: Length) -> Shot:
        return cls(result=result, field_x=field_x, field_y=field_y, _internal=True)

    @classmethod
    def compute(cls, *, zemod: ZeMod, zemod_field: ZeModField, analysis_def: AnalysisDefinition, x: Length, y: Length) -> Shot:
        xf = float(x.value_mm)
        yf = float(y.value_mm)
        zemod_field.set_xy(xf, yf)
        log.debug("field set x=%s, y=%s", xf, yf)
        with analysis_def.get_resource(zemod) as zemod_resource:
            analysis_def.configure(zemod_resource, zemod)
            raw_result = analysis_def.run(zemod_resource)
            shot_result = analysis_def.get_result(raw_result)
        return cls(result=shot_result, field_x=x, field_y=y, _internal=True)

    @property
    def field_x(self) -> Length:
        return self._field_x

    @property
    def field_y(self) -> Length:
        return self._field_y

    @property
    def result(self) -> ShotResultLike:
        return self._result

    @property
    def payload(self):
        return self._result.payload

    @property
    def meta(self):
        return self._result.meta

    @property
    def raw_data(self) -> NDArray:
        return self._result.preview()

    @property
    def shape(self) -> tuple[int, ...]:
        return self._result.preview_shape

    @property
    def min(self) -> float:
        return self._result.finite_min()

    @property
    def max(self) -> float:
        return self._result.finite_max()

    def plot(self, *args, **kwargs):
        if not isinstance(self.meta, IGridMeta):
            raise RuntimeError(
                "plot() is only available for grid results (IDataGrid). "
                "This Shot contains a non-grid result."
            )
        from scanner3d.afs.shot.plot_shot import plot_shot
        return plot_shot(self, *args, **kwargs)

    def __str__(self) -> str:
        return (
            "📸Shot\n"
            "────────────────────────────\n"
            f"  field: x={self.field_x.value_mm:.2f} [mm], y={self.field_y.value_mm:.2f} [mm],\n"
            f"  shape={self.shape}, min={self.min:.4g}, max={self.max:.4g}\n")