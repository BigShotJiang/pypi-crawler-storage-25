from __future__ import annotations
from dimetra.geo import  Length, LengthUnit
from typing import Optional, Tuple, TYPE_CHECKING
from imagera.plotter import PltScalar2d, PlotParameters, CMaps
from imagera.image import ImageBundle


if TYPE_CHECKING:
    from scanner3d.afs.shot.shot import Shot

def plot_shot(
    shot: Shot,
    plot_params: Optional[PlotParameters] = None,
    *,
    plot_label: str | None = None,
    cmap=CMaps.JET,
    dpi: int = 300,
    fig_size_in: Tuple[Length, Length] = (Length(3, LengthUnit.INCH), Length(3, LengthUnit.INCH)),
    with_colorbar: bool = True,
    mosaic_title: str | None = None,
) -> ImageBundle:

    if plot_params is None:
        plot_params = PlotParameters(
            cmap=cmap,
            dpi=dpi,
            size_in=fig_size_in,
            with_colorbar=with_colorbar,
            plot_label=plot_label)

    scalar2d = PltScalar2d(
        shot.result.values,
        params=plot_params,
        extent=shot.result.extent,
        hide_ticks=False,
        show_lattice=True,
        lattice_color=(1, 1, 1, 0.4),
    )
    array_image = scalar2d.render(plot_label=plot_label)
    return ImageBundle(array_image)


