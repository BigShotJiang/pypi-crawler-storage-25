from __future__ import annotations
import logging
from numbers import Integral
import numpy as np
from pathlib import Path
from typing import Optional,TYPE_CHECKING, Iterator, overload
from scanner3d.afs.frame.frame import Frame
from dimetra.geo import Length, LengthSeq


if TYPE_CHECKING:
    from scanner3d.tuner.tuner import Tuner
    from zemod.zemod import ZeMod
    from scanner3d.analysis.analysis_definition.analysis_definition import AnalysisDefinition
    from scanner3d.afs.album_settings.album_settings import AlbumSettings

log = logging.getLogger(__name__)
class Album:
    __slots__ = ("_frames", "_z_seq", "_path", "_album_settings")
    def __init__(
            self,
            *,
            album_settings: AlbumSettings,
            frames: list[Frame],
            z_seq: LengthSeq,
            path: Optional[Path] = None,
        _internal: bool = False,
    ) -> None:
        if not _internal:
            raise RuntimeError("Direct construction of Album is not allowed. ")
        if not isinstance(z_seq, LengthSeq):
            raise TypeError(f"Album z_seq must be LengthSeq, got {type(z_seq).__module__}.{type(z_seq).__qualname__}")
        self._album_settings = album_settings
        self._frames = list(frames)
        self._z_seq = z_seq
        self._path = path


    @property
    def album_settings(self) -> AlbumSettings:
        return self._album_settings

    @property
    def frames(self) -> list[Frame]:
        return self._frames

    @property
    def z_seq(self) -> LengthSeq:
        return self._z_seq

    def z_seq_mm(self) -> np.ndarray:
        return np.array([z.value_mm for z in self._z_seq], dtype=float)

    @property
    def path(self) -> Optional[Path]:
        return self._path

    @property
    def n_frames(self) -> int:
        return len(self.frames)

    def __iter__(self) -> Iterator[Frame]:
        return iter(self._frames)

    def __len__(self) -> int:
        return self.n_frames

    @overload
    def __getitem__(self, item: Length) -> Frame: ...
    @overload
    def __getitem__(self, item: slice) -> list[Frame]: ...
    @overload
    def __getitem__(self, item: int) -> Frame: ...

    def __getitem__(self, item):

        if isinstance(item, Length):
            return self.get_nearest(item)
        if isinstance(item, Integral):
            return self._frames[item]  # will raise IndexError naturally if out of range
        if isinstance(item, slice):
            return self._frames[item]

        raise TypeError(
            f"Unsupported index type for Album: {type(item)!r}; "
            f"use Length (for nearest-z), int (for direct index), or a slice.")

    def get_nearest(self, z: Length) -> Frame:
        if not self._z_seq:
            raise ValueError("Album has no z sequence; cannot search nearest frame.")
        z_mm = self.z_seq_mm()
        target_mm = z.value_mm
        eligible = z_mm[z_mm <= target_mm]
        if eligible.size > 0:
            chosen_z = eligible.max()
        else:
            chosen_z = z_mm.min()
        idx = int(np.where(z_mm == chosen_z)[0][0])
        psf = self._frames[idx]
        log.info("Requested Z=%s → selected frame %.3f mm (index %d)",z, chosen_z, idx)
        return psf


    @classmethod
    def from_components(
            cls,
            *,
            album_settings: AlbumSettings,
            frames: list[Frame],
            z_seq: LengthSeq,
            path: Optional[Path] = None) -> Album:
        return cls(frames=list(frames),z_seq=z_seq, path=path, album_settings=album_settings, _internal=True)

    @classmethod
    def compute(
            cls,
            *,
            zemod: ZeMod,
            tuner: Tuner,
            analysis_def: AnalysisDefinition,
            album_settings: AlbumSettings,
            x_seq:LengthSeq,
            y_seq:LengthSeq,
            z_seq: LengthSeq) -> Album:
        frames: list[Frame] = []
        z_row = tuner.sm.get_wd_row() #ask tuner for surface (row) in LDE for set working distance
        zemod_field = tuner.fm.get_test_field()  #ask tuner which field used for test
        for z in z_seq:
            z_row.thickness = z.value_mm
            profile = tuner.get_profile()
            psf_slice = Frame.compute(
                zemod = zemod,
                zemod_field=zemod_field,
                analysis_def= analysis_def,
                x_seq=x_seq,
                y_seq=y_seq,
                profile=profile,
                z=z)
            log.debug("PSF Frame @ %.2f mm created", z.value_mm)
            frames.append(psf_slice)
        return cls(frames=frames, z_seq=z_seq, _internal=True, album_settings=album_settings)

    def __str__(self) -> str:
        if not self._z_seq:
            return "📘 Album (empty)>"

        z_mm = sorted(self.z_seq_mm())
        n = len(z_mm)
        lines = [
            "📘 Album",
            "────────────────────────────",
            f"  File: {self._path.name if self._path else '(unsaved)'}",
            f"  Number of frames: {n}",
            f"  Range: {z_mm[0]:.2f} mm → {z_mm[-1]:.2f} mm",
        ]
        return "\n".join(lines)

    def __repr__(self) -> str:
        if not self._z_seq:
            return "Album"
        z_mm = sorted(self.z_seq_mm())
        return f"Album {len(z_mm)} frames {z_mm[0]:.2f}–{z_mm[-1]:.2f} mm>"
