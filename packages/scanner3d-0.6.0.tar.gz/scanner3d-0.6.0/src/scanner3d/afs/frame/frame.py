from __future__ import annotations
import numpy as np
import logging
from typing import TYPE_CHECKING, Optional,Sequence
from dimetra.geo import  Length, LengthSeq, LengthUnit
from scanner3d.tuner.profile import Profile
from scanner3d.afs.shot.shot import Shot
from scanner3d.afs.shot_result.shots import Shots
from scanner3d.afs.frame.frame_meta import FrameMeta

if TYPE_CHECKING:
    from zemod.zemod import ZeMod
    from zemod.zemod_field import ZeModField
    from scanner3d.analysis.analysis_definition.analysis_definition import AnalysisDefinition


log = logging.getLogger(__name__)
class Frame:
    __slots__ = ("_shots", "_x_seq", "_y_seq", "_meta", "_profile", "_z")

    def __init__(
        self,
        *,
        shots,
        x_seq: LengthSeq,
        y_seq: LengthSeq,
        meta: FrameMeta,
        profile: Profile,
        z: Length,
        _internal: bool = False,
    ) -> None:
        if not _internal:
            raise RuntimeError(
                "Direct construction of Frame is not allowed. "
                "Use compute(...) to calculate it from Zemax, or from_components() to reconstruct it.")

        self._shots = shots
        self._x_seq = x_seq
        self._y_seq = y_seq
        self._meta = meta
        self._profile = profile
        self._z = z

    @classmethod
    def from_components(
        cls,
        *,
        shots,
        x_seq: LengthSeq,
        y_seq: LengthSeq,
        profile: Profile,
        z: Length,
        meta: FrameMeta,
    ) -> Frame:
        return cls(shots=shots, x_seq=x_seq, y_seq=y_seq, meta=meta, profile=profile, z=z, _internal=True)

    @classmethod
    def compute(
        cls,
        *,
        zemod: ZeMod,
        zemod_field: ZeModField,
        analysis_def: AnalysisDefinition,
        x_seq: Optional[LengthSeq],
        y_seq: Optional[LengthSeq],
        profile: Profile,
        z: Length,
    ) -> Frame:
        if x_seq is None and y_seq is None:
            raise ValueError("Provide x_seq and/or y_seq (x for 1D-X, y for 1D-Y, both for 2D).")
        x_list: list[Length] | None = list(x_seq) if x_seq is not None else None
        y_list: list[Length] | None = list(y_seq) if y_seq is not None else None

        log.debug(
            "Frame.compute: start | z=%.4f mm | x_seq=%s | y_seq=%s",
            z.value_mm,
            f"{len(x_list)} pts" if x_list is not None else "None",
            f"{len(y_list)} pts" if y_list is not None else "None")

        # 1️⃣ 2D CASE — both x_seq and y_seq provided
        if x_list is not None and y_list is not None:
            xs: list[Length] = []
            ys: list[Length] = []
            for yv in y_list:
                for xv in x_list:
                    xs.append(xv)
                    ys.append(yv)
            x_meta = x_list
            y_meta = y_list

        # 2️⃣ 1D CASE — scan along X (y = 0 mm)
        elif x_list is not None:
            zero = Length(0.0, LengthUnit.MM)
            xs = x_list
            ys = [zero for _ in x_list]
            x_meta = x_list
            y_meta = [zero]

        # 3️⃣ 1D CASE — scan along Y (x = 0 mm)
        else:
            assert y_list is not None  # since we checked both None above
            zero = Length(0.0, LengthUnit.MM)
            ys = y_list
            xs = [zero for _ in y_list]
            x_meta = [zero]
            y_meta = y_list

        log.debug(
            "Frame.compute: grid built | mode=%s | nx=%d | ny=%d | total points=%d",
            "2D"
            if (x_list is not None and y_list is not None)
            else "1D-X"
            if x_list is not None
            else "1D-Y",
            len(x_meta),
            len(y_meta),
            len(xs))
        log.debug(
            "Frame.compute: x range = [%.4g, %.4g] mm | y range = [%.4g, %.4g] mm",
            min(v.value_mm for v in xs),
            max(v.value_mm for v in xs),
            min(v.value_mm for v in ys),
            max(v.value_mm for v in ys))

        shots: list[Shot] = []
        for xv, yv in zip(xs, ys):
            shot = Shot.compute(
                zemod = zemod,
                zemod_field=zemod_field,
                analysis_def=analysis_def,
                x=xv,
                y=yv)
            shots.append(shot)

        shots_batch = Shots.from_list(shots)

        meta = FrameMeta.from_shots(shots=shots)

        return cls(
            shots=shots_batch,
            x_seq=LengthSeq.from_lengths(x_meta),
            y_seq=LengthSeq.from_lengths(y_meta),
            meta=meta,
            profile=profile,
            z=z,
            _internal=True,
        )

    @property
    def values(self) -> np.ndarray:
        return self._shots.values

    @property
    def shots(self) -> Sequence[Shot]:
        return self._shots.items

    @property
    def shots_batch(self) -> Shots:
        return self._shots

    @property
    def x_seq(self) -> LengthSeq:
        return self._x_seq

    @property
    def y_seq(self) -> LengthSeq:
        return self._y_seq

    @property
    def meta(self) -> FrameMeta:
        return self._meta

    @property
    def profile(self) -> Profile:
        return self._profile

    @property
    def z(self) -> Length:
        return self._z

    @property
    def z_mm(self) -> float:
        return self._z.value_mm

    @property
    def x_seq_mm(self) -> np.ndarray:
        return np.asarray(self._x_seq.values_mm, dtype=float)

    @property
    def y_seq_mm(self) -> np.ndarray:
        return np.asarray(self._y_seq.values_mm, dtype=float)

    @property
    def frame_name(self) -> str:
        wd = self.profile.working_distance
        return f"psf_frame_at_{wd:.2f}" if wd is not None else "psf_frame_at_unknown"

    @property
    def n_rows(self) -> int:
        return len(self._y_seq)

    @property
    def n_cols(self) -> int:
        return len(self._x_seq)

    def top_right_shot(self) -> Shot:
        return self[self.n_rows - 1, self.n_cols - 1]

    def __call__(self, row: int, col: int) -> Shot:
        """
        Return the Shot at grid position (row, col).
        row = index into y_seq
        col = index into x_seq
        """
        nx = len(self._x_seq)
        idx = row * nx + col
        return self._shots[idx]

    def __getitem__(self, idx):
        """
        Access PSF shots in the frame.

        Supports:
            frame[i]          -> 1D flat index (0 .. N-1)
            frame[row, col]   -> 2D grid index
                                 row: Y index (0 .. len(y_seq) - 1)
                                 col: X index (0 .. len(x_seq) - 1)
        """
        if isinstance(idx, tuple) and len(idx) == 2:
            row, col = idx
            n_cols = len(self._x_seq)
            n_rows = len(self._y_seq)
            if not (0 <= row < n_rows and 0 <= col < n_cols):
                raise IndexError(
                    f"Grid index out of range: row={row}, col={col}, "
                    f"valid rows [0..{n_rows - 1}], cols [0..{n_cols - 1}]"
                )
            i = row * n_cols + col
            return self._shots[i]
        return self._shots[idx]

    def __str__(self) -> str:
        x_arr = np.asarray(self._x_seq.values_mm, dtype=float)
        y_arr = np.asarray(self._y_seq.values_mm, dtype=float)
        z_mm = self._z.value_mm
        parts = [
            "🖼️ PSF Frame",
            "────────────────────────────",
            f"  z: {z_mm:.2f} mm",
            f"  x: shape={x_arr.shape}, "
            f"min={np.nanmin(x_arr):.4g}, max={np.nanmax(x_arr):.4g} mm,",
            f"  y: shape={y_arr.shape}, "
            f"min={np.nanmin(y_arr):.4g}, max={np.nanmax(y_arr):.4g} mm,",
            f"  total shots: {len(self._shots)},",
            f"  values shape: {self.values.shape},",
            f"  meta: {self._meta}",
        ]
        return "\n".join(parts)

    def plot(self, *args, **kwargs):
        from scanner3d.afs.frame.plot_frame import plot_frame
        return plot_frame(self, *args, **kwargs)