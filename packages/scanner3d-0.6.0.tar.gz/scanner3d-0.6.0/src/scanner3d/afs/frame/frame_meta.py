from __future__ import annotations

import numpy as np
from dataclasses import dataclass
from typing import Sequence, TYPE_CHECKING

if TYPE_CHECKING:
    from scanner3d.afs.shot.shot import Shot


@dataclass(frozen=True, slots=True)
class FrameMeta:
    value_min: float
    value_max: float

    @staticmethod
    def from_shots(shots: Sequence[Shot]) -> FrameMeta:
        if not shots:
            return FrameMeta(value_min=np.nan, value_max=np.nan)

        mins = np.array([s.min for s in shots], dtype=float)
        maxs = np.array([s.max for s in shots], dtype=float)

        mins = mins[np.isfinite(mins)]
        maxs = maxs[np.isfinite(maxs)]

        return FrameMeta(
            value_min=float(np.nanmin(mins)) if mins.size else np.nan,
            value_max=float(np.nanmax(maxs)) if maxs.size else np.nan,
        )

    def __str__(self) -> str:
        vmin = "NaN" if np.isnan(self.value_min) else f"{self.value_min:.6g}"
        vmax = "NaN" if np.isnan(self.value_max) else f"{self.value_max:.6g}"
        return f"📝 Frame meta:\n  • min = {vmin}\n  • max = {vmax}"

    def __repr__(self) -> str:
        return f"Frame min={self.value_min:.6g} max={self.value_max:.6g}>"