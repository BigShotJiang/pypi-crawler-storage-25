from __future__ import annotations
import numpy as np
from dimetra.geo import  Length, LengthUnit
from typing import Optional, Tuple, TYPE_CHECKING
from imagera.plotter import plt_scalars2d, PlotParameters, CMaps
from imagera.image import ImageBundle


if TYPE_CHECKING:
    from scanner3d.afs.frame.frame import Frame


def plot_frame(
    frame: Frame,
    plot_params: Optional[PlotParameters] = None,
    *,
    cmap=CMaps.JET,
    dpi: int = 300,
    fig_size_in: Tuple[Length, Length] = (Length(3, LengthUnit.INCH), Length(3, LengthUnit.INCH)),
    with_colorbar: bool = True,
    tile_titles: bool = False,
    mosaic_title: str | None = None,
) -> ImageBundle:
    profile = frame.profile
    default_title = (
        f"PSF Frame for {profile.objective_id}\n"
        f"with sensor {profile.sensor_model} at {profile.working_distance:.3f} mm"
    )
    title = mosaic_title or default_title
    if plot_params is None:
        plot_params = PlotParameters(cmap=cmap, dpi=dpi, size_in=fig_size_in)

    x_seq = np.asarray(frame.x_seq_mm, dtype=float)
    y_seq = np.asarray(frame.y_seq_mm, dtype=float)
    X, Y = np.meshgrid(x_seq, y_seq)           # (R, C)
    grid = np.stack((X, Y), axis=-1)           # (R, C, 2)

    # Frame.values is (n_shots, Ny, Nx) ordered in y-major grid
    R = len(y_seq)
    C = len(x_seq)
    Ny, Nx = frame.values.shape[-2:]
    values_array = frame.values.reshape(R, C, Ny, Nx)
    array_image =plt_scalars2d(
        grid=grid,
        values_array=values_array,
        params=plot_params,
        with_colorbar=with_colorbar,
        tile_titles=tile_titles,
        mosaic_title=title)
    return ImageBundle(array_image)




