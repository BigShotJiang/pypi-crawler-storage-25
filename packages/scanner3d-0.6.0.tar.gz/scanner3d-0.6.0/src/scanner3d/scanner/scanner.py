from __future__ import annotations
from typing import Tuple
from scanner3d.camera3d import Camera3D
from geopto.cs import CS3D

class Scanner:
    __slots__ = ("_name", "_scanner_cs", "_cameras")

    def __init__(
        self,
        name: str,
        cameras: Tuple[Camera3D, ...],
        scanner_cs: CS3D | None = None,
    ) -> None:
        if not cameras:
            raise ValueError("Scanner must contain at least one camera")

        self._name = name
        self._scanner_cs = scanner_cs if scanner_cs is not None else CS3D.world()
        self._cameras = tuple(cameras)  # ensure immutability

    # --- read-only properties (frozen behavior) ---
    @property
    def name(self) -> str:
        return self._name

    @property
    def scanner_cs(self) -> CS3D:
        return self._scanner_cs

    @property
    def cameras(self) -> Tuple[Camera3D, ...]:
        return self._cameras

    # --- string representations ---
    def __str__(self) -> str:
        cam_list = ", ".join(c.name for c in self._cameras)
        return (
            f"🔭 Scanner '{self._name}'\n"
            f"────────────────────────\n"
            f"  cameras : {cam_list}\n"
            f"  count   : {len(self._cameras)}"
        )

    def __repr__(self) -> str:
        return f"Scanner(name={self._name!r}, cameras={[c.name for c in self._cameras]!r})"

    # --- logic ---
    def camera_in_world(self, cam: Camera3D) -> CS3D:
        return self._scanner_cs.compose_after(cam.cam_pos.cs)