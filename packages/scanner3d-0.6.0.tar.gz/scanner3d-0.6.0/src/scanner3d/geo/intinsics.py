from __future__ import annotations
from dataclasses import dataclass
from dimetra.geo import Length


@dataclass(frozen=True, slots=True)
class Intrinsics:
    """
    Camera intrinsics (pinhole-like).

    All values are in physical units (mm).
    """
    fx: Length   # focal length in x
    fy: Length   # focal length in y
    cx: Length   # principal point x
    cy: Length   # principal point y

    @staticmethod
    def symmetric(
        *,
        f: Length,
        cx: Length = Length(0),
        cy: Length = Length(0),
    ) -> Intrinsics:
        return Intrinsics(fx=f, fy=f, cx=cx, cy=cy)
