from __future__ import annotations
from dataclasses import dataclass
from dimetra.geo import Length
from geopto.primitives.point_3d import Point3D
from geopto.primitives.vec_3d import Vec3
from geopto.cs import CS3D

@dataclass(frozen=True, slots=True)
class CameraPosition:
    """
    Camera pose relative to its parent coordinate system.

    Convention: cs maps camera-local -> parent-local.
    (Variant A: parent is scanner-local.)
    """
    cs: CS3D

    @staticmethod
    def aligned_with_parent_at_origin() -> CameraPosition:
        """Camera coincides with parent frame (identity)."""
        return CameraPosition(cs=CS3D.world())

    @staticmethod
    def from_origin_and_forward_in_parent(
        origin_in_parent: Point3D,
        forward_in_parent: Vec3,
        *,
        up_hint_in_parent: Vec3 = Vec3(0.0, 1.0, 0.0),
    ) -> CameraPosition:
        """Build camera pose in parent coordinates."""
        return CameraPosition(cs=CS3D.from_forward(origin_in_parent, forward_in_parent, up_hint=up_hint_in_parent))

    @property
    def origin_in_parent(self) -> Point3D:
        return self.cs.origin

    @property
    def forward_in_parent(self) -> Vec3:
        return self.cs.forward

    @property
    def right_in_parent(self) -> Vec3:
        return self.cs.right

    @property
    def up_in_parent(self) -> Vec3:
        return self.cs.up

    def parent_to_camera_mm(self, p_parent: Point3D) -> Vec3:
        """Transform parent point to camera-local coordinates (mm)."""
        return self.cs.point_world_to_local_mm(p_parent)  # (название метода CS3D историческое)

    def camera_to_parent(self, p_cam_mm: Vec3) -> Point3D:
        """Transform camera-local point (mm) to parent coordinates."""
        return self.cs.point_local_mm_to_world(p_cam_mm)

    def translate_parent(self, v_parent_mm: Vec3) -> CameraPosition:
        """Translate camera in parent coordinates by mm-vector."""
        # Тут лучше иметь помощник: Vec3(mm) -> Point3D increment
        from gosti.geo.vector_3d import Vector3D
        new_origin = self.origin_in_parent + Vector3D(
            Length(v_parent_mm.x),
            Length(v_parent_mm.y),
            Length(v_parent_mm.z),
        )
        return CameraPosition(cs=CS3D(origin=new_origin, basis=self.cs.basis))

    def translate_forward(self, distance: Length) -> CameraPosition:
        """Move camera along its forward axis (defined in parent coordinates)."""
        v_parent_mm = self.forward_in_parent * float(distance.value_mm)
        return self.translate_parent(v_parent_mm)

    def __str__(self) -> str:
        o = self.origin_in_parent
        f = self.forward_in_parent
        u = self.up_in_parent
        r = self.right_in_parent

        return (
            "CameraPosition(\n"
            f"  origin_parent = ({o.x.value_mm:.3f}, {o.y.value_mm:.3f}, {o.z.value_mm:.3f}) mm\n"
            f"  forward_parent= ({f.x:.6f}, {f.y:.6f}, {f.z:.6f})\n"
            f"  up_parent     = ({u.x:.6f}, {u.y:.6f}, {u.z:.6f})\n"
            f"  right_parent  = ({r.x:.6f}, {r.y:.6f}, {r.z:.6f})\n"
            ")"
        )