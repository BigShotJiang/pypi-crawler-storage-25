from scanner3d.geo import ZRange
from dimetra.geo import Length, LengthUnit

Z_RANGE_SPIDER = ZRange(
    z_min=Length(190.0, LengthUnit.MM),
    z_max=Length(350.0, LengthUnit.MM),
    z_focus=Length(240.0, LengthUnit.MM))

Z_RANGE_EVA = (ZRange(
    z_min=Length(350.0, LengthUnit.MM),
    z_max=Length(800.0, LengthUnit.MM),
    z_focus=Length(550.0, LengthUnit.MM)))

Z_RANGE_LEO = (ZRange(
    z_min=Length(350.0, LengthUnit.MM),
    z_max=Length(1200.0, LengthUnit.MM),
    z_focus=Length(550.0, LengthUnit.MM)))





