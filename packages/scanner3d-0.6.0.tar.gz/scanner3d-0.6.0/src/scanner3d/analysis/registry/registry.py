from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Iterable
from scanner3d.analysis.case.case_result import CaseResult


class Registry(ABC):
    @abstractmethod
    def save_settings_bundle(self, folder: Path, settings_objects: Iterable[Any]) -> None:
        raise NotImplementedError

    @abstractmethod
    def verify_file(self, path: Path) -> bool:
        raise NotImplementedError

    @abstractmethod
    def register_case_result(self, *, kind: str, case: CaseResult) -> None:
        raise NotImplementedError
