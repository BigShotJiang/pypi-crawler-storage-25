import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from allytools.strings import sanitize
from scanner3d.analysis.base.analysis_meta import AnalysisMeta
from scanner3d.analysis.case.case_result import CaseResult
from scanner3d.analysis.registry.registry import Registry

log = logging.getLogger(__name__)


@dataclass(slots=True)
class DefaultRegistry(Registry):
    meta: AnalysisMeta

    def save_settings_bundle(self, folder: Path, settings_objects: Iterable[Any]) -> None:
        from scanner3d.analysis.save_settings import save_settings
        for obj in settings_objects:
            save_settings(obj, folder)

    def verify_file(self, path: Path) -> bool:
        exists = path.exists()
        size = path.stat().st_size if exists else 0
        ok = exists and size > 0
        if not ok:
            log.warning("output verification failed: exists=%s size=%s path=%s", exists, size, path)
        return ok

    def register_case_result(self, *, kind: str, case: CaseResult) -> None:
        from scanner3d.analysis.result.register_case_result import register_case_result
        register_case_result(
            scanner_name=sanitize(self.meta.scanner_name),
            analysis_name=sanitize(self.meta.analysis_name),
            case_name=sanitize(case.name),
            kind=sanitize(kind),
            outcome=str(case.outcome),
            elapsed_time=float(case.elapsed_time),
            artifacts=case.artifacts)