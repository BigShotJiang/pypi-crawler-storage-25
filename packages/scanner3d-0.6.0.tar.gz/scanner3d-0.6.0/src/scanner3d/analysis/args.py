import argparse
from pathlib import Path
from scanner3d.analysis.presets import CAMERA_PRESETS, ANALYSIS_PRESETS


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="scanner3d-analyses")

    p.add_argument(
        "--analyses",
        default="quick",
        choices=sorted(ANALYSIS_PRESETS.keys()),
        help="Analysis preset to run.")
    p.add_argument(
        "--cameras",
        default="spider2proc",
        choices=sorted(CAMERA_PRESETS.keys()),
        help="Camera preset to run.")
    p.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Output folder. If not provided, uses get_output_dir().")
    p.add_argument(
        "--fail-fast",
        action="store_true",
        help="Stop after first camera with failures/errors.")
    return p


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)
