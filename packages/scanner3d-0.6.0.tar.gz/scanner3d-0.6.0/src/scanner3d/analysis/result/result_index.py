from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable
import json
from scanner3d.analysis.case.case_record import CaseRecord
from scanner3d.analysis.result.parse_timestamp import parse_timestamp
from scanner3d.analysis.result.path import get_index_path
from scanner3d.scanner.scanner import Scanner
from scanner3d.scanners.ScannersDB import ScannersDB

type CaseKey = tuple[str, str, str]

def get_available_scanners() -> list[Scanner]:
    index = ResultsIndex.from_jsonl(get_index_path())
    return [ScannersDB.get_scanner(name) for name in index.scanners]

@dataclass(slots=True)
class ResultsIndex:
    cases: list[CaseRecord] = field(default_factory=list)
    _by_key: dict[CaseKey, list[CaseRecord]] = field(init=False, default_factory=dict)

    def __post_init__(self) -> None:
        by_key: dict[CaseKey, list[CaseRecord]] = {}
        for case in self.cases:
            key = (case.scanner_name, case.analysis_name, case.case_name)
            by_key.setdefault(key, []).append(case)
        self._by_key = by_key

    @property
    def scanners(self) -> list[str]:
        return sorted({case.scanner_name for case in self.cases})

    @classmethod
    def from_jsonl(cls, path: Path) -> ResultsIndex:
        if not path.exists():
            return cls()

        cases: list[CaseRecord] = []
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                data = json.loads(line)
                cases.append(CaseRecord.from_dict(data))
        return cls(cases=cases)

    def iter_matching(
            self,
            *,
            scanner_name: str,
            analysis_name: str,
            case_name: str,
            require_passed: bool = True,
    ) -> Iterable[CaseRecord]:
        key = (scanner_name, analysis_name, case_name)
        for case in self._by_key.get(key, []):
            if require_passed and case.outcome != "Outcome.PASSED":
                continue
            yield case

    def find_latest_case(
        self,
        *,
        scanner_name: str,
        analysis_name: str,
        case_name: str,
        require_passed: bool = True,
    ) -> CaseRecord | None:
        matches = list(
            self.iter_matching(
                scanner_name=scanner_name,
                analysis_name=analysis_name,
                case_name=case_name,
                require_passed=require_passed))
        if not matches:
            return None
        return max(matches, key=lambda c: parse_timestamp(c.timestamp))

    def get_artifact(
        self,
        *,
        scanner_name: str,
        analysis_name: str,
        case_name: str,
        artifact_key: str = "h5",
        require_passed: bool = True,
    ) -> str | None:
        case = self.find_latest_case(
            scanner_name=scanner_name,
            analysis_name=analysis_name,
            case_name=case_name,
            require_passed=require_passed)
        if case is None:
            return None

        if artifact_key in case.artifacts:
            return case.artifacts[artifact_key]

        for value in case.artifacts.values():
            sv = str(value)
            if artifact_key == "h5" and sv.lower().endswith(".h5"):
                return sv

        return None