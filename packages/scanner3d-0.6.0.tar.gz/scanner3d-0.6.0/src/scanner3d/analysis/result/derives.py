from typing import  Any

def derive_analysis_name(analysis: Any) -> str:
    for attr in ("analysis_name", "label", "name"):
        if hasattr(analysis, attr):
            v = getattr(analysis, attr)
            if v is not None:
                return str(v)
    return str(analysis)


def derive_case_name(case: Any) -> str:
    for attr in ("album_name", "name", "label"):
        if hasattr(case, attr):
            v = getattr(case, attr)
            if v is not None:
                return str(v)
    return str(case)