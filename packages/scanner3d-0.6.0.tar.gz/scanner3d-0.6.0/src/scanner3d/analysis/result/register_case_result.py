from __future__ import annotations
import json
from dataclasses import asdict
from typing import Any
from scanner3d.analysis.case.case_record import CaseRecord
from scanner3d.analysis.result.path import to_artifact_path, get_index_path

def register_case_result(
    *,
    scanner_name: str,
    analysis_name: str,
    case_name: str,
    kind: str,
    outcome: str,
    elapsed_time: float,
    artifacts: dict[str, Any] | None,
    camera_name: str | None = None,
) -> None:
    rec = CaseRecord(
        scanner_name=scanner_name,
        analysis_name=analysis_name,
        case_name=case_name,
        kind=kind,
        outcome=outcome,
        elapsed_time=float(elapsed_time),
        artifacts={k: to_artifact_path(v) for k, v in (artifacts or {}).items()},
        camera_name=camera_name,
    )
    idx = get_index_path()
    idx.parent.mkdir(parents=True, exist_ok=True)
    with idx.open("a", encoding="utf-8") as f:
        f.write(json.dumps(asdict(rec), ensure_ascii=False) + "\n")
