from pathlib import Path
import scanner3d
from typing import Any
from allytools.files.require import ensure_folder


JSON_FILENAME = "results_index.jsonl"
OUTPUT_DIR_NAME = "analysis_outcome"

def get_project_root() -> Path:
    """Find the root directory of the project """
    pkg_dir = Path(scanner3d.__file__).resolve().parent  # .../src/scanner3d
    return pkg_dir.parent.parent                         # .../Scanner3D

def get_output_dir() -> Path:
    """Return the directory where all analysis results are stored."""
    root = get_project_root()
    out_dir = root / OUTPUT_DIR_NAME
    ensure_folder(out_dir)
    return out_dir

def get_index_path() -> Path:
    """Return full path to the index file."""
    return get_output_dir() / JSON_FILENAME

def resolve_artifact_path(p: str) -> Path:
    """
    Convert a stored artifact path (from index) into a real filesystem path.
    Supports:
        - relative paths (resolved against output dir)
        - absolute paths (returned as-is)
    Raises:
        - ValueError if resolved path escapes output directory
    """
    root = get_output_dir()
    pp = Path(p)
    if pp.is_absolute():
        return pp
    resolved = (root / pp).resolve()
    try:
        resolved.relative_to(root)
    except ValueError:
        raise ValueError(f"Path escapes output dir: {p}")

    return resolved

def to_artifact_path(value: Any) -> str:
    """ Store paths relative to output root when possible. Everything else becomes str(value)."""
    if isinstance(value, Path):
        root = get_output_dir()
        p = value.resolve()
        try:
            rel = p.relative_to(root)
            return str(rel)
        except ValueError:
            return str(p)
    return str(value)