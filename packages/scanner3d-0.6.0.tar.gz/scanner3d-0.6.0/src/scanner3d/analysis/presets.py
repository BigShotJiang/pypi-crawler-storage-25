from __future__ import annotations
from typing import Iterable, Sequence
from scanner3d.analysis.base.run_config import RunConfig
from scanner3d.analysis.factory import ALL_COARSE, ALL, ZERNIKE_COARSE, BRT_COARSE, PSF_COARSE, DISTORTION, BATCH_PUPIL_RAYS
from scanner3d.camera_group import CAMERA_LIST_FULL, SPIDER2, SPIDER_GROUP, LEO_GROUP, EVA_GROUP

ANALYSIS_PRESETS: dict[str, Sequence] = {
    "all_coarse": ALL_COARSE,
    "all": ALL,
    "zernike_coarse": ZERNIKE_COARSE,
    "btr_coarse": BRT_COARSE,
    "psf_coarse": PSF_COARSE
}

CAMERA_PRESETS: dict[str, Iterable] = {
    "all": CAMERA_LIST_FULL,
    "spider2": SPIDER2,
    "spider_group": SPIDER_GROUP,
    "leo_group": LEO_GROUP,
    "eva_group": EVA_GROUP
}

DEFAULT_CFG = RunConfig(analyses=BATCH_PUPIL_RAYS, cameras=SPIDER2, fail_fast=False)