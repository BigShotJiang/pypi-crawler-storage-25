from enum import Enum, auto

class AnalysisTypes(Enum):
    FFT_PSF = auto()
    HUYGENS_PSF = auto()
    ZERNIKE_STANDARD = auto()
    BATCH_PUPIL_RAYS = auto()
