from scanner3d.analysis.base.analysis import Analysis
from scanner3d.analysis.sweep import *
from scanner3d.analysis.batch_raytrace import *
from scanner3d.analysis.distortion import *

PSF_COARSE:             list[Analysis] = [psf_coarse]
ZERNIKE_COARSE:         list[Analysis] = [zernike_coarse]
ALL_COARSE:             list[Analysis] = [psf_coarse, batch_raytrace_coarse, zernike_coarse]
ALL:                    list[Analysis] = [psf_detailed, batch_raytrace_detailed, zernike_detailed]
BRT_COARSE:             list[Analysis] = [batch_raytrace_coarse]
BRT_DETAILED:           list[Analysis] = [batch_raytrace_detailed]
DISTORTION:             list[Analysis] = [distortion_test]
BATCH_PUPIL_RAYS:       list[Analysis] = [batch_pupil_rays]