from __future__ import annotations
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Sequence
from dataclasses import dataclass
from scanner3d.analysis.base.analysis import Analysis
from scanner3d.analysis.base.analysis_context import AnalysisContext
from scanner3d.analysis.base.analysis_result import AnalysisResult
from h5kit import H5IOManager

if TYPE_CHECKING:
    from scanner3d.camera3d.camera3d import Camera3D
    from zemod.zemod import ZeMod

log = logging.getLogger(__name__)
@dataclass
class AnalysesSuite:
    analyses: Sequence[Analysis]

    def names(self) -> list[str]:
        return [t.analysis_name for t in self.analyses]

    def __iter__(self):
        return iter(self.analyses)

    def run(
        self, zemod: ZeMod, camera: Camera3D, output_root: Path, h5_manager:H5IOManager, scanner_name:str
    ) -> list[AnalysisResult]:
        results: list[AnalysisResult] = []
        for t in self.analyses:
            log.info("=== Running analysis %s ===", t.analysis_name)
            ctx = AnalysisContext(zemod=zemod, camera=camera, h5_manager=h5_manager, scanner_name=scanner_name)
            try:
                res = t.run(ctx=ctx, output_root=output_root)
                results.append(res)
                log.info(
                    "=== Analysus %s -> %s (%.2f s) ===",
                    res.analysis_name,
                    res.outcome.name,
                    res.elapsed_s)
            except Exception:
                log.exception("Analysis crashed: %s", t.analysis_name)
                raise
        return results