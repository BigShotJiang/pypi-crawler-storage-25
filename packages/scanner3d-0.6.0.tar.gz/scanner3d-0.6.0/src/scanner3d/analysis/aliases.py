from typing import TypeVar

TResource = TypeVar("TResource")
TSettings = TypeVar("TSettings")
TRawResult = TypeVar("TRawResult")
TResult = TypeVar("TResult")
