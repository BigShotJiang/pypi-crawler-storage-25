from scanner3d.analysis.batch_raytrace.batch_raytrace_analysis import BatchRayTraceAnalysis
from scanner3d.analysis.base.analysis_settings import AnalysisSettings
from scanner3d.tuner.tuner_settings.tuner_settings_presets import second_field_rectangular
from scanner3d.analysis.batch_raytrace.settings_presets import normal_unpolarized_64, normal_unpolarized_full, normal_unpolarized_2

batch_raytrace_coarse = BatchRayTraceAnalysis(
    analysis_settings=AnalysisSettings(analysis_name="Batch ray trace coarse"),
    raytrace_settings=normal_unpolarized_2,
    tuner_settings=second_field_rectangular)

batch_raytrace_detailed = BatchRayTraceAnalysis(
    analysis_settings=AnalysisSettings(analysis_name="Batch ray trace detailed"),
    raytrace_settings=normal_unpolarized_full,
    tuner_settings=second_field_rectangular)

