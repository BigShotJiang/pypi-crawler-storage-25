from zempy.zosapi.tools.raytrace.enums import RaysType
from gosti.batch_raytrace.trace_method import TraceMethod
from gosti.grid import FieldGridRectangle, PupilGridCircle, OnAxisPupil, FieldGridRadial,FieldRectangleMaxX
from gosti.batch_raytrace.raytrace_settings import RayTraceSettings
from gosti.batch_raytrace.aid import RayTraceRunMode

normal_unpolarized_64 = RayTraceSettings(
    name="Sensor matrix 64x64",
    rays_type=RaysType.Real,
    method=TraceMethod.Normal_Unpolarized,
    wave_number=1,
    field_grid=FieldGridRectangle(64, 64),
    pupil_grid=OnAxisPupil(),
    raytrace_mode=RayTraceRunMode.BATCH)

normal_unpolarized_2 = RayTraceSettings(
    name="Sensor matrix 2x2",
    rays_type=RaysType.Real,
    method=TraceMethod.Normal_Unpolarized,
    wave_number=1,
    field_grid=FieldRectangleMaxX(),
    pupil_grid=PupilGridCircle(3,3),
    raytrace_mode=RayTraceRunMode.BATCH)

normal_unpolarized_full = RayTraceSettings(
    name="Full sensor",
    rays_type=RaysType.Real,
    method=TraceMethod.Normal_Unpolarized,
    wave_number=1,
    use_sensor_grid=True,
    pupil_grid=OnAxisPupil(),
    raytrace_mode=RayTraceRunMode.BATCH)

single_unpolarized = RayTraceSettings(
    name="SingleUnpolarized",
    method=TraceMethod.Normal_Unpolarized,
    rays_type=RaysType.Real,
    wave_number=1,
    raytrace_mode=RayTraceRunMode.SINGLE)