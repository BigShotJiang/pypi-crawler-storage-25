import logging
from typing import Any
from zemod.tools.zemod_tool_list import ZeModToolList
from gosti.batch_raytrace.raytrace_settings import RayTraceSettings
from gosti.batch_raytrace.ray_batch_type import REQUIRED_FOR_ANALYSIS
from scanner3d.analysis.base.analysis import Analysis
from scanner3d.analysis.base.analysis_context import AnalysisContext
from scanner3d.analysis.base.analysis_meta import AnalysisMeta
from scanner3d.analysis.base.result_layout import ResultLayout
from scanner3d.analysis.case.case_output import CaseOutput
from scanner3d.analysis.registry.registry import Registry


log = logging.getLogger(__name__)
class BatchRayTraceAnalysis(Analysis):
    def __init__(self, *,
                 analysis_settings,
                 tuner_settings,
                 raytrace_settings: RayTraceSettings) -> None:
        super().__init__(analysis_settings=analysis_settings, tuner_settings=tuner_settings)
        self.raytrace_settings = raytrace_settings

    def iter_cases(self, *, ctx: AnalysisContext) -> list[Any]:
        return [self.raytrace_settings.name]

    def compute_case(self, *,
                     ctx: AnalysisContext,
                     meta: AnalysisMeta,
                     layout: ResultLayout,
                     registry: Registry,
                     case: Any) -> CaseOutput:

        sensor_grid = (ctx.camera.sensor.width_pix, ctx.camera.sensor.height_pix)
        updated = self.raytrace_settings.replace_grid(grid=sensor_grid)

        from gosti.batch_raytrace.ray_batch import RayBatch
        from gosti.batch_raytrace.ray_batches import RayBatches

        ray_batches = RayBatches.empty()
        with ctx.tuner.tune(settings=self.tuner_settings):
            for batch_type in REQUIRED_FOR_ANALYSIS:
                to_surface = batch_type.to_surface(ctx.zemod.lde)
                zemod_tool = ctx.zemod.tools.run_tool(ZeModToolList.BATCH_RAYTRACE,updated.replace_surface(to_surface))
                batch = RayBatch.from_settings(
                    batch_type=batch_type,
                    rays=zemod_tool.rays,
                    process_time=zemod_tool.generic_tracer.process_time,
                    settings=updated.replace_surface(to_surface))
                ray_batches.append(batch)

        return CaseOutput(
            case_kind="raytrace",
            case_filename=str(updated.name),
            payload=ray_batches,
            settings_bundle=(self.tuner_settings, updated),
            extra_folder=None)
