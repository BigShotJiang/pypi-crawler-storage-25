from datetime import datetime
from allytools.files import ensure_folder
from allytools.logger import LoggingManager, TRACE_LEVEL
from scanner3d.analysis.args import parse_args
from scanner3d.analysis.base.run_config import RunConfig, cfg_from_args
from scanner3d.analysis.presets import DEFAULT_CFG
from scanner3d.analysis.result.path import get_output_dir
from scanner3d.h5.bootstrap import build_scanner3d_h5_manager


def main(argv: list[str] | None = None, *, cfg: RunConfig) -> int:
    if argv is not None:
        args = parse_args(argv)
        cfg = cfg_from_args(args)
    elif cfg is None:
        raise ValueError("cfg must be provided when argv is None")
    base_output = cfg.output or get_output_dir()
    ensure_folder(base_output)
    log_level = TRACE_LEVEL
    log_manager = LoggingManager(console_level=log_level)
    log_manager.configure_root_once()
    main_log = log_manager.summary_logger(file_path=base_output / "summary.log",propagate=True)
    main_log.info("Starting scanner3d analysis")
    main_log.info("Output dir: %s", base_output)
    h5_manager = build_scanner3d_h5_manager()
    any_failed = False
    for cam in cfg.cameras:
        main_log.info("Start camera %s", cam)
        camera_output = base_output / f"{cam.scanner_name}/{cam.camera.name}"
        ensure_folder(camera_output)
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        camera_log = camera_output / f"camera_analyses_{timestamp}.log"
        with log_manager.capture_all_to_file(file_path=camera_log, level=log_level):
            result = cam.analyze(
                out_folder=camera_output,
                analyses=cfg.analyses,
                log_manager=log_manager,
                h5_manager=h5_manager)
        main_log.info(
            "%s [%d]: %s (%d analyses, %d failed, total=%.3f s) Full log: %s",
            cam.scanner_name,
            cam.index,
            "PASS" if result.ok else "FAIL",
            result.n_analyses,
            result.n_failed,
            result.metrics.camera_analysis_duration,
            camera_log)
        any_failed |= result.ok is not True
    if any_failed:
        main_log.error("Some cameras failed")
        return 2
    main_log.info("All cameras passed all analyses.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(cfg=DEFAULT_CFG))
