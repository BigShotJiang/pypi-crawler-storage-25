import logging
from typing import Any
from gosti.batch_raytrace.raytrace_settings import RayTraceSettings
from gosti.distortion.distortion_model import DistortionModel
from gosti.grid.grid_metric import FieldMetric
from scanner3d.analysis.base.analysis import Analysis
from scanner3d.analysis.base.analysis_context import AnalysisContext
from scanner3d.analysis.base.analysis_meta import AnalysisMeta
from scanner3d.analysis.base.result_layout import ResultLayout
from scanner3d.analysis.case.case_output import CaseOutput
from scanner3d.analysis.registry.registry import Registry
from scanner3d.analysis.distortion.distortion_settings import DistortionSettings
from scanner3d.analysis.distortion.trace_ray_pair import trace_ray_pairs
from scanner3d.tuner.tuner_settings.tuner_settings_presets import single_field_rectangular
from scanner3d.analysis.analysis_definition.analysis_definition import AnalysisDefinition
from scanner3d.afs.album.album import Album

log = logging.getLogger(__name__)
class DistortionAnalysis(Analysis):
    def __init__(self, *,
                 analysis_settings,
                 tuner_settings,
                 analysis_def: AnalysisDefinition,
                 distortion_settings: DistortionSettings,
                 raytrace_settings: RayTraceSettings) -> None:
        super().__init__(analysis_settings=analysis_settings, tuner_settings=tuner_settings)
        self.distortion_settings = distortion_settings
        self.raytrace_settings = raytrace_settings
        self.analysis_def = analysis_def

    def iter_cases(self, *, ctx: AnalysisContext) -> list[Any]:
        return [self.distortion_settings.name]

    def compute_case(self, *,
                     ctx: AnalysisContext,
                     meta: AnalysisMeta,
                     layout: ResultLayout,
                     registry: Registry,
                     case: Any) -> CaseOutput:

        grid_rays = list(self.distortion_settings.iter_field_rays())
        single_settings = self.raytrace_settings.with_rays([self.distortion_settings.ray_sample_focus])
        matrix_settings = self.raytrace_settings.with_rays(grid_rays).replace_grid(grid=ctx.camera.sensor.shape)
        with ctx.tuner.tune(settings=self.tuner_settings):
            ray_pairs_focus = trace_ray_pairs(ctx=ctx, raytrace_settings=single_settings)
            ray_pairs_grid  = trace_ray_pairs(ctx=ctx, raytrace_settings=matrix_settings)
        dist = DistortionModel.from_samples(
            ray_pairs_focus=ray_pairs_focus, ray_sample_focus=self.distortion_settings.ray_sample_focus,
            ray_pairs_grid=ray_pairs_grid, field_grid=self.distortion_settings.field_grid)
        case_folder = layout.result_folder()
        csv_path = case_folder / "distortion_table.csv"
        df = dist.to_dataframe()
        df.to_csv(csv_path, index=False, float_format="%.12g")
        log.info("Saved distortion table to %s", csv_path)

        metric = FieldMetric(
            field_edge_xy=[(ctx.camera.sensor.width / 2, ctx.camera.sensor.height / 2)])

        album_settings = album_points_like_field_grid(
            name="Distortion",
            field_grid=self.distortion_settings.field_grid,
            metric=metric,
            z_values=[ctx.camera.z_range.z_focus],
        )
        with ctx.tuner.tune(settings=single_field_rectangular):
            with self.analysis_def.get_analysis(ctx.zemod) as zemod_analysis:
                zemod_analysis.settings.apply_settings(self.analysis_def.settings)
                x_seq = album_settings.get_x_axis()
                y_seq = album_settings.get_y_axis()
                z_seq = album_settings.get_z_seq(ctx.camera.z_range)
                album = Album.compute(
                    tuner=ctx.tuner,
                    zemod_analysis=zemod_analysis,
                    analysis_def=self.analysis_def,
                    album_settings=album_settings,
                    x_seq=x_seq,
                    y_seq=y_seq,
                    z_seq=z_seq)



        return CaseOutput(
            case_kind="distortion",
            case_filename=str(case),
            payload=dist,
            settings_bundle=(
                self.tuner_settings,
                self.raytrace_settings,
                self.distortion_settings),
            extra_folder=None)