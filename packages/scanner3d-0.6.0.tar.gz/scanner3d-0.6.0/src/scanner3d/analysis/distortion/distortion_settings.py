from typing import Iterator
from gosti.grid.field_grid_rectangle import FieldGridRectangle
from dataclasses import dataclass
from gosti.ray.ray_sample import RaySample
from gosti.norm import NormalizedPupilCenter, NormalizedSmallField

@dataclass(frozen=True, slots=True)
class DistortionSettings:
    name:str
    ray_sample_focus: RaySample
    field_grid: FieldGridRectangle


    def iter_field_rays(self) -> Iterator[RaySample]:
        for field in self.field_grid:
            yield RaySample(field, NormalizedPupilCenter)

    def __str__(self) -> str:
        return (
            "DistortionSettings(\n"
            f"  ray_sample_focus={self.ray_sample_focus},\n"
            f"  field_grid={self.field_grid}\n"
            ")"
        )

distortion_settings_grid = DistortionSettings(
    name="distortion grid 25x25",
    ray_sample_focus=RaySample(NormalizedSmallField,NormalizedPupilCenter),
    field_grid= FieldGridRectangle(25, 25))