def build_field_samples(
    initial: float,
    total_points: int,
) -> list[float]:

    if total_points <= 0:
        raise ValueError("total_points must be > 0")

    return [initial] + [i / total_points for i in range(1, total_points + 1)]