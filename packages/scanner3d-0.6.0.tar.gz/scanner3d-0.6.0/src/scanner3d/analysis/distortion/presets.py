from scanner3d.analysis.distortion.distortion_analysis import DistortionAnalysis
from scanner3d.analysis.distortion.distortion_settings import distortion_settings_grid
from scanner3d.analysis.base.analysis_settings import AnalysisSettings
from scanner3d.tuner.tuner_settings.tuner_settings_presets import second_field_rectangular
from scanner3d.analysis.batch_raytrace.settings_presets import single_unpolarized
from scanner3d.analysis.analysis_definition.presets import ANALYSES
from scanner3d.analysis.analysis_types import AnalysisTypes

distortion_test = DistortionAnalysis(
    analysis_settings=AnalysisSettings(analysis_name="Distortion"),
    distortion_settings=distortion_settings_grid,
    tuner_settings=second_field_rectangular,
    raytrace_settings=single_unpolarized,
    analysis_def=ANALYSES[AnalysisTypes.ZERNIKE_STANDARD])