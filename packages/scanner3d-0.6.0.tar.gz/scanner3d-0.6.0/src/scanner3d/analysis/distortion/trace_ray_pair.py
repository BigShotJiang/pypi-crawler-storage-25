from gosti.ray.ray_3d import Ray3D
from gosti.ray.ray_pair import RayPair
from gosti.batch_raytrace.trace_method import TraceMethod
from gosti.batch_raytrace.rays_of import rays_of
from zemod.tools.zemod_tool_list import ZeModToolList
from gosti.batch_raytrace.raytrace_settings import RayTraceSettings

def trace_ray_pairs(
    *,
    ctx,
    raytrace_settings: RayTraceSettings,
) -> list[RayPair]:
    """
    Traces the same RaySamples to object and image surfaces
    and returns paired Ray3D rays.
    """
    raytrace_object = ctx.zemod.tools.run_tool(
        ZeModToolList.BATCH_RAYTRACE,
        raytrace_settings.replace_surface(ctx.zemod.lde.object_surfaces_n))
    raytrace_image = ctx.zemod.tools.run_tool(
        ZeModToolList.BATCH_RAYTRACE,
        raytrace_settings.replace_surface(ctx.zemod.lde.image_surfaces_n))
    rays_obj = rays_of(TraceMethod.Normal_Unpolarized, raytrace_object.rays)
    rays_img = rays_of(TraceMethod.Normal_Unpolarized, raytrace_image.rays)
    if len(rays_obj) != len(rays_img):
        raise ValueError(f"Ray count mismatch: obj={len(rays_obj)}, img={len(rays_img)}")
    ray3d_obj = [Ray3D.from_zempy_unpolarized(r) for r in rays_obj]
    ray3d_img = [Ray3D.from_zempy_unpolarized(r) for r in rays_img]
    return [RayPair(obj=ro, img=ri)for ro, ri in zip(ray3d_obj, ray3d_img)]

