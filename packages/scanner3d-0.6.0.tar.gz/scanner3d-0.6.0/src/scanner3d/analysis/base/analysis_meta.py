from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True, slots=True)
class AnalysisMeta:
    analysis_name: str
    scanner_name: str
    output_root: Path
