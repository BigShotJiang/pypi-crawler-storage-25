from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from allytools.files import ensure_folder
from allytools.strings import sanitize
from scanner3d.analysis.base.analysis_meta import AnalysisMeta

@dataclass(slots=True)
class ResultLayout:
    meta: AnalysisMeta

    def result_folder(self, extra_folder: Optional[str] = None) -> Path:
        folder = (
            self.meta.output_root / self.meta.analysis_name / extra_folder
            if extra_folder
            else self.meta.output_root / self.meta.analysis_name
        )
        ensure_folder(folder)
        return folder

    def h5_path(self, *, folder: Path, settings_name: str) -> Path:
        stem = "_".join(map(sanitize, (self.meta.scanner_name, self.meta.analysis_name, settings_name)))
        return (folder / stem).with_suffix(".h5")