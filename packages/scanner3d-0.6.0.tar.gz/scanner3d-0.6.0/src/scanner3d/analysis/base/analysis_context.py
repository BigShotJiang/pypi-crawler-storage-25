from zemod.zemod import ZeMod
from scanner3d.tuner.tuner import Tuner
from scanner3d.camera3d.camera3d import Camera3D
from h5kit import H5IOManager

class AnalysisContext:
    def __init__(self, camera: Camera3D, zemod: ZeMod, h5_manager: H5IOManager, scanner_name:str) -> None:
        self.camera = camera
        self.zemod = zemod
        self.h5_manager = h5_manager
        self.tuner = Tuner(zemod=zemod, camera=camera)
        self.scanner_name = scanner_name

