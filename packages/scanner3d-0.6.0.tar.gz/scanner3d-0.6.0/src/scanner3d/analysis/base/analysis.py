import logging
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Sequence, TypeVar
from scanner3d.analysis.base.analysis_context import AnalysisContext
from scanner3d.analysis.base.result_layout import ResultLayout
from scanner3d.analysis.base.analysis_result import AnalysisResult
from scanner3d.analysis.base.analysis_meta import AnalysisMeta
from scanner3d.analysis.base.outcome import Outcome
from scanner3d.analysis.registry.registry import Registry
from scanner3d.analysis.registry.registry_default import DefaultRegistry
from scanner3d.analysis.case.case_result import CaseResult
from scanner3d.analysis.case.case_output import CaseOutput
from scanner3d.analysis.base.analysis_settings import AnalysisSettings
from scanner3d.tuner.tuner_settings.tuner_settings import TunerSettings

TCase = TypeVar("TCase")

log = logging.getLogger(__name__)
class Analysis(ABC):

    def __init__(self, *, analysis_settings:AnalysisSettings, tuner_settings: TunerSettings) -> None:
        self.analysis_settings = analysis_settings
        self.tuner_settings = tuner_settings

    @property
    def analysis_name(self)->str:
        return self.analysis_settings.analysis_name

    @property
    def enabled(self)->bool:
        return self.analysis_settings.enabled

    @property
    def enable_h5_save(self)->bool:
        return self.analysis_settings.enable_h5_save

    @abstractmethod
    def iter_cases(self, *, ctx: AnalysisContext) -> Sequence[TCase]:
        raise NotImplementedError

    @abstractmethod
    def compute_case(
        self,
        *,
        ctx: AnalysisContext,
        meta: AnalysisMeta,
        layout: ResultLayout,
        registry: Registry,
        case: TCase,
    ) -> CaseOutput:
        raise NotImplementedError

    def run(self, *, ctx: AnalysisContext, output_root: Path) -> AnalysisResult:
        meta = AnalysisMeta(
            analysis_name=self.analysis_name,
            scanner_name=ctx.scanner_name,
            output_root=output_root)
        layout = ResultLayout(meta=meta)
        registry: Registry = DefaultRegistry(meta=meta)
        if not self.enabled:
            return AnalysisResult(
                analysis_name=meta.analysis_name,
                scanner_name=meta.scanner_name,
                outcome=Outcome.SKIPPED,
                elapsed_s=0.0,
                cases=[])
        t0 = time.perf_counter()
        cases = list(self.iter_cases(ctx=ctx))
        case_results: list[CaseResult] = []
        overall = Outcome.PASSED
        for case in cases:
            try:
                case_t0 = time.perf_counter()
                out = self.compute_case(ctx=ctx, meta=meta, layout=layout, registry=registry, case=case)
                out.elapsed_time = time.perf_counter() - case_t0
                case_res = self._persist_case(layout=layout,registry=registry,out=out, ctx=ctx)
            except Exception as e:
                log.exception("case failed in %s", self.analysis_name)
                case_res = CaseResult(
                    name=str(case),
                    outcome=Outcome.FAILED,
                    elapsed_time=0.0,
                    artifacts={},
                    message=str(e))
            case_results.append(case_res)
            if case_res.outcome == Outcome.FAILED:
                overall = Outcome.FAILED
        elapsed = time.perf_counter() - t0
        return AnalysisResult(
            analysis_name=meta.analysis_name,
            scanner_name=meta.scanner_name,
            outcome=overall,
            elapsed_s=elapsed,
            cases=case_results)

    def _persist_case(self, *, layout: ResultLayout, registry: Registry, out: CaseOutput, ctx:AnalysisContext) -> CaseResult:
        folder = layout.result_folder(extra_folder=out.extra_folder)
        h5_path = layout.h5_path(folder=folder, settings_name=out.case_filename)
        wrote_h5 = False
        ok = True
        if self.enable_h5_save and out.payload is not None:
            ctx.h5_manager.save(path=h5_path, obj=out.payload)
            log.info("Payload saved to HDF5: %s", h5_path)
            wrote_h5 = True
            ok = registry.verify_file(h5_path)

        for hook in out.post_write:
            try:
                hook(folder, h5_path)
            except Exception:
                log.exception("post_write hook failed: analysis=%s case=%s",self.analysis_name,out.case_filename)

        if out.settings_bundle:
            registry.save_settings_bundle(folder, out.settings_bundle)
        artifacts_map = dict(out.extra_artifacts)
        if wrote_h5 and ok:
            artifacts_map["h5"] = h5_path
        case_result = CaseResult(
            name=out.case_filename,
            outcome=Outcome.PASSED if ok else Outcome.FAILED,
            elapsed_time=out.elapsed_time,
            artifacts=artifacts_map)
        registry.register_case_result(kind=out.case_kind, case=case_result)
        return case_result