from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence, TYPE_CHECKING
from scanner3d.analysis.camera_analysis.camera_analysis  import CameraAnalysis
from scanner3d.analysis.base.analysis import Analysis
if TYPE_CHECKING:
    from scanner3d.analysis.presets import ANALYSIS_PRESETS, CAMERA_PRESETS

@dataclass(frozen=True)
class RunConfig:
    analyses: Sequence[Analysis]
    cameras: Sequence[CameraAnalysis]
    output: Path | None = None
    fail_fast: bool = False


def cfg_from_args(args) -> RunConfig:
    return RunConfig(
        analyses=tuple(ANALYSIS_PRESETS[args.analyses]),
        cameras=tuple(CAMERA_PRESETS[args.cameras]),
        output=args.output,
        fail_fast=args.fail_fast)
