from enum import Enum

class Outcome(str, Enum):
    SKIPPED = "skipped"
    PASSED = "passed"
    FAILED = "failed"
