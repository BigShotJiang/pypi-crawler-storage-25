from dataclasses import dataclass, field
from scanner3d.analysis.base.outcome import Outcome
from scanner3d.analysis.case.case_result import CaseResult

@dataclass(slots=True)
class AnalysisResult:
    analysis_name: str
    scanner_name: str
    outcome: Outcome
    elapsed_s: float
    cases: list[CaseResult] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return self.outcome == Outcome.PASSED