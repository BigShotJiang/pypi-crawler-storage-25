class AnalysisSettings:

    def __init__(
        self, *, analysis_name: str, enabled: bool = True, enable_h5_save:bool = True) -> None:
        self.analysis_name = analysis_name
        self.enabled = enabled
        self.enable_h5_save = enable_h5_save

