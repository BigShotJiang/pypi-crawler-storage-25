from dataclasses import dataclass, field
from pathlib import Path
from scanner3d.analysis.base.outcome import Outcome

@dataclass(slots=True)
class CaseResult:
    name: str
    outcome: Outcome
    elapsed_time: float
    artifacts: dict[str, Path] = field(default_factory=dict)
    message: str = ""