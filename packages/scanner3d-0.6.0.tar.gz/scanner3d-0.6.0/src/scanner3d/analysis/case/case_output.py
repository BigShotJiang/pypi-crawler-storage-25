from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

PostWriteHook = Callable[[Path, Path], None]

@dataclass(slots=True)
class CaseOutput:
    case_kind:str
    case_filename: str
    elapsed_time: float = 0.0
    payload: Optional[object] = None
    settings_bundle: tuple[Any, ...] = ()
    extra_artifacts: dict[str, Path] = field(default_factory=dict)
    extra_folder: str | None = None
    post_write: list[PostWriteHook] = field(default_factory=list)
