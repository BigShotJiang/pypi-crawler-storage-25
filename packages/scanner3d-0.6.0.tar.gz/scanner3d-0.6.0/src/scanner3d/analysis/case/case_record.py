from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

@dataclass(slots=True)
class CaseRecord:
    scanner_name: str
    analysis_name: str
    case_name: str
    kind: str
    outcome: str
    elapsed_time: float
    artifacts: dict[str, str] = field(default_factory=dict)
    camera_name: str | None = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CaseRecord:
        return cls(
            scanner_name=str(data["scanner_name"]),
            analysis_name=str(data["analysis_name"]),
            case_name=str(data["case_name"]),
            kind=str(data["kind"]),
            outcome=str(data["outcome"]),
            elapsed_time=float(data["elapsed_time"]),
            artifacts={str(k): str(v) for k, v in (data.get("artifacts") or {}).items()},
            camera_name=data.get("camera_name"),
            timestamp=str(data.get("timestamp") or ""))
