from __future__ import annotations

from typing import Dict

from zemod.presets import zernike_standard_37, fft_psf, huygens_psf
from scanner3d.analysis.analysis_definition.analysis_definition import AnalysisDefinition
from scanner3d.analysis.analysis_types import AnalysisTypes
from scanner3d.analysis.batch_raytrace.settings_presets import normal_unpolarized_2
from gosti.batch_raytrace.ray_batch import RayBatch
from gosti.batch_raytrace.ray_batch_type import RayBatchType

from scanner3d.afs.shot_result.shot_result_array import ShotResultArray
from scanner3d.afs.shot_result.shot_result_ray_batch import ShotResultRayBatch
from scanner3d.afs.shot_result.shot_result_zernike import ShotResultZernike


def _run_batch_tool(t):
    t.run_wait_for_completion()
    return t


ANALYSES: Dict[AnalysisTypes, AnalysisDefinition] = {
    AnalysisTypes.FFT_PSF: AnalysisDefinition(
        resource_factory=lambda z: z.get_fftpsf(),
        settings=fft_psf,
        apply_settings=lambda a, s, z: a.settings.apply_settings(s),
        run_resource=lambda a: a.run(),
        result_factory=lambda r: ShotResultArray.from_native_result(r.get_data_grid(0)),
    ),

    AnalysisTypes.HUYGENS_PSF: AnalysisDefinition(
        resource_factory=lambda z: z.get_huygens_psf(),
        settings=huygens_psf,
        apply_settings=lambda a, s, z: a.settings.apply_settings(s),
        run_resource=lambda a: a.run(),
        result_factory=lambda r: ShotResultArray.from_native_result(r.get_data_grid(0)),
    ),

    AnalysisTypes.ZERNIKE_STANDARD: AnalysisDefinition(
        resource_factory=lambda z: z.get_zernike_standard_coefficients(),
        settings=zernike_standard_37,
        apply_settings=lambda a, s, z: a.settings.apply_settings(s),
        run_resource=lambda a: a.run(),
        result_factory=lambda r: ShotResultZernike.from_native_result(r.get_text_file()),
    ),

    AnalysisTypes.BATCH_PUPIL_RAYS: AnalysisDefinition(
        resource_factory=lambda z: z.get_raytracer(),
        settings=normal_unpolarized_2,
        apply_settings=lambda t, s, z: t.apply_settings(
            s.replace_surface(RayBatchType.OnLastSurface.to_surface(z.lde))),
        run_resource=_run_batch_tool,
        result_factory=lambda t: ShotResultRayBatch(
            RayBatch.from_settings(
                batch_type=RayBatchType.OnLastSurface,
                rays=t.rays,
                process_time=t.generic_tracer.process_time,
                settings=t.settings,
            )
        ),
    ),
}