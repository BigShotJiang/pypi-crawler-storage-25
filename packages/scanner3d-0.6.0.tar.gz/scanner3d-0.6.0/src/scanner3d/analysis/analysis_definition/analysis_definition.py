from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Generic
from contextlib import AbstractContextManager
from zemod.zemod import ZeMod
from scanner3d.analysis.aliases import TRawResult, TResource, TSettings
from scanner3d.afs.shot_result.shot_result_like import ShotResultLike

@dataclass
class AnalysisDefinition(Generic[TResource, TSettings, TRawResult]):
    resource_factory: Callable[[ZeMod], AbstractContextManager[TResource]]
    settings: TSettings
    apply_settings: Callable[[TResource, TSettings, ZeMod], None]
    run_resource: Callable[[TResource], TRawResult]
    result_factory: Callable[[TRawResult], ShotResultLike]

    def get_resource(self, zemod: ZeMod) -> AbstractContextManager[TResource]:
        return self.resource_factory(zemod)

    def configure(self, resource: TResource, zemod:ZeMod) -> None:
        self.apply_settings(resource, self.settings, zemod)

    def run(self, resource: TResource) -> TRawResult:
        return self.run_resource(resource)

    def get_result(self, raw: TRawResult) -> ShotResultLike:
        return self.result_factory(raw)