from __future__ import annotations
from scanner3d.analysis.base.outcome import Outcome
from scanner3d.analysis.base.analysis_result import AnalysisResult
from scanner3d.analysis.camera_analysis.camera_analysis_metrics import CameraAnalysisMetrics


class CameraAnalysisResult:
    __slots__ = ("camera_name", "analysis_results", "ok", "reason", "metrics")

    def __init__(
        self,
        camera_name: str,
        analysis_results: list[AnalysisResult] | None = None,
        *,
        ok: bool | None = None,
        reason: str = "",
        metrics: CameraAnalysisMetrics | None = None,
    ) -> None:
        self.camera_name = camera_name
        self.analysis_results = analysis_results or []
        self.metrics = metrics or CameraAnalysisMetrics()
        if ok is not None:
            self.ok = ok
            self.reason = reason
            return

        failed = [r for r in self.analysis_results if r.outcome == Outcome.FAILED]
        self.ok = len(failed) == 0

        if failed and not reason:
            names = [r.analysis_name for r in failed]
            self.reason = f"{len(names)} failed: {', '.join(names)}"
        else:
            self.reason = reason

    @property
    def passed_results(self) -> list[AnalysisResult]:
        return [r for r in self.analysis_results if r.outcome == Outcome.PASSED]

    @property
    def failed_results(self) -> list[AnalysisResult]:
        return [r for r in self.analysis_results if r.outcome == Outcome.FAILED]

    @property
    def skipped_results(self) -> list[AnalysisResult]:
        return [r for r in self.analysis_results if r.outcome == Outcome.SKIPPED]

    @property
    def failed_analysis_names(self) -> list[str]:
        return [r.analysis_name for r in self.failed_results]

    @property
    def n_analyses(self) -> int:
        return len(self.analysis_results)

    @property
    def n_failed(self) -> int:
        return len(self.failed_results)

    def __repr__(self) -> str:
        return (
            f"CameraAnalysisResult(camera_name={self.camera_name!r}, ok={self.ok!r}, "
            f"n_analyses={self.n_analyses}, n_failed={self.n_failed}, reason={self.reason!r})")