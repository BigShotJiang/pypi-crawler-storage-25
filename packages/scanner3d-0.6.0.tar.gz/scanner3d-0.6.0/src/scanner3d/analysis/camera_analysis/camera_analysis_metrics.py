from time import perf_counter


class CameraAnalysisMetrics:
    __slots__ = ("_start_time", "_stop_time")

    def __init__(self) -> None:
        self._start_time = 0.0
        self._stop_time = 0.0

    def start(self) -> None:
        self._start_time = perf_counter()
        self._stop_time = 0.0

    def stop(self) -> None:
        self._stop_time = perf_counter()

    @property
    def camera_analysis_duration(self) -> float:
        if self._stop_time == 0.0:
            return perf_counter() - self._start_time
        return self._stop_time - self._start_time
