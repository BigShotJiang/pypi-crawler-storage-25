import logging
from pathlib import Path
from dataclasses import dataclass
from typing import Sequence
from allytools.logger import LoggingManager
from zemod.zemod import ZeMod
from zempy.bridge.zempy_session import zempy_session
from scanner3d.camera3d.camera3d import Camera3D
from scanner3d.scanner.scanner import Scanner
from scanner3d.analysis.base.analysis import Analysis
from scanner3d.analysis.camera_analysis.camera_analysis_result import CameraAnalysisResult
from scanner3d.analysis.camera_analysis.camera_analysis_metrics import CameraAnalysisMetrics
from scanner3d.analysis.analyses_suit import AnalysesSuite
from h5kit import H5IOManager

@dataclass(frozen=True)
class CameraAnalysis:
    scanner: Scanner
    index: int

    @property
    def camera(self) -> Camera3D:
        return self.scanner.cameras[self.index]

    @property
    def scanner_name(self) -> str:
        return self.scanner.name

    def analyze(
            self,
            *,
            out_folder: Path,
            analyses: Sequence[Analysis],
            log_manager: LoggingManager,
            h5_manager:H5IOManager) -> CameraAnalysisResult:
        cam_log = log_manager.logger(f"scanner3d.camera.{self.scanner_name}.{self.camera.name}", level=logging.DEBUG)
        cam_log.info(
            "=== Starting analysis for %s [%d] (%s) ===",
            self.scanner_name,
            self.index,
            self.camera.name)

        zmx_path = self.camera.objective.zmx_file
        analyses_suit = AnalysesSuite(analyses=analyses)
        metrics = CameraAnalysisMetrics()
        metrics.start()
        try:
            with zempy_session(zmx_path) as (_zs, system):
                zemod = ZeMod.from_optical_system(system)
                results = analyses_suit.run(
                    zemod=zemod,
                    camera=self.camera,
                    output_root=out_folder,
                    h5_manager=h5_manager,
                    scanner_name=self.scanner_name)
        except Exception as e:
            cam_log.exception("Camera analysis failed")
            return CameraAnalysisResult(
                camera_name=self.camera.name,
                analysis_results=[],
                ok=False,
                reason=str(e),
                metrics=metrics)
        finally:
            metrics.stop()
        for res in results:
            mark = "✔" if res.success else "✖"
            cam_log.info("%s %s  %.2f s", mark, res.analysis_name, res.elapsed_s)
        result = CameraAnalysisResult(camera_name=self.camera.name, analysis_results=results,metrics=metrics)
        cam_log.info("Summary: %d analyses, %d failed",result.n_analyses,result.n_failed)
        cam_log.info("Timing: total=%.3f s",result.metrics.camera_analysis_duration)
        return result
