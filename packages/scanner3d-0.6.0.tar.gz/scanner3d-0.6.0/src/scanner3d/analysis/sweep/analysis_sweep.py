import logging
from scanner3d.analysis.base.analysis import Analysis
from scanner3d.analysis.base.analysis_context import AnalysisContext
from scanner3d.analysis.base.analysis_meta import AnalysisMeta
from scanner3d.analysis.base.result_layout import ResultLayout
from scanner3d.analysis.case.case_output import CaseOutput
from scanner3d.analysis.registry.registry import Registry
from scanner3d.analysis.analysis_definition.analysis_definition import AnalysisDefinition
from scanner3d.afs.album_settings.album_settings import AlbumSettings

log = logging.getLogger(__name__)
class AnalysisSweep(Analysis):
    def __init__(self, *,
                 analysis_settings,
                 tuner_settings,
                 analysis_def: AnalysisDefinition,
                 albums_settings: list[AlbumSettings]) -> None:
        super().__init__(analysis_settings=analysis_settings,tuner_settings=tuner_settings)
        self.analysis_def = analysis_def
        self.albums_settings = albums_settings

    def iter_cases(self, *, ctx: AnalysisContext) -> list[AlbumSettings]:
        return self.albums_settings

    def compute_case(
        self,
        *,
        ctx: AnalysisContext,
        meta: AnalysisMeta,
        layout: ResultLayout,
        registry: Registry,
        case: AlbumSettings,
    ) -> CaseOutput:
        from scanner3d.afs.album.album import Album
        with ctx.tuner.tune(settings=self.tuner_settings):
            x_seq = case.get_x_seq(ctx.camera.sensor.grid)
            y_seq = case.get_y_seq(ctx.camera.sensor.grid)
            z_seq = case.get_z_seq(ctx.camera.z_range)
            album = Album.compute(
                zemod = ctx.zemod,
                tuner=ctx.tuner,
                analysis_def=self.analysis_def,
                album_settings=case,
                x_seq=x_seq,
                y_seq=y_seq,
                z_seq=z_seq)
        def save_images(folder, h5_path):
            if not case.enable_image_save:
                return
            for frame in album.frames:
                img_path = h5_path.with_name(f"{h5_path.stem}_{frame.z_mm:.1f}.png")
                frame.plot().save(str(img_path))
                log.info("Frame saved as image: %s", img_path)

        return CaseOutput(
            case_kind="album",
            case_filename=case.name,
            payload=album,
            settings_bundle=(
                self.tuner_settings,
                case,
                self.analysis_def.settings),
            extra_folder=case.name,
            post_write=[save_images])
