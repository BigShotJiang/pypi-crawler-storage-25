from scanner3d.analysis.base.analysis_settings import AnalysisSettings
from scanner3d.analysis.sweep.analysis_sweep import AnalysisSweep
from scanner3d.analysis.analysis_definition.presets import ANALYSES
from scanner3d.analysis.analysis_types import AnalysisTypes
from scanner3d.afs.album_settings import *
from scanner3d.tuner.tuner_settings.tuner_settings_presets import single_field_rectangular, second_field_rectangular, second_field_radial_on_axis


psf_coarse = AnalysisSweep(
    analysis_settings=AnalysisSettings(analysis_name="FFT PSF coarse"),
    analysis_def=ANALYSES[AnalysisTypes.FFT_PSF],
    albums_settings=[album_major_frames_3x3,
                     album_radial_coarse,
                     album_sparse_grid_coarse],
    tuner_settings=single_field_rectangular)


psf_detailed = AnalysisSweep(
    analysis_settings=AnalysisSettings(analysis_name="FFT PSF detailed"),
    analysis_def=ANALYSES[AnalysisTypes.FFT_PSF],
    albums_settings=[album_major_frames_5x5,
                     album_radial_detailed,
                     album_sparse_grid_detailed],
    tuner_settings=single_field_rectangular)


huygens_psf_coarse = AnalysisSweep(
    analysis_settings=AnalysisSettings(analysis_name="Huygens PSF coarse"),
    analysis_def=ANALYSES[AnalysisTypes.HUYGENS_PSF],
    albums_settings=[album_major_frames_3x3,album_radial_coarse],
    tuner_settings=single_field_rectangular)


huygens_psf_detailed = AnalysisSweep(
    analysis_settings=AnalysisSettings(analysis_name="Huygens PSF detailed"),
    analysis_def=ANALYSES[AnalysisTypes.HUYGENS_PSF],
    albums_settings=[album_radial_detailed],
    tuner_settings=single_field_rectangular)

zernike_coarse = AnalysisSweep(
    analysis_settings=AnalysisSettings(analysis_name="Zernike coarse"),
    analysis_def=ANALYSES[AnalysisTypes.ZERNIKE_STANDARD],
    albums_settings=[album_radial_coarse,album_sparse_grid_coarse],
    tuner_settings=single_field_rectangular)

zernike_detailed = AnalysisSweep(
    analysis_settings=AnalysisSettings(analysis_name="Zernike detailed"),
    analysis_def=ANALYSES[AnalysisTypes.ZERNIKE_STANDARD],
    albums_settings=[album_radial_detailed],
    tuner_settings=single_field_rectangular)

batch_pupil_rays = AnalysisSweep(
    analysis_settings=AnalysisSettings(analysis_name="Batch pupil rays"),
    analysis_def=ANALYSES[AnalysisTypes.BATCH_PUPIL_RAYS],
    albums_settings=[album_radial_focus_only],
    tuner_settings=second_field_radial_on_axis)
