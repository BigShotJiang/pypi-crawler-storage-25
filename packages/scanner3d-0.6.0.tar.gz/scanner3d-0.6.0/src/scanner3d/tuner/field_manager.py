import logging
from dataclasses import dataclass, field
from typing import Optional, Tuple

from scanner3d.tuner.base_manager import BaseManager, _SENTINEL
from zemod.enums import ZeModFieldNormalizationType, ZeModFieldTypes
from zemod.zemod_field import ZeModField
from zemod.zemod_fields import ZeModFields

log = logging.getLogger(__name__)


@dataclass(slots=True)
class FieldManager(BaseManager):
    """
    Manages system fields:
      - Keeps field #1 on axis (0,0).
      - Syncs field type + normalization.
      - Optionally adds an extra field (#2) for rectangular normalization workflows.
      - revert(): restores type + normalization, removes field #2 if it was created,
        and ALWAYS resets field #1 back to (0,0).
    """
    fields: ZeModFields

    _test_field_number: int = field(init=False, default=_SENTINEL, repr=False)
    _orig_type: ZeModFieldTypes | object = field(init=False, default=_SENTINEL, repr=False)
    _orig_norm: ZeModFieldNormalizationType | object = field(init=False, default=_SENTINEL, repr=False)
    _added_field2: bool = field(init=False, default=False, repr=False)


    def apply(
        self,
        *,
        field_type: ZeModFieldTypes,
        normalization: ZeModFieldNormalizationType,
        test_field_number: Optional[int],
        extra_field: Optional[Tuple[float, float]],
    ) -> None:

        log.debug ("Field manager applying")
        self.sync_setting(
            label="field type",
            get=self.fields.get_field_type,
            set_=self.fields.set_field_type,
            target=field_type,
            orig_attr="_orig_type")
        self.sync_setting(
            label="normalization",
            get=self.fields.get_normalization,
            set_=self.fields.set_normalization,
            target=normalization,
            orig_attr="_orig_norm",
        )

        if extra_field is not None:
            x_mm, y_mm = extra_field
            self._added_field2 = (self.fields.n_fields == 1)
            self.add_edge_field(x_mm, y_mm)
            log.debug("Add extra field (%f, %f)", x_mm, y_mm)
        else:
            self._added_field2 = False
        self.set_test_field_number(test_field_number)

    @property
    def test_field_number(self) -> int:
        return self._test_field_number

    def set_test_field_number(self, n: Optional[int]) -> None:
        if n is None:
            log.warning("No test field specified. Default field (1) will be used.")
            self._test_field_number = 1
            return

        if not (1 <= n <= self.fields.n_fields):
            log.error("Invalid field number %d. Valid range is 1..%d.", n, self.fields.n_fields)
            raise ValueError(f"Field number {n} is out of valid range.")

        self._test_field_number = n

    def get_test_field(self) -> ZeModField:
        log.debug("Field manger provide field number %d", self.test_field_number)
        return self.fields.get_field(self.test_field_number)

    def check_fields_n(self, keep: int = 1) -> None:
        n_before = self.fields.n_fields
        if n_before > keep:
            log.warning(
                "system has %d fields (> %d); trimming to %d. not reversible in run-time",
                n_before, keep, keep)
            for i in range(n_before, keep, -1):
                try:
                    self.fields.delete_at(i)
                    log.debug("removed extra field #%d", i)
                except Exception as e:
                    log.exception("failed to remove field #%d (%s)", i, e)

        n_after = self.fields.n_fields
        log.debug("Check total fields number done, should be only %d left - %d", keep, n_after)

    def ensure_field1_on_axis(self, tol: float = 0.0) -> None:
        f1 = self.fields.get_field(1)

        curx, cury = float(f1.x), float(f1.y)
        log.debug("Field one set on axis  (%f, %f)", curx, cury)

        if abs(curx) <= tol and abs(cury) <= tol:
            log.debug(
                "%s.ensure_axis_first_field: already on-axis (%.3f, %.3f) within tol=%.3g",
                self.__class__.__name__, curx, cury, tol,
            )
            return

        f1.x, f1.y = 0.0, 0.0
        log.info(
            "%s.ensure_axis_first_field: (%.4f, %.4f) -> (0.0000, 0.0000)",
            self.__class__.__name__, curx, cury,
        )

    def add_edge_field(self, x: float, y: float) -> None:
        n = self.fields.n_fields
        if n == 1:
            self.fields.add_field(x, y)
            log.info("created field #2 at (%.3f, %.3f)", x, y)
        else:
            f2 = self.fields.get_field(2)
            oldx, oldy = float(f2.x), float(f2.y)
            if (oldx, oldy) != (x, y):
                log.info("field #2 (%.3f, %.3f) -> (%.3f, %.3f) — not reversible at runtime",oldx, oldy, x, y)
                f2.x, f2.y = x, y
            else:
                log.debug("field #2 already at (%.3f, %.3f)", x, y)

    def _revert_specs(self):
        yield dict(
            label="type",
            get=self.fields.get_field_type,
            set_=self.fields.set_field_type,
            orig_attr="_orig_type",
        )
        yield dict(
            label="normalization",
            get=self.fields.get_normalization,
            set_=self.fields.set_normalization,
            orig_attr="_orig_norm",
        )

    def _revert_added_field2(self) -> bool:
        if not self._added_field2:
            return False
        if self.fields.n_fields < 2:
            return False

        try:
            self.fields.delete_at(2)
            log.info("FieldManager.revert: removed extra field #2 (created during tune)")
            return True
        except Exception as e:
            log.exception("FieldManager.revert: failed to remove field #2 (%s)", e)
            return False

    def _reset_field1_to_axis(self, tol: float = 0.0) -> bool:
        f1 = self.fields.get_field(1)
        curx, cury = float(f1.x), float(f1.y)

        if abs(curx) <= tol and abs(cury) <= tol:
            return False

        f1.x, f1.y = 0.0, 0.0
        log.info(
            "FieldManager.revert: reset first-field XY: (%.4f, %.4f) -> (0.0000, 0.0000)",
            curx, cury,
        )
        return True

    def revert(self) -> None:
        did_anything = False

        for spec in self._revert_specs():
            did_anything |= self._revert_setting(**spec)

        did_anything |= self._revert_added_field2()

        # Always restore field#1 to axis (your invariant)
        did_anything |= self._reset_field1_to_axis(tol=1e-12)

        if not did_anything:
            log.debug("%s.revert: nothing to revert", self.__class__.__name__)
