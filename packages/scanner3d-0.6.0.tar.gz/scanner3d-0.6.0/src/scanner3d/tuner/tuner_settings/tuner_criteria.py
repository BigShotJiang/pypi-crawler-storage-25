from enum import Enum

class WavelengthCriteria(Enum):
    Primary = "Primary"

class FocusDistanceCriteria(Enum):
    BestFocus = "Best focus position from camera"
    AverageFocus = "Average between z_min and z_max"
