from zemod.enums.enums import ZeModFieldTypes, ZeModFieldNormalizationType
from isensor.sensor import SensorPosition, SensorPointRef
from scanner3d.tuner.tuner_settings.tuner_settings import TunerSettings
from scanner3d.tuner.tuner_settings.tuner_criteria import WavelengthCriteria, FocusDistanceCriteria

single_field_rectangular = TunerSettings(
    field_type=ZeModFieldTypes.RealImageHeight,
    filed_normalization=ZeModFieldNormalizationType.Rectangular,
    focus_distance_criteria=FocusDistanceCriteria.BestFocus,
    wavelength_criteria=WavelengthCriteria.Primary,
    analysis_field_number=1)

single_field_radial = TunerSettings(
    field_type=ZeModFieldTypes.RealImageHeight,
    filed_normalization=ZeModFieldNormalizationType.Radial,
    focus_distance_criteria=FocusDistanceCriteria.BestFocus,
    wavelength_criteria=WavelengthCriteria.Primary,
    analysis_field_number=1)

second_field_rectangular = TunerSettings(
    field_type=ZeModFieldTypes.RealImageHeight,
    filed_normalization=ZeModFieldNormalizationType.Rectangular,
    focus_distance_criteria=FocusDistanceCriteria.BestFocus,
    wavelength_criteria=WavelengthCriteria.Primary,
    analysis_field_number=1,
    extra_field_position=SensorPosition.TOP_RIGHT,
    extra_field_type=SensorPointRef.GEOMETRIC_EDGE)

second_field_radial = TunerSettings(
    field_type=ZeModFieldTypes.RealImageHeight,
    filed_normalization=ZeModFieldNormalizationType.Radial,
    focus_distance_criteria=FocusDistanceCriteria.BestFocus,
    wavelength_criteria=WavelengthCriteria.Primary,
    analysis_field_number=1,
    extra_field_position=SensorPosition.DIAGONAL,
    extra_field_type=SensorPointRef.GEOMETRIC_EDGE)

second_field_radial_on_axis = TunerSettings(
    field_type=ZeModFieldTypes.RealImageHeight,
    filed_normalization=ZeModFieldNormalizationType.Radial,
    focus_distance_criteria=FocusDistanceCriteria.BestFocus,
    wavelength_criteria=WavelengthCriteria.Primary,
    analysis_field_number=2,
    extra_field_position=SensorPosition.TOP_RIGHT,
    extra_field_type=SensorPointRef.GEOMETRIC_EDGE)