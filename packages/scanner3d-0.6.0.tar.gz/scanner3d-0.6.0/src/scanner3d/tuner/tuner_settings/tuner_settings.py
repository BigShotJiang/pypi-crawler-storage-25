from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Optional
from zemod.enums.enums import ZeModFieldTypes, ZeModFieldNormalizationType
from isensor.sensor import SensorPosition, SensorPointRef
from scanner3d.tuner.tuner_settings.tuner_criteria import FocusDistanceCriteria, WavelengthCriteria

@dataclass
class TunerSettings:
    field_type: ZeModFieldTypes
    filed_normalization : ZeModFieldNormalizationType
    focus_distance_criteria: Optional[FocusDistanceCriteria] =None
    wavelength_criteria: Optional[WavelengthCriteria] = None
    analysis_field_number: Optional[int] = None
    extra_field_position: Optional[SensorPosition] = None
    extra_field_type: Optional[SensorPointRef] = None

    def __post_init__(self) -> None:
        if self.extra_field_position is not None and self.extra_field_type is None:
            raise ValueError("extra_field_type must be specified when extra_field_position is set")

    def to_dict(self) -> dict:
        d = asdict(self)
        for key, value in d.items():
            if isinstance(value, Enum):
                d[key] = value.value
            elif isinstance(value, SensorPosition):
                d[key] = str(value)
        return d

    def __str__(self) -> str:
        parts = []
        for key, value in self.to_dict().items():
            parts.append(f"{key}={value}")
        body = "\n".join("  " + p for p in parts)
        return f"TunerSettings(\n{body}\n)"
