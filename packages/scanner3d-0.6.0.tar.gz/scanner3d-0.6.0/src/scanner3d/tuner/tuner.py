import logging
from contextlib import contextmanager
from typing import Optional, Tuple, Self
from collections.abc import Iterator
from dimetra.geo import Length
from zemod.zemod_fields import ZeModFields
from scanner3d.camera3d.camera3d import Camera3D
from zemod.zemod import ZeMod
from zemod.zemod_lde import ZeModLDE
from zemod.zemod_wavelengths import ZeModWavelengths
from scanner3d.tuner.surface_manager import SurfaceManager
from scanner3d.tuner.field_manager import FieldManager
from scanner3d.tuner.wavelength_manager import WavelengthManager
from scanner3d.tuner.reverse_stack import RevertStack
from scanner3d.tuner.tuner_settings.tuner_settings import TunerSettings, WavelengthCriteria, FocusDistanceCriteria
from scanner3d.tuner.profile import Profile
from isensor.sensor import SensorPosition, SensorPointRef


log = logging.getLogger(__name__)
class Tuner:
    __slots__ = ("zemod", "camera", "_settings", "_fm", "_wm", "_sm")

    def __init__(self, *, zemod: ZeMod, camera: Camera3D) -> None:
        self.zemod = zemod
        self.camera = camera
        self._settings: TunerSettings | None = None
        self._fm: FieldManager | None = None
        self._wm: WavelengthManager | None = None
        self._sm: SurfaceManager | None = None
        log.debug("Tuner initialized")

    @property
    def lde(self) -> ZeModLDE:
        return self.zemod.lde

    @property
    def fields(self) -> ZeModFields:
        return self.zemod.sd.fields

    @property
    def wavelengths(self) -> ZeModWavelengths:
        return self.zemod.sd.wavelengths

    @property
    def settings(self) -> TunerSettings:
        if self._settings is None:
            raise RuntimeError("Tuner is not in a tune() session")
        return self._settings

    @property
    def fm(self) -> FieldManager:
        if self._fm is None:
            raise RuntimeError("FieldManager not initialized (call tune())")
        return self._fm

    @property
    def wm(self) -> WavelengthManager:
        if self._wm is None:
            raise RuntimeError("WavelengthManager not initialized (call tune())")
        return self._wm

    @property
    def sm(self) -> SurfaceManager:
        if self._sm is None:
            raise RuntimeError("SurfaceManager not initialized (call tune())")
        return self._sm

    @contextmanager
    def tune(self, *, settings: TunerSettings)  -> Iterator[Self]:
        self._settings = settings
        self._fm = FieldManager(self.fields)
        self._wm = WavelengthManager(self.wavelengths)
        self._sm = SurfaceManager(self.zemod, self.lde)

        stack = RevertStack()
        with stack.session():
            stack.push(self.sm, self.wm, self.fm)
            self.fm.check_fields_n()  # First ensure that only one field used otherwise Surface Manger will focus to several!
            self.fm.ensure_field1_on_axis()
            self.wm.apply(primary_wavelength=self.get_wavelength())
            self.sm.apply(focus_distance=self.get_focus_distance())
            self.fm.apply(
                field_type=settings.field_type,
                normalization=settings.filed_normalization,
                test_field_number=settings.analysis_field_number,
                extra_field=self.get_extra_field(settings.extra_field_position, settings.extra_field_type))
            yield self

    def get_extra_field(
        self,
        field_position: Optional[SensorPosition],
        point_ref: Optional[SensorPointRef],
    ) -> Optional[Tuple[float, float]]:
        if field_position is None:
            return None
        if point_ref is None:
            raise ValueError("point_ref must be set when field_position is set")
        x_len, y_len = self.camera.sensor.grid.get_position(field_position, ref=point_ref)
        log.debug("extra filed x y are calculated (%.4f, %.4f)", x_len.value_mm, y_len.value_mm)
        return x_len.value_mm, y_len.value_mm

    def get_focus_distance(self) -> Optional[Length]:
        if self.settings.focus_distance_criteria == FocusDistanceCriteria.BestFocus:
            return self.camera.z_range.z_focus
        if self.settings.focus_distance_criteria == FocusDistanceCriteria.AverageFocus:
            raise NotImplementedError("AverageFocus distance is not implemented yet")
        return None

    def get_wavelength(self) -> Optional[Length]:
        if self.settings.wavelength_criteria == WavelengthCriteria.Primary:
            return self.camera.primary_wavelength
        else:
            raise NotImplementedError("AverageFocus distance is not implemented yet")

    def get_profile(self) -> Profile:
        sd = self.zemod.sd
        wr = self.lde.get_surface_at(self.sm.wd_index)
        fr = self.lde.get_surface_at(self.sm.focus_index)
        return Profile(
            file=self.zemod.file_name,
            name=self.zemod.system_name,
            title=sd.title,
            author=sd.author,
            notes=sd.notes if sd.notes is not None else "",  # TODO do I need this?
            working_distance=wr.thickness,
            focusing_distance=fr.thickness,
            sensor_model=self.camera.sensor.sensor_model.model,
            objective_id=self.camera.objective.objectiveID.model,
            f_number=self.camera.objective.f_number)
