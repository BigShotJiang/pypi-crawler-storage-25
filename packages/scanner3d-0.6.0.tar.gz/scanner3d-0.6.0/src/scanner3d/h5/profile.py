from __future__ import annotations

from h5kit.register.build_codec_registry import build_codec_registry
from h5kit.register.build_codec_registry_from_entry_points import (
    build_codec_registry_from_entry_points,
)
from h5kit.register.codec_registry import CodecRegistry
from scanner3d.h5 import register_codecs as register_scanner3d_codecs


SCANNER3D_EXTERNAL_CODEC_ENTRY_POINTS = (
    "dimetra",
    "isensor",
    "lensguild",
    "geopto",
    "gosti",
)

SCANNER3D_TEST_CODEC_PACKAGES = (
    "dimetra.h5.codec",
    "isensor.h5.codec",
    "lensguild.h5.codec",
    "geopto.h5.codec",
    "gosti.h5.codec",
)


def build_scanner3d_codec_registry() -> CodecRegistry:
    registry = CodecRegistry()
    register_scanner3d_codecs(registry)

    all_eps = build_codec_registry_from_entry_points()
    for codec in all_eps.iter_codecs():
        module_root = codec.__module__.split(".", 1)[0]
        if module_root in SCANNER3D_EXTERNAL_CODEC_ENTRY_POINTS:
            registry.register(codec, py_type=getattr(codec, "PY_TYPE", None))

    return registry


def build_scanner3d_test_codec_registry() -> CodecRegistry:
    registry = CodecRegistry()
    register_scanner3d_codecs(registry)

    external_registry = build_codec_registry(SCANNER3D_TEST_CODEC_PACKAGES)
    for codec in external_registry.iter_codecs():
        registry.register(codec, py_type=getattr(codec, "PY_TYPE", None))

    return registry