from __future__ import annotations

from h5kit.register.codec_registry import CodecRegistry

from scanner3d.h5.codec.camera3d_codec import Camera3DCodec
from scanner3d.h5.codec.album_codec import AlbumCodec
from scanner3d.h5.codec.album_settings_codec import AlbumSettingsCodec
from scanner3d.h5.codec.camera_position_codec import CameraPositionCodec
from scanner3d.h5.codec.frame_codec import FrameCodec
from scanner3d.h5.codec.frame_meta_codec import FrameMetaCodec
from scanner3d.h5.codec.grid_meta_codec import GridMetaCodec
from scanner3d.h5.codec.profile_codec import ProfileCodec
from scanner3d.h5.codec.scanner_codec import ScannerCodec
from scanner3d.h5.codec.shots_codec import ShotsCodec
from scanner3d.h5.codec.z_range_codec import ZRangeCodec
from scanner3d.h5.codec.zernike_meta_codec import ZernikeMetaCodec
from scanner3d.h5.codec.payload_analysis_codec import PayloadAnalysisCodec
from scanner3d.h5.codec.payload_zernike_codec import PayloadZernikeCodec


def register_codecs(registry: CodecRegistry) -> None:
    registry.register(Camera3DCodec, py_type=Camera3DCodec.PY_TYPE)
    registry.register(AlbumCodec, py_type=AlbumCodec.PY_TYPE)
    registry.register(AlbumSettingsCodec, py_type=AlbumSettingsCodec.PY_TYPE)
    registry.register(CameraPositionCodec, py_type=CameraPositionCodec.PY_TYPE)
    registry.register(FrameCodec, py_type=FrameCodec.PY_TYPE)
    registry.register(FrameMetaCodec, py_type=FrameMetaCodec.PY_TYPE)
    registry.register(GridMetaCodec, py_type=GridMetaCodec.PY_TYPE)
    registry.register(ProfileCodec, py_type=ProfileCodec.PY_TYPE)
    registry.register(ScannerCodec, py_type=ScannerCodec.PY_TYPE)
    registry.register(ShotsCodec, py_type=ShotsCodec.PY_TYPE)
    registry.register(ZRangeCodec, py_type=ZRangeCodec.PY_TYPE)
    registry.register(ZernikeMetaCodec, py_type=ZernikeMetaCodec.PY_TYPE)
    registry.register(PayloadAnalysisCodec, py_type=PayloadAnalysisCodec.PY_TYPE)
    registry.register(PayloadZernikeCodec, py_type=PayloadZernikeCodec.PY_TYPE)