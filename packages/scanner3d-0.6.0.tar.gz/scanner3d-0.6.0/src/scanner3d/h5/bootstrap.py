from __future__ import annotations
import logging
from h5kit import H5IOManager
from scanner3d.h5.profile import build_scanner3d_codec_registry

log = logging.getLogger(__name__)


def build_scanner3d_h5_manager() -> H5IOManager:
    log.info("=== Creating scanner3d H5IOManager ===")
    manager = H5IOManager(build_scanner3d_codec_registry())
    log.info("=== H5IOManager ready ===")
    return manager