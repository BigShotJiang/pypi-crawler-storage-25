from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar
from gosti.wavelength import Wavelength
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.camera3d import Camera3D, Camera3DTypes
from scanner3d.h5.codec.camera3d_codec_layout import CAMERA3D_CODEC_LAYOUT
from scanner3d.geo import CameraPosition, ZRange
from isensor.sensor import Sensor
from lensguild.objective import Objective

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class Camera3DCodec(H5CodecMixin, H5CodecLike[Camera3D]):
    PY_TYPE: ClassVar[type[Camera3D]] = Camera3D
    SCHEMA: ClassVar[str] = "scanner3d.camera3d.Camera3D"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = CAMERA3D_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: Camera3D) -> None:
        cls.clear_before_write(w)
        w.attr(CAMERA3D_CODEC_LAYOUT.name, obj.name)
        w.attr(CAMERA3D_CODEC_LAYOUT.type, obj.type.name)
        cls.write_obj(w, key=CAMERA3D_CODEC_LAYOUT.objective, obj=obj.objective)
        cls.write_obj(w, key=CAMERA3D_CODEC_LAYOUT.sensor, obj=obj.sensor)
        cls.write_obj(w, key=CAMERA3D_CODEC_LAYOUT.cam_pos, obj=obj.cam_pos)
        cls.write_obj(w, key=CAMERA3D_CODEC_LAYOUT.z_range, obj=obj.z_range)
        cls.write_obj(w, key=CAMERA3D_CODEC_LAYOUT.primary_wavelength, obj=obj.primary_wavelength, py_type=Wavelength)

    @classmethod
    def read(cls, r: H5Reader) -> Camera3D:
        type_name = r.require_attr(CAMERA3D_CODEC_LAYOUT.type, transform=str)
        try:
            camera_type = Camera3DTypes[type_name]
        except KeyError as exc:
            valid = ", ".join(Camera3DTypes.__members__.keys())
            raise ValueError(f"{cls.__name__}: unknown camera type {type_name!r}; expected one of [{valid}]") from exc
        objective = cls.require_obj_typed(r, CAMERA3D_CODEC_LAYOUT.objective, py_type=Objective)
        sensor = cls.require_obj_typed(r, CAMERA3D_CODEC_LAYOUT.sensor, py_type=Sensor)
        z_range = cls.require_obj_typed(r, CAMERA3D_CODEC_LAYOUT.z_range, py_type=ZRange)
        cam_pos = cls.require_obj_typed(r, CAMERA3D_CODEC_LAYOUT.cam_pos, py_type=CameraPosition)
        wavelength =  cls.require_obj_typed(r, CAMERA3D_CODEC_LAYOUT.primary_wavelength, py_type=Wavelength)
        return Camera3D(
            name=r.require_attr(CAMERA3D_CODEC_LAYOUT.name, transform=str),
            type=camera_type,
            objective=objective,
            sensor=sensor,
            cam_pos=cam_pos,
            z_range=z_range,
            primary_wavelength=wavelength)
