from __future__ import annotations

from dataclasses import dataclass

from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class CameraPositionCodecLayout:
    cs: str = "cs"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            groups=(self.cs,),
        )


CAMERA_POSITION_CODEC_LAYOUT = CameraPositionCodecLayout()
