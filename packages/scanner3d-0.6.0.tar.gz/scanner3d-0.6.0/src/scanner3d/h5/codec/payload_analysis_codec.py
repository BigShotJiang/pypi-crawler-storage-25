from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar
import numpy as np
from h5kit import codec
from h5kit.aid import suggest_chunks
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.afs.shot_result.payload_analysis import PaylodAnalysis
from scanner3d.h5.codec.payload_analysis_codec_layout import PAYLOAD_ANALYSIS_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer

@codec
class PayloadAnalysisCodec(H5CodecMixin, H5CodecLike[PaylodAnalysis]):
    PY_TYPE: ClassVar[type[PaylodAnalysis]] = PaylodAnalysis
    SCHEMA: ClassVar[str] = "scanner3d.afs.shot_result.payload_data.PayloadData"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = PAYLOAD_ANALYSIS_CODEC_LAYOUT.h5_layout

    @staticmethod
    def _meta_name(i: int) -> str:
        return f"{i:06d}"

    @classmethod
    def write(cls, w: H5Writer, obj: PaylodAnalysis) -> None:
        cls.clear_before_write(w)
        values = np.asarray(obj.values, dtype=float)
        w.array(PAYLOAD_ANALYSIS_CODEC_LAYOUT.result_values, values, chunks=suggest_chunks(values.shape),compression="gzip")
        meta_root = w.group(PAYLOAD_ANALYSIS_CODEC_LAYOUT.result_meta)
        for i, meta in enumerate(obj.metas):
            cls.write_obj(meta_root, key=cls._meta_name(i), obj=meta)

    @classmethod
    def read(cls, r: H5Reader) -> PaylodAnalysis:
        values = r.require_ndarray(PAYLOAD_ANALYSIS_CODEC_LAYOUT.result_values).astype(float, copy=False)
        meta_root = r.group(PAYLOAD_ANALYSIS_CODEC_LAYOUT.result_meta)
        if meta_root is None:
            raise ValueError(f"{cls.__name__}: missing group '{PAYLOAD_ANALYSIS_CODEC_LAYOUT.result_meta}'")
        meta_names = sorted(meta_root.grp.keys())
        metas = [cls.require_obj_auto(meta_root, key=name) for name in meta_names]
        return PaylodAnalysis(values=values, metas=metas)