from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar
from dimetra.geo import LengthSeq
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.afs.shot_result.shots import Shots
from scanner3d.h5.codec.shots_codec_layout import SHOTS_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class ShotsCodec(H5CodecMixin, H5CodecLike[Shots]):
    PY_TYPE: ClassVar[type[Shots]] = Shots
    SCHEMA: ClassVar[str] = "scanner3d.afs.shot_result.shots.Shots"
    VER: ClassVar[int] = 2
    LAYOUT: ClassVar[H5CodecLayout] = SHOTS_CODEC_LAYOUT.h5_layout

    @staticmethod
    def _item_name(i: int) -> str:
        return f"{i:06d}"

    @classmethod
    def write(cls, w: H5Writer, obj: Shots) -> None:
        cls.clear_before_write(w)
        cls.write_obj(w, key=SHOTS_CODEC_LAYOUT.field_x_seq, obj=obj.field_x_seq)
        cls.write_obj(w, key=SHOTS_CODEC_LAYOUT.field_y_seq, obj=obj.field_y_seq)
        payload_root = w.group(SHOTS_CODEC_LAYOUT.result_payload)
        for i, payload in enumerate(obj.payloads):
            cls.write_obj(payload_root, key=cls._item_name(i), obj=payload)

    @classmethod
    def read(cls, r: H5Reader) -> Shots:
        field_x_seq = cls.require_obj_typed(r, SHOTS_CODEC_LAYOUT.field_x_seq, py_type=LengthSeq)
        field_y_seq = cls.require_obj_typed(r, SHOTS_CODEC_LAYOUT.field_y_seq, py_type=LengthSeq)
        payload_root = r.require_group(SHOTS_CODEC_LAYOUT.result_payload)
        if payload_root is None:
            raise ValueError(f"{cls.__name__}: missing group '{SHOTS_CODEC_LAYOUT.result_payload}'")
        payload_names = sorted(payload_root.grp.keys())
        payloads = [cls.require_obj_auto(payload_root, key=name) for name in payload_names]
        return Shots.from_components(payloads=payloads, field_x_seq=field_x_seq, field_y_seq=field_y_seq)