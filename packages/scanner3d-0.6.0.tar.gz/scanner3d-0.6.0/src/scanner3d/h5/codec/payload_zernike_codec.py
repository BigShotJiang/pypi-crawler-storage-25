from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar
import numpy as np
from h5kit import codec
from h5kit.aid import suggest_chunks
from h5kit.codec import H5CodecLike, H5CodecMixin

from scanner3d.afs.shot_result.payload_zernike import PayloadZernike
from scanner3d.h5.codec.payload_zernike_codec_layout import PAYLOAD_ZERNIKE_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class PayloadZernikeCodec(H5CodecMixin, H5CodecLike[PayloadZernike]):
    PY_TYPE: ClassVar[type[PayloadZernike]] = PayloadZernike
    SCHEMA: ClassVar[str] = "scanner3d.afs.shot_result.payload_zernike.PayloadZernike"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = PAYLOAD_ZERNIKE_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: PayloadZernike) -> None:
        cls.clear_before_write(w)

        coeffs = np.asarray(obj.coefficients, dtype=float)
        w.array(
            PAYLOAD_ZERNIKE_CODEC_LAYOUT.coefficients,
            coeffs,
            chunks=suggest_chunks(coeffs.shape),
            compression="gzip",
        )

        meta_root = w.group(PAYLOAD_ZERNIKE_CODEC_LAYOUT.meta)
        cls.write_obj(meta_root, key="value", obj=obj.meta)

    @classmethod
    def read(cls, r: H5Reader) -> PayloadZernike:
        coeffs = r.require_ndarray(PAYLOAD_ZERNIKE_CODEC_LAYOUT.coefficients).astype(float, copy=False)
        meta_root = r.require_group(PAYLOAD_ZERNIKE_CODEC_LAYOUT.meta)
        meta = cls.require_obj_auto(meta_root, key="value")
        return PayloadZernike(coefficients=coeffs, meta=meta)