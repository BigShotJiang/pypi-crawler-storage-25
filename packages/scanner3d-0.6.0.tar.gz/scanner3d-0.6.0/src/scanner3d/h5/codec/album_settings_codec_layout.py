from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout

@dataclass(frozen=True)
class AlbumSettingsCodecLayout:
    kind: str = "kind"
    name: str = "name"
    dx: str = "dx"
    dy: str = "dy"
    dz: str = "dz"
    x_axis: str = "x_axis"
    y_axis: str = "y_axis"
    z_axis: str = "z_axis"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            attrs=(self.kind, self.name),
            optional_datasets=(self.dz, self.x_axis, self.y_axis, self.z_axis),
            optional_attrs=(self.dx, self.dy))

ALBUM_SETTINGS_CODEC_LAYOUT = AlbumSettingsCodecLayout()