from __future__ import annotations

from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class ZRangeCodecLayout:
    z_min: str = "z_min"
    z_max: str = "z_max"
    z_focus: str = "z_focus"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            groups=(self.z_min, self.z_max, self.z_focus),
        )


Z_RANGE_CODEC_LAYOUT = ZRangeCodecLayout()