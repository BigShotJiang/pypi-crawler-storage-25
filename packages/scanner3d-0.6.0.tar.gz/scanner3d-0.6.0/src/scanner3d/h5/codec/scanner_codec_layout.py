from __future__ import annotations

from dataclasses import dataclass

from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class ScannerCodecLayout:
    name: str = "name"
    scanner_cs: str = "scanner_cs"
    cameras: str = "cameras"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            attrs=(self.name,),
            groups=(self.scanner_cs,self.cameras,))


SCANNER_CODEC_LAYOUT = ScannerCodecLayout()
