from __future__ import annotations

from dataclasses import dataclass

from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class Camera3DCodecLayout:
    name: str = "name"
    type: str = "type"
    objective: str = "objective"
    sensor: str = "sensor"
    cam_pos: str = "cam_pos"
    z_range: str = "z_range"
    primary_wavelength: str = "primary_wavelength"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            attrs=(
                self.name,
                self.type,
            ),
            groups=(
                self.objective,
                self.sensor,
                self.cam_pos,
                self.z_range,
                self.primary_wavelength,
            ),
        )


CAMERA3D_CODEC_LAYOUT = Camera3DCodecLayout()
