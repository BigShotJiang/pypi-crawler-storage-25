from __future__ import annotations

from dataclasses import dataclass

from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class FrameMetaCodecLayout:
    value_min: str = "value_min"
    value_max: str = "value_max"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            datasets=(
                self.value_min,
                self.value_max,
            ),
        )


FRAME_META_CODEC_LAYOUT = FrameMetaCodecLayout()