from __future__ import annotations

from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class ProfileCodecLayout:
    file: str = "file"
    name: str = "name"
    title: str = "title"
    author: str = "author"
    notes: str = "notes"
    working_distance: str = "working_distance"
    focusing_distance: str = "focusing_distance"
    sensor_model: str = "sensor_model"
    objective_id: str = "objective_id"
    f_number: str = "f_number"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            datasets=(),
            groups=(),
            attrs=(
                self.file,
                self.name,
                self.title,
                self.author,
                self.notes,
                self.working_distance,
                self.focusing_distance,
                self.sensor_model,
                self.objective_id,
                self.f_number,
            ),
        )


PROFILE_CODEC_LAYOUT = ProfileCodecLayout()