from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.afs.frame.frame_meta import FrameMeta
from scanner3d.h5.codec.frame_meta_codec_layout import FRAME_META_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class FrameMetaCodec(H5CodecMixin, H5CodecLike[FrameMeta]):
    PY_TYPE: ClassVar[type[FrameMeta]] = FrameMeta
    SCHEMA: ClassVar[str] = "scanner3d.afs.frame.frame_meta.FrameMeta"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = FRAME_META_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: FrameMeta) -> None:
        cls.clear_before_write(w)
        w.scalar(FRAME_META_CODEC_LAYOUT.value_min, obj.value_min)
        w.scalar(FRAME_META_CODEC_LAYOUT.value_max, obj.value_max)

    @classmethod
    def read(cls, r: H5Reader) -> FrameMeta:
        return FrameMeta(
            value_min=r.scalar(FRAME_META_CODEC_LAYOUT.value_min),
            value_max=r.scalar(FRAME_META_CODEC_LAYOUT.value_max))