from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.h5.codec.scanner_codec_layout import SCANNER_CODEC_LAYOUT
from scanner3d.scanner.scanner import Scanner
from scanner3d.camera3d import Camera3D
from geopto.cs import CS3D

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class ScannerCodec(H5CodecMixin, H5CodecLike[Scanner]):
    PY_TYPE: ClassVar[type[Scanner]] = Scanner
    SCHEMA: ClassVar[str] = "scanner3d.scanner.Scanner"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = SCANNER_CODEC_LAYOUT.h5_layout

    @staticmethod
    def _camera_name(i: int) -> str:
        return f"{i:06d}"

    @classmethod
    def write(cls, w: H5Writer, obj: Scanner) -> None:
        cls.clear_before_write(w)
        w.attr(SCANNER_CODEC_LAYOUT.name, obj.name)
        cls.write_obj(w, key=SCANNER_CODEC_LAYOUT.scanner_cs, obj=obj.scanner_cs)
        cameras_root = w.group(SCANNER_CODEC_LAYOUT.cameras)
        for i, camera in enumerate(obj.cameras):
            cls.write_obj(cameras_root, key=cls._camera_name(i), obj=camera)

    @classmethod
    def read(cls, r: H5Reader) -> Scanner:
        cameras_root = r.require_group(SCANNER_CODEC_LAYOUT.cameras)
        scanner_cs = cls.require_obj_typed(r, key=SCANNER_CODEC_LAYOUT.scanner_cs, py_type=CS3D)
        camera_names = sorted(cameras_root.grp.keys())
        cameras = tuple(
            cls.require_obj_typed(cameras_root, key=name, py_type=Camera3D)
            for name in camera_names)

        return Scanner(
            name=r.require_attr(SCANNER_CODEC_LAYOUT.name, transform=str),
            scanner_cs=scanner_cs,
            cameras=cameras)