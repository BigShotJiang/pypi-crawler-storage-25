from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class GridMetaCodecLayout:
    min_x: str = "min_x"
    min_y: str = "min_y"
    dx: str = "dx"
    dy: str = "dy"

    description: str = "description"
    x_label: str = "x_label"
    y_label: str = "y_label"
    value_label: str = "value_label"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            attrs=(self.description, self.x_label, self.y_label, self.value_label),
            groups=(self.min_x, self.min_y,self.dx, self.dy)
        )


GRID_META_CODEC_LAYOUT = GridMetaCodecLayout()