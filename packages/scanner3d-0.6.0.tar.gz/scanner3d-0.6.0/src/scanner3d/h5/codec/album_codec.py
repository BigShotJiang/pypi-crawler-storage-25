from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar
import numpy as np
from dimetra.geo import LengthSeq
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.afs.album.album import Album
from scanner3d.afs.frame.frame import Frame
from scanner3d.afs.album_settings.album_settings import AlbumSettings
from scanner3d.h5.codec.album_codec_layout import ALBUM_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class AlbumCodec(H5CodecMixin, H5CodecLike[Album]):
    PY_TYPE: ClassVar[type[Album]] = Album
    SCHEMA: ClassVar[str] = "scanner3d.afs.album.album.Album"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = ALBUM_CODEC_LAYOUT.h5_layout

    @staticmethod
    def _frame_name(i: int) -> str:
        return f"{i:06d}"

    @classmethod
    def write(cls, w: H5Writer, obj: Album) -> None:
        cls.clear_before_write(w)
        frames = list(obj.frames)
        w.attr_if_not_none(ALBUM_CODEC_LAYOUT.path, obj.path, transform=lambda p: str(Path(p)))
        cls.write_obj(w, key=ALBUM_CODEC_LAYOUT.z_seq, obj=obj.z_seq)
        cls.write_obj(w, key=ALBUM_CODEC_LAYOUT.album_settings, obj=obj.album_settings)
        frames_root = w.group(ALBUM_CODEC_LAYOUT.frames)
        for i, frame in enumerate(frames):
            cls.write_obj(frames_root, key=cls._frame_name(i), obj=frame)

    @classmethod
    def read(cls, r: H5Reader) -> Album:
        z_seq = cls.require_obj_typed(r, ALBUM_CODEC_LAYOUT.z_seq, LengthSeq)
        album_settings = cls.require_obj_typed(r, ALBUM_CODEC_LAYOUT.album_settings, AlbumSettings)
        frames_root = r.group(ALBUM_CODEC_LAYOUT.frames)
        if frames_root is None:
            raise ValueError(f"{cls.__name__}: missing group '{ALBUM_CODEC_LAYOUT.frames}'")
        frame_names = sorted(frames_root.grp.keys())
        frames = [
            cls.require_obj_auto(frames_root, key=name)
            for name in frame_names]
        for i, frame in enumerate(frames):
            if not isinstance(frame, Frame):
                raise TypeError(f"{cls.__name__}: expected Frame at index {i}, got {type(frame)!r}")
        frame_z_mm = np.asarray([frame.z_mm for frame in frames], dtype=float)
        if not np.allclose(frame_z_mm, z_seq.values_mm, equal_nan=True):
            raise ValueError(f"{cls.__name__}: stored z_seq does not match frame.z values")
        path_str = r.attr(ALBUM_CODEC_LAYOUT.path, default=None, transform=str)
        return Album.from_components(
            album_settings=album_settings,
            frames=frames,
            z_seq=z_seq,
            path=None if path_str is None else Path(path_str))