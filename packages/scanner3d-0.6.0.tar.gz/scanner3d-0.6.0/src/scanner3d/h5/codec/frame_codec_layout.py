from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout

@dataclass(frozen=True)
class FrameCodecLayout:
    shots: str = "shots"
    x_seq: str = "x_seq"
    y_seq: str = "y_seq"
    z: str = "z"
    tuner_profile: str = "tuner_profile"
    frame_meta: str = "frame_meta"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            datasets=(self.x_seq, self.y_seq),
            groups=(self.shots, self.tuner_profile, self.frame_meta, self.z))


FRAME_CODEC_LAYOUT = FrameCodecLayout()