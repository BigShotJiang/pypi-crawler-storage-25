from __future__ import annotations

from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class PayloadAnalysisCodecLayout:
    result_values: str = "result_values"
    result_meta: str = "result_meta"


    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            datasets=(self.result_values,),
            groups=(self.result_meta,),)


PAYLOAD_ANALYSIS_CODEC_LAYOUT = PayloadAnalysisCodecLayout()