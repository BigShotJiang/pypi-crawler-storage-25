from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar
from dimetra.geo import Length, LengthSeq
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.afs.frame.frame import Frame
from scanner3d.afs.frame.frame_meta import FrameMeta
from scanner3d.afs.shot_result.shots import Shots
from scanner3d.h5.codec.frame_codec_layout import FRAME_CODEC_LAYOUT
from scanner3d.tuner.profile import Profile

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class FrameCodec(H5CodecMixin, H5CodecLike[Frame]):
    PY_TYPE: ClassVar[type[Frame]] = Frame
    SCHEMA: ClassVar[str] = "scanner3d.afs.frame.frame.Frame"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = FRAME_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: Frame) -> None:
        cls.clear_before_write(w)
        cls.write_obj(w, FRAME_CODEC_LAYOUT.z, obj=obj.z)
        cls.write_obj(w, FRAME_CODEC_LAYOUT.x_seq, obj=obj.x_seq)
        cls.write_obj(w, FRAME_CODEC_LAYOUT.y_seq, obj=obj.y_seq)
        cls.write_obj(w, FRAME_CODEC_LAYOUT.shots, obj=obj.shots_batch)
        cls.write_obj(w, FRAME_CODEC_LAYOUT.tuner_profile, obj=obj.profile)
        cls.write_obj(w, FRAME_CODEC_LAYOUT.frame_meta, obj=obj.meta)

    @classmethod
    def read(cls, r: H5Reader) -> Frame:
        x_seq = cls.require_obj_typed(r, FRAME_CODEC_LAYOUT.x_seq, LengthSeq)
        y_seq = cls.require_obj_typed(r, FRAME_CODEC_LAYOUT.y_seq, LengthSeq)
        shots = cls.require_obj_typed(r, FRAME_CODEC_LAYOUT.shots, Shots)
        profile = cls.require_obj_typed(r, FRAME_CODEC_LAYOUT.tuner_profile, Profile)
        z = cls.require_obj_typed(r, FRAME_CODEC_LAYOUT.z, py_type=Length)
        expected_shots = len(x_seq) * len(y_seq)
        if len(shots) != expected_shots:
            raise ValueError(f"{cls.__name__}: expected {expected_shots} shots from x/y sequences, got {len(shots)}")
        frame_meta = cls.require_obj_typed(r, FRAME_CODEC_LAYOUT.frame_meta, FrameMeta)
        return Frame.from_components(
            shots=shots,
            x_seq=x_seq,
            y_seq=y_seq,
            meta=frame_meta,
            profile=profile,
            z=z)