from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout

@dataclass(frozen=True)
class AlbumCodecLayout:
    frames: str = "frames"
    album_settings: str = "album_settings"
    z_seq: str = "z_seq"
    path: str = "path"


    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            datasets=(self.z_seq,),
            groups=(self.frames, self.album_settings),
            attrs=(self.path,))

ALBUM_CODEC_LAYOUT = AlbumCodecLayout()
