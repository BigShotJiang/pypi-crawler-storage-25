from __future__ import annotations

from dataclasses import dataclass

from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class ZernikeMetaCodecLayout:
    pv_to_chief: str = "pv_to_chief"
    pv_to_centroid: str = "pv_to_centroid"

    rms_to_chief_rays: str = "rms_to_chief_rays"
    rms_to_centroid_rays: str = "rms_to_centroid_rays"

    rms_to_chief_fit: str = "rms_to_chief_fit"
    rms_to_centroid_fit: str = "rms_to_centroid_fit"

    variance_rays: str = "variance_rays"
    variance_fit: str = "variance_fit"

    strehl_rays: str = "strehl_rays"
    strehl_fit: str = "strehl_fit"

    rms_fit_error: str = "rms_fit_error"
    max_fit_error: str = "max_fit_error"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            attrs=(
                self.pv_to_chief,
                self.pv_to_centroid,
                self.rms_to_chief_rays,
                self.rms_to_centroid_rays,
                self.rms_to_chief_fit,
                self.rms_to_centroid_fit,
                self.variance_rays,
                self.variance_fit,
                self.strehl_rays,
                self.strehl_fit,
                self.rms_fit_error,
                self.max_fit_error,
            ),
        )


ZERNIKE_META_CODEC_LAYOUT = ZernikeMetaCodecLayout()