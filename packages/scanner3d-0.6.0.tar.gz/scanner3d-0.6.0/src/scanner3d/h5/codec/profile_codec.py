from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin

from scanner3d.h5.codec.profile_codec_layout import PROFILE_CODEC_LAYOUT
from scanner3d.tuner.profile import Profile

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class ProfileCodec(H5CodecMixin, H5CodecLike[Profile]):
    PY_TYPE: ClassVar[type[Profile]] = Profile
    SCHEMA: ClassVar[str] = "scanner3d.tuner.profile.Profile"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = PROFILE_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: Profile) -> None:
        cls.clear_before_write(w)
        w.attr(PROFILE_CODEC_LAYOUT.file, obj.file)
        w.attr(PROFILE_CODEC_LAYOUT.name, obj.name)
        w.attr(PROFILE_CODEC_LAYOUT.title, obj.title)
        w.attr(PROFILE_CODEC_LAYOUT.author, obj.author)
        w.attr(PROFILE_CODEC_LAYOUT.notes, obj.notes)
        w.attr(PROFILE_CODEC_LAYOUT.working_distance, float(obj.working_distance))
        w.attr(PROFILE_CODEC_LAYOUT.focusing_distance, float(obj.focusing_distance))
        w.attr(PROFILE_CODEC_LAYOUT.sensor_model, obj.sensor_model)
        w.attr(PROFILE_CODEC_LAYOUT.objective_id, obj.objective_id)
        w.attr(PROFILE_CODEC_LAYOUT.f_number, float(obj.f_number))

    @classmethod
    def read(cls, r: H5Reader) -> Profile:
        return Profile(
            file=r.require_attr(PROFILE_CODEC_LAYOUT.file, transform=str),
            name=r.require_attr(PROFILE_CODEC_LAYOUT.name, transform=str),
            title=r.require_attr(PROFILE_CODEC_LAYOUT.title, transform=str),
            author=r.require_attr(PROFILE_CODEC_LAYOUT.author, transform=str),
            notes=r.require_attr(PROFILE_CODEC_LAYOUT.notes, transform=str),
            working_distance=r.require_attr(PROFILE_CODEC_LAYOUT.working_distance, transform=float),
            focusing_distance=r.require_attr(PROFILE_CODEC_LAYOUT.focusing_distance, transform=float),
            sensor_model=r.require_attr(PROFILE_CODEC_LAYOUT.sensor_model, transform=str),
            objective_id=r.require_attr(PROFILE_CODEC_LAYOUT.objective_id, transform=str),
            f_number=r.require_attr(PROFILE_CODEC_LAYOUT.f_number, transform=float),
        )