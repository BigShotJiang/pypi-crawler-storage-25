from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar, cast
from dimetra.geo import Length, LengthSeq
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.afs.album_settings.album_settings import AlbumSettings
from scanner3d.afs.album_settings.album_types import AlbumTypes
from scanner3d.afs.album_settings.field_grid_rect import FieldGridRectAlbumSettings
from scanner3d.afs.album_settings.major_frames import MajorFramesAlbumSettings
from scanner3d.afs.album_settings.radial import RadialAlbumSettings
from scanner3d.afs.album_settings.sparse_grid import SparseGridAlbumSettings
from scanner3d.afs.album_settings.radila_focus_only import RadialFocusOnlyAlbumSettings
from scanner3d.h5.codec.album_settings_codec_layout import ALBUM_SETTINGS_CODEC_LAYOUT
from scanner3d.afs.album_settings.typed import TypedAlbumSettings

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class AlbumSettingsCodec(H5CodecMixin, H5CodecLike[AlbumSettings]):
    PY_TYPE: ClassVar[type[AlbumSettings]] = AlbumSettings
    SCHEMA: ClassVar[str] = "scanner3d.afs.album_settings.album_settings.AlbumSettings"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = ALBUM_SETTINGS_CODEC_LAYOUT.h5_layout


    @classmethod
    def write(cls, w: H5Writer, obj: AlbumSettings) -> None:
        cls.clear_before_write(w)
        obj_typed = cast(TypedAlbumSettings, obj)
        kind = obj_typed.ALBUM_TYPE
        w.attr(ALBUM_SETTINGS_CODEC_LAYOUT.kind, kind.value)
        w.attr(ALBUM_SETTINGS_CODEC_LAYOUT.name, obj.name)

        if isinstance(obj, MajorFramesAlbumSettings) or isinstance(obj, SparseGridAlbumSettings):
            w.attr(ALBUM_SETTINGS_CODEC_LAYOUT.dx, obj.dx)
            w.attr(ALBUM_SETTINGS_CODEC_LAYOUT.dy, obj.dy)
            cls.write_obj(w, key=ALBUM_SETTINGS_CODEC_LAYOUT.dz, obj=obj.dz, py_type=Length)
            return

        if isinstance(obj, RadialAlbumSettings):
            cls.write_obj(w, key=ALBUM_SETTINGS_CODEC_LAYOUT.dx, obj=obj.dx, py_type=Length)
            cls.write_obj(w, key=ALBUM_SETTINGS_CODEC_LAYOUT.dz, obj=obj.dz, py_type=Length)
            return

        if isinstance(obj, FieldGridRectAlbumSettings):
            cls.write_obj(w, key=ALBUM_SETTINGS_CODEC_LAYOUT.x_axis, obj=obj.x_axis, py_type=LengthSeq)
            cls.write_obj(w, key=ALBUM_SETTINGS_CODEC_LAYOUT.y_axis, obj=obj.y_axis, py_type=LengthSeq)
            cls.write_obj(w, key=ALBUM_SETTINGS_CODEC_LAYOUT.z_axis, obj=obj.z_axis, py_type=LengthSeq)
            return
        if isinstance(obj, RadialFocusOnlyAlbumSettings):
            cls.write_obj(w, key=ALBUM_SETTINGS_CODEC_LAYOUT.x_axis, obj=obj.dx, py_type=LengthSeq)
            return

        raise TypeError(f"{cls.__name__}: unsupported AlbumSettings kind {kind!r}")

    @classmethod
    def read(cls, r: H5Reader) -> AlbumSettings:
        kind_raw = r.require_attr(ALBUM_SETTINGS_CODEC_LAYOUT.kind, transform=str)
        name = r.require_attr(ALBUM_SETTINGS_CODEC_LAYOUT.name, transform=str)

        try:
            kind = AlbumTypes(kind_raw)
        except ValueError as exc:
            raise ValueError(f"{cls.__name__}: unknown settings kind {kind_raw!r}") from exc

        if kind is AlbumTypes.MAJOR_FRAMES:
            return MajorFramesAlbumSettings(
                name=name,
                dx=r.require_attr(ALBUM_SETTINGS_CODEC_LAYOUT.dx, transform=int),
                dy=r.require_attr(ALBUM_SETTINGS_CODEC_LAYOUT.dy, transform=int),
                dz=cls.read_obj_typed(r, key=ALBUM_SETTINGS_CODEC_LAYOUT.dz, py_type=Length))

        if kind is AlbumTypes.SPARSE_GRID:
            return SparseGridAlbumSettings(
                name=name,
                dx=r.require_attr(ALBUM_SETTINGS_CODEC_LAYOUT.dx, transform=int),
                dy=r.require_attr(ALBUM_SETTINGS_CODEC_LAYOUT.dy, transform=int),
                dz=cls.read_obj_typed(r, key=ALBUM_SETTINGS_CODEC_LAYOUT.dz, py_type=Length))

        if kind is AlbumTypes.RADIAL:
            return RadialAlbumSettings(
                name=name,
                dx=cls.require_obj_typed(r, key=ALBUM_SETTINGS_CODEC_LAYOUT.dx, py_type=Length),
                dz=cls.require_obj_typed(r, key=ALBUM_SETTINGS_CODEC_LAYOUT.dz, py_type=Length))

        if kind is AlbumTypes.FIELD_GRID_RECT:
            return FieldGridRectAlbumSettings(
                name=name,
                x_axis=cls.require_obj_typed(r, key=ALBUM_SETTINGS_CODEC_LAYOUT.x_axis, py_type=LengthSeq),
                y_axis=cls.require_obj_typed(r, key=ALBUM_SETTINGS_CODEC_LAYOUT.y_axis, py_type=LengthSeq),
                z_axis=cls.require_obj_typed(r, key=ALBUM_SETTINGS_CODEC_LAYOUT.z_axis, py_type=LengthSeq))
        if kind is AlbumTypes.RADIAL_FOCUS_ONLY:
            return RadialFocusOnlyAlbumSettings(
                name=name,
                dx=cls.require_obj_typed(r, key=ALBUM_SETTINGS_CODEC_LAYOUT.dx, py_type=Length))

        raise ValueError(f"{cls.__name__}: unknown settings kind {kind_raw!r}")
