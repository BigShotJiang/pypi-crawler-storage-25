from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from scanner3d.geo.camera_position import CameraPosition
from geopto.cs.cs_3d import CS3D
from scanner3d.h5.codec.camera_position_codec_layout import CAMERA_POSITION_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class CameraPositionCodec(H5CodecMixin, H5CodecLike[CameraPosition]):
    PY_TYPE: ClassVar[type[CameraPosition]] = CameraPosition
    SCHEMA: ClassVar[str] = "geopto.camera.camera_position.CameraPosition"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = CAMERA_POSITION_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: CameraPosition) -> None:
        cls.clear_before_write(w)
        cls.write_obj(w, key=CAMERA_POSITION_CODEC_LAYOUT.cs, obj=obj.cs)

    @classmethod
    def read(cls, r: H5Reader) -> CameraPosition:
        cs = cls.require_obj_typed(r, CAMERA_POSITION_CODEC_LAYOUT.cs, py_type=CS3D)
        return CameraPosition(cs=cs)
