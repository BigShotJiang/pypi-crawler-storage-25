from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class ShotsCodecLayout:
    field_x_seq: str = "field_x_seq"
    field_y_seq: str = "field_y_seq"
    result_payload: str = "result_payload"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            datasets=(),
            groups=(self.field_x_seq, self.field_y_seq, self.result_payload))

SHOTS_CODEC_LAYOUT = ShotsCodecLayout()