from __future__ import annotations

import math
from typing import TYPE_CHECKING, ClassVar

from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from zemod.iar.zernike import ZernikeMeta

from scanner3d.h5.codec.zernike_meta_codec_layout import ZERNIKE_META_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


def _encode_opt_float(x: float | None) -> float:
    return float("nan") if x is None else float(x)


def _decode_opt_float(x: float) -> float | None:
    return None if math.isnan(x) else float(x)


@codec
class ZernikeMetaCodec(H5CodecMixin, H5CodecLike[ZernikeMeta]):
    PY_TYPE: ClassVar[type[ZernikeMeta]] = ZernikeMeta
    SCHEMA: ClassVar[str] = "zemod.iar.zernike.ZernikeMeta"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = ZERNIKE_META_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: ZernikeMeta) -> None:
        cls.clear_before_write(w)

        w.attr(ZERNIKE_META_CODEC_LAYOUT.pv_to_chief, _encode_opt_float(obj.pv_to_chief))
        w.attr(ZERNIKE_META_CODEC_LAYOUT.pv_to_centroid, _encode_opt_float(obj.pv_to_centroid))

        w.attr(ZERNIKE_META_CODEC_LAYOUT.rms_to_chief_rays, _encode_opt_float(obj.rms_to_chief_rays))
        w.attr(ZERNIKE_META_CODEC_LAYOUT.rms_to_centroid_rays, _encode_opt_float(obj.rms_to_centroid_rays))

        w.attr(ZERNIKE_META_CODEC_LAYOUT.rms_to_chief_fit, _encode_opt_float(obj.rms_to_chief_fit))
        w.attr(ZERNIKE_META_CODEC_LAYOUT.rms_to_centroid_fit, _encode_opt_float(obj.rms_to_centroid_fit))

        w.attr(ZERNIKE_META_CODEC_LAYOUT.variance_rays, _encode_opt_float(obj.variance_rays))
        w.attr(ZERNIKE_META_CODEC_LAYOUT.variance_fit, _encode_opt_float(obj.variance_fit))

        w.attr(ZERNIKE_META_CODEC_LAYOUT.strehl_rays, _encode_opt_float(obj.strehl_rays))
        w.attr(ZERNIKE_META_CODEC_LAYOUT.strehl_fit, _encode_opt_float(obj.strehl_fit))

        w.attr(ZERNIKE_META_CODEC_LAYOUT.rms_fit_error, _encode_opt_float(obj.rms_fit_error))
        w.attr(ZERNIKE_META_CODEC_LAYOUT.max_fit_error, _encode_opt_float(obj.max_fit_error))

    @classmethod
    def read(cls, r: H5Reader) -> ZernikeMeta:
        return ZernikeMeta(
            pv_to_chief=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.pv_to_chief, transform=float)),
            pv_to_centroid=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.pv_to_centroid, transform=float)),
            rms_to_chief_rays=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.rms_to_chief_rays, transform=float)),
            rms_to_centroid_rays=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.rms_to_centroid_rays, transform=float)),
            rms_to_chief_fit=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.rms_to_chief_fit, transform=float)),
            rms_to_centroid_fit=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.rms_to_centroid_fit, transform=float)),
            variance_rays=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.variance_rays, transform=float)),
            variance_fit=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.variance_fit, transform=float)),
            strehl_rays=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.strehl_rays, transform=float)),
            strehl_fit=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.strehl_fit, transform=float)),
            rms_fit_error=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.rms_fit_error, transform=float)),
            max_fit_error=_decode_opt_float(r.require_attr(ZERNIKE_META_CODEC_LAYOUT.max_fit_error, transform=float)),
        )