from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from dimetra.geo import Length
from h5kit import codec
from h5kit.codec import H5CodecLike, H5CodecMixin
from h5kit.io.registry_io import write_registered_object

from scanner3d.geo.z_range import ZRange
from scanner3d.h5.codec.z_range_codec_layout import Z_RANGE_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit.codec.h5_codec_layout import H5CodecLayout
    from h5kit.io import H5Reader, H5Writer


@codec
class ZRangeCodec(H5CodecMixin, H5CodecLike[ZRange]):
    PY_TYPE: ClassVar[type[ZRange]] = ZRange
    SCHEMA: ClassVar[str] = "scanner3d.geo.z_range.ZRange"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = Z_RANGE_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: ZRange) -> None:
        cls.clear_before_write(w)
        write_registered_object(w, Z_RANGE_CODEC_LAYOUT.z_min, obj.z_min, registry=w.registry)
        write_registered_object(w, Z_RANGE_CODEC_LAYOUT.z_max, obj.z_max, registry=w.registry)
        write_registered_object(w, Z_RANGE_CODEC_LAYOUT.z_focus, obj.z_focus, registry=w.registry)

    @classmethod
    def read(cls, r: H5Reader) -> ZRange:
        z_min = cls.require_obj_typed(r, Z_RANGE_CODEC_LAYOUT.z_min, py_type=Length)
        z_max = cls.require_obj_typed(r, Z_RANGE_CODEC_LAYOUT.z_max, py_type=Length)
        z_focus = cls.require_obj_typed(r, Z_RANGE_CODEC_LAYOUT.z_focus, py_type=Length)
        return ZRange(z_min=z_min, z_max=z_max, z_focus=z_focus)