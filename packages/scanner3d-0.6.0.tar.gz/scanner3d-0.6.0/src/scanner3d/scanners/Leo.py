from typing import  Final
from dimetra.geo import Length, LengthUnit
from scanner3d.scanner.scanner import Scanner
from scanner3d.camera3d import Camera3D, Camera3DTypes
from scanner3d.geo import Z_RANGE_LEO, CameraPosition
from lensguild.catalog import ObjectivesDB
from isensor.sensor import SensorsDB
from geopto.cs import CS3D
from gosti.wavelength import Wavelength

Leo: Final[Scanner] = Scanner(
    name="Leo",
    cameras=(
        Camera3D(
            name="Reconstruction",
            type=Camera3DTypes.Reconstruction,
            objective=ObjectivesDB.NAVITAR_E3399_16_F5_6,
            sensor=SensorsDB.SONY_IMX174,
            cam_pos=CameraPosition(cs=CS3D.world()),
            z_range=Z_RANGE_LEO,
            primary_wavelength=Wavelength(Length(808, LengthUnit.NM)),
        ),
    ),
)
