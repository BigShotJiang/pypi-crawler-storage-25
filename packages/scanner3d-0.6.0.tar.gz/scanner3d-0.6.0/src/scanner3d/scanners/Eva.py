from typing import Final
from scanner3d.scanner.scanner import Scanner
from scanner3d.camera3d import Camera3D, Camera3DTypes
from scanner3d.geo import Z_RANGE_EVA, CameraPosition
from lensguild.catalog import ObjectivesDB
from isensor.sensor import SensorsDB
from gosti.wavelength import Wavelength
from dimetra.geo import Length,LengthUnit
from geopto.cs import CS3D
from geopto.primitives import Point3D
from geopto.primitives import OrthoBasis3D

Eva: Final[Scanner] = Scanner(
    name="Eva",
    cameras=(
        Camera3D(
            name="Reconstruction",
            type=Camera3DTypes.Reconstruction,
            objective=ObjectivesDB.DSL934_F3_0_NIR,
            sensor=SensorsDB.SONY_IMX445,
            cam_pos=CameraPosition(cs=CS3D.world()),
            z_range=Z_RANGE_EVA,
            primary_wavelength=Wavelength(Length(450, LengthUnit.NM)),
        ),
        Camera3D(
            name="Texture",
            type=Camera3DTypes.Texture,
            objective=ObjectivesDB.DSL934_F3_0_NIR,
            sensor=SensorsDB.SONY_IMX445,
            cam_pos=CameraPosition(
                cs=CS3D(
                    origin=Point3D(x=Length(0, LengthUnit.MM), y=Length(107, LengthUnit.MM), z=Length(-13.4, LengthUnit.MM)),
                    basis=OrthoBasis3D.rx_deg(10.7),
                )
            ),
            z_range=Z_RANGE_EVA,
            primary_wavelength=Wavelength(Length(450, LengthUnit.NM)),
        ),
    ),
)
