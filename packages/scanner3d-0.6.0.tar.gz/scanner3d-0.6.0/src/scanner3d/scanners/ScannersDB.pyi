from typing import ClassVar, Mapping, Tuple
from scanner3d.scanner.scanner import Scanner

REGISTRY: Mapping[str, Scanner]

class ScannersDB:
    REGISTRY: ClassVar[Mapping[str, Scanner]]
    Eva: ClassVar[Scanner]
    Eva2: ClassVar[Scanner]
    Leo: ClassVar[Scanner]
    Leo2: ClassVar[Scanner]
    Spider2: ClassVar[Scanner]
    Spider2Pro: ClassVar[Scanner]

    @classmethod
    def find_camera(cls, *args, **kwargs) -> Tuple[str, int]: ...
    @classmethod
    def get_scanner(cls, *args, **kwargs) -> Scanner: ...
    @classmethod
    def names(cls, *args, **kwargs) -> tuple[str, ...]: ...
