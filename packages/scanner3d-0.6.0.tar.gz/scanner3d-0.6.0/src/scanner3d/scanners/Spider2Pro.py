from typing import Final
from dimetra.geo import Length,LengthUnit
from scanner3d.scanner.scanner import Scanner
from scanner3d.camera3d import Camera3D, Camera3DTypes
from scanner3d.geo import Z_RANGE_SPIDER, CameraPosition
from lensguild.catalog import ObjectivesDB
from isensor.sensor import SensorsDB
from gosti.wavelength import Wavelength
from geopto.cs import CS3D

Spider2Pro: Final[Scanner] = Scanner(
    name="Spider2Pro",
    cameras=(
        Camera3D(
            name="Reconstruction_0",
            type=Camera3DTypes.Reconstruction,
            objective=ObjectivesDB.DSL935_F4_8_NIR,
            sensor=SensorsDB.SONY_IMX547,
            cam_pos=CameraPosition(cs=CS3D.world()),
            z_range=Z_RANGE_SPIDER,
            primary_wavelength=Wavelength(Length(450, LengthUnit.NM)),
        ),
    ),
)