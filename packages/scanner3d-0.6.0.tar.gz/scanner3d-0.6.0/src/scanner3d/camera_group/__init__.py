from scanner3d.camera_group.camera_group_presets import (
    CAMERA_LIST_FULL,
    SPIDER2,
    SPIDER2PRO,

    SPIDER_GROUP,
    LEO_GROUP,
    EVA_GROUP,
)

__all__ = [
    "CAMERA_LIST_FULL",
    "SPIDER2",
    "SPIDER2PRO",
    "SPIDER_GROUP",
    "LEO_GROUP",
    "EVA_GROUP",
]
