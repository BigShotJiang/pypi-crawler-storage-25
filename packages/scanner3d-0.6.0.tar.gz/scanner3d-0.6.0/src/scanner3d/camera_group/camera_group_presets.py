from scanner3d.scanners.ScannersDB import ScannersDB
from scanner3d.analysis.camera_analysis.camera_analysis import CameraAnalysis
from scanner3d.camera_group.camera_group import CameraGroup

CAMERA_LIST_FULL = CameraGroup(
    name="ALL",
    cameras=(
        CameraAnalysis(scanner=ScannersDB.Spider2, index=0),
        CameraAnalysis(scanner=ScannersDB.Spider2Pro, index=0),
        CameraAnalysis(scanner=ScannersDB.Eva, index=0),
        CameraAnalysis(scanner=ScannersDB.Eva2, index=0),
        CameraAnalysis(scanner=ScannersDB.Leo, index=0),
        CameraAnalysis(scanner=ScannersDB.Leo2, index=0),
    ),
)

SPIDER2 = CameraGroup(
    name="Spider2",
    cameras=(
        CameraAnalysis(scanner=ScannersDB.Spider2, index=0),
    ),
)

SPIDER2PRO = CameraGroup(
    name="Spider2Pro",
    cameras=(
        CameraAnalysis(scanner=ScannersDB.Spider2Pro, index=0),
    ),
)

LEO_GROUP = CameraGroup(
    name="LeoGroup",
    cameras=(
        CameraAnalysis(scanner=ScannersDB.Leo, index=0),
        CameraAnalysis(scanner=ScannersDB.Leo2, index=0),
    ),
)

SPIDER_GROUP = CameraGroup(
    name="LeoGroup",
    cameras=(
        CameraAnalysis(scanner=ScannersDB.Spider2, index=0),
        CameraAnalysis(scanner=ScannersDB.Spider2Pro, index=0),
    ),
)

EVA_GROUP= CameraGroup(
    name="Eva",
    cameras=(
        CameraAnalysis(scanner=ScannersDB.Eva, index=0),
        CameraAnalysis(scanner=ScannersDB.Eva2, index=0),
    ),
)