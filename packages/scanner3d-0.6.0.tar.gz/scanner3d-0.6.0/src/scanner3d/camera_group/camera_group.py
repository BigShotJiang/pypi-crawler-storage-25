from __future__ import annotations
from dataclasses import dataclass
from typing import Iterator, Tuple
from scanner3d.analysis.camera_analysis.camera_analysis import CameraAnalysis

@dataclass(frozen=True)
class CameraGroup:
    """Immutable group of cameras for analysis."""
    name: str
    cameras: Tuple[CameraAnalysis, ...]

    def __iter__(self) -> Iterator[CameraAnalysis]:
        return iter(self.cameras)

    def __len__(self) -> int:
        return len(self.cameras)

    @property
    def scanner_names(self) -> list[str]:
        return [c.scanner_name for c in self.cameras]

    def with_index(self, index: int) -> CameraGroup:
        """Return a new group with a different index for all cameras."""
        return CameraGroup(
            name=self.name,
            cameras=tuple(
                CameraAnalysis(scanner=c.scanner, index=index)
                for c in self.cameras
            ),
        )