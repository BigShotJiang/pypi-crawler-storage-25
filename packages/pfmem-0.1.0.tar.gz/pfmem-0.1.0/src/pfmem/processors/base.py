"""Processor interface and data models."""

from abc import ABC, abstractmethod
from typing import Optional

from pydantic import BaseModel


class MemoryOperation(BaseModel):
    """A single memory action returned by a processor.

    INSERT: text = new memory, memory_id = None
    UPDATE: text = new memory, memory_id = existing memory to replace
    DELETE: text = memory being deleted, memory_id = existing memory to remove
    """
    action: str
    text: str
    memory_id: Optional[str] = None


class BaseLaneProcessor(ABC):
    """Interface all lane processors must implement.

    Rule: processors are pure — no DB access. They take data in,
    return MemoryOperation list out. The Memory class handles storage.

    Two-step flow (used by Memory class):
      1. extract_facts(messages, config) → (facts, embeddings)
      2. decide_crud(facts, existing, config) → operations

    extract() is a convenience wrapper that calls both steps.
    """

    @abstractmethod
    def extract_facts(self, messages: list[dict], config) -> tuple[list[str], dict]:
        """LLM call 1: extract new facts from messages and embed them.

        Args:
            messages: Pre-filtered by role. Never empty (caller checks).
            config: The LaneConfig for this lane.

        Returns:
            (facts, embeddings) where embeddings is {fact_text: embedding_vector}.
            Embeddings are cached here so the Memory class can reuse them for
            vector search and INSERT without re-embedding.
        """
        ...

    @abstractmethod
    def decide_crud(self, new_facts: list[str], existing_memories: list[dict], config) -> list[MemoryOperation]:
        """LLM call 2: compare new facts against existing memories, return operations.

        Args:
            new_facts: Strings extracted by extract_facts().
            existing_memories: Semantically relevant existing memories fetched by Memory class.
                [{id: "mem_123", text: "some fact"}, ...]
            config: The LaneConfig for this lane.

        Returns:
            List of MemoryOperation (INSERT/UPDATE/DELETE), already filtered by CRUD flags.
        """
        ...

    def extract(self, messages: list[dict], existing_memories: list[dict], config) -> list[MemoryOperation]:
        """Convenience: extract facts + decide CRUD in one call."""
        facts, _ = self.extract_facts(messages, config)
        if not facts:
            return []
        return self.decide_crud(facts, existing_memories, config)
