"""Default processor — extracts memories via LLM calls."""

import json
import logging
from datetime import datetime

from pfmem.processors.base import BaseLaneProcessor, MemoryOperation

logger = logging.getLogger(__name__)


class LLMExtractProcessor(BaseLaneProcessor):
    """Standard extraction processor. Used by all 4 default lanes.

    Non-additive lanes (semantic, procedural): 2 LLM calls
      Call 1: extract facts from messages
      Call 2: compare facts against existing memories → INSERT/UPDATE/DELETE

    Additive lanes (episodic, observational): 1 LLM call
      Call 1: extract facts → all become INSERTs (no comparison needed)
    """

    def __init__(self, llm, embedder):
        self.llm = llm
        self.embedder = embedder

    def extract_facts(self, messages, config, context_messages=None) -> tuple[list[str], dict]:
        """LLM call 1: extract facts and embed each one.

        Returns:
            (facts, embeddings) where embeddings is {fact_text: embedding_vector}.
            Embeddings are cached so Memory class can reuse them for vector search
            and INSERT without a second embed call.
        """
        if not messages:
            return [], {}

        parsed_current = self._parse_messages(messages)
        parsed_context = self._parse_messages(context_messages) if context_messages else None
        facts = self._extract_facts(parsed_current, config, context_text=parsed_context)
        if not facts:
            return [], {}

        vectors = self.embedder.embed_many(facts, "add")
        embeddings = dict(zip(facts, vectors))
        return facts, embeddings

    def decide_crud(self, new_facts, existing_memories, config) -> list[MemoryOperation]:
        """LLM call 2 (or INSERT shortcut for additive lanes).

        Includes filtering by lane CRUD flags.
        """
        is_additive = not config.enable_updates and not config.enable_deletes
        if is_additive or not existing_memories:
            operations = [MemoryOperation(action="INSERT", text=fact) for fact in new_facts]
        else:
            operations = self._decide_crud(new_facts, existing_memories, config)
        return self._filter_by_crud_flags(operations, config)

    # ── Helper: parse messages into text ──

    def _parse_messages(self, messages):
        """Convert message dicts into 'role: content' text block."""
        lines = []
        for msg in messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if content:
                lines.append(f"{role}: {content}")
        return "\n".join(lines)

    # ── Helper: LLM call 1 — extract facts ──

    def _extract_facts(self, parsed_text, config, context_text=None):
        """Call LLM with extraction prompt, return list of fact strings."""
        prompt = config.extraction_prompt
        # Inject runtime values into prompt placeholders
        try:
            prompt = prompt.format(today_date=datetime.now().strftime("%Y-%m-%d"))
        except KeyError:
            pass  # prompt has no placeholders, that's fine

        if context_text:
            user_content = (
                f"Previous conversation (context only — do NOT extract from this):\n{context_text}\n\n"
                f"Current messages (extract facts from ONLY these):\n{parsed_text}"
            )
        else:
            user_content = f"Input:\n{parsed_text}"

        try:
            response = self.llm.generate_response(
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": user_content},
                ],
                response_format={"type": "json_object"},
            )
        except Exception as e:
            logger.error(f"LLM call failed during extraction: {e}")
            return []

        try:
            response = self._clean_response(response)
            if not response.strip():
                return []
            data = json.loads(response)
            return data.get("facts", [])
        except (json.JSONDecodeError, Exception) as e:
            logger.error(f"Error extracting facts: {e}")
            return []

    def _clean_response(self, text):
        """Strip markdown code blocks from LLM response."""
        import re
        match = re.match(r"^```(?:\w+)?\s*\n(.*?)```\s*$", text.strip(), re.DOTALL)
        return match.group(1).strip() if match else text.strip()

    # ── Helper: LLM call 2 — CRUD decision ──

    def _decide_crud(self, new_facts, existing_memories, config):
        """Compare new facts against existing memories, return operations.

        Key trick: map real UUIDs to simple ints (0, 1, 2...) before sending
        to LLM. This prevents the LLM from hallucinating memory IDs.
        After LLM responds, map ints back to real UUIDs.
        """
        from pfmem.configs.prompts import get_update_memory_messages

        # Build UUID ↔ int mapping
        uuid_map = {}  # {"0": "real-uuid-abc", "1": "real-uuid-def"}
        simplified = []
        for idx, mem in enumerate(existing_memories):
            str_idx = str(idx)
            uuid_map[str_idx] = mem["id"]
            simplified.append({"id": str_idx, "text": mem["text"]})

        # Build prompt and call LLM
        prompt = get_update_memory_messages(simplified, new_facts)
        try:
            response = self.llm.generate_response(
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"},
            )
            response = self._clean_response(response)
            actions = json.loads(response) if response.strip() else {}
        except (json.JSONDecodeError, Exception) as e:
            logger.error(f"Error in CRUD decision: {e}")
            return []

        # Parse LLM response into MemoryOperations, mapping ints back to UUIDs
        # Handle both formats: {"memory": [...]} or direct [...]
        if isinstance(actions, list):
            items = actions
        else:
            items = actions.get("memory", [])

        operations = []
        for item in items:
            # Handle both formats:
            # Prompt format: {"id": "0", "text": "...", "event": "ADD"}
            # Direct format: {"action": "INSERT", "text": "...", "memory_id": "..."}
            event = item.get("event") or item.get("action", "")
            text = item.get("text", "")
            item_id = str(item.get("id", item.get("memory_id", "") or ""))

            # Normalize event names: ADD→INSERT, DELETE→DELETE, UPDATE→UPDATE
            action_map = {"ADD": "INSERT", "INSERT": "INSERT", "UPDATE": "UPDATE", "DELETE": "DELETE"}
            action = action_map.get(event.upper(), None) if event else None

            if not action or action == "NONE" or not text:
                continue

            if action == "INSERT":
                operations.append(MemoryOperation(action="INSERT", text=text))

            elif action == "UPDATE":
                real_id = uuid_map.get(item_id)
                if real_id:
                    operations.append(MemoryOperation(action="UPDATE", text=text, memory_id=real_id))
                else:
                    logger.warning(f"UPDATE: unknown id '{item_id}', treating as INSERT")
                    operations.append(MemoryOperation(action="INSERT", text=text))

            elif action == "DELETE":
                real_id = uuid_map.get(item_id)
                if real_id:
                    operations.append(MemoryOperation(action="DELETE", text=text, memory_id=real_id))
                else:
                    logger.warning(f"DELETE: unknown id '{item_id}', skipping")

            # NONE = no change, skip

        return operations

    # ── Helper: filter by CRUD flags ──

    def _filter_by_crud_flags(self, operations, config):
        """Remove operations that the lane's CRUD flags don't allow."""
        allowed = []
        for op in operations:
            if op.action == "INSERT" and not config.enable_inserts:
                continue
            if op.action == "UPDATE" and not config.enable_updates:
                continue
            if op.action == "DELETE" and not config.enable_deletes:
                continue
            allowed.append(op)
        return allowed
