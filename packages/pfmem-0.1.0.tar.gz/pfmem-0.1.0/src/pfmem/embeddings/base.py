from abc import ABC, abstractmethod
from typing import Literal, Optional

from pfmem.configs.embeddings.base import BaseEmbedderConfig


class EmbeddingBase(ABC):
    def __init__(self, config: Optional[BaseEmbedderConfig] = None):
        self.config = config if config else BaseEmbedderConfig()

    @abstractmethod
    def embed(self, text, memory_action: Optional[Literal["add", "search", "update"]] = None):
        pass

    def embed_many(self, texts: list[str], memory_action: Optional[Literal["add", "search", "update"]] = None) -> list:
        """Batch embed multiple texts. Default: call embed() in a loop.
        Override in subclasses for a single batched API call."""
        return [self.embed(t, memory_action) for t in texts]
