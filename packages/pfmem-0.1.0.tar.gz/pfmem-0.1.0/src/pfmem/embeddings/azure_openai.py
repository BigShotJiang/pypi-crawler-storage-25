import os
from typing import Literal, Optional

from pfmem.configs.embeddings.base import BaseEmbedderConfig
from pfmem.embeddings.base import EmbeddingBase

SCOPE = "https://cognitiveservices.azure.com/.default"


class AzureOpenAIEmbedding(EmbeddingBase):
    def __init__(self, config: Optional[BaseEmbedderConfig] = None):
        super().__init__(config)

        from openai import AzureOpenAI
        api_key = self.config.azure_kwargs.api_key or os.getenv("EMBEDDING_AZURE_OPENAI_API_KEY")
        azure_deployment = self.config.azure_kwargs.azure_deployment or os.getenv("EMBEDDING_AZURE_DEPLOYMENT")
        azure_endpoint = self.config.azure_kwargs.azure_endpoint or os.getenv("EMBEDDING_AZURE_ENDPOINT")
        api_version = self.config.azure_kwargs.api_version or os.getenv("EMBEDDING_AZURE_API_VERSION")

        if not api_key:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
            credential = DefaultAzureCredential()
            azure_ad_token_provider = get_bearer_token_provider(credential, SCOPE)
        else:
            azure_ad_token_provider = None

        self.client = AzureOpenAI(
            azure_deployment=azure_deployment, azure_endpoint=azure_endpoint,
            azure_ad_token_provider=azure_ad_token_provider,
            api_version=api_version, api_key=api_key,
            http_client=self.config.http_client,
            default_headers=self.config.azure_kwargs.default_headers,
        )

    def embed(self, text, memory_action: Optional[Literal["add", "search", "update"]] = None):
        text = text.replace("\n", " ")
        return self.client.embeddings.create(input=[text], model=self.config.model).data[0].embedding

    def embed_many(self, texts: list[str], memory_action: Optional[Literal["add", "search", "update"]] = None) -> list:
        cleaned = [t.replace("\n", " ") for t in texts]
        response = self.client.embeddings.create(input=cleaned, model=self.config.model)
        return [d.embedding for d in response.data]
