"""Vector store interface and common output format."""

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Optional

from pydantic import BaseModel, field_validator


class MemoryRecord(BaseModel):
    """Common output format. Every vector store converts its native results to this.

    Provider-specific conversion happens inside the vector store implementation.
    Memory class only sees MemoryRecord — never raw dicts or provider types.
    All datetime fields are guaranteed to be timezone-aware (UTC).
    """
    id: str
    text: str = ""
    score: Optional[float] = None
    lane: Optional[str] = None
    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    session_id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    metadata: dict = {}

    @field_validator("created_at", "updated_at", "expires_at", mode="before")
    @classmethod
    def ensure_timezone_aware(cls, v):
        """Normalize naive datetimes to UTC. Providers may return naive datetimes."""
        if v is not None and isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v


class VectorStoreBase(ABC):
    @abstractmethod
    def create_col(self, name, vector_size, distance): pass

    @abstractmethod
    def insert(self, vectors, payloads=None, ids=None): pass

    @abstractmethod
    def search(self, query, vectors, limit=5, filters=None) -> list[MemoryRecord]: pass

    @abstractmethod
    def delete(self, vector_id): pass

    @abstractmethod
    def update(self, vector_id, vector=None, payload=None): pass

    @abstractmethod
    def get(self, vector_id) -> Optional[MemoryRecord]: pass

    @abstractmethod
    def list_cols(self): pass

    @abstractmethod
    def delete_col(self): pass

    @abstractmethod
    def col_info(self): pass

    @abstractmethod
    def list(self, filters=None, limit=None) -> list[MemoryRecord]: pass

    @abstractmethod
    def reset(self): pass
