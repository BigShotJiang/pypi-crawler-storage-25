"""MongoDB vector store with pre-filter support.

Fixes from old version:
1. Top-level fields instead of nested payload (enables pre-filter)
2. Filters inside $vectorSearch, not $match after (pre-filter, not post-filter)
3. numCandidates passed separately from limit
4. Index check at __init__, not every search
5. Returns MemoryRecord (common format), not provider-specific OutputData
"""

import logging
from datetime import datetime, timezone
from typing import Optional

try:
    from pymongo import MongoClient
    from pymongo.operations import SearchIndexModel
except ImportError:
    raise ImportError("pymongo is required. Install with: pip install pymongo")

from pfmem.vector_stores.base import MemoryRecord, VectorStoreBase

logger = logging.getLogger(__name__)


class MongoDB(VectorStoreBase):
    VECTOR_TYPE = "knnVector"
    SIMILARITY_METRIC = "cosine"

    def __init__(self, db_name, collection_name, embedding_model_dims, mongo_uri):
        self.collection_name = collection_name
        self.embedding_model_dims = embedding_model_dims
        self.db_name = db_name
        self.client = MongoClient(mongo_uri)
        self.db = self.client[db_name]
        self.collection = self.create_col()
        self._verify_index()

    def create_col(self, name=None, vector_size=None, distance=None):
        db = self.client[self.db_name]
        if self.collection_name not in db.list_collection_names():
            col = db[self.collection_name]
            col.insert_one({"_id": 0, "placeholder": True})
            col.delete_one({"_id": 0})
        else:
            col = db[self.collection_name]

        self.index_name = f"{self.collection_name}_vector_index"

        if not list(col.list_search_indexes(name=self.index_name)):
            col.create_search_index(SearchIndexModel(
                name=self.index_name,
                definition={"mappings": {"dynamic": False, "fields": {
                    "embedding": {
                        "type": self.VECTOR_TYPE,
                        "dimensions": self.embedding_model_dims,
                        "similarity": self.SIMILARITY_METRIC,
                    },
                    "user_id": {"type": "token"},
                    "agent_id": {"type": "token"},
                    "lane": {"type": "token"},
                    "session_id": {"type": "token"},
                }}},
            ))
        return col

    def _verify_index(self):
        indexes = list(self.collection.list_search_indexes(name=self.index_name))
        if not indexes:
            logger.warning(
                f"Vector search index '{self.index_name}' not found. "
                f"Search will not work until the index is created in MongoDB Atlas."
            )
            self._index_ready = False
        else:
            self._index_ready = True

    # ── INSERT ──

    def insert(self, vectors, payloads=None, ids=None):
        data = []
        for vec, payload, _id in zip(
            vectors,
            payloads or [{}] * len(vectors),
            ids or [None] * len(vectors),
        ):
            doc = {
                "_id": _id,
                "embedding": vec,
                **payload,
            }
            if "created_at" not in doc:
                doc["created_at"] = datetime.now(timezone.utc)
            if "updated_at" not in doc:
                doc["updated_at"] = datetime.now(timezone.utc)
            doc.setdefault("valid_from", None)
            doc.setdefault("valid_to", None)
            doc.setdefault("category", None)
            doc.setdefault("source_text", None)
            doc.setdefault("metadata", {})
            data.append(doc)
        self.collection.insert_many(data)

    # ── SEARCH ──

    def search(self, query, vectors, limit=5, filters=None, num_candidates=100) -> list[MemoryRecord]:
        if not self._index_ready:
            # Index still building — fall back to plain filter query so callers don't miss existing memories
            safe_filters = {k: v for k, v in (filters or {}).items() if k not in ("exclude_session_id", "session_ids")}
            logger.warning("Vector index not ready, falling back to list() for search.")
            return self.list(filters=safe_filters, limit=limit)

        # Build pre-filter — only include fields that were actually passed
        filter_doc = {}
        if filters:
            for key, value in filters.items():
                if value is None:
                    continue
                if key == "exclude_session_id":
                    filter_doc["session_id"] = {"$ne": value}
                elif key == "session_ids":
                    filter_doc["session_id"] = {"$in": value}
                else:
                    filter_doc[key] = {"$eq": value}

        vector_search = {
            "index": self.index_name,
            "queryVector": vectors,
            "path": "embedding",
            "limit": limit,
            "numCandidates": num_candidates,
        }
        if filter_doc:
            vector_search["filter"] = filter_doc

        pipeline = [
            {"$vectorSearch": vector_search},
            {"$set": {"score": {"$meta": "vectorSearchScore"}}},
            {"$project": {"embedding": 0}},
        ]

        results = list(self.collection.aggregate(pipeline))
        return [self._doc_to_record(d) for d in results]

    # ── GET ──

    def get(self, vector_id) -> Optional[MemoryRecord]:
        doc = self.collection.find_one({"_id": vector_id})
        if doc:
            return self._doc_to_record(doc)
        logger.warning(f"Document with ID '{vector_id}' not found.")
        return None

    # ── UPDATE ──

    def update(self, vector_id, vector=None, payload=None):
        fields = {}
        if vector is not None:
            fields["embedding"] = vector
        if payload is not None:
            fields.update(payload)
        fields["updated_at"] = datetime.now(timezone.utc)
        if fields:
            self.collection.update_one({"_id": vector_id}, {"$set": fields})

    # ── DELETE ──

    def delete(self, vector_id):
        self.collection.delete_one({"_id": vector_id})

    # ── LIST ──

    def list(self, filters=None, limit=100) -> list[MemoryRecord]:
        query = {}
        if filters:
            conditions = []
            for k, v in filters.items():
                if v is None:
                    continue
                if k == "session_ids":
                    conditions.append({"session_id": {"$in": v}})
                else:
                    conditions.append({k: v})
            if conditions:
                query = {"$and": conditions}
        cursor = self.collection.find(query).limit(limit)
        return [self._doc_to_record(d) for d in cursor]

    # ── Utility ──

    def list_cols(self):
        return self.db.list_collection_names()

    def delete_col(self):
        self.collection.drop()

    def col_info(self):
        stats = self.db.command("collstats", self.collection_name)
        return {"name": self.collection_name, "count": stats.get("count"), "size": stats.get("size")}

    def reset(self):
        self.delete_col()
        self.collection = self.create_col()
        self._verify_index()

    def _doc_to_record(self, doc) -> MemoryRecord:
        """Convert a MongoDB document to the common MemoryRecord format."""
        return MemoryRecord(
            id=str(doc["_id"]),
            text=doc.get("text", ""),
            score=doc.get("score"),
            lane=doc.get("lane"),
            user_id=doc.get("user_id"),
            agent_id=doc.get("agent_id"),
            session_id=doc.get("session_id"),
            created_at=doc.get("created_at"),
            updated_at=doc.get("updated_at"),
            expires_at=doc.get("expires_at"),
            metadata=doc.get("metadata", {}),
        )

    def __del__(self):
        try:
            if hasattr(self, "client"):
                self.client.close()
        except Exception:
            pass
