from typing import Dict, List, Optional

from pfmem.configs.llms.base import BaseLlmConfig
from pfmem.llms.base import LLMBase

try:
    from langchain.chat_models.base import BaseChatModel
    from langchain_core.messages import AIMessage
except ImportError:
    raise ImportError("langchain is not installed. Please install it using `pip install langchain`")


class LangchainLLM(LLMBase):
    def __init__(self, config: Optional[BaseLlmConfig] = None):
        super().__init__(config)
        if self.config.model is None:
            raise ValueError("`model` parameter is required")
        if not isinstance(self.config.model, BaseChatModel):
            raise ValueError("`model` must be an instance of BaseChatModel")
        self.langchain_model = self.config.model

    def _parse_response(self, response: AIMessage, tools):
        if not tools:
            return response.content
        processed = {"content": response.content, "tool_calls": []}
        for tc in response.tool_calls:
            processed["tool_calls"].append({"name": tc["name"], "arguments": tc["args"]})
        return processed

    def generate_response(self, messages, response_format=None, tools=None, tool_choice="auto"):
        lc_messages = []
        for m in messages:
            role_map = {"system": "system", "user": "human", "assistant": "ai"}
            lc_messages.append((role_map.get(m["role"], m["role"]), m["content"]))
        model = self.langchain_model
        if tools:
            model = model.bind_tools(tools=tools, tool_choice=tool_choice)
        response = model.invoke(lc_messages)
        return self._parse_response(response, tools)
