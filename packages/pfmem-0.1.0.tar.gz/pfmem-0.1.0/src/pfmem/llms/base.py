from abc import ABC, abstractmethod
from typing import Dict, List, Optional


class LLMBase(ABC):
    def __init__(self, config=None):
        from pfmem.configs.llms.base import BaseLlmConfig
        if config is None:
            self.config = BaseLlmConfig()
        elif isinstance(config, dict):
            self.config = BaseLlmConfig(**config)
        else:
            self.config = config

    @abstractmethod
    def generate_response(self, messages: List[Dict[str, str]], tools=None, tool_choice="auto", **kwargs):
        pass

    def _get_common_params(self, **kwargs) -> Dict:
        return {"temperature": self.config.temperature, "max_tokens": self.config.max_tokens, "top_p": self.config.top_p, **kwargs}

    def _is_reasoning_model(self, model: str) -> bool:
        model_lower = (model or "").lower()
        return any(m in model_lower for m in ["gpt-5", "o1", "o3"])

    def _get_supported_params(self, **kwargs) -> Dict:
        model = getattr(self.config, "model", "")
        if self._is_reasoning_model(model or ""):
            return {k: v for k, v in kwargs.items() if k in ("messages", "response_format", "tools", "tool_choice")}
        return self._get_common_params(**kwargs)
