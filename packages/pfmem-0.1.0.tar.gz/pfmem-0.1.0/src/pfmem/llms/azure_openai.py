import json
import os
from typing import Dict, List, Optional, Union

from pfmem.configs.llms.azure_openai import AzureOpenAIConfig
from pfmem.configs.llms.base import BaseLlmConfig
from pfmem.llms.base import LLMBase

SCOPE = "https://cognitiveservices.azure.com/.default"


class AzureOpenAILLM(LLMBase):
    def __init__(self, config: Optional[Union[BaseLlmConfig, AzureOpenAIConfig, Dict]] = None):
        if config is None:
            config = AzureOpenAIConfig()
        elif isinstance(config, dict):
            config = AzureOpenAIConfig(**config)
        elif isinstance(config, BaseLlmConfig) and not isinstance(config, AzureOpenAIConfig):
            config = AzureOpenAIConfig(model=config.model, temperature=config.temperature,
                                       api_key=config.api_key, max_tokens=config.max_tokens,
                                       top_p=config.top_p, top_k=config.top_k)
        super().__init__(config)

        if not self.config.model:
            self.config.model = "gpt-4o"

        from openai import AzureOpenAI
        api_key = self.config.azure_kwargs.api_key or os.getenv("LLM_AZURE_OPENAI_API_KEY")
        azure_deployment = self.config.azure_kwargs.azure_deployment or os.getenv("LLM_AZURE_DEPLOYMENT")
        azure_endpoint = self.config.azure_kwargs.azure_endpoint or os.getenv("LLM_AZURE_ENDPOINT")
        api_version = self.config.azure_kwargs.api_version or os.getenv("LLM_AZURE_API_VERSION")

        if not api_key:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
            credential = DefaultAzureCredential()
            azure_ad_token_provider = get_bearer_token_provider(credential, SCOPE)
        else:
            azure_ad_token_provider = None

        self.client = AzureOpenAI(
            azure_deployment=azure_deployment, azure_endpoint=azure_endpoint,
            azure_ad_token_provider=azure_ad_token_provider,
            api_version=api_version, api_key=api_key,
            http_client=self.config.http_client,
            default_headers=self.config.azure_kwargs.default_headers,
        )

    def generate_response(self, messages, response_format=None, tools=None, tool_choice="auto", **kwargs):
        params = self._get_supported_params(messages=messages, **kwargs)
        params.update({"model": self.config.model, "messages": messages})
        if response_format:
            params["response_format"] = response_format
        if tools:
            params["tools"] = tools
            params["tool_choice"] = tool_choice
        response = self.client.chat.completions.create(**params)
        if tools:
            result = {"content": response.choices[0].message.content, "tool_calls": []}
            if response.choices[0].message.tool_calls:
                for tc in response.choices[0].message.tool_calls:
                    result["tool_calls"].append({"name": tc.function.name, "arguments": json.loads(tc.function.arguments)})
            return result
        return response.choices[0].message.content
