"""Input guards and utilities for memory processing."""

import re


def filter_messages_by_roles(messages: list[dict], include_roles: list[str]) -> list[dict]:
    """Keep only messages whose role is in include_roles. Always exclude 'system'."""
    return [
        m for m in messages
        if m.get("role") in include_roles and m.get("role") != "system"
    ]


def strip_private_tags(text: str) -> str:
    """Remove <private>...</private> blocks from text before LLM calls."""
    return re.sub(r"<private>.*?</private>", "", text, flags=re.DOTALL).strip()


def is_too_short(text: str, min_chars: int = 20) -> bool:
    """Return True if text is too short to bother extracting from."""
    return len(text.strip()) < min_chars
