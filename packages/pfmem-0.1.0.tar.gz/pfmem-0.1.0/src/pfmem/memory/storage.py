"""History tracking for memory CRUD events.

Replaces the old SQLiteManager. Writes to a MongoDB collection
(pfmem_memories_history) in the same database as the memories.
"""

import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class MongoHistoryManager:
    """Tracks INSERT/UPDATE/DELETE events on memories."""

    def __init__(self, collection):
        """collection: a pymongo Collection object for 'pfmem_memories_history'."""
        self.collection = collection

    def add_history(self, memory_id, user_id, agent_id, event, old_memory, new_memory, lane):
        """Record a single CRUD event.

        Args:
            memory_id: which memory was affected
            user_id: owner (can be None for agent-scoped memories)
            agent_id: which agent (can be None for user-scoped memories)
            event: "INSERT", "UPDATE", or "DELETE"
            old_memory: previous text (None for INSERT)
            new_memory: new text (None for DELETE)
            lane: which lane ("semantic", "episodic", etc.)
        """
        doc = {
            "memory_id": memory_id,
            "user_id": user_id,
            "agent_id": agent_id,
            "event": event,
            "old_memory": old_memory,
            "new_memory": new_memory,
            "lane": lane,
            "created_at": datetime.now(timezone.utc),
        }
        try:
            self.collection.insert_one(doc)
        except Exception as e:
            logger.error(f"Failed to write history: {e}")

    def get_history(self, memory_id):
        """Get all events for a memory, oldest first."""
        cursor = self.collection.find(
            {"memory_id": memory_id}
        ).sort("created_at", 1)

        return [
            {
                "memory_id": doc["memory_id"],
                "user_id": doc.get("user_id"),
                "agent_id": doc.get("agent_id"),
                "event": doc["event"],
                "old_memory": doc.get("old_memory"),
                "new_memory": doc.get("new_memory"),
                "lane": doc.get("lane"),
                "created_at": doc.get("created_at"),
            }
            for doc in cursor
        ]
