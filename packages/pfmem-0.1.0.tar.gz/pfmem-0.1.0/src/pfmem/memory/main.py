"""PFMEM Memory class — the stateful shell.

Owns all DB access. Processors are pure (no DB).
This class fetches data, calls processors, executes returned operations.
"""

import logging
import uuid
from datetime import datetime, timezone

from pfmem.configs.base import MemoryConfig
from pfmem.configs.lanes import MemoryLane
from pfmem.memory.storage import MongoHistoryManager
from pfmem.memory.utils import filter_messages_by_roles, is_too_short, strip_private_tags
from pfmem.utils.factory import EmbedderFactory, LlmFactory, VectorStoreFactory

logger = logging.getLogger(__name__)


class Memory:
    def __init__(self, config: MemoryConfig | None = None):
        self.config = config or MemoryConfig()

        self.embedder = EmbedderFactory.create(
            self.config.embedder.provider,
            self.config.embedder.config,
        )
        self.vector_store = VectorStoreFactory.create(
            self.config.vector_store.provider,
            self.config.vector_store.config,
        )
        self.llm = LlmFactory.create(
            self.config.llm.provider,
            self.config.llm.config,
        )

        # History manager — uses same MongoDB client as vector store
        self.history = None
        if self.config.enable_history and hasattr(self.vector_store, 'db'):
            history_col = self.vector_store.db["pfmem_memories_history"]
            self.history = MongoHistoryManager(history_col)

    # ── ADD ──

    def add(self, messages, *, user_id, agent_id, session_id,
            context=None, metadata=None, lanes: list[MemoryLane] | None = None, last_n=None, expires_at=None):
        """Extract and store memories from a conversation.

        Args:
            messages: Current turn messages in OpenAI format [{"role": ..., "content": ...}].
                These are the messages to extract new facts from. Can also be a plain string
                or a single dict — both are auto-wrapped into a list.
            user_id: Who the memories belong to (required). Used for scoping — memories
                are stored and retrieved per user.
            agent_id: Which agent is storing the memories (required). Allows multiple
                agents to maintain separate memory spaces for the same user.
            session_id: Current conversation session ID (required). Stored on each
                memory document. Used to track which session created or last updated
                a memory.
            context: Previous conversation turns for reference only (optional).
                Same format as messages. The LLM can use these to resolve references
                (e.g. "it", "that", "he") but will NOT extract facts from them.
                If None, all messages are treated as new (backward compatible).
            metadata: Extra fields to store on each memory document (optional).
                Arbitrary dict — stored as-is on every inserted/updated record.
            lanes: List of MemoryLane enums to process (optional). Defaults to all
                lanes enabled in config. Example: [MemoryLane.SEMANTIC].
                Passing a lane not in config silently skips it.
            last_n: Cap on how many messages (from the messages param) to send to the
                LLM (optional). Takes the last N messages. If smaller than the lane's
                context_window, this wins. Context gets the remaining budget from the
                total window. Example: context_window=10, last_n=3 → 3 messages(from messages arr) + up
                to 7 context messages.
            expires_at: UTC datetime when these memories should expire (optional).
                Expired memories are excluded from search results and cleaned up by
                cleanup_expired(). None means memories never expire.

        Returns:
            dict keyed by lane name:
            {"semantic": {"inserted": 2, "updated": 1, "deleted": 0}, ...}
        """

        if isinstance(messages, str):
            messages = [{"role": "user", "content": messages}]
        elif isinstance(messages, dict):
            messages = [messages]

        metadata = metadata or {}

        active_lanes = self.config.lanes
        if lanes:
            if not all(isinstance(l, MemoryLane) for l in lanes):
                raise TypeError("lanes must be a list of MemoryLane enums, e.g. [MemoryLane.SEMANTIC]")
            lane_values = {l.value for l in lanes}
            active_lanes = [l for l in active_lanes if l.name in lane_values]

        results = {}
        for lane in active_lanes:
            lane_result = self._add_to_lane(
                messages, lane, user_id, agent_id, session_id, metadata, last_n, expires_at, context,
            )
            if lane_result:
                results[lane.name] = lane_result

        return results

    def _add_to_lane(self, messages, lane, user_id, agent_id, session_id, metadata, last_n, expires_at, context=None):
        """Process one lane: filter → guard → extract facts → fetch relevant existing → CRUD → execute."""

        # Step 1: Role filter both blocks
        filtered_messages = filter_messages_by_roles(messages, lane.include_roles)
        filtered_context  = filter_messages_by_roles(context or [], lane.include_roles)

        if not filtered_messages:
            return None

        # Step 2: Budget split — total messages seen by LLM capped at context_window
        # messages get priority (extraction target), context fills remainder
        total = lane.context_window
        if last_n is not None:
            filtered_messages = filtered_messages[-last_n:]
        msg_count = min(len(filtered_messages), total)
        ctx_budget = total - msg_count
        filtered_messages = filtered_messages[-msg_count:]
        filtered_context  = filtered_context[-ctx_budget:] if ctx_budget > 0 else []

        # Step 3: Strip private tags (copy to avoid mutating caller's data)
        filtered_messages = [
            {**msg, "content": strip_private_tags(msg["content"])} if msg.get("content") else msg
            for msg in filtered_messages
        ]
        filtered_context = [
            {**msg, "content": strip_private_tags(msg["content"])} if msg.get("content") else msg
            for msg in filtered_context
        ]

        # Step 4: Min length guard (on current messages only)
        total_text = " ".join(m.get("content", "") for m in filtered_messages)
        if is_too_short(total_text):
            return None

        if not lane.processor_cls:
            logger.error(f"Lane '{lane.name}' has no processor_cls set")
            return None
        processor = lane.processor_cls(llm=self.llm, embedder=self.embedder)

        # Step 5: LLM call 1 — extract facts and embed them (embeddings cached for reuse)
        facts, fact_embeddings = processor.extract_facts(filtered_messages, lane, context_messages=filtered_context)
        if not facts:
            return None

        # Step 6: Fetch only semantically relevant existing memories (one search per fact)
        # Additive lanes skip this — they never update or delete existing memories
        is_additive = not lane.enable_updates and not lane.enable_deletes
        if is_additive:
            existing = []
        else:
            existing = self._fetch_existing_for_facts(facts, fact_embeddings, user_id, agent_id, lane)

        # Step 7: LLM call 2 — CRUD decision (additive lanes get INSERT shortcut inside decide_crud)
        operations = processor.decide_crud(facts, existing, lane)

        # Step 8: Execute operations (fact_embeddings reused in _do_insert to avoid re-embedding)
        return self._execute_operations(
            operations, lane, user_id, agent_id, session_id, metadata, expires_at, fact_embeddings,
        )

    def _fetch_existing_for_facts(self, facts, fact_embeddings, user_id, agent_id, lane):
        """Fetch semantically relevant existing memories — one vector search per new fact.

        Reuses embeddings computed in extract_facts() so no extra embed calls.
        Deduplicates by ID across all fact searches (same approach as mem0).
        """
        filters = {"lane": lane.name}
        if user_id:
            filters["user_id"] = user_id
        if agent_id:
            filters["agent_id"] = agent_id

        seen_ids = set()
        existing = []
        for fact in facts:
            vector = fact_embeddings.get(fact)
            if vector is None:
                continue
            try:
                # query=None because the vector is already computed from the fact embedding.
                # No need to embed a query string — you pass the vector directly. 
                results = self.vector_store.search(
                    query=None,
                    vectors=vector,
                    limit=lane.existing_fetch_limit,
                    filters=filters,
                    num_candidates=lane.num_candidates,
                )
            except TypeError:
                try:
                    results = self.vector_store.search(
                        query=None,
                        vectors=vector,
                        limit=lane.existing_fetch_limit,
                        filters=filters,
                    )
                except Exception as e:
                    logger.error(f"Error fetching existing memories for lane '{lane.name}': {e}")
                    continue
            except Exception as e:
                logger.error(f"Error fetching existing memories for lane '{lane.name}': {e}")
                continue
            for r in results:
                if r.id not in seen_ids:
                    seen_ids.add(r.id)
                    existing.append({"id": r.id, "text": r.text})

        logger.debug(f"Lane '{lane.name}': {len(facts)} facts → {len(existing)} relevant existing memories")
        return existing

    def _execute_operations(self, operations, lane, user_id, agent_id, session_id, metadata, expires_at, fact_embeddings=None):
        """Execute INSERT/UPDATE/DELETE operations on vector store."""
        summary = {"inserted": 0, "updated": 0, "deleted": 0}

        for op in operations:
            try:
                if op.action == "INSERT":
                    self._do_insert(op, lane, user_id, agent_id, session_id, metadata, expires_at, fact_embeddings)
                    summary["inserted"] += 1
                elif op.action == "UPDATE" and op.memory_id:
                    self._do_update(op, lane, user_id, agent_id, session_id, metadata, fact_embeddings)
                    summary["updated"] += 1
                elif op.action == "DELETE" and op.memory_id:
                    self._do_delete(op, lane, user_id, agent_id)
                    summary["deleted"] += 1
            except Exception as e:
                logger.error(f"Error executing {op.action} in lane '{lane.name}': {e}")

        return summary

    def _do_insert(self, op, lane, user_id, agent_id, session_id, metadata, expires_at, fact_embeddings=None):
        """Insert a new memory document."""
        memory_id = str(uuid.uuid4())
        # Reuse cached embedding from extract_facts() if available — avoids a second embed call
        if fact_embeddings and op.text in fact_embeddings:
            embedding = fact_embeddings[op.text]
        else:
            embedding = self.embedder.embed(op.text, "add")

        payload = {
            "text": op.text,
            "lane": lane.name,
            "user_id": user_id,
            "agent_id": agent_id,
            "session_id": session_id,
            "expires_at": expires_at,
            **metadata,
        }

        self.vector_store.insert(vectors=[embedding], payloads=[payload], ids=[memory_id])

        if self.history:
            self.history.add_history(
                memory_id=memory_id, user_id=user_id, agent_id=agent_id,
                event="INSERT", old_memory=None, new_memory=op.text, lane=lane.name,
            )

    def _do_update(self, op, lane, user_id, agent_id, session_id, metadata, fact_embeddings=None):
        """Update an existing memory document. Preserves original session_id."""
        if fact_embeddings and op.text in fact_embeddings:
            embedding = fact_embeddings[op.text]
        else:
            embedding = self.embedder.embed(op.text, "update")

        existing = self.vector_store.get(op.memory_id)
        old_text = None
        original_session_id = session_id
        if existing:
            old_text = existing.text
            original_session_id = existing.session_id or session_id

        payload = {
            "text": op.text,
            "lane": lane.name,
            "user_id": user_id,
            "agent_id": agent_id,
            "session_id": original_session_id,
            **metadata,
        }

        self.vector_store.update(vector_id=op.memory_id, vector=embedding, payload=payload)

        if self.history:
            self.history.add_history(
                memory_id=op.memory_id, user_id=user_id, agent_id=agent_id,
                event="UPDATE", old_memory=old_text, new_memory=op.text, lane=lane.name,
            )

    def _do_delete(self, op, lane, user_id, agent_id):
        """Delete an existing memory document."""
        self.vector_store.delete(vector_id=op.memory_id)

        if self.history:
            self.history.add_history(
                memory_id=op.memory_id, user_id=user_id, agent_id=agent_id,
                event="DELETE", old_memory=op.text, new_memory=None, lane=lane.name,
            )

    # ── SEARCH ──

    def search(self, query, *, user_id=None, agent_id=None, session_ids=None,
               exclude_session_id=None, lanes: list[MemoryLane] | None = None, messages=None):
        """Search memories across lanes.

        Args:
            query: natural language search query
            user_id: scope to this user's memories
            agent_id: scope to this agent's memories
            session_ids: narrow to memories from these specific sessions (list of str)
            exclude_session_id: exclude memories from this session (typically current session)
            lanes: list of lane names to search (None = all)
            messages: conversation history for query expansion (optional)

        Returns:
            list of memory dicts sorted by score descending
        """
        if not user_id and not agent_id:
            raise ValueError("At least one of 'user_id' or 'agent_id' must be provided.")
        if session_ids and exclude_session_id and exclude_session_id in session_ids:
            raise ValueError(
                f"Conflict: '{exclude_session_id}' cannot be in both session_ids and exclude_session_id."
            )
        if user_id and not agent_id:
            logger.warning("search: no agent_id — searching across all agents for user '%s'.", user_id)
        if agent_id and not user_id:
            logger.warning("search: no user_id — searching across all users for agent '%s'.", agent_id)

        active_lanes = self.config.lanes
        if lanes:
            if not all(isinstance(l, MemoryLane) for l in lanes):
                raise TypeError("lanes must be a list of MemoryLane enums, e.g. [MemoryLane.SEMANTIC]")
            lane_values = {l.value for l in lanes}
            active_lanes = [l for l in active_lanes if l.name in lane_values]

        search_cfg = self.config.search

        # Mode: "always" — expand before searching
        if search_cfg.query_expansion and messages and search_cfg.expansion_mode == "always":
            query = self._expand_query(query, messages)

        query_vector = self.embedder.embed(query, "search")

        all_results = []
        for lane in active_lanes:
            lane_results = self._search_lane(
                query_vector, lane, user_id, agent_id, exclude_session_id, session_ids,
            )
            all_results.extend(lane_results)

        all_results.sort(key=lambda r: r.get("score", 0), reverse=True)

        # Mode: "threshold" — expand and re-search if top score is weak
        if (search_cfg.query_expansion and messages
                and search_cfg.expansion_mode == "threshold"
                and (not all_results or all_results[0].get("score", 0) < search_cfg.expansion_threshold)):
            expanded = self._expand_query(query, messages)
            query_vector = self.embedder.embed(expanded, "search")
            all_results = []
            for lane in active_lanes:
                lane_results = self._search_lane(
                    query_vector, lane, user_id, agent_id, exclude_session_id, session_ids,
                )
                all_results.extend(lane_results)
            all_results.sort(key=lambda r: r.get("score", 0), reverse=True)

        return self._deduplicate(all_results)

    @staticmethod
    def _deduplicate(results):
        """Remove duplicate memories by text, keeping highest score (first after sort)."""
        seen = set()
        deduped = []
        for r in results:
            key = r["text"].strip().lower()
            if key not in seen:
                seen.add(key)
                deduped.append(r)
        return deduped

    def _expand_query(self, query, messages):
        """Use LLM to rewrite a vague query using conversation context."""
        from pfmem.configs.prompts import QUERY_EXPANSION_PROMPT
        prompt = self.config.search.expansion_prompt or QUERY_EXPANSION_PROMPT
        user_msgs = "\n".join(
            m.get("content", "") for m in messages if m.get("role") == "user"
        )
        filled = prompt.format(messages=user_msgs, query=query)
        result = self.llm.generate_response([{"role": "user", "content": filled}])
        if not isinstance(result, str):
            logger.warning("Query expansion returned non-string, using original query")
            return query
        return result.strip()

    def _search_lane(self, query_vector, lane, user_id, agent_id, exclude_session_id, session_ids=None):
        """Search one lane with pre-filters and threshold."""
        filters = {"lane": lane.name}
        if user_id:
            filters["user_id"] = user_id
        if agent_id:
            filters["agent_id"] = agent_id
        if exclude_session_id:
            filters["exclude_session_id"] = exclude_session_id
        if session_ids:
            filters["session_ids"] = session_ids

        try:
            results = self.vector_store.search(
                query=None,
                vectors=query_vector,
                limit=lane.top_k,
                filters=filters,
                num_candidates=lane.num_candidates,
            )
        except TypeError:
            results = self.vector_store.search(
                query=None,
                vectors=query_vector,
                limit=lane.top_k,
                filters=filters,
            )

        # Apply per-lane similarity threshold, filter expired, and format
        now = datetime.now(timezone.utc)
        return [
            {
                "id": r.id,
                "text": r.text,
                "lane": r.lane,
                "score": r.score,
                "user_id": r.user_id,
                "agent_id": r.agent_id,
                "session_id": r.session_id,
            }
            for r in results
            if r.score is not None
            and r.score >= lane.similarity_threshold
            and (r.expires_at is None or r.expires_at > now)
        ]

    # ── STATS ──

    def stats(self, *, user_id=None, agent_id=None):
        """Return a count breakdown of stored memories.

        Args:
            user_id: scope to this user (optional)
            agent_id: scope to this agent (optional)

        Returns:
            {
                "total_memories": int,
                "by_agent": {"agent_id": count, ...},
                "by_user":  {"user_id": count, ...},
                "by_lane":  {"lane": count, ...},
            }
        """
        if not hasattr(self.vector_store, 'collection'):
            raise RuntimeError("stats() requires MongoDB vector store with direct collection access")

        match = {}
        if user_id:
            match["user_id"] = user_id
        if agent_id:
            match["agent_id"] = agent_id

        pipeline = []
        if match:
            pipeline.append({"$match": match})
        pipeline.append({
            "$facet": {
                "total":    [{"$count": "n"}],
                "by_agent": [{"$group": {"_id": "$agent_id", "count": {"$sum": 1}}}],
                "by_user":  [{"$group": {"_id": "$user_id",  "count": {"$sum": 1}}}],
                "by_lane":  [{"$group": {"_id": "$lane",     "count": {"$sum": 1}}}],
            }
        })

        result = list(self.vector_store.collection.aggregate(pipeline))[0]
        return {
            "total_memories": result["total"][0]["n"] if result["total"] else 0,
            "by_agent": {str(r["_id"]): r["count"] for r in result["by_agent"]},
            "by_user":  {str(r["_id"]): r["count"] for r in result["by_user"]},
            "by_lane":  {str(r["_id"]): r["count"] for r in result["by_lane"]},
        }

    # ── CLEANUP ──

    def cleanup_expired(self):
        """Delete memories past their expires_at. Call via cron, not per-request."""
        if not hasattr(self.vector_store, 'collection'):
            logger.warning("cleanup_expired requires MongoDB vector store with direct collection access")
            return 0

        now = datetime.now(timezone.utc)
        result = self.vector_store.collection.delete_many({
            "expires_at": {"$ne": None, "$lt": now}
        })
        count = result.deleted_count
        if count:
            logger.info(f"Cleaned up {count} expired memories")
        return count

    # ── GET / GET_ALL / DELETE / DELETE_ALL / RESET ──

    def get(self, memory_id):
        """Get a single memory by ID."""
        r = self.vector_store.get(vector_id=memory_id)
        if not r:
            return None
        return {
            "id": r.id,
            "text": r.text,
            "lane": r.lane,
            "user_id": r.user_id,
            "agent_id": r.agent_id,
            "session_id": r.session_id,
            "created_at": r.created_at,
            "updated_at": r.updated_at,
        }

    def get_all(self, *, user_id=None, agent_id=None, session_ids=None, lane: MemoryLane | None = None, limit=100):
        """Get all memories matching the given filters."""
        if not user_id and not agent_id:
            raise ValueError("At least one of 'user_id' or 'agent_id' must be provided.")
        if lane is not None and not isinstance(lane, MemoryLane):
            raise TypeError("lane must be a MemoryLane enum, e.g. MemoryLane.EPISODIC")
        if user_id and not agent_id:
            logger.warning("get_all: no agent_id — fetching across all agents for user '%s'.", user_id)
        if agent_id and not user_id:
            logger.warning("get_all: no user_id — fetching across all users for agent '%s'.", agent_id)

        filters = {}
        if user_id:
            filters["user_id"] = user_id
        if agent_id:
            filters["agent_id"] = agent_id
        if session_ids:
            filters["session_ids"] = session_ids
        if lane:
            filters["lane"] = lane.value

        results = self.vector_store.list(filters=filters, limit=limit)
        return [
            {
                "id": r.id,
                "text": r.text,
                "lane": r.lane,
                "user_id": r.user_id,
                "agent_id": r.agent_id,
            }
            for r in results
        ]

    def delete(self, memory_id):
        """Delete a single memory by ID."""
        existing = self.vector_store.get(vector_id=memory_id)
        self.vector_store.delete(vector_id=memory_id)

        if self.history and existing:
            self.history.add_history(
                memory_id=memory_id,
                user_id=existing.user_id,
                agent_id=existing.agent_id,
                event="DELETE",
                old_memory=existing.text,
                new_memory=None,
                lane=existing.lane,
            )
        return {"message": "Memory deleted successfully."}

    def delete_all(self, *, user_id=None, agent_id=None, lane: MemoryLane | None = None):
        """Delete all memories matching the given filters."""
        if not user_id and not agent_id:
            raise ValueError("At least one of 'user_id' or 'agent_id' must be provided.")
        if lane is not None and not isinstance(lane, MemoryLane):
            raise TypeError("lane must be a MemoryLane enum, e.g. MemoryLane.SEMANTIC")
        if user_id and not agent_id:
            logger.warning("delete_all: no agent_id — deleting across all agents for user '%s'.", user_id)
        if agent_id and not user_id:
            logger.warning("delete_all: no user_id — deleting across all users for agent '%s'.", agent_id)

        filters = {}
        if user_id:
            filters["user_id"] = user_id
        if agent_id:
            filters["agent_id"] = agent_id
        if lane:
            filters["lane"] = lane.value

        memories = self.vector_store.list(filters=filters)
        count = 0
        for mem in memories:
            self.vector_store.delete(vector_id=mem.id)
            count += 1

        return {"message": f"Deleted {count} memories."}

    def reset(self):
        """Delete everything — all memories, all history."""
        self.vector_store.reset()
        if self.history:
            self.history.collection.delete_many({})
        return {"message": "All data reset."}
