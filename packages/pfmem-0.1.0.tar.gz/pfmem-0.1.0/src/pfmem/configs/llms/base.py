from typing import Any, Dict, Optional, Union

import httpx
from pydantic import BaseModel, ConfigDict, Field


class BaseLlmConfig(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    model: Optional[str] = None
    temperature: float = 0.1
    api_key: Optional[str] = None
    max_tokens: int = 2000
    top_p: float = 0.1
    top_k: int = 1
    enable_vision: bool = False
    vision_details: Optional[str] = "auto"
    http_client_proxies: Optional[Union[Dict, str]] = None
    http_client: Optional[Any] = Field(default=None, exclude=True)

    def model_post_init(self, __context: Any) -> None:
        if self.http_client_proxies and self.http_client is None:
            self.http_client = httpx.Client(proxies=self.http_client_proxies)
