from typing import Any, Dict, Optional

from pfmem.configs.base import AzureConfig
from pfmem.configs.llms.base import BaseLlmConfig


class AzureOpenAIConfig(BaseLlmConfig):
    azure_kwargs: Optional[Dict[str, Any]] = None

    def model_post_init(self, __context: Any) -> None:
        super().model_post_init(__context)
        if self.azure_kwargs is None:
            self.azure_kwargs = AzureConfig()
        elif isinstance(self.azure_kwargs, dict):
            self.azure_kwargs = AzureConfig(**self.azure_kwargs)


CONFIG_CLASS = AzureOpenAIConfig
