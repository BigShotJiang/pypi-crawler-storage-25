"""PFMEM configuration models."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from pfmem.configs.lanes import LaneConfig, SEMANTIC, EPISODIC, PROCEDURAL, OBSERVATIONAL


# ── Provider configs (unchanged from old code) ──

class LlmConfig(BaseModel):
    provider: str = Field(default="azure_openai", description="LLM provider name")
    config: Optional[Dict] = Field(default=None, description="Provider-specific config")

    @model_validator(mode="after")
    def validate_and_create_config(self) -> "LlmConfig":
        provider = self.provider
        config = self.config
        try:
            module = __import__(f"pfmem.configs.llms.{provider}", fromlist=["CONFIG_CLASS"])
            config_class = getattr(module, "CONFIG_CLASS", None)
            if not config_class:
                raise ValueError(f"Provider module 'pfmem.configs.llms.{provider}' missing CONFIG_CLASS")
            if config is None:
                config = {}
            if isinstance(config, dict):
                self.config = config_class(**config)
        except ImportError:
            raise ValueError(f"Unsupported LLM provider: {provider}")
        return self


class EmbedderConfig(BaseModel):
    provider: str = Field(default="azure_openai", description="Embedding provider name")
    config: Optional[Dict] = Field(default=None, description="Provider-specific config")

    @model_validator(mode="after")
    def validate_and_create_config(self) -> "EmbedderConfig":
        provider = self.provider
        config = self.config
        try:
            module = __import__(f"pfmem.configs.embeddings.{provider}", fromlist=["CONFIG_CLASS"])
            config_class = getattr(module, "CONFIG_CLASS", None)
            if not config_class:
                raise ValueError(f"Provider module 'pfmem.configs.embeddings.{provider}' missing CONFIG_CLASS")
            if config is None:
                config = {}
            if isinstance(config, dict):
                self.config = config_class(**config)
        except ImportError:
            raise ValueError(f"Unsupported embedder provider: {provider}")
        return self


class VectorStoreConfig(BaseModel):
    provider: str = Field(default="mongodb", description="Vector store provider name")
    config: Optional[Dict] = Field(default=None, description="Provider-specific config")

    @model_validator(mode="after")
    def validate_and_create_config(self) -> "VectorStoreConfig":
        provider = self.provider
        config = self.config
        try:
            module = __import__(f"pfmem.configs.vector_stores.{provider}", fromlist=["CONFIG_CLASS"])
            config_class = getattr(module, "CONFIG_CLASS", None)
            if not config_class:
                raise ValueError(f"Provider module 'pfmem.configs.vector_stores.{provider}' missing CONFIG_CLASS")
            if config is None:
                config = {}
            if isinstance(config, dict):
                self.config = config_class(**config)
        except ImportError:
            raise ValueError(f"Unsupported vector store provider: {provider}")
        return self


# ── Search config ──

class SearchConfig(BaseModel):
    query_expansion: bool = Field(default=False, description="Enable query expansion for vague queries")
    expansion_mode: str = Field(default="threshold", description="'always' or 'threshold'")
    expansion_threshold: float = Field(default=0.5, description="If top score < this, expand and re-search")
    expansion_prompt: Optional[str] = Field(default=None, description="Custom expansion prompt, or None for default")


# ── Main config ──

class MemoryConfig(BaseModel):
    vector_store: VectorStoreConfig = Field(default_factory=VectorStoreConfig)
    llm: LlmConfig = Field(default_factory=LlmConfig)
    embedder: EmbedderConfig = Field(default_factory=EmbedderConfig)
    version: str = Field(default="v2.0")

    # Lane system
    lanes: List[LaneConfig] = Field(
        default_factory=lambda: [SEMANTIC]
    )

    # Search config
    search: SearchConfig = Field(default_factory=SearchConfig)

    # History tracking (now MongoDB, not SQLite)
    enable_history: bool = True

    @field_validator("lanes")
    def validate_unique_lane_names(cls, lanes):
        names = [lane.name for lane in lanes]
        if len(names) != len(set(names)):
            raise ValueError(f"Duplicate lane names: {names}")
        return lanes


# ── Azure config (used by configs/llms/azure.py) ──

class AzureConfig(BaseModel):
    api_key: Optional[str] = None
    azure_deployment: Optional[str] = None
    azure_endpoint: Optional[str] = None
    api_version: Optional[str] = None
    default_headers: Optional[Dict[str, str]] = None
