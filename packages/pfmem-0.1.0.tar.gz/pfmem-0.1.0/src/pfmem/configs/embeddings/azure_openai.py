"""Azure OpenAI embedder config — uses base config as-is."""

from pfmem.configs.embeddings.base import BaseEmbedderConfig

CONFIG_CLASS = BaseEmbedderConfig
