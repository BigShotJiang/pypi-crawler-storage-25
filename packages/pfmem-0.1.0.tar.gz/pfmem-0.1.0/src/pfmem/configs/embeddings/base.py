from typing import Any, Dict, Optional, Union

import httpx
from pydantic import BaseModel, ConfigDict, Field

from pfmem.configs.base import AzureConfig


class BaseEmbedderConfig(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    model: Optional[str] = None
    api_key: Optional[str] = None
    embedding_dims: Optional[int] = None
    azure_kwargs: Optional[dict] = None
    http_client_proxies: Optional[Union[Dict, str]] = None
    http_client: Optional[Any] = Field(default=None, exclude=True)
    # Forward-compat with other providers
    ollama_base_url: Optional[str] = None
    openai_base_url: Optional[str] = None
    model_kwargs: Optional[dict] = None
    huggingface_base_url: Optional[str] = None
    vertex_credentials_json: Optional[str] = None
    memory_add_embedding_type: Optional[str] = None
    memory_update_embedding_type: Optional[str] = None
    memory_search_embedding_type: Optional[str] = None
    output_dimensionality: Optional[str] = None
    lmstudio_base_url: Optional[str] = None
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_region: Optional[str] = None

    def model_post_init(self, __context: Any) -> None:
        if self.http_client_proxies and self.http_client is None:
            self.http_client = httpx.Client(proxies=self.http_client_proxies)
        if self.azure_kwargs is None:
            self.azure_kwargs = AzureConfig()
        elif isinstance(self.azure_kwargs, dict):
            self.azure_kwargs = AzureConfig(**self.azure_kwargs)
        if self.model_kwargs is None:
            self.model_kwargs = {}


CONFIG_CLASS = BaseEmbedderConfig
