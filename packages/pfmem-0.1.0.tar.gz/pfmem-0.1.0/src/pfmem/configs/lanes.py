"""Memory lane definitions and configuration."""

from enum import Enum
from typing import Any, Optional, Type

from pydantic import BaseModel

from pfmem.configs.prompts import (
    EPISODIC_EXTRACTION_PROMPT,
    OBSERVATIONAL_EXTRACTION_PROMPT,
    PROCEDURAL_EXTRACTION_PROMPT,
    SEMANTIC_EXTRACTION_PROMPT,
    UPDATE_MEMORY_PROMPT,
)


class MemoryLane(Enum):
    SEMANTIC = "semantic"
    EPISODIC = "episodic"
    PROCEDURAL = "procedural"
    OBSERVATIONAL = "observational"


class LaneConfig(BaseModel):
    """Configuration for a single memory lane.

    This is pure data — it describes WHAT a lane does.
    The processor (referenced by processor_cls) describes HOW.
    """

    # ── Identity ──
    name: str  # stored as 'lane' field on every MongoDB document

    # ── Message routing ──
    # Which message roles this lane processes.
    # Messages with other roles are filtered out BEFORE the processor sees them.
    include_roles: list[str] = ["user"]

    # ── CRUD flags ──
    # These control what operations the processor is allowed to return.
    # When enable_updates=False AND enable_deletes=False → additive lane → skip LLM call 2.
    enable_inserts: bool = True
    enable_updates: bool = True
    enable_deletes: bool = True

    # ── Prompts ──
    extraction_prompt: str  # LLM call 1: what to extract

    # ── Retrieval tuning ──
    similarity_threshold: float = 0.7  # minimum score to include in search results
    top_k: int = 10                    # max results per lane in search
    num_candidates: int = 100          # MongoDB examines this many before ranking top_k
    existing_fetch_limit: int = 5      # existing memories fetched per fact for CRUD comparison

    # ── Input control ──
    context_window: int = 10  # max messages sent to LLM after role filtering

    # ── Processor ──
    # Which class handles extraction. Default set to LLMExtractProcessor
    # after import (avoids circular import — processors import LaneConfig).
    processor_cls: Optional[Type] = None

    # ── V2 slots (reserved, not used in V1) ──
    output_schema: Optional[Any] = None   # structured extraction model
    max_steps: int = 1                    # multi-step reflection iterations

    model_config = {"arbitrary_types_allowed": True}


# ── 4 Default Lane Instances ──
# These match the values in PFMEM_V1_ARCHITECTURE.md
# Import here (after LaneConfig is defined) to avoid circular import.

from pfmem.processors.llm_extract import LLMExtractProcessor

SEMANTIC = LaneConfig(
    name="semantic",
    include_roles=["user"],
    enable_inserts=True,
    enable_updates=True,
    enable_deletes=True,
    extraction_prompt=SEMANTIC_EXTRACTION_PROMPT,
    similarity_threshold=0.85,
    top_k=10,
    num_candidates=100,
    processor_cls=LLMExtractProcessor,
)

EPISODIC = LaneConfig(
    name="episodic",
    include_roles=["user", "assistant"],
    enable_inserts=True,
    enable_updates=False,   # additive — events are immutable
    enable_deletes=False,   # skips LLM call 2
    extraction_prompt=EPISODIC_EXTRACTION_PROMPT,
    similarity_threshold=0.8,
    top_k=10,
    num_candidates=150,
    processor_cls=LLMExtractProcessor,
)

PROCEDURAL = LaneConfig(
    name="procedural",
    include_roles=["user", "assistant", "tool"],
    enable_inserts=True,
    enable_updates=True,    # instructions can evolve
    enable_deletes=False,   # don't silently delete procedures
    extraction_prompt=PROCEDURAL_EXTRACTION_PROMPT,
    similarity_threshold=0.8,
    top_k=5,
    num_candidates=100,
    processor_cls=LLMExtractProcessor,
)

OBSERVATIONAL = LaneConfig(
    name="observational",
    include_roles=["tool"],
    enable_inserts=True,
    enable_updates=False,   # additive
    enable_deletes=False,   # skips LLM call 2
    extraction_prompt=OBSERVATIONAL_EXTRACTION_PROMPT,
    similarity_threshold=0.8,
    top_k=10,
    num_candidates=150,
    processor_cls=LLMExtractProcessor,
)
