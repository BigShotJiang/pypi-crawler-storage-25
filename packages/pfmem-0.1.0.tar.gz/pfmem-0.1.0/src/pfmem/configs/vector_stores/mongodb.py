from typing import Any, Dict, Optional
import warnings
from pydantic import BaseModel, Field, model_validator


class MongoDBConfig(BaseModel):
    db_name: str = Field("pfmem_db", description="Name of the MongoDB database")
    collection_name: str = Field("pfmem", description="Name of the MongoDB collection")
    embedding_model_dims: Optional[int] = Field(
        1536, description="Dimensions of the embedding vectors"
    )
    mongo_uri: str = Field("mongodb://localhost:27017", description="MongoDB URI")

    @model_validator(mode="before")
    @classmethod
    def validate_extra_fields(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        allowed = set(cls.model_fields.keys())
        extra = set(values.keys()) - allowed
        if extra:
            raise ValueError(f"Extra fields not allowed: {', '.join(extra)}")

        defaults = {"db_name": "pfmem_db", "collection_name": "pfmem", "mongo_uri": "mongodb://localhost:27017"}
        for field, default in defaults.items():
            if field not in values:
                warnings.warn(
                    f"MongoDBConfig: '{field}' not set, using default '{default}'. "
                    "Set explicitly for production.",
                    UserWarning,
                    stacklevel=2,
                )
        return values


CONFIG_CLASS = MongoDBConfig
