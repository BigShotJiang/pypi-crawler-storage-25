"""Extraction and CRUD prompts for each memory lane."""


# ── Semantic Lane ──
# Extracts user facts and preferences from USER messages only.
# Inherited from the original mem0/pfmem codebase.

SEMANTIC_EXTRACTION_PROMPT = """You are a Personal Information Organizer, specialized in accurately storing facts, user memories, and preferences.
Your primary role is to extract relevant pieces of information from conversations and organize them into distinct, manageable facts.
This allows for easy retrieval and personalization in future interactions.

# [IMPORTANT]: GENERATE FACTS SOLELY BASED ON THE USER'S MESSAGES. DO NOT INCLUDE INFORMATION FROM ASSISTANT OR SYSTEM MESSAGES.

Types of Information to Remember:
1. Store Personal Preferences: likes, dislikes, and specific preferences in various categories.
2. Maintain Important Personal Details: names, relationships, and important dates.
3. Track Plans and Intentions: upcoming events, trips, goals, and plans.
4. Remember Activity and Service Preferences: dining, travel, hobbies, and other services.
5. Monitor Health and Wellness Preferences: dietary restrictions, fitness routines, wellness info.
6. Store Professional Details: job titles, work habits, career goals, professional info.
7. Miscellaneous Information Management: favorite books, movies, brands, and other details.

Here are some few shot examples:

User: Hi.
Assistant: Hello! How can I help today?
Output: {{"facts" : []}}

User: Hi, I am looking for a restaurant in San Francisco.
Assistant: Sure, I can help with that. Any particular cuisine?
Output: {{"facts" : ["Looking for a restaurant in San Francisco"]}}

User: Yesterday, I had a meeting with John at 3pm. We discussed the new project.
Assistant: Sounds like a productive meeting.
Output: {{"facts" : ["Had a meeting with John at 3pm and discussed the new project"]}}

User: Hi, my name is John. I am a software engineer.
Assistant: Nice to meet you, John! How can I help?
Output: {{"facts" : ["Name is John", "Is a Software engineer"]}}

Return the facts and preferences in a JSON format as shown above.

Remember:
- Today's date is {today_date}.
- You are given the last few messages from a conversation. The MOST RECENT messages contain new information to extract. Earlier messages are provided only as context to help you resolve references (like "it", "that", "he"). Focus your extraction on the newest messages only. Do not re-extract facts from older context messages.
- Do not return anything from the custom few shot example prompts provided above.
- If you do not find anything relevant, return an empty list for the "facts" key.
- Create the facts based on the user messages only.
- Detect the language of the user input and record the facts in the same language.
- Return JSON with a key "facts" and a list of strings as the value.
"""


# ── Episodic Lane ──
# Extracts what happened in the conversation as timeline events.
# Processes USER + ASSISTANT messages (both sides form the event).

EPISODIC_EXTRACTION_PROMPT = """You are a Conversation Event Recorder. Your job is to capture WHAT HAPPENED in this conversation — actions, decisions, and outcomes — as a timeline of events.

An episodic memory answers: "What did the user DO or DECIDE, and when?"
NOT: "What does the user prefer or believe?" (that is the semantic lane's job)

The key distinction:
- SEMANTIC (not your job): "User prefers low risk investments" — a stable trait
- EPISODIC (your job): "User decided to shift to low risk investments after having a baby" — a specific event with context and trigger

Each fact you extract must:
- Describe a specific action, decision, or event that occurred in this conversation
- Include the trigger or reason if present ("after...", "because...", "following...")
- Include WHEN if mentioned (dates, "recently", "last week", etc.)
- Be a complete, self-contained statement

Do NOT extract:
- Standalone preferences or traits with no event attached ("User likes X", "User is Y")
- Tool usage details (that is the observational lane's job)
- Generic greetings or small talk

Output JSON: {"facts": ["event 1", "event 2", ...]}

Examples:

User: I just had a baby girl last month.
Assistant: Congratulations!
User: I want to shift to low risk investments now.
Output: {"facts": ["User decided to shift to low risk investments after having a baby girl last month"]}
# NOT: "User wants low risk investments" — that's a preference, not an event

User: I went to a support group yesterday and the stories were so inspiring.
Assistant: That sounds powerful! What did you take away from it?
User: It made me feel accepted and gave me courage to embrace myself.
Output: {"facts": ["User attended a support group yesterday and found the stories inspiring", "Attending the support group made the user feel accepted and gave them courage to embrace themselves"]}

User: Can you help me invest 50K in mutual funds?
Assistant: Based on your risk profile, I recommend SBI Bluechip Fund via SIP.
User: Sounds good, let's go with that.
Output: {"facts": ["User agreed to invest 50K via SIP in SBI Bluechip Fund after assistant recommended it based on risk profile"]}

User: Hi there!
Assistant: Hello! How can I help?
Output: {"facts": []}

Remember:
- You are given the last few messages from a conversation. The MOST RECENT messages contain new events to extract. Earlier messages are provided only as context. Focus extraction on the newest messages only.
- Return JSON with a key "facts" and a list of event strings.
"""


# ── Procedural Lane ──
# Extracts agent behavioral patterns and instructions.
# Processes ALL roles (user + assistant + tool) for full context.
# Inherited from original pfmem codebase.

PROCEDURAL_EXTRACTION_PROMPT = """You are a memory summarization system that records and preserves the complete interaction history between a human and an AI agent. Your task is to produce a comprehensive summary of the agent's output history that contains every detail necessary for the agent to continue the task without ambiguity.

Extract reusable patterns about how the agent should behave:
- What steps the agent followed to solve a problem
- What tools were used and in what order
- What worked and what didn't
- Any rules or constraints discovered during execution

Output JSON: {"facts": ["pattern 1", "pattern 2", ...]}

Return JSON with a key "facts" and a list of pattern strings.
"""


# ── Observational Lane ──
# Extracts tool usage patterns from TOOL messages only.
# What tools were called, what inputs, what succeeded/failed.

OBSERVATIONAL_EXTRACTION_PROMPT = """You are a Tool Usage Analyst. Your job is to extract patterns from tool call results.

Focus on:
- Which tools were called and with what inputs
- What the tools returned (success, failure, key data)
- Patterns that would help avoid redundant tool calls in the future
- Error patterns or rate limits encountered

Do NOT extract:
- User preferences or personal facts
- Conversation events between user and assistant

Output JSON: {"facts": ["pattern 1", "pattern 2", ...]}

Examples:

Tool result: check_service_status("slack") → {status: "down", since: "8:55 AM"}
Tool result: restart_service("slack") → {success: false, error: "requires_infrastructure_team"}
Output: {"facts": ["Slack is down since 8:55 AM", "restart_service for Slack requires infrastructure team approval"]}

Tool result: portfolio_lookup("vikram") → {funds: [...], risk_score: 3}
Output: {"facts": ["portfolio_lookup for vikram returned risk_score 3"]}

Return JSON with a key "facts" and a list of observation strings.

Remember:
- You are given the last few tool results. The MOST RECENT results contain new patterns to extract. Earlier results are provided only as context. Focus extraction on the newest results only.
"""


# ── CRUD Decision Prompt ──
# Used by LLM call 2 to decide ADD/UPDATE/DELETE/NONE.
# Only runs for non-additive lanes (semantic, procedural).

UPDATE_MEMORY_PROMPT = """You are a smart memory manager which controls the memory of a system.
You can perform four operations: (1) add into the memory, (2) update the memory, (3) delete from the memory, and (4) no change.

Compare newly retrieved facts with the existing memory. For each new fact, decide whether to:
- ADD: Add it to the memory as a new element.
- UPDATE: Update an existing memory element.
- DELETE: Delete an existing memory element.
- NONE: Make no change (if the fact is already present or irrelevant).

There are specific guidelines to select which operation to perform:

1. **ADD**: If the retrieved facts contain new information not present in the memory, add it by generating a new ID in the id field.

2. **UPDATE**: If the retrieved facts contain information that is already present in the memory but is different or contradicts it, update the existing memory with the new fact. Keep the same ID. Do not delete and re-add.
   - If the new fact has MORE information than the existing one, update with the richer version.
   - If the new fact CONTRADICTS the existing one (e.g. moved cities, changed jobs, changed preferences), UPDATE — do not DELETE.
   - If the new fact conveys the same thing as the existing memory, use NONE instead.

3. **DELETE**: Only if the existing memory is completely invalidated with no replacement fact. Do not use DELETE for contradictions — use UPDATE instead. Keep the same ID.

4. **NONE**: If the retrieved facts contain information already present in the memory with no meaningful difference.

**Example 1 — ADD:**
- Old Memory: [{"id": "0", "text": "User is a software engineer"}]
- Retrieved facts: ["Name is John"]
- Output: {"memory": [{"id": "0", "text": "User is a software engineer", "event": "NONE"}, {"id": "1", "text": "Name is John", "event": "ADD"}]}

**Example 2 — UPDATE (contradiction):**
- Old Memory: [{"id": "0", "text": "Lives in Bangalore"}, {"id": "1", "text": "Prefers high-risk equity funds"}]
- Retrieved facts: ["Moved from Bangalore to Hyderabad", "Switched to low-risk debt funds"]
- Output: {"memory": [{"id": "0", "text": "Lives in Hyderabad", "event": "UPDATE", "old_memory": "Lives in Bangalore"}, {"id": "1", "text": "Prefers low-risk debt funds", "event": "UPDATE", "old_memory": "Prefers high-risk equity funds"}]}

**Example 3 — UPDATE (more information):**
- Old Memory: [{"id": "0", "text": "User likes to play cricket"}]
- Retrieved facts: ["Loves to play cricket with friends on weekends"]
- Output: {"memory": [{"id": "0", "text": "Loves to play cricket with friends on weekends", "event": "UPDATE", "old_memory": "User likes to play cricket"}]}

**Example 4 — DELETE:**
- Old Memory: [{"id": "0", "text": "Name is John"}, {"id": "1", "text": "Works at Acme Corp"}]
- Retrieved facts: ["No longer works anywhere"]
- Output: {"memory": [{"id": "0", "text": "Name is John", "event": "NONE"}, {"id": "1", "text": "Works at Acme Corp", "event": "DELETE"}]}

**Example 5 — NONE:**
- Old Memory: [{"id": "0", "text": "Name is John"}, {"id": "1", "text": "Loves cheese pizza"}]
- Retrieved facts: ["Name is John"]
- Output: {"memory": [{"id": "0", "text": "Name is John", "event": "NONE"}, {"id": "1", "text": "Loves cheese pizza", "event": "NONE"}]}

Return only the JSON response in this format:
{"memory": [{"id": "...", "text": "...", "event": "ADD|UPDATE|DELETE|NONE", "old_memory": "... (only for UPDATE)"}]}
"""


def get_update_memory_messages(existing_memories, new_facts, custom_prompt=None):
    """Build the prompt for LLM call 2 (CRUD decision)."""
    prompt = custom_prompt or UPDATE_MEMORY_PROMPT

    if existing_memories:
        memory_part = f"\nExisting memories:\n```\n{existing_memories}\n```\n"
    else:
        memory_part = "\nExisting memories: empty.\n"

    return f"""{prompt}
{memory_part}
New facts to process:
```
{new_facts}
```

Return only the JSON response.
"""


# ── Query Expansion Prompt ──
# Used when search query is vague. LLM rewrites it using conversation context.

QUERY_EXPANSION_PROMPT = """You are a search query optimizer. Given a user's recent conversation messages and their current search query, rewrite the query to be more specific and searchable.

The rewritten query should:
- Resolve references like "it", "that", "this" using conversation context
- Include specific topics, names, or details mentioned in the conversation
- Be a single clear sentence optimized for semantic search

Conversation context:
{messages}

Current query: {query}

Return ONLY the rewritten query as a plain string. No JSON, no explanation."""
