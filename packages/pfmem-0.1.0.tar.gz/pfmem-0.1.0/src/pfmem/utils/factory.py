import importlib
from typing import Dict, Optional, Union

from pfmem.configs.llms.base import BaseLlmConfig
from pfmem.configs.llms.azure_openai import AzureOpenAIConfig
from pfmem.configs.embeddings.base import BaseEmbedderConfig


def load_class(class_type):
    module_path, class_name = class_type.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


class LlmFactory:
    provider_to_class = {
        "langchain": ("pfmem.llms.langchain.LangchainLLM", BaseLlmConfig),
        "azure_openai": ("pfmem.llms.azure_openai.AzureOpenAILLM", AzureOpenAIConfig),
    }

    @classmethod
    def create(cls, provider_name, config=None, **kwargs):
        if provider_name not in cls.provider_to_class:
            raise ValueError(f"Unsupported LLM provider: {provider_name}. Available: {list(cls.provider_to_class.keys())}")
        class_type, config_class = cls.provider_to_class[provider_name]
        llm_class = load_class(class_type)
        if config is None:
            config = config_class(**kwargs)
        elif isinstance(config, dict):
            config.update(kwargs)
            config = config_class(**config)
        return llm_class(config)

    @classmethod
    def register_provider(cls, name, class_path, config_class=None):
        cls.provider_to_class[name] = (class_path, config_class or BaseLlmConfig)


class EmbedderFactory:
    provider_to_class = {
        "azure_openai": "pfmem.embeddings.azure_openai.AzureOpenAIEmbedding",
    }

    @classmethod
    def create(cls, provider_name, config, vector_config=None):
        class_type = cls.provider_to_class.get(provider_name)
        if not class_type:
            raise ValueError(f"Unsupported embedder provider: {provider_name}. Available: {list(cls.provider_to_class.keys())}")
        embedder_class = load_class(class_type)
        if isinstance(config, dict):
            config = BaseEmbedderConfig(**config)
        return embedder_class(config)

    @classmethod
    def register_provider(cls, name, class_path):
        cls.provider_to_class[name] = class_path


class VectorStoreFactory:
    provider_to_class = {
        "mongodb": "pfmem.vector_stores.mongodb.MongoDB",
    }

    @classmethod
    def create(cls, provider_name, config):
        class_type = cls.provider_to_class.get(provider_name)
        if not class_type:
            raise ValueError(f"Unsupported vector store provider: {provider_name}. Available: {list(cls.provider_to_class.keys())}")
        if not isinstance(config, dict):
            config = config.model_dump()
        return load_class(class_type)(**config)

    @classmethod
    def reset(cls, instance):
        instance.reset()
        return instance

    @classmethod
    def register_provider(cls, name, class_path):
        cls.provider_to_class[name] = class_path
