"""SLURM batch execution backend."""
from __future__ import annotations

import os
import re
import shlex
import subprocess
from typing import Any, Dict, List, Optional, Tuple

from .base import (
    Backend,
    BackendConfig,
    SlurmConfig,
    _build_worktree_setup_commands,
    _rewrite_mounts_for_worktrees,
)


class SlurmBackend(Backend):
    """Backend for SLURM cluster execution."""

    # ------------------------------------------------------------------
    # prepare.sh handling (same as SSH -- relative to remote_dir)
    # ------------------------------------------------------------------

    def get_prepare_commands(self) -> List[str]:
        """Return source command for prepare.sh, relative to remote_dir."""
        return self._get_remote_prepare_commands()

    # ------------------------------------------------------------------
    # Script generation
    # ------------------------------------------------------------------

    def generate_script(
        self,
        task: Dict[str, Any],
        script: str,
        python_command: str = "python",
        env: Optional[Dict[str, str]] = None,
        slurm_overrides: Optional[Dict[str, Any]] = None,
        hydra_enabled: bool = False,
        hydra_flags: Optional[Dict[str, Any]] = None,
        serial_steps: Optional[List[Tuple[str, list]]] = None,
        submodule_worktrees: Optional[Dict[str, str]] = None,
        submodule_resolved_commits: Optional[Dict[str, str]] = None,
    ) -> str:
        """Generate a SLURM batch script.

        Structure:
        1. SBATCH header from ``SlurmConfig.to_sbatch_header()``
        2. ``#SBATCH -o / -e / --job-name`` directives
        3. ``set -x``, ``set -u``, ``set -e``
        4. ``cd {remote_dir}``
        5. ``cd {remote_dir}``
        6. ``module load`` for each module and cuda_module
        7. Inner commands (prepare.sh + python), optionally
           wrapped with singularity

        For ``serial_steps``, multiple python commands are generated in the
        same script (one per step), each wrapped independently with
        singularity if configured.

        Args:
            task: Task dict with ``params`` sub-dict.  ``params`` must contain
                  ``log_dir`` for SBATCH output directives.
            script: Python script to run.
            python_command: Base python command (default ``python``; for SLURM
                  this is often ``srun python``).
            env: Optional env vars.
            slurm_overrides: Optional dict to override SLURM params per-experiment.
            hydra_enabled: Use Hydra override format for args.
            hydra_flags: Hydra flags (e.g. ``{'multirun': True}``).
            serial_steps: List of (key, [val1, val2, ...]) for order='serial'.
                  Generates one command per step value in the same script.
            submodule_worktrees: Optional mapping of submodule path to absolute
                remote worktree path. When set, mounts for these submodules are
                redirected to the worktree. Requires ``submodule_resolved_commits``.
            submodule_resolved_commits: Optional mapping of submodule path to full
                40-char SHA. Required when ``submodule_worktrees`` is set.

        Returns:
            Full SLURM batch script as a string.
        """
        params = task.get("params", {})
        log_dir = params.get("log_dir", "")
        exp_name = params.get("exp_name", task.get("exp_name", "chester_job"))
        remote_dir = self.config.remote_dir or "./"

        # ---- SBATCH header ----
        slurm_cfg = self.config.slurm or SlurmConfig()
        if slurm_overrides:
            slurm_cfg = slurm_cfg.with_overrides(slurm_overrides)

        header = slurm_cfg.to_sbatch_header()

        lines: List[str] = []
        lines.append(header)

        # Per-job SBATCH directives
        lines.append(f"#SBATCH -o {log_dir}/slurm.out")
        lines.append(f"#SBATCH -e {log_dir}/slurm.err")
        lines.append(f"#SBATCH --job-name={exp_name}")

        # ---- Bash preamble ----
        # Redirect xtrace to a separate file so slurm.err stays clean
        lines.append(f"exec 19>{log_dir}/chester_xtrace.log")
        lines.append("BASH_XTRACEFD=19")
        lines.append("set -x")
        lines.append("set -u")
        lines.append("set -e")
        lines.append(f"cd {remote_dir}")

        # ---- Module loads ----
        # Suppress LMOD's "Shell debugging temporarily silenced" stderr noise
        # by disabling xtrace around module calls.
        has_modules = self.config.modules or self.config.cuda_module
        if has_modules:
            lines.append("{ set +x; } 2>/dev/null")
        for mod in self.config.modules:
            lines.append(f"module load {mod}")
        if self.config.cuda_module:
            lines.append(f"module load {self.config.cuda_module}")
        if has_modules:
            lines.append("set -x")

        # ---- Prepare + inner commands ----
        # Backend prepare.sh always runs on the host (module loads, etc.).
        prepare_cmds = self.get_prepare_commands()
        lines.extend(prepare_cmds)

        # ---- Submodule worktree setup (before overlay and singularity) ----
        if submodule_worktrees:
            lines.extend(_build_worktree_setup_commands(
                submodule_worktrees, submodule_resolved_commits, remote_dir
            ))
            rewritten_mounts = _rewrite_mounts_for_worktrees(
                self.config.singularity.mounts if self.config.singularity else [],
                submodule_worktrees,
                remote_dir,
            )
        else:
            rewritten_mounts = None

        # Create overlay image if needed (before singularity exec).
        lines.extend(self.get_overlay_setup_commands())

        if serial_steps:
            # Generate one command per serial step
            from ..run_exp import _iter_serial_overrides
            for step_overrides in _iter_serial_overrides(serial_steps):
                command = self.build_python_command(
                    params, script, python_command, env,
                    hydra_enabled, hydra_flags,
                    extra_overrides=step_overrides,
                )
                if self.config.singularity:
                    inner: List[str] = list(self.get_singularity_prepare_commands())
                    inner.append(command)
                    lines.append(self.wrap_with_singularity(inner, mounts_override=rewritten_mounts))
                else:
                    lines.append(command)
        else:
            command = self.build_python_command(
                params, script, python_command, env,
                hydra_enabled, hydra_flags,
            )
            if self.config.singularity:
                inner: List[str] = list(self.get_singularity_prepare_commands())
                inner.append(command)
                lines.append(self.wrap_with_singularity(inner, mounts_override=rewritten_mounts))
            else:
                lines.append(command)

        return "\n".join(lines) + "\n"

    # ------------------------------------------------------------------
    # Submission
    # ------------------------------------------------------------------

    def submit(
        self,
        task: Dict[str, Any],
        script_content: str,
        dry: bool = False,
        dependency_job_ids: Optional[List[int]] = None,
    ) -> Optional[int]:
        """Submit a SLURM batch job.

        Steps:
        1. Write script locally to ``{local_log_dir}/chester_slurm.sh``
        2. Create remote log directory via SSH
        3. SCP the batch script to remote
        4. SSH into the host and run ``sbatch``

        Args:
            task: Task dict.  ``params`` must contain ``log_dir`` (the
                  *remote* log dir where the script will be placed).
            script_content: The full SLURM batch script content.
            dry: If True, print the script but do not submit.
        """
        if dry:
            print(script_content)
            return None

        params = task.get("params", {})
        log_dir = params.get("log_dir", "")
        exp_name = params.get("exp_name", task.get("exp_name", "chester_job"))
        host = self.config.host

        # Determine local log dir for writing the script before SCP
        local_log_dir = task.get("_local_log_dir", log_dir)

        # 1. Write script locally
        os.makedirs(local_log_dir, exist_ok=True)
        local_script = os.path.join(local_log_dir, "chester_slurm.sh")
        with open(local_script, "w") as f:
            f.write(script_content)

        # 2. Create remote log dir
        subprocess.run(
            ["ssh", host, f"mkdir -p {shlex.quote(log_dir)}"],
            check=True,
        )

        # 3. SCP script to remote
        remote_script = os.path.join(log_dir, "chester_slurm.sh")
        subprocess.run(
            ["scp", local_script, f"{host}:{remote_script}"],
            check=True,
        )

        # 4. Submit via sbatch
        sbatch_cmd = f"sbatch"
        if dependency_job_ids:
            dep_str = ":".join(str(jid) for jid in dependency_job_ids)
            sbatch_cmd += f" --dependency=afterok:{dep_str}"
            print(f"[chester] Job depends on SLURM jobs: {dependency_job_ids}")
        sbatch_cmd += f" {shlex.quote(remote_script)}"

        print(f"[chester] Submitting SLURM job on {host}: {exp_name}")
        print(f"[chester] Remote script: {remote_script}")
        result = subprocess.run(
            ["ssh", host, sbatch_cmd],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"[chester] sbatch failed: {result.stderr.strip()}")
            raise RuntimeError(
                f"sbatch failed on {host}: {result.stderr.strip()}"
            )
        print(f"[chester] {result.stdout.strip()}")

        match = re.search(r"Submitted batch job (\d+)", result.stdout)
        if match:
            job_id = int(match.group(1))
            print(f"[chester] SLURM job ID: {job_id}")
            job_id_file = os.path.join(log_dir, ".chester_slurm_job_id")
            subprocess.run(
                ["ssh", host, f"echo {job_id} > {shlex.quote(job_id_file)}"],
                check=False,
            )
            return job_id
        else:
            print(f"[chester] Warning: could not parse SLURM job ID from: {result.stdout.strip()}")
            return None
