"""
Utilities for integrating Chester with Hydra.

Note: hydra-core is an optional dependency. Functions that require hydra
will raise ImportError if hydra is not installed.
"""

import base64
import os
import os.path as osp
import pickle
import shlex
from pathlib import Path
from typing import Any, Callable, Dict, List, Union

# Lazy imports for optional hydra dependency
_hydra = None
_HydraConfig = None
_read_write = None
_open_dict = None


def _require_hydra():
    """Import hydra and related modules. Raises ImportError if not available."""
    global _hydra, _HydraConfig, _read_write, _open_dict
    if _hydra is None:
        try:
            import hydra
            from hydra.core.hydra_config import HydraConfig
            from omegaconf import read_write, open_dict
            _hydra = hydra
            _HydraConfig = HydraConfig
            _read_write = read_write
            _open_dict = open_dict
        except ImportError:
            raise ImportError(
                "hydra-core is required for this function. "
                "Install it with: pip install hydra-core"
            )
    return _hydra, _HydraConfig, _read_write, _open_dict

def _format_hydra_value(value: Any) -> str:
    """Format a value for Hydra command line override."""
    if isinstance(value, bool):
        return str(value).lower()
    elif isinstance(value, (int, float)):
        return str(value)
    elif isinstance(value, str):
        # Keep Hydra/OmegaConf interpolations unquoted (e.g., ${eval:'...'}).
        if value.startswith("${") and value.endswith("}"):
            return value
        # If it contains spaces, quote it
        if ' ' in value:
            return f'"{value}"'
        return value
    elif isinstance(value, (list, tuple)):
        # Format list/tuple values with Hydra's format [val1,val2,...]
        formatted_items = []
        for item in value:
            if isinstance(item, str) and ',' in item:
                # Escape commas in string values
                formatted_items.append(f'"{item}"')
            else:
                formatted_items.append(_format_hydra_value(item))
        return f"[{','.join(formatted_items)}]"
    return str(value)


def variant_to_hydra_overrides(variant: Dict[str, Any]) -> List[str]:
    """
    Convert a chester variant dictionary to Hydra command line overrides.
    
    Args:
        variant: Dictionary of parameters from chester's VariantGenerator
        
    Returns:
        List of strings, each being a Hydra command line override (e.g., ['key1=val1', 'key2=val2', ...])
    """
    overrides = []
    
    for key, value in variant.items():
        # Skip special chester keys
        if key in ['chester_first_variant', 'chester_last_variant', 'is_debug']:
            continue
        
        # Handle nested dictionaries
        if isinstance(value, dict):
            for nested_key, nested_value in value.items():
                if str(nested_key) == "_name":
                    # Special case for _name which becomes just the parent key in Hydra
                    overrides.append(f"{key}={_format_hydra_value(nested_value)}")
                else:
                    overrides.append(f"{key}.{nested_key}={_format_hydra_value(nested_value)}")
        else:
            overrides.append(f"{key}={_format_hydra_value(value)}")
    
    return overrides


def build_hydra_args(
    params: Dict[str, Any],
    hydra_flags: Dict[str, Any] = None,
    extra_overrides: Dict[str, Any] = None,
) -> str:
    """Build Hydra override args from a params dict.

    Deserializes ``variant_data`` from *params*, sets ``hydra.run.dir``
    to the task's ``log_dir``, and formats the variant as ``key=value``
    Hydra overrides.  Also appends hydra flags (``--multirun``, etc.).

    This is the Hydra counterpart to :func:`chester.utils.build_cli_args`.

    Args:
        params: Task parameter dict containing ``variant_data`` (base64-
                encoded pickled variant) and ``log_dir``.
        hydra_flags: Optional Hydra flags (e.g. ``{'multirun': True}``).
        extra_overrides: Optional dict of key/value pairs to merge on top of
                         the decoded variant before formatting.  Existing keys
                         are replaced; new keys are added.

    Returns:
        Args string, e.g. ``"lr=0.01 batch_size=32 --multirun"``.
    """
    variant_data = pickle.loads(base64.b64decode(params["variant_data"]))
    variant_data["hydra.run.dir"] = params["log_dir"]
    if extra_overrides:
        variant_data.update(extra_overrides)

    parts: List[str] = []

    # Hydra flags (--multirun, etc.)
    if hydra_flags:
        for flag, value in hydra_flags.items():
            if value is True:
                parts.append(f"--{flag}")
            elif value not in [False, None]:
                parts.append(f"--{flag}={value}")

    # Hydra overrides (key=value)
    overrides = variant_to_hydra_overrides(variant_data)
    parts.extend(overrides)

    return " ".join(parts)


def to_hydra_command(
    params: Dict[str, Any],
    python_command: str = "python",
    script: str = "main_df.py",
    hydra_flags: Dict[str, Any] = None,
    env: Dict[str, Any] = {},
) -> str:
    """Convert parameters to a Hydra command.

    This is a convenience wrapper that builds the full command string
    including the python prefix.  Internally delegates to
    :func:`build_hydra_args`.

    Args:
        params: Dictionary of parameters (will be read, not mutated).
        python_command: Python command to use.
        script: Script to run.
        hydra_flags: Additional Hydra flags (e.g., {'multirun': True}).
        env: Environment variables to prepend.

    Returns:
        Command string to execute.
    """
    command = python_command + " " + script
    for k, v in env.items():
        command = ("%s=%s " % (k, v)) + command

    args = build_hydra_args(params, hydra_flags)
    if args:
        command += " " + args

    return command

def run_hydra_command(command: str, log_dir: str, stub_method_call: Callable):
    from .config import load_config
    hydra, HydraConfig, read_write, open_dict = _require_hydra()

    cmd_parts = shlex.split(command)
    # Find the index where the python module starts (after python command and potential -m flag)
    module_start_idx = 0
    for i, part in enumerate(cmd_parts):
        if part.endswith('.py') or (part == '-m' and i+1 < len(cmd_parts)):
            module_start_idx = i + 2 if part == '-m' else i + 1
            break

    # Everything after the python module are hydra overrides
    overrides = cmd_parts[module_start_idx:]
    # Use hydra_config_path from config (resolved to absolute path by load_config)
    cfg = load_config()
    config_dir = cfg["hydra_config_path"]
    with hydra.initialize_config_dir(config_dir=config_dir, version_base=None):
        cfg = hydra.compose(config_name="config",
                            overrides=overrides,
                            return_hydra_config=True)
        # output_dir = cfg.hydra.run.dir
        output_dir = log_dir
        with read_write(cfg.hydra.runtime):
            with open_dict(cfg.hydra.runtime):
                cfg.hydra.runtime.output_dir = os.path.abspath(output_dir)
        Path(str(output_dir)).mkdir(parents=True, exist_ok=True)
        HydraConfig.instance().set_config(cfg)
        stub_method_call(cfg)