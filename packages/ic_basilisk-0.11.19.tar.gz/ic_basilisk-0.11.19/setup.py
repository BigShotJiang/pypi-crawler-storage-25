from basilisk import __version__
from pathlib import Path
from setuptools import setup  # type: ignore

setup(
    name="ic-basilisk",
    version=__version__,
    author="Smart Social Contracts",
    author_email="contact@smartsocialcontracts.org",
    description="An ICP Python Canister Development Kit for the Internet Computer",
    url="https://github.com/smart-social-contracts/basilisk",
    project_urls={
        "Documentation": "https://github.com/smart-social-contracts/basilisk#readme",
        "Source": "https://github.com/smart-social-contracts/basilisk",
        "Issues": "https://github.com/smart-social-contracts/basilisk/issues",
        "Live Demo": "https://ic-basilisk.tech/",
    },
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Software Development :: Compilers",
        "Topic :: Internet",
    ],
    package_data={"basilisk": [
        "compiler/**/*.py",
        "compiler/**/*.rs",
        "compiler/**/*.toml",
        "compiler/**/*.c",
        "compiler/**/*.h",
        "compiler/**/*.sh",
        "compiler/**/*.json",
        "compiler/**/*.wasm",
        "compiler/**/*.a",
        "compiler/**/*.pdf",
        "compiler/**/LICENSE*",
        "canisters/**",
        "py.typed",
        "*.wasm",
        "*.js",
    ]},
    include_package_data=True,
    packages=["basilisk"],
    install_requires=[],
    extras_require={
        "test": ["pytest"],
    },
    entry_points={
        "console_scripts": [
            "basilisk=basilisk.cli:main",
        ],
    },
    long_description=Path("README.md").read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
)
