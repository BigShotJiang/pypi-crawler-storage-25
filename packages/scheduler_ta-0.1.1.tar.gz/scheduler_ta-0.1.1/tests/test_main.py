# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 15:50:00 2026

@author: shane

Integration tests for the main CLI entry point.
"""

import sys

from scheduler_ta.main import main


def test_main_quiz_help(capsys):
    """Test calling main quiz mode with no args shows help."""
    # Mock sys.argv
    sys.argv = ["main.py", "quiz", "--help"]
    try:
        main()
    except SystemExit:
        pass

    captured = capsys.readouterr()
    assert "quiz [-h]" in captured.out


def test_main_quiz_basic(capsys):
    """Test a basic valid quiz command."""
    sys.argv = [
        "main.py",
        "quiz",
        "-c",
        "04/01",
        "--prof-sched",
        "MWF 10am-11am",
        "--grader-sched",
        "TTh 1pm-2pm",
    ]
    main()
    captured = capsys.readouterr()
    assert "OPTIMIZED QUIZ SCHEDULES" in captured.out
    assert "Collect [01 Wed Apr]" in captured.out


def test_main_heatmap(capsys):
    """Test the heatmap command."""
    sys.argv = [
        "main.py",
        "heatmap",
        "--days",
        "3",
        "--prof-sched",
        "MWF 10am-11am",
        "--grader-sched",
        "TTh 1pm-2pm",
    ]
    main()
    captured = capsys.readouterr()
    assert "CONVENIENCE HEATMAP" in captured.out


def test_main_pair(capsys):
    """Test the pairing command."""
    sys.argv = [
        "main.py",
        "pair",
        "--prof",
        "MWF 10am-11am",
        "--grader",
        "TTh 1pm-2pm",
        "--global-opt",
    ]
    main()
    captured = capsys.readouterr()
    assert "GLOBAL DEPARTMENT-WIDE BEST MATCHES" in captured.out


def test_main_pair_individual(capsys):
    """Test the pairing command without global opt."""
    sys.argv = [
        "main.py",
        "pair",
        "--prof",
        "MWF 10am-11am",
        "--grader",
        "TTh 1pm-2pm",
    ]
    main()
    captured = capsys.readouterr()
    assert "INDIVIDUAL PAIRING COMPATIBILITY" in captured.out


def test_main_invalid_load(capsys):
    """Test calling main with an invalid load format."""
    sys.argv = [
        "main.py",
        "quiz",
        "-c",
        "04/01",
        "--load",
        "invalid_load",
    ]
    main()
    captured = capsys.readouterr()
    assert "Warning: Invalid load format" in captured.out


def test_main_invalid_collect_date(capsys):
    """Test calling main with an invalid collection date format."""
    sys.argv = [
        "main.py",
        "quiz",
        "-c",
        "invalid",
    ]
    try:
        main()
    except SystemExit:
        pass
    captured = capsys.readouterr()
    assert "Error: Invalid date format" in captured.out


def test_main_quiz_no_options(capsys):
    """Test quiz mode when no valid schedules are found."""
    sys.argv = [
        "main.py",
        "quiz",
        "-c",
        "04/01",
        "--prof-sched",
        "T 10am-11am",  # 4/01 is Wed, Prof not on campus
    ]
    main()
    captured = capsys.readouterr()
    assert "No valid schedules found" in captured.out


def test_main_no_args(capsys):
    """Test calling main with no arguments shows help."""
    sys.argv = ["main.py"]
    main()
    captured = capsys.readouterr()
    assert "Academic Grading & Pairing Optimizer" in captured.out


def test_main_timeline(capsys):
    """Test the timeline command."""
    sys.argv = [
        "main.py",
        "timeline",
        "--days",
        "7",
        "--prof-sched",
        "MWF 10am-11am",
        "--grader-sched",
        "TTh 1pm-2pm",
    ]
    main()
    captured = capsys.readouterr()
    assert "EXPECTED TURNAROUND GUIDANCE" in captured.out
    assert "Turnaround" in captured.out


def test_main_pair_with_date(capsys):
    """Test the pairing command with a specific date."""
    sys.argv = [
        "main.py",
        "pair",
        "--prof",
        "MWF 10am-11am",
        "--grader",
        "TTh 1pm-2pm",
        "--date",
        "04/05",
    ]
    main()
    captured = capsys.readouterr()
    assert "INDIVIDUAL PAIRING COMPATIBILITY" in captured.out
    assert "Prof_1" in captured.out


def test_main_cadence(capsys):
    """Test the cadence command."""
    sys.argv = [
        "main.py",
        "cadence",
        "--weeks",
        "2",
        "--prof-sched",
        "MWF 10am-11am",
        "--grader-sched",
        "TTh 1pm-2pm",
    ]
    main()
    captured = capsys.readouterr()
    assert "SYLLABUS CADENCE ADVISOR" in captured.out
    assert "Recommendation" in captured.out


def test_main_cadence_no_days(capsys):
    """Test the cadence command when there are no valid teaching days."""
    sys.argv = [
        "main.py",
        "cadence",
        "-s",
        "04/06",
        "--weeks",
        "0",  # 0 weeks means no days
        "--prof-sched",
        "MWF 10am-11am",
        "--grader-sched",
        "TTh 1pm-2pm",
    ]
    main()
    captured = capsys.readouterr()
    assert "No teaching days found." in captured.out


def test_main_install_comp_bash(capsys, monkeypatch, tmp_path):
    """Test standard completion hook installation."""
    rc_file = tmp_path / ".bashrc"
    monkeypatch.setattr("os.path.expanduser", lambda path: str(rc_file))

    sys.argv = ["main.py", "install-completion", "--shell", "bash"]
    main()

    output = capsys.readouterr().out
    assert "Successfully installed autocompletion hook" in output
    assert "eval" in rc_file.read_text(encoding="utf-8")


def test_main_install_comp_already_exists(capsys, monkeypatch, tmp_path):
    """Test hook isn't duplicated."""
    rc_file = tmp_path / ".zshrc"
    rc_file.write_text(
        'eval "$(register-python-argcomplete scheduler-ta)"\n', encoding="utf-8"
    )
    monkeypatch.setattr("os.path.expanduser", lambda path: str(rc_file))

    sys.argv = ["main.py", "install-completion", "--shell", "zsh"]
    main()
    output = capsys.readouterr().out
    assert "Completion hook already exists" in output


def test_main_install_comp_error(capsys, monkeypatch, tmp_path):
    """Test safe exception handling if file inaccessible."""
    rc_dir = tmp_path / ".bashrc"
    rc_dir.mkdir()  # Causes write error because it's a directory
    monkeypatch.setattr("os.path.expanduser", lambda path: str(rc_dir))

    sys.argv = ["main.py", "install-completion", "--shell", "bash"]
    main()
    output = capsys.readouterr().out
    assert "Failed to install completion hook" in output
