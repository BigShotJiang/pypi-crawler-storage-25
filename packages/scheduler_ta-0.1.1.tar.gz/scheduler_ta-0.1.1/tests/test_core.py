# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 13:10:00 2026

@author: shane

Unit tests for the core scheduling and matchmaking logic.
"""

from datetime import datetime, timedelta

import pytest

import scheduler_ta.core as core_mod
from scheduler_ta.core import (
    _calculate_penalty,
    calculate_convenience_heatmap,
    calculate_quiz_options,
    calculate_timeline,
    calculate_weekly_cadence,
    global_matchmaking,
    optimal_matchmaking,
    optimize_pairings,
)
from scheduler_ta.models import Person
from scheduler_ta.utils import parse_schedule


def test_quiz_options_prof1_student_a():
    """
    Test case from user:
    Teacher 1: MWF 10:40am (Calc)
    Student A: TTh 5:30pm-10:00pm

    If collected on Monday (04/06), the best pickup should be Tuesday (04/07).
    """
    prof = Person("Teacher 1", "Teacher", parse_schedule("MWF 10:40am-12:00pm"))
    grader = Person("Student A", "Student", parse_schedule("TTh 5:30pm-10:00pm"))

    # Monday 04/06/2026
    c_date = datetime(2026, 4, 6)

    options = calculate_quiz_options(prof, grader, [c_date], None)

    # Rank 1 should be Tuesday (04/07)
    assert len(options) > 0
    best = options[0]
    assert best.collection_date == c_date
    assert best.pickup_date == datetime(2026, 4, 7)
    assert best.special_trips == 0
    assert best.turnaround_days == 1
    assert best.total_penalty == 1


def test_convenience_heatmap():
    """Test that heatmap correctly ranks on-campus days higher."""
    prof = Person("Prof", "Teacher", parse_schedule("MWF 10:00am-11:00am"))
    grader = Person("Grader", "Student", parse_schedule("T 10:00am-11:00am"))

    # Start on Monday
    start = datetime(2026, 4, 6)
    heatmap = calculate_convenience_heatmap(prof, grader, start, days=7)

    # Monday (04/06) -> Best pickup is Tue (04/07) [Penalty 1]
    # Wednesday (04/08) -> Best pickup is Tue (04/14) [Penalty 6]
    # Friday (04/10) -> Best pickup is Tue (04/14) [Penalty 4]

    assert heatmap[0]["date"] == datetime(2026, 4, 6)
    assert heatmap[0]["score"] == 1


def test_global_matchmaking():
    """Test that pairings are unique and optimized."""
    p1 = Person("P1", "Teacher", parse_schedule("M 10am-11am"))
    p2 = Person("P2", "Teacher", parse_schedule("T 10am-11am"))

    g1 = Person(
        "G1", "Student", parse_schedule("Th 10am-11am")
    )  # Better for P1 (3 days)
    g2 = Person(
        "G2", "Student", parse_schedule("F 10am-11am")
    )  # Better for P2 (3 days)

    matches = global_matchmaking([p1, p2], [g1, g2])

    assert len(matches) == 2
    # Ensure they are correctly matched
    # P1 -> G1 (Window 3)
    # P2 -> G2 (Window 3)
    # If P1 took G2, window would be 4.


def test_calculate_quiz_options_with_load():
    """Test that external load affects the penalty score."""
    prof = Person("Prof", "Teacher", parse_schedule("MWF 10:00am-11:00am"))
    grader = Person("Grader", "Student", parse_schedule("T 10:00am-11:00am"))

    # Monday 04/06
    c_date = datetime(2026, 4, 6)

    # Normal pickup on Tue 04/07: penalty = 1 (turnaround) + 0 (on-campus) = 1
    options_no_load = calculate_quiz_options(prof, grader, [c_date], ["1"])
    assert options_no_load[0].total_penalty == 1

    # Add external load on Tue 04/07
    grader.external_load = {"04/07": 50}
    options_with_load = calculate_quiz_options(prof, grader, [c_date], ["1"])
    assert options_with_load[0].total_penalty == 51  # 1 + 50


def test_calculate_quiz_options_special_trip():
    """Test penalty for a special trip."""
    prof = Person("Prof", "Teacher", parse_schedule("M 10:00am-11:00am"))
    grader = Person("Grader", "Student", parse_schedule("F 10:00am-11:00am"))

    c_date = datetime(2026, 4, 6)  # Monday
    # Pickup on Monday (0 offset): penalty = 0 (turnaround) + 10 (special) = 10
    options = calculate_quiz_options(prof, grader, [c_date], ["0"])
    assert options[0].special_trips == 1
    assert options[0].total_penalty == 10


def test_optimize_pairings_complex():
    """Test optimize_pairings with multi-day alignment."""
    p1 = Person("P1", "Teacher", parse_schedule("MWF 10am-11am"))
    g1 = Person("G1", "Student", parse_schedule("TTh 10am-11am"))

    # P1(M) -> T (Window 1), Th (Window 3) [ON-CAMPUS] -> Perfect
    # P1(W) -> Th (Window 1), (Window 3=Sat) [OFF] -> Window 3 is Sat?
    # Window range is 3-5.
    # P1(M) -> T(1), W(2), Th(3), F(4), S(5).
    # Grader is TTh.
    # From M: Th(3) is ON-CAMPUS -> Perfect.
    # From W: Sat(3), Sun(4), Mon(5) -> NONE ON-CAMPUS -> 0.
    # From F: Mon(3), Tue(4), Wed(5) -> Tue(4) is ON-CAMPUS? No, Student is TTh.
    # Mon(3), Tue(4) is T. So Tue(4) -> Perfect.

    # So 2/3 days are perfect. Score = 66.7%
    pairings = optimize_pairings([p1], [g1])
    assert pairings[0]["score"] == 66.7


def test_calculate_quiz_options_edge_cases(capsys):
    """Test absolute dates, invalid inputs, and negative windows."""
    prof = Person("P1", "Teacher", parse_schedule("MWF 10:00am-11:00am"))
    grader = Person("G1", "Student", parse_schedule("TTh 10:00am-11:00am"))

    # 04/06 is Monday
    c_dates = [
        datetime(2026, 4, 6),
        datetime(2026, 4, 7),
    ]  # Mon (Teach), Tue (No Teach)

    # Inputs:
    # "1": Offset 1 (Tue)
    # "04/08": Absolute (Wed)
    # "04/05": Absolute Before (Sun) -> Should be skipped
    # "garbage": Invalid -> Should trigger warning
    p_inputs = ["1", "04/08", "04/05", "garbage"]

    options = calculate_quiz_options(prof, grader, c_dates, p_inputs)

    # Check warning output
    captured = capsys.readouterr()
    assert "Could not parse pickup input 'garbage'" in captured.out

    # We expect 2 options for Mon collection (Tue, Wed)
    # Tue collection should be skipped (Prof not on campus)
    assert len(options) == 2

    # Verify no option has pickup < collection
    for opt in options:
        assert opt.pickup_date >= opt.collection_date


def test_convenience_heatmap_no_options():
    """Test heatmap when calculate_quiz_options returns nothing for a day."""
    prof = Person("P1", "Teacher", parse_schedule("M 10:00am-11:00am"))
    grader = Person("G1", "Student", parse_schedule("M 10:00am-11:00am"))

    # Force to return nothing by providing a pickup date in the past
    # 04/01 is before 04/06 (Monday).
    heatmap = calculate_convenience_heatmap(
        prof, grader, datetime(2026, 4, 6), days=1, pickup_inputs=["04/01"]
    )
    assert len(heatmap) == 0


def test_wait_time_penalty():
    """Test that wait time penalty is calculated correctly."""
    # Prof 10:00 - 11:00 am, Grader 1:00 - 2:00 pm (13:00 - 14:00)
    prof = Person("Prof", "Teacher", parse_schedule("M 10:00am-11:00am"))
    grader = Person("Grader", "Student", parse_schedule("M 1:00pm-2:00pm"))

    # same day, wait time is 13:00 - 11:00 = 2 hours. Penalty should be 0.2
    c_date = datetime(2026, 4, 6)  # Monday
    options = calculate_quiz_options(prof, grader, [c_date], ["0"])

    assert len(options) == 1
    opt = options[0]
    assert opt.total_penalty == 0.2


def test_wait_time_penalty_zero():
    """Test wait time penalty when gap is zero or negative."""
    # Prof ends 11am, Grader starts 10am (negative gap)
    prof = Person("P1", "T", parse_schedule("M 10am-11am"))
    grader = Person("G1", "S", parse_schedule("M 9am-10am"))
    c_date = datetime(2026, 4, 6)
    penalty = _calculate_penalty(c_date, c_date, grader, prof)
    # Turnaround=0, Special=0, Load=0, Wait=0. Total=0
    assert penalty == 0.0


def test_optimal_matchmaking_empty():
    """Test optimal matchmaking with empty inputs."""
    assert not optimal_matchmaking([], [])


def test_optimal_matchmaking_with_scipy():
    """Test optimal matchmaking when scipy is available."""

    p1 = Person("P1", "Teacher", parse_schedule("M 10am-11am"))
    p2 = Person("P2", "Teacher", parse_schedule("T 10am-11am"))

    g1 = Person("G1", "Student", parse_schedule("Th 10am-11am"))
    g2 = Person("G2", "Student", parse_schedule("F 10am-11am"))

    matches = optimal_matchmaking([p1, p2], [g1, g2])
    assert len(matches) == 2


def test_optimal_matchmaking_fallback(monkeypatch, capsys):
    """Test fallback to greedy algorithm when scipy is missing."""
    monkeypatch.setattr(core_mod, "linear_sum_assignment", None)

    p1 = Person("P1", "Teacher", parse_schedule("M 10am-11am"))
    g1 = Person("G1", "Student", parse_schedule("Th 10am-11am"))

    matches = optimal_matchmaking([p1], [g1], start_date=datetime(2026, 4, 5))
    assert len(matches) == 1

    out, _ = capsys.readouterr()
    assert "Falling back to greedy algorithm" in out


def test_calculate_timeline():
    """Test chronological timeline generation."""
    prof = Person("Prof", "Teacher", parse_schedule("MWF 10:00am-11:00am"))
    grader = Person("Grader", "Student", parse_schedule("TTh 1:00pm-2:00pm"))

    # Start Monday 04/06/2026
    start = datetime(2026, 4, 6)
    timeline = calculate_timeline(prof, grader, start, days=7)

    # MWF -> 3 collection days
    assert len(timeline) == 3
    # Monday collection (04/06) -> Tue pickup (04/07)
    assert timeline[0].collection_date == datetime(2026, 4, 6)
    assert timeline[0].pickup_date == datetime(2026, 4, 7)
    # Friday collection (04/10) -> Tuesday pickup (04/14)
    assert timeline[2].collection_date == datetime(2026, 4, 10)
    assert timeline[2].pickup_date == datetime(2026, 4, 14)


def test_calculate_timeline_no_options():
    """Test timeline when some days have no options."""
    prof = Person("P1", "T", parse_schedule("M 10am-11am"))
    grader = Person("G1", "S", parse_schedule("T 10am-11am"))
    # 04/06 is Mon. 0-day window for pickup on same day?
    # but grader is only on Tue.
    # If we pass unparsable pickup_inputs, no candidates are generated.

    timeline = calculate_timeline(
        prof, grader, datetime(2026, 4, 6), days=1, pickup_inputs=["garbage"]
    )
    assert len(timeline) == 0


def test_complex_overdue_scenario():
    """
    Test Case: Shane has overdue assignments from Prof 1.
    Current Day: Thursday 04/02/2026.
    Questions: Best collection for Profs 2 and 3 next week?
    """
    student = Person("Shane", "Student", parse_schedule("TTh 5:30pm-10:00pm"))
    # Two overdue quizzes mean Shane is busy this weekend and coming Monday.
    # We penalize Fri-Mon heavily to represent the 'Catch-up' period.
    student.external_load = {
        "04/03": 50,  # Fri
        "04/04": 50,  # Sat
        "04/05": 50,  # Sun
        "04/06": 50,  # Mon
    }

    # Prof 2 (MW) and Prof 3 (TTh)
    prof2 = Person("Prof 2", "Teacher", parse_schedule("MW 10:00am-11:00am"))
    prof3 = Person("Prof 3", "Teacher", parse_schedule("TTh 1:00pm-2:00pm"))

    # Next week starts Sunday 04/05
    start = datetime(2026, 4, 5)

    # Prof 2: Mon (04/06) or Wed (04/08)
    options_prof2 = calculate_quiz_options(
        prof2, student, [start + timedelta(days=1), start + timedelta(days=3)], None
    )

    print("\n--- Prof 2 (M W) Options for Shane ---")
    for opt in options_prof2:
        print(
            f"Collect {opt.collection_date.strftime('%d %a %b')} -> "
            f"Pick up {opt.pickup_date.strftime('%d %a %b')} "
            f"(Penalty: {opt.total_penalty:.2f})"
        )

    # Best for Prof 2?
    # Both Mon (04/06) and Wed (04/08) collection dates result in an optimal
    # 1.00 penalty (Turnaround=1, Special=0, Load=0). Earliest is Monday.
    best_prof2 = options_prof2[0]
    assert best_prof2.collection_date == start + timedelta(days=1)
    assert best_prof2.pickup_date == start + timedelta(days=2)
    assert best_prof2.total_penalty == pytest.approx(1.0)

    # Prof 3: Tue (04/07) or Thu (04/09)
    options_prof3 = calculate_quiz_options(
        prof3, student, [start + timedelta(days=2), start + timedelta(days=4)], None
    )

    print("\n--- Prof 3 (T Th) Options for Shane ---")
    for opt in options_prof3:
        print(
            f"Collect {opt.collection_date.strftime('%d %a %b')} -> "
            f"Pick up {opt.pickup_date.strftime('%d %a %b')} "
            f"(Penalty: {opt.total_penalty:.2f})"
        )

    # Best for Prof 3?
    # Both Tue (04/07) and Thu (04/09) result in an optimal 0.35 penalty
    # (Turnaround=0, Special=0, Load=0, Wait=0.35). Earliest is Tuesday.
    best_prof3 = options_prof3[0]
    assert best_prof3.collection_date == start + timedelta(days=2)
    assert best_prof3.pickup_date == start + timedelta(days=2)
    assert best_prof3.total_penalty == pytest.approx(0.35)


def test_matchmaking_algorithms_comparison():
    """
    Test Case: Naive Greedy vs. Hungarian Matchmaking.
    A 'Greedy Trap' scenario with Shane and John.
    """

    # Shane (MWF) and John (TTh)
    shane = Person("Shane", "Student", parse_schedule("MWF 5:30pm-10:00pm"))
    john = Person("John", "Student", parse_schedule("TTh 1:00pm-5:00pm"))

    # Prof 1: MWF 10am class (Perfect for Shane)
    # Prof 2: MWF 11am class (Also good for Shane, but John is weak match)
    p1 = Person("Prof A", "Teacher", parse_schedule("MWF 10:00am-11:00am"))
    p2 = Person("Prof B", "Teacher", parse_schedule("MWF 11:30am-12:30pm"))

    # Modify John's schedule slightly so he is less compatible with Prof A.
    # We want a scenario where:
    # (P1, S) = 100, (P1, J) = 80
    # (P2, S) = 100, (P2, J) = 20

    # Let's use specific dates that force a'Greedy Trap'
    # Prof A: MWF (Mon/Wed/Fri)
    # Prof B: Mon only
    p1 = Person("Prof A", "Teacher", parse_schedule("MWF 10:00am-11:00am"))
    p2 = Person("Prof B", "Teacher", parse_schedule("M 10:00am-11:00am"))

    # Shane: On campus Wed/Fri (Compatible with P1's later-week pickups)
    # John: Only On campus Wed.
    shane = Person("Shane", "Student", parse_schedule("WF 1:00pm-2:00pm"))
    john = Person("John", "Student", parse_schedule("W 1:00pm-2:00pm"))

    # Alignment Logic:
    # 3-5 day window.
    # P1 (MWF):
    # - Mon -> Wed/Thu/Fri. Shane is WF. Match!
    # - Wed -> Sat/Sun/Mon. Neither are on campus. No Match.
    # - Fri -> Mon/Tue/Wed. Shane is No, John is Wed. Match!
    # P2 (Mon):
    # - Mon -> Wed/Thu/Fri. Shane is WF (Match), John is W (Match).

    # Let's verify compatibility manually:
    # P1: Mon, Wed, Fri (3 days)
    #   Mon pickup: Shane(W, F), John(W) -> Match for both.
    #   Wed pickup: None -> No match for both.
    #   Fri pickup: Shane(None), John(Wed) -> Match for John only.
    # Scores: (P1, Shane) = 1/3 (33.3%), (P1, John) = 2/3 (66.7%)
    # P2: Mon (1 day)
    #   Mon pickup: Shane(W), John(W) -> Match for both.
    # Scores: (P2, Shane) = 1/1 (100%), (P2, John) = 1/1 (100%)

    # Greedy Strategy:
    # 1. (P2, Shane) = 100 (Assigned)
    # 2. (P1, John) = 66.7 (Assigned)
    # Total = 166.7

    # Hungarian Strategy:
    # 1. (P2, John) = 100
    # 2. (P1, Shane) = 33.3  (Wait, this is worse? No, 100+66.7 > 100+33.3)

    # Let's flip it:
    # (P1, S) = 90, (P1, J) = 80
    # (P2, S) = 70, (P2, J) = 5
    # Greedy: (P1, S=90) -> (P2, J=5) = 95
    # Hungarian: (P1, J=80) -> (P2, S=70) = 150

    profs = [p1, p2]
    graders = [shane, john]

    # We'll use a specific datetime next week to factor in "catch-up"
    start = datetime(2026, 4, 5)  # Sunday
    shane.external_load = {"04/06": 50}  # Shane busy Mon (ruins Mon pickups)

    greedy_matches = global_matchmaking(profs, graders, start_date=start)
    optimal_matches = optimal_matchmaking(profs, graders, start_date=start)

    print("\n--- Matchmaking Comparison (Shane Overdue) ---")
    print("Greedy Matchmaking (Naive):")
    g_total = 0
    for m in greedy_matches:
        print(f"  {m['prof']} matched with {m['grader']} (Score: {m['score']}%)")
        g_total += m["score"]

    print("Hungarian Matchmaking (Optimal):")
    o_total = 0
    for m in optimal_matches:
        print(f"  {m['prof']} matched with {m['grader']} (Score: {m['score']}%)")
        o_total += m["score"]

    print(f"Total Scores: Greedy={g_total:.1f} vs Hungarian={o_total:.1f}")

    # Hungarian should be >= Greedy
    assert o_total >= g_total


def test_calculate_weekly_cadence():
    """Test weekly cadence aggregation."""
    prof = Person("Prof", "Teacher", parse_schedule("MWF 10:00am-11:00am"))
    grader = Person("Grader", "Student", parse_schedule("TTh 1:00pm-2:00pm"))
    start = datetime(2026, 4, 6)  # Monday

    res = calculate_weekly_cadence(prof, grader, start, weeks=2)
    assert "Monday" in res
    assert "Wednesday" in res
    assert "Friday" in res
    assert "Tuesday" not in res
    # Monday pickup on Tue (Turnaround 1) -> Penalty 1.0
    assert res["Monday"] == 1.0
