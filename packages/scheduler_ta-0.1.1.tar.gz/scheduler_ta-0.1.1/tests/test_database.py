# -*- coding: utf-8 -*-
"""
Created on Thu Apr  2 12:32:00 2026

@author: shane

Unit tests for database persistence and staff management.
"""

import os
import sys
from datetime import datetime, timedelta

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from scheduler_ta.database import Base, init_db
from scheduler_ta.main import main
from scheduler_ta.models import Person, TimeBlock


@pytest.fixture(name="db_session")
def fixture_db_session():
    """Provides a clean in-memory SQLite database for each test."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)
    session_local = sessionmaker(bind=engine)
    session = session_local()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


def test_person_creation_and_retrieval(db_session):
    """Test correctly creating and retrieving a Person from the database."""
    person = Person(name="Shane", role="Student")
    db_session.add(person)
    db_session.commit()

    retrieved = db_session.query(Person).filter(Person.name == "Shane").first()
    assert retrieved is not None
    assert retrieved.name == "Shane"
    assert retrieved.role == "Student"


def test_person_with_schedule(db_session):
    """Test retrieving a Person with associated TimeBlocks."""
    person = Person(name="Euler", role="Teacher")
    block = TimeBlock(weekday=0, start_time="10:00", end_time="11:45")
    person.schedule.append(block)

    db_session.add(person)
    db_session.commit()

    retrieved = db_session.query(Person).filter(Person.name == "Euler").first()
    assert len(retrieved.schedule) == 1
    assert retrieved.schedule[0].weekday == 0


def test_person_is_on_campus(db_session):
    """Test the is_on_campus method using database records."""
    person = Person(name="Shane", role="Student")
    # Monday = 0
    person.schedule.append(TimeBlock(weekday=0, start_time="10:00", end_time="11:00"))
    db_session.add(person)
    db_session.commit()

    # Apr 6, 2026 is a Monday (weekday 0)
    monday = datetime(2026, 4, 6)
    # Apr 7, 2026 is a Tuesday (weekday 1)
    tuesday = datetime(2026, 4, 7)

    assert person.is_on_campus(monday) is True
    assert person.is_on_campus(tuesday) is False


def test_init_db_creates_directory(tmp_path, monkeypatch):
    """Test that init_db creates the necessary application directories."""
    db_dir = tmp_path / ".scheduler_ta"
    monkeypatch.setattr("scheduler_ta.database.DB_DIR", str(db_dir))
    monkeypatch.setattr("scheduler_ta.database.DB_PATH", str(db_dir / "data.db"))
    monkeypatch.setattr("scheduler_ta.database.DB_URL", f"sqlite:///{db_dir}/data.db")

    # We need to re-initialize the engine for the monkeypatched URL
    new_engine = create_engine(f"sqlite:///{db_dir}/data.db")
    monkeypatch.setattr("scheduler_ta.database.engine", new_engine)

    init_db()
    assert os.path.exists(db_dir)
    assert os.path.exists(db_dir / "data.db")
    new_engine.dispose()


def test_main_db_commands(
    monkeypatch, capsys, tmp_path
):  # pylint: disable=too-many-statements
    """Test the 'db' commands in main.py via mocked environment."""
    db_dir = tmp_path / ".scheduler_ta_cli"
    db_path = db_dir / "data.db"

    # Mock database environment
    monkeypatch.setattr("scheduler_ta.database.DB_DIR", str(db_dir))
    monkeypatch.setattr("scheduler_ta.database.DB_PATH", str(db_path))
    monkeypatch.setattr("scheduler_ta.database.DB_URL", f"sqlite:///{db_path}")

    new_engine = create_engine(f"sqlite:///{db_path}")
    monkeypatch.setattr("scheduler_ta.database.engine", new_engine)
    # pylint: disable=no-member
    monkeypatch.setattr(
        "scheduler_ta.database.SESSION_LOCAL", sessionmaker(bind=new_engine)
    )

    # 1. Init
    monkeypatch.setattr(sys, "argv", ["scheduler-ta", "db", "init"])
    main()
    capsys.readouterr()

    # 2. Empty List Check
    monkeypatch.setattr(sys, "argv", ["scheduler-ta", "db", "list"])
    main()
    out, _ = capsys.readouterr()
    assert "No staff members found" in out

    # 3. Add Person (Shane)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "scheduler-ta",
            "db",
            "add-person",
            "--name",
            "Shane",
            "--role",
            "Student",
            "--sched",
            "TTh 5:30pm-10:00pm",
            "--load",
            "04/06:50",
        ],
    )
    main()
    capsys.readouterr()

    # 4. List now should have Shane
    monkeypatch.setattr(sys, "argv", ["scheduler-ta", "db", "list"])
    main()
    out, _ = capsys.readouterr()
    assert "Shane" in out

    # 4b. Update Shane (Upsert)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "scheduler-ta",
            "db",
            "add-person",
            "--name",
            "Shane",
            "--role",
            "Student",
            "--sched",
            "TTh 5:30pm-10:00pm",
            "--load",
            "04/06:50",
        ],
    )
    main()
    out, _ = capsys.readouterr()
    assert "Updated" in out

    # 5. Quiz with Shane and Extra Load
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "scheduler-ta",
            "quiz",
            "-c",
            "04/06",
            "--prof-name",
            "Shane",
            "--grader-name",
            "Shane",
            "--load",
            "04/07:100",
        ],
    )
    main()
    out, _ = capsys.readouterr()
    assert "Shane" in out

    # 6. Add professor Euler
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "scheduler-ta",
            "db",
            "add-person",
            "--name",
            "Euler",
            "--role",
            "Teacher",
            "--sched",
            "MWF 10am-11am",
        ],
    )
    main()
    capsys.readouterr()

    # 7. Heatmap and Timeline
    modes = ["heatmap", "timeline"]
    for mode in modes:
        argv = ["scheduler-ta", mode, "--prof-name", "Euler", "--grader-name", "Shane"]
        monkeypatch.setattr(sys, "argv", argv)
        main()
        out, _ = capsys.readouterr()
        assert "Euler" in out

    # 8. Pair Mode (Global)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "scheduler-ta",
            "pair",
            "--prof-names",
            "Euler",
            "--grader-names",
            "Shane",
            "--global-opt",
        ],
    )
    main()
    out, _ = capsys.readouterr()
    assert "GLOBAL" in out

    # 9. No Args Case
    monkeypatch.setattr(sys, "argv", ["scheduler-ta"])
    main()
    out, _ = capsys.readouterr()
    assert "usage:" in out

    # 10. Pair Empty Error
    monkeypatch.setattr(sys, "argv", ["scheduler-ta", "pair"])
    with pytest.raises(SystemExit):
        main()
    out, _ = capsys.readouterr()
    assert "Error: Specify both instructors and graders." in out

    # 11. No Options Coverage
    # Add staff with impossible schedule (Empty)
    # We use a date far in the future to ensure no hits in a 14-day window
    future_date = (datetime.now() + timedelta(days=100)).strftime("%m/%d")
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "scheduler-ta",
            "db",
            "add-person",
            "--name",
            "Ghost",
            "--role",
            "Teacher",
            "--sched",
            f"{future_date} 10am-11am",
        ],
    )
    main()
    capsys.readouterr()

    modes_fail = ["quiz", "heatmap", "timeline"]
    for mode in modes_fail:
        argv = ["scheduler-ta", mode, "--prof-name", "Ghost", "--grader-name", "Shane"]
        if mode == "quiz":
            argv.extend(["-c", "04/06"])
        monkeypatch.setattr(sys, "argv", argv)
        main()
        out, _ = capsys.readouterr()
        assert "No" in out  # Hits "No valid schedules" / "No campus presence"

    # 12. Person Not Found Coverage
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "scheduler-ta",
            "quiz",
            "-c",
            "04/06",
            "--prof-name",
            "DoesNotExist",
            "--grader-name",
            "Shane",
        ],
    )
    with pytest.raises(SystemExit):
        main()
    out, _ = capsys.readouterr()
    assert "not found in database" in out

    # 13. Reset DB Coverage
    monkeypatch.setattr(
        sys,
        "argv",
        ["scheduler-ta", "db", "reset"],
    )
    monkeypatch.setattr("builtins.input", lambda _: "")
    main()
    out, _ = capsys.readouterr()
    assert "reset" in out

    # 14. Export DB Coverage
    monkeypatch.setattr(
        sys,
        "argv",
        ["scheduler-ta", "db", "export"],
    )
    main()
    out, _ = capsys.readouterr()
    assert "exported" in out

    new_engine.dispose()
