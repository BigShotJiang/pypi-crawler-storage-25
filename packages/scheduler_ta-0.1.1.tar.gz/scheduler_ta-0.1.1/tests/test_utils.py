# -*- coding: utf-8 -*-
"""
Created on Sun Mar 29 11:00:00 2026

@author: shane

Unit tests for the schedule and date parsing utilities.
"""

from datetime import datetime

import pytest

from scheduler_ta.utils import format_schedule, parse_date, parse_schedule


def test_parse_schedule_single_block():
    """Test parsing a single time block."""
    blocks = parse_schedule("MWF 10:30am-12:15pm")
    assert len(blocks) == 3
    assert blocks[0].weekday == 0  # Monday
    assert blocks[0].start_time == "10:30"
    assert blocks[2].weekday == 4  # Friday


def test_parse_schedule_multi_block():
    """Test parsing multiple blocks separated by semicolon."""
    blocks = parse_schedule("MW 10:30am-12:00pm; TTh 1:00pm-2:00pm")
    assert len(blocks) == 4
    # MW
    assert blocks[0].weekday == 0
    assert blocks[1].weekday == 2
    # TTh
    assert blocks[2].weekday == 1
    assert blocks[3].weekday == 3


def test_parse_schedule_abbreviations():
    """Test 'TTh' to 'TR' conversion."""
    blocks = parse_schedule("TTh 1:00pm-2:00pm")
    assert len(blocks) == 2
    assert blocks[0].weekday == 1
    assert blocks[1].weekday == 3


def test_parse_date_absolute():
    """Test MM/DD parsing."""
    date = parse_date("04/01")
    assert date.month == 4
    assert date.day == 1
    assert date.year == 2026


def test_parse_date_offset():
    """Test integer offset parsing."""
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    date = parse_date("2")
    assert (date - today).days == 2


def test_parse_date_invalid():
    """Test error on invalid format."""
    with pytest.raises(ValueError, match="Invalid date format"):
        parse_date("invalid_date")


def test_format_schedule():
    """Test correctly formatting list of timeblocks back to strings."""
    blocks = parse_schedule("MWF 10:00am-11:00am")
    # Our formatter outputs in 24h
    formatted = format_schedule(blocks)
    assert "MWF 10:00-11:00" in formatted

    blocks2 = parse_schedule("TTh 1:00pm-2:00pm; M 10:00am-11:00am")
    formatted2 = format_schedule(blocks2)
    assert "TTh 13:00-14:00" in formatted2
    assert "M 10:00-11:00" in formatted2

    assert format_schedule([]) == "None"


def test_parse_schedule_empty():
    """Test parsing an empty schedule string."""
    assert not parse_schedule("")


def test_parse_schedule_no_time_part():
    """Test parsing a schedule string with no time part."""
    assert not parse_schedule("MWF")


def test_parse_schedule_bad_time_format():
    """Test parsing a schedule string with an invalid time format."""
    assert not parse_schedule("MWF noon-1pm")


def test_parse_schedule_unparsable_time():
    """Line 42: to_24h raises ValueError for a truly unparsable token."""
    # Force regex to match but strptime to fail both formats
    with pytest.raises(ValueError, match="Could not parse time"):
        parse_schedule("MWF 25am-12pm")
