# -*- coding: utf-8 -*-
"""
Database configuration and session management for scheduler-ta.
"""

import os
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

# Default database location: ~/.scheduler_ta/data.db
DB_DIR = os.path.expanduser("~/.scheduler_ta")
DB_PATH = os.path.join(DB_DIR, "data.db")
DB_URL = f"sqlite:///{DB_PATH}"

Base = declarative_base()
engine = create_engine(DB_URL, echo=False)
SESSION_LOCAL = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Initializes the database directory and creates all tables."""
    if not os.path.exists(DB_DIR):
        os.makedirs(DB_DIR)

    # Import models here to ensure they are registered with Base
    # pylint: disable=import-outside-toplevel, unused-import, cyclic-import
    from . import models  # noqa: F401

    Base.metadata.create_all(bind=engine)


def reset_db():
    """Drops the entire database and recreates it."""
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    init_db()


@contextmanager
def get_db():
    """Context manager for database sessions."""
    if not os.path.exists(DB_DIR):
        init_db()
    db = SESSION_LOCAL()
    try:
        yield db
    finally:
        db.close()
