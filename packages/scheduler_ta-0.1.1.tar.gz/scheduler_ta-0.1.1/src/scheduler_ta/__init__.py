# -*- coding: utf-8 -*-
"""
Created on Wed Apr 01 08:00:00 2026

@author: shane

Scheduler-TA package initialization.
"""
