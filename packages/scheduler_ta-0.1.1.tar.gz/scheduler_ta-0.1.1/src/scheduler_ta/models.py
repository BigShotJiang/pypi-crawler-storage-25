# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 14:20:00 2026

@author: shane

Data models for the scheduler-ta application.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import List

from sqlalchemy import Boolean, Column, ForeignKey, Integer, String
from sqlalchemy.ext.associationproxy import association_proxy
from sqlalchemy.orm import attribute_mapped_collection, relationship

from .database import Base


class TimeBlock(Base):  # pylint: disable=too-few-public-methods
    """Represents a recurring time period on campus for a specific weekday."""

    __tablename__ = "time_blocks"

    id = Column(Integer, primary_key=True, index=True)
    person_id = Column(Integer, ForeignKey("people.id"))
    weekday = Column(Integer)  # 0=Monday, 6=Sunday
    start_time = Column(String)  # "HH:MM"
    end_time = Column(String)  # "HH:MM"

    person = relationship("Person", back_populates="schedule")

    def __init__(self, weekday=None, start_time=None, end_time=None, **kwargs):
        super().__init__(
            weekday=weekday, start_time=start_time, end_time=end_time, **kwargs
        )


class ExternalLoad(Base):
    """Represents a short-term busy period (e.g. exams) for a Person."""

    # pylint: disable=too-few-public-methods
    __tablename__ = "external_loads"

    id = Column(Integer, primary_key=True, index=True)
    person_id = Column(Integer, ForeignKey("people.id"))
    date_str = Column(String)  # "MM/DD"
    score = Column(Integer)  # 0-100 penalty

    person = relationship("Person", back_populates="_external_load_rel")


class Person(Base):
    """
    Represents a university staff member (Professor or Grader).
    """

    __tablename__ = "people"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    role = Column(String)  # "Teacher" or "Student"
    is_fixed = Column(Boolean, default=False)

    schedule = relationship(
        "TimeBlock", back_populates="person", cascade="all, delete-orphan"
    )

    _external_load_rel = relationship(
        "ExternalLoad",
        collection_class=attribute_mapped_collection("date_str"),
        back_populates="person",
        cascade="all, delete-orphan",
    )

    # Proxy 'external_load' to act like a dict {date_str: score}
    external_load = association_proxy(
        "_external_load_rel",
        "score",
        creator=lambda k, v: ExternalLoad(date_str=k, score=v),
    )

    def __init__(  # pylint: disable=too-many-arguments, too-many-positional-arguments
        self,
        name=None,
        role=None,
        schedule=None,
        external_load=None,
        is_fixed=False,
        **kw,
    ):
        super().__init__(name=name, role=role, is_fixed=is_fixed, **kw)
        if schedule:
            self.schedule = schedule
        if external_load:
            self.external_load = external_load

    def is_on_campus(self, date: datetime) -> bool:
        """Check if the person is on campus on the weekday of the given date."""
        return len(self.get_presence(date)) > 0

    def get_presence(self, date: datetime) -> List[TimeBlock]:
        """Return all TimeBlocks for a specific date's weekday."""
        weekday = date.weekday()
        return [block for block in self.schedule if block.weekday == weekday]

    def get_load(self, date: datetime) -> int:
        """Return the external workload penalty for a specific date."""
        d_str = date.strftime("%m/%d")
        return self.external_load.get(d_str, 0)


@dataclass
class ScheduleOption:
    """
    Represents a proposed collection and pickup pairing with its calculated penalty.
    """

    collection_date: datetime
    pickup_date: datetime
    special_trips: int
    turnaround_days: int
    total_penalty: float
