# -*- coding: utf-8 -*-
"""
Main entry point for the scheduler-ta CLI.
"""

import argparse
import os
import sqlite3
import sys
from contextlib import closing
from datetime import datetime
from typing import List, Optional

import argcomplete

from .core import (
    calculate_convenience_heatmap,
    calculate_quiz_options,
    calculate_timeline,
    calculate_weekly_cadence,
    optimal_matchmaking,
    optimize_pairings,
)
from .database import DB_DIR, DB_PATH, get_db, init_db, reset_db
from .models import Person
from .utils import format_schedule, parse_date, parse_schedule


def parse_load(load_args: List[str]) -> dict:
    """Parses 'MM/DD:Score' format into a dictionary."""
    loads = {}
    if not load_args:
        return loads
    for item in load_args:
        try:
            date_str, score = item.split(":")
            loads[date_str] = int(score)
        except ValueError:
            print(f"Warning: Invalid load format '{item}'. Expected MM/DD:Score.")
    return loads


def fetch_person(
    db, name: Optional[str], manual_sched: Optional[str], role: str
) -> Person:
    """Resolves a Person from database, manual input, or an anonymous fallback."""
    if name:
        person = db.query(Person).filter(Person.name == name).first()
        if not person:
            print(f"Error: Person '{name}' not found in database.")
            sys.exit(1)
        return person
    if manual_sched:
        # Generate a name for transient person to avoid relationship collisions
        idx = 1
        default_name = f"{'Prof' if role == 'Teacher' else 'Grader'}_{idx}"
        return Person(
            name=default_name, role=role, schedule=parse_schedule(manual_sched)
        )
    # Default fallback for one-sided analysis (e.g. tests or simple CLI usage)
    return Person(name="Anonymous", role=role, schedule=[])


def handle_db_mode(args):
    """Handles staff database management commands."""
    if args.db_cmd == "init":
        init_db()
        print("Database initialized at ~/.scheduler_ta/data.db")
        return
    if args.db_cmd == "reset":
        try:
            input(
                "WARNING: This will wipe the entire database clean! "
                "Press Enter to proceed or Ctrl+C to cancel..."
            )
        except (KeyboardInterrupt, EOFError):
            print("\nDatabase reset aborted.")
            return
        reset_db()
        print("Database has been completely reset.")
        return
    if args.db_cmd == "export":

        export_path = os.path.join(DB_DIR, "scheduler_ta_backup.sql")

        with closing(sqlite3.connect(DB_PATH)) as conn:
            with open(export_path, "w", encoding="utf-8") as f:
                for line in conn.iterdump():
                    f.write(f"{line}\n")

        print(f"Database exported to {export_path}")
        return

    with get_db() as db:
        if args.db_cmd == "add-person":
            existing = db.query(Person).filter(Person.name == args.name).first()
            if existing:
                existing.role = args.role
                existing.schedule = parse_schedule(args.sched)
                existing.external_load = parse_load(args.load)
                db.commit()
                print(f"Updated {args.role} '{args.name}' in database.")
                return

            person = Person(
                name=args.name,
                role=args.role,
                schedule=parse_schedule(args.sched),
                external_load=parse_load(args.load),
            )
            db.add(person)
            db.commit()
            print(f"Added {args.role} '{args.name}' to database.")
        elif args.db_cmd == "list":
            people = db.query(Person).all()
            print("\n=== DEPARTMENT STAFF ===\n")
            if not people:
                print("No staff members found.")
            for p in people:
                print(f"[{p.role}] {p.name}")


def handle_quiz_mode(args):  # pylint: disable=too-many-locals
    """Handles quiz collection/pickup optimization analysis."""
    # 1. Parse dates FIRST to satisfy tests expecting format errors early
    collection_dates = []
    for c_str in args.collect:
        try:
            collection_dates.append(parse_date(c_str))
        except ValueError as e:
            print(f"Error: {e}")
            sys.exit(1)

    # 2. Fetch persons
    with get_db() as db:
        prof_manual = args.prof or args.prof_sched
        grader_manual = args.grader or args.grader_sched

        prof = fetch_person(db, args.prof_name, prof_manual, "Teacher")
        grader = fetch_person(db, args.grader_name, grader_manual, "Student")

        # Apply additional transient load if provided
        if args.load:
            extra_load = parse_load(args.load)
            for d, s in extra_load.items():
                grader.external_load[d] = s

        ranked_solutions = calculate_quiz_options(
            prof, grader, collection_dates, args.pickup
        )

        print("\n=== OPTIMIZED QUIZ SCHEDULES (RANKED) ===\n")
        print(f"Prof:   {prof.name}")
        print(f"Grader: {grader.name}\n")

        if not ranked_solutions:
            print(
                "No valid schedules found. Check if Prof has classes on "
                "specified dates."
            )
            return

        for sol in ranked_solutions[:20]:
            c_f = sol.collection_date.strftime("%d %a %b")
            p_f = sol.pickup_date.strftime("%d %a %b")
            commute_str = "✓" if sol.special_trips == 0 else "⚠ SPECIAL TRIP"
            msg = (
                f"Collect [{c_f}] -> Pickup [{p_f}] | "
                f"Penalty: {sol.total_penalty:.2f} ({commute_str})"
            )
            print(msg)


def handle_heatmap_mode(args):
    """Handles convenience heatmap analysis."""
    start_date = parse_date(args.start) if args.start else datetime.now()

    with get_db() as db:
        prof_manual = args.prof or args.prof_sched
        grader_manual = args.grader or args.grader_sched

        prof = fetch_person(db, args.prof_name, prof_manual, "Teacher")
        grader = fetch_person(db, args.grader_name, grader_manual, "Student")

        heatmap = calculate_convenience_heatmap(prof, grader, start_date, args.days)

        print(f"\n=== CONVENIENCE HEATMAP ({args.days} DAYS) ===\n")
        print(f"Prof: {prof.name}, Grader: {grader.name}\n")
        if not heatmap:
            print("No campus presence found in specified range.")
        for entry in heatmap:
            d = entry["date"]
            score = entry["score"]
            print(f"{d.strftime('%d %a %b')}: Best Penalty {score:.2f}")


def handle_pair_mode(args):  # pylint: disable=too-many-branches
    """Handles pairing comparison and matchmaking analysis."""
    # 1. Parse date first
    d = parse_date(args.date) if args.date else None

    with get_db() as db:
        profs = []
        if args.prof_names:
            for name in args.prof_names:
                profs.append(fetch_person(db, name, None, "Teacher"))
        elif args.prof:
            for i, s in enumerate(args.prof, 1):
                profs.append(
                    Person(name=f"Prof_{i}", role="Teacher", schedule=parse_schedule(s))
                )

        graders = []
        if args.grader_names:
            for name in args.grader_names:
                graders.append(fetch_person(db, name, None, "Student"))
        elif args.grader:
            for i, s in enumerate(args.grader, 1):
                graders.append(
                    Person(
                        name=f"Grader_{i}", role="Student", schedule=parse_schedule(s)
                    )
                )

        if not profs or not graders:
            print("Error: Specify both instructors and graders.")
            sys.exit(1)

        if args.global_opt:
            matches = optimal_matchmaking(profs, graders, start_date=d)
            print("\n=== GLOBAL DEPARTMENT-WIDE BEST MATCHES ===\n")
            for m in matches:
                msg = (
                    f"{m['prof']} pairs with {m['grader']} "
                    f"(Score: {m['score']:.1f}%)"
                )
                print(msg)
        else:
            pairings = optimize_pairings(profs, graders, start_date=d)
            print("\n=== INDIVIDUAL PAIRING COMPATIBILITY ===\n")
            for p in pairings:
                print(f"{p['prof']} + {p['grader']}: {p['score']:.1f}% Match")


def handle_timeline_mode(args):
    """Handles chronological guidance analysis."""
    start_date = parse_date(args.start) if args.start else datetime.now()

    with get_db() as db:
        prof_manual = args.prof or args.prof_sched
        grader_manual = args.grader or args.grader_sched

        prof = fetch_person(db, args.prof_name, prof_manual, "Teacher")
        grader = fetch_person(db, args.grader_name, grader_manual, "Student")

        timeline = calculate_timeline(prof, grader, start_date, args.days)

        print(f"\n=== EXPECTED TURNAROUND GUIDANCE ({args.days} DAYS) ===\n")
        print(f"Prof: {prof.name}, Grader: {grader.name}\n")
        if not timeline:
            print("No teaching days found in specified range.")
        for ent in timeline:
            c_f = ent.collection_date.strftime("%d %a %b")
            p_f = ent.pickup_date.strftime("%d %a %b")
            print(
                f"Collect [{c_f}] -> Pickup [{p_f}] | "
                f"Penalty: {ent.total_penalty:.2f} [Turnaround]"
            )


def handle_cadence_mode(args):
    """Handles syllabus cadence analysis."""
    start_date = parse_date(args.start) if args.start else datetime.now()

    with get_db() as db:
        prof_manual = args.prof or args.prof_sched
        grader_manual = args.grader or args.grader_sched

        prof = fetch_person(db, args.prof_name, prof_manual, "Teacher")
        grader = fetch_person(db, args.grader_name, grader_manual, "Student")

        cadence_results = calculate_weekly_cadence(prof, grader, start_date, args.weeks)

        print(f"\n=== SYLLABUS CADENCE ADVISOR ({args.weeks} WEEKS) ===\n")
        print(f"Prof:   {prof.name} ({format_schedule(prof.schedule)})")
        print(f"Grader: {grader.name} ({format_schedule(grader.schedule)})\n")

        if not cadence_results:
            print("No teaching days found.")
            return

        print("If you rigidly collect assignments weekly on:")
        best_day = None
        best_score = float("inf")

        for pday, score in cadence_results.items():
            print(f"  - {pday:<10}: Avg Penalty {score:.2f}")
            if score < best_score:
                best_score = score
                best_day = pday

        if best_day:
            msg = (
                f"\nRecommendation: Design your syllabus with "
                f"{best_day.upper()} collection dates."
            )
            print(msg)


def handle_install_completion(args: argparse.Namespace) -> None:
    """Installs argcomplete hook into the user's shell rc file."""
    shell = args.shell
    rc_file = os.path.expanduser(f"~/.{shell}rc")
    hook = 'eval "$(register-python-argcomplete scheduler-ta)"'

    try:
        # Check if already installed
        if os.path.exists(rc_file):
            with open(rc_file, "r", encoding="utf-8") as f:
                if hook in f.read():
                    print(f"Completion hook already exists in {rc_file}")
                    return

        with open(rc_file, "a", encoding="utf-8") as f:
            f.write(f"\n# scheduler-ta autocompletion\n{hook}\n")
        print(f"Successfully installed autocompletion hook into {rc_file}!\n")
        print(f"Please restart your terminal or run: source {rc_file}")
    # pylint: disable=broad-except
    except Exception as e:
        print(f"Failed to install completion hook: {e}")


def setup_parser() -> argparse.ArgumentParser:
    """Sets up the CLI argument parser."""
    parser = argparse.ArgumentParser(description="Academic Grading & Pairing Optimizer")
    subparsers = parser.add_subparsers(dest="mode", help="Analysis mode")

    # DB subcommand
    db_p = subparsers.add_parser("db", help="Manage staff database")
    db_sub = db_p.add_subparsers(dest="db_cmd", help="Database operation")
    db_sub.add_parser("init", help="Initialize database")
    db_sub.add_parser("reset", help="Reset database and drop all tables")
    db_sub.add_parser("export", help="Export database to SQL dump file")
    db_sub.add_parser("list", help="List all staff members")

    add_p = db_sub.add_parser("add-person", help="Add staff member")
    add_p.add_argument("--name", required=True)
    add_p.add_argument("--role", required=True, choices=["Teacher", "Student"])
    add_p.add_argument("--sched", required=True)
    add_p.add_argument("--load", nargs="*", help="MM/DD:Score loads")

    # Shared analysis arguments
    def add_shared_args(p):
        p.add_argument("--prof-name", help="DB name")
        p.add_argument("--grader-name", help="DB name")
        p.add_argument("--prof", help="Manual schedule")
        p.add_argument("--grader", help="Manual schedule")
        p.add_argument("--prof-sched", help=argparse.SUPPRESS)
        p.add_argument("--grader-sched", help=argparse.SUPPRESS)

    # Mode parsers
    quiz_p = subparsers.add_parser("quiz", help="Quiz optimization")
    quiz_p.add_argument("-c", "--collect", required=True, nargs="+")
    quiz_p.add_argument("-p", "--pickup", nargs="+")
    add_shared_args(quiz_p)
    quiz_p.add_argument("--load", nargs="*", help="Extra load")

    heat_p = subparsers.add_parser("heatmap", help="Convenience heatmap")
    heat_p.add_argument("-s", "--start")
    heat_p.add_argument("-d", "--days", type=int, default=14)
    add_shared_args(heat_p)

    pair_p = subparsers.add_parser("pair", help="Compare pairing")
    pair_p.add_argument("--prof-names", nargs="+")
    pair_p.add_argument("--grader-names", nargs="+")
    pair_p.add_argument("--prof", nargs="+")
    pair_p.add_argument("--grader", nargs="+")
    pair_p.add_argument("--global-opt", action="store_true")
    pair_p.add_argument("--date")

    time_p = subparsers.add_parser("timeline", help="Turnaround guidance")
    time_p.add_argument("-s", "--start")
    time_p.add_argument("-d", "--days", type=int, default=14)
    add_shared_args(time_p)

    cad_p = subparsers.add_parser("cadence", help="Syllabus cadence advisor")
    cad_p.add_argument("-s", "--start")
    cad_p.add_argument("-w", "--weeks", type=int, default=16)
    add_shared_args(cad_p)

    comp_p = subparsers.add_parser(
        "install-completion", help="Install shell autocompletion"
    )
    comp_p.add_argument(
        "-s", "--shell", choices=["bash", "zsh"], required=True, help="Target shell"
    )

    return parser


def main():
    """Main CLI entry point."""
    parser = setup_parser()
    try:
        argcomplete.autocomplete(parser)
    # pylint: disable=broad-except
    except Exception as e:
        print(f"Error: {e}")
    args = parser.parse_args()

    if not args.mode:
        parser.print_help()
        return

    handlers = {
        "db": handle_db_mode,
        "quiz": handle_quiz_mode,
        "heatmap": handle_heatmap_mode,
        "pair": handle_pair_mode,
        "timeline": handle_timeline_mode,
        "cadence": handle_cadence_mode,
        "install-completion": handle_install_completion,
    }

    if args.mode in handlers:
        handlers[args.mode](args)
