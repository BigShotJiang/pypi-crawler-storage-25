# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 10:15:00 2026

@author: shane

Utility functions for parsing schedules and dates.
"""

import re
from datetime import datetime, timedelta
from typing import List

from .models import TimeBlock


def _parse_single_block(block_str: str) -> List[TimeBlock]:
    """Parses a single 'Days Time-Range' block into TimeBlocks."""
    # Map characters to weekday integers
    day_map = {"M": 0, "T": 1, "W": 2, "R": 3, "F": 4, "S": 5, "U": 6}

    parts = re.split(r"\s+", block_str.strip())
    if len(parts) < 2:
        return []

    days_part = parts[0].replace("TTh", "TR")
    time_part = parts[1]

    active_days = []
    for char in days_part:
        if char in day_map:
            active_days.append(day_map[char])

    # Parse time range: "10:30am-12:15pm" or "10am-12pm" (ignore case)
    time_regex = r"(\d{1,2}(?::\d{2})?[ap]m)-(\d{1,2}(?::\d{2})?[ap]m)"
    time_match = re.match(time_regex, time_part, re.I)
    if not time_match:
        return []

    def to_24h(t_str):
        t_str = t_str.lower()
        for fmt in ("%I:%M%p", "%I%p"):
            try:
                return datetime.strptime(t_str, fmt).strftime("%H:%M")
            except ValueError:
                continue
        raise ValueError(f"Could not parse time: {t_str}")

    # TODO: Handle exceptions
    start_24 = to_24h(time_match.group(1))
    end_24 = to_24h(time_match.group(2))

    return [TimeBlock(day, start_24, end_24) for day in active_days]


def parse_schedule(schedule_str: str) -> List[TimeBlock]:
    """
    Parses a schedule string like 'MWF 10:30am-12:15pm' or 'TTh 5:30pm-10:00pm'.
    Supports multiple blocks separated by semicolons.
    """
    if not schedule_str:
        return []

    all_blocks = []
    # Support multiple blocks separated by semicolon
    for block_str in schedule_str.split(";"):
        all_blocks.extend(_parse_single_block(block_str))

    return all_blocks


def format_schedule(schedule: List[TimeBlock]) -> str:
    """Formats a list of TimeBlocks into a concise string like 'MWF 10:00-11:00'."""
    if not schedule:
        return "None"

    day_abbr = {0: "M", 1: "T", 2: "W", 3: "Th", 4: "F", 5: "S", 6: "Su"}
    grouped = {}
    for block in schedule:
        key = (block.start_time, block.end_time)
        if key not in grouped:
            grouped[key] = []
        grouped[key].append(block.weekday)

    parts = []
    for (start, end), days in grouped.items():
        days.sort()
        day_str = "".join([day_abbr.get(d, str(d)) for d in days])
        parts.append(f"{day_str} {start}-{end}")

    return "; ".join(parts)


def parse_date(date_str: str) -> datetime:
    """Parses MM/DD format or integer offset from today."""
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    try:
        # Try parsing as integer offset
        offset = int(date_str)
        return today + timedelta(days=offset)
    except ValueError:
        try:
            # Try MM/DD (assume current year)
            current_year = today.year
            return datetime.strptime(f"{date_str}/{current_year}", "%m/%d/%Y")
        except ValueError as exc:
            raise ValueError(
                f"Invalid date format '{date_str}'. Expected MM/DD or integer offset."
            ) from exc
