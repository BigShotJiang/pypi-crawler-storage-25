# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 16:45:00 2026

@author: shane

Core scheduling algorithms and optimization logic.
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional

try:
    from scipy.optimize import linear_sum_assignment
except ImportError:
    linear_sum_assignment = None


from .models import Person, ScheduleOption
from .utils import parse_date


def _calculate_penalty(
    c_date: datetime, p_date: datetime, grader: Person, prof: Person
) -> float:
    """Calculates the total penalty score for a collection/pickup combination."""

    # pylint: disable=too-many-locals

    turnaround = (p_date - c_date).days
    is_special = not grader.is_on_campus(p_date)
    special_trips = 1 if is_special else 0

    # Wait Time Penalty (for same-day pickup)
    wait_penalty = 0.0
    if turnaround == 0:
        p_presence = grader.get_presence(p_date)
        c_presence = prof.get_presence(c_date)
        if p_presence and c_presence:
            # End of prof's last block on that day
            last_prof_end = max(block.end_time for block in c_presence)
            # Start of grader's first block on that day
            first_grader_start = min(block.start_time for block in p_presence)

            # Simple HH:MM comparison/gap
            p_h, p_m = map(int, last_prof_end.split(":"))
            g_h, g_m = map(int, first_grader_start.split(":"))
            gap_minutes = (g_h * 60 + g_m) - (p_h * 60 + p_m)

            # Penalize gaps: 0.1 pts per hour
            if gap_minutes > 0:
                wait_penalty = (gap_minutes / 60) * 0.1

    # SCORING:
    # - 1 Special Trip = 10 points
    # - Each turnaround day = 1 point
    # - Wait Time = 0.1 points per hour
    # - External workload penalty = grader.get_load()
    load_penalty = grader.get_load(p_date)
    return float(turnaround + (special_trips * 10) + load_penalty + wait_penalty)


def calculate_quiz_options(
    prof: Person,
    grader: Person,
    collection_dates: List[datetime],
    pickup_inputs: Optional[List[str]],
) -> List[ScheduleOption]:
    """
    Generate and rank all possible quiz collection/pickup schedules
    for a specific Professor and Grader pair, inclusive of external workload.
    """
    all_options = []

    # Handle pickup inputs
    if not pickup_inputs:
        pickup_offsets = list(range(11))
        pickup_absolute = []
    else:
        pickup_offsets = []
        pickup_absolute = []
        for p in pickup_inputs:
            try:
                pickup_offsets.append(int(p))
            except ValueError:
                try:
                    pickup_absolute.append(parse_date(p))
                except ValueError:
                    print(f"Warning: Could not parse pickup input '{p}'. Skipping.")

    for c_date in collection_dates:
        if not prof.is_on_campus(c_date):
            continue

        candidates = list(pickup_absolute)
        for offset in pickup_offsets:
            candidates.append(c_date + timedelta(days=offset))

        candidates = sorted(list(set(candidates)))

        for p_date in candidates:
            if p_date < c_date:
                continue

            penalty = _calculate_penalty(c_date, p_date, grader, prof)

            all_options.append(
                ScheduleOption(
                    collection_date=c_date,
                    pickup_date=p_date,
                    special_trips=1 if not grader.is_on_campus(p_date) else 0,
                    turnaround_days=(p_date - c_date).days,
                    total_penalty=penalty,
                )
            )

    all_options.sort(
        key=lambda x: (x.total_penalty, x.special_trips, x.turnaround_days)
    )
    return all_options


def calculate_convenience_heatmap(
    prof: Person,
    grader: Person,
    start_date: datetime,
    days: int = 14,
    pickup_inputs: Optional[List[str]] = None,
) -> List[Dict]:
    """
    Generate a convenience score for EVERY possible assignment day in a range.
    Useful for 'Flexible' assignment professors like Euler.
    """
    heatmap = []

    for i in range(days):
        current_date = start_date + timedelta(days=i)

        # We only care about days the Prof is actually teaching
        if not prof.is_on_campus(current_date):
            continue

        # Find the best possible pickup script for this specific day
        # By default, look for any pickup in the 0-10 window
        options = calculate_quiz_options(prof, grader, [current_date], pickup_inputs)

        if options:
            best_opt = options[0]
            heatmap.append(
                {
                    "date": current_date,
                    "score": best_opt.total_penalty,
                    "best_pickup": best_opt.pickup_date,
                    "is_on_campus": best_opt.special_trips == 0,
                }
            )

    heatmap.sort(key=lambda x: x["score"])
    return heatmap


def _check_day_alignment(dummy_date: datetime, grader: Person) -> bool:
    """Helper to check if a grader is on campus within a 3-5 day window."""
    for window in range(3, 6):
        pickup_day = dummy_date + timedelta(days=window)
        if grader.is_on_campus(pickup_day):
            return True
    return False


def _is_perfect_match(
    current_date: datetime, prof: Person, grader: Person, start_date: Optional[datetime]
) -> bool:
    """Determine if a specific day is a 'perfect match' for a pair."""
    if not prof.is_on_campus(current_date):
        return False

    if not _check_day_alignment(current_date, grader):
        return False

    # If start_date is set, factor in external workload
    if start_date:
        # We check the potential pickup window (3-5 days after)
        # to see if the grader is busy during those pickup days.
        # For simplicity, if load is >= 50, it's not a match.
        for window in range(3, 6):
            pickup_day = current_date + timedelta(days=window)
            if grader.get_load(pickup_day) >= 50:
                return False

    return True


def optimize_pairings(
    profs: List[Person],
    graders: List[Person],
    start_date: Optional[datetime] = None,
) -> List[dict]:
    """
    Match multiple professors to students based on schedule alignment.
    Returns a list of all potential pairings with scores.
    If start_date is provided, factors in external_load for a short-term match.
    """
    results = []

    # We look at a typical week (7 days) for alignment
    for prof in profs:
        for grader in graders:
            perfect_days = 0
            total_prof_days = 0

            # Check a standard week for overlap
            # 0=Monday to 6=Sunday
            for day_idx in range(7):
                if start_date:
                    current_date = start_date + timedelta(days=day_idx)
                else:
                    # Default to current week's Monday to avoid hardcoded dates
                    now = datetime.now()
                    current_date = (now - timedelta(days=now.weekday())) + timedelta(
                        days=day_idx
                    )

                if prof.is_on_campus(current_date):
                    total_prof_days += 1
                    # Specially track perfect matches
                    if _is_perfect_match(current_date, prof, grader, start_date):
                        perfect_days += 1

            compatibility = (
                (perfect_days / total_prof_days * 100) if total_prof_days > 0 else 0
            )

            results.append(
                {
                    "prof": prof.name,
                    "grader": grader.name,
                    "score": round(compatibility, 1),
                    "prof_days": total_prof_days,
                    "matching_windows": perfect_days,
                }
            )

    results.sort(key=lambda x: x["score"], reverse=True)
    return results


def global_matchmaking(
    profs: List[Person],
    graders: List[Person],
    capacity: int = 1,
    start_date: Optional[datetime] = None,
) -> List[dict]:
    """
    Solve for the global optimum score across the entire group.

    Args:
        profs: List of Professors with schedules.
        graders: List of Graders with schedules.
        capacity: Maximum professors one grader can support.
        start_date: Optional date to factor in short-term workload (external_load).

    Returns:
        List of match dictionaries containing prof, grader, and compatibility score.
    """
    all_pairs = optimize_pairings(profs, graders, start_date=start_date)
    final_matches = []

    assigned_profs = set()
    grader_counts = {g.name: 0 for g in graders}

    # --- GREEDY ALGORITHM IMPLEMENTATION ---
    # We iterate through the pre-sorted list of all possible pairings
    # (highest compatibility first) and aggressively assign them.
    for pair in all_pairs:
        if (
            pair["prof"] not in assigned_profs
            and grader_counts.get(pair["grader"], 0) < capacity
        ):
            final_matches.append(pair)
            assigned_profs.add(pair["prof"])
            grader_counts[pair["grader"]] = grader_counts.get(pair["grader"], 0) + 1

    return final_matches


def optimal_matchmaking(
    profs: List[Person],
    graders: List[Person],
    capacity: int = 1,
    start_date: Optional[datetime] = None,
) -> List[dict]:
    """
    Find global optimum score across entire group via Hungarian Algorithm (Scipy).

    Args:
        profs: List of Professors with schedules.
        graders: List of Graders with schedules.
        capacity: Maximum professors one grader can support.
        start_date: Optional date to factor in short-term workload (external_load).

    Returns:
        List of match dictionaries containing prof, grader, and compatibility score.
    """

    # pylint: disable=too-many-locals

    if not profs or not graders:
        return []

    # Check for scipy and Hungarian algo method (module import check/fallback)
    if linear_sum_assignment is None:
        print(
            "Warning: scipy is not installed. Falling back to greedy algorithm.\n"
            "To enable true optimal matchmaking, install scipy: pip install scipy"
        )
        return global_matchmaking(profs, graders, capacity, start_date=start_date)

    # Calculate all pairwise compatibility scores
    # Score matrix: rows = profs, cols = duplicated graders
    duplicated_graders = []
    for g in graders:
        for _ in range(capacity):
            duplicated_graders.append(g)

    # Determine cost matrix (we want to maximize score, so cost = 100 - score)
    cost_matrix = []

    # optimize_pairings gives us a flat list of scores
    all_pairs = optimize_pairings(profs, graders, start_date=start_date)

    # Build a lookup for quick access: (prof_name, grader_name) -> score
    score_lookup = {}
    prof_days_lookup = {}
    windows_lookup = {}
    for pair in all_pairs:
        score_lookup[(pair["prof"], pair["grader"])] = pair["score"]
        prof_days_lookup[(pair["prof"], pair["grader"])] = pair["prof_days"]
        windows_lookup[(pair["prof"], pair["grader"])] = pair["matching_windows"]

    for p in profs:
        row = []
        for g in duplicated_graders:
            score = score_lookup.get((p.name, g.name), 0)
            row.append(100.0 - score)
        cost_matrix.append(row)

    # Apply scipy's linear sum assignment (Hungarian algorithm)
    # The algorithm works even if matrix is rectangular
    row_ind, col_ind = linear_sum_assignment(cost_matrix)

    final_matches = []
    for r, c in zip(row_ind, col_ind):
        p = profs[r]
        g = duplicated_graders[c]
        score = score_lookup.get((p.name, g.name), 0)
        prof_days = prof_days_lookup.get((p.name, g.name), 0)
        windows = windows_lookup.get((p.name, g.name), 0)

        final_matches.append(
            {
                "prof": p.name,
                "grader": g.name,
                "score": score,
                "prof_days": prof_days,
                "matching_windows": windows,
            }
        )

    # Sort final matches to match global_matchmaking style
    final_matches.sort(key=lambda x: x["score"], reverse=True)
    return final_matches


def calculate_timeline(
    prof: Person,
    grader: Person,
    start_date: datetime,
    days: int = 14,
    pickup_inputs: Optional[List[str]] = None,
) -> List[ScheduleOption]:
    """
    Generate a chronological timeline of collection and pickup dates.
    Useful for providing guidance to graders on turnaround expectations.
    """
    timeline = []

    for i in range(days):
        current_date = start_date + timedelta(days=i)

        # We only care about days the Prof is actually teaching
        if not prof.is_on_campus(current_date):
            continue

        # Find the best possible pickup script for this specific day
        options = calculate_quiz_options(prof, grader, [current_date], pickup_inputs)

        if options:
            # Take the top-ranked (best) option for this day
            timeline.append(options[0])

    # No sorting needed as we iterate through dates chronologically,
    # but ensure it's absolute for robustness.
    timeline.sort(key=lambda x: x.collection_date)
    return timeline


def calculate_weekly_cadence(
    prof: Person,
    grader: Person,
    start_date: datetime,
    weeks: int = 16,
    pickup_inputs: Optional[List[str]] = None,
) -> dict:
    """
    Calculate the average penalty of collecting assignments on specific weekdays.
    Returns a dictionary mapping weekday name to its average penalty.
    """
    # pylint: disable=too-many-locals
    days = weeks * 7
    weekday_penalties = {i: [] for i in range(7)}
    weekday_names = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
    ]

    for i in range(days):
        current_date = start_date + timedelta(days=i)

        if not prof.is_on_campus(current_date):
            continue

        options = calculate_quiz_options(prof, grader, [current_date], pickup_inputs)
        if options:
            best_penalty = options[0].total_penalty
            weekday_penalties[current_date.weekday()].append(best_penalty)

    results = {}
    for w_idx in range(7):
        penalties = weekday_penalties[w_idx]
        if penalties:
            avg_penalty = sum(penalties) / len(penalties)
            results[weekday_names[w_idx]] = round(avg_penalty, 2)

    return results
