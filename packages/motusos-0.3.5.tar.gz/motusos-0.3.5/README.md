# Motus

> Motus is a local control plane for work.
> Define the work item. Attach proof as it happens. Close with a receipt you can trust.

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)
[![PyPI](https://img.shields.io/pypi/v/motusos)](https://pypi.org/project/motusos/)
[![Downloads](https://img.shields.io/pypi/dm/motusos)](https://pypi.org/project/motusos/)
[![Quality Gates](https://github.com/motus-os/motus/actions/workflows/quality-gates.yml/badge.svg)](https://github.com/motus-os/motus/actions/workflows/quality-gates.yml)

## What Motus Solves

Important work disappears into chat, tickets, logs, and memory.
Motus gives that work a bounded transaction path and a durable receipt.

## What Motus Is

Motus is the system that:

1. defines work as a bounded transaction,
2. records ownership with a lease,
3. attaches structured evidence,
4. closes with an explicit outcome,
5. preserves the result as durable work lineage.

## What Motus Is Not

Motus is not:

1. an orchestration app,
2. a replacement for Git, CI, N8N, ticketing, or ERP,
3. a cloud control tower.

## Install

```bash
pip install motusos
motus --help
```

## Day 1 (10 Minutes)

```bash
motus install
motus init --lite --path .
motus doctor
LEASE_ID=$(motus work claim ADHOC-DAY1-001 --intent "Day1 smoke" | awk -F': ' '/^Lease ID:/ {print $2}')
motus work evidence "$LEASE_ID" test_result --passed 1 --failed 0
motus work release "$LEASE_ID" success
```

Expected:
- `motus doctor` reports healthy.
- Work is claimed with a lease ID.
- Evidence is attached to that lease.
- Release returns a success receipt.

Why this loop exists:
- the work item is the atomic unit,
- the deterministic path is `claim -> evidence -> release`,
- `ADHOC-*` IDs are for solo/day-1 work,
- managed lanes use pre-registered work IDs.

## Learn More

- [Implementation Guide](docs/implementation/README.md)
- [Architecture](../../ARCHITECTURE.md)
- [CLI Reference](docs/cli-reference.md)
- [Docs Index](docs/README.md)

## Links

- PyPI: https://pypi.org/project/motusos/
- GitHub: https://github.com/motus-os/motus
- Contributing: ../../CONTRIBUTING.md
- Security Policy: ../../SECURITY.md

## License

Apache License 2.0. See LICENSE.
