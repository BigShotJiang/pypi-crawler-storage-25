import asyncio
import logging
from collections import deque
from dataclasses import dataclass, field
from inspect import isclass, iscoroutinefunction, isfunction
from typing import Dict, List, Optional, Set, Type, cast

from .components import (
    Component,
    ComponentIndex,
    ComponentPool,
    IComponentPool,
    TComponent,
)
from .constants import MAX_COMPONENTS
from .entities import Entity
from .exceptions import MaximumComponentsExceededError
from .query import get_queries_instance_from_arguments, get_signed_query_arguments
from .systems import System, SystemPipeline, SystemState
from .utils import Signature

logger = logging.getLogger(__name__)


@dataclass
class ResourceMarker:
    name: str
    index: int


@dataclass(slots=True)
class Registry:
    number_of_entities: int = 0
    number_of_systems: int = 0
    component_pools: List[Optional[IComponentPool]] = field(default_factory=list)
    systems: Dict[
        SystemPipeline,
        Dict[SystemState, Set[System]],
    ] = field(
        default_factory=lambda: {
            pipeline: {state: set()}
            for pipeline in SystemPipeline
            for state in SystemState
        }
    )
    queries: dict[System, List[object]] = field(default_factory=dict)
    resource_markers: dict[System, List[ResourceMarker]] = field(default_factory=dict)

    entity_component_signatures: List[Signature] = field(default_factory=list)

    entities_to_be_added: Set[Entity] = field(default_factory=set)
    entities_to_be_removed: Set[Entity] = field(default_factory=set)
    entities_to_be_synced_on_remove: Set[Entity] = field(default_factory=set)
    entities_to_be_synced_on_add: Set[Entity] = field(default_factory=set)

    free_entity_ids: deque[int] = field(default_factory=deque)

    resources: dict[str, object] = field(default_factory=dict)
    global_resources: dict[str, object] = field(default_factory=dict)

    def create_entity(self) -> Entity:

        if len(self.free_entity_ids) == 0:
            self.number_of_entities += 1
            entity_id = self.number_of_entities
            if entity_id >= len(self.entity_component_signatures):
                self.entity_component_signatures.extend([Signature(MAX_COMPONENTS)])
        else:
            entity_id = self.free_entity_ids.popleft()

        entity = Entity(entity_id, self)
        self.entities_to_be_added.add(entity)
        return entity

    # Component management
    def add_component(
        self,
        entity: Entity,
        component_type: Type[TComponent],
        component: TComponent,
        sync_queries: bool = False,
    ) -> None:
        if sync_queries:
            self.entities_to_be_synced_on_add.add(entity)

        entity_id = entity.get_id()
        component_id = ComponentIndex.get_id(component_type.__name__)

        if component_id >= len(self.component_pools):
            if component_id >= MAX_COMPONENTS:
                raise MaximumComponentsExceededError(MAX_COMPONENTS)
            new_size = component_id + 1
            self.component_pools.extend([None] * (new_size - len(self.component_pools)))

        if self.component_pools[component_id - 1] is None:
            self.component_pools[component_id - 1] = ComponentPool(component_type)

        component_pool = cast(
            ComponentPool[TComponent], self.component_pools[component_id - 1]
        )

        if entity_id >= len(component_pool):
            new_pool_size = max(entity_id + 1, len(component_pool) * 2)
            component_pool.extend([None] * (new_pool_size - len(component_pool)))

        component_pool.set(entity_id - 1, component)
        self.entity_component_signatures[entity_id - 1].set(component_id, True)

    def get_component(
        self,
        entity: Entity,
        component_type: Type[TComponent],
    ) -> Optional[TComponent]:
        entity_id: int = entity.get_id()
        component_id: int = ComponentIndex.get_id(component_type.__name__)
        if (
            component_id > len(self.component_pools)
            or self.component_pools[component_id - 1] is None
        ):
            return None

        component_pool: ComponentPool[TComponent] = cast(
            ComponentPool[TComponent], self.component_pools[component_id - 1]
        )
        return component_pool.get(entity_id - 1)

    def remove_component(
        self,
        entity: Entity,
        component_type: Type[TComponent],
    ) -> None:
        entity_id: int = entity.get_id()
        component_id: int = ComponentIndex.get_id(component_type.__name__)
        if component_id - 1 > len(self.component_pools):
            return

        component_pool = cast(
            ComponentPool[Component],
            self.component_pools[component_id - 1],
        )
        component_pool.set(entity.get_id() - 1, None)  # type: ignore

        self.entity_component_signatures[entity_id - 1].clear_bit(component_id)
        self.entities_to_be_synced_on_remove.add(entity)

    def has_component(
        self,
        entity: Entity,
        component_type: Type[TComponent],
    ) -> bool:
        entity_id: int = entity.get_id()
        component_id: int = ComponentIndex.get_id(component_type.__name__)
        return self.entity_component_signatures[entity_id - 1].test(component_id)

    def add_system(
        self, pipeline: SystemPipeline, state: SystemState, system: System
    ) -> None:
        arguments = get_signed_query_arguments(system)
        markers = self._extract_resource_markers(arguments)
        self.queries[system] = list(arguments.values())
        self.resource_markers[system] = markers
        for query in get_queries_instance_from_arguments(self.queries[system]):
            query.set_registry(self)

        if self.systems.get(pipeline) is None:
            self.systems[pipeline] = dict()
        if not isfunction(system):
            raise ValueError("System must be a function")

        self.systems[pipeline].setdefault(state, set()).add(system)
        self.number_of_systems += 1

    def _extract_resource_markers(
        self, arguments: dict[str, object]
    ) -> List[ResourceMarker]:
        markers: List[ResourceMarker] = []
        for idx, (key, value) in enumerate(arguments.items()):
            if isclass(value) and not issubclass(value, Component):
                resource_name = value.__name__
                if value.__module__ == "builtins":
                    continue
                markers.append(ResourceMarker(resource_name, idx))
                arguments[key] = None
        return markers

    def get_resource(self, resource_name: str) -> object | None:
        if resource_name in self.resources:
            return self.resources[resource_name]
        return self.global_resources.get(resource_name)

    def add_entity_to_systems(self, entity: Entity) -> None:
        self.sync_entity_queries(entity)

    def remove_entity_from_systems(self, entity: Entity) -> None:
        for arguments in self.queries.values():
            queries = get_queries_instance_from_arguments(arguments)
            for query in queries:
                query.remove_entity(entity)

    def sync_entity_queries(self, entity: Entity) -> None:
        entity_id = entity.get_id()
        component_signature = self.entity_component_signatures[entity_id - 1]
        for arguments in self.queries.values():
            affected_queries = get_queries_instance_from_arguments(arguments)
            for affected_query in affected_queries:
                if affected_query.matches(component_signature):
                    affected_query.add_entity(entity)
                else:
                    affected_query.remove_entity(entity)

    def kill_entity(self, entity: Entity) -> None:
        self.entities_to_be_removed.add(entity)

    def set_system_state(
        self, pipeline: SystemPipeline, system: System, state: SystemState
    ) -> None:
        prev_state = [
            state
            for state, systems in self.systems[pipeline].items()
            if system in systems
        ]
        if len(prev_state) == 0:
            raise ValueError(f"System {system} not found in pipeline {pipeline}")

        prev_state = prev_state[0]
        self.systems[pipeline][prev_state].remove(system)
        if not state in self.systems[pipeline]:
            self.systems[pipeline][state] = set()

        self.systems[pipeline][state].add(system)

    # Update
    def update(self) -> None:

        if self.entities_to_be_synced_on_add:
            for entity in self.entities_to_be_synced_on_add:
                self.sync_entity_queries(entity)
            self.entities_to_be_synced_on_add.clear()

        if self.entities_to_be_synced_on_remove:
            for entity in self.entities_to_be_synced_on_remove:
                self.sync_entity_queries(entity)
            self.entities_to_be_synced_on_remove.clear()

        if self.entities_to_be_added:
            for entity in self.entities_to_be_added:
                self.add_entity_to_systems(entity)
            self.entities_to_be_added.clear()

        if self.entities_to_be_removed:
            for entity in self.entities_to_be_removed:
                self.remove_entity_from_systems(entity)
                self.entity_component_signatures[entity.get_id() - 1].clear()
                self.free_entity_ids.append(entity.get_id())
            self.entities_to_be_removed.clear()

    def run(self, pipeline: SystemPipeline) -> None:
        pipeline_systems = self.systems.get(pipeline, {})
        for state, systems in pipeline_systems.items():
            if state == SystemState.OFF:
                continue

            for system in systems:
                args = self._resolve_system_args(system)
                if iscoroutinefunction(system):
                    asyncio.create_task(system(*args))
                    continue
                system(*args)

    def _resolve_system_args(self, system: System) -> List[object]:
        args = self.queries[system]
        markers = self.resource_markers.get(system, [])
        for marker in markers:
            args[marker.index] = self.get_resource(marker.name)
        return args
