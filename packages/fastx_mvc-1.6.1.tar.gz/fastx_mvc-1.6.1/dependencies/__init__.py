"""Application dependency modules."""

