import json
import mimetypes
import time
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Mapping, Optional, Sequence, Tuple, Union

import requests

from prodloop.exceptions import APIError, ValidationError
from prodloop.models import (
    BotLLMInput,
    EvaluationParameter,
    ParameterInput,
    SimulationMode,
    coerce_bot_llm,
    coerce_parameter,
)


class ProdloopClient:
    _SERVICE_URL = "https://asia-south1-prodloop.cloudfunctions.net/prodloop-evaluator-fn"

    def __init__(
        self,
        api_key: str,
        timeout_seconds: int = 1800,
        session: Optional[requests.Session] = None,
    ):
        if not api_key or not api_key.strip():
            raise ValidationError("api_key is required.")

        self.api_key = api_key.strip()
        self.timeout_seconds = timeout_seconds
        self._session = session or requests.Session()

    def evaluate_call(
        self,
        audio_file_path: str,
        parameters: Sequence[ParameterInput],
        thresholds: Optional[Mapping[str, Any]] = None,
        extraction_schema: Optional[Mapping[str, str]] = None,
        bot_captured_variables: Optional[Mapping[str, Any]] = None,
        input_prompt: Optional[str] = None,
        timeout_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        normalized_parameters = self._normalize_parameters(parameters)
        normalized_input_prompt = (input_prompt or "").strip()
        payload: Dict[str, Any] = {
            "parameters": [param.value for param in normalized_parameters],
        }

        if thresholds:
            payload["thresholds"] = dict(thresholds)
        if extraction_schema:
            payload["extraction_schema"] = dict(extraction_schema)
        if bot_captured_variables:
            payload["bot_captured_variables"] = dict(bot_captured_variables)
        if normalized_input_prompt:
            payload["input_prompt"] = normalized_input_prompt

        if EvaluationParameter.EXTRACTION_VARIABLES in normalized_parameters:
            if not extraction_schema:
                raise ValidationError(
                    "extraction_schema is required when using 'extraction_variables'."
                )
            if not bot_captured_variables:
                raise ValidationError(
                    "bot_captured_variables is required when using 'extraction_variables'."
                )
            missing_keys = [
                key for key in extraction_schema.keys() if key not in bot_captured_variables
            ]
            if missing_keys:
                raise ValidationError(
                    "bot_captured_variables is missing keys from extraction_schema: "
                    + ", ".join(missing_keys)
                )
        if EvaluationParameter.HALLUCINATION in normalized_parameters:
            if not normalized_input_prompt:
                raise ValidationError(
                    "input_prompt is required when using 'hallucination'."
                )

        audio_path = Path(audio_file_path)
        if not audio_path.exists():
            raise ValidationError(f"Audio file not found: {audio_file_path}")
        if not audio_path.is_file():
            raise ValidationError(f"Audio path is not a file: {audio_file_path}")

        request_timeout = timeout_seconds or self.timeout_seconds
        url = self._SERVICE_URL
        headers = {"Authorization": f"Bearer {self.api_key}"}
        mime_type = self._guess_mime_type(audio_path)

        with audio_path.open("rb") as audio_file:
            files = {
                "audio_file": (audio_path.name, audio_file, mime_type),
                "metadata": (None, json.dumps(payload), "application/json"),
            }
            response = self._session.post(
                url, headers=headers, files=files, timeout=request_timeout
            )

        self._raise_for_api_error(response)
        return self._safe_json(response)

    def simulate_prompt(
        self,
        prompt: str,
        parameters: Sequence[ParameterInput],
        bot_llm: Optional[BotLLMInput] = None,
        simulation_mode: Union[SimulationMode, str] = SimulationMode.SELF_SIMULATION,
        max_turns: int = 3,
        scenario: Optional[str] = None,
        bot_turn_handler: Optional[
            Callable[
                [str, Sequence[Mapping[str, Any]]],
                Union[str, Tuple[str, float], Mapping[str, Any]],
            ]
        ] = None,
        timeout_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        normalized_mode = self._normalize_simulation_mode(simulation_mode)
        normalized_parameters = self._normalize_simulation_parameters(parameters)
        normalized_prompt = (prompt or "").strip()
        if not normalized_prompt:
            raise ValidationError("prompt is required.")
        if max_turns < 1:
            raise ValidationError("max_turns must be at least 1.")
        if len(normalized_parameters) != 1:
            raise ValidationError(
                "Simulation currently supports exactly one parameter per run."
            )

        payload: Dict[str, Any] = {
            "simulation_mode": normalized_mode.value,
            "prompt": normalized_prompt,
            "parameters": list(normalized_parameters),
            "max_turns": int(max_turns),
        }
        if scenario and scenario.strip():
            payload["scenario"] = scenario.strip()

        if normalized_mode is SimulationMode.SELF_SIMULATION:
            normalized_bot_llm = coerce_bot_llm(bot_llm)
            if normalized_bot_llm is None:
                raise ValidationError("bot_llm is required for self_simulation.")
            payload["bot_llm"] = self._self_simulation_bot_payload(normalized_bot_llm)
            return self._post_json("/simulate/start", payload, timeout_seconds)

        if bot_turn_handler is None:
            raise ValidationError(
                "bot_turn_handler is required for user_orchestrated simulations."
            )
        start_response = self._post_json("/simulate/start", payload, timeout_seconds)
        return self._run_user_orchestrated_loop(
            start_response=start_response,
            bot_turn_handler=bot_turn_handler,
            timeout_seconds=timeout_seconds,
        )

    def _run_user_orchestrated_loop(
        self,
        start_response: Mapping[str, Any],
        bot_turn_handler: Callable[
            [str, Sequence[Mapping[str, Any]]],
            Union[str, Tuple[str, float], Mapping[str, Any]],
        ],
        timeout_seconds: Optional[int],
    ) -> Dict[str, Any]:
        chat_id = str(start_response.get("chat_id") or "").strip()
        if not chat_id:
            raise APIError(500, "Backend response missing chat_id.")

        current_response: Dict[str, Any] = dict(start_response)
        while current_response.get("status") != "completed":
            tester_message = str(current_response.get("tester_message") or "").strip()
            if not tester_message:
                raise APIError(500, "Backend response missing tester_message.")

            transcript = current_response.get("transcript") or []
            if not isinstance(transcript, list):
                raise APIError(500, "Backend transcript must be a list.")

            handler_start = time.perf_counter()
            handler_output = bot_turn_handler(tester_message, transcript)
            measured_handler_latency_ms = round((time.perf_counter() - handler_start) * 1000.0, 2)
            bot_response, bot_response_latency_ms = self._normalize_bot_turn_output(
                handler_output=handler_output,
                measured_handler_latency_ms=measured_handler_latency_ms,
            )

            current_response = self._post_json(
                "/simulate/turn",
                {
                    "chat_id": chat_id,
                    "bot_response": bot_response.strip(),
                    "bot_response_latency_ms": bot_response_latency_ms,
                },
                timeout_seconds,
            )

        return current_response

    def get_simulation(
        self,
        chat_id: str,
        timeout_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        normalized_chat_id = (chat_id or "").strip()
        if not normalized_chat_id:
            raise ValidationError("chat_id is required.")
        return self._get_json(f"/simulate/{normalized_chat_id}", timeout_seconds)

    def get_simulation_parameters(
        self,
        timeout_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        return self._get_json("/simulate/parameters", timeout_seconds)

    def get_credit_balance(
        self,
        timeout_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        return self._get_json("/credits", timeout_seconds)

    def get_credits_remaining(
        self,
        timeout_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        return self.get_credit_balance(timeout_seconds=timeout_seconds)

    def _post_json(
        self,
        path: str,
        payload: Mapping[str, Any],
        timeout_seconds: Optional[int],
    ) -> Dict[str, Any]:
        request_timeout = timeout_seconds or self.timeout_seconds
        url = f"{self._SERVICE_URL}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        response = self._session.post(
            url, headers=headers, json=dict(payload), timeout=request_timeout
        )
        self._raise_for_api_error(response)
        return self._safe_json(response)

    def _get_json(
        self,
        path: str,
        timeout_seconds: Optional[int],
    ) -> Dict[str, Any]:
        request_timeout = timeout_seconds or self.timeout_seconds
        url = f"{self._SERVICE_URL}{path}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = self._session.get(url, headers=headers, timeout=request_timeout)
        self._raise_for_api_error(response)
        return self._safe_json(response)

    @staticmethod
    def _self_simulation_bot_payload(bot_llm: Mapping[str, Any]) -> Dict[str, Any]:
        provider = str(bot_llm.get("provider", "")).strip()
        model = str(bot_llm.get("model", "")).strip()
        options = dict(bot_llm.get("options") or {})
        endpoint = dict(bot_llm.get("endpoint") or {})
        livekit_kwargs = dict(bot_llm.get("livekit_kwargs") or {})

        # Self simulation uses Prodloop-owned backend credentials. Keep only safe
        # user-selected model/options/routing config; strip local credentials.
        for secret_key in (
            "api_key",
            "api_secret",
            "azure_ad_token",
            "client_secret",
            "password",
            "token",
        ):
            livekit_kwargs.pop(secret_key, None)
        for backend_owned_key in ("project", "location", "vertex_project", "vertex_location"):
            endpoint.pop(backend_owned_key, None)
            livekit_kwargs.pop(backend_owned_key, None)

        return {
            "provider": provider,
            "model": model,
            "credentials": {},
            "endpoint": endpoint,
            "options": options,
            "livekit_kwargs": livekit_kwargs,
        }

    @staticmethod
    def _normalize_parameters(parameters: Iterable[ParameterInput]) -> Sequence[EvaluationParameter]:
        normalized = [coerce_parameter(param) for param in parameters]
        if not normalized:
            raise ValidationError("At least one evaluation parameter is required.")
        return normalized

    @staticmethod
    def _normalize_simulation_parameters(parameters: Iterable[ParameterInput]) -> Sequence[str]:
        normalized: list[str] = []
        for parameter in parameters:
            if isinstance(parameter, EvaluationParameter):
                value = parameter.value
            else:
                value = str(parameter or "").strip().lower()
            if value:
                normalized.append(value)
        if not normalized:
            raise ValidationError("At least one simulation parameter is required.")
        return normalized

    @staticmethod
    def _normalize_simulation_mode(value: Union[SimulationMode, str]) -> SimulationMode:
        if isinstance(value, SimulationMode):
            return value
        normalized = str(value).strip().lower()
        for mode in SimulationMode:
            if mode.value == normalized:
                return mode
        raise ValidationError(
            "Unsupported simulation_mode. Supported values: "
            + ", ".join(mode.value for mode in SimulationMode)
            + "."
        )

    @staticmethod
    def _guess_mime_type(audio_path: Path) -> str:
        guessed, _ = mimetypes.guess_type(str(audio_path))
        return guessed or "application/octet-stream"

    @staticmethod
    def _safe_json(response: requests.Response) -> Dict[str, Any]:
        try:
            payload = response.json()
        except ValueError as exc:
            raise APIError(response.status_code, "Backend returned non-JSON response.") from exc
        if not isinstance(payload, dict):
            raise APIError(response.status_code, "Backend response must be a JSON object.")
        return payload

    @staticmethod
    def _raise_for_api_error(response: requests.Response) -> None:
        if response.ok:
            return

        try:
            payload = response.json()
            message = payload.get("error") or payload.get("message") or str(payload)
        except ValueError:
            message = response.text or "Unknown backend error"

        raise APIError(response.status_code, message)

    @staticmethod
    def _normalize_bot_turn_output(
        handler_output: Any,
        measured_handler_latency_ms: float,
    ) -> Tuple[str, float]:
        if isinstance(handler_output, str):
            response_text = handler_output.strip()
            if not response_text:
                raise ValidationError("bot_turn_handler must return a non-empty string.")
            return response_text, measured_handler_latency_ms

        if isinstance(handler_output, tuple) and len(handler_output) == 2:
            response_raw, latency_raw = handler_output
            response_text = str(response_raw or "").strip()
            if not response_text:
                raise ValidationError("bot_turn_handler tuple must include a non-empty response.")
            try:
                latency_ms = float(latency_raw)
            except (TypeError, ValueError) as exc:
                raise ValidationError(
                    "bot_turn_handler tuple latency must be numeric."
                ) from exc
            if latency_ms < 0:
                raise ValidationError("bot_turn_handler tuple latency cannot be negative.")
            return response_text, round(latency_ms, 2)

        if isinstance(handler_output, Mapping):
            response_text = str(handler_output.get("response", "")).strip()
            if not response_text:
                raise ValidationError(
                    "bot_turn_handler mapping must include a non-empty 'response' field."
                )
            latency_raw = (
                handler_output.get("llm_processing_latency_ms")
                or handler_output.get("bot_response_latency_ms")
                or handler_output.get("latency_ms")
            )
            if latency_raw is None:
                return response_text, measured_handler_latency_ms
            try:
                latency_ms = float(latency_raw)
            except (TypeError, ValueError) as exc:
                raise ValidationError(
                    "bot_turn_handler mapping latency must be numeric."
                ) from exc
            if latency_ms < 0:
                raise ValidationError("bot_turn_handler mapping latency cannot be negative.")
            return response_text, round(latency_ms, 2)

        raise ValidationError(
            "bot_turn_handler must return either a string, "
            "(response, llm_latency_ms), or a mapping with response and latency."
        )

