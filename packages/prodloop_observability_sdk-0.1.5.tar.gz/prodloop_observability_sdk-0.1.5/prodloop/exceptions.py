class ProdloopError(Exception):
    """Base exception for SDK errors."""


class ValidationError(ProdloopError):
    """Raised when request inputs are invalid."""


class APIError(ProdloopError):
    """Raised when backend API returns an error response."""

    def __init__(self, status_code: int, message: str):
        super().__init__(f"Prodloop API error ({status_code}): {message}")
        self.status_code = status_code
        self.message = message
