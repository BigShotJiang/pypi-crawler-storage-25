from __future__ import annotations

from typing import Any, Dict


def compact(values: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in values.items() if value is not None}
