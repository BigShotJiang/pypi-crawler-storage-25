from __future__ import annotations

import time
import os
from typing import Any, Mapping, Optional, Sequence

from prodloop.models import BotLLMConnection
from prodloop.plugins._utils import compact


class LiteLLM(BotLLMConnection):
    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        timeout_seconds: Optional[float] = None,
        endpoint: Optional[Mapping[str, Any]] = None,
        options: Optional[Mapping[str, Any]] = None,
    ):
        merged_endpoint = dict(endpoint or {})
        if base_url is not None:
            merged_endpoint["base_url"] = base_url

        merged_options = dict(options or {})
        for key, value in {
            "temperature": temperature,
            "max_tokens": max_tokens,
            "timeout_seconds": timeout_seconds,
        }.items():
            if value is not None:
                merged_options[key] = value

        super().__init__(
            provider="litellm",
            model=model,
            credentials=compact({"api_key": api_key}),
            endpoint=compact(merged_endpoint),
            options=compact(merged_options),
        )

    def as_turn_handler(
        self,
        system_prompt: str,
    ) -> "LiteLLMBot":
        return LiteLLMBot(
            model=self.model,
            system_prompt=system_prompt,
            api_key=self.credentials.get("api_key"),
            base_url=self.endpoint.get("base_url"),
            endpoint=self.endpoint,
            options=self.options,
        )


class LiteLLMBot:
    def __init__(
        self,
        model: str,
        system_prompt: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        endpoint: Optional[Mapping[str, Any]] = None,
        options: Optional[Mapping[str, Any]] = None,
    ):
        self.model = model
        self.system_prompt = system_prompt
        self.api_key = api_key
        self.base_url = base_url
        self.endpoint = dict(endpoint or {})
        self.options = dict(options or {})

    def __call__(
        self,
        tester_message: str,
        transcript: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        from litellm import completion

        messages = self._messages(tester_message=tester_message, transcript=transcript)
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
        }
        for key in ("temperature", "max_tokens", "timeout_seconds"):
            value = self.options.get(key)
            if value is not None:
                kwargs["timeout" if key == "timeout_seconds" else key] = value
        if self.api_key:
            kwargs["api_key"] = self.api_key
        if self.base_url:
            kwargs["base_url"] = self.base_url
        kwargs.update(self._provider_kwargs())

        start = time.perf_counter()
        response = _completion_with_retry(completion, kwargs)
        latency_ms = round((time.perf_counter() - start) * 1000.0, 2)
        text = _response_text(response)
        if not text:
            raise RuntimeError("LiteLLM bot returned an empty response.")
        return {"response": text, "llm_processing_latency_ms": latency_ms}

    def _messages(
        self,
        tester_message: str,
        transcript: Sequence[Mapping[str, Any]],
    ) -> list[dict[str, str]]:
        messages = [{"role": "system", "content": self.system_prompt}]
        for item in transcript:
            content = str(item.get("content") or "").strip()
            if not content:
                continue
            raw_role = str(item.get("role") or "user").strip().lower()
            role = "assistant" if raw_role in {"bot", "assistant"} else "user"
            messages.append({"role": role, "content": content})
        messages.append({"role": "user", "content": tester_message})
        return messages

    def _provider_kwargs(self) -> dict[str, Any]:
        kwargs: dict[str, Any] = {}
        normalized_model = self.model.lower()
        if normalized_model.startswith("vertex_ai/"):
            _add(
                kwargs,
                "vertex_project",
                self.endpoint.get("project")
                or self.endpoint.get("vertex_project")
                or os.getenv("VERTEX_PROJECT")
                or os.getenv("GOOGLE_CLOUD_PROJECT"),
            )
            _add(
                kwargs,
                "vertex_location",
                self.endpoint.get("location")
                or self.endpoint.get("vertex_location")
                or os.getenv("VERTEX_LOCATION")
                or os.getenv("GOOGLE_CLOUD_LOCATION"),
            )
        if normalized_model.startswith("azure/"):
            _add(kwargs, "api_version", self.endpoint.get("api_version") or os.getenv("AZURE_API_VERSION"))
            _add(kwargs, "azure_ad_token", self.options.get("azure_ad_token") or os.getenv("AZURE_AD_TOKEN"))
        return kwargs


def prefixed_model(prefix: str, model: str) -> str:
    normalized = str(model or "").strip()
    if not normalized or "/" in normalized:
        return normalized
    return f"{prefix}/{normalized}"


def _response_text(response: Any) -> str:
    try:
        content = response.choices[0].message.content
    except (AttributeError, IndexError, KeyError, TypeError):
        return ""
    return content.strip() if isinstance(content, str) else ""


def _completion_with_retry(completion_fn: Any, kwargs: dict[str, Any]) -> Any:
    delays = (5, 10, 15)
    last_error: Exception | None = None
    for attempt in range(1, len(delays) + 2):
        try:
            return completion_fn(**kwargs)
        except Exception as exc:
            last_error = exc
            if attempt <= len(delays):
                time.sleep(delays[attempt - 1])
    assert last_error is not None
    raise last_error


def _add(kwargs: dict[str, Any], key: str, value: Any) -> None:
    if value not in (None, ""):
        kwargs[key] = value
