from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Union


class EvaluationParameter(str, Enum):
    E2E_RESPONSE_TIME = "e2e_response_time"
    TURN_BY_TURN_LATENCY = "turn_by_turn_latency"
    PAUSE_PROFILE = "pause_profile"
    AUDIO_ARTIFACTS = "audio_artifacts"
    HALLUCINATION = "hallucination"
    EXTRACTION_VARIABLES = "extraction_variables"
    INTERRUPTION_BEHAVIOR = "interruption_behavior"


ParameterInput = Union[EvaluationParameter, str]

SUPPORTED_PARAMETERS = tuple(param.value for param in EvaluationParameter)


class SimulationMode(str, Enum):
    SELF_SIMULATION = "self_simulation"
    USER_ORCHESTRATED = "user_orchestrated"


@dataclass(frozen=True)
class BotLLMConnection:
    provider: str
    model: str
    credentials: Mapping[str, Any] = field(default_factory=dict)
    endpoint: Mapping[str, Any] = field(default_factory=dict)
    options: Mapping[str, Any] = field(default_factory=dict)
    livekit_kwargs: Mapping[str, Any] = field(default_factory=dict)

    def to_payload(self) -> Dict[str, Any]:
        provider = self.provider.strip().lower()
        model = self.model.strip()
        if not provider:
            raise ValueError("bot_llm.provider is required.")
        if not model:
            raise ValueError("bot_llm.model is required.")

        payload = {
            "provider": provider,
            "model": model,
            "credentials": dict(self.credentials or {}),
            "endpoint": dict(self.endpoint or {}),
            "options": dict(self.options or {}),
        }
        if self.livekit_kwargs:
            payload["livekit_kwargs"] = dict(self.livekit_kwargs or {})
        return payload


BotLLMInput = Union[BotLLMConnection, Mapping[str, Any]]


def coerce_parameter(value: ParameterInput) -> EvaluationParameter:
    if isinstance(value, EvaluationParameter):
        return value

    normalized = str(value).strip().lower()
    for parameter in EvaluationParameter:
        if parameter.value == normalized:
            return parameter

    raise ValueError(
        f"Unsupported parameter '{value}'. Supported values: {', '.join(SUPPORTED_PARAMETERS)}."
    )


def coerce_bot_llm(value: Optional[BotLLMInput]) -> Optional[Dict[str, Any]]:
    if value is None:
        return None
    if isinstance(value, BotLLMConnection):
        return value.to_payload()
    if not isinstance(value, Mapping):
        raise ValueError("bot_llm must be a BotLLMConnection or mapping.")

    connection = BotLLMConnection(
        provider=str(value.get("provider", "")),
        model=str(value.get("model", "")),
        credentials=value.get("credentials") or {},
        endpoint=value.get("endpoint") or {},
        options=value.get("options") or {},
        livekit_kwargs=value.get("livekit_kwargs") or (value.get("livekit") or {}).get("kwargs", {}),
    )
    return connection.to_payload()
