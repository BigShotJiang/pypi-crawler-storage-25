"""VMware operations modules."""
