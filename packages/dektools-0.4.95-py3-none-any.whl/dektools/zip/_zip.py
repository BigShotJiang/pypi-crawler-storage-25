import os
import time
import shutil
from zipfile import ZipFile, ZipInfo


class ZipFilePlus(ZipFile):
    # https://stackoverflow.com/a/46837272/15543185
    ZIP_UNIX_SYSTEM = 3

    def _extract_member(self, member, targetpath, pwd):
        """Extract the ZipInfo object 'member' to a physical
           file on the path targetpath.
        """
        if not isinstance(member, ZipInfo):
            member = self.getinfo(member)

        # build the destination pathname, replacing
        # forward slashes to platform specific separators.
        arcname = member.filename.replace('/', os.path.sep)

        if os.path.altsep:
            arcname = arcname.replace(os.path.altsep, os.path.sep)
        # interpret absolute pathname as relative, remove drive letter or
        # UNC path, redundant separators, "." and ".." components.
        arcname = os.path.splitdrive(arcname)[1]
        invalid_path_parts = ('', os.path.curdir, os.path.pardir)
        arcname = os.path.sep.join(x for x in arcname.split(os.path.sep)
                                   if x not in invalid_path_parts)
        if os.path.sep == '\\':
            # filter illegal characters on Windows
            arcname = self._sanitize_windows_name(arcname, os.path.sep)

        targetpath = os.path.join(targetpath, arcname)
        targetpath = os.path.normpath(targetpath)

        # Create all upper directories if necessary.
        upperdirs = os.path.dirname(targetpath)
        if upperdirs and not os.path.exists(upperdirs):
            os.makedirs(upperdirs)

        if member.is_dir():
            if not os.path.isdir(targetpath):
                os.mkdir(targetpath)
            return targetpath

        with self.open(member, pwd=pwd) as source, \
                open(targetpath, "wb") as target:
            shutil.copyfileobj(source, target)

        self.set_member_attributes(targetpath, member)

        return targetpath

    @classmethod
    def set_member_attributes(cls, path, member):
        cls.utime(member, path)
        if member.create_system == cls.ZIP_UNIX_SYSTEM:
            unix_attributes = member.external_attr >> 16
            if unix_attributes:
                os.chmod(path, unix_attributes)

    @staticmethod
    def utime(zipinfo, targetpath):
        if not hasattr(os, 'utime'):
            return
        t = time.mktime(zipinfo.date_time + (0, 0, 0))
        os.utime(targetpath, (t, t))
