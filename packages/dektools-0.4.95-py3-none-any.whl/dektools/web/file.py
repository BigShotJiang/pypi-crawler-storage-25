import os
import codecs


def generate_root_index(root_path):
    if not os.path.isdir(root_path):
        return
    all_files = []
    for root, dirs, files in os.walk(root_path):
        for name in files:
            full_path = os.path.join(root, name)
            rel_path = os.path.relpath(full_path, root_path)
            rel_path = rel_path.replace(os.sep, '/')
            if rel_path != 'index.html':
                all_files.append(rel_path)
    links = [f'<div><a href="./{p}">{p}</a></div>' for p in sorted(all_files)]
    if not os.path.exists(os.path.join(root_path, 'index.html')):
        with codecs.open(os.path.join(root_path, 'index.html'), 'w', encoding='utf-8') as f:
            f.write('\n'.join(links))


def generate_recursive_index(root_path):
    if not os.path.isdir(root_path):
        return
    for root, dirs, files in os.walk(root_path):
        items = sorted(dirs + files)
        links = []
        if root != root_path:
            links.append('<div><a href="../index.html">..</a></div>')
        for item in items:
            if item == 'index.html':
                continue
            href = f"./{item}/index.html" if os.path.isdir(os.path.join(root, item)) else f"./{item}"
            links.append(f'<div><a href="{href}">{item}</a></div>')
        if not os.path.exists(os.path.join(root, 'index.html')):
            with codecs.open(os.path.join(root, 'index.html'), 'w', encoding='utf-8') as f:
                f.write('\n'.join(links))
