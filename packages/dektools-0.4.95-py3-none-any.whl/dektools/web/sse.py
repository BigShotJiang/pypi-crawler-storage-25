import time
import socketserver
from urllib.parse import urlparse, parse_qs
from http.server import HTTPServer, BaseHTTPRequestHandler


class ThreadingHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    """
    Enable multi-threading to handle multiple concurrent requests.
    This prevents the server from blocking during sleep or long bundle generations.
    """
    allow_reuse_address = True
    daemon_threads = True


class SSERequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # Parse URL and query parameters
        parsed_url = urlparse(self.path)
        query_params = parse_qs(parsed_url.query)

        # --- Handle Root Directory: Returns HTML for testing ---
        if parsed_url.path == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()

            html_content = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>SSE Stream vs Bundle Test</title>
                <style>
                    body { font-family: sans-serif; display: flex; gap: 20px; padding: 20px; }
                    .panel { border: 1px solid #ccc; padding: 15px; width: 45%; border-radius: 8px; }
                    .log { background: #f4f4f4; padding: 10px; height: 300px; overflow-y: auto; font-family: monospace; font-size: 12px; margin-top: 10px; }
                    .status { font-weight: bold; color: #007bff; }
                </style>
            </head>
            <body>
                <div class="panel">
                    <h2>1. Streaming Mode</h2>
                    <p>Receives messages one by one with a delay (0.5s).</p>
                    <button class="stream" onclick="startSSE('/stream?count=5&delay=0.5', 'stream-log')">Start Stream Test</button>
                    <div id="stream-log" class="log"></div>
                </div>

                <div class="panel">
                    <h2>2. Bundling Mode</h2>
                    <p>Receives all messages in a single batch.</p>
                    <button class="bundle" onclick="startSSE('/bundle?count=5', 'bundle-log')">Start Bundle Test</button>
                    <div id="bundle-log" class="log"></div>
                </div>

                <script>
                    function startSSE(url, logId) {
                        const logDiv = document.getElementById(logId);
                        logDiv.innerHTML = '<span class="status">Connecting...</span><br>';

                        const eventSource = new EventSource(url);

                        eventSource.onmessage = function(event) {
                            logDiv.innerHTML += 'Received: ' + event.data + '<br>';
                            logDiv.scrollTop = logDiv.scrollHeight;
                        };

                        eventSource.addEventListener('end', function(event) {
                            logDiv.innerHTML += '<span class="status">--- Stream Finished ---</span><br>';
                            eventSource.close();
                        });

                        eventSource.onerror = function() {
                            logDiv.innerHTML += '<span style="color:red">Connection closed or error occurred.</span><br>';
                            eventSource.close();
                        };
                    }
                </script>
            </body>
            </html>
            """
            self.wfile.write(html_content.encode('utf-8'))
            return

        # --- Handle SSE Endpoints (/stream and /bundle) ---
        if parsed_url.path in {'/stream', '/bundle'}:
            try:
                # Extract parameters: ?count=5&delay=0.5
                max_messages = int(query_params.get('count', [5])[0])
                delay = float(query_params.get('delay', [1.0])[0])
            except ValueError:
                self.send_error(400, "Invalid parameters")
                return

            # Set SSE Headers
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Cache-Control', 'no-cache, no-transform')
            self.send_header('Connection', 'keep-alive')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

            try:
                # Prepare all data chunks
                all_chunks = []
                for i in range(1, max_messages + 1):
                    # Using standard JSON format for the payload
                    payload = f'{{"msg_id": {i}, "status": "active"}}'
                    chunk = f"data: {payload}\n\n".encode('utf-8')
                    all_chunks.append(chunk)

                # Add final termination event
                all_chunks.append(b"event: end\ndata: stream finished\n\n")

                if parsed_url.path == '/stream':
                    # MODE: Streaming - Write and flush each chunk individually
                    for chunk in all_chunks:
                        self.wfile.write(chunk)
                        self.wfile.flush()
                        # Apply delay only between data chunks
                        if b"event: end" not in chunk:
                            time.sleep(delay)
                    print(f"[{self.client_address}] Streamed {max_messages} messages.")
                else:
                    # MODE: Bundling - Send all chunks in one go
                    full_response = b"".join(all_chunks)
                    self.wfile.write(full_response)
                    self.wfile.flush()
                    print(f"[{self.client_address}] Sent bundled response ({max_messages} messages).")

            except (ConnectionResetError, BrokenPipeError):
                print(f"[{self.client_address}] Client disconnected.")
            finally:
                self.close_connection = True
        else:
            self.send_error(404, "Not Found")


def run_sse_server(host=None, port=None):
    host = host or '127.0.0.1'
    port = port or 11551
    httpd = ThreadingHTTPServer((host, port), SSERequestHandler)

    print("-" * 60)
    print(f"Server is running:")
    print(f"  Web Dashboard: http://{host}:{port}/")
    print(f"  Direct Stream: http://{host}:{port}/stream?count=5&delay=0.5")
    print(f"  Direct Bundle: http://{host}:{port}/bundle?count=5")
    print("-" * 60)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopping...")
        httpd.server_close()


if __name__ == '__main__':
    run_sse_server()
