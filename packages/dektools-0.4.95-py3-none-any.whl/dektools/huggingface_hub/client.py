from huggingface_hub import hf_hub_download, snapshot_download


def hf_download(repo_id, filename=None, glob=None, local=None, revision=None, **kwargs):
    if glob or not filename:
        return snapshot_download(
            repo_id=repo_id,
            revision=revision,
            allow_patterns=glob,
            local_dir=local,
            **kwargs
        )
    else:
        return hf_hub_download(
            repo_id, filename,
            revision=revision,
            local_dir=local
        )
