import typer

app = typer.Typer(add_completion=False)


@app.command()
def root(path):
    from ..web.file import generate_root_index
    generate_root_index(path)


@app.command()
def each(path):
    from ..web.file import generate_recursive_index
    generate_recursive_index(path)


@app.command()
def sse(host: str = None, port: str = None):
    from ..web.sse import run_sse_server
    run_sse_server(host, port)
