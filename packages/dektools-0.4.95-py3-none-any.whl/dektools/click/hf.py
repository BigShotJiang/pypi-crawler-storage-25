import typer
from typing_extensions import Annotated

app = typer.Typer(add_completion=False)


@app.command()
def download(
        repo, path: Annotated[str, typer.Argument()] = "",
        glob: str = None, local: str = None, revision: str = None):
    from ..huggingface_hub.client import hf_download
    result = hf_download(
        repo, path,
        glob=glob or None, local=local or None, revision=revision or None)
    if not local:
        print(result, end='', flush=True)
