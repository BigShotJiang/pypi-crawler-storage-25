from ....common import cached_property


class InstructionBase:
    head = ''

    def __init__(self, instruction_set, key, value, value_raw):
        self.instruction_set = instruction_set
        self.key_raw = key
        self.value = value
        self.value_raw = value_raw

    @classmethod
    def recognize(cls, key):
        return cls.head == '' or key.startswith(cls.head)

    @cached_property
    def key(self):
        return self.key_raw[len(self.head):].strip()
