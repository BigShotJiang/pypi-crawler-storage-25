#!/usr/bin/env python3
"""Validate that all metrics are properly saved (no NULL or 0 where unexpected)"""

from src.database.db_manager import DatabaseManager

def validate_data():
    db = DatabaseManager()
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        
        # Check test_runs
        print("=" * 70)
        print("VALIDATING TEST RUNS")
        print("=" * 70)
        
        cursor.execute('''
            SELECT id, browser_name, duration_seconds, ai_enabled, query
            FROM test_runs
        ''')
        
        issues = []
        for row in cursor.fetchall():
            test_id, browser, duration, ai, query = row
            
            if duration is None or duration == 0:
                issues.append(f"Test {test_id}: duration is {duration}")
            if not query:
                issues.append(f"Test {test_id}: query is empty")
        
        if issues:
            print("ISSUES FOUND:")
            for issue in issues:
                print(f"  - {issue}")
        else:
            print("OK: All test runs have valid data")
        
        # Check system_metrics
        print("\n" + "=" * 70)
        print("VALIDATING SYSTEM METRICS")
        print("=" * 70)
        
        cursor.execute('''
            SELECT test_run_id, COUNT(*) as metric_count
            FROM system_metrics
            GROUP BY test_run_id
        ''')
        
        for row in cursor.fetchall():
            test_id, count = row
            if count < 5:
                print(f"WARNING: Test {test_id}: Only {count} metrics saved")
            else:
                print(f"OK: Test {test_id}: {count} metrics saved")
        
        # Check energy_calculations
        print("\n" + "=" * 70)
        print("VALIDATING ENERGY CALCULATIONS")
        print("=" * 70)
        
        cursor.execute('''
            SELECT test_run_id, estimated_energy_wh, cpu_power_watts, 
                   memory_power_watts, base_power_watts
            FROM energy_calculations
        ''')
        
        for row in cursor.fetchall():
            test_id, energy, cpu_w, mem_w, base_w = row
            
            issues = []
            if energy is None or energy == 0:
                issues.append("energy is 0/NULL")
            if cpu_w is None:
                issues.append("cpu_power is NULL")
            if mem_w is None:
                issues.append("memory_power is NULL")
            if base_w is None or base_w == 0:
                issues.append("base_power is 0/NULL")
            
            if issues:
                print(f"ERROR: Test {test_id}: {', '.join(issues)}")
            else:
                print(f"OK: Test {test_id}: Energy={energy:.3f} Wh, CPU={cpu_w:.2f}W, Mem={mem_w:.3f}W, Base={base_w}W")
        
        # Check privacy_security_metrics
        print("\n" + "=" * 70)
        print("VALIDATING PRIVACY/SECURITY METRICS")
        print("=" * 70)
        
        cursor.execute('''
            SELECT test_run_id, https_enabled, cookie_count, tracker_count
            FROM privacy_security_metrics
        ''')
        
        rows = cursor.fetchall()
        if not rows:
            print("WARNING: No privacy/security metrics found")
        else:
            for row in rows:
                test_id, https, cookies, trackers = row
                print(f"OK: Test {test_id}: HTTPS={https}, Cookies={cookies}, Trackers={trackers}")
        
        # Summary
        print("\n" + "=" * 70)
        print("SUMMARY")
        print("=" * 70)
        
        cursor.execute('SELECT COUNT(*) FROM test_runs')
        total_tests = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT test_run_id) FROM system_metrics')
        tests_with_metrics = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT test_run_id) FROM energy_calculations')
        tests_with_energy = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT test_run_id) FROM privacy_security_metrics')
        tests_with_privacy = cursor.fetchone()[0]
        
        print(f"Total tests:                  {total_tests}")
        print(f"Tests with system metrics:    {tests_with_metrics}/{total_tests}")
        print(f"Tests with energy data:       {tests_with_energy}/{total_tests}")
        print(f"Tests with privacy metrics:   {tests_with_privacy}/{total_tests}")
        
        if total_tests == tests_with_metrics == tests_with_energy:
            print("\nRESULT: All data properly saved.")
        else:
            print("\nRESULT: Some data is missing.")

if __name__ == '__main__':
    validate_data()
