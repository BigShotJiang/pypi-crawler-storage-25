#!/bin/bash
# SafeWeb CLI Installation Test

echo "SafeWeb CLI - Installation Test"
echo "===================================="
echo ""

# Check Python version
echo "1. Checking Python version..."
python3 --version
if [ $? -ne 0 ]; then
    echo "ERROR: Python 3 not found. Please install Python 3.8+"
    exit 1
fi
echo "OK: Python found"
echo ""

# Check if in correct directory
if [ ! -f "safeweb.py" ]; then
    echo "ERROR: Please run this from the safeweb-cli directory"
    exit 1
fi

# Check safeweb_run.sh is executable
echo "2. Checking safeweb_run.sh..."
if [ ! -f "safeweb_run.sh" ]; then
    echo "ERROR: safeweb_run.sh not found"
    exit 1
fi
chmod +x safeweb_run.sh
echo "OK: safeweb_run.sh found and executable"
echo ""

# Test browser detection (also triggers first-run setup if needed)
echo "3. Detecting installed browsers..."
./safeweb_run.sh list
echo ""

# Test dry run
echo "4. Testing dry run..."
./safeweb_run.sh run-tests --dry-run
echo ""

echo "===================================="
echo "Installation test complete!"
echo ""
echo "Next steps:"
echo "  ./safeweb_run.sh run-tests -b chrome -t 1    # Quick test"
echo "  ./safeweb_run.sh analyze                      # View results"
echo ""
