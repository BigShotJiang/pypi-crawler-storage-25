"""
Working 2captcha.com solver for Google reCAPTCHA v2 Enterprise
Specifically handles Google's /sorry/index CAPTCHA page.

Google's sorry page uses reCAPTCHA Enterprise with:
  - Form id="captcha-form", method="post", action="/sorry/index"
  - Hidden fields: q, continue
  - Textarea: g-recaptcha-response
  - data-callback="submitCallback" on the .g-recaptcha div
  - data-s="..." dynamic token on the .g-recaptcha div (CRITICAL for Google)
  - reCAPTCHA Enterprise iframe at /recaptcha/enterprise/anchor

Flow:
  1. Extract site key + data-s from the page
  2. Send to 2captcha with enterprise=1 AND data-s
  3. Inject the token into the g-recaptcha-response textarea
  4. Call window.submitCallback(token) which triggers form.submit()
"""

import time
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class WorkingCaptchaSolver:
    def __init__(self, api_key):
        self.api_key = api_key
        self.solver = None

        if api_key:
            try:
                from twocaptcha import TwoCaptcha
                self.solver = TwoCaptcha(api_key)
                balance = self.solver.balance()
                print(f"✅ 2captcha initialized (Balance: ${balance})")
            except Exception as e:
                print(f"❌ 2captcha init failed: {e}")

    def solve_google_recaptcha(self, driver, max_attempts=2):
        """Solve Google reCAPTCHA Enterprise on /sorry/index page"""
        if not self.solver:
            print("❌ No 2captcha solver available")
            return False

        for attempt in range(1, max_attempts + 1):
            try:
                current_url = driver.current_url
                print(f"\n{'='*60}")
                print(f"🔍 CAPTCHA solve attempt {attempt}/{max_attempts}")
                print(f"   URL: {current_url}")

                # Detect Enterprise vs regular
                is_enterprise = self._is_enterprise(driver)

                # Extract site key
                site_key = self._extract_site_key(driver)
                if not site_key:
                    print("❌ No reCAPTCHA site key found")
                    return False

                # Extract data-s (CRITICAL for Google pages)
                data_s = self._extract_data_s(driver)

                # Extract callback name
                named_callback = self._get_named_callback(driver)

                # Extract user agent from the browser
                user_agent = driver.execute_script("return navigator.userAgent")

                print(f"   Enterprise: {is_enterprise}")
                print(f"🔑 Site key: {site_key}")
                print(f"🔐 data-s: {'Yes (' + data_s[:30] + '...)' if data_s else 'Not found'}")
                print(f"📞 Callback: {named_callback or '(none)'}")
                print(f"⏳ Sending to 2captcha.com (expect 20-120s)...")

                # Build solve params
                start = time.time()
                solve_kwargs = {}

                if is_enterprise:
                    solve_kwargs['enterprise'] = 1

                if data_s:
                    # The 2captcha Python lib uses **kwargs, so we can pass data-s
                    # The API expects the field name 'data-s'
                    solve_kwargs['data-s'] = data_s

                if user_agent:
                    solve_kwargs['userAgent'] = user_agent

                result = self.solver.recaptcha(
                    sitekey=site_key,
                    url=current_url,
                    **solve_kwargs
                )

                elapsed = time.time() - start
                token = result['code']

                print(f"✅ Solution received in {elapsed:.1f}s")
                print(f"🎫 Token (first 50 chars): {token[:50]}...")

                # Inject token and submit
                if self._inject_and_submit(driver, token, named_callback):
                    # Verify we left the CAPTCHA page
                    time.sleep(5)
                    new_url = driver.current_url
                    page_text = driver.page_source.lower()[:2000]

                    if 'sorry' not in new_url and 'captcha' not in page_text:
                        print(f"✅ CAPTCHA solved! Now at: {new_url}")
                        return True
                    else:
                        print(f"⚠️  Still on CAPTCHA page after attempt {attempt}")

                        # For retry: reload the page to get a fresh data-s
                        if attempt < max_attempts:
                            print("   Reloading page for fresh data-s token...")
                            driver.refresh()
                            time.sleep(3)
                            continue
                else:
                    print(f"❌ Injection/submission failed on attempt {attempt}")

            except Exception as e:
                print(f"❌ CAPTCHA solving error (attempt {attempt}): {e}")
                if attempt < max_attempts:
                    time.sleep(2)

        print("❌ All CAPTCHA solve attempts exhausted")
        return False

    # ──────────────────────────────────────────────────────────
    #  Detection helpers
    # ──────────────────────────────────────────────────────────

    def _is_enterprise(self, driver):
        """Detect if the page uses reCAPTCHA Enterprise"""
        try:
            iframes = driver.find_elements(By.TAG_NAME, "iframe")
            for iframe in iframes:
                src = iframe.get_attribute("src") or ""
                if "recaptcha/enterprise" in src:
                    return True
            page = driver.page_source
            if "recaptcha/enterprise" in page or "grecaptcha.enterprise" in page:
                return True
        except Exception:
            pass
        return False

    def _get_named_callback(self, driver):
        """Get the data-callback attribute from the .g-recaptcha div"""
        try:
            el = driver.find_element(By.CSS_SELECTOR, "[data-callback]")
            return el.get_attribute("data-callback")
        except Exception:
            pass
        return None

    def _extract_data_s(self, driver):
        """Extract data-s parameter from the reCAPTCHA div (Google-specific)"""
        # Method 1: From .g-recaptcha div
        try:
            el = driver.find_element(By.CSS_SELECTOR, ".g-recaptcha[data-s]")
            val = el.get_attribute("data-s")
            if val and len(val) > 10:
                return val
        except Exception:
            pass

        # Method 2: From any element with data-s
        try:
            el = driver.find_element(By.CSS_SELECTOR, "[data-s]")
            val = el.get_attribute("data-s")
            if val and len(val) > 10:
                return val
        except Exception:
            pass

        # Method 3: From page source via regex
        try:
            page = driver.page_source
            m = re.search(r'data-s=["\']([^"\']{20,})["\']', page)
            if m:
                return m.group(1)
        except Exception:
            pass

        return None

    # ──────────────────────────────────────────────────────────
    #  Site key extraction
    # ──────────────────────────────────────────────────────────

    def _extract_site_key(self, driver):
        """Extract reCAPTCHA site key"""

        # Strategy 1: data-sitekey attribute
        try:
            el = driver.find_element(By.CSS_SELECTOR, "[data-sitekey]")
            key = el.get_attribute("data-sitekey")
            if key and len(key) > 20:
                return key
        except Exception:
            pass

        # Strategy 2: From iframe src
        try:
            iframes = driver.find_elements(By.TAG_NAME, "iframe")
            for iframe in iframes:
                src = iframe.get_attribute("src") or ""
                if "recaptcha" in src and "k=" in src:
                    key = src.split("k=")[1].split("&")[0]
                    if len(key) > 20:
                        return key
        except Exception:
            pass

        # Strategy 3: Regex
        try:
            page = driver.page_source
            patterns = [
                r'data-sitekey=["\']([A-Za-z0-9_-]{40})["\']',
                r'[?&]k=([A-Za-z0-9_-]{40})',
            ]
            for pat in patterns:
                m = re.search(pat, page)
                if m:
                    return m.group(1)
        except Exception:
            pass

        return None

    # ──────────────────────────────────────────────────────────
    #  Token injection + form submission
    # ──────────────────────────────────────────────────────────

    def _inject_and_submit(self, driver, token, named_callback=None):
        """Inject the solved token and submit the CAPTCHA form"""
        try:
            # ── 1. Fill the g-recaptcha-response textarea ──
            print("📝 Step 1: Injecting token into g-recaptcha-response...")
            injected = driver.execute_script(f"""
                var count = 0;
                var el = document.getElementById('g-recaptcha-response');
                if (el) {{
                    el.innerHTML = '{token}';
                    el.value = '{token}';
                    count++;
                }}
                var els = document.getElementsByName('g-recaptcha-response');
                for (var i = 0; i < els.length; i++) {{
                    els[i].innerHTML = '{token}';
                    els[i].value = '{token}';
                    count++;
                }}
                return count;
            """)
            print(f"   ✅ Token injected into {injected} element(s)")

            time.sleep(0.5)

            # ── 2. Call the named callback (e.g. "submitCallback") ──
            # On Google's /sorry page, submitCallback = function(response) { form.submit(); }
            # So calling it will automatically submit the form
            submitted = False

            if named_callback:
                print(f"📝 Step 2: Calling {named_callback}(token)...")
                try:
                    result = driver.execute_script(f"""
                        if (typeof window['{named_callback}'] === 'function') {{
                            window['{named_callback}']('{token}');
                            return true;
                        }}
                        return false;
                    """)
                    if result:
                        print(f"   ✅ {named_callback}() called — form should auto-submit")
                        submitted = True
                except Exception as e:
                    print(f"   ⚠️  Callback failed: {e}")

            # ── 3. If callback didn't submit, try manual form submission ──
            if not submitted:
                print("📝 Step 3: Manual form submission...")
                try:
                    driver.execute_script(f"""
                        var form = document.getElementById('captcha-form');
                        if (!form) form = document.getElementsByTagName('form')[0];
                        if (form) {{
                            var textarea = form.querySelector('[name=g-recaptcha-response]');
                            if (textarea) textarea.value = '{token}';
                            form.submit();
                        }}
                    """)
                    print("   ✅ Form submitted manually")
                except Exception as e:
                    print(f"   ⚠️  Manual submission failed: {e}")

            # Wait for redirect
            time.sleep(5)
            return True

        except Exception as e:
            print(f"❌ Token injection/submission error: {e}")
            return False
