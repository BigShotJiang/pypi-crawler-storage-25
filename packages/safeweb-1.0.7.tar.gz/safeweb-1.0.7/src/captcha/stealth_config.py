"""
Stealth Browser Configuration
Reduces CAPTCHA triggers by making automation less detectable
"""

def get_stealth_chrome_options():
    """Get Chrome options for stealth browsing"""
    from selenium.webdriver.chrome.options import Options
    
    options = Options()
    
    # Basic stealth settings
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    
    # User agent rotation
    user_agents = [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ]
    
    import random
    options.add_argument(f"--user-agent={random.choice(user_agents)}")
    
    # Additional stealth
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-plugins")
    options.add_argument("--disable-images")  # Faster loading
    options.add_argument("--window-size=1920,1080")
    
    return options

def get_stealth_firefox_options():
    """Get Firefox options for stealth browsing"""
    from selenium.webdriver.firefox.options import Options
    
    options = Options()
    
    # Core stealth settings
    options.set_preference("dom.webdriver.enabled", False)
    options.set_preference("useAutomationExtension", False)
    options.set_preference("marionette.enabled", False)
    
    # User agent
    options.set_preference("general.useragent.override", 
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:120.0) Gecko/20100101 Firefox/120.0")
    
    # Privacy settings to avoid detection
    options.set_preference("privacy.trackingprotection.enabled", False)
    options.set_preference("privacy.resistFingerprinting", False)
    
    # Disable automation detection
    options.set_preference("devtools.console.stdout.content", False)
    options.set_preference("browser.cache.disk.enable", True)
    options.set_preference("browser.cache.memory.enable", True)
    
    # Add random delays to appear human
    options.set_preference("network.http.pipelining", True)
    options.set_preference("network.http.proxy.pipelining", True)
    
    # Window size
    options.add_argument("--width=1920")
    options.add_argument("--height=1080")
    
    return options

def apply_stealth_script(driver):
    """Apply JavaScript stealth modifications"""
    stealth_script = """
    // Remove webdriver property
    Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
    });
    
    // Mock plugins
    Object.defineProperty(navigator, 'plugins', {
        get: () => [1, 2, 3, 4, 5],
    });
    
    // Mock languages
    Object.defineProperty(navigator, 'languages', {
        get: () => ['en-US', 'en'],
    });
    
    // Mock permissions
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (parameters) => (
        parameters.name === 'notifications' ?
            Promise.resolve({ state: Notification.permission }) :
            originalQuery(parameters)
    );
    """
    
    try:
        driver.execute_script(stealth_script)
    except Exception as e:
        print(f"Stealth script application failed: {e}")