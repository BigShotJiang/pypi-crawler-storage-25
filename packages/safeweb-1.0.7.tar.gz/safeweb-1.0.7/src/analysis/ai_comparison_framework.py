#!/usr/bin/env python3
"""
AI vs Non-AI Comparison Framework - Week 3
Systematic comparison and cost breakdown analysis
"""

import sqlite3
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
import logging
from datetime import datetime
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from config import DATABASE_PATH

class AIComparisonFramework:
    def __init__(self, db_path=None):
        self.db_path = str(db_path) if db_path else str(DATABASE_PATH)
        self.logger = logging.getLogger(__name__)

    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)

    def get_ai_vs_regular_data(self) -> pd.DataFrame:
        """Retrieve AI vs regular test data"""
        conn = self.get_connection()
        
        query = """
        SELECT 
            tr.id,
            tr.browser_name,
            tr.search_engine,
            CASE WHEN tr.ai_enabled = 1 THEN 'ai_enabled' ELSE 'regular' END as test_type,
            tr.query,
            tr.duration_seconds,
            tr.timestamp,
            sm.value as cpu_percent,
            sm2.value as memory_percent,
            sm3.value as network_bytes_sent,
            sm4.value as network_bytes_recv,
            ec.estimated_energy_wh,
            ad.ai_features_detected,
            ad.ai_indicators_found
        FROM test_runs tr
        LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id AND sm.metric_type = 'cpu_percent'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'memory_percent'
        LEFT JOIN system_metrics sm3 ON tr.id = sm3.test_run_id AND sm3.metric_type = 'network_bytes_sent'
        LEFT JOIN system_metrics sm4 ON tr.id = sm4.test_run_id AND sm4.metric_type = 'network_bytes_recv'
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        LEFT JOIN ai_detection ad ON tr.id = ad.test_run_id
        WHERE tr.status = 'completed'
        ORDER BY tr.browser_name, tr.search_engine, tr.ai_enabled
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        # Add calculated fields
        df['total_network_bytes'] = df['network_bytes_sent'].fillna(0) + df['network_bytes_recv'].fillna(0)
        df['ai_actually_detected'] = df['ai_features_detected'].fillna('').str.len() > 0
        
        return df

    def compare_performance_metrics(self) -> Dict:
        """Compare performance metrics between AI and regular searches"""
        df = self.get_ai_vs_regular_data()
        
        comparison = {}
        
        # Group by test type
        for test_type in ['ai_enabled', 'regular']:
            type_data = df[df['test_type'] == test_type]
            
            if len(type_data) == 0:
                continue
            
            comparison[test_type] = {
                'duration_seconds': {
                    'mean': type_data['duration_seconds'].mean(),
                    'median': type_data['duration_seconds'].median(),
                    'std': type_data['duration_seconds'].std(),
                    'min': type_data['duration_seconds'].min(),
                    'max': type_data['duration_seconds'].max()
                },
                'cpu_usage': {
                    'mean': type_data['cpu_percent'].mean(),
                    'median': type_data['cpu_percent'].median(),
                    'std': type_data['cpu_percent'].std()
                },
                'memory_usage': {
                    'mean': type_data['memory_percent'].mean(),
                    'median': type_data['memory_percent'].median(),
                    'std': type_data['memory_percent'].std()
                },
                'network_usage': {
                    'mean': type_data['total_network_bytes'].mean(),
                    'median': type_data['total_network_bytes'].median(),
                    'std': type_data['total_network_bytes'].std()
                },
                'energy_consumption': {
                    'mean': type_data['energy_consumption'].mean(),
                    'median': type_data['energy_consumption'].median(),
                    'std': type_data['energy_consumption'].std()
                },
                'test_count': len(type_data)
            }
        
        # Calculate percentage differences
        if 'ai_enabled' in comparison and 'regular' in comparison:
            comparison['performance_impact'] = {
                'duration_seconds_increase_percent': ((comparison['ai_enabled']['duration_seconds']['mean'] - 
                                             comparison['regular']['duration_seconds']['mean']) / 
                                            comparison['regular']['duration_seconds']['mean']) * 100,
                'cpu_increase_percent': ((comparison['ai_enabled']['cpu_usage']['mean'] - 
                                        comparison['regular']['cpu_usage']['mean']) / 
                                       comparison['regular']['cpu_usage']['mean']) * 100,
                'memory_increase_percent': ((comparison['ai_enabled']['memory_usage']['mean'] - 
                                           comparison['regular']['memory_usage']['mean']) / 
                                          comparison['regular']['memory_usage']['mean']) * 100,
                'energy_increase_percent': ((comparison['ai_enabled']['energy_consumption']['mean'] - 
                                           comparison['regular']['energy_consumption']['mean']) / 
                                          comparison['regular']['energy_consumption']['mean']) * 100
            }
        
        return comparison

    def analyze_ai_detection_effectiveness(self) -> Dict:
        """Analyze AI detection rates and effectiveness"""
        df = self.get_ai_vs_regular_data()
        
        # AI-enabled tests only
        ai_tests = df[df['test_type'] == 'ai_enabled']
        
        if len(ai_tests) == 0:
            return {'error': 'No AI-enabled tests found'}
        
        # Detection rates by search engine
        detection_by_engine = {}
        for engine in ai_tests['search_engine'].unique():
            engine_data = ai_tests[ai_tests['search_engine'] == engine]
            detected_count = len(engine_data[engine_data['ai_actually_detected'] == True])
            total_count = len(engine_data)
            
            detection_by_engine[engine] = {
                'total_tests': total_count,
                'ai_detected': detected_count,
                'detection_rate_percent': (detected_count / total_count) * 100 if total_count > 0 else 0
            }
        
        # Detection rates by browser
        detection_by_browser = {}
        for browser in ai_tests['browser_name'].unique():
            browser_data = ai_tests[ai_tests['browser_name'] == browser]
            detected_count = len(browser_data[browser_data['ai_actually_detected'] == True])
            total_count = len(browser_data)
            
            detection_by_browser[browser] = {
                'total_tests': total_count,
                'ai_detected': detected_count,
                'detection_rate_percent': (detected_count / total_count) * 100 if total_count > 0 else 0
            }
        
        # Overall detection rate
        total_ai_tests = len(ai_tests)
        total_detected = len(ai_tests[ai_tests['ai_actually_detected'] == True])
        overall_detection_rate = (total_detected / total_ai_tests) * 100 if total_ai_tests > 0 else 0
        
        return {
            'overall_detection_rate': overall_detection_rate,
            'total_ai_tests': total_ai_tests,
            'total_detected': total_detected,
            'detection_by_search_engine': detection_by_engine,
            'detection_by_browser': detection_by_browser
        }

    def calculate_cost_breakdown(self) -> Dict:
        """Calculate detailed cost breakdown for AI vs regular searches"""
        df = self.get_ai_vs_regular_data()
        
        # Cost factors (arbitrary units for comparison)
        cost_factors = {
            'cpu_cost_per_percent_second': 0.001,
            'memory_cost_per_percent_second': 0.0005,
            'network_cost_per_mb': 0.01,
            'energy_cost_per_wh': 0.12,
            'time_cost_per_second': 0.02
        }
        
        cost_breakdown = {}
        
        for test_type in ['ai_enabled', 'regular']:
            type_data = df[df['test_type'] == test_type]
            
            if len(type_data) == 0:
                continue
            
            # Calculate costs per test
            cpu_costs = (type_data['cpu_percent'] * type_data['duration_seconds'] * 
                        cost_factors['cpu_cost_per_percent_second'])
            
            memory_costs = (type_data['memory_percent'] * type_data['duration_seconds'] * 
                           cost_factors['memory_cost_per_percent_second'])
            
            network_costs = (type_data['total_network_bytes'] / (1024*1024) * 
                            cost_factors['network_cost_per_mb'])
            
            energy_costs = (type_data['energy_consumption'] * 
                           cost_factors['energy_cost_per_wh'])
            
            time_costs = (type_data['duration_seconds'] * 
                         cost_factors['time_cost_per_second'])
            
            total_costs = cpu_costs + memory_costs + network_costs + energy_costs + time_costs
            
            cost_breakdown[test_type] = {
                'avg_cpu_cost': cpu_costs.mean(),
                'avg_memory_cost': memory_costs.mean(),
                'avg_network_cost': network_costs.mean(),
                'avg_energy_cost': energy_costs.mean(),
                'avg_time_cost': time_costs.mean(),
                'avg_total_cost': total_costs.mean(),
                'cost_distribution': {
                    'cpu_percent': (cpu_costs.mean() / total_costs.mean()) * 100,
                    'memory_percent': (memory_costs.mean() / total_costs.mean()) * 100,
                    'network_percent': (network_costs.mean() / total_costs.mean()) * 100,
                    'energy_percent': (energy_costs.mean() / total_costs.mean()) * 100,
                    'time_percent': (time_costs.mean() / total_costs.mean()) * 100
                }
            }
        
        # Calculate cost increase for AI
        if 'ai_enabled' in cost_breakdown and 'regular' in cost_breakdown:
            ai_cost = cost_breakdown['ai_enabled']['avg_total_cost']
            regular_cost = cost_breakdown['regular']['avg_total_cost']
            
            cost_breakdown['ai_cost_impact'] = {
                'absolute_increase': ai_cost - regular_cost,
                'percentage_increase': ((ai_cost - regular_cost) / regular_cost) * 100,
                'cost_multiplier': ai_cost / regular_cost
            }
        
        return cost_breakdown

    def generate_browser_engine_matrix(self) -> Dict:
        """Generate performance matrix for all browser-search engine combinations"""
        df = self.get_ai_vs_regular_data()
        
        matrix = {}
        
        for browser in df['browser_name'].unique():
            matrix[browser] = {}
            
            for engine in df['search_engine'].unique():
                combination_data = df[(df['browser_name'] == browser) & (df['search_engine'] == engine)]
                
                if len(combination_data) == 0:
                    continue
                
                ai_data = combination_data[combination_data['test_type'] == 'ai_enabled']
                regular_data = combination_data[combination_data['test_type'] == 'regular']
                
                matrix[browser][engine] = {
                    'ai_tests': len(ai_data),
                    'regular_tests': len(regular_data),
                    'ai_avg_duration_seconds': ai_data['duration_seconds'].mean() if len(ai_data) > 0 else 0,
                    'regular_avg_duration_seconds': regular_data['duration_seconds'].mean() if len(regular_data) > 0 else 0,
                    'ai_detection_rate': (len(ai_data[ai_data['ai_actually_detected'] == True]) / 
                                         len(ai_data) * 100) if len(ai_data) > 0 else 0,
                    'performance_difference_percent': (
                        ((ai_data['duration_seconds'].mean() - regular_data['duration_seconds'].mean()) / 
                         regular_data['duration_seconds'].mean()) * 100
                    ) if len(ai_data) > 0 and len(regular_data) > 0 else 0
                }
        
        return matrix

    def generate_comprehensive_report(self) -> Dict:
        """Generate comprehensive AI vs Non-AI comparison report"""
        self.logger.info("Generating comprehensive AI vs Non-AI comparison report")
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'performance_comparison': self.compare_performance_metrics(),
            'ai_detection_analysis': self.analyze_ai_detection_effectiveness(),
            'cost_breakdown_analysis': self.calculate_cost_breakdown(),
            'browser_engine_matrix': self.generate_browser_engine_matrix()
        }
        
        return report

def main():
    """Test the AIComparisonFramework module"""
    framework = AIComparisonFramework()
    
    print("🤖 SAFE-Web AI vs Non-AI Comparison Framework")
    
    # Generate comprehensive report
    report = framework.generate_comprehensive_report()
    
    # Display key findings
    if 'performance_comparison' in report and 'performance_impact' in report['performance_comparison']:
        impact = report['performance_comparison']['performance_impact']
        print(f"Performance Impact of AI:")
        print(f"  Duration increase: {impact['duration_seconds_increase_percent']:.1f}%")
        print(f"  CPU increase: {impact['cpu_increase_percent']:.1f}%")
        print(f"  Energy increase: {impact['energy_increase_percent']:.1f}%")
    
    if 'ai_detection_analysis' in report:
        detection = report['ai_detection_analysis']
        print(f"AI Detection: {detection['overall_detection_rate']:.1f}% success rate")

if __name__ == "__main__":
    main()