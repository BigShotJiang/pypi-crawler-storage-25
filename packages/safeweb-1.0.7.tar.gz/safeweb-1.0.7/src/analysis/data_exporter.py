#!/usr/bin/env python3
"""
Data Export Functionality - Week 3
CSV, JSON, PDF export for comprehensive reporting
"""

import sqlite3
import pandas as pd
import json
import csv
from datetime import datetime
from typing import Dict, List, Optional
import logging
import sys
import os

# For PDF generation
try:
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from config import DATABASE_PATH, RESULTS_DIR

class DataExporter:
    def __init__(self, db_path=None):
        self.db_path = str(db_path) if db_path else str(DATABASE_PATH)
        self.export_dir = str(RESULTS_DIR / "exports")
        self.logger = logging.getLogger(__name__)
        
        # Create export directory
        os.makedirs(self.export_dir, exist_ok=True)

    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)

    def export_to_csv(self, filename: Optional[str] = None) -> str:
        """Export all test data with all 35+ metrics to CSV"""
        if not filename:
            filename = "safeweb_results.csv"
        
        # Check if filename already has full path
        if os.path.isabs(filename) or filename.startswith('results/'):
            filepath = filename
        else:
            filepath = os.path.join(self.export_dir, filename)
        
        conn = self.get_connection()
        
        # Get all test runs with basic info
        query_base = """
        SELECT 
            tr.id,
            tr.timestamp,
            tr.browser_name,
            tr.browser_version,
            tr.search_engine,
            tr.ai_enabled,
            tr.query,
            tr.query_type,
            tr.duration_seconds,
            tr.status,
            tr.os_info,
            tr.hardware_info,
            tr.error_message,
            ec.estimated_energy_wh,
            ec.estimated_power_watts,
            ec.cpu_power_watts,
            ec.memory_power_watts,
            ec.base_power_watts,
            ec.display_power_watts,
            ec.calculation_method,
            ad.ai_features_detected,
            ad.ai_indicators_found,
            ad.confidence_score,
            ad.detection_method,
            psm.https_enabled,
            psm.cookie_count,
            psm.third_party_cookies,
            psm.secure_cookies,
            psm.httponly_cookies,
            psm.local_storage_items,
            psm.session_storage_items,
            psm.script_count,
            psm.tracker_count,
            psm.mixed_content,
            psm.permissions_requested
        FROM test_runs tr
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        LEFT JOIN ai_detection ad ON tr.id = ad.test_run_id
        LEFT JOIN privacy_security_metrics psm ON tr.id = psm.test_run_id
        ORDER BY tr.timestamp
        """
        
        df_base = pd.read_sql_query(query_base, conn)
        
        # Get all system metrics and pivot them
        query_metrics = """
        SELECT test_run_id, metric_type, value
        FROM system_metrics
        """
        df_metrics = pd.read_sql_query(query_metrics, conn)
        
        # Pivot metrics so each metric_type becomes a column
        df_metrics_pivot = df_metrics.pivot_table(
            index='test_run_id',
            columns='metric_type',
            values='value',
            aggfunc='first'
        ).reset_index()
        
        # Merge base data with pivoted metrics
        df_final = df_base.merge(df_metrics_pivot, left_on='id', right_on='test_run_id', how='left')
        
        # Drop duplicate id column
        if 'test_run_id' in df_final.columns:
            df_final = df_final.drop('test_run_id', axis=1)
        
        conn.close()
        
        df_final.to_csv(filepath, index=False)
        
        self.logger.info(f"Exported {len(df_final)} tests with all metrics to {filepath}")
        return filepath

    def export_to_json(self, filename: Optional[str] = None) -> str:
        """Export all test data to JSON"""
        if not filename:
            filename = "safeweb_results.json"
        
        filepath = os.path.join(self.export_dir, filename) if not filename.startswith('/') else filename
        
        conn = self.get_connection()
        
        query = """
        SELECT 
            tr.*,
            ec.estimated_energy_wh,
            ec.cpu_power_watts,
            ec.memory_power_watts
        FROM test_runs tr
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        # Convert to JSON
        data = df.to_dict(orient='records')
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        
        self.logger.info(f"Exported to {filepath}")
        return filepath

    def export_to_excel(self, filename: Optional[str] = None) -> str:
        """Export all test data to Excel with multiple sheets"""
        if not filename:
            filename = "safeweb_results.xlsx"
        
        filepath = os.path.join(self.export_dir, filename) if not filename.startswith('/') else filename
        
        conn = self.get_connection()
        
        # Create Excel writer
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # Sheet 1: Test Runs
            df_tests = pd.read_sql_query("SELECT * FROM test_runs", conn)
            df_tests.to_excel(writer, sheet_name='Test Runs', index=False)
            
            # Sheet 2: System Metrics
            df_metrics = pd.read_sql_query("SELECT * FROM system_metrics", conn)
            df_metrics.to_excel(writer, sheet_name='System Metrics', index=False)
            
            # Sheet 3: Energy Calculations
            df_energy = pd.read_sql_query("SELECT * FROM energy_calculations", conn)
            df_energy.to_excel(writer, sheet_name='Energy', index=False)
            
            # Sheet 4: AI Detection
            df_ai = pd.read_sql_query("SELECT * FROM ai_detection", conn)
            df_ai.to_excel(writer, sheet_name='AI Detection', index=False)
        
        conn.close()
        
        self.logger.info(f"Exported to {filepath}")
        return filepath

    def export_raw_data_csv(self, filename: Optional[str] = None) -> str:
        """Export all raw test data to CSV"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"safe_web_raw_data_{timestamp}.csv"
        
        filepath = os.path.join(self.export_dir, filename)
        
        conn = self.get_connection()
        
        query = """
        SELECT 
            tr.id,
            tr.browser_name,
            tr.search_engine,
            CASE WHEN tr.ai_enabled = 1 THEN 'ai_enabled' ELSE 'regular' END as test_type,
            tr.query,
            tr.duration_seconds,
            tr.status,
            tr.timestamp,
            sm.value as cpu_percent,
            sm2.value as memory_percent,
            sm3.value as network_bytes_sent,
            sm4.value as network_bytes_recv,
            ec.estimated_energy_wh,
            ec.calculation_method,
            ad.ai_features_detected,
            ad.ai_indicators_found
        FROM test_runs tr
        LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id AND sm.metric_type = 'cpu_percent'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'memory_percent'
        LEFT JOIN system_metrics sm3 ON tr.id = sm3.test_run_id AND sm3.metric_type = 'network_bytes_sent'
        LEFT JOIN system_metrics sm4 ON tr.id = sm4.test_run_id AND sm4.metric_type = 'network_bytes_recv'
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        LEFT JOIN ai_detection ad ON tr.id = ad.test_run_id
        ORDER BY tr.timestamp
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        df.to_csv(filepath, index=False)
        
        self.logger.info(f"Raw data exported to {filepath}")
        return filepath

    def export_statistical_summary_csv(self, filename: Optional[str] = None) -> str:
        """Export statistical summary to CSV"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"safe_web_statistics_{timestamp}.csv"
        
        filepath = os.path.join(self.export_dir, filename)
        
        # Import statistical analyzer
        from src.analysis.statistical_analyzer import StatisticalAnalyzer
        analyzer = StatisticalAnalyzer(self.db_path)
        
        # Get browser performance statistics
        browser_stats = analyzer.analyze_browser_performance()
        
        # Convert to DataFrame
        rows = []
        for browser, metrics in browser_stats.items():
            for metric_name, stats in metrics.items():
                row = {
                    'browser': browser,
                    'metric': metric_name,
                    'mean': stats['mean'],
                    'median': stats['median'],
                    'std_dev': stats['std_dev'],
                    'min': stats['min'],
                    'max': stats['max'],
                    'count': stats['count']
                }
                rows.append(row)
        
        df = pd.DataFrame(rows)
        df.to_csv(filepath, index=False)
        
        self.logger.info(f"Statistical summary exported to {filepath}")
        return filepath

    def export_ai_comparison_json(self, filename: Optional[str] = None) -> str:
        """Export AI vs Non-AI comparison to JSON"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"safe_web_ai_comparison_{timestamp}.json"
        
        filepath = os.path.join(self.export_dir, filename)
        
        # Import AI comparison framework
        from src.analysis.ai_comparison_framework import AIComparisonFramework
        framework = AIComparisonFramework(self.db_path)
        
        # Generate comprehensive report
        report = framework.generate_comprehensive_report()
        
        # Convert numpy types to native Python types for JSON serialization
        def convert_numpy_types(obj):
            if hasattr(obj, 'item'):
                return obj.item()
            elif isinstance(obj, dict):
                return {key: convert_numpy_types(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_numpy_types(item) for item in obj]
            else:
                return obj
        
        report = convert_numpy_types(report)
        
        with open(filepath, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        self.logger.info(f"AI comparison exported to {filepath}")
        return filepath

    def export_energy_analysis_json(self, filename: Optional[str] = None) -> str:
        """Export energy analysis to JSON"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"safe_web_energy_analysis_{timestamp}.json"
        
        filepath = os.path.join(self.export_dir, filename)
        
        # Import energy impact assessment
        from src.analysis.energy_impact_assessment import EnergyImpactAssessment
        assessor = EnergyImpactAssessment(self.db_path)
        
        # Generate energy analysis
        energy_data = {
            'methodology': assessor.generate_energy_methodology_report(),
            'browser_analysis': assessor.analyze_energy_by_browser(),
            'timestamp': datetime.now().isoformat()
        }
        
        with open(filepath, 'w') as f:
            json.dump(energy_data, f, indent=2, default=str)
        
        self.logger.info(f"Energy analysis exported to {filepath}")
        return filepath

    def generate_pdf_report(self, filename: Optional[str] = None) -> str:
        """Generate comprehensive PDF report"""
        if not PDF_AVAILABLE:
            self.logger.error("PDF generation not available. Install reportlab: pip install reportlab")
            return ""
        
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"safe_web_report_{timestamp}.pdf"
        
        filepath = os.path.join(self.export_dir, filename)
        
        # Create PDF document
        doc = SimpleDocTemplate(filepath, pagesize=A4)
        styles = getSampleStyleSheet()
        story = []
        
        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            spaceAfter=30,
            alignment=1  # Center alignment
        )
        
        story.append(Paragraph("SAFE-Web Browser Testing Report", title_style))
        story.append(Spacer(1, 20))
        
        # Executive Summary
        story.append(Paragraph("Executive Summary", styles['Heading2']))
        
        # Get summary statistics
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM test_runs WHERE success = 1")
        successful_tests = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT browser) FROM test_runs")
        browsers_tested = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT search_engine) FROM test_runs")
        engines_tested = cursor.fetchone()[0]
        
        conn.close()
        
        summary_text = f"""
        This report presents the results of comprehensive browser testing conducted as part of the SAFE-Web project.
        
        Key Statistics:
        • Total successful tests: {successful_tests}
        • Browsers tested: {browsers_tested}
        • Search engines tested: {engines_tested}
        • Test period: {datetime.now().strftime('%B %Y')}
        """
        
        story.append(Paragraph(summary_text, styles['Normal']))
        story.append(Spacer(1, 20))
        
        # Browser Performance Table
        story.append(Paragraph("Browser Performance Summary", styles['Heading2']))
        
        # Import statistical analyzer for data
        from src.analysis.statistical_analyzer import StatisticalAnalyzer
        analyzer = StatisticalAnalyzer(self.db_path)
        browser_stats = analyzer.analyze_browser_performance()
        
        # Create table data
        table_data = [['Browser', 'Avg Duration (s)', 'Avg CPU (%)', 'Avg Memory (%)', 'Test Count']]
        
        for browser, stats in browser_stats.items():
            if 'duration' in stats and stats['duration']['count'] > 0:
                row = [
                    browser.title(),
                    f"{stats['duration']['mean']:.2f}",
                    f"{stats['cpu_percent']['mean']:.1f}",
                    f"{stats['memory_percent']['mean']:.1f}",
                    str(stats['duration']['count'])
                ]
                table_data.append(row)
        
        # Create and style table
        table = Table(table_data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(table)
        story.append(Spacer(1, 20))
        
        # Methodology section
        story.append(Paragraph("Methodology", styles['Heading2']))
        methodology_text = """
        This study employed automated browser testing to evaluate performance across multiple dimensions:
        
        • Performance Metrics: CPU usage, memory consumption, page load times
        • Energy Analysis: Local device consumption and estimated server-side energy
        • AI Detection: Identification of AI-powered search features
        • Statistical Analysis: Mean, median, and standard deviation calculations
        
        All tests were conducted with standardized queries and controlled conditions to ensure reproducibility.
        """
        
        story.append(Paragraph(methodology_text, styles['Normal']))
        
        # Build PDF
        doc.build(story)
        
        self.logger.info(f"PDF report generated: {filepath}")
        return filepath

    def export_all_formats(self) -> Dict[str, str]:
        """Export data in all available formats"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        exports = {}
        
        try:
            exports['raw_csv'] = self.export_raw_data_csv(f"raw_data_{timestamp}.csv")
        except Exception as e:
            self.logger.error(f"CSV export failed: {e}")
        
        try:
            exports['stats_csv'] = self.export_statistical_summary_csv(f"statistics_{timestamp}.csv")
        except Exception as e:
            self.logger.error(f"Statistics CSV export failed: {e}")
        
        try:
            exports['ai_json'] = self.export_ai_comparison_json(f"ai_comparison_{timestamp}.json")
        except Exception as e:
            self.logger.error(f"AI comparison JSON export failed: {e}")
        
        try:
            exports['energy_json'] = self.export_energy_analysis_json(f"energy_analysis_{timestamp}.json")
        except Exception as e:
            self.logger.error(f"Energy analysis JSON export failed: {e}")
        
        if PDF_AVAILABLE:
            try:
                exports['pdf_report'] = self.generate_pdf_report(f"comprehensive_report_{timestamp}.pdf")
            except Exception as e:
                self.logger.error(f"PDF export failed: {e}")
        
        return exports

def main():
    """Test the DataExporter module"""
    exporter = DataExporter()
    
    print("📊 SAFE-Web Data Export System")
    
    # Export all formats
    exports = exporter.export_all_formats()
    
    print("Export Results:")
    for format_type, filepath in exports.items():
        print(f"  {format_type}: {filepath}")

if __name__ == "__main__":
    main()