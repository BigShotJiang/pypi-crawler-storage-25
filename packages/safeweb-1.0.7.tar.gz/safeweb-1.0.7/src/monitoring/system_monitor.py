"""
System Monitoring Module
Monitors CPU, memory, network, and energy consumption
"""

import time
import psutil
import threading
import logging
from datetime import datetime
from dataclasses import dataclass
from typing import List, Dict, Optional

@dataclass
class SystemMetrics:
    """Data class for system metrics"""
    timestamp: datetime
    cpu_percent: float
    memory_percent: float
    memory_used_mb: float
    network_bytes_sent: int
    network_bytes_recv: int
    disk_read_bytes: int
    disk_write_bytes: int
    process_count: int

class SystemMonitor:
    """Monitors system resources during browser testing"""
    
    def __init__(self, monitoring_interval=1.0):
        self.monitoring_interval = monitoring_interval
        self.is_monitoring = False
        self.metrics_history: List[SystemMetrics] = []
        self.monitor_thread = None
        self.logger = logging.getLogger(__name__)
        
        # Store initial network stats for delta calculation
        self.initial_net_io = psutil.net_io_counters()
        self.initial_disk_io = psutil.disk_io_counters()
        
    def start_monitoring(self):
        """Start system monitoring in background thread"""
        if self.is_monitoring:
            self.logger.warning("Monitoring already in progress")
            return
            
        self.is_monitoring = True
        self.metrics_history.clear()
        
        # Reset baseline measurements
        self.initial_net_io = psutil.net_io_counters()
        self.initial_disk_io = psutil.disk_io_counters()
        
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        
        self.logger.info("System monitoring started")
    
    def stop_monitoring(self):
        """Stop system monitoring and return aggregated metrics"""
        if not self.is_monitoring:
            return {}
            
        self.is_monitoring = False
        
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=2.0)
            
        self.logger.info(f"System monitoring stopped. Collected {len(self.metrics_history)} data points")
        
        # Return aggregated metrics
        return self._aggregate_metrics()
    
    def get_current_metrics(self):
        """Get current aggregated metrics without stopping monitoring"""
        return self._aggregate_metrics()
    
    def _aggregate_metrics(self) -> Dict:
        """Aggregate metrics from history"""
        if not self.metrics_history:
            return {'data_points': 0}
        
        cpu_values = [m.cpu_percent for m in self.metrics_history]
        memory_mb_values = [m.memory_used_mb for m in self.metrics_history]
        memory_pct_values = [m.memory_percent for m in self.metrics_history]
        
        # Get latest network and disk values (cumulative)
        latest = self.metrics_history[-1]
        
        return {
            'cpu_mean': sum(cpu_values) / len(cpu_values),
            'cpu_max': max(cpu_values),
            'cpu_min': min(cpu_values),
            'memory_mean_mb': sum(memory_mb_values) / len(memory_mb_values),
            'memory_max_mb': max(memory_mb_values),
            'memory_mean_percent': sum(memory_pct_values) / len(memory_pct_values),
            'memory_max_percent': max(memory_pct_values),
            'network_bytes': latest.network_bytes_sent + latest.network_bytes_recv,
            'network_bytes_sent': latest.network_bytes_sent,
            'network_bytes_received': latest.network_bytes_recv,
            'disk_io_bytes': latest.disk_read_bytes + latest.disk_write_bytes,
            'disk_read_bytes': latest.disk_read_bytes,
            'disk_write_bytes': latest.disk_write_bytes,
            'data_points': len(self.metrics_history)
        }
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.is_monitoring:
            try:
                metrics = self._collect_metrics()
                self.metrics_history.append(metrics)
                time.sleep(self.monitoring_interval)
                
            except Exception as e:
                self.logger.error(f"Error collecting metrics: {str(e)}")
                time.sleep(self.monitoring_interval)
    
    def _collect_metrics(self) -> SystemMetrics:
        """Collect current system metrics"""
        # CPU usage
        cpu_percent = psutil.cpu_percent(interval=None)
        
        # Memory usage
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        memory_used_mb = memory.used / (1024 * 1024)
        
        # Network I/O
        net_io = psutil.net_io_counters()
        net_bytes_sent = net_io.bytes_sent - self.initial_net_io.bytes_sent
        net_bytes_recv = net_io.bytes_recv - self.initial_net_io.bytes_recv
        
        # Disk I/O
        disk_io = psutil.disk_io_counters()
        disk_read_bytes = disk_io.read_bytes - self.initial_disk_io.read_bytes
        disk_write_bytes = disk_io.write_bytes - self.initial_disk_io.write_bytes
        
        # Process count
        process_count = len(psutil.pids())
        
        return SystemMetrics(
            timestamp=datetime.now(),
            cpu_percent=cpu_percent,
            memory_percent=memory_percent,
            memory_used_mb=memory_used_mb,
            network_bytes_sent=net_bytes_sent,
            network_bytes_recv=net_bytes_recv,
            disk_read_bytes=disk_read_bytes,
            disk_write_bytes=disk_write_bytes,
            process_count=process_count
        )
    
    def get_cpu_usage(self) -> float:
        """Get current CPU usage percentage"""
        return psutil.cpu_percent(interval=0.1)
    
    def get_memory_usage(self) -> Dict:
        """Get current memory usage"""
        memory = psutil.virtual_memory()
        return {
            'percent': memory.percent,
            'used_mb': memory.used / (1024 * 1024),
            'available_mb': memory.available / (1024 * 1024),
            'total_mb': memory.total / (1024 * 1024)
        }
    
    def get_browser_process_metrics(self, browser_name: str) -> Optional[Dict]:
        """Get metrics for specific browser process"""
        try:
            browser_processes = []
            
            # Find browser processes
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
                try:
                    proc_name = proc.info['name'].lower()
                    
                    # Match browser process names
                    if (browser_name == "chrome" and "chrome" in proc_name) or \
                       (browser_name == "firefox" and "firefox" in proc_name) or \
                       (browser_name == "safari" and "safari" in proc_name) or \
                       (browser_name == "edge" and "msedge" in proc_name) or \
                       (browser_name == "opera" and "opera" in proc_name) or \
                       (browser_name == "brave" and "brave" in proc_name):
                        
                        browser_processes.append({
                            'pid': proc.info['pid'],
                            'name': proc.info['name'],
                            'cpu_percent': proc.cpu_percent(),
                            'memory_mb': proc.memory_info().rss / (1024 * 1024)
                        })
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if browser_processes:
                # Aggregate metrics for all browser processes
                total_cpu = sum(p['cpu_percent'] for p in browser_processes)
                total_memory = sum(p['memory_mb'] for p in browser_processes)
                
                return {
                    'process_count': len(browser_processes),
                    'total_cpu_percent': total_cpu,
                    'total_memory_mb': total_memory,
                    'processes': browser_processes
                }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting browser process metrics: {str(e)}")
            return None
    
    def calculate_statistics(self) -> Dict:
        """Calculate statistics from collected metrics"""
        if not self.metrics_history:
            return {}
        
        try:
            cpu_values = [m.cpu_percent for m in self.metrics_history]
            memory_values = [m.memory_percent for m in self.metrics_history]
            memory_mb_values = [m.memory_used_mb for m in self.metrics_history]
            
            # Calculate means
            cpu_mean = sum(cpu_values) / len(cpu_values)
            memory_mb_mean = sum(memory_mb_values) / len(memory_mb_values)
            
            # Calculate standard deviations
            cpu_variance = sum((x - cpu_mean) ** 2 for x in cpu_values) / len(cpu_values)
            cpu_stddev = cpu_variance ** 0.5
            
            memory_variance = sum((x - memory_mb_mean) ** 2 for x in memory_mb_values) / len(memory_mb_values)
            memory_stddev = memory_variance ** 0.5
            
            # Calculate network and disk totals
            total_net_sent = max(m.network_bytes_sent for m in self.metrics_history)
            total_net_recv = max(m.network_bytes_recv for m in self.metrics_history)
            total_disk_read = max(m.disk_read_bytes for m in self.metrics_history)
            total_disk_write = max(m.disk_write_bytes for m in self.metrics_history)
            
            return {
                'duration_seconds': len(self.metrics_history) * self.monitoring_interval,
                'cpu_stats': {
                    'mean': cpu_mean,
                    'max': max(cpu_values),
                    'min': min(cpu_values),
                    'stddev': cpu_stddev
                },
                'memory_stats': {
                    'mean_percent': sum(memory_values) / len(memory_values),
                    'max_percent': max(memory_values),
                    'mean_mb': memory_mb_mean,
                    'max_mb': max(memory_mb_values),
                    'min_mb': min(memory_mb_values),
                    'stddev_mb': memory_stddev
                },
                'network_stats': {
                    'total_bytes_sent': total_net_sent,
                    'total_bytes_received': total_net_recv,
                    'total_bytes': total_net_sent + total_net_recv
                },
                'disk_stats': {
                    'total_read_bytes': total_disk_read,
                    'total_write_bytes': total_disk_write,
                    'total_io_bytes': total_disk_read + total_disk_write
                },
                'data_points': len(self.metrics_history)
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating statistics: {str(e)}")
            return {}
    
    def estimate_energy_consumption(self, duration_seconds: float) -> Dict:
        """Estimate energy consumption based on system metrics"""
        try:
            stats = self.calculate_statistics()
            
            if not stats:
                return {}
            
            # Simple energy estimation (rough approximation)
            # These are very rough estimates and would need calibration
            avg_cpu_percent = stats['cpu_stats']['mean']
            avg_memory_mb = stats['memory_stats']['mean_mb']
            
            # Estimate power consumption (watts)
            # CPU: assume 1W per 10% CPU usage
            cpu_power = (avg_cpu_percent / 10.0) * 1.0
            
            # Memory: assume 0.1W per GB
            memory_power = (avg_memory_mb / 1024.0) * 0.1
            
            # Base system power (display, motherboard, etc.)
            base_power = 5.0
            
            total_power_watts = cpu_power + memory_power + base_power
            energy_wh = (total_power_watts * duration_seconds) / 3600.0
            
            return {
                'estimated_power_watts': total_power_watts,
                'estimated_energy_wh': energy_wh,
                'cpu_power_watts': cpu_power,
                'memory_power_watts': memory_power,
                'base_power_watts': base_power,
                'duration_seconds': duration_seconds,
                'note': 'These are rough estimates and need calibration'
            }
            
        except Exception as e:
            self.logger.error(f"Error estimating energy consumption: {str(e)}")
            return {}
    
    def export_metrics_csv(self, filename: str):
        """Export metrics to CSV file"""
        try:
            import csv
            
            with open(filename, 'w', newline='') as csvfile:
                fieldnames = ['timestamp', 'cpu_percent', 'memory_percent', 'memory_used_mb',
                            'network_bytes_sent', 'network_bytes_recv', 'disk_read_bytes', 
                            'disk_write_bytes', 'process_count']
                
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                
                for metric in self.metrics_history:
                    writer.writerow({
                        'timestamp': metric.timestamp.isoformat(),
                        'cpu_percent': metric.cpu_percent,
                        'memory_percent': metric.memory_percent,
                        'memory_used_mb': metric.memory_used_mb,
                        'network_bytes_sent': metric.network_bytes_sent,
                        'network_bytes_recv': metric.network_bytes_recv,
                        'disk_read_bytes': metric.disk_read_bytes,
                        'disk_write_bytes': metric.disk_write_bytes,
                        'process_count': metric.process_count
                    })
            
            self.logger.info(f"Metrics exported to {filename}")
            
        except Exception as e:
            self.logger.error(f"Error exporting metrics: {str(e)}")

# Test the system monitor
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    monitor = SystemMonitor(monitoring_interval=0.5)
    
    print("Starting system monitoring test...")
    monitor.start_monitoring()
    
    # Simulate some activity
    time.sleep(5)
    
    monitor.stop_monitoring()
    
    stats = monitor.calculate_statistics()
    print("Statistics:", stats)
    
    energy = monitor.estimate_energy_consumption(5.0)
    print("Energy estimate:", energy)
