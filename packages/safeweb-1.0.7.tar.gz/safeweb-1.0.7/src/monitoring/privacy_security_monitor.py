"""Privacy and Security Metrics Monitor"""

import logging
from typing import Dict, Any
from selenium.webdriver.remote.webdriver import WebDriver

logger = logging.getLogger(__name__)

class PrivacySecurityMonitor:
    
    def collect_metrics(self, driver: WebDriver) -> Dict[str, Any]:
        """Collect privacy and security metrics"""
        metrics = {}
        
        try:
            # HTTPS/Security
            metrics['https_enabled'] = driver.current_url.startswith('https://')
            
            # Cookies
            cookies = driver.get_cookies()
            metrics['cookie_count'] = len(cookies)
            metrics['third_party_cookies'] = sum(1 for c in cookies if not self._is_first_party(c, driver.current_url))
            metrics['secure_cookies'] = sum(1 for c in cookies if c.get('secure', False))
            metrics['httponly_cookies'] = sum(1 for c in cookies if c.get('httpOnly', False))
            
            # Local Storage
            try:
                local_storage_size = driver.execute_script("return Object.keys(localStorage).length;")
                metrics['local_storage_items'] = local_storage_size
            except:
                metrics['local_storage_items'] = 0
            
            # Session Storage
            try:
                session_storage_size = driver.execute_script("return Object.keys(sessionStorage).length;")
                metrics['session_storage_items'] = session_storage_size
            except:
                metrics['session_storage_items'] = 0
            
            # Trackers (basic detection via script tags)
            try:
                scripts = driver.execute_script("return document.getElementsByTagName('script').length;")
                metrics['script_count'] = scripts
                
                # Common tracker domains
                tracker_domains = ['google-analytics', 'doubleclick', 'facebook', 'twitter', 'linkedin', 'analytics']
                tracker_count = 0
                for domain in tracker_domains:
                    count = driver.execute_script(f"""
                        return Array.from(document.getElementsByTagName('script'))
                            .filter(s => s.src && s.src.includes('{domain}')).length;
                    """)
                    tracker_count += count
                metrics['tracker_count'] = tracker_count
            except:
                metrics['script_count'] = 0
                metrics['tracker_count'] = 0
            
            # Mixed Content
            try:
                metrics['mixed_content'] = driver.execute_script("""
                    return Array.from(document.querySelectorAll('img, script, link'))
                        .filter(e => e.src && e.src.startsWith('http:')).length;
                """)
            except:
                metrics['mixed_content'] = 0
            
            # Permissions requested
            try:
                metrics['permissions_requested'] = driver.execute_script("""
                    return navigator.permissions ? 1 : 0;
                """)
            except:
                metrics['permissions_requested'] = 0
                
        except Exception as e:
            logger.error(f"Error collecting privacy/security metrics: {str(e)}")
        
        return metrics
    
    def calculate_privacy_score(self, metrics: Dict) -> float:
        """Calculate privacy score from collected metrics.
        
        Formula based on Englehardt & Narayanan (2016) ACM CCS:
        - Third-party cookies: logarithmic penalty (long-tail distribution)
        - Trackers: normalised to median of 12 per site from paper
        - HTTPS: penalty per Felt et al. (2017) USENIX Security
        """
        import math
        score = 10.0

        third_party = metrics.get('third_party_cookies', 0)
        if third_party > 0:
            score -= min(3.0, math.log10(third_party + 1) * 1.5)

        trackers = metrics.get('tracker_count', 0)
        if trackers > 0:
            score -= min(4.0, (trackers / 12.0) * 4.0)

        if not metrics.get('https_enabled', True):
            score -= 2.0

        return round(max(0.0, score), 2)

    def calculate_security_score(self, metrics: Dict) -> float:
        """Calculate security score from collected metrics.
        
        Formula based on:
        - Felt et al. (2017) USENIX Security: HTTPS and secure cookie flags
        - Lekies et al. (2013) ACM CCS: mixed content as attack surface
        """
        score = 10.0

        mixed = metrics.get('mixed_content', 0)
        if mixed > 0:
            score -= min(2.0, mixed * 0.5)

        if not metrics.get('https_enabled', True):
            score -= 4.0

        total_cookies = metrics.get('cookie_count', 1) or 1
        secure_cookies = metrics.get('secure_cookies', 0)
        ratio = secure_cookies / total_cookies
        if ratio < 0.5:
            score -= (0.5 - ratio) * 2.0

        return round(max(0.0, score), 2)

    def _is_first_party(self, cookie: Dict, url: str) -> bool:
        """Check if cookie is first-party"""
        try:
            from urllib.parse import urlparse
            domain = urlparse(url).netloc
            cookie_domain = cookie.get('domain', '')
            return domain in cookie_domain or cookie_domain in domain
        except:
            return True
