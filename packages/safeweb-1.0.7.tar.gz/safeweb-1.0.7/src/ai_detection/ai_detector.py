"""
AI Detection Module
Detects and handles AI-powered search features across different search engines
"""

import time
import logging
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

class AIDetector:
    """Detects and interacts with AI features in search engines"""
    
    def __init__(self, driver):
        self.driver = driver
        self.logger = logging.getLogger(__name__)
    
    def detect_google_ai_overview(self):
        """Detect Google AI Overview/SGE features"""
        try:
            # Look for AI Overview section
            ai_selectors = [
                '[data-attrid="SGE"]',  # Search Generative Experience
                '[data-testid="ai-overview"]',  # AI Overview
                '.ai-overview-container',
                '.SGE-container',
                '[aria-label*="AI-generated"]',
                '.generated-answer'
            ]
            
            for selector in ai_selectors:
                try:
                    element = WebDriverWait(self.driver, 3).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                    )
                    self.logger.info(f"Google AI feature detected: {selector}")
                    return {
                        'ai_detected': True,
                        'ai_type': 'Google AI Overview',
                        'selector': selector,
                        'element_text': element.text[:200] if element.text else ''
                    }
                except TimeoutException:
                    continue
            
            # Check for "AI-powered" or "Generative AI" text
            try:
                ai_text = self.driver.find_element(By.XPATH, "//*[contains(text(), 'AI-powered') or contains(text(), 'Generative AI') or contains(text(), 'AI Overview')]")
                return {
                    'ai_detected': True,
                    'ai_type': 'Google AI Text',
                    'selector': 'text_detection',
                    'element_text': ai_text.text[:200]
                }
            except NoSuchElementException:
                pass
            
            return {'ai_detected': False, 'ai_type': None}
            
        except Exception as e:
            self.logger.error(f"Error detecting Google AI: {e}")
            return {'ai_detected': False, 'ai_type': None, 'error': str(e)}
    
    def detect_bing_copilot(self):
        """Detect Bing Copilot features"""
        try:
            # Look for Copilot elements
            copilot_selectors = [
                '.b_copilot',
                '[data-testid="copilot"]',
                '.copilot-container',
                '.chat-container',
                '[aria-label*="Copilot"]',
                '.ai-chat-response'
            ]
            
            for selector in copilot_selectors:
                try:
                    element = WebDriverWait(self.driver, 3).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                    )
                    self.logger.info(f"Bing Copilot detected: {selector}")
                    return {
                        'ai_detected': True,
                        'ai_type': 'Bing Copilot',
                        'selector': selector,
                        'element_text': element.text[:200] if element.text else ''
                    }
                except TimeoutException:
                    continue
            
            # Check for Copilot text
            try:
                copilot_text = self.driver.find_element(By.XPATH, "//*[contains(text(), 'Copilot') or contains(text(), 'AI chat') or contains(text(), 'AI-generated')]")
                return {
                    'ai_detected': True,
                    'ai_type': 'Bing Copilot Text',
                    'selector': 'text_detection',
                    'element_text': copilot_text.text[:200]
                }
            except NoSuchElementException:
                pass
            
            return {'ai_detected': False, 'ai_type': None}
            
        except Exception as e:
            self.logger.error(f"Error detecting Bing Copilot: {e}")
            return {'ai_detected': False, 'ai_type': None, 'error': str(e)}
    
    def detect_duckduckgo_ai(self):
        """Detect DuckDuckGo AI features"""
        try:
            # DuckDuckGo has DuckAssist (AI chat)
            ai_selectors = [
                '.duckassist',
                '.ai-chat',
                '[data-testid="ai-chat"]',
                '.instant-answer--ai'
            ]
            
            for selector in ai_selectors:
                try:
                    element = WebDriverWait(self.driver, 3).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                    )
                    return {
                        'ai_detected': True,
                        'ai_type': 'DuckDuckGo AI',
                        'selector': selector,
                        'element_text': element.text[:200] if element.text else ''
                    }
                except TimeoutException:
                    continue
            
            return {'ai_detected': False, 'ai_type': None}
            
        except Exception as e:
            self.logger.error(f"Error detecting DuckDuckGo AI: {e}")
            return {'ai_detected': False, 'ai_type': None, 'error': str(e)}
    
    def detect_yahoo_ai(self):
        """Detect Yahoo AI features"""
        try:
            # Yahoo may have AI-powered results
            ai_selectors = [
                '.ai-result',
                '.yahoo-ai',
                '[data-testid="ai-answer"]'
            ]
            
            for selector in ai_selectors:
                try:
                    element = WebDriverWait(self.driver, 3).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                    )
                    return {
                        'ai_detected': True,
                        'ai_type': 'Yahoo AI',
                        'selector': selector,
                        'element_text': element.text[:200] if element.text else ''
                    }
                except TimeoutException:
                    continue
            
            return {'ai_detected': False, 'ai_type': None}
            
        except Exception as e:
            self.logger.error(f"Error detecting Yahoo AI: {e}")
            return {'ai_detected': False, 'ai_type': None, 'error': str(e)}
    
    def detect_ai_features(self, search_engine):
        """Main method to detect AI features based on search engine"""
        self.logger.info(f"Detecting AI features for {search_engine}")
        
        # Wait for page to load
        time.sleep(2)
        
        if search_engine.lower() == 'google':
            return self.detect_google_ai_overview()
        elif search_engine.lower() == 'bing':
            return self.detect_bing_copilot()
        elif search_engine.lower() == 'duckduckgo':
            return self.detect_duckduckgo_ai()
        elif search_engine.lower() == 'yahoo':
            return self.detect_yahoo_ai()
        else:
            return {'ai_detected': False, 'ai_type': None, 'error': 'Unknown search engine'}
    
    def force_ai_mode(self, search_engine):
        """Attempt to enable AI features if available"""
        try:
            if search_engine.lower() == 'google':
                # Try to enable SGE/AI Overview
                try:
                    # Look for "Try new AI-powered search" or similar buttons
                    ai_button = self.driver.find_element(By.XPATH, "//*[contains(text(), 'AI') and contains(@role, 'button')]")
                    ai_button.click()
                    time.sleep(2)
                    return True
                except NoSuchElementException:
                    pass
            
            elif search_engine.lower() == 'bing':
                # Try to access Copilot
                try:
                    copilot_button = self.driver.find_element(By.XPATH, "//*[contains(text(), 'Copilot') or contains(text(), 'Chat')]")
                    copilot_button.click()
                    time.sleep(2)
                    return True
                except NoSuchElementException:
                    pass
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error forcing AI mode: {e}")
            return False
    
    def get_ai_availability_matrix(self):
        """Return matrix of AI feature availability by browser/search engine"""
        return {
            'google': {
                'chrome': 'AI Overview available',
                'firefox': 'AI Overview limited',
                'safari': 'AI Overview limited',
                'edge': 'AI Overview available',
                'opera': 'AI Overview limited',
                'brave': 'AI Overview blocked',
                'tor': 'AI Overview unavailable'
            },
            'bing': {
                'chrome': 'Copilot available',
                'firefox': 'Copilot available',
                'safari': 'Copilot available',
                'edge': 'Copilot integrated',
                'opera': 'Copilot available',
                'brave': 'Copilot limited',
                'tor': 'Copilot unavailable'
            },
            'duckduckgo': {
                'chrome': 'DuckAssist limited',
                'firefox': 'DuckAssist limited',
                'safari': 'DuckAssist limited',
                'edge': 'DuckAssist limited',
                'opera': 'DuckAssist limited',
                'brave': 'DuckAssist available',
                'tor': 'DuckAssist available'
            },
            'yahoo': {
                'chrome': 'No AI features',
                'firefox': 'No AI features',
                'safari': 'No AI features',
                'edge': 'No AI features',
                'opera': 'No AI features',
                'brave': 'No AI features',
                'tor': 'No AI features'
            }
        }