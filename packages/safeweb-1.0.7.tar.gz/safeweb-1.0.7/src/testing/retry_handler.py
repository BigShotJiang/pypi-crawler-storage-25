#!/usr/bin/env python3
"""
Retry Handler Module - Week 3 Day 11
Automatic retry logic for failed tests
"""

import time
import logging
from typing import Dict, List, Optional, Callable
from datetime import datetime, timedelta

class RetryHandler:
    def __init__(self, max_retries: int = 3, base_delay: float = 1.0, max_delay: float = 60.0):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.retry_history = []
        
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def exponential_backoff(self, attempt: int) -> float:
        """Calculate exponential backoff delay"""
        delay = min(self.base_delay * (2 ** attempt), self.max_delay)
        return delay

    def should_retry(self, error: Exception, attempt: int) -> bool:
        """Determine if error should trigger retry"""
        if attempt >= self.max_retries:
            return False
        
        # Retry for common browser/network errors
        retry_errors = [
            'TimeoutException',
            'WebDriverException', 
            'ConnectionError',
            'NoSuchElementException',
            'ElementNotInteractableException',
            'StaleElementReferenceException'
        ]
        
        error_name = type(error).__name__
        return any(retry_error in error_name for retry_error in retry_errors)

    def execute_with_retry(self, func: Callable, *args, **kwargs) -> Dict:
        """Execute function with automatic retry logic"""
        attempt = 0
        last_error = None
        
        while attempt <= self.max_retries:
            try:
                result = func(*args, **kwargs)
                
                if attempt > 0:
                    self.logger.info(f"✅ Retry successful after {attempt} attempts")
                
                return {
                    'success': True,
                    'result': result,
                    'attempts': attempt + 1,
                    'error': None
                }
                
            except Exception as e:
                last_error = e
                attempt += 1
                
                if self.should_retry(e, attempt):
                    delay = self.exponential_backoff(attempt - 1)
                    self.logger.warning(f"🔄 Attempt {attempt} failed: {str(e)}, retrying in {delay:.1f}s")
                    time.sleep(delay)
                else:
                    self.logger.error(f"❌ Max retries exceeded or non-retryable error: {str(e)}")
                    break
        
        # Record failure
        failure_record = {
            'timestamp': datetime.now(),
            'function': func.__name__,
            'attempts': attempt,
            'final_error': str(last_error),
            'args': str(args)[:100],  # Truncate for logging
            'kwargs': str(kwargs)[:100]
        }
        
        self.retry_history.append(failure_record)
        
        return {
            'success': False,
            'result': None,
            'attempts': attempt,
            'error': str(last_error)
        }

    def retry_failed_tests(self, failed_tests: List[Dict], test_executor: Callable) -> List[Dict]:
        """Retry a list of failed tests"""
        self.logger.info(f"🔄 Retrying {len(failed_tests)} failed tests")
        
        retry_results = []
        recovered_tests = []
        
        for failed_test in failed_tests:
            test_config = failed_test.get('config', {})
            
            self.logger.info(f"Retrying: {failed_test.get('test_id', 'unknown')}")
            
            retry_result = self.execute_with_retry(test_executor, test_config)
            
            if retry_result['success']:
                recovered_tests.append(failed_test)
                retry_results.append(retry_result['result'])
                self.logger.info(f"✅ Recovered: {failed_test.get('test_id')}")
            else:
                self.logger.error(f"❌ Still failing: {failed_test.get('test_id')}")
        
        self.logger.info(f"🎯 Recovery summary: {len(recovered_tests)}/{len(failed_tests)} tests recovered")
        
        return retry_results

    def get_retry_statistics(self) -> Dict:
        """Get retry attempt statistics"""
        if not self.retry_history:
            return {'total_failures': 0, 'avg_attempts': 0, 'common_errors': []}
        
        total_failures = len(self.retry_history)
        total_attempts = sum(record['attempts'] for record in self.retry_history)
        avg_attempts = total_attempts / total_failures
        
        # Count error types
        error_counts = {}
        for record in self.retry_history:
            error_type = record['final_error'].split(':')[0]
            error_counts[error_type] = error_counts.get(error_type, 0) + 1
        
        common_errors = sorted(error_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        
        return {
            'total_failures': total_failures,
            'avg_attempts': round(avg_attempts, 2),
            'common_errors': common_errors,
            'recent_failures': self.retry_history[-10:]  # Last 10 failures
        }

    def cleanup_old_history(self, days: int = 7):
        """Remove retry history older than specified days"""
        cutoff_date = datetime.now() - timedelta(days=days)
        
        original_count = len(self.retry_history)
        self.retry_history = [
            record for record in self.retry_history 
            if record['timestamp'] > cutoff_date
        ]
        
        cleaned_count = original_count - len(self.retry_history)
        if cleaned_count > 0:
            self.logger.info(f"🧹 Cleaned {cleaned_count} old retry records")

def main():
    """Test the RetryHandler module"""
    retry_handler = RetryHandler(max_retries=3)
    
    # Test function that fails twice then succeeds
    def test_function(fail_count=[0]):
        fail_count[0] += 1
        if fail_count[0] <= 2:
            raise Exception(f"TimeoutException: Test failure {fail_count[0]}")
        return f"Success after {fail_count[0]} attempts"
    
    print("🧪 Testing RetryHandler")
    result = retry_handler.execute_with_retry(test_function)
    print(f"Result: {result}")
    
    # Test statistics
    stats = retry_handler.get_retry_statistics()
    print(f"Statistics: {stats}")

if __name__ == "__main__":
    main()