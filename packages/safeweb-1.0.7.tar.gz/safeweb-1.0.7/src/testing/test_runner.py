#!/usr/bin/env python3
"""
Test Runner Module - Week 3 Day 11
SAFE-Web Testing Framework
"""

import time
import logging
from datetime import datetime
from typing import Dict, List, Optional
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from src.browser_automation.browser_manager import BrowserManager
from src.monitoring.system_monitor import SystemMonitor
from src.monitoring.privacy_security_monitor import PrivacySecurityMonitor
from src.database.db_manager import DatabaseManager
from src.ai_detection.ai_detector import AIDetector

class TestRunner:
    def __init__(self):
        self.browser_manager = BrowserManager()
        self.system_monitor = SystemMonitor()
        self.privacy_monitor = PrivacySecurityMonitor()
        self.db_manager = DatabaseManager()
        # AIDetector will be initialized per test with browser instance
        
        # Test configuration
        self.browsers = ['chrome', 'firefox', 'safari', 'edge', 'opera', 'brave', 'tor']
        self.search_engines = ['google', 'bing', 'duckduckgo', 'yahoo']
        self.trials_per_combination = 25
        
        # Mixed queries - AI detection will determine if AI features appear
        self.queries = [
            "What are the environmental impacts of climate change on ocean ecosystems?",
            "weather today",
            "How does artificial intelligence affect job markets?",
            "news headlines",
            "What are the health benefits of renewable energy?",
            "stock market",
            "Explain quantum computing applications in healthcare",
            "sports scores",
            "What are sustainable transportation solutions?",
            "movie times"
        ]
        
        # Test queue management
        self.test_queue = []
        self.completed_tests = []
        self.failed_tests = []
        
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def generate_test_queue(self):
        """Generate complete test queue for 25 trials per combination"""
        self.test_queue = []
        
        for browser in self.browsers:
            for search_engine in self.search_engines:
                for trial in range(1, self.trials_per_combination + 1):
                    # Use mixed queries - AI detection will determine ai_enabled
                    query = self.queries[trial % len(self.queries)]
                    query_type = 'complex' if trial % 2 == 1 else 'simple'  # Track query complexity separately
                    
                    self.test_queue.append({
                        'browser': browser,
                        'search_engine': search_engine,
                        'query': query,
                        'query_type': query_type,
                        'trial': trial,
                        'test_id': f"{browser}_{search_engine}_{trial}"
                    })
        
        self.logger.info(f"Generated {len(self.test_queue)} tests")
        return len(self.test_queue)

    def execute_single_test(self, test_config: Dict) -> Dict:
        """Execute single test with comprehensive monitoring"""
        test_id = test_config['test_id']
        
        try:
            # Create fresh monitor for this test
            test_monitor = SystemMonitor()
            test_monitor.start_monitoring()
            start_time = time.time()
            
            # Special handling for Opera - warn user
            if test_config['browser'] == 'opera':
                print("\n⚠️  Opera browser may show a data separation popup.")
                print("    Please accept it manually when it appears (you have ~10 seconds).")
                print("    If the test fails, Opera will be skipped.\n")
            
            # Launch browser and execute search
            self.browser_manager.launch_browser(test_config['browser'])
            browser_instance = self.browser_manager.driver
            
            if not browser_instance:
                raise Exception(f"Failed to launch {test_config['browser']} browser")
            
            # Perform search using BrowserManager's method
            search_success = self.browser_manager.perform_search(
                test_config['search_engine'], 
                test_config['query']
            )
            
            if not search_success:
                raise Exception(f"Search failed on {test_config['search_engine']}")
            
            # Wait 30 seconds for full page load and metric collection (research quality)
            self.logger.info("⏱️  Collecting metrics for 30 seconds...")
            time.sleep(30)
            
            # AI detection - always run to detect actual AI presence
            ai_result = None
            ai_detected = False
            if browser_instance:
                try:
                    ai_detector = AIDetector(browser_instance)
                    ai_result = ai_detector.detect_ai_features(test_config['search_engine'])
                    ai_detected = ai_result.get('ai_detected', False) if ai_result else False
                except Exception as e:
                    self.logger.warning(f"AI detection failed: {str(e)}")
                    ai_result = None
                    ai_detected = False
            
            # Collect privacy/security metrics
            privacy_metrics = {}
            if browser_instance:
                try:
                    privacy_metrics = self.privacy_monitor.collect_metrics(browser_instance)
                except Exception as e:
                    self.logger.warning(f"Privacy/security collection failed: {str(e)}")
                    privacy_metrics = {}
            
            # Stop monitoring and collect metrics
            end_time = time.time()
            metrics = test_monitor.stop_monitoring()
            duration = end_time - start_time
            
            # Get browser version
            browser_version = "Unknown"
            try:
                if browser_instance:
                    browser_version = browser_instance.capabilities.get("browserVersion", "Unknown")
            except:
                pass
            
            # Calculate energy consumption using research-based methodology
            # References: See ENERGY_MODEL_RESEARCH_VALIDATION.md
            cpu_usage = metrics.get('cpu_mean', 0) if metrics else 0
            memory_usage_mb = metrics.get('memory_mean_mb', 0) if metrics else 0
            
            # Local energy calculation (peer-reviewed research-based)
            # CPU: 0.3W per % (conservative estimate for modern laptops)
            cpu_watts = cpu_usage * 0.3
            
            # Memory: 0.02W per GB (Ghose et al., SIGMETRICS 2018)
            memory_gb = memory_usage_mb / 1024
            memory_watts = memory_gb * 0.02
            
            # Base system: 15W (ACM PACS 2005 - laptop idle power)
            base_watts = 15
            
            # Display: 10W (typical laptop at 50% brightness)
            display_watts = 10
            
            cpu_energy_wh = (cpu_watts * duration) / 3600
            memory_energy_wh = (memory_watts * duration) / 3600
            base_energy_wh = (base_watts * duration) / 3600
            display_energy_wh = (display_watts * duration) / 3600
            
            local_energy_wh = cpu_energy_wh + memory_energy_wh + base_energy_wh + display_energy_wh
            
            # Remote energy calculation (search engine server)
            # Traditional search: 0.0003 kWh = 0.3 Wh (Google Official Blog, 2009)
            # AI search: 0.24 Wh (Google Cloud Technical Report, 2025)
            if ai_detected:
                base_remote = 0.24  # AI-augmented search (Google 2025)
            else:
                base_remote = 0.3  # Traditional search (Google 2009: 0.0003 kWh = 0.3 Wh)
            
            # PUE (Power Usage Effectiveness) - Google Data Centers official data
            pue_map = {
                'google': 1.12,      # Google official: 1.09-1.12
                'bing': 1.30,        # Estimated (Microsoft hyperscale)
                'duckduckgo': 1.30,  # Estimated (cloud providers)
                'yahoo': 1.30        # Estimated (cloud providers)
            }
            
            pue = pue_map.get(test_config['search_engine'], 1.30)
            remote_energy_wh = base_remote * pue
            
            # Total energy
            estimated_energy = local_energy_wh + remote_energy_wh
            
            # Get system info
            import platform
            import psutil
            os_info = f"{platform.system()} {platform.release()}"
            hardware_info = f"CPU: {psutil.cpu_count()} cores, RAM: {psutil.virtual_memory().total / (1024**3):.1f}GB"
            
            # Save to database
            test_run_id = self.db_manager.create_test_run(
                browser_name=test_config['browser'],
                browser_version=browser_version,
                search_engine=test_config['search_engine'],
                ai_enabled=ai_detected,  # Use actual detection result
                query=test_config['query'],
                query_type=test_config.get('query_type', 'unknown'),
                duration=duration,
                os_info=os_info,
                hardware_info=hardware_info,
                success=True
            )
            
            self.db_manager.save_system_metrics(test_run_id, metrics)
            
            # Calculate average power
            estimated_power_watts = (estimated_energy * 3600) / duration if duration > 0 else 0
            
            self.db_manager.save_energy_calculation(test_run_id, {
                'estimated_energy_wh': estimated_energy,
                'estimated_power_watts': estimated_power_watts,
                'cpu_power_watts': cpu_watts,
                'memory_power_watts': memory_watts,
                'base_power_watts': base_watts,
                'display_power_watts': display_watts,
                'calculation_method': 'research_based_component_estimation'
            })
            
            if ai_result:
                self.db_manager.save_ai_detection(test_run_id, ai_result)
            
            if privacy_metrics:
                self.db_manager.save_privacy_metrics(test_run_id, privacy_metrics)
            
            # Update status to completed
            self.db_manager.update_test_run(test_run_id, status='completed')
            
            self.browser_manager.close_browser()
            
            result = {
                'test_id': test_id,
                'success': True,
                'duration': duration,
                'energy': estimated_energy,
                'ai_detected': ai_result is not None,
                'metrics': metrics
            }
            
            self.completed_tests.append(result)
            self.logger.info(f"✅ {test_id} completed")
            
            return result
            
        except Exception as e:
            self.logger.error(f"❌ {test_id} failed: {str(e)}")
            
            failure = {
                'test_id': test_id,
                'success': False,
                'error': str(e),
                'config': test_config
            }
            
            self.failed_tests.append(failure)
            return failure

    def run_test_batch(self, batch_size: int = 50) -> Dict:
        """Execute tests in batches with progress tracking"""
        if not self.test_queue:
            self.generate_test_queue()
        
        total_tests = len(self.test_queue)
        completed = 0
        
        self.logger.info(f"Starting batch execution: {total_tests} tests")
        start_time = datetime.now()
        
        for i, test_config in enumerate(self.test_queue):
            result = self.execute_single_test(test_config)
            completed += 1
            
            # Progress update every batch_size tests
            if completed % batch_size == 0:
                progress = (completed / total_tests) * 100
                elapsed = datetime.now() - start_time
                self.logger.info(f"Progress: {completed}/{total_tests} ({progress:.1f}%) | Elapsed: {elapsed}")
        
        end_time = datetime.now()
        duration = end_time - start_time
        
        summary = {
            'total_tests': total_tests,
            'completed': len(self.completed_tests),
            'failed': len(self.failed_tests),
            'success_rate': (len(self.completed_tests) / total_tests) * 100,
            'duration': duration,
            'tests_per_minute': total_tests / (duration.total_seconds() / 60)
        }
        
        self.logger.info(f"Batch complete: {summary}")
        return summary

    def get_progress_status(self) -> Dict:
        """Get current test execution progress"""
        total = len(self.test_queue) if self.test_queue else 0
        completed = len(self.completed_tests)
        failed = len(self.failed_tests)
        
        return {
            'total_tests': total,
            'completed': completed,
            'failed': failed,
            'remaining': total - completed - failed,
            'success_rate': (completed / max(completed + failed, 1)) * 100,
            'completion_rate': ((completed + failed) / max(total, 1)) * 100
        }

def main():
    """Test the TestRunner module"""
    runner = TestRunner()
    
    print("🚀 SAFE-Web Test Runner")
    print(f"Browsers: {len(runner.browsers)}")
    print(f"Search Engines: {len(runner.search_engines)}")
    print(f"Trials per combination: {runner.trials_per_combination}")
    
    # Generate test queue
    total_tests = runner.generate_test_queue()
    print(f"Total tests generated: {total_tests}")
    
    # Run small test batch
    print("\nRunning test batch...")
    summary = runner.run_test_batch(batch_size=10)
    print(f"Test execution summary: {summary}")

if __name__ == "__main__":
    main()