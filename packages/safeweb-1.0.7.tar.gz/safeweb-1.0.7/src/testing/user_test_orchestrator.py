"""User Test Orchestrator - Executes browser tests for users"""

import logging
import time
from typing import Dict, Any

from src.browser_automation.browser_manager import BrowserManager
from src.monitoring.system_monitor import SystemMonitor
from src.monitoring.privacy_security_monitor import PrivacySecurityMonitor
from src.ai_detection.ai_detector import AIDetector
from src.database.db_manager import DatabaseManager

logger = logging.getLogger(__name__)

class UserTestOrchestrator:
    
    def __init__(self):
        self.browser_manager = BrowserManager()
        self.system_monitor = SystemMonitor()
        self.privacy_monitor = PrivacySecurityMonitor()
        self.db = DatabaseManager()
    
    def run_test(self, browser: str, search_engine: str, query: str, ai_enabled: bool) -> Dict[str, Any]:
        """Execute complete browser test and return results"""
        
        max_retries = 1
        for attempt in range(max_retries + 1):
            test_run_id = None
            driver = None
            
            try:
                # Create test run
                test_run_id = self.db.create_test_run(
                    browser_name=browser,
                    search_engine=search_engine,
                    ai_enabled=ai_enabled,
                    query=query,
                    status='running'
                )
                
                # Start monitoring
                try:
                    self.system_monitor.stop_monitoring()  # Stop any previous monitoring
                except:
                    pass
                self.system_monitor.start_monitoring()
                start_time = time.time()
                
                # Launch browser and search
                driver = self.browser_manager.launch_browser(browser)
                search_url = self._build_search_url(search_engine, query)
                driver.get(search_url)
                
                # Wait minimum 30 seconds, check if we have enough data
                time.sleep(30)
                
                # Check if we have sufficient metrics (at least 30 data points)
                current_metrics = self.system_monitor.get_current_metrics()
                data_points = current_metrics.get('data_points', 0) if isinstance(current_metrics, dict) else 0
                
                # Wait up to 120 more seconds if needed (150 total max)
                max_additional_wait = 120
                waited = 0
                while data_points < 30 and waited < max_additional_wait:
                    time.sleep(10)
                    waited += 10
                    current_metrics = self.system_monitor.get_current_metrics()
                    data_points = current_metrics.get('data_points', 0) if isinstance(current_metrics, dict) else 0
                
                # Detect AI
                ai_detector = AIDetector(driver)
                ai_result = ai_detector.detect_ai_features(search_engine)
                ai_detected = ai_result.get('ai_detected', False) if isinstance(ai_result, dict) else False
                ai_type = ai_result.get('ai_type', 'None') if isinstance(ai_result, dict) else 'None'
                
                # Collect privacy/security metrics
                privacy_metrics = self.privacy_monitor.collect_metrics(driver)
                if not isinstance(privacy_metrics, dict):
                    privacy_metrics = {}
                
                # Calculate privacy score (same logic as app.py)
                import math
                privacy_score = 10
                if privacy_metrics.get('third_party_cookies', 0) > 0:
                    cookie_count = privacy_metrics.get('third_party_cookies', 0)
                    cookie_penalty = min(3.0, math.log10(cookie_count + 1) * 1.5)
                    privacy_score -= cookie_penalty
                
                tracker_count = privacy_metrics.get('tracker_count', 0)
                if tracker_count > 0:
                    tracker_penalty = min(4.0, (tracker_count / 12.0) * 4.0)
                    privacy_score -= tracker_penalty
                
                if not privacy_metrics.get('https_enabled', True):
                    privacy_score -= 2.0
                
                privacy_score = max(0, privacy_score)
                
                # Calculate security score (same logic as app.py)
                security_score = 10
                if privacy_metrics.get('mixed_content', 0) > 0:
                    mixed_penalty = min(2.0, privacy_metrics.get('mixed_content', 0) * 0.5)
                    security_score -= mixed_penalty
                
                if not privacy_metrics.get('https_enabled', True):
                    security_score -= 4.0
                
                secure_cookie_ratio = privacy_metrics.get('secure_cookies', 0) / max(privacy_metrics.get('cookie_count', 1), 1)
                if secure_cookie_ratio < 0.5:
                    cookie_penalty = (0.5 - secure_cookie_ratio) * 2.0
                    security_score -= cookie_penalty
                
                security_score = max(0, security_score)
                
                # Add scores to privacy_metrics
                privacy_metrics['privacy_score'] = round(privacy_score, 1)
                privacy_metrics['security_score'] = round(security_score, 1)
                privacy_metrics['tracker_blocking'] = tracker_count < 3
                privacy_metrics['cookie_protection'] = privacy_metrics.get('third_party_cookies', 0) < 5
                privacy_metrics['https_enforcement'] = privacy_metrics.get('https_enabled', False) and privacy_metrics.get('mixed_content', 0) == 0
                
                # Collect metrics
                duration = time.time() - start_time
                metrics = self.system_monitor.stop_monitoring()
                
                # Handle case where monitoring failed
                if not isinstance(metrics, dict):
                    metrics = {}
                
                energy_wh = self._calculate_energy(metrics, duration)
                
                # Store results
                self._store_results(test_run_id, metrics, energy_wh, duration)
                self.db.update_test_run(test_run_id, status='completed', duration_seconds=duration)
                
                return {
                    'success': True,
                    'test_id': test_run_id,
                    'browser': browser,
                    'engine': search_engine,
                    'ai_enabled': ai_enabled,
                    'ai_detected': ai_detected,
                    'ai_type': ai_type,
                    'duration': round(duration, 2),
                    'metrics': {
                        'energy': round(energy_wh, 3),
                        'energy_wh': round(energy_wh, 3),
                        'cpu_mean': round(metrics.get('cpu_mean', 0), 2),
                        'cpu_max': round(metrics.get('cpu_max', 0), 2),
                        'cpu_min': round(metrics.get('cpu_min', 0), 2),
                        'memory_mb': round(metrics.get('memory_mean_mb', 0), 2),
                        'memory_max_mb': round(metrics.get('memory_max_mb', 0), 2),
                        'memory_percent': round(metrics.get('memory_mean_percent', 0), 2),
                        'network_mb': round(metrics.get('network_bytes', 0) / 1024 / 1024, 2),
                        'network_sent_mb': round(metrics.get('network_bytes_sent', 0) / 1024 / 1024, 2),
                        'network_received_mb': round(metrics.get('network_bytes_received', 0) / 1024 / 1024, 2),
                        'disk_mb': round(metrics.get('disk_io_bytes', 0) / 1024 / 1024, 2),
                        'disk_read_mb': round(metrics.get('disk_read_bytes', 0) / 1024 / 1024, 2),
                        'disk_write_mb': round(metrics.get('disk_write_bytes', 0) / 1024 / 1024, 2),
                        'duration': round(duration, 2),
                        'data_points': metrics.get('data_points', 0),
                        'privacy_score': privacy_metrics.get('privacy_score', 0),
                        'security_score': privacy_metrics.get('security_score', 0),
                        'tracker_blocking': privacy_metrics.get('tracker_blocking', False),
                        'cookie_protection': privacy_metrics.get('cookie_protection', False),
                        'https_enforcement': privacy_metrics.get('https_enforcement', False),
                        **privacy_metrics
                    }
                }
                
            except Exception as e:
                import traceback
                error_trace = traceback.format_exc()
                logger.error(f"Test failed (attempt {attempt + 1}/{max_retries + 1}): {str(e)}")
                logger.error(f"Full traceback:\n{error_trace}")
                print(f"FULL ERROR TRACEBACK:\n{error_trace}")
                
                if test_run_id:
                    self.db.update_test_run(test_run_id, status='failed', error_message=str(e))
                
                if attempt < max_retries:
                    logger.info(f"Retrying test...")
                    time.sleep(5)
                    continue
                else:
                    return {'success': False, 'error': str(e)}
            
            finally:
                if driver:
                    try:
                        driver.quit()
                    except:
                        pass
    
    def _build_search_url(self, engine: str, query: str) -> str:
        """Build search URL"""
        q = query.replace(' ', '+')
        urls = {
            'google': f'https://www.google.com/search?q={q}',
            'bing': f'https://www.bing.com/search?q={q}',
            'duckduckgo': f'https://duckduckgo.com/?q={q}',
            'yahoo': f'https://search.yahoo.com/search?p={q}'
        }
        return urls.get(engine.lower(), urls['google'])
    
    def _calculate_energy(self, metrics: Dict, duration: float) -> float:
        """
        Calculate energy using research-based algorithms
        Based on Koomey et al. (2011), Barroso & Hölzle (2007), and Strubell et al. (2019)
        """
        cpu_mean = metrics.get('cpu_mean', 0)
        memory_percent = metrics.get('memory_mean_percent', 0)
        
        # Research-based power consumption model
        # Peak power consumption (watts) - based on Intel TDP specifications
        P_cpu_peak = 15.0  # Typical laptop CPU TDP
        P_memory_peak = 5.0  # DDR4 memory power consumption
        P_base_idle = 8.0  # Base system power
        
        # Barroso & Hölzle (2007): Energy-proportional computing
        # Laptops are more energy-proportional than servers (30% vs 55% idle ratio)
        idle_ratio = 0.3
        
        # Calculate component power consumption
        P_cpu = P_cpu_peak * (idle_ratio + (1 - idle_ratio) * (cpu_mean / 100))
        P_memory = P_memory_peak * (memory_percent / 100)
        P_base = P_base_idle
        
        # Total power and energy calculation
        total_power = P_cpu + P_memory + P_base
        energy_wh = (total_power * duration) / 3600
        
        return energy_wh
    
    def _store_results(self, test_run_id: int, metrics: Dict, energy_wh: float, duration: float):
        """Store metrics in database"""
        
        # Save system metrics
        system_metrics = {
            'cpu_stats_mean': metrics.get('cpu_mean', 0),
            'cpu_stats_max': metrics.get('cpu_max', 0),
            'cpu_stats_min': metrics.get('cpu_min', 0),
            'memory_stats_mean_mb': metrics.get('memory_mean_mb', 0),
            'memory_stats_max_mb': metrics.get('memory_max_mb', 0),
            'memory_stats_mean_percent': metrics.get('memory_mean_percent', 0),
            'memory_stats_max_percent': metrics.get('memory_max_percent', 0),
            'network_stats_total_bytes': metrics.get('network_bytes', 0),
            'network_stats_total_bytes_sent': metrics.get('network_bytes_sent', 0),
            'network_stats_total_bytes_received': metrics.get('network_bytes_received', 0),
            'disk_stats_total_io_bytes': metrics.get('disk_io_bytes', 0),
            'disk_stats_total_read_bytes': metrics.get('disk_read_bytes', 0),
            'disk_stats_total_write_bytes': metrics.get('disk_write_bytes', 0),
            'data_points': metrics.get('data_points', 0),
            'duration_seconds': duration
        }
        self.db.save_system_metrics(test_run_id, system_metrics)
        
        # Save energy calculation
        energy_data = {
            'estimated_energy_wh': energy_wh,
            'calculation_method': 'user_test'
        }
        self.db.save_energy_calculation(test_run_id, energy_data)
