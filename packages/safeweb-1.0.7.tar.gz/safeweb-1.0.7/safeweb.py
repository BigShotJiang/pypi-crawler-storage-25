#!/usr/bin/env python3
"""SafeWeb CLI Tool - Browser Safety and Sustainability Testing"""
import argparse
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.testing.test_runner import TestRunner
from src.database.db_manager import DatabaseManager
from src.analysis.statistical_analyzer import StatisticalAnalyzer
from src.analysis.data_exporter import DataExporter
from config import BROWSERS, ensure_directories, ensure_reports_dir, ensure_reports_dir
import platform


def detect_installed_browsers():
    """Auto-detect installed browsers"""
    installed = []
    for name, config in BROWSERS.items():
        if name == 'chrome':
            installed.append(name)  # Chrome managed by webdriver-manager, no path needed
        elif name == 'firefox':
            if config.get('executable_path'):  # Only if binary found on this machine
                installed.append(name)
        elif name == 'safari' and platform.system() == 'Darwin':
            if config.get('executable_path'):
                installed.append(name)
        elif config.get('executable_path'):
            installed.append(name)
    return installed


def run_tests(args):
    """Run browser tests"""
    print("🔍 SafeWeb Browser Testing Tool")
    print("=" * 60)
    
    installed = detect_installed_browsers()
    if not installed:
        print("❌ No browsers detected. Install Chrome, Firefox, or Safari.")
        sys.exit(1)
    
    print(f"✅ Detected: {', '.join(b.title() for b in installed)}")
    
    test_browsers = [b for b in (args.browsers or installed) if b in installed]
    if not test_browsers:
        print(f"❌ Specified browsers not installed. Available: {', '.join(installed)}")
        sys.exit(1)
    
    print(f"🎯 Testing: {', '.join(b.title() for b in test_browsers)}")
    print(f"🔎 Engines: {', '.join(args.engines) if args.engines else 'all'}")
    print(f"🔢 Trials: {args.trials} per combination")
    print(f"📊 Collecting 35+ metrics per test\n")
    
    if args.dry_run:
        runner = TestRunner()
        runner.browsers = test_browsers
        if args.engines:
            runner.search_engines = args.engines
        runner.trials_per_combination = args.trials
        runner.generate_test_queue()
        print(f"📋 Plan: {len(runner.test_queue)} tests")
        print("✓ Dry run complete. Remove --dry-run to execute.")
        return
    
    runner = TestRunner()
    runner.browsers = test_browsers
    if args.engines:
        runner.search_engines = args.engines
    runner.trials_per_combination = args.trials
    
    # Override queries if custom query provided
    if args.query:
        runner.queries = [args.query]
        print(f"📝 Using custom query: '{args.query}'")
    
    runner.generate_test_queue()
    
    print(f"🚀 Starting {len(runner.test_queue)} tests...\n")
    
    # Run tests in batches
    results = runner.run_test_batch(batch_size=len(runner.test_queue))
    
    print("\n" + "=" * 60)
    print(f"✅ Complete! {results.get('completed', 0)} tests finished")
    print(f"📁 Data saved to: results/database/safe_web.db")
    if results.get('failed', 0) > 0:
        print(f"⚠️  {results.get('failed', 0)} tests failed")
    print("\n💡 Next: safeweb analyze")


def analyze(args):
    """Analyze results"""
    print("📊 SafeWeb Analysis — Three Lenses: Privacy, Security, Sustainability")
    print("=" * 80)

    db = DatabaseManager()
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM test_runs")
        count = cursor.fetchone()[0]
        if count == 0:
            print("\n❌ No data. Run: safeweb run-tests")
            sys.exit(1)
        print(f"\n📈 Analyzing {count} tests\n")

    analyzer = StatisticalAnalyzer()

    if args.browser:
        r = analyzer.get_browser_stats(args.browser)
        print(f"🌐 {args.browser.upper()}:")
        print(f"  Tests:       {r.get('tests', 0)}")
        print(f"  Energy:      {r.get('energy', 0):.3f} Wh (total)")
        print(f"  CPU:         {r.get('cpu', 0):.1f}%")
        print(f"  Memory:      {r.get('memory', 0):.0f} MB")
        print(f"  🔒 Privacy:  {r.get('privacy', 0):.1f}/10")
        print(f"  🛡  Security: {r.get('security', 0):.1f}/10")
    else:
        results = analyzer.get_all_browser_stats()

        # Fetch local/remote energy breakdown per browser
        energy_breakdown = {}
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT tr.browser_name,
                    AVG(ec.cpu_power_watts + ec.memory_power_watts + ec.base_power_watts + ec.display_power_watts) as avg_local_watts,
                    AVG(ec.estimated_energy_wh) as avg_total,
                    AVG(tr.duration_seconds) as avg_dur
                FROM test_runs tr
                JOIN energy_calculations ec ON tr.id = ec.test_run_id
                GROUP BY tr.browser_name
            """)
            for row in cursor.fetchall():
                name = row[0].title()
                avg_local_watts = row[1] or 0
                avg_total = row[2] or 0
                avg_dur = row[3] or 0
                local_wh = (avg_local_watts * avg_dur) / 3600
                remote_wh = max(0, avg_total - local_wh)
                energy_breakdown[name] = (round(local_wh, 3), round(remote_wh, 4))

        # Fetch standard deviations per browser
        stddevs = {}
        with db.get_connection() as conn:
            cursor = conn.cursor()
            for b in results:
                cursor.execute("""
                    SELECT 
                        COUNT(*) as n,
                        AVG(ec.estimated_energy_wh) as mean_energy,
                        SUM((ec.estimated_energy_wh - (SELECT AVG(estimated_energy_wh) FROM energy_calculations ec2 
                                                        JOIN test_runs tr2 ON ec2.test_run_id = tr2.id 
                                                        WHERE tr2.browser_name = tr.browser_name)) * 
                            (ec.estimated_energy_wh - (SELECT AVG(estimated_energy_wh) FROM energy_calculations ec2 
                                                        JOIN test_runs tr2 ON ec2.test_run_id = tr2.id 
                                                        WHERE tr2.browser_name = tr.browser_name))) as sum_sq_diff,
                        AVG(sm_cpu.value) as mean_cpu,
                        SUM((sm_cpu.value - (SELECT AVG(sm.value) FROM system_metrics sm 
                                             JOIN test_runs tr2 ON sm.test_run_id = tr2.id 
                                             WHERE tr2.browser_name = tr.browser_name AND sm.metric_type = 'cpu_mean')) * 
                            (sm_cpu.value - (SELECT AVG(sm.value) FROM system_metrics sm 
                                             JOIN test_runs tr2 ON sm.test_run_id = tr2.id 
                                             WHERE tr2.browser_name = tr.browser_name AND sm.metric_type = 'cpu_mean'))) as cpu_sum_sq_diff,
                        AVG(sm_mem.value) as mean_mem,
                        SUM((sm_mem.value - (SELECT AVG(sm.value) FROM system_metrics sm 
                                             JOIN test_runs tr2 ON sm.test_run_id = tr2.id 
                                             WHERE tr2.browser_name = tr.browser_name AND sm.metric_type = 'memory_mean_mb')) * 
                            (sm_mem.value - (SELECT AVG(sm.value) FROM system_metrics sm 
                                             JOIN test_runs tr2 ON sm.test_run_id = tr2.id 
                                             WHERE tr2.browser_name = tr.browser_name AND sm.metric_type = 'memory_mean_mb'))) as mem_sum_sq_diff
                    FROM test_runs tr
                    JOIN energy_calculations ec ON tr.id = ec.test_run_id
                    LEFT JOIN system_metrics sm_cpu ON tr.id = sm_cpu.test_run_id AND sm_cpu.metric_type = 'cpu_mean'
                    LEFT JOIN system_metrics sm_mem ON tr.id = sm_mem.test_run_id AND sm_mem.metric_type = 'memory_mean_mb'
                    WHERE tr.browser_name = ?
                """, (b['name'].lower(),))
                row = cursor.fetchone()
                if row and row[0] > 1:  # Need at least 2 samples for stddev
                    n = row[0]
                    energy_stddev = (row[2] / (n - 1)) ** 0.5 if row[2] else 0
                    cpu_stddev = (row[4] / (n - 1)) ** 0.5 if row[4] else 0
                    mem_stddev = (row[6] / (n - 1)) ** 0.5 if row[6] else 0
                    stddevs[b['name']] = {
                        'energy': energy_stddev,
                        'cpu': cpu_stddev,
                        'memory': mem_stddev
                    }
                else:
                    stddevs[b['name']] = {'energy': 0, 'cpu': 0, 'memory': 0}

        # Main table
        print(f"{'Browser':<12} {'Tests':<7} {'Total(Wh)':<11} {'Local(Wh)':<11} {'Remote(Wh)':<12} {'CPU%':<7} {'Mem(MB)':<10} {'Privacy':<9} {'Security'}")
        print("-" * 95)
        for b in results:
            local, remote = energy_breakdown.get(b['name'], (0, 0))
            print(f"{b['name']:<12} {b['tests']:<7} {b['energy']:<11.3f} {local:<11.3f} {remote:<12.4f} {b['cpu']:<7.1f} {b['memory']:<10.0f} {b['privacy']:<9.1f} {b['security']:.1f}")

        # Three-Lens Summary for each browser
        print("\n📋 Three-Lens Summary (per browser):")
        for b in results:
            co2 = (b['energy'] / 1000) * 400  # IEA global average: 400g CO2/kWh
            sd = stddevs.get(b['name'], {'energy': 0, 'cpu': 0, 'memory': 0})
            print(f"\n   {b['name']}:")
            print(f"      🔒 Privacy:        {b['privacy']:.1f}/10  (cookies, trackers, HTTPS)")
            print(f"      🛡  Security:       {b['security']:.1f}/10 (HTTPS, mixed content, secure cookies)")
            print(f"      🌱 Sustainability: {b['energy']:.3f} Wh (±{sd['energy']:.3f}) | {co2:.3f}g CO2")
            print(f"         CPU: {b['cpu']:.1f}% (±{sd['cpu']:.1f}) | Memory: {b['memory']:.0f} MB (±{sd['memory']:.0f})")

        print("\n🏆 Best per category:")
        best_e = min(results, key=lambda x: x['energy'])
        best_c = min(results, key=lambda x: x['cpu'])
        best_m = min(results, key=lambda x: x['memory'])
        best_p = max(results, key=lambda x: x['privacy'])
        best_s = max(results, key=lambda x: x['security'])
        print(f"  ⚡ Energy:   {best_e['name']} ({best_e['energy']:.3f} Wh)")
        print(f"  🖥  CPU:      {best_c['name']} ({best_c['cpu']:.1f}%)")
        print(f"  💾 Memory:   {best_m['name']} ({best_m['memory']:.0f} MB)")
        print(f"  🔒 Privacy:  {best_p['name']} ({best_p['privacy']:.1f}/10)")
        print(f"  🛡  Security: {best_s['name']} ({best_s['security']:.1f}/10)")

    if args.ai_comparison:
        ai = analyzer.compare_ai_impact()
        if ai.get('non_ai') and ai.get('ai'):
            print(f"\n🤖 AI vs Non-AI Energy Impact:")
            print(f"  Non-AI search: {ai['non_ai']['energy']:.4f} Wh  ({ai['non_ai']['tests']} tests)")
            print(f"  AI search:     {ai['ai']['energy']:.4f} Wh  ({ai['ai']['tests']} tests)")
            print(f"  Multiplier:    {ai.get('multiplier', 0):.2f}x more energy with AI")
    print()


def explain(args):
    """Explain the Three-Lens Framework"""
    print("📚 SafeWeb Three-Lens Framework")
    print("=" * 80)
    print()
    print("SafeWeb evaluates browsers through THREE research-based lenses:")
    print()
    
    print("🔒 LENS 1: PRIVACY (Score 0-10)")
    print("   What it measures:")
    print("   • Third-party cookies (from advertisers/trackers)")
    print("   • Tracker scripts (Google Analytics, Facebook Pixel, etc.)")
    print("   • HTTPS encryption")
    print()
    print("   How it's calculated:")
    print("   • Start with 10 points")
    print("   • Subtract up to 3 points for tracking cookies (logarithmic)")
    print("   • Subtract up to 4 points for tracker scripts (linear)")
    print("   • Subtract 2 points if no HTTPS")
    print()
    print("   Research basis:")
    print("   ✅ Englehardt & Narayanan (2016), ACM CCS")
    print("      'Online Tracking: A 1-million-site Measurement'")
    print("   ✅ Felt et al. (2017), USENIX Security")
    print("      'Measuring HTTPS Adoption on the Web'")
    print()
    
    print("🛡  LENS 2: SECURITY (Score 0-10)")
    print("   What it measures:")
    print("   • HTTPS encryption")
    print("   • Mixed content (insecure resources on secure pages)")
    print("   • Secure cookie flags")
    print()
    print("   How it's calculated:")
    print("   • Start with 10 points")
    print("   • Subtract 4 points if no HTTPS (highest penalty!)")
    print("   • Subtract up to 2 points for mixed content (0.5 per item)")
    print("   • Subtract up to 2 points for insecure cookies")
    print()
    print("   Research basis:")
    print("   ✅ Felt et al. (2017), USENIX Security")
    print("      'Measuring HTTPS Adoption on the Web'")
    print("   ✅ Lekies et al. (2013), ACM CCS")
    print("      '25 Million Flows Later: DOM-based XSS Detection'")
    print()
    
    print("🌱 LENS 3: SUSTAINABILITY (Energy in Wh, CO2 in grams)")
    print("   What it measures:")
    print("   • Local energy (your laptop: CPU, memory, display)")
    print("   • Remote energy (search engine servers)")
    print("   • CO2 emissions (based on energy consumption)")
    print()
    print("   How it's calculated:")
    print("   Local Energy:")
    print("   • CPU: (usage % × 0.3W) × duration")
    print("   • Memory: (GB used × 0.02W) × duration")
    print("   • Base system: 15W × duration")
    print("   • Display: 10W × duration")
    print()
    print("   Remote Energy:")
    print("   • Traditional search: 0.3 Wh × PUE")
    print("   • AI search: 0.24 Wh × PUE")
    print("   • PUE = Power Usage Effectiveness (Google: 1.12, Others: 1.30)")
    print()
    print("   CO2 Emissions:")
    print("   • CO2 (grams) = (Total Energy Wh / 1000) × 400")
    print("   • 400g CO2/kWh = IEA global average grid carbon intensity")
    print()
    print("   Research basis:")
    print("   ✅ Ghose et al. (2018), ACM SIGMETRICS")
    print("      'What Your DRAM Power Models Are Not Telling You'")
    print("   ✅ ACM PACS (2005)")
    print("      'Power Consumption Breakdown on a Modern Laptop'")
    print("   ✅ Google (2009): Traditional search = 0.0003 kWh = 0.3 Wh")
    print("   ✅ Google Cloud (2025): AI search = 0.24 Wh")
    print()
    
    print("📊 HOW THEY COMBINE IN 'recommend' COMMAND:")
    print("   Composite Score = 40% Energy + 30% Performance + 20% Privacy + 10% Security")
    print()
    print("   Weight justification:")
    print("   • Energy (40%): Primary sustainability metric (Preist et al. 2019, ACM CHI)")
    print("   • Performance (30%): Dominant user-perceived quality")
    print("   • Privacy (20%): Significant but secondary (Acquisti et al. 2015, Science)")
    print("   • Security (10%): Often subordinated to usability (Whitten & Tygar 1999)")
    print()
    print("💡 TIP: Run './safeweb_run.sh analyze' to see all three lenses for your tests")
    print()


def export(args):
    """Export results"""
    print(f"Exporting to CSV")
    print("=" * 60)
    
    exporter = DataExporter()
    output = args.output or "safeweb_results.csv"
    
    print(f"Output: results/exports/{output}\n")
    result = exporter.export_to_csv(output)
    print(f"Exported: {result}")
    print("Includes all 35+ metrics")
    
    print(f"✅ Exported: {result}")
    print("📊 Includes all 35+ metrics")


def recommend(args):
    """Find the best browser+engine combination from test results using research-based weighted scoring.

    Composite weights (Preist et al. 2019; Acquisti et al. 2015; Whitten & Tygar 1999):
      Energy     40% — primary sustainability metric (Preist et al., ACM CHI 2019)
      Performance 30% — dominant user-perceived quality metric
      Privacy    20% — significant but secondary concern (Acquisti et al., Science 2015)
      Security   10% — frequently subordinated to usability (Whitten & Tygar, USENIX 1999)
    """
    print("🏆 SafeWeb Browser Recommendation")
    print("=" * 60)

    db = DatabaseManager()

    # Get hardware context from the most recent test run
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM test_runs")
        if cursor.fetchone()[0] == 0:
            print("\n❌ No data. Run: safeweb run-tests first.")
            sys.exit(1)

        cursor.execute("""
            SELECT os_info, hardware_info FROM test_runs
            ORDER BY timestamp DESC LIMIT 1
        """)
        hw = cursor.fetchone()
        os_info = hw[0] or 'Unknown OS'
        hw_info = hw[1] or 'Unknown hardware'

    print(f"\n💻 System: {os_info} | {hw_info}")
    print("⚠️  Results are specific to this machine. CPU architecture (e.g. Apple M4 vs M1 vs Intel)")
    print("   affects power draw — scores are not directly comparable across different hardware.\n")

    from src.monitoring.privacy_security_monitor import PrivacySecurityMonitor
    monitor = PrivacySecurityMonitor()

    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT
                tr.browser_name,
                tr.search_engine,
                COUNT(*) as tests,
                AVG(ec.estimated_energy_wh) as avg_energy,
                AVG(ec.cpu_power_watts + ec.memory_power_watts + ec.base_power_watts + ec.display_power_watts) as avg_local_watts,
                AVG(tr.duration_seconds) as avg_duration,
                AVG(sm_cpu.value) as avg_cpu,
                AVG(sm_mem.value) as avg_memory,
                AVG(psm.https_enabled) as avg_https,
                AVG(psm.third_party_cookies) as avg_3p_cookies,
                AVG(psm.tracker_count) as avg_trackers,
                AVG(psm.mixed_content) as avg_mixed,
                AVG(psm.cookie_count) as avg_cookies,
                AVG(psm.secure_cookies) as avg_secure_cookies
            FROM test_runs tr
            JOIN energy_calculations ec ON tr.id = ec.test_run_id
            LEFT JOIN system_metrics sm_cpu ON tr.id = sm_cpu.test_run_id AND sm_cpu.metric_type = 'cpu_mean'
            LEFT JOIN system_metrics sm_mem ON tr.id = sm_mem.test_run_id AND sm_mem.metric_type = 'memory_mean_mb'
            LEFT JOIN privacy_security_metrics psm ON tr.id = psm.test_run_id
            GROUP BY tr.browser_name, tr.search_engine
            HAVING tests >= 1
        """)
        rows = cursor.fetchall()

    if not rows:
        print("❌ No completed tests found.")
        sys.exit(1)

    combos = []
    for row in rows:
        avg_metrics = {
            'https_enabled': bool(round(row[8] or 1)),
            'third_party_cookies': row[9] or 0,
            'tracker_count': row[10] or 0,
            'mixed_content': row[11] or 0,
            'cookie_count': row[12] or 1,
            'secure_cookies': row[13] or 0,
        }
        combos.append({
            'browser': row[0].title(),
            'engine': row[1].title(),
            'tests': row[2],
            'energy': row[3] or 0,
            'duration': row[5] or 0,
            'cpu': row[6] or 0,
            'memory': row[7] or 0,
            'privacy': monitor.calculate_privacy_score(avg_metrics),
            'security': monitor.calculate_security_score(avg_metrics),
        })

    # Normalise each metric across all combos (0–1 scale)
    def norm(values, higher_is_better=False):
        mn, mx = min(values), max(values)
        if mx == mn:
            return [1.0] * len(values)
        if higher_is_better:
            return [(v - mn) / (mx - mn) for v in values]
        else:
            return [(mx - v) / (mx - mn) for v in values]  # lower = better → higher score

    energies  = norm([c['energy']   for c in combos])
    cpus      = norm([c['cpu']      for c in combos])
    memories  = norm([c['memory']   for c in combos])
    durations = norm([c['duration'] for c in combos])
    privacies = norm([c['privacy']  for c in combos], higher_is_better=True)
    securities= norm([c['security'] for c in combos], higher_is_better=True)

    # Composite score — weights from literature (see docstring)
    WEIGHTS = {'energy': 0.40, 'performance': 0.30, 'privacy': 0.20, 'security': 0.10}

    for i, c in enumerate(combos):
        perf = (cpus[i] + memories[i] + durations[i]) / 3
        c['score'] = (
            WEIGHTS['energy']      * energies[i] +
            WEIGHTS['performance'] * perf +
            WEIGHTS['privacy']     * privacies[i] +
            WEIGHTS['security']    * securities[i]
        )

    combos.sort(key=lambda x: x['score'], reverse=True)

    # Print ranked table
    print(f"{'Rank':<6} {'Browser+Engine':<22} {'Score':<8} {'Energy(Wh)':<12} {'CPU%':<7} {'Privacy':<9} {'Security':<10} {'Tests'}")
    print("-" * 85)
    for rank, c in enumerate(combos, 1):
        label = f"{c['browser']}+{c['engine']}"
        medal = "🥇" if rank == 1 else ("🥈" if rank == 2 else ("🥉" if rank == 3 else f"#{rank} "))
        print(f"{medal:<6} {label:<22} {c['score']:.3f}   {c['energy']:<12.3f} {c['cpu']:<7.1f} {c['privacy']:<9.1f} {c['security']:<10.1f} {c['tests']}")

    best = combos[0]
    print(f"\n✅ Recommendation for your {hw_info}:")
    print(f"   Use {best['browser']} with {best['engine']}")
    print(f"   Composite score: {best['score']:.3f}/1.000")
    print(f"   Energy: {best['energy']:.3f} Wh | Privacy: {best['privacy']:.1f}/10 | Security: {best['security']:.1f}/10")
    print(f"\n📌 Scoring weights: Energy 40% · Performance 30% · Privacy 20% · Security 10%")
    print(f"   (Preist et al. 2019; Acquisti et al. 2015; Whitten & Tygar 1999)")
    print(f"   Results are limited to {len(combos)} tested combination(s) on this machine.\n")


def compare(args):
    """Compare two browser+engine configurations"""
    print("🏆 SafeWeb Configuration Comparison")
    print("=" * 60)
    
    if not args.config1 or not args.config2:
        print("❌ Please specify two configurations to compare")
        print("   Example: safeweb compare chrome:google edge:duckduckgo")
        sys.exit(1)
    
    # Parse configurations
    try:
        browser1, engine1 = args.config1.split(':')
        browser2, engine2 = args.config2.split(':')
    except:
        print("❌ Invalid format. Use: browser:engine (e.g., chrome:google)")
        sys.exit(1)
    
    db = DatabaseManager()
    
    # Get data for both configurations
    with db.get_connection() as conn:
        cursor = conn.cursor()
        
        query = """
        SELECT 
            tr.browser_name,
            tr.search_engine,
            tr.ai_enabled,
            AVG(ec.estimated_energy_wh) as energy,
            AVG(sm1.value) as cpu_mean,
            AVG(sm2.value) as cpu_max,
            AVG(sm3.value) as memory_mean_mb,
            AVG(sm4.value) as memory_mean_percent,
            AVG(sm5.value) as network_bytes,
            AVG(sm6.value) as disk_io_bytes,
            AVG(tr.duration_seconds) as duration,
            COUNT(*) as tests
        FROM test_runs tr
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        LEFT JOIN system_metrics sm1 ON tr.id = sm1.test_run_id AND sm1.metric_type = 'cpu_mean'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'cpu_max'
        LEFT JOIN system_metrics sm3 ON tr.id = sm3.test_run_id AND sm3.metric_type = 'memory_mean_mb'
        LEFT JOIN system_metrics sm4 ON tr.id = sm4.test_run_id AND sm4.metric_type = 'memory_mean_percent'
        LEFT JOIN system_metrics sm5 ON tr.id = sm5.test_run_id AND sm5.metric_type = 'network_bytes'
        LEFT JOIN system_metrics sm6 ON tr.id = sm6.test_run_id AND sm6.metric_type = 'disk_io_bytes'
        WHERE LOWER(tr.browser_name) = LOWER(?) AND LOWER(tr.search_engine) = LOWER(?)
        GROUP BY tr.browser_name, tr.search_engine, tr.ai_enabled
        """
        
        cursor.execute(query, (browser1, engine1))
        config1_data = cursor.fetchall()
        
        cursor.execute(query, (browser2, engine2))
        config2_data = cursor.fetchall()
    
    if not config1_data or not config2_data:
        print(f"❌ No data found for one or both configurations")
        print(f"   Run tests first: safeweb run-tests -b {browser1} {browser2} -e {engine1} {engine2}")
        sys.exit(1)
    
    # Use first result (or aggregate if multiple)
    c1 = config1_data[0]
    c2 = config2_data[0]
    
    # Calculate scores (lower is better, normalize to 0-100)
    def normalize_score(val1, val2):
        """Lower value gets higher score"""
        if val1 == 0 and val2 == 0:
            return 50, 50
        total = val1 + val2
        if total == 0:
            return 50, 50
        return (val2/total)*100, (val1/total)*100
    
    # Energy score (40%)
    energy1, energy2 = c1[3] or 0, c2[3] or 0
    energy_score1, energy_score2 = normalize_score(energy1, energy2)
    
    # Performance score (30%) - average of CPU, Memory, Duration, Network, Disk
    cpu1, cpu2 = c1[4] or 0, c2[4] or 0
    mem1, mem2 = c1[7] or 0, c2[7] or 0
    dur1, dur2 = c1[10] or 0, c2[10] or 0
    net1, net2 = (c1[8] or 0)/1e6, (c2[8] or 0)/1e6  # Convert to MB
    disk1, disk2 = (c1[9] or 0)/1e6, (c2[9] or 0)/1e6
    
    cpu_s1, cpu_s2 = normalize_score(cpu1, cpu2)
    mem_s1, mem_s2 = normalize_score(mem1, mem2)
    dur_s1, dur_s2 = normalize_score(dur1, dur2)
    net_s1, net_s2 = normalize_score(net1, net2)
    disk_s1, disk_s2 = normalize_score(disk1, disk2)
    
    perf_score1 = (cpu_s1 + mem_s1 + dur_s1 + net_s1 + disk_s1) / 5
    perf_score2 = (cpu_s2 + mem_s2 + dur_s2 + net_s2 + disk_s2) / 5
    
    # Privacy & Security scores (calculated from actual metrics)
    # Get privacy/security data from database
    with db.get_connection() as conn:
        cursor = conn.cursor()
        
        privacy_query = """
        SELECT 
            AVG(CASE WHEN https_enabled THEN 10 ELSE 0 END) as https_score,
            AVG(CASE WHEN third_party_cookies < 5 THEN 10 ELSE MAX(0, 10 - third_party_cookies/2.0) END) as cookie_score,
            AVG(CASE WHEN tracker_count < 3 THEN 10 ELSE MAX(0, 10 - tracker_count/1.5) END) as tracker_score,
            AVG(CASE WHEN mixed_content = 0 THEN 10 ELSE MAX(0, 10 - mixed_content*2) END) as security_score
        FROM privacy_security_metrics psm
        JOIN test_runs tr ON psm.test_run_id = tr.id
        WHERE LOWER(tr.browser_name) = LOWER(?) AND LOWER(tr.search_engine) = LOWER(?)
        """
        
        cursor.execute(privacy_query, (browser1, engine1))
        p1 = cursor.fetchone()
        
        cursor.execute(privacy_query, (browser2, engine2))
        p2 = cursor.fetchone()
    
    # Calculate privacy/security scores from actual metrics (or use defaults if no data)
    if p1 and p1[0] is not None:
        privacy1 = (p1[0] + p1[1] + p1[2]) / 3  # Average of https, cookie, tracker scores
        security1 = (p1[0] + p1[3]) / 2  # Average of https and mixed content scores
    else:
        # Fallback to research scores if no privacy data collected
        privacy_scores = {'brave': 10, 'tor': 10, 'safari': 8, 'firefox': 8, 'edge': 6, 'chrome': 5, 'opera': 5}
        security_scores = {'safari': 9, 'edge': 9, 'brave': 9, 'chrome': 8, 'firefox': 8, 'opera': 7, 'tor': 6}
        privacy1 = privacy_scores.get(browser1.lower(), 7)
        security1 = security_scores.get(browser1.lower(), 7)
    
    if p2 and p2[0] is not None:
        privacy2 = (p2[0] + p2[1] + p2[2]) / 3
        security2 = (p2[0] + p2[3]) / 2
    else:
        privacy_scores = {'brave': 10, 'tor': 10, 'safari': 8, 'firefox': 8, 'edge': 6, 'chrome': 5, 'opera': 5}
        security_scores = {'safari': 9, 'edge': 9, 'brave': 9, 'chrome': 8, 'firefox': 8, 'opera': 7, 'tor': 6}
        privacy2 = privacy_scores.get(browser2.lower(), 7)
        security2 = security_scores.get(browser2.lower(), 7)
    
    privacy_score1 = (privacy1 / 10) * 100
    privacy_score2 = (privacy2 / 10) * 100
    security_score1 = (security1 / 10) * 100
    security_score2 = (security2 / 10) * 100
    
    # Weighted total score
    total1 = (energy_score1 * 0.40) + (perf_score1 * 0.30) + (privacy_score1 * 0.20) + (security_score1 * 0.10)
    total2 = (energy_score2 * 0.40) + (perf_score2 * 0.30) + (privacy_score2 * 0.20) + (security_score2 * 0.10)
    
    # Determine winner
    winner = 1 if total1 > total2 else 2
    diff_pct = abs(total1 - total2)
    
    print(f"\n🏆 {browser1.title()} + {engine1.title()} {'WINS!' if winner == 1 else ''}")
    print(f"🏆 {browser2.title()} + {engine2.title()} {'WINS!' if winner == 2 else ''}")
    print(f"\n{diff_pct:.0f}% more efficient overall")
    print(f"(Energy: 40%, Performance: 30%, Privacy: 20%, Security: 10%)")
    
    print(f"\n📊 Detailed Scores:")
    print(f"\n{browser1.title()} + {engine1.title()}:")
    print(f"  Energy:      {energy_score1:.1f}/100  ({energy1:.2f} Wh)")
    print(f"  Performance: {perf_score1:.1f}/100")
    print(f"  Privacy:     {privacy_score1:.1f}/100  ({privacy1}/10)")
    print(f"  Security:    {security_score1:.1f}/100  ({security1}/10)")
    print(f"  TOTAL:       {total1:.1f}/100")
    
    print(f"\n{browser2.title()} + {engine2.title()}:")
    print(f"  Energy:      {energy_score2:.1f}/100  ({energy2:.2f} Wh)")
    print(f"  Performance: {perf_score2:.1f}/100")
    print(f"  Privacy:     {privacy_score2:.1f}/100  ({privacy2}/10)")
    print(f"  Security:    {security_score2:.1f}/100  ({security2}/10)")
    print(f"  TOTAL:       {total2:.1f}/100")
    
    print(f"\n📈 Metrics Comparison:")
    print(f"{'Metric':<20} {browser1.title():<15} {browser2.title():<15} {'Winner'}")
    print("-" * 60)
    print(f"{'Energy (Wh)':<20} {energy1:<15.2f} {energy2:<15.2f} {'Config 1 ✓' if energy1 < energy2 else 'Config 2 ✓'}")
    print(f"{'CPU Mean (%)':<20} {cpu1:<15.1f} {cpu2:<15.1f} {'Config 1 ✓' if cpu1 < cpu2 else 'Config 2 ✓'}")
    print(f"{'Memory (MB)':<20} {mem1:<15.0f} {mem2:<15.0f} {'Config 1 ✓' if mem1 < mem2 else 'Config 2 ✓'}")
    print(f"{'Network (MB)':<20} {net1:<15.1f} {net2:<15.1f} {'Config 1 ✓' if net1 < net2 else 'Config 2 ✓'}")
    print(f"{'Disk I/O (MB)':<20} {disk1:<15.1f} {disk2:<15.1f} {'Config 1 ✓' if disk1 < disk2 else 'Config 2 ✓'}")
    print(f"{'Duration (s)':<20} {dur1:<15.1f} {dur2:<15.1f} {'Config 1 ✓' if dur1 < dur2 else 'Config 2 ✓'}")
    print()


def report(args):
    """Generate report"""
    print("Generating Report")
    print("=" * 60)

    analyzer = StatisticalAnalyzer()
    reports_dir = ensure_reports_dir()
    output = args.output or str(reports_dir / 'safeweb_report.md')

    print(f"Output: {output}")
    if args.charts:
        print("Including charts")
    print()
    
    analyzer.generate_report(output, include_charts=args.charts)
    print(f"✅ Report: {output}")


def list_browsers(args):
    """List installed browsers"""
    print("🔍 Installed Browsers")
    print("=" * 60)
    
    installed = detect_installed_browsers()
    print(f"\n✅ Installed ({len(installed)}):")
    for b in installed:
        print(f"   • {BROWSERS[b]['name']}")
    
    not_installed = [b for b in BROWSERS if b not in installed]
    if not_installed:
        print(f"\n❌ Not Installed ({len(not_installed)}):")
        for b in not_installed:
            print(f"   • {BROWSERS[b]['name']}")
    print()


def main():
    ensure_directories()
    
    parser = argparse.ArgumentParser(
        description='SafeWeb - Browser Safety & Sustainability Testing',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  safeweb list                          # Show installed browsers
  safeweb run-tests                     # Test all browsers
  safeweb run-tests -b chrome firefox   # Test specific browsers
  safeweb run-tests -t 25               # 25 trials (full study)
  safeweb analyze                       # View results
  safeweb analyze --ai-comparison       # AI impact
  safeweb export -f csv                 # Export to CSV
  safeweb report --charts               # Generate report
        """
    )
    
    subparsers = parser.add_subparsers(dest='command')
    
    subparsers.add_parser('list', help='List installed browsers')
    
    subparsers.add_parser('explain', help='Explain the Three-Lens Framework (Privacy, Security, Sustainability)')
    
    test_p = subparsers.add_parser('run-tests', help='Run tests')
    test_p.add_argument('-b', '--browsers', nargs='+', 
                       choices=['chrome', 'firefox', 'safari', 'edge', 'opera', 'brave', 'tor'])
    test_p.add_argument('-e', '--engines', nargs='+',
                       choices=['google', 'bing', 'duckduckgo', 'yahoo'])
    test_p.add_argument('-t', '--trials', type=int, default=5)
    test_p.add_argument('-q', '--query', type=str,
                       help='Custom search query (default: predefined queries)')
    test_p.add_argument('--dry-run', action='store_true')
    
    analyze_p = subparsers.add_parser('analyze', help='Analyze results')
    analyze_p.add_argument('-b', '--browser', 
                          choices=['chrome', 'firefox', 'safari', 'edge', 'opera', 'brave', 'tor'])
    analyze_p.add_argument('--ai-comparison', action='store_true')
    
    compare_p = subparsers.add_parser('compare', help='Compare two configurations')
    compare_p.add_argument('config1', help='First config (browser:engine, e.g., chrome:google)')
    compare_p.add_argument('config2', help='Second config (browser:engine, e.g., edge:duckduckgo)')
    
    export_p = subparsers.add_parser('export', help='Export results')
    export_p.add_argument('-f', '--format', choices=['csv'], default='csv')
    export_p.add_argument('-o', '--output')
    
    subparsers.add_parser('recommend', help='Recommend best browser+engine for your machine')

    report_p = subparsers.add_parser('report', help='Generate report')
    report_p.add_argument('-o', '--output')
    report_p.add_argument('--charts', action='store_true')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    try:
        if args.command == 'list':
            list_browsers(args)
        elif args.command == 'explain':
            explain(args)
        elif args.command == 'run-tests':
            run_tests(args)
        elif args.command == 'analyze':
            analyze(args)
        elif args.command == 'compare':
            compare(args)
        elif args.command == 'export':
            export(args)
        elif args.command == 'report':
            report(args)
        elif args.command == 'recommend':
            recommend(args)
    except KeyboardInterrupt:
        print("\n⚠️  Interrupted")
        sys.exit(130)
    except SystemExit:
        raise
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
