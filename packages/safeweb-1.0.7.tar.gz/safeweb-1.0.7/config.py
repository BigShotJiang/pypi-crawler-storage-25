"""SafeWeb Configuration"""
import os
import platform
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent

# Zip users run from inside the safeweb-cli folder (safeweb.py is in cwd).
# Pip users run from any folder (safeweb.py is not in cwd).
if (Path.cwd() / "safeweb.py").exists():
    RESULTS_DIR = PROJECT_ROOT / "results"   # zip: save inside safeweb-cli/
else:
    RESULTS_DIR = Path.cwd() / "results"     # pip: save in user's current folder

DATABASE_PATH = RESULTS_DIR / "database" / "safe_web.db"

def detect_browser_path(browser_name):
    """Auto-detect browser on macOS by checking known paths then searching /Applications"""
    if platform.system() != "Darwin":
        return None

    known_paths = {
        "firefox": [
            "/Applications/Firefox.app/Contents/MacOS/firefox",
            "/Applications/Firefox Developer Edition.app/Contents/MacOS/firefox",
            "/Applications/Firefox Nightly.app/Contents/MacOS/firefox",
        ],
        "safari": ["/Applications/Safari.app/Contents/MacOS/Safari"],
        "edge": ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"],
        "opera": ["/Applications/Opera.app/Contents/MacOS/Opera"],
        "brave": ["/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"],
        "tor": ["/Applications/Tor Browser.app/Contents/MacOS/firefox"],
    }

    # Check known paths first
    for path in known_paths.get(browser_name, []):
        if os.path.exists(path):
            return path

    # Fallback: search /Applications for the binary by browser name keyword
    search_keywords = {
        "firefox": "firefox", "safari": "Safari", "edge": "Edge",
        "opera": "Opera", "brave": "Brave", "tor": "Tor"
    }
    keyword = search_keywords.get(browser_name)
    if keyword:
        import subprocess
        try:
            result = subprocess.run(
                ["find", "/Applications", "-name", keyword, "-type", "f"],
                capture_output=True, text=True, timeout=5
            )
            for line in result.stdout.strip().splitlines():
                if os.path.exists(line):
                    return line
        except Exception:
            pass

    return None

BROWSERS = {
    "chrome": {"name": "Google Chrome", "executable_path": None},
    "firefox": {"name": "Mozilla Firefox", "executable_path": detect_browser_path("firefox")},
    "safari": {"name": "Safari", "executable_path": detect_browser_path("safari")},
    "edge": {"name": "Microsoft Edge", "executable_path": detect_browser_path("edge")},
    "opera": {"name": "Opera", "executable_path": detect_browser_path("opera")},
    "brave": {"name": "Brave Browser", "executable_path": detect_browser_path("brave")},
    "tor": {"name": "Tor Browser", "executable_path": detect_browser_path("tor")}
}

SEARCH_ENGINES = {
    "google": {"name": "Google", "url": "https://www.google.com", "search_box_selector": "textarea[name='q']"},
    "bing": {"name": "Bing", "url": "https://www.bing.com", "search_box_selector": "#sb_form_q"},
    "duckduckgo": {"name": "DuckDuckGo", "url": "https://duckduckgo.com", "search_box_selector": "input[name='q']"},
    "yahoo": {"name": "Yahoo", "url": "https://search.yahoo.com", "search_box_selector": "input[name='p']"}
}

TEST_CONFIG = {
    "trials_per_combination": 5,
    "page_load_timeout": 60,
    "monitoring_interval": 1.0
}

def ensure_directories():
    """Create necessary directories"""
    for d in [RESULTS_DIR, RESULTS_DIR/"database", RESULTS_DIR/"exports"]:
        d.mkdir(parents=True, exist_ok=True)

def ensure_reports_dir():
    """Create reports directory only when generating a report"""
    (RESULTS_DIR / "reports").mkdir(parents=True, exist_ok=True)
    return RESULTS_DIR / "reports"
