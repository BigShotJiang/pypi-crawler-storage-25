# SafeWeb CLI - Workflow Guide

## How It Works

```
+-------------------------------------------------------------+
|                    USER'S MAC COMPUTER                       |
|                                                              |
|  1. User runs: ./safeweb_run.sh list                        |
|     |                                                        |
|  2. Tool detects installed browsers                         |
|     Chrome    Firefox    Safari                              |
|                                                              |
|  3. User runs: ./safeweb_run.sh run-tests -t 1             |
|     |                                                        |
|  4. Tool automatically:                                      |
|     - Opens Chrome  -> searches -> measures for 30s         |
|     - Opens Firefox -> searches -> measures for 30s         |
|     - Opens Safari  -> searches -> measures for 30s         |
|                                                              |
|  5. Real-time metrics collected (every ~0.37 seconds):      |
|     CPU:     42.3% (mean, max, min)                         |
|     Memory:  2450 MB (mean, max, %)                         |
|     Energy:  0.285 Wh (local + remote)                      |
|     Network: 1.2 MB (sent/received)                         |
|     Disk:    450 KB (read/write)                            |
|     Page Load: 2.3s                                         |
|     AI Detected: Yes/No                                     |
|     ... 35+ total metrics                                   |
|                                                              |
|  6. Data saved locally:                                      |
|     results/database/safe_web.db                            |
|                                                              |
|  7. User analyzes: ./safeweb_run.sh analyze                 |
|     |                                                        |
|  8. Tool shows comparison:                                   |
|     Best Energy: Chrome (0.285 Wh)                          |
|     Best CPU:    Safari (38.5%)                             |
|     Best Memory: Safari (2100 MB)                           |
|                                                              |
|  9. User compares:                                           |
|     ./safeweb_run.sh compare chrome:google firefox:duckduckgo |
|     |                                                        |
|  10. Tool shows winner with weighted scoring:                |
|      Firefox + DuckDuckGo WINS (79.3/100)                   |
|      Energy: 40%, Performance: 30%, Privacy: 20%, Security: 10% |
|                                                              |
|  11. User exports: ./safeweb_run.sh export -f csv           |
|      |                                                       |
|  12. CSV file created with all 35+ metrics:                 |
|      results/exports/safeweb_results.csv                    |
|                                                              |
+-------------------------------------------------------------+
```

---

## Data Flow

```
+------------------+
|    User Mac      |
+--------+---------+
         |
         +-> [1] ./safeweb_run.sh list
         |        |
         |   Detect Browsers
         |        |
         |   Show: Chrome, Firefox, Safari
         |
         +-> [2] ./safeweb_run.sh run-tests
         |        |
         |   +-----------------------------+
         |   | For each browser:           |
         |   | 1. Launch browser           |
         |   | 2. Open search engine       |
         |   | 3. Perform search           |
         |   | 4. Monitor metrics (1s)     |
         |   | 5. Detect AI usage          |
         |   | 6. Save to database         |
         |   | 7. Close browser            |
         |   | 8. Repeat for next combo    |
         |   +-----------------------------+
         |        |
         |   SQLite Database
         |   (results/database/safe_web.db)
         |        |
         |   [All 35+ metrics stored]
         |
         +-> [3] ./safeweb_run.sh analyze
         |        |
         |   Read Database
         |        |
         |   Calculate Statistics
         |        |
         |   Show Comparison Table
         |
         +-> [4] ./safeweb_run.sh export -f csv
         |        |
         |   Read Database
         |        |
         |   Generate CSV
         |        |
         |   results/exports/safeweb_results.csv
         |
         +-> [5] ./safeweb_run.sh report --charts
                  |
             Read Database
                  |
             Generate Analysis
                  |
             Create Charts (PNG)
                  |
             results/reports/safeweb_report.md
```

---

## Test Execution Flow

```
START: ./safeweb_run.sh run-tests -b chrome firefox -t 3
  |
+-----------------------------------------------------------+
| Test Configuration                                         |
| - Browsers: Chrome, Firefox                               |
| - Search Engines: Google, Bing, DuckDuckGo, Yahoo        |
| - Trials: 3 per combination                               |
| - Total Tests: 2 browsers x 4 engines x 3 trials = 24    |
| - Estimated Time: ~24 minutes                             |
+-----------------------------------------------------------+
  |
+-----------------------------------------------------------+
| Test 1: Chrome + Google                                    |
| +-------------------------------------------------------+ |
| | 1. Launch Chrome                                      | |
| | 2. Navigate to google.com                             | |
| | 3. Start monitoring (CPU, memory, network, etc.)      | |
| | 4. Enter query: "What is climate change?"             | |
| | 5. Wait for page load                                 | |
| | 6. Detect AI summary                                  | |
| | 7. Collect metrics for 30 seconds (~81 data points)   | |
| | 8. Calculate energy consumption                       | |
| | 9. Save to database                                   | |
| | 10. Close Chrome                                      | |
| +-------------------------------------------------------+ |
| Test 1 complete (~30-40 seconds)                          |
+-----------------------------------------------------------+
  |
  ... (23 more tests)
  |
+-----------------------------------------------------------+
| All Tests Complete                                         |
| - Total: 24 tests                                          |
| - Data saved: results/database/safe_web.db                |
+-----------------------------------------------------------+
  |
END: Ready for analysis
```

---

## Metrics Collection Timeline

```
Time: 0s --------------------------------------------------------> 30s
      |                                                              |
      +- Browser Launch                                             |
      +- Navigate to Search Engine                                  |
      +- Enter Query                                                |
      +- Page Load Start                                            |
      |                                                              |
      +- [Monitoring Active]                                        |
      |   +- CPU:     45.2% -> 42.1% -> 43.8% -> 41.5%            |
      |   +- Memory:  2450MB -> 2480MB -> 2510MB                   |
      |   +- Network: 0KB -> 850KB -> 1.2MB                        |
      |   +- Disk:    0KB -> 120KB -> 450KB                        |
      |   +- Energy:  Calculating...                                |
      |                                                              |
      +- Page Load Complete (2.3s)                                  |
      +- AI Detection: Yes/No                                       |
      +- Continue Monitoring...                                     |
      |                                                              |
      +- Stop Monitoring                                            |
         Calculate Averages                                         |
         Save to Database                                           |
         Close Browser                                              |
```

---

## Metrics Collected (35+)

```
+-----------------------------------------------------------+
|                   METRICS COLLECTED                        |
+-----------------------------------------------------------+
|                                                            |
| CPU METRICS (3)                                           |
|   - CPU Mean %                                            |
|   - CPU Max %                                             |
|   - CPU Min %                                             |
|                                                            |
| MEMORY METRICS (4)                                        |
|   - Memory Mean MB                                        |
|   - Memory Max MB                                         |
|   - Memory Mean %                                         |
|   - Memory Max %                                          |
|                                                            |
| NETWORK METRICS (3)                                       |
|   - Bytes Sent                                            |
|   - Bytes Received                                        |
|   - Total Bytes                                           |
|                                                            |
| DISK METRICS (3)                                          |
|   - Disk Read Bytes                                       |
|   - Disk Write Bytes                                      |
|   - Total Disk I/O                                        |
|                                                            |
| QUALITY METRICS (1)                                       |
|   - Data Points (number of measurements)                  |
|                                                            |
| ENERGY METRICS (4)                                        |
|   - Total Energy (Wh)                                     |
|   - CPU Power (watts)                                     |
|   - Memory Power (watts)                                  |
|   - Base Power (watts)                                    |
|                                                            |
| TEST INFO (9)                                             |
|   - Browser Name                                          |
|   - Browser Version (auto-detected)                       |
|   - Search Engine                                         |
|   - AI Enabled (Yes/No)                                   |
|   - Query Text                                            |
|   - Duration (seconds)                                    |
|   - Page Load Time                                        |
|   - Status (completed/failed)                             |
|   - Timestamp                                             |
|                                                            |
| AI DETECTION (2)                                          |
|   - AI Features Detected                                  |
|   - Confidence Score (0-1)                                |
|                                                            |
| TOTAL: 35+ METRICS PER TEST                               |
+-----------------------------------------------------------+
```

---

## Sharing Workflow

```
+-----------------------------------------------------------+
|                  YOU (Project Creator)                     |
+------------------------+----------------------------------+
                         |
                         +-> Option 1: Zip Folder
                         |   $ cd ~/Desktop
                         |   $ zip -r safeweb-cli.zip safeweb-cli
                         |   safeweb-cli.zip (ready to share)
                         |
                         +-> Option 2: Create Package
                             $ cd safeweb-cli
                             $ python3 setup.py sdist
                             dist/safeweb-1.0.0.tar.gz

                         | [Send via email/drive/USB]

+-----------------------------------------------------------+
|                  RECIPIENT (Other Users)                   |
+------------------------+----------------------------------+
                         |
                         +-> From Zip:
                         |   $ unzip safeweb-cli.zip
                         |   $ cd safeweb-cli
                         |   $ ./safeweb_run.sh list
                         |   (setup is automatic on first run)
                         |
                         +-> From Package:
                             $ pip3 install safeweb-1.0.0.tar.gz
                             $ safeweb list
                             $ safeweb run-tests

+-----------------------------------------------------------+
|              RESULTS ON THEIR MACHINE                      |
|  - Tests run on their hardware                            |
|  - Data saved in their results/ folder                    |
|  - Can export and analyze locally                         |
|  - No internet needed (except for actual searches)        |
+-----------------------------------------------------------+
```

---

## Example: Student Use Case

```
DAY 1: Setup
+-----------------------------------------------------------+
| Student receives: safeweb-cli.zip                         |
| |                                                          |
| $ unzip safeweb-cli.zip                                   |
| $ cd safeweb-cli                                          |
| $ ./safeweb_run.sh list                                   |
| Setup complete (automatic, ~60 seconds first run)         |
+-----------------------------------------------------------+

DAY 2: Data Collection
+-----------------------------------------------------------+
| $ ./safeweb_run.sh list                                   |
| Detected: Chrome, Firefox, Safari                         |
| |                                                          |
| $ ./safeweb_run.sh run-tests -t 10                        |
| Running tests...                                          |
| Duration: ~20 minutes                                     |
| Complete. Data saved.                                     |
+-----------------------------------------------------------+

DAY 3: Analysis
+-----------------------------------------------------------+
| $ ./safeweb_run.sh analyze                                |
| Browser comparison table displayed                        |
| |                                                          |
| $ ./safeweb_run.sh analyze --ai-comparison                |
| AI uses 2.3x more energy                                  |
| |                                                          |
| $ ./safeweb_run.sh export -f excel                        |
| Excel file created                                        |
| |                                                          |
| $ ./safeweb_run.sh report --charts                        |
| Full report with charts generated                         |
+-----------------------------------------------------------+

DAY 4: Submission
+-----------------------------------------------------------+
| Submit:                                                    |
| - results/exports/safeweb_results.xlsx                    |
| - results/reports/safeweb_report.md                       |
| - Charts (PNG files)                                      |
+-----------------------------------------------------------+
```

---

## Summary

What the tool does:
1. Auto-detects installed browsers on user's Mac
2. Runs automated tests with real searches
3. Collects 35+ metrics in real-time (30 seconds per test)
4. Saves everything locally in SQLite database
5. Generates comparison tables with weighted scoring
6. Exports to CSV/Excel/JSON
7. Creates comprehensive reports

Why it is easy to share:
- No web server needed
- No complex setup -- ./safeweb_run.sh handles everything
- Works on any Mac with Python 3.8+
- All data stays local
- Just zip and send

Key features:
- Auto-detection: Finds browsers automatically
- Custom queries: Use -q "your query" for any search
- Flexible trials: -t 1 for quick tests, -t 25 for research
- Weighted scoring: Energy 40%, Performance 30%, Privacy 20%, Security 10%
- Complete export: All 35+ metrics in CSV/Excel
- Local storage: Each user has their own database
