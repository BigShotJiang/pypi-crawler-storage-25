#!/bin/bash
# SafeWeb CLI Launcher
# Usage: ./safeweb_run.sh list
#        ./safeweb_run.sh run-tests -b chrome firefox -e google -t 2
#        ./safeweb_run.sh analyze
#        ./safeweb_run.sh recommend

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="$SCRIPT_DIR/venv"

# ── Check Python 3 is available ──────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "❌ Python 3 is not installed."
    echo "   Install it from https://www.python.org/downloads/ and try again."
    exit 1
fi

PYTHON_MINOR=$(python3 -c "import sys; print(sys.version_info.minor)")
PYTHON_MAJOR=$(python3 -c "import sys; print(sys.version_info.major)")
if [ "$PYTHON_MAJOR" -lt 3 ] || [ "$PYTHON_MINOR" -lt 8 ]; then
    echo "❌ Python 3.8 or higher is required."
    echo "   Your version: $(python3 --version)"
    echo "   Download a newer version from https://www.python.org/downloads/"
    exit 1
fi

find_venv_python() {
    find "$VENV/bin" -name "python3*" \( -type f -o -type l \) 2>/dev/null | sort | tail -1
}

# ── First run: create venv and install dependencies ──────────────────────
VENV_PYTHON=$(find_venv_python)

if [ -z "$VENV_PYTHON" ]; then
    echo "🔧 First run — setting up SafeWeb (takes ~60 seconds)..."

    python3 -m venv "$VENV"
    if [ $? -ne 0 ]; then
        echo "❌ Failed to create virtual environment."
        echo "   Try running: python3 -m pip install --user virtualenv"
        exit 1
    fi

    "$VENV/bin/pip" install -q -r "$SCRIPT_DIR/requirements.txt"
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install dependencies."
        echo "   Check your internet connection and try again."
        exit 1
    fi

    echo "✅ Setup complete!"
    echo ""

    VENV_PYTHON=$(find_venv_python)
fi

# ── Run via venv python directly — no system PATH conflicts ──────────────
"$VENV_PYTHON" "$SCRIPT_DIR/safeweb.py" "$@"
