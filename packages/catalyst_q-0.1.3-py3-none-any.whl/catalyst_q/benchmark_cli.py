from __future__ import annotations

import argparse
from typing import List, Optional

from catalyst_rain import CatalystQClient

from .benchmarks import write_public_benchmark_artifacts


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="catalyst-q-benchmark",
        description="Generate Catalyst-Q public benchmark harness artifacts.",
    )
    parser.add_argument(
        "--output-dir",
        default="catalyst-q-public-benchmarks",
        help="Directory for generated JSON and Markdown artifacts.",
    )
    parser.add_argument("--shots", type=int, default=1024, help="Shot count used for circuit billing estimates.")
    parser.add_argument(
        "--execute-api",
        action="store_true",
        help="Post each prepared benchmark request to the Catalyst-Q API and record status, latency, and response digests.",
    )
    parser.add_argument(
        "--base-url",
        default="https://api.strategic-innovations.ai/v3turbo",
        help="Catalyst-Q API base URL used with --execute-api.",
    )
    parser.add_argument("--api-key", default=None, help="Optional Catalyst-Q API key or license token.")
    parser.add_argument("--timeout", type=float, default=30.0, help="Per-request timeout in seconds for --execute-api.")
    args = parser.parse_args(argv)

    client = CatalystQClient(api_key=args.api_key, base_url=args.base_url)
    artifacts = write_public_benchmark_artifacts(
        args.output_dir,
        shots=args.shots,
        client=client,
        execute_api=args.execute_api,
        timeout=args.timeout,
    )
    print(f"Wrote {artifacts['json']}")
    print(f"Wrote {artifacts['markdown']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
