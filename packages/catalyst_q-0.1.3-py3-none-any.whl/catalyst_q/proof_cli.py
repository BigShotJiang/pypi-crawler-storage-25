from __future__ import annotations

import argparse
from typing import List, Optional

from .proof import write_proof_artifacts


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="catalyst-q-prove",
        description="Generate Catalyst-Q proof harness artifacts.",
    )
    parser.add_argument(
        "--output-dir",
        default="catalyst-q-proof-results",
        help="Directory for generated proof JSON and Markdown artifacts.",
    )
    args = parser.parse_args(argv)

    artifacts = write_proof_artifacts(args.output_dir)
    print(f"Wrote {artifacts['json']}")
    print(f"Wrote {artifacts['markdown']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
