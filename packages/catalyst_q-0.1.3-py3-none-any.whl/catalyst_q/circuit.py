from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class QuantumCircuit:
    qubits: int
    gates: List[Dict[str, Any]] = field(default_factory=list)

    def _one(self, gate: str, target: int, **params: Any) -> "QuantumCircuit":
        self._check_qubit(target)
        payload: Dict[str, Any] = {"gate": gate, "target": target}
        payload.update(params)
        self.gates.append(payload)
        return self

    def _two(self, gate: str, control: int, target: int, **params: Any) -> "QuantumCircuit":
        self._check_qubit(control)
        self._check_qubit(target)
        payload: Dict[str, Any] = {"gate": gate, "control": control, "target": target}
        payload.update(params)
        self.gates.append(payload)
        return self

    def _three(self, gate: str, control1: int, control2: int, target: int) -> "QuantumCircuit":
        self._check_qubit(control1)
        self._check_qubit(control2)
        self._check_qubit(target)
        self.gates.append({"gate": gate, "controls": [control1, control2], "target": target})
        return self

    def _check_qubit(self, qubit: int) -> None:
        if qubit < 0 or qubit >= self.qubits:
            raise ValueError(f"qubit {qubit} out of range for {self.qubits}-qubit circuit")

    def h(self, target: int) -> "QuantumCircuit":
        return self._one("h", target)

    def x(self, target: int) -> "QuantumCircuit":
        return self._one("x", target)

    def y(self, target: int) -> "QuantumCircuit":
        return self._one("y", target)

    def z(self, target: int) -> "QuantumCircuit":
        return self._one("z", target)

    def s(self, target: int) -> "QuantumCircuit":
        return self._one("s", target)

    def sdg(self, target: int) -> "QuantumCircuit":
        return self._one("sdg", target)

    def t(self, target: int) -> "QuantumCircuit":
        return self._one("t", target)

    def tdg(self, target: int) -> "QuantumCircuit":
        return self._one("tdg", target)

    def p(self, target: int, theta: float) -> "QuantumCircuit":
        return self._one("p", target, theta=theta)

    def rx(self, target: int, theta: float) -> "QuantumCircuit":
        return self._one("rx", target, theta=theta)

    def ry(self, target: int, theta: float) -> "QuantumCircuit":
        return self._one("ry", target, theta=theta)

    def rz(self, target: int, theta: float) -> "QuantumCircuit":
        return self._one("rz", target, theta=theta)

    def u(self, target: int, theta: float, phi: float, lam: float) -> "QuantumCircuit":
        return self._one("u", target, theta=theta, phi=phi, lambda_=lam)

    def sx(self, target: int) -> "QuantumCircuit":
        return self._one("sx", target)

    def cx(self, control: int, target: int) -> "QuantumCircuit":
        return self._two("cx", control, target)

    def cy(self, control: int, target: int) -> "QuantumCircuit":
        return self._two("cy", control, target)

    def cz(self, control: int, target: int) -> "QuantumCircuit":
        return self._two("cz", control, target)

    def cp(self, control: int, target: int, theta: float) -> "QuantumCircuit":
        return self._two("cp", control, target, theta=theta)

    def crx(self, control: int, target: int, theta: float) -> "QuantumCircuit":
        return self._two("crx", control, target, theta=theta)

    def cry(self, control: int, target: int, theta: float) -> "QuantumCircuit":
        return self._two("cry", control, target, theta=theta)

    def crz(self, control: int, target: int, theta: float) -> "QuantumCircuit":
        return self._two("crz", control, target, theta=theta)

    def swap(self, q0: int, q1: int) -> "QuantumCircuit":
        self._check_qubit(q0)
        self._check_qubit(q1)
        self.gates.append({"gate": "swap", "targets": [q0, q1]})
        return self

    def ccx(self, control1: int, control2: int, target: int) -> "QuantumCircuit":
        return self._three("ccx", control1, control2, target)

    def cswap(self, control: int, target1: int, target2: int) -> "QuantumCircuit":
        self._check_qubit(control)
        self._check_qubit(target1)
        self._check_qubit(target2)
        self.gates.append({"gate": "cswap", "control": control, "targets": [target1, target2]})
        return self

    def measure(self, qubit: int, bit: int) -> "QuantumCircuit":
        self._check_qubit(qubit)
        if bit < 0:
            raise ValueError("classical bit index must be non-negative")
        self.gates.append({"gate": "measure", "target": qubit, "bit": bit})
        return self

    def to_payload(self) -> Dict[str, Any]:
        return {"qubits": self.qubits, "circuit": list(self.gates)}
