from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from catalyst_rain import CatalystQClient, RainProtocolKey, execute_prepared_request
from catalyst_rain.client import Transport

from .circuit import QuantumCircuit
from .solvers import KnapsackProblem, MaxCutProblem, PortfolioProblem, QUBOProblem, SATProblem, TSPProblem


PUBLIC_BENCHMARK_SOURCES: Dict[str, str] = {
    "qedc": "https://quantumconsortium.org/publication/application-oriented-performance-benchmarks-for-quantum-computing/",
    "supermarq": "https://www.scholars.northwestern.edu/en/publications/supermarq-a-scalable-quantum-benchmark-suite",
    "qasmbench": "https://github.com/pnnl/QASMBench",
    "mqt_bench": "https://github.com/munich-quantum-toolkit/bench",
    "satlib": "https://www.cs.ubc.ca/~hoos/SATLIB/",
    "tsplib": "https://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/index.html",
    "orlib_knapsack": "https://people.brunel.ac.uk/~mastjjb/jeb/orlib/mknapinfo.html",
    "orlib_portfolio": "https://people.brunel.ac.uk/~mastjjb/jeb/orlib/portinfo.html",
    "biq_mac": "https://biqmac.aau.at/biqmaclib.html",
}


@dataclass(frozen=True)
class PublicBenchmarkCase:
    id: str
    suite: str
    family: str
    workload_type: str
    size_label: str
    source_url: str
    description: str

    def to_catalog_entry(self) -> Dict[str, str]:
        return {
            "id": self.id,
            "suite": self.suite,
            "family": self.family,
            "workload_type": self.workload_type,
            "size_label": self.size_label,
            "source_url": self.source_url,
            "description": self.description,
        }


PUBLIC_BENCHMARK_CASES: List[PublicBenchmarkCase] = [
    PublicBenchmarkCase(
        id="qedc_bernstein_vazirani_8",
        suite="QED-C Application-Oriented Benchmarks",
        family="Bernstein-Vazirani",
        workload_type="circuit",
        size_label="8-bit hidden string",
        source_url=PUBLIC_BENCHMARK_SOURCES["qedc"],
        description="Application-oriented oracle circuit representative used for SDK request validation.",
    ),
    PublicBenchmarkCase(
        id="supermarq_ghz_16",
        suite="SupermarQ",
        family="GHZ",
        workload_type="circuit",
        size_label="16 qubits",
        source_url=PUBLIC_BENCHMARK_SOURCES["supermarq"],
        description="Scalable entanglement workload aligned with SupermarQ-style application benchmarks.",
    ),
    PublicBenchmarkCase(
        id="supermarq_qaoa_ring_8",
        suite="SupermarQ",
        family="QAOA ring",
        workload_type="circuit",
        size_label="8 qubits, one layer",
        source_url=PUBLIC_BENCHMARK_SOURCES["supermarq"],
        description="Parameterized optimization circuit with alternating cost and mixer layers.",
    ),
    PublicBenchmarkCase(
        id="qasmbench_qft_5_qasm",
        suite="QASMBench",
        family="QFT",
        workload_type="qasm",
        size_label="5 qubits",
        source_url=PUBLIC_BENCHMARK_SOURCES["qasmbench"],
        description="OpenQASM request-preparation path modeled on QASMBench-style circuit artifacts.",
    ),
    PublicBenchmarkCase(
        id="mqtbench_grover_6",
        suite="MQT Bench",
        family="Grover",
        workload_type="circuit",
        size_label="6 qubits",
        source_url=PUBLIC_BENCHMARK_SOURCES["mqt_bench"],
        description="Algorithm-level Grover-style circuit for broad SDK gate coverage.",
    ),
    PublicBenchmarkCase(
        id="satlib_random_3sat_20",
        suite="SATLIB",
        family="Random 3-SAT",
        workload_type="solver",
        size_label="20 variables, 86 clauses",
        source_url=PUBLIC_BENCHMARK_SOURCES["satlib"],
        description="DIMACS-style random 3-SAT instance shape for SAT solver payload validation.",
    ),
    PublicBenchmarkCase(
        id="tsplib_euclidean_10",
        suite="TSPLIB",
        family="Euclidean TSP",
        workload_type="solver",
        size_label="10 cities",
        source_url=PUBLIC_BENCHMARK_SOURCES["tsplib"],
        description="Complete integer-distance TSP instance shaped after TSPLIB-style Euclidean problems.",
    ),
    PublicBenchmarkCase(
        id="orlib_mknap_12",
        suite="OR-Library Knapsack",
        family="0/1 knapsack",
        workload_type="solver",
        size_label="12 items",
        source_url=PUBLIC_BENCHMARK_SOURCES["orlib_knapsack"],
        description="Single-constraint knapsack payload derived from OR-Library-style item/capacity data.",
    ),
    PublicBenchmarkCase(
        id="orlib_portfolio_8",
        suite="OR-Library Portfolio",
        family="Cardinality-constrained portfolio",
        workload_type="solver",
        size_label="8 assets",
        source_url=PUBLIC_BENCHMARK_SOURCES["orlib_portfolio"],
        description="Mean/covariance portfolio payload shaped after OR-Library portfolio benchmark fields.",
    ),
    PublicBenchmarkCase(
        id="biqmac_qubo_6",
        suite="Biq Mac Library",
        family="Binary quadratic optimization",
        workload_type="solver",
        size_label="6 binary variables",
        source_url=PUBLIC_BENCHMARK_SOURCES["biq_mac"],
        description="Small dense QUBO payload for public SDK route and validator coverage.",
    ),
    PublicBenchmarkCase(
        id="biqmac_maxcut_6",
        suite="Biq Mac Library",
        family="Max-Cut",
        workload_type="solver",
        size_label="6 nodes, 9 weighted edges",
        source_url=PUBLIC_BENCHMARK_SOURCES["biq_mac"],
        description="Weighted Max-Cut payload for public SDK route and validator coverage.",
    ),
]


def industry_benchmark_catalog() -> List[Dict[str, str]]:
    return [case.to_catalog_entry() for case in PUBLIC_BENCHMARK_CASES]


def run_public_benchmark_harness(
    client: Optional[CatalystQClient] = None,
    shots: int = 1024,
    include_payloads: bool = False,
    execute_api: bool = False,
    timeout: float = 30.0,
    transport: Optional[Transport] = None,
) -> Dict[str, Any]:
    catalyst = client or CatalystQClient()
    rows: List[Dict[str, Any]] = []
    circuit_runs = 0
    solver_runs = 0

    for case in PUBLIC_BENCHMARK_CASES:
        state_key = RainProtocolKey.create(workflow_id=f"public-benchmark-{case.id}", capacity=1024)
        started = time.perf_counter_ns()

        if case.workload_type == "circuit":
            request = _prepare_circuit_case(catalyst, case.id, state_key, shots, circuit_runs)
            circuit_runs += 1
        elif case.workload_type == "qasm":
            request = catalyst.prepare_qasm(
                _qft5_openqasm(),
                rain_key=state_key,
                calls_this_month=circuit_runs,
                shots=shots,
                output_format="counts",
            )
            circuit_runs += 1
        elif case.workload_type == "solver":
            request = _prepare_solver_case(catalyst, case.id, state_key, solver_runs)
            solver_runs += 1
        else:
            raise ValueError(f"unsupported benchmark workload type: {case.workload_type}")

        elapsed_us = (time.perf_counter_ns() - started) / 1000.0
        payload_bytes = len(json.dumps(request.json, sort_keys=True, separators=(",", ":")).encode("utf-8"))
        billing = dict(request.json.get("billing_estimate", {}))
        row: Dict[str, Any] = {
            **case.to_catalog_entry(),
            "prepared_request": {
                "method": request.method,
                "url": request.url,
                "route": _route_path(request.url),
                "anonymous_install": request.headers.get("X-Catalyst-Account-Mode") == "anonymous_install",
            },
            "billing_estimate": billing,
            "payload_bytes": payload_bytes,
            "prepare_time_us": round(elapsed_us, 3),
        }
        if include_payloads:
            row["payload"] = request.json
        if execute_api:
            row["api_execution"] = execute_prepared_request(request, timeout=timeout, transport=transport)
        rows.append(row)

    mode = "live-api" if execute_api else "request-preparation"
    return {
        "harness": "catalyst-q-public-benchmark-harness",
        "harness_version": "0.1.0",
        "generated_at": "deterministic-local",
        "mode": mode,
        "disclaimer": "Public harness results validate SDK request generation and billing estimates; they are not a formal complexity proof.",
        "sources": PUBLIC_BENCHMARK_SOURCES,
        "summary": _summarize(rows),
        "benchmarks": rows,
    }


def write_public_benchmark_artifacts(
    output_dir: Any,
    shots: int = 1024,
    client: Optional[CatalystQClient] = None,
    execute_api: bool = False,
    timeout: float = 30.0,
    transport: Optional[Transport] = None,
) -> Dict[str, str]:
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    report = run_public_benchmark_harness(
        client=client,
        shots=shots,
        execute_api=execute_api,
        timeout=timeout,
        transport=transport,
    )
    json_path = destination / "catalyst_q_public_benchmark_results.json"
    markdown_path = destination / "catalyst_q_public_benchmark_results.md"
    json_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    markdown_path.write_text(_render_markdown(report), encoding="utf-8")
    return {"json": str(json_path), "markdown": str(markdown_path)}


def _prepare_circuit_case(
    client: CatalystQClient,
    case_id: str,
    state_key: RainProtocolKey,
    shots: int,
    calls_this_month: int,
):
    if case_id == "qedc_bernstein_vazirani_8":
        circuit = _bernstein_vazirani_8()
    elif case_id == "supermarq_ghz_16":
        circuit = _ghz(16)
    elif case_id == "supermarq_qaoa_ring_8":
        circuit = _qaoa_ring(8)
    elif case_id == "mqtbench_grover_6":
        circuit = _grover_style_6()
    else:
        raise ValueError(f"unsupported circuit benchmark case: {case_id}")
    return client.prepare_execute(circuit, rain_key=state_key, shots=shots, calls_this_month=calls_this_month)


def _prepare_solver_case(client: CatalystQClient, case_id: str, state_key: RainProtocolKey, runs_this_month: int):
    if case_id == "satlib_random_3sat_20":
        return client.prepare_sat(_random_3sat_20(), rain_key=state_key, solver_runs_this_month=runs_this_month)
    if case_id == "tsplib_euclidean_10":
        return client.prepare_tsp(_euclidean_tsp_10(), rain_key=state_key, solver_runs_this_month=runs_this_month)
    if case_id == "orlib_mknap_12":
        return client.prepare_knapsack(_knapsack_12(), rain_key=state_key, solver_runs_this_month=runs_this_month)
    if case_id == "orlib_portfolio_8":
        return client.prepare_portfolio(_portfolio_8(), rain_key=state_key, solver_runs_this_month=runs_this_month)
    if case_id == "biqmac_qubo_6":
        return client.prepare_qubo(_qubo_6(), rain_key=state_key, solver_runs_this_month=runs_this_month)
    if case_id == "biqmac_maxcut_6":
        return client.prepare_maxcut(_maxcut_6(), rain_key=state_key, solver_runs_this_month=runs_this_month)
    raise ValueError(f"unsupported solver benchmark case: {case_id}")


def _bernstein_vazirani_8() -> QuantumCircuit:
    circuit = QuantumCircuit(9)
    ancilla = 8
    secret = [1, 0, 1, 1, 0, 1, 0, 1]
    circuit.x(ancilla)
    for qubit in range(9):
        circuit.h(qubit)
    for qubit, bit in enumerate(secret):
        if bit:
            circuit.cx(qubit, ancilla)
    for qubit in range(8):
        circuit.h(qubit).measure(qubit, qubit)
    return circuit


def _ghz(qubits: int) -> QuantumCircuit:
    circuit = QuantumCircuit(qubits).h(0)
    for qubit in range(qubits - 1):
        circuit.cx(qubit, qubit + 1)
    for qubit in range(qubits):
        circuit.measure(qubit, qubit)
    return circuit


def _qaoa_ring(qubits: int) -> QuantumCircuit:
    circuit = QuantumCircuit(qubits)
    gamma = 0.6283185307179586
    beta = 0.39269908169872414
    for qubit in range(qubits):
        circuit.h(qubit)
    for qubit in range(qubits):
        target = (qubit + 1) % qubits
        circuit.cx(qubit, target).rz(target, gamma).cx(qubit, target)
    for qubit in range(qubits):
        circuit.rx(qubit, beta).measure(qubit, qubit)
    return circuit


def _grover_style_6() -> QuantumCircuit:
    circuit = QuantumCircuit(6)
    for qubit in range(6):
        circuit.h(qubit)
    circuit.x(1).x(3).ccx(0, 2, 5).cz(5, 4).ccx(0, 2, 5).x(1).x(3)
    for qubit in range(6):
        circuit.h(qubit).x(qubit)
    circuit.h(5).ccx(0, 1, 5).h(5)
    for qubit in range(6):
        circuit.x(qubit).h(qubit).measure(qubit, qubit)
    return circuit


def _qft5_openqasm() -> str:
    lines = ["OPENQASM 2.0;", 'include "qelib1.inc";', "qreg q[5];", "creg c[5];"]
    for target in range(5):
        lines.append(f"h q[{target}];")
        for control in range(target + 1, 5):
            theta = math.pi / (2 ** (control - target))
            lines.append(f"cp({theta:.12f}) q[{control}],q[{target}];")
    lines.extend(["swap q[0],q[4];", "swap q[1],q[3];"])
    for qubit in range(5):
        lines.append(f"measure q[{qubit}] -> c[{qubit}];")
    return "\n".join(lines)


def _random_3sat_20() -> SATProblem:
    clauses: List[List[int]] = []
    for idx in range(86):
        a = (idx * 7) % 20 + 1
        b = (idx * 11 + 3) % 20 + 1
        c = (idx * 13 + 9) % 20 + 1
        clause = [
            a if idx % 2 == 0 else -a,
            -b if idx % 3 == 0 else b,
            c if idx % 5 else -c,
        ]
        clauses.append(clause)
    return SATProblem(clauses=clauses, variables=20)


def _euclidean_tsp_10() -> TSPProblem:
    coords = [
        ("a", 7, 11),
        ("b", 18, 31),
        ("c", 29, 7),
        ("d", 42, 29),
        ("e", 51, 13),
        ("f", 64, 35),
        ("g", 71, 9),
        ("h", 83, 30),
        ("i", 95, 12),
        ("j", 106, 33),
    ]
    distances: List[List[float]] = []
    for _, x0, y0 in coords:
        row = []
        for _, x1, y1 in coords:
            row.append(round(math.hypot(x1 - x0, y1 - y0)))
        distances.append(row)
    return TSPProblem(distances=distances, cities=[name for name, _, _ in coords])


def _knapsack_12() -> KnapsackProblem:
    return KnapsackProblem(
        weights=[12, 7, 11, 8, 9, 6, 14, 3, 5, 10, 13, 4],
        values=[24, 13, 23, 15, 16, 11, 28, 7, 9, 18, 27, 8],
        capacity=48,
    )


def _portfolio_8() -> PortfolioProblem:
    returns = [0.031, 0.044, 0.038, 0.052, 0.027, 0.049, 0.035, 0.041]
    stddev = [0.12, 0.18, 0.15, 0.21, 0.11, 0.2, 0.14, 0.17]
    covariance: List[List[float]] = []
    for i, sigma_i in enumerate(stddev):
        row = []
        for j, sigma_j in enumerate(stddev):
            corr = 1.0 if i == j else 0.18 + 0.03 * ((i + j) % 4)
            row.append(round(sigma_i * sigma_j * corr, 6))
        covariance.append(row)
    return PortfolioProblem(returns=returns, covariance=covariance, risk_tolerance=0.45)


def _qubo_6() -> QUBOProblem:
    return QUBOProblem(
        matrix=[
            [1.0, -2.0, 0.5, 0.0, -1.0, 0.25],
            [-2.0, 1.5, -1.0, 0.75, 0.0, -0.5],
            [0.5, -1.0, 2.0, -1.25, 0.5, 0.0],
            [0.0, 0.75, -1.25, 1.0, -0.75, 1.0],
            [-1.0, 0.0, 0.5, -0.75, 1.75, -1.5],
            [0.25, -0.5, 0.0, 1.0, -1.5, 1.25],
        ],
        offset=0.0,
    )


def _maxcut_6() -> MaxCutProblem:
    return MaxCutProblem(
        nodes=6,
        edges=[
            (0, 1, 1.0),
            (0, 2, 1.5),
            (1, 2, 0.75),
            (1, 3, 2.0),
            (2, 4, 1.25),
            (3, 4, 1.0),
            (3, 5, 1.75),
            (4, 5, 0.5),
            (0, 5, 1.0),
        ],
    )


def _route_path(url: str) -> str:
    marker = "/v3turbo"
    if marker in url:
        return url[url.index(marker) :]
    return url


def _summarize(rows: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    materialized = list(rows)
    suites = sorted({row["suite"] for row in materialized})
    total_compute = sum(int(row["billing_estimate"].get("compute_units", 0)) for row in materialized)
    max_qubits = max(int(row["billing_estimate"].get("qubits", 0)) for row in materialized)
    summary: Dict[str, Any] = {
        "total_cases": len(materialized),
        "quantum_cases": sum(1 for row in materialized if row["workload_type"] in {"circuit", "qasm"}),
        "solver_cases": sum(1 for row in materialized if row["workload_type"] == "solver"),
        "suite_count": len(suites),
        "suites": suites,
        "max_qubits": max_qubits,
        "total_compute_units": total_compute,
        "total_payload_bytes": sum(int(row["payload_bytes"]) for row in materialized),
    }
    executed = [row for row in materialized if "api_execution" in row]
    if executed:
        summary["executed_cases"] = len(executed)
        summary["successful_api_cases"] = sum(1 for row in executed if row["api_execution"].get("ok") is True)
        summary["median_latency_ms"] = _median([float(row["api_execution"]["latency_ms"]) for row in executed])
    return summary


def _render_markdown(report: Dict[str, Any]) -> str:
    lines = [
        "# Catalyst-Q Public Benchmark Harness",
        "",
        "This report validates SDK request generation, billing estimates, and payload shape against public benchmark families.",
        "It is not a formal complexity proof and does not disclose proprietary execution internals.",
        "",
        "## Summary",
        "",
        f"- API execution mode: {report['mode']}",
        f"- Total cases: {report['summary']['total_cases']}",
        f"- Quantum cases: {report['summary']['quantum_cases']}",
        f"- Solver cases: {report['summary']['solver_cases']}",
        f"- Public suites covered: {report['summary']['suite_count']}",
        f"- Total compute units: {report['summary']['total_compute_units']}",
        "",
        "## Cases",
        "",
        "| ID | Suite | Family | Type | Size | Compute units | Payload bytes |",
        "|---|---|---|---|---|---:|---:|",
    ]
    for row in report["benchmarks"]:
        lines.append(
            "| {id} | {suite} | {family} | {workload_type} | {size_label} | {compute} | {payload} |".format(
                id=row["id"],
                suite=row["suite"],
                family=row["family"],
                workload_type=row["workload_type"],
                size_label=row["size_label"],
                compute=row["billing_estimate"].get("compute_units", 0),
                payload=row["payload_bytes"],
            )
        )
    if report["mode"] == "live-api":
        lines.insert(12, f"- Successful API cases: {report['summary'].get('successful_api_cases', 0)}")
        lines.insert(13, f"- Median API latency ms: {report['summary'].get('median_latency_ms', 0)}")
    lines.extend(["", "## Sources", ""])
    for key, url in report["sources"].items():
        lines.append(f"- {key}: {url}")
    return "\n".join(lines) + "\n"


def _median(values: List[float]) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    midpoint = len(ordered) // 2
    if len(ordered) % 2:
        return round(ordered[midpoint], 3)
    return round((ordered[midpoint - 1] + ordered[midpoint]) / 2, 3)
