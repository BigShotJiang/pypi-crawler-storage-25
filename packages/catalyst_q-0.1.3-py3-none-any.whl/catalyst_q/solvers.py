from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass(frozen=True)
class SATProblem:
    clauses: List[List[int]]
    variables: int

    @property
    def problem_size(self) -> int:
        return self.variables

    @property
    def compute_units(self) -> int:
        return max(1, self.variables * len(self.clauses))

    def to_payload(self) -> Dict[str, Any]:
        return {"clauses": self.clauses, "variables": self.variables}


@dataclass(frozen=True)
class TSPProblem:
    distances: List[List[float]]
    cities: Optional[List[str]] = None

    @property
    def problem_size(self) -> int:
        return len(self.distances)

    @property
    def compute_units(self) -> int:
        size = self.problem_size
        return max(1, size * size)

    def to_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"distances": self.distances}
        if self.cities is not None:
            payload["cities"] = self.cities
        return payload


@dataclass(frozen=True)
class KnapsackProblem:
    weights: List[float]
    values: List[float]
    capacity: float

    @property
    def problem_size(self) -> int:
        return len(self.weights)

    @property
    def compute_units(self) -> int:
        return max(1, len(self.weights) * max(1, int(self.capacity)))

    def to_payload(self) -> Dict[str, Any]:
        return {"weights": self.weights, "values": self.values, "capacity": self.capacity}


@dataclass(frozen=True)
class MultidimensionalKnapsackProblem:
    values: List[float]
    constraints: List[List[float]]
    capacities: List[float]
    node_limit: Optional[int] = None

    @property
    def problem_size(self) -> int:
        return len(self.values)

    @property
    def compute_units(self) -> int:
        constraint_count = max(1, len(self.capacities))
        return max(1, len(self.values) * constraint_count * max(1, int(sum(self.capacities))))

    def to_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "values": self.values,
            "constraints": self.constraints,
            "capacities": self.capacities,
        }
        if self.node_limit is not None:
            payload["node_limit"] = self.node_limit
        return payload


@dataclass(frozen=True)
class PortfolioProblem:
    returns: List[float]
    covariance: List[List[float]]
    risk_tolerance: float

    @property
    def problem_size(self) -> int:
        return len(self.returns)

    @property
    def compute_units(self) -> int:
        size = self.problem_size
        return max(1, size * size)

    def to_payload(self) -> Dict[str, Any]:
        return {
            "returns": self.returns,
            "covariance": self.covariance,
            "risk_tolerance": self.risk_tolerance,
        }


@dataclass(frozen=True)
class QUBOProblem:
    matrix: List[List[float]]
    offset: float = 0.0

    @property
    def problem_size(self) -> int:
        return len(self.matrix)

    @property
    def compute_units(self) -> int:
        size = self.problem_size
        return max(1, size * size)

    def to_payload(self) -> Dict[str, Any]:
        return {"matrix": self.matrix, "offset": self.offset}


@dataclass(frozen=True)
class MaxCutProblem:
    edges: List[Tuple[int, int, float]]
    nodes: Optional[int] = None

    @property
    def problem_size(self) -> int:
        if self.nodes is not None:
            return self.nodes
        if not self.edges:
            return 0
        return max(max(int(u), int(v)) for u, v, _ in self.edges) + 1

    @property
    def compute_units(self) -> int:
        return max(1, self.problem_size * max(1, len(self.edges)))

    def to_payload(self) -> Dict[str, Any]:
        return {
            "nodes": self.problem_size,
            "edges": [
                {"u": int(u), "v": int(v), "weight": float(weight)}
                for u, v, weight in self.edges
            ],
        }
