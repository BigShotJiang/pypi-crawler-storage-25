from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .rain import RainProtocolKey, _hash_bits


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _association_bits(tenant_id: str, workflow_id: str, key: str, value: str, capacity: int) -> int:
    key_bits = _hash_bits(f"{tenant_id}:{workflow_id}:qram:key:{key}", capacity)
    value_bits = _hash_bits(f"{tenant_id}:{workflow_id}:qram:value:{value}", capacity)
    return key_bits ^ value_bits


def _popcount(value: int) -> int:
    if hasattr(int, "bit_count"):
        return value.bit_count()
    return bin(value).count("1")


def _empty_index() -> Dict[str, Any]:
    return {
        "association_count": 0,
        "keys": {},
        "values": {},
    }


@dataclass(frozen=True)
class RainQRAM:
    """State-in-payload associative memory for Catalyst-Q solver preconditioning.

    The state vector is updated algebraically and travels with the request. Exact
    SDK recall uses a compact payload-carried codebook; resonance scores are
    still computed from the fixed-width RainProtocol state for validation and
    diagnostics.
    """

    rain_key: RainProtocolKey

    @classmethod
    def create(
        cls,
        workflow_id: str,
        tenant_id: str = "default",
        capacity: int = 10000,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "RainQRAM":
        key = RainProtocolKey.create(
            workflow_id=workflow_id,
            tenant_id=tenant_id,
            capacity=capacity,
            metadata={
                "storage": "state_in_payload",
                "rain_qram": _empty_index(),
                **(metadata or {}),
            },
        )
        return cls(key)

    def store(self, key: str, value: str) -> "RainQRAM":
        if not key:
            raise ValueError("key must be non-empty")
        if not value:
            raise ValueError("value must be non-empty")

        index = self._index()
        key_digest = _digest(key)
        value_digest = _digest(value)
        keys = dict(index["keys"])
        values = dict(index["values"])
        is_new = key_digest not in keys
        keys[key_digest] = value_digest
        values[value_digest] = value

        next_state = self.rain_key.state_value ^ _association_bits(
            self.rain_key.tenant_id,
            self.rain_key.workflow_id,
            key,
            value,
            self.rain_key.capacity,
        )
        metadata = {
            **self.rain_key.metadata,
            "storage": "state_in_payload",
            "rain_qram": {
                "association_count": int(index["association_count"]) + (1 if is_new else 0),
                "keys": keys,
                "values": values,
            },
            "last_role": "rain_qram_store",
        }
        return RainQRAM(
            RainProtocolKey(
                workflow_id=self.rain_key.workflow_id,
                tenant_id=self.rain_key.tenant_id,
                capacity=self.rain_key.capacity,
                state_value=next_state,
                step_index=self.rain_key.step_index + 1,
                metadata=metadata,
            )._signed()
        )

    def recall(self, key: str, candidates: Optional[List[str]] = None) -> Dict[str, Any]:
        index = self._index()
        key_digest = _digest(key)
        values = dict(index["values"])
        candidate_values = candidates or list(values.values())
        exact_digest = dict(index["keys"]).get(key_digest)
        exact_value = values.get(exact_digest) if exact_digest else None
        if exact_value and exact_value not in candidate_values:
            candidate_values.append(exact_value)

        scores = [
            {
                "value": candidate,
                "score": self._resonance_score(key, candidate),
            }
            for candidate in candidate_values
        ]
        scores.sort(key=lambda item: item["score"], reverse=True)
        best = scores[0] if scores else {"value": None, "score": 0.0}
        value = exact_value or best["value"]
        return {
            "found": value is not None,
            "key_digest": key_digest,
            "value": value,
            "score": round(float(best["score"]), 6),
            "candidate_count": len(candidate_values),
            "association_count": int(index["association_count"]),
            "state_mode": "rainprotocol_state_in_payload",
        }

    def shard(self, shard_count: int) -> List["RainQRAM"]:
        return [RainQRAM(shard) for shard in self.rain_key.shard(shard_count, strategy="nonlinear")]

    @classmethod
    def recombine(cls, shards: List["RainQRAM"]) -> "RainQRAM":
        if not shards:
            raise ValueError("at least one shard is required")
        return cls(RainProtocolKey.recombine([shard.rain_key for shard in shards]))

    def to_wire(self) -> Dict[str, Any]:
        index = self._index()
        return {
            "mode": "rainprotocol_qram",
            "state_mode": "rainprotocol_state_in_payload",
            "rain_key": self.rain_key.to_wire(),
            "association_count": int(index["association_count"]),
        }

    @classmethod
    def from_wire(cls, payload: Dict[str, Any]) -> "RainQRAM":
        rain_payload = payload.get("rain_key", payload)
        if not isinstance(rain_payload, dict):
            raise ValueError("RainQRAM payload must contain a rain_key object")
        return cls(RainProtocolKey.from_wire(rain_payload))

    def to_solver_payload(self, kind: str, problem_size: int) -> Dict[str, Any]:
        wire = self.to_wire()
        wire["solver_kind"] = kind
        wire["problem_size"] = int(problem_size)
        wire["preconditioner"] = "candidate_resonance"
        return wire

    def _index(self) -> Dict[str, Any]:
        raw = self.rain_key.metadata.get("rain_qram")
        if not isinstance(raw, dict):
            return _empty_index()
        return {
            "association_count": int(raw.get("association_count", 0)),
            "keys": dict(raw.get("keys", {})),
            "values": dict(raw.get("values", {})),
        }

    def _resonance_score(self, key: str, value: str) -> float:
        association = _association_bits(
            self.rain_key.tenant_id,
            self.rain_key.workflow_id,
            key,
            value,
            self.rain_key.capacity,
        )
        distance = _popcount(self.rain_key.state_value ^ association)
        return 1.0 - (distance / max(1, self.rain_key.capacity))
