from __future__ import annotations

import base64
import hashlib
import json
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


def _sha256(data: str) -> bytes:
    return hashlib.sha256(data.encode("utf-8")).digest()


def _sha256_hex(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _hash_bits(seed: str, capacity: int) -> int:
    value = 0
    produced = 0
    counter = 0
    while produced < capacity:
        digest = _sha256(f"{seed}:{counter}")
        for byte in digest:
            for bit in range(8):
                if produced >= capacity:
                    break
                if (byte >> bit) & 1:
                    value |= 1 << produced
                produced += 1
        counter += 1
    return value


def _encode_state(value: int, capacity: int) -> str:
    size = max(1, math.ceil(capacity / 8))
    return base64.b64encode(value.to_bytes(size, "big")).decode("ascii")


def _decode_state(value: str) -> int:
    return int.from_bytes(base64.b64decode(value.encode("ascii")), "big")


def _bits_to_int(bits: List[int]) -> int:
    value = 0
    for idx, bit in enumerate(bits):
        if bit:
            value |= 1 << idx
    return value


def _int_to_bits(value: int, width: int) -> List[int]:
    return [(value >> idx) & 1 for idx in range(width)]


def _coprime_step(seed: str, capacity: int) -> int:
    raw = int.from_bytes(_sha256(seed), "big")
    step = raw % capacity
    if step == 0:
        step = 1
    while math.gcd(step, capacity) != 1:
        step = (step + 1) % capacity or 1
    return step


@dataclass(frozen=True)
class RainProtocolKey:
    workflow_id: str
    tenant_id: str = "default"
    capacity: int = 10000
    state_value: int = 0
    step_index: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    integrity: str = ""
    shard_count: int = 1
    shard_index: int = 0
    indices: Optional[List[int]] = None

    @classmethod
    def create(
        cls,
        workflow_id: str,
        tenant_id: str = "default",
        capacity: int = 10000,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "RainProtocolKey":
        state = _hash_bits(f"{tenant_id}:{workflow_id}:state", capacity)
        meta = {"storage": "state_in_payload", **(metadata or {})}
        return cls(
            workflow_id=workflow_id,
            tenant_id=tenant_id,
            capacity=capacity,
            state_value=state,
            metadata=meta,
        )._signed()

    def update(self, role: str, value: str, blend: float = 1.0) -> "RainProtocolKey":
        if not 0 <= blend <= 1:
            raise ValueError("blend must be between 0 and 1")
        delta = _hash_bits(f"{self.tenant_id}:{self.workflow_id}:{role}:{value}", self.capacity)
        if blend >= 1.0:
            next_state = self.state_value ^ delta
        elif blend <= 0.0:
            next_state = self.state_value
        else:
            mask = _hash_bits(f"blend:{role}:{value}:{blend}", self.capacity)
            thresholded = delta & mask
            next_state = self.state_value ^ thresholded
        return RainProtocolKey(
            workflow_id=self.workflow_id,
            tenant_id=self.tenant_id,
            capacity=self.capacity,
            state_value=next_state,
            step_index=self.step_index + 1,
            metadata={**self.metadata, "last_role": role},
            shard_count=1,
            shard_index=0,
        )._signed()

    def shard(self, shard_count: int, strategy: str = "nonlinear") -> List["RainProtocolKey"]:
        if shard_count <= 0:
            raise ValueError("shard_count must be positive")
        if strategy != "nonlinear":
            raise ValueError("only nonlinear sharding is supported")

        step = _coprime_step(f"{self.workflow_id}:{self.tenant_id}:shard", self.capacity)
        start = int.from_bytes(_sha256(f"{self.workflow_id}:start"), "big") % self.capacity
        permutation = [(start + idx * step) % self.capacity for idx in range(self.capacity)]
        shards: List[RainProtocolKey] = []
        for shard_index in range(shard_count):
            indices = permutation[shard_index::shard_count]
            bits = [1 if (self.state_value >> idx) & 1 else 0 for idx in indices]
            shard_state = _bits_to_int(bits)
            shards.append(
                RainProtocolKey(
                    workflow_id=self.workflow_id,
                    tenant_id=self.tenant_id,
                    capacity=len(indices),
                    state_value=shard_state,
                    step_index=self.step_index,
                    metadata=self.metadata,
                    shard_count=shard_count,
                    shard_index=shard_index,
                    indices=indices,
                )._signed()
            )
        return shards

    @classmethod
    def recombine(cls, shards: List["RainProtocolKey"]) -> "RainProtocolKey":
        if not shards:
            raise ValueError("at least one shard is required")
        full_capacity = max(max(shard.indices or [0]) for shard in shards) + 1
        state = 0
        for shard in shards:
            if shard.indices is None:
                raise ValueError("cannot recombine shards without non-linear indices")
            for source_bit, target_idx in zip(_int_to_bits(shard.state_value, len(shard.indices)), shard.indices):
                if source_bit:
                    state |= 1 << target_idx
        first = shards[0]
        return cls(
            workflow_id=first.workflow_id,
            tenant_id=first.tenant_id,
            capacity=full_capacity,
            state_value=state,
            step_index=first.step_index,
            metadata=first.metadata,
        )._signed()

    def to_wire(self) -> Dict[str, Any]:
        payload = self._payload(include_integrity=True)
        payload["state_token"] = _encode_state(self.state_value, self.capacity)
        return payload

    @classmethod
    def from_wire(cls, payload: Dict[str, Any]) -> "RainProtocolKey":
        restored = cls(
            workflow_id=payload["workflow_id"],
            tenant_id=payload.get("tenant_id", "default"),
            capacity=int(payload["capacity"]),
            state_value=_decode_state(payload["state_token"]),
            step_index=int(payload.get("step_index", 0)),
            metadata=dict(payload.get("metadata", {})),
            integrity=payload.get("integrity", ""),
            shard_count=int(payload.get("shard_count", 1)),
            shard_index=int(payload.get("shard_index", 0)),
            indices=payload.get("indices"),
        )
        if not restored.verify():
            raise ValueError("RainProtocol integrity check failed")
        return restored

    def verify(self) -> bool:
        return self.integrity == self._signature()

    def _signed(self) -> "RainProtocolKey":
        return RainProtocolKey(
            workflow_id=self.workflow_id,
            tenant_id=self.tenant_id,
            capacity=self.capacity,
            state_value=self.state_value,
            step_index=self.step_index,
            metadata=self.metadata,
            integrity=self._signature(),
            shard_count=self.shard_count,
            shard_index=self.shard_index,
            indices=self.indices,
        )

    def _signature(self) -> str:
        return _sha256_hex(json.dumps(self._payload(include_integrity=False), sort_keys=True, separators=(",", ":")))

    def _payload(self, include_integrity: bool) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "workflow_id": self.workflow_id,
            "tenant_id": self.tenant_id,
            "capacity": self.capacity,
            "state_token": _encode_state(self.state_value, self.capacity),
            "step_index": self.step_index,
            "metadata": self.metadata,
            "shard_count": self.shard_count,
            "shard_index": self.shard_index,
            "indices": self.indices,
        }
        if include_integrity:
            payload["integrity"] = self.integrity
        return payload
