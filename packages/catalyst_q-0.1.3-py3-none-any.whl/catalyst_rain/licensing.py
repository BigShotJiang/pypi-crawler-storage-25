from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


class FreemiumLimitError(RuntimeError):
    """Raised when a local SDK policy blocks an over-limit operation."""


def _limit_message(tier: str, detail: str) -> str:
    return f"{tier} tier {detail}; upgrade or wait until next month"


@dataclass(frozen=True)
class UsagePolicy:
    tier: str
    monthly_circuit_runs: int
    monthly_solver_runs: int
    monthly_compute_units: int
    max_qubits: int
    max_problem_size: int
    cloudflare_deploy: bool
    production_allowed: bool = False
    price_monthly_usd: Optional[int] = None

    @classmethod
    def free(cls) -> "UsagePolicy":
        return cls(
            tier="free",
            monthly_circuit_runs=10_000,
            monthly_solver_runs=500,
            monthly_compute_units=5_000_000,
            max_qubits=50,
            max_problem_size=250,
            cloudflare_deploy=False,
            production_allowed=False,
            price_monthly_usd=0,
        )

    @classmethod
    def starter(cls) -> "UsagePolicy":
        return cls(
            tier="starter",
            monthly_circuit_runs=100_000,
            monthly_solver_runs=5_000,
            monthly_compute_units=100_000_000,
            max_qubits=100,
            max_problem_size=1_000,
            cloudflare_deploy=True,
            production_allowed=True,
            price_monthly_usd=29,
        )

    @classmethod
    def pro(cls) -> "UsagePolicy":
        return cls(
            tier="pro",
            monthly_circuit_runs=1_000_000,
            monthly_solver_runs=50_000,
            monthly_compute_units=2_000_000_000,
            max_qubits=250,
            max_problem_size=10_000,
            cloudflare_deploy=True,
            production_allowed=True,
            price_monthly_usd=199,
        )

    @classmethod
    def enterprise(cls) -> "UsagePolicy":
        return cls(
            tier="enterprise",
            monthly_circuit_runs=10**12,
            monthly_solver_runs=10**12,
            monthly_compute_units=10**18,
            max_qubits=10**9,
            max_problem_size=10**12,
            cloudflare_deploy=True,
            production_allowed=True,
            price_monthly_usd=None,
        )

    @property
    def monthly_calls(self) -> int:
        return self.monthly_circuit_runs

    def check_circuit_run(
        self,
        operation: str,
        circuit_runs_this_month: int,
        compute_units_this_month: int,
        qubits: int,
        requested_compute_units: int,
        production: bool = False,
    ) -> None:
        if production and not self.production_allowed:
            raise FreemiumLimitError(
                f"{self.tier} tier is for development and evaluation; production {operation} requires a paid license"
            )
        if circuit_runs_this_month >= self.monthly_circuit_runs:
            raise FreemiumLimitError(_limit_message(self.tier, f"exceeded monthly circuit run limit for {operation}"))
        if qubits > self.max_qubits:
            raise FreemiumLimitError(
                _limit_message(self.tier, f"allows circuits up to {self.max_qubits} qubits, got {qubits}")
            )
        self._check_compute_units(operation, compute_units_this_month, requested_compute_units)

    def check_solver_run(
        self,
        operation: str,
        solver_runs_this_month: int,
        compute_units_this_month: int,
        problem_size: int,
        requested_compute_units: int,
        production: bool = False,
    ) -> None:
        if production and not self.production_allowed:
            raise FreemiumLimitError(
                f"{self.tier} tier is for development and evaluation; production {operation} requires a paid license"
            )
        if solver_runs_this_month >= self.monthly_solver_runs:
            raise FreemiumLimitError(_limit_message(self.tier, f"exceeded monthly solver run limit for {operation}"))
        if problem_size > self.max_problem_size:
            raise FreemiumLimitError(
                _limit_message(
                    self.tier,
                    f"allows NP solver problems up to {self.max_problem_size} variables/items/cities, got {problem_size}",
                )
            )
        self._check_compute_units(operation, compute_units_this_month, requested_compute_units)

    def check_call(
        self,
        operation: str,
        calls_this_month: int,
        requested_dim: int = 0,
        production: bool = False,
    ) -> None:
        self.check_circuit_run(
            operation,
            circuit_runs_this_month=calls_this_month,
            compute_units_this_month=0,
            qubits=min(self.max_qubits, max(1, requested_dim)),
            requested_compute_units=1,
            production=production,
        )

    def _check_compute_units(
        self,
        operation: str,
        compute_units_this_month: int,
        requested_compute_units: int,
    ) -> None:
        if compute_units_this_month + requested_compute_units > self.monthly_compute_units:
            raise FreemiumLimitError(
                _limit_message(self.tier, f"exceeded monthly compute unit limit for {operation}")
            )
