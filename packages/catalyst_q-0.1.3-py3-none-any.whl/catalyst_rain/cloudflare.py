from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass(frozen=True)
class RenderedDeployment:
    files: Dict[str, str]
    deploy_command: List[str]


@dataclass(frozen=True)
class CloudflareDeploymentSpec:
    worker_name: str
    route_prefix: str = "/v3turbo"
    compatibility_date: str = "2026-05-11"

    def render(self) -> RenderedDeployment:
        wrangler = "\n".join(
            [
                f'name = "{self.worker_name}"',
                'main = "src/worker.ts"',
                f'compatibility_date = "{self.compatibility_date}"',
                "",
                "[vars]",
                'CATALYST_STATE_MODE = "rainprotocol_state_in_payload"',
                'CATALYST_SHARDING = "nonlinear"',
                "",
            ]
        )
        worker = "\n".join(
            [
                "export default {",
                "  async fetch(request: Request): Promise<Response> {",
                "    const url = new URL(request.url);",
                f'    if (!url.pathname.startsWith("{self.route_prefix}")) {{',
                '      return new Response("not found", { status: 404 });',
                "    }",
                "    return Response.json({",
                '      status: "ready",',
                '      state_mode: "rainprotocol_state_in_payload",',
                '      sharding: "nonlinear",',
                "    });",
                "  },",
                "};",
                "",
            ]
        )
        return RenderedDeployment(
            files={
                "wrangler.toml": wrangler,
                "src/worker.ts": worker,
            },
            deploy_command=["npx", "wrangler", "deploy"],
        )
