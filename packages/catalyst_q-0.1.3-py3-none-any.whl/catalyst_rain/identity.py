from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class InstallIdentity:
    install_id: str
    created_at: str
    tier: str = "free"
    mode: str = "anonymous_install"
    register_on: str = "first_api_request"

    @classmethod
    def load(cls, home: Optional[Path] = None) -> "InstallIdentity":
        path = cls.path(home)
        if path.exists():
            return cls.from_wire(json.loads(path.read_text()))
        identity = cls(
            install_id=f"cqi_{uuid.uuid4().hex}",
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(identity.to_wire(), sort_keys=True, indent=2))
        return identity

    @classmethod
    def path(cls, home: Optional[Path] = None) -> Path:
        if home is None:
            home_value = os.environ.get("CATALYST_Q_HOME")
            home = Path(home_value) if home_value else Path.home() / ".catalyst_q"
        return home / "install.json"

    @classmethod
    def from_wire(cls, payload: Dict[str, Any]) -> "InstallIdentity":
        return cls(
            install_id=str(payload["install_id"]),
            created_at=str(payload["created_at"]),
            tier=str(payload.get("tier", "free")),
            mode=str(payload.get("mode", "anonymous_install")),
            register_on=str(payload.get("register_on", "first_api_request")),
        )

    def to_wire(self) -> Dict[str, Any]:
        return {
            "install_id": self.install_id,
            "created_at": self.created_at,
            "tier": self.tier,
            "mode": self.mode,
            "register_on": self.register_on,
        }
