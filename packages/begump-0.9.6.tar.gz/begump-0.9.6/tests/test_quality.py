"""
QUALITY BENCHMARKS — Would a paying customer be satisfied?
=============================================================
Each test simulates a real customer scenario.
"""
import sys, os, time, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.orgxray import analyze as org_analyze
from gump.learnengine import track as learn_track
from gump.foldwatch import analyze as fold_analyze
from gump.chipfast import design as chip_design
from gump.aitrainer import detect_grokking
from gump.knowledge import build_graph
from gump.sensor import UniversalSensor, measure_kret


class TestOrgXrayQuality(unittest.TestCase):
    def test_20_person_company(self):
        edges = []
        for i in range(20):
            for j in range(i+1, min(i+3, 20)):
                edges.append((f'person_{i}', f'person_{j}'))
        r = org_analyze(edges)
        self.assertEqual(r['n_nodes'], 20)
        self.assertGreater(r['K'], 0)


class TestFoldWatchQuality(unittest.TestCase):
    def test_amyloid_beta(self):
        seq = 'DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA'
        r = fold_analyze(seq)
        self.assertEqual(r['sequence_length'], 42)
        self.assertIn(r['misfolding_risk'], ('low', 'medium', 'high'))


class TestChipFastQuality(unittest.TestCase):
    def test_50_gates(self):
        gates = [f'g{i}' for i in range(50)]
        wires = [(i, i+1) for i in range(49)] + [(0, 49)]
        t0 = time.time()
        r = chip_design(gates, wires)
        elapsed = time.time() - t0
        self.assertEqual(r['n_gates'], 50)
        self.assertLess(elapsed, 30.0, "50 gates too slow")


class TestSensorQuality(unittest.TestCase):
    def test_diagnose_regime(self):
        s = UniversalSensor('test')
        # Stable signal
        for v in [10, 10.1, 9.9, 10.0, 10.1, 9.9, 10.0, 10.1]:
            s.feed([v])
        d = s.diagnose()
        self.assertIn(d['regime'], ('locked', 'coherent', 'transitional', 'volatile', 'diffuse'))


class TestKnowledgeQuality(unittest.TestCase):
    def test_extracts_concepts(self):
        text = """
        The hippocampus is crucial for memory formation. Memory consolidation
        occurs during sleep. The cortex stores long-term memories.
        Neurons communicate through synapses using neurotransmitters.
        """
        r = build_graph(text)
        self.assertGreater(r['n_nodes'], 3)


if __name__ == '__main__':
    unittest.main()
