"""Tests for gump.aitrainer — Grokking detection."""
import sys, os, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.aitrainer import detect_grokking


class TestDetectGrokking(unittest.TestCase):
    def test_insufficient_data(self):
        r = detect_grokking([1.0]*5, [1.0]*5)
        self.assertEqual(r['phase'], 'INSUFFICIENT_DATA')

    def test_learning_phase(self):
        train = [2.0 - i*0.01 for i in range(100)]
        test = [2.0 - i*0.005 for i in range(100)]
        r = detect_grokking(train, test)
        self.assertIn(r['phase'], ('LEARNING', 'MEMORIZED'))

    def test_memorized_phase(self):
        train = np.linspace(2, 0.01, 100).tolist()
        test = np.linspace(2, 0.5, 100).tolist()
        r = detect_grokking(train, test)
        self.assertEqual(r['phase'], 'MEMORIZED')
        self.assertGreater(r['gap'], 0)

    def test_output_fields(self):
        train = np.linspace(2, 0.01, 100).tolist()
        test = np.linspace(2, 0.5, 100).tolist()
        r = detect_grokking(train, test)
        self.assertIn('phase', r)
        self.assertIn('train_loss', r)
        self.assertIn('test_loss', r)
        self.assertIn('gap', r)
        self.assertIn('n', r)


if __name__ == '__main__':
    unittest.main()
