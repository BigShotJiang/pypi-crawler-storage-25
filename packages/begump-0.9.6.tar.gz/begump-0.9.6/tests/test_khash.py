"""
Tests for K-Hash — cryptographic hash from coupled oscillators.
Every property a hash function MUST have, tested.
"""
import sys, os, time, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.khash import khash, khash256, khash512, khash1096, khmac


class TestDeterminism(unittest.TestCase):
    """Same input MUST produce same output. Always. No exceptions."""

    def test_k256_deterministic(self):
        for _ in range(5):
            h = khash256(b'test')
        h1 = khash256(b'test')
        h2 = khash256(b'test')
        self.assertEqual(h1, h2)

    def test_k512_deterministic(self):
        self.assertEqual(khash512(b'hello'), khash512(b'hello'))

    def test_k1096_deterministic(self):
        self.assertEqual(khash1096(b'world'), khash1096(b'world'))

    def test_string_vs_bytes(self):
        self.assertEqual(khash256('hello'), khash256(b'hello'))

    def test_empty_input(self):
        h = khash256(b'')
        self.assertEqual(len(h), 64)  # 32 bytes = 64 hex chars


class TestOutputSize(unittest.TestCase):
    """Output must be exactly the right number of bits."""

    def test_k256_is_256_bits(self):
        h = khash256(b'test')
        self.assertEqual(len(h), 64, f"K-256 output is {len(h)} hex chars, expected 64 (256 bits)")

    def test_k512_is_512_bits(self):
        h = khash512(b'test')
        self.assertEqual(len(h), 128, f"K-512 output is {len(h)} hex chars, expected 128 (512 bits)")

    def test_k1096_is_1096_bits(self):
        h = khash1096(b'test')
        self.assertEqual(len(h), 274, f"K-1096 output is {len(h)} hex chars, expected 274 (1096 bits)")

    def test_output_is_valid_hex(self):
        h = khash256(b'test')
        int(h, 16)  # should not raise

    def test_custom_size(self):
        h = khash(b'test', n_bytes=16, ncols=4, rounds=32)
        self.assertEqual(len(h), 32)  # 16 bytes = 32 hex chars


class TestAvalanche(unittest.TestCase):
    """Tiny input change MUST cause massive output change.
    This is the core property. If this fails, the hash is useless."""

    def test_one_bit_flip_k256(self):
        h1 = khash256(b'test0')
        h2 = khash256(b'test1')
        # Count differing hex chars
        diffs = sum(1 for a, b in zip(h1, h2) if a != b)
        ratio = diffs / len(h1)
        self.assertGreater(ratio, 0.3,
            f"K-256 avalanche: only {ratio*100:.0f}% of output changed — need >30%")

    def test_one_bit_flip_k512(self):
        h1 = khash512(b'test0')
        h2 = khash512(b'test1')
        diffs = sum(1 for a, b in zip(h1, h2) if a != b)
        ratio = diffs / len(h1)
        self.assertGreater(ratio, 0.3,
            f"K-512 avalanche: only {ratio*100:.0f}% changed")

    def test_one_bit_flip_k1096(self):
        h1 = khash1096(b'test0')
        h2 = khash1096(b'test1')
        diffs = sum(1 for a, b in zip(h1, h2) if a != b)
        ratio = diffs / len(h1)
        self.assertGreater(ratio, 0.3,
            f"K-1096 avalanche: only {ratio*100:.0f}% changed")

    def test_adjacent_inputs(self):
        """Hash of N and N+1 for many N — all must be wildly different."""
        hashes = [khash256(str(i).encode()) for i in range(20)]
        for i in range(len(hashes) - 1):
            diffs = sum(1 for a, b in zip(hashes[i], hashes[i+1]) if a != b)
            ratio = diffs / len(hashes[i])
            self.assertGreater(ratio, 0.25,
                f"Adjacent inputs {i},{i+1}: only {ratio*100:.0f}% difference")

    def test_long_vs_short_input(self):
        """Very different length inputs should produce very different hashes."""
        h1 = khash256(b'a')
        h2 = khash256(b'a' * 10000)
        diffs = sum(1 for a, b in zip(h1, h2) if a != b)
        self.assertGreater(diffs, len(h1) * 0.3)


class TestCollisionResistance(unittest.TestCase):
    """Finding two inputs with the same hash should be practically impossible."""

    def test_1000_unique_hashes(self):
        """1000 different inputs must produce 1000 different hashes."""
        hashes = set()
        for i in range(1000):
            h = khash256(f'input_{i}'.encode())
            self.assertNotIn(h, hashes,
                f"COLLISION at input {i} — hash function is broken")
            hashes.add(h)

    def test_similar_inputs_unique(self):
        """Inputs that differ by 1 byte must all hash differently."""
        base = b'The quick brown fox jumps over the lazy dog'
        hashes = set()
        for i in range(len(base)):
            modified = base[:i] + bytes([(base[i] + 1) % 256]) + base[i+1:]
            h = khash256(modified)
            self.assertNotIn(h, hashes,
                f"COLLISION: modifying byte {i} produced duplicate hash")
            hashes.add(h)


class TestPreImage(unittest.TestCase):
    """Given a hash, it should be impossible to find the input."""

    def test_output_looks_random(self):
        """Hash output should have uniform byte distribution (no patterns)."""
        h = khash512(b'test data for distribution analysis')
        h_bytes = bytes.fromhex(h)
        # Check byte distribution — should be roughly uniform
        counts = [0] * 256
        for b in h_bytes:
            counts[b] += 1
        # Chi-squared test approximation: no byte should dominate
        max_count = max(counts)
        expected = len(h_bytes) / 256
        # Allow 10x expected frequency (very loose — just catching obvious patterns)
        self.assertLess(max_count, max(expected * 10, 5),
            f"Byte distribution non-uniform: one byte appears {max_count} times")

    def test_no_input_leakage(self):
        """Input bytes should not appear verbatim in output."""
        data = b'SECRETPASSWORD123456789'
        h = bytes.fromhex(khash256(data))
        # No 4-byte substring of input should appear in output
        for i in range(len(data) - 3):
            chunk = data[i:i+4]
            self.assertNotIn(chunk, h,
                f"Input bytes leaked into hash at position {i}")


class TestHMAC(unittest.TestCase):
    """HMAC-K: keyed hash for signatures."""

    def test_deterministic(self):
        h1 = khmac(b'key', b'data')
        h2 = khmac(b'key', b'data')
        self.assertEqual(h1, h2)

    def test_different_keys(self):
        h1 = khmac(b'key1', b'data')
        h2 = khmac(b'key2', b'data')
        self.assertNotEqual(h1, h2)

    def test_different_data(self):
        h1 = khmac(b'key', b'data1')
        h2 = khmac(b'key', b'data2')
        self.assertNotEqual(h1, h2)

    def test_string_inputs(self):
        h = khmac('key', 'data')
        self.assertIsInstance(h, str)


class TestSpeed(unittest.TestCase):
    """Must be fast enough for real-world use."""

    def test_k256_speed(self):
        """K-256: 100 hashes in under 3 seconds."""
        start = time.time()
        for i in range(100):
            khash256(f'benchmark_{i}'.encode())
        elapsed = time.time() - start
        per_hash = elapsed / 100 * 1000
        self.assertLess(elapsed, 3.0,
            f"K-256: {per_hash:.1f}ms per hash — too slow for payments")

    def test_k512_speed(self):
        """K-512: 50 hashes in under 3 seconds."""
        start = time.time()
        for i in range(50):
            khash512(f'benchmark_{i}'.encode())
        elapsed = time.time() - start
        per_hash = elapsed / 50 * 1000
        self.assertLess(elapsed, 3.0,
            f"K-512: {per_hash:.1f}ms per hash — too slow")

    def test_k1096_speed(self):
        """K-1096: 10 hashes in under 5 seconds."""
        start = time.time()
        for i in range(10):
            khash1096(f'benchmark_{i}'.encode())
        elapsed = time.time() - start
        per_hash = elapsed / 10 * 1000
        self.assertLess(elapsed, 5.0,
            f"K-1096: {per_hash:.1f}ms per hash — too slow")


class TestVsSHA256(unittest.TestCase):
    """Prove K-Hash properties match or exceed SHA-256."""

    def test_output_entropy(self):
        """K-256 output should have similar entropy to SHA-256."""
        import hashlib
        # Generate many hashes, check bit distribution
        k_bits = []
        sha_bits = []
        for i in range(100):
            data = f'test_{i}'.encode()
            k_h = bytes.fromhex(khash256(data))
            s_h = hashlib.sha256(data).digest()
            k_bits.extend(k_h)
            sha_bits.extend(s_h)

        # Both should have mean ~127.5 (uniform bytes)
        import numpy as np
        k_mean = np.mean(k_bits)
        sha_mean = np.mean(sha_bits)
        self.assertAlmostEqual(k_mean, 127.5, delta=15,
            msg=f"K-256 mean byte: {k_mean:.1f} (expected ~127.5)")
        self.assertAlmostEqual(sha_mean, 127.5, delta=15,
            msg=f"SHA-256 mean byte: {sha_mean:.1f}")

    def test_k1096_more_bits(self):
        """K-1096 gives 4.3× more output bits than SHA-256."""
        import hashlib
        k_h = khash1096(b'test')
        s_h = hashlib.sha256(b'test').hexdigest()
        ratio = len(k_h) / len(s_h)
        self.assertGreater(ratio, 4,
            f"K-1096 only {ratio:.1f}× SHA-256 output — should be >4×")


if __name__ == '__main__':
    unittest.main(verbosity=2)
