"""
Tests for gump.k_core — K language compiled core algorithms
These test the PROTECTED implementations that products call.
"""
import sys, os, unittest, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.k_core import (
    k_tensions, k_place, k_energy, k_grok_detect, k_measure, k_interval,
    _PHI, _INV_PHI, _K_CEIL, _LANDAUER
)


class TestKConstants(unittest.TestCase):
    """The constants ARE the algorithm. If they're wrong, everything's wrong."""

    def test_phi(self):
        self.assertAlmostEqual(_PHI, (1 + 5**0.5) / 2, places=10)

    def test_inv_phi(self):
        self.assertAlmostEqual(_INV_PHI, 1 / _PHI, places=10)
        self.assertAlmostEqual(_INV_PHI, 0.6180339887, places=8)

    def test_k_ceiling(self):
        self.assertAlmostEqual(_K_CEIL, 1.868, places=3)

    def test_landauer(self):
        expected = 1.380649e-23 * 300 * np.log(2)
        self.assertAlmostEqual(_LANDAUER, expected, places=26)


class TestKTensions(unittest.TestCase):

    def test_chain_finds_endpoints(self):
        """Chain 0-1-2-3-4: tension between 0 and 4."""
        t = k_tensions(5, [(0,1),(1,2),(2,3),(3,4)], top_k=5)
        pairs = [(min(a,b), max(a,b)) for _,a,b,_ in t]
        self.assertIn((0, 4), pairs)

    def test_star_spoke_tensions(self):
        """Hub-spoke: spokes should have tension between them."""
        edges = [(0, i) for i in range(1, 7)]
        t = k_tensions(7, edges, top_k=15)
        spoke_tensions = [(a,b) for _,a,b,_ in t if a > 0 and b > 0]
        self.assertGreater(len(spoke_tensions), 0)

    def test_complete_graph_low_tension(self):
        """Fully connected = no missing connections = low tension."""
        edges = [(i,j) for i in range(5) for j in range(i+1,5)]
        t = k_tensions(5, edges)
        self.assertEqual(len(t), 0, "Complete graph should have no tensions")

    def test_empty_graph(self):
        t = k_tensions(0, [])
        self.assertEqual(len(t), 0)

    def test_scale_500(self):
        """500 nodes in under 2 seconds."""
        np.random.seed(42)
        n = 500
        edges = [(i, (i+1)%n) for i in range(n)]
        edges += [(np.random.randint(0,n), np.random.randint(0,n)) for _ in range(1000)]
        edges = [(a,b) for a,b in edges if a != b]
        start = time.time()
        t = k_tensions(n, edges, top_k=10)
        elapsed = time.time() - start
        self.assertLess(elapsed, 2.0, f"500-node took {elapsed:.1f}s")
        self.assertGreater(len(t), 0)

    def test_never_returns_existing_edge(self):
        """Tensions must ONLY be between unconnected nodes."""
        edges = [(0,1),(1,2),(2,3)]
        edge_set = set((min(a,b),max(a,b)) for a,b in edges)
        t = k_tensions(4, edges)
        for _, a, b, _ in t:
            pair = (min(a,b), max(a,b))
            self.assertNotIn(pair, edge_set, f"Returned existing edge {pair}")

    def test_weighted_edges(self):
        """Heavily weighted edge should reduce tension along that path."""
        edges = [(0,1),(1,2)]
        t_normal = k_tensions(3, edges, weights=[1, 1])
        t_heavy = k_tensions(3, edges, weights=[10, 1])
        # Both should find 0-2 tension, but heavy weighting might change score
        self.assertGreater(len(t_normal), 0)
        self.assertGreater(len(t_heavy), 0)


class TestKPlace(unittest.TestCase):

    def test_shape(self):
        pos = k_place(5, [(0,1),(1,2),(2,3),(3,4)])
        self.assertEqual(pos.shape, (5, 2))

    def test_connected_closer(self):
        """Connected nodes should be placed closer together."""
        n = 30
        edges = [(i, i+1) for i in range(n-1)]
        pos = k_place(n, edges, 100, 100)
        # Average connected distance
        conn_dist = np.mean([np.linalg.norm(pos[a]-pos[b]) for a,b in edges])
        # Average random distance
        rand_dist = np.mean([np.linalg.norm(pos[a]-pos[b])
                            for a, b in [(np.random.randint(0,n), np.random.randint(0,n))
                                         for _ in range(100)] if a != b])
        self.assertLess(conn_dist, rand_dist)

    def test_wirelength_improvement(self):
        """Spectral placement must beat random on wire length."""
        np.random.seed(42)
        n = 100
        edges = [(i, (i+1)%n) for i in range(n)]
        edges += [(np.random.randint(0,n), np.random.randint(0,n)) for _ in range(200)]
        edges = list(set((min(a,b),max(a,b)) for a,b in edges if a!=b))

        spectral_pos = k_place(n, edges, 100, 100)
        random_pos = np.random.rand(n, 2) * 100

        def wl(pos):
            return sum(abs(pos[a][0]-pos[b][0])+abs(pos[a][1]-pos[b][1]) for a,b in edges)

        improvement = (wl(random_pos) - wl(spectral_pos)) / wl(random_pos) * 100
        self.assertGreater(improvement, 10, f"Only {improvement:.1f}% improvement")


class TestKEnergy(unittest.TestCase):

    def test_one_bit(self):
        cost = k_energy(1)
        self.assertAlmostEqual(cost, _LANDAUER, places=25)

    def test_reversible_free(self):
        self.assertEqual(k_energy(1000, 'reverse'), 0.0)

    def test_linear_scaling(self):
        c1 = k_energy(1)
        c100 = k_energy(100)
        self.assertAlmostEqual(c100, c1 * 100, places=20)


class TestKGrok(unittest.TestCase):

    def test_classic_grok_trajectory(self):
        train = [0.95] * 100 + [0.97] * 50
        test = [0.12] * 100 + [0.12 + i * 0.016 for i in range(50)]
        grokked, epoch, jump = k_grok_detect(train, test)
        self.assertTrue(grokked, "Failed to detect classic grokking")
        self.assertGreater(epoch, 80, "Grok detected too early")

    def test_no_false_grok_gradual(self):
        train = [0.5 + i*0.002 for i in range(200)]
        test = [0.45 + i*0.002 for i in range(200)]
        grokked, _, _ = k_grok_detect(train, test)
        self.assertFalse(grokked, "False grokking on gradual learning")

    def test_no_grok_memorize_only(self):
        train = [0.95] * 200
        test = [0.12] * 200
        grokked, _, _ = k_grok_detect(train, test)
        self.assertFalse(grokked, "False grokking with no test improvement")


class TestKMeasure(unittest.TestCase):

    def test_sine_high_K(self):
        t = np.linspace(0, 10*np.pi, 200)
        m = k_measure(np.sin(t).tolist())
        self.assertGreater(m['K'], 1.0)

    def test_noise_low_K(self):
        np.random.seed(42)
        m = k_measure(np.random.randn(200).tolist())
        self.assertLess(m['K'], 0.5)

    def test_constant_zero_T(self):
        m = k_measure([5.0] * 20)
        self.assertEqual(m['T'], 0.0)

    def test_too_few_samples(self):
        m = k_measure([1, 2])
        self.assertIn('error', m)


class TestKInterval(unittest.TestCase):

    def test_fifth(self):
        self.assertAlmostEqual(k_interval(3, 2), 1.7918, places=3)

    def test_tritone(self):
        self.assertAlmostEqual(k_interval(45, 32), 7.274, places=2)

    def test_unison(self):
        self.assertAlmostEqual(k_interval(1, 1), 0.0, places=10)


if __name__ == '__main__':
    unittest.main()
