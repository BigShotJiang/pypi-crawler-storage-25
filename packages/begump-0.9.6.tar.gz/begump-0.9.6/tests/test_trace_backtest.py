"""
BACKTEST — Real fraud patterns. Does Trace catch what auditors missed?
========================================================================
Each test reconstructs the STRUCTURE of a known fraud case using
synthetic data that mirrors the documented transaction patterns.

If Trace can't catch these, it can't be sold.
"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.trace import scan


class TestEnronStructure(unittest.TestCase):
    """Enron used Special Purpose Entities (SPEs) to hide debt.
    Structure: Enron → SPE → back to Enron (circular).
    SPEs like LJM, Chewco, JEDI were controlled by Enron insiders
    but treated as independent entities to move debt off-balance-sheet.

    Key pattern: money flows in circles through entities that
    all trace back to the same parent. High bidirectional flow
    between "independent" entities that shouldn't be connected."""

    def test_spe_circular_flow(self):
        """Enron → LJM → Chewco → Enron. Classic."""
        txs = [
            # Enron "sells" assets to SPE (moves debt off books)
            {'from': 'Enron', 'to': 'LJM', 'amount': 30_000_000},
            {'from': 'Enron', 'to': 'Chewco', 'amount': 12_000_000},
            {'from': 'Enron', 'to': 'JEDI', 'amount': 25_000_000},
            # SPEs "invest" back into Enron (circular guarantee)
            {'from': 'LJM', 'to': 'Enron', 'amount': 28_000_000},
            {'from': 'Chewco', 'to': 'JEDI', 'amount': 11_000_000},
            {'from': 'JEDI', 'to': 'Enron', 'amount': 22_000_000},
            # Chewco backed by Enron guarantee (circular)
            {'from': 'Chewco', 'to': 'Enron', 'amount': 10_000_000},
            # Normal business mixed in
            {'from': 'Enron', 'to': 'Supplier_A', 'amount': 5_000_000},
            {'from': 'Enron', 'to': 'Supplier_B', 'amount': 3_000_000},
            {'from': 'Customer_1', 'to': 'Enron', 'amount': 8_000_000},
            {'from': 'Customer_2', 'to': 'Enron', 'amount': 6_000_000},
        ]
        r = scan(txs)
        # MUST detect circular flows
        self.assertGreater(len(r['circular_flows']), 0,
            "FAILED: Missed Enron SPE circular flows — the pattern that fooled Arthur Andersen")
        # MUST detect Enron as concentration risk
        conc_names = [c['entity'] for c in r['concentration']]
        self.assertIn('Enron', conc_names,
            "FAILED: Missed Enron as concentration risk — it handled most of the flow")
        # Risk should be significant
        self.assertGreater(r['risk_score'], 30,
            f"Risk score only {r['risk_score']} — this is ENRON, should be flagged hard")
        # Should flag the Enron↔LJM relationship specifically
        circular_entities = set()
        for c in r['circular_flows']:
            if 'entity_a' in c:
                circular_entities.add(c['entity_a'])
                circular_entities.add(c['entity_b'])
            if 'path' in c:
                for e in c['path'].split(' → '):
                    circular_entities.add(e.strip())
        self.assertTrue('Enron' in circular_entities and 'LJM' in circular_entities,
            f"Flagged entities: {circular_entities} — must include Enron and LJM")

    def test_spe_hidden_relationships(self):
        """SPEs that don't directly transact but are spectrally close (same parent)."""
        txs = [
            {'from': 'Enron', 'to': 'LJM', 'amount': 30_000_000},
            {'from': 'Enron', 'to': 'Chewco', 'amount': 20_000_000},
            {'from': 'Enron', 'to': 'JEDI', 'amount': 25_000_000},
            # LJM and Chewco never transact directly
            # but they should have spectral tension (both connected to Enron)
        ]
        r = scan(txs)
        tension_pairs = set()
        for t in r['tensions']:
            tension_pairs.add(frozenset([t['entity_a'], t['entity_b']]))
        # LJM↔Chewco, LJM↔JEDI, or Chewco↔JEDI should appear
        spe_tension = any(
            frozenset([a, b]) in tension_pairs
            for a in ['LJM', 'Chewco', 'JEDI']
            for b in ['LJM', 'Chewco', 'JEDI']
            if a != b
        )
        self.assertTrue(spe_tension,
            "FAILED: Missed hidden relationships between SPEs — they all connect to Enron but not each other")


class TestMadoffStructure(unittest.TestCase):
    """Madoff Ponzi: new investor money pays old investor "returns."
    Pattern: many entities pay into a central hub, hub pays out to
    earlier entities. Net flow through hub should be near-zero
    (no real investment returns, just recycling)."""

    def test_ponzi_flow(self):
        """Classic Ponzi: 20 investors, central fund, early investors get "returns"."""
        txs = []
        # Phase 1: investors pay in
        for i in range(20):
            txs.append({'from': f'Investor_{i}', 'to': 'Madoff_Fund', 'amount': 500_000})
        # Phase 2: early investors get "returns" (paid from new money)
        for i in range(10):
            txs.append({'from': 'Madoff_Fund', 'to': f'Investor_{i}', 'amount': 600_000})

        r = scan(txs)
        # MUST detect bidirectional flows (fund pays investors who also paid in)
        self.assertGreater(len(r['circular_flows']), 0,
            "FAILED: Missed Ponzi bidirectional flows — investors paying in and getting paid out")
        # MUST detect extreme concentration
        conc_names = [c['entity'] for c in r['concentration']]
        self.assertIn('Madoff_Fund', conc_names,
            "FAILED: Missed Madoff_Fund as concentration — ALL money flows through it")
        # Risk should be very high
        self.assertGreater(r['risk_score'], 40,
            f"Ponzi scored only {r['risk_score']} — must be flagged hard")

    def test_ponzi_net_flow(self):
        """Madoff Fund should show net flow near zero (just recycling money)."""
        txs = []
        for i in range(20):
            txs.append({'from': f'Investor_{i}', 'to': 'Madoff_Fund', 'amount': 500_000})
        for i in range(15):
            txs.append({'from': 'Madoff_Fund', 'to': f'Investor_{i}', 'amount': 550_000})

        r = scan(txs)
        fund_flow = r['net_flow'].get('Madoff_Fund', {})
        received = fund_flow.get('received', 0)
        sent = fund_flow.get('sent', 0)
        # In a Ponzi, the fund receives almost as much as it sends (just passing through)
        if received > 0:
            throughput_ratio = sent / received
            self.assertGreater(throughput_ratio, 0.5,
                f"Fund throughput ratio only {throughput_ratio:.2f} — should be high (money just passes through)")


class TestWashTrading(unittest.TestCase):
    """Wash trading: same entity trades with itself through intermediaries
    to inflate volume. Pattern: A→B→A with similar amounts."""

    def test_direct_wash(self):
        """A sends to B, B sends back. Textbook wash."""
        txs = [
            {'from': 'TraderA', 'to': 'TraderB', 'amount': 1_000_000},
            {'from': 'TraderB', 'to': 'TraderA', 'amount': 995_000},
        ]
        r = scan(txs)
        self.assertGreater(len(r['circular_flows']), 0,
            "FAILED: Missed direct wash trading — A↔B with 99.5% return")
        # The ratio should be flagged as HIGH (>90% return)
        high_flags = [c for c in r['circular_flows'] if c.get('flag') == 'HIGH']
        self.assertGreater(len(high_flags), 0,
            "FAILED: Wash trading not flagged as HIGH risk")

    def test_layered_wash(self):
        """A→B→C→A. Layered wash trading through an intermediary."""
        txs = [
            {'from': 'Account_1', 'to': 'Account_2', 'amount': 500_000},
            {'from': 'Account_2', 'to': 'Account_3', 'amount': 490_000},
            {'from': 'Account_3', 'to': 'Account_1', 'amount': 480_000},
        ]
        r = scan(txs)
        triangular = [c for c in r['circular_flows'] if 'path' in c]
        self.assertGreater(len(triangular), 0,
            "FAILED: Missed layered wash trading — A→B→C→A")

    def test_wash_with_noise(self):
        """Wash trading hidden among 100 normal transactions."""
        import random
        random.seed(42)
        txs = []
        # 100 normal transactions between 20 entities
        entities = [f'Normal_{i}' for i in range(20)]
        for _ in range(100):
            a, b = random.sample(entities, 2)
            txs.append({'from': a, 'to': b, 'amount': random.uniform(1000, 50000)})
        # Hidden wash trades
        txs.append({'from': 'Washer_X', 'to': 'Washer_Y', 'amount': 200_000})
        txs.append({'from': 'Washer_Y', 'to': 'Washer_X', 'amount': 198_000})
        txs.append({'from': 'Washer_X', 'to': 'Washer_Z', 'amount': 150_000})
        txs.append({'from': 'Washer_Z', 'to': 'Washer_X', 'amount': 147_000})

        r = scan(txs)
        # Must find the wash trades among the noise
        circular_entities = set()
        for c in r['circular_flows']:
            if 'entity_a' in c:
                circular_entities.add(c['entity_a'])
                circular_entities.add(c['entity_b'])
        washer_found = 'Washer_X' in circular_entities or 'Washer_Y' in circular_entities
        self.assertTrue(washer_found,
            f"FAILED: Wash trades hidden in noise not detected. Found: {circular_entities}")


class TestFTXAlameda(unittest.TestCase):
    """FTX/Alameda: customer deposits went to Alameda Research.
    Pattern: customers → FTX → Alameda → FTX (circular with customer money).
    Alameda got special privileges, customer funds used for trading."""

    def test_ftx_alameda_structure(self):
        txs = []
        # Customers deposit into FTX
        for i in range(50):
            txs.append({'from': f'Customer_{i}', 'to': 'FTX', 'amount': 100_000})
        # FTX sends customer money to Alameda (the fraud)
        txs.append({'from': 'FTX', 'to': 'Alameda_Research', 'amount': 3_000_000})
        # Alameda "returns" some to FTX
        txs.append({'from': 'Alameda_Research', 'to': 'FTX', 'amount': 1_500_000})
        # FTX pays some withdrawals
        for i in range(20):
            txs.append({'from': 'FTX', 'to': f'Customer_{i}', 'amount': 80_000})

        r = scan(txs)
        # Must detect FTX↔Alameda circular flow
        circular_entities = set()
        for c in r['circular_flows']:
            if 'entity_a' in c:
                circular_entities.update([c['entity_a'], c['entity_b']])
        self.assertIn('FTX', circular_entities, "FAILED: Missed FTX in circular flows")
        self.assertIn('Alameda_Research', circular_entities,
            "FAILED: Missed Alameda Research in circular flows")
        # FTX must be concentration risk
        conc = [c['entity'] for c in r['concentration']]
        self.assertIn('FTX', conc, "FAILED: Missed FTX as concentration risk")
        # High risk
        self.assertGreater(r['risk_score'], 40,
            f"FTX/Alameda scored only {r['risk_score']} — this destroyed billions")


class TestDanskeBank(unittest.TestCase):
    """Danske Bank Estonian branch: $230B in suspicious transactions.
    Pattern: Russian/former-Soviet entities → Danske Estonia → Western banks.
    Layering through a branch that didn't do proper KYC."""

    def test_layering_through_branch(self):
        txs = []
        # Suspicious entities send money to Danske Estonia branch
        for i in range(30):
            txs.append({'from': f'Shell_Company_{i}', 'to': 'Danske_Estonia',
                        'amount': 5_000_000 + i * 100_000})
        # Danske Estonia forwards to Western banks (layering)
        txs.append({'from': 'Danske_Estonia', 'to': 'Deutsche_Bank', 'amount': 50_000_000})
        txs.append({'from': 'Danske_Estonia', 'to': 'JPMorgan', 'amount': 40_000_000})
        txs.append({'from': 'Danske_Estonia', 'to': 'Bank_of_America', 'amount': 30_000_000})
        # Some circular back
        txs.append({'from': 'Deutsche_Bank', 'to': 'Danske_Estonia', 'amount': 15_000_000})

        r = scan(txs)
        # Danske Estonia must be flagged as concentration risk
        conc = [c['entity'] for c in r['concentration']]
        self.assertIn('Danske_Estonia', conc,
            "FAILED: Missed Danske Estonia as the funnel point for $230B")
        # High risk score
        self.assertGreater(r['risk_score'], 30,
            f"Danske Bank pattern scored only {r['risk_score']}")
        # Shell companies and Danske should have tensions
        self.assertGreater(len(r['tensions']), 0,
            "FAILED: No hidden relationships detected in layering structure")


class TestCleanData(unittest.TestCase):
    """Control group: legitimate business patterns should NOT flag."""

    def test_normal_payroll(self):
        """Company pays 50 employees. No fraud."""
        txs = [{'from': 'Company', 'to': f'Employee_{i}', 'amount': 5000}
               for i in range(50)]
        r = scan(txs)
        self.assertEqual(len(r['circular_flows']), 0,
            "False flag on normal payroll")
        self.assertLess(r['risk_score'], 30,
            f"Clean payroll scored {r['risk_score']} — should be low")

    def test_normal_supply_chain(self):
        """Supplier → Manufacturer → Distributor → Retailer. Linear, no circles."""
        txs = [
            {'from': 'Raw_Supplier', 'to': 'Manufacturer', 'amount': 100_000},
            {'from': 'Manufacturer', 'to': 'Distributor', 'amount': 150_000},
            {'from': 'Distributor', 'to': 'Retailer_1', 'amount': 80_000},
            {'from': 'Distributor', 'to': 'Retailer_2', 'amount': 70_000},
        ]
        r = scan(txs)
        self.assertEqual(len(r['circular_flows']), 0,
            "False flag on normal supply chain")

    def test_normal_investment_fund(self):
        """10 investors → Fund → 5 portfolio companies. One-directional, legitimate."""
        txs = []
        for i in range(10):
            txs.append({'from': f'LP_{i}', 'to': 'VC_Fund', 'amount': 1_000_000})
        for i in range(5):
            txs.append({'from': 'VC_Fund', 'to': f'Portfolio_{i}', 'amount': 1_500_000})
        r = scan(txs)
        # Fund IS concentrated (expected), but no circular flows
        self.assertEqual(len(r['circular_flows']), 0,
            "False flag on normal VC fund — one-directional flow is legitimate")




class TestWirecardStructure(unittest.TestCase):
    """Wirecard: fake revenue through third-party acquirers.
    95% of EBITDA from 3 opaque entities. EUR 1.9B in phantom cash.
    Round-sum transfers. Loans to TPAs that grew in lockstep with "revenue"."""

    def test_round_trip_revenue(self):
        """Wirecard loans money to TPAs, TPAs report it as revenue back."""
        txs = [
            # Wirecard "loans" to TPAs
            {'from': 'Wirecard', 'to': 'Al_Alam', 'amount': 200_000_000},
            {'from': 'Wirecard', 'to': 'PayEasy', 'amount': 150_000_000},
            {'from': 'Wirecard', 'to': 'Senjo', 'amount': 120_000_000},
            # TPAs "pay" revenue back (the round-trip)
            {'from': 'Al_Alam', 'to': 'Wirecard', 'amount': 180_000_000},
            {'from': 'PayEasy', 'to': 'Wirecard', 'amount': 140_000_000},
            {'from': 'Senjo', 'to': 'Wirecard', 'amount': 110_000_000},
            # PayEasy also sends round-sum to shell (structuring)
            {'from': 'PayEasy', 'to': 'HK_Shell', 'amount': 100_000_000},
            # Normal merchant processing mixed in
            *[{'from': f'Merchant_{i}', 'to': 'Wirecard', 'amount': 500_000} for i in range(20)],
        ]
        r = scan(txs)
        # Must catch the circular flows
        self.assertGreater(len(r['circular_flows']), 0,
            "FAILED: Missed Wirecard round-trip revenue scheme")
        # Wirecard must be concentration risk
        conc = [c['entity'] for c in r['concentration']]
        self.assertIn('Wirecard', conc,
            "FAILED: Missed Wirecard as concentration point")
        # Risk should be high
        self.assertGreater(r['risk_score'], 40,
            f"Wirecard scored only {r['risk_score']} — EUR 1.9B fraud")

    def test_tpa_hidden_relationships(self):
        """Al Alam, PayEasy, Senjo never transact with each other
        but all connect to Wirecard — spectral tension should flag them."""
        txs = [
            {'from': 'Wirecard', 'to': 'Al_Alam', 'amount': 200_000_000},
            {'from': 'Wirecard', 'to': 'PayEasy', 'amount': 150_000_000},
            {'from': 'Wirecard', 'to': 'Senjo', 'amount': 120_000_000},
        ]
        r = scan(txs)
        tension_entities = set()
        for t in r['tensions']:
            tension_entities.add(t['entity_a'])
            tension_entities.add(t['entity_b'])
        tpa_tension = any(e in tension_entities for e in ['Al_Alam', 'PayEasy', 'Senjo'])
        self.assertTrue(tpa_tension,
            "FAILED: Missed hidden relationships between Wirecard TPAs")


class TestFinCENShellCompanies(unittest.TestCase):
    """FinCEN Files: shell companies with shared addresses layering
    money through correspondent banking."""

    def test_shell_company_layering(self):
        """Money flows: source → shell1 → shell2 → shell3 → destination.
        3+ hops through entities with no real business."""
        txs = [
            {'from': 'Russian_Entity', 'to': 'Shell_BVI_1', 'amount': 5_000_000},
            {'from': 'Shell_BVI_1', 'to': 'Shell_UK_2', 'amount': 4_900_000},
            {'from': 'Shell_UK_2', 'to': 'Shell_Cyprus_3', 'amount': 4_800_000},
            {'from': 'Shell_Cyprus_3', 'to': 'Real_Estate_London', 'amount': 4_700_000},
            # Second layering chain
            {'from': 'Azeri_Entity', 'to': 'Shell_BVI_4', 'amount': 3_000_000},
            {'from': 'Shell_BVI_4', 'to': 'Shell_UK_2', 'amount': 2_900_000},  # same shell!
            {'from': 'Shell_UK_2', 'to': 'Luxury_Goods_Paris', 'amount': 2_800_000},
        ]
        r = scan(txs)
        # Shell_UK_2 is the funnel — must be flagged
        conc = [c['entity'] for c in r['concentration']]
        has_funnel = 'Shell_UK_2' in conc
        # Also check tensions — Russian_Entity and Azeri_Entity should be linked through Shell_UK_2
        self.assertGreater(r['risk_score'], 5,
            "Shell layering should flag something")
        self.assertGreater(len(r['tensions']), 0,
            "FAILED: No hidden relationships in shell company network")

    def test_shared_address_entities(self):
        """60+ shell companies at the same address — all transact through one bank.
        Pattern: many sources → one hub → many destinations."""
        txs = []
        # 30 shell companies all send to Danske_Estonia
        for i in range(30):
            txs.append({'from': f'Lantana_Shell_{i}', 'to': 'Correspondent_Bank',
                        'amount': 1_000_000 + i * 50_000})
        # Correspondent forwards to destinations
        txs.append({'from': 'Correspondent_Bank', 'to': 'Swiss_Account', 'amount': 15_000_000})
        txs.append({'from': 'Correspondent_Bank', 'to': 'Dubai_RE', 'amount': 10_000_000})
        txs.append({'from': 'Correspondent_Bank', 'to': 'London_Property', 'amount': 8_000_000})

        r = scan(txs)
        # Correspondent bank must be extreme concentration
        conc = [c['entity'] for c in r['concentration']]
        self.assertIn('Correspondent_Bank', conc,
            "FAILED: Missed correspondent bank as money funnel for 30 shells")
        self.assertGreater(r['risk_score'], 25, "30 shells through one bank must flag")


class TestCollateralSelfReference(unittest.TestCase):
    """FTX used FTT token as collateral for loans FROM FTX.
    Enron used Enron stock to capitalize SPEs that hedged Enron.
    Pattern: entity backs its own obligations with its own assets."""

    def test_self_referential_collateral(self):
        """Company issues tokens, sends to subsidiary, subsidiary posts back as collateral."""
        txs = [
            # Company issues 1B in tokens to subsidiary
            {'from': 'FTX', 'to': 'Alameda', 'amount': 1_000_000_000},
            # Alameda posts tokens back as "collateral" for a loan
            {'from': 'Alameda', 'to': 'FTX', 'amount': 800_000_000},
            # FTX lends customer money to Alameda against this "collateral"
            {'from': 'FTX', 'to': 'Alameda', 'amount': 5_000_000_000},
            # Alameda sends some back
            {'from': 'Alameda', 'to': 'FTX', 'amount': 2_000_000_000},
        ]
        r = scan(txs)
        # Massive circular flow
        self.assertGreater(len(r['circular_flows']), 0,
            "FAILED: Missed self-referential collateral scheme")
        # Both entities should be flagged
        circular_entities = set()
        for c in r['circular_flows']:
            if 'entity_a' in c:
                circular_entities.update([c['entity_a'], c['entity_b']])
        self.assertIn('FTX', circular_entities)
        self.assertIn('Alameda', circular_entities)
        # Extreme risk
        self.assertGreater(r['risk_score'], 40, "Self-referential collateral must flag high")


if __name__ == '__main__':
    unittest.main(verbosity=2)
