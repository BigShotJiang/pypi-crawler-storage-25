"""Tests for gump.couple — 4-axis coupling profile between signals."""
import pytest
import numpy as np
from gump.couple import profile, quick


class TestProfile:
    """Coupling profile tests."""

    def test_identical_signals(self):
        x = np.sin(np.linspace(0, 10, 200))
        p = profile(x, x)
        assert p['K_overall'] >= 0.8  # identical signals should couple strongly
        assert p['profile_type'] in ('COUPLED', 'ENTRAINED', 'FLICKERING')

    def test_shifted_signals(self):
        t = np.linspace(0, 10, 200)
        x = np.sin(t)
        y = np.sin(t + 0.3)
        p = profile(x, y)
        assert p['K_overall'] > 0.5  # shifted but still coupled
        assert 'K_filter' in p
        assert 'K_bind' in p
        assert 'K_hierarchy' in p
        assert 'K_direction' in p

    def test_uncorrelated(self):
        np.random.seed(42)
        x = np.random.randn(200)
        y = np.random.randn(200)
        p = profile(x, y)
        assert p['K_overall'] < 0.5

    def test_sin_cos_quadrature(self):
        t = np.linspace(0, 10, 200)
        x = np.sin(t)
        y = np.cos(t)
        p = profile(x, y)
        # Sin and cos at 90 degrees: K_filter=0 (uncorrelated at zero lag)
        # but K_bind > 0 (same spectral content)
        assert p['K_bind'] > 0.3

    def test_direction_detection(self):
        t = np.linspace(0, 10, 200)
        x = np.sin(t)
        y = np.sin(t + 0.5)  # y follows x
        p = profile(x, y)
        assert 'direction_label' in p
        assert p['direction_label'] in ('A_DRIVES', 'B_DRIVES', 'MUTUAL')

    def test_all_keys_present(self):
        x = np.random.randn(200)
        y = np.random.randn(200)
        p = profile(x, y)
        expected_keys = ['K_filter', 'K_bind', 'K_hierarchy', 'K_direction',
                         'K_overall', 'profile_type', 'diagnosis', 'n']
        for k in expected_keys:
            assert k in p, f"Missing key: {k}"


class TestQuick:
    """Quick coupling summary tests."""

    def test_returns_string(self):
        x = np.sin(np.linspace(0, 10, 200))
        y = np.sin(np.linspace(0, 10, 200) + 0.3)
        q = quick(x, y)
        assert isinstance(q, str)
        assert 'K=' in q

    def test_coupled_signals(self):
        x = np.sin(np.linspace(0, 10, 200))
        q = quick(x, x)
        assert 'COUPLED' in q or 'ENTRAINED' in q

    def test_random_signals(self):
        np.random.seed(42)
        x = np.random.randn(200)
        y = np.random.randn(200)
        q = quick(x, y)
        assert 'K=' in q
