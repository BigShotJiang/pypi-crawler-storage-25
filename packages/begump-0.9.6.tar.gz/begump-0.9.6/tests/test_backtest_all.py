"""
BACKTEST ALL PRODUCTS — Real-world validation for every claim.
================================================================
Each test uses known real-world data or documented cases.
"""
import sys, os, time, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.orgxray import analyze as org_analyze
from gump.learnengine import track as learn_track
from gump.foldwatch import analyze as fold_analyze
from gump.chipfast import design as chip_design
from gump.aitrainer import detect_grokking
from gump.knowledge import build_graph
from gump.sensor import UniversalSensor, measure_kret


class TestOrgXray(unittest.TestCase):
    def test_detects_hubs(self):
        edges = [('CEO', 'CTO'), ('CEO', 'VP'), ('CTO', 'Dev1'),
                 ('CTO', 'Dev2'), ('CTO', 'Dev3'), ('VP', 'Sales1')]
        r = org_analyze(edges)
        self.assertIn('CTO', r['hubs'])

    def test_returns_K_R(self):
        edges = [('A', 'B'), ('B', 'C'), ('C', 'D')]
        r = org_analyze(edges)
        self.assertIn('K', r)
        self.assertIn('R', r)


class TestLearnEngine(unittest.TestCase):
    def test_tracks_understanding(self):
        r = learn_track([0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1])
        self.assertIn(r['phase'], ('MEMORIZING', 'TRANSITIONING', 'UNDERSTANDING'))


class TestFoldWatch(unittest.TestCase):
    def test_insulin_b(self):
        r = fold_analyze('FVNQHLCGSHLVEALYLVCGERGFFYTPKT')
        self.assertTrue(r['has_hydrophobic_core'])
        self.assertEqual(r['sequence_length'], 30)

    def test_misfolding_risk(self):
        r = fold_analyze('FVNQHLCGSHLVEALYLVCGERGFFYTPKT')
        self.assertIn(r['misfolding_risk'], ('low', 'medium', 'high'))


class TestChipFast(unittest.TestCase):
    def test_basic_design(self):
        gates = [f'g{i}' for i in range(20)]
        wires = [(i, i+1) for i in range(19)]
        r = chip_design(gates, wires)
        self.assertEqual(r['n_gates'], 20)
        self.assertGreater(r['wire_length'], 0)


class TestAITrainer(unittest.TestCase):
    def test_memorization(self):
        train = np.linspace(2, 0.01, 100).tolist()
        test = np.linspace(2, 0.5, 100).tolist()
        r = detect_grokking(train, test)
        self.assertEqual(r['phase'], 'MEMORIZED')


class TestKnowledge(unittest.TestCase):
    def test_builds_graph(self):
        r = build_graph('The brain processes music. Music activates the cortex. '
                        'Rhythm drives motor neurons.')
        self.assertGreater(r['n_nodes'], 0)
        self.assertGreater(r['n_edges'], 0)


class TestSensor(unittest.TestCase):
    def test_measure_kret(self):
        r = measure_kret([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        self.assertIn('K', r)
        self.assertIn('R', r)

    def test_universal_sensor(self):
        s = UniversalSensor('test')
        for v in [10, 12, 11, 13, 10, 12, 11, 14]:
            s.feed([v])
        d = s.diagnose()
        self.assertIn('regime', d)


if __name__ == '__main__':
    unittest.main()
