"""Tests for gump.sensor — Universal Sensor and K/R/E/T measurement."""
import sys, os, json, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.sensor import UniversalSensor, measure_kret, scan, detect_regime_change


class TestBasics(unittest.TestCase):
    def test_create(self):
        s = UniversalSensor('test')
        self.assertEqual(s.name, 'test')

    def test_feed_list(self):
        s = UniversalSensor()
        s.feed([1, 2, 3, 4, 5])
        self.assertEqual(len(s.data), 5)

    def test_feed_single(self):
        s = UniversalSensor()
        s.feed(3.14)
        self.assertEqual(len(s.data), 1)

    def test_feed_multiple(self):
        s = UniversalSensor()
        s.feed([1, 2, 3])
        s.feed([4, 5, 6])
        self.assertEqual(len(s.data), 6)


class TestDiagnose(unittest.TestCase):
    def test_diagnose_basic(self):
        s = UniversalSensor()
        s.feed([1, 2, 3, 4, 5, 6, 7, 8])
        d = s.diagnose()
        self.assertIn('K', d)
        self.assertIn('R', d)
        self.assertIn('T', d)
        self.assertIn('regime', d)

    def test_too_few_data(self):
        s = UniversalSensor()
        s.feed([1, 2])
        d = s.diagnose()
        self.assertEqual(d['regime'], 'unknown')

    def test_sine_wave_coherent(self):
        s = UniversalSensor()
        t = np.linspace(0, 4*np.pi, 100)
        s.feed(np.sin(t).tolist())
        d = s.diagnose()
        self.assertGreater(d['K'], 0.3)

    def test_regime_detection(self):
        s = UniversalSensor()
        s.feed(list(range(100)))
        d = s.diagnose()
        self.assertIn(d['regime'], ['locked', 'coherent', 'transitional', 'volatile', 'diffuse'])

    def test_anomaly_detection(self):
        s = UniversalSensor()
        data = [1.0] * 50 + [100.0] + [1.0] * 50
        s.feed(data)
        d = s.diagnose()
        self.assertGreater(len(d['anomalies']), 0)

    def test_volatile(self):
        np.random.seed(42)
        s = UniversalSensor()
        s.feed((np.random.randn(100) * 10).tolist())
        d = s.diagnose()
        self.assertIn('regime', d)


class TestMeasureKret(unittest.TestCase):
    def test_basic(self):
        r = measure_kret([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        self.assertIn('K', r)
        self.assertIn('R', r)
        self.assertIn('T', r)

    def test_constant_signal(self):
        r = measure_kret([5.0] * 20)
        self.assertEqual(r['T'], 0)

    def test_negative_values(self):
        r = measure_kret([-5, -3, -1, 0, 1, 3, 5])
        self.assertIn('K', r)


class TestScan(unittest.TestCase):
    def test_scan_basic(self):
        r = scan(list(range(200)), window=20)
        self.assertGreater(len(r), 0)
        self.assertIn('K', r[0])

    def test_scan_large(self):
        r = scan(np.random.randn(10000).tolist(), window=100)
        self.assertGreater(len(r), 0)


class TestEdgeCases(unittest.TestCase):
    def test_json_serializable(self):
        s = UniversalSensor()
        s.feed([1, 2, 3, 4, 5, 6, 7, 8])
        d = s.diagnose()
        json.dumps(d, default=str)


if __name__ == '__main__':
    unittest.main()
