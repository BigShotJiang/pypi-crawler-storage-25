"""
ATTACK THE LEDGER — Try to break it every way a real attacker would.
=====================================================================
If any of these attacks succeed, the product is worthless.

Run: cd gump-package && python tests/test_ledger_attacks.py -v
"""
import sys, os, time, copy, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.ledger import Ledger, Wallet, Transaction, Block, _hash


class TestDoubleSpend(unittest.TestCase):
    """The #1 attack on any payment system."""

    def test_spend_more_than_balance(self):
        """Try to send more than you have."""
        l = Ledger()
        a = Wallet('attacker', seed='a')
        b = Wallet('victim', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 100)
        tx = l.transfer(a, b, 500)
        self.assertIn('error', tx, "HACKED: Spent 500 with only 100 balance")

    def test_drain_then_spend_again(self):
        """Send everything, then try to send more."""
        l = Ledger()
        a = Wallet('attacker', seed='a')
        b = Wallet('b1', seed='b1')
        c = Wallet('b2', seed='b2')
        l.register(a); l.register(b); l.register(c)
        l.mint(a, 1000)
        l.transfer(a, b, 1000)  # drain
        tx = l.transfer(a, c, 1)  # try to spend again
        self.assertIn('error', tx, "HACKED: Spent after draining to zero")
        self.assertAlmostEqual(l._balance_from_chain(a.address), 0)

    def test_rapid_double_spend(self):
        """Send the same money to two people quickly."""
        l = Ledger()
        a = Wallet('attacker', seed='a')
        b = Wallet('victim1', seed='b')
        c = Wallet('victim2', seed='c')
        l.register(a); l.register(b); l.register(c)
        l.mint(a, 100)
        tx1 = l.transfer(a, b, 100)
        tx2 = l.transfer(a, c, 100)
        self.assertNotIn('error', tx1, "First spend should work")
        self.assertIn('error', tx2, "HACKED: Double spend succeeded")
        self.assertAlmostEqual(l._balance_from_chain(b.address), 100)
        self.assertAlmostEqual(l._balance_from_chain(c.address), 0)

    def test_conservation_after_many_transfers(self):
        """Money must be conserved no matter how many transfers."""
        l = Ledger()
        wallets = [Wallet(f'w{i}', seed=f's{i}') for i in range(10)]
        for w in wallets: l.register(w)
        l.mint(wallets[0], 10000)

        np.random.seed(42)
        for _ in range(200):
            sender = wallets[np.random.randint(0, 10)]
            receiver = wallets[np.random.randint(0, 10)]
            if sender.address != receiver.address and l._balance_from_chain(sender.address) > 1:
                amount = min(l._balance_from_chain(sender.address) * 0.3, l._balance_from_chain(sender.address))
                l.transfer(sender, receiver, round(amount, 2))

        total = sum(l._balance_from_chain(w.address) for w in wallets)
        self.assertAlmostEqual(total, 10000.0, places=2,
            msg=f"HACKED: Conservation broken after 200 transfers. Total={total}")


class TestForgery(unittest.TestCase):
    """Try to create fake transactions and blocks."""

    def test_forge_transaction_wrong_signature(self):
        """Create a transaction and sign with wrong wallet."""
        l = Ledger()
        a = Wallet('alice', seed='a')
        b = Wallet('bob', seed='b')
        fake = Wallet('fake', seed='fake')
        l.register(a); l.register(b); l.register(fake)
        l.mint(a, 1000)

        # Create transaction from alice but sign with fake's key
        tx = Transaction(a.address, b.address, 500, a.nonce)
        tx.sign(fake)  # wrong signer

        # Manual verification should fail
        expected_sig = a.sign(tx.hash)
        self.assertNotEqual(tx.signature, expected_sig,
            "HACKED: Forged signature accepted")

    def test_modify_transaction_after_signing(self):
        """Sign a transaction, then change the amount."""
        l = Ledger()
        a = Wallet('alice', seed='a')
        b = Wallet('bob', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 1000)

        tx = Transaction(a.address, b.address, 100, a.nonce)
        tx.sign(a)
        original_sig = tx.signature

        # Tamper with amount
        tx.amount = 999
        tx.hash = tx._compute_hash()  # recompute hash

        # Signature no longer matches
        expected_sig = a.sign(tx.hash)
        self.assertNotEqual(original_sig, expected_sig,
            "HACKED: Modified transaction still has valid signature")

    def test_tamper_block_chain(self):
        """Modify a block and check if chain integrity catches it."""
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 1000)
        l.transfer(a, b, 500)
        l.forge_block()
        l.transfer(b, a, 200)
        l.forge_block()

        # Tamper with block 0's hash
        original_hash = l.chain[0].hash
        l.chain[0].hash = 'tampered' + original_hash[8:]

        # Block 1's prev_hash should no longer match
        audit = l.audit()
        self.assertFalse(audit['chain_valid'],
            "HACKED: Tampered block chain not detected")

    def test_create_money_from_nothing(self):
        """Try to increase balance without minting.
        In v2, balance is derived from chain — there IS no wallet.balance to tamper.
        The attack vector is gone by design. Verify it."""
        l = Ledger()
        a = Wallet('attacker', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 100)
        # Can't tamper — balance derived from chain
        self.assertFalse(hasattr(a, 'balance'),
            "Wallet still has a .balance attribute — attack surface exists")
        # Verify actual balance is correct
        self.assertAlmostEqual(l._balance_from_chain(a.address), 100)
        # Try to overspend — should fail
        tx = l.transfer(a, b, 50000)
        self.assertIn('error', tx, "HACKED: Overspend succeeded")


class TestReplay(unittest.TestCase):
    """Try to replay old transactions."""

    def test_nonce_increments(self):
        """Each transfer must increment nonce."""
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 1000)
        n0 = a.nonce
        l.transfer(a, b, 100)
        self.assertEqual(a.nonce, n0 + 1)
        l.transfer(a, b, 100)
        self.assertEqual(a.nonce, n0 + 2)

    def test_same_transaction_different_hash(self):
        """Same sender/receiver/amount at different times = different hash."""
        tx1 = Transaction('s', 'r', 100, 0, timestamp=1000.0)
        tx2 = Transaction('s', 'r', 100, 0, timestamp=1001.0)
        self.assertNotEqual(tx1.hash, tx2.hash,
            "HACKED: Same params at different times produce same hash — replay possible")

    def test_nonce_makes_replay_unique(self):
        """Same everything but different nonce = different hash."""
        tx1 = Transaction('s', 'r', 100, 0, timestamp=1000.0)
        tx2 = Transaction('s', 'r', 100, 1, timestamp=1000.0)
        self.assertNotEqual(tx1.hash, tx2.hash,
            "HACKED: Nonce doesn't affect hash — replay attack possible")


class TestNegativeAmounts(unittest.TestCase):
    """Try to steal money with negative transfers."""

    def test_negative_transfer(self):
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 100)
        tx = l.transfer(a, b, -50)  # negative = steal FROM b
        self.assertIn('error', tx, "HACKED: Negative transfer accepted")

    def test_zero_transfer(self):
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 100)
        tx = l.transfer(a, b, 0)
        self.assertIn('error', tx, "HACKED: Zero transfer accepted (spam vector)")

    def test_tiny_amount(self):
        """Very small amounts should still work (no dust attack blocking)."""
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 100)
        tx = l.transfer(a, b, 0.00000001)
        self.assertNotIn('error', tx, "Blocked legitimate tiny transfer")


class TestUnregistered(unittest.TestCase):
    """Try to transact with unknown wallets."""

    def test_transfer_from_unknown(self):
        l = Ledger()
        a = Wallet('ghost', seed='g')
        b = Wallet('b', seed='b')
        l.register(b)
        # Don't register a
        tx = l.transfer(a, b, 100)
        self.assertIn('error', tx, "HACKED: Unregistered sender can transfer")

    def test_transfer_to_unknown(self):
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('ghost', seed='g')
        l.register(a)
        l.mint(a, 100)
        tx = l.transfer(a, b, 50)
        self.assertIn('error', tx, "HACKED: Can send to unregistered wallet")

    def test_mint_to_unknown(self):
        l = Ledger()
        a = Wallet('ghost', seed='g')
        try:
            l.mint(a, 1000)
            self.fail("HACKED: Can mint to unregistered wallet")
        except ValueError:
            pass  # expected


class TestSpectralAudit(unittest.TestCase):
    """Test that spectral audit actually catches suspicious patterns."""

    def test_circular_transfers_detected(self):
        """A→B→C→A is a wash trading pattern. Audit should flag tension."""
        l = Ledger()
        wallets = [Wallet(f'w{i}', seed=f's{i}') for i in range(4)]
        for w in wallets: l.register(w)
        l.mint(wallets[0], 10000)
        # Circular: 0→1→2→3
        l.transfer(wallets[0], wallets[1], 1000)
        l.transfer(wallets[1], wallets[2], 900)
        l.transfer(wallets[2], wallets[3], 800)
        l.forge_block()
        audit = l.audit()
        # Wallets 0 and 3 have no direct transaction but are connected through chain
        # Tension detection should find this
        self.assertIsInstance(audit['tensions'], list)

    def test_audit_after_many_blocks(self):
        """Audit should work after many blocks."""
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 100000)
        for i in range(50):
            l.transfer(a, b, 10)
            l.transfer(b, a, 5)
            if i % 10 == 0:
                l.forge_block()
        l.forge_block()
        audit = l.audit()
        self.assertTrue(audit['chain_valid'])
        self.assertTrue(audit['balances_valid'])


class TestEdgeCases(unittest.TestCase):

    def test_float_precision(self):
        """Floating point shouldn't break conservation."""
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 1.0)
        # Transfer 0.1 ten times
        for _ in range(10):
            l.transfer(a, b, 0.1)
        # a should be ~0, b should be ~1
        self.assertAlmostEqual(l._balance_from_chain(a.address) + l._balance_from_chain(b.address), 1.0, places=10,
            msg="Float precision broke conservation")

    def test_empty_block(self):
        l = Ledger()
        result = l.forge_block()
        self.assertIn('error', result)

    def test_massive_amount(self):
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a); l.register(b)
        l.mint(a, 1e18)  # quintillion
        tx = l.transfer(a, b, 1e17)
        self.assertNotIn('error', tx)
        self.assertAlmostEqual(l._balance_from_chain(a.address) + l._balance_from_chain(b.address), 1e18)


if __name__ == '__main__':
    unittest.main(verbosity=2)
