"""Tests for the Gurgle Detector."""
import math
import numpy as np
from gump.tune import coherence, detect, anomaly_detect


def test_pure_tone_is_coherent():
    """A pure sine wave should have high coherence."""
    t = np.arange(1000) / 1000
    signal = np.sin(2 * np.pi * 10 * t)
    score = coherence(signal)
    assert score > 0.3, f"Pure tone coherence {score} should be > 0.3"


def test_noise_is_incoherent():
    """White noise should have low coherence."""
    np.random.seed(42)
    signal = np.random.randn(1000)
    score = coherence(signal)
    assert score < 0.15, f"Noise coherence {score} should be < 0.15"


def test_constant_is_zero():
    """A constant signal has no dynamics to evaluate."""
    signal = np.ones(1000)
    score = coherence(signal)
    assert score == 0.0, f"Constant coherence {score} should be 0"


def test_silence_is_zero():
    """An all-zeros signal has no dynamics."""
    signal = np.zeros(1000)
    score = coherence(signal)
    assert score == 0.0


def test_tone_beats_noise():
    """Tone should score higher than noise."""
    t = np.arange(1000) / 1000
    tone = np.sin(2 * np.pi * 10 * t)
    np.random.seed(42)
    noise = np.random.randn(1000)
    assert coherence(tone) > coherence(noise)


def test_detect_finds_peak():
    """detect should return a peak parameter."""
    def system(K):
        # Simple: sine at high K, noise at low K
        t = np.arange(500) / 500
        np.random.seed(42)
        return K * np.sin(2 * np.pi * 5 * t) + (1 - K / 5) * np.random.randn(500)

    result = detect(system, (0, 5), resolution=30, n_trials=1)
    assert result['peak'] is not None
    assert result['peak_score'] > 0


def test_anomaly_detects_change():
    """anomaly_detect should find where coherence drops."""
    np.random.seed(42)
    t = np.arange(1000) / 100
    signal = np.sin(2 * np.pi * t) + 0.1 * np.random.randn(1000)
    # Add anomaly at sample 500
    signal[500:] += np.random.randn(500) * 3.0

    result = anomaly_detect(signal, window=80, threshold=0.05)
    # Should detect a coherence drop somewhere after the anomaly
    assert len(result['scores']) > 0
    # Coherence should be lower after the anomaly than before
    mid = len(result['scores']) // 2
    before = np.mean(result['scores'][:mid - 50])
    after = np.mean(result['scores'][mid + 50:])
    assert after < before, f"After ({after:.3f}) should be less coherent than before ({before:.3f})"


def test_kuramoto_critical():
    """The peak should be near K_c for Kuramoto oscillators."""
    def kuramoto(K):
        N = 20
        np.random.seed(42)
        omegas = np.random.standard_normal(N) * 2
        phases = np.zeros(N)
        dt = 0.05
        trace = []
        for step in range(400):
            mre = np.mean(np.cos(phases))
            mim = np.mean(np.sin(phases))
            R = math.sqrt(mre ** 2 + mim ** 2)
            trace.append(R)
            mp = math.atan2(mim, mre)
            phases += dt * (omegas + K * np.sin(mp - phases))
        return trace

    result = detect(kuramoto, (0, 6), resolution=30, n_trials=2)
    # K_c ≈ 3.2 for this distribution
    assert result['peak'] is not None
    assert 1.0 < result['peak'] < 5.0, f"Peak at {result['peak']}, expected near 3"


def test_short_signal():
    """Short signals should return 0 coherence, not crash."""
    assert coherence([1, 2, 3]) == 0.0
    assert coherence([]) == 0.0


def test_nan_handling():
    """NaN values in signal should be handled gracefully."""
    signal = [1.0, 2.0, float('nan'), 3.0, 4.0] * 20
    score = coherence(signal)
    assert np.isfinite(score)


if __name__ == '__main__':
    tests = [
        test_pure_tone_is_coherent,
        test_noise_is_incoherent,
        test_constant_is_zero,
        test_silence_is_zero,
        test_tone_beats_noise,
        test_detect_finds_peak,
        test_anomaly_detects_change,
        test_kuramoto_critical,
        test_short_signal,
        test_nan_handling,
    ]
    passed = 0
    for test in tests:
        try:
            test()
            print(f'  ✓ {test.__name__}')
            passed += 1
        except Exception as e:
            print(f'  ✗ {test.__name__}: {e}')
    print(f'\n  {passed}/{len(tests)} passed')
