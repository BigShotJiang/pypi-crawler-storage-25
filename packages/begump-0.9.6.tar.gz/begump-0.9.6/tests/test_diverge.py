"""Tests for gump.diverge — parallel response divergence detector."""
import pytest
from gump.diverge import diverge, diverge_batch, distance


class TestDiverge:
    """Core diverge() function tests."""

    def test_identical_responses(self):
        r = diverge(["The answer is 42", "The answer is 42", "The answer is 42"])
        assert r['divergence_score'] == 0.0
        assert r['diagnosis'] == 'converged'
        assert r['n'] == 3

    def test_completely_different(self):
        r = diverge(["apple banana cherry", "dog elephant fox", "guitar harmonica piano"])
        assert r['divergence_score'] == 1.0
        assert r['diagnosis'] == 'divergent'

    def test_partially_similar(self):
        r = diverge(["The protein folds tight", "The protein unfolds", "The protein is stable"])
        assert 0.0 < r['divergence_score'] < 1.0
        assert 'protein' in r['consensus']

    def test_single_response(self):
        r = diverge(["only one response"])
        assert r['diagnosis'] == 'insufficient data'
        assert r['n'] == 1

    def test_empty_input(self):
        r = diverge([])
        assert r['diagnosis'] == 'no data'
        assert r['n'] == 0

    def test_none_input(self):
        r = diverge(None)
        assert r['diagnosis'] == 'no data'

    def test_two_responses(self):
        r = diverge(["hello world", "hello there"])
        assert r['n'] == 2
        assert 'hello' in r['consensus']

    def test_numbers_are_tokenized(self):
        """Regression: numbers were dropped by old tokenizer."""
        r = diverge(["42", "42", "42"])
        assert r['divergence_score'] == 0.0
        assert r['diagnosis'] == 'converged'

    def test_numbers_in_context(self):
        """Consensus should include numeric tokens."""
        r = diverge(["price is 100", "the price is 100", "cost: 100 dollars"])
        assert '100' in r['consensus']

    def test_pure_numeric_divergence(self):
        r = diverge(["42", "43", "99"])
        assert r['divergence_score'] == 1.0

    def test_empty_strings_filtered(self):
        r = diverge(["hello", "", "hello"])
        assert r['n'] == 2

    def test_non_string_input(self):
        """Non-strings should be coerced."""
        r = diverge([42, 42, 42])
        assert r['diagnosis'] == 'converged'

    def test_splits_found(self):
        r = diverge([
            "The answer is coupling",
            "The answer is energy",
            "The answer is coupling",
        ])
        # 'coupling' appears in 2/3, 'energy' in 1/3
        assert 'coupling' in r['splits'] or 'energy' in r['splits']


class TestDivergeBatch:
    """Batch mode tests."""

    def test_batch_dict(self):
        results = diverge_batch({
            'q1': ["yes", "yes", "yes"],
            'q2': ["cat", "dog", "fish"],
        })
        assert results['most_converged'] == 'q1'
        assert results['most_divergent'] == 'q2'

    def test_batch_list(self):
        results = diverge_batch([
            ["same", "same"],
            ["different", "words"],
        ])
        assert 0 in results['per_prompt']
        assert 1 in results['per_prompt']

    def test_batch_empty(self):
        results = diverge_batch({})
        assert results['mean_divergence'] == 0.0


class TestDistance:
    """Convenience distance() function tests."""

    def test_identical(self):
        assert distance("hello world", "hello world") == 0.0

    def test_no_overlap(self):
        assert distance("apple", "banana") == 1.0

    def test_partial(self):
        d = distance("hello world", "hello there")
        assert 0.0 < d < 1.0

    def test_numbers_counted(self):
        """Numbers should contribute to similarity."""
        d = distance("error 404", "error 404")
        assert d == 0.0
