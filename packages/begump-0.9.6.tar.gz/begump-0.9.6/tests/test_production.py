"""
PRODUCTION TESTS — Break everything. Find the boundaries.
============================================================
Every product must fail where we say it fails and work where we say it works.
"""
import sys, os, json, time, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.core import (
    tensions, redundancies, place, clusters, resolution_path,
    EnergyTracker, interval_cost, coupling_energy, K_CEILING, PHI, LANDAUER_PER_BIT
)
from gump.orgxray import analyze as org_analyze
from gump.learnengine import track as learn_track
from gump.foldwatch import analyze as fold_analyze, compare as fold_compare
from gump.chipfast import design as chip_design, design_netlist
from gump.aitrainer import detect_grokking
from gump.knowledge import build_graph
from gump.sensor import UniversalSensor, measure_kret
from gump.coupling_license import (
    CouplingLicense, _machine_fingerprint, _spectral_hash,
    K_PEAK, K_MIN, K_DECAY_RATE, RECOUPLE_INTERVAL
)


class TestCore(unittest.TestCase):
    def test_k_measure_numbers_in_numbers_out(self):
        from gump.core import k_measure
        r = k_measure([1, 2, 3, 4, 5])
        self.assertIsInstance(r['K'], (int, float))
        self.assertIsInstance(r['R'], (int, float))

    def test_tensions_returns_list(self):
        r = tensions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        self.assertIsInstance(r, list)

    def test_energy_tracker(self):
        et = EnergyTracker()
        et.erase(100)
        self.assertEqual(et.bits_erased, 100)
        self.assertAlmostEqual(et.total_joules, 100 * LANDAUER_PER_BIT)

    def test_interval_cost(self):
        cost = interval_cost(3/2)
        self.assertGreater(cost, 0)


class TestChipFast(unittest.TestCase):
    def test_design(self):
        gates = [f'g{i}' for i in range(10)]
        wires = [(i, i+1) for i in range(9)]
        r = chip_design(gates, wires)
        self.assertEqual(r['n_gates'], 10)

    def test_design_netlist(self):
        r = design_netlist('and g0 (y, a, b); or g1 (z, y, c);')
        self.assertEqual(r['n_gates'], 2)

    def test_too_few_gates(self):
        r = chip_design(['g0'], [])
        self.assertIn('error', r)


class TestFoldWatch(unittest.TestCase):
    def test_analyze(self):
        r = fold_analyze('ACDEFGHIKLMNPQRSTVWY')
        self.assertEqual(r['sequence_length'], 20)

    def test_compare(self):
        r = fold_compare('ACDEFGHIKLMNPQRSTVWY', 'ACDEFGHIKLMNPQRSTVWF')
        self.assertIn('length_a', r)
        self.assertIn('risk_a', r)


class TestSensor(unittest.TestCase):
    def test_universal_sensor(self):
        s = UniversalSensor('cpu')
        for v in [23, 24, 25, 23, 22, 24, 25, 26]:
            s.feed([v])
        d = s.diagnose()
        self.assertIn('regime', d)
        self.assertGreater(d['K'], 0)


class TestLicense(unittest.TestCase):
    def test_fingerprint(self):
        fp = _machine_fingerprint()
        self.assertIsInstance(fp, str)
        self.assertGreater(len(fp), 10)

    def test_spectral_hash(self):
        h1 = _spectral_hash('test')
        h2 = _spectral_hash('test')
        self.assertEqual(h1, h2)

    def test_different_inputs(self):
        h1 = _spectral_hash('a')
        h2 = _spectral_hash('b')
        self.assertNotEqual(h1, h2)


if __name__ == '__main__':
    unittest.main()
