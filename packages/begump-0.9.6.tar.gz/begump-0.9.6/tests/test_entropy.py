"""Tests for gump.entropy — antropy with K brain."""
import pytest
import numpy as np
from gump.entropy import profile, diagnose


class TestProfile:
    """Entropy profile tests."""

    def test_sine_wave(self):
        x = np.sin(np.linspace(0, 20, 500))
        p = profile(x)
        assert 'features' in p
        assert 'K' in p
        assert 'R' in p
        assert 'E' in p
        assert 'T' in p
        assert 'diagnosis' in p
        assert 'detail' in p

    def test_random_noise(self):
        x = np.random.randn(500)
        p = profile(x)
        assert p['K'] < 1.0  # noise should have low coupling
        assert p['diagnosis'] in ('decoupled', 'decoupling', 'loosely coupled', 'phase-locked')

    def test_deterministic_high_k(self):
        x = np.sin(np.linspace(0, 20, 500))
        p = profile(x)
        assert p['K'] > 1.0  # pure sine should have high coupling

    def test_constant_signal(self):
        x = np.ones(500)
        p = profile(x)
        # Constant signal should still return valid result
        assert isinstance(p['K'], (int, float))

    def test_short_signal(self):
        """Short signals return error dict, not K."""
        x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        p = profile(x)
        assert 'error' in p  # too short for entropy analysis

    def test_features_are_numeric(self):
        x = np.random.randn(500)
        p = profile(x)
        for k, v in p['features'].items():
            assert isinstance(v, (int, float, np.integer, np.floating)), f"Feature {k} is {type(v)}"


class TestDiagnose:
    """Diagnose function tests."""

    def test_random_decoupling(self):
        x = np.random.randn(500)
        d = diagnose(x)
        assert d in ('decoupled', 'decoupling', 'loosely coupled', 'phase-locked')

    def test_returns_string(self):
        x = np.sin(np.linspace(0, 10, 200))
        d = diagnose(x)
        assert isinstance(d, str)
        assert len(d) > 0
