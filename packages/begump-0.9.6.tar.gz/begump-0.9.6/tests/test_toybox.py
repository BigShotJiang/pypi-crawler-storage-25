"""Tests for gump.toybox — Demo pages that can't be gamed"""
import sys, os, unittest, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.toybox import generate_demo, generate_all_demos, DEMO_DATA

class TestDemoGeneration(unittest.TestCase):
    def test_all_products_have_demo(self):
        expected = ['orgxray','learnengine','foldwatch','chipfast','aitrainer','knowledge','sensor']
        for p in expected:
            self.assertIn(p, DEMO_DATA, f"Missing demo data for {p}")

    def test_each_demo_valid_html(self):
        for key in DEMO_DATA:
            html = generate_demo(key)
            self.assertIn('<html', html, f"{key} missing html tag")
            self.assertIn(DEMO_DATA[key]['title'], html, f"{key} missing title")
            self.assertIn('TRY IT', html, f"{key} missing demo section")
            self.assertIn('_gumpFP', html, f"{key} missing fingerprint JS")

    def test_each_demo_has_3_outputs(self):
        for key in DEMO_DATA:
            html = generate_demo(key)
            self.assertIn("DEMO_OUTPUTS", html, f"{key} missing demo outputs")

    def test_each_demo_has_pricing(self):
        for key in DEMO_DATA:
            html = generate_demo(key)
            price = DEMO_DATA[key]['price']
            self.assertIn(price, html, f"{key} missing price {price}")

    def test_each_demo_has_competitor_mention(self):
        for key in DEMO_DATA:
            html = generate_demo(key)
            self.assertIn('Replaces:', html, f"{key} missing competitor comparison")

    def test_each_demo_has_killer_feature(self):
        for key in DEMO_DATA:
            self.assertGreater(len(DEMO_DATA[key]['killer']), 20,
                f"{key} killer feature too short")

    def test_generate_all(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            keys = generate_all_demos(tmpdir)
            self.assertEqual(len(keys), 7)
            for key in keys:
                path = os.path.join(tmpdir, f'try-{key}.html')
                self.assertTrue(os.path.exists(path), f"Missing file: {path}")
                size = os.path.getsize(path)
                self.assertGreater(size, 5000, f"{key} demo too small: {size} bytes")

    def test_unknown_product(self):
        html = generate_demo('nonexistent')
        self.assertIn('Unknown', html)

    def test_demo_limit_in_js(self):
        for key in DEMO_DATA:
            html = generate_demo(key)
            limit = DEMO_DATA[key]['demo_limit']
            self.assertIn(f'MAX_TRIES = {limit}', html)

    def test_anti_abuse_triple_storage(self):
        """Verify fingerprint stores in localStorage + cookie + backup key"""
        html = generate_demo('orgxray')
        self.assertIn('localStorage.setItem(key,', html)
        self.assertIn('localStorage.setItem(keyB,', html)
        self.assertIn('document.cookie', html)

if __name__ == '__main__':
    unittest.main()
