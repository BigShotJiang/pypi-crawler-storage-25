"""Tests for gump.turbo — K expression evaluator."""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.turbo import compile_k, run


class TestCompileK(unittest.TestCase):
    def test_valid_expression(self):
        r = compile_k('K(5)')
        self.assertTrue(r['compiled'])

    def test_invalid_characters(self):
        r = compile_k('import os; os.system("rm")')
        self.assertIn('error', r)


class TestRun(unittest.TestCase):
    def test_K_function(self):
        r = run('K(5)')
        self.assertAlmostEqual(r['result'], 5/6, places=5)

    def test_R_function(self):
        r = run('R(2)')
        self.assertIsInstance(r['result'], float)

    def test_E_function(self):
        r = run('E(100)')
        self.assertGreater(r['result'], 0)

    def test_T_function(self):
        r = run('K(5) - R(5)')
        self.assertIsInstance(r['result'], float)

    def test_arithmetic(self):
        r = run('K(3) + R(4)')
        self.assertIsInstance(r['result'], float)

    def test_invalid_expression(self):
        r = run('undefined_func(5)')
        self.assertIn('error', r)


if __name__ == '__main__':
    unittest.main()
