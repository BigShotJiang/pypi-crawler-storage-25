"""Tests for gump.knowledge — Knowledge graph builder."""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.knowledge import build_graph


class TestBuildGraph(unittest.TestCase):
    def test_basic(self):
        r = build_graph('The brain processes music. Music activates the cortex.')
        self.assertIn('nodes', r)
        self.assertIn('edges', r)
        self.assertGreater(r['n_nodes'], 0)

    def test_empty_text(self):
        r = build_graph('')
        self.assertEqual(r['n_nodes'], 0)

    def test_gaps_detected(self):
        text = ('The brain processes music. Music activates the cortex. '
                'Rhythm drives motor neurons. The brain and rhythm are coupled.')
        r = build_graph(text)
        self.assertIn('gaps', r)

    def test_K_and_R(self):
        text = 'A connects to B. B connects to C. C connects to A.'
        r = build_graph(text)
        self.assertIn('K', r)
        self.assertIn('R', r)

    def test_stopwords_excluded(self):
        r = build_graph('The cat sat on the mat with a hat.')
        for node in r['nodes']:
            self.assertNotIn(node, ('the', 'on', 'with'))


if __name__ == '__main__':
    unittest.main()
