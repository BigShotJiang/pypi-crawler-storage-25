"""Tests for gump.learnengine — Learning progress tracker."""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.learnengine import track


class TestTrack(unittest.TestCase):
    def test_insufficient_data(self):
        r = track([1, 0])
        self.assertEqual(r['phase'], 'INSUFFICIENT_DATA')

    def test_learning_phase(self):
        r = track([0, 0, 1, 0, 0, 1, 0, 0, 1, 0])
        self.assertIn(r['phase'], ('LEARNING', 'MEMORIZING'))

    def test_understanding_phase(self):
        r = track([0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1])
        self.assertIn(r['phase'], ('MEMORIZING', 'TRANSITIONING', 'UNDERSTANDING'))

    def test_output_fields(self):
        r = track([1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1])
        self.assertIn('phase', r)
        self.assertIn('accuracy', r)
        self.assertIn('trend', r)
        self.assertIn('K_consistency', r)
        self.assertIn('n_responses', r)
        self.assertIn('n_correct', r)

    def test_accuracy_correct(self):
        r = track([1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
        self.assertAlmostEqual(r['accuracy'], 1.0)

    def test_n_correct(self):
        r = track([1, 0, 1, 0, 1, 0, 1, 0, 1, 0])
        self.assertEqual(r['n_correct'], 5)


if __name__ == '__main__':
    unittest.main()
