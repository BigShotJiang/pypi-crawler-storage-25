"""
Tests for gump.ledger — Physics-based payment system
Every transaction has a provable energy cost. No mining. No waste.
"""
import sys, os, json, time, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.ledger import Ledger, Wallet, Transaction, _hash, _merkle_root
from gump.core import LANDAUER_PER_BIT


class TestSpectralHash(unittest.TestCase):

    def test_deterministic(self):
        h1 = _hash('hello')
        h2 = _hash('hello')
        self.assertEqual(h1, h2)

    def test_different_inputs(self):
        h1 = _hash('hello')
        h2 = _hash('world')
        self.assertNotEqual(h1, h2)

    def test_avalanche(self):
        """Tiny change in input → big change in hash."""
        h1 = _hash('test1')
        h2 = _hash('test2')
        # Count differing characters
        diffs = sum(1 for a, b in zip(h1, h2) if a != b)
        self.assertGreater(diffs, len(h1) * 0.3,
            f"Only {diffs}/{len(h1)} chars differ — weak avalanche")

    def test_consistent_length(self):
        for data in ['', 'a', 'long string ' * 100]:
            h = _hash(data)
            self.assertEqual(len(h), 64)  # SHA256 hex length


class TestWallet(unittest.TestCase):

    def test_create(self):
        w = Wallet('alice')
        self.assertEqual(w.name, 'alice')
        self.assertEqual(w.nonce, 0)
        self.assertEqual(len(w.address), 40)

    def test_unique_addresses(self):
        w1 = Wallet('alice', seed='seed1')
        w2 = Wallet('alice', seed='seed2')
        self.assertNotEqual(w1.address, w2.address)

    def test_sign_deterministic(self):
        w = Wallet('alice', seed='fixed')
        s1 = w.sign('data')
        s2 = w.sign('data')
        self.assertEqual(s1, s2)

    def test_sign_different_data(self):
        w = Wallet('alice', seed='fixed')
        s1 = w.sign('data1')
        s2 = w.sign('data2')
        self.assertNotEqual(s1, s2)


class TestTransaction(unittest.TestCase):

    def test_has_landauer_cost(self):
        tx = Transaction('sender', 'receiver', 100, 0)
        self.assertGreater(tx.cost_joules, 0)
        self.assertGreater(tx.bits_erased, 0)
        self.assertEqual(tx.cost_joules, tx.bits_erased * LANDAUER_PER_BIT)

    def test_cost_scales_with_amount(self):
        tx_small = Transaction('s', 'r', 1, 0)
        tx_large = Transaction('s', 'r', 1000000, 0)
        self.assertGreater(tx_large.cost_joules, tx_small.cost_joules)

    def test_hash_unique(self):
        tx1 = Transaction('s', 'r', 100, 0, timestamp=1000)
        tx2 = Transaction('s', 'r', 100, 1, timestamp=1000)
        self.assertNotEqual(tx1.hash, tx2.hash)

    def test_json_serializable(self):
        tx = Transaction('sender', 'receiver', 50, 0)
        json.dumps(tx.to_dict())


class TestLedger(unittest.TestCase):

    def _setup_ledger(self):
        l = Ledger()
        alice = Wallet('alice', seed='alice_seed')
        bob = Wallet('bob', seed='bob_seed')
        l.register(alice)
        l.register(bob)
        l.mint(alice, 1000)
        return l, alice, bob

    def test_mint(self):
        l, alice, _ = self._setup_ledger()
        self.assertAlmostEqual(l._balance_from_chain(alice.address), 1000)
        self.assertEqual(l.total_supply, 1000)

    def test_transfer(self):
        l, alice, bob = self._setup_ledger()
        tx = l.transfer(alice, bob, 250)
        self.assertNotIn('error', tx)
        self.assertTrue(tx['verified'])
        self.assertAlmostEqual(l._balance_from_chain(alice.address), 750)
        self.assertAlmostEqual(l._balance_from_chain(bob.address), 250)

    def test_transfer_has_energy_cost(self):
        l, alice, bob = self._setup_ledger()
        tx = l.transfer(alice, bob, 100)
        self.assertGreater(tx['cost_joules'], 0)
        self.assertGreater(tx['bits_erased'], 0)

    def test_insufficient_balance(self):
        l, alice, bob = self._setup_ledger()
        tx = l.transfer(alice, bob, 5000)
        self.assertIn('error', tx)

    def test_self_transfer_blocked(self):
        l, alice, _ = self._setup_ledger()
        tx = l.transfer(alice, alice, 100)
        self.assertIn('error', tx)

    def test_negative_amount_blocked(self):
        l, alice, bob = self._setup_ledger()
        tx = l.transfer(alice, bob, -50)
        self.assertIn('error', tx)

    def test_balance_conservation(self):
        """Total supply must be conserved after transfers."""
        l, alice, bob = self._setup_ledger()
        l.transfer(alice, bob, 300)
        l.transfer(bob, alice, 100)
        total = l._balance_from_chain(alice.address) + l._balance_from_chain(bob.address)
        self.assertAlmostEqual(total, 1000,
            msg=f"Balance not conserved: total={total}")

    def test_nonce_prevents_replay(self):
        """Each transaction increments nonce. Replay = wrong nonce."""
        l, alice, bob = self._setup_ledger()
        l.transfer(alice, bob, 100)
        initial_nonce = alice.nonce
        l.transfer(alice, bob, 100)
        self.assertEqual(alice.nonce, initial_nonce + 1)

    def test_forge_block(self):
        l, alice, bob = self._setup_ledger()
        l.transfer(alice, bob, 100)
        block = l.forge_block()
        self.assertNotIn('error', block)
        self.assertGreater(block['n_transactions'], 0)
        self.assertEqual(len(l.chain), 1)

    def test_chain_integrity(self):
        """Each block references the previous block's hash."""
        l, alice, bob = self._setup_ledger()
        l.transfer(alice, bob, 50)
        l.forge_block()
        l.transfer(alice, bob, 50)
        l.forge_block()
        self.assertEqual(l.chain[1].prev_hash, l.chain[0].hash)

    def test_energy_tracking(self):
        """Ledger tracks total energy spent."""
        l, alice, bob = self._setup_ledger()
        l.transfer(alice, bob, 100)
        self.assertGreater(l.total_energy, 0)


class TestAudit(unittest.TestCase):

    def test_clean_audit(self):
        l = Ledger()
        a = Wallet('alice', seed='a')
        b = Wallet('bob', seed='b')
        l.register(a)
        l.register(b)
        l.mint(a, 1000)
        l.transfer(a, b, 500)
        l.forge_block()
        audit = l.audit()
        self.assertEqual(audit['status'], 'clean')
        self.assertTrue(audit['chain_valid'])
        self.assertTrue(audit['balances_valid'])

    def test_audit_detects_chain_tamper(self):
        l = Ledger()
        a = Wallet('alice', seed='a')
        b = Wallet('bob', seed='b')
        l.register(a)
        l.register(b)
        l.mint(a, 1000)
        l.transfer(a, b, 500)
        l.forge_block()
        # Tamper with a transaction amount in the chain
        l.chain[0].transactions[0].amount = 9999
        # Supply mismatch: minted 1000 but chain now says 9999
        audit = l.audit()
        self.assertFalse(audit['balances_valid'],
            "HACKED: Tampered transaction amount not detected")

    def test_audit_tension_detection(self):
        """Multiple wallets with transaction patterns — audit should find tensions."""
        l = Ledger()
        wallets = [Wallet(f'w{i}', seed=f'seed{i}') for i in range(5)]
        for w in wallets:
            l.register(w)
        l.mint(wallets[0], 10000)
        # Create a pattern: 0→1, 1→2, 2→3 (chain)
        for i in range(3):
            l.transfer(wallets[i], wallets[i+1], 1000)
        l.forge_block()
        audit = l.audit()
        # Wallet 0 and 3 are spectrally close (through the chain) but have no direct transaction
        self.assertEqual(audit['status'], 'clean')

    def test_multiple_blocks(self):
        l = Ledger()
        a = Wallet('alice', seed='a')
        b = Wallet('bob', seed='b')
        c = Wallet('carol', seed='c')
        for w in [a, b, c]:
            l.register(w)
        l.mint(a, 10000)
        l.transfer(a, b, 3000)
        l.forge_block()
        l.transfer(b, c, 1000)
        l.transfer(a, c, 500)
        l.forge_block()
        audit = l.audit()
        self.assertEqual(audit['total_blocks'], 2)
        self.assertTrue(audit['chain_valid'])


class TestScaleAndSpeed(unittest.TestCase):

    def test_100_transactions(self):
        """100 transactions should complete in under 1 second."""
        import time
        l = Ledger()
        a = Wallet('alice', seed='a')
        b = Wallet('bob', seed='b')
        l.register(a)
        l.register(b)
        l.mint(a, 100000)

        start = time.time()
        for i in range(100):
            l.transfer(a, b, 1)
        l.forge_block()
        elapsed = time.time() - start
        self.assertLess(elapsed, 5.0,
            f"100 transactions took {elapsed:.2f}s — too slow for payments")

    def test_status_json_serializable(self):
        l = Ledger()
        a = Wallet('alice', seed='a')
        l.register(a)
        l.mint(a, 1000)
        json.dumps(l.status())
        json.dumps(l.audit(), default=str)


class TestVsBitcoin(unittest.TestCase):
    """Prove we're better than Bitcoin on the things that matter."""

    def test_no_mining_waste(self):
        """Bitcoin: ~1.5 GWh per block. GUMP: Landauer minimum only."""
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a)
        l.register(b)
        l.mint(a, 1000)
        l.transfer(a, b, 500)
        block = l.forge_block()
        # Block energy should be TINY — just Landauer cost
        self.assertLess(block['total_energy_J'], 1e-15,
            f"Block energy {block['total_energy_J']} — should be femtojoules, not gigawatt-hours")

    def test_instant_finality(self):
        """Bitcoin: ~10 minutes per block. GUMP: instant."""
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a)
        l.register(b)
        l.mint(a, 1000)
        start = time.time()
        l.transfer(a, b, 500)
        l.forge_block()
        elapsed = time.time() - start
        self.assertLess(elapsed, 0.1,
            f"Block took {elapsed:.3f}s — Bitcoin takes 600s")

    def test_energy_cost_is_real(self):
        """Every transaction has a provable, physical energy cost."""
        tx = Transaction('sender', 'receiver', 1000, 0)
        # Landauer cost: bits × kT ln(2)
        expected_minimum = 64 * LANDAUER_PER_BIT  # at least 64 bits
        self.assertGreaterEqual(tx.cost_joules, expected_minimum,
            "Transaction energy below Landauer minimum — physics violation")

    def test_conservation(self):
        """Money is conserved. Can't create from nothing (except mint)."""
        l = Ledger()
        a = Wallet('a', seed='a')
        b = Wallet('b', seed='b')
        l.register(a)
        l.register(b)
        l.mint(a, 1000)
        for _ in range(10):
            l.transfer(a, b, 50)
            l.transfer(b, a, 30)
        total = l._balance_from_chain(a.address) + l._balance_from_chain(b.address)
        self.assertAlmostEqual(total, 1000.0,
            msg=f"Conservation violated: {total} != 1000")


if __name__ == '__main__':
    unittest.main()
