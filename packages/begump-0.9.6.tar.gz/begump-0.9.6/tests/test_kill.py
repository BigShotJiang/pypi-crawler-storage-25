"""Tests for gump.kill — the 12P automator."""
import pytest
from gump.kill import kill, kill_sweep


class TestKill:
    """Core kill() function tests."""

    def test_exact_match(self):
        r = kill("pi", "pi")
        assert r['match'] is True
        assert r['verdict'] == 'PASS'
        assert r['ppm'] == 0.0

    def test_sqrt_2_over_pi(self):
        r = kill("sqrt(2/pi)", 0.79788456)
        assert r['match'] is True
        assert r['ppm'] < 1.0

    def test_killed(self):
        r = kill("pi", 3.0)
        assert r['match'] is False
        assert 'KILLED' in r['verdict']

    def test_close_but_not_pass(self):
        r = kill("pi", 3.14159, tolerance_ppm=0.01)
        # pi = 3.14159265..., so 3.14159 is off by ~0.08 ppm
        # This should be CLOSE or PASS depending on tolerance
        assert r['ppm'] < 1.0

    def test_string_target(self):
        r = kill("pi/4", "atan(1)")
        assert r['match'] is True
        assert r['ppm'] < 0.001

    def test_float_candidate(self):
        r = kill(3.14159265, "pi", tolerance_ppm=0.1)
        assert r['ppm'] < 0.1

    def test_zero_target(self):
        r = kill(0.0, 0.0)
        assert r['match'] is True
        assert r['ppm'] == 0.0

    def test_zero_target_nonzero_candidate(self):
        r = kill(1.0, 0.0)
        assert r['match'] is False

    def test_sigma_calculation(self):
        r = kill("pi", 3.14159, uncertainty=0.00001)
        assert r['sigma'] is not None
        assert r['sigma'] > 0

    def test_name_label(self):
        r = kill("pi", 3.14159265, name="pi test")
        assert r['name'] == "pi test"

    def test_report_contains_info(self):
        r = kill("sqrt(2)", 1.41421356)
        assert 'KILL TEST' in r['report']
        assert 'ppm' in r['report']

    def test_caret_as_power(self):
        r = kill("2^10", 1024)
        assert r['match'] is True

    def test_phi(self):
        r = kill("phi", 1.6180339887)
        assert r['match'] is True

    def test_euler_constant(self):
        r = kill("euler", 0.5772156649)
        assert r['match'] is True

    def test_invalid_expression(self):
        with pytest.raises(ValueError):
            kill("import os", 0)

    def test_arctan_sqrt_19_18(self):
        """Session 38: arctan(sqrt(19/18)) revival claim must be testable."""
        r = kill("atan(sqrt(19/18))", "atan(sqrt(19/18))")
        assert r['match'] is True
        assert r['ppm'] == 0.0
        # Value should be around 0.7989 radians
        val = float(r['candidate_value'])
        assert 0.79 < val < 0.81

    def test_nested_trig(self):
        """Compound expressions with trig + sqrt + fractions."""
        r = kill("sin(pi/6)", 0.5)
        assert r['match'] is True
        assert r['ppm'] < 0.01


class TestKillSweep:
    """Sweep tests."""

    def test_basic_sweep(self):
        results = kill_sweep({
            "pi": "pi",
            "e": "e",
            "phi": "phi",
        }, 3.14159265)
        # pi should be closest
        assert results[0]['name'] == 'pi'
        assert results[0]['match'] is True

    def test_sorted_by_ppm(self):
        results = kill_sweep({
            "pi": "pi",
            "e": "e",
        }, 3.0)
        # Sorted by closeness to 3.0
        assert results[0]['ppm'] <= results[1]['ppm']

    def test_error_handling(self):
        results = kill_sweep({
            "good": "pi",
            "bad": "undefined_function()",
        }, 3.14)
        # Should have 2 results, bad one with ERROR
        assert len(results) == 2
        bad = [r for r in results if r['name'] == 'bad']
        assert len(bad) == 1
        assert 'ERROR' in bad[0]['verdict']

    def test_empty_sweep(self):
        results = kill_sweep({}, 1.0)
        assert len(results) == 0
