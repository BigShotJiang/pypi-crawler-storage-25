"""Tests for gump.accord — Regulatory gap analysis."""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.accord import scan_regulations


class TestScanRegulations(unittest.TestCase):
    def test_empty_rules(self):
        r = scan_regulations([])
        self.assertIn('error', r)

    def test_all_gaps(self):
        rules = [
            {'id': 'r1', 'requirement': 'must have encryption', 'category': 'security'},
            {'id': 'r2', 'requirement': 'should log access', 'category': 'audit'},
        ]
        r = scan_regulations(rules)
        self.assertEqual(r['n_gaps'], 2)
        self.assertEqual(r['K_compliance'], 0.0)

    def test_partial_coverage(self):
        rules = [
            {'id': 'r1', 'requirement': 'must have encryption', 'category': 'security'},
            {'id': 'r2', 'requirement': 'should log access', 'category': 'audit'},
        ]
        state = [{'category': 'security', 'status': 'compliant'}]
        r = scan_regulations(rules, state)
        self.assertEqual(r['covered'], 1)
        self.assertEqual(r['n_gaps'], 1)
        self.assertAlmostEqual(r['K_compliance'], 0.5)

    def test_full_coverage(self):
        rules = [{'id': 'r1', 'requirement': 'X', 'category': 'a'}]
        state = [{'category': 'a', 'status': 'compliant'}]
        r = scan_regulations(rules, state)
        self.assertEqual(r['K_compliance'], 1.0)

    def test_priority_detection(self):
        rules = [
            {'id': 'r1', 'requirement': 'must have X', 'category': 'a'},
            {'id': 'r2', 'requirement': 'should have Y', 'category': 'b'},
        ]
        r = scan_regulations(rules)
        priorities = [g['priority'] for g in r['gaps']]
        self.assertIn('HIGH', priorities)
        self.assertIn('MEDIUM', priorities)


if __name__ == '__main__':
    unittest.main()
