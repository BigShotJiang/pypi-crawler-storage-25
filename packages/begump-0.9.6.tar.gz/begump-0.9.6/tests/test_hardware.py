"""
MM Test: gump.hardware — every compute unit, every failure mode.
Every function must handle None, wrong types, edge cases, and degrade gracefully.
"""
import pytest
import numpy as np


class TestGPUMatmul:
    """Metal Performance Shaders matrix multiply."""

    def test_basic_correctness(self):
        from gump.hardware import gpu_matmul
        A = np.random.randn(64, 64).astype(np.float32)
        B = np.random.randn(64, 64).astype(np.float32)
        C = gpu_matmul(A, B)
        assert C.shape == (64, 64)
        assert np.allclose(C, A @ B, atol=1e-3)

    def test_rectangular(self):
        from gump.hardware import gpu_matmul
        A = np.random.randn(32, 128).astype(np.float32)
        B = np.random.randn(128, 16).astype(np.float32)
        C = gpu_matmul(A, B)
        assert C.shape == (32, 16)
        assert np.allclose(C, A @ B, atol=1e-3)

    def test_large(self):
        from gump.hardware import gpu_matmul
        A = np.random.randn(512, 512).astype(np.float32)
        B = np.random.randn(512, 512).astype(np.float32)
        C = gpu_matmul(A, B)
        assert C.shape == (512, 512)
        assert np.allclose(C, A @ B, atol=1e-2)

    def test_identity(self):
        from gump.hardware import gpu_matmul
        A = np.random.randn(100, 100).astype(np.float32)
        I = np.eye(100, dtype=np.float32)
        C = gpu_matmul(A, I)
        assert np.allclose(C, A, atol=1e-3)

    def test_zeros(self):
        from gump.hardware import gpu_matmul
        A = np.zeros((10, 10), dtype=np.float32)
        B = np.random.randn(10, 10).astype(np.float32)
        C = gpu_matmul(A, B)
        assert np.allclose(C, 0, atol=1e-6)

    def test_none_inputs(self):
        from gump.hardware import gpu_matmul
        assert gpu_matmul(None, None) is None
        assert gpu_matmul(None, np.eye(3)) is None
        assert gpu_matmul(np.eye(3), None) is None

    def test_shape_mismatch(self):
        from gump.hardware import gpu_matmul
        with pytest.raises(ValueError):
            gpu_matmul(np.zeros((3, 4)), np.zeros((5, 6)))

    def test_float64_input(self):
        """Should auto-convert to float32."""
        from gump.hardware import gpu_matmul
        A = np.random.randn(32, 32)  # float64
        B = np.random.randn(32, 32)
        C = gpu_matmul(A, B)
        assert C.shape == (32, 32)

    def test_1d_passthrough(self):
        """1D arrays should still work via numpy."""
        from gump.hardware import gpu_matmul
        a = np.array([1.0, 2.0, 3.0])
        b = np.array([4.0, 5.0, 6.0])
        r = gpu_matmul(a, b)
        assert float(r) == pytest.approx(32.0)

    def test_single_element(self):
        from gump.hardware import gpu_matmul
        A = np.array([[5.0]], dtype=np.float32)
        B = np.array([[3.0]], dtype=np.float32)
        C = gpu_matmul(A, B)
        assert float(C[0, 0]) == pytest.approx(15.0, abs=0.01)


class TestSmartDispatch:
    """matmul() auto-dispatches to GPU or CPU based on size."""

    def test_small_uses_cpu(self):
        from gump.hardware import matmul
        A = np.random.randn(10, 10).astype(np.float32)
        B = np.random.randn(10, 10).astype(np.float32)
        C = matmul(A, B)
        assert np.allclose(C, A @ B, atol=1e-3)

    def test_large_dispatches(self):
        from gump.hardware import matmul
        A = np.random.randn(512, 512).astype(np.float32)
        B = np.random.randn(512, 512).astype(np.float32)
        C = matmul(A, B)
        assert C.shape == (512, 512)
        assert np.allclose(C, A @ B, atol=1e-2)

    def test_none(self):
        from gump.hardware import matmul
        assert matmul(None, None) is None


class TestANE:
    """Neural Engine via CoreML MIL builder."""

    def test_basic(self):
        from gump.hardware import ane_inference
        W1 = np.random.randn(64, 128).astype(np.float16) * 0.01
        W2 = np.random.randn(128, 64).astype(np.float16) * 0.01
        x = np.random.randn(1, 64).astype(np.float32)
        r = ane_inference(x, (W1, W2))
        assert r is not None
        # Check shape — CoreML may return dict or array
        if isinstance(r, dict):
            v = list(r.values())[0]
        else:
            v = r
        assert np.asarray(v).shape[-1] == 64

    def test_activations(self):
        from gump.hardware import ane_inference
        W1 = np.random.randn(32, 64).astype(np.float16) * 0.01
        W2 = np.random.randn(64, 32).astype(np.float16) * 0.01
        x = np.random.randn(1, 32).astype(np.float32)
        for act in ['relu', 'tanh', 'sigmoid']:
            r = ane_inference(x, (W1, W2), activation=act)
            assert r is not None

    def test_1d_input(self):
        """1D input should auto-reshape."""
        from gump.hardware import ane_inference
        W1 = np.random.randn(16, 32).astype(np.float16) * 0.01
        W2 = np.random.randn(32, 16).astype(np.float16) * 0.01
        x = np.random.randn(16).astype(np.float32)
        r = ane_inference(x, (W1, W2))
        assert r is not None

    def test_none_inputs(self):
        from gump.hardware import ane_inference
        assert ane_inference(None, (np.eye(4), np.eye(4))) is None
        assert ane_inference(np.eye(4), None) is None
        assert ane_inference(np.eye(4), (None, np.eye(4))) is None

    def test_cached_model_reuse(self):
        """Second call with same dimensions should reuse compiled model."""
        from gump.hardware import ane_inference, _ane_models
        W1 = np.random.randn(32, 64).astype(np.float16) * 0.01
        W2 = np.random.randn(64, 32).astype(np.float16) * 0.01
        x = np.random.randn(1, 32).astype(np.float32)
        _ = ane_inference(x, (W1, W2))
        key = (32, 64, 'relu')
        assert key in _ane_models
        # Second call
        r2 = ane_inference(x, (W1, W2))
        assert r2 is not None


class TestSecureEnclave:
    """Hardware ECC P-256 signing."""

    def test_sign_and_verify(self):
        from gump.hardware import secure_sign, secure_verify
        sig = secure_sign("test data 12345")
        if sig is None:
            pytest.skip("Secure Enclave signer not available")
        assert isinstance(sig, str)
        assert len(sig) > 20
        assert secure_verify("test data 12345", sig) is True

    def test_tamper_detection(self):
        from gump.hardware import secure_sign, secure_verify
        sig = secure_sign("original data")
        if sig is None:
            pytest.skip("Secure Enclave signer not available")
        assert secure_verify("tampered data", sig) is False

    def test_pubkey(self):
        from gump.hardware import secure_pubkey
        key = secure_pubkey()
        if key is None:
            pytest.skip("Secure Enclave signer not available")
        assert isinstance(key, str)
        assert len(key) > 10

    def test_none_input(self):
        from gump.hardware import secure_sign, secure_verify
        assert secure_sign(None) is None
        assert secure_verify(None, "sig") is None
        assert secure_verify("data", None) is None

    def test_empty_string(self):
        from gump.hardware import secure_sign, secure_verify
        sig = secure_sign("")
        if sig is None:
            pytest.skip("Secure Enclave signer not available")
        assert secure_verify("", sig) is True

    def test_unicode(self):
        from gump.hardware import secure_sign, secure_verify
        sig = secure_sign("日本語テスト 🎵")
        if sig is None:
            pytest.skip("Secure Enclave signer not available")
        assert secure_verify("日本語テスト 🎵", sig) is True

    def test_long_data(self):
        from gump.hardware import secure_sign, secure_verify
        data = "x" * 10000
        sig = secure_sign(data)
        if sig is None:
            pytest.skip("Secure Enclave signer not available")
        assert secure_verify(data, sig) is True

    def test_numeric_input(self):
        """Numbers should be converted to string."""
        from gump.hardware import secure_sign
        sig = secure_sign(42)
        if sig is None:
            pytest.skip("Secure Enclave signer not available")
        assert isinstance(sig, str)


class TestAvailability:
    """System reports what's active."""

    def test_available_returns_dict(self):
        from gump.hardware import available
        a = available()
        assert isinstance(a, dict)
        assert 'gpu' in a
        assert 'neural_engine' in a
        assert 'secure_enclave' in a
        assert a['cpu'] is True

    def test_spec_returns_all_sections(self):
        from gump.hardware import spec
        s = spec()
        assert 'gpu' in s
        assert 'neural_engine' in s
        assert 'secure_enclave' in s
        assert 'memory' in s
        assert 'efficiency' in s
        assert s['memory']['zero_copy'] is True
        assert s['efficiency']['tdp_watts'] == 35


class TestGracefulDegradation:
    """If Apple removes an API, nothing crashes."""

    def test_gpu_matmul_without_metal(self):
        """Simulating Metal unavailable by using numpy path."""
        import gump.hardware as hw
        saved = hw._mps_available
        hw._mps_available = False
        try:
            A = np.random.randn(32, 32).astype(np.float32)
            B = np.random.randn(32, 32).astype(np.float32)
            C = hw.gpu_matmul(A, B)
            assert np.allclose(C, A @ B, atol=1e-5)
        finally:
            hw._mps_available = saved

    def test_ane_without_coreml(self):
        """Simulating CoreML unavailable by using numpy path."""
        import gump.hardware as hw
        saved = hw._ane_available
        hw._ane_available = False
        try:
            W1 = np.random.randn(16, 32).astype(np.float32) * 0.01
            W2 = np.random.randn(32, 16).astype(np.float32) * 0.01
            x = np.random.randn(1, 16).astype(np.float32)
            r = hw.ane_inference(x, (W1, W2))
            assert r is not None
            assert r.shape == (1, 16)
        finally:
            hw._ane_available = saved

    def test_se_without_binary(self):
        """Simulating Secure Enclave binary missing."""
        import gump.hardware as hw
        saved = hw._se_available
        hw._se_available = False
        try:
            assert hw.secure_sign("data") is None
            assert hw.secure_verify("data", "sig") is None
            assert hw.secure_pubkey() is None
        finally:
            hw._se_available = saved

    def test_matmul_dispatch_without_gpu(self):
        """Smart dispatch falls to CPU when GPU unavailable."""
        import gump.hardware as hw
        saved = hw._mps_available
        hw._mps_available = False
        try:
            A = np.random.randn(1024, 1024).astype(np.float32)
            B = np.random.randn(1024, 1024).astype(np.float32)
            C = hw.matmul(A, B)
            assert np.allclose(C, A @ B, atol=1e-3)
        finally:
            hw._mps_available = saved
