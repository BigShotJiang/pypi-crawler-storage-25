"""
Tests for gump.foldwatch_app — Fold Watch product
Run: cd gump-package && python tests/test_foldwatch_app.py
"""
import sys, os, unittest, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.foldwatch_app import report, compare_report
from gump.foldwatch import analyze

# Insulin B chain
INSULIN_B = 'FVNQHLCGSHLVEALYLVCGERGFFYTPKT'
# Hemoglobin alpha (partial)
HBA = 'MVLSPADKTNVKAAWGKVGAHAGEYGAEALERMFLSFPTTKTYFPHFDLSH'
# Amyloid-beta 42 (aggregation-prone)
ABETA = 'DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA'


class TestAnalysis(unittest.TestCase):

    def test_insulin_analysis(self):
        r = analyze(INSULIN_B)
        self.assertNotIn('error', r)
        self.assertEqual(r['sequence_length'], 30)
        self.assertIn('misfolding_risk', r)
        self.assertIn(r['misfolding_risk'], ['low', 'medium', 'high'])

    def test_hemoglobin(self):
        r = analyze(HBA)
        self.assertNotIn('error', r)
        # Hemoglobin is mostly helical
        self.assertGreater(r['helix_pct'], 10)  # Single-sequence: ~20% on partial fragment

    def test_amyloid_beta(self):
        r = analyze(ABETA)
        self.assertNotIn('error', r)
        # Amyloid-beta should have aggregation regions
        self.assertGreater(len(r['aggregation_regions']), 0)

    def test_invalid_sequence(self):
        r = analyze('ABCXYZ123')
        self.assertIn('error', r)

    def test_short_sequence(self):
        r = analyze('ACG')
        self.assertIn('error', r)

    def test_disulfide_detection(self):
        # Insulin B has C7 and C19
        r = analyze(INSULIN_B)
        self.assertGreater(len(r['disulfide_candidates']), 0)

    def test_domains(self):
        r = analyze(HBA)
        self.assertGreater(r['n_domains'], 0)

    def test_charge(self):
        r = analyze(INSULIN_B)
        self.assertIn('net_charge', r)
        self.assertIsInstance(r['net_charge'], float)

    def test_json_serializable(self):
        r = analyze(INSULIN_B)
        json.dumps(r, default=str)  # should not raise


class TestReport(unittest.TestCase):

    def test_report_valid_html(self):
        html = report(INSULIN_B)
        self.assertIn('<html', html)
        self.assertIn('Fold Watch', html)
        self.assertIn('<canvas', html)

    def test_report_contains_sequence(self):
        html = report(INSULIN_B)
        # Should contain some amino acids
        self.assertIn('FVNQHLCGSHLVEALYLVCGERGFFYTPKT', html)

    def test_report_has_sections(self):
        html = report(INSULIN_B)
        self.assertIn('SEQUENCE VIEWER', html)
        self.assertIn('SPECTRAL FOLD MAP', html)
        self.assertIn('RISK FACTORS', html)
        self.assertIn('FOLD TENSIONS', html)
        self.assertIn('STRUCTURAL DOMAINS', html)

    def test_report_shows_risk(self):
        html = report(INSULIN_B)
        self.assertTrue('LOW' in html or 'MEDIUM' in html or 'HIGH' in html)

    def test_report_error_sequence(self):
        html = report('XXXXX')
        self.assertIn('Error', html)

    def test_report_amyloid(self):
        html = report(ABETA, title='Amyloid-Beta 42')
        self.assertIn('Amyloid-Beta 42', html)
        self.assertIn('AGGREGATION', html)

    def test_report_custom_title(self):
        html = report(INSULIN_B, title='Insulin B Chain')
        self.assertIn('Insulin B Chain', html)


class TestCompare(unittest.TestCase):

    def test_compare_basic(self):
        html = compare_report(INSULIN_B, HBA)
        self.assertIn('<html', html)
        self.assertIn('Comparison', html)

    def test_compare_wt_vs_mutant(self):
        # Change one residue
        mutant = INSULIN_B[:20] + 'A' + INSULIN_B[21:]
        html = compare_report(INSULIN_B, mutant, 'Wild Type', 'G21A Mutant')
        self.assertIn('Wild Type', html)
        self.assertIn('G21A Mutant', html)


if __name__ == '__main__':
    unittest.main()
