"""
Tests for gump.trace — Spectral forensics for financial data.
"""
import sys, os, json, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.trace import scan, scan_csv, visualize


class TestBasics(unittest.TestCase):

    def test_simple_scan(self):
        txs = [{'from':'A','to':'B','amount':100},{'from':'B','to':'C','amount':90}]
        r = scan(txs)
        self.assertNotIn('error', r)
        self.assertIn('risk_score', r)
        self.assertIn('flags', r)

    def test_empty(self):
        r = scan([])
        self.assertIn('error', r)

    def test_single_entity(self):
        r = scan([{'from':'A','to':'A','amount':100}])
        # Self-transfer filtered, only 1 entity
        self.assertIn('error', r)


class TestCircularDetection(unittest.TestCase):

    def test_bidirectional_flow(self):
        """A sends to B, B sends back — wash trading signal."""
        txs = [
            {'from':'A','to':'B','amount':1000},
            {'from':'B','to':'A','amount':950},
        ]
        r = scan(txs)
        self.assertGreater(len(r['circular_flows']), 0,
            "Missed bidirectional flow — potential wash trading")

    def test_triangular_flow(self):
        """A→B→C→A — classic layering."""
        txs = [
            {'from':'A','to':'B','amount':1000},
            {'from':'B','to':'C','amount':900},
            {'from':'C','to':'A','amount':800},
        ]
        r = scan(txs)
        circular = [c for c in r['circular_flows'] if 'path' in c]
        self.assertGreater(len(circular), 0,
            "Missed triangular flow — classic layering pattern")

    def test_no_false_circular(self):
        """Normal business: supplier→company→employee. Not circular."""
        txs = [
            {'from':'Supplier','to':'Company','amount':5000},
            {'from':'Company','to':'Employee1','amount':3000},
            {'from':'Company','to':'Employee2','amount':2000},
        ]
        r = scan(txs)
        circular = r['circular_flows']
        self.assertEqual(len(circular), 0,
            "False circular flag on normal business transactions")


class TestAnomalousAmounts(unittest.TestCase):

    def test_spike_detected(self):
        """99 normal transactions + 1 massive outlier."""
        txs = [{'from':'A','to':'B','amount':100} for _ in range(99)]
        txs.append({'from':'A','to':'B','amount':100000})
        r = scan(txs)
        self.assertGreater(len(r['anomalous_amounts']), 0,
            "Missed 1000× outlier in transaction amounts")

    def test_no_false_anomaly(self):
        """Consistent amounts should not flag."""
        txs = [{'from':'A','to':'B','amount':100+i} for i in range(50)]
        r = scan(txs)
        self.assertEqual(len(r['anomalous_amounts']), 0,
            "False anomaly on gradually increasing amounts")


class TestConcentration(unittest.TestCase):

    def test_hub_detected(self):
        """One entity handles all flow."""
        txs = [{'from':'Hub','to':f'E{i}','amount':1000} for i in range(10)]
        r = scan(txs)
        conc = [c for c in r['concentration'] if c['entity'] == 'Hub']
        self.assertGreater(len(conc), 0,
            "Missed concentration risk — Hub handles 100% of outflow")


class TestTensions(unittest.TestCase):

    def test_hidden_relationship(self):
        """A→B→C but no A→C. Tension should flag A↔C."""
        txs = [
            {'from':'A','to':'B','amount':1000},
            {'from':'B','to':'C','amount':900},
        ]
        r = scan(txs)
        tension_pairs = [(t['entity_a'], t['entity_b']) for t in r['tensions']]
        has_ac = ('A','C') in tension_pairs or ('C','A') in tension_pairs
        self.assertTrue(has_ac,
            "Missed hidden relationship between A and C")


class TestNetFlow(unittest.TestCase):

    def test_net_roles(self):
        """A sends to B and C. A=sender, B+C=receivers."""
        txs = [
            {'from':'A','to':'B','amount':500},
            {'from':'A','to':'C','amount':300},
        ]
        r = scan(txs)
        self.assertEqual(r['net_flow']['A']['role'], 'net_sender')
        self.assertEqual(r['net_flow']['B']['role'], 'net_receiver')


class TestRiskScore(unittest.TestCase):

    def test_clean_is_low(self):
        """Normal transactions = low risk."""
        txs = [
            {'from':'Payroll','to':f'Emp{i}','amount':5000}
            for i in range(20)
        ]
        r = scan(txs)
        self.assertLess(r['risk_score'], 30,
            f"Clean payroll scored {r['risk_score']} — should be low")

    def test_dirty_is_high(self):
        """Circular + anomalous + concentrated = high risk."""
        txs = []
        # Circular
        txs += [{'from':'A','to':'B','amount':10000},{'from':'B','to':'A','amount':9500}]
        # Triangular
        txs += [{'from':'X','to':'Y','amount':5000},{'from':'Y','to':'Z','amount':4800},
                {'from':'Z','to':'X','amount':4600}]
        # Anomalous
        txs += [{'from':'A','to':'C','amount':100} for _ in range(50)]
        txs += [{'from':'A','to':'C','amount':999999}]
        r = scan(txs)
        self.assertGreater(r['risk_score'], 50,
            f"Obviously suspicious pattern scored only {r['risk_score']}")


class TestCSV(unittest.TestCase):

    def test_csv_basic(self):
        csv = "from,to,amount\nAlice,Bob,500\nBob,Carol,300\n"
        r = scan_csv(csv)
        self.assertNotIn('error', r)
        self.assertEqual(r['stats']['entities'], 3)

    def test_csv_no_header(self):
        csv = "Alice,Bob,500\nBob,Carol,300\n"
        r = scan_csv(csv, has_header=False)
        self.assertNotIn('error', r)


class TestVisualize(unittest.TestCase):

    def test_html_valid(self):
        txs = [
            {'from':'A','to':'B','amount':500},
            {'from':'B','to':'C','amount':300},
            {'from':'C','to':'A','amount':200},
        ]
        r = scan(txs)
        html = visualize(r)
        self.assertIn('<html', html)
        self.assertIn('Trace', html)
        self.assertIn('<canvas', html)

    def test_html_error(self):
        html = visualize({'error': 'test'})
        self.assertIn('Error', html)


class TestScale(unittest.TestCase):

    def test_1000_transactions(self):
        """1000 transactions should complete in <2 seconds."""
        import time, random
        random.seed(42)
        entities = [f'E{i}' for i in range(50)]
        txs = [{'from':random.choice(entities),'to':random.choice(entities),
                'amount':random.uniform(10,10000)}
               for _ in range(1000)]
        txs = [t for t in txs if t['from'] != t['to']]
        start = time.time()
        r = scan(txs)
        elapsed = time.time() - start
        self.assertLess(elapsed, 2.0, f"1000 tx took {elapsed:.1f}s")
        self.assertNotIn('error', r)

    def test_json_serializable(self):
        txs = [{'from':'A','to':'B','amount':100}]
        r = scan(txs)
        json.dumps(r, default=str)


if __name__ == '__main__':
    unittest.main()
