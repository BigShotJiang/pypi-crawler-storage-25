"""Tests for gump.orgxray — Organizational structure analysis."""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.orgxray import analyze


class TestAnalyze(unittest.TestCase):
    def test_basic(self):
        r = analyze([('A', 'B'), ('B', 'C'), ('C', 'D')])
        self.assertIn('K', r)
        self.assertIn('R', r)
        self.assertEqual(r['n_nodes'], 4)

    def test_hub_detection(self):
        # B is connected to everything
        edges = [('A', 'B'), ('B', 'C'), ('B', 'D'), ('B', 'E')]
        r = analyze(edges)
        self.assertIn('B', r['hubs'])

    def test_empty(self):
        r = analyze([])
        self.assertIn('error', r)

    def test_single_edge(self):
        r = analyze([('A', 'B')])
        self.assertEqual(r['n_nodes'], 2)

    def test_K_range(self):
        r = analyze([('A', 'B'), ('B', 'C'), ('A', 'C')])
        self.assertGreaterEqual(r['K'], 0)
        self.assertLessEqual(r['K'], 1)


if __name__ == '__main__':
    unittest.main()
