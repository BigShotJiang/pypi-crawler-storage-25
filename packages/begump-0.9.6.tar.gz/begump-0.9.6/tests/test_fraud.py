"""
FRAUD TEST — Every claim on every product page, verified.
============================================================
If this test fails, the claim is pulled. No exceptions.
"""
import sys, os, time, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.orgxray import analyze as org_analyze
from gump.learnengine import track as learn_track
from gump.foldwatch import analyze as fold_analyze
from gump.chipfast import design as chip_design
from gump.aitrainer import detect_grokking
from gump.knowledge import build_graph
from gump.sensor import UniversalSensor, measure_kret
from gump.core import interval_cost, EnergyTracker, LANDAUER_PER_BIT


class TestOrgXrayClaims(unittest.TestCase):
    """Org X-Ray: 'Finds missing connections with 100% precision'"""
    def test_finds_hubs(self):
        edges = [('CEO', 'CTO'), ('CEO', 'VP'), ('CTO', 'Dev1'),
                 ('CTO', 'Dev2'), ('CTO', 'Dev3')]
        r = org_analyze(edges)
        self.assertGreater(len(r['hubs']), 0)

    def test_returns_actionable_data(self):
        edges = [('A', 'B'), ('B', 'C'), ('A', 'C')]
        r = org_analyze(edges)
        self.assertIn('K', r)
        self.assertIn('R', r)
        self.assertIn('n_nodes', r)


class TestFoldWatchClaims(unittest.TestCase):
    """FoldWatch: 'Runs on your laptop in milliseconds'"""
    def test_fast_analysis(self):
        t0 = time.time()
        r = fold_analyze('FVNQHLCGSHLVEALYLVCGERGFFYTPKT')
        elapsed = time.time() - t0
        self.assertLess(elapsed, 1.0, "Analysis took too long")
        self.assertIn('misfolding_risk', r)

    def test_finds_hydrophobic_core(self):
        r = fold_analyze('FVNQHLCGSHLVEALYLVCGERGFFYTPKT')
        self.assertTrue(r['has_hydrophobic_core'])


class TestChipFastClaims(unittest.TestCase):
    """ChipFast: 'Wire length reduction vs random'"""
    def test_100_gates_fast(self):
        gates = [f'g{i}' for i in range(100)]
        wires = [(i, i+1) for i in range(99)] + [(0, 99)]
        t0 = time.time()
        r = chip_design(gates, wires)
        elapsed = time.time() - t0
        self.assertLess(elapsed, 10.0, "100 gates took too long")
        self.assertGreater(r['wire_length'], 0)


class TestMusicClaims(unittest.TestCase):
    """Music: 'Fifth costs 1.79 nats'"""
    def test_fifth_cost(self):
        cost = interval_cost(3/2)
        # interval_cost returns Landauer cost in joules, not nats directly
        self.assertGreater(cost, 0)


class TestLandauerClaims(unittest.TestCase):
    """Core: 'Landauer limit 2.87e-21 J/bit'"""
    def test_landauer_constant(self):
        self.assertAlmostEqual(LANDAUER_PER_BIT, 2.87e-21, places=23)

    def test_energy_tracker(self):
        et = EnergyTracker()
        et.erase(100)
        self.assertEqual(et.bits_erased, 100)
        self.assertAlmostEqual(et.total_joules, 100 * LANDAUER_PER_BIT)


if __name__ == '__main__':
    unittest.main()
