"""
Tests for gump.k_runtime — K core runtime layer.
"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.k_runtime import (
    tensions, place, energy, grok_detect, measure, interval_cost, is_protected
)


class TestRouting(unittest.TestCase):

    def test_tensions_through_runtime(self):
        t = tensions(5, [(0,1),(1,2),(2,3),(3,4)], top_k=5)
        self.assertIsInstance(t, list)

    def test_energy_through_runtime(self):
        cost = energy(100)
        self.assertGreater(cost, 0)
        self.assertEqual(energy(100, 'reverse'), 0.0)

    def test_grok_through_runtime(self):
        train = [0.95] * 60 + [0.97] * 40
        test = [0.12] * 60 + [0.12 + i*0.02 for i in range(40)]
        grokked, epoch, jump = grok_detect(train, test)
        self.assertIsInstance(grokked, bool)

    def test_measure_through_runtime(self):
        m = measure([1, 2, 3, 4, 5, 6, 7, 8])
        self.assertIn('K', m)
        self.assertIn('R', m)
        self.assertIn('T', m)

    def test_is_protected_returns_bool(self):
        r = is_protected()
        self.assertIsInstance(r, bool)


class TestProductsUseKRuntime(unittest.TestCase):
    """Verify modules that should route through k_runtime actually do."""

    def test_foldwatch_app_uses_k_place(self):
        import gump.foldwatch_app
        import inspect
        src = inspect.getsource(gump.foldwatch_app)
        self.assertIn('k_runtime', src, "foldwatch_app not using k_runtime")

    def test_chipfast_app_uses_k_runtime(self):
        import gump.chipfast_app
        import inspect
        src = inspect.getsource(gump.chipfast_app)
        self.assertIn('k_runtime', src, "chipfast_app not using k_runtime")


if __name__ == '__main__':
    unittest.main()
