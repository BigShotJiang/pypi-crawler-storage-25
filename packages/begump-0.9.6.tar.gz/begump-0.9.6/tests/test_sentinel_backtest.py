"""
BACKTEST SENTINEL — Real attack patterns. Does it catch what matters?
=====================================================================
Each test simulates a documented attack pattern using system metrics.
If Sentinel can't catch these, it can't protect a $100B company.
"""
import sys, os, time, tempfile, shutil, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from gump.sentinel import Sentinel


class TestCryptoMiner(unittest.TestCase):
    """Cryptojacking: attacker installs a crypto miner.
    Pattern: CPU spikes to 95%+, stays there. Process count increases.
    Network connections increase (mining pool). Memory slowly climbs."""

    def test_cpu_spike_sustained(self):
        s = Sentinel()
        s.set_baseline({
            'cpu': {'mean': 15, 'std': 5, 'min': 5, 'max': 30, 'samples': 60},
            'processes': {'mean': 280, 'std': 15, 'min': 250, 'max': 320, 'samples': 60},
        })
        # Normal for 10 readings
        for _ in range(10):
            s.feed_metrics({'cpu': 15 + np.random.randn() * 3, 'processes': 280 + np.random.randn() * 10})
        # Miner starts — CPU pegs at 95%
        alerts = s.check({'cpu': 95, 'processes': 285})
        cpu_alerts = [a for a in alerts if a['metric'] == 'cpu']
        self.assertGreater(len(cpu_alerts), 0,
            "FAILED: Missed cryptominer CPU spike to 95%")

    def test_process_spawn(self):
        """Miner spawns worker processes."""
        s = Sentinel()
        s.set_baseline({
            'processes': {'mean': 280, 'std': 15, 'min': 250, 'max': 320, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({'processes': 280 + np.random.randn() * 10})
        # Miner spawns 200 worker threads
        alerts = s.check({'processes': 480})
        self.assertGreater(len(alerts), 0,
            "FAILED: Missed 200 extra processes from cryptominer")


class TestDataExfiltration(unittest.TestCase):
    """Data exfiltration: attacker copies data out.
    Pattern: network_out spikes massively while everything else is normal.
    Connections to unusual count. File access patterns change."""

    def test_network_exfil_spike(self):
        s = Sentinel()
        s.set_baseline({
            'network_out': {'mean': 500, 'std': 100, 'min': 200, 'max': 800, 'samples': 60},
            'connections': {'mean': 20, 'std': 5, 'min': 10, 'max': 35, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({'network_out': 500 + np.random.randn() * 80, 'connections': 20 + np.random.randn() * 3})
        # Exfil: 50x normal outbound traffic
        alerts = s.check({'network_out': 25000, 'connections': 22})
        net_alerts = [a for a in alerts if a['metric'] == 'network_out']
        self.assertGreater(len(net_alerts), 0,
            "FAILED: Missed 50x network exfiltration spike")

    def test_slow_exfil(self):
        """Sophisticated attacker: slow drip exfiltration over hours."""
        s = Sentinel()
        s.set_baseline({
            'network_out': {'mean': 500, 'std': 100, 'min': 200, 'max': 800, 'samples': 60},
        })
        # Slow climb from 500 to 2000 over 20 readings
        for i in range(20):
            s.feed_metrics({'network_out': 500 + i * 75})
        alerts = s.check({'network_out': 2000})
        self.assertGreater(len(alerts), 0,
            "FAILED: Missed slow exfiltration — gradual climb from 500 to 2000")


class TestRansomware(unittest.TestCase):
    """Ransomware: encrypts files rapidly.
    Pattern: disk I/O maxes out, CPU spikes, file count changes rapidly,
    open files explodes."""

    def test_disk_io_explosion(self):
        s = Sentinel()
        s.set_baseline({
            'disk_io': {'mean': 30, 'std': 10, 'min': 5, 'max': 60, 'samples': 60},
            'cpu': {'mean': 20, 'std': 8, 'min': 5, 'max': 45, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({'disk_io': 30 + np.random.randn() * 8, 'cpu': 20 + np.random.randn() * 5})
        # Ransomware: disk I/O maxes, CPU spikes (encryption)
        alerts = s.check({'disk_io': 500, 'cpu': 98})
        self.assertGreater(len(alerts), 0,
            "FAILED: Missed ransomware disk I/O explosion")

    def test_file_integrity_mass_change(self):
        """Ransomware modifies hundreds of files rapidly."""
        tmpdir = tempfile.mkdtemp()
        # Create 20 "important" files
        for i in range(20):
            with open(os.path.join(tmpdir, f'doc_{i}.txt'), 'w') as f:
                f.write(f'Important document {i} with real content')

        s = Sentinel()
        s.watch_files([tmpdir])

        # Ransomware encrypts all files
        for i in range(20):
            path = os.path.join(tmpdir, f'doc_{i}.txt')
            with open(path, 'w') as f:
                f.write('ENCRYPTED_BY_RANSOMWARE_' + os.urandom(16).hex())

        changes = s.check_integrity()
        shutil.rmtree(tmpdir)
        modified = [c for c in changes if c['type'] == 'modified']
        self.assertEqual(len(modified), 20,
            f"Only detected {len(modified)}/20 file modifications — ransomware partially undetected")


class TestPortScan(unittest.TestCase):
    """Port scan / reconnaissance: attacker probes the system.
    Pattern: connection count spikes dramatically, then drops."""

    def test_connection_surge(self):
        s = Sentinel()
        s.set_baseline({
            'connections': {'mean': 20, 'std': 5, 'min': 10, 'max': 35, 'samples': 60},
            'listeners': {'mean': 8, 'std': 1, 'min': 6, 'max': 10, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({'connections': 20 + np.random.randn() * 3, 'listeners': 8})
        # Port scan: 1000 connections in seconds
        alerts = s.check({'connections': 1000, 'listeners': 8})
        conn_alerts = [a for a in alerts if a['metric'] == 'connections']
        self.assertGreater(len(conn_alerts), 0,
            "FAILED: Missed port scan — 1000 connections from baseline of 20")


class TestPrivilegeEscalation(unittest.TestCase):
    """Privilege escalation: attacker gains root.
    Pattern: new listening ports appear, process count changes,
    files in /etc modified."""

    def test_new_listeners(self):
        s = Sentinel()
        s.set_baseline({
            'listeners': {'mean': 8, 'std': 1, 'min': 6, 'max': 10, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({'listeners': 8 + np.random.randn() * 0.5})
        # Attacker opens backdoor port
        alerts = s.check({'listeners': 15})
        self.assertGreater(len(alerts), 0,
            "FAILED: Missed 7 new listening ports — backdoor installed")

    def test_etc_modification(self):
        """Attacker modifies /etc/passwd equivalent."""
        tmpdir = tempfile.mkdtemp()
        passwd = os.path.join(tmpdir, 'passwd')
        shadow = os.path.join(tmpdir, 'shadow')
        with open(passwd, 'w') as f:
            f.write('root:x:0:0:root:/root:/bin/bash\nuser:x:1000:1000::/home/user:/bin/bash')
        with open(shadow, 'w') as f:
            f.write('root:$6$hash:19000:0:99999:7:::\nuser:$6$hash:19000:0:99999:7:::')

        s = Sentinel()
        s.watch_files([tmpdir])

        # Attacker adds a new root user
        with open(passwd, 'a') as f:
            f.write('\nhacker:x:0:0::/root:/bin/bash')

        changes = s.check_integrity()
        shutil.rmtree(tmpdir)
        self.assertGreater(len(changes), 0,
            "FAILED: Missed /etc/passwd modification — privilege escalation undetected")


class TestDDoS(unittest.TestCase):
    """DDoS: system overwhelmed with requests.
    Pattern: connections explode, CPU spikes, memory climbs, response time degrades."""

    def test_multi_metric_attack(self):
        s = Sentinel()
        s.set_baseline({
            'cpu': {'mean': 20, 'std': 5, 'min': 8, 'max': 35, 'samples': 60},
            'memory': {'mean': 55, 'std': 3, 'min': 50, 'max': 62, 'samples': 60},
            'connections': {'mean': 25, 'std': 5, 'min': 15, 'max': 40, 'samples': 60},
        })
        for _ in range(10):
            s.feed_metrics({
                'cpu': 20 + np.random.randn() * 3,
                'memory': 55 + np.random.randn() * 2,
                'connections': 25 + np.random.randn() * 3,
            })
        # DDoS: everything spikes simultaneously
        alerts = s.check({'cpu': 99, 'memory': 95, 'connections': 5000})
        self.assertGreaterEqual(len(alerts), 2,
            f"Only {len(alerts)} alerts during DDoS — should flag multiple metrics")


class TestActiveDefense(unittest.TestCase):
    """Test the active defense capabilities."""

    def test_intruder_profiling(self):
        s = Sentinel()
        attack = [
            {'source': 'attacker', 'target': '/etc/passwd', 'intensity': 1},
            {'source': 'attacker', 'target': '/var/log', 'intensity': 2},
            {'source': 'attacker', 'target': '/root/.ssh', 'intensity': 5},
            {'source': '/root/.ssh', 'target': '/tmp/keys', 'intensity': 8},
        ]
        profile = s.profile_intruder(attack)
        self.assertIn('fingerprint', profile, "Profiling failed to produce fingerprint")
        self.assertIn('predicted_targets', profile, "Profiling failed to predict targets")

    def test_fingerprint_consistency(self):
        """Same attack pattern = same fingerprint regardless of session."""
        s = Sentinel()
        pattern = ['/etc/passwd', '/var/log', '/root/.ssh', '/tmp/exfil']
        fp1 = s.spectral_fingerprint(pattern)
        fp2 = s.spectral_fingerprint(pattern)
        self.assertEqual(fp1['fingerprint'], fp2['fingerprint'],
            "Same attack pattern produced different fingerprints")

    def test_fingerprint_uniqueness(self):
        """Different attack pattern = different fingerprint."""
        s = Sentinel()
        fp1 = s.spectral_fingerprint(['/etc/passwd', '/root/.ssh'])
        fp2 = s.spectral_fingerprint(['/var/www', '/tmp/uploads'])
        self.assertNotEqual(fp1['fingerprint'], fp2['fingerprint'],
            "Different attack patterns produced same fingerprint")

    def test_honeypot_deployment(self):
        s = Sentinel()
        targets = [
            {'target': '/database/credentials', 'tension': 5.0},
            {'target': '/config/api_keys', 'tension': 3.0},
        ]
        deployed = s.deploy_honeypots(targets, '/tmp/gump_test_honeypots')
        self.assertGreater(len(deployed), 0, "No honeypots deployed")
        # Verify files exist
        for h in deployed:
            self.assertTrue(os.path.exists(h['path']), f"Honeypot not created: {h['path']}")
        shutil.rmtree('/tmp/gump_test_honeypots', ignore_errors=True)

    def test_honeypot_triggers_on_access(self):
        s = Sentinel()
        deployed = s.deploy_honeypots(
            [{'target': 'secret_db', 'tension': 5.0}],
            '/tmp/gump_test_hp2'
        )
        # Simulate intruder reading the honeypot
        if deployed:
            with open(deployed[0]['path'], 'a') as f:
                f.write('\n# accessed by intruder')
            triggered = s.check_honeypots()
            self.assertGreater(len(triggered), 0,
                "Honeypot accessed but no alert triggered")
            self.assertEqual(triggered[0]['severity'], 'CRITICAL')
        shutil.rmtree('/tmp/gump_test_hp2', ignore_errors=True)


class TestCleanSystem(unittest.TestCase):
    """Control: normal system behavior should NOT trigger alerts."""

    def test_normal_day(self):
        """Simulate 8 hours of normal operation. Zero alerts."""
        s = Sentinel()
        s.set_baseline({
            'cpu': {'mean': 20, 'std': 8, 'min': 5, 'max': 45, 'samples': 60},
            'memory': {'mean': 60, 'std': 3, 'min': 54, 'max': 68, 'samples': 60},
            'connections': {'mean': 20, 'std': 5, 'min': 10, 'max': 35, 'samples': 60},
            'processes': {'mean': 280, 'std': 15, 'min': 250, 'max': 320, 'samples': 60},
        })
        # 100 normal readings
        total_alerts = 0
        for _ in range(100):
            s.feed_metrics({
                'cpu': 20 + np.random.randn() * 6,
                'memory': 60 + np.random.randn() * 2,
                'connections': 20 + np.random.randn() * 4,
                'processes': 280 + np.random.randn() * 12,
            })
            alerts = s.check({
                'cpu': 20 + np.random.randn() * 6,
                'memory': 60 + np.random.randn() * 2,
                'connections': 20 + np.random.randn() * 4,
                'processes': 280 + np.random.randn() * 12,
            })
            total_alerts += len([a for a in alerts if a.get('severity') in ('HIGH', 'CRITICAL')])

        self.assertLess(total_alerts, 6,
            f"Normal operation triggered {total_alerts} high/critical alerts — too many false positives")


if __name__ == '__main__':
    unittest.main(verbosity=2)
