"""Tests for gump.oracle — Spectral prediction engine."""
import sys, os, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gump.oracle import extract, predict


class TestExtract(unittest.TestCase):
    def test_basic_extraction(self):
        r = extract([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        self.assertIsInstance(r, list)
        self.assertGreater(len(r), 0)

    def test_mode_fields(self):
        r = extract([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        for mode in r:
            self.assertIn('frequency', mode)
            self.assertIn('amplitude', mode)
            self.assertIn('phase', mode)

    def test_sine_wave(self):
        t = np.linspace(0, 2*np.pi, 100)
        signal = np.sin(t * 5)
        r = extract(signal.tolist(), n_modes=3)
        self.assertGreater(len(r), 0)
        self.assertGreater(r[0]['amplitude'], 0)

    def test_too_short(self):
        r = extract([1, 2])
        self.assertEqual(r, [])

    def test_n_modes(self):
        r = extract(list(range(50)), n_modes=3)
        self.assertLessEqual(len(r), 3)


class TestPredict(unittest.TestCase):
    def test_basic_prediction(self):
        r = predict([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], steps=5)
        self.assertIn('values', r)
        self.assertEqual(len(r['values']), 5)

    def test_confidence_decays(self):
        r = predict(list(range(20)), steps=10)
        self.assertGreater(r['confidence'][0], r['confidence'][-1])

    def test_modes_used(self):
        r = predict(list(range(20)), steps=5)
        self.assertIn('modes_used', r)
        self.assertGreater(r['modes_used'], 0)

    def test_constant_signal(self):
        r = predict([5]*20, steps=5)
        # Constant signal should predict near constant
        self.assertEqual(r['modes_used'], 0)


if __name__ == '__main__':
    unittest.main()
