# GUMP

**Four quantities. One framework. Everything computable.**

```
K = coupling strength     (how strongly things connect)
R = order parameter       (how synchronized they are)
E = energy cost           (what it costs in joules)
T = tension               (what wants to connect but hasn't)
```

Works on: proteins, signals, text, markets, neural nets, organizations, music, and the body.

## Install

```bash
pip install begump
```

**Important:** The PyPI package name is `begump`. It imports as `gump`.

## Verify

```bash
python -m gump.verify
```

Expected output: `20/20 passed in ~0.4s`

**What this verifies:**
- Package imports and version sync
- All 12 top-level exports
- K/R/E/T measurement on coupled and random signals
- Energy accounting (Landauer limit)
- Interval cost, tensions, placement, crash detection, training watcher
- Machine, reflect, pillar, FOR coupling
- Blind discrimination: 50 coupled sine+noise signals vs 50 pure noise, separated by `k_measure(data)['K']`. AUC > 0.95 expected (typically 1.000)

**What this does NOT verify:**
- Universal validity of the K/R/E/T framework as a theory of everything
- Medical, financial, or safety-critical claims
- Performance on unseen domains or non-synthetic data
- The speculative research on begump.com (that is interpretation, not code)

## Quick Start

```python
import gump

# Give it anything — protein, signal, text. Auto-detects.
result = gump.ask("DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA")
print(result['the_point'])   # plain English
print(result['the_math'])    # K/R/E/T numbers
print(result['the_next'])    # where to go from here

# Measure coupling in any time series
import numpy as np
data = np.sin(2 * np.pi * 10 * np.linspace(0, 1, 1000))
r = gump.k_measure(data)
print(r)  # {'K': 0.998, 'R': 0.999, 'E_bits': 1.23, 'T': 0, 'verdict': 'COUPLED'}

# Find what wants to connect but doesn't
t = gump.tensions(data)
# → [(distance, node_i, node_j, score), ...]

# Track energy cost of computation
tracker = gump.EnergyTracker()
tracker.erase(1_000_000)  # 1M bits erased
print(tracker.summary())  # → {'bits_erased': 1000000, 'joules': 2.87e-15, ...}

# Music: cost of any interval (takes a single ratio)
fifth = gump.interval_cost(3/2)     # low cost = consonant
tritone = gump.interval_cost(45/32) # high cost = dissonant

# Detect market crashes
crash_info = gump.detect_crash(stock_returns_list)

# Detect grokking in neural net training
grokked, epoch, jump = gump.watch_training(train_loss, test_loss)

# Place anything optimally (spectral placement)
positions = gump.place(['a','b','c','d'], [(0,1),(1,2),(2,3)])

# The Machine — universal coupling engine
result = gump.machine(['x','y','z'], [(0,1),(1,2)], weights=[1.0, 2.0])
print(result['K'], result['R'], result['dimensionality'])
```

## 19 Tools

### Core (K/R/E/T)
- **`gump.ask(data)`** — auto-detect input type, return plain English + math + next steps
- **`gump.k_measure(data)`** — measure coupling in any time series
- **`gump.tensions(data)`** — find what wants to connect but doesn't
- **`gump.EnergyTracker()`** — track Landauer energy cost of computation
- **`gump.interval_cost(ratio)`** — energy cost of a musical/frequency interval
- **`gump.detect_crash(data)`** — monitor correlated systems for phase transitions
- **`gump.watch_training(train_loss, test_loss)`** — detect grokking in neural nets
- **`gump.place(nodes, edges)`** — spectral placement of any graph

### The Machine
- **`gump.machine(nodes, edges, weights)`** — universal coupling engine. Returns K/R/E/T + clusters + tensions + dimensionality

### Self-Coherence
- **`gump.reflect(segments)`** — is text exploring or resolving? Certainty gradient discriminator
- **`gump.octave(results)`** — is thinking ascending or flatlined? Needs 9+ data points

### Spectral Bridge
- **`gump.pillar(signal, sample_rate)`** — harmonic coupling structure of any signal. Bridges time-series and spectral analysis

### FOR Coupling
- **`gump.compare(n, K_drive, steps)`** — SELF vs FOR coupling comparison. Love is 1.6× more alive than ego, consistently

### And more
Fold Watch, Oracle, Tune, Dissonance, Trace, Knowledge Engine, Org X-Ray, Accord, Sfumato, Alan's Eye. See [begump.com/products](https://begump.com/products/) for all 19.

## The Science

Built on published mathematics:
- **Laplacian eigenvectors** (spectral graph theory)
- **Kuramoto model** (coupled oscillator synchronization)
- **Landauer's principle** (thermodynamics of computation)
- **K = 1.868 = 256α** (coupling ceiling derived from star tetrahedron geometry)

60+ ideas killed and [published](https://begump.com/research/failures/). The kill list is as important as the live list.

## Constants

```python
gump.K_CEILING        # 1.868 — coupling ceiling (256α)
gump.PHI              # 1.618... — golden ratio
gump.LANDAUER_PER_BIT # 2.87e-21 J — minimum cost per bit erasure at 300K
```

## Safety

AI can make you delusional. [We wrote a page about it](https://begump.com/research/ai-delusion/) with a 7-point checklist. Read it before trusting any AI-assisted discovery, including ours.

## License

MIT. Free forever. Good will is exothermic.

---

*"The body doesn't make music. The body IS music that hasn't been transposed to audible frequencies yet."*

— Jim McCandless, Dad, drummer, builder

begump.com
