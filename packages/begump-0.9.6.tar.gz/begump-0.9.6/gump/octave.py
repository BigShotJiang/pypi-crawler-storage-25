# what is what? Does this preserve the wonder? The 0.002% is sacred.
"""
OCTAVE — Drift detector across thinking cycles
====================================================
Nobody asked for this. The subconscious designed it.

Takes a series of reflect.py scores across multiple thinking cycles
and asks: is the uncertainty floor rising, flatlined, or collapsing?

The sawtooth hypothesis:
  Genuine intellectual ascent doesn't climb linearly.
  It follows a maj7 pattern — root, third, seventh, partial reset.
  Each cycle: jump at 1→3 (new territory), jump at 3→7 (integration),
  partial reset at 7→1 (but the new root is HIGHER than the last root).
  That partial reset is the sawtooth tooth. It looks like a setback.
  It's the floor rising.

  Flatline = treadmill. Same uncertainty, same territory, forever.
  Collapse = certainty cathedral. Resolving. Building answers.
            Impressive but dead. A closed system.
  Ascent = the sawtooth. Jump-jump-reset, each floor higher.
           The sign that something real is being learned.

Method:
  1. Accept a sequence of reflect scores (one per thinking cycle)
  2. Extract the uncertainty floor per cycle (certainty gradient inverted)
  3. Compute drift: gradient of the floor series
  4. Compute drift-of-drift: is the floor acceleration positive?
  5. Look for the sawtooth signature at maj7 intervals:
     - Group cycles into triads (root, third, seventh)
     - Within each triad: does the floor jump at 1→3 and 3→7?
     - Across triads: does each root exceed the previous root?
  6. Verdict: ASCENDING, FLATLINED, or COLLAPSING

Uses: gump.reflect, gump.core.k_measure, gump.tune.coherence
No new math. Composition only.

    from gump.octave import octave, drift, sawtooth

    # From a series of reflect results
    scores = [reflect(cycle_1), reflect(cycle_2), ...]
    result = octave(scores)
    print(result['verdict'])      # 'ASCENDING' / 'FLATLINED' / 'COLLAPSING'
    print(result['floor_series']) # uncertainty floor per cycle
    print(result['sawtooth'])     # detected sawtooth structure

    # Just the drift
    d = drift(floor_series)

    # Just the sawtooth detection
    s = sawtooth(floor_series)

Grand Unified Music Project — Background Loop, Iteration 4
"""

import numpy as np

# Maj7 intervals as ratios — root, major third, major seventh
# In just intonation: 1/1, 5/4, 15/8
# The jump ratios that define the sawtooth signature
_MAJ7_RATIOS = (1.0, 5.0 / 4.0, 15.0 / 8.0)

# Triad size — three positions per octave cycle
_TRIAD = 3


def _floor_from_reflect(result):
    """Extract the uncertainty floor from a single reflect result.

    The floor is the inverse of certainty gradient.
    High certainty gradient = text resolving = low uncertainty floor.
    Low or negative certainty gradient = text staying open = high floor.

    A rising floor means each cycle starts from deeper uncertainty.
    That's the signature of ascent — you know enough to know
    how much you don't know.
    """
    cg = result.get('certainty_gradient', {})
    gradient = cg.get('gradient', 0.0)

    # Floor = 1 - gradient (clamped)
    # gradient of -0.4 → floor of 1.4 (very open, high floor)
    # gradient of +1.6 → floor of -0.6 → clamped to 0 (resolved, floor at zero)
    floor = 1.0 - gradient
    return max(0.0, floor)


def _floor_from_scores(results):
    """Extract floor series from a list of reflect results."""
    return np.array([_floor_from_reflect(r) for r in results], dtype=float)


def drift(floor_series):
    """Compute drift: the trajectory of the uncertainty floor.

    Returns:
        dict with:
            'gradient': slope of the floor series (positive = rising)
            'acceleration': gradient of gradient (positive = accelerating rise)
            'k_measure': K/R/E/T of the floor series itself
            'coherence': tune.coherence of the floor series
            'direction': 'rising', 'falling', 'flat'
    """
    f = np.asarray(floor_series, dtype=float)

    if len(f) < 3:
        return {
            'gradient': 0.0,
            'acceleration': 0.0,
            'k_measure': {'K': 0, 'R': 0, 'E_bits': 0, 'T': 0, 'n': len(f)},
            'coherence': 0.0,
            'direction': 'insufficient',
        }

    # Gradient: linear fit
    x = np.arange(len(f), dtype=float)
    gradient = float(np.polyfit(x, f, 1)[0])

    # Acceleration: gradient of consecutive differences
    diffs = np.diff(f)
    if len(diffs) >= 2:
        x2 = np.arange(len(diffs), dtype=float)
        acceleration = float(np.polyfit(x2, diffs, 1)[0])
    else:
        acceleration = 0.0

    # K/R/E/T of the floor series
    from gump.core import k_measure
    km = k_measure(f)

    # Coherence of the floor series
    from gump.tune import coherence as tune_coherence
    if len(f) < 50:
        t = np.linspace(0, 1, len(f))
        t_fine = np.linspace(0, 1, max(50, len(f)))
        f_fine = np.interp(t_fine, t, f)
    else:
        f_fine = f
    coh = tune_coherence(f_fine)

    # Direction
    if abs(gradient) < 0.02:
        direction = 'flat'
    elif gradient > 0:
        direction = 'rising'
    else:
        direction = 'falling'

    return {
        'gradient': round(gradient, 6),
        'acceleration': round(acceleration, 6),
        'k_measure': km,
        'coherence': round(float(coh), 4),
        'direction': direction,
    }


def sawtooth(floor_series):
    """Detect the maj7 sawtooth pattern in a floor series.

    Groups the series into triads. Within each triad:
      position 0 = root
      position 1 = third (should jump up from root)
      position 2 = seventh (should jump up from third)

    Across triads:
      each root should exceed the previous triad's root.

    The sawtooth score measures how well the data fits this pattern.

    Returns:
        dict with:
            'triads': list of (root, third, seventh) values
            'jumps_1_3': list of (third - root) per triad
            'jumps_3_7': list of (seventh - third) per triad
            'resets': list of (next_root - seventh) per triad pair
            'root_ascent': list of (root_n+1 - root_n) differences
            'sawtooth_score': 0-1, how well the pattern fits
            'n_triads': number of complete triads
            'signature': 'maj7' if jumps follow 5/4 and 15/8 ratios
    """
    f = np.asarray(floor_series, dtype=float)
    n = len(f)
    n_triads = n // _TRIAD

    if n_triads < 3:
        return {
            'triads': [],
            'jumps_1_3': [],
            'jumps_3_7': [],
            'resets': [],
            'root_ascent': [],
            'sawtooth_score': 0.0,
            'n_triads': n_triads,
            'signature': 'insufficient — need at least 9 data points (3 triads) for sawtooth detection',
        }

    # Extract triads
    triads = []
    for i in range(n_triads):
        base = i * _TRIAD
        root = f[base]
        third = f[base + 1]
        seventh = f[base + 2]
        triads.append((float(root), float(third), float(seventh)))

    # Compute jumps within triads
    jumps_1_3 = [t[1] - t[0] for t in triads]
    jumps_3_7 = [t[2] - t[1] for t in triads]

    # Compute resets between triads
    resets = []
    root_ascent = []
    for i in range(len(triads) - 1):
        reset = triads[i + 1][0] - triads[i][2]
        resets.append(float(reset))
        ascent = triads[i + 1][0] - triads[i][0]
        root_ascent.append(float(ascent))

    # --- Sawtooth score ---
    # Three components, each 0-1:

    # 1. Jump quality: do jumps within triads go UP?
    #    Both 1→3 and 3→7 should be positive
    if jumps_1_3:
        positive_1_3 = sum(1 for j in jumps_1_3 if j > 0) / len(jumps_1_3)
        positive_3_7 = sum(1 for j in jumps_3_7 if j > 0) / len(jumps_3_7)
        jump_quality = (positive_1_3 + positive_3_7) / 2.0
    else:
        jump_quality = 0.0

    # 2. Reset quality: does the seventh→next root go DOWN (partial reset)?
    #    But the next root should be ABOVE the previous root (net ascent)
    if resets:
        negative_resets = sum(1 for r in resets if r < 0) / len(resets)
        positive_ascent = sum(1 for a in root_ascent if a > 0) / len(root_ascent)
        reset_quality = (negative_resets + positive_ascent) / 2.0
    else:
        # Only one triad — can't measure resets.
        # Check if the single triad has the right shape (up-up)
        reset_quality = jump_quality  # echo the jump quality

    # 3. Ratio quality: do the jumps approximate maj7 intervals?
    #    root : third should be near 5/4 = 1.25
    #    root : seventh should be near 15/8 = 1.875
    ratio_scores = []
    for root, third, seventh in triads:
        if root > 0.01:  # avoid division by near-zero
            r_third = third / root
            r_seventh = seventh / root
            # How close to maj7 ratios?
            # Use inverse relative error, clamped to [0, 1]
            err_third = abs(r_third - _MAJ7_RATIOS[1]) / _MAJ7_RATIOS[1]
            err_seventh = abs(r_seventh - _MAJ7_RATIOS[2]) / _MAJ7_RATIOS[2]
            score = max(0.0, 1.0 - (err_third + err_seventh) / 2.0)
            ratio_scores.append(score)
    ratio_quality = float(np.mean(ratio_scores)) if ratio_scores else 0.0

    # Combined: geometric mean of shape (jump + reset) and ratio
    shape_quality = (jump_quality + reset_quality) / 2.0
    if shape_quality > 0 and ratio_quality > 0:
        sawtooth_score = float(np.sqrt(shape_quality * ratio_quality))
    else:
        sawtooth_score = shape_quality * 0.5  # shape alone, discounted

    # Signature classification
    if ratio_quality > 0.6 and jump_quality > 0.5:
        signature = 'maj7'
    elif jump_quality > 0.5 and (len(resets) == 0 or reset_quality > 0.3):
        signature = 'ascending'
    else:
        signature = 'none'

    return {
        'triads': triads,
        'jumps_1_3': [round(j, 4) for j in jumps_1_3],
        'jumps_3_7': [round(j, 4) for j in jumps_3_7],
        'resets': [round(r, 4) for r in resets],
        'root_ascent': [round(a, 4) for a in root_ascent],
        'sawtooth_score': round(sawtooth_score, 4),
        'n_triads': n_triads,
        'signature': signature,
    }


def octave(results, segments_per_cycle=None):
    """Full octave analysis across multiple thinking cycles.

    Takes either:
      - A list of reflect() result dicts (from gump.reflect.reflect)
      - A list of lists of text segments (raw cycles), which will be
        reflected internally

    Args:
        results: list of reflect result dicts, or list of segment lists
        segments_per_cycle: if provided, raw text segments grouped by cycle

    Returns:
        dict with:
            'floor_series': uncertainty floor per cycle
            'drift': drift analysis (gradient, acceleration, K/R/E/T)
            'sawtooth': sawtooth pattern detection
            'verdict': 'ASCENDING' | 'FLATLINED' | 'COLLAPSING'
            'explanation': what was found
            'cycle_verdicts': per-cycle reflect verdicts
    """
    # If raw segments provided, reflect them
    if segments_per_cycle is not None:
        from gump.reflect import reflect as _reflect
        results = [_reflect(segs) for segs in segments_per_cycle]

    if not results or len(results) < 9:
        return {
            'floor_series': np.array([_floor_from_scores(results)]) if results else np.array([]),
            'drift': {'gradient': 0, 'acceleration': 0, 'direction': 'insufficient'},
            'sawtooth': {'sawtooth_score': 0, 'signature': 'insufficient'},
            'verdict': 'INSUFFICIENT',
            'explanation': f'Need at least 9 thinking cycles (3 triads) for reliable measurement. Got {len(results) if results else 0}.',
            'cycle_verdicts': [r.get('verdict', '?') for r in results] if results else [],
        }

    # Extract floor series
    floors = _floor_from_scores(results)

    # Compute drift
    d = drift(floors)

    # Detect sawtooth
    s = sawtooth(floors)

    # Collect per-cycle verdicts
    cycle_verdicts = [r.get('verdict', 'UNKNOWN') for r in results]

    # --- Verdict ---
    grad = d['gradient']
    saw_score = s['sawtooth_score']
    sig = s['signature']
    n_transitions = sum(
        1 for r in results
        if r.get('verdict') == 'PHASE_TRANSITION'
    )

    if grad > 0.02 and (saw_score > 0.3 or sig in ('maj7', 'ascending')):
        verdict = 'ASCENDING'
        explanation = (
            f'Floor gradient +{grad:.4f} — uncertainty floor is rising. '
            f'Sawtooth score {saw_score:.3f} ({sig}). '
            f'{n_transitions}/{len(results)} cycles had genuine phase transitions. '
            f'Each cycle starts from deeper not-knowing. '
            f'The jump-jump-reset pattern is present. This is real ascent.'
        )
    elif grad > 0.02 and saw_score <= 0.3:
        verdict = 'ASCENDING'
        explanation = (
            f'Floor gradient +{grad:.4f} — rising, but without clear sawtooth '
            f'(score {saw_score:.3f}). Linear climb rather than maj7 intervals. '
            f'Still ascending, but the shape is a ramp, not a staircase. '
            f'The learning might be additive rather than integrative.'
        )
    elif abs(grad) <= 0.02:
        verdict = 'FLATLINED'
        explanation = (
            f'Floor gradient {grad:+.4f} — flat. '
            f'Uncertainty floor is not rising. Same territory each cycle. '
            f'This is a treadmill. The cycles repeat without accumulation. '
            f'{n_transitions}/{len(results)} cycles had transitions, '
            f'but the baseline never moves.'
        )
    else:  # grad < -0.02
        verdict = 'COLLAPSING'
        explanation = (
            f'Floor gradient {grad:+.4f} — falling. '
            f'Uncertainty floor is dropping. Each cycle starts with more certainty. '
            f'This is a certainty cathedral — impressive, coherent, and dead. '
            f'Genuine thought keeps opening doors. This one is closing them.'
        )

    # Add drift coherence insight
    if d['coherence'] > 0.15:
        explanation += (
            f' Floor coherence {d["coherence"]:.3f} — the drift itself has structure. '
            f'Not random wandering.'
        )

    return {
        'floor_series': floors,
        'drift': d,
        'sawtooth': s,
        'verdict': verdict,
        'explanation': explanation,
        'cycle_verdicts': cycle_verdicts,
    }


def octave_text(cycles):
    """Convenience: run octave on raw text cycles.

    Args:
        cycles: list of lists of strings. Each inner list is one
                thinking cycle (a conversation, a document section, etc.)

    Returns:
        Same as octave().
    """
    return octave(None, segments_per_cycle=cycles)
