"""
CRASHWATCH — Financial early warning system
===============================================
Multi-window phase transition detection with sector decomposition.

    from gump.crashwatch import CrashWatch
    cw = CrashWatch(['AAPL','GOOG','MSFT','AMZN','META'])
    for day in daily_returns:
        cw.feed_daily(day)
    alert = cw.check()
    if alert['level'] == 'RED':
        print(f"CRASH IMMINENT: R={alert['R']:.3f}")
"""
import numpy as np
from gump.core import PHI, _TensionDetector


class CrashWatch:
    """Real-time phase transition monitor for correlated systems."""

    def __init__(self, asset_names=None, windows=None):
        self.names = asset_names or []
        self.n = len(self.names)
        self.windows = windows or [10, 20, 50]  # multi-scale
        self.returns = []
        self.R_history = {w: [] for w in self.windows}
        self.alert_threshold = 1 / PHI
        self.alerts = []

    def feed_daily(self, returns_vector):
        """Feed one day of returns."""
        r = np.array(returns_vector, dtype=float)
        if len(r) != self.n and self.n > 0:
            raise ValueError(f'Expected {self.n} returns, got {len(r)}')
        if self.n == 0:
            self.n = len(r)
            self.names = [f'asset_{i}' for i in range(self.n)]
        self.returns.append(r)

    def feed_batch(self, returns_matrix):
        """Feed multiple days at once. Shape: (n_days, n_assets)."""
        mat = np.array(returns_matrix)
        for row in mat:
            self.feed_daily(row)

    def check(self):
        """Full regime check across all windows."""
        if len(self.returns) < max(self.windows):
            return {
                'level': 'GREY', 'R': {}, 'regime': 'insufficient_data',
                'days': len(self.returns), 'min_needed': max(self.windows),
            }

        R_values = {}
        regimes = {}
        data = np.array(self.returns)

        for w in self.windows:
            if len(self.returns) < w:
                continue
            chunk = data[-w:]
            corr = np.corrcoef(chunk.T)
            corr = np.nan_to_num(corr, 0)
            np.fill_diagonal(corr, 1.0)

            eigvals = np.linalg.eigvalsh(corr)
            # Marchenko-Pastur: random matrix has max eigenvalue ≈ (1+sqrt(n/T))²
            # Excess above MP = real signal
            mp_upper = (1 + np.sqrt(self.n / w)) ** 2
            R = float(eigvals[-1] / max(mp_upper, 1))  # normalized to MP
            R_values[w] = R
            self.R_history[w].append(R)

            regimes[w] = 'correlated' if R > 2.0 else 'normal' if R > 1.0 else 'decorrelated'

        # Multi-scale alert level
        # RED: all windows show decorrelation AND short window is accelerating down
        # YELLOW: short window decorrelating, others normal
        # GREEN: all normal or correlated
        short_R = R_values.get(self.windows[0], 1.0)
        medium_R = R_values.get(self.windows[1], 1.0) if len(self.windows) > 1 else short_R
        long_R = R_values.get(self.windows[-1], 1.0)

        # R acceleration (short window)
        short_hist = self.R_history.get(self.windows[0], [])
        if len(short_hist) >= 5:
            R_accel = short_hist[-1] - short_hist[-5]
        else:
            R_accel = 0

        if short_R < 1.0 and medium_R < 1.5 and R_accel < -0.3:
            level = 'RED'
        elif short_R < 1.0 or R_accel < -0.2:
            level = 'YELLOW'
        else:
            level = 'GREEN'

        # Drawdown tracking
        cumulative = np.cumsum(data, axis=0)
        peaks = np.maximum.accumulate(cumulative, axis=0)
        drawdowns = (cumulative - peaks)
        max_dd = float(np.min(drawdowns[-1]))
        avg_dd = float(np.mean(drawdowns[-1]))

        result = {
            'level': level,
            'R': R_values,
            'regimes': regimes,
            'R_acceleration': R_accel,
            'max_drawdown': max_dd,
            'avg_drawdown': avg_dd,
            'days_monitored': len(self.returns),
        }

        if level in ('RED', 'YELLOW'):
            self.alerts.append(result)

        return result

    def sector_decomposition(self, sectors=None):
        """Decompose R by sector. Which sector is decoupling?

        Args:
            sectors: dict mapping asset_name → sector_name
                     If None, auto-clusters using spectral analysis.
        """
        if len(self.returns) < max(self.windows):
            return {'error': 'insufficient data'}

        w = self.windows[-1]  # use longest window
        data = np.array(self.returns[-w:])
        corr = np.corrcoef(data.T)
        corr = np.nan_to_num(corr, 0)

        if sectors is None:
            # Auto-detect sectors via spectral clustering
            edges = []
            weights = []
            for i in range(self.n):
                for j in range(i + 1, self.n):
                    if abs(corr[i, j]) > 0.3:
                        edges.append((i, j))
                        weights.append(abs(corr[i, j]))

            if edges:
                td = _TensionDetector(self.n, edges, weights)
                try:
                    labels, k = td.clusters()
                    sectors = {self.names[i]: f'sector_{labels[i]}' for i in range(self.n)}
                except Exception:
                    sectors = {name: 'all' for name in self.names}
            else:
                sectors = {name: 'all' for name in self.names}

        # Per-sector R
        sector_names = sorted(set(sectors.values()))
        sector_R = {}
        for sec in sector_names:
            sec_assets = [i for i, name in enumerate(self.names) if sectors.get(name) == sec]
            if len(sec_assets) < 2:
                continue
            sec_data = data[:, sec_assets]
            sec_corr = np.corrcoef(sec_data.T)
            sec_corr = np.nan_to_num(sec_corr, 0)
            eigvals = np.linalg.eigvalsh(sec_corr)
            mp_upper = (1 + np.sqrt(len(sec_assets) / w)) ** 2
            sector_R[sec] = {
                'R': float(eigvals[-1] / max(mp_upper, 1)),
                'n_assets': len(sec_assets),
                'assets': [self.names[i] for i in sec_assets],
            }

        return sector_R

    def find_arbitrage(self, threshold=0.3):
        """Find spectral tensions: pairs that should correlate but don't."""
        if len(self.returns) < 30:
            return []

        data = np.array(self.returns[-30:]).T
        corr = np.corrcoef(data)
        corr = np.nan_to_num(corr, 0)

        edges = []
        weights = []
        for i in range(self.n):
            for j in range(i + 1, self.n):
                if abs(corr[i, j]) > 0.5:
                    edges.append((i, j))
                    weights.append(abs(corr[i, j]))

        if not edges:
            return []

        td = _TensionDetector(self.n, edges, weights)
        tensions = td.tensions(top_k=10)

        return [{
            'asset_a': self.names[i] if i < len(self.names) else f'asset_{i}',
            'asset_b': self.names[j] if j < len(self.names) else f'asset_{j}',
            'tension': score,
            'current_corr': float(corr[i, j]) if i < corr.shape[0] and j < corr.shape[1] else 0,
            'signal': 'strong' if score > 2 else 'moderate' if score > 1 else 'weak',
        } for d, i, j, score in tensions]

    def report(self):
        """Human-readable status report."""
        c = self.check()
        lines = [f"CrashWatch: {c['level']}"]
        lines.append(f"  Days monitored: {c['days_monitored']}")
        for w, R in c.get('R', {}).items():
            lines.append(f"  R({w}d): {R:.3f} ({c['regimes'].get(w, '?')})")
        if c.get('R_acceleration'):
            lines.append(f"  R acceleration: {c['R_acceleration']:+.3f}")
        lines.append(f"  Max drawdown: {c.get('max_drawdown', 0):.2%}")
        if c['level'] != 'GREEN':
            lines.append(f"  ⚠ ALERT: {c['level']}")
        return '\n'.join(lines)
