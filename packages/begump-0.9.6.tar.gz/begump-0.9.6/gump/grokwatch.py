"""
GROKWATCH — Know when your model understands
================================================
Tracks memorization, generalization, and the transition between them.
Multiple detection methods: accuracy jump, loss divergence, weight norm.

    from gump.grokwatch import GrokWatch
    watcher = GrokWatch()
    for epoch in range(10000):
        train(model)
        watcher.log(train_acc=0.99, test_acc=0.15, loss=2.3,
                     weight_norm=model.weight_norm())
        if watcher.grokked:
            print(f'Grokked at epoch {watcher.grok_epoch}! Save {watcher.savings}%')
            break
"""
import numpy as np
from gump.core import EnergyTracker, LANDAUER_PER_BIT


class GrokWatch:
    """Monitor training for grokking with multi-signal detection."""

    def __init__(self, window=20, acc_threshold=0.15, patience=500):
        """
        Args:
            window: smoothing window for detection
            acc_threshold: minimum accuracy jump to count as grokking
            patience: epochs to wait after memorization before declaring stuck
        """
        self.window = window
        self.acc_threshold = acc_threshold
        self.patience = patience

        self.train_accs = []
        self.test_accs = []
        self.losses = []
        self.weight_norms = []
        self.grad_norms = []
        self.energy_per_correct = []

        self.tracker = EnergyTracker()
        self.grokked = False
        self.grok_epoch = -1
        self.grok_jump = 0.0
        self.memorized = False
        self.memorize_epoch = -1
        self.stuck = False

        self._prev_test = 0

    def log(self, train_acc, test_acc, loss=None, weight_norm=None,
            grad_norm=None, n_params=0):
        """Log one epoch. Call after each training epoch."""
        self.train_accs.append(float(train_acc))
        self.test_accs.append(float(test_acc))
        if loss is not None:
            self.losses.append(float(loss))
        if weight_norm is not None:
            self.weight_norms.append(float(weight_norm))
        if grad_norm is not None:
            self.grad_norms.append(float(grad_norm))

        # Energy tracking
        bits = max(n_params, 100) * 32
        self.tracker.erase(bits)
        n_correct = max(1, int(test_acc * 100))
        self.energy_per_correct.append(self.tracker.total_joules / n_correct)

        epoch = len(self.test_accs) - 1

        # ─── Detection logic ───

        # 1. Memorization: train high, test low
        if train_acc > 0.90 and test_acc < 0.30 and not self.memorized:
            self.memorized = True
            self.memorize_epoch = epoch

        # 2. Grokking detection (multi-signal)
        if not self.grokked and epoch >= self.window:
            grok_signals = 0

            # Signal A: test accuracy jump
            recent_avg = np.mean(self.test_accs[-self.window:])
            prev_avg = np.mean(self.test_accs[-2 * self.window:-self.window]) \
                if epoch >= 2 * self.window else np.mean(self.test_accs[:self.window])
            acc_jump = recent_avg - prev_avg
            if acc_jump > self.acc_threshold:
                grok_signals += 1

            # Signal B: energy per correct drops
            if len(self.energy_per_correct) >= 2 * self.window:
                recent_epc = np.mean(self.energy_per_correct[-self.window:])
                prev_epc = np.mean(self.energy_per_correct[-2 * self.window:-self.window])
                if prev_epc > 0 and recent_epc / prev_epc < 0.5:  # 50% drop
                    grok_signals += 1

            # Signal C: weight norm stabilizes (understanding = compressed weights)
            if len(self.weight_norms) >= 2 * self.window:
                recent_wnorm = np.std(self.weight_norms[-self.window:])
                prev_wnorm = np.std(self.weight_norms[-2 * self.window:-self.window])
                if prev_wnorm > 0 and recent_wnorm / prev_wnorm < 0.3:
                    grok_signals += 1

            # Signal D: train-test gap closing
            gap = train_acc - test_acc
            prev_gap = self.train_accs[-self.window] - self.test_accs[-self.window] \
                if epoch >= self.window else 1.0
            if gap < prev_gap * 0.5 and gap < 0.3:
                grok_signals += 1

            # Grok if 2+ signals agree
            if grok_signals >= 2:
                self.grokked = True
                self.grok_epoch = epoch
                self.grok_jump = acc_jump

        # 3. Stuck detection
        if self.memorized and not self.grokked:
            if epoch - self.memorize_epoch > self.patience:
                if self.test_accs[-1] < 0.3:
                    self.stuck = True

        self._prev_test = test_acc

    @property
    def phase(self):
        if self.grokked:
            return 'generalized'
        if self.stuck:
            return 'stuck'
        if self.memorized:
            return 'memorizing'
        return 'learning'

    @property
    def savings(self):
        """Estimated compute savings if we stop at grok point."""
        if not self.grokked or self.grok_epoch < 1:
            return 0
        # If total training was planned for 3× current epochs
        planned = len(self.test_accs) * 3
        saved = planned - self.grok_epoch
        return round(saved / planned * 100)

    def should_stop(self):
        """Should training stop?"""
        if self.grokked:
            return True
        if self.stuck:
            return True
        return False

    def status(self):
        """Current status dict."""
        epoch = len(self.test_accs)
        return {
            'epoch': epoch,
            'phase': self.phase,
            'train_acc': self.train_accs[-1] if self.train_accs else 0,
            'test_acc': self.test_accs[-1] if self.test_accs else 0,
            'memorized': self.memorized,
            'memorize_epoch': self.memorize_epoch,
            'grokked': self.grokked,
            'grok_epoch': self.grok_epoch,
            'grok_jump': self.grok_jump,
            'stuck': self.stuck,
            'total_energy_J': self.tracker.total_joules,
            'energy_per_correct': self.energy_per_correct[-1] if self.energy_per_correct else 0,
            'savings_pct': self.savings,
        }

    def report(self):
        """Human-readable report."""
        s = self.status()
        lines = [f"GrokWatch: {s['phase'].upper()}"]
        lines.append(f"  Epoch {s['epoch']}: train={s['train_acc']:.1%} test={s['test_acc']:.1%}")
        lines.append(f"  Energy: {s['total_energy_J']:.2e} J total, {s['energy_per_correct']:.2e} J/correct")
        if s['memorized']:
            lines.append(f"  Memorized at epoch {s['memorize_epoch']}")
        if s['grokked']:
            lines.append(f"  ★ GROKKED at epoch {s['grok_epoch']} (jump: {s['grok_jump']:.2f})")
            lines.append(f"  Estimated savings: {s['savings_pct']}% of compute")
        if s['stuck']:
            lines.append(f"  ✗ STUCK — consider: more weight decay, different optimizer, more data")
        return '\n'.join(lines)
