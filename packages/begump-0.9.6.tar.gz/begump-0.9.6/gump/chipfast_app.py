"""
CHIP FAST APP — Design chips for free. Interactive layout visualization.
=========================================================================
Write a circuit → see it placed, routed, and analyzed instantly.

    from gump.chipfast_app import design_report, netlist_report

    # From gates and wires
    html = design_report(['and','or','xor','buf','nand'],
                         [(0,1),(1,2),(2,3),(3,4),(0,4)])

    # From netlist
    html = netlist_report('and g0 (y, a, b); or g1 (z, y, c);')

    # Random benchmark
    html = benchmark_report(1000)   # 1000 gates

Built on: gump.chipfast (placement + routing) + gump.core (spectral, tensions)
"""

import json
import numpy as np
from gump.chipfast import design, design_netlist
from gump.k_runtime import energy as k_energy_cost
from gump.core import EnergyTracker, LANDAUER_PER_BIT


def design_report(gates, wires, weights=None, title='Chip Layout'):
    """Generate interactive chip layout report — Cadence Innovus / OpenROAD style."""
    result = design(gates, wires, weights)
    if 'error' in result:
        return f'<html><body><h1>Error</h1><p>{result["error"]}</p></body></html>'

    # Compute Landauer cost
    tracker = EnergyTracker()
    n_bits = result['n_gates'] * 32
    tracker.erase(n_bits, 'placement')
    energy_J = tracker.total_joules

    # Wire reduction vs random placement
    n = result['n_gates']
    random_wl = 0
    if n > 1:
        pos_rand = np.column_stack([np.random.rand(n) * np.sqrt(n) * 3,
                                     np.random.rand(n) * np.sqrt(n) * 3])
        ci = [w[0] for w in wires]
        cj = [w[1] for w in wires]
        random_wl = float(np.sum(np.abs(pos_rand[ci, 0] - pos_rand[cj, 0]) +
                                  np.abs(pos_rand[ci, 1] - pos_rand[cj, 1])))
    reduction = round((1 - result['wire_length'] / max(random_wl, 1)) * 100, 1) if random_wl > 0 else 0

    positions = result['positions']
    pos_list = [[round(float(positions[i][0]), 2), round(float(positions[i][1]), 2)]
                for i in range(n)]

    # Compute per-gate degree for hover info
    degree = [0] * n
    for w in wires:
        if w[0] < n:
            degree[w[0]] += 1
        if w[1] < n:
            degree[w[1]] += 1

    # Simple gate type classification from name
    gate_types = []
    for g in result['gate_names']:
        gl = g.lower()
        if 'and' in gl or 'nand' in gl:
            gate_types.append('and')
        elif 'or' in gl or 'nor' in gl:
            gate_types.append('or')
        elif 'xor' in gl or 'xnor' in gl:
            gate_types.append('xor')
        elif 'buf' in gl or 'inv' in gl or 'not' in gl:
            gate_types.append('buf')
        elif 'ff' in gl or 'flop' in gl or 'reg' in gl:
            gate_types.append('ff')
        else:
            gate_types.append('logic')

    # Compute congestion grid for heatmap
    grid_size = 20
    if n > 0:
        pmax_x = max(p[0] for p in pos_list) or 1
        pmax_y = max(p[1] for p in pos_list) or 1
    else:
        pmax_x = pmax_y = 1
    congestion = [[0] * grid_size for _ in range(grid_size)]
    for w in wires:
        if w[0] < n and w[1] < n:
            gx0 = min(grid_size - 1, int(pos_list[w[0]][0] / max(pmax_x, 0.01) * (grid_size - 1)))
            gy0 = min(grid_size - 1, int(pos_list[w[0]][1] / max(pmax_y, 0.01) * (grid_size - 1)))
            gx1 = min(grid_size - 1, int(pos_list[w[1]][0] / max(pmax_x, 0.01) * (grid_size - 1)))
            gy1 = min(grid_size - 1, int(pos_list[w[1]][1] / max(pmax_y, 0.01) * (grid_size - 1)))
            congestion[gy0][gx0] += 1
            congestion[gy1][gx1] += 1

    data = {
        'gates': result['gate_names'],
        'gate_types': gate_types,
        'degree': degree,
        'wires': [[int(w[0]), int(w[1])] for w in wires],
        'positions': pos_list,
        'wire_length': round(result['wire_length'], 1),
        'hot_spots': result['hot_spots'],
        'missing': result['missing_connections'],
        'n_gates': n,
        'n_wires': len(wires),
        'reduction': reduction,
        'energy_J': energy_J,
        'congestion': congestion,
    }
    data_json = json.dumps(data)

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Chip Fast — {title}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:#08080d;color:#e8e4dc;font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;display:flex;height:100vh;overflow:hidden;}}
@keyframes fadeIn{{from{{opacity:0;transform:translateY(6px);}}to{{opacity:1;transform:translateY(0);}}}}
@keyframes pulseMissing{{0%,100%{{opacity:0.4;}}50%{{opacity:0.8;}}}}

/* ═══ Canvas ═══ */
#canvas-wrap{{flex:1;position:relative;min-width:0;}}
canvas{{display:block;width:100%;height:100%;cursor:grab;}}
canvas:active{{cursor:grabbing;}}

/* ═══ Tooltip ═══ */
#tooltip{{position:absolute;display:none;background:#0d0d14;border:1px solid #c9a44a40;border-radius:10px;padding:14px 18px;
  pointer-events:none;z-index:100;min-width:200px;box-shadow:0 8px 32px rgba(0,0,0,0.6);backdrop-filter:blur(8px);}}
#tooltip .tt-name{{font-size:1.05em;font-weight:600;color:#c9a44a;margin-bottom:6px;}}
#tooltip .tt-type{{display:inline-block;padding:2px 10px;border-radius:8px;font-size:0.65em;font-weight:600;
  letter-spacing:0.06em;text-transform:uppercase;margin-bottom:8px;}}
#tooltip .tt-row{{display:flex;justify-content:space-between;font-size:0.78em;color:#888;padding:2px 0;}}
#tooltip .tt-row span:last-child{{color:#e8e4dc;font-weight:500;}}

/* ═══ Overlay controls ═══ */
#controls{{position:absolute;top:16px;left:16px;display:flex;gap:6px;z-index:10;}}
.ctrl-btn{{background:#0d0d14d0;border:1px solid #ffffff10;border-radius:8px;padding:6px 14px;font-size:0.7em;
  color:#888;cursor:pointer;transition:all 0.2s;backdrop-filter:blur(4px);user-select:none;}}
.ctrl-btn:hover{{border-color:#ffffff20;color:#e8e4dc;}}
.ctrl-btn.active{{border-color:#c9a44a40;color:#c9a44a;background:#c9a44a10;}}

/* ═══ Legend ═══ */
#legend{{position:absolute;bottom:16px;left:16px;background:#0d0d14e0;border:1px solid #ffffff08;
  border-radius:10px;padding:12px 16px;font-size:0.65em;color:#888;backdrop-filter:blur(4px);line-height:2;}}
#legend .lg-row{{display:flex;align-items:center;gap:8px;}}
#legend .lg-box{{width:12px;height:8px;border-radius:2px;flex-shrink:0;}}
#legend .lg-line{{width:16px;height:0;flex-shrink:0;}}

/* ═══ Zoom indicator ═══ */
#zoom-ind{{position:absolute;bottom:16px;right:16px;background:#0d0d14d0;border:1px solid #ffffff08;
  border-radius:8px;padding:6px 12px;font-size:0.65em;color:#666;backdrop-filter:blur(4px);}}

/* ═══ Right panel ═══ */
#panel{{width:340px;background:#0d0d14;border-left:1px solid #ffffff08;overflow-y:auto;padding:0;display:flex;flex-direction:column;}}
#panel::-webkit-scrollbar{{width:4px;}} #panel::-webkit-scrollbar-track{{background:transparent;}} #panel::-webkit-scrollbar-thumb{{background:#ffffff10;border-radius:2px;}}
.panel-inner{{padding:24px 20px;}}
h1{{font-size:1.3em;font-weight:300;color:#c9a44a;letter-spacing:0.08em;margin-bottom:2px;}}
.sub{{font-size:0.62em;color:#444;letter-spacing:0.15em;margin-bottom:20px;font-weight:400;}}
h2{{font-size:0.72em;font-weight:600;color:#c9a44a80;letter-spacing:0.12em;text-transform:uppercase;margin:24px 0 10px;}}

/* ═══ Stats cards ═══ */
.stats-grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin:12px 0;}}
.stat-card{{background:#111118;border:1px solid #ffffff04;border-radius:8px;padding:12px;text-align:center;transition:border-color 0.3s;}}
.stat-card:hover{{border-color:#c9a44a20;}}
.stat-card .sv{{font-size:1.5em;font-weight:200;line-height:1;}}
.stat-card .sl{{font-size:0.58em;color:#666;margin-top:4px;text-transform:uppercase;letter-spacing:0.08em;}}
.stat-card.good .sv{{color:#4a9;}} .stat-card.warn .sv{{color:#c94;}} .stat-card.gold .sv{{color:#c9a44a;}}

/* ═══ Reduction badge ═══ */
.reduction-badge{{display:flex;align-items:center;justify-content:center;gap:8px;background:linear-gradient(135deg,#0d1a0d,#111118);
  border:1px solid #4a9930;border-radius:12px;padding:14px;margin:12px 0;}}
.reduction-badge .rb-pct{{font-size:2em;font-weight:200;color:#4a9;}}
.reduction-badge .rb-label{{font-size:0.72em;color:#888;}}

/* ═══ Missing connections ═══ */
.missing-card{{background:#111118;border:1px solid #c9a44a15;border-radius:8px;padding:12px 14px;margin:6px 0;
  display:flex;align-items:center;gap:12px;transition:border-color 0.3s;cursor:pointer;}}
.missing-card:hover{{border-color:#c9a44a40;}}
.missing-card .mc-icon{{width:8px;height:8px;border-radius:50%;border:2px dashed #c9a44a;flex-shrink:0;animation:pulseMissing 2s infinite;}}
.missing-card .mc-gates{{font-size:0.82em;font-weight:500;color:#e8e4dc;}}
.missing-card .mc-tension{{font-size:0.68em;color:#666;margin-left:auto;}}

/* ═══ Netlist input ═══ */
.netlist-wrap{{margin-top:8px;}}
textarea{{width:100%;height:70px;background:#111118;border:1px solid #ffffff08;color:#e8e4dc;
  font-family:'SF Mono','Fira Code',monospace;font-size:0.72em;padding:10px;border-radius:8px;resize:vertical;}}
textarea:focus{{outline:none;border-color:#c9a44a40;}}
.btn{{background:#c9a44a15;border:1px solid #c9a44a30;color:#c9a44a;padding:8px 20px;border-radius:20px;
  cursor:pointer;font-size:0.72em;margin-top:6px;transition:all 0.2s;font-weight:500;}}
.btn:hover{{background:#c9a44a25;border-color:#c9a44a60;}}

@media(max-width:768px){{
  body{{flex-direction:column;}}
  #panel{{width:100%;height:50vh;border-left:none;border-top:1px solid #ffffff08;}}
}}
</style>
</head>
<body>

<div id="canvas-wrap">
  <canvas id="chip"></canvas>
  <div id="tooltip"></div>
  <div id="controls">
    <div class="ctrl-btn" id="btn-congestion" onclick="toggleCongestion()">Congestion</div>
    <div class="ctrl-btn" id="btn-wires" onclick="toggleWires()">Wires</div>
    <div class="ctrl-btn active" id="btn-labels" onclick="toggleLabels()">Labels</div>
    <div class="ctrl-btn" id="btn-missing" onclick="toggleMissing()">Missing</div>
  </div>
  <div id="legend">
    <div class="lg-row"><div class="lg-box" style="background:#c9a44a;"></div>AND / NAND</div>
    <div class="lg-row"><div class="lg-box" style="background:#4a9;"></div>OR / NOR</div>
    <div class="lg-row"><div class="lg-box" style="background:#60a0e8;"></div>XOR / XNOR</div>
    <div class="lg-row"><div class="lg-box" style="background:#a070d0;"></div>BUF / INV</div>
    <div class="lg-row"><div class="lg-box" style="background:#c94;"></div>Flip-flop</div>
    <div class="lg-row"><div class="lg-box" style="background:#888;"></div>Logic</div>
    <div class="lg-row"><div class="lg-line" style="border-top:1.5px solid #4a9ac960;"></div>H-wire (M1)</div>
    <div class="lg-row"><div class="lg-line" style="border-top:1.5px solid #4ac96960;"></div>V-wire (M2)</div>
    <div class="lg-row"><div class="lg-line" style="border-top:1.5px dashed #c9a44a80;"></div>Missing conn.</div>
    <div class="lg-row"><div class="lg-box" style="background:linear-gradient(90deg,#4a9,#c44);opacity:0.5;"></div>Congestion</div>
  </div>
  <div id="zoom-ind">100%</div>
</div>

<div id="panel">
  <div class="panel-inner">
    <h1>Chip Fast</h1>
    <div class="sub">GUMP &middot; spectral placement &amp; routing</div>

    <div class="reduction-badge">
      <div class="rb-pct">{reduction}%</div>
      <div class="rb-label">wire length<br>reduction vs random</div>
    </div>

    <div class="stats-grid">
      <div class="stat-card gold"><div class="sv">{n}</div><div class="sl">gates</div></div>
      <div class="stat-card gold"><div class="sv">{len(wires)}</div><div class="sl">wires</div></div>
      <div class="stat-card good"><div class="sv">{result['wire_length']:.0f}</div><div class="sl">wire length</div></div>
      <div class="stat-card {'warn' if result['hot_spots'] > 3 else 'gold'}"><div class="sv">{result['hot_spots']}</div><div class="sl">hot spots</div></div>
      <div class="stat-card gold"><div class="sv">{len(result.get('missing_connections', []))}</div><div class="sl">missing</div></div>
      <div class="stat-card gold"><div class="sv">{energy_J:.1e}</div><div class="sl">energy (J)</div></div>
    </div>

    <h2>MISSING CONNECTIONS</h2>
    <div id="missing-list"></div>

    <h2>NETLIST INPUT</h2>
    <div class="netlist-wrap">
      <textarea id="netlist-input" placeholder="and g0 (y, a, b); or g1 (z, y, c);"></textarea>
      <button class="btn" onclick="redesign()">Redesign</button>
    </div>
  </div>
</div>

<script>
var DATA = {data_json};

var TYPE_COLORS = {{and:'#c9a44a',or:'#4a9',xor:'#60a0e8',buf:'#a070d0',ff:'#c94',logic:'#888'}};

var cv = document.getElementById('chip');
var cx = cv.getContext('2d');
var wrap = document.getElementById('canvas-wrap');
var tooltip = document.getElementById('tooltip');
var zoomInd = document.getElementById('zoom-ind');
var dpr = window.devicePixelRatio||1;

// View state
var cam = {{x:0,y:0,zoom:1}};
var drag = {{active:false,sx:0,sy:0,cx:0,cy:0}};
var hoveredGate = -1;
var showCongestion = false, showWires = true, showLabels = true, showMissing = true;

function resize(){{
  var r=wrap.getBoundingClientRect();
  cv.width=r.width*dpr; cv.height=r.height*dpr;
  cx.setTransform(dpr,0,0,dpr,0,0);
}}
resize();
window.addEventListener('resize',function(){{ resize(); draw(); }});

var W=function(){{return cv.width/dpr;}};
var H=function(){{return cv.height/dpr;}};

// Bounds
var pos=DATA.positions, gates=DATA.gates, wires=DATA.wires;
var minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
pos.forEach(function(p){{
  if(p[0]<minX)minX=p[0]; if(p[0]>maxX)maxX=p[0];
  if(p[1]<minY)minY=p[1]; if(p[1]>maxY)maxY=p[1];
}});
var rangeX=maxX-minX||1, rangeY=maxY-minY||1;

function mapP(p){{
  var margin=60;
  var w=W(),h=H();
  var scaleX=(w-2*margin)/rangeX, scaleY=(h-2*margin)/rangeY;
  var scale=Math.min(scaleX,scaleY)*cam.zoom;
  var cx_=w/2+(p[0]-(minX+rangeX/2))*scale+cam.x*cam.zoom;
  var cy_=h/2+(p[1]-(minY+rangeY/2))*scale+cam.y*cam.zoom;
  return [cx_,cy_];
}}

function draw(){{
  var w=W(), h=H();
  cx.clearRect(0,0,w,h);

  // Row lines (from placement grid)
  var margin=60;
  var scaleX=(w-2*margin)/rangeX, scaleY=(h-2*margin)/rangeY;
  var scale=Math.min(scaleX,scaleY)*cam.zoom;
  cx.strokeStyle='rgba(255,255,255,0.02)';
  cx.lineWidth=0.5;
  var rowH=1.8*scale;
  if(rowH>5){{
    var startY=mapP([minX,minY])[1];
    var endY=mapP([minX,maxY])[1];
    for(var ry=startY;ry<=endY;ry+=rowH){{
      cx.beginPath();cx.moveTo(0,ry);cx.lineTo(w,ry);cx.stroke();
    }}
  }}

  // Congestion heatmap overlay
  if(showCongestion){{
    var cg=DATA.congestion;
    var maxCong=0;
    cg.forEach(function(row){{ row.forEach(function(v){{ if(v>maxCong)maxCong=v; }}); }});
    if(maxCong>0){{
      var gw=20;
      for(var gy=0;gy<gw;gy++){{
        for(var gx=0;gx<gw;gx++){{
          var val=cg[gy][gx]/maxCong;
          if(val<0.05) continue;
          var px=minX+(gx/gw)*rangeX;
          var py=minY+(gy/gw)*rangeY;
          var px2=minX+((gx+1)/gw)*rangeX;
          var py2=minY+((gy+1)/gw)*rangeY;
          var tl=mapP([px,py]), br=mapP([px2,py2]);

          var r_=Math.round(val*200+55);
          var g_=Math.round((1-val)*200+55);
          cx.fillStyle='rgba('+r_+','+g_+',60,'+Math.min(0.35,val*0.4)+')';
          cx.fillRect(tl[0],tl[1],br[0]-tl[0],br[1]-tl[1]);
        }}
      }}
    }}
  }}

  // Wires with Manhattan routing and metal layer coloring
  if(showWires){{
    wires.forEach(function(wire){{
      var a=mapP(pos[wire[0]]), b=mapP(pos[wire[1]]);
      // L-shape: horizontal first segment, then vertical
      var midX=a[0], midY=b[1];
      // Horizontal segment (M1 = blue)
      cx.strokeStyle='rgba(74,154,201,0.18)';
      cx.lineWidth=Math.max(0.5,1*cam.zoom);
      cx.beginPath();
      cx.moveTo(a[0],a[1]);
      cx.lineTo(b[0],a[1]);
      cx.stroke();
      // Vertical segment (M2 = green)
      cx.strokeStyle='rgba(74,201,105,0.18)';
      cx.beginPath();
      cx.moveTo(b[0],a[1]);
      cx.lineTo(b[0],b[1]);
      cx.stroke();
      // Via dot at corner
      if(Math.abs(a[0]-b[0])>2 && Math.abs(a[1]-b[1])>2){{
        cx.fillStyle='rgba(201,164,74,0.15)';
        cx.beginPath();cx.arc(b[0],a[1],1.5*cam.zoom,0,Math.PI*2);cx.fill();
      }}
    }});
  }}

  // Missing connections
  if(showMissing){{
    cx.setLineDash([5*cam.zoom,4*cam.zoom]);
    (DATA.missing||[]).forEach(function(m){{
      var ai=gates.indexOf(m.gate_a);
      var bi=gates.indexOf(m.gate_b);
      if(ai>=0&&bi>=0){{
        var a=mapP(pos[ai]),b=mapP(pos[bi]);
        cx.strokeStyle='rgba(201,164,74,0.5)';
        cx.lineWidth=1.5*cam.zoom;
        cx.beginPath();cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.stroke();
      }}
    }});
    cx.setLineDash([]);
  }}

  // Gates
  var gateW_=Math.max(4,Math.min(18,300/Math.sqrt(pos.length))*cam.zoom);
  var gateH_=gateW_*0.65;
  pos.forEach(function(p,i){{
    var mp=mapP(p);
    var type=DATA.gate_types[i]||'logic';
    var color=TYPE_COLORS[type]||'#888';
    var isHovered = hoveredGate===i;

    // Hover glow
    if(isHovered){{
      var grad=cx.createRadialGradient(mp[0],mp[1],gateW_,mp[0],mp[1],gateW_*3);
      grad.addColorStop(0,color+'30');
      grad.addColorStop(1,color+'00');
      cx.fillStyle=grad;
      cx.beginPath();cx.arc(mp[0],mp[1],gateW_*3,0,Math.PI*2);cx.fill();

      // Highlight connected wires
      cx.strokeStyle=color+'60';
      cx.lineWidth=2*cam.zoom;
      wires.forEach(function(wire){{
        if(wire[0]===i||wire[1]===i){{
          var a=mapP(pos[wire[0]]),b=mapP(pos[wire[1]]);
          cx.beginPath();cx.moveTo(a[0],a[1]);cx.lineTo(b[0],a[1]);cx.lineTo(b[0],b[1]);cx.stroke();
        }}
      }});
    }}

    // Gate body
    cx.fillStyle = isHovered?color:color+'c0';
    var rr=2*cam.zoom;
    cx.beginPath();
    cx.moveTo(mp[0]-gateW_/2+rr, mp[1]-gateH_/2);
    cx.lineTo(mp[0]+gateW_/2-rr, mp[1]-gateH_/2);
    cx.arcTo(mp[0]+gateW_/2, mp[1]-gateH_/2, mp[0]+gateW_/2, mp[1]-gateH_/2+rr, rr);
    cx.lineTo(mp[0]+gateW_/2, mp[1]+gateH_/2-rr);
    cx.arcTo(mp[0]+gateW_/2, mp[1]+gateH_/2, mp[0]+gateW_/2-rr, mp[1]+gateH_/2, rr);
    cx.lineTo(mp[0]-gateW_/2+rr, mp[1]+gateH_/2);
    cx.arcTo(mp[0]-gateW_/2, mp[1]+gateH_/2, mp[0]-gateW_/2, mp[1]+gateH_/2-rr, rr);
    cx.lineTo(mp[0]-gateW_/2, mp[1]-gateH_/2+rr);
    cx.arcTo(mp[0]-gateW_/2, mp[1]-gateH_/2, mp[0]-gateW_/2+rr, mp[1]-gateH_/2, rr);
    cx.closePath();
    cx.fill();

    // Pin dots
    if(gateW_>6){{
      cx.fillStyle='rgba(0,0,0,0.3)';
      cx.beginPath();cx.arc(mp[0]-gateW_/2,mp[1],1.5*cam.zoom,0,Math.PI*2);cx.fill();
      cx.beginPath();cx.arc(mp[0]+gateW_/2,mp[1],1.5*cam.zoom,0,Math.PI*2);cx.fill();
    }}

    // Label
    if(showLabels && pos.length<300 && gateW_>6){{
      cx.fillStyle=isHovered?'#fff':'#e8e4dc';
      cx.font=(isHovered?'600 ':'400 ')+Math.max(7,Math.min(11,gateW_*0.5))+'px -apple-system,sans-serif';
      cx.textAlign='center';
      cx.fillText(gates[i]||i, mp[0], mp[1]-gateH_/2-3*cam.zoom);
    }}
  }});
}}

// ═══ MOUSE INTERACTION ═══
cv.addEventListener('wheel',function(e){{
  e.preventDefault();
  var factor=e.deltaY<0?1.15:0.87;
  cam.zoom=Math.max(0.2,Math.min(10,cam.zoom*factor));
  zoomInd.textContent=Math.round(cam.zoom*100)+'%';
  draw();
}},{{passive:false}});

cv.addEventListener('mousedown',function(e){{
  drag.active=true; drag.sx=e.clientX; drag.sy=e.clientY; drag.cx=cam.x; drag.cy=cam.y;
}});
cv.addEventListener('mousemove',function(e){{
  if(drag.active){{
    cam.x=drag.cx+(e.clientX-drag.sx)/cam.zoom;
    cam.y=drag.cy+(e.clientY-drag.sy)/cam.zoom;
    draw();
    return;
  }}

  // Hit test
  var rect=cv.getBoundingClientRect();
  var mx=e.clientX-rect.left, my=e.clientY-rect.top;
  var gateW_=Math.max(4,Math.min(18,300/Math.sqrt(pos.length))*cam.zoom);
  var hit=-1;
  pos.forEach(function(p,i){{
    var mp=mapP(p);
    if(Math.abs(mp[0]-mx)<gateW_&&Math.abs(mp[1]-my)<gateW_) hit=i;
  }});

  if(hit!==hoveredGate){{
    hoveredGate=hit;
    draw();
    if(hit>=0){{
      var type=DATA.gate_types[hit]||'logic';
      var color=TYPE_COLORS[type]||'#888';
      var p=pos[hit];
      tooltip.innerHTML='<div class="tt-name">'+gates[hit]+'</div>'+
        '<div class="tt-type" style="background:'+color+'20;color:'+color+';">'+type+'</div>'+
        '<div class="tt-row"><span>Degree</span><span>'+DATA.degree[hit]+'</span></div>'+
        '<div class="tt-row"><span>Position</span><span>('+p[0].toFixed(1)+', '+p[1].toFixed(1)+')</span></div>'+
        '<div class="tt-row"><span>Index</span><span>'+hit+'</span></div>';
      tooltip.style.display='block';
      var mp=mapP(p);
      tooltip.style.left=Math.min(mp[0]+20, W()-220)+'px';
      tooltip.style.top=Math.max(10, mp[1]-30)+'px';
    }} else {{
      tooltip.style.display='none';
    }}
  }}
}});
window.addEventListener('mouseup',function(){{ drag.active=false; }});

// ═══ TOGGLE BUTTONS ═══
function toggleCongestion(){{ showCongestion=!showCongestion; document.getElementById('btn-congestion').classList.toggle('active',showCongestion); draw(); }}
function toggleWires(){{ showWires=!showWires; document.getElementById('btn-wires').classList.toggle('active',showWires); draw(); }}
function toggleLabels(){{ showLabels=!showLabels; document.getElementById('btn-labels').classList.toggle('active',showLabels); draw(); }}
function toggleMissing(){{ showMissing=!showMissing; document.getElementById('btn-missing').classList.toggle('active',showMissing); draw(); }}

// ═══ MISSING CONNECTIONS LIST ═══
(function(){{
  var d=document.getElementById('missing-list');
  if(DATA.missing&&DATA.missing.length>0){{
    DATA.missing.forEach(function(m,i){{
      d.innerHTML+='<div class="missing-card" style="animation:fadeIn 0.3s ease '+(i*0.08)+'s both;" onclick="highlightMissing(\''+m.gate_a+'\',\''+m.gate_b+'\')">'+
        '<div class="mc-icon"></div>'+
        '<div class="mc-gates">'+m.gate_a+' &#8596; '+m.gate_b+'</div>'+
        '<div class="mc-tension">T: '+m.tension.toFixed(1)+'</div></div>';
    }});
  }} else {{
    d.innerHTML='<div style="color:#4a9;font-size:0.75em;padding:8px 0;">No missing connections detected.</div>';
  }}
}})();

function highlightMissing(a,b){{
  var ai=gates.indexOf(a), bi=gates.indexOf(b);
  if(ai>=0&&bi>=0){{
    // Center view on the midpoint
    var pa=pos[ai], pb=pos[bi];
    var mid=[(pa[0]+pb[0])/2, (pa[1]+pb[1])/2];
    cam.x=-(mid[0]-(minX+rangeX/2));
    cam.y=-(mid[1]-(minY+rangeY/2));
    cam.zoom=2;
    zoomInd.textContent='200%';
    draw();
  }}
}}

function redesign(){{
  var netlist=document.getElementById('netlist-input').value;
  if(netlist.trim()){{
    alert('Netlist captured: '+netlist.split(';').length+' statements. Full redesign requires Python backend.');
  }}
}}

// Init with wires visible
showWires=true;
document.getElementById('btn-wires').classList.add('active');
showMissing=true;
document.getElementById('btn-missing').classList.add('active');
setTimeout(function(){{ resize(); draw(); }}, 50);
</script>
</body>
</html>'''


def netlist_report(netlist_text, title='Netlist Layout'):
    """Generate report from netlist text."""
    result = design_netlist(netlist_text)
    if 'error' in result:
        return f'<html><body><h1>Error</h1><p>{result["error"]}</p></body></html>'
    return design_report(result['gate_names'], [(int(w[0]), int(w[1])) for w in zip(
        [wires[0] for wires in []], [wires[1] for wires in []])], title=title)


def benchmark_report(n_gates=1000, connectivity=3):
    """Generate report for a random benchmark circuit."""
    import random
    random.seed(42)
    gates = [f'g{i}' for i in range(n_gates)]
    wires = set()
    for i in range(n_gates):
        for _ in range(connectivity):
            j = random.randint(0, n_gates - 1)
            if i != j:
                wires.add((min(i, j), max(i, j)))
    return design_report(gates, list(wires), title=f'{n_gates}-Gate Benchmark')
