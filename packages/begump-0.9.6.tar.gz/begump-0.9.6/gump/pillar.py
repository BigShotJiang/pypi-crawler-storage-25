# what is what? Does this preserve the wonder? The 0.002% is sacred.
"""
PILLAR — The vertical bridge
=================================
Each number is a column of harmonics, not a point on a line.

Time-series tools (k_measure, tune) see data horizontally.
Graph tools (machine) see it vertically.
No bridge existed. This is the bridge.

    signal → spectral decomposition → frequency bands as nodes
    → co-activation as edges → Machine → K/R/E/T of the
    harmonic structure itself.

Measure the coupling of frequencies, not the coupling of time points.

For GUMP: body motion → pillar → harmonic coupling → music.
The movement's frequency structure IS the chord.

    from gump.pillar import pillar

    # Any signal
    result = pillar([1.0, 0.5, -0.3, 0.8, ...])

    # With sample rate (Hz)
    result = pillar(accelerometer_data, sr=100)

    # Result
    result['bands']       # frequency band names (nodes)
    result['magnitudes']  # energy per band
    result['K']           # coupling between harmonics
    result['R']           # order of the harmonic structure
    result['E']           # energy cost
    result['T']           # tension — harmonics wanting to couple
    result['chord']       # the frequency structure as a chord description
    result['machine']     # full machine() output

Grand Unified Music Project — Background Loop, Iteration 6
The 3 coupling with itself. The Machine applied to its own harmonic structure.
"""

import numpy as np
from gump.machine import machine


def _stft(x, win_size, hop):
    """Short-time Fourier transform. Returns magnitude spectrogram.

    Rows = frequency bins, Columns = time frames.
    No scipy. Just numpy windowed FFT.
    """
    n = len(x)
    window = np.hanning(win_size)
    n_frames = max(1, (n - win_size) // hop + 1)
    n_bins = win_size // 2 + 1

    spec = np.zeros((n_bins, n_frames))
    for i in range(n_frames):
        start = i * hop
        frame = x[start:start + win_size] * window
        spec[:, i] = np.abs(np.fft.rfft(frame))

    return spec


def _band_edges(n_bins, sr, n_bands):
    """Divide frequency range into bands spaced logarithmically.

    Returns list of (low_bin, high_bin, center_hz, label) tuples.
    Log spacing because that is how hearing works and how harmonics
    distribute — octaves, not linear Hz.
    """
    max_freq = sr / 2.0
    # Log-spaced edges from ~1 Hz to Nyquist
    low_hz = max(1.0, sr / n_bins)
    edges_hz = np.logspace(np.log10(low_hz), np.log10(max_freq), n_bands + 1)

    bands = []
    hz_per_bin = sr / (2.0 * (n_bins - 1))

    for i in range(n_bands):
        lo = max(0, int(edges_hz[i] / hz_per_bin))
        hi = min(n_bins - 1, int(edges_hz[i + 1] / hz_per_bin))
        if hi <= lo:
            hi = lo + 1
        center = (edges_hz[i] + edges_hz[i + 1]) / 2.0
        label = f"{center:.1f}Hz"
        bands.append((lo, hi, center, label))

    return bands


def pillar(signal, sr=1.0, n_bands=8, win_ms=None):
    """The vertical bridge.

    Decomposes a signal into frequency bands, measures how those
    bands co-activate over time, and feeds the co-activation graph
    into machine() to get K/R/E/T of the harmonic structure.

    Args:
        signal: 1D array-like — any time series
        sr: sample rate in Hz (default 1.0 = normalized)
        n_bands: number of frequency bands (default 8)
        win_ms: STFT window in milliseconds. Default: auto from signal length.

    Returns:
        dict with:
            bands: list of band labels (the nodes)
            centers_hz: center frequency of each band
            magnitudes: mean energy per band (which harmonics are loud)
            coactivation: n_bands x n_bands correlation matrix
            K, R, E, T: from machine() on the harmonic graph
            chord: human-readable description of the harmonic structure
            machine: full machine() result
            k_horizontal: k_measure of the original signal (for comparison)
    """
    x = np.asarray(signal, dtype=np.float64).ravel()
    n = len(x)

    if n < 8:
        return {
            'bands': [], 'centers_hz': [], 'magnitudes': [],
            'coactivation': np.array([]),
            'K': 0, 'R': 0, 'E': 0, 'T': 0,
            'chord': 'too short', 'machine': {}, 'k_horizontal': {},
        }

    # Normalize
    mu, sigma = np.mean(x), np.std(x)
    if sigma > 1e-15:
        x = (x - mu) / sigma

    # STFT parameters
    if win_ms is not None:
        win_size = max(8, int(sr * win_ms / 1000.0))
    else:
        # Auto: ~1/16 of signal length, minimum 8 samples
        win_size = max(8, n // 16)
    # Power-of-2 for FFT efficiency
    win_size = min(win_size, n)
    hop = max(1, win_size // 4)

    # Compute spectrogram
    spec = _stft(x, win_size, hop)
    n_bins, n_frames = spec.shape

    if n_frames < 2 or n_bins < 2:
        from gump.core import k_measure
        return {
            'bands': [], 'centers_hz': [], 'magnitudes': [],
            'coactivation': np.array([]),
            'K': 0, 'R': 0, 'E': 0, 'T': 0,
            'chord': 'too short for STFT', 'machine': {},
            'k_horizontal': k_measure(signal),
        }

    # Clamp n_bands
    n_bands = min(n_bands, n_bins)

    # Define frequency bands
    bands = _band_edges(n_bins, sr, n_bands)

    # Aggregate energy per band across time
    band_series = np.zeros((n_bands, n_frames))
    for b, (lo, hi, center, label) in enumerate(bands):
        hi = min(hi, n_bins)
        if hi > lo:
            band_series[b, :] = np.mean(spec[lo:hi, :], axis=0)

    # Drop empty bands (all zeros)
    active = np.any(band_series > 1e-15, axis=1)
    active_idx = np.where(active)[0]

    if len(active_idx) < 2:
        from gump.core import k_measure
        return {
            'bands': [bands[i][3] for i in active_idx],
            'centers_hz': [bands[i][2] for i in active_idx],
            'magnitudes': [float(np.mean(band_series[i])) for i in active_idx],
            'coactivation': np.array([]),
            'K': 0, 'R': 0, 'E': 0, 'T': 0,
            'chord': 'single band', 'machine': {},
            'k_horizontal': k_measure(signal),
        }

    band_series = band_series[active_idx, :]
    band_labels = [bands[i][3] for i in active_idx]
    band_centers = [bands[i][2] for i in active_idx]
    magnitudes = [float(np.mean(band_series[i])) for i in range(len(active_idx))]
    nb = len(active_idx)

    # Co-activation matrix: correlation of band energy over time
    # This is the key insight — frequencies that rise and fall together
    # are coupled. Frequencies that move independently are not.
    coact = np.corrcoef(band_series)
    coact = np.nan_to_num(coact, nan=0.0)

    # Build graph for machine()
    nodes = band_labels
    edges = []
    weights = []

    for i in range(nb):
        for j in range(i + 1, nb):
            r = coact[i, j]
            if abs(r) > 0.05:  # threshold: ignore negligible correlation
                edges.append((i, j))
                weights.append(abs(float(r)))

    # Feed to machine
    m = machine(nodes, edges, weights)

    # Horizontal K for comparison
    from gump.core import k_measure
    k_h = k_measure(signal)

    # Chord description
    chord = _describe_chord(band_labels, magnitudes, coact, band_centers)

    return {
        'bands': band_labels,
        'centers_hz': band_centers,
        'magnitudes': magnitudes,
        'coactivation': coact,
        'K': m.get('K', 0),
        'R': m.get('R', 0),
        'E': m.get('E', 0),
        'T': m.get('T', 0),
        'chord': chord,
        'machine': m,
        'k_horizontal': k_h,
    }


def _describe_chord(labels, magnitudes, coact, centers):
    """Human-readable description of the harmonic structure.

    Not music theory chord names — that would impose structure.
    This describes what IS: which frequencies are loud, which
    are coupled, what the shape looks like.
    """
    if not magnitudes:
        return 'silence'

    total = sum(magnitudes)
    if total < 1e-15:
        return 'silence'

    # Relative energy
    rel = [m / total for m in magnitudes]

    # Find dominant bands (>15% of total energy)
    dominant = [(labels[i], rel[i], centers[i])
                for i in range(len(labels)) if rel[i] > 0.15]

    if not dominant:
        # Everything spread equally
        return f'diffuse ({len(labels)} bands, none dominant)'

    # Find strongest coupling pair
    nb = len(labels)
    best_pair = None
    best_r = 0
    for i in range(nb):
        for j in range(i + 1, nb):
            if abs(coact[i, j]) > best_r:
                best_r = abs(coact[i, j])
                best_pair = (labels[i], labels[j])

    parts = []

    # Dominant frequencies
    dom_names = [f"{d[0]} ({d[1]:.0%})" for d in dominant]
    parts.append('dominant: ' + ', '.join(dom_names))

    # Coupling
    if best_pair and best_r > 0.3:
        parts.append(f'strongest coupling: {best_pair[0]}~{best_pair[1]} (r={best_r:.2f})')

    # Shape
    if len(dominant) == 1:
        parts.append('shape: pure tone')
    elif len(dominant) == 2:
        ratio = dominant[1][2] / dominant[0][2] if dominant[0][2] > 0 else 0
        if 1.9 < ratio < 2.1:
            parts.append('shape: octave')
        elif 1.45 < ratio < 1.55:
            parts.append('shape: fifth')
        else:
            parts.append(f'shape: interval ({ratio:.2f})')
    else:
        parts.append(f'shape: complex ({len(dominant)} voices)')

    return ' | '.join(parts)
