#include <stdio.h>
#include <string.h>
#include <math.h>
#define MR 500
#define TB 3.8f
#define PI 3.14159265f
typedef struct{float x,y,z;}V;
static const float HY[26]={0.62,0,0.50,0.10,0.12,0.88,0.50,0.40,0.88,0,0.08,0.84,0.74,0.24,0,0.64,0.26,0.06,0.36,0.38,0,0.84,0.85,0,0.58,0};
static const float HX[26]={1.42,0,0.70,1.01,1.51,1.13,0.57,1.00,1.08,0,1.16,1.21,1.45,0.67,0,0.57,1.11,0.98,0.77,0.83,0,1.06,1.08,0,0.69,0};
static unsigned RS=42;
static float rf(){RS=RS*1103515245+12345;return(float)((RS>>16)&0x7FFF)/32768.0f;}

float fold(const char*sq,int n,V*c){
    float erg=2.0f*powf((float)n,0.38f);
    c[0]=(V){0,0,0};RS=42;
    for(int i=1;i<n;i++){
        float t=rf()*2*PI,p=rf()*PI;
        c[i]=(V){c[i-1].x+sinf(p)*cosf(t)*2,c[i-1].y+sinf(p)*sinf(t)*2,c[i-1].z+cosf(p)*2};
        V cn={0,0,0};for(int j=0;j<=i;j++){cn.x+=c[j].x;cn.y+=c[j].y;cn.z+=c[j].z;}
        float inv=1.0f/(i+1);cn.x*=inv;cn.y*=inv;cn.z*=inv;
        float dx=c[i].x-cn.x,dy=c[i].y-cn.y,dz=c[i].z-cn.z,d=sqrtf(dx*dx+dy*dy+dz*dz);
        if(d>erg*0.95f){float r=erg*0.9f/d;c[i]=(V){cn.x+dx*r,cn.y+dy*r,cn.z+dz*r};}
    }
    V cn={0,0,0};float inv=1.0f/n;for(int i=0;i<n;i++){cn.x+=c[i].x;cn.y+=c[i].y;cn.z+=c[i].z;}
    cn.x*=inv;cn.y*=inv;cn.z*=inv;for(int i=0;i<n;i++){c[i].x-=cn.x;c[i].y-=cn.y;c[i].z-=cn.z;}
    cn=(V){0,0,0};for(int i=0;i<n;i++){cn.x+=c[i].x;cn.y+=c[i].y;cn.z+=c[i].z;}
    cn.x*=inv;cn.y*=inv;cn.z*=inv;
    for(int i=0;i<n;i++){float tx=cn.x-c[i].x,ty=cn.y-c[i].y,tz=cn.z-c[i].z,cd=sqrtf(tx*tx+ty*ty+tz*tz);
        if(cd>0.1f){float s=HY[sq[i]-'A']*erg*0.25f/cd;c[i].x+=tx*s;c[i].y+=ty*s;c[i].z+=tz*s;}}
    cn=(V){0,0,0};for(int i=0;i<n;i++){cn.x+=c[i].x;cn.y+=c[i].y;cn.z+=c[i].z;}
    cn.x*=inv;cn.y*=inv;cn.z*=inv;for(int i=0;i<n;i++){c[i].x-=cn.x;c[i].y-=cn.y;c[i].z-=cn.z;}
    float rg2=0;for(int i=0;i<n;i++)rg2+=c[i].x*c[i].x+c[i].y*c[i].y+c[i].z*c[i].z;
    float rg=sqrtf(rg2/n);if(rg>0.1f){float s=erg/rg;for(int i=0;i<n;i++){c[i].x*=s;c[i].y*=s;c[i].z*=s;}}
    
    char hm[MR];for(int i=0;i<n;i++)hm[i]=(i>=4&&HX[sq[i]-'A']>1.0f);
    int nw=n<40?14:n<80?18:22,sw=(int)(nw*0.6f);
    
    for(int w=0;w<sw;w++){
        for(int i=1;i<n;i++){float dx=c[i].x-c[i-1].x,dy=c[i].y-c[i-1].y,dz=c[i].z-c[i-1].z,d=sqrtf(dx*dx+dy*dy+dz*dz);
            if(d>0.1f){float f=(d-TB)*0.3f/d;c[i].x-=dx*f;c[i].y-=dy*f;c[i].z-=dz*f;}
            if(hm[i]){float hx=c[i].x-c[i-4].x,hy=c[i].y-c[i-4].y,hz=c[i].z-c[i-4].z,hd=sqrtf(hx*hx+hy*hy+hz*hz);
                if(hd>0.1f){float f=(hd-5.4f)*0.1f*(HX[sq[i]-'A']-0.9f)/hd;c[i].x-=hx*f;c[i].y-=hy*f;c[i].z-=hz*f;}}}
        for(int i=n-2;i>=0;i--){float dx=c[i].x-c[i+1].x,dy=c[i].y-c[i+1].y,dz=c[i].z-c[i+1].z,d=sqrtf(dx*dx+dy*dy+dz*dz);
            if(d>0.1f){float f=(d-TB)*0.15f/d;c[i].x-=dx*f;c[i].y-=dy*f;c[i].z-=dz*f;}}
        for(int i=0;i<n;i++){int jm=i+8;if(jm>n)jm=n;for(int j=i+2;j<jm;j++){
            float dx=c[j].x-c[i].x,dy=c[j].y-c[i].y,dz=c[j].z-c[i].z,d=sqrtf(dx*dx+dy*dy+dz*dz);
            if(d>0.1f&&d<2.8f){float ol=(2.8f-d)*0.125f/d;c[i].x-=dx*ol;c[i].y-=dy*ol;c[i].z-=dz*ol;c[j].x+=dx*ol;c[j].y+=dy*ol;c[j].z+=dz*ol;}}}
    }
    for(int w=0;w<nw-sw;w++){
        cn=(V){0,0,0};for(int i=0;i<n;i++){cn.x+=c[i].x;cn.y+=c[i].y;cn.z+=c[i].z;}
        cn.x*=inv;cn.y*=inv;cn.z*=inv;
        rg2=0;float md=0;for(int i=0;i<n;i++){float dx=c[i].x-cn.x,dy=c[i].y-cn.y,dz=c[i].z-cn.z;rg2+=dx*dx+dy*dy+dz*dz;md+=sqrtf(dx*dx+dy*dy+dz*dz);}
        rg=sqrtf(rg2*inv);md*=inv;float rr=rg/erg,rgf=0;
        if(rr>1.15f)rgf=(rr-1)*0.06f;else if(rr<0.85f)rgf=-(1-rr)*0.06f;
        for(int i=0;i<n;i++){float tx=cn.x-c[i].x,ty=cn.y-c[i].y,tz=cn.z-c[i].z,cd=sqrtf(tx*tx+ty*ty+tz*tz);if(cd<0.1f)continue;
            if(rgf!=0){float s=rgf/cd;c[i].x+=tx*s;c[i].y+=ty*s;c[i].z+=tz*s;}
            float hi=HY[sq[i]-'A'];if(cd>md&&hi>0.6f){float s=hi*0.04f/cd;c[i].x+=tx*s;c[i].y+=ty*s;c[i].z+=tz*s;}
            else if(cd<=md&&hi<0.15f){float s=0.02f/cd;c[i].x-=tx*s;c[i].y-=ty*s;c[i].z-=tz*s;}}
        for(int i=1;i<n;i++){float dx=c[i].x-c[i-1].x,dy=c[i].y-c[i-1].y,dz=c[i].z-c[i-1].z,d=sqrtf(dx*dx+dy*dy+dz*dz);
            if(d>0.1f){float f=(d-TB)*0.1f/d;c[i].x-=dx*f;c[i].y-=dy*f;c[i].z-=dz*f;}}
        for(int i=n-2;i>=0;i--){float dx=c[i].x-c[i+1].x,dy=c[i].y-c[i+1].y,dz=c[i].z-c[i+1].z,d=sqrtf(dx*dx+dy*dy+dz*dz);
            if(d>0.1f){float f=(d-TB)*0.05f/d;c[i].x-=dx*f;c[i].y-=dy*f;c[i].z-=dz*f;}}
        for(int i=0;i<n;i++){int jm=i+6;if(jm>n)jm=n;for(int j=i+2;j<jm;j++){
            float dx=c[j].x-c[i].x,dy=c[j].y-c[i].y,dz=c[j].z-c[i].z,d=sqrtf(dx*dx+dy*dy+dz*dz);
            if(d>0.1f&&d<3.0f){float ol=(3.0f-d)*0.06f/d;c[i].x-=dx*ol;c[i].y-=dy*ol;c[i].z-=dz*ol;c[j].x+=dx*ol;c[j].y+=dy*ol;c[j].z+=dz*ol;}}}
    }
    cn=(V){0,0,0};for(int i=0;i<n;i++){cn.x+=c[i].x;cn.y+=c[i].y;cn.z+=c[i].z;}
    cn.x*=inv;cn.y*=inv;cn.z*=inv;
    rg2=0;for(int i=0;i<n;i++){float dx=c[i].x-cn.x,dy=c[i].y-cn.y,dz=c[i].z-cn.z;rg2+=dx*dx+dy*dy+dz*dz;}
    return sqrtf(rg2*inv);
}

int main(int argc, char **argv){
    if(argc!=2){fprintf(stderr,"Usage: %s <sequence>\n",argv[0]);return 1;}
    V coords[MR]; int n=strlen(argv[1]);
    if(n<3||n>=MR){fprintf(stderr,"Sequence must be 3-%d residues\n",MR-1);return 1;}
    printf("%.1f\n",fold(argv[1],n,coords));
    return 0;
}
