"""Data files bundled with begump."""
import os
import json

_DATA_DIR = os.path.dirname(__file__)


def gnomad_index():
    """Load the gnomAD population frequency index (18,272 variants, 15 genes)."""
    path = os.path.join(_DATA_DIR, 'gnomad_index.json')
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f)


def alphafold_contacts():
    """Load AlphaFold CA-CA contact maps (22 genes)."""
    path = os.path.join(_DATA_DIR, 'alphafold_contacts.json')
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f)
