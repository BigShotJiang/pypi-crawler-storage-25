"""ACCORD — Regulatory gap analysis."""

def scan_regulations(rules, business_state=None):
    """Find compliance gaps. rules: list of {id, requirement, category}."""
    if not rules: return {'error':'No rules'}
    biz = {}
    for b in (business_state or []):
        biz.setdefault(b.get('category',''), []).append(b)
    gaps, covered = [], 0
    for rule in rules:
        cat = rule.get('category','')
        if biz.get(cat) and any(m.get('status')=='compliant' for m in biz[cat]):
            covered += 1
        else:
            gaps.append({'rule_id':rule.get('id','?'),'requirement':rule.get('requirement',''),
                         'category':cat,'priority':'HIGH' if 'must' in rule.get('requirement','').lower() else 'MEDIUM'})
    K = covered/len(rules) if rules else 0
    return {'K_compliance':round(K,4),'total_rules':len(rules),'covered':covered,'gaps':gaps,'n_gaps':len(gaps)}
