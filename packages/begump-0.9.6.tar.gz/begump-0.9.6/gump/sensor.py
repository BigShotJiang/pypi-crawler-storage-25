"""SENSOR — K/R/E/T for time series with windowed analysis."""
import numpy as np
from gump.core import k_measure

def measure_kret(data, sample_rate=1.0):
    """Measure K/R/E/T for a time series."""
    return k_measure(data, sample_rate)

def scan(data, window=100, step=None):
    """Sliding window K/R/E/T scan."""
    x = np.asarray(data, dtype=np.float64).ravel()
    if step is None: step = max(1, window // 4)
    return [dict(k_measure(x[i:i+window]), position=i) for i in range(0, len(x)-window+1, step)]

def detect_regime_change(data, window=100, threshold=0.3):
    """Find where K changes significantly."""
    tl = scan(data, window)
    return [{'position': tl[i]['position'], 'delta_K': round(abs(tl[i]['K']-tl[i-1]['K']),4)}
            for i in range(1, len(tl)) if abs(tl[i]['K']-tl[i-1]['K']) > threshold]


class UniversalSensor:
    """Streaming K/R/E/T sensor for any named metric."""

    def __init__(self, name='sensor'):
        self.name = name
        self.data = []

    def feed(self, values):
        """Append one or more values."""
        if isinstance(values, (list, tuple)):
            self.data.extend(float(v) for v in values)
        else:
            self.data.append(float(values))

    def diagnose(self):
        """K/R/E/T diagnosis of accumulated data."""
        if len(self.data) < 3:
            return {'K': 0, 'R': 0, 'T': 0, 'regime': 'unknown'}
        result = k_measure(self.data)
        K = result.get('K', 0)
        R = result.get('R', 0)
        T = result.get('T', 0)
        # Regime classification
        if K > 0.8 and R > 0.6:
            regime = 'locked'
        elif K > 0.5 and R > 0.3:
            regime = 'coherent'
        elif K > 0.3:
            regime = 'transitional'
        else:
            regime = 'diffuse'
        # Anomaly detection
        arr = np.array(self.data)
        mu, sigma = np.mean(arr), np.std(arr)
        anomalies = []
        if sigma > 0:
            for i, v in enumerate(self.data):
                z = abs(v - mu) / sigma
                if z > 3:
                    anomalies.append({'index': i, 'value': v, 'zscore': round(z, 2)})
        return {'K': round(K, 4), 'R': round(R, 4), 'T': round(T, 4),
                'regime': regime, 'anomalies': anomalies}
