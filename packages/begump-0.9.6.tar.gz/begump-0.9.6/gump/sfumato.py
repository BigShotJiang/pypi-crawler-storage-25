"""SFUMATO — Compression via coupling."""
import numpy as np, zlib, json

def compress(data):
    """Compress data. Strings: zlib. Numbers: DCT+zlib."""
    if isinstance(data, str):
        raw = data.encode('utf-8'); c = zlib.compress(raw, 9)
        return {'compressed':c,'original_size':len(raw),'compressed_size':len(c),
                'ratio':round(len(raw)/max(1,len(c)),2),'method':'zlib'}
    x = np.asarray(data, dtype=np.float64).ravel(); n = len(x)
    dct = np.fft.rfft(x).real
    thresh = np.max(np.abs(dct))*0.01
    sparse = [(i,float(v)) for i,v in enumerate(dct) if abs(v)>thresh]
    payload = json.dumps({'n':n,'coeffs':sparse}).encode('utf-8')
    c = zlib.compress(payload, 9)
    return {'compressed':c,'original_size':n*8,'compressed_size':len(c),
            'ratio':round(n*8/max(1,len(c)),2),'coefficients_kept':len(sparse),'method':'dct+zlib'}

def decompress(result):
    """Decompress."""
    data = zlib.decompress(result['compressed'])
    if result.get('method')=='zlib': return data.decode('utf-8')
    p = json.loads(data.decode('utf-8')); dct = np.zeros(p['n']//2+1)
    for i,v in p['coeffs']: dct[i] = v
    return np.fft.irfft(dct, n=p['n']).tolist()
