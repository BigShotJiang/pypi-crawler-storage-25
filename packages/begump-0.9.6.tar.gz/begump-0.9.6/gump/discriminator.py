"""
Discriminator — Real coupling has a Landauer cost. Correlation is free.
=========================================================================

    from gump.discriminator import test, test_directed

    # Are these two signals coupled or just correlated?
    result = test(signal_a, signal_b)
    print(result['verdict'])  # COUPLED | CORRELATED | FORCED | INDEPENDENT

    # Who drives whom?
    result = test_directed(series_a, series_b)
    print(result['direction'])  # A→B | B→A | MUTUAL | NONE

The test: shuffle one signal. If the relationship survives shuffling,
it's real. If it doesn't, it was correlation. The Landauer cost of
the real relationship is the energy difference.

Five verdicts:
    COUPLED     — real signal, energy exchanged, p < 0.01
    CORRELATED  — high synchronization but no energy (phantom)
    FORCED      — energy flows but systems resist (low sync)
    COMMON_DRIVER — real relationship, but neither drives the other
    INDEPENDENT — nothing there
"""

import numpy as np

KT_LN2 = 2.87e-21  # Joules per bit erased at 300K
PHI = (1 + 5 ** 0.5) / 2


def test(a, b, n_shuffles=500, seed=137):
    """Test whether two signals are coupled or merely correlated.

    Args:
        a, b: array-like signals (same length)
        n_shuffles: number of random shuffles for null distribution
        seed: random seed for reproducibility

    Returns dict with:
        verdict: COUPLED | CORRELATED | FORCED | INDEPENDENT
        R: synchronization (0-1)
        E_bits: Landauer cost in bits (real coupling only)
        p_value: probability of seeing this R by chance
    """
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    n = min(len(a), len(b))
    a, b = a[:n], b[:n]

    if n < 10:
        return {'verdict': 'INDEPENDENT', 'R': 0, 'E_bits': 0, 'p_value': 1, 'n': n}

    # Observed synchronization
    R = _sync(a, b)

    # Observed mutual information
    MI = _mutual_info(a, b)

    # Null distribution: shuffle a, keep b
    rng = np.random.RandomState(seed)
    R_null = np.empty(n_shuffles)
    MI_null = np.empty(n_shuffles)
    a_shuf = a.copy()

    for i in range(n_shuffles):
        rng.shuffle(a_shuf)
        R_null[i] = _sync(a_shuf, b)
        MI_null[i] = _mutual_info(a_shuf, b)

    # Signal above noise
    R_excess = max(0, R - np.mean(R_null))
    MI_excess = max(0, MI - np.mean(MI_null))
    p_value = float(np.mean(R_null >= R))

    # Landauer cost: only real information exchange has a cost
    E_bits = MI_excess
    E_joules = E_bits * KT_LN2 * n

    # Verdict
    real = p_value < 0.01 and E_bits > 0.1
    high_R = R > 1 / (2 * PHI)

    if real and high_R:
        verdict = 'COUPLED'
    elif real and not high_R:
        verdict = 'FORCED'
    elif not real and high_R:
        verdict = 'CORRELATED'
    else:
        verdict = 'INDEPENDENT'

    return {
        'verdict': verdict,
        'R': round(float(R), 4),
        'R_excess': round(float(R_excess), 4),
        'E_bits': round(float(E_bits), 4),
        'E_joules': float(E_joules),
        'p_value': round(float(p_value), 4),
        'n': n,
    }


def test_directed(a, b, lag=1, n_shuffles=500, seed=137):
    """Test causal direction: does A drive B, or B drive A?

    Uses transfer entropy — the bits erased in B's future
    due to A's past influence.

    Returns dict with:
        direction: A→B | B→A | MUTUAL | NONE
        TE_AB: transfer entropy A to B (bits)
        TE_BA: transfer entropy B to A (bits)
    """
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    n = min(len(a), len(b))
    a, b = a[:n], b[:n]

    if n < 20:
        return {'direction': 'NONE', 'TE_AB': 0, 'TE_BA': 0, 'n': n}

    # Normalize to [0, 1]
    a_n = (a - a.min()) / (a.max() - a.min() + 1e-15)
    b_n = (b - b.min()) / (b.max() - b.min() + 1e-15)

    te_ab = _transfer_entropy(a_n, b_n, lag)
    te_ba = _transfer_entropy(b_n, a_n, lag)

    # Null distribution
    rng = np.random.RandomState(seed)
    te_ab_null = np.empty(n_shuffles)
    te_ba_null = np.empty(n_shuffles)
    a_shuf = a_n.copy()

    for i in range(n_shuffles):
        rng.shuffle(a_shuf)
        te_ab_null[i] = _transfer_entropy(a_shuf, b_n, lag)
        te_ba_null[i] = _transfer_entropy(b_n, a_shuf, lag)

    te_ab_real = max(0, te_ab - np.mean(te_ab_null))
    te_ba_real = max(0, te_ba - np.mean(te_ba_null))
    p_ab = float(np.mean(te_ab_null >= te_ab))
    p_ba = float(np.mean(te_ba_null >= te_ba))

    ab = p_ab < 0.01 and te_ab_real > 0.01
    ba = p_ba < 0.01 and te_ba_real > 0.01

    if ab and ba:
        direction = 'MUTUAL'
    elif ab:
        direction = 'A→B'
    elif ba:
        direction = 'B→A'
    else:
        direction = 'NONE'

    return {
        'direction': direction,
        'TE_AB': round(float(te_ab_real), 4),
        'TE_BA': round(float(te_ba_real), 4),
        'p_AB': round(float(p_ab), 4),
        'p_BA': round(float(p_ba), 4),
        'n': n,
    }


def quick(a, b):
    """One-line verdict."""
    r = test(a, b)
    return f"{r['verdict']} (R={r['R']:.3f}, E={r['E_bits']:.2f} bits, p={r['p_value']:.3f})"


# ═══ Internal functions ═══

def _sync(a, b):
    """Synchronization between two signals."""
    a_n = (a - np.mean(a)) / (np.std(a) + 1e-15)
    b_n = (b - np.mean(b)) / (np.std(b) + 1e-15)
    return float(abs(np.mean(a_n * b_n)))


def _entropy(x, bins=32):
    """Shannon entropy."""
    counts, _ = np.histogram(x, bins=bins)
    p = counts / counts.sum()
    p = p[p > 0]
    return float(-np.sum(p * np.log2(p)))


def _mutual_info(x, y, bins=32):
    """Mutual information I(X;Y)."""
    hx = _entropy(x, bins)
    hy = _entropy(y, bins)
    counts, _, _ = np.histogram2d(x, y, bins=bins)
    p = counts.flatten() / counts.sum()
    p = p[p > 0]
    hxy = float(-np.sum(p * np.log2(p)))
    return max(0, hx + hy - hxy)


def _transfer_entropy(source, target, lag=1, bins=16):
    """Transfer entropy TE(source → target)."""
    n = len(target) - lag
    if n < 10:
        return 0.0
    t_past = target[:n]
    t_future = target[lag:lag + n]
    s_past = source[:n]
    h_cond = _conditional_entropy(t_future, t_past, bins)
    joint = t_past * bins + s_past
    joint = (joint - joint.min()) / (joint.max() - joint.min() + 1e-15)
    h_cond_both = _conditional_entropy(t_future, joint, bins)
    return max(0.0, h_cond - h_cond_both)


def _conditional_entropy(x, y, bins=32):
    """H(X|Y) = H(X,Y) - H(Y)."""
    counts, _, _ = np.histogram2d(x, y, bins=bins)
    p = counts.flatten() / counts.sum()
    p = p[p > 0]
    hxy = float(-np.sum(p * np.log2(p)))
    hy = _entropy(y, bins)
    return hxy - hy
