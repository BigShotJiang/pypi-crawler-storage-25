// GUMP Secure Enclave Signer
// Hardware-backed ECC P-256 signatures. Private key never leaves the chip.
// Usage: swift secure_sign.swift [generate|sign <hex>|verify <hex> <sig>|pubkey]

import Foundation
import CryptoKit

let keyTag = "com.begump.secure-signer"

func getOrCreateKey() -> SecureEnclave.P256.Signing.PrivateKey {
    // Try to load existing key
    let query: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrAccount as String: keyTag,
        kSecReturnData as String: true
    ]

    var item: CFTypeRef?
    let status = SecItemCopyMatching(query as CFDictionary, &item)

    if status == errSecSuccess, let data = item as? Data {
        do {
            return try SecureEnclave.P256.Signing.PrivateKey(
                dataRepresentation: data
            )
        } catch {
            // Key corrupted, regenerate
        }
    }

    // Generate new key in Secure Enclave
    let key = try! SecureEnclave.P256.Signing.PrivateKey()
    let keyData = key.dataRepresentation

    // Store the key handle
    let addQuery: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrAccount as String: keyTag,
        kSecValueData as String: keyData
    ]
    SecItemDelete(addQuery as CFDictionary) // remove old if exists
    SecItemAdd(addQuery as CFDictionary, nil)

    return key
}

let args = CommandLine.arguments

guard args.count >= 2 else {
    print("usage: secure_sign [generate|sign <hex>|verify <hex> <sig_hex>|pubkey]")
    exit(1)
}

switch args[1] {
case "generate":
    let key = getOrCreateKey()
    let pub = key.publicKey.compactRepresentation!
    print("OK")
    print("pubkey:\(pub.base64EncodedString())")

case "pubkey":
    let key = getOrCreateKey()
    let pub = key.publicKey.compactRepresentation!
    print(pub.base64EncodedString())

case "sign":
    guard args.count >= 3 else { print("error:need data"); exit(1) }
    let data = args[2].data(using: .utf8)!
    let key = getOrCreateKey()
    let sig = try! key.signature(for: data)
    print(sig.rawRepresentation.base64EncodedString())

case "verify":
    guard args.count >= 4 else { print("error:need data and sig"); exit(1) }
    let data = args[2].data(using: .utf8)!
    let sigData = Data(base64Encoded: args[3])!
    let key = getOrCreateKey()
    let sig = try! P256.Signing.ECDSASignature(rawRepresentation: sigData)
    let valid = key.publicKey.isValidSignature(sig, for: data)
    print(valid ? "VALID" : "INVALID")

default:
    print("error:unknown command \(args[1])")
    exit(1)
}
