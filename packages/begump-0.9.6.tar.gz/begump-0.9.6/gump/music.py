"""
GUMP MUSIC — Thermodynamic music theory
===========================================
Every interval, chord, rhythm, and progression has a Landauer cost.
Consonance = energy efficiency. Dissonance = expensive.
The body's energy budget determines which music is affordable.

    from gump.music import (analyze_melody, analyze_chord, analyze_progression,
                             suggest_next, groove_cost, composer_efficiency,
                             key_from_notes, energy_profile)
"""
import numpy as np
from math import log, gcd, sqrt
from gump.core import _TensionDetector, PHI

NOTES = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B']
NOTE_ALIASES = {'Db': 'C#', 'D#': 'Eb', 'Gb': 'F#', 'G#': 'Ab', 'A#': 'Bb'}

# Just intonation ratios
JI = {
    0: (1, 1), 1: (16, 15), 2: (9, 8), 3: (6, 5), 4: (5, 4), 5: (4, 3),
    6: (45, 32), 7: (3, 2), 8: (8, 5), 9: (5, 3), 10: (9, 5), 11: (15, 8),
}

# Chord templates (semitone intervals from root)
CHORDS = {
    'major': [0, 4, 7],
    'minor': [0, 3, 7],
    'dim': [0, 3, 6],
    'aug': [0, 4, 8],
    'dom7': [0, 4, 7, 10],
    'maj7': [0, 4, 7, 11],
    'min7': [0, 3, 7, 10],
    'dim7': [0, 3, 6, 9],
    'sus2': [0, 2, 7],
    'sus4': [0, 5, 7],
    'power': [0, 7],
    'add9': [0, 4, 7, 14],
}

MODES = {
    'major': [0, 2, 4, 5, 7, 9, 11],
    'minor': [0, 2, 3, 5, 7, 8, 10],
    'dorian': [0, 2, 3, 5, 7, 9, 10],
    'phrygian': [0, 1, 3, 5, 7, 8, 10],
    'lydian': [0, 2, 4, 6, 7, 9, 11],
    'mixolydian': [0, 2, 4, 5, 7, 9, 10],
    'pentatonic': [0, 2, 4, 7, 9],
    'blues': [0, 3, 5, 6, 7, 10],
}


def _note_to_pc(note):
    """Convert note name to pitch class (0-11)."""
    if isinstance(note, int):
        return note % 12
    note = str(note).strip()
    name = note[0].upper() + note[1:] if len(note) > 1 else note.upper()
    # Strip octave number
    while name and name[-1].isdigit():
        name = name[:-1]
    if name in NOTE_ALIASES:
        name = NOTE_ALIASES[name]
    try:
        return NOTES.index(name)
    except ValueError:
        return 0


def _interval_cost(semitones):
    semi = abs(int(semitones)) % 12
    p, q = JI.get(semi, (16, 15))
    g = gcd(p, q)
    return log(max(p // g, 1)) + log(max(q // g, 1))


def analyze_melody(notes):
    """Full melodic analysis with energy profile.

    Args:
        notes: list of MIDI numbers, note names, or pitch classes
    """
    if not notes or len(notes) < 2:
        return {'error': 'Need at least 2 notes'}

    # Convert to MIDI if needed
    if isinstance(notes[0], str):
        midi = []
        for n in notes:
            pc = _note_to_pc(n)
            # Guess octave from context
            octave = 4
            name = str(n).strip()
            if name and name[-1].isdigit():
                octave = int(name[-1])
            midi.append(pc + (octave + 1) * 12)
        notes = midi

    n = len(notes)
    costs = []
    intervals_semitones = []
    for i in range(n - 1):
        semi = abs(notes[i + 1] - notes[i])
        costs.append(_interval_cost(semi))
        intervals_semitones.append(semi % 12)

    total = sum(costs)
    avg = total / len(costs)

    # Dynamic range
    nonzero = [c for c in costs if c > 0.01]
    if nonzero:
        dynamic_range = max(nonzero) / min(nonzero)
    else:
        dynamic_range = 1.0

    # Pitch classes
    pcs = sorted(set(n % 12 for n in notes))

    # Interval distribution
    interval_counts = {}
    interval_names = ['P1', 'm2', 'M2', 'm3', 'M3', 'P4', 'TT', 'P5', 'm6', 'M6', 'm7', 'M7']
    for semi in intervals_semitones:
        name = interval_names[semi] if semi < 12 else f'{semi}st'
        interval_counts[name] = interval_counts.get(name, 0) + 1

    # Motion analysis
    ups = sum(1 for i in range(n - 1) if notes[i + 1] > notes[i])
    downs = sum(1 for i in range(n - 1) if notes[i + 1] < notes[i])
    repeats = sum(1 for i in range(n - 1) if notes[i + 1] == notes[i])
    range_semitones = max(notes) - min(notes)

    # Tension arc: how does cost evolve over time?
    if len(costs) >= 4:
        first_half = np.mean(costs[:len(costs) // 2])
        second_half = np.mean(costs[len(costs) // 2:])
        if second_half > first_half * 1.3:
            arc = 'building'
        elif first_half > second_half * 1.3:
            arc = 'resolving'
        else:
            arc = 'steady'
    else:
        arc = 'too_short'

    return {
        'n_notes': n,
        'total_cost_nats': round(total, 3),
        'avg_cost_nats': round(avg, 3),
        'cheapest_interval': round(min(costs), 3) if costs else 0,
        'most_expensive': round(max(costs), 3) if costs else 0,
        'dynamic_range': round(dynamic_range, 2),
        'efficiency': round(dynamic_range / max(total, 0.01), 4),
        'pitch_classes': [NOTES[pc] for pc in pcs],
        'n_pitch_classes': len(pcs),
        'interval_distribution': interval_counts,
        'motion': {'up': ups, 'down': downs, 'repeat': repeats},
        'range_semitones': range_semitones,
        'tension_arc': arc,
        'intervals': costs,
    }


def analyze_chord(notes):
    """Analyze a chord's energy cost and tension.

    Args:
        notes: list of note names or MIDI numbers
    """
    pcs = sorted(set(_note_to_pc(n) for n in notes))
    if len(pcs) < 2:
        return {'error': 'Need at least 2 different notes'}

    # Total energy: sum of all pairwise intervals
    total_cost = 0
    intervals = []
    for i in range(len(pcs)):
        for j in range(i + 1, len(pcs)):
            semi = (pcs[j] - pcs[i]) % 12
            cost = _interval_cost(semi)
            total_cost += cost
            intervals.append({'a': NOTES[pcs[i]], 'b': NOTES[pcs[j]],
                            'semitones': semi, 'cost': round(cost, 3)})

    avg_cost = total_cost / len(intervals)

    # Identify chord type
    root = pcs[0]
    relative = sorted(set((pc - root) % 12 for pc in pcs))
    chord_name = None
    for name, template in CHORDS.items():
        if relative == template:
            chord_name = NOTES[root] + name
            break

    # Tension: most expensive interval in the chord
    most_tense = max(intervals, key=lambda x: x['cost'])

    return {
        'notes': [NOTES[pc] for pc in pcs],
        'chord_name': chord_name or 'unknown',
        'total_cost_nats': round(total_cost, 3),
        'avg_cost_nats': round(avg_cost, 3),
        'most_tense_interval': most_tense,
        'consonance': round(1.0 / (avg_cost + 0.1), 3),
        'intervals': intervals,
    }


def analyze_progression(chords):
    """Analyze a chord progression's energy flow.

    Args:
        chords: list of chord note lists, e.g. [['C','E','G'], ['F','A','C'], ...]
    """
    if len(chords) < 2:
        return {'error': 'Need at least 2 chords'}

    chord_costs = []
    transitions = []

    for i, chord in enumerate(chords):
        analysis = analyze_chord(chord)
        chord_costs.append(analysis)

        if i > 0:
            # Transition cost: voice leading energy
            prev_pcs = sorted(set(_note_to_pc(n) for n in chords[i - 1]))
            curr_pcs = sorted(set(_note_to_pc(n) for n in chords[i]))

            # Minimum voice movement
            total_movement = 0
            for pc in curr_pcs:
                min_dist = min(min(abs(pc - p), 12 - abs(pc - p)) for p in prev_pcs)
                total_movement += _interval_cost(min_dist)

            transitions.append({
                'from': chord_costs[i - 1].get('chord_name', '?'),
                'to': analysis.get('chord_name', '?'),
                'voice_leading_cost': round(total_movement, 3),
            })

    # Energy profile
    costs_over_time = [c['total_cost_nats'] for c in chord_costs]
    total_energy = sum(costs_over_time)
    transition_energy = sum(t['voice_leading_cost'] for t in transitions)

    # Detect cadences
    cadences = []
    for i, t in enumerate(transitions):
        # V → I detection (large cost drop)
        if i < len(costs_over_time) - 1:
            if costs_over_time[i] > costs_over_time[i + 1] * 1.3:
                cadences.append({'position': i + 1, 'type': 'resolution', 'strength': round(costs_over_time[i] / costs_over_time[i + 1], 2)})

    return {
        'n_chords': len(chords),
        'chords': [c.get('chord_name', '?') for c in chord_costs],
        'total_harmonic_cost': round(total_energy, 3),
        'total_voice_leading_cost': round(transition_energy, 3),
        'avg_chord_cost': round(total_energy / len(chords), 3),
        'transitions': transitions,
        'cadences': cadences,
        'energy_profile': costs_over_time,
    }


def suggest_next(notes, avoid_recent=True):
    """What note wants to play next?"""
    if not notes:
        return {'note': 'C', 'midi': 60, 'reason': 'start on C'}

    # Build consonance graph
    edges = []
    weights = []
    for root in range(12):
        for iv in [3, 4, 5, 7, 8, 9]:
            j = (root + iv) % 12
            cost = _interval_cost(iv)
            edges.append((min(root, j), max(root, j)))
            weights.append(1.0 / max(cost, 0.1))

    edge_dict = {}
    for (a, b), w in zip(edges, weights):
        edge_dict[(a, b)] = max(edge_dict.get((a, b), 0), w)
    edges = list(edge_dict.keys())
    weights = [edge_dict[e] for e in edges]

    td = _TensionDetector(12, edges, weights)

    recent_pcs = set(_note_to_pc(n) for n in notes[-6:])
    last_pc = _note_to_pc(notes[-1])

    path = td.resolution_path(last_pc, top_k=12)
    for p in path:
        if avoid_recent and p['node'] in recent_pcs:
            continue
        cost = _interval_cost(abs(p['node'] - last_pc))
        return {
            'note': NOTES[p['node']],
            'pitch_class': p['node'],
            'cost_nats': round(cost, 3),
            'tension': not p['connected'],
            'reason': 'tension resolution' if not p['connected'] else 'consonant continuation',
        }

    return {'note': NOTES[last_pc], 'reason': 'no suggestion'}


def groove_cost(pattern_name):
    """Energy cost of rhythmic patterns."""
    patterns = {
        'quarter': [(1, 1)] * 4,
        'eighth': [(1, 1)] * 8,
        'triplet': [(1, 1)] * 3,
        'shuffle': [(2, 1), (1, 2)] * 4,
        'waltz': [(1, 1)] * 3,
        'tresillo': [(3, 3), (3, 3), (2, 3)],
        'clave_32': [(3, 2), (1, 1), (2, 3), (1, 1)],
        'clave_23': [(2, 3), (1, 1), (3, 2), (1, 1)],
        'purdie': [(2, 1), (1, 3), (2, 1), (1, 1)] * 2,
        'bossa': [(3, 2), (3, 2), (3, 2), (3, 2), (4, 3)],
        'reggae': [(1, 1)] * 4,
        'breakbeat': [(3, 1), (1, 3), (2, 1), (1, 1), (3, 2), (1, 3)],
        'dnb': [(3, 1), (1, 1), (1, 3), (2, 1), (1, 3)],
    }

    if pattern_name not in patterns:
        return {'error': f'Unknown pattern. Available: {sorted(patterns.keys())}'}

    intervals = patterns[pattern_name]
    costs = [log(max(p // gcd(p, q), 1)) + log(max(q // gcd(p, q), 1)) for p, q in intervals]
    total = sum(costs)
    avg = total / len(costs) if costs else 0

    return {
        'pattern': pattern_name,
        'total_cost_nats': round(total, 3),
        'avg_cost_nats': round(avg, 3),
        'groove_efficiency': round(1.0 / max(avg + 0.01, 0.01), 2),
        'n_subdivisions': len(intervals),
    }


def key_from_notes(notes):
    """Detect the key from a list of notes using spectral analysis."""
    pcs = [_note_to_pc(n) for n in notes]
    pc_counts = np.zeros(12)
    for pc in pcs:
        pc_counts[pc] += 1

    best_key = None
    best_score = -1
    for root in range(12):
        for mode_name, intervals in MODES.items():
            scale_pcs = set((root + iv) % 12 for iv in intervals)
            score = sum(pc_counts[pc] for pc in scale_pcs)
            if score > best_score:
                best_score = score
                best_key = {'root': NOTES[root], 'mode': mode_name, 'score': score}

    if best_key:
        best_key['confidence'] = round(best_key['score'] / max(len(pcs), 1), 2)
    return best_key


def energy_profile(notes):
    """Full energy profile: per-note Landauer cost over time.
    Use this to visualize how expensive the music is moment by moment."""
    if len(notes) < 2:
        return {'costs': [], 'cumulative': []}

    costs = []
    cumulative = [0]
    for i in range(len(notes) - 1):
        if isinstance(notes[i], str):
            semi = abs(_note_to_pc(notes[i + 1]) - _note_to_pc(notes[i]))
        else:
            semi = abs(int(notes[i + 1]) - int(notes[i]))
        cost = _interval_cost(semi)
        costs.append(round(cost, 3))
        cumulative.append(round(cumulative[-1] + cost, 3))

    return {
        'costs': costs,
        'cumulative': cumulative,
        'total': cumulative[-1],
        'peak_position': costs.index(max(costs)) / len(costs) if costs else 0,
        'peak_cost': max(costs) if costs else 0,
    }
