"""Sensitive content detection — inspired by kcode's neura_memory module.

Detects passwords, API keys, tokens, and other sensitive patterns in text.
Use before storing to memory or publishing to prevent accidental exposure.
"""

SENSITIVE_PATTERNS = [
    "password", "passphrase", "api key", "apikey", "api_key",
    "secret", "token", "bearer ", "private key", "ssh key",
    "oauth", "cookie", "session id", "credit card", "ssn",
    "social security", "aws_access", "aws_secret",
    "stripe_key", "webhook_secret", "database_url",
    "connection_string", "auth_token", "refresh_token",
]


def detect(text):
    """Check if text contains sensitive content.

    Returns list of matched patterns, empty if clean.

    >>> detect("my password is hunter2")
    ['password']
    >>> detect("the weather is nice")
    []
    """
    lowered = text.lower()
    return [p for p in SENSITIVE_PATTERNS if p in lowered]


def is_sensitive(text):
    """Boolean check for sensitive content.

    >>> is_sensitive("api_key=sk-12345")
    True
    >>> is_sensitive("coupling strength K=1.868")
    False
    """
    return len(detect(text)) > 0


def redact(text, replacement="[REDACTED]"):
    """Replace sensitive values with redaction markers.

    Simple pattern: looks for key=value or key: value patterns
    where key matches a sensitive pattern, and replaces the value.

    >>> redact("password=hunter2")
    'password=[REDACTED]'
    >>> redact("api_key: sk-12345-abcde")
    'api_key: [REDACTED]'
    """
    import re
    result = text
    for pattern in SENSITIVE_PATTERNS:
        escaped = re.escape(pattern)
        # key=value
        result = re.sub(
            rf'({escaped})\s*[=:]\s*\S+',
            rf'\1={replacement}',
            result,
            flags=re.IGNORECASE
        )
    return result
