"""
LEARNPATH — Curriculum optimizer
====================================
Map any subject as a graph. Find the optimal learning order.
Tension detection finds which concepts to teach together.

    from gump.learnpath import curriculum
    topics = ['algebra', 'geometry', 'calculus', 'trig', 'stats']
    prereqs = [('algebra','calculus'), ('trig','calculus'), ('algebra','stats')]
    path = curriculum(topics, prereqs)
    print(path['order'])        # optimal learning sequence
    print(path['connections'])  # concepts that should be taught together
"""
import numpy as np
from gump.core import _TensionDetector


def curriculum(topics, prerequisites, weights=None):
    """Find the optimal learning path through a subject.

    Args:
        topics: list of topic names
        prerequisites: list of (prereq, dependent) pairs
        weights: optional importance weights

    Returns:
        order: optimal learning sequence
        connections: topics that should be taught together (tensions)
        clusters: natural topic groups
        difficulty: estimated difficulty curve
    """
    n = len(topics)
    topic_idx = {name: i for i, name in enumerate(topics)}
    edges = [(topic_idx[a], topic_idx[b]) for a, b in prerequisites
             if a in topic_idx and b in topic_idx]

    td = _TensionDetector(n, edges, weights)

    # Spectral ordering: distance from "root" concepts determines order
    # Root = concept with no prerequisites
    has_prereq = set(b for _, b in edges)
    roots = [i for i in range(n) if i not in has_prereq]
    if not roots:
        roots = [0]

    # Average spectral distance from roots
    root_center = np.mean([td.coords[r] for r in roots], axis=0)
    dists = [float(np.linalg.norm(td.coords[i] - root_center)) for i in range(n)]
    order_idx = np.argsort(dists)
    order = [topics[i] for i in order_idx]

    # Tensions: concepts that should be co-taught
    tensions = td.tensions(top_k=10)
    connections = [{
        'topic_a': topics[i],
        'topic_b': topics[j],
        'tension': score,
        'suggestion': f'Teach {topics[i]} and {topics[j]} together — they reinforce each other',
    } for d, i, j, score in tensions]

    # Clusters: natural topic groups
    try:
        labels, k = td.clusters()
        groups = []
        for c in range(k):
            members = [topics[i] for i in range(n) if labels[i] == c]
            if members:
                groups.append(members)
    except Exception:
        groups = [topics]

    # Difficulty curve: spectral distance = cognitive distance from foundation
    difficulty = [{
        'topic': topics[i],
        'difficulty': float(dists[i]),
        'position': rank,
    } for rank, i in enumerate(order_idx)]

    return {
        'order': order,
        'connections': connections,
        'clusters': groups,
        'difficulty': difficulty,
        'n_topics': n,
        'n_prerequisites': len(edges),
    }
