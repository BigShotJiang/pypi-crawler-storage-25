/*
 * K-HASH NATIVE — Compiled C implementation.
 * The same algorithm as khash.py, zero-dependency, runs anywhere.
 *
 * K-256: 32-byte state, 4×8 grid, 48 rounds
 * Target: <1 microsecond per hash. 1M+ hashes/second.
 *
 * Compile: cc -O3 -o khash_native khash_native.c -lm
 * Bench:   ./khash_native bench
 * Hash:    ./khash_native "hello world"
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#define STATE_SIZE 32
#define NCOLS 8
#define NROWS (STATE_SIZE / NCOLS)
#define ROUNDS 48
#define RATE (STATE_SIZE / 2)

/* Golden ratio */
#define PHI 1.6180339887498948482

/* ═══ S-BOX ═══ */
static unsigned char SBOX[256];
static int sbox_ready = 0;

static void build_sbox(void) {
    if (sbox_ready) return;
    unsigned int state = (unsigned int)(PHI * 4294967296.0);
    for (int i = 0; i < 256; i++) SBOX[i] = (unsigned char)i;
    for (int i = 255; i > 0; i--) {
        state = state * 1103515245u + 12345u;
        int j = state % (i + 1);
        unsigned char tmp = SBOX[i];
        SBOX[i] = SBOX[j];
        SBOX[j] = tmp;
    }
    sbox_ready = 1;
}

/* ═══ ROUND CONSTANTS ═══ */
static unsigned char RC[ROUNDS][STATE_SIZE];
static int rc_ready = 0;

static void build_rc(void) {
    if (rc_ready) return;
    for (int r = 0; r < ROUNDS; r++) {
        for (int i = 0; i < STATE_SIZE; i++) {
            RC[r][i] = (unsigned char)((int)((r * STATE_SIZE + i) * PHI * 256.0) % 256);
        }
    }
    rc_ready = 1;
}

/* ═══ PERMUTATION ═══ */

static void sub_bytes(unsigned char *state) {
    for (int i = 0; i < STATE_SIZE; i++)
        state[i] = SBOX[state[i]];
}

static void shift_rows(unsigned char *state) {
    unsigned char tmp[STATE_SIZE];
    for (int r = 0; r < NROWS; r++) {
        for (int c = 0; c < NCOLS; c++) {
            int src = r * NCOLS + c;
            int dst = r * NCOLS + ((c - r + NCOLS) % NCOLS);
            tmp[dst] = state[src];
        }
    }
    memcpy(state, tmp, STATE_SIZE);
}

static void mix_columns(unsigned char *state) {
    unsigned char out[STATE_SIZE];
    memcpy(out, state, STATE_SIZE);
    for (int c = 0; c < NCOLS; c++) {
        unsigned char col[NROWS];
        for (int r = 0; r < NROWS; r++)
            col[r] = state[r * NCOLS + c];
        for (int r = 0; r < NROWS; r++) {
            unsigned char v = col[r];
            unsigned char sum = (col[(r + 1) % NROWS] + col[(r - 1 + NROWS) % NROWS]) & 0xFF;
            v ^= SBOX[sum];
            unsigned char rot = col[(r + 2) % NROWS];
            v ^= (rot >> 1) | (rot << 7);
            out[r * NCOLS + c] = v;
        }
    }
    memcpy(state, out, STATE_SIZE);
}

static void add_constant(unsigned char *state, int round) {
    for (int i = 0; i < STATE_SIZE; i++)
        state[i] ^= RC[round][i];
}

static void permute(unsigned char *state, int rounds) {
    for (int r = 0; r < rounds; r++) {
        sub_bytes(state);
        shift_rows(state);
        mix_columns(state);
        add_constant(state, r % ROUNDS);
    }
}

/* ═══ ABSORPTION ═══ */

static void absorb(unsigned char *state, const unsigned char *block, int block_len) {
    for (int i = 0; i < block_len && i < RATE; i++)
        state[i] ^= block[i];
}

/* ═══ K-256 HASH ═══ */

void khash256(const unsigned char *data, size_t len, unsigned char *out) {
    build_sbox();
    build_rc();

    /* Initialize state from golden ratio */
    unsigned char state[STATE_SIZE];
    for (int i = 0; i < STATE_SIZE; i++)
        state[i] = (unsigned char)((int)(i * PHI * 256.0) % 256);

    /* Pad: data + 8-byte length + 0x01 + zeros */
    size_t pad_len = len + 9;
    while (pad_len % RATE != 0) pad_len++;
    unsigned char *padded = (unsigned char *)calloc(pad_len, 1);
    memcpy(padded, data, len);
    /* Big-endian length */
    for (int i = 0; i < 8; i++)
        padded[len + i] = (unsigned char)((len >> (56 - 8 * i)) & 0xFF);
    padded[len + 8] = 0x01;

    /* Absorb */
    for (size_t off = 0; off < pad_len; off += RATE) {
        int blen = (pad_len - off < RATE) ? (int)(pad_len - off) : RATE;
        absorb(state, padded + off, blen);
        permute(state, ROUNDS);
    }

    /* Squeeze */
    permute(state, ROUNDS / 2);
    memcpy(out, state, STATE_SIZE);
    free(padded);
}

/* ═══ UTILITIES ═══ */

static void hex_encode(const unsigned char *data, int len, char *out) {
    const char hex[] = "0123456789abcdef";
    for (int i = 0; i < len; i++) {
        out[i * 2] = hex[data[i] >> 4];
        out[i * 2 + 1] = hex[data[i] & 0x0F];
    }
    out[len * 2] = '\0';
}

/* ═══ MERKLE ROOT ═══ */

void merkle_root(const unsigned char hashes[][STATE_SIZE], int count, unsigned char *out) {
    if (count == 0) {
        khash256((const unsigned char *)"empty", 5, out);
        return;
    }
    if (count == 1) {
        memcpy(out, hashes[0], STATE_SIZE);
        return;
    }
    /* Pad to even */
    int n = count;
    if (n % 2 == 1) n++;

    unsigned char (*level)[STATE_SIZE] = malloc(n * STATE_SIZE);
    memcpy(level, hashes, count * STATE_SIZE);
    if (count < n) memcpy(level[n - 1], hashes[count - 1], STATE_SIZE);

    while (n > 1) {
        int next_n = (n + 1) / 2;
        for (int i = 0; i < n / 2; i++) {
            unsigned char combined[STATE_SIZE * 2];
            memcpy(combined, level[i * 2], STATE_SIZE);
            memcpy(combined + STATE_SIZE, level[i * 2 + 1], STATE_SIZE);
            khash256(combined, STATE_SIZE * 2, level[i]);
        }
        if (n % 2 == 1) memcpy(level[next_n - 1], level[n - 1], STATE_SIZE);
        n = next_n;
    }
    memcpy(out, level[0], STATE_SIZE);
    free(level);
}

/* ═══ MAIN ═══ */

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: khash_native <data>    — hash a string\n");
        printf("       khash_native bench     — benchmark\n");
        printf("       khash_native bench N   — benchmark N hashes\n");
        return 0;
    }

    if (strcmp(argv[1], "bench") == 0) {
        int n = 1000000;
        if (argc > 2) n = atoi(argv[2]);

        printf("K-256 benchmark: %d hashes\n", n);
        unsigned char out[STATE_SIZE];
        char hex[STATE_SIZE * 2 + 1];
        char input[64];

        struct timespec start, end;
        clock_gettime(CLOCK_MONOTONIC, &start);

        for (int i = 0; i < n; i++) {
            int len = snprintf(input, sizeof(input), "bench_%d", i);
            khash256((unsigned char *)input, len, out);
        }

        clock_gettime(CLOCK_MONOTONIC, &end);
        double elapsed = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
        double per_hash = elapsed / n * 1e6;

        hex_encode(out, STATE_SIZE, hex);
        printf("Last hash: %s\n", hex);
        printf("Time: %.3f seconds\n", elapsed);
        printf("Speed: %.2f microseconds/hash\n", per_hash);
        printf("Rate: %.0f hashes/second\n", n / elapsed);

        /* Collision check */
        printf("\nCollision check (10000 hashes)...\n");
        /* Simple: hash 10000 values, store in sorted array, check for dupes */
        char **store = malloc(10000 * sizeof(char *));
        for (int i = 0; i < 10000; i++) {
            store[i] = malloc(65);
            int len = snprintf(input, sizeof(input), "collision_%d", i);
            khash256((unsigned char *)input, len, out);
            hex_encode(out, STATE_SIZE, store[i]);
        }
        int dupes = 0;
        for (int i = 0; i < 10000; i++) {
            for (int j = i + 1; j < 10000; j++) {
                if (strcmp(store[i], store[j]) == 0) {
                    dupes++;
                    printf("COLLISION: %d == %d\n", i, j);
                }
            }
        }
        printf("Collisions: %d / 10000\n", dupes);
        for (int i = 0; i < 10000; i++) free(store[i]);
        free(store);

        /* Avalanche check */
        printf("\nAvalanche check...\n");
        unsigned char h1[STATE_SIZE], h2[STATE_SIZE];
        khash256((unsigned char *)"test0", 5, h1);
        khash256((unsigned char *)"test1", 5, h2);
        int diffs = 0;
        for (int i = 0; i < STATE_SIZE; i++) {
            unsigned char x = h1[i] ^ h2[i];
            while (x) { diffs += x & 1; x >>= 1; }
        }
        printf("Bit flips: %d / %d (%.1f%%)\n", diffs, STATE_SIZE * 8, diffs * 100.0 / (STATE_SIZE * 8));

        return 0;
    }

    /* Hash the argument */
    unsigned char out[STATE_SIZE];
    char hex[STATE_SIZE * 2 + 1];
    khash256((unsigned char *)argv[1], strlen(argv[1]), out);
    hex_encode(out, STATE_SIZE, hex);
    printf("%s\n", hex);
    return 0;
}
