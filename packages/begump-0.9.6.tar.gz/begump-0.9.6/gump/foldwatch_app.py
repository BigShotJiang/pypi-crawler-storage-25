"""
FOLD WATCH APP — Protein structure analysis with interactive visualization.
=============================================================================
Paste a protein sequence. Get: secondary structure, domains, misfolding risk,
aggregation-prone regions, fold tensions, and a full interactive report.

    from gump.foldwatch_app import report

    # Insulin B chain
    html = report('FVNQHLCGSHLVEALYLVCGERGFFYTPKT')
    with open('insulin_b.html', 'w') as f: f.write(html)

    # Compare wild type vs mutant
    html = compare_report('FVNQHLCGSHLVEALYLVCGERGFFYTPKT',
                          'FVNQHLCGSHLVEALYLVCGERGFFYTPET')

Built on: gump.foldwatch (analysis) + gump.core (spectral placement)
"""

import json
import numpy as np
from gump.foldwatch import analyze, compare
from gump.k_runtime import place as spectral_place


def report(sequence, title='Protein Analysis'):
    """Generate interactive HTML report for a protein sequence — AlphaFold database style."""
    result = analyze(sequence)
    if 'error' in result:
        return f'<html><body><h1>Error</h1><p>{result["error"]}</p></body></html>'

    n = result['sequence_length']
    seq = sequence.upper().strip()
    ss = result['secondary_structure']
    risk = result['misfolding_risk']
    risk_color = '#c44' if risk == 'high' else '#c94' if risk == 'medium' else '#4a9'

    # Spectral positions for the residue graph
    edges = []
    for i in range(n - 1):
        edges.append((i, i + 1))
    for t in result.get('fold_tensions', []):
        edges.append((t['residue_a'], t['residue_b']))

    try:
        positions = spectral_place(n, edges, 800, 600)
        pos_list = [[round(float(positions[i][0]), 1), round(float(positions[i][1]), 1)]
                     for i in range(n)]
    except Exception:
        pos_list = [[round(i * 800 / max(n - 1, 1), 1), 300.0] for i in range(n)]

    # Per-residue property arrays from the property tables in foldwatch
    from gump.foldwatch import HYDRO, HELIX_PROP, SHEET_PROP, AGG_PROP
    hydro_arr = [round(HYDRO.get(seq[i], 0.5), 3) for i in range(n)]
    helix_arr = [round(HELIX_PROP.get(seq[i], 0.8), 3) for i in range(n)]
    agg_arr = [round(max(0, AGG_PROP.get(seq[i], 0.0)), 3) for i in range(n)]

    data = {
        'sequence': seq,
        'ss': ss,
        'positions': pos_list,
        'analysis': result,
        'hydro': hydro_arr,
        'helix_prop': helix_arr,
        'agg_prop': agg_arr,
    }
    data_json = json.dumps(data, default=str)

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fold Watch — {title}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:#08080d;color:#e8e4dc;font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;overflow-x:hidden;}}
@keyframes pulseAgg{{0%,100%{{opacity:0.7;}}50%{{opacity:1;}}}}
@keyframes fadeIn{{from{{opacity:0;transform:translateY(6px);}}to{{opacity:1;transform:translateY(0);}}}}

.page{{max-width:1100px;margin:0 auto;padding:24px;}}
h1{{font-size:1.5em;font-weight:300;color:#c9a44a;letter-spacing:0.08em;margin-bottom:2px;}}
.sub{{font-size:0.62em;color:#444;letter-spacing:0.15em;margin-bottom:20px;font-weight:400;}}
h2{{font-size:0.72em;font-weight:600;color:#c9a44a80;letter-spacing:0.12em;text-transform:uppercase;margin:28px 0 12px;}}

/* ═══ Risk badge ═══ */
.risk-row{{display:flex;align-items:center;gap:16px;margin:12px 0 20px;}}
.risk-badge{{display:flex;align-items:center;gap:10px;padding:10px 24px;border-radius:24px;font-size:0.85em;font-weight:600;
  color:#fff;background:{risk_color};letter-spacing:0.08em;box-shadow:0 4px 16px {risk_color}40;}}
.risk-badge .rb-icon{{width:20px;height:20px;border-radius:50%;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;font-size:0.9em;}}
.risk-label{{font-size:0.72em;color:#888;}}

/* ═══ Stats grid ═══ */
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin:16px 0;}}
.stat-card{{background:#0d0d14;border:1px solid #ffffff06;border-radius:10px;padding:14px 12px;text-align:center;transition:border-color 0.3s;}}
.stat-card:hover{{border-color:#c9a44a30;}}
.stat-card .val{{font-size:1.8em;font-weight:200;color:#c9a44a;line-height:1;}}
.stat-card .label{{font-size:0.62em;color:#666;margin-top:6px;text-transform:uppercase;letter-spacing:0.08em;}}

/* ═══ Sequence viewer ═══ */
.seq-container{{background:#0a0a12;border:1px solid #ffffff06;border-radius:10px;padding:0;margin:12px 0;overflow:hidden;}}
.seq-header{{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-bottom:1px solid #ffffff06;}}
.seq-header .sh-title{{font-size:0.72em;color:#888;font-weight:500;}}
.seq-legend{{display:flex;gap:12px;font-size:0.65em;}}
.seq-legend .sl-item{{display:flex;align-items:center;gap:4px;color:#888;}}
.seq-legend .sl-dot{{width:8px;height:8px;border-radius:2px;}}
.seq-scroll{{overflow-x:auto;padding:16px;}}
.seq-scroll::-webkit-scrollbar{{height:4px;}} .seq-scroll::-webkit-scrollbar-thumb{{background:#ffffff10;border-radius:2px;}}

/* Residue cells */
.seq-row{{display:flex;gap:1px;min-width:fit-content;}}
.res-col{{display:flex;flex-direction:column;align-items:center;gap:1px;min-width:20px;}}
.res-cell{{width:20px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:3px;
  font-family:'SF Mono','Fira Code',monospace;font-size:0.72em;font-weight:500;cursor:pointer;transition:all 0.15s;position:relative;}}
.res-cell:hover{{transform:scale(1.3);z-index:2;box-shadow:0 2px 8px rgba(0,0,0,0.5);}}
.res-cell.ss-H{{background:#e8a06020;color:#e8a060;}} .res-cell.ss-E{{background:#60a0e820;color:#60a0e8;}} .res-cell.ss-C{{background:#44444420;color:#666;}}
.res-cell.agg{{animation:pulseAgg 1.5s ease-in-out infinite;box-shadow:inset 0 0 0 1px #c44;}}
.res-ss{{width:20px;height:6px;border-radius:1px;}} .res-ss.ss-H{{background:#e8a060;}} .res-ss.ss-E{{background:#60a0e8;}} .res-ss.ss-C{{background:#333;}}
.res-num{{font-size:0.5em;color:#555;height:14px;display:flex;align-items:center;}}
.res-domain{{width:20px;height:3px;border-radius:1px;}}
.domain-sep{{position:absolute;right:-1px;top:0;bottom:0;width:2px;background:#c9a44a;z-index:1;}}

/* Disulfide arcs */
.ss-arcs{{position:relative;height:40px;min-width:fit-content;}}
.ss-arc{{position:absolute;border:1.5px solid #c9a44a60;border-bottom:none;border-radius:999px 999px 0 0;}}

/* ═══ Profile chart ═══ */
.profile-wrap{{background:#0a0a12;border:1px solid #ffffff06;border-radius:10px;margin:12px 0;overflow:hidden;}}
.profile-tabs{{display:flex;gap:0;border-bottom:1px solid #ffffff06;}}
.profile-tab{{flex:1;padding:10px;text-align:center;font-size:0.68em;font-weight:500;color:#666;cursor:pointer;
  transition:all 0.2s;border-bottom:2px solid transparent;}}
.profile-tab:hover{{color:#e8e4dc;}} .profile-tab.active{{color:#c9a44a;border-bottom-color:#c9a44a;}}
.profile-canvas{{display:block;width:100%;}}

/* ═══ Fold map canvas ═══ */
.foldmap-wrap{{background:#0a0a12;border:1px solid #ffffff06;border-radius:10px;overflow:hidden;margin:12px 0;}}
.foldmap-header{{padding:12px 16px;border-bottom:1px solid #ffffff06;display:flex;justify-content:space-between;align-items:center;}}
.foldmap-header .fh-title{{font-size:0.72em;color:#888;font-weight:500;}}
canvas#foldmap{{display:block;width:100%;cursor:crosshair;}}

/* ═══ Risk/tension/agg/domain cards ═══ */
.card-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:8px;}}
.warn-card{{background:#0d0d14;border:1px solid #ffffff06;border-radius:10px;padding:14px 16px;transition:border-color 0.3s;}}
.warn-card:hover{{border-color:#c9a44a20;}}
.warn-card .wc-icon{{font-size:1.1em;margin-bottom:6px;}}
.warn-card .wc-title{{font-size:0.82em;font-weight:500;color:#e8e4dc;margin-bottom:4px;}}
.warn-card .wc-desc{{font-size:0.7em;color:#888;line-height:1.5;}}
.warn-card.risk{{border-left:3px solid #c94;}} .warn-card.agg{{border-left:3px solid #c44;}}
.warn-card.tension{{border-left:3px solid #c9a44a40;}} .warn-card.domain{{border-left:3px solid #4a9;}}

/* ═══ Residue tooltip ═══ */
#res-tip{{position:fixed;display:none;background:#0d0d14;border:1px solid #c9a44a40;border-radius:8px;padding:10px 14px;
  pointer-events:none;z-index:200;font-size:0.75em;box-shadow:0 8px 24px rgba(0,0,0,0.6);min-width:160px;}}
#res-tip .rt-aa{{font-size:1.4em;font-weight:300;color:#c9a44a;}}
#res-tip .rt-row{{display:flex;justify-content:space-between;gap:16px;color:#888;padding:2px 0;}}
#res-tip .rt-row span:last-child{{color:#e8e4dc;}}
</style>
</head>
<body>
<div id="res-tip"></div>
<div class="page">
  <h1>Fold Watch</h1>
  <div class="sub">GUMP &middot; protein structure from spectral tension</div>

  <div class="risk-row">
    <div class="risk-badge"><div class="rb-icon">{"!" if risk != "low" else "&#10003;"}</div>{risk.upper()} MISFOLDING RISK</div>
    <div class="risk-label">{n} residues &middot; {result['n_domains']} domain{"s" if result['n_domains'] != 1 else ""} &middot; {len(result.get('risk_factors', []))} risk factor{"s" if len(result.get('risk_factors', [])) != 1 else ""}</div>
  </div>

  <div class="stats">
    <div class="stat-card"><div class="val">{n}</div><div class="label">residues</div></div>
    <div class="stat-card"><div class="val" style="color:#e8a060;">{result['helix_pct']:.0f}%</div><div class="label">helix</div></div>
    <div class="stat-card"><div class="val" style="color:#60a0e8;">{result['sheet_pct']:.0f}%</div><div class="label">sheet</div></div>
    <div class="stat-card"><div class="val" style="color:#666;">{result['coil_pct']:.0f}%</div><div class="label">coil</div></div>
    <div class="stat-card"><div class="val">{result['net_charge']:+.0f}</div><div class="label">net charge</div></div>
    <div class="stat-card"><div class="val">{result['n_domains']}</div><div class="label">domains</div></div>
    <div class="stat-card"><div class="val">{len(result.get('disulfide_candidates',[]))}</div><div class="label">S-S bonds</div></div>
    <div class="stat-card"><div class="val" style="color:{risk_color};">{risk.upper()}</div><div class="label">risk level</div></div>
  </div>

  <h2>SEQUENCE VIEWER</h2>
  <div class="seq-container">
    <div class="seq-header">
      <div class="sh-title">Secondary Structure &middot; Aggregation &middot; Domains</div>
      <div class="seq-legend">
        <div class="sl-item"><div class="sl-dot" style="background:#e8a060;"></div>Helix</div>
        <div class="sl-item"><div class="sl-dot" style="background:#60a0e8;"></div>Sheet</div>
        <div class="sl-item"><div class="sl-dot" style="background:#444;"></div>Coil</div>
        <div class="sl-item"><div class="sl-dot" style="background:#c44;border:1px solid #c44;"></div>Aggregation</div>
      </div>
    </div>
    <div class="seq-scroll">
      <div class="ss-arcs" id="ss-arcs"></div>
      <div class="seq-row" id="seq-row"></div>
    </div>
  </div>

  <h2>RESIDUE PROFILE</h2>
  <div class="profile-wrap">
    <div class="profile-tabs" id="profile-tabs">
      <div class="profile-tab active" data-prop="hydro" onclick="setProfile('hydro')">Hydrophobicity</div>
      <div class="profile-tab" data-prop="agg" onclick="setProfile('agg')">Aggregation</div>
      <div class="profile-tab" data-prop="helix" onclick="setProfile('helix')">Helix Propensity</div>
    </div>
    <canvas id="profile-cv" height="140"></canvas>
  </div>

  <h2>RISK FACTORS</h2>
  <div class="card-grid" id="risks"></div>

  <h2>SPECTRAL FOLD MAP</h2>
  <div class="foldmap-wrap">
    <div class="foldmap-header"><div class="fh-title">Residue positions from spectral tension &middot; colored by domain</div></div>
    <canvas id="foldmap" height="420"></canvas>
  </div>

  <h2>FOLD TENSIONS</h2>
  <div class="card-grid" id="tensions"></div>

  <h2>AGGREGATION REGIONS</h2>
  <div class="card-grid" id="agg-cards"></div>

  <h2>STRUCTURAL DOMAINS</h2>
  <div class="card-grid" id="domain-cards"></div>
</div>

<script>
var DATA = {data_json};
var A = DATA.analysis;
var seq = DATA.sequence;
var ss = DATA.ss;
var n = seq.length;
var tip = document.getElementById('res-tip');

var SS_COLORS = {{H:'#e8a060',E:'#60a0e8',C:'#555'}};
var SS_BG = {{H:'#e8a06020',E:'#60a0e820',C:'#44444420'}};
var DOMAIN_COLORS = ['#c9a44a','#4a9','#60a0e8','#c94','#a070d0','#e8a060','#7ac','#c44'];

// Build aggregation index
var aggSet = new Set();
(A.aggregation_regions||[]).forEach(function(r){{ for(var i=r.start;i<=r.end;i++) aggSet.add(i); }});

// Build domain index
var domainOf = new Array(n).fill(-1);
(A.domains||[]).forEach(function(d,idx){{ for(var i=d.start;i<=d.end;i++) domainOf[i]=idx; }});

// Domain boundaries
var domainBounds = new Set();
(A.domains||[]).forEach(function(d){{ domainBounds.add(d.end); }});

// ═══ SEQUENCE VIEWER ═══
(function(){{
  var row = document.getElementById('seq-row');
  var html = '';
  for(var i=0;i<n;i++){{
    var s = ss[i];
    var isAgg = aggSet.has(i);
    var dIdx = domainOf[i];
    var dColor = dIdx>=0?DOMAIN_COLORS[dIdx%DOMAIN_COLORS.length]:'#333';
    var hasSep = domainBounds.has(i) && i<n-1;
    html += '<div class="res-col" style="position:relative;">'+
      (i%10===0?'<div class="res-num">'+(i+1)+'</div>':'<div class="res-num"></div>')+
      '<div class="res-cell ss-'+s+(isAgg?' agg':'')+'" data-idx="'+i+'" '+
      'onmouseenter="showResTip(event,'+i+')" onmouseleave="hideResTip()">'+seq[i]+'</div>'+
      '<div class="res-ss ss-'+s+'"></div>'+
      '<div class="res-domain" style="background:'+dColor+'40;"></div>'+
      (hasSep?'<div class="domain-sep"></div>':'')+
      '</div>';
  }}
  row.innerHTML = html;

  // Disulfide arcs
  var arcs = document.getElementById('ss-arcs');
  var disul = A.disulfide_candidates||[];
  if(disul.length>0){{
    var arcHTML = '';
    disul.forEach(function(pair,idx){{
      var left = pair[0]*21;
      var right = pair[1]*21;
      var w = right-left;
      var h = Math.min(36, 10+w*0.08);
      arcHTML += '<div class="ss-arc" style="left:'+left+'px;width:'+w+'px;height:'+h+'px;top:'+(36-h)+'px;"></div>';
    }});
    arcs.innerHTML = arcHTML;
    arcs.style.minWidth = (n*21)+'px';
  }} else {{ arcs.style.display='none'; }}
}})();

function showResTip(e,idx){{
  var s = ss[idx];
  var ssName = s==='H'?'Helix':s==='E'?'Sheet':'Coil';
  var isAgg = aggSet.has(idx);
  var dIdx = domainOf[idx];
  tip.innerHTML = '<div class="rt-aa" style="color:'+SS_COLORS[s]+';">'+seq[idx]+'<span style="font-size:0.5em;color:#888;"> '+(idx+1)+'</span></div>'+
    '<div class="rt-row"><span>Structure</span><span style="color:'+SS_COLORS[s]+';">'+ssName+'</span></div>'+
    '<div class="rt-row"><span>Hydrophobicity</span><span>'+DATA.hydro[idx].toFixed(2)+'</span></div>'+
    '<div class="rt-row"><span>Helix propensity</span><span>'+DATA.helix_prop[idx].toFixed(2)+'</span></div>'+
    '<div class="rt-row"><span>Aggregation</span><span'+(isAgg?' style="color:#c44;"':'')+'>'+DATA.agg_prop[idx].toFixed(2)+(isAgg?' !!':'')+'</span></div>'+
    (dIdx>=0?'<div class="rt-row"><span>Domain</span><span>'+(dIdx+1)+'</span></div>':'')+
    '';
  tip.style.display='block';
  tip.style.left = Math.min(e.clientX+12, window.innerWidth-180)+'px';
  tip.style.top = (e.clientY-80)+'px';
}}
function hideResTip(){{ tip.style.display='none'; }}

// ═══ PROFILE CHART ═══
var profileProp = 'hydro';
var profileData = {{ hydro:DATA.hydro, agg:DATA.agg_prop, helix:DATA.helix_prop }};
var profileColors = {{ hydro:'#c9a44a', agg:'#c44', helix:'#e8a060' }};
var profileLabels = {{ hydro:'Hydrophobicity', agg:'Aggregation Propensity', helix:'Helix Propensity' }};

function setProfile(prop){{
  profileProp = prop;
  document.querySelectorAll('.profile-tab').forEach(function(t){{ t.classList.toggle('active',t.dataset.prop===prop); }});
  drawProfile();
}}

function drawProfile(){{
  var cv = document.getElementById('profile-cv');
  var cx = cv.getContext('2d');
  var dpr = window.devicePixelRatio||1;
  cv.width = cv.offsetWidth*dpr;
  cv.height = 140*dpr;
  cx.setTransform(dpr,0,0,dpr,0,0);
  var W=cv.offsetWidth, H=140;
  var pad = {{l:40,r:10,t:20,b:24}};
  var vals = profileData[profileProp]||[];
  var maxV = Math.max.apply(null, vals)||1;
  var color = profileColors[profileProp];
  var barW = Math.max(1, (W-pad.l-pad.r)/n - 0.5);

  cx.clearRect(0,0,W,H);

  // Y-axis grid
  cx.strokeStyle='#ffffff06'; cx.lineWidth=0.5;
  for(var g=0;g<=4;g++){{
    var gy = pad.t+(H-pad.t-pad.b)*(1-g/4);
    cx.beginPath();cx.moveTo(pad.l,gy);cx.lineTo(W-pad.r,gy);cx.stroke();
    cx.fillStyle='#555';cx.font='9px -apple-system,sans-serif';cx.textAlign='right';
    cx.fillText((maxV*g/4).toFixed(1), pad.l-4, gy+3);
  }}

  // Bars
  for(var i=0;i<n;i++){{
    var x = pad.l + i*(W-pad.l-pad.r)/n;
    var v = vals[i]/maxV;
    var bH = v*(H-pad.t-pad.b);
    var isAgg = aggSet.has(i);

    if(profileProp==='agg' && isAgg){{
      cx.fillStyle='#c4480';
      cx.fillRect(x,pad.t,barW,H-pad.t-pad.b);
      cx.fillStyle='#c44';
    }} else {{
      cx.fillStyle=color+'90';
    }}
    cx.fillRect(x, H-pad.b-bH, barW, bH);
  }}

  // Domain boundaries
  cx.strokeStyle='#c9a44a40'; cx.lineWidth=1; cx.setLineDash([3,3]);
  domainBounds.forEach(function(b){{
    var x = pad.l + (b+0.5)*(W-pad.l-pad.r)/n;
    cx.beginPath();cx.moveTo(x,pad.t);cx.lineTo(x,H-pad.b);cx.stroke();
  }});
  cx.setLineDash([]);

  // Label
  cx.fillStyle='#888';cx.font='10px -apple-system,sans-serif';cx.textAlign='center';
  cx.fillText(profileLabels[profileProp], W/2, H-4);
}}

setTimeout(drawProfile, 50);
window.addEventListener('resize', drawProfile);

// ═══ SPECTRAL FOLD MAP ═══
(function(){{
  var cv = document.getElementById('foldmap');
  var cx = cv.getContext('2d');
  var dpr = window.devicePixelRatio||1;
  cv.width = cv.offsetWidth*dpr;
  cv.height = 420*dpr;
  cx.setTransform(dpr,0,0,dpr,0,0);
  var W=cv.offsetWidth, H=420;
  var pos = DATA.positions;

  // Draw backbone
  cx.strokeStyle='rgba(255,255,255,0.05)';
  cx.lineWidth=1;
  cx.beginPath();
  for(var i=0;i<pos.length;i++){{
    var x=40+(pos[i][0]/800)*(W-80);
    var y=30+(pos[i][1]/600)*(H-60);
    if(i===0) cx.moveTo(x,y); else cx.lineTo(x,y);
  }}
  cx.stroke();

  // Tensions
  cx.setLineDash([3,3]);
  (A.fold_tensions||[]).forEach(function(t){{
    var a=pos[t.residue_a],b=pos[t.residue_b];
    if(!a||!b) return;
    var ax=40+(a[0]/800)*(W-80), ay=30+(a[1]/600)*(H-60);
    var bx=40+(b[0]/800)*(W-80), by=30+(b[1]/600)*(H-60);
    cx.strokeStyle = t.type==='hydrophobic'?'rgba(201,164,74,0.2)':
                     t.type==='electrostatic'?'rgba(100,164,201,0.2)':'rgba(150,150,150,0.12)';
    cx.lineWidth=1;
    cx.beginPath();cx.moveTo(ax,ay);cx.lineTo(bx,by);cx.stroke();
  }});
  cx.setLineDash([]);

  // Disulfide bond arcs on fold map
  (A.disulfide_candidates||[]).forEach(function(pair){{
    var a=pos[pair[0]],b=pos[pair[1]];
    if(!a||!b) return;
    var ax=40+(a[0]/800)*(W-80), ay=30+(a[1]/600)*(H-60);
    var bx=40+(b[0]/800)*(W-80), by=30+(b[1]/600)*(H-60);
    cx.strokeStyle='#c9a44a60';
    cx.lineWidth=2;
    cx.beginPath();
    var mx=(ax+bx)/2, my=Math.min(ay,by)-30;
    cx.moveTo(ax,ay);cx.quadraticCurveTo(mx,my,bx,by);cx.stroke();
  }});

  // Residues colored by domain cluster
  for(var i=0;i<pos.length;i++){{
    var x=40+(pos[i][0]/800)*(W-80);
    var y=30+(pos[i][1]/600)*(H-60);
    var dIdx = domainOf[i];
    var color = dIdx>=0?DOMAIN_COLORS[dIdx%DOMAIN_COLORS.length]:SS_COLORS[ss[i]]||'#444';
    var r = aggSet.has(i)?5:3;

    // Aggregation glow
    if(aggSet.has(i)){{
      cx.fillStyle='rgba(204,68,68,0.15)';
      cx.beginPath();cx.arc(x,y,8,0,Math.PI*2);cx.fill();
    }}

    cx.fillStyle=color;
    cx.beginPath();cx.arc(x,y,r,0,Math.PI*2);cx.fill();

    // Label every 10th or first/last
    if(i%10===0||i===n-1){{
      cx.fillStyle='#888';
      cx.font='9px -apple-system,sans-serif';
      cx.textAlign='center';
      cx.fillText(seq[i]+(i+1), x, y-8);
    }}
  }}

  // Domain boundary markers
  domainBounds.forEach(function(b){{
    if(b>=pos.length-1) return;
    var p1=pos[b], p2=pos[b+1];
    var x1=40+(p1[0]/800)*(W-80), y1=30+(p1[1]/600)*(H-60);
    var x2=40+(p2[0]/800)*(W-80), y2=30+(p2[1]/600)*(H-60);
    var mx=(x1+x2)/2, my=(y1+y2)/2;
    cx.strokeStyle='#c9a44a40';cx.lineWidth=1;cx.setLineDash([2,2]);
    cx.beginPath();cx.moveTo(mx,my-15);cx.lineTo(mx,my+15);cx.stroke();
    cx.setLineDash([]);
  }});

  // Legend
  cx.font='10px -apple-system,sans-serif';
  var lx=W-160, ly=H-10;
  (A.domains||[]).forEach(function(d,i){{
    cx.fillStyle=DOMAIN_COLORS[i%DOMAIN_COLORS.length];
    cx.beginPath();cx.arc(lx,ly-i*16,4,0,Math.PI*2);cx.fill();
    cx.fillStyle='#888';cx.textAlign='left';
    cx.fillText('Domain '+(i+1)+' ('+(d.start+1)+'-'+(d.end+1)+')', lx+10, ly-i*16+3);
  }});
}})();

// ═══ RISK FACTOR CARDS ═══
(function(){{
  var d=document.getElementById('risks');
  var rf=A.risk_factors||[];
  if(rf.length===0){{ d.innerHTML='<div class="warn-card domain" style="border-left-color:#4a9;"><div class="wc-title" style="color:#4a9;">No significant risk factors</div><div class="wc-desc">This sequence shows low misfolding risk based on structural analysis.</div></div>'; return; }}
  rf.forEach(function(r,i){{
    d.innerHTML+='<div class="warn-card risk" style="animation:fadeIn 0.3s ease '+(i*0.1)+'s both;">'+
      '<div class="wc-title">'+r+'</div>'+
      '<div class="wc-desc">Contributes to overall '+A.misfolding_risk+' misfolding risk assessment.</div></div>';
  }});
}})();

// ═══ TENSION CARDS ═══
(function(){{
  var d=document.getElementById('tensions');
  (A.fold_tensions||[]).forEach(function(t,i){{
    var typeColor = t.type==='hydrophobic'?'#c9a44a':t.type==='electrostatic'?'#60a0e8':'#888';
    d.innerHTML+='<div class="warn-card tension" style="animation:fadeIn 0.3s ease '+(i*0.05)+'s both;">'+
      '<div class="wc-title" style="color:'+typeColor+';">'+seq[t.residue_a]+(t.residue_a+1)+' --- '+seq[t.residue_b]+(t.residue_b+1)+'</div>'+
      '<div class="wc-desc">'+t.type+' tension &middot; score '+t.tension.toFixed(1)+' &middot; '+t.seq_distance+' residues apart</div></div>';
  }});
  if((A.fold_tensions||[]).length===0) d.innerHTML='<div style="color:#4a9;font-size:0.75em;">No significant fold tensions.</div>';
}})();

// ═══ AGGREGATION CARDS ═══
(function(){{
  var d=document.getElementById('agg-cards');
  var regs=A.aggregation_regions||[];
  if(regs.length===0){{ d.innerHTML='<div style="color:#4a9;font-size:0.75em;">No aggregation-prone regions detected.</div>'; return; }}
  regs.forEach(function(r,i){{
    d.innerHTML+='<div class="warn-card agg" style="animation:fadeIn 0.3s ease '+(i*0.1)+'s both;">'+
      '<div class="wc-title">Residues '+(r.start+1)+'&ndash;'+(r.end+1)+'</div>'+
      '<div class="wc-desc">Sequence: '+seq.substring(r.start,r.end+1)+'<br>Aggregation score: '+r.max_score.toFixed(2)+'</div></div>';
  }});
}})();

// ═══ DOMAIN CARDS ═══
(function(){{
  var d=document.getElementById('domain-cards');
  (A.domains||[]).forEach(function(dm,i){{
    var ssType = dm.dominant_ss==='H'?'Helix-rich':dm.dominant_ss==='E'?'Sheet-rich':'Coil-dominant';
    var color = DOMAIN_COLORS[i%DOMAIN_COLORS.length];
    d.innerHTML+='<div class="warn-card domain" style="border-left-color:'+color+';animation:fadeIn 0.3s ease '+(i*0.1)+'s both;">'+
      '<div class="wc-title">Domain '+(i+1)+'</div>'+
      '<div class="wc-desc">Residues '+(dm.start+1)+'&ndash;'+(dm.end+1)+' &middot; '+dm.size+' residues<br>'+
      ssType+' &middot; Hydrophobicity: '+(dm.avg_hydro?dm.avg_hydro.toFixed(2):'?')+'</div></div>';
  }});
}})();
</script>
</body>
</html>'''


def compare_report(seq_a, seq_b, title_a='Wild Type', title_b='Mutant'):
    """Generate comparison report for two sequences."""
    result = compare(seq_a, seq_b)
    if 'error' in result:
        return f'<html><body><h1>Error</h1><p>{result["error"]}</p></body></html>'

    # Build side-by-side
    report_a = report(seq_a, title_a)
    report_b = report(seq_b, title_b)

    return f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fold Watch — Comparison</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:#08080d;color:#e8e4dc;font-family:Georgia,serif;}}
.compare{{display:flex;gap:20px;padding:20px;min-height:100vh;}}
.half{{flex:1;overflow-y:auto;}}
h1{{font-size:1.2em;font-weight:200;color:#c9a44a;text-align:center;margin-bottom:16px;}}
iframe{{width:100%;height:100vh;border:1px solid #ffffff08;border-radius:8px;background:#08080d;}}
</style></head><body>
<div class="compare">
  <div class="half"><iframe srcdoc="{report_a.replace(chr(34), '&quot;').replace('<', '&lt;').replace('>', '&gt;')}"></iframe></div>
  <div class="half"><iframe srcdoc="{report_b.replace(chr(34), '&quot;').replace('<', '&lt;').replace('>', '&gt;')}"></iframe></div>
</div>
</body></html>'''
