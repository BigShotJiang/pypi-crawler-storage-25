"""
TENSIONMAP — Organizational X-ray
====================================
Feed any network. Get back what's missing, what's redundant,
what clusters naturally, and a prioritized action plan.

    from gump.tensionmap import scan, scan_csv, scan_imports, scan_org
    result = scan(nodes, edges)
    print(result['action_plan'])     # top 5 things to fix
    print(result['health_score'])    # 0-100 network health

Works on: org charts, codebases, citation networks, supply chains,
social graphs, dependency trees — anything with connections.
"""
import numpy as np
from gump.core import _TensionDetector, PHI


def scan(nodes, edges, weights=None, top_k=20, node_properties=None):
    """Deep network analysis.

    Args:
        nodes: list of node names
        edges: list of (name_a, name_b) tuples
        weights: optional edge weights
        node_properties: optional dict {node_name: {prop: value}} for enrichment
        top_k: how many tensions/redundancies to return

    Returns comprehensive analysis dict.
    """
    if not nodes:
        return {'error': 'no nodes provided'}
    if not edges:
        return {'error': 'no edges provided', 'n_nodes': len(nodes)}

    node_idx = {name: i for i, name in enumerate(nodes)}
    n = len(nodes)

    idx_edges = []
    idx_weights = []
    for k, (a, b) in enumerate(edges):
        if a in node_idx and b in node_idx:
            idx_edges.append((node_idx[a], node_idx[b]))
            idx_weights.append(weights[k] if weights and k < len(weights) else 1.0)

    if not idx_edges:
        return {'error': 'no valid edges (check node names match)', 'n_nodes': n}

    td = _TensionDetector(n, idx_edges, idx_weights)

    # ═══ Degree analysis ═══
    degree = np.zeros(n)
    for i, j in idx_edges:
        degree[i] += 1
        degree[j] += 1

    # Hub detection (high degree = bottleneck or key connector)
    hub_threshold = np.mean(degree) + 2 * np.std(degree) if np.std(degree) > 0 else np.mean(degree) + 1
    hubs = [{'node': nodes[i], 'degree': int(degree[i])} for i in range(n) if degree[i] > hub_threshold]
    hubs.sort(key=lambda x: -x['degree'])

    # Isolates (low degree = disconnected)
    isolates = [nodes[i] for i in range(n) if degree[i] <= 1]

    # ═══ Tensions ═══
    raw_tensions = td.tensions(top_k)
    tensions = []
    for d, i, j, score in raw_tensions:
        t = {
            'a': nodes[i], 'b': nodes[j],
            'tension': round(score, 3), 'distance': round(d, 4),
            'priority': 'high' if score > np.mean([s for _, _, _, s in raw_tensions]) * 1.5 else
                        'medium' if score > np.mean([s for _, _, _, s in raw_tensions]) else 'low',
        }
        if node_properties:
            if nodes[i] in node_properties:
                t['a_props'] = node_properties[nodes[i]]
            if nodes[j] in node_properties:
                t['b_props'] = node_properties[nodes[j]]
        tensions.append(t)

    # ═══ Redundancies ═══
    raw_redund = td.redundancies(top_k)
    redundancies = [{
        'a': nodes[i], 'b': nodes[j],
        'distance': round(d, 4),
        'strength': 'weak' if d > np.median([dd for dd, _, _ in raw_redund]) else 'moderate',
    } for d, i, j in raw_redund]

    # ═══ Clusters ═══
    try:
        labels, k = td.clusters()
        cluster_groups = []
        for c in range(k):
            members = [nodes[i] for i in range(n) if labels[i] == c]
            if members:
                # Cluster coherence: average internal spectral distance
                member_idx = [i for i in range(n) if labels[i] == c]
                if len(member_idx) > 1:
                    center = np.mean(td.coords[member_idx], axis=0)
                    coherence = 1.0 / (np.mean([np.linalg.norm(td.coords[i] - center)
                                                  for i in member_idx]) + 0.01)
                else:
                    coherence = 1.0
                cluster_groups.append({
                    'members': members,
                    'size': len(members),
                    'coherence': round(coherence, 2),
                })
        cluster_groups.sort(key=lambda x: -x['size'])
    except Exception:
        cluster_groups = [{'members': nodes, 'size': n, 'coherence': 0}]

    # ═══ Bridge detection ═══
    # Nodes that connect different clusters
    bridges = []
    if len(cluster_groups) > 1 and 'labels' in dir():
        for i, j in idx_edges:
            if labels[i] != labels[j]:
                bridges.append({
                    'node_a': nodes[i], 'cluster_a': int(labels[i]),
                    'node_b': nodes[j], 'cluster_b': int(labels[j]),
                })

    # ═══ Health score (0-100) ═══
    # Based on: connectivity, cluster balance, tension level, bridge coverage
    avg_degree = np.mean(degree)
    degree_score = min(25, avg_degree / max(n * 0.1, 1) * 25)

    cluster_balance = 1.0 - np.std([c['size'] for c in cluster_groups]) / max(n, 1)
    balance_score = cluster_balance * 25

    tension_ratio = len(tensions) / max(len(idx_edges), 1)
    tension_score = max(0, 25 - tension_ratio * 50)

    bridge_score = min(25, len(bridges) / max(len(cluster_groups) - 1, 1) * 25) if len(cluster_groups) > 1 else 25

    health = round(degree_score + balance_score + tension_score + bridge_score)

    # ═══ Action plan ═══
    actions = []
    for t in tensions[:5]:
        actions.append({
            'action': f"Connect {t['a']} with {t['b']}",
            'reason': f"Spectral tension {t['tension']:.1f} — they should be collaborating",
            'priority': t['priority'],
            'type': 'add_connection',
        })
    for iso in isolates[:3]:
        actions.append({
            'action': f"Integrate {iso} into the network",
            'reason': f"Degree ≤ 1 — at risk of isolation",
            'priority': 'high',
            'type': 'integrate_isolate',
        })
    for r in redundancies[:2]:
        if r['strength'] == 'weak':
            actions.append({
                'action': f"Evaluate {r['a']} ↔ {r['b']} connection",
                'reason': f"Weakest link (spectral distance {r['distance']:.3f})",
                'priority': 'low',
                'type': 'evaluate_redundancy',
            })

    actions.sort(key=lambda x: {'high': 0, 'medium': 1, 'low': 2}[x['priority']])

    return {
        'health_score': health,
        'tensions': tensions,
        'redundancies': redundancies,
        'clusters': cluster_groups,
        'hubs': hubs,
        'isolates': isolates,
        'bridges': bridges[:10],
        'action_plan': actions,
        'stats': {
            'n_nodes': n,
            'n_edges': len(idx_edges),
            'n_clusters': len(cluster_groups),
            'avg_degree': round(float(avg_degree), 1),
            'max_degree': int(max(degree)),
            'n_hubs': len(hubs),
            'n_isolates': len(isolates),
            'n_tensions': len(tensions),
            'n_bridges': len(bridges),
        },
    }


def scan_csv(csv_text, has_header=False):
    """Scan from CSV. Format: 'node_a,node_b[,weight]' per line."""
    lines = csv_text.strip().split('\n')
    if has_header:
        lines = lines[1:]

    nodes_set = set()
    edges = []
    weights = []
    for line in lines:
        parts = [p.strip() for p in line.strip().split(',')]
        if len(parts) >= 2 and parts[0] and parts[1]:
            a, b = parts[0], parts[1]
            nodes_set.add(a)
            nodes_set.add(b)
            edges.append((a, b))
            try:
                weights.append(float(parts[2]) if len(parts) >= 3 else 1.0)
            except (ValueError, IndexError):
                weights.append(1.0)

    if not nodes_set:
        return {'error': 'No valid edges found in CSV'}

    return scan(sorted(nodes_set), edges, weights)


def scan_imports(directory, language='python'):
    """Scan a codebase for import dependencies."""
    import os
    import re

    if not os.path.isdir(directory):
        return {'error': f'Directory not found: {directory}'}

    ext = '.py' if language == 'python' else '.js' if language == 'javascript' else '.py'
    pattern = r'(?:from|import)\s+([\w.]+)' if language == 'python' else r'(?:require|import)\s+[\'\"]([\w./]+)'

    files = {}
    for root, dirs, filenames in os.walk(directory):
        # Skip hidden dirs and common excludes
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ('node_modules', '__pycache__', 'venv', '.git')]
        for f in filenames:
            if f.endswith(ext) and not f.startswith('__'):
                path = os.path.join(root, f)
                name = os.path.splitext(f)[0]
                files[name] = path

    nodes = sorted(files.keys())
    node_set = set(nodes)
    edges = []

    for name, path in files.items():
        try:
            with open(path, encoding='utf-8', errors='ignore') as f:
                content = f.read()
            matches = re.findall(pattern, content)
            for match in matches:
                # Extract module name
                mod = match.split('.')[-1]
                if mod in node_set and mod != name:
                    edges.append((name, mod))
        except Exception:
            continue

    if not edges:
        return {'error': 'No import dependencies found', 'n_files': len(nodes)}

    return scan(nodes, list(set(edges)))


def scan_org(people, reports_to):
    """Scan an org chart.

    Args:
        people: list of names
        reports_to: dict {person: manager} or list of (person, manager) tuples
    """
    if isinstance(reports_to, dict):
        edges = [(v, k) for k, v in reports_to.items() if v in set(people) and k in set(people)]
    else:
        edges = [(a, b) for a, b in reports_to if a in set(people) and b in set(people)]

    return scan(people, edges)
