"""CHIPFAST — Gate placement via coupling."""
import numpy as np
import re


def place(gates, connections, grid_size=None):
    """Place gates using force-directed layout."""
    n = len(gates)
    if n < 2: return {'error':'Need >= 2 gates'}
    if grid_size is None: side = int(np.ceil(np.sqrt(n))); grid_size = (side, side)
    pos = np.random.RandomState(42).uniform(0, grid_size[0], (n, 2))
    for _ in range(200):
        forces = np.zeros((n, 2))
        for i in range(n):
            for j in range(i+1, n):
                d = pos[i]-pos[j]; dist = np.sqrt(np.sum(d**2))+0.01
                f = 2.0/dist**2; forces[i] += d/dist*f; forces[j] -= d/dist*f
        for a,b in connections:
            if a>=n or b>=n: continue
            d = pos[b]-pos[a]; dist = np.sqrt(np.sum(d**2))+0.01
            f = dist*0.1; forces[a] += d/dist*f; forces[b] -= d/dist*f
        pos += forces*0.1; pos = np.clip(pos, 0, grid_size[0])
    wl = sum(np.sqrt(np.sum((pos[a]-pos[b])**2)) for a,b in connections if a<n and b<n)
    aw = wl/max(1,len(connections))
    return {'positions':{gates[i]:(round(float(pos[i,0]),2),round(float(pos[i,1]),2)) for i in range(n)},
            'total_wire':round(float(wl),2),'K_compactness':round(float(1/(1+aw)),4),'n_gates':n}


def design(gates, wires, weights=None):
    """Full chip design: placement + analysis. Returns standardized result dict."""
    n = len(gates)
    if n < 2:
        return {'error': 'Need >= 2 gates'}
    result = place(gates, wires)
    if 'error' in result:
        return result
    # Build integer-indexed positions for downstream consumers
    positions = {i: result['positions'][gates[i]] for i in range(n)}
    # Detect hot spots (gates with highest degree)
    degree = np.zeros(n)
    for a, b in wires:
        if a < n: degree[a] += 1
        if b < n: degree[b] += 1
    threshold = np.mean(degree) + 2 * np.std(degree) if np.std(degree) > 0 else np.mean(degree) + 1
    hot_spots = int(np.sum(degree > threshold))
    # Tensions: pairs spectrally close but not connected
    edge_set = set((min(a,b), max(a,b)) for a,b in wires if a < n and b < n)
    tensions = []
    pos_arr = np.array([positions[i] for i in range(n)])
    for i in range(min(n, 50)):
        dists = np.linalg.norm(pos_arr - pos_arr[i], axis=1)
        nearest = np.argsort(dists)[1:6]
        for j in nearest:
            pair = (min(i,int(j)), max(i,int(j)))
            if pair not in edge_set:
                tensions.append({'a': gates[i], 'b': gates[int(j)],
                                 'distance': round(float(dists[j]), 3)})
    return {
        'n_gates': n,
        'n_wires': len(wires),
        'gate_names': list(gates),
        'positions': positions,
        'wire_length': result['total_wire'],
        'K_compactness': result['K_compactness'],
        'hot_spots': hot_spots,
        'tensions': tensions[:20],
        'missing_connections': tensions[:20],
    }


def isolate(components, connections, isolate_pairs, couple_pairs=None):
    """Anti-Chipfast: maximize isolation between sensitive pairs.

    Same Laplacian math as place(), opposite objective.
    Finds placement that maximizes spectral distance between
    isolate_pairs while keeping couple_pairs close.

    Args:
        components: list of component names
        connections: list of (i, j) functional connections
        isolate_pairs: list of (name_a, name_b) to push apart
        couple_pairs: list of (name_a, name_b) that must stay close (optional)

    Returns:
        dict with positions, isolation scores, and Fiedler gap
    """
    n = len(components)
    if n < 2:
        return {'error': 'Need >= 2 components'}

    # Build Laplacian
    adj = np.zeros((n, n))
    for a, b in connections:
        if a < n and b < n:
            adj[a, b] = 1; adj[b, a] = 1

    degree = adj.sum(axis=1)
    L = np.diag(degree) - adj

    # Fiedler vector (second smallest eigenvector of L)
    eigvals = np.linalg.eigvalsh(L)
    # Full eigen decomposition
    vals, vecs = np.linalg.eigh(L)

    # Use Fiedler vector for 1D placement (spectral bisection)
    fiedler = vecs[:, 1] if n > 2 else np.array([1, -1] + [0] * (n - 2))

    # Positions from Fiedler
    positions = {components[i]: round(float(fiedler[i]), 4) for i in range(n)}

    # Measure isolation between requested pairs
    isolation_scores = []
    for pair in isolate_pairs:
        a_name, b_name = pair
        if a_name in components and b_name in components:
            ai = components.index(a_name)
            bi = components.index(b_name)
            dist = abs(fiedler[ai] - fiedler[bi])
            isolation_scores.append({
                'pair': (a_name, b_name),
                'spectral_distance': round(float(dist), 4),
                'isolated': dist > 0.5,
            })

    # Measure coupling compliance
    coupling_scores = []
    if couple_pairs:
        for pair in couple_pairs:
            a_name, b_name = pair
            if a_name in components and b_name in components:
                ai = components.index(a_name)
                bi = components.index(b_name)
                dist = abs(fiedler[ai] - fiedler[bi])
                coupling_scores.append({
                    'pair': (a_name, b_name),
                    'spectral_distance': round(float(dist), 4),
                    'coupled': dist < 0.3,
                })

    fiedler_gap = float(vals[1]) if len(vals) > 1 else 0

    return {
        'positions': positions,
        'isolation': isolation_scores,
        'coupling': coupling_scores,
        'fiedler_gap': round(fiedler_gap, 4),
        'n_components': n,
    }


def design_netlist(netlist_text):
    """Parse a simple netlist and design.
    Format: 'type name (output, input1, input2, ...);' per line.
    """
    gates = []
    wires = []
    net_to_gates = {}
    for line in netlist_text.strip().replace(';', '\n').split('\n'):
        line = line.strip()
        if not line:
            continue
        m = re.match(r'(\w+)\s+(\w+)\s*\(([^)]+)\)', line)
        if not m:
            continue
        gate_type, gate_name, ports_str = m.groups()
        gate_idx = len(gates)
        gates.append(gate_name)
        ports = [p.strip() for p in ports_str.split(',')]
        for net in ports:
            if net in net_to_gates:
                for prev_idx in net_to_gates[net]:
                    wires.append((prev_idx, gate_idx))
                net_to_gates[net].append(gate_idx)
            else:
                net_to_gates[net] = [gate_idx]
    if not gates:
        return {'error': 'No gates found in netlist'}
    return design(gates, wires)
