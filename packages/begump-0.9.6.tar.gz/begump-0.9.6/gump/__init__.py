"""
GUMP — Grand Unified Music Project

One function. Give it anything. Get back three things:
    the_point  — what it means, in plain English
    the_math   — the full data, for experts
    the_next   — where to go from here, what to couple with

    import gump
    result = gump.ask("DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA")
    print(result['the_point'])
    print(result['the_next'])

Works on: proteins, signals, text. Auto-detects.

K = coupling strength     (how strongly things connect)
R = order parameter       (how synchronized they are)
E = energy cost           (what it costs in joules)
T = tension               (what wants to connect but hasn't)
"""

__version__ = '0.9.6'

from gump.core import (
    k_measure, tensions, EnergyTracker, interval_cost,
    place, detect_crash, watch_training, _TensionDetector
)
from gump.machine import machine
from gump.reflect import reflect, trajectory, recurrence
from gump.octave import octave, drift, sawtooth
from gump.pillar import pillar
from gump.for_machine import for_machine, for_signature, compare
from gump.entropy import profile as entropy_profile, diagnose as entropy_diagnose
from gump.diverge import diverge, diverge_batch, distance as diverge_distance
from gump.couple import profile as couple_profile, quick as couple_quick
from gump.kill import kill, kill_sweep
from gump.sensitive import detect as sensitive_detect, is_sensitive, redact as sensitive_redact

# ═══════════════════════════════════════════════════════════
# AMINO ACIDS & DNA — for type detection
# ═══════════════════════════════════════════════════════════

_AMINO = set('ACDEFGHIKLMNPQRSTVWY')
_DNA   = set('ACGT')

# ═══════════════════════════════════════════════════════════
# DETECT — what did the user give us?
# ═══════════════════════════════════════════════════════════

def _detect(data):
    """Identify the input type. Returns ('protein'|'signal'|'text'|'unknown', cleaned_data)."""

    if data is None:
        return 'unknown', None

    if isinstance(data, str):
        clean = data.upper().replace(' ', '').replace('\n', '')
        if len(clean) < 4:
            return 'text', data
        chars = set(clean)
        if chars <= _DNA and len(clean) > 20:
            return 'dna', clean
        if chars <= _AMINO and len(clean) > 8:
            return 'protein', clean
        return 'text', data

    if isinstance(data, (list, tuple)):
        if len(data) == 0:
            return 'unknown', []
        try:
            import math
            nums = [float(x) for x in data]
            if any(math.isnan(x) or math.isinf(x) for x in nums):
                nums = [x for x in nums if not (math.isnan(x) or math.isinf(x))]
            return 'signal', nums
        except (ValueError, TypeError):
            return 'text', str(data)

    if isinstance(data, (int, float)):
        return 'signal', [float(data)]

    return 'text', str(data)


# ═══════════════════════════════════════════════════════════
# ASK — the front door
# ═══════════════════════════════════════════════════════════

def ask(data):
    """Give it anything. Get back the point, the math, and the next step.

    Returns:
        dict with keys:
            type      — 'protein', 'signal', 'text', 'dna', or 'unknown'
            the_point — plain English summary (no jargon)
            the_math  — full data dictionary
            the_next  — coupling targets and next steps
    """

    kind, clean = _detect(data)

    if kind == 'protein':  return _protein(clean)
    if kind == 'dna':      return _dna(clean)
    if kind == 'signal':   return _signal(clean)
    if kind == 'text':     return _text(clean)

    return {
        'type':      'unknown',
        'the_point': "Couldn't determine what this is. Try a protein sequence, a list of numbers, or some text.",
        'the_math':  {},
        'the_next':  "→ Protein: gump.ask('MVLSPADKTNVKAAWGKVGAH...')\n→ Signal: gump.ask([1.2, 3.4, 2.1, 5.6])\n→ Text: gump.ask('any sentence')",
    }


# ═══════════════════════════════════════════════════════════
# PROTEIN — fold it, read it, point forward
# ═══════════════════════════════════════════════════════════

def _protein(seq):
    from gump.foldwatch import analyze, crystal_fold

    a  = analyze(seq)
    cf = crystal_fold(seq)
    n  = len(seq)

    # — the math —
    math = {**a, 'crystal_fold': cf}

    # — measurements —
    core   = a.get('core_hydrophobicity', 0)
    helix  = a.get('helix_pct', 0)
    coil   = a.get('coil_pct', 0)
    rg     = cf.get('rg', 0)
    agg    = a.get('aggregation_regions', [])
    risk   = a.get('misfolding_risk', 'unknown')
    ss     = a.get('disulfide_candidates', [])

    helix  = helix if helix > 1 else helix * 100
    coil   = coil  if coil  > 1 else coil  * 100

    # — the point (no jargon) —
    point = [f"Protein. {n} amino acids."]

    if   core > 0.6: point.append(f"Strong inner core ({core:.0%}) — folds tight, sensitive to disruption.")
    elif core > 0.4: point.append(f"Normal core ({core:.0%}) — standard folding.")
    else:            point.append(f"Weak core ({core:.0%}) — flexible or disordered.")

    point.append(f"Shape: {helix:.0f}% spiral, {coil:.0f}% loose. Predicted size: {rg:.1f}Å.")

    if len(agg) > 0: point.append(f"⚠ {len(agg)} sticky region{'s' if len(agg) > 1 else ''} — may clump (like Alzheimer's proteins).")
    if len(ss)  > 0: point.append(f"Has {len(ss)} internal bridge{'s' if len(ss) > 1 else ''} (stabilizers).")

    # — the next (coupling targets) —
    nxt = []

    if len(agg) > 0:
        nxt.append("STICKY REGIONS DETECTED:")
        nxt.append("  → Does this match known disease proteins?")
        nxt.append("    Alzheimer's (Aβ42): sticky at positions 16-20 (KLVFF)")
        nxt.append("    Parkinson's (α-syn): sticky at positions 61-95")
        nxt.append("    ALS (TDP-43): sticky tail region")
        nxt.append("  → Can we fix it? Add a charged amino acid at the sticky center.")
        nxt.append("    TEST: gump.foldwatch.fold(sequence) — are sticky regions exposed?")
        nxt.append("    TEST: mutate the stickiest position to Asp or Glu — does clumping drop?")

    if core > 0.6:
        nxt.append("\nSTRONG CORE:")
        nxt.append("  → Core mutations are dangerous — they unfold the protein.")
        nxt.append("    TEST: gump.foldwatch.lucy_scan(sequence) — which positions matter most?")

    if isinstance(rg, (int, float)):
        nxt.append(f"\nSIZE ({rg:.1f}Å):")
        if   rg < 10: nxt.append("  → Small. Similar to: insulin (9.0Å), ubiquitin (11.8Å)")
        elif rg < 15: nxt.append("  → Medium. Similar to: lysozyme (14.3Å), myoglobin (15.5Å)")
        else:         nxt.append("  → Large. Check for multiple domains or disorder.")

    if len(ss) > 0:
        nxt.append(f"\nBRIDGES ({len(ss)}):")
        nxt.append("  → These hold the shape together. Breaking them = unfolding.")
        nxt.append("  → Relevant for: drug design, storage conditions, lab handling.")

    if not nxt:
        nxt.append("No high-priority targets. Try:")
        nxt.append("  gump.foldwatch.fold(seq)        — 3D structure")
        nxt.append("  gump.foldwatch.water_fold(seq)   — fast screening")

    return {
        'type':      'protein',
        'the_point': '\n'.join(point),
        'the_math':  math,
        'the_next':  '\n'.join(nxt),
    }


# ═══════════════════════════════════════════════════════════
# DNA — acknowledge, point to protein
# ═══════════════════════════════════════════════════════════

def _dna(seq):
    n = len(seq)
    codons = n // 3
    gc = (seq.count('G') + seq.count('C')) / max(n, 1)

    return {
        'type':      'dna',
        'the_point': f"DNA sequence. {n} bases. {codons} codons. GC content: {gc:.0%}.",
        'the_math':  {'length': n, 'codons': codons, 'gc_content': gc},
        'the_next':  "→ Translate to protein: use the standard codon table\n→ Then: gump.ask(protein_sequence) for folding analysis\n→ GC content affects stability — high GC = tighter double helix",
    }


# ═══════════════════════════════════════════════════════════
# SIGNAL — measure K, read the coupling, point forward
# ═══════════════════════════════════════════════════════════

def _signal(nums):
    if len(nums) < 2:
        return {
            'type':      'signal',
            'the_point': f"Signal with {len(nums)} point{'s' if len(nums) != 1 else ''}. Need at least 2 for analysis.",
            'the_math':  {'n': len(nums)},
            'the_next':  "→ Provide more data points. K needs 50+ for reliable measurement.",
        }

    from gump.sensor import measure_kret
    import numpy as np

    kret = measure_kret(np.array(nums, dtype=float))
    k    = kret.get('K', 0)
    v    = kret.get('verdict', 'UNKNOWN')
    n    = len(nums)

    # — the point —
    point = [f"Signal. {n} data points."]

    if   k > 0.8: point.append(f"K = {k:.3f} — almost deterministic. Very strong pattern.")
    elif k > 0.3: point.append(f"K = {k:.3f} — strong coupling. Real structure here.")
    elif k > 0.1: point.append(f"K = {k:.3f} — moderate coupling. Something there, maybe faint.")
    elif k > 0.02:point.append(f"K = {k:.3f} — weak. Mostly noise with hints of pattern.")
    else:         point.append(f"K = {k:.3f} — no coupling. This is random.")

    # — the next —
    nxt = []

    if k > 0.3:
        nxt.append("STRONG SIGNAL — worth investigating:")
        nxt.append("  → Find the rhythm:  gump.oracle.extract(signal)")
        nxt.append("  → Predict ahead:    gump.oracle.predict(signal, steps=10)")
        nxt.append("  → Find breakpoints: gump.sensor.scan(signal)")
        nxt.append("  → Deep entropy:     gump.entropy.profile(signal)")
        nxt.append("  → Compare two signals: gump.couple.profile(signal_a, signal_b)")
        nxt.append("  → Compare K to known systems:")
        nxt.append("      Brain EEG:    0.3–0.8")
        nxt.append("      Heart rate:   0.5–0.9")
        nxt.append("      Stock market: 0.05–0.3")
        nxt.append("      Random noise:  0.00–0.02")
    elif k > 0.1:
        nxt.append("MODERATE — might be real:")
        nxt.append("  → Try a longer sample — K gets clearer with more data.")
        nxt.append("  → Check for a hidden rhythm: gump.oracle.extract(signal)")
        nxt.append("  → Deep entropy:  gump.entropy.profile(signal)")
        nxt.append("  → Compare before/after an event: does K change?")
    else:
        nxt.append("RANDOM — no structure found.")
        nxt.append("  → If you expected a pattern, check:")
        nxt.append("    • Is the data clean? (dropouts, wrong units)")
        nxt.append("    • Long enough? (K needs 50+ points)")
        nxt.append("    • Measuring the right thing?")
        nxt.append("  → Still useful: gump.entropy.profile(signal) — even noise has structure.")

    return {
        'type':      'signal',
        'the_point': '\n'.join(point),
        'the_math':  kret,
        'the_next':  '\n'.join(nxt),
    }


# ═══════════════════════════════════════════════════════════
# TEXT — find concepts, map connections, point forward
# ═══════════════════════════════════════════════════════════

def _text(text):
    if not text or not text.strip():
        return {
            'type':      'text',
            'the_point': 'Empty text.',
            'the_math':  {},
            'the_next':  '→ Give me something to read.',
        }

    from gump.knowledge import build_graph

    graph   = build_graph(text)
    n_words = len(text.split())
    nodes   = graph.get('nodes', []) if isinstance(graph, dict) else []
    edges   = graph.get('edges', []) if isinstance(graph, dict) else []

    point = [f"Text. {n_words} words. {len(nodes)} concepts. {len(edges)} connections."]
    if nodes:
        point.append(f"Key ideas: {', '.join(str(n) for n in nodes[:5])}")

    nxt = []
    if len(nodes) > 3:
        nxt.append("CONCEPT MAP:")
        nxt.append(f"  → {len(nodes)} ideas connected by {len(edges)} links.")
        nxt.append("  → Find the hub: gump.orgxray.analyze(graph)")
        nxt.append("  → Ideas that always appear together = coupled.")
        nxt.append("  → Ideas that appear alone = isolated gaps worth exploring.")
        nxt.append("  → Feed more text to see if the map grows or fragments.")
        nxt.append("  → Compare versions: gump.diverge(['v1 text', 'v2 text'])")
    else:
        nxt.append("→ Too little text for deep analysis. Try a longer passage.")
        nxt.append("→ Compare responses: gump.diverge(['response1', 'response2'])")

    return {
        'type':      'text',
        'the_point': '\n'.join(point),
        'the_math':  graph if isinstance(graph, dict) else {},
        'the_next':  '\n'.join(nxt),
    }
