"""
GUMP Verification — run every testable claim.

    python -m gump.verify

Prints PASS/FAIL for each claim. No external data needed.
Everything runs from what ships with pip install begump.
"""
import sys
import time
import numpy as np


def _test(name, fn):
    """Run a test, print PASS/FAIL, return bool."""
    try:
        result = fn()
        if result is False:
            print(f"  [FAIL] {name}")
            return False
        print(f"  [PASS] {name}")
        return True
    except Exception as e:
        print(f"  [FAIL] {name} — {e}")
        return False


def verify():
    """Run all verification tests."""
    t0 = time.time()
    import gump

    print(f"GUMP verification")
    print(f"version: {gump.__version__}")
    print()

    results = []

    # ═══ IMPORT & EXPORTS ═══
    print("Imports & exports:")
    results.append(_test("import gump", lambda: True))

    exports = [
        'ask', 'k_measure', 'tensions', 'EnergyTracker', 'interval_cost',
        'place', 'detect_crash', 'watch_training', 'machine',
        'reflect', 'pillar', 'compare',
        'entropy_profile', 'entropy_diagnose',
        'couple_profile', 'couple_quick',
        'diverge', 'diverge_batch', 'diverge_distance',
        'kill', 'kill_sweep',
    ]
    missing = [e for e in exports if not hasattr(gump, e)]
    results.append(_test(
        f"top-level exports: {len(exports) - len(missing)}/{len(exports)}",
        lambda: len(missing) == 0
    ))
    print()

    # ═══ CORE K/R/E/T ═══
    print("Core (K/R/E/T):")

    # k_measure on coupled signal
    def test_kmeasure_coupled():
        t = np.linspace(0, 1, 1000)
        sig = np.sin(2 * np.pi * 10 * t)
        r = gump.k_measure(sig)
        return r['verdict'] == 'COUPLED' and r['K'] > 0.9
    results.append(_test("k_measure(sine) → COUPLED, K>0.9", test_kmeasure_coupled))

    # k_measure on noise
    def test_kmeasure_noise():
        r = gump.k_measure(np.random.randn(1000))
        return r['verdict'] == 'RANDOM' and r['K'] < 0.1
    results.append(_test("k_measure(noise) → RANDOM, K<0.1", test_kmeasure_noise))

    # EnergyTracker
    def test_energy():
        tracker = gump.EnergyTracker()
        tracker.erase(1_000_000)
        s = tracker.summary()
        return 'joules' in s and abs(s['joules'] - 2.87e-15) < 1e-16
    results.append(_test("EnergyTracker.erase(1M) → 2.87e-15 J", test_energy))

    # interval_cost
    def test_interval():
        fifth = gump.interval_cost(3/2)
        tritone = gump.interval_cost(45/32)
        return isinstance(fifth, float) and isinstance(tritone, float) and fifth > 0
    results.append(_test("interval_cost(3/2) returns float", test_interval))

    # tensions
    def test_tensions():
        r = gump.tensions(np.sin(2 * np.pi * 5 * np.linspace(0, 1, 200)))
        return r is not None
    results.append(_test("tensions(signal) runs", test_tensions))

    # place
    def test_place():
        r = gump.place(['a', 'b', 'c'], [(0, 1), (1, 2)])
        return r is not None and len(r) == 3
    results.append(_test("place(nodes, edges) returns positions", test_place))

    # detect_crash
    def test_crash():
        r = gump.detect_crash(list(np.random.randn(100)))
        return r is not None
    results.append(_test("detect_crash(data) runs", test_crash))

    # watch_training
    def test_watch():
        r = gump.watch_training([0.5, 0.4, 0.3, 0.2, 0.1], [0.6, 0.5, 0.4, 0.3, 0.2])
        return r is not None
    results.append(_test("watch_training(train, test) runs", test_watch))

    print()

    # ═══ ASK ═══
    print("gump.ask() auto-detection:")

    def test_ask_protein():
        r = gump.ask("DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA")
        return r['type'] == 'protein' and 'the_point' in r
    results.append(_test("ask(protein) → type=protein", test_ask_protein))

    def test_ask_signal():
        r = gump.ask([1, 2, 3, 4, 3, 2, 1, 2, 3, 4])
        return r['type'] in ('signal', 'unknown') and 'the_point' in r
    results.append(_test("ask(signal) → returns the_point", test_ask_signal))

    def test_ask_text():
        r = gump.ask("What makes music good?")
        return 'the_point' in r
    results.append(_test("ask(text) → returns the_point", test_ask_text))

    print()

    # ═══ MACHINE ═══
    print("Machine (coupling engine):")

    def test_machine():
        r = gump.machine(['x', 'y', 'z'], [(0, 1), (1, 2)])
        return 'K' in r and 'R' in r and 'dimensionality' in r
    results.append(_test("machine(nodes, edges) → K/R/dimensionality", test_machine))

    print()

    # ═══ NEW TOOLS (v0.9) ═══
    print("New tools (v0.9):")

    # reflect
    def test_reflect():
        r = gump.reflect(['first thought', 'second thought', 'third thought',
                          'fourth thought', 'fifth thought'])
        return 'verdict' in r
    results.append(_test("reflect(segments) → verdict", test_reflect))

    # pillar
    def test_pillar():
        t = np.linspace(0, 1, 1000)
        drum = np.sin(2 * np.pi * 33 * t) * np.exp(-5 * t)
        r = gump.pillar(drum, 1000)
        return 'K' in r and r['K'] > 0.5
    results.append(_test("pillar(drum_hit) → K>0.5", test_pillar))

    def test_pillar_noise():
        r = gump.pillar(np.random.randn(1000), 1000)
        return r['K'] < 0.3
    results.append(_test("pillar(noise) → K<0.3", test_pillar_noise))

    # compare (FOR machine)
    def test_for():
        r = gump.compare(n=10, K_drive=1.5, steps=100, seed=42)
        return 'self' in r and 'for' in r
    results.append(_test("compare(SELF vs FOR) runs", test_for))

    print()

    # ═══ NEW TOOLS (v0.9.5) ═══
    print("New tools (v0.9.5):")

    # entropy
    def test_entropy():
        from gump.entropy import profile
        t = np.linspace(0, 1, 256)
        sig = np.sin(2 * np.pi * 10 * t)
        r = profile(sig, fs=256)
        return 'K' in r and 'diagnosis' in r and r['K'] > 0.5
    results.append(_test("entropy.profile(sine) → K>0.5, diagnosis present", test_entropy))

    def test_entropy_noise():
        from gump.entropy import diagnose
        d = diagnose(np.random.randn(256), fs=256)
        return isinstance(d, str) and len(d) > 0
    results.append(_test("entropy.diagnose(noise) → returns string", test_entropy_noise))

    # couple
    def test_couple():
        from gump.couple import profile as cp
        t = np.linspace(0, 1, 256)
        a = np.sin(2 * np.pi * 5 * t)
        b = np.sin(2 * np.pi * 5 * t + 0.1)
        r = cp(a, b, fs=256)
        return 'K_overall' in r and 'diagnosis' in r
    results.append(_test("couple.profile(similar sines) → K_overall present", test_couple))

    def test_couple_quick():
        from gump.couple import quick
        t = np.linspace(0, 1, 256)
        k = quick(np.sin(2 * np.pi * 5 * t), np.random.randn(256))
        return isinstance(k, str) and 'K=' in k
    results.append(_test("couple.quick(sine, noise) → verdict string with K=", test_couple_quick))

    # diverge
    def test_diverge():
        from gump.diverge import diverge
        r = diverge(["the answer is 42", "the answer is 42", "the answer is 37"])
        return 'divergence_score' in r and 'consensus' in r and r['divergence_score'] > 0
    results.append(_test("diverge(['42','42','37']) → divergence>0", test_diverge))

    # kill
    def test_kill():
        from gump.kill import kill
        r = kill("pi", 3.14159265358979)
        return r['verdict'] == 'PASS' and r['ppm'] < 1.0
    results.append(_test("kill('pi', 3.14159) → PASS, ppm<1", test_kill))

    def test_kill_killed():
        from gump.kill import kill
        r = kill("pi", 3.0)
        return r['verdict'] == 'KILLED'
    results.append(_test("kill('pi', 3.0) → KILLED", test_kill_killed))

    print()

    # ═══ CONSTANTS ═══
    print("Constants:")

    def test_constants():
        from gump.core import PHI, LANDAUER_PER_BIT
        from gump.machine import machine
        K_CEIL = 256 / 137.036
        return (abs(PHI - 1.6180339887) < 1e-6 and
                abs(LANDAUER_PER_BIT - 2.87e-21) < 1e-23 and
                abs(K_CEIL - 1.868) < 0.001)
    results.append(_test("PHI, LANDAUER_PER_BIT, K_CEILING = 256α", test_constants))

    print()

    # ═══ BLIND DISCRIMINATION ═══
    print("Blind discrimination (coupled vs random):")

    def test_discrimination():
        random_Ks = []
        coupled_Ks = []
        for i in range(50):
            rng = np.random.RandomState(i)
            random_Ks.append(gump.k_measure(rng.randn(200))['K'])
            sig = np.sin(2 * np.pi * 7 * np.linspace(0, 1, 200)) + 0.3 * rng.randn(200)
            coupled_Ks.append(gump.k_measure(sig)['K'])
        # AUC: fraction of coupled > random pairs
        auc = sum(1 for c in coupled_Ks for r in random_Ks if c > r) / (50 * 50)
        return auc > 0.95
    results.append(_test("50 random vs 50 coupled → AUC > 0.95", test_discrimination))

    print()

    # ═══ SUMMARY ═══
    passed = sum(results)
    total = len(results)
    elapsed = time.time() - t0

    print("=" * 50)
    print(f"RESULT: {passed}/{total} passed in {elapsed:.1f}s")
    if passed == total:
        print("ALL PASS — every testable claim verified.")
    else:
        print(f"WARNING: {total - passed} tests failed.")
    print("=" * 50)

    return passed == total


if __name__ == '__main__':
    success = verify()
    sys.exit(0 if success else 1)
