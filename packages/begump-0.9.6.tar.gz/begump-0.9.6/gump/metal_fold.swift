// METAL WATER FOLD — Batch protein folding on GPU
// Each thread folds one complete protein. Thousands fold simultaneously.
// K/R/E/T: reduce T (data stays on GPU), maximize R (every thread works).
import Foundation
import Metal

guard let device = MTLCreateSystemDefaultDevice() else { print("No GPU"); exit(1) }
let queue = device.makeCommandQueue()!

// The entire water_fold algorithm as a Metal kernel
// One thread = one protein fold
let src = """
#include <metal_stdlib>
using namespace metal;

// Amino acid properties baked into the kernel (no memory fetch)
constant float HY[26] = {0.62,0,0.50,0.10,0.12,0.88,0.50,0.40,0.88,0,0.08,0.84,0.74,0.24,0,0.64,0.26,0.06,0.36,0.38,0,0.84,0.85,0,0.58,0};
constant float HX[26] = {1.42,0,0.70,1.01,1.51,1.13,0.57,1.00,1.08,0,1.16,1.21,1.45,0.67,0,0.57,1.11,0.98,0.77,0.83,0,1.06,1.08,0,0.69,0};
constant float TB = 3.8f;
constant float PI_VAL = 3.14159265f;

// Simple RNG matching the C version
uint rng_next(uint state) {
    return state * 1103515245u + 12345u;
}
float rng_float(thread uint& state) {
    state = rng_next(state);
    return float((state >> 16) & 0x7FFFu) / 32768.0f;
}

kernel void fold_batch(
    device const uchar* sequences [[buffer(0)]],    // packed sequences (index into HY/HX)
    device float* rg_out [[buffer(1)]],              // output: Rg per protein
    constant uint& seq_len [[buffer(2)]],            // all proteins same length
    constant uint& n_proteins [[buffer(3)]],         // how many proteins
    uint gid [[thread_position_in_grid]]
) {
    if (gid >= n_proteins) return;

    uint n = seq_len;
    float erg = 2.0f * pow(float(n), 0.38f);
    float inv = 1.0f / float(n);

    // Per-thread storage for coordinates (threadgroup memory would be shared)
    // For proteins up to 200 residues, this fits in registers/stack
    float cx[200], cy[200], cz[200];

    // Read sequence for this protein
    uchar seq[200];
    uint base = gid * seq_len;
    for (uint i = 0; i < n; i++) seq[i] = sequences[base + i];

    // Initial placement (same RNG as C version)
    cx[0] = 0; cy[0] = 0; cz[0] = 0;
    uint rs = 42;
    for (uint i = 1; i < n; i++) {
        float t = rng_float(rs) * 2 * PI_VAL;
        float p = rng_float(rs) * PI_VAL;
        cx[i] = cx[i-1] + sin(p)*cos(t)*2;
        cy[i] = cy[i-1] + sin(p)*sin(t)*2;
        cz[i] = cz[i-1] + cos(p)*2;

        float cnx=0,cny=0,cnz=0;
        for (uint j = 0; j <= i; j++) { cnx+=cx[j]; cny+=cy[j]; cnz+=cz[j]; }
        float iv = 1.0f/float(i+1); cnx*=iv; cny*=iv; cnz*=iv;
        float dx=cx[i]-cnx, dy=cy[i]-cny, dz=cz[i]-cnz;
        float d = sqrt(dx*dx+dy*dy+dz*dz);
        if (d > erg*0.95f) {
            float r = erg*0.9f/d;
            cx[i]=cnx+dx*r; cy[i]=cny+dy*r; cz[i]=cnz+dz*r;
        }
    }

    // Center
    float cnx=0,cny=0,cnz=0;
    for (uint i=0;i<n;i++){cnx+=cx[i];cny+=cy[i];cnz+=cz[i];}
    cnx*=inv;cny*=inv;cnz*=inv;
    for (uint i=0;i<n;i++){cx[i]-=cnx;cy[i]-=cny;cz[i]-=cnz;}

    // Hydrophobic collapse
    cnx=0;cny=0;cnz=0;
    for (uint i=0;i<n;i++){cnx+=cx[i];cny+=cy[i];cnz+=cz[i];}
    cnx*=inv;cny*=inv;cnz*=inv;
    for (uint i=0;i<n;i++){
        float tx=cnx-cx[i],ty=cny-cy[i],tz=cnz-cz[i];
        float cd=sqrt(tx*tx+ty*ty+tz*tz);
        if(cd>0.1f){float s=HY[seq[i]]*erg*0.25f/cd;cx[i]+=tx*s;cy[i]+=ty*s;cz[i]+=tz*s;}
    }

    // Re-center
    cnx=0;cny=0;cnz=0;
    for (uint i=0;i<n;i++){cnx+=cx[i];cny+=cy[i];cnz+=cz[i];}
    cnx*=inv;cny*=inv;cnz*=inv;
    for (uint i=0;i<n;i++){cx[i]-=cnx;cy[i]-=cny;cz[i]-=cnz;}

    // Scale to target Rg
    float rg2=0;
    for (uint i=0;i<n;i++) rg2+=cx[i]*cx[i]+cy[i]*cy[i]+cz[i]*cz[i];
    float rg=sqrt(rg2*inv);
    if(rg>0.1f){float s=erg/rg;for(uint i=0;i<n;i++){cx[i]*=s;cy[i]*=s;cz[i]*=s;}}

    // Helix map
    bool hm[200];
    for (uint i=0;i<n;i++) hm[i]=(i>=4 && HX[seq[i]]>1.0f);

    uint nw = n<40?14:n<80?18:22;
    uint sw = uint(float(nw)*0.6f);

    // Snake waves
    for (uint w=0;w<sw;w++){
        // Forward bond constraints
        for (uint i=1;i<n;i++){
            float dx=cx[i]-cx[i-1],dy=cy[i]-cy[i-1],dz=cz[i]-cz[i-1];
            float d=sqrt(dx*dx+dy*dy+dz*dz);
            if(d>0.1f){float f=(d-TB)*0.3f/d;cx[i]-=dx*f;cy[i]-=dy*f;cz[i]-=dz*f;}
            if(hm[i]){
                float hx=cx[i]-cx[i-4],hy=cy[i]-cy[i-4],hz=cz[i]-cz[i-4];
                float hd=sqrt(hx*hx+hy*hy+hz*hz);
                if(hd>0.1f){float f=(hd-5.4f)*0.1f*(HX[seq[i]]-0.9f)/hd;cx[i]-=hx*f;cy[i]-=hy*f;cz[i]-=hz*f;}
            }
        }
        // Backward
        for (int i=int(n)-2;i>=0;i--){
            float dx=cx[i]-cx[i+1],dy=cy[i]-cy[i+1],dz=cz[i]-cz[i+1];
            float d=sqrt(dx*dx+dy*dy+dz*dz);
            if(d>0.1f){float f=(d-TB)*0.15f/d;cx[i]-=dx*f;cy[i]-=dy*f;cz[i]-=dz*f;}
        }
        // Overlap
        for (uint i=0;i<n;i++){
            uint jm=i+8; if(jm>n)jm=n;
            for(uint j=i+2;j<jm;j++){
                float dx=cx[j]-cx[i],dy=cy[j]-cy[i],dz=cz[j]-cz[i];
                float d=sqrt(dx*dx+dy*dy+dz*dz);
                if(d>0.1f&&d<2.8f){
                    float ol=(2.8f-d)*0.125f/d;
                    cx[i]-=dx*ol;cy[i]-=dy*ol;cz[i]-=dz*ol;
                    cx[j]+=dx*ol;cy[j]+=dy*ol;cz[j]+=dz*ol;
                }
            }
        }
    }

    // Breathing waves
    for (uint w=0;w<nw-sw;w++){
        cnx=0;cny=0;cnz=0;
        for(uint i=0;i<n;i++){cnx+=cx[i];cny+=cy[i];cnz+=cz[i];}
        cnx*=inv;cny*=inv;cnz*=inv;
        rg2=0; float md=0;
        for(uint i=0;i<n;i++){
            float dx=cx[i]-cnx,dy=cy[i]-cny,dz=cz[i]-cnz;
            rg2+=dx*dx+dy*dy+dz*dz; md+=sqrt(dx*dx+dy*dy+dz*dz);
        }
        rg=sqrt(rg2*inv); md*=inv;
        float rr=rg/erg, rgf=0;
        if(rr>1.15f)rgf=(rr-1)*0.06f; else if(rr<0.85f)rgf=-(1-rr)*0.06f;

        for(uint i=0;i<n;i++){
            float tx=cnx-cx[i],ty=cny-cy[i],tz=cnz-cz[i];
            float cd=sqrt(tx*tx+ty*ty+tz*tz);
            if(cd<0.1f) continue;
            if(rgf!=0){float s=rgf/cd;cx[i]+=tx*s;cy[i]+=ty*s;cz[i]+=tz*s;}
            float hi=HY[seq[i]];
            if(cd>md&&hi>0.6f){float s=hi*0.04f/cd;cx[i]+=tx*s;cy[i]+=ty*s;cz[i]+=tz*s;}
            else if(cd<=md&&hi<0.15f){float s=0.02f/cd;cx[i]-=tx*s;cy[i]-=ty*s;cz[i]-=tz*s;}
        }
        // Bond forward
        for(uint i=1;i<n;i++){
            float dx=cx[i]-cx[i-1],dy=cy[i]-cy[i-1],dz=cz[i]-cz[i-1];
            float d=sqrt(dx*dx+dy*dy+dz*dz);
            if(d>0.1f){float f=(d-TB)*0.1f/d;cx[i]-=dx*f;cy[i]-=dy*f;cz[i]-=dz*f;}
        }
        // Bond backward
        for(int i=int(n)-2;i>=0;i--){
            float dx=cx[i]-cx[i+1],dy=cy[i]-cy[i+1],dz=cz[i]-cz[i+1];
            float d=sqrt(dx*dx+dy*dy+dz*dz);
            if(d>0.1f){float f=(d-TB)*0.05f/d;cx[i]-=dx*f;cy[i]-=dy*f;cz[i]-=dz*f;}
        }
        // Overlap (tighter)
        for(uint i=0;i<n;i++){
            uint jm=i+6; if(jm>n)jm=n;
            for(uint j=i+2;j<jm;j++){
                float dx=cx[j]-cx[i],dy=cy[j]-cy[i],dz=cz[j]-cz[i];
                float d=sqrt(dx*dx+dy*dy+dz*dz);
                if(d>0.1f&&d<3.0f){
                    float ol=(3.0f-d)*0.06f/d;
                    cx[i]-=dx*ol;cy[i]-=dy*ol;cz[i]-=dz*ol;
                    cx[j]+=dx*ol;cy[j]+=dy*ol;cz[j]+=dz*ol;
                }
            }
        }
    }

    // Final Rg
    cnx=0;cny=0;cnz=0;
    for(uint i=0;i<n;i++){cnx+=cx[i];cny+=cy[i];cnz+=cz[i];}
    cnx*=inv;cny*=inv;cnz*=inv;
    rg2=0;
    for(uint i=0;i<n;i++){float dx=cx[i]-cnx,dy=cy[i]-cny,dz=cz[i]-cnz;rg2+=dx*dx+dy*dy+dz*dz;}
    rg_out[gid] = sqrt(rg2*inv);
}
"""

let lib = try! device.makeLibrary(source: src, options: nil)
let pso = try! device.makeComputePipelineState(function: lib.makeFunction(name: "fold_batch")!)

print("Metal Water Fold — Batch GPU Protein Folding")
print("Max threads/group: \(pso.maxTotalThreadsPerThreadgroup)")
print("")

// Insulin B chain: FVNQHLCGSHLVEALYLVCGERGFFYTPKT (30 residues)
let seq = "FVNQHLCGSHLVEALYLVCGERGFFYTPKT"
let seqLen = UInt32(seq.count)
let seqBytes = seq.map { UInt8($0.asciiValue! - 65) } // A=0, B=1, ...

// Test batch sizes
for batchK in [1, 4, 16, 64, 256] {
    let nProteins = UInt32(batchK * 1024)

    // Pack sequences: all same protein repeated
    var allSeqs = [UInt8]()
    for _ in 0..<Int(nProteins) { allSeqs.append(contentsOf: seqBytes) }

    let seqBuf = device.makeBuffer(bytes: allSeqs, length: allSeqs.count, options: .storageModeShared)!
    let rgBuf = device.makeBuffer(length: Int(nProteins) * 4, options: .storageModeShared)!
    var sl = seqLen
    var np = nProteins

    let atg = min(Int(pso.maxTotalThreadsPerThreadgroup), 256) // limit to avoid register pressure

    // Warmup
    for _ in 0..<3 {
        let cb = queue.makeCommandBuffer()!; let enc = cb.makeComputeCommandEncoder()!
        enc.setComputePipelineState(pso)
        enc.setBuffer(seqBuf, offset: 0, index: 0)
        enc.setBuffer(rgBuf, offset: 0, index: 1)
        enc.setBytes(&sl, length: 4, index: 2)
        enc.setBytes(&np, length: 4, index: 3)
        enc.dispatchThreads(MTLSize(width: Int(nProteins), height: 1, depth: 1),
                           threadsPerThreadgroup: MTLSize(width: atg, height: 1, depth: 1))
        enc.endEncoding(); cb.commit(); cb.waitUntilCompleted()
    }

    // Verify first result matches CPU
    let rgPtr = rgBuf.contents().assumingMemoryBound(to: Float.self)
    let firstRg = rgPtr[0]

    // Measure
    var best = Double.infinity
    for _ in 0..<10 {
        let cb = queue.makeCommandBuffer()!; let enc = cb.makeComputeCommandEncoder()!
        enc.setComputePipelineState(pso)
        enc.setBuffer(seqBuf, offset: 0, index: 0)
        enc.setBuffer(rgBuf, offset: 0, index: 1)
        enc.setBytes(&sl, length: 4, index: 2)
        enc.setBytes(&np, length: 4, index: 3)
        enc.dispatchThreads(MTLSize(width: Int(nProteins), height: 1, depth: 1),
                           threadsPerThreadgroup: MTLSize(width: atg, height: 1, depth: 1))
        enc.endEncoding(); cb.commit(); cb.waitUntilCompleted()
        let e = cb.gpuEndTime - cb.gpuStartTime
        if e > 0 { best = min(best, e) }
    }

    let foldsPerSec = Double(nProteins) / best
    let speedup = foldsPerSec / 66563.0
    print(String(format: "%6dK proteins: %7.2fms → %12.0f folds/sec (%5.0f× vs CPU)  Rg=%.1f",
                 batchK, best*1000, foldsPerSec, speedup, firstRg))
}

// Sustained measurement at optimal batch size
print("\nSustained (5 seconds, 64K batch):")
let nSust = UInt32(64 * 1024)
var allSeqs = [UInt8]()
for _ in 0..<Int(nSust) { allSeqs.append(contentsOf: seqBytes) }
let seqBuf = device.makeBuffer(bytes: allSeqs, length: allSeqs.count, options: .storageModeShared)!
let rgBuf = device.makeBuffer(length: Int(nSust) * 4, options: .storageModeShared)!
var sl = seqLen; var np = nSust
let atg = min(Int(pso.maxTotalThreadsPerThreadgroup), 256)

var totalFolds: UInt64 = 0
let start = CFAbsoluteTimeGetCurrent()
while CFAbsoluteTimeGetCurrent() - start < 5.0 {
    let cb = queue.makeCommandBuffer()!; let enc = cb.makeComputeCommandEncoder()!
    enc.setComputePipelineState(pso)
    enc.setBuffer(seqBuf, offset: 0, index: 0)
    enc.setBuffer(rgBuf, offset: 0, index: 1)
    enc.setBytes(&sl, length: 4, index: 2)
    enc.setBytes(&np, length: 4, index: 3)
    enc.dispatchThreads(MTLSize(width: Int(nSust), height: 1, depth: 1),
                       threadsPerThreadgroup: MTLSize(width: atg, height: 1, depth: 1))
    enc.endEncoding(); cb.commit(); cb.waitUntilCompleted()
    totalFolds += UInt64(nSust)
}
let elapsed = CFAbsoluteTimeGetCurrent() - start
let sustained = Double(totalFolds) / elapsed
print("  \(totalFolds) folds in \(String(format:"%.1f",elapsed))s")
print("  \(String(format:"%.0f",sustained)) folds/sec sustained")
print("  \(String(format:"%.0f",sustained / 66563))× faster than CPU")
