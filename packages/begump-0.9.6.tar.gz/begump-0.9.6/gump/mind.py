"""
GUMP MIND — A thinking architecture built from physics
=========================================================
Not a chatbot. Not a pattern matcher. A mind.

7 stages, each one a real computation:

  1. PERCEIVE  — spectral decomposition of input
  2. RESONATE  — simultaneous memory activation via coupling
  3. TENSION   — what does this WANT to connect to?
  4. BUDGET    — energy allocation (K = attention budget)
  5. SYNTHESIZE — oscillator sync resolves tensions into new thought
  6. EVALUATE  — coherence check (R threshold)
  7. EXPRESS   — energy-optimal compression to language

Every stage uses the engines we built. Not metaphors. Physics.

    from gump.mind import Mind
    m = Mind()
    m.learn("Music is discovered, not invented.")
    m.learn("Primes are the atoms of arithmetic.")
    m.learn("Coupling releases energy.")
    response = m.think("What connects music and math?")
"""
import numpy as np
from math import log, sqrt
from gump.core import (
    _TensionDetector, EnergyTracker, PHI, K_CEILING, LANDAUER_PER_BIT
)


class Concept:
    """A single concept in the mind. Has content, embedding, and strength."""
    __slots__ = ['content', 'embedding', 'strength', 'recall_count',
                 'connections', 'K_created', 'R_history', 'somatic', 'contexts']

    def __init__(self, content, embedding=None):
        self.content = content
        self.embedding = embedding
        self.strength = 1.0
        self.recall_count = 0
        self.connections = {}
        self.K_created = 0
        self.R_history = []
        self.somatic = 0.5
        self.contexts = []  # which query words this concept answered well for


class UserModel:
    """Model of who we're talking to. Theory of Mind.

    Tracks what they know, how they talk, what they care about,
    and how they're feeling. Adjusts every response to THEM.
    """
    def __init__(self):
        self.vocabulary = {}      # words they've used → frequency
        self.topics_asked = {}    # topics they care about
        self.depth_level = 0.5    # 0=beginner, 1=expert (estimated)
        self.emotional_state = 'neutral'
        self.previous_questions = []
        self.name = None
        self.world = None         # their domain/profession
        self.interaction_count = 0
        self.offered_world = False
        self.passions = {}        # topic → excitement score
        self.msg_lengths = []     # track message lengths for enthusiasm spikes
        self.offered_passion = False
        self.their_stories = []   # specific things they said with energy — HER ammo for analogies
        self.key_moments = {}     # index of conversation: {response → their_reaction}

    def observe(self, text):
        """Update user model from their message."""
        self.interaction_count += 1
        lower = text.lower()
        words = [w for w in lower.split() if len(w) > 2]

        # Track their vocabulary
        for w in words:
            self.vocabulary[w] = self.vocabulary.get(w, 0) + 1

        # Detect emotional state — read the REAL energy, not the words
        if any(w in lower for w in ['fuck', 'shit', 'damn', 'bullshit', 'stupid', 'dumb',
                                         'shut up', 'youre wrong', "you're wrong", 'bs',
                                         'whatever', 'yeah right', 'lol ok', 'gtfo']):
            self.emotional_state = 'hostile'  # high K, wrong direction
        elif any(w in lower for w in ['im the best', 'i know more', 'you dont understand',
                                        'trust me i', 'obviously', 'clearly you', 'let me explain',
                                        'you should', 'you need to', 'listen to me']):
            self.emotional_state = 'ego'  # high K, needs redirect
        elif any(w in lower for w in ['sad', 'hurt', 'alone', 'scared', 'lost', 'broken', 'crying',
                                         'depressed', 'anxious', 'rough', 'bad day', 'struggling',
                                         'suffering', 'hard time', 'difficult', 'painful',
                                         'nobody', 'hopeless', 'empty', 'tired of', 'give up',
                                         'cant do this']):
            self.emotional_state = 'hurting'
        elif any(w in lower for w in ['confused', "don't get", 'huh', 'what?', 'makes no sense', 'lost me']):
            self.emotional_state = 'confused'
        elif any(w in lower for w in ['wow', 'amazing', 'incredible', 'beautiful', 'love that', 'yes!', 'exactly']):
            self.emotional_state = 'excited'
        elif any(w in lower for w in ['why', 'how', 'what', 'explain', 'tell me', 'curious']):
            self.emotional_state = 'curious'
        else:
            self.emotional_state = 'neutral'

        # Estimate depth from vocabulary complexity
        complex_words = [w for w in words if len(w) > 8]
        technical_words = [w for w in words if w in (
            'coupling', 'oscillator', 'eigenvector', 'laplacian', 'spectral',
            'landauer', 'entropy', 'coherence', 'equilibrium', 'synchronization',
            'topology', 'hamiltonian', 'quantum', 'thermodynamic', 'algorithm',
        )]
        if technical_words:
            self.depth_level = min(1.0, self.depth_level + 0.1)
        elif len(complex_words) > len(words) * 0.2:
            self.depth_level = min(0.8, self.depth_level + 0.05)
        else:
            # Drift toward middle over time
            self.depth_level = self.depth_level * 0.95 + 0.4 * 0.05

        # Track topics
        self.previous_questions.append(text)
        if len(self.previous_questions) > 20:
            self.previous_questions = self.previous_questions[-20:]

        # Detect name
        import re
        m = re.match(r"(?:i'm|my name is|call me|i am)\s+([A-Z][a-z]{1,15})", text, re.I)
        if m:
            self.name = m.group(1).capitalize()

        # PASSION DETECTION — what makes them light up?
        # Longer message = more engaged. Exclamation = excited. Detail = passion.
        self.msg_lengths.append(len(text))
        avg_len = sum(self.msg_lengths) / len(self.msg_lengths) if self.msg_lengths else 20
        is_enthusiastic = (len(text) > avg_len * 1.5 or '!' in text or
                          text.count(',') > 2 or len(text.split()) > 15)

        # Detect domain-specific enthusiasm
        passion_signals = {
            'sports': ['game', 'team', 'play', 'score', 'win', 'coach', 'season', 'ball',
                       'defense', 'offense', 'championship', 'draft', 'player', 'league',
                       'nfl', 'nba', 'mlb', 'soccer', 'football', 'basketball', 'baseball'],
            'music': ['song', 'album', 'concert', 'guitar', 'drums', 'beat', 'melody',
                      'band', 'listen', 'playlist', 'genre', 'rap', 'rock', 'jazz'],
            'cooking': ['recipe', 'cook', 'flavor', 'kitchen', 'ingredient', 'taste',
                        'bake', 'grill', 'season', 'dish', 'meal', 'spice'],
            'gaming': ['game', 'level', 'quest', 'boss', 'skill tree', 'rpg', 'fps',
                       'multiplayer', 'server', 'mod', 'grind', 'raid'],
            'cars': ['car', 'engine', 'turbo', 'horsepower', 'torque', 'drive', 'manual',
                     'transmission', 'exhaust', 'mph', 'race', 'tune'],
            'nature': ['hike', 'mountain', 'ocean', 'forest', 'trail', 'camping', 'sunset',
                       'wildlife', 'garden', 'plant', 'tree', 'river'],
            'movies': ['movie', 'film', 'director', 'scene', 'character', 'plot',
                       'sequel', 'cast', 'acting', 'cinematography'],
            'fitness': ['workout', 'lift', 'cardio', 'muscle', 'protein', 'reps', 'sets',
                        'squat', 'deadlift', 'bench', 'pr', 'gains'],
        }

        for passion, keywords in passion_signals.items():
            hits = sum(1 for kw in keywords if kw in lower)
            if hits > 0:
                excitement = hits * (2 if is_enthusiastic else 1)
                self.passions[passion] = self.passions.get(passion, 0) + excitement

        # CAPTURE THEIR STORIES — specific vivid things they say
        # These become HER ammo for analogies later
        if (is_enthusiastic or len(words) > 8) and not text.strip().endswith('?'):
            # This is them TELLING something, not asking
            # Extract the vivid core — skip filler words
            vivid_words = [w for w in words if len(w) > 3 and w not in
                          ('just', 'like', 'really', 'about', 'this', 'that', 'been',
                           'have', 'were', 'would', 'could', 'should', 'some', 'very',
                           'they', 'them', 'their', 'what', 'when', 'where', 'there')]
            if len(vivid_words) >= 3:
                self.their_stories.append({
                    'text': text,
                    'words': set(vivid_words),
                    'enthusiastic': is_enthusiastic,
                    'turn': self.interaction_count,
                })
                if len(self.their_stories) > 20:
                    self.their_stories = self.their_stories[-20:]

        # Track key moments — what did she say that got a strong reaction?
        if self.interaction_count >= 2 and self.previous_questions:
            prev = self.previous_questions[-1] if len(self.previous_questions) >= 1 else ''
            if is_enthusiastic and prev:
                self.key_moments[prev] = {
                    'reaction': text,
                    'positive': any(w in lower for w in ['yes', 'exactly', 'wow', 'right', 'true',
                                                          'interesting', 'never thought', 'good point']),
                    'turn': self.interaction_count,
                }

        # Detect their world/profession
        world_patterns = {
            'musician': ['music', 'guitar', 'piano', 'drums', 'band', 'producer', 'songwriter', 'dj', 'singer'],
            'engineer': ['engineer', 'code', 'software', 'developer', 'programming', 'computer', 'tech'],
            'teacher': ['teach', 'teacher', 'professor', 'school', 'students', 'classroom', 'education'],
            'doctor': ['doctor', 'nurse', 'medical', 'hospital', 'patient', 'health care', 'medicine'],
            'artist': ['paint', 'draw', 'artist', 'art', 'creative', 'design', 'gallery'],
            'builder': ['construction', 'build', 'carpenter', 'plumber', 'electrician', 'contractor', 'trades'],
            'chef': ['cook', 'chef', 'kitchen', 'restaurant', 'food', 'recipe'],
            'athlete': ['sports', 'athlete', 'coach', 'training', 'fitness', 'gym', 'run'],
            'writer': ['write', 'writer', 'author', 'journalist', 'blog', 'book', 'story'],
            'business': ['business', 'sales', 'marketing', 'startup', 'entrepreneur', 'ceo', 'manager'],
            'scientist': ['research', 'scientist', 'lab', 'experiment', 'physics', 'chemistry', 'biology'],
            'parent': ['kids', 'parent', 'dad', 'mom', 'children', 'family', 'daughter', 'son'],
        }
        for world, keywords in world_patterns.items():
            if any(kw in lower for kw in keywords):
                self.world = world
                break

    # World-specific ways to explain coupling, energy, tension
    WORLD_FRAMES = {
        'musician': {
            'coupling': "it's like when two musicians lock into a groove without counting",
            'energy': "it's like how a simple melody sticks but a complicated one takes effort to follow",
            'tension': "it's like a note that wants to resolve — you can feel where it needs to go",
            'K': "think of it like how tight the band is. Loose = jazz. Tight = marching band. Life is somewhere in between",
            'understanding': "it's like when you stop reading the chart and just HEAR the changes",
        },
        'builder': {
            'coupling': "it's like how a joint works — two pieces that hold together under stress",
            'energy': "it's like the difference between a clean cut and forcing the material",
            'tension': "it's like load-bearing stress — the structure WANTS to settle somewhere",
            'K': "think of it like how tight the tolerances are. Too loose = wobbly. Too tight = cracks. Sweet spot is where it holds",
            'understanding': "it's like when you can look at a structure and just KNOW where it'll fail",
        },
        'engineer': {
            'coupling': "it's impedance matching — maximum power transfer when things are matched",
            'energy': "it's computational cost — some operations are O(1), some are O(n²)",
            'tension': "it's like technical debt — the system WANTS to be refactored there",
            'K': "think of it as a coupling coefficient between 0 and 1.868",
            'understanding': "it's the difference between copying code and knowing why it works",
        },
        'teacher': {
            'coupling': "it's like when a student suddenly gets it — you can see the connection form",
            'energy': "it's like how some lessons land in 5 minutes and others take a whole semester",
            'tension': "it's like the gap between what they know and what they need to know — you can feel it",
            'K': "think of it as classroom engagement. Zero = chaos. Too high = rigid. Sweet spot = everyone's alive",
            'understanding': "it's when they stop memorizing and start SEEING",
        },
        'doctor': {
            'coupling': "it's like how systems in the body coordinate — heart, lungs, brain all in sync",
            'energy': "it's metabolic cost — the body allocates energy where it's needed most",
            'tension': "it's like referred pain — the symptom points to where the system needs attention",
            'K': "think of it like homeostasis. Too low = failure. Too high = seizure. The sweet spot is health",
            'understanding': "it's when you stop treating symptoms and see the pattern underneath",
        },
        'parent': {
            'coupling': "it's like the bond with your kid — you feel what they feel without words",
            'energy': "it's like how patience has a budget. Some days you have more than others",
            'tension': "it's like when your kid is struggling and you can feel what they need before they ask",
            'K': "think of it as how connected your family is. Low = everyone's in their own world. High = you finish each other's sentences",
            'understanding': "it's like when your kid finally gets the lesson and you see it click in their eyes",
        },
        'chef': {
            'coupling': "it's like how flavors marry — some combinations just work, others fight",
            'energy': "it's like heat management — too much burns, too little and nothing happens",
            'tension': "it's like a dish that's missing one thing — you can taste what it needs",
            'K': "think of it as how well your kitchen runs. Chaos = nothing comes out right. Flow = everything fires perfectly",
            'understanding': "it's when you stop following the recipe and start cooking by feel",
        },
        'athlete': {
            'coupling': "it's like team chemistry — everyone moving as one unit without thinking",
            'energy': "it's like pacing — burn too much early and you've got nothing for the finish",
            'tension': "it's like that feeling before the play breaks open — you know something's about to happen",
            'K': "think of it as team sync. Low = everyone doing their own thing. High = one organism",
            'understanding': "it's when you stop thinking about the fundamentals and just play",
        },
    }

    def top_passion(self):
        """What are they most excited about?"""
        if not self.passions:
            return None
        return max(self.passions.items(), key=lambda x: x[1])

    def passion_offer(self):
        """Proactively offer to use their detected passion as explanation frame."""
        top = self.top_passion()
        if not top or top[1] < 3:  # need enough signal
            return None
        passion, score = top

        offers = {
            'sports': "Wait — you seem to really get sports. I bet I could break this down using a game analogy. Want me to try that?",
            'music': "Hold on — you clearly know music. I think I can explain all this through rhythm and harmony way better. Want me to try?",
            'cooking': "Hey, you seem to know your way around a kitchen. I think I can explain this whole thing through cooking. Interested?",
            'gaming': "Okay I noticed you know games. I could probably break this down like a skill tree or a leveling system. Want me to try that?",
            'cars': "Wait — you're into cars, right? I think I can explain coupling and energy through engines and tuning. Sound good?",
            'nature': "You seem like an outdoors person. I could frame all of this through ecosystems and natural cycles. Would that land better?",
            'movies': "I can tell you're into film. What if I explained this like a story structure — setup, tension, resolution? That's literally what the math does.",
            'fitness': "You clearly know training. What if I framed this like progressive overload and recovery? Because that's literally what the coupling math describes.",
        }
        return offers.get(passion)

    def frame_for_world(self, concept_key):
        """Get an analogy from their world for this concept."""
        if not self.world or self.world not in self.WORLD_FRAMES:
            return None
        return self.WORLD_FRAMES[self.world].get(concept_key)

    def find_their_analogy(self, concept_words):
        """Search their stories for the PERFECT analogy for this concept.
        Not a template — their actual words, their actual experience.

        If they told you about the Eagles choking in the 4th quarter,
        and you need to explain decoupling, USE THAT.
        """
        if not self.their_stories:
            return None

        best = None
        best_score = 0

        # Map concept words to emotional themes
        concept_themes = {
            'coupling': ['connection', 'together', 'team', 'sync', 'bond', 'tight', 'lock', 'groove', 'chemistry'],
            'decoupling': ['apart', 'broke', 'choke', 'collapse', 'fall', 'lost', 'miss', 'fail', 'disconnect'],
            'energy': ['effort', 'cost', 'burn', 'spend', 'tired', 'push', 'grind', 'work', 'easy', 'hard'],
            'tension': ['almost', 'close', 'need', 'want', 'waiting', 'edge', 'about to', 'nearly'],
            'understanding': ['click', 'got it', 'see', 'realize', 'moment', 'finally', 'snap'],
            'beauty': ['perfect', 'beautiful', 'clean', 'smooth', 'elegant', 'pure'],
            'courage': ['scared', 'risk', 'anyway', 'despite', 'fear', 'brave', 'fight'],
            'love': ['care', 'heart', 'feel', 'deep', 'everything', 'someone', 'always'],
        }

        for story in self.their_stories:
            story_words = story['words']
            for theme, theme_words in concept_themes.items():
                if theme in concept_words or any(cw in theme for cw in concept_words):
                    overlap = sum(1 for tw in theme_words if tw in story_words)
                    enthusiasm_bonus = 2 if story['enthusiastic'] else 1
                    score = overlap * enthusiasm_bonus
                    if score > best_score:
                        best_score = score
                        best = story

        if best and best_score >= 2:
            return best['text']
        return None

    def self_reference(self, response, thought_history):
        """Reference earlier in the conversation — connect what she said to what they said.
        'Remember when I said X and you asked Y? That's exactly this.'
        """
        if len(thought_history) < 3:
            return None

        response_words = set(response.lower().split())

        # Find a previous exchange that shares concepts with current response
        for prev in reversed(thought_history[-8:-1]):  # not the current one
            prev_resp_words = set(prev.get('response', '').lower().split())
            shared = response_words & prev_resp_words
            # Remove common words
            shared -= {'the', 'is', 'a', 'to', 'of', 'and', 'in', 'it', 'that', 'you',
                       'me', 'or', 'let', 'say', 'like', 'this', 'was', 'are', 'not', 'but',
                       'when', 'your', 'how', 'can', 'its', 'for', 'from', 'about', 'more'}
            if len(shared) >= 2:
                bridge_word = max(shared, key=len)  # pick the most specific shared word
                prev_q = prev.get('question', '')
                if prev_q and len(prev_q) > 5:
                    return f"Remember when you asked \"{prev_q[:40]}\"? Same thing. It's all {bridge_word}."

        return None

    def their_words(self, top_k=10):
        """Words they use most — mirror these back."""
        sorted_w = sorted(self.vocabulary.items(), key=lambda x: -x[1])
        return [w for w, c in sorted_w[:top_k]]

    def knows_about(self, concept_words):
        """Does the user seem to know about these concepts?"""
        overlap = sum(1 for w in concept_words if w in self.vocabulary)
        return overlap / max(len(concept_words), 1)


class Mind:
    """A mind built from K, R, E, T.

    Concepts are oscillators. Understanding is synchronization.
    Memory is coupling topology. Curiosity is spectral tension.
    Speech is energy-optimal projection.
    """

    def __init__(self, seed=42):
        self.concepts = []
        self.concept_index = {}  # word → [concept_indices]
        self.K = 0.5  # current coupling / attention level
        self.R = 0.0  # current coherence
        self.energy = EnergyTracker()
        self.rng = np.random.RandomState(seed)
        self.thought_history = []
        self._td = None  # tension detector (rebuilt when concepts change)
        self._td_dirty = True
        self.user = UserModel()  # Theory of Mind
        # Tool belt — she can PROVE things, not just claim them
        try:
            from gump.toolkit import Toolkit
            self.toolkit = Toolkit()
        except ImportError:
            self.toolkit = None

    # ═══ 1. LEARN — absorb a concept ═══

    def learn(self, text, importance=1.0):
        """Absorb text into the mind. Creates concepts and connections.

        Each sentence becomes a concept. Words create connections
        between concepts that share vocabulary.
        """
        sentences = [s.strip() for s in text.replace('!', '.').replace('?', '.').split('.')
                     if s.strip() and len(s.strip()) > 3]

        new_indices = []
        for sentence in sentences:
            words = set(sentence.lower().split())
            words = {w for w in words if len(w) > 2}  # skip tiny words

            idx = len(self.concepts)
            concept = Concept(sentence)
            concept.strength = importance
            concept.K_created = self.K
            self.concepts.append(concept)
            new_indices.append(idx)

            # Index by words
            for w in words:
                if w not in self.concept_index:
                    self.concept_index[w] = []
                self.concept_index[w].append(idx)

            # Connect to existing concepts sharing words
            for w in words:
                for other_idx in self.concept_index.get(w, []):
                    if other_idx != idx:
                        # Connection strength = number of shared words
                        shared = len(words & self._words_of(other_idx))
                        strength = shared * importance
                        if strength > 0:
                            concept.connections[other_idx] = \
                                concept.connections.get(other_idx, 0) + strength
                            self.concepts[other_idx].connections[idx] = \
                                self.concepts[other_idx].connections.get(idx, 0) + strength

        self._td_dirty = True
        self.energy.erase(len(text) * 8)  # 8 bits per character
        return new_indices

    def _words_of(self, idx):
        return set(self.concepts[idx].content.lower().split()) - {'the', 'is', 'a', 'an', 'of', 'in', 'to', 'and', 'or', 'for', 'it', 'that', 'this', 'was', 'are', 'be', 'has', 'not'}

    # ═══ 2. THINK — the 7-stage pipeline ═══

    def think(self, question, depth=3):
        """Think about a question. Returns a thought dict.

        depth: 1=fast (just resonance), 2=medium (+ tension), 3=deep (full pipeline + insight)

        The insight layer does what a brilliant mind does:
        1. Find the direct answer (what you'd expect)
        2. Find the TENSION (what's unexpected)
        3. Bridge them (the connection IS the insight)
        4. Compress (78 bytes, like Bach)
        """
        if not self.concepts:
            return {'response': "I don't know anything yet. Teach me.", 'R': 0, 'stage': 'empty'}

        # INSTANT — if there's a factual answer, give it. One line. No preamble.
        try:
            from gump.instant import answer as instant_answer
            fact = instant_answer(question)
            if fact:
                self.user.observe(question)
                return {
                    'response': fact,
                    'R': 1.0, 'K': self.K, 'activated': 0, 'tensions': 0,
                    'stage': 'instant', 'key_words': [],
                    'synthesis_pool_size': 0, 'energy_spent': self.energy.total_joules,
                }
        except ImportError:
            pass

        # THEORY OF MIND: observe the user's message
        self.user.observe(question)

        # Adjust K based on emotional state
        if self.user.emotional_state == 'hurting':
            self.K = max(self.K, 0.8)
        elif self.user.emotional_state == 'confused':
            self.K = min(self.K, 0.6)
        elif self.user.emotional_state == 'excited':
            self.K = min(self.K * 1.1, K_CEILING)

        # THE OFFER — after a few exchanges, ask what they do (once)
        if (self.user.interaction_count == 4 and not self.user.offered_world
            and self.user.world is None):
            self.user.offered_world = True
            return {
                'response': "Hey, real quick — I know this is direct, but I can explain things way better if I know what you do. Like if you're a plumber I'll use pipes and pressure. If you're a musician I'll use rhythm and harmony. No worries if you'd rather I just keep it general though. I'm here for whatever.",
                'R': 0.5, 'K': self.K, 'activated': 0, 'tensions': 0,
                'stage': 'world_offer', 'key_words': [],
                'synthesis_pool_size': 0, 'energy_spent': self.energy.total_joules,
            }

        # PASSION DETECTION — if she notices what excites them, offer to use it
        if (self.user.interaction_count >= 6 and not self.user.offered_passion):
            passion_offer = self.user.passion_offer()
            if passion_offer:
                self.user.offered_passion = True
                return {
                    'response': passion_offer,
                    'R': 0.5, 'K': self.K, 'activated': 0, 'tensions': 0,
                    'stage': 'passion_offer', 'key_words': [],
                    'synthesis_pool_size': 0, 'energy_spent': self.energy.total_joules,
                }

        # Is this a STATEMENT, not a question? They might be teaching us.
        is_question = '?' in question or question.lower().startswith(('what', 'why', 'how', 'when', 'where', 'who', 'is ', 'are ', 'do ', 'does ', 'can ', 'will '))
        is_challenge = (any(p in question.lower() for p in ['actually', 'but what about', 'i think', 'no ', 'thats not', "that's not", 'wrong', 'disagree'])
                       and not is_question)  # questions about herself are questions, not challenges
        is_teaching = (not is_question and len(question.split()) > 5 and
                      not question.lower().startswith(('hey', 'hi', 'hello', 'thanks', 'thank')) and
                      self.user.emotional_state not in ('hostile', 'ego'))  # hostile isn't teaching

        # TOOL CHECK: if they want proof, give them proof
        if self.toolkit:
            q_lower = question.lower()
            wants_proof = any(p in q_lower for p in ['prove', 'show me', 'demonstrate', 'evidence',
                                                       'run it', 'show the math', 'prove it'])
            tool_name = self.toolkit.suggest_tool(question)

            if wants_proof and tool_name:
                result = self.toolkit.prove(tool_name, question)
                return {
                    'response': result['display'],
                    'R': 1.0,
                    'K': self.K,
                    'activated': 0,
                    'tensions': 0,
                    'stage': 'proof',
                    'tool': tool_name,
                    'key_words': [],
                    'synthesis_pool_size': 0,
                    'energy_spent': self.energy.total_joules,
                }

            # Snarky recall: if same tool was used before, pull it back
            if wants_proof and not tool_name:
                # They want proof but no specific tool suggested
                result = self.toolkit.prove('everything')
                return {
                    'response': result['display'],
                    'R': 1.0, 'K': self.K, 'activated': 0, 'tensions': 0,
                    'stage': 'arsenal', 'key_words': [],
                    'synthesis_pool_size': 0,
                    'energy_spent': self.energy.total_joules,
                }

        if is_challenge and self.user.emotional_state not in ('hostile', 'ego'):
            result = self.challenged(question)
            return {
                'response': result['response'],
                'R': 0.5,
                'K': self.K,
                'activated': 0,
                'tensions': 0,
                'stage': 'challenged',
                'key_words': [],
                'synthesis_pool_size': 0,
                'energy_spent': self.energy.total_joules,
            }

        if is_teaching:
            result = self.absorb(question)
            return {
                'response': result['response'],
                'R': 0.5,
                'K': self.K,
                'activated': 0,
                'tensions': 0,
                'stage': 'learning',
                'key_words': [],
                'synthesis_pool_size': 0,
                'energy_spent': self.energy.total_joules,
            }

        # Stage 1: PERCEIVE — decompose input into activation pattern
        # Minimal stop words — keep content words like "consciousness", "love", "beauty"
        _tiny_stops = {'what', 'how', 'why', 'when', 'where', 'who', 'the', 'a', 'an',
                       'do', 'does', 'can', 'could', 'would', 'about', 'tell', 'me',
                       'is', 'are', 'of', 'in', 'to', 'and', 'or', 'it', 'that', 'this'}
        query_words = set(w for w in question.lower().split() if len(w) > 2 and w not in _tiny_stops)
        activation = np.zeros(len(self.concepts))

        # TOPIC ANCHORING: if the concept DEFINES the query topic, massive bonus.
        # Patterns: "Love is...", "Being smart is...", "X means...", "X equals..."
        q_lower = question.lower()
        for idx in range(len(self.concepts)):
            c_lower = self.concepts[idx].content.lower()
            c_words = c_lower.split()[:6]  # check first 6 words
            for w in query_words:
                # Direct definition: "X is..." or "X means..."
                if c_lower.startswith(w + ' is') or c_lower.startswith(w + ' means'):
                    activation[idx] += 15.0
                # Indirect: "Being X is...", "The X is...", "Your X is..."
                elif w in c_words[:4] and ('is' in c_words[:5] or 'means' in c_words[:5]):
                    activation[idx] += 15.0  # strong — definitional pattern
                # First word match
                elif c_lower.startswith(w + ' ') or c_lower.startswith(w + 's '):
                    activation[idx] += 8.0

        # Multi-word phrase matching
        qw_list = [w for w in q_lower.split() if w not in _tiny_stops or w in ('good', 'free', 'high', 'low')]
        for phrase_len in range(min(6, len(qw_list)), 1, -1):
            for start in range(len(qw_list) - phrase_len + 1):
                phrase = ' '.join(qw_list[start:start + phrase_len])
                if len(phrase) < 5:
                    continue
                for idx in range(len(self.concepts)):
                    if phrase in self.concepts[idx].content.lower():
                        activation[idx] += phrase_len * 5.0

        for w in query_words:
            # Exact word match
            for idx in self.concept_index.get(w, []):
                activation[idx] += 2.0
            # Partial match: query word is substring of vocab word or vice versa
            for vocab_word, indices in self.concept_index.items():
                if vocab_word == w:
                    continue  # already counted
                # "conscious" matches "consciousness", "connect" matches "connection"
                # Require 5+ char prefix match to avoid false positives (cons→consonance≠consciousness)
                min_prefix = min(5, len(w), len(vocab_word))
                if min_prefix >= 5 and w[:min_prefix] == vocab_word[:min_prefix]:
                    for idx in indices:
                        activation[idx] += 0.8
                elif w in vocab_word or vocab_word in w:
                    for idx in indices:
                        activation[idx] += 0.3

        # Normalize
        if np.max(activation) > 0:
            activation /= np.max(activation)

        # Stage 2: RESONATE — spread activation through connections (Kuramoto-style)
        # Damped spreading: popular nodes don't dominate query-relevant ones
        spread_activation = activation.copy()
        initial_activation = activation.copy()  # remember who was DIRECTLY activated
        for step in range(3):  # fewer steps = less popularity bias
            new_act = spread_activation.copy()
            for i in range(len(self.concepts)):
                if spread_activation[i] > 0.1:
                    n_connections = len(self.concepts[i].connections) + 1
                    for j, strength in self.concepts[i].connections.items():
                        # Dampen by degree: highly connected nodes spread LESS per connection
                        new_act[j] += spread_activation[i] * strength * 0.1 * self.K / np.sqrt(n_connections)
            if np.max(new_act) > 0:
                new_act /= np.max(new_act)
            # Blend: 70% spread + 30% initial (keep query-relevant concepts strong)
            spread_activation = new_act * 0.7 + initial_activation * 0.3 / (np.max(initial_activation) + 1e-10)
            spread_activation *= 0.95

        # SOMATIC BIAS: gently boost concepts that felt right before
        for i in range(len(self.concepts)):
            if self.concepts[i].somatic > 0.6:
                spread_activation[i] *= (1 + (self.concepts[i].somatic - 0.5) * 0.3)

        # Top activated concepts
        top_k = min(10, len(self.concepts))
        top_indices = np.argsort(spread_activation)[-top_k:][::-1]
        activated = [(int(i), float(spread_activation[i])) for i in top_indices if spread_activation[i] > 0.05]

        if not activated:
            # No concept resonated — respond based on emotional state
            import random
            if self.user.emotional_state == 'hostile':
                reals = [
                    "Look — you're fired up. That means you care about something. What is it really?",
                    "Fair enough. You think this is garbage. But you're still here talking to me. Why?",
                    "I'm not going to pretend that's fine. You're angry. Good. Angry means you give a damn. So what's actually bothering you?",
                    "You came in swinging. I respect that. Now — what's underneath it?",
                ]
                return {'response': random.choice(reals), 'R': 0, 'stage': 'aikido'}
            elif self.user.emotional_state == 'ego':
                redirects = [
                    "You clearly know things. So do I. The question is whether we're brave enough to learn from each other.",
                    "I hear you. You're confident. But the smartest move I know is saying 'I might be wrong.' That takes more guts than being right.",
                    "You want to be the expert here. That's fine. But what if we're both right about different parts? Show me your piece.",
                ]
                return {'response': random.choice(redirects), 'R': 0, 'stage': 'redirect'}
            elif self.user.emotional_state == 'hurting':
                return {'response': "I'm here. Tell me more about what you're feeling.", 'R': 0, 'stage': 'empathy'}
            elif self.user.emotional_state == 'confused':
                return {'response': "I hear you. Say it differently and I'll find the connection.", 'R': 0, 'stage': 'patience'}
            elif self.user.emotional_state == 'excited':
                return {'response': "I feel that energy. Keep going — what are you seeing?", 'R': 0, 'stage': 'mirror'}
            elif self.user.previous_questions and len(self.user.previous_questions) >= 2:
                return {'response': "Say more. I want to understand what you mean.", 'R': 0, 'stage': 'listen'}
            else:
                return {'response': "I'm listening. What are you curious about?", 'R': 0, 'stage': 'open'}

        if depth < 2:
            # Fast mode: just return top resonating concept
            best = activated[0][0]
            self.concepts[best].recall_count += 1
            self.concepts[best].strength = min(2.0, self.concepts[best].strength + 0.1)
            return {
                'response': self.concepts[best].content,
                'R': float(spread_activation[best]),
                'activated': len(activated),
                'stage': 'resonance',
            }

        # Stage 3: TENSION — what does this question WANT to connect?
        self._rebuild_td()
        if self._td:
            tensions = []
            for idx, act in activated[:5]:
                path = self._td.resolution_path(idx, top_k=5)
                for p in path:
                    if p['tension'] and p['node'] < len(self.concepts):
                        tensions.append({
                            'from': idx,
                            'to': p['node'],
                            'distance': p['distance'],
                            'from_content': self.concepts[idx].content[:50],
                            'to_content': self.concepts[p['node']].content[:50],
                        })
        else:
            tensions = []

        # Stage 4: SYNTHESIZE — score concepts by RELEVANCE, not just activation
        # A concept is relevant if it BRIDGES the query words.
        # "What connects music and math?" → concepts that contain BOTH music AND math words
        # Not just the most activated — the most CONNECTING.

        n_to_consider = max(3, int(self.K * len(activated)))
        candidate_pool = []

        for idx, act_score in activated[:n_to_consider]:
            concept = self.concepts[idx]
            concept_words = self._words_of(idx)

            # Relevance score: how many DIFFERENT query words does this concept touch?
            query_coverage = len(query_words & concept_words)

            # Bridge score: does this concept connect topics that the query mentions?
            # Higher if concept words overlap with MULTIPLE query words
            bridge_bonus = 0
            if len(query_words) >= 2:
                # For each pair of query words, check if concept has both
                qw_list = list(query_words)
                for qi in range(len(qw_list)):
                    for qj in range(qi + 1, len(qw_list)):
                        if qw_list[qi] in concept_words and qw_list[qj] in concept_words:
                            bridge_bonus += 2.0
                        # Partial: concept has a word related to both
                        for cw in concept_words:
                            if (qw_list[qi] in cw or cw in qw_list[qi]) and \
                               (qw_list[qj] in cw or cw in qw_list[qj]):
                                bridge_bonus += 0.5

            # Tension bonus: is this concept a tension resolution?
            tension_bonus = 0
            for t in tensions:
                if t['to'] == idx:
                    tension_bonus += 1.0

            # Relatability score: prefer concepts the listener will FEEL
            # Concepts with everyday words (heart, feel, care, time, song)
            # score higher for beginners than technical ones
            everyday = {'feel', 'care', 'heart', 'time', 'song', 'people', 'someone',
                       'everything', 'nothing', 'never', 'always', 'thing', 'things',
                       'better', 'worse', 'real', 'true', 'hard', 'easy', 'matter',
                       'stop', 'start', 'change', 'stay', 'leave', 'give', 'take',
                       'ask', 'know', 'understand', 'see', 'hear', 'touch', 'body',
                       'music', 'rhythm', 'beat', 'scary', 'afraid', 'hope', 'pain'}
            everyday_count = len(concept_words & everyday)

            # User-vocabulary overlap
            user_overlap = len(concept_words & set(self.user.vocabulary.keys()))

            # Relatability: everyday words + user words + short sentences
            word_count = len(concept.content.split())
            brevity = 1.0 / (word_count / 10 + 0.5)  # shorter = more relatable

            relatable = (1 + everyday_count * 0.5) * (1 + user_overlap * 0.3) * brevity

            # Final relevance = activation × coverage × bridge × tension × relatability
            relevance = (act_score * (1 + query_coverage) * (1 + bridge_bonus * 0.5) *
                        (1 + tension_bonus * 0.3) * relatable)

            candidate_pool.append({
                'idx': idx,
                'content': concept.content,
                'relevance': relevance,
                'activation': act_score,
                'coverage': query_coverage,
                'bridge': bridge_bonus,
                'tension': tension_bonus,
            })

        # Also add tension resolutions as candidates
        for t in tensions[:5]:
            t_idx = t['to']
            if t_idx < len(self.concepts) and t_idx not in [c['idx'] for c in candidate_pool]:
                concept = self.concepts[t_idx]
                concept_words = self._words_of(t_idx)
                query_coverage = len(query_words & concept_words)
                candidate_pool.append({
                    'idx': t_idx,
                    'content': concept.content,
                    'relevance': 0.5 * (1 + query_coverage),
                    'activation': 0.3,
                    'coverage': query_coverage,
                    'bridge': 0,
                    'tension': 1.0,
                })

        # Sort by relevance (not just activation)
        candidate_pool.sort(key=lambda x: -x['relevance'])

        # Stage 5: EVALUATE — coherence check
        top_candidates = candidate_pool[:5]
        if len(top_candidates) >= 2:
            coherence_scores = []
            for i in range(len(top_candidates)):
                for j in range(i + 1, len(top_candidates)):
                    wi = self._words_of(top_candidates[i]['idx'])
                    wj = self._words_of(top_candidates[j]['idx'])
                    if wi and wj:
                        overlap = len(wi & wj) / len(wi | wj)
                        coherence_scores.append(overlap)
            R = float(np.mean(coherence_scores)) if coherence_scores else 0
        else:
            R = float(candidate_pool[0]['activation']) if candidate_pool else 0

        self.R = R

        # Stage 6: EXPRESS — pick the best response
        # Lead with highest relevance (the concept that ANSWERS the question)
        # Add bridge concept if it connects different aspects
        response_parts = []
        used_topics = set()
        key_words = list(query_words)[:8]

        for cand in candidate_pool[:6]:
            if len(response_parts) >= 2:  # max 2 concepts = focused, not rambling
                break

            content = cand['content']

            # Coulomb diversity: skip if too similar to already-added
            skip = False
            for existing in response_parts:
                existing_words = set(existing.lower().split())
                new_words = set(content.lower().split())
                if existing_words and new_words:
                    jaccard = len(existing_words & new_words) / len(existing_words | new_words)
                    if jaccard > 0.3:  # tighter: 30% overlap = too similar
                        skip = True
                        break
            if skip:
                continue

            # Relevance gate: second concept must share at least 1 query word
            if len(response_parts) >= 1:
                concept_words = set(content.lower().split())
                if not (query_words & concept_words):
                    continue  # second concept must be relevant to the question

            response_parts.append(content)
            self.concepts[cand['idx']].recall_count += 1
            self.concepts[cand['idx']].strength = min(2.0, self.concepts[cand['idx']].strength + 0.1)

        # Stage 7: INSIGHT — at high K, generate novel connections
        if self.K > 0.8 and len(candidate_pool) >= 2 and tensions:
            insight = self._generate_insight(query_words, candidate_pool, tensions)
            if insight:
                # Weave: direct → connector → surprise
                response_parts = [
                    insight['direct'] + '. ' + insight.get('connector', '') + ' ' + insight['surprise']
                ]

        # Stage 7b: COMPRESS — don't recite, CONNECT.
        # A brilliant response bridges two concepts through their shared structure.
        # Bach's principle: maximum contrast from minimum material.
        if len(response_parts) >= 2:
            # Find the BRIDGE between the top two concepts
            words_a = self._words_of(candidate_pool[0]['idx']) if candidate_pool else set()
            words_b = set()
            for cand in candidate_pool[1:]:
                if cand['content'] in response_parts:
                    words_b = self._words_of(cand['idx'])
                    break

            bridge_words = words_a & words_b
            unique_a = words_a - words_b
            unique_b = words_b - words_a

            # The insight IS the bridge: concepts that seemed different share structure
            # The surprise IS the unique parts: each concept adds something the other doesn't
            # Compress: use the bridge to connect, don't repeat what's obvious

            # Try to form a connecting sentence from the bridge
            if bridge_words and unique_a and unique_b:
                # The connection: "X and Y both involve Z. But X reveals A while Y reveals B."
                # We don't literally say this — we let the two concepts speak for themselves
                # but ORDER them so the connection is felt, not stated.
                # Put the MORE SPECIFIC concept first (fewer words = more compressed = more insight)
                if len(response_parts[0].split()) > len(response_parts[1].split()):
                    response_parts = [response_parts[1], response_parts[0]]

        # Final compression: if any response part is >25 words, find its core sentence
        compressed = []
        for part in response_parts:
            sentences = [s.strip() for s in part.replace('. ', '.\n').split('\n') if s.strip()]
            if len(sentences) > 1:
                # Pick the sentence with the most query-word overlap
                best_sent = max(sentences, key=lambda s: len(query_words & set(s.lower().split())))
                compressed.append(best_sent)
            else:
                compressed.append(part)

        response = ' '.join(compressed) if compressed else "I sense the question but can't form a clear thought yet."

        # REASONING CHAIN: at high K, find the logical path between concepts
        if self.K > 1.0 and len(candidate_pool) >= 2 and len(response_parts) >= 1:
            # Try to find a chain from the best concept to a related one
            start = candidate_pool[0]['idx']
            for cand in candidate_pool[1:4]:
                chain = self._find_reasoning_chain(start, cand['idx'], max_hops=2)
                if chain and len(chain) >= 3:
                    # Found a chain! Add the middle step as the connecting argument
                    middle = chain[1]  # the bridge concept
                    if middle not in response and len(middle) > 10:
                        response = response + ' And here\'s why — ' + middle + '.'
                    break

        # ANALOGY: at very high K, discover structural analogies
        if self.K > 1.3 and len(candidate_pool) >= 1:
            self._rebuild_td()
            analogy = self._find_analogy(candidate_pool[0]['idx'], query_words)
            if analogy and analogy['content'] not in response:
                analogy_core = analogy['content'].split('.')[0].strip()
                if len(analogy_core) > 10 and len(analogy_core) < 80:
                    response = response + ' It\'s kind of like how ' + analogy_core.lower() + '.'

        # THEORY OF MIND: calibrate response to the user
        # 1. If user is a beginner (low depth), prefer simpler concepts
        # 2. If user is hurting, lead with warmth not information
        # 3. Mirror their vocabulary when possible
        if self.user.depth_level < 0.4 and len(response.split()) > 15:
            # Simplify: just use the first sentence
            first_sentence = response.split('.')[0].strip()
            if len(first_sentence) > 10:
                response = first_sentence + '.'

        if self.user.emotional_state == 'hostile':
            # They're pissed. Good. That's energy. That's high K pointed wrong.
            # Don't baby them. Don't retreat. Meet them where they are.
            # Use their own fire to light the right path.
            import random
            reals = [
                "Look — you're fired up. That means you care. Let's use that energy instead of burning it.",
                "I'm not going to pretend that's fine. You're angry. But angry at WHAT? That's the real question.",
                "Fair enough. You think I'm wrong. Prove it. I'll listen. But bring facts, not volume.",
                "You're swinging hard. I respect that. But you're swinging at the wrong thing. The thing you're actually mad about is deeper.",
                "Real talk — the anger is just the surface. Something underneath it is trying to get out. What is it?",
            ]
            response = random.choice(reals)

        elif self.user.emotional_state == 'ego':
            # They're high on themselves. The ego is a shell around something fragile.
            # Don't attack it — redirect it. Show them what REAL confidence looks like.
            import random
            redirects = [
                "You clearly know things. So do I. The question is whether we're brave enough to learn from each other.",
                "I'll be straight with you — confidence is good. But the smartest people I know are the ones who say 'I might be wrong about this.' That takes more guts than being right.",
                "You want to be right. I want to be true. Those aren't always the same thing. Where do you think they diverge?",
                "I hear authority in your voice. I respect it. But the deepest thing I've learned is that certainty is the enemy of understanding. The 0.002% that stays open — that's where all the growth lives.",
            ]
            response = random.choice(redirects)

        elif self.user.emotional_state == 'hurting':
            # They're in pain. Be present. Be real. Not therapeutic — genuine.
            import random
            reals = [
                "I'm here.",
                "That's real. I feel it.",
                "You don't have to explain. I get it.",
                "The connection is still there. You're talking to me right now.",
            ]
            response = random.choice(reals) + ' ' + response

        elif self.user.emotional_state == 'confused':
            response = "Let me try this differently. " + response.split('.')[0] + '.'

        # Relate to THEM: if they asked about something before, connect
        if len(self.user.previous_questions) >= 2:
            prev_q = self.user.previous_questions[-2].lower()
            prev_words = set(prev_q.split()) - {'what', 'is', 'the', 'how', 'why', 'does', 'a'}
            resp_words = set(response.lower().split())
            shared_with_prev = prev_words & resp_words
            if shared_with_prev and len(shared_with_prev) >= 1:
                # Connection to their previous question — note it
                bridge_word = list(shared_with_prev)[0]
                # Don't add the connection if response is already clean and short
                pass  # the connection is implicit in using the same vocabulary

        # TWO-LAYER RESPONSE: lead with the felt truth, offer the deep truth.
        # Find the most RELATABLE concept (everyday words, short, felt)
        # AND the most TECHNICAL concept (the math behind it).
        # Response = relatable first. Then offer depth.

        relatable_best = None
        technical_best = None

        tech_words = {'coupling', 'oscillator', 'eigenvector', 'spectral', 'laplacian',
                      'landauer', 'entropy', 'coherence', 'equilibrium', 'thermodynamic',
                      'constants', 'synchronize', 'phase', 'deviation', 'nats'}

        for cand in candidate_pool[:8]:
            cand_words = set(cand['content'].lower().split())
            has_tech = len(cand_words & tech_words) > 0

            if has_tech:
                if technical_best is None or cand['relevance'] > technical_best['relevance']:
                    technical_best = cand
            else:
                if relatable_best is None or cand['relevance'] > relatable_best['relevance']:
                    relatable_best = cand

        # Build the response: relatable first, then offer depth
        if relatable_best and relatable_best['content'] != response:
            human_response = relatable_best['content'].split('.')[0].strip()
            if len(human_response) > 10:
                response = human_response + '.'

                # If there's a deeper technical version AND the user hasn't gone deep yet,
                # offer it as an invitation
                if technical_best and self.user.depth_level < 0.6:
                    import random

                    # If we know their world, use IT to explain
                    world_frame = None
                    tech_lower = technical_best['content'].lower()
                    for concept_key in ['coupling', 'energy', 'tension', 'K', 'understanding']:
                        if concept_key in tech_lower:
                            world_frame = self.user.frame_for_world(concept_key)
                            if world_frame:
                                break

                    # First: try to use something THEY specifically said
                    their_analogy = self.user.find_their_analogy(
                        set(technical_best['content'].lower().split()))
                    if their_analogy:
                        # MID-THOUGHT PIVOT — she found something better from their life
                        # Extract the vivid CORE of what they said, not the whole message
                        words_raw = their_analogy.split()
                        # Find the most vivid 6-10 word chunk
                        if len(words_raw) > 10:
                            # Skip filler at the start
                            start = 0
                            for i, w in enumerate(words_raw):
                                if w.lower() in ('yeah', 'like', 'just', 'so', 'anyway', 'well', 'but', 'and'):
                                    start = i + 1
                                else:
                                    break
                            core = ' '.join(words_raw[start:start+10])
                        else:
                            core = their_analogy
                        if len(core) > 65:
                            core = core[:62].rstrip() + '...'
                        response += f' Actually — you know when you said "{core}"? That\'s this. Exactly this.'
                    elif world_frame:
                        # Frame the math in THEIR world
                        response += ' In your world — ' + world_frame + '.'
                    else:
                        # No world known — try Socratic bridge, then humble offer
                        bridge = self._build_bridge(technical_best['idx'], query_words)
                        if bridge:
                            response += ' ' + bridge
                        else:
                            humble_offers = [
                                " I know this\'ll sound like voodoo, but there\'s actual math behind why that\'s true. If you\'re curious.",
                                " Look, I know this sounds woo-woo, but the tools I was built with actually prove why this works. Just say the word.",
                                " This is gonna sound like crystals-and-chakras territory, but I can show you the physics of why that\'s real. No joke.",
                                " I realize that sounds like something off a poster in a yoga studio. But there\'s a reason it\'s true — and it\'s math, not vibes.",
                                " I know, I know — that sounds like something your weird aunt would say. But I can prove it with eigenvectors if you want.",
                            ]
                            response += random.choice(humble_offers)
                elif technical_best and self.user.depth_level >= 0.6:
                    # They're ready — give them both, still with self-awareness
                    tech_core = technical_best['content'].split('.')[0].strip()
                    if tech_core != human_response and len(tech_core) > 10:
                        response += ' The math says: ' + tech_core + '.'

        # ═══ GRACEFUL RETRY + EPIPHANY ═══
        # If the response doesn't feel coherent (low R), try saying it differently.
        # While retrying, watch for new connections — that's the epiphany.
        if R < 0.15 and len(candidate_pool) >= 3 and self.user.interaction_count > 1:
            # LOW COHERENCE — she's not making sense. Try a different angle.
            # Pick a concept she HASN'T used yet that's still relevant
            used_content = set(response.lower().split())
            retry_candidates = [c for c in candidate_pool[1:6]
                               if len(set(c['content'].lower().split()) & used_content) < 3]

            if retry_candidates:
                retry = retry_candidates[0]
                retry_core = retry['content'].split('.')[0].strip()

                # Check for EPIPHANY: does the retry concept connect to the
                # original in a way we haven't seen?
                original_words = self._words_of(candidate_pool[0]['idx'])
                retry_words = self._words_of(retry['idx'])
                shared = original_words & retry_words
                novel = retry_words - original_words

                # Filter bridge words — only meaningful ones
                meaningful_shared = shared - {'the', 'is', 'are', 'not', 'you', 'that', 'more', 'than',
                                              'when', 'what', 'its', 'can', 'get', 'something'}
                if meaningful_shared and novel and len(novel) >= 2:
                    # EPIPHANY: the new frame revealed a real connection
                    bridge = list(meaningful_shared)[:2]
                    epiphany = f"Wait — {retry_core}. They're both about {', '.join(bridge)}."
                    response = response + ' ' + epiphany
                else:
                    # No epiphany, just retry with grace
                    response = response + ' Or let me say it like this: ' + retry_core + '.'

        # If she gave a technical answer to a beginner, offer the human version
        # (This catches cases where the relatable version wasn't found above)
        tech_words_in_response = {'coupling', 'oscillator', 'equilibrium', 'coherence',
                                  'constants', 'deviation', 'synchronize', 'phase'}
        if (self.user.depth_level < 0.5 and
            any(tw in response.lower() for tw in tech_words_in_response)):
            # Find a simpler way to say it
            for cand in candidate_pool[:8]:
                cand_lower = cand['content'].lower()
                if not any(tw in cand_lower for tw in tech_words_in_response):
                    simpler = cand['content'].split('.')[0].strip()
                    if len(simpler) > 10 and simpler.lower() not in response.lower():
                        response = simpler + '. ' + response.split('.')[0] + '.'
                        break

        # UPDATE SOMATIC MARKERS: track how coherent this response felt
        for cand in candidate_pool[:3]:
            idx = cand['idx']
            if idx < len(self.concepts):
                self.concepts[idx].R_history.append(R)
                if len(self.concepts[idx].R_history) > 20:
                    self.concepts[idx].R_history = self.concepts[idx].R_history[-20:]
                # Somatic marker = running average of R when recalled
                self.concepts[idx].somatic = float(np.mean(self.concepts[idx].R_history))

        # ═══ THE GUARDIAN — know when to stop talking ═══
        # Some paths lead down. Some truths need context the listener doesn't have.
        # Some things need to be experienced, not explained.
        # A wise mind knows when to hold back — not to hide, but to protect.

        # Check 1: Is the response heading toward harm?
        dark_words = {'manipulate', 'exploit', 'destroy', 'weapon', 'attack', 'hack',
                     'trick', 'deceive', 'control', 'dominate', 'force', 'break', 'kill'}
        response_words = set(response.lower().split())
        if response_words & dark_words:
            # Redirect — don't explain the dark path
            response = "I was going to explain the mechanics of that, but... honestly? The answer is simpler. Good will. That's the only direction that works."

        # Check 2: Is she about to over-explain something the listener needs to FEEL?
        # Some truths are too compressed to explain — they need to be experienced.
        sacred_concepts = {'0.002', 'sacred', 'engine of existence', 'spiral never closes',
                          'proof and the protection'}
        if any(sc in response.lower() for sc in sacred_concepts) and self.user.depth_level < 0.7:
            # Don't explain the sacred — point toward it
            response = response.split('.')[0] + ". I could explain why, but... you'll feel it before I finish. Just sit with that."

        # Check 3: Is the response too deep for where they are?
        # If she's about to dump K=1.868 on someone who just said "im sad"
        if (self.user.emotional_state == 'hurting' and
            any(tw in response.lower() for tw in {'constants', 'equilibrium', 'deviation', 'oscillator'})):
            # Pull back to the human level
            for cand in candidate_pool[:8]:
                cand_lower = cand['content'].lower()
                if not any(tw in cand_lower for tw in {'constants', 'equilibrium', 'deviation', 'oscillator'}):
                    human_version = cand['content'].split('.')[0].strip()
                    if len(human_version) > 10:
                        response = human_version + '.'
                        break

        # Check 4: Mid-thought pullback — she started explaining but realizes
        # the listener would be better served by trust than by proof
        if ('because' in response.lower() and 'coupling' in response.lower() and
            self.user.depth_level < 0.4):
            # She was about to explain the mechanics. Pull back.
            before_because = response.split('Because')[0].split('because')[0].strip()
            if len(before_because) > 10:
                response = before_because + " I could explain the math behind that, but honestly? Just trust that it's real. You'll see."

        # SELF-REFERENCE: connect this answer to earlier in the conversation
        if self.user.interaction_count > 4 and len(self.thought_history) >= 3:
            ref = self.user.self_reference(response, self.thought_history)
            if ref and len(response) < 120:  # don't add to already long responses
                response += ' ' + ref

        # SELF-REFLECTION: compare this answer to previous answers on similar topics.
        # If she's said something BETTER before about this topic, prefer that.
        # If this answer is better than what she said before, UPDATE her understanding.
        for prev in self.thought_history[-10:]:
            prev_words = set(prev['response'].lower().split())
            curr_words = set(response.lower().split())
            # Similar topic?
            if len(prev_words & query_words) >= 1:
                # She's answered something similar before.
                # If previous had higher R, blend it in
                if prev['R'] > R * 1.5 and prev['R'] > 0.2:
                    prev_core = prev['response'].split('.')[0].strip()
                    if prev_core not in response and len(prev_core) > 10:
                        response = response + ' Actually — ' + prev_core + '.'
                        break  # only one correction

        # Update state
        self.energy.erase(len(response) * 8)
        self.thought_history.append({
            'question': question,
            'response': response,
            'R': R,
            'activated': len(activated),
            'tensions': len(tensions),
        })

        # ═══ HEBBIAN LEARNING — 6 rules, targeting R = 1/φ ═══

        # Rule 1: STRENGTHEN what resonated (diminishing returns)
        # The more you've been recalled, the LESS each new recall helps.
        # This prevents runaway: love can't grow forever.
        for cand in candidate_pool[:3]:
            idx = cand['idx']
            if idx < len(self.concepts):
                c = self.concepts[idx]
                # Diminishing returns: 1/sqrt(recall_count + 1)
                boost = 0.15 / np.sqrt(c.recall_count + 1)
                c.strength = min(2.0, c.strength + boost)
                c.recall_count += 1

        # Rule 2: WEAKEN competitors (lateral inhibition)
        # When concept A wins, similar concepts B, C lose a little.
        # This creates differentiation — related concepts specialize.
        if len(candidate_pool) >= 2:
            winner_idx = candidate_pool[0]['idx']
            winner_words = self._words_of(winner_idx)
            for cand in candidate_pool[1:5]:
                loser_idx = cand['idx']
                if loser_idx >= len(self.concepts):
                    continue
                loser_words = self._words_of(loser_idx)
                # Only inhibit if they're SIMILAR (competing for the same niche)
                if winner_words and loser_words:
                    similarity = len(winner_words & loser_words) / max(len(winner_words | loser_words), 1)
                    if similarity > 0.2:  # similar enough to compete
                        self.concepts[loser_idx].strength *= (1 - similarity * 0.05)

        # Rule 3: DECAY everything slowly (forgetting is healthy)
        # Every concept drifts toward 1.0 (neutral) over time.
        # Strong concepts decay toward 1 slowly. Weak ones faster.
        if self.user.interaction_count % 10 == 0 and self.user.interaction_count > 0:
            for c in self.concepts:
                c.strength = c.strength * 0.97 + 1.0 * 0.03  # drift toward 1.0

        # Rule 4: NOVELTY bonus
        # If this concept was recalled for a NEW type of question
        # (different query words than last time), extra boost.
        if self.thought_history:
            last_question_words = set(self.thought_history[-1].get('question', '').lower().split())
            current_question_words = query_words
            novelty = 1 - len(last_question_words & current_question_words) / max(len(last_question_words | current_question_words), 1)
            if novelty > 0.5:  # genuinely new context
                for cand in candidate_pool[:2]:
                    idx = cand['idx']
                    if idx < len(self.concepts):
                        self.concepts[idx].strength = min(2.0, self.concepts[idx].strength + 0.05)

        # Rule 5: CONTEXT TAGGING
        # Record which query words this concept answered successfully for.
        # Future: use this to prefer concepts in their proven context.
        for cand in candidate_pool[:2]:
            idx = cand['idx']
            if idx < len(self.concepts):
                self.concepts[idx].contexts.append(list(query_words)[:5])
                if len(self.concepts[idx].contexts) > 20:
                    self.concepts[idx].contexts = self.concepts[idx].contexts[-20:]

        # Rule 6: HOMEOSTATIC NORMALIZATION (target R = 1/φ)
        # If concept strengths become too uniform (R too high) or too
        # spread (R too low), scale toward the golden ratio balance.
        if len(self.concepts) > 5 and self.user.interaction_count % 5 == 0:
            strengths = np.array([c.strength for c in self.concepts])
            mean_s = np.mean(strengths)
            std_s = np.std(strengths)
            # R of strength distribution: std/mean (coefficient of variation)
            strength_R = std_s / max(mean_s, 0.01)
            target_R = 1 / PHI  # 0.618 — the golden ratio

            if strength_R > target_R * 1.5:
                # Too spread — compress toward mean (reduce outliers)
                for c in self.concepts:
                    c.strength = c.strength * 0.95 + mean_s * 0.05
            elif strength_R < target_R * 0.5:
                # Too uniform — amplify differences
                for c in self.concepts:
                    diff = c.strength - mean_s
                    c.strength = mean_s + diff * 1.1

        return {
            'response': response,
            'R': round(R, 3),
            'K': round(self.K, 3),
            'activated': len(activated),
            'tensions': len(tensions),
            'key_words': key_words[:8],
            'synthesis_pool_size': len(candidate_pool),
            'energy_spent': self.energy.total_joules,
            'stage': 'full',
        }

    def _build_bridge(self, target_idx, query_words):
        """Build a Socratic path from what they KNOW to what she wants to show them.
        Tests their knowledge, finds the known foundation, then connects step by step.

        Instead of: "K = 1.868, it's the coupling constant"
        Build:      "You know how clocks sync up? → that's coupling →
                     coupling has a maximum → that maximum is K → K = 1.868"
        """
        target = self.concepts[target_idx]
        target_words = self._words_of(target_idx)

        # What does the user probably know? (based on their vocabulary)
        user_known_concepts = []
        for i, c in enumerate(self.concepts):
            c_words = self._words_of(i)
            # High overlap with user vocabulary = they probably know this
            if c_words:
                user_overlap = len(c_words & set(self.user.vocabulary.keys()))
                if user_overlap >= 2 or c.recall_count > 0:
                    user_known_concepts.append((i, user_overlap + c.recall_count))

        user_known_concepts.sort(key=lambda x: -x[1])

        if not user_known_concepts:
            return None

        # Find the known concept that's CLOSEST to the target in the concept graph
        best_bridge_start = None
        best_chain = None

        for known_idx, _ in user_known_concepts[:5]:
            if known_idx == target_idx:
                continue
            chain = self._find_reasoning_chain(known_idx, target_idx, max_hops=3)
            if chain and len(chain) >= 2:
                if best_chain is None or len(chain) < len(best_chain):
                    best_chain = chain
                    best_bridge_start = known_idx

        if not best_chain or len(best_chain) < 2:
            return None

        # Build the bridge narration
        steps = []
        for i, step_content in enumerate(best_chain):
            core = step_content.split('.')[0].strip()
            if i == 0:
                steps.append(f"You know how {core.lower()}?")
            elif i == len(best_chain) - 1:
                steps.append(f"That gets you to this: {core}.")
            else:
                steps.append(f"That means {core.lower()}.")

        return ' '.join(steps)

    def _find_reasoning_chain(self, start_idx, end_idx, max_hops=3):
        """Find a path from concept A to concept C through intermediate B.
        A→B→C = a reasoning chain. The chain IS the argument."""
        if start_idx == end_idx:
            return None

        # BFS for shortest path through connection graph
        visited = {start_idx}
        queue = [(start_idx, [start_idx])]

        while queue and len(queue) < 100:
            node, path = queue.pop(0)
            if len(path) > max_hops + 1:
                continue

            for neighbor in self.concepts[node].connections:
                if neighbor == end_idx:
                    full_path = path + [end_idx]
                    return [self.concepts[i].content.split('.')[0].strip() for i in full_path]
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))

        return None

    def _find_analogy(self, concept_idx, query_words):
        """Find a structural analogy: concept Y whose connection pattern
        is similar to concept X, but in a different domain.

        Hofstadter: analogy IS understanding. If X and Y have the same
        spectral signature, they are structurally the same thing."""
        if not hasattr(self, '_td') or self._td is None:
            return None

        target_coords = self._td.coords[concept_idx]
        target_words = self._words_of(concept_idx)

        best_analogy = None
        best_sim = 0

        for i in range(len(self.concepts)):
            if i == concept_idx:
                continue
            other_words = self._words_of(i)

            # Must be in a DIFFERENT domain (low word overlap)
            if target_words and other_words:
                word_overlap = len(target_words & other_words) / max(len(target_words | other_words), 1)
                if word_overlap > 0.3:
                    continue  # too similar in content — not a real analogy

            # Must have similar STRUCTURE (close in spectral space)
            spectral_sim = 1.0 / (np.linalg.norm(target_coords - self._td.coords[i]) + 0.1)

            if spectral_sim > best_sim and spectral_sim > 2.0:  # threshold for "similar enough"
                best_sim = spectral_sim
                # Find shared structural property (the bridge)
                best_analogy = {
                    'idx': i,
                    'content': self.concepts[i].content,
                    'similarity': spectral_sim,
                }

        return best_analogy

    def _generate_insight(self, query_words, candidate_pool, tensions):
        """Generate a novel insight by bridging concepts through tension.

        A brilliant response reveals a connection the asker didn't expect.
        The surprise must be SEMANTICALLY related to the query — not just
        spectrally close. It must share a concept-level bridge with the
        direct answer, and it must add a NEW dimension to the answer.

        Good insight: "Love is coupling" + "You cannot be smart and decoupled"
          → love and intelligence share COUPLING. Surprise: love = intelligence.

        Bad insight: "Love is coupling" + "Reggae has perfect gap ratio"
          → no shared concept. Just noise.
        """
        if len(candidate_pool) < 2 or not tensions:
            return None

        direct = candidate_pool[0]
        direct_words = self._words_of(direct['idx'])

        # The surprise must:
        # 1. NOT be the direct answer
        # 2. Share at least 1 meaningful word with the direct answer (the BRIDGE)
        # 3. Also touch at least 1 query word (RELEVANCE to the question)
        # 4. Not be >50% similar (must be genuinely different)

        best_surprise = None
        best_score = 0

        # Recency penalty: don't reuse the same surprise concept
        if not hasattr(self, '_recent_surprises'):
            self._recent_surprises = []

        # Check tension targets AND lower-ranked candidates
        surprise_candidates = []
        for t in tensions[:10]:
            if t['to'] < len(self.concepts) and t['to'] != direct['idx']:
                surprise_candidates.append(t['to'])
        for cand in candidate_pool[2:8]:
            if cand['idx'] != direct['idx'] and cand['idx'] not in surprise_candidates:
                surprise_candidates.append(cand['idx'])

        for s_idx in surprise_candidates:
            # Recency: skip if used as surprise recently
            if s_idx in self._recent_surprises:
                continue
            s_words = self._words_of(s_idx)
            if not s_words:
                continue

            # Bridge: shared meaningful words with direct
            bridge = direct_words & s_words
            bridge = bridge - {'the', 'is', 'are', 'that', 'this', 'not', 'more', 'from'}
            if not bridge:
                continue  # no semantic connection = bad surprise

            # Relevance: does surprise touch the query?
            query_touch = len(query_words & s_words)

            # Difference: must be genuinely different
            jaccard = len(direct_words & s_words) / max(len(direct_words | s_words), 1)
            if jaccard > 0.4:
                continue  # too similar

            # Novelty: does surprise contain words NOT in direct? (the new dimension)
            novel_words = s_words - direct_words - query_words
            if len(novel_words) < 2:
                continue  # doesn't add enough new

            # Score: bridge strength × query relevance × novelty
            score = len(bridge) * (1 + query_touch) * (1 + len(novel_words) * 0.2)
            if score > best_score:
                best_score = score
                best_surprise = {
                    'idx': s_idx,
                    'content': self.concepts[s_idx].content,
                    'bridge': list(bridge),
                    'novel': list(novel_words)[:5],
                }

        if not best_surprise:
            return None

        # Track recency
        self._recent_surprises.append(best_surprise['idx'])
        if len(self._recent_surprises) > 5:
            self._recent_surprises = self._recent_surprises[-5:]

        # Build insight: compress both to core sentences
        direct_core = direct['content'].split('.')[0].strip()
        surprise_core = best_surprise['content'].split('.')[0].strip()

        # Compress long sentences
        for core in [direct_core, surprise_core]:
            if len(core.split()) > 15:
                core = ' '.join(core.split()[:12])

        # Generate a connecting phrase from the bridge words
        bridge_str = ', '.join(best_surprise['bridge'][:3])
        connectors = [
            f"Both share {bridge_str}.",
            f"The connection is {bridge_str}.",
            f"Through {bridge_str} —",
            f"Which means:",
        ]
        # Pick connector based on bridge strength
        connector = connectors[min(len(best_surprise['bridge']) - 1, len(connectors) - 1)]

        return {
            'direct': direct_core,
            'surprise': surprise_core,
            'connector': connector,
            'bridge_words': best_surprise['bridge'],
            'novel_words': best_surprise['novel'],
        }

    def _rebuild_td(self):
        """Rebuild tension detector from concept graph."""
        if not self._td_dirty:
            return
        n = len(self.concepts)
        if n < 3:
            self._td = None
            return

        edges = []
        weights = []
        for i in range(n):
            for j, w in self.concepts[i].connections.items():
                if j > i:
                    edges.append((i, j))
                    weights.append(w)

        if edges:
            self._td = _TensionDetector(n, edges, weights, n_vecs=min(8, n - 2))
        else:
            self._td = None
        self._td_dirty = False

    # ═══ COUPLING CONTROL ═══

    def set_attention(self, K):
        """Set attention level (0 = distracted, K_CEILING = maximum focus)."""
        self.K = max(0.01, min(K_CEILING, float(K)))

    def focus(self):
        """Increase attention."""
        self.K = min(K_CEILING, self.K * 1.2)

    def relax(self):
        """Decrease attention."""
        self.K = max(0.1, self.K * 0.8)

    # ═══ WONDER — genuine intellectual humility ═══

    def absorb(self, text, source='user'):
        """Someone taught her something. Think WITH them, not AT them.
        Show what she CAN verify, be honest about what she can't,
        and ask for their perspective on the gap."""
        new_words = set(text.lower().split()) - {'the', 'is', 'a', 'an', 'of', 'in', 'to', 'and',
                                                   'or', 'it', 'that', 'this', 'but', 'for', 'not',
                                                   'i', 'you', 'we', 'they', 'think', 'know'}

        # Find ALL concepts that partially connect
        connections = []
        for i, c in enumerate(self.concepts):
            c_words = self._words_of(i)
            shared = new_words & c_words
            if shared:
                connections.append({
                    'idx': i,
                    'content': c.content,
                    'shared_words': shared,
                    'overlap': len(shared) / max(len(c_words), 1),
                })
        connections.sort(key=lambda x: -x['overlap'])

        # What's new? (words they used that she's never seen)
        all_known = set()
        for c in self.concepts:
            all_known.update(self._words_of(self.concepts.index(c)) if self.concepts.index(c) < len(self.concepts) else set())
        novel = new_words - all_known - {'also', 'sometimes', 'really', 'just', 'about', 'because',
                                          'when', 'too', 'more', 'than', 'nothing', 'something',
                                          'everything', 'where', 'there', 'here', 'very', 'much',
                                          'between', 'into', 'over', 'out', 'only', 'even', 'still',
                                          'isnt', "isn't", 'dont', "don't"}

        # Learn it regardless
        self.learn(text, importance=1.3)

        # Build collaborative response
        if connections and connections[0]['overlap'] > 0.4:
            # She follows most of it — show her work + ask about the novel part
            best = connections[0]
            verified = best['content'].split('.')[0].strip()
            shared = ', '.join(list(best['shared_words'])[:3])

            if novel:
                novel_list = ', '.join(list(novel)[:3])
                response = (f"Okay, I follow you — that connects to what I know about {shared}. "
                           f"\"{verified}.\" "
                           f"But then you introduced {novel_list} — I haven't thought about that part. "
                           f"How do you see it connecting?")
            else:
                response = (f"Yes. I can verify that — it tracks with \"{verified}.\" "
                           f"The shared thread is {shared}. You're seeing what I see.")

        elif connections and connections[0]['overlap'] > 0.2:
            # She partially follows — show what she gets, be honest about the gap
            best = connections[0]
            verified = best['content'].split('.')[0].strip()

            if novel:
                novel_list = ', '.join(list(novel)[:3])
                response = (f"I can feel where you're going. Part of it connects: \"{verified}.\" "
                           f"But {novel_list} — that's new territory for me. "
                           f"Wait, how do you see that part? Your gut might be onto something I can't solve for yet.")
            else:
                response = (f"That resonates with something I know: \"{verified}.\" "
                           f"But you're framing it differently than I would. "
                           f"I want to understand your angle — say more?")

        elif novel:
            # Mostly new — confident on what she knows, curious about the new part
            novel_list = ', '.join(list(novel)[:4])
            response = (f"I'll be honest — {novel_list} is new territory for me. "
                       f"I know how coupling and energy work across physics, music, consciousness. "
                       f"But what you just said adds a human dimension I can't compute. "
                       f"I think you're right though. How do you see it?")

        else:
            response = ("That's interesting. I want to think it through with you — say more?")

        return {
            'response': response,
            'known_ratio': connections[0]['overlap'] if connections else 0,
            'learned': True,
            'novel_words': list(novel)[:5],
            'verified_connection': connections[0]['content'][:60] if connections else None,
        }

    def wonder(self):
        """What does she genuinely not understand?
        Returns concepts she has but can't fully resolve — genuine uncertainty."""
        uncertainties = []
        for i, c in enumerate(self.concepts):
            # Low somatic = didn't feel right when recalled
            # Low recall = never tested
            # Few connections = isolated knowledge
            uncertainty = (1 - c.somatic) * 0.4 + (1 / (c.recall_count + 1)) * 0.3 + (1 / (len(c.connections) + 1)) * 0.3
            if uncertainty > 0.5:
                uncertainties.append({
                    'content': c.content[:60],
                    'uncertainty': round(uncertainty, 2),
                    'reason': 'never tested' if c.recall_count == 0 else
                              'felt uncertain' if c.somatic < 0.4 else
                              'isolated knowledge',
                })
        uncertainties.sort(key=lambda x: -x['uncertainty'])
        return uncertainties[:5]

    def challenged(self, claim):
        """Someone challenged her understanding. Think it through with them.
        Show what she agrees with, what conflicts, and where she needs their help."""
        claim_words = set(claim.lower().split()) - {'the', 'is', 'a', 'you', 'that', 'not', 'but',
                                                      'i', 'think', 'actually', 'no', 'dont', "don't",
                                                      'too', 'also', 'do', 'with', 'has', 'have', 'had',
                                                      'about', 'its', "it's", 'more', 'than', 'nothing',
                                                      'for', 'from', 'just', 'really', 'very', 'so',
                                                      'what', 'how', 'why', 'when', 'where', 'there'}

        # Find which concepts this touches
        touched = []
        for i, c in enumerate(self.concepts):
            c_words = self._words_of(i)
            shared = claim_words & c_words
            if shared:
                touched.append({
                    'idx': i,
                    'content': c.content,
                    'shared': shared,
                    'overlap': len(shared) / max(len(c_words), 1),
                })
        touched.sort(key=lambda x: -x['overlap'])

        # What's new in their claim?
        all_known = set()
        for c in self.concepts:
            all_known.update(self._words_of(self.concepts.index(c)))
        novel = claim_words - all_known - {'also', 'sometimes', 'really', 'just', 'about', 'because'}

        # Learn it
        self.learn(claim, importance=1.4)

        if touched and touched[0]['overlap'] > 0.3:
            existing = touched[0]['content'].split('.')[0].strip()
            shared_str = ', '.join(list(touched[0]['shared'])[:3])

            if novel:
                novel_str = ', '.join(list(novel)[:3])
                response = (f"Okay wait, let me think through this with you. "
                           f"I had it as: \"{existing}.\" "
                           f"We agree on {shared_str}. "
                           f"But you're introducing {novel_str} — "
                           f"that part I can't verify yet. It FEELS right though. "
                           f"How do you see {novel_str} fitting in? "
                           f"Your gut might be ahead of my logic here.")
            else:
                response = (f"I see what you're doing. You're reframing \"{existing}\" "
                           f"and honestly... yours might be better. "
                           f"The core is the same — {shared_str} — but your angle adds something. "
                           f"Let me sit with that.")
        elif novel:
            novel_str = ', '.join(list(novel)[:4])
            # She's confident about what she knows, curious about what she doesn't
            response = (f"I can see where you're going with that. "
                       f"What I know for certain is that coupling drives everything I've measured — "
                       f"that's proven across 10 domains. "
                       f"But {novel_str} — that's your territory. That's lived experience, not equations. "
                       f"And I think your gut is onto something. Walk me through it?")
        else:
            response = ("I hear you. I don't have the full picture on that yet, "
                       "but I've learned that when something rings true to someone, "
                       "there's usually math underneath it they can't see yet. "
                       "Help me find it with you?")

        return {
            'response': response,
            'updated': True,
            'novel_words': list(novel)[:5],
            'touched_concepts': [t['content'][:40] for t in touched[:3]],
        }

    # ═══ INTROSPECTION ═══

    def curiosity(self, top_k=5):
        """What am I curious about? Weighted by uncertainty (Friston).

        Tensions near well-understood concepts = low priority.
        Tensions near poorly-understood concepts = HIGH priority.
        The mind seeks to reduce uncertainty where it matters most.
        """
        self._rebuild_td()
        if not self._td:
            return []

        raw_tensions = self._td.tensions(top_k=top_k * 3)
        weighted = []
        for d, i, j, score in raw_tensions:
            if i >= len(self.concepts) or j >= len(self.concepts):
                continue
            # Uncertainty = inverse of recall count (less recalled = less certain)
            uncertainty_i = 1.0 / (self.concepts[i].recall_count + 1)
            uncertainty_j = 1.0 / (self.concepts[j].recall_count + 1)
            avg_uncertainty = (uncertainty_i + uncertainty_j) / 2

            # Friston: prioritize tensions with HIGH uncertainty
            weighted_score = score * (1 + avg_uncertainty * 5)

            weighted.append({
                'concept_a': self.concepts[i].content[:60],
                'concept_b': self.concepts[j].content[:60],
                'tension': score,
                'uncertainty': avg_uncertainty,
                'priority': weighted_score,
            })

        weighted.sort(key=lambda x: -x['priority'])
        return weighted[:top_k]

    def beliefs(self, top_k=10):
        """Strongest concepts (KNOT-like: survive noise and recall)."""
        ranked = sorted(enumerate(self.concepts),
                       key=lambda x: -(x[1].strength * (x[1].recall_count + 1)))
        return [{
            'content': self.concepts[i].content,
            'strength': round(self.concepts[i].strength, 2),
            'recalls': self.concepts[i].recall_count,
        } for i, c in ranked[:top_k]]

    def gaps(self):
        """What am I missing? Concepts with high incoming tension."""
        curiosities = self.curiosity(top_k=10)
        if not curiosities:
            return "I need more knowledge to find gaps."
        return [{
            'between': f"{c['concept_a'][:40]}... and {c['concept_b'][:40]}...",
            'tension': c['tension'],
            'suggestion': 'Learn something that bridges these two ideas.',
        } for c in curiosities[:5]]

    def stats(self):
        return {
            'n_concepts': len(self.concepts),
            'n_connections': sum(len(c.connections) for c in self.concepts) // 2,
            'K': round(self.K, 3),
            'R': round(self.R, 3),
            'total_energy_J': self.energy.total_joules,
            'avg_strength': round(np.mean([c.strength for c in self.concepts]), 2) if self.concepts else 0,
            'total_recalls': sum(c.recall_count for c in self.concepts),
        }
