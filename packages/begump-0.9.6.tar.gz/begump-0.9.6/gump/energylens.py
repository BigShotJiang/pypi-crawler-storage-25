"""
ENERGYLENS — Computational thermodynamics
=============================================
Profile any computation. Report Landauer cost. Show the gap.

    from gump.energylens import profile
    result = profile(my_function, n_calls=1000)
    print(result['landauer_J'])       # minimum physics cost
    print(result['actual_J'])         # what it actually used
    print(result['gap'])              # orders of magnitude above limit
    print(result['suggestions'])      # how to close the gap
"""
import numpy as np
import time
from gump.core import EnergyTracker, LANDAUER_PER_BIT


def profile(fn, args=(), n_calls=100, watts=10):
    """Profile a function's energy cost.

    Args:
        fn: callable to profile
        args: arguments to pass
        n_calls: number of times to call
        watts: estimated power draw of your machine (default 10W for M4)

    Returns dict with Landauer cost, actual cost, gap, suggestions.
    """
    # Estimate bits processed by measuring output entropy
    results = []
    t0 = time.time()
    for _ in range(n_calls):
        result = fn(*args)
        if result is not None:
            if isinstance(result, (int, float)):
                results.append(float(result))
            elif isinstance(result, np.ndarray):
                results.append(result.ravel()[:10].tolist())
    elapsed = time.time() - t0

    # Estimate bits from output variance
    if results:
        flat = np.array([r if isinstance(r, (int, float)) else r[0] if isinstance(r, list) and r else 0
                        for r in results])
        if np.std(flat) > 0:
            # Shannon entropy estimate
            hist, _ = np.histogram(flat, bins=min(50, len(flat)))
            probs = hist / hist.sum()
            probs = probs[probs > 0]
            entropy_bits = float(-np.sum(probs * np.log2(probs)))
        else:
            entropy_bits = 1.0
    else:
        entropy_bits = 32.0  # assume 32-bit output

    # Total bits erased ≈ calls × output bits × computation ratio
    # Conservative: each call erases at least output_bits * 10 (intermediate steps)
    bits_per_call = max(entropy_bits * 10, 32)
    total_bits = bits_per_call * n_calls

    landauer_J = total_bits * LANDAUER_PER_BIT
    actual_J = watts * elapsed
    gap = actual_J / landauer_J if landauer_J > 0 else float('inf')
    orders = np.log10(gap) if gap > 0 else 0

    # Suggestions
    suggestions = []
    if orders > 12:
        suggestions.append("Consider reversible computation (ECHO pattern) for the core logic")
    if orders > 10:
        suggestions.append("Data movement dominates — minimize copies, use shared memory")
    if orders > 8:
        suggestions.append("Consider GPU offload for parallel operations")
    if orders > 6:
        suggestions.append("Cache optimization would reduce memory energy")
    if elapsed / n_calls > 0.001:
        suggestions.append(f"Function takes {elapsed/n_calls*1000:.1f}ms/call — look for algorithmic improvements")

    return {
        'n_calls': n_calls,
        'total_time_s': elapsed,
        'time_per_call_ms': elapsed / n_calls * 1000,
        'bits_erased': int(total_bits),
        'landauer_J': landauer_J,
        'actual_J': actual_J,
        'gap': gap,
        'orders_above_limit': orders,
        'suggestions': suggestions,
    }


def compare_engines(fn, args_list, engine_names, watts=10):
    """Compare multiple implementations of the same computation.
    Returns sorted by Landauer efficiency."""
    results = []
    for fn_impl, args, name in zip(fn, args_list, engine_names):
        r = profile(fn_impl, args, n_calls=10, watts=watts)
        r['engine'] = name
        results.append(r)

    results.sort(key=lambda x: x['landauer_J'])
    return results


def estimate_training_cost(n_params, n_epochs, batch_size=32, watts=300):
    """Estimate training cost for a neural network.

    Args:
        n_params: number of parameters
        n_epochs: number of training epochs
        batch_size: training batch size
        watts: GPU power draw (default 300W for A100)
    """
    # Each parameter update erases ~32 bits (float32)
    bits_per_step = n_params * 32
    # Assume 1000 steps per epoch
    steps = n_epochs * 1000
    total_bits = bits_per_step * steps

    landauer_J = total_bits * LANDAUER_PER_BIT

    # Rough time estimate: ~1ms per step for medium model
    est_time_s = steps * 0.001 * (n_params / 1e6)
    actual_J = watts * est_time_s

    return {
        'n_params': n_params,
        'n_epochs': n_epochs,
        'total_bits_erased': int(total_bits),
        'landauer_minimum_J': landauer_J,
        'landauer_minimum_kWh': landauer_J / 3.6e6,
        'estimated_actual_J': actual_J,
        'estimated_actual_kWh': actual_J / 3.6e6,
        'gap': actual_J / landauer_J if landauer_J > 0 else 0,
        'orders_above_limit': np.log10(actual_J / landauer_J) if landauer_J > 0 else 0,
        'could_save': f'{(1 - landauer_J/actual_J)*100:.6f}% of energy is wasted',
    }
