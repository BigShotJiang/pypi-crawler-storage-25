"""
THE MACHINE — one function, every domain.

    from gump.machine import machine

    result = machine(nodes, edges, weights)

Describe the coupling. Get back what emerges.
The dimensionality isn't an input. It's an output.

Every product is a special case of this function.
"""
import numpy as np
from gump.core import _TensionDetector, PHI, LANDAUER_PER_BIT


def machine(nodes, edges, weights=None, n_dims=None):
    """The universal coupling engine.

    Args:
        nodes: list of node names (any hashable)
        edges: list of (i, j) index pairs
        weights: list of floats (coupling strength per edge). Default: all 1.0
        n_dims: number of spatial dimensions to embed. Default: auto-detect

    Returns:
        positions: {node: [coords]} — where things land in spectral space
        K: coupling strength
        R: order parameter
        E: energy cost (Landauer)
        T: tension — what wants to couple but hasn't
        clusters: {cluster_id: [nodes]}
        tensions: top uncoupled pairs
        dimensionality: how many dimensions the coupling needs
    """
    if nodes is None or not isinstance(nodes, (list, tuple)):
        return {'error': 'nodes must be a non-empty list', 'K': 0, 'R': 0, 'E': 0, 'T': 0}
    if len(nodes) == 0:
        return {'error': 'nodes must be a non-empty list', 'K': 0, 'R': 0, 'E': 0, 'T': 0}
    if edges is None or not isinstance(edges, (list, tuple)):
        edges = []
    if weights is None:
        weights = [1.0] * len(edges)

    n = len(nodes)
    if n < 2:
        return {'error': 'Need at least 2 nodes', 'K': 0, 'R': 0, 'E': 0, 'T': 0}

    # Clean edges and weights
    clean_edges = []
    clean_weights = []
    for idx, (i, j) in enumerate(edges):
        if 0 <= i < n and 0 <= j < n and i != j:
            w = float(weights[idx]) if idx < len(weights) else 1.0
            if np.isfinite(w) and w != 0:
                clean_edges.append((i, j))
                clean_weights.append(abs(w))

    if not clean_edges:
        # No edges: everything is uncoupled
        return {
            'nodes': list(nodes), 'n': n,
            'positions': {nodes[i]: [0.0] for i in range(n)},
            'K': 0, 'R': 0, 'E': 0, 'T': 0,
            'clusters': {0: list(nodes)},
            'tensions': [],
            'dimensionality': 0,
        }

    # Auto-detect dimensionality: how many significant eigenvectors?
    max_vecs = min(n - 1, 20)
    td = _TensionDetector(n, clean_edges, clean_weights, n_vecs=max_vecs)

    if n_dims is None:
        # Auto: find where eigenvalues drop off
        # The number of "significant" eigenvectors = the natural dimensionality
        coords = td.coords
        variances = np.var(coords, axis=0)
        total_var = np.sum(variances)
        if total_var > 0:
            cumulative = np.cumsum(variances) / total_var
            # Dimensions that explain 95% of variance
            n_dims = int(np.searchsorted(cumulative, 0.95)) + 1
            n_dims = max(1, min(n_dims, coords.shape[1]))
        else:
            n_dims = 1

    coords = td.coords[:, :min(n_dims, td.coords.shape[1])]

    # Pad if needed
    if coords.shape[1] < n_dims:
        pad = np.zeros((n, n_dims - coords.shape[1]))
        coords = np.hstack([coords, pad])

    # ═══ K: coupling strength ═══
    # Normalized: total edge weight / maximum possible
    max_edges = n * (n - 1) / 2
    K = float(np.sum(clean_weights) / (max_edges + 1e-12))

    # ═══ R: order parameter ═══
    # How clustered are the nodes? Low spread = high order
    center = np.mean(coords, axis=0)
    dists = np.array([np.linalg.norm(coords[i] - center) for i in range(n)])
    if np.max(dists) > 0:
        R = float(1.0 - np.std(dists) / (np.max(dists) + 1e-12))
    else:
        R = 1.0
    R = max(0, min(1, R))

    # ═══ E: energy (Landauer cost of the coupling) ═══
    total_bits = sum(max(1, int(np.ceil(np.log2(max(abs(w), 2))))) for w in clean_weights)
    E = float(total_bits * LANDAUER_PER_BIT)

    # ═══ T: tension ═══
    raw_tensions = td.tensions(top_k=min(50, n * (n - 1) // 2))
    tensions = []
    for d, i, j, score in raw_tensions:
        tensions.append({
            'node_a': nodes[i], 'node_b': nodes[j],
            'tension': round(float(score), 4),
            'distance': round(float(d), 4),
        })
    T = float(np.mean([t['tension'] for t in tensions])) if tensions else 0

    # ═══ Clusters ═══
    from collections import defaultdict
    if n_dims >= 1 and n >= 4:
        labels = (coords[:, 0] > np.median(coords[:, 0])).astype(int)
    else:
        labels = np.zeros(n, dtype=int)
    clusters = defaultdict(list)
    for i in range(n):
        clusters[int(labels[i])].append(nodes[i])
    clusters = dict(clusters)

    # ═══ Width: parallelism / multiplicity ═══
    # How many independent groups exist at each spectral level?
    width = n_dims  # base width = number of significant dimensions

    return {
        'nodes': list(nodes),
        'n': n,
        'positions': {nodes[i]: coords[i].tolist() for i in range(n)},
        'K': round(K, 4),
        'R': round(R, 4),
        'E': E,
        'T': round(T, 4),
        'clusters': clusters,
        'tensions': tensions[:20],
        'dimensionality': n_dims,
    }
