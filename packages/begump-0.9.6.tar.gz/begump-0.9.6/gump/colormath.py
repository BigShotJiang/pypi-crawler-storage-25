"""
COLORMATH — True color theory for automotive paint.
=====================================================
Color is frequency. Mixing is vector math. Drying is chemistry.
This is the real rules — what a master painter knows in his gut,
written down as math that doesn't lie.

    from gump.colormath import Color, mix, blend_plan, dry_time, match

Built for the guy who can eyeball a blend zone but wants to know WHY.
"""
import numpy as np
import math

# ═══ CIE Lab: the color space that matches human eyes ═══
# L* = lightness (0 black, 100 white)
# a* = green(-) to red(+)
# b* = blue(-) to yellow(+)

# D65 illuminant reference (standard daylight, 6504K) — scaled to 100
_D65 = (95.047, 100.000, 108.883)


def _srgb_to_xyz(r, g, b):
    """sRGB (0-255) to CIE XYZ."""
    rgb = np.array([r, g, b]) / 255.0
    # Inverse sRGB companding
    rgb = np.where(rgb > 0.04045, ((rgb + 0.055) / 1.055) ** 2.4, rgb / 12.92)
    # sRGB to XYZ matrix (D65)
    M = np.array([
        [0.4124564, 0.3575761, 0.1804375],
        [0.2126729, 0.7151522, 0.0721750],
        [0.0193339, 0.1191920, 0.9503041],
    ])
    return M @ (rgb * 100)


def _xyz_to_lab(x, y, z):
    """CIE XYZ to CIE L*a*b* (D65)."""
    xyz = np.array([x, y, z]) / np.array(_D65)
    xyz = np.where(xyz > 0.008856, xyz ** (1/3), 7.787 * xyz + 16/116)
    L = 116 * xyz[1] - 16
    a = 500 * (xyz[0] - xyz[1])
    b = 200 * (xyz[1] - xyz[2])
    return float(L), float(a), float(b)


def _lab_to_xyz(L, a, b):
    """CIE L*a*b* to XYZ (D65)."""
    fy = (L + 16) / 116
    fx = a / 500 + fy
    fz = fy - b / 200
    x = _D65[0] * (fx ** 3 if fx ** 3 > 0.008856 else (fx - 16/116) / 7.787)
    y = _D65[1] * (fy ** 3 if fy ** 3 > 0.008856 else (fy - 16/116) / 7.787)
    z = _D65[2] * (fz ** 3 if fz ** 3 > 0.008856 else (fz - 16/116) / 7.787)
    return x, y, z


def _xyz_to_srgb(x, y, z):
    """CIE XYZ to sRGB (0-255)."""
    M_inv = np.array([
        [ 3.2404542, -1.5371385, -0.4985314],
        [-0.9692660,  1.8760108,  0.0415560],
        [ 0.0556434, -0.2040259,  1.0572252],
    ])
    rgb = M_inv @ np.array([x, y, z]) / 100.0
    rgb = np.clip(rgb, 0, None)  # clamp negatives before gamma
    rgb = np.where(rgb > 0.0031308, 1.055 * rgb ** (1/2.4) - 0.055, 12.92 * rgb)
    rgb = np.clip(rgb * 255, 0, 255)
    return int(round(rgb[0])), int(round(rgb[1])), int(round(rgb[2]))


def _lab_to_lch(L, a, b):
    """Lab to LCh (Lightness, Chroma, Hue)."""
    C = math.sqrt(a**2 + b**2)
    h = math.degrees(math.atan2(b, a)) % 360
    return L, C, h


def _lch_to_lab(L, C, h):
    """LCh to Lab."""
    h_rad = math.radians(h)
    a = C * math.cos(h_rad)
    b = C * math.sin(h_rad)
    return L, a, b


# ═══ Color Object ═══

class Color:
    """A color in every space simultaneously.

        c = Color(r=255, g=0, b=0)          # from RGB
        c = Color(L=53.2, a=80.1, b=67.2)   # from Lab
        c = Color(hex='#FF0000')             # from hex

    Access any representation:
        c.rgb, c.lab, c.lch, c.hex, c.L, c.C, c.h
    """
    def __init__(self, r=None, g=None, b=None, L=None, a=None, b_=None, hex=None):
        if hex is not None:
            hex = hex.lstrip('#')
            r, g, b = int(hex[0:2], 16), int(hex[2:4], 16), int(hex[4:6], 16)

        if r is not None and g is not None and b is not None:
            self._r, self._g, self._b = int(r), int(g), int(b)
            x, y, z = _srgb_to_xyz(self._r, self._g, self._b)
            self._L, self._a, self._b_val = _xyz_to_lab(x, y, z)
        elif L is not None and a is not None and b_ is not None:
            self._L, self._a, self._b_val = float(L), float(a), float(b_)
            x, y, z = _lab_to_xyz(self._L, self._a, self._b_val)
            self._r, self._g, self._b = _xyz_to_srgb(x, y, z)
        else:
            self._r, self._g, self._b = 0, 0, 0
            self._L, self._a, self._b_val = 0.0, 0.0, 0.0

        self._L2, self._C, self._h = _lab_to_lch(self._L, self._a, self._b_val)

    @property
    def rgb(self):
        return (self._r, self._g, self._b)

    @property
    def lab(self):
        return (round(self._L, 2), round(self._a, 2), round(self._b_val, 2))

    @property
    def lch(self):
        return (round(self._L, 2), round(self._C, 2), round(self._h, 2))

    @property
    def L(self):
        return round(self._L, 2)

    @property
    def C(self):
        return round(self._C, 2)

    @property
    def h(self):
        return round(self._h, 2)

    @property
    def hex(self):
        return f'#{self._r:02X}{self._g:02X}{self._b:02X}'

    def __repr__(self):
        return f'Color({self.hex} L={self.L} C={self.C} h={self.h}°)'


# ═══ Delta E: how different two colors look ═══

def delta_e(c1, c2):
    """CIEDE2000 — the gold standard for 'how different do these look?'

    < 1.0:  not perceptible (perfect match)
    1-2:    barely perceptible (acceptable in body shop)
    2-3.5:  noticeable up close
    3.5-5:  obvious difference
    > 5:    different colors

    This is what spectrophotometers compute.
    """
    L1, a1, b1 = c1._L, c1._a, c1._b_val
    L2, a2, b2 = c2._L, c2._a, c2._b_val

    # CIEDE2000 implementation
    Lbar = (L1 + L2) / 2
    C1 = math.sqrt(a1**2 + b1**2)
    C2 = math.sqrt(a2**2 + b2**2)
    Cbar = (C1 + C2) / 2

    G = 0.5 * (1 - math.sqrt(Cbar**7 / (Cbar**7 + 25**7)))
    a1p = a1 * (1 + G)
    a2p = a2 * (1 + G)
    C1p = math.sqrt(a1p**2 + b1**2)
    C2p = math.sqrt(a2p**2 + b2**2)
    Cbarp = (C1p + C2p) / 2

    h1p = math.degrees(math.atan2(b1, a1p)) % 360
    h2p = math.degrees(math.atan2(b2, a2p)) % 360

    if abs(h1p - h2p) <= 180:
        dhp = h2p - h1p
    elif h2p - h1p > 180:
        dhp = h2p - h1p - 360
    else:
        dhp = h2p - h1p + 360

    dLp = L2 - L1
    dCp = C2p - C1p
    dHp = 2 * math.sqrt(C1p * C2p) * math.sin(math.radians(dhp / 2))

    if abs(h1p - h2p) <= 180:
        Hbarp = (h1p + h2p) / 2
    elif h1p + h2p < 360:
        Hbarp = (h1p + h2p + 360) / 2
    else:
        Hbarp = (h1p + h2p - 360) / 2

    T = (1 - 0.17 * math.cos(math.radians(Hbarp - 30))
         + 0.24 * math.cos(math.radians(2 * Hbarp))
         + 0.32 * math.cos(math.radians(3 * Hbarp + 6))
         - 0.20 * math.cos(math.radians(4 * Hbarp - 63)))

    SL = 1 + 0.015 * (Lbar - 50)**2 / math.sqrt(20 + (Lbar - 50)**2)
    SC = 1 + 0.045 * Cbarp
    SH = 1 + 0.015 * Cbarp * T

    RT_term = -2 * math.sqrt(Cbarp**7 / (Cbarp**7 + 25**7))
    dtheta = 30 * math.exp(-((Hbarp - 275) / 25)**2)
    RC = RT_term * math.sin(math.radians(2 * dtheta))

    dE = math.sqrt(
        (dLp / SL)**2 + (dCp / SC)**2 + (dHp / SH)**2
        + RC * (dCp / SC) * (dHp / SH)
    )
    return round(dE, 2)


# ═══ Paint Mixing ═══

def mix(colors, ratios=None):
    """Mix paint colors by weight ratio.

    Colors mixed in Lab space (subtractive, perceptually uniform).
    This is how real paint mixes — NOT RGB averaging.

        red = Color(r=200, g=30, b=30)
        white = Color(r=255, g=255, b=255)
        pink = mix([red, white], [1, 3])  # 1 part red, 3 parts white
    """
    if not colors:
        return None
    if ratios is None:
        ratios = [1.0] * len(colors)
    total = sum(ratios)
    if total == 0:
        return colors[0]

    # Mix in Lab (weighted average — correct for subtractive pigments)
    L = sum(c._L * r for c, r in zip(colors, ratios)) / total
    a = sum(c._a * r for c, r in zip(colors, ratios)) / total
    b = sum(c._b_val * r for c, r in zip(colors, ratios)) / total
    return Color(L=L, a=a, b_=b)


def lighten(color, amount=0.2):
    """Lighten by mixing with white. amount = 0-1 (how much white).

    This is what adding white toner does — raises L*, drops C* (desaturates).
    """
    white = Color(r=255, g=255, b=255)
    return mix([color, white], [1 - amount, amount])


def darken(color, amount=0.2):
    """Darken by mixing with black. amount = 0-1.

    Warning: black pigments are overpowering. Small amounts shift dramatically.
    Black also shifts hue — a red darkened with black drifts toward brown.
    """
    black = Color(r=0, g=0, b=0)
    return mix([color, black], [1 - amount, amount])


def shift_hue(color, degrees):
    """Rotate hue on the color wheel.

    +degrees = toward yellow/red (warm)
    -degrees = toward blue/green (cool)

    Rule: you can only shift toward ADJACENT colors on the wheel.
    Shifting 180° gives the complement (makes mud if mixed).
    """
    L, C, h = color._L, color._C, color._h
    h_new = (h + degrees) % 360
    L_new, a_new, b_new = _lch_to_lab(L, C, h_new)
    return Color(L=L_new, a=a_new, b_=b_new)


def desaturate(color, amount=0.3):
    """Remove chroma (saturation). amount = 0-1.

    This is what adding a complementary toner does — pulls toward gray.
    amount=1.0 gives pure gray at the same lightness.
    """
    L, C, h = color._L, color._C, color._h
    C_new = C * (1 - amount)
    L_new, a_new, b_new = _lch_to_lab(L, C_new, h)
    return Color(L=L_new, a=a_new, b_=b_new)


# ═══ Blend Plan ═══

def blend_plan(target, existing, n_coats=4):
    """Generate a coat-by-coat blend plan from existing color to target.

    Returns a list of colors for each coat, transitioning
    from 100% target (repair zone) to mixed (blend zone).
    This is the intermix method the pros use.

        plan = blend_plan(new_red, old_red, n_coats=4)
        # plan[0] = pure new color (repair area)
        # plan[1] = 70/30 new/old
        # plan[2] = 50/50
        # plan[3] = 30/70 (feather edge)
    """
    ratios = []
    for i in range(n_coats):
        t = 1.0 - (i / max(n_coats - 1, 1)) * 0.7  # 100% → 30%
        ratios.append(t)

    plan = []
    for t in ratios:
        blended = mix([target, existing], [t, 1 - t])
        de = delta_e(blended, existing)
        plan.append({
            'coat': len(plan) + 1,
            'target_pct': round(t * 100),
            'existing_pct': round((1 - t) * 100),
            'color': blended,
            'delta_e_to_existing': de,
        })
    return plan


# ═══ Dry Time Calculator ═══

# Base times at 70°F (21°C), <50% humidity
_DRY_TIMES = {
    'flash_base_between':   {'minutes': 4,    'desc': 'Between basecoat coats'},
    'flash_base_final':     {'minutes': 15,   'desc': 'Final basecoat flash before clear'},
    'flash_clear_between':  {'minutes': 8,    'desc': 'Between clearcoat coats'},
    'recoat_window_clear':  {'minutes': 30,   'desc': 'Max time before clear needs scuff'},
    'tape_free':            {'minutes': 180,  'desc': 'Safe for careful tape/handling'},
    'dust_free':            {'minutes': 30,   'desc': 'Dust no longer sticks'},
    'wet_sand_ready':       {'minutes': 1440, 'desc': 'Ready for wet sand (air dry)'},
    'wet_sand_ready_bake':  {'minutes': 240,  'desc': 'Ready for wet sand (after bake)'},
    'polish_ready':         {'minutes': 1440, 'desc': 'Ready for machine polish (air dry)'},
    'full_cure':            {'minutes': 43200, 'desc': 'Full crosslink cure (30 days)'},
}


def dry_time(temp_f=70, humidity_pct=40, baked=False, bake_temp_f=None, bake_minutes=None):
    """Calculate dry times adjusted for temperature and humidity.

    The Rule of 15: every 15°F above 70°F halves dry time.
    Every 15°F below 70°F doubles it.
    Below 55°F: catalyst goes DORMANT. Do not paint.

    Humidity above 50%: adds 25% to all times.
    Humidity above 70%: adds 50% — risk of solvent pop.

    Returns dict of all critical times in minutes.
    """
    if temp_f < 55:
        return {'error': 'Below 55°F — catalyst dormant. DO NOT PAINT. Film will never cure properly.'}

    # Temperature adjustment (Rule of 15)
    temp_factor = 2 ** ((70 - temp_f) / 15)

    # Humidity adjustment
    if humidity_pct > 70:
        humid_factor = 1.5
        humid_warning = 'HIGH HUMIDITY — risk of solvent pop and bubbles'
    elif humidity_pct > 50:
        humid_factor = 1.25
        humid_warning = 'Elevated humidity — extended flash times recommended'
    else:
        humid_factor = 1.0
        humid_warning = None

    factor = temp_factor * humid_factor

    results = {}
    for key, info in _DRY_TIMES.items():
        adjusted = info['minutes'] * factor
        # Baked items
        if baked and 'bake' not in key and key in ('wet_sand_ready', 'polish_ready', 'full_cure'):
            if key == 'full_cure':
                adjusted = 10080  # still 7 days minimum even with bake
            else:
                adjusted = _DRY_TIMES.get(key.replace('ready', 'ready_bake'), info)['minutes'] * factor
        results[key] = {
            'minutes': round(adjusted, 1),
            'hours': round(adjusted / 60, 1),
            'description': info['desc'],
        }

    results['conditions'] = {
        'temp_f': temp_f,
        'humidity_pct': humidity_pct,
        'temp_factor': round(temp_factor, 2),
        'humid_factor': humid_factor,
        'baked': baked,
    }
    if humid_warning:
        results['warning'] = humid_warning

    # Reducer recommendation
    if temp_f < 70:
        results['reducer'] = 'FAST — compensates for slow evaporation in cold'
    elif temp_f > 85:
        results['reducer'] = 'SLOW — keeps film open in heat, prevents orange peel'
    else:
        results['reducer'] = 'MEDIUM — standard range'

    return results


# ═══ Match Quality ═══

def match(color_a, color_b):
    """How well do two colors match? Returns human-readable verdict.

    Uses CIEDE2000 (what the spectrophotometer computes).
    """
    de = delta_e(color_a, color_b)
    L_diff = color_b._L - color_a._L
    C_diff = color_b._C - color_a._C
    h_diff = color_b._h - color_a._h
    if h_diff > 180:
        h_diff -= 360
    elif h_diff < -180:
        h_diff += 360

    if de < 1.0:
        verdict = 'PERFECT — not perceptible by human eye'
    elif de < 2.0:
        verdict = 'ACCEPTABLE — barely perceptible, body shop quality'
    elif de < 3.5:
        verdict = 'NOTICEABLE — visible up close, blend zone needed'
    elif de < 5.0:
        verdict = 'OBVIOUS — visible at arm length, needs tinting'
    else:
        verdict = 'MISMATCH — different colors, re-formulate'

    adjustments = []
    if abs(L_diff) > 2:
        adjustments.append(f'{"Darken" if L_diff > 0 else "Lighten"} (L* off by {L_diff:+.1f})')
    if abs(C_diff) > 2:
        adjustments.append(f'{"Desaturate" if C_diff > 0 else "Add chroma"} (C* off by {C_diff:+.1f})')
    if abs(h_diff) > 3:
        adjustments.append(f'Shift hue {h_diff:+.1f}° ({"warmer" if h_diff > 0 else "cooler"})')

    return {
        'delta_e': de,
        'verdict': verdict,
        'L_diff': round(L_diff, 2),
        'C_diff': round(C_diff, 2),
        'h_diff': round(h_diff, 2),
        'adjustments': adjustments,
    }


# ═══ Color Wheel & Relationships ═══

def complementary(color):
    """The complement — 180° opposite. Mixed together makes mud."""
    return shift_hue(color, 180)


def analogous(color, spread=30):
    """Adjacent colors on the wheel — harmonious, easy to blend."""
    return [shift_hue(color, -spread), color, shift_hue(color, spread)]


def triadic(color):
    """Three colors equally spaced — vibrant, balanced."""
    return [color, shift_hue(color, 120), shift_hue(color, 240)]


# ═══ Paint System Reference ═══

PAINT_CHEMISTRY = {
    'basecoat': {
        'type': '1K (single component)',
        'cures_by': 'Solvent evaporation only — no crosslinking',
        'binder': 'Acrylic or polyester resin',
        'note': 'Soft film by itself. Needs clearcoat for durability.',
    },
    'clearcoat_2k': {
        'type': '2K (two component)',
        'cures_by': 'Isocyanate crosslinking (NCO + OH → urethane)',
        'component_a': 'Hydroxyl-functional acrylic polyol',
        'component_b': 'HDI or IPDI polyisocyanate hardener',
        'common_ratios': {'4:1': 'standard', '3:1': 'European systems', '2:1': 'high-solids'},
        'nco_oh_ratio': '1.5:1 to 3:1 (excess NCO for complete crosslinking)',
        'protection': 'UV absorbers (benzotriazole) + HALS (radical scavengers)',
        'thickness': '30-50 micrometers',
    },
    'hardener_effects': {
        'too_much': 'Brittle, cracks with thermal cycling, yellowing',
        'too_little': 'Soft, never fully cures, poor chemical resistance, tacky',
        'correct': 'Dense crosslink network, hard, chemical-resistant, durable',
    },
    'intercoat_bonding': {
        'mechanism': 'Clearcoat solvents partially dissolve fresh basecoat surface (solvent bite) + covalent bonds form across boundary',
        'recoat_window': '24-48 hours max — after that, must scuff-sand for mechanical adhesion',
    },
}


METALLIC_RULES = {
    'flake_orientation': {
        'closer_gun': 'Wetter application → flakes lay flatter → darker, more uniform',
        'farther_gun': 'Drier application → flakes tilt randomly → lighter, coarser sparkle',
        'higher_pressure': 'Flakes lay flat → lighter face, more specular → metallic "pop"',
        'lower_pressure': 'Random orientation → darker face, less pop',
    },
    'flop': {
        'what': 'Color change from head-on vs side angle',
        'coarse_flake': 'More flop (dramatic light-to-dark travel)',
        'fine_flake': 'Less flop (uniform appearance)',
        'face_15deg': 'Highlight — dominated by flake reflection',
        'mid_45deg': 'Body color — what you see normally',
        'flop_110deg': 'Side tone — dominated by absorption pigments below flakes',
    },
    'mist_coat': 'Light, dry pass at blend edge to align flakes with existing panel',
}


REDUCER_GUIDE = {
    'fast':   {'temp_range': 'Below 70°F', 'use': 'Small spot repairs, cold shops', 'risk': 'Orange peel in warm conditions'},
    'medium': {'temp_range': '70-85°F', 'use': 'Default choice, standard conditions', 'risk': 'None when conditions match'},
    'slow':   {'temp_range': 'Above 85°F', 'use': 'Large panels, hot shops, maintaining wet edge', 'risk': 'Runs/sags in cold conditions'},
}


CURE_STAGES = {
    'day_1':  {'hardness_pct': 60, 'note': 'Handle carefully. No tape.'},
    'day_7':  {'hardness_pct': 80, 'note': 'Can wet-sand and polish.'},
    'day_30': {'hardness_pct': 95, 'note': 'Approaching final hardness.'},
    'day_90': {'hardness_pct': 100, 'note': 'Full cure. Maximum durability.'},
}
