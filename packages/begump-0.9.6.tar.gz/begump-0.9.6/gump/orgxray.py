"""ORGXRAY — Organizational structure from connections."""
import numpy as np
from collections import defaultdict

def analyze(connections):
    """Analyze org structure. connections: list of (a,b) tuples."""
    if not connections: return {'error':'No connections'}
    adj = defaultdict(set)
    nodes = set()
    for a,b in connections:
        a,b = str(a),str(b); nodes.add(a); nodes.add(b); adj[a].add(b); adj[b].add(a)
    nodes = sorted(nodes); n = len(nodes)
    if n < 2: return {'error':'Need >= 2 nodes'}
    degrees = {nd:len(adj[nd]) for nd in nodes}
    dv = list(degrees.values())
    K = len(connections)/(n*(n-1)/2) if n>1 else 0
    R = 1/(1+np.std(dv)/(np.mean(dv)+1e-10))
    threshold = np.percentile(dv, 90)
    hubs = [nd for nd in nodes if degrees[nd] >= threshold]
    bottlenecks = []
    for node in nodes:
        if degrees[node] < 2: continue
        remaining = [nd for nd in nodes if nd != node]
        visited = set([remaining[0]]); stack = [remaining[0]]
        while stack:
            curr = stack.pop()
            for nb in adj[curr]:
                if nb != node and nb not in visited: visited.add(nb); stack.append(nb)
        if len(visited) < len(remaining): bottlenecks.append(node)
    return {'K':round(K,4),'R':round(R,4),'n_nodes':n,'n_edges':len(connections),
            'hubs':hubs[:10],'bottlenecks':bottlenecks[:10],'hub_dependence':round(max(dv)/np.mean(dv),2)}
