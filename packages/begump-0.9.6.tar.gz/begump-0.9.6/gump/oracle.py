"""ORACLE — Find hidden frequencies, project forward."""
import numpy as np

def extract(data, n_modes=10, sample_rate=1.0):
    """Extract dominant frequencies from a signal."""
    x = np.asarray(data, dtype=np.float64).ravel()
    n = len(x)
    if n < 4: return []
    fft = np.fft.rfft(x)
    freqs = np.fft.rfftfreq(n, d=1.0/sample_rate)
    mags = np.abs(fft); mags[0] = 0
    phases = np.angle(fft)
    top = np.argsort(mags)[::-1][:n_modes]
    return [{'frequency': round(float(freqs[i]),6), 'amplitude': round(float(mags[i])/n,6),
             'phase': round(float(phases[i]),6)} for i in top if mags[i] > 1e-10]

def predict(data, steps=50, n_modes=10, sample_rate=1.0):
    """Project a signal forward using extracted frequencies."""
    x = np.asarray(data, dtype=np.float64).ravel()
    modes = extract(x, n_modes, sample_rate)
    if not modes: return {'values': [float(x[-1])]*steps, 'confidence': [0.0]*steps, 'modes_used': 0}
    t = np.arange(len(x), len(x)+steps) / sample_rate
    pred = sum(m['amplitude']*np.cos(2*np.pi*m['frequency']*t + m['phase']) for m in modes) + np.mean(x)
    conf = np.exp(-np.arange(steps)/(len(x)*0.5))
    return {'values': [round(float(v),6) for v in pred], 'confidence': [round(float(c),4) for c in conf],
            'modes_used': len(modes), 'n_input': len(x)}
