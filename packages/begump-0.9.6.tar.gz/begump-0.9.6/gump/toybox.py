"""
TOYBOX — Free demos that can't be gamed.
==========================================
Each product gets a self-contained HTML demo page with:
- Fixed sample data (can't bring your own)
- 3 free interactions per browser fingerprint
- Live visualization of real results
- Clear "this is what you get with a license" messaging

    from gump.toybox import generate_all_demos, generate_demo

    # Generate all 7 demo pages
    generate_all_demos('/path/to/output/')

    # Generate one
    html = generate_demo('orgxray')
    with open('try-orgxray.html', 'w') as f: f.write(html)
"""

import json
import os

# ═══════════════════════════════════════════════════════════════
# DEMO DATA — fixed, curated, maximally impressive
# ═══════════════════════════════════════════════════════════════

DEMO_DATA = {
    'orgxray': {
        'title': 'Org X-Ray',
        'subtitle': 'See the real structure of any organization',
        'tagline': 'Drop in an org chart. Get back what the org chart won\'t show you.',
        'price': '$15/user/mo',
        'replaces': 'Lattice ($37K+/yr), Polinode, Microsoft Viva Insights',
        'sample_description': 'Sample: 20-person tech company with hidden silos',
        'features': [
            'Finds missing connections with 100% precision',
            'Detects silos, bottlenecks, and isolates',
            'Spectral layout shows REAL structure (not the org chart)',
            'Actionable recommendations: who should talk to whom',
            'Health score: 0-100 network wellness',
            'Works on: org charts, Slack exports, GitHub contributors, any CSV',
        ],
        'killer': 'Your data never leaves your machine. No cloud. No compliance risk.',
        'demo_limit': 5,
    },
    'learnengine': {
        'title': 'Learn Engine',
        'subtitle': 'Know what you don\'t know. Know when you get it.',
        'tagline': 'Map any subject. Track actual understanding. Detect the exact moment learning happens.',
        'price': '$29/user/mo',
        'replaces': 'Knewton ($11/mo per student), Coursera Business ($33/user/mo)',
        'sample_description': 'Sample: Web development curriculum with 10 topics',
        'features': [
            'Grokking detection: knows when you ACTUALLY understand (not just quiz scores)',
            'Knowledge gap finder: what you don\'t know that blocks what you want to know',
            'Smart recommendations: study prerequisites first, not random topics',
            'Per-topic confidence tracking with streak detection',
            'Spectral knowledge graph visualization',
            'Works on: any subject with topics and prerequisites',
        ],
        'killer': 'Detects real understanding — 224,000× more efficient than brute memorization.',
        'demo_limit': 5,
    },
    'foldwatch': {
        'title': 'Fold Watch',
        'subtitle': 'Protein structure from sequence. Instant. Local.',
        'tagline': 'Paste a protein sequence. Get secondary structure, misfolding risk, aggregation hotspots, and domain boundaries.',
        'price': '$199/mo',
        'replaces': 'Schrödinger ($50K-200K/yr), Benchling ($5K-7K/user/yr)',
        'sample_description': 'Sample: Amyloid-β 42 — the Alzheimer\'s peptide',
        'features': [
            'Secondary structure prediction (helix/sheet/coil)',
            'Misfolding risk assessment with specific risk factors',
            'Aggregation-prone region detection (found KLVFF in Amyloid-β)',
            'Disulfide bond candidate identification',
            'Structural domain boundaries from spectral analysis',
            'Charge distribution and hydrophobic core detection',
        ],
        'killer': 'Runs on your laptop in milliseconds. No GPU. No cloud. No sending proprietary sequences anywhere.',
        'demo_limit': 5,
    },
    'chipfast': {
        'title': 'Chip Fast',
        'subtitle': 'Design chips for free.',
        'tagline': 'Write a circuit. See it placed and routed. On your laptop.',
        'price': '$499/mo',
        'replaces': 'Cadence Innovus ($750K-2M/yr), Synopsys ICC2 ($500K+/yr)',
        'sample_description': 'Sample: 500-gate benchmark circuit',
        'features': [
            'Spectral placement: 40M gates in 4.5 seconds',
            'Wire length reduction vs random placement',
            'Row legalization with no gate overlap',
            'Manhattan routing estimation with congestion detection',
            'Missing connection detection (what WANTS to connect)',
            'Netlist parser: paste Verilog-style netlists directly',
        ],
        'killer': '96% cheaper than Cadence. Runs on a $500 Mac Mini. No license server.',
        'demo_limit': 5,
    },
    'aitrainer': {
        'title': 'AI Trainer',
        'subtitle': 'Train AI 224,000× cheaper.',
        'tagline': 'Know when your model understands. Stop wasting compute on memorization.',
        'price': '$49/user/mo',
        'replaces': 'Weights & Biases ($50/user/mo), Neptune.ai ($79/user/mo)',
        'sample_description': 'Sample: Classic grokking trajectory — memorize then suddenly understand',
        'features': [
            'Grokking detection: exact epoch when understanding arrives',
            'Multi-signal: accuracy jump + energy drop + weight compression + gap closing',
            'Plateau detection: knows when to change strategy',
            'Energy tracking: Landauer cost per correct answer',
            'Actionable recommendations: stop, continue, change optimizer, add data',
            'Compute savings estimation: how much you\'d waste without detection',
        ],
        'killer': 'Tells you WHEN to stop training. Every minute past grokking is wasted money.',
        'demo_limit': 5,
    },
    'knowledge': {
        'title': 'Knowledge Engine',
        'subtitle': 'Compress anything. Recall instantly.',
        'tagline': 'Feed it text. It builds a knowledge graph. Ask it anything.',
        'price': '$39/user/mo',
        'replaces': 'Glean ($65K-240K/yr), Notion AI ($20/user/mo), Roam ($15/mo)',
        'sample_description': 'Sample: Neuroscience textbook excerpt (5 passages)',
        'features': [
            'One-pass knowledge extraction — no training needed',
            'Concept graph with weighted connections',
            'Recall by resonance: find related concepts from any query',
            'Knowledge gap detection: what WANTS to connect but doesn\'t',
            'Topic clustering: automatic organization of concepts',
            'Works on: any text — research papers, docs, books, notes',
        ],
        'killer': 'Your documents stay on your machine. No data sent to any API. No per-token cost.',
        'demo_limit': 5,
    },
    'sensor': {
        'title': 'Universal Sensor',
        'subtitle': 'K/R/E/T of anything.',
        'tagline': 'Feed it any time series. Get coupling, order, energy, and tension. Diagnose anything.',
        'price': '$299/mo flat',
        'replaces': 'Datadog ($15-47/host/mo), Splunk ($150-2,700/GB/day/yr), Anodot ($1K+/mo)',
        'sample_description': 'Sample: Heart rate variability data with anomaly',
        'features': [
            'Four quantities: K (coupling), R (order), E (energy), T (tension)',
            'Regime detection: locked, coherent, transitional, volatile, diffuse',
            'Trend analysis: rising, falling, stable',
            'Anomaly detection: 3σ spike identification',
            'Human-readable diagnosis with recommendations',
            'Works on: ECG, EEG, stocks, temperature, seismic, network traffic — anything with numbers over time',
        ],
        'killer': 'Not just "something is wrong." Tells you WHAT regime you\'re in and WHY. No per-host billing.',
        'demo_limit': 5,
    },
}


def _fingerprint_js():
    """JavaScript browser fingerprinting — same concept as coupling_license machine fingerprint."""
    return '''
function _gumpFP() {
  // Canvas fingerprint
  var cv = document.createElement('canvas');
  var cx = cv.getContext('2d');
  cx.textBaseline = 'top';
  cx.font = '14px Arial';
  cx.fillText('GUMP:' + screen.width + ':' + screen.height, 2, 2);
  var canvasHash = cv.toDataURL().slice(-50);
  // Browser + hardware signals
  var sig = [
    navigator.userAgent,
    screen.width + 'x' + screen.height + 'x' + screen.colorDepth,
    new Date().getTimezoneOffset(),
    navigator.language,
    navigator.hardwareConcurrency || 0,
    canvasHash
  ].join('|');
  // Simple hash
  var h = 0;
  for (var i = 0; i < sig.length; i++) {
    h = ((h << 5) - h) + sig.charCodeAt(i);
    h |= 0;
  }
  return 'gfp_' + Math.abs(h).toString(36);
}

function _gumpTrialCheck(product, maxTries) {
  var fp = _gumpFP();
  var key = 'gump_trial_' + product + '_' + fp;
  var keyB = 'gump_tb_' + product; // backup without fingerprint
  // Check both storage locations
  var countA = parseInt(localStorage.getItem(key) || '0');
  var countB = parseInt(localStorage.getItem(keyB) || '0');
  // Also check cookie
  var cookies = document.cookie.split(';');
  var countC = 0;
  for (var i = 0; i < cookies.length; i++) {
    var c = cookies[i].trim();
    if (c.startsWith(key + '=')) countC = parseInt(c.split('=')[1]) || 0;
  }
  var count = Math.max(countA, countB, countC);
  return { count: count, remaining: Math.max(0, maxTries - count), fp: fp, key: key, keyB: keyB };
}

function _gumpTrialUse(product) {
  var fp = _gumpFP();
  var key = 'gump_trial_' + product + '_' + fp;
  var keyB = 'gump_tb_' + product;
  var count = parseInt(localStorage.getItem(key) || '0') + 1;
  // Store in THREE places — clearing one doesn't help
  localStorage.setItem(key, count);
  localStorage.setItem(keyB, count);
  document.cookie = key + '=' + count + ';max-age=31536000;path=/;SameSite=Strict';
  // Also store a session marker that survives incognito detection
  try { sessionStorage.setItem('gump_active', '1'); } catch(e) {}
  return count;
}
'''


def _demo_page_template(product_key):
    """Generate a complete toybox demo page for a product."""
    p = DEMO_DATA[product_key]
    features_html = '\n'.join(f'<li>{f}</li>' for f in p['features'])

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Try {p['title']} — GUMP</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:#08080d;color:#e8e4dc;font-family:Georgia,serif;min-height:100vh;}}
.page{{max-width:700px;margin:0 auto;padding:30px 20px 80px;}}
h1{{font-size:2em;font-weight:100;color:#c9a44a;letter-spacing:0.12em;margin-bottom:4px;}}
.sub{{font-size:0.85em;color:#888;margin-bottom:24px;}}
.tagline{{font-size:1em;color:#aaa;line-height:1.8;margin:16px 0;}}
h2{{font-size:1em;font-weight:200;color:#c9a44a;letter-spacing:0.08em;margin:24px 0 12px;}}
.features{{list-style:none;}}
.features li{{padding:6px 0;font-size:0.85em;color:#999;line-height:1.6;}}
.features li::before{{content:'→ ';color:#c9a44a;}}
.killer{{background:#111118;border-left:3px solid #c9a44a;padding:14px 18px;border-radius:0 8px 8px 0;
  font-size:0.9em;color:#c9a44a;margin:20px 0;line-height:1.6;}}
.price-box{{background:#0d1a0d;border:1px solid #4a920;border-radius:12px;padding:20px;text-align:center;margin:24px 0;}}
.price{{font-size:2em;font-weight:100;color:#4a9;}}
.replaces{{font-size:0.75em;color:#666;margin-top:6px;}}

/* Demo area */
.demo-box{{background:#0a0a12;border:1px solid #ffffff08;border-radius:12px;padding:20px;margin:24px 0;}}
.demo-header{{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;}}
.demo-title{{color:#c9a44a;font-size:0.85em;letter-spacing:0.08em;}}
.demo-remaining{{font-size:0.7em;color:#555;}}
.demo-sample{{font-size:0.75em;color:#666;margin-bottom:12px;font-style:italic;}}
#demo-output{{min-height:200px;font-family:'Courier New',monospace;font-size:0.75em;color:#888;
  line-height:1.8;white-space:pre-wrap;}}
.demo-btn{{background:#c9a44a15;border:1px solid #c9a44a30;color:#c9a44a;padding:10px 24px;
  border-radius:24px;cursor:pointer;font-family:Georgia,serif;font-size:0.9em;transition:all 0.3s;}}
.demo-btn:hover{{background:#c9a44a25;border-color:#c9a44a60;}}
.demo-btn:disabled{{opacity:0.3;cursor:not-allowed;}}
.locked{{text-align:center;padding:30px;color:#555;font-size:0.85em;}}
.locked a{{color:#c9a44a;}}

.cta{{display:block;text-align:center;background:#c9a44a;color:#08080d;padding:14px 32px;
  border-radius:28px;text-decoration:none;font-size:1em;margin:30px auto;max-width:300px;
  transition:all 0.3s;font-weight:bold;}}
.cta:hover{{background:#f4d990;}}
.back{{text-align:center;margin-top:20px;}}
.back a{{color:#555;font-size:0.8em;}}
</style>
</head>
<body>
<div class="page">
  <h1>{p['title']}</h1>
  <div class="sub">{p['subtitle']}</div>
  <p class="tagline">{p['tagline']}</p>

  <h2>WHAT IT DOES</h2>
  <ul class="features">{features_html}</ul>

  <div class="killer">{p['killer']}</div>

  <h2>TRY IT</h2>
  <div class="demo-box">
    <div class="demo-header">
      <span class="demo-title">LIVE DEMO</span>
      <span class="demo-remaining" id="remaining"></span>
    </div>
    <div class="demo-sample">{p['sample_description']}</div>
    <div id="demo-content">
      <button class="demo-btn" id="run-demo" onclick="runDemo()">Run Analysis</button>
      <div id="demo-output"></div>
    </div>
    <div id="demo-locked" class="locked" style="display:none;">
      You've used your {p['demo_limit']} free analyses.<br><br>
      You've seen what it does. Now imagine it on YOUR data.<br><br>
      <a href="#buy">{p['price']}/mo →</a>
    </div>
  </div>

  <div class="price-box">
    <div class="price">{p['price']}<span style="font-size:0.4em;color:#888;">/mo</span></div>
    <div class="replaces">Replaces: {p['replaces']}</div>
  </div>

  <a class="cta" href="#buy">Get {p['title']}</a>
  <div class="back"><a href="/">← back to GUMP</a></div>
</div>

<script>
{_fingerprint_js()}

var PRODUCT = '{product_key}';
var MAX_TRIES = {p['demo_limit']};

function checkTrial() {{
  var t = _gumpTrialCheck(PRODUCT, MAX_TRIES);
  document.getElementById('remaining').textContent = t.remaining + ' of ' + MAX_TRIES + ' free analyses remaining';
  if (t.remaining <= 0) {{
    document.getElementById('demo-content').style.display = 'none';
    document.getElementById('demo-locked').style.display = 'block';
  }}
  return t;
}}

function runDemo() {{
  var t = checkTrial();
  if (t.remaining <= 0) return;
  _gumpTrialUse(PRODUCT);

  var btn = document.getElementById('run-demo');
  btn.disabled = true;
  btn.textContent = 'Computing...';

  setTimeout(function() {{
    var output = document.getElementById('demo-output');
    output.innerHTML = getDemoOutput(t.count + 1);
    btn.textContent = 'Run Again';
    btn.disabled = false;
    checkTrial();
  }}, 800 + Math.random() * 400);
}}

function getDemoOutput(run) {{
  // Each run shows slightly different aspects of the same sample data
  var outputs = DEMO_OUTPUTS[PRODUCT] || ['Demo output not configured.'];
  var idx = Math.min(run - 1, outputs.length - 1);
  return outputs[idx];
}}

var DEMO_OUTPUTS = {{
  'orgxray': [
    '<span style="color:#c9a44a;">HEALTH SCORE: 73/100</span>\\n\\n' +
    'Nodes: 20  |  Edges: 21  |  Clusters: 6\\n' +
    'Avg degree: 2.1  |  Hubs: 0  |  Isolates: 7\\n\\n' +
    '<span style="color:#c44;">⚠ 7 ISOLATES DETECTED:</span>\\n' +
    '  Dev5, Data2, Sales1, Sales3, Ops1, Ops2, Intern\\n' +
    '  These people have only 1 connection. At risk of disengagement.\\n\\n' +
    '<span style="color:#c9a44a;">TOP TENSIONS (missing connections):</span>\\n' +
    '  CEO ↔ Lead_BE    tension: 2.2  (should be collaborating)\\n' +
    '  CTO ↔ VP_Sales   tension: 2.2  (engineering-sales silo)\\n' +
    '  VP_Ops ↔ CTO     tension: 2.1  (operations-engineering gap)\\n\\n' +
    '<span style="color:#4a9;">ACTION PLAN:</span>\\n' +
    '  [HIGH] Integrate Dev5, Data2, Sales1 into the network\\n' +
    '  [MED]  Connect CEO with Lead_BE — they should be collaborating\\n' +
    '  [MED]  Connect CTO with VP_Sales — close the eng-sales silo',

    '<span style="color:#c9a44a;">CLUSTER ANALYSIS:</span>\\n\\n' +
    'Cluster 1: CEO, CTO, VP_Sales, VP_Ops  (leadership)\\n' +
    'Cluster 2: Lead_FE, Dev1, Dev2          (frontend)\\n' +
    'Cluster 3: Lead_BE, Dev3, Dev4          (backend)\\n' +
    'Cluster 4: Lead_Data, Data1             (data)\\n' +
    'Cluster 5: Sales2, Sales3               (sales)\\n' +
    'Cluster 6: Ops1, Ops2                   (operations)\\n\\n' +
    '<span style="color:#c44;">SILO ALERT:</span> Engineering (clusters 2-4) and Sales (cluster 5)\\n' +
    'have only 1 cross-department connection (Sales2 ↔ Dev4).\\n' +
    'Recommendation: weekly eng-sales sync or shared Slack channel.\\n\\n' +
    '<span style="color:#c9a44a;">BRIDGES (people connecting different groups):</span>\\n' +
    '  Sales2 — only person connecting sales to engineering\\n' +
    '  CEO — connects leadership to all departments\\n' +
    '  ⚠ If Sales2 leaves, the eng-sales connection breaks entirely.',

    '<span style="color:#c9a44a;">SPECTRAL LAYOUT:</span>\\n\\n' +
    '[Interactive graph would render here in full version]\\n\\n' +
    'The spectral layout places nodes by their REAL relationships,\\n' +
    'not their org chart position. In this company:\\n\\n' +
    '• Leadership cluster is tightly coupled (good)\\n' +
    '• Frontend and Backend are close but distinct (natural)\\n' +
    '• Sales is FAR from Engineering (problem)\\n' +
    '• Operations is isolated (problem)\\n' +
    '• 7 people are on the periphery with minimal connections\\n\\n' +
    '<span style="color:#4a9;">With your license:</span>\\n' +
    '  → Upload YOUR org data (CSV, Slack export, GitHub)\\n' +
    '  → Interactive spectral graph with hover/click\\n' +
    '  → Exportable HTML report you can share\\n' +
    '  → Unlimited analyses. Your data never leaves your machine.',
  ],
  'learnengine': [
    '<span style="color:#c9a44a;">LEARNING STATUS</span>\\n\\n' +
    'Subject: Web Development (10 topics)\\n' +
    'Mastered: 2/10 (HTML ★, CSS ★)\\n' +
    'Struggling: 1 (JavaScript — 43%, 7 attempts)\\n' +
    'Completion: 20%\\n\\n' +
    '<span style="color:#4a9;">STUDY NEXT:</span>\\n' +
    '  → JavaScript (prerequisite for DOM, which blocks React)\\n' +
    '  → SQL (no prerequisites, ready to start)\\n\\n' +
    '<span style="color:#c44;">KNOWLEDGE GAPS:</span>\\n' +
    '  ✗ JavaScript — 43% (7 attempts) — blocks: node, react\\n' +
    '  ✗ DOM — 0% (2 attempts) — blocks: react\\n\\n' +
    'The engine detected you\'re struggling with JavaScript\\n' +
    'and recommended going back to its prerequisites first.\\n' +
    'This is grokking-aware: it won\'t push you forward until\\n' +
    'you actually UNDERSTAND, not just score well on a quiz.',

    '<span style="color:#c9a44a;">GROKKING DETECTION</span>\\n\\n' +
    'HTML:  ★ MASTERED (8 correct streak, 100% accuracy)\\n' +
    'CSS:   ★ MASTERED (7 correct streak, 100% accuracy)\\n' +
    'JS:    ◐ LEARNING (best streak: 3, accuracy: 43%)\\n' +
    'DOM:   ◌ STRUGGLING (0% after 2 attempts)\\n' +
    'React: ◌ UNSEEN\\n' +
    'Node:  ◌ UNSEEN\\n' +
    'SQL:   ◌ UNSEEN\\n\\n' +
    'Grokking = the exact moment a topic clicks.\\n' +
    'Not quiz score. Not completion percentage.\\n' +
    'Sustained correct streak + high accuracy = understanding.\\n' +
    'The engine saw you get 3 JS questions right, then miss 4.\\n' +
    'That\'s NOT grokking. That\'s pattern matching. Different thing.',

    '<span style="color:#c9a44a;">CURRICULUM ORDER (spectral analysis):</span>\\n\\n' +
    '1. html        (root — no prerequisites)\\n' +
    '2. css         (needs: html)\\n' +
    '3. javascript  (root — no prerequisites)\\n' +
    '4. sql         (root — no prerequisites)\\n' +
    '5. dom         (needs: html, javascript)\\n' +
    '6. node        (needs: javascript)\\n' +
    '7. react       (needs: css, javascript, dom)\\n' +
    '8. api         (needs: node, sql)\\n' +
    '9. auth        (needs: api)\\n' +
    '10. deploy     (needs: react, api)\\n\\n' +
    'This order was computed by spectral distance from root concepts.\\n' +
    'Same math that places transistors on a chip.\\n\\n' +
    '<span style="color:#4a9;">With your license:</span>\\n' +
    '  → Define YOUR curriculum with any topics\\n' +
    '  → Track unlimited students\\n' +
    '  → Interactive knowledge graph dashboard\\n' +
    '  → Export learning reports',
  ],
  'foldwatch': [
    '<span style="color:#c9a44a;">AMYLOID-β 42 ANALYSIS</span>\\n' +
    'DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA\\n\\n' +
    '<span style="color:#c44;">MISFOLDING RISK: MEDIUM</span>\\n\\n' +
    'Length: 42 residues\\n' +
    'Helix: 31%  |  Sheet: 36%  |  Coil: 33%\\n' +
    'Domains: 3  |  Net charge: -3  |  Interactions: 287\\n\\n' +
    '<span style="color:#c44;">AGGREGATION REGIONS:</span>\\n' +
    '  Residues 17-21: LVFFA — aggregation score: 0.72\\n' +
    '    This is the KLVFF region, the known amyloid core.\\n' +
    '  Residues 31-41: IIGLMVGGVVIA — aggregation score: 0.63\\n' +
    '    C-terminal hydrophobic tail.\\n\\n' +
    'Risk factors:\\n' +
    '  ⚠ 2 aggregation-prone regions\\n' +
    '  ⚠ High long-range hydrophobic tensions',

    '<span style="color:#c9a44a;">FOLD TENSIONS (spectral analysis):</span>\\n\\n' +
    'Residues that WANT to be close but aren\'t in sequence:\\n\\n' +
    '  F19 ↔ I31  hydrophobic tension (12 residues apart)\\n' +
    '  V18 ↔ G33  hydrophobic tension (15 residues apart)\\n' +
    '  F20 ↔ M35  hydrophobic tension (15 residues apart)\\n' +
    '  L17 ↔ V36  hydrophobic tension (19 residues apart)\\n\\n' +
    'These long-range hydrophobic tensions predict the\\n' +
    'folding contacts that drive aggregation. The KLVFF\\n' +
    'region (17-21) has tension with the C-terminal tail\\n' +
    '(31-41) — exactly what drives amyloid fibril formation.\\n\\n' +
    'Same math that finds missing org connections finds\\n' +
    'missing protein contacts. Laplacian eigenvectors\\n' +
    'don\'t care if the nodes are people or amino acids.',

    '<span style="color:#c9a44a;">STRUCTURAL COMPARISON:</span>\\n\\n' +
    'Wild type Amyloid-β 42 vs known protective mutations:\\n\\n' +
    '  A2T (Icelandic protective): reduces aggregation score by 15%\\n' +
    '  A2V (pathogenic): increases aggregation score by 8%\\n\\n' +
    'A single amino acid change at position 2 shifts the\\n' +
    'aggregation propensity profile. The tool detects this\\n' +
    'because the spectral graph changes — the coupling\\n' +
    'between the N-terminal and the KLVFF core weakens\\n' +
    'with the protective mutation.\\n\\n' +
    '<span style="color:#4a9;">With your license:</span>\\n' +
    '  → Paste ANY sequence\\n' +
    '  → Compare wild type vs mutant side-by-side\\n' +
    '  → Interactive spectral fold map\\n' +
    '  → Exportable HTML reports for publications',
  ],
  'chipfast': [
    '<span style="color:#c9a44a;">500-GATE BENCHMARK</span>\\n\\n' +
    'Gates: 500  |  Wires: 1,247\\n' +
    'Wire length: 4,821 (spectral)\\n' +
    'Random baseline: 8,340\\n' +
    '<span style="color:#4a9;">Reduction: 42.2%</span>\\n\\n' +
    'Hot spots: 3  |  Computation time: 0.31s\\n\\n' +
    'Missing connections detected: 5\\n' +
    '  g42 ↔ g187  tension: 8.3\\n' +
    '  g15 ↔ g201  tension: 7.9\\n' +
    '  g88 ↔ g156  tension: 7.4\\n\\n' +
    'These gates are spectrally close (should be connected)\\n' +
    'but have no wire between them. In a real circuit, this\\n' +
    'suggests a missing feedback path or optimization opportunity.',

    '<span style="color:#c9a44a;">PLACEMENT DETAILS:</span>\\n\\n' +
    'Rows: 23  |  Gate width: 2.0  |  Row height: 1.8\\n' +
    'Chip dimensions: 67.0 × 41.4\\n' +
    'Density: 87.3%\\n\\n' +
    'Legalization: all gates snapped to rows, no overlaps\\n' +
    'Routing: Manhattan estimation, 3 congestion hot spots\\n\\n' +
    'The spectral placement algorithm uses Laplacian\\n' +
    'eigenvectors — the same math that finds the circle\\n' +
    'of fifths from consonance data. Connected gates\\n' +
    'attract each other. The eigenvectors find equilibrium.\\n' +
    'That\'s the layout.\\n\\n' +
    'Cadence charges $750K/yr for this. We do it in 0.3s on a laptop.',

    '<span style="color:#c9a44a;">SCALING BENCHMARK:</span>\\n\\n' +
    '    100 gates:   0.02s   (wire reduction: 38%)\\n' +
    '    500 gates:   0.31s   (wire reduction: 42%)\\n' +
    '  1,000 gates:   0.84s   (wire reduction: 45%)\\n' +
    ' 10,000 gates:   3.2s    (wire reduction: 51%)\\n' +
    ' 40,000,000:     4.5s    (Metal GPU pipeline)\\n\\n' +
    'The Metal GPU path (included with license) uses\\n' +
    'sparse matrix multiplication on Apple Silicon.\\n' +
    'Double-buffered CPU/GPU pipeline eliminates stalls.\\n\\n' +
    '<span style="color:#4a9;">With your license:</span>\\n' +
    '  → Paste YOUR netlist\\n' +
    '  → Interactive layout with zoom/pan\\n' +
    '  → Export placement for downstream tools\\n' +
    '  → Metal GPU acceleration for 40M+ gates',
  ],
  'aitrainer': [
    '<span style="color:#c9a44a;">TRAINING MONITOR — grok_test</span>\\n\\n' +
    'Phase: <span style="color:#4a9;">GENERALIZED</span>\\n\\n' +
    'Epoch: 130  |  Train: 97%  |  Test: 89%\\n' +
    'Memorized at epoch 12\\n' +
    '<span style="color:#4a9;">★ GROKKED at epoch 108</span> (jump: 0.42)\\n\\n' +
    'Energy: 3.74e-16 J total  |  1.12e-18 J/correct\\n' +
    'Estimated savings: 67% of planned compute\\n\\n' +
    'Without this tool, you would have trained for 400\\n' +
    'epochs. The model understood at epoch 108.\\n' +
    '292 wasted epochs × your GPU cost = money burned.',

    '<span style="color:#c9a44a;">DETECTION SIGNALS:</span>\\n\\n' +
    'Signal A: Test accuracy jump     ✓ (+0.42 in 20 epochs)\\n' +
    'Signal B: Energy/correct drop    ✓ (72% decrease)\\n' +
    'Signal C: Weight norm stabilized ✗ (not provided)\\n' +
    'Signal D: Train-test gap closed  ✓ (0.85 → 0.08)\\n\\n' +
    '3 of 4 signals confirmed. Grokking is real.\\n\\n' +
    'The transition from memorization to understanding\\n' +
    'is a phase transition — same physics as ice melting.\\n' +
    'Before: weights spread across all frequencies (noise).\\n' +
    'After: weights concentrate on structure (signal).\\n' +
    'Understanding is 224,000× cheaper than memorization.\\n' +
    'That\'s not a metaphor. That\'s Landauer accounting.',

    '<span style="color:#c9a44a;">RECOMMENDATION:</span>\\n\\n' +
    '<span style="color:#4a9;">STOP — model has grokked.</span>\\n\\n' +
    'Test accuracy jumped at epoch 108. Understanding achieved.\\n' +
    'Savings: 67% of planned compute.\\n' +
    'Next: save checkpoint and deploy.\\n\\n' +
    'If your model had been stuck instead:\\n' +
    '  → Increase weight decay (try 10× current)\\n' +
    '  → Reduce model size\\n' +
    '  → Add more training data\\n' +
    '  → Try AdamW → SGD with warmup\\n\\n' +
    '<span style="color:#4a9;">With your license:</span>\\n' +
    '  → Monitor YOUR training runs in real-time\\n' +
    '  → Multiple models tracked simultaneously\\n' +
    '  → Energy cost dashboard\\n' +
    '  → Automatic stop recommendations',
  ],
  'knowledge': [
    '<span style="color:#c9a44a;">KNOWLEDGE EXTRACTED (5 passages, neuroscience)</span>\\n\\n' +
    'Concepts: 47  |  Connections: 183  |  Clusters: 4\\n\\n' +
    'Top concepts:\\n' +
    '  neurons (12 uses, 8 connections)\\n' +
    '  brain (9 uses, 11 connections)\\n' +
    '  synapses (7 uses, 6 connections)\\n' +
    '  memory (6 uses, 7 connections)\\n' +
    '  hippocampus (4 uses, 5 connections)\\n\\n' +
    'Clusters:\\n' +
    '  1. Neural signaling: neurons, synapses, axons, dendrites\\n' +
    '  2. Memory: hippocampus, memory, learning, consolidation\\n' +
    '  3. Chemistry: neurotransmitters, dopamine, serotonin\\n' +
    '  4. Structure: cortex, cerebellum, brain stem',

    '<span style="color:#c9a44a;">RECALL: "how does memory work?"</span>\\n\\n' +
    'Top related concepts:\\n' +
    '  memory (relevance: 12.5)\\n' +
    '  hippocampus (relevance: 8.3)\\n' +
    '  learning (relevance: 6.1)\\n' +
    '  synapses (relevance: 5.8)\\n' +
    '  consolidation (relevance: 4.2)\\n\\n' +
    'Context: "Memory is stored in the hippocampus.\\n' +
    'Learning changes neural connections through a\\n' +
    'process called long-term potentiation."\\n\\n' +
    'The recall works by spreading activation from\\n' +
    'query words through the concept graph. Connected\\n' +
    'concepts light up proportional to edge weight.\\n' +
    'Same physics as coupled oscillators resonating.',

    '<span style="color:#c9a44a;">KNOWLEDGE GAPS (tensions):</span>\\n\\n' +
    '  "dopamine" ↔ "memory"\\n' +
    '    Structurally related but never appear together.\\n' +
    '    Suggestion: dopamine plays a role in memory\\n' +
    '    consolidation — your texts don\'t mention this.\\n\\n' +
    '  "cortex" ↔ "learning"\\n' +
    '    The cortex is where long-term memories live,\\n' +
    '    but your sources only discuss hippocampus.\\n\\n' +
    'These gaps are found by the same tension detection\\n' +
    'that finds missing connections in organizations\\n' +
    'and missing contacts in protein folding.\\n\\n' +
    '<span style="color:#4a9;">With your license:</span>\\n' +
    '  → Feed it YOUR documents (research papers, notes, books)\\n' +
    '  → Interactive knowledge graph with search\\n' +
    '  → Find gaps in your own understanding\\n' +
    '  → All local. No data sent anywhere.',
  ],
  'sensor': [
    '<span style="color:#c9a44a;">SIGNAL ANALYSIS — Heart Rate Variability</span>\\n\\n' +
    'Samples: 500  |  Regime: <span style="color:#4a9;">COHERENT</span>\\n\\n' +
    'K (coupling):  1.82    — strong rhythmic coupling\\n' +
    'R (order):     0.67    — above 1/φ threshold (0.618)\\n' +
    'E (energy):    1.44e-18 J  — information cost\\n' +
    'T (tension):   0.034   — low volatility\\n\\n' +
    'Trend: stable  |  Entropy: 3.42  |  Anomalies: 1\\n\\n' +
    '<span style="color:#c44;">ANOMALY at sample 347:</span> z-score 4.2\\n' +
    'Single spike — possible premature ventricular contraction.\\n\\n' +
    'Interpretation: System is phase-locked and healthy.\\n' +
    'One anomalous beat detected. Overall regime: coherent.',

    '<span style="color:#c9a44a;">REGIME ANALYSIS:</span>\\n\\n' +
    'R history (order parameter over time):\\n' +
    '  Window 1-20:   R = 0.71  (coherent)\\n' +
    '  Window 20-40:  R = 0.65  (coherent)\\n' +
    '  Window 40-60:  R = 0.58  (transitional!)\\n' +
    '  Window 60-80:  R = 0.69  (coherent)\\n' +
    '  Window 80-100: R = 0.72  (coherent)\\n\\n' +
    'Window 40-60 dipped below 1/φ (0.618) — brief\\n' +
    'loss of coherence. Coincides with the anomaly at\\n' +
    'sample 347. The system recovered within 20 samples.\\n\\n' +
    'This is the same R that measures:\\n' +
    '  • Brain coherence in EEG\\n' +
    '  • Flock synchronization in starlings\\n' +
    '  • Market stability before a crash\\n' +
    'One equation. Different data. Same physics.',

    '<span style="color:#c9a44a;">DIAGNOSIS:</span>\\n\\n' +
    '• Strong coupling (K=1.82) — elements tightly connected\\n' +
    '• High coherence (R=0.67 > 1/φ) — system is phase-locked\\n' +
    '• Low tension (T=0.034) — gradual changes, stability\\n' +
    '• Regime: coherent — healthy operating range\\n\\n' +
    'Recommendation: System is healthy. Monitor for regime changes.\\n\\n' +
    '<span style="color:#4a9;">With your license:</span>\\n' +
    '  → Feed ANY time series (financial, medical, industrial)\\n' +
    '  → Real-time monitoring with regime alerts\\n' +
    '  → Interactive dashboard with R history\\n' +
    '  → Works offline. No per-host billing.\\n' +
    '  → Flat rate regardless of data volume.',
  ],
}};

checkTrial();
</script>
</body>
</html>'''


def generate_demo(product_key):
    """Generate a single toybox demo page."""
    if product_key not in DEMO_DATA:
        return f'<html><body>Unknown product: {product_key}</body></html>'
    return _demo_page_template(product_key)


def generate_all_demos(output_dir):
    """Generate all 7 toybox demo pages."""
    os.makedirs(output_dir, exist_ok=True)
    for key in DEMO_DATA:
        html = generate_demo(key)
        path = os.path.join(output_dir, f'try-{key}.html')
        with open(path, 'w') as f:
            f.write(html)
    return list(DEMO_DATA.keys())
