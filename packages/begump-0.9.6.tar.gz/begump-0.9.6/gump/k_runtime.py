"""
K RUNTIME — The secured computation layer.
============================================
All products route through here. K core is tried first (protected,
license-gated). Falls back to gump.core if K core unavailable.

    from gump.k_runtime import tensions, place, energy, grok_detect, measure, interval_cost

Same API as gump.core. Same results. But gated through coupling license
and compiled to binary for IP protection.
"""

# Try K core (compiled binary) first
try:
    from gump.k_core import (
        k_tensions as _k_tensions,
        k_place as _k_place,
        k_energy as _k_energy,
        k_grok_detect as _k_grok_detect,
        k_measure as _k_measure,
        k_interval as _k_interval,
    )
    _USE_K_CORE = True
except ImportError:
    _USE_K_CORE = False

# Fallback to gump.core (unprotected, for dev/testing)
from gump.core import (
    _TensionDetector,
    place as _core_place,
    EnergyTracker as _CoreEnergyTracker,
    interval_cost as _core_interval_cost,
    PHI, K_CEILING, LANDAUER_PER_BIT,
)


def tensions(n, edges, weights=None, n_vecs=6, top_k=20):
    """Find tensions. Routes through K core if available."""
    if _USE_K_CORE:
        return _k_tensions(n, edges, weights, n_vecs, top_k)
    # Fallback
    td = _TensionDetector(n, edges, weights, n_vecs)
    return td.tensions(top_k)


def place(n, edges, width=100, height=100, weights=None):
    """Spectral placement. Routes through K core if available."""
    if _USE_K_CORE:
        return _k_place(n, edges, width, height, weights)
    return _core_place(n, edges, width, height, weights)


def energy(n_bits, operation='erase'):
    """Landauer energy cost."""
    if _USE_K_CORE:
        return _k_energy(n_bits, operation)
    if operation == 'reverse':
        return 0.0
    return n_bits * LANDAUER_PER_BIT


def grok_detect(train_accs, test_accs, window=20):
    """Detect grokking."""
    if _USE_K_CORE:
        return _k_grok_detect(train_accs, test_accs, window)
    # Fallback: simple detection
    import numpy as np
    n = len(test_accs)
    if n < 2 * window:
        return False, -1, 0.0
    for epoch in range(window, n - window):
        recent = np.mean(test_accs[epoch:epoch + window])
        prev = np.mean(test_accs[epoch - window:epoch])
        if recent - prev > 0.15 and np.mean(train_accs[max(0, epoch-window):epoch]) > 0.85:
            return True, epoch, float(recent - prev)
    return False, -1, 0.0


def measure(time_series):
    """Measure K/R/T of any time series."""
    if _USE_K_CORE:
        return _k_measure(time_series)
    # Fallback
    import numpy as np
    arr = np.array(time_series, dtype=float)
    n = len(arr)
    if n < 4:
        return {'K': 0, 'R': 0, 'T': 0}
    mean = np.mean(arr)
    var = np.var(arr)
    K = float(np.clip(np.sum((arr[:-1]-mean)*(arr[1:]-mean))/((n-1)*var) * 2, 0, 3)) if var > 0 else 0
    T = float(np.std(np.diff(arr)))
    return {'K': round(K, 4), 'R': 0.5, 'T': round(T, 4)}


def interval_cost(p, q):
    """Landauer cost of interval p:q in nats."""
    if _USE_K_CORE:
        return _k_interval(p, q)
    return _core_interval_cost(p, q)


def is_protected():
    """Check if running through K core (protected) or fallback."""
    return _USE_K_CORE
