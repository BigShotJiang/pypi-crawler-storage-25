"""
python3 -m gump "anything"

Give it a protein sequence, a list of numbers, or some text.
Get back: what it is, what it means, what to do next.

Examples:
    python3 -m gump "MVLSPADKTNVKAAWGKVGAHAGEYGAEALERMFLSFPTTKTYFPHFDLSH"
    python3 -m gump "1.2 3.4 2.1 5.6 1.1 3.3 2.0 5.5"
    python3 -m gump "The coupling between oscillators produces emergent behavior"
    python3 -m gump kill "sqrt(2/pi)" 0.79788456
    echo "1 2 3 4 5" | python3 -m gump

Grand Unified Music Project
"""
import sys


def main():
    args = sys.argv[1:]

    # Version
    if args and args[0] in ('-v', '--version', 'version'):
        from gump import __version__
        print(f'begump {__version__}')
        sys.exit(0)

    # Help
    if args and args[0] in ('-h', '--help', 'help'):
        print("Usage: python3 -m gump <data>")
        print()
        print("  Protein:  python3 -m gump MVLSPADKTNVKAAWG...")
        print("  Signal:   python3 -m gump 1.2 3.4 2.1 5.6")
        print("  Text:     python3 -m gump 'any sentence'")
        print("  Kill:     python3 -m gump kill 'sqrt(2/pi)' 0.79788456")
        print("  Verify:   python3 -m gump verify")
        print("  Pipe:     echo '1 2 3' | python3 -m gump")
        print()
        print("pip install begump  |  begump.com  |  everything free")
        sys.exit(0)

    # Subcommand: kill
    if args and args[0] == 'kill':
        from gump.kill import _cli
        sys.argv = ['gump.kill'] + args[1:]
        _cli()
        return

    # Subcommand: verify
    if args and args[0] == 'verify':
        from gump.verify import verify
        success = verify()
        sys.exit(0 if success else 1)

    # Get input from args or stdin
    if args:
        raw = ' '.join(args)
    else:
        # No args — check if piped input
        try:
            is_tty = sys.stdin.isatty()
        except Exception:
            is_tty = True
        if not is_tty:
            raw = sys.stdin.read().strip()
        else:
            print("Usage: python3 -m gump <data>")
            print()
            print("  Protein:  python3 -m gump MVLSPADKTNVKAAWG...")
            print("  Signal:   python3 -m gump 1.2 3.4 2.1 5.6")
            print("  Text:     python3 -m gump 'any sentence'")
            print("  Kill:     python3 -m gump kill 'sqrt(2/pi)' 0.79788456")
            print("  Pipe:     echo '1 2 3' | python3 -m gump")
            print()
            print("pip install begump  |  begump.com  |  everything free")
            sys.exit(0)

    # Try to parse as numbers first
    data = raw
    parts = raw.replace(',', ' ').split()
    try:
        nums = [float(p) for p in parts]
        if len(nums) > 1:
            data = nums
    except ValueError:
        pass

    from gump import ask
    result = ask(data)

    # Print results
    print()
    print(result['the_point'])
    print()
    print(result['the_next'])
    print()


if __name__ == '__main__':
    main()
