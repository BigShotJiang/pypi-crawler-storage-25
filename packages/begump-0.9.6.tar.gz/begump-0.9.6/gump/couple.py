"""
couple -- 4-axis coupling profile between two signals.
======================================================

    from gump.couple import profile, quick

    result = profile(signal_a, signal_b, fs=256)
    print(result['diagnosis'])
    print(result['K_overall'])

    # One-liner
    print(quick(signal_a, signal_b))

Four axes of coupling:

    K_filter     Cross-frequency coupling (PAC). Does the slow rhythm of A
                 gate the fast rhythm of B? High = hierarchical control.
                 Low = independent frequency layers.

    K_bind       Temporal binding. Does the coupling stay consistent across
                 time windows, or does it flicker? High = stable partnership.
                 Low = intermittent (ADHD-like).

    K_hierarchy  Spectral slope ratio. How similarly do A and B rank their
                 frequencies? Matching slopes = same internal hierarchy.
                 Mismatched slopes = different organizing principles.

    K_direction  Who drives whom? Transfer entropy A->B vs B->A.
                 Positive = A leads. Negative = B leads. Zero = mutual.

Plus:
    K_overall    Single coupling score (0-1).
    diagnosis    Plain English: what these two signals are doing together.
    profile_type One of: COUPLED, ENTRAINED, FORCED, FLICKERING, INDEPENDENT.
    comparison   How this profile compares to known coupling archetypes.

Foundation: coupling_hierarchy.py (PAC, temporal binding, spectral slope)
           + discriminator.py (transfer entropy for directionality)

This is NOT correlation. Correlation is free. Coupling costs energy.
The shuffle test (inherited from discriminator) proves which is which.
"""

import numpy as np
from scipy import signal as sig

# ═══════════════════════════════════════════════════════════
# PUBLIC API
# ═══════════════════════════════════════════════════════════


def profile(a, b, fs=1.0, n_shuffles=200, seed=137):
    """Compute the 4-axis coupling profile between two signals.

    Args:
        a, b:        array-like signals (any length; trimmed to min)
        fs:          sample rate in Hz (default 1.0 for unitless)
        n_shuffles:  shuffles for null distribution (coupling vs correlation)
        seed:        random seed for reproducibility

    Returns:
        dict with K_filter, K_bind, K_hierarchy, K_direction,
        K_overall, diagnosis, profile_type, comparison, and raw data.
    """
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    n = min(len(a), len(b))
    a, b = a[:n], b[:n]

    # ─── Edge cases ───
    if n < 4:
        return _empty(n, reason="Too few samples (need >= 4).")

    # Constant signals
    if np.std(a) < 1e-15 or np.std(b) < 1e-15:
        return _empty(n, reason="One or both signals are constant.")

    # ─── Axis 1: K_filter (cross-frequency coupling) ───
    k_filter, k_filter_p = _compute_k_filter(a, b, fs, n_shuffles, seed)

    # ─── Axis 2: K_bind (temporal binding) ───
    k_bind = _compute_k_bind(a, b, fs)

    # ─── Axis 3: K_hierarchy (spectral slope similarity) ───
    k_hierarchy, slope_a, slope_b = _compute_k_hierarchy(a, b, fs)

    # ─── Axis 4: K_direction (who drives whom) ───
    k_direction, te_ab, te_ba, dir_label = _compute_k_direction(
        a, b, n_shuffles, seed
    )

    # ─── Overall coupling score ───
    # Weighted combination: filter and bind matter most,
    # hierarchy and direction are modifiers.
    k_overall = _overall(k_filter, k_bind, k_hierarchy, k_direction)

    # ─── Profile type ───
    profile_type = _classify(k_filter, k_bind, k_hierarchy,
                             k_direction, k_filter_p)

    # ─── Diagnosis ───
    diagnosis = _diagnose(k_filter, k_bind, k_hierarchy,
                          k_direction, dir_label, profile_type, n)

    # ─── Comparison to archetypes ───
    comparison = _compare(k_filter, k_bind, k_hierarchy, k_direction)

    return {
        # The four axes
        'K_filter':     round(float(k_filter), 4),
        'K_bind':       round(float(k_bind), 4),
        'K_hierarchy':  round(float(k_hierarchy), 4),
        'K_direction':  round(float(k_direction), 4),
        # Summary
        'K_overall':    round(float(k_overall), 4),
        'profile_type': profile_type,
        'diagnosis':    diagnosis,
        'comparison':   comparison,
        # Raw data for experts
        'direction_label': dir_label,
        'slope_a':      round(float(slope_a), 4),
        'slope_b':      round(float(slope_b), 4),
        'TE_AB':        round(float(te_ab), 4),
        'TE_BA':        round(float(te_ba), 4),
        'filter_p':     round(float(k_filter_p), 4),
        'n':            n,
        'fs':           fs,
    }


def quick(a, b, fs=1.0):
    """One-line coupling verdict."""
    r = profile(a, b, fs=fs)
    return (f"{r['profile_type']} "
            f"(filter={r['K_filter']:.3f}, bind={r['K_bind']:.3f}, "
            f"hier={r['K_hierarchy']:.3f}, dir={r['K_direction']:+.3f}) "
            f"K={r['K_overall']:.3f}")


# ═══════════════════════════════════════════════════════════
# AXIS 1: K_FILTER — Cross-Frequency Coupling (PAC)
# ═══════════════════════════════════════════════════════════
# Does the phase of A's slow oscillation modulate the
# amplitude of B's fast oscillation? This is the hierarchical
# control channel — the slow rhythm gates the fast one.


def _compute_k_filter(a, b, fs, n_shuffles, seed):
    """Phase-amplitude coupling: theta phase of A vs gamma amplitude of B.

    For low sample rates (fs < 8), falls back to cross-correlation
    envelope coupling since bandpass won't work.
    """
    nyq = fs / 2.0

    # Need at least theta band (4-8 Hz) resolvable
    # and gamma band (30+ Hz) resolvable
    if nyq <= 8 or len(a) < int(fs * 2):
        # Low sample rate: use envelope coupling instead
        return _envelope_coupling(a, b, n_shuffles, seed)

    # Theta phase from signal A
    low_band = (max(1, 4), min(8, nyq - 1))
    high_band = (max(13, low_band[1] + 1), min(80, nyq - 1))

    if high_band[0] >= high_band[1] or low_band[0] >= low_band[1]:
        return _envelope_coupling(a, b, n_shuffles, seed)

    try:
        b_lo, a_lo = sig.butter(
            3, [low_band[0] / nyq, low_band[1] / nyq], btype='band'
        )
        phase_a = np.angle(sig.hilbert(sig.filtfilt(b_lo, a_lo, a)))

        b_hi, a_hi = sig.butter(
            3, [high_band[0] / nyq, high_band[1] / nyq], btype='band'
        )
        amp_b = np.abs(sig.hilbert(sig.filtfilt(b_hi, a_hi, b)))
    except (ValueError, np.linalg.LinAlgError):
        return _envelope_coupling(a, b, n_shuffles, seed)

    # Modulation index (Tort et al. 2010)
    mi = _modulation_index(phase_a, amp_b)

    # Null distribution: shuffle phase
    rng = np.random.RandomState(seed)
    mi_null = np.empty(n_shuffles)
    for i in range(n_shuffles):
        shift = rng.randint(len(phase_a) // 4, 3 * len(phase_a) // 4)
        phase_shuf = np.roll(phase_a, shift)
        mi_null[i] = _modulation_index(phase_shuf, amp_b)

    p_value = float(np.mean(mi_null >= mi))
    mi_excess = max(0, mi - np.mean(mi_null))

    # Normalize to [0, 1] — typical MI range is 0 to ~0.3
    k_filter = min(1.0, mi_excess * 5)

    return k_filter, p_value


def _envelope_coupling(a, b, n_shuffles, seed):
    """Fallback: coupling between amplitude envelopes."""
    env_a = np.abs(sig.hilbert(a - np.mean(a)))
    env_b = np.abs(sig.hilbert(b - np.mean(b)))

    if np.std(env_a) < 1e-15 or np.std(env_b) < 1e-15:
        return 0.0, 1.0

    r_obs = abs(np.corrcoef(env_a, env_b)[0, 1])
    if np.isnan(r_obs):
        return 0.0, 1.0

    rng = np.random.RandomState(seed)
    r_null = np.empty(n_shuffles)
    env_a_shuf = env_a.copy()
    for i in range(n_shuffles):
        rng.shuffle(env_a_shuf)
        r_null[i] = abs(np.corrcoef(env_a_shuf, env_b)[0, 1])
        if np.isnan(r_null[i]):
            r_null[i] = 0

    p = float(np.mean(r_null >= r_obs))
    excess = max(0, r_obs - np.mean(r_null))
    return min(1.0, excess * 2), p


def _modulation_index(phase, amplitude, n_bins=18):
    """Tort modulation index: KL divergence of amp distribution over phase bins."""
    bins = np.linspace(-np.pi, np.pi, n_bins + 1)
    mean_amp = np.zeros(n_bins)
    for i in range(n_bins):
        mask = (phase >= bins[i]) & (phase < bins[i + 1])
        if mask.sum() > 0:
            mean_amp[i] = amplitude[mask].mean()

    total = mean_amp.sum()
    if total <= 0:
        return 0.0

    p = mean_amp / total
    uniform = np.ones(n_bins) / n_bins
    p_safe = np.where(p > 0, p, 1e-10)
    mi = np.sum(p_safe * np.log(p_safe / uniform)) / np.log(n_bins)
    return float(mi)


# ═══════════════════════════════════════════════════════════
# AXIS 2: K_BIND — Temporal Binding
# ═══════════════════════════════════════════════════════════
# Does the coupling stay consistent over time, or flicker?
# Split both signals into windows, measure coupling per window,
# return the consistency (1 - CV) of those measurements.


def _compute_k_bind(a, b, fs):
    """Temporal binding: consistency of cross-correlation across windows."""
    n = len(a)

    # Window size: 2 seconds or 1/4 of signal, whichever is smaller
    window = min(int(2 * fs), n // 4) if fs > 1 else n // 4
    window = max(window, 8)  # minimum 8 samples per window

    n_windows = n // window
    if n_windows < 2:
        # Can't measure binding with fewer than 2 windows
        # Fall back to single-window correlation stability
        return _single_window_bind(a, b)

    # Coupling in each window
    couplings = []
    for w in range(n_windows):
        start = w * window
        end = start + window
        seg_a = a[start:end]
        seg_b = b[start:end]

        if np.std(seg_a) < 1e-15 or np.std(seg_b) < 1e-15:
            couplings.append(0)
            continue

        r = np.corrcoef(seg_a, seg_b)[0, 1]
        if np.isnan(r):
            couplings.append(0)
        else:
            couplings.append(abs(r))

    couplings = np.array(couplings)
    mean_c = np.mean(couplings)

    if mean_c < 1e-10:
        return 0.0

    # Binding = 1 minus coefficient of variation
    # High CV = flickering = low binding
    cv = np.std(couplings) / mean_c
    k_bind = float(max(0, min(1, 1 - cv)))

    # Weight by mean coupling strength
    # (consistent zero coupling is NOT high binding)
    k_bind *= min(1.0, mean_c * 2)

    return k_bind


def _single_window_bind(a, b):
    """Fallback for very short signals."""
    if np.std(a) < 1e-15 or np.std(b) < 1e-15:
        return 0.0
    r = np.corrcoef(a, b)[0, 1]
    if np.isnan(r):
        return 0.0
    return float(abs(r)) * 0.5  # penalized: can't confirm temporal stability


# ═══════════════════════════════════════════════════════════
# AXIS 3: K_HIERARCHY — Spectral Slope Similarity
# ═══════════════════════════════════════════════════════════
# How similarly do A and B organize their frequencies?
# Matching 1/f slopes = same internal hierarchy.
# Different slopes = different organizing principles.


def _compute_k_hierarchy(a, b, fs):
    """Spectral slope similarity between two signals."""
    slope_a = _spectral_slope(a, fs)
    slope_b = _spectral_slope(b, fs)

    # Similarity: 1 when slopes match, 0 when maximally different
    # Typical slopes range from -3 (very steep) to +1 (inverted)
    max_diff = 4.0  # range of plausible slopes
    diff = abs(slope_a - slope_b)
    k_hier = float(max(0, 1 - diff / max_diff))

    return k_hier, slope_a, slope_b


def _spectral_slope(x, fs):
    """1/f spectral slope of a signal."""
    n = len(x)
    if n < 8:
        return -1.0  # default

    # Use Welch for stability
    nperseg = min(256, n)
    freqs, psd = sig.welch(x, fs=fs, nperseg=nperseg)

    # Fit in log-log space, skip DC
    mask = freqs > 0
    if mask.sum() < 3:
        return -1.0

    log_f = np.log10(freqs[mask])
    log_p = np.log10(psd[mask] + 1e-30)

    coeffs = np.polyfit(log_f, log_p, 1)
    return float(coeffs[0])


# ═══════════════════════════════════════════════════════════
# AXIS 4: K_DIRECTION — Who Drives Whom
# ═══════════════════════════════════════════════════════════
# Transfer entropy: bits erased in B's future due to A's past.
# Positive = A drives B. Negative = B drives A. Zero = mutual.
# Granger-like but nonlinear — doesn't assume linear causality.


def _compute_k_direction(a, b, n_shuffles, seed):
    """Directional coupling via transfer entropy."""
    n = len(a)

    if n < 20:
        return 0.0, 0.0, 0.0, 'MUTUAL'

    # Normalize to [0, 1]
    a_n = (a - a.min()) / (a.max() - a.min() + 1e-15)
    b_n = (b - b.min()) / (b.max() - b.min() + 1e-15)

    te_ab = _transfer_entropy(a_n, b_n)
    te_ba = _transfer_entropy(b_n, a_n)

    # Null distribution
    rng = np.random.RandomState(seed)
    te_ab_null = np.empty(n_shuffles)
    te_ba_null = np.empty(n_shuffles)
    a_shuf = a_n.copy()

    for i in range(n_shuffles):
        rng.shuffle(a_shuf)
        te_ab_null[i] = _transfer_entropy(a_shuf, b_n)
        te_ba_null[i] = _transfer_entropy(b_n, a_shuf)

    te_ab_real = max(0, te_ab - np.mean(te_ab_null))
    te_ba_real = max(0, te_ba - np.mean(te_ba_null))

    p_ab = float(np.mean(te_ab_null >= te_ab))
    p_ba = float(np.mean(te_ba_null >= te_ba))

    sig_ab = p_ab < 0.05 and te_ab_real > 0.005
    sig_ba = p_ba < 0.05 and te_ba_real > 0.005

    # Direction score: positive = A leads, negative = B leads
    total = te_ab_real + te_ba_real
    if total < 1e-10:
        k_dir = 0.0
        label = 'MUTUAL'
    else:
        k_dir = (te_ab_real - te_ba_real) / total
        if sig_ab and sig_ba:
            label = 'MUTUAL'
        elif sig_ab:
            label = 'A_DRIVES'
        elif sig_ba:
            label = 'B_DRIVES'
        else:
            label = 'MUTUAL'

    return float(k_dir), float(te_ab_real), float(te_ba_real), label


def _transfer_entropy(source, target, lag=1, bins=16):
    """TE(source -> target): how much does source's past reduce
    uncertainty about target's future, beyond target's own past?"""
    n = len(target) - lag
    if n < 10:
        return 0.0

    t_past = target[:n]
    t_future = target[lag:lag + n]
    s_past = source[:n]

    h_cond = _conditional_entropy(t_future, t_past, bins)

    # Joint condition: target past + source past
    joint = t_past * bins + s_past
    joint = (joint - joint.min()) / (joint.max() - joint.min() + 1e-15)
    h_cond_both = _conditional_entropy(t_future, joint, bins)

    return max(0.0, h_cond - h_cond_both)


def _conditional_entropy(x, y, bins=32):
    """H(X|Y) = H(X,Y) - H(Y)."""
    counts, _, _ = np.histogram2d(x, y, bins=bins)
    p = counts.flatten() / counts.sum()
    p = p[p > 0]
    hxy = float(-np.sum(p * np.log2(p)))

    counts_y, _ = np.histogram(y, bins=bins)
    p_y = counts_y / counts_y.sum()
    p_y = p_y[p_y > 0]
    hy = float(-np.sum(p_y * np.log2(p_y)))

    return hxy - hy


# ═══════════════════════════════════════════════════════════
# SCORING, CLASSIFICATION, DIAGNOSIS
# ═══════════════════════════════════════════════════════════


def _overall(k_filter, k_bind, k_hierarchy, k_direction):
    """Single coupling score from four axes.

    Weighted: filter 30%, bind 30%, hierarchy 20%, |direction| 20%.
    Direction magnitude matters (strong driver = strong coupling),
    sign doesn't affect overall strength.
    """
    score = (
        0.30 * k_filter +
        0.30 * k_bind +
        0.20 * k_hierarchy +
        0.20 * abs(k_direction)
    )
    return float(max(0, min(1, score)))


def _classify(k_filter, k_bind, k_hierarchy, k_direction, filter_p):
    """Assign a profile type."""
    real_filter = filter_p < 0.05 and k_filter > 0.05

    if k_bind > 0.5 and (real_filter or k_hierarchy > 0.5):
        return 'COUPLED'
    if k_bind > 0.3 and k_hierarchy > 0.7:
        return 'ENTRAINED'
    if abs(k_direction) > 0.5 and k_bind < 0.3:
        return 'FORCED'
    if k_bind < 0.2 and k_filter < 0.1:
        return 'INDEPENDENT'
    if k_bind > 0.1 and k_bind < 0.4:
        return 'FLICKERING'

    # Default based on overall strength
    overall = _overall(k_filter, k_bind, k_hierarchy, k_direction)
    if overall > 0.4:
        return 'COUPLED'
    if overall > 0.15:
        return 'FLICKERING'
    return 'INDEPENDENT'


def _diagnose(k_filter, k_bind, k_hierarchy, k_direction,
              dir_label, profile_type, n):
    """Plain English diagnosis."""
    lines = []

    # Profile type headline
    headlines = {
        'COUPLED':     "These signals are genuinely coupled.",
        'ENTRAINED':   "These signals are entrained — same internal rhythm.",
        'FORCED':      "One signal is forcing the other, but it's resisting.",
        'FLICKERING':  "Coupling is intermittent — comes and goes.",
        'INDEPENDENT': "These signals are independent.",
    }
    lines.append(headlines.get(profile_type, "Ambiguous coupling."))

    # Filter axis
    if k_filter > 0.3:
        lines.append(
            f"Strong cross-frequency coupling ({k_filter:.2f}): "
            "slow rhythms in A gate fast activity in B."
        )
    elif k_filter > 0.1:
        lines.append(
            f"Moderate cross-frequency coupling ({k_filter:.2f}): "
            "some hierarchical gating."
        )

    # Bind axis
    if k_bind > 0.6:
        lines.append(
            f"Stable temporal binding ({k_bind:.2f}): "
            "coupling is consistent over time."
        )
    elif k_bind < 0.2:
        lines.append(
            f"Weak temporal binding ({k_bind:.2f}): "
            "coupling flickers or is absent."
        )

    # Hierarchy axis
    if k_hierarchy > 0.8:
        lines.append(
            f"Matching spectral hierarchy ({k_hierarchy:.2f}): "
            "both signals organize frequencies the same way."
        )
    elif k_hierarchy < 0.3:
        lines.append(
            f"Different spectral hierarchies ({k_hierarchy:.2f}): "
            "these signals have different internal structure."
        )

    # Direction axis
    dir_desc = {
        'A_DRIVES':  f"A drives B (direction={k_direction:+.2f}).",
        'B_DRIVES':  f"B drives A (direction={k_direction:+.2f}).",
        'MUTUAL':    "Neither signal dominates — mutual influence.",
    }
    lines.append(dir_desc.get(dir_label, "Direction unclear."))

    if n < 50:
        lines.append(
            f"Warning: only {n} samples. "
            "Results are suggestive, not definitive. Need 50+."
        )

    return ' '.join(lines)


def _compare(k_filter, k_bind, k_hierarchy, k_direction):
    """Compare to known coupling archetypes."""
    # Known profiles (from neuroscience and signal processing literature)
    archetypes = {
        'Brain EEG (healthy)': {
            'filter': 0.15, 'bind': 0.7, 'hier': 0.6, 'dir': 0.1,
            'desc': "Balanced hierarchy, stable binding, mild top-down."
        },
        'Brain EEG (schizophrenia)': {
            'filter': 0.25, 'bind': 0.3, 'hier': 0.4, 'dir': 0.05,
            'desc': "Over-coupled but temporally unstable."
        },
        'Heartbeat-respiration': {
            'filter': 0.3, 'bind': 0.8, 'hier': 0.7, 'dir': 0.6,
            'desc': "Strong PAC, respiration drives heart rate."
        },
        'Two pendulums (entrained)': {
            'filter': 0.05, 'bind': 0.95, 'hier': 0.95, 'dir': 0.0,
            'desc': "Pure entrainment, perfect binding, mutual."
        },
        'Random noise pair': {
            'filter': 0.02, 'bind': 0.05, 'hier': 0.5, 'dir': 0.0,
            'desc': "Nothing. Hierarchy match is accidental."
        },
    }

    vec = np.array([k_filter, k_bind, k_hierarchy, abs(k_direction)])
    best_name = None
    best_dist = float('inf')

    for name, arch in archetypes.items():
        arch_vec = np.array([arch['filter'], arch['bind'],
                             arch['hier'], abs(arch['dir'])])
        dist = float(np.linalg.norm(vec - arch_vec))
        if dist < best_dist:
            best_dist = dist
            best_name = name

    arch = archetypes[best_name]
    return {
        'closest_match':    best_name,
        'match_distance':   round(best_dist, 3),
        'match_description': arch['desc'],
    }


# ═══════════════════════════════════════════════════════════
# EMPTY RESULT (edge cases)
# ═══════════════════════════════════════════════════════════


def _empty(n, reason="Insufficient data."):
    """Return a valid but zeroed profile."""
    return {
        'K_filter':     0.0,
        'K_bind':       0.0,
        'K_hierarchy':  0.0,
        'K_direction':  0.0,
        'K_overall':    0.0,
        'profile_type': 'INDEPENDENT',
        'diagnosis':    reason,
        'comparison':   {'closest_match': 'Random noise pair',
                         'match_distance': 0,
                         'match_description': 'Nothing.'},
        'direction_label': 'MUTUAL',
        'slope_a':      0.0,
        'slope_b':      0.0,
        'TE_AB':        0.0,
        'TE_BA':        0.0,
        'filter_p':     1.0,
        'n':            n,
        'fs':           1.0,
    }
