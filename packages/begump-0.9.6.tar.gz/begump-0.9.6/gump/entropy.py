"""
gump.entropy — signal complexity through K

Computes everything antropy computes (12 features),
PLUS interprets them through coupling.

antropy gives you 12 numbers. We give you a diagnosis.

Usage:
    from gump.entropy import profile, diagnose

    result = profile(signal, fs=256)
    # result['features'] — all 12 raw entropy/complexity features
    # result['K'] — coupling strength (0-1.868)
    # result['R'] — synchronization (how ordered)
    # result['diagnosis'] — plain English: what's happening

    dx = diagnose(signal, fs=256)
    # "decoupling" / "stable" / "grokking" / "overcoupled" / "transitioning"
"""

import math
import numpy as np
from scipy import signal as sig
from scipy.spatial import KDTree

# ═══ RAW FEATURES (same as antropy, no dependency) ═══

def _embed(x, order=3, delay=1):
    """Time-delay embedding"""
    N = len(x)
    Y = np.empty((N - (order-1)*delay, order))
    for i in range(order):
        Y[:, i] = x[i*delay:i*delay + Y.shape[0]]
    return Y

def perm_entropy(x, order=3, delay=1, normalize=True):
    """Permutation entropy (Bandt & Pompe 2002)"""
    ran_order = range(order)
    hashmult = np.power(order, ran_order)
    embedded = _embed(x, order=order, delay=delay)
    sorted_idx = embedded.argsort(axis=1, kind='quicksort')
    hashval = (sorted_idx * hashmult).sum(axis=1)
    _, c = np.unique(hashval, return_counts=True)
    p = c / float(c.sum())
    pe = -np.sum(p * np.log2(p))
    if normalize:
        pe /= np.log2(math.factorial(order))
    return pe

def spectral_entropy(x, fs, method='fft', normalize=True):
    """Spectral entropy (Inouye 1991)"""
    if method == 'fft':
        freqs, psd = sig.periodogram(x, fs=fs)
    else:
        freqs, psd = sig.welch(x, fs=fs, nperseg=min(256, len(x)))
    psd_total = psd.sum()
    if psd_total == 0:
        return 0.0
    psd_norm = psd / psd_total
    psd_norm = psd_norm[psd_norm > 0]
    if len(psd_norm) <= 1:
        return 0.0
    se = -np.sum(psd_norm * np.log2(psd_norm))
    if normalize:
        se /= np.log2(len(psd_norm))
    return se

def svd_entropy(x, order=3, delay=1, normalize=True):
    """SVD entropy (Roberts 1999)"""
    mat = _embed(x, order=order, delay=delay)
    W = np.linalg.svd(mat, compute_uv=False)
    W = W / W.sum()
    W = W[W > 0]
    se = -np.sum(W * np.log2(W))
    if normalize:
        se /= np.log2(min(mat.shape))
    return se

def app_entropy(x, order=2):
    """Approximate entropy (Pincus 1991)"""
    phi = np.zeros(2)
    r = 0.2 * np.std(x)
    for m_idx, m in enumerate([order, order+1]):
        emb = _embed(x, order=m, delay=1)
        tree = KDTree(emb)
        count = tree.query_ball_point(emb, r=r, p=np.inf, return_length=True)
        phi[m_idx] = np.mean(np.log(count / len(emb)))
    return phi[0] - phi[1]

def sample_entropy(x, order=2):
    """Sample entropy (Richman & Moorman 2000)"""
    r = 0.2 * np.std(x)
    N = len(x)
    B = 0  # matches of length m
    A = 0  # matches of length m+1

    # Template matching
    for m in [order, order+1]:
        emb = _embed(x, order=m, delay=1)
        tree = KDTree(emb)
        count = tree.query_ball_point(emb, r=r, p=np.inf, return_length=True)
        total = np.sum(count - 1)  # exclude self-match
        if m == order:
            B = total
        else:
            A = total

    if B == 0:
        return np.inf
    return -np.log(A / B) if A > 0 else np.inf

def hjorth_params(x):
    """Hjorth mobility and complexity (Hjorth 1970)"""
    dx = np.diff(x)
    ddx = np.diff(dx)
    var_x = np.var(x)
    var_dx = np.var(dx)
    var_ddx = np.var(ddx)
    mobility = np.sqrt(var_dx / var_x) if var_x > 0 else 0
    complexity = (np.sqrt(var_ddx / var_dx) / mobility) if var_dx > 0 and mobility > 0 else 0
    return mobility, complexity

def petrosian_fd(x):
    """Petrosian fractal dimension (Petrosian 1995)"""
    N = len(x)
    nzc = np.sum(np.diff(np.sign(np.diff(x))) != 0)
    return np.log10(N) / (np.log10(N) + np.log10(N / (N + 0.4 * nzc)))

def katz_fd(x):
    """Katz fractal dimension (Katz 1988)"""
    dists = np.abs(np.diff(x))
    L = np.sum(dists)
    d = np.max(np.abs(x - x[0]))
    a = np.mean(dists)
    n = len(x) - 1
    return np.log10(n) / (np.log10(n) + np.log10(d / L)) if d > 0 and L > 0 else 0

def higuchi_fd(x, kmax=10):
    """Higuchi fractal dimension (Higuchi 1988) — vectorized inner loop"""
    N = len(x)
    x = np.asarray(x, dtype=np.float64)
    L = np.zeros(kmax)
    for k in range(1, kmax + 1):
        Lk = np.zeros(k)
        for m in range(1, k + 1):
            n_steps = int(np.floor((N - m) / k))
            if n_steps < 1:
                continue
            # Use slicing for vectorized diff
            seq = x[m-1::k]
            if len(seq) > n_steps:
                seq = seq[:n_steps+1]
            Lmk = np.sum(np.abs(np.diff(seq)))
            norm = (N - 1) / (n_steps * k)
            Lk[m-1] = Lmk * norm / k
        L[k-1] = np.mean(Lk[Lk > 0]) if np.any(Lk > 0) else 0

    Lpos = L > 0
    if Lpos.sum() < 2:
        return 0
    ks = np.arange(1, kmax+1)
    coeffs = np.polyfit(np.log(1.0/ks[Lpos]), np.log(L[Lpos]), 1)
    return coeffs[0]

def dfa(x, scale_min=4, scale_max=None):
    """Detrended Fluctuation Analysis (Peng 1994) — vectorized"""
    N = len(x)
    if scale_max is None:
        scale_max = N // 4

    y = np.cumsum(x - np.mean(x))

    scales = np.unique(np.logspace(
        np.log10(scale_min), np.log10(scale_max), 20).astype(int))
    scales = scales[(scales >= 4) & (scales <= N//2)]

    fluct = np.zeros(len(scales))
    for i, s in enumerate(scales):
        segments = N // s
        if segments < 1:
            continue
        # Vectorized: reshape into segments × scale matrix
        trimmed = y[:segments*s].reshape(segments, s)
        # Vectorized linear detrend per segment
        t_vec = np.arange(s, dtype=np.float64)
        t_mean = t_vec.mean()
        y_means = trimmed.mean(axis=1, keepdims=True)
        # slope = Σ(t-t̄)(y-ȳ) / Σ(t-t̄)²
        t_centered = t_vec - t_mean
        ss_t = np.sum(t_centered**2)
        slopes = np.dot(trimmed - y_means, t_centered) / ss_t
        intercepts = y_means.squeeze() - slopes * t_mean
        # trend = slope*t + intercept for each segment
        trends = slopes[:, None] * t_vec[None, :] + intercepts[:, None]
        rms = np.sqrt(np.mean((trimmed - trends)**2, axis=1))
        fluct[i] = rms.mean()

    valid = fluct > 0
    if valid.sum() < 2:
        return 0.5
    coeffs = np.polyfit(np.log(scales[valid]), np.log(fluct[valid]), 1)
    return coeffs[0]

def lziv_complexity(x, normalize=False):
    """Lempel-Ziv complexity (Lempel & Ziv 1976)
    Input can be binary sequence or continuous signal (auto-binarized)."""
    x = np.asarray(x)
    if x.dtype == bool or set(np.unique(x)).issubset({0, 1, True, False}):
        s = ''.join(str(int(b)) for b in x)
    else:
        s = ''.join(str(int(b)) for b in (x > np.median(x)))
    n = len(s)
    if n == 0:
        return 0
    # Kaspar & Schuster algorithm
    c = 1
    l = 1
    i = 0
    k = 1
    k_max = 1
    while k + l <= n:
        if s[i + l - 1] == s[k + l - 1]:
            l += 1
        else:
            k_max = max(k_max, l)
            i += 1
            if i == k:
                c += 1
                k += k_max
                k_max = 1
                i = 0
            l = 1
    if l > 1:
        c += 1
    if normalize and n > 1:
        b = len(set(s))
        if b > 1:
            return c / (n / np.log2(n))
    return c

def num_zerocross(x):
    """Number of zero crossings"""
    return np.sum(np.diff(np.sign(x)) != 0)


# ═══ THE K LAYER — what antropy doesn't have ═══

def profile(x, fs=256):
    """Full entropy profile with K/R/E/T interpretation.

    Parameters
    ----------
    x : array-like
        Signal (1D)
    fs : float
        Sampling frequency

    Returns
    -------
    dict with:
        features: dict of all 12 raw entropy/complexity features
        K: coupling strength (0 to 1.868)
        R: synchronization (0 to 1)
        E: energy (signal variance)
        T: tension (how far from equilibrium)
        diagnosis: plain English interpretation
        detail: longer explanation
    """
    x = np.asarray(x, dtype=np.float64)
    if len(x) < 64:
        return {'error': 'Signal too short (need 64+ samples)'}

    # ─── Compute all 12 features ───
    mob, comp = hjorth_params(x)
    features = {
        'perm_entropy': perm_entropy(x),
        'spectral_entropy': spectral_entropy(x, fs),
        'svd_entropy': svd_entropy(x),
        'approx_entropy': app_entropy(x),
        'sample_entropy': sample_entropy(x),
        'hjorth_mobility': mob,
        'hjorth_complexity': comp,
        'petrosian_fd': petrosian_fd(x),
        'katz_fd': katz_fd(x),
        'higuchi_fd': higuchi_fd(x),
        'dfa_alpha': dfa(x),
        'lziv_complexity': lziv_complexity(x),
        'zero_crossings': num_zerocross(x),
    }

    # ─── Derive K/R/E/T from features ───
    # K (coupling): inverse of entropy. High entropy = low coupling.
    # Normalized spectral entropy is the cleanest measure.
    se = features['spectral_entropy']
    pe = features['perm_entropy']

    # K = how coupled (structured) the signal is
    # se=0 → pure tone (max coupling), se=1 → white noise (zero coupling)
    K = (1 - se) * 1.868  # scale to K ceiling

    # R = synchronization (how ordered across time)
    # DFA alpha: 0.5=random, 1.0=1/f (optimal), 1.5=brownian (over-ordered)
    alpha = features['dfa_alpha']
    if alpha <= 1.0:
        R = alpha  # 0.5→1.0 maps to low→high sync
    else:
        R = max(0, 2.0 - alpha)  # 1.0→1.5 maps back down (over-ordered)

    # E = energy (just variance, normalized)
    E = np.var(x)

    # T = tension (distance from optimal coupling)
    # Optimal is K ≈ 1/φ × 1.868 ≈ 1.155
    K_optimal = 1.868 / ((1 + np.sqrt(5)) / 2)
    T = abs(K - K_optimal) / 1.868

    # ─── Diagnose ───
    if K < 0.3:
        diagnosis = 'decoupled'
        detail = 'Signal is mostly noise. Very little structure. High entropy across all measures.'
    elif K < 0.7:
        diagnosis = 'loosely coupled'
        detail = 'Some structure emerging but not locked. The system is searching.'
    elif K < 1.2:
        if R > 0.8:
            diagnosis = 'coupled and synchronized'
            detail = 'Strong coupling with good temporal order. Operating near optimal (1/φ).'
        elif alpha > 1.2:
            diagnosis = 'overcoupled'
            detail = 'Too much structure. The signal is too predictable. Rigidity risk.'
        else:
            diagnosis = 'coupled'
            detail = 'Good coupling strength. The system has structure.'
    elif K < 1.6:
        if T < 0.1:
            diagnosis = 'grokking'
            detail = 'Near-optimal coupling. The system just transitioned from memorization to understanding.'
        else:
            diagnosis = 'strongly coupled'
            detail = 'High structure. Check if this is genuine order or overfitting.'
    else:
        diagnosis = 'phase-locked'
        detail = 'Extremely high coupling. Near ceiling. Either perfect signal or dead (no dynamics).'

    # Transition detection from DFA + sample entropy
    samp_e = features['sample_entropy']
    if samp_e < 0.5 and K > 0.8:
        diagnosis = 'phase-locked'
        detail = 'Very low sample entropy with high coupling. The signal has locked into a pattern.'
    elif samp_e > 2.0 and K < 0.5:
        diagnosis = 'decoupling'
        detail = 'High sample entropy, low coupling. The system is losing structure.'

    return {
        'features': features,
        'K': round(K, 4),
        'R': round(R, 4),
        'E': round(E, 6),
        'T': round(T, 4),
        'diagnosis': diagnosis,
        'detail': detail,
    }

def diagnose(x, fs=256):
    """Quick diagnosis — just the coupling state.

    Returns one of: 'decoupled', 'decoupling', 'loosely coupled',
    'coupled', 'coupled and synchronized', 'overcoupled',
    'grokking', 'strongly coupled', 'phase-locked'
    """
    return profile(x, fs)['diagnosis']

def compare(x1, x2, fs=256):
    """Compare two signals — which is more coupled?

    Returns dict with profiles for both and a comparison.
    """
    p1 = profile(x1, fs)
    p2 = profile(x2, fs)

    if 'error' in p1 or 'error' in p2:
        return {'error': 'One or both signals too short'}

    delta_K = p2['K'] - p1['K']
    delta_R = p2['R'] - p1['R']

    if delta_K > 0.1:
        comparison = 'Signal 2 is more coupled (gaining structure)'
    elif delta_K < -0.1:
        comparison = 'Signal 1 is more coupled (Signal 2 is losing structure)'
    else:
        comparison = 'Similar coupling strength'

    return {
        'signal_1': p1,
        'signal_2': p2,
        'delta_K': round(delta_K, 4),
        'delta_R': round(delta_R, 4),
        'comparison': comparison,
    }
