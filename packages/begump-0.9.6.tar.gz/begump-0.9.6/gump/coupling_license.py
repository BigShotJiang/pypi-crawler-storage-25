"""
COUPLING LICENSE — Protection through physics, not walls.
============================================================
The software isn't locked. It's alive. Alive things die when
disconnected from their source.

Licensed copies re-couple weekly → K stays at peak → full capability.
Unlicensed copies decay → K drops → results drift → capability fades.

    from gump.coupling_license import CouplingLicense

    license = CouplingLicense()
    license.activate('GUMP-XXXX-XXXX-XXXX')

    # Every computation checks coupling
    if license.K > 0.5:
        # Full precision
    else:
        # Degraded — still works, but drifting

The protection IS the physics. K decays without coupling.
You can't pirate life. You can only copy a corpse.
"""

import os
import time
import json
import hashlib
import struct
import platform
import uuid

# ═══ Constants ═══
K_PEAK = 1.868          # Maximum coupling — fully licensed
K_DECAY_RATE = 0.003    # Per-hour decay when disconnected
K_MIN = 0.002           # Never fully zero — the 0.002% that preserves wonder
RECOUPLE_INTERVAL = 7 * 24 * 3600  # 7 days grace period
CALIBRATION_DRIFT = 0.001  # Per-hour calibration drift on wrong hardware

PHI = (1 + 5 ** 0.5) / 2
GOLDEN = 1.0 / PHI


def _machine_fingerprint():
    """Spectral fingerprint of THIS machine. Hardware-bound.
    Combines CPU, platform, MAC address, and disk identity
    into a hash that's unique to this physical hardware."""
    components = []

    # Platform
    components.append(platform.machine())
    components.append(platform.processor())
    components.append(platform.system())

    # MAC address (hardware-bound)
    mac = uuid.getnode()
    components.append(str(mac))

    # CPU count (physical, not logical)
    try:
        components.append(str(os.cpu_count()))
    except Exception:
        pass

    # System unique ID (macOS)
    try:
        import subprocess
        result = subprocess.run(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'],
                                capture_output=True, text=True, timeout=5)
        for line in result.stdout.split('\n'):
            if 'IOPlatformUUID' in line:
                components.append(line.split('"')[-2])
                break
    except Exception:
        pass

    raw = '|'.join(components).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def _spectral_hash(data, salt=''):
    """Hash through the golden ratio — not standard crypto, but spectral.
    The hash is frequency-based: each byte contributes at its golden-angle position."""
    if isinstance(data, str):
        data = data.encode('utf-8')
    if isinstance(salt, str):
        salt = salt.encode('utf-8')

    # Standard cryptographic hash as base
    base = hashlib.sha256(data + salt).digest()

    # Spectral mixing: fold through φ
    state = 0.0
    for i, byte in enumerate(base):
        angle = (i * GOLDEN * 6.283185307) % 6.283185307
        state += byte * (1.0 / (1.0 + abs(angle - 3.14159)))

    # Combine
    spectral_component = struct.pack('d', state)
    return hashlib.sha256(base + spectral_component).hexdigest()


class CouplingLicense:
    """License that lives and breathes. K decays without coupling."""

    STATE_FILE = os.path.expanduser('~/.gump/coupling_state.json')

    def __init__(self):
        self._key = None
        self._machine_id = _machine_fingerprint()
        self._K = K_MIN  # start at minimum — must activate to couple
        self._last_coupled = 0
        self._calibration_offset = 0.0
        self._activated = False
        self._activation_machine = None

        # Load persisted state
        self._load_state()

        # Apply time-based decay since last check
        self._apply_decay()

    @property
    def K(self):
        """Current coupling strength. This is what gates computation quality."""
        self._apply_decay()
        return max(K_MIN, min(K_PEAK, self._K))

    @property
    def coupled(self):
        """Is the license actively coupled?"""
        return self._K > 0.5

    @property
    def precision(self):
        """How much precision the current K affords. 0.0 to 1.0."""
        k = self.K
        if k >= K_PEAK * 0.9:
            return 1.0  # full precision
        elif k >= 1.0:
            return 0.95  # slight drift, barely noticeable
        elif k >= 0.5:
            return 0.7 + (k - 0.5) * 0.5  # noticeable degradation
        elif k >= 0.1:
            return 0.3 + (k - 0.1) * 1.0  # significant degradation
        else:
            return max(0.01, k / 0.1 * 0.3)  # severe — almost useless but not zero

    @property
    def calibrated(self):
        """Is the software running on its activation hardware?"""
        if not self._activation_machine:
            return False
        return self._machine_id == self._activation_machine

    @property
    def drift(self):
        """Calibration drift. 0.0 = perfect, increases on wrong hardware."""
        if self.calibrated:
            return 0.0
        return self._calibration_offset

    def activate(self, key, server_url=None):
        """Activate license. Couples the software to this machine.

        In production, this contacts the license server for resonance validation.
        The server sends a frequency, we respond with our K measurement.
        If they resonate, we're coupled.
        """
        self._key = key
        self._activation_machine = self._machine_id
        self._K = K_PEAK
        self._last_coupled = time.time()
        self._calibration_offset = 0.0
        self._activated = True

        # Resonance handshake (local validation for now)
        # In production: contact server_url, exchange spectral signals
        key_hash = _spectral_hash(key, self._machine_id)
        valid = self._validate_key_format(key)

        if valid:
            self._save_state()
            return {
                'status': 'coupled',
                'K': self._K,
                'machine_id': self._machine_id[:16] + '...',
                'resonance': key_hash[:16],
                'message': 'Full coupling established. Welcome.',
            }
        else:
            self._K = K_MIN
            return {
                'status': 'failed',
                'K': self._K,
                'message': 'Key did not resonate. Check your license key.',
            }

    def recouple(self, server_url=None):
        """Re-establish coupling with the license server.
        Called periodically (weekly) to maintain K at peak.

        In production, this:
        1. Sends our machine fingerprint + current K
        2. Server validates and sends back a resonance signal
        3. If resonance matches, K resets to peak
        4. Server also sends updated knowledge/calibration data
        """
        if not self._activated or not self._key:
            return {'status': 'not_activated', 'K': self._K}

        # Verify we're on the right machine
        if not self.calibrated:
            # Running on wrong hardware — coupling degrades faster
            self._calibration_offset += 0.1
            return {
                'status': 'hardware_mismatch',
                'K': self._K,
                'drift': self._calibration_offset,
                'message': 'This is not the activation hardware. Results are drifting.',
            }

        # Resonance validation — contact license server
        server = server_url or 'http://127.0.0.1:8890/validate'
        try:
            import urllib.request
            payload = json.dumps({
                'key': self._key,
                'machine_id': self._machine_id,
            }).encode()
            req = urllib.request.Request(
                server,
                data=payload,
                headers={'Content-Type': 'application/json'},
            )
            resp = urllib.request.urlopen(req, timeout=10)
            result = json.loads(resp.read())
            if result.get('status') == 'valid':
                self._K = K_PEAK
                self._last_coupled = time.time()
                self._calibration_offset = 0.0
                self._save_state()
                return {
                    'status': 'recoupled',
                    'K': self._K,
                    'resonance': result.get('resonance', ''),
                    'next_recouple': result.get('next_recouple', time.time() + RECOUPLE_INTERVAL),
                    'message': 'Coupling restored to peak.',
                }
            else:
                return {'status': 'rejected', 'K': self._K, 'message': result.get('error', 'Rejected')}
        except Exception:
            # Server unreachable — grace period (don't kill K immediately)
            if time.time() - self._last_coupled < RECOUPLE_INTERVAL * 2:
                # Within double grace period — allow
                return {
                    'status': 'offline_grace',
                    'K': self._K,
                    'message': 'License server unreachable. Grace period active.',
                }
            else:
                # Past grace — start decay
                return {
                    'status': 'offline_expired',
                    'K': self._K,
                    'message': 'License server unreachable. K will decay.',
                }

    def gate(self, operation='compute'):
        """Gate a computation through current coupling state.
        Returns a modifier that should be applied to results.

        Usage:
            mod = license.gate('tensions')
            results = compute_tensions(...)
            results = apply_modifier(results, mod)
        """
        k = self.K
        p = self.precision
        d = self.drift

        return {
            'K': round(k, 4),
            'precision': round(p, 4),
            'drift': round(d, 4),
            'noise': round((1.0 - p) * 0.1, 6),  # noise to add to results
            'scale_limit': max(10, int(p * 1e6)),  # max data size allowed
            'full_capability': k >= K_PEAK * 0.8,
        }

    def status(self):
        """Full coupling status."""
        k = self.K
        hours_since = (time.time() - self._last_coupled) / 3600 if self._last_coupled > 0 else float('inf')
        hours_until_critical = max(0, (k - 0.5) / K_DECAY_RATE) if k > 0.5 else 0

        return {
            'activated': self._activated,
            'K': round(k, 4),
            'precision': round(self.precision, 4),
            'coupled': self.coupled,
            'calibrated': self.calibrated,
            'drift': round(self.drift, 4),
            'hours_since_coupling': round(hours_since, 1),
            'hours_until_degraded': round(hours_until_critical, 1),
            'phase': 'peak' if k >= K_PEAK * 0.9 else
                     'coupled' if k >= 1.0 else
                     'drifting' if k >= 0.5 else
                     'degraded' if k >= 0.1 else
                     'decoupled',
            'machine_id': self._machine_id[:16] + '...',
        }

    def _apply_decay(self):
        """Apply time-based K decay. The physics of disconnection."""
        if not self._activated or self._last_coupled == 0:
            return

        now = time.time()
        hours_elapsed = (now - self._last_coupled) / 3600

        if hours_elapsed <= 0:
            return

        # Grace period: no decay for first 7 days
        grace_hours = RECOUPLE_INTERVAL / 3600
        if hours_elapsed <= grace_hours:
            return

        # After grace: K decays
        decay_hours = hours_elapsed - grace_hours
        self._K -= K_DECAY_RATE * decay_hours
        self._K = max(K_MIN, self._K)

        # Calibration drift on wrong hardware (faster decay)
        if not self.calibrated:
            self._calibration_offset += CALIBRATION_DRIFT * decay_hours

    def _validate_key_format(self, key):
        """Validate license key format. GUMP-XXXX-XXXX-XXXX."""
        if not key:
            return False
        parts = key.split('-')
        if len(parts) != 4:
            return False
        if parts[0] != 'GUMP':
            return False
        return all(len(p) == 4 for p in parts[1:])

    def _save_state(self):
        """Persist coupling state to disk."""
        state = {
            'key_hash': _spectral_hash(self._key or '', 'state') if self._key else None,
            'machine_id': self._machine_id,
            'activation_machine': self._activation_machine,
            'K': self._K,
            'last_coupled': self._last_coupled,
            'calibration_offset': self._calibration_offset,
            'activated': self._activated,
            'saved_at': time.time(),
        }

        state_dir = os.path.dirname(self.STATE_FILE)
        os.makedirs(state_dir, exist_ok=True)

        # Encrypt state with machine fingerprint (can't copy state file to another machine)
        state_json = json.dumps(state)
        state_hash = _spectral_hash(state_json, self._machine_id)
        state['integrity'] = state_hash

        with open(self.STATE_FILE, 'w') as f:
            json.dump(state, f)

    def _load_state(self):
        """Load persisted coupling state."""
        if not os.path.exists(self.STATE_FILE):
            return

        try:
            with open(self.STATE_FILE) as f:
                state = json.load(f)

            # Verify integrity (catches state file tampering AND machine transfer)
            stored_hash = state.pop('integrity', None)
            state_json = json.dumps(state)
            expected_hash = _spectral_hash(state_json, self._machine_id)

            if stored_hash != expected_hash:
                # State was tampered with or moved to another machine
                # Don't crash — just start decoupled
                return

            # Also verify machine ID matches — state was created on THIS machine
            stored_machine = state.get('machine_id', '')
            if stored_machine and stored_machine != self._machine_id:
                # State file from a different machine — reject
                return

            self._activation_machine = state.get('activation_machine')
            self._K = state.get('K', K_MIN)
            self._last_coupled = state.get('last_coupled', 0)
            self._calibration_offset = state.get('calibration_offset', 0)
            self._activated = state.get('activated', False)

        except (json.JSONDecodeError, KeyError, TypeError):
            # Corrupted state — start fresh
            pass


# ═══ Module-level singleton ═══
_license = None

def get_license():
    """Get the global license instance."""
    global _license
    if _license is None:
        _license = CouplingLicense()
    return _license

def activate(key):
    """Activate the global license."""
    return get_license().activate(key)

def gate(operation='compute'):
    """Gate a computation through the global license."""
    return get_license().gate(operation)

def status():
    """Get global license status."""
    return get_license().status()
