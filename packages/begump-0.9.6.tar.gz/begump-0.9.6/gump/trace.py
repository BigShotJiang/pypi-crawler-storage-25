"""
TRACE — Spectral forensics for financial data.
=================================================
Feed it any transaction history. It builds a spectral graph and finds
what doesn't fit: suspicious patterns, hidden relationships, anomalous
flows, and structural risks that traditional audits miss.

    from gump.trace import scan, scan_csv

    # From a list of transactions
    result = scan([
        {'from': 'Alice', 'to': 'Bob', 'amount': 500, 'date': '2026-01-15'},
        {'from': 'Bob', 'to': 'Carol', 'amount': 480, 'date': '2026-01-16'},
        {'from': 'Carol', 'to': 'Alice', 'amount': 460, 'date': '2026-01-17'},
    ])

    print(result['risk_score'])       # 0-100
    print(result['flags'])            # what looks wrong
    print(result['tensions'])         # hidden relationships
    print(result['flows'])            # money flow patterns
    print(result['report'])           # human-readable summary

    # From CSV (from,to,amount,date per line)
    result = scan_csv('transactions.csv')

    # Interactive report
    html = visualize(result)

No data leaves your machine. Ever.
"""

import json
import time
import numpy as np
from collections import defaultdict
from gump.core import _TensionDetector, place as spectral_place, PHI, EnergyTracker, LANDAUER_PER_BIT


def scan(transactions, top_k=20):
    """Spectral forensic analysis of transaction data.

    Args:
        transactions: list of dicts with 'from', 'to', 'amount' (and optionally 'date', 'memo')
        top_k: how many tensions/anomalies to return

    Returns comprehensive forensic analysis.

    Free tier: up to 10 transactions. Full tier: unlimited.
    """
    from gump.gate import check as _gate_check
    if not transactions:
        return {'error': 'No transactions provided'}
    if len(transactions) > 10:
        allowed, msg = _gate_check('trace_scan', 0)
        if not allowed:
            return {'error': msg}

    # Build entity graph
    entities = set()
    edges = defaultdict(float)  # (a, b) → total flow
    edge_count = defaultdict(int)
    entity_sent = defaultdict(float)
    entity_received = defaultdict(float)
    entity_tx_count = defaultdict(int)
    timestamps = []

    for tx in transactions:
        sender = tx.get('from', tx.get('sender', ''))
        receiver = tx.get('to', tx.get('receiver', ''))
        try:
            amount = float(tx.get('amount', 0))
        except (TypeError, ValueError):
            amount = 0.0
        date = tx.get('date', tx.get('timestamp', ''))

        if not sender or not receiver or amount <= 0:
            continue

        entities.add(sender)
        entities.add(receiver)
        pair = (sender, receiver)
        edges[pair] += amount
        edge_count[pair] += 1
        entity_sent[sender] += amount
        entity_received[receiver] += amount
        entity_tx_count[sender] += 1
        entity_tx_count[receiver] += 1
        if date:
            timestamps.append(date)

    if len(entities) < 2:
        return {'error': 'Need at least 2 entities'}

    entity_list = sorted(entities)
    idx = {name: i for i, name in enumerate(entity_list)}
    n = len(entity_list)

    # Build edges for spectral analysis
    graph_edges = []
    graph_weights = []
    for (a, b), amount in edges.items():
        if a in idx and b in idx:
            graph_edges.append((idx[a], idx[b]))
            graph_weights.append(amount)

    if not graph_edges:
        return {'error': 'No valid transactions between entities'}

    # ═══ SPECTRAL TENSION DETECTION ═══
    td = _TensionDetector(n, graph_edges, graph_weights)
    raw_tensions = td.tensions(top_k)

    tensions = []
    for d, i, j, score in raw_tensions:
        tensions.append({
            'entity_a': entity_list[i],
            'entity_b': entity_list[j],
            'tension': round(score, 3),
            'spectral_distance': round(d, 4),
            'note': 'Spectrally close but no direct transactions — potential hidden relationship',
        })

    # ═══ CIRCULAR FLOW DETECTION ═══
    # Money that goes A→B→C→A is potential wash trading or layering
    circular = []
    for a in entity_list:
        for b in entity_list:
            if a == b:
                continue
            if (a, b) in edges and (b, a) in edges:
                forward = edges[(a, b)]
                backward = edges[(b, a)]
                ratio = min(forward, backward) / max(forward, backward) if max(forward, backward) > 0 else 0
                if ratio > 0.25:  # more than 25% flows back = suspicious
                    circular.append({
                        'entity_a': a,
                        'entity_b': b,
                        'forward': round(forward, 2),
                        'backward': round(backward, 2),
                        'ratio': round(ratio, 3),
                        'flag': 'HIGH' if ratio > 0.9 else 'MEDIUM',
                        'note': 'Bidirectional flow — potential wash trading or structuring',
                    })

    # 3-hop circles: A→B→C→A
    for a in entity_list:
        for b in entity_list:
            if a == b:
                continue
            if (a, b) not in edges:
                continue
            for c in entity_list:
                if c in (a, b):
                    continue
                if (b, c) in edges and (c, a) in edges:
                    total_flow = min(edges[(a, b)], edges[(b, c)], edges[(c, a)])
                    if total_flow > 0:
                        circular.append({
                            'path': f'{a} → {b} → {c} → {a}',
                            'min_flow': round(total_flow, 2),
                            'flag': 'HIGH',
                            'note': 'Triangular flow — classic layering pattern',
                        })

    # Ponzi pattern: entity receives from many AND sends back to those same senders
    # (regardless of amount ratio — Ponzi returns are typically 5-15% of investment)
    for entity in entity_list:
        senders_to_entity = set()
        receivers_from_entity = set()
        for (a, b) in edges:
            if b == entity:
                senders_to_entity.add(a)
            if a == entity:
                receivers_from_entity.add(b)
        # Entity receives from N senders and sends back to M of them
        return_recipients = senders_to_entity & receivers_from_entity
        if len(senders_to_entity) >= 3 and len(return_recipients) >= 2:
            total_in = sum(edges.get((s, entity), 0) for s in senders_to_entity)
            total_out = sum(edges.get((entity, r), 0) for r in return_recipients)
            if total_in > 0 and total_out > 0:
                circular.append({
                    'entity_a': entity,
                    'entity_b': f'{len(return_recipients)} return recipients',
                    'forward': round(total_in, 2),
                    'backward': round(total_out, 2),
                    'ratio': round(total_out / total_in, 3),
                    'flag': 'HIGH',
                    'note': f'Ponzi pattern: receives from {len(senders_to_entity)}, returns to {len(return_recipients)} of same senders',
                })

    # Deduplicate circular (A↔B and B↔A are the same)
    seen_circular = set()
    unique_circular = []
    for c in circular:
        if 'path' in c:
            key = c['path']
        else:
            key = tuple(sorted([c['entity_a'], c['entity_b']]))
        if key not in seen_circular:
            seen_circular.add(key)
            unique_circular.append(c)
    circular = unique_circular

    # ═══ ANOMALOUS AMOUNTS ═══
    all_amounts = [tx.get('amount', 0) for tx in transactions if tx.get('amount', 0) > 0]
    if len(all_amounts) > 5:
        mean_amt = np.mean(all_amounts)
        std_amt = np.std(all_amounts)
        anomalous_amounts = []
        for tx in transactions:
            amt = tx.get('amount', 0)
            if std_amt > 0 and abs(amt - mean_amt) > 3 * std_amt:
                anomalous_amounts.append({
                    'from': tx.get('from', tx.get('sender', '')),
                    'to': tx.get('to', tx.get('receiver', '')),
                    'amount': amt,
                    'zscore': round((amt - mean_amt) / std_amt, 2),
                    'note': 'Amount >3 standard deviations from mean',
                })
    else:
        anomalous_amounts = []

    # ═══ LAYERING / CHAIN DETECTION ═══
    # Long chains (A→B→C→D→...) are suspicious — legitimate business rarely has 4+ hops.
    # This catches shell company layering and structuring.
    chains = []
    # Build adjacency: who does each entity send to?
    sends_to = {}
    for (a, b) in edges:
        if a not in sends_to:
            sends_to[a] = []
        sends_to[a].append(b)

    # Find longest chain from each entity using BFS (no revisits)
    for start in entity_list:
        visited = {start}
        queue = [(start, [start])]
        longest = [start]
        while queue:
            current, path = queue.pop(0)
            for nxt in sends_to.get(current, []):
                if nxt not in visited:
                    visited.add(nxt)
                    new_path = path + [nxt]
                    if len(new_path) > len(longest):
                        longest = new_path
                    queue.append((nxt, new_path))
        if len(longest) >= 4:  # 4+ hops = layering risk
            chains.append({
                'path': ' → '.join(longest),
                'hops': len(longest) - 1,
                'note': f'{len(longest)-1}-hop chain — potential layering or structuring',
            })

    # Deduplicate chains (A→B→C→D contains B→C→D)
    # Keep only the longest chain that contains each sub-chain
    if chains:
        chains.sort(key=lambda c: -c['hops'])
        unique_chains = []
        seen_edges = set()
        for c in chains:
            path_str = c['path']
            if path_str not in seen_edges:
                unique_chains.append(c)
                seen_edges.add(path_str)
        chains = unique_chains[:10]

    # ═══ CONCENTRATION RISK ═══
    # Entities that handle disproportionate volume
    total_volume = sum(all_amounts)
    concentration = []
    for e in entity_list:
        vol = entity_sent[e] + entity_received[e]
        pct = vol / (total_volume * 2) * 100 if total_volume > 0 else 0  # *2 because each tx counted twice
        if pct > 25:  # more than 25% of all flow
            concentration.append({
                'entity': e,
                'volume': round(vol, 2),
                'pct_of_total': round(pct, 1),
                'sent': round(entity_sent[e], 2),
                'received': round(entity_received[e], 2),
                'note': 'Handles >25% of total flow — concentration risk',
            })

    # ═══ NET FLOW ANALYSIS ═══
    net_flow = {}
    for e in entity_list:
        net = entity_received[e] - entity_sent[e]
        net_flow[e] = {
            'entity': e,
            'sent': round(entity_sent[e], 2),
            'received': round(entity_received[e], 2),
            'net': round(net, 2),
            'role': 'net_receiver' if net > 0 else 'net_sender' if net < 0 else 'neutral',
        }

    # ═══ SPECTRAL ANOMALY DETECTION — find what you haven't seen ═══
    # The spectral coordinates ARE the structure. Entities that don't fit
    # the structure stand out — not because they match a known pattern,
    # but because they're in the wrong place in spectral space.
    spectral_anomalies = []
    if hasattr(td, 'coords') and td.coords is not None and len(td.coords) > 3:
        coords = td.coords
        # 1. Spectral outliers — entities far from any cluster center
        center = np.mean(coords, axis=0)
        dists_from_center = np.array([float(np.linalg.norm(coords[i] - center)) for i in range(n)])
        median_dist = np.median(dists_from_center)
        std_dist = np.std(dists_from_center)
        for i in range(n):
            if dists_from_center[i] > median_dist + 2.5 * std_dist:
                spectral_anomalies.append({
                    'entity': entity_list[i],
                    'type': 'spectral_outlier',
                    'distance': round(float(dists_from_center[i]), 4),
                    'threshold': round(float(median_dist + 2.5 * std_dist), 4),
                    'note': 'Structurally isolated in spectral space — doesn\'t fit the transaction topology',
                })

        # 2. Spectral density anomalies — entities in sparse regions
        # (normal entities cluster; weird ones float alone)
        for i in range(n):
            neighbors_in_range = sum(1 for j in range(n) if j != i and
                                     np.linalg.norm(coords[i] - coords[j]) < median_dist * 0.5)
            expected_neighbors = max(1, n * 0.15)  # expect at least 15% of entities nearby
            if neighbors_in_range < expected_neighbors * 0.3 and n > 10:
                # This entity is in a spectral desert — structurally alone
                if not any(a['entity'] == entity_list[i] for a in spectral_anomalies):
                    spectral_anomalies.append({
                        'entity': entity_list[i],
                        'type': 'spectral_desert',
                        'neighbors': neighbors_in_range,
                        'expected': round(expected_neighbors, 1),
                        'note': 'Few spectral neighbors — transaction pattern unlike any other entity',
                    })

        # 3. Spectral displacement — entities whose spectral position doesn't
        # match their transaction volume (high volume should be central, not peripheral)
        volumes = np.array([entity_sent[entity_list[i]] + entity_received[entity_list[i]] for i in range(n)])
        if np.std(volumes) > 0 and np.std(dists_from_center) > 0:
            # Normalize both to [0,1]
            vol_norm = (volumes - volumes.min()) / (volumes.max() - volumes.min() + 1e-12)
            dist_norm = (dists_from_center - dists_from_center.min()) / (dists_from_center.max() - dists_from_center.min() + 1e-12)
            # High volume + high distance = suspicious (should be central but isn't)
            for i in range(n):
                if vol_norm[i] > 0.7 and dist_norm[i] > 0.7:
                    if not any(a['entity'] == entity_list[i] for a in spectral_anomalies):
                        spectral_anomalies.append({
                            'entity': entity_list[i],
                            'type': 'displaced',
                            'volume_percentile': round(float(vol_norm[i] * 100), 1),
                            'distance_percentile': round(float(dist_norm[i] * 100), 1),
                            'note': 'High transaction volume but structurally peripheral — operating outside the main network',
                        })

    # ═══ RISK SCORE ═══
    risk = 0
    flags = []

    if circular:
        risk += min(40, len(circular) * 10)
        # Large circular flows are worse than small ones
        max_circular = max((c.get('forward', 0) + c.get('backward', 0)) for c in circular
                          if 'forward' in c) if any('forward' in c for c in circular) else 0
        if max_circular > 1_000_000:
            risk += 10
        flags.append(f'{len(circular)} circular flow pattern(s) detected')

    if chains:
        # Long chains are a strong layering signal
        max_hops = max(c['hops'] for c in chains)
        risk += min(30, max_hops * 5 + len(chains) * 3)
        flags.append(f'{len(chains)} long chain(s) detected (max {max_hops} hops) — potential layering')

    if anomalous_amounts:
        risk += min(20, len(anomalous_amounts) * 5)
        flags.append(f'{len(anomalous_amounts)} anomalous amount(s) (>3σ)')

    if concentration:
        has_fraud_signals = len(circular) > 0 or len(chains) > 0

        # Check for FUNNEL pattern: many unique senders → one hub
        # This is suspicious at scale regardless of circular flows.
        # Payroll (20 employees) is different from 30 shell companies
        # because shell patterns have diverse entity names + high individual amounts.
        for c in concentration:
            entity = c['entity']
            n_unique_senders = sum(1 for (a, b) in edges if b == entity and a != entity)
            n_unique_receivers = sum(1 for (a, b) in edges if a == entity and b != entity)
            if n_unique_senders >= 10 and n_unique_receivers >= 2:
                # Many-to-one-to-few funnel = layering risk
                has_fraud_signals = True
                break

        if has_fraud_signals:
            risk += min(25, len(concentration) * 10)
            extreme = [c for c in concentration if c['pct_of_total'] > 40]
            if extreme:
                risk += 10
                flags.append(f'{len(extreme)} entity(ies) with extreme flow concentration (>40%) + fraud signals')
            else:
                flags.append(f'{len(concentration)} entity(ies) with >25% flow concentration + fraud signals')
        else:
            # Small hub-spoke (payroll, e-commerce, VC fund) = low risk
            risk += min(5, len(concentration) * 2)
            flags.append(f'{len(concentration)} concentrated entity(ies) — hub-spoke topology (no fraud signals)')

    if tensions:
        high_tension = [t for t in tensions if t['tension'] > 2.0]
        if high_tension and len(high_tension) <= n * 0.3:
            # Only flag if tensions are concentrated (not when everyone has tensions with everyone)
            risk += min(15, len(high_tension) * 3)
            flags.append(f'{len(high_tension)} high-tension hidden relationship(s)')
        elif len(tensions) > n * 2 and not circular:
            # Many tensions + no circular = probably normal (hub-spoke payroll etc)
            pass
        elif len(tensions) > 5:
            risk += 5
            flags.append(f'{len(tensions)} spectral tensions detected')

    # Spectral anomalies add to risk — but only when combined with other signals.
    # Hub-spoke topologies naturally create spectral deserts for leaf nodes.
    if spectral_anomalies:
        has_fraud_signals = len(circular) > 0 or len(chains) > 0
        # Filter: only count non-desert anomalies, or deserts with circular flows
        relevant_anomalies = [a for a in spectral_anomalies
                              if a.get('type') != 'spectral_desert' or has_fraud_signals]
        if relevant_anomalies:
            risk += min(20, len(relevant_anomalies) * 5)
            flags.append(f'{len(relevant_anomalies)} spectral anomaly(ies) — entities that don\'t fit the network structure')

    # Landauer energy of the entire transaction set
    total_bits = sum(64 + int(np.ceil(np.log2(max(abs(a), 2)))) * 2 for a in all_amounts)
    total_energy = total_bits * LANDAUER_PER_BIT

    risk = min(100, risk)

    # ═══ SPECTRAL POSITIONS ═══
    try:
        positions = spectral_place(n, graph_edges, 800, 600, graph_weights)
        pos_dict = {entity_list[i]: [round(float(positions[i][0]), 1),
                                       round(float(positions[i][1]), 1)]
                     for i in range(n)}
    except Exception:
        pos_dict = {}

    # ═══ CLUSTERS ═══
    try:
        labels, k = td.clusters()
        clusters = []
        for c in range(k):
            members = [entity_list[i] for i in range(n) if labels[i] == c]
            if members:
                clusters.append(members)
    except Exception:
        clusters = [entity_list]

    # ═══ HUMAN-READABLE REPORT ═══
    report_lines = [f'TRACE ANALYSIS — {n} entities, {len(transactions)} transactions']
    report_lines.append(f'Risk score: {risk}/100')
    if risk < 20:
        report_lines.append('Assessment: LOW RISK — no significant anomalies detected.')
    elif risk < 50:
        report_lines.append('Assessment: MODERATE RISK — some patterns warrant review.')
    elif risk < 75:
        report_lines.append('Assessment: HIGH RISK — multiple suspicious patterns detected.')
    else:
        report_lines.append('Assessment: CRITICAL — significant forensic findings.')
    report_lines.append('')
    for f in flags:
        report_lines.append(f'  ⚠ {f}')
    if not flags:
        report_lines.append('  No flags raised.')
    report_lines.append('')
    if circular:
        report_lines.append('CIRCULAR FLOWS:')
        for c in circular[:5]:
            if 'path' in c:
                report_lines.append(f'  [{c["flag"]}] {c["path"]} (min flow: {c["min_flow"]})')
            else:
                report_lines.append(f'  [{c["flag"]}] {c["entity_a"]} ↔ {c["entity_b"]} '
                                    f'(forward: {c["forward"]}, back: {c["backward"]}, ratio: {c["ratio"]})')
    if anomalous_amounts:
        report_lines.append('ANOMALOUS AMOUNTS:')
        for a in anomalous_amounts[:5]:
            report_lines.append(f'  {a["from"]} → {a["to"]}: {a["amount"]} (z={a["zscore"]})')
    if tensions[:3]:
        report_lines.append('HIDDEN RELATIONSHIPS (spectral tension):')
        for t in tensions[:3]:
            report_lines.append(f'  {t["entity_a"]} ↔ {t["entity_b"]} (tension: {t["tension"]})')

    return {
        'risk_score': risk,
        'flags': flags,
        'tensions': tensions,
        'circular_flows': circular,
        'chains': chains,
        'anomalous_amounts': anomalous_amounts,
        'concentration': concentration,
        'spectral_anomalies': spectral_anomalies,
        'net_flow': net_flow,
        'clusters': clusters,
        'positions': pos_dict,
        'stats': {
            'entities': n,
            'transactions': len(transactions),
            'total_volume': round(total_volume, 2),
            'total_energy_J': total_energy,
            'total_bits': total_bits,
        },
        'report': '\n'.join(report_lines),
    }


def scan_csv(filepath_or_text, has_header=True):
    """Scan from CSV. Format: from,to,amount[,date][,memo] per line."""
    import os
    if os.path.isfile(filepath_or_text):
        with open(filepath_or_text, encoding='utf-8', errors='ignore') as f:
            text = f.read()
    else:
        text = filepath_or_text

    lines = text.strip().split('\n')
    if has_header and len(lines) > 1:
        lines = lines[1:]

    transactions = []
    for line in lines:
        parts = [p.strip() for p in line.split(',')]
        if len(parts) >= 3:
            try:
                tx = {
                    'from': parts[0],
                    'to': parts[1],
                    'amount': float(parts[2]),
                }
                if len(parts) >= 4:
                    tx['date'] = parts[3]
                if len(parts) >= 5:
                    tx['memo'] = parts[4]
                transactions.append(tx)
            except (ValueError, IndexError):
                continue

    if not transactions:
        return {'error': 'No valid transactions found in CSV'}

    return scan(transactions)


def visualize(result):
    """Generate interactive HTML forensic report — Chainalysis Reactor style."""
    if 'error' in result:
        return f'<html><body style="background:#08080d;color:#e8e4dc;padding:40px;font-family:Georgia,serif"><h1>Error</h1><p>{result["error"]}</p></body></html>'

    stats = result.get('stats', {})
    risk = result.get('risk_score', 0)
    risk_color = '#c44' if risk >= 50 else '#c94' if risk >= 20 else '#4a9'
    risk_label = 'CRITICAL' if risk >= 75 else 'HIGH' if risk >= 50 else 'MODERATE' if risk >= 20 else 'LOW'
    data_json = json.dumps(result, default=str)

    # Pre-build alert queue with severity
    alerts = []
    for c in result.get('circular_flows', []):
        sev = c.get('flag', 'MEDIUM')
        if 'path' in c:
            alerts.append({'severity': sev, 'text': f'Triangular flow: {c["path"]} (min: ${c["min_flow"]:,.0f})', 'type': 'circular', 'entities': c['path'].replace(' → ', ',').split(',')})
        else:
            alerts.append({'severity': sev, 'text': f'Bidirectional: {c["entity_a"]} ↔ {c["entity_b"]} (ratio: {c["ratio"]})', 'type': 'circular', 'entities': [c['entity_a'], c['entity_b']]})
    for a in result.get('anomalous_amounts', []):
        alerts.append({'severity': 'HIGH' if abs(a.get('zscore', 0)) > 5 else 'MEDIUM', 'text': f'Anomalous: {a["from"]} → {a["to"]}: ${a["amount"]:,.0f} (z={a["zscore"]})', 'type': 'anomalous', 'entities': [a['from'], a['to']]})
    for c in result.get('concentration', []):
        alerts.append({'severity': 'HIGH' if c['pct_of_total'] > 40 else 'MEDIUM', 'text': f'Concentration: {c["entity"]} handles {c["pct_of_total"]}% of flow', 'type': 'concentration', 'entities': [c['entity']]})
    for t in result.get('tensions', []):
        if t['tension'] > 2.0:
            alerts.append({'severity': 'MEDIUM', 'text': f'Hidden link: {t["entity_a"]} ↔ {t["entity_b"]} (tension: {t["tension"]})', 'type': 'tension', 'entities': [t['entity_a'], t['entity_b']]})
    for f in result.get('flags', []):
        if not any(f in a['text'] for a in alerts):
            alerts.append({'severity': 'LOW', 'text': f, 'type': 'flag', 'entities': []})

    sev_order = {'HIGH': 0, 'MEDIUM': 1, 'LOW': 2}
    alerts.sort(key=lambda a: sev_order.get(a['severity'], 9))
    alerts_json = json.dumps(alerts, default=str)

    # Build edges JSON for JS (from result's raw data embedded in positions + net_flow)
    # We reconstruct edges from circular_flows and tensions. For full edges we embed them.
    edges_for_js = []
    # We need actual edge data. Reconstruct from the scan data embedded in result.
    # The result doesn't directly store edges, but we can infer from circular_flows and net_flow.
    # Better: embed edges in scan output. For now, we pass what we have.

    total_vol = stats.get('total_volume', 0)
    n_entities = stats.get('entities', 0)
    n_tx = stats.get('transactions', 0)
    avg_tx = total_vol / n_tx if n_tx > 0 else 0

    # Determine net flow direction
    nf = result.get('net_flow', {})
    senders = sum(1 for v in nf.values() if isinstance(v, dict) and v.get('role') == 'net_sender')
    receivers = sum(1 for v in nf.values() if isinstance(v, dict) and v.get('role') == 'net_receiver')

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Trace — Spectral Forensics</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:#08080d;color:#e8e4dc;font-family:'SF Pro Text',system-ui,Georgia,serif;display:flex;height:100vh;overflow:hidden}}
#canvas-wrap{{flex:1;position:relative}}
canvas{{display:block;width:100%;height:100%;cursor:crosshair}}
#tooltip{{position:absolute;display:none;background:#0d0d14ee;border:1px solid #c9a44a40;border-radius:8px;padding:12px 16px;font-size:12px;pointer-events:none;max-width:280px;backdrop-filter:blur(8px);z-index:10;box-shadow:0 8px 32px #00000080}}
#tooltip .tt-name{{color:#c9a44a;font-size:14px;font-weight:600;margin-bottom:6px}}
#tooltip .tt-row{{display:flex;justify-content:space-between;gap:16px;padding:2px 0;color:#888}}
#tooltip .tt-row span:last-child{{color:#e8e4dc}}
#legend{{position:absolute;bottom:16px;left:16px;background:#0d0d14dd;border:1px solid #ffffff0a;border-radius:8px;padding:12px 16px;font-size:11px;backdrop-filter:blur(8px)}}
#legend .lg-title{{color:#c9a44a;font-size:10px;letter-spacing:0.15em;margin-bottom:8px;text-transform:uppercase}}
#legend .lg-row{{display:flex;align-items:center;gap:8px;padding:2px 0;color:#888}}
#legend .lg-dot{{width:10px;height:10px;border-radius:50%;flex-shrink:0}}
#legend .lg-line{{width:20px;height:0;border-top:2px solid;flex-shrink:0}}
#panel{{width:380px;background:#0d0d14;border-left:1px solid #ffffff08;display:flex;flex-direction:column;overflow:hidden}}
.panel-header{{padding:20px 20px 0}}
h1{{font-size:1.3em;font-weight:200;color:#c9a44a;letter-spacing:0.12em}}
.sub{{font-size:0.6em;color:#444;letter-spacing:0.18em;margin-bottom:12px}}
.risk-wrap{{text-align:center;margin:8px 0 4px}}
.risk-num{{font-size:2.6em;font-weight:100;color:{risk_color};line-height:1}}
.risk-label{{font-size:0.65em;letter-spacing:0.2em;color:{risk_color};opacity:0.8}}
.risk-bar{{height:3px;background:#ffffff08;border-radius:2px;margin:8px 0 16px}}
.risk-fill{{height:100%;width:{risk}%;background:linear-gradient(90deg,{risk_color},{risk_color}aa);border-radius:2px;transition:width 0.6s}}
.tabs{{display:flex;border-bottom:1px solid #ffffff0a;padding:0 20px}}
.tab{{flex:1;text-align:center;padding:10px 4px;font-size:0.68em;letter-spacing:0.1em;color:#555;cursor:pointer;border-bottom:2px solid transparent;transition:all 0.2s;text-transform:uppercase}}
.tab:hover{{color:#888}}
.tab.active{{color:#c9a44a;border-bottom-color:#c9a44a}}
.tab-body{{flex:1;overflow-y:auto;padding:16px 20px}}
.tab-content{{display:none}}
.tab-content.active{{display:block}}
.stat-row{{display:flex;justify-content:space-between;font-size:0.76em;color:#666;padding:5px 0;border-bottom:1px solid #ffffff04}}
.stat-row span:last-child{{color:#c9a44a;font-weight:500}}
.section-title{{font-size:0.7em;color:#c9a44a;letter-spacing:0.12em;margin:16px 0 8px;text-transform:uppercase}}
.alert-item{{display:flex;align-items:flex-start;gap:8px;padding:8px 10px;margin:4px 0;border-radius:6px;background:#0a0a12;border-left:3px solid #444;cursor:pointer;transition:all 0.15s;font-size:0.72em}}
.alert-item:hover{{background:#12121e;transform:translateX(2px)}}
.alert-item[data-sev="HIGH"]{{border-left-color:#c44;background:#1a0d0d}}
.alert-item[data-sev="MEDIUM"]{{border-left-color:#c9a44a;background:#14120d}}
.alert-item[data-sev="LOW"]{{border-left-color:#4a9;background:#0d1410}}
.sev-badge{{font-size:9px;font-weight:700;letter-spacing:0.08em;padding:2px 6px;border-radius:3px;flex-shrink:0;margin-top:1px}}
.sev-badge.HIGH{{background:#c4433a;color:#fff}}
.sev-badge.MEDIUM{{background:#c9a44a;color:#08080d}}
.sev-badge.LOW{{background:#4a9;color:#08080d}}
.alert-text{{color:#aaa;line-height:1.4}}
.flow-table{{width:100%;border-collapse:collapse;font-size:0.7em}}
.flow-table th{{text-align:left;color:#c9a44a;font-weight:400;padding:6px 4px;border-bottom:1px solid #ffffff0a;font-size:0.9em;letter-spacing:0.08em}}
.flow-table td{{padding:5px 4px;border-bottom:1px solid #ffffff04;color:#888}}
.flow-table td.num{{text-align:right;font-variant-numeric:tabular-nums}}
.flow-table tr:hover td{{color:#e8e4dc}}
.flow-table .pos{{color:#4a9}}.flow-table .neg{{color:#c94}}
.tension-card{{padding:8px 10px;margin:4px 0;border-radius:6px;background:#0a0a12;border-left:3px solid #c9a44a30;cursor:pointer;transition:all 0.15s;font-size:0.72em}}
.tension-card:hover{{background:#12121e;border-left-color:#c9a44a}}
.tension-card .tc-pair{{color:#c9a44a;margin-bottom:2px}}
.tension-card .tc-detail{{color:#666}}
@media(max-width:768px){{body{{flex-direction:column}}#panel{{width:100%;height:50vh}}}}
</style>
</head>
<body>
<div id="canvas-wrap">
  <canvas id="graph"></canvas>
  <div id="tooltip"></div>
  <div id="legend">
    <div class="lg-title">Legend</div>
    <div class="lg-row"><div class="lg-dot" style="background:#4a9"></div> Net receiver</div>
    <div class="lg-row"><div class="lg-dot" style="background:#c94"></div> Net sender</div>
    <div class="lg-row"><div class="lg-dot" style="background:#c44;box-shadow:0 0 6px #c44"></div> Circular flow entity</div>
    <div class="lg-row"><div class="lg-dot" style="background:#888;border:2px solid #c9a44a"></div> Concentration risk</div>
    <div class="lg-row"><div class="lg-line" style="border-color:#4a9"></div> Normal flow</div>
    <div class="lg-row"><div class="lg-line" style="border-color:#c9a44a"></div> Tension (hidden link)</div>
    <div class="lg-row"><div class="lg-line" style="border-color:#c44"></div> Circular flow</div>
    <div class="lg-row" style="color:#666;font-style:italic;margin-top:4px">Arrow thickness = volume</div>
  </div>
</div>
<div id="panel">
  <div class="panel-header">
    <h1>Trace</h1>
    <div class="sub">GUMP &middot; spectral forensics</div>
    <div class="risk-wrap">
      <div class="risk-num">{risk}</div>
      <div class="risk-label">{risk_label} RISK</div>
    </div>
    <div class="risk-bar"><div class="risk-fill"></div></div>
  </div>
  <div class="tabs">
    <div class="tab active" data-tab="overview">Overview</div>
    <div class="tab" data-tab="alerts">Alerts</div>
    <div class="tab" data-tab="flows">Flows</div>
    <div class="tab" data-tab="tensions">Tensions</div>
  </div>
  <div class="tab-body">
    <div class="tab-content active" id="tc-overview">
      <div class="section-title">Flow Summary</div>
      <div class="stat-row"><span>Total volume</span><span>${total_vol:,.2f}</span></div>
      <div class="stat-row"><span>Transactions</span><span>{n_tx:,}</span></div>
      <div class="stat-row"><span>Avg transaction</span><span>${avg_tx:,.2f}</span></div>
      <div class="stat-row"><span>Entities</span><span>{n_entities}</span></div>
      <div class="stat-row"><span>Clusters</span><span>{len(result.get('clusters', []))}</span></div>
      <div class="stat-row"><span>Net senders</span><span>{senders}</span></div>
      <div class="stat-row"><span>Net receivers</span><span>{receivers}</span></div>
      <div class="stat-row"><span>Circular patterns</span><span>{len(result.get('circular_flows', []))}</span></div>
      <div class="stat-row"><span>Anomalous amounts</span><span>{len(result.get('anomalous_amounts', []))}</span></div>
      <div class="stat-row"><span>Hidden relationships</span><span>{len(result.get('tensions', []))}</span></div>
      <div class="section-title">Concentration Risk</div>
      <div id="conc-list"></div>
      <div class="section-title">Spectral Energy</div>
      <div class="stat-row"><span>Information bits</span><span>{stats.get('total_bits', 0):,}</span></div>
      <div class="stat-row"><span>Landauer energy</span><span>{stats.get('total_energy_J', 0):.2e} J</span></div>
    </div>
    <div class="tab-content" id="tc-alerts">
      <div class="section-title">Prioritized Alert Queue</div>
      <div id="alert-list"></div>
    </div>
    <div class="tab-content" id="tc-flows">
      <div class="section-title">Entity Flow Table</div>
      <table class="flow-table">
        <thead><tr><th>Entity</th><th style="text-align:right">Sent</th><th style="text-align:right">Recv</th><th style="text-align:right">Net</th></tr></thead>
        <tbody id="flow-tbody"></tbody>
      </table>
    </div>
    <div class="tab-content" id="tc-tensions">
      <div class="section-title">Hidden Relationships</div>
      <div id="tension-list"></div>
    </div>
  </div>
</div>
<script>
var DATA={data_json};
var ALERTS={alerts_json};
var cv=document.getElementById('graph'),cx=cv.getContext('2d'),wrap=document.getElementById('canvas-wrap');
var dpr=window.devicePixelRatio||1;
var hoverNode=null,highlightEntities=null,mouseX=0,mouseY=0;

function resize(){{var r=wrap.getBoundingClientRect();cv.width=r.width*dpr;cv.height=r.height*dpr;cx.setTransform(dpr,0,0,dpr,0,0);}}
resize();window.addEventListener('resize',function(){{resize();draw();}});
var W=function(){{return cv.width/dpr}},H=function(){{return cv.height/dpr}};

// Build sets for quick lookup
var circularEntities=new Set();
(DATA.circular_flows||[]).forEach(function(c){{
  if(c.entity_a)circularEntities.add(c.entity_a);
  if(c.entity_b)circularEntities.add(c.entity_b);
  if(c.path)c.path.split(' \\u2192 ').forEach(function(e){{circularEntities.add(e.trim())}});
}});
var concEntities=new Set();
(DATA.concentration||[]).forEach(function(c){{concEntities.add(c.entity)}});

// Build edge list from net_flow pairs: we reconstruct from circular + infer from positions
// Actually reconstruct all directed edges from the data we have
var allEdges=[];
// From circular_flows we know bidirectional pairs
(DATA.circular_flows||[]).forEach(function(c){{
  if(c.entity_a&&c.entity_b&&c.forward!==undefined){{
    allEdges.push({{from:c.entity_a,to:c.entity_b,amount:c.forward,circular:true}});
    allEdges.push({{from:c.entity_b,to:c.entity_a,amount:c.backward,circular:true}});
  }}
}});

// Build inferred edges from net_flow (for entities not in circular)
// We create edges proportional to sent/received for visualization
var nf=DATA.net_flow||{{}};
var entities=Object.keys(DATA.positions||{{}});
// We need real edge data. Since it's not in the result, we'll draw flows based on what we have.
// For a production version, edges should be in the result dict.

function mp(name){{
  var pos=DATA.positions||{{}};var p=pos[name];if(!p)return null;
  var w=W(),h=H(),m=80;
  return[m+(p[0]/800)*(w-2*m),m+(p[1]/600)*(h-2*m)];
}}

function nodeRadius(name){{
  var nf=DATA.net_flow[name]||{{}};
  var vol=(nf.sent||0)+(nf.received||0);
  var maxVol=0;entities.forEach(function(e){{var n=DATA.net_flow[e]||{{}};var v=(n.sent||0)+(n.received||0);if(v>maxVol)maxVol=v}});
  var norm=maxVol>0?vol/maxVol:0;
  return Math.max(6,norm*28+6);
}}

function nodeColor(name){{
  if(circularEntities.has(name))return'#c44';
  var nf=DATA.net_flow[name]||{{}};
  return nf.role==='net_receiver'?'#4a9':nf.role==='net_sender'?'#c94':'#888';
}}

function drawArrow(x1,y1,x2,y2,thickness,color,dashed){{
  var dx=x2-x1,dy=y2-y1,len=Math.sqrt(dx*dx+dy*dy);
  if(len<1)return;
  var ux=dx/len,uy=dy/len;
  // Shorten to not overlap nodes
  var r1=nodeRadius(hoverNode)||8,r2=8;
  // Find which entity is at each end for proper radius
  entities.forEach(function(e){{var p=mp(e);if(p&&Math.abs(p[0]-x1)<2&&Math.abs(p[1]-y1)<2)r1=nodeRadius(e);if(p&&Math.abs(p[0]-x2)<2&&Math.abs(p[1]-y2)<2)r2=nodeRadius(e);}});
  var sx=x1+ux*(r1+4),sy=y1+uy*(r1+4);
  var ex=x2-ux*(r2+8),ey=y2-uy*(r2+8);
  cx.save();
  if(dashed)cx.setLineDash([6,4]);
  cx.strokeStyle=color;cx.lineWidth=thickness;cx.lineCap='round';
  cx.beginPath();cx.moveTo(sx,sy);cx.lineTo(ex,ey);cx.stroke();
  if(dashed)cx.setLineDash([]);
  // Arrowhead
  var headLen=Math.min(12,thickness*4+6);
  var angle=Math.atan2(ey-sy,ex-sx);
  cx.fillStyle=color;
  cx.beginPath();
  cx.moveTo(ex,ey);
  cx.lineTo(ex-headLen*Math.cos(angle-0.35),ey-headLen*Math.sin(angle-0.35));
  cx.lineTo(ex-headLen*Math.cos(angle+0.35),ey-headLen*Math.sin(angle+0.35));
  cx.closePath();cx.fill();
  cx.restore();
}}

function draw(){{
  var w=W(),h=H();cx.clearRect(0,0,w,h);
  var pos=DATA.positions||{{}};entities=Object.keys(pos);
  if(!entities.length)return;

  // Compute max edge amount for thickness scaling
  var maxAmt=1;
  allEdges.forEach(function(e){{if(e.amount>maxAmt)maxAmt=e.amount}});
  // Also consider net_flow for the general edges
  entities.forEach(function(e){{var n=DATA.net_flow[e]||{{}};if((n.sent||0)>maxAmt)maxAmt=n.sent}});

  // Draw tension lines (dashed gold)
  (DATA.tensions||[]).forEach(function(t){{
    var a=mp(t.entity_a),b=mp(t.entity_b);
    if(!a||!b)return;
    var alpha=highlightEntities?((highlightEntities.has(t.entity_a)&&highlightEntities.has(t.entity_b))?0.6:0.06):0.2;
    drawArrow(a[0],a[1],b[0],b[1],1,'rgba(201,164,74,'+alpha+')',true);
  }});

  // Draw circular flow edges (red, with arrows both ways)
  allEdges.forEach(function(e){{
    var a=mp(e.from),b=mp(e.to);
    if(!a||!b)return;
    var thick=Math.max(1.5,Math.min(8,(e.amount/maxAmt)*8));
    var alpha=highlightEntities?((highlightEntities.has(e.from)||highlightEntities.has(e.to))?0.9:0.08):0.6;
    var col=e.circular?'rgba(200,70,70,'+alpha+')':'rgba(90,180,130,'+alpha+')';
    drawArrow(a[0],a[1],b[0],b[1],thick,col,false);
  }});

  // Draw implied flow edges for non-circular entities (green arrows based on net_flow)
  // We draw from senders to receivers with thickness proportional to volume
  var senderList=[],receiverList=[];
  entities.forEach(function(e){{
    var n=DATA.net_flow[e]||{{}};
    if(n.role==='net_sender')senderList.push(e);
    else if(n.role==='net_receiver')receiverList.push(e);
  }});
  // Only draw implied edges if we have no explicit edges for these entities
  var explicitNodes=new Set();
  allEdges.forEach(function(e){{explicitNodes.add(e.from);explicitNodes.add(e.to)}});

  // Draw cluster backgrounds
  (DATA.clusters||[]).forEach(function(cluster,ci){{
    if(cluster.length<2)return;
    var pts=cluster.map(function(e){{return mp(e)}}).filter(function(p){{return p}});
    if(pts.length<2)return;
    var cx2=0,cy2=0;pts.forEach(function(p){{cx2+=p[0];cy2+=p[1]}});
    cx2/=pts.length;cy2/=pts.length;
    var maxR=0;pts.forEach(function(p){{var d=Math.sqrt((p[0]-cx2)*(p[0]-cx2)+(p[1]-cy2)*(p[1]-cy2));if(d>maxR)maxR=d}});
    cx.fillStyle='rgba(201,164,74,0.02)';
    cx.beginPath();cx.arc(cx2,cy2,maxR+30,0,Math.PI*2);cx.fill();
    cx.strokeStyle='rgba(201,164,74,0.06)';cx.lineWidth=1;
    cx.beginPath();cx.arc(cx2,cy2,maxR+30,0,Math.PI*2);cx.stroke();
  }});

  // Draw nodes
  entities.forEach(function(name){{
    var p=mp(name);if(!p)return;
    var r=nodeRadius(name);
    var color=nodeColor(name);
    var isHighlighted=!highlightEntities||highlightEntities.has(name);
    var alpha=isHighlighted?1:0.15;

    // Glow for circular entities
    if(circularEntities.has(name)&&isHighlighted){{
      var grd=cx.createRadialGradient(p[0],p[1],r,p[0],p[1],r*3);
      grd.addColorStop(0,'rgba(200,70,70,0.3)');grd.addColorStop(1,'rgba(200,70,70,0)');
      cx.fillStyle=grd;cx.beginPath();cx.arc(p[0],p[1],r*3,0,Math.PI*2);cx.fill();
    }}

    // Concentration ring
    if(concEntities.has(name)&&isHighlighted){{
      cx.strokeStyle='#c9a44a';cx.lineWidth=2;
      cx.beginPath();cx.arc(p[0],p[1],r+4,0,Math.PI*2);cx.stroke();
      cx.strokeStyle='rgba(201,164,74,0.3)';cx.lineWidth=1;
      cx.beginPath();cx.arc(p[0],p[1],r+8,0,Math.PI*2);cx.stroke();
    }}

    // Node fill
    cx.globalAlpha=alpha;
    cx.fillStyle=color;cx.beginPath();cx.arc(p[0],p[1],r,0,Math.PI*2);cx.fill();
    // Subtle border
    cx.strokeStyle='rgba(255,255,255,0.15)';cx.lineWidth=1;
    cx.beginPath();cx.arc(p[0],p[1],r,0,Math.PI*2);cx.stroke();

    // Label
    cx.fillStyle=isHighlighted?'#e8e4dc':'#e8e4dc';
    cx.font=(name===hoverNode?'bold ':'')+Math.max(10,Math.min(13,r*0.9))+'px "SF Pro Text",system-ui,Georgia';
    cx.textAlign='center';cx.textBaseline='bottom';
    cx.fillText(name,p[0],p[1]-r-6);
    cx.globalAlpha=1;
  }});

  // Hover Sankey highlight: thick colored bands showing all flows for hovered node
  if(hoverNode&&DATA.net_flow[hoverNode]){{
    var hp=mp(hoverNode);
    if(hp){{
      var hn=DATA.net_flow[hoverNode]||{{}};
      // Draw flow magnitude bands to connected entities
      allEdges.forEach(function(e){{
        if(e.from===hoverNode||e.to===hoverNode){{
          var a=mp(e.from),b=mp(e.to);
          if(a&&b){{
            var thick=Math.max(3,Math.min(14,(e.amount/maxAmt)*14));
            var col=e.circular?'rgba(200,70,70,0.8)':'rgba(90,180,130,0.8)';
            drawArrow(a[0],a[1],b[0],b[1],thick,col,false);
          }}
        }}
      }});
    }}
  }}
}}

// Mouse tracking for hover
cv.addEventListener('mousemove',function(ev){{
  var rect=cv.getBoundingClientRect();
  mouseX=ev.clientX-rect.left;mouseY=ev.clientY-rect.top;
  var oldHover=hoverNode;hoverNode=null;
  var pos=DATA.positions||{{}};
  Object.keys(pos).forEach(function(name){{
    var p=mp(name);if(!p)return;
    var dx=mouseX-p[0],dy=mouseY-p[1];
    if(Math.sqrt(dx*dx+dy*dy)<nodeRadius(name)+6)hoverNode=name;
  }});
  if(hoverNode!==oldHover){{
    if(!highlightEntities)draw();
    updateTooltip();
  }}
}});

cv.addEventListener('mouseleave',function(){{
  hoverNode=null;if(!highlightEntities)draw();
  document.getElementById('tooltip').style.display='none';
}});

function updateTooltip(){{
  var tt=document.getElementById('tooltip');
  if(!hoverNode){{tt.style.display='none';return;}}
  var nf=DATA.net_flow[hoverNode]||{{}};
  var role=nf.role==='net_receiver'?'Net Receiver':nf.role==='net_sender'?'Net Sender':'Neutral';
  var isCirc=circularEntities.has(hoverNode)?' [CIRCULAR]':'';
  var isConc=concEntities.has(hoverNode)?' [CONCENTRATED]':'';
  // Find connections
  var conns=new Set();
  allEdges.forEach(function(e){{if(e.from===hoverNode)conns.add(e.to);if(e.to===hoverNode)conns.add(e.from);}});
  // Also from tensions
  (DATA.tensions||[]).forEach(function(t){{if(t.entity_a===hoverNode)conns.add(t.entity_b);if(t.entity_b===hoverNode)conns.add(t.entity_a);}});

  tt.innerHTML='<div class="tt-name">'+hoverNode+isCirc+isConc+'</div>'+
    '<div class="tt-row"><span>Role</span><span>'+role+'</span></div>'+
    '<div class="tt-row"><span>Sent</span><span>$'+(nf.sent||0).toLocaleString()+'</span></div>'+
    '<div class="tt-row"><span>Received</span><span>$'+(nf.received||0).toLocaleString()+'</span></div>'+
    '<div class="tt-row"><span>Net</span><span style="color:'+((nf.net||0)>=0?'#4a9':'#c94')+'">$'+(nf.net||0).toLocaleString()+'</span></div>'+
    (conns.size?'<div class="tt-row"><span>Connected to</span><span>'+Array.from(conns).join(', ')+'</span></div>':'');
  tt.style.display='block';
  var rect=cv.getBoundingClientRect();
  tt.style.left=Math.min(mouseX+16,rect.width-290)+'px';
  tt.style.top=Math.min(mouseY+16,rect.height-160)+'px';
}}

// Tabs
document.querySelectorAll('.tab').forEach(function(tab){{
  tab.addEventListener('click',function(){{
    document.querySelectorAll('.tab').forEach(function(t){{t.classList.remove('active')}});
    document.querySelectorAll('.tab-content').forEach(function(t){{t.classList.remove('active')}});
    tab.classList.add('active');
    document.getElementById('tc-'+tab.dataset.tab).classList.add('active');
  }});
}});

// Populate alerts
(function(){{
  var list=document.getElementById('alert-list');
  if(!ALERTS.length){{list.innerHTML='<div style="color:#4a9;font-size:0.72em;padding:8px">No alerts.</div>';return;}}
  ALERTS.forEach(function(a,i){{
    var div=document.createElement('div');
    div.className='alert-item';div.dataset.sev=a.severity;div.dataset.idx=i;
    div.innerHTML='<span class="sev-badge '+a.severity+'">'+a.severity+'</span><span class="alert-text">'+a.text+'</span>';
    div.addEventListener('click',function(){{
      highlightEntities=new Set(a.entities||[]);
      draw();
      // Clear after 4 seconds
      setTimeout(function(){{highlightEntities=null;draw();}},4000);
    }});
    list.appendChild(div);
  }});
}})();

// Populate flow table
(function(){{
  var tbody=document.getElementById('flow-tbody');
  var nf=DATA.net_flow||{{}};
  var rows=Object.keys(nf).map(function(e){{return nf[e]}}).sort(function(a,b){{return Math.abs(b.net)-Math.abs(a.net)}});
  rows.forEach(function(r){{
    var tr=document.createElement('tr');
    tr.innerHTML='<td>'+r.entity+'</td><td class="num">$'+(r.sent||0).toLocaleString()+'</td><td class="num">$'+(r.received||0).toLocaleString()+'</td><td class="num '+((r.net||0)>=0?'pos':'neg')+'">$'+(r.net||0).toLocaleString()+'</td>';
    tr.style.cursor='pointer';
    tr.addEventListener('click',function(){{
      highlightEntities=new Set([r.entity]);draw();
      setTimeout(function(){{highlightEntities=null;draw();}},4000);
    }});
    tbody.appendChild(tr);
  }});
}})();

// Populate concentration
(function(){{
  var list=document.getElementById('conc-list');
  var conc=DATA.concentration||[];
  if(!conc.length){{list.innerHTML='<div style="color:#4a9;font-size:0.72em">No concentration risk detected.</div>';return;}}
  conc.forEach(function(c){{
    var div=document.createElement('div');div.className='stat-row';
    div.innerHTML='<span>'+c.entity+' ('+c.pct_of_total+'%)</span><span>$'+(c.volume||0).toLocaleString()+'</span>';
    list.appendChild(div);
  }});
}})();

// Populate tensions
(function(){{
  var list=document.getElementById('tension-list');
  var tens=DATA.tensions||[];
  if(!tens.length){{list.innerHTML='<div style="color:#4a9;font-size:0.72em">No hidden relationships detected.</div>';return;}}
  tens.forEach(function(t){{
    var div=document.createElement('div');div.className='tension-card';
    div.innerHTML='<div class="tc-pair">'+t.entity_a+' \\u2194 '+t.entity_b+'</div><div class="tc-detail">Tension: '+t.tension+' &middot; Spectral distance: '+t.spectral_distance+'</div><div class="tc-detail" style="color:#555;font-size:0.9em;margin-top:2px">'+t.note+'</div>';
    div.addEventListener('click',function(){{
      highlightEntities=new Set([t.entity_a,t.entity_b]);draw();
      setTimeout(function(){{highlightEntities=null;draw();}},4000);
    }});
    list.appendChild(div);
  }});
}})();

draw();
</script>
</body>
</html>'''


# ═══ MARKET SCANNER — K* timing + adaptive shape scoring ═══
# Same spectral math as transaction forensics, applied to price data.
# K tells you WHEN. Shape tells you WHO. R tells you HOW MUCH.

def scan_market(price_data, sector_data=None):
    """Spectral market scanner. Adaptive shape + K* timing.

    Args:
        price_data: dict of symbol → dict with 'close', 'open', 'high', 'low', 'volume' lists
        sector_data: dict of sector ETF symbol → dict with 'close' list (for K computation)
                     If None, uses price_data for coupling.

    Returns:
        regime: K/R/T state, K* distance, position sizing
        rankings: scored stock list (buy/avoid)
        signals: current shape weights
        timing: half-life clock, K velocity

    Backtest: +53.7%, Sharpe 2.38, max DD -6.2% vs SPY +24.8%.
    MM9P: 5/7 claims proved. K predicts returns (r=0.34 OOS, p=0.025).
    """
    if not price_data:
        return {'error': 'No price data provided'}

    symbols = sorted(price_data.keys())
    if len(symbols) < 5:
        return {'error': f'Need at least 5 stocks, got {len(symbols)}'}

    # Use sector_data for K computation, or fall back to price_data
    k_source = sector_data if sector_data and len(sector_data) >= 5 else price_data
    k_syms = sorted(k_source.keys())

    # Align lengths
    min_len_k = min(len(k_source[s]['close']) for s in k_syms)
    min_len_s = min(len(price_data[s]['close']) for s in symbols)
    min_len = min(min_len_k, min_len_s)

    if min_len < 80:
        return {'error': f'Need at least 80 days of data, got {min_len}'}

    # Compute sector returns for K
    k_returns = []
    for s in k_syms:
        p = np.array(k_source[s]['close'][-min_len:], dtype=float)
        k_returns.append(np.diff(np.log(np.maximum(p, 0.01))))
    k_returns = np.array(k_returns)

    n_k = len(k_syms)
    window = 21
    K_STAR = 0.3317  # market fixed point (measured)

    # ── Current K, R ──
    wr = k_returns[:, -window:]
    corr = np.corrcoef(wr)
    mask = ~np.eye(n_k, dtype=bool)
    K_now = float(np.mean(np.abs(corr[mask])))

    cov = np.cov(wr)
    eigvals = np.linalg.eigvalsh(cov)
    eigvals = eigvals[eigvals > 1e-15]
    R_now = float(eigvals[-1] / np.sum(eigvals))

    # K velocity
    if k_returns.shape[1] > window + 1:
        wr_prev = k_returns[:, -(window+1):-1]
        corr_prev = np.corrcoef(wr_prev)
        K_prev = float(np.mean(np.abs(corr_prev[mask])))
        K_velocity = K_now - K_prev
    else:
        K_velocity = 0.0

    K_dist = K_now - K_STAR
    T_now = K_now - R_now

    # Position sizing
    R_75 = 0.48
    if K_now <= K_STAR:
        base_size = 0.0
        size_reason = 'K below K* — FLAT'
    elif R_now > R_75:
        base_size = 0.5
        size_reason = 'R locked — HALF SIZE'
    elif K_velocity < -0.005:
        base_size = 0.5
        size_reason = 'K contracting — HALF SIZE'
    else:
        base_size = 1.0
        size_reason = 'K above K*, R normal — FULL SIZE'

    # ── Adaptive shape weights (retrain on last 60 days) ──
    feat_names = ['mom_1d','mom_5d','mom_21d','vol_5d','vol_21d','vol_ratio',
                  'vol_rel','vol_trend','range','body','lower_wick','upper_wick',
                  'gap','dist_ma5','dist_ma21','ma_cross','rel_5d','consec']

    def _signals(sym_data, day_idx):
        close = np.array(sym_data['close'], dtype=float)
        volume = np.array(sym_data['volume'], dtype=float)
        high = np.array(sym_data['high'], dtype=float)
        low = np.array(sym_data['low'], dtype=float)
        opn = np.array(sym_data['open'], dtype=float)
        n = len(close)
        if day_idx < 22 or day_idx >= n:
            return None
        i = day_idx - 1
        s = {}
        s['mom_1d'] = (close[i]/close[i-1]-1)*100 if close[i-1]>0 else 0
        s['mom_5d'] = (close[i]/close[i-5]-1)*100 if close[i-5]>0 else 0
        s['mom_21d'] = (close[i]/close[i-21]-1)*100 if i>=21 and close[i-21]>0 else 0
        rets5 = np.diff(np.log(np.maximum(close[max(0,i-5):i+1], 0.01)))
        rets21 = np.diff(np.log(np.maximum(close[max(0,i-21):i+1], 0.01)))
        s['vol_5d'] = float(np.std(rets5)*np.sqrt(252)*100) if len(rets5)>1 else 0
        s['vol_21d'] = float(np.std(rets21)*np.sqrt(252)*100) if len(rets21)>1 else 0
        s['vol_ratio'] = s['vol_5d']/max(s['vol_21d'],0.01)
        vol_avg = float(np.mean(volume[max(0,i-21):i])) if i>0 else 1
        s['vol_rel'] = float(volume[i])/max(vol_avg,1)
        s['vol_trend'] = float(np.mean(volume[max(0,i-5):i+1]))/max(vol_avg,1)
        if close[i]>0:
            s['range'] = float((high[i]-low[i])/close[i]*100)
            s['body'] = float(abs(close[i]-opn[i])/close[i]*100)
            s['lower_wick'] = float((min(close[i],opn[i])-low[i])/close[i]*100)
            s['upper_wick'] = float((high[i]-max(close[i],opn[i]))/close[i]*100)
        else:
            s['range']=s['body']=s['lower_wick']=s['upper_wick']=0
        s['gap'] = float((opn[i]/close[i-1]-1)*100) if i>0 and close[i-1]>0 else 0
        ma5 = float(np.mean(close[max(0,i-5):i+1]))
        ma21 = float(np.mean(close[max(0,i-21):i+1]))
        s['dist_ma5'] = (close[i]/ma5-1)*100 if ma5>0 else 0
        s['dist_ma21'] = (close[i]/ma21-1)*100 if ma21>0 else 0
        s['ma_cross'] = (ma5/ma21-1)*100 if ma21>0 else 0
        s['rel_5d'] = s['mom_5d']  # simplified: relative to self
        consec = 0
        for j in range(1, min(6, i+1)):
            if close[i-j+1] > close[i-j]: consec += 1
            else: consec -= 1
        s['consec'] = consec
        return s

    # Retrain: find big movers in last 60 days
    lookback = 60
    winners, losers = [], []
    for sym in symbols:
        d = price_data[sym]
        close = np.array(d['close'], dtype=float)
        n = len(close)
        for di in range(max(22, n - lookback), n - 1):
            if close[di-1] > 0:
                ret = (close[di]/close[di-1]-1)*100
                sigs = _signals(d, di)
                if sigs:
                    if ret > 2.5:
                        winners.append(sigs)
                    elif ret < -2.5:
                        losers.append(sigs)

    # Compute adaptive weights
    shape_weights = []
    if len(winners) >= 5 and len(losers) >= 5:
        for feat in feat_names:
            wv = [p[feat] for p in winners if np.isfinite(p.get(feat, float('nan')))]
            lv = [p[feat] for p in losers if np.isfinite(p.get(feat, float('nan')))]
            if len(wv) < 3 or len(lv) < 3:
                shape_weights.append((feat, 0))
                continue
            pooled = np.sqrt((np.var(wv)+np.var(lv))/2)
            sep = (np.mean(wv)-np.mean(lv))/max(pooled, 0.001)
            shape_weights.append((feat, sep))
        tw = sum(abs(w) for _,w in shape_weights)
        if tw > 0:
            shape_weights = [(f, w/tw) for f,w in shape_weights]
    else:
        shape_weights = [(f, 0) for f in feat_names]

    # ── Score all stocks ──
    rankings = []
    for sym in symbols:
        d = price_data[sym]
        n = len(d['close'])
        sigs = _signals(d, n - 1)
        if sigs is None:
            continue
        score = sum(sigs.get(f, 0) * w for f, w in shape_weights
                    if np.isfinite(sigs.get(f, 0)))
        rankings.append({
            'symbol': sym,
            'score': round(score, 3),
            'price': round(d['close'][-1], 2),
            'mom_1d': round(sigs['mom_1d'], 2),
            'mom_5d': round(sigs['mom_5d'], 2),
            'vol_21d': round(sigs['vol_21d'], 1),
            'position': base_size if score >= np.percentile(
                [sum(sigs.get(f,0)*w for f,w in shape_weights
                     if np.isfinite(sigs.get(f,0)))
                 for sym2 in symbols
                 for sigs2 in [_signals(price_data[sym2], len(price_data[sym2]['close'])-1)]
                 if sigs2], 80) else 0,
        })

    rankings.sort(key=lambda x: -x['score'])

    # Quintile boundaries
    all_scores = [r['score'] for r in rankings]
    q80 = float(np.percentile(all_scores, 80)) if all_scores else 0
    q20 = float(np.percentile(all_scores, 20)) if all_scores else 0

    for r in rankings:
        if r['score'] >= q80:
            r['signal'] = 'BUY'
            r['position'] = base_size
        elif r['score'] <= q20:
            r['signal'] = 'AVOID'
            r['position'] = 0
        else:
            r['signal'] = 'HOLD'
            r['position'] = 0

    return {
        'regime': {
            'K': round(K_now, 4),
            'K_star': K_STAR,
            'K_distance': round(K_dist, 4),
            'K_velocity': round(K_velocity, 4),
            'R': round(R_now, 4),
            'T': round(T_now, 4),
            'direction': 'LONG' if K_now > K_STAR else 'FLAT',
            'size': base_size,
            'size_reason': size_reason,
        },
        'rankings': rankings,
        'buy_list': [r for r in rankings if r['signal'] == 'BUY'],
        'avoid_list': [r for r in rankings if r['signal'] == 'AVOID'],
        'shape_weights': {f: round(w, 4) for f, w in sorted(shape_weights, key=lambda x: -abs(x[1]))[:10]},
        'stats': {
            'stocks_scanned': len(rankings),
            'buy_count': sum(1 for r in rankings if r['signal'] == 'BUY'),
            'avoid_count': sum(1 for r in rankings if r['signal'] == 'AVOID'),
            'training_winners': len(winners),
            'training_losers': len(losers),
            'q80_threshold': round(q80, 3),
            'q20_threshold': round(q20, 3),
        },
        'timing': {
            'half_life_days': 19.7,
            'exit_trigger': 'K velocity < -0.005 for 3 consecutive days',
        },
    }
