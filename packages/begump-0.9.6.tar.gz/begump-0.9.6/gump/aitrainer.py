"""AITRAINER — Detect grokking (memorization -> understanding)."""
import numpy as np

def detect_grokking(train_loss, test_loss, window=20):
    """Detect grokking phase. Returns phase: LEARNING|MEMORIZED|GROKKING|UNDERSTOOD."""
    train = np.asarray(train_loss, dtype=np.float64)
    test = np.asarray(test_loss, dtype=np.float64)
    n = min(len(train), len(test))
    if n < window*2: return {'phase':'INSUFFICIENT_DATA','n':n}
    train, test = train[:n], test[:n]
    gap = test - train
    gt = np.polyfit(range(window), gap[-window:], 1)[0]
    fg = float(np.mean(gap[-window:]))
    ft = float(np.mean(train[-window:]))
    if ft > 0.5: phase = 'LEARNING'
    elif fg > 0.3 and gt > 0: phase = 'MEMORIZED'
    elif fg > 0.1 and gt < -0.001: phase = 'GROKKING'
    elif fg < 0.1: phase = 'UNDERSTOOD'
    else: phase = 'MEMORIZED'
    grok_epoch = None
    if phase in ('GROKKING','UNDERSTOOD'):
        for i in range(window, n-window):
            if np.polyfit(range(window), gap[i:i+window], 1)[0] < -0.001 and gap[i] > 0.2:
                grok_epoch = i; break
    return {'phase':phase,'train_loss':round(ft,4),'test_loss':round(float(np.mean(test[-window:])),4),
            'gap':round(fg,4),'gap_trend':round(float(gt),6),'grok_epoch':grok_epoch,'n':n}
