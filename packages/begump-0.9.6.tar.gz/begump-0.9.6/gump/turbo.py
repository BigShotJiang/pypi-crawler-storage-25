"""TURBO — K language expression evaluator."""
import re

def compile_k(expression):
    """Parse a K-language expression."""
    if not re.match(r'^[KRET0-9()+\-*/^.,\s]+$', expression):
        return {'error':'Invalid characters'}
    return {'expression':expression,'compiled':True}

def run(expression):
    """Evaluate a K-language expression."""
    phi = (1+5**0.5)/2
    def K(x): return float(x)/(1+float(x))
    def R(x): return 1/(1+1/max(0.001,float(x)))
    def E(x): return float(x)*2.87e-21
    def T(x): return max(0, K(x)-R(x))
    try:
        expr = expression.replace('^','**')
        result = eval(expr, {'__builtins__':{}}, {'K':K,'R':R,'E':E,'T':T,'abs':abs,'max':max,'min':min})
        return {'expression':expression,'result':float(result)}
    except Exception as e:
        return {'expression':expression,'error':str(e)}
