"""KNOWLEDGE — Build a knowledge graph from text, find gaps."""
import re
from collections import Counter

STOPWORDS = {'the','a','an','is','are','was','were','be','been','being','have','has','had',
    'do','does','did','will','would','could','should','may','might','shall','can','to','of',
    'in','for','on','with','at','by','from','as','into','through','and','but','or','not','no',
    'it','its','this','that','these','those','he','she','they','we','you','i','me','my','his',
    'her','our','your','their','what','which','who','whom','how','than','then','so','if','when',
    'where','while','also','just','about','up','out','all','each','every','both','more','most'}

def build_graph(text, min_word_length=3, min_cooccurrence=1):
    """Build co-occurrence graph from text. Returns nodes, edges, gaps, K, R."""
    import numpy as np
    sentences = [s.strip() for s in re.split(r'[.!?]+', text.lower()) if s.strip()]
    wp = re.compile(r'[a-z]+')
    cooccur, word_freq = Counter(), Counter()
    for sent in sentences:
        words = list(set(w for w in wp.findall(sent) if len(w)>=min_word_length and w not in STOPWORDS))
        for w in words: word_freq[w] += 1
        for i in range(len(words)):
            for j in range(i+1, len(words)):
                cooccur[tuple(sorted([words[i],words[j]]))] += 1
    nodes = [w for w,_ in word_freq.most_common(100)]
    edges = [(a,b,c) for (a,b),c in cooccur.items() if c>=min_cooccurrence and a in nodes and b in nodes]
    node_deg = Counter()
    connected = set()
    for a,b,c in edges:
        node_deg[a]+=c; node_deg[b]+=c; connected.add((a,b)); connected.add((b,a))
    top = [n for n,_ in node_deg.most_common(20)]
    gaps = [{'from':top[i],'to':top[j]} for i in range(len(top)) for j in range(i+1,len(top)) if (top[i],top[j]) not in connected]
    mx = len(nodes)*(len(nodes)-1)/2
    K = len(edges)/mx if mx>0 else 0
    degs = list(node_deg.values())
    R = 1/(1+np.std(degs)/(np.mean(degs)+1e-10)) if degs else 0
    return {'nodes':nodes[:50],'edges':edges[:100],'gaps':gaps[:20],'K':round(K,4),'R':round(R,4),
            'n_nodes':len(nodes),'n_edges':len(edges),'n_gaps':len(gaps)}
