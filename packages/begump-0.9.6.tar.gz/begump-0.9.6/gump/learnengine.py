"""LEARNENGINE — Track learning progress, detect understanding."""
import numpy as np

def track(responses, window=5):
    """Track learning from correct/incorrect sequence. Returns phase."""
    r = np.asarray(responses, dtype=np.float64)
    n = len(r)
    if n < window*2: return {'phase':'INSUFFICIENT_DATA','n':n}
    current = float(np.mean(r[-window:]))
    accs = [np.mean(r[i-window:i]) for i in range(window, n+1)]
    trend = np.polyfit(range(len(accs[-window:])), accs[-window:], 1)[0] if len(accs) >= window else 0
    if current < 0.5: phase = 'LEARNING'
    elif current < 0.8: phase = 'MEMORIZING'
    elif trend > 0.01: phase = 'TRANSITIONING'
    else: phase = 'UNDERSTANDING'
    K = float(1 - np.std(r[-window:])) if n >= window else 0
    return {'phase':phase,'accuracy':round(current,4),'trend':round(float(trend),6),
            'K_consistency':round(K,4),'n_responses':n,'n_correct':int(np.sum(r))}
