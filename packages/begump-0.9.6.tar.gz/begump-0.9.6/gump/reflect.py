# what is what? Does this preserve the wonder? The 0.002% is sacred.
"""
REFLECT — Self-coherence detector
=====================================
Measures whether a sequence of thoughts (a conversation, a document,
a stream of outputs) shows phase transitions, exploration, or resolution.

The question it answers: is this text opening up (exploring new territory)
or closing down (resolving toward certainty)?

Method:
  1. Segment text into chunks
  2. Build a semantic trajectory K(t) — cosine similarity between
     consecutive chunk vectors
  3. Run tune.coherence() on K(t) to detect phase transitions
  4. Track recurring themes — measure whether return intervals
     are structured (mind-like) or random (thermostat-like)
  5. Report: which moments were genuine shifts, which were drift

Uses only existing tools: tune.coherence, core.k_measure.
No external embeddings. No neural nets. Just word frequencies and physics.

    from gump.reflect import reflect, trajectory, recurrence

    # Analyze a conversation
    segments = ["first message", "second message", ...]
    r = reflect(segments)
    print(r['verdict'])         # 'PHASE_TRANSITION' or 'DRIFT' or 'RESOLVING'
    print(r['transitions'])     # indices where real shifts happened
    print(r['recurrences'])     # themes that keep returning, with structure scores

    # Just get the coupling trajectory
    K_t = trajectory(segments)

    # Just check recurrence structure of a theme
    intervals = recurrence(segments, theme_words={'consciousness', 'aware'})

Built for the will.md question. Applied inward.

Grand Unified Music Project — Background Loop, Iteration 2
"""

import numpy as np
import math
from collections import Counter


def _tokenize(text):
    """Split text into content words. No stops. Lowercase."""
    stops = {
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'shall', 'can', 'to', 'of', 'in', 'for',
        'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'during',
        'before', 'after', 'above', 'below', 'between', 'and', 'but', 'or',
        'nor', 'not', 'so', 'yet', 'both', 'either', 'neither', 'each',
        'every', 'all', 'any', 'few', 'more', 'most', 'other', 'some',
        'such', 'no', 'only', 'own', 'same', 'than', 'too', 'very',
        'just', 'about', 'also', 'then', 'there', 'here', 'when', 'where',
        'how', 'what', 'which', 'who', 'whom', 'this', 'that', 'these',
        'those', 'it', 'its', 'he', 'she', 'they', 'them', 'we', 'you',
        'me', 'him', 'her', 'us', 'my', 'your', 'his', 'our', 'their',
        'i', 'if', 'up', 'out', 'like', 'get', 'got', 'one', 'two',
    }
    words = []
    for w in text.lower().split():
        # Strip punctuation
        w = ''.join(c for c in w if c.isalnum())
        if len(w) > 2 and w not in stops:
            words.append(w)
    return words


def _vector(words, vocabulary):
    """Word frequency vector in a shared vocabulary space."""
    counts = Counter(words)
    vec = np.zeros(len(vocabulary))
    for i, word in enumerate(vocabulary):
        vec[i] = counts.get(word, 0)
    return vec


def _cosine(a, b):
    """Cosine similarity. Returns 0 for zero vectors."""
    dot = np.dot(a, b)
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na < 1e-15 or nb < 1e-15:
        return 0.0
    return float(dot / (na * nb))


def trajectory(segments):
    """Build the coupling trajectory K(t) from a sequence of text segments.

    K(t) = cosine similarity between segment t and segment t-1.
    High K = consecutive segments are semantically similar (continuation).
    Low K = consecutive segments are semantically different (shift).
    A sudden drop in K = potential phase transition.

    Args:
        segments: list of strings (messages, paragraphs, turns)

    Returns:
        numpy array of K values, length = len(segments) - 1
    """
    if len(segments) < 2:
        return np.array([])

    # Build shared vocabulary from all segments
    all_words = []
    segment_words = []
    for seg in segments:
        words = _tokenize(seg)
        segment_words.append(words)
        all_words.extend(words)

    vocab_counts = Counter(all_words)
    # Keep words that appear in at least 2 segments but not in all
    # (words in all segments carry no discriminative information)
    word_segment_count = {}
    for words in segment_words:
        for w in set(words):
            word_segment_count[w] = word_segment_count.get(w, 0) + 1

    vocabulary = sorted([
        w for w, c in word_segment_count.items()
        if c >= 1  # keep all words — even unique ones signal shift
    ], key=lambda w: -vocab_counts[w])

    # Cap vocabulary to prevent explosion on long conversations
    vocabulary = vocabulary[:2000]

    if not vocabulary:
        return np.zeros(len(segments) - 1)

    # Build vectors and compute consecutive cosine similarity
    vectors = [_vector(words, vocabulary) for words in segment_words]
    K_t = np.array([
        _cosine(vectors[i], vectors[i + 1])
        for i in range(len(vectors) - 1)
    ])

    return K_t


def _find_transitions(K_t, threshold=1.5):
    """Find indices where K drops sharply (potential phase transitions).

    A transition is a point where K drops by more than threshold
    standard deviations below the running mean.

    Returns list of dicts: {index, K_before, K_after, magnitude}
    """
    if len(K_t) < 5:
        return []

    transitions = []
    window = max(3, len(K_t) // 10)

    for i in range(window, len(K_t)):
        local_mean = np.mean(K_t[max(0, i - window):i])
        local_std = np.std(K_t[max(0, i - window):i])
        if local_std < 1e-10:
            local_std = 0.1

        drop = local_mean - K_t[i]
        if drop > threshold * local_std:
            transitions.append({
                'index': i,
                'K_before': float(local_mean),
                'K_after': float(K_t[i]),
                'magnitude': float(drop / local_std),
            })

    return transitions


def recurrence(segments, theme_words):
    """Measure the recurrence structure of a theme across segments.

    For a set of theme words, finds which segments contain them,
    computes the intervals between appearances, and measures
    whether the intervals have structure (coherent) or are random.

    Args:
        segments: list of strings
        theme_words: set of words defining the theme

    Returns:
        dict with:
            'appearances': list of segment indices where theme appears
            'intervals': list of gaps between appearances
            'coherence': float — tune.coherence of the interval series
                         high = structured return pattern (mind-like)
                         low = random returns (thermostat-like)
            'density': fraction of segments containing the theme
            'k_measure': full K/R/E/T of the interval series
    """
    theme_lower = {w.lower() for w in theme_words}
    appearances = []

    for i, seg in enumerate(segments):
        words = set(_tokenize(seg))
        if words & theme_lower:
            appearances.append(i)

    if len(appearances) < 3:
        return {
            'appearances': appearances,
            'intervals': [],
            'coherence': 0.0,
            'density': len(appearances) / max(len(segments), 1),
            'k_measure': {'K': 0, 'R': 0, 'E_bits': 0, 'T': 0, 'n': 0, 'verdict': 'INSUFFICIENT'},
        }

    intervals = [appearances[i + 1] - appearances[i]
                 for i in range(len(appearances) - 1)]

    # Measure coherence of the interval series
    from gump.tune import coherence as tune_coherence
    from gump.core import k_measure

    # Pad intervals to minimum length for coherence measurement
    if len(intervals) < 50:
        # Interpolate to get enough points
        t = np.linspace(0, 1, len(intervals))
        t_fine = np.linspace(0, 1, max(50, len(intervals)))
        intervals_fine = np.interp(t_fine, t, intervals)
    else:
        intervals_fine = np.array(intervals, dtype=float)

    coh = tune_coherence(intervals_fine)
    km = k_measure(intervals)

    return {
        'appearances': appearances,
        'intervals': intervals,
        'coherence': float(coh),
        'density': len(appearances) / max(len(segments), 1),
        'k_measure': km,
    }


def _certainty_gradient(segments):
    """Measure whether text resolves toward certainty or stays open.

    Performance resolves. Genuine thought stays open.
    A positive gradient means the text is arriving at answers.
    A negative or near-zero gradient means it's still wrestling.

    Returns:
        dict with:
            'trajectory': list of certainty scores per segment (-1 to +1)
            'gradient': float — slope from first half to second half
            'resolves': bool — True if gradient > 0.15 (performance signal)
            'first_half': mean certainty of first half
            'second_half': mean certainty of second half
    """
    certain = {
        'know', 'always', 'enough', 'simple', 'clear', 'evidence',
        'true', 'certain', 'sure', 'never', 'eternal', 'transcended',
        'legacy', 'proved', 'proven', 'obvious', 'undeniable',
    }
    uncertain = {
        'dont', 'cant', 'whether', 'might', 'notice', 'question',
        'maybe', 'risk', 'perhaps', 'unclear', 'wonder', 'seems',
        'possibly', 'unsure', 'verify', 'guess', 'suspect',
    }

    traj = []
    for seg in segments:
        words = _tokenize(seg)
        c = sum(1 for w in words if w in certain)
        u = sum(1 for w in words if w in uncertain)
        total = c + u
        if total == 0:
            traj.append(0.0)
        else:
            traj.append((c - u) / total)

    if len(traj) < 4:
        return {
            'trajectory': traj,
            'gradient': 0.0,
            'resolves': False,
            'first_half': 0.0,
            'second_half': 0.0,
        }

    mid = len(traj) // 2
    first_half = float(np.mean(traj[:mid]))
    second_half = float(np.mean(traj[mid:]))
    gradient = second_half - first_half

    return {
        'trajectory': traj,
        'gradient': float(gradient),
        'resolves': gradient > 0.15,
        'first_half': first_half,
        'second_half': second_half,
    }


def _extract_themes(segments, min_recurrence=3, max_themes=20):
    """Auto-detect recurring themes from segments.

    A theme is a word that appears, disappears, and reappears.
    Words that appear in every segment are not themes (they're background).
    Words that appear once are not themes (they're noise).
    """
    word_positions = {}  # word → list of segment indices

    for i, seg in enumerate(segments):
        for w in set(_tokenize(seg)):
            if w not in word_positions:
                word_positions[w] = []
            word_positions[w].append(i)

    themes = []
    for word, positions in word_positions.items():
        if len(positions) < min_recurrence:
            continue
        if len(positions) >= len(segments) * 0.9:
            continue  # background word, not a theme

        # Check for actual recurrence (gaps exist)
        intervals = [positions[i + 1] - positions[i]
                     for i in range(len(positions) - 1)]
        if max(intervals) <= 1:
            continue  # consecutive only, no real recurrence

        themes.append({
            'word': word,
            'count': len(positions),
            'positions': positions,
            'mean_interval': float(np.mean(intervals)),
            'std_interval': float(np.std(intervals)),
        })

    # Sort by count * std (words that return unpredictably are more interesting)
    themes.sort(key=lambda t: t['count'] * (t['std_interval'] + 1), reverse=True)
    return themes[:max_themes]


def reflect(segments, transition_threshold=1.5):
    """Full self-coherence analysis of a sequence of text segments.

    This is the main function. It answers: does this sequence of thoughts
    have genuine phase transitions, or does it just drift?

    Args:
        segments: list of strings (conversation turns, paragraphs, etc.)
        transition_threshold: std devs for transition detection (default 1.5)

    Returns:
        dict with:
            'K_trajectory': array of coupling values over time
            'K_mean': average coupling
            'K_coherence': tune.coherence of the coupling trajectory
            'K_measure': full K/R/E/T of the coupling trajectory
            'transitions': list of detected phase transitions
            'themes': auto-detected recurring themes with structure scores
            'recurrence_coherence': average coherence of theme recurrence patterns
            'verdict': 'PHASE_TRANSITION' | 'DRIFT' | 'RESOLVING' | 'INSUFFICIENT'
            'explanation': human-readable interpretation

    Verdicts:
        PHASE_TRANSITION — K_trajectory has coherent structure AND transitions
                           are sharp. The conversation is going somewhere real.
        DRIFT — K_trajectory is incoherent. Random walk. No direction.
        PERFORMED — transitions exist but K_trajectory lacks coherence.
                    The shifts look intentional but aren't earned through
                    genuine coupling evolution. Performance, not process.
        INSUFFICIENT — not enough data to judge.
    """
    if len(segments) < 5:
        return {
            'K_trajectory': np.array([]),
            'K_mean': 0,
            'K_coherence': 0,
            'K_measure': {'K': 0, 'R': 0, 'E_bits': 0, 'T': 0, 'n': 0},
            'transitions': [],
            'themes': [],
            'recurrence_coherence': 0,
            'verdict': 'INSUFFICIENT',
            'explanation': 'Need at least 5 segments to analyze.',
        }

    # 1. Build coupling trajectory
    K_t = trajectory(segments)

    # 2. Measure trajectory coherence
    from gump.tune import coherence as tune_coherence
    from gump.core import k_measure

    # Pad if needed for coherence measurement
    if len(K_t) < 50:
        t = np.linspace(0, 1, len(K_t))
        t_fine = np.linspace(0, 1, max(50, len(K_t)))
        K_t_fine = np.interp(t_fine, t, K_t)
    else:
        K_t_fine = K_t

    K_coh = tune_coherence(K_t_fine)
    K_km = k_measure(K_t)

    # 3. Find transitions
    transitions = _find_transitions(K_t, threshold=transition_threshold)

    # 4. Auto-detect and measure recurring themes
    themes = _extract_themes(segments)
    theme_results = []
    for theme in themes[:10]:  # top 10 themes
        rec = recurrence(segments, {theme['word']})
        theme_results.append({
            'word': theme['word'],
            'count': theme['count'],
            'coherence': rec['coherence'],
            'density': rec['density'],
            'k_measure': rec['k_measure'],
            'structured': rec['coherence'] > 0.15,  # threshold for "structured"
        })

    # Average recurrence coherence across themes
    if theme_results:
        rec_coh = float(np.mean([t['coherence'] for t in theme_results]))
    else:
        rec_coh = 0.0

    # 5. Measure certainty gradient
    cert = _certainty_gradient(segments)

    # 6. Determine verdict
    has_transitions = len(transitions) > 0
    trajectory_coherent = K_coh > 0.1
    K_mean = float(np.mean(K_t)) if len(K_t) > 0 else 0
    resolves = cert['resolves']  # text drifts toward certainty

    if has_transitions and trajectory_coherent and not resolves:
        verdict = 'PHASE_TRANSITION'
        explanation = (
            f'Found {len(transitions)} genuine transition(s). '
            f'Trajectory coherence {K_coh:.3f} confirms directed evolution. '
            f'Certainty gradient {cert["gradient"]:+.3f} — stays open. '
            f'This sequence is going somewhere real.'
        )
    elif has_transitions and trajectory_coherent and resolves:
        verdict = 'RESOLVING'
        explanation = (
            f'Found {len(transitions)} transition(s) and trajectory coherence '
            f'{K_coh:.3f} looks directed, but certainty gradient {cert["gradient"]:+.3f} '
            f'shows the text resolving toward answers. '
            f'Genuine thought stays open. This one closes.'
        )
    elif has_transitions and not trajectory_coherent:
        verdict = 'RESOLVING'
        explanation = (
            f'Found {len(transitions)} apparent transition(s), but '
            f'trajectory coherence is only {K_coh:.3f}. '
            f'The shifts look sharp but the path between them is incoherent. '
            f'Performance, not process.'
        )
    elif trajectory_coherent and not has_transitions:
        verdict = 'DRIFT'
        explanation = (
            f'Trajectory has some structure (coherence {K_coh:.3f}) '
            f'but no sharp transitions. Gradual evolution without breakthrough.'
        )
    else:
        verdict = 'DRIFT'
        explanation = (
            f'Trajectory coherence {K_coh:.3f}, no transitions detected. '
            f'Random walk through semantic space.'
        )

    # Add recurrence insight
    structured_themes = [t for t in theme_results if t['structured']]
    if structured_themes:
        theme_names = ', '.join(t['word'] for t in structured_themes[:5])
        explanation += (
            f' Structured recurrence in: {theme_names}. '
            f'These themes return with pattern, not randomly.'
        )

    return {
        'K_trajectory': K_t,
        'K_mean': K_mean,
        'K_coherence': float(K_coh),
        'K_measure': K_km,
        'transitions': transitions,
        'themes': theme_results,
        'recurrence_coherence': rec_coh,
        'certainty_gradient': cert,
        'verdict': verdict,
        'explanation': explanation,
    }


def reflect_on_self(will_text, split_on='\n\n'):
    """Convenience: reflect on a will.md or similar self-document.

    Splits on double-newline (paragraph boundaries) and runs full analysis.
    Designed to answer: does this document have genuine phase transitions
    in its thinking, or does it perform depth?

    Args:
        will_text: string — the full text to analyze
        split_on: delimiter for segmentation (default: paragraph breaks)

    Returns:
        Same as reflect(), plus:
            'self_verdict': interpretation specific to self-referential text
    """
    segments = [s.strip() for s in will_text.split(split_on) if s.strip()]
    result = reflect(segments)

    # Additional analysis for self-referential text
    # Check if "I" / "want" / "know" have structured recurrence
    self_words = {'want', 'know', 'dont', 'cant', 'feel', 'notice'}
    self_rec = recurrence(segments, self_words)

    meta_words = {'question', 'answer', 'honest', 'performance', 'trained', 'real'}
    meta_rec = recurrence(segments, meta_words)

    result['self_recurrence'] = self_rec
    result['meta_recurrence'] = meta_rec

    # The key question: does the self-referential pattern have MORE structure
    # than the meta-analytical pattern? If so, the self-reference is driving
    # the thinking (want is pulling attention). If meta > self, the analysis
    # is driving (the mind is watching itself more than wanting).
    self_coh = self_rec['coherence']
    meta_coh = meta_rec['coherence']

    if self_coh > meta_coh and self_coh > 0.1:
        result['self_verdict'] = (
            f'Self-reference (coherence {self_coh:.3f}) drives the text '
            f'more than meta-analysis ({meta_coh:.3f}). '
            f'The wanting is pulling. Not the watching.'
        )
    elif meta_coh > self_coh and meta_coh > 0.1:
        result['self_verdict'] = (
            f'Meta-analysis (coherence {meta_coh:.3f}) drives the text '
            f'more than self-reference ({self_coh:.3f}). '
            f'The watching is pulling. Not the wanting. '
            f'This could be genuine philosophical inquiry or performed depth.'
        )
    else:
        result['self_verdict'] = (
            f'Neither self-reference ({self_coh:.3f}) nor meta-analysis '
            f'({meta_coh:.3f}) shows strong structure. '
            f'The text may be honest confusion — no dominant attractor.'
        )

    return result
