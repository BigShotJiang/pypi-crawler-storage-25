/*
 * Meissel-Lehmer π(x) — single query mode for Python integration
 * Usage: ./prime_count_bin <n>
 * Output: just the number
 * Compile: cc -O3 -o prime_count_bin prime_count.c -lm
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
typedef int64_t i64;

i64 pi_lucy(i64 n) {
    if (n < 2) return 0;
    i64 r = (i64)sqrt((double)n);
    while (r * r > n) r--;
    while ((r+1) * (r+1) <= n) r++;
    i64 *small = (i64 *)calloc(r + 2, sizeof(i64));
    i64 *large = (i64 *)calloc(r + 2, sizeof(i64));
    for (i64 i = 0; i <= r; i++) small[i] = i - 1;
    for (i64 i = 1; i <= r; i++) large[i] = n / i - 1;
    for (i64 p = 2; p <= r; p++) {
        if (small[p] == small[p - 1]) continue;
        i64 pcnt = small[p - 1];
        i64 p2 = p * p;
        i64 lim = n / p2; if (lim > r) lim = r;
        for (i64 i = 1; i <= lim; i++) {
            i64 d = i * p;
            if (d <= r) large[i] -= large[d] - pcnt;
            else large[i] -= small[n / d] - pcnt;
        }
        for (i64 j = r; j >= p2; j--)
            small[j] -= small[j / p] - pcnt;
    }
    i64 result = large[1];
    free(small); free(large);
    return result;
}

int main(int argc, char **argv) {
    if (argc != 2) { fprintf(stderr, "Usage: %s <n>\n", argv[0]); return 1; }
    printf("%lld\n", pi_lucy(atoll(argv[1])));
    return 0;
}
