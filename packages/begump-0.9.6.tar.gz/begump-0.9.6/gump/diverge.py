"""
DIVERGE — Parallel response divergence detector
=====================================================
"How different are they?"

One function. Give it a list of responses to the same prompt.
Get back: how much they agree, where they split, and why.

Usage:
    from gump.diverge import diverge

    result = diverge([
        "The answer is 4.",
        "2+2 equals 4.",
        "Four.",
    ])
    print(result['divergence_score'])   # 0-1 (0=identical, 1=nothing shared)
    print(result['diagnosis'])          # "converged" / "divergent" / "split on [topic]"
    print(result['consensus'])          # what ALL responses agree on
    print(result['splits'])             # what only SOME say

    # Batch mode: multiple prompts, each with parallel responses
    from gump.diverge import diverge_batch

    results = diverge_batch({
        'q1': ["4.", "Four.", "2+2=4."],
        'q2': ["Paris.", "The capital is Paris.", "Paris, France."],
    })

Derived from the neuro divergence test (Session 35).
Generalized: works on any set of parallel text responses.

Grand Unified Music Project
"""

import re
from collections import Counter


# ═══════════════════════════════════════════════════════════
# TOKENIZATION
# ═══════════════════════════════════════════════════════════

def _tokenize(text):
    """Lowercase word+number tokenization. Keeps digits as tokens."""
    if not isinstance(text, str):
        text = str(text)
    return re.findall(r'[a-z0-9]+', text.lower())


def _token_set(text):
    """Unique tokens from text."""
    return set(_tokenize(text))


# ═══════════════════════════════════════════════════════════
# CORE METRICS
# ═══════════════════════════════════════════════════════════

def _jaccard_distance(a, b):
    """1 - Jaccard similarity between two token sets. 0=identical, 1=disjoint."""
    set_a = _token_set(a)
    set_b = _token_set(b)
    if not set_a and not set_b:
        return 0.0
    intersection = set_a & set_b
    union = set_a | set_b
    return 1.0 - len(intersection) / len(union)


def _pairwise_divergence(responses):
    """Mean pairwise Jaccard distance across all response pairs."""
    n = len(responses)
    if n < 2:
        return 0.0
    total = 0.0
    count = 0
    for i in range(n):
        for j in range(i + 1, n):
            total += _jaccard_distance(responses[i], responses[j])
            count += 1
    return total / count


def _unique_content_ratio(responses):
    """Fraction of distinct words that appear in only one response."""
    word_counts = Counter()
    for r in responses:
        for w in _token_set(r):
            word_counts[w] += 1
    total = len(word_counts)
    if total == 0:
        return 0.0
    unique = sum(1 for w, c in word_counts.items() if c == 1)
    return unique / total


def _length_cv(responses):
    """Coefficient of variation of response lengths (word count)."""
    lengths = [len(_tokenize(r)) for r in responses]
    n = len(lengths)
    if n == 0:
        return 0.0
    mean_l = sum(lengths) / n
    if mean_l == 0:
        return 0.0
    variance = sum((x - mean_l) ** 2 for x in lengths) / n
    std = variance ** 0.5
    return std / mean_l


# ═══════════════════════════════════════════════════════════
# CONSENSUS & SPLITS
# ═══════════════════════════════════════════════════════════

def _find_consensus(responses):
    """Words that appear in ALL responses (intersection of token sets)."""
    if not responses:
        return set()
    sets = [_token_set(r) for r in responses]
    common = sets[0]
    for s in sets[1:]:
        common = common & s
    # Filter out stopwords — they inflate consensus meaninglessly
    return common - _STOPWORDS


def _find_splits(responses):
    """Words that appear in SOME but not ALL responses — the interesting part.

    Returns dict: {word: count_of_responses_containing_it}
    Only includes words in 2+ responses but not all (partial agreement).
    For 2-response sets, words unique to one side are also splits.
    """
    if len(responses) < 2:
        return {}
    word_counts = Counter()
    for r in responses:
        for w in _token_set(r):
            word_counts[w] += 1
    n = len(responses)
    # Split = appears in more than 1 but fewer than all
    # For n=2, also include unique words (count=1) as splits
    if n == 2:
        splits = {w: c for w, c in word_counts.items()
                  if c < n and w not in _STOPWORDS}
    else:
        splits = {w: c for w, c in word_counts.items()
                  if 1 < c < n and w not in _STOPWORDS}
    return splits


# Stopwords — common English words that carry no signal
_STOPWORDS = {
    'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'shall', 'can', 'to', 'of', 'in', 'for',
    'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'during',
    'before', 'after', 'above', 'below', 'between', 'out', 'off', 'over',
    'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when',
    'where', 'why', 'how', 'all', 'each', 'every', 'both', 'few', 'more',
    'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own',
    'same', 'so', 'than', 'too', 'very', 'just', 'but', 'and', 'or',
    'if', 'because', 'until', 'while', 'about', 'against', 'up', 'down',
    'that', 'this', 'these', 'those', 'it', 'its', 'i', 'me', 'my',
    'we', 'our', 'you', 'your', 'he', 'she', 'they', 'them', 'their',
    'what', 'which', 'who', 'whom', 'his', 'her', 'him', 'am',
}


# ═══════════════════════════════════════════════════════════
# DIAGNOSIS
# ═══════════════════════════════════════════════════════════

def _diagnose(divergence_score, unique_ratio, splits, n_responses):
    """Classify the divergence pattern."""
    if divergence_score < 0.15:
        return "converged"
    if divergence_score > 0.65:
        return "divergent"
    # Check if there's a specific topic split
    if splits and n_responses >= 3:
        # Find the most "controversial" words — appear in ~half the responses
        half = n_responses / 2
        split_words = sorted(
            splits.items(),
            key=lambda x: abs(x[1] - half)  # closest to half = most divisive
        )
        if split_words:
            # Take top 3 most divisive content words
            top = [w for w, c in split_words[:3]]
            return f"split on [{', '.join(top)}]"
    if divergence_score > 0.4:
        return "divergent"
    return "converged"


# ═══════════════════════════════════════════════════════════
# MAIN FUNCTION
# ═══════════════════════════════════════════════════════════

def diverge(responses):
    """Measure divergence across parallel responses to the same prompt.

    Args:
        responses: list of strings (2+ responses to the same prompt)

    Returns:
        dict with:
            divergence_score   — 0-1, mean pairwise Jaccard distance
            unique_content_ratio — fraction of words in only one response
            length_cv          — coefficient of variation of response lengths
            consensus          — set of words ALL responses share
            splits             — dict {word: count} for partial-agreement words
            diagnosis          — "converged" / "divergent" / "split on [topic]"
            n                  — number of responses analyzed
    """
    # Validate input
    if not responses or not isinstance(responses, (list, tuple)):
        return {
            'divergence_score': 0.0,
            'unique_content_ratio': 0.0,
            'length_cv': 0.0,
            'consensus': set(),
            'splits': {},
            'diagnosis': 'no data',
            'n': 0,
        }

    # Convert any non-strings
    responses = [str(r) if not isinstance(r, str) else r for r in responses]

    # Filter empty
    responses = [r for r in responses if r.strip()]

    n = len(responses)
    if n < 2:
        return {
            'divergence_score': 0.0,
            'unique_content_ratio': 0.0,
            'length_cv': 0.0,
            'consensus': _token_set(responses[0]) - _STOPWORDS if n == 1 else set(),
            'splits': {},
            'diagnosis': 'insufficient data',
            'n': n,
        }

    div = _pairwise_divergence(responses)
    ucr = _unique_content_ratio(responses)
    lcv = _length_cv(responses)
    consensus = _find_consensus(responses)
    splits = _find_splits(responses)
    diagnosis = _diagnose(div, ucr, splits, n)

    return {
        'divergence_score': round(div, 4),
        'unique_content_ratio': round(ucr, 4),
        'length_cv': round(lcv, 4),
        'consensus': consensus,
        'splits': splits,
        'diagnosis': diagnosis,
        'n': n,
    }


# ═══════════════════════════════════════════════════════════
# BATCH MODE
# ═══════════════════════════════════════════════════════════

def diverge_batch(prompt_responses):
    """Analyze divergence across multiple prompts.

    Args:
        prompt_responses: dict of {prompt_id: [response1, response2, ...]}
                          or list of lists [[r1, r2, ...], [r1, r2, ...]]

    Returns:
        dict with:
            per_prompt  — list of individual diverge() results (keyed by prompt_id)
            mean_divergence — average divergence across all prompts
            mean_unique     — average unique_content_ratio
            mean_length_cv  — average length_cv
            most_converged  — prompt_id with lowest divergence
            most_divergent  — prompt_id with highest divergence
    """
    # Normalize input
    if isinstance(prompt_responses, (list, tuple)):
        prompt_responses = {i: r for i, r in enumerate(prompt_responses)}

    per_prompt = {}
    for pid, resps in prompt_responses.items():
        per_prompt[pid] = diverge(resps)

    if not per_prompt:
        return {
            'per_prompt': {},
            'mean_divergence': 0.0,
            'mean_unique': 0.0,
            'mean_length_cv': 0.0,
            'most_converged': None,
            'most_divergent': None,
        }

    divs = {pid: r['divergence_score'] for pid, r in per_prompt.items()}
    uniqs = {pid: r['unique_content_ratio'] for pid, r in per_prompt.items()}
    lcvs = {pid: r['length_cv'] for pid, r in per_prompt.items()}

    n = len(divs)
    mean_div = sum(divs.values()) / n
    mean_uniq = sum(uniqs.values()) / n
    mean_lcv = sum(lcvs.values()) / n

    most_converged = min(divs, key=divs.get)
    most_divergent = max(divs, key=divs.get)

    return {
        'per_prompt': per_prompt,
        'mean_divergence': round(mean_div, 4),
        'mean_unique': round(mean_uniq, 4),
        'mean_length_cv': round(mean_lcv, 4),
        'most_converged': most_converged,
        'most_divergent': most_divergent,
    }


# ═══════════════════════════════════════════════════════════
# CONVENIENCE — compare two specific responses
# ═══════════════════════════════════════════════════════════

def distance(a, b):
    """Jaccard distance between two texts. 0=identical vocabulary, 1=no overlap."""
    return round(_jaccard_distance(a, b), 4)
