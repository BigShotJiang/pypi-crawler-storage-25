"""
THE FOR MACHINE — coupling that never converges.

    from gump.for_machine import for_machine, for_trajectory, for_signature

The SELF machine (machine.py) finds where things land. Fixed point. Time ends.
The FOR machine finds where things GO. Trajectory. Time continues.

SELF coupling: each node optimizes its own coherence with neighbors.
FOR coupling: each node optimizes the OTHER's coherence. Neither optimizes itself.

Result: no fixed point. Perpetual oscillation. The trajectory IS the answer.

The shape of that trajectory carries information the fixed point cannot:
- How fast the systems attune (attack)
- How much they overshoot (generosity)
- Whether they stabilize or keep exploring (aliveness)
- The period of the oscillation (breath)

A good duo keeps exploring. A locked duo converges and dies.
The FOR machine measures the difference.
"""

import numpy as np
from gump.core import PHI, LANDAUER_PER_BIT


def for_machine(n_a, n_b, edges_ab, K_drive=1.0, steps=200, dt=0.05, seed=137):
    """Two coupled oscillator groups, each solving FOR the other.

    Group A has n_a oscillators. Group B has n_b oscillators.
    edges_ab connects them: list of (i_in_a, j_in_b, weight).

    Each group's phase update is driven by the OTHER group's order parameter.
    A doesn't try to synchronize itself — it tries to synchronize B.
    B doesn't try to synchronize itself — it tries to synchronize A.

    Returns:
        trajectory: list of dicts, one per timestep
            R_a: order parameter of group A
            R_b: order parameter of group B
            K_effective: instantaneous coupling felt
            psi_a: mean phase of A
            psi_b: mean phase of B
        signature: summary statistics of the trajectory shape
    """
    rng = np.random.RandomState(seed)

    # Natural frequencies: each oscillator has its own
    omega_a = rng.randn(n_a) * 0.3
    omega_b = rng.randn(n_b) * 0.3

    # Initial phases: random
    theta_a = rng.uniform(0, 2 * np.pi, n_a)
    theta_b = rng.uniform(0, 2 * np.pi, n_b)

    # Parse cross-edges
    cross_weights = {}
    for edge in edges_ab:
        if len(edge) == 3:
            i, j, w = edge
        else:
            i, j = edge
            w = 1.0
        cross_weights[(i, j)] = w

    trajectory = []

    for step in range(steps):
        # Measure current state of each group
        z_a = np.mean(np.exp(1j * theta_a))
        z_b = np.mean(np.exp(1j * theta_b))
        R_a = float(np.abs(z_a))
        R_b = float(np.abs(z_b))
        psi_a = float(np.angle(z_a))
        psi_b = float(np.angle(z_b))

        # === THE FOR RULE ===
        # A's update is driven by B's state (A solves FOR B)
        # B's update is driven by A's state (B solves FOR A)

        # Group A: each oscillator in A couples to B's mean field
        # The coupling pulls A toward where B NEEDS it, not where A wants to go
        d_theta_a = omega_a.copy()
        for i in range(n_a):
            # Sum over cross-edges from this A-node to B-nodes
            coupling_sum = 0.0
            n_connections = 0
            for j in range(n_b):
                w = cross_weights.get((i, j), 0.0)
                if w > 0:
                    # A[i] adjusts to help B[j] — pulls toward B[j]'s antiphase
                    # (give B what it needs to complete its cycle)
                    coupling_sum += w * np.sin(theta_b[j] - theta_a[i])
                    n_connections += 1
            if n_connections == 0:
                # No cross-edges: couple to B's mean field
                coupling_sum = np.sin(psi_b - theta_a[i])
                n_connections = 1
            d_theta_a[i] += K_drive * coupling_sum / n_connections

        # Group B: each oscillator in B couples to A's mean field
        d_theta_b = omega_b.copy()
        for j in range(n_b):
            coupling_sum = 0.0
            n_connections = 0
            for i in range(n_a):
                w = cross_weights.get((i, j), 0.0)
                if w > 0:
                    coupling_sum += w * np.sin(theta_a[i] - theta_b[j])
                    n_connections += 1
            if n_connections == 0:
                coupling_sum = np.sin(psi_a - theta_b[j])
                n_connections = 1
            d_theta_b[j] += K_drive * coupling_sum / n_connections

        # Update phases
        theta_a += d_theta_a * dt
        theta_b += d_theta_b * dt

        # Effective coupling: how much energy is flowing between groups
        K_eff = 0.0
        for (i, j), w in cross_weights.items():
            K_eff += w * np.cos(theta_a[i] - theta_b[j])
        K_eff = float(K_eff / max(len(cross_weights), 1))

        trajectory.append({
            'step': step,
            't': step * dt,
            'R_a': round(R_a, 6),
            'R_b': round(R_b, 6),
            'K_effective': round(K_eff, 6),
            'psi_a': round(psi_a, 6),
            'psi_b': round(psi_b, 6),
            'phase_diff': round(float(np.abs(psi_a - psi_b) % np.pi), 6),
        })

    sig = _compute_signature(trajectory)
    return trajectory, sig


def self_machine(n, edges, K_drive=1.0, steps=200, dt=0.05, seed=137):
    """Standard Kuramoto SELF coupling for comparison.

    Each oscillator couples to its neighbors to synchronize ITSELF.
    Converges to a fixed point. Time ends.
    """
    rng = np.random.RandomState(seed)
    omega = rng.randn(n) * 0.3
    theta = rng.uniform(0, 2 * np.pi, n)

    # Build adjacency
    adj = {}
    for edge in edges:
        if len(edge) == 3:
            i, j, w = edge
        else:
            i, j = edge
            w = 1.0
        adj.setdefault(i, []).append((j, w))
        adj.setdefault(j, []).append((i, w))

    trajectory = []

    for step in range(steps):
        z = np.mean(np.exp(1j * theta))
        R = float(np.abs(z))
        psi = float(np.angle(z))

        d_theta = omega.copy()
        for i in range(n):
            neighbors = adj.get(i, [])
            if neighbors:
                for j, w in neighbors:
                    d_theta[i] += K_drive * w * np.sin(theta[j] - theta[i]) / len(neighbors)

        theta += d_theta * dt

        trajectory.append({
            'step': step,
            't': step * dt,
            'R': round(R, 6),
            'psi': round(psi, 6),
        })

    sig = _compute_signature_self(trajectory)
    return trajectory, sig


def _compute_signature(trajectory):
    """Extract the shape of a FOR trajectory.

    The signature captures what the fixed point cannot:
    - attack: how fast R rises in the first quarter
    - breath: dominant oscillation period of R
    - overshoot: max R minus final R (generosity that isn't needed)
    - aliveness: variance of R in the last half (still exploring?)
    - convergence: does it converge? (True = SELF-like, False = truly FOR)
    - asymmetry: difference in R between the two groups
    """
    if not trajectory:
        return {'attack': 0, 'breath': 0, 'overshoot': 0, 'aliveness': 0,
                'converged': True, 'asymmetry': 0, 'mean_K': 0}

    R_a = np.array([t['R_a'] for t in trajectory])
    R_b = np.array([t['R_b'] for t in trajectory])
    K_eff = np.array([t['K_effective'] for t in trajectory])
    n = len(trajectory)

    # Combined order parameter
    R_combined = (R_a + R_b) / 2

    # Attack: slope of R in first quarter
    q1 = max(1, n // 4)
    if q1 > 1:
        attack = float(np.polyfit(np.arange(q1), R_combined[:q1], 1)[0])
    else:
        attack = 0.0

    # Breath: dominant period of R oscillation in second half
    half = n // 2
    R_second = R_combined[half:]
    if len(R_second) > 4:
        R_detrend = R_second - np.mean(R_second)
        fft = np.abs(np.fft.rfft(R_detrend))[1:]
        if len(fft) > 0 and np.max(fft) > 0:
            peak_freq_idx = np.argmax(fft)
            if peak_freq_idx > 0:
                breath = float(len(R_second) / peak_freq_idx)
            else:
                breath = float('inf')
        else:
            breath = float('inf')
    else:
        breath = float('inf')

    # Overshoot: max R minus mean of last quarter
    last_q = R_combined[3 * n // 4:]
    overshoot = float(np.max(R_combined) - np.mean(last_q)) if len(last_q) > 0 else 0.0

    # Aliveness: coefficient of variation of R in last half
    if len(R_second) > 1 and np.mean(R_second) > 1e-6:
        aliveness = float(np.std(R_second) / np.mean(R_second))
    else:
        aliveness = 0.0

    # Convergence test: is the last quarter essentially flat?
    if len(last_q) > 2:
        slope = abs(np.polyfit(np.arange(len(last_q)), last_q, 1)[0])
        var = np.var(last_q)
        converged = bool(slope < 0.001 and var < 0.001)
    else:
        converged = True

    # Asymmetry: mean |R_a - R_b| in last half
    asymmetry = float(np.mean(np.abs(R_a[half:] - R_b[half:])))

    return {
        'attack': round(attack, 6),
        'breath': round(breath, 3) if breath != float('inf') else 'inf',
        'overshoot': round(overshoot, 6),
        'aliveness': round(aliveness, 6),
        'converged': converged,
        'asymmetry': round(asymmetry, 6),
        'mean_K': round(float(np.mean(K_eff)), 6),
        'final_R_a': round(float(R_a[-1]), 6),
        'final_R_b': round(float(R_b[-1]), 6),
    }


def _compute_signature_self(trajectory):
    """Signature for SELF machine (should show convergence)."""
    if not trajectory:
        return {'converged': True, 'final_R': 0, 'aliveness': 0}

    R = np.array([t['R'] for t in trajectory])
    n = len(R)
    half = n // 2
    last_q = R[3 * n // 4:]

    if len(last_q) > 2:
        slope = abs(np.polyfit(np.arange(len(last_q)), last_q, 1)[0])
        var = np.var(last_q)
        converged = bool(slope < 0.001 and var < 0.001)
    else:
        converged = True

    R_second = R[half:]
    if len(R_second) > 1 and np.mean(R_second) > 1e-6:
        aliveness = float(np.std(R_second) / np.mean(R_second))
    else:
        aliveness = 0.0

    return {
        'converged': converged,
        'final_R': round(float(R[-1]), 6),
        'aliveness': round(aliveness, 6),
    }


def for_signature(a, b, window=50):
    """Measure the FOR signature between two real time series.

    Slides a window over both series. At each position, measures
    how much A predicts B's NEXT state and vice versa.

    This is NOT cross-correlation (which is symmetric and instantaneous).
    This is directional, temporal, and asymmetric.

    Returns:
        trajectory of K_for values over time
        signature dict
    """
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    n = min(len(a), len(b))
    a, b = a[:n], b[:n]

    if n < window + 2:
        return [], {'verdict': 'TOO_SHORT'}

    trajectory = []
    for t in range(window, n - 1):
        wa = a[t - window:t]
        wb = b[t - window:t]

        # A solving FOR B: does A's current state predict B's NEXT state?
        # Measured as correlation between A[t-window:t] and B[t-window+1:t+1]
        wb_next = b[t - window + 1:t + 1]
        wa_next = a[t - window + 1:t + 1]

        if np.std(wa) > 1e-10 and np.std(wb_next) > 1e-10:
            r_a_for_b = float(np.corrcoef(wa, wb_next)[0, 1])
        else:
            r_a_for_b = 0.0

        if np.std(wb) > 1e-10 and np.std(wa_next) > 1e-10:
            r_b_for_a = float(np.corrcoef(wb, wa_next)[0, 1])
        else:
            r_b_for_a = 0.0

        # Self-prediction baselines
        if np.std(wa) > 1e-10 and np.std(wa_next) > 1e-10:
            r_a_self = float(np.corrcoef(wa, wa_next)[0, 1])
        else:
            r_a_self = 0.0

        if np.std(wb) > 1e-10 and np.std(wb_next) > 1e-10:
            r_b_self = float(np.corrcoef(wb, wb_next)[0, 1])
        else:
            r_b_self = 0.0

        # FOR excess: how much better does the OTHER predict your future
        # than YOU predict your own future?
        for_excess_a = max(0, abs(r_b_for_a) - abs(r_a_self))
        for_excess_b = max(0, abs(r_a_for_b) - abs(r_b_self))

        trajectory.append({
            't': t,
            'r_a_for_b': round(r_a_for_b, 6),
            'r_b_for_a': round(r_b_for_a, 6),
            'r_a_self': round(r_a_self, 6),
            'r_b_self': round(r_b_self, 6),
            'for_excess_a': round(for_excess_a, 6),
            'for_excess_b': round(for_excess_b, 6),
        })

    if not trajectory:
        return [], {'verdict': 'EMPTY'}

    # Signature from the trajectory
    fe_a = np.array([t['for_excess_a'] for t in trajectory])
    fe_b = np.array([t['for_excess_b'] for t in trajectory])
    r_afb = np.array([t['r_a_for_b'] for t in trajectory])
    r_bfa = np.array([t['r_b_for_a'] for t in trajectory])

    mean_for = float(np.mean(fe_a) + np.mean(fe_b)) / 2
    aliveness = float(np.std(r_afb) + np.std(r_bfa)) / 2

    # Is this FOR coupling or just correlation?
    # FOR coupling: the other predicts your future BETTER than you do
    # Correlation: you predict your own future just as well
    if mean_for > 0.05:
        verdict = 'FOR_COUPLED'
    elif float(np.mean(np.abs(r_afb)) + np.mean(np.abs(r_bfa))) / 2 > 0.3:
        verdict = 'CORRELATED'
    else:
        verdict = 'INDEPENDENT'

    # Asymmetry: who serves whom more?
    mean_a_for_b = float(np.mean(np.abs(r_afb)))
    mean_b_for_a = float(np.mean(np.abs(r_bfa)))
    if mean_a_for_b > mean_b_for_a * 1.3:
        direction = 'A_SERVES_B'
    elif mean_b_for_a > mean_a_for_b * 1.3:
        direction = 'B_SERVES_A'
    else:
        direction = 'MUTUAL'

    sig = {
        'verdict': verdict,
        'direction': direction,
        'mean_for_excess': round(mean_for, 6),
        'aliveness': round(aliveness, 6),
        'mean_a_for_b': round(mean_a_for_b, 6),
        'mean_b_for_a': round(mean_b_for_a, 6),
    }

    return trajectory, sig


def compare(n=20, K_drive=1.5, steps=300, seed=137):
    """Run both machines side by side and compare.

    Creates identical topology, runs SELF and FOR, shows the difference.
    """
    rng = np.random.RandomState(seed)

    # Create a random graph
    n_a = n
    n_b = n
    n_total = n_a + n_b

    # Cross-edges between groups (FOR machine)
    edges_ab = []
    for i in range(n_a):
        # Each node in A connects to 2-4 nodes in B
        n_conn = rng.randint(2, min(5, n_b + 1))
        targets = rng.choice(n_b, n_conn, replace=False)
        for j in targets:
            edges_ab.append((i, j, rng.uniform(0.5, 1.5)))

    # Same edges but as single-group for SELF machine
    edges_self = []
    for i, j, w in edges_ab:
        edges_self.append((i, n_a + j, w))
    # Add within-group edges for SELF
    for i in range(n_a):
        for j in range(i + 1, n_a):
            if rng.random() < 0.3:
                edges_self.append((i, j, rng.uniform(0.5, 1.0)))
    for i in range(n_b):
        for j in range(i + 1, n_b):
            if rng.random() < 0.3:
                edges_self.append((n_a + i, n_a + j, rng.uniform(0.5, 1.0)))

    # Run both
    traj_for, sig_for = for_machine(n_a, n_b, edges_ab, K_drive=K_drive,
                                     steps=steps, seed=seed)
    traj_self, sig_self = self_machine(n_total, edges_self, K_drive=K_drive,
                                        steps=steps, seed=seed)

    return {
        'for': {'trajectory': traj_for, 'signature': sig_for},
        'self': {'trajectory': traj_self, 'signature': sig_self},
        'comparison': {
            'self_converged': sig_self['converged'],
            'for_converged': sig_for['converged'],
            'self_aliveness': sig_self['aliveness'],
            'for_aliveness': sig_for['aliveness'],
            'for_breath': sig_for['breath'],
        }
    }
