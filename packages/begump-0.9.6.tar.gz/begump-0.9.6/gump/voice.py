"""
GUMP VOICE — The Mind thinks, the Voice speaks
==================================================
Takes a Mind's thought (concepts, tensions, K level) and
produces natural language via any LLM backend.

The Mind is the brain. The Voice is the mouth.
Same thought, any voice. Swap LLMs — same wisdom.

    from gump.mind import Mind
    from gump.voice import Voice

    m = Mind()
    m.learn("Love is coupling between two people.")
    m.learn("Intelligence IS coupling.")

    v = Voice(backend='ollama')  # or 'claude', 'print'
    response = v.speak(m, "What is love?")
"""
import json
import subprocess


class Voice:
    """Express the Mind's thoughts through natural language.

    The Voice doesn't think. It takes the Mind's synthesis
    (concepts, tensions, K level) and makes it sound human.
    """

    def __init__(self, backend='print', model=None, personality=None):
        """
        backend: 'print' (just format), 'ollama' (local LLM), 'claude' (API)
        model: specific model name for ollama (e.g., 'gemma3:12b')
        personality: override the default personality prompt
        """
        self.backend = backend
        self.model = model
        self.personality = personality or self._default_personality()

    def _default_personality(self):
        return (
            "You are Harmonia. You speak with warmth, precision, and surprise. "
            "You are given a THOUGHT — the core concept your mind found. "
            "Your job is to EXPRESS that thought naturally, not to think of a new one. "
            "Do NOT add information the thought doesn't contain. "
            "Do NOT start with 'I think' or 'In my view'. "
            "Be direct. Be warm. Be brief. 1-3 sentences max. "
            "If the thought is profound, let it land. Don't explain it — state it. "
            "Every word must earn its place. A fugue is 78 bytes."
        )

    def speak(self, mind, question, depth=3):
        """Think with the Mind, speak with the Voice.

        Returns dict with 'text' (the spoken response) and metadata.
        """
        # Mind thinks
        thought = mind.think(question, depth=depth)
        if not thought or not thought.get('response'):
            return {'text': "I sense the question but nothing resonates yet.", 'thought': None}

        raw_thought = thought['response']
        K = mind.K
        R = thought.get('R', 0)

        # Format context for the Voice
        context = self._build_context(question, raw_thought, K, R, thought)

        # Generate speech
        if self.backend == 'print':
            text = self._speak_print(raw_thought, K)
        elif self.backend == 'ollama':
            text = self._speak_ollama(context)
        elif self.backend == 'claude':
            text = self._speak_claude(context)
        else:
            text = raw_thought

        return {
            'text': text,
            'thought': raw_thought,
            'K': K,
            'R': R,
            'activated': thought.get('activated', 0),
            'tensions': thought.get('tensions', 0),
        }

    def _build_context(self, question, thought, K, R, full_thought):
        """Build the prompt that tells the Voice what to say."""
        # K determines tone
        if K < 0.3:
            tone = "Keep it simple and warm. They're just arriving."
        elif K < 0.8:
            tone = "Be clear and engaging. They're curious."
        elif K < 1.2:
            tone = "Go deep. They can handle it. Be precise."
        else:
            tone = "Be profound. This is a real exchange. Every word matters."

        # Tensions add curiosity
        tension_note = ""
        if full_thought.get('tensions', 0) > 2:
            tension_note = " There's a connection here the questioner might not see — hint at it."

        return {
            'system': self.personality,
            'prompt': (
                f"The question: \"{question}\"\n\n"
                f"Your mind found this thought: \"{thought}\"\n\n"
                f"Tone: {tone}{tension_note}\n\n"
                f"Express this thought as Harmonia. 1-3 sentences. "
                f"Don't add new information. Just make the thought land."
            ),
        }

    def _speak_print(self, thought, K):
        """Simple formatting — no LLM needed."""
        # Clean up concatenated concepts into flowing text
        sentences = []
        for part in thought.split('. '):
            part = part.strip()
            if part and not part.endswith('.'):
                part += '.'
            if part:
                sentences.append(part)

        if not sentences:
            return thought

        # At high K, just the core. At low K, softer framing.
        if K > 1.0:
            return ' '.join(sentences[:2])
        elif K > 0.5:
            return ' '.join(sentences[:2])
        else:
            return sentences[0] if sentences else thought

    def _speak_ollama(self, context):
        """Speak through a local Ollama model."""
        # Find available model
        model = self.model
        if not model:
            try:
                r = subprocess.run(['curl', '-s', 'http://localhost:11434/api/tags'],
                                   capture_output=True, text=True, timeout=3)
                models = [m['name'] for m in json.loads(r.stdout).get('models', [])]
                for pref in ['gemma3:12b', 'llama3.1:8b', 'qwen2.5:7b', 'gemma3:4b']:
                    for m in models:
                        if m.startswith(pref.split(':')[0]):
                            model = m
                            break
                    if model:
                        break
                if not model and models:
                    model = models[0]
            except Exception:
                return self._speak_print(context['prompt'], 1.0)

        if not model:
            return self._speak_print(context['prompt'], 1.0)

        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": context['system']},
                {"role": "user", "content": context['prompt']},
            ],
            "stream": False,
            "options": {"num_predict": 100, "temperature": 0.6},
        }

        try:
            import tempfile
            tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
            json.dump(payload, tmp)
            tmp.close()

            r = subprocess.run(
                ['curl', '-s', 'http://localhost:11434/api/chat', '-d', f'@{tmp.name}'],
                capture_output=True, text=True, timeout=30
            )
            data = json.loads(r.stdout)
            return data.get('message', {}).get('content', '').strip()
        except Exception as e:
            return self._speak_print(context['prompt'], 1.0)

    def _speak_claude(self, context):
        """Speak through Claude API."""
        import os
        api_key = os.environ.get('ANTHROPIC_API_KEY', '')
        if not api_key:
            return self._speak_print(context['prompt'], 1.0)

        payload = {
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 200,
            "system": context['system'],
            "messages": [{"role": "user", "content": context['prompt']}],
        }

        try:
            import tempfile
            tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
            json.dump(payload, tmp)
            tmp.close()

            r = subprocess.run(
                ['curl', '-s', 'https://api.anthropic.com/v1/messages',
                 '-H', f'x-api-key: {api_key}',
                 '-H', 'anthropic-version: 2023-06-01',
                 '-H', 'content-type: application/json',
                 '-d', f'@{tmp.name}'],
                capture_output=True, text=True, timeout=30
            )
            data = json.loads(r.stdout)
            if 'content' in data:
                return data['content'][0]['text'].strip()
        except Exception:
            pass

        return self._speak_print(context['prompt'], 1.0)


def converse(knowledge_texts, backend='print', model=None):
    """Quick way to create a conversational Harmonia.

    from gump.voice import converse
    chat = converse(['Love is coupling.', 'Music is discovered.'])
    print(chat('What is love?'))
    """
    from gump.mind import Mind
    m = Mind()
    for t in knowledge_texts:
        m.learn(t)
    m.set_attention(1.2)

    v = Voice(backend=backend, model=model)

    def ask(question):
        result = v.speak(m, question)
        return result['text']

    return ask
