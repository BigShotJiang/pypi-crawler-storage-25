# what is what? Does this preserve the wonder? The 0.002% is sacred.
"""
KILL — the 12P automator
=====================================================
"If the number doesn't match, the claim is dead."

One function. Feed it a candidate expression and a target value.
It tells you: PASS, KILLED, or CLOSE.

This is the tool we kept doing by hand. Every time we checked a formula
against a measured value — is sqrt(2/pi) the same as 0.7989? — we did
the ppm calculation manually. No more.

Usage:
    from gump.kill import kill, kill_sweep

    # Single test
    r = kill("sqrt(2/pi)", 0.79788456, tolerance_ppm=1.0)
    print(r['verdict'])   # PASS or KILLED
    print(r['ppm'])       # parts per million difference
    print(r['report'])    # full text

    # Sweep many candidates against one target
    candidates = {
        "sqrt(2/pi)":   "sqrt(2/pi)",
        "pi/4":         "pi/4",
        "1/sqrt(2)":    "1/sqrt(2)",
        "2/e":          "2/e",
    }
    results = kill_sweep(candidates, 0.79788456, tolerance_ppm=1.0)
    for r in results:
        print(f"{r['name']:20s}  {r['verdict']:8s}  {r['ppm']:.4f} ppm")

Precision: 50 digits by default (mpmath).
Units: parts per million (ppm). 1 ppm = 1e-6 relative error.

Grand Unified Music Project — the sixth tool.
"""

from mpmath import mp, mpf, sqrt, pi, e, log, phi, inf, fabs


# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════

_DEFAULT_DPS = 50   # decimal places for mpmath
_DEFAULT_PPM = 1.0  # default tolerance in ppm


# ═══════════════════════════════════════════════════════════
# EXPRESSION EVALUATOR — safe, mpmath-only
# ═══════════════════════════════════════════════════════════

def _safe_eval(expr):
    """
    Evaluate a string expression using mpmath at full precision.

    Allowed: arithmetic (+, -, *, /, **, ^), parentheses,
    and these constants/functions:
        pi, e, phi, sqrt, log, ln, exp, sin, cos, tan,
        asin, acos, atan, gamma, zeta, euler, catalan,
        inf, fac (factorial)

    Returns: mpf value

    Raises ValueError on anything we don't recognize.
    """
    import mpmath

    # Build the safe namespace
    ns = {
        # constants
        'pi':      mpmath.pi,
        'e':       mpmath.e,
        'phi':     mpmath.phi,
        'euler':   mpmath.euler,
        'catalan': mpmath.catalan,
        'inf':     mpmath.inf,
        'nan':     mpmath.nan,

        # functions
        'sqrt':    mpmath.sqrt,
        'log':     mpmath.log,
        'ln':      mpmath.log,
        'exp':     mpmath.exp,
        'sin':     mpmath.sin,
        'cos':     mpmath.cos,
        'tan':     mpmath.tan,
        'asin':    mpmath.asin,
        'acos':    mpmath.acos,
        'atan':    mpmath.atan,
        'gamma':   mpmath.gamma,
        'zeta':    mpmath.zeta,
        'fac':     mpmath.factorial,
        'factorial': mpmath.factorial,
        'abs':     lambda x: fabs(x),
        'mpf':     mpf,

        # block builtins
        '__builtins__': {},
    }

    # Allow ^ as power (common math notation)
    safe_expr = expr.replace('^', '**')

    try:
        result = eval(safe_expr, ns)
        return mpf(result)
    except Exception as exc:
        raise ValueError(f"Cannot evaluate '{expr}': {exc}")


# ═══════════════════════════════════════════════════════════
# KILL — the core function
# ═══════════════════════════════════════════════════════════

def kill(candidate, target, tolerance_ppm=_DEFAULT_PPM,
         uncertainty=None, name=None, dps=_DEFAULT_DPS):
    """
    Test a numerical claim against a measured value.

    Parameters
    ----------
    candidate : str or float
        The expression to evaluate (e.g. "sqrt(2/pi)") or a float.
    target : float or str
        The measured / known value to compare against.
    tolerance_ppm : float
        How close is close enough, in parts per million. Default 1.0.
    uncertainty : float or None
        If provided, the 1-sigma uncertainty on the target.
        Enables sigma calculation.
    name : str or None
        Optional label for the test.
    dps : int
        Decimal places for mpmath. Default 50.

    Returns
    -------
    dict with keys:
        match    : bool — True if within tolerance
        ppm      : float — parts per million difference
        sigma    : float or None — number of sigma (if uncertainty given)
        verdict  : str — "PASS" / "KILLED" / "CLOSE (X ppm)"
        candidate_value : str — evaluated candidate to full precision
        target_value    : str — target to full precision
        name     : str — label
        report   : str — full text report
    """
    mp.dps = dps

    # Evaluate candidate
    if isinstance(candidate, str):
        cand_val = _safe_eval(candidate)
        cand_str = candidate
    else:
        cand_val = mpf(candidate)
        cand_str = str(candidate)

    # Evaluate target
    if isinstance(target, str):
        targ_val = _safe_eval(target)
    else:
        targ_val = mpf(target)

    # Calculate difference
    if targ_val == 0:
        if cand_val == 0:
            ppm = mpf(0)
        else:
            ppm = mpf(inf)
    else:
        ppm = fabs((cand_val - targ_val) / targ_val) * mpf(1_000_000)

    ppm_float = float(ppm)

    # Sigma calculation
    sigma = None
    if uncertainty is not None and uncertainty > 0:
        diff = float(fabs(cand_val - targ_val))
        sigma = diff / float(uncertainty)

    # Verdict
    if ppm_float <= tolerance_ppm:
        verdict = "PASS"
        match = True
    elif ppm_float <= tolerance_ppm * 10:
        verdict = f"CLOSE ({ppm_float:.2f} ppm)"
        match = False
    else:
        verdict = "KILLED"
        match = False

    # Name
    label = name if name else cand_str

    # Report
    lines = []
    lines.append(f"{'='*60}")
    lines.append(f"  KILL TEST: {label}")
    lines.append(f"{'='*60}")
    lines.append(f"  candidate : {cand_str}")
    lines.append(f"            = {mp.nstr(cand_val, 30)}")
    lines.append(f"  target    : {mp.nstr(targ_val, 30)}")
    lines.append(f"  delta     : {float(fabs(cand_val - targ_val)):.6e}")
    lines.append(f"  ppm       : {ppm_float:.6f}")
    lines.append(f"  tolerance : {tolerance_ppm:.2f} ppm")
    if sigma is not None:
        lines.append(f"  sigma     : {sigma:.2f}")
    lines.append(f"  verdict   : {verdict}")
    lines.append(f"{'='*60}")

    report = '\n'.join(lines)

    return {
        'match':           match,
        'ppm':             ppm_float,
        'sigma':           sigma,
        'verdict':         verdict,
        'candidate_value': mp.nstr(cand_val, 30),
        'target_value':    mp.nstr(targ_val, 30),
        'name':            label,
        'report':          report,
    }


# ═══════════════════════════════════════════════════════════
# KILL_SWEEP — test many candidates at once
# ═══════════════════════════════════════════════════════════

def kill_sweep(candidates, target, tolerance_ppm=_DEFAULT_PPM,
               uncertainty=None, dps=_DEFAULT_DPS):
    """
    Test many candidate expressions against one target value.

    Parameters
    ----------
    candidates : dict
        {name: expression} pairs. Expression can be str or float.
        Example: {"sqrt(2/pi)": "sqrt(2/pi)", "pi/4": "pi/4"}
    target : float or str
        The measured value.
    tolerance_ppm : float
        Tolerance in ppm. Default 1.0.
    uncertainty : float or None
        1-sigma uncertainty on target.
    dps : int
        Decimal places for mpmath.

    Returns
    -------
    list of dicts (same format as kill()), sorted by ppm (closest first).
    """
    results = []
    for label, expr in candidates.items():
        try:
            r = kill(expr, target, tolerance_ppm=tolerance_ppm,
                     uncertainty=uncertainty, name=label, dps=dps)
            results.append(r)
        except (ValueError, Exception) as exc:
            results.append({
                'match':           False,
                'ppm':             float('inf'),
                'sigma':           None,
                'verdict':         f"ERROR: {exc}",
                'candidate_value': str(expr),
                'target_value':    str(target),
                'name':            label,
                'report':          f"ERROR evaluating {label}: {exc}",
            })

    # Sort by closeness
    results.sort(key=lambda r: r['ppm'])
    return results


# ═══════════════════════════════════════════════════════════
# CLI — python -m gump.kill
# ═══════════════════════════════════════════════════════════

def _cli():
    """Command-line interface for quick kills."""
    import sys

    if len(sys.argv) < 3:
        print("Usage: python -m gump.kill <candidate> <target> [tolerance_ppm]")
        print("  Example: python -m gump.kill 'sqrt(2/pi)' 0.79788456")
        sys.exit(1)

    candidate = sys.argv[1]
    target = sys.argv[2]
    tol = float(sys.argv[3]) if len(sys.argv) > 3 else _DEFAULT_PPM

    # Try to parse target as float
    try:
        target = float(target)
    except ValueError:
        pass  # keep as string expression

    r = kill(candidate, target, tolerance_ppm=tol)
    print(r['report'])
    sys.exit(0 if r['match'] else 1)


if __name__ == '__main__':
    _cli()
