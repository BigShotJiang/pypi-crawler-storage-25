"""GAC Workflow MCP server — stdio transport, wraps /api/v1/projects/workflow-agents REST API."""

__version__ = "0.1.0"
