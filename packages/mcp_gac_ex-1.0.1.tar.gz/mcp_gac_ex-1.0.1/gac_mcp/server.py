"""
MCP tools + prompts.

- Tool docstrings: exposed to the LLM as tool descriptions (when to call, parameters).
- @mcp.prompt(): reusable instruction templates the client may surface as "prompts".
"""

from __future__ import annotations

import json
from typing import Annotated

from mcp.server.fastmcp import FastMCP

from gac_mcp.client import GacApiClient, GacApiError
from gac_mcp.config import load_config

mcp = FastMCP("gac-workflow")


def _json_dumps(data: object) -> str:
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


def _resolve_project_id(explicit: int | None) -> int:
    cfg = load_config()
    if explicit is not None:
        return explicit
    if cfg.default_project_id is not None:
        return cfg.default_project_id
    raise ValueError(
        "project_id is required (or set GAC_DEFAULT_PROJECT_ID in MCP env)."
    )


def _is_node_list(value: object) -> bool:
    return isinstance(value, list) and all(isinstance(item, dict) for item in value)


def _is_edge_list(value: object) -> bool:
    return isinstance(value, list) and all(isinstance(item, dict) for item in value)


def _normalize_nodes(nodes: list[dict]) -> list[dict]:
    normalized: list[dict] = []
    for node in nodes:
        node_copy = dict(node)
        node_type = str(node_copy.get("type", "")).strip().lower()
        data = node_copy.get("data")
        data_dict = dict(data) if isinstance(data, dict) else {}

        # Runtime in BE defaults agent.sourceType to {"type":"text"}.
        # We persist the same default from MCP to avoid null/missing fields in UI.
        if node_type == "agent" and data_dict.get("sourceType") is None:
            data_dict["sourceType"] = {"type": "text"}

        node_copy["data"] = data_dict
        normalized.append(node_copy)
    return normalized


def _preflight_validate_graph(nodes: list[dict], edges: list[dict]) -> str | None:
    node_ids = {
        str(node.get("id"))
        for node in nodes
        if node.get("id") is not None and str(node.get("id")).strip()
    }
    if len(node_ids) != len(nodes):
        return "Invalid graph: each node must have a unique non-empty `id`."

    start_count = sum(
        1 for node in nodes if str(node.get("type", "")).strip().lower() == "start"
    )
    end_count = sum(
        1 for node in nodes if str(node.get("type", "")).strip().lower() == "end"
    )
    if start_count != 1:
        return "Invalid graph: must contain exactly one `start` node."
    if end_count < 1:
        return "Invalid graph: must contain at least one `end` node."

    for edge in edges:
        source = edge.get("source")
        target = edge.get("target")
        if not source or not target:
            return "Invalid graph: each edge must include non-empty `source` and `target`."
        if str(source) not in node_ids or str(target) not in node_ids:
            return (
                "Invalid graph: edge endpoint not found in nodes "
                f"(source={source}, target={target})."
            )

    return None


# ---------------------------------------------------------------------------
# Tools — docstring đầu (summary) + phần Args/Returns là "prompt" cho model
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_projects(
    page: Annotated[int, "1-based page index."] = 1,
    page_size: Annotated[int, "Items per page (API max 100)."] = 50,
    search: Annotated[
        str | None,
        "Optional search in project code, name, or description.",
    ] = None,
) -> str:
    """List projects the authenticated user can access (owned or invited; admins see all).

    Call this first to obtain project_id values for list_workflows and other project-scoped tools.
    """
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.list_projects(
                page=page, page_size=min(page_size, 100), search=search
            )
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def list_workflows(
    project_id: Annotated[
        int | None,
        "Numeric project ID. If omitted, uses GAC_DEFAULT_PROJECT_ID from MCP env.",
    ] = None,
    page: Annotated[int, "1-based page index."] = 1,
    page_size: Annotated[int, "Items per page (max reasonable e.g. 50)."] = 50,
    name: Annotated[
        str | None,
        "Optional filter substring for workflow name.",
    ] = None,
) -> str:
    """List workflow agents in a project (member access or higher).

    Use first to discover workflow IDs and names before get_workflow or edits.
    """
    pid = _resolve_project_id(project_id)
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.list_workflows(
                pid, page=page, page_size=page_size, name=name
            )
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def get_workflow(
    workflow_id: Annotated[int, "Workflow agent primary key."],
    project_id: Annotated[
        int | None,
        "Project ID; omit if GAC_DEFAULT_PROJECT_ID is set in MCP env.",
    ] = None,
) -> str:
    """Fetch one workflow's draft definition: nodes, edges, publish metadata.

    Use before update_workflow to read current graph JSON.
    """
    pid = _resolve_project_id(project_id)
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.get_workflow(pid, workflow_id)
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def create_workflow(
    name: Annotated[str, "Human-readable workflow name."],
    nodes_json: Annotated[
        str,
        'JSON array of node objects, e.g. [{"id":"n1","type":"start",...}]. Must be valid JSON string.',
    ],
    edges_json: Annotated[
        str,
        'JSON array of edge objects, e.g. [{"id":"e1","source":"n1","target":"n2"}].',
    ],
    project_id: Annotated[int | None, "Project ID (or use GAC_DEFAULT_PROJECT_ID)."] = None,
    description: Annotated[str | None, "Optional description."] = None,
) -> str:
    """Create a new workflow agent in the project (project owner only).

    Build nodes_json/edges_json to match workflow DSL.
    Minimum valid graph:
    - one `start` node
    - one `end` node
    - at least one edge from start to end (directly or via intermediate nodes)

    Recommended creation flow:
    1) Ask user to confirm node count and each node's purpose
    2) Build nodes JSON first
    3) Build edges JSON by explicit source->target mapping
    4) Validate every edge source/target exists in nodes list
    """
    pid = _resolve_project_id(project_id)
    try:
        nodes = json.loads(nodes_json)
        edges = json.loads(edges_json)
    except json.JSONDecodeError as e:
        return f"Invalid JSON in nodes_json/edges_json: {e}"
    if not _is_node_list(nodes):
        return "Invalid nodes_json: expected a JSON array of node objects."
    if not _is_edge_list(edges):
        return "Invalid edges_json: expected a JSON array of edge objects."
    nodes = _normalize_nodes(nodes)
    graph_error = _preflight_validate_graph(nodes, edges)
    if graph_error:
        return graph_error
    body: dict = {"name": name, "nodes": nodes, "edges": edges}
    if description is not None:
        body["description"] = description
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.create_workflow(pid, body)
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def update_workflow(
    workflow_id: Annotated[int, "Workflow to update."],
    name: Annotated[str | None, "New name, or omit to leave unchanged."] = None,
    description: Annotated[str | None, "New description, or omit."] = None,
    nodes_json: Annotated[
        str | None,
        "If provided: full JSON array string of nodes replacing draft nodes.",
    ] = None,
    edges_json: Annotated[
        str | None,
        "If provided: full JSON array string of edges replacing draft edges.",
    ] = None,
    project_id: Annotated[int | None, "Project ID (or GAC_DEFAULT_PROJECT_ID)."] = None,
) -> str:
    """Update workflow draft (owner only). Omit fields you do not want to change.

    Prefer fetching with get_workflow first, then modify nodes/edges JSON locally.
    """
    pid = _resolve_project_id(project_id)
    body: dict = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if nodes_json is not None:
        try:
            parsed_nodes = json.loads(nodes_json)
        except json.JSONDecodeError as e:
            return f"Invalid nodes_json: {e}"
        if not _is_node_list(parsed_nodes):
            return "Invalid nodes_json: expected a JSON array of node objects."
        body["nodes"] = _normalize_nodes(parsed_nodes)
    if edges_json is not None:
        try:
            parsed_edges = json.loads(edges_json)
        except json.JSONDecodeError as e:
            return f"Invalid edges_json: {e}"
        if not _is_edge_list(parsed_edges):
            return "Invalid edges_json: expected a JSON array of edge objects."
        body["edges"] = parsed_edges
    if "nodes" in body and "edges" in body:
        graph_error = _preflight_validate_graph(body["nodes"], body["edges"])
        if graph_error:
            return graph_error
    if not body:
        return "No fields to update."
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.update_workflow(pid, workflow_id, body)
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def delete_workflow(
    workflow_id: Annotated[int, "Workflow to delete."],
    project_id: Annotated[int | None, "Project ID (or GAC_DEFAULT_PROJECT_ID)."] = None,
) -> str:
    """Delete a workflow draft (owner only).

    Safety rule:
    - Always call `get_workflow` first and summarize what will be deleted.
    - Ask for explicit confirmation before deleting.
    """
    pid = _resolve_project_id(project_id)
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.delete_workflow(pid, workflow_id)
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def publish_workflow(
    workflow_id: Annotated[int, "Workflow to publish."],
    project_id: Annotated[int | None, "Project ID (or GAC_DEFAULT_PROJECT_ID)."] = None,
    version_name: Annotated[str | None, "Optional version label."] = None,
    release_notes: Annotated[str | None, "Optional release notes."] = None,
) -> str:
    """Snapshot current draft as an immutable published version (owner only).

    Call after validate_workflow_draft when the graph is ready for production use.
    """
    pid = _resolve_project_id(project_id)
    body: dict = {}
    if version_name is not None:
        body["name"] = version_name
    if release_notes is not None:
        body["release_notes"] = release_notes
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.publish_workflow(pid, workflow_id, body)
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def list_workflow_versions(
    workflow_id: Annotated[int, "Workflow ID to query version history."],
    project_id: Annotated[int | None, "Project ID (or GAC_DEFAULT_PROJECT_ID)."] = None,
    page: Annotated[int, "1-based page index."] = 1,
    page_size: Annotated[int, "Items per page (default 20)."] = 20,
    named_only: Annotated[
        bool,
        "If true, return only named versions.",
    ] = False,
    created_by: Annotated[
        int | None,
        "Optional creator user_id filter.",
    ] = None,
) -> str:
    """List version history for a workflow (member access or higher)."""
    pid = _resolve_project_id(project_id)
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.list_workflow_versions(
                pid,
                workflow_id,
                page=page,
                page_size=page_size,
                named_only=named_only,
                created_by=created_by,
            )
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def get_workflow_version(
    workflow_id: Annotated[int, "Workflow ID."],
    version_id: Annotated[int, "Version ID."],
    project_id: Annotated[int | None, "Project ID (or GAC_DEFAULT_PROJECT_ID)."] = None,
) -> str:
    """Get one workflow version with full DSL snapshot."""
    pid = _resolve_project_id(project_id)
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.get_workflow_version(pid, workflow_id, version_id)
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def delete_workflow_version(
    workflow_id: Annotated[int, "Workflow ID."],
    version_id: Annotated[int, "Version ID to delete."],
    project_id: Annotated[int | None, "Project ID (or GAC_DEFAULT_PROJECT_ID)."] = None,
) -> str:
    """Delete one workflow version (owner only)."""
    pid = _resolve_project_id(project_id)
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.delete_workflow_version(pid, workflow_id, version_id)
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def restore_workflow_version(
    workflow_id: Annotated[int, "Workflow ID."],
    version_id: Annotated[int, "Version ID to restore into draft."],
    project_id: Annotated[int | None, "Project ID (or GAC_DEFAULT_PROJECT_ID)."] = None,
) -> str:
    """Restore a version snapshot into current draft (owner only)."""
    pid = _resolve_project_id(project_id)
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        try:
            data = await client.restore_workflow_version(pid, workflow_id, version_id)
        except GacApiError as e:
            return f"API error: {e}"
    return _json_dumps(data)


@mcp.tool()
async def execute_workflow(
    workflow_id: Annotated[int, "Saved workflow ID to run."],
    execution_request_json: Annotated[
        str,
        "Full JSON object matching WorkflowExecuteRequest: messages, nodes, edges "
        "(see API schema). Usually copy nodes/edges from get_workflow and add messages.",
    ],
    project_id: Annotated[
        int | None,
        "Not sent to execute path; only used if you need context in error messages.",
    ] = None,
) -> str:
    """Run workflow execution (SSE). Uses bearer token from JWT direct mode or PAT exchange."""
    _ = project_id  # reserved for future path variants
    cfg = load_config()
    if not cfg.enable_execute:
        return (
            "execute_workflow is disabled. Set env GAC_MCP_ENABLE_EXECUTE=true "
            "and ensure the backend accepts Bearer for POST "
            f"/projects/workflow-agents/{workflow_id}/execute "
            "(today may require session; see docs)."
        )
    try:
        body = json.loads(execution_request_json)
    except json.JSONDecodeError as e:
        return f"Invalid execution_request_json: {e}"
    async with GacApiClient(cfg) as client:
        try:
            preview = await client.execute_workflow_stream_preview(workflow_id, body)
        except GacApiError as e:
            return (
                f"API error while executing workflow: {e}\n"
                "Check PAT scope (workflow:execute), project binding, and token exchange config."
            )
    return preview


# ---------------------------------------------------------------------------
# MCP Prompts — template strings some clients list as "prompts" (khác tool descriptions)
# ---------------------------------------------------------------------------


@mcp.prompt()
def plan_new_workflow(goal: str) -> str:
    """Guide user from requirement to valid workflow DSL."""
    return f"""You are assisting with GAC agent workflows.

User goal:
{goal}

Steps:
1. Ask for project_id if unknown.
2. Call list_workflows to see existing names.
3. Propose graph plan with exact node count:
   - node_id
   - node_type
   - purpose per node
4. Propose edge map with explicit source->target for every connection.
5. Convert to valid nodes_json and edges_json.
6. Call create_workflow.
7. Remind: only project owners can create/update/delete.
"""


@mcp.prompt()
def refine_workflow(workflow_id: str, change: str) -> str:
    """Guide editing an existing workflow by ID."""
    return f"""Workflow id: {workflow_id}
Requested change: {change}

1. get_workflow to load current nodes/edges.
2. Apply the minimal JSON change.
3. update_workflow with updated nodes_json/edges_json strings.
4. Re-check graph validity: all edge endpoints exist; no orphan end path.
"""


@mcp.prompt()
def build_workflow_from_requirements(requirements: str) -> str:
    """Structured prompt for turning user intent into node/edge DSL."""
    return f"""Convert the requirements into workflow DSL JSON.

Requirements:
{requirements}

Output format:
1) Node list table:
   - id
   - type
   - purpose
2) Edge list table:
   - id
   - source
   - target
   - sourceHandle
   - targetHandle
3) Final `nodes_json` and `edges_json` ready for create_workflow tool.

Validation checklist before returning:
- Exactly one start node
- At least one end node
- Every edge source/target exists in nodes
- No disconnected critical node
"""


@mcp.prompt()
def explain_last_error() -> str:
    """Ask the model to interpret the last tool/API error for the user."""
    return (
        "The previous tool call returned an API error. Explain in plain language "
        "whether it is auth (401), permission (403), not found (404), or validation (422), "
        "and what the user should do next."
    )
