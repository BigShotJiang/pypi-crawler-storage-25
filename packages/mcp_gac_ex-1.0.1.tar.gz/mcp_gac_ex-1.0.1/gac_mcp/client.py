"""HTTP client for GAC REST API with PAT -> JWT exchange support."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from gac_mcp.config import Config


class GacApiError(Exception):
    def __init__(self, status_code: int, body: str) -> None:
        self.status_code = status_code
        self.body = body
        super().__init__(f"HTTP {status_code}: {body[:2000]}")


class GacApiClient:
    def __init__(self, config: Config) -> None:
        self._config = config
        self._active_bearer: str | None = None
        self._bearer_expires_at: datetime | None = None
        self._client = httpx.AsyncClient(
            base_url=config.base_url,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(config.request_timeout_s),
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> GacApiClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any | None = None,
    ) -> Any:
        r = await self._request_with_reauth(
            method,
            path,
            params=params,
            json_body=json_body,
        )
        text = r.text
        if r.status_code >= 400:
            raise GacApiError(r.status_code, text)
        if not text.strip():
            return None
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text

    async def _request_with_reauth(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any | None = None,
    ) -> httpx.Response:
        await self._ensure_auth_header()
        response = await self._client.request(
            method,
            path,
            params=params,
            json=json_body,
        )
        if response.status_code == 401 and self._config.pat_token:
            # Session/JWT can expire. Force PAT->JWT refresh once and retry.
            self._active_bearer = None
            self._bearer_expires_at = None
            await self._ensure_auth_header()
            response = await self._client.request(
                method,
                path,
                params=params,
                json=json_body,
            )
        return response

    async def _ensure_auth_header(self) -> None:
        if self._active_bearer and self._bearer_expires_at:
            if datetime.now(timezone.utc) < (self._bearer_expires_at - timedelta(seconds=30)):
                self._client.headers["Authorization"] = f"Bearer {self._active_bearer}"
                return

        if self._active_bearer and self._bearer_expires_at is None:
            self._client.headers["Authorization"] = f"Bearer {self._active_bearer}"
            return

        if self._config.pat_token:
            try:
                await self._exchange_pat_for_jwt()
                self._client.headers["Authorization"] = f"Bearer {self._active_bearer}"
                return
            except GacApiError:
                if not self._config.jwt_token:
                    raise

        if not self._config.jwt_token:
            raise GacApiError(401, "No JWT available and PAT exchange failed")

        self._active_bearer = self._config.jwt_token
        self._bearer_expires_at = None
        self._client.headers["Authorization"] = f"Bearer {self._active_bearer}"

    async def bootstrap_auth(self) -> None:
        """Initialize auth at startup (PAT exchange preferred, JWT fallback)."""
        await self._ensure_auth_header()

    async def _exchange_pat_for_jwt(self) -> None:
        payload: dict[str, Any] = {"pat_token": self._config.pat_token}

        response = await self._client.post(self._config.pat_exchange_path, json=payload)
        text = response.text
        if response.status_code >= 400:
            raise GacApiError(response.status_code, text)

        data = json.loads(text) if text.strip() else {}
        token = data.get("access_token")
        if not token:
            raise GacApiError(500, "PAT exchange response missing access_token")

        self._active_bearer = token
        expires_in = int(data.get("expires_in", 0))
        self._bearer_expires_at = (
            datetime.now(timezone.utc) + timedelta(seconds=expires_in)
            if expires_in > 0
            else None
        )

    async def verify_auth(self) -> None:
        """Call GET /me — same JWT as tools. Raises GacApiError if token invalid."""
        await self._request("GET", "/me")

    async def list_projects(
        self,
        *,
        page: int = 1,
        page_size: int = 50,
        search: str | None = None,
    ) -> Any:
        """GET /projects — projects the current user can access (JWT)."""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if search:
            params["search"] = search
        return await self._request("GET", "/projects", params=params)

    async def list_workflows(
        self,
        project_id: int,
        *,
        page: int = 1,
        page_size: int = 50,
        name: str | None = None,
    ) -> Any:
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if name:
            params["name"] = name
        return await self._request(
            "GET",
            f"/projects/{project_id}/workflow-agents",
            params=params,
        )

    async def get_workflow(self, project_id: int, workflow_id: int) -> Any:
        return await self._request(
            "GET",
            f"/projects/{project_id}/workflow-agents/{workflow_id}",
        )

    async def create_workflow(
        self,
        project_id: int,
        body: dict[str, Any],
    ) -> Any:
        return await self._request(
            "POST",
            f"/projects/{project_id}/workflow-agents",
            json_body=body,
        )

    async def update_workflow(
        self,
        project_id: int,
        workflow_id: int,
        body: dict[str, Any],
    ) -> Any:
        return await self._request(
            "PUT",
            f"/projects/{project_id}/workflow-agents/{workflow_id}",
            json_body=body,
        )

    async def delete_workflow(self, project_id: int, workflow_id: int) -> Any:
        return await self._request(
            "DELETE",
            f"/projects/{project_id}/workflow-agents/{workflow_id}",
        )

    async def publish_workflow(
        self,
        project_id: int,
        workflow_id: int,
        body: dict[str, Any] | None = None,
    ) -> Any:
        return await self._request(
            "POST",
            f"/projects/{project_id}/workflow-agents/{workflow_id}/publish",
            json_body=body or {},
        )

    async def list_workflow_versions(
        self,
        project_id: int,
        workflow_id: int,
        *,
        page: int = 1,
        page_size: int = 20,
        named_only: bool = False,
        created_by: int | None = None,
    ) -> Any:
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if named_only:
            params["named_only"] = True
        if created_by is not None:
            params["created_by"] = created_by
        return await self._request(
            "GET",
            f"/projects/{project_id}/workflow-agents/{workflow_id}/versions",
            params=params,
        )

    async def get_workflow_version(
        self,
        project_id: int,
        workflow_id: int,
        version_id: int,
    ) -> Any:
        return await self._request(
            "GET",
            f"/projects/{project_id}/workflow-agents/{workflow_id}/versions/{version_id}",
        )

    async def delete_workflow_version(
        self,
        project_id: int,
        workflow_id: int,
        version_id: int,
    ) -> Any:
        return await self._request(
            "DELETE",
            f"/projects/{project_id}/workflow-agents/{workflow_id}/versions/{version_id}",
        )

    async def restore_workflow_version(
        self,
        project_id: int,
        workflow_id: int,
        version_id: int,
    ) -> Any:
        return await self._request(
            "POST",
            f"/projects/{project_id}/workflow-agents/{workflow_id}/versions/{version_id}/restore",
            json_body={},
        )

    async def execute_workflow_stream_preview(
        self,
        workflow_id: int,
        body: dict[str, Any],
    ) -> str:
        """POST execute — API returns SSE; we read raw bytes and truncate for MCP."""
        r = await self._request_with_reauth(
            "POST",
            f"/projects/workflow-agents/{workflow_id}/execute",
            json_body=body,
        )
        text = r.text
        if r.status_code >= 400:
            raise GacApiError(r.status_code, text)
        # SSE: return first ~8k chars so the model sees something without huge context
        preview = text[:8000]
        if len(text) > 8000:
            preview += "\n\n... [truncated; full response is SSE stream] ..."
        return preview
