"""Entry: stdio MCP server for Cursor / Claude Code."""

from __future__ import annotations

import asyncio
import logging
import sys

from gac_mcp.client import GacApiClient, GacApiError
from gac_mcp.config import load_config
from gac_mcp.server import mcp


def _quiet_noisy_http_loggers() -> None:
    """Avoid emitting non-MCP output on stdio transport."""
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


async def _verify_jwt_before_stdio() -> None:
    """Exchange PAT->JWT (or fallback JWT), then verify auth before stdio starts."""
    cfg = load_config()
    async with GacApiClient(cfg) as client:
        # Force auth bootstrap at startup so MCP is ready for subsequent API calls.
        await client.bootstrap_auth()
        await client.verify_auth()


def main() -> None:
    _quiet_noisy_http_loggers()

    # Config must exist (base URL + token)
    load_config()
    try:
        asyncio.run(_verify_jwt_before_stdio())
    except GacApiError as exc:
        print(
            f"MCP auth failed (check GAC_PAT or GAC_JWT and GAC_BASE_URL): {exc}",
            file=sys.stderr,
        )
        sys.exit(2)
    except OSError as exc:
        print(f"MCP auth request failed: {exc}", file=sys.stderr)
        sys.exit(2)

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
