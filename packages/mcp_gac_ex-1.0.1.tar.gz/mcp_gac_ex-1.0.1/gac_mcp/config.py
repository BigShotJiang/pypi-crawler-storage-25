"""Load MCP runtime configuration for JWT/PAT auth."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass


def _read_optional_file(path: str) -> str:
    p = os.path.expanduser(path)
    if not os.path.isfile(p):
        print(f"ERROR: GAC_JWT_FILE not found: {p}", file=sys.stderr)
        sys.exit(2)
    try:
        with open(p, encoding="utf-8") as f:
            return f.read().strip()
    except OSError as exc:
        print(f"ERROR: Cannot read GAC_JWT_FILE: {exc}", file=sys.stderr)
        sys.exit(2)


def _load_jwt_token() -> str:
    """Resolve direct JWT token (optional file first, then env vars)."""
    path = (os.environ.get("GAC_JWT_FILE") or "").strip()
    if path:
        raw = _read_optional_file(path)
        if raw:
            return raw
        print("ERROR: GAC_JWT_FILE is empty.", file=sys.stderr)
        sys.exit(2)

    token = (os.environ.get("GAC_JWT") or os.environ.get("GAC_TOKEN") or "").strip()
    if token.startswith("gac_pat_"):
        return ""
    return token


def _load_pat_token() -> str:
    """Resolve PAT token from env vars."""
    return (os.environ.get("GAC_PAT") or "").strip()


@dataclass(frozen=True)
class Config:
    """Runtime config for the MCP server process."""

    base_url: str
    jwt_token: str
    pat_token: str
    default_project_id: int | None
    enable_execute: bool
    request_timeout_s: float
    pat_exchange_path: str


def load_config() -> Config:
    """Read env config for PAT exchange and/or direct JWT mode.

    Dùng **access_token JWT hiện có** (đã đăng nhập app/Swagger) — không cần login lại trong MCP.

    Cách đặt token (chọn một):

    - ``GAC_JWT_FILE``: đường dẫn file chỉ chứa JWT (khuyến nghị: không dán token vào ``mcp.json``).
    - ``GAC_JWT`` / ``GAC_TOKEN`` / ``GAC_PAT``: giá trị JWT trực tiếp (vd. env khi mở Cursor từ terminal đã ``export``).
    """
    base = os.environ.get("GAC_BASE_URL", "").rstrip("/")
    jwt_token = _load_jwt_token()
    pat_token = _load_pat_token()
    if not base:
        print("ERROR: Set GAC_BASE_URL (e.g. http://localhost:8000/api/v1)", file=sys.stderr)
        sys.exit(2)
    if not jwt_token and not pat_token:
        print(
            "ERROR: Set GAC_PAT or GAC_JWT_FILE / GAC_JWT (or GAC_TOKEN).",
            file=sys.stderr,
        )
        sys.exit(2)

    dp = os.environ.get("GAC_DEFAULT_PROJECT_ID")
    default_project_id = int(dp) if dp and dp.isdigit() else None
    enable_execute = os.environ.get("GAC_MCP_ENABLE_EXECUTE", "false").lower() in (
        "1",
        "true",
        "yes",
    )
    timeout = float(os.environ.get("GAC_HTTP_TIMEOUT_S", "120"))
    pat_exchange_path = os.environ.get("GAC_PAT_EXCHANGE_PATH", "/auth/pat/exchange").strip()
    if not pat_exchange_path.startswith("/"):
        pat_exchange_path = f"/{pat_exchange_path}"

    return Config(
        base_url=base,
        jwt_token=jwt_token,
        pat_token=pat_token,
        default_project_id=default_project_id,
        enable_execute=enable_execute,
        request_timeout_s=timeout,
        pat_exchange_path=pat_exchange_path,
    )
