#!/usr/bin/env python3
"""CLI: same HTTP call as MCP tool `list_workflows`. Requires GAC_BASE_URL + GAC_JWT."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys

# Allow running without installing package: add parent for gac_mcp
_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)


async def main() -> None:
    parser = argparse.ArgumentParser(description="List workflow agents (MCP list_workflows equivalent).")
    parser.add_argument("project_id", type=int, nargs="?", default=None, help="Project ID (or GAC_DEFAULT_PROJECT_ID)")
    parser.add_argument("--page", type=int, default=1)
    parser.add_argument("--page-size", type=int, default=50)
    parser.add_argument("--name", type=str, default=None)
    args = parser.parse_args()

    os.chdir(_ROOT)
    from gac_mcp.client import GacApiClient
    from gac_mcp.config import load_config

    cfg = load_config()
    pid = args.project_id if args.project_id is not None else cfg.default_project_id
    if pid is None:
        print("Set project_id argument or GAC_DEFAULT_PROJECT_ID", file=sys.stderr)
        sys.exit(2)

    async with GacApiClient(cfg) as client:
        data = await client.list_workflows(
            pid, page=args.page, page_size=args.page_size, name=args.name
        )
    print(json.dumps(data, indent=2, ensure_ascii=False, default=str))


if __name__ == "__main__":
    asyncio.run(main())
