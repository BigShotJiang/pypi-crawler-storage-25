# Publish `mcp-gac-ex` 1.0.0 lên PyPI

Các bước dưới đây giả sử bạn dùng **TestPyPI** (thử) hoặc **PyPI** thật. Package name: **`mcp-gac-ex`**, version trong `pyproject.toml`: **`1.0.0`**, lệnh CLI sau cài: **`mcp-gac-ex`**.

## 0. Điều kiện

- Cài [uv](https://docs.astral.sh/uv/getting-started/installation/) (`uv --version`).
- Tên **`mcp-gac-ex` chưa bị** ai chiếm trên [PyPI](https://pypi.org/) (kiểm tra tìm kiếm). Nếu trùng, đổi tên trong `pyproject.toml` rồi mới build.

## 1. Tài khoản & token PyPI

1. Vào [https://pypi.org](https://pypi.org) → **Register** (hoặc đăng nhập).
2. **Account settings → API tokens** → **Add API token**  
   - **Scope:** toàn bộ account (lần đầu) *hoặc* chỉ project `mcp-gac-ex` (sau khi đã upload lần 1 bằng cách khác, hoặc tạo project trên PyPI trước nếu PyPI hỗ trợ).  
   - Copy token (bắt đầu bằng `pypi-...`).

**Không** commit token lên git.

## 2. Cấu hình đăng nhập khi `uv publish`

Cách thường dùng (theo tài liệu uv, có thể cập nhật theo bản bạn cài):

```bash
# Một lần trên máy: biến môi trường khi publish (bash/zsh)
export UV_PUBLISH_TOKEN="pypi-AgEIcHxlcmFfdG9r..."
```

Hoặc dùng **API token theo chuẩn Twine** (nhiều công cụ tương thích):

- Username: `__token__`  
- Password: giá trị token `pypi-...`  

Chi tiết cập nhật: [uv publish / publishing](https://docs.astral.sh/uv/guides/publish/).

**TestPyPI (khuyên nên thử trước):**

- Đăng ký tại [test.pypi.org](https://test.pypi.org), tạo token riêng.
- Publish kèm index test (xem lệnh `uv publish --help` cho `--index` / URL test).

## 3. Build & kiểm tra file

```bash
cd path/to/gac-gen-ai-console-be/examples/gac_mcp_workflow
uv sync
uv build
ls -la dist/
```

Bạn sẽ thấy `mcp_gac_ex-1.0.0-py3-none-any.whl` (và thường cả `.tar.gz` sdist). Mở wheel (zip) nếu muốn kiểm tra nội dung.

## 4. Upload lên PyPI

```bash
uv publish
```

Nếu lệnh hỏi username/password: dùng `__token__` và token `pypi-...` như trên, hoặc đảm bảo `UV_PUBLISH_TOKEN` đã set.

Nếu lỗi tên trùng / version đã tồn tại: tăng version trong `pyproject.toml` (vd. `1.0.1`) rồi build + publish lại.

## 5. Xác minh

```bash
# Sau vài phút, trên môi trường sạch hoặc venv tạm:
uv pip install mcp-gac-ex==1.0.0
mcp-gac-ex --help
# hoặc: uvx mcp-gac-ex@1.0.0  (cú pháp theo bản uv)
```

Mở [https://pypi.org/project/mcp-gac-ex/1.0.0/](https://pypi.org/project/mcp-gac-ex/1.0.0/) (nếu public).

## 6. Cursor / MCP cho end-user (sau publish)

Không cần `--directory` tới repo; ví dụ (chỉnh theo cú pháp `uvx` bản máy bạn):

```json
{
  "mcpServers": {
    "gac-workflow": {
      "command": "uvx",
      "args": ["mcp-gac-ex@1.0.0"],
      "env": {
        "GAC_BASE_URL": "https://api.example.com/api/v1",
        "GAC_JWT": "PASTE_JWT"
      }
    }
  }
}
```

Nếu `uvx` cần entrypoint tường minh, thử: `["--from", "mcp-gac-ex@1.0.0", "mcp-gac-ex"]` (xem `uvx --help`).

## Checklist nhanh

- [ ] `pyproject.toml`: `name = "mcp-gac-ex"`, `version = "1.0.0"`, script `mcp-gac-ex`
- [ ] `uv build` thành công, `dist/` có bản 1.0.0
- [ ] PyPI API token tạo và export / nhập khi publish
- [ ] `uv publish` thành công
- [ ] Cài thử `pip`/`uv pip install mcp-gac-ex==1.0.0`

---

**Lưu ý pháp lý:** nếu package gắn thương hiệu công ty, cân nhắc license + README trước khi public.
