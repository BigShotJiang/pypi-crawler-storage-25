"""SDK client that connects to the nebo daemon server.

In server mode, all events (logs, metrics, node registrations, etc.) are
forwarded to the daemon via HTTP. If the daemon disconnects, the client
falls back to local mode and buffers events for replay on reconnect.

Uses only stdlib (urllib) — no httpx dependency required.
"""

from __future__ import annotations

import atexit
import json
import os
import queue
import sys
import threading
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class DrainResult:
    """Outcome of a drain attempt.

    `last_error` is None on full success (dropped == 0); on partial or
    full failure it carries `repr(exc)` of the most recent
    `_post_batch` failure.
    """
    sent: int
    dropped: int
    dropped_bytes: int
    last_error: Optional[str]


class DaemonClient:
    """Client that streams events from the SDK to the daemon server.

    Thread-safe. Uses a background thread for batched HTTP flushing.
    Supports graceful fallback and reconnection.
    """

    # 2 MB cap on a single POST body. Large enough that normal
    # text-event traffic never chunks; small enough that common proxy /
    # WAF body limits don't bite even with base64 image payloads.
    _MAX_CHUNK_BYTES = 2 * 1024 * 1024

    def __init__(
        self,
        host: str = "localhost",
        port: int = 7861,
        run_id: Optional[str] = None,
        flush_interval: float = 0.1,
        base_url: Optional[str] = None,
        api_token: Optional[str] = None,
        shutdown_timeout: float = 10.0,
    ) -> None:
        """Connect to a nebo daemon.

        For a local daemon: pass `host` + `port` (defaults work).
        For a remote daemon (e.g. one running on a Hugging Face Space):
        pass `base_url` (e.g. `https://username-space.hf.space`) and
        optionally `api_token`. When `base_url` is set it takes
        precedence over `host`/`port`. When `api_token` is set, an
        `X-Nebo-Token` header is added to every HTTP request — required
        when the target daemon enforces auth via `NEBO_API_TOKEN`.

        `shutdown_timeout` (default 10 s; env override
        NEBO_SHUTDOWN_TIMEOUT) is the budget the atexit drain has to
        push remaining events to the daemon before warning to stderr.
        """
        self._host = host
        self._port = port
        self._run_id = run_id
        self._flush_interval = flush_interval
        self._api_token = api_token
        if base_url:
            self._base_url = base_url.rstrip("/")
        else:
            self._base_url = f"http://{host}:{port}"

        self._queue: queue.Queue[dict[str, Any]] = queue.Queue()
        self._buffer: list[dict[str, Any]] = []
        self._connected = False
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._fallback_buffer: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._run_completed: bool = False

        env_timeout = os.environ.get("NEBO_SHUTDOWN_TIMEOUT")
        if env_timeout is not None:
            try:
                shutdown_timeout = float(env_timeout)
            except ValueError:
                pass
        self._shutdown_timeout = shutdown_timeout

    def _auth_headers(self) -> dict[str, str]:
        if self._api_token:
            # Use X-Nebo-Token instead of Authorization: Bearer.
            # Google Cloud Frontend's WAF blocks the Authorization
            # bearer pattern (matches Stripe-like leaked-credential
            # detection) AND the X-Nebo-Api-Token header name
            # specifically — but X-Nebo-Token sails through.
            return {"X-Nebo-Token": self._api_token}
        return {}

    def warmup(self, timeout: float = 120.0) -> bool:
        """Block until a fronting router has a daemon ready (best-effort).

        POSTs to `/api/daemon/warmup` to nudge a multi-tenant router
        into bringing up a per-user daemon. Returns True on 200, False
        otherwise. For directly-reachable daemons (local or a Space)
        this endpoint typically 404s and the caller should ignore the
        return value.

        No-op (returns True immediately) when no api_token is set.
        """
        if not self._api_token:
            return True
        url = (
            f"{self._base_url}/api/daemon/warmup"
            f"?t={urllib.request.quote(self._api_token)}"
        )
        req = urllib.request.Request(url, data=b"", method="POST")
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.status == 200
        except Exception:
            return False

    def connect(self) -> bool:
        """Attempt to connect to the daemon server.

        Returns:
            True if connection successful.
        """
        try:
            req = urllib.request.Request(f"{self._base_url}/health", method="GET")
            for k, v in self._auth_headers().items():
                req.add_header(k, v)
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                if resp.status == 200:
                    self._connected = True
                    self._start_flush_thread()
                    return True
        except Exception:
            pass
        self._connected = False
        return False

    def send_event(self, event: dict[str, Any]) -> None:
        """Queue an event to be sent to the daemon.

        If disconnected, events are buffered for replay on reconnect.

        Args:
            event: The event dictionary to send.
        """
        if self._connected:
            self._queue.put(event)
        else:
            with self._lock:
                self._fallback_buffer.append(event)

    def send_events(self, events: list[dict[str, Any]]) -> None:
        """Queue multiple events."""
        for event in events:
            self.send_event(event)

    def is_connected(self) -> bool:
        """Check if the client is connected to the daemon."""
        return self._connected

    def disconnect(self) -> None:
        """Disconnect from the daemon and flush remaining events."""
        # Send run_completed event before flushing (guard against double send)
        if self._connected and not self._run_completed:
            self._queue.put({
                "type": "run_completed",
                "data": {"exit_code": 0},
            })
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3.0)
        self._flush_remaining()
        self._connected = False

    def _start_flush_thread(self) -> None:
        """Start the background flush thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._thread.start()
        atexit.register(self.disconnect)

    def _flush_loop(self) -> None:
        """Background loop: batch events and send to daemon."""
        last_flush = time.monotonic()

        while self._running:
            try:
                event = self._queue.get(timeout=self._flush_interval)
                self._buffer.append(event)
            except queue.Empty:
                pass

            now = time.monotonic()

            if (now - last_flush) >= self._flush_interval and self._buffer:
                success = self._do_flush()
                last_flush = now
                if not success:
                    self._handle_disconnect()

    def _chunk_buffer(
        self,
        events: list[dict[str, Any]],
        max_bytes: int,
    ) -> list[list[dict[str, Any]]]:
        """Split events into sub-batches each <= max_bytes encoded JSON.

        A single event larger than max_bytes becomes its own chunk
        (the chunker never drops — the network may still accept it).
        """
        chunks: list[list[dict[str, Any]]] = []
        current: list[dict[str, Any]] = []
        current_size = 0
        for event in events:
            event_size = len(json.dumps(event))
            if current and current_size + event_size > max_bytes:
                chunks.append(current)
                current = []
                current_size = 0
            current.append(event)
            current_size += event_size
        if current:
            chunks.append(current)
        return chunks

    def _drain_with_retry(self, deadline: float) -> DrainResult:
        """Drain queue + buffer to the daemon, retrying until deadline.

        On entry, anything in self._buffer or self._queue is fair game.
        On exit, any unsent events remain in self._buffer for the
        caller to inspect (or for another call to retry).
        """
        sent = 0
        last_error: Optional[str] = None

        while True:
            self._drain_queue_into_buffer()
            if not self._buffer:
                return DrainResult(
                    sent=sent, dropped=0, dropped_bytes=0, last_error=None
                )

            pending = self._buffer[:]
            self._buffer.clear()
            chunks = self._chunk_buffer(pending, self._MAX_CHUNK_BYTES)

            failed_at: Optional[int] = None
            for i, chunk in enumerate(chunks):
                ok, exc = self._post_batch(chunk)
                if ok:
                    sent += len(chunk)
                else:
                    last_error = repr(exc)
                    failed_at = i
                    break

            if failed_at is not None:
                # Restore the failed chunk + everything after it.
                for chunk in chunks[failed_at:]:
                    self._buffer.extend(chunk)

                now = time.monotonic()
                if now >= deadline:
                    dropped_bytes = sum(
                        len(json.dumps(e)) for e in self._buffer
                    )
                    return DrainResult(
                        sent=sent,
                        dropped=len(self._buffer),
                        dropped_bytes=dropped_bytes,
                        last_error=last_error,
                    )
                time.sleep(min(0.2, deadline - now))
            # If failed_at is None, all chunks succeeded; loop again to
            # catch anything queued during the POSTs.

    def _post_batch(
        self, batch: list[dict[str, Any]]
    ) -> tuple[bool, Optional[Exception]]:
        """POST a batch of events to the daemon.

        Returns (True, None) on HTTP 200; (False, exc) otherwise. The
        exception form is returned (not raised) so callers keep linear
        flow and can record the cause for diagnostics.
        """
        if not batch:
            return True, None
        try:
            url = f"{self._base_url}/events"
            if self._run_id:
                url += f"?run_id={urllib.request.quote(self._run_id)}"
            data = json.dumps(batch).encode("utf-8")
            req = urllib.request.Request(url, data=data, method="POST")
            req.add_header("Content-Type", "application/json")
            for k, v in self._auth_headers().items():
                req.add_header(k, v)
            # Remote daemons cross the public internet; loopback daemons
            # are fast. Use the longer timeout whenever a token is in
            # play, since that's the remote-target signal.
            request_timeout = 30.0 if self._api_token else 5.0
            with urllib.request.urlopen(req, timeout=request_timeout) as resp:
                if resp.status == 200:
                    return True, None
                return False, RuntimeError(f"HTTP {resp.status}")
        except Exception as exc:
            return False, exc

    def _do_flush(self) -> bool:
        """Send buffered events to the daemon. Returns True on success."""
        if not self._buffer:
            return True

        batch = self._buffer[:]
        self._buffer.clear()

        ok, _ = self._post_batch(batch)
        if not ok:
            # Put events back for retry by the next periodic tick.
            self._buffer = batch + self._buffer
        return ok

    def _drain_queue_into_buffer(self) -> None:
        """Move every event currently in self._queue into self._buffer."""
        while not self._queue.empty():
            try:
                event = self._queue.get_nowait()
                self._buffer.append(event)
            except queue.Empty:
                break

    def _flush_remaining(self) -> None:
        """Drain queue + buffer at shutdown with a bounded retry budget.

        On any unsent residue, prints a WARNING to stderr (not via the
        `nebo` logger or `warnings.warn` — atexit runs after most
        logging handlers have shut down and warnings filters may have
        been reconfigured by user code by this point; bare stderr is
        the path most likely to actually reach the terminal).
        """
        deadline = time.monotonic() + self._shutdown_timeout
        result = self._drain_with_retry(deadline)
        if result.dropped > 0:
            kb = result.dropped_bytes / 1024
            msg = (
                f"nebo: WARNING — dropped {result.dropped} event(s) "
                f"(~{kb:.0f} KB) at shutdown after "
                f"{self._shutdown_timeout}s. "
                f"Last error: {result.last_error}. "
                "Some logs may not appear in the UI."
            )
            print(msg, file=sys.stderr, flush=True)

    def _handle_disconnect(self) -> None:
        """Handle daemon disconnection: buffer events and try to reconnect."""
        self._connected = False

        # Move buffer to fallback
        with self._lock:
            self._fallback_buffer.extend(self._buffer)
            self._buffer.clear()

        # Try to reconnect periodically
        for _ in range(5):
            time.sleep(1.0)
            if self.connect():
                # Replay buffered events
                with self._lock:
                    replay = self._fallback_buffer[:]
                    self._fallback_buffer.clear()
                if replay:
                    for event in replay:
                        self._queue.put(event)
                return

    def flush(self, timeout: float = 5.0) -> bool:
        """Force-flush queued events to the daemon, blocking until done
        or `timeout` seconds elapse.

        Useful for time-sensitive events (e.g. ask prompts) that
        shouldn't wait for the next batch interval, and for fencing
        a logging-heavy section before something irreversible.

        Returns True if everything was sent; False if any events
        remain un-flushed when the deadline expired (those events
        stay in self._buffer).
        """
        deadline = time.monotonic() + max(0.0, timeout)
        result = self._drain_with_retry(deadline)
        return result.dropped == 0

    def get(self, path: str) -> Optional[dict[str, Any]]:
        """Send a GET request to the daemon and return the JSON response.

        Args:
            path: URL path (e.g. "/runs/run_1/ask/abc/respond").

        Returns:
            Parsed JSON dict, or None on error.
        """
        try:
            url = f"{self._base_url}{path}"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                if resp.status == 200:
                    return json.loads(resp.read().decode("utf-8"))
        except Exception:
            pass
        return None

    def get_pause_state(self) -> bool:
        """Poll the daemon for the current pause state.

        Returns:
            True if the run is paused, False otherwise.
        """
        path = f"/runs/{self._run_id}/pause"
        resp = self.get(path)
        if resp is not None:
            return resp.get("paused", False)
        return False

    def try_reconnect(self) -> bool:
        """Manually attempt reconnection."""
        if self._connected:
            return True
        connected = self.connect()
        if connected:
            with self._lock:
                replay = self._fallback_buffer[:]
                self._fallback_buffer.clear()
            for event in replay:
                self._queue.put(event)
        return connected
