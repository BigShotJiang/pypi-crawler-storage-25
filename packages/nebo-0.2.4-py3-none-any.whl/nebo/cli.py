"""CLI entry points for nebo.

Commands:
    nebo serve   — Start the persistent daemon server
    nebo run     — Run a pipeline as a managed subprocess
    nebo status  — Show daemon status and recent runs
    nebo stop    — Stop the daemon
    nebo logs    — View logs from runs
    nebo errors  — View errors from runs
    nebo mcp     — Print MCP connection config for Claude Code
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

_PID_DIR = Path.home() / ".nebo"
_PID_FILE = _PID_DIR / "server.pid"


def _write_pid(pid: int) -> None:
    _PID_DIR.mkdir(parents=True, exist_ok=True)
    _PID_FILE.write_text(str(pid))


def _read_pid() -> int | None:
    try:
        if _PID_FILE.exists():
            return int(_PID_FILE.read_text().strip())
    except (ValueError, OSError):
        pass
    return None


def _remove_pid() -> None:
    try:
        _PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _is_alive(port: int) -> bool:
    try:
        import httpx
        resp = httpx.get(f"http://localhost:{port}/health", timeout=2.0)
        return resp.status_code == 200
    except Exception:
        return False


def _process_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def cmd_serve(args: argparse.Namespace) -> None:
    """Start the persistent daemon server."""
    port = args.port
    host = args.host

    if _is_alive(port):
        print(f"Nebo daemon is already running on {host}:{port}")
        return

    if getattr(args, "no_store", False):
        os.environ["NEBO_NO_STORE"] = "1"
    if getattr(args, "store_dir", None):
        os.environ["NEBO_STORE_DIR"] = args.store_dir
    if getattr(args, "api_token", None):
        os.environ["NEBO_API_TOKEN"] = args.api_token
    if getattr(args, "read", None):
        os.environ["NEBO_READ_MODE"] = args.read
    if getattr(args, "write", None):
        os.environ["NEBO_WRITE_MODE"] = args.write

    if args.daemon:
        # Background mode
        cmd = [
            sys.executable, "-m", "uvicorn",
            "nebo.server.daemon:create_daemon_app",
            "--factory",
            "--host", host,
            "--port", str(port),
            "--log-level", "warning",
        ]
        env = os.environ.copy()
        env["NEBO_DAEMON_PORT"] = str(port)
        if getattr(args, "no_store", False):
            env["NEBO_NO_STORE"] = "1"
        if getattr(args, "store_dir", None):
            env["NEBO_STORE_DIR"] = args.store_dir
        if getattr(args, "api_token", None):
            env["NEBO_API_TOKEN"] = args.api_token
        if getattr(args, "read", None):
            env["NEBO_READ_MODE"] = args.read
        if getattr(args, "write", None):
            env["NEBO_WRITE_MODE"] = args.write
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            env=env,
        )
        _write_pid(proc.pid)

        # Wait for server to come up
        for _ in range(50):
            if _is_alive(port):
                print(f"Nebo daemon started on {host}:{port} (PID {proc.pid})")
                return
            time.sleep(0.1)

        print(f"Nebo daemon started (PID {proc.pid}), but health check pending...")
    else:
        # Foreground mode
        _write_pid(os.getpid())
        os.environ["NEBO_DAEMON_PORT"] = str(port)
        print(f"Starting Nebo daemon on {host}:{port}...")
        print("Press Ctrl+C to stop.\n")
        import uvicorn
        try:
            uvicorn.run(
                "nebo.server.daemon:create_daemon_app",
                factory=True,
                host=host,
                port=port,
                log_level="info",
            )
        except KeyboardInterrupt:
            pass
        finally:
            _remove_pid()
            print("\nNebo daemon stopped.")


def cmd_run(args: argparse.Namespace) -> None:
    """Run a pipeline managed by the daemon."""
    port = args.port
    script = args.script
    script_args = args.script_args or []

    if not Path(script).exists():
        print(f"Error: Script not found: {script}")
        sys.exit(1)

    # Ensure daemon is running
    if not _is_alive(port):
        print(f"Daemon not running on port {port}. Starting in background...")
        ns = argparse.Namespace(port=port, host="localhost", daemon=True)
        cmd_serve(ns)
        time.sleep(1)

    import httpx

    # Register run with daemon
    run_id = args.name or f"run_{int(time.time())}"

    # Set environment so SDK auto-connects
    env = os.environ.copy()
    env["NEBO_SERVER_PORT"] = str(port)
    env["NEBO_RUN_ID"] = run_id
    env["NEBO_MODE"] = "server"
    env["NEBO_FLUSH_INTERVAL"] = str(args.flush_interval)

    cmd = [sys.executable, script] + script_args

    print(f"Starting pipeline: {script} (run_id: {run_id})")
    proc = subprocess.Popen(cmd, env=env)

    try:
        exit_code = proc.wait()
    except KeyboardInterrupt:
        proc.terminate()
        try:
            exit_code = proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            exit_code = -1

    if exit_code == 0:
        print(f"\nPipeline completed successfully (run_id: {run_id})")
    else:
        print(f"\nPipeline exited with code {exit_code} (run_id: {run_id})")

    # Notify daemon
    try:
        httpx.post(
            f"http://localhost:{port}/events",
            json=[{"type": "run_completed", "data": {"run_id": run_id, "exit_code": exit_code}}],
            timeout=2.0,
        )
    except Exception:
        pass

    sys.exit(exit_code)


def cmd_status(args: argparse.Namespace) -> None:
    """Show daemon status and recent runs."""
    port = args.port

    if not _is_alive(port):
        print("Nebo daemon is not running.")
        pid = _read_pid()
        if pid:
            print(f"  Stale PID file found: {pid}")
        return

    import httpx

    try:
        health = httpx.get(f"http://localhost:{port}/health", timeout=2.0).json()
        runs = httpx.get(f"http://localhost:{port}/runs", timeout=2.0).json()
    except Exception as e:
        print(f"Error connecting to daemon: {e}")
        return

    print(f"Nebo daemon: running on port {port}")
    print(f"  Active run: {health.get('active_run', 'none')}")
    print(f"  Total runs: {health.get('total_runs', 0)}")

    run_list = runs.get("runs", [])
    if run_list:
        print(f"\nRecent runs:")
        for r in run_list[-10:]:
            status_icon = {"running": "↻", "completed": "✓", "crashed": "✗", "stopped": "■", "starting": "…"}.get(r["status"], "?")
            print(f"  {status_icon} {r['id']}: {r['status']} | {r['script_path']} | "
                  f"nodes={r.get('node_count', 0)}, errors={r.get('error_count', 0)}")


def cmd_stop(args: argparse.Namespace) -> None:
    """Stop the daemon."""
    port = args.port
    pid = _read_pid()

    if pid and _process_alive(pid):
        os.kill(pid, signal.SIGTERM)
        print(f"Sent SIGTERM to daemon (PID {pid})")
        # Wait for it to die
        for _ in range(30):
            if not _process_alive(pid):
                break
            time.sleep(0.1)
        _remove_pid()
        print("Nebo daemon stopped.")
    elif _is_alive(port):
        print(f"Daemon is running on port {port} but PID unknown. Use kill manually.")
    else:
        print("Nebo daemon is not running.")
        _remove_pid()


def cmd_logs(args: argparse.Namespace) -> None:
    """View logs from runs."""
    port = args.port

    if not _is_alive(port):
        print("Nebo daemon is not running.")
        return

    import httpx

    try:
        params = {"limit": args.limit}
        if args.node:
            params["loggable_id"] = args.node

        if args.run:
            url = f"http://localhost:{port}/runs/{args.run}/logs"
        else:
            url = f"http://localhost:{port}/logs"

        resp = httpx.get(url, params=params, timeout=5.0)
        data = resp.json()
    except Exception as e:
        print(f"Error: {e}")
        return

    logs = data.get("logs", [])
    if not logs:
        print("No logs found.")
        return

    for entry in logs:
        node_tag = f"[{entry.get('loggable_id', '?')}]" if entry.get("loggable_id") else ""
        print(f"  {node_tag} {entry.get('message', '')}")


def cmd_errors(args: argparse.Namespace) -> None:
    """View errors from runs."""
    port = args.port

    if not _is_alive(port):
        print("Nebo daemon is not running.")
        return

    import httpx

    try:
        if args.run:
            url = f"http://localhost:{port}/runs/{args.run}/errors"
        else:
            url = f"http://localhost:{port}/errors"

        resp = httpx.get(url, timeout=5.0)
        data = resp.json()
    except Exception as e:
        print(f"Error: {e}")
        return

    errors = data.get("errors", [])
    if not errors:
        print("No errors found.")
        return

    for err in errors:
        print(f"\n{'='*60}")
        print(f"Node: {err.get('node_name', '?')}")
        print(f"Type: {err.get('exception_type', '?')}: {err.get('exception_message', '')}")
        tb = err.get("traceback", "")
        if tb:
            print(f"Traceback:\n{tb}")


def cmd_mcp(args: argparse.Namespace) -> None:
    """Print MCP connection config for Claude Code."""
    port = getattr(args, "port", 7861)
    nebo_args = ["mcp-stdio"]
    if port != 7861:
        nebo_args += ["--port", str(port)]
    config = {
        "mcpServers": {
            "nebo": {
                "command": "nebo",
                "args": nebo_args,
                "env": {},
            }
        }
    }
    print("# Add this to your Claude Code MCP config (~/.claude/mcp.json):")
    print(json.dumps(config, indent=2))


def _replay_nebo_file_to_remote(filepath: str, base_url: str, api_token: str | None) -> None:
    """Read a .nebo file locally and POST its events to a remote daemon.

    The daemon's `POST /load` accepts a server-side filepath, which
    doesn't exist when the daemon is on a Hugging Face Space and the
    file is on the user's machine. This walks the file with the
    existing reader and pushes events through `/events` instead — same
    wire shape, same auth header, just a different ingress.
    """
    import json as _json
    import urllib.request
    from nebo.core.fileformat import NeboFileReader

    headers = {"Content-Type": "application/json"}
    if api_token:
        headers["X-Nebo-Token"] = api_token

    with open(filepath, "rb") as f:
        reader = NeboFileReader(f)
        meta = reader.read_header()
        run_id = meta["run_id"]

        # Open the run on the remote side. `store=False` so the remote
        # daemon doesn't write a fresh .nebo copy alongside its other
        # runs — the source-of-truth is the file we're uploading.
        events: list[dict] = [{
            "type": "run_start",
            "data": {
                "script_path": meta.get("script_path", os.path.basename(filepath)),
                "store": False,
            },
        }]
        while True:
            entry = reader.read_next_entry()
            if entry is None:
                break
            events.append({"type": entry["type"], **entry["payload"]})

    # Chunk by encoded byte size so a single POST never balloons past
    # what proxies / WAFs accept. 1 MB matches the SDK's own ceiling.
    chunk_limit = 1024 * 1024
    chunks: list[list[dict]] = [[]]
    chunk_size = 0
    for evt in events:
        encoded_size = len(_json.dumps(evt))
        if chunks[-1] and chunk_size + encoded_size > chunk_limit:
            chunks.append([])
            chunk_size = 0
        chunks[-1].append(evt)
        chunk_size += encoded_size

    target = f"{base_url.rstrip('/')}/events?run_id={urllib.parse.quote(run_id)}"
    sent = 0
    for chunk in chunks:
        if not chunk:
            continue
        data = _json.dumps(chunk).encode("utf-8")
        req = urllib.request.Request(target, data=data, method="POST", headers=headers)
        with urllib.request.urlopen(req, timeout=60) as resp:
            if resp.status != 200:
                raise RuntimeError(f"HTTP {resp.status} from {target}")
        sent += len(chunk)

    print(f"Loaded: {filepath} → {base_url} (run_id={run_id}, {sent} events in {len(chunks)} batch(es))")


def cmd_load(args: argparse.Namespace) -> None:
    """Load a .nebo file into the daemon (local or remote)."""
    filepath = os.path.abspath(args.file)
    if not os.path.exists(filepath):
        print(f"Error: File not found: {filepath}")
        sys.exit(1)

    url = getattr(args, "url", None) or os.environ.get("NEBO_URL")
    api_token = getattr(args, "api_token", None) or os.environ.get("NEBO_API_TOKEN")

    if url:
        try:
            _replay_nebo_file_to_remote(filepath, url, api_token)
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)
        return

    import httpx
    port = args.port
    if not _is_alive(port):
        print(f"Nebo daemon is not running on port {port}.")
        sys.exit(1)
    resp = httpx.post(
        f"http://localhost:{port}/load",
        json={"filepath": filepath},
        timeout=10.0,
    )
    data = resp.json()
    if "error" in data:
        print(f"Error: {data['error']}")
        sys.exit(1)
    print(f"Loaded: {filepath}")


def cmd_mcp_stdio(args: argparse.Namespace) -> None:
    """Run the MCP stdio transport (bridges stdio <-> daemon HTTP)."""
    from nebo.mcp.stdio import run_stdio_bridge
    run_stdio_bridge(port=args.port)


def _lazy_deploy(args: argparse.Namespace) -> None:
    """Defer the huggingface_hub import — it's an optional dependency."""
    from nebo.cli_deploy import cmd_deploy
    cmd_deploy(args)


def main() -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="nebo",
        description="Nebo - Function-level logging for Python",
    )
    parser.add_argument("--port", type=int, default=7861, help="Daemon port (default: 7861)")
    subparsers = parser.add_subparsers(dest="command")

    # serve
    p_serve = subparsers.add_parser("serve", help="Start the persistent daemon server")
    p_serve.add_argument("--host", default="localhost", help="Host to bind (default: localhost)")
    p_serve.add_argument("--port", type=int, default=7861, help="Port (default: 7861)")
    p_serve.add_argument("--daemon", "-d", action="store_true", help="Run in background")
    p_serve.add_argument("--no-store", action="store_true", help="Disable .nebo file storage")
    p_serve.add_argument("--store-dir", help="Directory for .nebo files (default: ./.nebo). Sets NEBO_STORE_DIR.")
    p_serve.add_argument("--api-token", help="Require this token on API requests via X-Nebo-Token / ?token=. Sets NEBO_API_TOKEN.")
    p_serve.add_argument("--read", choices=["public", "private"], help="Read access mode (default: public). Only matters when --api-token is set.")
    p_serve.add_argument("--write", choices=["public", "private"], help="Write access mode (default: private). Only matters when --api-token is set.")

    # run
    p_run = subparsers.add_parser("run", help="Run a pipeline managed by the daemon")
    p_run.add_argument("script", help="Path to the Python script")
    p_run.add_argument("--name", help="Run name/ID")
    p_run.add_argument("--port", type=int, default=7861)
    p_run.add_argument("--flush-interval", type=float, default=0.1, help="Seconds between event flushes (default: 0.1)")
    p_run.add_argument("script_args", nargs="*", help="Arguments for the script")

    # status
    p_status = subparsers.add_parser("status", help="Show daemon status")
    p_status.add_argument("--port", type=int, default=7861)

    # stop
    p_stop = subparsers.add_parser("stop", help="Stop the daemon")
    p_stop.add_argument("--port", type=int, default=7861)

    # logs
    p_logs = subparsers.add_parser("logs", help="View logs")
    p_logs.add_argument("--run", help="Run ID")
    p_logs.add_argument("--node", help="Filter by node")
    p_logs.add_argument("--limit", type=int, default=100)
    p_logs.add_argument("--port", type=int, default=7861)

    # errors
    p_errors = subparsers.add_parser("errors", help="View errors")
    p_errors.add_argument("--run", help="Run ID")
    p_errors.add_argument("--port", type=int, default=7861)

    # load
    p_load = subparsers.add_parser("load", help="Load a .nebo file into the daemon")
    p_load.add_argument("file", help="Path to .nebo file")
    p_load.add_argument("--port", type=int, default=7861, help="Local daemon port (ignored if --url is set)")
    p_load.add_argument("--url", help="Remote daemon URL (e.g. an HF Space). Reads file locally and replays events. Defaults to NEBO_URL env.")
    p_load.add_argument("--api-token", help="Token for the remote daemon. Defaults to NEBO_API_TOKEN env.")

    # mcp
    p_mcp = subparsers.add_parser("mcp", help="Print MCP config for Claude Code")
    p_mcp.add_argument("--port", type=int, default=7861, help="Daemon port to embed in the MCP config")

    # mcp-stdio (internal)
    p_mcp_stdio = subparsers.add_parser("mcp-stdio", help="Run MCP stdio transport")
    p_mcp_stdio.add_argument("--port", type=int, default=7861)

    # deploy
    p_deploy = subparsers.add_parser(
        "deploy",
        help="Deploy the nebo daemon to a Hugging Face Space",
    )
    p_deploy.add_argument("--space-id", required=True, help="Hugging Face Space ID, e.g. 'username/my-dashboard'")
    p_deploy.add_argument("--hf-token", help="Hugging Face write token (defaults to HF_TOKEN env / cached login)")
    p_deploy.add_argument("--api-token", help="Token clients must send via X-Nebo-Token. Random if omitted.")
    p_deploy.add_argument("--private", action="store_true", help="Create the Space as private")
    p_deploy.add_argument("--from-source", action="store_true", help="Build a wheel from this checkout and ship it instead of installing from PyPI")
    p_deploy.add_argument("--read", choices=["public", "private"], default="public", help="Read access mode (default: public — anyone can view).")
    p_deploy.add_argument("--write", choices=["public", "private"], default="private", help="Write access mode (default: private — token required to push events / control runs).")

    args = parser.parse_args()

    commands = {
        "serve": cmd_serve,
        "run": cmd_run,
        "status": cmd_status,
        "stop": cmd_stop,
        "logs": cmd_logs,
        "errors": cmd_errors,
        "load": cmd_load,
        "mcp": cmd_mcp,
        "mcp-stdio": cmd_mcp_stdio,
        "deploy": _lazy_deploy,
    }

    handler = commands.get(args.command)
    if handler:
        handler(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
