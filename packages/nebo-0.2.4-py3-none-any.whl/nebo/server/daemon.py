"""Persistent daemon server for nebo.

The daemon outlives individual pipeline runs, retaining logs, errors, and DAG
state across crashes and restarts. AI agents connect via MCP to the same server.
"""

from __future__ import annotations

import asyncio
import hashlib
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, Optional

from fastapi import WebSocket, WebSocketDisconnect
from nebo.server.protocol import MessageType, decode_batch


RunStatus = Literal["starting", "running", "completed", "crashed", "stopped"]

NEBO_STORAGE_DIR = os.environ.get("NEBO_STORE_DIR") or os.path.join(os.getcwd(), ".nebo")


@dataclass
class LogEntry:
    """A single log entry."""
    timestamp: float
    node: Optional[str]
    message: str
    level: str = "info"
    type: str = "log"
    step: Optional[int] = None
    extra: dict = field(default_factory=dict)


@dataclass
class ErrorEntry:
    """An enriched error entry with full node context."""
    timestamp: float
    node_name: str
    node_docstring: Optional[str]
    exception_type: str
    exception_message: str
    traceback: str
    execution_count: int
    params: dict = field(default_factory=dict)
    last_logs: list[str] = field(default_factory=list)


@dataclass
class LoggableState:
    """State for a single loggable (DAG node or the implicit global loggable) within a run."""
    loggable_id: str
    kind: str = "node"
    func_name: str = ""
    docstring: Optional[str] = None
    exec_count: int = 0
    is_source: bool = True
    pausable: bool = False
    params: dict = field(default_factory=dict)
    logs: list[dict] = field(default_factory=list)
    metrics: dict[str, list] = field(default_factory=dict)
    errors: list[dict] = field(default_factory=list)
    images: list[dict] = field(default_factory=list)
    audio: list[dict] = field(default_factory=list)
    progress: Optional[dict] = None
    group: Optional[str] = None  # Class name if this node is a method of a decorated class
    ui_hints: Optional[dict] = None  # Per-node UI display hints from @nb.fn(ui=...)


@dataclass
class Run:
    """Represents a single pipeline run managed by the daemon."""
    id: str
    script_path: str
    args: list[str] = field(default_factory=list)
    status: RunStatus = "starting"
    process: Any = None  # subprocess.Popen, not serializable
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    exit_code: Optional[int] = None
    loggables: dict[str, "LoggableState"] = field(default_factory=dict)
    edges: list[dict[str, str]] = field(default_factory=list)
    _edge_set: set[tuple[str, str]] = field(default_factory=set, repr=False)
    logs: list[LogEntry] = field(default_factory=list)
    errors: list[ErrorEntry] = field(default_factory=list)
    metrics: dict[str, list] = field(default_factory=dict)
    pending_asks: dict[str, dict] = field(default_factory=dict)
    ask_responses: dict[str, str] = field(default_factory=dict)
    source_hash: Optional[str] = None
    workflow_description: Optional[str] = None
    config: dict = field(default_factory=dict)
    paused: bool = False
    ui_config: Optional[dict] = None
    stdout_lines: list[str] = field(default_factory=list)
    stderr_lines: list[str] = field(default_factory=list)
    significant_events: list[dict] = field(default_factory=list)
    run_name: Optional[str] = None
    run_config: dict = field(default_factory=dict)

    def get_graph(self) -> dict:
        """Return the DAG as a serializable dict.

        Only node-kind loggables appear under the "nodes" key; the implicit
        global loggable (kind="global") is excluded from the DAG view.
        Edges are filtered to those whose endpoints are both node-kind, so
        the graph is self-consistent even if a stray edge referenced the
        global.
        """
        non_node_ids = {
            lid for lid, lg in self.loggables.items() if lg.kind != "node"
        }
        return {
            "nodes": {
                lid: {
                    "name": lg.loggable_id,
                    "func_name": lg.func_name,
                    "docstring": lg.docstring,
                    "exec_count": lg.exec_count,
                    "is_source": lg.is_source,
                    "pausable": lg.pausable,
                    "params": lg.params,
                    "progress": lg.progress,
                    "group": lg.group,
                    "ui_hints": lg.ui_hints,
                }
                for lid, lg in self.loggables.items()
                if lg.kind == "node"
            },
            "edges": [
                e for e in self.edges
                if e.get("source") not in non_node_ids
                and e.get("target") not in non_node_ids
            ],
            "workflow_description": self.workflow_description,
            "has_pausable": any(
                lg.pausable for lg in self.loggables.values() if lg.kind == "node"
            ),
            "paused": self.paused,
            "ui_config": self.ui_config,
            "run_config": self.run_config,
        }

    def get_summary(self) -> dict:
        """Return a concise run summary."""
        # Flat catalog of available metric names per loggable. Lets agents
        # discover what's loggable without iterating every loggable card.
        metrics_index: dict[str, list[str]] = {
            lid: sorted(loggable.metrics.keys())
            for lid, loggable in self.loggables.items()
            if loggable.metrics
        }
        return {
            "id": self.id,
            "script_path": self.script_path,
            "args": self.args,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "ended_at": self.ended_at.isoformat() if self.ended_at else None,
            "exit_code": self.exit_code,
            "node_count": sum(1 for l in self.loggables.values() if l.kind == "node"),
            "edge_count": len(self.edges),
            "log_count": len(self.logs),
            "error_count": len(self.errors),
            "run_name": self.run_name,
            "metrics_index": metrics_index,
        }


class DaemonState:
    """Central state holder for the daemon server.

    Manages all runs, retaining state across pipeline lifecycles.
    """

    def __init__(self) -> None:
        self.runs: dict[str, Run] = {}
        self.active_run_id: Optional[str] = None
        self._ws_clients: list[Any] = []
        self._lock = asyncio.Lock()
        self._event_notify: asyncio.Condition = asyncio.Condition()
        self._media_store: dict[str, str] = {}  # media_id -> base64 data

    def init_storage(self) -> None:
        """Create the .nebo storage directory if it doesn't exist."""
        os.makedirs(NEBO_STORAGE_DIR, exist_ok=True)

    def create_run(
        self,
        script_path: str,
        args: list[str] | None = None,
        run_id: str | None = None,
        store: bool = False,
    ) -> Run:
        """Create a new run entry."""
        if run_id is None:
            run_id = f"run_{int(time.time())}_{len(self.runs)}"

        source_hash = None
        path = Path(script_path)
        if path.exists():
            source_hash = hashlib.sha256(path.read_bytes()).hexdigest()[:12]

        run = Run(
            id=run_id,
            script_path=script_path,
            args=args or [],
            status="starting",
            started_at=datetime.now(),
            source_hash=source_hash,
        )
        self.runs[run_id] = run
        self.active_run_id = run_id

        if store:
            from nebo.core.fileformat import NeboFileWriter
            self.init_storage()
            timestamp = time.strftime("%Y-%m-%d_%H%M%S")
            filepath = os.path.join(NEBO_STORAGE_DIR, f"{timestamp}_{run_id}.nebo")
            run._file_stream = open(filepath, "wb")
            run._file_writer = NeboFileWriter(
                run._file_stream, run_id=run_id, script_path=script_path, args=args or [],
            )
            run._file_writer.write_header()
        else:
            run._file_stream = None
            run._file_writer = None

        return run

    def finalize_run(self, run_id: str) -> None:
        """Close the .nebo file for a run if storage was enabled."""
        run = self.runs.get(run_id)
        if run and getattr(run, "_file_stream", None):
            run._file_writer.close()
            run._file_stream.close()
            run._file_stream = None
            run._file_writer = None

    async def load_nebo_file(self, filepath: str) -> None:
        """Load a .nebo file and reconstruct a Run from it."""
        from nebo.core.fileformat import NeboFileReader

        with open(filepath, "rb") as f:
            reader = NeboFileReader(f)
            meta = reader.read_header()
            run_id = meta["run_id"]

            run = self.create_run(
                meta["script_path"],
                meta.get("args", []),
                run_id,
                store=False,
            )
            run.status = "completed"

            events = list(reader.read_entries())
            event_dicts = [
                {"type": e["type"], **e["payload"]}
                for e in events
            ]
            await self.ingest_events(event_dicts, run_id=run_id)

    def get_active_run(self) -> Optional[Run]:
        """Return the currently active run, if any."""
        if self.active_run_id and self.active_run_id in self.runs:
            run = self.runs[self.active_run_id]
            if run.status == "running":
                return run
        return None

    def get_latest_run(self) -> Optional[Run]:
        """Return the most recent run regardless of status."""
        if self.active_run_id and self.active_run_id in self.runs:
            return self.runs[self.active_run_id]
        if self.runs:
            return list(self.runs.values())[-1]
        return None

    async def ingest_events(self, events: list[dict], run_id: str | None = None) -> None:
        """Ingest a batch of events into the appropriate run."""
        async with self._lock:
            rid = run_id or self.active_run_id
            if not rid or rid not in self.runs:
                # Create run if it doesn't exist yet (script_path updated by run_start event).
                # store=True so the run is persisted to NEBO_STORAGE_DIR — matches /run's
                # default. Set NEBO_NO_STORE=1 to opt out (e.g., for ephemeral test daemons).
                store = not os.environ.get("NEBO_NO_STORE")
                run = self.create_run("direct", run_id=rid, store=store)
                rid = run.id

            run = self.runs[rid]
            if run.status == "starting":
                run.status = "running"

            for event in events:
                self._process_event(run, event)

        # Broadcast to WebSocket clients
        for ws in self._ws_clients[:]:
            try:
                await ws.send_json({"type": "batch", "run_id": rid, "events": events})
            except Exception:
                if ws in self._ws_clients:
                    self._ws_clients.remove(ws)

        # Notify any waiters of new significant events
        async with self._event_notify:
            self._event_notify.notify_all()

    def _process_event(self, run: Run, event: dict) -> None:
        """Process a single event into run state."""
        # Write to .nebo file if storage is enabled
        writer = getattr(run, "_file_writer", None)
        if writer is not None:
            entry_type = event.get("type", "log")
            writer.write_entry(entry_type, dict(event))

        etype = event.get("type", "")
        loggable_id = event.get("loggable_id")

        if etype == "log":
            entry = LogEntry(
                timestamp=event.get("timestamp", time.time()),
                node=loggable_id,
                message=event.get("message", ""),
                level=event.get("level", "info"),
                step=event.get("step"),
            )
            run.logs.append(entry)
            if loggable_id and loggable_id in run.loggables:
                run.loggables[loggable_id].logs.append(event)

        elif etype == "metric":
            lid = event.get("loggable_id", "")
            if not lid or lid not in run.loggables:
                return
            mname = event.get("name", "")
            mtype = event.get("metric_type", "line")
            series = run.loggables[lid].metrics.setdefault(
                mname, {"type": mtype, "entries": []}
            )
            # Server is tolerant of type mismatches: first-writer-wins.
            new_entry: dict[str, Any] = {
                "step": event.get("step"),
                "value": event.get("value"),
                "tags": list(event.get("tags") or []),
                "timestamp": event.get("timestamp"),
            }
            if "colors" in event:
                new_entry["colors"] = bool(event["colors"])
            # Line metrics accumulate over time; every other chart type
            # is a snapshot — re-emitting the same name overwrites the
            # prior value rather than stacking another entry.
            if mtype == "line":
                series["entries"].append(new_entry)
            else:
                series["entries"] = [new_entry]

        elif etype == "progress":
            if loggable_id and loggable_id in run.loggables:
                run.loggables[loggable_id].progress = event.get("data", {})

        elif etype == "error":
            data = event.get("data", event)
            node = run.loggables.get(loggable_id or data.get("loggable_id", ""))
            error = ErrorEntry(
                timestamp=data.get("timestamp", time.time()),
                node_name=data.get("loggable_id", loggable_id or ""),
                node_docstring=node.docstring if node else data.get("docstring"),
                exception_type=data.get("type", ""),
                exception_message=data.get("error", ""),
                traceback=data.get("traceback", ""),
                execution_count=node.exec_count if node else data.get("exec_count", 0),
                params=node.params if node else data.get("params", {}),
                last_logs=[l.get("message", "") for l in (node.logs[-5:] if node else [])],
            )
            run.errors.append(error)
            if node:
                node.errors.append(data)
            run.significant_events.append({
                "type": "error",
                "timestamp": error.timestamp,
                "loggable_id": error.node_name,
                "message": error.exception_message,
            })

        elif etype == "loggable_register":
            data = event.get("data", {})
            lid = data.get("loggable_id", loggable_id or "")
            kind = data.get("kind", "node")
            if lid and lid not in run.loggables:
                run.loggables[lid] = LoggableState(
                    loggable_id=lid,
                    kind=kind,
                    func_name=data.get("func_name") or "",
                    docstring=data.get("docstring"),
                    pausable=data.get("pausable", False),
                    group=data.get("group"),
                    ui_hints=data.get("ui_hints"),
                )

        elif etype == "node_executed":
            data = event.get("data", {})
            lid = data.get("loggable_id", loggable_id or "")
            caller = data.get("caller")
            if lid and lid in run.loggables:
                run.loggables[lid].exec_count += 1
            if caller and lid:
                key = (caller, lid)
                if key not in run._edge_set:
                    run._edge_set.add(key)
                    run.edges.append({"source": caller, "target": lid})
                    if lid in run.loggables:
                        run.loggables[lid].is_source = False

        elif etype == "edge":
            data = event.get("data", {})
            src = data.get("source", "")
            tgt = data.get("target", "")
            key = (src, tgt)
            if key not in run._edge_set:
                run._edge_set.add(key)
                run.edges.append({"source": src, "target": tgt})
                if tgt in run.loggables:
                    run.loggables[tgt].is_source = False

        elif etype == "image":
            if loggable_id and loggable_id in run.loggables:
                media_id = uuid.uuid4().hex[:16]
                self._media_store[media_id] = event.pop("data", "")
                event["media_id"] = media_id
                run.loggables[loggable_id].images.append({
                    "media_id": media_id,
                    "name": event.get("name", ""),
                    "step": event.get("step"),
                    "timestamp": event.get("timestamp", time.time()),
                    "labels": event.get("labels"),
                })

        elif etype == "audio":
            if loggable_id and loggable_id in run.loggables:
                media_id = uuid.uuid4().hex[:16]
                self._media_store[media_id] = event.pop("data", "")
                event["media_id"] = media_id
                run.loggables[loggable_id].audio.append({
                    "media_id": media_id,
                    "name": event.get("name", ""),
                    "sr": event.get("sr", 16000),
                    "step": event.get("step"),
                    "timestamp": event.get("timestamp", time.time()),
                })

        elif etype == "ask_prompt":
            ask_id = event.get("ask_id") or event.get("data", {}).get("ask_id", "")
            if ask_id:
                run.pending_asks[ask_id] = event
                run.significant_events.append({
                    "type": "ask_prompt",
                    "timestamp": event.get("timestamp", time.time()),
                    "ask_id": ask_id,
                    "question": event.get("question", event.get("data", {}).get("question", "")),
                })

        elif etype == "description":
            desc = event.get("data", {}).get("description", "")
            if run.workflow_description:
                run.workflow_description += "\n\n" + desc
            else:
                run.workflow_description = desc

        elif etype == "config":
            cfg = event.get("data", {})
            run.config = cfg
            if loggable_id and loggable_id in run.loggables:
                run.loggables[loggable_id].params.update(cfg)

        elif etype == "ui_config":
            run.ui_config = event.get("data", {})

        elif etype == "run_config":
            run.run_config = event.get("data", {})

        elif etype == "run_start":
            data = event.get("data", {})
            script_path = data.get("script_path", "")
            if script_path:
                run.script_path = script_path
            # Store run_name if provided
            run_name = data.get("run_name")
            if run_name is not None:
                run.run_name = run_name
            # Resume support: set status back to running
            run.status = "running"
            if self.active_run_id is None:
                self.active_run_id = run.id
            # Seed the implicit __global__ loggable so logs that arrive without
            # a node context (e.g. nb.log() outside an @nb.fn) have a home.
            run.loggables.setdefault(
                "__global__",
                LoggableState(loggable_id="__global__", kind="global"),
            )
            # Enable storage if SDK requests it and daemon allows it
            store = data.get("store", True)
            if store and not os.environ.get("NEBO_NO_STORE") and not getattr(run, "_file_writer", None):
                from nebo.core.fileformat import NeboFileWriter
                self.init_storage()
                timestamp = time.strftime("%Y-%m-%d_%H%M%S")
                filepath = os.path.join(NEBO_STORAGE_DIR, f"{timestamp}_{run.id}.nebo")
                run._file_stream = open(filepath, "wb")
                run._file_writer = NeboFileWriter(
                    run._file_stream, run_id=run.id, script_path=script_path, args=run.args,
                )
                run._file_writer.write_header()

        elif etype == "run_completed":
            data = event.get("data", {})
            exit_code = data.get("exit_code", 0)
            run.status = "completed" if exit_code == 0 else "crashed"
            run.exit_code = exit_code
            run.ended_at = datetime.now()
            if self.active_run_id == run.id:
                self.active_run_id = None
            run.significant_events.append({
                "type": "run_completed",
                "timestamp": time.time(),
                "exit_code": exit_code,
                "status": run.status,
            })
            self.finalize_run(run.id)

    def mark_run_completed(self, run_id: str, exit_code: int = 0) -> None:
        """Mark a run as completed."""
        if run_id in self.runs:
            run = self.runs[run_id]
            run.status = "completed" if exit_code == 0 else "crashed"
            run.exit_code = exit_code
            run.ended_at = datetime.now()
            if self.active_run_id == run_id:
                self.active_run_id = None

    def mark_run_stopped(self, run_id: str) -> None:
        """Mark a run as manually stopped."""
        if run_id in self.runs:
            run = self.runs[run_id]
            run.status = "stopped"
            run.ended_at = datetime.now()
            if self.active_run_id == run_id:
                self.active_run_id = None


def create_daemon_app(state: DaemonState | None = None, port: int | None = None) -> Any:
    """Create the FastAPI daemon application.

    Args:
        state: Optional pre-existing DaemonState. Creates new if None.
        port: Daemon port for injecting into pipeline subprocess env.
              Falls back to NEBO_DAEMON_PORT env var, then 7861.

    Returns:
        FastAPI application instance.
    """
    from fastapi import FastAPI
    from fastapi.responses import JSONResponse

    from nebo.server.runner import PipelineRunner

    if port is None:
        port = int(os.environ.get("NEBO_DAEMON_PORT", "7861"))

    if state is None:
        state = DaemonState()

    # --- Pipeline runner wired into daemon state ---
    runner = PipelineRunner(
        on_started=lambda rid: None,  # Run already created in /run handler
        on_completed=lambda rid, code: state.mark_run_completed(rid, code),
        on_output=lambda rid, stream, line: _capture_output(state, rid, stream, line),
    )

    def _capture_output(st: DaemonState, run_id: str, stream: str, line: str) -> None:
        run = st.runs.get(run_id)
        if run:
            if stream == "stdout":
                run.stdout_lines.append(line)
            else:
                run.stderr_lines.append(line)

    app = FastAPI(title="Nebo Daemon Server")
    app.state.daemon = state
    app.state.runner = runner

    # CORS for development (Vite dev server)
    from starlette.middleware.cors import CORSMiddleware
    from starlette.types import ASGIApp, Receive, Scope, Send

    class CORSWithWebSocket:
        """Wraps CORSMiddleware but lets WebSocket connections pass through."""
        def __init__(self, app: ASGIApp) -> None:
            self.app = app
            self.cors = CORSMiddleware(
                app,
                allow_origins=["*"],
                allow_methods=["*"],
                allow_headers=["*"],
            )

        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
            if scope["type"] == "websocket":
                await self.app(scope, receive, send)
            else:
                await self.cors(scope, receive, send)

    app.add_middleware(CORSWithWebSocket)

    # Optional bearer-token auth, split into independent read/write
    # gates. When the daemon process has NEBO_API_TOKEN set (e.g. as a
    # Hugging Face Space secret) the gates kick in:
    #
    #   read mode (NEBO_READ_MODE, default 'public'):
    #     'public'  → GET requests pass without a token
    #     'private' → GET requests require a token
    #   write mode (NEBO_WRITE_MODE, default 'private'):
    #     'public'  → non-GET requests pass without a token
    #     'private' → non-GET requests require a token
    #
    # /health and the static UI bundle stay open in every mode so
    # external healthchecks and the iframe bootstrap HTML keep working.
    # Without NEBO_API_TOKEN set, both gates are open regardless of
    # mode — preserves the local-dev "no auth needed" workflow.
    expected_token = os.environ.get("NEBO_API_TOKEN")
    _read_private = os.environ.get("NEBO_READ_MODE", "public").lower() == "private"
    _write_private = os.environ.get("NEBO_WRITE_MODE", "private").lower() == "private"
    _GATED_PREFIXES = (
        "/events", "/ingest", "/run", "/runs",
        "/logs", "/errors", "/loggables", "/load",
        "/chat", "/graph",
    )

    def _is_read(method: str) -> bool:
        # GET/HEAD are reads; everything else (POST/PUT/PATCH/DELETE)
        # mutates state and gates on write mode.
        return method.upper() in ("GET", "HEAD")

    if expected_token:
        from fastapi.responses import JSONResponse

        @app.middleware("http")
        async def _auth_middleware(request, call_next):
            path = request.url.path
            if path == "/health" or not any(path.startswith(p) for p in _GATED_PREFIXES):
                return await call_next(request)
            # CORS preflight requests can't carry custom headers; let
            # them through and rely on the eventual real request to
            # authenticate.
            if request.method == "OPTIONS":
                return await call_next(request)
            require_token = _read_private if _is_read(request.method) else _write_private
            if not require_token:
                return await call_next(request)
            token = request.headers.get("x-nebo-token") or request.query_params.get("token")
            if token != expected_token:
                return JSONResponse(status_code=401, content={"error": "unauthorized"})
            return await call_next(request)

    @app.get("/health")
    async def health():
        return {
            "status": "ok",
            "timestamp": time.time(),
            "active_run": state.active_run_id,
            "total_runs": len(state.runs),
        }

    @app.post("/events")
    async def ingest_events(events: list[dict[str, Any]], run_id: str | None = None):
        await state.ingest_events(events, run_id)
        return {"status": "ok", "count": len(events)}

    # Legacy endpoint for backward compat
    @app.post("/ingest")
    async def ingest_legacy(events: list[dict[str, Any]]):
        await state.ingest_events(events)
        return {"status": "ok", "count": len(events)}

    @app.post("/run")
    async def start_run(body: dict[str, Any]):
        """Start a pipeline script as a managed subprocess."""
        script_path = body.get("script_path", "")
        args = body.get("args", [])
        run_id = body.get("run_id") or f"run_{int(time.time())}_{len(state.runs)}"
        store = not os.environ.get("NEBO_NO_STORE")
        if not script_path:
            return JSONResponse(status_code=400, content={"error": "script_path is required"})
        try:
            run = state.create_run(script_path, args, run_id, store=store)
            proc = runner.start(
                run_id=run_id,
                script_path=script_path,
                args=args,
                port=port,
            )
            run.process = proc
            run.status = "running"
            return {"run_id": run_id, "pid": proc.pid, "status": "started"}
        except FileNotFoundError as e:
            return JSONResponse(status_code=404, content={"error": str(e)})
        except Exception as e:
            return JSONResponse(status_code=500, content={"error": str(e)})

    @app.post("/runs/{run_id}/stop")
    async def stop_run(run_id: str):  # noqa: path param only
        """Stop a running pipeline."""
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        exit_code = runner.stop(run_id)
        if exit_code is None and not runner.is_running(run_id):
            state.mark_run_stopped(run_id)
            return {"run_id": run_id, "status": "stopped", "exit_code": None}
        state.mark_run_stopped(run_id)
        return {"run_id": run_id, "status": "stopped", "exit_code": exit_code}

    @app.get("/runs")
    async def list_runs():
        return {
            "runs": [r.get_summary() for r in state.runs.values()],
            "active_run": state.active_run_id,
        }

    @app.get("/runs/{run_id}")
    async def get_run(run_id: str):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        return state.runs[run_id].get_summary()

    @app.get("/runs/{run_id}/graph")
    async def get_run_graph(run_id: str):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        return state.runs[run_id].get_graph()

    @app.get("/runs/{run_id}/logs")
    async def get_run_logs(run_id: str, loggable_id: str | None = None, limit: int = 100):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        run = state.runs[run_id]
        logs = run.logs
        if loggable_id:
            logs = [l for l in logs if l.node == loggable_id]
        return {"logs": [{"timestamp": l.timestamp, "loggable_id": l.node, "message": l.message, "level": l.level, "step": l.step} for l in logs[-limit:]]}

    @app.get("/runs/{run_id}/errors")
    async def get_run_errors(run_id: str):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        run = state.runs[run_id]
        return {
            "errors": [
                {
                    "timestamp": e.timestamp,
                    "node_name": e.node_name,
                    "node_docstring": e.node_docstring,
                    "exception_type": e.exception_type,
                    "exception_message": e.exception_message,
                    "traceback": e.traceback,
                    "execution_count": e.execution_count,
                    "params": e.params,
                    "last_logs": e.last_logs,
                }
                for e in run.errors
            ]
        }

    @app.get("/runs/{run_id}/metrics")
    async def get_run_metrics(run_id: str):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        run = state.runs[run_id]
        metrics: dict[str, dict[str, dict]] = {}
        for lid, l in run.loggables.items():
            if l.metrics:
                metrics[lid] = l.metrics
        return {"metrics": metrics}

    @app.get("/runs/{run_id}/images")
    async def get_run_images(run_id: str):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        run = state.runs[run_id]
        images: dict[str, list] = {}
        for lid, l in run.loggables.items():
            if l.images:
                images[lid] = [
                    {
                        "loggable_id": lid,
                        "media_id": img.get("media_id", ""),
                        "name": img.get("name", ""),
                        "step": img.get("step"),
                        "timestamp": img.get("timestamp", 0),
                        "labels": img.get("labels"),
                    }
                    for img in l.images
                ]
        return {"images": images}

    @app.get("/runs/{run_id}/audio")
    async def get_run_audio(run_id: str):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        run = state.runs[run_id]
        audio: dict[str, list] = {}
        for lid, l in run.loggables.items():
            if l.audio:
                audio[lid] = [
                    {
                        "loggable_id": lid,
                        "media_id": a.get("media_id", ""),
                        "name": a.get("name", ""),
                        "sr": a.get("sr", 16000),
                        "step": a.get("step"),
                        "timestamp": a.get("timestamp", 0),
                    }
                    for a in l.audio
                ]
        return {"audio": audio}

    @app.get("/runs/{run_id}/media/{media_id}")
    async def get_media(run_id: str, media_id: str):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        if media_id not in state._media_store:
            return JSONResponse(status_code=404, content={"error": f"Media '{media_id}' not found"})
        return {"data": state._media_store[media_id]}

    @app.get("/runs/{run_id}/loggables/{loggable_id}")
    async def get_run_loggable(run_id: str, loggable_id: str):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        run = state.runs[run_id]
        if loggable_id not in run.loggables:
            return JSONResponse(status_code=404, content={"error": f"Loggable '{loggable_id}' not found"})
        lg = run.loggables[loggable_id]
        return {
            "loggable_id": lg.loggable_id, "kind": lg.kind, "func_name": lg.func_name, "docstring": lg.docstring,
            "exec_count": lg.exec_count,
            "is_source": lg.is_source, "params": lg.params,
            "recent_logs": lg.logs[-20:], "errors": lg.errors,
            "metrics": lg.metrics, "progress": lg.progress,
        }

    # --- Ask / respond endpoints ---

    def _get_run_or_404(run_id: str):
        if run_id not in state.runs:
            return None, JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})
        return state.runs[run_id], None

    @app.get("/runs/{run_id}/asks")
    async def get_run_asks(run_id: str):
        run, err = _get_run_or_404(run_id)
        if err:
            return err
        return {"pending": list(run.pending_asks.values())}

    @app.get("/runs/{run_id}/ask/{ask_id}/respond")
    async def get_ask_response(run_id: str, ask_id: str):
        run, err = _get_run_or_404(run_id)
        if err:
            return err
        if ask_id in run.ask_responses:
            return {"status": "answered", "response": run.ask_responses[ask_id]}
        if ask_id in run.pending_asks:
            return {"status": "pending"}
        return JSONResponse(status_code=404, content={"error": f"Ask '{ask_id}' not found"})

    @app.post("/runs/{run_id}/ask/{ask_id}/respond")
    async def post_ask_response(run_id: str, ask_id: str, body: dict):
        run, err = _get_run_or_404(run_id)
        if err:
            return err
        response = body.get("response", "")
        run.ask_responses[ask_id] = response
        run.pending_asks.pop(ask_id, None)
        return {"status": "ok"}

    # --- Pause / unpause endpoints ---

    @app.get("/runs/{run_id}/pause")
    async def get_pause_state(run_id: str):
        run, err = _get_run_or_404(run_id)
        if err:
            return err
        return {"paused": run.paused}

    @app.post("/runs/{run_id}/pause")
    async def pause_run(run_id: str):
        run, err = _get_run_or_404(run_id)
        if err:
            return err
        run.paused = True
        # Broadcast pause state to WebSocket clients
        for ws in state._ws_clients[:]:
            try:
                await ws.send_json({
                    "type": "batch",
                    "run_id": run_id,
                    "events": [{"type": "pause_state", "data": {"paused": True}}],
                })
            except Exception:
                if ws in state._ws_clients:
                    state._ws_clients.remove(ws)
        return {"status": "ok", "paused": True}

    @app.post("/runs/{run_id}/unpause")
    async def unpause_run(run_id: str):
        run, err = _get_run_or_404(run_id)
        if err:
            return err
        run.paused = False
        # Broadcast unpause state to WebSocket clients
        for ws in state._ws_clients[:]:
            try:
                await ws.send_json({
                    "type": "batch",
                    "run_id": run_id,
                    "events": [{"type": "pause_state", "data": {"paused": False}}],
                })
            except Exception:
                if ws in state._ws_clients:
                    state._ws_clients.remove(ws)
        return {"status": "ok", "paused": False}

    # --- Event wait endpoint ---

    @app.get("/runs/{run_id}/events/wait")
    async def wait_for_event(
        run_id: str,
        types: str = "error,run_completed,ask_prompt",
        timeout: float = 300,
        since: float = 0,
    ):
        if run_id not in state.runs:
            return JSONResponse(status_code=404, content={"error": f"Run '{run_id}' not found"})

        wanted = set(t.strip() for t in types.split(","))
        deadline = asyncio.get_event_loop().time() + timeout

        def _find_match() -> Optional[dict]:
            run = state.runs[run_id]
            for evt in run.significant_events:
                if evt["type"] in wanted and evt.get("timestamp", 0) > since:
                    return evt
            return None

        # Check for existing matching events first
        match = _find_match()
        if match:
            return {"status": "event", "event": match}

        # Wait for new events with condition variable
        async with state._event_notify:
            while True:
                remaining = deadline - asyncio.get_event_loop().time()
                if remaining <= 0:
                    break
                try:
                    await asyncio.wait_for(
                        state._event_notify.wait(), timeout=remaining
                    )
                except asyncio.TimeoutError:
                    break
                match = _find_match()
                if match:
                    return {"status": "event", "event": match}

        run = state.runs[run_id]
        return {"status": "timeout", "run_status": run.status}

    # Backward-compatible endpoints (use latest run)
    @app.get("/graph")
    async def get_graph():
        run = state.get_latest_run()
        if not run:
            return {"nodes": {}, "edges": [], "workflow_description": None}
        return run.get_graph()

    @app.get("/logs")
    async def get_logs(loggable_id: str | None = None, limit: int = 100):
        run = state.get_latest_run()
        if not run:
            return {"logs": []}
        logs = run.logs
        if loggable_id:
            logs = [l for l in logs if l.node == loggable_id]
        return {"logs": [{"timestamp": l.timestamp, "loggable_id": l.node, "message": l.message} for l in logs[-limit:]]}

    @app.get("/errors")
    async def get_errors():
        run = state.get_latest_run()
        if not run:
            return {"errors": []}
        return {
            "errors": [
                {
                    "timestamp": e.timestamp,
                    "node_name": e.node_name,
                    "exception_type": e.exception_type,
                    "exception_message": e.exception_message,
                    "traceback": e.traceback,
                }
                for e in run.errors
            ]
        }

    @app.get("/loggables/{loggable_id}")
    async def get_loggable(loggable_id: str):
        run = state.get_latest_run()
        if not run:
            return JSONResponse(status_code=404, content={"error": "No runs"})
        if loggable_id not in run.loggables:
            return JSONResponse(status_code=404, content={"error": f"Loggable '{loggable_id}' not found"})
        lg = run.loggables[loggable_id]
        return {
            "loggable_id": lg.loggable_id, "kind": lg.kind, "func_name": lg.func_name, "docstring": lg.docstring,
            "exec_count": lg.exec_count, "is_source": lg.is_source, "params": lg.params,
            "recent_logs": lg.logs[-20:], "errors": lg.errors,
            "metrics": lg.metrics, "progress": lg.progress,
        }

    @app.post("/load")
    async def load_file(body: dict[str, Any]):
        """Load a .nebo file into the daemon for viewing and Q&A."""
        filepath = body.get("filepath", "")
        if not filepath or not os.path.exists(filepath):
            return JSONResponse(status_code=404, content={"error": f"File not found: {filepath}"})
        try:
            await state.load_nebo_file(filepath)
            return {"status": "loaded", "filepath": filepath}
        except Exception as e:
            return JSONResponse(status_code=500, content={"error": str(e)})

    @app.post("/chat")
    async def chat(body: dict[str, Any]):
        """Q&A via Claude Code CLI with streaming response."""
        import json as _json
        from starlette.responses import StreamingResponse

        question = body.get("question", "")
        run_id = body.get("run_id") or state.active_run_id

        if not run_id:
            return JSONResponse(status_code=400, content={"error": "No run specified"})
        if not question:
            return JSONResponse(status_code=400, content={"error": "No question provided"})

        from nebo.server.chat import stream_chat_response

        server_url = f"http://localhost:{port}"

        async def generate():
            async for chunk in stream_chat_response(question, run_id, server_url):
                yield f"data: {_json.dumps({'text': chunk})}\n\n"
            yield "data: [DONE]\n\n"

        return StreamingResponse(generate(), media_type="text/event-stream")

    @app.websocket("/stream")
    async def websocket_endpoint(ws: WebSocket):
        # Browsers can't set custom WebSocket headers, so accept the
        # token from `?token=...` as well as `X-Nebo-Token`. The
        # handshake is gated by read mode (since the WS primarily
        # broadcasts state to subscribers) and inbound `receive_text`
        # is gated by write mode (clients can also push events here).
        client_authed = False
        if expected_token:
            token = ws.query_params.get("token") or ws.headers.get("x-nebo-token")
            client_authed = token == expected_token
            if _read_private and not client_authed:
                await ws.close(code=4401)
                return
        await ws.accept()
        state._ws_clients.append(ws)
        try:
            while True:
                data = await ws.receive_text()
                # If write mode is private, silently ignore inbound
                # events from unauthenticated clients. They keep the
                # subscription so they still receive broadcasts.
                if expected_token and _write_private and not client_authed:
                    continue
                events = decode_batch(data)
                await state.ingest_events(events)
        except WebSocketDisconnect:
            if ws in state._ws_clients:
                state._ws_clients.remove(ws)
        except Exception:
            if ws in state._ws_clients:
                state._ws_clients.remove(ws)

    # Serve the web UI static files (must be last — catches all unmatched routes)
    static_dir = Path(__file__).parent / "static"
    if static_dir.is_dir():
        from fastapi.staticfiles import StaticFiles
        app.mount("/", StaticFiles(directory=str(static_dir), html=True), name="ui")

    return app
