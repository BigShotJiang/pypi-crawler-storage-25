"""
Style classes for openpyxl compatibility.

Provides Font, PatternFill, Border, Side, Alignment, and numbers
matching openpyxl.styles.
"""

from __future__ import annotations


class Font:
    """
    Font properties for a cell.

    Mirrors openpyxl.styles.Font.
    """

    def __init__(
        self,
        name: str | None = None,
        size: float | None = None,
        bold: bool = False,
        italic: bool = False,
        underline: str | None = None,
        strikethrough: bool = False,
        color: str | None = None,
    ):
        self.name = name
        self.size = size
        self.bold = bold
        self.italic = italic
        self.underline = underline
        self.strikethrough = strikethrough
        self.color = color

    def to_style_dict(self) -> dict[str, object]:
        """Convert to command style dictionary."""
        result: dict[str, object] = {}
        if self.name is not None:
            result["fontName"] = self.name
        if self.size is not None:
            result["fontSize"] = self.size
        if self.bold:
            result["bold"] = True
        if self.italic:
            result["italic"] = True
        if self.underline:
            result["underline"] = True
        if self.strikethrough:
            result["strikethrough"] = True
        if self.color:
            result["fontColor"] = self.color
        return result

    def __repr__(self) -> str:
        parts = []
        if self.name:
            parts.append(f"name={self.name!r}")
        if self.size:
            parts.append(f"size={self.size}")
        if self.bold:
            parts.append("bold=True")
        if self.italic:
            parts.append("italic=True")
        return f"Font({', '.join(parts)})"


class PatternFill:
    """
    Fill pattern for a cell.

    Mirrors openpyxl.styles.PatternFill.
    """

    def __init__(
        self,
        fill_type: str | None = None,
        fgColor: str | None = None,
        bgColor: str | None = None,
        patternType: str | None = None,
        start_color: str | None = None,  # Alias for fgColor (openpyxl compat)
        end_color: str | None = None,  # Alias for bgColor (openpyxl compat)
    ):
        self.fill_type = fill_type or patternType
        self.fgColor = fgColor or start_color
        self.bgColor = bgColor or end_color

    def to_style_dict(self) -> dict[str, object]:
        """Convert to command style dictionary."""
        result: dict[str, object] = {}
        if self.fgColor:
            result["backgroundColor"] = self.fgColor
        return result


class Side:
    """
    Border side specification.

    Mirrors openpyxl.styles.Side.
    """

    def __init__(
        self,
        style: str | None = None,
        color: str | None = None,
    ):
        self.style = style
        self.color = color

    def to_dict(self) -> dict[str, str]:
        result: dict[str, str] = {}
        if self.style:
            result["style"] = self.style
        if self.color:
            result["colorHex"] = self.color
        return result


class Border:
    """
    Cell border specification.

    Mirrors openpyxl.styles.Border.
    """

    def __init__(
        self,
        left: Side | None = None,
        right: Side | None = None,
        top: Side | None = None,
        bottom: Side | None = None,
    ):
        self.left = left
        self.right = right
        self.top = top
        self.bottom = bottom

    def to_style_dict(self) -> dict[str, object]:
        """Convert to command style dictionary.

        Note: API expects border style as string (e.g., 'thin', 'medium').
        """
        result: dict[str, object] = {}
        if self.top and self.top.style:
            result["borderTop"] = self.top.style
        if self.bottom and self.bottom.style:
            result["borderBottom"] = self.bottom.style
        if self.left and self.left.style:
            result["borderLeft"] = self.left.style
        if self.right and self.right.style:
            result["borderRight"] = self.right.style
        return result


class Alignment:
    """
    Cell alignment specification.

    Mirrors openpyxl.styles.Alignment.
    """

    def __init__(
        self,
        horizontal: str | None = None,
        vertical: str | None = None,
        wrap_text: bool = False,
        text_rotation: int = 0,
        shrink_to_fit: bool = False,
        indent: int = 0,
    ):
        self.horizontal = horizontal
        self.vertical = vertical
        self.wrap_text = wrap_text
        self.text_rotation = text_rotation
        self.shrink_to_fit = shrink_to_fit
        self.indent = indent

    def to_style_dict(self) -> dict[str, object]:
        """Convert to command style dictionary."""
        result: dict[str, object] = {}
        if self.horizontal:
            result["horizontalAlignment"] = self.horizontal
        if self.vertical:
            # Map openpyxl's "center" to API's "middle" for vertical alignment
            vert = "middle" if self.vertical == "center" else self.vertical
            result["verticalAlignment"] = vert
        if self.wrap_text:
            result["wrapText"] = True
        return result


# Number format constants (matching openpyxl.styles.numbers)
FORMAT_GENERAL = "General"
FORMAT_NUMBER = "0"
FORMAT_NUMBER_00 = "0.00"
FORMAT_NUMBER_COMMA_SEPARATED1 = "#,##0.00"
FORMAT_PERCENTAGE = "0%"
FORMAT_PERCENTAGE_00 = "0.00%"
FORMAT_DATE_YYYYMMDD2 = "yyyy-mm-dd"
FORMAT_DATE_DATETIME = "yyyy-mm-dd h:mm:ss"
FORMAT_CURRENCY_USD = '"$"#,##0.00'
FORMAT_CURRENCY_EUR = "[$\u20ac-407]#,##0.00"
