"""
Pivot tables — openpyxl.pivot parity (Tier C).

Maps to the rowsncolumns engine ``PivotTable`` shape consumed by
``createPivotTable``. The engine call is async; the applier handles the
promise. SDK-authored pivots and converter-imported pivots share the same
engine code path.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any, Literal

from .errors import ValidationError
from .utils import parse_range

PivotAggregator = Literal[
    "SUM", "AVERAGE", "MIN", "MAX", "COUNT", "COUNT_UNIQUE", "STDEV", "VARIANCE"
]


class PivotField:
    """A field used as a row, column, or value group in a pivot table.

    Mirrors openpyxl.pivot.fields.FieldItems / Field shapes.
    """

    def __init__(self, name: str, sort: Literal["asc", "desc"] | None = None):
        self.name = name
        self.sort = sort

    def to_engine_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"sourceColumnOffset": 0, "label": self.name}
        if self.sort:
            out["sortOrder"] = self.sort.upper()
        return out


class PivotValue:
    """A pivot value column with an aggregator.

    Mirrors openpyxl.pivot.fields.PivotValueField but trimmed for engine compat.
    """

    def __init__(
        self,
        name: str,
        aggregator: PivotAggregator = "SUM",
        formula: str | None = None,
    ):
        self.name = name
        self.aggregator = aggregator
        self.formula = formula

    def to_engine_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "sourceColumnOffset": 0,
            "name": self.name,
            "summarizeFunction": self.aggregator,
        }
        if self.formula:
            out["formula"] = self.formula
        return out


class PivotTable:
    """An Excel pivot table.

    Mirrors openpyxl.pivot.table.TableDefinition. Coordinate inputs are A1
    range strings and addresses (e.g. ``source="A1:E100"``, ``location="G1"``).
    """

    def __init__(
        self,
        name: str,
        source: str,
        location: str,
        rows: list[PivotField] | None = None,
        columns: list[PivotField] | None = None,
        values: list[PivotValue] | None = None,
        pivot_id: str | int | None = None,
    ):
        if not name:
            raise ValidationError("PivotTable name is required", "name")
        if not source:
            raise ValidationError("PivotTable source is required", "source")
        if not location:
            raise ValidationError("PivotTable location is required", "location")
        self.name = name
        self.source = source
        self.location = location
        self.rows: list[PivotField] = rows or []
        self.columns: list[PivotField] = columns or []
        self.values: list[PivotValue] = values or []
        self.pivot_id = pivot_id

    def to_engine_payload(self, source_sheet_id: int, target_sheet_id: int) -> dict[str, Any]:
        if not self.values:
            raise ValidationError(
                "PivotTable must have at least one value column; call .values.append(...)",
                "values",
            )
        start_row, start_col, end_row, end_col = parse_range(self.source)
        # location can be a single cell ("G1") or range; treat as anchor cell.
        from .utils import column_index_from_string, coordinate_from_string

        loc_clean = self.location.split(":")[0].replace("$", "")
        col_str, row = coordinate_from_string(loc_clean)
        col = column_index_from_string(col_str)

        # rowsncolumns expects 1-based, inclusive grid indices for the source
        # range (A1 → 1,1). targetPosition is also 1-based for consistency
        # with cell writes (SetCellValue takes row=1, col=1 for A1). Previous
        # `- 1` on both produced 0-based output that misaligned pivots.
        return {
            "pivotId": self.pivot_id or self.name,
            "name": self.name,
            "source": {
                "sheetId": source_sheet_id,
                "startRowIndex": start_row,
                "endRowIndex": end_row,
                "startColumnIndex": start_col,
                "endColumnIndex": end_col,
            },
            "targetPosition": {
                "sheetId": target_sheet_id,
                "rowIndex": row,
                "columnIndex": col,
            },
            "rows": [r.to_engine_dict() for r in self.rows],
            "columns": [c.to_engine_dict() for c in self.columns],
            "values": [v.to_engine_dict() for v in self.values],
        }


class PivotTableList:
    """Container exposed as ``wb.pivot_tables``."""

    def __init__(self) -> None:
        self.pivotTables: list[PivotTable] = []

    def append(self, pt: PivotTable) -> None:
        if not isinstance(pt, PivotTable):
            raise TypeError(f"append expects PivotTable, got {type(pt).__name__}")
        self.pivotTables.append(pt)

    def __iter__(self) -> Iterator[PivotTable]:
        return iter(self.pivotTables)

    def __len__(self) -> int:
        return len(self.pivotTables)
