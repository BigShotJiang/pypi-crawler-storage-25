"""
Cell proxy class.

Provides openpyxl-compatible Cell abstraction that operates
on remote workbooks via the XLSX Studio API.
"""

from __future__ import annotations

from datetime import date, datetime, time
from typing import TYPE_CHECKING, Any, cast

from .commands import (
    RemoveCellComment,
    SetCellComment,
    SetCellFormula,
    SetCellStyle,
    SetCellValue,
)
from .typing import CellSnapshot, CellStyle
from .utils import cell_reference, get_column_letter

if TYPE_CHECKING:
    from .batching import CommandBuffer
    from .styles import Alignment, Border, Font, PatternFill
    from .worksheet import Worksheet


class Cell:
    """
    Proxy for a single cell in a worksheet.

    Provides openpyxl-compatible Cell API that reads from snapshots
    and writes via commands to the XLSX Studio API.

    Example:
        ws = wb.active
        cell = ws['A1']
        cell.value = "Hello"
        cell.font = Font(bold=True)
    """

    def __init__(
        self,
        worksheet: Worksheet,
        row: int,
        col: int,
        snapshot: CellSnapshot | None = None,
    ):
        self._worksheet = worksheet
        self._row = row
        self._col = col
        self._snapshot = snapshot
        self._value: Any = snapshot.value if snapshot else None
        self._formula: str | None = snapshot.formula if snapshot else None
        self._font: Font | None = None
        self._fill: PatternFill | None = None
        self._border: Border | None = None
        self._alignment: Alignment | None = None
        self._number_format: str | None = None
        self._comment: Comment | None = None
        self._hyperlink: Hyperlink | None = None
        # Hydrate style proxies from the snapshot's interned cell-xf entry so
        # cell.font / cell.fill / cell.alignment / cell.border read back what
        # the engine already stored, not just what was written this session.
        if snapshot and snapshot.style:
            self._hydrate_styles_from_snapshot(snapshot.style)

    def _hydrate_styles_from_snapshot(self, style: CellStyle) -> None:
        """Wrap an interned ``CellStyle`` dict into Font/Fill/Alignment/Border."""
        # Lazy import to avoid the circular at module load.
        from .styles import Alignment, Border, Font, PatternFill, Side

        font_kwargs: dict[str, Any] = {}
        for k_in, k_out in (
            ("fontName", "name"),
            ("fontSize", "size"),
            ("bold", "bold"),
            ("italic", "italic"),
            ("underline", "underline"),
            ("strikethrough", "strikethrough"),
            ("fontColor", "color"),
        ):
            if k_in in style:
                font_kwargs[k_out] = style[k_in]  # type: ignore[literal-required]
        if font_kwargs:
            self._font = Font(**font_kwargs)

        if "backgroundColor" in style:
            self._fill = PatternFill(fill_type="solid", fgColor=style["backgroundColor"])

        align_kwargs: dict[str, Any] = {}
        if "horizontalAlignment" in style:
            align_kwargs["horizontal"] = style["horizontalAlignment"]
        if "verticalAlignment" in style:
            v = style["verticalAlignment"]
            # Engine uses "middle"; openpyxl uses "center".
            align_kwargs["vertical"] = "center" if v == "middle" else v
        if "wrapText" in style:
            align_kwargs["wrap_text"] = bool(style["wrapText"])
        if align_kwargs:
            self._alignment = Alignment(**align_kwargs)

        border_sides: dict[str, Side] = {}
        for k_in, k_out in (
            ("borderTop", "top"),
            ("borderBottom", "bottom"),
            ("borderLeft", "left"),
            ("borderRight", "right"),
        ):
            if k_in in style:
                border_sides[k_out] = Side(style=style[k_in])  # type: ignore[literal-required]
        if border_sides:
            self._border = Border(**border_sides)

        if "numberFormat" in style:
            self._number_format = style["numberFormat"]

    @property
    def _buffer(self) -> CommandBuffer:
        return self._worksheet._buffer

    @property
    def row(self) -> int:
        """1-based row number."""
        return self._row

    @property
    def column(self) -> int:
        """1-based column number."""
        return self._col

    @property
    def col_idx(self) -> int:
        """Alias for ``column`` (matches openpyxl)."""
        return self._col

    @property
    def column_letter(self) -> str:
        """Column letter (e.g., 'A', 'B', 'AA')."""
        return get_column_letter(self._col)

    @property
    def coordinate(self) -> str:
        """Cell coordinate string (e.g., 'A1')."""
        return cell_reference(self._row, self._col)

    @property
    def value(self) -> Any:
        """Get or set the cell value."""
        return self._value

    @value.setter
    def value(self, val: Any) -> None:
        """Set the cell value, emitting a SetCellValue command."""
        self._value = val
        self._formula = None  # Setting value clears formula

        # Determine cell type
        cell_type = None
        if val is None:
            cell_type = "empty"
        elif isinstance(val, bool):
            cell_type = "boolean"
        elif isinstance(val, (int, float)):
            cell_type = "number"
        elif isinstance(val, str):
            if val.startswith("="):
                # Treat as formula
                self._formula = val
                self._buffer.add(
                    SetCellFormula(
                        sheet_index=self._worksheet._index,
                        row=self._row,
                        col=self._col,
                        formula=val,
                    )
                )
                self._mirror_to_snapshot(value=None, cell_type="formula")
                return
            cell_type = "string"

        self._buffer.add(
            SetCellValue(
                sheet_index=self._worksheet._index,
                row=self._row,
                col=self._col,
                value=val,
                cell_type=cell_type,
            )
        )
        self._mirror_to_snapshot(value=val, cell_type=cell_type or "empty")

    def _mirror_to_snapshot(self, *, value: Any, cell_type: str) -> None:
        """Write through to the worksheet snapshot so dimension properties
        (`max_row`, `max_column`, `min_row`, `min_column`, `dimensions`)
        reflect pending buffered writes — not just what was loaded at
        snapshot time. Without this, e.g. a freshly-`append()`-ed table
        reports `max_row == 0`.
        """
        ws = self._worksheet
        if ws is None:
            return
        ws._snapshot.cells[self.coordinate] = CellSnapshot(
            row=self._row,
            col=self._col,
            value=value,
            cell_type=cast(Any, cell_type),
            formula=self._formula,
        )

    @property
    def data_type(self) -> str:
        """The data type of the cell (s=string, n=number, b=boolean, f=formula, d=date)."""
        if self._formula:
            return "f"
        if self._value is None:
            return "n"  # openpyxl default
        if isinstance(self._value, bool):
            return "b"
        if isinstance(self._value, (date, datetime, time)):
            return "d"
        if isinstance(self._value, (int, float)):
            return "n"
        return "s"

    @property
    def is_date(self) -> bool:
        """True if the cell value is a date/datetime/time (matches openpyxl)."""
        return isinstance(self._value, (date, datetime, time))

    @property
    def font(self) -> Font | None:
        """Get the cell font."""
        return self._font

    @font.setter
    def font(self, value: Font) -> None:
        """Set the cell font, emitting a SetCellStyle command."""
        self._font = value
        self._emit_style_command()

    @property
    def fill(self) -> PatternFill | None:
        """Get the cell fill."""
        return self._fill

    @fill.setter
    def fill(self, value: PatternFill) -> None:
        """Set the cell fill, emitting a SetCellStyle command."""
        self._fill = value
        self._emit_style_command()

    @property
    def border(self) -> Border | None:
        """Get the cell border."""
        return self._border

    @border.setter
    def border(self, value: Border) -> None:
        """Set the cell border, emitting a SetCellStyle command."""
        self._border = value
        self._emit_style_command()

    @property
    def alignment(self) -> Alignment | None:
        """Get the cell alignment."""
        return self._alignment

    @alignment.setter
    def alignment(self, value: Alignment) -> None:
        """Set the cell alignment, emitting a SetCellStyle command."""
        self._alignment = value
        self._emit_style_command()

    @property
    def number_format(self) -> str:
        """Get the cell number format."""
        return self._number_format or "General"

    @number_format.setter
    def number_format(self, value: str) -> None:
        """Set the cell number format."""
        self._number_format = value
        self._emit_style_command()

    @property
    def comment(self) -> Comment | None:
        """Get or set the cell comment.

        Returns a ``Comment`` object (matches openpyxl). Persistence is
        object-model only today — the engine's comment-thread API is hooked
        up at the Olympus client layer; SDK-authored comments are visible
        through ``cell.comment`` on the same in-process Workbook but a full
        round-trip wave is forthcoming.
        """
        if self._comment is not None:
            return self._comment
        if self._snapshot and self._snapshot.comment:
            self._comment = Comment(text=self._snapshot.comment)
            return self._comment
        return None

    @comment.setter
    def comment(self, value: Comment | str | None) -> None:
        if value is None:
            self._comment = None
            self._buffer.add(
                RemoveCellComment(
                    sheet_index=self._worksheet._index,
                    row=self._row,
                    col=self._col,
                )
            )
            return
        if isinstance(value, str):
            value = Comment(text=value)
        if not isinstance(value, Comment):
            raise TypeError(f"comment must be a Comment, str, or None; got {type(value).__name__}")
        self._comment = value
        self._buffer.add(
            SetCellComment(
                sheet_index=self._worksheet._index,
                row=self._row,
                col=self._col,
                text=value.text,
                author=value.author,
            )
        )

    @property
    def hyperlink(self) -> Hyperlink | None:
        """Get or set the cell hyperlink.

        Stored as a structured value (``{"kind": "hyperlink", "url": …}``)
        on write — the applier's existing ``getEffectiveStructuredValue`` path
        already understands ``kind === "hyperlink"`` (no new applier handler).
        """
        return self._hyperlink

    @hyperlink.setter
    def hyperlink(self, value: Hyperlink | str | None) -> None:
        if value is None:
            self._hyperlink = None
            return
        if isinstance(value, str):
            value = Hyperlink(target=value)
        if not isinstance(value, Hyperlink):
            raise TypeError(
                f"hyperlink must be a Hyperlink, str, or None; got {type(value).__name__}"
            )
        self._hyperlink = value
        # Write the structured value so it round-trips through the applier's
        # existing hyperlink-aware structuredValue path.
        self._buffer.add(
            SetCellValue(
                sheet_index=self._worksheet._index,
                row=self._row,
                col=self._col,
                value={
                    "kind": "hyperlink",
                    "url": value.target,
                    "display": value.display,
                    "tooltip": value.tooltip,
                    "location": value.location,
                },
                cell_type="string",
            )
        )

    def _emit_style_command(self) -> None:
        """Emit a SetCellStyle command with all current style properties."""
        style: dict[str, object] = {}

        if self._font:
            style.update(self._font.to_style_dict())
        if self._fill:
            style.update(self._fill.to_style_dict())
        if self._border:
            style.update(self._border.to_style_dict())
        if self._alignment:
            style.update(self._alignment.to_style_dict())
        if self._number_format:
            style["numberFormat"] = self._number_format

        if style:
            self._buffer.add(
                SetCellStyle(
                    sheet_index=self._worksheet._index,
                    row=self._row,
                    col=self._col,
                    style=cast(CellStyle, style),
                )
            )

    def __repr__(self) -> str:
        return f"<Cell {self._worksheet.title}.{self.coordinate}>"


class MergedCell(Cell):
    """A cell that is part of a merged range but is not the top-left cell.

    Inherits from ``Cell`` so ``isinstance(c, Cell)`` works (matches openpyxl)
    but rejects writes — only the anchor cell of a merge can carry a value.
    """

    @property
    def value(self) -> None:
        return None

    @value.setter
    def value(self, val: Any) -> None:
        raise AttributeError(
            f"Cannot assign to MergedCell {self.coordinate}; "
            "set the value on the anchor cell of the merge instead."
        )

    def __repr__(self) -> str:
        return f"<MergedCell {self._worksheet.title}.{self.coordinate}>"


class Comment:
    """A note attached to a cell.

    Mirrors ``openpyxl.comments.Comment``.
    """

    def __init__(
        self,
        text: str,
        author: str | None = None,
        height: float | None = None,
        width: float | None = None,
    ):
        self.text = text
        self.author = author
        self.height = height
        self.width = width

    # openpyxl alias
    @property
    def content(self) -> str:
        return self.text

    @content.setter
    def content(self, value: str) -> None:
        self.text = value

    def __repr__(self) -> str:
        return f"<Comment text={self.text!r} author={self.author!r}>"


class Hyperlink:
    """A hyperlink attached to a cell.

    Mirrors ``openpyxl.worksheet.hyperlink.Hyperlink``.
    """

    def __init__(
        self,
        target: str,
        display: str | None = None,
        tooltip: str | None = None,
        location: str | None = None,
        ref: str | None = None,
        id: str | None = None,
    ):
        self.target = target
        self.display = display
        self.tooltip = tooltip
        self.location = location
        self.ref = ref
        self.id = id

    def __repr__(self) -> str:
        return f"<Hyperlink target={self.target!r}>"
