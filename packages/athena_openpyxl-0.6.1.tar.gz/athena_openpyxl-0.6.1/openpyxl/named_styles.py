"""
Named styles — openpyxl.styles.NamedStyle parity.

Object-model only today: ``@rowsncolumns/spreadsheet-state`` doesn't have a
public ``createNamedStyle`` method on the Spreadsheet interface. Named styles
that the converter imports are preserved on round-trip via the cellXfs
registry, but SDK-authored named styles are stored in-process and resolved
lazily when a cell is assigned ``cell.style = "MyStyle"``.
"""

from __future__ import annotations

from typing import Any


class NamedStyle:
    """A named cell style.

    Mirrors openpyxl.styles.NamedStyle.
    """

    def __init__(
        self,
        name: str,
        font: Any = None,
        fill: Any = None,
        alignment: Any = None,
        border: Any = None,
        protection: Any = None,
        number_format: str | None = None,
        builtinId: int | None = None,
        hidden: bool = False,
    ):
        self.name = name
        self.font = font
        self.fill = fill
        self.alignment = alignment
        self.border = border
        self.protection = protection
        self.number_format = number_format
        self.builtinId = builtinId
        self.hidden = hidden

    def to_style_dict(self) -> dict[str, Any]:
        """Compose a style dict for SetCellStyle by merging child to_style_dict()s."""
        out: dict[str, Any] = {}
        for child in (self.font, self.fill, self.alignment, self.border):
            if child is not None and hasattr(child, "to_style_dict"):
                out.update(child.to_style_dict())
        if self.number_format:
            out["numberFormat"] = self.number_format
        return out

    def __repr__(self) -> str:
        return f"<NamedStyle name={self.name!r}>"


class NamedStyleList(list[NamedStyle]):
    """Container exposed as ``wb.named_styles``.

    Mirrors openpyxl's ``NamedStyleList`` (a ``list`` subclass with ``__contains__``
    accepting a style name string).
    """

    def __contains__(self, key: object) -> bool:
        if isinstance(key, str):
            return any(getattr(s, "name", None) == key for s in self)
        return super().__contains__(key)

    def get(self, name: str) -> NamedStyle | None:
        for s in self:
            if getattr(s, "name", None) == name:
                return s
        return None
