"""
Worksheet proxy class.

Provides openpyxl-compatible Worksheet abstraction that operates
on remote workbooks via the XLSX Studio API.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

from ..cell import Cell
from ..charts import _BaseChart
from ..commands import (
    AddConditionalFormat,
    AddDataValidation,
    CreateChart,
    CreatePivotTable,
    CreateTable,
    DeleteColumns,
    DeleteRows,
    DeleteTable,
    InsertColumns,
    InsertRows,
    RenameSheet,
    SetAutoFilter,
    SetColumnWidth,
    SetRowHeight,
    SetSheetProperties,
    SetSheetProtection,
)
from ..commands import (
    MergeCells as MergeCellsCmd,
)
from ..commands import (
    UnmergeCells as UnmergeCellsCmd,
)
from ..conditional_formatting import ConditionalFormattingList, _BaseRule
from ..datavalidation import DataValidation, DataValidationList
from ..pivot import PivotTable as PivotTableObject
from ..protection import SheetProtection
from ..tables import Table
from ..typing import SheetSnapshot
from ..utils import (
    cell_reference,
    column_index_from_string,
    coordinate_from_string,
    parse_range,
)

if TYPE_CHECKING:
    from ..batching import CommandBuffer
    from ..workbook import Workbook


class Worksheet:
    """
    Proxy for a worksheet in a workbook.

    Provides openpyxl-compatible Worksheet API that reads from snapshots
    and writes via commands to the XLSX Studio API.

    Example:
        ws = wb.active
        ws['A1'] = "Hello"
        ws['B1'] = 42
        ws.column_dimensions['A'].width = 20
    """

    def __init__(
        self,
        workbook: Workbook,
        index: int,
        snapshot: SheetSnapshot,
        buffer: CommandBuffer,
    ):
        self._workbook = workbook
        self._index = index
        self._snapshot = snapshot
        self._buffer = buffer
        self._cells: dict[str, Cell] = {}
        self._print_title_rows: str | None = None
        self._print_title_cols: str | None = None
        self._print_area: str | None = None
        self._page_setup = PrintPageSetup()
        self._page_margins = PageMargins()
        self._print_options = PrintOptions()
        self._data_validations = DataValidationList()
        self._conditional_formatting = ConditionalFormattingList(self)
        self._next_dv_id = 1
        self._next_cf_id = 1
        self._protection = SheetProtection()

        # Pre-populate cells from snapshot
        for cell_key, cell_snap in snapshot.cells.items():
            cell = Cell(self, cell_snap.row, cell_snap.col, cell_snap)
            self._cells[cell_key] = cell

    @property
    def parent(self) -> Workbook:
        """The parent Workbook this sheet belongs to."""
        return self._workbook

    @property
    def sheet_id(self) -> int:
        """The sheet ID (1-based, matching openpyxl)."""
        return self._index + 1

    @property
    def dimensions(self) -> str:
        """The range of cells containing data, e.g. 'A1:D10'."""
        if not self._snapshot.cells:
            return "A1:A1"
        from ..utils import range_reference

        return range_reference(
            self.min_row,
            self.min_column,
            self.max_row,
            self.max_column,
        )

    @property
    def title(self) -> str:
        """Get or set the sheet name."""
        return self._snapshot.name

    @title.setter
    def title(self, value: str) -> None:
        """Rename the sheet."""
        self._snapshot.name = value
        self._buffer.add(
            RenameSheet(
                sheet_index=self._index,
                name=value,
            )
        )

    @property
    def sheet_state(self) -> str:
        """Sheet visibility state."""
        return "hidden" if self._snapshot.hidden else "visible"

    @property
    def merged_cells(self) -> MergedCellRanges:
        """Access merged cell ranges."""
        return MergedCellRanges(self)

    @property
    def column_dimensions(self) -> ColumnDimensions:
        """Access column dimension settings."""
        return ColumnDimensions(self)

    @property
    def row_dimensions(self) -> RowDimensions:
        """Access row dimension settings."""
        return RowDimensions(self)

    @property
    def freeze_panes(self) -> str | None:
        """Get or set the freeze pane location."""
        if self._snapshot.frozen_rows == 0 and self._snapshot.frozen_cols == 0:
            return None
        return cell_reference(
            self._snapshot.frozen_rows + 1,
            self._snapshot.frozen_cols + 1,
        )

    @freeze_panes.setter
    def freeze_panes(self, value: str | None) -> None:
        """Set the freeze pane location (e.g., 'B2' freezes row 1 and column A)."""
        if value is None:
            frozen_rows = 0
            frozen_cols = 0
        else:
            col_str, row = coordinate_from_string(value)
            frozen_rows = row - 1
            frozen_cols = column_index_from_string(col_str) - 1

        self._snapshot.frozen_rows = frozen_rows
        self._snapshot.frozen_cols = frozen_cols
        self._buffer.add(
            SetSheetProperties(
                sheet_index=self._index,
                frozen_rows=frozen_rows,
                frozen_cols=frozen_cols,
            )
        )

    @property
    def auto_filter(self) -> AutoFilter:
        """Access auto-filter settings."""
        return AutoFilter(self)

    @property
    def tables(self) -> list[Table]:
        """List of tables on this sheet (matches openpyxl.worksheet.Worksheet.tables)."""
        return [Table.from_table_view(view) for view in self._snapshot.tables]

    @property
    def data_validations(self) -> DataValidationList:
        """Data validation rules (matches openpyxl.worksheet.Worksheet.data_validations)."""
        return self._data_validations

    def add_data_validation(self, dv: DataValidation) -> None:
        """Add a data validation rule and emit an ``AddDataValidation`` command."""
        if not isinstance(dv, DataValidation):
            raise TypeError(f"add_data_validation expects DataValidation, got {type(dv).__name__}")
        if not dv.ranges:
            raise ValueError("DataValidation has no ranges; call dv.add(range_string) first")

        sheet_id = self._numeric_sheet_id()
        rule_id = self._next_dv_id
        self._next_dv_id += 1
        record = dv.to_engine_record(sheet_id=sheet_id, rule_id=rule_id)
        self._data_validations.append(dv)
        self._buffer.add(AddDataValidation(sheet_index=self._index, rule_record=record))

    @property
    def conditional_formatting(self) -> ConditionalFormattingList:
        """Conditional formatting rules (matches openpyxl)."""
        return self._conditional_formatting

    @property
    def protection(self) -> SheetProtection:
        """Sheet protection settings (matches openpyxl)."""
        return self._protection

    @protection.setter
    def protection(self, value: SheetProtection) -> None:
        if not isinstance(value, SheetProtection):
            raise TypeError(f"protection must be a SheetProtection, got {type(value).__name__}")
        self._protection = value
        self._buffer.add(
            SetSheetProtection(
                sheet_index=self._index,
                protection=value.to_engine_record(),
            )
        )

    def protect(self, password: str | None = None) -> None:
        """Enable sheet protection (matches openpyxl convenience method)."""
        self._protection.sheet = True
        if password is not None:
            self._protection.password = password
        self._buffer.add(
            SetSheetProtection(
                sheet_index=self._index,
                protection=self._protection.to_engine_record(),
            )
        )

    def unprotect(self) -> None:
        """Disable sheet protection."""
        self._protection.sheet = False
        self._buffer.add(
            SetSheetProtection(
                sheet_index=self._index,
                protection=self._protection.to_engine_record(),
            )
        )

    def add_pivot_table(self, pivot_table: PivotTableObject) -> None:
        """Add a pivot table that materializes on this worksheet (matches openpyxl).

        ``pivot_table.source`` is the data source range; ``pivot_table.location``
        is the cell on this worksheet where the pivot result starts.
        """
        if not isinstance(pivot_table, PivotTableObject):
            raise TypeError(
                f"add_pivot_table expects a PivotTable, got {type(pivot_table).__name__}"
            )
        sheet_id = self._numeric_sheet_id()
        # Source defaults to this worksheet too unless the user passed a
        # qualified range (Sheet2!A1:E100). The applier resolves that on its end.
        source_sheet_id = sheet_id
        payload = pivot_table.to_engine_payload(
            source_sheet_id=source_sheet_id,
            target_sheet_id=sheet_id,
        )
        self._workbook.pivot_tables.append(pivot_table)
        self._buffer.add(CreatePivotTable(sheet_index=self._index, payload=payload))

    def add_chart(self, chart: _BaseChart, anchor: str = "E2") -> None:
        """Embed a chart on this sheet (matches openpyxl.worksheet.Worksheet.add_chart).

        ``anchor`` is the top-left cell where the chart overlay starts (default
        ``"E2"``, matching openpyxl's default placement to the right of the
        usual data).
        """
        if not isinstance(chart, _BaseChart):
            raise TypeError(f"add_chart expects a Chart, got {type(chart).__name__}")
        # Default categories to data labels' worksheet so add_data without
        # set_categories still validates with a useful error.
        payload = chart.to_engine_payload(
            sheet_id=self._numeric_sheet_id(),
            anchor_cell=anchor,
        )
        self._buffer.add(CreateChart(sheet_index=self._index, payload=payload))

    def _register_conditional_format(self, range_string: str, rule: _BaseRule) -> None:
        """Called by ConditionalFormattingList.add — emit the engine command."""
        sheet_id = self._numeric_sheet_id()
        rule_id = self._next_cf_id
        self._next_cf_id += 1
        engine_rule = rule.to_engine_rule(sheet_id=sheet_id, ranges=[range_string], rule_id=rule_id)
        self._buffer.add(AddConditionalFormat(sheet_index=self._index, rule=engine_rule))

    def _numeric_sheet_id(self) -> int:
        try:
            return int(self._snapshot.id)
        except (TypeError, ValueError):
            return self._index + 1

    def add_table(self, table: Table) -> None:
        """Add a table to the sheet.

        The serialized ``TableView`` is appended to the local snapshot so a
        subsequent ``ws.tables`` read returns it without a server round-trip,
        and a ``CreateTable`` command is buffered for the engine to apply
        through ``@rowsncolumns/spreadsheet-state``.
        """
        if not isinstance(table, Table):
            raise TypeError(f"add_table expects a Table, got: {type(table).__name__}")

        view = table.to_table_view(self._numeric_sheet_id())

        # Reject duplicate displayName on the same sheet (matches openpyxl).
        for existing in self._snapshot.tables:
            if existing.get("title") == table.displayName:
                raise ValueError(
                    f"Table named {table.displayName!r} already exists on sheet {self.title!r}"
                )

        self._snapshot.tables.append(view)
        self._buffer.add(
            CreateTable(
                sheet_index=self._index,
                table_view=view,
            )
        )

    def remove_table(self, table_id: int | str) -> None:
        """Remove a table from the sheet by id (or displayName)."""
        target_index: int | None = None
        for i, existing in enumerate(self._snapshot.tables):
            if str(existing.get("id")) == str(table_id) or existing.get("title") == table_id:
                target_index = i
                break
        if target_index is None:
            raise KeyError(f"No table with id or displayName {table_id!r} on this sheet")

        removed = self._snapshot.tables.pop(target_index)
        resolved_id = removed.get("id") or removed.get("title") or str(table_id)
        self._buffer.add(
            DeleteTable(
                sheet_index=self._index,
                table_id=resolved_id,
            )
        )

    @property
    def print_title_rows(self) -> str | None:
        """Rows to repeat at top of each printed page, e.g. '1:3'."""
        return self._print_title_rows

    @print_title_rows.setter
    def print_title_rows(self, value: str | None) -> None:
        self._print_title_rows = value

    @property
    def print_title_cols(self) -> str | None:
        """Columns to repeat at left of each printed page, e.g. 'A:C'."""
        return self._print_title_cols

    @print_title_cols.setter
    def print_title_cols(self, value: str | None) -> None:
        self._print_title_cols = value

    @property
    def print_area(self) -> str | None:
        """Range to print, e.g. 'A1:D50'. None means the entire sheet."""
        return self._print_area

    @print_area.setter
    def print_area(self, value: str | None) -> None:
        self._print_area = value

    @property
    def page_setup(self) -> PrintPageSetup:
        """Page setup options (paper size, orientation, scale, fitToPage)."""
        return self._page_setup

    @page_setup.setter
    def page_setup(self, value: PrintPageSetup) -> None:
        self._page_setup = value

    @property
    def page_margins(self) -> PageMargins:
        """Page margin settings (left, right, top, bottom, header, footer)."""
        return self._page_margins

    @page_margins.setter
    def page_margins(self, value: PageMargins) -> None:
        self._page_margins = value

    @property
    def print_options(self) -> PrintOptions:
        """Print options (gridlines, headings, centering)."""
        return self._print_options

    @print_options.setter
    def print_options(self, value: PrintOptions) -> None:
        self._print_options = value

    @property
    def max_row(self) -> int:
        """The maximum row number containing data."""
        if not self._snapshot.cells:
            return 0
        return max(c.row for c in self._snapshot.cells.values())

    @property
    def max_column(self) -> int:
        """The maximum column number containing data."""
        if not self._snapshot.cells:
            return 0
        return max(c.col for c in self._snapshot.cells.values())

    @property
    def min_row(self) -> int:
        """The minimum row number containing data."""
        if not self._snapshot.cells:
            return 1
        return min(c.row for c in self._snapshot.cells.values())

    @property
    def min_column(self) -> int:
        """The minimum column number containing data."""
        if not self._snapshot.cells:
            return 1
        return min(c.col for c in self._snapshot.cells.values())

    # -------------------------------------------------------------------------
    # Cell access
    # -------------------------------------------------------------------------

    def cell(self, row: int, column: int, value: Any = None) -> Cell:
        """
        Get or create a cell by row and column numbers.

        Args:
            row: 1-based row number
            column: 1-based column number
            value: Optional value to set

        Returns:
            Cell object
        """
        key = cell_reference(row, column)
        if key not in self._cells:
            snap = self._snapshot.cells.get(key)
            self._cells[key] = Cell(self, row, column, snap)

        cell = self._cells[key]
        if value is not None:
            cell.value = value
        return cell

    def __getitem__(
        self, key: str | int | tuple[Any, ...]
    ) -> Cell | tuple[Cell, ...] | tuple[tuple[Cell, ...], ...]:
        """
        Access cells by coordinate string, row number, or slice.

        Examples:
            ws['A1']         # single cell
            ws['A1:C3']     # range (returns tuple of tuples of cells)
            ws['A']         # column (returns tuple of cells)
            ws[1]           # row (returns tuple of cells)
        """
        if isinstance(key, int):
            # Row access
            return self._get_row(key)

        if isinstance(key, str):
            if ":" in key:
                # Range access
                return self._get_range(key)

            # Check if it's a column letter or cell reference
            if key.isalpha():
                # Column access
                return self._get_column(key)

            # Single cell
            col_str, row = coordinate_from_string(key)
            col = column_index_from_string(col_str)
            return self.cell(row, col)

        raise TypeError(f"Unsupported key type: {type(key)}")

    def __setitem__(self, key: str, value: Any) -> None:
        """Set a cell value by coordinate or range string.

        Examples:
            ws['A1'] = 'Hello'                   # single cell
            ws['A1:C1'] = ['x', 'y', 'z']        # 1D range, single row or column
            ws['A1:B2'] = [['a', 'b'], [1, 2]]   # 2D range
        """
        if not isinstance(key, str):
            raise TypeError(f"Can only set value by string key, got: {type(key).__name__}")

        if ":" not in key and not key.isalpha():
            col_str, row = coordinate_from_string(key)
            col = column_index_from_string(col_str)
            self.cell(row, col, value)
            return

        if ":" in key:
            self._set_range(key, value)
            return

        raise TypeError(f"Can only set value on single cell coordinates or ranges, got: {key}")

    def _set_range(self, range_str: str, value: Any) -> None:
        """Assign values to a rectangular range."""
        start_row, start_col, end_row, end_col = parse_range(range_str)
        n_rows = end_row - start_row + 1
        n_cols = end_col - start_col + 1

        if not isinstance(value, (list, tuple)):
            raise TypeError(
                f"Range assignment requires a list or tuple of values, got: {type(value).__name__}"
            )

        # 1D row: ws['A1:C1'] = [v1, v2, v3]
        if n_rows == 1 and not (value and isinstance(value[0], (list, tuple))):
            if len(value) != n_cols:
                raise ValueError(
                    f"Expected {n_cols} values for range {range_str}, got {len(value)}"
                )
            for offset, v in enumerate(value):
                self.cell(start_row, start_col + offset, v)
            return

        # 1D column: ws['A1:A3'] = [v1, v2, v3]
        if n_cols == 1 and not (value and isinstance(value[0], (list, tuple))):
            if len(value) != n_rows:
                raise ValueError(
                    f"Expected {n_rows} values for range {range_str}, got {len(value)}"
                )
            for offset, v in enumerate(value):
                self.cell(start_row + offset, start_col, v)
            return

        # 2D range
        if len(value) != n_rows:
            raise ValueError(f"Expected {n_rows} rows for range {range_str}, got {len(value)}")
        for row_offset, row_values in enumerate(value):
            if not isinstance(row_values, (list, tuple)):
                raise TypeError(
                    f"Row {row_offset} must be a list or tuple, got: {type(row_values).__name__}"
                )
            if len(row_values) != n_cols:
                raise ValueError(
                    f"Expected {n_cols} columns in row {row_offset}, got {len(row_values)}"
                )
            for col_offset, v in enumerate(row_values):
                self.cell(start_row + row_offset, start_col + col_offset, v)

    def _get_row(self, row: int) -> tuple[Cell, ...]:
        """Get all cells in a row."""
        max_col = self.max_column or 1
        return tuple(self.cell(row, col) for col in range(1, max_col + 1))

    def _get_column(self, col_letter: str) -> tuple[Cell, ...]:
        """Get all cells in a column."""
        col = column_index_from_string(col_letter)
        max_row = self.max_row or 1
        return tuple(self.cell(row, col) for row in range(1, max_row + 1))

    def _get_range(self, range_str: str) -> tuple[tuple[Cell, ...], ...]:
        """Get a rectangular range of cells."""
        start_row, start_col, end_row, end_col = parse_range(range_str)
        rows = []
        for row in range(start_row, end_row + 1):
            rows.append(tuple(self.cell(row, col) for col in range(start_col, end_col + 1)))
        return tuple(rows)

    def iter_rows(
        self,
        min_row: int | None = None,
        max_row: int | None = None,
        min_col: int | None = None,
        max_col: int | None = None,
        values_only: bool = False,
        named: bool = False,
    ) -> Iterator[Any]:
        """Iterate over rows of cells.

        Matches openpyxl.worksheet.Worksheet.iter_rows. The ``named`` kwarg
        is an Athena addition: when ``True``, yields ``dict`` rows keyed by
        the first row's header values (only meaningful with ``values_only``).
        """
        min_row = min_row or self.min_row
        max_row = max_row or self.max_row
        min_col = min_col or self.min_column
        max_col = max_col or self.max_column

        if named:
            headers = [str(self.cell(min_row, c).value or "") for c in range(min_col, max_col + 1)]
            for row in range(min_row + 1, max_row + 1):
                values = [self.cell(row, c).value for c in range(min_col, max_col + 1)]
                yield dict(zip(headers, values, strict=False))
            return

        for row in range(min_row, max_row + 1):
            if values_only:
                yield tuple(self.cell(row, col).value for col in range(min_col, max_col + 1))
            else:
                yield tuple(self.cell(row, col) for col in range(min_col, max_col + 1))

    def iter_cols(
        self,
        min_row: int | None = None,
        max_row: int | None = None,
        min_col: int | None = None,
        max_col: int | None = None,
        values_only: bool = False,
    ) -> Iterator[tuple[Any, ...]]:
        """
        Iterate over columns of cells.

        Matches openpyxl.worksheet.Worksheet.iter_cols behavior.
        """
        min_row = min_row or self.min_row
        max_row = max_row or self.max_row
        min_col = min_col or self.min_column
        max_col = max_col or self.max_column

        for col in range(min_col, max_col + 1):
            if values_only:
                yield tuple(self.cell(row, col).value for row in range(min_row, max_row + 1))
            else:
                yield tuple(self.cell(row, col) for row in range(min_row, max_row + 1))

    def append(self, row_data: list[Any] | tuple[Any, ...] | dict[Any, Any]) -> None:
        """
        Append a row of data to the bottom of the sheet.

        Args:
            row_data: A list/tuple of values, or a dict mapping column letter or
                      1-based column index to value (matches openpyxl behavior).
        """
        next_row = self.max_row + 1
        if isinstance(row_data, dict):
            for col_key, value in row_data.items():
                if isinstance(col_key, str):
                    col_idx = column_index_from_string(col_key)
                elif isinstance(col_key, int):
                    col_idx = col_key
                else:
                    raise TypeError(
                        f"Dict keys must be column letters or 1-based ints, "
                        f"got: {type(col_key).__name__}"
                    )
                self.cell(next_row, col_idx, value)
            return

        if not isinstance(row_data, (list, tuple)):
            raise TypeError(
                f"append() expects a list, tuple, or dict, got: {type(row_data).__name__}"
            )

        for col_idx, value in enumerate(row_data, start=1):
            self.cell(next_row, col_idx, value)

    # -------------------------------------------------------------------------
    # Row/Column operations
    # -------------------------------------------------------------------------

    def insert_rows(self, idx: int, amount: int = 1) -> None:
        """Insert rows before row idx."""
        self._buffer.add(
            InsertRows(
                sheet_index=self._index,
                row=idx,
                count=amount,
            )
        )

    def insert_cols(self, idx: int, amount: int = 1) -> None:
        """Insert columns before column idx."""
        self._buffer.add(
            InsertColumns(
                sheet_index=self._index,
                col=idx,
                count=amount,
            )
        )

    def delete_rows(self, idx: int, amount: int = 1) -> None:
        """Delete rows starting at row idx."""
        self._buffer.add(
            DeleteRows(
                sheet_index=self._index,
                row=idx,
                count=amount,
            )
        )

    def delete_cols(self, idx: int, amount: int = 1) -> None:
        """Delete columns starting at column idx."""
        self._buffer.add(
            DeleteColumns(
                sheet_index=self._index,
                col=idx,
                count=amount,
            )
        )

    # -------------------------------------------------------------------------
    # Merge operations
    # -------------------------------------------------------------------------

    def merge_cells(
        self,
        range_string: str | None = None,
        start_row: int | None = None,
        start_column: int | None = None,
        end_row: int | None = None,
        end_column: int | None = None,
    ) -> None:
        """
        Merge cells in a range.

        Can use either range_string ('A1:C3') or explicit row/col params.
        """
        if range_string:
            start_row, start_column, end_row, end_column = parse_range(range_string)

        if None in (start_row, start_column, end_row, end_column):
            raise ValueError(
                "Must provide range_string or all of start_row, start_column, end_row, end_column"
            )

        # At this point, None values have been validated above
        assert start_row is not None
        assert start_column is not None
        assert end_row is not None
        assert end_column is not None

        self._buffer.add(
            MergeCellsCmd(
                sheet_index=self._index,
                start_row=start_row,
                start_col=start_column,
                end_row=end_row,
                end_col=end_column,
            )
        )

    def unmerge_cells(
        self,
        range_string: str | None = None,
        start_row: int | None = None,
        start_column: int | None = None,
        end_row: int | None = None,
        end_column: int | None = None,
    ) -> None:
        """Unmerge a previously merged range."""
        if range_string:
            start_row, start_column, end_row, end_column = parse_range(range_string)

        if None in (start_row, start_column, end_row, end_column):
            raise ValueError(
                "Must provide range_string or all of start_row, start_column, end_row, end_column"
            )

        # At this point, None values have been validated above
        assert start_row is not None
        assert start_column is not None
        assert end_row is not None
        assert end_column is not None

        self._buffer.add(
            UnmergeCellsCmd(
                sheet_index=self._index,
                start_row=start_row,
                start_col=start_column,
                end_row=end_row,
                end_col=end_column,
            )
        )

    def __repr__(self) -> str:
        return f'<Worksheet "{self.title}">'


# -------------------------------------------------------------------------
# Helper classes
# -------------------------------------------------------------------------


class MergedCellRanges:
    """Access merged cell ranges in a worksheet."""

    def __init__(self, worksheet: Worksheet):
        self._worksheet = worksheet

    @property
    def ranges(self) -> list[str]:
        """List of merged range strings."""
        from ..utils import range_reference

        return [
            range_reference(mr.start_row, mr.start_col, mr.end_row, mr.end_col)
            for mr in self._worksheet._snapshot.merged_ranges
        ]

    def __iter__(self) -> Iterator[str]:
        return iter(self.ranges)

    def __len__(self) -> int:
        return len(self._worksheet._snapshot.merged_ranges)


class ColumnDimension:
    """Column dimension settings."""

    def __init__(self, worksheet: Worksheet, col: int):
        self._worksheet = worksheet
        self._col = col

    @property
    def width(self) -> float:
        """Column width in character units."""
        return self._worksheet._snapshot.column_widths.get(self._col, 8.43)

    @width.setter
    def width(self, value: float) -> None:
        self._worksheet._snapshot.column_widths[self._col] = value
        self._worksheet._buffer.add(
            SetColumnWidth(
                sheet_index=self._worksheet._index,
                col=self._col,
                width=value,
            )
        )


class ColumnDimensions:
    """Dictionary-like access to column dimensions."""

    def __init__(self, worksheet: Worksheet):
        self._worksheet = worksheet

    def __getitem__(self, key: str) -> ColumnDimension:
        col = column_index_from_string(key)
        return ColumnDimension(self._worksheet, col)


class RowDimension:
    """Row dimension settings."""

    def __init__(self, worksheet: Worksheet, row: int):
        self._worksheet = worksheet
        self._row = row

    @property
    def height(self) -> float:
        """Row height in points."""
        return self._worksheet._snapshot.row_heights.get(self._row, 15.0)

    @height.setter
    def height(self, value: float) -> None:
        self._worksheet._snapshot.row_heights[self._row] = value
        self._worksheet._buffer.add(
            SetRowHeight(
                sheet_index=self._worksheet._index,
                row=self._row,
                height=value,
            )
        )


class RowDimensions:
    """Dictionary-like access to row dimensions."""

    def __init__(self, worksheet: Worksheet):
        self._worksheet = worksheet

    def __getitem__(self, key: int) -> RowDimension:
        return RowDimension(self._worksheet, key)


class AutoFilter:
    """Auto-filter settings for a worksheet."""

    def __init__(self, worksheet: Worksheet):
        self._worksheet = worksheet
        self._ref: str | None = None

    @property
    def ref(self) -> str | None:
        """Get the auto-filter range reference."""
        return self._ref

    @ref.setter
    def ref(self, value: str | None) -> None:
        """Set the auto-filter range (e.g., 'A1:D10')."""
        self._ref = value
        if value:
            start_row, start_col, end_row, end_col = parse_range(value)
            self._worksheet._buffer.add(
                SetAutoFilter(
                    sheet_index=self._worksheet._index,
                    start_row=start_row,
                    start_col=start_col,
                    end_row=end_row,
                    end_col=end_col,
                )
            )


class PrintPageSetup:
    """Page setup for printing.

    Mirrors openpyxl.worksheet.page.PrintPageSetup.
    """

    def __init__(
        self,
        orientation: str | None = None,
        paperSize: int | None = None,
        scale: int | None = None,
        fitToPage: bool | None = None,
        fitToHeight: int | None = None,
        fitToWidth: int | None = None,
    ):
        self.orientation = orientation
        self.paperSize = paperSize
        self.scale = scale
        self.fitToPage = fitToPage
        self.fitToHeight = fitToHeight
        self.fitToWidth = fitToWidth


class PageMargins:
    """Page margins for printing.

    Mirrors openpyxl.worksheet.page.PageMargins.
    """

    def __init__(
        self,
        left: float = 0.7,
        right: float = 0.7,
        top: float = 0.75,
        bottom: float = 0.75,
        header: float = 0.3,
        footer: float = 0.3,
    ):
        self.left = left
        self.right = right
        self.top = top
        self.bottom = bottom
        self.header = header
        self.footer = footer


class PrintOptions:
    """Print options.

    Mirrors openpyxl.worksheet.worksheet.PrintOptions.
    """

    def __init__(
        self,
        horizontalCentered: bool = False,
        verticalCentered: bool = False,
        gridLines: bool = False,
        gridLinesSet: bool = True,
        headings: bool = False,
    ):
        self.horizontalCentered = horizontalCentered
        self.verticalCentered = verticalCentered
        self.gridLines = gridLines
        self.gridLinesSet = gridLinesSet
        self.headings = headings
