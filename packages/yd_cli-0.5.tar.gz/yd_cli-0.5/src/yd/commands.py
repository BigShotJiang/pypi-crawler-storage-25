# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""Commands assembly."""

from __future__ import annotations

import itertools as it
import logging
import uuid
from pathlib import Path

from yd import types

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Sequence


log = logging.getLogger(__name__)

__all__ = ["CONFIG_TEMPLATE", "create"]

# TODO: check if `--rename-speedup` in fact produces speedups worth the extra
# complexity.


def _complete_path(path: Path, *, home: Path) -> Path:
    if not home.is_absolute():
        raise ValueError(f"non-absolute home specification: `{home}`")

    if not path.is_absolute():
        path = home / path
    return path.resolve()


def _is_empty(path: Path) -> bool:
    try:
        next(path.iterdir())
    except StopIteration:
        return True
    return False


def _format_path(path: Path, /) -> str:
    return f"{path.as_posix()}/"


def _create_error_command(
    enc_msg: str, /, environment: types.Environment
) -> tuple[str, tuple[str]]:
    return environment.echo_bin, (enc_msg,)


def create(  # noqa: PLR0915
    cg: types.CommandGroup,
    /,
    *,
    env: types.Environment,
    src_home: str | None,
    target_home: str | None,
    dry_run: bool,
    keep_newer: bool,
    rename_speedup: bool,
    no_backup: bool,
    out_format: str = '{"filename": "%n", "transfer_bytes": %b, "info": "%i"}',
    error_encoder: Callable[[str], str],
) -> Iterable[tuple[str, Sequence[str]]]:
    """Build CLI commands.

    If the source directory is empty, then an `echo` command will be created. If
    the target has `delete_extra` set, then the command will also suggest to delete the
    target's contents manually.

    Parameters
    ----------
    keep_newer
        If `False`, then files in the target are overwritten even if they have a newer
        modification time. This may be necessary if there was an interruption when
        running a command with `mtp_target` set (files may not yet have their actual
        modification date set before the interruption occurred).
    out_format
        See the `log format` section on the `rsyncd.conf` man page.
    """
    # Catches empty strings provided at the command line.
    if not (src_home := cg.src_home if src_home is None else src_home):
        raise types.CommandBuildError("missing src home specification")
    if not (target_home := cg.target_home if target_home is None else target_home):
        raise types.CommandBuildError("missing target home specification")

    target_home = env.current_time.strftime(target_home)
    src_hpath, target_hpath = (
        _complete_path(Path(src_home), home=env.home_dir),
        _complete_path(Path(target_home), home=env.home_dir),
    )

    base_args = [
        "--mkpath",  # Create target directory if it does not exist.
        "--recursive",  # Recurse into directories.
        "--outbuf=L",  # Use line buffering.
        "--debug=none",  # Silence all debugging messages.
        "--compress",  # Compress during transit.
        "--links",  # Copy symlinks as symlinks.
        "--safe-links",  # Links pointing outside src will not be created in dest.
        "--hard-links",  # Keep hard links as hard links (do not copy content).
        "--one-file-system",  # Do not cross over into other filesystems (mounts!)
        "--one-file-system",  # Don't follow mount even on the same device.
        "--no-owner",  # Take ownership of the synced file (don't copy owner/group).
        "--no-group",
        "--perms",  # Retain permissions.
        "--times",  # Retains modification times (important for quick change check).
        "--atimes",  # Keep access times.
        "--open-noatime",
        "--prune-empty-dirs",  # Remove directories with no files in the target.
        "--out-format",  # Set output format to show
        out_format,
    ]
    if dry_run:
        base_args.append("--dry-run")  # Dry-run: no actions.
    if keep_newer:
        base_args.append("--update")
    if rename_speedup:
        base_args.extend(
            (
                "--fuzzy",  # Search for similar files in the target and use matches to
                "--fuzzy",  # speed up transfers (2x fuzzy = search the full transfer
                "--fuzzy",  # list).
            )
        )
    if cg.mtp_target:
        base_args.append("--inplace")

    if no_backup:
        backup_path: Path | None = None
    else:
        if (backup := cg.backup) is None:
            backup = f".{__package__}-{env.current_time:%Y-%m-%d-%H-%M}-{uuid.uuid4()}"
        else:
            backup = env.current_time.strftime(backup)
        backup_path = _complete_path(Path(backup), home=target_hpath)

    for cmd in cg.commands:
        if (src_path := Path(cmd.src)).is_absolute():
            raise types.CommandBuildError(
                f"found absolute source path `{cmd.src}` in command specification"
            )
        src = _complete_path(src_path, home=src_hpath)
        if not src.is_relative_to(src_hpath):
            raise types.CommandBuildError(
                f"source path `{src}` is outside src home `{src_hpath}`"
            )
        if not src.is_dir():
            raise types.CommandBuildError(f"source directory `{src}` not found")
        if _is_empty(src):
            # Intentionally not checking for the target as that would require quite some
            # extra checking to meaningfully cover cases like date-based targets.
            msg = f"Source directory `{src}` is empty. No synchronization will be done."
            if cmd.delete_extra:
                msg += " Delete the folder contents manually to synchronize."

            log.warning(msg)
            yield _create_error_command(error_encoder(msg), environment=env)
            continue

        target_spec = (
            cmd.src if cmd.target is None else env.current_time.strftime(cmd.target)
        )
        if (target_path := Path(target_spec)).is_absolute():
            raise types.CommandBuildError(
                f"found absolute target path `{cmd.src}` in command specification"
            )
        target = _complete_path(target_path, home=target_hpath)
        if not target.is_relative_to(target_hpath):
            raise types.CommandBuildError(
                f"target path `{target}` is outside target home `{target_hpath}`"
            )

        if src.is_relative_to(target):
            raise types.CommandBuildError(
                f"source path `{src}` is included in target `{target}`"
            )
        if target.is_relative_to(src):
            raise types.CommandBuildError(
                f"target path `{src}` is included in source `{target}`"
            )

        if backup_path is None:
            target_backup_path: Path | None = None
        else:
            target_backup_path = _complete_path(target_path, home=backup_path)
            if target_backup_path.is_relative_to(src) or src.is_relative_to(
                target_backup_path
            ):
                raise types.CommandBuildError(
                    f"source `{src}` intersects with backup path `{target_backup_path}`"
                )

        args = base_args.copy()
        if cmd.delete_extra:
            if rename_speedup:
                # Use delayed option to make fuzzy work.
                args.append("--delete-delay")
            else:
                args.append("--delete-during")

        if target_backup_path:
            # The `--backup-dir` option automatically creates the backup directory.
            # A relative path will be considered relative to the destination directory.
            args.extend(("--backup", "--backup-dir", _format_path(target_backup_path)))

        args.extend(
            f"--exclude={pattern}" for pattern in it.chain(cmd.exclude, cg.exclude)
        )

        args.append(_format_path(src))
        args.append(_format_path(target))

        yield env.rsync_bin, args


CONFIG_TEMPLATE = """\
# Comments right at the start of the file
# are considered config description.

# Root path (relative path are taken as relative to your home directory).
# May be omitted (both, one, or two), but missing values
# must then be provided via the CLI.
src_home = "/home/myuser"
target_home = "/mnt/myusbdrive"
# Set `true` when sending data to a device accessed via MTP.
mtp_target = false
# If not provided, then a new directory inside `target_home` is created.
# Date/time placeholder are evaluated based on execution time.
backup = "/tmp/%Y-%m-%d-%H-%M"
# Global exclude patterns.
exclude = [
    ".venv/",
    "__pycache__/",
]

[[commands]]
# Relative (to src_home) path. If `target` is not specified, then `src` is copied.
src = "Documents"
# Local exclude patterns; joined with global patterns.
exclude = [
    "*.log",
]

[[commands]]
src = "Pictures"
# Date/time placeholder are evaluated based on execution time.
target = "pics-%Y-%m-%d"
# If `True`, then files in `target` not contained in `src` are deleted.
delete_extra = false
"""
