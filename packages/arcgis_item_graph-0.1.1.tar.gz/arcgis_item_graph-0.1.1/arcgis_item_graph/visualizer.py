"""
ItemGraphVisualizer — interactive HTML dependency graph using Cytoscape.js + dagre.

Nodes are color-coded by ArcGIS item type. Forward dependencies (what an item
depends on) appear below the queried item; backward dependencies (what depends on
the item) appear above. Load time is O(seconds) for 500+ node graphs.
Works as a self-contained HTML file and inline in Jupyter notebooks.
"""
import json
import logging
import tempfile
from pathlib import Path
from typing import Optional, TYPE_CHECKING

import networkx as nx
from jinja2 import Environment, FileSystemLoader

if TYPE_CHECKING:
    from arcgis_item_graph.query import QueryResult

logger = logging.getLogger(__name__)

# Color map for common ArcGIS item types
_TYPE_COLORS = {
    "Web Map": "#4e9af1",
    "Feature Layer Collection": "#f1a74e",
    "Feature Service": "#f1a74e",
    "Dashboard": "#7b4ef1",
    "Form": "#4ef18a",
    "StoryMaps": "#f14e6a",
    "Web AppBuilder": "#f1e24e",
    "Microsoft Word": "#4ec9f1",
}
_DEFAULT_COLOR = "#aaaaaa"
_QUERIED_BORDER = "#ff0000"   # red border for explicitly queried nodes

# Paths resolved relative to this file
_LIB_DIR = Path(__file__).parent.parent / "lib"
_TEMPLATE_DIR = Path(__file__).parent / "templates"


class ItemGraphVisualizer:
    """
    Renders a QueryResult as an interactive self-contained HTML graph.

    Uses Cytoscape.js with dagre hierarchical layout. Forward dependencies
    (items the queried item depends on) appear below the queried node;
    backward dependencies (items that depend on the queried item) appear above.

    Args:
        result: A QueryResult produced by ItemGraphQuery.query().
    """

    def __init__(self, result: "QueryResult"):
        self.result = result

    def render(
        self,
        output_file: Optional[str] = None,
        show_inline: bool = False,
    ) -> None:
        """
        Render the dependency graph as a self-contained interactive HTML file.

        Args:
            output_file: Path to write the HTML file. Required if show_inline=False.
            show_inline: Display inline in a Jupyter notebook. A temporary file is
                         used when output_file is None.

        Raises:
            ValueError: If neither output_file is provided nor show_inline=True.
        """
        if not output_file and not show_inline:
            raise ValueError(
                "Provide output_file, set show_inline=True, or both."
            )

        graph_data = self.serialize()

        # Pick title from first queried node, fallback to generic
        title = "Dependency Graph"
        for n in graph_data["nodes"]:
            if n["queried"]:
                title = n["title"]
                break

        env = Environment(
            loader=FileSystemLoader(str(_TEMPLATE_DIR)),
            autoescape=True,
        )
        template = env.get_template("graph.html")

        html = template.render(
            title=title,
            graph_data_json=json.dumps(graph_data, separators=(",", ":")).replace("</", "<\\/"),
            cytoscape_js=(_LIB_DIR / "cytoscape.min.js").read_text(encoding="utf-8"),
            dagre_js=(_LIB_DIR / "dagre.min.js").read_text(encoding="utf-8"),
            cytoscape_dagre_js=(_LIB_DIR / "cytoscape-dagre.js").read_text(encoding="utf-8"),
        )

        if output_file:
            Path(output_file).write_text(html, encoding="utf-8")
            logger.info(f"Graph saved to: {output_file}")

        if show_inline:
            self._display_inline(output_file, html)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def serialize(self) -> dict:
        """
        Serialize QueryResult into a dict suitable for JSON injection into the
        HTML template.

        Returns a dict with keys: nodes, edges, meta.
        """
        # Build a temporary NetworkX DiGraph from the result graph's edges.
        # Edge A → B means "A contains/depends on B" (A is the consumer).
        nx_graph = nx.DiGraph()
        try:
            edge_list = list(self.result.graph.edges())
            nx_graph.add_edges_from(edge_list)
        except Exception:
            edge_list = []

        # Compute which nodes are backward deps (ancestors of queried items).
        # An "ancestor" of Q in the graph is a node P where P→…→Q exists,
        # meaning P depends on Q — i.e., P is a backward dep of Q.
        backward_nodes: set = set()
        for qid in self.result.queried_ids:
            if qid in nx_graph:
                try:
                    backward_nodes.update(nx.ancestors(nx_graph, qid))
                except Exception:
                    pass

        # Detect circular dependencies.
        cycles: list = []
        try:
            cycles = list(nx.simple_cycles(nx_graph))
        except Exception:
            pass

        # Serialize nodes.
        portal_base = (getattr(self.result, "portal_url", None) or "").rstrip("/")
        nodes = []
        for node in self.result.nodes:
            item_type = getattr(node.item, "type", None) if node.item else None
            color = _TYPE_COLORS.get(item_type, _DEFAULT_COLOR)
            title = getattr(node.item, "title", None) if node.item else None
            owner = getattr(node.item, "owner", None) if node.item else None
            label = title or node.id
            if len(label) > 45:
                label = label[:42] + "..."
            portal_url = (
                f"{portal_base}/home/item.html?id={node.id}"
                if portal_base else None
            )
            nodes.append({
                "id": node.id,
                "label": label,
                "type": item_type or "Unknown",
                "owner": owner or "",
                "title": title or node.id,
                "color": color,
                "queried": node.id in self.result.queried_ids,
                "hydrated": node.item is not None,
                "portal_url": portal_url,
                "broken_reason": getattr(node, "broken_reason", None)
                                 if isinstance(getattr(node, "broken_reason", None), (str, type(None)))
                                 else None,
                "deprecated":    bool(getattr(node, "deprecated", False)),
            })

        # Serialize edges with direction.
        # Edges from backward_nodes are "backward"; all others are "forward".
        edges = []
        for src, dst in edge_list:
            direction = "backward" if src in backward_nodes else "forward"
            edges.append({"source": src, "target": dst, "direction": direction})

        item_types = sorted({n["type"] for n in nodes if n["type"] != "Unknown"})

        return {
            "nodes": nodes,
            "edges": edges,
            "meta": {
                "queried_ids": list(self.result.queried_ids),
                "item_types": item_types,
                "cycles": cycles,
                "total_nodes": len(nodes),
                "total_edges": len(edges),
            },
        }

    def _display_inline(self, output_file: Optional[str], html: str) -> None:
        """Display the graph inline in a Jupyter notebook."""
        try:
            from IPython.display import display, IFrame
            if output_file:
                path = output_file   # already written by render()
            else:
                with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w", encoding="utf-8") as f:
                    f.write(html)
                    path = f.name
            display(IFrame(path, width="100%", height="760px"))
        except ImportError:
            logger.warning(
                "IPython not available. Cannot display inline. "
                "Use output_file instead."
            )
