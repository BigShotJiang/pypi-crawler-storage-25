"""
ItemGraphReporter — generates tabular dependency reports from a QueryResult.
"""
import logging
from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from arcgis_item_graph.query import QueryResult

logger = logging.getLogger(__name__)

# Column order for the Dependency Edges sheet
_EDGE_COLS = [
    "source_id", "source_title", "source_type", "source_owner",
    "dep_id", "dep_title", "dep_type", "dep_owner", "dep_status",
]


class ItemGraphReporter:
    """
    Generates pandas DataFrames, CSV, and Excel reports from a QueryResult.

    Args:
        result: A QueryResult produced by ItemGraphQuery.query().
    """

    def __init__(self, result: "QueryResult"):
        self.result = result

    def to_dataframe(self) -> pd.DataFrame:
        """
        Build a DataFrame summarising each item in the query result.

        Columns:
            item_id, title, type, owner, status,
            contains_count, required_by_count,
            direct_dependencies, queried_item

        ``status`` is "healthy" when portal metadata was successfully fetched
        and "broken" when the item could not be hydrated (deleted, inaccessible,
        or otherwise unresolvable).
        """
        rows = []
        for node in self.result.nodes:
            try:
                contains_ids = node.contains("id")
            except Exception as e:
                logger.warning("node.contains() raised for node %s: %s", node.id, e)
                contains_ids = []

            try:
                required_by_ids = node.required_by("id")
            except Exception as e:
                logger.warning("node.required_by() raised for node %s: %s", node.id, e)
                required_by_ids = []

            title = owner = item_type = None
            hydrated = node.item is not None
            if node.item:
                title = getattr(node.item, "title", None)
                item_type = getattr(node.item, "type", None)
                owner = getattr(node.item, "owner", None)

            rows.append({
                "item_id": node.id,
                "title": title,
                "type": item_type,
                "owner": owner,
                "status": "healthy" if hydrated else "broken",
                "contains_count": len(contains_ids),
                "required_by_count": len(required_by_ids),
                "direct_dependencies": contains_ids,
                "queried_item": node.id in self.result.queried_ids,
                "broken_reason": getattr(node, "broken_reason", None)
                                 if isinstance(getattr(node, "broken_reason", None), (str, type(None)))
                                 else None,
                "deprecated":    getattr(node, "deprecated", None)
                                 if hydrated and isinstance(getattr(node, "deprecated", None), (bool, type(None)))
                                 else None,
            })

        df = pd.DataFrame(rows)
        logger.info(f"Report built: {len(df)} rows")
        return df

    def to_csv(self, path: str) -> None:
        """
        Save the dependency report to a CSV file.

        Args:
            path: File path for the CSV output.
        """
        df = self.to_dataframe()
        df.to_csv(path, index=False)
        logger.info(f"Report saved to: {path}")

    def to_excel(self, path: str) -> None:
        """
        Save the dependency report to an Excel workbook with three sheets.

        Calls to_dataframe() once and reuses the direct_dependencies column
        to build the edge sheet — avoids calling node.contains() twice per node.

        Sheets:
            All Items          — one row per node; includes status ("healthy" /
                                 "broken"), type, owner, and dependency counts.
                                 Use as a high-level inventory for migration planning.
            Dependency Edges   — one row per source→dependency relationship with
                                 resolved titles, types, and dep_status.  Suitable
                                 for direct use in a migration script to enumerate
                                 and validate every relationship.
            Broken Dependencies — filtered subset of Dependency Edges where
                                  dep_status == "broken".  These are relationships
                                  that will break after migration if not repaired.

        dep_status values:
            healthy        — dependency was found and metadata resolved
            broken         — dependency is in the result but could not be hydrated
                             (deleted item, permission error, or malformed ID)
            not_in_result  — dependency ID is referenced by an edge but was not
                             included in the query result (outside traversal scope)

        Args:
            path: File path for the .xlsx output.
        """
        node_lookup = {n.id: n for n in self.result.nodes if n is not None}

        # ── Sheet 1: All Items ────────────────────────────────────────────────
        # to_dataframe() already computes direct_dependencies (contains_ids).
        # Reuse that column for the edge sheet to avoid a second node.contains() pass.
        df_full = self.to_dataframe()
        df_items = df_full.drop(columns=["direct_dependencies"], errors="ignore")

        # Build a fast lookup: item_id → list[dep_id] from the already-computed column
        contains_map: dict = {
            row["item_id"]: (row["direct_dependencies"] or [])
            for _, row in df_full.iterrows()
        }

        # ── Sheet 2: Dependency Edges ─────────────────────────────────────────
        edge_rows = []
        for node in self.result.nodes:
            if node is None:
                continue

            src_title = src_type = src_owner = None
            if node.item:
                src_title = getattr(node.item, "title", None)
                src_type = getattr(node.item, "type", None)
                src_owner = getattr(node.item, "owner", None)

            for dep_id in contains_map.get(node.id, []):
                dep_node = node_lookup.get(dep_id)
                dep_title = dep_type = dep_owner = None
                if dep_node and dep_node.item:
                    dep_title = getattr(dep_node.item, "title", None)
                    dep_type = getattr(dep_node.item, "type", None)
                    dep_owner = getattr(dep_node.item, "owner", None)

                if dep_node is None:
                    dep_status = "not_in_result"
                elif dep_node.item is None:
                    dep_status = "broken"
                else:
                    dep_status = "healthy"

                edge_rows.append({
                    "source_id": node.id,
                    "source_title": src_title,
                    "source_type": src_type,
                    "source_owner": src_owner,
                    "dep_id": dep_id,
                    "dep_title": dep_title,
                    "dep_type": dep_type,
                    "dep_owner": dep_owner,
                    "dep_status": dep_status,
                })

        df_edges = (
            pd.DataFrame(edge_rows)
            if edge_rows
            else pd.DataFrame(columns=_EDGE_COLS)
        )

        # ── Sheet 3: Broken Dependencies ──────────────────────────────────────
        df_broken = (
            df_edges[df_edges["dep_status"] == "broken"].copy()
            if not df_edges.empty
            else df_edges.copy()
        )

        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            df_items.to_excel(writer, sheet_name="All Items", index=False)
            df_edges.to_excel(writer, sheet_name="Dependency Edges", index=False)
            df_broken.to_excel(writer, sheet_name="Broken Dependencies", index=False)

        logger.info(f"Excel report saved to: {path}")
