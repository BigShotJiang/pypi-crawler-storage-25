# tests/test_updater.py
from unittest.mock import MagicMock, patch
from pathlib import Path
import pytest
from arcgis_item_graph.updater import ItemGraphUpdater
from tests.conftest import make_mock_node, make_mock_graph


def test_updater_raises_if_timestamp_missing(tmp_path):
    """get_last_timestamp() should raise FileNotFoundError when file absent."""
    updater = ItemGraphUpdater(
        gis=MagicMock(),
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
    )
    with pytest.raises(FileNotFoundError):
        updater.get_last_timestamp()


def test_updater_saves_and_reads_timestamp(tmp_path):
    """save_timestamp() then get_last_timestamp() should round-trip correctly."""
    ts_file = tmp_path / "ts.txt"
    updater = ItemGraphUpdater(
        gis=MagicMock(),
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(ts_file),
    )
    updater.save_timestamp(1700000000000)
    assert updater.get_last_timestamp() == 1700000000000


def test_remove_deleted_items_removes_orphan_nodes(tmp_path):
    """Nodes with no item and no contained_by relationships should be removed."""
    orphan = make_mock_node("orphan_id")
    orphan.item = None
    orphan.contained_by = MagicMock(return_value=[])
    orphan.required_by = MagicMock(return_value=[])

    keeper = make_mock_node("keeper_id")
    keeper.contained_by = MagicMock(return_value=["parent"])

    graph = make_mock_graph([orphan, keeper])
    graph.remove_node = MagicMock()

    updater = ItemGraphUpdater(
        gis=MagicMock(),
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
    )
    removed = updater.remove_deleted_items(graph)

    assert removed == 1
    graph.remove_node.assert_called_once_with("orphan_id")


def test_get_current_timestamp_has_millisecond_precision(tmp_path):
    """Verify get_current_timestamp preserves sub-second precision.

    The buggy formula: int(t) * 1000  → always ends in 000 (second-aligned)
    The correct formula: int(t * 1000) → preserves ms digits
    """
    import datetime as _dt
    from unittest.mock import patch

    updater = ItemGraphUpdater(
        gis=MagicMock(),
        gml_file=str(tmp_path / "g.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
    )

    # Mock datetime.datetime.now() to return a time with 456ms
    fixed_time = _dt.datetime(2024, 4, 5, 12, 34, 56, 456000)  # .456 seconds

    with patch("arcgis_item_graph.updater.datetime") as mock_dt:
        mock_dt.datetime.now.return_value = fixed_time
        ts = updater.get_current_timestamp()

    # With the bug:   int(1712320496) * 1000 = 1712320496000  (% 1000 == 0)
    # With the fix:   int(1712320496.456 * 1000) = 1712320496456
    assert ts % 1000 != 0, (
        f"Timestamp {ts} appears second-aligned (ends in 000); "
        "check for int(t)*1000 vs int(t*1000) bug"
    )
    assert ts == int(fixed_time.timestamp() * 1000)


def test_get_modified_items_passes_max_items_to_search(tmp_path):
    """Verify modified-items search forwards max_items to content.search()."""
    mock_gis = MagicMock()
    mock_gis.content.search.return_value = []

    updater = ItemGraphUpdater(
        gis=mock_gis,
        gml_file=str(tmp_path / "g.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
        max_items=500,
    )
    updater.get_modified_items_with_retry(old_timestamp=1000, new_timestamp=2000)

    call_kwargs = mock_gis.content.search.call_args
    assert call_kwargs.kwargs.get("max_items") == 500, (
        "content.search() must be called with max_items to prevent silent truncation"
    )


def test_get_modified_items_warns_on_possible_truncation(tmp_path, caplog):
    """Verify a warning is logged when returned items == max_items (possible truncation)."""
    import logging

    mock_gis = MagicMock()
    # Return exactly max_items items → possible truncation
    mock_gis.content.search.return_value = [MagicMock()] * 5

    updater = ItemGraphUpdater(
        gis=mock_gis,
        gml_file=str(tmp_path / "g.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
        max_items=5,
    )

    with caplog.at_level(logging.WARNING, logger="arcgis_item_graph.updater"):
        updater.get_modified_items_with_retry(old_timestamp=1000, new_timestamp=2000)

    assert any("truncat" in r.message.lower() for r in caplog.records), (
        "Expected a truncation warning when result count equals max_items"
    )


def test_hydration_uses_thread_pool(tmp_path):
    """Verify _hydrate_graph_items_with_diagnostics uses concurrent fetching."""
    mock_gis = MagicMock()
    # Return a fresh MagicMock item for any ID
    mock_gis.content.get.side_effect = lambda item_id: MagicMock(title=f"Item {item_id}")

    updater = ItemGraphUpdater(
        gis=mock_gis,
        gml_file=str(tmp_path / "g.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
        hydration_workers=4,
    )

    # 8 nodes to hydrate
    nodes = [MagicMock(id=f"node{i}", item=None) for i in range(8)]
    mock_graph = MagicMock()

    # Should not raise; all 8 content.get() calls must be made
    updater._hydrate_graph_items_with_diagnostics(mock_graph, nodes)

    assert mock_gis.content.get.call_count == 8


def test_hydrate_diagnostics_sets_broken_reason_on_error():
    """broken_reason is set on the node when gis.content.get raises."""
    import types
    from arcgis_item_graph.updater import ItemGraphUpdater

    gis = MagicMock()
    gis.content.get.side_effect = Exception("unable to find iteminfo error code: 500")

    updater = ItemGraphUpdater.__new__(ItemGraphUpdater)
    updater.gis = gis
    updater.hydration_workers = 1

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    graph = MagicMock()
    graph.remove_node = MagicMock()

    updater._hydrate_graph_items_with_diagnostics(graph, [node])

    assert node.broken_reason == "deleted"


def test_hydrate_diagnostics_sets_deprecated_on_success():
    """deprecated is set on the node when gis.content.get returns a deprecated item."""
    import types
    from arcgis_item_graph.updater import ItemGraphUpdater

    mock_item = MagicMock()
    mock_item.deprecated = True

    gis = MagicMock()
    gis.content.get.return_value = mock_item

    updater = ItemGraphUpdater.__new__(ItemGraphUpdater)
    updater.gis = gis
    updater.hydration_workers = 1

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    graph = MagicMock()

    updater._hydrate_graph_items_with_diagnostics(graph, [node])

    assert node.item is mock_item
    assert node.deprecated is True
