# tests/test_reporter.py
from unittest.mock import MagicMock
import pytest
import pandas as pd
from arcgis_item_graph.reporter import ItemGraphReporter
from arcgis_item_graph.query import QueryResult
from tests.conftest import make_mock_node, make_mock_graph, make_mock_unhydrated_node


@pytest.fixture
def simple_result():
    """QueryResult with two nodes: node_a (queried) contains node_b (dependency)."""
    node_a = make_mock_node(
        "id_a", title="My Dashboard", item_type="Dashboard",
        owner="jsmith", contains_ids=["id_b"], required_by_ids=[]
    )
    node_b = make_mock_node(
        "id_b", title="Base Map", item_type="Web Map",
        owner="esri", contains_ids=[], required_by_ids=["id_a"]
    )
    graph = make_mock_graph([node_a, node_b])
    return QueryResult(
        nodes=[node_a, node_b],
        graph=graph,
        queried_ids={"id_a"},
    )


@pytest.fixture
def empty_result():
    """QueryResult with zero nodes and zero edges."""
    return QueryResult(
        nodes=[],
        graph=make_mock_graph([]),
        queried_ids=set(),
    )


@pytest.fixture
def not_in_result_result():
    """QueryResult where node_a references id_x via contains but id_x is absent from result.nodes."""
    node_a = make_mock_node(
        "id_a", title="My Dashboard", item_type="Dashboard",
        owner="jsmith", contains_ids=["id_x"], required_by_ids=[]
    )
    graph = make_mock_graph([node_a])
    return QueryResult(
        nodes=[node_a],
        graph=graph,
        queried_ids={"id_a"},
    )


@pytest.fixture
def broken_result():
    """QueryResult where node_a contains node_b (healthy) and node_c (broken)."""
    node_a = make_mock_node(
        "id_a", title="My Dashboard", item_type="Dashboard",
        owner="jsmith", contains_ids=["id_b", "id_c"]
    )
    node_b = make_mock_node(
        "id_b", title="Base Map", item_type="Web Map",
        owner="esri", contains_ids=[]
    )
    node_c = make_mock_unhydrated_node("id_c")  # broken — could not be hydrated
    graph = make_mock_graph([node_a, node_b, node_c])
    return QueryResult(
        nodes=[node_a, node_b, node_c],
        graph=graph,
        queried_ids={"id_a"},
    )


# ── to_dataframe ─────────────────────────────────────────────────────────────

def test_to_dataframe_returns_dataframe(simple_result):
    """to_dataframe() should return a pandas DataFrame."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    assert isinstance(df, pd.DataFrame)


def test_to_dataframe_has_expected_columns(simple_result):
    """DataFrame should contain all required columns including status."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    expected_cols = {
        "item_id", "title", "type", "owner", "status",
        "contains_count", "required_by_count",
        "direct_dependencies", "queried_item",
    }
    assert expected_cols.issubset(set(df.columns))


def test_to_dataframe_queried_item_flag(simple_result):
    """queried_item column should be True only for explicitly queried items."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    assert df.loc[df["item_id"] == "id_a", "queried_item"].iloc[0] == True
    assert df.loc[df["item_id"] == "id_b", "queried_item"].iloc[0] == False


def test_to_dataframe_counts(simple_result):
    """contains_count and required_by_count should match mock node data."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    row_a = df[df["item_id"] == "id_a"].iloc[0]
    assert row_a["contains_count"] == 1
    assert row_a["required_by_count"] == 0


def test_to_dataframe_status_healthy(simple_result):
    """Hydrated nodes should have status='healthy'."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    assert (df["status"] == "healthy").all()


def test_to_dataframe_status_broken(broken_result):
    """Unhydrated nodes (item=None) should have status='broken'."""
    reporter = ItemGraphReporter(broken_result)
    df = reporter.to_dataframe()
    row_c = df[df["item_id"] == "id_c"].iloc[0]
    assert row_c["status"] == "broken"
    # Other nodes should still be healthy
    row_a = df[df["item_id"] == "id_a"].iloc[0]
    assert row_a["status"] == "healthy"


# ── to_csv ────────────────────────────────────────────────────────────────────

def test_to_csv_writes_file(simple_result, tmp_path):
    """to_csv() should write a CSV file at the given path."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.csv"
    reporter.to_csv(str(out))
    assert out.exists()
    df = pd.read_csv(str(out))
    assert len(df) == 2


# ── to_excel ─────────────────────────────────────────────────────────────────

def test_to_excel_writes_file(simple_result, tmp_path):
    """to_excel() should write an .xlsx file at the given path."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    assert out.exists()


def test_to_excel_has_three_sheets(simple_result, tmp_path):
    """to_excel() workbook should contain All Items, Dependency Edges, and Broken Dependencies sheets."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    xl = pd.ExcelFile(str(out))
    assert "All Items" in xl.sheet_names
    assert "Dependency Edges" in xl.sheet_names
    assert "Broken Dependencies" in xl.sheet_names


def test_to_excel_all_items_row_count(simple_result, tmp_path):
    """All Items sheet should have one row per node."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="All Items")
    assert len(df) == 2


def test_to_excel_dependency_edges_columns(simple_result, tmp_path):
    """Dependency Edges sheet should include source, dep, and dep_status columns."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="Dependency Edges")
    for col in ("source_id", "source_title", "dep_id", "dep_title", "dep_type", "dep_status"):
        assert col in df.columns, f"Missing column: {col}"


def test_to_excel_dependency_edge_status_healthy(simple_result, tmp_path):
    """Healthy deps (hydrated node_b) should have dep_status='healthy'."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="Dependency Edges")
    # node_a contains node_b; node_b is hydrated → healthy
    assert len(df) == 1
    assert df.iloc[0]["source_id"] == "id_a"
    assert df.iloc[0]["dep_id"] == "id_b"
    assert df.iloc[0]["dep_status"] == "healthy"


def test_to_excel_broken_dependencies_sheet(broken_result, tmp_path):
    """Broken Dependencies sheet should contain only edges where dep_status='broken'."""
    reporter = ItemGraphReporter(broken_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df_broken = pd.read_excel(str(out), sheet_name="Broken Dependencies")
    df_edges  = pd.read_excel(str(out), sheet_name="Dependency Edges")
    # Only the id_c dep is broken
    assert len(df_broken) == 1
    assert df_broken.iloc[0]["dep_id"] == "id_c"
    assert df_broken.iloc[0]["dep_status"] == "broken"
    # Edges sheet should have both id_b (healthy) and id_c (broken)
    assert len(df_edges) == 2


def test_to_excel_broken_dep_title_is_null(broken_result, tmp_path):
    """Broken dep entries should have null dep_title since item data is missing."""
    reporter = ItemGraphReporter(broken_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df_edges = pd.read_excel(str(out), sheet_name="Dependency Edges")
    broken_row = df_edges[df_edges["dep_id"] == "id_c"].iloc[0]
    assert pd.isna(broken_row["dep_title"])


def test_to_excel_all_items_no_direct_dependencies_column(simple_result, tmp_path):
    """All Items sheet should not have a direct_dependencies column (not Excel-friendly)."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="All Items")
    assert "direct_dependencies" not in df.columns


def test_to_excel_empty_result(empty_result, tmp_path):
    """to_excel() with zero nodes should write a valid file with correct edge columns and zero data rows."""
    reporter = ItemGraphReporter(empty_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    assert out.exists()
    df_items = pd.read_excel(str(out), sheet_name="All Items")
    df_edges = pd.read_excel(str(out), sheet_name="Dependency Edges")
    df_broken = pd.read_excel(str(out), sheet_name="Broken Dependencies")
    assert len(df_items) == 0
    assert len(df_edges) == 0
    assert len(df_broken) == 0
    for col in ("source_id", "dep_id", "dep_status"):
        assert col in df_edges.columns, f"Missing column in Dependency Edges: {col}"
        assert col in df_broken.columns, f"Missing column in Broken Dependencies: {col}"


def test_to_excel_dep_status_not_in_result(not_in_result_result, tmp_path):
    """A dep_id present in contains but absent from result.nodes should have dep_status='not_in_result'."""
    reporter = ItemGraphReporter(not_in_result_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="Dependency Edges")
    assert len(df) == 1
    assert df.iloc[0]["dep_id"] == "id_x"
    assert df.iloc[0]["dep_status"] == "not_in_result"


def test_to_excel_does_not_call_contains_twice(tmp_path):
    """node.contains() should be called once per node, not twice (DataFrame + edge sheet)."""
    from arcgis_item_graph.reporter import ItemGraphReporter
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node_a = make_mock_node("aaa", contains_ids=["bbb"])
    node_b = make_mock_node("bbb", contains_ids=[])
    graph = make_mock_graph([node_a, node_b])

    result = QueryResult(
        nodes=[node_a, node_b],
        graph=graph,
        queried_ids={"aaa"},
    )

    reporter = ItemGraphReporter(result)
    reporter.to_excel(str(tmp_path / "out.xlsx"))

    # Each node.contains() should be called exactly once (from to_dataframe())
    # If called twice, call_count would be 2 per node.
    assert node_a.contains.call_count == 1, (
        f"node_a.contains called {node_a.contains.call_count} times; expected 1"
    )
    assert node_b.contains.call_count == 1, (
        f"node_b.contains called {node_b.contains.call_count} times; expected 1"
    )


def test_to_dataframe_includes_broken_reason_column():
    """to_dataframe() must include a broken_reason column populated for broken nodes."""
    from arcgis_item_graph.reporter import ItemGraphReporter
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=[])
    node.item = None
    node.broken_reason = "deleted"

    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    df = ItemGraphReporter(result).to_dataframe()

    assert "broken_reason" in df.columns
    assert df.loc[df["item_id"] == "aaa", "broken_reason"].iloc[0] == "deleted"


def test_to_dataframe_includes_deprecated_column():
    """to_dataframe() must include a deprecated column populated for hydrated nodes."""
    from arcgis_item_graph.reporter import ItemGraphReporter
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph
    from unittest.mock import MagicMock

    node = make_mock_node("bbb", contains_ids=[])
    mock_item = MagicMock()
    mock_item.title = "My Layer"
    mock_item.type = "Feature Service"
    mock_item.owner = "testuser"
    node.item = mock_item
    node.deprecated = True

    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"bbb"})

    df = ItemGraphReporter(result).to_dataframe()

    assert "deprecated" in df.columns
    assert df.loc[df["item_id"] == "bbb", "deprecated"].iloc[0] == True
