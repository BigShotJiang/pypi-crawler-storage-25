# tests/test_utils.py
"""Tests for arcgis_item_graph/utils.py — categorize_hydration_error."""
import pytest
from arcgis_item_graph.utils import categorize_hydration_error


class TestCategorizeHydrationError:
    """categorize_hydration_error() must map error strings to correct categories."""

    # ── malformed_url ──────────────────────────────────────────────────────

    def test_http_url_rest_services(self):
        """/rest/services/ URLs are malformed item IDs."""
        assert categorize_hydration_error(
            "some error", "https://example.com/arcgis/rest/services/MyService/MapServer"
        ) == "malformed_url"

    def test_no_connection_adapters(self):
        """'no connection adapters' signals a URL used as an item ID."""
        assert categorize_hydration_error("No connection adapters were found", "abc123") == "malformed_url"

    # ── deleted (ArcGIS-specific item-not-found) ───────────────────────────

    def test_unable_to_find_iteminfo(self):
        """ArcGIS 'unable to find iteminfo' message → deleted."""
        assert categorize_hydration_error("Unable to find iteminfo for abc123", "abc123") == "deleted"

    def test_unable_to_find_iteminfo_with_500(self):
        """ArcGIS-specific message takes precedence over generic 500."""
        assert categorize_hydration_error(
            "Unable to find iteminfo. Error code: 500", "abc123"
        ) == "deleted"

    # ── not_found (HTTP 404) ───────────────────────────────────────────────

    def test_error_code_404(self):
        """HTTP 404 from portal → not_found (item genuinely missing)."""
        assert categorize_hydration_error("Error code: 404", "abc123") == "not_found"

    def test_404_not_found_string(self):
        """'404 not found' string → not_found."""
        assert categorize_hydration_error("404 not found", "abc123") == "not_found"

    # ── degraded (HTTP 500 server error, NOT item-missing) ────────────────

    def test_error_code_500_alone_is_degraded_not_deleted(self):
        """Generic HTTP 500 without ArcGIS iteminfo message → degraded, not deleted."""
        assert categorize_hydration_error("Error code: 500", "abc123") == "degraded"

    def test_server_error_500_message(self):
        """ArcGIS Server 'Unable to complete operation. (Error code: 500)' → degraded."""
        assert categorize_hydration_error(
            "Unable to complete operation. (Error code: 500)", "abc123"
        ) == "degraded"

    # ── network ───────────────────────────────────────────────────────────

    def test_timeout(self):
        assert categorize_hydration_error("Read timeout occurred", "abc123") == "network"

    def test_connection_error(self):
        assert categorize_hydration_error("Connection reset by peer", "abc123") == "network"

    def test_socket_error(self):
        assert categorize_hydration_error("socket.timeout: timed out", "abc123") == "network"

    # ── permission ────────────────────────────────────────────────────────

    def test_403_forbidden(self):
        assert categorize_hydration_error("403 Forbidden", "abc123") == "permission"

    def test_unauthorized(self):
        assert categorize_hydration_error("Unauthorized access", "abc123") == "permission"

    def test_permission_keyword(self):
        assert categorize_hydration_error("User does not have permission", "abc123") == "permission"

    # ── unknown ───────────────────────────────────────────────────────────

    def test_unrecognised_error(self):
        assert categorize_hydration_error("Something completely unexpected", "abc123") == "unknown"
