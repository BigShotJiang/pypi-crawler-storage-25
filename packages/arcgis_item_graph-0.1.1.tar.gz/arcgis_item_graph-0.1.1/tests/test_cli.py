"""tests/test_cli.py — Unit tests for the CLI entry point."""
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch, mock_open

import pytest
import yaml

from tests.conftest import make_config


# ── load_config ───────────────────────────────────────────────────────────────

class TestLoadConfig:
    def test_returns_dict_for_valid_yaml(self, tmp_path):
        from cli.main import load_config
        cfg_file = tmp_path / "config.yaml"
        cfg_file.write_text("auth:\n  profile: test\n")
        result = load_config(cfg_file)
        assert result == {"auth": {"profile": "test"}}

    def test_exits_with_message_when_file_missing(self, tmp_path, capsys):
        from cli.main import load_config
        with pytest.raises(SystemExit) as exc:
            load_config(tmp_path / "nonexistent.yaml")
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "config.example.yaml" in captured.out

    def test_exits_when_yaml_is_not_a_mapping(self, tmp_path, capsys):
        from cli.main import load_config
        cfg_file = tmp_path / "config.yaml"
        cfg_file.write_text("- item1\n- item2\n")
        with pytest.raises(SystemExit) as exc:
            load_config(cfg_file)
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "list" in captured.out

    def test_default_config_is_relative_string(self):
        """DEFAULT_CONFIG must be a plain relative path, not tied to the package location."""
        from cli.main import DEFAULT_CONFIG
        from pathlib import Path
        # Must be relative so it resolves to the user's CWD, not site-packages
        assert not Path(DEFAULT_CONFIG).is_absolute(), (
            f"DEFAULT_CONFIG must be relative, got: {DEFAULT_CONFIG}"
        )
        assert str(DEFAULT_CONFIG) == "config/config.yaml"


# ── validate_config ───────────────────────────────────────────────────────────

class TestValidateConfig:
    def test_passes_for_valid_config(self):
        from cli.main import validate_config
        config = make_config()
        validate_config(config, Path("config/config.yaml"))  # must not raise or exit

    def test_exits_when_required_section_missing(self, capsys):
        from cli.main import validate_config
        config = make_config()
        del config["paths"]
        with pytest.raises(SystemExit) as exc:
            validate_config(config, Path("config/config.yaml"))
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "paths" in captured.out

    def test_exits_when_required_sub_key_missing(self, capsys):
        from cli.main import validate_config
        config = make_config()
        del config["paths"]["gml_file"]
        with pytest.raises(SystemExit) as exc:
            validate_config(config, Path("config/config.yaml"))
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "paths.gml_file" in captured.out

    def test_exits_when_section_value_is_null(self, capsys):
        from cli.main import validate_config
        config = make_config()
        config["paths"] = None  # bare `paths:` in YAML produces None
        with pytest.raises(SystemExit) as exc:
            validate_config(config, Path("config/config.yaml"))
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "paths." in captured.out  # e.g. "paths.gml_file"

    def test_exits_when_output_formats_is_scalar(self, capsys):
        from cli.main import validate_config
        config = make_config()
        config["query"]["output_formats"] = "csv"  # scalar, not YAML list
        with pytest.raises(SystemExit) as exc:
            validate_config(config, Path("config/config.yaml"))
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "output_formats" in captured.out


# ── resolve_gis ───────────────────────────────────────────────────────────────

class TestResolveGis:
    def test_uses_profile_when_set(self):
        from cli.main import resolve_gis
        args = MagicMock(profile="psa_profile", url=None, user=None, password=None)
        config = make_config(**{"auth": {"profile": "psa_profile", "verify_cert": False}})
        with patch("cli.main.GIS") as mock_gis:
            resolve_gis(config, args)
            mock_gis.assert_called_once_with(profile="psa_profile", verify_cert=False)

    def test_uses_env_vars_when_no_profile(self, monkeypatch):
        from cli.main import resolve_gis
        monkeypatch.setenv("ARCGIS_URL", "https://test.arcgis.com")
        monkeypatch.setenv("ARCGIS_USER", "admin")
        monkeypatch.setenv("ARCGIS_PASSWORD", "secret")
        args = MagicMock(profile=None, url=None, user=None, password=None)
        config = make_config(**{"auth": {"profile": "", "verify_cert": False}})
        with patch("cli.main.GIS") as mock_gis:
            resolve_gis(config, args)
            mock_gis.assert_called_once_with(
                url="https://test.arcgis.com",
                username="admin",
                password="secret",
                verify_cert=False,
            )

    def test_cli_flags_override_config_profile(self):
        from cli.main import resolve_gis
        args = MagicMock(profile="override_profile", url=None, user=None, password=None)
        config = make_config(**{"auth": {"profile": "config_profile", "verify_cert": False}})
        with patch("cli.main.GIS") as mock_gis:
            resolve_gis(config, args)
            mock_gis.assert_called_once_with(profile="override_profile", verify_cert=False)

    def test_exits_with_message_when_no_auth(self, monkeypatch, capsys):
        from cli.main import resolve_gis
        monkeypatch.delenv("ARCGIS_URL", raising=False)
        monkeypatch.delenv("ARCGIS_USER", raising=False)
        monkeypatch.delenv("ARCGIS_PASSWORD", raising=False)
        args = MagicMock(profile=None, url=None, user=None, password=None)
        config = make_config(**{"auth": {"profile": "", "verify_cert": False}})
        with pytest.raises(SystemExit) as exc:
            resolve_gis(config, args)
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "ARCGIS_URL" in captured.out

    def test_prints_warning_when_password_flag_used(self, caplog):
        import logging
        from cli.main import resolve_gis
        args = MagicMock(
            profile=None, url="https://test.arcgis.com",
            user="admin", password="secret123"
        )
        config = make_config(**{"auth": {"profile": "", "verify_cert": False}})
        with patch("cli.main.GIS"), caplog.at_level(logging.WARNING):
            resolve_gis(config, args)
        assert "shell history" in caplog.text


# ── cmd_create ────────────────────────────────────────────────────────────────

class TestCmdCreate:
    def test_calls_creator_with_config_values(self, tmp_path):
        from cli.main import cmd_create
        args = MagicMock(
            profile="prof", url=None, user=None, password=None,
            gml_file=None, timestamp_file=None, max_items=None,
        )
        config = make_config()
        config["paths"]["gml_file"] = str(tmp_path / "graph.gml")
        config["paths"]["timestamp_file"] = str(tmp_path / "graph.timestamp")

        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"
        gml_file = tmp_path / "graph.gml"
        gml_file.touch()  # simulate creator writing the file so archive copy succeeds
        mock_result = {"success": True, "items_indexed": 42, "gml_file": str(gml_file)}

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphCreator") as MockCreator:
            MockCreator.return_value.create.return_value = mock_result
            cmd_create(args, config)
            MockCreator.assert_called_once()
            MockCreator.return_value.create.assert_called_once()

    def test_exits_on_creator_failure(self, tmp_path, capsys):
        from cli.main import cmd_create
        args = MagicMock(
            profile="prof", url=None, user=None, password=None,
            gml_file=None, timestamp_file=None, max_items=None,
        )
        config = make_config()
        config["paths"]["gml_file"] = str(tmp_path / "graph.gml")
        config["paths"]["timestamp_file"] = str(tmp_path / "graph.timestamp")

        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphCreator") as MockCreator:
            MockCreator.return_value.create.return_value = {"success": False, "error": "timeout"}
            with pytest.raises(SystemExit) as exc:
                cmd_create(args, config)
            assert exc.value.code == 1


# ── cmd_update ────────────────────────────────────────────────────────────────

class TestCmdUpdate:
    def test_calls_updater_with_config_values(self, tmp_path):
        from cli.main import cmd_update
        gml = tmp_path / "graph.gml"
        gml.write_text("")  # file must exist for updater
        args = MagicMock(
            profile="prof", url=None, user=None, password=None,
            gml_file=str(gml), timestamp_file=None,
            max_retries=None, retry_delay=None,
        )
        config = make_config()
        config["paths"]["timestamp_file"] = str(tmp_path / "ts.txt")

        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphUpdater") as MockUpdater:
            MockUpdater.return_value.update.return_value = {"duration": 1.5}
            cmd_update(args, config)
            MockUpdater.assert_called_once()
            MockUpdater.return_value.update.assert_called_once()

    def test_helpful_message_when_no_gml(self, tmp_path, capsys):
        from cli.main import cmd_update
        args = MagicMock(
            profile="prof", url=None, user=None, password=None,
            gml_file=str(tmp_path / "missing.gml"),
            timestamp_file=None, max_retries=None, retry_delay=None,
        )
        config = make_config()
        config["paths"]["timestamp_file"] = str(tmp_path / "ts.txt")
        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphUpdater") as MockUpdater:
            MockUpdater.return_value.update.side_effect = FileNotFoundError
            with pytest.raises(SystemExit) as exc:
                cmd_update(args, config)
            assert exc.value.code == 1
            captured = capsys.readouterr()
            assert "create" in captured.out.lower()


# ── cmd_query ─────────────────────────────────────────────────────────────────

class TestCmdQuery:
    def _base_args(self, **kw):
        defaults = dict(
            profile="prof", url=None, user=None, password=None,
            gml_file=None, output_dir=None, format=None,
            item_id=None, search=None,
            serve=False, port=8765,
        )
        defaults.update(kw)
        return MagicMock(**defaults)

    def test_query_by_item_id(self, tmp_path):
        from cli.main import cmd_query
        args = self._base_args(item_id="abc123")
        config = make_config()
        config["paths"]["output_dir"] = str(tmp_path)
        config["paths"]["gml_file"] = "outputs/graph.gml"

        import pandas as pd
        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"
        mock_result = MagicMock()
        mock_result.nodes = ["n1", "n2"]
        mock_result.to_dataframe.return_value = pd.DataFrame([{
            "item_id": "abc123",
            "title": "Test Item",
            "type": "Web Map",
            "owner": "admin",
            "contains_count": 2,
            "required_by_count": 1,
            "queried_item": True,
        }])

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphQuery") as MockQuery:
            MockQuery.return_value.query.return_value = mock_result
            cmd_query(args, config)
            MockQuery.return_value.query.assert_called_once_with(ids=["abc123"])

    def test_query_by_search(self, tmp_path):
        from cli.main import cmd_query
        args = self._base_args(search="owner:jsmith type:Dashboard")
        config = make_config()
        config["paths"]["output_dir"] = str(tmp_path)

        import pandas as pd
        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"
        mock_result = MagicMock()
        mock_result.nodes = ["n1"]
        mock_result.to_dataframe.return_value = pd.DataFrame([{
            "item_id": "xyz789",
            "title": "Dashboard",
            "type": "Dashboard",
            "owner": "jsmith",
            "contains_count": 3,
            "required_by_count": 0,
            "queried_item": True,
        }])

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphQuery") as MockQuery:
            MockQuery.return_value.query.return_value = mock_result
            cmd_query(args, config)
            MockQuery.return_value.query.assert_called_once_with(
                search="owner:jsmith type:Dashboard"
            )

    def test_exits_when_no_item_id_or_search(self, capsys):
        from cli.main import cmd_query
        args = self._base_args()  # no item_id, no search
        config = make_config()
        mock_gis = MagicMock()
        with patch("cli.main.resolve_gis", return_value=mock_gis):
            with pytest.raises(SystemExit) as exc:
                cmd_query(args, config)
            assert exc.value.code == 1

    def test_query_excel_format(self, tmp_path):
        from cli.main import cmd_query
        args = self._base_args(item_id="abc123")
        config = make_config()
        config["paths"]["output_dir"] = str(tmp_path)
        config["query"]["output_formats"] = ["excel"]

        import pandas as pd
        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"
        mock_result = MagicMock()
        mock_result.nodes = ["n1"]
        mock_result.to_dataframe.return_value = pd.DataFrame([{
            "item_id": "abc123", "title": "Item", "type": "Web Map",
            "owner": "admin", "status": "healthy",
            "contains_count": 0, "required_by_count": 0, "queried_item": True,
        }])

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphQuery") as MockQuery, \
             patch("arcgis_item_graph.reporter.ItemGraphReporter") as MockReporter:
            MockQuery.return_value.query.return_value = mock_result
            cmd_query(args, config)
            MockReporter.assert_called_once_with(mock_result)
            xlsx_path = MockReporter.return_value.to_excel.call_args[0][0]
            assert xlsx_path.endswith(".xlsx")

    def test_exits_when_both_item_id_and_search_provided(self, capsys):
        from cli.main import build_parser
        parser = build_parser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["query", "--item-id", "abc123", "--search", "owner:jsmith"])
        assert exc.value.code == 2   # argparse exits with 2 for usage errors
        captured = capsys.readouterr()
        assert "--item-id" in captured.err or "--search" in captured.err

    def test_query_serve_flag_parsed(self):
        """--serve and --port must appear in the parsed namespace."""
        from cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args([
            "query", "--item-id", "abc123", "--serve", "--port", "9000"
        ])
        assert args.serve is True
        assert args.port == 9000

    def test_query_serve_defaults_false(self):
        """--serve must default to False when not supplied."""
        from cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args(["query", "--item-id", "abc123"])
        assert args.serve is False
        assert args.port == 8765


# ── cmd_setup ─────────────────────────────────────────────────────────────────

class TestCmdSetup:
    """Tests for the interactive config-creation wizard."""

    def _run_setup(self, monkeypatch, tmp_path, inputs, getpass_return="secret"):
        """Helper: cd to tmp_path, mock input/getpass, run cmd_setup."""
        import argparse
        from cli.main import DEFAULT_CONFIG, cmd_setup
        monkeypatch.chdir(tmp_path)
        input_iter = iter(inputs)
        monkeypatch.setattr("builtins.input", lambda _prompt: next(input_iter))
        monkeypatch.setattr("getpass.getpass", lambda _prompt: getpass_return)
        args = argparse.Namespace(config=str(DEFAULT_CONFIG))
        cmd_setup(args)

    def test_creates_config_with_named_profile(self, monkeypatch, tmp_path):
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "https://myorg.maps.arcgis.com",  # portal URL
            "1",                               # auth: named profile
            "my_profile",                      # profile name
            "",                                # verify_cert (default Y)
            "",                                # output_dir (default outputs)
        ])
        config_path = tmp_path / "config" / "config.yaml"
        assert config_path.exists()
        cfg = yaml.safe_load(config_path.read_text())
        assert cfg["auth"]["profile"] == "my_profile"
        assert cfg["auth"]["verify_cert"] is True
        assert cfg["paths"]["output_dir"] == "outputs"
        assert not (tmp_path / ".env").exists()

    def test_creates_env_file_for_username_password(self, monkeypatch, tmp_path):
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "https://myorg.maps.arcgis.com",  # portal URL
            "2",                               # auth: username/password
            "admin",                           # username
            "",                                # verify_cert
            "",                                # output_dir
        ], getpass_return="p@ssw0rd")
        env_content = (tmp_path / ".env").read_text()
        assert "ARCGIS_URL=https://myorg.maps.arcgis.com" in env_content
        assert "ARCGIS_USER=admin" in env_content
        assert "ARCGIS_PASSWORD=p@ssw0rd" in env_content
        cfg = yaml.safe_load((tmp_path / "config" / "config.yaml").read_text())
        assert cfg["auth"]["profile"] == ""

    def test_aborts_when_user_declines_overwrite(self, monkeypatch, tmp_path, capsys):
        (tmp_path / "config").mkdir()
        config_path = tmp_path / "config" / "config.yaml"
        config_path.write_text("original: true\n")
        import argparse
        from cli.main import cmd_setup
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("builtins.input", lambda _: "n")
        cmd_setup(argparse.Namespace(config=str(config_path)))
        assert config_path.read_text() == "original: true\n"
        assert "cancelled" in capsys.readouterr().out.lower()

    def test_overwrites_config_when_confirmed(self, monkeypatch, tmp_path):
        (tmp_path / "config").mkdir()
        config_path = tmp_path / "config" / "config.yaml"
        config_path.write_text("original: true\n")
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "y",                               # confirm overwrite
            "https://myorg.maps.arcgis.com",
            "1",
            "new_profile",
            "",
            "",
        ])
        cfg = yaml.safe_load(config_path.read_text())
        assert cfg["auth"]["profile"] == "new_profile"

    def test_uses_defaults_on_blank_input(self, monkeypatch, tmp_path):
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "",   # portal URL → default https://www.arcgis.com
            "1",  # auth: named profile
            "p",  # profile name
            "",   # verify_cert → default Y → True
            "",   # output_dir → default outputs
        ])
        cfg = yaml.safe_load((tmp_path / "config" / "config.yaml").read_text())
        assert cfg["paths"]["gml_file"] == "outputs/graph.gml"
        assert cfg["auth"]["verify_cert"] is True
        assert cfg["paths"]["output_dir"] == "outputs"

    def test_config_passes_validate_config(self, monkeypatch, tmp_path):
        """Config written by setup wizard must pass validate_config without exits."""
        from cli.main import validate_config
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "https://myorg.maps.arcgis.com",
            "1",
            "some_profile",
            "",
            "",
        ])
        cfg = yaml.safe_load((tmp_path / "config" / "config.yaml").read_text())
        # Should not raise SystemExit
        validate_config(cfg, tmp_path / "config" / "config.yaml")


# ── setup subcommand wiring ────────────────────────────────────────────────────

class TestSetupSubcommand:
    def test_setup_registered_in_parser(self):
        from cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args(["setup"])
        assert args.command == "setup"

    def test_setup_has_no_required_flags(self):
        """setup must parse successfully with no flags beyond the subcommand name."""
        from cli.main import build_parser
        parser = build_parser()
        # Should not raise
        args = parser.parse_args(["setup"])
        assert args.command == "setup"

    def test_main_calls_cmd_setup_without_loading_config(self, monkeypatch, tmp_path):
        """main() must call cmd_setup and return before load_config when command=setup."""
        from cli import main as cli_main
        monkeypatch.setattr("sys.argv", ["arcgis-graph", "setup"])
        setup_called = []
        monkeypatch.setattr(cli_main, "cmd_setup", lambda args: setup_called.append(True))
        monkeypatch.setattr(cli_main, "load_config", lambda p: (_ for _ in ()).throw(
            AssertionError("load_config must not be called during setup")
        ))
        cli_main.main()
        assert setup_called == [True]
