# ArcGIS Item Dependency Management

## Overview

This tool builds and maintains an organization-wide ArcGIS item dependency graph, showing what Web Maps, Dashboards, Feature Services, and other items depend on each other. You can query the graph by item ID or portal search string and receive CSV, Excel, interactive HTML, and GML outputs — making it safe to audit, migrate, and clean up portal content without breaking downstream items.

---

## Quick Start

### 1. Install

**Standard Python / Mac / Linux:**

```bash
pip install arcgis-item-graph
```

**ArcGIS Pro (Windows) — uses Pro's bundled Python:**

```bat
"%PROGRAMFILES%\ArcGIS\Pro\bin\Python\Scripts\pip.exe" install arcgis-item-graph
```

**Windows one-click installer:** Download `install.bat` from the [Releases page](https://github.com/your-org/ArcGIS-Item-Dependency-Management/releases) and double-click it.

### 2. Configure

```bash
arcgis-graph setup
```

The wizard prompts for your portal URL, authentication method (named profile or username/password), and output preferences. Your credentials are never stored in `config.yaml` — they go to a gitignored `.env` file.

### 3. Build the graph (run once)

```bash
arcgis-graph create
```

This crawls your portal and saves a dependency graph locally. For large organizations (5,000+ items) it can take 30–90 minutes.

### 4. Query

```bash
arcgis-graph query --item-id abc123
arcgis-graph query --search "owner:jsmith type:Dashboard"
```

---

## Prerequisites

- Python 3.9 or later
- ArcGIS API for Python 2.4.0 or later (`arcgis>=2.4.0`)

---

## Setup

See [Quick Start](#quick-start) above for installation and configuration.

For development setup, see [For Contributors](#for-contributors) below.

---

## Configuration

`config/config.yaml` controls authentication and all run-time settings. Two auth options are available:

### Option 1 — Named ArcGIS profile (recommended for GIS admins)

Set the `auth.profile` key to the name of a saved ArcGIS credential profile:

```yaml
auth:
  profile: "my_portal_profile"   # created via arcgis.gis.GIS(profile=...)
  verify_cert: true
```

Run `python -c "from arcgis.gis import GIS; GIS(profile='my_portal_profile')"` to verify the profile name is correct.

### Option 2 — Environment variables

Leave `auth.profile` blank and create a `.env` file in the project root:

```
ARCGIS_URL=https://your-portal/portal
ARCGIS_USER=your_username
ARCGIS_PASSWORD=your_password
```

The CLI loads `.env` automatically when a profile is not set.

### Other settings

| Key | Default | Description |
|-----|---------|-------------|
| `paths.output_dir` | `outputs/` | Where all output files are written |
| `paths.gml_file` | `outputs/graph.gml` | Persistent graph file |
| `create.max_items` | `10000` | Upper limit on items indexed |
| `update.max_retries` | `5` | Retries on transient API errors |
| `query.output_formats` | `excel, html, gml` | Default outputs for each query (`excel`, `csv`, `html`, `gml`) |

---

## Usage

All commands are run via the unified CLI entry point:

```bash
python -m cli [--config /path/to/config.yaml] {create,update,query} [options]
```

### Build the graph (run once)

Crawls the entire portal and saves a GML snapshot. For large organizations (5,000+ items) this can take 30–90 minutes.

```bash
python -m cli create
```

### Keep the graph current (run on a schedule)

Finds items modified since the last run and merges changes into the existing GML. Designed for a daily cron job.

```bash
python -m cli update
```

### Query the graph

```bash
# Query by item ID
python -m cli query --item-id abc123

# Query by portal search string
python -m cli query --search "owner:jsmith type:Dashboard"

# Request specific output formats for a single run
python -m cli query --item-id abc123 --format excel
python -m cli query --item-id abc123 --format csv --format html

# Use a different config file
python -m cli --config /path/to/other/config.yaml query --item-id abc123
```

Run `python -m cli --help` or `python -m cli <command> --help` for the full list of options and overrides.

---

## Output files

All output files land in the directory set by `paths.output_dir` (default: `outputs/`).

| Command | Output files |
|---------|-------------|
| `create` | `graph.gml`, `graph.timestamp` |
| `update` | Updates `graph.gml` in place |
| `query` | `dependency_report_<timestamp>.csv` — tabular summary; `dependency_report_<timestamp>.xlsx` — 3-sheet Excel workbook (All Items, Dependency Edges, Broken Dependencies); `dependency_graph_<timestamp>.html` — interactive visualization; `query_subgraph_<timestamp>.gml` — sub-graph for further analysis |

---

## Project structure

```
arcgis_item_graph/   Core library: creator, updater, query, reporter, visualizer, utils
cli/                 Unified CLI entry point (python -m cli ...)
config/              config.example.yaml template — copy to config.yaml and fill in credentials
docs/                Documentation and design plans
lib/                 Vendored frontend assets (cytoscape.js, dagre, cytoscape-dagre) for offline HTML output
outputs/             Generated output files (gitignored)
tests/               Unit and integration tests (pytest)
```

---

## For Contributors

**1. Clone the repository**

```bash
git clone https://github.com/your-org/ArcGIS-Item-Dependency-Management.git
cd ArcGIS-Item-Dependency-Management
```

**2. Install in editable mode with dev dependencies**

```bash
pip install -e ".[dev]"
```

**3. Activate the commit-message hook**

```bash
git config core.hooksPath .githooks
```

**4. Create your configuration file**

```bash
cp config/config.example.yaml config/config.yaml
# or just run: arcgis-graph setup
```

---

## Running tests

```bash
pytest tests/ -v
```

---

## Performance & Architecture Notes

### Graph Traversal
The query BFS uses `collections.deque` for O(1) popleft (O(V+E) total).
Seed items not found in the cached GML file are fetched live in parallel via
`ThreadPoolExecutor` (default 10 workers, configurable via `fetch_workers`
on `ItemGraphQuery`).

### Update Hydration
`ItemGraphUpdater` hydrates all cached graph nodes concurrently using
`ThreadPoolExecutor` (default 10 workers, configurable via `hydration_workers`).
Graph mutations (node removal) happen serially on the main thread after all
fetches complete. The modified-items search enforces a `max_items` cap (defaults
to `create.max_items` from config) and warns when results may be truncated.

### Timestamps
All timestamps are stored in milliseconds with sub-second precision
(`int(t.timestamp() * 1000)`).

### Excel Reports
`ItemGraphReporter.to_excel()` builds all three sheets from a single pass
through `to_dataframe()` — `node.contains()` is called once per node.
