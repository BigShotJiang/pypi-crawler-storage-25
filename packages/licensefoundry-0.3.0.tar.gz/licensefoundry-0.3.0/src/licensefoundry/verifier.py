"""Offline credential verification using cached JWKS + Status List 2021.

Per ``/docs/credential-format.md`` §7, verification involves: parsing the
compact JWS, resolving the issuer's ``did:web`` DID to its JWKS, verifying
the EdDSA signature, checking temporal validity + ``@context``, and
checking the Status List bit for revocation.

Per ``/docs/billing-model.md`` §2, **offline verification is FREE** — no
metering event. If a customer prefers online verification, call the
issuer's ``/v1/credentials/verify`` endpoint directly.

The verifier is intentionally dependency-light: it uses ``cryptography``
for Ed25519 verification (already a peer dep of most Python services
working with VCs) and ``httpx`` for fetches. No JWT library is pulled in
since the JWT format is trivial to parse and we already have the crypto.
"""

from __future__ import annotations

import base64
import gzip
import json
from datetime import UTC, datetime
from typing import Any

import httpx
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from licensefoundry.errors import (
    MalformedCredentialError,
    NetworkError,
    VerificationError,
)
from licensefoundry.types import (
    CredentialStatusEntry,
    CredentialSubject,
    JwtVcInner,
    JwtVcPayload,
    VerificationResult,
    credential_subject_from_dict,
)

DEFAULT_CACHE_TTL_SECONDS = 24 * 60 * 60
DEFAULT_STATUS_LIST_CACHE_TTL_SECONDS = 5 * 60
DEFAULT_CONTEXT_URL = "https://licensefoundry.com/contexts/license/v1"


class Verifier:
    """Offline verifier for licensefoundry-issued JWT-VCs."""

    def __init__(
        self,
        *,
        accepted_issuers: list[str],
        accepted_context_urls: list[str] | None = None,
        cache_ttl_seconds: int = DEFAULT_CACHE_TTL_SECONDS,
        status_list_cache_ttl_seconds: int = DEFAULT_STATUS_LIST_CACHE_TTL_SECONDS,
        clock_skew_seconds: int = 60,
        http_client: httpx.Client | None = None,
    ) -> None:
        if not accepted_issuers:
            raise ValueError(
                "Verifier requires at least one accepted issuer DID. Production "
                "verifiers MUST reject sandbox credentials by listing only "
                "production DIDs here."
            )
        self._accepted_issuers = set(accepted_issuers)
        self._accepted_context_urls = set(accepted_context_urls or [DEFAULT_CONTEXT_URL])
        self._cache_ttl = cache_ttl_seconds
        self._status_list_cache_ttl = status_list_cache_ttl_seconds
        self._clock_skew = clock_skew_seconds
        self._http = http_client or httpx.Client(timeout=30.0)
        self._owns_http = http_client is None
        self._jwks_cache: dict[str, tuple[list[dict[str, Any]], float]] = {}
        self._sl_cache: dict[str, tuple[bytes, float]] = {}

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    def __enter__(self) -> "Verifier":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def clear_cache(self) -> None:
        """Drop all cached JWKS and Status List bitstrings."""
        self._jwks_cache.clear()
        self._sl_cache.clear()

    def verify(self, credential_jwt: str) -> VerificationResult:
        """Verify a credential JWT. Returns a structured result rather than
        raising on invalid credentials — invalidity is information, not an
        exception. Raises only on caller error (totally malformed input).
        """
        errors: list[str] = []

        try:
            header, payload_dict, signing_input, signature = _decode_jwt(credential_jwt)
        except MalformedCredentialError as e:
            return VerificationResult(valid=False, claims=None, errors=[f"malformed_jwt: {e}"])

        # Parse the payload into a typed object (best-effort — used for the
        # `claims` field even when verification fails).
        try:
            claims = _parse_payload(payload_dict)
        except Exception as e:
            return VerificationResult(
                valid=False,
                claims=None,
                errors=[f"bad_payload: {e}"],
            )

        # Header sanity
        if header.get("alg") != "EdDSA":
            errors.append(f"bad_header: alg must be 'EdDSA', got {header.get('alg')!r}")
        if header.get("typ") != "vc+jwt":
            errors.append(f"bad_header: typ must be 'vc+jwt', got {header.get('typ')!r}")
        kid = header.get("kid")
        if not isinstance(kid, str):
            errors.append("bad_header: kid header is required")
            kid = None

        # Issuer accepted?
        if claims.iss not in self._accepted_issuers:
            errors.append(
                f"issuer_mismatch: {claims.iss} not in accepted issuers"
                f" [{', '.join(sorted(self._accepted_issuers))}]"
            )

        # @context accepted?
        contexts = list(claims.vc.context)
        if not any(c in self._accepted_context_urls for c in contexts):
            errors.append(
                f"bad_context: no recognized @context URL in [{', '.join(contexts)}]"
            )

        # Signature
        if kid and claims.iss in self._accepted_issuers:
            try:
                jwks = self._resolve_jwks(claims.iss)
                jwk = _find_key_by_kid(jwks, kid)
                if jwk is None:
                    errors.append(f"kid_not_found: {kid}")
                else:
                    if not _ed25519_verify(jwk, signing_input, signature):
                        errors.append("bad_signature")
            except NetworkError as e:
                errors.append(f"jwks_fetch_failed: {e}")

        # Temporal
        now = int(datetime.now(UTC).timestamp())
        if claims.nbf is not None and claims.nbf - self._clock_skew > now:
            errors.append("not_yet_valid")
        if claims.exp is not None and claims.exp + self._clock_skew < now:
            errors.append("expired")

        # Revocation (skip if other errors — saves a network call)
        if not errors and claims.vc.credential_status is not None:
            reason = self._check_revocation(claims.vc.credential_status)
            if reason:
                errors.append(reason)

        return VerificationResult(valid=not errors, claims=claims, errors=errors)

    def verify_or_raise(self, credential_jwt: str) -> JwtVcPayload:
        """Like :meth:`verify` but raises :class:`VerificationError` on failure."""
        result = self.verify(credential_jwt)
        if not result.valid or result.claims is None:
            raise VerificationError(result.errors)
        return result.claims

    # ─── internals ──────────────────────────────────────────────────────────

    def _resolve_jwks(self, issuer_did: str) -> list[dict[str, Any]]:
        cached = self._jwks_cache.get(issuer_did)
        now = datetime.now(UTC).timestamp()
        if cached is not None and cached[1] > now:
            return cached[0]

        domain = _did_web_domain(issuer_did)
        if domain is None:
            raise MalformedCredentialError(
                f"cannot derive https domain from issuer {issuer_did}"
            )
        url = f"https://{domain}/.well-known/jwks.json"
        try:
            response = self._http.get(url)
        except httpx.RequestError as e:
            raise NetworkError(f"failed to fetch {url}: {e}", cause=e) from e
        if response.status_code != 200:
            raise NetworkError(f"JWKS fetch returned {response.status_code} from {url}")
        data = response.json()
        keys = data.get("keys", []) if isinstance(data, dict) else []
        self._jwks_cache[issuer_did] = (keys, now + self._cache_ttl)
        return keys

    def _check_revocation(self, entry: CredentialStatusEntry) -> str | None:
        try:
            index = int(entry.status_list_index)
        except ValueError:
            return f"bad_status_entry: invalid statusListIndex {entry.status_list_index!r}"
        if index < 0:
            return f"bad_status_entry: negative statusListIndex {index}"

        url = entry.status_list_credential
        cached = self._sl_cache.get(url)
        now = datetime.now(UTC).timestamp()
        if cached is None or cached[1] <= now:
            try:
                bitstring = self._fetch_status_list_bitstring(url)
            except NetworkError as e:
                return f"status_list_fetch_failed: {e}"
            except MalformedCredentialError as e:
                return f"status_list_malformed: {e}"
            self._sl_cache[url] = (bitstring, now + self._status_list_cache_ttl)
        else:
            bitstring = cached[0]

        byte_index, bit_index = divmod(index, 8)
        if byte_index >= len(bitstring):
            return f"bad_status_entry: index {index} exceeds bitstring length"
        if bitstring[byte_index] & (1 << bit_index):
            return "revoked"
        return None

    def _fetch_status_list_bitstring(self, url: str) -> bytes:
        try:
            response = self._http.get(url)
        except httpx.RequestError as e:
            raise NetworkError(f"failed to fetch {url}: {e}", cause=e) from e
        if response.status_code != 200:
            raise NetworkError(f"status list fetch returned {response.status_code}")
        body = response.json()
        if not isinstance(body, dict):
            raise MalformedCredentialError("status list response is not a JSON object")
        jwt_str = body.get("credential_jwt")
        if not isinstance(jwt_str, str):
            raise MalformedCredentialError("status list response missing credential_jwt")

        _, payload_dict, _, _ = _decode_jwt(jwt_str)
        vc = payload_dict.get("vc")
        if not isinstance(vc, dict):
            raise MalformedCredentialError("status list payload missing vc block")
        subject = vc.get("credentialSubject")
        if not isinstance(subject, dict):
            raise MalformedCredentialError("status list missing credentialSubject")
        encoded = subject.get("encodedList")
        if not isinstance(encoded, str):
            raise MalformedCredentialError("status list missing encodedList")
        return gzip.decompress(_b64url_decode(encoded))


# ─── helpers ─────────────────────────────────────────────────────────────────


def _b64url_decode(s: str) -> bytes:
    pad = (-len(s)) % 4
    return base64.urlsafe_b64decode(s + ("=" * pad))


def _decode_jwt(jwt: str) -> tuple[dict[str, Any], dict[str, Any], bytes, bytes]:
    parts = jwt.split(".")
    if len(parts) != 3:
        raise MalformedCredentialError("JWT must have three segments")
    h_b64, p_b64, s_b64 = parts
    try:
        header = json.loads(_b64url_decode(h_b64))
        payload = json.loads(_b64url_decode(p_b64))
        signature = _b64url_decode(s_b64)
    except (ValueError, json.JSONDecodeError) as e:
        raise MalformedCredentialError(f"JWT segment decode failed: {e}") from e
    if not isinstance(header, dict) or not isinstance(payload, dict):
        raise MalformedCredentialError("JWT segments must be JSON objects")
    signing_input = f"{h_b64}.{p_b64}".encode("ascii")
    return header, payload, signing_input, signature


def _parse_payload(payload: dict[str, Any]) -> JwtVcPayload:
    vc = payload.get("vc")
    if not isinstance(vc, dict):
        raise ValueError("payload missing vc block")
    cs_raw = vc.get("credentialSubject")
    if not isinstance(cs_raw, dict):
        raise ValueError("vc.credentialSubject missing")
    cs: CredentialSubject = credential_subject_from_dict(cs_raw)

    cstatus_raw = vc.get("credentialStatus")
    cstatus = None
    if isinstance(cstatus_raw, dict):
        cstatus = CredentialStatusEntry(
            id=cstatus_raw["id"],
            type=cstatus_raw["type"],
            status_purpose=cstatus_raw.get("statusPurpose", "revocation"),
            status_list_index=cstatus_raw["statusListIndex"],
            status_list_credential=cstatus_raw["statusListCredential"],
        )

    inner = JwtVcInner(
        context=list(vc.get("@context", [])),
        type=list(vc.get("type", [])),
        issuer=vc.get("issuer", payload.get("iss", "")),
        issuance_date=vc.get("issuanceDate", ""),
        credential_subject=cs,
        expiration_date=vc.get("expirationDate"),
        credential_status=cstatus,
    )

    return JwtVcPayload(
        iss=str(payload.get("iss", "")),
        sub=str(payload.get("sub", "")),
        jti=str(payload.get("jti", "")),
        iat=int(payload.get("iat", 0)),
        nbf=int(payload["nbf"]) if "nbf" in payload else None,
        exp=int(payload["exp"]) if "exp" in payload else None,
        vc=inner,
    )


def _find_key_by_kid(keys: list[dict[str, Any]], kid: str) -> dict[str, Any] | None:
    fragment = kid.rsplit("#", 1)[-1]
    for k in keys:
        if k.get("kid") == kid or k.get("kid") == fragment:
            return k
    return None


def _did_web_domain(did: str) -> str | None:
    if not did.startswith("did:web:"):
        return None
    rest = did[len("did:web:") :]
    rest = rest.split("#", 1)[0]
    return rest.replace(":", "/") or None


def _ed25519_verify(jwk: dict[str, Any], message: bytes, signature: bytes) -> bool:
    if jwk.get("kty") != "OKP" or jwk.get("crv") != "Ed25519":
        return False
    x = jwk.get("x")
    if not isinstance(x, str):
        return False
    try:
        public_key = Ed25519PublicKey.from_public_bytes(_b64url_decode(x))
        public_key.verify(signature, message)
        return True
    except InvalidSignature:
        return False
    except Exception:
        return False
