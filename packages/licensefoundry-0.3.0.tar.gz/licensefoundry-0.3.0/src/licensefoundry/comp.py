"""CoMP-shaped translation of license credentials.

Mirrors ``services/api/adapters/comp_v1_0_adapter.py`` and the TypeScript
SDK's ``comp.ts`` — the Python SDK ships the same translation locally so
consumers can match credentials against IAB CoMP queries without round-
tripping through the issuer service.

Per ``/docs/comp-mapping.md``:

============== ===================================
canonical right CoMP encoding
============== ===================================
train          ``function: 2`` + ``subfn: 0``
rag            ``function: 3`` + ``subfn: 1``
embed          ``function: 4`` + ``subfn: 0``
display        ``function: 5``
eval           ``function: 3`` + ``subfn: 2``
derive         ``function: 6``
commercial     ``ause: 0``
============== ===================================
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from licensefoundry.types import CredentialSubject, JwtVcPayload

COMP_VERSION = "comp/v1.0"

FUNCTION_AI_TRAIN = 2
FUNCTION_AI_INPUT = 3
FUNCTION_AI_INDEX = 4
FUNCTION_SEARCH = 5
FUNCTION_AI_OUTPUT = 6

SUBFN_TRAINING = 0
SUBFN_INDEXING = 0
SUBFN_RAG = 1
SUBFN_EVAL = 2

AUSE_COMMERCIAL = 0


@dataclass(slots=True)
class CompFunctionEntry:
    granted: bool
    subfn: int | None = None
    scope: dict[str, Any] | None = None


@dataclass(slots=True)
class CompPackage:
    lid: str
    functions: dict[str, CompFunctionEntry]
    ause: list[int] | None = None
    citation: dict[str, Any] | None = None
    country: list[str] | None = None
    licensedur: int | None = None
    ctype: str | None = None


def from_credential(input_: JwtVcPayload | CredentialSubject) -> CompPackage:
    """Translate a credential's subject to a CoMP-shaped Package.

    Accepts either a full decoded :class:`JwtVcPayload` or a bare
    :class:`CredentialSubject`.
    """
    subject = input_.vc.credential_subject if isinstance(input_, JwtVcPayload) else input_

    pkg = CompPackage(lid=subject.id, functions={})
    r = subject.rights

    if r.train and r.train.granted:
        pkg.functions[str(FUNCTION_AI_TRAIN)] = CompFunctionEntry(
            granted=True,
            subfn=SUBFN_TRAINING,
            scope=_scope_to_dict(r.train.scope),
        )
    if r.rag and r.rag.granted:
        pkg.functions[str(FUNCTION_AI_INPUT)] = CompFunctionEntry(
            granted=True,
            subfn=SUBFN_RAG,
            scope=_scope_to_dict(r.rag.scope),
        )
    if r.embed and r.embed.granted:
        pkg.functions[str(FUNCTION_AI_INDEX)] = CompFunctionEntry(
            granted=True,
            subfn=SUBFN_INDEXING,
            scope=_scope_to_dict(r.embed.scope),
        )
    if r.display and r.display.granted:
        pkg.functions[str(FUNCTION_SEARCH)] = CompFunctionEntry(granted=True)
    if r.eval and r.eval.granted:
        # eval shares ai-input with rag — first-write-wins per the TS SDK
        if str(FUNCTION_AI_INPUT) not in pkg.functions:
            pkg.functions[str(FUNCTION_AI_INPUT)] = CompFunctionEntry(
                granted=True, subfn=SUBFN_EVAL
            )
    if r.derive and r.derive.granted:
        pkg.functions[str(FUNCTION_AI_OUTPUT)] = CompFunctionEntry(
            granted=True,
            scope=_scope_to_dict(r.derive.scope),
        )
    if r.commercial and r.commercial.granted:
        pkg.ause = [AUSE_COMMERCIAL]

    sc = subject.scope
    if sc.attribution:
        cite: dict[str, Any] = {"required": sc.attribution.required}
        if sc.attribution.format:
            cite["format"] = sc.attribution.format
        pkg.citation = cite
    if sc.jurisdiction:
        pkg.country = list(sc.jurisdiction)
    if sc.duration:
        pkg.licensedur = _duration_days(sc.duration.starts, sc.duration.ends)
    if subject.asset.media_type:
        pkg.ctype = subject.asset.media_type

    return pkg


def satisfies(
    input_: JwtVcPayload | CredentialSubject,
    *,
    function: int | None = None,
    subfn: int | None = None,
    ause: int | None = None,
    country: str | None = None,
) -> bool:
    """Boolean check: does the credential grant the requested CoMP criteria?

    Multiple criteria are AND-combined. Examples::

        comp.satisfies(vc, function=2, subfn=0)   # train+training
        comp.satisfies(vc, function=3, subfn=1)   # ai-input+rag
        comp.satisfies(vc, ause=0)                 # commercial
    """
    pkg = from_credential(input_)

    if function is not None:
        entry = pkg.functions.get(str(function))
        if entry is None or not entry.granted:
            return False
        if subfn is not None and entry.subfn != subfn:
            return False
    if ause is not None:
        if not pkg.ause or ause not in pkg.ause:
            return False
    if country is not None:
        if not pkg.country or country not in pkg.country:
            return False
    return True


def _scope_to_dict(scope: Any) -> dict[str, Any] | None:
    if scope is None:
        return None
    out: dict[str, Any] = {}
    for f in scope.__dataclass_fields__:  # type: ignore[attr-defined]
        v = getattr(scope, f)
        if v is not None:
            out[f] = v
    return out or None


def _duration_days(starts: str, ends: str | None) -> int:
    if ends is None:
        return -1
    try:
        s = _parse_iso(starts)
        e = _parse_iso(ends)
    except ValueError:
        return -1
    delta = e - s
    return max(0, round(delta.total_seconds() / 86400))


def _parse_iso(s: str) -> datetime:
    # Python's fromisoformat accepts trailing "Z" only on 3.11+; normalize first.
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    return datetime.fromisoformat(s)
