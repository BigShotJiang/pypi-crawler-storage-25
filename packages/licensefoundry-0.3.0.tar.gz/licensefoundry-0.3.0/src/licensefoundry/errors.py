"""Typed exception hierarchy for the licensefoundry SDK.

Per ``/docs/auth-access-flows.md`` §4.5, the SDK MUST surface paid-feature
gate failures as :class:`CapabilityNotEnabledError` so customer code can
prompt users to upgrade rather than treat the response as a generic 4xx.
"""

from __future__ import annotations

from typing import Any, Literal

ErrorCode = Literal[
    "auth_failed",
    "scope_denied",
    "capability_not_enabled",
    "validation_failed",
    "not_found",
    "conflict",
    "rate_limited",
    "server_error",
    "network_error",
    "verification_failed",
    "malformed_credential",
]


class LicenseFoundryError(Exception):
    """Base class for all SDK errors. ``code`` is a stable string for
    switch-style dispatch; ``status`` is the HTTP status when applicable."""

    code: ErrorCode = "server_error"

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        detail: Any = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.detail = detail
        if cause is not None:
            self.__cause__ = cause


class AuthError(LicenseFoundryError):
    code: ErrorCode = "auth_failed"

    def __init__(self, message: str = "authentication failed", *, status: int = 401, detail: Any = None) -> None:
        super().__init__(message, status=status, detail=detail)


class ScopeDeniedError(LicenseFoundryError):
    code: ErrorCode = "scope_denied"

    def __init__(self, action: str | None = None, detail: Any = None) -> None:
        message = f"scope denies action {action}" if action else "scope denied"
        super().__init__(message, status=403, detail=detail)
        self.action = action


class CapabilityNotEnabledError(LicenseFoundryError):
    """HTTP 402 with ``error: capability_not_enabled``.

    Catch this and surface an upgrade flow:

        try:
            client.issuer.issue_credential(...)
        except CapabilityNotEnabledError as e:
            show_upgrade_modal(plan=e.required_plan, url=e.upgrade_url)
    """

    code: ErrorCode = "capability_not_enabled"

    def __init__(self, detail: dict[str, Any]) -> None:
        capability = detail.get("capability", "<unknown>")
        required = detail.get("required_plan")
        msg = f"capability '{capability}' not enabled on current plan"
        if required:
            msg += f" (requires {required})"
        super().__init__(msg, status=402, detail=detail)
        self.capability = capability
        self.current_plan = detail.get("current_plan")
        self.required_plan = required
        self.upgrade_url = detail.get("upgrade_url")


class ValidationError(LicenseFoundryError):
    code: ErrorCode = "validation_failed"

    def __init__(self, message: str = "validation failed", detail: Any = None) -> None:
        super().__init__(message, status=422, detail=detail)


class NotFoundError(LicenseFoundryError):
    code: ErrorCode = "not_found"

    def __init__(self, message: str = "not found", detail: Any = None) -> None:
        super().__init__(message, status=404, detail=detail)


class ConflictError(LicenseFoundryError):
    code: ErrorCode = "conflict"

    def __init__(self, message: str = "conflict", detail: Any = None) -> None:
        super().__init__(message, status=409, detail=detail)


class RateLimitedError(LicenseFoundryError):
    code: ErrorCode = "rate_limited"

    def __init__(self, retry_after: int | None = None, detail: Any = None) -> None:
        msg = f"rate limited; retry after {retry_after}s" if retry_after else "rate limited"
        super().__init__(msg, status=429, detail=detail)
        self.retry_after = retry_after


class ServerError(LicenseFoundryError):
    code: ErrorCode = "server_error"

    def __init__(self, message: str = "server error", status: int = 500, detail: Any = None) -> None:
        super().__init__(message, status=status, detail=detail)


class NetworkError(LicenseFoundryError):
    code: ErrorCode = "network_error"

    def __init__(self, message: str, cause: BaseException | None = None) -> None:
        super().__init__(message, cause=cause)


class VerificationError(LicenseFoundryError):
    """Raised by :meth:`Verifier.verify_or_raise` when verification fails.
    Carries the structured error list."""

    code: ErrorCode = "verification_failed"

    def __init__(self, errors: list[str]) -> None:
        super().__init__("credential verification failed: " + "; ".join(errors))
        self.errors = errors


class MalformedCredentialError(LicenseFoundryError):
    code: ErrorCode = "malformed_credential"

    def __init__(self, message: str, cause: BaseException | None = None) -> None:
        super().__init__(message, cause=cause)
