"""HTTP layer for the licensefoundry SDK.

Wraps ``httpx.Client`` with: auth header injection, JSON encode/decode, and
structured error mapping per ``/docs/auth-access-flows.md`` §4.5.

The Python SDK exposes snake_case keys throughout (idiomatic Python), and the
service API also uses snake_case, so no key translation happens here — only
shape mapping.
"""

from __future__ import annotations

from typing import Any

import httpx

from licensefoundry.errors import (
    AuthError,
    CapabilityNotEnabledError,
    ConflictError,
    LicenseFoundryError,
    NetworkError,
    NotFoundError,
    RateLimitedError,
    ScopeDeniedError,
    ServerError,
    ValidationError,
)


class HttpClient:
    """Synchronous HTTP client. Wraps :class:`httpx.Client`."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout_seconds: float = 30.0,
        transport: httpx.BaseTransport | None = None,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        if not base_url:
            raise ValueError("base_url is required")
        if not api_key:
            raise ValueError("api_key is required")
        self._api_key = api_key
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            timeout=timeout_seconds,
            transport=transport,
            headers={
                "Accept": "application/json",
                **(default_headers or {}),
            },
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        unauthenticated: bool = False,
    ) -> Any:
        headers: dict[str, str] = {}
        if not unauthenticated:
            headers["Authorization"] = f"Bearer {self._api_key}"

        try:
            response = self._client.request(method, path, json=json, headers=headers)
        except httpx.RequestError as e:
            raise NetworkError(f"request failed: {e}", cause=e) from e

        if response.is_success:
            if response.status_code == 204 or not response.content:
                return None
            return response.json()

        raise self._map_error(response)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "HttpClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    @staticmethod
    def _map_error(response: httpx.Response) -> LicenseFoundryError:
        try:
            detail = response.json() if response.content else None
        except Exception:
            detail = None

        # Most FastAPI errors come back as {"detail": {"reason": ..., ...}}
        inner: dict[str, Any] = {}
        if isinstance(detail, dict):
            d = detail.get("detail")
            if isinstance(d, dict):
                inner = d
            else:
                inner = detail
        reason = inner.get("reason") if isinstance(inner.get("reason"), str) else None

        status = response.status_code
        if status == 401:
            return AuthError(reason or "authentication failed", detail=detail)
        if status == 402:
            error = inner.get("error")
            if error == "capability_not_enabled" and isinstance(inner.get("capability"), str):
                return CapabilityNotEnabledError(inner)
            err = LicenseFoundryError(reason or "payment required", status=402, detail=detail)
            err.code = "capability_not_enabled"  # type: ignore[assignment]
            return err
        if status == 403:
            action = inner.get("action") if isinstance(inner.get("action"), str) else None
            return ScopeDeniedError(action, detail=detail)
        if status == 404:
            return NotFoundError(reason or "not found", detail=detail)
        if status == 409:
            return ConflictError(reason or "conflict", detail=detail)
        if status == 422:
            return ValidationError(reason or "validation failed", detail=detail)
        if status == 429:
            ra_header = response.headers.get("Retry-After")
            try:
                retry_after = int(ra_header) if ra_header is not None else None
            except ValueError:
                retry_after = None
            return RateLimitedError(retry_after, detail=detail)
        return ServerError(
            f"request failed with status {status}",
            status=status,
            detail=detail,
        )
