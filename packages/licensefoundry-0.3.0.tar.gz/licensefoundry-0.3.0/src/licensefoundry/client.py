"""LicenseFoundryClient — top-level entry point for the Python SDK.

Composes the lower-level clients (issuer, verifier) with shared HTTP
configuration. Most callers should use this rather than constructing
the sub-clients directly.

    lf = LicenseFoundryClient(
        base_url="https://api.licensefoundry.com",
        api_key=os.environ["LICENSEFOUNDRY_API_KEY"],
        accepted_issuers=["did:web:licensefoundry.com"],
    )

    cred = lf.issuer.issue_credential(IssueCredentialRequest(...))
    result = lf.verifier.verify(cred.credential_jwt)
"""

from __future__ import annotations

from typing import Any

import httpx

from licensefoundry.http import HttpClient
from licensefoundry.issuer import IssuerClient
from licensefoundry.verifier import Verifier


class LicenseFoundryClient:
    """Top-level SDK client. Owns the underlying HTTP client; call
    :meth:`close` (or use as a context manager) to release sockets."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        accepted_issuers: list[str],
        accepted_context_urls: list[str] | None = None,
        timeout_seconds: float = 30.0,
        cache_ttl_seconds: int = 24 * 60 * 60,
        status_list_cache_ttl_seconds: int = 5 * 60,
        clock_skew_seconds: int = 60,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            timeout_seconds=timeout_seconds,
            transport=transport,
        )
        self.issuer = IssuerClient(self._http)
        self.verifier = Verifier(
            accepted_issuers=accepted_issuers,
            accepted_context_urls=accepted_context_urls,
            cache_ttl_seconds=cache_ttl_seconds,
            status_list_cache_ttl_seconds=status_list_cache_ttl_seconds,
            clock_skew_seconds=clock_skew_seconds,
        )

    def close(self) -> None:
        self._http.close()
        self.verifier.close()

    def __enter__(self) -> "LicenseFoundryClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
