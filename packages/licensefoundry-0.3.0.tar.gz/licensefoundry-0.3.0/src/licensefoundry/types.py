"""Canonical credential types — Python mirror of the TypeScript SDK's ``types.ts``.

All types use canonical Path C field names. Per
``/docs/credential-format.md`` §3 the canonical model is the durable source of
truth; CoMP-shaped output is produced by :mod:`licensefoundry.comp`.

Implemented as :mod:`dataclasses` rather than Pydantic to keep the SDK's
dependency surface minimal — Pydantic 2.x is heavy for a client library.
The :func:`asdict_camel` helper converts dataclass instances to camelCase
dicts for the wire (the HTTP layer further translates to snake_case).
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields, is_dataclass
from datetime import datetime
from typing import Any, Literal, TypeAlias

MediaType: TypeAlias = Literal["text", "video", "image", "audio", "other"]
Audience: TypeAlias = Literal["single_product", "internal", "named_partners", "public"]


@dataclass(slots=True)
class AssetInfo:
    sha256: str
    ipfs_cid: str
    anchor_txid: str
    media_type: MediaType


@dataclass(slots=True)
class TrainScope:
    model_family: str | None = None
    one_time: bool | None = None
    derivatives_only: bool | None = None


@dataclass(slots=True)
class TrainGrant:
    granted: bool
    scope: TrainScope | None = None


@dataclass(slots=True)
class RagScope:
    max_excerpt_tokens: int | None = None
    citation_required: bool | None = None


@dataclass(slots=True)
class RagGrant:
    granted: bool
    scope: RagScope | None = None


@dataclass(slots=True)
class EmbedScope:
    index_only: bool | None = None


@dataclass(slots=True)
class EmbedGrant:
    granted: bool
    scope: EmbedScope | None = None


@dataclass(slots=True)
class DisplayGrant:
    granted: bool


@dataclass(slots=True)
class EvalGrant:
    granted: bool


@dataclass(slots=True)
class DeriveScope:
    derivative_types: list[str] | None = None


@dataclass(slots=True)
class DeriveGrant:
    granted: bool
    scope: DeriveScope | None = None


@dataclass(slots=True)
class CommercialGrant:
    granted: bool


@dataclass(slots=True)
class Rights:
    train: TrainGrant | None = None
    rag: RagGrant | None = None
    embed: EmbedGrant | None = None
    display: DisplayGrant | None = None
    eval: EvalGrant | None = None
    derive: DeriveGrant | None = None
    commercial: CommercialGrant | None = None


@dataclass(slots=True)
class Attribution:
    required: bool
    format: str | None = None


@dataclass(slots=True)
class Duration:
    starts: str
    ends: str | None = None


@dataclass(slots=True)
class CredentialScope:
    audience: Audience | None = None
    product_id: str | None = None
    jurisdiction: list[str] | None = None
    attribution: Attribution | None = None
    duration: Duration | None = None


@dataclass(slots=True)
class CredentialSubject:
    id: str
    asset: AssetInfo
    rights: Rights
    scope: CredentialScope


@dataclass(slots=True)
class CredentialStatusEntry:
    id: str
    type: Literal["StatusList2021Entry"]
    status_purpose: Literal["revocation"]
    status_list_index: str
    status_list_credential: str


@dataclass(slots=True)
class JwtVcInner:
    """The ``vc`` block inside a JWT-VC payload."""

    context: list[str]
    """Mapped to ``@context`` on the wire (Python identifier limitation)."""

    type: list[str]
    issuer: str
    issuance_date: str
    credential_subject: CredentialSubject
    expiration_date: str | None = None
    credential_status: CredentialStatusEntry | None = None


@dataclass(slots=True)
class JwtVcPayload:
    iss: str
    sub: str
    jti: str
    iat: int
    vc: JwtVcInner
    nbf: int | None = None
    exp: int | None = None


@dataclass(slots=True)
class VerificationResult:
    valid: bool
    claims: JwtVcPayload | None
    errors: list[str]


# ─── HTTP request / response payloads ────────────────────────────────────────


@dataclass(slots=True)
class RegisterAssetRequest:
    sha256: str
    ipfs_cid: str
    anchor_txid: str
    media_type: MediaType
    size_bytes: int
    filename: str
    minio_key: str


@dataclass(slots=True)
class RegisterAssetResponse:
    asset_id: str
    sha256: str
    environment: str


@dataclass(slots=True)
class IssueCredentialRequest:
    asset_id: str
    rights: Rights
    scope: CredentialScope
    condition_set_id: str | None = None
    expires_at: datetime | None = None
    comp_version: str = "v1.0"


@dataclass(slots=True)
class IssueCredentialResponse:
    license_id: str
    license_id_url: str
    credential_jwt: str
    issuer_did: str
    issued_at: str
    expires_at: str | None
    canonical_version: str
    comp_version_issued: str


@dataclass(slots=True)
class RevokeCredentialResponse:
    license_id: str
    revoked: bool
    revoked_at: str
    revoke_reason: str | None


@dataclass(slots=True)
class CredentialStatusResponse:
    license_id: str
    revoked: bool
    revoked_at: str | None
    status_list_credential: str | None
    status_list_index: int | None


# ─── Conversion helpers ──────────────────────────────────────────────────────


def to_dict(obj: Any) -> Any:
    """Recursively convert a dataclass tree to a plain-dict tree.

    Handles ``datetime`` (isoformat) and special-cases :class:`JwtVcInner`'s
    ``context`` field, which renders as ``@context`` on the wire.
    """
    if isinstance(obj, JwtVcInner):
        out: dict[str, Any] = {"@context": list(obj.context), "type": list(obj.type)}
        out["issuer"] = obj.issuer
        out["issuanceDate"] = obj.issuance_date
        if obj.expiration_date is not None:
            out["expirationDate"] = obj.expiration_date
        out["credentialSubject"] = to_dict(obj.credential_subject)
        if obj.credential_status is not None:
            out["credentialStatus"] = to_dict(obj.credential_status)
        return out
    if is_dataclass(obj):
        out = {}
        for f in fields(obj):
            value = getattr(obj, f.name)
            if value is None:
                continue
            out[f.name] = to_dict(value)
        return out
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, list):
        return [to_dict(v) for v in obj]
    if isinstance(obj, dict):
        return {k: to_dict(v) for k, v in obj.items()}
    return obj


def credential_subject_from_dict(d: dict[str, Any]) -> CredentialSubject:
    """Build a :class:`CredentialSubject` from a parsed dict (snake_case keys).

    Tolerates both snake_case (canonical) and camelCase (W3C envelope) keys
    for the few overlapping fields. Unknown keys are ignored — per
    ``/docs/credential-format.md`` §7, verifiers SHOULD log unknown fields
    without rejecting (forward-compat).
    """
    asset = d["asset"]
    rights = d.get("rights") or {}
    scope = d.get("scope") or {}
    return CredentialSubject(
        id=d["id"],
        asset=AssetInfo(
            sha256=asset["sha256"],
            ipfs_cid=asset.get("ipfs_cid") or asset.get("ipfsCid"),
            anchor_txid=asset.get("anchor_txid") or asset.get("anchorTxid"),
            media_type=asset.get("media_type") or asset.get("mediaType"),
        ),
        rights=_rights_from_dict(rights),
        scope=_scope_from_dict(scope),
    )


def _rights_from_dict(d: dict[str, Any]) -> Rights:
    def _train(v: dict[str, Any] | None) -> TrainGrant | None:
        if v is None:
            return None
        sc = v.get("scope")
        return TrainGrant(
            granted=bool(v.get("granted")),
            scope=TrainScope(
                model_family=_pick(sc, "model_family", "modelFamily") if sc else None,
                one_time=_pick(sc, "one_time", "oneTime") if sc else None,
                derivatives_only=_pick(sc, "derivatives_only", "derivativesOnly") if sc else None,
            ) if sc else None,
        )

    def _rag(v: dict[str, Any] | None) -> RagGrant | None:
        if v is None:
            return None
        sc = v.get("scope")
        return RagGrant(
            granted=bool(v.get("granted")),
            scope=RagScope(
                max_excerpt_tokens=_pick(sc, "max_excerpt_tokens", "maxExcerptTokens") if sc else None,
                citation_required=_pick(sc, "citation_required", "citationRequired") if sc else None,
            ) if sc else None,
        )

    def _embed(v: dict[str, Any] | None) -> EmbedGrant | None:
        if v is None:
            return None
        sc = v.get("scope")
        return EmbedGrant(
            granted=bool(v.get("granted")),
            scope=EmbedScope(
                index_only=_pick(sc, "index_only", "indexOnly") if sc else None,
            ) if sc else None,
        )

    def _derive(v: dict[str, Any] | None) -> DeriveGrant | None:
        if v is None:
            return None
        sc = v.get("scope")
        return DeriveGrant(
            granted=bool(v.get("granted")),
            scope=DeriveScope(
                derivative_types=_pick(sc, "derivative_types", "derivativeTypes") if sc else None,
            ) if sc else None,
        )

    return Rights(
        train=_train(d.get("train")),
        rag=_rag(d.get("rag")),
        embed=_embed(d.get("embed")),
        display=DisplayGrant(granted=bool(d["display"]["granted"])) if d.get("display") else None,
        eval=EvalGrant(granted=bool(d["eval"]["granted"])) if d.get("eval") else None,
        derive=_derive(d.get("derive")),
        commercial=CommercialGrant(granted=bool(d["commercial"]["granted"])) if d.get("commercial") else None,
    )


def _scope_from_dict(d: dict[str, Any]) -> CredentialScope:
    attribution = d.get("attribution")
    duration = d.get("duration")
    return CredentialScope(
        audience=d.get("audience"),
        product_id=_pick(d, "product_id", "productId"),
        jurisdiction=d.get("jurisdiction"),
        attribution=Attribution(
            required=bool(attribution.get("required")),
            format=attribution.get("format"),
        ) if attribution else None,
        duration=Duration(
            starts=duration["starts"],
            ends=duration.get("ends"),
        ) if duration else None,
    )


def _pick(d: dict[str, Any] | None, *keys: str) -> Any:
    if d is None:
        return None
    for k in keys:
        if k in d:
            return d[k]
    return None
