"""licensefoundry — Python SDK.

Three surfaces:
- :class:`LicenseFoundryClient` — top-level client wiring HTTP + issuer + verifier
- :class:`IssuerClient` / :class:`Verifier` — use directly if you only need one half
- :mod:`licensefoundry.comp` — CoMP-shaped helpers (``from_credential``, ``satisfies``)

The customer-facing API uses canonical Path C field names. CoMP terms never appear
in the public surface except through the explicit :mod:`comp` helpers.
"""

from licensefoundry import comp, compliance
from licensefoundry.client import LicenseFoundryClient
from licensefoundry.errors import (
    AuthError,
    CapabilityNotEnabledError,
    ConflictError,
    LicenseFoundryError,
    MalformedCredentialError,
    NetworkError,
    NotFoundError,
    RateLimitedError,
    ScopeDeniedError,
    ServerError,
    ValidationError,
    VerificationError,
)
from licensefoundry.http import HttpClient
from licensefoundry.issuer import IssuerClient
from licensefoundry.types import (
    AssetInfo,
    Audience,
    Attribution,
    CommercialGrant,
    CredentialScope,
    CredentialStatusEntry,
    CredentialSubject,
    DeriveGrant,
    DeriveScope,
    DisplayGrant,
    Duration,
    EmbedGrant,
    EmbedScope,
    EvalGrant,
    IssueCredentialRequest,
    IssueCredentialResponse,
    JwtVcInner,
    JwtVcPayload,
    MediaType,
    RagGrant,
    RagScope,
    RegisterAssetRequest,
    RegisterAssetResponse,
    Rights,
    TrainGrant,
    TrainScope,
    VerificationResult,
)
from licensefoundry.verifier import Verifier

__all__ = [
    "AssetInfo",
    "Attribution",
    "Audience",
    "AuthError",
    "CapabilityNotEnabledError",
    "CommercialGrant",
    "ConflictError",
    "CredentialScope",
    "CredentialStatusEntry",
    "CredentialSubject",
    "DeriveGrant",
    "DeriveScope",
    "DisplayGrant",
    "Duration",
    "EmbedGrant",
    "EmbedScope",
    "EvalGrant",
    "HttpClient",
    "IssueCredentialRequest",
    "IssueCredentialResponse",
    "IssuerClient",
    "JwtVcInner",
    "JwtVcPayload",
    "LicenseFoundryClient",
    "LicenseFoundryError",
    "MalformedCredentialError",
    "MediaType",
    "NetworkError",
    "NotFoundError",
    "RagGrant",
    "RagScope",
    "RateLimitedError",
    "RegisterAssetRequest",
    "RegisterAssetResponse",
    "Rights",
    "ScopeDeniedError",
    "ServerError",
    "TrainGrant",
    "TrainScope",
    "ValidationError",
    "VerificationError",
    "VerificationResult",
    "Verifier",
    "comp",
    "compliance",
]

# Read the version from the installed package metadata so this can't
# drift from pyproject.toml. (Previously hardcoded — got out of sync
# during the 0.1.0 -> 0.1.1 publish; see docs/sdk-publishing.md.)
from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("licensefoundry")
except PackageNotFoundError:  # pragma: no cover — only happens in editable installs without metadata
    __version__ = "unknown"

del PackageNotFoundError, _pkg_version
