"""IssuerClient — register assets, issue/revoke credentials, fetch status."""

from __future__ import annotations

from typing import Any

from licensefoundry.http import HttpClient
from licensefoundry.types import (
    CredentialStatusResponse,
    IssueCredentialRequest,
    IssueCredentialResponse,
    RegisterAssetRequest,
    RegisterAssetResponse,
    RevokeCredentialResponse,
    to_dict,
)


class IssuerClient:
    """Sync client for the issuance + revocation HTTP surface."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def register_asset(self, request: RegisterAssetRequest) -> RegisterAssetResponse:
        """Register an asset's metadata. v1 expects the caller to have already
        computed the SHA-256, pinned to IPFS, and anchored onchain — Phase 6
        will add a higher-level ``anchor_asset(file)`` that does all of this.
        """
        body = to_dict(request)
        data = self._http.request("POST", "/v1/assets", json=body)
        return RegisterAssetResponse(**data)

    def issue_credential(self, request: IssueCredentialRequest) -> IssueCredentialResponse:
        """Issue a new license credential as a JWT-VC.

        The returned ``credential_jwt`` is the wire format.
        """
        body = to_dict(request)
        data = self._http.request("POST", "/v1/credentials/issue", json=body)
        return IssueCredentialResponse(**data)

    def revoke_credential(
        self, credential_id: str, reason: str | None = None
    ) -> RevokeCredentialResponse:
        """Revoke a previously issued credential. Idempotent.

        Per ``/docs/billing-model.md`` §2, revocation is never billed and is
        permitted even on suspended accounts.
        """
        body: dict[str, Any] = {"reason": reason} if reason is not None else {}
        data = self._http.request(
            "POST",
            f"/v1/credentials/{credential_id}/revoke",
            json=body,
        )
        return RevokeCredentialResponse(**data)

    def get_credential_status(self, credential_id: str) -> CredentialStatusResponse:
        """Look up a credential's revocation status (public; no auth required)."""
        data = self._http.request(
            "GET",
            f"/v1/credentials/{credential_id}/status",
            unauthenticated=True,
        )
        return CredentialStatusResponse(**data)

    def get_status_list_credential(
        self, period: str, environment: str
    ) -> str:
        """Fetch the signed Status List 2021 credential JWT for ``(period, env)``.

        ``period`` is ``"YYYY-MM"``; ``environment`` is ``"sandbox"`` or
        ``"production"``. Verifiers should cache this per ``Cache-Control``
        (default 5 min per ``/docs/credential-format.md`` §7).
        """
        data = self._http.request(
            "GET",
            f"/v1/status-lists/{period}/{environment}",
            unauthenticated=True,
        )
        return data["credential_jwt"]
