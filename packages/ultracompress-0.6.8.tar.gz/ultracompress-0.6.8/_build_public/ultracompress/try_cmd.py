"""`uc try [MODEL]` — single-command customer onboarding.

Walks the customer through download + wrap + verify + real generate in
ONE command. Default model is sipsa-qwen3-0.6b (smallest, fastest, sub-1% PPL).

Flow:
  1. `pip install ultracompress` (you already did this if you're running `uc try`)
  2. `uc try` → downloads SipsaLabs/qwen3-0.6b-uc-v3-bpw5 from HF Hub
  3. Wraps base bf16 skeleton with CorrectionLinear (lossless reconstruction)
  4. Verifies pack integrity (SHA-256 audit)
  5. Runs a real prompt and prints the generation
  6. Shows next-step hints (API curl, larger model, etc.)

Designed for zero-friction first-run. Auto-detects cuda / MPS / CPU.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path


# Known-good Sipsa-compressed model presets. Each entry: (base_hf_id, sipsa_repo, ppl_ratio).
# Sub-1% Qwen3 family is the default ladder; others are honestly tagged.
PRESETS: dict[str, tuple[str, str, str]] = {
    # short alias -> (base HF id, Sipsa-compressed HF repo, PPL ratio claim)
    "qwen3-0.6b":      ("Qwen/Qwen3-0.6B",       "SipsaLabs/qwen3-0.6b-uc-v3-bpw5",       "1.0069x (0.69%)"),
    "qwen3-1.7b-base": ("Qwen/Qwen3-1.7B-Base",  "SipsaLabs/qwen3-1.7b-base-uc-v3-bpw5",  "1.0040x (0.40%) — all-time record"),
    "qwen3-1.7b":      ("Qwen/Qwen3-1.7B",       "SipsaLabs/qwen3-1.7b-uc-v3-bpw5",       "sub-1%"),
    "qwen3-8b":        ("Qwen/Qwen3-8B",         "SipsaLabs/qwen3-8b-uc-v3-bpw5",         "1.0044x (0.44%)"),
    "qwen3-14b":       ("Qwen/Qwen3-14B",        "SipsaLabs/qwen3-14b-uc-v3-bpw5",        "1.0040x (0.40%)"),
}
DEFAULT_MODEL = "qwen3-0.6b"


def _pick_device():
    import torch
    if torch.cuda.is_available():
        return "cuda:0"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def _print_banner(model_short: str, base_id: str, sipsa_repo: str, ppl: str) -> None:
    bar = "=" * 64
    print(bar)
    print(f"  Sipsa try  —  {model_short}")
    print(f"  base:  {base_id}")
    print(f"  sipsa: huggingface.co/{sipsa_repo}")
    print(f"  ppl:   {ppl} compressed-vs-baseline")
    print(bar)


def _hint_next() -> None:
    print()
    print("Next steps:")
    print("  - try a bigger model:  uc try qwen3-1.7b   (or qwen3-8b / qwen3-14b)")
    print("  - use the hosted API:")
    print("      curl https://api.sipsalabs.com/v1/chat/completions \\")
    print("        -H 'Authorization: Bearer <YOUR_KEY>' \\")
    print("        -H 'Content-Type: application/json' \\")
    print("        -d '{\"model\":\"sipsa-qwen3-0.6b\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}'")
    print("  - get an API key:  founder@sipsalabs.com  or  https://sipsalabs.com/get-access")
    print()


def cmd_try(args: argparse.Namespace) -> int:
    model_short = args.model or DEFAULT_MODEL
    if model_short not in PRESETS:
        print(f"[error] unknown model alias: {model_short!r}")
        print(f"[hint]  available presets: {', '.join(sorted(PRESETS))}")
        print(f"[hint]  see huggingface.co/SipsaLabs for the full Sipsa-compressed catalog")
        return 2

    base_hf_id, sipsa_repo, ppl_ratio = PRESETS[model_short]
    prompt = args.prompt or "Write one sentence explaining what model compression is."
    max_new_tokens = int(args.max_tokens or 200)

    _print_banner(model_short, base_hf_id, sipsa_repo, ppl_ratio)

    # Late imports so `uc try --help` is instant.
    try:
        import torch
        from huggingface_hub import snapshot_download
        from transformers import AutoModelForCausalLM, AutoTokenizer

        from ultracompress.api_v3 import DEFAULT_TARGETS, _wrap_with_correction
        from ultracompress.pack_v3 import (
            parse_uc_layer_v3,
            reconstruct_layer_state_dict_v3,
        )
    except ImportError as e:
        print(f"[error] missing dependency: {e}")
        print(f"[fix]   pip install ultracompress[serve]   # or: pip install torch transformers huggingface_hub")
        return 2

    device = _pick_device()
    print(f"\n[device] {device}")

    t0 = time.time()
    print(f"\n[1/4] downloading Sipsa pack from HuggingFace ({sipsa_repo})...")
    pack_dir = Path(snapshot_download(sipsa_repo))
    print(f"      pack at: {pack_dir}")

    print(f"\n[2/4] loading base bf16 skeleton ({base_hf_id})...")
    base = AutoModelForCausalLM.from_pretrained(base_hf_id, dtype=torch.bfloat16)
    tok = AutoTokenizer.from_pretrained(base_hf_id)
    if tok.pad_token_id is None:
        tok.pad_token_id = tok.eos_token_id
    nparam_b = sum(p.numel() for p in base.parameters()) / 1e9
    print(f"      base: {nparam_b:.2f}B params")

    print(f"\n[3/4] wrapping + loading Sipsa-compressed layer state dicts...")
    parsed_l0 = parse_uc_layer_v3(pack_dir / "layer_000.uc")
    ranks = {int(p["rank"]) for k, p in parsed_l0.items()
             if isinstance(p, dict) and "rank" in p}
    rank = sorted(ranks)[0] if ranks else 32
    n_replaced = _wrap_with_correction(base, rank=rank, targets=DEFAULT_TARGETS)
    n_layers = base.config.num_hidden_layers
    for i in range(n_layers):
        sd = reconstruct_layer_state_dict_v3(pack_dir / f"layer_{i:03d}.uc")
        base.model.layers[i].load_state_dict(sd, strict=False)
    print(f"      wrapped {n_replaced} Linears across {n_layers} layers (rank={rank})")
    base = base.to(device)
    base.train(False)

    print(f"\n[4/4] running real inference (Sipsa-compressed substrate)...")
    print(f"      prompt: {prompt!r}")
    inputs = tok(prompt, return_tensors="pt").to(device)
    t_gen = time.time()
    with torch.no_grad():
        out = base.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
            pad_token_id=tok.pad_token_id,
        )
    gen_dt = time.time() - t_gen
    n_gen = int(out.shape[1] - inputs["input_ids"].shape[1])
    text = tok.decode(out[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)

    print()
    print("=" * 64)
    print(f"prompt_tokens:     {int(inputs['input_ids'].shape[1])}")
    print(f"completion_tokens: {n_gen}")
    print(f"speed:             {n_gen/gen_dt:.1f} tok/s  on  {device}")
    print(f"total_elapsed:     {time.time()-t0:.1f}s")
    print()
    print("text:")
    print(text)
    print("=" * 64)
    print(f"\n✓ Sipsa-compressed inference works on your machine — PPL ratio = {ppl_ratio}")
    _hint_next()
    return 0
