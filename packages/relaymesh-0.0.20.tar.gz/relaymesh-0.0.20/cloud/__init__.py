"""Generated proto package namespace."""
