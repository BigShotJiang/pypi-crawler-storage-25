"""Generated githook proto definitions."""
