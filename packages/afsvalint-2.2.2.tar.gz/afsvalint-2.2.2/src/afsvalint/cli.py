# ----------------------------------------------------
# SPDX-FileCopyrightText: AsFigo Technologies, UK
# SPDX-FileCopyrightText: VerifWorks, India
# SPDX-License-Identifier: MIT
# ----------------------------------------------------
'''
import sys
import os
import argparse
# Add the 'src' directory to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

import logging
import verible_verilog_syntax
from ..af_lint_rule import AsFigoLintRule
from asfigo_linter import AsFigoLinter
from afsvalint.rules.af_asrt_no_label import MissingLabelChk
from afsvalint.rules.af_perf_no_pass_ablk import PerfNoPABlk
from afsvalint.rules.af_no_timeliteral import NoExplTimeLiterals
from afsvalint.rules.af_no_within_oper import NoWithinOperInAsrt
from afsvalint.rules.af_no_fmatch_oper import NoFirstMatchOperInAsrt
from afsvalint.rules.af_no_range_ant import NoRangeInAntAsrt
from afsvalint.rules.af_perf_no_ub_range_ant import NoUBRangeInAntAsrt
from afsvalint.rules.af_func_missing_fablk import FuncMissingFABLK
from afsvalint.rules.af_missing_elbl_prop import MissingEndLblProp
from afsvalint.rules.af_missing_elbl_seq import MissingEndLblSEQ
from afsvalint.rules.af_prop_naming import PropNaming
from afsvalint.rules.af_perf_missing_impl_oper import MissingImplicationOper
from afsvalint.rules.af_perf_no_large_del import NoLargeDelayProp
from afsvalint.rules.af_use_simple_cnseq import UseSimpleExprConseq
from afsvalint.rules.af_no_dollar_time import UseRealTimeVsTime
from afsvalint.rules.af_func_cov_nolap import FuncNOLAPInCoverProp 
from afsvalint.rules.af_func_cov_olap import FuncOLAPInCoverProp 
from afsvalint.rules.af_reuse_fa_one_liner import ReuseNoOneLinerFABLK 
from afsvalint.rules.af_func_no_ub_in_cnseq import NoUBRangeInConseqAsrt 
from afsvalint.rules.af_asrt_naming import AssertNaming
from afsvalint.rules.af_no_aa_exists_sva import AvoidAAExistsSVA
from afsvalint.rules.af_no_pop_back_sva import AvoidPopBkSVA
from afsvalint.rules.af_no_pop_front_sva import AvoidPopFrSVA
from afsvalint.rules.af_assume_naming import AssumeNaming
from afsvalint.rules.af_cover_naming import CoverNaming

class SVALinter(AsFigoLinter):
    """Linter that applies multiple rules on SVA code"""

    def __init__(self, configFile, logLevel=logging.INFO):
        super().__init__(configFile=configFile, logLevel=logLevel)
        # Automatically discover and register all subclasses of AsFigoLintRule
        self.rules = [rule_cls(self) for rule_cls in AsFigoLintRule.__subclasses__()]

    def loadSyntaxTree(self):
        """Loads Verilog syntax tree using VeribleVerilogSyntax."""
        parser = verible_verilog_syntax.VeribleVerilogSyntax()
        return parser.parse_files([self.testName], options={"gen_tree": True})

    def runLinter(self):
        """Runs all registered lint rules on the Verilog file."""
        treeData = self.loadSyntaxTree()

        for filePath, fileData in treeData.items():
            self.logInfo("SVALint", f"Loaded test file: {self.testName}")
            
            for rule in self.rules:
                rule.run(filePath, fileData)

            self.logSummary()


def main():
    byolDemo = SVALinter(configFile="config.toml", logLevel=logging.INFO)
    byolDemo.runLinter()

if __name__ == "__main__":
    main()

def main():
    parser = argparse.ArgumentParser(description="Run SVALint linter")
    parser.add_argument("--config", default="config.toml", help="Path to config file")
    args = parser.parse_args()

    linter = SVALinter(configFile=args.config, logLevel=logging.INFO)
    linter.runLinter()
if __name__ == "__main__":
    main()

'''
import argparse
import logging
import sys

from . import verible_verilog_syntax
from .asfigo_linter import AsFigoLinter

# Import all rules
from afsvalint.rules.af_asrt_no_label import MissingLabelChk
from afsvalint.rules.af_perf_no_pass_ablk import PerfNoPABlk
from afsvalint.rules.af_no_timeliteral import NoExplTimeLiterals
from afsvalint.rules.af_no_within_oper import NoWithinOperInAsrt
from afsvalint.rules.af_no_fmatch_oper import NoFirstMatchOperInAsrt
from afsvalint.rules.af_no_range_ant import NoRangeInAntAsrt
from afsvalint.rules.af_perf_no_ub_range_ant import NoUBRangeInAntAsrt
from afsvalint.rules.af_func_missing_fablk import FuncMissingFABLK
from afsvalint.rules.af_missing_elbl_prop import MissingEndLblProp
from afsvalint.rules.af_missing_elbl_seq import MissingEndLblSEQ
from afsvalint.rules.af_prop_naming import PropNaming
from afsvalint.rules.af_perf_missing_impl_oper import MissingImplicationOper
from afsvalint.rules.af_perf_no_large_del import NoLargeDelayProp
from afsvalint.rules.af_use_simple_cnseq import UseSimpleExprConseq
from afsvalint.rules.af_no_dollar_time import UseRealTimeVsTime
from afsvalint.rules.af_func_cov_nolap import FuncNOLAPInCoverProp
from afsvalint.rules.af_func_cov_olap import FuncOLAPInCoverProp
from afsvalint.rules.af_reuse_fa_one_liner import ReuseNoOneLinerFABLK
from afsvalint.rules.af_func_no_ub_in_cnseq import NoUBRangeInConseqAsrt
from afsvalint.rules.af_asrt_naming import AssertNaming
from afsvalint.rules.af_no_aa_exists_sva import AvoidAAExistsSVA
from afsvalint.rules.af_assume_naming import AssumeNaming
from afsvalint.rules.af_cover_naming import CoverNaming
from afsvalint.rules.af_no_pop_back_sva import NoPopBackSVA
from afsvalint.rules.af_no_pop_front_sva import NoPopFrontSVA


def setup_logging(verbose: bool):
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s"
    )


def get_all_rules():
    """Instantiate and return all lint rules"""
    return [
        MissingLabelChk(),
        PerfNoPABlk(),
        NoExplTimeLiterals(),
        NoWithinOperInAsrt(),
        NoFirstMatchOperInAsrt(),
        NoRangeInAntAsrt(),
        NoUBRangeInAntAsrt(),
        FuncMissingFABLK(),
        MissingEndLblProp(),
        MissingEndLblSEQ(),
        PropNaming(),
        MissingImplicationOper(),
        NoLargeDelayProp(),
        UseSimpleExprConseq(),
        UseRealTimeVsTime(),
        FuncNOLAPInCoverProp(),
        FuncOLAPInCoverProp(),
        ReuseNoOneLinerFABLK(),
        NoUBRangeInConseqAsrt(),
        AssertNaming(),
        AvoidAAExistsSVA(),
        AssumeNaming(),
        CoverNaming(),
        NoPopBackSVA(),
        NoPopFrontSVA(),
    ]


def parse_args():
    parser = argparse.ArgumentParser(
        prog="svalint",
        description="SVA Linter (afsvalint)"
    )

    parser.add_argument(
        "file",
        help="Input SystemVerilog (.sv) file"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose/debug logging"
    )

    return parser.parse_args()


def main():
    args = parse_args()
    setup_logging(args.verbose)

    # Read file
    try:
        with open(args.file, "r") as f:
            code = f.read()
    except FileNotFoundError:
        logging.error(f"File not found: {args.file}")
        sys.exit(1)

    # Parse SV code
    try:
        syntax_tree = verible_verilog_syntax.parse_string(code)
    except AttributeError:
        logging.error("verible_verilog_syntax.parse_string() not found. Check implementation.")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Parsing failed: {e}")
        sys.exit(1)

    # Initialize linter
    linter = AsFigoLinter()

    # Register rules
    for rule in get_all_rules():
        linter.register_rule(rule)

    # Run linter
    try:
        results = linter.run(syntax_tree)
    except Exception as e:
        logging.error(f"Linter execution failed: {e}")
        sys.exit(1)

    # Print results
    if not results:
        print("No lint issues found ✅")
    else:
        for res in results:
            print(res)


if __name__ == "__main__":
    main()
