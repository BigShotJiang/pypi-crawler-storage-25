"""Tests for the Anthropic client plugin."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from space_evals.clients.base import Message
from space_evals_client_anthropic import AnthropicClient


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    return AnthropicClient(model="claude-sonnet-4-20250514")


class TestAnthropicClient:
    def test_reads_api_key_from_env(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        c = AnthropicClient(model="claude-sonnet-4-20250514")
        assert c.api_key == "sk-ant-test"

    def test_reads_custom_api_key_env(self, monkeypatch):
        monkeypatch.setenv("MY_KEY", "sk-custom")
        c = AnthropicClient(model="claude-sonnet-4-20250514", api_key_env="MY_KEY")
        assert c.api_key == "sk-custom"

    def test_missing_api_key_raises(self, monkeypatch):
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        with pytest.raises(KeyError):
            AnthropicClient(model="claude-sonnet-4-20250514")

    @pytest.mark.asyncio
    async def test_send_formats_messages(self, client):
        mock_text_block = MagicMock()
        mock_text_block.type = "text"
        mock_text_block.text = "Hello!"

        mock_response = MagicMock()
        mock_response.content = [mock_text_block]
        mock_response.model_dump.return_value = {"id": "test"}

        mock_async_client = AsyncMock()
        mock_async_client.messages.create = AsyncMock(return_value=mock_response)
        client._client = mock_async_client

        result = await client.send(
            messages=[Message(role="user", content="Hi")],
            system_prompt="Be helpful",
        )

        assert result.content == "Hello!"
        call_kwargs = mock_async_client.messages.create.call_args.kwargs
        assert call_kwargs["system"] == "Be helpful"
        assert call_kwargs["messages"] == [{"role": "user", "content": "Hi"}]

    @pytest.mark.asyncio
    async def test_send_extracts_tool_calls(self, client):
        mock_tool_block = MagicMock()
        mock_tool_block.type = "tool_use"
        mock_tool_block.name = "get_weather"
        mock_tool_block.input = {"city": "NYC"}

        mock_response = MagicMock()
        mock_response.content = [mock_tool_block]
        mock_response.model_dump.return_value = {}

        mock_async_client = AsyncMock()
        mock_async_client.messages.create = AsyncMock(return_value=mock_response)
        client._client = mock_async_client

        result = await client.send(messages=[Message(role="user", content="weather?")])

        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].tool_name == "get_weather"
        assert result.tool_calls[0].arguments == {"city": "NYC"}

    @pytest.mark.asyncio
    async def test_send_without_system_prompt(self, client):
        mock_text_block = MagicMock()
        mock_text_block.type = "text"
        mock_text_block.text = "Hi"

        mock_response = MagicMock()
        mock_response.content = [mock_text_block]
        mock_response.model_dump.return_value = {}

        mock_async_client = AsyncMock()
        mock_async_client.messages.create = AsyncMock(return_value=mock_response)
        client._client = mock_async_client

        await client.send(messages=[Message(role="user", content="Hi")])

        call_kwargs = mock_async_client.messages.create.call_args.kwargs
        assert "system" not in call_kwargs
