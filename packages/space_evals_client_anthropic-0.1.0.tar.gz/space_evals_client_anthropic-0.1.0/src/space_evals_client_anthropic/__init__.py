"""Anthropic client plugin for space-evals."""

from __future__ import annotations

import os
from typing import Any

from space_evals.clients.base import BaseClient, ClientResponse, Message
from space_evals.models.token_usage import TokenUsage
from space_evals.models.transcript import ToolCall


class AnthropicClient(BaseClient):
    def __init__(self, model: str, api_key_env: str | None = None, **params: Any) -> None:
        self.model = model
        self.api_key = os.environ[api_key_env or "ANTHROPIC_API_KEY"]
        self.params = params
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            from anthropic import AsyncAnthropic

            self._client = AsyncAnthropic(api_key=self.api_key)
        return self._client

    async def send(self, messages: list[Message], system_prompt: str = "") -> ClientResponse:
        client = self._get_client()

        api_messages: list[dict[str, str]] = []
        for msg in messages:
            api_messages.append({"role": msg.role, "content": msg.content})

        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": api_messages,
            "max_tokens": self.params.pop("max_tokens", 1024),
            **self.params,
        }
        if system_prompt:
            kwargs["system"] = system_prompt

        response = await client.messages.create(**kwargs)

        content = ""
        tool_calls: list[ToolCall] = []
        for block in response.content:
            if block.type == "text":
                content += block.text
            elif block.type == "tool_use":
                tool_calls.append(ToolCall(
                    tool_name=block.name,
                    arguments=block.input if isinstance(block.input, dict) else {},
                ))

        usage = None
        if response.usage:
            usage = TokenUsage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            )

        return ClientResponse(
            content=content,
            tool_calls=tool_calls,
            usage=usage,
            raw=response.model_dump(),
        )
