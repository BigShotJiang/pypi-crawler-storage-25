"""Command-line entry point for the ``claude-shop`` distribution.

The package exposes a single console script:

* ``claude-shop start TOKEN [-- claude args]`` - launch ``claude`` with
  ``ANTHROPIC_AUTH_TOKEN`` and ``ANTHROPIC_BASE_URL`` pointed at the
  claude.shop proxy.
* ``claude-shop check TOKEN`` - probe the proxy ``/health`` endpoint.
* ``claude-shop balance TOKEN`` - print remaining quota for a token.
* ``claude-shop --version`` - print package version.

We deliberately avoid third-party dependencies (argparse + urllib only) so the
package stays a fast ``pip install``.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from typing import Sequence

from . import __version__

PROXY_BASE_URL = "https://claudeshop.duckdns.org"
HEALTH_PATH = "/health"
BALANCE_PATH = "/api/users/balance/"
DEFAULT_CLAUDE_BIN = "claude"
HTTP_TIMEOUT_SECONDS = 10

TERMINAL_HINT = (
    "Run claude-shop in a system terminal (Windows: cmd.exe or PowerShell, "
    "macOS/Linux: Terminal/bash/zsh). Do NOT paste these commands into the "
    "Python REPL (the >>> prompt) — they are shell commands, not Python."
)


def _looks_like_python_repl() -> bool:
    """Heuristic: are we being run from inside a Python REPL?

    The console_script entry point sets ``sys.argv[0]`` to the wrapper path,
    but if the user pasted ``claude-shop ...`` into ``>>>`` the call never
    reaches us. The check below catches the closest cousin: ``python -m
    claude_shop`` invoked from inside an interactive interpreter via
    ``runpy``-like reentry, which leaves ``sys.ps1`` defined.
    """
    return hasattr(sys, "ps1")


def _claude_bin() -> str:
    """Allow advanced users to override the binary via env (e.g. for testing)."""
    return os.environ.get("CLAUDE_SHOP_CLAUDE_BIN", DEFAULT_CLAUDE_BIN)


def _mask_token(token: str) -> str:
    if len(token) <= 6:
        return "***"
    return f"...{token[-6:]}"


def _eprint(*parts: object) -> None:
    print(*parts, file=sys.stderr)


def _fmt_int(value: object) -> str:
    if isinstance(value, int):
        return f"{value:,}".replace(",", " ")
    return "—"


def cmd_start(args: argparse.Namespace) -> int:
    """Run the local ``claude`` binary with proxy env vars injected."""
    token = (args.token or "").strip()
    if not token:
        _eprint("claude-shop: error: empty token")
        return 2

    bin_name = _claude_bin()
    claude_path = shutil.which(bin_name)
    if claude_path is None:
        _eprint(
            f"claude-shop: error: {bin_name!r} not found on PATH. "
            "Install Claude Code first: "
            "https://docs.claude.com/en/docs/claude-code/install"
        )
        return 127

    env = os.environ.copy()
    env["ANTHROPIC_AUTH_TOKEN"] = token
    env["ANTHROPIC_BASE_URL"] = PROXY_BASE_URL

    extra = list(args.claude_args or [])
    _eprint(
        f"claude-shop: launching {bin_name} via {PROXY_BASE_URL} "
        f"(token {_mask_token(token)})"
    )

    try:
        completed = subprocess.run(
            [claude_path, *extra], env=env, check=False
        )
    except FileNotFoundError:
        _eprint(f"claude-shop: error: failed to spawn {claude_path!r}")
        return 127
    except KeyboardInterrupt:
        return 130
    return completed.returncode


def cmd_check(args: argparse.Namespace) -> int:
    """Probe ``GET <PROXY>/health`` and report reachability."""
    token = (args.token or "").strip()
    url = f"{PROXY_BASE_URL}{HEALTH_PATH}"
    req = urllib.request.Request(url, method="GET")
    req.add_header("User-Agent", f"claude-shop/{__version__}")

    try:
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT_SECONDS) as resp:
            status = resp.status
            body = resp.read(2048).decode("utf-8", errors="replace").strip()
    except urllib.error.HTTPError as exc:
        _eprint(f"claude-shop: HTTP {exc.code} from {url}")
        return 1
    except urllib.error.URLError as exc:
        _eprint(f"claude-shop: cannot reach {url}: {exc.reason}")
        return 1
    except TimeoutError:
        _eprint(f"claude-shop: timeout after {HTTP_TIMEOUT_SECONDS}s reaching {url}")
        return 1

    print(f"OK: proxy reachable at {url} (HTTP {status})")
    if body:
        print(body)
    if token:
        print(f"token: {_mask_token(token)}")
    return 0


def cmd_balance(args: argparse.Namespace) -> int:
    """Fetch the remaining quota for ``token`` from the proxy."""
    token = (args.token or "").strip()
    if not token:
        _eprint("claude-shop: error: empty token")
        return 2

    url = f"{PROXY_BASE_URL}{BALANCE_PATH}{token}"
    req = urllib.request.Request(url, method="GET")
    req.add_header("User-Agent", f"claude-shop/{__version__}")
    req.add_header("Accept", "application/json")

    try:
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT_SECONDS) as resp:
            body = resp.read(8192).decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            _eprint("claude-shop: token not found (was it deactivated?)")
            return 1
        _eprint(f"claude-shop: HTTP {exc.code} from {url}")
        return 1
    except urllib.error.URLError as exc:
        _eprint(f"claude-shop: cannot reach {url}: {exc.reason}")
        return 1
    except TimeoutError:
        _eprint(f"claude-shop: timeout after {HTTP_TIMEOUT_SECONDS}s reaching {url}")
        return 1

    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        _eprint(f"claude-shop: malformed response: {body[:200]}")
        return 1

    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    plan_type = data.get("plan_type") or "?"
    is_active = data.get("is_active")
    print(f"Token: {_mask_token(token)}")
    print(f"Plan: {plan_type}")
    print(f"Active: {'yes' if is_active else 'NO (limit reached or expired)'}")

    if plan_type == "tokens":
        used = data.get("tokens_used") or 0
        limit = data.get("token_limit") or 0
        remaining = data.get("tokens_remaining")
        if remaining is None and isinstance(limit, int):
            remaining = max(0, limit - used)
        print(f"Used:      {_fmt_int(used)} tokens")
        print(f"Limit:     {_fmt_int(limit)} tokens")
        print(f"Remaining: {_fmt_int(remaining)} tokens")
    elif plan_type == "days":
        print(f"Days limit:     {_fmt_int(data.get('days_limit'))}")
        print(f"Days remaining: {_fmt_int(data.get('days_remaining'))}")
        if data.get("expires_at"):
            print(f"Expires at: {data['expires_at']}")

    bonuses = data.get("bonuses") or []
    if bonuses:
        print(f"Bonuses applied: {', '.join(bonuses)}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="claude-shop",
        description=(
            "Launch Claude Code via the claude.shop proxy. "
            "IMPORTANT: claude-shop is a SHELL command, not Python code. "
            "Run it in your system terminal (cmd.exe / PowerShell on Windows, "
            "Terminal / bash / zsh on macOS / Linux), NOT in the Python REPL. "
            "Buy a token at https://claudeshop.duckdns.org and run "
            "`claude-shop start <token>`."
        ),
        epilog=TERMINAL_HINT,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    p_start = sub.add_parser(
        "start",
        help="run claude with the given proxy token",
        description=(
            "Inject ANTHROPIC_AUTH_TOKEN and ANTHROPIC_BASE_URL, then exec "
            "the local `claude` binary. Anything after TOKEN is forwarded to claude. "
            "Run this in a SHELL (cmd / PowerShell / bash), NOT the Python REPL."
        ),
    )
    p_start.add_argument("token", help="proxy access token")
    p_start.add_argument(
        "claude_args",
        nargs=argparse.REMAINDER,
        help="extra arguments passed through to the claude binary",
    )
    p_start.set_defaults(func=cmd_start)

    p_check = sub.add_parser(
        "check",
        help="probe the proxy /health endpoint",
        description=(
            "Issue GET <PROXY>/health to verify the proxy is reachable. "
            "Note: /health does not validate the token itself; full validation "
            "happens on the first real request when claude calls /v1/messages."
        ),
    )
    p_check.add_argument("token", help="proxy access token (printed masked)")
    p_check.set_defaults(func=cmd_check)

    p_balance = sub.add_parser(
        "balance",
        help="show remaining quota for a token",
        description=(
            "Fetch token usage and remaining quota from the proxy. "
            "Run this in a SHELL, not the Python REPL."
        ),
    )
    p_balance.add_argument("token", help="proxy access token")
    p_balance.add_argument(
        "--json",
        action="store_true",
        help="print the raw JSON response",
    )
    p_balance.set_defaults(func=cmd_balance)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    if _looks_like_python_repl():
        _eprint(
            "claude-shop: looks like you're running this from the Python REPL.\n"
            f"  {TERMINAL_HINT}"
        )
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
