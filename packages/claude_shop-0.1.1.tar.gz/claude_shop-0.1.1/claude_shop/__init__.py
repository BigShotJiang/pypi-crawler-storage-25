"""claude-shop: CLI launcher for Claude Code via the claude.shop proxy."""

__version__ = "0.1.1"

__all__ = ["__version__"]
