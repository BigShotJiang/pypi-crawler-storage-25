"""Entry point for ``python -m claude_shop``."""

from claude_shop.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
