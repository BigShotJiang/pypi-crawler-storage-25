# claude-shop

A tiny CLI launcher for [Claude Code](https://docs.claude.com/en/docs/claude-code) that
points it at the [claude.shop](https://claudeshop.duckdns.org) proxy. Buy a token,
install one Python package, and start coding.

> **Run `claude-shop` in a SYSTEM TERMINAL — not the Python REPL.**
> On Windows that means `cmd.exe` or PowerShell. On macOS / Linux that's
> Terminal / bash / zsh. Pasting `claude-shop ...` after the `>>>` Python prompt
> will give you `SyntaxError: invalid syntax` because it's a shell command,
> not Python code.

## Install

```bash
pip install claude-shop
```

You also need the `claude` binary on your `PATH` — install it via the
[official Claude Code instructions](https://docs.claude.com/en/docs/claude-code/install).

## Usage

```bash
# Launch Claude Code through the proxy
claude-shop start <YOUR_TOKEN>

# Forward extra args to claude
claude-shop start <YOUR_TOKEN> --resume
claude-shop start <YOUR_TOKEN> -p "explain this repo"

# Check remaining quota for a token
claude-shop balance <YOUR_TOKEN>
claude-shop balance <YOUR_TOKEN> --json

# Verify the proxy is reachable
claude-shop check <YOUR_TOKEN>

# Show version
claude-shop --version
```

`python -m claude_shop` is also supported and behaves identically to the
`claude-shop` console script.

`start` injects two environment variables for the spawned `claude` process and
inherits everything else from your shell:

| Variable | Value |
| --- | --- |
| `ANTHROPIC_AUTH_TOKEN` | your token |
| `ANTHROPIC_BASE_URL` | `https://claudeshop.duckdns.org` |

The exit code of `claude` is propagated. `Ctrl-C` returns `130` as usual.

## How it works

`claude-shop start` is a thin wrapper:

1. Looks up `claude` on `PATH` (or the binary named in `CLAUDE_SHOP_CLAUDE_BIN`).
2. Builds an env dict from your current environment plus the two proxy variables.
3. Runs `claude` via `subprocess.run`, passing through any extra arguments.

`claude-shop balance` issues `GET https://claudeshop.duckdns.org/api/users/balance/<token>`
and prints how much quota is left on your token.

`claude-shop check` issues `GET https://claudeshop.duckdns.org/health` so you can
quickly tell whether the proxy is up. Token validity itself is checked by the
proxy when `claude` makes its first request.

## Buying a token

Tokens are sold on FunPay; see the storefront at
[claudeshop.duckdns.org](https://claudeshop.duckdns.org).

## License

MIT.
