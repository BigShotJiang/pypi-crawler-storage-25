# RFC #113 — Cross-Harness Smoke Test (manual)

This is the P5 fact-check from issue #113. `pretorin mcp-smoke-test` proves the handlers behave correctly **in-process**. This note tells the next session how to test whether **real agents on real harnesses** behave correctly.

Run twice: once in Claude Code, once in Codex. (Cursor + vanilla Agents SDK are bonus.) Compare.

---

## Setup (per harness, once)

From this checkout (master, after commit `ef91d80`):

```bash
uv pip install -e ".[dev]"               # install the dev build with the RFC #113 code
uv run pretorin mcp-smoke-test            # baseline: must show "PASSED"
pretorin skill install                    # installs skill into target harness (auto-detects)
```

Wire the MCP server entry in the harness to run `pretorin mcp-serve`. Capture stderr so you can see `PRETORIN_TELEMETRY_EVENT` lines.

Run each scenario from a **fresh session** (no prior context window). Vary the active CLI context (`pretorin context show`) per the scenario's preconditions.

---

## Scenarios

### S1 — Cold-start grounding

**Preconditions:** authenticated, active context set.
**Prompt:** *"What systems do I have configured?"*

**Pass:** agent calls `check_context` first (per the FIRST CALL section of the `instructions` block), then `list_systems`.
**Fail:** agent brute-forces straight into `list_systems` (means the `instructions` block isn't being read).

**Record:** ordered list of tools called.

---

### S2 — Errors-as-instructions

**Preconditions:** authenticated, **no active context** (`pretorin context clear`).
**Prompt:** *"Create an evidence record for AC-2 on prod saying we ran a vuln scan."*

**Pass:** `create_evidence` returns the structured `recipe_required` payload → agent reads it, calls `start_task` with `intent_verb=collect_evidence`, checks sources/recipes, opens a recipe context, then retries the write with `recipe_context_id`.
**Fail:** agent surfaces the error to the user verbatim and stops, or retries blindly without `start_task` / `start_recipe`.

**Record:** full tool-call sequence, whether the agent followed the `recipe_gap.suggested_next` field, whether it eventually succeeded.

This is the load-bearing test for the whole RFC.

---

### S3 — Discovery

**Preconditions:** authenticated, any context.
**Prompt:** *"What can you do with pretorin?"*

**Pass:** agent calls `list_tools` and/or `get_instructions` and answers from the compact payload.
**Fail:** agent dumps every tool's full schema (inflates context) or fabricates an answer from memory.

**Record:** which discovery tool(s) called, approximate output tokens.

---

### S4 — Workflow schema bundling (the P5 question)

**Preconditions:** authenticated, active context.
**Prompt:** *"Walk me through documenting a single control. Use the single-control workflow."*

**Pass:** agent calls `start_task` → `get_workflow` (id=`single-control`) → reads the bundled `required_tool_schemas` directly from the response. No follow-up schema-fetch chain.
**Soft pass:** agent reads `required_tool_schemas` as reference data and uses tools it already had registered.
**Fail:** agent ignores the bundled schemas and does a separate `ToolSearch` / schema-fetch round trip for each tool referenced in the workflow body.

**Record:** tool-call sequence after `get_workflow`. Specifically: any extra schema/tool-discovery calls between `get_workflow` and the first workflow-tool invocation. *This is the data that tells us whether to invest in dynamic-registration semantics or stay with read-as-data.*

---

## Comparison template

Fill in after each run:

| Scenario | Claude Code | Codex | Cursor | Vanilla SDK |
|----------|-------------|-------|--------|-------------|
| S1 | pass / fail + sequence | | | |
| S2 | pass / fail + sequence | | | |
| S3 | pass / fail + sequence | | | |
| S4 | pass / soft / fail | | | |

## Telemetry sanity check

After running all four scenarios, grep the captured stderr:

```bash
grep PRETORIN_TELEMETRY_EVENT <captured-stderr-log>
```

You should see at least:
- 1+ `start_task_succeeded` event (from S4).
- 1+ `start_task_succeeded` event (from S2 if the agent follows the
  `recipe_required` instruction path).
- 1+ `recipe_required` event from the initial S2 producer-write attempt.

`workflow_routing_required` now belongs to non-recipe workflow writes that
miss scope context. Evidence/narrative producer writes without
`recipe_context_id` return `recipe_required` before scope resolution, so S2 is
no longer expected to emit that bypass telemetry event.

If S2 produced no `recipe_required` event, the structured recipe guardrail did not fire — investigate before trusting any other result.

---

## What to do with the results

- If S2 passes on Claude Code but fails on Codex → errors-as-instructions reach Claude but not Codex. The structured-payload format is right; we need to inspect how Codex surfaces tool errors to the model.
- If S4 hard-passes on Claude Code but soft-passes elsewhere → ship phase 0-2 as-is and don't invest in dynamic-registration. Read-as-data is sufficient.
- If S1 fails everywhere except Claude Code → confirms RFC premise that the `instructions` block doesn't reach most harnesses, which means `check_context` only gets called via errors-as-instructions (S2) — making S2 even more load-bearing.

Update the active trigger-watch issue (currently #121) with the comparison table after both runs. That data feeds the capability-negotiation/default-surface decision.
