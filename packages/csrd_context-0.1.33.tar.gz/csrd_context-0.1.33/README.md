# csrd-context

Request context, header utilities, and logging middleware for FastAPI.

**Package**: `csrd.context` · **Import**: `from csrd.context import ...`

## What's included

- Framework-agnostic context variable system (headers, path params, query params, API version)
- `RequestContextMiddleware` — captures request headers into context (raw ASGI, streaming-safe)
- `HTTPLoggingMiddleware` — structured HTTP request/response logging (raw ASGI, streaming-safe)
- Platform context variables (`user_info_context`, `hit_id_context`, `app_id_context`)
- `get_headers()`, `get_hit_id()`, `get_app_id()` — accessors for the current request context

## Installation

This package is part of the `fastapi-common` monorepo. Install via git:

```bash
uv pip install "csrd-context @ git+ssh://git@github.com/csrd-api/fastapi-common.git#subdirectory=packages/context"
```

## Dependencies

- `csrd-models` (Tier 1 — no other `csrd.*` sibling dependencies)
