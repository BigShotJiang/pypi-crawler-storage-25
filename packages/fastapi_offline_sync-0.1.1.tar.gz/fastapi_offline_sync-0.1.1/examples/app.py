from __future__ import annotations

import os
from typing import Any
from fastapi import FastAPI, Depends, Header, HTTPException, status
from fastapi_offline_sync import SyncConfig, SyncRouter


async def verify_jwt_auth(
    authorization: str | None = Header(default=None),
) -> dict[str, str]:
    """Production JWT auth dependency.

    In a production application, this decodes and verifies a JWT token
    against an identity provider, extracting the user ID and tenant/business ID.
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing Authorization header",
        )
    
    token = authorization.removeprefix("Bearer ")
    # Decode and validate token here
    # Example decoded payload format:
    # return {"user_id": decoded["sub"], "business_id": decoded["tenant_id"]}
    
    # Placeholder return for request routing
    return {"user_id": "user-prod-123", "business_id": "business-prod-999"}


# Read configuration from the environment
mongodb_uri = os.getenv("MONGODB_URI", "mongodb://mongodb.internal:27017/?replicaSet=rs0")
database_name = os.getenv("DATABASE_NAME", "production_sync")
hlc_node_id = os.getenv("POD_NAME") or os.getenv("HOSTNAME")  # Ensures HLC uniqueness across replicas

# Instantiate production sync configuration
sync_config = SyncConfig(
    mongodb_uri=mongodb_uri,
    database_name=database_name,
    collections=("tasks", "inventory_items"),
    jwt_dependency=verify_jwt_auth,
    batch_atomic=True,
    use_transactions=True,
    hlc_node_id=hlc_node_id,
    metrics_enabled=True,
)

app = FastAPI(title="FastAPI Offline Sync Engine")

# Register the sync router
app.include_router(SyncRouter(sync_config))


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "healthy"}
