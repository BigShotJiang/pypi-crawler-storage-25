from fastapi import FastAPI
from fastapi.testclient import TestClient

from fastapi_offline_sync import SyncConfig, SyncRouter
from fastapi_offline_sync.exceptions import FullResyncRequired


def test_sync_router_registers_routes() -> None:
    app = FastAPI()
    router = SyncRouter(SyncConfig(mongodb_uri="mongodb://localhost:27017", database_name="test"))
    app.include_router(router)

    paths = {route.path for route in app.router.routes}

    assert "/sync/push" in paths
    assert "/sync/pull" in paths
    assert "/sync/full" in paths


def test_pull_endpoint_can_return_full_resync_signal() -> None:
    app = FastAPI()
    router = SyncRouter(SyncConfig(mongodb_uri="mongodb://localhost:27017", database_name="test"))

    async def fake_initialize() -> None:
        return None

    async def fake_pull(*, since: str, collections: list[str], limit: int, user: object):
        del since, limit, user
        raise FullResyncRequired(collections)

    router.service.initialize = fake_initialize  # type: ignore[method-assign]
    router.service.pull = fake_pull  # type: ignore[method-assign]
    app.include_router(router)

    with TestClient(app) as client:
        response = client.get("/sync/pull", params={"since": "20260502T120000.000Z-0001", "collections": "tasks"})

    assert response.status_code == 200
    assert response.json() == {"full_resync_required": True, "collections": ["tasks"]}


def test_router_uses_configured_auth_dependency_for_push() -> None:
    captured_users: list[object] = []

    def get_current_user() -> dict[str, str]:
        return {"user_id": "jwt-user"}

    app = FastAPI()
    router = SyncRouter(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            jwt_dependency=get_current_user,
        )
    )

    async def fake_initialize() -> None:
        return None

    async def fake_push(payload, user):
        del payload
        captured_users.append(user)
        return {"results": []}

    router.service.initialize = fake_initialize  # type: ignore[method-assign]
    router.service.push = fake_push  # type: ignore[method-assign]
    app.include_router(router)

    with TestClient(app) as client:
        response = client.post(
            "/sync/push",
            json={
                "client_id": "device-1",
                "changes": [
                    {
                        "collection": "tasks",
                        "operation": "upsert",
                        "doc_id": "task-1",
                        "data": {"title": "Buy milk"},
                        "parent_version": "20260502T120000.000Z-0001",
                    }
                ],
            },
        )

    assert response.status_code == 200
    assert captured_users == [{"user_id": "jwt-user"}]
