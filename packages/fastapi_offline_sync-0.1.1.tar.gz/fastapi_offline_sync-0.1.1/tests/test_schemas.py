import pytest
from pydantic import ValidationError

from fastapi_offline_sync.schemas import PushRequest, StreamSubscribeMessage


def test_push_request_requires_changes() -> None:
    with pytest.raises(ValidationError):
        PushRequest(client_id="device-1", changes=[])


def test_stream_subscription_requires_valid_type() -> None:
    with pytest.raises(ValidationError):
        StreamSubscribeMessage(type="invalid", since="20260502T120000.000Z-0001", collections=["tasks"])


def test_push_request_allows_empty_parent_version_for_first_write() -> None:
    request = PushRequest(
        client_id="device-1",
        changes=[
            {
                "collection": "tasks",
                "operation": "upsert",
                "doc_id": "task-1",
                "data": {"title": "first-write"},
                "parent_version": "",
            }
        ],
    )

    assert request.changes[0].parent_version is None
