from __future__ import annotations

import copy
import gzip
from contextlib import asynccontextmanager
from typing import Any

import pytest

from fastapi_offline_sync.config import CollectionPolicy, SyncCollectionConfig, SyncConfig
from fastapi_offline_sync.exceptions import FullResyncRequired
from fastapi_offline_sync.schemas import FullSyncQuery, PushRequest, StreamSubscribeMessage
from fastapi_offline_sync.service import SyncService


class FakeCursor:
    def __init__(self, documents: list[dict[str, Any]]) -> None:
        self._documents = documents
        self._index = 0

    def sort(self, field: str, direction: int) -> "FakeCursor":
        reverse = direction < 0
        self._documents.sort(key=lambda document: _get_value(document, field), reverse=reverse)
        return self

    def limit(self, count: int) -> "FakeCursor":
        self._documents = self._documents[:count]
        return self

    def __aiter__(self) -> "FakeCursor":
        self._index = 0
        return self

    async def __anext__(self) -> dict[str, Any]:
        if self._index >= len(self._documents):
            raise StopAsyncIteration
        document = copy.deepcopy(self._documents[self._index])
        self._index += 1
        return document


class FakeCollection:
    def __init__(self) -> None:
        self.store: dict[Any, dict[str, Any]] = {}

    async def find_one(self, query: dict[str, Any] | None = None, *, sort: list[tuple[str, int]] | None = None, session: Any = None):
        del session
        documents = [copy.deepcopy(document) for document in self.store.values() if _matches(document, query or {})]
        if sort:
            for field, direction in reversed(sort):
                documents.sort(key=lambda document: _get_value(document, field), reverse=direction < 0)
        return documents[0] if documents else None

    def find(self, query: dict[str, Any] | None = None) -> FakeCursor:
        documents = [copy.deepcopy(document) for document in self.store.values() if _matches(document, query or {})]
        return FakeCursor(documents)

    async def replace_one(self, query: dict[str, Any], replacement: dict[str, Any], *, upsert: bool = False, session: Any = None) -> None:
        del query, upsert, session
        self.store[replacement["_id"]] = copy.deepcopy(replacement)

    async def insert_one(self, document: dict[str, Any], *, session: Any = None) -> None:
        del session
        self.store[document["_id"]] = copy.deepcopy(document)

    async def create_index(self, *args: Any, **kwargs: Any) -> None:
        del args, kwargs
        return None


class FakeTransaction:
    def __init__(self, manager: "FakeMongoManager") -> None:
        self._manager = manager
        self._snapshot: dict[str, dict[Any, dict[str, Any]]] | None = None

    async def __aenter__(self) -> None:
        self._snapshot = self._manager.snapshot()

    async def __aexit__(self, exc_type, exc, tb) -> None:
        del exc, tb
        if exc_type is not None and self._snapshot is not None:
            self._manager.restore(self._snapshot)


class FakeSession:
    def __init__(self, manager: "FakeMongoManager") -> None:
        self._manager = manager

    def start_transaction(self) -> FakeTransaction:
        return FakeTransaction(self._manager)

    async def end_session(self) -> None:
        return None


class FakeWatchStream:
    def __init__(self, events: list[dict[str, Any]]) -> None:
        self._events = events
        self._index = 0

    def __aiter__(self) -> "FakeWatchStream":
        self._index = 0
        return self

    async def __anext__(self) -> dict[str, Any]:
        if self._index >= len(self._events):
            raise StopAsyncIteration
        event = copy.deepcopy(self._events[self._index])
        self._index += 1
        return event


class FakeMongoManager:
    def __init__(self) -> None:
        self._collections: dict[str, FakeCollection] = {"sync_oplog": FakeCollection()}
        self.watch_events: list[dict[str, Any]] = []

    @property
    def oplog(self) -> FakeCollection:
        return self._collections["sync_oplog"]

    def collection(self, name: str) -> FakeCollection:
        if name not in self._collections:
            self._collections[name] = FakeCollection()
        return self._collections[name]

    async def initialize(self) -> None:
        return None

    async def ensure_business_indexes(self, collection_name: str) -> None:
        self.collection(collection_name)

    async def estimate_oplog_size(self) -> int:
        return len(self.oplog.store)

    async def transaction(self) -> FakeSession:
        return FakeSession(self)

    def snapshot(self) -> dict[str, dict[Any, dict[str, Any]]]:
        return {name: copy.deepcopy(collection.store) for name, collection in self._collections.items()}

    def restore(self, snapshot: dict[str, dict[Any, dict[str, Any]]]) -> None:
        for name, documents in snapshot.items():
            self.collection(name).store = copy.deepcopy(documents)

    @asynccontextmanager
    async def watch_oplog(self, pipeline: list[dict[str, Any]], *, full_document: str = "updateLookup"):
        del full_document
        match = pipeline[0]["$match"] if pipeline else {}
        filtered_events = [event for event in self.watch_events if _matches(event, match)]
        yield FakeWatchStream(filtered_events)


def _get_value(document: dict[str, Any], field: str) -> Any:
    current: Any = document
    for part in field.split("."):
        if isinstance(current, dict):
            current = current.get(part)
        else:
            return None
    return current


def _matches(document: dict[str, Any], query: dict[str, Any]) -> bool:
    for key, expected in query.items():
        actual = _get_value(document, key)
        if isinstance(expected, dict):
            if "$gt" in expected and not (actual is not None and actual > expected["$gt"]):
                return False
            if "$in" in expected and actual not in expected["$in"]:
                return False
            if "$ne" in expected and actual == expected["$ne"]:
                return False
        elif actual != expected:
            return False
    return True


async def _read_stream(body) -> bytes:
    chunks = []
    async for chunk in body:
        chunks.append(chunk)
    return b"".join(chunks)


@pytest.mark.asyncio
async def test_custom_resolver_handles_version_conflict() -> None:
    manager = FakeMongoManager()
    manager.collection("tasks").store["task-1"] = {
        "_id": "task-1",
        "title": "old",
        "_sync_version": "20260502T120000.000Z-0005",
        "_sync_actor_id": "user-1",
        "_sync_scope_id": "user-1",
        "_sync_deleted": False,
    }
    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("tasks",),
            conflict_resolvers={
                "tasks": lambda collection, doc_id, current_doc, incoming_change, current_version, incoming_parent_version: {
                    "title": f"merged:{current_doc['title']}:{incoming_change['data']['title']}"
                }
            },
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    response = await service.push(
        PushRequest(
            client_id="device-1",
            changes=[
                {
                    "collection": "tasks",
                    "operation": "upsert",
                    "doc_id": "task-1",
                    "data": {"title": "new"},
                    "parent_version": "20260502T120000.000Z-0001",
                }
            ],
        ),
        user={"user_id": "user-1"},
    )

    assert response.results[0].status == "conflict_resolved"
    assert manager.collection("tasks").store["task-1"]["title"] == "merged:old:new"


@pytest.mark.asyncio
async def test_incoming_document_transform_can_enrich_pushed_documents() -> None:
    manager = FakeMongoManager()
    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("customers",),
            incoming_document_transform=lambda collection, document, user: {
                **(document or {}),
                "vendor_id": user["business_id"],
                "vendor": user["business_email"],
            } if collection == "customers" else document,
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    response = await service.push(
        PushRequest(
            client_id="device-1",
            changes=[
                {
                    "collection": "customers",
                    "operation": "upsert",
                    "doc_id": "offline-customer-1",
                    "data": {"name": "Ada", "email": "ada@example.com", "phone_no": "123", "address": "Lagos"},
                    "parent_version": None,
                }
            ],
        ),
        user={"user_id": "user-1", "business_id": "business-1", "business_email": "vendor@example.com"},
    )

    assert response.results[0].status == "accepted"
    assert manager.collection("customers").store["offline-customer-1"]["vendor_id"] == "business-1"
    assert manager.collection("customers").store["offline-customer-1"]["vendor"] == "vendor@example.com"


@pytest.mark.asyncio
async def test_batch_atomic_rolls_back_on_rejected_change() -> None:
    manager = FakeMongoManager()
    manager.collection("tasks").store["task-2"] = {
        "_id": "task-2",
        "title": "server",
        "_sync_version": "20260502T120000.000Z-0005",
        "_sync_actor_id": "user-1",
        "_sync_scope_id": "user-1",
        "_sync_deleted": False,
    }
    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("tasks",),
            batch_atomic=True,
            use_transactions=True,
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    response = await service.push(
        PushRequest(
            client_id="device-1",
            changes=[
                {
                    "collection": "tasks",
                    "operation": "upsert",
                    "doc_id": "task-1",
                    "data": {"title": "new doc"},
                    "parent_version": "20260502T120000.000Z-0001",
                },
                {
                    "collection": "tasks",
                    "operation": "upsert",
                    "doc_id": "task-2",
                    "data": {"title": "stale update"},
                    "parent_version": "20260502T120000.000Z-0001",
                },
            ],
        ),
        user={"user_id": "user-1"},
    )

    assert all(result.status == "rejected" for result in response.results)
    assert "task-1" not in manager.collection("tasks").store
    assert manager.collection("tasks").store["task-2"]["title"] == "server"


@pytest.mark.asyncio
async def test_pull_raises_full_resync_required_for_stale_cursor() -> None:
    manager = FakeMongoManager()
    manager.oplog.store["20260502T120000.000Z-0005"] = {
        "_id": "20260502T120000.000Z-0005",
        "collection": "tasks",
        "doc_id": "task-1",
        "operation": "upsert",
        "data": {"title": "server"},
        "actor_id": "user-1",
        "scope_id": "user-1",
        "parent_version": "20260502T120000.000Z-0004",
    }
    service = SyncService(
        SyncConfig(mongodb_uri="mongodb://localhost:27017", database_name="test", collections=("tasks",), metrics_enabled=False),
        mongo_manager=manager,
    )

    with pytest.raises(FullResyncRequired) as exc_info:
        await service.pull("20260502T120000.000Z-0001", ["tasks"], 100, {"user_id": "user-1"})

    assert exc_info.value.collections == ["tasks"]


@pytest.mark.asyncio
async def test_full_sync_streams_gzipped_ndjson_with_cursor() -> None:
    manager = FakeMongoManager()
    tasks = manager.collection("tasks")
    tasks.store["task-1"] = {
        "_id": "task-1",
        "title": "one",
        "_sync_version": "20260502T120000.000Z-0001",
        "_sync_actor_id": "user-1",
        "_sync_scope_id": "user-1",
        "_sync_deleted": False,
    }
    tasks.store["task-2"] = {
        "_id": "task-2",
        "title": "two",
        "_sync_version": "20260502T120000.000Z-0002",
        "_sync_actor_id": "user-1",
        "_sync_scope_id": "user-1",
        "_sync_deleted": False,
    }
    service = SyncService(
        SyncConfig(mongodb_uri="mongodb://localhost:27017", database_name="test", collections=("tasks",), metrics_enabled=False),
        mongo_manager=manager,
    )

    body, headers = await service.full_sync(FullSyncQuery(collections=["tasks"], limit=1), {"user_id": "user-1"})
    payload = gzip.decompress(await _read_stream(body)).decode("utf-8")

    assert '"doc_id":"task-1"' in payload
    assert headers["Content-Encoding"] == "gzip"
    assert "X-Sync-Cursor" in headers


@pytest.mark.asyncio
async def test_stream_changes_emits_backlog_then_live_event() -> None:
    manager = FakeMongoManager()
    manager.oplog.store["20260502T120000.000Z-0001"] = {
        "_id": "20260502T120000.000Z-0001",
        "collection": "tasks",
        "doc_id": "task-0",
        "operation": "upsert",
        "data": {"title": "seed"},
        "actor_id": "user-1",
        "scope_id": "user-1",
        "parent_version": None,
    }
    manager.oplog.store["20260502T120000.000Z-0002"] = {
        "_id": "20260502T120000.000Z-0002",
        "collection": "tasks",
        "doc_id": "task-1",
        "operation": "upsert",
        "data": {"title": "backlog"},
        "actor_id": "user-1",
        "scope_id": "user-1",
        "parent_version": "20260502T120000.000Z-0001",
    }
    manager.watch_events = [
        {
            "operationType": "insert",
            "fullDocument": {
                "_id": "20260502T120000.000Z-0003",
                "collection": "tasks",
                "doc_id": "task-2",
                "operation": "upsert",
                "data": {"title": "live"},
                "actor_id": "user-1",
                "scope_id": "user-1",
                "parent_version": "20260502T120000.000Z-0002",
            },
        }
    ]
    service = SyncService(
        SyncConfig(mongodb_uri="mongodb://localhost:27017", database_name="test", collections=("tasks",), metrics_enabled=False),
        mongo_manager=manager,
    )

    subscription = StreamSubscribeMessage(type="subscribe", since="20260502T120000.000Z-0001", collections=["tasks"])
    events = []
    async for event in service.stream_changes(subscription, {"user_id": "user-1"}):
        events.append(event)
        if len(events) == 2:
            break

    assert events[0]["doc_id"] == "task-1"
    assert events[1]["doc_id"] == "task-2"


@pytest.mark.asyncio
async def test_delete_update_policy_can_reject_resurrection() -> None:
    manager = FakeMongoManager()
    manager.collection("tasks").store["task-1"] = {
        "_id": "task-1",
        "_sync_version": "20260502T120000.000Z-0005",
        "_sync_actor_id": "user-1",
        "_sync_scope_id": "user-1",
        "_sync_deleted": True,
    }
    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collection_configs={
                "tasks": SyncCollectionConfig(name="tasks", policy=CollectionPolicy(delete_update_policy="reject_update"))
            },
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    response = await service.push(
        PushRequest(
            client_id="device-1",
            changes=[
                {
                    "collection": "tasks",
                    "operation": "upsert",
                    "doc_id": "task-1",
                    "data": {"title": "resurrect"},
                    "parent_version": "20260502T120000.000Z-0001",
                }
            ],
        ),
        user={"user_id": "user-1"},
    )

    assert response.results[0].status == "rejected"


@pytest.mark.asyncio
async def test_record_server_change_uses_actor_and_scope_metadata() -> None:
    manager = FakeMongoManager()
    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("tasks",),
            scope_id_field="business_id",
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    version = await service.record_server_change(
        collection="tasks",
        doc_id="task-1",
        operation="upsert",
        data={"title": "created-in-Fisco"},
        actor={"user_id": "user-1", "business_id": "business-1"},
        scope_id="business-1",
    )

    recorded = manager.oplog.store[version]
    assert recorded["actor_id"] == "user-1"
    assert recorded["scope_id"] == "business-1"
    assert recorded["doc_id"] == "task-1"


@pytest.mark.asyncio
async def test_business_scope_filters_pull_results_for_Fisco_style_users() -> None:
    manager = FakeMongoManager()
    manager.oplog.store["20260502T120000.000Z-0001"] = {
        "_id": "20260502T120000.000Z-0001",
        "collection": "tasks",
        "doc_id": "task-0",
        "operation": "upsert",
        "data": {"title": "seed"},
        "actor_id": "user-1",
        "scope_id": "business-1",
        "parent_version": None,
    }
    manager.oplog.store["20260502T120000.000Z-0002"] = {
        "_id": "20260502T120000.000Z-0002",
        "collection": "tasks",
        "doc_id": "task-1",
        "operation": "upsert",
        "data": {"title": "biz-one"},
        "actor_id": "user-1",
        "scope_id": "business-1",
        "parent_version": "20260502T120000.000Z-0001",
    }
    manager.oplog.store["20260502T120000.000Z-0003"] = {
        "_id": "20260502T120000.000Z-0003",
        "collection": "tasks",
        "doc_id": "task-2",
        "operation": "upsert",
        "data": {"title": "biz-two"},
        "actor_id": "user-2",
        "scope_id": "business-2",
        "parent_version": "20260502T120000.000Z-0002",
    }
    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("tasks",),
            scope_id_field="business_id",
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    response = await service.pull(
        since="20260502T120000.000Z-0001",
        collections=["tasks"],
        limit=100,
        user={"user_id": "user-1", "business_id": "business-1"},
    )

    assert [change.doc_id for change in response.changes] == ["task-1"]


@pytest.mark.asyncio
async def test_rejected_push_result_includes_server_version() -> None:
    """A client whose change is rejected due to conflict should receive the
    current server version so it can immediately pull the winning document."""
    manager = FakeMongoManager()
    current_server_version = "20260502T120000.000Z-0005"
    manager.collection("tasks").store["task-1"] = {
        "_id": "task-1",
        "title": "server-state",
        "_sync_version": current_server_version,
        "_sync_actor_id": "user-1",
        "_sync_scope_id": "user-1",
        "_sync_deleted": False,
    }
    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("tasks",),
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    response = await service.push(
        PushRequest(
            client_id="device-1",
            changes=[
                {
                    "collection": "tasks",
                    "operation": "upsert",
                    "doc_id": "task-1",
                    "data": {"title": "stale-client-update"},
                    # parent_version is older than the server's current version
                    "parent_version": "20260502T120000.000Z-0001",
                }
            ],
        ),
        user={"user_id": "user-1"},
    )

    result = response.results[0]
    assert result.status == "rejected"
    assert result.server_version == current_server_version, (
        "Client must receive the winning server version to pull from"
    )


@pytest.mark.asyncio
async def test_write_session_raises_transaction_unavailable_on_failure() -> None:
    """_write_session must raise TransactionUnavailable when the MongoDB session cannot start a transaction."""
    from pymongo.errors import OperationFailure

    from fastapi_offline_sync.exceptions import TransactionUnavailable

    manager = FakeMongoManager()

    class BrokenSession:
        """Simulates a session whose start_transaction().`__aenter__` raises."""

        def start_transaction(self):
            return self

        async def __aenter__(self):
            raise OperationFailure("not a replica set")

        async def __aexit__(self, *args):
            pass

        async def end_session(self):
            pass

    async def broken_transaction():
        return BrokenSession()

    manager.transaction = broken_transaction  # type: ignore[method-assign]

    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("tasks",),
            use_transactions=True,
            batch_atomic=True,
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    response = await service.push(
        PushRequest(
            client_id="device-1",
            changes=[
                {
                    "collection": "tasks",
                    "operation": "upsert",
                    "doc_id": "task-1",
                    "data": {"title": "new"},
                    "parent_version": None,
                }
            ],
        ),
        user={"user_id": "user-1"},
    )

    # All changes in the batch should be returned as rejected with a clear error
    assert all(r.status == "rejected" for r in response.results)
    assert any("replica set" in (r.error or "") for r in response.results)


@pytest.mark.asyncio
async def test_full_sync_includes_tombstone_for_deleted_document() -> None:
    """A client doing a full resync must be told about documents that were
    soft-deleted so it can remove them from its local store."""
    import gzip

    import json

    manager = FakeMongoManager()
    tasks = manager.collection("tasks")
    tasks.store["task-alive"] = {
        "_id": "task-alive",
        "title": "still here",
        "_sync_version": "20260502T120000.000Z-0001",
        "_sync_actor_id": "user-1",
        "_sync_scope_id": "user-1",
        "_sync_deleted": False,
    }
    tasks.store["task-dead"] = {
        "_id": "task-dead",
        "_sync_version": "20260502T120000.000Z-0002",
        "_sync_actor_id": "user-1",
        "_sync_scope_id": "user-1",
        "_sync_deleted": True,
    }
    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("tasks",),
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    body, headers = await service.full_sync(
        FullSyncQuery(collections=["tasks"], limit=100),
        {"user_id": "user-1"},
    )
    raw = gzip.decompress(await _read_stream(body)).decode("utf-8")
    records = [json.loads(line) for line in raw.strip().splitlines()]

    doc_ids = {r["doc_id"] for r in records}
    assert "task-alive" in doc_ids, "Live document must be included"
    assert "task-dead" in doc_ids, "Deleted document must be included as a tombstone"

    dead = next(r for r in records if r["doc_id"] == "task-dead")
    assert dead["deleted"] is True
    assert dead["data"] is None, "Tombstone data must be null"

    alive = next(r for r in records if r["doc_id"] == "task-alive")
    assert alive["deleted"] is False
    assert alive["data"] is not None


@pytest.mark.asyncio
async def test_stream_changes_pipeline_does_not_contain_id_filter() -> None:
    """The Change Stream pipeline must not include a fullDocument._id $gt filter."""
    captured_pipelines: list[list[dict]] = []

    manager = FakeMongoManager()
    manager.oplog.store["20260502T120000.000Z-0001"] = {
        "_id": "20260502T120000.000Z-0001",
        "collection": "tasks",
        "doc_id": "task-seed",
        "operation": "upsert",
        "data": {"title": "seed"},
        "actor_id": "user-1",
        "scope_id": "user-1",
        "parent_version": None,
    }

    original_watch = manager.watch_oplog

    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def capturing_watch(pipeline, *, full_document="updateLookup"):
        captured_pipelines.append(pipeline)
        async with original_watch(pipeline, full_document=full_document) as stream:
            yield stream

    manager.watch_oplog = capturing_watch  # type: ignore[method-assign]

    service = SyncService(
        SyncConfig(
            mongodb_uri="mongodb://localhost:27017",
            database_name="test",
            collections=("tasks",),
            metrics_enabled=False,
        ),
        mongo_manager=manager,
    )

    subscription = StreamSubscribeMessage(type="subscribe", since="20260502T120000.000Z-0001", collections=["tasks"])
    events = []
    async for event in service.stream_changes(subscription, {"user_id": "user-1"}):
        events.append(event)

    assert captured_pipelines, "watch_oplog must have been called"
    match_stage = captured_pipelines[0][0]["$match"]
    assert "fullDocument._id" not in match_stage, (
        "Invalid fullDocument._id filter must not appear in the Change Stream pipeline"
    )
