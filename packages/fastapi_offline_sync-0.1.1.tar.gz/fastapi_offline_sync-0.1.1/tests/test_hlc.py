from fastapi_offline_sync.hlc import HybridLogicalClock, validate_hlc


def test_hlc_now_generates_valid_values() -> None:
    clock = HybridLogicalClock()

    value = clock.now()

    assert validate_hlc(value) == value


def test_hlc_compare_orders_values_lexicographically() -> None:
    older = "20260502T120000.000Z-0001"
    newer = "20260502T120000.000Z-0002"

    assert HybridLogicalClock.compare(older, newer) == -1
    assert HybridLogicalClock.compare(newer, older) == 1
    assert HybridLogicalClock.compare(older, older) == 0


def test_hlc_node_id_is_appended_to_generated_values() -> None:
    """Each worker's clock should embed a unique node ID in the HLC string."""
    clock = HybridLogicalClock(node_id="abcd")

    value = clock.now()

    # Format: <timestamp>-<counter>-<node_id>
    parts = value.split("-")
    assert len(parts) == 3
    assert parts[2] == "abcd"


def test_hlc_without_node_id_produces_two_part_string() -> None:
    """Legacy format (no node ID) must still be produced when node_id is None."""
    clock = HybridLogicalClock(node_id=None)

    value = clock.now()

    parts = value.split("-")
    assert len(parts) == 2


def test_validate_hlc_accepts_two_part_legacy_format() -> None:
    legacy = "20260502T120000.000Z-0001"

    assert validate_hlc(legacy) == legacy


def test_validate_hlc_accepts_three_part_node_aware_format() -> None:
    node_aware = "20260502T120000.000Z-0001-a3f2"

    assert validate_hlc(node_aware) == node_aware


def test_validate_hlc_rejects_malformed_values() -> None:
    import pytest

    with pytest.raises(ValueError):
        validate_hlc("not-a-valid-hlc")


def test_hlc_compare_ignores_node_id_suffix() -> None:
    """Two HLC values that differ only in node_id should compare as equal."""
    left = "20260502T120000.000Z-0001-aaaa"
    right = "20260502T120000.000Z-0001-bbbb"

    assert HybridLogicalClock.compare(left, right) == 0


def test_derive_node_id_returns_four_hex_chars() -> None:
    node_id = HybridLogicalClock.derive_node_id()

    assert len(node_id) == 4
    assert all(c in "0123456789abcdef" for c in node_id)
