Here’s the **Client‑Side PRD** for the `@fisco/sync-client` package, the front‑end counterpart to the server‑side engine.

---

# Product Requirements Document  
## `@fisco/sync-client` (Client‑Side Package)

| Version | Date       | Author        | Status     |
|---------|------------|---------------|------------|
| 1.1     | 2026-05-02 | Fisco Team    | Draft      |

---

## 1. Introduction

### 1.1 Purpose  
`@fisco/sync-client` is a TypeScript library that enables React and React Native applications to operate fully offline while keeping data synchronised with a FastAPI backend running the `fastapi-offline-sync` server package. It provides a unified sync client, a local database abstraction, persistent offline queue, conflict handling, and React hooks for seamless integration.

### 1.2 Problem Statement  
Mobile and web apps in regions with intermittent connectivity require a client that can:
- Store data locally and allow full CRUD operations without network access.
- Track all user changes while offline and replay them accurately.
- Reconcile local edits with remote changes using the server’s conflict resolution.
- Provide a real‑time sync stream when online.
- Do all of the above efficiently on low‑power devices and slow networks.

Existing solutions either lock developers into specific cloud services (Firebase, Realm’s deprecated sync), or are heavily tied to Node.js backends. This package completes the Fisco Offline Sync Engine for FastAPI + MongoDB stacks.

### 1.3 Target Audience  
- Frontend developers using React (web) or React Native (mobile) building offline‑first apps on top of FastAPI backends.
- Contributors to the open‑source Fisco sync ecosystem.

### 1.4 Current Server Contract Alignment
This PRD is aligned to the current `fastapi-offline-sync` package contract in this repository.

- `POST /sync/push` returns per-change `accepted`, `conflict_resolved`, or `rejected` statuses.
- `POST /sync/push` now accepts `parent_version` as either a valid HLC string or `null`; an empty string is normalized to `null` server-side for first-write/bootstrap flows.
- `GET /sync/pull` returns change records with a top-level `version` and `last_seq`.
- `GET /sync/full` returns gzipped NDJSON records with `collection`, `doc_id`, and `data`, plus `X-Sync-LastSeq` and optional `X-Sync-Cursor` headers.
- `WS /sync/stream` accepts one initial `subscribe` message and does not support in-place subscription updates; clients must reconnect if the observed collection set changes.
- `WS /sync/stream` subscription payloads may now include an optional `scope_id` for scoped backends such as Fisco, where sync visibility is business-scoped rather than globally user-scoped.
- Full-resync records do not currently include a per-document sync version, so the client must maintain document version metadata when available from incremental pull or successful local push, and fall back to the global `last_seen_version` after full resync.

### 1.5 Contract Changes Since Last Review

The following contract changes were introduced after the previous client PRD review and should be reflected in the client implementation:

- `parent_version` is now nullable in push payloads.
  - Clients may send `null` for first-write/bootstrap mutations when no document-level or global sync version is available.
  - The server also tolerates `""` and normalizes it to `null`, but the client should prefer sending `null` explicitly.
- WebSocket subscribe payloads now support optional `scope_id`.
  - For business-scoped backends like Fisco, the client should include the currently selected `business_id` as `scope_id` when opening `/sync/stream`.
  - If the selected sync scope changes, the client should reconnect with the new `scope_id` as part of the fresh subscribe payload.
- There is no change to pull/full response shapes from the last review.
  - Incremental pull still provides per-change `version` plus top-level `last_seq`.
  - Full resync still does not provide per-document sync versions in imported records.

---

## 2. Project Goals

1. **Offline‑first data access**: all reads and writes work against a local store, without any network dependency.
2. **Automatic sync**: seamlessly push local changes and pull remote changes when connectivity allows.
3. **Cross‑platform**: a single core written in TypeScript, with swappable storage adapters for web (IndexedDB) and mobile (SQLite).
4. **React integration**: idiomatic React context providers and hooks (`useSyncedCollection`, `useOfflineStatus`).
5. **Battery & bandwidth friendly**: batches changes, minimises data transfer (delta sync), and uses WebSockets only when the app is active.
6. **Conflict‑aware**: surfaces conflicts to the developer via hooks/callbacks, but generally defers resolution to the server.
7. **Extensible**: clear adapter interface so the community can add support for other local databases (e.g., RxDB, Realm).

---

## 3. Scope

### In Scope
- Core `SyncClient` class managing push/pull/stream logic.
- Outbound change queue with persistent storage, retry logic, and backoff.
- Local database abstraction (`ILocalStore`) and two initial adapters:
  - `DexieLocalStore` for web (IndexedDB via Dexie.js).
  - `WatermelonLocalStore` for React Native (WatermelonDB/SQLite).
- `SyncProvider` and React hooks:
  - `useSyncedCollection(collectionName, query?)`
  - `useOfflineStatus()`
  - `usePendingChanges()`
  - `useSyncClient()` (low‑level access).
- Ability to apply incoming changes (pull data) to local store.
- Automatic detection of network state (online/offline) and synchronisation triggering.
- Configuration for:
  - Sync interval (when online)
  - Push/pull batch sizes
  - Conflict callback
- TypeScript types generated from the server’s OpenAPI spec for push/pull payloads (optional, but recommended).

### Out of Scope
- Peer‑to‑peer sync.
- All‑client‑side conflict resolution (server authority).
- Full text search, complex queries (left to the adapter’s native capabilities).
- Native iOS/Android bridges (React Native only; Expo support wherever possible).

---

## 4. Functional Requirements

### FR1 – `SyncClient` Core

**FR1.1** The `SyncClient` is a singleton (or context‑scoped) class that coordinates all sync activities. It is constructed with:
- `localStore: ILocalStore`
- `serverUrl: string`
- `authTokenProvider: () => Promise<string>`
- `options?: SyncClientOptions` (batch sizes, intervals, conflict handler).

**FR1.2** On initialisation, the client inspects the local store for any pending outbound changes and begins the sync cycle if the network is available.

**FR1.3** The client must maintain two crucial pieces of state persisted in the local store:
- `last_seen_version`: the latest HLC version received from the server (for subsequent pulls).
- `outbound_queue`: a table of unsent local changes.

The client should also persist a best-effort per-document sync metadata record, keyed by `{collection, doc_id}`, containing the latest known server version for that document when available. This metadata is updated from successful push responses and incremental pull records. After full resync, this metadata may be unavailable for imported documents until a later pull or local mutation refreshes it.

**FR1.4** The client exposes a method to perform a local mutation:
```ts
await client.mutate({
  collection: 'tasks',
  operation: 'upsert', // or 'delete'
  docId: 'task1',
  data: { title: 'Buy milk', done: false }
});
```
This method:
1. Immediately applies the change to the local store (optimistic update).
2. Resolves `parent_version` using this precedence:
  - the locally stored per-document sync version, if known;
  - otherwise the global `last_seen_version`;
  - otherwise `null` for a first-write/bootstrap mutation.
3. Records the change in the outbound queue with that `parent_version`.
4. Returns a promise that resolves once the local write is committed (not waiting for server sync).

**FR1.5** The client provides a method to query data locally:
```ts
const tasks = await client.query('tasks', { where: { status: 'open' } });
```
This queries the local store directly, with the adapter’s query syntax.

### FR2 – Outbound Queue (Push Logic)

**FR2.1** The outbound queue is stored in a dedicated table/collection in the local store, with fields:
- `id: string` (uuid)
- `collection: string`
- `doc_id: string`
- `operation: 'upsert' | 'delete'`
- `data: any` (null for delete)
- `parent_version: string | null` (HLC when known, otherwise `null`)
- `created_at: string` (ISO)
- `status: 'pending' | 'conflicted'`
- `retries: number` (default 0)
- `last_error?: string`

**FR2.2** When the network becomes available (detected via `navigator.onLine` / NetInfo), or at a configurable interval (default 30 seconds), the client:
1. Reads up to `batchSize` (default 50) pending items from the queue, oldest first.
2. Constructs a `POST /sync/push` request with the batch.
3. Sends the request with the current auth token.
4. On success, parses the response:
  - For each `status: 'accepted' | 'conflict_resolved'`: remove the corresponding queue item and update local per-document sync metadata using the returned `new_version`.
  - For each `status: 'rejected'`: mark the queue item as `"conflicted"` and call the optional `onConflict` callback supplied by the developer.
5. On network/server error, increments `retries` and schedules a retry with exponential backoff (base 500ms, max 30s, jitter). The queue entry stays until it is successfully pushed or manually dismissed.

**FR2.3** The current server contract does not return `full_resync_required` from `POST /sync/push`. Full resync is triggered only by `GET /sync/pull` or `WS /sync/stream`.

### FR3 – Pulling Remote Changes

**FR3.1** The client pulls new changes:
- Automatically after a successful push.
- Periodically at the configured `pullInterval` (default 5 minutes) when online and not already pulling.
- When the WebSocket stream delivers a change (already applied, but pull can catch up if connection drops).

**FR3.2** Pull request: `GET /sync/pull?since=<last_seen_version>&collections=<subscribed collections>&limit=100`.

**FR3.3** On receiving a successful pull response:
1. The client applies each change to the local store in order. Each change includes a complete snapshot of the document (for upsert) or a delete marker.
2. The client updates its `last_seen_version` to the returned `last_seq`.
3. The client updates per-document sync metadata using each change record’s `version`.
4. If a change affects a document that exists in the outbound queue with a higher parent version, the queue item might still be valid (the server resolved it). The client does **not** remove queue items based on pulls; only the push response can remove them.

**FR3.4** If the server responds with `full_resync_required: true`, the client enters the full resync flow (FR4).

**FR3.5** The pull must be atomic to the local store: either all changes are applied, or none (to avoid partial updates). Use a local transaction if the adapter supports it; otherwise, implement a batch with rollback logic.

### FR4 – Full Resync Fallback

**FR4.1** The full resync flow is triggered automatically when a pull returns `full_resync_required`, or manually by the developer (e.g., for a “force sync” button).

**FR4.2** Steps:
1. The client pauses the normal sync cycle.
2. It attempts to push all remaining pending changes (may fail, but we try).
3. Then it calls `GET /sync/full?collections=...` (may be chunked via cursor).
4. The client imports each page into a staging area or equivalent temporary write set. It must **not** clear the main collections before the import is complete.
5. The most recent `X-Sync-Cursor` is persisted after each successful page so the flow can resume after interruption.
6. When the final page is received, the client replaces the target collections atomically if the adapter supports transactions. If not, it must perform `clear + bulkPut` inside the smallest recoverable critical section available.
7. It updates `last_seen_version` to the header `X-Sync-LastSeq`.
8. Because full-resync records do not include per-document sync versions in the current server contract, imported documents are considered to have unknown document-level version metadata until a later incremental pull or successful local push refreshes them.
9. The outbound queue is **not** cleared – it still contains changes that may have been attempted but not yet acknowledged. After the full resync, the normal push is retried.
10. The normal sync cycle resumes.

**FR4.3** The full resync state must be reflected in the React hooks (`useOfflineStatus` can indicate “resyncing”).

### FR5 – WebSocket Real‑Time Stream

**FR5.1** If the developer enables `useWebSocket: true`, the client establishes a WebSocket connection to the server’s `/sync/stream` endpoint after authentication.

**FR5.2** The client sends a subscription message with the current `since` version, the list of collections the app is observing, and an optional `scope_id` when the backend requires scoped sync visibility. If the observed collection set changes while the socket is open, or if the selected sync scope changes, the client reconnects and sends a fresh subscribe message with the updated collection list and scope.

**FR5.3** On receiving a change frame, the client immediately applies it to the local store (upsert/delete) and updates `last_seen_version`. This provides near‑instant updates when the app is online, without waiting for the next poll.

**FR5.4** The WebSocket connection is closed when the app goes to background (mobile) or tabs become inactive (web) to save battery. The client will fall back to periodic polling until the app is foregrounded again.

**FR5.5** Reconnection is automatic with exponential backoff. On reconnect, the client always resubscribes using the current `last_seen_version`; if the server responds with `full_resync_required`, the client falls back to the HTTP full resync flow.

### FR6 – Local Storage Adapter Interface

**FR6.1** The `ILocalStore` interface defines the contract for local data storage:

```ts
interface ILocalStore {
  // Basic CRUD
  get(collection: string, docId: string): Promise<any | null>;
  put(collection: string, docId: string, data: any): Promise<void>;
  delete(collection: string, docId: string): Promise<void>;
  
  // Queries (adapter-specific syntax, but minimum: list all)
  query(collection: string, predicate?: any): Promise<any[]>;
  
  // Outbound queue operations
  enqueueChange(change: QueueItem): Promise<void>;
  dequeueChange(id: string): Promise<void>;
  getPendingChanges(limit: number): Promise<QueueItem[]>;
  markChangeConflicted(id: string, error: string): Promise<void>;
  
  // Sync metadata
  getMeta(key: string): Promise<string | null>;
  setMeta(key: string, value: string): Promise<void>;
  getDocVersion(collection: string, docId: string): Promise<string | null>;
  setDocVersion(collection: string, docId: string, version: string): Promise<void>;
  
  // Bulk operations for pull/full resync
  clearCollection(collection: string): Promise<void>;
  bulkPut(collection: string, docs: { docId: string, data: any }[]): Promise<void>;

  // Reactivity and atomicity
  subscribe(collection: string, predicate: any, onChange: () => void): Promise<() => void>;
  runInTransaction<T>(work: () => Promise<T>): Promise<T>;
}
```

**FR6.2** The initial implementation must provide:
- **`DexieLocalStore`**: uses IndexedDB via Dexie.js. Collections are mapped to Dexie tables. All operations return promises.
- **`WatermelonLocalStore`**: uses WatermelonDB with two schemas: one for app data collections, one for sync queue. The store must also handle lazy loading and reactivity for hooks.

**FR6.3** Adapters are tree‑shakable. The consumer imports only the one they need.

**FR6.4** Full-resync staging may be implemented either with dedicated temporary tables/collections or with adapter-managed shadow state, but the adapter must ensure that an interrupted full resync does not leave the primary collection permanently empty.

### FR7 – React Integration

**FR7.1** `<SyncProvider>` must wrap the application and accept:
- `client: SyncClient` (already configured)
- `options?: { enableWebSocket?: boolean, ... }`

**FR7.2** Hooks provided:

- `useSyncedCollection<T>(collectionName: string, query?: object)`
  - Returns `{ data: T[], isLoading: boolean, error?: Error }`.
  - Subscribes to local store changes (re‑renders on pull/WS updates) and ensures the collection is included in the WebSocket subscription and pull filters.

- `useOfflineStatus()`
  - Returns `{ isOnline: boolean, pendingChanges: number, isResyncing: boolean }`.

- `usePendingChanges()`
  - Returns an array of pending `QueueItem` objects (read‑only) for UI feedback (e.g., “3 changes pending sync”).

- `useSyncClient()`
  - Returns the raw `SyncClient` instance for manual mutations or custom operations.

**FR7.3** The hooks must be efficient; data returned by `useSyncedCollection` should be memoised and only re‑render when the actual subset changes. WatermelonDB’s observables are leveraged on React Native; on web, Dexie’s live query or a simple poll‑with‑diff can be used.

---

## 5. Non‑Functional Requirements

### NFR1 – Performance
- Local reads: < 10 ms for simple queries on both platforms.
- Bulk insert of 500 documents (full resync): < 2 seconds.
- Sync client overhead: < 5% of main thread time.
- WebSocket heartbeat: every 30 seconds.

### NFR2 – Reliability
- Outbound queue must survive app restarts and crashes (persisted in local DB).
- Push/pull operations must be idempotent; the queue prevents duplicate submissions.
- Conflict callbacks must be invoked reliably; never silently drop a change.
- Full resync must be recoverable if interrupted, either by resuming from the last persisted cursor or by safely restarting the staged import without corrupting the main local dataset.

### NFR3 – Battery & Data Usage
- Sync only when app is foregrounded (use AppState on RN, visibility API on web).
- Batched push/pull; no chatty requests.
- WebSocket used only when actively subscribed; automatic disconnect when no listeners.
- Pull delta only; full resync as last resort.
- Compress requests with gzip when supported (for large pushes).

### NFR4 – Security
- Auth token provider is called on each request; tokens are never stored in the sync client (except in memory).
- Local data may be considered unencrypted (rely on device encryption); sensitive data handling is up to the application.

### NFR5 – Platform Support
- Web: modern browsers (Chrome, Firefox, Safari, Edge) with IndexedDB support.
- React Native: iOS 13+ and Android 6+, via WatermelonDB (SQLite) or potentially a simpler SQLite adapter for Expo.

### NFR6 – Developer Experience
- Package install via `npm install @fisco/sync-client dexie` (web) or `@fisco/sync-client @nozbe/watermelondb` (RN).
- Clear documentation with examples for both platforms.
- TypeScript definitions included.
- Minimal boilerplate to integrate:
```tsx
const localStore = new DexieLocalStore('myApp');
const client = new SyncClient({
  localStore,
  serverUrl: 'https://api.example.com',
  authTokenProvider: () => getAccessToken()
});

<SyncProvider client={client}>
  <App />
</SyncProvider>
```

---

## 6. Implementation Milestones (Client Only)

| Phase | Duration | Deliverables |
|-------|----------|--------------|
| **M1 – Core SyncClient** | 2 weeks | `SyncClient` class with push/pull/manual full resync logic, queue management, network detection, exponential backoff. |
| **M2 – ILocalStore & Dexie Adapter** | 2 weeks | Interface definition, `DexieLocalStore` implementation, outbound queue table, basic query support. |
| **M3 – React Integration & Hooks (Web)** | 2 weeks | `SyncProvider`, `useSyncedCollection`, `useOfflineStatus`, `usePendingChanges`. React demo app. |
| **M4 – React Native Adapter** | 3 weeks | `WatermelonLocalStore` or SQLite adapter, schema generation, integration with RN NetInfo and AppState, hooks compatibility. RN demo app. |
| **M5 – WebSocket & Real‑Time** | 2 weeks | WebSocket client with subscribe-on-connect, reconnect-based collection updates, heartbeat, reconnection, fallback to polling. |
| **M6 – Full Resync & Hardening** | 2 weeks | Full resync flow, conflict callback, error handling, performance tests on low‑end devices. |
| **M7 – Documentation & Release** | 1 week | Comprehensive docs, quickstart guides for both platforms, CI/CD publication to npm. |

---

## 7. Open Source & Community

- **License**: MIT.
- **Repository**: monorepo with `client/` directory under the Fisco sync engine project.
- **Contributing**: TypeScript strict mode, ESLint, Prettier, Jest tests, and platform‑specific integration tests (Puppeteer for web, Detox for RN).
- **Documentation**: Docusaurus site with live examples.
- **Community**: Discord channel shared with server package.

---

This client‑side PRD defines the complete scope for the `@fisco/sync-client` package, ensuring it pairs seamlessly with the server to deliver a full offline‑first experience. Would you like to go deeper into any adapter interface detail, or perhaps draft the developer guide or example application structure?