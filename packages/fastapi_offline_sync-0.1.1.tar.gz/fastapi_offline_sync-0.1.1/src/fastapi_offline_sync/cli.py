from __future__ import annotations

import argparse
import asyncio

from fastapi_offline_sync.config import SyncConfig
from fastapi_offline_sync.service import SyncService


async def _init_command(args: argparse.Namespace) -> None:
    config = SyncConfig(mongodb_uri=args.mongodb_uri, database_name=args.database_name)
    service = SyncService(config)
    await service.initialize()


def main() -> None:
    parser = argparse.ArgumentParser(prog="fastapi-offline-sync")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init")
    init_parser.add_argument("--mongodb-uri", required=True)
    init_parser.add_argument("--database-name", required=True)

    args = parser.parse_args()
    if args.command == "init":
        asyncio.run(_init_command(args))
