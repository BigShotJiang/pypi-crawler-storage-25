from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorCollection, AsyncIOMotorDatabase
from pymongo import ASCENDING, DESCENDING
from pymongo.errors import CollectionInvalid

from fastapi_offline_sync.config import SyncConfig


class MongoManager:
    def __init__(self, config: SyncConfig) -> None:
        self._config = config
        self._client = AsyncIOMotorClient(config.mongodb_uri)
        self._database = self._client[config.database_name]

    @property
    def database(self) -> AsyncIOMotorDatabase:
        return self._database

    @property
    def oplog(self) -> AsyncIOMotorCollection:
        return self._database[self._config.sync_oplog_collection]

    def collection(self, name: str) -> AsyncIOMotorCollection:
        return self._database[name]

    async def initialize(self) -> None:
        try:
            await self._database.create_collection(self._config.sync_oplog_collection)
        except CollectionInvalid:
            pass
        await self.oplog.create_index([("timestamp", ASCENDING)], expireAfterSeconds=self._config.oplog_ttl_days * 86400)
        await self.oplog.create_index([("scope_id", ASCENDING), ("collection", ASCENDING), ("_id", ASCENDING)])
        for collection_name in self._config.configured_collections():
            await self.ensure_business_indexes(collection_name)

    async def ensure_business_indexes(self, collection_name: str) -> None:
        collection = self.collection(collection_name)
        await collection.create_index([("_sync_scope_id", ASCENDING), ("_sync_deleted", ASCENDING), ("_id", ASCENDING)])
        await collection.create_index([("_sync_version", DESCENDING)])

    async def estimate_oplog_size(self) -> int:
        return await self.oplog.estimated_document_count()

    async def transaction(self):
        session = await self._client.start_session()
        return session

    @asynccontextmanager
    async def watch_oplog(self, pipeline: list[dict[str, Any]], *, full_document: str = "updateLookup"):
        async with self.oplog.watch(pipeline=pipeline, full_document=full_document) as stream:
            yield stream
