from __future__ import annotations

from fastapi_offline_sync.schemas.common import SyncModel


class FullSyncQuery(SyncModel):
    collections: list[str]
    cursor: str | None = None
    limit: int = 1000


class FullSyncRecord(SyncModel):
    collection: str
    doc_id: str | int
    data: dict[str, object] | None
    deleted: bool = False
    """True when this document was soft-deleted on the server.

    Clients should remove the record from their local store when they see
    ``deleted=True``.  ``data`` will be ``None`` for deleted records.
    """

