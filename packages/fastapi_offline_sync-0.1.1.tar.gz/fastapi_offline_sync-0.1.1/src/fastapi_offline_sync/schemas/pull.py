from __future__ import annotations

from pydantic import field_validator

from fastapi_offline_sync.hlc import validate_hlc
from fastapi_offline_sync.schemas.common import OplogEntry, SyncModel


class PullQuery(SyncModel):
    since: str
    collections: list[str] = []
    limit: int = 500

    @field_validator("since")
    @classmethod
    def validate_since(cls, value: str) -> str:
        return validate_hlc(value)

    @field_validator("limit")
    @classmethod
    def validate_limit(cls, value: int) -> int:
        if value < 1 or value > 1000:
            raise ValueError("limit must be between 1 and 1000")
        return value


class PullResponse(SyncModel):
    changes: list[OplogEntry]
    last_seq: str


class FullResyncRequiredResponse(SyncModel):
    full_resync_required: bool = True
    collections: list[str]
