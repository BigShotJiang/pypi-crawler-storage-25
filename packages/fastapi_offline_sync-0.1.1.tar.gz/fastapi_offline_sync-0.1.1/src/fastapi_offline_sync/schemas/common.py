from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from fastapi_offline_sync.hlc import validate_hlc


class SyncModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid")


class SyncChangePayload(SyncModel):
    collection: str
    operation: str
    doc_id: str | int = Field(serialization_alias="doc_id")
    data: dict[str, Any] | None = None
    parent_version: str | None = None

    @field_validator("operation")
    @classmethod
    def validate_operation(cls, value: str) -> str:
        if value not in {"upsert", "delete"}:
            raise ValueError("operation must be 'upsert' or 'delete'")
        return value

    @field_validator("parent_version")
    @classmethod
    def validate_parent_version(cls, value: str | None) -> str | None:
        if value in {None, ""}:
            return None
        return validate_hlc(value)


class OplogEntry(SyncModel):
    version: str
    collection: str
    doc_id: str | int
    operation: str
    data: dict[str, Any] | None
    parent_version: str | None = None
