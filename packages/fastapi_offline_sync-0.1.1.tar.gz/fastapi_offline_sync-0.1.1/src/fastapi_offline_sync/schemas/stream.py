from __future__ import annotations

from pydantic import field_validator

from fastapi_offline_sync.hlc import validate_hlc
from fastapi_offline_sync.schemas.common import SyncModel


class StreamSubscribeMessage(SyncModel):
    type: str
    since: str
    collections: list[str]
    scope_id: str | None = None

    @field_validator("type")
    @classmethod
    def validate_type(cls, value: str) -> str:
        if value != "subscribe":
            raise ValueError("type must be 'subscribe'")
        return value

    @field_validator("since")
    @classmethod
    def validate_since(cls, value: str) -> str:
        return validate_hlc(value)


class StreamControlMessage(SyncModel):
    type: str
    collections: list[str]
