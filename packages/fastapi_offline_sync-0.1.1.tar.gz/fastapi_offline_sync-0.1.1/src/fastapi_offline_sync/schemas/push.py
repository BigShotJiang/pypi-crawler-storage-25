from __future__ import annotations

from pydantic import field_validator

from fastapi_offline_sync.schemas.common import SyncChangePayload, SyncModel


class PushRequest(SyncModel):
    client_id: str
    changes: list[SyncChangePayload]

    @field_validator("changes")
    @classmethod
    def validate_changes(cls, value: list[SyncChangePayload]) -> list[SyncChangePayload]:
        if not value:
            raise ValueError("changes must not be empty")
        return value


class PushResult(SyncModel):
    doc_id: str | int
    status: str
    new_version: str | None = None
    server_version: str | None = None
    """The winning HLC version already on the server, populated on rejection.

    When a push is rejected due to a conflict the client should pull changes
    starting from ``server_version`` to reconcile its local state immediately,
    rather than waiting for the next scheduled sync cycle.
    """
    error: str | None = None



class PushResponse(SyncModel):
    results: list[PushResult]
