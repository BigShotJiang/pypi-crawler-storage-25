from __future__ import annotations

import asyncio
import base64
import logging
import zlib
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

from bson import ObjectId
from pymongo.errors import OperationFailure

from fastapi_offline_sync.config import SyncConfig
from fastapi_offline_sync.exceptions import AuthorizationDenied, ConflictRejection, FullResyncRequired, TransactionUnavailable
from fastapi_offline_sync.hlc import HybridLogicalClock
from fastapi_offline_sync.metrics import SyncMetrics, build_metrics
from fastapi_offline_sync.mongo import MongoManager
from fastapi_offline_sync.resolver import LastWriterWinsByHLC, ResolutionResult
from fastapi_offline_sync.schemas import FullSyncQuery, FullSyncRecord, OplogEntry, PullResponse, PushRequest, PushResponse, PushResult, StreamSubscribeMessage


logger = logging.getLogger(__name__)


class _BatchRejected(Exception):
    def __init__(self, results: list[PushResult]) -> None:
        super().__init__("Batch rejected")
        self.results = results



def _normalize_doc_id(doc_id: str | int) -> str | int | ObjectId:
    if isinstance(doc_id, str) and ObjectId.is_valid(doc_id):
        return ObjectId(doc_id)
    return doc_id


class SyncService:
    def __init__(self, config: SyncConfig, mongo_manager: MongoManager | None = None) -> None:
        self._config = config
        node_id = config.hlc_node_id or HybridLogicalClock.derive_node_id()
        self._clock = HybridLogicalClock(node_id=node_id)
        self._mongo = mongo_manager or MongoManager(config)
        self._resolver = LastWriterWinsByHLC()
        self._metrics: SyncMetrics | None = build_metrics() if config.metrics_enabled else None

    @property
    def metrics(self) -> SyncMetrics | None:
        return self._metrics

    async def initialize(self) -> None:
        await self._mongo.initialize()
        if self._metrics is not None:
            self._metrics.oplog_size.set(await self._mongo.estimate_oplog_size())

    async def push(self, payload: PushRequest, user: Any) -> PushResponse:
        identity = self._identity(user)
        if self._metrics is not None:
            self._metrics.push_changes_total.inc(len(payload.changes))

        if self._config.batch_atomic:
            try:
                async with self._write_session() as session:
                    results = await self._apply_batch(payload, user, identity, session=session)
            except TransactionUnavailable as exc:
                logger.error("sync_push_transaction_unavailable", extra={"error": str(exc)})
                if self._metrics is not None:
                    self._metrics.push_total.labels(status="failure").inc()
                return PushResponse(
                    results=[PushResult(doc_id=change.doc_id, status="rejected", error=str(exc)) for change in payload.changes]
                )
            except _BatchRejected as exc:
                # Transaction has already been rolled back by _write_session.
                # Return the individual results (which include server_version).
                logger.warning("sync_push_batch_rolled_back", extra={"error": exc.results[-1].error})
                if self._metrics is not None:
                    self._metrics.push_total.labels(status="failure").inc()
                
                # Mark all results as rejected because the batch was rolled back.
                results = []
                for change, result in zip(payload.changes, exc.results):
                    if result.status == "rejected":
                        results.append(result)
                    else:
                        results.append(
                            PushResult(
                                doc_id=change.doc_id,
                                status="rejected",
                                error="Batch rolled back",
                            )
                        )
                # Pad remaining changes as rejected too
                applied = len(exc.results)
                pending = [
                    PushResult(doc_id=change.doc_id, status="rejected", error="Batch rolled back")
                    for change in payload.changes[applied:]
                ]
                return PushResponse(results=results + pending)
            except (AuthorizationDenied, ValueError) as exc:
                logger.warning("sync_push_batch_rolled_back", extra={"error": str(exc)})
                if self._metrics is not None:
                    self._metrics.push_total.labels(status="failure").inc()
                return PushResponse(
                    results=[PushResult(doc_id=change.doc_id, status="rejected", error=str(exc)) for change in payload.changes]
                )
        else:
            results = []
            for change in payload.changes:
                try:
                    await self._authorize(user, change.collection)
                    result = await self._apply_change(change.model_dump(), identity, user=user)
                    results.append(result)
                except (ConflictRejection, AuthorizationDenied, ValueError) as exc:
                    logger.warning(
                        "sync_push_rejected",
                        extra={"collection": change.collection, "doc_id": change.doc_id, "error": str(exc)},
                    )
                    results.append(PushResult(doc_id=change.doc_id, status="rejected", error=str(exc)))

        if self._metrics is not None:
            status = "success" if all(result.status != "rejected" for result in results) else "failure"
            self._metrics.push_total.labels(status=status).inc()
        return PushResponse(results=results)

    async def pull(self, since: str, collections: list[str], limit: int, user: Any) -> PullResponse:
        identity = self._identity(user)
        requested_collections = self._requested_collections(collections)
        for collection in requested_collections:
            await self._authorize(user, collection)

        earliest = await self._mongo.oplog.find_one(
            self._oplog_query(since=None, collections=requested_collections, scope_id=identity["scope_id"]),
            sort=[("_id", 1)],
        )
        if earliest is not None and earliest["_id"] > since:
            raise FullResyncRequired(requested_collections)

        cursor = self._mongo.oplog.find(
            self._oplog_query(since=since, collections=requested_collections, scope_id=identity["scope_id"])
        ).sort("_id", 1).limit(limit)
        records = [self._map_oplog_entry(entry) async for entry in cursor]

        if self._metrics is not None:
            self._metrics.pull_total.inc()
            self._metrics.pull_changes_served.inc(len(records))

        last_seq = records[-1].version if records else since
        return PullResponse(changes=records, last_seq=last_seq)

    async def full_sync(self, query: FullSyncQuery, user: Any) -> tuple[AsyncIterator[bytes], dict[str, str]]:
        identity = self._identity(user)
        requested_collections = self._requested_collections(query.collections)
        for collection in requested_collections:
            await self._authorize(user, collection)
            if not self._config.full_resync_allowed_for(collection):
                raise AuthorizationDenied(f"Full resync disabled for collection: {collection}")

        limit = min(query.limit or self._config.default_full_limit, self._config.max_pull_limit)
        cursor_state = self._decode_cursor(query.cursor)
        latest_seq = await self._latest_version_for(scope_id=identity["scope_id"], collections=requested_collections)
        has_more = False
        remaining = limit
        start_index = cursor_state["collection_index"] if cursor_state is not None else 0
        records: list[FullSyncRecord] = []
        next_cursor_state: dict[str, Any] | None = None

        for index, collection_name in enumerate(requested_collections[start_index:], start=start_index):
            collection = self._mongo.collection(collection_name)
            # Include both active and soft-deleted documents.
            filter_query: dict[str, Any] = {"_sync_scope_id": identity["scope_id"]}
            if cursor_state is not None and index == cursor_state["collection_index"] and cursor_state["last_id"] is not None:
                filter_query["_id"] = {"$gt": _normalize_doc_id(cursor_state["last_id"])}
            cursor = collection.find(filter_query).sort("_id", 1).limit(remaining)
            async for document in cursor:
                is_deleted = bool(document.get("_sync_deleted"))
                records.append(
                    FullSyncRecord(
                        collection=collection_name,
                        doc_id=str(document.get("_id")),
                        data=None if is_deleted else self._strip_sync_fields(document),
                        deleted=is_deleted,
                    )
                )
                remaining -= 1
                next_cursor_state = {"collection_index": index, "last_id": str(document.get("_id"))}
                if remaining == 0:
                    has_more = True
                    break
            if remaining == 0:
                break

        async def stream() -> AsyncIterator[bytes]:
            compressor = zlib.compressobj(wbits=zlib.MAX_WBITS | 16)
            for record in records:
                chunk = compressor.compress((record.model_dump_json() + "\n").encode("utf-8"))
                if chunk:
                    yield chunk
            trailer = compressor.flush()
            if trailer:
                yield trailer

        headers = {
            "X-Sync-LastSeq": latest_seq,
            "Content-Type": "application/x-ndjson",
            "Content-Encoding": "gzip",
        }
        stream_body = stream()
        if self._metrics is not None:
            self._metrics.full_resync_total.inc()
        if has_more and next_cursor_state is not None:
            headers["X-Sync-Cursor"] = self._encode_cursor(next_cursor_state)
        elif cursor_state is not None and has_more:
            headers["X-Sync-Cursor"] = self._encode_cursor(cursor_state)
        return stream_body, headers

    async def stream_changes(self, subscription: StreamSubscribeMessage, user: Any) -> AsyncIterator[dict[str, Any]]:
        identity = self._identity(user)
        requested_collections = self._requested_collections(subscription.collections)
        for collection in requested_collections:
            await self._authorize(user, collection)

        earliest = await self._mongo.oplog.find_one(
            self._oplog_query(since=None, collections=requested_collections, scope_id=identity["scope_id"]),
            sort=[("_id", 1)],
        )
        if earliest is not None and earliest["_id"] > subscription.since:
            yield {"type": "full_resync_required", "collections": requested_collections}
            return

        backlog = await self.pull(
            since=subscription.since,
            collections=requested_collections,
            limit=self._config.max_pull_limit,
            user=user,
        )
        last_seq = subscription.since
        for entry in backlog.changes:
            last_seq = entry.version
            yield entry.model_dump()

        # Watch the oplog for new insertions matching the client's scope and collections.
        pipeline = [
            {
                "$match": {
                    "operationType": "insert",
                    "fullDocument.scope_id": identity["scope_id"],
                    "fullDocument.collection": {"$in": requested_collections},
                }
            }
        ]

        if self._metrics is not None:
            self._metrics.websocket_connections.inc()

        try:
            async with self._mongo.watch_oplog(pipeline=pipeline, full_document="updateLookup") as stream:
                async for change in stream:
                    entry = self._map_oplog_entry(change["fullDocument"])
                    yield entry.model_dump()
        finally:
            if self._metrics is not None:
                self._metrics.websocket_connections.dec()

    async def heartbeat(self) -> AsyncIterator[dict[str, str]]:
        while True:
            await asyncio.sleep(30)
            yield {"type": "ping"}

    async def _apply_batch(self, payload: PushRequest, user: Any, identity: dict[str, str], session: Any) -> list[PushResult]:
        results: list[PushResult] = []
        for change in payload.changes:
            try:
                await self._authorize(user, change.collection)
                result = await self._apply_change(change.model_dump(), identity, user=user, session=session)
                results.append(result)
                if result.status == "rejected":
                    # Raise to trigger transaction rollback, carrying the results.
                    raise _BatchRejected(results)
            except ConflictRejection as exc:
                results.append(PushResult(doc_id=change.doc_id, status="rejected", error=str(exc)))
                raise _BatchRejected(results)
        return results

    async def _apply_change(self, change: dict[str, Any], identity: dict[str, str], user: Any, session: Any = None) -> PushResult:
        if session is None:
            async with self._write_session() as managed_session:
                return await self._apply_change(change, identity, user=user, session=managed_session)

        new_version = self._clock.now()
        collection_name = change["collection"]
        collection = self._mongo.collection(collection_name)
        doc_key = _normalize_doc_id(change["doc_id"])
        await self._mongo.ensure_business_indexes(collection_name)

        current_doc = await collection.find_one({"_id": doc_key}, session=session)
        current_version = current_doc.get("_sync_version") if current_doc is not None else None

        status = "accepted"
        operation = change["operation"]
        document_to_store = change.get("data")

        if current_version is not None and current_version != change["parent_version"]:
            resolution = self._resolve_conflict(
                collection_name=collection_name,
                doc_id=change["doc_id"],
                current_doc=current_doc,
                incoming_change=change,
                current_version=current_version,
            )
            status = resolution.status
            operation = resolution.operation
            document_to_store = resolution.document
            if status == "rejected":
                if self._metrics is not None:
                    self._metrics.conflict_total.labels(collection=collection_name).inc()
                return PushResult(
                    doc_id=change["doc_id"],
                    status=status,
                    server_version=current_version,
                    error="Change superseded by newer version",
                )

        if operation == "delete":
            tombstone = self.build_sync_metadata(actor=identity["actor_id"], scope_id=identity["scope_id"], version=new_version)
            tombstone.update({"_id": doc_key, "_sync_deleted": True})
            await collection.replace_one({"_id": doc_key}, tombstone, upsert=True, session=session)
            oplog_data = None
        else:
            stored = await self._transform_incoming_document(collection_name, document_to_store, user)
            stored.update(self.build_sync_metadata(actor=identity["actor_id"], scope_id=identity["scope_id"], version=new_version))
            stored.update({"_id": doc_key, "_sync_deleted": False})
            await collection.replace_one({"_id": doc_key}, stored, upsert=True, session=session)
            oplog_data = self._strip_sync_fields(stored)

        await self.record_server_change(
            collection=collection_name,
            doc_id=change["doc_id"],
            operation=operation,
            data=oplog_data,
            actor=identity["actor_id"],
            scope_id=identity["scope_id"],
            parent_version=change["parent_version"],
            session=session,
            version=new_version,
        )

        if self._metrics is not None:
            if status == "conflict_resolved":
                self._metrics.conflict_total.labels(collection=collection_name).inc()
            self._metrics.oplog_size.set(await self._mongo.estimate_oplog_size())
        return PushResult(doc_id=change["doc_id"], status=status, new_version=new_version)

    def _resolve_conflict(
        self,
        *,
        collection_name: str,
        doc_id: str | int,
        current_doc: dict[str, Any] | None,
        incoming_change: dict[str, Any],
        current_version: str,
    ) -> ResolutionResult:
        policy = self._config.delete_update_policy_for(collection_name)
        if incoming_change["operation"] == "upsert" and current_doc is not None and current_doc.get("_sync_deleted"):
            if policy == "reject_update":
                raise ConflictRejection(f"Update rejected for deleted document: {doc_id}")
            if policy == "delete_wins":
                return ResolutionResult(document=None, operation="delete", status="rejected")

        custom_resolver = self._config.resolver_for(collection_name)
        if custom_resolver is not None:
            custom_document = custom_resolver(
                collection_name,
                doc_id,
                current_doc,
                incoming_change,
                current_version,
                incoming_change["parent_version"],
            )
            operation = "delete" if custom_document is None else incoming_change["operation"]
            return ResolutionResult(document=custom_document, operation=operation, status="conflict_resolved")

        return self._resolver.resolve(
            collection=collection_name,
            doc_id=doc_id,
            current_doc=current_doc,
            incoming_change=incoming_change,
            current_version=current_version,
            incoming_parent_version=incoming_change["parent_version"],
            delete_update_policy=policy,
        )

    async def _transform_incoming_document(self, collection: str, document: dict[str, Any] | None, user: Any) -> dict[str, Any]:
        payload = dict(document or {})
        transform = self._config.incoming_document_transform
        if transform is None:
            return payload

        transformed = transform(collection, payload, user)
        if asyncio.iscoroutine(transformed):
            transformed = await transformed
        if transformed is None:
            return payload
        return dict(transformed)

    async def _authorize(self, user: Any, collection: str) -> None:
        configured_collections = self._config.configured_collections()
        if configured_collections and collection not in configured_collections:
            raise AuthorizationDenied(f"Collection not configured: {collection}")

        callback = self._config.authorization_callback
        if callback is None:
            return

        allowed = callback(user, collection)
        if asyncio.iscoroutine(allowed):
            allowed = await allowed
        if not allowed:
            raise AuthorizationDenied(f"Access denied for collection: {collection}")

    def _requested_collections(self, collections: list[str]) -> list[str]:
        requested = [collection.strip() for collection in collections if collection.strip()]
        if requested:
            return requested
        return list(self._config.configured_collections())

    def _oplog_query(self, since: str | None, collections: list[str], scope_id: str) -> dict[str, Any]:
        query: dict[str, Any] = {"scope_id": scope_id}
        if since is not None:
            query["_id"] = {"$gt": since}
        if collections:
            query["collection"] = {"$in": collections}
        return query

    async def _latest_version_for(self, *, scope_id: str, collections: list[str]) -> str:
        latest = await self._mongo.oplog.find_one(
            self._oplog_query(since=None, collections=collections, scope_id=scope_id),
            sort=[("_id", -1)],
        )
        if latest is None:
            return self._clock.now()
        return str(latest["_id"])

    def build_sync_metadata(self, *, actor: Any, scope_id: str | None = None, version: str | None = None) -> dict[str, Any]:
        actor_id = str(actor) if isinstance(actor, str) else self._extract_identity_value(actor, self._config.actor_id_field, self._config.actor_id_resolver, label="actor_id")
        resolved_scope_id = scope_id or actor_id
        return {
            "_sync_version": version or self._clock.now(),
            "_sync_actor_id": actor_id,
            "_sync_scope_id": str(resolved_scope_id),
        }

    async def record_server_change(
        self,
        *,
        collection: str,
        doc_id: str | int,
        operation: str,
        data: dict[str, Any] | None,
        actor: Any,
        scope_id: str | None = None,
        parent_version: str | None = None,
        session: Any = None,
        version: str | None = None,
    ) -> str:
        resolved = self.build_sync_metadata(actor=actor, scope_id=scope_id, version=version)
        await self._mongo.oplog.insert_one(
            {
                "_id": resolved["_sync_version"],
                "timestamp": datetime.now(tz=timezone.utc),
                "collection": collection,
                "doc_id": doc_id,
                "operation": operation,
                "data": data,
                "actor_id": resolved["_sync_actor_id"],
                "scope_id": resolved["_sync_scope_id"],
                "parent_version": parent_version,
            },
            session=session,
        )
        if self._metrics is not None:
            self._metrics.oplog_size.set(await self._mongo.estimate_oplog_size())
        return str(resolved["_sync_version"])

    def _identity(self, user: Any) -> dict[str, str]:
        actor_id = self._extract_identity_value(user, self._config.actor_id_field, self._config.actor_id_resolver, label="actor_id")
        scope_id = self._extract_identity_value(user, self._config.scope_id_field, self._config.scope_id_resolver, label="scope_id")
        return {"actor_id": actor_id, "scope_id": scope_id}

    @staticmethod
    def _extract_identity_value(user: Any, field_name: str, resolver: Any, *, label: str) -> str:
        if resolver is not None:
            value = resolver(user)
        elif isinstance(user, dict):
            value = user.get(field_name)
        else:
            value = getattr(user, field_name, None)
        if value is None or value == "":
            raise ValueError(f"Authenticated user must provide {label}")
        return str(value)

    @staticmethod
    def _encode_cursor(cursor_state: dict[str, Any]) -> str:
        payload = f"{cursor_state['collection_index']}:{cursor_state['last_id'] or ''}"
        return base64.urlsafe_b64encode(payload.encode("utf-8")).decode("ascii")

    @staticmethod
    def _decode_cursor(cursor: str | None) -> dict[str, Any] | None:
        if not cursor:
            return None
        decoded = base64.urlsafe_b64decode(cursor.encode("ascii")).decode("utf-8")
        collection_index, last_id = decoded.split(":", maxsplit=1)
        return {"collection_index": int(collection_index), "last_id": last_id or None}

    @staticmethod
    def _strip_sync_fields(document: dict[str, Any]) -> dict[str, Any]:
        return {
            key: (str(value) if isinstance(value, ObjectId) else value)
            for key, value in document.items()
            if key not in {"_sync_version", "_sync_actor_id", "_sync_scope_id", "_sync_deleted"}
        }

    @staticmethod
    def _map_oplog_entry(entry: dict[str, Any]) -> OplogEntry:
        return OplogEntry(
            version=entry["_id"],
            collection=entry["collection"],
            doc_id=entry["doc_id"],
            operation=entry["operation"],
            data=entry.get("data"),
            parent_version=entry.get("parent_version"),
        )

    @asynccontextmanager
    async def _write_session(self):
        if not self._config.use_transactions:
            yield None
            return

        session = await self._mongo.transaction()
        transaction = session.start_transaction()
        try:
            await transaction.__aenter__()
        except OperationFailure as exc:
            await session.end_session()
            # Transactions are required to prevent partial commits when use_transactions is True.
            raise TransactionUnavailable(
                "MongoDB transactions are unavailable — ensure the server is "
                "part of a replica set, or set use_transactions=False in "
                "SyncConfig if you explicitly accept best-effort consistency."
            ) from exc

        try:
            yield session
        except Exception as exc:
            await transaction.__aexit__(type(exc), exc, exc.__traceback__)
            raise
        else:
            await transaction.__aexit__(None, None, None)
        finally:
            await session.end_session()
