from __future__ import annotations

import asyncio
import contextlib
from typing import Any, Callable, cast

from fastapi import APIRouter, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect, status
from fastapi.responses import StreamingResponse
from prometheus_fastapi_instrumentator import Instrumentator

from fastapi_offline_sync.config import SyncConfig
from fastapi_offline_sync.exceptions import AuthorizationDenied, FullResyncRequired
from fastapi_offline_sync.schemas import FullResyncRequiredResponse, FullSyncQuery, PullQuery, PullResponse, PushRequest, PushResponse, StreamSubscribeMessage
from fastapi_offline_sync.service import SyncService


def _noop_user(*, token: str | None = None) -> dict[str, str]:
    del token
    return {"user_id": "anonymous"}


class SyncRouter(APIRouter):
    def __init__(self, config: SyncConfig) -> None:
        self.config = config
        self.service = SyncService(config)
        dependency = config.jwt_dependency or _noop_user
        self._auth_dependency = dependency
        self._websocket_auth_dependency: Callable[..., Any] = cast(
            Callable[..., Any],
            config.websocket_identity_resolver or dependency,
        )

        super().__init__(prefix=config.sync_prefix, tags=["sync"])
        self.add_event_handler("startup", self.install)

        async def push_endpoint(payload: PushRequest, user: Any = Depends(dependency)) -> PushResponse:
            return await self._handle_push(payload, user)

        async def pull_endpoint(
            since: str,
            collections: str | None = None,
            limit: int = Query(default=config.default_pull_limit, ge=1, le=config.max_pull_limit),
            user: Any = Depends(dependency),
        ) -> PullResponse | FullResyncRequiredResponse:
            return await self._handle_pull(since=since, collections=collections, limit=limit, user=user)

        async def full_sync_endpoint(
            collections: str,
            cursor: str | None = None,
            limit: int = Query(default=config.default_full_limit, ge=1, le=config.max_pull_limit),
            user: Any = Depends(dependency),
        ) -> StreamingResponse:
            return await self._handle_full_sync(collections=collections, cursor=cursor, limit=limit, user=user)

        self.add_api_route("/push", push_endpoint, methods=["POST"], response_model=PushResponse)
        self.add_api_route("/pull", pull_endpoint, methods=["GET"], response_model=PullResponse | FullResyncRequiredResponse)
        self.add_api_route("/full", full_sync_endpoint, methods=["GET"])
        self.add_api_websocket_route("/stream", self.stream)

    async def install(self) -> None:
        await self.service.initialize()

    def instrument(self, app: Any) -> None:
        if not self.config.metrics_enabled:
            return
        Instrumentator().instrument(app).expose(app)

    async def _handle_push(self, payload: PushRequest, user: Any) -> PushResponse:
        try:
            return await self.service.push(payload, user)
        except AuthorizationDenied as exc:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc)) from exc

    async def _handle_pull(self, since: str, collections: str | None, limit: int, user: Any) -> PullResponse | FullResyncRequiredResponse:
        parsed = PullQuery(since=since, collections=collections.split(",") if collections else [], limit=limit)
        try:
            return await self.service.pull(since=parsed.since, collections=parsed.collections, limit=parsed.limit, user=user)
        except FullResyncRequired as exc:
            return FullResyncRequiredResponse(collections=exc.collections)
        except AuthorizationDenied as exc:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc)) from exc

    async def _handle_full_sync(self, collections: str, cursor: str | None, limit: int, user: Any) -> StreamingResponse:
        query = FullSyncQuery(collections=collections.split(","), cursor=cursor, limit=limit)
        try:
            body, headers = await self.service.full_sync(query, user)
        except AuthorizationDenied as exc:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc)) from exc
        return StreamingResponse(body, media_type="application/x-ndjson", headers=headers)

    async def stream(self, websocket: WebSocket) -> None:
        subscription_task: asyncio.Task[None] | None = None
        heartbeat_task: asyncio.Task[None] | None = None
        try:
            await websocket.accept()
            message = await websocket.receive_json()
            token = message.get("token") or websocket.query_params.get("token")
            scope_id = message.get("scope_id") or websocket.query_params.get("scope_id")
            user = await self._resolve_websocket_user(token, scope_id)
            payload = dict(message)
            payload.pop("token", None)
            subscription = StreamSubscribeMessage.model_validate(payload)

            async def forward_events() -> None:
                async for event in self.service.stream_changes(subscription, user):
                    await websocket.send_json(event)

            async def forward_heartbeat() -> None:
                async for ping in self.service.heartbeat():
                    await websocket.send_json(ping)

            subscription_task = asyncio.create_task(forward_events())
            heartbeat_task = asyncio.create_task(forward_heartbeat())
            done, pending = await asyncio.wait({subscription_task, heartbeat_task}, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                await task
            for task in pending:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        except (WebSocketDisconnect, AuthorizationDenied):
            return
        finally:
            if subscription_task is not None:
                subscription_task.cancel()
            if heartbeat_task is not None:
                heartbeat_task.cancel()
            with contextlib.suppress(RuntimeError):
                await websocket.close()

    async def _resolve_websocket_user(self, token: str | None, scope_id: str | None = None) -> Any:
        if token is not None or scope_id is not None:
            resolved = self._websocket_auth_dependency(token=token, scope_id=scope_id)
        else:
            resolved = self._websocket_auth_dependency()
        if asyncio.iscoroutine(resolved):
            return await resolved
        return resolved
