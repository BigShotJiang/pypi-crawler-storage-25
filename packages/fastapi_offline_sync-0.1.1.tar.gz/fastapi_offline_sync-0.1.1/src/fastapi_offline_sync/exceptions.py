class SyncError(Exception):
    """Base exception for sync engine failures."""


class ConflictRejection(SyncError):
    """Raised when a conflict resolver permanently rejects a change."""


class FullResyncRequired(SyncError):
    """Raised when the client's sequence is older than oplog retention."""

    def __init__(self, collections: list[str]) -> None:
        super().__init__("Full resync required")
        self.collections = collections


class AuthorizationDenied(SyncError):
    """Raised when a user is not authorized for a collection."""


class TransactionUnavailable(SyncError):
    """Raised when a MongoDB transaction cannot be started.

    This typically means the server is not part of a replica set.
    Transactions are required for atomic push operations; falling back to
    non-transactional writes risks partial commits that corrupt sync state.
    Set ``use_transactions=False`` in SyncConfig only if you explicitly accept
    best-effort consistency (not recommended for production).
    """
