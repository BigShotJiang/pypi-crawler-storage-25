from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from threading import Lock


def _derive_node_id() -> str:
    """Return a 4-character hex string derived from this machine's MAC address.

    Uses Python's ``uuid.getnode()`` which returns the MAC as an integer.
    Falls back gracefully if the MAC cannot be determined (uuid will make one
    up, which is still unique enough for our purposes).
    """
    mac = uuid.getnode()
    return format(mac & 0xFFFF, "04x")


def validate_hlc(value: str) -> str:
    """Validate an HLC string, accepting both 2-part and 3-part formats.

    2-part (legacy): ``20260502T143000.000Z-0001``
    3-part (node-aware): ``20260502T143000.000Z-0001-a3f2``
    """
    try:
        parts = value.split("-", maxsplit=2)
        if len(parts) not in (2, 3):
            raise ValueError("wrong number of parts")
        timestamp_part = parts[0]
        counter_part = parts[1]
        datetime.strptime(timestamp_part, "%Y%m%dT%H%M%S.%fZ")
        counter = int(counter_part)
    except ValueError as exc:
        raise ValueError(f"Invalid HLC value: {value}") from exc

    if counter < 0:
        raise ValueError(f"Invalid HLC counter: {value}")
    return value


@dataclass(slots=True)
class HLCState:
    last_timestamp: datetime = field(default_factory=lambda: datetime.fromtimestamp(0, tz=timezone.utc))
    counter: int = 0


class HybridLogicalClock:
    def __init__(self, node_id: str | None = None) -> None:
        self._lock = Lock()
        self._state = HLCState()
        self._node_id = node_id

    @staticmethod
    def derive_node_id() -> str:
        """Return a 4-char hex node ID derived from the local MAC address.

        Suitable for single-host multi-worker setups.  For multi-host
        deployments supply an explicit ``hlc_node_id`` in ``SyncConfig``
        (e.g. last 4 hex of the pod IP or a short UUID prefix).
        """
        return _derive_node_id()

    def now(self) -> str:
        with self._lock:
            current = datetime.now(tz=timezone.utc)
            if current > self._state.last_timestamp:
                self._state.last_timestamp = current
                self._state.counter = 0
            else:
                self._state.counter += 1

            return self._format(self._state.last_timestamp, self._state.counter, self._node_id)

    @staticmethod
    def compare(left: str, right: str) -> int:
        validate_hlc(left)
        validate_hlc(right)
        # Strip optional node_id suffix before comparing so that clocks from
        # different nodes with the same timestamp+counter are considered equal.
        left_core = "-".join(left.split("-", maxsplit=2)[:2])
        right_core = "-".join(right.split("-", maxsplit=2)[:2])
        if left_core == right_core:
            return 0
        return -1 if left_core < right_core else 1

    @staticmethod
    def _format(timestamp: datetime, counter: int, node_id: str | None) -> str:
        base = f"{timestamp.strftime('%Y%m%dT%H%M%S.%f')[:-3]}Z-{counter:04d}"
        if node_id:
            return f"{base}-{node_id}"
        return base
