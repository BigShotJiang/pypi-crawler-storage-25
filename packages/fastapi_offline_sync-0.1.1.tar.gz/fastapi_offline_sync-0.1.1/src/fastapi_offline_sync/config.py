from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


AuthorizationCallback = Callable[[Any, str], bool | Awaitable[bool]]
JWTDependency = Callable[..., Any]
WebSocketIdentityResolver = Callable[..., Any]
ConflictResolver = Callable[[str, Any, dict[str, Any] | None, dict[str, Any], str | None, str], dict[str, Any] | None]
IdentityResolver = Callable[[Any], str | None]
IncomingDocumentTransform = Callable[[str, dict[str, Any] | None, Any], dict[str, Any] | None | Awaitable[dict[str, Any] | None]]


@dataclass(slots=True)
class CollectionPolicy:
    delete_update_policy: str = "resurrect_on_update"

    def __post_init__(self) -> None:
        if self.delete_update_policy not in {"resurrect_on_update", "reject_update", "delete_wins"}:
            raise ValueError(f"Unsupported delete_update_policy: {self.delete_update_policy}")


@dataclass(slots=True)
class SyncCollectionConfig:
    name: str
    allow_full_resync: bool = True
    policy: CollectionPolicy = field(default_factory=CollectionPolicy)


class SyncConfig(BaseSettings):
    mongodb_uri: str
    database_name: str
    sync_prefix: str = "/sync"
    sync_oplog_collection: str = "sync_oplog"
    oplog_ttl_days: int = 30
    default_pull_limit: int = 500
    max_pull_limit: int = 1000
    default_full_limit: int = 1000
    collections: Sequence[str] = Field(default_factory=tuple)
    collection_configs: Mapping[str, SyncCollectionConfig] = Field(default_factory=dict)
    conflict_resolvers: Mapping[str, ConflictResolver] = Field(default_factory=dict)
    jwt_dependency: JWTDependency | None = None
    websocket_identity_resolver: WebSocketIdentityResolver | None = None
    authorization_callback: AuthorizationCallback | None = None
    incoming_document_transform: IncomingDocumentTransform | None = None
    actor_id_field: str = "user_id"
    scope_id_field: str = "user_id"
    actor_id_resolver: IdentityResolver | None = None
    scope_id_resolver: IdentityResolver | None = None
    batch_atomic: bool = True
    use_transactions: bool = True
    metrics_enabled: bool = True
    hlc_node_id: str | None = None
    """Optional node identifier appended to HLC timestamps (e.g. ``"a3f2"``).

    Set this to any short unique string per deployment unit (e.g. last 4 hex
    of the pod IP, a worker index, or a UUID prefix). When ``None`` the
    service will auto-derive a node ID from the local MAC address, which is
    sufficient for single-host setups.
    """

    model_config = SettingsConfigDict(
        env_prefix="FASTAPI_OFFLINE_SYNC_",
        arbitrary_types_allowed=True,
    )

    def configured_collections(self) -> tuple[str, ...]:
        if self.collections:
            return tuple(self.collections)
        return tuple(self.collection_configs.keys())

    def delete_update_policy_for(self, collection: str) -> str:
        collection_config = self.collection_configs.get(collection)
        if collection_config is None:
            return "resurrect_on_update"
        return collection_config.policy.delete_update_policy

    def full_resync_allowed_for(self, collection: str) -> bool:
        collection_config = self.collection_configs.get(collection)
        if collection_config is None:
            return True
        return collection_config.allow_full_resync

    def resolver_for(self, collection: str) -> ConflictResolver | None:
        return self.conflict_resolvers.get(collection)
