from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from fastapi_offline_sync.exceptions import ConflictRejection
from fastapi_offline_sync.hlc import HybridLogicalClock


@dataclass(slots=True)
class ResolutionResult:
    document: dict[str, Any] | None
    operation: str
    status: str


class LastWriterWinsByHLC:
    def resolve(
        self,
        *,
        collection: str,
        doc_id: str | int,
        current_doc: dict[str, Any] | None,
        incoming_change: dict[str, Any],
        current_version: str | None,
        incoming_parent_version: str,
        delete_update_policy: str,
    ) -> ResolutionResult:
        del collection

        if current_doc is None or current_version is None:
            return ResolutionResult(
                document=incoming_change.get("data"),
                operation=incoming_change["operation"],
                status="accepted",
            )

        if incoming_change["operation"] == "upsert" and current_doc.get("_sync_deleted"):
            if delete_update_policy == "reject_update":
                raise ConflictRejection(f"Update rejected for deleted document: {doc_id}")
            if delete_update_policy == "delete_wins":
                return ResolutionResult(document=None, operation="delete", status="rejected")

        comparison = HybridLogicalClock.compare(incoming_parent_version, current_version)
        if comparison >= 0:
            return ResolutionResult(
                document=incoming_change.get("data"),
                operation=incoming_change["operation"],
                status="conflict_resolved",
            )

        tie_break = str(doc_id)
        if incoming_parent_version == current_version and tie_break <= str(doc_id):
            return ResolutionResult(
                document=incoming_change.get("data"),
                operation=incoming_change["operation"],
                status="conflict_resolved",
            )

        return ResolutionResult(
            document=current_doc,
            operation="upsert" if not current_doc.get("_sync_deleted") else "delete",
            status="rejected",
        )
