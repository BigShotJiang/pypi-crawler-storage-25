from __future__ import annotations

from dataclasses import dataclass
from typing import Final

from prometheus_client import Counter, Gauge


@dataclass(slots=True)
class SyncMetrics:
    push_total: Counter
    push_changes_total: Counter
    conflict_total: Counter
    pull_total: Counter
    pull_changes_served: Counter
    full_resync_total: Counter
    oplog_size: Gauge
    websocket_connections: Gauge


_METRICS: SyncMetrics | None = None


def build_metrics() -> SyncMetrics:
    global _METRICS

    if _METRICS is None:
        _METRICS = SyncMetrics(
            push_total=Counter("sync_push_total", "Push requests", labelnames=("status",)),
            push_changes_total=Counter("sync_push_changes_total", "Changes pushed"),
            conflict_total=Counter("sync_conflict_total", "Conflicts detected", labelnames=("collection",)),
            pull_total=Counter("sync_pull_total", "Pull requests"),
            pull_changes_served=Counter("sync_pull_changes_served", "Changes served from pull"),
            full_resync_total=Counter("sync_full_resync_total", "Full resync requests"),
            oplog_size=Gauge("sync_oplog_size", "Estimated oplog document count"),
            websocket_connections=Gauge("sync_websocket_connections", "Active websocket connections"),
        )

    return _METRICS
