from __future__ import annotations

import logging
import runpy
import sys
from pathlib import Path
from typing import Any, AsyncIterator, Callable

from minimal_harness.tool.base import StreamingTool
from minimal_harness.tool.registry import ToolRegistry

logger = logging.getLogger(__name__)


def _make_register_tool(
    captured_tools: list[StreamingTool],
) -> Callable[..., Callable[..., Any]]:
    def register_tool(
        name: str | None = None,
        description: str | None = None,
        parameters: dict | None = None,
    ) -> Callable[..., Callable[..., Any]]:
        def decorator(
            fn: Callable[..., AsyncIterator[Any]],
        ) -> Callable[..., AsyncIterator[Any]]:
            tool_name = name or fn.__name__
            tool_description = description or (fn.__doc__ or "").strip()
            tool_params = parameters or {}
            captured_tools.append(
                StreamingTool(
                    name=tool_name,
                    description=tool_description,
                    parameters=tool_params,
                    fn=fn,
                )
            )
            return fn

        return decorator

    return register_tool


def _make_register(captured_tools: list[StreamingTool]) -> Callable[..., None]:
    def register(
        name: str,
        description: str,
        parameters: dict,
        fn: Callable[..., AsyncIterator[Any]],
    ) -> None:
        captured_tools.append(
            StreamingTool(
                name=name,
                description=description,
                parameters=parameters,
                fn=fn,
            )
        )

    return register


def load_tools_from_file(path: str | Path) -> list[str]:
    file_path = Path(path).expanduser().resolve()
    if not file_path.is_file():
        logger.error("Tool script not found: %s", file_path)
        return []

    captured_tools: list[StreamingTool] = []
    register_tool = _make_register_tool(captured_tools)
    register = _make_register(captured_tools)

    namespace: dict[str, Any] = {
        "register_tool": register_tool,
        "register": register,
    }

    original_sys_path = sys.path.copy()
    script_dir = str(file_path.parent)
    try:
        if script_dir not in sys.path:
            sys.path.insert(0, script_dir)

        original_module = sys.modules.get(file_path.stem)
        if file_path.stem in sys.modules:
            del sys.modules[file_path.stem]

        runpy.run_path(str(file_path), init_globals=namespace, run_name=file_path.stem)

        if file_path.stem not in sys.modules or original_module is None:
            sys.modules.pop(file_path.stem, None)
        elif original_module is not None:
            sys.modules[file_path.stem] = original_module

    except Exception:
        logger.exception("Error loading tool script %s", file_path)
        return []
    finally:
        sys.path = original_sys_path

    loaded_names: list[str] = []
    registry = ToolRegistry.get_instance()
    for tool in captured_tools:
        registry.register(tool)
        loaded_names.append(tool.name)
        logger.info("Loaded external tool: %s", tool.name)

    return loaded_names


def load_tools_from_directory(path: str | Path, pattern: str = "*.py") -> list[str]:
    dir_path = Path(path).expanduser().resolve()
    if not dir_path.is_dir():
        logger.error("Tool directory not found: %s", dir_path)
        return []

    loaded_names: list[str] = []
    for script_file in sorted(dir_path.glob(pattern)):
        loaded_names.extend(load_tools_from_file(script_file))

    return loaded_names


def load_external_tools(tools_path: str | Path | None) -> list[str]:
    if not tools_path:
        return []

    p = Path(str(tools_path)).expanduser().resolve()
    if p.is_dir():
        return load_tools_from_directory(p)
    if p.is_file():
        return load_tools_from_file(p)

    logger.error("Tools path does not exist: %s", p)
    return []
