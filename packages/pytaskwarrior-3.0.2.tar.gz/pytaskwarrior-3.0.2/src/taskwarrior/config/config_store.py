import os
import re
from pathlib import Path
from typing import TYPE_CHECKING

from ..exceptions import TaskConfigurationError

if TYPE_CHECKING:
    from ..dto.context_dto import ContextDTO
    from ..dto.uda_dto import UdaConfig

DEFAULT_OPTIONS = [
    "rc.confirmation=off",
    "rc.bulk=0",
]


class ConfigStore:
    """
    Loads and caches Taskwarrior config from taskrc. Provides access methods and refresh capability.
    """

    def __init__(self, taskrc_path: str, data_location: str | None = None) -> None:
        self._taskrc_path: Path = Path(os.path.expandvars(taskrc_path)).expanduser()
        self._data_location: Path | None = (
            Path(os.path.expandvars(data_location)).expanduser() if data_location else None
        )
        self._check_or_create_taskfiles()
        self._config: dict[str, str] | None = None
        self._load_config()

    def _load_config(self) -> None:
        self._config = self._extract_taskrc_config(self._taskrc_path)

    def _check_or_create_taskfiles(self) -> None:
        """Create taskrc and data directory if they don't exist."""
        if not self._taskrc_path.exists():
            default_content = f"""# Taskwarrior configuration file
# This file was automatically created by pytaskwarrior
# Default data location
rc.data.location={self._data_location or "~/.task"}
# Disable confirmation prompts
rc.confirmation=off
rc.bulk=0
"""
            self._taskrc_path.parent.mkdir(parents=True, exist_ok=True)
            self._taskrc_path.write_text(default_content)
        if self._data_location and not self._data_location.exists():
            self._data_location.mkdir(parents=True, exist_ok=True)

    def _extract_taskrc_config(self, path: Path) -> dict[str, str]:
        import configparser

        config: dict[str, str] = {}
        # RawConfigParser disables %(key)s interpolation so that values
        # containing '%' (e.g. passphrases) are read verbatim.
        parser = configparser.RawConfigParser()
        # Accept .taskrc files without section headers by adding a dummy section
        try:
            with open(path, encoding="utf-8") as f:
                lines = f.readlines()
        except FileNotFoundError as e:
            raise TaskConfigurationError(f"Taskrc file not found: {path}") from e
        except PermissionError as e:
            raise TaskConfigurationError(
                f"Cannot read taskrc file (permission denied): {path}"
            ) from e
        except OSError as e:
            raise TaskConfigurationError(f"Failed to read taskrc file: {path}: {e}") from e
        # Only keep blank lines, comments, or lines containing '=' (key-value)
        filtered = [
            line
            for line in lines
            if line.strip() == "" or line.strip().startswith("#") or "=" in line
        ]
        content = "[taskrc]\n" + "".join(filtered)
        parser.read_string(content)
        for section in parser.sections():
            for key, value in parser.items(section):
                config[key] = value
        for key in parser.defaults():
            config[key] = parser.defaults()[key]
        return config

    def refresh(self) -> None:
        """Reloads the config from disk."""
        self._load_config()

    @property
    def config(self) -> dict[str, str]:
        if self._config is None:
            self._load_config()
        assert self._config is not None
        return self._config

    @property
    def taskrc_path(self) -> Path:
        """Return the path to the taskrc file."""
        return self._taskrc_path

    @property
    def data_location(self) -> Path:
        """Return the effective task data directory.

        Resolution order:
        1. Explicit *data_location* passed to the constructor
        2. ``rc.data.location`` key from the taskrc file
        3. ``~/.task`` (TaskWarrior default)
        """
        if self._data_location:
            return self._data_location
        from_rc = self.config.get("rc.data.location")
        if from_rc:
            return Path(os.path.expandvars(from_rc)).expanduser()
        return Path("~/.task").expanduser()

    @property
    def cli_options(self) -> list[str]:
        """Return CLI options for Taskwarrior commands, including defaults."""
        options = [f"rc:{self._taskrc_path}"]
        if self._data_location:
            options.append(f"rc.data.location={self._data_location}")
        options.extend(DEFAULT_OPTIONS)
        return options

    def get_sync_config(self) -> dict[str, str]:
        # Extract sync config directly from self.config
        # Accept both 'sync.' and 'taskrc.sync.' keys for compatibility
        return {k: v for k, v in self.config.items() if k.startswith("sync.")}

    def set_sync_config(self, config: dict[str, str | None]) -> None:
        """Write (or clear) the ``sync.*`` section of the taskrc file.

        This is the write-symmetric counterpart of :meth:`get_sync_config`.  It
        **replaces** the current ``sync.*`` keys entirely: keys present in the
        file but absent from *config* are deleted; keys provided in *config*
        are written (or removed when their value is ``None``).

        Keys may be supplied with or without the ``"sync."`` prefix — the prefix
        is added automatically when missing.

        Args:
            config: Mapping of sync key → value.  Pass ``None`` as the value
                to explicitly delete a key (e.g.
                ``{"sync.encryption.secret": None}``).  Pass an empty dict to
                wipe all ``sync.*`` keys.

        Raises:
            TaskConfigurationError: If the taskrc file cannot be read or
                written.

        Example::

            tw.config_store.set_sync_config({
                "sync.server.origin": "https://taskchampion.example.com",
                "sync.server.client_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                "sync.encryption.secret": "my-passphrase",
            })
            # Replace with local sync, removing any previous remote config:
            tw.config_store.set_sync_config({
                "sync.local.server_dir": "/mnt/shared/taskserver",
            })
        """
        # Normalise keys so callers may omit the "sync." prefix.
        normalised: dict[str, str | None] = {}
        for k, v in config.items():
            full_key = k if k.startswith("sync.") else f"sync.{k}"
            normalised[full_key] = v

        # Delete keys currently in the file that are not present in the new config.
        for existing_key in list(self.get_sync_config().keys()):
            if existing_key not in normalised:
                self.delete_value(existing_key)

        # Write or delete each supplied key.
        for key, value in normalised.items():
            if value is None:
                self.delete_value(key)
            else:
                self.set_value(key, value)

        # Final refresh ensures the in-memory cache reflects the final state.
        self.refresh()

    def get_contexts_config(self) -> dict[str, str]:
        # Extract context config directly from self.config
        return {k: v for k, v in self.config.items() if k.startswith("context.")}

    def get_contexts(self, current_context: str | None = None) -> list["ContextDTO"]:
        """
        Returns a list of ContextDTO objects representing all defined contexts.
        """
        from ..dto.context_dto import ContextDTO

        contexts_config = self.get_contexts_config()
        names: dict[str, dict[str, str]] = {}

        for k, v in contexts_config.items():
            m = re.match(r"context\.([^\.]+)\.(read|write)", k)
            if m:
                ctx_name = m.group(1)
                kind = m.group(2)
                names.setdefault(ctx_name, {})[kind] = v
        return [
            ContextDTO(
                name=n,
                read_filter=filters.get("read", ""),
                write_filter=filters.get("write", ""),
                active=(n == current_context),
            )
            for n, filters in names.items()
        ]

    def set_value(self, key: str, value: str) -> None:
        """Upsert a key-value pair in the taskrc file.

        If *key* already exists in the file it is updated in-place; otherwise
        ``key=value`` is appended at the end.  The in-memory cache is refreshed
        automatically after the write.

        Because both :class:`~taskwarrior.adapters.taskchampion_adapter.TaskChampionAdapter`
        and :class:`~taskwarrior.adapters.taskwarrior_adapter.TaskWarriorAdapter`
        read configuration lazily from this store, changes are effective on the
        **next** adapter call without requiring an adapter restart.

        Args:
            key: Dotted taskrc key (e.g. ``"sync.server.origin"``).
            value: New value (may be empty string to clear the value without
                removing the key).

        Raises:
            TaskConfigurationError: If the file cannot be written.

        Example::

            tw.config_store.set_value("sync.server.origin", "https://sync.example.com")
            tw.synchronize()  # picks up the new URL immediately
        """
        pattern = re.compile(r"^\s*" + re.escape(key) + r"\s*=.*$", re.IGNORECASE)
        try:
            lines = self._taskrc_path.read_text(encoding="utf-8").splitlines(keepends=True)
        except OSError as e:
            raise TaskConfigurationError(f"Cannot read taskrc file: {self._taskrc_path}: {e}") from e

        new_line = f"{key}={value}\n"
        replaced = False
        for i, line in enumerate(lines):
            if pattern.match(line):
                lines[i] = new_line
                replaced = True
                break

        if not replaced:
            lines.append(new_line)

        try:
            self._taskrc_path.write_text("".join(lines), encoding="utf-8")
        except OSError as e:
            raise TaskConfigurationError(f"Cannot write taskrc file: {self._taskrc_path}: {e}") from e

        self.refresh()

    def delete_value(self, key: str) -> None:
        """Remove a key from the taskrc file.

        If the key is not present the call is a no-op.  The in-memory cache is
        refreshed automatically after the write.

        Args:
            key: Dotted taskrc key to remove (e.g. ``"uda.severity.type"``).

        Raises:
            TaskConfigurationError: If the file cannot be written.
        """
        pattern = re.compile(r"^\s*" + re.escape(key) + r"\s*=.*$", re.IGNORECASE)
        try:
            lines = self._taskrc_path.read_text(encoding="utf-8").splitlines(keepends=True)
        except OSError as e:
            raise TaskConfigurationError(f"Cannot read taskrc file: {self._taskrc_path}: {e}") from e

        new_lines = [line for line in lines if not pattern.match(line)]

        if len(new_lines) != len(lines):
            try:
                self._taskrc_path.write_text("".join(new_lines), encoding="utf-8")
            except OSError as e:
                raise TaskConfigurationError(
                    f"Cannot write taskrc file: {self._taskrc_path}: {e}"
                ) from e
            self.refresh()

    def get_udas(self) -> list["UdaConfig"]:
        """
        Parse and return UDAs from the cached config mapping.

        Returns a list of UdaConfig objects representing UDAs defined in the
        TaskWarrior configuration. Uses the shared uda_parser to perform parsing.
        """
        # Local import to avoid module import cycles
        from .uda_parser import parse_udas_from_mapping

        return parse_udas_from_mapping(self.config)
