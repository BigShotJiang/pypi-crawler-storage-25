from __future__ import annotations

from pathlib import Path

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.converter.base import SUPPORTED_SOURCE_FORMATS, SUPPORTED_TARGET_FORMATS
from rawctx.sdk import client as rawctx_client


@click.command()
@click.argument("input_path", type=click.Path(path_type=Path), required=True)
@click.option(
    "--from",
    "from_format",
    type=click.Choice(list(SUPPORTED_SOURCE_FORMATS), case_sensitive=False),
    required=True,
    help="Source format",
)
@click.option(
    "--to",
    "to_format",
    type=click.Choice(list(SUPPORTED_TARGET_FORMATS), case_sensitive=False),
    required=True,
    help="Target format",
)
@click.option("--output", "output_dir", type=click.Path(path_type=Path), required=True, help="Output package directory")
@click.option("--package-name", default=None, help="Override generated package name")
@click.option("--package-version", default=None, help="Override generated package version")
@click.option("--overwrite", is_flag=True, default=False, help="Replace output directory if it exists")
@click.option("--json", "json_output", is_flag=True, default=False, help="Print JSON response")
def convert(
    input_path: Path,
    from_format: str,
    to_format: str,
    output_dir: Path,
    package_name: str | None,
    package_version: str | None,
    overwrite: bool,
    json_output: bool,
) -> None:
    """Convert supported source formats into an OSI package. [user]"""

    try:
        with rawctx_client() as sdk_client:
            payload = sdk_client.convert(
                input_path,
                from_format=from_format,
                to_format=to_format,
                output=output_dir,
                package_name=package_name,
                package_version=package_version,
                overwrite=overwrite,
            )
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(payload)
        return

    click.echo(f"Converted {payload['from']} -> {payload['to']}")
    click.echo(f"Package: {payload['package_name']}@{payload['version']}")
    click.echo(f"Wrote {len(payload['written_files'])} file(s) to {payload['output_dir']}")


__all__ = ["convert"]
