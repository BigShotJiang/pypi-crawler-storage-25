from __future__ import annotations

from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import shutil
import tempfile

import click

from rawctx.config import ConfigStore, load_package_cache, resolve_registry, resolve_token, save_package_cache, upsert_cache_entry
from rawctx.converter import get_conversion_registry
from rawctx.converter.base import ConversionError
from rawctx.converter.metricflow_to_osi import build_converted_package
from rawctx.formats.metricflow import load_metricflow_project
from rawctx.package_formats import materialize_metricflow_package_from_project
from rawctx.package_ops import materialize_package, resolve_package_name, resolve_version
from rawctx.packaging.builder import build_package_archive
from rawctx.packaging.manifest import ValidationError
from rawctx.readme import rewrite_legacy_install_commands
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import parse_package_ref
from rawctx.validation import validate_target


def _build_metricflow_osi_package(
    source_root: Path,
    *,
    package_name: str | None,
    package_version: str | None,
    emit_package_dir: Path | None,
    store: ConfigStore,
) -> Path:
    registry = get_conversion_registry()
    route = registry.get("metricflow", "osi")

    project = route.convert(source_root)
    resolved_package_name = resolve_package_name(project.project_name, package_name, store.load().profile.username)
    resolved_version = resolve_version(project.project_version, package_version)

    converted = build_converted_package(
        project,
        package_name=resolved_package_name,
        version=resolved_version,
        source_format="metricflow",
    )

    tmp_dir = Path(tempfile.mkdtemp(prefix="rawctx-from-dbt-"))
    package_dir = tmp_dir / "package"
    try:
        materialize_package(
            package_dir,
            package_name=converted.package_name,
            package_version=converted.version,
            source_format=converted.source_format,
            model_documents=converted.model_documents,
            overwrite=False,
        )

        validate_target(package_dir, "auto")

        if emit_package_dir is not None:
            emit_path = emit_package_dir.expanduser().resolve()
            if emit_path.exists():
                raise ConversionError(f"emit package path already exists: {emit_path}", file_path=emit_path)
            shutil.copytree(package_dir, emit_path)

        return package_dir
    except Exception:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise


def _build_metricflow_native_package(
    source_root: Path,
    *,
    package_name: str | None,
    package_version: str | None,
    emit_package_dir: Path | None,
    store: ConfigStore,
) -> Path:
    parsed = load_metricflow_project(source_root)
    resolved_package_name = resolve_package_name(parsed.project_name, package_name, store.load().profile.username)
    resolved_version = resolve_version(parsed.project_version, package_version)

    tmp_dir = Path(tempfile.mkdtemp(prefix="rawctx-from-dbt-native-"))
    package_dir = tmp_dir / "package"
    try:
        materialize_metricflow_package_from_project(
            parsed.root,
            package_dir,
            package_name=resolved_package_name,
            package_version=resolved_version,
            overwrite=False,
        )
        validate_target(package_dir, "auto")

        if emit_package_dir is not None:
            emit_path = emit_package_dir.expanduser().resolve()
            if emit_path.exists():
                raise ConversionError(f"emit package path already exists: {emit_path}", file_path=emit_path)
            shutil.copytree(package_dir, emit_path)

        return package_dir
    except Exception:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise


@click.command()
@click.argument("target_dir", required=False, default=".")
@click.option(
    "--from-dbt",
    "from_dbt",
    default=None,
    type=click.Path(path_type=Path, exists=True),
    help="Convert and publish from dbt project",
)
@click.option("--emit-package", "emit_package", default=None, type=click.Path(path_type=Path), help="Persist converted package directory")
@click.option("--package-name", default=None, help="Override generated package name for --from-dbt")
@click.option("--package-version", default=None, help="Override generated package version for --from-dbt")
@click.option("--native", "native_format", is_flag=True, default=False, help="Publish a native MetricFlow package for --from-dbt")
@click.option("--private", "is_private", is_flag=True, default=False, help="Publish package as private")
@click.option("--org", "org_name", default=None, help="Organization name for package ownership and ACL")
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def publish(
    target_dir: str,
    from_dbt: Path | None,
    emit_package: Path | None,
    package_name: str | None,
    package_version: str | None,
    native_format: bool,
    is_private: bool,
    org_name: str | None,
    registry_override: str | None,
) -> None:
    store = ConfigStore()

    if from_dbt is not None:
        if target_dir != ".":
            raise click.UsageError("target_dir argument cannot be used with --from-dbt")
        try:
            if native_format:
                target_path = _build_metricflow_native_package(
                    from_dbt,
                    package_name=package_name,
                    package_version=package_version,
                    emit_package_dir=emit_package,
                    store=store,
                )
            else:
                target_path = _build_metricflow_osi_package(
                    from_dbt,
                    package_name=package_name,
                    package_version=package_version,
                    emit_package_dir=emit_package,
                    store=store,
                )
        except (ConversionError, ValidationError, ValueError) as exc:
            raise click.ClickException(str(exc)) from exc
    else:
        if native_format:
            raise click.UsageError("--native can only be used with --from-dbt")
        target_path = Path(target_dir).expanduser().resolve()

    if not target_path.is_dir():
        raise click.UsageError("publish target must be a directory")

    try:
        try:
            validation_result = validate_target(target_path, "auto")
        except ValidationError as exc:
            raise click.ClickException(str(exc)) from exc

        manifest = validation_result.manifest
        if manifest is None:
            raise click.ClickException("manifest validation did not produce a manifest")

        readme_text: str | None = None
        readme_path = target_path / "README.md"
        if readme_path.is_file():
            readme_text = rewrite_legacy_install_commands(readme_path.read_text(encoding="utf-8"))

        with tempfile.TemporaryDirectory(prefix="rawctx-publish-") as tmp_dir:
            build = build_package_archive(target_path, Path(tmp_dir), manifest=manifest)
            archive_bytes = build.archive_path.read_bytes()

        checksum = sha256(archive_bytes).hexdigest()

        config = store.load()
        registry = resolve_registry(cli_registry=registry_override, config=config)
        token = resolve_token(config)
        if not token:
            raise click.ClickException("Authentication required. Run `rawctx login` first.")

        package_ref = parse_package_ref(manifest.name)

        payload = {
            "scope": package_ref.scope,
            "name": package_ref.name,
            "description": manifest.description,
            "format": manifest.format,
            "source_format": manifest.source_format,
            "source": manifest.source,
            "domain": manifest.domain,
            "license": manifest.license,
            "repository_url": manifest.repository,
            "readme": readme_text,
            "tags": manifest.tags or [],
        }

        client = RegistryClient(registry=registry, token=token)
        try:
            org_id = None
            if org_name:
                org = client.get_org(orgname=org_name)
                org_id = org.get("id")
                if not isinstance(org_id, str) or not org_id.strip():
                    raise click.ClickException(f"Organization lookup failed: {org_name}")

            try:
                client.create_package(
                    payload={
                        **payload,
                        "is_private": is_private,
                        "org_id": org_id,
                    }
                )
            except RegistryError as exc:
                if exc.status_code != 409:
                    raise

            try:
                upload_data = client.request_version_upload(
                    scope=package_ref.scope,
                    name=package_ref.name,
                    version=manifest.version,
                    file_size=len(archive_bytes),
                    checksum_sha256=checksum,
                    content_type="application/gzip",
                )
            except RegistryError as exc:
                if exc.status_code == 409:
                    raise click.ClickException(f"Version already exists: {package_ref.package_name}@{manifest.version}") from exc
                raise

            upload_url = str(upload_data.get("upload_url") or "")
            if not upload_url:
                raise click.ClickException("Registry did not return upload_url")

            client.upload_bytes(upload_url=upload_url, payload=archive_bytes, content_type="application/gzip")
            version_info = client.complete_version(
                scope=package_ref.scope,
                name=package_ref.name,
                version=manifest.version,
                checksum_sha256=checksum,
            )

            package_detail = client.get_package(scope=package_ref.scope, name=package_ref.name)
            versions, _meta = client.list_versions(scope=package_ref.scope, name=package_ref.name)

            cache = load_package_cache(store.paths)
            upsert_cache_entry(
                cache,
                scope=package_ref.scope,
                name=package_ref.name,
                registry=registry,
                package=asdict(package_detail),
                versions=[asdict(item) for item in versions],
            )
            save_package_cache(store.paths, cache)
        except click.ClickException:
            raise
        except RegistryError as exc:
            raise click.ClickException(str(exc)) from exc
        finally:
            client.close()

        click.echo(f"Published {package_ref.package_name}@{version_info.version}")
    finally:
        if from_dbt is not None:
            shutil.rmtree(target_path.parent, ignore_errors=True)
