from __future__ import annotations

from pathlib import Path

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import client as rawctx_client
from rawctx.validation import ValidateResult, validate_target


def _format_measure_names(measures: list[str | None]) -> str:
    if not measures:
        return "-"
    normalized: list[str] = []
    for measure in measures:
        if isinstance(measure, str) and measure.strip():
            normalized.append(measure.strip())
        else:
            normalized.append("(unnamed metric)")
    return ", ".join(normalized)


def _print_dataset_measures(dataset_measures: list[dict[str, object]]) -> None:
    grouped: dict[str, list[dict[str, object]]] = {}
    for detail in dataset_measures:
        model = detail.get("model")
        key = str(model) if isinstance(model, str) and model.strip() else "(unnamed model)"
        grouped.setdefault(key, []).append(detail)

    for model_name in sorted(grouped):
        click.echo(f"dataset measures: {model_name}")
        for detail in grouped[model_name]:
            click.echo(
                f"  [{model_name}] {detail['dataset']}: "
                f"{detail['measure_count']} ({_format_measure_names(list(detail.get('measures', [])))})"
            )


@click.command()
@click.argument("target", required=False, default=".")
@click.option(
    "--format",
    "format_hint",
    type=click.Choice(["auto", "manifest", "osi"]),
    default="auto",
    show_default=True,
)
@click.option("--show-dataset-measures", is_flag=True, default=False, help="Show measure assignment by dataset")
@click.option("--json", "json_output", is_flag=True, default=False, help="Print JSON response")
def validate(target: str, format_hint: str, show_dataset_measures: bool, json_output: bool) -> None:
    """Validate a local package or OSI document. [user]"""

    try:
        with rawctx_client() as sdk_client:
            payload = sdk_client.validate(target, format=format_hint, show_dataset_measures=show_dataset_measures)
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(payload)
        return

    click.echo(f"validated {len(payload['validated_files'])} file(s)")
    manifest = payload.get("manifest")
    if isinstance(manifest, dict):
        click.echo(f"package: {manifest['name']}@{manifest['version']}")
    summary = payload["summary"]
    if summary["datasets"] or summary["measures"] or summary["dimensions"] or summary["relationships"]:
        click.echo(
            "osi summary: "
            f"datasets={summary['datasets']}, measures={summary['measures']}, "
            f"dimensions={summary['dimensions']}, relationships={summary['relationships']}, "
            f"ai_context={str(summary['ai_context']).lower()}"
        )
        if show_dataset_measures:
            _print_dataset_measures(payload["dataset_measures"])


__all__ = ["ValidateResult", "validate", "validate_target"]
