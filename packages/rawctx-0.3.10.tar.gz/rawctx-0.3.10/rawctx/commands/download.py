from __future__ import annotations

from pathlib import Path

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import _serialize_file_materialization
from rawctx.sdk import client as rawctx_client


@click.command()
@click.argument("package_ref", required=True)
@click.argument("model_path", required=True)
@click.option("--local-dir", default=None, help="Destination root for the downloaded file")
@click.option("--stdout", "stdout_output", is_flag=True, default=False, help="Print the OSI YAML content")
@click.option("--offline", is_flag=True, default=False)
@click.option("--force", is_flag=True, default=False)
@click.option("--json", "json_output", is_flag=True, default=False)
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def download(
    package_ref: str,
    model_path: str,
    local_dir: str | None,
    stdout_output: bool,
    offline: bool,
    force: bool,
    json_output: bool,
    registry_override: str | None,
) -> None:
    """Download a single OSI model file. [user]"""

    if stdout_output and json_output:
        raise click.UsageError("--stdout cannot be combined with --json")

    try:
        with rawctx_client(registry=registry_override) as sdk_client:
            result = sdk_client._download_materialized(
                package_ref,
                model_path,
                local_dir=local_dir,
                offline=offline,
                force=force,
            )
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(_serialize_file_materialization(result))
        return

    if stdout_output:
        click.echo(Path(result.local_path).read_text(encoding="utf-8"), nl=False)
        return

    click.echo(str(result.local_path))
