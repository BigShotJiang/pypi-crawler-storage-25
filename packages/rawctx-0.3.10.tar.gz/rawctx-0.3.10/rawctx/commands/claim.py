from __future__ import annotations

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import client as rawctx_client


@click.command()
@click.argument("package_ref", required=True)
@click.option("--json", "json_output", is_flag=True, default=False, help="Print JSON response")
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def claim(package_ref: str, json_output: bool, registry_override: str | None) -> None:
    """Claim an indexed package you maintain. [maintainer]"""

    try:
        with rawctx_client(registry=registry_override) as sdk_client:
            payload = sdk_client.claim(package_ref)
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(payload)
        return

    click.echo(f"Package: {payload['package']}")
    click.echo(f"Claim status: {payload['claim_status']}")
    click.echo(f"Origin repo: {payload['origin_repo']}")
    if payload.get("origin_url"):
        click.echo(f"Origin URL: {payload['origin_url']}")
    click.echo(f"Claimed by: {payload['claimed_by']}")
    click.echo(f"Claimed at: {payload['claimed_at']}")
    click.echo(f"Suggested native package: {payload['suggested_native_ref']}")
    click.echo(f"Next step: {payload['next_publish_command']}")
