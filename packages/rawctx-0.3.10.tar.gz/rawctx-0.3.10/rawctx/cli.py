import click

from rawctx.commands.claim import claim
from rawctx.commands.convert import convert
from rawctx.commands.download import download
from rawctx import __version__
from rawctx.commands.index import index
from rawctx.commands.info import info
from rawctx.commands.login import login, logout
from rawctx.commands.pack import pack
from rawctx.commands.publish import publish
from rawctx.commands.search import search
from rawctx.commands.snapshot_download import snapshot_download
from rawctx.commands.validate import validate


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=__version__, prog_name="rawctx")
@click.option("--debug", is_flag=True, default=False, help="Enable debug mode.")
@click.pass_context
def main(ctx: click.Context, debug: bool) -> None:
    """rawctx CLI."""
    ctx.ensure_object(dict)
    ctx.obj["debug"] = debug


main.add_command(publish)
main.add_command(login)
main.add_command(logout)
main.add_command(search)
main.add_command(download)
main.add_command(snapshot_download)
main.add_command(info)
main.add_command(validate)
main.add_command(pack)
main.add_command(convert)
main.add_command(index)
main.add_command(claim)


if __name__ == "__main__":
    main()
