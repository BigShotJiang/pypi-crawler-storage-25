from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from rawctx.packaging.manifest import ValidationError
from rawctx.formats.osi import assign_measure_datasets, read_osi


@dataclass(frozen=True)
class Measure:
    name: str
    dataset: str | None
    model: str
    path: str
    expression: dict[str, Any] | None
    description: str | None = None
    ai_context: Any = None


@dataclass(frozen=True)
class Dimension:
    name: str
    dataset: str
    model: str
    path: str
    is_time: bool
    label: str | None
    description: str | None
    expression: dict[str, Any] | None
    ai_context: Any = None


@dataclass(frozen=True)
class Relationship:
    name: str
    from_dataset: str
    to_dataset: str
    from_columns: list[str]
    to_columns: list[str]
    model: str
    path: str
    ai_context: Any = None


@dataclass(frozen=True)
class SemanticModel:
    name: str
    path: str
    datasets: list[str] = field(default_factory=list)
    measures: list[Measure] = field(default_factory=list)
    dimensions: list[Dimension] = field(default_factory=list)
    relationships: list[Relationship] = field(default_factory=list)


@dataclass(frozen=True)
class LoadedPackage:
    package: str
    version: str
    model_paths: list[str]
    snapshot_dir: Path
    format_name: str = "osi"
    datasets: list[str] = field(default_factory=list)
    measures: list[Measure] = field(default_factory=list)
    dimensions: list[Dimension] = field(default_factory=list)
    relationships: list[Relationship] = field(default_factory=list)
    models: list[SemanticModel] = field(default_factory=list)


@dataclass(frozen=True)
class _MetricFlowEntityRef:
    model_name: str
    expr: str


def _clean_str(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned or None


def _copy_mapping(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    return deepcopy(value)


def _copy_ai_context(value: Any) -> Any:
    return deepcopy(value)


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item.strip() for item in value if isinstance(item, str) and item.strip()]


def _normalize_items(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _extract_metricflow_items(document: Any, key: str) -> list[dict[str, Any]]:
    if isinstance(document, dict):
        return _normalize_items(document.get(key))
    if isinstance(document, list):
        items: list[dict[str, Any]] = []
        for entry in document:
            if isinstance(entry, dict):
                items.extend(_normalize_items(entry.get(key)))
        return items
    return []


def _read_metricflow_document(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return yaml.safe_load(handle)
    except yaml.YAMLError as exc:
        raise ValidationError("invalid YAML syntax", path) from exc
    except OSError as exc:
        raise ValidationError("failed to read MetricFlow file", path) from exc


def _expression_mapping(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        return deepcopy(value)
    cleaned = _clean_str(value)
    if cleaned is None:
        return None
    return {"metricflow": cleaned}


def _measure_owner_map(semantic_models: list[tuple[str, dict[str, Any]]]) -> dict[str, set[str]]:
    owners: dict[str, set[str]] = {}
    for _path, semantic_model in semantic_models:
        model_name = _clean_str(semantic_model.get("name")) or ""
        for measure in _normalize_items(semantic_model.get("measures")):
            measure_name = _clean_str(measure.get("name"))
            if measure_name:
                owners.setdefault(measure_name, set()).add(model_name)
    return owners


def _metric_ref_name(value: Any) -> str | None:
    if isinstance(value, dict):
        for key in ("name", "metric", "measure"):
            candidate = _clean_str(value.get(key))
            if candidate:
                return candidate
        return None
    return _clean_str(value)


def _metric_owner_hint_map(
    metrics: list[tuple[str, dict[str, Any]]],
    *,
    owner_by_measure: dict[str, set[str]],
) -> dict[str, set[str]]:
    hints: dict[str, set[str]] = {}
    for _path, metric in metrics:
        metric_name = _clean_str(metric.get("name"))
        if not metric_name:
            continue

        owners: set[str] = set()
        semantic_model = _clean_str(metric.get("semantic_model")) or _clean_str(metric.get("model"))
        if semantic_model:
            owners.add(semantic_model)

        type_params = metric.get("type_params")
        if isinstance(type_params, dict):
            measure_name = _metric_ref_name(type_params.get("measure"))
            if measure_name:
                owners.update(owner_by_measure.get(measure_name, set()))

        if owners:
            hints.setdefault(metric_name, set()).update(owners)
    return hints


def _resolve_metric_owner(
    metric: dict[str, Any],
    owner_by_measure: dict[str, set[str]],
    owner_by_metric_hint: dict[str, set[str]],
    *,
    default_owner: str | None,
) -> str | None:
    semantic_model = _clean_str(metric.get("semantic_model")) or _clean_str(metric.get("model"))
    if semantic_model:
        return semantic_model

    type_params = metric.get("type_params") if isinstance(metric.get("type_params"), dict) else {}
    measure_name = _metric_ref_name(type_params.get("measure"))
    if measure_name:
        candidates = set(owner_by_measure.get(measure_name, set()))
        candidates.update(owner_by_metric_hint.get(measure_name, set()))
        if len(candidates) == 1:
            return next(iter(candidates))
        if len(candidates) > 1:
            return sorted(candidates)[0]
        return default_owner

    numerator = _metric_ref_name(type_params.get("numerator"))
    denominator = _metric_ref_name(type_params.get("denominator"))
    if numerator and denominator:
        owners = set(owner_by_measure.get(numerator, set()))
        owners.update(owner_by_metric_hint.get(numerator, set()))
        owners.update(owner_by_measure.get(denominator, set()))
        owners.update(owner_by_metric_hint.get(denominator, set()))
        if len(owners) == 1:
            return next(iter(owners))
        if len(owners) > 1:
            return sorted(owners)[0]
        return default_owner

    metric_refs = type_params.get("metrics")
    if isinstance(metric_refs, list):
        owners: set[str] = set()
        for raw_ref in metric_refs:
            ref_name = _metric_ref_name(raw_ref)
            if not ref_name:
                continue
            owners.update(owner_by_measure.get(ref_name, set()))
            owners.update(owner_by_metric_hint.get(ref_name, set()))
        if len(owners) == 1:
            return next(iter(owners))
        if len(owners) > 1:
            return sorted(owners)[0]

    return default_owner


def _build_metricflow_relationships(
    semantic_models: list[tuple[str, dict[str, Any]]],
) -> dict[str, list[tuple[str, str, str, str]]]:
    targets: dict[str, list[_MetricFlowEntityRef]] = {}

    for _path, semantic_model in semantic_models:
        model_name = _clean_str(semantic_model.get("name")) or ""
        for entity in _normalize_items(semantic_model.get("entities")):
            entity_name = _clean_str(entity.get("name"))
            entity_type = (_clean_str(entity.get("type")) or "").lower()
            if not entity_name or entity_type not in {"primary", "unique", "natural"}:
                continue
            expr = _clean_str(entity.get("expr")) or entity_name
            targets.setdefault(entity_name, []).append(_MetricFlowEntityRef(model_name=model_name, expr=expr))

    relationships: dict[str, list[tuple[str, str, str, str]]] = {}
    for _path, semantic_model in semantic_models:
        model_name = _clean_str(semantic_model.get("name")) or ""
        for entity in _normalize_items(semantic_model.get("entities")):
            entity_name = _clean_str(entity.get("name"))
            entity_type = (_clean_str(entity.get("type")) or "").lower()
            if not entity_name or entity_type != "foreign":
                continue
            candidates = [item for item in targets.get(entity_name, []) if item.model_name != model_name]
            if len(candidates) != 1:
                continue
            from_expr = _clean_str(entity.get("expr")) or entity_name
            target = candidates[0]
            relationships.setdefault(model_name, []).append((entity_name, from_expr, target.model_name, target.expr))
    return relationships


def _build_loaded_metricflow_package(
    *,
    package: str,
    version: str,
    snapshot_dir: Path,
    model_paths: list[str],
) -> LoadedPackage:
    documents_by_path: dict[str, Any] = {}
    semantic_models_by_path: dict[str, list[dict[str, Any]]] = {}
    metrics_by_path: dict[str, list[dict[str, Any]]] = {}
    semantic_model_rows: list[tuple[str, dict[str, Any]]] = []
    metric_rows: list[tuple[str, dict[str, Any]]] = []

    for model_path in model_paths:
        document = _read_metricflow_document(snapshot_dir / model_path)
        documents_by_path[model_path] = document
        semantic_models = _extract_metricflow_items(document, "semantic_models")
        metrics = _extract_metricflow_items(document, "metrics")
        semantic_models_by_path[model_path] = semantic_models
        metrics_by_path[model_path] = metrics
        semantic_model_rows.extend((model_path, item) for item in semantic_models)
        metric_rows.extend((model_path, item) for item in metrics)

    owner_by_measure = _measure_owner_map(semantic_model_rows)
    owner_by_metric_hint = _metric_owner_hint_map(metric_rows, owner_by_measure=owner_by_measure)
    relationships_by_model = _build_metricflow_relationships(semantic_model_rows)
    ordered_model_names = [
        _clean_str(item.get("name")) or ""
        for _path, item in semantic_model_rows
        if _clean_str(item.get("name"))
    ]
    default_owner = ordered_model_names[0] if len(set(ordered_model_names)) == 1 and ordered_model_names else None

    metrics_by_owner: dict[str, list[tuple[str, dict[str, Any]]]] = {}
    unassigned_metrics: list[tuple[str, dict[str, Any]]] = []
    for metric_path, metric in metric_rows:
        owner = _resolve_metric_owner(metric, owner_by_measure, owner_by_metric_hint, default_owner=default_owner)
        metric_name = _clean_str(metric.get("name"))
        if not metric_name:
            continue
        if owner is None:
            unassigned_metrics.append((metric_path, metric))
            continue
        metrics_by_owner.setdefault(owner, []).append((metric_path, metric))
        owner_by_metric_hint.setdefault(metric_name, set()).add(owner)

    datasets: list[str] = []
    seen_datasets: set[str] = set()
    measures: list[Measure] = []
    dimensions: list[Dimension] = []
    relationships: list[Relationship] = []
    models: list[SemanticModel] = []

    for model_path in model_paths:
        for semantic_model in semantic_models_by_path.get(model_path, []):
            model_name = _clean_str(semantic_model.get("name"))
            if not model_name:
                continue
            if model_name not in seen_datasets:
                seen_datasets.add(model_name)
                datasets.append(model_name)

            model_dimensions: list[Dimension] = []
            for raw_dimension in _normalize_items(semantic_model.get("dimensions")):
                dimension_name = _clean_str(raw_dimension.get("name"))
                if not dimension_name:
                    continue
                dimension = Dimension(
                    name=dimension_name,
                    dataset=model_name,
                    model=model_name,
                    path=model_path,
                    is_time=(_clean_str(raw_dimension.get("type")) or "").lower() == "time",
                    label=_clean_str(raw_dimension.get("label")),
                    description=_clean_str(raw_dimension.get("description")),
                    expression=_expression_mapping(raw_dimension.get("expr")),
                    ai_context=_copy_ai_context(raw_dimension.get("ai_context")),
                )
                model_dimensions.append(dimension)
                dimensions.append(dimension)

            model_measures: list[Measure] = []
            for raw_measure in _normalize_items(semantic_model.get("measures")):
                measure_name = _clean_str(raw_measure.get("name"))
                if not measure_name:
                    continue
                measure = Measure(
                    name=measure_name,
                    dataset=model_name,
                    model=model_name,
                    path=model_path,
                    expression=_expression_mapping(raw_measure.get("expr")),
                    description=_clean_str(raw_measure.get("description")),
                    ai_context=_copy_ai_context(raw_measure.get("ai_context")),
                )
                model_measures.append(measure)
                measures.append(measure)

            for metric_path, raw_metric in metrics_by_owner.get(model_name, []):
                metric_name = _clean_str(raw_metric.get("name"))
                if not metric_name:
                    continue
                metric_measure = Measure(
                    name=metric_name,
                    dataset=model_name,
                    model=model_name,
                    path=metric_path,
                    expression=None,
                    description=_clean_str(raw_metric.get("description")),
                    ai_context=_copy_ai_context(raw_metric.get("ai_context")),
                )
                model_measures.append(metric_measure)
                measures.append(metric_measure)

            model_relationships: list[Relationship] = []
            for entity_name, from_expr, target_model, target_expr in relationships_by_model.get(model_name, []):
                relationship = Relationship(
                    name=f"{model_name}__{entity_name}__to__{target_model}",
                    from_dataset=model_name,
                    to_dataset=target_model,
                    from_columns=[from_expr],
                    to_columns=[target_expr],
                    model=model_name,
                    path=model_path,
                    ai_context=None,
                )
                model_relationships.append(relationship)
                relationships.append(relationship)

            models.append(
                SemanticModel(
                    name=model_name,
                    path=model_path,
                    datasets=[model_name],
                    measures=model_measures,
                    dimensions=model_dimensions,
                    relationships=model_relationships,
                )
            )

    for metric_path, raw_metric in unassigned_metrics:
        metric_name = _clean_str(raw_metric.get("name"))
        if not metric_name:
            continue
        measures.append(
            Measure(
                name=metric_name,
                dataset=None,
                model="",
                path=metric_path,
                expression=None,
                description=_clean_str(raw_metric.get("description")),
                ai_context=_copy_ai_context(raw_metric.get("ai_context")),
            )
        )

    return LoadedPackage(
        package=package,
        version=version,
        model_paths=list(model_paths),
        snapshot_dir=snapshot_dir,
        format_name="metricflow",
        datasets=datasets,
        measures=measures,
        dimensions=dimensions,
        relationships=relationships,
        models=models,
    )


def build_loaded_package(
    *,
    package: str,
    version: str,
    snapshot_dir: Path,
    model_paths: list[str],
    format_name: str = "osi",
) -> LoadedPackage:
    if format_name == "metricflow":
        return _build_loaded_metricflow_package(
            package=package,
            version=version,
            snapshot_dir=snapshot_dir,
            model_paths=model_paths,
        )

    datasets: list[str] = []
    measures: list[Measure] = []
    dimensions: list[Dimension] = []
    relationships: list[Relationship] = []
    models: list[SemanticModel] = []
    seen_datasets: set[str] = set()

    for model_path in model_paths:
        document = read_osi(snapshot_dir / model_path)
        semantic_models = document.get("semantic_model")
        if not isinstance(semantic_models, list):
            continue

        for semantic_model in semantic_models:
            if not isinstance(semantic_model, dict):
                continue

            model_name = _clean_str(semantic_model.get("name")) or ""
            raw_datasets = semantic_model.get("datasets")
            raw_relationships = semantic_model.get("relationships")
            raw_measures = semantic_model.get("metrics")
            if not isinstance(raw_datasets, list):
                raw_datasets = []
            if not isinstance(raw_relationships, list):
                raw_relationships = []
            if not isinstance(raw_measures, list):
                raw_measures = []

            model_dataset_names: list[str] = []
            dataset_field_names: dict[str, set[str]] = {}

            for raw_dataset in raw_datasets:
                if not isinstance(raw_dataset, dict):
                    continue
                dataset_name = _clean_str(raw_dataset.get("name"))
                if dataset_name is None:
                    continue
                model_dataset_names.append(dataset_name)
                if dataset_name not in seen_datasets:
                    seen_datasets.add(dataset_name)
                    datasets.append(dataset_name)

                raw_fields = raw_dataset.get("fields")
                if not isinstance(raw_fields, list):
                    raw_fields = []
                dataset_field_names[dataset_name] = {
                    field_name
                    for raw_field in raw_fields
                    if isinstance(raw_field, dict)
                    for field_name in [_clean_str(raw_field.get("name"))]
                    if field_name is not None
                }

            measure_datasets = assign_measure_datasets(raw_measures, model_dataset_names, dataset_field_names)

            model_dimensions: list[Dimension] = []
            for raw_dataset in raw_datasets:
                if not isinstance(raw_dataset, dict):
                    continue
                dataset_name = _clean_str(raw_dataset.get("name"))
                if dataset_name is None:
                    continue
                raw_fields = raw_dataset.get("fields")
                if not isinstance(raw_fields, list):
                    raw_fields = []
                for raw_field in raw_fields:
                    if not isinstance(raw_field, dict) or not isinstance(raw_field.get("dimension"), dict):
                        continue
                    field_name = _clean_str(raw_field.get("name"))
                    if field_name is None:
                        continue
                    dimension = Dimension(
                        name=field_name,
                        dataset=dataset_name,
                        model=model_name,
                        path=model_path,
                        is_time=bool(raw_field["dimension"].get("is_time", False)),
                        label=_clean_str(raw_field.get("label")),
                        description=_clean_str(raw_field.get("description")),
                        expression=_copy_mapping(raw_field.get("expression")),
                        ai_context=_copy_ai_context(raw_field.get("ai_context")),
                    )
                    model_dimensions.append(dimension)
                    dimensions.append(dimension)

            model_measures: list[Measure] = []
            for raw_measure, dataset_name in zip(raw_measures, measure_datasets, strict=False):
                if not isinstance(raw_measure, dict):
                    continue
                measure_name = _clean_str(raw_measure.get("name"))
                if measure_name is None:
                    continue
                measure = Measure(
                    name=measure_name,
                    dataset=dataset_name,
                    model=model_name,
                    path=model_path,
                    expression=_copy_mapping(raw_measure.get("expression")),
                    description=_clean_str(raw_measure.get("description")),
                    ai_context=_copy_ai_context(raw_measure.get("ai_context")),
                )
                model_measures.append(measure)
                measures.append(measure)

            model_relationships: list[Relationship] = []
            for raw_relationship in raw_relationships:
                if not isinstance(raw_relationship, dict):
                    continue
                name = _clean_str(raw_relationship.get("name"))
                from_dataset = _clean_str(raw_relationship.get("from"))
                to_dataset = _clean_str(raw_relationship.get("to"))
                if name is None or from_dataset is None or to_dataset is None:
                    continue
                relationship = Relationship(
                    name=name,
                    from_dataset=from_dataset,
                    to_dataset=to_dataset,
                    from_columns=_string_list(raw_relationship.get("from_columns")),
                    to_columns=_string_list(raw_relationship.get("to_columns")),
                    model=model_name,
                    path=model_path,
                    ai_context=_copy_ai_context(raw_relationship.get("ai_context")),
                )
                model_relationships.append(relationship)
                relationships.append(relationship)

            models.append(
                SemanticModel(
                    name=model_name,
                    path=model_path,
                    datasets=model_dataset_names,
                    measures=model_measures,
                    dimensions=model_dimensions,
                    relationships=model_relationships,
                )
            )

    return LoadedPackage(
        package=package,
        version=version,
        model_paths=list(model_paths),
        snapshot_dir=snapshot_dir,
        format_name="osi",
        datasets=datasets,
        measures=measures,
        dimensions=dimensions,
        relationships=relationships,
        models=models,
    )
