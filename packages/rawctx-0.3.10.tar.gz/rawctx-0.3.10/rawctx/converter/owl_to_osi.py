"""OWL -> OSI converter placeholder."""
