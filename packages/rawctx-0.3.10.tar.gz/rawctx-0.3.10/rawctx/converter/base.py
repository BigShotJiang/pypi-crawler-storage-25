from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


SUPPORTED_SOURCE_FORMATS = ("metricflow", "cube", "owl", "skos")
SUPPORTED_TARGET_FORMATS = ("osi",)


@dataclass(frozen=True)
class ConversionError(Exception):
    message: str
    file_path: Path | None = None
    field: str | None = None

    def __str__(self) -> str:
        location: list[str] = []
        if self.file_path is not None:
            location.append(str(self.file_path))
        if self.field:
            location.append(f"field '{self.field}'")
        if location:
            return f"{self.message} ({', '.join(location)})"
        return self.message


@dataclass(frozen=True)
class DialectExpressionIR:
    dialect: str
    expression: str


@dataclass(frozen=True)
class ExpressionIR:
    dialects: list[DialectExpressionIR]


@dataclass(frozen=True)
class FieldIR:
    name: str
    expression: ExpressionIR
    is_time: bool = False
    label: str | None = None
    description: str | None = None
    ai_context: str | dict[str, Any] | None = None


@dataclass(frozen=True)
class DatasetIR:
    name: str
    source: str
    description: str | None = None
    ai_context: str | dict[str, Any] | None = None
    primary_key: list[str] | None = None
    unique_keys: list[list[str]] | None = None
    fields: list[FieldIR] = field(default_factory=list)


@dataclass(frozen=True)
class MetricIR:
    name: str
    expression: ExpressionIR
    description: str | None = None
    ai_context: str | dict[str, Any] | None = None


@dataclass(frozen=True)
class RelationshipIR:
    name: str
    from_dataset: str
    to_dataset: str
    from_columns: list[str]
    to_columns: list[str]
    ai_context: str | dict[str, Any] | None = None


@dataclass(frozen=True)
class SemanticModelIR:
    name: str
    datasets: list[DatasetIR]
    description: str | None = None
    ai_context: str | dict[str, Any] | None = None
    relationships: list[RelationshipIR] = field(default_factory=list)
    metrics: list[MetricIR] = field(default_factory=list)


@dataclass(frozen=True)
class ProjectIR:
    project_name: str
    project_version: str | None
    semantic_models: list[SemanticModelIR]
    source_root: Path
    dialects: list[str] = field(default_factory=lambda: ["ANSI_SQL"])
    vendors: list[str] = field(default_factory=lambda: ["COMMON"])


@dataclass(frozen=True)
class ConvertedPackage:
    package_name: str
    version: str
    source_format: str
    model_documents: dict[str, dict[str, Any]]


ConvertFn = Callable[[Path], ProjectIR]


@dataclass(frozen=True)
class ConversionRoute:
    from_format: str
    to_format: str
    description: str
    convert: ConvertFn


class ConversionRegistry:
    def __init__(self) -> None:
        self._routes: dict[tuple[str, str], ConversionRoute] = {}

    def register(self, route: ConversionRoute) -> None:
        key = (route.from_format, route.to_format)
        if key in self._routes:
            raise ConversionError(f"conversion route already registered: {route.from_format} -> {route.to_format}")
        self._routes[key] = route

    def get(self, from_format: str, to_format: str) -> ConversionRoute:
        key = (from_format, to_format)
        route = self._routes.get(key)
        if route is None:
            raise ConversionError(f"unsupported conversion route: {from_format} -> {to_format}")
        return route

    def list_routes(self) -> list[ConversionRoute]:
        return sorted(self._routes.values(), key=lambda item: (item.from_format, item.to_format))
