from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from rawctx.converter.base import ConversionError


RelationshipAction = Literal["error", "skip"]


@dataclass(frozen=True)
class MetricFlowCaseModule:
    name: str
    description: str
    unresolved_relationship_action: RelationshipAction
    ambiguous_relationship_action: RelationshipAction
    ambiguous_metric_owner_action: Literal["error", "first"]
    unresolved_metric_owner_action: Literal["error", "first-model"]


_CASE_MODULES: dict[str, MetricFlowCaseModule] = {
    "strict": MetricFlowCaseModule(
        name="strict",
        description="Fail conversion on unresolved or ambiguous relationship targets.",
        unresolved_relationship_action="error",
        ambiguous_relationship_action="error",
        ambiguous_metric_owner_action="error",
        unresolved_metric_owner_action="error",
    ),
    "skip-unresolvable-relationships": MetricFlowCaseModule(
        name="skip-unresolvable-relationships",
        description="Skip foreign-entity relationships that cannot be safely resolved.",
        unresolved_relationship_action="skip",
        ambiguous_relationship_action="skip",
        ambiguous_metric_owner_action="first",
        unresolved_metric_owner_action="first-model",
    ),
}


def list_metricflow_case_modules() -> tuple[str, ...]:
    return tuple(sorted(_CASE_MODULES.keys()))


def get_metricflow_case_module(name: str) -> MetricFlowCaseModule:
    module = _CASE_MODULES.get(name)
    if module is None:
        supported = ", ".join(list_metricflow_case_modules())
        raise ConversionError(f"unsupported MetricFlow case module '{name}' (supported: {supported})")
    return module


def auto_fallback_case_module_for_error(error: ConversionError) -> str | None:
    message = (error.message or "").lower()
    if "cannot resolve relationship target for entity" in message:
        return "skip-unresolvable-relationships"
    if "ambiguous relationship target for entity" in message:
        return "skip-unresolvable-relationships"
    if "ambiguous measure owner for metric reference" in message:
        return "skip-unresolvable-relationships"
    if "ambiguous measure owner for metric measure" in message:
        return "skip-unresolvable-relationships"
    if "cannot resolve measure owner for metric reference" in message:
        return "skip-unresolvable-relationships"
    if "cannot resolve measure owner for metric measure" in message:
        return "skip-unresolvable-relationships"
    if "unable to resolve metric owner semantic model" in message:
        return "skip-unresolvable-relationships"
    return None
