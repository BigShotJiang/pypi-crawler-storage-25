from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
from urllib.parse import urlparse
from typing import Any

import yaml


DEFAULT_REGISTRY = "https://api.rawctx.dev"


@dataclass
class AuthConfig:
    token: str | None = None
    token_id: str | None = None
    token_name: str | None = None
    issued_at: str | None = None


@dataclass
class ProfileConfig:
    username: str | None = None
    tenant_slug: str | None = None
    tenant_display_name: str | None = None


@dataclass
class RawctxConfig:
    registry: str = DEFAULT_REGISTRY
    auth: AuthConfig = field(default_factory=AuthConfig)
    profile: ProfileConfig = field(default_factory=ProfileConfig)


@dataclass(frozen=True)
class AppPaths:
    home_dir: Path
    config_path: Path
    cache_dir: Path
    packages_dir: Path
    archives_dir: Path
    package_index_path: Path

    @classmethod
    def discover(cls, config_path: str | Path | None = None) -> "AppPaths":
        configured = config_path if config_path is not None else os.getenv("RAWCTX_CONFIG")
        if configured:
            config_path = Path(configured).expanduser().resolve()
            home_dir = config_path.parent
        else:
            home_dir = Path.home() / ".rawctx"
            config_path = home_dir / "config.yaml"

        cache_dir = home_dir / "cache"
        packages_dir = home_dir / "packages"
        archives_dir = cache_dir / "archives"
        package_index_path = cache_dir / "packages.json"
        return cls(
            home_dir=home_dir,
            config_path=config_path,
            cache_dir=cache_dir,
            packages_dir=packages_dir,
            archives_dir=archives_dir,
            package_index_path=package_index_path,
        )

    def ensure(self) -> None:
        self.home_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.packages_dir.mkdir(parents=True, exist_ok=True)
        self.archives_dir.mkdir(parents=True, exist_ok=True)

    def archive_path(self, scope: str, name: str, version: str, *, registry: str | None = None) -> Path:
        return self.archives_dir / registry_cache_segment(registry) / f"@{scope}" / name / f"{version}.rawctx.tar.gz"

    def install_path(
        self,
        scope: str,
        name: str,
        version: str,
        *,
        registry: str | None = None,
        destination: Path | None = None,
    ) -> Path:
        root = destination if destination is not None else self.packages_dir
        return root / registry_cache_segment(registry) / f"@{scope}" / name / version


class ConfigStore:
    def __init__(self, paths: AppPaths | None = None, *, config_path: str | Path | None = None) -> None:
        self.paths = paths or AppPaths.discover(config_path=config_path)

    def load(self) -> RawctxConfig:
        self.paths.ensure()
        if not self.paths.config_path.exists():
            return RawctxConfig()

        try:
            with self.paths.config_path.open("r", encoding="utf-8") as handle:
                raw = yaml.safe_load(handle) or {}
        except OSError as exc:
            raise RuntimeError(f"Failed to read config: {self.paths.config_path}") from exc

        if not isinstance(raw, dict):
            return RawctxConfig()

        auth_raw = raw.get("auth") if isinstance(raw.get("auth"), dict) else {}
        profile_raw = raw.get("profile") if isinstance(raw.get("profile"), dict) else {}

        return RawctxConfig(
            registry=str(raw.get("registry") or DEFAULT_REGISTRY).rstrip("/"),
            auth=AuthConfig(
                token=_as_optional_str(auth_raw.get("token")),
                token_id=_as_optional_str(auth_raw.get("token_id")),
                token_name=_as_optional_str(auth_raw.get("token_name")),
                issued_at=_as_optional_str(auth_raw.get("issued_at")),
            ),
            profile=ProfileConfig(
                username=_as_optional_str(profile_raw.get("username")),
                tenant_slug=_as_optional_str(profile_raw.get("tenant_slug")),
                tenant_display_name=_as_optional_str(profile_raw.get("tenant_display_name")),
            ),
        )

    def save(self, config: RawctxConfig) -> None:
        self.paths.ensure()
        payload: dict[str, Any] = {
            "registry": config.registry.rstrip("/"),
            "auth": {
                "token": config.auth.token,
                "token_id": config.auth.token_id,
                "token_name": config.auth.token_name,
                "issued_at": config.auth.issued_at,
            },
            "profile": {
                "username": config.profile.username,
                "tenant_slug": config.profile.tenant_slug,
                "tenant_display_name": config.profile.tenant_display_name,
            },
        }

        try:
            with self.paths.config_path.open("w", encoding="utf-8") as handle:
                yaml.safe_dump(payload, handle, sort_keys=False)
        except OSError as exc:
            raise RuntimeError(f"Failed to write config: {self.paths.config_path}") from exc

    def save_auth(
        self,
        *,
        config: RawctxConfig,
        token: str,
        token_id: str,
        token_name: str,
        username: str | None,
        tenant_slug: str | None = None,
        tenant_display_name: str | None = None,
    ) -> None:
        config.auth.token = token
        config.auth.token_id = token_id
        config.auth.token_name = token_name
        config.auth.issued_at = datetime.now(timezone.utc).isoformat()
        if username:
            config.profile.username = username
        if tenant_slug:
            config.profile.tenant_slug = tenant_slug
        if tenant_display_name:
            config.profile.tenant_display_name = tenant_display_name
        self.save(config)

    def clear_auth(self, config: RawctxConfig) -> None:
        config.auth = AuthConfig()
        self.save(config)


def resolve_registry(*, cli_registry: str | None, config: RawctxConfig | None = None) -> str:
    if cli_registry:
        return cli_registry.rstrip("/")

    env_registry = os.getenv("RAWCTX_REGISTRY", "").strip()
    if env_registry:
        return env_registry.rstrip("/")

    if config is not None and config.registry:
        return config.registry.rstrip("/")

    return DEFAULT_REGISTRY


def resolve_token(config: RawctxConfig | None) -> str | None:
    env_token = os.getenv("RAWCTX_TOKEN", "").strip()
    if env_token:
        return env_token
    if config is None:
        return None
    return config.auth.token


def load_package_cache(paths: AppPaths) -> dict[str, dict[str, Any]]:
    paths.ensure()
    if not paths.package_index_path.exists():
        return {}

    try:
        with paths.package_index_path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return {}

    if not isinstance(payload, dict):
        return {}

    valid: dict[str, dict[str, Any]] = {}
    for key, value in payload.items():
        if isinstance(key, str) and isinstance(value, dict):
            valid[key] = value
    return valid


def save_package_cache(paths: AppPaths, cache: dict[str, dict[str, Any]]) -> None:
    paths.ensure()
    try:
        with paths.package_index_path.open("w", encoding="utf-8") as handle:
            json.dump(cache, handle, indent=2, sort_keys=True)
            handle.write("\n")
    except OSError as exc:
        raise RuntimeError(f"Failed to write cache: {paths.package_index_path}") from exc


def registry_cache_segment(registry: str | None) -> str:
    if not registry:
        return "default"

    parsed = urlparse(registry)
    host = (parsed.netloc or parsed.path or "default").strip().lower()
    path = parsed.path.strip().lower() if parsed.netloc else ""
    combined = host if not path else f"{host}{path}"
    cleaned = re.sub(r"[^a-z0-9._/-]+", "-", combined).strip("-/")
    return cleaned.replace("/", "__") or "default"


def cache_key(scope: str, name: str, registry: str | None = None) -> str:
    return f"{registry_cache_segment(registry)}::@{scope}/{name}"


def upsert_cache_entry(
    cache: dict[str, dict[str, Any]],
    *,
    scope: str,
    name: str,
    registry: str | None = None,
    package: dict[str, Any] | None = None,
    versions: list[dict[str, Any]] | None = None,
) -> None:
    key = cache_key(scope, name, registry)
    entry = cache.get(key, {})

    if package is not None:
        entry["package"] = package
    if versions is not None:
        entry["versions"] = versions

    entry["last_seen_at"] = datetime.now(timezone.utc).isoformat()
    cache[key] = entry


def _as_optional_str(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None
