from __future__ import annotations


class RawctxError(RuntimeError):
    """Base error for public rawctx SDK operations."""


class UsageError(RawctxError):
    """Invalid user input or unsupported invocation."""


class AuthRequiredError(RawctxError):
    """Authentication is required for this operation."""


class RegistryError(RawctxError):
    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        detail: str | None = None,
        payload: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail
        self.payload = payload


class ValidationError(RawctxError):
    """Local package or format validation failed."""


class OfflineCacheMissError(RawctxError):
    """Requested offline data is unavailable in the local cache."""
