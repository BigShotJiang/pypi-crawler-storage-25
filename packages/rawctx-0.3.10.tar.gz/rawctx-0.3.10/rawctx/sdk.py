from __future__ import annotations

import asyncio
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from difflib import SequenceMatcher
import os
from pathlib import Path
import time
import warnings
import webbrowser
from typing import Any, Callable, Iterable

from rawctx.config import (
    ConfigStore,
    RawctxConfig,
    cache_key,
    load_package_cache,
    registry_cache_segment,
    resolve_registry,
    resolve_token,
    save_package_cache,
    upsert_cache_entry,
)
from rawctx.converter import get_conversion_registry
from rawctx.converter.base import ConversionError
from rawctx.converter.metricflow_to_osi import build_converted_package
from rawctx.downloads import (
    FileMaterialization,
    SnapshotMaterialization,
    copy_model_file,
    copy_snapshot,
    ensure_clean_dir,
    extract_archive,
    indexed_blocked_message,
    load_snapshot_manifest,
    select_cached_version,
    snapshot_matches,
    validate_force_target_dir,
    validate_model_path,
)
from rawctx.errors import AuthRequiredError, OfflineCacheMissError, RawctxError, RegistryError, UsageError, ValidationError
from rawctx.indexer import GitIndexEntry, IndexRunResult, index_dbt_seed_entry, index_git_repo, load_dbt_seed_entries
from rawctx.package_ops import materialize_package, resolve_package_name, resolve_version
from rawctx.packaging.builder import build_package_archive
from rawctx.packaging.manifest import ValidationError as ManifestValidationError
from rawctx.prompting import build_prompt
from rawctx.registry.auth import extract_username_from_jwt, start_oauth_login, wait_for_oauth_id_token
from rawctx.registry.client import AsyncRegistryClient, RegistryClient
from rawctx.registry.models import PackageDetail, SearchItem, VersionInfo, choose_latest_version, parse_package_ref
from rawctx.semantic import Dimension, LoadedPackage, Measure, Relationship, SemanticModel, build_loaded_package
from rawctx.validation import ValidateResult, validate_target


ProgressCallback = Callable[[dict[str, Any]], None]
PromptCallback = Callable[[str], str]
SearchTags = str | Iterable[str] | None

def _read_boolean_flag(name: str, default_value: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default_value
    return raw.strip().lower() not in {"0", "false", "no", "off"}


HIDE_ACTIVITY_SIGNALS = _read_boolean_flag("RAWCTX_HIDE_ACTIVITY_SIGNALS", True)
PUBLIC_SEARCH_SORTS = ("recent", "name")
LEGACY_SEARCH_SORTS = ("downloads", "stars")
_SEARCH_SORTS = set(PUBLIC_SEARCH_SORTS + LEGACY_SEARCH_SORTS)
_ACTIVITY_SIGNAL_KEYS = {"download_count", "star_count"}


@dataclass(frozen=True)
class _OnlinePackageSelection:
    package: PackageDetail
    versions: list[VersionInfo]
    version: str


def _emit(progress: ProgressCallback | None, event: dict[str, Any]) -> None:
    if progress is not None:
        progress(event)


def _strip_activity_signals(value: Any) -> Any:
    if not HIDE_ACTIVITY_SIGNALS:
        return value
    if isinstance(value, dict):
        return {
            key: _strip_activity_signals(item)
            for key, item in value.items()
            if key not in _ACTIVITY_SIGNAL_KEYS
        }
    if isinstance(value, list):
        return [_strip_activity_signals(item) for item in value]
    return value


def _serialize_search_items(items: list[SearchItem], meta: dict[str, Any]) -> dict[str, Any]:
    payload = {
        "items": [asdict(item) for item in items],
        "meta": meta,
    }
    return _strip_activity_signals(payload)


def _search_result_has_matches(result: SearchResult) -> bool:
    if result.items:
        return True
    total = result.meta.get("total")
    try:
        return int(total or 0) > 0
    except (TypeError, ValueError):
        return False


def _serialize_validate_result(result: ValidateResult) -> dict[str, Any]:
    dataset_measures: list[dict[str, Any]] = []
    total = {"datasets": 0, "measures": 0, "dimensions": 0, "relationships": 0, "ai_context": False}
    for summary in result.osi_summaries.values():
        total["datasets"] += summary.datasets
        total["measures"] += summary.measures
        total["dimensions"] += summary.dimensions
        total["relationships"] += summary.relationships
        total["ai_context"] = total["ai_context"] or summary.has_ai_context
        for detail in summary.dataset_measures:
            item = asdict(detail)
            item["measures"] = list(item.get("measures", []))
            dataset_measures.append(item)

    return {
        "target": str(result.target),
        "validated_files": [str(path) for path in result.validated_files],
        "manifest": asdict(result.manifest) if result.manifest is not None else None,
        "summary": total,
        "dataset_measures": dataset_measures,
    }


def _serialize_index_results(
    *,
    mode: str,
    results: list[IndexRunResult],
    seed_file: Path | None = None,
) -> dict[str, Any]:
    payload = {
        "mode": mode,
        "results": [asdict(item) for item in results],
        "summary": {
            "total": len(results),
            "indexed": sum(1 for item in results if item.status == "indexed"),
            "skipped": sum(1 for item in results if item.status == "skipped"),
            "dry_run": sum(1 for item in results if item.status == "dry-run"),
            "failed": sum(1 for item in results if item.status == "failed"),
        },
    }
    if seed_file is not None:
        payload["seed_file"] = str(seed_file)
    return payload


def _serialize_snapshot_materialization(result: SnapshotMaterialization) -> dict[str, Any]:
    return {
        "package": result.package,
        "version": result.version,
        "local_path": str(result.local_path),
        "files": list(result.files),
    }


def _serialize_file_materialization(result: FileMaterialization) -> dict[str, Any]:
    return {
        "package": result.package,
        "version": result.version,
        "path": result.path,
        "local_path": str(result.local_path),
    }


def _load_snapshot_materialization(result: SnapshotMaterialization) -> LoadedPackage:
    return build_loaded_package(
        package=result.package,
        version=result.version,
        snapshot_dir=result.local_path,
        model_paths=result.manifest.models,
        format_name=result.manifest.format,
    )


def _cache_search_items(cache: dict[str, dict[str, Any]], *, registry: str, items: list[SearchItem]) -> None:
    for item in items:
        upsert_cache_entry(
            cache,
            scope=item.scope,
            name=item.name,
            registry=registry,
            package={
                "id": item.id,
                "scope": item.scope,
                "name": item.name,
                "description": item.description,
                "format": item.format,
                "source_format": item.source_format,
                "origin": item.origin,
                "origin_url": item.origin_url,
                "origin_repo": item.origin_repo,
                "source": item.source,
                "domain": item.domain,
                "latest_osi_version": item.latest_osi_version,
                "tags": item.tags,
                "download_count": item.download_count,
                "star_count": item.star_count,
            },
        )


def _search_remote_public_first(
    *,
    registry: str,
    token: str | None,
    timeout: float,
    query: str | None,
    format: str | None,
    source_format: str | None,
    origin: str,
    domain: str | None,
    source: str | None,
    tags: str | None,
    sort: str,
    page: int,
    size: int,
) -> SearchResult:
    request_kwargs = {
        "query": query,
        "format": format,
        "source_format": source_format,
        "origin": origin,
        "domain": domain,
        "source": source,
        "tags": tags,
        "sort": sort,
        "page": page,
        "size": size,
    }
    with RegistryClient(registry=registry, token=None, timeout=timeout) as registry_client:
        public_result = registry_client.search_packages(**request_kwargs)
    if _search_result_has_matches(public_result) or not token:
        return public_result
    with RegistryClient(registry=registry, token=token, timeout=timeout) as registry_client:
        return registry_client.search_packages(**request_kwargs)


async def _search_remote_public_first_async(
    *,
    registry: str,
    token: str | None,
    timeout: float,
    query: str | None,
    format: str | None,
    source_format: str | None,
    origin: str,
    domain: str | None,
    source: str | None,
    tags: str | None,
    sort: str,
    page: int,
    size: int,
) -> SearchResult:
    request_kwargs = {
        "query": query,
        "format": format,
        "source_format": source_format,
        "origin": origin,
        "domain": domain,
        "source": source,
        "tags": tags,
        "sort": sort,
        "page": page,
        "size": size,
    }
    async with AsyncRegistryClient(registry=registry, token=None, timeout=timeout) as registry_client:
        public_result = await registry_client.search_packages(**request_kwargs)
    if _search_result_has_matches(public_result) or not token:
        return public_result
    async with AsyncRegistryClient(registry=registry, token=token, timeout=timeout) as registry_client:
        return await registry_client.search_packages(**request_kwargs)


def _resolve_runtime(
    *,
    config_path: str | Path | None,
    registry_override: str | None,
    token_override: str | None,
) -> tuple[ConfigStore, RawctxConfig, str, str | None]:
    store = ConfigStore(config_path=config_path)
    config = store.load()
    registry = resolve_registry(cli_registry=registry_override, config=config)
    token = token_override.strip() if token_override else resolve_token(config)
    return store, config, registry, token


def _normalize_tags_for_query(tags: SearchTags) -> tuple[str | None, list[str]]:
    if tags is None:
        return None, []
    if isinstance(tags, str):
        cleaned = [tag.strip() for tag in tags.split(",") if tag.strip()]
    else:
        cleaned = [str(tag).strip() for tag in tags if str(tag).strip()]
    return (", ".join(cleaned) if cleaned else None), [tag.lower() for tag in cleaned]


def _validate_search_args(page: int, size: int, sort: str) -> str:
    if page < 1:
        raise UsageError("--page must be >= 1")
    if size < 1 or size > 100:
        raise UsageError("--size must be between 1 and 100")
    normalized = sort.strip().lower()
    if normalized not in _SEARCH_SORTS:
        visible = ", ".join(PUBLIC_SEARCH_SORTS if HIDE_ACTIVITY_SIGNALS else PUBLIC_SEARCH_SORTS + LEGACY_SEARCH_SORTS)
        raise UsageError(f"--sort must be one of: {visible}")
    if HIDE_ACTIVITY_SIGNALS and normalized in LEGACY_SEARCH_SORTS:
        warnings.warn(
            f'--sort {normalized} is hidden while RAWCTX_HIDE_ACTIVITY_SIGNALS is enabled; using "recent" instead.',
            UserWarning,
            stacklevel=2,
        )
        return "recent"
    return normalized


def _cache_scope_name_from_key(key: str) -> tuple[str, str] | None:
    _, sep, raw = key.partition("::")
    if not sep or not raw.startswith("@"):
        return None
    without_sig = raw[1:]
    scope, slash, name = without_sig.partition("/")
    if not slash or not scope or not name:
        return None
    return scope, name


def _search_cache(
    cache: dict[str, dict[str, Any]],
    *,
    registry: str,
    query: str | None,
    format_filter: str | None,
    source_format_filter: str | None,
    origin_filter: str,
    domain: str | None,
    source: str | None,
    tags: SearchTags,
    sort: str,
    page: int,
    size: int,
) -> tuple[list[SearchItem], dict[str, Any]]:
    tag_query, tag_filters = _normalize_tags_for_query(tags)
    normalized_query = (query or "").strip().lower()
    registry_prefix = f"{registry_cache_segment(registry)}::"

    candidates: list[tuple[SearchItem, str, str]] = []
    matched: list[tuple[SearchItem, str]] = []

    for key, entry in cache.items():
        if not key.startswith(registry_prefix):
            continue

        package = entry.get("package")
        if not isinstance(package, dict):
            continue

        scope = str(package.get("scope") or "")
        name = str(package.get("name") or "")
        if not scope or not name:
            parsed = _cache_scope_name_from_key(key)
            if parsed is None:
                continue
            scope, name = parsed

        package_tags = [str(tag).strip() for tag in package.get("tags", []) if str(tag).strip()]
        if format_filter and str(package.get("format") or "").lower() != format_filter.lower():
            continue
        if source_format_filter and str(package.get("source_format") or "").lower() != source_format_filter.lower():
            continue
        if origin_filter != "all" and str(package.get("origin") or "native").lower() != origin_filter.lower():
            continue
        if domain and str(package.get("domain") or "").lower() != domain.lower():
            continue
        if source and str(package.get("source") or "").lower() != source.lower():
            continue
        if tag_filters:
            lowered_tags = {tag.lower() for tag in package_tags}
            if not set(tag_filters).issubset(lowered_tags):
                continue

        item = SearchItem(
            id=str(package.get("id") or key),
            scope=scope,
            name=name,
            description=package.get("description") if isinstance(package.get("description"), str) else None,
            format=str(package.get("format") or "unknown"),
            source_format=package.get("source_format") if isinstance(package.get("source_format"), str) else None,
            origin=str(package.get("origin") or "native"),
            origin_url=package.get("origin_url") if isinstance(package.get("origin_url"), str) else None,
            origin_repo=package.get("origin_repo") if isinstance(package.get("origin_repo"), str) else None,
            source=package.get("source") if isinstance(package.get("source"), str) else None,
            domain=package.get("domain") if isinstance(package.get("domain"), str) else None,
            tags=package_tags,
            download_count=int(package.get("download_count") or 0),
            star_count=int(package.get("star_count") or 0),
            latest_osi_version=package.get("latest_osi_version")
            if isinstance(package.get("latest_osi_version"), str)
            else None,
        )
        haystack = " ".join(
            [
                f"@{scope}/{name}",
                str(package.get("description") or ""),
                str(package.get("readme") or ""),
                str(package.get("format") or ""),
                str(package.get("source_format") or ""),
                str(package.get("source") or ""),
                str(package.get("domain") or ""),
                " ".join(package_tags),
            ]
        ).lower()
        last_seen_at = str(entry.get("last_seen_at") or "")
        candidates.append((item, haystack, last_seen_at))
        if normalized_query and normalized_query not in haystack:
            continue
        matched.append((item, last_seen_at))

    if sort == "downloads":
        matched.sort(key=lambda item: (item[0].download_count, item[0].star_count, item[1], item[0].package_name), reverse=True)
    elif sort == "stars":
        matched.sort(key=lambda item: (item[0].star_count, item[0].download_count, item[1], item[0].package_name), reverse=True)
    elif sort == "name":
        matched.sort(key=lambda item: item[0].package_name.lower())
    else:
        matched.sort(key=lambda item: (item[1], item[0].download_count, item[0].star_count, item[0].package_name), reverse=True)

    expanded = False
    if normalized_query and not matched and candidates:
        scored: list[tuple[float, SearchItem, str]] = []
        for item, haystack, last_seen_at in candidates:
            score = SequenceMatcher(None, normalized_query, haystack).ratio()
            if score >= 0.2:
                scored.append((score, item, last_seen_at))
        if sort == "recent":
            scored.sort(key=lambda row: (row[0], row[2], row[1].download_count, row[1].star_count), reverse=True)
        elif sort == "stars":
            scored.sort(key=lambda row: (row[0], row[1].star_count, row[1].download_count, row[2]), reverse=True)
        elif sort == "name":
            scored.sort(key=lambda row: (-row[0], row[1].package_name.lower()))
        else:
            scored.sort(key=lambda row: (row[0], row[1].download_count, row[1].star_count, row[2]), reverse=True)
        matched = [(row[1], row[2]) for row in scored]
        expanded = True

    total = len(matched)
    start = (page - 1) * size
    end = start + size
    paged = [row[0] for row in matched[start:end]]
    return paged, {
        "page": page,
        "size": size,
        "total": total,
        "sort": sort,
        "cached_at": int(datetime.now(timezone.utc).timestamp()),
        "query_mode": "expanded" if expanded else "exact",
        "expanded": expanded,
        "applied_rewrite": normalized_query or None,
        "tags": tag_query,
    }


def _load_info_offline(
    cache: dict[str, dict[str, Any]],
    registry: str,
    scope: str,
    name: str,
) -> tuple[PackageDetail, list[VersionInfo]]:
    entry = cache.get(cache_key(scope, name, registry))
    if not entry:
        raise OfflineCacheMissError(f"No cached package found for @{scope}/{name}")

    package_raw = entry.get("package")
    if not isinstance(package_raw, dict):
        raise OfflineCacheMissError(f"Cached package data is invalid for @{scope}/{name}")

    versions_raw = entry.get("versions")
    versions: list[VersionInfo] = []
    if isinstance(versions_raw, list):
        for item in versions_raw:
            if isinstance(item, dict):
                versions.append(VersionInfo.from_api(item))

    return PackageDetail.from_api(package_raw), versions


def _wrap_manifest_error(exc: ManifestValidationError | ValueError | RuntimeError) -> ValidationError:
    return ValidationError(str(exc))


def _model_paths_from_version(version: VersionInfo | None) -> list[str]:
    if version is None or not isinstance(version.manifest, dict):
        return []
    models = version.manifest.get("models")
    if not isinstance(models, list):
        return []
    return [item.strip() for item in models if isinstance(item, str) and item.strip()]


def _serialize_info_payload(
    *,
    package: PackageDetail,
    versions: list[VersionInfo],
    selected_version: VersionInfo | None,
) -> dict[str, Any]:
    target_version = selected_version if selected_version is not None else (versions[0] if versions else None)
    payload = {
        "package": asdict(package),
        "versions": [asdict(item) for item in versions],
        "selected_version": asdict(selected_version) if selected_version else None,
        "model_paths": _model_paths_from_version(target_version),
        "model_paths_version": target_version.version if target_version is not None else None,
    }
    return _strip_activity_signals(payload)


def _select_latest_version_from_infos(versions: list[VersionInfo]) -> str | None:
    return choose_latest_version(item.version for item in versions)


def _update_package_cache(
    cache: dict[str, dict[str, Any]],
    *,
    registry: str,
    package: PackageDetail,
    versions: list[VersionInfo],
) -> None:
    upsert_cache_entry(
        cache,
        scope=package.scope,
        name=package.name,
        registry=registry,
        package=asdict(package),
        versions=[asdict(item) for item in versions],
    )


def _resolve_online_package_selection(
    *,
    registry: str,
    token: str | None,
    timeout: float,
    scope: str,
    name: str,
    preferred_version: str | None,
) -> _OnlinePackageSelection:
    with RegistryClient(registry=registry, token=token, timeout=timeout) as registry_client:
        package = registry_client.get_package(scope=scope, name=name)
        if package.origin == "indexed":
            raise RawctxError(
                indexed_blocked_message(
                    package_name=package.package_name,
                    source=package.source,
                    origin_url=package.origin_url,
                )
            )
        versions, _meta = registry_client.list_versions(scope=scope, name=name, page=1, size=100)
    selected_version = preferred_version or _select_latest_version_from_infos(versions)
    if not selected_version:
        raise RawctxError(f"No downloadable version found for @{scope}/{name}")
    return _OnlinePackageSelection(package=package, versions=versions, version=selected_version)


async def _resolve_online_package_selection_async(
    *,
    registry: str,
    token: str | None,
    timeout: float,
    scope: str,
    name: str,
    preferred_version: str | None,
) -> _OnlinePackageSelection:
    async with AsyncRegistryClient(registry=registry, token=token, timeout=timeout) as registry_client:
        package = await registry_client.get_package(scope=scope, name=name)
        if package.origin == "indexed":
            raise RawctxError(
                indexed_blocked_message(
                    package_name=package.package_name,
                    source=package.source,
                    origin_url=package.origin_url,
                )
            )
        versions, _meta = await registry_client.list_versions(scope=scope, name=name, page=1, size=100)
    selected_version = preferred_version or _select_latest_version_from_infos(versions)
    if not selected_version:
        raise RawctxError(f"No downloadable version found for @{scope}/{name}")
    return _OnlinePackageSelection(package=package, versions=versions, version=selected_version)


def _download_archive_bytes(
    *,
    registry: str,
    token: str | None,
    timeout: float,
    scope: str,
    name: str,
    version: str,
) -> bytes:
    with RegistryClient(registry=registry, token=token, timeout=timeout) as registry_client:
        try:
            download = registry_client.request_download(scope=scope, name=name, version=version)
        except RegistryError as exc:
            payload = exc.payload if isinstance(exc.payload, dict) else {}
            if exc.status_code == 403 and payload.get("error") == "indexed_package":
                raise RawctxError(
                    indexed_blocked_message(
                        package_name=f"@{scope}/{name}",
                        source=str(payload.get("source") or ""),
                        origin_url=str(payload.get("origin_url") or ""),
                        claim_hint=str(payload.get("claim_url") or f"rawctx claim @{scope}/{name}"),
                    )
                ) from exc
            raise
        download_url = str(download.get("download_url") or "")
        if not download_url:
            raise RawctxError("Registry did not return download_url")
        return registry_client.download_bytes(download_url=download_url)


async def _download_archive_bytes_async(
    *,
    registry: str,
    token: str | None,
    timeout: float,
    scope: str,
    name: str,
    version: str,
) -> bytes:
    async with AsyncRegistryClient(registry=registry, token=token, timeout=timeout) as registry_client:
        try:
            download = await registry_client.request_download(scope=scope, name=name, version=version)
        except RegistryError as exc:
            payload = exc.payload if isinstance(exc.payload, dict) else {}
            if exc.status_code == 403 and payload.get("error") == "indexed_package":
                raise RawctxError(
                    indexed_blocked_message(
                        package_name=f"@{scope}/{name}",
                        source=str(payload.get("source") or ""),
                        origin_url=str(payload.get("origin_url") or ""),
                        claim_hint=str(payload.get("claim_url") or f"rawctx claim @{scope}/{name}"),
                    )
                ) from exc
            raise
        download_url = str(download.get("download_url") or "")
        if not download_url:
            raise RawctxError("Registry did not return download_url")
        return await registry_client.download_bytes(download_url=download_url)


def _materialize_snapshot_from_cache_or_archive(
    *,
    store: ConfigStore,
    registry: str,
    scope: str,
    name: str,
    version: str,
    local_dir: str | Path | None,
    force: bool,
    archive_bytes: bytes | None,
) -> SnapshotMaterialization:
    package_name = f"@{scope}/{name}"
    snapshot_root = store.paths.install_path(scope, name, version, registry=registry)
    target_root = Path(local_dir).expanduser().resolve() if local_dir is not None else snapshot_root

    target_matches = snapshot_matches(target_root, package_name=package_name, version=version)
    if target_matches and not force:
        manifest = load_snapshot_manifest(target_root)
        return SnapshotMaterialization(package=package_name, version=version, local_path=target_root, files=list(manifest.models), manifest=manifest)

    if target_root.exists() and not target_matches and not force:
        raise RawctxError(f"Snapshot target already exists: {target_root}. Use --force to overwrite.")

    if force and target_root.resolve() != snapshot_root.resolve():
        validate_force_target_dir(target_root, package_name=package_name)

    cache_matches = snapshot_matches(snapshot_root, package_name=package_name, version=version)
    if cache_matches and not force:
        manifest = load_snapshot_manifest(snapshot_root)
    else:
        archive_path = store.paths.archive_path(scope, name, version, registry=registry)
        if archive_bytes is None:
            if not archive_path.exists():
                raise OfflineCacheMissError(f"No cached archive found for {package_name}@{version}")
            archive_bytes = archive_path.read_bytes()
        else:
            archive_path.parent.mkdir(parents=True, exist_ok=True)
            archive_path.write_bytes(archive_bytes)

        ensure_clean_dir(snapshot_root)
        extract_archive(archive_bytes=archive_bytes, target_dir=snapshot_root)
        manifest = load_snapshot_manifest(snapshot_root)

    if target_root.resolve() != snapshot_root.resolve():
        copy_snapshot(source_dir=snapshot_root, target_dir=target_root, force=force)
        manifest = load_snapshot_manifest(target_root)

    return SnapshotMaterialization(package=package_name, version=version, local_path=target_root, files=list(manifest.models), manifest=manifest)


def _download_model_from_snapshot(
    *,
    snapshot: SnapshotMaterialization,
    model_path: str,
    local_dir: str | Path | None,
    force: bool,
) -> FileMaterialization:
    selected_path = validate_model_path(snapshot.manifest, model_path)
    if local_dir is None:
        local_path = (snapshot.local_path / selected_path).resolve()
        if not local_path.is_file():
            raise RawctxError(f"Model file declared in manifest is missing: {selected_path}")
        return FileMaterialization(package=snapshot.package, version=snapshot.version, path=selected_path, local_path=local_path)

    local_root = Path(local_dir).expanduser().resolve()
    local_path = copy_model_file(source_root=snapshot.local_path, model_path=selected_path, local_dir=local_root, force=force)
    return FileMaterialization(package=snapshot.package, version=snapshot.version, path=selected_path, local_path=local_path)


async def _wait_for_oauth_id_token_async(
    *,
    client: AsyncRegistryClient,
    session_id: str,
    timeout_seconds: int = 300,
    poll_interval_seconds: int = 2,
) -> str:
    deadline = time.monotonic() + timeout_seconds
    poll_interval = max(1, poll_interval_seconds)

    while True:
        if time.monotonic() >= deadline:
            raise RegistryError("Timed out waiting for OAuth login completion. Retry `rawctx login`.")

        try:
            session = await client.oauth_login_session(session_id)
        except RegistryError as exc:
            if exc.status_code in {404, 405}:
                try:
                    session = await client.oauth_login_session_github(session_id)
                except RegistryError as legacy_exc:
                    if legacy_exc.status_code == 404:
                        raise RegistryError("OAuth login session expired. Retry `rawctx login`.") from legacy_exc
                    raise
            else:
                raise

        status = session.status.strip().lower()
        if status == "ready":
            if session.id_token:
                return session.id_token
            raise RegistryError("OAuth login completed but id_token is missing.")

        if status == "error":
            reason = session.error_description or session.error or "OAuth login failed"
            raise RegistryError(f"OAuth login failed: {reason}")

        await asyncio.sleep(poll_interval)


class RawctxClient:
    def __init__(
        self,
        *,
        registry: str | None = None,
        token: str | None = None,
        config_path: str | Path | None = None,
        timeout: float = 20.0,
    ) -> None:
        self.registry_override = registry
        self.token_override = token
        self.config_path = config_path
        self.timeout = timeout

    def close(self) -> None:
        return None

    def __enter__(self) -> "RawctxClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # type: ignore[no-untyped-def]
        self.close()

    def login(
        self,
        *,
        id_token: str | None = None,
        token_name: str = "rawctx-cli",
        expires_in_days: int | None = None,
        no_browser: bool = False,
        progress: ProgressCallback | None = None,
        prompt_for_id_token: PromptCallback | None = None,
    ) -> dict[str, Any]:
        store, config, registry, _token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        config.registry = registry

        with RegistryClient(registry=registry, timeout=self.timeout) as registry_client:
            login_info = start_oauth_login(client=registry_client, open_browser=not no_browser)
            prompt_label = login_info.provider_label or "Sign in"
            _emit(
                progress,
                {
                    "type": "authorize_url",
                    "authorize_url": login_info.authorize_url,
                    "prompt_label": prompt_label,
                },
            )

            provided_token = id_token.strip() if id_token else ""
            if not provided_token:
                if login_info.session_id:
                    _emit(progress, {"type": "waiting"})
                    provided_token = wait_for_oauth_id_token(
                        client=registry_client,
                        session_id=login_info.session_id,
                        poll_interval_seconds=login_info.poll_interval_seconds,
                    )
                else:
                    _emit(progress, {"type": "manual_token_required"})
                    if prompt_for_id_token is None:
                        raise UsageError("Automatic token capture is unavailable on this registry. Pass id_token explicitly.")
                    provided_token = prompt_for_id_token("id_token").strip()

            if not provided_token:
                raise UsageError("id_token is required")

            token_info = registry_client.create_api_token(
                id_token=provided_token,
                name=token_name,
                expires_in_days=expires_in_days,
            )
            username = extract_username_from_jwt(provided_token) or config.profile.username
            tenant_slug = config.profile.tenant_slug
            tenant_display_name = config.profile.tenant_display_name
            try:
                me = registry_client.get_me(token=token_info.token)
            except RegistryError:
                me = None
            if me is not None:
                username = me.username or username
                tenant_slug = me.tenant.slug
                tenant_display_name = me.tenant.display_name
            store.save_auth(
                config=config,
                token=token_info.token,
                token_id=token_info.id,
                token_name=token_info.name,
                username=username,
                tenant_slug=tenant_slug,
                tenant_display_name=tenant_display_name,
            )

        return {
            "registry": registry,
            "token_id": token_info.id,
            "token_name": token_info.name,
            "username": username,
            "tenant_slug": tenant_slug,
            "tenant_display_name": tenant_display_name,
            "config_path": str(store.paths.config_path),
        }

    def logout(self, *, local_only: bool = False) -> dict[str, Any]:
        store, config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )

        had_token = bool(config.auth.token)
        if not had_token:
            return {
                "had_token": False,
                "local_only": local_only,
                "revoked": False,
                "config_path": str(store.paths.config_path),
            }

        revoked = False
        if not local_only and token and config.auth.token_id:
            with RegistryClient(registry=registry, token=token, timeout=self.timeout) as registry_client:
                revoked = registry_client.revoke_api_token(config.auth.token_id)

        store.clear_auth(config)
        return {
            "had_token": True,
            "local_only": local_only,
            "revoked": revoked,
            "config_path": str(store.paths.config_path),
        }

    def search(
        self,
        query: str | None = None,
        *,
        format: str | None = None,
        source_format: str | None = None,
        origin: str = "all",
        domain: str | None = None,
        source: str | None = None,
        tags: SearchTags = None,
        sort: str = "recent",
        page: int = 1,
        size: int = 20,
        offline: bool = False,
    ) -> dict[str, Any]:
        normalized_sort = _validate_search_args(page, size, sort)
        store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        cache = load_package_cache(store.paths)

        if offline:
            items, meta = _search_cache(
                cache,
                registry=registry,
                query=query,
                format_filter=format,
                source_format_filter=source_format,
                origin_filter=origin.lower(),
                domain=domain,
                source=source,
                tags=tags,
                sort=normalized_sort,
                page=page,
                size=size,
            )
            return _serialize_search_items(items, meta)

        tags_query, _tag_filters = _normalize_tags_for_query(tags)
        result = _search_remote_public_first(
            registry=registry,
            token=token,
            timeout=self.timeout,
            query=query,
            format=format,
            source_format=source_format,
            origin=origin.lower(),
            domain=domain,
            source=source,
            tags=tags_query,
            sort=normalized_sort,
            page=page,
            size=size,
        )

        _cache_search_items(cache, registry=registry, items=result.items)
        save_package_cache(store.paths, cache)
        return _serialize_search_items(result.items, result.meta)

    def info(self, package_ref: str, *, offline: bool = False) -> dict[str, Any]:
        try:
            parsed = parse_package_ref(package_ref)
        except ValueError as exc:
            raise UsageError(str(exc)) from exc

        store, config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        cache = load_package_cache(store.paths)

        if offline:
            package, versions = _load_info_offline(cache, registry, parsed.scope, parsed.name)
        else:
            with RegistryClient(registry=registry, token=token, timeout=self.timeout) as registry_client:
                package = registry_client.get_package(scope=parsed.scope, name=parsed.name)
                versions, _meta = registry_client.list_versions(scope=parsed.scope, name=parsed.name, page=1, size=100)

            upsert_cache_entry(
                cache,
                scope=parsed.scope,
                name=parsed.name,
                registry=registry,
                package=asdict(package),
                versions=[asdict(item) for item in versions],
            )
            save_package_cache(store.paths, cache)

        selected_version = None
        if parsed.version:
            selected_version = next((item for item in versions if item.version == parsed.version), None)
            if selected_version is None:
                raise RawctxError(f"Version not found: {parsed.normalized}")

        return _serialize_info_payload(package=package, versions=versions, selected_version=selected_version)

    def _snapshot_download_materialized(
        self,
        package_ref: str,
        *,
        local_dir: str | Path | None = None,
        offline: bool = False,
        force: bool = False,
    ) -> SnapshotMaterialization:
        try:
            parsed = parse_package_ref(package_ref)
        except ValueError as exc:
            raise UsageError(str(exc)) from exc

        store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        cache = load_package_cache(store.paths)

        if offline:
            selected_version = select_cached_version(
                cache,
                packages_root=store.paths.packages_dir,
                archives_root=store.paths.archives_dir,
                registry=registry,
                scope=parsed.scope,
                name=parsed.name,
                preferred_version=parsed.version,
            )
            archive_bytes = None
        else:
            selection = _resolve_online_package_selection(
                registry=registry,
                token=token,
                timeout=self.timeout,
                scope=parsed.scope,
                name=parsed.name,
                preferred_version=parsed.version,
            )
            _update_package_cache(cache, registry=registry, package=selection.package, versions=selection.versions)
            save_package_cache(store.paths, cache)
            selected_version = selection.version

            snapshot_root = store.paths.install_path(parsed.scope, parsed.name, selected_version, registry=registry)
            target_root = Path(local_dir).expanduser().resolve() if local_dir is not None else snapshot_root
            target_matches = snapshot_matches(target_root, package_name=parsed.package_name, version=selected_version)
            cache_matches = snapshot_matches(snapshot_root, package_name=parsed.package_name, version=selected_version)
            archive_bytes = None
            if force or not (target_matches or cache_matches):
                archive_bytes = _download_archive_bytes(
                    registry=registry,
                    token=token,
                    timeout=self.timeout,
                    scope=parsed.scope,
                    name=parsed.name,
                    version=selected_version,
                )

        return _materialize_snapshot_from_cache_or_archive(
            store=store,
            registry=registry,
            scope=parsed.scope,
            name=parsed.name,
            version=selected_version,
            local_dir=local_dir,
            force=force,
            archive_bytes=archive_bytes,
        )

    def snapshot_download(
        self,
        package_ref: str,
        *,
        local_dir: str | Path | None = None,
        offline: bool = False,
        force: bool = False,
    ) -> str:
        result = self._snapshot_download_materialized(
            package_ref,
            local_dir=local_dir,
            offline=offline,
            force=force,
        )
        return str(result.local_path)

    def load(self, package_ref: str, *, offline: bool = False) -> LoadedPackage:
        snapshot = self._snapshot_download_materialized(
            package_ref,
            local_dir=None,
            offline=offline,
            force=False,
        )
        return _load_snapshot_materialization(snapshot)

    def to_prompt(
        self,
        package_ref: str,
        *,
        datasets: Iterable[str] | None = None,
        max_tokens: int = 2000,
        offline: bool = False,
    ) -> str:
        loaded = self.load(package_ref, offline=offline)
        info_payload = self.info(package_ref, offline=offline)
        return build_prompt(
            package_ref=package_ref,
            loaded=loaded,
            info_payload=info_payload,
            datasets=datasets,
            max_tokens=max_tokens,
        )

    def _download_materialized(
        self,
        package_ref: str,
        model_path: str,
        *,
        local_dir: str | Path | None = None,
        offline: bool = False,
        force: bool = False,
    ) -> FileMaterialization:
        snapshot = self._snapshot_download_materialized(
            package_ref,
            local_dir=None,
            offline=offline,
            force=force,
        )
        return _download_model_from_snapshot(
            snapshot=snapshot,
            model_path=model_path,
            local_dir=local_dir,
            force=force,
        )

    def download(
        self,
        package_ref: str,
        path: str,
        *,
        local_dir: str | Path | None = None,
        offline: bool = False,
        force: bool = False,
    ) -> str:
        result = self._download_materialized(
            package_ref,
            path,
            local_dir=local_dir,
            offline=offline,
            force=force,
        )
        return str(result.local_path)

    def validate(self, target: str | Path = ".", *, format: str = "auto", show_dataset_measures: bool = False) -> dict[str, Any]:
        del show_dataset_measures
        try:
            result = validate_target(Path(target), format)
        except ManifestValidationError as exc:
            raise _wrap_manifest_error(exc) from exc
        except ValueError as exc:
            raise UsageError(str(exc)) from exc
        return _serialize_validate_result(result)

    def pack(self, target_dir: str | Path = ".", *, output_dir: str | Path = "dist") -> dict[str, Any]:
        target_path = Path(target_dir).expanduser().resolve()
        if not target_path.is_dir():
            raise UsageError("pack target must be a directory")

        try:
            validation_result = validate_target(target_path, "auto")
            if validation_result.manifest is None:
                raise ValidationError("manifest validation did not produce a manifest")
            build = build_package_archive(target_path, Path(output_dir), manifest=validation_result.manifest)
        except ManifestValidationError as exc:
            raise _wrap_manifest_error(exc) from exc

        return {
            "package": validation_result.manifest.name,
            "version": validation_result.manifest.version,
            "archive_path": str(build.archive_path),
            "output_dir": str(Path(output_dir).expanduser().resolve()),
        }

    def convert(
        self,
        input_path: str | Path,
        *,
        from_format: str,
        to_format: str = "osi",
        output: str | Path,
        package_name: str | None = None,
        package_version: str | None = None,
        overwrite: bool = False,
    ) -> dict[str, Any]:
        normalized_from = from_format.lower().strip()
        normalized_to = to_format.lower().strip()

        registry = get_conversion_registry()
        try:
            route = registry.get(normalized_from, normalized_to)
        except ConversionError as exc:
            raise UsageError(str(exc)) from exc

        try:
            project = route.convert(Path(input_path))
        except ConversionError as exc:
            raise RawctxError(str(exc)) from exc

        store = ConfigStore(config_path=self.config_path)
        config = store.load()
        try:
            resolved_package_name = resolve_package_name(project.project_name, package_name, config.profile.username)
            resolved_version = resolve_version(project.project_version, package_version)
        except ValueError as exc:
            raise UsageError(str(exc)) from exc

        converted = build_converted_package(
            project,
            package_name=resolved_package_name,
            version=resolved_version,
            source_format=normalized_from,
        )

        output_dir = Path(output).expanduser().resolve()
        try:
            written = materialize_package(
                output_dir,
                package_name=converted.package_name,
                package_version=converted.version,
                source_format=converted.source_format,
                model_documents=converted.model_documents,
                overwrite=overwrite,
            )
            validate_target(output_dir, "auto")
        except ManifestValidationError as exc:
            raise _wrap_manifest_error(exc) from exc
        except RuntimeError as exc:
            raise RawctxError(str(exc)) from exc

        return {
            "from": normalized_from,
            "to": normalized_to,
            "package_name": converted.package_name,
            "version": converted.version,
            "output_dir": str(output_dir),
            "written_files": [str(path) for path in written],
        }

    def claim(self, package_ref: str) -> dict[str, Any]:
        try:
            parsed = parse_package_ref(package_ref)
        except ValueError as exc:
            raise UsageError(str(exc)) from exc

        if parsed.version:
            raise UsageError("claim only accepts @scope/name")

        _store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        if not token:
            raise AuthRequiredError("Authentication required. Run `rawctx login` first.")

        with RegistryClient(registry=registry, token=token, timeout=self.timeout) as registry_client:
            result = registry_client.claim_package(scope=parsed.scope, name=parsed.name)
        return asdict(result)

    def index_dbt(
        self,
        *,
        seed_file: str | Path,
        only: str | None = None,
        limit: int = 0,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        if limit < 0:
            raise UsageError("--limit must be >= 0")

        seed_path = Path(seed_file).expanduser().resolve()
        entries = load_dbt_seed_entries(seed_path)
        if only:
            entries = [entry for entry in entries if entry.repo == only]
        if limit > 0:
            entries = entries[:limit]

        _store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        if not dry_run and not token:
            raise AuthRequiredError("Authentication required. Run `rawctx login` first.")

        results = [
            index_dbt_seed_entry(entry=entry, registry=registry, token=token, dry_run=dry_run)
            for entry in entries
        ]
        return _serialize_index_results(mode="dbt", results=results, seed_file=seed_path)

    def index_git(
        self,
        *,
        repo: str,
        source_ref: str = "main",
        package_version: str,
        package_name: str | None = None,
        scope: str = "github-hub",
        model_glob: str | Iterable[str] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        if isinstance(model_glob, str):
            model_globs = (model_glob,)
        elif model_glob is None:
            model_globs = ()
        else:
            model_globs = tuple(str(item).strip() for item in model_glob if str(item).strip())

        _store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        if not dry_run and not token:
            raise AuthRequiredError("Authentication required. Run `rawctx login` first.")

        entry = GitIndexEntry(
            repo=repo,
            source_ref=source_ref,
            package_version=package_version,
            package_name=package_name,
            scope=scope.strip(),
            model_globs=model_globs,
        )
        result = index_git_repo(entry=entry, registry=registry, token=token, dry_run=dry_run)
        return _serialize_index_results(mode="git", results=[result])


class AsyncRawctxClient:
    def __init__(
        self,
        *,
        registry: str | None = None,
        token: str | None = None,
        config_path: str | Path | None = None,
        timeout: float = 20.0,
    ) -> None:
        self.registry_override = registry
        self.token_override = token
        self.config_path = config_path
        self.timeout = timeout

    async def close(self) -> None:
        return None

    async def __aenter__(self) -> "AsyncRawctxClient":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:  # type: ignore[no-untyped-def]
        await self.close()

    def _sync_client(self) -> RawctxClient:
        return RawctxClient(
            registry=self.registry_override,
            token=self.token_override,
            config_path=self.config_path,
            timeout=self.timeout,
        )

    async def login(
        self,
        *,
        id_token: str | None = None,
        token_name: str = "rawctx-cli",
        expires_in_days: int | None = None,
        no_browser: bool = False,
        progress: ProgressCallback | None = None,
        prompt_for_id_token: PromptCallback | None = None,
    ) -> dict[str, Any]:
        store, config, registry, _token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        config.registry = registry

        async with AsyncRegistryClient(registry=registry, timeout=self.timeout) as registry_client:
            try:
                login_info = await registry_client.oauth_login()
            except RegistryError as exc:
                if exc.status_code not in {404, 405}:
                    raise
                login_info = await registry_client.oauth_login_github()

            if not no_browser:
                webbrowser.open(login_info.authorize_url)

            prompt_label = login_info.provider_label or "Sign in"
            _emit(
                progress,
                {
                    "type": "authorize_url",
                    "authorize_url": login_info.authorize_url,
                    "prompt_label": prompt_label,
                },
            )

            provided_token = id_token.strip() if id_token else ""
            if not provided_token:
                if login_info.session_id:
                    _emit(progress, {"type": "waiting"})
                    provided_token = await _wait_for_oauth_id_token_async(
                        client=registry_client,
                        session_id=login_info.session_id,
                        poll_interval_seconds=login_info.poll_interval_seconds,
                    )
                else:
                    _emit(progress, {"type": "manual_token_required"})
                    if prompt_for_id_token is None:
                        raise UsageError("Automatic token capture is unavailable on this registry. Pass id_token explicitly.")
                    provided_token = prompt_for_id_token("id_token").strip()

            if not provided_token:
                raise UsageError("id_token is required")

            token_info = await registry_client.create_api_token(
                id_token=provided_token,
                name=token_name,
                expires_in_days=expires_in_days,
            )
            username = extract_username_from_jwt(provided_token) or config.profile.username
            tenant_slug = config.profile.tenant_slug
            tenant_display_name = config.profile.tenant_display_name
            try:
                me = await registry_client.get_me(token=token_info.token)
            except RegistryError:
                me = None
            if me is not None:
                username = me.username or username
                tenant_slug = me.tenant.slug
                tenant_display_name = me.tenant.display_name
            store.save_auth(
                config=config,
                token=token_info.token,
                token_id=token_info.id,
                token_name=token_info.name,
                username=username,
                tenant_slug=tenant_slug,
                tenant_display_name=tenant_display_name,
            )

        return {
            "registry": registry,
            "token_id": token_info.id,
            "token_name": token_info.name,
            "username": username,
            "tenant_slug": tenant_slug,
            "tenant_display_name": tenant_display_name,
            "config_path": str(store.paths.config_path),
        }

    async def logout(self, *, local_only: bool = False) -> dict[str, Any]:
        store, config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )

        had_token = bool(config.auth.token)
        if not had_token:
            return {
                "had_token": False,
                "local_only": local_only,
                "revoked": False,
                "config_path": str(store.paths.config_path),
            }

        revoked = False
        if not local_only and token and config.auth.token_id:
            async with AsyncRegistryClient(registry=registry, token=token, timeout=self.timeout) as registry_client:
                revoked = await registry_client.revoke_api_token(config.auth.token_id)

        store.clear_auth(config)
        return {
            "had_token": True,
            "local_only": local_only,
            "revoked": revoked,
            "config_path": str(store.paths.config_path),
        }

    async def search(
        self,
        query: str | None = None,
        *,
        format: str | None = None,
        source_format: str | None = None,
        origin: str = "all",
        domain: str | None = None,
        source: str | None = None,
        tags: SearchTags = None,
        sort: str = "recent",
        page: int = 1,
        size: int = 20,
        offline: bool = False,
    ) -> dict[str, Any]:
        if offline:
            return await asyncio.to_thread(
                self._sync_client().search,
                query,
                format=format,
                source_format=source_format,
                origin=origin,
                domain=domain,
                source=source,
                tags=tags,
                sort=sort,
                page=page,
                size=size,
                offline=True,
            )

        normalized_sort = _validate_search_args(page, size, sort)
        store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        cache = load_package_cache(store.paths)
        tags_query, _tag_filters = _normalize_tags_for_query(tags)

        result = await _search_remote_public_first_async(
            registry=registry,
            token=token,
            timeout=self.timeout,
            query=query,
            format=format,
            source_format=source_format,
            origin=origin.lower(),
            domain=domain,
            source=source,
            tags=tags_query,
            sort=normalized_sort,
            page=page,
            size=size,
        )

        _cache_search_items(cache, registry=registry, items=result.items)
        save_package_cache(store.paths, cache)
        return _serialize_search_items(result.items, result.meta)

    async def info(self, package_ref: str, *, offline: bool = False) -> dict[str, Any]:
        if offline:
            return await asyncio.to_thread(self._sync_client().info, package_ref, offline=True)

        try:
            parsed = parse_package_ref(package_ref)
        except ValueError as exc:
            raise UsageError(str(exc)) from exc

        store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        cache = load_package_cache(store.paths)

        async with AsyncRegistryClient(registry=registry, token=token, timeout=self.timeout) as registry_client:
            package = await registry_client.get_package(scope=parsed.scope, name=parsed.name)
            versions, _meta = await registry_client.list_versions(scope=parsed.scope, name=parsed.name, page=1, size=100)

        upsert_cache_entry(
            cache,
            scope=parsed.scope,
            name=parsed.name,
            registry=registry,
            package=asdict(package),
            versions=[asdict(item) for item in versions],
        )
        save_package_cache(store.paths, cache)

        selected_version = None
        if parsed.version:
            selected_version = next((item for item in versions if item.version == parsed.version), None)
            if selected_version is None:
                raise RawctxError(f"Version not found: {parsed.normalized}")

        return _serialize_info_payload(package=package, versions=versions, selected_version=selected_version)

    async def _snapshot_download_materialized(
        self,
        package_ref: str,
        *,
        local_dir: str | Path | None = None,
        offline: bool = False,
        force: bool = False,
    ) -> SnapshotMaterialization:
        try:
            parsed = parse_package_ref(package_ref)
        except ValueError as exc:
            raise UsageError(str(exc)) from exc

        if offline:
            return await asyncio.to_thread(
                self._sync_client()._snapshot_download_materialized,
                package_ref,
                local_dir=local_dir,
                offline=True,
                force=force,
            )

        store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        cache = load_package_cache(store.paths)
        selection = await _resolve_online_package_selection_async(
            registry=registry,
            token=token,
            timeout=self.timeout,
            scope=parsed.scope,
            name=parsed.name,
            preferred_version=parsed.version,
        )
        _update_package_cache(cache, registry=registry, package=selection.package, versions=selection.versions)
        save_package_cache(store.paths, cache)

        snapshot_root = store.paths.install_path(parsed.scope, parsed.name, selection.version, registry=registry)
        target_root = Path(local_dir).expanduser().resolve() if local_dir is not None else snapshot_root
        target_matches = await asyncio.to_thread(
            snapshot_matches,
            target_root,
            package_name=parsed.package_name,
            version=selection.version,
        )
        cache_matches = await asyncio.to_thread(
            snapshot_matches,
            snapshot_root,
            package_name=parsed.package_name,
            version=selection.version,
        )

        archive_bytes = None
        if force or not (target_matches or cache_matches):
            archive_bytes = await _download_archive_bytes_async(
                registry=registry,
                token=token,
                timeout=self.timeout,
                scope=parsed.scope,
                name=parsed.name,
                version=selection.version,
            )

        return await asyncio.to_thread(
            _materialize_snapshot_from_cache_or_archive,
            store=store,
            registry=registry,
            scope=parsed.scope,
            name=parsed.name,
            version=selection.version,
            local_dir=local_dir,
            force=force,
            archive_bytes=archive_bytes,
        )

    async def snapshot_download(
        self,
        package_ref: str,
        *,
        local_dir: str | Path | None = None,
        offline: bool = False,
        force: bool = False,
    ) -> str:
        result = await self._snapshot_download_materialized(
            package_ref,
            local_dir=local_dir,
            offline=offline,
            force=force,
        )
        return str(result.local_path)

    async def load(self, package_ref: str, *, offline: bool = False) -> LoadedPackage:
        snapshot = await self._snapshot_download_materialized(
            package_ref,
            local_dir=None,
            offline=offline,
            force=False,
        )
        return await asyncio.to_thread(_load_snapshot_materialization, snapshot)

    async def to_prompt(
        self,
        package_ref: str,
        *,
        datasets: Iterable[str] | None = None,
        max_tokens: int = 2000,
        offline: bool = False,
    ) -> str:
        loaded = await self.load(package_ref, offline=offline)
        info_payload = await self.info(package_ref, offline=offline)
        return await asyncio.to_thread(
            build_prompt,
            package_ref=package_ref,
            loaded=loaded,
            info_payload=info_payload,
            datasets=datasets,
            max_tokens=max_tokens,
        )

    async def _download_materialized(
        self,
        package_ref: str,
        model_path: str,
        *,
        local_dir: str | Path | None = None,
        offline: bool = False,
        force: bool = False,
    ) -> FileMaterialization:
        snapshot = await self._snapshot_download_materialized(
            package_ref,
            local_dir=None,
            offline=offline,
            force=force,
        )
        return await asyncio.to_thread(
            _download_model_from_snapshot,
            snapshot=snapshot,
            model_path=model_path,
            local_dir=local_dir,
            force=force,
        )

    async def download(
        self,
        package_ref: str,
        path: str,
        *,
        local_dir: str | Path | None = None,
        offline: bool = False,
        force: bool = False,
    ) -> str:
        result = await self._download_materialized(
            package_ref,
            path,
            local_dir=local_dir,
            offline=offline,
            force=force,
        )
        return str(result.local_path)

    async def validate(self, target: str | Path = ".", *, format: str = "auto", show_dataset_measures: bool = False) -> dict[str, Any]:
        return await asyncio.to_thread(self._sync_client().validate, target, format=format, show_dataset_measures=show_dataset_measures)

    async def pack(self, target_dir: str | Path = ".", *, output_dir: str | Path = "dist") -> dict[str, Any]:
        return await asyncio.to_thread(self._sync_client().pack, target_dir, output_dir=output_dir)

    async def convert(
        self,
        input_path: str | Path,
        *,
        from_format: str,
        to_format: str = "osi",
        output: str | Path,
        package_name: str | None = None,
        package_version: str | None = None,
        overwrite: bool = False,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            self._sync_client().convert,
            input_path,
            from_format=from_format,
            to_format=to_format,
            output=output,
            package_name=package_name,
            package_version=package_version,
            overwrite=overwrite,
        )

    async def claim(self, package_ref: str) -> dict[str, Any]:
        try:
            parsed = parse_package_ref(package_ref)
        except ValueError as exc:
            raise UsageError(str(exc)) from exc

        if parsed.version:
            raise UsageError("claim only accepts @scope/name")

        _store, _config, registry, token = _resolve_runtime(
            config_path=self.config_path,
            registry_override=self.registry_override,
            token_override=self.token_override,
        )
        if not token:
            raise AuthRequiredError("Authentication required. Run `rawctx login` first.")

        async with AsyncRegistryClient(registry=registry, token=token, timeout=self.timeout) as registry_client:
            result = await registry_client.claim_package(scope=parsed.scope, name=parsed.name)
        return asdict(result)

    async def index_dbt(
        self,
        *,
        seed_file: str | Path,
        only: str | None = None,
        limit: int = 0,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(self._sync_client().index_dbt, seed_file=seed_file, only=only, limit=limit, dry_run=dry_run)

    async def index_git(
        self,
        *,
        repo: str,
        source_ref: str = "main",
        package_version: str = "",
        package_name: str | None = None,
        scope: str = "github-hub",
        model_glob: str | Iterable[str] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        if not package_version:
            raise UsageError("package_version is required")
        return await asyncio.to_thread(
            self._sync_client().index_git,
            repo=repo,
            source_ref=source_ref,
            package_version=package_version,
            package_name=package_name,
            scope=scope,
            model_glob=model_glob,
            dry_run=dry_run,
        )


def client(
    *,
    registry: str | None = None,
    token: str | None = None,
    config_path: str | Path | None = None,
    timeout: float = 20.0,
) -> RawctxClient:
    return RawctxClient(registry=registry, token=token, config_path=config_path, timeout=timeout)


def async_client(
    *,
    registry: str | None = None,
    token: str | None = None,
    config_path: str | Path | None = None,
    timeout: float = 20.0,
) -> AsyncRawctxClient:
    return AsyncRawctxClient(registry=registry, token=token, config_path=config_path, timeout=timeout)


def login(**kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.login(**kwargs)


def logout(**kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.logout(**kwargs)


def search(query: str | None = None, **kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.search(query, **kwargs)


def info(package_ref: str, **kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.info(package_ref, **kwargs)


def snapshot_download(package_ref: str, **kwargs: Any) -> str:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.snapshot_download(package_ref, **kwargs)


def load(package_ref: str, **kwargs: Any) -> LoadedPackage:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.load(package_ref, **kwargs)


def to_prompt(package_ref: str, **kwargs: Any) -> str:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.to_prompt(package_ref, **kwargs)


def download(package_ref: str, path: str, **kwargs: Any) -> str:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.download(package_ref, path, **kwargs)


def validate(target: str | Path = ".", **kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.validate(target, **kwargs)


def pack(target_dir: str | Path = ".", **kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.pack(target_dir, **kwargs)


def convert(input_path: str | Path, **kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.convert(input_path, **kwargs)


def claim(package_ref: str, **kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.claim(package_ref, **kwargs)


def index_dbt(**kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.index_dbt(**kwargs)


def index_git(**kwargs: Any) -> dict[str, Any]:
    with client(
        registry=kwargs.pop("registry", None),
        token=kwargs.pop("token", None),
        config_path=kwargs.pop("config_path", None),
        timeout=kwargs.pop("timeout", 20.0),
    ) as c:
        return c.index_git(**kwargs)


__all__ = [
    "AsyncRawctxClient",
    "Dimension",
    "LoadedPackage",
    "Measure",
    "RawctxClient",
    "Relationship",
    "SemanticModel",
    "async_client",
    "claim",
    "client",
    "convert",
    "download",
    "index_dbt",
    "index_git",
    "info",
    "login",
    "load",
    "logout",
    "pack",
    "search",
    "snapshot_download",
    "to_prompt",
    "validate",
]
