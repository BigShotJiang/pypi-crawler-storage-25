from __future__ import annotations

import re
from urllib.parse import quote, urlsplit, urlunsplit

_INSTALL_COMMAND_RE = re.compile(r"\brawctx install\b")
_DEST_FLAG_RE = re.compile(r"(?<!\S)--dest(?=(?:=|\s|`|$))")
_INLINE_EXTERNAL_LINK_RE = re.compile(r"(\[[^\]\n]+\]\()((?:https?://|www\.)[^)\n]+)(\))", re.IGNORECASE)
_AUTOLINK_EXTERNAL_LINK_RE = re.compile(r"(<)((?:https?://|www\.)[^>\n]+)(>)", re.IGNORECASE)
_ABSOLUTE_HTTP_RE = re.compile(r"^https?://", re.IGNORECASE)


def _normalize_external_target(target: str) -> str:
    raw = target.strip()
    if not raw:
        return raw

    candidate = raw if _ABSOLUTE_HTTP_RE.match(raw) else f"https://{raw}" if raw.lower().startswith("www.") else raw
    try:
        parts = urlsplit(candidate)
    except ValueError:
        return raw

    if parts.scheme.lower() not in {"http", "https"} or not parts.netloc:
        return raw

    return urlunsplit(
        (
            parts.scheme.lower(),
            parts.netloc,
            quote(parts.path or "", safe="/:@!$&'()*+,;=-._~%"),
            quote(parts.query or "", safe="/?:@!$&'()*+,;=-._~%"),
            quote(parts.fragment or "", safe="/?:@!$&'()*+,;=-._~%"),
        )
    )


def rewrite_legacy_install_commands(markdown: str) -> str:
    rendered = markdown.replace("\r\n", "\n")
    rendered = _INSTALL_COMMAND_RE.sub("rawctx snapshot-download", rendered)
    rendered = _DEST_FLAG_RE.sub("--local-dir", rendered)
    rendered = _INLINE_EXTERNAL_LINK_RE.sub(lambda match: f"{match.group(1)}{_normalize_external_target(match.group(2))}{match.group(3)}", rendered)
    rendered = _AUTOLINK_EXTERNAL_LINK_RE.sub(lambda match: f"{match.group(1)}{_normalize_external_target(match.group(2))}{match.group(3)}", rendered)
    return rendered
