from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

import yaml

from rawctx.converter.base import ConversionError
from rawctx.formats.metricflow import load_metricflow_project
from rawctx.package_formats.base import PackageFormatAdapter, PackageFormatValidationResult
from rawctx.package_ops import write_yaml
from rawctx.packaging.manifest import Manifest, ValidationError


def _read_yaml(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return yaml.safe_load(handle)
    except yaml.YAMLError as exc:
        raise ValidationError("invalid YAML syntax", path) from exc
    except OSError as exc:
        raise ValidationError("failed to read MetricFlow file", path) from exc


def _has_metricflow_content(value: Any) -> bool:
    if isinstance(value, dict):
        semantic_models = value.get("semantic_models")
        metrics = value.get("metrics")
        if isinstance(semantic_models, list) and semantic_models:
            return True
        if isinstance(metrics, list) and metrics:
            return True
    if isinstance(value, list):
        for item in value:
            if isinstance(item, dict) and _has_metricflow_content(item):
                return True
    return False


def _as_validation_error(exc: ConversionError) -> ValidationError:
    return ValidationError(
        exc.message,
        file_path=exc.file_path,
        field=exc.field,
    )


def materialize_metricflow_package_from_project(
    source_root: Path,
    output_dir: Path,
    *,
    package_name: str,
    package_version: str,
    overwrite: bool,
) -> list[Path]:
    parsed = load_metricflow_project(source_root)

    if output_dir.exists():
        if not overwrite:
            raise RuntimeError(f"output already exists: {output_dir} (use --overwrite)")
        shutil.rmtree(output_dir)

    output_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    model_paths: list[str] = []
    source_root_resolved = parsed.root.resolve()

    dbt_project_source = source_root_resolved / "dbt_project.yml"
    dbt_project_dest = output_dir / "dbt_project.yml"
    dbt_project_dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(dbt_project_source, dbt_project_dest)
    written.append(dbt_project_dest)

    for source_file in parsed.source_files:
        relative = source_file.resolve().relative_to(source_root_resolved)
        destination = output_dir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_file, destination)
        written.append(destination)
        model_paths.append(relative.as_posix())

    manifest = {
        "name": package_name,
        "version": package_version,
        "format": "metricflow",
        "description": "Native MetricFlow package",
        "source": "dbt",
        "models": model_paths,
    }
    manifest_path = output_dir / "rawctx.yaml"
    write_yaml(manifest_path, manifest)
    written.append(manifest_path)

    readme_path = output_dir / "README.md"
    readme_path.write_text(
        (
            f"# {package_name}\n\n"
            "Native MetricFlow package materialized from a dbt project using `rawctx publish --from-dbt --native`.\n"
        ),
        encoding="utf-8",
    )
    written.append(readme_path)
    return written


class MetricFlowPackageFormatAdapter(PackageFormatAdapter):
    format_name = "metricflow"

    def validate_directory(self, target_dir: Path, manifest: Manifest) -> PackageFormatValidationResult:
        dbt_project_path = (target_dir / "dbt_project.yml").resolve()
        if not dbt_project_path.is_file():
            raise ValidationError("dbt_project.yml not found", dbt_project_path)

        try:
            load_metricflow_project(target_dir)
        except ConversionError as exc:
            raise _as_validation_error(exc) from exc

        validated_files: list[Path] = [dbt_project_path]
        for model_path in manifest.models:
            path = (target_dir / model_path).resolve()
            document = _read_yaml(path)
            if not _has_metricflow_content(document):
                raise ValidationError(
                    "MetricFlow model file must include semantic_models or metrics",
                    path,
                )
            validated_files.append(path)

        validated_files.extend(self._included_files(target_dir, manifest))
        return PackageFormatValidationResult(validated_files=tuple(dict.fromkeys(validated_files)))

    def collect_archive_files(self, target_dir: Path, manifest: Manifest) -> list[tuple[str, Path]]:
        paths = [(target_dir / "dbt_project.yml").resolve()]
        paths.extend((target_dir / model_path).resolve() for model_path in manifest.models)
        paths.extend(self._included_files(target_dir, manifest))
        return self._archive_entries(target_dir, paths)
