from __future__ import annotations

from rawctx.package_formats.base import PackageFormatAdapter, PackageFormatValidationResult
from rawctx.package_formats.metricflow import MetricFlowPackageFormatAdapter, materialize_metricflow_package_from_project
from rawctx.package_formats.osi import OsiPackageFormatAdapter


_ADAPTERS: dict[str, PackageFormatAdapter] = {
    adapter.format_name: adapter
    for adapter in (
        OsiPackageFormatAdapter(),
        MetricFlowPackageFormatAdapter(),
    )
}


def get_package_format_adapter(format_name: str) -> PackageFormatAdapter:
    adapter = _ADAPTERS.get(format_name)
    if adapter is None:
        raise ValueError(f"unsupported package format: {format_name}")
    return adapter


__all__ = [
    "PackageFormatAdapter",
    "PackageFormatValidationResult",
    "get_package_format_adapter",
    "materialize_metricflow_package_from_project",
]
