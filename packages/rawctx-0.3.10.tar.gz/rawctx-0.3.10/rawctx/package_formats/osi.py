from __future__ import annotations

from pathlib import Path

from rawctx.formats.osi import validate_osi
from rawctx.package_formats.base import PackageFormatAdapter, PackageFormatValidationResult
from rawctx.packaging.manifest import Manifest


class OsiPackageFormatAdapter(PackageFormatAdapter):
    format_name = "osi"

    def validate_directory(self, target_dir: Path, manifest: Manifest) -> PackageFormatValidationResult:
        validated_files: list[Path] = []
        summaries: dict[Path, object] = {}
        for model_path in manifest.models:
            path = (target_dir / model_path).resolve()
            summaries[path] = validate_osi(path)
            validated_files.append(path)

        validated_files.extend(self._included_files(target_dir, manifest))
        return PackageFormatValidationResult(
            validated_files=tuple(dict.fromkeys(validated_files)),
            summaries=summaries,
        )

    def collect_archive_files(self, target_dir: Path, manifest: Manifest) -> list[tuple[str, Path]]:
        paths = [(target_dir / model_path).resolve() for model_path in manifest.models]
        paths.extend(self._included_files(target_dir, manifest))
        return self._archive_entries(target_dir, paths)
