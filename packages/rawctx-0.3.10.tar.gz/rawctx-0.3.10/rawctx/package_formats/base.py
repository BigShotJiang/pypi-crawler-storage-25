from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from rawctx.packaging.manifest import Manifest


@dataclass(frozen=True)
class PackageFormatValidationResult:
    validated_files: tuple[Path, ...] = ()
    summaries: dict[Path, Any] = field(default_factory=dict)


class PackageFormatAdapter(ABC):
    format_name: str

    @abstractmethod
    def validate_directory(self, target_dir: Path, manifest: Manifest) -> PackageFormatValidationResult:  # pragma: no cover
        raise NotImplementedError

    @abstractmethod
    def collect_archive_files(self, target_dir: Path, manifest: Manifest) -> list[tuple[str, Path]]:  # pragma: no cover
        raise NotImplementedError

    def _included_files(self, target_dir: Path, manifest: Manifest) -> list[Path]:
        files: list[Path] = []
        for raw_path in manifest.include or []:
            path = (target_dir / raw_path).resolve()
            if path.is_dir():
                files.extend(sorted(item for item in path.rglob("*") if item.is_file()))
            elif path.is_file():
                files.append(path)
        return files

    def _archive_entries(self, target_dir: Path, paths: list[Path]) -> list[tuple[str, Path]]:
        entries: dict[str, Path] = {}
        base_dir = target_dir.resolve()
        for path in paths:
            resolved = path.resolve()
            relative = resolved.relative_to(base_dir).as_posix()
            if relative in {"rawctx.yaml", "README.md"}:
                continue
            entries.setdefault(f"package/{relative}", resolved)
        return sorted(entries.items(), key=lambda item: item[0])
