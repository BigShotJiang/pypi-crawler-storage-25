from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner
import yaml

from rawctx.cli import main


def _write_metricflow_project(base: Path, *, unresolved_jinja: bool = False) -> Path:
    project_dir = base / "dbt_project"
    models_dir = project_dir / "models" / "semantic_models"
    models_dir.mkdir(parents=True, exist_ok=True)

    (project_dir / "dbt_project.yml").write_text(
        """
name: "jaffle_shop"
version: "1.2.3"
config-version: 2
""".strip()
        + "\n",
        encoding="utf-8",
    )

    model_source = "\"{{ ref('fct_orders') }}\"" if unresolved_jinja else "ref('fct_orders')"

    (models_dir / "orders.yml").write_text(
        f"""
version: 2
semantic_models:
  - name: customers
    model: ref('dim_customers')
    entities:
      - name: customer
        type: primary
        expr: customer_id
    dimensions:
      - name: signup_date
        type: time
        expr: signup_date
    measures:
      - name: customer_count
        expr: customer_id

  - name: orders
    model: {model_source}
    entities:
      - name: order
        type: primary
        expr: order_id
      - name: customer
        type: foreign
        expr: customer_id
    dimensions:
      - name: ordered_at
        type: time
        expr: ordered_at
    measures:
      - name: gross_revenue
        expr: amount
      - name: order_count
        expr: 1

metrics:
  - name: gross_revenue
    type: simple
    type_params:
      measure: gross_revenue
  - name: customer_count
    type: simple
    type_params:
      measure: customer_count
  - name: order_count
    type: simple
    type_params:
      measure: order_count
  - name: gross_revenue_pct
    type: ratio
    type_params:
      numerator: gross_revenue
      denominator: order_count
  - name: average_order_value
    type: derived
    type_params:
      metrics:
        - gross_revenue
        - order_count
      expr: gross_revenue / nullif(order_count, 0)
  - name: orders_per_customer
    type: derived
    type_params:
      metrics:
        - order_count
        - customer_count
      expr: order_count / nullif(customer_count, 0)
""".strip()
        + "\n",
        encoding="utf-8",
    )

    return project_dir


def test_convert_metricflow_to_osi_success(monkeypatch, tmp_path: Path) -> None:
    project_dir = _write_metricflow_project(tmp_path)
    output_dir = tmp_path / "out-package"

    config_path = tmp_path / "rawctx" / "config.yaml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text("profile:\n  username: owner\n", encoding="utf-8")
    monkeypatch.setenv("RAWCTX_CONFIG", str(config_path))

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "convert",
            "--from",
            "metricflow",
            "--to",
            "osi",
            str(project_dir),
            "--output",
            str(output_dir),
        ],
    )

    assert result.exit_code == 0, result.output
    assert (output_dir / "rawctx.yaml").exists()

    manifest = yaml.safe_load((output_dir / "rawctx.yaml").read_text(encoding="utf-8"))
    assert manifest["name"] == "@owner/jaffle-shop-semantic"
    assert manifest["version"] == "1.2.3"
    assert manifest["format"] == "osi"
    assert manifest["source_format"] == "metricflow"
    assert len(manifest["models"]) == 2

    order_model = yaml.safe_load((output_dir / "models" / "orders.osi.yaml").read_text(encoding="utf-8"))
    assert order_model["version"] == "0.1.1"
    assert len(order_model["semantic_model"]) == 1
    semantic_model = order_model["semantic_model"][0]
    assert semantic_model["datasets"][0]["name"] == "orders"
    assert semantic_model["relationships"][0]["name"].startswith("orders__customer")
    metric_names = [item["name"] for item in semantic_model["metrics"]]
    assert "average_order_value" in metric_names
    assert "gross_revenue_pct" in metric_names

    customer_model = yaml.safe_load((output_dir / "models" / "customers.osi.yaml").read_text(encoding="utf-8"))
    customer_metric_names = [item["name"] for item in customer_model["semantic_model"][0]["metrics"]]
    assert "orders_per_customer" in customer_metric_names


def test_convert_strict_fails_on_unresolved_jinja(tmp_path: Path) -> None:
    project_dir = _write_metricflow_project(tmp_path, unresolved_jinja=True)
    output_dir = tmp_path / "out-package"

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "convert",
            "--from",
            "metricflow",
            "--to",
            "osi",
            str(project_dir),
            "--output",
            str(output_dir),
        ],
    )

    assert result.exit_code == 1
    assert "unresolved Jinja" in result.output


def test_convert_unsupported_route_errors(tmp_path: Path) -> None:
    project_dir = _write_metricflow_project(tmp_path)
    output_dir = tmp_path / "out-package"

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "convert",
            "--from",
            "cube",
            "--to",
            "osi",
            str(project_dir),
            "--output",
            str(output_dir),
        ],
    )

    assert result.exit_code == 2
    assert "unsupported conversion route" in result.output
