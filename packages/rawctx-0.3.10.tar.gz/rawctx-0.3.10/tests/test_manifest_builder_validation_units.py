from __future__ import annotations

from pathlib import Path

import pytest

from rawctx.packaging.builder import _read_bytes, build_package_archive
from rawctx.packaging.manifest import (
    Manifest,
    ValidationError,
    _as_optional_str,
    _as_str,
    _as_str_list,
    _validate_relative_paths,
    load_manifest,
    validate_manifest,
)
from rawctx.validation import (
    resolve_manifest_path,
    validate_directory,
    validate_file,
    validate_manifest_file,
    validate_osi_file,
    validate_target,
)


def _write_valid_osi_package(base: Path) -> Path:
    package_dir = base / "osi-package"
    models_dir = package_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)
    (package_dir / "rawctx.yaml").write_text(
        (
            'name: "@owner/sample"\n'
            'version: "1.0.0"\n'
            'format: "osi"\n'
            "models:\n"
            "  - models/sample.osi.yaml\n"
        ),
        encoding="utf-8",
    )
    (models_dir / "sample.osi.yaml").write_text(
        (
            'version: "0.1.1"\n'
            "dialects:\n"
            "  - ANSI_SQL\n"
            "vendors:\n"
            "  - COMMON\n"
            "semantic_model:\n"
            "  - name: sample\n"
            "    datasets:\n"
            "      - name: sample\n"
            "        source: analytics.sample\n"
            "        fields:\n"
            "          - name: dim_one\n"
            "            expression:\n"
            "              dialects:\n"
            "                - dialect: ANSI_SQL\n"
            '                  expression: "dim_one"\n'
            "            dimension:\n"
            "              is_time: false\n"
            "    metrics:\n"
            "      - name: sample_metric\n"
            "        expression:\n"
            "          dialects:\n"
            "            - dialect: ANSI_SQL\n"
            '              expression: "count(*)"\n'
        ),
        encoding="utf-8",
    )
    return package_dir


def _write_valid_metricflow_package(base: Path) -> Path:
    package_dir = base / "metricflow-package"
    models_dir = package_dir / "models" / "semantic_models"
    models_dir.mkdir(parents=True, exist_ok=True)
    (package_dir / "rawctx.yaml").write_text(
        (
            'name: "@owner/native"\n'
            'version: "1.2.3"\n'
            'format: "metricflow"\n'
            "models:\n"
            "  - models/semantic_models/orders.yml\n"
        ),
        encoding="utf-8",
    )
    (package_dir / "dbt_project.yml").write_text('name: "jaffle_shop"\nversion: "1.2.3"\nconfig-version: 2\n', encoding="utf-8")
    (models_dir / "orders.yml").write_text("semantic_models:\n  - name: orders\n", encoding="utf-8")
    return package_dir


def test_manifest_helpers_and_load_manifest_error_paths(monkeypatch, tmp_path: Path) -> None:
    manifest_path = tmp_path / "rawctx.yaml"

    error = ValidationError("invalid", manifest_path, line=3, column=7)
    assert str(error) == f"invalid ({manifest_path}, line 3, column 7)"

    with pytest.raises(ValidationError, match="expected non-empty string"):
        _as_str(1, "name", manifest_path)
    with pytest.raises(ValidationError, match="expected string"):
        _as_optional_str(1, "description", manifest_path)
    with pytest.raises(ValidationError, match="expected list"):
        _as_str_list("bad", "models", manifest_path, allow_empty=False)
    with pytest.raises(ValidationError, match="expected non-empty list"):
        _as_str_list([], "models", manifest_path, allow_empty=False)
    with pytest.raises(ValidationError, match="expected non-empty string item"):
        _as_str_list([None], "models", manifest_path, allow_empty=True)

    manifest_path.write_text("name: [\n", encoding="utf-8")
    with pytest.raises(ValidationError, match="invalid YAML syntax"):
        load_manifest(manifest_path)

    original_open = Path.open

    def fake_open(self: Path, *args, **kwargs):  # type: ignore[no-untyped-def]
        if self == manifest_path:
            raise OSError("boom")
        return original_open(self, *args, **kwargs)

    monkeypatch.setattr(Path, "open", fake_open)
    with pytest.raises(ValidationError, match="failed to read manifest"):
        load_manifest(manifest_path)

    monkeypatch.setattr(Path, "open", original_open)
    manifest_path.write_text("- item\n", encoding="utf-8")
    with pytest.raises(ValidationError, match="manifest root must be a mapping"):
        load_manifest(manifest_path)

    manifest_path.write_text(
        (
            'name: "@owner/pkg"\n'
            'version: "1.2.3"\n'
            'format: "metricflow"\n'
            "author: bad\n"
            "models:\n"
            "  - models/orders.yml\n"
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValidationError, match="author must be an object"):
        load_manifest(manifest_path)

    manifest_path.write_text(
        (
            'name: "@owner/pkg"\n'
            'version: "1.2.3"\n'
            'format: "metricflow"\n'
            'description: "Native MetricFlow package"\n'
            'license: "Apache-2.0"\n'
            "author:\n"
            '  name: "Analyst"\n'
            '  org: "Data Team"\n'
            '  url: "https://example.com"\n'
            'source: "dbt"\n'
            'domain: "finance"\n'
            'repository: "https://github.com/example/repo"\n'
            "tags:\n"
            "  - metrics\n"
            "dependencies:\n"
            "  - '@owner/dep'\n"
            "include:\n"
            "  - macros\n"
            "models:\n"
            "  - models/orders.yml\n"
        ),
        encoding="utf-8",
    )
    manifest = load_manifest(manifest_path)
    assert manifest.dependencies == ["@owner/dep"]
    assert manifest.include == ["macros"]
    assert manifest.author is not None
    assert manifest.author.org == "Data Team"


def test_validate_manifest_covers_format_and_path_errors(tmp_path: Path) -> None:
    base_dir = tmp_path / "pkg"
    models_dir = base_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)
    (models_dir / "orders.yml").write_text("semantic_models:\n  - name: orders\n", encoding="utf-8")
    effective_path = base_dir / "rawctx.yaml"

    with pytest.raises(ValidationError, match="name must match '@scope/package'"):
        validate_manifest(Manifest(name="bad", version="1.2.3", format="metricflow", models=["models/orders.yml"]), base_dir)
    with pytest.raises(ValidationError, match="SemVer"):
        validate_manifest(Manifest(name="@owner/pkg", version="1.2", format="metricflow", models=["models/orders.yml"]), base_dir)
    with pytest.raises(ValidationError, match="unsupported format"):
        validate_manifest(Manifest(name="@owner/pkg", version="1.2.3", format="bad", models=["models/orders.yml"]), base_dir)
    with pytest.raises(ValidationError, match="unsupported source_format"):
        validate_manifest(
            Manifest(name="@owner/pkg", version="1.2.3", format="metricflow", models=["models/orders.yml"], source_format="bad"),
            base_dir,
        )

    with pytest.raises(ValidationError, match="models path must be relative"):
        _validate_relative_paths([str((models_dir / "orders.yml").resolve())], base_dir=base_dir, effective_path=effective_path, field_name="models", allow_directories=False)
    with pytest.raises(ValidationError, match="include path must not contain '\\.\\.'"):
        _validate_relative_paths(["../outside"], base_dir=base_dir, effective_path=effective_path, field_name="include", allow_directories=True)

    outside_file = tmp_path / "outside.yml"
    outside_file.write_text("semantic_models:\n  - name: outside\n", encoding="utf-8")
    (base_dir / "escape.yml").symlink_to(outside_file)
    with pytest.raises(ValidationError, match="models path escapes package directory"):
        _validate_relative_paths(["escape.yml"], base_dir=base_dir, effective_path=effective_path, field_name="models", allow_directories=False)

    with pytest.raises(ValidationError, match="model file not found"):
        _validate_relative_paths(["models/missing.yml"], base_dir=base_dir, effective_path=effective_path, field_name="models", allow_directories=False)
    with pytest.raises(ValidationError, match="file or directory not found"):
        _validate_relative_paths(["missing-dir"], base_dir=base_dir, effective_path=effective_path, field_name="include", allow_directories=True)

    include_dir = base_dir / "macros"
    include_dir.mkdir()
    validate_manifest(
        Manifest(
            name="@owner/pkg",
            version="1.2.3",
            format="metricflow",
            models=["models/orders.yml"],
            source_format="metricflow",
            include=["macros"],
        ),
        base_dir,
    )


def test_builder_and_validation_dispatch_paths(monkeypatch, tmp_path: Path) -> None:
    osi_package = _write_valid_osi_package(tmp_path)
    metricflow_package = _write_valid_metricflow_package(tmp_path)
    manifest_path = osi_package / "rawctx.yaml"
    osi_path = osi_package / "models" / "sample.osi.yaml"

    assert resolve_manifest_path(osi_package) == manifest_path
    with pytest.raises(ValidationError, match="rawctx.yaml not found"):
        resolve_manifest_path(tmp_path / "missing")

    manifest, files = validate_manifest_file(manifest_path)
    assert manifest.format == "osi"
    assert files == [manifest_path]

    summary, files = validate_osi_file(osi_path)
    assert summary.datasets == 1
    assert files == [osi_path]

    with pytest.raises(ValidationError, match="package format is 'metricflow', not 'osi'"):
        validate_directory(metricflow_package, "osi")

    assert validate_file(manifest_path, "manifest").manifest is not None
    assert validate_file(osi_path, "osi").osi_summaries
    assert validate_file(manifest_path, "auto").manifest is not None
    assert validate_file(osi_path, "auto").osi_summaries
    assert validate_target(manifest_path).manifest is not None

    other_file = tmp_path / "notes.txt"
    other_file.write_text("hello\n", encoding="utf-8")
    with pytest.raises(ValueError, match="auto format requires"):
        validate_file(other_file, "auto")

    with pytest.raises(ValueError, match="format must be one of"):
        validate_target(osi_package, "bad")
    with pytest.raises(ValidationError, match="target does not exist"):
        validate_target(tmp_path / "does-not-exist")

    original_is_file = Path.is_file

    def fake_is_file(self: Path) -> bool:
        if self == other_file:
            return False
        return original_is_file(self)

    monkeypatch.setattr(Path, "is_file", fake_is_file)
    with pytest.raises(ValidationError, match="target must be a file or directory"):
        validate_target(other_file)

    with pytest.raises(ValidationError, match="pack target must be a directory"):
        build_package_archive(osi_path, tmp_path / "dist")

    original_read_bytes = Path.read_bytes

    def fake_read_bytes(self: Path) -> bytes:
        if self == manifest_path:
            raise OSError("boom")
        return original_read_bytes(self)

    monkeypatch.setattr(Path, "read_bytes", fake_read_bytes)
    with pytest.raises(ValidationError, match="failed to read file for packaging"):
        _read_bytes(manifest_path)
