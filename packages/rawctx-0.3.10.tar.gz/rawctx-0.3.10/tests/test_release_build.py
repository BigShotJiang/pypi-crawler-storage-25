from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path
import zipfile

import build_hooks
import pytest
from build_hooks import FreshBuildPy, remove_stale_build_package
from setuptools import Distribution


def _copy_release_tree(tmp_path: Path) -> Path:
    source_root = Path(__file__).resolve().parents[1]
    project_root = tmp_path / "cli"
    shutil.copytree(source_root / "rawctx", project_root / "rawctx")
    shutil.copy2(source_root / "pyproject.toml", project_root / "pyproject.toml")
    shutil.copy2(source_root / "README.md", project_root / "README.md")
    shutil.copy2(source_root / "setup.py", project_root / "setup.py")
    shutil.copy2(source_root / "build_hooks.py", project_root / "build_hooks.py")
    return project_root


def test_remove_stale_build_package_deletes_existing_tree(tmp_path: Path) -> None:
    package_dir = tmp_path / "build" / "lib" / "rawctx" / "formats"
    package_dir.mkdir(parents=True)
    stale_file = package_dir / "osi.py"
    stale_file.write_text("STALE = True\n", encoding="utf-8")

    removed_path = remove_stale_build_package(tmp_path / "build" / "lib", "rawctx")

    assert removed_path == tmp_path / "build" / "lib" / "rawctx"
    assert not removed_path.exists()


def test_fresh_build_py_cleans_package_tree_before_build(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    calls: list[tuple[str, object, object]] = []

    def fake_remove(build_lib: str | Path, package_name: str) -> Path:
        calls.append(("remove", Path(build_lib), package_name))
        return Path(build_lib) / package_name

    def fake_super_run(self: FreshBuildPy) -> None:
        calls.append(("super", self.build_lib, self.force))

    monkeypatch.setattr(build_hooks, "remove_stale_build_package", fake_remove)
    monkeypatch.setattr(build_hooks._build_py, "run", fake_super_run)

    command = FreshBuildPy(Distribution())
    command.build_lib = str(tmp_path / "build" / "lib")
    command.force = False

    command.run()

    assert calls == [
        ("remove", tmp_path / "build" / "lib", "rawctx"),
        ("super", str(tmp_path / "build" / "lib"), True),
    ]


def test_wheel_build_ignores_stale_build_lib(tmp_path: Path) -> None:
    project_root = _copy_release_tree(tmp_path)
    stale_package_dir = project_root / "build" / "lib" / "rawctx" / "formats"
    stale_package_dir.mkdir(parents=True)
    (stale_package_dir / "osi.py").write_text(
        "from __future__ import annotations\n\nSTALE_BUILD_SENTINEL = True\n",
        encoding="utf-8",
    )

    dist_dir = tmp_path / "dist"
    subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "wheel",
            ".",
            "--no-deps",
            "--no-build-isolation",
            "--wheel-dir",
            str(dist_dir),
        ],
        cwd=project_root,
        check=True,
        capture_output=True,
        text=True,
    )

    wheels = sorted(dist_dir.glob("rawctx-*.whl"))
    assert len(wheels) == 1

    with zipfile.ZipFile(wheels[0]) as wheel:
        osi_module = wheel.read("rawctx/formats/osi.py").decode("utf-8")

    assert "STALE_BUILD_SENTINEL" not in osi_module
    assert "def assign_measure_datasets(" in osi_module
