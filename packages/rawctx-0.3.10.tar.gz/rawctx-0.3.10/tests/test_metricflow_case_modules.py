from __future__ import annotations

from pathlib import Path

import pytest

from rawctx.converter.base import ConversionError
from rawctx.converter.metricflow_case_modules import auto_fallback_case_module_for_error
from rawctx.converter.metricflow_to_osi import metricflow_to_project_ir


def _write_metricflow_project_with_unresolved_relationship(base: Path) -> Path:
    project_dir = base / "dbt_project"
    metrics_dir = project_dir / "models" / "metrics"
    metrics_dir.mkdir(parents=True, exist_ok=True)

    (project_dir / "dbt_project.yml").write_text(
        (
            "name: \"demo\"\n"
            "version: \"0.1.0\"\n"
            "config-version: 2\n"
        ),
        encoding="utf-8",
    )

    (metrics_dir / "models.yml").write_text(
        (
            "semantic_models:\n"
            "  - name: customers\n"
            "    model: ref('dim_customers')\n"
            "    entities:\n"
            "      - name: customer\n"
            "        type: primary\n"
            "        expr: customer_id\n"
            "    measures:\n"
            "      - name: customer_count\n"
            "        expr: customer_id\n"
            "\n"
            "  - name: orders\n"
            "    model: ref('fct_orders')\n"
            "    entities:\n"
            "      - name: order\n"
            "        type: primary\n"
            "        expr: order_id\n"
            "      - name: customer\n"
            "        type: foreign\n"
            "        expr: customer_id\n"
            "      - name: location\n"
            "        type: foreign\n"
            "        expr: location_id\n"
            "    measures:\n"
            "      - name: order_count\n"
            "        expr: 1\n"
        ),
        encoding="utf-8",
    )

    return project_dir


def _write_metricflow_project_with_object_measure_metric(base: Path) -> Path:
    project_dir = base / "dbt_project_obj_metric"
    metrics_dir = project_dir / "models" / "metrics"
    metrics_dir.mkdir(parents=True, exist_ok=True)

    (project_dir / "dbt_project.yml").write_text(
        (
            "name: \"demo_obj_metric\"\n"
            "version: \"0.1.0\"\n"
            "config-version: 2\n"
        ),
        encoding="utf-8",
    )

    (metrics_dir / "models.yml").write_text(
        (
            "semantic_models:\n"
            "  - name: customers\n"
            "    model: ref('dim_customers')\n"
            "    entities:\n"
            "      - name: customer\n"
            "        type: primary\n"
            "        expr: customer_id\n"
            "    measures:\n"
            "      - name: account_balance\n"
            "        expr: account_balance\n"
            "\n"
            "metrics:\n"
            "  - name: met_account_balance\n"
            "    type: simple\n"
            "    type_params:\n"
            "      measure:\n"
            "        name: account_balance\n"
        ),
        encoding="utf-8",
    )

    return project_dir


def test_metricflow_strict_case_module_fails_on_unresolved_relationship(tmp_path: Path) -> None:
    project_dir = _write_metricflow_project_with_unresolved_relationship(tmp_path)

    with pytest.raises(ConversionError, match="cannot resolve relationship target"):
        metricflow_to_project_ir(project_dir, case_module="strict")


def test_metricflow_skip_case_module_skips_unresolved_relationship(tmp_path: Path) -> None:
    project_dir = _write_metricflow_project_with_unresolved_relationship(tmp_path)

    project = metricflow_to_project_ir(project_dir, case_module="skip-unresolvable-relationships")
    orders = next(model for model in project.semantic_models if model.name == "orders")

    assert len(orders.relationships) == 1
    assert orders.relationships[0].to_dataset == "customers"
    assert "location" not in orders.relationships[0].name


def test_metricflow_unknown_case_module_errors(tmp_path: Path) -> None:
    project_dir = _write_metricflow_project_with_unresolved_relationship(tmp_path)

    with pytest.raises(ConversionError, match="unsupported MetricFlow case module"):
        metricflow_to_project_ir(project_dir, case_module="unknown-module")


def test_auto_fallback_for_unresolved_metric_owner_error() -> None:
    error = ConversionError("unable to resolve metric owner semantic model")
    assert auto_fallback_case_module_for_error(error) == "skip-unresolvable-relationships"


def test_metricflow_metric_measure_object_is_supported(tmp_path: Path) -> None:
    project_dir = _write_metricflow_project_with_object_measure_metric(tmp_path)
    project = metricflow_to_project_ir(project_dir, case_module="strict")

    model = next(item for item in project.semantic_models if item.name == "customers")
    metric = next(item for item in model.metrics if item.name == "met_account_balance")
    assert metric.expression.dialects[0].expression == "account_balance"
