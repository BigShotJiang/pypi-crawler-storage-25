from __future__ import annotations

import tarfile
from pathlib import Path

from click.testing import CliRunner
import pytest

from rawctx.cli import main
from rawctx.package_formats import get_package_format_adapter
from rawctx.packaging.manifest import ValidationError, load_manifest


def _write_metricflow_package(base: Path) -> Path:
    package_dir = base / "metricflow-package"
    models_dir = package_dir / "models" / "semantic_models"
    macros_dir = package_dir / "macros"
    models_dir.mkdir(parents=True, exist_ok=True)
    macros_dir.mkdir(parents=True, exist_ok=True)

    (package_dir / "rawctx.yaml").write_text(
        """
name: "@owner/metricflow-native"
version: "1.2.3"
format: "metricflow"
description: "Native MetricFlow package"
models:
  - models/semantic_models/orders.yml
include:
  - packages.yml
  - macros
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (package_dir / "README.md").write_text("# MetricFlow native package\n", encoding="utf-8")
    (package_dir / "dbt_project.yml").write_text(
        """
name: "jaffle_shop"
version: "1.2.3"
config-version: 2
""".strip()
        + "\n",
        encoding="utf-8",
    )
    (package_dir / "packages.yml").write_text("packages: []\n", encoding="utf-8")
    (macros_dir / "currency.sql").write_text("{% macro currency() %}USD{% endmacro %}\n", encoding="utf-8")
    (models_dir / "orders.yml").write_text(
        """
version: 2
semantic_models:
  - name: orders
    model: ref('fct_orders')
    entities:
      - name: order
        type: primary
        expr: order_id
      - name: customer
        type: foreign
        expr: customer_id
    dimensions:
      - name: ordered_at
        type: time
        expr: ordered_at
    measures:
      - name: gross_revenue
        expr: amount
metrics:
  - name: gross_revenue
    type: simple
    type_params:
      measure: gross_revenue
""".strip()
        + "\n",
        encoding="utf-8",
    )

    return package_dir


def test_get_package_format_adapter_rejects_unknown_format() -> None:
    with pytest.raises(ValueError, match="unsupported package format"):
        get_package_format_adapter("unknown")


def test_metricflow_adapter_requires_dbt_project(tmp_path: Path) -> None:
    package_dir = _write_metricflow_package(tmp_path)
    (package_dir / "dbt_project.yml").unlink()

    manifest = load_manifest(package_dir / "rawctx.yaml")
    adapter = get_package_format_adapter(manifest.format)

    with pytest.raises(ValidationError, match="dbt_project.yml"):
        adapter.validate_directory(package_dir, manifest)


def test_validate_metricflow_package_success(tmp_path: Path) -> None:
    package_dir = _write_metricflow_package(tmp_path)
    runner = CliRunner()

    result = runner.invoke(main, ["validate", str(package_dir)])

    assert result.exit_code == 0, result.output
    assert "validated 5 file(s)" in result.output
    assert "package: @owner/metricflow-native@1.2.3" in result.output


def test_pack_metricflow_package_includes_support_files(tmp_path: Path) -> None:
    package_dir = _write_metricflow_package(tmp_path)
    out_dir = tmp_path / "dist"
    runner = CliRunner()

    result = runner.invoke(main, ["pack", str(package_dir), "--output-dir", str(out_dir)])

    assert result.exit_code == 0, result.output
    archive = out_dir / "owner__metricflow-native-1.2.3.rawctx.tar.gz"
    assert archive.exists()

    with tarfile.open(archive, "r:gz") as tar:
        names = sorted(tar.getnames())
        assert names == [
            "package/README.md",
            "package/checksums.sha256",
            "package/dbt_project.yml",
            "package/macros/currency.sql",
            "package/models/semantic_models/orders.yml",
            "package/packages.yml",
            "package/rawctx.yaml",
        ]
