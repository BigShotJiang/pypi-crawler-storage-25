from rawctx.readme import rewrite_legacy_install_commands


def test_rewrite_legacy_install_commands_updates_external_markdown_links() -> None:
    markdown = "[Source](Https://developer.salesforce.com/docs/atlas.en Us.object Reference.meta/object Reference/)"

    rewritten = rewrite_legacy_install_commands(markdown)

    assert rewritten == "[Source](https://developer.salesforce.com/docs/atlas.en%20Us.object%20Reference.meta/object%20Reference/)"


def test_rewrite_legacy_install_commands_updates_external_autolinks() -> None:
    markdown = "<www.example.com/docs/space path>"

    rewritten = rewrite_legacy_install_commands(markdown)

    assert rewritten == "<https://www.example.com/docs/space%20path>"
