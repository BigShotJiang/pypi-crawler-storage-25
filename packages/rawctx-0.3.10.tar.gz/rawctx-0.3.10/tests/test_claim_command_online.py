from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.config import AuthConfig, ConfigStore, ProfileConfig, RawctxConfig
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import ClaimResult


def _save_auth_config() -> None:
    store = ConfigStore()
    store.save(
        RawctxConfig(
            registry="https://registry.example",
            auth=AuthConfig(token="rxctx_test_token"),
            profile=ProfileConfig(username="owner"),
        )
    )


def test_claim_command_success(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    _save_auth_config()

    monkeypatch.setattr(
        RegistryClient,
        "claim_package",
        lambda self, scope, name: ClaimResult(
            package=f"@{scope}/{name}",
            origin_repo="dbt-labs/jaffle-shop",
            origin_url="https://github.com/dbt-labs/jaffle-shop",
            claim_status="claimed",
            claimed_by="user-1",
            claimed_at="2026-03-02T16:15:00Z",
            suggested_native_ref="@owner/jaffle-shop",
            next_publish_command="rawctx publish --from-dbt . --package-name @owner/jaffle-shop",
        ),
    )

    runner = CliRunner()
    result = runner.invoke(main, ["claim", "@dbt-hub/jaffle-shop", "--registry", "https://registry.example"])

    assert result.exit_code == 0
    assert "Claim status: claimed" in result.output
    assert "Next step: rawctx publish --from-dbt . --package-name @owner/jaffle-shop" in result.output


def test_claim_command_requires_auth(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    runner = CliRunner()
    result = runner.invoke(main, ["claim", "@dbt-hub/jaffle-shop", "--registry", "https://registry.example"])

    assert result.exit_code != 0
    assert "Authentication required. Run `rawctx login` first." in result.output


def test_claim_command_maps_registry_errors(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    _save_auth_config()

    def _raise_conflict(self, *, scope: str, name: str):  # type: ignore[no-untyped-def]
        raise RegistryError(
            "Registry request failed (409): Package has already been claimed by another user",
            status_code=409,
            detail="Package has already been claimed by another user",
        )

    monkeypatch.setattr(RegistryClient, "claim_package", _raise_conflict)

    runner = CliRunner()
    result = runner.invoke(main, ["claim", "@dbt-hub/jaffle-shop", "--registry", "https://registry.example"])
    assert result.exit_code != 0
    assert "Registry request failed (409)" in result.output


def test_claim_command_maps_github_failure(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    _save_auth_config()

    def _raise_unavailable(self, *, scope: str, name: str):  # type: ignore[no-untyped-def]
        raise RegistryError(
            "Registry request failed (503): Failed to verify GitHub repository ownership",
            status_code=503,
            detail="Failed to verify GitHub repository ownership",
        )

    monkeypatch.setattr(RegistryClient, "claim_package", _raise_unavailable)

    runner = CliRunner()
    result = runner.invoke(main, ["claim", "@dbt-hub/jaffle-shop", "--registry", "https://registry.example"])
    assert result.exit_code != 0
    assert "Registry request failed (503)" in result.output
