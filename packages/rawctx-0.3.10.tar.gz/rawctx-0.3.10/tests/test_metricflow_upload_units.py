from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from click.testing import CliRunner
import pytest

from rawctx.cli import main
from rawctx.commands import publish as publish_module
from rawctx.converter.base import ConversionError
from rawctx.package_formats.metricflow import (
    _as_validation_error,
    _has_metricflow_content,
    _read_yaml,
    MetricFlowPackageFormatAdapter,
    materialize_metricflow_package_from_project,
)
from rawctx.package_formats.osi import OsiPackageFormatAdapter
from rawctx.packaging.manifest import Manifest, ValidationError
from rawctx.registry.client import RegistryError


def _write_dbt_project(base: Path) -> Path:
    project_dir = base / "dbt_project"
    models_dir = project_dir / "models" / "semantic_models"
    models_dir.mkdir(parents=True, exist_ok=True)
    (project_dir / "dbt_project.yml").write_text(
        """
name: "jaffle_shop"
version: "1.2.3"
config-version: 2
""".strip()
        + "\n",
        encoding="utf-8",
    )
    (models_dir / "orders.yml").write_text(
        """
version: 2
semantic_models:
  - name: orders
    model: ref('fct_orders')
    entities:
      - name: order
        type: primary
        expr: order_id
    measures:
      - name: gross_revenue
        expr: amount
metrics:
  - name: gross_revenue
    type: simple
    type_params:
      measure: gross_revenue
""".strip()
        + "\n",
        encoding="utf-8",
    )
    return project_dir


def _write_native_metricflow_package(
    base: Path,
    *,
    invalid_model: bool = False,
    extra_valid_model: bool = False,
) -> Path:
    package_dir = base / "metricflow-native"
    models_dir = package_dir / "models" / "semantic_models"
    models_dir.mkdir(parents=True, exist_ok=True)
    (package_dir / "dbt_project.yml").write_text(
        """
name: "jaffle_shop"
version: "1.2.3"
config-version: 2
""".strip()
        + "\n",
        encoding="utf-8",
    )
    (package_dir / "rawctx.yaml").write_text(
        """
name: "@owner/metricflow-native"
version: "1.2.3"
format: "metricflow"
models:
  - models/semantic_models/orders.yml
include:
  - rawctx.yaml
  - README.md
""".strip()
        + "\n",
        encoding="utf-8",
    )
    (package_dir / "README.md").write_text("# Native package\n", encoding="utf-8")
    (models_dir / "orders.yml").write_text(
        ("version: 2\nsemantic_models:\n  - name: orders\n" if not invalid_model else "version: 2\n"),
        encoding="utf-8",
    )
    if extra_valid_model:
        (models_dir / "customers.yml").write_text(
            "version: 2\nsemantic_models:\n  - name: customers\n",
            encoding="utf-8",
        )
    return package_dir


def _configure_auth(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_test")


def test_base_archive_entries_skip_support_files(tmp_path: Path) -> None:
    package_dir = _write_native_metricflow_package(tmp_path)
    adapter = OsiPackageFormatAdapter()

    entries = adapter._archive_entries(  # noqa: SLF001
        package_dir,
        [
            package_dir / "rawctx.yaml",
            package_dir / "README.md",
            package_dir / "models" / "semantic_models" / "orders.yml",
        ],
    )

    assert entries == [("package/models/semantic_models/orders.yml", package_dir / "models" / "semantic_models" / "orders.yml")]


def test_metricflow_private_helpers_cover_error_paths(tmp_path: Path) -> None:
    assert _has_metricflow_content([{"metrics": [{"name": "m1"}]}]) is True
    assert _has_metricflow_content("nope") is False

    invalid_yaml = tmp_path / "invalid.yml"
    invalid_yaml.write_text("semantic_models: [\n", encoding="utf-8")
    with pytest.raises(ValidationError, match="invalid YAML syntax"):
        _read_yaml(invalid_yaml)

    missing = tmp_path / "missing.yml"
    with pytest.raises(ValidationError, match="failed to read MetricFlow file"):
        _read_yaml(missing)

    exc = ConversionError("boom", file_path=missing, field="models")
    wrapped = _as_validation_error(exc)
    assert str(wrapped) == "boom (" + str(missing) + ", field 'models')"


def test_materialize_metricflow_package_overwrite_branches(tmp_path: Path) -> None:
    project_dir = _write_dbt_project(tmp_path)
    output_dir = tmp_path / "out"
    output_dir.mkdir()
    (output_dir / "old.txt").write_text("old\n", encoding="utf-8")

    with pytest.raises(RuntimeError, match="output already exists"):
        materialize_metricflow_package_from_project(
            project_dir,
            output_dir,
            package_name="@owner/pkg",
            package_version="1.2.3",
            overwrite=False,
        )

    written = materialize_metricflow_package_from_project(
        project_dir,
        output_dir,
        package_name="@owner/pkg",
        package_version="1.2.3",
        overwrite=True,
    )
    assert (output_dir / "old.txt").exists() is False
    assert (output_dir / "dbt_project.yml") in written


def test_metricflow_adapter_rejects_non_semantic_model_file(tmp_path: Path) -> None:
    package_dir = _write_native_metricflow_package(tmp_path, invalid_model=True, extra_valid_model=True)
    manifest = Manifest(
        name="@owner/metricflow-native",
        version="1.2.3",
        format="metricflow",
        models=["models/semantic_models/orders.yml"],
        include=["rawctx.yaml", "README.md"],
    )
    adapter = MetricFlowPackageFormatAdapter()

    with pytest.raises(ValidationError, match="MetricFlow model file must include semantic_models or metrics"):
        adapter.validate_directory(package_dir, manifest)


def test_metricflow_adapter_wraps_conversion_errors(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    package_dir = _write_native_metricflow_package(tmp_path)
    manifest = Manifest(
        name="@owner/metricflow-native",
        version="1.2.3",
        format="metricflow",
        models=["models/semantic_models/orders.yml"],
    )
    adapter = MetricFlowPackageFormatAdapter()

    monkeypatch.setattr(
        "rawctx.package_formats.metricflow.load_metricflow_project",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(
            ConversionError("broken project", file_path=package_dir / "models", field="semantic_models")
        ),
    )

    with pytest.raises(ValidationError, match="broken project"):
        adapter.validate_directory(package_dir, manifest)


def test_publish_usage_and_validation_errors(monkeypatch, tmp_path: Path) -> None:
    project_dir = _write_dbt_project(tmp_path)
    package_dir = _write_native_metricflow_package(tmp_path / "pkg")
    runner = CliRunner()

    result = runner.invoke(main, ["publish", str(package_dir), "--from-dbt", str(project_dir)])
    assert result.exit_code != 0
    assert "target_dir argument cannot be used with --from-dbt" in result.output

    result = runner.invoke(main, ["publish", str(package_dir), "--native"])
    assert result.exit_code != 0
    assert "--native can only be used with --from-dbt" in result.output

    not_dir = tmp_path / "not-dir.txt"
    not_dir.write_text("x\n", encoding="utf-8")
    result = runner.invoke(main, ["publish", str(not_dir)])
    assert result.exit_code != 0
    assert "publish target must be a directory" in result.output

    monkeypatch.setattr(publish_module, "validate_target", lambda *_args, **_kwargs: (_ for _ in ()).throw(ValidationError("bad")))
    result = runner.invoke(main, ["publish", str(package_dir)])
    assert result.exit_code != 0
    assert "bad" in result.output


def test_publish_missing_manifest_and_registry_errors(monkeypatch, tmp_path: Path) -> None:
    package_dir = _write_native_metricflow_package(tmp_path)
    _configure_auth(monkeypatch, tmp_path)
    runner = CliRunner()

    monkeypatch.setattr(publish_module, "validate_target", lambda *_args, **_kwargs: SimpleNamespace(manifest=None))
    result = runner.invoke(main, ["publish", str(package_dir), "--registry", "https://registry.example"])
    assert result.exit_code != 0
    assert "manifest validation did not produce a manifest" in result.output

    monkeypatch.setattr(
        publish_module,
        "validate_target",
        lambda *_args, **_kwargs: SimpleNamespace(
            manifest=Manifest(name="@owner/metricflow-native", version="1.2.3", format="metricflow", models=["models/semantic_models/orders.yml"])
        ),
    )
    monkeypatch.setattr(publish_module, "build_package_archive", lambda *_args, **_kwargs: SimpleNamespace(archive_path=package_dir / "README.md"))
    original_read_bytes = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda self: b"archive" if self == package_dir / "README.md" else original_read_bytes(self))

    def _raise_create(self, *, payload):  # type: ignore[no-untyped-def]
        del payload
        raise RegistryError("create failed", status_code=500)

    monkeypatch.setattr(publish_module.RegistryClient, "create_package", _raise_create)
    result = runner.invoke(main, ["publish", str(package_dir), "--registry", "https://registry.example"])
    assert result.exit_code != 0
    assert "create failed" in result.output


def test_publish_org_lookup_and_upload_url_errors(monkeypatch, tmp_path: Path) -> None:
    package_dir = _write_native_metricflow_package(tmp_path)
    _configure_auth(monkeypatch, tmp_path)
    runner = CliRunner()

    def _manifest_result(*_args, **_kwargs):
        return SimpleNamespace(
            manifest=Manifest(name="@owner/metricflow-native", version="1.2.3", format="metricflow", models=["models/semantic_models/orders.yml"])
        )

    monkeypatch.setattr(publish_module, "validate_target", _manifest_result)
    monkeypatch.setattr(publish_module, "build_package_archive", lambda *_args, **_kwargs: SimpleNamespace(archive_path=package_dir / "README.md"))
    original_read_bytes = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda self: b"archive" if self == package_dir / "README.md" else original_read_bytes(self))
    monkeypatch.setattr(publish_module.RegistryClient, "get_org", lambda self, orgname: {"id": ""})

    result = runner.invoke(main, ["publish", str(package_dir), "--org", "team", "--registry", "https://registry.example"])
    assert result.exit_code != 0
    assert "Organization lookup failed: team" in result.output

    monkeypatch.setattr(publish_module.RegistryClient, "get_org", lambda self, orgname: {"id": "org-1"})
    monkeypatch.setattr(publish_module.RegistryClient, "create_package", lambda self, payload: None)
    monkeypatch.setattr(
        publish_module.RegistryClient,
        "request_version_upload",
        lambda self, **kwargs: {"version": kwargs["version"], "version_id": "v1", "s3_key": "key", "expires_in": 1},
    )

    result = runner.invoke(main, ["publish", str(package_dir), "--org", "team", "--registry", "https://registry.example"])
    assert result.exit_code != 0
    assert "Registry did not return upload_url" in result.output


def test_build_metricflow_helpers_cleanup_existing_emit_dir(monkeypatch, tmp_path: Path) -> None:
    project_dir = _write_dbt_project(tmp_path)
    emit_dir = tmp_path / "emit"
    emit_dir.mkdir()
    _configure_auth(monkeypatch, tmp_path)
    store = publish_module.ConfigStore()

    native_tmp = tmp_path / "native-tmp"
    monkeypatch.setattr(publish_module.tempfile, "mkdtemp", lambda prefix: str(native_tmp))
    with pytest.raises(ConversionError, match="emit package path already exists"):
        publish_module._build_metricflow_native_package(  # noqa: SLF001
            project_dir,
            package_name="@owner/native",
            package_version="1.2.3",
            emit_package_dir=emit_dir,
            store=store,
        )
    assert native_tmp.exists() is False

    osi_tmp = tmp_path / "osi-tmp"
    monkeypatch.setattr(publish_module.tempfile, "mkdtemp", lambda prefix: str(osi_tmp))
    with pytest.raises(ConversionError, match="emit package path already exists"):
        publish_module._build_metricflow_osi_package(  # noqa: SLF001
            project_dir,
            package_name="@owner/osi",
            package_version="1.2.3",
            emit_package_dir=emit_dir,
            store=store,
        )
    assert osi_tmp.exists() is False
