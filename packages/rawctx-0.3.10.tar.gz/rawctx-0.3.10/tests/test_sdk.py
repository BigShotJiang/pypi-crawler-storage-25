from __future__ import annotations

import asyncio
import base64
from io import BytesIO
import json
from pathlib import Path
import tarfile

from click.testing import CliRunner
import pytest

import rawctx
from rawctx.cli import main
from rawctx.config import ConfigStore, DEFAULT_REGISTRY, load_package_cache, save_package_cache, upsert_cache_entry
from rawctx.formats.osi import assign_measure_datasets
from rawctx.registry.client import AsyncRegistryClient, RegistryClient, SearchResult
from rawctx.registry.models import ApiTokenInfo, OAuthLoginInfo, PackageDetail, SearchItem, VersionInfo


def _fake_jwt(payload: dict[str, object]) -> str:
    header = base64.urlsafe_b64encode(json.dumps({"alg": "none", "typ": "JWT"}).encode("utf-8")).decode("utf-8").rstrip("=")
    body = base64.urlsafe_b64encode(json.dumps(payload).encode("utf-8")).decode("utf-8").rstrip("=")
    return f"{header}.{body}.signature"


def _archive_bytes(
    version: str,
    *,
    package_name: str = "@owner/sample",
    model_files: dict[str, str] | None = None,
    manifest_models: list[str] | None = None,
) -> bytes:
    payload = BytesIO()
    default_model_files = {
        "models/sample.osi.yaml": (
            "version: \"0.1.1\"\n"
            "dialects:\n"
            "  - ANSI_SQL\n"
            "vendors:\n"
            "  - COMMON\n"
            "semantic_model:\n"
            "  - name: sample\n"
            "    datasets:\n"
            "      - name: sample\n"
            "        source: analytics.sample\n"
        ),
    }
    effective_model_files = model_files or default_model_files
    effective_manifest_models = manifest_models or list(effective_model_files.keys())

    with tarfile.open(fileobj=payload, mode="w:gz") as tar:
        files = {
            "package/rawctx.yaml": (
                f"name: \"{package_name}\"\n"
                f"version: \"{version}\"\n"
                "format: \"osi\"\n"
                "models:\n"
                + "".join(f"  - {path}\n" for path in effective_manifest_models)
            ),
        }
        files.update({f"package/{path}": content for path, content in effective_model_files.items()})
        for name, content in files.items():
            content_bytes = content.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(content_bytes)
            info.mtime = 0
            tar.addfile(info, BytesIO(content_bytes))
    return payload.getvalue()


def _complex_archive_bytes(version: str) -> bytes:
    return _archive_bytes(
        version,
        model_files={
            "models/core.osi.yaml": (
                "version: \"0.1.1\"\n"
                "dialects:\n"
                "  - ANSI_SQL\n"
                "vendors:\n"
                "  - COMMON\n"
                "semantic_model:\n"
                "  - name: travel_core\n"
                "    datasets:\n"
                "      - name: users\n"
                "        source: analytics.users\n"
                "        fields:\n"
                "          - name: id\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"id\"\n"
                "      - name: trips\n"
                "        source: analytics.trips\n"
                "        fields:\n"
                "          - name: trip_count\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"trip_count\"\n"
                "          - name: currency_code\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"currency_code\"\n"
                "            dimension: {}\n"
                "    relationships:\n"
                "      - name: trip_user\n"
                "        from: trips\n"
                "        to: users\n"
                "        from_columns:\n"
                "          - user_id\n"
                "        to_columns:\n"
                "          - id\n"
                "    metrics:\n"
                "      - name: total_amount\n"
                "        description: \"Total trip amount\"\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"SUM(trips.amount)\"\n"
                "      - name: trip_count\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"COUNT(*)\"\n"
                "      - name: unresolved_margin\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"SUM(margin)\"\n"
                "  - name: expense_reporting\n"
                "    datasets:\n"
                "      - name: expense_reports\n"
                "        source: analytics.expense_reports\n"
                "        fields:\n"
                "          - name: submitted_at\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"submitted_at\"\n"
                "            dimension:\n"
                "              is_time: true\n"
                "    metrics:\n"
                "      - name: report_total\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"SUM(amount)\"\n"
            ),
            "models/rollups.osi.yaml": (
                "version: \"0.1.1\"\n"
                "dialects:\n"
                "  - ANSI_SQL\n"
                "vendors:\n"
                "  - COMMON\n"
                "semantic_model:\n"
                "  - name: trip_rollups\n"
                "    datasets:\n"
                "      - name: trips\n"
                "        source: analytics.trip_rollups\n"
                "        fields:\n"
                "          - name: region\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"region\"\n"
                "            dimension: {}\n"
                "    metrics:\n"
                "      - name: duplicate_amount\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"SUM(trips.amount)\"\n"
            ),
        },
        manifest_models=["models/core.osi.yaml", "models/rollups.osi.yaml"],
    )


def _prompt_archive_bytes(version: str) -> bytes:
    return _archive_bytes(
        version,
        package_name="@owner/zoho-expense",
        model_files={
            "models/zoho-expense.osi.yaml": (
                "version: \"0.1.1\"\n"
                "dialects:\n"
                "  - ANSI_SQL\n"
                "vendors:\n"
                "  - COMMON\n"
                "semantic_model:\n"
                "  - name: zoho_expense\n"
                "    datasets:\n"
                "      - name: expense_reports\n"
                "        source: finance.expense_reports\n"
                "        description: company expense reports\n"
                "        fields:\n"
                "          - name: status\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"status\"\n"
                "            dimension: {}\n"
                "          - name: department\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"department\"\n"
                "            dimension: {}\n"
                "          - name: submitted_by\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"submitted_by\"\n"
                "            dimension: {}\n"
                "          - name: project_id\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"project_id\"\n"
                "            dimension: {}\n"
                "          - name: currency_code\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"currency_code\"\n"
                "            dimension: {}\n"
                "      - name: users\n"
                "        source: hr.users\n"
                "        description: employee records\n"
                "        fields:\n"
                "          - name: role\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"role\"\n"
                "            dimension: {}\n"
                "          - name: email\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"email\"\n"
                "            dimension: {}\n"
                "          - name: department\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"department\"\n"
                "            dimension: {}\n"
                "          - name: manager_id\n"
                "            expression:\n"
                "              dialects:\n"
                "                - dialect: ANSI_SQL\n"
                "                  expression: \"manager_id\"\n"
                "            dimension: {}\n"
                "    relationships:\n"
                "      - name: expense_submitter\n"
                "        from: expense_reports\n"
                "        to: users\n"
                "        from_columns:\n"
                "          - submitted_by\n"
                "        to_columns:\n"
                "          - user_id\n"
                "      - name: expense_project\n"
                "        from: expense_reports\n"
                "        to: projects\n"
                "        from_columns:\n"
                "          - project_id\n"
                "        to_columns:\n"
                "          - project_id\n"
                "    metrics:\n"
                "      - name: total_amount\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"SUM(expense_reports.total_amount)\"\n"
                "      - name: approved_amount\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"SUM(expense_reports.approved_amount)\"\n"
                "      - name: reimbursed_amount\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"SUM(expense_reports.reimbursed_amount)\"\n"
                "      - name: rejected_amount\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"SUM(expense_reports.rejected_amount)\"\n"
                "      - name: report_count\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"COUNT(users.user_id)\"\n"
                "      - name: approver_count\n"
                "        expression:\n"
                "          dialects:\n"
                "            - dialect: ANSI_SQL\n"
                "              expression: \"COUNT(users.manager_id)\"\n"
            ),
        },
    )


def _metricflow_archive_bytes(version: str, *, package_name: str = "@owner/jaffle-metricflow") -> bytes:
    payload = BytesIO()
    with tarfile.open(fileobj=payload, mode="w:gz") as tar:
        files = {
            "package/rawctx.yaml": (
                f"name: \"{package_name}\"\n"
                f"version: \"{version}\"\n"
                "format: \"metricflow\"\n"
                "models:\n"
                "  - models/customers.yml\n"
                "  - models/orders.yml\n"
            ),
            "package/dbt_project.yml": (
                "name: \"jaffle_shop\"\n"
                f"version: \"{version}\"\n"
            ),
            "package/models/customers.yml": (
                "semantic_models:\n"
                "  - name: customers\n"
                "    entities:\n"
                "      - name: customer\n"
                "        type: primary\n"
                "        expr: customer_id\n"
                "    dimensions:\n"
                "      - name: customer_name\n"
                "        type: categorical\n"
                "    measures:\n"
                "      - name: customer_count\n"
                "        agg: sum\n"
                "metrics:\n"
                "  - name: customers_with_orders\n"
                "    type: simple\n"
                "    type_params:\n"
                "      measure: customer_count\n"
            ),
            "package/models/orders.yml": (
                "semantic_models:\n"
                "  - name: orders\n"
                "    entities:\n"
                "      - name: order\n"
                "        type: primary\n"
                "        expr: order_id\n"
                "      - name: customer\n"
                "        type: foreign\n"
                "        expr: customer_id\n"
                "    dimensions:\n"
                "      - name: ordered_at\n"
                "        type: time\n"
                "    measures:\n"
                "      - name: order_total\n"
                "        expr: order_total\n"
                "        agg: sum\n"
                "metrics:\n"
                "  - name: total_orders\n"
                "    semantic_model: orders\n"
                "    type: simple\n"
                "    type_params:\n"
                "      measure: order_total\n"
            ),
        }
        for name, content in files.items():
            content_bytes = content.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(content_bytes)
            info.mtime = 0
            tar.addfile(info, BytesIO(content_bytes))
    return payload.getvalue()


def _native_package(
    scope: str,
    name: str,
    *,
    origin: str = "native",
    source: str | None = None,
    origin_url: str | None = None,
    domain: str | None = None,
    description: str = "Sample",
) -> PackageDetail:
    return PackageDetail(
        id="pkg",
        scope=scope,
        name=name,
        description=description,
        format="osi",
        source_format=None,
        origin=origin,
        origin_url=origin_url,
        origin_repo=None,
        source=source,
        domain=domain,
        license=None,
        repository_url=None,
        readme=None,
        tags=[],
        is_private=False,
        download_count=0,
        star_count=0,
        owner=None,
    )


def _write_valid_package(base: Path) -> Path:
    package_dir = base / "example"
    models_dir = package_dir / "models"
    models_dir.mkdir(parents=True)

    (package_dir / "rawctx.yaml").write_text(
        """
name: "@demo/retail-analytics"
version: "1.0.0"
format: "osi"
description: "Retail analytics semantic model"
models:
  - models/sales_summary.osi.yaml
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (package_dir / "README.md").write_text("# Retail Analytics\n", encoding="utf-8")

    (models_dir / "sales_summary.osi.yaml").write_text(
        """
version: "0.1.1"
dialects:
  - ANSI_SQL
vendors:
  - COMMON
semantic_model:
  - name: sales_summary
    datasets:
      - name: sales_summary
        source: analytics.sales_summary
        fields:
          - name: order_count
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: "count(*)"
          - name: order_date
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: "order_date"
            dimension:
              is_time: true
    metrics:
      - name: order_count
        expression:
          dialects:
            - dialect: ANSI_SQL
              expression: "count(*)"
""".strip()
        + "\n",
        encoding="utf-8",
    )

    return package_dir


def _write_metricflow_project(base: Path) -> Path:
    project_dir = base / "dbt_project"
    models_dir = project_dir / "models" / "semantic_models"
    models_dir.mkdir(parents=True, exist_ok=True)

    (project_dir / "dbt_project.yml").write_text(
        """
name: "jaffle_shop"
version: "1.2.3"
config-version: 2
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (models_dir / "orders.yml").write_text(
        """
version: 2
semantic_models:
  - name: orders
    model: ref('fct_orders')
    entities:
      - name: order
        type: primary
        expr: order_id
    dimensions:
      - name: ordered_at
        type: time
        expr: ordered_at
    measures:
      - name: order_count
        expr: 1

metrics:
  - name: order_count
    type: simple
    type_params:
      measure: order_count
""".strip()
        + "\n",
        encoding="utf-8",
    )

    return project_dir


def test_rawctx_exports_and_sync_login_logout(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    assert callable(rawctx.search)
    assert callable(rawctx.download)
    assert callable(rawctx.snapshot_download)
    assert callable(rawctx.load)
    assert callable(rawctx.to_prompt)
    assert rawctx.RawctxClient is not None
    assert rawctx.AsyncRawctxClient is not None

    monkeypatch.setattr(
        RegistryClient,
        "oauth_login",
        lambda self: OAuthLoginInfo(authorize_url="https://auth.example/login", state="state123"),
    )
    monkeypatch.setattr(
        RegistryClient,
        "create_api_token",
        lambda self, *, id_token, name, expires_in_days=None: ApiTokenInfo(
            id="token-id",
            name=name,
            token="rxctx_token",
            prefix="rxctx_",
            created_at="2026-02-28T00:00:00Z",
            expires_at=None,
        ),
    )
    monkeypatch.setattr(RegistryClient, "revoke_api_token", lambda self, token_id: True)

    payload = rawctx.login(
        registry="https://registry.example",
        no_browser=True,
        id_token=_fake_jwt({"preferred_username": "owner"}),
    )
    assert payload["username"] == "owner"
    assert payload["token_id"] == "token-id"

    logout_payload = rawctx.logout()
    assert logout_payload["had_token"] is True
    assert logout_payload["revoked"] is True


def test_search_json_parity_with_sdk(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        return SearchResult(
            items=[
                SearchItem(
                    id="pkg-1",
                    scope="owner",
                    name="sample",
                    description="Sample",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="shopify",
                    domain="finance",
                    tags=["demo"],
                    download_count=1,
                    star_count=2,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "sort": sort},
        )

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    sdk_payload = rawctx.search("sample", registry="https://registry.example", sort="downloads")

    runner = CliRunner()
    result = runner.invoke(
        main,
        ["search", "sample", "--sort", "downloads", "--registry", "https://registry.example", "--json"],
    )

    assert result.exit_code == 0, result.output
    assert json.loads(result.output) == sdk_payload


def test_info_includes_model_paths(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg-1",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source="shopify",
            domain="finance",
            license=None,
            repository_url=None,
            readme=None,
            tags=["demo"],
            is_private=False,
            download_count=1,
            star_count=2,
            owner=None,
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v1",
                    version="1.2.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary={"dataset_count": 1},
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                    manifest={
                        "name": "@owner/sample",
                        "version": "1.2.0",
                        "format": "osi",
                        "models": ["models/sample.osi.yaml", "models/orders.osi.yaml"],
                    },
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )

    payload = rawctx.info("@owner/sample", registry="https://registry.example")
    assert payload["model_paths"] == ["models/sample.osi.yaml", "models/orders.osi.yaml"]
    assert payload["model_paths_version"] == "1.2.0"

    runner = CliRunner()
    result = runner.invoke(main, ["info", "@owner/sample", "--registry", "https://registry.example"])

    assert result.exit_code == 0, result.output
    assert "models/sample.osi.yaml" in result.output
    assert "models/orders.osi.yaml" in result.output


def test_assign_measure_datasets_prefers_explicit_dataset() -> None:
    owners = assign_measure_datasets(
        [
            {
                "name": "gross_revenue",
                "dataset": "orders",
                "expression": {"dialects": [{"dialect": "ANSI_SQL", "expression": "SUM(amount)"}]},
            }
        ],
        ["orders", "customers"],
        {"orders": set(), "customers": set()},
    )

    assert owners == ["orders"]


def test_load_returns_typed_package(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(RegistryClient, "get_package", lambda self, scope, name: _native_package(scope, name))
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _complex_archive_bytes("1.0.0"))

    loaded = rawctx.load("@owner/sample", registry="https://registry.example")

    assert isinstance(loaded, rawctx.LoadedPackage)
    assert loaded.package == "@owner/sample"
    assert loaded.version == "1.0.0"
    assert loaded.format_name == "osi"
    assert loaded.model_paths == ["models/core.osi.yaml", "models/rollups.osi.yaml"]
    assert loaded.snapshot_dir == Path(rawctx.snapshot_download("@owner/sample", registry="https://registry.example"))
    assert loaded.datasets == ["users", "trips", "expense_reports"]
    assert [measure.name for measure in loaded.measures] == [
        "total_amount",
        "trip_count",
        "unresolved_margin",
        "report_total",
        "duplicate_amount",
    ]
    assert [measure.dataset for measure in loaded.measures] == [
        "trips",
        "trips",
        None,
        "expense_reports",
        "trips",
    ]
    assert [dimension.name for dimension in loaded.dimensions] == ["currency_code", "submitted_at", "region"]
    assert loaded.relationships == [
        rawctx.Relationship(
            name="trip_user",
            from_dataset="trips",
            to_dataset="users",
            from_columns=["user_id"],
            to_columns=["id"],
            model="travel_core",
            path="models/core.osi.yaml",
            ai_context=None,
        )
    ]
    assert [model.name for model in loaded.models] == ["travel_core", "expense_reporting", "trip_rollups"]
    assert loaded.models[0].datasets == ["users", "trips"]
    assert loaded.models[1].datasets == ["expense_reports"]
    assert loaded.models[2].datasets == ["trips"]
    assert loaded.models[0].measures[0].path == "models/core.osi.yaml"
    assert loaded.models[2].measures[0].model == "trip_rollups"


def test_load_offline_uses_cached_snapshot(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    store = ConfigStore()
    snapshot_dir = store.paths.install_path("owner", "sample", "1.1.0", registry=DEFAULT_REGISTRY)
    snapshot_dir.parent.mkdir(parents=True, exist_ok=True)

    archive = BytesIO(_complex_archive_bytes("1.1.0"))
    with tarfile.open(fileobj=archive, mode="r:gz") as tar:
        tar.extractall(snapshot_dir.parent)

    extracted_package_dir = snapshot_dir.parent / "package"
    extracted_package_dir.rename(snapshot_dir)

    loaded = rawctx.load("@owner/sample@1.1.0", offline=True)

    assert loaded.version == "1.1.0"
    assert loaded.snapshot_dir == snapshot_dir
    assert loaded.datasets == ["users", "trips", "expense_reports"]


def test_load_metricflow_native_package(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: _native_package(scope, name, description="MetricFlow package"),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _metricflow_archive_bytes("1.0.0"))

    loaded = rawctx.load("@owner/jaffle-metricflow", registry="https://registry.example")

    assert isinstance(loaded, rawctx.LoadedPackage)
    assert loaded.package == "@owner/jaffle-metricflow"
    assert loaded.version == "1.0.0"
    assert loaded.format_name == "metricflow"
    assert loaded.model_paths == ["models/customers.yml", "models/orders.yml"]
    assert loaded.datasets == ["customers", "orders"]
    assert [measure.name for measure in loaded.measures] == [
        "customer_count",
        "customers_with_orders",
        "order_total",
        "total_orders",
    ]
    assert [measure.dataset for measure in loaded.measures] == [
        "customers",
        "customers",
        "orders",
        "orders",
    ]
    assert [dimension.name for dimension in loaded.dimensions] == ["customer_name", "ordered_at"]
    assert loaded.relationships == [
        rawctx.Relationship(
            name="orders__customer__to__customers",
            from_dataset="orders",
            to_dataset="customers",
            from_columns=["customer_id"],
            to_columns=["customer_id"],
            model="orders",
            path="models/orders.yml",
            ai_context=None,
        )
    ]
    assert [model.name for model in loaded.models] == ["customers", "orders"]


def test_load_blocks_indexed_package(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: _native_package(
            scope,
            name,
            origin="indexed",
            source="dbt-hub",
            origin_url="https://hub.getdbt.com/fivetran/shopify/latest/",
        ),
    )

    with pytest.raises(rawctx.RawctxError, match="indexed from dbt Hub"):
        rawctx.load("@owner/sample", registry="https://registry.example")


def test_to_prompt_returns_compressed_context(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: _native_package(scope, name, domain="finance", description="Zoho Expense"),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _prompt_archive_bytes("1.0.0"))

    prompt = rawctx.to_prompt("@owner/zoho-expense", registry="https://registry.example")

    assert prompt == (
        "Domain: finance (zoho-expense)\n\n"
        "Datasets:\n"
        "- expense_reports: company expense reports\n"
        "  measures: total_amount, approved_amount, reimbursed_amount, rejected_amount\n"
        "  dimensions: status, department, submitted_by, project_id, currency_code\n\n"
        "- users: employee records\n"
        "  measures: report_count, approver_count\n"
        "  dimensions: role, email, department, manager_id\n\n"
        "Relationships:\n"
        "- expense_reports.submitted_by -> users.user_id\n"
        "- expense_reports.project_id -> projects.project_id"
    )


def test_to_prompt_dataset_filter_and_missing_dataset(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: _native_package(scope, name, domain="finance"),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _prompt_archive_bytes("1.0.0"))

    prompt = rawctx.to_prompt(
        "@owner/zoho-expense",
        datasets=["expense_reports", "users", "expense_reports"],
        registry="https://registry.example",
    )

    assert prompt.startswith("Domain: finance (zoho-expense)")
    assert "- expense_reports: company expense reports" in prompt
    assert "- users: employee records" in prompt
    assert "projects.project_id" in prompt
    assert prompt.index("- expense_reports: company expense reports") < prompt.index("- users: employee records")

    with pytest.raises(rawctx.UsageError, match="Unknown dataset\\(s\\): missing_dataset"):
        rawctx.to_prompt(
            "@owner/zoho-expense",
            datasets=["expense_reports", "missing_dataset"],
            registry="https://registry.example",
        )


def test_to_prompt_applies_approximate_token_cap(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: _native_package(scope, name, domain="finance"),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _prompt_archive_bytes("1.0.0"))

    prompt = rawctx.to_prompt(
        "@owner/zoho-expense",
        datasets=["expense_reports", "users"],
        max_tokens=60,
        registry="https://registry.example",
    )

    assert prompt == (
        "Domain: finance (zoho-expense)\n\n"
        "Datasets:\n"
        "- expense_reports\n"
        "- users\n\n"
        "Relationships:\n"
        "-"
    )


def test_to_prompt_supports_metricflow_native_package(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="MetricFlow package",
            format="metricflow",
            source_format="metricflow",
            origin="native",
            origin_url=None,
            origin_repo=None,
            source="dbt",
            domain="finance",
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _metricflow_archive_bytes("1.0.0"))

    prompt = rawctx.to_prompt("@owner/jaffle-metricflow", registry="https://registry.example")

    assert prompt.startswith("Domain: finance (jaffle-metricflow)")
    assert "- customers: customers" in prompt
    assert "measures: customer_count, customers_with_orders" in prompt
    assert "- orders: orders" in prompt
    assert "measures: order_total, total_orders" in prompt
    assert "orders.customer_id -> customers.customer_id" in prompt


def test_to_prompt_offline_uses_cached_info_and_snapshot(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    store = ConfigStore()
    cache = load_package_cache(store.paths)
    upsert_cache_entry(
        cache,
        scope="owner",
        name="zoho-expense",
        registry=DEFAULT_REGISTRY,
        package={
            "id": "pkg-1",
            "scope": "owner",
            "name": "zoho-expense",
            "description": "Zoho Expense",
            "format": "osi",
            "source_format": None,
            "origin": "native",
            "origin_url": None,
            "origin_repo": None,
            "source": "zoho",
            "domain": "finance",
            "latest_osi_version": "1.1.0",
            "tags": ["finance"],
            "download_count": 0,
            "star_count": 0,
        },
        versions=[
            {
                "id": "ver-110",
                "version": "1.1.0",
                "status": "published",
                "search_index_status": "indexed",
                "file_size": 123,
                "checksum_sha256": "a" * 64,
                "manifest": {
                    "name": "@owner/zoho-expense",
                    "version": "1.1.0",
                    "format": "osi",
                    "models": ["models/zoho-expense.osi.yaml"],
                },
                "model_summary": {"dataset_count": 2},
                "created_at": "2026-02-28T00:00:00Z",
                "published_at": "2026-02-28T00:00:00Z",
            }
        ],
    )
    save_package_cache(store.paths, cache)

    snapshot_dir = store.paths.install_path("owner", "zoho-expense", "1.1.0", registry=DEFAULT_REGISTRY)
    snapshot_dir.parent.mkdir(parents=True, exist_ok=True)
    archive = BytesIO(_prompt_archive_bytes("1.1.0"))
    with tarfile.open(fileobj=archive, mode="r:gz") as tar:
        tar.extractall(snapshot_dir.parent)
    (snapshot_dir.parent / "package").rename(snapshot_dir)

    prompt = rawctx.to_prompt(
        "@owner/zoho-expense@1.1.0",
        datasets=["expense_reports", "users"],
        offline=True,
    )

    assert prompt.startswith("Domain: finance (zoho-expense)")
    assert "expense_reports.submitted_by -> users.user_id" in prompt


def test_search_prefers_public_results_before_authenticated_fallback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_secret")

    observed_tokens: list[str | None] = []

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        observed_tokens.append(self.token)
        if self.token:
            return SearchResult(
                items=[
                    SearchItem(
                        id="private-1",
                        scope="owner",
                        name="private-result",
                        description="Private fallback result",
                        format="osi",
                        source_format=None,
                        origin="native",
                        origin_url=None,
                        origin_repo=None,
                        source="salesforce",
                        domain="crm",
                        tags=["private"],
                        download_count=0,
                        star_count=0,
                    )
                ],
                meta={"page": page, "size": size, "total": 1, "engine": "postgres", "query_mode": "fallback"},
            )
        return SearchResult(
            items=[
                SearchItem(
                    id="public-1",
                    scope="owner",
                    name="public-result",
                    description="Public search result",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="salesforce",
                    domain="crm",
                    tags=["public"],
                    download_count=0,
                    star_count=0,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "engine": "opensearch", "query_mode": "exact"},
        )

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    payload = rawctx.search("sf revenue", registry="https://registry.example")

    assert payload["items"][0]["name"] == "public-result"
    assert payload["meta"]["engine"] == "opensearch"
    assert observed_tokens == [None]


def test_search_falls_back_to_authenticated_results_when_public_is_empty(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_secret")

    observed_tokens: list[str | None] = []

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        observed_tokens.append(self.token)
        if self.token:
            return SearchResult(
                items=[
                    SearchItem(
                        id="private-1",
                        scope="owner",
                        name="private-result",
                        description="Private fallback result",
                        format="osi",
                        source_format=None,
                        origin="native",
                        origin_url=None,
                        origin_repo=None,
                        source="salesforce",
                        domain="crm",
                        tags=["private"],
                        download_count=0,
                        star_count=0,
                    )
                ],
                meta={"page": page, "size": size, "total": 1, "engine": "postgres", "query_mode": "fallback"},
            )
        return SearchResult(items=[], meta={"page": page, "size": size, "total": 0, "engine": "opensearch", "query_mode": "exact"})

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    payload = rawctx.search("private package", registry="https://registry.example")

    assert payload["items"][0]["name"] == "private-result"
    assert payload["meta"]["engine"] == "postgres"
    assert observed_tokens == [None, "rxctx_secret"]


def test_download_json_parity_with_sdk(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _archive_bytes("1.0.0"))

    sdk_path = rawctx.download("@owner/sample", "models/sample.osi.yaml", registry="https://registry.example")

    runner = CliRunner()
    cli_result = runner.invoke(
        main,
        [
            "download",
            "@owner/sample",
            "models/sample.osi.yaml",
            "--registry",
            "https://registry.example",
            "--json",
        ],
    )

    assert cli_result.exit_code == 0, cli_result.output
    assert json.loads(cli_result.output) == {
        "package": "@owner/sample",
        "version": "1.0.0",
        "path": "models/sample.osi.yaml",
        "local_path": sdk_path,
    }


def test_snapshot_download_json_parity_with_sdk(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _archive_bytes("1.0.0"))

    sdk_path = rawctx.snapshot_download("@owner/sample", registry="https://registry.example")

    runner = CliRunner()
    cli_result = runner.invoke(
        main,
        ["snapshot-download", "@owner/sample", "--registry", "https://registry.example", "--json"],
    )

    assert cli_result.exit_code == 0, cli_result.output
    assert json.loads(cli_result.output) == {
        "package": "@owner/sample",
        "version": "1.0.0",
        "local_path": sdk_path,
        "files": ["models/sample.osi.yaml"],
    }


def test_async_rawctx_client_search(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    async def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        return SearchResult(
            items=[
                SearchItem(
                    id="pkg-1",
                    scope="owner",
                    name="sample",
                    description="Sample",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="shopify",
                    domain="finance",
                    tags=["demo"],
                    download_count=1,
                    star_count=2,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "sort": sort},
        )

    monkeypatch.setattr(AsyncRegistryClient, "search_packages", fake_search_packages)

    async def run() -> dict:
        async with rawctx.AsyncRawctxClient(registry="https://registry.example") as client:
            return await client.search("sample", sort="stars")

    payload = asyncio.run(run())
    assert payload["meta"]["sort"] == "recent"
    assert payload["items"][0]["name"] == "sample"


def test_async_load(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    async def fake_get_package(self, *, scope, name):
        return _native_package(scope, name)

    async def fake_list_versions(self, *, scope, name, page=1, size=100):
        return (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        )

    async def fake_request_download(self, *, scope, name, version):
        return {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900}

    async def fake_download_bytes(self, *, download_url):
        return _complex_archive_bytes("1.0.0")

    monkeypatch.setattr(AsyncRegistryClient, "get_package", fake_get_package)
    monkeypatch.setattr(AsyncRegistryClient, "list_versions", fake_list_versions)
    monkeypatch.setattr(AsyncRegistryClient, "request_download", fake_request_download)
    monkeypatch.setattr(AsyncRegistryClient, "download_bytes", fake_download_bytes)

    async def run() -> rawctx.LoadedPackage:
        async with rawctx.AsyncRawctxClient(registry="https://registry.example") as client:
            return await client.load("@owner/sample")

    loaded = asyncio.run(run())
    assert isinstance(loaded, rawctx.LoadedPackage)
    assert loaded.datasets == ["users", "trips", "expense_reports"]
    assert [model.name for model in loaded.models] == ["travel_core", "expense_reporting", "trip_rollups"]
    assert loaded.measures[2].dataset is None


def test_async_to_prompt_matches_sync(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: _native_package(scope, name, domain="finance"),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _prompt_archive_bytes("1.0.0"))

    async def fake_get_package(self, *, scope, name):
        return _native_package(scope, name, domain="finance")

    async def fake_list_versions(self, *, scope, name, page=1, size=100):
        return (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        )

    async def fake_request_download(self, *, scope, name, version):
        return {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900}

    async def fake_download_bytes(self, *, download_url):
        return _prompt_archive_bytes("1.0.0")

    monkeypatch.setattr(AsyncRegistryClient, "get_package", fake_get_package)
    monkeypatch.setattr(AsyncRegistryClient, "list_versions", fake_list_versions)
    monkeypatch.setattr(AsyncRegistryClient, "request_download", fake_request_download)
    monkeypatch.setattr(AsyncRegistryClient, "download_bytes", fake_download_bytes)

    expected = rawctx.to_prompt(
        "@owner/zoho-expense",
        datasets=["expense_reports", "users"],
        registry="https://registry.example",
    )

    async def run() -> str:
        async with rawctx.AsyncRawctxClient(registry="https://registry.example") as client:
            return await client.to_prompt("@owner/zoho-expense", datasets=["expense_reports", "users"])

    assert asyncio.run(run()) == expected


def test_async_search_prefers_public_results_before_authenticated_fallback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_secret")

    observed_tokens: list[str | None] = []

    async def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        observed_tokens.append(self.token)
        if self.token:
            return SearchResult(
                items=[
                    SearchItem(
                        id="private-1",
                        scope="owner",
                        name="private-result",
                        description="Private fallback result",
                        format="osi",
                        source_format=None,
                        origin="native",
                        origin_url=None,
                        origin_repo=None,
                        source="salesforce",
                        domain="crm",
                        tags=["private"],
                        download_count=0,
                        star_count=0,
                    )
                ],
                meta={"page": page, "size": size, "total": 1, "engine": "postgres", "query_mode": "fallback"},
            )
        return SearchResult(
            items=[
                SearchItem(
                    id="public-1",
                    scope="owner",
                    name="public-result",
                    description="Public search result",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="salesforce",
                    domain="crm",
                    tags=["public"],
                    download_count=0,
                    star_count=0,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "engine": "opensearch", "query_mode": "exact"},
        )

    monkeypatch.setattr(AsyncRegistryClient, "search_packages", fake_search_packages)

    async def run() -> dict:
        async with rawctx.AsyncRawctxClient(registry="https://registry.example") as client:
            return await client.search("sf revenue")

    payload = asyncio.run(run())
    assert payload["items"][0]["name"] == "public-result"
    assert payload["meta"]["engine"] == "opensearch"
    assert observed_tokens == [None]


def test_async_download_and_snapshot_download(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    async def fake_get_package(self, *, scope, name):
        return PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        )

    async def fake_list_versions(self, *, scope, name, page=1, size=100):
        return (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        )

    async def fake_request_download(self, *, scope, name, version):
        return {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900}

    async def fake_download_bytes(self, *, download_url):
        return _archive_bytes("1.0.0")

    monkeypatch.setattr(AsyncRegistryClient, "get_package", fake_get_package)
    monkeypatch.setattr(AsyncRegistryClient, "list_versions", fake_list_versions)
    monkeypatch.setattr(AsyncRegistryClient, "request_download", fake_request_download)
    monkeypatch.setattr(AsyncRegistryClient, "download_bytes", fake_download_bytes)

    async def run() -> tuple[str, str]:
        async with rawctx.AsyncRawctxClient(registry="https://registry.example") as client:
            snapshot_path = await client.snapshot_download("@owner/sample")
            file_path = await client.download("@owner/sample", "models/sample.osi.yaml")
            return snapshot_path, file_path

    snapshot_path, file_path = asyncio.run(run())
    assert snapshot_path.endswith("/@owner/sample/1.0.0")
    assert file_path.endswith("/models/sample.osi.yaml")


def test_validate_and_pack_json_parity_with_sdk(tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    sdk_validate = rawctx.validate(package_dir)
    sdk_pack = rawctx.pack(package_dir, output_dir=tmp_path / "dist")

    runner = CliRunner()
    validate_result = runner.invoke(main, ["validate", str(package_dir), "--json"])
    pack_result = runner.invoke(main, ["pack", str(package_dir), "--output-dir", str(tmp_path / "dist"), "--json"])

    assert validate_result.exit_code == 0, validate_result.output
    assert pack_result.exit_code == 0, pack_result.output
    assert json.loads(validate_result.output) == sdk_validate
    assert json.loads(pack_result.output) == sdk_pack


def test_convert_json_parity_with_sdk(monkeypatch, tmp_path: Path) -> None:
    project_dir = _write_metricflow_project(tmp_path)
    config_path = tmp_path / "rawctx" / "config.yaml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text("profile:\n  username: owner\n", encoding="utf-8")
    monkeypatch.setenv("RAWCTX_CONFIG", str(config_path))

    output_dir = tmp_path / "converted"
    sdk_payload = rawctx.convert(project_dir, from_format="metricflow", to_format="osi", output=output_dir)

    runner = CliRunner()
    cli_result = runner.invoke(
        main,
        [
            "convert",
            "--from",
            "metricflow",
            "--to",
            "osi",
            str(project_dir),
            "--output",
            str(output_dir),
            "--overwrite",
            "--json",
        ],
    )

    assert cli_result.exit_code == 0, cli_result.output
    assert json.loads(cli_result.output) == sdk_payload
