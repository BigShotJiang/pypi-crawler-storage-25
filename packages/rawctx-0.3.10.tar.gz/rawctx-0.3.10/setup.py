from __future__ import annotations

import sys
from pathlib import Path

from setuptools import setup

PROJECT_ROOT = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from build_hooks import FreshBuildPy


setup(cmdclass={"build_py": FreshBuildPy})
