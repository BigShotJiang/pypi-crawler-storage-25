from typing import Any, Literal

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company import Candlestick
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class CandlestickAPI(BaseAPI):
    """Candlestick (K-line) data APIs."""

    async def get_candlestick(  # noqa: PLR0913
        self,
        stock_code: str,
        start_date: str,
        end_date: str,
        adjust_type: Literal["ex_rights", "lxr_fc_rights", "fc_rights", "bc_rights"] | None = None,
        adjust_forward_date: str | None = None,
        adjust_backward_date: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """获取K线数据.

        API Endpoint: /cn/company/candlestick
        API Method: POST

        Args:
            stock_code: 股票代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)
            adjust_type: 复权类型
                - ex_rights: 不复权
                - lxr_fc_rights: 理杏仁前复权
                - fc_rights: 前复权
                - bc_rights: 后复权
            adjust_forward_date: 前复权指定起始时间点 (YYYY-MM-DD)，需要与endDate一起使用且大于或等于endDate
            adjust_backward_date: 后复权指定起始时间点 (YYYY-MM-DD)，需要与startDate一起使用且小于或等于startDate
            limit: 返回最近数据的数量

        Returns:
            DataFrame containing candlestick data

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
            "startDate": start_date,
            "endDate": end_date,
        }
        if adjust_type is not None:
            payload["type"] = adjust_type
        if adjust_forward_date is not None:
            payload["adjustForwardDate"] = adjust_forward_date
        if adjust_backward_date is not None:
            payload["adjustBackwardDate"] = adjust_backward_date
        if limit is not None:
            payload["limit"] = limit

        data = await self._request("POST", "/cn/company/candlestick", json=payload)
        return get_response_df(data, Candlestick)


# Functional API instance
_api_instance = CandlestickAPI()


@api
async def get_candlestick(  # noqa: PLR0913
    stock_code: str,
    start_date: str,
    end_date: str,
    adjust_type: Literal["ex_rights", "lxr_fc_rights", "fc_rights", "bc_rights"] | None = None,
    adjust_forward_date: str | None = None,
    adjust_backward_date: str | None = None,
    limit: int | None = None,
) -> pd.DataFrame:
    """获取K线数据.

    Args:
        stock_code: 股票代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD)
        adjust_type: 复权类型
            - ex_rights: 不复权
            - lxr_fc_rights: 理杏仁前复权
            - fc_rights: 前复权
            - bc_rights: 后复权
        adjust_forward_date: 前复权指定起始时间点 (YYYY-MM-DD)
        adjust_backward_date: 后复权指定起始时间点 (YYYY-MM-DD)
        limit: 返回最近数据的数量

    Returns:
        DataFrame containing candlestick data

    Example:
        >>> df = await get_candlestick(
        ...     stock_code="300750",
        ...     start_date="2025-04-01",
        ...     end_date="2026-04-01",
        ...     adjust_type="lxr_fc_rights"
        ... )

    """
    return await _api_instance.get_candlestick(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        adjust_type=adjust_type,
        adjust_forward_date=adjust_forward_date,
        adjust_backward_date=adjust_backward_date,
        limit=limit,
    )
