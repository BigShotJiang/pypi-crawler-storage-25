"""TUI / Host 共用的轻量偏好（如主对话 ``/mode``），持久化在 ``HOME/data/tui_prefs.json``。"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Final

MAIN_CHAT_CANONICAL_MODES: Final[frozenset[str]] = frozenset(
    {"default", "chat", "doc", "plan"}
)
# 主会话「场景」工作模式（与 main_chat_mode 正交）；持久化键 **work_mode**
WORK_MODE_CANONICAL_MODES: Final[frozenset[str]] = frozenset(
    {"general", "dev", "script", "pentest", "ops"}
)
# 启动横幅 / TUI 展示用（与 builtin 提示词正交）
WORK_MODE_DISPLAY_ZH: Final[dict[str, str]] = {
    "general": "通用",
    "dev": "开发",
    "script": "脚本/自动化",
    "pentest": "安全评估（授权）",
    "ops": "运维/可靠性",
}


def work_mode_display_name_zh(mode: str) -> str:
    """工作模式键 → 简短中文名（未知键原样返回）。"""
    m = (mode or "").strip().lower() or "general"
    return WORK_MODE_DISPLAY_ZH.get(m, mode)


TUI_PREFS_FILENAME = "tui_prefs.json"


def parse_main_chat_mode_token(raw: str) -> tuple[str | None, str]:
    """
    解析 ``/mode``、Host 参数中的模式名。

    返回 ``(canonical, err)``：成功时 ``canonical`` 为 ``default|chat|doc|plan`` 且 ``err==""``；
    ``err=="help"`` 表示帮助意图；否则 ``canonical is None`` 且 ``err`` 为可读错误。
    """
    m = (raw or "").strip().lower()
    if not m:
        return None, "empty"
    if m in ("help", "?", "h"):
        return None, "help"
    if m in ("default", "balanced", "normal", "standard"):
        return "default", ""
    if m in ("chat", "qa", "q&a", "ask"):
        return "chat", ""
    if m in ("doc", "deliver", "author", "files", "library"):
        return "doc", ""
    if m in ("plan", "orchestrate", "router", "coordinate"):
        return "plan", ""
    return None, f"未知模式 {raw!r}；可用 default、chat、doc、plan"


def parse_work_mode_token(raw: str) -> tuple[str | None, str]:
    """
    解析 TUI ``/workmode``、Host 的 **work_mode** 参数。

    返回 ``(canonical, err)``：成功时为 ``general|dev|script|pentest|ops``；
    ``err==help`` 表示帮助；否则 ``canonical is None``。
    """
    m = (raw or "").strip().lower()
    if not m:
        return None, "empty"
    if m in ("help", "?", "h"):
        return None, "help"
    if m in ("general", "default", "balanced", "normal", "standard"):
        return "general", ""
    if m in ("dev", "development", "build", "code"):
        return "dev", ""
    if m in ("script", "scripts", "automation", "cli"):
        return "script", ""
    if m in ("pentest", "penetration", "security", "sec"):
        return "pentest", ""
    if m in ("ops", "ops_mode", "sre", "oper", "运维"):
        return "ops", ""
    return None, f"未知工作模式 {raw!r}；可用 general、dev、script、pentest、ops"


def load_main_chat_mode(data_dir: Path) -> str | None:
    """从 ``data_dir/tui_prefs.json`` 读取 ``main_chat_mode``；非法或缺失返回 ``None``。"""
    p = (data_dir / TUI_PREFS_FILENAME).resolve()
    if not p.is_file():
        return None
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(obj, dict):
            return None
        m = str(obj.get("main_chat_mode", "")).strip().lower()
        if m in MAIN_CHAT_CANONICAL_MODES:
            return m
    except (OSError, json.JSONDecodeError, TypeError):
        pass
    return None


def load_work_mode(data_dir: Path) -> str | None:
    """读取 ``work_mode``；非法或缺失返回 ``None``。"""
    p = (data_dir / TUI_PREFS_FILENAME).resolve()
    if not p.is_file():
        return None
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(obj, dict):
            return None
        m = str(obj.get("work_mode", "")).strip().lower()
        if m in WORK_MODE_CANONICAL_MODES:
            return m
    except (OSError, json.JSONDecodeError, TypeError):
        pass
    return None


def load_assistant_markdown_chat(data_dir: Path) -> bool:
    """
    是否用 Rich Markdown 渲染助手回复（粗体/标题/列表/行内代码等，见 ``resolve_tui_assistant_markdown_chat``）。

    未写配置文件、或 JSON 中**未出现** ``assistant_markdown_chat`` 键时默认 **开**；
    仅当键存在且为 ``false`` 时关。
    """
    p = (data_dir / TUI_PREFS_FILENAME).resolve()
    if not p.is_file():
        return True
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(obj, dict):
            return True
        if "assistant_markdown_chat" not in obj:
            return True
        v = obj.get("assistant_markdown_chat")
        if v is None:
            return True
        return bool(v)
    except (OSError, json.JSONDecodeError, TypeError):
        return True


def resolve_tui_assistant_markdown_chat(data_dir: Path) -> bool:
    """
    助手区是否按 Markdown 排版（Rich 将 ``**`` 转为粗体、``##`` 为标题等，GFM 表仍由 ``tui_chat_render`` 预处理）。

    优先级：环境变量 **AICD_TUI_ASSISTANT_MARKDOWN**（1/true/yes/on 开；0/false/off 关）>
    ``tui_prefs.json`` 的 **assistant_markdown_chat**；默认 **开**（TUI 中更易读）。
    """
    e = (os.environ.get("AICD_TUI_ASSISTANT_MARKDOWN") or "").strip().lower()
    if e in ("1", "true", "yes", "on"):
        return True
    if e in ("0", "false", "no", "off"):
        return False
    return load_assistant_markdown_chat(data_dir)


def save_main_chat_mode(data_dir: Path, mode: str) -> None:
    """合并写入 ``main_chat_mode``；保留 JSON 内其它键。"""
    if mode not in MAIN_CHAT_CANONICAL_MODES:
        return
    data_dir = data_dir.resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    p = data_dir / TUI_PREFS_FILENAME
    prev: dict[str, object] = {}
    if p.is_file():
        try:
            loaded = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                prev = dict(loaded)
        except (OSError, json.JSONDecodeError, TypeError):
            prev = {}
    prev["main_chat_mode"] = mode
    p.write_text(
        json.dumps(prev, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def save_work_mode(data_dir: Path, mode: str) -> None:
    """合并写入 ``work_mode``；保留 JSON 内其它键。"""
    if mode not in WORK_MODE_CANONICAL_MODES:
        return
    data_dir = data_dir.resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    p = data_dir / TUI_PREFS_FILENAME
    prev: dict[str, object] = {}
    if p.is_file():
        try:
            loaded = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                prev = dict(loaded)
        except (OSError, json.JSONDecodeError, TypeError):
            prev = {}
    prev["work_mode"] = mode
    p.write_text(
        json.dumps(prev, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
