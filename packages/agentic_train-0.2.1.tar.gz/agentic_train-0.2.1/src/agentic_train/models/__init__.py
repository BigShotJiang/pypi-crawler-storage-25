from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Generic, Self, Union, cast

import torch
from agentic_base.mixins import FromConfigMixin
from agentic_train.types import TCModel
from safetensors.torch import load_file as load_safetensors
from torch import nn
from transformers import PreTrainedModel


class Model(FromConfigMixin[TCModel], ABC, Generic[TCModel]):
    def __init__(self, config: TCModel):
        self.config = config

    @abstractmethod
    def to_hf_model(self) -> PreTrainedModel:  # inplace
        raise NotImplementedError()

    def save(
        self,
        repo_dir: Union[str, Path],
        push: bool = False,
        **push_kwargs: Any,
    ) -> None:
        repo_dir_path = Path(repo_dir) if isinstance(repo_dir, str) else repo_dir
        self.to_hf_model().save_pretrained(repo_dir_path)
        if push:
            self.to_hf_model().push_to_hub(
                repo_dir_path.name,  # type: ignore[arg-type]
                **push_kwargs,
            )

    def to(self, device: str) -> Self:
        cast(nn.Module, self.to_hf_model()).to(device)
        return self

    @classmethod
    def from_checkpoint(
        cls,
        config: TCModel,
        checkpoint: str,
        device: str,
        strict: bool = True,
    ) -> "Model[TCModel]":
        model = cls(config)
        hf_model = model.to_hf_model()
        checkpoint_path = Path(checkpoint)
        # Case 1: Hugging Face directory (model.safetensors)
        if checkpoint_path.is_dir():
            state_dict_path = checkpoint_path / "model.safetensors"
            if not state_dict_path.exists():
                raise FileNotFoundError(
                    f"No model.safetensors found in {checkpoint_path}"
                )
            state_dict = load_safetensors(state_dict_path)
        # Case 2: raw state_dict (.pt or .bin)
        else:
            state_dict = torch.load(checkpoint_path, map_location="cpu")["model_state"]
            if not isinstance(state_dict, dict):
                raise ValueError("Checkpoint must be a state_dict")
        hf_model.load_state_dict(state_dict, strict=strict)
        hf_model.to(device)  # type: ignore[arg-type]
        return model
