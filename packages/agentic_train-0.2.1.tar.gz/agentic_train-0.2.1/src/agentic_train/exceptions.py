class AgenticTrainError(Exception):
    """Base exception for all agentic_train errors."""


# -------------------------
# Runtime errors
# -------------------------
class AgenticTrainRuntimeError(RuntimeError, AgenticTrainError):
    """Runtime errors during execution (training, loading, etc.)."""


class MissingContextError(AgenticTrainRuntimeError):
    """Raised when required context is missing."""


# -------------------------
# Type errors
# -------------------------
class AgenticTrainTypeError(TypeError, AgenticTrainError):
    """Invalid type provided."""


class InvalidRunnerClassError(AgenticTrainTypeError):
    """Runner class is not valid or does not inherit expected base."""


# -------------------------
# Value errors
# -------------------------
class AgenticTrainValueError(ValueError, AgenticTrainError):
    """Invalid value provided in configuration or runtime."""
