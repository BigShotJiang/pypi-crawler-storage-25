import importlib
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any

from huggingface_hub import HfApi

if TYPE_CHECKING:
    pass


def load_class(path: str) -> Any:
    module_path, class_name = path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def save_extra_files_locally(
    *,
    files: list[str],
    target_dir: Path,
) -> None:
    """
    Copy extra source files into the local HF repo directory.
    """
    target_dir.mkdir(parents=True, exist_ok=True)

    for file in files:
        src = Path(file)
        if not src.exists():
            raise FileNotFoundError(f"Extra file not found: {src}")

        dst = target_dir / src.name
        shutil.copy2(src, dst)


def push_extra_files_to_hf(
    *,
    repo_id: str,
    files: list[str],
    revision: str | None,
    commit_message: str,
) -> None:
    api = HfApi()

    for file in files:
        path = Path(file)

        api.upload_file(
            path_or_fileobj=path,
            path_in_repo=path.name,
            repo_id=repo_id,
            repo_type="model",
            revision=revision,
            commit_message=commit_message,
        )
