import random
from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, List, Optional, Tuple

from agentic_base.mixins import FromConfigMixin
from agentic_train.settings import StepRangeDistanceSettings
from agentic_train.types import T, TCDistance, TCSampler


class Sampler(ABC, Generic[TCSampler, T]):
    RANDOM_SEED = 42

    def __init__(self, config: TCSampler, context: Optional[Dict[str, Any]]) -> None:
        self.config = config
        self.context = context
        self.rng = random.Random(self.config.seed)

    @abstractmethod
    def sample(self, item: T, **kwargs: Any) -> List[str]:
        pass

    def _init_components(self) -> None:
        pass


class Distance(FromConfigMixin[TCDistance], ABC, Generic[TCDistance]):
    def __init__(self, config: TCDistance) -> None:
        self.config = config

    @abstractmethod
    def __call__(self, a: Tuple[int, int], b: Tuple[int, int]) -> int:
        raise NotImplementedError


class StepRangeDistance(Distance[StepRangeDistanceSettings]):
    def __init__(self, config: StepRangeDistanceSettings) -> None:
        super().__init__(config)

    def __call__(self, a: Tuple[int, int], b: Tuple[int, int]) -> int:
        if a[1] < b[0]:
            return b[0] - a[1]
        if b[1] < a[0]:
            return a[0] - b[1]
        return 0
