RANDOM_SEED = 42
CONFIG_PATH = "/config/config.yaml"
TRUST_REMOTE_CODE = True
