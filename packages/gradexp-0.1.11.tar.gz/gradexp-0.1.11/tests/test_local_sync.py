import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import requests

from gradexp import local_sync


class FakeHostedSyncClient:
    def __init__(self):
        self.api_base_url = "https://api.gradient-explorer.xyz"
        self.created_runs = []
        self.created_tensors = []
        self.uploaded_batches = []
        self.updated_statuses = []

    def create_run(self, project_name, run_name, source="sync"):
        self.created_runs.append((project_name, run_name))
        return {
            "project_id": "remote-project-1",
            "run_id": "remote-run-1",
            "run_name": run_name,
        }

    def create_tensor(self, run_id, tensor):
        tensor_id = f"remote-tensor-{len(self.created_tensors) + 1}"
        self.created_tensors.append((run_id, tensor["name"]))
        return {"tensor_id": tensor_id}

    def upload_tensor_steps(self, tensor_id, steps):
        self.uploaded_batches.append((tensor_id, [item["step"] for item in steps]))
        total_bytes = sum(len(item["value"]) for item in steps)
        return len(steps), total_bytes

    def update_run_status(self, run_id, status):
        self.updated_statuses.append((run_id, status))


class TestLocalSync(unittest.TestCase):
    def test_sync_is_incremental_and_persists_state(self):
        remote_user = {"id": "remote-user-1", "username": "tester"}
        sync_client = FakeHostedSyncClient()

        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            self._write_store(
                data_dir,
                steps=[0, 1],
                run_status="complete",
            )

            first_summary = local_sync.sync_local_data_once(data_dir, sync_client, remote_user)
            self.assertTrue(first_summary.changed())
            self.assertEqual(first_summary.runs_created, 1)
            self.assertEqual(first_summary.tensors_created, 1)
            self.assertEqual(first_summary.steps_uploaded, 2)
            # Status set immediately on creation (complete != active), so no end-of-run update
            self.assertEqual(first_summary.statuses_updated, 0)
            # But update_run_status was called during creation for non-active status
            self.assertEqual(len(sync_client.updated_statuses), 1)
            self.assertEqual(sync_client.updated_statuses[0], ("remote-run-1", "complete"))

            sync_state = json.loads((data_dir / local_sync.SYNC_STATE_FILENAME).read_text())
            account_state = next(iter(sync_state["accounts"].values()))
            self.assertEqual(account_state["runs"]["local-run-1"]["remote_run_id"], "remote-run-1")
            self.assertEqual(account_state["tensors"]["local-tensor-1"]["last_synced_step"], 1)

            second_summary = local_sync.sync_local_data_once(data_dir, sync_client, remote_user)
            self.assertFalse(second_summary.changed())
            self.assertEqual(len(sync_client.created_runs), 1)
            self.assertEqual(len(sync_client.created_tensors), 1)
            self.assertEqual(len(sync_client.uploaded_batches), 1)
            self.assertEqual(len(sync_client.updated_statuses), 1)

            self._write_store(
                data_dir,
                steps=[0, 1, 2],
                run_status="complete",
            )
            third_summary = local_sync.sync_local_data_once(data_dir, sync_client, remote_user)
            self.assertEqual(third_summary.steps_uploaded, 1)
            self.assertEqual(third_summary.step_batches_uploaded, 1)
            self.assertEqual(sync_client.uploaded_batches[-1], ("remote-tensor-1", [2]))

    def test_build_hosted_sync_client_falls_back_to_saved_token(self):
        def fake_get_remote_user(instance):
            if instance.api_key == "gradexp-local-token":
                response = MagicMock()
                response.status_code = 401
                error = requests.exceptions.HTTPError("unauthorized")
                error.response = response
                raise error
            return {"id": "remote-user-1", "username": "tester"}

        with patch.dict(os.environ, {"GRADEXP_API_KEY": "gradexp-local-token"}, clear=False), \
             patch("gradexp.local_sync.auth.get_api_base_url", return_value="https://api.gradient-explorer.xyz"), \
             patch("gradexp.local_sync.auth.load_saved_token", return_value="saved-remote-token"), \
             patch.object(local_sync.HostedSyncClient, "get_remote_user", new=fake_get_remote_user):
            sync_client, remote_user = local_sync._build_hosted_sync_client()

        self.assertEqual(sync_client.api_key, "saved-remote-token")
        self.assertEqual(remote_user["id"], "remote-user-1")

    def test_watch_mode_clears_idle_status_before_summary(self):
        outputs = []
        seq = [
            local_sync.SyncSummary(store_available=True),
            local_sync.SyncSummary(store_available=True, steps_uploaded=3, bytes_uploaded=9),
            KeyboardInterrupt(),
        ]

        def fake_sync(*args, **kwargs):
            item = seq.pop(0)
            if isinstance(item, BaseException):
                raise item
            return item

        fake_client = type("FakeClient", (), {"api_base_url": "https://api.gradient-explorer.xyz"})()
        remote_user = {"id": "remote-user-1", "username": "tester"}

        with patch.object(local_sync, "_build_hosted_sync_client", return_value=(fake_client, remote_user)), \
             patch.object(local_sync, "sync_local_data_once", side_effect=fake_sync), \
             patch("time.sleep", return_value=None), \
             patch("click.echo", side_effect=lambda message="", nl=True: outputs.append((message, nl))):
            local_sync.run_local_sync(data_dir="/tmp/fake-gradexp-data", once=False, interval=0.01)

        self.assertIn(("\r" + (" " * local_sync._STATUS_LINE_WIDTH) + "\r", False), outputs)
        summary_index = outputs.index(("Sync complete for tester: 3 steps (9 B).", True))
        clear_index = outputs.index(("\r" + (" " * local_sync._STATUS_LINE_WIDTH) + "\r", False))
        self.assertLess(clear_index, summary_index)

    def test_iter_pending_step_batches_accounts_for_wire_size(self):
        with tempfile.TemporaryDirectory() as tmp_dir, \
             patch.object(local_sync, "DEFAULT_SYNC_MAX_BATCH_BYTES", 100):
            data_dir = Path(tmp_dir)
            blobs_dir = data_dir / "blobs" / "local-tensor-1"
            blobs_dir.mkdir(parents=True, exist_ok=True)
            (blobs_dir / "0.bin").write_bytes(b"a" * 40)
            (blobs_dir / "1.bin").write_bytes(b"b" * 40)

            tensor = {
                "tensorId": "local-tensor-1",
                "steps": [0, 1],
            }
            tensor_state = {"last_synced_step": -1}

            batches = list(local_sync._iter_pending_step_batches(data_dir, tensor, tensor_state))

        self.assertEqual([[item["step"] for item in batch] for batch in batches], [[0], [1]])

    def test_hosted_sync_client_falls_back_to_raw_step_after_413(self):
        class FakeResponse:
            def __init__(self, status_code):
                self.status_code = status_code

            def raise_for_status(self):
                if self.status_code >= 400:
                    error = requests.exceptions.HTTPError(f"{self.status_code} error")
                    error.response = self
                    raise error

        class FakeSession:
            def __init__(self):
                self.calls = []

            def post(self, url, **kwargs):
                self.calls.append((url, kwargs))
                if url.endswith("/steps"):
                    return FakeResponse(413)
                if url.endswith("/step?step=7"):
                    return FakeResponse(200)
                raise AssertionError(f"unexpected URL: {url}")

        session = FakeSession()
        sync_client = local_sync.HostedSyncClient(
            "test_api_key",
            api_base_url="https://api.gradient-explorer.xyz",
            session=session,
        )

        uploaded_steps, uploaded_bytes = sync_client.upload_tensor_steps(
            "tensor-123",
            [{"step": 7, "value": b"\x00\x01\x02"}],
        )

        self.assertEqual((uploaded_steps, uploaded_bytes), (1, 3))
        self.assertEqual(len(session.calls), 2)
        self.assertEqual(session.calls[0][1]["headers"]["Content-Type"], "application/json")
        self.assertEqual(
            session.calls[0][1]["data"],
            b'{"steps":[{"step":7,"value":"AAEC"}]}',
        )
        self.assertEqual(session.calls[1][1]["headers"]["Content-Type"], "application/octet-stream")
        self.assertEqual(session.calls[1][1]["data"], b"\x00\x01\x02")

    def test_get_local_sync_status_reports_pending_tensors_and_bytes(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            self._write_store(
                data_dir,
                steps=[0, 1, 2],
                run_status="active",
            )
            (data_dir / local_sync.SYNC_STATE_FILENAME).write_text(
                json.dumps(
                    {
                        "version": local_sync.SYNC_STATE_VERSION,
                        "accounts": {
                            "https://api.gradient-explorer.xyz|remote-user-1": {
                                "remote_api_base_url": "https://api.gradient-explorer.xyz",
                                "remote_user_id": "remote-user-1",
                                "runs": {
                                    "local-run-1": {
                                        "remote_run_id": "remote-run-1",
                                    }
                                },
                                "tensors": {
                                    "local-tensor-1": {
                                        "remote_tensor_id": "remote-tensor-1",
                                        "last_synced_step": 1,
                                    }
                                },
                            }
                        },
                    },
                    indent=2,
                )
            )

            summary = local_sync.get_local_sync_status(data_dir)

        self.assertTrue(summary.store_available)
        self.assertEqual(summary.total_runs, 1)
        self.assertEqual(summary.total_tensors, 1)
        self.assertEqual(summary.total_steps, 3)
        self.assertEqual(summary.unsynced_tensors, 1)
        self.assertEqual(summary.unsynced_steps, 1)
        self.assertEqual(summary.unsynced_bytes, 3)
        self.assertGreater(summary.local_bytes, summary.unsynced_bytes)

    def test_sync_collapses_gradient_stats_progress_into_one_grouped_line(self):
        remote_user = {"id": "remote-user-1", "username": "tester"}
        sync_client = FakeHostedSyncClient()

        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            self._write_gradient_stats_store(data_dir)
            (data_dir / local_sync.SYNC_STATE_FILENAME).write_text(
                json.dumps(
                    {
                        "version": local_sync.SYNC_STATE_VERSION,
                        "accounts": {
                            "https://api.gradient-explorer.xyz|remote-user-1": {
                                "remote_api_base_url": "https://api.gradient-explorer.xyz",
                                "remote_user_id": "remote-user-1",
                                "runs": {
                                    "local-run-1": {
                                        "remote_run_id": "remote-run-1",
                                        "last_synced_status": "active",
                                    }
                                },
                                "tensors": {
                                    "local-tensor-1": {
                                        "remote_tensor_id": "remote-tensor-1",
                                        "last_synced_step": -1,
                                    },
                                    "local-tensor-2": {
                                        "remote_tensor_id": "remote-tensor-2",
                                        "last_synced_step": -1,
                                    },
                                },
                            }
                        },
                    },
                    indent=2,
                )
            )

            outputs = []
            with patch("click.echo", side_effect=lambda message="", nl=True: outputs.append((message, nl))):
                summary = local_sync.sync_local_data_once(data_dir, sync_client, remote_user)

        self.assertEqual(summary.steps_uploaded, 2)
        grouped_progress = [item for item in outputs if "gradient stats" in item[0]]
        self.assertEqual(len(grouped_progress), 2)
        self.assertEqual(sum(1 for _, nl in grouped_progress if nl), 1)
        self.assertTrue(any("step 7" in message for message, _ in grouped_progress))
        self.assertFalse(any(message.startswith("\r    ↑ attn/grad_l2") for message, _ in outputs))
        self.assertFalse(any(message.startswith("\r    ↑ mlp/grad_l2") for message, _ in outputs))

    def _write_store(self, data_dir, steps, run_status):
        blobs_dir = data_dir / "blobs" / "local-tensor-1"
        blobs_dir.mkdir(parents=True, exist_ok=True)
        for step in steps:
            (blobs_dir / f"{step}.bin").write_bytes(bytes([step + 1, step + 2, step + 3]))

        store = {
            "version": 1,
            "projects": [
                {
                    "projectId": "local-project-1",
                    "userId": "local-user",
                    "name": "project-a",
                    "createdAt": "2026-03-19T10:00:00Z",
                }
            ],
            "runs": [
                {
                    "runId": "local-run-1",
                    "projectId": "local-project-1",
                    "name": "run-a",
                    "status": run_status,
                    "createdAt": "2026-03-19T10:01:00Z",
                    "lastActivityAt": "2026-03-19T10:02:00Z",
                }
            ],
            "tensors": [
                {
                    "tensorId": "local-tensor-1",
                    "runId": "local-run-1",
                    "name": "weights",
                    "dtype": "float32",
                    "shape": [3],
                    "dimensionLabels": [],
                    "createdAt": "2026-03-19T10:01:30Z",
                    "updatedAt": "2026-03-19T10:02:00Z",
                    "stepCount": len(steps),
                    "minStep": min(steps) if steps else None,
                    "maxStep": max(steps) if steps else None,
                    "steps": steps,
                }
            ],
        }
        (data_dir / "store.json").write_text(json.dumps(store, indent=2))

    def _write_gradient_stats_store(self, data_dir):
        for tensor_id, payload in (("local-tensor-1", b"\x01\x02"), ("local-tensor-2", b"\x03\x04")):
            blobs_dir = data_dir / "blobs" / tensor_id
            blobs_dir.mkdir(parents=True, exist_ok=True)
            (blobs_dir / "7.bin").write_bytes(payload)

        store = {
            "version": 1,
            "projects": [
                {
                    "projectId": "local-project-1",
                    "userId": "local-user",
                    "name": "project-a",
                    "createdAt": "2026-03-19T10:00:00Z",
                }
            ],
            "runs": [
                {
                    "runId": "local-run-1",
                    "projectId": "local-project-1",
                    "name": "run-a",
                    "status": "active",
                    "createdAt": "2026-03-19T10:01:00Z",
                    "lastActivityAt": "2026-03-19T10:02:00Z",
                }
            ],
            "tensors": [
                {
                    "tensorId": "local-tensor-1",
                    "runId": "local-run-1",
                    "name": "attn/grad_l2",
                    "dtype": "float32",
                    "shape": [1],
                    "dimensionLabels": [],
                    "createdAt": "2026-03-19T10:01:30Z",
                    "updatedAt": "2026-03-19T10:02:00Z",
                    "stepCount": 1,
                    "minStep": 7,
                    "maxStep": 7,
                    "steps": [7],
                    "stepMetadata": {
                        "7": {
                            "kind": "gradient_stats",
                            "group_id": "group-1",
                            "step": 7,
                            "created_at_ns": 123,
                        }
                    },
                },
                {
                    "tensorId": "local-tensor-2",
                    "runId": "local-run-1",
                    "name": "mlp/grad_l2",
                    "dtype": "float32",
                    "shape": [1],
                    "dimensionLabels": [],
                    "createdAt": "2026-03-19T10:01:31Z",
                    "updatedAt": "2026-03-19T10:02:01Z",
                    "stepCount": 1,
                    "minStep": 7,
                    "maxStep": 7,
                    "steps": [7],
                    "stepMetadata": {
                        "7": {
                            "kind": "gradient_stats",
                            "group_id": "group-1",
                            "step": 7,
                            "created_at_ns": 123,
                        }
                    },
                },
            ],
        }
        (data_dir / "store.json").write_text(json.dumps(store, indent=2))


if __name__ == "__main__":
    unittest.main()
