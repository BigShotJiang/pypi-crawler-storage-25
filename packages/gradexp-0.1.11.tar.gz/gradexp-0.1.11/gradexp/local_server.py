import base64
import gzip
import json
import math
import threading
import time
import traceback
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import format_datetime, parsedate_to_datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit
from uuid import uuid4

from .precision import canonicalize_precision, expected_byte_length


DEFAULT_USER_ID = "local-user"
MIME_TYPES = {
    ".bin": "application/octet-stream",
    ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8",
    ".ico": "image/x-icon",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".map": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".wasm": "application/wasm",
}


def _normalize_tensor_payload(payload):
    try:
        dtype = canonicalize_precision(payload.get("dtype"))
    except ValueError as error:
        return None, str(error)

    shape_values = payload.get("shape")
    if not isinstance(shape_values, list):
        return None, "name, dtype and shape are required"

    try:
        shape = [int(value) for value in shape_values]
    except (TypeError, ValueError):
        return None, "shape must contain integers"

    if any(value < 0 for value in shape):
        return None, "shape dimensions must be non-negative"

    return {
        "name": str(payload.get("name") or ""),
        "dtype": dtype,
        "shape": shape,
        "dimension_labels": payload.get("dimension_labels") or [],
    }, None


def _validate_tensor_value_size(tensor, value):
    expected_size = expected_byte_length(tensor["dtype"], tensor["shape"])
    actual_size = len(value)
    if actual_size != expected_size:
        return (
            f"Tensor '{tensor['name']}' expects {expected_size} bytes for dtype {tensor['dtype']} "
            f"and shape {tensor['shape']}, received {actual_size} bytes."
        )
    return None


def _utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _to_http_date(value):
    if not value:
        return None

    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None

    return format_datetime(parsed.astimezone(timezone.utc), usegmt=True)


def _parse_if_modified_since(value):
    if not value:
        return None

    try:
        return parsedate_to_datetime(value).timestamp()
    except (TypeError, ValueError, IndexError, OverflowError):
        return None


def _empty_stats():
    return {
        "min": 0,
        "max": 0,
        "avg": 0,
        "median": 0,
        "p10": 0,
        "p90": 0,
    }


def _percentile(sorted_values, proportion):
    if not sorted_values:
        return 0
    if len(sorted_values) == 1:
        return sorted_values[0]

    position = (len(sorted_values) - 1) * proportion
    lower_index = math.floor(position)
    upper_index = math.ceil(position)
    weight = position - lower_index

    if lower_index == upper_index:
        return sorted_values[lower_index]

    return (
        sorted_values[lower_index]
        + (sorted_values[upper_index] - sorted_values[lower_index]) * weight
    )


def _calculate_stats(values):
    sorted_values = sorted(values)
    total = sum(sorted_values)
    return {
        "min": sorted_values[0],
        "max": sorted_values[-1],
        "avg": total / len(sorted_values),
        "median": _percentile(sorted_values, 0.5),
        "p10": _percentile(sorted_values, 0.1),
        "p90": _percentile(sorted_values, 0.9),
    }


def _build_linear_histogram(values, bucket_count):
    min_value = min(values)
    max_value = max(values)

    if min_value == max_value:
        return [
            {"min": min_value, "max": max_value, "count": len(values) if index == 0 else 0}
            for index in range(bucket_count)
        ]

    bucket_width = (max_value - min_value) / bucket_count
    buckets = [
        {
            "min": min_value + bucket_width * index,
            "max": max_value if index == bucket_count - 1 else min_value + bucket_width * (index + 1),
            "count": 0,
        }
        for index in range(bucket_count)
    ]

    for value in values:
        bucket_index = min(bucket_count - 1, int((value - min_value) / bucket_width))
        buckets[bucket_index]["count"] += 1

    return buckets


def _build_log_histogram(values, bucket_count):
    positive_values = [value for value in values if value > 0]
    min_value = min(positive_values)
    max_value = max(positive_values)

    if min_value == max_value:
        return [
            {"min": min_value, "max": max_value, "count": len(positive_values) if index == 0 else 0}
            for index in range(bucket_count)
        ]

    log_min = math.log10(min_value)
    log_max = math.log10(max_value)
    bucket_width = (log_max - log_min) / bucket_count
    buckets = [
        {
            "min": math.pow(10, log_min + bucket_width * index),
            "max": max_value if index == bucket_count - 1 else math.pow(10, log_min + bucket_width * (index + 1)),
            "count": 0,
        }
        for index in range(bucket_count)
    ]

    for value in positive_values:
        bucket_index = min(bucket_count - 1, int((math.log10(value) - log_min) / bucket_width))
        buckets[bucket_index]["count"] += 1

    return buckets


def _calculate_user_marker(value, buckets, sorted_values):
    better_than = len([entry for entry in sorted_values if entry < value])
    percentile_value = 0 if not sorted_values else (better_than / len(sorted_values)) * 100

    bucket_index = next(
        (
            index
            for index, bucket in enumerate(buckets)
            if (index == len(buckets) - 1 and bucket["min"] <= value <= bucket["max"])
            or (index < len(buckets) - 1 and bucket["min"] <= value < bucket["max"])
        ),
        -1,
    )
    if bucket_index == -1:
        bucket_index = 0 if value < buckets[0]["min"] else len(buckets) - 1

    percentile_value = round(percentile_value, 1)
    return {
        "value": value,
        "percentile": percentile_value,
        "bucket": bucket_index,
        "message": f"Better than {percentile_value}% of local benchmark logs",
    }


class LocalStore:
    def __init__(self, data_dir, access_token):
        self.data_dir = Path(data_dir)
        self.state_path = self.data_dir / "store.json"
        self.blobs_root = self.data_dir / "blobs"
        self._lock = threading.RLock()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.blobs_root.mkdir(parents=True, exist_ok=True)
        self.state = self._load_state(access_token)
        self._persist()

    def _initial_state(self, access_token):
        created_at = _utc_now()
        return {
            "version": 1,
            "user": {
                "userId": DEFAULT_USER_ID,
                "apiKey": access_token,
                "createdAt": created_at,
            },
            "projects": [],
            "runs": [],
            "tensors": [],
            "legacyData": [],
            "demoLogs": [],
        }

    def _load_state(self, access_token):
        initial_state = self._initial_state(access_token)
        if not self.state_path.exists():
            return initial_state

        try:
            parsed = json.loads(self.state_path.read_text())
        except json.JSONDecodeError:
            return initial_state

        return {
            **initial_state,
            **parsed,
            "user": {
                **initial_state["user"],
                **(parsed.get("user") or {}),
                "apiKey": access_token,
            },
            "projects": parsed.get("projects") if isinstance(parsed.get("projects"), list) else [],
            "runs": parsed.get("runs") if isinstance(parsed.get("runs"), list) else [],
            "tensors": parsed.get("tensors") if isinstance(parsed.get("tensors"), list) else [],
            "legacyData": parsed.get("legacyData") if isinstance(parsed.get("legacyData"), list) else [],
            "demoLogs": parsed.get("demoLogs") if isinstance(parsed.get("demoLogs"), list) else [],
        }

    def _persist(self):
        with self._lock:
            self.state_path.write_text(json.dumps(self.state, indent=2))

    def _get_project(self, project_id):
        return next((project for project in self.state["projects"] if project["projectId"] == project_id), None)

    def _get_run(self, run_id):
        return next((run for run in self.state["runs"] if run["runId"] == run_id), None)

    def _get_tensor(self, tensor_id):
        return next((tensor for tensor in self.state["tensors"] if tensor["tensorId"] == tensor_id), None)

    def _get_project_by_name(self, project_name):
        return next((project for project in self.state["projects"] if project["name"] == project_name), None)

    def _tensor_step_path(self, tensor_id, step):
        return self.blobs_root / tensor_id / f"{step}.bin"

    def _update_tensor_stats(self, tensor, now):
        sorted_steps = sorted(tensor["steps"])
        tensor["steps"] = sorted_steps
        tensor["stepCount"] = len(sorted_steps)
        tensor["minStep"] = sorted_steps[0] if sorted_steps else None
        tensor["maxStep"] = sorted_steps[-1] if sorted_steps else None
        tensor["updatedAt"] = now

    def _write_tensor_step(self, tensor, step, value, now, step_metadata=None):
        step_dir = self.blobs_root / tensor["tensorId"]
        step_dir.mkdir(parents=True, exist_ok=True)
        was_already_present = step in tensor["steps"]
        self._tensor_step_path(tensor["tensorId"], step).write_bytes(value)
        if not was_already_present:
            tensor["steps"].append(step)
        step_metadata_map = tensor.setdefault("stepMetadata", {})
        step_key = str(int(step))
        if isinstance(step_metadata, dict) and step_metadata:
            step_metadata_map[step_key] = step_metadata
        else:
            step_metadata_map.pop(step_key, None)
            if not step_metadata_map:
                tensor.pop("stepMetadata", None)
        self._update_tensor_stats(tensor, now)

        run = self._get_run(tensor["runId"])
        if run:
            run["lastActivityAt"] = now

        return not was_already_present

    def _project_last_modified(self, project):
        related_runs = [run for run in self.state["runs"] if run["projectId"] == project["projectId"]]
        timestamps = [project["createdAt"], *[(run.get("lastActivityAt") or run["createdAt"]) for run in related_runs]]
        return sorted(timestamps)[-1] if timestamps else project["createdAt"]

    def _next_available_run_name(self, project_id, base_name):
        existing_names = {
            run["name"]
            for run in self.state["runs"]
            if run["projectId"] == project_id
        }
        if base_name not in existing_names:
            return base_name

        suffix = 2
        while f"{base_name}-{suffix}" in existing_names:
            suffix += 1
        return f"{base_name}-{suffix}"

    def get_user(self):
        return self.state["user"]

    def get_table_info(self):
        return {
            "message": "Table 'user_content' ready",
            "tableName": "user_content",
            "tableExists": True,
            "indexExists": True,
            "columns": [
                {"name": "id", "dataType": "integer", "isNullable": "NO"},
                {"name": "user_id", "dataType": "text", "isNullable": "NO"},
                {"name": "content", "dataType": "text", "isNullable": "YES"},
                {"name": "created_at", "dataType": "timestamp with time zone", "isNullable": "YES"},
            ],
            "userRowCount": len(self.state["legacyData"]),
            "userId": self.state["user"]["userId"],
        }

    def list_legacy_data(self):
        return sorted(self.state["legacyData"], key=lambda entry: entry["id"], reverse=True)

    def create_legacy_data(self, content):
        with self._lock:
            next_id = max((item["id"] for item in self.state["legacyData"]), default=0) + 1
            record = {
                "id": next_id,
                "userId": self.state["user"]["userId"],
                "content": content,
                "createdAt": _utc_now(),
            }
            self.state["legacyData"].append(record)
            self._persist()
            return record

    def list_projects(self):
        with self._lock:
            projects = [
                {
                    "project_id": project["projectId"],
                    "name": project["name"],
                    "created_at": project["createdAt"],
                    "last_run_updated_at": self._project_last_modified(project),
                }
                for project in sorted(self.state["projects"], key=lambda entry: entry["createdAt"], reverse=True)
            ]

            active_runs = [
                {
                    "run_id": run["runId"],
                    "project_id": run["projectId"],
                    "project_name": (self._get_project(run["projectId"]) or {}).get("name", "unknown"),
                    "name": run["name"],
                    "status": run["status"],
                    "created_at": run["createdAt"],
                    "updated_at": run["lastActivityAt"],
                }
                for run in sorted(
                    [run for run in self.state["runs"] if run["status"] == "active"],
                    key=lambda entry: entry["lastActivityAt"],
                    reverse=True,
                )
            ]

            timestamps = [project["last_run_updated_at"] or project["created_at"] for project in projects]
            return {
                "lastModified": sorted(timestamps)[-1] if timestamps else None,
                "payload": {"projects": projects, "active_runs": active_runs},
            }

    def list_runs(self, project_name):
        with self._lock:
            project = self._get_project_by_name(project_name)
            if not project:
                return {"status": 404, "payload": {"error": f"Project not found: {project_name}"}}

            runs = [
                {
                    "run_id": run["runId"],
                    "project_id": run["projectId"],
                    "name": run["name"],
                    "status": run["status"],
                    "created_at": run["createdAt"],
                    "last_activity_at": run["lastActivityAt"],
                }
                for run in sorted(
                    [run for run in self.state["runs"] if run["projectId"] == project["projectId"]],
                    key=lambda entry: entry["createdAt"],
                    reverse=True,
                )
            ]
            timestamps = [run["last_activity_at"] or run["created_at"] for run in runs]
            return {
                "status": 200,
                "lastModified": sorted(timestamps)[-1] if timestamps else None,
                "payload": runs,
            }

    def list_tensors(self, run_id):
        with self._lock:
            run = self._get_run(run_id)
            if not run:
                return {"status": 404, "payload": {"error": f"Run not found: {run_id}"}}

            tensors = [
                {
                    "tensor_id": tensor["tensorId"],
                    "run_id": tensor["runId"],
                    "name": tensor["name"],
                    "dtype": tensor["dtype"],
                    "shape": tensor["shape"],
                    "dimension_labels": tensor["dimensionLabels"],
                    "created_at": tensor["createdAt"],
                    "updated_at": tensor["updatedAt"],
                    "step_count": tensor["stepCount"],
                    "min_step": tensor["minStep"],
                    "max_step": tensor["maxStep"],
                }
                for tensor in sorted(
                    [tensor for tensor in self.state["tensors"] if tensor["runId"] == run_id],
                    key=lambda entry: entry["createdAt"],
                )
            ]
            return {
                "status": 200,
                "lastModified": run.get("lastActivityAt") or run["createdAt"],
                "payload": tensors,
            }

    def get_step_values(self, run_id, step):
        with self._lock:
            run = self._get_run(run_id)
            if not run:
                return {"status": 404, "payload": {"error": f"Run not found: {run_id}"}}

            values = [
                {
                    "name": tensor["name"],
                    "dtype": tensor["dtype"],
                    "shape": tensor["shape"],
                    "value": base64.b64encode(self._tensor_step_path(tensor["tensorId"], step).read_bytes()).decode("ascii"),
                }
                for tensor in self.state["tensors"]
                if tensor["runId"] == run_id and step in tensor["steps"]
            ]
            return {"status": 200, "payload": values}

    def get_tensor_values(self, tensor_id):
        with self._lock:
            tensor = self._get_tensor(tensor_id)
            if not tensor:
                return {"status": 404, "payload": {"error": f"Tensor not found: {tensor_id}"}}

            steps = [
                {
                    "step": step,
                    "value": base64.b64encode(self._tensor_step_path(tensor_id, step).read_bytes()).decode("ascii"),
                }
                for step in sorted(tensor["steps"])
            ]
            return {
                "status": 200,
                "lastModified": tensor.get("updatedAt") or tensor["createdAt"],
                "payload": steps,
            }

    def create_run(self, project_name, run_name):
        if not project_name or not run_name:
            return {"status": 400, "payload": {"error": "project_name and run_name are required"}}

        with self._lock:
            project = self._get_project_by_name(project_name)
            now = _utc_now()

            if not project:
                project = {
                    "projectId": str(uuid4()),
                    "userId": self.state["user"]["userId"],
                    "name": project_name,
                    "createdAt": now,
                }
                self.state["projects"].append(project)

            conflict = next(
                (
                    run
                    for run in self.state["runs"]
                    if run["projectId"] == project["projectId"] and run["name"] == run_name
                ),
                None,
            )
            if conflict:
                return {
                    "status": 409,
                    "payload": {
                        "error": "Run already exists in this project",
                        "suggested_name": self._next_available_run_name(project["projectId"], run_name),
                    },
                }

            run = {
                "runId": str(uuid4()),
                "projectId": project["projectId"],
                "name": run_name,
                "status": "active",
                "createdAt": now,
                "lastActivityAt": now,
            }
            self.state["runs"].append(run)
            self._persist()
            return {
                "status": 201,
                "payload": {"project_id": project["projectId"], "run_id": run["runId"]},
            }

    def update_run(self, run_id, update):
        with self._lock:
            run = self._get_run(run_id)
            if not run:
                return {"status": 404, "payload": {"error": f"Run not found: {run_id}"}}

            changed = False
            if update.get("name") and update["name"] != run["name"]:
                run["name"] = update["name"]
                changed = True
            if update.get("status") and update["status"] != run["status"]:
                run["status"] = update["status"]
                changed = True
            if changed:
                run["lastActivityAt"] = _utc_now()
            self._persist()
            return {"status": 200, "payload": {"status": "success"}}

    def create_tensor(self, run_id, payload):
        with self._lock:
            run = self._get_run(run_id)
            if not run:
                return {"status": 404, "payload": {"error": f"Run not found: {run_id}"}}
            normalized_payload, error = _normalize_tensor_payload(payload)
            if error:
                return {"status": 400, "payload": {"error": error}}
            if not normalized_payload["name"]:
                return {"status": 400, "payload": {"error": "name, dtype and shape are required"}}

            now = _utc_now()
            tensor = {
                "tensorId": str(uuid4()),
                "runId": run_id,
                "name": normalized_payload["name"],
                "dtype": normalized_payload["dtype"],
                "shape": normalized_payload["shape"],
                "dimensionLabels": normalized_payload["dimension_labels"],
                "createdAt": now,
                "updatedAt": now,
                "stepCount": 0,
                "minStep": None,
                "maxStep": None,
                "steps": [],
                "stepMetadata": {},
            }
            self.state["tensors"].append(tensor)
            self._persist()
            return {"status": 201, "payload": {"tensor_id": tensor["tensorId"]}}

    def log_tensor_step(self, tensor_id, step, value, step_metadata=None):
        with self._lock:
            tensor = self._get_tensor(tensor_id)
            if not tensor:
                return {"status": 404, "payload": {"error": f"Tensor not found: {tensor_id}"}}
            error = _validate_tensor_value_size(tensor, value)
            if error:
                return {"status": 400, "payload": {"error": error}}

            inserted = self._write_tensor_step(tensor, step, value, _utc_now(), step_metadata=step_metadata)
            self._persist()
            return {"status": 200, "payload": {"status": "success", "inserted": inserted}}

    def batch_log_tensor_steps(self, tensor_id, steps):
        with self._lock:
            tensor = self._get_tensor(tensor_id)
            if not tensor:
                return {"status": 404, "payload": {"error": f"Tensor not found: {tensor_id}"}}
            for item in steps:
                error = _validate_tensor_value_size(tensor, item["value"])
                if error:
                    return {"status": 400, "payload": {"error": error}}

            now = _utc_now()
            inserted = 0
            for item in steps:
                if self._write_tensor_step(
                    tensor,
                    item["step"],
                    item["value"],
                    now,
                    step_metadata=item.get("local_step_metadata"),
                ):
                    inserted += 1
            self._persist()
            return {"status": 200, "payload": {"inserted": inserted}}

    def log_demo(self, payload):
        with self._lock:
            self.state["demoLogs"].append({
                "id": str(uuid4()),
                "createdAt": _utc_now(),
                "flops": float(payload.get("flops") or 0),
                "bandwidth": float(payload.get("bandwidth") or 0),
                "fps": float(payload.get("fps") or 0),
                "dimension": float(payload.get("dimension") or 0),
                "render_views": float(payload.get("render_views") or 0),
                "timestamp": str(payload.get("timestamp") or ""),
                "hardware": payload.get("hardware") if isinstance(payload.get("hardware"), dict) else {},
            })
            self._persist()
            return {"status": 201, "payload": {"status": "success"}}

    def get_histogram(self, field, bucket_count, scale, user_value=None):
        field_to_getter = {
            "flops": lambda entry: entry["flops"],
            "bandwidth": lambda entry: entry["bandwidth"],
            "fps": lambda entry: entry["fps"],
            "dimension": lambda entry: entry["dimension"],
        }
        value_getter = field_to_getter.get(field)
        if not value_getter:
            return {"status": 400, "payload": {"error": "Invalid field. Use: flops, bandwidth, fps, dimension"}}

        values = [
            value_getter(entry)
            for entry in self.state["demoLogs"]
            if math.isfinite(value_getter(entry)) and value_getter(entry) > 0
        ]
        if not values:
            return {
                "status": 200,
                "payload": {
                    "buckets": [],
                    "field": field,
                    "bucket_count": bucket_count,
                    "total": 0,
                    "stats": _empty_stats(),
                    "scale": scale,
                },
            }

        stats = _calculate_stats(values)
        buckets = _build_log_histogram(values, bucket_count) if scale == "log" else _build_linear_histogram(values, bucket_count)
        payload = {
            "buckets": buckets,
            "field": field,
            "bucket_count": bucket_count,
            "total": len(values),
            "stats": stats,
            "scale": scale,
        }
        if user_value and user_value > 0:
            payload["user_marker"] = _calculate_user_marker(user_value, buckets, sorted(values))

        return {"status": 200, "payload": payload}


@dataclass
class LocalServerContext:
    app_dir: Path
    data_dir: Path
    app_port: int
    api_port: int
    instance_id: str
    access_token: str
    store: LocalStore
    stop_event: threading.Event

    @property
    def api_base_url(self):
        return f"http://127.0.0.1:{self.api_port}"

    def runtime_config(self):
        return {
            "apiBaseUrl": self.api_base_url,
            "localAuthToken": self.access_token,
            "localMode": True,
        }


class LocalHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address, handler_class, context):
        super().__init__(server_address, handler_class)
        self.context = context


class LocalBaseHandler(BaseHTTPRequestHandler):
    server_version = "gradexp-local"

    @property
    def context(self):
        return self.server.context

    def log_message(self, format, *args):
        super().log_message(format, *args)


class LocalAppHandler(LocalBaseHandler):
    def do_GET(self):
        self._serve(send_body=True)

    def do_HEAD(self):
        self._serve(send_body=False)

    def _serve(self, send_body):
        try:
            path = unquote(urlsplit(self.path).path or "/")
            requested_path = "/index.html" if path == "/" else path
            app_root = self.context.app_dir.resolve()
            resolved_path = (app_root / requested_path.lstrip("/")).resolve()

            try:
                resolved_path.relative_to(app_root)
                path_is_safe = True
            except ValueError:
                path_is_safe = False

            if path_is_safe and resolved_path.is_file():
                if resolved_path.name == "index.html":
                    self._serve_index(send_body)
                else:
                    self._serve_file(resolved_path, send_body)
                return

            if "." in Path(requested_path).name:
                self.send_response(404)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                if send_body:
                    self.wfile.write(f"Asset not found: {requested_path}".encode("utf-8"))
                return

            self._serve_index(send_body)
        except Exception:
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            if send_body:
                self.wfile.write(b"Failed to serve application")

    def _serve_index(self, send_body):
        index_path = self.context.app_dir / "index.html"
        html = index_path.read_text(encoding="utf-8")
        runtime_script = (
            "<script>"
            f"window.__GRADEXP_RUNTIME__ = {json.dumps(self.context.runtime_config(), separators=(',', ':'))};"
            "</script>"
        )
        html = html.replace("</head>", f"{runtime_script}</head>", 1)
        content = html.encode("utf-8")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        if send_body:
            self.wfile.write(content)

    def _serve_file(self, file_path, send_body):
        content = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", MIME_TYPES.get(file_path.suffix, "application/octet-stream"))
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        if send_body:
            self.wfile.write(content)


class LocalAPIHandler(LocalBaseHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self._set_api_headers()
        self.end_headers()

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PATCH(self):
        self._handle("PATCH")

    def _handle(self, method):
        try:
            self._dispatch(method)
        except Exception:
            traceback.print_exc()
            self._send_error(500, "Internal server error")

    def _dispatch(self, method):
        split_result = urlsplit(self.path)
        pathname = unquote(split_result.path)
        segments = [segment for segment in pathname.split("/") if segment]
        query = parse_qs(split_result.query)

        if pathname == "/version" and method == "GET":
            self._send_json(
                200,
                {
                    "version": "local-dev",
                    "mode": "local",
                    "instance_id": self.context.instance_id,
                    "data_dir": str(self.context.data_dir),
                },
            )
            return

        if pathname == "/local/shutdown" and method == "POST":
            if not self._require_access_token():
                return
            self._send_json(202, {"status": "stopping"})
            self.context.stop_event.set()
            return

        if segments and segments[0] == "demo":
            self._handle_demo_routes(segments, query, method)
            return

        if segments and segments[0] == "protected":
            if not self._require_access_token():
                return
            self._handle_protected_routes(segments, method)
            return

        if len(segments) >= 2 and segments[0] == "api" and segments[1] == "v1":
            if not self._require_access_token():
                return
            self._handle_api_routes(segments, query, method)
            return

        self._send_error(404, f"Route not found: {pathname}")

    def _handle_demo_routes(self, segments, query, method):
        if len(segments) == 1 and method == "POST":
            payload = self._read_json_body()
            if payload is None:
                return
            result = self.context.store.log_demo(payload)
            self._send_json(result["status"], result["payload"])
            return

        if len(segments) == 2 and segments[1] == "histogram" and method == "GET":
            field = query.get("field", ["flops"])[0]
            try:
                bucket_count = int(query.get("buckets", ["20"])[0])
            except ValueError:
                bucket_count = 20
            bucket_count = max(5, min(100, bucket_count))
            scale = "log" if query.get("scale", ["linear"])[0] == "log" else "linear"
            value = query.get("value", [None])[0]
            user_value = float(value) if value not in (None, "") else None
            result = self.context.store.get_histogram(field, bucket_count, scale, user_value)
            self._send_json(result["status"], result["payload"])
            return

        self._send_error(404, f"Route not found: /{'/'.join(segments)}")

    def _handle_protected_routes(self, segments, method):
        if len(segments) == 1 and method == "GET":
            self._send_json(200, {"message": "Authenticated", "userId": DEFAULT_USER_ID})
            return

        if segments[1:] == ["get-or-create-table"] and method == "GET":
            self._send_json(200, self.context.store.get_table_info())
            return

        if segments[1:] == ["data"] and method == "GET":
            self._send_json(200, self.context.store.list_legacy_data())
            return

        if segments[1:] == ["data"] and method == "POST":
            payload = self._read_json_body()
            if payload is None:
                return
            content = str(payload.get("content") or "").strip()
            if not content:
                self._send_error(400, "Content cannot be empty.")
                return
            record = self.context.store.create_legacy_data(content)
            self._send_json(201, {"id": record["id"], "message": "Data saved successfully"})
            return

        if len(segments) == 2 and segments[1] == "api-key" and method in {"GET", "POST"}:
            status = 200 if method == "GET" else 201
            self._send_json(status, {"apiKey": self.context.store.get_user()["apiKey"]})
            return

        if len(segments) == 2 and segments[1] == "projects" and method == "GET":
            result = self.context.store.list_projects()
            if self._send_not_modified_if_needed(result["lastModified"]):
                return
            self._send_json(200, result["payload"], result["lastModified"])
            return

        if len(segments) == 4 and segments[1] == "projects" and segments[3] == "runs" and method == "GET":
            result = self.context.store.list_runs(segments[2])
            if result["status"] == 200 and self._send_not_modified_if_needed(result.get("lastModified")):
                return
            self._send_json(result["status"], result["payload"], result.get("lastModified"))
            return

        if len(segments) == 4 and segments[1] == "runs" and segments[3] == "tensors" and method == "GET":
            result = self.context.store.list_tensors(segments[2])
            if result["status"] == 200 and self._send_not_modified_if_needed(result.get("lastModified")):
                return
            self._send_json(result["status"], result["payload"], result.get("lastModified"))
            return

        if len(segments) == 5 and segments[1] == "runs" and segments[3] == "steps" and method == "GET":
            try:
                step = int(segments[4])
            except ValueError:
                self._send_error(400, "Invalid step")
                return
            result = self.context.store.get_step_values(segments[2], step)
            self._send_json(result["status"], result["payload"])
            return

        if len(segments) == 4 and segments[1] == "tensors" and segments[3] == "values" and method == "GET":
            result = self.context.store.get_tensor_values(segments[2])
            if result["status"] == 200 and self._send_not_modified_if_needed(result.get("lastModified")):
                return
            self._send_json(result["status"], result["payload"], result.get("lastModified"))
            return

        self._send_error(404, f"Route not found: /{'/'.join(segments)}")

    def _handle_api_routes(self, segments, query, method):
        if len(segments) == 3 and segments[2] == "me" and method == "GET":
            self._send_json(200, {"id": DEFAULT_USER_ID, "username": f"user_{DEFAULT_USER_ID}"})
            return

        if len(segments) == 3 and segments[2] == "runs" and method == "POST":
            payload = self._read_json_body()
            if payload is None:
                return
            result = self.context.store.create_run(
                str(payload.get("project_name") or ""),
                str(payload.get("run_name") or ""),
            )
            self._send_json(result["status"], result["payload"])
            return

        if len(segments) == 4 and segments[2] == "runs" and method == "PATCH":
            payload = self._read_json_body()
            if payload is None:
                return
            result = self.context.store.update_run(segments[3], payload)
            self._send_json(result["status"], result["payload"])
            return

        if len(segments) == 5 and segments[2] == "runs" and segments[4] == "tensors" and method == "POST":
            payload = self._read_json_body()
            if payload is None:
                return
            result = self.context.store.create_tensor(segments[3], {
                "name": str(payload.get("name") or ""),
                "dtype": str(payload.get("dtype") or ""),
                "shape": payload.get("shape") if isinstance(payload.get("shape"), list) else [],
                "dimension_labels": payload.get("dimension_labels") if isinstance(payload.get("dimension_labels"), list) else [],
            })
            self._send_json(result["status"], result["payload"])
            return

        if len(segments) == 5 and segments[2] == "tensors" and segments[4] == "step" and method == "POST":
            try:
                step = int(query.get("step", [""])[0])
            except ValueError:
                self._send_error(400, "Missing tensor_id or step")
                return
            raw_step_metadata = self.headers.get("X-Gradexp-Step-Metadata")
            step_metadata = None
            if raw_step_metadata:
                try:
                    parsed_step_metadata = json.loads(raw_step_metadata)
                except ValueError:
                    parsed_step_metadata = None
                if isinstance(parsed_step_metadata, dict):
                    step_metadata = parsed_step_metadata
            result = self.context.store.log_tensor_step(
                segments[3],
                step,
                self._read_body(),
                step_metadata=step_metadata,
            )
            self._send_json(result["status"], result["payload"])
            return

        if len(segments) == 5 and segments[2] == "tensors" and segments[4] == "steps" and method == "POST":
            payload = self._read_json_body()
            if payload is None:
                return
            steps = payload.get("steps") if isinstance(payload.get("steps"), list) else []
            if not steps:
                self._send_error(400, "No steps provided")
                return
            decoded_steps = [
                {
                    "step": int(item.get("step")),
                    "value": base64.b64decode(str(item.get("value") or "").encode("ascii")),
                    "local_step_metadata": item.get("local_step_metadata")
                    if isinstance(item.get("local_step_metadata"), dict)
                    else None,
                }
                for item in steps
            ]
            result = self.context.store.batch_log_tensor_steps(segments[3], decoded_steps)
            self._send_json(result["status"], result["payload"])
            return

        if len(segments) == 5 and segments[2] == "data-instances" and method == "POST":
            result = self.context.store.update_run(segments[3], {"status": segments[4]})
            self._send_json(result["status"], result["payload"])
            return

        self._send_error(404, f"Route not found: /{'/'.join(segments)}")

    def _set_api_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, If-Modified-Since")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, OPTIONS")
        self.send_header("Access-Control-Expose-Headers", "Content-Type, Last-Modified")
        self.send_header("Content-Type", "application/json; charset=utf-8")

    def _send_json(self, status_code, payload, last_modified=None):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status_code)
        self._set_api_headers()
        http_date = _to_http_date(last_modified)
        if http_date:
            self.send_header("Last-Modified", http_date)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_error(self, status_code, message):
        self._send_json(status_code, {"error": message})

    def _send_not_modified_if_needed(self, last_modified):
        if not last_modified:
            return False

        client_timestamp = _parse_if_modified_since(self.headers.get("If-Modified-Since"))
        if client_timestamp is None:
            return False

        try:
            server_timestamp = datetime.fromisoformat(last_modified.replace("Z", "+00:00")).timestamp()
        except ValueError:
            return False

        if server_timestamp > client_timestamp + 0.999:
            return False

        self.send_response(304)
        self._set_api_headers()
        http_date = _to_http_date(last_modified)
        if http_date:
            self.send_header("Last-Modified", http_date)
        self.end_headers()
        return True

    def _bearer_token(self):
        authorization = self.headers.get("Authorization")
        if not authorization:
            return None

        scheme, _, token = authorization.partition(" ")
        if scheme != "Bearer" or not token:
            return None
        return token.strip()

    def _require_access_token(self):
        token = self._bearer_token()
        if not token:
            self._send_error(401, "Missing Authorization header")
            return False

        if token != self.context.access_token:
            self._send_error(401, "Invalid API Key")
            return False
        return True

    def _read_body(self):
        content_length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(content_length) if content_length else b""
        if self.headers.get("Content-Encoding") == "gzip":
            body = gzip.decompress(body)
        return body

    def _read_json_body(self):
        try:
            return json.loads(self._read_body().decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._send_error(400, "Invalid request body")
            return None


def serve_local_app(app_dir, data_dir, app_port, api_port, instance_id, access_token, stop_event=None):
    stop_event = stop_event or threading.Event()
    context = LocalServerContext(
        app_dir=Path(app_dir),
        data_dir=Path(data_dir),
        app_port=app_port,
        api_port=api_port,
        instance_id=instance_id,
        access_token=access_token,
        store=LocalStore(data_dir, access_token),
        stop_event=stop_event,
    )

    api_server = LocalHTTPServer(("127.0.0.1", api_port), LocalAPIHandler, context)
    app_server = LocalHTTPServer(("127.0.0.1", app_port), LocalAppHandler, context)

    threads = [
        threading.Thread(target=api_server.serve_forever, daemon=True),
        threading.Thread(target=app_server.serve_forever, daemon=True),
    ]
    for thread in threads:
        thread.start()

    try:
        while not stop_event.wait(0.5):
            continue
    finally:
        for server in (api_server, app_server):
            server.shutdown()
            server.server_close()
        for thread in threads:
            thread.join(timeout=1)
