"""Mod Spotlight: Willow Hub"""
__version__ = "1.0.0"
