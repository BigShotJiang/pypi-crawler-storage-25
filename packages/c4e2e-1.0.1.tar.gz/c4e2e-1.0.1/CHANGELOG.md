# Changelog

## [1.0.0]
- Initial stable release
- End-to-end encryption pipeline
- Payload signing/verification

## [1.0.1]
Official Release on PyPi will be v1.0.1

- Information Disclosure Vulnerability fixed
- wiki added
