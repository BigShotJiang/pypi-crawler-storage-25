"""
c4e2e.node - Transmitter, Receiver, and Hybrid node classes

Transmitter: encrypts and signs outgoing payloads
Receiver:    verifies and decrypts incoming payloads, writes output files
Hybrid:      does both
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .config import C4Config
from .crypto import (
    encrypt_for_recipient,
    decrypt_from_sender,
    export_ed25519_public,
    pubkey_to_b64,
    b64_to_pubkey,
)
from .payload import (
    build_metadata,
    build_job,
    parse_job,
    pack_frame,
    unpack_frame,
    build_extra,
)

logger = logging.getLogger("c4e2e")


class C4NodeError(Exception):
    pass


class ModeError(C4NodeError):
    pass


class SignatureError(C4NodeError):
    pass


class UntrustedSenderError(C4NodeError):
    pass


# ─── Transmitter ───────────────────────────────────────────────────────────────

class Transmitter:
    """
    Encrypts and signs outgoing payloads.
    Requires a private key. Needs recipient's public key per send.
    """

    def __init__(self, config: C4Config):
        if config.mode not in ("transmitter", "hybrid"):
            raise ModeError(f"Transmitter requires mode 'transmitter' or 'hybrid', got '{config.mode}'")
        if config.private_key is None:
            raise C4NodeError("Transmitter requires a private key")
        self.config = config
        self._priv = config.private_key
        self._pub = config.public_key

    @property
    def public_key_b64(self) -> str:
        return pubkey_to_b64(self._pub)

    def encrypt(
        self,
        name: str,
        job: Dict[str, Any],
        recipient_pubkey: Union[str, Ed25519PublicKey],
        job_id: str = None,
        tags: List[str] = None,
        include_host: bool = True,
        raw_extra: dict = None,
    ) -> bytes:
        """
        Encrypt a job payload addressed to a recipient.

        Args:
            name:             Filename the receiver will write the decrypted output to
            job:              Job data dict (will be JSON-serialized inside ciphertext)
            recipient_pubkey: Recipient's Ed25519 public key (base64 string or key object)
            job_id:           Optional job ID to embed in extra
            tags:             Optional list of tags to embed in extra
            include_host:     Whether to include host info in extra (default True)
            raw_extra:        Override the entire extra dict (skips auto host/tag collection)

        Returns:
            Raw bytes of the wire frame (ready to transmit)
        """
        if isinstance(recipient_pubkey, str):
            recipient_pubkey = b64_to_pubkey(recipient_pubkey)

        # Build extra
        if raw_extra is not None:
            extra = raw_extra
        else:
            extra = build_extra(
                job_id=job_id,
                tags=tags,
                include_host=include_host,
            )

        metadata = build_metadata(
            name=name,
            pubkey_b64=self.public_key_b64,
            extra=extra,
        )

        job_bytes = build_job(job)
        encrypted_body = encrypt_for_recipient(job_bytes, recipient_pubkey, self._priv)
        frame = pack_frame(metadata, encrypted_body)

        logger.debug(f"[TX] Encrypted payload '{name}' ({len(frame)} bytes)")
        return frame


# ─── Receiver ──────────────────────────────────────────────────────────────────

class Receiver:
    """
    Listens for and decrypts incoming payloads.
    Only accepts payloads signed with trusted pubkeys.
    Writes decrypted content to files named by metadata.name.
    """

    def __init__(self, config: C4Config):
        if config.mode not in ("receiver", "hybrid"):
            raise ModeError(f"Receiver requires mode 'receiver' or 'hybrid', got '{config.mode}'")
        if config.private_key is None:
            raise C4NodeError("Receiver requires a private key")
        self.config = config
        self._priv = config.private_key
        self._trusted: Dict[str, Ed25519PublicKey] = {}

        for key in config.trusted_keys:
            b64 = pubkey_to_b64(key)
            self._trusted[b64] = key
            logger.debug(f"[RX] Trusting key: {b64[:16]}...")

    def trust(self, pubkey: Union[str, Ed25519PublicKey]):
        """Add a key to the trusted set at runtime."""
        if isinstance(pubkey, str):
            b64 = pubkey
            key = b64_to_pubkey(pubkey)
        else:
            b64 = pubkey_to_b64(pubkey)
            key = pubkey
        self._trusted[b64] = key
        logger.info(f"[RX] Trusted key added: {b64[:16]}...")

    def untrust(self, pubkey: Union[str, Ed25519PublicKey]):
        """Remove a key from the trusted set."""
        if isinstance(pubkey, Ed25519PublicKey):
            pubkey = pubkey_to_b64(pubkey)
        self._trusted.pop(pubkey, None)

    def is_trusted(self, pubkey_b64: str) -> bool:
        return pubkey_b64 in self._trusted

    @property
    def trusted_keys(self) -> List[str]:
        return list(self._trusted.keys())

    def decrypt(
        self,
        frame: bytes,
        write_output: bool = True,
    ) -> Dict[str, Any]:
        """
        Decrypt an incoming frame.

        Args:
            frame:        Raw wire frame bytes
            write_output: If True, write decrypted job to file in output_dir

        Returns:
            Dict with keys:
              "name"     - the output filename (from metadata)
              "job"      - the decrypted job dict
              "metadata" - the full metadata dict
              "output_path" - Path where file was written (or None)

        Raises:
            UntrustedSenderError: sender pubkey not in trusted set
            SignatureError:       signature verification failed
            C4NodeError:          other decryption errors
        """
        try:
            metadata, encrypted_body = unpack_frame(frame)
        except Exception as e:
            raise C4NodeError(f"Frame parse failed: {e}")

        sender_b64 = metadata["pubkey"]

        if self._trusted and sender_b64 not in self._trusted:
            raise UntrustedSenderError(
                f"Sender pubkey not trusted: {sender_b64[:16]}... "
                f"({len(self._trusted)} trusted keys registered)"
            )

        sender_pub = self._trusted.get(sender_b64) or b64_to_pubkey(sender_b64)

        try:
            plaintext = decrypt_from_sender(encrypted_body, self._priv, sender_pub)
        except ValueError as e:
            raise SignatureError(str(e))
        except Exception as e:
            raise C4NodeError(f"Decryption failed: {e}")

        job = parse_job(plaintext)
        name = metadata["name"]
        output_path = None

        if write_output:
            output_path = self._write_output(name, job, metadata)

        logger.info(f"[RX] Decrypted payload '{name}' from {sender_b64[:16]}...")

        return {
            "name": name,
            "job": job,
            "metadata": metadata,
            "output_path": output_path,
        }

    def _write_output(self, name: str, job: dict, metadata: dict) -> Path:
        """Write decrypted job data to a file. Filename comes from metadata.name."""
        safe_name = Path(name).name  # strip directory traversal
        out_path = self.config.output_dir / safe_name

        payload = {
            "metadata": metadata,
            "job": job,
        }

        out_path.write_text(json.dumps(payload, indent=2))
        logger.info(f"[RX] Wrote output → {out_path}")
        return out_path


# ─── Hybrid ────────────────────────────────────────────────────────────────────

class Hybrid(Transmitter, Receiver):
    """
    Combined transmitter + receiver node.
    Can both encrypt outgoing and decrypt incoming payloads.
    """

    def __init__(self, config: C4Config):
        if config.mode != "hybrid":
            raise ModeError(f"Hybrid requires mode 'hybrid', got '{config.mode}'")
        if config.private_key is None:
            raise C4NodeError("Hybrid requires a private key")

        # Initialize both parent classes
        self.config = config
        self._priv = config.private_key
        self._pub = config.public_key
        self._trusted: Dict[str, Ed25519PublicKey] = {}

        for key in config.trusted_keys:
            b64 = pubkey_to_b64(key)
            self._trusted[b64] = key

    def __repr__(self):
        return (
            f"<Hybrid pubkey={self.public_key_b64[:16]}... "
            f"trusted={len(self._trusted)} "
            f"output_dir={self.config.output_dir}>"
        )


# ─── Factory ───────────────────────────────────────────────────────────────────

def create_node(config: C4Config) -> Union[Transmitter, Receiver, Hybrid]:
    """Factory: create the right node type from config."""
    if config.mode == "transmitter":
        return Transmitter(config)
    elif config.mode == "receiver":
        return Receiver(config)
    elif config.mode == "hybrid":
        return Hybrid(config)
    raise ValueError(f"Unknown mode: {config.mode}")
