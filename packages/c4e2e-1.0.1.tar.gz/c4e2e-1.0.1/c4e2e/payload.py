"""
c4e2e.payload - Wire format construction and parsing


"""

import base64
import json
import struct
import socket
import platform
import datetime
from typing import Any, Dict, Optional


METADATA_KEYS = {"name", "pubkey", "extra"}


# ─── Metadata ─────────────────────────────────────────────────────────────────

def build_metadata(name: str, pubkey_b64: str, extra: Optional[Dict] = None) -> dict:
    """
    Build a metadata dict. Only three keys allowed.
    `extra` can hold host info, job tags, timestamps, etc.
    """
    if extra is not None and not isinstance(extra, dict):
        raise TypeError("metadata.extra must be a dict")
    return {
        "name": name,
        "pubkey": pubkey_b64,
        "extra": extra or {},
    }


def validate_metadata(meta: dict):
    keys = set(meta.keys())
    if keys != METADATA_KEYS:
        unexpected = keys - METADATA_KEYS
        missing = METADATA_KEYS - keys
        parts = []
        if unexpected:
            parts.append(f"unexpected keys: {unexpected}")
        if missing:
            parts.append(f"missing keys: {missing}")
        raise ValueError(f"Metadata schema violation — {'; '.join(parts)}")


def encode_metadata(meta: dict) -> bytes:
    validate_metadata(meta)
    return base64.b64encode(json.dumps(meta, separators=(",", ":")).encode())


def decode_metadata(raw: bytes) -> dict:
    meta = json.loads(base64.b64decode(raw).decode())
    validate_metadata(meta)
    return meta


# ─── Job Body ─────────────────────────────────────────────────────────────────

def build_job(job_data: Dict[str, Any]) -> bytes:
    """Serialize job data to bytes for encryption."""
    return json.dumps(job_data, separators=(",", ":")).encode()


def parse_job(raw: bytes) -> Dict[str, Any]:
    return json.loads(raw.decode())


# ─── Wire Frame Assembly ───────────────────────────────────────────────────────

def pack_frame(metadata: dict, encrypted_body: dict) -> bytes:
    """
    Pack metadata + encrypted body into a single wire frame.

    Frame layout:
      [4 bytes: metadata length big-endian uint32]
      [N bytes: base64-encoded metadata JSON]
      [remaining: JSON of encrypted body]
    """
    meta_bytes = encode_metadata(metadata)
    body_bytes = json.dumps(encrypted_body, separators=(",", ":")).encode()

    frame = struct.pack(">I", len(meta_bytes)) + meta_bytes + body_bytes
    return frame


def unpack_frame(frame: bytes) -> tuple:
    """
    Unpack a wire frame into (metadata dict, encrypted_body dict).
    Returns (metadata, encrypted_body).
    """
    if len(frame) < 4:
        raise ValueError("Frame too short")

    meta_len = struct.unpack(">I", frame[:4])[0]
    if len(frame) < 4 + meta_len:
        raise ValueError("Frame truncated — metadata region incomplete")

    meta_raw = frame[4:4 + meta_len]
    body_raw = frame[4 + meta_len:]

    metadata = decode_metadata(meta_raw)
    encrypted_body = json.loads(body_raw.decode())

    return metadata, encrypted_body


# ─── Host Info Helper ─────────────────────────────────────────────────────────

def collect_host_info() -> dict:
    """Collect basic host metadata to embed in extra.host_info."""
    try:
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
    except Exception:
        hostname = "unknown"
        ip = "unknown"

    return {
        "hostname": hostname,
        "ip": ip,
        "platform": platform.system(),
        "arch": platform.machine(),
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
    }


def build_extra(job_id: str = None, tags: list = None, include_host: bool = False) -> dict:
    """Build the `extra` metadata field."""
    extra = {}
    if include_host:
        extra["host_info"] = collect_host_info()
    if job_id:
        extra["job_id"] = job_id
    if tags:
        extra["tags"] = tags
    return extra
# This is pulling host info and can cause inadvertent system disclosure. this was only meant as a field that a user could manually add info and as a placeholder for future improvements
# setting bool to false by default wil revise in a later release
