# Synapto + Cursor

## Setup

1. Install Synapto and initialize:

```bash
pip install synapto
createdb synapto && psql -d synapto -c "CREATE EXTENSION vector;"
synapto init
```

2. Add to `.cursor/mcp.json` in your project root:

**Recommended (auto-updates on every restart):**

```json
{
  "mcpServers": {
    "synapto": {
      "command": "uvx",
      "args": ["--refresh", "synapto", "serve"],
      "env": {
        "SYNAPTO_DEFAULT_TENANT": "my-project"
      }
    }
  }
}
```

> **Why `--refresh`?** Without it, `uvx` reuses the cached environment across restarts, so a new Synapto release on PyPI will not be picked up until the cache expires or you run `uv cache clean synapto` manually. `--refresh` tells `uv` to re-resolve the package on every launch, adding 1–3 seconds to startup in exchange for "always on the latest version". Drop the flag (or pin a version like `"synapto==0.2.0"`) once you want to freeze a known-good build.

3. Restart Cursor. Synapto tools will be available to the AI agent.

## Usage

Cursor's AI will automatically use `remember` and `recall` tools when appropriate. You can also prompt:

- "Store this pattern in memory for future reference"
- "Search memory for how we handle authentication"
- "What entities are related to the user service?"

## Cross-Agent Handoffs

Use handoffs in natural language first:

```text
Continue from Synapto handoff b0e1506e-d1b7-4bee-9223-4d0f8d18a1b2.
Don't edit yet — read it, verify metadata, fetch related context, then propose.
```

Cursor should call `get_memory`, verify `metadata.kind = "agent_handoff"`, fetch
any `context_ids`, and continue from the packet. If the user asks "any handoffs
for you?" without an ID, Cursor can use `handoff_inbox_template` or `recall`.

If your Cursor MCP client exposes Synapto prompts, use `agent_handoff` to create
a handoff and `handoff_inbox` to receive one. If prompts are not surfaced but
tools are, use `agent_handoff_template` and `handoff_inbox_template` to render
the same workflow instructions. If neither is surfaced, ask Cursor to follow the
workflow manually:

```text
recall(
  "agent_handoff agent handoff for cursor status ready_for_implementation",
  depth_layer="working",
  preview_chars=200
)
get_memory("<handoff-id>")
```

`recall` returns ranked candidates instead of filtering by metadata fields, so
verify `metadata.kind`, `metadata.to_agent`, and `metadata.status` after
`get_memory`.

Handoffs are normal project memories with structured metadata, so they remain
portable across Codex, Claude Code, Cursor, and other MCP clients. See
[Cross-agent handoffs](handoffs.md) for the full schema.
