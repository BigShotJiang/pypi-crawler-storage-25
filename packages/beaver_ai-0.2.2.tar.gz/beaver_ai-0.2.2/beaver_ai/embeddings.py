from typing import List, Union, Optional
from .types import EmbeddingResponse, EmbeddingData, Usage


class Embeddings:
    def __init__(self, client):
        self._client = client

    def create(self, model: str, input: Union[str, List[str]],
               dimensions: Optional[int] = None) -> EmbeddingResponse:
        """
        Create embeddings for a given input.
        """
        payload = {"model": model, "input": input}
        if dimensions:
            payload["dimensions"] = dimensions
            
        raw = self._client._post("/v1/embeddings", payload)
        
        return EmbeddingResponse(
            data=[EmbeddingData(index=d["index"], embedding=d["embedding"])
                  for d in raw["data"]],
            model=raw["model"],
            usage=Usage(**raw.get("usage", {})) if "usage" in raw else None,
        )
