class AudioSpeech:
    def __init__(self, client):
        self._client = client

    def create(self, model: str, input: str, voice: str,
               response_format: str = "mp3", speed: float = 1.0) -> bytes:
        """
        Convert text to speech and return raw bytes.
        """
        payload = {
            "model": model, 
            "input": input, 
            "voice": voice,
            "response_format": response_format, 
            "speed": speed,
        }
        return self._client._post_raw("/v1/audio/speech", payload)


class Audio:
    def __init__(self, client):
        self.speech = AudioSpeech(client)
