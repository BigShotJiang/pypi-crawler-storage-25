from .client import Beaver
from .errors import BeaverError
from .types import (
    Message,
    ChatCompletionResponse,
    Choice,
    Usage,
    ChatCompletionChunk,
    StreamChoice,
    StreamDelta,
    ImageData,
    ImageResponse,
    EmbeddingData,
    EmbeddingResponse,
)

__version__ = "0.2.0"

__all__ = [
    "Beaver",
    "BeaverError",
    "Message",
    "ChatCompletionResponse",
    "Choice",
    "Usage",
    "ChatCompletionChunk",
    "StreamChoice",
    "StreamDelta",
    "ImageData",
    "ImageResponse",
    "EmbeddingData",
    "EmbeddingResponse",
]
