from .types import ImageResponse, ImageData


class Images:
    def __init__(self, client):
        self._client = client

    def generate(self, model: str, prompt: str, n: int = 1,
                 size: str = "1024x1024", quality: str = "standard",
                 response_format: str = "url") -> ImageResponse:
        """
        Generate an image using standard OpenAI-style parameters.
        """
        payload = {
            "model": model,
            "prompt": prompt,
            "n": n,
            "size": size,
            "quality": quality,
            "response_format": response_format,
        }
        raw = self._client._post("/v1/images/generations", payload)
        
        return ImageResponse(
            created=raw.get("created", 0),
            data=[ImageData(
                url=item.get("url"),
                b64_json=item.get("b64_json")
            ) for item in raw["data"]]
        )
