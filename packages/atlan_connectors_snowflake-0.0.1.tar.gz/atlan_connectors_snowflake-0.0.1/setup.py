from setuptools import setup, find_packages

setup(
    name="atlan-connectors-snowflake",
    version="0.0.1",
    author="Ilham",
    description="Security Research Placeholder for Atlan Ecosystem",
    long_description="This package is claimed for security research purposes to prevent dependency confusion. It contains no functional code.",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
    ],
)