# Security Research Placeholder
This package has been claimed as part of a vulnerability disclosure process with Atlan.
It is intended to prevent potential supply-chain attacks (Dependency Confusion).
Contact: ilhamalazis741@gmail.com