"""Cairn.info XML converter."""
__version__ = "0.7.1"
