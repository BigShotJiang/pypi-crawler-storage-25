# Design: CLI Output Formatting and English Standardization

**Date:** 2026-05-03
**Status:** Approved

## Problem

CLI output messages are inconsistent: some are in Portuguese, some in English, and none follow a structured visual hierarchy. The output lacks clear differentiation between success, warnings, and errors.

## Scope

Standardize all `print()` output in `src/hybris_test_skills/cli.py` to:
1. English only
2. Consistent `  ✓` / `  !` / `  ✗` prefix pattern
3. Blank lines delimiting output blocks

`cmd_list` output is excluded — kept as-is.

## Prefix Convention

| Prefix | Meaning | When to use |
|---|---|---|
| `  ✓` | Success | Operation completed successfully |
| `  !` | Warning | Something happened that the user should notice, but is not a failure |
| `  ✗` | Error | Operation cannot proceed |

## Message Mapping

### `_copy_axetrules`

| Before | After |
|---|---|
| `Arquivo .axetrules existente preservado como .axetrules/custom.md por segurança.` | `  ! Existing .axetrules preserved as .axetrules/custom.md` |

### `cmd_install`

| Before | After |
|---|---|
| `Cypress module not available in this version. Coming soon in v1.0.0.` | `  ! Cypress module not available in this version. Coming soon in v1.0.0.` |
| `hybris-test-skills[{module}] installed in {dest}` | `  ✓ hybris-test-skills[{module}] installed in {dest}` |

### `cmd_uninstall`

| Before | After |
|---|---|
| `Manifesto corrompido em {dest}: {exc}` | `  ✗ Corrupted manifest at {dest}: {exc}` |
| `Nenhuma instalação encontrada em {dest}. Execute 'hybris install <module>' primeiro.` | `  ✗ No installation found in {dest}. Run 'hybris install <module>' first.` |
| `hybris-test-skills desinstalado de {dest}` | *(removed — replaced by individual ✓ lines)* |
| `  skills removidas: {names}` | `  ✓ Removed skills: {names}` |
| `  axetrules removidos: {names}` | `  ✓ Removed axetrules: {names}` |
| `.axetrules restaurado como arquivo` | `  ✓ .axetrules restored as file` |
| `Aviso: .axetrules contém arquivos adicionais — não foi possível restaurar...` | `  ! .axetrules has additional files — could not restore original. .axetrules/custom.md preserved.` |
| `.axetrules mantido (contém arquivos adicionais)` | `  ! .axetrules has additional files — directory kept as-is.` |

## Blank Line Structure

Output blocks are wrapped with a leading and trailing blank line:

```
$ hybris install junit

  ! Existing .axetrules preserved as .axetrules/custom.md

  ✓ hybris-test-skills[junit] installed in /home/.../teste

$ hybris uninstall

  ✓ Removed skills: hybris-base, hybris-junit
  ✓ Removed axetrules: commands.md, hybris-tests.md, hybris-tests-dev.md
  ✓ .axetrules restored as file

$ hybris uninstall  (no manifest)

  ✗ No installation found in /home/.../teste. Run 'hybris install <module>' first.
```

For `cmd_install`: blank line before the backup warning (if present), blank line before the success line, blank line after.

For `cmd_uninstall`: blank line before the first `✓`/`✗` line, blank line after the last line.

## Architecture

All changes are inline `print()` replacements in `cli.py`. No helper functions introduced — the number of call sites is small and a `success()`/`warn()`/`error()` abstraction would be premature.

The `axetrules_status` string (built inside `cmd_uninstall`) is updated to include the prefix character directly, since its content determines whether it is a warning or success.

## Files Modified

| File | Change |
|---|---|
| `src/hybris_test_skills/cli.py` | Update all `print()` strings |
| `tests/test_cli.py` | Update test assertions that check message content |
