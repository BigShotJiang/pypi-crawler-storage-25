# Design: Correções hybris-junit — testsrc path, validação de ambiente e test-healer

**Data:** 2026-04-29
**Origem:** Análise da sessão test-beta-2 (aXet.Plugin com AraucoCashbackFacade)
**Escopo:** 3 arquivos — run-junit.sh (edit), test-healer.py (create), SKILL.md (edit)

---

## Contexto

Durante o beta-2, três classes de falha foram identificadas:

1. O `run-junit.sh` buscava arquivos de teste em `*/src/test/*` (padrão Maven), mas Hybris usa `*/testsrc/*`. Isso causou erro "File not found" em todas as tentativas.
2. Quando o `ant` não estava no PATH, o script retornava `{"error":"Build failed: "}` com mensagem vazia, impedindo diagnóstico correto.
3. O `test-healer.py` referenciado no SKILL.md e commands.md nunca foi criado — o loop de correção automática era um no-op.

---

## Mudanças em `run-junit.sh`

### Patch 1 — busca de arquivo de teste (linha 33)

**Antes:**
```bash
TEST_FILE=$(find . -name "${SIMPLE_NAME}.java" -path "*/src/test/*" 2>/dev/null | head -1)
```

**Depois:**
```bash
TEST_FILE=$(find . -name "${SIMPLE_NAME}.java" \
    \( -path "*/testsrc/*" -o -path "*/src/test/*" \) \
    2>/dev/null | head -1)
```

A mensagem de erro também deve ser atualizada de `"not found under src/test/"` para `"not found under testsrc/ or src/test/"`.

### Patch 2 — validação explícita de ant (após o bloco setantenv.sh)

Inserir após o bloco de sourcing do `setantenv.sh`:

```bash
if ! command -v ant &>/dev/null; then
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"errorType\":\"environment\",\"error\":\"ant não encontrado. Configure HYBRIS_HOME e execute setantenv.sh antes de rodar este script.\"}"
    exit 1
fi
```

O campo `errorType: "environment"` é consumido pelo `test-healer.py` para early-exit imediato.

---

## Criação de `skills/hybris-junit/scripts/test-healer.py`

### Interface

```bash
python3 skills/hybris-junit/scripts/test-healer.py \
    <caminho/do/TestFile.java> \
    '<json_de_erro_do_run_junit>' \
    <numero_iteracao>   # 1, 2 ou 3
```

### Saída JSON

```json
{
  "shouldContinue": true,
  "iteration": 1,
  "maxIterations": 3,
  "errorType": "compile_error",
  "affectedLine": 42,
  "affectedSymbol": "AraucoCashbackModel",
  "suggestion": "Import missing: add 'import de.hybris.platform.arauco.model.AraucoCashbackModel;'",
  "rawError": "cannot find symbol..."
}
```

### Tabela de `errorType` e regras de diagnóstico

| errorType | Detectado por | shouldContinue |
|---|---|---|
| `environment` | Campo `errorType: "environment"` no JSON de entrada | `false` |
| `compile_error` | `cannot find symbol`, `error:`, `package does not exist` no `rawError` | `true` |
| `syntax_error` | `reached end of file`, `illegal start of expression`, `insert }` | `true` |
| `assertion_fail` | Surefire XML presente mas `failures > 0` (status FAIL, não ERROR) | `true` |
| `max_iterations` | `iteration >= 3` | `false` |
| `unknown` | Nenhum padrão conhecido | `true` (tenta uma vez) |

### Lógica de extração de contexto

O `test-healer.py` recebe o JSON de saída do `run-junit.sh` como string no segundo argumento. Dois shapes possíveis:

- **Status ERROR** (sem Surefire XML): `{"status":"ERROR","testClass":"...","error":"...","errorType":"...","durationMs":N}` — o campo `error` contém o output bruto do ant/javac.
- **Status FAIL** (com Surefire XML): `{"status":"FAIL","testClass":"...","testsRun":N,"testsFailed":N,"failures":[...],"durationMs":N}` — o campo `failures[]` contém os detalhes de cada falha.

Para `compile_error` e `syntax_error` (shape ERROR), o script extrai do campo `error`:
- `affectedLine`: número da linha do primeiro erro (regex `\.java:(\d+):`)
- `affectedSymbol`: símbolo problemático (regex `symbol:\s+class\s+(\w+)` ou `symbol:\s+method\s+(\w+)`)
- `suggestion`: template baseado no padrão detectado, ex:
  - `cannot find symbol` + classe → `"Add import for '<affectedSymbol>' or check if the mock is declared"`
  - `package does not exist` → `"Package in import statement not found — check if extension dependency is declared in extensioninfo.xml"`
  - `insert }` / `reached end of file` → `"Syntax error near line <affectedLine> — check unclosed braces or missing method body"`

Para `assertion_fail` (shape FAIL), serializa `failures[0].message` e `failures[0].stackTrace` como `suggestion`.

### Early-exit conditions

Retornar `shouldContinue: false` em:
- `errorType == "environment"` — ambiente não configurado, correção no teste não resolve
- `iteration >= 3` — limite de iterações atingido

### Loop de correção no SKILL.md (instrução ao LLM)

```
10. Se run-junit.sh retornar status ERROR:
    a. Chamar: python3 skills/hybris-junit/scripts/test-healer.py <arquivo> '<json>' <iteracao>
    b. Se shouldContinue == false → parar e reportar ao dev (motivo em errorType)
    c. Se shouldContinue == true → aplicar suggestion ao arquivo de teste
    d. Re-executar run-junit.sh com o mesmo class name
    e. Repetir incrementando iteracao até shouldContinue == false ou status == PASS
```

---

## Mudanças em `SKILL.md`

### Fix 1 — caminho no template do plano

**Antes:**
```
**Arquivo de teste:** src/test/java/[pacote]/DefaultXxxTest.java
```

**Depois:**
```
**Arquivo de teste:** testsrc/[pacote]/DefaultXxxTest.java
```

### Fix 2 — passo 10 do fluxo obrigatório

**Antes:**
```
10. Se falhar → invocar skills/hybris-junit/scripts/test-healer.py (máx 3 iterações)
```

**Depois:** expandir conforme a instrução completa descrita na seção acima.

---

## Arquivos alterados/criados

| Arquivo | Ação |
|---|---|
| `skills/hybris-junit/scripts/run-junit.sh` | Editar — 2 patches |
| `skills/hybris-junit/scripts/test-healer.py` | Criar |
| `skills/hybris-junit/SKILL.md` | Editar — 2 pontos |

## Fora de escopo

- `parse_java_class.py` — sem relação com os bugs
- `commands.md` — já referencia `test-healer.py` corretamente
- Lógica de geração do teste (exemplos, few-shot)
- Cypress e outras skills
