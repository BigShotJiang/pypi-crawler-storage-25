# Design: Migração de `.axetrules` arquivo→diretório e comando `uninstall`

**Data:** 2026-04-30
**Status:** Aprovado

## Problema

O comando `hybris install junit` falha com `FileExistsError` quando o workspace já possui `.axetrules` como **arquivo** (formato suportado pelo axet plugin). A função `_copy_axetrules` em `cli.py` chama `dst_dir.mkdir(exist_ok=True)`, que suprime o erro apenas quando o path já é um diretório — se for um arquivo, ainda lança a exceção.

Adicionalmente, não existe comando de desinstalação, impedindo o usuário de desfazer a instalação de forma segura.

## Escopo

1. Corrigir `_copy_axetrules` para tratar `.axetrules` como arquivo
2. Adicionar módulo `manifest.py` para rastrear o que foi instalado
3. Adicionar comando `hybris uninstall`

## Arquitetura

```
hybris install junit
  ├── _copy_skills()          — sem mudança
  ├── _copy_axetrules()       — detecta arquivo vs diretório, migra se necessário
  │     └── retorna: had_backup (bool)
  ├── manifest.write()        — salva .hybris-install.json no workspace
  └── _ensure_gitignore()     — adiciona .hybris-install.json ao .gitignore se ainda não estiver

hybris uninstall
  ├── manifest.read()         — carrega o registro
  ├── remove skills instaladas (uma a uma, pelo nome)
  ├── remove arquivos axetrules instalados (um a um, pelo nome)
  ├── resolve estado de .axetrules/
  └── manifest.delete()       — limpa o registro
```

Dois novos artefatos:
- `src/hybris_test_skills/manifest.py` — lógica de leitura/escrita do manifesto
- `.hybris-install.json` — criado no workspace do usuário

## Manifesto (`.hybris-install.json`)

```json
{
  "version": "0.1.0b3",
  "installed_at": "2026-04-30T14:32:00",
  "module": "junit",
  "skills": ["hybris-base", "hybris-junit"],
  "axetrules": ["commands.md", "hybris-tests.md", "hybris-tests-dev.md"],
  "axetrules_backup": true
}
```

- `skills` e `axetrules`: listas exatas do que foi instalado, usadas pelo uninstall para remover apenas esses itens
- `axetrules_backup`: indica se `custom.md` existe e deve ser restaurado no uninstall
- Reinstall sobrescreve o manifesto com os valores mais recentes
- O instalador adiciona `.hybris-install.json` ao `.gitignore` do workspace se ainda não estiver lá

## `manifest.py`

Três funções, sem dependências externas:

```python
MANIFEST_FILE = ".hybris-install.json"

def write(dest: Path, module: str, skills: list, axetrules: list, axetrules_backup: bool) -> None: ...
def read(dest: Path) -> dict | None:  # None se manifesto não existir
def delete(dest: Path) -> None: ...
```

## Migração de `.axetrules` (mudança em `_copy_axetrules`)

Antes do `mkdir`, verificar se o path existe como arquivo:

```
se .axetrules existe como ARQUIVO:
    lê conteúdo
    cria diretório .axetrules/
    salva conteúdo em .axetrules/custom.md
    imprime mensagem de preservação
    retorna had_backup=True
senão:
    comportamento atual (mkdir com exist_ok=True)
    retorna had_backup=False
```

Mensagem ao usuário:
> `Arquivo .axetrules existente preservado como .axetrules/custom.md por segurança.`

## Comando `hybris uninstall`

### Lógica de remoção

**Skills:**
- Remove apenas as subpastas listadas no manifesto (`skills/hybris-base/`, `skills/hybris-junit/`)
- Outras skills do usuário: intocadas
- Se `skills/` ficar vazia após a remoção → remove o diretório também

**Arquivos axetrules:**
- Remove apenas os arquivos listados no manifesto dentro de `.axetrules/`
- Arquivos adicionados pelo usuário: intocados

**Estado de `.axetrules/` após remoção dos arquivos instalados:**

| Diretório vazio? | Tem backup? | Ação |
|---|---|---|
| Sim | Sim | Restaura `custom.md` → `.axetrules` (arquivo), remove diretório |
| Sim | Não | Remove diretório |
| Não | Sim | Aviso: não foi possível restaurar — há outros arquivos em `.axetrules/`; `custom.md` permanece |
| Não | Não | Deixa diretório como está |

### CLI

Adiciona `sub.add_parser("uninstall")` em `main()`.

Mensagem de erro se manifesto não existir:
> `Nenhuma instalação encontrada em <dest>. Execute 'hybris install <module>' primeiro.`

Resumo impresso ao final do uninstall:
```
hybris-test-skills desinstalado de <dest>
  skills removidas: hybris-base, hybris-junit
  axetrules removidos: commands.md, hybris-tests.md, hybris-tests-dev.md
  .axetrules restaurado como arquivo        # ou aviso se não foi possível
```

## Arquivos modificados

| Arquivo | Mudança |
|---|---|
| `src/hybris_test_skills/cli.py` | Corrige `_copy_axetrules`; adiciona `_ensure_gitignore`; adiciona comando `uninstall` |
| `src/hybris_test_skills/manifest.py` | Novo módulo |
| `tests/test_cli.py` (ou equivalente) | Testes para migração e uninstall |
