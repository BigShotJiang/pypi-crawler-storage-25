# Design: Fix ant sourcing em run-junit.sh e aviso em check_environment.py

**Data:** 2026-04-29
**Origem:** Sessão test-beta-2-pt2 — `run-junit.sh` retornou `errorType: "environment"` mesmo com `check_environment.py` reportando `[OK]`
**Escopo:** 2 arquivos — `run-junit.sh` (edit), `check_environment.py` (edit), `tests/test_run_junit_sh.py` (edit)

---

## Causa raiz

`run-junit.sh` sourcia `setantenv.sh` sem fazer `cd` para o diretório da plataforma:

```bash
. "$SETANTENV" > /dev/null 2>&1   # CWD = raiz do projeto
```

`setantenv.sh` usa caminhos relativos internamente (ex: `ANT_HOME="../../../tools/ant"` relativo a `platform/`). Quando sourciado a partir da raiz do projeto, esses caminhos não resolvem e `ant` nunca entra no `PATH`. O `> /dev/null 2>&1` esconde o erro silenciosamente.

`check_environment.py` funciona porque faz `cd platform/ && . ./setantenv.sh` antes de verificar — os caminhos relativos resolvem corretamente.

---

## Mudança em `run-junit.sh`

**Localização:** bloco de sourcing do setantenv.sh (linhas 17-22)

**Antes:**
```bash
if [ -f "$SETANTENV" ]; then
    set +u  # setantenv.sh pode referenciar variáveis não definidas
    # shellcheck source=/dev/null
    . "$SETANTENV" > /dev/null 2>&1
    set -u
fi
```

**Depois:**
```bash
if [ -f "$SETANTENV" ]; then
    set +u  # setantenv.sh pode referenciar variáveis não definidas
    # shellcheck source=/dev/null
    pushd "$PLATFORM_DIR" > /dev/null 2>&1
    . ./setantenv.sh > /dev/null 2>&1
    popd > /dev/null 2>&1
    set -u
fi
```

`pushd`/`popd` garante que o CWD é restaurado após o sourcing. As mudanças de PATH feitas por `setantenv.sh` persistem no shell corrente porque o sourcing ocorre no mesmo processo bash — apenas o CWD é temporariamente alterado.

---

## Mudança em `check_environment.py`

**Localização:** função `check_ant()` e função `main()`

### Patch 1 — `check_ant()` retorna flag de aviso

Alterar o shape de retorno quando ant é encontrado via setantenv.sh para sinalizar que não está no PATH global. A função continua retornando `(bool, str)` para manter compatibilidade com os outros checks, mas a mensagem inclui um prefixo parseável:

```python
# Antes
return True, f"ant via setantenv.sh ({version_line})"

# Depois
return True, f"ant via setantenv.sh ({version_line})\n            ↳ ant não está no PATH global — run-junit.sh sourciará setantenv.sh automaticamente"
```

A string multi-linha é formatada para alinhar visualmente com a linha `[OK]` quando impressa por `main()`. Nenhuma mudança necessária em `main()` — o `print(f"  {status} {name}: {msg}")` já imprime a string completa.

---

## Mudança em `tests/test_run_junit_sh.py`

Adicionar classe `TestAntViaSetantenv` que verifica que `run-junit.sh` passa pelo check de ant quando:
- ant NÃO está no PATH global (PATH restrito)
- `setantenv.sh` está presente e funcional (mockado como script que adiciona um `ant` fake ao PATH)

```python
class TestAntViaSetantenv:
    def test_finds_ant_via_setantenv_when_not_in_global_path(self, tmp_path):
        # Cria estrutura fake: hybris/bin/platform/setantenv.sh que exporta ant fake
        platform_dir = tmp_path / "hybris" / "bin" / "platform"
        platform_dir.mkdir(parents=True)

        # ant fake que apenas responde a -version
        ant_bin = tmp_path / "fake_ant"
        ant_bin.write_text("#!/bin/bash\necho 'Apache Ant(TM) version 1.10.15'\n")
        ant_bin.chmod(0o755)

        # setantenv.sh que adiciona o ant fake ao PATH
        setantenv = platform_dir / "setantenv.sh"
        setantenv.write_text(f"#!/bin/bash\nexport PATH={shlex.quote(str(tmp_path))}:$PATH\n")

        make_testsrc_file(tmp_path, "com.example", "FooTest")

        restricted_path = "/usr/bin:/bin"
        if shutil.which("ant", path=restricted_path):
            pytest.skip("ant está em /usr/bin ou /bin — não é possível isolar PATH")

        output = run_junit(
            "com.example.FooTest", tmp_path,
            extra_env={
                "PATH": restricted_path,
                "HYBRIS_HOME": str(tmp_path / "hybris"),
            }
        )
        # Não deve retornar errorType environment — ant foi encontrado via setantenv.sh
        assert output.get("errorType") != "environment", (
            f"run-junit.sh falhou com errorType=environment mesmo com setantenv.sh disponível: {output}"
        )
```

---

## Arquivos alterados

| Arquivo | Ação |
|---|---|
| `skills/hybris-junit/scripts/run-junit.sh` | Editar — substituir sourcing sem cd por pushd/popd |
| `skills/hybris-base/scripts/check_environment.py` | Editar — adicionar aviso inline na mensagem de ant via setantenv.sh |
| `tests/test_run_junit_sh.py` | Editar — adicionar TestAntViaSetantenv |

## Fora de escopo

- `test-healer.py` — não relacionado
- Lógica de geração de testes
- Outros checks em `check_environment.py`
