# Ant setantenv cd Fix Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Corrigir o sourcing de `setantenv.sh` em `run-junit.sh` para que `cd` ao diretório da plataforma seja feito antes de sourcear, e adicionar aviso em `check_environment.py` quando ant está disponível apenas via setantenv.sh.

**Architecture:** Dois patches cirúrgicos: (1) substituir `. "$SETANTENV"` por `pushd`/`popd` em `run-junit.sh`; (2) adicionar linha de aviso inline na mensagem de retorno de `check_ant()` em `check_environment.py`. TDD: teste falha primeiro, depois o fix.

**Tech Stack:** Bash, Python 3.10+, pytest, unittest.mock

---

## Mapa de arquivos

| Arquivo | Ação |
|---|---|
| `skills/hybris-junit/scripts/run-junit.sh` | Editar linhas 17-22 — pushd/popd |
| `skills/hybris-base/scripts/check_environment.py` | Editar linha 149 — adicionar aviso na mensagem |
| `tests/test_run_junit_sh.py` | Editar — adicionar `TestAntViaSetantenv` |
| `tests/test_check_environment.py` | Editar — adicionar assertion de aviso em `TestCheckAnt` |

---

### Task 1: run-junit.sh — pushd/popd ao sourcear setantenv.sh

**Files:**
- Modify: `skills/hybris-junit/scripts/run-junit.sh:17-22`
- Modify: `tests/test_run_junit_sh.py` (adicionar `TestAntViaSetantenv`)

- [ ] **Step 1: Adicionar teste que falha**

Adicionar ao final de `tests/test_run_junit_sh.py`:

```python
class TestAntViaSetantenv:
    def test_finds_ant_via_setantenv_when_not_in_global_path(self, tmp_path):
        platform_dir = tmp_path / "hybris" / "bin" / "platform"
        platform_dir.mkdir(parents=True)

        # ant fake executável que responde ao command -v e ao -version
        ant_bin = tmp_path / "ant"
        ant_bin.write_text("#!/bin/bash\necho 'Apache Ant(TM) version 1.10.15'\nexit 0\n")
        ant_bin.chmod(0o755)

        # setantenv.sh que adiciona o diretório do ant fake ao PATH
        setantenv = platform_dir / "setantenv.sh"
        setantenv.write_text(
            f"export PATH={shlex.quote(str(tmp_path))}:$PATH\n"
        )

        make_testsrc_file(tmp_path, "com.example", "FooTest")

        restricted_path = "/usr/bin:/bin"
        if shutil.which("ant", path=restricted_path):
            pytest.skip("ant está em /usr/bin ou /bin — não é possível isolar PATH neste ambiente")

        output = run_junit(
            "com.example.FooTest", tmp_path,
            extra_env={
                "PATH": restricted_path,
                "HYBRIS_HOME": str(tmp_path / "hybris"),
            }
        )
        assert output.get("errorType") != "environment", (
            f"run-junit.sh retornou errorType=environment mesmo com setantenv.sh disponível — "
            f"o pushd/popd fix pode não ter sido aplicado corretamente: {output}"
        )
```

Também adicionar `import shlex` no topo do arquivo (junto com os imports existentes):

```python
import shlex
```

- [ ] **Step 2: Rodar para confirmar que falha**

```bash
cd "/home/igorchagas/Documentos/1. Projetos/Claude/hybris-test-skills"
python3 -m pytest tests/test_run_junit_sh.py::TestAntViaSetantenv -v
```

Saída esperada: FAIL — `run-junit.sh` retorna `errorType: "environment"` porque sourcia setantenv.sh sem `cd`.

- [ ] **Step 3: Aplicar fix em run-junit.sh**

Em `skills/hybris-junit/scripts/run-junit.sh`, substituir o bloco nas linhas 17-22:

**Antes:**
```bash
if [ -f "$SETANTENV" ]; then
    set +u  # setantenv.sh pode referenciar variáveis não definidas
    # shellcheck source=/dev/null
    . "$SETANTENV" > /dev/null 2>&1
    set -u
fi
```

**Depois:**
```bash
if [ -f "$SETANTENV" ]; then
    set +u  # setantenv.sh pode referenciar variáveis não definidas
    # shellcheck source=/dev/null
    pushd "$PLATFORM_DIR" > /dev/null 2>&1
    . ./setantenv.sh > /dev/null 2>&1
    popd > /dev/null 2>&1
    set -u
fi
```

- [ ] **Step 4: Rodar para confirmar que passa**

```bash
python3 -m pytest tests/test_run_junit_sh.py::TestAntViaSetantenv -v
```

Saída esperada: PASS — `errorType` não é `"environment"`.

- [ ] **Step 5: Rodar toda a suite de test_run_junit_sh.py**

```bash
python3 -m pytest tests/test_run_junit_sh.py -v
```

Saída esperada: todos os testes existentes continuam passando.

- [ ] **Step 6: Commit**

```bash
git add skills/hybris-junit/scripts/run-junit.sh tests/test_run_junit_sh.py
git commit -m "fix: run-junit.sh usa pushd/popd ao sourcear setantenv.sh para resolver paths relativos"
```

---

### Task 2: check_environment.py — aviso quando ant disponível apenas via setantenv.sh

**Files:**
- Modify: `skills/hybris-base/scripts/check_environment.py:147-149`
- Modify: `tests/test_check_environment.py` (atualizar `test_passes_via_setantenv_when_ant_not_in_path`)

- [ ] **Step 1: Adicionar assertion de aviso no teste existente**

Em `tests/test_check_environment.py`, localizar o teste `test_passes_via_setantenv_when_ant_not_in_path` (linha ~231) e adicionar uma assertion ao final:

```python
def test_passes_via_setantenv_when_ant_not_in_path(self):
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = "Apache Ant(TM) version 1.10.15\nant home: /path\n"
    fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
    with patch("shutil.which", return_value=None):
        with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_ant()
    assert ok is True
    assert "setantenv.sh" in msg
    assert "Apache Ant(TM) version 1.10.15" in msg
    assert "PATH global" in msg  # nova assertion — aviso deve estar presente
```

- [ ] **Step 2: Rodar para confirmar que falha**

```bash
python3 -m pytest "tests/test_check_environment.py::TestCheckAnt::test_passes_via_setantenv_when_ant_not_in_path" -v
```

Saída esperada: FAIL — `"PATH global" not in msg`.

- [ ] **Step 3: Aplicar fix em check_environment.py**

Em `skills/hybris-base/scripts/check_environment.py`, localizar a linha dentro de `check_ant()` (aproximadamente linha 149):

**Antes:**
```python
return True, f"ant via setantenv.sh ({version_line})"
```

**Depois:**
```python
return True, (
    f"ant via setantenv.sh ({version_line})\n"
    f"            ↳ ant não está no PATH global — run-junit.sh sourciará setantenv.sh automaticamente"
)
```

- [ ] **Step 4: Rodar para confirmar que passa**

```bash
python3 -m pytest "tests/test_check_environment.py::TestCheckAnt::test_passes_via_setantenv_when_ant_not_in_path" -v
```

Saída esperada: PASS.

- [ ] **Step 5: Rodar suite completa**

```bash
python3 -m pytest tests/ -v
```

Saída esperada: todos os testes passam.

- [ ] **Step 6: Commit**

```bash
git add skills/hybris-base/scripts/check_environment.py tests/test_check_environment.py
git commit -m "fix: check_environment.py exibe aviso quando ant disponível apenas via setantenv.sh"
```
