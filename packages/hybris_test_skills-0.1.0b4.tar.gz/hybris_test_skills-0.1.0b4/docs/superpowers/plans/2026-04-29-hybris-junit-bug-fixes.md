# hybris-junit Bug Fixes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Corrigir 3 bugs no fluxo /junit: path de busca errado (src/test vs testsrc), validação silenciosa de ant, e script test-healer.py ausente que impedia o loop de correção.

**Architecture:** Dois patches cirúrgicos no bash script existente (run-junit.sh), criação do módulo Python test-healer.py com diagnóstico estruturado de erros e early-exit de ambiente, e dois ajustes de texto no SKILL.md. Nenhuma mudança fora desse escopo.

**Tech Stack:** Bash, Python 3.10+, pytest (já configurado em pyproject.toml), importlib para carregar módulo com hífen no nome.

---

## Mapa de arquivos

| Arquivo | Ação | Responsabilidade |
|---|---|---|
| `skills/hybris-junit/scripts/run-junit.sh` | Editar | Executor JUnit via ant; saída JSON estruturada |
| `skills/hybris-junit/scripts/test-healer.py` | Criar | Diagnóstico de erros; saída JSON com `shouldContinue` e `suggestion` para o LLM |
| `skills/hybris-junit/SKILL.md` | Editar | Instrução ao LLM sobre fluxo de geração e loop de correção |
| `tests/test_run_junit_sh.py` | Criar | Testes de integração do shell script via subprocess |
| `tests/test_test_healer.py` | Criar | Testes unitários do test-healer.py via importlib |

---

### Task 1: run-junit.sh — patch de busca testsrc

**Files:**
- Modify: `skills/hybris-junit/scripts/run-junit.sh:33-38`
- Create: `tests/test_run_junit_sh.py`

- [ ] **Step 1: Criar arquivo de teste com caso que falha**

Criar `tests/test_run_junit_sh.py`:

```python
"""Testes de integração para run-junit.sh."""
import json
import os
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
SCRIPT = PROJECT_ROOT / "skills" / "hybris-junit" / "scripts" / "run-junit.sh"


def run_junit(test_class: str, cwd: Path, extra_env: dict | None = None) -> dict:
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    result = subprocess.run(
        ["bash", str(SCRIPT), test_class],
        capture_output=True, text=True, env=env, cwd=str(cwd)
    )
    return json.loads(result.stdout)


def make_testsrc_file(base: Path, pkg: str, class_name: str, annotation: str = "@UnitTest") -> Path:
    """Cria <base>/myext/testsrc/<pkg_as_path>/<class_name>.java com anotação."""
    pkg_path = base / "myext" / "testsrc" / Path(*pkg.split("."))
    pkg_path.mkdir(parents=True, exist_ok=True)
    java_file = pkg_path / f"{class_name}.java"
    java_file.write_text(
        f"package {pkg};\n{annotation}\npublic class {class_name} {{}}\n"
    )
    return java_file


class TestFindTestFile:
    def test_finds_file_in_testsrc(self, tmp_path):
        # Arquivo em testsrc/ — deve ser encontrado
        make_testsrc_file(tmp_path, "com.example", "FooTest")
        output = run_junit("com.example.FooTest", tmp_path)
        # Se o arquivo não for encontrado, o erro seria "FooTest.java not found under src/test/"
        # Qualquer outro erro (ant, ambiente) significa que o arquivo foi encontrado
        assert "FooTest.java not found" not in output.get("error", "")

    def test_error_message_mentions_testsrc_when_file_missing(self, tmp_path):
        # Sem nenhum arquivo — erro deve mencionar testsrc
        output = run_junit("com.example.MissingTest", tmp_path)
        assert output["status"] == "ERROR"
        assert "MissingTest.java not found" in output["error"]
        assert "testsrc" in output["error"]
```

- [ ] **Step 2: Rodar o teste para confirmar que falha**

```bash
cd /home/igorchagas/Documentos/1.\ Projetos/Claude/hybris-test-skills
python3 -m pytest tests/test_run_junit_sh.py::TestFindTestFile -v
```

Saída esperada: 2 FAIL — `test_finds_file_in_testsrc` falha porque retorna "not found under src/test/"; `test_error_message_mentions_testsrc_when_file_missing` falha porque a mensagem não menciona "testsrc".

- [ ] **Step 3: Aplicar patch 1 em run-junit.sh**

Em `skills/hybris-junit/scripts/run-junit.sh`, substituir as linhas 33–38:

**Antes:**
```bash
TEST_FILE=$(find . -name "${SIMPLE_NAME}.java" -path "*/src/test/*" 2>/dev/null | head -1)

if [ -z "$TEST_FILE" ]; then
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"error\":\"File ${SIMPLE_NAME}.java not found under src/test/\"}"
    exit 1
fi
```

**Depois:**
```bash
TEST_FILE=$(find . -name "${SIMPLE_NAME}.java" \
    \( -path "*/testsrc/*" -o -path "*/src/test/*" \) \
    2>/dev/null | head -1)

if [ -z "$TEST_FILE" ]; then
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"error\":\"File ${SIMPLE_NAME}.java not found under testsrc/ or src/test/\"}"
    exit 1
fi
```

- [ ] **Step 4: Rodar os testes para confirmar que passam**

```bash
python3 -m pytest tests/test_run_junit_sh.py::TestFindTestFile -v
```

Saída esperada: 2 passed.

- [ ] **Step 5: Commit**

```bash
git add skills/hybris-junit/scripts/run-junit.sh tests/test_run_junit_sh.py
git commit -m "fix: run-junit.sh busca testsrc/ além de src/test/ — padrão Hybris"
```

---

### Task 2: run-junit.sh — validação explícita de ant

**Files:**
- Modify: `skills/hybris-junit/scripts/run-junit.sh` (inserir após linha 30, após `SIMPLE_NAME=...`)
- Modify: `tests/test_run_junit_sh.py` (adicionar `TestAntValidation`)

- [ ] **Step 1: Adicionar teste que falha**

Primeiro, adicionar `import shutil` ao bloco de imports no topo de `tests/test_run_junit_sh.py` (junto com os imports existentes de `json`, `os`, `subprocess`, `pathlib`).

Depois, adicionar ao final do arquivo:

```python
class TestAntValidation:
    def test_returns_environment_error_when_ant_not_in_path(self, tmp_path):
        make_testsrc_file(tmp_path, "com.example", "FooTest")
        # PATH restrito a utilitários básicos — ant geralmente não está em /usr/bin ou /bin
        restricted_path = "/usr/bin:/bin"
        if shutil.which("ant", path=restricted_path):
            import pytest
            pytest.skip("ant está em /usr/bin ou /bin — não é possível isolar PATH neste ambiente")
        output = run_junit(
            "com.example.FooTest", tmp_path,
            extra_env={"PATH": restricted_path, "HYBRIS_HOME": str(tmp_path)}
        )
        assert output["status"] == "ERROR"
        assert output.get("errorType") == "environment"
        assert "ant" in output["error"].lower()
```

- [ ] **Step 2: Rodar o teste para confirmar que falha**

```bash
python3 -m pytest tests/test_run_junit_sh.py::TestAntValidation -v
```

Saída esperada: FAIL — script não retorna `errorType: "environment"`, retorna `{"error":"Build failed: "}` ou similar.

- [ ] **Step 3: Aplicar patch 2 em run-junit.sh**

Em `skills/hybris-junit/scripts/run-junit.sh`, inserir após a linha `SIMPLE_NAME="${CLASS_NAME##*.}"` (linha 30):

```bash
if ! command -v ant &>/dev/null; then
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"errorType\":\"environment\",\"error\":\"ant não encontrado. Configure HYBRIS_HOME e execute setantenv.sh antes de rodar este script.\"}"
    exit 1
fi
```

O bloco deve ficar assim no arquivo (linhas 29–37):

```bash
CLASS_NAME="$1"
SIMPLE_NAME="${CLASS_NAME##*.}"

if ! command -v ant &>/dev/null; then
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"errorType\":\"environment\",\"error\":\"ant não encontrado. Configure HYBRIS_HOME e execute setantenv.sh antes de rodar este script.\"}"
    exit 1
fi

TEST_FILE=$(find . -name "${SIMPLE_NAME}.java" \
```

- [ ] **Step 4: Rodar todos os testes do arquivo**

```bash
python3 -m pytest tests/test_run_junit_sh.py -v
```

Saída esperada: 3 passed (TestFindTestFile × 2 + TestAntValidation × 1).

- [ ] **Step 5: Commit**

```bash
git add skills/hybris-junit/scripts/run-junit.sh tests/test_run_junit_sh.py
git commit -m "fix: run-junit.sh valida ant antes de executar e retorna errorType environment"
```

---

### Task 3: test-healer.py — estrutura base e early-exit

**Files:**
- Create: `skills/hybris-junit/scripts/test-healer.py`
- Create: `tests/test_test_healer.py`

O script tem hífen no nome (`test-healer.py`), que é inválido como identificador Python. Os testes o carregam via `importlib.util`.

- [ ] **Step 1: Criar arquivo de teste com casos de early-exit que falham**

Criar `tests/test_test_healer.py`:

```python
"""Testes para test-healer.py — diagnóstico estruturado de erros JUnit."""
import importlib.util
import json
from pathlib import Path

HEALER_PATH = Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts" / "test-healer.py"


def load_healer():
    spec = importlib.util.spec_from_file_location("test_healer", HEALER_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TestEarlyExit:
    def test_environment_error_stops_loop(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "testClass": "com.example.FooTest",
            "errorType": "environment",
            "error": "ant não encontrado.",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["shouldContinue"] is False
        assert result["errorType"] == "environment"

    def test_max_iterations_stops_loop(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "testClass": "com.example.FooTest",
            "error": "cannot find symbol",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=3)
        assert result["shouldContinue"] is False
        assert result["errorType"] == "max_iterations"

    def test_iteration_below_max_continues(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "testClass": "com.example.FooTest",
            "error": "cannot find symbol",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["shouldContinue"] is True

    def test_output_always_includes_required_fields(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "testClass": "com.example.FooTest",
            "errorType": "environment",
            "error": "ant não encontrado.",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        for field in ("shouldContinue", "iteration", "maxIterations", "errorType", "suggestion", "rawError"):
            assert field in result, f"Campo ausente: {field}"
```

- [ ] **Step 2: Rodar para confirmar que falha**

```bash
python3 -m pytest tests/test_test_healer.py::TestEarlyExit -v
```

Saída esperada: 4 FAIL com `ModuleNotFoundError` ou `FileNotFoundError` — o script não existe ainda.

- [ ] **Step 3: Criar test-healer.py com estrutura base**

Criar `skills/hybris-junit/scripts/test-healer.py`:

```python
#!/usr/bin/env python3
"""test-healer.py — diagnóstico estruturado de erros JUnit para loop de correção.

Uso:
    python3 test-healer.py <caminho/TestFile.java> '<json_do_run_junit>' <iteracao>

Saída:
    JSON com shouldContinue, errorType, suggestion e metadados para o LLM.
"""
import json
import re
import sys

MAX_ITERATIONS = 3


def classify_error(run_junit_json: dict) -> str:
    """Retorna o errorType baseado no JSON de saída do run-junit.sh."""
    if run_junit_json.get("errorType") == "environment":
        return "environment"

    status = run_junit_json.get("status", "")
    if status == "FAIL":
        return "assertion_fail"

    error = run_junit_json.get("error", "")

    syntax_patterns = ["reached end of file", "illegal start of expression", "insert }"]
    if any(p in error for p in syntax_patterns):
        return "syntax_error"

    compile_patterns = ["cannot find symbol", "package does not exist", "error:"]
    if any(p in error for p in compile_patterns):
        return "compile_error"

    return "unknown"


def extract_context(run_junit_json: dict, error_type: str) -> dict:
    """Extrai affectedLine, affectedSymbol e suggestion do JSON de erro."""
    error = run_junit_json.get("error", "")

    if error_type == "assertion_fail":
        failures = run_junit_json.get("failures", [])
        if failures:
            first = failures[0]
            msg = first.get("message", "")
            trace = first.get("stackTrace", "")[:300]
            suggestion = f"Assertion failed: {msg}. Stack trace: {trace}"
        else:
            suggestion = "Test failed but no failure details available in JSON"
        return {"affectedLine": None, "affectedSymbol": None, "suggestion": suggestion}

    if error_type in ("compile_error", "syntax_error"):
        line_match = re.search(r'\.java:(\d+):', error)
        affected_line = int(line_match.group(1)) if line_match else None

        symbol_match = re.search(r'symbol:\s+(?:class|method|variable)\s+(\w+)', error)
        affected_symbol = symbol_match.group(1) if symbol_match else None

        line_str = f" near line {affected_line}" if affected_line else ""

        if "cannot find symbol" in error and affected_symbol:
            suggestion = (
                f"Add import for '{affected_symbol}' or check if the mock is declared in the test class"
            )
        elif "package does not exist" in error:
            suggestion = (
                "Package in import statement not found — check if the extension dependency "
                "is declared in extensioninfo.xml"
            )
        elif "insert }" in error or "reached end of file" in error:
            suggestion = f"Syntax error{line_str} — check for unclosed braces or missing method body"
        elif "illegal start of expression" in error:
            suggestion = (
                f"Syntax error{line_str} — check for misplaced keywords or extra/missing semicolons"
            )
        else:
            suggestion = f"Compilation error{line_str} — review the full error message in rawError"

        return {"affectedLine": affected_line, "affectedSymbol": affected_symbol, "suggestion": suggestion}

    return {"affectedLine": None, "affectedSymbol": None, "suggestion": ""}


def build_diagnosis(run_junit_json: dict, iteration: int) -> dict:
    """Constrói o JSON de diagnóstico completo para o LLM."""
    if iteration >= MAX_ITERATIONS:
        return {
            "shouldContinue": False,
            "iteration": iteration,
            "maxIterations": MAX_ITERATIONS,
            "errorType": "max_iterations",
            "affectedLine": None,
            "affectedSymbol": None,
            "suggestion": f"Max iterations ({MAX_ITERATIONS}) reached — stop and report to developer",
            "rawError": run_junit_json.get("error", ""),
        }

    error_type = classify_error(run_junit_json)
    should_continue = error_type not in ("environment",)
    context = extract_context(run_junit_json, error_type)

    return {
        "shouldContinue": should_continue,
        "iteration": iteration,
        "maxIterations": MAX_ITERATIONS,
        "errorType": error_type,
        "affectedLine": context["affectedLine"],
        "affectedSymbol": context["affectedSymbol"],
        "suggestion": context["suggestion"],
        "rawError": run_junit_json.get("error", ""),
    }


def main() -> None:
    if len(sys.argv) != 4:
        print(json.dumps({
            "shouldContinue": False,
            "errorType": "environment",
            "suggestion": "Usage: test-healer.py <test_file> '<run_junit_json>' <iteration>",
            "rawError": "",
        }))
        sys.exit(1)

    _test_file, error_json_str, iteration_str = sys.argv[1], sys.argv[2], sys.argv[3]
    run_junit_json = json.loads(error_json_str)
    iteration = int(iteration_str)
    print(json.dumps(build_diagnosis(run_junit_json, iteration)))


if __name__ == "__main__":
    main()
```

- [ ] **Step 4: Rodar os testes para confirmar que passam**

```bash
python3 -m pytest tests/test_test_healer.py::TestEarlyExit -v
```

Saída esperada: 4 passed.

- [ ] **Step 5: Commit**

```bash
git add skills/hybris-junit/scripts/test-healer.py tests/test_test_healer.py
git commit -m "feat: criar test-healer.py com estrutura base e early-exit de ambiente"
```

---

### Task 4: test-healer.py — diagnóstico compile_error e syntax_error

**Files:**
- Modify: `tests/test_test_healer.py` (adicionar `TestCompileAndSyntaxErrors`)

Nenhuma mudança no código de produção — a lógica já foi implementada na Task 3. Esta task apenas valida os caminhos de diagnóstico com testes explícitos.

- [ ] **Step 1: Adicionar testes**

Adicionar ao final de `tests/test_test_healer.py`:

```python
class TestCompileAndSyntaxErrors:
    def test_classifies_cannot_find_symbol_as_compile_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:42: error: cannot find symbol\n  symbol:   class AraucoCashbackModel",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "compile_error"
        assert result["shouldContinue"] is True

    def test_extracts_line_number_from_compile_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:42: error: cannot find symbol\n  symbol:   class AraucoCashbackModel",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["affectedLine"] == 42

    def test_extracts_symbol_from_compile_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:42: error: cannot find symbol\n  symbol:   class AraucoCashbackModel",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["affectedSymbol"] == "AraucoCashbackModel"

    def test_suggestion_mentions_import_for_symbol(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:10: error: cannot find symbol\n  symbol:   class MyModel",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert "import" in result["suggestion"].lower() or "MyModel" in result["suggestion"]

    def test_classifies_package_not_exist_as_compile_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:3: error: package de.hybris.platform.foo does not exist",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "compile_error"
        assert "extensioninfo" in result["suggestion"].lower()

    def test_classifies_insert_brace_as_syntax_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:328: error: reached end of file while parsing\n insert } to complete ClassBody",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "syntax_error"
        assert "brace" in result["suggestion"].lower() or "}" in result["suggestion"]
```

- [ ] **Step 2: Rodar os testes**

```bash
python3 -m pytest tests/test_test_healer.py::TestCompileAndSyntaxErrors -v
```

Saída esperada: 6 passed.

- [ ] **Step 3: Commit**

```bash
git add tests/test_test_healer.py
git commit -m "test: adicionar testes de diagnóstico compile_error e syntax_error no test-healer"
```

---

### Task 5: test-healer.py — diagnóstico assertion_fail

**Files:**
- Modify: `tests/test_test_healer.py` (adicionar `TestAssertionFail`)

- [ ] **Step 1: Adicionar testes**

Adicionar ao final de `tests/test_test_healer.py`:

```python
class TestAssertionFail:
    def test_classifies_fail_status_as_assertion_fail(self):
        healer = load_healer()
        run_junit_json = {
            "status": "FAIL",
            "testClass": "com.example.FooTest",
            "testsRun": 3,
            "testsFailed": 1,
            "failures": [
                {
                    "testMethod": "shouldReturnCashback",
                    "errorType": "assertion_fail",
                    "message": "expected:<10.0> but was:<0.0>",
                    "stackTrace": "at com.example.FooTest.shouldReturnCashback(FooTest.java:55)",
                    "line": 55,
                }
            ],
            "durationMs": 120,
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "assertion_fail"
        assert result["shouldContinue"] is True

    def test_suggestion_includes_failure_message(self):
        healer = load_healer()
        run_junit_json = {
            "status": "FAIL",
            "testClass": "com.example.FooTest",
            "testsRun": 1,
            "testsFailed": 1,
            "failures": [
                {
                    "testMethod": "shouldReturnCashback",
                    "errorType": "assertion_fail",
                    "message": "expected:<10.0> but was:<0.0>",
                    "stackTrace": "at FooTest.java:55",
                    "line": 55,
                }
            ],
            "durationMs": 80,
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert "expected:<10.0> but was:<0.0>" in result["suggestion"]

    def test_suggestion_fallback_when_no_failures_array(self):
        healer = load_healer()
        run_junit_json = {
            "status": "FAIL",
            "testClass": "com.example.FooTest",
            "testsRun": 1,
            "testsFailed": 1,
            "failures": [],
            "durationMs": 50,
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "assertion_fail"
        assert result["suggestion"]  # deve ter alguma mensagem de fallback
```

- [ ] **Step 2: Rodar os testes**

```bash
python3 -m pytest tests/test_test_healer.py::TestAssertionFail -v
```

Saída esperada: 3 passed.

- [ ] **Step 3: Rodar toda a suite para garantir ausência de regressão**

```bash
python3 -m pytest tests/ -v
```

Saída esperada: todos os testes passam (inclui os pré-existentes de parse_java_class, parse_items_xml, etc.).

- [ ] **Step 4: Commit**

```bash
git add tests/test_test_healer.py
git commit -m "test: adicionar testes de diagnóstico assertion_fail no test-healer"
```

---

### Task 6: SKILL.md — fixes de caminho e loop de correção

**Files:**
- Modify: `skills/hybris-junit/SKILL.md`

Edições de texto — não há código executável para testar com pytest. Verificação é visual (leitura do arquivo).

- [ ] **Step 1: Fix 1 — caminho no template do plano**

Em `skills/hybris-junit/SKILL.md`, localizar a linha:

```
**Arquivo de teste:** src/test/java/[pacote]/DefaultXxxTest.java
```

Substituir por:

```
**Arquivo de teste:** testsrc/[pacote]/DefaultXxxTest.java
```

- [ ] **Step 2: Fix 2 — expandir passo 10 do fluxo obrigatório**

Localizar a linha:

```
10. Se falhar → invocar skills/hybris-junit/scripts/test-healer.py (máx 3 iterações)
```

Substituir por:

```
10. Se run-junit.sh retornar status ERROR ou FAIL:
    a. Executar: python3 skills/hybris-junit/scripts/test-healer.py <caminho/TestFile.java> '<json_do_run_junit>' <iteracao>
    b. Se shouldContinue == false → parar o loop e reportar ao dev (motivo em errorType)
    c. Se shouldContinue == true → aplicar a suggestion ao arquivo de teste
    d. Re-executar: bash skills/hybris-junit/scripts/run-junit.sh <fully.qualified.TestClassName>
    e. Repetir incrementando iteracao (1 → 2 → 3) até shouldContinue == false ou status == PASS
```

- [ ] **Step 3: Verificar o arquivo editado**

```bash
grep -n "testsrc\|test-healer\|shouldContinue" skills/hybris-junit/SKILL.md
```

Saída esperada: ao menos 3 linhas mencionando `testsrc`, `test-healer.py`, e `shouldContinue`.

- [ ] **Step 4: Commit final**

```bash
git add skills/hybris-junit/SKILL.md
git commit -m "fix: SKILL.md corrige caminho testsrc e expande instrução do loop de correção"
```
