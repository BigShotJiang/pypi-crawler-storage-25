# CLI Output Formatting — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Standardize all CLI output messages to English with `  ✓` / `  !` / `  ✗` prefixes and blank-line-delimited output blocks.

**Architecture:** Inline `print()` string replacements in `cli.py` only — no helper functions introduced. `axetrules_status` strings are updated to carry their own prefix character. Tests checking Portuguese strings are updated to match the new English messages.

**Tech Stack:** Python 3.13, pytest — standard library only.

---

## File Map

| File | Action |
|---|---|
| `src/hybris_test_skills/cli.py` | Update all `print()` calls |
| `tests/test_cli.py` | Update 5 test assertions that check output strings |

---

## Task 1: Update output messages in `cli.py` and fix test assertions

**Files:**
- Modify: `src/hybris_test_skills/cli.py`
- Modify: `tests/test_cli.py`

Work in: `/home/igorchagas/Documentos/1. Projetos/Claude/hybris-test-skills/.worktrees/axetrules-migration`

---

### Step 1: Update test assertions to expect new English messages

Find and update these 5 assertions in `tests/test_cli.py`:

**1a. `test_axetrules_arquivo_migrado_exibe_mensagem`** (currently lines ~75-77):

Replace:
```python
assert "custom.md" in out
assert "segurança" in out
```
With:
```python
assert "! Existing .axetrules preserved as .axetrules/custom.md" in out
```

**1b. `test_nao_restaura_arquivo_quando_nao_vazio_com_backup`** (currently line ~265):

Replace:
```python
assert "não foi possível restaurar" in out.lower() or "custom.md" in out
```
With:
```python
assert "could not restore" in out.lower()
```

**1c. `test_uninstall_sem_manifesto_exibe_erro`** (currently line ~279):

Replace:
```python
assert "nenhuma instalação encontrada" in out.lower()
```
With:
```python
assert "no installation found" in out.lower()
```

**1d. `test_uninstall_manifesto_corrompido_exibe_erro`** (currently line ~286):

Replace:
```python
assert "corrompido" in out.lower() or "corrupted" in out.lower()
```
With:
```python
assert "corrupted" in out.lower()
```

**1e. `test_uninstall_exibe_resumo`** (currently lines ~294-296):

Replace:
```python
assert "desinstalado" in out.lower()
assert "hybris-base" in out
assert "hybris-junit" in out
```
With:
```python
assert "removed skills" in out.lower()
assert "hybris-base" in out
assert "hybris-junit" in out
```

---

### Step 2: Run tests to verify they fail

```bash
cd /home/igorchagas/Documentos/1. Projetos/Claude/hybris-test-skills/.worktrees/axetrules-migration
pytest tests/test_cli.py -k "mensagem or exibe_erro or corrompido or exibe_resumo" -v
```

Expected: 5 tests FAIL — the assertions no longer match the current Portuguese strings in `cli.py`.

---

### Step 3: Update `cli.py` — `_copy_axetrules`

Find line 154 and replace:
```python
print("Arquivo .axetrules existente preservado como .axetrules/custom.md por segurança.")
```
With:
```python
print("\n  ! Existing .axetrules preserved as .axetrules/custom.md")
```

---

### Step 4: Update `cli.py` — `cmd_install`

**Cypress message** (line 63). Replace:
```python
print("Cypress module not available in this version. Coming soon in v1.0.0.")
```
With:
```python
print("\n  ! Cypress module not available in this version. Coming soon in v1.0.0.\n")
```

**Success message** (line 71). Replace:
```python
print(f"hybris-test-skills[{module}] installed in {dest}")
```
With:
```python
print(f"\n  ✓ hybris-test-skills[{module}] installed in {dest}\n")
```

---

### Step 5: Update `cli.py` — `cmd_uninstall` error messages

**Corrupted manifest** (line 78). Replace:
```python
print(f"Manifesto corrompido em {dest}: {exc}")
```
With:
```python
print(f"\n  ✗ Corrupted manifest at {dest}: {exc}\n")
```

**No manifest** (line 81). Replace:
```python
print(f"Nenhuma instalação encontrada em {dest}. Execute 'hybris install <module>' primeiro.")
```
With:
```python
print(f"\n  ✗ No installation found in {dest}. Run 'hybris install <module>' first.\n")
```

---

### Step 6: Update `cli.py` — `cmd_uninstall` `axetrules_status` strings and summary block

**`axetrules_status` assignments** (lines 114, 116-119, 124). Replace the entire block:

```python
                axetrules_status = ".axetrules restaurado como arquivo"
            else:
                axetrules_status = (
                    "Aviso: .axetrules contém arquivos adicionais — não foi possível restaurar "
                    "o arquivo original. .axetrules/custom.md permanece no diretório."
                )
        else:
            if not remaining:
                shutil.rmtree(axetrules_dir)
            else:
                axetrules_status = ".axetrules mantido (contém arquivos adicionais)"
```

With:

```python
                axetrules_status = "✓ .axetrules restored as file"
            else:
                axetrules_status = (
                    "! .axetrules has additional files — could not restore original. "
                    ".axetrules/custom.md preserved."
                )
        else:
            if not remaining:
                shutil.rmtree(axetrules_dir)
            else:
                axetrules_status = "! .axetrules has additional files — directory kept as-is."
```

**Summary block** (lines 128-134). Replace:

```python
    print(f"hybris-test-skills desinstalado de {dest}")
    if removed_skills:
        print(f"  skills removidas: {', '.join(removed_skills)}")
    if removed_axetrules:
        print(f"  axetrules removidos: {', '.join(removed_axetrules)}")
    if axetrules_status:
        print(f"  {axetrules_status}")
```

With:

```python
    print()
    if removed_skills:
        print(f"  ✓ Removed skills: {', '.join(removed_skills)}")
    if removed_axetrules:
        print(f"  ✓ Removed axetrules: {', '.join(removed_axetrules)}")
    if axetrules_status:
        print(f"  {axetrules_status}")
    print()
```

---

### Step 7: Run all tests

```bash
pytest tests/ -v
```

Expected: all 133 tests PASS.

---

### Step 8: Commit

```bash
git add src/hybris_test_skills/cli.py tests/test_cli.py
git commit -m "feat: standardize CLI output to English with ✓/!/✗ prefixes"
```
