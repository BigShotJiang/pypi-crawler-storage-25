# axetrules Migration and Uninstall Command — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix the `FileExistsError` crash when `.axetrules` exists as a file, preserve existing content as `custom.md`, and add a `hybris uninstall` command that safely reverts what was installed.

**Architecture:** New `manifest.py` module writes/reads `.hybris-install.json` in the user's workspace, tracking exactly what was installed. `_copy_axetrules` is updated to detect a file at `.axetrules` and migrate it before installing. `cmd_uninstall` reads the manifest and removes only what it tracks, resolving the `.axetrules` state from a decision table.

**Tech Stack:** Python 3.13, `pathlib`, `shutil`, `json`, `datetime` — standard library only.

---

## File Map

| File | Action | Responsibility |
|---|---|---|
| `src/hybris_test_skills/manifest.py` | Create | write/read/delete `.hybris-install.json` |
| `src/hybris_test_skills/cli.py` | Modify | fix `_copy_axetrules`, add `_ensure_gitignore`, update `cmd_install`, add `cmd_uninstall` |
| `tests/test_manifest.py` | Create | unit tests for manifest module |
| `tests/test_cli.py` | Modify | add tests for migration, gitignore, and uninstall |

---

## Task 1: Create `manifest.py`

**Files:**
- Create: `src/hybris_test_skills/manifest.py`
- Create: `tests/test_manifest.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_manifest.py`:

```python
"""Testes para manifest.py."""
import json
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestManifestWrite:
    def test_cria_arquivo_json(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base"], ["commands.md"], False, "0.1.0b3")
        assert (tmp_path / ".hybris-install.json").exists()

    def test_conteudo_correto(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base", "hybris-junit"],
                       ["commands.md", "hybris-tests.md"], True, "0.1.0b3")
        data = json.loads((tmp_path / ".hybris-install.json").read_text())
        assert data["module"] == "junit"
        assert data["skills"] == ["hybris-base", "hybris-junit"]
        assert data["axetrules"] == ["commands.md", "hybris-tests.md"]
        assert data["axetrules_backup"] is True
        assert data["version"] == "0.1.0b3"
        assert "installed_at" in data

    def test_sobrescreve_manifesto_existente(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base"], ["commands.md"], False, "0.1.0b1")
        manifest.write(tmp_path, "all",   ["hybris-base"], ["commands.md"], True,  "0.1.0b3")
        data = json.loads((tmp_path / ".hybris-install.json").read_text())
        assert data["module"] == "all"
        assert data["version"] == "0.1.0b3"


class TestManifestRead:
    def test_retorna_dict_quando_existe(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base"], ["commands.md"], False, "0.1.0b3")
        data = manifest.read(tmp_path)
        assert data is not None
        assert data["module"] == "junit"

    def test_retorna_none_quando_nao_existe(self, tmp_path):
        from hybris_test_skills import manifest
        assert manifest.read(tmp_path) is None


class TestManifestDelete:
    def test_remove_arquivo(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base"], ["commands.md"], False, "0.1.0b3")
        manifest.delete(tmp_path)
        assert not (tmp_path / ".hybris-install.json").exists()

    def test_nao_falha_se_nao_existe(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.delete(tmp_path)  # não deve lançar exceção
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_manifest.py -v
```

Expected: `ModuleNotFoundError: No module named 'hybris_test_skills.manifest'`

- [ ] **Step 3: Create `manifest.py`**

```python
"""Registro de instalação do hybris-test-skills no workspace."""
import json
from datetime import datetime
from pathlib import Path

MANIFEST_FILE = ".hybris-install.json"


def write(
    dest: Path,
    module: str,
    skills: list,
    axetrules: list,
    axetrules_backup: bool,
    version: str,
) -> None:
    data = {
        "version": version,
        "installed_at": datetime.now().isoformat(timespec="seconds"),
        "module": module,
        "skills": skills,
        "axetrules": axetrules,
        "axetrules_backup": axetrules_backup,
    }
    (dest / MANIFEST_FILE).write_text(json.dumps(data, indent=2))


def read(dest: Path) -> dict | None:
    path = dest / MANIFEST_FILE
    if not path.exists():
        return None
    return json.loads(path.read_text())


def delete(dest: Path) -> None:
    path = dest / MANIFEST_FILE
    if path.exists():
        path.unlink()
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_manifest.py -v
```

Expected: all 8 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/hybris_test_skills/manifest.py tests/test_manifest.py
git commit -m "feat: add manifest module for install tracking"
```

---

## Task 2: Fix `_copy_axetrules` for file→directory migration

**Files:**
- Modify: `src/hybris_test_skills/cli.py:65-72`
- Modify: `tests/test_cli.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_cli.py` inside `class TestInstallJunit`:

```python
def test_axetrules_arquivo_migrado_para_custom_md(self, tmp_path):
    from hybris_test_skills.cli import cmd_install
    # Cria .axetrules como arquivo (formato antigo do axet)
    axetrules_file = tmp_path / ".axetrules"
    axetrules_file.write_text("regra personalizada do usuário")

    cmd_install("junit", tmp_path)

    assert (tmp_path / ".axetrules").is_dir()
    assert (tmp_path / ".axetrules" / "custom.md").exists()
    assert (tmp_path / ".axetrules" / "custom.md").read_text() == "regra personalizada do usuário"

def test_axetrules_arquivo_migrado_exibe_mensagem(self, tmp_path, capsys):
    from hybris_test_skills.cli import cmd_install
    axetrules_file = tmp_path / ".axetrules"
    axetrules_file.write_text("conteúdo")

    cmd_install("junit", tmp_path)

    out = capsys.readouterr().out
    assert "custom.md" in out
    assert "segurança" in out

def test_axetrules_sem_arquivo_preexistente_sem_backup(self, tmp_path):
    from hybris_test_skills.cli import cmd_install, _copy_axetrules, _JUNIT_AXETRULES
    had_backup = _copy_axetrules(_JUNIT_AXETRULES, tmp_path)
    assert had_backup is False
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_cli.py::TestInstallJunit::test_axetrules_arquivo_migrado_para_custom_md \
       tests/test_cli.py::TestInstallJunit::test_axetrules_arquivo_migrado_exibe_mensagem \
       tests/test_cli.py::TestInstallJunit::test_axetrules_sem_arquivo_preexistente_sem_backup -v
```

Expected: FAIL — `FileExistsError` (first two) and `TypeError` (terceiro, pois a função retorna `None`)

- [ ] **Step 3: Update `_copy_axetrules` in `cli.py`**

Replace lines 65-72:

```python
def _copy_axetrules(filenames: list, dest: Path) -> bool:
    src_dir = _resolve_axetrules_path()
    dst_dir = dest / ".axetrules"

    had_backup = False
    if dst_dir.exists() and not dst_dir.is_dir():
        content = dst_dir.read_text()
        dst_dir.unlink()
        dst_dir.mkdir(parents=True)
        (dst_dir / "custom.md").write_text(content)
        print("Arquivo .axetrules existente preservado como .axetrules/custom.md por segurança.")
        had_backup = True
    else:
        dst_dir.mkdir(parents=True, exist_ok=True)

    for fname in filenames:
        src = src_dir / fname
        if src.exists():
            shutil.copy2(src, dst_dir / fname)

    return had_backup
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_cli.py -v
```

Expected: todos os testes PASS (incluindo os já existentes)

- [ ] **Step 5: Commit**

```bash
git add src/hybris_test_skills/cli.py tests/test_cli.py
git commit -m "fix: _copy_axetrules migrates .axetrules file to directory, preserving content as custom.md"
```

---

## Task 3: Update `cmd_install` to write manifest and update `.gitignore`

**Files:**
- Modify: `src/hybris_test_skills/cli.py:47-55`
- Modify: `tests/test_cli.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_cli.py` inside `class TestInstallJunit`:

```python
def test_install_cria_manifesto(self, tmp_path):
    import json
    from hybris_test_skills.cli import cmd_install
    cmd_install("junit", tmp_path)
    manifest_file = tmp_path / ".hybris-install.json"
    assert manifest_file.exists()
    data = json.loads(manifest_file.read_text())
    assert data["module"] == "junit"
    assert "hybris-base" in data["skills"]
    assert "hybris-junit" in data["skills"]
    assert "commands.md" in data["axetrules"]
    assert data["axetrules_backup"] is False

def test_install_com_backup_registra_no_manifesto(self, tmp_path):
    import json
    from hybris_test_skills.cli import cmd_install
    (tmp_path / ".axetrules").write_text("regra antiga")
    cmd_install("junit", tmp_path)
    data = json.loads((tmp_path / ".hybris-install.json").read_text())
    assert data["axetrules_backup"] is True

def test_install_adiciona_manifesto_ao_gitignore(self, tmp_path):
    from hybris_test_skills.cli import cmd_install
    cmd_install("junit", tmp_path)
    gitignore = tmp_path / ".gitignore"
    assert gitignore.exists()
    assert ".hybris-install.json" in gitignore.read_text()

def test_install_nao_duplica_entrada_no_gitignore(self, tmp_path):
    from hybris_test_skills.cli import cmd_install
    # instala duas vezes
    cmd_install("junit", tmp_path)
    cmd_install("junit", tmp_path)
    gitignore = tmp_path / ".gitignore"
    count = gitignore.read_text().splitlines().count(".hybris-install.json")
    assert count == 1

def test_install_preserva_gitignore_existente(self, tmp_path):
    from hybris_test_skills.cli import cmd_install
    (tmp_path / ".gitignore").write_text("node_modules/\n.env\n")
    cmd_install("junit", tmp_path)
    content = (tmp_path / ".gitignore").read_text()
    assert "node_modules/" in content
    assert ".env" in content
    assert ".hybris-install.json" in content
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_cli.py::TestInstallJunit::test_install_cria_manifesto \
       tests/test_cli.py::TestInstallJunit::test_install_com_backup_registra_no_manifesto \
       tests/test_cli.py::TestInstallJunit::test_install_adiciona_manifesto_ao_gitignore \
       tests/test_cli.py::TestInstallJunit::test_install_nao_duplica_entrada_no_gitignore \
       tests/test_cli.py::TestInstallJunit::test_install_preserva_gitignore_existente -v
```

Expected: todos FAIL (`AssertionError` — `.hybris-install.json` e `.gitignore` não existem)

- [ ] **Step 3: Add import and `_ensure_gitignore`, update `cmd_install` in `cli.py`**

At the top of `cli.py`, after the existing imports, add:

```python
from hybris_test_skills import manifest
```

Add the new helper function before `cmd_install`:

```python
def _ensure_gitignore(dest: Path) -> None:
    entry = ".hybris-install.json"
    gitignore = dest / ".gitignore"
    if gitignore.exists():
        lines = gitignore.read_text().splitlines()
        if entry in lines:
            return
        gitignore.write_text(gitignore.read_text().rstrip("\n") + "\n" + entry + "\n")
    else:
        gitignore.write_text(entry + "\n")
```

Replace `cmd_install`:

```python
def cmd_install(module: str, dest: Path) -> None:
    if module == "cypress":
        print("Cypress module not available in this version. Coming soon in v1.0.0.")
        return

    _copy_skills(_JUNIT_SKILLS, dest)
    had_backup = _copy_axetrules(_JUNIT_AXETRULES, dest)
    manifest.write(dest, module, _JUNIT_SKILLS, _JUNIT_AXETRULES, had_backup, VERSION)
    _ensure_gitignore(dest)
    print(f"hybris-test-skills[{module}] installed in {dest}")
```

- [ ] **Step 4: Run all tests to verify they pass**

```bash
pytest tests/test_cli.py tests/test_manifest.py -v
```

Expected: todos PASS

- [ ] **Step 5: Commit**

```bash
git add src/hybris_test_skills/cli.py tests/test_cli.py
git commit -m "feat: cmd_install writes manifest and updates .gitignore"
```

---

## Task 4: Add `cmd_uninstall` — skill removal

**Files:**
- Modify: `src/hybris_test_skills/cli.py`
- Modify: `tests/test_cli.py`

- [ ] **Step 1: Write the failing tests**

Add a new class at the end of `tests/test_cli.py`:

```python
class TestUninstallSkills:
    def _install(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

    def test_remove_skills_instaladas(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / "skills" / "hybris-base").exists()
        assert not (tmp_path / "skills" / "hybris-junit").exists()

    def test_nao_remove_skills_do_usuario(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        # skill do usuário adicionada após o install
        user_skill = tmp_path / "skills" / "minha-skill"
        user_skill.mkdir()
        (user_skill / "SKILL.md").write_text("minha skill")
        cmd_uninstall(tmp_path)
        assert (tmp_path / "skills" / "minha-skill").exists()

    def test_remove_diretorio_skills_se_vazio(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / "skills").exists()

    def test_mantem_diretorio_skills_se_nao_vazio(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        user_skill = tmp_path / "skills" / "minha-skill"
        user_skill.mkdir()
        cmd_uninstall(tmp_path)
        assert (tmp_path / "skills").exists()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_cli.py::TestUninstallSkills -v
```

Expected: `ImportError: cannot import name 'cmd_uninstall'`

- [ ] **Step 3: Add `cmd_uninstall` to `cli.py` (skill removal only)**

Add after `cmd_install`:

```python
def cmd_uninstall(dest: Path) -> None:
    data = manifest.read(dest)
    if data is None:
        print(f"Nenhuma instalação encontrada em {dest}. Execute 'hybris install <module>' primeiro.")
        return

    removed_skills = []
    for name in data["skills"]:
        skill_dir = dest / "skills" / name
        if skill_dir.exists():
            shutil.rmtree(skill_dir)
            removed_skills.append(name)

    skills_dir = dest / "skills"
    if skills_dir.exists() and not any(skills_dir.iterdir()):
        skills_dir.rmdir()

    manifest.delete(dest)

    print(f"hybris-test-skills desinstalado de {dest}")
    if removed_skills:
        print(f"  skills removidas: {', '.join(removed_skills)}")
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_cli.py::TestUninstallSkills -v
```

Expected: todos 4 PASS

- [ ] **Step 5: Commit**

```bash
git add src/hybris_test_skills/cli.py tests/test_cli.py
git commit -m "feat: cmd_uninstall removes installed skills"
```

---

## Task 5: Add `cmd_uninstall` — axetrules removal and state resolution

**Files:**
- Modify: `src/hybris_test_skills/cli.py`
- Modify: `tests/test_cli.py`

- [ ] **Step 1: Write the failing tests**

Add a new class to `tests/test_cli.py`:

```python
class TestUninstallAxetrules:
    def _install(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

    def test_remove_arquivos_instalados(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / ".axetrules" / "commands.md").exists()
        assert not (tmp_path / ".axetrules" / "hybris-tests.md").exists()
        assert not (tmp_path / ".axetrules" / "hybris-tests-dev.md").exists()

    def test_nao_remove_arquivos_do_usuario(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        (tmp_path / ".axetrules" / "meu-arquivo.md").write_text("meu conteúdo")
        cmd_uninstall(tmp_path)
        assert (tmp_path / ".axetrules" / "meu-arquivo.md").exists()

    def test_remove_diretorio_se_vazio_sem_backup(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / ".axetrules").exists()

    def test_mantem_diretorio_se_nao_vazio_sem_backup(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        (tmp_path / ".axetrules" / "meu-arquivo.md").write_text("meu conteúdo")
        cmd_uninstall(tmp_path)
        assert (tmp_path / ".axetrules").is_dir()

    def test_restaura_arquivo_quando_vazio_com_backup(self, tmp_path):
        from hybris_test_skills.cli import cmd_install, cmd_uninstall
        # Simula workspace com .axetrules como arquivo (migração ocorre no install)
        (tmp_path / ".axetrules").write_text("regra original do usuário")
        cmd_install("junit", tmp_path)
        cmd_uninstall(tmp_path)
        axetrules = tmp_path / ".axetrules"
        assert axetrules.is_file()
        assert axetrules.read_text() == "regra original do usuário"

    def test_nao_restaura_arquivo_quando_nao_vazio_com_backup(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install, cmd_uninstall
        (tmp_path / ".axetrules").write_text("regra original")
        cmd_install("junit", tmp_path)
        # Usuário adiciona arquivo extra após o install
        (tmp_path / ".axetrules" / "extra.md").write_text("arquivo do usuário")
        cmd_uninstall(tmp_path)
        # Diretório deve permanecer (não foi possível restaurar)
        assert (tmp_path / ".axetrules").is_dir()
        # custom.md deve permanecer
        assert (tmp_path / ".axetrules" / "custom.md").exists()
        out = capsys.readouterr().out
        assert "não foi possível restaurar" in out.lower() or "custom.md" in out

    def test_remove_manifesto_ao_final(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / ".hybris-install.json").exists()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_cli.py::TestUninstallAxetrules -v
```

Expected: vários FAIL — axetrules não são removidos, diretório não é resolvido, restauração não ocorre

- [ ] **Step 3: Replace `cmd_uninstall` with the complete version in `cli.py`**

```python
def cmd_uninstall(dest: Path) -> None:
    data = manifest.read(dest)
    if data is None:
        print(f"Nenhuma instalação encontrada em {dest}. Execute 'hybris install <module>' primeiro.")
        return

    removed_skills = []
    for name in data["skills"]:
        skill_dir = dest / "skills" / name
        if skill_dir.exists():
            shutil.rmtree(skill_dir)
            removed_skills.append(name)

    skills_dir = dest / "skills"
    if skills_dir.exists() and not any(skills_dir.iterdir()):
        skills_dir.rmdir()

    axetrules_dir = dest / ".axetrules"
    removed_axetrules = []
    for fname in data["axetrules"]:
        fpath = axetrules_dir / fname
        if fpath.exists():
            fpath.unlink()
            removed_axetrules.append(fname)

    axetrules_status = ""
    has_backup = data.get("axetrules_backup", False)
    if axetrules_dir.exists():
        remaining = list(axetrules_dir.iterdir())
        if has_backup:
            other_files = [f for f in remaining if f.name != "custom.md"]
            if not other_files:
                custom = axetrules_dir / "custom.md"
                content = custom.read_text() if custom.exists() else ""
                shutil.rmtree(axetrules_dir)
                (dest / ".axetrules").write_text(content)
                axetrules_status = ".axetrules restaurado como arquivo"
            else:
                axetrules_status = (
                    "Aviso: .axetrules contém arquivos adicionais — não foi possível restaurar "
                    "o arquivo original. .axetrules/custom.md permanece no diretório."
                )
        else:
            if not remaining:
                shutil.rmtree(axetrules_dir)
            else:
                axetrules_status = ".axetrules mantido (contém arquivos adicionais)"

    manifest.delete(dest)

    print(f"hybris-test-skills desinstalado de {dest}")
    if removed_skills:
        print(f"  skills removidas: {', '.join(removed_skills)}")
    if removed_axetrules:
        print(f"  axetrules removidos: {', '.join(removed_axetrules)}")
    if axetrules_status:
        print(f"  {axetrules_status}")
```

- [ ] **Step 4: Run all tests to verify they pass**

```bash
pytest tests/test_cli.py tests/test_manifest.py -v
```

Expected: todos PASS

- [ ] **Step 5: Commit**

```bash
git add src/hybris_test_skills/cli.py tests/test_cli.py
git commit -m "feat: cmd_uninstall removes axetrules and resolves directory state"
```

---

## Task 6: Wire `uninstall` into the CLI parser

**Files:**
- Modify: `src/hybris_test_skills/cli.py:96-118`
- Modify: `tests/test_cli.py`

- [ ] **Step 1: Write the failing tests**

Add a new class to `tests/test_cli.py`:

```python
class TestUninstallCLI:
    def test_uninstall_sem_manifesto_exibe_erro(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_uninstall
        cmd_uninstall(tmp_path)
        out = capsys.readouterr().out
        assert "nenhuma instalação encontrada" in out.lower()

    def test_uninstall_exibe_resumo(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install, cmd_uninstall
        cmd_install("junit", tmp_path)
        capsys.readouterr()  # descarta output do install
        cmd_uninstall(tmp_path)
        out = capsys.readouterr().out
        assert "desinstalado" in out.lower()
        assert "hybris-base" in out
        assert "hybris-junit" in out
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_cli.py::TestUninstallCLI -v
```

Expected: FAIL — `cmd_uninstall` existe mas o segundo teste falha pois "desinstalado" pode não estar na saída com o estado atual

Note: se ambos passarem, o wiring está correto e você pode pular o Step 3 direto para o Step 4.

- [ ] **Step 3: Add `uninstall` subcommand to `main()` in `cli.py`**

Replace the `main()` function:

```python
def main() -> None:
    parser = argparse.ArgumentParser(
        prog="hybris",
        description="SAP Commerce test skills installer",
    )
    sub = parser.add_subparsers(dest="command")

    install_p = sub.add_parser("install", help="Install skills into current workspace")
    install_p.add_argument("module", choices=["junit", "cypress", "all"])

    sub.add_parser("list", help="List available modules")
    sub.add_parser("version", help="Show installed version")
    sub.add_parser("uninstall", help="Uninstall skills from current workspace")

    args = parser.parse_args()

    if args.command == "install":
        cmd_install(args.module, Path.cwd())
    elif args.command == "list":
        cmd_list(Path.cwd())
    elif args.command == "version":
        cmd_version()
    elif args.command == "uninstall":
        cmd_uninstall(Path.cwd())
    else:
        parser.print_help()
```

- [ ] **Step 4: Run all tests**

```bash
pytest tests/ -v
```

Expected: todos PASS

- [ ] **Step 5: Commit**

```bash
git add src/hybris_test_skills/cli.py tests/test_cli.py
git commit -m "feat: add 'hybris uninstall' subcommand to CLI"
```
