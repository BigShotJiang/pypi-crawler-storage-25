"""Testes para a CLI hybris install/list/version."""
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestInstallJunit:
    def test_copia_axetrules_dev(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / ".axetrules" / "commands.md").exists()
        assert (tmp_path / ".axetrules" / "hybris-tests.md").exists()
        assert (tmp_path / ".axetrules" / "hybris-tests-dev.md").exists()

    def test_nao_copia_axetrules_arch(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert not (tmp_path / ".axetrules" / "hybris-tests-arch.md").exists()

    def test_copia_skill_base(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-base" / "SKILL.md").exists()

    def test_copia_skill_junit(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "SKILL.md").exists()

    def test_copia_scripts_junit(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "scripts" / "parse_java_class.py").exists()
        assert (tmp_path / "skills" / "hybris-junit" / "scripts" / "run-junit.sh").exists()

    def test_copia_scripts_base(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-base" / "scripts" / "check_environment.py").exists()

    def test_nao_copia_cypress(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert not (tmp_path / "skills" / "spartacus-cypress").exists()
        assert not (tmp_path / "skills" / "accelerator-jsp-cypress").exists()

    def test_axetrules_arquivo_migrado_para_custom_md(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        # Cria .axetrules como arquivo (formato antigo do axet)
        axetrules_file = tmp_path / ".axetrules"
        axetrules_file.write_text("regra personalizada do usuário")

        cmd_install("junit", tmp_path)

        assert (tmp_path / ".axetrules").is_dir()
        assert (tmp_path / ".axetrules" / "custom.md").exists()
        assert (tmp_path / ".axetrules" / "custom.md").read_text() == "regra personalizada do usuário"

    def test_axetrules_arquivo_migrado_exibe_mensagem(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install
        axetrules_file = tmp_path / ".axetrules"
        axetrules_file.write_text("conteúdo")

        cmd_install("junit", tmp_path)

        out = capsys.readouterr().out
        assert "! Existing .axetrules preserved as .axetrules/custom.md" in out

    def test_axetrules_sem_arquivo_preexistente_sem_backup(self, tmp_path):
        from hybris_test_skills.cli import _copy_axetrules, _JUNIT_AXETRULES
        had_backup = _copy_axetrules(_JUNIT_AXETRULES, tmp_path)
        assert had_backup is False

    def test_install_cria_manifesto(self, tmp_path):
        import json
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)
        manifest_file = tmp_path / ".hybris-install.json"
        assert manifest_file.exists()
        data = json.loads(manifest_file.read_text())
        assert data["module"] == "junit"
        assert "hybris-base" in data["skills"]
        assert "hybris-junit" in data["skills"]
        assert "commands.md" in data["axetrules"]
        assert data["axetrules_backup"] is False

    def test_install_com_backup_registra_no_manifesto(self, tmp_path):
        import json
        from hybris_test_skills.cli import cmd_install
        (tmp_path / ".axetrules").write_text("regra antiga")
        cmd_install("junit", tmp_path)
        data = json.loads((tmp_path / ".hybris-install.json").read_text())
        assert data["axetrules_backup"] is True

    def test_install_adiciona_manifesto_ao_gitignore(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)
        gitignore = tmp_path / ".gitignore"
        assert gitignore.exists()
        assert ".hybris-install.json" in gitignore.read_text()

    def test_install_nao_duplica_entrada_no_gitignore(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        # instala duas vezes
        cmd_install("junit", tmp_path)
        cmd_install("junit", tmp_path)
        gitignore = tmp_path / ".gitignore"
        count = gitignore.read_text().splitlines().count(".hybris-install.json")
        assert count == 1

    def test_install_preserva_gitignore_existente(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        (tmp_path / ".gitignore").write_text("node_modules/\n.env\n")
        cmd_install("junit", tmp_path)
        content = (tmp_path / ".gitignore").read_text()
        assert "node_modules/" in content
        assert ".env" in content
        assert ".hybris-install.json" in content


class TestInstallCypress:
    def test_exibe_coming_soon(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install
        cmd_install("cypress", tmp_path)

        out = capsys.readouterr().out
        assert "coming soon" in out.lower()

    def test_nao_cria_arquivos(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("cypress", tmp_path)

        assert not (tmp_path / "skills").exists()


class TestInstallAll:
    def test_all_instala_junit_na_fase1(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("all", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "SKILL.md").exists()


class TestVersion:
    def test_exibe_versao(self, capsys):
        from hybris_test_skills.cli import cmd_version
        cmd_version()

        out = capsys.readouterr().out
        assert "0.1.0" in out


class TestList:
    def test_exibe_modulos_disponiveis(self, capsys):
        from hybris_test_skills.cli import cmd_list
        cmd_list(Path("."))

        out = capsys.readouterr().out
        assert "junit" in out
        assert "cypress" in out


class TestUninstallSkills:
    def _install(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

    def test_remove_skills_instaladas(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / "skills" / "hybris-base").exists()
        assert not (tmp_path / "skills" / "hybris-junit").exists()

    def test_nao_remove_skills_do_usuario(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        # skill do usuário adicionada após o install
        user_skill = tmp_path / "skills" / "minha-skill"
        user_skill.mkdir()
        (user_skill / "SKILL.md").write_text("minha skill")
        cmd_uninstall(tmp_path)
        assert (tmp_path / "skills" / "minha-skill").exists()

    def test_remove_diretorio_skills_se_vazio(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / "skills").exists()

    def test_mantem_diretorio_skills_se_nao_vazio(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        user_skill = tmp_path / "skills" / "minha-skill"
        user_skill.mkdir()
        cmd_uninstall(tmp_path)
        assert (tmp_path / "skills").exists()


class TestUninstallAxetrules:
    def _install(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

    def test_remove_arquivos_instalados(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / ".axetrules" / "commands.md").exists()
        assert not (tmp_path / ".axetrules" / "hybris-tests.md").exists()
        assert not (tmp_path / ".axetrules" / "hybris-tests-dev.md").exists()

    def test_nao_remove_arquivos_do_usuario(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        (tmp_path / ".axetrules" / "meu-arquivo.md").write_text("meu conteúdo")
        cmd_uninstall(tmp_path)
        assert (tmp_path / ".axetrules" / "meu-arquivo.md").exists()

    def test_remove_diretorio_se_vazio_sem_backup(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / ".axetrules").exists()

    def test_mantem_diretorio_se_nao_vazio_sem_backup(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        (tmp_path / ".axetrules" / "meu-arquivo.md").write_text("meu conteúdo")
        cmd_uninstall(tmp_path)
        assert (tmp_path / ".axetrules").is_dir()

    def test_mantem_diretorio_se_nao_vazio_sem_backup_exibe_mensagem(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        (tmp_path / ".axetrules" / "meu-arquivo.md").write_text("meu conteúdo")
        cmd_uninstall(tmp_path)
        out = capsys.readouterr().out
        assert "directory kept" in out.lower()

    def test_restaura_arquivo_quando_vazio_com_backup(self, tmp_path):
        from hybris_test_skills.cli import cmd_install, cmd_uninstall
        # Simula workspace com .axetrules como arquivo (migração ocorre no install)
        (tmp_path / ".axetrules").write_text("regra original do usuário")
        cmd_install("junit", tmp_path)
        cmd_uninstall(tmp_path)
        axetrules = tmp_path / ".axetrules"
        assert axetrules.is_file()
        assert axetrules.read_text() == "regra original do usuário"

    def test_restaura_arquivo_exibe_mensagem(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install, cmd_uninstall
        (tmp_path / ".axetrules").write_text("regra original do usuário")
        cmd_install("junit", tmp_path)
        capsys.readouterr()
        cmd_uninstall(tmp_path)
        out = capsys.readouterr().out
        assert "restored as file" in out.lower()

    def test_nao_restaura_arquivo_quando_nao_vazio_com_backup(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install, cmd_uninstall
        (tmp_path / ".axetrules").write_text("regra original")
        cmd_install("junit", tmp_path)
        # Usuário adiciona arquivo extra após o install
        (tmp_path / ".axetrules" / "extra.md").write_text("arquivo do usuário")
        cmd_uninstall(tmp_path)
        # Diretório deve permanecer (não foi possível restaurar)
        assert (tmp_path / ".axetrules").is_dir()
        # custom.md deve permanecer
        assert (tmp_path / ".axetrules" / "custom.md").exists()
        out = capsys.readouterr().out
        assert "could not restore" in out.lower()

    def test_remove_manifesto_ao_final(self, tmp_path):
        from hybris_test_skills.cli import cmd_uninstall
        self._install(tmp_path)
        cmd_uninstall(tmp_path)
        assert not (tmp_path / ".hybris-install.json").exists()


class TestUninstallCLI:
    def test_uninstall_sem_manifesto_exibe_erro(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_uninstall
        cmd_uninstall(tmp_path)
        out = capsys.readouterr().out
        assert "no installation found" in out.lower()

    def test_uninstall_manifesto_corrompido_exibe_erro(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_uninstall
        (tmp_path / ".hybris-install.json").write_text("{ invalid }")
        cmd_uninstall(tmp_path)
        out = capsys.readouterr().out
        assert "corrupted" in out.lower()

    def test_uninstall_exibe_resumo(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install, cmd_uninstall
        cmd_install("junit", tmp_path)
        capsys.readouterr()  # descarta output do install
        cmd_uninstall(tmp_path)
        out = capsys.readouterr().out
        assert "removed skills" in out.lower()
        assert "hybris-base" in out
        assert "hybris-junit" in out
