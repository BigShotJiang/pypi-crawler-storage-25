"""Testes para test-healer.py — diagnóstico estruturado de erros JUnit."""
import importlib.util
from pathlib import Path

HEALER_PATH = Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts" / "test-healer.py"


def load_healer():
    spec = importlib.util.spec_from_file_location("test_healer", HEALER_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TestEarlyExit:
    def test_environment_error_stops_loop(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "testClass": "com.example.FooTest",
            "errorType": "environment",
            "error": "ant não encontrado.",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["shouldContinue"] is False
        assert result["errorType"] == "environment"

    def test_max_iterations_stops_loop(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "testClass": "com.example.FooTest",
            "error": "cannot find symbol",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=3)
        assert result["shouldContinue"] is False
        assert result["errorType"] == "max_iterations"

    def test_iteration_below_max_continues(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "testClass": "com.example.FooTest",
            "error": "cannot find symbol",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["shouldContinue"] is True

    def test_output_always_includes_required_fields(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "testClass": "com.example.FooTest",
            "errorType": "environment",
            "error": "ant não encontrado.",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        for field in ("shouldContinue", "iteration", "maxIterations", "errorType", "suggestion", "rawError"):
            assert field in result, f"Campo ausente: {field}"


class TestCompileAndSyntaxErrors:
    def test_classifies_cannot_find_symbol_as_compile_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:42: error: cannot find symbol\n  symbol:   class AraucoCashbackModel",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "compile_error"
        assert result["shouldContinue"] is True

    def test_extracts_line_number_from_compile_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:42: error: cannot find symbol\n  symbol:   class AraucoCashbackModel",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["affectedLine"] == 42

    def test_extracts_symbol_from_compile_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:42: error: cannot find symbol\n  symbol:   class AraucoCashbackModel",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["affectedSymbol"] == "AraucoCashbackModel"

    def test_suggestion_mentions_import_for_symbol(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:10: error: cannot find symbol\n  symbol:   class MyModel",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert "import" in result["suggestion"].lower() or "MyModel" in result["suggestion"]

    def test_classifies_package_not_exist_as_compile_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:3: error: package de.hybris.platform.foo does not exist",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "compile_error"
        assert "extensioninfo" in result["suggestion"].lower()

    def test_classifies_insert_brace_as_syntax_error(self):
        healer = load_healer()
        run_junit_json = {
            "status": "ERROR",
            "error": "FooTest.java:328: error: reached end of file while parsing\n insert } to complete ClassBody",
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "syntax_error"
        assert "brace" in result["suggestion"].lower() or "}" in result["suggestion"]


class TestAssertionFail:
    def test_classifies_fail_status_as_assertion_fail(self):
        healer = load_healer()
        run_junit_json = {
            "status": "FAIL",
            "testClass": "com.example.FooTest",
            "testsRun": 3,
            "testsFailed": 1,
            "failures": [
                {
                    "testMethod": "shouldReturnCashback",
                    "errorType": "assertion_fail",
                    "message": "expected:<10.0> but was:<0.0>",
                    "stackTrace": "at com.example.FooTest.shouldReturnCashback(FooTest.java:55)",
                    "line": 55,
                }
            ],
            "durationMs": 120,
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "assertion_fail"
        assert result["shouldContinue"] is True

    def test_suggestion_includes_failure_message(self):
        healer = load_healer()
        run_junit_json = {
            "status": "FAIL",
            "testClass": "com.example.FooTest",
            "testsRun": 1,
            "testsFailed": 1,
            "failures": [
                {
                    "testMethod": "shouldReturnCashback",
                    "errorType": "assertion_fail",
                    "message": "expected:<10.0> but was:<0.0>",
                    "stackTrace": "at FooTest.java:55",
                    "line": 55,
                }
            ],
            "durationMs": 80,
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert "expected:<10.0> but was:<0.0>" in result["suggestion"]

    def test_suggestion_fallback_when_no_failures_array(self):
        healer = load_healer()
        run_junit_json = {
            "status": "FAIL",
            "testClass": "com.example.FooTest",
            "testsRun": 1,
            "testsFailed": 1,
            "failures": [],
            "durationMs": 50,
        }
        result = healer.build_diagnosis(run_junit_json, iteration=1)
        assert result["errorType"] == "assertion_fail"
        assert result["suggestion"]
