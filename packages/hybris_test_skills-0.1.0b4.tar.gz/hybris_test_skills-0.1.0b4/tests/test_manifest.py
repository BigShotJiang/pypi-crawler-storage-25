"""Testes para manifest.py."""
import json
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestManifestWrite:
    def test_cria_arquivo_json(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base"], ["commands.md"], False, "0.1.0b3")
        assert (tmp_path / ".hybris-install.json").exists()

    def test_conteudo_correto(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base", "hybris-junit"],
                       ["commands.md", "hybris-tests.md"], True, "0.1.0b3")
        data = json.loads((tmp_path / ".hybris-install.json").read_text())
        assert data["module"] == "junit"
        assert data["skills"] == ["hybris-base", "hybris-junit"]
        assert data["axetrules"] == ["commands.md", "hybris-tests.md"]
        assert data["axetrules_backup"] is True
        assert data["version"] == "0.1.0b3"
        assert "installed_at" in data

    def test_sobrescreve_manifesto_existente(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base"], ["commands.md"], False, "0.1.0b1")
        manifest.write(tmp_path, "all",   ["hybris-base"], ["commands.md"], True,  "0.1.0b3")
        data = json.loads((tmp_path / ".hybris-install.json").read_text())
        assert data["module"] == "all"
        assert data["version"] == "0.1.0b3"


class TestManifestRead:
    def test_retorna_dict_quando_existe(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base"], ["commands.md"], False, "0.1.0b3")
        data = manifest.read(tmp_path)
        assert data is not None
        assert data["module"] == "junit"

    def test_retorna_none_quando_nao_existe(self, tmp_path):
        from hybris_test_skills import manifest
        assert manifest.read(tmp_path) is None

    def test_levanta_value_error_se_corrompido(self, tmp_path):
        from hybris_test_skills import manifest
        (tmp_path / ".hybris-install.json").write_text("{ invalid json }")
        with pytest.raises(ValueError, match="corrompido|corrupted"):
            manifest.read(tmp_path)


class TestManifestDelete:
    def test_remove_arquivo(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.write(tmp_path, "junit", ["hybris-base"], ["commands.md"], False, "0.1.0b3")
        manifest.delete(tmp_path)
        assert not (tmp_path / ".hybris-install.json").exists()

    def test_nao_falha_se_nao_existe(self, tmp_path):
        from hybris_test_skills import manifest
        manifest.delete(tmp_path)  # não deve lançar exceção
