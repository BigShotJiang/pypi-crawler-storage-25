"""Testes de integração para run-junit.sh."""
import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).parent.parent
SCRIPT = PROJECT_ROOT / "skills" / "hybris-junit" / "scripts" / "run-junit.sh"


def run_junit(test_class: str, cwd: Path, extra_env: dict | None = None) -> dict:
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    result = subprocess.run(
        ["bash", str(SCRIPT), test_class],
        capture_output=True, text=True, env=env, cwd=str(cwd)
    )
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        pytest.fail(
            f"Non-JSON stdout (rc={result.returncode}):\n{result.stdout!r}\nstderr:\n{result.stderr!r}"
        )


def make_testsrc_file(base: Path, pkg: str, class_name: str, annotation: str = "@UnitTest") -> Path:
    """Cria <base>/myext/testsrc/<pkg_as_path>/<class_name>.java com anotação."""
    pkg_path = base / "myext" / "testsrc" / Path(*pkg.split("."))
    pkg_path.mkdir(parents=True, exist_ok=True)
    java_file = pkg_path / f"{class_name}.java"
    java_file.write_text(
        f"package {pkg};\n{annotation}\npublic class {class_name} {{}}\n"
    )
    return java_file


class TestFindTestFile:
    def test_finds_file_in_testsrc(self, tmp_path):
        # Arquivo em testsrc/ — deve ser encontrado
        make_testsrc_file(tmp_path, "com.example", "FooTest")
        output = run_junit("com.example.FooTest", tmp_path)
        # Se o arquivo não for encontrado, o erro seria "FooTest.java not found under src/test/"
        # Qualquer outro erro (ant, ambiente) significa que o arquivo foi encontrado
        error = output.get("error", "")
        assert "FooTest.java not found" not in error, (
            f"File was not found in testsrc/ — find patch may be broken. Full output: {output}"
        )

    def test_error_message_mentions_testsrc_when_file_missing(self, tmp_path):
        # Sem nenhum arquivo — erro deve mencionar testsrc
        output = run_junit("com.example.MissingTest", tmp_path)
        assert output["status"] == "ERROR"
        assert "MissingTest.java not found" in output["error"]
        assert "testsrc" in output["error"]


class TestAntValidation:
    def test_returns_environment_error_when_ant_not_in_path(self, tmp_path):
        make_testsrc_file(tmp_path, "com.example", "FooTest")
        # PATH restrito a utilitários básicos — ant geralmente não está em /usr/bin ou /bin
        restricted_path = "/usr/bin:/bin"
        if shutil.which("ant", path=restricted_path):
            pytest.skip("ant está em /usr/bin ou /bin — não é possível isolar PATH neste ambiente")
        output = run_junit(
            "com.example.FooTest", tmp_path,
            extra_env={"PATH": restricted_path, "HYBRIS_HOME": str(tmp_path)}
        )
        assert output["status"] == "ERROR"
        assert output.get("errorType") == "environment", (
            f"Expected errorType='environment' but got: {output}"
        )
        assert "ant" in output["error"].lower(), (
            f"Expected 'ant' in error message but got: {output['error']}"
        )


class TestAntViaSetantenv:
    def test_finds_ant_via_setantenv_when_not_in_global_path(self, tmp_path):
        platform_dir = tmp_path / "hybris" / "bin" / "platform"
        platform_dir.mkdir(parents=True)

        # fake ant inside platform_dir/ant_bin/ — only reachable via $PWD-relative PATH
        # when setantenv.sh is sourced from platform_dir (the pushd fix)
        ant_bin_dir = platform_dir / "ant_bin"
        ant_bin_dir.mkdir()
        ant_bin = ant_bin_dir / "ant"
        ant_bin.write_text("#!/bin/bash\necho 'Apache Ant(TM) version 1.10.15'\nexit 0\n")
        ant_bin.chmod(0o755)

        # setantenv.sh uses $PWD (current dir at source time) to build the PATH
        # works only when sourced from platform_dir/
        setantenv = platform_dir / "setantenv.sh"
        setantenv.write_text("export PATH=\"$PWD/ant_bin:$PATH\"\n")

        make_testsrc_file(tmp_path, "com.example", "FooTest")

        restricted_path = "/usr/bin:/bin"
        if shutil.which("ant", path=restricted_path):
            pytest.skip("ant está em /usr/bin ou /bin — não é possível isolar PATH neste ambiente")

        output = run_junit(
            "com.example.FooTest", tmp_path,
            extra_env={
                "PATH": restricted_path,
                "HYBRIS_HOME": str(tmp_path / "hybris"),
            }
        )
        assert output.get("errorType") != "environment", (
            f"run-junit.sh retornou errorType=environment mesmo com setantenv.sh disponível — "
            f"o pushd/popd fix pode não ter sido aplicado corretamente: {output}"
        )
