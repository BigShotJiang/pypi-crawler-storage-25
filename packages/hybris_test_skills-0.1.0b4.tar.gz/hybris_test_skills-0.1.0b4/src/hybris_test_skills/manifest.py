"""Registro de instalação do hybris-test-skills no workspace."""
import json
from datetime import datetime
from pathlib import Path

MANIFEST_FILE = ".hybris-install.json"


def write(
    dest: Path,
    module: str,
    skills: list,
    axetrules: list,
    axetrules_backup: bool,
    version: str,
) -> None:
    data = {
        "version": version,
        "installed_at": datetime.now().isoformat(timespec="seconds"),
        "module": module,
        "skills": skills,
        "axetrules": axetrules,
        "axetrules_backup": axetrules_backup,
    }
    (dest / MANIFEST_FILE).write_text(json.dumps(data, indent=2))


def read(dest: Path) -> dict | None:
    path = dest / MANIFEST_FILE
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise ValueError(f"Manifest corrupted at {path}: {exc}") from exc


def delete(dest: Path) -> None:
    path = dest / MANIFEST_FILE
    if path.exists():
        path.unlink()
