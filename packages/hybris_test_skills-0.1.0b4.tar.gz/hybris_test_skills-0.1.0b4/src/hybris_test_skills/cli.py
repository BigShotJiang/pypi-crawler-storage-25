"""CLI hybris — instala skills de teste SAP Commerce no workspace."""
import argparse
import shutil
from pathlib import Path

from hybris_test_skills import manifest

VERSION = "0.1.0b4"

_PKG_DATA = Path(__file__).parent / "_data"

# Mapping of skill name (as used in dest) to _data subdirectory (installed mode)
_SKILL_DATA_SUBDIR = {
    "hybris-base": "base",
    "hybris-junit": "junit",
}


def _is_installed_mode() -> bool:
    """Return True when the package was installed (wheel) and _data/ exists."""
    return _PKG_DATA.exists()


def _repo_root() -> Path:
    """Return the repo root (three levels up from cli.py inside src/hybris_test_skills/)."""
    return Path(__file__).parent.parent.parent


def _resolve_skill_path(key: str) -> Path:
    """Resolve the source path for a skill in both installed and dev modes."""
    if _is_installed_mode():
        subdir = _SKILL_DATA_SUBDIR.get(key, key)
        return _PKG_DATA / subdir
    # Dev mode: read directly from skills/ in the repo
    return _repo_root() / "skills" / key


def _resolve_axetrules_path() -> Path:
    """Resolve the source .axetrules directory."""
    if _is_installed_mode():
        return _PKG_DATA / "axetrules"
    return _repo_root() / ".axetrules"


_JUNIT_SKILLS = ["hybris-base", "hybris-junit"]
_JUNIT_AXETRULES = ["commands.md", "hybris-tests.md", "hybris-tests-dev.md"]


def _ensure_gitignore(dest: Path) -> None:
    entry = ".hybris-install.json"
    gitignore = dest / ".gitignore"
    if gitignore.exists():
        existing = gitignore.read_text()
        if entry in existing.splitlines():
            return
        gitignore.write_text(existing.rstrip("\n") + "\n" + entry + "\n")
    else:
        gitignore.write_text(entry + "\n")


def cmd_install(module: str, dest: Path) -> None:
    if module == "cypress":
        print("  ! Cypress module not available in this version. Coming soon in v1.0.0.")
        return

    # Phase 1: both "junit" and "all" install the junit bundle
    _copy_skills(_JUNIT_SKILLS, dest)
    had_backup = _copy_axetrules(_JUNIT_AXETRULES, dest)
    manifest.write(dest, module, _JUNIT_SKILLS, _JUNIT_AXETRULES, had_backup, VERSION)
    _ensure_gitignore(dest)
    print(f"  ✓ hybris-test-skills[{module}] installed in {dest}")


def cmd_uninstall(dest: Path) -> None:
    try:
        data = manifest.read(dest)
    except ValueError as exc:
        print(f"  ✗ Corrupted manifest at {dest}: {exc}")
        return
    if data is None:
        print(f"  ✗ No installation found in {dest}. Run 'hybris install <module>' first.")
        return

    removed_skills = []
    for name in data["skills"]:
        skill_dir = dest / "skills" / name
        if skill_dir.exists():
            shutil.rmtree(skill_dir)
            removed_skills.append(name)

    skills_dir = dest / "skills"
    if skills_dir.exists() and not any(skills_dir.iterdir()):
        skills_dir.rmdir()

    axetrules_dir = dest / ".axetrules"
    removed_axetrules = []
    for fname in data["axetrules"]:
        fpath = axetrules_dir / fname
        if fpath.exists():
            fpath.unlink()
            removed_axetrules.append(fname)

    axetrules_status = ""
    has_backup = data.get("axetrules_backup", False)
    if axetrules_dir.exists():
        remaining = list(axetrules_dir.iterdir())
        if has_backup:
            other_files = [f for f in remaining if f.name != "custom.md"]
            if not other_files:
                custom = axetrules_dir / "custom.md"
                content = custom.read_text() if custom.exists() else ""
                shutil.rmtree(axetrules_dir)
                (dest / ".axetrules").write_text(content)
                axetrules_status = "✓ .axetrules restored as file"
            else:
                axetrules_status = (
                    "! .axetrules has additional files — could not restore original. "
                    ".axetrules/custom.md preserved."
                )
        else:
            if not remaining:
                shutil.rmtree(axetrules_dir)
            else:
                axetrules_status = "! .axetrules has additional files — directory kept as-is."

    manifest.delete(dest)

    if removed_skills:
        print(f"  ✓ Removed skills: {', '.join(removed_skills)}")
    if removed_axetrules:
        print(f"  ✓ Removed axetrules: {', '.join(removed_axetrules)}")
    if axetrules_status:
        print(f"  {axetrules_status}")


def _copy_skills(skill_names: list, dest: Path) -> None:
    skills_dest = dest / "skills"
    for name in skill_names:
        src = _resolve_skill_path(name)
        _copy_tree(src, skills_dest / name)


def _copy_axetrules(filenames: list, dest: Path) -> bool:
    src_dir = _resolve_axetrules_path()
    dst_dir = dest / ".axetrules"

    had_backup = False
    if dst_dir.exists() and not dst_dir.is_dir():
        content = dst_dir.read_text()
        dst_dir.unlink()
        dst_dir.mkdir(parents=True)
        (dst_dir / "custom.md").write_text(content)
        print("  ! Existing .axetrules preserved as .axetrules/custom.md")
        had_backup = True
    else:
        dst_dir.mkdir(parents=True, exist_ok=True)

    for fname in filenames:
        src = src_dir / fname
        if src.exists():
            shutil.copy2(src, dst_dir / fname)

    return had_backup


def _copy_tree(src: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        target = dest / item.name
        if item.is_dir():
            _copy_tree(item, target)
        else:
            shutil.copy2(item, target)


def cmd_list(_dest: Path) -> None:
    print("Available modules:")
    print("  junit   — JUnit test generation skills (hybris-base + hybris-junit)")
    print("  cypress — Cypress E2E skills [coming soon in v1.0.0]")
    print("  all     — All modules [Phase 1: installs junit]")


def cmd_version() -> None:
    print(f"hybris-test-skills {VERSION}")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="hybris",
        description="SAP Commerce test skills installer",
    )
    sub = parser.add_subparsers(dest="command")

    install_p = sub.add_parser("install", help="Install skills into current workspace")
    install_p.add_argument("module", choices=["junit", "cypress", "all"])

    sub.add_parser("list", help="List available modules")
    sub.add_parser("version", help="Show installed version")
    sub.add_parser("uninstall", help="Uninstall skills from current workspace")

    args = parser.parse_args()

    if args.command == "install":
        cmd_install(args.module, Path.cwd())
    elif args.command == "list":
        cmd_list(Path.cwd())
    elif args.command == "version":
        cmd_version()
    elif args.command == "uninstall":
        cmd_uninstall(Path.cwd())
    else:
        parser.print_help()
