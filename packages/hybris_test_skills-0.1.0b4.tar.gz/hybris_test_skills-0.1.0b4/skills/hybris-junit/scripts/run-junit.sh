#!/usr/bin/env bash
# run-junit.sh — executa JUnit para uma classe e retorna JSON estruturado
# Input:  fully-qualified class name (ex: com.ntt.myextension.populators.DefaultProductPopulatorTest)
# Output: JSON com status, testsRun, testsPassed, testsFailed, failures[], durationMs
#
# Requer: HYBRIS_HOME apontando para raiz do Hybris (default: ./hybris),
#         ant disponível via PATH ou via $HYBRIS_HOME/bin/platform/setantenv.sh,
#         xmllint (libxml2-utils) para parse do Surefire XML

set -uo pipefail

HYBRIS_HOME="${HYBRIS_HOME:-hybris}"
PLATFORM_DIR="${HYBRIS_HOME}/bin/platform"

# Garante que ant está no PATH via setantenv.sh do hybris
SETANTENV="${PLATFORM_DIR}/setantenv.sh"
if [ -f "$SETANTENV" ]; then
    set +u  # setantenv.sh pode referenciar variáveis não definidas
    # shellcheck source=/dev/null
    if pushd "$PLATFORM_DIR" > /dev/null 2>&1; then
        . ./setantenv.sh > /dev/null 2>&1
        popd > /dev/null 2>&1
    fi
    set -u
fi

if [ $# -lt 1 ]; then
    echo '{"status":"ERROR","error":"Usage: run-junit.sh <fully.qualified.TestClassName>"}'
    exit 1
fi

CLASS_NAME="$1"
SIMPLE_NAME="${CLASS_NAME##*.}"

# Localiza o arquivo de teste
TEST_FILE=$(find . -name "${SIMPLE_NAME}.java" \
    \( -path "*/testsrc/*" -o -path "*/src/test/*" \) \
    2>/dev/null | head -1)

if [ -z "$TEST_FILE" ]; then
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"error\":\"File ${SIMPLE_NAME}.java not found under testsrc/ or src/test/\"}"
    exit 1
fi

if ! command -v ant &>/dev/null; then
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"errorType\":\"environment\",\"error\":\"ant não encontrado. Configure HYBRIS_HOME e execute setantenv.sh antes de rodar este script.\"}"
    exit 1
fi

# Detecta anotação para escolher ant target
if grep -q "@IntegrationTest" "$TEST_FILE"; then
    ANT_TARGET="integrationtests"
elif grep -q "@UnitTest" "$TEST_FILE"; then
    ANT_TARGET="unittests"
else
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"error\":\"No @UnitTest or @IntegrationTest annotation in ${SIMPLE_NAME}.java\"}"
    exit 1
fi

# Executa ant e captura output
START_MS=$(date +%s%3N)
cd "$PLATFORM_DIR" && ant "$ANT_TARGET" -Dtestclasses.single="$CLASS_NAME" > /tmp/junit_run_output.txt 2>&1 || true
END_MS=$(date +%s%3N)
DURATION=$((END_MS - START_MS))

# Localiza Surefire XML gerado
SUREFIRE_XML=$(find . -name "${SIMPLE_NAME}.xml" -path "*/surefire-reports/*" 2>/dev/null | head -1)

if [ -z "$SUREFIRE_XML" ]; then
    ERROR_MSG=$(grep -E "BUILD FAILED|error:|Error" /tmp/junit_run_output.txt | head -3 | tr '\n' ' ' | sed 's/"/\\"/g')
    echo "{\"status\":\"ERROR\",\"testClass\":\"${CLASS_NAME}\",\"error\":\"Build failed: ${ERROR_MSG}\",\"durationMs\":${DURATION}}"
    exit 1
fi

# Extrai métricas do Surefire XML com xmllint
TESTS=$(xmllint --xpath "string(/testsuite/@tests)" "$SUREFIRE_XML" 2>/dev/null || echo "0")
FAILURES=$(xmllint --xpath "string(/testsuite/@failures)" "$SUREFIRE_XML" 2>/dev/null || echo "0")
ERRORS=$(xmllint --xpath "string(/testsuite/@errors)" "$SUREFIRE_XML" 2>/dev/null || echo "0")
TOTAL_FAIL=$((FAILURES + ERRORS))
PASSED=$((TESTS - TOTAL_FAIL))

STATUS="PASS"
if [ "$TOTAL_FAIL" -gt 0 ]; then
    STATUS="FAIL"
fi

# Gera array JSON de falhas via python3
FAIL_JSON=$(python3 -c "
import sys, json
from lxml import etree
try:
    tree = etree.parse('${SUREFIRE_XML}')
    failures = []
    for tc in tree.findall('.//testcase'):
        for tag in ('failure', 'error'):
            el = tc.find(tag)
            if el is not None:
                failures.append({
                    'testMethod': tc.get('name', ''),
                    'errorType': 'assertion_fail' if tag == 'failure' else 'compile_error',
                    'message': (el.get('message') or '')[:300],
                    'stackTrace': (el.text or '')[:500],
                    'line': 0
                })
    print(json.dumps(failures))
except Exception:
    print('[]')
" 2>/dev/null || echo "[]")

echo "{\"status\":\"${STATUS}\",\"testClass\":\"${CLASS_NAME}\",\"testsRun\":${TESTS},\"testsPassed\":${PASSED},\"testsFailed\":${TOTAL_FAIL},\"failures\":${FAIL_JSON},\"durationMs\":${DURATION}}"
