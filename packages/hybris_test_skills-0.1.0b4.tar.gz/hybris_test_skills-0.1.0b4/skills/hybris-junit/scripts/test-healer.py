#!/usr/bin/env python3
"""test-healer.py — diagnóstico estruturado de erros JUnit para loop de correção.

Uso:
    python3 test-healer.py <caminho/TestFile.java> '<json_do_run_junit>' <iteracao>

Saída:
    JSON com shouldContinue, errorType, suggestion e metadados para o LLM.
"""
import json
import re
import sys

MAX_ITERATIONS = 3


def classify_error(run_junit_json: dict) -> str:
    if run_junit_json.get("errorType") == "environment":
        return "environment"

    status = run_junit_json.get("status", "")
    if status == "FAIL":
        return "assertion_fail"

    error = run_junit_json.get("error", "")

    syntax_patterns = ["reached end of file", "illegal start of expression", "insert }"]
    if any(p in error for p in syntax_patterns):
        return "syntax_error"

    compile_patterns = ["cannot find symbol", "package does not exist", "error:"]
    if any(p in error for p in compile_patterns):
        return "compile_error"

    return "unknown"


def extract_context(run_junit_json: dict, error_type: str) -> dict:
    error = run_junit_json.get("error", "")

    if error_type == "assertion_fail":
        failures = run_junit_json.get("failures", [])
        if failures:
            first = failures[0]
            msg = first.get("message", "")
            trace = first.get("stackTrace", "")[:300]
            suggestion = f"Assertion failed: {msg}. Stack trace: {trace}"
        else:
            suggestion = "Test failed but no failure details available in JSON"
        return {"affectedLine": None, "affectedSymbol": None, "suggestion": suggestion}

    if error_type in ("compile_error", "syntax_error"):
        line_match = re.search(r'\.java:(\d+):', error)
        affected_line = int(line_match.group(1)) if line_match else None

        symbol_match = re.search(r'symbol:\s+(?:class|method|variable)\s+(\w+)', error)
        affected_symbol = symbol_match.group(1) if symbol_match else None

        line_str = f" near line {affected_line}" if affected_line else ""

        if "cannot find symbol" in error and affected_symbol:
            suggestion = (
                f"Add import for '{affected_symbol}' or check if the mock is declared in the test class"
            )
        elif re.search(r'package .+ does not exist', error):
            suggestion = (
                "Package in import statement not found — check if the extension dependency "
                "is declared in extensioninfo.xml"
            )
        elif "insert }" in error or "reached end of file" in error:
            suggestion = f"Syntax error{line_str} — check for unclosed braces or missing method body"
        elif "illegal start of expression" in error:
            suggestion = (
                f"Syntax error{line_str} — check for misplaced keywords or extra/missing semicolons"
            )
        else:
            suggestion = f"Compilation error{line_str} — review the full error message in rawError"

        return {"affectedLine": affected_line, "affectedSymbol": affected_symbol, "suggestion": suggestion}

    return {"affectedLine": None, "affectedSymbol": None, "suggestion": ""}


def build_diagnosis(run_junit_json: dict, iteration: int) -> dict:
    if iteration >= MAX_ITERATIONS:
        return {
            "shouldContinue": False,
            "iteration": iteration,
            "maxIterations": MAX_ITERATIONS,
            "errorType": "max_iterations",
            "affectedLine": None,
            "affectedSymbol": None,
            "suggestion": f"Max iterations ({MAX_ITERATIONS}) reached — stop and report to developer",
            "rawError": run_junit_json.get("error", ""),
        }

    error_type = classify_error(run_junit_json)
    should_continue = error_type not in ("environment",)
    context = extract_context(run_junit_json, error_type)

    return {
        "shouldContinue": should_continue,
        "iteration": iteration,
        "maxIterations": MAX_ITERATIONS,
        "errorType": error_type,
        "affectedLine": context["affectedLine"],
        "affectedSymbol": context["affectedSymbol"],
        "suggestion": context["suggestion"],
        "rawError": run_junit_json.get("error", ""),
    }


def main() -> None:
    if len(sys.argv) != 4:
        print(json.dumps({
            "shouldContinue": False,
            "errorType": "environment",
            "suggestion": "Usage: test-healer.py <test_file> '<run_junit_json>' <iteration>",
            "rawError": "",
        }))
        sys.exit(1)

    _test_file, error_json_str, iteration_str = sys.argv[1], sys.argv[2], sys.argv[3]
    run_junit_json = json.loads(error_json_str)
    iteration = int(iteration_str)
    print(json.dumps(build_diagnosis(run_junit_json, iteration)))


if __name__ == "__main__":
    main()
