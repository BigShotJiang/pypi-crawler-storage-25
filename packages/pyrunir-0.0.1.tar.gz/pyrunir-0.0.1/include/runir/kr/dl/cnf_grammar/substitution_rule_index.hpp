#ifndef RUNIR_CNF_GRAMMAR_SUBSTITUTION_RULE_INDEX_HPP_
#define RUNIR_CNF_GRAMMAR_SUBSTITUTION_RULE_INDEX_HPP_

#include "runir/kr/dl/cnf_grammar/declarations.hpp"

#include <tyr/common/index_mixins.hpp>
#include <tyr/common/types.hpp>

namespace tyr
{

template<runir::kr::dl::CategoryTag Category>
struct Index<runir::kr::dl::cnf_grammar::SubstitutionRule<Category>> : IndexMixin<Index<runir::kr::dl::cnf_grammar::SubstitutionRule<Category>>>
{
    using Base = IndexMixin<Index<runir::kr::dl::cnf_grammar::SubstitutionRule<Category>>>;
    using Base::Base;
};

}

#endif
