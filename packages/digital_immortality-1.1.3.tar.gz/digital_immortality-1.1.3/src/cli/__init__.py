"""Immortality CLI package."""

