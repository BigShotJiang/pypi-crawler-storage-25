"""
Event builder utilities for creating observability events.

Copyright 2026 Geek Cafe
All Rights Reserved. www.geekcafe.dev LICENSED MATERIALS
"""

import os
from typing import Optional, Dict, Any
from datetime import datetime, timezone


def get_current_aws_context() -> Dict[str, str]:
    """
    Get current AWS execution context from environment.
    
    Returns:
        Dict with aws_account_id and aws_region
    """
    account_id = os.getenv("AWS_ACCOUNT_ID", "unknown")
    region = os.getenv("AWS_REGION", os.getenv("AWS_DEFAULT_REGION", "us-east-1"))
    
    return {
        "aws_account_id": account_id,
        "aws_region": region
    }


def get_current_environment() -> str:
    """
    Get current deployment environment.
    
    Returns:
        Environment name (dev/staging/prod)
    """
    return os.getenv("ENVIRONMENT", os.getenv("STAGE", "unknown"))


def build_workflow_event(
    event_type: str,
    service: str,
    component: str,
    execution_id: str,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
    payload: Optional[Dict[str, Any]] = None,
    root_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Build a workflow lifecycle event.
    
    Args:
        event_type: Event type (e.g., "workflow.completed")
        service: Service name (e.g., "acme-services")
        component: Component name (e.g., "on-complete-handler")
        execution_id: Workflow execution ID
        tenant_id: Optional tenant ID
        user_id: Optional user ID
        payload: Optional event payload
        root_id: Optional root execution ID
        
    Returns:
        Event dictionary ready for emission
    """
    import uuid
    
    aws_context = get_current_aws_context()
    environment = get_current_environment()
    
    event = {
        "event_id": str(uuid.uuid4()),
        "event_type": event_type,
        "event_version": 1,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "source": {
            "service": service,
            "component": component,
            "environment": environment
        },
        "origin": aws_context,
        "payload": payload or {}
    }
    
    if tenant_id:
        event["tenant"] = {"tenant_id": tenant_id}
    
    if user_id:
        event["actor"] = {"user_id": user_id}
    
    event["correlation"] = {
        "execution_id": execution_id,
        "root_id": root_id or execution_id
    }
    
    return event


def build_user_event(
    event_type: str,
    service: str,
    component: str,
    user_id: str,
    tenant_id: str,
    payload: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Build a user lifecycle event.
    
    Args:
        event_type: Event type (e.g., "user.created")
        service: Service name
        component: Component name
        user_id: User ID
        tenant_id: Tenant ID
        payload: Optional event payload
        
    Returns:
        Event dictionary ready for emission
    """
    import uuid
    
    aws_context = get_current_aws_context()
    environment = get_current_environment()
    
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": event_type,
        "event_version": 1,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "source": {
            "service": service,
            "component": component,
            "environment": environment
        },
        "origin": aws_context,
        "tenant": {"tenant_id": tenant_id},
        "actor": {"user_id": user_id},
        "payload": payload or {}
    }


def build_step_event(
    event_type: str,
    service: str,
    component: str,
    execution_id: str,
    step_id: str,
    step_type: str,
    tenant_id: Optional[str] = None,
    payload: Optional[Dict[str, Any]] = None,
    root_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Build a step lifecycle event.
    
    Args:
        event_type: Event type (e.g., "step.completed")
        service: Service name
        component: Component name
        execution_id: Workflow execution ID
        step_id: Step ID
        step_type: Step type (e.g., "data_cleaning")
        tenant_id: Optional tenant ID
        payload: Optional event payload
        root_id: Optional root execution ID
        
    Returns:
        Event dictionary ready for emission
    """
    import uuid
    
    aws_context = get_current_aws_context()
    environment = get_current_environment()
    
    event = {
        "event_id": str(uuid.uuid4()),
        "event_type": event_type,
        "event_version": 1,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "source": {
            "service": service,
            "component": component,
            "environment": environment
        },
        "origin": aws_context,
        "correlation": {
            "execution_id": execution_id,
            "root_id": root_id or execution_id,
            "step_id": step_id,
            "step_type": step_type
        },
        "payload": payload or {}
    }
    
    if tenant_id:
        event["tenant"] = {"tenant_id": tenant_id}
    
    return event
