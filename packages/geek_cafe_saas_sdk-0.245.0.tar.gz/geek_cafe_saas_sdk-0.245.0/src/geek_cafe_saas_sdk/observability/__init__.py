"""
Observability utilities for cross-account event emission.

Copyright 2026 Geek Cafe
All Rights Reserved. www.geekcafe.dev LICENSED MATERIALS
"""

from .emitter import ObservabilityEmitter

__all__ = ["ObservabilityEmitter"]
