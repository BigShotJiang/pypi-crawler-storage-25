"""
ObservabilityEmitter - Fire-and-forget event publishing to central observability account.

Copyright 2026 Geek Cafe
All Rights Reserved. www.geekcafe.dev LICENSED MATERIALS
"""

import json
import logging
import os
from typing import Optional, Dict, Any
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class ObservabilityEmitter:
    """
    Fire-and-forget event emitter for cross-account observability.
    
    Publishes structured events to central SQS queue in observability account.
    Uses Organizations-based IAM authentication (no API keys needed).
    
    Usage:
        emitter = ObservabilityEmitter(
            queue_url=os.getenv("OBSERVABILITY_QUEUE_URL")
        )
        
        event = ObservabilityEvent(
            event_type="workflow.completed",
            source=EventSource(...),
            origin=EventOrigin(...),
            payload={...}
        )
        
        emitter.emit(event)
    
    Design Principles:
    - Fire-and-forget: Failures are logged but not raised
    - No retries: SQS handles delivery retries
    - Minimal overhead: Fast, non-blocking
    - Fail-safe: Event emission never blocks primary operations
    """
    
    def __init__(
        self,
        queue_url: Optional[str] = None,
        sqs_client: Optional[Any] = None,
        enabled: bool = True
    ):
        """
        Initialize emitter.
        
        Args:
            queue_url: SQS queue URL in observability account
            sqs_client: Optional pre-configured SQS client (for testing)
            enabled: Whether to actually send events (disable for testing)
        """
        self.queue_url = queue_url or os.getenv("OBSERVABILITY_QUEUE_URL")
        self.enabled = enabled and bool(self.queue_url)
        self.sqs_client = sqs_client or boto3.client("sqs")
        
        if not self.enabled:
            logger.warning(
                "ObservabilityEmitter disabled: "
                f"queue_url={'set' if self.queue_url else 'not set'}, "
                f"enabled={enabled}"
            )
    
    def emit(self, event: Any) -> bool:
        """
        Emit an observability event.
        
        Args:
            event: ObservabilityEvent instance
            
        Returns:
            True if sent successfully, False otherwise
            
        Note:
            Failures are logged but not raised. This is fire-and-forget.
        """
        if not self.enabled:
            logger.debug(f"Skipping event emission (disabled): {event.event_type}")
            return False
        
        try:
            event.validate()
            
            message_body = json.dumps(event.to_dict())
            
            response = self.sqs_client.send_message(
                QueueUrl=self.queue_url,
                MessageBody=message_body,
                MessageAttributes={
                    "event_type": {
                        "DataType": "String",
                        "StringValue": event.event_type
                    },
                    "event_version": {
                        "DataType": "Number",
                        "StringValue": str(event.event_version)
                    }
                }
            )
            
            logger.info(
                f"Emitted event: {event.event_type} "
                f"(id: {event.event_id}, msg_id: {response['MessageId']})"
            )
            return True
            
        except ValueError as e:
            logger.error(f"Event validation failed: {e}", exc_info=True)
            return False
            
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            logger.error(
                f"Failed to emit event {event.event_type}: "
                f"{error_code} - {e}",
                exc_info=True
            )
            return False
            
        except Exception as e:
            logger.error(
                f"Unexpected error emitting event {event.event_type}: {e}",
                exc_info=True
            )
            return False
    
    def emit_dict(self, event_dict: Dict[str, Any]) -> bool:
        """
        Emit an event from a dictionary.
        
        Args:
            event_dict: Event dictionary (must conform to schema)
            
        Returns:
            True if sent successfully, False otherwise
        """
        if not self.enabled:
            logger.debug("Skipping event emission (disabled)")
            return False
        
        try:
            message_body = json.dumps(event_dict)
            
            response = self.sqs_client.send_message(
                QueueUrl=self.queue_url,
                MessageBody=message_body,
                MessageAttributes={
                    "event_type": {
                        "DataType": "String",
                        "StringValue": event_dict.get("event_type", "unknown")
                    }
                }
            )
            
            logger.info(
                f"Emitted event: {event_dict.get('event_type')} "
                f"(id: {event_dict.get('event_id')}, msg_id: {response['MessageId']})"
            )
            return True
            
        except Exception as e:
            logger.error(f"Failed to emit event dict: {e}", exc_info=True)
            return False
    
    def emit_batch(self, events: list) -> Dict[str, int]:
        """
        Emit multiple events in a batch (up to 10).
        
        Args:
            events: List of ObservabilityEvent instances
            
        Returns:
            Dict with 'successful' and 'failed' counts
        """
        if not self.enabled:
            logger.debug(f"Skipping batch emission (disabled): {len(events)} events")
            return {"successful": 0, "failed": len(events)}
        
        if len(events) > 10:
            logger.warning(f"Batch size {len(events)} exceeds SQS limit of 10, truncating")
            events = events[:10]
        
        entries = []
        for i, event in enumerate(events):
            try:
                event.validate()
                entries.append({
                    "Id": str(i),
                    "MessageBody": json.dumps(event.to_dict()),
                    "MessageAttributes": {
                        "event_type": {
                            "DataType": "String",
                            "StringValue": event.event_type
                        }
                    }
                })
            except Exception as e:
                logger.error(f"Failed to prepare event {i}: {e}")
        
        if not entries:
            return {"successful": 0, "failed": len(events)}
        
        try:
            response = self.sqs_client.send_message_batch(
                QueueUrl=self.queue_url,
                Entries=entries
            )
            
            successful = len(response.get("Successful", []))
            failed = len(response.get("Failed", []))
            
            if failed > 0:
                logger.warning(f"Batch emission: {successful} succeeded, {failed} failed")
                for failure in response.get("Failed", []):
                    logger.error(f"Failed to send event {failure['Id']}: {failure.get('Message')}")
            else:
                logger.info(f"Batch emission: {successful} events sent successfully")
            
            return {"successful": successful, "failed": failed}
            
        except Exception as e:
            logger.error(f"Failed to emit batch: {e}", exc_info=True)
            return {"successful": 0, "failed": len(entries)}


def get_emitter(queue_url: Optional[str] = None) -> ObservabilityEmitter:
    """
    Get a singleton ObservabilityEmitter instance.
    
    Args:
        queue_url: Optional queue URL (uses env var if not provided)
        
    Returns:
        ObservabilityEmitter instance
    """
    if not hasattr(get_emitter, "_instance"):
        get_emitter._instance = ObservabilityEmitter(queue_url=queue_url)
    return get_emitter._instance
