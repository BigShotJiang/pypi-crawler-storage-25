"""
Testable handler decorator for the auto-discovery system.

Registers lambda handler functions into the global HANDLER_REGISTRY
at import time. Modeled after @register_rule in Data Cleaning.
"""

import functools
import logging
from typing import Optional

from geek_cafe_saas_sdk.testing.handler_entry import HandlerEntry
from geek_cafe_saas_sdk.testing.registry import HANDLER_REGISTRY

logger = logging.getLogger(__name__)


def testable_handler(
    name: str,
    description: str = "",
    default_event_file: str = "",
    event_files: Optional[list[str]] = None,
    repository: str = "",
):
    """
    Decorator that registers a lambda handler for test harness discovery.

    Args:
        name: Required friendly name for the handler (e.g., "analysis-history").
        description: Human-readable description of the handler.
        default_event_file: Path to the default JSON event file.
        event_files: Additional event file paths for this handler.
        repository: Repository name (e.g., "Acme-Orchestration").

    Raises:
        TypeError: If name is not provided or is empty.
    """
    if not name:
        raise TypeError("@testable_handler requires a 'name' argument")

    # Build combined event files list: default_event_file first, then event_files, deduplicated
    combined_events: list[str] = []
    if default_event_file:
        combined_events.append(default_event_file)
    for ef in (event_files or []):
        if ef and ef not in combined_events:
            combined_events.append(ef)

    def decorator(func):
        module_path = f"{func.__module__}:{func.__qualname__}"
        entry = HandlerEntry(
            name=name,
            module_path=module_path,
            description=description,
            default_event_file=default_event_file,
            event_files=combined_events,
            default_env_file="",
            repository=repository,
        )

        if name in HANDLER_REGISTRY:
            existing = HANDLER_REGISTRY[name]
            logger.warning(
                "Duplicate handler name '%s': replacing %s with %s",
                name,
                existing.module_path,
                module_path,
            )

        HANDLER_REGISTRY[name] = entry

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapper

    return decorator
