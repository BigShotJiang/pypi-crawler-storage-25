"""
Global handler registry and HandlerRegistry facade for the test harness.

The module-level HANDLER_REGISTRY dict is populated at import time
by the @testable_handler decorator. The HandlerRegistry class provides
package scanning and JSON override merging on top of it.
"""

import importlib
import json
import logging
import pkgutil
from pathlib import Path
from typing import Optional

from geek_cafe_saas_sdk.testing.handler_entry import HandlerEntry

logger = logging.getLogger(__name__)

# Global registry — populated at import time by @testable_handler
HANDLER_REGISTRY: dict[str, HandlerEntry] = {}


class HandlerRegistry:
    """
    Facade over the global HANDLER_REGISTRY.
    Supports package scanning and JSON override merging.
    """

    def scan_packages(self, prefixes: list[str]) -> None:
        """Recursively import all modules under each prefix to trigger decorator registrations."""
        for prefix in prefixes:
            try:
                package = importlib.import_module(prefix)
            except ModuleNotFoundError as e:
                logger.warning("Cannot import package '%s': %s", prefix, e)
                continue

            package_path = getattr(package, "__path__", None)
            if package_path is None:
                logger.warning("Package '%s' has no __path__; skipping walk", prefix)
                continue

            for _importer, modname, _ispkg in pkgutil.walk_packages(
                package_path, prefix=prefix + "."
            ):
                try:
                    importlib.import_module(modname)
                except Exception as e:
                    logger.warning("Failed to import '%s': %s", modname, e)

    def load_overrides(self, config_path: Optional[Path] = None) -> None:
        """
        Merge JSON override entries on top of auto-discovered entries.

        JSON values win on conflict. Partial field overrides only update
        the specified keys. New handler names in JSON are added as new entries
        (require at minimum a module_path).

        Args:
            config_path: Path to the JSON override file. If None, this is a no-op.

        Raises:
            FileNotFoundError: If config_path is provided but doesn't exist.
            json.JSONDecodeError: If the file contains invalid JSON.
            ValueError: If a new JSON entry is missing module_path.
        """
        if config_path is None:
            return

        config_path = Path(config_path)
        if not config_path.exists():
            raise FileNotFoundError(
                f"Override config file not found: {config_path}"
            )

        with open(config_path, "r") as f:
            data = json.load(f)

        for name, entry_data in data.get("handlers", {}).items():
            if name in HANDLER_REGISTRY:
                # Partial override: only update fields present in JSON
                existing = HANDLER_REGISTRY[name]
                if "module_path" in entry_data:
                    existing.module_path = entry_data["module_path"]
                if "description" in entry_data:
                    existing.description = entry_data["description"]
                if "default_event_file" in entry_data:
                    existing.default_event_file = entry_data["default_event_file"]
                if "default_env_file" in entry_data:
                    existing.default_env_file = entry_data["default_env_file"]
                if "repository" in entry_data:
                    existing.repository = entry_data["repository"]
                if "event_files" in entry_data:
                    existing.event_files = entry_data["event_files"]
            else:
                # New entry from JSON — must have module_path
                if "module_path" not in entry_data:
                    raise ValueError(
                        f"JSON override for new handler '{name}' is missing "
                        f"required field 'module_path'"
                    )
                HANDLER_REGISTRY[name] = HandlerEntry(
                    name=name,
                    module_path=entry_data["module_path"],
                    description=entry_data.get("description", ""),
                    default_event_file=entry_data.get("default_event_file", ""),
                    event_files=entry_data.get("event_files", []),
                    default_env_file=entry_data.get("default_env_file", ""),
                    repository=entry_data.get("repository", ""),
                )

    def resolve(self, name: str) -> HandlerEntry:
        """
        Look up a handler by friendly name.

        Raises:
            KeyError: With message listing available handler names.
        """
        if name in HANDLER_REGISTRY:
            return HANDLER_REGISTRY[name]

        available = ", ".join(sorted(HANDLER_REGISTRY.keys()))
        raise KeyError(
            f"Handler '{name}' not found. Available handlers: {available}"
        )

    def list_all(self) -> dict[str, list[HandlerEntry]]:
        """Return all entries grouped by repository."""
        grouped: dict[str, list[HandlerEntry]] = {}
        for entry in HANDLER_REGISTRY.values():
            grouped.setdefault(entry.repository, []).append(entry)
        return grouped
