"""
Invocation result data model for the test harness.

Captures the outcome of a lambda handler invocation including
success/failure, response, timing, and error details.
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class InvocationResult:
    """Result of a lambda handler invocation through the test harness."""

    success: bool
    response: Optional[Dict[str, Any]] = None
    execution_time_ms: float = 0.0
    error_type: Optional[str] = None
    error_message: Optional[str] = None
    error_traceback: Optional[str] = None
    handler_path: str = ""
    env_file: str = ""
    event_file: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "success": self.success,
            "response": self.response,
            "execution_time_ms": self.execution_time_ms,
            "error_type": self.error_type,
            "error_message": self.error_message,
            "error_traceback": self.error_traceback,
            "handler_path": self.handler_path,
            "env_file": self.env_file,
            "event_file": self.event_file,
        }
