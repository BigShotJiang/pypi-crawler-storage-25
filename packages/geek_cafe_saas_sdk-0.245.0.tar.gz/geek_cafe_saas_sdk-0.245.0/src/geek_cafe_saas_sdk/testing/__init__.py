"""
geek_cafe_saas_sdk.testing — Reusable test harness infrastructure.

Provides decorator-based auto-discovery, registry, and invocation
support for lambda handler testing. No hard dependencies on
rich, click, or InquirerPy.

Public API:
    testable_handler    — Decorator for handler registration
    HandlerRegistry     — Facade for scanning and resolving handlers
    HandlerEntry        — Data model for a registered handler
    InvocationResult    — Data model for invocation outcomes
    HANDLER_REGISTRY    — Global dict of registered handlers
    HandlerResolver     — Resolves module.path:function strings to callables
    TestHarness         — Orchestrator for handler invocation
    EnvironmentLoader   — .env file parser
    EventLoader         — JSON event file loader
"""

from geek_cafe_saas_sdk.testing.decorator import testable_handler
from geek_cafe_saas_sdk.testing.environment_loader import EnvironmentLoader
from geek_cafe_saas_sdk.testing.event_loader import EventLoader
from geek_cafe_saas_sdk.testing.handler_entry import HandlerEntry
from geek_cafe_saas_sdk.testing.handler_resolver import HandlerResolver
from geek_cafe_saas_sdk.testing.invocation_result import InvocationResult
from geek_cafe_saas_sdk.testing.registry import HANDLER_REGISTRY, HandlerRegistry
from geek_cafe_saas_sdk.testing.test_harness import TestHarness

__all__ = [
    "testable_handler",
    "HandlerRegistry",
    "HandlerEntry",
    "HandlerResolver",
    "TestHarness",
    "EnvironmentLoader",
    "EventLoader",
    "InvocationResult",
    "HANDLER_REGISTRY",
]
