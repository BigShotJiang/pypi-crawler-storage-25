"""
Dynamic handler resolver for the test harness.

Resolves dotted module paths (e.g., 'module.path:function_name') to callable
handler functions using importlib. No rich/click dependencies.
"""

import importlib
from typing import Callable


class HandlerResolver:
    """Resolves a 'module.path:function_name' string to a callable."""

    @staticmethod
    def resolve(handler_path: str) -> Callable:
        """
        Resolve a handler path to a callable function.

        Args:
            handler_path: A string in the format 'module.path:function_name'.
                          If no ':' is present, defaults function name to 'lambda_handler'.

        Returns:
            The callable handler function.

        Raises:
            ModuleNotFoundError: If the module cannot be imported.
            AttributeError: If the function is not found in the module.
        """
        if ":" in handler_path:
            module_path, func_name = handler_path.rsplit(":", 1)
        else:
            module_path = handler_path
            func_name = "lambda_handler"

        try:
            module = importlib.import_module(module_path)
        except ModuleNotFoundError as e:
            raise ModuleNotFoundError(
                f"Cannot import module '{module_path}': {e}"
            ) from e

        try:
            handler_fn = getattr(module, func_name)
        except AttributeError:
            raise AttributeError(
                f"Function '{func_name}' not found in module '{module_path}'"
            )

        return handler_fn
