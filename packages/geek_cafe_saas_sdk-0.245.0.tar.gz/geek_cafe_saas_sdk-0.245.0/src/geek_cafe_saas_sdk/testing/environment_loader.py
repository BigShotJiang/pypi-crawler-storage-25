"""
Environment file loader for the test harness.

Parses .env files and sets OS environment variables so boto3 clients
pick up the correct AWS profile, region, and resource names.
Stdlib only — no external dependencies.
"""

import os
from pathlib import Path


class EnvironmentLoader:
    """Loads environment variables from .env files."""

    @staticmethod
    def load(env_file_path: str | Path) -> dict[str, str]:
        """
        Parse a .env file and set each key=value pair in os.environ.

        Strips surrounding double quotes from values. Skips blank lines
        and lines starting with '#'.

        Args:
            env_file_path: Path to the .env file.

        Returns:
            Dictionary of variables that were set.

        Raises:
            FileNotFoundError: If the file does not exist.
        """
        path = Path(env_file_path)
        if not path.exists():
            raise FileNotFoundError(
                f"Environment file not found: {env_file_path}"
            )

        loaded: dict[str, str] = {}
        with open(path, "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue

                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip()
                # Strip surrounding double quotes
                if value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]

                os.environ[key] = value
                loaded[key] = value

        return loaded
