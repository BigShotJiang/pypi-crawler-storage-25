"""
Handler entry data model for the test harness auto-discovery system.

Represents a registered lambda handler with its metadata.
"""

from dataclasses import dataclass, field


@dataclass
class HandlerEntry:
    """A registered handler with its metadata."""

    name: str
    module_path: str
    description: str = ""
    default_event_file: str = ""
    event_files: list[str] = field(default_factory=list)
    default_env_file: str = ""
    repository: str = ""
