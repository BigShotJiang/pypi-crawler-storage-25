"""
Event payload loader for the test harness.

Reads JSON event files and returns them as Python dictionaries
to be passed as lambda event payloads. Stdlib only — no external dependencies.
"""

import json
from pathlib import Path
from typing import Any, Dict


class EventLoader:
    """Loads JSON event payloads from files."""

    @staticmethod
    def load(
        event_file_path: str | Path,
        event_path: str | None = None,
    ) -> Dict[str, Any]:
        """
        Read a JSON file and return its contents as a dict.

        Args:
            event_file_path: Path to the JSON event file.
            event_path: Optional dot-separated path to extract the event
                        from a larger structure (e.g., 'message.event').
                        If not provided and the JSON looks like a CloudWatch
                        log entry (has 'message.event'), it will be extracted
                        automatically.

        Returns:
            The parsed JSON content as a dictionary.

        Raises:
            FileNotFoundError: If the file does not exist.
            ValueError: If the file contains invalid JSON or the path is invalid.
        """
        path = Path(event_file_path)
        if not path.exists():
            raise FileNotFoundError(
                f"Event file not found: {event_file_path}"
            )

        try:
            with open(path, "r") as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Invalid JSON in event file '{event_file_path}': {e}"
            ) from e

        # Extract nested event if path is specified
        if event_path:
            return EventLoader._extract(data, event_path, event_file_path)

        # Auto-detect CloudWatch log format: look for message.event
        if (
            isinstance(data, dict)
            and "message" in data
            and isinstance(data["message"], dict)
            and "event" in data["message"]
        ):
            return data["message"]["event"]

        return data

    @staticmethod
    def _extract(
        data: Dict[str, Any], dot_path: str, file_path: str | Path
    ) -> Dict[str, Any]:
        """Walk a dot-separated path into a nested dict."""
        current = data
        for key in dot_path.split("."):
            if not isinstance(current, dict) or key not in current:
                raise ValueError(
                    f"Event path '{dot_path}' not found in '{file_path}'. "
                    f"Failed at key '{key}'."
                )
            current = current[key]
        if not isinstance(current, dict):
            raise ValueError(
                f"Value at '{dot_path}' in '{file_path}' is not a dict."
            )
        return current
