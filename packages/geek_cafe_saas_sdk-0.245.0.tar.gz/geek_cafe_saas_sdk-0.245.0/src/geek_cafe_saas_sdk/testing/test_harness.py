"""
Centralized lambda test harness orchestrator.

Ties together environment loading, event loading, handler resolution,
signature detection, and invocation into a single invoke() call.
No rich/click dependencies — returns InvocationResult only, uses logging.
"""

import inspect
import logging
import os
import time
import traceback
from pathlib import Path
from typing import Optional

import boto3
from botocore.exceptions import (
    BotoCoreError,
    ClientError,
    NoCredentialsError,
    ProfileNotFound,
)

from geek_cafe_saas_sdk.testing.environment_loader import EnvironmentLoader
from geek_cafe_saas_sdk.testing.event_loader import EventLoader
from geek_cafe_saas_sdk.testing.handler_resolver import HandlerResolver
from geek_cafe_saas_sdk.testing.invocation_result import InvocationResult

logger = logging.getLogger(__name__)


class TestHarness:
    """Orchestrates lambda handler invocation for local debugging."""

    @staticmethod
    def verify_aws_credentials() -> bool:
        """
        Verify AWS credentials are valid by calling STS get_caller_identity.

        Returns True if credentials work, False otherwise.
        Logs diagnostic info via logging (no rich output).
        """
        profile = os.environ.get(
            "AWS_PROFILE", os.environ.get("AWS_DEFAULT_PROFILE")
        )
        region = os.environ.get(
            "AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        )

        try:
            session = boto3.Session(profile_name=profile, region_name=region)
            sts = session.client("sts")
            identity = sts.get_caller_identity()

            logger.info("AWS Profile: %s", profile or "(default)")
            logger.info("AWS Region:  %s", region)
            logger.info("Account:     %s", identity["Account"])
            logger.info("Identity:    %s", identity["Arn"])
            return True

        except ProfileNotFound:
            logger.warning(
                "AWS profile '%s' not found in ~/.aws/credentials. "
                "Available profiles can be listed with: aws configure list-profiles. "
                "The profile is set by AWS_PROFILE in your .env file.",
                profile,
            )
            return False

        except NoCredentialsError:
            logger.warning(
                "No AWS credentials found. "
                "Check that your .env file sets AWS_PROFILE and that the profile "
                "exists in ~/.aws/credentials with valid access keys. "
                "Current AWS_PROFILE: %s",
                profile or "(not set)",
            )
            return False

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code in ("ExpiredToken", "ExpiredTokenException"):
                logger.warning(
                    "AWS credentials for profile '%s' have expired. "
                    "If using SSO, refresh with: aws sso login --profile %s. "
                    "If using temporary credentials, request new ones.",
                    profile,
                    profile,
                )
            else:
                logger.warning(
                    "AWS access error (%s): %s. Profile: %s, Region: %s",
                    error_code,
                    e,
                    profile or "(default)",
                    region,
                )
            return False

        except BotoCoreError as e:
            logger.warning(
                "AWS connection error: %s. Profile: %s, Region: %s",
                e,
                profile or "(default)",
                region,
            )
            return False

    @staticmethod
    def resolve_env_file(
        explicit_env: Optional[str],
        repository: Optional[str],
    ) -> Optional[str]:
        """
        Env resolution chain:
        1. explicit --env-file (if provided, use it)
        2. ./.env.dev (project root)
        3. ../<repository>/.env.dev (sibling project)

        Returns the first match, or None.
        """
        if explicit_env:
            return explicit_env

        # Check project root .env.dev
        local_env = Path(".env.dev")
        if local_env.exists():
            return str(local_env)

        # Check sibling project .env.dev
        if repository:
            sibling_env = Path("..") / repository / ".env.dev"
            if sibling_env.exists():
                return str(sibling_env)

        return None

    def invoke(
        self,
        handler_path: str,
        env_file: Optional[str] = None,
        event_file: Optional[str] = None,
        event_path: Optional[str] = None,
        debug: bool = False,
        repository: Optional[str] = None,
    ) -> InvocationResult:
        """
        Full orchestration: resolve env file, load env, load event,
        resolve handler, inspect signature, invoke, time, and capture exceptions.
        """
        # Resolve env file using the chain
        resolved_env = self.resolve_env_file(env_file, repository)
        env_file_used = resolved_env or ""
        event_file_used = event_file or ""

        # Load environment
        if resolved_env:
            try:
                EnvironmentLoader.load(resolved_env)
            except FileNotFoundError:
                logger.warning(
                    "Environment file not found: %s. "
                    "Check that the path is correct relative to where you're "
                    "running the command.",
                    resolved_env,
                )
                return InvocationResult(
                    success=False,
                    error_type="FileNotFoundError",
                    error_message=f"Environment file not found: {resolved_env}",
                    handler_path=handler_path,
                    env_file=env_file_used,
                )
        else:
            logger.warning(
                "No environment file found in resolution chain. "
                "Proceeding without loading environment variables."
            )

        # Verify AWS credentials before proceeding
        if not self.verify_aws_credentials():
            return InvocationResult(
                success=False,
                error_type="AWSCredentialError",
                error_message="AWS credential verification failed.",
                handler_path=handler_path,
                env_file=env_file_used,
            )

        # Load event
        if event_file:
            try:
                event = EventLoader.load(event_file, event_path=event_path)
            except FileNotFoundError:
                logger.warning(
                    "Event file not found: %s. "
                    "Check that the path is correct.",
                    event_file,
                )
                return InvocationResult(
                    success=False,
                    error_type="FileNotFoundError",
                    error_message=f"Event file not found: {event_file}",
                    handler_path=handler_path,
                    env_file=env_file_used,
                    event_file=event_file_used,
                )
            except ValueError as e:
                logger.warning("Invalid event file: %s", e)
                return InvocationResult(
                    success=False,
                    error_type="ValueError",
                    error_message=str(e),
                    handler_path=handler_path,
                    env_file=env_file_used,
                    event_file=event_file_used,
                )
        else:
            event = {}

        # Resolve handler
        try:
            handler_fn = HandlerResolver.resolve(handler_path)
        except (ModuleNotFoundError, AttributeError) as e:
            logger.warning(
                "Handler resolution failed for '%s': %s",
                handler_path,
                e,
            )
            return InvocationResult(
                success=False,
                error_type=type(e).__name__,
                error_message=str(e),
                handler_path=handler_path,
                env_file=env_file_used,
                event_file=event_file_used,
            )

        # Detect signature for injected_service vs injected_services
        sig = inspect.signature(handler_fn)
        params = sig.parameters

        kwargs: dict = {"event": event, "context": None}
        if "injected_services" in params:
            kwargs["injected_services"] = None
        elif "injected_service" in params:
            kwargs["injected_service"] = None

        # Invoke and time
        start = time.perf_counter()
        try:
            response = handler_fn(**kwargs)
            elapsed_ms = (time.perf_counter() - start) * 1000
            return InvocationResult(
                success=True,
                response=response,
                execution_time_ms=elapsed_ms,
                handler_path=handler_path,
                env_file=env_file_used,
                event_file=event_file_used,
            )
        except Exception as e:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return InvocationResult(
                success=False,
                execution_time_ms=elapsed_ms,
                error_type=type(e).__name__,
                error_message=str(e),
                error_traceback=traceback.format_exc(),
                handler_path=handler_path,
                env_file=env_file_used,
                event_file=event_file_used,
            )
