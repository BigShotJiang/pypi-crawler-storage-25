"""LongTermServiceBase — abstract base for services targeting long-term DynamoDB tables.

Extends ``DatabaseService[T]`` and validates at construction time that the
provided table name is classified as a long-term resource via
``StorageIntent.LONG_TERM``.
"""

from typing import Optional, TypeVar, TYPE_CHECKING

from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from geek_cafe_saas_sdk.core.services.storage_validator import (
    validate_storage_access,
    StorageIntent,
)

if TYPE_CHECKING:
    from boto3_assist.dynamodb.dynamodb import DynamoDB
    from geek_cafe_saas_sdk.core.request_context import RequestContext
    from geek_cafe_saas_sdk.core.audit import IAuditLogger
    from geek_cafe_saas_sdk.core.retry_config import RetryConfig

T = TypeVar("T")


class LongTermServiceBase(DatabaseService[T]):
    """Base class for services targeting long-term DynamoDB tables.

    Validates that the table name is NOT classified as transient before
    passing it to ``DatabaseService.__init__``.

    Raises:
        StorageMismatchError: In *enforce* mode when the table name
            is classified as transient.
    """

    def __init__(
        self,
        *,
        dynamodb: Optional["DynamoDB"] = None,
        table_name: Optional[str] = None,
        request_context: "RequestContext",
        audit_logger: Optional["IAuditLogger"] = None,
        retry_config: Optional["RetryConfig"] = None,
        **kwargs,
    ):
        if table_name:
            validate_storage_access(
                table_name,
                StorageIntent.LONG_TERM,
                context=type(self).__name__,
            )
        super().__init__(
            dynamodb=dynamodb,
            table_name=table_name,
            request_context=request_context,
            audit_logger=audit_logger,
            retry_config=retry_config,
        )
