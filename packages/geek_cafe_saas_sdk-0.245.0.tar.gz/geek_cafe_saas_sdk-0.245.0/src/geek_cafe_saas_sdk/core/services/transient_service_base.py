"""TransientServiceBase — abstract base for services targeting transient DynamoDB tables.

Extends ``DatabaseService[T]`` and incorporates ``TransientTableMixin`` so that
the transient table name is resolved automatically and validated against
``StorageIntent.TRANSIENT`` at construction time.
"""

from typing import Optional, TypeVar, TYPE_CHECKING

from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from geek_cafe_saas_sdk.core.services.transient_table_mixin import TransientTableMixin
from geek_cafe_saas_sdk.core.services.storage_validator import (
    validate_storage_access,
    StorageIntent,
)

if TYPE_CHECKING:
    from boto3_assist.dynamodb.dynamodb import DynamoDB
    from geek_cafe_saas_sdk.core.request_context import RequestContext
    from geek_cafe_saas_sdk.core.audit import IAuditLogger
    from geek_cafe_saas_sdk.core.retry_config import RetryConfig

T = TypeVar("T")


class TransientServiceBase(DatabaseService[T], TransientTableMixin):
    """Base class for services targeting transient DynamoDB tables.

    Resolves the transient table name via ``TransientTableMixin`` and validates
    that the resolved name is classified as a transient resource before passing
    it to ``DatabaseService.__init__``.

    Raises:
        StorageMismatchError: In *enforce* mode when the resolved table name
            is not classified as transient.
    """

    def __init__(
        self,
        *,
        dynamodb: Optional["DynamoDB"] = None,
        table_name: Optional[str] = None,
        request_context: "RequestContext",
        audit_logger: Optional["IAuditLogger"] = None,
        retry_config: Optional["RetryConfig"] = None,
        **kwargs,
    ):
        resolved_table = self.resolve_transient_table_name(
            fallback_table_name=table_name,
        )
        # Only validate when transient storage is active — when disabled,
        # the resolved table is intentionally the main (long-term) table.
        if self.is_transient_storage_enabled():
            validate_storage_access(
                resolved_table,
                StorageIntent.TRANSIENT,
                context=type(self).__name__,
            )
        super().__init__(
            dynamodb=dynamodb,
            table_name=resolved_table,
            request_context=request_context,
            audit_logger=audit_logger,
            retry_config=retry_config,
        )
