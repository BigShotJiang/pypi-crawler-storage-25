"""Storage Validator — classifies resource names and enforces storage-intent rules.

Provides stateless utility functions that determine whether a DynamoDB table
or S3 bucket is *transient* (short-lived, TTL-governed) or *long-term*
(permanent) based on a simple naming convention: the presence of the
substring ``transient`` (case-insensitive) in the resource name.

A configurable validation mode (``STORAGE_VALIDATION_MODE`` env var) controls
whether mismatches raise errors (``enforce``, the default) or only log
warnings (``warn``).
"""

import os
from enum import Enum
from typing import Optional

from aws_lambda_powertools import Logger

logger = Logger(__name__)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ResourceClassification(str, Enum):
    """Classification of a storage resource based on its name."""

    TRANSIENT = "transient"
    LONG_TERM = "long_term"


class StorageIntent(str, Enum):
    """Declared intent of a service regarding storage tier."""

    TRANSIENT = "transient"
    LONG_TERM = "long_term"


class ValidationMode(str, Enum):
    """How the validator responds to mismatches."""

    ENFORCE = "enforce"
    WARN = "warn"


# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class StorageMismatchError(Exception):
    """Raised when a service's storage intent doesn't match the target resource."""

    def __init__(
        self,
        message: str,
        resource_name: str,
        intent: StorageIntent,
        classification: ResourceClassification,
    ):
        super().__init__(message)
        self.resource_name = resource_name
        self.intent = intent
        self.classification = classification


# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------


def classify_resource(resource_name: str) -> ResourceClassification:
    """Classify a resource name as transient or long-term.

    Args:
        resource_name: DynamoDB table name or S3 bucket name.

    Returns:
        ``ResourceClassification.TRANSIENT`` if *transient* appears in the
        name (case-insensitive), ``ResourceClassification.LONG_TERM``
        otherwise.

    Raises:
        ValueError: If *resource_name* is ``None``, empty, or whitespace-only.
    """
    if resource_name is None or not resource_name.strip():
        raise ValueError(
            "resource_name must be a non-empty, non-whitespace string"
        )

    if "transient" in resource_name.lower():
        return ResourceClassification.TRANSIENT
    return ResourceClassification.LONG_TERM


def get_validation_mode() -> ValidationMode:
    """Read ``STORAGE_VALIDATION_MODE`` from the environment.

    Returns ``ValidationMode.ENFORCE`` when the variable is unset or contains
    an unrecognised value (logging a warning in the latter case).
    """
    raw = os.getenv("STORAGE_VALIDATION_MODE", "").strip().lower()

    if raw == ValidationMode.WARN.value:
        return ValidationMode.WARN

    if raw == ValidationMode.ENFORCE.value or raw == "":
        return ValidationMode.ENFORCE

    # Unrecognised value — default to enforce and warn the operator.
    logger.warning(
        "Unrecognized STORAGE_VALIDATION_MODE '%s'; defaulting to 'enforce'",
        raw,
    )
    return ValidationMode.ENFORCE


def validate_storage_access(
    resource_name: str,
    intent: StorageIntent,
    context: Optional[str] = None,
) -> None:
    """Validate that a resource name matches the declared storage intent.

    Args:
        resource_name: The DynamoDB table or S3 bucket name.
        intent: The service's declared storage intent.
        context: Optional description for error/warning messages
            (e.g. model type, operation name).

    Raises:
        StorageMismatchError: In *enforce* mode when *intent* doesn't match
            the resource classification.
    """
    classification = classify_resource(resource_name)

    # Determine whether intent and classification are aligned.
    intent_is_transient = intent == StorageIntent.TRANSIENT
    resource_is_transient = classification == ResourceClassification.TRANSIENT

    if intent_is_transient == resource_is_transient:
        return  # Match — nothing to do.

    # Build a human-readable message.
    ctx = f" (context: {context})" if context else ""
    message = (
        f"Storage mismatch{ctx}: intent is '{intent.value}' but resource "
        f"'{resource_name}' is classified as '{classification.value}'"
    )

    mode = get_validation_mode()

    if mode == ValidationMode.WARN:
        logger.warning(message)
        return

    raise StorageMismatchError(
        message,
        resource_name=resource_name,
        intent=intent,
        classification=classification,
    )
