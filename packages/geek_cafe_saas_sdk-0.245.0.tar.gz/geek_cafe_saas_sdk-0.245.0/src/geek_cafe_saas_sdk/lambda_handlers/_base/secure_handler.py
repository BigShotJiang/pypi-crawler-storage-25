"""
Secure Lambda handler that relies on API Gateway authorization.

This handler assumes that API Gateway (or ALB) has already validated
the request using AWS Cognito, IAM, or a custom authorizer.
The handler trusts that the request has been authenticated.
"""

from typing import Dict, Any, Optional
from aws_lambda_powertools import Logger

from .base_handler import BaseLambdaHandler
from geek_cafe_saas_sdk.utilities.response import error_response

logger = Logger(__name__)


class SecureLambdaHandler(BaseLambdaHandler):
    """
    Secure handler that relies on API Gateway/ALB authorization.
    
    Use this when:
    - API Gateway has a Cognito authorizer configured
    - API Gateway has a Lambda authorizer configured
    - ALB has authentication configured
    - Request is authenticated before reaching Lambda
    
    The handler does NOT perform its own authentication.
    It trusts the upstream service (API Gateway/ALB).
    
    Example:
        handler = SecureLambdaHandler(
            service_class=VoteService,
            require_body=True
        )
        
        def lambda_handler(event, context):
            return handler.execute(event, context, process_vote)
        
        def process_vote(event, service, user_context):
            # user_context contains claims from API Gateway authorizer
            payload = event["parsed_body"]
            return service.create_vote(...)
    """
    
    def __init__(
        self,
        require_authorizer_claims: bool = True,
        **kwargs
    ):
        """
        Initialize the secure handler.
        
        Args:
            require_authorizer_claims: Whether to require authorizer claims in event
            **kwargs: Arguments passed to BaseLambdaHandler
        """
        super().__init__(**kwargs)
        self.require_authorizer_claims = require_authorizer_claims
    
    def _validate_security(self, event: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Validate that request came through authorized API Gateway.
        
        Checks for requestContext.authorizer which is populated by
        API Gateway when using Cognito or Lambda authorizers.
        
        Returns:
            Error response dict if validation fails, None if valid
        """
        if not self.require_authorizer_claims:
            return None
        
        # Extract request metadata for diagnostic logging
        http_method = event.get("httpMethod", "UNKNOWN")
        resource_path = event.get("resource", "UNKNOWN")
        request_id = event.get("requestContext", {}).get("requestId", "UNKNOWN")
        
        # Check for API Gateway authorizer context
        request_context = event.get("requestContext", {})
        authorizer = request_context.get("authorizer", {})
        
        # Branch 1: No authorizer configured at all (deployment issue)
        if not authorizer:
            logger.warning(
                "No authorizer configured on this endpoint",
                extra={
                    "auth_failure_reason": "authorizer_not_configured",
                    "http_method": http_method,
                    "resource_path": resource_path,
                    "request_id": request_id
                }
            )
            return error_response(
                "Authorization not configured. No authorizer is attached to this endpoint. "
                "This is a deployment configuration issue.",
                "AUTHORIZER_NOT_CONFIGURED",
                401
            )
        
        # Branch 2: Authorizer exists but required claims are missing
        claims = authorizer.get("claims", {})
        if not claims.get("custom:user_id"):
            missing = [c for c in ["custom:user_id"] if not claims.get(c)]
            logger.warning(
                "Authentication failed: required claims missing",
                extra={
                    "auth_failure_reason": "missing_claims",
                    "http_method": http_method,
                    "resource_path": resource_path,
                    "request_id": request_id,
                    "missing_claims": missing
                }
            )
            return error_response(
                "Authentication required but not provided",
                "AUTHENTICATION_REQUIRED",
                401
            )
        
        return None
