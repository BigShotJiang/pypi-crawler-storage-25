"""
Lambda handler for retrieving a tenant by ID.

Requires authentication (secure mode).
"""

from typing import Dict, Any
from aws_lambda_powertools import Logger
from geek_cafe_saas_sdk.lambda_handlers import create_handler, LambdaEvent
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.modules.tenancy.services.tenant_service import TenantService

logger = Logger(__name__)

# Factory creates handler (defaults to secure auth)
handler_wrapper = create_handler(
    service_class=TenantService,
    require_body=False,
    convert_request_case=True
)

# Fields extracted from Subscription into the summary dict
SUBSCRIPTION_SUMMARY_FIELDS = [
    "id", "status", "plan_code", "plan_name", "seat_count",
    "billing_interval", "price_cents", "currency",
    "current_period_start_utc_ts", "current_period_end_utc_ts",
    "is_trial", "trial_ends_utc_ts", "cancel_at_period_end",
]


def lambda_handler(event: Dict[str, Any], context: Any, injected_service=None) -> Dict[str, Any]:
    """
    Lambda handler for retrieving a tenant by ID.
    
    Args:
        event: API Gateway event
        context: Lambda context
        injected_service: Optional TenantService for testing
    """
    return handler_wrapper.execute(event, context, get_tenant, injected_service)


def build_subscription_summary(subscription) -> dict:
    """Extract subscription summary fields into a flat dictionary."""
    return {field: getattr(subscription, field) for field in SUBSCRIPTION_SUMMARY_FIELDS}


def _fetch_subscription_summary(tenant_service: TenantService, tenant_id: str) -> dict | None:
    """Fetch active subscription summary for a tenant. Returns None on any failure."""
    try:
        from geek_cafe_saas_sdk.modules.tenancy.services.subscription_service import SubscriptionService

        subscription_service = SubscriptionService(
            dynamodb=tenant_service.dynamodb,
            table_name=tenant_service.table_name,
            request_context=tenant_service.request_context,
        )
        sub_result = subscription_service.get_bound_subscription()
        if sub_result.success and sub_result.data is not None:
            return build_subscription_summary(sub_result.data)
        return None
    except Exception as e:
        logger.warning("Subscription enrichment failed", extra={
            "tenant_id": tenant_id,
            "error": str(e),
        })
        return None


def get_tenant(event: LambdaEvent, service: TenantService) -> ServiceResult:
    """
    Business logic for getting a tenant by ID.
    
    Service already has request_context with tenant_id and user_id.
    """
    tenant_id = event.path("id", "tenantId")
    
    if not tenant_id:
        raise ValueError("Tenant ID is required in the path")
    
    result = service.get_by_id(tenant_id=tenant_id)
    if not result.success:
        return result

    enriched = event.query_bool("enriched", default=True)
    if enriched:
        result.metadata["active_subscription"] = _fetch_subscription_summary(service, tenant_id)

    return result
