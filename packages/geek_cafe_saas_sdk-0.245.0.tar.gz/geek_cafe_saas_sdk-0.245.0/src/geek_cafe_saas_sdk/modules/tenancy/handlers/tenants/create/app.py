"""
Lambda handler for creating a tenant.

Requires authentication (secure mode).
"""

from typing import Dict, Any
from geek_cafe_saas_sdk.lambda_handlers import create_handler, LambdaEvent
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.modules.tenancy.services.tenant_service import TenantService


# Factory creates handler (defaults to secure auth)
handler_wrapper = create_handler(
    service_class=TenantService,
    require_body=True,
    convert_request_case=True
)


def lambda_handler(event: Dict[str, Any], context: Any, injected_service=None) -> Dict[str, Any]:
    """
    Lambda handler for creating a tenant.

    Args:
        event: API Gateway event
        context: Lambda context
        injected_service: Optional TenantService for testing
    """
    return handler_wrapper.execute(event, context, create_tenant, injected_service)


def create_tenant(event: LambdaEvent, service: TenantService) -> ServiceResult:
    """
    Business logic for creating a tenant.

    Service already has request_context with tenant_id and user_id.
    Unwraps the 'tenant' envelope if present.
    """
    body = event.body()
    payload = body.get("tenant", body)
    return service.create(payload=payload)
