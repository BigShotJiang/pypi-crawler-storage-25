"""
Lambda handler for creating/upserting a subscription.

Supports three modes via a single POST endpoint:
  1. Create — no subscription ID, no autoActivate
  2. Update — subscription ID in path, no autoActivate
  3. Activate — autoActivate=true in payload (create-and-activate or
     update-and-activate); delegates to activate_subscription which
     atomically sets the active pointer, supersedes old subscriptions,
     and syncs the tenant's plan_tier.

Requires authentication (secure mode).
"""

from typing import Dict, Any
from geek_cafe_saas_sdk.lambda_handlers import create_handler, LambdaEvent
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.modules.tenancy.services.subscription_service import SubscriptionService


# Factory creates handler (defaults to secure auth)
handler_wrapper = create_handler(
    service_class=SubscriptionService,
    require_body=True,
    convert_request_case=True
)


def lambda_handler(event: Dict[str, Any], context: Any, injected_service=None) -> Dict[str, Any]:
    """
    Lambda handler for creating/upserting a subscription.

    Args:
        event: API Gateway event
        context: Lambda context
        injected_service: Optional SubscriptionService for testing
    """
    return handler_wrapper.execute(event, context, create_subscription, injected_service)


def create_subscription(event: LambdaEvent, service: SubscriptionService) -> ServiceResult:
    """
    Business logic for creating/upserting a subscription.

    Service already has request_context with tenant_id and user_id.
    Unwraps the 'subscription' envelope if present.

    Routing logic:
      - If payload contains autoActivate=true → activate_subscription
        (atomically creates subscription, updates active pointer,
        supersedes old subscription, syncs tenant plan_tier)
      - Elif subscription ID in path → update existing subscription
      - Else → create new subscription (inactive)
    """
    body = event.body()
    payload = body.get("subscription", body)

    # Extract and remove the routing flag — it's not a subscription field
    auto_activate = payload.pop("auto_activate", False)

    # Check for subscription ID in path (update case)
    subscription_id = event.path("id", "subscriptionId", "subscription-id",
                                  "subscription_id")

    if auto_activate:
        # Activate: atomically create/update + set active pointer + sync tenant
        return service.activate_subscription(payload=payload)

    if subscription_id:
        # Update existing subscription
        return service.update(subscription_id=subscription_id, updates=payload)

    # Create new subscription (does NOT activate)
    return service.create(payload=payload)
