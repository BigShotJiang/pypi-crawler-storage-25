"""
Workflow Tracking model — lightweight cross-tenant monitoring record.

Written as a side-effect of every WorkflowService save so the monitoring
and diagnostic systems can query execution status globally (across all
tenants) without touching tenant-scoped indexes.

Access Patterns (DynamoDB Keys):
  - pk:    TRACKING#{execution_id}
  - sk:    tracking
  - gsi3:  PK = "tracking#monitoring"  (constant — single cross-tenant partition)
           SK = "status#{status}#ts#{started_utc_ts}"
           → query with begins_with("status#running") to find all running executions

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Optional, Any, Dict
from boto3_assist.dynamodb.dynamodb_index import DynamoDBIndex, DynamoDBKey
from geek_cafe_saas_sdk.core.models.base_model import BaseModel


class WorkflowTracking(BaseModel):
    """
    Lightweight execution status record for cross-tenant monitoring.

    One record per execution.  Written (upserted) whenever the corresponding
    Workflow record is saved.  Contains only the fields needed for monitoring
    and diagnostics — no tenant/owner in the index keys so a single GSI query
    returns all running executions regardless of tenant.

    Security note:
        These records are intentionally cross-tenant.  They must only be
        readable by system-level services (monitoring Lambda, admin tooling).
        tenant_id / owner_id are stored as plain attributes for reference and
        diagnostics but are never used as index keys.
    """

    def __init__(self):
        super().__init__()

        self._execution_id: Optional[str] = None
        self._status: Optional[str] = None
        self._lifecycle_state: Optional[str] = None
        self._started_utc_ts: Optional[float] = None
        self._started_utc: Optional[str] = None
        self._execution_type: Optional[str] = None
        self._name: Optional[str] = None
        self._tenant_id: Optional[str] = None
        self._owner_id: Optional[str] = None

        self._setup_indexes()

    def _setup_indexes(self):
        """Single-table indexes for WorkflowTracking."""

        # Primary: one record per execution
        primary = DynamoDBIndex()
        primary.name = "primary"
        primary.partition_key.attribute_name = "pk"
        primary.partition_key.value = lambda: DynamoDBKey.build_key(
            ("tracking", self._execution_id)
        )
        primary.sort_key.attribute_name = "sk"
        primary.sort_key.value = lambda: "tracking"
        self.indexes.add_primary(primary)

        # GSI3: Cross-tenant monitoring index
        #   PK = "tracking#monitoring#status#{status}"
        #        → status in PK keeps each status class in its own partition
        #   SK = "started_ts#{ts}"
        #        → raw timestamp enables BETWEEN queries to filter by age directly
        #        → build_key stops at None, so an unset ts yields "started_ts#"
        #          which is sufficient for begins_with queries
        gsi3 = DynamoDBIndex()
        gsi3.name = "gsi3"
        gsi3.partition_key.attribute_name = "gsi3_pk"
        gsi3.partition_key.value = lambda: DynamoDBKey.build_key(
            ("tracking", "monitoring"),
            ("status", self._status),
        )
        gsi3.sort_key.attribute_name = "gsi3_sk"
        gsi3.sort_key.value = lambda: DynamoDBKey.build_key(
            ("started_ts", self._started_utc_ts)
        )
        self.indexes.add_secondary(gsi3)

    # -------------------------------------------------------------------------
    # Factory
    # -------------------------------------------------------------------------

    @classmethod
    def from_workflow(cls, execution) -> "WorkflowTracking":
        """
        Build a WorkflowTracking record from a Workflow model instance.

        Args:
            execution: A Workflow model (or any object with the relevant fields)

        Returns:
            WorkflowTracking populated with the execution's current state
        """
        record = cls()
        record.execution_id = execution.id or getattr(execution, "execution_id", None)
        record.status = getattr(execution, "status", None)
        record.lifecycle_state = getattr(execution, "lifecycle_state", None)
        record.started_utc_ts = getattr(execution, "started_utc_ts", None)
        record.started_utc = getattr(execution, "started_utc", None)
        record.execution_type = getattr(execution, "execution_type", None)
        record.name = getattr(execution, "name", None)
        record.tenant_id = getattr(execution, "tenant_id", None)
        record.owner_id = getattr(execution, "owner_id", None)
        return record

    # -------------------------------------------------------------------------
    # map() — DynamoDB → model
    # -------------------------------------------------------------------------

    def map(self, item: Dict[str, Any]) -> "WorkflowTracking":
        super().map(item)
        self._execution_id = item.get("execution_id")
        self._status = item.get("status")
        self._lifecycle_state = item.get("lifecycle_state")
        self._started_utc_ts = item.get("started_utc_ts")
        self._started_utc = item.get("started_utc")
        self._execution_type = item.get("execution_type")
        self._name = item.get("name")
        self._tenant_id = item.get("tenant_id")
        self._owner_id = item.get("owner_id")
        return self

    # -------------------------------------------------------------------------
    # Properties
    # -------------------------------------------------------------------------

    @property
    def execution_id(self) -> Optional[str]:
        return self._execution_id

    @execution_id.setter
    def execution_id(self, value: Optional[str]):
        self._execution_id = value

    @property
    def status(self) -> Optional[str]:
        return self._status

    @status.setter
    def status(self, value: Optional[str]):
        self._status = value

    @property
    def lifecycle_state(self) -> Optional[str]:
        return self._lifecycle_state

    @lifecycle_state.setter
    def lifecycle_state(self, value: Optional[str]):
        self._lifecycle_state = value

    @property
    def started_utc_ts(self) -> Optional[float]:
        return self._started_utc_ts

    @started_utc_ts.setter
    def started_utc_ts(self, value: Optional[float]):
        self._started_utc_ts = value

    @property
    def started_utc(self) -> Optional[str]:
        return self._started_utc

    @started_utc.setter
    def started_utc(self, value: Optional[str]):
        self._started_utc = value

    @property
    def execution_type(self) -> Optional[str]:
        return self._execution_type

    @execution_type.setter
    def execution_type(self, value: Optional[str]):
        self._execution_type = value

    @property
    def name(self) -> Optional[str]:
        return self._name

    @name.setter
    def name(self, value: Optional[str]):
        self._name = value

    @property
    def tenant_id(self) -> Optional[str]:
        """Reference only — not used in any index key."""
        return self._tenant_id

    @tenant_id.setter
    def tenant_id(self, value: Optional[str]):
        self._tenant_id = value

    @property
    def owner_id(self) -> Optional[str]:
        """Reference only — not used in any index key."""
        return self._owner_id

    @owner_id.setter
    def owner_id(self, value: Optional[str]):
        self._owner_id = value
