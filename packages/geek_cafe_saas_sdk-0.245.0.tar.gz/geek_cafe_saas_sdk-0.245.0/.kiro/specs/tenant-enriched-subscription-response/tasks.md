# Implementation Plan: Tenant Enriched Subscription Response

## Overview

Enrich the tenant GET API response with an active subscription summary by default. Implementation modifies the tenant GET handler to optionally fetch subscription data via `SubscriptionService.get_bound_subscription()`, adds a pure `build_subscription_summary()` extraction function, and updates the response utilities to include `ServiceResult.metadata` in the HTTP response body. The Tenant model remains unchanged.

## Tasks

- [x] 1. Implement `build_subscription_summary()` pure function and `_fetch_subscription_summary()` helper
  - [x] 1.1 Add `build_subscription_summary()` and `SUBSCRIPTION_SUMMARY_FIELDS` to the tenant GET handler module
    - Define `SUBSCRIPTION_SUMMARY_FIELDS` list with the 13 specified fields: `id`, `status`, `plan_code`, `plan_name`, `seat_count`, `billing_interval`, `price_cents`, `currency`, `current_period_start_utc_ts`, `current_period_end_utc_ts`, `is_trial`, `trial_ends_utc_ts`, `cancel_at_period_end`
    - Implement `build_subscription_summary(subscription) -> dict` as a pure function using `getattr` over the fields list
    - File: `geek_cafe_saas_sdk/modules/tenancy/handlers/tenants/get/app.py`
    - _Requirements: 2.2, 6.1, 6.2, 6.3_

  - [x] 1.2 Add `_fetch_subscription_summary()` private helper to the tenant GET handler module
    - Instantiate `SubscriptionService` using `tenant_service.dynamodb`, `tenant_service.table_name`, and `tenant_service.request_context`
    - Call `subscription_service.get_bound_subscription()`
    - On success with data, call `build_subscription_summary()` and return the dict
    - On `success=False`, missing data, or any exception, return `None`
    - Log warning on exception with `tenant_id` and error message
    - File: `geek_cafe_saas_sdk/modules/tenancy/handlers/tenants/get/app.py`
    - _Requirements: 2.4, 4.1, 4.2, 4.3_

  - [ ]* 1.3 Write property test for `build_subscription_summary()` — Property 1: Summary extraction preserves all specified fields
    - **Property 1: Subscription summary extraction preserves all specified fields**
    - **Validates: Requirements 2.2, 6.1, 6.2, 6.3**
    - Use Hypothesis to generate random Subscription objects with arbitrary field values
    - Assert result dict has exactly 13 keys matching `SUBSCRIPTION_SUMMARY_FIELDS`
    - Assert each value equals `getattr(subscription, field)`
    - Assert no extra keys are present
    - File: `tests/properties/test_tenant_enriched_subscription_properties.py`

  - [ ]* 1.4 Write property test for `_fetch_subscription_summary()` — Property 2: Failure resilience always yields null subscription
    - **Property 2: Subscription lookup failure always yields null subscription**
    - **Validates: Requirements 4.1, 4.3**
    - Use Hypothesis to generate random exception types and error messages
    - Mock `SubscriptionService.get_bound_subscription()` to raise the generated exception or return `ServiceResult(success=False)`
    - Assert `_fetch_subscription_summary()` returns `None`
    - File: `tests/properties/test_tenant_enriched_subscription_properties.py`

- [x] 2. Modify `get_tenant()` to support enriched query parameter
  - [x] 2.1 Extend `get_tenant()` business logic to read `enriched` query param and conditionally enrich
    - Read `enriched` query parameter via `event.query_bool("enriched", default=True)`
    - When `enriched=True` and tenant fetch succeeds, call `_fetch_subscription_summary()` and attach result to `result.metadata["active_subscription"]`
    - When `enriched=False`, skip subscription lookup entirely (current behavior preserved)
    - Add necessary imports for `SubscriptionService` and logger
    - File: `geek_cafe_saas_sdk/modules/tenancy/handlers/tenants/get/app.py`
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 2.1, 2.3, 3.2_

  - [ ]* 2.2 Write property test for enriched response structure — Property 3: Enriched response structure places subscription in metadata
    - **Property 3: Enriched response structure places subscription in metadata**
    - **Validates: Requirements 2.1, 3.1, 5.1**
    - Use Hypothesis to generate random Tenant and Subscription objects
    - Mock services to return them
    - Call `get_tenant()` with `enriched=true`
    - Assert `result.data` is the Tenant object (unchanged)
    - Assert `result.metadata["active_subscription"]` is a dict with 13 fields
    - Assert the Tenant object contains no subscription keys
    - File: `tests/properties/test_tenant_enriched_subscription_properties.py`

  - [ ]* 2.3 Write unit tests for `get_tenant()` enrichment scenarios
    - Test default enrichment (no `enriched` param) → response includes `active_subscription`
    - Test explicit opt-out (`enriched=false`) → response has no `metadata` / subscription data
    - Test no active subscription → `active_subscription: null`
    - Test subscription service exception → 200 response, `active_subscription: null`, warning logged
    - Test subscription service returns `success=False` → `active_subscription: null`
    - Test tenant not found → normal 404 error, no subscription lookup attempted
    - File: `tests/test_tenant_enriched_subscription.py`
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 2.1, 2.3, 4.1, 4.2, 4.3_

- [x] 3. Checkpoint — Ensure handler logic and property tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Update response utilities to include metadata in HTTP response
  - [x] 4.1 Modify `service_result_to_response()` to include `ServiceResult.metadata` in the response body
    - After building the success body via `success_response()`, check if `result.metadata` is non-empty
    - If metadata is present, apply case conversion (using the same `target_format` and `preserve_fields`) and add as `body["metadata"]`
    - Ensure metadata is included only on success responses
    - File: `geek_cafe_saas_sdk/utilities/response.py`
    - _Requirements: 5.1, 5.2_

  - [x] 4.2 Add `metadata` parameter to `success_response()` function
    - Add optional `metadata: Optional[Dict[str, Any]] = None` parameter
    - When metadata is provided and non-empty, apply case conversion and add as `body["metadata"]`
    - File: `geek_cafe_saas_sdk/utilities/response.py`
    - _Requirements: 5.1, 5.2_

  - [x] 4.3 Update `service_result_to_response()` to pass metadata through to `success_response()`
    - Extract `result.metadata` and pass it as the `metadata` kwarg to `success_response()`
    - This wires the ServiceResult metadata into the HTTP response body end-to-end
    - File: `geek_cafe_saas_sdk/utilities/response.py`
    - _Requirements: 5.1, 5.3_

  - [ ]* 4.4 Write unit tests for response utility metadata support
    - Test `success_response()` with metadata → body includes `metadata` key with case-converted keys
    - Test `success_response()` without metadata → body has no `metadata` key
    - Test `service_result_to_response()` with `ServiceResult.metadata` populated → HTTP response body includes `metadata`
    - Test `service_result_to_response()` with empty metadata → no `metadata` key in body
    - Test case conversion applies to metadata field names (snake_case → camelCase)
    - Test `enriched=false` produces response identical to current behavior (no metadata key)
    - File: `tests/test_tenant_enriched_subscription.py`
    - _Requirements: 5.1, 5.2, 5.3_

- [x] 5. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Verify Tenant model isolation and backward compatibility
  - [x] 6.1 Verify Tenant model is unchanged and `TenantService.get_by_id()` returns only Tenant data
    - Confirm no modifications to `geek_cafe_saas_sdk/modules/tenancy/models/tenant.py`
    - Confirm `TenantService.get_by_id()` still returns only Tenant data without subscription fields
    - Add a regression unit test asserting `TenantService.get_by_id()` result contains no subscription keys
    - _Requirements: 3.1, 3.3_

  - [ ]* 6.2 Write integration-style unit test for end-to-end enriched response
    - Mock DynamoDB and both services
    - Call `lambda_handler` with a full API Gateway event (no `enriched` param)
    - Parse the response body JSON
    - Assert `data` contains tenant fields, `metadata.activeSubscription` contains the 13 summary fields (camelCase)
    - Assert response `statusCode` is 200 and `success` is true
    - _Requirements: 1.2, 2.1, 2.2, 5.1, 5.2, 6.1_

- [x] 7. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
- Unit tests validate specific examples and edge cases
- The Tenant model (`tenant.py`) must NOT be modified — subscription enrichment is a handler-layer concern
- All code changes are in the open-source SDK (`geek-cafe-saas-sdk`)
- Use the project virtual environment: `source geek-cafe-saas-sdk/.venv/bin/activate`
