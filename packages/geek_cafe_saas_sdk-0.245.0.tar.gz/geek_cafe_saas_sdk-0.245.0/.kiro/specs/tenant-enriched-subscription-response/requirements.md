# Requirements Document

## Introduction

When loading tenant information in the UI, the frontend needs the active subscription details (plan, status, seat count, billing period, etc.) to render the tenant dashboard. Currently, the tenant GET API returns only the Tenant model data, requiring a separate API call to fetch the active subscription. This feature enriches the tenant GET API response to include an active subscription summary by default, eliminating the extra round-trip.

The enrichment is performed via a secondary service call using the existing `SubscriptionService.get_bound_subscription()` method, which does an O(1) pointer lookup (`sk: "subscription#active"`) followed by a subscription fetch. The Tenant model itself is not modified — subscription data remains stored separately. An `enriched` query parameter (defaulting to `true`) controls whether the subscription summary is included, preserving backward compatibility when callers explicitly opt out.

## Glossary

- **Tenant_GET_Handler**: The Lambda handler that processes GET requests for a single tenant by ID, currently implemented in `geek_cafe_saas_sdk.modules.tenancy.handlers.tenants.get.app`.
- **Tenant_Service**: The `TenantService` class in `geek-cafe-saas-sdk` that provides tenant CRUD operations, including `get_by_id()`.
- **Subscription_Service**: The `SubscriptionService` class in `geek-cafe-saas-sdk` that manages subscription operations, including `get_bound_subscription()` for O(1) active subscription lookup.
- **Bound_Subscription**: The subscription currently referenced by the active pointer item (`PK=tenant#<tenant_id>`, `SK=subscription#active`). Retrieved via `SubscriptionService.get_bound_subscription()`.
- **Subscription_Summary**: A subset of Bound_Subscription fields included in the enriched tenant response: `id`, `status`, `plan_code`, `plan_name`, `seat_count`, `billing_interval`, `price_cents`, `currency`, `current_period_start_utc_ts`, `current_period_end_utc_ts`, `is_trial`, `trial_ends_utc_ts`, and `cancel_at_period_end`.
- **Enriched_Response**: The tenant GET API response that includes both the Tenant data and the Subscription_Summary under an `active_subscription` key.
- **LambdaEvent**: The SDK's event wrapper class that provides typed access to path parameters, query parameters, headers, and body from API Gateway events.
- **ServiceResult**: The standard response wrapper used by all SDK services, containing `success`, `data`, `message`, and `metadata` fields.

## Requirements

### Requirement 1: Enriched Query Parameter

**User Story:** As a frontend developer, I want to control whether the tenant GET API returns enriched data, so that I can get the subscription summary by default but opt out when I only need basic tenant data.

#### Acceptance Criteria

1. THE Tenant_GET_Handler SHALL accept an `enriched` query parameter of type boolean.
2. WHEN the `enriched` query parameter is not provided, THE Tenant_GET_Handler SHALL default the enrichment behavior to `true`.
3. WHEN the `enriched` query parameter is set to `false`, THE Tenant_GET_Handler SHALL return only the Tenant data without any subscription information (current behavior).
4. WHEN the `enriched` query parameter is set to `true`, THE Tenant_GET_Handler SHALL include the Subscription_Summary in the response.

### Requirement 2: Subscription Summary Enrichment

**User Story:** As a frontend developer, I want the tenant GET response to include the active subscription summary, so that I can render the tenant dashboard without making a separate subscription API call.

#### Acceptance Criteria

1. WHEN enrichment is enabled and a Bound_Subscription exists, THE Tenant_GET_Handler SHALL include an `active_subscription` field in the response containing the Subscription_Summary.
2. THE Subscription_Summary SHALL include the following fields from the Bound_Subscription: `id`, `status`, `plan_code`, `plan_name`, `seat_count`, `billing_interval`, `price_cents`, `currency`, `current_period_start_utc_ts`, `current_period_end_utc_ts`, `is_trial`, `trial_ends_utc_ts`, and `cancel_at_period_end`.
3. WHEN enrichment is enabled and no Bound_Subscription exists (no active pointer or pointer references a missing subscription), THE Tenant_GET_Handler SHALL include `active_subscription` set to `null` in the response.
4. THE Tenant_GET_Handler SHALL retrieve the Bound_Subscription using `SubscriptionService.get_bound_subscription()`, which performs the O(1) pointer lookup.

### Requirement 3: Tenant Model Isolation

**User Story:** As a developer, I want the Tenant model to remain unchanged by this feature, so that subscription enrichment is a presentation concern handled at the handler/API layer.

#### Acceptance Criteria

1. THE Tenant model SHALL NOT be modified to include subscription fields or a subscription ID reference.
2. THE Tenant_GET_Handler SHALL perform the subscription lookup as a secondary call after retrieving the Tenant, keeping the Tenant_Service and Subscription_Service decoupled.
3. THE Tenant_Service `get_by_id()` method SHALL continue to return only Tenant data without subscription information.

### Requirement 4: Enrichment Failure Resilience

**User Story:** As a platform operator, I want the tenant GET API to return tenant data even if the subscription lookup fails, so that a subscription service issue does not break the tenant loading experience.

#### Acceptance Criteria

1. IF the `SubscriptionService.get_bound_subscription()` call fails (returns `success=False` or raises an exception), THEN THE Tenant_GET_Handler SHALL return the Tenant data with `active_subscription` set to `null`.
2. IF the subscription lookup fails, THEN THE Tenant_GET_Handler SHALL log the failure details including the tenant ID and the error message for operational debugging.
3. IF the subscription lookup fails, THEN THE Tenant_GET_Handler SHALL NOT return an error status code; the response SHALL remain a successful 200 response with the Tenant data.

### Requirement 5: Response Structure Consistency

**User Story:** As a frontend developer, I want the enriched response to follow the existing API response conventions, so that I can parse it using the same patterns as other API responses.

#### Acceptance Criteria

1. THE enriched response SHALL use the existing ServiceResult structure, with the Tenant data as the primary `data` payload and the Subscription_Summary included within the `metadata` field of the ServiceResult.
2. THE Subscription_Summary field names SHALL use snake_case to match the existing API response convention.
3. WHEN enrichment is disabled (`enriched=false`), THE response SHALL be identical to the current tenant GET response with no additional fields.

### Requirement 6: Subscription Summary Serialization

**User Story:** As a frontend developer, I want the subscription summary to contain only the fields I need for the dashboard, so that the response payload is concise and does not expose unnecessary internal subscription details.

#### Acceptance Criteria

1. THE Subscription_Summary SHALL be serialized as a flat dictionary containing only the fields defined in the Glossary (id, status, plan_code, plan_name, seat_count, billing_interval, price_cents, currency, current_period_start_utc_ts, current_period_end_utc_ts, is_trial, trial_ends_utc_ts, cancel_at_period_end).
2. THE Subscription_Summary SHALL NOT include internal fields such as DynamoDB keys (pk, sk), GSI key attributes, version, created_by_id, updated_by_id, or external billing provider IDs.
3. FOR ALL Subscription_Summary fields that are timestamps, THE Subscription_Summary SHALL represent the values as Unix epoch floats (matching the existing timestamp convention in the API).
