# Design Document: Tenant Enriched Subscription Response

## Overview

This feature enriches the tenant GET API response with an active subscription summary, eliminating the need for a separate API call to fetch subscription data. The enrichment is controlled by an `enriched` query parameter (defaulting to `true`) and is implemented entirely at the handler layer — the Tenant model and TenantService remain unchanged.

The design leverages the existing `SubscriptionService.get_bound_subscription()` method for O(1) active subscription lookup via the DynamoDB pointer pattern (`pk: "tenant#{tenant_id}"`, `sk: "subscription#active"`). Subscription lookup failures are handled gracefully — the tenant response is always returned, with `active_subscription` set to `null` on failure.

### Key Design Decisions

1. **Handler-layer enrichment only** — No changes to Tenant model, TenantService, or Subscription model. The enrichment logic lives in the GET handler's business logic function.
2. **ServiceResult.metadata for subscription data** — The subscription summary is placed in `ServiceResult.metadata["active_subscription"]`, keeping the primary `data` payload as the Tenant object. This requires a small enhancement to `service_result_to_response()` to include metadata in the HTTP response body.
3. **Fail-open on subscription errors** — Any subscription lookup failure (exception, `success=False`, missing pointer) results in `active_subscription: null` with a 200 response. Errors are logged for operational debugging.
4. **Summary extraction as a pure function** — A standalone `build_subscription_summary()` function extracts exactly 13 fields from a Subscription object into a flat dict. This is easily testable and reusable.

## Architecture

The enrichment follows a sequential two-step pattern within the existing handler framework:

```mermaid
sequenceDiagram
    participant Client
    participant Handler as Tenant GET Handler
    participant TS as TenantService
    participant SS as SubscriptionService
    participant DB as DynamoDB

    Client->>Handler: GET /tenants/{id}?enriched=true
    Handler->>TS: get_by_id(tenant_id)
    TS->>DB: GetItem(pk=tenant#id, sk=tenant#id)
    DB-->>TS: Tenant item
    TS-->>Handler: ServiceResult[Tenant]

    alt enriched=true
        Handler->>SS: get_bound_subscription()
        SS->>DB: GetItem(pk=tenant#id, sk=subscription#active)
        DB-->>SS: Pointer item (active_subscription_id)
        SS->>DB: GetItem(pk=subscription#sub_id, sk=subscription#sub_id)
        DB-->>SS: Subscription item
        SS-->>Handler: ServiceResult[Subscription]
        Handler->>Handler: build_subscription_summary(subscription)
    end

    Handler-->>Client: 200 { data: tenant, metadata: { active_subscription: summary } }
```

### Component Interaction

The handler orchestrates two independent service calls. The SubscriptionService is instantiated within the handler using the same DynamoDB connection and request context as the TenantService. This keeps the services decoupled — TenantService has no knowledge of subscriptions.

```mermaid
graph TD
    A[Tenant GET Handler] --> B[TenantService.get_by_id]
    A --> C[SubscriptionService.get_bound_subscription]
    A --> D[build_subscription_summary]
    B --> E[(DynamoDB)]
    C --> E
    D --> F[ServiceResult.metadata]
```

## Components and Interfaces

### 1. Modified: `get_tenant()` business logic function

**File:** `geek_cafe_saas_sdk/modules/tenancy/handlers/tenants/get/app.py`

The existing `get_tenant(event, service)` function is extended to:
1. Read the `enriched` query parameter (default `True`) via `event.query_bool("enriched", default=True)`
2. If enriched, instantiate a `SubscriptionService` using the same DynamoDB and table_name from the TenantService, plus the same `request_context`
3. Call `subscription_service.get_bound_subscription()`
4. On success with data, call `build_subscription_summary(subscription)` and attach to `ServiceResult.metadata["active_subscription"]`
5. On failure or no data, set `metadata["active_subscription"] = None`
6. Return the ServiceResult with tenant data and metadata

```python
def get_tenant(event: LambdaEvent, service: TenantService) -> ServiceResult:
    tenant_id = event.path("id", "tenantId")
    if not tenant_id:
        raise ValueError("Tenant ID is required in the path")

    result = service.get_by_id(tenant_id=tenant_id)
    if not result.success:
        return result

    enriched = event.query_bool("enriched", default=True)
    if enriched:
        result.metadata["active_subscription"] = _fetch_subscription_summary(service, tenant_id)

    return result
```

### 2. New: `_fetch_subscription_summary()` helper function

**File:** `geek_cafe_saas_sdk/modules/tenancy/handlers/tenants/get/app.py`

A private helper that encapsulates the subscription lookup with error handling:

```python
def _fetch_subscription_summary(tenant_service: TenantService, tenant_id: str) -> dict | None:
    try:
        subscription_service = SubscriptionService(
            dynamodb=tenant_service.dynamodb,
            table_name=tenant_service.table_name,
            request_context=tenant_service.request_context,
        )
        sub_result = subscription_service.get_bound_subscription()
        if sub_result.success and sub_result.data is not None:
            return build_subscription_summary(sub_result.data)
        return None
    except Exception as e:
        logger.warning("Subscription enrichment failed", extra={
            "tenant_id": tenant_id,
            "error": str(e),
        })
        return None
```

### 3. New: `build_subscription_summary()` pure function

**File:** `geek_cafe_saas_sdk/modules/tenancy/handlers/tenants/get/app.py`

A pure function that extracts exactly the 13 specified fields from a Subscription object into a flat dictionary:

```python
SUBSCRIPTION_SUMMARY_FIELDS = [
    "id", "status", "plan_code", "plan_name", "seat_count",
    "billing_interval", "price_cents", "currency",
    "current_period_start_utc_ts", "current_period_end_utc_ts",
    "is_trial", "trial_ends_utc_ts", "cancel_at_period_end",
]

def build_subscription_summary(subscription) -> dict:
    return {field: getattr(subscription, field) for field in SUBSCRIPTION_SUMMARY_FIELDS}
```

### 4. Modified: `service_result_to_response()` utility

**File:** `geek_cafe_saas_sdk/utilities/response.py`

The `service_result_to_response()` function currently does not include `ServiceResult.metadata` in the HTTP response body. A small change is needed to merge metadata into the response body when present:

```python
# In service_result_to_response(), after building the success body:
if hasattr(result, 'metadata') and result.metadata:
    if target_format and result.metadata:
        body["metadata"] = CaseConverter.convert_keys(result.metadata, target_format, preserve_fields=preserve_fields)
    else:
        body["metadata"] = result.metadata
```

This adds a top-level `metadata` key to the response body alongside `data`, `timestamp`, `success`, etc. The metadata values undergo the same case conversion as the rest of the response (e.g., `snake_case` → `camelCase` for JS clients).

### 5. Modified: `success_response()` utility

**File:** `geek_cafe_saas_sdk/utilities/response.py`

The `success_response()` function also needs a `metadata` parameter so that non-ServiceResult callers can include metadata:

```python
def success_response(
    data, status_code=200, message=None,
    convert_to_camel_case=True, start_time=None,
    preserve_fields=None, metadata=None,
) -> Dict[str, Any]:
    # ... existing body construction ...
    if metadata:
        if target_format:
            body["metadata"] = CaseConverter.convert_keys(metadata, target_format, preserve_fields=preserve_fields)
        else:
            body["metadata"] = metadata
    # ...
```

## Data Models

### Subscription Summary (Response DTO)

The subscription summary is a flat dictionary — not a new model class. It contains exactly these fields extracted from the `Subscription` model:

| Field | Type | Source Property | Description |
|-------|------|----------------|-------------|
| `id` | `str` | `Subscription.id` | Subscription ID |
| `status` | `str` | `Subscription.status` | Current status (active, trial, canceled, etc.) |
| `plan_code` | `str \| None` | `Subscription.plan_code` | Plan identifier code |
| `plan_name` | `str \| None` | `Subscription.plan_name` | Plan display name |
| `seat_count` | `int` | `Subscription.seat_count` | Number of seats |
| `billing_interval` | `str` | `Subscription.billing_interval` | month or year |
| `price_cents` | `int` | `Subscription.price_cents` | Price in cents |
| `currency` | `str` | `Subscription.currency` | Currency code (USD, EUR, etc.) |
| `current_period_start_utc_ts` | `float \| None` | `Subscription.current_period_start_utc_ts` | Period start (Unix epoch) |
| `current_period_end_utc_ts` | `float \| None` | `Subscription.current_period_end_utc_ts` | Period end (Unix epoch) |
| `is_trial` | `bool` | `Subscription.is_trial` | Whether in trial period |
| `trial_ends_utc_ts` | `float \| None` | `Subscription.trial_ends_utc_ts` | Trial end (Unix epoch) |
| `cancel_at_period_end` | `bool` | `Subscription.cancel_at_period_end` | Whether canceling at period end |

### Enriched Response Shape

When `enriched=true` (default):

```json
{
  "data": {
    "id": "tenant-123",
    "name": "Acme Corp",
    "status": "active",
    "planTier": "enterprise",
    "maxUsers": 50
  },
  "metadata": {
    "activeSubscription": {
      "id": "sub-456",
      "status": "active",
      "planCode": "enterprise",
      "planName": "Enterprise Plan",
      "seatCount": 50,
      "billingInterval": "year",
      "priceCents": 99900,
      "currency": "USD",
      "currentPeriodStartUtcTs": 1777491385.031,
      "currentPeriodEndUtcTs": 1809027385.031,
      "isTrial": false,
      "trialEndsUtcTs": null,
      "cancelAtPeriodEnd": false
    }
  },
  "success": true,
  "statusCode": 200,
  "timestamp": "2026-05-01T12:00:00+00:00"
}
```

When `enriched=false`:

```json
{
  "data": {
    "id": "tenant-123",
    "name": "Acme Corp",
    "status": "active",
    "planTier": "enterprise",
    "maxUsers": 50
  },
  "success": true,
  "statusCode": 200,
  "timestamp": "2026-05-01T12:00:00+00:00"
}
```

Note: Field names shown in camelCase above reflect the default response case conversion. The internal representation uses snake_case.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Subscription summary extraction preserves all specified fields

*For any* valid Subscription object with arbitrary field values, `build_subscription_summary(subscription)` SHALL produce a flat dictionary containing exactly the 13 specified fields (`id`, `status`, `plan_code`, `plan_name`, `seat_count`, `billing_interval`, `price_cents`, `currency`, `current_period_start_utc_ts`, `current_period_end_utc_ts`, `is_trial`, `trial_ends_utc_ts`, `cancel_at_period_end`), where each field's value equals the corresponding property on the Subscription object, and no other fields are present.

**Validates: Requirements 2.2, 6.1, 6.2, 6.3**

### Property 2: Subscription lookup failure always yields null subscription

*For any* error condition during subscription enrichment (exception raised, `ServiceResult.success=False`, missing pointer, missing subscription), the `_fetch_subscription_summary()` function SHALL return `None`, and the overall handler response SHALL be a successful 200 with the tenant data intact and `active_subscription` set to `null`.

**Validates: Requirements 4.1, 4.3**

### Property 3: Enriched response structure places subscription in metadata

*For any* tenant with an active subscription, when enrichment is enabled, the handler SHALL return a `ServiceResult` where `data` is the Tenant object (unchanged from `TenantService.get_by_id()`) and `metadata["active_subscription"]` is the subscription summary dict. The tenant `data` SHALL NOT contain any subscription fields.

**Validates: Requirements 2.1, 3.1, 5.1**

## Error Handling

### Subscription Lookup Failures

All subscription-related errors are caught and handled gracefully:

| Error Scenario | Handler Behavior | Response |
|---|---|---|
| `get_bound_subscription()` raises exception | Log warning with tenant_id and error, return `None` | 200 with `active_subscription: null` |
| `get_bound_subscription()` returns `success=False` | Return `None` (no log — service already logged) | 200 with `active_subscription: null` |
| No active pointer exists | `get_bound_subscription()` returns `success=True, data=None` → return `None` | 200 with `active_subscription: null` |
| Pointer exists but subscription is deleted/missing | `get_bound_subscription()` returns `success=False` (NotFoundError) | 200 with `active_subscription: null` |

### Tenant Lookup Failures

Tenant lookup failures are NOT affected by this feature. If `TenantService.get_by_id()` fails, the handler returns the error ServiceResult as before (404, 403, etc.). Subscription enrichment is only attempted after a successful tenant fetch.

### Logging

On subscription lookup failure, the handler logs at WARNING level:
```
Subscription enrichment failed | tenant_id=<id> | error=<message>
```

This provides operational visibility without polluting ERROR-level logs (since the failure is expected/handled).

## Testing Strategy

### Property-Based Tests (Hypothesis)

Property-based tests use the [Hypothesis](https://hypothesis.readthedocs.io/) library for Python. Each property test runs a minimum of 100 iterations with randomly generated inputs.

**Property 1: Summary extraction**
- Generate random Subscription objects using Hypothesis strategies (random strings for plan_code/plan_name, random ints for price_cents/seat_count, random floats for timestamps, random bools for is_trial/cancel_at_period_end)
- Call `build_subscription_summary(subscription)`
- Assert the result dict has exactly 13 keys matching `SUBSCRIPTION_SUMMARY_FIELDS`
- Assert each value equals `getattr(subscription, field)`
- Assert no extra keys are present
- Tag: **Feature: tenant-enriched-subscription-response, Property 1: Subscription summary extraction preserves all specified fields**

**Property 2: Failure resilience**
- Generate random exception types and error messages
- Mock `SubscriptionService.get_bound_subscription()` to raise the generated exception or return `ServiceResult(success=False, message=...)`
- Call `_fetch_subscription_summary()`
- Assert the return value is `None`
- Tag: **Feature: tenant-enriched-subscription-response, Property 2: Subscription lookup failure always yields null subscription**

**Property 3: Enriched response structure**
- Generate random Tenant and Subscription objects
- Mock services to return them
- Call `get_tenant()` with `enriched=true`
- Assert `result.data` is the Tenant object
- Assert `result.metadata["active_subscription"]` is a dict with 13 fields
- Assert the Tenant's `to_dictionary()` output contains no subscription keys
- Tag: **Feature: tenant-enriched-subscription-response, Property 3: Enriched response structure places subscription in metadata**

### Unit Tests (pytest)

Example-based tests for specific scenarios:

1. **Default enrichment** — Call handler with no `enriched` param → response includes `active_subscription`
2. **Explicit opt-out** — Call handler with `enriched=false` → response has no `metadata` key
3. **No active subscription** — Subscription pointer doesn't exist → `active_subscription: null`
4. **Subscription service exception** — Mock raises `Exception` → 200 response, `active_subscription: null`, warning logged
5. **Subscription service returns failure** — Mock returns `ServiceResult(success=False)` → `active_subscription: null`
6. **Tenant not found** — `get_by_id()` returns 404 → normal 404 error, no subscription lookup attempted
7. **Response case conversion** — Verify `active_subscription` fields are converted to camelCase in the HTTP response body
8. **TenantService.get_by_id unchanged** — Verify it still returns only Tenant data (regression)

### Integration Tests

1. **End-to-end with DynamoDB Local** — Create a tenant and subscription, bind them, call the GET handler, verify the enriched response contains correct subscription data
2. **End-to-end opt-out** — Same setup, call with `enriched=false`, verify no subscription data in response
