# Implementation Plan: Transient Storage Safeguards

## Overview

Implement runtime validation in the `geek-cafe-saas-sdk` that prevents accidental persistence of long-term data into transient (TTL-governed) DynamoDB tables and S3 buckets. The implementation adds a `StorageValidator` utility module, two new abstract base classes (`TransientServiceBase`, `LongTermServiceBase`), and integrates validation into the existing `TransientTableMixin`.

## Tasks

- [x] 1. Implement StorageValidator module
  - [x] 1.1 Create `src/geek_cafe_saas_sdk/core/services/storage_validator.py` with enums, exception, and core functions
    - Define `ResourceClassification`, `StorageIntent`, and `ValidationMode` enums (all `str, Enum`)
    - Implement `StorageMismatchError` exception with `resource_name`, `intent`, and `classification` attributes
    - Implement `classify_resource(resource_name)` — returns `TRANSIENT` if lowercase name contains `transient`, `LONG_TERM` otherwise; raises `ValueError` on `None`/empty/whitespace
    - Implement `get_validation_mode()` — reads `STORAGE_VALIDATION_MODE` env var, defaults to `enforce` if unset or unrecognized, logs warning for unrecognized values
    - Implement `validate_storage_access(resource_name, intent, context)` — classifies resource, compares to intent, raises `StorageMismatchError` in enforce mode or logs warning in warn mode
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 2.1, 2.2, 2.4, 3.1, 3.2, 6.1, 6.2, 6.3, 6.4, 6.5_

  - [x]* 1.2 Write property test: Classification correctness
    - **Property 1: Classification correctness**
    - Create `tests/test_storage_validator.py` with Hypothesis generators (`resource_names_with_transient`, `resource_names_without_transient`)
    - For any non-empty resource name, `classify_resource` returns `TRANSIENT` iff lowercase contains `transient`
    - Use `@settings(max_examples=100)`
    - **Validates: Requirements 1.1, 1.2, 1.4**

  - [x]* 1.3 Write property test: Empty and whitespace names rejected
    - **Property 2: Empty and whitespace names are rejected**
    - Generate whitespace-only strings (spaces, tabs, newlines) and `None`; assert `classify_resource` raises `ValueError`
    - Use `@settings(max_examples=100)`
    - **Validates: Requirements 1.3**

  - [x]* 1.4 Write property test: Matching intent passes validation
    - **Property 3: Matching intent passes validation**
    - For any resource name and aligned intent (transient intent + transient resource, long-term intent + long-term resource), `validate_storage_access` does not raise
    - Use `@settings(max_examples=100)`
    - **Validates: Requirements 2.3, 5.5, 5.6**

  - [x]* 1.5 Write property test: Mismatched intent raises in enforce mode
    - **Property 4: Mismatched intent raises StorageMismatchError in enforce mode**
    - For any resource name and misaligned intent, with `STORAGE_VALIDATION_MODE=enforce`, `validate_storage_access` raises `StorageMismatchError` with correct attributes
    - Use `@settings(max_examples=100)`
    - **Validates: Requirements 2.2, 2.4, 3.2, 5.7, 5.8, 6.2**

  - [x]* 1.6 Write property test: Warn mode allows mismatch
    - **Property 5: Warn mode allows mismatched operations without raising**
    - For any resource name and misaligned intent, with `STORAGE_VALIDATION_MODE=warn`, `validate_storage_access` does not raise
    - Use `@settings(max_examples=100)`
    - **Validates: Requirements 6.3**

  - [x]* 1.7 Write property test: Unrecognized mode defaults to enforce
    - **Property 6: Unrecognized validation mode defaults to enforce**
    - For any string that is not `enforce` or `warn`, `get_validation_mode` returns `ValidationMode.ENFORCE`
    - Use `@settings(max_examples=100)`
    - **Validates: Requirements 6.4, 6.5**

- [x] 2. Checkpoint - Ensure StorageValidator tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Integrate validation into TransientTableMixin
  - [x] 3.1 Update `src/geek_cafe_saas_sdk/core/services/transient_table_mixin.py` to call StorageValidator after resolving names
    - In `resolve_transient_table_name`: after resolving the name, call `classify_resource` and log a warning if the resolved name is not classified as `TRANSIENT`
    - In `resolve_transient_bucket`: after resolving the name, call `classify_resource` and log a warning if the resolved name is not classified as `TRANSIENT`
    - Preserve existing fallback behavior — validation adds warnings but does not change resolution logic
    - _Requirements: 4.1, 4.2, 4.3, 4.4_

  - [x]* 3.2 Write unit tests for TransientTableMixin validation integration
    - Add tests to `tests/test_transient_table_mixin_validation.py`
    - Test that `resolve_transient_table_name` logs warning when fallback resolves to non-transient name (Req 4.2)
    - Test that `resolve_transient_table_name` does not warn when resolved name is transient (Req 4.1)
    - Test that `resolve_transient_bucket` logs warning when fallback resolves to non-transient name (Req 4.4)
    - Test that `resolve_transient_bucket` does not warn when resolved name is transient (Req 4.3)
    - _Requirements: 4.1, 4.2, 4.3, 4.4_

- [x] 4. Implement TransientServiceBase
  - [x] 4.1 Create `src/geek_cafe_saas_sdk/core/services/transient_service_base.py`
    - Extend `DatabaseService[T]` and incorporate `TransientTableMixin`
    - In `__init__`, resolve transient table name via `resolve_transient_table_name` and validate with `validate_storage_access` using `StorageIntent.TRANSIENT`
    - Pass resolved table name to `DatabaseService.__init__`
    - _Requirements: 5.1, 5.3, 5.5_

  - [x]* 4.2 Write unit tests for TransientServiceBase
    - Add tests to `tests/test_transient_service_base.py`
    - Test that init resolves and validates transient table name
    - Test that init raises `StorageMismatchError` when resolved table is not transient (enforce mode)
    - Test that init succeeds when resolved table contains `transient`
    - _Requirements: 5.1, 5.5, 5.7_

- [x] 5. Implement LongTermServiceBase
  - [x] 5.1 Create `src/geek_cafe_saas_sdk/core/services/long_term_service_base.py`
    - Extend `DatabaseService[T]`
    - In `__init__`, validate that the provided table name is classified as `LONG_TERM` using `validate_storage_access` with `StorageIntent.LONG_TERM`
    - Pass table name to `DatabaseService.__init__`
    - _Requirements: 5.2, 5.4, 5.6_

  - [x]* 5.2 Write unit tests for LongTermServiceBase
    - Add tests to `tests/test_long_term_service_base.py`
    - Test that init validates long-term table name
    - Test that init raises `StorageMismatchError` when table name contains `transient` (enforce mode)
    - Test that init succeeds when table name does not contain `transient`
    - _Requirements: 5.2, 5.6, 5.8_

- [x] 6. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Wire components together and export public API
  - [x] 7.1 Update `src/geek_cafe_saas_sdk/core/services/__init__.py` to export new classes
    - Export `StorageValidator` functions and types (`classify_resource`, `validate_storage_access`, `get_validation_mode`, `ResourceClassification`, `StorageIntent`, `ValidationMode`, `StorageMismatchError`)
    - Export `TransientServiceBase` and `LongTermServiceBase`
    - _Requirements: 1.1, 5.1, 5.2_

  - [x]* 7.2 Write integration tests for crossover service pattern
    - Add tests to `tests/test_crossover_service_pattern.py`
    - Test that a crossover service composing a `TransientServiceBase` reader and `LongTermServiceBase` writer works correctly
    - Test that transient reader can access transient resources and long-term writer can access long-term resources
    - Test that transient reader is blocked from long-term resources and vice versa
    - _Requirements: 3.3, 3.4, 5.3, 5.4, 5.7, 5.8_

- [x] 8. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document using Hypothesis
- Unit tests validate specific examples, integration points, and edge cases
- All code targets Python; use `source geek-cafe-saas-sdk/.venv/bin/activate` before running tests
