# Requirements Document

## Introduction

The platform uses two tiers of storage: **transient** (short-lived, TTL-governed DynamoDB tables and S3 buckets for intermediate pipeline data like profile splitting and calculations) and **long-term** (permanent DynamoDB tables and S3 buckets for final results, user files, and audit records). Several services — notably the Output Service and Package Manager — legitimately cross over between the two tiers, reading intermediate results from transient storage and writing final outputs to long-term storage.

Today there is no runtime safeguard preventing a developer from accidentally persisting long-term data (e.g., final output files, user records) into a transient resource where it would be silently deleted by TTL. This feature introduces name-based validation that detects and prevents such misuse at the SDK level, starting with a simple heuristic: checking whether the string `transient` appears in the DynamoDB table name or S3 bucket name.

## Glossary

- **Transient_Resource**: A DynamoDB table or S3 bucket whose name contains the substring `transient`, intended for ephemeral pipeline data with a TTL lifecycle.
- **Long_Term_Resource**: A DynamoDB table or S3 bucket whose name does not contain the substring `transient`, intended for permanent data storage.
- **Storage_Validator**: A utility module in the SDK that inspects resource names and classifies them as transient or long-term, and enforces placement rules.
- **TransientTableMixin**: The existing SDK mixin class (`geek_cafe_saas_sdk.core.services.transient_table_mixin`) that resolves transient DynamoDB table names and S3 bucket names from environment variables.
- **DatabaseService**: The base SDK service class (`geek_cafe_saas_sdk.core.services.database_service`) that all DynamoDB-backed services extend.
- **Crossover_Service**: A service that legitimately operates on both transient and long-term storage (e.g., Output Service batch merger, Package Manager), composed of dedicated transient and long-term service classes.
- **TransientServiceBase**: An abstract base class that Crossover_Services extend for operations explicitly intended to target Transient_Resource storage.
- **LongTermServiceBase**: An abstract base class that Crossover_Services extend for operations explicitly intended to target Long_Term_Resource storage.
- **Resource_Classification**: The act of determining whether a given resource name refers to a Transient_Resource or a Long_Term_Resource based on naming conventions.

## Requirements

### Requirement 1: Resource Name Classification

**User Story:** As a developer, I want a utility that classifies a DynamoDB table name or S3 bucket name as transient or long-term based on its name, so that I can programmatically determine the storage tier of any resource.

#### Acceptance Criteria

1. WHEN a resource name containing the substring `transient` (case-insensitive) is provided, THE Storage_Validator SHALL classify the resource as a Transient_Resource.
2. WHEN a resource name not containing the substring `transient` is provided, THE Storage_Validator SHALL classify the resource as a Long_Term_Resource.
3. IF an empty or null resource name is provided, THEN THE Storage_Validator SHALL raise a ValueError with a descriptive message.
4. THE Storage_Validator SHALL support classification of both DynamoDB table names and S3 bucket names using the same naming convention check.

### Requirement 2: Prevent Long-Term Data in Transient Storage

**User Story:** As a platform operator, I want the SDK to prevent long-term data models from being saved to transient DynamoDB tables, so that important data is not silently lost when TTL expiration occurs.

#### Acceptance Criteria

1. WHEN a service attempts to save a model to a DynamoDB table, THE Storage_Validator SHALL verify that the table name classification matches the intended data lifecycle.
2. IF a non-transient data model is saved to a table classified as a Transient_Resource, THEN THE Storage_Validator SHALL raise a StorageMismatchError with a message identifying the table name and model type.
3. WHILE a service inherits from TransientTableMixin, THE Storage_Validator SHALL permit saves to Transient_Resource tables without raising an error.
4. WHEN a service does not inherit from TransientTableMixin and targets a Transient_Resource table, THE Storage_Validator SHALL raise a StorageMismatchError.

### Requirement 3: Prevent Long-Term Data in Transient S3 Buckets

**User Story:** As a platform operator, I want the SDK to prevent final output files from being written to transient S3 buckets, so that permanent artifacts are not lost to lifecycle policies.

#### Acceptance Criteria

1. WHEN a file write operation targets an S3 bucket, THE Storage_Validator SHALL verify that the bucket name classification matches the intended data lifecycle.
2. IF a final output file is written to a bucket classified as a Transient_Resource, THEN THE Storage_Validator SHALL raise a StorageMismatchError with a message identifying the bucket name and operation context.
3. WHILE a Crossover_Service reads intermediate data from a Transient_Resource bucket, THE Storage_Validator SHALL permit the read operation without raising an error.
4. WHEN a Crossover_Service writes final output to a Long_Term_Resource bucket after reading from a Transient_Resource bucket, THE Storage_Validator SHALL permit the write operation without raising an error.

### Requirement 4: Validation Integration with TransientTableMixin

**User Story:** As a developer, I want the transient resource resolution methods to include validation, so that misconfigured environment variables are caught early.

#### Acceptance Criteria

1. WHEN `resolve_transient_table_name` resolves a table name, THE TransientTableMixin SHALL validate that the resolved name is classified as a Transient_Resource.
2. IF `resolve_transient_table_name` resolves to a table name not classified as a Transient_Resource (fallback to main table), THEN THE TransientTableMixin SHALL log a warning indicating the resolved table is not a dedicated transient table.
3. WHEN `resolve_transient_bucket` resolves a bucket name, THE TransientTableMixin SHALL validate that the resolved name is classified as a Transient_Resource.
4. IF `resolve_transient_bucket` resolves to a bucket name not classified as a Transient_Resource (fallback to workload bucket), THEN THE TransientTableMixin SHALL log a warning indicating the resolved bucket is not a dedicated transient bucket.

### Requirement 5: Explicit Intent Through Dedicated Service Classes for Crossover Services

**User Story:** As a developer working on the Output Service or Package Manager, I want dedicated service classes for transient work and long-term work, so that each operation's storage intent is clear through the type system rather than bypassing validation.

#### Acceptance Criteria

1. THE SDK SHALL provide a TransientServiceBase class that Crossover_Services extend for operations targeting Transient_Resource storage.
2. THE SDK SHALL provide a LongTermServiceBase class that Crossover_Services extend for operations targeting Long_Term_Resource storage.
3. WHEN a Crossover_Service performs transient operations, THE Crossover_Service SHALL delegate those operations to its TransientServiceBase subclass.
4. WHEN a Crossover_Service performs long-term operations, THE Crossover_Service SHALL delegate those operations to its LongTermServiceBase subclass.
5. THE Storage_Validator SHALL permit TransientServiceBase subclasses to access Transient_Resource storage without raising a StorageMismatchError.
6. THE Storage_Validator SHALL permit LongTermServiceBase subclasses to access Long_Term_Resource storage without raising a StorageMismatchError.
7. IF a TransientServiceBase subclass attempts to write to a Long_Term_Resource, THEN THE Storage_Validator SHALL raise a StorageMismatchError.
8. IF a LongTermServiceBase subclass attempts to write to a Transient_Resource, THEN THE Storage_Validator SHALL raise a StorageMismatchError.

### Requirement 6: Validation Mode Configuration

**User Story:** As a platform operator, I want to control whether storage validation raises errors or only logs warnings, so that I can roll out the safeguards gradually without breaking existing deployments.

#### Acceptance Criteria

1. THE Storage_Validator SHALL support two validation modes: `enforce` (raise errors on mismatch) and `warn` (log warnings on mismatch without raising errors).
2. WHEN the `STORAGE_VALIDATION_MODE` environment variable is set to `enforce`, THE Storage_Validator SHALL raise StorageMismatchError on detected mismatches.
3. WHEN the `STORAGE_VALIDATION_MODE` environment variable is set to `warn`, THE Storage_Validator SHALL log a warning on detected mismatches and allow the operation to proceed.
4. WHEN the `STORAGE_VALIDATION_MODE` environment variable is not set, THE Storage_Validator SHALL default to `enforce` mode.
5. IF the `STORAGE_VALIDATION_MODE` environment variable contains an unrecognized value, THEN THE Storage_Validator SHALL default to `enforce` mode and log a warning about the invalid configuration.
