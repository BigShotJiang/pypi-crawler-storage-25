# Design Document: Transient Storage Safeguards

## Overview

This feature adds runtime validation to the `geek-cafe-saas-sdk` that prevents accidental persistence of long-term data into transient (TTL-governed) DynamoDB tables and S3 buckets. The core mechanism is a `StorageValidator` utility that classifies resource names by checking for the substring `transient` (case-insensitive) and enforces that a service's declared storage intent matches the resource it targets.

Two new abstract base classes — `TransientServiceBase` and `LongTermServiceBase` — make storage intent explicit through the type system. Crossover services (e.g., Output Service, Package Manager) compose these rather than bypassing validation. A configurable validation mode (`enforce` vs `warn`) controlled by the `STORAGE_VALIDATION_MODE` environment variable allows gradual rollout.

### Key Design Decisions

1. **Name-based heuristic over metadata lookup**: Checking for `transient` in the resource name is simple, fast, zero-dependency, and matches the existing naming convention. No DynamoDB DescribeTable or S3 GetBucketTagging calls needed.
2. **Composition over inheritance for crossover services**: Rather than a single service with an opt-out flag, crossover services compose a `TransientServiceBase` subclass and a `LongTermServiceBase` subclass. This makes intent visible in the type hierarchy.
3. **Validation at the SDK level**: Validation lives in the SDK so all downstream services (Output Service, Calc Engine, Orchestration, etc.) get protection without individual changes.
4. **Default to `enforce` mode**: New validation defaults to enforcing errors so misconfigurations are caught early. Teams can opt into `warn` mode during migration if needed.

## Architecture

```mermaid
graph TD
    subgraph SDK Core
        SV[StorageValidator]
        SME[StorageMismatchError]
        TSB[TransientServiceBase]
        LTSB[LongTermServiceBase]
        TTM[TransientTableMixin]
        DS[DatabaseService]
    end

    TSB -->|extends| DS
    TSB -->|uses| TTM
    TSB -->|validated by| SV
    LTSB -->|extends| DS
    LTSB -->|validated by| SV
    TTM -->|calls| SV

    subgraph Downstream Services
        BRS[BatchRecordService]
        CS[CoordinationService]
        EFS[ExecutionFileService]
        COS[Crossover OutputService]
    end

    BRS -->|extends| TSB
    CS -->|extends| TSB
    EFS -->|extends| TSB
    COS -->|composes| TSB
    COS -->|composes| LTSB

    SV -->|raises| SME
    SV -->|reads| ENV[STORAGE_VALIDATION_MODE]
```

### Validation Flow

```mermaid
sequenceDiagram
    participant Service
    participant StorageValidator
    participant Logger
    participant Operation

    Service->>StorageValidator: validate_storage_access(resource_name, service_intent)
    StorageValidator->>StorageValidator: classify_resource(resource_name)
    alt Classification matches intent
        StorageValidator-->>Service: OK (no-op)
        Service->>Operation: proceed
    else Mismatch detected
        alt STORAGE_VALIDATION_MODE = enforce (default)
            StorageValidator-->>Service: raise StorageMismatchError
        else STORAGE_VALIDATION_MODE = warn
            StorageValidator->>Logger: log warning
            StorageValidator-->>Service: OK (allow)
            Service->>Operation: proceed
        end
    end
```

## Components and Interfaces

### 1. StorageValidator (`geek_cafe_saas_sdk.core.services.storage_validator`)

A stateless utility module with pure functions for resource classification and validation.

```python
from enum import Enum
from typing import Optional

class ResourceClassification(str, Enum):
    """Classification of a storage resource based on its name."""
    TRANSIENT = "transient"
    LONG_TERM = "long_term"

class StorageIntent(str, Enum):
    """Declared intent of a service regarding storage tier."""
    TRANSIENT = "transient"
    LONG_TERM = "long_term"

class ValidationMode(str, Enum):
    """How the validator responds to mismatches."""
    ENFORCE = "enforce"
    WARN = "warn"

class StorageMismatchError(Exception):
    """Raised when a service's storage intent doesn't match the target resource."""
    def __init__(self, message: str, resource_name: str, intent: StorageIntent, classification: ResourceClassification):
        super().__init__(message)
        self.resource_name = resource_name
        self.intent = intent
        self.classification = classification

def classify_resource(resource_name: str) -> ResourceClassification:
    """Classify a resource name as transient or long-term.
    
    Args:
        resource_name: DynamoDB table name or S3 bucket name.
    
    Returns:
        ResourceClassification.TRANSIENT if 'transient' appears in the name (case-insensitive),
        ResourceClassification.LONG_TERM otherwise.
    
    Raises:
        ValueError: If resource_name is None or empty/whitespace.
    """
    ...

def get_validation_mode() -> ValidationMode:
    """Read STORAGE_VALIDATION_MODE from environment.
    
    Returns ValidationMode.ENFORCE if unset or unrecognized.
    """
    ...

def validate_storage_access(
    resource_name: str,
    intent: StorageIntent,
    context: Optional[str] = None,
) -> None:
    """Validate that a resource name matches the declared storage intent.
    
    Args:
        resource_name: The DynamoDB table or S3 bucket name.
        intent: The service's declared storage intent.
        context: Optional description for error messages (e.g., model type, operation).
    
    Raises:
        StorageMismatchError: In enforce mode when intent doesn't match classification.
    """
    ...
```

### 2. TransientServiceBase (`geek_cafe_saas_sdk.core.services.transient_service_base`)

Abstract base class for services that explicitly target transient storage. Extends `DatabaseService` and incorporates `TransientTableMixin`.

```python
from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from geek_cafe_saas_sdk.core.services.transient_table_mixin import TransientTableMixin

class TransientServiceBase(DatabaseService[T], TransientTableMixin):
    """Base class for services targeting transient DynamoDB tables.
    
    Resolves the transient table name via TransientTableMixin and validates
    that the resolved name is classified as a transient resource.
    """
    
    def __init__(self, *, dynamodb=None, table_name=None, request_context=None, **kwargs):
        resolved_table = self.resolve_transient_table_name(fallback_table_name=table_name)
        # Validate: resolved table must be transient
        validate_storage_access(resolved_table, StorageIntent.TRANSIENT, context=type(self).__name__)
        super().__init__(dynamodb=dynamodb, table_name=resolved_table, request_context=request_context, **kwargs)
```

### 3. LongTermServiceBase (`geek_cafe_saas_sdk.core.services.long_term_service_base`)

Abstract base class for services that explicitly target long-term storage.

```python
from geek_cafe_saas_sdk.core.services.database_service import DatabaseService

class LongTermServiceBase(DatabaseService[T]):
    """Base class for services targeting long-term DynamoDB tables.
    
    Validates that the table name is NOT classified as transient.
    """
    
    def __init__(self, *, dynamodb=None, table_name=None, request_context=None, **kwargs):
        # Validate: table must NOT be transient
        if table_name:
            validate_storage_access(table_name, StorageIntent.LONG_TERM, context=type(self).__name__)
        super().__init__(dynamodb=dynamodb, table_name=table_name, request_context=request_context, **kwargs)
```

### 4. Enhanced TransientTableMixin

The existing `TransientTableMixin` is updated to call `StorageValidator` after resolving names, logging warnings when a fallback resolves to a non-transient resource.

```python
# In resolve_transient_table_name, after resolution:
classification = classify_resource(resolved_name)
if classification != ResourceClassification.TRANSIENT:
    logger.warning(f"Resolved transient table '{resolved_name}' is not classified as transient")

# Same pattern in resolve_transient_bucket
```

### 5. File Path Summary

| File | Purpose |
|------|---------|
| `src/geek_cafe_saas_sdk/core/services/storage_validator.py` | `StorageValidator` functions, enums, `StorageMismatchError` |
| `src/geek_cafe_saas_sdk/core/services/transient_service_base.py` | `TransientServiceBase` abstract class |
| `src/geek_cafe_saas_sdk/core/services/long_term_service_base.py` | `LongTermServiceBase` abstract class |
| `src/geek_cafe_saas_sdk/core/services/transient_table_mixin.py` | Updated with validation calls |
| `tests/test_storage_validator.py` | Unit + property tests for StorageValidator |
| `tests/test_transient_service_base.py` | Tests for TransientServiceBase |
| `tests/test_long_term_service_base.py` | Tests for LongTermServiceBase |


## Data Models

### Enums

```python
class ResourceClassification(str, Enum):
    TRANSIENT = "transient"
    LONG_TERM = "long_term"

class StorageIntent(str, Enum):
    TRANSIENT = "transient"
    LONG_TERM = "long_term"

class ValidationMode(str, Enum):
    ENFORCE = "enforce"
    WARN = "warn"
```

### Exception

```python
class StorageMismatchError(Exception):
    """Raised when storage intent doesn't match resource classification."""
    resource_name: str          # The table/bucket name that caused the mismatch
    intent: StorageIntent       # What the service declared
    classification: ResourceClassification  # What the name resolved to
```

### Environment Variables

| Variable | Values | Default | Description |
|----------|--------|---------|-------------|
| `STORAGE_VALIDATION_MODE` | `enforce`, `warn` | `enforce` | Controls whether mismatches raise errors or log warnings |
| `DYNAMODB_TRANSIENT_TABLE_NAME` | string | (none) | Existing env var for transient DynamoDB table |
| `S3_TRANSIENT_BUCKET` | string | (none) | Existing env var for transient S3 bucket |

### Class Hierarchy (Updated)

```
DatabaseService[T]
├── LongTermServiceBase[T]          # NEW — validates long-term intent
├── TransientServiceBase[T]         # NEW — validates transient intent
│   (also mixes in TransientTableMixin)
│   ├── BatchRecordService          # MIGRATED from DatabaseService+TransientTableMixin
│   ├── CoordinationService         # MIGRATED from DatabaseService+TransientTableMixin
│   └── ExecutionFileService        # MIGRATED from DatabaseService+TransientTableMixin
```

For crossover services (e.g., Output Service batch merger):

```
OutputBatchMerger
├── _transient_reader: TransientServiceBase subclass   # reads from transient
└── _long_term_writer: LongTermServiceBase subclass    # writes to long-term
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Classification correctness

*For any* non-empty resource name string, `classify_resource` returns `TRANSIENT` if and only if the lowercase form of the string contains the substring `transient`. Otherwise it returns `LONG_TERM`.

**Validates: Requirements 1.1, 1.2, 1.4**

### Property 2: Empty and whitespace names are rejected

*For any* string composed entirely of whitespace characters (including the empty string), and for `None`, `classify_resource` shall raise a `ValueError`.

**Validates: Requirements 1.3**

### Property 3: Matching intent passes validation

*For any* resource name and storage intent where the intent matches the resource classification (transient intent + transient resource, or long-term intent + long-term resource), `validate_storage_access` shall not raise any exception regardless of validation mode.

**Validates: Requirements 2.3, 5.5, 5.6**

### Property 4: Mismatched intent raises StorageMismatchError in enforce mode

*For any* resource name and storage intent where the intent does NOT match the resource classification, when `STORAGE_VALIDATION_MODE` is `enforce`, `validate_storage_access` shall raise a `StorageMismatchError` whose `resource_name`, `intent`, and `classification` attributes match the inputs.

**Validates: Requirements 2.2, 2.4, 3.2, 5.7, 5.8, 6.2**

### Property 5: Warn mode allows mismatched operations without raising

*For any* resource name and storage intent where the intent does NOT match the resource classification, when `STORAGE_VALIDATION_MODE` is `warn`, `validate_storage_access` shall NOT raise an exception.

**Validates: Requirements 6.3**

### Property 6: Unrecognized validation mode defaults to enforce

*For any* string value of `STORAGE_VALIDATION_MODE` that is not exactly `enforce` or `warn`, `get_validation_mode` shall return `ValidationMode.ENFORCE`.

**Validates: Requirements 6.4, 6.5**

## Error Handling

### StorageMismatchError

Raised when a service's declared storage intent conflicts with the target resource's classification. Contains structured fields (`resource_name`, `intent`, `classification`) for programmatic handling.

**When raised (enforce mode only):**
- `TransientServiceBase` initialized with a non-transient table name
- `LongTermServiceBase` initialized with a transient table name
- `validate_storage_access` called with mismatched intent/classification

**When suppressed (warn mode):**
- Same scenarios as above, but a warning is logged via `aws_lambda_powertools.Logger` and the operation proceeds.

### ValueError

Raised by `classify_resource` when given `None`, empty string, or whitespace-only string. This is a programming error — resource names should always be non-empty.

### Graceful Degradation

- If `STORAGE_VALIDATION_MODE` is unset → defaults to `enforce` (catches misconfigurations early)
- If `STORAGE_VALIDATION_MODE` has an unrecognized value → defaults to `enforce` and logs a warning about the invalid config
- Existing services that don't use the new base classes continue to work unchanged
- The `TransientTableMixin` fallback behavior is preserved; validation adds warnings but doesn't change resolution logic

## Testing Strategy

### Property-Based Testing

Use **Hypothesis** (already in `requirements.dev.txt`) for property-based tests. Each property from the Correctness Properties section maps to a single Hypothesis test.

**Configuration:**
- Minimum 100 examples per property test (`@settings(max_examples=100)`)
- Each test tagged with a comment: `# Feature: transient-storage-safeguards, Property N: <title>`

**Generators needed:**
- `resource_names_with_transient()`: Generates strings guaranteed to contain "transient" in random case positions (e.g., `"my-TRANSIENT-table"`, `"data_Transient_bucket"`)
- `resource_names_without_transient()`: Generates strings guaranteed NOT to contain "transient" (e.g., `"my-permanent-table"`, `"prod-data-bucket"`)
- `whitespace_strings()`: Generates strings of only whitespace characters (spaces, tabs, newlines)
- `storage_intent()`: Generates random `StorageIntent` values
- `invalid_mode_strings()`: Generates strings that are not `"enforce"` or `"warn"`

**Property tests (6 tests):**

| Test | Property | Description |
|------|----------|-------------|
| `test_classification_correctness` | Property 1 | Random names → classification matches substring check |
| `test_empty_whitespace_rejected` | Property 2 | Whitespace/empty strings → ValueError |
| `test_matching_intent_passes` | Property 3 | Aligned intent+resource → no exception |
| `test_mismatch_raises_in_enforce` | Property 4 | Misaligned intent+resource in enforce → StorageMismatchError |
| `test_warn_mode_allows_mismatch` | Property 5 | Misaligned intent+resource in warn → no exception |
| `test_unrecognized_mode_defaults_enforce` | Property 6 | Random non-enforce/warn string → ValidationMode.ENFORCE |

### Unit Tests

Unit tests cover specific examples, integration points, and edge cases not suited to property testing:

- `TransientTableMixin` logs warning when fallback resolves to non-transient name (Req 4.2, 4.4)
- `TransientTableMixin` does not warn when resolved name is transient (Req 4.1, 4.3)
- `TransientServiceBase.__init__` resolves and validates transient table (integration)
- `LongTermServiceBase.__init__` validates long-term table (integration)
- Crossover service pattern: transient reader + long-term writer compose correctly (Req 3.3, 3.4)
- `StorageMismatchError` attributes are populated correctly
- `STORAGE_VALIDATION_MODE` unset defaults to enforce (Req 6.4)
- `get_validation_mode` logs warning for unrecognized value (Req 6.5)
