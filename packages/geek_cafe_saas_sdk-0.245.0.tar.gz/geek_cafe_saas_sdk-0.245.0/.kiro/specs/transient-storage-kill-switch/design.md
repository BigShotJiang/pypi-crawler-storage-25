# Design Document: Transient Storage Kill Switch

## Overview

This feature adds a master kill switch — the `TRANSIENT_STORAGE_ENABLED` environment variable — to the SDK's `TransientTableMixin`. When set to `false`, the mixin's `resolve_transient_table_name()` and `resolve_transient_bucket()` methods bypass transient resource resolution entirely and return the main (long-term) DynamoDB table and S3 bucket. This ensures every service in the pipeline reads and writes from the same resources, eliminating the partial-configuration problem where some services target transient storage and others don't.

The kill switch operates at the lowest resolution layer (`TransientTableMixin`) so that all consumers — `TransientServiceBase`, downstream step handlers, output service handlers — inherit the behavior automatically. When disabled, `TransientServiceBase` also skips its `validate_storage_access()` call to avoid a false `StorageMismatchError` (the resolved table is intentionally long-term).

### Key Design Decisions

1. **Single static method `is_transient_storage_enabled()`**: A new static method on `TransientTableMixin` encapsulates the env-var parsing. All branching in `resolve_transient_table_name()`, `resolve_transient_bucket()`, and `TransientServiceBase.__init__` calls this one method. No duplicated parsing logic.

2. **Default to `true` (enabled)**: When `TRANSIENT_STORAGE_ENABLED` is unset, the kill switch defaults to enabled. This preserves 100% backward compatibility — existing deployments that don't set the variable behave identically to today.

3. **Modify existing methods, don't add new ones**: The kill switch adds an early-return path at the top of `resolve_transient_table_name()` and `resolve_transient_bucket()`. No new method signatures, no new parameters. Callers don't change at all.

4. **Skip validation, don't reconfigure it**: When disabled, `TransientServiceBase` skips `validate_storage_access()` entirely rather than switching the intent to `LONG_TERM`. The resolved table *is* the main table — validating it as transient would fail, and validating it as long-term is pointless since we know it's correct by construction.

5. **CDK passes the env var as a static value**: `TRANSIENT_STORAGE_ENABLED` is added to Lambda configs with a literal `"value"` field (no `"transform": true`), so `EnvironmentServices` passes it through without needing a new match case.

## Architecture

```mermaid
graph TD
    subgraph "TransientTableMixin (SDK)"
        ITSE["is_transient_storage_enabled()"]
        RTTN["resolve_transient_table_name()"]
        RTB["resolve_transient_bucket()"]
    end

    subgraph "TransientServiceBase (SDK)"
        TSB_INIT["__init__()"]
    end

    subgraph "Environment"
        ENV_KS["TRANSIENT_STORAGE_ENABLED"]
        ENV_TT["DYNAMODB_TRANSIENT_TABLE_NAME"]
        ENV_TB["S3_TRANSIENT_BUCKET"]
        ENV_MT["DYNAMODB_TABLE_NAME"]
        ENV_MB["S3_BUCKET"]
    end

    ITSE -->|reads| ENV_KS
    RTTN -->|calls| ITSE
    RTB -->|calls| ITSE
    TSB_INIT -->|calls| ITSE
    TSB_INIT -->|calls| RTTN

    RTTN -->|"enabled=true"| ENV_TT
    RTTN -->|"enabled=false"| ENV_MT
    RTB -->|"enabled=true"| ENV_TB
    RTB -->|"enabled=false"| ENV_MB
    TSB_INIT -->|"enabled=true"| SV["validate_storage_access()"]
    TSB_INIT -->|"enabled=false"| SKIP["skip validation"]
```

### Resolution Flow When Kill Switch Is Disabled

```mermaid
sequenceDiagram
    participant Caller
    participant TTM as TransientTableMixin
    participant TSB as TransientServiceBase
    participant SV as StorageValidator

    Note over Caller,SV: resolve_transient_table_name() with kill switch OFF
    Caller->>TTM: resolve_transient_table_name(fallback_table_name)
    TTM->>TTM: is_transient_storage_enabled() → False
    TTM->>TTM: resolve main table from fallback or DYNAMODB_TABLE_NAME
    TTM-->>Caller: main_table_name (no transient env var checked)

    Note over Caller,SV: TransientServiceBase.__init__ with kill switch OFF
    TSB->>TTM: resolve_transient_table_name(fallback)
    TTM-->>TSB: main_table_name
    TSB->>TTM: is_transient_storage_enabled() → False
    Note over TSB: Skip validate_storage_access()
    TSB->>TSB: super().__init__(table_name=main_table_name)
```

## Components and Interfaces

### 1. `TransientTableMixin.is_transient_storage_enabled()` (New)

A static method that reads `TRANSIENT_STORAGE_ENABLED` from the environment and returns a boolean.

```python
@staticmethod
def is_transient_storage_enabled() -> bool:
    """Check whether transient storage is active.

    Reads the ``TRANSIENT_STORAGE_ENABLED`` environment variable.

    Returns:
        ``True`` when the variable is unset, empty, ``'true'``
        (case-insensitive), or any unrecognized value (with a warning).
        ``False`` only when the variable is exactly ``'false'``
        (case-insensitive).
    """
    raw = os.getenv("TRANSIENT_STORAGE_ENABLED", "").strip().lower()
    if raw == "false":
        return False
    if raw in ("", "true"):
        return True
    # Unrecognized value — default to enabled, warn operator
    logger.warning(
        "Unrecognized TRANSIENT_STORAGE_ENABLED value '%s'; defaulting to true",
        raw,
    )
    return True
```

### 2. Modified `resolve_transient_table_name()` 

An early-return block is added at the top of the existing method. When disabled, it resolves the main table from `fallback_table_name`, `DYNAMODB_TABLE_NAME`, or `TABLE_NAME` — and skips the `classify_resource()` warning check.

```python
@staticmethod
def resolve_transient_table_name(
    fallback_table_name: Optional[str] = None,
) -> str:
    # --- Kill switch check ---
    if not TransientTableMixin.is_transient_storage_enabled():
        resolved = (
            fallback_table_name
            or os.getenv("DYNAMODB_TABLE_NAME")
            or os.getenv("TABLE_NAME")
        )
        if not resolved:
            raise ValueError(
                "Transient storage is disabled but no main table name available. "
                "Set DYNAMODB_TABLE_NAME or provide fallback_table_name."
            )
        logger.info(
            "Transient storage disabled — using main table '%s'", resolved
        )
        return resolved

    # --- Existing resolution logic (unchanged) ---
    ...
```

### 3. Modified `resolve_transient_bucket()`

Same pattern — early return when disabled, resolving from `fallback_bucket`, `S3_BUCKET`, or `FILE_SYSTEM_BUCKET`.

```python
@staticmethod
def resolve_transient_bucket(fallback_bucket: Optional[str] = None) -> str:
    # --- Kill switch check ---
    if not TransientTableMixin.is_transient_storage_enabled():
        resolved = (
            fallback_bucket
            or os.getenv("S3_BUCKET")
            or os.getenv("FILE_SYSTEM_BUCKET")
        )
        if not resolved:
            logger.info(
                "Transient storage disabled — no main bucket available"
            )
            return ""
        logger.info(
            "Transient storage disabled — using main bucket '%s'", resolved
        )
        return resolved

    # --- Existing resolution logic (unchanged) ---
    ...
```

### 4. Modified `TransientServiceBase.__init__()`

Skips `validate_storage_access()` when the kill switch is disabled.

```python
def __init__(self, *, dynamodb=None, table_name=None, request_context, 
             audit_logger=None, retry_config=None, **kwargs):
    resolved_table = self.resolve_transient_table_name(
        fallback_table_name=table_name,
    )
    # Only validate when transient storage is active — when disabled,
    # the resolved table is intentionally the main (long-term) table.
    if self.is_transient_storage_enabled():
        validate_storage_access(
            resolved_table,
            StorageIntent.TRANSIENT,
            context=type(self).__name__,
        )
    super().__init__(
        dynamodb=dynamodb,
        table_name=resolved_table,
        request_context=request_context,
        audit_logger=audit_logger,
        retry_config=retry_config,
    )
```

### 5. CDK Lambda Config Changes

Add `TRANSIENT_STORAGE_ENABLED` to each relevant Lambda config's `environment_variables` array. Since the value is provided directly (no `"transform": true`), `EnvironmentServices.load_environment_variables()` passes it through as-is via the existing `if value is None or transform:` guard — no code change needed in `environment_services.py`.

```json
{
    "name": "TRANSIENT_STORAGE_ENABLED",
    "value": "true"
}
```

Operators set `"value": "false"` to disable transient storage for a deployment.

### 6. File Change Summary

| File | Change |
|------|--------|
| `geek-cafe-saas-sdk/.../transient_table_mixin.py` | Add `is_transient_storage_enabled()`, add early-return blocks in `resolve_transient_table_name()` and `resolve_transient_bucket()` |
| `geek-cafe-saas-sdk/.../transient_service_base.py` | Wrap `validate_storage_access()` call in `if self.is_transient_storage_enabled()` |
| `NCA-SaaS-Application/.../04-profile-splitting.json` | Add `TRANSIENT_STORAGE_ENABLED` env var |
| `NCA-SaaS-Application/.../05-caclulations.json` | Add `TRANSIENT_STORAGE_ENABLED` env var |
| `NCA-SaaS-Application/.../05a-caclulations-aggregator.json` | Add `TRANSIENT_STORAGE_ENABLED` env var |
| `NCA-SaaS-Application/.../06-output-service-batch-dispatcher.json` | Add `TRANSIENT_STORAGE_ENABLED` env var |
| `NCA-SaaS-Application/.../06a-output-service-batch-processor.json` | Add `TRANSIENT_STORAGE_ENABLED` env var |
| `NCA-SaaS-Application/.../06b-output-service-batch-aggregator.json` | Add `TRANSIENT_STORAGE_ENABLED` env var |
| `NCA-SaaS-Application/.../06c-output-service-batch-merger.json` | Add `TRANSIENT_STORAGE_ENABLED` env var |
| `NCA-SaaS-Application/.../07-analysis-packaging.json` | Add `TRANSIENT_STORAGE_ENABLED` env var |
| `geek-cafe-saas-sdk/tests/test_transient_table_mixin.py` | New/updated tests for kill switch behavior |
| `geek-cafe-saas-sdk/tests/test_transient_service_base.py` | New tests for skip-validation behavior |

## Data Models

No new data models are introduced. The feature modifies control flow only.

### Environment Variables

| Variable | Values | Default | Description |
|----------|--------|---------|-------------|
| `TRANSIENT_STORAGE_ENABLED` | `true`, `false` (case-insensitive) | `true` (when unset) | Master kill switch for transient storage |
| `DYNAMODB_TRANSIENT_TABLE_NAME` | string | (none) | Existing — ignored when kill switch is disabled |
| `S3_TRANSIENT_BUCKET` | string | (none) | Existing — ignored when kill switch is disabled |
| `DYNAMODB_TABLE_NAME` | string | (none) | Existing — used as main table fallback |
| `TABLE_NAME` | string | (none) | Existing — secondary main table fallback |
| `S3_BUCKET` | string | (none) | Existing — used as main bucket fallback |
| `FILE_SYSTEM_BUCKET` | string | (none) | Existing — secondary main bucket fallback |

### Method Signature Preservation

No method signatures change. `resolve_transient_table_name(fallback_table_name=None)` and `resolve_transient_bucket(fallback_bucket=None)` retain their existing signatures. The only addition is the new `is_transient_storage_enabled()` static method.


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Kill switch state accessor correctness

*For any* string value of the `TRANSIENT_STORAGE_ENABLED` environment variable, `is_transient_storage_enabled()` shall return `False` if and only if the stripped, lowercased value equals `"false"`. For all other values (including `"true"`, unset/empty, and any unrecognized string), it shall return `True`.

**Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 5.2, 5.3, 5.4**

### Property 2: Table resolution bypasses transient env var when disabled

*For any* combination of a transient table name (set as `DYNAMODB_TRANSIENT_TABLE_NAME`), a fallback table name parameter, and a main table name (set as `DYNAMODB_TABLE_NAME`), when `TRANSIENT_STORAGE_ENABLED` is `"false"`, `resolve_transient_table_name()` shall return the main table (preferring `fallback_table_name`, then `DYNAMODB_TABLE_NAME`, then `TABLE_NAME`) and shall never return the transient table name.

**Validates: Requirements 2.1, 2.2, 2.3**

### Property 3: Bucket resolution bypasses transient env var when disabled

*For any* combination of a transient bucket name (set as `S3_TRANSIENT_BUCKET`), a fallback bucket parameter, and a main bucket name (set as `S3_BUCKET`), when `TRANSIENT_STORAGE_ENABLED` is `"false"`, `resolve_transient_bucket()` shall return the main bucket (preferring `fallback_bucket`, then `S3_BUCKET`, then `FILE_SYSTEM_BUCKET`) and shall never return the transient bucket name.

**Validates: Requirements 3.1, 3.2, 3.3**

### Property 4: TransientServiceBase skips validation when disabled

*For any* main table name (non-transient), when `TRANSIENT_STORAGE_ENABLED` is `"false"`, constructing a `TransientServiceBase` subclass shall succeed without raising `StorageMismatchError`, even when `STORAGE_VALIDATION_MODE` is `"enforce"`.

**Validates: Requirements 4.1, 4.2**

### Property 5: TransientServiceBase validates when enabled

*For any* table name that does NOT contain the substring `"transient"` (case-insensitive), when `TRANSIENT_STORAGE_ENABLED` is `"true"` and `STORAGE_VALIDATION_MODE` is `"enforce"`, constructing a `TransientServiceBase` subclass shall raise `StorageMismatchError`.

**Validates: Requirements 4.3, 7.2**

### Property 6: Backward compatibility when kill switch is unset

*For any* combination of `DYNAMODB_TRANSIENT_TABLE_NAME` (set or unset) and `DYNAMODB_TABLE_NAME` (set or unset), when `TRANSIENT_STORAGE_ENABLED` is not set in the environment, `resolve_transient_table_name()` shall produce the same result as the pre-kill-switch implementation: prefer `DYNAMODB_TRANSIENT_TABLE_NAME`, then `fallback_table_name`, then `DYNAMODB_TABLE_NAME`/`TABLE_NAME`.

**Validates: Requirements 7.1, 7.4**

## Error Handling

### ValueError from `resolve_transient_table_name()`

When the kill switch is disabled and no main table name can be resolved from any source (`fallback_table_name` is `None`, `DYNAMODB_TABLE_NAME` is unset, `TABLE_NAME` is unset), the method raises `ValueError` with a descriptive message. This is a deployment configuration error — the operator disabled transient storage but didn't configure a main table.

### Empty string from `resolve_transient_bucket()`

When the kill switch is disabled and no main bucket can be resolved, the method returns an empty string. This matches the existing fallback behavior of the method (it already returns `""` when no bucket source is available).

### StorageMismatchError bypass

When the kill switch is disabled, `TransientServiceBase` skips `validate_storage_access()` entirely. This prevents false positives — the resolved table is intentionally the main (long-term) table, so validating it against `StorageIntent.TRANSIENT` would always fail.

### Unrecognized TRANSIENT_STORAGE_ENABLED values

If the env var contains a value other than `"true"` or `"false"` (case-insensitive), `is_transient_storage_enabled()` defaults to `True` (enabled) and logs a warning. This is the safe default — transient storage continues to work, and the operator is alerted to fix the configuration.

### No impact on StorageValidator

The `StorageValidator` module (`storage_validator.py`) is not modified. When the kill switch is disabled, validation is simply not called. When enabled, the existing `STORAGE_VALIDATION_MODE` behavior is fully preserved.

## Testing Strategy

### Property-Based Testing

Use **Hypothesis** for property-based tests. Each property from the Correctness Properties section maps to a single Hypothesis test.

**Configuration:**
- Minimum 100 examples per property test (`@settings(max_examples=100)`)
- Each test tagged with a comment: `# Feature: transient-storage-kill-switch, Property N: <title>`

**Generators needed:**
- `false_case_variations()`: Generates case variations of `"false"` (e.g., `"False"`, `"FALSE"`, `"fAlSe"`) with optional whitespace padding
- `true_case_variations()`: Generates case variations of `"true"` with optional whitespace padding
- `non_boolean_strings()`: Generates strings that are not case-insensitive `"true"` or `"false"` (e.g., `"yes"`, `"0"`, `"disabled"`)
- `valid_resource_names()`: Generates non-empty, non-whitespace strings for table/bucket names (guaranteed not to contain `"transient"`)
- `transient_resource_names()`: Generates strings guaranteed to contain `"transient"` in random case positions

**Property tests (6 tests):**

| Test | Property | Description |
|------|----------|-------------|
| `test_kill_switch_state_accessor` | Property 1 | Random env var values → `is_transient_storage_enabled()` returns False iff lowered value is "false" |
| `test_table_resolution_disabled` | Property 2 | Random table names with kill switch off → returns main table, never transient |
| `test_bucket_resolution_disabled` | Property 3 | Random bucket names with kill switch off → returns main bucket, never transient |
| `test_service_base_skips_validation_disabled` | Property 4 | Random non-transient table names with kill switch off → no StorageMismatchError |
| `test_service_base_validates_when_enabled` | Property 5 | Random non-transient table names with kill switch on + enforce → StorageMismatchError |
| `test_backward_compat_unset` | Property 6 | Random table name combos with kill switch unset → same resolution as current logic |

### Unit Tests

Unit tests cover specific examples, edge cases, and integration points:

- `is_transient_storage_enabled()` returns `True` when env var is unset (Req 1.4, 5.4)
- `is_transient_storage_enabled()` returns `True` when env var is empty string (edge case)
- `resolve_transient_table_name()` raises `ValueError` when disabled and no main table available (Req 2.4)
- `resolve_transient_bucket()` returns `""` when disabled and no main bucket available (Req 3.4)
- `resolve_transient_table_name()` logs info message when disabled (Req 2.5)
- `resolve_transient_bucket()` logs info message when disabled (Req 3.5)
- `TransientServiceBase` constructs with main table when disabled, even with `STORAGE_VALIDATION_MODE=enforce` (integration)
- CDK Lambda configs for steps 04, 05, 05a, 06, 06a, 06b, 06c, 07 contain `TRANSIENT_STORAGE_ENABLED` (Req 6.1)
