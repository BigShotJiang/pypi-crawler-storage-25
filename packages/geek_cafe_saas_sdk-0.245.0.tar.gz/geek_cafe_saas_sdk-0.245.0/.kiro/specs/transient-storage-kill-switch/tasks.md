# Implementation Plan: Transient Storage Kill Switch

## Overview

Add a master kill switch (`TRANSIENT_STORAGE_ENABLED` env var) to the SDK's `TransientTableMixin` that, when set to `false`, forces all transient resource resolution to fall back to main (long-term) DynamoDB tables and S3 buckets. SDK changes come first, then CDK Lambda config updates, then tests.

## Tasks

- [x] 1. Add `is_transient_storage_enabled()` and modify `TransientTableMixin`
  - [x] 1.1 Add `is_transient_storage_enabled()` static method to `TransientTableMixin`
    - Add the static method to `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/core/services/transient_table_mixin.py`
    - Read `TRANSIENT_STORAGE_ENABLED` env var, return `False` only when stripped/lowered value is `"false"`, return `True` for `"true"`, unset, empty, or unrecognized values
    - Log a warning for unrecognized values
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 5.1, 5.2, 5.3, 5.4_

  - [x] 1.2 Add early-return kill switch block in `resolve_transient_table_name()`
    - At the top of the existing method, call `is_transient_storage_enabled()`
    - When disabled: resolve main table from `fallback_table_name`, then `DYNAMODB_TABLE_NAME`, then `TABLE_NAME`
    - When disabled: raise `ValueError` if no main table can be resolved
    - When disabled: log info message and return main table, skip `classify_resource()` warning
    - When disabled: ignore `DYNAMODB_TRANSIENT_TABLE_NAME` even if set
    - Do not change the method signature
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 4.4, 7.4_

  - [x] 1.3 Add early-return kill switch block in `resolve_transient_bucket()`
    - At the top of the existing method, call `is_transient_storage_enabled()`
    - When disabled: resolve main bucket from `fallback_bucket`, then `S3_BUCKET`, then `FILE_SYSTEM_BUCKET`
    - When disabled: return empty string if no main bucket available
    - When disabled: log info message and return main bucket, skip `classify_resource()` warning
    - When disabled: ignore `S3_TRANSIENT_BUCKET` even if set
    - Do not change the method signature
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 4.4, 7.4_

  - [ ]* 1.4 Write property test for `is_transient_storage_enabled()` (Property 1)
    - **Property 1: Kill switch state accessor correctness**
    - Create or update `geek-cafe-saas-sdk/tests/test_transient_kill_switch.py`
    - Use Hypothesis with `@settings(max_examples=100)`
    - Generate case variations of `"false"`, `"true"`, unset, and arbitrary strings
    - Assert: returns `False` iff stripped/lowered value equals `"false"`, `True` otherwise
    - **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 5.2, 5.3, 5.4**

  - [ ]* 1.5 Write property test for table resolution when disabled (Property 2)
    - **Property 2: Table resolution bypasses transient env var when disabled**
    - Use Hypothesis to generate random table name combinations (transient, fallback, main)
    - Assert: when `TRANSIENT_STORAGE_ENABLED=false`, result is never the transient table name; prefers fallback, then `DYNAMODB_TABLE_NAME`, then `TABLE_NAME`
    - **Validates: Requirements 2.1, 2.2, 2.3**

  - [ ]* 1.6 Write property test for bucket resolution when disabled (Property 3)
    - **Property 3: Bucket resolution bypasses transient env var when disabled**
    - Use Hypothesis to generate random bucket name combinations (transient, fallback, main)
    - Assert: when `TRANSIENT_STORAGE_ENABLED=false`, result is never the transient bucket name; prefers fallback, then `S3_BUCKET`, then `FILE_SYSTEM_BUCKET`
    - **Validates: Requirements 3.1, 3.2, 3.3**

  - [ ]* 1.7 Write unit tests for kill switch edge cases
    - Test `is_transient_storage_enabled()` returns `True` when env var is unset
    - Test `is_transient_storage_enabled()` returns `True` when env var is empty string
    - Test `resolve_transient_table_name()` raises `ValueError` when disabled and no main table available
    - Test `resolve_transient_bucket()` returns `""` when disabled and no main bucket available
    - Test `resolve_transient_table_name()` logs info message when disabled
    - Test `resolve_transient_bucket()` logs info message when disabled
    - _Requirements: 1.4, 2.4, 2.5, 3.4, 3.5_

- [x] 2. Modify `TransientServiceBase.__init__()` to skip validation when disabled
  - [x] 2.1 Wrap `validate_storage_access()` call in kill switch check
    - In `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/core/services/transient_service_base.py`
    - Add `if self.is_transient_storage_enabled():` guard around the existing `validate_storage_access()` call
    - When disabled, pass the resolved main table name directly to `super().__init__()` without validation
    - _Requirements: 4.1, 4.2, 4.3_

  - [ ]* 2.2 Write property test for TransientServiceBase skipping validation when disabled (Property 4)
    - **Property 4: TransientServiceBase skips validation when disabled**
    - Use Hypothesis to generate non-transient table names
    - Assert: constructing a `TransientServiceBase` subclass with `TRANSIENT_STORAGE_ENABLED=false` succeeds without `StorageMismatchError`, even with `STORAGE_VALIDATION_MODE=enforce`
    - **Validates: Requirements 4.1, 4.2**

  - [ ]* 2.3 Write property test for TransientServiceBase validating when enabled (Property 5)
    - **Property 5: TransientServiceBase validates when enabled**
    - Use Hypothesis to generate non-transient table names (no `"transient"` substring)
    - Assert: constructing with `TRANSIENT_STORAGE_ENABLED=true` and `STORAGE_VALIDATION_MODE=enforce` raises `StorageMismatchError`
    - **Validates: Requirements 4.3, 7.2**

- [x] 3. Checkpoint - Verify SDK changes
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Add `TRANSIENT_STORAGE_ENABLED` env var to CDK Lambda configs
  - [x] 4.1 Add env var to step 04 (`04-profile-splitting.json`)
    - Add `{"name": "TRANSIENT_STORAGE_ENABLED", "value": "true"}` to the `environment_variables` array in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/04-profile-splitting.json`
    - _Requirements: 6.1, 6.2, 6.4_

  - [x] 4.2 Add env var to step 05 (`05-caclulations.json`)
    - Add `{"name": "TRANSIENT_STORAGE_ENABLED", "value": "true"}` to the `environment_variables` array in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/05-caclulations.json`
    - _Requirements: 6.1, 6.2, 6.4_

  - [x] 4.3 Add env var to step 05a (`05a-caclulations-aggregator.json`)
    - Add `{"name": "TRANSIENT_STORAGE_ENABLED", "value": "true"}` to the `environment_variables` array in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/05a-caclulations-aggregator.json`
    - _Requirements: 6.1, 6.2, 6.4_

  - [x] 4.4 Add env var to step 06 (`06-output-service-batch-dispatcher.json`)
    - Add `{"name": "TRANSIENT_STORAGE_ENABLED", "value": "true"}` to the `environment_variables` array in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/06-output-service-batch-dispatcher.json`
    - _Requirements: 6.1, 6.2, 6.4_

  - [x] 4.5 Add env var to step 06a (`06a-output-service-batch-processor.json`)
    - Add `{"name": "TRANSIENT_STORAGE_ENABLED", "value": "true"}` to the `environment_variables` array in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/06a-output-service-batch-processor.json`
    - _Requirements: 6.1, 6.2, 6.4_

  - [x] 4.6 Add env var to step 06b (`06b-output-service-batch-aggregator.json`)
    - Add `{"name": "TRANSIENT_STORAGE_ENABLED", "value": "true"}` to the `environment_variables` array in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/06b-output-service-batch-aggregator.json`
    - _Requirements: 6.1, 6.2, 6.4_

  - [x] 4.7 Add env var to step 06c (`06c-output-service-batch-merger.json`)
    - Add `{"name": "TRANSIENT_STORAGE_ENABLED", "value": "true"}` to the `environment_variables` array in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/06c-output-service-batch-merger.json`
    - _Requirements: 6.1, 6.2, 6.4_

  - [x] 4.8 Add env var to step 07 (`07-analysis-packaging.json`)
    - Add `{"name": "TRANSIENT_STORAGE_ENABLED", "value": "true"}` to the `environment_variables` array in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/07-analysis-packaging.json`
    - _Requirements: 6.1, 6.2, 6.4_

- [x] 5. Backward compatibility and integration tests
  - [ ]* 5.1 Write property test for backward compatibility (Property 6)
    - **Property 6: Backward compatibility when kill switch is unset**
    - Use Hypothesis to generate combinations of `DYNAMODB_TRANSIENT_TABLE_NAME` (set/unset) and `DYNAMODB_TABLE_NAME` (set/unset)
    - Assert: when `TRANSIENT_STORAGE_ENABLED` is not set, `resolve_transient_table_name()` produces the same result as the pre-kill-switch logic (prefer transient env var, then fallback, then main env var)
    - **Validates: Requirements 7.1, 7.4**

  - [ ]* 5.2 Write unit tests for CDK config validation
    - Verify all 8 Lambda config JSON files (steps 04, 05, 05a, 06, 06a, 06b, 06c, 07) contain a `TRANSIENT_STORAGE_ENABLED` entry in their `environment_variables` array
    - _Requirements: 6.1_

- [x] 6. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- The design uses Python — all code examples and tests use Python with Hypothesis for property-based testing
- `TRANSIENT_STORAGE_ENABLED` is passed as a static `"value"` in CDK configs (no `"transform": true`), so no changes to `environment_services.py` are needed
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
