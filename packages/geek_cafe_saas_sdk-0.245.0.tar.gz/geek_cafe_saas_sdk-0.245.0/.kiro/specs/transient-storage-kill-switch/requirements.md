# Requirements Document

## Introduction

The platform's transient storage system uses dedicated DynamoDB tables and S3 buckets for short-lived pipeline data (profile splitting, calculations, batch outputs). The current architecture is all-or-nothing: if one service (e.g., profile-splitting at step 04) writes to the transient table/bucket but another service (e.g., calc-engine at step 05) is not configured with the transient environment variables, the second service cannot find the data because it reads from the main table/bucket.

This feature introduces a master kill switch — a single environment variable `TRANSIENT_STORAGE_ENABLED` — that, when set to `false`, forces ALL services to fall back to the main (long-term) DynamoDB table and main workload S3 bucket. The kill switch operates at the `TransientTableMixin` level in the SDK so that:

- `resolve_transient_table_name()` returns the main table name regardless of whether `DYNAMODB_TRANSIENT_TABLE_NAME` is set
- `resolve_transient_bucket()` returns the main workload bucket regardless of whether `S3_TRANSIENT_BUCKET` is set
- `StorageValidator` validation is effectively bypassed because all resources target the same long-term resources, eliminating mismatch possibilities

This provides a safe, consistent way to disable transient storage across the entire pipeline without requiring per-service configuration changes, and ensures all services in the workflow read and write from the same resources.

## Glossary

- **Kill_Switch**: The `TRANSIENT_STORAGE_ENABLED` environment variable that globally controls whether transient storage is active (`true`) or disabled (`false`). When disabled, all transient resource resolution falls back to main (long-term) resources.
- **TransientTableMixin**: The SDK mixin class (`geek_cafe_saas_sdk.core.services.transient_table_mixin`) that resolves transient DynamoDB table names and S3 bucket names from environment variables (`DYNAMODB_TRANSIENT_TABLE_NAME`, `S3_TRANSIENT_BUCKET`).
- **Storage_Validator**: The SDK utility module (`geek_cafe_saas_sdk.core.services.storage_validator`) that classifies resource names as transient or long-term and enforces storage-intent rules via `STORAGE_VALIDATION_MODE`.
- **TransientServiceBase**: The SDK abstract base class for services targeting transient DynamoDB tables. Resolves the transient table via TransientTableMixin and validates the resolved name at construction time.
- **Main_Table**: The primary long-term DynamoDB table resolved from `DYNAMODB_TABLE_NAME` or `TABLE_NAME` environment variables.
- **Main_Bucket**: The primary long-term S3 workload bucket resolved from `S3_BUCKET`, `ANALYSIS_BUCKET`, or `FILE_SYSTEM_BUCKET` environment variables.
- **Downstream_Service**: Any Lambda-based service in the NCA pipeline that depends on TransientTableMixin for resource resolution, including profile-splitting (step 04), calculations (step 05), output service (steps 06a/06b/06c), and packaging (step 07).
- **CDK_Lambda_Config**: A JSON configuration file in `NCA-SaaS-Application/devops/cdk/configs/resources/lambda_functions/v3/workflow-executions/` that defines a Lambda function's environment variables and resource bindings.
- **Environment_Services**: The CDK utility class (`NCA-SaaS-Application/devops/cdk/utilities/environment_services.py`) that resolves and transforms environment variable values during stack synthesis.

## Requirements

### Requirement 1: Kill Switch Environment Variable

**User Story:** As a platform operator, I want a single environment variable that controls whether transient storage is active or disabled across all services, so that I can ensure consistent resource targeting without modifying per-service configuration.

#### Acceptance Criteria

1. THE TransientTableMixin SHALL read the `TRANSIENT_STORAGE_ENABLED` environment variable to determine whether transient storage is active.
2. WHEN `TRANSIENT_STORAGE_ENABLED` is set to `true` (case-insensitive), THE TransientTableMixin SHALL resolve transient resources using the existing resolution logic (transient env vars, then fallback).
3. WHEN `TRANSIENT_STORAGE_ENABLED` is set to `false` (case-insensitive), THE TransientTableMixin SHALL bypass transient resource resolution and return main (long-term) resources.
4. WHEN `TRANSIENT_STORAGE_ENABLED` is not set, THE TransientTableMixin SHALL default to `true` (transient storage enabled) to preserve backward compatibility with existing deployments.
5. IF `TRANSIENT_STORAGE_ENABLED` contains an unrecognized value (not `true` or `false`, case-insensitive), THEN THE TransientTableMixin SHALL default to `true` and log a warning about the invalid configuration.

### Requirement 2: Table Name Resolution When Kill Switch Is Disabled

**User Story:** As a platform developer, I want `resolve_transient_table_name()` to return the main table name when the kill switch is disabled, so that all services read and write DynamoDB data from the same long-term table.

#### Acceptance Criteria

1. WHILE the Kill_Switch is disabled, THE TransientTableMixin `resolve_transient_table_name()` method SHALL return the Main_Table name resolved from the `fallback_table_name` parameter.
2. WHILE the Kill_Switch is disabled and no `fallback_table_name` is provided, THE TransientTableMixin `resolve_transient_table_name()` method SHALL return the Main_Table name resolved from the `DYNAMODB_TABLE_NAME` or `TABLE_NAME` environment variable.
3. WHILE the Kill_Switch is disabled, THE TransientTableMixin `resolve_transient_table_name()` method SHALL ignore the `DYNAMODB_TRANSIENT_TABLE_NAME` environment variable even when it is set.
4. IF the Kill_Switch is disabled and no main table name can be resolved from any source, THEN THE TransientTableMixin SHALL raise a ValueError with a descriptive message.
5. WHILE the Kill_Switch is disabled, THE TransientTableMixin `resolve_transient_table_name()` method SHALL log an informational message indicating that transient storage is disabled and the main table is being used.

### Requirement 3: Bucket Resolution When Kill Switch Is Disabled

**User Story:** As a platform developer, I want `resolve_transient_bucket()` to return the main workload bucket when the kill switch is disabled, so that all services read and write S3 data from the same long-term bucket.

#### Acceptance Criteria

1. WHILE the Kill_Switch is disabled, THE TransientTableMixin `resolve_transient_bucket()` method SHALL return the Main_Bucket name resolved from the `fallback_bucket` parameter.
2. WHILE the Kill_Switch is disabled and no `fallback_bucket` is provided, THE TransientTableMixin `resolve_transient_bucket()` method SHALL return the Main_Bucket name resolved from the `S3_BUCKET` or `FILE_SYSTEM_BUCKET` environment variable.
3. WHILE the Kill_Switch is disabled, THE TransientTableMixin `resolve_transient_bucket()` method SHALL ignore the `S3_TRANSIENT_BUCKET` environment variable even when it is set.
4. IF the Kill_Switch is disabled and no main bucket name can be resolved from any source, THEN THE TransientTableMixin `resolve_transient_bucket()` method SHALL return an empty string, matching the existing fallback behavior.
5. WHILE the Kill_Switch is disabled, THE TransientTableMixin `resolve_transient_bucket()` method SHALL log an informational message indicating that transient storage is disabled and the main bucket is being used.

### Requirement 4: Storage Validator Bypass When Kill Switch Is Disabled

**User Story:** As a platform developer, I want the StorageValidator to skip transient-vs-long-term mismatch validation when the kill switch is disabled, so that services do not raise StorageMismatchError when all resources correctly target long-term storage.

#### Acceptance Criteria

1. WHILE the Kill_Switch is disabled, THE TransientServiceBase SHALL skip the `validate_storage_access()` call during construction, because the resolved table name is the Main_Table (a long-term resource) and validating it against `StorageIntent.TRANSIENT` would produce a false mismatch.
2. WHILE the Kill_Switch is disabled, THE TransientServiceBase SHALL pass the Main_Table name to `DatabaseService.__init__` without raising a StorageMismatchError.
3. WHILE the Kill_Switch is enabled, THE TransientServiceBase SHALL continue to validate the resolved table name against `StorageIntent.TRANSIENT` using the existing validation logic.
4. WHILE the Kill_Switch is disabled, THE TransientTableMixin SHALL skip the `classify_resource()` warning check in `resolve_transient_table_name()` and `resolve_transient_bucket()`, because the resolved resource is intentionally a long-term resource.

### Requirement 5: Kill Switch State Accessor

**User Story:** As a developer, I want a clean API to check whether transient storage is enabled, so that any component in the SDK can branch behavior based on the kill switch state without duplicating environment variable parsing logic.

#### Acceptance Criteria

1. THE TransientTableMixin SHALL provide a static method `is_transient_storage_enabled()` that returns a boolean indicating whether transient storage is active.
2. WHEN `TRANSIENT_STORAGE_ENABLED` is set to `true` (case-insensitive), THE `is_transient_storage_enabled()` method SHALL return `True`.
3. WHEN `TRANSIENT_STORAGE_ENABLED` is set to `false` (case-insensitive), THE `is_transient_storage_enabled()` method SHALL return `False`.
4. WHEN `TRANSIENT_STORAGE_ENABLED` is not set, THE `is_transient_storage_enabled()` method SHALL return `True`.
5. THE `is_transient_storage_enabled()` method SHALL be usable by TransientServiceBase, Downstream_Services, and any other SDK component that needs to check the kill switch state.

### Requirement 6: CDK Infrastructure Support for Kill Switch

**User Story:** As a platform operator, I want the CDK infrastructure to pass the `TRANSIENT_STORAGE_ENABLED` environment variable to all relevant Lambda functions, so that I can control the kill switch from a single deployment configuration.

#### Acceptance Criteria

1. THE CDK_Lambda_Config for all Downstream_Services (steps 04, 05, 05a, 06, 06a, 06b, 06c, 07) SHALL support a `TRANSIENT_STORAGE_ENABLED` environment variable.
2. THE Environment_Services SHALL pass the `TRANSIENT_STORAGE_ENABLED` value through to the Lambda environment without transformation.
3. WHEN `TRANSIENT_STORAGE_ENABLED` is not specified in a CDK_Lambda_Config, THE Downstream_Service SHALL default to `true` (transient storage enabled) at runtime via the SDK default.
4. THE CDK_Lambda_Config SHALL allow operators to set `TRANSIENT_STORAGE_ENABLED` to `false` to disable transient storage for a specific deployment environment.

### Requirement 7: Backward Compatibility

**User Story:** As a platform operator, I want the kill switch to be fully backward compatible with existing deployments, so that services continue to work without any configuration changes when the kill switch environment variable is not present.

#### Acceptance Criteria

1. WHEN the `TRANSIENT_STORAGE_ENABLED` environment variable is not set, THE TransientTableMixin SHALL behave identically to the current implementation (resolve transient resources from `DYNAMODB_TRANSIENT_TABLE_NAME` and `S3_TRANSIENT_BUCKET`, fall back to main resources when those are not set).
2. WHEN the `TRANSIENT_STORAGE_ENABLED` environment variable is not set, THE TransientServiceBase SHALL continue to validate the resolved table name against `StorageIntent.TRANSIENT` using the existing validation logic.
3. WHEN the `TRANSIENT_STORAGE_ENABLED` environment variable is not set, THE Storage_Validator SHALL continue to operate in the mode specified by `STORAGE_VALIDATION_MODE` (defaulting to `enforce`).
4. THE Kill_Switch feature SHALL not modify the method signatures of `resolve_transient_table_name()` or `resolve_transient_bucket()`, preserving API compatibility for all callers.
