# Design Document: SDK Moto Integration Tests

## Overview

This design adds moto-backed Cognito fixtures to the SDK's existing test infrastructure and creates integration tests that exercise the full user CRUD lifecycle through the Lambda handler layer. The goal is to verify that DynamoDB records and Cognito user identities stay in sync across create, update, delete, and restore operations — using moto's emulated AWS services instead of mocks or patches.

The existing `tests/conftest.py` already provides moto-backed DynamoDB and S3 fixtures. This design extends that foundation with Cognito user pool fixtures and a fully-wired `UserService` integration fixture, then adds integration tests that call Lambda handlers with realistic API Gateway event payloads.

### Key Design Decisions

1. **Shared `moto.mock_aws` context**: The existing `db` fixture uses `with moto.mock_aws():` internally. To share a single moto context across DynamoDB, S3, and Cognito, the new integration fixtures will use a single top-level `mock_aws` context that yields all three services together.

2. **`injected_service` pattern for handler tests**: Lambda handlers accept an `injected_service` parameter. Integration tests construct a `UserService` wired to moto-backed DynamoDB + Cognito, then pass it to the handler. This bypasses the handler's default service initialization while still exercising the full handler → service → AWS path.

3. **Realistic API Gateway events**: Tests build event dicts matching the API Gateway proxy integration format, including `requestContext.authorizer.claims` with `custom:user_id`, `custom:tenant_id`, and `custom:roles`. This ensures `RequestContext` extracts authentication correctly.

4. **Separate integration conftest**: Integration-specific fixtures live in `tests/integration/conftest.py` to keep them isolated from unit test fixtures. The session-scoped `load_test_environment` fixture from the root conftest still applies.

## Architecture

```mermaid
graph TD
    subgraph "Test Layer"
        IT[Integration Test]
        EV[API Gateway Event Builder]
    end

    subgraph "Fixtures (tests/integration/conftest.py)"
        MCX[moto.mock_aws context]
        CPF[cognito_user_pool fixture]
        CUF[cognito_utility fixture]
        DBF[integration_db fixture]
        USF[integration_user_service fixture]
    end

    subgraph "SDK Code Under Test"
        LH[Lambda Handler<br/>create/update/delete]
        US[UserService]
        CU[CognitoUtility]
        DB[DynamoDB via boto3_assist]
    end

    subgraph "Moto Emulated Services"
        MDY[DynamoDB]
        MCG[Cognito IDP]
    end

    IT --> EV
    IT --> LH
    LH -->|injected_service| US
    US --> CU
    US --> DB
    CU --> MCG
    DB --> MDY

    MCX --> CPF
    MCX --> DBF
    CPF --> CUF
    CUF --> USF
    DBF --> USF
```

## Components and Interfaces

### 1. `.env.mock` Update

Add `COGNITO_USER_POOL_ID` to the existing mock environment file. The value is a placeholder — integration fixtures override it with the real moto-generated pool ID at runtime.

```
COGNITO_USER_POOL_ID="us-east-1_TestPool123"
```

### 2. `pyproject.toml` Test Dependencies

Add a `test` optional-dependencies group:

```toml
[project.optional-dependencies]
dev = ["build", "twine"]
test = [
    "pytest",
    "python-dotenv",
    "hypothesis",
    "moto[cognitoidp,dynamodb,s3]",
    "boto3",
]
```

### 3. Integration Conftest (`tests/integration/conftest.py`)

This file provides fixtures that share a single `moto.mock_aws` context across DynamoDB, S3, and Cognito.

#### `cognito_user_pool` fixture

Creates a Cognito user pool with the SDK's custom attribute schema:

```python
def _create_cognito_user_pool(region: str = "us-east-1") -> str:
    client = boto3.client("cognito-idp", region_name=region)
    response = client.create_user_pool(
        PoolName="test-sdk-pool",
        Schema=[
            {"Name": "email", "AttributeDataType": "String", "Mutable": True, "Required": True},
            {"Name": "custom:user_id", "AttributeDataType": "String", "Mutable": True},
            {"Name": "custom:tenant_id", "AttributeDataType": "String", "Mutable": True},
            {"Name": "custom:roles", "AttributeDataType": "String", "Mutable": True},
        ],
        AutoVerifiedAttributes=["email"],
    )
    return response["UserPool"]["Id"]
```

#### `cognito_utility` fixture

Instantiates `CognitoUtility(aws_region="us-east-1")` within the shared moto context. Since `CognitoUtility.__init__` creates a boto3 session internally, it automatically connects to the moto-backed Cognito service.

#### `integration_db` fixture

Creates a `DynamoDB` instance (from `boto3_assist`) and the standard test table with 10 GSIs, within the shared moto context.

#### `integration_user_service` factory fixture

Returns a factory function that creates a `UserService` wired to the moto-backed DynamoDB and Cognito:

```python
def _create_service(request_context=None, user_id="admin_user", tenant_id="tenant_123"):
    if request_context is None:
        request_context = AnonymousContextFactory.create_user_context(
            user_id=user_id, tenant_id=tenant_id,
            roles=["tenant_admin"], allow_tenant_wide_access=True,
        )
        request_context.set_targets(tenant_id=tenant_id, user_id=user_id)
    return UserService(
        dynamodb=db, table_name=TABLE_NAME,
        request_context=request_context,
        cognito_utility=cognito_util, user_pool_id=pool_id,
    )
```

### 4. API Gateway Event Builder

A helper function that constructs realistic API Gateway proxy events:

```python
def build_apigw_event(
    method: str, path: str, body: dict = None,
    path_params: dict = None,
    user_id: str = "admin_user", tenant_id: str = "tenant_123",
    roles: str = "tenant_admin",
) -> dict:
    event = {
        "httpMethod": method,
        "path": path,
        "pathParameters": path_params or {},
        "requestContext": {
            "authorizer": {
                "claims": {
                    "sub": user_id,
                    "custom:user_id": user_id,
                    "custom:tenant_id": tenant_id,
                    "custom:roles": roles,
                    "email": f"{user_id}@test.com",
                }
            }
        },
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body) if body else None,
    }
    return event
```

### 5. Integration Test Module (`tests/integration/test_user_lifecycle.py`)

Contains the following test functions, all marked with `@pytest.mark.integration`:

| Test | Handler/Method | Verifies |
|------|---------------|----------|
| `test_create_user_handler` | create `lambda_handler` | HTTP 201, DynamoDB record exists, Cognito user exists with correct custom attributes |
| `test_update_user_handler` | update `lambda_handler` | HTTP 200, DynamoDB roles updated, Cognito `custom:roles` updated |
| `test_delete_user_handler` | delete `lambda_handler` | HTTP 204, DynamoDB `deleted_utc_ts` set, Cognito user disabled |
| `test_restore_user_reenables_cognito` | `UserService.restore_user` | ServiceResult success, `deleted_utc_ts` None, Cognito user enabled |
| `test_create_rollback_on_cognito_failure` | `UserService.create` | Exception raised, DynamoDB record absent (rolled back) |
| `test_update_creates_cognito_when_missing` | `UserService.update` | Cognito user created for DynamoDB-only user, correct attributes |

### 6. Verification Helpers

Reusable functions for asserting DynamoDB and Cognito state:

```python
def get_dynamodb_user(db, table_name, user_id):
    """Fetch user record from DynamoDB by pk/sk."""

def get_cognito_user(cognito_client, user_pool_id, email):
    """Fetch Cognito user by email via list_users."""

def get_cognito_attribute(user, attr_name):
    """Extract a specific attribute value from Cognito user response."""

def assert_cognito_user_exists(cognito_client, user_pool_id, email):
    """Assert a Cognito user exists and return the user dict."""

def assert_cognito_user_enabled(cognito_client, user_pool_id, email, expected=True):
    """Assert Cognito user enabled/disabled state."""
```

## Data Models

No new data models are introduced. The tests operate on existing models:

- **User** (`geek_cafe_saas_sdk.modules.users.models.User`): DynamoDB user record with `pk`, `sk`, GSI keys, `email`, `first_name`, `last_name`, `roles`, `tenant_id`, `deleted_utc_ts`, etc.
- **Cognito User**: Moto-emulated Cognito user with `Username` (email), `Attributes` list containing `custom:user_id`, `custom:tenant_id`, `custom:roles`, `email`, `given_name`, `family_name`.
- **API Gateway Event**: Dict matching AWS API Gateway proxy integration format with `httpMethod`, `body`, `pathParameters`, `requestContext.authorizer.claims`.

## Error Handling

| Scenario | Expected Behavior | Test Coverage |
|----------|-------------------|---------------|
| Cognito `admin_create_user` fails (duplicate email) | `UserService.create` raises the Cognito exception; DynamoDB record is rolled back via `_delete_model` | `test_create_rollback_on_cognito_failure` |
| Cognito user missing on update | `_sync_cognito_update` creates the Cognito user (best-effort) | `test_update_creates_cognito_when_missing` |
| Cognito disable fails on delete | `_sync_cognito_disable` logs warning, sets `cognito_sync_warning` in metadata (best-effort) | Covered by existing `UserService` logic; not a separate test |
| Cognito enable fails on restore | `_sync_cognito_enable` logs warning, sets `cognito_sync_warning` in metadata (best-effort) | Covered by existing `UserService` logic; not a separate test |

## Testing Strategy

### Why Property-Based Testing Does Not Apply

This feature is purely integration testing — it verifies the wiring between Lambda handlers, `UserService`, DynamoDB, and Cognito using moto-emulated AWS services. The tests exercise specific CRUD lifecycle scenarios with concrete inputs and verify side effects in external services (DynamoDB records, Cognito user state). There are no pure functions with universal properties across a wide input space. PBT is not appropriate here.

### Integration Test Approach

- All tests marked with `@pytest.mark.integration` and excluded from default `pytest` runs (already configured in `pyproject.toml` via `addopts = "-m 'not integration'"`).
- Each test uses a shared `moto.mock_aws` context that provides DynamoDB, S3, and Cognito together.
- Tests call Lambda handlers with `injected_service` to exercise the full handler → service → AWS path.
- Verification checks both DynamoDB state (record exists, fields correct) and Cognito state (user exists, attributes correct, enabled/disabled).

### Test Execution

```bash
# Run only integration tests
source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest tests/integration/ -m integration -v

# Run all tests including integration
source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest -m '' -v
```

### File Structure

```
geek-cafe-saas-sdk/
├── tests/
│   ├── conftest.py                          # Existing (unchanged)
│   ├── integration/
│   │   ├── __init__.py
│   │   ├── conftest.py                      # Cognito + shared moto fixtures
│   │   ├── helpers.py                       # Event builder + verification helpers
│   │   └── test_user_lifecycle.py           # Integration tests (Req 6-11)
```
