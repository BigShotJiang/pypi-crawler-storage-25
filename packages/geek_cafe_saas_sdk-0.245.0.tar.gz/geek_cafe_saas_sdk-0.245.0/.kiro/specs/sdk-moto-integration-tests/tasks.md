# Implementation Plan: SDK Moto Integration Tests

## Overview

Add moto-backed Cognito fixtures to the SDK's existing test infrastructure and create integration tests that exercise the full user CRUD lifecycle through the Lambda handler layer. Tests verify DynamoDB records and Cognito user identities stay in sync across create, update, delete, and restore operations.

## Tasks

- [x] 1. Update project configuration and environment
  - [x] 1.1 Add `test` optional-dependencies group to `pyproject.toml`
    - Add `test` group with `pytest`, `python-dotenv`, `hypothesis`, `moto[cognitoidp,dynamodb,s3]`, `boto3`
    - Keep existing `dev` group unchanged
    - _Requirements: 1.1, 1.2_

  - [x] 1.2 Add `COGNITO_USER_POOL_ID` to `.env.mock`
    - Add `COGNITO_USER_POOL_ID="us-east-1_TestPool123"` placeholder entry
    - Existing `COGNITO_USER_POOL` and `COGNITO_CLIENT_ID` entries remain unchanged
    - _Requirements: 2.1, 2.2_

- [x] 2. Create integration test infrastructure
  - [x] 2.1 Create `tests/integration/__init__.py`
    - Add empty `__init__.py` to make `tests/integration` a proper Python package
    - _Requirements: 3.5, 4.2_

  - [x] 2.2 Create `tests/integration/helpers.py` with event builder and verification helpers
    - Implement `build_apigw_event(method, path, body, path_params, user_id, tenant_id, roles)` — builds realistic API Gateway proxy event dicts with `requestContext.authorizer.claims`
    - Implement `get_dynamodb_user(db, table_name, user_id)` — fetches user record by pk/sk
    - Implement `get_cognito_user(cognito_client, user_pool_id, email)` — fetches Cognito user by email via `list_users`
    - Implement `get_cognito_attribute(user, attr_name)` — extracts attribute value from Cognito user response
    - Implement `assert_cognito_user_exists(cognito_client, user_pool_id, email)` — asserts Cognito user exists, returns user dict
    - Implement `assert_cognito_user_enabled(cognito_client, user_pool_id, email, expected)` — asserts Cognito user enabled/disabled state
    - _Requirements: 6.1, 6.3, 7.3, 8.3, 9.3_

  - [x] 2.3 Create `tests/integration/conftest.py` with shared moto fixtures
    - Implement `cognito_user_pool` fixture — creates moto-backed Cognito pool with `custom:user_id`, `custom:tenant_id`, `custom:roles` schema attributes, `email` required and auto-verified
    - Implement `cognito_utility` fixture — instantiates `CognitoUtility(aws_region="us-east-1")` within shared moto context
    - Implement `integration_db` fixture — creates `DynamoDB` instance and standard test table with 10 GSIs within shared moto context
    - Implement `integration_user_service` factory fixture — returns factory that creates `UserService` wired to moto DynamoDB + Cognito, accepts `request_context` parameter defaulting to tenant admin
    - All fixtures must share a single `moto.mock_aws` context so DynamoDB and Cognito coexist
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 4.1, 4.2, 4.3, 5.1, 5.2, 5.3_

- [x] 3. Checkpoint - Verify fixtures
  - Ensure all fixtures can be imported and instantiated without errors, ask the user if questions arise.

- [x] 4. Implement integration tests
  - [x] 4.1 Implement `test_create_user_handler` in `tests/integration/test_user_lifecycle.py`
    - Mark with `@pytest.mark.integration`
    - Build API Gateway event with `build_apigw_event` containing email, first_name, last_name
    - Call create `lambda_handler` with `injected_service` from `integration_user_service` fixture
    - Assert HTTP 201 response
    - Verify DynamoDB record exists with correct email, first_name, last_name using `get_dynamodb_user`
    - Verify Cognito user exists with correct `custom:user_id`, `custom:tenant_id`, `custom:roles` using `assert_cognito_user_exists` and `get_cognito_attribute`
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

  - [x] 4.2 Implement `test_update_user_handler`
    - Mark with `@pytest.mark.integration`
    - First create a user via the service, then build update event with new roles
    - Call update `lambda_handler` with `injected_service`
    - Assert HTTP 200 response
    - Verify DynamoDB record reflects updated roles
    - Verify Cognito `custom:roles` attribute reflects updated roles
    - _Requirements: 7.1, 7.2, 7.3_

  - [x] 4.3 Implement `test_delete_user_handler`
    - Mark with `@pytest.mark.integration`
    - First create a user via the service, then build delete event
    - Call delete `lambda_handler` with `injected_service` (use a different admin user_id so self-delete prevention doesn't trigger)
    - Assert HTTP 200 response (handler returns 200 with `ServiceResult.success_result(True)`)
    - Verify DynamoDB record has non-null `deleted_utc_ts` (soft delete)
    - Verify Cognito user is disabled using `assert_cognito_user_enabled(..., expected=False)`
    - _Requirements: 8.1, 8.2, 8.3_

  - [x] 4.4 Implement `test_restore_user_reenables_cognito`
    - Mark with `@pytest.mark.integration`
    - Create a user, then delete it via the service to set up soft-deleted state
    - Call `UserService.restore_user` directly
    - Assert ServiceResult is successful
    - Verify DynamoDB `deleted_utc_ts` is None
    - Verify Cognito user is re-enabled using `assert_cognito_user_enabled(..., expected=True)`
    - _Requirements: 9.1, 9.2, 9.3_

  - [x] 4.5 Implement `test_create_rollback_on_cognito_failure`
    - Mark with `@pytest.mark.integration`
    - Pre-create a Cognito user with the same email directly via `cognito_client.admin_create_user` to force a duplicate
    - Call `UserService.create` with that email — expect Cognito exception
    - Verify DynamoDB table does NOT contain a user record for the attempted creation (rollback completed)
    - _Requirements: 10.1, 10.2_

  - [x] 4.6 Implement `test_update_creates_cognito_when_missing`
    - Mark with `@pytest.mark.integration`
    - Create a user in DynamoDB only (via service with `cognito_utility=None`, or direct DynamoDB write)
    - Then update that user via a `UserService` instance that HAS Cognito wired
    - Verify Cognito user pool now contains a user with the correct email, `custom:user_id`, and `custom:tenant_id`
    - _Requirements: 11.1, 11.2_

- [x] 5. Final checkpoint - Ensure all integration tests pass
  - Run `source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest tests/integration/test_user_lifecycle.py -m integration -v`
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- All integration tests are marked `@pytest.mark.integration` and excluded from default `pytest` runs via existing `addopts = "-m 'not integration'"` in `pyproject.toml`
- The design explicitly states property-based testing does not apply — these are integration tests with concrete inputs verifying side effects in external services
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
