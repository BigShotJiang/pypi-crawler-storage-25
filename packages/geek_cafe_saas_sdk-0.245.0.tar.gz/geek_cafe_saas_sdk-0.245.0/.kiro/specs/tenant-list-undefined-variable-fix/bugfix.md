# Bugfix Requirements Document

## Introduction

The `TenantService.list_all` and `TenantService.list_by_status` methods in `tenant_service.py` crash at runtime with `NameError: name 'tenant_id' is not defined`. This occurs because both methods reference local variables (`tenant_id`, `user_id`) that were never defined in their method signatures or bodies. The Lambda handler for listing tenants (`/tenants/list`) is completely broken — every invocation results in a 500 error.

The root cause is that `list_all` passes `tenant_id` and `user_id` as positional arguments to `list_by_status`, but neither variable exists in scope, and `list_by_status` doesn't accept those parameters anyway. Additionally, both methods' exception handlers reference `tenant_id` in their `**context` kwargs, which also triggers the same `NameError`. Other methods in the same class correctly obtain these values from `self.request_context`.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN `list_all` is called THEN the system crashes with `NameError: name 'tenant_id' is not defined` on the line `return self.list_by_status("active", tenant_id, user_id, limit)` because `tenant_id` and `user_id` are not defined in the method scope

1.2 WHEN `list_all` is called and the exception handler runs THEN the system crashes with `NameError: name 'tenant_id' is not defined` on the line `self._handle_service_exception(e, 'list_all_tenants', tenant_id=tenant_id)` because `tenant_id` is not defined

1.3 WHEN `list_by_status` is called and an exception occurs THEN the system crashes with `NameError: name 'tenant_id' is not defined` on the line `self._handle_service_exception(e, 'list_tenants_by_status', status=status, tenant_id=tenant_id)` because `tenant_id` is not defined in the method scope

1.4 WHEN `list_all` calls `list_by_status` THEN the system would receive a `TypeError` for passing extra positional arguments (`tenant_id`, `user_id`) that `list_by_status` does not accept in its signature `(self, status: str, limit: int = 50)`

### Expected Behavior (Correct)

2.1 WHEN `list_all` is called THEN the system SHALL delegate to `list_by_status("active", limit)` without passing `tenant_id` or `user_id` as arguments, since `list_by_status` only accepts `status` and `limit`

2.2 WHEN `list_all` is called and the exception handler runs THEN the system SHALL reference `self.request_context.target_tenant_id` instead of the undefined `tenant_id` variable

2.3 WHEN `list_by_status` is called and an exception occurs THEN the system SHALL reference `self.request_context.target_tenant_id` instead of the undefined `tenant_id` variable in the exception handler

2.4 WHEN `list_all` calls `list_by_status` THEN the system SHALL pass only the arguments that match `list_by_status`'s signature: `status` and `limit`

### Unchanged Behavior (Regression Prevention)

3.1 WHEN `list_by_status` is called with a valid `status` and `limit` THEN the system SHALL CONTINUE TO query the GSI1 index, filter out deleted tenants, and return a `ServiceResult` with the list of matching tenants

3.2 WHEN other `TenantService` methods (`create`, `get_by_id`, `update`, `deactivate`, `activate`, `delete`) are called THEN the system SHALL CONTINUE TO function correctly with no changes to their behavior

3.3 WHEN the Lambda handler calls `service.list_all(limit=limit)` THEN the system SHALL CONTINUE TO accept the `limit` keyword argument and return a `ServiceResult`

3.4 WHEN `_handle_service_exception` is called from any method THEN the system SHALL CONTINUE TO receive valid keyword arguments for logging context
