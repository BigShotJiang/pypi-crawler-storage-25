# Tenant List Undefined Variable Bugfix Design

## Overview

The `TenantService.list_all` and `TenantService.list_by_status` methods crash at runtime with `NameError` because they reference undefined local variables `tenant_id` and `user_id`. The fix removes these phantom references and aligns both methods with the established pattern used by every other method in the class: accessing tenant/user identity through `self.request_context`.

## Glossary

- **Bug_Condition (C)**: Any invocation of `list_all` or any exception path in `list_by_status` — both reference variables (`tenant_id`, `user_id`) that do not exist in scope
- **Property (P)**: `list_all` delegates to `list_by_status("active", limit)` without extra arguments; exception handlers use `self.request_context.target_tenant_id` for logging context
- **Preservation**: The query logic inside `list_by_status` (GSI1 index query, deleted-tenant filtering, `ServiceResult` wrapping) and all other `TenantService` methods remain unchanged
- **TenantService**: The service class in `modules/tenancy/services/tenant_service.py` that manages tenant CRUD operations
- **request_context**: An object on `DatabaseService` (the base class) that carries authenticated tenant/user identity (`target_tenant_id`, `target_user_id`)
- **_handle_service_exception**: Base class method that maps exceptions to `ServiceResult` error responses; accepts `**context` kwargs for logging

## Bug Details

### Bug Condition

The bug manifests whenever `list_all` is called (every invocation) or whenever `list_by_status` hits its exception handler. In `list_all`, the method body references `tenant_id` and `user_id` as positional arguments to `list_by_status`, but neither variable is defined in the method signature or body. In both methods' `except` blocks, `tenant_id` is passed as a keyword argument to `_handle_service_exception` but is also undefined. Additionally, `list_by_status` only accepts `(self, status, limit)`, so even if the variables existed, the call from `list_all` would raise `TypeError` for too many positional arguments.

**Formal Specification:**
```
FUNCTION isBugCondition(input)
  INPUT: input of type MethodCall(method_name, args, exception_raised)
  OUTPUT: boolean

  RETURN (input.method_name == "list_all")
         OR (input.method_name == "list_by_status" AND input.exception_raised == True)
END FUNCTION
```

### Examples

- Calling `service.list_all(limit=50)` → crashes with `NameError: name 'tenant_id' is not defined` on line `return self.list_by_status("active", tenant_id, user_id, limit)`
- Calling `service.list_all(limit=50)` even if the NameError were somehow bypassed → would crash with `TypeError: list_by_status() takes 2 positional arguments but 4 positional arguments were given`
- Calling `service.list_by_status("active")` succeeds normally, but if the GSI1 query raises an exception → crashes with `NameError: name 'tenant_id' is not defined` in the except block
- Calling `service.get_by_id(tid)` → works correctly (uses `self.request_context.target_tenant_id` pattern)

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- `list_by_status` query logic: GSI1 index query using `temp_tenant.status`, ascending=False, limit parameter, deleted-tenant filtering, and `ServiceResult` wrapping must remain identical
- All other `TenantService` methods (`create`, `create_with_user`, `get_by_id`, `update`, `deactivate`, `activate`, `delete`, `get_user_count`, `can_add_user`) must be completely unaffected
- The Lambda handler in `handlers/tenants/list/app.py` calls `service.list_all(limit=limit)` — this call site must continue to work with no changes
- `_handle_service_exception` must continue to receive valid keyword arguments for error context logging

**Scope:**
All inputs that do NOT involve `list_all` invocations or `list_by_status` exception paths should be completely unaffected by this fix. This includes:
- Direct calls to `list_by_status` that succeed without exceptions
- All other service method calls
- The Lambda handler's event parsing and response formatting

## Hypothesized Root Cause

Based on the code analysis, the root cause is clear:

1. **Phantom Parameters in `list_all`**: The method signature is `list_all(self, limit: int = 50)` but the body calls `self.list_by_status("active", tenant_id, user_id, limit)` — `tenant_id` and `user_id` were likely left over from an earlier refactor that moved these values into `request_context` but forgot to update `list_all`

2. **Signature Mismatch**: `list_by_status` accepts `(self, status: str, limit: int = 50)` — it has no `tenant_id` or `user_id` parameters, so even if the variables existed, the call would fail with `TypeError`

3. **Stale Exception Handler References**: Both `list_all` and `list_by_status` exception handlers pass `tenant_id=tenant_id` to `_handle_service_exception`, but `tenant_id` is not in scope. Other methods like `get_by_id`, `update`, `deactivate`, `activate`, and `delete` correctly use a locally-assigned `tenant_id` from their parameters or `self.request_context`

4. **Stale Docstrings**: Both methods' docstrings document `tenant_id` and `user_id` as Args, but these parameters don't exist in the method signatures

## Correctness Properties

Property 1: Bug Condition - list_all delegates correctly to list_by_status

_For any_ call to `list_all(limit)`, the fixed method SHALL delegate to `self.list_by_status("active", limit)` with exactly two arguments matching `list_by_status`'s signature, and SHALL NOT reference any undefined variables.

**Validates: Requirements 2.1, 2.4**

Property 2: Bug Condition - Exception handlers use request_context

_For any_ exception raised during `list_all` or `list_by_status` execution, the fixed exception handler SHALL pass `self.request_context.target_tenant_id` as the `tenant_id` keyword argument to `_handle_service_exception`, and SHALL NOT reference any undefined variables.

**Validates: Requirements 2.2, 2.3**

Property 3: Preservation - list_by_status query logic unchanged

_For any_ call to `list_by_status(status, limit)` that does NOT raise an exception, the fixed function SHALL produce the same result as the original function — querying GSI1 by status, filtering deleted tenants, and returning a `ServiceResult` with the tenant list.

**Validates: Requirements 3.1, 3.3**

Property 4: Preservation - Other TenantService methods unchanged

_For any_ call to other `TenantService` methods (`create`, `get_by_id`, `update`, `deactivate`, `activate`, `delete`, etc.), the fixed code SHALL produce exactly the same behavior as the original code, preserving all existing functionality.

**Validates: Requirements 3.2, 3.4**

## Fix Implementation

### Changes Required

**File**: `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/tenant_service.py`

**Function**: `list_all`

**Specific Changes**:
1. **Remove undefined arguments from delegation call**: Change `return self.list_by_status("active", tenant_id, user_id, limit)` to `return self.list_by_status("active", limit)`
2. **Fix exception handler**: Change `tenant_id=tenant_id` to `tenant_id=self.request_context.target_tenant_id`
3. **Update docstring**: Remove `tenant_id` and `user_id` from the Args section

**Function**: `list_by_status`

**Specific Changes**:
4. **Fix exception handler**: Change `tenant_id=tenant_id` to `tenant_id=self.request_context.target_tenant_id`
5. **Update docstring**: Remove `tenant_id` and `user_id` from the Args section

## Testing Strategy

### Validation Approach

The testing strategy follows a two-phase approach: first, surface counterexamples that demonstrate the bug on unfixed code, then verify the fix works correctly and preserves existing behavior.

### Exploratory Bug Condition Checking

**Goal**: Surface counterexamples that demonstrate the bug BEFORE implementing the fix. Confirm that the NameError occurs as described.

**Test Plan**: Write tests that call `list_all` and trigger exception paths in `list_by_status`. Run these tests on the UNFIXED code to observe `NameError` failures.

**Test Cases**:
1. **list_all NameError Test**: Call `service.list_all(limit=50)` — will crash with `NameError: name 'tenant_id' is not defined` (will fail on unfixed code)
2. **list_by_status Exception Handler Test**: Force an exception inside `list_by_status` (e.g., mock `_query_by_index` to raise) — will crash with `NameError` in the except block (will fail on unfixed code)
3. **list_all Argument Count Test**: Even if variables were defined, verify `list_by_status` rejects extra positional args (will fail on unfixed code)

**Expected Counterexamples**:
- `NameError: name 'tenant_id' is not defined` when calling `list_all`
- `NameError: name 'tenant_id' is not defined` when `list_by_status` exception handler runs
- Possible `TypeError` for argument count mismatch if NameError is somehow bypassed

### Fix Checking

**Goal**: Verify that for all inputs where the bug condition holds, the fixed function produces the expected behavior.

**Pseudocode:**
```
FOR ALL input WHERE isBugCondition(input) DO
  result := fixedFunction(input)
  ASSERT result IS ServiceResult
  ASSERT NO NameError raised
  ASSERT NO TypeError raised
END FOR
```

### Preservation Checking

**Goal**: Verify that for all inputs where the bug condition does NOT hold, the fixed function produces the same result as the original function.

**Pseudocode:**
```
FOR ALL input WHERE NOT isBugCondition(input) DO
  ASSERT list_by_status_fixed(input) = list_by_status_original(input)
  ASSERT other_methods_fixed(input) = other_methods_original(input)
END FOR
```

**Testing Approach**: Property-based testing is recommended for preservation checking because:
- It generates many test cases automatically across the input domain
- It catches edge cases that manual unit tests might miss
- It provides strong guarantees that behavior is unchanged for all non-buggy inputs

**Test Plan**: Observe behavior on UNFIXED code first for successful `list_by_status` calls and other methods, then write property-based tests capturing that behavior.

**Test Cases**:
1. **list_by_status Success Preservation**: Verify that `list_by_status("active", limit)` continues to query GSI1, filter deleted tenants, and return correct results after the fix
2. **Other Method Preservation**: Verify `get_by_id`, `update`, `deactivate`, `activate`, `delete` continue to work identically
3. **Lambda Handler Preservation**: Verify `service.list_all(limit=limit)` call from the handler works correctly after fix

### Unit Tests

- Test `list_all` calls `list_by_status` with correct arguments (status="active", limit=N)
- Test `list_all` exception handler passes `self.request_context.target_tenant_id` to `_handle_service_exception`
- Test `list_by_status` exception handler passes `self.request_context.target_tenant_id` to `_handle_service_exception`
- Test `list_by_status` normal path returns filtered tenant list unchanged

### Property-Based Tests

- Generate random limit values and verify `list_all` delegates correctly to `list_by_status` without raising `NameError` or `TypeError`
- Generate random status values and verify `list_by_status` query behavior is preserved
- Generate random exception types and verify exception handlers produce valid `ServiceResult` errors with correct context

### Integration Tests

- Test full Lambda handler flow: event → `list_tenants` → `service.list_all(limit=limit)` → `ServiceResult`
- Test that the fix works end-to-end with a mocked DynamoDB backend
- Test error responses include correct `tenant_id` from `request_context` in error details
