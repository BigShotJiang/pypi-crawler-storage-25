# Implementation Plan

- [x] 1. Write bug condition exploration test
  - **Property 1: Bug Condition** - list_all and list_by_status NameError on Undefined Variables
  - **CRITICAL**: This test MUST FAIL on unfixed code - failure confirms the bug exists
  - **DO NOT attempt to fix the test or the code when it fails**
  - **NOTE**: This test encodes the expected behavior - it will validate the fix when it passes after implementation
  - **GOAL**: Surface counterexamples that demonstrate the NameError bug exists
  - **Scoped PBT Approach**: Scope the property to the concrete failing cases:
    - `list_all(limit)` for any limit value crashes with `NameError: name 'tenant_id' is not defined`
    - `list_by_status(status, limit)` exception handler crashes with `NameError: name 'tenant_id' is not defined` when an exception is raised during query execution
  - Create test file at `geek-cafe-saas-sdk/tests/test_tenant_list_bug_condition.py`
  - Use `unittest.mock` to mock DynamoDB and `request_context` dependencies on `TenantService`
  - Test 1: Call `service.list_all(limit=50)` — assert it does NOT raise `NameError` or `TypeError` and returns a `ServiceResult` (from Bug Condition isBugCondition: method_name == "list_all")
  - Test 2: Mock `_query_by_index` to raise an exception, call `service.list_by_status("active", limit=50)` — assert the exception handler does NOT raise `NameError` and returns a `ServiceResult` (from Bug Condition isBugCondition: method_name == "list_by_status" AND exception_raised == True)
  - Use property-based testing (Hypothesis) to generate random `limit` values (integers 1-1000) and verify `list_all` does not crash with `NameError` for any limit
  - Run tests on UNFIXED code
  - **EXPECTED OUTCOME**: Tests FAIL with `NameError: name 'tenant_id' is not defined` (this is correct - it proves the bug exists)
  - Document counterexamples found (e.g., "list_all(50) raises NameError", "list_by_status exception handler raises NameError")
  - Mark task complete when test is written, run, and failure is documented
  - _Requirements: 1.1, 1.2, 1.3, 1.4_

- [x] 2. Write preservation property tests (BEFORE implementing fix)
  - **Property 2: Preservation** - list_by_status Query Logic and Other Methods Unchanged
  - **IMPORTANT**: Follow observation-first methodology
  - Create test file at `geek-cafe-saas-sdk/tests/test_tenant_list_preservation.py`
  - Use `unittest.mock` to mock DynamoDB and `request_context` dependencies on `TenantService`
  - Observe on UNFIXED code: `list_by_status("active", limit=50)` queries GSI1 index with `temp_tenant.status = status`, `ascending=False`, filters deleted tenants, returns `ServiceResult`
  - Observe on UNFIXED code: Other methods (`get_by_id`, `update`, `deactivate`, `activate`, `delete`) work correctly using `self.request_context` pattern
  - Write property-based test (Hypothesis): For all valid status strings in {"active", "inactive", "archived"} and limit values (1-1000), `list_by_status` calls `_query_by_index` with correct GSI1 parameters and filters deleted tenants from results
  - Write preservation test: Verify `_handle_service_exception` receives valid keyword arguments (no undefined variable references) for methods other than `list_all` and `list_by_status` exception paths
  - Write preservation test: Verify the Lambda handler call pattern `service.list_all(limit=limit)` matches the expected signature
  - Run tests on UNFIXED code (only the `list_by_status` success-path and other-method tests — skip tests that would trigger the bug condition)
  - **EXPECTED OUTCOME**: Tests PASS (this confirms baseline behavior to preserve)
  - Mark task complete when tests are written, run, and passing on unfixed code
  - _Requirements: 3.1, 3.2, 3.3, 3.4_

- [x] 3. Fix for undefined variable references in list_all and list_by_status

  - [x] 3.1 Implement the fix
    - In `list_all`: Change `return self.list_by_status("active", tenant_id, user_id, limit)` to `return self.list_by_status("active", limit)`
    - In `list_all` exception handler: Change `tenant_id=tenant_id` to `tenant_id=self.request_context.target_tenant_id`
    - In `list_by_status` exception handler: Change `tenant_id=tenant_id` to `tenant_id=self.request_context.target_tenant_id`
    - Update `list_all` docstring: Remove `tenant_id: Requesting tenant ID` and `user_id: Requesting user ID` from Args
    - Update `list_by_status` docstring: Remove `tenant_id: Requesting tenant ID` and `user_id: Requesting user ID` from Args
    - File: `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/tenant_service.py`
    - _Bug_Condition: isBugCondition(input) where input.method_name == "list_all" OR (input.method_name == "list_by_status" AND input.exception_raised == True)_
    - _Expected_Behavior: list_all delegates to list_by_status("active", limit) without undefined variables; exception handlers use self.request_context.target_tenant_id_
    - _Preservation: list_by_status query logic (GSI1 query, deleted-tenant filtering, ServiceResult wrapping) and all other TenantService methods remain unchanged_
    - _Requirements: 2.1, 2.2, 2.3, 2.4_

  - [x] 3.2 Verify bug condition exploration test now passes
    - **Property 1: Expected Behavior** - list_all and list_by_status No Longer Crash
    - **IMPORTANT**: Re-run the SAME test from task 1 - do NOT write a new test
    - The test from task 1 encodes the expected behavior (no NameError, returns ServiceResult)
    - When this test passes, it confirms the expected behavior is satisfied
    - Run bug condition exploration test from step 1: `source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest geek-cafe-saas-sdk/tests/test_tenant_list_bug_condition.py -v`
    - **EXPECTED OUTCOME**: Test PASSES (confirms bug is fixed)
    - _Requirements: 2.1, 2.2, 2.3, 2.4_

  - [x] 3.3 Verify preservation tests still pass
    - **Property 2: Preservation** - list_by_status Query Logic and Other Methods Still Unchanged
    - **IMPORTANT**: Re-run the SAME tests from task 2 - do NOT write new tests
    - Run preservation property tests from step 2: `source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest geek-cafe-saas-sdk/tests/test_tenant_list_preservation.py -v`
    - **EXPECTED OUTCOME**: Tests PASS (confirms no regressions)
    - Confirm all tests still pass after fix (no regressions)

- [x] 4. Checkpoint - Ensure all tests pass
  - Run full test suite: `source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest geek-cafe-saas-sdk/tests/test_tenant_list_bug_condition.py geek-cafe-saas-sdk/tests/test_tenant_list_preservation.py -v`
  - Ensure all tests pass, ask the user if questions arise.
