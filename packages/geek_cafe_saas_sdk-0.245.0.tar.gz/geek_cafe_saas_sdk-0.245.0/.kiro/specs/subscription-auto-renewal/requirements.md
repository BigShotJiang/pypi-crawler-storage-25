# Requirements Document

## Introduction

This feature adds automatic subscription renewal, mid-cycle upgrade handling, and atomic pointer management to the existing subscription lifecycle in `geek-cafe-saas-sdk`. Today, creating a new subscription and swinging the active pointer requires a manual call to `activate_subscription()`. This spec introduces a `renew_subscription()` flow that creates a new subscription record with contiguous period dates, atomically swaps the active pointer using DynamoDB TransactWrite, and properly marks the old subscription. It also formalizes upgrade (mid-cycle plan change) handling and adds idempotency guards to prevent duplicate renewal records.

## Glossary

- **Subscription_Service**: The `SubscriptionService` class in `geek_cafe_saas_sdk.modules.tenancy.services.subscription_service` responsible for subscription CRUD, pointer management, and lifecycle operations.
- **Subscription**: The `Subscription` model (SDK base) representing a single subscription record in DynamoDB, including plan details, billing period timestamps, status, and payment tracking.
- **Acme_Subscription**: The `Subscription` model in `acme_saas_models.subscription` that extends the SDK Subscription with additional statuses (`disabled`, `restricted`), `renewal_cadence` metadata, grace period logic, and resource allocation metadata.
- **Active_Pointer**: A dedicated DynamoDB item (`PK=tenant#<tenant_id>`, `SK=subscription#active`) that stores the `active_subscription_id` for O(1) lookup of the current subscription.
- **Contiguous_Period**: A billing period where the new subscription's `current_period_start_utc_ts` equals the old subscription's `current_period_end_utc_ts`, ensuring no gap in coverage.
- **TransactWrite**: A DynamoDB transactional write operation (`transact_write_items`) that atomically commits multiple item writes, ensuring all-or-nothing semantics.
- **Renewal_Eligibility**: The set of preconditions that must be satisfied before a subscription can be auto-renewed (active status, not canceled, not disabled, valid billing interval).
- **Idempotency_Key**: A deterministic key derived from tenant ID and target period start timestamp, used to prevent duplicate renewal records for the same billing period.
- **Superseded**: A subscription status indicating the record was replaced by a newer subscription, either through renewal or mid-cycle upgrade.

## Requirements

### Requirement 1: Renewal Eligibility Check

**User Story:** As a billing system operator, I want the Subscription_Service to verify that a subscription is eligible for renewal before processing, so that renewals are only attempted on valid, active subscriptions.

#### Acceptance Criteria

1. WHEN a renewal is requested for a subscription, THE Subscription_Service SHALL verify that the subscription status is "active" or "trial" before proceeding.
2. WHEN a renewal is requested for a subscription with `cancel_at_period_end` set to true, THE Subscription_Service SHALL reject the renewal and return an error result with error code "RENEWAL_CANCELED".
3. WHEN a renewal is requested for a subscription with status "disabled", THE Subscription_Service SHALL reject the renewal and return an error result with error code "RENEWAL_DISABLED".
4. WHEN a renewal is requested for a subscription with status "past_due", THE Subscription_Service SHALL reject the renewal and return an error result with error code "RENEWAL_PAST_DUE".
5. WHEN a renewal is requested for a subscription with status "canceled" or "expired", THE Subscription_Service SHALL reject the renewal and return an error result with error code "RENEWAL_INELIGIBLE".
6. THE Subscription_Service SHALL expose a `check_renewal_eligibility` method that accepts a Subscription and returns a ServiceResult indicating eligibility or the specific rejection reason.

### Requirement 2: Contiguous Period Calculation

**User Story:** As a billing system operator, I want renewed subscriptions to have billing periods that are contiguous with the previous subscription, so that there are no gaps or overlaps in coverage.

#### Acceptance Criteria

1. WHEN a subscription is renewed, THE Subscription_Service SHALL set the new subscription's `current_period_start_utc_ts` equal to the old subscription's `current_period_end_utc_ts`.
2. WHEN a subscription with `billing_interval` "month" is renewed, THE Subscription_Service SHALL set the new subscription's `current_period_end_utc_ts` to exactly one calendar month after the new `current_period_start_utc_ts`.
3. WHEN a subscription with `billing_interval` "year" is renewed, THE Subscription_Service SHALL set the new subscription's `current_period_end_utc_ts` to exactly one calendar year after the new `current_period_start_utc_ts`.
4. THE Subscription_Service SHALL set the new subscription's `next_billing_utc_ts` equal to the new subscription's `current_period_end_utc_ts`.
5. IF the old subscription's `current_period_end_utc_ts` is null or zero, THEN THE Subscription_Service SHALL reject the renewal and return an error result with error code "INVALID_PERIOD".

### Requirement 3: Renew Subscription

**User Story:** As a billing system operator, I want a `renew_subscription` method that creates a new subscription record with contiguous dates and swings the active pointer, so that renewals can be processed when payment is confirmed.

#### Acceptance Criteria

1. WHEN `renew_subscription` is called with a valid active subscription ID, THE Subscription_Service SHALL create a new Subscription record that copies `plan_code`, `plan_name`, `plan_id`, `price_cents`, `currency`, `billing_interval`, `seat_count`, `payment_method`, `external_subscription_id`, `external_customer_id`, `active_addons`, and `addon_metadata` from the old subscription.
2. WHEN `renew_subscription` creates a new subscription, THE Subscription_Service SHALL set the new subscription's status to "active".
3. WHEN `renew_subscription` creates a new subscription, THE Subscription_Service SHALL set the old subscription's status to "expired".
4. WHEN `renew_subscription` completes successfully, THE Subscription_Service SHALL update the Active_Pointer to reference the new subscription's ID.
5. WHEN `renew_subscription` completes successfully, THE Subscription_Service SHALL return a ServiceResult containing the new Subscription.
6. IF `renew_subscription` is called for a subscription that fails the Renewal_Eligibility check, THEN THE Subscription_Service SHALL return the eligibility error without creating any records.

### Requirement 4: Atomic Pointer Swap with TransactWrite

**User Story:** As a system architect, I want the active pointer swap and subscription record writes to be atomic, so that the system never enters an inconsistent state where the pointer references a non-existent or stale subscription.

#### Acceptance Criteria

1. WHEN `renew_subscription` writes the new subscription record, updates the old subscription status, and updates the Active_Pointer, THE Subscription_Service SHALL execute all three writes in a single DynamoDB TransactWrite operation.
2. IF the TransactWrite operation fails, THEN THE Subscription_Service SHALL return an error result with error code "TRANSACTION_FAILED" and leave all records unchanged.
3. WHEN `activate_subscription` writes the new subscription record and updates the Active_Pointer, THE Subscription_Service SHALL execute both writes in a single DynamoDB TransactWrite operation (replacing the current sequential writes).
4. THE Subscription_Service SHALL use the `transact_write_items` method from `boto3_assist.dynamodb.dynamodb.DynamoDB` for all transactional writes.

### Requirement 5: Renewal Idempotency

**User Story:** As a billing system operator, I want renewal processing to be idempotent, so that if a renewal is triggered twice for the same billing period, only one new subscription record is created.

#### Acceptance Criteria

1. WHEN `renew_subscription` is called, THE Subscription_Service SHALL compute an Idempotency_Key from the tenant ID and the target period start timestamp (the old subscription's `current_period_end_utc_ts`).
2. WHEN a subscription already exists for the same tenant with `current_period_start_utc_ts` matching the target period start, THE Subscription_Service SHALL return the existing subscription instead of creating a duplicate.
3. WHEN the idempotency check finds an existing renewal, THE Subscription_Service SHALL return a ServiceResult with the existing subscription and a message indicating the renewal was already processed.

### Requirement 6: Mid-Cycle Upgrade Handling

**User Story:** As a billing system operator, I want mid-cycle plan changes (upgrades/downgrades) to properly mark the old subscription as superseded, so that the subscription history accurately reflects the reason each subscription ended.

#### Acceptance Criteria

1. WHEN `activate_subscription` is called while an active subscription already exists, THE Subscription_Service SHALL set the old subscription's status to "superseded".
2. WHEN `activate_subscription` marks an old subscription as superseded, THE Subscription_Service SHALL record the new subscription's ID in the old subscription's `notes` field as "Superseded by: <new_subscription_id>".
3. THE Subscription model SHALL accept "superseded" as a valid status value in the SDK base class.
4. THE Acme_Subscription model SHALL accept "superseded" as a valid status value.

### Requirement 7: Superseded Status in Subscription Model

**User Story:** As a developer, I want the Subscription model to support a "superseded" status, so that subscription history clearly distinguishes between expired (natural end), canceled (user action), and superseded (replaced by upgrade or renewal-triggered replacement) subscriptions.

#### Acceptance Criteria

1. THE Subscription model SHALL include "superseded" in the list of valid statuses: trial, active, past_due, canceled, expired, superseded.
2. THE Subscription model SHALL provide an `is_superseded` method that returns true when status equals "superseded".
3. THE Acme_Subscription model SHALL include "superseded" in the list of valid statuses: trial, active, past_due, canceled, expired, disabled, restricted, superseded.
