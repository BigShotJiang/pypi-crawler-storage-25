# Design Document: Subscription Auto-Renewal

## Overview

This design adds automatic subscription renewal, atomic pointer management, mid-cycle upgrade handling, and idempotency guards to the `SubscriptionService` in `geek-cafe-saas-sdk`. The core flow is: verify eligibility → check idempotency → compute contiguous period → create new subscription + expire old + swap pointer atomically via DynamoDB TransactWrite. The existing `activate_subscription()` is also upgraded to use TransactWrite and to mark superseded subscriptions.

All new logic lives in `SubscriptionService` with minor model changes to `Subscription` (SDK) and `Subscription` (Acme) to support the `"superseded"` status.

## Architecture

```mermaid
sequenceDiagram
    participant Caller
    participant SubscriptionService
    participant DynamoDB

    Caller->>SubscriptionService: renew_subscription(subscription_id)
    SubscriptionService->>DynamoDB: get active subscription
    SubscriptionService->>SubscriptionService: check_renewal_eligibility()
    alt Not eligible
        SubscriptionService-->>Caller: ServiceResult(error)
    end
    SubscriptionService->>SubscriptionService: compute idempotency key
    SubscriptionService->>DynamoDB: query GSI1 for existing renewal
    alt Already renewed
        SubscriptionService-->>Caller: ServiceResult(existing sub)
    end
    SubscriptionService->>SubscriptionService: calculate_contiguous_period()
    SubscriptionService->>SubscriptionService: build new Subscription (copy fields)
    SubscriptionService->>DynamoDB: TransactWrite [Put new sub, Update old sub → expired, Update pointer]
    alt Transaction fails
        SubscriptionService-->>Caller: ServiceResult(TRANSACTION_FAILED)
    end
    SubscriptionService-->>Caller: ServiceResult(new Subscription)
```

### activate_subscription() Upgrade

```mermaid
sequenceDiagram
    participant Caller
    participant SubscriptionService
    participant DynamoDB

    Caller->>SubscriptionService: activate_subscription(payload)
    SubscriptionService->>DynamoDB: get current active subscription (if any)
    alt Has existing active sub
        SubscriptionService->>SubscriptionService: mark old sub "superseded"
    end
    SubscriptionService->>DynamoDB: TransactWrite [Put new sub, (Update old → superseded), Update pointer]
    SubscriptionService->>SubscriptionService: update tenant plan_tier
    SubscriptionService-->>Caller: ServiceResult(new Subscription)
```

## Components and Interfaces

### New Methods on `SubscriptionService`

| Method | Signature | Description |
|---|---|---|
| `check_renewal_eligibility` | `(subscription: Subscription) -> ServiceResult` | Validates preconditions for renewal. Returns eligibility or specific error code. |
| `renew_subscription` | `(subscription_id: str) -> ServiceResult[Subscription]` | Full renewal flow: eligibility → idempotency → period calc → atomic write. |
| `_calculate_contiguous_period` | `(old_sub: Subscription) -> tuple[float, float, float]` | Returns `(new_start, new_end, next_billing)` timestamps. |
| `_build_renewal_subscription` | `(old_sub: Subscription, new_start: float, new_end: float, next_billing: float) -> Subscription` | Creates new Subscription copying plan fields from old. |
| `_compute_idempotency_key` | `(tenant_id: str, period_start_ts: float) -> str` | Deterministic key: `f"{tenant_id}#{int(period_start_ts)}"`. |
| `_find_existing_renewal` | `(tenant_id: str, period_start_ts: float) -> Subscription \| None` | Queries GSI1 for a subscription matching the target period start. |
| `_execute_transact_write` | `(operations: list[dict]) -> ServiceResult` | Wraps `self.dynamodb.transact_write_items()` with error handling. |

### Modified Methods on `SubscriptionService`

| Method | Change |
|---|---|
| `activate_subscription` | Use TransactWrite for atomic pointer swap. Mark existing active subscription as `"superseded"` with notes. |
| `_update_active_pointer` | Refactored to return a TransactWrite operation dict instead of performing a direct `put_item`. |

### Model Changes

| Model | Change |
|---|---|
| `Subscription` (SDK) | Add `"superseded"` to valid statuses. Add `is_superseded()` method. |
| `Subscription` (Acme) | Add `"superseded"` to valid statuses list. |

## Data Models

### Subscription Record (existing, no schema change)

The existing Subscription model fields are sufficient. The renewal flow copies these fields from old → new:

- `plan_code`, `plan_name`, `plan_id`, `price_cents`, `currency`, `billing_interval`
- `seat_count`, `payment_method`, `external_subscription_id`, `external_customer_id`
- `active_addons`, `addon_metadata`

New subscription gets:
- `status = "active"`
- `current_period_start_utc_ts = old.current_period_end_utc_ts`
- `current_period_end_utc_ts` = start + 1 month/year
- `next_billing_utc_ts = current_period_end_utc_ts`

Old subscription gets:
- `status = "expired"` (renewal) or `"superseded"` (mid-cycle upgrade)
- `notes = "Superseded by: <new_id>"` (upgrade only)

### Active Pointer Item (existing, no schema change)

```
PK: tenant#<tenant_id>
SK: subscription#active
active_subscription_id: <subscription_id>
modified_utc_ts: <timestamp>
updated_by_id: <user_id>
```

### TransactWrite Operation Structure

For `renew_subscription`, the transaction contains 3 operations:

```python
operations = [
    {
        "Put": {
            "TableName": table_name,
            "Item": new_subscription.to_resource_dictionary(),
        }
    },
    {
        "Update": {
            "TableName": table_name,
            "Key": {"pk": old_sub_pk, "sk": old_sub_sk},
            "UpdateExpression": "SET #status = :expired, modified_utc_ts = :now",
            "ExpressionAttributeNames": {"#status": "status"},
            "ExpressionAttributeValues": {":expired": "expired", ":now": now_ts},
        }
    },
    {
        "Put": {
            "TableName": table_name,
            "Item": pointer_item,
        }
    },
]
```

### Contiguous Period Calculation

Uses `dateutil.relativedelta` for calendar-accurate month/year arithmetic:

```python
from dateutil.relativedelta import relativedelta

new_start_dt = datetime.fromtimestamp(old_end_ts, tz=timezone.utc)
if billing_interval == "month":
    new_end_dt = new_start_dt + relativedelta(months=1)
elif billing_interval == "year":
    new_end_dt = new_start_dt + relativedelta(years=1)
new_end_ts = new_end_dt.timestamp()
```

### Idempotency Check

The idempotency key is derived from `tenant_id` and the target `current_period_start_utc_ts`. The check queries GSI1 (tenant subscriptions) and filters for a subscription whose `current_period_start_utc_ts` matches the old subscription's `current_period_end_utc_ts`. If found, the existing subscription is returned without creating a duplicate.

### Error Codes

| Code | Trigger |
|---|---|
| `RENEWAL_CANCELED` | `cancel_at_period_end` is true |
| `RENEWAL_DISABLED` | Status is `"disabled"` |
| `RENEWAL_PAST_DUE` | Status is `"past_due"` |
| `RENEWAL_INELIGIBLE` | Status is `"canceled"` or `"expired"` |
| `INVALID_PERIOD` | `current_period_end_utc_ts` is null or zero |
| `TRANSACTION_FAILED` | DynamoDB TransactWrite fails |


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Eligibility gate

*For any* Subscription, `check_renewal_eligibility` SHALL return success if and only if the subscription's status is `"active"` or `"trial"` AND `cancel_at_period_end` is false. For all other statuses or when `cancel_at_period_end` is true, it SHALL return a failure with the appropriate error code (`RENEWAL_CANCELED`, `RENEWAL_DISABLED`, `RENEWAL_PAST_DUE`, or `RENEWAL_INELIGIBLE`).

**Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5**

### Property 2: Contiguous period calculation

*For any* valid Subscription with a non-null, non-zero `current_period_end_utc_ts` and a `billing_interval` of `"month"` or `"year"`, `_calculate_contiguous_period` SHALL return a tuple where: (a) `new_start` equals the old subscription's `current_period_end_utc_ts`, (b) `new_end` equals exactly one calendar month or one calendar year after `new_start` (matching the billing interval), and (c) `next_billing` equals `new_end`.

**Validates: Requirements 2.1, 2.2, 2.3, 2.4**

### Property 3: Renewal output invariants

*For any* eligible Subscription that passes the renewal eligibility check, after `renew_subscription` completes successfully: (a) the new Subscription SHALL have `plan_code`, `plan_name`, `plan_id`, `price_cents`, `currency`, `billing_interval`, `seat_count`, `payment_method`, `external_subscription_id`, `external_customer_id`, `active_addons`, and `addon_metadata` equal to the old Subscription's values, (b) the new Subscription's status SHALL be `"active"`, (c) the old Subscription's status SHALL be `"expired"`, and (d) the active pointer SHALL reference the new Subscription's ID.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4**

### Property 4: Idempotency key determinism

*For any* tenant ID and period start timestamp, `_compute_idempotency_key` SHALL be a pure function: the same inputs always produce the same key, and different `(tenant_id, period_start_ts)` pairs produce different keys.

**Validates: Requirements 5.1**

### Property 5: Superseded invariants on mid-cycle upgrade

*For any* active Subscription, when `activate_subscription` is called with a new plan while the old subscription is active, the old Subscription's status SHALL be `"superseded"` and its `notes` field SHALL contain `"Superseded by: <new_subscription_id>"`.

**Validates: Requirements 6.1, 6.2**

### Property 6: is_superseded correctness

*For any* Subscription with any valid status, `is_superseded()` SHALL return `True` if and only if the status equals `"superseded"`.

**Validates: Requirements 7.2**

## Error Handling

### Eligibility Errors

The `check_renewal_eligibility` method returns specific error codes based on the rejection reason. These are returned as `ServiceResult` with `success=False`:

| Condition | Error Code | Message |
|---|---|---|
| `cancel_at_period_end` is true | `RENEWAL_CANCELED` | Subscription is set to cancel at period end |
| Status is `"disabled"` | `RENEWAL_DISABLED` | Subscription is disabled |
| Status is `"past_due"` | `RENEWAL_PAST_DUE` | Subscription has past due payments |
| Status is `"canceled"` or `"expired"` | `RENEWAL_INELIGIBLE` | Subscription is not in a renewable state |
| `current_period_end_utc_ts` is null/zero | `INVALID_PERIOD` | Subscription has no valid period end date |

The eligibility check is evaluated in priority order: `cancel_at_period_end` first (since an active subscription can be pending cancellation), then status checks.

### Transaction Errors

When `transact_write_items` raises an exception (e.g., `TransactionCanceledException`), the service catches it and returns:

```python
ServiceResult(
    success=False,
    message=f"Renewal transaction failed: {str(e)}",
    error_code="TRANSACTION_FAILED"
)
```

Because TransactWrite is atomic, no partial state is left behind — all records remain unchanged on failure.

### Idempotency Handling

When a duplicate renewal is detected, the service returns a successful `ServiceResult` containing the existing subscription, with a message: `"Renewal already processed for this billing period"`. This is not an error — it's a safe, expected outcome.

### General Exception Handling

All new methods follow the existing pattern of catching exceptions and returning `ServiceResult.exception_result(e, error_code=..., context=...)` to ensure consistent error reporting and logging via `aws_lambda_powertools`.

## Testing Strategy

### Property-Based Tests (Hypothesis)

The project uses Python, so we use [Hypothesis](https://hypothesis.readthedocs.io/) for property-based testing. Each property test runs a minimum of 100 iterations.

| Property | Test Description | Tag |
|---|---|---|
| Property 1 | Generate subscriptions with random statuses and cancel flags. Verify eligibility result matches expected logic. | `Feature: subscription-auto-renewal, Property 1: Eligibility gate` |
| Property 2 | Generate random valid period-end timestamps and billing intervals. Verify contiguous period calculation invariants. | `Feature: subscription-auto-renewal, Property 2: Contiguous period calculation` |
| Property 3 | Generate random eligible subscriptions with varied plan fields. Mock DynamoDB. Verify all renewal output invariants. | `Feature: subscription-auto-renewal, Property 3: Renewal output invariants` |
| Property 4 | Generate random tenant IDs and timestamps. Verify idempotency key is deterministic and collision-free. | `Feature: subscription-auto-renewal, Property 4: Idempotency key determinism` |
| Property 5 | Generate random active subscriptions. Mock DynamoDB. Call activate_subscription with new plan. Verify superseded status and notes. | `Feature: subscription-auto-renewal, Property 5: Superseded invariants on mid-cycle upgrade` |
| Property 6 | Generate subscriptions with all valid statuses. Verify is_superseded() returns True iff status is "superseded". | `Feature: subscription-auto-renewal, Property 6: is_superseded correctness` |

### Unit Tests (Example-Based)

| Test | Description |
|---|---|
| `test_check_renewal_eligibility_returns_service_result` | Verify method signature and return type |
| `test_renew_subscription_returns_new_subscription` | Happy path with mocked DynamoDB |
| `test_renew_idempotency_returns_existing` | Mock query returning existing renewal, verify no new writes |
| `test_renew_idempotency_message` | Verify the "already processed" message text |
| `test_transaction_failure_returns_error` | Mock transact_write_items to raise, verify TRANSACTION_FAILED |
| `test_ineligible_subscription_no_writes` | Verify no DynamoDB writes when eligibility fails |
| `test_superseded_status_valid_in_sdk_model` | Set status to "superseded" on SDK Subscription |
| `test_superseded_status_valid_in_acme_model` | Set status to "superseded" on Acme Subscription |
| `test_activate_uses_transact_write` | Verify activate_subscription calls transact_write_items |
| `test_invalid_period_rejection` | Subscription with null/zero period end returns INVALID_PERIOD |

### Integration Tests

| Test | Description |
|---|---|
| `test_renew_subscription_e2e` | Full renewal against local DynamoDB, verify all 3 items written |
| `test_activate_subscription_transactwrite_e2e` | Full activate against local DynamoDB, verify atomic write |
| `test_renew_idempotency_e2e` | Call renew twice, verify only one new subscription exists |
