# Requirements Document

## Introduction

The NCA SaaS platform manages tenant subscriptions across multiple projects: the SDK (`geek-cafe-saas-sdk`), the Acme models layer (`Acme-SaaS-Models`), the core bootstrap service (`Acme-SaaS-Core`), and the NCA services gate (`Acme-Services`). The current subscription lifecycle has three critical problems:

1. **Missing active pointer during bootstrap**: The `BootstrapOnboardingService._create_subscription()` uses raw `db.save()` which creates the subscription record but never writes the active subscription pointer (`PK=tenant#<tenant_id>`, `SK=subscription#active`). This causes `get_active_subscription()` to return `None`, and the `SubscriptionGateService` raises "No active subscription found for this tenant".

2. **Overloaded "active" terminology**: The word "active" means two different things — a subscription's `status` field can be `"active"` (meaning the subscription is valid/available), and separately a subscription can be "the active subscription" (meaning it is the one currently bound to the tenant via the pointer item). This creates confusion in code and conversation.

3. **Inconsistent creation paths**: `SubscriptionService.create()` saves a subscription without a pointer, `activate_subscription()` saves with a pointer atomically, and `BootstrapOnboardingService._create_subscription()` uses raw `db.save()` bypassing both. There is no single, enforced lifecycle path.

This feature establishes a clean subscription lifecycle: create → configure → bind (to tenant via pointer), with clear terminology and a single code path for making a subscription the tenant's current subscription.

## Glossary

- **Subscription_Service**: The `SubscriptionService` class in `geek-cafe-saas-sdk` that manages subscription CRUD, activation, renewal, and history operations.
- **Bootstrap_Service**: The `BootstrapOnboardingService` class in `Acme-SaaS-Core` that orchestrates first-time tenant onboarding (tenant, subscription, user, Cognito).
- **Subscription_Gate**: The `SubscriptionGateService` class in `Acme-Services` that performs subscription-level admission control before allowing executions.
- **Active_Pointer**: A DynamoDB item with `PK=tenant#<tenant_id>`, `SK=subscription#active` that stores `active_subscription_id` — providing O(1) lookup of the tenant's current subscription.
- **Bound_Subscription**: The subscription currently referenced by the Active_Pointer for a given tenant. This is the subscription the Subscription_Gate validates against.
- **Subscription_Status**: The `status` field on a subscription record. Valid values: `trial`, `active`, `past_due`, `canceled`, `expired`, `disabled`, `restricted`, `superseded`.
- **Subscription_Record**: A DynamoDB item with `PK=subscription#<id>`, `SK=subscription#<id>` representing a subscription's data and history.
- **TransactWrite**: A DynamoDB transactional write operation that atomically applies multiple Put/Update/Delete operations.

## Requirements

### Requirement 1: Bootstrap Subscription Binding

**User Story:** As a platform operator, I want the bootstrap onboarding process to create both the subscription record and the active pointer atomically, so that newly onboarded tenants have a working subscription immediately.

#### Acceptance Criteria

1. WHEN the Bootstrap_Service creates a new subscription during onboarding, THE Bootstrap_Service SHALL write both the Subscription_Record and the Active_Pointer in the same database operation.
2. WHEN the Bootstrap_Service updates an existing subscription during tenant re-onboarding, THE Bootstrap_Service SHALL update the Active_Pointer to reference the updated subscription.
3. WHEN the Bootstrap_Service completes subscription creation, THE Subscription_Service `get_active_subscription()` SHALL return the newly created subscription for that tenant.
4. IF the Active_Pointer write fails during bootstrap, THEN THE Bootstrap_Service SHALL report the failure in the `BootstrapResult` with `failed_step` set to `"subscription"`.

### Requirement 2: Single Binding Code Path

**User Story:** As a developer, I want a single, well-defined method for binding a subscription to a tenant, so that all code paths produce consistent results and the active pointer is never missing.

#### Acceptance Criteria

1. THE Subscription_Service SHALL provide a `bind_subscription` method that atomically writes the Subscription_Record and the Active_Pointer using a TransactWrite operation.
2. WHEN `bind_subscription` is called and an existing Bound_Subscription exists, THE Subscription_Service SHALL mark the old subscription's Subscription_Status as `"superseded"` within the same TransactWrite.
3. WHEN `bind_subscription` completes successfully, THE Subscription_Service SHALL update the tenant's `plan_tier` and `max_users` fields to match the new subscription.
4. THE Bootstrap_Service SHALL use the Subscription_Service `bind_subscription` method (or an equivalent internal helper that performs the same atomic write) instead of raw `db.save()` for subscription creation.
5. THE Subscription_Service `create()` method SHALL remain available for creating subscription records without binding, and its docstring SHALL clearly state that it does not create an Active_Pointer.

### Requirement 3: Terminology Clarification — Bound vs Status

**User Story:** As a developer, I want clear, unambiguous terminology distinguishing "the subscription bound to a tenant" from "a subscription whose status is active", so that code reviews and debugging are straightforward.

#### Acceptance Criteria

1. THE Subscription_Service SHALL use the term "bound" (or "bind") when referring to the subscription referenced by the Active_Pointer, and "status" when referring to the Subscription_Status field value.
2. THE Subscription_Service SHALL rename `activate_subscription()` to `bind_subscription()` to eliminate the overloaded use of "active".
3. THE Subscription_Service SHALL rename `get_active_subscription()` to `get_bound_subscription()` to clarify that the method retrieves the pointer-referenced subscription, not a subscription filtered by status.
4. THE Subscription_Gate SHALL update its `load_subscription()` method to call `get_bound_subscription()` instead of `get_active_subscription()`.
5. THE Subscription_Service SHALL update `_update_active_pointer()` and `_update_active_pointer_operation()` to use naming consistent with "bound" terminology (e.g., `_update_bound_pointer()` and `_update_bound_pointer_operation()`).

### Requirement 4: Subscription Gate Resilience

**User Story:** As a platform operator, I want the subscription gate to provide clear, actionable error messages when subscription validation fails, so that I can quickly diagnose onboarding or configuration issues.

#### Acceptance Criteria

1. WHEN the Subscription_Gate calls `get_bound_subscription()` and receives `None`, THE Subscription_Gate SHALL raise a `SubscriptionGateError` with error code `SUBSCRIPTION_NOT_FOUND` and a message that includes the tenant ID.
2. WHEN the Subscription_Gate calls `get_bound_subscription()` and the service call fails, THE Subscription_Gate SHALL raise a `SubscriptionGateError` with error code `SUBSCRIPTION_CHECK_FAILED` and include the underlying error message.
3. WHILE the subscription gate is disabled via the `SUBSCRIPTION_GATE_ENABLED` environment variable, THE Subscription_Gate SHALL log diagnostic information about what enforcement would have occurred and return `None` without raising errors.

### Requirement 5: Renewal Binding Consistency

**User Story:** As a platform operator, I want subscription renewals to use the same binding mechanism as initial activation, so that the active pointer is always updated consistently.

#### Acceptance Criteria

1. WHEN the Subscription_Service renews a subscription, THE Subscription_Service SHALL use the same `_update_bound_pointer_operation()` helper to update the Active_Pointer within the renewal TransactWrite.
2. WHEN a renewal TransactWrite completes, THE Active_Pointer SHALL reference the new renewal subscription's ID.
3. WHEN a renewal TransactWrite completes, THE old subscription's Subscription_Status SHALL be set to `"expired"`.

### Requirement 6: Bootstrap Idempotency for Subscription Binding

**User Story:** As a platform operator, I want re-running bootstrap onboarding for an existing tenant to update the subscription and rebind the pointer correctly, so that migration and recovery scenarios work reliably.

#### Acceptance Criteria

1. WHEN the Bootstrap_Service detects an existing subscription for a reused tenant, THE Bootstrap_Service SHALL update the existing Subscription_Record with current input values and ensure the Active_Pointer references the updated subscription.
2. WHEN the Bootstrap_Service creates a new subscription for a reused tenant (no existing subscription found), THE Bootstrap_Service SHALL create the Subscription_Record and Active_Pointer atomically.
3. FOR ALL bootstrap executions (new tenant or reused tenant), THE `get_bound_subscription()` method SHALL return a valid subscription after bootstrap completes successfully.

### Requirement 7: UI Cache Invalidation Signal

**User Story:** As a frontend developer, I want the subscription API responses to include a cache-busting version indicator, so that the UI can detect when subscription data has changed and refresh accordingly.

#### Acceptance Criteria

1. THE Subscription_Service SHALL include the subscription's `version` field and `modified_utc_ts` timestamp in all subscription response payloads.
2. WHEN the Subscription_Service modifies a subscription (bind, update, renew, cancel), THE Subscription_Service SHALL increment the `version` field on the Subscription_Record.
3. WHEN the Active_Pointer is updated, THE Active_Pointer item SHALL include a `modified_utc_ts` timestamp reflecting the time of the pointer update.
