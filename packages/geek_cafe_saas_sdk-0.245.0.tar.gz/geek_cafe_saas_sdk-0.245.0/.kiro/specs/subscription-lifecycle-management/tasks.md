# Implementation Plan: Subscription Lifecycle Management

## Overview

This plan implements a clean subscription lifecycle (create → configure → bind) across three projects: the SDK (`geek-cafe-saas-sdk`), the bootstrap service (`Acme-SaaS-Core`), and the subscription gate (`Acme-Services`). Changes are ordered so that SDK renames and new methods land first, then consumers are updated, then tests are added.

## Tasks

- [x] 1. Rename active-pointer methods to bound-pointer terminology in SubscriptionService
  - [x] 1.1 Rename `_update_active_pointer()` to `_update_bound_pointer()` and `_update_active_pointer_operation()` to `_update_bound_pointer_operation()` in `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`
    - Update method names, docstrings, and all internal call sites within the file
    - _Requirements: 3.1, 3.5_

  - [x] 1.2 Rename `activate_subscription()` to `bind_subscription()` in `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`
    - Rename the method, update `@service_method` tag to `"bind_subscription"`, update docstring to use "bind" terminology
    - Update the internal call from `self.get_active_subscription()` to `self.get_bound_subscription()` and from `self._update_active_pointer_operation()` to `self._update_bound_pointer_operation()`
    - _Requirements: 2.1, 3.1, 3.2_

  - [x] 1.3 Rename `get_active_subscription()` to `get_bound_subscription()` in `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`
    - Rename the method, update `@service_method` tag to `"get_bound_subscription"`, update docstring to use "bound" terminology
    - _Requirements: 3.1, 3.3_

  - [x] 1.4 Update `renew_subscription()` to call `_update_bound_pointer_operation()` instead of `_update_active_pointer_operation()`
    - In `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`
    - _Requirements: 5.1_

  - [x] 1.5 Update `create()` docstring to reference `bind_subscription()` instead of `activate_subscription()`
    - In `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`
    - _Requirements: 2.5_

- [x] 2. Add `_bind_subscription_no_auth()` method to SubscriptionService
  - [x] 2.1 Implement `_bind_subscription_no_auth(tenant_id, subscription, user_id)` in `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`
    - Skips `require_authentication()`, accepts tenant_id and pre-built Subscription directly
    - Performs the same atomic TransactWrite as `bind_subscription()`: put subscription, supersede old bound sub (if any), put active pointer
    - Sets `version=1` on new subscriptions (via `prep_for_save()`)
    - Reuses `_update_bound_pointer_operation()` and `_execute_transact_write()` internals
    - Reads existing pointer directly via `dynamodb.resource.Table().get_item()` (no auth required)
    - _Requirements: 2.1, 2.4, 1.1_

- [x] 3. Checkpoint — Verify SDK changes
  - Ensure all tests pass in `geek-cafe-saas-sdk`, ask the user if questions arise.

- [x] 4. Update BootstrapOnboardingService to use binding
  - [x] 4.1 Add optional `subscription_service` parameter to `BootstrapOnboardingService.__init__()` in `Acme-SaaS-Core/src/acme_saas_core/services/bootstrap_onboarding_service.py`
    - If not provided, create a `SubscriptionService` internally using existing `db` and `table_name`
    - Add import for `SubscriptionService`
    - _Requirements: 2.4_

  - [x] 4.2 Update `_create_subscription()` to use `_bind_subscription_no_auth()` instead of `db.save()`
    - Build the Subscription model, call `prep_for_save()`, then call `self.subscription_service._bind_subscription_no_auth(tenant_id, subscription, user_id=None)`
    - On failure, let the exception propagate so `bootstrap()` catches it with `failed_step="subscription"`
    - _Requirements: 1.1, 1.3, 1.4, 2.4_

  - [x] 4.3 Update the re-onboarding subscription path in `bootstrap()` to use `_bind_subscription_no_auth()`
    - Replace the `self.db.save()` call in the `tenant_reused` + existing subscription branch with `_bind_subscription_no_auth()`
    - Also replace the `_create_subscription()` call in the `tenant_reused` + no existing subscription branch (already handled by 4.2)
    - _Requirements: 1.2, 6.1, 6.2, 6.3_

- [x] 5. Checkpoint — Verify bootstrap changes
  - Ensure all tests pass in `Acme-SaaS-Core`, ask the user if questions arise.

- [x] 6. Update SubscriptionGateService to use bound terminology
  - [x] 6.1 Update `load_subscription()` in `Acme-Services/src/acme_services/services/subscription_gate.py` to call `get_bound_subscription()` instead of `get_active_subscription()`
    - Update all three call sites: the diagnostic block (gate disabled), the main path, and the error handling
    - Update the `SUBSCRIPTION_NOT_FOUND` error message to include the tenant_id
    - _Requirements: 3.4, 4.1, 4.2, 4.3_

- [x] 7. Checkpoint — Verify gate changes
  - Ensure all tests pass in `Acme-Services`, ask the user if questions arise.

- [x] 8. Property-based tests for subscription lifecycle
  - [ ]* 8.1 Write property test for binding atomicity (Property 1)
    - **Property 1: Binding atomicity — TransactWrite contains subscription and pointer**
    - Use Hypothesis to generate valid tenant IDs and subscription data, mock DynamoDB, verify TransactWrite operations list contains exactly one Put for the subscription and one Put for the active pointer with matching `active_subscription_id`
    - Test both `bind_subscription` and `_bind_subscription_no_auth` paths
    - Place test in `geek-cafe-saas-sdk/tests/properties/test_subscription_lifecycle_properties.py`
    - **Validates: Requirements 1.1, 2.1, 6.2**

  - [ ]* 8.2 Write property test for supersession of existing bound subscription (Property 2)
    - **Property 2: Supersession of existing bound subscription**
    - Use Hypothesis to generate binding scenarios where an existing bound subscription is present, verify TransactWrite contains an Update setting old sub status to `"superseded"` with `modified_utc_ts`
    - **Validates: Requirements 2.2**

  - [ ]* 8.3 Write property test for re-onboarding pointer consistency (Property 3)
    - **Property 3: Re-onboarding pointer consistency**
    - Use Hypothesis to generate re-onboarding scenarios (existing tenant with/without existing subscription), verify the pointer's `active_subscription_id` matches the subscription being bound
    - **Validates: Requirements 1.2, 6.1**

  - [ ]* 8.4 Write property test for renewal pointer and expiration (Property 4)
    - **Property 4: Renewal pointer and expiration**
    - Use Hypothesis to generate renewable subscriptions, verify TransactWrite contains: Put for new sub, Update setting old sub status to `"expired"`, Put for pointer with matching `active_subscription_id`
    - **Validates: Requirements 5.1, 5.2, 5.3**

  - [ ]* 8.5 Write property test for subscription serialization includes version and timestamp (Property 5)
    - **Property 5: Subscription serialization includes version and timestamp**
    - Use Hypothesis to generate random Subscription instances, call `to_resource_dictionary()`, assert `version` and `modified_utc_ts` keys exist
    - **Validates: Requirements 7.1**

  - [ ]* 8.6 Write property test for version monotonicity on mutation (Property 6)
    - **Property 6: Version monotonicity on mutation**
    - Use Hypothesis to generate subscriptions with random version values, perform mutation operations (update, cancel, record_payment, mark_past_due), assert version equals V + 1
    - **Validates: Requirements 7.2**

  - [ ]* 8.7 Write property test for pointer item includes timestamp (Property 7)
    - **Property 7: Pointer item includes timestamp**
    - Use Hypothesis to generate random tenant IDs, subscription IDs, and user IDs, call `_update_bound_pointer_operation()`, assert returned item contains `modified_utc_ts` with numeric value > 0
    - **Validates: Requirements 7.3**

- [x] 9. Unit tests for subscription lifecycle
  - [ ]* 9.1 Write unit tests for SubscriptionService renames and bind
    - Test `bind_subscription()` with valid payload returns success
    - Test `bind_subscription()` with missing required fields returns validation error
    - Test `_bind_subscription_no_auth()` does not call `require_authentication()`
    - Test `get_bound_subscription()` with no pointer returns None
    - Test `create()` does not write an active pointer
    - Place tests in `geek-cafe-saas-sdk/tests/unit/test_subscription_service_lifecycle.py`
    - _Requirements: 2.1, 2.2, 2.4, 2.5, 3.2, 3.3_

  - [ ]* 9.2 Write unit tests for SubscriptionGateService updates
    - Test `load_subscription()` with None subscription raises `SUBSCRIPTION_NOT_FOUND` with tenant_id in message
    - Test `load_subscription()` with service exception raises `SUBSCRIPTION_CHECK_FAILED`
    - Test gate disabled returns None with diagnostic logging
    - Place tests in `Acme-Services/tests/unit/test_subscription_gate_lifecycle.py`
    - _Requirements: 4.1, 4.2, 4.3_

  - [ ]* 9.3 Write unit tests for BootstrapOnboardingService binding
    - Test `_create_subscription()` calls `_bind_subscription_no_auth` instead of `db.save()`
    - Test re-onboarding with existing subscription updates pointer via `_bind_subscription_no_auth`
    - Test re-onboarding with no existing subscription creates subscription and pointer atomically
    - Test tenant `plan_tier` is correctly mapped after bind
    - Place tests in `Acme-SaaS-Core/tests/unit/test_bootstrap_subscription_binding.py`
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 6.1, 6.2, 6.3_

- [x] 10. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass across all three projects, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- SDK changes (tasks 1–2) must land before consumer changes (tasks 4, 6)
- Property tests validate the seven correctness properties from the design document using Hypothesis
- Unit tests validate specific examples and edge cases
- Checkpoints ensure incremental validation across the three project boundaries
