# Design Document: Subscription Lifecycle Management

## Overview

This design establishes a clean subscription lifecycle — create → configure → bind — across the SDK (`geek-cafe-saas-sdk`), bootstrap service (`Acme-SaaS-Core`), subscription gate (`Acme-Services`), and models layer (`Acme-SaaS-Models`). The core change replaces the overloaded "active/activate" terminology with "bound/bind" and ensures every code path that makes a subscription the tenant's current subscription writes the active pointer atomically.

The design addresses three problems:
1. The bootstrap service creates subscriptions without writing the active pointer, leaving tenants in a broken state.
2. The word "active" is overloaded — it means both "the pointer-referenced subscription" and "a subscription whose status field is `active`".
3. Multiple code paths (SDK `create()`, SDK `activate_subscription()`, bootstrap `_create_subscription()`) produce inconsistent results.

After this change, `bind_subscription()` is the single method for making a subscription the tenant's current subscription, and the bootstrap service uses an internal helper that performs the same atomic write without requiring a `SecurityToken`.

## Architecture

### Cross-Project Change Map

```mermaid
graph TD
    subgraph "geek-cafe-saas-sdk"
        SS[SubscriptionService]
        SS -->|rename| BS[bind_subscription]
        SS -->|rename| GBS[get_bound_subscription]
        SS -->|rename| UBP[_update_bound_pointer]
        SS -->|rename| UBPO[_update_bound_pointer_operation]
        SS -->|new| BSNH[_bind_subscription_no_auth]
    end

    subgraph "Acme-SaaS-Core"
        BOS[BootstrapOnboardingService]
        BOS -->|calls| BSNH
    end

    subgraph "Acme-Services"
        SGS[SubscriptionGateService]
        SGS -->|calls| GBS
    end

    subgraph "Acme-SaaS-Models"
        SUB[Subscription model]
        SUB -->|unchanged| SUB
    end
```

### Binding Flow

```mermaid
sequenceDiagram
    participant Caller
    participant SubscriptionService
    participant DynamoDB

    Caller->>SubscriptionService: bind_subscription(payload)
    SubscriptionService->>SubscriptionService: Validate required fields
    SubscriptionService->>SubscriptionService: Build Subscription model
    SubscriptionService->>DynamoDB: get_item(pointer) — check existing bound sub
    DynamoDB-->>SubscriptionService: existing pointer (or none)
    
    Note over SubscriptionService: Build TransactWrite operations
    SubscriptionService->>DynamoDB: TransactWrite [Put sub, Update old→superseded, Put pointer]
    DynamoDB-->>SubscriptionService: Success
    
    SubscriptionService->>DynamoDB: Update tenant plan_tier (non-critical)
    SubscriptionService-->>Caller: ServiceResult[Subscription]
```

### Bootstrap Binding Flow

```mermaid
sequenceDiagram
    participant Bootstrap as BootstrapOnboardingService
    participant SS as SubscriptionService
    participant DynamoDB

    Bootstrap->>SS: _bind_subscription_no_auth(tenant_id, subscription, user_id)
    SS->>DynamoDB: get_item(pointer) — check existing bound sub
    DynamoDB-->>SS: existing pointer (or none)
    
    Note over SS: Build TransactWrite operations
    SS->>DynamoDB: TransactWrite [Put sub, Update old→superseded, Put pointer]
    DynamoDB-->>SS: Success
    SS-->>Bootstrap: ServiceResult[Subscription]
```

## Components and Interfaces

### 1. SubscriptionService (geek-cafe-saas-sdk)

#### Renamed Methods

| Current Name | New Name | Notes |
|---|---|---|
| `activate_subscription()` | `bind_subscription()` | Public, `@service_method`, requires auth |
| `get_active_subscription()` | `get_bound_subscription()` | Public, `@service_method`, requires auth |
| `_update_active_pointer()` | `_update_bound_pointer()` | Internal, direct put or TransactWrite op |
| `_update_active_pointer_operation()` | `_update_bound_pointer_operation()` | Internal, returns TransactWrite Put dict |

#### New Method: `_bind_subscription_no_auth()`

```python
def _bind_subscription_no_auth(
    self,
    tenant_id: str,
    subscription: Subscription,
    user_id: str | None = None,
) -> ServiceResult[Subscription]:
    """
    Bind a subscription to a tenant without requiring authentication.
    
    Used by the bootstrap service which operates without a SecurityToken.
    Performs the same atomic TransactWrite as bind_subscription():
    1. Put subscription record
    2. Supersede existing bound subscription (if any)
    3. Put/update active pointer
    
    Args:
        tenant_id: Tenant ID to bind to.
        subscription: Pre-built Subscription with prep_for_save() already called.
        user_id: Optional user ID for audit trail on the pointer.
    
    Returns:
        ServiceResult with the bound Subscription.
    """
```

This method skips `self.request_context.require_authentication()` and accepts the tenant_id and subscription directly. It reuses the same `_update_bound_pointer_operation()` and `_execute_transact_write()` internals.

#### Modified Method: `bind_subscription()` (renamed from `activate_subscription()`)

The logic remains the same — validate, build subscription, check for existing bound sub, TransactWrite atomically. The only changes are:
- Method name: `bind_subscription`
- `@service_method("bind_subscription")`
- Docstring updated to use "bind" terminology
- Increments `version` on the new subscription before save
- Includes `modified_utc_ts` on the pointer item (already present in `_update_bound_pointer_operation`)

#### Modified Method: `get_bound_subscription()` (renamed from `get_active_subscription()`)

Same logic — reads the pointer item (`PK=tenant#<id>`, `SK=subscription#active`), then fetches the subscription by ID. Only the method name and `@service_method` tag change.

#### Modified Method: `renew_subscription()`

Already uses `_update_active_pointer_operation()` — will be updated to call `_update_bound_pointer_operation()` instead. No logic change.

#### `create()` — Unchanged

Remains available for creating subscription records without binding. Docstring already states it does not create an active pointer.

### 2. BootstrapOnboardingService (Acme-SaaS-Core)

#### Modified Methods

**`_create_subscription()`** — Instead of `self.db.save()`, will:
1. Build the `Subscription` model and call `prep_for_save()`
2. Instantiate a `SubscriptionService` (passing `dynamodb` and `table_name`, no `request_context`)
3. Call `subscription_service._bind_subscription_no_auth(tenant_id, subscription, user_id=None)`

**`bootstrap()`** — The subscription update path for reused tenants will also use `_bind_subscription_no_auth()` instead of raw `db.save()`.

#### Constructor Change

The `BootstrapOnboardingService.__init__()` will accept an optional `subscription_service` parameter. If not provided, it will create one internally using the existing `db` and `table_name`.

### 3. SubscriptionGateService (Acme-Services)

#### Modified Method: `load_subscription()`

All calls to `self._subscription_service.get_active_subscription()` become `self._subscription_service.get_bound_subscription()`.

The error messages and error codes remain the same (`SUBSCRIPTION_NOT_FOUND`, `SUBSCRIPTION_CHECK_FAILED`). The diagnostic logging block also updates to call `get_bound_subscription()`.

### 4. Subscription Model (Acme-SaaS-Models)

No changes to the model itself. The `version` field already exists on `BaseModel` (starts at `1.0`). The `modified_utc_ts` field already exists. The `status` setter already validates the `superseded` status value.

## Data Models

### Active Pointer Item (DynamoDB)

The pointer item structure remains unchanged:

| Attribute | Type | Description |
|---|---|---|
| `pk` | String | `tenant#<tenant_id>` |
| `sk` | String | `subscription#active` |
| `active_subscription_id` | String | ID of the bound subscription |
| `modified_utc_ts` | Number (Decimal) | Timestamp of last pointer update |
| `updated_by_id` | String | User who last updated the pointer |

### Subscription Record (DynamoDB)

Existing structure, with these fields relevant to this feature:

| Attribute | Type | Description |
|---|---|---|
| `pk` | String | `subscription#<id>` |
| `sk` | String | `subscription#<id>` |
| `version` | Number | Incremented on every mutation (bind, update, renew, cancel) |
| `modified_utc_ts` | Number | Timestamp of last modification |
| `status` | String | One of: trial, active, past_due, canceled, expired, disabled, restricted, superseded |

### TransactWrite Operation Structure (bind_subscription)

The atomic transaction includes 2–3 operations:

1. **Put** — New subscription record
2. **Update** (conditional) — Mark old bound subscription as `superseded`, set `modified_utc_ts`
3. **Put** — Active pointer item with `active_subscription_id`, `modified_utc_ts`, `updated_by_id`

### Version Increment Rules

| Operation | Version Behavior |
|---|---|
| `bind_subscription()` | New subscription starts at `version=1.0` (from `prep_for_save()`) |
| `renew_subscription()` | New renewal subscription starts at `version=1.0`; old subscription's version is not incremented (it's expired via raw Update) |
| `update()` | `version += 1` |
| `cancel_subscription()` | `version += 1` |
| `record_payment()` | `version += 1` |
| `mark_past_due()` | `version += 1` |


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Binding atomicity — TransactWrite contains subscription and pointer

*For any* valid tenant ID and subscription data, the TransactWrite operations list produced by the binding operation (both `bind_subscription` and `_bind_subscription_no_auth`) SHALL contain exactly one Put operation for the subscription record and exactly one Put operation for the active pointer item with `active_subscription_id` matching the new subscription's ID.

**Validates: Requirements 1.1, 2.1, 6.2**

### Property 2: Supersession of existing bound subscription

*For any* binding operation where an existing bound subscription is present, the TransactWrite operations list SHALL contain an Update operation that sets the old subscription's status to `"superseded"` and includes a `modified_utc_ts` timestamp.

**Validates: Requirements 2.2**

### Property 3: Re-onboarding pointer consistency

*For any* re-onboarding operation (existing tenant with or without an existing subscription), the resulting binding operation SHALL produce a pointer item whose `active_subscription_id` matches the subscription being bound.

**Validates: Requirements 1.2, 6.1**

### Property 4: Renewal pointer and expiration

*For any* renewable subscription, the renewal TransactWrite operations list SHALL contain: (a) a Put for the new subscription, (b) an Update setting the old subscription's status to `"expired"`, and (c) a Put for the active pointer with `active_subscription_id` matching the new renewal subscription's ID.

**Validates: Requirements 5.1, 5.2, 5.3**

### Property 5: Subscription serialization includes version and timestamp

*For any* subscription instance, calling `to_resource_dictionary()` SHALL produce a dictionary containing both a `version` field and a `modified_utc_ts` field.

**Validates: Requirements 7.1**

### Property 6: Version monotonicity on mutation

*For any* subscription with version V, after a mutation operation (update, cancel, record_payment, mark_past_due), the subscription's version SHALL equal V + 1.

**Validates: Requirements 7.2**

### Property 7: Pointer item includes timestamp

*For any* call to `_update_bound_pointer_operation()`, the returned Put operation's Item SHALL contain a `modified_utc_ts` field with a numeric value greater than zero.

**Validates: Requirements 7.3**

## Error Handling

### SubscriptionService

| Scenario | Behavior |
|---|---|
| `bind_subscription()` — missing required fields | Returns `ServiceResult(success=False)` with `VALIDATION_ERROR` |
| `bind_subscription()` — TransactWrite fails | Returns `ServiceResult(success=False)` with `TRANSACTION_FAILED` |
| `bind_subscription()` — tenant update fails after bind | Logs warning, returns success (subscription is already bound) |
| `_bind_subscription_no_auth()` — TransactWrite fails | Returns `ServiceResult(success=False)` with `TRANSACTION_FAILED` |
| `get_bound_subscription()` — no pointer item | Returns `ServiceResult(success=True, data=None)` |
| `get_bound_subscription()` — pointer exists but subscription not found | Returns `ServiceResult(success=False)` with `NOT_FOUND` |
| `renew_subscription()` — ineligible status | Returns `ServiceResult(success=False)` with specific error code (RENEWAL_CANCELED, RENEWAL_DISABLED, etc.) |

### BootstrapOnboardingService

| Scenario | Behavior |
|---|---|
| `_create_subscription()` — binding fails | `bootstrap()` returns `BootstrapResult(success=False, failed_step="subscription")` |
| Re-onboarding subscription update — binding fails | `bootstrap()` returns `BootstrapResult(success=False, failed_step="subscription_lookup")` |

### SubscriptionGateService

| Scenario | Behavior |
|---|---|
| `get_bound_subscription()` returns None | Raises `SubscriptionGateError(SUBSCRIPTION_NOT_FOUND)` with tenant ID in message |
| `get_bound_subscription()` raises exception | Raises `SubscriptionGateError(SUBSCRIPTION_CHECK_FAILED)` with underlying error |
| Gate disabled via env var | Logs diagnostic info, returns None |

## Testing Strategy

### Property-Based Tests (Hypothesis)

The project uses Python with pytest. Property-based tests will use the [Hypothesis](https://hypothesis.readthedocs.io/) library.

Each correctness property maps to a single property-based test with a minimum of 100 iterations. Tests will use mocks for DynamoDB interactions and focus on verifying the structure of TransactWrite operations lists and model state transitions.

**Test configuration:**
- Library: `hypothesis` with `@given` decorator
- Minimum iterations: 100 (via `@settings(max_examples=100)`)
- Each test tagged with: `Feature: subscription-lifecycle-management, Property {N}: {title}`

**Property test targets:**
- Properties 1–4: Test the TransactWrite operations list structure by mocking `get_bound_subscription()` / `get_active_subscription()` return values and capturing the operations list passed to `_execute_transact_write()`.
- Property 5: Generate random Subscription instances, call `to_resource_dictionary()`, assert `version` and `modified_utc_ts` keys exist.
- Property 6: Generate random subscriptions with random version values, perform mutation, assert version incremented by 1.
- Property 7: Generate random tenant IDs, subscription IDs, and user IDs, call `_update_bound_pointer_operation()`, assert `modified_utc_ts` in the returned item.

### Unit Tests (Example-Based)

- `bind_subscription()` with valid payload — verify success result
- `bind_subscription()` with missing required fields — verify validation error
- `_bind_subscription_no_auth()` — verify it does not call `require_authentication()`
- `get_bound_subscription()` with no pointer — verify returns None
- `create()` — verify no pointer is written
- SubscriptionGate `load_subscription()` — None subscription raises SUBSCRIPTION_NOT_FOUND
- SubscriptionGate `load_subscription()` — service exception raises SUBSCRIPTION_CHECK_FAILED
- SubscriptionGate disabled — returns None with diagnostic logging
- Bootstrap `_create_subscription()` — verify calls `_bind_subscription_no_auth`
- Bootstrap re-onboarding — verify pointer updated for existing subscription
- Tenant plan_tier update after bind — verify correct mapping

### Integration Tests

- End-to-end bootstrap → `get_bound_subscription()` returns valid subscription (new tenant)
- End-to-end bootstrap → `get_bound_subscription()` returns valid subscription (reused tenant)
- Renewal → `get_bound_subscription()` returns new renewal subscription
