# Tenant Admin Access Denied Bugfix Design

## Overview

Tenant admins are denied access when retrieving their own tenant via `GET /v3/tenants/{tenant-id}` because the `Tenant` model lacks a `tenant_id` property. The `Tenant` model extends `BaseModel` directly (not `BaseTenantModel`), so `AccessChecker.check_model_access()` extracts `None` from `getattr(model, 'tenant_id', None)`, causing all tenant-scoped access checks to fail. The fix is to add a read-only `tenant_id` property to the `Tenant` model that returns `self.id`, since a Tenant IS the tenant (self-referential identity).

## Glossary

- **Bug_Condition (C)**: The condition that triggers the bug — when `AccessChecker.check_model_access()` is called on a `Tenant` model instance and `getattr(model, 'tenant_id', None)` returns `None`
- **Property (P)**: The desired behavior — `Tenant.tenant_id` should return `self.id`, enabling `AccessChecker` to correctly resolve the resource's tenant and grant access to tenant admins
- **Preservation**: Existing access behavior for platform admins, system contexts, cross-tenant denial, and all other models that already define `tenant_id` must remain unchanged
- **Tenant model**: The class in `modules/tenancy/models/tenant.py` that extends `BaseModel` directly (not `BaseTenantModel`)
- **BaseTenantModel**: The class in `core/models/base_tenant_model.py` that defines `self.tenant_id` as a plain attribute — used by most other models but NOT by `Tenant`
- **AccessChecker.check_model_access()**: The centralized access validation method in `core/access/access_checker.py` that extracts `resource_tenant_id` via `getattr(model, 'tenant_id', None)`
- **resource_tenant_id**: The value extracted from a model by `AccessChecker` to determine which tenant owns the resource

## Bug Details

### Bug Condition

The bug manifests when any non-platform-admin, non-system-context user attempts to retrieve a `Tenant` model through `_get_by_id()`. The `AccessChecker.check_model_access()` method extracts `resource_tenant_id` as `None` because the `Tenant` class has no `tenant_id` attribute or property. This causes the tenant admin check (`resource_tenant_id == user_tenant_id`) to evaluate as `None == "tenant-123"` → `False`, and all subsequent tenant-scoped checks (field matching, tenant-wide access) also fail because `is_same_tenant` evaluates incorrectly.

**Formal Specification:**
```
FUNCTION isBugCondition(model, request_context)
  INPUT: model of type BaseModel, request_context of type RequestContext
  OUTPUT: boolean

  resource_tenant_id := getattr(model, 'tenant_id', None)

  RETURN model IS instance of Tenant
         AND resource_tenant_id IS None
         AND NOT request_context.is_platform_admin()
         AND NOT request_context.roles CONTAINS 'system'
         AND NOT request_context.authenticated_user_id == 'system'
END FUNCTION
```

### Examples

- **Tenant admin retrieves own tenant**: User with `tenant_admin` role and `authenticated_tenant_id = "t-001"` calls `GET /v3/tenants/t-001`. `AccessChecker` extracts `resource_tenant_id = None`. Tenant admin check: `None == "t-001"` → `False`. Result: Access denied (masked as 404). Expected: Access granted as `tenant_admin`.
- **Regular user retrieves own tenant**: User with `authenticated_tenant_id = "t-001"` calls `GET /v3/tenants/t-001`. `AccessChecker` extracts `resource_tenant_id = None`. `is_same_tenant` evaluates as `None == "t-001"` → `False` (not `None is None` since it's a comparison). Field checks and tenant-wide access all fail. Result: Access denied. Expected: Access evaluated through normal access chain with correct tenant context.
- **Platform admin retrieves any tenant**: User with `platform_admin` role calls `GET /v3/tenants/t-002`. `AccessChecker` grants access at step 2 (platform admin check) before ever reading `tenant_id`. Result: Access granted. This case is NOT affected by the bug.
- **Cross-tenant attempt**: User with `authenticated_tenant_id = "t-001"` calls `GET /v3/tenants/t-002`. With the fix, `resource_tenant_id = "t-002"`, tenant admin check: `"t-002" != "t-001"` → correctly denied. Without the fix, also denied but for the wrong reason (`None != "t-001"`).

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- Platform admin access to any tenant must continue to be granted at step 2 of `check_model_access()`
- System context access must continue to be granted at step 1 of `check_model_access()`
- Cross-tenant access denial must continue to work — a tenant admin from tenant A must NOT access tenant B's record
- All other models that already have `tenant_id` (via `BaseTenantModel` or `BaseTenantUserModel`) must continue to resolve `resource_tenant_id` from their existing attributes without any change
- The `Tenant` model's DynamoDB serialization must not be affected — the `tenant_id` property should not introduce a new persisted field if the model doesn't already store one
- Mouse/API interactions that don't involve `Tenant` model retrieval must be completely unaffected

**Scope:**
All inputs that do NOT involve retrieving a `Tenant` model through `AccessChecker.check_model_access()` should be completely unaffected by this fix. This includes:
- Access checks on User, File, Subscription, and all other models
- Platform admin and system context access to Tenant models (these bypass the tenant_id check)
- Tenant creation flows (which set `tenant.tenant_id = tenant.id` explicitly before save)

## Hypothesized Root Cause

Based on the code analysis, the root cause is confirmed (not just hypothesized):

1. **Missing `tenant_id` on Tenant model**: The `Tenant` class extends `BaseModel` directly, not `BaseTenantModel`. This is intentional — a Tenant IS the tenant, so it doesn't "belong to" another tenant. However, `AccessChecker.check_model_access()` uses `getattr(model, 'tenant_id', None)` uniformly on all models, and `Tenant` returns `None` because it has no such attribute or property.

2. **Self-referential identity gap**: The `TenantService.create()` and `create_with_user()` methods both set `tenant.tenant_id = tenant.id` before saving, which works because `BaseModel.__setattr__` allows setting attributes during initialization. But this is a transient assignment — when the model is later fetched from DynamoDB and deserialized, the `tenant_id` value from the database is loaded via `load_from_dictionary()`, but since `Tenant` has no `tenant_id` property or attribute defined in its class, the strict property enforcement in `BaseModel.__setattr__` may reject it, or it may be silently dropped depending on the deserialization path.

3. **AccessChecker assumes all models have tenant_id**: The `check_model_access()` method's step 3 (tenant admin check) and `is_same_tenant` calculation both depend on `resource_tenant_id` being non-None for tenant-scoped resources. When it's `None`, the tenant admin check fails, and `is_same_tenant` evaluates to `True` (because `resource_tenant_id is None` is treated as "system/global resource"), but the field checks in step 4 still don't match because the user isn't the owner/creator of the tenant in most cases.

## Correctness Properties

Property 1: Bug Condition - Tenant model returns self.id as tenant_id

_For any_ `Tenant` model instance where `self.id` is set, the `tenant_id` property SHALL return `self.id`, ensuring that `AccessChecker.check_model_access()` extracts a non-None `resource_tenant_id` equal to the tenant's own ID.

**Validates: Requirements 2.1, 2.2, 2.3**

Property 2: Preservation - Non-Tenant model access unchanged

_For any_ model that is NOT a `Tenant` instance (e.g., User, File, Subscription) and already defines `tenant_id` via `BaseTenantModel` or `BaseTenantUserModel`, the `AccessChecker.check_model_access()` method SHALL produce the same `AccessResult` as before the fix, preserving all existing access control behavior.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5**

## Fix Implementation

### Changes Required

The fix is minimal — a single read-only property addition.

**File**: `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/models/tenant.py`

**Class**: `Tenant`

**Specific Changes**:
1. **Add `tenant_id` property (getter)**: Add a `@property` method that returns `self.id`. This makes the Tenant self-referential — a Tenant's `tenant_id` is its own `id`. This is consistent with how `TenantService.create()` already sets `tenant.tenant_id = tenant.id`.

2. **Add `tenant_id` setter (no-op or pass-through)**: Add a setter that either:
   - Is a no-op (ignores the value) since the tenant_id is always derived from `self.id`, OR
   - Accepts the value silently for deserialization compatibility (when loading from DynamoDB, the stored `tenant_id` field will be set via the setter)
   
   The setter is needed because DynamoDB deserialization calls `setattr(model, 'tenant_id', value)` when loading data, and without a setter, it would raise an `AttributeError` due to `BaseModel`'s strict property enforcement.

3. **No changes to AccessChecker**: The `getattr(model, 'tenant_id', None)` call will now correctly return the tenant's `id` for `Tenant` instances, and the existing access chain works as designed.

4. **No changes to TenantService**: The explicit `tenant.tenant_id = tenant.id` assignments in `create()` and `create_with_user()` will hit the new setter (no-op), which is harmless and maintains backward compatibility.

5. **No changes to BaseModel or BaseTenantModel**: The fix is scoped entirely to the `Tenant` model class.

## Testing Strategy

### Validation Approach

The testing strategy follows a two-phase approach: first, surface counterexamples that demonstrate the bug on unfixed code, then verify the fix works correctly and preserves existing behavior.

### Exploratory Bug Condition Checking

**Goal**: Surface counterexamples that demonstrate the bug BEFORE implementing the fix. Confirm that `getattr(Tenant(), 'tenant_id', None)` returns `None` and that `AccessChecker` denies access to tenant admins for their own tenant.

**Test Plan**: Create a `Tenant` instance with a known `id`, then verify that `getattr(tenant, 'tenant_id', None)` returns `None`. Then construct an `AccessChecker` with a tenant admin `RequestContext` and call `check_model_access()` on the Tenant — expect access denied.

**Test Cases**:
1. **Missing tenant_id attribute**: Create `Tenant()`, set `id = "t-001"`, assert `getattr(tenant, 'tenant_id', None) is None` (will pass on unfixed code, confirming the bug)
2. **Tenant admin denied own tenant**: Create `AccessChecker` with tenant admin context (`tenant_id = "t-001"`), call `check_model_access(tenant)` where `tenant.id = "t-001"` — expect `AccessResult.granted == False` (will fail on unfixed code, demonstrating the bug)
3. **Regular user denied own tenant**: Same as above but without `tenant_admin` role — expect denied (will fail on unfixed code)

**Expected Counterexamples**:
- `getattr(Tenant(), 'tenant_id', None)` returns `None` instead of the tenant's `id`
- `AccessChecker.check_model_access()` returns `AccessResult(granted=False, reason="no_access")` for tenant admins accessing their own tenant

### Fix Checking

**Goal**: Verify that for all inputs where the bug condition holds, the fixed function produces the expected behavior.

**Pseudocode:**
```
FOR ALL tenant WHERE tenant IS instance of Tenant AND tenant.id IS NOT None DO
  ASSERT tenant.tenant_id == tenant.id

  FOR ALL request_context WHERE request_context.is_tenant_admin()
        AND request_context.authenticated_tenant_id == tenant.id DO
    checker := AccessChecker(request_context)
    result := checker.check_model_access(tenant)
    ASSERT result.granted == True
    ASSERT result.reason == "tenant_admin"
  END FOR
END FOR
```

### Preservation Checking

**Goal**: Verify that for all inputs where the bug condition does NOT hold, the fixed function produces the same result as the original function.

**Pseudocode:**
```
FOR ALL model WHERE model IS NOT instance of Tenant DO
  ASSERT check_model_access_fixed(model) == check_model_access_original(model)
END FOR

FOR ALL tenant, request_context WHERE request_context.is_platform_admin() DO
  ASSERT check_model_access_fixed(tenant) == check_model_access_original(tenant)
END FOR

FOR ALL tenant, request_context WHERE request_context.authenticated_tenant_id != tenant.id DO
  ASSERT check_model_access_fixed(tenant).granted == False
END FOR
```

**Testing Approach**: Property-based testing is recommended for preservation checking because:
- It generates many combinations of model types, roles, and tenant IDs automatically
- It catches edge cases like `None` tenant IDs, empty strings, or mismatched IDs
- It provides strong guarantees that the fix doesn't alter behavior for non-Tenant models

**Test Plan**: Observe behavior on UNFIXED code first for platform admin access, system context access, and cross-tenant denial, then write property-based tests capturing that behavior.

**Test Cases**:
1. **Platform admin preservation**: Verify platform admins can still access any tenant (granted before and after fix)
2. **System context preservation**: Verify system context still bypasses all checks (granted before and after fix)
3. **Cross-tenant denial preservation**: Verify tenant admin from tenant A cannot access tenant B (denied before and after fix)
4. **Other model preservation**: Verify User, Subscription, and other models with existing `tenant_id` attributes produce identical `AccessResult` before and after fix

### Unit Tests

- Test `Tenant.tenant_id` property returns `self.id` when `id` is set
- Test `Tenant.tenant_id` property returns `None` when `id` is `None`
- Test `Tenant.tenant_id` setter is a no-op (setting a value doesn't change the derived property)
- Test `AccessChecker.check_model_access()` grants `tenant_admin` access for same-tenant Tenant retrieval
- Test `AccessChecker.check_model_access()` denies cross-tenant Tenant retrieval for tenant admins

### Property-Based Tests

- Generate random tenant IDs and verify `Tenant.tenant_id` always equals `Tenant.id`
- Generate random combinations of (role, authenticated_tenant_id, tenant.id) and verify `AccessChecker` produces correct results
- Generate random non-Tenant models with various `tenant_id` values and verify `AccessChecker` behavior is unchanged

### Integration Tests

- Test full `TenantService.get_by_id()` flow with tenant admin context — should return tenant successfully
- Test full `TenantService.get_by_id()` flow with cross-tenant admin context — should return not found
- Test full `TenantService.get_by_id()` flow with platform admin context — should return tenant successfully
