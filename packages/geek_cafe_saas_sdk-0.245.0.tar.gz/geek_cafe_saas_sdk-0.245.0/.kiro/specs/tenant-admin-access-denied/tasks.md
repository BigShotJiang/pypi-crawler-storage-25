# Implementation Plan

- [x] 1. Write bug condition exploration test
  - **Property 1: Bug Condition** - Tenant model missing tenant_id causes access denial
  - **CRITICAL**: This test MUST FAIL on unfixed code - failure confirms the bug exists
  - **DO NOT attempt to fix the test or the code when it fails**
  - **NOTE**: This test encodes the expected behavior - it will validate the fix when it passes after implementation
  - **GOAL**: Surface counterexamples that demonstrate the bug exists
  - **Scoped PBT Approach**: Scope the property to Tenant model instances where `id` is set, verifying that `getattr(tenant, 'tenant_id', None)` returns `self.id` (not `None`), and that `AccessChecker.check_model_access()` grants `tenant_admin` access for same-tenant retrieval
  - Create test file `tests/test_tenant_admin_access_bug_condition.py`
  - Test 1: Create a `Tenant()` instance, set `id = "t-001"`, assert `tenant.tenant_id == "t-001"` (will FAIL on unfixed code because `Tenant` has no `tenant_id` property)
  - Test 2 (property-based): For any generated tenant ID string, create a `Tenant` with that ID and a tenant admin `RequestContext` with matching `authenticated_tenant_id`, call `AccessChecker.check_model_access(tenant)` — assert `result.granted == True` and `result.reason == "tenant_admin"` (will FAIL on unfixed code)
  - Test 3: Create `AccessChecker` with tenant admin context (`tenant_id = "t-001"`), call `check_model_access(tenant)` where `tenant.id = "t-001"` — expect `AccessResult.granted == True` (will FAIL on unfixed code, demonstrating the bug)
  - Use `hypothesis` with `st.text(min_size=1, max_size=50, alphabet=st.characters(whitelist_categories=('L', 'N', 'P')))` for tenant ID generation
  - Use `AnonymousContextFactory.create_test_context()` for creating request contexts (as seen in existing tests)
  - Run test on UNFIXED code
  - **EXPECTED OUTCOME**: Tests FAIL (this is correct - it proves the bug exists)
  - Document counterexamples found: `getattr(Tenant(), 'tenant_id', None)` returns `None`; `AccessChecker.check_model_access()` returns `AccessResult(granted=False, reason="no_access")` for tenant admins
  - Mark task complete when test is written, run, and failure is documented
  - _Requirements: 1.1, 1.2, 1.3, 2.1, 2.2_

- [x] 2. Write preservation property tests (BEFORE implementing fix)
  - **Property 2: Preservation** - Non-Tenant access and privileged Tenant access unchanged
  - **IMPORTANT**: Follow observation-first methodology
  - Create test file `tests/test_tenant_admin_access_preservation.py`
  - Observe on UNFIXED code:
    - Platform admin accessing any Tenant → granted as `platform_admin` (step 2 in check_model_access, before tenant_id is read)
    - System context accessing any Tenant → granted as `system` (step 1 in check_model_access, before tenant_id is read)
    - Tenant admin from tenant A accessing tenant B → denied (cross-tenant, `resource_tenant_id` is `None` which != `user_tenant_id`)
    - Regular user accessing a mock model with existing `tenant_id` (e.g., a simple mock with `tenant_id = "t-001"`, `owner_id = "user-001"`) → granted as owner when user matches `owner_id`
  - Write property-based tests capturing observed behavior:
    - Property: For any tenant ID, platform admin `check_model_access(tenant)` returns `granted=True, reason="platform_admin"`
    - Property: For any tenant ID, system context `check_model_access(tenant)` returns `granted=True, reason="system"`
    - Property: For any pair of distinct tenant IDs (tenant_a != tenant_b), tenant admin from tenant_a calling `check_model_access(tenant_b_model)` returns `granted=False`
    - Property: For any model with `tenant_id` and `owner_id` matching the authenticated user, `check_model_access()` returns `granted=True`
  - Use `hypothesis` strategies for generating random tenant IDs and user IDs
  - Verify all tests PASS on UNFIXED code (these behaviors are not affected by the bug)
  - **EXPECTED OUTCOME**: Tests PASS (this confirms baseline behavior to preserve)
  - Mark task complete when tests are written, run, and passing on unfixed code
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [x] 3. Fix for Tenant model missing tenant_id property

  - [x] 3.1 Implement the fix
    - Add `tenant_id` property (getter) to `Tenant` class in `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/models/tenant.py`
    - The getter returns `self.id` (self-referential: a Tenant's tenant_id IS its own id)
    - Add `tenant_id` setter as a no-op (`pass`) for deserialization compatibility — DynamoDB `load_from_dictionary()` calls `setattr(model, 'tenant_id', value)` and `BaseModel.__setattr__` requires a property setter to exist
    - No changes to `AccessChecker`, `DatabaseService`, `TenantService`, `BaseModel`, or `BaseTenantModel`
    - _Bug_Condition: isBugCondition(model, request_context) where model IS Tenant AND getattr(model, 'tenant_id', None) IS None_
    - _Expected_Behavior: Tenant.tenant_id returns self.id, enabling AccessChecker to correctly resolve resource_tenant_id and grant tenant_admin access_
    - _Preservation: Platform admin, system context, cross-tenant denial, and all non-Tenant models remain unchanged_
    - _Requirements: 2.1, 2.2, 2.3, 3.1, 3.2, 3.3, 3.4, 3.5_

  - [x] 3.2 Verify bug condition exploration test now passes
    - **Property 1: Expected Behavior** - Tenant model returns self.id as tenant_id
    - **IMPORTANT**: Re-run the SAME test from task 1 - do NOT write a new test
    - The test from task 1 encodes the expected behavior: `tenant.tenant_id == tenant.id` and `AccessChecker` grants `tenant_admin` for same-tenant Tenant retrieval
    - Run `tests/test_tenant_admin_access_bug_condition.py`
    - **EXPECTED OUTCOME**: Test PASSES (confirms bug is fixed)
    - _Requirements: 2.1, 2.2, 2.3_

  - [x] 3.3 Verify preservation tests still pass
    - **Property 2: Preservation** - Non-Tenant access and privileged Tenant access unchanged
    - **IMPORTANT**: Re-run the SAME tests from task 2 - do NOT write new tests
    - Run `tests/test_tenant_admin_access_preservation.py`
    - **EXPECTED OUTCOME**: Tests PASS (confirms no regressions)
    - Confirm all tests still pass after fix (no regressions)

- [x] 4. Checkpoint - Ensure all tests pass
  - Run full test suite: `python -m pytest tests/test_tenant_admin_access_bug_condition.py tests/test_tenant_admin_access_preservation.py tests/test_access_checker.py -v`
  - Ensure all tests pass, ask the user if questions arise.
