# Bugfix Requirements Document

## Introduction

Tenant admins are denied access when calling `GET /v3/tenants/{tenant-id}` to retrieve their own tenant, even though their JWT `custom:tenant_id` matches the requested tenant ID and they have the `tenant_admin` role. The root cause is that the `Tenant` model lacks a `tenant_id` property, so `AccessChecker.check_model_access()` extracts `None` via `getattr(model, 'tenant_id', None)` and the tenant admin check (`resource_tenant_id == user_tenant_id`) always fails for Tenant resources.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN a tenant admin calls `GET /v3/tenants/{tenant-id}` where `{tenant-id}` matches their own `custom:tenant_id` THEN the system returns "Access denied" masked as a 404 (Not Found) with denial reason `no_access`

1.2 WHEN `AccessChecker.check_model_access()` runs against a `Tenant` model instance THEN the system extracts `resource_tenant_id` as `None` (because `getattr(tenant, 'tenant_id', None)` returns `None`) and the tenant admin comparison `None == user_tenant_id` evaluates to `False`

1.3 WHEN any non-platform-admin, non-system-context user retrieves a `Tenant` model via `_get_by_id()` THEN the system cannot match the resource to any tenant because `Tenant` has no `tenant_id`, causing all subsequent tenant-scoped access checks (tenant admin, same-tenant field checks, tenant-wide access) to fail

### Expected Behavior (Correct)

2.1 WHEN a tenant admin calls `GET /v3/tenants/{tenant-id}` where `{tenant-id}` matches their own `custom:tenant_id` THEN the system SHALL return the tenant record successfully with access granted as `tenant_admin`

2.2 WHEN `AccessChecker.check_model_access()` runs against a `Tenant` model instance THEN the system SHALL extract `resource_tenant_id` as the tenant's own `id` (via a `tenant_id` property that returns `self.id`) so that the tenant admin comparison correctly evaluates `tenant.id == user_tenant_id`

2.3 WHEN any authenticated user within the same tenant retrieves a `Tenant` model via `_get_by_id()` THEN the system SHALL correctly identify the resource as belonging to that tenant, enabling all tenant-scoped access checks (tenant admin, same-tenant field checks, tenant-wide access) to function properly

### Unchanged Behavior (Regression Prevention)

3.1 WHEN a platform admin calls `GET /v3/tenants/{tenant-id}` for any tenant THEN the system SHALL CONTINUE TO grant access as `platform_admin`

3.2 WHEN a system context (internal operation) retrieves a Tenant THEN the system SHALL CONTINUE TO grant access as `system`

3.3 WHEN a tenant admin calls `GET /v3/tenants/{tenant-id}` where `{tenant-id}` does NOT match their own `custom:tenant_id` THEN the system SHALL CONTINUE TO deny access (cross-tenant access prevention)

3.4 WHEN a regular tenant user (non-admin) calls `GET /v3/tenants/{tenant-id}` THEN the system SHALL CONTINUE TO apply the standard access chain (field matching, self-access, shares, tenant-wide access) using the now-correct `tenant_id` value

3.5 WHEN other models that already have their own `tenant_id` property (e.g., `UsageRecord`, `Role`, `TenantSharingSettings`) go through `AccessChecker.check_model_access()` THEN the system SHALL CONTINUE TO resolve `resource_tenant_id` from their existing `tenant_id` properties without any change in behavior
