# Design Document: Handler Auth Diagnostics

## Overview

This feature enhances the authentication diagnostic pipeline in the `geek-cafe-saas-sdk` Lambda handler framework. The current `BaseLambdaHandler.execute()` fallback auth check and `SecureLambdaHandler._validate_security()` produce a single generic 401 response for all auth failures, making it difficult to distinguish deployment misconfigurations (no authorizer attached) from genuine authentication failures (missing/expired claims).

The design introduces three capabilities:
1. A pre-auth INFO log entry emitted at the top of `execute()` so every invocation leaves a trace in CloudWatch.
2. A two-branch auth failure classification that distinguishes "no authorizer configured" (`AUTHORIZER_NOT_CONFIGURED`) from "authorizer present but claims missing" (`AUTHENTICATION_REQUIRED`).
3. Structured WARNING logs for both failure branches, using fields queryable in CloudWatch Logs Insights.

All changes are confined to `BaseLambdaHandler.execute()` and `SecureLambdaHandler._validate_security()`. The `error_response()` signature and response shape are unchanged. Backward compatibility is preserved via existing `require_auth`, `require_authorizer_claims`, and `require_request_context` flags.

## Architecture

The feature modifies the early execution path of the handler pipeline. No new classes or modules are introduced.

```mermaid
flowchart TD
    A[execute&#40;event, context, ...&#41;] --> B[Emit pre-auth INFO log]
    B --> C{services_container?}
    C -- Yes --> D[container.load_security&#40;&#41;]
    C -- No --> E{require_auth?}
    E -- No --> F[Continue to body parsing]
    E -- Yes --> G{authorizer present?}
    G -- No/Empty --> H[WARNING log: AUTHORIZER_NOT_CONFIGURED]
    H --> I[Return 401 AUTHORIZER_NOT_CONFIGURED]
    G -- Yes --> J{claims.custom:user_id?}
    J -- Missing --> K[WARNING log: AUTHENTICATION_REQUIRED + missing_claims]
    K --> L[Return 401 AUTHENTICATION_REQUIRED]
    J -- Present --> F
```

The same two-branch logic is mirrored in `SecureLambdaHandler._validate_security()`, which currently only logs a warning but does not return an error. The updated `_validate_security()` will return an `error_response` for the missing-authorizer case and a separate one for missing claims, gated by `require_authorizer_claims`.

### Execution Order in `execute()`

1. Optional event logging (existing, unchanged)
2. Optional message unwrapping (existing, unchanged)
3. `requestContext` presence check (existing, unchanged)
4. **NEW: Pre-auth INFO log** — emits HTTP method, resource path, request ID
5. Container-based security loading (existing, unchanged)
6. **MODIFIED: Fallback auth check** — split into authorizer-missing vs claims-missing branches
7. Body parsing and business logic (existing, unchanged)

### Execution Order in `_validate_security()`

1. Check `require_authorizer_claims` flag — if False, return None (existing)
2. **MODIFIED:** If authorizer is absent/empty → WARNING log + return `error_response` with `AUTHORIZER_NOT_CONFIGURED`
3. **NEW:** If authorizer present but `custom:user_id` missing → WARNING log + return `error_response` with `AUTHENTICATION_REQUIRED`
4. If all checks pass → return None (existing)

## Components and Interfaces

### Modified: `BaseLambdaHandler.execute()`

Location: `src/geek_cafe_saas_sdk/lambda_handlers/_base/base_handler.py`

Changes:
- Insert a pre-auth INFO log after the `requestContext` validation and before the container security load.
- Replace the single `if not authorizer or not authorizer.get("claims", {}).get("custom:user_id")` block with two distinct checks.

The pre-auth log extracts metadata safely:
```python
http_method = event.get("httpMethod", "UNKNOWN")
resource_path = event.get("resource", "UNKNOWN")
request_id = event.get("requestContext", {}).get("requestId", "UNKNOWN")
```

### Modified: `SecureLambdaHandler._validate_security()`

Location: `src/geek_cafe_saas_sdk/lambda_handlers/_base/secure_handler.py`

Changes:
- When `require_authorizer_claims` is True and authorizer is absent/empty, return an `error_response` instead of just logging a warning.
- Add a new check: when authorizer exists but `custom:user_id` is missing from claims, return an `error_response` with `AUTHENTICATION_REQUIRED`.
- Emit structured WARNING logs for both cases.

### Unchanged: `error_response()`

Location: `src/geek_cafe_saas_sdk/utilities/response.py`

The existing `error_response(error, error_code, status_code)` signature is used as-is. No changes to the response structure.

### Unchanged: `AuthorizedSecureLambdaHandler`

This handler calls `super().execute()` which routes through `BaseLambdaHandler.execute()`. It inherits the improved diagnostics automatically.

### Integration Point: `SecureLambdaHandler._validate_security()` and `BaseLambdaHandler.execute()`

Currently `_validate_security()` is called nowhere in the execution flow — the `SecureLambdaHandler` does not override `execute()` and the base `execute()` does not call `_validate_security()`. The `AuthorizedSecureLambdaHandler` overrides `execute()` to call `_check_authorization()` but not `_validate_security()`.

**Design decision:** Rather than adding a call to `_validate_security()` in the base `execute()` (which would change the execution flow for all handler types), we will:
1. Update `_validate_security()` to return proper error responses (for use by subclasses or future callers).
2. Apply the same two-branch logic directly in the `execute()` fallback auth check.

This keeps the change minimal and avoids altering the call chain for handlers that use `services_container`.

## Data Models

No new data models are introduced. The feature operates on the existing Lambda event dictionary structure:

### Lambda Event Auth Fields (read-only)

```python
{
    "httpMethod": str,           # "GET", "POST", etc.
    "resource": str,             # "/tenants/{tenant-id}/users"
    "requestContext": {
        "requestId": str,        # API Gateway request ID
        "authorizer": {          # Populated by Cognito/Lambda authorizer
            "claims": {
                "custom:user_id": str,
                "custom:tenant_id": str,
                # ... other JWT claims
            }
        }
    }
}
```

### Structured Log Entry Fields

The WARNING log entries use `aws_lambda_powertools.Logger` extra fields:

| Field | Type | Description |
|-------|------|-------------|
| `auth_failure_reason` | str | `"authorizer_not_configured"` or `"missing_claims"` |
| `http_method` | str | HTTP method from event, or `"UNKNOWN"` |
| `resource_path` | str | Resource path from event, or `"UNKNOWN"` |
| `request_id` | str | API Gateway request ID, or `"UNKNOWN"` |
| `missing_claims` | list[str] | Only present when reason is `"missing_claims"`. List of claim field names not found. |

### Error Response Codes

| Error Code | HTTP Status | When |
|------------|-------------|------|
| `AUTHORIZER_NOT_CONFIGURED` | 401 | `requestContext.authorizer` is absent or empty |
| `AUTHENTICATION_REQUIRED` | 401 | Authorizer present but `custom:user_id` claim missing |


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Pre-auth log contains correct request metadata

*For any* Lambda event (with or without `httpMethod`, `resource`, or `requestContext.requestId`), when `execute()` is called, the handler SHALL emit an INFO-level log entry before any auth check that contains the event's `httpMethod` (or `"UNKNOWN"` if absent), `resource` (or `"UNKNOWN"` if absent), and `requestContext.requestId` (or `"UNKNOWN"` if absent).

**Validates: Requirements 1.1, 1.2**

### Property 2: Missing authorizer produces AUTHORIZER_NOT_CONFIGURED response and structured WARNING log

*For any* Lambda event where `requestContext.authorizer` is absent or an empty dict, when the handler has `require_auth=True` (fallback path) or `require_authorizer_claims=True` (secure handler path), the handler SHALL return a 401 response with error code `"AUTHORIZER_NOT_CONFIGURED"` and SHALL emit a WARNING log containing `auth_failure_reason="authorizer_not_configured"`, `http_method`, `resource_path`, and `request_id`.

**Validates: Requirements 2.1, 2.2, 2.3, 6.2**

### Property 3: Missing claims produces AUTHENTICATION_REQUIRED response and structured WARNING log

*For any* Lambda event where `requestContext.authorizer` exists and is non-empty but `claims.custom:user_id` is missing, when the handler has `require_auth=True` or `require_authorizer_claims=True`, the handler SHALL return a 401 response with error code `"AUTHENTICATION_REQUIRED"` and SHALL emit a WARNING log containing `auth_failure_reason="missing_claims"`, `http_method`, `resource_path`, `request_id`, and a `missing_claims` list that includes `"custom:user_id"`.

**Validates: Requirements 3.1, 3.2, 6.2, 6.3**

### Property 4: No sensitive data in error responses

*For any* Lambda event containing authorization headers, JWT token values, claim values, or request body content, when the handler returns a 401 error response, the response body SHALL NOT contain any of those sensitive values, nor internal file paths, stack traces, Lambda function names, or AWS account identifiers.

**Validates: Requirements 3.3, 4.1, 4.2**

### Property 5: No sensitive data in diagnostic log entries

*For any* Lambda event containing authorization headers, JWT token values, or claim values, when the handler emits pre-auth INFO or auth-failure WARNING log entries, those log entries SHALL NOT contain authorization header contents, token values, or claim values. The WARNING log metadata SHALL be limited to: `auth_failure_reason`, `http_method`, `resource_path`, `request_id`, and `missing_claims` (claim names only, not values).

**Validates: Requirements 1.3, 4.3**

### Property 6: Valid auth passes through to business logic

*For any* Lambda event with a properly populated `requestContext.authorizer.claims` containing `custom:user_id`, when the handler has `require_auth=True`, the handler SHALL invoke the business logic callable and return its result without any auth-related error response.

**Validates: Requirements 5.1**

### Property 7: require_authorizer_claims=False bypasses security validation

*For any* Lambda event (regardless of authorizer or claims state), when `SecureLambdaHandler` has `require_authorizer_claims=False`, `_validate_security()` SHALL return `None` and no auth-failure WARNING log SHALL be emitted.

**Validates: Requirements 5.3**

### Property 8: require_auth=False bypasses fallback auth check

*For any* Lambda event (regardless of authorizer or claims state), when `BaseLambdaHandler` has `require_auth=False` and no `services_container`, the handler SHALL skip the fallback auth check and proceed to business logic execution.

**Validates: Requirements 5.4**

### Property 9: Both code paths produce equivalent auth failure responses

*For any* Lambda event without a valid authorizer, the `SecureLambdaHandler._validate_security()` method and the `BaseLambdaHandler.execute()` fallback auth check SHALL produce responses with the same HTTP status code and error code.

**Validates: Requirements 2.4**

## Error Handling

### Auth Failure Error Responses

| Scenario | Status | Error Code | Message |
|----------|--------|------------|---------|
| No authorizer attached | 401 | `AUTHORIZER_NOT_CONFIGURED` | "Authorization not configured. No authorizer is attached to this endpoint. This is a deployment configuration issue." |
| Authorizer present, claims missing | 401 | `AUTHENTICATION_REQUIRED` | "Authentication required but not provided" |

Both responses use the existing `error_response()` function, which produces a JSON body with `error`, `errorCode`, `timestamp`, `statusCode`, and `success` fields (camelCase converted).

### Fallback Behavior

- If `event.get("httpMethod")` raises an unexpected error, the outer `except Exception` in `execute()` catches it and returns a 500 `INTERNAL_ERROR` response. The pre-auth log uses `.get()` with defaults, so this should not occur.
- If `require_request_context=False` (e.g., SQS/S3 triggers), the handler skips the `requestContext` validation. The pre-auth log still runs but will log `"UNKNOWN"` for all fields since there's no `requestContext`. The fallback auth check is typically also disabled (`require_auth=False`) for these triggers.

### No New Exception Types

No new exception classes are introduced. All error paths use the existing `error_response()` utility.

## Testing Strategy

### Property-Based Tests (Hypothesis)

The project does not currently use Hypothesis. It should be added as a dev dependency (`hypothesis>=6.0`).

Each correctness property maps to a single property-based test with a minimum of 100 iterations. Tests use Hypothesis strategies to generate random Lambda events with varying:
- HTTP methods (GET, POST, PUT, DELETE, PATCH, OPTIONS, and random strings)
- Resource paths (random strings including special characters)
- Request IDs (random UUIDs and strings)
- Authorizer states (absent, empty dict, present with varying claims)
- Claim values (random strings for `custom:user_id`, `custom:tenant_id`, etc.)
- Sensitive data in headers, body, and tokens

The handler's `Logger` is mocked to capture log calls for assertion. Business logic is a simple mock callable.

Property test tag format: `Feature: handler-auth-diagnostics, Property {N}: {title}`

### Unit Tests (Example-Based)

Unit tests complement property tests for specific scenarios:
- Exact message text verification for `AUTHORIZER_NOT_CONFIGURED` response
- Exact message text verification for `AUTHENTICATION_REQUIRED` response
- `error_response()` signature compatibility (smoke test for Requirement 5.2)
- Structured log format verification with Powertools Logger (Requirement 6.1)
- `AuthorizedSecureLambdaHandler` inherits diagnostics via `super().execute()` call chain

### Test File Location

- Property tests: `geek-cafe-saas-sdk/tests/test_handler_auth_diagnostics_properties.py`
- Unit tests: `geek-cafe-saas-sdk/tests/test_handler_auth_diagnostics.py`

### Test Dependencies

- `hypothesis>=6.0` — property-based testing library
- `unittest.mock` — for mocking Logger and business logic callables
- `pytest` — test runner (already in use)
