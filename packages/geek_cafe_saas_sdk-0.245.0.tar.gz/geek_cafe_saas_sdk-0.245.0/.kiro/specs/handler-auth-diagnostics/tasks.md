# Implementation Plan: Handler Auth Diagnostics

## Overview

Enhance the authentication diagnostic pipeline in `BaseLambdaHandler.execute()` and `SecureLambdaHandler._validate_security()` with pre-auth logging, two-branch auth failure classification, and structured WARNING logs. All changes are confined to two files plus tests. The `error_response()` signature and response shape remain unchanged.

## Tasks

- [x] 1. Add pre-auth INFO log to `BaseLambdaHandler.execute()`
  - [x] 1.1 Insert pre-auth INFO log entry in `execute()` after the `requestContext` presence check and before the `services_container` security load
    - Extract `http_method`, `resource_path`, and `request_id` from the event using `.get()` with `"UNKNOWN"` fallbacks
    - Emit an INFO-level log via `logger.info()` with the extracted metadata
    - Ensure no authorization headers, token values, or request body content appear in the log entry
    - File: `src/geek_cafe_saas_sdk/lambda_handlers/_base/base_handler.py`
    - _Requirements: 1.1, 1.2, 1.3_

  - [ ]* 1.2 Write property test for pre-auth log metadata (Property 1)
    - **Property 1: Pre-auth log contains correct request metadata**
    - Use Hypothesis to generate Lambda events with varying `httpMethod`, `resource`, and `requestContext.requestId` (including absent fields)
    - Mock `logger.info` and assert the log entry contains the correct values or `"UNKNOWN"` fallbacks
    - Assert no sensitive data (auth headers, tokens, body) appears in the log
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 1.1, 1.2**

- [x] 2. Split fallback auth check in `execute()` into two branches
  - [x] 2.1 Replace the single `if not authorizer or not authorizer.get("claims", {}).get("custom:user_id")` block with two distinct checks
    - Branch 1: If `requestContext.authorizer` is absent or empty dict → return `error_response("Authorization not configured. No authorizer is attached to this endpoint. This is a deployment configuration issue.", "AUTHORIZER_NOT_CONFIGURED", 401)` and emit a structured WARNING log with `auth_failure_reason="authorizer_not_configured"`, `http_method`, `resource_path`, `request_id`
    - Branch 2: If authorizer exists but `claims.custom:user_id` is missing → return `error_response("Authentication required but not provided", "AUTHENTICATION_REQUIRED", 401)` and emit a structured WARNING log with `auth_failure_reason="missing_claims"`, `http_method`, `resource_path`, `request_id`, `missing_claims=["custom:user_id"]`
    - Use `logger.warning()` with Powertools `extra` fields for structured log entries
    - File: `src/geek_cafe_saas_sdk/lambda_handlers/_base/base_handler.py`
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 3.1, 3.2, 6.1, 6.2, 6.3_

  - [ ]* 2.2 Write property test for missing authorizer detection (Property 2)
    - **Property 2: Missing authorizer produces AUTHORIZER_NOT_CONFIGURED response and structured WARNING log**
    - Use Hypothesis to generate events where `requestContext.authorizer` is absent or empty
    - Assert 401 status, `AUTHORIZER_NOT_CONFIGURED` error code, and WARNING log with correct structured fields
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 2.1, 2.2, 2.3, 6.2**

  - [ ]* 2.3 Write property test for missing claims detection (Property 3)
    - **Property 3: Missing claims produces AUTHENTICATION_REQUIRED response and structured WARNING log**
    - Use Hypothesis to generate events where authorizer exists but `custom:user_id` is missing from claims
    - Assert 401 status, `AUTHENTICATION_REQUIRED` error code, and WARNING log with `missing_claims` field
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 3.1, 3.2, 6.2, 6.3**

- [x] 3. Update `SecureLambdaHandler._validate_security()` with two-branch logic
  - [x] 3.1 Modify `_validate_security()` to return error responses instead of just logging
    - When `require_authorizer_claims=True` and authorizer is absent/empty → return `error_response` with `AUTHORIZER_NOT_CONFIGURED` and emit structured WARNING log
    - When authorizer exists but `custom:user_id` is missing → return `error_response` with `AUTHENTICATION_REQUIRED` and emit structured WARNING log
    - When all checks pass → return `None` (unchanged)
    - Import `error_response` from `geek_cafe_saas_sdk.utilities.response`
    - File: `src/geek_cafe_saas_sdk/lambda_handlers/_base/secure_handler.py`
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 3.1, 3.2, 6.1, 6.2, 6.3_

  - [ ]* 3.2 Write property test for `require_authorizer_claims=False` bypass (Property 7)
    - **Property 7: require_authorizer_claims=False bypasses security validation**
    - Use Hypothesis to generate events with any authorizer/claims state
    - Assert `_validate_security()` returns `None` and no WARNING log is emitted when `require_authorizer_claims=False`
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 5.3**

  - [ ]* 3.3 Write property test for equivalent responses across code paths (Property 9)
    - **Property 9: Both code paths produce equivalent auth failure responses**
    - Use Hypothesis to generate events without valid authorizer
    - Assert `_validate_security()` and the `execute()` fallback produce responses with the same HTTP status code and error code
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 2.4**

- [x] 4. Checkpoint — Verify core implementation
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 5. Add security and backward-compatibility property tests
  - [ ]* 5.1 Write property test for no sensitive data in error responses (Property 4)
    - **Property 4: No sensitive data in error responses**
    - Use Hypothesis to generate events with authorization headers, JWT tokens, claim values, and body content
    - Assert none of those values appear in the 401 response body
    - Assert no file paths, stack traces, Lambda function names, or AWS account IDs in response
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 3.3, 4.1, 4.2**

  - [ ]* 5.2 Write property test for no sensitive data in diagnostic logs (Property 5)
    - **Property 5: No sensitive data in diagnostic log entries**
    - Use Hypothesis to generate events with sensitive data in headers, tokens, and claims
    - Mock logger and assert no sensitive values appear in INFO or WARNING log entries
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 1.3, 4.3**

  - [ ]* 5.3 Write property test for valid auth passthrough (Property 6)
    - **Property 6: Valid auth passes through to business logic**
    - Use Hypothesis to generate events with valid `requestContext.authorizer.claims` containing `custom:user_id`
    - Assert business logic callable is invoked and no auth error response is returned
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 5.1**

  - [ ]* 5.4 Write property test for `require_auth=False` bypass (Property 8)
    - **Property 8: require_auth=False bypasses fallback auth check**
    - Use Hypothesis to generate events with any authorizer/claims state
    - Assert handler skips fallback auth check and proceeds to business logic when `require_auth=False`
    - File: `tests/test_handler_auth_diagnostics_properties.py`
    - **Validates: Requirements 5.4**

- [ ] 6. Write unit tests for specific scenarios
  - [ ]* 6.1 Write unit tests for handler auth diagnostics
    - Test exact message text for `AUTHORIZER_NOT_CONFIGURED` response: `"Authorization not configured. No authorizer is attached to this endpoint. This is a deployment configuration issue."`
    - Test exact message text for `AUTHENTICATION_REQUIRED` response: `"Authentication required but not provided"`
    - Test `error_response()` signature compatibility (smoke test — call with 3 positional args)
    - Test structured log format with Powertools Logger extra fields (`auth_failure_reason`, `http_method`, `resource_path`, `request_id`, `missing_claims`)
    - Test `AuthorizedSecureLambdaHandler` inherits diagnostics via `super().execute()` call chain
    - Test pre-auth log with missing `httpMethod` and `resource` uses `"UNKNOWN"` fallbacks
    - File: `tests/test_handler_auth_diagnostics.py`
    - _Requirements: 2.1, 3.1, 5.1, 5.2, 6.1, 6.2_

- [x] 7. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- `hypothesis` is already listed in `pyproject.toml` under `[project.optional-dependencies] test`
- Property tests validate universal correctness properties from the design document
- Unit tests validate specific example scenarios and exact message text
- The `error_response()` function signature is unchanged — only the caller logic in `execute()` and `_validate_security()` is modified
