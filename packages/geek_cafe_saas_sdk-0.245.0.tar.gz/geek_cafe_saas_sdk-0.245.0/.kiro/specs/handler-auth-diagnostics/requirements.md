# Requirements Document

## Introduction

This feature improves the authentication diagnostic messaging in the Lambda handler SDK (`geek-cafe-saas-sdk`). Currently, when the API Gateway Cognito authorizer is not configured (a deployment/infrastructure issue), the `SecureLambdaHandler` and the `BaseLambdaHandler.execute()` fallback auth check return a generic 401 response ("Authentication required but not provided") with minimal logging. This makes it difficult to distinguish between a deployment misconfiguration (no authorizer attached) and a genuine user authentication failure (bad/expired token with missing claims). The feature adds differentiated error responses, structured diagnostic logging, and a pre-auth request log entry so that every Lambda invocation produces at least one CloudWatch log line.

## Glossary

- **Handler**: An instance of `BaseLambdaHandler` or its subclasses (`SecureLambdaHandler`, `AuthorizedSecureLambdaHandler`) that processes incoming Lambda events.
- **Authorizer_Context**: The `requestContext.authorizer` object in an API Gateway Lambda event, populated by a configured Cognito or Lambda authorizer.
- **Claims**: The `requestContext.authorizer.claims` dictionary containing JWT claim fields such as `custom:user_id` and `custom:tenant_id`.
- **Fallback_Auth_Check**: The authentication validation in `BaseLambdaHandler.execute()` that runs when `require_auth` is True and no `services_container` is provided.
- **Diagnostic_Logger**: The structured logging component within the Handler that emits WARNING-level messages with contextual metadata for authentication failures.
- **Request_Log_Entry**: An INFO-level log message emitted at the start of every Handler invocation containing the HTTP method, route path, and basic request metadata.

## Requirements

### Requirement 1: Pre-Auth Request Logging

**User Story:** As a developer debugging a Lambda in CloudWatch, I want every invocation to produce at least one log entry before the auth check, so that I can confirm the Lambda was invoked and see which route was hit even when authentication fails early.

#### Acceptance Criteria

1. WHEN the Handler receives a Lambda event containing a `requestContext`, THE Handler SHALL log the HTTP method, resource path, and request ID at INFO level before performing any authentication or authorization checks.
2. WHEN the Lambda event does not contain an `httpMethod` or `resource` field, THE Handler SHALL log the available request metadata at INFO level using fallback values of "UNKNOWN" for missing fields.
3. THE Request_Log_Entry SHALL NOT include authorization headers, token values, request bodies, or any other sensitive data.

### Requirement 2: Missing Authorizer Detection

**User Story:** As a DevOps engineer, I want the handler to clearly tell me when no authorizer is configured on the API Gateway endpoint, so that I can immediately identify deployment configuration issues without digging through logs.

#### Acceptance Criteria

1. WHEN the Handler detects that `requestContext.authorizer` is absent or empty in a secure handler context, THE Handler SHALL return a 401 response with the message "Authorization not configured. No authorizer is attached to this endpoint. This is a deployment configuration issue."
2. WHEN the Handler detects that `requestContext.authorizer` is absent or empty, THE Diagnostic_Logger SHALL emit a WARNING-level log entry containing the HTTP method, resource path, and a description stating that no authorizer is configured.
3. WHEN the Handler detects a missing Authorizer_Context, THE Handler SHALL use the error code "AUTHORIZER_NOT_CONFIGURED" in the error response to distinguish this case from other authentication failures.
4. THE Handler SHALL apply the missing-authorizer detection in both the `SecureLambdaHandler._validate_security()` method and the `BaseLambdaHandler.execute()` Fallback_Auth_Check.

### Requirement 3: Missing Claims Detection

**User Story:** As a developer, I want the handler to tell me which specific JWT claims are missing when authentication fails due to an incomplete token, so that I can quickly determine whether the issue is a bad token, an expired token, or a Cognito attribute misconfiguration.

#### Acceptance Criteria

1. WHEN the Authorizer_Context exists but the Claims dictionary is missing the `custom:user_id` field, THE Handler SHALL return a 401 response with the message "Authentication required but not provided" and the error code "AUTHENTICATION_REQUIRED".
2. WHEN the Authorizer_Context exists but required Claims fields are missing, THE Diagnostic_Logger SHALL emit a WARNING-level log entry listing the specific missing claim field names, the HTTP method, and the resource path.
3. THE Handler SHALL NOT include claim values, token contents, or any sensitive authentication data in the 401 response body or in log messages.

### Requirement 4: Secure Diagnostic Messaging

**User Story:** As a security engineer, I want to ensure that diagnostic error messages do not leak internal system details, so that the API remains safe to expose to end users.

#### Acceptance Criteria

1. THE Handler SHALL NOT include internal file paths, stack traces, Lambda function names, or AWS account identifiers in any 401 error response body.
2. THE Handler SHALL NOT include raw JWT token values, authorization header contents, or claim values in any 401 error response body.
3. WHEN the Diagnostic_Logger emits WARNING-level log entries for authentication failures, THE Diagnostic_Logger SHALL limit logged metadata to: HTTP method, resource path, request ID, and the names of missing claims (not their values).

### Requirement 5: Backward Compatibility

**User Story:** As a developer using the SDK in an existing project, I want the improved diagnostics to not break my current handler behavior, so that I can upgrade the SDK without code changes.

#### Acceptance Criteria

1. WHEN the API Gateway authorizer is properly configured and valid Claims are present, THE Handler SHALL process the request identically to the current behavior with no change in response format or status codes.
2. THE Handler SHALL preserve the existing `error_response()` function signature and response structure for all error responses.
3. WHEN `require_authorizer_claims` is set to False on `SecureLambdaHandler`, THE Handler SHALL skip both the missing-authorizer and missing-claims checks, preserving the current permissive behavior.
4. WHEN `require_auth` is set to False on `BaseLambdaHandler`, THE Handler SHALL skip the Fallback_Auth_Check entirely, preserving the current behavior.

### Requirement 6: Structured Log Format

**User Story:** As a DevOps engineer querying CloudWatch Logs Insights, I want diagnostic log entries to use structured key-value fields, so that I can filter and aggregate authentication failures by route, method, and failure reason.

#### Acceptance Criteria

1. THE Diagnostic_Logger SHALL emit all authentication-failure WARNING log entries as structured log messages compatible with AWS Lambda Powertools Logger format.
2. WHEN the Diagnostic_Logger emits an authentication-failure log entry, THE Diagnostic_Logger SHALL include the following fields: `auth_failure_reason`, `http_method`, `resource_path`, and `request_id`.
3. WHEN the failure reason is missing claims, THE Diagnostic_Logger SHALL include a `missing_claims` field containing the list of claim field names that were not found.
