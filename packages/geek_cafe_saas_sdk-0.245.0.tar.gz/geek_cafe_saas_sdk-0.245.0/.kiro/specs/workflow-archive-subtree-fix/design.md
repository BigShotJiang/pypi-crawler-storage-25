# Workflow Archive/Restore Subtree Bugfix Design

## Overview

The `archive()` and `restore()` methods in `WorkflowService` are supposed to operate on the targeted execution and its entire subtree (all descendants). Instead, they call `list_by_root(execution.data.root_id)` which queries GSI1 by `root_id` — but in practice this returns only the targeted item, not the full tree. Even if it did return the full tree, the logic would be wrong: it would archive/restore everything from the root down (siblings, parents, unrelated branches) instead of only the subtree rooted at the targeted item.

The fix replaces the `list_by_root` call with a recursive walk using `list_children(parent_id)` (GSI2), collecting the targeted item plus all its direct and indirect descendants. This is the same parent→children traversal pattern the model's GSI2 index was designed for.

## Glossary

- **Bug_Condition (C)**: The condition that triggers the bug — when `archive()` or `restore()` is called on any execution that has children (descendants), only the targeted item's `lifecycle_state` is effectively updated
- **Property (P)**: The desired behavior — the targeted item AND all its descendants have their `lifecycle_state` updated to `"archived"` or `"active"` respectively
- **Preservation**: Existing behavior that must remain unchanged — leaf-node archive/restore, not-found error handling, return value shape, and non-descendant items remaining untouched
- **WorkflowService**: The service class in `workflow_service.py` that manages workflow execution CRUD and lifecycle operations
- **Workflow**: The DynamoDB model in `execution.py` representing a workflow execution item with hierarchy fields (`root_id`, `parent_id`)
- **list_by_root**: Method querying GSI1 by `root_id` — returns executions sharing the same root (currently used by archive/restore, but broken)
- **list_children**: Method querying GSI2 by `parent_id` — returns direct children of a given execution (working correctly)
- **lifecycle_state**: A string field on Workflow (`"active"`, `"archived"`, `"deleted"`) controlling visibility
- **Subtree**: The targeted execution plus all its direct and indirect descendants in the execution hierarchy

## Bug Details

### Bug Condition

The bug manifests when a user archives or restores any execution item that has children. The `archive()` and `restore()` methods call `self.list_by_root(execution.data.root_id)` to collect related items, but this query returns only the targeted item in practice. The iteration then updates only that single item's `lifecycle_state`, leaving all descendants unchanged.

Additionally, even if `list_by_root` returned the full tree, the semantics would be wrong: archiving a mid-tree node should only affect that node and its descendants, not siblings or ancestors.

**Formal Specification:**
```
FUNCTION isBugCondition(input)
  INPUT: input of type { method: "archive" | "restore", execution_id: str }
  OUTPUT: boolean

  execution := WorkflowService.get(input.execution_id)
  children := WorkflowService.list_children(execution.id)

  RETURN execution EXISTS
         AND children.length > 0
         AND (input.method == "archive" OR input.method == "restore")
END FUNCTION
```

### Examples

- **Mid-tree archive**: User archives `child_A` which has two grandchildren (`gc_1`, `gc_2`). Expected: `child_A`, `gc_1`, `gc_2` all become `"archived"`. Actual: only `child_A` becomes `"archived"`.
- **Root archive**: User archives `root` which has children `child_A`, `child_B` and grandchild `gc_1` under `child_A`. Expected: all four items become `"archived"`. Actual: only `root` becomes `"archived"`.
- **Mid-tree restore**: User restores `child_A` (archived) which has archived grandchildren. Expected: `child_A` and all its descendants become `"active"`. Actual: only `child_A` becomes `"active"`.
- **Leaf archive (no bug)**: User archives `gc_1` which has no children. Expected and actual: only `gc_1` becomes `"archived"` — this case works correctly today.

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- Archiving/restoring a leaf node (no children) must continue to update only that single item
- Archiving the root must continue to result in all items in the tree being archived (now correctly via subtree walk instead of broken `list_by_root`)
- A not-found `execution_id` must continue to return a `ServiceResult` error with `ErrorCode.NOT_FOUND`
- The return value must continue to be `ServiceResult.success_result(execution.data)` containing the originally requested execution
- Non-descendant items (parents, siblings, other branches) must NOT have their `lifecycle_state` changed when archiving/restoring a non-root item

**Scope:**
All inputs that do NOT involve archiving or restoring an execution with children should be completely unaffected by this fix. This includes:
- All other `WorkflowService` methods (`create`, `start`, `complete`, `fail`, `cancel`, `retry`, etc.)
- `cancel_tree` and `fail_tree` (which use `list_by_root` for a different purpose — operating on the full tree by root_id, which is their correct semantic)
- Any read operations (`get`, `list_by_root`, `list_children`, `list_by_status`, etc.)

## Hypothesized Root Cause

Based on the code analysis, the root cause is clear:

1. **Wrong query method**: `archive()` and `restore()` call `self.list_by_root(execution.data.root_id)` which queries GSI1 using the execution's `root_id`. The GSI1 partition key is `tenant#<tenant_id>|owner#<owner_id>` and the sort key is `root#<root_id>|ts#<timestamp>`. In practice, this query returns only the targeted item rather than the full tree — likely because the sort key's `begins_with` condition combined with the specific `root_id` and timestamp narrows results to a single item.

2. **Wrong semantic even if query worked**: Even if `list_by_root` returned all items sharing the same `root_id`, the code would archive/restore the entire tree from root down. The correct semantic for archiving a mid-tree node is to archive only that node's subtree (the node itself plus all descendants), not siblings or ancestors.

3. **Correct approach already exists**: `list_children(parent_id)` queries GSI2 by `parent_id` and correctly returns direct children. A recursive walk using `list_children` starting from the targeted `execution_id` will collect exactly the subtree that should be archived/restored.

## Correctness Properties

Property 1: Bug Condition - Subtree Archive/Restore Completeness

_For any_ execution that has one or more descendants (children, grandchildren, etc.), calling `archive(execution_id)` SHALL set `lifecycle_state = "archived"` on the targeted execution AND every direct and indirect descendant. Similarly, `restore(execution_id)` SHALL set `lifecycle_state = "active"` on the targeted execution AND every descendant.

**Validates: Requirements 2.1, 2.2, 2.3, 2.4**

Property 2: Preservation - Non-Descendant Items Unchanged

_For any_ execution in the tree that is NOT the targeted item and NOT a descendant of the targeted item (i.e., parents, siblings, other branches), calling `archive()` or `restore()` on the targeted item SHALL NOT modify that execution's `lifecycle_state`, preserving all existing non-descendant state.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5**

## Fix Implementation

### Changes Required

**File**: `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/workflows/services/workflow_service.py`

**Functions**: `archive`, `restore`

**Specific Changes**:

1. **Add a private recursive helper `_collect_subtree`**: Create a method that takes an `execution_id`, calls `list_children(execution_id)` to get direct children, then recursively calls itself for each child. Returns a flat list of all descendant Workflow items.

2. **Replace `list_by_root` in `archive()`**: Instead of `self.list_by_root(execution.data.root_id)`, collect the subtree by calling `_collect_subtree(execution_id)`. Then set `lifecycle_state = "archived"` on the targeted execution itself plus all collected descendants.

3. **Replace `list_by_root` in `restore()`**: Same pattern — use `_collect_subtree(execution_id)` instead of `list_by_root`. Set `lifecycle_state = "active"` on the targeted execution plus all descendants.

4. **Keep the targeted execution update explicit**: The targeted execution (already fetched via `self.get()`) should be updated first, then all descendants from the recursive walk. This ensures the return value `ServiceResult.success_result(execution.data)` reflects the updated state.

5. **Preserve error handling**: Keep the existing not-found check at the top of both methods unchanged.

## Testing Strategy

### Validation Approach

The testing strategy follows a two-phase approach: first, surface counterexamples that demonstrate the bug on unfixed code, then verify the fix works correctly and preserves existing behavior. All tests use moto-backed DynamoDB with real table creation (no mocks).

### Exploratory Bug Condition Checking

**Goal**: Surface counterexamples that demonstrate the bug BEFORE implementing the fix. Confirm that `list_by_root` fails to collect the subtree.

**Test Plan**: Create a realistic execution tree hierarchy in a moto-backed DynamoDB table (root → children → grandchildren). Call `archive()` on a mid-tree node and assert that all descendants are archived. Run on UNFIXED code to observe failures.

**Test Cases**:
1. **Mid-tree archive test**: Create tree `root → [child_A, child_B]`, `child_A → [gc_1, gc_2]`. Archive `child_A`. Assert `child_A`, `gc_1`, `gc_2` are all archived. (will fail on unfixed code)
2. **Root archive test**: Archive `root`. Assert all 5 items are archived. (will fail on unfixed code — only root gets archived)
3. **Mid-tree restore test**: Archive entire tree manually, then restore `child_A`. Assert `child_A`, `gc_1`, `gc_2` are active while `root`, `child_B` remain archived. (will fail on unfixed code)

**Expected Counterexamples**:
- Only the targeted item has `lifecycle_state` updated; descendants remain unchanged
- Root cause confirmed: `list_by_root` returns only the targeted item, not the full subtree

### Fix Checking

**Goal**: Verify that for all inputs where the bug condition holds, the fixed function produces the expected behavior.

**Pseudocode:**
```
FOR ALL input WHERE isBugCondition(input) DO
  result := archive_fixed(input.execution_id)  // or restore_fixed
  subtree := collect_subtree(input.execution_id)
  FOR EACH item IN subtree DO
    ASSERT item.lifecycle_state == expected_state
  END FOR
END FOR
```

### Preservation Checking

**Goal**: Verify that for all inputs where the bug condition does NOT hold, the fixed function produces the same result as the original function, and that non-descendant items are never modified.

**Pseudocode:**
```
FOR ALL input WHERE NOT isBugCondition(input) DO
  ASSERT archive_original(input) = archive_fixed(input)
END FOR

FOR ALL input WHERE isBugCondition(input) DO
  non_descendants := all_items - subtree(input.execution_id)
  FOR EACH item IN non_descendants DO
    ASSERT item.lifecycle_state == original_lifecycle_state
  END FOR
END FOR
```

**Testing Approach**: Moto-backed integration tests with real DynamoDB tables. Tests create a full execution tree, perform archive/restore on specific nodes, then query every item in the tree to verify only the correct subtree was affected.

**Test Plan**: Build a 5-node tree (`root → [child_A, child_B]`, `child_A → [gc_1, gc_2]`). For each test, verify the lifecycle_state of every node after the operation.

**Test Cases**:
1. **Leaf archive preservation**: Archive `gc_1` (leaf). Verify only `gc_1` is archived; all other items unchanged.
2. **Sibling preservation**: Archive `child_A`. Verify `child_B` and `root` remain `"active"`.
3. **Not-found preservation**: Call `archive("nonexistent-id")`. Verify error result returned with NOT_FOUND code.
4. **Return value preservation**: Archive `child_A`. Verify the returned `ServiceResult` contains `child_A`'s data.

### Unit Tests

- Test `_collect_subtree` returns correct items for leaf, mid-tree, and root nodes
- Test `archive()` updates all descendants for a mid-tree node
- Test `restore()` updates all descendants for a mid-tree node
- Test not-found error handling is unchanged

### Property-Based Tests

- Generate random tree structures (varying depth and branching factor) and verify archive/restore affects exactly the correct subtree
- Generate random target nodes within a tree and verify non-descendant items are never modified
- Generate random sequences of archive/restore operations and verify consistency

### Integration Tests

- Full moto-backed test with realistic NCA execution tree (root → nca_workflow children → nca_validation grandchildren)
- Test archive mid-tree node, verify subtree archived, siblings/parent untouched
- Test restore mid-tree node, verify subtree restored, other archived items untouched
- Test archive root, verify entire tree archived
- Test restore root, verify entire tree restored
