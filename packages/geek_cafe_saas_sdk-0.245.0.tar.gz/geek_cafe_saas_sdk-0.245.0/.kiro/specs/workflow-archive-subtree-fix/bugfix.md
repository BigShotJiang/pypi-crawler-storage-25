# Bugfix Requirements Document

## Introduction

When a user archives an orchestration workflow item (e.g., an nca_workflow, nca_validation, or any node in the execution tree), the system should archive that item and all its descendants (the subtree rooted at that item). In practice, only the single targeted item gets archived — none of its children are affected. The same bug also affects the `restore()` method, which uses the identical flawed pattern.

## Bug Analysis

### Root Cause

The `archive()` and `restore()` methods in `WorkflowService` call `self.list_by_root(execution.data.root_id)` to find related executions. This queries GSI1 using the execution's `root_id`. However, `list_by_root` returns only executions that share the same `root_id` AND match the authenticated user's `tenant_id`/`owner_id` in the GSI1 partition key. In practice, the query appears to return only the targeted execution itself rather than the full tree — so only the one item gets its `lifecycle_state` updated.

Even if `list_by_root` did return the full tree, the logic is wrong: it archives everything from the root down (siblings, parents, unrelated branches) instead of only the subtree from the targeted item downward.

The correct approach is to:
1. Archive the targeted execution itself
2. Use `list_children(execution_id)` (GSI2, which queries by `parent_id`) to find direct children
3. Recursively archive each child's subtree

### Current Behavior (Defect)

1.1 WHEN a user archives any execution item THEN the system archives only that single item — none of its children or descendants are archived, even though the code iterates over `list_by_root` results

1.2 WHEN a user restores any execution item THEN the system restores only that single item — none of its children or descendants are restored

### Expected Behavior (Correct)

2.1 WHEN a user archives an execution item THEN the system SHALL archive that item and all its direct and indirect descendants (the subtree rooted at that item), leaving the parent, siblings, and other branches unchanged

2.2 WHEN a user archives the root execution item THEN the system SHALL archive the root item and all its descendants (the full tree)

2.3 WHEN a user restores an execution item THEN the system SHALL restore that item and all its direct and indirect descendants (the subtree rooted at that item), leaving other archived items in the tree unchanged

2.4 WHEN a user restores the root execution item THEN the system SHALL restore the root item and all its descendants (the full tree)

### Unchanged Behavior (Regression Prevention)

3.1 WHEN a user archives an execution that has no children (a leaf node) THEN the system SHALL CONTINUE TO archive only that single execution item

3.2 WHEN a user archives the root execution THEN the system SHALL CONTINUE TO result in all items in the tree being archived

3.3 WHEN the archive operation encounters an execution_id that does not exist THEN the system SHALL CONTINUE TO return a not-found error result

3.4 WHEN the archive operation completes THEN the system SHALL CONTINUE TO return a ServiceResult containing the originally requested execution's data

3.5 WHEN a user restores an execution that has no children (a leaf node) THEN the system SHALL CONTINUE TO restore only that single execution item

## Testing Requirements

4.1 All fix verification MUST use moto-backed integration tests with real DynamoDB tables (not mocks) to prove the fix works against actual data

4.2 Tests MUST create a realistic execution tree hierarchy (root → children → grandchildren) and verify archive/restore operations affect only the correct subtree

4.3 Tests MUST verify that sibling executions and parent executions are NOT affected when archiving/restoring a non-root item
