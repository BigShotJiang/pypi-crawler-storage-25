"""."""

import cv2
import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw
from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw
from kinematic_tracker.types import FMT, FT


W_PI4 = 0.9238795325112867
RZ_PI4 = 0.3826834323650898


@pytest.fixture
def driver() -> MetricIouLikeTwoYaw:
    return MetricIouLikeTwoYaw(15, 17, 10, (0, 1, 2, 3, 6, 7, 8, 9))


@pytest.fixture
def ref_driver() -> MetricGIoUYaw:
    return MetricGIoUYaw(15, 17, 10, (0, 1, 2, 3, 6, 7, 8, 9))


@pytest.fixture
def ref_1z() -> FMT:
    return np.array((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0)).reshape(1, 10)


def get_kf(pre_z: FMT) -> cv2.KalmanFilter:
    kf = cv2.KalmanFilter(10, 10, 0, cv2.CV_64F)
    kf.statePre = pre_z.reshape(10, 1)
    kf.measurementMatrix = np.eye(10)
    return kf


@pytest.fixture
def vecs_28z() -> np.ndarray:  # Example vecs_289 in nuScenes format: x,y,z,w,rx,ry,rz,sx,sy,sz
    zz1 = np.array(
        [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 2.0]
    )  # x,y,z,roll,pitch,yaw,length,width,height
    zz2 = np.array(
        [2.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 2.0]
    )  # certain overlap and axis aligned
    zz4 = np.array(
        [2.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 1.0]
    )  # certain overlap and height diff
    zz5 = np.array([6.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 2.0])  # no overlap and axis align
    zz7 = np.array([6.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 1.0])  # no overlap and height diff
    zz8 = np.array(
        [16.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 1.0]
    )  # no overlap and height diff
    zz3 = np.array(
        [2.0, 0.0, 0.0, W_PI4, 0.0, 0.0, RZ_PI4, 4.0, 2.0, 2.0]
    )  # certain overlap and yaw rotation
    zz6 = np.array(
        [6.0, 0.0, 0.0, W_PI4, 0.0, 0.0, RZ_PI4, 4.0, 2.0, 2.0]
    )  # no overlap and yaw rotation

    vectors1 = [zz1, zz2, zz3, zz4, zz5, zz6, zz7, zz8]
    vectors2 = [zz2, zz1, zz4, zz3, zz6, zz5, zz8, zz7]
    return np.array((vectors1, vectors2))


@pytest.fixture
def ref_88() -> FMT:
    # fmt: off
    ref = [
        [0.666666666666667, 1., 0.51666666666667, 0.5055352698662247, 0.2761423749153967, 0.4, 0.15, 0.3],
        [1.0, 0.666666666666667, 0.75, 0.6729276873448939, 0.3521265234510925, 0.5, 0.166666666666667, 0.375],
        [0.6729276873448939, 0.5055352698662247, 0.5113457592395015, 1., 0.3203772410170408, 0.3521265234510924, 0.11123238428420973, 0.26413738349885535],
        [0.75, 0.51666666666667, 1.0, 0.5113457592395015, 0.2641373834988554, 0.375, 0.2222222222222222, 0.5],
        [0.5, 0.4, 0.375, 0.3521265234510924, 0.6729276873448939, 1.0, 0.2142857142857143, 0.75],
        [0.3521265234510925, 0.2761423749153967, 0.2641373834988554, 0.3203772410170408, 1.0, 0.6729276873448939, 0.1447323080007507, 0.5113457592395015],
        [0.375, 0.3, 0.5, 0.26413738349885535, 0.5113457592395015, 0.75, 0.2857142857142857, 1.0],
        [0.16666666666666669, 0.15, 0.2222222222222222, 0.11123238428420973, 0.1447323080007507, 0.2142857142857143, 1.0, 0.2857142857142857]
    ]
    # fmt: on
    return np.array(ref)


@pytest.fixture
def filters() -> FT:
    h_mat_zx = np.eye(10, 16)
    vec_nz = np.linspace(1.0, 30.0, 30).reshape(3, 10)
    vec_nz[:, 4:6] = 0

    filters = []
    for vec_z in vec_nz:
        kf = cv2.KalmanFilter(16, 10, 0, cv2.CV_64F)
        kf.measurementMatrix = h_mat_zx
        kf.statePre = vec_z.dot(h_mat_zx).reshape(16, 1)
        filters.append(kf)

    return filters


@pytest.fixture
def det_rz() -> FMT:
    vec_nz = np.linspace(1.0, 20.0, 20).reshape(2, 10)
    vec_nz[:, 4:6] = 0
    return vec_nz
