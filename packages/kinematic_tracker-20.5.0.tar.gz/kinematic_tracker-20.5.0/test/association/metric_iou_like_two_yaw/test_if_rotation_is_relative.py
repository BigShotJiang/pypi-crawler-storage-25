import numpy as np
import pytest

from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw

from .conftest import get_kf


def test_0_90_vs_90_180(driver: MetricIouLikeTwoYaw) -> None:
    """."""
    ref_1z = np.array((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 1.0)).reshape(1, 10)
    vec90_z = np.array((0.0, 0.0, 0.0, 0.707106781, 0.0, 0.0, 0.707106781, 4.0, 2.0, 1.0))
    kf90 = get_kf(vec90_z)
    metric0_90 = driver.compute_metric(ref_1z, [kf90])[0, 0]

    vec180_z = np.array((0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 4.0, 2.0, 1.0))
    kf180 = get_kf(vec180_z)
    metric90_180 = driver.compute_metric(vec90_z.reshape(1, 10), [kf180])[0, 0]
    assert metric0_90 == pytest.approx(metric90_180)


def test_30_75_vs_30_255(driver: MetricIouLikeTwoYaw) -> None:
    """."""
    vec30_1z = np.array([(0.0, 0.0, 0.0, 0.965925826, 0.0, 0.0, 0.258819045, 4.0, 2.0, 1.0)])
    vec75_1z = np.array([(0.0, 0.0, 0.0, 0.79335334, 0.0, 0.0, 0.608761429, 4.0, 2.0, 1.0)])
    kf75 = get_kf(vec75_1z[0])
    metric30_75 = driver.compute_metric(vec30_1z, [kf75])[0, 0]

    vec255_1z = np.array([(0.0, 0.0, 0.0, 0.608761429, 0.0, 0.0, -0.79335334, 4.0, 2.0, 1.0)])
    kf255 = get_kf(vec255_1z[0])
    metric30_255 = driver.compute_metric(vec30_1z, [kf255])[0, 0]
    assert metric30_75 == pytest.approx(metric30_255)
