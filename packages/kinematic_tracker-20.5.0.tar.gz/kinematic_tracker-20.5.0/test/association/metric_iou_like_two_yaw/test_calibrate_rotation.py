import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw
from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw

from .conftest import get_kf


def test_rotation(driver: MetricIouLikeTwoYaw, ref_driver: MetricGIoUYaw) -> None:
    """."""
    ref_1z = np.array((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 1.0)).reshape(1, 10)
    probe90_z = np.array((0.0, 0.0, 0.0, 0.707106781, 0.0, 0.0, 0.707106781, 4.0, 2.0, 1.0))
    probe180_z = np.array((0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 4.0, 2.0, 1.0))
    kf90 = get_kf(probe90_z)
    kf180 = get_kf(probe180_z)
    ref = ref_driver.compute_metric(ref_1z, [kf90])[0, 0]
    probe90 = driver.compute_metric(ref_1z, [kf90])[0, 0]
    probe180 = driver.compute_metric(ref_1z, [kf180])[0, 0]
    assert probe180 == pytest.approx(1.0)
    assert abs(probe90 - ref) < 0.000085
