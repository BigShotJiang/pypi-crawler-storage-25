import cv2
import numpy as np
import pytest

from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw
from kinematic_tracker.types import FMT


def test_normal(driver: MetricIouLikeTwoYaw, filters: list[cv2.KalmanFilter], det_rz: FMT) -> None:
    metric_rt = driver.compute_metric(det_rz, filters)

    ref = [
        [1.0, 0.42497781661003675, 0.28536712207339293],
        [0.13411748922622344, 0.13850504414275566, 0.14303758062844857],
    ]
    assert metric_rt == pytest.approx(np.array(ref))


# xxx need to benchmark comparing the real GIoU-yaw metric.
