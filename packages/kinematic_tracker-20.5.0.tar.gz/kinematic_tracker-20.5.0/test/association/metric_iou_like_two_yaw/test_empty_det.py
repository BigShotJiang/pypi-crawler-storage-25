"""."""

import numpy as np

from kinematic_tracker.association.metric_giou_yaw import FT
from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw


def test_empty_det(filters: FT, driver: MetricIouLikeTwoYaw) -> None:
    metric = driver.compute_metric(np.empty((0, 10)), filters)
    assert metric.shape == (0, 3)
