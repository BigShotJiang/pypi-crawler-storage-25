"""."""

import pytest

from kinematic_tracker.association.metric_iou_like_two_yaw import MetricIouLikeTwoYaw


def test_init(driver: MetricIouLikeTwoYaw) -> None:
    assert driver.xx_tn.shape == (17, 10)
    assert driver.xx_rn.shape == (15, 10)


def test_num_z_ge_8() -> None:
    with pytest.raises(AssertionError):
        MetricIouLikeTwoYaw(10, 10, 7, (0, 1, 2, 3, 6, -3, -2, -1))


def test_fancy_indices() -> None:
    with pytest.raises(AssertionError):
        MetricIouLikeTwoYaw(10, 10, 8, (0, 2, 3, 6, -3, -2, -1))

    with pytest.raises(AssertionError):
        MetricIouLikeTwoYaw(10, 10, 8, [(0, 1, 2, 3, 6, -3, -2, -1)])
