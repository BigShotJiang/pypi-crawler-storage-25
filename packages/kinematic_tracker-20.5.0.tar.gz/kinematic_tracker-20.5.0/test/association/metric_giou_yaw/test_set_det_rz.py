"""."""

import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw
from kinematic_tracker.types import FMT


def test_set_det_rz(driver: MetricGIoUYaw, det_rz: FMT) -> None:
    driver.set_det_rz(det_rz)
    assert driver.report_buf.num_rect == 2
    ref = [
        [1.0, 2.0, 3.0, 4.0, 0.0, 0.0, 7.0, 8.0, 9.0, 10.0],
        [11.0, 12.0, 13.0, 14.0, 0.0, 0.0, 17.0, 18.0, 19.0, 20.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    ]
    assert driver.xx_rz[:5] == pytest.approx(np.array(ref))
