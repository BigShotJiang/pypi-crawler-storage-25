import cv2
import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw
from kinematic_tracker.types import FMT


def test_normal(driver: MetricGIoUYaw, filters: list[cv2.KalmanFilter], det_rz: FMT) -> None:
    metric_rt = driver.compute_metric(det_rz, filters)
    ref = [
        [1.0, 0.3185216546083782, 0.26513977158265706],
        [0.3185216546083782, 1.0, 0.4392318438129806],
    ]
    assert metric_rt == pytest.approx(np.array(ref))
