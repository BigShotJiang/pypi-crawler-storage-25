import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw

from .conftest import get_kf_cp


REF_VALUE = 0.5625


def test_normal_1x1_and_2x2(driver: MetricGIoUYaw) -> None:
    det1_rz = np.array([(0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0)])
    kf_cp = get_kf_cp((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 2.0, 2.0, 2.0))
    metric_rt = driver.compute_metric(det1_rz, [kf_cp])
    assert metric_rt[0, 0] == pytest.approx(REF_VALUE)
    det2_rz = np.array([(0.0, 0.5, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0)])
    metric_rt = driver.compute_metric(det2_rz, [kf_cp])
    assert metric_rt[0, 0] == pytest.approx(REF_VALUE)


def test_normal_2x2_and_1x1(driver: MetricGIoUYaw) -> None:
    det1_rz = np.array([(0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 2.0, 2.0, 2.0)])
    kf_cp = get_kf_cp((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0))
    metric_rt = driver.compute_metric(det1_rz, [kf_cp])
    assert metric_rt[0, 0] == pytest.approx(REF_VALUE)
    det2_rz = np.array([(0.0, 0.5, 0.0, 1.0, 0.0, 0.0, 1.0, 2.0, 2.0, 2.0)])
    metric_rt = driver.compute_metric(det2_rz, [kf_cp])
    assert metric_rt[0, 0] == pytest.approx(REF_VALUE)
