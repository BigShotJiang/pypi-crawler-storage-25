import cv2
import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw
from kinematic_tracker.types import FMT


def test_it(
    driver: MetricGIoUYaw, filters8: list[cv2.KalmanFilter], vecs_28z: np.ndarray, ref_88: FMT
) -> None:
    metric_rt = driver.compute_metric(vecs_28z[0], filters8)
    assert metric_rt == pytest.approx(ref_88)
