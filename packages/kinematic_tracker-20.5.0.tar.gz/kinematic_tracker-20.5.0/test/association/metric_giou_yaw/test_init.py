"""."""

import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw


def test_init(driver: MetricGIoUYaw) -> None:
    assert driver.xx_rz.shape == (15, 10)
    assert driver.xx_tz.shape == (17, 10)


def test_num_z_ge_8() -> None:
    with pytest.raises(AssertionError):
        MetricGIoUYaw(10, 10, 7, (0, 1, 2, 3, 6, -3, -2, -1))


def test_fancy_indices() -> None:
    with pytest.raises(AssertionError):
        MetricGIoUYaw(10, 10, 8, (0, 2, 3, 6, -3, -2, -1))

    with pytest.raises(AssertionError):
        MetricGIoUYaw(10, 10, 8, [(0, 1, 2, 3, 6, -3, -2, -1)])
