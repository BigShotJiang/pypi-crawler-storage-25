"""."""

import pytest

from kinematic_tracker.association.metric_mahalanobis_size_mod import MetricMahalanobisSizeMod


@pytest.fixture
def driver() -> MetricMahalanobisSizeMod:
    return MetricMahalanobisSizeMod(100, 500, 1.23, 12, 6, (0, 1, 2, -3, -2, -1))
