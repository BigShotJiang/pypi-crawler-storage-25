import math

import numpy as np
import pytest

from kinematic_tracker.types import FMT


@pytest.fixture
def vecs_289() -> np.ndarray:
    zz1 = np.array([0.0, 0, 0, 0, 0, 0, 4, 2, 2])  # x,y,z,roll,pitch,yaw,length,width,height
    zz2 = np.array([2.0, 0, 0, 0, 0, 0, 4, 2, 2])  # certain overlap and axis aligned
    zz3 = np.array([2.0, 0, 0, 0, 0, math.pi / 4, 4, 2, 2])  # certain overlap and yaw rotation
    zz4 = np.array([2.0, 0, 0, 0, 0, 0, 4, 2, 1])  # certain overlap and height diff
    zz5 = np.array([6.0, 0, 0, 0, 0, 0, 4, 2, 2])  # no overlap and axis align
    zz6 = np.array([6.0, 0, 0, 0, 0, math.pi / 4, 4, 2, 2])  # no overlap and yaw rotation
    zz7 = np.array([6.0, 0, 0, 0, 0, 0, 4, 2, 1])  # no overlap and height diff
    zz8 = np.array([16.0, 0, 0, 0, 0, 0, 4, 2, 1])  # no overlap and height diff
    vectors1 = [zz1, zz2, zz3, zz4, zz5, zz6, zz7, zz8]
    vectors2 = [zz2, zz1, zz4, zz3, zz6, zz5, zz8, zz7]
    return np.array((vectors1, vectors2))


@pytest.fixture
def ref_88() -> FMT:
    # fmt: off
    ref = [
        [0.666666666666667, 1., 0.51666666666667, 0.5055352698662247, 0.2761423749153967, 0.4, 0.15, 0.3],
        [1.0, 0.666666666666667, 0.75, 0.6729276873448939, 0.3521265234510925, 0.5, 0.166666666666667, 0.375],
        [0.6729276873448939, 0.5055352698662247, 0.5113457592395015, 1., 0.3203772410170408, 0.3521265234510924, 0.11123238428420973, 0.26413738349885535],
        [0.75, 0.51666666666667, 1.0, 0.5113457592395015, 0.2641373834988554, 0.375, 0.2222222222222222, 0.5],
        [0.5, 0.4, 0.375, 0.3521265234510924, 0.6729276873448939, 1.0, 0.2142857142857143, 0.75],
        [0.3521265234510925, 0.2761423749153967, 0.2641373834988554, 0.3203772410170408, 1.0, 0.6729276873448939, 0.1447323080007507, 0.5113457592395015],
        [0.375, 0.3, 0.5, 0.26413738349885535, 0.5113457592395015, 0.75, 0.2857142857142857, 1.0],
        [0.16666666666666669, 0.15, 0.2222222222222222, 0.11123238428420973, 0.1447323080007507, 0.2142857142857143, 1.0, 0.2857142857142857]
    ]
    # fmt: on
    return np.array(ref)
