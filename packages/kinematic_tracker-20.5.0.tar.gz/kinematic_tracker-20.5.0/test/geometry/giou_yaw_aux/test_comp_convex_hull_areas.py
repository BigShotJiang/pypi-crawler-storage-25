"""."""

import numpy as np
import pytest

from kinematic_tracker.geometry.giou_yaw_aux import GiouYawAux


def test_without_init(aux: GiouYawAux) -> None:
    areas = aux.comp_convex_hull_areas(4)
    assert len(areas) == 4
    assert areas == pytest.approx(0.0)


def test_normal_operation(aux: GiouYawAux) -> None:
    # fmt: off
    rect_t4c = np.array([
        [[4.0, -1.0], [4.0, 1.0], [0.0, 1.0], [0.0, -1.0]], [[2.0, -1.0], [2.0, 1.0], [-2.0, 1.0], [-2.0, -1.0]],
        [[4.0, -1.0], [4.0, 1.0], [0.0, 1.0], [0.0, -1.0]],
        [[4.121320343559642, 0.7071067811865477], [2.7071067811865475, 2.121320343559643], [-0.12132034355964239, -0.7071067811865477], [1.2928932188134525, -2.121320343559643]],
        [[8.121320343559642, 0.7071067811865477], [6.707106781186547, 2.121320343559643], [3.8786796564403576, -0.7071067811865477], [5.292893218813453, -2.121320343559643]],
        [[8.0, -1.0], [8.0, 1.0], [4.0, 1.0], [4.0, -1.0]], [[18.0, -1.0], [18.0, 1.0], [14.0, 1.0], [14.0, -1.0]],
        [[8.0, -1.0], [8.0, 1.0], [4.0, 1.0], [4.0, -1.0]]
    ])
    # fmt: on
    aux.set_second_4_vertices(rect_t4c)
    aux.set_first_4_vertices(rect_t4c[1], 8)
    areas = aux.comp_convex_hull_areas(8)
    ref = 12.0, 8.0, 12.0, 16.48528137423857, 28.970562748477143, 20.0, 40.0, 20.0
    assert areas == pytest.approx(ref)
