"""."""

import numpy as np
import pytest

from kinematic_tracker.geometry.giou_yaw_aux import GiouYawAux


def test_set_second_4_vertices(aux: GiouYawAux) -> None:
    rect_t4c = np.linspace(1, 24, 24).reshape(3, 4, 2)
    aux.set_second_4_vertices(rect_t4c)
    # fmt: off
    ref = [
        [[0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [1.0, 2.0], [3.0, 4.0], [5.0, 6.0], [7.0, 8.0]],
        [[0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [9.0, 10.0], [11.0, 12.0], [13.0, 14.0], [15.0, 16.0]],
        [[0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [17.0, 18.0], [19.0, 20.0], [21.0, 22.0], [23.0, 24.0]]
    ]
    # fmt: on
    assert aux.merged_p8c[:3] == pytest.approx(np.array(ref))
