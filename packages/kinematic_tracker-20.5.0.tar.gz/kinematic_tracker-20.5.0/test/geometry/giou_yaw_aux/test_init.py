"""."""

from kinematic_tracker.geometry.giou_yaw_aux import GiouYawAux


def test_init(aux: GiouYawAux) -> None:
    assert aux.merged_p8c.shape == (123, 8, 2)
    assert aux.stacked_4p.shape == (4, 123)
    assert aux.union_heights_p.shape == (123,)
    assert aux.union_volumes_p.shape == (123,)
    assert aux.intersection_volumes_p.shape == (123,)
    assert aux.intersection_areas_p.shape == (123,)
    assert aux.intersection_heights_p.shape == (123,)
    assert aux.hull_areas_p.shape == (123,)
    assert aux.convex_hulls_p.shape == (123,)
    assert aux.multi_points_p.shape == (123,)
