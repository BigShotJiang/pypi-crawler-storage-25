import pytest

from kinematic_tracker.geometry.giou_yaw_aux import GiouYawAux


@pytest.fixture
def aux() -> GiouYawAux:
    return GiouYawAux(123)
