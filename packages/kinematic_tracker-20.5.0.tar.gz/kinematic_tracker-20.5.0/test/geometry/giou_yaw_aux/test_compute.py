"""."""

import numpy as np
import pytest

from kinematic_tracker.geometry.giou_yaw_aux import GiouYawAux
from kinematic_tracker.geometry.rectangle_buffers import RectangleBuffers


def test_compute(aux: GiouYawAux) -> None:
    # prepare
    rect_buffers = RectangleBuffers(10)
    det_rz = np.linspace(1, 40, 40).reshape(4, 10)
    det_rz[:, 4:6] = 0
    rect_buffers.set_nu_scenes(det_rz)
    cuboid = det_rz[1, :]
    poly = rect_buffers.mid_polygons_n[1]
    polygons = rect_buffers.mid_polygons_n[:4]
    volumes = det_rz[:, -3:].prod(axis=-1)
    out = np.ones(4)
    aux.set_first_4_vertices(rect_buffers.rect_coordinates_n4c[1, :, :2], 4)
    aux.set_second_4_vertices(rect_buffers.rect_coordinates_n4c[:4, :, :2])
    # compute
    aux.compute(cuboid, poly, det_rz, polygons, volumes, out)
    ref = 0.3185216546083782, 1.0, 0.4392318438129806, 0.3261591198359483
    assert out == pytest.approx(ref)
