"""."""

import numpy as np

from kinematic_tracker.geometry.giou_yaw_aux import GiouYawAux


def test_set_first_4_vertices(aux: GiouYawAux) -> None:
    rect_4c = np.linspace(1, 8, 8).reshape(4, 2)
    aux.set_first_4_vertices(rect_4c, 6)
    ref8 = [
        [1.0, 2.0],
        [3.0, 4.0],
        [5.0, 6.0],
        [7.0, 8.0],
        [0.0, 0.0],
        [0.0, 0.0],
        [0.0, 0.0],
        [0.0, 0.0],
    ]
    assert np.allclose(aux.merged_p8c[:6], np.array(ref8))
