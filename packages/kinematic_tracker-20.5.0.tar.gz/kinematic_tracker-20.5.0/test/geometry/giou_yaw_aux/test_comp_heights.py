"""."""

import numpy as np
import pytest

from kinematic_tracker.geometry.giou_yaw_aux import GiouYawAux
from kinematic_tracker.types import F3T


def test_comp_heights(aux: GiouYawAux, vecs_289: F3T) -> None:
    cuboids = np.linspace(1, 30, 30).reshape(3, 10)
    cuboid = np.linspace(1, 10, 10)
    intersections, unions = aux.comp_heights(cuboid, cuboids)
    assert intersections == pytest.approx([10.0, 5.0, 0.0])
    assert unions == pytest.approx([10.0, 25.0, 40.0])
