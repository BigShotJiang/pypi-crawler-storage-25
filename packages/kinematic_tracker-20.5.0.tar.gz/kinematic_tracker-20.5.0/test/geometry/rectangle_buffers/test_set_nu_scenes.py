"""."""

import numpy as np
import pytest

from scipy.spatial.transform import Rotation

from kinematic_tracker.geometry.rectangle_buffers import RectangleBuffers
from kinematic_tracker.types import FMT


def test_set_nu_scenes(rb5: RectangleBuffers, vec_2z: FMT) -> None:
    rb5.set_nu_scenes(vec_2z)
    assert rb5.num_rect == 2
    ref = [
        [
            [2.8461538461538463, 7.730769230769232, 3.0],
            [-4.90769230769231, 3.1615384615384614, 3.0],
            [-0.8461538461538463, -3.7307692307692317, 3.0],
            [6.90769230769231, 0.8384615384615386, 3.0],
        ],
        [
            [18.5979381443299, 22.654639175257735, 13.0],
            [-0.049484536082477604, 19.01134020618557, 13.0],
            [3.4020618556701017, 1.345360824742265, 13.0],
            [22.049484536082478, 4.988659793814432, 13.0],
        ],
    ]
    assert rb5.rect_coordinates_n4c[:2] == pytest.approx(np.array(ref))

    for vec_z, vertices_4c in zip(vec_2z, rb5.rect_coordinates_n4c):
        rot = Rotation.from_quat(vec_z[3:7], scalar_first=True)
        mid_vertices_4c = rb5.unit_vertices_14c[0] * vec_z[7:].reshape(1, 3)
        vertices_c4 = np.dot(rot.as_matrix(), mid_vertices_4c.T) + vec_z[:3].T.reshape(3, 1)
        assert vertices_c4.T == pytest.approx(vertices_4c)
