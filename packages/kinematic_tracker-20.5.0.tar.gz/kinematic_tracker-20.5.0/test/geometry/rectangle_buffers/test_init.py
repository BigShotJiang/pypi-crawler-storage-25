"""."""

from kinematic_tracker.geometry.rectangle_buffers import RectangleBuffers


def test_init(rb5: RectangleBuffers) -> None:
    assert rb5.rect_coordinates_n4c.shape == (5, 4, 3)
    assert rb5.num_rect == 0
