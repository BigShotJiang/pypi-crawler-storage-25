"""LLM provider models for agent configuration.

This module defines the LLMProvider model used in agent.yaml configuration
and global configuration files.
"""

import logging
from enum import Enum

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SecretStr,
    field_validator,
    model_validator,
)

from holodeck.models.claude_config import AuthProvider

logger = logging.getLogger(__name__)

# Invariant (feature 031-eval-runs-dashboard): every provider secret field in
# this model tree MUST be declared as `SecretStr` (or `SecretStr | None`) so the
# eval-run redactor's type-driven rule covers them automatically. If a future
# provider adds an `auth_token`, OAuth refresh token, AWS credentials, or any
# similar field, type it `SecretStr` from day one — do NOT rely on the name
# allowlist in `lib/eval_run/redactor.py` alone.


class ProviderEnum(str, Enum):
    """Supported LLM providers."""

    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    ANTHROPIC = "anthropic"
    OLLAMA = "ollama"


class LLMProvider(BaseModel):
    """LLM provider configuration.

    Specifies which LLM provider and model to use, along with model parameters.
    """

    model_config = ConfigDict(extra="forbid")

    provider: ProviderEnum = Field(..., description="LLM provider")
    name: str = Field(..., description="Model name or identifier")
    temperature: float | None = Field(default=0.3, description="Temperature (0.0-2.0)")
    max_tokens: int | None = Field(
        default=1000, description="Maximum tokens to generate"
    )
    top_p: float | None = Field(default=None, description="Nucleus sampling parameter")
    endpoint: str | None = Field(
        None, description="API endpoint (required for Azure OpenAI and Ollama)"
    )
    api_key: SecretStr | None = Field(None, description="API Key for LLM Provider")
    api_version: str | None = Field(
        default=None,
        description="API version for Azure OpenAI (e.g., '2024-10-21')",
    )
    auth_provider: AuthProvider | None = Field(
        default=None,
        description=(
            "Authentication method for Anthropic provider. "
            "Defaults to api_key. Ignored for non-Anthropic providers."
        ),
    )

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate name is not empty."""
        if not v or not v.strip():
            raise ValueError("name must be a non-empty string")
        return v

    @field_validator("temperature")
    @classmethod
    def validate_temperature(cls, v: float | None) -> float | None:
        """Validate temperature is in valid range."""
        if v is not None and (v < 0.0 or v > 2.0):
            raise ValueError("temperature must be between 0.0 and 2.0")
        return v

    @field_validator("max_tokens")
    @classmethod
    def validate_max_tokens(cls, v: int | None) -> int | None:
        """Validate max_tokens is positive."""
        if v is not None and v <= 0:
            raise ValueError("max_tokens must be positive")
        return v

    @field_validator("top_p")
    @classmethod
    def validate_top_p(cls, v: float | None) -> float | None:
        """Validate top_p is in valid range."""
        if v is not None and (v < 0.0 or v > 1.0):
            raise ValueError("top_p must be between 0.0 and 1.0")
        return v

    @model_validator(mode="after")
    def check_endpoint_required(self) -> "LLMProvider":
        """Validate endpoint is provided for Azure OpenAI and Ollama."""
        if self.provider in (ProviderEnum.AZURE_OPENAI,) and (
            not self.endpoint or not self.endpoint.strip()
        ):
            raise ValueError(f"endpoint is required for {self.provider.value} provider")
        return self

    @model_validator(mode="after")
    def check_auth_provider_relevance(self) -> "LLMProvider":
        """Warn when auth_provider is set for non-Anthropic providers."""
        if self.auth_provider is not None and self.provider != ProviderEnum.ANTHROPIC:
            logger.warning(
                "auth_provider '%s' is only relevant for Anthropic provider; "
                "it will be ignored for provider '%s'",
                self.auth_provider.value,
                self.provider.value,
            )
        return self

    @model_validator(mode="after")
    def check_custom_auth_needs_endpoint(self) -> "LLMProvider":
        """Warn when auth_provider is 'custom' but no endpoint is set."""
        if self.auth_provider == AuthProvider.custom and not self.endpoint:
            logger.warning(
                "auth_provider 'custom' is typically used with a custom endpoint "
                "(e.g., endpoint: http://localhost:11434/v1). "
                "No endpoint is currently configured."
            )
        return self
