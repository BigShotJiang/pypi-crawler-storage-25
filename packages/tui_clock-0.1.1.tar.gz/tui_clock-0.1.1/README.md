# tui-clock

A terminal-based clock application that visualizes time using dot displays alongside traditional numeric formats.

![Screenshot](img/screenshot.png)

## Features

- **Hour display** - 24 dots representing hours of the day
- **Minute display** - 30 dots representing 60 minutes (2 min per dot)
- **Second display** - 30 dots representing 60 seconds (2 sec per dot)
- **Numeric time** - Traditional HH:MM:SS format
- **Date display** - Full date with day of week
- **Quit** - Press `q` to exit

All displays update in real-time.

## Requirements

- Python >= 3.11

## Installation

Using a virtual environment (recommended):

```bash
python -m venv venv
source venv/bin/activate
pip install tui-clock
```

Or install to your user directory:

```bash
pip install --user tui-clock
```

### Development

```bash
git clone https://github.com/YOUR_USERNAME/tui-clock.git
cd tui-clock
python -m venv venv
source venv/bin/activate
pip install -e .
```

## Usage

```bash
tui-clock
```

## Uninstall

```bash
pip uninstall tui-clock
```

## License

MIT
