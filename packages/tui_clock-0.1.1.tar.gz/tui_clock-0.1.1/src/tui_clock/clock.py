import time
from importlib.resources import files

from textual.app import App, ComposeResult
from textual.reactive import reactive
from textual.widgets import Footer, Header, Static, Placeholder
from textual.containers import Horizontal

from .time_display import TimeDisplay


class Clock(App):
	current_time = reactive(time.localtime())

	CSS_PATH = files(__package__).joinpath("styles.tcss")
	BINDINGS = []

	def compose(self) -> ComposeResult:
		yield Horizontal(
			TimeDisplay("h", classes="dots"),
			TimeDisplay("m", classes="dots"),
			TimeDisplay("s", classes="dots"),
		)
		yield TimeDisplay("f", classes="numeric")
		yield TimeDisplay("d", classes="numeric")

	def on_mount(self) -> None:
		self.set_interval(1, self.update_time)

	def on_key(self, event) -> None:
		match event.key:
			case "q":
				exit()

	def update_time(self) -> None:
		self.current_time = time.localtime()
