import time
from textual.app import RenderResult
from textual.widget import Widget
from rich.text import Text

FULL = ("● ", "bright_white")
HALF = ("● ", "grey62")
EMPTY = ("● ", "black")


class TimeDisplay(Widget):
    def __init__(self, unit: str, classes: str = None) -> None:
        super().__init__(classes=classes)
        self.unit = unit

    def on_mount(self) -> None:
        self.watch(self.app, "current_time", self.refresh)

    @property
    def appTime(self):
        return self.app.current_time

    def render(self) -> RenderResult:
        match self.unit:
            case "f":
                return self.render_full()
            case "d":
                return self.render_date()
            case "h":
                return self.render_hour()
            case _:
                return self.render_minsec()

    def render_hour(self) -> RenderResult:
        res = Text()
        for i in range(24):
            if i < self.appTime.tm_hour:
                res.append(*FULL)
            else:
                res.append(*EMPTY)
            if i % 4 == 3:
                res += "\n"
        return res

    def render_minsec(self) -> RenderResult:
        res = Text()
        match self.unit:
            case "m":
                value = self.appTime.tm_min
            case "s":
                value = self.appTime.tm_sec
        for i in range(30):
            if i < value // 2:
                res.append(*FULL)
            elif value % 2 == 1 and i == value // 2:
                res.append(*HALF)
            else:
                res.append(*EMPTY)
            if i % 5 == 4:
                res += "\n"
        return res

    def render_full(self) -> RenderResult:
        return (
            f"{self.appTime.tm_hour:02}:"
            f"{self.appTime.tm_min:02}:"
            f"{self.appTime.tm_sec:02}"
        )

    def render_date(self) -> RenderResult:
        return time.strftime("%A, %B, %d", self.appTime)
