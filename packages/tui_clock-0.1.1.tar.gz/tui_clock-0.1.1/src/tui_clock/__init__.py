from .clock import Clock

def main():
    Clock().run()
