"""
Antaris Agent Session Management — Multi-Session Support

Provides SessionManager and SessionState for managing independent conversation
sessions per (user_id, channel_id) pair. Each session maintains its own history,
conversation buffer, and state lifecycle.

Usage:
    session_manager = SessionManager(config)
    session = await session_manager.get_or_create(user_id, channel_id, platform)
    session.add_to_history(message)
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def estimate_tokens(content) -> int:
    """Rough token estimate from stringified content (chars / 4).

    This is an approximation — accurate enough for compaction budgets and
    context-percentage displays, but not a substitute for a real tokenizer.
    Structured messages (tool results, images) may over- or under-estimate.
    """
    return max(1, len(str(content)) // 4)


@dataclass
class SessionState:
    """
    Per-session state containing conversation history and metadata.
    
    Each session represents a unique (user_id, channel_id) pair and maintains
    independent conversation state, history, and buffer for context management.
    """
    session_id: str               # "{user_id}:{channel_id}" or custom label
    user_id: str
    channel_id: str
    platform: str                 # "discord" | "telegram" | "terminal"
    history: list                 # conversation history (list of Message dicts)
    message_count: int = 0
    compaction_notified: bool = False
    pre_compaction_flushed: bool = False
    conversation_buffer: list = field(default_factory=list)  # (user_id, user_msg, bot_resp) tuples
    created_at: float = 0.0       # time.time()
    last_active: float = 0.0
    status: str = "active"        # active | idle | compacted | closed
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Initialize timestamps if not set."""
        if self.created_at == 0.0:
            self.created_at = time.time()
        if self.last_active == 0.0:
            self.last_active = time.time()

    @property
    def context_pct(self) -> float:
        """Approximate context usage as percentage."""
        estimated_tokens = sum(estimate_tokens(m) for m in self.history)
        max_tokens = getattr(self, '_context_max_tokens', 1_000_000) or 1_000_000
        return min(100.0, (estimated_tokens / max_tokens) * 100)

    def add_to_history(self, message) -> None:
        """Add message to history without a hard message cap."""
        self.history.append(message)
        self.message_count += 1
        self.last_active = time.time()

    def add_to_buffer(self, user_id: str, user_msg: str, bot_resp: str) -> None:
        """Add to conversation buffer (rolling window of 30)."""
        self.conversation_buffer.append((user_id, user_msg, bot_resp))
        if len(self.conversation_buffer) > 30:
            self.conversation_buffer = self.conversation_buffer[-30:]

    def build_summary(self) -> str:
        """Build conversation summary from buffer."""
        if not self.conversation_buffer:
            return "(no conversation data)"
        lines = ["### Recent conversation summary\n"]
        for uid, umsg, bresp in self.conversation_buffer:
            lines.append(f"- User: {umsg[:150]}")
            lines.append(f"  Bot: {bresp[:150]}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Serialize session state to a JSON-safe dict."""
        try:
            serialized_history = []
            for msg in self.history:
                try:
                    # Only serialize string content; skip vision/image blocks
                    content = msg.content
                    if isinstance(content, str):
                        serialized_history.append({"role": msg.role, "content": content})
                    # else: skip complex/structured content (images, tool use, etc.)
                except Exception:
                    pass  # skip any message that can't be serialized

            return {
                "session_id": self.session_id,
                "user_id": self.user_id,
                "channel_id": self.channel_id,
                "platform": self.platform,
                "history": serialized_history,
                "message_count": self.message_count,
                "created_at": self.created_at,
                "last_active": self.last_active,
                "status": self.status,
                "metadata": self.metadata,
            }
        except Exception as e:
            logger.warning("SessionState.to_dict() failed for %s: %s", self.session_id, e)
            return {}

    @classmethod
    def from_dict(cls, data: dict) -> "SessionState":
        """Restore a SessionState from a serialized dict."""
        try:
            from antaris_agent.llm.base import Message as LLMMessage
            history = []
            for m in data.get("history", []):
                try:
                    role = m.get("role", "user")
                    content = m.get("content", "")
                    if isinstance(content, str) and role in ("user", "assistant", "system"):
                        history.append(LLMMessage(role=role, content=content))
                except Exception:
                    pass  # skip malformed entries

            return cls(
                session_id=data["session_id"],
                user_id=data["user_id"],
                channel_id=data["channel_id"],
                platform=data.get("platform", "unknown"),
                history=history,
                message_count=data.get("message_count", 0),
                created_at=data.get("created_at", time.time()),
                last_active=data.get("last_active", time.time()),
                status=data.get("status", "active"),
                metadata=data.get("metadata", {}),
            )
        except Exception as e:
            logger.warning("SessionState.from_dict() failed: %s", e)
            raise


class SessionManager:
    """
    Coroutine-safe session management for Antaris Agent (asyncio.Lock).
    
    Manages active sessions, idle timeout, max concurrent limits, and session
    lifecycle operations (create, read, update, delete, compact).
    """

    def __init__(self, config, idle_timeout_minutes: int = 120, max_concurrent: int = 50):
        self._sessions: dict[str, SessionState] = {}
        self._lock: asyncio.Lock = asyncio.Lock()
        self._config = config
        self._idle_timeout = idle_timeout_minutes * 60
        self._max_concurrent = max_concurrent
        self._message_counter: int = 0  # for auto-save throttle
        logger.info("SessionManager initialized with %d minute timeout, %d max concurrent",
                   idle_timeout_minutes, max_concurrent)

    async def get_or_create(self, user_id: str, channel_id: str, platform: str) -> SessionState:
        """Get existing session or create new one. Coroutine-safe via asyncio.Lock."""
        session_id = self.session_id_for(user_id, channel_id)
        async with self._lock:
            if session_id in self._sessions:
                session = self._sessions[session_id]
                session.last_active = time.time()
                if session.status == "idle":
                    session.status = "active"
                    logger.debug("Reactivated idle session %s", session_id)
                return session
            
            # Check max concurrent limit
            active = sum(1 for s in self._sessions.values() if s.status in ("active", "idle"))
            if active >= self._max_concurrent:
                # Find and close oldest idle session
                idle = sorted(
                    [s for s in self._sessions.values() if s.status == "idle"],
                    key=lambda s: s.last_active
                )
                if idle:
                    oldest_session_id = idle[0].session_id
                    del self._sessions[oldest_session_id]
                    logger.info("Evicted oldest idle session %s to make room", oldest_session_id)

            session = SessionState(
                session_id=session_id,
                user_id=user_id,
                channel_id=channel_id,
                platform=platform,
                history=[],
                created_at=time.time(),
                last_active=time.time(),
            )
            session._context_max_tokens = getattr(self._config, 'context_max_tokens', 1_000_000) if self._config else 1_000_000
            self._sessions[session_id] = session
            logger.debug("Created new session %s for platform %s", session_id, platform)
            return session

    async def get_session(self, session_id: str) -> Optional[SessionState]:
        """Get session by ID. Returns None if not found."""
        return self._sessions.get(session_id)

    async def list_sessions(self, active_only: bool = True) -> list[SessionState]:
        """List all sessions, optionally filtering to active/idle/compacted only."""
        if active_only:
            return [s for s in self._sessions.values() if s.status in ("active", "idle", "compacted")]
        return list(self._sessions.values())

    async def kill_session(self, session_id: str) -> bool:
        """Terminate session. Returns True if found and closed."""
        if session_id not in self._sessions:
            return False
        session = self._sessions[session_id]
        session.status = "closed"
        del self._sessions[session_id]
        logger.info("Killed session %s", session_id)
        return True

    async def kill_all(self) -> int:
        """Terminate all sessions. Returns count killed."""
        count = len(self._sessions)
        for session in self._sessions.values():
            session.status = "closed"
        self._sessions.clear()
        if count:
            logger.info("Killed all %d sessions", count)
        return count

    async def reset_session(self, session_id: str) -> bool:
        """Clear history but keep session alive. Returns True if found."""
        if session_id not in self._sessions:
            return False
        session = self._sessions[session_id]
        session.history.clear()
        session.message_count = 0
        session.conversation_buffer.clear()
        session.compaction_notified = False
        session.pre_compaction_flushed = False
        logger.info("Reset session %s history and buffer", session_id)
        return True

    async def cleanup_idle(self) -> int:
        """Close sessions idle longer than timeout. Returns count closed."""
        now = time.time()
        to_close = [
            sid for sid, s in self._sessions.items()
            if s.status == "idle" and (now - s.last_active) > self._idle_timeout
        ]
        for sid in to_close:
            del self._sessions[sid]
        if to_close:
            logger.info("Cleaned up %d idle sessions", len(to_close))
        return len(to_close)

    async def compact_session(self, session_id: str) -> Optional[str]:
        """Compact session: build summary, truncate history by token budget. Returns summary or None."""
        session = self._sessions.get(session_id)
        if not session:
            return None
        summary = session.build_summary()
        keep_recent_tokens = getattr(self._config, 'keep_recent_tokens', 100_000) if self._config else 100_000
        kept_history: list = []
        token_total = 0
        for message in reversed(session.history):
            message_tokens = estimate_tokens(message)
            if kept_history and token_total + message_tokens > keep_recent_tokens:
                break
            # The first (most-recent) message is always kept so compaction never
            # produces an empty history.  Warn if it alone exceeds the budget.
            if not kept_history and message_tokens > keep_recent_tokens:
                logger.warning(
                    "Compaction: newest message (~%d tokens) exceeds keep_recent_tokens (%d)",
                    message_tokens, keep_recent_tokens,
                )
            kept_history.append(message)
            token_total += message_tokens
        session.history = list(reversed(kept_history))
        session.conversation_buffer.clear()
        session.status = "compacted"
        logger.info(
            "Compacted session %s, kept %d messages (~%d tokens)",
            session_id,
            len(session.history),
            token_total,
        )
        return summary

    def save_all(self, path: Path) -> None:
        """Save all active sessions to a JSON file."""
        if not getattr(self._config, "session_persistence_enabled", True):
            return
        try:
            sessions_data = {}
            for sid, session in self._sessions.items():
                try:
                    d = session.to_dict()
                    if d:
                        sessions_data[sid] = d
                except Exception as e:
                    logger.warning("Could not serialize session %s: %s", sid, e)
            tmp_path = Path(str(path) + ".tmp")
            tmp_path.parent.mkdir(parents=True, exist_ok=True)
            with open(tmp_path, "w") as f:
                json.dump({"version": 1, "saved_at": time.time(), "sessions": sessions_data}, f, indent=2)
            tmp_path.replace(path)
            logger.info("SessionManager.save_all: saved %d sessions to %s", len(sessions_data), path)
        except Exception as e:
            logger.warning("SessionManager.save_all() failed: %s", e)

    def load_all(self, path: Path) -> None:
        """Restore sessions from a JSON file. Prunes old sessions. Safe on corrupt/missing file."""
        if not getattr(self._config, "session_persistence_enabled", True):
            return
        if not path.exists():
            logger.debug("SessionManager.load_all: no sessions file at %s", path)
            return
        try:
            with open(path) as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("SessionManager.load_all: corrupt/unreadable sessions file (%s), starting fresh", e)
            return
        try:
            max_age_hours = getattr(self._config, "session_max_age_hours", 48)
            keep_recent_tokens = getattr(self._config, "keep_recent_tokens", 100_000) if self._config else 100_000
            cutoff = time.time() - (max_age_hours * 3600)
            sessions_data = data.get("sessions", {})
            restored = 0
            skipped_old = 0
            skipped_err = 0
            for sid, sdata in sessions_data.items():
                try:
                    last_active = sdata.get("last_active", 0)
                    if last_active < cutoff:
                        skipped_old += 1
                        continue
                    # Truncate restored history by token budget (consistent with compaction)
                    history = sdata.get("history", [])
                    if history:
                        kept: list = []
                        tok_total = 0
                        for msg in reversed(history):
                            msg_tokens = estimate_tokens(msg)
                            if kept and tok_total + msg_tokens > keep_recent_tokens:
                                break
                            kept.append(msg)
                            tok_total += msg_tokens
                        sdata = dict(sdata)
                        sdata["history"] = list(reversed(kept))
                    session = SessionState.from_dict(sdata)
                    session._context_max_tokens = getattr(self._config, 'context_max_tokens', 1_000_000) if self._config else 1_000_000
                    self._sessions[sid] = session
                    restored += 1
                except Exception as e:
                    logger.warning("SessionManager.load_all: could not restore session %s: %s", sid, e)
                    skipped_err += 1
            logger.info(
                "SessionManager.load_all: restored=%d, skipped_old=%d, skipped_err=%d (cutoff=%dh)",
                restored, skipped_old, skipped_err, max_age_hours,
            )
        except Exception as e:
            logger.warning("SessionManager.load_all: unexpected error restoring sessions: %s", e)

    def maybe_autosave(self, path: Path) -> None:
        """Increment message counter and save if interval reached."""
        if not getattr(self._config, "session_persistence_enabled", True):
            return
        try:
            interval = getattr(self._config, "session_save_interval", 5)
            self._message_counter += 1
            if self._message_counter >= interval:
                self._message_counter = 0
                self.save_all(path)
        except Exception as e:
            logger.warning("SessionManager.maybe_autosave() failed: %s", e)

    def session_id_for(self, user_id: str, channel_id: str) -> str:
        """Generate session ID from user and channel."""
        return f"{user_id}:{channel_id}"

    @property
    def active_count(self) -> int:
        """Count of active, idle, and compacted sessions."""
        return sum(1 for s in self._sessions.values() if s.status in ("active", "idle", "compacted"))

    @property
    def total_count(self) -> int:
        """Total count of all sessions."""
        return len(self._sessions)

    async def mark_idle(self, session_id: str) -> bool:
        """Mark session as idle. Returns True if found and marked."""
        session = self._sessions.get(session_id)
        if not session or session.status not in ("active", "compacted"):
            return False
        session.status = "idle"
        logger.debug("Marked session %s as idle", session_id)
        return True
