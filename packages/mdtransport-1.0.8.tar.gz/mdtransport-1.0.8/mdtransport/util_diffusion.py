#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import os
import sys
import math
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from .util import BaseAnalysis, tqdm 

def fit_func(x, a, b, c):
    return a * (1 - b * x**-c)

def get_cor_matrix(n, fit_type='GLS'):
    cor = np.eye(n)
    if fit_type == 'GLS':
        for i in range(n):
            for j in range(n):
                if i != j:
                    cor[i, j] = math.pow(2, -0.5 * math.fabs(i - j))
    return cor

def process_window(args):
    (t1, t2), species_data_local = args
    total_abs_dev = 0.0
    valid_species = 0

    for key in sorted(species_data_local.keys()):
        data = species_data_local[key]

        # indices up to t1 and t2
        i1 = t1
        i2 = t2 - 1

        # number of valid points
        n = (i2 - i1 + 1) - (data[i2, 4] - (data[i1 - 1, 4] if i1 > 0 else 0))

        if n < 2:
            continue

        # cumulative sums
        Sx = data[i2, 0] - (data[i1 - 1, 0] if i1 > 0 else 0)
        Sy = data[i2, 1] - (data[i1 - 1, 1] if i1 > 0 else 0)
        Sxx = data[i2, 2] - (data[i1 - 1, 2] if i1 > 0 else 0)
        Sxy = data[i2, 3] - (data[i1 - 1, 3] if i1 > 0 else 0)

        denom = (n * Sxx) - (Sx * Sx)
        if denom == 0:
            continue

        slope = (n * Sxy - Sx * Sy) / denom
        abs_dev = abs(slope - 1.0)
        total_abs_dev += abs_dev
        valid_species += 1

    if valid_species == 0:
        return (float("inf"), float("inf"), t1, t2)

    return (total_abs_dev, 0.0, t1, t2)

class UTIL_DIFFUSION(BaseAnalysis):
            
    """
    This is a UTIL_DIFFUSION class which perform diffusion and Nernst-Einstein conductivity analysis
    
    """
    def __init__(self, args):
                                
        """
        Initialize class with input arguments and class objects
        
        """
        super().__init__(args)
        self.n_cores = self.args.n_cores

    def perform_fit(self, times, d_tau, errors, fit_type='GLS'):
        n = len(times)
        
        cor0 = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                cor0[i, j] = 2.0 ** (-abs(j - i) / 2.0)
                
        if fit_type.upper() == 'WLS':
            cor0 = np.eye(n)

        cov = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                cov[i, j] = cor0[i, j] * errors[i] * errors[j]
                
        cov += np.eye(n) * 1e-12 * np.max(cov)

        t_scale = times[0]
        D_inf_guess = d_tau[-1]
        b_guess = max(-99.0, min(99.0, 1.0 - (d_tau[0] / D_inf_guess)))
        
        if abs(b_guess) < 1e-4:
            b_guess = 1e-4 if b_guess >= 0 else -1e-4

        def run_optimizer(fix_c=False):
            if fix_c:
                def func(t, D_inf, b_scaled):
                    return D_inf * (1 - b_scaled * np.power(t / t_scale, -1.0))
                p0 = [D_inf_guess, b_guess]
                bounds = ([0.0, -100.0], [10.0 * D_inf_guess, 100.0])
            else:
                def func(t, D_inf, b_scaled, c):
                    return D_inf * (1 - b_scaled * np.power(t / t_scale, -c))
                p0 = [D_inf_guess, b_guess, 1.0]
                bounds = ([0.0, -100.0, 0.01], [10.0 * D_inf_guess, 100.0, 5.0])
                
            popt, pcov = curve_fit(func, times, d_tau, p0=p0, sigma=cov, 
                                   absolute_sigma=True, bounds=bounds, maxfev=10000)
            perr = np.sqrt(np.diag(pcov))
            return popt, perr

        try:
            popt_s, perr_s = run_optimizer(fix_c=False)
            
            if perr_s[0] > 0.25 * popt_s[0]:
                raise RuntimeError("Overfitting detected (error > 25%). Forcing 2-parameter fit.")
                
        except Exception as e_3param:
            try:
                popt_s, perr_s = run_optimizer(fix_c=True)
                popt_s = [popt_s[0], popt_s[1], 1.0]
                perr_s = [perr_s[0], perr_s[1], 0.0]
            except Exception as e_2param:
                self.log_message("ERROR", "\n--- OPTIMIZATION FAILED COMPLETELY ---")
                self.log_message("ERROR", f"3-Param fit crashed: {e_3param}")
                self.log_message("ERROR", f"2-Param fit crashed: {e_2param}")
                self.log_message("ERROR", "--------------------------------------\n")
                return None, None

        D_inf_opt = popt_s[0]
        b_scaled_opt = popt_s[1]
        c_opt = popt_s[2]
        
        b_true = b_scaled_opt * (t_scale ** c_opt)
        popt = [D_inf_opt, b_true, c_opt]
        perr = [perr_s[0], perr_s[1] * (t_scale ** c_opt), perr_s[2]]
        
        return popt, perr
        
    def find_best_time_window(self, msd_data_map, dt):
        
        """
        Finds the best time window where the log-log slope of MSD is closest to 1.
        """
    
        if not msd_data_map:
            return None, None, None
    
        lengths_map = {name: len(df) for name, df in msd_data_map.items()}
        unique_lengths = set(lengths_map.values())
        
        # If there is more than one unique length, we have a mismatch
        if len(unique_lengths) > 1:
            self.log_message("ERROR", "="*60)
            self.log_message("ERROR", "CRITICAL ERROR: MSD Data Length Mismatch")
            self.log_message("ERROR", "="*60)
            self.log_message("ERROR", "The MSD data for the provided species have different lengths.")
            self.log_message("ERROR", "This usually happens when including frozen atoms or species")
            self.log_message("ERROR", "that do not move significantly (e.g., graphite walls).")
            self.log_message("ERROR", "\nDetected Lengths:")
            
            for species, length in lengths_map.items():
                self.log_message("ERROR", f"  - {species:<10} : {length} data points")
                
            self.log_message("ERROR", "\nACTION REQUIRED:")
            self.log_message("ERROR", "Please run the command again using the '--skip_species' option")
            self.log_message("ERROR", "to exclude the species with inconsistent/shorter data.")
            self.log_message("ERROR", "="*60)
            
            sys.exit(1)

        total_len = list(unique_lengths)[0]
        
        if self.args.min_window:
            window_min_size = int(self.args.min_window / dt)
        elif total_len <= int(10000 / dt):
            window_min_size = int(total_len / 2)
        else:
            window_min_size = max(int(total_len / 4), int(8000 / dt))
        
        if dt <= 100:
            step = int(100 / dt)
            step = max(step, 1)
        else:
            step = 1

        if total_len < window_min_size:
            self.log_message("ERROR",
                             f"Shortest trajectory ({total_len*dt:.1f} ps) is shorter than "
                             f"minimum window size ({window_min_size*dt:.1f} ps).")
            sys.exit(1)

        if self.args.msd_fit is not None:
            start = int(self.args.msd_fit[0] / dt)
            end   = int(self.args.msd_fit[1] / dt)
        else:
            start = 0
            end   = total_len

        if start >= end:
            self.log_message(
                "ERROR",
                f"Invalid fit window: start ({start*dt:.1f} ps) must be less than "
                f"end ({end*dt:.1f} ps)."
            )
            sys.exit(1)

        if start < 0 or end > total_len:
            self.log_message(
                "ERROR",
                f"Fit window out of bounds: start={start*dt:.1f} ps, "
                f"end={end*dt:.1f} ps, trajectory length={total_len*dt:.1f} ps."
            )
            sys.exit(1)

        if (end - start) < window_min_size:
            self.log_message(
                "ERROR",
                f"Fit window ({(end-start)*dt:.1f} ps) is smaller than "
                f"minimum window size ({window_min_size*dt:.1f} ps)."
            )
            sys.exit(1)

        t1_start = start
        t1_end   = int(total_len - window_min_size)
        t2_end   = end
    
        if t1_start >= t1_end:
            self.log_message("ERROR", "Invalid search range for linear fit. Not enough data points.")
            sys.exit(1)
    
        windows_list = [
            (t1, t2)
            for t1 in range(t1_start, t1_end, step)
            for t2 in range(t1 + window_min_size, t2_end, step)
        ]
        windows_list = sorted(windows_list)
    
        if not windows_list:
            self.log_message("WARNING", "No valid time windows found for analysis.")
            return None, None
    
        precomputed_data_local = {}
    
        for key in sorted(msd_data_map.keys()):
            df = msd_data_map[key]
            delta = df["delta"].values
            product = df["product"].values
    
            valid_idx = (delta > 0) & (product > 0)
            log_t = np.log(delta[valid_idx]).astype(np.float64)
            log_m = np.log(product[valid_idx]).astype(np.float64)
    
            N = len(log_t)
            species_data = np.zeros((N, 5), dtype=np.float64)
    
            species_data[:, 0] = np.cumsum(log_t)
            species_data[:, 1] = np.cumsum(log_m)
            species_data[:, 2] = np.cumsum(log_t ** 2)
            species_data[:, 3] = np.cumsum(log_t * log_m)
            species_data[:, 4] = np.cumsum(~valid_idx[:N])  # invalid count prefix-sum
    
            precomputed_data_local[key] = species_data
    
        best_result = (float("inf"), float("inf"), -1, -1)
        
        pbar = tqdm(windows_list, desc="Finding best time window", unit="window")
        
        for win in pbar:
            current_arg = (win, precomputed_data_local)
            
            result = process_window(current_arg)
        
            if result < best_result:
                best_result = result
                avg_dev = best_result[0] / len(msd_data_map)
                pbar.set_postfix({"avg|β-1|": f"{avg_dev:.4f}"})
        
        best_diff, _, best_t1, best_t2 = best_result
        
        if np.isinf(best_diff):
            self.log_message("WARNING", "Could not find any valid window for slope calculation.")
            return None, None
    
        mean_abs_dev = best_diff / len(msd_data_map)
    
        tol = 0.075
        if mean_abs_dev >= tol:
            self.log_message("WARNING",
                             f"Mean deviation from ideal slope (1.0) is {mean_abs_dev:.3f}, above tolerance {tol}.")
            
        return mean_abs_dev, best_t1, best_t2

    def calculate_diffusivity(self, species_counts, dt, DIR):
        """
        Read CSVs, compute MSD slopes and diffusion coefficients.
        """
        skip_species = self.args.SKIP_SPECIES or []
        all_species = list(species_counts.keys())
        species_names = [s for s in all_species if s not in skip_species]
        self.generate_folders("results_diffusion")
        directions = set(DIR) if DIR else {"x", "y", "z"}
        dim = len(directions)
        msd_data_map = {}
        
        # Load MSD data
        for species_name in species_names:
            input_file = f"results_msd/msd_{species_name}.csv"
            if not os.path.exists(input_file): continue
            df_out = pd.read_csv(input_file)
            df_filtered = df_out[(df_out["delta"] > 0) & (df_out["product"] > 0)].reset_index(drop=True)
            if not df_filtered.empty:
                msd_data_map[species_name] = df_filtered

        if not msd_data_map:
            self.log_message("WARNING", "No valid MSD data found.")
            return
    
        # Identifies the diffusive regime window where Beta ~ 1
        avg_best_diff, best_t1, best_t2 = self.find_best_time_window(msd_data_map, dt)
        
        fit_method = getattr(self.args, "fit_method", "ols")
        if isinstance(fit_method, list):
            fit_method = fit_method[0] if len(fit_method) > 0 else "ols"
        if fit_method is None:
            fit_method = "ols"
            
        fit_method = str(fit_method).lower().strip()
        
        if fit_method == "ols":
            print_method = "Ordinary Least Squares"
        elif fit_method == "wls":
            print_method = "Weighted Least Squares"
        elif fit_method == "gls":
            print_method = "Generalized Least Squares"
        else:
            print_method = f"Unknown Method ({fit_method})"

        final_results = []

        for species_name, df in msd_data_map.items():
            res = {"Species": species_name, "Dimensions": f"{dim}D", "Fit_Method": fit_method.upper()}
            
            if best_t1 is not None and best_t2 is not None:
                df_window = df.iloc[best_t1:best_t2].copy().reset_index(drop=True)
            else:
                df_window = df.copy()

            if len(df_window) < 4: 
                self.log_message("WARNING", f"Skipping {species_name}: Time window has fewer than 4 points ({len(df_window)}).")
                continue 

            # Calculate Beta
            log_t = np.log(df_window["delta"])
            log_m = np.log(df_window["product"])
            beta, _ = np.polyfit(log_t, log_m, 1)

            if fit_method == "ols":
                # Linear fit for D (Standard OLS fit of MSD = 2*d*D*t)
                popt, pcov = np.polyfit(df_window["delta"], df_window["product"], 1, cov=True)
                slope, intercept_lin = popt
                D_species = slope / (2 * dim) * 1e-8
                slope_std = np.sqrt(pcov[0,0])
                D_uncertainty = slope_std / (2 * dim) * 1e-8

                res.update({
                    "Time Window (ps)": f"{df_window['delta'].iloc[0]:.2f}-{df_window['delta'].iloc[-1]:.2f}",
                    "Beta": f"{beta:.3f}",
                    "D (10⁻¹¹ m²/s)": f"{D_species*1e11:.3f}",
                    "Std_Error (10⁻¹¹ m²/s)": f"{D_uncertainty*1e11:.3f}",
                })
    
            elif fit_method in ["gls", "wls"]:
                df_curve = df.copy()
                # D(t) = MSD / (2 * dim * t)
                df_curve["D_t (10⁻¹¹ m²/s)"] = (df_curve["product"] / (2 * dim * df_curve["delta"])) * 1e-8 * 1e11
                df_curve["in_fit_window"] = False
                if best_t1 is not None and best_t2 is not None:
                    df_curve.loc[best_t1:best_t2, "in_fit_window"] = True
                
                curve_path = f"results_diffusion/diff_curve_{species_name}.csv"
                df_curve.to_csv(curve_path, index=False)

                max_pow = int(math.log2(len(df_window)))
                binary_indices = [2**p for p in range(max_pow) if 2**p < len(df_window)]
                df_binary = df_window.iloc[binary_indices]
                
                times = df_binary["delta"].values
                msd_vals = df_binary["product"].values
                d_tau = msd_vals / (2 * dim * times)
                
                orig_N = len(df)
                mi = np.array([orig_N - (best_t1 + idx) for idx in binary_indices])
                
                errors = d_tau * np.sqrt(2 / (dim * mi))

                popt, perr = self.perform_fit(times, d_tau, errors, fit_type=fit_method.upper())
                
                if popt is None: 
                    self.log_message("WARNING", f"{fit_method.upper()} fit failed for {species_name}.")
                    continue
    
                D_species = popt[0] * 1e-8
                uncertainty = perr[0] * 1e-8
    
                res.update({
                    "Time Window (ps)": f"{df_window['delta'].iloc[0]:.2f}-{df_window['delta'].iloc[-1]:.2f}",
                    "Beta": f"{beta:.3f}",
                    "D (10⁻¹¹ m²/s)": f"{D_species*1e11:.3f}",
                    "Std_Error (10⁻¹¹ m²/s)": f"{uncertainty*1e11:.3f}",
                })
            
            else:
                self.log_message("ERROR", f"Unknown fit method '{fit_method}'. Defaulting to None.")
                continue
    
            final_results.append(res)
    
        if not final_results:
            self.log_message("WARNING", "No diffusion coefficients calculated.")
            return

        display_cols = ["Species", "Dimensions", "Time Window (ps)", "Beta", "D (10⁻¹¹ m²/s)", "Std_Error (10⁻¹¹ m²/s)"]
        col_widths = {col: max(len(col), max(len(str(r.get(col, ""))) for r in final_results)) + 2 for col in display_cols}
    
        self.log_message("INFO", "=" * 120)
        self.log_message("INFO", f"Self-Diffusion Coefficients Summary (fitting method: {print_method})")
        self.log_message("INFO", "=" * 120)
    
        header_str = "".join([f"{col:<{col_widths[col]}}" for col in display_cols])
        self.log_message("INFO", header_str)
        self.log_message("INFO", "-" * len(header_str))
    
        for r in final_results:
            line = "".join([f"{str(r.get(col, '')):<{col_widths[col]}}" for col in display_cols])
            self.log_message("INFO", line)
    
        self.log_message("INFO", "=" * 120 + "\n")
        
        df_final = pd.DataFrame(final_results)
        df_final.to_csv("results_diffusion/diffusion_summary.csv", index=False)

    def calculate_nernst_einstein(self, K_m, species_counts, species_charges, dt, DIR):
        
        """
        Read CSVs, compute MSD slopes and Nernst-Einstein conductivity
        """

        self.generate_folders("results_nernst_einstein")
        self.generate_folders("results_transference_numbers")
        
        skip_species = self.args.SKIP_SPECIES
        if skip_species is None:
            skip_species = []
            
        all_species = list(species_counts.keys())
        species_names = [s for s in all_species if s not in skip_species]
        
        skipped_list = [s for s in all_species if s in skip_species]
        if skipped_list:
            self.log_message("INFO", f"Skipping Nernst-Einstein calculation for: {', '.join(skipped_list)}")
            
        if not species_names:
            self.log_message("WARNING", "All species were skipped. No NE calculations performed.")
            sys.exit(1)

        directions = set(DIR) if DIR else {"x", "y", "z"}
        dim = len(directions)
        msd_data_map = {}
        
        for species_name in species_names:
            input_file = f"results_msd/msd_{species_name}.csv"
            if not os.path.exists(input_file):
                self.log_message("WARNING", f"WARNING: {input_file} not found, skipping.")
                continue
    
            df_out = pd.read_csv(input_file)
            df_filtered = df_out[(df_out["delta"] > 0) & (df_out["product"] > 0)].reset_index(drop=True)
    
            if not df_filtered.empty:
                msd_data_map[species_name] = df_filtered
    
        if not msd_data_map:
            self.log_message("WARNING", "No valid MSD data found.")
            return
    
        avg_best_diff, best_t1, best_t2 = self.find_best_time_window(msd_data_map, dt)
        if best_t1 is None or best_t2 is None:
            self.log_message("WARNING", "Could not determine a best fit window. Aborting NE calculation.")
            return

        first_key = list(msd_data_map.keys())[0]
        t1_ps = round(msd_data_map[first_key]["delta"].iloc[best_t1], 2)
        t2_ps = round(msd_data_map[first_key]["delta"].iloc[best_t2], 2)
        
        if not hasattr(self.args, 'MSD') or not self.args.MSD:
            self.log_message("INFO", f"\nBest time window for linear fit: {t1_ps} – {t2_ps} ps | avg|β-1|: {avg_best_diff:.4f}\n")

        # Determine fitting method
        fit_method = getattr(self.args, "fit_method", "ols")
        if isinstance(fit_method, list):
            fit_method = fit_method[0] if len(fit_method) > 0 else "ols"
        if fit_method is None:
            fit_method = "ols"
        fit_method = str(fit_method).lower().strip()

        diffusion_data = {}
        diffusion_err = {}

        # Compute Diffusion Coefficients and Standard Errors per species
        for species_name, df in msd_data_map.items():
            df_window = df.iloc[best_t1:best_t2].copy().reset_index(drop=True)
            if len(df_window) < 4:
                self.log_message("WARNING", f"Skipping {species_name}: Time window has fewer than 4 points.")
                continue

            if fit_method == "ols":
                popt, pcov = np.polyfit(df_window["delta"], df_window["product"], 1, cov=True)
                slope = popt[0]
                slope_err = np.sqrt(pcov[0,0])
                
                D_species = slope / (2 * dim) * 1e-8
                D_unc = slope_err / (2 * dim) * 1e-8

            elif fit_method in ["gls", "wls"]:
                max_pow = int(math.log2(len(df_window)))
                binary_indices = [2**p for p in range(max_pow) if 2**p < len(df_window)]
                df_binary = df_window.iloc[binary_indices]
                
                times = df_binary["delta"].values
                msd_vals = df_binary["product"].values
                d_tau = msd_vals / (2 * dim * times)
                
                orig_N = len(df)
                mi = np.array([orig_N - (best_t1 + idx) for idx in binary_indices])
                errors = d_tau * np.sqrt(2 / (dim * mi))

                popt, perr = self.perform_fit(times, d_tau, errors, fit_type=fit_method.upper())
                
                if popt is None: 
                    self.log_message("WARNING", f"{fit_method.upper()} fit failed for {species_name}.")
                    continue
    
                D_species = popt[0] * 1e-8
                D_unc = perr[0] * 1e-8
            else:
                self.log_message("ERROR", f"Unknown fit method '{fit_method}'.")
                continue

            diffusion_data[species_name] = D_species
            diffusion_err[species_name] = D_unc

        charged_species = [s for s in species_names if species_charges.get(s, 0) != 0]
        
        if not charged_species:
            self.log_message("WARNING", "No charged species found.")
            self.log_message("WARNING", "Skipping Nernst-Einstein conductivity analysis.")
            sys.exit(1)
            
        neutral_species = [s for s in all_species if s not in charged_species]
        if neutral_species:
            self.log_message("INFO", f"Skipping neutral species for Nernst-Einstein analysis: {', '.join(neutral_species)}")

        # Compute NE summation factor A_s = c_s * z_s^2 * D_s and propagate variance
        NE_sum = 0.0
        NE_var = 0.0
        A_dict = {}
        A_err_dict = {}
        
        for s in charged_species:
            if s in diffusion_data:
                factor = species_counts[s] * (species_charges[s] ** 2)
                A_s = factor * diffusion_data[s]
                A_err_s = factor * diffusion_err[s]
                
                A_dict[s] = A_s
                A_err_dict[s] = A_err_s
                
                NE_sum += A_s
                NE_var += A_err_s ** 2

        if NE_sum == 0:
            self.log_message("ERROR", "\nCould not calculate Transference Numbers or Nernst-Einstein Conductivity (sum of charges*D is zero).")
            return

        NE_err = np.sqrt(NE_var)
        
        # Calculate Transference Numbers and their individual errors
        final_results_ne = []
        for s in charged_species:
            if s in A_dict:
                A_s = A_dict[s]
                A_err_s = A_err_dict[s]
                
                t_s = A_s / NE_sum
                
                # Transference error variance formula taking independence into account:
                var_t_s = ((1 - t_s) / NE_sum)**2 * A_err_s**2
                for i in charged_species:
                    if i != s and i in A_err_dict:
                        var_t_s += (t_s / NE_sum)**2 * A_err_dict[i]**2
                
                t_err_s = np.sqrt(var_t_s)
                
                final_results_ne.append({
                    "Species": s, 
                    "Transference Number": f"{t_s:.4f} ± {t_err_s:.4f}"
                })

        df_transference = pd.DataFrame(final_results_ne)
        self.log_message("INFO", "=" * 65) 
        self.log_message("INFO", f"     Nernst-Einstein Transference Numbers Summary ({fit_method.upper()}) ")
        self.log_message("INFO", "=" * 65 + "\n")

        if not df_transference.empty:
            col_widths = {}
            for col in df_transference.columns:
                max_len = max(len(str(col)), df_transference[col].astype(str).str.len().max())
                col_widths[col] = max_len + 2  
        
            header_line = "".join([f"{col:<{width}}" for col, width in col_widths.items()])
            self.log_message("INFO", header_line)
            self.log_message("INFO", "-" * len(header_line))
        
            for index, row in df_transference.iterrows():
                row_line = "".join([f"{str(row[col]):<{col_widths[col]}}" for col in df_transference.columns])
                self.log_message("INFO", row_line)
        else:
            self.log_message("WARNING", "No transference number data to display.")
        
        df_transference.to_csv("results_transference_numbers/transference_numbers_summary.csv", index=False)
        
        # Extract global Nernst-Einstein Result
        KEY_WIDTH = 32
        NE_conductivity_Sm = K_m * NE_sum
        NE_conductivity_err = K_m * NE_err
        
        self.log_message("INFO", "\n")
        self.log_message("INFO", "=" * 65) 
        self.log_message("INFO", f"         Nernst-Einstein Conductivity Summary ({fit_method.upper()}) ")
        self.log_message("INFO", "=" * 65)
        
        key_text = "Nernst-Einstein Conductivity"
        value_str = f"{NE_conductivity_Sm:.4f} ± {NE_conductivity_err:.4f} S/m"
        self.log_message("INFO", f" {key_text:<{KEY_WIDTH}} : {value_str}")
        
        self.log_message("INFO", "=" * 65 + "\n")
        
        pd.DataFrame({
            "Method": [fit_method.upper()],
            "Nernst_Einstein_Conductivity (S/m)": [NE_conductivity_Sm],
            "Std_Error (S/m)": [NE_conductivity_err]
        }).to_csv("results_nernst_einstein/nernst_einstein_summary.csv", index=False)
        
        return