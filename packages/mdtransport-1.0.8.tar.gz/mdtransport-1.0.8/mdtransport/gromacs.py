#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import os
import gc
import sys
import time
import glob
import pandas as pd
import numpy as np
import scipy.constants as const
from datetime import datetime
from .util import BaseAnalysis, tqdm
from .util_gromacs import UTIL_GROMACS
from .util_onsager import UTIL_ONSAGER
from .util_transport import UTIL_TRANSPORT
from .util_smd import UTIL_SMD
from .util_msd import UTIL_MSD
from .util_rdf import UTIL_RDF
from .util_einstein import UTIL_EN
from .util_spda import UTIL_SPDA
from .util_pcl import Util_PairLifetime
from .util_cagecorr import Util_CageCorrelation
from .util_clusterpopulation import Util_ClusterPopulation
from .util_vehicular import UTIL_Vehicular
from .util_diffusion import UTIL_DIFFUSION
      
class GROMACS(BaseAnalysis):
    
    """
    This is a GROMACS class which calls various functions to perform transport analysis
    
    """
    def __init__(self, args):
        
        """
        Initialize class with input arguments and class objects
        
        """
        super().__init__(args)
        self.util_gromacs = UTIL_GROMACS(args)
        self.util_transport = UTIL_TRANSPORT(args)
        self.util_onsager = UTIL_ONSAGER(args)
        self.util_smd = UTIL_SMD(args)
        self.util_msd = UTIL_MSD(args)
        self.util_rdf = UTIL_RDF(args)
        self.util_einstein = UTIL_EN(args)
        self.util_spda = UTIL_SPDA(args)
        self.util_pcl = Util_PairLifetime(args)
        self.util_cagecorr = Util_CageCorrelation(args)
        self.util_clusterpopulation = Util_ClusterPopulation(args)
        self.util_vehicular = UTIL_Vehicular(args)
        self.util_diffusion = UTIL_DIFFUSION(args)
        
        self.data_prepared = False
        self.corr_dfs = None
        self.box_df = None
        self.species_charges = None
        self.species_counts = None
        self.dt = None
        self.Volume = None
        self.K_multi = None
        self.K_onsg = None
        self.K_m_nernst = None

    def get_com(self, species=None, frames=None):
        """
        COM extractor.
        """
        if getattr(self, 'COM_data', None) is None:
            self.log_message("ERROR", "COM data not loaded.")
            return pd.DataFrame()

        n_frames, n_mols, n_cols = self.COM_data.shape
        
        # Determine indices
        mol_indices = np.arange(n_mols) if species is None else ([species] if isinstance(species, int) else list(species))
        frame_indices = np.arange(n_frames) if frames is None else ([frames] if isinstance(frames, int) else list(frames))

        # Slice data
        sliced_data = self.COM_data[np.ix_(frame_indices, mol_indices)]
        n_req_frames, n_req_mols = len(frame_indices), len(mol_indices)

        # Handle 3-column vs 4-column data (X,Y,Z vs T,X,Y,Z)
        if n_cols == 4:
            times = sliced_data[:, :, 0].flatten()
            x, y, z = sliced_data[:, :, 1].flatten(), sliced_data[:, :, 2].flatten(), sliced_data[:, :, 3].flatten()
        else:
            # Get times from the stored pos_times array
            times = np.repeat(self.pos_times[frame_indices], n_req_mols)
            x, y, z = sliced_data[:, :, 0].flatten(), sliced_data[:, :, 1].flatten(), sliced_data[:, :, 2].flatten()
        
        df = pd.DataFrame({
            'frame': np.repeat(frame_indices, n_req_mols),
            'mol_id': np.tile(mol_indices, n_req_frames),
            't': times,
            'xu': x, 'yu': y, 'zu': z
        })
        return df.dropna(subset=['xu']).reset_index(drop=True)


    def get_pos(self, resnames=None, mol_ids=None, atom_types=None, atom_names=None, atom_masses=None, frames=None, times=None):
        """
        Atomic position extractor.
        """
        if getattr(self, 'POS_data', None) is None:
            self.log_message("ERROR", "Atomic positions not loaded.")
            return pd.DataFrame()

        mask = pd.Series([True] * len(self.atom_metadata))
        if resnames: mask &= self.atom_metadata['resname'].isin([resnames] if isinstance(resnames, str) else resnames)
        if mol_ids: mask &= self.atom_metadata['mol_id'].isin([mol_ids] if isinstance(mol_ids, int) else mol_ids)
        if atom_types: mask &= self.atom_metadata['atom_type'].isin([atom_types] if isinstance(atom_types, str) else atom_types)
        if atom_names: mask &= self.atom_metadata['atom_name'].isin([atom_names] if isinstance(atom_names, str) else atom_names)
        
        if atom_masses:
            m_list = [atom_masses] if isinstance(atom_masses, (int, float)) else atom_masses
            mask &= self.atom_metadata['mass'].isin(m_list)
            
        atom_indices = np.where(mask)[0]
        if len(atom_indices) == 0: return pd.DataFrame()

        if times is not None:
            t_list = [times] if isinstance(times, (int, float)) else times
            frame_indices = [np.argmin(np.abs(self.pos_times - t)) for t in t_list]
        else:
            frame_indices = np.arange(self.POS_data.shape[0]) if frames is None else ([frames] if isinstance(frames, int) else list(frames))

        sliced_coords = self.POS_data[np.ix_(frame_indices, atom_indices)]
        n_f, n_a = len(frame_indices), len(atom_indices)
        
        meta_subset = self.atom_metadata.iloc[atom_indices]
        df = pd.concat([meta_subset] * n_f, ignore_index=True)
        
        df['frame'] = np.repeat(frame_indices, n_a)
        df['time'] = np.repeat(self.pos_times[frame_indices], n_a)
        
        coords_flat = sliced_coords.reshape(-1, 3)
        df['x'], df['y'], df['z'] = coords_flat[:, 0], coords_flat[:, 1], coords_flat[:, 2]

        return df
    
    def create_charge_array(self):
        """
        Creates a DataFrame mapping IDs to charges.
        """
        if getattr(self, 'atomic_coordinates', False):
            if hasattr(self, 'atom_metadata') and not self.atom_metadata.empty:
                cols = ['atom_index', 'mol_id', 'resname', 'atom_name', 'atom_type', 'charge']
                available_cols = [c for c in cols if c in self.atom_metadata.columns]
                self.charge = self.atom_metadata[available_cols].copy()
                return self.charge

        elif hasattr(self, 'inv_mol_id_map') and self.inv_mol_id_map is not None:
            charge_data = []
            charge_lookup = getattr(self, 'species_charges', {}) or {}
            
            for mol_id, res_info in self.inv_mol_id_map.items():
                resname = res_info[0] if isinstance(res_info, (tuple, list)) else res_info
                
                if hasattr(self, 'charges_df') and self.charges_df is not None:
                    try: q = self.charges_df.iloc[mol_id]['q']
                    except: q = charge_lookup.get(resname, 0.0)
                else:
                    q = charge_lookup.get(resname, 0.0)
                    
                charge_data.append({'mol_id': mol_id + 1, 'resname': resname, 'charge': q})
            
            self.charge = pd.DataFrame(charge_data)
            return self.charge

        return pd.DataFrame()
    
    
    def export_data(self):
        """
        Export system state to CSV files in chunks to prevent memory overload. 
        """
        # Save Atomic Coordinates
        if getattr(self, 'POS_data', None) is not None:
            filename = "atomic_coord.csv"
            
            n_frames = self.POS_data.shape[0]
            n_atoms = self.POS_data.shape[1]
            
            # Write in chunks to save memory
            chunk_size = max(1, 2000000 // n_atoms) 
            first_write = True
            base_meta = self.atom_metadata.copy()

            with tqdm(total=n_frames, desc="Exporting  Data") as pbar:
                for start_idx in range(0, n_frames, chunk_size):
                    end_idx = min(start_idx + chunk_size, n_frames)
                    chunk_frames = end_idx - start_idx
                    
                    pos_chunk = self.POS_data[start_idx:end_idx]  # Extract slice from disk
                    chunk_df = pd.concat([base_meta] * chunk_frames, ignore_index=True)
                    
                    times_chunk = self.pos_times[start_idx:end_idx]
                    chunk_df.insert(0, 't', np.repeat(times_chunk, n_atoms))
                    
                    coords_flat = pos_chunk.reshape(-1, 3)
                    chunk_df['x'] = coords_flat[:, 0]
                    chunk_df['y'] = coords_flat[:, 1]
                    chunk_df['z'] = coords_flat[:, 2]
                    
                    chunk_df.to_csv(filename, mode='a' if not first_write else 'w', 
                                    header=first_write, index=False)
                    first_write = False
                    pbar.update(chunk_frames)
                    
            self.log_message("INFO", f"Successfully saved Atomic Coordinates to {filename}")

        # Save COM Coordinates
        if getattr(self, 'COM_data', None) is not None:
            filename = "com_coord.csv"
            n_frames = self.COM_data.shape[0]
            n_mols = self.COM_data.shape[1]
            n_cols = self.COM_data.shape[2] # Could be 3 or 4
            
            # Identify time source for COM mode
            time_df = getattr(self, 'box_df', None)
            
            self.log_message("INFO", f"Exporting COM Coordinates to {filename}...")
            
            # Write header
            header = ["mol_id", "t", "xu", "yu", "zu"]
            with open(filename, 'w') as f:
                f.write(",".join(header) + "\n")
                
                for i in range(n_frames):
                    frame_data = self.COM_data[i] # Current frame data
                    
                    if n_cols == 4:
                        temp_df = pd.DataFrame(frame_data, columns=['t', 'xu', 'yu', 'zu'])
                    else:
                        temp_df = pd.DataFrame(frame_data, columns=['xu', 'yu', 'zu'])
                        # Prepend time from the box dataframe
                        t_val = time_df.iloc[i]['t'] if time_df is not None else i
                        temp_df.insert(0, 't', t_val)
                    
                    # Add mol_id (1-based)
                    temp_df.insert(0, 'mol_id', np.arange(1, n_mols + 1))
                    
                    # Append this frame to the file
                    temp_df.to_csv(f, header=False, index=False)
                    
            self.log_message("INFO", "Successfully saved COM Coordinates.")
        
        # Save Box Dimensions
        if hasattr(self, 'box_df'): 
            filename = "box_length.csv"
            self.box_df.to_csv(filename, index=False)
            self.log_message("INFO", f"Successfully saved Box Dimensions to {filename}")

        # Save Charges
        filename = "charges.csv"
        df_charge = self.create_charge_array()
        
        if not df_charge.empty:
            if getattr(self, 'atomic_coordinates', False):
                cols = ['atom_index', 'mol_id', 'resname', 'atom_name', 'atom_type', 'charge']
            else:
                cols = ['mol_id', 'resname', 'charge']
            
            final_cols = [c for c in cols if c in df_charge.columns]
            df_charge[final_cols].to_csv(filename, index=False)
            
            mode_str = "Atomic" if getattr(self, 'atomic_coordinates', False) else "Molecular"
            self.log_message("INFO", f"Successfully saved {mode_str} Charges to {filename}")
            
    def prepare_data_for_analysis(self):
        """
        Function for parsing and extracting trajectory data.
        """

        if self.data_prepared:
            return
        
        prep_start_time = time.time()
        self.print_centered_block(
            "MDTransport: Starting Data Preparation",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )

        if self.args.msd_mode and self.args.msd_species:
            self.update_filters_for_msd_extraction()
            
        n_steps = self.args.n_steps
        t_start, t_end = (n_steps[0], n_steps[1]) if n_steps else (0, float("inf"))
        
        analysis_flags = [
            'PCL','CAGE','CAGE_P','VEH','ONSG','NE','SMD','SPDA','CORR','EN'
        ]
        
        requested = {flag for flag in analysis_flags if getattr(self.args, flag, False)}
    
        # Check if RDF/MSD modes are actually enabled
        rdf_ok = self.args.RDF and (self.args.rdf_mode is not None)
        msd_ok = self.args.MSD and (self.args.msd_mode is not None)
    
        self.atomic_coordinates = ((self.args.GET_CSV == "atom") or (rdf_ok or msd_ok)) and not requested
        
        if self.atomic_coordinates:
            self.log_message("INFO", "Mode: Atomic Coordinate Extraction")
            self.POS_data, self.box_df, self.atom_metadata, self.system_mass = self.get_system_info(
                t_start, t_end, valid_species=False, return_atoms=True
            )
            self.pos_times = self.box_df['t'].values
        else:
            self.log_message("INFO", "Mode: Center of Mass Extraction")
            results = self.get_system_info(t_start, t_end, valid_species=False, return_atoms=False)
            
            (self.COM_data, self.box_df, self.species_charges, 
             self.species_counts, self.dt, self.unique_resnames, 
             self.inv_mol_id_map, self.system_mass, self.species_masses) = results

        # Calculate Physical Properties 
        if not self.box_df.empty:
            self.Volume = ((self.box_df["Lx"] * self.box_df["Ly"] * self.box_df["Lz"]).mean()) * (10 ** (-30))
            # mass_kg conversion
            mass_kg = self.system_mass * 1.66054e-27                
            self.system_density = mass_kg / self.Volume      
        else:
            self.Volume = 0.0
            self.system_density = 0.0
                    
        # Pre-calculate prefactors for specific analysis (Only in COM Mode)
        if not self.atomic_coordinates:
            if (self.args.EN or self.args.CORR or self.args.SPDA):
                self.K_multi = self.compute_K_multi(self.Volume)
            if self.args.NE:
                self.K_m_nernst = self.compute_K_m(self.Volume)
            if self.args.ONSG:
                N_A = const.Avogadro
                self.K_onsg = (self.compute_K_Onsg(self.Volume)) / (N_A)**2
        
        # Dynamic Printing Logic
        keys_to_print = ["Average Volume", "Average Density"]
        
        if self.atomic_coordinates:
            keys_to_print.append("Atoms Extracted")
        else:
            for species in self.species_counts.keys():
                keys_to_print.append(species)
                keys_to_print.append(f"{species}_charge")

        KEY_WIDTH = max(len(key) for key in keys_to_print) + 2

        self.log_message("INFO","\n")
        self.log_message("INFO","=" * 55)
        self.log_message("INFO","                 System Properties")
        self.log_message("INFO","=" * 55)

        # Print Volume and Density (nm^3 and kg/m^3)
        self.log_message("INFO",f"{'Average Volume':<{KEY_WIDTH}} : {self.Volume * 10 ** (27):.3f} nm³")
        self.log_message("INFO",f"{'Average Density':<{KEY_WIDTH}} : {self.system_density:.3f} kg/m³")
        
        if self.atomic_coordinates:
            # Atomic Mode specific print
            n_atoms = self.POS_data.shape[1] if hasattr(self, 'POS_data') else 0
            self.log_message("INFO",f"{'Atoms Extracted':<{KEY_WIDTH}} : {n_atoms}")
        else:
            # COM Mode specific print (Species Counts)
            for species, count in self.species_counts.items():
                self.log_message("INFO",f"{species:<{KEY_WIDTH}} : {count}")
            
            # COM Mode specific print (Charges)
            for species, charge in self.species_charges.items():
                key = f"{species}_charge"
                self.log_message("INFO",f"{key:<{KEY_WIDTH}} : {charge:.3f}")
            
        self.log_message("INFO","=" * 55 + "\n")

        if not self.atomic_coordinates:
            values = self.args.species_charges
            if values is not None:
                if len(values) == 1:
                    try:
                        val = float(values[0])
                    except ValueError:
                        self.log_message("ERROR", "Single value for --species-charge must be a float.")
                        sys.exit(1)
            
                    self.species_charges = {
                        name: float(np.sign(q) * val) if abs(q) > 0.1 else 0.0
                        for name, q in self.species_charges.items()
                    }
            
                    self.log_message(
                        "INFO",
                        f"Applying uniform charge magnitude ±{val} based on original sign "
                        "(neutral species set to 0.0)."
                    )
            
                else:
                    if len(values) % 2 != 0:
                        self.log_message(
                            "ERROR",
                            "Provide species-charge pairs like: EMI 0.8 BF 0.9"
                        )
                        sys.exit(1)
            
                    updates = {}
                    for i in range(0, len(values), 2):
                        name = values[i]
                        try:
                            charge = float(values[i + 1])
                        except ValueError:
                            self.log_message("ERROR", f"Invalid charge for species '{name}'.")
                            sys.exit(1)
            
                        updates[name] = charge
            
                    for name, charge in updates.items():
                        if name not in self.species_charges:
                            self.log_message("WARNING", f"Species '{name}' not found. Skipping.")
                            continue
                        self.species_charges[name] = charge
            
                    self.log_message(
                        "INFO",
                        f"Applied user-defined species charges: {updates}"
                    )
            self.system_drift = self.calculate_system_drift()
            
        self.data_prepared = True
        
        # Clean up temporary files
        hidden_files = glob.glob(".*.npz") + glob.glob(".*.lock")
        for f in hidden_files:
            try:
                os.remove(f)
            except:
                continue 
                    
        self.print_centered_block(
            "MDTransport: Data Preparation Finished",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            task_start_time=prep_start_time
        )
        
    def run_analysis(self):
        
        """
        Main function to run requested analyses sequentially.
        """
        main_start_time = time.time()
    
        analysis_map = {
            'PCL': (self.perform_pcl, "Pair-correlation Lifetime Analysis"),
            'CAGE': (self.perform_cage, "Cage Lifetime Analysis"),
            'CAGE_P': (self.perform_cage_p, "Cage Population (Cluster) Analysis"),
            'RDF': (self.perform_rdf, "Radial Distribution Function (RDF) Calculation"),
            'VEH': (self.perform_vehicular, "Vehicular Transport Mechanism Analysis"),
            'ONSG': (self.perform_onsager, "Onsager Transport Coefficients Analysis"),
            'MSD': (self.perform_msd, "Self-diffusion Coefficients Calculation"),
            'NE': (self.perform_nernest_einstein, "Nernst-Einstein Conductivity Calculation"),
            'SMD': (self.perform_smd, "Stefan-Maxwell Diffusivity and Conductivity Calculation"),
            'SPDA': (self.perform_spatial_decomposition, "Spatial Decomposition of Cross-Correlations"),
            'CORR': (self.perform_transport_coeff, "Einstein, Self- and Cross-correlations calculations"),
            'EN': (self.perform_einstein, "Einstein Conductivity Analysis"),
        }
        
        self.total_analysis = len(analysis_map)
        requested_analyses = [flag for flag in analysis_map if getattr(self.args, flag, False)]

        data_only = self.args.GET_CSV is not None
        
        if not requested_analyses and not data_only:
            self.log_message("WARNING", "No analysis flags were provided. Exiting.")
            return

        # Prepare the data once before running any analysis

        self.prepare_data_for_analysis()

        if data_only and not requested_analyses:
            task_start_time = time.time()
            self.print_centered_block(
                "MDTransport: DATA Loading Started",
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            )
            
            self.export_data()
            
            self.volume = self.Volume
            self.box = self.box_df
            self.charge = self.create_charge_array()

            self.print_centered_block(
                "MDTransport: DATA Loading Finished",
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                task_start_time=task_start_time,
                total_start_time=main_start_time
            )

            if self.args.USE_DISK:
                pos_file = "POS_data.dat"
                com_file = "COM_data.dat"
    
                for pat in {pos_file, com_file}: 
                    for f in glob.glob(pat):
                        try:
                            os.remove(f)
                        except FileNotFoundError:
                            pass
                        except OSError as e:
                            self.log_message("ERROR", f"Failed to delete {f}: {e}")
            
            return
        
        # Execute each requested analysis sequentially
        num_analyses = len(requested_analyses)
        for i, flag in enumerate(requested_analyses):
            method, description = analysis_map[flag]
            task_start_time = time.time()
            is_last_task = (i == num_analyses - 1)
    
            self.print_centered_block(
                f"MDTransport: Starting {description}",
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            )
            
            method() # Run the actual analysis
            
            self.print_centered_block(
                f"MDTransport: {description} Finished",
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                task_start_time=task_start_time,
                # Only pass the total_start_time if this is the very last task
                total_start_time=main_start_time if is_last_task else None
            )

        if hasattr(self, 'POS_data'):
            del self.POS_data
        if hasattr(self, 'COM_data'):
            del self.COM_data
        gc.collect()

        if self.args.USE_DISK:
            pos_file = "POS_data.dat"
            com_file = "COM_data.dat"

            for pat in {pos_file, com_file}: 
                for f in glob.glob(pat):
                    try:
                        os.remove(f)
                    except FileNotFoundError:
                        pass
                    except OSError as e:
                        self.log_message("ERROR", f"Failed to delete {f}: {e}")
        
    def perform_transport_coeff(self):
        self.log_message("DEBUG", f"Computed K_multi value: {self.K_multi}")
        self.util_transport.calculate_einstein_conductivity(self.COM_data, self.box_df, self.dt, self.species_counts, self.species_charges, self.args.n_delta, self.K_multi, self.system_drift, wrap_requested=False, charge_requested=True)

    def perform_onsager(self):
        self.log_message("DEBUG", f"Computed K_onsg value: {self.K_onsg}")
        self.util_onsager.calculate_onsager(self.COM_data, self.box_df, self.dt, self.species_counts, self.species_masses, self.args.n_delta, self.K_onsg, self.system_drift, wrap_requested=False, charge_requested=False)

    def perform_einstein(self):
        self.log_message("DEBUG", f"Computed K_multi value: {self.K_multi}")
        self.util_einstein.cal_einstein(self.COM_data, self.box_df, self.species_counts, self.species_charges, self.dt, self.K_multi, self.system_drift, wrap_requested=False, charge_requested=True)

    def perform_msd(self):
        if self.args.msd_mode and hasattr(self, 'POS_data'):
            self.dt = (self.pos_times[1] - self.pos_times[0]) if len(self.pos_times) > 1 else 1.0
            self.log_message("DEBUG", f"Calculating MSD for Atomic Selections (Mode: {self.args.msd_mode})")
            self.util_msd.calculate_atomic_msd(
                self.POS_data, self.box_df, self.atom_metadata, self.dt
            )
        
        elif hasattr(self, 'COM_data'):
            self.log_message("DEBUG", "Calculating MSD for Molecular COM")
            self.util_msd.calculate_msd(self.COM_data, self.box_df, self.species_counts, self.dt, self.args.DIR, self.system_drift, wrap_requested=False, charge_requested=False)
            
    def perform_nernest_einstein(self):
        self.log_message("DEBUG", f"Computed K_m_nernst value: {self.K_m_nernst}")
        if not self.args.MSD:
            self.util_msd.calculate_msd(self.COM_data, self.box_df, self.species_counts, self.dt, self.args.DIR, self.system_drift, wrap_requested=False, charge_requested=False)
        self.util_diffusion.calculate_nernst_einstein(self.K_m_nernst, self.species_counts, self.species_charges, self.dt, self.args.DIR)

    def perform_smd(self):
        self.util_smd.run_stefan_maxwell(self.COM_data, self.box_df, self.dt, self.species_counts, self.species_charges, self.Volume, self.args.Temp, self.system_drift, wrap_requested=False, charge_requested=False)

    def perform_spatial_decomposition(self):
        self.log_message("DEBUG", f"Computed K_multi value: {self.K_multi}")
        self.util_spda.run_spatial_decomposition_analysis(self.COM_data, self.box_df, self.species_counts, self.species_charges, self.dt, self.K_multi, self.args.n_delta, self.system_drift, wrap_requested=False, charge_requested=False)

    def perform_pcl(self):
        pcl_species1, pcl_species2 = self.args.resname
        self.util_pcl.run_pcl(self.COM_data, self.box_df, self.species_counts, self.species_charges, pcl_species1, pcl_species2, self.dt, self.system_drift, wrap_requested=True, charge_requested=False)

    def perform_cage(self):
        self.util_cagecorr.run_cage_lifetime(self.COM_data, self.box_df, self.species_counts, self.args.CA, self.args.AN, self.dt, self.system_drift, wrap_requested=True, charge_requested=False)
    
    def perform_cage_p(self):
        self.util_clusterpopulation.run_clusterpopulation(self.COM_data, self.box_df, self.species_counts, self.dt, self.system_drift, wrap_requested=True, charge_requested=False)

    def perform_rdf(self):
        if self.args.rdf_mode and hasattr(self, 'POS_data'):
            self.log_message("DEBUG", f"Calculating RDF for Atomic Selections (Modes: {self.args.rdf_mode})")
            self.util_rdf.perform_rdf_atomic(self.POS_data, self.atom_metadata, self.box_df, self.args.rdf_pairs, self.args.rdf_mode)

        elif hasattr(self, 'COM_data'):
            self.log_message("DEBUG", "Calculating RDF for Molecular COM")
            self.util_rdf.cal_rdf(self.COM_data, self.box_df, self.species_counts, self.dt, self.system_drift, wrap_requested=True, charge_requested=False)

    def perform_vehicular(self):
        species_i, species_j = self.args.resname
        self.util_vehicular.run_vehicular_analysis(self.COM_data, self.box_df, self.species_counts, species_i, species_j, self.dt, self.system_drift, wrap_requested=False, charge_requested=False)
    
    def format_time(self, seconds):
        
        """Function to format seconds into HH:MM:SS."""
        from datetime import timedelta
        return str(timedelta(seconds=int(seconds)))
    
    def print_centered_block(self, title, timestamp, task_start_time=None, total_start_time=None):
        
        """
        - If task_start_time is given, it prints the "Elapsed Time" for the task.
        - If total_start_time is given, it prints the "Total Wall Time" for the entire run.
        """
        width = 80
        self.log_message("INFO","\n")
        self.log_message("INFO","=" * (width + 5))
        self.log_message("INFO",f" {title} ".center(width + 5, ' '))
        self.log_message("INFO",f" {timestamp} ".center(width + 5, ' '))
        
        current_time = time.time()
        
        # Print the elapsed time for the specific task
        if task_start_time:
            elapsed_seconds = current_time - task_start_time
            formatted_time = self.format_time(elapsed_seconds)
            self.log_message("INFO",f" {'Elapsed Time'}: {formatted_time} ".center(width + 5, ' '))
    
        # Print the total wall time for the entire script execution
        if total_start_time:
            total_elapsed_seconds = current_time - total_start_time
            formatted_time = self.format_time(total_elapsed_seconds)
            self.log_message("INFO",f" {'Total Wall Time'}: {formatted_time} ".center(width + 5, ' '))
            
        self.log_message("INFO","=" * (width + 5) + "\n")