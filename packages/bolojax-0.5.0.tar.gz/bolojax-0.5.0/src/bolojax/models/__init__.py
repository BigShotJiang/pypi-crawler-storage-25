"""Model definitions for bolojax."""
