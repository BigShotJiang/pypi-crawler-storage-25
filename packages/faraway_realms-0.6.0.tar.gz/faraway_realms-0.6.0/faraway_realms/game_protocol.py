"""Structural interface that both Game and ClientGame satisfy."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from faraway_realms.chat import ChatMessage
    from faraway_realms.combat.projectile import Projectile
    from faraway_realms.combat.status import StatusInstance
    from faraway_realms.effects.fog import FogParams
    from faraway_realms.effects.light import LightSource
    from faraway_realms.entities.entity import Entity, GameEntity
    from faraway_realms.entities.static_object import StaticObject
    from faraway_realms.world.commands import Command
    from faraway_realms.world.factions import FactionRelations
    from faraway_realms.world.map import Map


@runtime_checkable
class GameProtocol(Protocol):
    """Structural interface satisfied by both Game and ClientGame."""

    @property
    def game_map(self) -> Map:
        """Return the active map."""
        ...

    @property
    def active_projectiles(self) -> list[Projectile]:
        """Return in-flight projectiles."""
        ...

    @property
    def static_objects(self) -> list[StaticObject]:
        """Return all static objects on the map."""
        ...

    @property
    def faction_relations(self) -> FactionRelations:
        """Return faction hostility relations."""
        ...

    @property
    def tick_rate(self) -> float:
        """Return the target ticks-per-second rate."""
        ...

    @property
    def abs_tick(self) -> int:
        """Return the current absolute tick counter."""
        ...

    def all_player_entities(self) -> list[GameEntity]:
        """Return all player-controlled entities."""
        ...

    def all_npcs(self) -> list[Entity]:
        """Return all NPC entities (those carrying a BehaviourComponent)."""
        ...

    def entity(self, entity_id: int) -> GameEntity | None:
        """Return entity by ID, or None."""
        ...

    def melee_anim_events(
        self,
    ) -> list[
        tuple[
            tuple[int, int],
            tuple[int, int],
            tuple[int, int, int],
            tuple[int, int, int] | None,
        ]
    ]:
        """Return (attacker_pos, target_pos, color) for all melee hits this tick."""
        ...

    def movement_trail_events(
        self,
    ) -> list[tuple[int, int, tuple[int, int, int], list[tuple[int, int]]]]:
        """Return (entity_id, char, fg_color, path) for each push trail this tick."""
        ...

    def attack_cooldown_fraction(self, entity_id: int) -> float:
        """Return attack cooldown progress for entity (0–1)."""
        ...

    def gcd_fraction(self, entity_id: int) -> float | None:
        """Return GCD progress while active, else None."""
        ...

    def cast_fraction(self, entity_id: int) -> float | None:
        """Return cast progress if casting, else None."""
        ...

    def ability_cooldown_fraction(self, entity_id: int, ability_name: str) -> float:
        """Return remaining cooldown fraction for the named ability."""
        ...

    def active_statuses(self, entity_id: int) -> list[StatusInstance]:
        """Return non-expired status effects on entity."""
        ...

    def has_active_status(self, entity_id: int, status_name: str) -> bool:
        """Return True when entity has the named active status."""
        ...

    def get_chat_history(self, last_n: int = 20) -> list[ChatMessage]:
        """Return the most recent chat messages."""
        ...

    def get_hit_seq(self, entity_id: int) -> int:
        """Return monotonically increasing hit count for entity."""
        ...

    def get_crit_dealt_seq(self, entity_id: int) -> int:
        """Return monotonically increasing crit count for entity."""
        ...

    def light_sources(self) -> list[tuple[int, int, LightSource]]:
        """Return all active light source positions."""
        ...

    def add_chat_message(
        self,
        message: str,
        color: tuple[int, int, int] = (200, 200, 200),
    ) -> None:
        """Append a message to the chat history."""
        ...

    def enqueue_command(self, command: Command) -> None:
        """Enqueue a command for processing."""
        ...

    def entity_catalogue(self) -> dict[str, dict]:
        """Return the full static type catalogue for all registries."""
        ...

    @property
    def ambient(self) -> float:
        """Return the ambient light level (0–1)."""
        ...

    @property
    def fog_params(self) -> FogParams:
        """Return the fog parameters for the current map."""
        ...
