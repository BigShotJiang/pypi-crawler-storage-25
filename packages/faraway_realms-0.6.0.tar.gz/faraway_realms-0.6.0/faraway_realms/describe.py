"""Client-side inspect logic: compose a description for any map position."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faraway_realms.game_protocol import GameProtocol

Color = tuple[int, int, int]

_DIM: Color = (120, 120, 120)
_HEADING: Color = (220, 220, 180)
_LABEL: Color = (160, 160, 160)
_VALUE: Color = (220, 220, 220)
_FACTION_COLORS: dict[str, Color] = {
    "player": (100, 200, 255),
    "hostile": (220, 80, 80),
    "neutral": (160, 160, 160),
    "friendly": (100, 220, 100),
}


@dataclass
class InspectResult:
    """Structured description of one map position."""

    heading: str
    lines: list[tuple[str, Color]] = field(default_factory=list)


def describe_position(
    game: GameProtocol, x: int, y: int, width: int = 18
) -> InspectResult:
    """Compose a full description of whatever is at *(x, y)*.

    Priority: entity > static object > tile.
    """
    entity_id = _entity_at(game, x, y)
    if entity_id is not None:
        return _describe_entity(game, entity_id, width)
    obj = _static_object_at(game, x, y)
    if obj is not None:
        return _describe_static_object(game, obj, width)
    return _describe_tile(game, x, y, width)


# ---------------------------------------------------------------------------
# Entity describe
# ---------------------------------------------------------------------------


def _entity_at(game: GameProtocol, x: int, y: int) -> int | None:
    for eid, (ex, ey) in game.game_map.get_all_positions().items():
        if ex == x and ey == y:
            return eid
    return None


def _describe_entity(game: GameProtocol, entity_id: int, width: int) -> InspectResult:
    entity = game.entity(entity_id)
    if entity is None:
        return InspectResult(heading="Entity")
    cat = game.entity_catalogue().get("entity_types", {}).get(entity.type_id, {})
    lines: list[tuple[str, Color]] = []
    lines.extend(_entity_faction_lines(entity.faction or ""))
    desc = cat.get("description")
    if desc:
        lines.append(("", _VALUE))
        lines.extend(_wrap(desc, width, _VALUE))
    lines.extend(_entity_stat_lines(entity.stats))
    lines.extend(_entity_status_lines(game.active_statuses(entity_id)))
    return InspectResult(heading=entity.display_name, lines=lines)


def _entity_faction_lines(faction: str) -> list[tuple[str, Color]]:
    if not faction:
        return []
    return [(faction.capitalize(), _FACTION_COLORS.get(faction, _DIM))]


def _entity_stat_lines(stats: dict) -> list[tuple[str, Color]]:
    if not stats:
        return []
    lines: list[tuple[str, Color]] = [("", _VALUE)]
    for stat in stats.values():
        if hasattr(stat, "current"):
            bar = f"{stat.abbreviation or '?'}: {stat.current}/{stat.value}"
        else:
            bar = f"{stat.abbreviation or '?'}: {stat.value}"
        lines.append((bar, _VALUE))
    return lines


def _entity_status_lines(statuses: list) -> list[tuple[str, Color]]:
    if not statuses:
        return []
    lines: list[tuple[str, Color]] = [("", _VALUE)]
    for s in statuses:
        lines.append((s.name, (200, 180, 80)))
    return lines


def _entity_ability_lines(cat: dict, catalogue: dict) -> list[tuple[str, Color]]:
    ability_cat = catalogue.get("ability_types", {})
    abilities = [a for a in (cat.get("abilities") or []) if a in ability_cat]
    if not abilities:
        return []
    lines: list[tuple[str, Color]] = [("", _VALUE), ("Abilities:", _LABEL)]
    for name in abilities:
        a = ability_cat[name]
        lines.append((f"  {name}", _VALUE))
        desc_a = a.get("description", "")
        if desc_a:
            lines.extend(_wrap(f"    {desc_a}", 18, _DIM))
    return lines


# ---------------------------------------------------------------------------
# Static object describe
# ---------------------------------------------------------------------------


def _static_object_at(game: GameProtocol, x: int, y: int):  # type: ignore[return]
    for obj in game.static_objects:
        if obj.x == x and obj.y == y:
            return obj
    return None


def _describe_static_object(game: GameProtocol, obj, width: int) -> InspectResult:  # type: ignore[return]
    cat_entry = (
        game.entity_catalogue().get("static_object_types", {}).get(obj.type_id, {})
    )
    name = (
        cat_entry.get("display_name")
        or obj.type_id.replace("_", " ").title()
        or "Object"
    )
    lines: list[tuple[str, Color]] = []
    desc = cat_entry.get("description")
    if desc:
        lines.extend(_wrap(desc, width, _VALUE))
    return InspectResult(heading=name, lines=lines)


# ---------------------------------------------------------------------------
# Tile describe
# ---------------------------------------------------------------------------


def _describe_tile(game: GameProtocol, x: int, y: int, width: int) -> InspectResult:
    from faraway_realms.world.tile import unknown_tile  # noqa: PLC0415

    tile = game.game_map.get_tile(x, y)
    sentinel = unknown_tile()
    if tile.char == sentinel.char and tile.bg_color == sentinel.bg_color:
        return InspectResult(heading="Unexplored")
    type_id = game.game_map.tile_type_ids.get((x, y))
    tile_cat = game.entity_catalogue().get("tile_types", {})
    if type_id and type_id in tile_cat:
        return _describe_typed_tile(game, x, y, tile, tile_cat[type_id], width)
    return _tile_generic_result(game, x, y, tile)


def _describe_typed_tile(
    game: GameProtocol, x: int, y: int, tile, cat_entry: dict, width: int
) -> InspectResult:
    desc = cat_entry.get("description") or ""
    dn = cat_entry.get("display_name") or ""
    heading = dn if dn else _tile_generic_heading(game, x, y)
    lines: list[tuple[str, Color]] = list(_wrap(desc, width, _VALUE)) if desc else []
    if not tile.walkable:
        lines.append(("Impassable", _DIM))
    return InspectResult(heading=heading, lines=lines)


def _tile_generic_heading(game: GameProtocol, x: int, y: int) -> str:
    tile = game.game_map.get_tile(x, y)
    return _compose_tile_heading(game, x, y, tile)


def _tile_generic_result(game: GameProtocol, x: int, y: int, tile) -> InspectResult:
    heading = _compose_tile_heading(game, x, y, tile)
    lines: list[tuple[str, Color]] = []
    if not tile.walkable:
        lines.append(("Impassable", _DIM))
    return InspectResult(heading=heading, lines=lines)


def _compose_tile_heading(game: GameProtocol, x: int, y: int, tile) -> str:
    zone = game.game_map.tile_zones.get((x, y), "")
    overlay_cat = game.entity_catalogue().get("tile_overlays", {})
    overlay_desc = overlay_cat.get(zone, {}).get("description") if zone else None
    base = "floor" if tile.walkable else "wall"
    return f"{overlay_desc.capitalize()} {base}" if overlay_desc else f"Cave {base}"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _wrap(text: str, width: int, color: Color) -> list[tuple[str, Color]]:
    """Break *text* into lines of at most *width* characters."""
    words = text.split()
    lines: list[tuple[str, Color]] = []
    current = ""
    for word in words:
        if current and len(current) + 1 + len(word) > width:
            lines.append((current, color))
            current = word
        else:
            current = f"{current} {word}".lstrip() if current else word
    if current:
        lines.append((current, color))
    return lines
