"""Sparse tile scatter pass — individual tile replacements at low probability."""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from faraway_realms.mapgen.base import MapGenResult, PopulationPass
from faraway_realms.world.tile import TILE_REGISTRY, Tile


@dataclass(frozen=True)
class ScatterReplacement:
    """A single tile replacement candidate with a per-tile roll probability.

    Parameters
    ----------
    tile : str
        Key in :data:`~faraway_realms.world.tile.TILE_REGISTRY`.
    probability : float
        Independent per-tile probability (0–1) of applying this replacement.
    inherit_bg : bool
        When ``True``, the replacement tile inherits the background colour of
        the tile being replaced (so scattered variants adapt to the
        noise-shifted colour underneath).  Default ``False``.
    inherit_fg : bool
        When ``True``, the replacement tile also inherits the foreground colour
        of the tile being replaced.  Use together with ``inherit_bg`` so both
        channels stay in sync with the noise-shifted original.
        Default ``False``.
    """

    tile: str
    probability: float
    inherit_bg: bool = False
    inherit_fg: bool = False


@dataclass(frozen=True)
class ScatterRule:
    """Rule for scattering replacement tiles across the map.

    Parameters
    ----------
    target : str
        ``"floor"`` or ``"wall"`` — which tile class to replace.
    replacements : tuple[ScatterReplacement, ...]
        Candidates tried in order; the first whose probability roll succeeds
        is applied.  Remaining candidates are skipped.
    zone : str or None
        When set, restricts the rule to tiles that received the named
        overlay or patch during :class:`NoiseTexturePass`.  ``None`` matches
        any zone (including ``"base"``).
    exclude_zones : tuple[str, ...]
        Zone names that are explicitly excluded.  Takes precedence over
        *zone*.  Use this to apply a rule globally except in specific zones
        (e.g. walls everywhere except the ``"gray_rock"`` patch).
    """

    target: str
    replacements: tuple[ScatterReplacement, ...]
    zone: str | None = None
    exclude_zones: tuple[str, ...] = ()


@dataclass
class TileScatterPass(PopulationPass):
    """Replace individual tiles at low probability using :class:`ScatterRule` list.

    Parameters
    ----------
    rules : tuple[ScatterRule, ...]
        Scatter rules applied in order per tile; first matching rule wins.
    """

    rules: tuple[ScatterRule, ...] = field(default_factory=tuple)

    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Apply scatter rules to every tile in *result.map*.

        Parameters
        ----------
        result : MapGenResult
            Generation result whose map tiles may be mutated.
        rng : random.Random
            Seeded random number generator for deterministic placement.
        """
        for x in range(result.map.width):
            for y in range(result.map.height):
                self._scatter_tile(
                    result.map, result.tile_zones, result.tile_type_ids, x, y, rng
                )

    def _scatter_tile(
        self,
        game_map,  # type: ignore[type-arg]
        zones: dict[tuple[int, int], str],
        tile_type_ids: dict[tuple[int, int], str],
        x: int,
        y: int,
        rng: random.Random,
    ) -> None:
        tile = game_map.get_tile(x, y)
        zone = zones.get((x, y), "base")
        for rule in self.rules:
            result = _try_rule(tile, rule, rng, zone)
            if result is not None:
                type_key, replacement = result
                game_map.set_tile(x, y, replacement)
                tile_type_ids[(x, y)] = type_key
                return


def _zone_matches(rule: ScatterRule, zone: str) -> bool:
    if zone in rule.exclude_zones:
        return False
    return rule.zone is None or zone == rule.zone


def _apply_inheritance(new_tile: Tile, original: Tile, rep: ScatterReplacement) -> Tile:
    if not rep.inherit_bg and not rep.inherit_fg:
        return new_tile
    return Tile(
        walkable=new_tile.walkable,
        bg_color=original.bg_color if rep.inherit_bg else new_tile.bg_color,
        fg_color=original.fg_color if rep.inherit_fg else new_tile.fg_color,
        char=new_tile.char,
        components=new_tile.components,
    )


def _try_replacements(
    rule: ScatterRule, rng: random.Random, original: Tile
) -> tuple[str, Tile] | None:
    for rep in rule.replacements:
        if rng.random() < rep.probability:  # noqa: S311 — game logic, not crypto
            new_tile = TILE_REGISTRY[rep.tile].make()
            return rep.tile, _apply_inheritance(new_tile, original, rep)
    return None


def _try_rule(
    tile: Tile, rule: ScatterRule, rng: random.Random, zone: str
) -> tuple[str, Tile] | None:
    if not _zone_matches(rule, zone):
        return None
    if (rule.target == "floor") != tile.walkable:
        return None
    return _try_replacements(rule, rng, tile)
