"""Base types for the map generation pipeline."""

from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faraway_realms.entities.creature_type import CreatureType
    from faraway_realms.entities.static_object import StaticObjectType


@dataclass(frozen=True)
class DoorCandidate:
    """A position where a door would fit between two adjacent walkable regions.

    Parameters
    ----------
    x : int
        Tile column.
    y : int
        Tile row.
    horizontal : bool
        ``True`` when the door spans north-south (fits in an east-west wall),
        ``False`` when it spans east-west (fits in a north-south wall).
    """

    x: int
    y: int
    horizontal: bool


@dataclass(frozen=True)
class Rect:
    """An axis-aligned rectangle used to represent room bounds.

    Parameters
    ----------
    x : int
        Left column (inclusive).
    y : int
        Top row (inclusive).
    width : int
        Number of columns.
    height : int
        Number of rows.
    """

    x: int
    y: int
    width: int
    height: int

    @property
    def x2(self) -> int:
        """One past the rightmost column (exclusive upper bound)."""
        return self.x + self.width

    @property
    def y2(self) -> int:
        """One past the bottommost row (exclusive upper bound)."""
        return self.y + self.height

    @property
    def center(self) -> tuple[int, int]:
        """Return the centre tile of the rectangle."""
        return (self.x + self.width // 2, self.y + self.height // 2)

    def intersects(self, other: Rect) -> bool:
        """Return True if this rectangle overlaps *other*.

        Parameters
        ----------
        other : Rect
            Rectangle to test against.

        Returns
        -------
        bool
            True when the two rectangles share at least one tile.
        """
        h_overlap = self.x < other.x2 and self.x2 > other.x
        return h_overlap and self.y < other.y2 and self.y2 > other.y


@dataclass
class MapGenResult:
    """Output of a map generation run.

    Parameters
    ----------
    map : faraway_realms.world.map.Map
        The fully constructed game map.
    rooms : list[Rect]
        Rectangular rooms carved by room-based generators (e.g. CaveGenerator).
        Empty for generators that do not produce rooms (e.g. cellular automata).
    player_start : tuple[int, int]
        Walkable (x, y) tile suitable for placing the player.
    spawn_zones : list[list[tuple[int, int]]]
        Algorithm-neutral spawn regions. Each entry is a list of walkable
        (x, y) positions. All zones are included; the player zone is identified
        by ``player_zone_index``. Population passes decide independently which
        zones to skip.
    player_zone_index : int
        Index into ``spawn_zones`` for the region containing the player.
        Population passes that should not spawn entities near the player
        skip this zone.
    door_candidates : list[DoorCandidate]
        Optional hints for door placement at corridor chokepoints or passage
        bottlenecks. Empty when the generator does not produce doors.
    creature_placements : list[tuple[CreatureType, int, int]]
        Creature type and (x, y) position for each NPC to spawn.
        Populated by :class:`CreaturePopulationPass` after generation.
    """

    from faraway_realms.world.map import Map  # local import to avoid circular deps

    map: Map
    rooms: list[Rect]
    player_start: tuple[int, int]
    spawn_zones: list[list[tuple[int, int]]] = field(default_factory=list)
    player_zone_index: int = 0
    door_candidates: list[DoorCandidate] = field(default_factory=list)
    creature_placements: list[tuple[CreatureType, int, int]] = field(
        default_factory=list
    )
    static_object_placements: list[tuple[StaticObjectType, int, int]] = field(
        default_factory=list
    )
    tile_zones: dict[tuple[int, int], str] = field(default_factory=dict)
    tile_type_ids: dict[tuple[int, int], str] = field(default_factory=dict)


def seed_base_tile_types(result: MapGenResult, floor_name: str, wall_name: str) -> None:
    """Record base tile type IDs for every tile in *result*.

    Patches and scatter passes overwrite specific cells afterwards; this
    ensures all tiles have a type ID, not just patch/scatter cells.
    """
    for y in range(result.map.height):
        for x in range(result.map.width):
            key = (x, y)
            if key not in result.tile_type_ids:
                name = floor_name if result.map.get_tile(x, y).walkable else wall_name
                result.tile_type_ids[key] = name


class PopulationPass(ABC):
    """Abstract base for a post-generation population step.

    After ``CaveGenerator.generate`` returns a :class:`MapGenResult`,
    one or more ``PopulationPass`` instances can be applied in sequence
    to place creatures, items, or other content.  Each pass receives the
    full generation result and a seeded RNG so that runs are repeatable.
    """

    @abstractmethod
    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Populate the world from the generation result.

        Parameters
        ----------
        result : MapGenResult
            The map and room layout produced by the generator.
        rng : random.Random
            Seeded random number generator for deterministic placement.
        """
