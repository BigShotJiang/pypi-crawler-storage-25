"""MapProfile — per-map-theme configuration loaded from YAML."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faraway_realms.effects.fog import FogParams
    from faraway_realms.mapgen.generator import GeneratorConfig
    from faraway_realms.mapgen.scatter_pass import ScatterRule


def _default_generator() -> GeneratorConfig:
    from faraway_realms.mapgen.generator import GeneratorConfig

    return GeneratorConfig()


def _default_fog() -> FogParams:
    from faraway_realms.effects.fog import FogParams

    return FogParams(
        density=0.5,
        scale=0.15,
        wind_x=0.25,
        wind_y=0.10,
        color=(130, 145, 165),
        opacity_min=0.0,
        opacity_max=0.20,
    )


MAP_PROFILE_REGISTRY: dict[str, MapProfile] = {}


@dataclass(frozen=True)
class MapProfile:
    """Configuration for a map generation theme.

    Parameters
    ----------
    name : str
        Registry key (e.g. ``"cave"``).
    creature_labels : tuple[str, ...]
        Labels used to filter :data:`CREATURE_REGISTRY` during population.
    static_object_labels : tuple[str, ...]
        Labels used to filter :data:`STATIC_OBJECT_REGISTRY` during population.
    texture_patches : tuple[str, ...] or None
        Registry keys of tile type patches to apply.  ``None`` uses all entries.
    texture_overlays : tuple[str, ...] or None
        Registry keys of tile overlays to apply.  ``None`` uses all entries.
    scatter : tuple[ScatterRule, ...]
        Scatter rules applied after texture passes.
    ambient : float
        Ambient light level (0–1); passed to :class:`LightMap`.
    fog : FogParams
        Fog parameters sent to the client via the welcome message.
    """

    name: str
    generator: GeneratorConfig = field(default_factory=_default_generator)
    creature_labels: tuple[str, ...] | None = ("cave",)
    creature_count: int = 0
    creature_min_player_distance: int = 8
    static_object_labels: tuple[str, ...] | None = ("cave",)
    static_object_count: int = 0
    static_object_min_player_distance: int = 8
    floor_tile: str = "cave_floor"
    wall_tile: str = "cave_wall"
    texture_patches: tuple[str, ...] | None = None
    texture_overlays: tuple[str, ...] | None = None
    noise_texture: bool = True
    noise_scale: float = 0.06
    noise_strength: float = 0.15
    scatter: tuple[ScatterRule, ...] = field(default_factory=tuple)
    ambient: float = 0.35
    fog: FogParams = field(default_factory=_default_fog)
