"""Cave map generator — carves rooms and corridors into solid rock."""

from __future__ import annotations

import random
from dataclasses import dataclass

from faraway_realms.mapgen.base import (
    DoorCandidate,
    MapGenResult,
    Rect,
    seed_base_tile_types,
)
from faraway_realms.mapgen.generator import MapGenerator
from faraway_realms.world.map import Map
from faraway_realms.world.tile import (
    TILE_REGISTRY,
    Tile,
    cave_floor_tile,
    cave_wall_tile,
)


def _padded(rect: Rect, amount: int = 1) -> Rect:
    """Return *rect* expanded by *amount* tiles on every side."""
    return Rect(
        rect.x - amount,
        rect.y - amount,
        rect.width + 2 * amount,
        rect.height + 2 * amount,
    )


@dataclass
class CaveGenerator(MapGenerator):
    """Generates a cave map by carving rooms and corridors into solid rock.

    Rooms are rectangular, placed randomly without overlapping (with a
    1-tile rock buffer between them).  Consecutive rooms are connected by
    L-shaped corridors that are always **2 tiles wide** so the player has
    room to manoeuvre and cardinal-only movement never produces dead-end
    single-tile passages.

    Parameters
    ----------
    max_rooms : int
        Upper bound on the number of rooms to attempt.  Rooms that would
        overlap an existing room are skipped, so the actual count may be
        lower.
    room_min_size : int
        Minimum interior dimension (both width and height) of a room.
        Must be ≥ 4 to leave meaningful space for encounters.
    room_max_size : int
        Maximum interior dimension of a room.
    floor_tile_name : str
        TILE_REGISTRY key for the base floor tile.  Defaults to
        ``"cave_floor"`` with a hardcoded fallback if the key is absent.
    wall_tile_name : str
        TILE_REGISTRY key for the base wall tile.  Defaults to
        ``"cave_wall"`` with a hardcoded fallback if the key is absent.
    """

    max_rooms: int = 30
    room_min_size: int = 4
    room_max_size: int = 10
    floor_tile_name: str = "cave_floor"
    wall_tile_name: str = "cave_wall"

    def _make_floor(self) -> Tile:
        tt = TILE_REGISTRY.get(self.floor_tile_name)
        return tt.make() if tt is not None else cave_floor_tile()

    def _make_wall(self) -> Tile:
        tt = TILE_REGISTRY.get(self.wall_tile_name)
        return tt.make() if tt is not None else cave_wall_tile()

    def generate(self, width: int, height: int, rng: random.Random) -> MapGenResult:
        """Build and return a cave map.

        Parameters
        ----------
        width : int
            Map width in tiles.
        height : int
            Map height in tiles.
        rng : random.Random
            Seeded RNG used for all random choices so output is
            reproducible given the same seed.

        Returns
        -------
        MapGenResult
            The generated map, the list of carved rooms, and the
            recommended player starting position (centre of first room).
        """
        tiles = [[self._make_wall() for _ in range(width)] for _ in range(height)]
        game_map = Map(width, height, tiles)
        rooms: list[Rect] = []
        for _ in range(self.max_rooms):
            room = self._random_room(width, height, rng)
            if not any(_padded(room).intersects(r) for r in rooms):
                self._carve_room(game_map, room)
                if rooms:
                    self._connect(game_map, rooms[-1], room)
                rooms.append(room)
        start = rooms[0].center if rooms else (width // 2, height // 2)
        result = MapGenResult(map=game_map, rooms=rooms, player_start=start)
        self._fill_spawn_zones(result)
        seed_base_tile_types(result, self.floor_tile_name, self.wall_tile_name)
        return result

    def _fill_spawn_zones(self, result: MapGenResult) -> None:
        """Populate spawn_zones (one per room) and door_candidates."""
        for room in result.rooms:
            zone = [
                (x, y)
                for x in range(room.x, room.x2)
                for y in range(room.y, room.y2)
                if result.map.get_tile(x, y).walkable
            ]
            result.spawn_zones.append(zone)
        for i in range(1, len(result.rooms)):
            result.door_candidates.extend(
                _corridor_door_candidates(result.rooms[i - 1], result.rooms[i])
            )

    def _random_room(self, width: int, height: int, rng: random.Random) -> Rect:
        w = rng.randint(self.room_min_size, self.room_max_size)
        h = rng.randint(self.room_min_size, self.room_max_size)
        x = rng.randint(1, width - w - 1)
        y = rng.randint(1, height - h - 1)
        return Rect(x, y, w, h)

    def _carve_room(self, game_map: Map, room: Rect) -> None:
        for ry in range(room.y, room.y2):
            for rx in range(room.x, room.x2):
                self._carve(game_map, rx, ry)

    def _carve(self, game_map: Map, x: int, y: int) -> None:
        """Carve a single tile, leaving the map border intact."""
        if 0 < x < game_map.width - 1 and 0 < y < game_map.height - 1:
            game_map.set_tile(x, y, self._make_floor())

    def _connect(self, game_map: Map, a: Rect, b: Rect) -> None:
        """Connect two rooms with a 2-wide L-shaped corridor."""
        cx1, cy1 = a.center
        cx2, cy2 = b.center
        self._h_tunnel(game_map, cx1, cx2, cy1)
        self._v_tunnel(game_map, cy1, cy2, cx2)

    def _h_tunnel(self, game_map: Map, x1: int, x2: int, y: int) -> None:
        """Carve a 2-tile-tall horizontal passage from x1 to x2 at row y."""
        for xi in range(min(x1, x2), max(x1, x2) + 1):
            for dy in range(2):
                self._carve(game_map, xi, y + dy)

    def _v_tunnel(self, game_map: Map, y1: int, y2: int, x: int) -> None:
        """Carve a 2-tile-wide vertical passage from y1 to y2 at column x."""
        for yi in range(min(y1, y2), max(y1, y2) + 1):
            for dx in range(2):
                self._carve(game_map, x + dx, yi)


def _corridor_door_candidates(a: Rect, b: Rect) -> list[DoorCandidate]:
    """Return door candidate positions at the exits of the L-shaped corridor.

    The corridor runs horizontally from ``a.center`` then vertically to
    ``b.center``.  A door candidate is placed one tile outside each room
    at the corridor entry, oriented to span the corridor opening.
    """
    cx1, cy1 = a.center
    cx2, cy2 = b.center
    candidates: list[DoorCandidate] = []
    step_x = 1 if cx2 > cx1 else -1
    candidates.append(DoorCandidate(x=cx1 + step_x, y=cy1, horizontal=False))
    step_y = 1 if cy2 > cy1 else -1
    candidates.append(DoorCandidate(x=cx2, y=cy1 + step_y, horizontal=True))
    return candidates
