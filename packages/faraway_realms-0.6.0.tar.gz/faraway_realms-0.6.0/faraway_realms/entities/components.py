"""Component system — cross-cutting capabilities attachable to any object.

Components are frozen dataclasses stored in a ``components`` dict keyed by
a short string (e.g. ``"light_emitter"``).  Any entity, static object, or
projectile effect can carry components without requiring a dedicated field
per capability.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from faraway_realms.effects.light import LightSource

if TYPE_CHECKING:
    from faraway_realms.ai.behaviour import Behaviour


class Component:
    """Marker base class for all components."""


@dataclass(frozen=True)
class LightEmitter(LightSource, Component):
    """A LightSource that is also a Component.

    Inherits radius, intensity, color from LightSource.
    Attach to any object via obj.components["light_emitter"] = LightEmitter(...).
    Because LightEmitter IS-A LightSource, it can be passed directly to
    LightMap.compute() with no conversion.
    """


@dataclass(frozen=True)
class CombatProfile(Component):
    """Combat statistics extracted from flat entity fields.

    When present in ``entity.components["combat_profile"]``, these values
    drive melee combat behaviour.  Absence means the entity is non-combat.

    Parameters
    ----------
    attack_every : int
        Ticks between melee attacks; lower = faster.
    armor_type : str
        Material type used in incoming damage multiplier lookup.
    damage_type : str
        Damage type used in outgoing melee multiplier lookup.
    death_stat : str
        Stat key depleted to trigger death; usually ``"health"``.
    blood_color : tuple[int, int, int] | None
        Blood splat colour; ``None`` suppresses blood effects.
    """

    attack_every: int = 5
    armor_type: str = "none"
    damage_type: str = "bludgeoning"
    death_stat: str = "health"
    blood_color: tuple[int, int, int] | None = (180, 0, 0)


@dataclass(frozen=True)
class BehaviourComponent(Component):
    """Wraps a Behaviour strategy — presence signals AI-controlled.

    An entity without this component is player-controlled; commands arrive
    from the network rather than from the AI.

    Parameters
    ----------
    behaviour : Behaviour
        The concrete behaviour strategy instance.
    """

    behaviour: Behaviour
