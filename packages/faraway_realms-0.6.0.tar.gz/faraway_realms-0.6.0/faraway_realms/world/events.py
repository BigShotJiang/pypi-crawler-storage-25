"""Game events — consequences emitted during command resolution."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class EventType(StrEnum):
    """Enumeration of supported event types."""

    CONTACT = "contact"
    ENTITY_DYING = "entity_dying"
    ENTITY_DIED = "entity_died"
    TICK = "tick"
    CAST_COMPLETE = "cast_complete"
    CHANNEL_TICK = "channel_tick"
    ENTITY_HIT = "entity_hit"
    CAST_STARTED = "cast_started"
    CAST_CANCELLED = "cast_cancelled"
    STATUS_APPLIED = "status_applied"
    STUN_APPLIED = "stun_applied"
    IMMOBILIZE_APPLIED = "immobilize_applied"
    PROJECTILE_SPAWN = "projectile_spawn"
    TARGET_CHANGED = "target_changed"
    STATUS_EXPIRED = "status_expired"
    RESOURCE_CHANGED = "resource_changed"
    NPC_STATE_CHANGED = "npc_state_changed"


@dataclass(frozen=True)
class Event:
    """An immutable game event emitted as a consequence of command resolution.

    Parameters
    ----------
    event_type : EventType
        The type of event.
    source_id : int
        Entity ID that caused the event.
    target_id : int | None
        Entity ID that receives the event, if applicable.
    resolve_at_tick : int
        Tick on which this event becomes ready to process.
        ``0`` means the current tick (resolve immediately).
        Set to a future tick number for deferred events (e.g. poison, stuns).
    payload : dict[str, object] | None
        Optional extra data for the event handler (damage amount, etc.).
    """

    event_type: EventType
    source_id: int
    target_id: int | None = None
    resolve_at_tick: int = 0
    payload: dict[str, object] | None = None
