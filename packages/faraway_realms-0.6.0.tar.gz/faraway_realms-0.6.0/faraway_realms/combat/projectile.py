"""Server-side projectile state for tick-based projectile travel."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from faraway_realms.effects.light import LightSource

if TYPE_CHECKING:
    from faraway_realms.combat.abilities import ApplyStatusEffect


@dataclass
class Projectile:
    """An in-flight projectile tracked by the server each tick.

    Parameters
    ----------
    source_id : int
        Entity ID of the caster/shooter.
    target_id : int
        Entity ID of the target, locked at cast time.
    x, y : int
        Current tile position.
    target_x, target_y : int
        Current destination tile (updated each move step when homing).
    speed : float
        Tiles moved per tick. Values <1 slow the projectile (e.g. ``0.5``
        = 1 tile every 2 ticks); values >1 move multiple tiles per tick
        (e.g. ``2.0`` = 2 tiles/tick).
    base_damage : int
        Base damage before armor and type modifiers.
    damage_type : str
        Damage type string (e.g. ``"fire"``).
    on_hit_statuses : tuple[ApplyStatusEffect, ...]
        Status effects applied to the target on impact.
    color : tuple[int, int, int]
        RGB colour used for the in-flight ``*`` glyph.
    visual_type : str
        Visual category hint for the client (``"spell"``, ``"arrow"``).
    trail_length : int
        How many past positions to keep for the visual trail. ``0`` = no trail.
    trail_char : str
        Single character drawn at each trail position.
    homing : bool
        When ``True``, destination updates to follow the target entity.
    light_source : LightSource | None
        Optional light emitted while in flight.  ``None`` = no emission.
    dist_accum : float
        Fractional tile distance accumulated this tick (internal).
    trail : deque[tuple[int, int]]
        Recent past positions, newest first (populated at runtime).
    """

    source_id: int
    target_id: int
    x: int
    y: int
    target_x: int
    target_y: int
    speed: float
    base_damage: int
    damage_type: str
    on_hit_statuses: tuple[ApplyStatusEffect, ...]
    color: tuple[int, int, int]
    visual_type: str = "spell"
    trail_length: int = 0
    trail_char: str = "+"
    homing: bool = True
    light_source: LightSource | None = None
    dist_accum: float = field(default=0.0, init=False)
    trail: deque[tuple[int, int]] = field(init=False)

    def __post_init__(self) -> None:
        """Initialise the trail deque with the configured max length."""
        self.trail = deque(maxlen=self.trail_length)
