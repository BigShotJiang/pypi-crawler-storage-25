"""Inspect mode: InspectMode state and InspectPanel for the details pane."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import tcod.console

from faraway_realms.describe import describe_position
from faraway_realms.ui.panels import Panel

if TYPE_CHECKING:
    from faraway_realms.game_protocol import GameProtocol

_TEXT_COLOR = (220, 220, 220)
_DIM_COLOR = (120, 120, 120)
_HEADING_COLOR = (220, 220, 180)
_COORD_COLOR = (100, 160, 200)


@dataclass
class InspectMode:
    """Mutable state for the inspect cursor."""

    cursor_x: int
    cursor_y: int


class InspectPanel(Panel):
    """Details pane panel that shows a description of the inspect cursor position."""

    def __init__(self, game: GameProtocol, mode: InspectMode) -> None:
        self._game = game
        self._mode = mode

    @property
    def title(self) -> str:
        """Panel header label."""
        return "Inspect"

    def render(self, console: tcod.console.Console, x: int, y: int, width: int) -> int:
        """Draw inspect description at the cursor position."""
        result = describe_position(
            self._game, self._mode.cursor_x, self._mode.cursor_y, width - 1
        )
        row = y
        coord = f"({self._mode.cursor_x}, {self._mode.cursor_y})"
        console.print(x, row, coord[:width], fg=_COORD_COLOR)
        row += 2
        console.print(x, row, result.heading[: width - 1], fg=_HEADING_COLOR)
        row += 2
        for text, color in result.lines:
            if row >= console.height - 1:
                break
            console.print(x, row, text[:width], fg=color)
            row += 1
        return row - y
