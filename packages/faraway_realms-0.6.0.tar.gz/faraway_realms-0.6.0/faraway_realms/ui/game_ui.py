"""GameUI — thin coordinator that owns MapView, ChatView, StatusBar, and overlays."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import TYPE_CHECKING

import tcod.console
import tcod.context
import tcod.event
import tcod.tileset

from faraway_realms.ai import fov as _fov
from faraway_realms.effects.blood import blood_drop_positions
from faraway_realms.effects.fog import render_fog
from faraway_realms.effects.light import LightMap, animate_light_sources
from faraway_realms.settings import DisplaySettings, load_display_settings
from faraway_realms.ui.ability_bar import AbilityBar
from faraway_realms.ui.chat_view import ChatView
from faraway_realms.ui.effects import (
    BloodParticle,
    EntityHitFlash,
    MeleeAttackAnimation,
    ScreenFlash,
    TrailAnimation,
    _swing_char,
    _swing_tiles,
)
from faraway_realms.ui.inspect import InspectMode, InspectPanel
from faraway_realms.ui.layout import (
    _FRAME_DURATION,
    _INPUT_BG,
    BINDINGS,
    CHAT_HEIGHT,
    CHAT_WIDTH,
    CHAT_X,
    CHAT_Y,
    CONSOLE_HEIGHT,
    CONSOLE_WIDTH,
    DETAILS_WIDTH,
    DETAILS_X,
    DETAILS_Y,
    INPUT_Y,
    INSPECT_CURSOR_COLOR,
    MAP_HEIGHT,
    MAP_WIDTH,
    MAP_X,
    MAP_Y,
    TILE_PX,
    TILESET_CHARMAP,
    TILESET_ROWS,
)
from faraway_realms.ui.map_view import MapView
from faraway_realms.ui.mode_bar import ModeBar
from faraway_realms.ui.overlays import HelpOverlay, Overlay
from faraway_realms.ui.status_bar import NameBar, StatusBar
from faraway_realms.world.commands import CommandParser

# libtcod 2.x uses SDL3 where SDL_WINDOW_FULLSCREEN gives borderless desktop
# fullscreen by default.  0x1001 (old SDL_WINDOW_FULLSCREEN_DESKTOP) is now
# SDL_WINDOW_FULLSCREEN | SDL_WINDOW_MODAL and crashes on macOS.
#
# Table mapping DisplaySettings bool attributes → SDL window flag values.
_SDL_FLAG_MAP: tuple[tuple[str, int], ...] = (
    ("fullscreen", tcod.context.SDL_WINDOW_FULLSCREEN),
    ("allow_highdpi", tcod.context.SDL_WINDOW_ALLOW_HIGHDPI),
    ("borderless", tcod.context.SDL_WINDOW_BORDERLESS),
    ("maximized", tcod.context.SDL_WINDOW_MAXIMIZED),
    ("resizable", tcod.context.SDL_WINDOW_RESIZABLE),
)

# Maps scale_quality setting strings to SDL hint values.
_SCALE_QUALITY: dict[str, str] = {"nearest": "0", "linear": "1", "best": "2"}


if TYPE_CHECKING:
    import numpy as np

    from faraway_realms.entities.entity import GameEntity, Player
    from faraway_realms.game_protocol import GameProtocol
    from faraway_realms.ui.panels import Panel
    from faraway_realms.world.map import Map


def _sdl_flags(settings: DisplaySettings) -> int:
    """OR together all SDL window flags enabled by *settings*."""
    return sum(flag for attr, flag in _SDL_FLAG_MAP if getattr(settings, attr))


def _pixel_size(settings: DisplaySettings) -> dict[str, int]:
    """Return explicit window pixel dimensions when integer scaling is active."""
    if settings.fullscreen or settings.integer_scale <= 1:
        return {}
    return {
        "width": CONSOLE_WIDTH * TILE_PX * settings.integer_scale,
        "height": CONSOLE_HEIGHT * TILE_PX * settings.integer_scale,
    }


def _context_kwargs(settings: DisplaySettings) -> dict:
    """Build keyword arguments for tcod.context.new from display settings."""
    flags = _sdl_flags(settings)
    _wpos = [("x", settings.window_x), ("y", settings.window_y)]
    pos = {k: v for k, v in _wpos if v is not None}
    kwargs: dict = {"vsync": settings.vsync, **pos, **_pixel_size(settings)}
    if flags:
        kwargs["sdl_window_flags"] = flags
    return kwargs


class GameUI:
    """Manages the TCOD window and three-pane layout.

    Parameters
    ----------
    game : Game
        The game state to render.
    tileset_path : str | Path
        Path to the unified 12×12 tilesheet PNG (CP437 + Urizen sprites).
    viewing_player : Player
        The player this UI instance belongs to.
    panels : list[Panel] | None
        Optional list of detail-pane panels to display.
    """

    def __init__(
        self,
        game: GameProtocol,
        tileset_path: str | Path,
        viewing_player: Player,
        panels: list[Panel] | None = None,
    ) -> None:
        self._game = game
        self._tileset_path = Path(tileset_path)
        self._viewing_player = viewing_player
        self._parser = CommandParser()
        self._panels: list[Panel] = list(panels) if panels else []
        self._panel_idx: int = 0
        self._overlay: Overlay | None = None
        self._map_view = MapView(game=game, viewing_player=viewing_player)
        self._chat = ChatView(game=game)
        self._status_bar = StatusBar(game=game, viewing_player=viewing_player)
        self._name_bar = NameBar(game=game, viewing_player=viewing_player)
        self._ability_bar = AbilityBar(game=game, viewing_player=viewing_player)
        self._inspect: InspectMode | None = None
        self._inspect_panel: InspectPanel | None = None
        self._mode_bar = ModeBar()
        self._fog_params = game.fog_params
        self._light_map = LightMap(
            game.game_map.width, game.game_map.height, ambient=game.ambient
        )
        self._damage_flash = ScreenFlash()
        self._last_hit_seq: int = game.get_hit_seq(viewing_player.entity.entity_id)
        self._crit_flash = ScreenFlash(color=(255, 210, 0), peak_alpha=200)
        self._last_crit_seq: int = game.get_crit_dealt_seq(
            viewing_player.entity.entity_id
        )
        self._attack_anims: list[MeleeAttackAnimation] = []
        self._blood_particles: list[BloodParticle] = []
        self._trail_anims: list[TrailAnimation] = []
        self._last_anim_tick: int = -1
        self._last_trail_tick: int = -1
        self._hit_flashes: dict[int, EntityHitFlash] = {}
        self._prev_hit_ticks: dict[int, int] = {}
        self._ctx: tcod.context.Context  # set in run()

    def _maybe_tick(self) -> None:
        """Call tick() on the game if it supports server-side ticking."""
        if hasattr(self._game, "tick"):
            self._game.tick()  # type: ignore[union-attr]

    def run(self) -> None:
        """Open the window and enter the render/event loop."""
        settings = load_display_settings()
        # SDL reads this hint before creating the renderer; must be set early.
        os.environ["SDL_RENDER_SCALE_QUALITY"] = _SCALE_QUALITY.get(
            settings.scale_quality, "0"
        )
        tileset = tcod.tileset.load_tilesheet(
            self._tileset_path, 16, TILESET_ROWS, TILESET_CHARMAP
        )
        console = tcod.console.Console(CONSOLE_WIDTH, CONSOLE_HEIGHT, order="C")
        with tcod.context.new(
            console=console,
            tileset=tileset,
            title="Faraway Realms",
            **_context_kwargs(settings),
        ) as ctx:
            self._ctx = ctx
            last_tick = time.monotonic()
            tick_interval = 1.0 / self._game.tick_rate

            while True:
                now = time.monotonic()
                if now - last_tick >= tick_interval:
                    self._maybe_tick()
                    last_tick = now

                if not self._handle_events(ctx):
                    break

                self._render_frame(console)
                ctx.present(console)

                elapsed = time.monotonic() - now
                time.sleep(max(0.0, _FRAME_DURATION - elapsed))

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _sync_viewing_player(self) -> None:
        """Copy mutable snapshot fields back to the stub entity each frame."""
        pid = self._viewing_player.entity.entity_id
        snap_e = self._game.entity(pid)
        if snap_e is not None:
            self._viewing_player.entity.target_id = snap_e.target_id

    def _render_frame(self, console: tcod.console.Console) -> None:
        self._sync_viewing_player()
        console.clear()
        self._render_borders(console)  # first — draw_frame clears interior cells
        cam = self._map_view.camera_origin()
        visible = self._map_view.compute_fov()
        self._light_map.compute(
            animate_light_sources(self._game.light_sources(), time.time()),
            _fov.build_transparency(self._game.game_map),
        )
        self._update_hit_flashes()
        self._map_view._color_overrides = {  # noqa: SLF001
            eid: f.current_color for eid, f in self._hit_flashes.items() if f.active
        }
        self._map_view.render(console, cam, visible, self._light_map)
        render_fog(
            console,
            cam,
            MAP_X,
            MAP_Y,
            MAP_WIDTH,
            MAP_HEIGHT,
            time.time(),
            self._fog_params,
        )
        self._tick_trail_anims(console, cam, visible)
        self._tick_attack_anims(console, cam)
        self._tick_blood_particles(console, cam)
        self._tick_damage_flash(console)
        self._tick_crit_flash(console)
        if self._inspect is not None:
            self._render_inspect_cursor(console, cam)
        self._render_details(console)
        self._chat.render(console)
        self._status_bar.render(console)
        self._name_bar.render(console)
        self._ability_bar.render(console)
        self._mode_bar.render(console, self._inspect is not None, self._chat.focused)
        if self._overlay is not None:
            self._overlay.render(console)

    def _tick_damage_flash(self, console: tcod.console.Console) -> None:
        eid = self._viewing_player.entity.entity_id
        hit_seq = self._game.get_hit_seq(eid)
        if hit_seq != self._last_hit_seq:
            self._last_hit_seq = hit_seq
            self._damage_flash.trigger()
        if self._damage_flash.active:
            self._damage_flash.render(console)

    def _tick_crit_flash(self, console: tcod.console.Console) -> None:
        eid = self._viewing_player.entity.entity_id
        crit_seq = self._game.get_crit_dealt_seq(eid)
        if crit_seq != self._last_crit_seq:
            self._last_crit_seq = crit_seq
            self._crit_flash.trigger()
        if self._crit_flash.active:
            self._crit_flash.render(console)

    def _tick_attack_anims(
        self, console: tcod.console.Console, cam: tuple[int, int]
    ) -> None:
        cur_tick = self._game.abs_tick
        if cur_tick != self._last_anim_tick:
            self._last_anim_tick = cur_tick
            self._spawn_anims_for_tick()
        self._attack_anims = [a for a in self._attack_anims if a.active]
        for anim in self._attack_anims:
            anim.render(console, cam)

    def _spawn_anims_for_tick(self) -> None:
        for from_pos, to_pos, color, blood_color in self._game.melee_anim_events():
            x0, y0 = from_pos
            x1, y1 = to_pos
            char = _swing_char(x1 - x0, y1 - y0)
            self._attack_anims.append(
                MeleeAttackAnimation(
                    tiles=_swing_tiles(x0, y0, x1, y1), char=char, color=color
                )
            )
            if blood_color is not None:
                self._spawn_blood_particles(x1, y1, x0, y0, blood_color)

    def _spawn_blood_particles(
        self,
        tx: int,
        ty: int,
        ax: int,
        ay: int,
        blood_color: tuple[int, int, int],
    ) -> None:
        game_map = self._game.game_map
        for lx, ly in blood_drop_positions(tx, ty, ax, ay):
            path = self._clip_path_to_walkable(game_map, _swing_tiles(tx, ty, lx, ly))
            if path:
                self._blood_particles.append(
                    BloodParticle(path=path, color=blood_color)
                )

    @staticmethod
    def _clip_path_to_walkable(game_map: Map, path: list) -> list:
        """Truncate *path* at the first non-walkable tile (inclusive)."""
        result = []
        for pos in path:
            result.append(pos)
            if not game_map.is_walkable(*pos):
                break
        return result

    def _tick_blood_particles(
        self, console: tcod.console.Console, cam: tuple[int, int]
    ) -> None:
        self._blood_particles = [p for p in self._blood_particles if p.active]
        for particle in self._blood_particles:
            particle.render(console, cam, self._light_map)

    def _update_hit_flashes(self) -> None:
        for flash in self._hit_flashes.values():
            flash.advance()
        entities = self._game.all_npcs() + self._game.all_player_entities()
        for entity in entities:
            self._check_entity_hit(entity)

    def _check_entity_hit(self, entity: GameEntity) -> None:
        eid = entity.entity_id
        prev = self._prev_hit_ticks.get(eid, -1)
        if entity.last_hit_tick == prev or entity.last_hit_tick == 0:
            return
        self._prev_hit_ticks[eid] = entity.last_hit_tick
        if eid not in self._hit_flashes:
            self._hit_flashes[eid] = EntityHitFlash(original_color=entity.fg_color)
        flash = self._hit_flashes[eid]
        flash.original_color = entity.fg_color
        flash.trigger()

    def _tick_trail_anims(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        cur_tick = self._game.abs_tick
        if cur_tick != self._last_trail_tick:
            self._last_trail_tick = cur_tick
            self._spawn_trail_anims()
        self._trail_anims = [a for a in self._trail_anims if a.active]
        for anim in self._trail_anims:
            anim.render(console, cam, visible)

    def _spawn_trail_anims(self) -> None:
        for _eid, char, color, path in self._game.movement_trail_events():
            if path:
                self._trail_anims.append(
                    TrailAnimation(positions=list(path), char=char, color=color)
                )

    def _render_borders(self, console: tcod.console.Console) -> None:
        # Vertical divider between map/chat and details
        console.draw_frame(DETAILS_X - 1, DETAILS_Y, DETAILS_WIDTH + 1, CONSOLE_HEIGHT)
        # Horizontal divider between map and chat
        console.draw_frame(MAP_X, CHAT_Y - 1, MAP_WIDTH, CONSOLE_HEIGHT - CHAT_Y + 1)

    def _render_details(self, console: tcod.console.Console) -> None:
        x = DETAILS_X + 1
        width = DETAILS_WIDTH - 2
        if self._inspect_panel is not None:
            self._render_panel_header(console, x, 1, width, self._inspect_panel.title)
            self._inspect_panel.render(console, x, 3, width)
            return
        if not self._panels:
            return
        panel = self._panels[self._panel_idx]
        self._render_panel_header(console, x, 1, width, panel.title)
        panel.render(console, x, 3, width)
        if len(self._panels) > 1:
            hint = "(]) next panel"
            console.print(x, CONSOLE_HEIGHT - 2, hint[:width], fg=(100, 100, 100))

    def _render_panel_header(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
        title: str,
    ) -> None:
        w = width - 1
        label = f"\u2500 {title} "
        padding = "\u2500" * max(0, w - len(label))
        console.print(x, y, (label + padding)[:w], fg=(140, 140, 80))

    # ------------------------------------------------------------------
    # Compatibility shims — delegate to sub-components
    # Used by tests that access private attributes directly.
    # ------------------------------------------------------------------

    def _render_map(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._map_view._render_map(console, cam, visible)  # noqa: SLF001

    def _render_entities(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._map_view._render_entities(console, cam, visible)  # noqa: SLF001

    def _render_map_cell(
        self,
        console: tcod.console.Console,
        screen_x: int,
        screen_y: int,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._map_view._render_map_cell(  # noqa: SLF001
            console, screen_x, screen_y, cam, visible
        )

    def _render_entity(
        self,
        console: tcod.console.Console,
        entity: GameEntity,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._map_view._render_entity(console, entity, cam, visible)  # noqa: SLF001

    def _camera_origin(self) -> tuple[int, int]:
        return self._map_view.camera_origin()

    def _render_chat(self, console: tcod.console.Console) -> None:
        history = self._game.get_chat_history(last_n=CHAT_HEIGHT)
        for i, message in enumerate(history):
            console.print(
                CHAT_X + 1, CHAT_Y + i, message.text[: CHAT_WIDTH - 2], fg=message.color
            )

    def _render_input_line(self, console: tcod.console.Console) -> None:
        console.rgb[INPUT_Y, CHAT_X + 1 : CHAT_X + CHAT_WIDTH - 1]["bg"] = _INPUT_BG
        prompt = "> " + self._chat._buffer  # noqa: SLF001
        if self._chat._focused:  # noqa: SLF001
            prompt += "_"
        console.print(CHAT_X + 1, INPUT_Y, prompt[: CHAT_WIDTH - 2], fg=(255, 255, 255))

    def _render_status_bar(self, console: tcod.console.Console) -> None:
        self._status_bar.render(console)

    @property
    def _input_buffer(self) -> str:  # noqa: D401
        return self._chat._buffer  # noqa: SLF001

    @_input_buffer.setter
    def _input_buffer(self, value: str) -> None:
        self._chat._buffer = value  # noqa: SLF001

    @property
    def _chat_focused(self) -> bool:
        return self._chat._focused  # noqa: SLF001

    @_chat_focused.setter
    def _chat_focused(self, value: bool) -> None:
        self._chat._focused = value  # noqa: SLF001

    @property
    def _command_history(self) -> list[str]:
        return self._chat._history  # noqa: SLF001

    @_command_history.setter
    def _command_history(self, value: list[str]) -> None:
        self._chat._history = value  # noqa: SLF001

    @property
    def _history_idx(self) -> int:
        return self._chat._history_idx  # noqa: SLF001

    @_history_idx.setter
    def _history_idx(self, value: int) -> None:
        self._chat._history_idx = value  # noqa: SLF001

    @property
    def _history_buffer(self) -> str:
        return self._chat._history_buffer  # noqa: SLF001

    @_history_buffer.setter
    def _history_buffer(self, value: str) -> None:
        self._chat._history_buffer = value  # noqa: SLF001

    def _submit_input(self) -> None:
        text = self._chat._buffer.strip()  # noqa: SLF001
        self._game.add_chat_message(text)
        if text.startswith("/"):
            parts = text.lstrip("/").split()
            verb = parts[0].lower() if parts else ""
            if verb != "help":
                self._game.enqueue_command(self._parser.parse(text))
            self._chat.record_history(text)
        self._chat._buffer = ""  # noqa: SLF001
        self._chat._history_idx = -1  # noqa: SLF001
        self._chat._history_buffer = ""  # noqa: SLF001

    def _handle_text_input(self, event: tcod.event.TextInput) -> None:
        self._chat.handle_text_input(event)

    def _history_older(self) -> None:
        self._chat._history_older()  # noqa: SLF001

    def _history_newer(self) -> None:
        self._chat._history_newer()  # noqa: SLF001

    def _handle_history_key(self, event: tcod.event.KeyDown) -> bool:
        return self._chat.handle_history_key(event)

    def _focus_chat(self, ctx: tcod.context.Context) -> None:
        self._chat.focus(ctx)

    def _unfocus_chat(self, ctx: tcod.context.Context) -> None:
        self._chat.unfocus(ctx)

    def _handle_backspace(self) -> None:
        if self._chat.focused:
            self._chat._buffer = self._chat._buffer[:-1]  # noqa: SLF001

    def _cycle_panel(self) -> None:
        if self._panels and not self._chat.focused:
            self._panel_idx = (self._panel_idx + 1) % len(self._panels)

    def _handle_escape(self, ctx: tcod.context.Context) -> bool:
        """Close inspect mode or unfocus chat; return True if something was closed."""
        if self._inspect is not None:
            self._exit_inspect()
            return True
        if self._chat.focused:
            self._chat.unfocus(ctx)
            return True
        return False

    def _enter_inspect(self, x: int, y: int) -> None:
        self._inspect = InspectMode(cursor_x=x, cursor_y=y)
        self._inspect_panel = InspectPanel(self._game, self._inspect)

    def _exit_inspect(self) -> None:
        self._inspect = None
        self._inspect_panel = None

    def _render_inspect_cursor(
        self, console: tcod.console.Console, cam: tuple[int, int]
    ) -> None:
        if self._inspect is None:
            return
        pos = self._map_view.world_to_screen(
            self._inspect.cursor_x, self._inspect.cursor_y
        )
        if pos is None:
            return
        col, row = pos
        ch = int(console.rgb[row, col]["ch"])
        if not ch or ch == ord(" "):
            console.rgb[row, col]["ch"] = ord("+")
        console.rgb[row, col]["fg"] = INSPECT_CURSOR_COLOR

    def _handle_inspect_key(self, event: tcod.event.KeyDown) -> None:
        """Route key events while inspect mode is active."""
        if self._inspect is None:
            return
        _CURSOR_MOVES: dict[tcod.event.KeySym, tuple[int, int]] = {
            tcod.event.KeySym(ord("h")): (-1, 0),
            tcod.event.KeySym(ord("j")): (0, 1),
            tcod.event.KeySym(ord("k")): (0, -1),
            tcod.event.KeySym(ord("l")): (1, 0),
            tcod.event.KeySym.LEFT: (-1, 0),
            tcod.event.KeySym.DOWN: (0, 1),
            tcod.event.KeySym.UP: (0, -1),
            tcod.event.KeySym.RIGHT: (1, 0),
        }
        delta = _CURSOR_MOVES.get(event.sym)
        if delta is not None:
            gm = self._game.game_map
            nx = max(0, min(self._inspect.cursor_x + delta[0], gm.width - 1))
            ny = max(0, min(self._inspect.cursor_y + delta[1], gm.height - 1))
            self._inspect.cursor_x = nx
            self._inspect.cursor_y = ny

    def _handle_bound_key(self, event: tcod.event.KeyDown) -> None:
        if self._chat.focused:
            return
        if self._handle_special_key(event):
            return
        raw = BINDINGS.get(event.sym)
        if raw is None:
            return
        self._game.enqueue_command(self._parser.parse(raw))

    def _player_position(self) -> tuple[int, int]:
        eid = self._viewing_player.entity.entity_id
        try:
            return self._game.game_map.get_entity_position(eid)
        except KeyError:
            return (0, 0)

    def _handle_special_key(self, event: tcod.event.KeyDown) -> bool:
        """Handle ``?``, ``/``, and ``i`` quick-keys; return True if consumed."""
        if self._is_help_key(event):
            self._overlay = HelpOverlay()
            return True
        if event.sym == tcod.event.KeySym.SLASH:
            self._chat.focus(self._ctx)
            self._chat._buffer = "/"  # noqa: SLF001
            return True
        if event.sym == tcod.event.KeySym(ord("i")) and self._inspect is None:
            px, py = self._player_position()
            self._enter_inspect(px, py)
            return True
        return False

    @staticmethod
    def _is_help_key(event: tcod.event.KeyDown) -> bool:
        """Return True for ``?`` (SDL may report it as QUESTION or SLASH+Shift)."""
        if event.sym == tcod.event.KeySym.QUESTION:
            return True
        return event.sym == tcod.event.KeySym.SLASH and bool(
            event.mod & tcod.event.Modifier.SHIFT
        )

    def _on_return(self, ctx: tcod.context.Context) -> None:
        if not self._chat.focused:
            self._chat.focus(ctx)
        elif self._chat.buffer.strip():
            self._submit_chat(ctx)
        else:
            self._chat.unfocus(ctx)

    # ------------------------------------------------------------------
    # Event handling
    # ------------------------------------------------------------------

    def _handle_events(self, ctx: tcod.context.Context) -> bool:
        for event in tcod.event.get():
            if not self._dispatch_event(event, ctx):
                return False
        return True

    def _dispatch_event(
        self, event: tcod.event.Event, ctx: tcod.context.Context
    ) -> bool:
        if isinstance(event, tcod.event.Quit):
            return False
        if isinstance(event, tcod.event.KeyDown):
            return self._handle_keydown(event, ctx)
        if isinstance(event, tcod.event.TextInput):
            self._chat.handle_text_input(event)
        return True

    def _handle_keydown(
        self, event: tcod.event.KeyDown, ctx: tcod.context.Context
    ) -> bool:
        if self._overlay is not None:
            return self._route_to_overlay(event)
        if event.sym == tcod.event.KeySym.ESCAPE:
            self._handle_escape(ctx)
            return True  # ESC never exits the game
        if self._inspect is not None:
            self._handle_inspect_key(event)
            return True
        self._handle_normal_key(event, ctx)
        return True

    def _handle_normal_key(
        self, event: tcod.event.KeyDown, ctx: tcod.context.Context
    ) -> None:
        if event.sym == tcod.event.KeySym.RETURN:
            self._on_return(ctx)
        else:
            self._handle_other_key(event)

    def _route_to_overlay(self, event: tcod.event.KeyDown) -> bool:
        if not self._overlay.handle_key(event):  # type: ignore[union-attr]
            self._overlay = None
        return True

    def _handle_other_key(self, event: tcod.event.KeyDown) -> None:
        if event.sym == tcod.event.KeySym.BACKSPACE:
            self._handle_backspace()
        elif event.sym == tcod.event.KeySym(ord("]")) and not (
            event.mod & tcod.event.Modifier.SHIFT
        ):
            self._cycle_panel()
        else:
            self._handle_navigation_key(event)

    def _handle_navigation_key(self, event: tcod.event.KeyDown) -> None:
        if not self._chat.handle_history_key(event):
            if not self._chat.handle_scroll_key(event):
                self._handle_bound_key(event)

    def _submit_chat(self, ctx: tcod.context.Context) -> None:
        text = self._chat.submit()
        if text is None:
            self._chat.unfocus(ctx)
            return
        self._game.add_chat_message(text)
        if text.startswith("/"):
            self._chat.record_history(text)
            self._dispatch_slash_command(text)
        self._chat.unfocus(ctx)

    def _dispatch_slash_command(self, text: str) -> None:
        parts = text.lstrip("/").split()
        verb = parts[0].lower() if parts else ""
        if verb == "help":
            topic = parts[1].lower() if len(parts) > 1 else None
            self._overlay = HelpOverlay(topic=topic)
        elif verb == "inspect":
            arg = parts[1] if len(parts) > 1 else "@self"
            self._handle_inspect_command(arg)
        else:
            self._game.enqueue_command(self._parser.parse(text))

    def _handle_inspect_command(self, arg: str) -> None:
        """Resolve /inspect argument and enter inspect mode."""
        if arg == "@self":
            self._inspect_self()
        elif arg == "@target":
            self._inspect_target()
        else:
            self._inspect_coords(arg)

    def _inspect_self(self) -> None:
        x, y = self._player_position()
        self._enter_inspect(x, y)

    def _inspect_target(self) -> None:
        target_id = self._viewing_player.entity.target_id
        if target_id is None:
            self._game.add_chat_message("No target selected.", color=(160, 160, 160))
            return
        try:
            x, y = self._game.game_map.get_entity_position(target_id)
            self._enter_inspect(x, y)
        except KeyError:
            self._game.add_chat_message("Target not found.", color=(160, 160, 160))

    def _inspect_coords(self, arg: str) -> None:
        for sep in (",", ":"):
            if sep in arg:
                parts = arg.split(sep, 1)
                try:
                    self._enter_inspect(int(parts[0].strip()), int(parts[1].strip()))
                    return
                except ValueError, IndexError:
                    pass
        self._game.add_chat_message(
            "Usage: /inspect @self | @target | x,y", color=(160, 160, 160)
        )
