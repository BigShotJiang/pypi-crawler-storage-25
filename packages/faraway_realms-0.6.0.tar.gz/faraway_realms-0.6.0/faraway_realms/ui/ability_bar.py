"""Ability bar: pipe-separated 4-char slots with cooldown countdown and flashes."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import tcod.console

from faraway_realms.ui.layout import (
    _PIP_EMPTY_BG,
    _SEP_CHAR,
    _STATUS_SEP_COLOR,
    ABILITY_Y,
)

if TYPE_CHECKING:
    from faraway_realms.combat.abilities import Ability
    from faraway_realms.entities.entity import Player
    from faraway_realms.game_protocol import GameProtocol

Color = tuple[int, int, int]

_SLOT_W: int = 4  # fixed slot width: ' AB ' or ' 30 '
_USE_FLASH_FRAMES: int = 6
_READY_FLASH_FRAMES: int = 9

_CD_FILLED_BG: Color = (110, 45, 10)  # dark amber — on cooldown
_CD_EMPTY_BG: Color = (25, 25, 25)  # near-black — ready
_USE_FLASH_BG: Color = (230, 200, 40)  # bright yellow — just activated
_READY_FLASH_BG: Color = (50, 190, 50)  # bright green — cooldown expired
_CD_TEXT_COLOR: Color = (200, 200, 200)
_ABBREV_MAIN: Color = (230, 230, 230)  # first letter — prominent
_ABBREV_SUB: Color = (110, 110, 110)  # second letter — subdued


@dataclass
class AbilityBar:
    """Renders player ability slots separated by pipes.

    Each slot is 4 chars wide (`` AB `` or `` 30 ``).  When on cooldown the
    background fills from the left and drains right; the slot text shows
    remaining seconds or ``Xm`` for minute-scale cooldowns.  The abbreviation
    is shown with a highlighted first letter when the ability is ready.

    Parameters
    ----------
    game : Game
        Game state used to query cooldown fractions.
    viewing_player : Player
        The player whose abilities are displayed.
    """

    game: GameProtocol
    viewing_player: Player
    _prev_fractions: dict[str, float] = field(default_factory=dict, init=False)
    _flash_frames: dict[str, int] = field(default_factory=dict, init=False)

    def render(self, console: tcod.console.Console) -> None:
        """Draw the ability bar into *console*."""
        pid = self.viewing_player.entity.entity_id
        entity = self.game.entity(pid)
        if entity is None:
            return
        x = 0
        for i, (name, ability) in enumerate(entity.abilities.items()):
            x = self._render_slot(console, pid, x, i, name, ability)

    def _render_slot(
        self,
        console: tcod.console.Console,
        pid: int,
        x: int,
        i: int,
        name: str,
        ability: Ability | None,
    ) -> int:
        """Render one ability slot; return the next x position."""
        if ability is None:
            return x
        if i > 0:
            self._draw_sep(console, x)
            x += 1
        frac = self.game.ability_cooldown_fraction(pid, name)
        self._tick_flash(name, frac)
        abbrev = (ability.abbreviation or name[:2]).upper()
        self._draw_slot(console, x, name, abbrev, frac, ability.cooldown)
        return x + _SLOT_W

    # ------------------------------------------------------------------
    # Flash bookkeeping
    # ------------------------------------------------------------------

    def _tick_flash(self, name: str, frac: float) -> None:
        prev = self._prev_fractions.get(name, 0.0)
        self._detect_flash(name, prev, frac)
        self._prev_fractions[name] = frac
        remaining = self._flash_frames.get(name, 0)
        if remaining > 0:
            self._flash_frames[name] = remaining - 1

    def _detect_flash(self, name: str, prev: float, frac: float) -> None:
        if self._is_used(prev, frac):
            self._flash_frames[name] = _USE_FLASH_FRAMES
        elif self._is_ready(prev, frac):
            self._flash_frames[name] = _READY_FLASH_FRAMES

    def _is_used(self, prev: float, frac: float) -> bool:
        return prev == 0.0 and frac > 0.0

    def _is_ready(self, prev: float, frac: float) -> bool:
        return prev > 0.0 and frac == 0.0

    # ------------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------------

    def _draw_slot(
        self,
        console: tcod.console.Console,
        x: int,
        name: str,
        abbrev: str,
        frac: float,
        cooldown: int,
    ) -> None:
        filled_bg, empty_bg = self._slot_bg(frac, self._flash_frames.get(name, 0))
        filled_w = round(frac * _SLOT_W)
        for i in range(_SLOT_W):
            bg = filled_bg if i < filled_w else empty_bg
            console.rgb[ABILITY_Y, x + i]["bg"] = bg
        self._draw_slot_text(console, x, abbrev, frac, cooldown)

    def _draw_slot_text(
        self,
        console: tcod.console.Console,
        x: int,
        abbrev: str,
        frac: float,
        cooldown: int,
    ) -> None:
        if frac == 0.0:
            console.print(x + 1, ABILITY_Y, abbrev[0], fg=_ABBREV_MAIN)
            console.print(x + 2, ABILITY_Y, abbrev[1], fg=_ABBREV_SUB)
        else:
            text = self._time_text(frac, cooldown)
            console.print(x, ABILITY_Y, text, fg=_CD_TEXT_COLOR)

    def _time_text(self, frac: float, cooldown: int) -> str:
        secs = max(1, math.ceil(frac * cooldown / self.game.tick_rate))
        if secs >= 60:
            mins = math.ceil(secs / 60)
            return f" {mins}m " if mins < 10 else f" {mins}m"
        return f" {secs:>2} "

    def _slot_bg(self, frac: float, flash_frames: int) -> tuple[Color, Color]:
        if flash_frames > 0:
            color = _USE_FLASH_BG if frac > 0.0 else _READY_FLASH_BG
            return color, color
        return _CD_FILLED_BG, _CD_EMPTY_BG

    def _draw_sep(self, console: tcod.console.Console, x: int) -> None:
        console.rgb[ABILITY_Y, x]["ch"] = _SEP_CHAR
        console.rgb[ABILITY_Y, x]["fg"] = _STATUS_SEP_COLOR
        console.rgb[ABILITY_Y, x]["bg"] = _PIP_EMPTY_BG
