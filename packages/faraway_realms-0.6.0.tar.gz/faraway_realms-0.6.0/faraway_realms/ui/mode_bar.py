"""Mode indicator bar — one row at the bottom of the left pane, vim-style."""

from __future__ import annotations

from typing import TYPE_CHECKING

import tcod.console

from faraway_realms.ui.layout import CHAT_WIDTH, MODE_BAR_Y

if TYPE_CHECKING:
    pass

_INSPECT_COLOR: tuple[int, int, int] = (0, 200, 220)
_CHAT_COLOR: tuple[int, int, int] = (180, 180, 100)
_NORMAL_COLOR: tuple[int, int, int] = (80, 80, 80)


class ModeBar:
    """Renders a one-row mode indicator below the chat input."""

    def render(
        self,
        console: tcod.console.Console,
        inspect_active: bool,
        chat_focused: bool,
    ) -> None:
        """Draw the mode indicator row; silent in normal (non-modal) mode."""
        if inspect_active:
            text = "-- INSPECT --"
            color = _INSPECT_COLOR
        elif chat_focused:
            text = "-- CHAT --"
            color = _CHAT_COLOR
        else:
            return
        console.print(1, MODE_BAR_Y, text[: CHAT_WIDTH - 2], fg=color)
