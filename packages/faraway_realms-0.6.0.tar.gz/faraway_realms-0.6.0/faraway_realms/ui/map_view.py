"""Map pane rendering: tiles, entities, camera, FOV, and lighting."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
import tcod.console
import tcod.tileset

from faraway_realms.ai import fov as _fov
from faraway_realms.ai.fov import entity_sight
from faraway_realms.effects.light import LightMap
from faraway_realms.entities.entity import GameEntity
from faraway_realms.ui.layout import (
    _MEMORY_TINT,
    _TARGET_BLINK_COLOR,
    MAP_HEIGHT,
    MAP_WIDTH,
    MAP_X,
    MAP_Y,
    _dim,
)

if TYPE_CHECKING:
    from faraway_realms.combat.projectile import Projectile
    from faraway_realms.entities.entity import Player
    from faraway_realms.entities.static_object import StaticObject
    from faraway_realms.game_protocol import GameProtocol

_PROJECTILE_CHAR: int = tcod.tileset.CHARMAP_CP437[42]  # * — in-flight projectile


@dataclass
class MapView:
    """Renders the map pane: tiles, entities, camera, FOV.

    Parameters
    ----------
    game : Game
        The game state to render.
    viewing_player : Player
        The player whose perspective is used for camera and FOV.
    """

    game: GameProtocol
    viewing_player: Player
    _light_map: LightMap | None = field(default=None, init=False, repr=False)
    _color_overrides: dict[int, tuple[int, int, int]] = field(
        default_factory=dict, init=False, repr=False
    )

    def world_to_screen(self, x: int, y: int) -> tuple[int, int] | None:
        """Convert map coordinates to console coordinates.

        Returns ``None`` when the position falls outside the current viewport.
        """
        cam_x, cam_y = self.camera_origin()
        sx, sy = x - cam_x, y - cam_y
        if not (0 <= sx < MAP_WIDTH and 0 <= sy < MAP_HEIGHT):
            return None
        return (MAP_X + sx, MAP_Y + sy)

    def camera_origin(self) -> tuple[int, int]:
        """Return the top-left map coordinate of the viewport, centred on the player.

        Returns
        -------
        tuple[int, int]
            ``(cam_x, cam_y)`` clamped to valid map bounds.
        """
        try:
            px, py = self.game.game_map.get_entity_position(
                self.viewing_player.entity.entity_id
            )
        except KeyError:
            return (0, 0)
        game_map = self.game.game_map
        max_cx = max(0, game_map.width - MAP_WIDTH)
        max_cy = max(0, game_map.height - MAP_HEIGHT)
        cam_x = max(0, min(px - MAP_WIDTH // 2, max_cx))
        cam_y = max(0, min(py - MAP_HEIGHT // 2, max_cy))
        return (cam_x, cam_y)

    def compute_fov(self) -> np.ndarray | None:
        """Compute the player's field of view.

        Returns
        -------
        np.ndarray | None
            Boolean visibility array, or ``None`` if the player has no position.
        """
        try:
            px, py = self.game.game_map.get_entity_position(
                self.viewing_player.entity.entity_id
            )
        except KeyError:
            return None
        return _fov.compute_fov(
            self.game.game_map, px, py, entity_sight(self.viewing_player.entity)
        )

    def render(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
        light_map: LightMap | None = None,
    ) -> None:
        """Render map tiles, static objects, entities, and projectiles.

        Parameters
        ----------
        console : tcod.console.Console
            Target console.
        cam : tuple[int, int]
            Camera origin ``(cam_x, cam_y)``.
        visible : np.ndarray | None
            FOV array or ``None`` for fully-visible mode.
        light_map : LightMap | None
            Per-tile brightness values.  ``None`` renders at full brightness.
        """
        self._light_map = light_map
        self._render_map(console, cam, visible)
        self._render_static_objects(console, cam, visible)
        self._render_entities(console, cam, visible)
        self._render_projectiles(console, cam, visible)

    def _render_map(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        for screen_y in range(MAP_HEIGHT):
            for screen_x in range(MAP_WIDTH):
                self._render_map_cell(console, screen_x, screen_y, cam, visible)

    def _render_map_cell(
        self,
        console: tcod.console.Console,
        screen_x: int,
        screen_y: int,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        map_x, map_y = screen_x + cam[0], screen_y + cam[1]
        if not self._in_map_bounds(map_x, map_y):
            return
        is_vis = visible is None or bool(visible[map_y, map_x])
        if is_vis and visible is not None:
            self.viewing_player.explored.add((map_x, map_y))
        self._draw_tile_shaded(console, screen_x, screen_y, map_x, map_y, is_vis)

    def _in_map_bounds(self, map_x: int, map_y: int) -> bool:
        return (
            0 <= map_x < self.game.game_map.width
            and 0 <= map_y < self.game.game_map.height
        )

    def _tile_light_factor(
        self, x: int, y: int, is_visible: bool
    ) -> tuple[float, float, float]:
        """Return the RGB light factor for a tile position.

        Visible tiles sample the light map (neutral ambient when unlit, colour-
        tinted near a source).  Explored-but-dark tiles return ``_MEMORY_TINT``
        — darker and slightly cool so they read as memory rather than live view.

        Parameters
        ----------
        x : int
            Map x coordinate.
        y : int
            Map y coordinate.
        is_visible : bool
            Whether the tile is currently in the player's FOV.

        Returns
        -------
        tuple[float, float, float]
            Per-channel RGB brightness factors in ``[0.0, 1.0]``.
        """
        if not is_visible:
            return _MEMORY_TINT
        return self._light_map.rgb_at(x, y) if self._light_map else (1.0, 1.0, 1.0)

    def _draw_tile_shaded(
        self,
        console: tcod.console.Console,
        screen_x: int,
        screen_y: int,
        map_x: int,
        map_y: int,
        is_visible: bool,
    ) -> None:
        if not is_visible and (map_x, map_y) not in self.viewing_player.explored:
            return
        tile = self.game.game_map.get_tile(map_x, map_y)
        factor = self._tile_light_factor(map_x, map_y, is_visible)
        row, col = MAP_Y + screen_y, MAP_X + screen_x
        console.rgb[row, col]["bg"] = _dim(tile.bg_color, factor)
        console.rgb[row, col]["fg"] = _dim(tile.fg_color, factor)
        console.rgb[row, col]["ch"] = tile.char

    def _render_static_objects(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        for obj in self.game.static_objects:
            self._render_static_object(console, obj, cam, visible)

    def _render_static_object(
        self,
        console: tcod.console.Console,
        obj: StaticObject,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        if (obj.x, obj.y) not in self.viewing_player.explored:
            return
        sx, sy = obj.x - cam[0], obj.y - cam[1]
        if not (0 <= sx < MAP_WIDTH and 0 <= sy < MAP_HEIGHT):
            return
        is_vis = visible is None or bool(visible[obj.y, obj.x])
        factor = self._tile_light_factor(obj.x, obj.y, is_vis)
        console.rgb[MAP_Y + sy, MAP_X + sx]["ch"] = obj.char
        console.rgb[MAP_Y + sy, MAP_X + sx]["fg"] = _dim(obj.fg_color, factor)

    def _render_entities(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        player_entities = self.game.all_player_entities()
        npc_entities = self.game.all_npcs()
        for entity in npc_entities + player_entities:
            self._render_entity(console, entity, cam, visible)

    def _is_entity_visible(self, entity_id: int, visible: np.ndarray | None) -> bool:
        if visible is None:
            return True
        try:
            ex, ey = self.game.game_map.get_entity_position(entity_id)
        except KeyError:
            return False
        return bool(visible[ey, ex])

    def _render_entity(
        self,
        console: tcod.console.Console,
        entity: GameEntity,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        if not self._is_entity_visible(entity.entity_id, visible):
            return
        try:
            ex, ey = self.game.game_map.get_entity_position(entity.entity_id)
        except KeyError:
            return
        screen_x, screen_y = ex - cam[0], ey - cam[1]
        if not (0 <= screen_x < MAP_WIDTH and 0 <= screen_y < MAP_HEIGHT):
            return
        lit = _dim(self._entity_fg(entity), self._tile_light_factor(ex, ey, True))
        console.rgb[MAP_Y + screen_y, MAP_X + screen_x]["ch"] = entity.char
        console.rgb[MAP_Y + screen_y, MAP_X + screen_x]["fg"] = lit

    def _render_projectiles(
        self,
        console: tcod.console.Console,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        for proj in self.game.active_projectiles:
            self._render_projectile(console, proj, cam, visible)

    def _render_projectile(
        self,
        console: tcod.console.Console,
        proj: Projectile,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        self._render_projectile_trail(console, proj, cam, visible)
        if visible is not None and not bool(visible[proj.y, proj.x]):
            return
        sx, sy = proj.x - cam[0], proj.y - cam[1]
        if not (0 <= sx < MAP_WIDTH and 0 <= sy < MAP_HEIGHT):
            return
        lit = _dim(proj.color, self._tile_light_factor(proj.x, proj.y, True))
        console.rgb[MAP_Y + sy, MAP_X + sx]["ch"] = _PROJECTILE_CHAR
        console.rgb[MAP_Y + sy, MAP_X + sx]["fg"] = lit

    def _render_projectile_trail(
        self,
        console: tcod.console.Console,
        proj: Projectile,
        cam: tuple[int, int],
        visible: np.ndarray | None,
    ) -> None:
        n = len(proj.trail)
        glyph = tcod.tileset.CHARMAP_CP437[ord(proj.trail_char)]
        for i, (tx, ty) in enumerate(proj.trail):
            factor = (n - i) / n * 0.6
            self._render_trail_tile(
                console, tx, ty, cam, visible, proj.color, glyph, factor
            )

    def _render_trail_tile(
        self,
        console: tcod.console.Console,
        tx: int,
        ty: int,
        cam: tuple[int, int],
        visible: np.ndarray | None,
        color: tuple[int, int, int],
        glyph: int,
        factor: float,
    ) -> None:
        if visible is not None and not bool(visible[ty, tx]):
            return
        sx, sy = tx - cam[0], ty - cam[1]
        if not (0 <= sx < MAP_WIDTH and 0 <= sy < MAP_HEIGHT):
            return
        lr, lg, lb = self._tile_light_factor(tx, ty, True)
        console.rgb[MAP_Y + sy, MAP_X + sx]["ch"] = glyph
        console.rgb[MAP_Y + sy, MAP_X + sx]["fg"] = _dim(
            color, (factor * lr, factor * lg, factor * lb)
        )

    def _entity_fg(self, entity: GameEntity) -> tuple[int, int, int]:
        override = self._color_overrides.get(entity.entity_id)
        if override is not None:
            return override
        if self.viewing_player.entity.target_id != entity.entity_id:
            return entity.fg_color
        return _TARGET_BLINK_COLOR if time.monotonic() % 1.0 < 0.5 else entity.fg_color
