"""
pairing.py — One-time credential acquisition for PS4 and PS5.

PS4 — MIM (Man-in-the-Middle) pairing
--------------------------------------
The PlayStation App broadcasts a WAKEUP datagram containing the user's
``user-credential`` field.  We emulate a PS4 on the local network (listening
on UDP port 987) so the App sends WAKEUP to us, allowing us to intercept the
credential without needing the real device.

    cred = await pair_ps4_intercept()
    storage = JsonCredentialStorage()
    storage.save(cred)

PS5 — Remote Play OAuth + registration
---------------------------------------
Sony's Remote Play uses the SEN OAuth2 flow to obtain a PSN access token,
then registers with the physical PS5 via an encrypted local HTTP endpoint
using a PIN shown on-screen.

    cred = await pair_ps5(
        device=discovered_ps5,
        pin="01234567",
        npsso="<NPSSO cookie from account.sony.com>",
    )
    storage = JsonCredentialStorage()
    storage.save(cred)

NPSSO tokens can be obtained from the ``npsso`` cookie at
https://ca.account.sony.com/api/v1/ssocookie  (login first in a browser).
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac as hmac_mod
import json
import logging
import os
import socket
import struct
import urllib.parse

import aiohttp
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from .credentials import (
    RemotePlayCredentials,
    SecondScreenCredentials,
    extract_account_id,
    registkey_to_credential,
)
from .discovery import DiscoveredDevice
from .exceptions import PlayDirectorPairingError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# PS4 MIM pairing constants
# ---------------------------------------------------------------------------

_PS4_DISCOVERY_PORT = 987
_MIM_LISTEN_TIMEOUT = 60.0  # seconds to wait for the PS App broadcast

# ---------------------------------------------------------------------------
# PS5 OAuth / Remote Play constants  (from oauth/requester.ts)
# ---------------------------------------------------------------------------

# Remote Play Windows Client (from requester.ts)
_REMOTE_PLAY_CLIENT_ID = "ba495a24-818c-472b-b12d-ff231c1b5745"
_REMOTE_PLAY_CLIENT_SECRET = "mvaiZkRsAsI1IBkY"
_REDIRECT_URI = "https://remoteplay.dl.playstation.net/remoteplay/redirect"

# psnawp / PSN Mobile client — returns id_token (JWT) that contains accountId
# Used only for account_id extraction; Remote Play client is used for access_token.
_PSNAWP_CLIENT_ID = "09515159-7237-4370-9b40-3806e67c0891"
_PSNAWP_CLIENT_SECRET = "ucPjka5tntB2KqsP"
_PSNAWP_REDIRECT_URI = "com.scee.psxandroid.scecompcall://redirect"

# Sony migrated OAuth to ca.account.sony.com/api/authz/v3 (new endpoint)
_PSN_AUTHORIZE_BASE = "https://ca.account.sony.com/api/authz/v3/oauth/authorize"
_PSN_TOKEN_URL = "https://ca.account.sony.com/api/authz/v3/oauth/token"

# Query params for the authorize request (matches psnawp / Sony mobile client)
_PSN_AUTHORIZE_PARAMS = {
    "access_type": "offline",
    "client_id": _REMOTE_PLAY_CLIENT_ID,
    "device_base_font_size": "10",
    "device_profile": "mobile",
    "elements_visibility": "no_aclink",
    "enable_scheme_error_code": "true",
    "no_captcha": "true",
    "PlatformPrivacyWs1": "minimal",
    "redirect_uri": _REDIRECT_URI,
    "response_type": "code",
    "scope": "psn:clientapp",
    "service_entity": "urn:service-entity:psn",
    "service_logo": "ps",
    "smcid": "remoteplay",
    "support_scheme": "sneiprls",
    "ui": "pr",
}

# Remote Play registration endpoints (local to the device)
_RP_REGISTER_PORT = 9295
_RP_REGISTER_PATH_PS5 = "/sie/ps5/rp/sess/rgst"
_RP_REGISTER_PATH_PS4 = "/sie/ps4/rp/sess/rgst"

# ---------------------------------------------------------------------------
# Remote Play crypto — ported from src/remoteplay/crypto/{base,modern,keys}.ts
# ---------------------------------------------------------------------------

# Client-Type constant (same for PS4 modern and PS5)
_CLIENT_TYPE_MODERN = "dabfa2ec873de5839bee8d3f4c0239c4282c07c25c6077a2931afcf0adc0d34f"

# HMAC keys per device type
_HMAC_KEY_PS5 = bytes.fromhex("464687b349ca8ce859c5270f5d7a69d6")
_HMAC_KEY_PS4 = bytes.fromhex("20d66f5904ea7c14e557ffc52e488ac8")

# INIT_KEYS[PS5] — from keys.ts (stride-0x20 access pattern, with modulo)
_INIT_KEY_PS5 = bytes(
    [
        0x24,
        0xD8,
        0xC2,
        0x69,
        0x4C,
        0x67,
        0x78,
        0x71,
        0xEE,
        0x31,
        0xBD,
        0x2B,
        0x83,
        0xB2,
        0x1D,
        0x61,
        0xC9,
        0xA7,
        0x8E,
        0xED,
        0x9A,
        0xD3,
        0x6A,
        0x6B,
        0x5C,
        0xC8,
        0x35,
        0x79,
        0xA7,
        0x24,
        0xE2,
        0x17,
        0x06,
        0x60,
        0x2E,
        0xDF,
        0xF4,
        0xDB,
        0x27,
        0x10,
        0x55,
        0xD9,
        0xEA,
        0x16,
        0x4E,
        0x90,
        0x0C,
        0xBF,
        0x40,
        0x6F,
        0x54,
        0xA5,
        0x31,
        0x70,
        0x2D,
        0x5D,
        0x1E,
        0x27,
        0xDF,
        0x37,
        0x40,
        0xBA,
        0x9D,
        0x5D,
        0xFF,
        0xE1,
        0x05,
        0x70,
        0x80,
        0xD4,
        0xB7,
        0xC2,
        0x96,
        0x7F,
        0x2F,
        0x42,
        0xEB,
        0x5A,
        0x08,
        0xDE,
        0xC1,
        0xB5,
        0x52,
        0x15,
        0xF6,
        0xB5,
        0xF2,
        0xD9,
        0x69,
        0xA5,
        0xC7,
        0xC4,
        0x7F,
        0x46,
        0x64,
        0xA4,
        0xFD,
        0x46,
        0x98,
        0xA7,
        0xE1,
        0x2A,
        0x8E,
        0x6F,
        0xAF,
        0x65,
        0x42,
        0x28,
        0xB9,
        0xC2,
        0x6F,
        0x3E,
        0xE3,
        0xE4,
        0x4E,
        0xE4,
        0x5B,
        0x9D,
        0x60,
        0x10,
        0xB8,
        0x5A,
        0xB0,
        0x7D,
        0x04,
        0x0C,
        0x4C,
        0x24,
        0x78,
        0xBD,
        0xB8,
        0xBA,
        0xDB,
        0x8F,
        0xE3,
        0xA0,
        0x75,
        0x6D,
        0x28,
        0xC2,
        0x33,
        0x5B,
        0x32,
        0x83,
        0xDD,
        0x51,
        0xB0,
        0xA5,
        0x8D,
        0x09,
        0x66,
        0xE4,
        0x5C,
        0xB8,
        0x70,
        0x0B,
        0xE6,
        0x82,
        0x14,
        0xB6,
        0xD2,
        0xB0,
        0xC2,
        0xE0,
        0x55,
        0xF3,
        0x84,
        0xAD,
        0x9D,
        0x3A,
        0xF8,
        0x77,
        0xF5,
        0x9D,
        0x9A,
        0xA9,
        0x7D,
        0xF1,
        0x45,
        0x1B,
        0x9B,
        0x55,
        0x25,
        0xD8,
        0xC1,
        0xFF,
        0x03,
        0xA5,
        0x48,
        0x0B,
        0x1B,
        0x19,
        0x0C,
        0xBD,
        0xE0,
        0xCD,
        0x48,
        0xF3,
        0x2C,
        0x99,
        0x19,
        0xD6,
        0xB8,
        0xBB,
        0xD6,
        0x35,
        0x43,
        0x6F,
        0x71,
        0xE3,
        0xEF,
        0x3E,
        0x97,
        0xB8,
        0xE9,
        0x40,
        0xA8,
        0x47,
        0xE0,
        0xE0,
        0x01,
        0x16,
        0x9D,
        0xA7,
        0xE5,
        0x94,
        0x4B,
        0x1D,
        0xD2,
        0x80,
        0xA2,
        0x7F,
        0xF2,
        0x98,
        0x10,
        0x38,
        0x0D,
        0xB8,
        0x56,
        0xC3,
        0x7A,
        0x4B,
        0x4C,
        0x85,
        0xEC,
        0x2F,
        0x23,
        0x89,
        0xAF,
        0xD5,
        0xBA,
        0x9A,
        0xAD,
        0xB0,
        0x61,
        0x9C,
        0x51,
        0xB4,
        0x6D,
        0x02,
        0x49,
        0x26,
        0xA4,
        0x34,
        0x84,
        0x20,
        0x35,
        0x30,
        0x23,
        0x0A,
        0x47,
        0x14,
        0x32,
        0x1A,
        0x96,
        0x0E,
        0xE8,
        0x0F,
        0x96,
        0x96,
        0xD4,
        0xBA,
        0x68,
        0x3A,
        0x67,
        0x15,
        0x74,
        0xE0,
        0xD6,
        0x60,
        0x4C,
        0x68,
        0x50,
        0x73,
        0x14,
        0x2F,
        0x11,
        0x59,
        0xAC,
        0xC8,
        0x32,
        0xD1,
        0xDB,
        0x4C,
        0x8A,
        0x94,
        0x75,
        0x33,
        0x61,
        0xD1,
        0xD4,
        0xFD,
        0xAA,
        0x6A,
        0x61,
        0x68,
        0xD8,
        0xAE,
        0x31,
        0x4F,
        0xB8,
        0x07,
        0x7B,
        0x27,
        0x0F,
        0xF9,
        0x0B,
        0xB0,
        0xC2,
        0x64,
        0xB3,
        0x72,
        0xEA,
        0x8B,
        0x87,
        0x40,
        0x09,
        0xB4,
        0x82,
        0xB4,
        0xAD,
        0x76,
        0xF9,
        0x36,
        0x05,
        0x60,
        0x89,
        0xC8,
        0x20,
        0xEB,
        0xA5,
        0xF1,
        0x51,
        0x0B,
        0x27,
        0xA7,
        0xF0,
        0x76,
        0x84,
        0x96,
        0xEB,
        0xB1,
        0x2E,
        0xC2,
        0x85,
        0x28,
        0xBC,
        0x48,
        0x34,
        0xD4,
        0x01,
        0x8D,
        0x5B,
        0x25,
        0x54,
        0xE0,
        0xC4,
        0x4F,
        0xA0,
        0xFA,
        0x99,
        0x8D,
        0x6D,
        0x7A,
        0x64,
        0xB1,
        0xA9,
        0x5D,
        0xA4,
        0xF9,
        0xF5,
        0x22,
        0xEB,
        0x9A,
        0xF4,
        0xA8,
        0x7A,
        0x78,
        0x4B,
        0x7F,
        0xE2,
        0x8B,
        0x04,
        0x50,
        0x43,
        0x7D,
        0x26,
        0x2D,
        0x19,
        0x98,
        0x38,
        0x6A,
        0x4F,
        0x2D,
        0x30,
        0x15,
        0x2E,
        0x4F,
        0xCD,
        0xB9,
        0xCE,
        0x9E,
        0x8D,
        0x12,
        0xC9,
        0xFE,
        0x33,
        0x8B,
        0x84,
        0xCE,
        0x5B,
        0x40,
        0xE3,
        0x7F,
        0x72,
        0x6D,
        0x6C,
        0x8A,
        0x6A,
        0x9E,
        0x54,
        0xF1,
        0xE3,
        0x64,
        0x5D,
        0x6E,
        0x7F,
        0xAC,
        0x1A,
        0xE7,
        0xF7,
        0xFA,
        0x00,
        0x22,
        0xED,
        0x2B,
        0x23,
        0xFA,
        0x58,
        0xC5,
        0xEB,
        0x44,
        0x92,
        0x5D,
        0xCC,
        0xAA,
        0x82,
        0x9F,
        0x23,
        0xFB,
        0xA6,
        0xC9,
        0x65,
        0x2A,
        0xE0,
        0x79,
        0x12,
        0x65,
        0x2C,
        0x34,
        0xC5,
        0x23,
        0x16,
        0xC9,
        0xCC,
        0x05,
        0x30,
        0xF3,
        0x96,
        0x0B,
        0x90,
        0x67,
        0x1A,
        0xA7,
        0x69,
        0x4C,
        0x3E,
        0x43,
        0x24,
        0x9D,
        0x4E,
        0x68,
        0xBD,
        0x8B,
        0x75,
        0x6E,
        0x9D,
        0x07,
        0x6F,
        0x1A,
        0x6A,
        0xBA,
    ]
)

# AERO_KEYS[PS5] — from keys.ts (stride-0x20 access, NO modulo — array must be >=489 bytes)
_AERO_KEY_PS5 = bytes(
    [
        0x79,
        0x4D,
        0x78,
        0x30,
        0xFE,
        0x10,
        0x52,
        0x4C,
        0xA8,
        0x90,
        0x5B,
        0x9A,
        0x7E,
        0x5F,
        0xD3,
        0xE1,
        0x13,
        0xE0,
        0xF1,
        0x0F,
        0xA3,
        0xE7,
        0xBB,
        0x45,
        0x7F,
        0xDC,
        0x8E,
        0xD5,
        0xF1,
        0x04,
        0x5C,
        0x78,
        0x51,
        0xEF,
        0xF8,
        0x65,
        0x59,
        0x03,
        0x39,
        0x84,
        0x37,
        0xAE,
        0x59,
        0xDF,
        0x23,
        0xB6,
        0x60,
        0x34,
        0xE6,
        0x4B,
        0xE2,
        0xF5,
        0x4C,
        0x13,
        0xC6,
        0xDA,
        0xF9,
        0xFD,
        0xB3,
        0x65,
        0x84,
        0xD6,
        0x45,
        0xEC,
        0x2C,
        0x00,
        0xF2,
        0xED,
        0xDC,
        0xCB,
        0x93,
        0x6E,
        0x61,
        0x46,
        0xE5,
        0xD6,
        0x01,
        0x94,
        0xEE,
        0x78,
        0x85,
        0x0E,
        0x68,
        0x5E,
        0xB5,
        0x5B,
        0xCD,
        0xD3,
        0x63,
        0x41,
        0xFC,
        0x81,
        0x43,
        0x1C,
        0x6F,
        0x7C,
        0xBA,
        0xE8,
        0xBD,
        0x86,
        0x31,
        0xD5,
        0x70,
        0x7F,
        0xB5,
        0x4A,
        0x90,
        0x3E,
        0x84,
        0xE1,
        0x71,
        0xE0,
        0x02,
        0x99,
        0xF4,
        0x71,
        0xE7,
        0x02,
        0xED,
        0x36,
        0xAF,
        0xDE,
        0x56,
        0xC2,
        0x90,
        0xE0,
        0xAE,
        0xC2,
        0xF9,
        0xAF,
        0x53,
        0xC6,
        0xD8,
        0x62,
        0x16,
        0x32,
        0x27,
        0xFB,
        0x6E,
        0x9B,
        0x48,
        0xC6,
        0xEA,
        0xFF,
        0x6F,
        0x78,
        0x02,
        0x22,
        0x98,
        0x2C,
        0x1F,
        0xBF,
        0xB0,
        0x8E,
        0xA9,
        0x39,
        0xBC,
        0xDF,
        0x17,
        0xDE,
        0xD7,
        0x0E,
        0xE1,
        0x7A,
        0x01,
        0x0E,
        0xC3,
        0x87,
        0xFC,
        0xAA,
        0xE4,
        0x6B,
        0x0F,
        0x5B,
        0x0A,
        0xF1,
        0x18,
        0x19,
        0x8A,
        0xE5,
        0x2C,
        0x36,
        0x9B,
        0x40,
        0x30,
        0x99,
        0x24,
        0x94,
        0x48,
        0xD7,
        0x47,
        0xB2,
        0xAF,
        0x6B,
        0x8C,
        0x40,
        0x9E,
        0x4D,
        0x6D,
        0x34,
        0x07,
        0xC1,
        0x26,
        0x2F,
        0xBB,
        0x14,
        0xF7,
        0xBC,
        0x36,
        0x52,
        0xBD,
        0x84,
        0xFE,
        0x4A,
        0x9A,
        0xF4,
        0x8A,
        0xDB,
        0x34,
        0x89,
        0xAA,
        0xF1,
        0x0D,
        0x94,
        0x0B,
        0x92,
        0xF4,
        0x1C,
        0xE4,
        0x6C,
        0x79,
        0x2D,
        0x6E,
        0xC0,
        0x19,
        0x0A,
        0xD5,
        0x55,
        0x94,
        0x14,
        0x05,
        0x13,
        0xC2,
        0x62,
        0x23,
        0xB3,
        0xD4,
        0x26,
        0xC4,
        0x44,
        0x56,
        0x7A,
        0xCD,
        0x1C,
        0xEA,
        0xD4,
        0x74,
        0xB9,
        0x36,
        0x40,
        0x9F,
        0x08,
        0xFB,
        0x49,
        0x62,
        0x05,
        0x92,
        0x98,
        0xAD,
        0x1D,
        0x9F,
        0x8A,
        0x76,
        0x8B,
        0xD4,
        0x0F,
        0x21,
        0x40,
        0x76,
        0xB6,
        0x16,
        0x91,
        0x45,
        0x93,
        0x66,
        0xCC,
        0x12,
        0xEA,
        0x4D,
        0xF4,
        0x09,
        0xE2,
        0xAC,
        0x33,
        0xD0,
        0x6F,
        0x43,
        0x51,
        0x07,
        0x3E,
        0xD7,
        0x95,
        0x2C,
        0x1E,
        0x1F,
        0x0C,
        0x24,
        0xB3,
        0x0E,
        0x3A,
        0xEF,
        0x95,
        0xF5,
        0xEB,
        0x77,
        0xDD,
        0x20,
        0xF2,
        0x35,
        0x98,
        0xF2,
        0xAE,
        0xA9,
        0x66,
        0xE6,
        0x13,
        0xEF,
        0x5D,
        0x3A,
        0x2D,
        0x66,
        0xED,
        0xE2,
        0x1E,
        0xE9,
        0x32,
        0x4A,
        0x40,
        0xBF,
        0x37,
        0xC6,
        0x70,
        0x29,
        0xD9,
        0x8C,
        0xA1,
        0x61,
        0x4A,
        0x29,
        0x3D,
        0xC7,
        0x55,
        0x9C,
        0x94,
        0x9E,
        0xC9,
        0x11,
        0x45,
        0x10,
        0x28,
        0xA7,
        0x27,
        0xD1,
        0xD3,
        0xD0,
        0x84,
        0x79,
        0xC7,
        0xA9,
        0xB0,
        0xF6,
        0xAF,
        0x45,
        0x8C,
        0x3C,
        0xD4,
        0xDF,
        0x3B,
        0xF7,
        0x0D,
        0xA2,
        0x4F,
        0x13,
        0x97,
        0x78,
        0x27,
        0xF0,
        0x48,
        0xC0,
        0xA5,
        0xAB,
        0x83,
        0x01,
        0x05,
        0xD0,
        0x12,
        0xD7,
        0x1E,
        0x12,
        0x3A,
        0x4E,
        0x98,
        0x77,
        0xAE,
        0xBA,
        0xB1,
        0x4E,
        0xB5,
        0x3B,
        0x59,
        0xCA,
        0x6D,
        0xA5,
        0x11,
        0x80,
        0x91,
        0x9C,
        0x07,
        0x69,
        0x59,
        0x5A,
        0x53,
        0x70,
        0x7C,
        0x95,
        0x97,
        0x11,
        0x6D,
        0x66,
        0x8D,
        0xA3,
        0xBD,
        0xBB,
        0x2D,
        0xB0,
        0xBF,
        0x9B,
        0x10,
        0xCB,
        0xC7,
        0x0F,
        0x5B,
        0x7E,
        0x67,
        0xE2,
        0xB0,
        0x4B,
        0xBA,
        0x10,
        0x12,
        0xB9,
        0xBC,
        0x97,
        0xFD,
        0x48,
        0xE4,
        0x8A,
        0xC1,
        0x0F,
        0xA1,
        0x30,
        0x9D,
        0x56,
        0x20,
        0x24,
        0x1A,
        0x7D,
        0x5B,
        0xA0,
        0xB4,
        0xBE,
        0x9D,
        0x38,
        0x4F,
        0xB4,
        0x56,
        0xA8,
        0x4D,
        0x13,
        0x7C,
        0x44,
        0xE8,
        0x84,
        0x97,
        0xEB,
        0x78,
        0x2C,
        0x52,
        0x85,
        0xE4,
        0xA2,
        0xF6,
        0xF3,
        0xD9,
        0x71,
        0x9E,
        0xEE,
        0xB8,
        0x11,
        0x47,
        0xFB,
        0xA9,
        0x1B,
        0xC7,
        0x40,
        0xC6,
        0xE1,
        0x19,
        0x6D,
        0x50,
        0xA1,
        0x2A,
    ]
)

# INIT_KEYS[PS4] — from keys.ts
_INIT_KEY_PS4 = bytes(
    [
        0xBE,
        0xCE,
        0x5D,
        0xF0,
        0xC1,
        0x7D,
        0xB5,
        0xD0,
        0xCB,
        0x30,
        0x13,
        0x5D,
        0xAA,
        0x56,
        0x23,
        0xFB,
        0xC4,
        0xBC,
        0xF1,
        0x8F,
        0x38,
        0x57,
        0xFB,
        0xD4,
        0xD4,
        0x3F,
        0x26,
        0x38,
        0xB5,
        0xCE,
        0xED,
        0x6A,
        0x21,
        0xBC,
        0x38,
        0xD0,
        0x1E,
        0x68,
        0xCC,
        0x7B,
        0x45,
        0xD1,
        0xBE,
        0x42,
        0x1A,
        0x08,
        0xAA,
        0x16,
        0xFD,
        0xB0,
        0xC0,
        0xF4,
        0xDA,
        0x35,
        0xE9,
        0x12,
        0xFD,
        0x21,
        0x07,
        0x48,
        0x34,
        0xC1,
        0xFC,
        0x9F,
        0x8C,
        0xB6,
        0xCB,
        0x5D,
        0xB2,
        0x9C,
        0x84,
        0xE0,
        0x1A,
        0xFA,
        0xA0,
        0xC7,
        0xEB,
        0x3A,
        0x93,
        0xB3,
        0xB3,
        0xF1,
        0x15,
        0xAF,
        0x13,
        0xBD,
        0x21,
        0xAB,
        0xEA,
        0x5B,
        0x80,
        0x50,
        0x6B,
        0x31,
        0x1D,
        0x7C,
        0x1D,
        0x40,
        0xBA,
        0x3C,
        0x56,
        0x0E,
        0xE7,
        0x94,
        0x3A,
        0x5B,
        0xA1,
        0x40,
        0x80,
        0x74,
        0x0A,
        0xAD,
        0x28,
        0xCF,
        0x47,
        0xDF,
        0x42,
        0xA6,
        0x69,
        0xE9,
        0x5E,
        0xBB,
        0xC0,
        0xC0,
        0x0E,
        0xB2,
        0xC5,
        0x8A,
        0xEE,
        0x08,
        0x03,
        0xD2,
        0x84,
        0xE5,
        0x91,
        0x00,
        0x1D,
        0x46,
        0x06,
        0x55,
        0x09,
        0x9D,
        0x39,
        0x9F,
        0xD8,
        0xE7,
        0xFD,
        0xAD,
        0x9E,
        0x93,
        0x97,
        0xC5,
        0xEA,
        0xE7,
        0xA3,
        0x10,
        0xA7,
        0xF2,
        0xA2,
        0x93,
        0x7F,
        0x07,
        0x04,
        0xB4,
        0xEE,
        0xBB,
        0xBF,
        0x88,
        0x23,
        0x9C,
        0x6E,
        0xA7,
        0x62,
        0xB1,
        0x4B,
        0x67,
        0x1E,
        0xB8,
        0x3B,
        0x1F,
        0x64,
        0x93,
        0x5A,
        0x99,
        0xEC,
        0xDA,
        0xFD,
        0x0C,
        0x6A,
        0xB7,
        0xFE,
        0xE4,
        0x12,
        0x76,
        0x32,
        0x65,
        0xB8,
        0x41,
        0x23,
        0xD1,
        0x17,
        0x09,
        0x9C,
        0x24,
        0x2D,
        0x5C,
        0x9D,
        0x12,
        0x79,
        0xDE,
        0xA1,
        0xCE,
        0x69,
        0xAC,
        0xA4,
        0xBC,
        0x39,
        0x2F,
        0x57,
        0x38,
        0x84,
        0x61,
        0x2D,
        0x2A,
        0xE8,
        0x04,
        0xF8,
        0xD5,
        0x9D,
        0x0B,
        0xFF,
        0x7E,
        0x56,
        0x0C,
        0xEC,
        0x87,
        0x0A,
        0x1E,
        0xAB,
        0xDF,
        0x93,
        0x81,
        0x13,
        0xEE,
        0xCF,
        0x32,
        0x02,
        0x5A,
        0xBF,
        0xB0,
        0x17,
        0xB7,
        0xBA,
        0xB5,
        0x7F,
        0xF0,
        0x01,
        0x7B,
        0xE1,
        0xCB,
        0x39,
        0x7E,
        0x60,
        0x6D,
        0xA4,
        0x75,
        0x6E,
        0x29,
        0x92,
        0x45,
        0xA6,
        0x4F,
        0x74,
        0x00,
        0x86,
        0x78,
        0x73,
        0xBE,
        0xFD,
        0x3E,
        0xE0,
        0xD1,
        0x0C,
        0x6C,
        0x0B,
        0x49,
        0x09,
        0x83,
        0x6C,
        0x85,
        0x8A,
        0x1D,
        0xCB,
        0x16,
        0xCE,
        0x81,
        0x7C,
        0x49,
        0xC9,
        0x2C,
        0x63,
        0x61,
        0xDE,
        0xE2,
        0x3F,
        0x98,
        0xB2,
        0x73,
        0xF0,
        0x9A,
        0xEC,
        0x7B,
        0x7C,
        0xF1,
        0xC9,
        0xE1,
        0x7F,
        0xA5,
        0x19,
        0x8B,
        0x4B,
        0xE8,
        0x38,
        0xA4,
        0x34,
        0x7D,
        0xF4,
        0x28,
        0xFE,
        0x0D,
        0x4D,
        0x11,
        0x57,
        0x0C,
        0x95,
        0xF1,
        0xAF,
        0xD7,
        0x34,
        0x80,
        0xF4,
        0xEB,
        0x9B,
        0x50,
        0xE6,
        0x6A,
        0x5D,
        0xEA,
        0xCE,
        0x0C,
        0x85,
        0x4E,
        0xC5,
        0x5B,
        0x93,
        0x44,
        0xC4,
        0x24,
        0x98,
        0x80,
        0xFC,
        0xF7,
        0x72,
        0x9C,
        0x31,
        0x0B,
        0xEE,
        0x89,
        0x67,
        0xB3,
        0xA2,
        0x69,
        0x4F,
        0xB3,
        0x79,
        0x5A,
        0x14,
        0x02,
        0x70,
        0xED,
        0x50,
        0x13,
        0x75,
        0x00,
        0x6A,
        0xF3,
        0xC6,
        0x05,
        0x1A,
        0x00,
        0x33,
        0x34,
        0xF5,
        0xAC,
        0x9E,
        0x04,
        0xDB,
        0xC2,
        0x00,
        0xB0,
        0x1B,
        0xC4,
        0xF3,
        0x97,
        0x9D,
        0x7F,
        0xBE,
        0xB8,
        0x23,
        0x8D,
        0x99,
        0xE7,
        0xCB,
        0x74,
        0x37,
        0x4C,
        0x57,
        0xEC,
        0xD2,
        0x69,
        0x49,
        0x46,
        0x75,
        0x74,
        0xAF,
        0x51,
        0x40,
        0xA4,
        0x11,
        0x7B,
        0xB3,
        0x2F,
        0x51,
        0xDA,
        0xE2,
        0xEF,
        0x33,
        0x73,
        0x12,
        0x18,
        0x25,
        0x39,
        0x03,
        0x09,
        0xCA,
        0x49,
        0xDC,
        0x8E,
        0xF1,
        0x94,
        0xD7,
        0x80,
        0x17,
        0x9E,
        0x87,
        0x46,
        0xC1,
        0x04,
        0x78,
        0xD1,
        0xE5,
        0x3D,
        0x25,
        0x88,
        0xEC,
        0x72,
        0x3A,
        0x28,
        0x41,
        0x68,
        0x14,
        0x6E,
        0x10,
        0xE4,
        0xC9,
        0x57,
        0x75,
        0x90,
        0xFE,
        0x22,
        0x1A,
        0x63,
        0x8E,
        0xF4,
        0xB8,
        0x8D,
        0x1A,
        0x36,
        0xFD,
        0xB6,
        0xCB,
        0x72,
        0xC2,
        0x97,
        0x52,
        0x9F,
        0x91,
        0x72,
        0x1B,
        0x75,
        0x57,
        0x90,
        0x3B,
        0xFD,
        0x5A,
        0x93,
        0x8C,
        0xDB,
        0xFC,
        0xA3,
        0x03,
        0xDF,
    ]
)

# AERO_KEYS[PS4] — from keys.ts
_AERO_KEY_PS4 = bytes(
    [
        0xC8,
        0x48,
        0xC2,
        0xB4,
        0x08,
        0xEB,
        0x88,
        0xF7,
        0x5F,
        0x4A,
        0x09,
        0x2D,
        0x59,
        0x1F,
        0x09,
        0xCD,
        0x1C,
        0x18,
        0xF4,
        0x7A,
        0x28,
        0x4A,
        0x96,
        0x6D,
        0xB3,
        0x59,
        0x71,
        0x53,
        0x75,
        0x7E,
        0x82,
        0x50,
        0x57,
        0xE4,
        0x59,
        0xB3,
        0xF4,
        0x49,
        0x69,
        0x40,
        0xEB,
        0x17,
        0xC9,
        0x9F,
        0x17,
        0x97,
        0x71,
        0xAE,
        0xC9,
        0x60,
        0x7F,
        0xF8,
        0x2E,
        0x08,
        0x94,
        0xE8,
        0x43,
        0xEA,
        0xDA,
        0x6B,
        0xE5,
        0x19,
        0x59,
        0x33,
        0x1F,
        0x89,
        0xAE,
        0x47,
        0x57,
        0x7B,
        0x1C,
        0x66,
        0xFE,
        0xFF,
        0x95,
        0xBF,
        0x55,
        0x6B,
        0xD5,
        0x93,
        0x27,
        0xEA,
        0xA6,
        0x24,
        0x67,
        0x39,
        0x9F,
        0xD3,
        0x0C,
        0xAA,
        0x26,
        0x42,
        0xE7,
        0x66,
        0x4D,
        0xD8,
        0x18,
        0x75,
        0xFE,
        0x44,
        0x03,
        0x46,
        0xEE,
        0x3E,
        0xF8,
        0x3C,
        0xB7,
        0x85,
        0x97,
        0x03,
        0x07,
        0x06,
        0x92,
        0xFF,
        0x59,
        0x17,
        0x27,
        0x0B,
        0x21,
        0xF7,
        0x05,
        0x7F,
        0x69,
        0x90,
        0x0E,
        0x38,
        0x91,
        0xC6,
        0x67,
        0x23,
        0x48,
        0xBA,
        0x08,
        0x8E,
        0x57,
        0xDD,
        0x91,
        0xD0,
        0x40,
        0x47,
        0x1C,
        0x5B,
        0xBF,
        0xC8,
        0x06,
        0x3F,
        0x96,
        0xA0,
        0xDC,
        0x00,
        0xE5,
        0x9A,
        0xF5,
        0x3B,
        0x90,
        0x80,
        0x66,
        0xBB,
        0x0F,
        0x93,
        0x30,
        0x07,
        0x2B,
        0x56,
        0x45,
        0xA0,
        0x9A,
        0xB1,
        0xB0,
        0x72,
        0x0C,
        0xE4,
        0xDD,
        0x70,
        0xDD,
        0x7C,
        0x5A,
        0xBF,
        0xD4,
        0xE8,
        0x0D,
        0xCA,
        0x37,
        0xE5,
        0x0E,
        0xFD,
        0x12,
        0xEE,
        0x79,
        0x9A,
        0x5E,
        0xA7,
        0x1E,
        0x31,
        0xAF,
        0x1F,
        0x46,
        0x52,
        0xCA,
        0xF3,
        0x42,
        0x00,
        0x3D,
        0xF2,
        0x89,
        0x7C,
        0x1C,
        0x77,
        0x60,
        0xB7,
        0x4A,
        0x80,
        0x76,
        0x47,
        0x4B,
        0x3F,
        0xB6,
        0x91,
        0x2F,
        0x9C,
        0xC2,
        0xF1,
        0xAD,
        0x44,
        0x29,
        0xCB,
        0x32,
        0x8C,
        0x0A,
        0x8D,
        0x05,
        0x75,
        0x46,
        0xA1,
        0xF8,
        0xDA,
        0x1A,
        0xA7,
        0x20,
        0xDE,
        0x32,
        0x59,
        0xFE,
        0x70,
        0xB5,
        0x87,
        0xF3,
        0x92,
        0xFD,
        0xB4,
        0xDF,
        0xF4,
        0xA6,
        0xE3,
        0x7D,
        0x98,
        0x3B,
        0xE1,
        0xBA,
        0x18,
        0xDB,
        0x61,
        0xD1,
        0xC2,
        0xA6,
        0xEE,
        0x08,
        0x25,
        0xFA,
        0x86,
        0x8A,
        0x7B,
        0xFE,
        0xBC,
        0x02,
        0xBD,
        0x22,
        0x5F,
        0x25,
        0x30,
        0x51,
        0x5D,
        0x28,
        0x36,
        0x5A,
        0x29,
        0x8E,
        0x52,
        0xEB,
        0x49,
        0x14,
        0x28,
        0x7F,
        0x0A,
        0xC4,
        0x69,
        0x25,
        0x85,
        0x6B,
        0xEC,
        0x33,
        0x33,
        0x57,
        0xAB,
        0x50,
        0x13,
        0xCF,
        0xE7,
        0x73,
        0x78,
        0x23,
        0x06,
        0x4D,
        0x1F,
        0xBB,
        0x38,
        0x11,
        0xB1,
        0x6E,
        0x6C,
        0x6F,
        0xCD,
        0x4B,
        0x0E,
        0x42,
        0x85,
        0x80,
        0xBB,
        0xA8,
        0x39,
        0x68,
        0xC9,
        0x5B,
        0xBB,
        0x46,
        0x58,
        0x86,
        0x88,
        0x57,
        0x88,
        0x5E,
        0xEA,
        0x7C,
        0x37,
        0xDF,
        0xFD,
        0x02,
        0x39,
        0x45,
        0x89,
        0x2E,
        0xF2,
        0xE4,
        0xF0,
        0x08,
        0xC0,
        0xB6,
        0xEB,
        0x9C,
        0x6E,
        0x7A,
        0x81,
        0xA3,
        0x26,
        0x46,
        0xFE,
        0xE1,
        0x70,
        0x3C,
        0x3E,
        0x11,
        0x7A,
        0x32,
        0xCE,
        0x45,
        0x02,
        0x7D,
        0x32,
        0xCD,
        0x08,
        0x07,
        0x06,
        0xA3,
        0xA8,
        0xF7,
        0x34,
        0xFE,
        0xEE,
        0x06,
        0xB0,
        0x14,
        0xD6,
        0x6B,
        0x2D,
        0x2E,
        0x01,
        0xAF,
        0x77,
        0x11,
        0xEC,
        0x1F,
        0x31,
        0x38,
        0x17,
        0x9C,
        0xD0,
        0xE0,
        0xC5,
        0x4D,
        0xA4,
        0xD6,
        0xAD,
        0xB9,
        0xE6,
        0xE1,
        0xE3,
        0xE2,
        0x9E,
        0x44,
        0x91,
        0x9A,
        0x5E,
        0x26,
        0xCA,
        0xCC,
        0xDA,
        0x4D,
        0xD7,
        0x78,
        0x6A,
        0x75,
        0xA6,
        0x19,
        0xAD,
        0xCC,
        0x62,
        0xC7,
        0xB6,
        0x0D,
        0x14,
        0xB1,
        0xBE,
        0xEB,
        0xCB,
        0x10,
        0xCF,
        0xA9,
        0xEE,
        0xE2,
        0x42,
        0x08,
        0x35,
        0x8A,
        0x5C,
        0xBC,
        0xF1,
        0x49,
        0xFE,
        0x64,
        0x78,
        0x03,
        0x49,
        0x0C,
        0x85,
        0xF0,
        0xE4,
        0x77,
        0x26,
        0xD2,
        0x5E,
        0xF5,
        0xC1,
        0x3B,
        0x3D,
        0x2D,
        0xCC,
        0xCF,
        0x2A,
        0xAC,
        0xED,
        0x88,
        0x52,
        0x74,
        0x6D,
        0xBF,
        0xB2,
        0xB9,
        0xF7,
        0x58,
        0x51,
        0x1C,
        0x50,
        0xF6,
        0x3D,
        0xF2,
        0xC4,
        0x47,
        0x0A,
        0x21,
        0x30,
        0x47,
        0x81,
        0x2D,
        0xE4,
        0x75,
        0x0D,
        0x8F,
        0x2D,
        0x22,
        0xB0,
        0x63,
        0x27,
    ]
)

_NONCE_LENGTH = 16
_PADDING_BYTES = 480
_AEROPAUSE_PART1_DST = 0xC7
_AEROPAUSE_PART2_DST = 0x191


def _generate_iv_ps5(nonce: bytes, counter: int) -> bytes:
    """Generate AES-CFB IV using HMAC-SHA256 truncated to 16 bytes (PS5)."""
    counter_bytes = struct.pack(">Q", counter)
    mac = hmac_mod.new(_HMAC_KEY_PS5, digestmod=hashlib.sha256)
    mac.update(nonce)
    mac.update(counter_bytes)
    return mac.digest()[:_NONCE_LENGTH]


def _generate_iv_ps4(nonce: bytes, counter: int) -> bytes:
    """Generate AES-CFB IV using HMAC-SHA256 truncated to 16 bytes (PS4 modern)."""
    counter_bytes = struct.pack(">Q", counter)
    mac = hmac_mod.new(_HMAC_KEY_PS4, digestmod=hashlib.sha256)
    mac.update(nonce)
    mac.update(counter_bytes)
    return mac.digest()[:_NONCE_LENGTH]


def _generate_seed_ps5(pin: int, init_key_off: int) -> bytes:
    """Generate 16-byte AES key seed from PIN + INIT_KEY offset (PS5 modern)."""
    seed = bytearray(_NONCE_LENGTH)
    for i in range(_NONCE_LENGTH):
        idx = (i * 0x20 + init_key_off) % len(_INIT_KEY_PS5)
        seed[i] = _INIT_KEY_PS5[idx]
    seed[0xC] ^= (pin >> 0x18) & 0xFF
    seed[0xD] ^= (pin >> 0x10) & 0xFF
    seed[0xE] ^= (pin >> 0x08) & 0xFF
    seed[0xF] ^= (pin >> 0x00) & 0xFF
    return bytes(seed)


def _generate_seed_ps4(pin: int, init_key_off: int) -> bytes:
    """Generate 16-byte AES key seed from PIN + INIT_KEY offset (PS4 modern)."""
    seed = bytearray(_NONCE_LENGTH)
    for i in range(_NONCE_LENGTH):
        idx = (i * 0x20 + init_key_off) % len(_INIT_KEY_PS4)
        seed[i] = _INIT_KEY_PS4[idx]
    seed[0xC] ^= (pin >> 0x18) & 0xFF
    seed[0xD] ^= (pin >> 0x10) & 0xFF
    seed[0xE] ^= (pin >> 0x08) & 0xFF
    seed[0xF] ^= (pin >> 0x00) & 0xFF
    return bytes(seed)


def _generate_aeropause_ps5(nonce: bytes, padding: bytearray) -> bytes:
    """Generate 16-byte aeropause value used to sign padding (PS5)."""
    aero_key_off = padding[0] >> 3
    wurzelbert = (-0x2D) & 0xFF  # PS5 branch = 0xd3
    aeropause = bytearray(_NONCE_LENGTH)
    for i in range(_NONCE_LENGTH):
        k = _AERO_KEY_PS5[i * 0x20 + aero_key_off]
        v = (nonce[i] ^ k) + wurzelbert + i
        aeropause[i] = v & 0xFF
    return bytes(aeropause)


def _generate_aeropause_ps4(nonce: bytes, padding: bytearray) -> bytes:
    """Generate 16-byte aeropause value used to sign padding (PS4 modern)."""
    aero_key_off = padding[0] >> 3
    wurzelbert = 0x29  # PS4 branch
    aeropause = bytearray(_NONCE_LENGTH)
    for i in range(_NONCE_LENGTH):
        k = _AERO_KEY_PS4[i * 0x20 + aero_key_off]
        v = (nonce[i] ^ k) + wurzelbert + i
        aeropause[i] = v & 0xFF
    return bytes(aeropause)


class _AesCfbCodec:
    """Stateful AES-128-CFB streaming codec — mirrors crypto-codec.ts."""

    def __init__(self, iv: bytes, key: bytes) -> None:
        cipher = Cipher(algorithms.AES(key), modes.CFB(iv))
        self._enc = cipher.encryptor()
        self._dec = cipher.decryptor()

    def encode(self, data: bytes) -> bytes:
        return self._enc.update(data)

    def decode(self, data: bytes) -> bytes:
        return self._dec.update(data)


class _RemotePlayCrypto:
    """
    Mirrors RemotePlayCrypto from src/remoteplay/crypto.ts.

    Generates a codec + preface for a given nonce and PIN.
    Holds a single cipher instance — encode and decode share state so they
    must each be called exactly once (once for the outgoing payload, once
    for the incoming response).

    Pass ``ps4=True`` to use PS4 modern crypto (firmware ≥ 8.0).
    """

    def __init__(self, nonce: bytes, pin_str: str, *, ps4: bool = False) -> None:
        if len(nonce) != _NONCE_LENGTH:
            raise ValueError(f"nonce must be {_NONCE_LENGTH} bytes, got {len(nonce)}")

        pin_number = int(pin_str, 10)
        preface = bytearray(b"A" * _PADDING_BYTES)

        if ps4:
            iv = _generate_iv_ps4(nonce, 0)
            init_key_off = preface[0x18D] & 0x1F
            seed = _generate_seed_ps4(pin_number, init_key_off)
            aeropause = _generate_aeropause_ps4(nonce, preface)
        else:
            iv = _generate_iv_ps5(nonce, 0)
            init_key_off = preface[0x18D] & 0x1F
            seed = _generate_seed_ps5(pin_number, init_key_off)
            aeropause = _generate_aeropause_ps5(nonce, preface)

        preface[_AEROPAUSE_PART1_DST : _AEROPAUSE_PART1_DST + 8] = aeropause[8:16]
        preface[_AEROPAUSE_PART2_DST : _AEROPAUSE_PART2_DST + 8] = aeropause[0:8]

        self._preface = bytes(preface)
        self._codec = _AesCfbCodec(iv, seed)

    def create_signed_payload(self, record: dict[str, str]) -> bytes:
        """Format, encrypt and prepend preface."""
        formatted = ""
        for k, v in record.items():
            formatted += f"{k}: {v}\r\n"
        payload_bytes = formatted.encode("utf-8")
        encoded = self._codec.encode(payload_bytes)
        return self._preface + encoded

    def decrypt_response(self, data: bytes) -> bytes:
        """Decrypt the registration response body."""
        return self._codec.decode(data)


def _parse_registration_body(body: bytes) -> dict[str, str]:
    """Parse decrypted registration response (CRLF-delimited key: value lines)."""
    result: dict[str, str] = {}
    text = body.decode("utf-8", errors="replace")
    for line in text.split("\r\n"):
        if ":" in line:
            k, _, v = line.partition(":")
            result[k.strip()] = v.strip()
    return result


# ---------------------------------------------------------------------------
# PS4 MIM pairing
# ---------------------------------------------------------------------------


class _MimProtocol(asyncio.DatagramProtocol):
    """UDP protocol that intercepts PS App WAKEUP broadcasts."""

    def __init__(self, result_future: asyncio.Future[tuple[str, str]]) -> None:
        self._future = result_future
        self._transport: asyncio.DatagramTransport | None = None

    def connection_made(self, transport: asyncio.DatagramTransport) -> None:  # type: ignore[override]
        self._transport = transport
        logger.info(
            "MIM listener ready on UDP port %d — open the PlayStation App and select your PS4.",
            _PS4_DISCOVERY_PORT,
        )

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        text = data.decode("utf-8", errors="replace")
        logger.debug("MIM received from %s: %s", addr[0], text[:200])
        if not text.startswith("WAKEUP"):
            return
        headers = _parse_ddp_headers(text)
        credential = headers.get("user-credential", "")
        if not credential:
            return
        if not self._future.done():
            self._future.set_result((credential, credential))
            if self._transport:
                self._transport.close()

    def error_received(self, exc: Exception) -> None:
        logger.warning("MIM protocol error: %s", exc)

    def connection_lost(self, exc: Exception | None) -> None:
        if exc and not self._future.done():
            self._future.set_exception(exc)


def _parse_ddp_headers(text: str) -> dict[str, str]:
    """Parse DDP-style headers into a dict."""
    headers: dict[str, str] = {}
    for line in text.splitlines()[1:]:
        line = line.strip()
        if ":" in line:
            k, _, v = line.partition(":")
            headers[k.strip().lower()] = v.strip()
    return headers


async def pair_ps4_intercept(
    *,
    timeout: float = _MIM_LISTEN_TIMEOUT,
    device_id: str = "ps4-mim",
    label: str | None = None,
) -> SecondScreenCredentials:
    """
    Intercept PS4 credentials from the PlayStation App via MIM.

    Prerequisites: This machine and the phone must be on the same LAN.
    UDP port 987 must be free. The PS4 must be in standby.

    Raises asyncio.TimeoutError if no WAKEUP is received within *timeout* seconds.
    """
    loop = asyncio.get_running_loop()
    future: asyncio.Future[tuple[str, str]] = loop.create_future()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setblocking(False)
    sock.bind(("", _PS4_DISCOVERY_PORT))

    transport, _ = await loop.create_datagram_endpoint(
        lambda: _MimProtocol(future),
        sock=sock,
    )
    try:
        raw_credential, registration_key = await asyncio.wait_for(future, timeout=timeout)
    finally:
        transport.close()

    logger.info("PS4 credential intercepted: %s...", raw_credential[:8])
    return SecondScreenCredentials(
        device_id=device_id,
        credential=raw_credential,
        account_id="",
        registration_key=registration_key,
        label=label,
    )


# ---------------------------------------------------------------------------
# PS5 OAuth token exchange
# ---------------------------------------------------------------------------


async def _exchange_npsso_for_tokens(
    npsso: str,
    session: aiohttp.ClientSession,
) -> tuple[str, str]:
    """
    Exchange NPSSO cookie for (access_token, account_id_base64).

    Two separate authorize calls are made with the same NPSSO:
      A. Remote Play client  → access_token (stored in credentials, used for re-pairing)
      B. psnawp mobile client → id_token (JWT) → accountId (needed for registration payload)

    Both clients hit ca.account.sony.com/api/authz/v3/oauth/authorize with the same
    NPSSO cookie and each return a direct 302 to their respective redirect_uri?code=.
    """
    _authorize_headers = {
        "Cookie": f"npsso={npsso}",
        "X-Requested-With": "com.scee.psxandroid",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-site",
    }

    # ── Step 1A: Remote Play client authorize → access_token ────────────────
    logger.info("OAuth step 1: getting Remote Play code...")
    async with session.get(
        _PSN_AUTHORIZE_BASE,
        params=_PSN_AUTHORIZE_PARAMS,
        headers=_authorize_headers,
        allow_redirects=False,
    ) as resp:
        location = resp.headers.get("Location", "")
        if resp.status not in (301, 302, 303, 307, 308) or not location.startswith(_REDIRECT_URI):
            raise PairingError(
                f"OAuth authorization failed (status {resp.status}). "
                "Check that your NPSSO token is valid and has not expired.\n"
                f"Redirect location: {location[:300]}"
            )
        rp_code = urllib.parse.parse_qs(urllib.parse.urlparse(location).query).get("code", [""])[0]
        if not rp_code:
            raise PairingError(f"No 'code' in Remote Play redirect. Location: {location[:300]}")

    logger.info("OAuth step 2: exchanging Remote Play code for access_token...")
    async with session.post(
        _PSN_TOKEN_URL,
        data={
            "code": rp_code,
            "grant_type": "authorization_code",
            "redirect_uri": _REDIRECT_URI,
        },
        auth=aiohttp.BasicAuth(_REMOTE_PLAY_CLIENT_ID, _REMOTE_PLAY_CLIENT_SECRET),
    ) as resp:
        if resp.status != 200:
            body = await resp.text()
            raise PairingError(
                f"Remote Play token exchange failed (status {resp.status}): {body[:300]}"
            )
        rp_token_data = await resp.json(content_type=None)

    access_token: str = rp_token_data.get("access_token", "")
    if not access_token:
        raise PairingError(
            f"Did not receive an access_token from PSN. Response keys: {list(rp_token_data.keys())}"
        )

    # ── Step 1B: psnawp mobile client authorize → id_token → accountId ──────
    # The Remote Play client does not support token_format=jwt so cannot return
    # an id_token.  The psnawp/mobile client does, and its id_token payload
    # contains the numeric 'sub' claim which is the PSN account ID.
    logger.info("OAuth step 3: getting psnawp code for account_id...")
    psnawp_params = {
        "access_type": "offline",
        "cid": "00000000-0000-0000-0000-000000000000",
        "client_id": _PSNAWP_CLIENT_ID,
        "device_base_font_size": "10",
        "device_profile": "mobile",
        "elements_visibility": "no_aclink",
        "enable_scheme_error_code": "true",
        "no_captcha": "true",
        "PlatformPrivacyWs1": "minimal",
        "redirect_uri": _PSNAWP_REDIRECT_URI,
        "response_type": "code",
        "scope": "psn:mobile.v2.core psn:clientapp",
        "service_entity": "urn:service-entity:psn",
        "service_logo": "ps",
        "smcid": "psapp:signin",
        "support_scheme": "sneiprls",
        "turnOnTrustedBrowser": "true",
        "ui": "pr",
    }
    async with session.get(
        _PSN_AUTHORIZE_BASE,
        params=psnawp_params,
        headers=_authorize_headers,
        allow_redirects=False,
    ) as resp:
        location = resp.headers.get("Location", "")
        if resp.status not in (301, 302, 303, 307, 308) or not location.startswith(
            _PSNAWP_REDIRECT_URI
        ):
            raise PairingError(
                f"psnawp OAuth authorization failed (status {resp.status}).\n"
                f"Redirect location: {location[:300]}"
            )
        psnawp_code = urllib.parse.parse_qs(urllib.parse.urlparse(location).query).get(
            "code", [""]
        )[0]
        if not psnawp_code:
            raise PairingError(f"No 'code' in psnawp redirect. Location: {location[:300]}")

    logger.info("OAuth step 4: exchanging psnawp code for id_token...")
    async with session.post(
        _PSN_TOKEN_URL,
        data={
            "cid": "00000000-0000-0000-0000-000000000000",
            "code": psnawp_code,
            "grant_type": "authorization_code",
            "redirect_uri": _PSNAWP_REDIRECT_URI,
            "scope": "psn:mobile.v2.core psn:clientapp",
            "token_format": "jwt",
        },
        auth=aiohttp.BasicAuth(_PSNAWP_CLIENT_ID, _PSNAWP_CLIENT_SECRET),
    ) as resp:
        if resp.status != 200:
            body = await resp.text()
            raise PairingError(f"psnawp token exchange failed (status {resp.status}): {body[:300]}")
        psnawp_token_data = await resp.json(content_type=None)

    id_token: str = psnawp_token_data.get("id_token", "")
    if not id_token:
        raise PairingError(
            "psnawp token response did not include an id_token. "
            f"Response keys: {list(psnawp_token_data.keys())}"
        )

    # Decode JWT payload (no signature verification needed — we just need the sub claim)
    logger.info("OAuth step 5: extracting account_id from id_token...")
    try:
        payload_b64 = id_token.split(".")[1]
        payload_b64 += "=" * (4 - len(payload_b64) % 4)
        jwt_claims = json.loads(base64.b64decode(payload_b64).decode("utf-8"))
    except Exception as exc:
        raise PairingError(f"Failed to decode id_token JWT payload: {exc}") from exc

    user_id_str: str = str(jwt_claims.get("sub", "") or jwt_claims.get("accountId", ""))
    if not user_id_str:
        raise PairingError(
            "id_token JWT payload missing 'sub'/'accountId' claim. "
            f"Claims present: {list(jwt_claims.keys())}"
        )

    user_id_int = int(user_id_str)
    account_id_b64 = extract_account_id(user_id_int)
    logger.info("PSN user_id=%s → account_id_b64=%s", user_id_str, account_id_b64)

    return access_token, account_id_b64


# ---------------------------------------------------------------------------
# PS4 device registration (latest firmware — RemotePlayVersion.PS4_10)
# ---------------------------------------------------------------------------


async def _search_for_ps4(device_ip: str, timeout: float = 15.0) -> None:
    """
    UDP SRC2/RES2 handshake — signals PS4 (firmware ≥ 8.0) that registration
    is about to start.  Required; without it the PS4 rejects the registration.
    """
    loop = asyncio.get_running_loop()
    found_event = asyncio.Event()

    class _SearchProtocol(asyncio.DatagramProtocol):
        def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
            text = data.decode("utf-8", errors="replace")
            logger.debug("PS4 search RX from %s: %s", addr[0], text[:80])
            if text.startswith("RES2"):
                found_event.set()

        def error_received(self, exc: Exception) -> None:
            logger.debug("PS4 search protocol error: %s", exc)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(False)
    try:
        sock.bind(("", _RP_REGISTER_PORT))
    except OSError as e:
        logger.warning(
            "Could not bind port %d for SRC2 search: %s — using ephemeral port",
            _RP_REGISTER_PORT,
            e,
        )
        sock.close()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setblocking(False)
        sock.bind(("", 0))

    transport, _ = await loop.create_datagram_endpoint(_SearchProtocol, sock=sock)
    try:
        logger.debug("Sending SRC2 to %s:%d", device_ip, _RP_REGISTER_PORT)
        transport.sendto(b"SRC2", (device_ip, _RP_REGISTER_PORT))
        try:
            await asyncio.wait_for(found_event.wait(), timeout=timeout)
            logger.debug("Received RES2 from PS4")
        except TimeoutError:
            logger.warning("No RES2 response within %.1fs — proceeding anyway", timeout)
        await asyncio.sleep(0.1)
    finally:
        transport.close()


async def _register_with_ps4(
    device: DiscoveredDevice,
    pin: str,
    account_id_b64: str,
    session: aiohttp.ClientSession,
) -> dict[str, str]:
    """
    Encrypted registration POST to a PS4 (firmware ≥ 8.0).

    Same structure as PS5 but uses PS4 crypto, RP-Version 10.0, and the
    /sie/ps4/rp/sess/rgst endpoint.
    """
    # 1. Prime the PS4 with SRC2 UDP search
    logger.info("Sending SRC2 to prime PS4 for registration...")
    await _search_for_ps4(device.ip)

    # 2. Build encrypted payload (PS4 modern crypto)
    nonce = os.urandom(_NONCE_LENGTH)
    crypto = _RemotePlayCrypto(nonce, pin, ps4=True)
    payload = crypto.create_signed_payload(
        {
            "Client-Type": _CLIENT_TYPE_MODERN,
            "Np-AccountId": account_id_b64,
        }
    )

    # 3. POST to registration endpoint
    url = f"http://{device.ip}:{_RP_REGISTER_PORT}{_RP_REGISTER_PATH_PS4}"
    headers = {
        "RP-Version": "10.0",
        "User-Agent": "remoteplay Windows",
        "Content-Length": str(len(payload)),
    }
    logger.info("POSTing %d-byte payload to %s", len(payload), url)

    async with session.post(url, data=payload, headers=headers) as resp:
        body = await resp.read()
        if resp.status >= 300:
            reason = resp.headers.get("rp-application-reason", "")
            _RP_ERRORS = {
                "80108b09": "Invalid PIN",
                "80108b02": "Invalid PSN ID",
                "80108b10": "In use",
                "80108b15": "Crash",
                "80108b11": "RP version mismatch",
                "80108bff": "Unknown",
            }
            detail = _RP_ERRORS.get(reason, reason)
            raise PairingError(
                f"PS4 registration HTTP {resp.status}" + (f" ({detail})" if detail else "")
            )

    # 4. Decrypt and parse response
    decrypted = crypto.decrypt_response(body)
    logger.debug("Raw decrypted PS4 registration response: %r", decrypted)
    registration = _parse_registration_body(decrypted)
    logger.debug("PS4 registration keys received: %s", list(registration.keys()))

    rp_key = registration.get("RP-Key", "")
    if not rp_key:
        raise PairingError(f"RP-Key missing from PS4 registration response. Got: {registration!r}")

    return registration


# ---------------------------------------------------------------------------
# PS5 device registration
# ---------------------------------------------------------------------------


async def _search_for_ps5(device_ip: str, timeout: float = 15.0) -> None:
    """
    UDP SRC3/RES3 handshake — signals PS5 that registration is about to start.
    Required; without it the PS5 rejects the registration HTTP POST.
    """
    loop = asyncio.get_running_loop()
    found_event = asyncio.Event()

    class _SearchProtocol(asyncio.DatagramProtocol):
        def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
            text = data.decode("utf-8", errors="replace")
            logger.debug("Search RX from %s: %s", addr[0], text[:80])
            if text.startswith("RES3"):
                found_event.set()

        def error_received(self, exc: Exception) -> None:
            logger.debug("Search protocol error: %s", exc)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(False)
    try:
        sock.bind(("", _RP_REGISTER_PORT))
    except OSError as e:
        logger.warning(
            "Could not bind port %d for SRC3 search: %s — using ephemeral port",
            _RP_REGISTER_PORT,
            e,
        )
        sock.close()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setblocking(False)
        sock.bind(("", 0))

    transport, _ = await loop.create_datagram_endpoint(_SearchProtocol, sock=sock)
    try:
        logger.debug("Sending SRC3 to %s:%d", device_ip, _RP_REGISTER_PORT)
        transport.sendto(b"SRC3", (device_ip, _RP_REGISTER_PORT))
        try:
            await asyncio.wait_for(found_event.wait(), timeout=timeout)
            logger.debug("Received RES3 from PS5")
        except TimeoutError:
            logger.warning("No RES3 response within %.1fs — proceeding anyway", timeout)
        await asyncio.sleep(0.1)
    finally:
        transport.close()


async def _register_with_ps5(
    device: DiscoveredDevice,
    pin: str,
    account_id_b64: str,
    session: aiohttp.ClientSession,
) -> dict[str, str]:
    """
    Encrypted registration POST to the PS5.

    Mirrors RemotePlayRegistration.register() from registration.ts.
    Returns the parsed IDeviceRegistration dict with PS5-RegistKey, RP-Key, etc.
    """
    # 1. Prime the PS5 with SRC3 UDP search
    logger.info("Sending SRC3 to prime PS5 for registration...")
    await _search_for_ps5(device.ip)

    # 2. Build encrypted payload
    nonce = os.urandom(_NONCE_LENGTH)
    crypto = _RemotePlayCrypto(nonce, pin)
    payload = crypto.create_signed_payload(
        {
            "Client-Type": _CLIENT_TYPE_MODERN,
            "Np-AccountId": account_id_b64,
        }
    )

    # 3. POST to registration endpoint
    url = f"http://{device.ip}:{_RP_REGISTER_PORT}{_RP_REGISTER_PATH_PS5}"
    headers = {
        "RP-Version": "1.0",
        "User-Agent": "remoteplay Windows",
        "Content-Length": str(len(payload)),
    }
    logger.info("POSTing %d-byte payload to %s", len(payload), url)

    async with session.post(url, data=payload, headers=headers) as resp:
        body = await resp.read()
        if resp.status >= 300:
            reason = resp.headers.get("rp-application-reason", "")
            _RP_ERRORS = {
                "80108b09": "Invalid PIN",
                "80108b02": "Invalid PSN ID",
                "80108b10": "In use",
                "80108b15": "Crash",
                "80108b11": "RP version mismatch",
                "80108bff": "Unknown",
            }
            detail = _RP_ERRORS.get(reason, reason)
            raise PairingError(
                f"Registration HTTP {resp.status}" + (f" ({detail})" if detail else "")
            )

    # 4. Decrypt and parse response
    decrypted = crypto.decrypt_response(body)
    logger.debug("Raw decrypted registration response: %r", decrypted)
    registration = _parse_registration_body(decrypted)
    logger.debug("Registration keys received: %s", list(registration.keys()))
    logger.debug("Registration dict: %r", registration)

    rp_key = registration.get("RP-Key", "")
    if not rp_key:
        raise PairingError(f"RP-Key missing from registration response. Got: {registration!r}")

    return registration


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


class PairingError(PlayDirectorPairingError):
    """Raised when a pairing attempt fails (wrong PIN or registration refused)."""


async def pair_ps5(
    device: DiscoveredDevice,
    *,
    pin: str,
    npsso: str,
    device_id: str | None = None,
    label: str | None = None,
) -> RemotePlayCredentials:
    """
    Pair with a PS5 to obtain :class:`~playdirector.credentials.RemotePlayCredentials`.

    Prerequisites
    -------------
    * The PS5 must be on with Remote Play enabled
      (Settings → System → Remote Play).
    * On the PS5: Settings → System → Remote Play → **Link Device** to show PIN.
    * Obtain your NPSSO token from ``https://ca.account.sony.com/api/v1/ssocookie``
      after logging into your PSN account in a browser.

    Parameters
    ----------
    device:
        Discovered PS5 (from :func:`~playdirector.discovery.discover`).
    pin:
        The 8-digit PIN shown on the PS5 screen.
    npsso:
        Your PSN NPSSO cookie value.
    device_id:
        Optional storage key (defaults to ``device.device_id``).
    label:
        Optional human-readable label.

    Returns
    -------
    RemotePlayCredentials

    Raises
    ------
    PairingError
        On invalid PIN or registration failure.
    aiohttp.ClientError
        On network errors during the PSN OAuth exchange.
    """
    connector = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=connector) as http:
        logger.info("Exchanging NPSSO for PSN access token...")
        access_token, account_id_b64 = await _exchange_npsso_for_tokens(npsso, http)

        logger.info("Registering with PS5 at %s...", device.ip)
        registration = await _register_with_ps5(
            device=device,
            pin=pin,
            account_id_b64=account_id_b64,
            session=http,
        )

    logger.info("Registration succeeded.")
    regist_key = registration.get("PS5-RegistKey") or registration.get("PS4-RegistKey", "")
    if not regist_key:
        raise PairingError(f"RegistKey missing from response. Keys: {list(registration.keys())}")

    credential = registkey_to_credential(regist_key)
    logger.info("Derived credential string from RegistKey.")

    return RemotePlayCredentials(
        device_id=device_id or device.device_id,
        credential=credential,
        account_id=account_id_b64,
        registration_key=regist_key,
        rp_key=registration.get("RP-Key", ""),
        access_token=access_token,
        refresh_token="",  # SEN 2.0 doesn't issue refresh tokens
        label=label,
    )


async def pair_ps4(
    device: DiscoveredDevice,
    *,
    pin: str,
    npsso: str,
    device_id: str | None = None,
    label: str | None = None,
) -> RemotePlayCredentials:
    """
    Pair with a PS4 (firmware ≥ 8.0, RemotePlay 10.0) to obtain
    :class:`~playdirector.credentials.RemotePlayCredentials`.

    Prerequisites
    -------------
    * The PS4 must be on with Remote Play enabled
      (Settings → Remote Play Connection Settings → Enable Remote Play).
    * On the PS4: Settings → Remote Play Connection Settings → **Add Device** to show PIN.
    * Obtain your NPSSO token from ``https://ca.account.sony.com/api/v1/ssocookie``
      after logging into your PSN account in a browser.

    Parameters
    ----------
    device:
        Discovered PS4 (from :func:`~playdirector.discovery.discover`).
    pin:
        The 8-digit PIN shown on the PS4 screen.
    npsso:
        Your PSN NPSSO cookie value.
    device_id:
        Optional storage key (defaults to ``device.device_id``).
    label:
        Optional human-readable label.

    Returns
    -------
    RemotePlayCredentials

    Raises
    ------
    PairingError
        On invalid PIN or registration failure.
    aiohttp.ClientError
        On network errors during the PSN OAuth exchange.
    """
    connector = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=connector) as http:
        logger.info("Exchanging NPSSO for PSN access token...")
        access_token, account_id_b64 = await _exchange_npsso_for_tokens(npsso, http)

        logger.info("Registering with PS4 at %s...", device.ip)
        registration = await _register_with_ps4(
            device=device,
            pin=pin,
            account_id_b64=account_id_b64,
            session=http,
        )

    logger.info("PS4 registration succeeded.")
    regist_key = registration.get("PS4-RegistKey") or registration.get("PS5-RegistKey", "")
    if not regist_key:
        raise PairingError(
            f"RegistKey missing from PS4 response. Keys: {list(registration.keys())}"
        )

    credential = registkey_to_credential(regist_key)
    logger.info("Derived credential string from PS4 RegistKey.")

    return RemotePlayCredentials(
        device_id=device_id or device.device_id,
        credential=credential,
        account_id=account_id_b64,
        registration_key=regist_key,
        rp_key=registration.get("RP-Key", ""),
        access_token=access_token,
        refresh_token="",
        label=label,
    )
