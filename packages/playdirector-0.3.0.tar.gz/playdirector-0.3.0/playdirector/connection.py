"""
connection.py — asyncio TCP connection manager for PS4/PS5 second-screen protocol.

Implements the full connection sequence:

  1. Send WAKEUP + LAUNCH UDP priming datagrams (wake device from standby).
  2. TCP connect to device IP:port.
  3. HandshakeProc — exchange ClientHello/ServerHello, RSA-encrypt seed,
     send Handshake, switch TCP stream to AES-CBC codec.
  4. LoginProc — send Login, await LoginResult, send Status acknowledgement.
  5. Return a live Session object.

The Session exposes:
  * ``standby()``   — works on both PS4 and PS5.
  * ``send_keys()`` — PS4 only; raises UnsupportedDeviceError on PS5.

Timing constants (matching the original playdirector implementation):
  * 1 500 ms delay after TCP connect before starting handshake.
  * 200 ms inter-key delay in send_keys().
"""

from __future__ import annotations

import asyncio
import logging
import socket
from collections.abc import AsyncIterator, Sequence
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.serialization import load_der_public_key

from .credentials import RemotePlayCredentials, SecondScreenCredentials
from .crypto import CryptoCodec
from .discovery import DeviceType, DiscoveredDevice
from .exceptions import (
    PlayDirectorConnectionError,
    PlayDirectorCredentialsError,
    PlayDirectorDeviceError,
    PlayDirectorError,
    PlayDirectorNotSupportedError,
)
from .packets import (
    InternalRemoteOperation,
    LoginResultPacket,
    PacketType,
    RemoteOperation,
    build_bye,
    build_client_hello,
    build_handshake,
    build_login,
    build_remote_control,
    build_standby,
    build_status,
    parse_header,
    parse_login_result,
    parse_server_hello,
    parse_standby_result,
)

if TYPE_CHECKING:
    from .remoteplay_session import RemotePlaySession

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Timing constants (seconds unless noted)
# ---------------------------------------------------------------------------

_POST_CONNECT_DELAY = 1.5  # wait after TCP connect before sending ClientHello
_INTER_KEY_DELAY = 0.200  # delay between individual key presses

# UDP WAKEUP/LAUNCH ports
_PS4_UDP_PORT = 987
_PS5_UDP_PORT = 9302

# ---------------------------------------------------------------------------
# Hardcoded RSA public key (PKCS#8 DER, from handshake.ts in the original)
# This is the well-known PlayStation public key used for the second-screen
# handshake on all PS4/PS5 firmware versions.
# ---------------------------------------------------------------------------

# fmt: off
_HANDSHAKE_PUBLIC_KEY_DER = bytes([
    0x30, 0x82, 0x01, 0x22, 0x30, 0x0d, 0x06, 0x09,
    0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01,
    0x01, 0x05, 0x00, 0x03, 0x82, 0x01, 0x0f, 0x00,
    0x30, 0x82, 0x01, 0x0a, 0x02, 0x82, 0x01, 0x01,
    0x00, 0xb5, 0x8a, 0x2c, 0x85, 0xf8, 0x06, 0xb2,
    0x95, 0x18, 0xfc, 0x86, 0xb6, 0xda, 0xf4, 0x63,
    0x2e, 0x88, 0x97, 0x00, 0xef, 0xcd, 0x4e, 0xb7,
    0x34, 0x61, 0x9c, 0x98, 0xa9, 0x6c, 0x2e, 0x43,
    0x7e, 0x29, 0x53, 0xec, 0x51, 0x97, 0xd3, 0x44,
    0x19, 0x4e, 0xa7, 0x9b, 0xf2, 0x7a, 0xd0, 0xab,
    0xc9, 0xf0, 0x92, 0x07, 0xd9, 0x13, 0x6e, 0x73,
    0x62, 0x39, 0x34, 0x2c, 0x58, 0xa1, 0x43, 0x64,
    0xb8, 0xac, 0x95, 0x1c, 0x5a, 0x35, 0x59, 0x0e,
    0x1e, 0x3d, 0xe6, 0xb0, 0x63, 0x11, 0xd5, 0xdf,
    0x98, 0xf4, 0x51, 0x3c, 0xc3, 0xc6, 0x1f, 0xac,
    0x86, 0x47, 0x0e, 0x89, 0x7c, 0xc3, 0x55, 0x1e,
    0x38, 0x93, 0xbf, 0x61, 0x83, 0x8e, 0x2d, 0x98,
    0x7e, 0xe5, 0x1b, 0xf1, 0x0f, 0x70, 0x6f, 0x01,
    0x6b, 0xf9, 0x3c, 0x78, 0x47, 0x49, 0x41, 0x10,
    0x53, 0x70, 0x8e, 0x93, 0xd5, 0x6e, 0x15, 0x37,
    0xce, 0x47, 0x32, 0xaf, 0x3e, 0x6c, 0x5e, 0x8a,
    0xcb, 0x7a, 0xed, 0x90, 0x24, 0x82, 0x4e, 0xb1,
    0x34, 0xc5, 0xee, 0x16, 0x4b, 0x0d, 0x57, 0x24,
    0x65, 0x8e, 0xc9, 0x2d, 0xba, 0xed, 0x93, 0x25,
    0xfc, 0x61, 0x0d, 0x61, 0x25, 0x6e, 0x84, 0xf0,
    0x34, 0xe9, 0x95, 0x1d, 0x49, 0x5b, 0xa0, 0x54,
    0xaa, 0x25, 0x7e, 0xfe, 0x98, 0x8a, 0x91, 0xb5,
    0x14, 0x0a, 0x6e, 0xe5, 0xe0, 0xa2, 0x3c, 0xe7,
    0x2d, 0x55, 0xe3, 0xa3, 0x4c, 0xe5, 0xcd, 0xca,
    0xe3, 0x38, 0x7a, 0x77, 0x0e, 0x55, 0x75, 0x54,
    0x62, 0x93, 0x8c, 0x5c, 0x87, 0xaa, 0xac, 0xf3,
    0xdb, 0x83, 0x6d, 0x4b, 0x74, 0x73, 0xdf, 0x07,
    0xd5, 0x54, 0x59, 0x68, 0xb3, 0x5a, 0x49, 0x87,
    0xe5, 0xd3, 0xec, 0xa3, 0x18, 0x5b, 0x1d, 0x49,
    0x62, 0xe2, 0xce, 0x55, 0x74, 0x17, 0x3a, 0x0b,
    0x97, 0x02, 0x03, 0x01, 0x00, 0x01,
])
# fmt: on


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class LoginError(PlayDirectorCredentialsError):
    """Raised when the device rejects the Login packet (invalid/expired credentials)."""

    def __init__(self, result: LoginResultPacket) -> None:
        super().__init__(
            f"Login failed: result_code={result.result_code:#x} error_code={result.error_code:#x}"
        )
        self.result = result


class StandbyError(PlayDirectorDeviceError):
    """Raised when the device refuses the standby command."""


class SessionInitError(PlayDirectorDeviceError):
    """
    Raised when the Remote Play ``sess/init`` request is refused by the device.

    The device is reachable but is not accepting a new Remote Play session.
    Common causes: an existing session is still active, or the Remote Play
    listener was not primed with a WAKEUP datagram first.

    ``status_code`` is the HTTP status returned (typically 403).
    ``reason`` is the ``RP-Application-Reason`` header value if present
    (e.g. ``'80108b10'`` = previous session not yet released).
    """

    def __init__(self, status_code: int, reason: str, status_line: str) -> None:
        super().__init__(f"sess/init refused ({status_code}): reason={reason!r}")
        self.status_code = status_code
        self.reason = reason
        self.status_line = status_line


class UnsupportedDeviceError(PlayDirectorNotSupportedError):
    """Raised when an operation is not supported on the target device type."""


class ProtocolError(PlayDirectorError):
    """Raised on unexpected wire-level protocol violations (internal)."""


# ---------------------------------------------------------------------------
# UDP priming
# ---------------------------------------------------------------------------

# Second-screen (PS4 / PS5 second-screen protocol)
# Field order and LF-only line endings match Node.js formatDiscoveryMessage().
_WAKEUP_FMT_SS = (
    "WAKEUP * HTTP/1.1\n"
    "app-type:c\n"
    "auth-type:C\n"
    "client-type:i\n"
    "model:w\n"
    "user-credential:{credential}\n"
    "device-discovery-protocol-version:00030010\n"
)

_LAUNCH_FMT_SS = (
    "LAUNCH * HTTP/1.1\n"
    "app-type:c\n"
    "auth-type:C\n"
    "client-type:i\n"
    "model:w\n"
    "user-credential:{credential}\n"
    "device-discovery-protocol-version:00030010\n"
)

# Remote Play (PS5)
_WAKEUP_FMT_RP = (
    "WAKEUP * HTTP/1.1\n"
    "app-type:r\n"
    "auth-type:R\n"
    "client-type:vr\n"
    "model:w\n"
    "user-credential:{credential}\n"
    "device-discovery-protocol-version:00030010\n"
)

_LAUNCH_FMT_RP = (
    "LAUNCH * HTTP/1.1\n"
    "app-type:r\n"
    "auth-type:R\n"
    "client-type:vr\n"
    "model:w\n"
    "user-credential:{credential}\n"
    "device-discovery-protocol-version:00030010\n"
)


async def _send_udp_priming(
    ip: str,
    port: int,
    credential: str,
    *,
    is_remote_play: bool = False,
) -> None:
    """
    Send WAKEUP then LAUNCH UDP datagrams to *ip*:*port*.

    These are fire-and-forget — we don't need to wait for a response.
    Errors are logged but not re-raised; the TCP connection attempt is the
    authoritative check.
    """
    if is_remote_play:
        wakeup = _WAKEUP_FMT_RP.format(credential=credential).encode("utf-8")
        launch = _LAUNCH_FMT_RP.format(credential=credential).encode("utf-8")
    else:
        wakeup = _WAKEUP_FMT_SS.format(credential=credential).encode("utf-8")
        launch = _LAUNCH_FMT_SS.format(credential=credential).encode("utf-8")

    loop = asyncio.get_running_loop()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setblocking(False)
        transport, _ = await loop.create_datagram_endpoint(
            asyncio.DatagramProtocol,
            sock=sock,
        )
        # Send WAKEUP three times (UDP is lossy; PS5 may need a moment to
        # bring its network listener up from REST mode).
        for _ in range(3):
            transport.sendto(wakeup, (ip, port))
            await asyncio.sleep(0.5)
        transport.sendto(launch, (ip, port))
        await asyncio.sleep(0.1)  # small delay so packets reach the device
        transport.close()
        logger.debug("Sent WAKEUP×3 + LAUNCH UDP priming to %s:%d", ip, port)
    except Exception as exc:
        logger.warning("UDP priming error: %s", exc)


# ---------------------------------------------------------------------------
# Encrypted stream reader
# ---------------------------------------------------------------------------


class _EncryptedStream:
    """
    Wraps asyncio.StreamReader/StreamWriter with a CryptoCodec.

    After construction, use ``read_packet()`` / ``write_packet()``
    for encrypted I/O, or ``read_raw()`` / ``write_raw()`` for the
    plain-text phase before the codec is activated.
    """

    def __init__(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        self._reader = reader
        self._writer = writer
        self._codec: CryptoCodec | None = None
        # Accumulate decrypted bytes across calls
        self._plaintext_buffer = bytearray()

    def activate_codec(self, seed: bytes) -> None:
        """Switch from plaintext to encrypted mode using *seed*."""
        self._codec = CryptoCodec(seed)
        logger.debug("AES codec activated")

    # ------------------------------------------------------------------
    # Low-level helpers
    # ------------------------------------------------------------------

    async def read_raw(self, n: int) -> bytes:
        """Read exactly *n* plaintext bytes (pre-codec phase)."""
        return await self._reader.readexactly(n)

    async def write_raw(self, data: bytes) -> None:
        """Write plaintext bytes (pre-codec phase)."""
        self._writer.write(data)
        await self._writer.drain()

    # ------------------------------------------------------------------
    # Encrypted helpers
    # ------------------------------------------------------------------

    async def write_packet(self, data: bytes) -> None:
        """Encrypt *data* and write it to the stream."""
        if self._codec is None:
            raise ProtocolError("Codec not yet activated")
        self._writer.write(self._codec.encode(data))
        await self._writer.drain()

    async def _fill_plaintext_buffer(self, n: int) -> None:
        """Accumulate at least *n* decrypted bytes in the internal buffer."""
        while len(self._plaintext_buffer) < n:
            # Read whatever is available (at least 1 byte, up to 4096)
            chunk = await self._reader.read(4096)
            if not chunk:
                raise ProtocolError("Connection closed unexpectedly")
            plaintext = self._codec.decode(chunk)  # type: ignore[union-attr]
            self._plaintext_buffer.extend(plaintext)

    async def read_packet(self) -> tuple[int, bytes]:
        """
        Read one complete encrypted packet.

        Returns
        -------
        (packet_type, payload)
            *packet_type* is the raw u32 type code.
            *payload* is the bytes after the 8-byte header.
        """
        if self._codec is None:
            raise ProtocolError("Codec not yet activated")

        # Read 8-byte header
        await self._fill_plaintext_buffer(8)
        header = bytes(self._plaintext_buffer[:8])
        del self._plaintext_buffer[:8]

        total_len, ptype = parse_header(header)
        payload_len = total_len - 8

        if payload_len > 0:
            await self._fill_plaintext_buffer(payload_len)
            payload = bytes(self._plaintext_buffer[:payload_len])
            del self._plaintext_buffer[:payload_len]
        else:
            payload = b""

        return ptype, payload

    async def close(self) -> None:
        """Send Bye packet and close the TCP stream."""
        try:
            if self._codec:
                await self.write_packet(build_bye())
        except Exception:
            pass
        try:
            self._writer.close()
            await self._writer.wait_closed()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


class Session:
    """
    A live authenticated session with a PlayStation device.

    Obtain via ``connect()`` — do not instantiate directly.

    PS4:  ``standby()`` and ``send_keys()`` are both available.
    PS5:  only ``standby()`` is available; ``send_keys()`` raises
          :exc:`UnsupportedDeviceError`.
    """

    def __init__(
        self,
        stream: _EncryptedStream,
        device: DiscoveredDevice,
    ) -> None:
        self._stream = stream
        self._device = device

    @property
    def device(self) -> DiscoveredDevice:
        return self._device

    async def standby(self) -> None:
        """Put the device into standby / rest mode."""
        logger.debug("Sending standby to %s", self._device.ip)
        await self._stream.write_packet(build_standby())
        ptype, payload = await self._stream.read_packet()
        if ptype == PacketType.STANDBY_RESULT:
            result = parse_standby_result(payload)
            if not result.success:
                raise StandbyError(f"Standby failed with result_code={result.result_code:#x}")
        logger.info("Device %s entered standby", self._device.ip)

    async def go_home(self) -> None:
        """Navigate to the home screen (PS5 Remote Play only)."""
        raise UnsupportedDeviceError("go_home() is only supported for PS5 Remote Play sessions.")

    async def send_keys(
        self,
        operations: Sequence[RemoteOperation],
        hold_time: int = 0,
    ) -> None:
        """
        Send one or more button presses to a PS4 device.

        The sequence mirrors the original playdirector send_keys flow:

          OPEN_RC  →  [KEY press + KEY_OFF per button]  →  CLOSE_RC

        A 200 ms delay is inserted between each key press pair.

        Parameters
        ----------
        operations:
            One or more :class:`~playdirector.packets.RemoteOperation` values.
        hold_time:
            Duration in milliseconds to hold each button.  0 = tap.

        Raises
        ------
        UnsupportedDeviceError
            If called on a PS5 device.
        """
        if self._device.device_type == DeviceType.PS5:
            raise UnsupportedDeviceError(
                "Button input via the second-screen protocol is not supported "
                "on PS5.  Only standby() is available for PS5 devices."
            )

        logger.debug(
            "send_keys: ops=%s hold_time=%dms on %s",
            operations,
            hold_time,
            self._device.ip,
        )

        # Open remote-control session
        await self._stream.write_packet(
            build_remote_control(InternalRemoteOperation.OPEN_RC, hold_time=0)
        )
        await asyncio.sleep(0.1)

        for op in operations:
            # Press
            await self._stream.write_packet(build_remote_control(op, hold_time=hold_time))
            await asyncio.sleep(0.05)
            # Release
            await self._stream.write_packet(
                build_remote_control(InternalRemoteOperation.KEY_OFF, hold_time=0)
            )
            await asyncio.sleep(_INTER_KEY_DELAY)

        # Close remote-control session
        await self._stream.write_packet(
            build_remote_control(InternalRemoteOperation.CLOSE_RC, hold_time=0)
        )

    async def close(self) -> None:
        """Gracefully close the session (sends Bye packet)."""
        await self._stream.close()


# ---------------------------------------------------------------------------
# Remote Play session wrapper (PS5 only)
# ---------------------------------------------------------------------------


class _RemotePlaySessionWrapper(Session):
    """
    Thin wrapper that adapts a
    :class:`~playdirector.remoteplay_session.RemotePlaySession` to the
    :class:`Session` interface, so callers remain protocol-agnostic.

    Used by :func:`connect` when *device* is PS5 and *credential* is
    :class:`~playdirector.credentials.RemotePlayCredentials`.
    """

    def __init__(
        self,
        rp_session: RemotePlaySession,
        device: DiscoveredDevice,
    ) -> None:
        # Deliberately bypass Session.__init__ — we have no _EncryptedStream.
        self._rp_session = rp_session
        self._device = device
        self._stream = None  # type: ignore[assignment]

    @property
    def device(self) -> DiscoveredDevice:
        return self._device

    async def standby(self) -> None:
        """Put the PS5 into standby via Remote Play."""
        await self._rp_session.standby()

    async def go_home(self) -> None:
        """Navigate the PS5 to the home screen via Remote Play."""
        await self._rp_session.go_home()

    async def send_keys(
        self,
        operations: Sequence[RemoteOperation],
        hold_time: int = 0,
    ) -> None:
        raise UnsupportedDeviceError(
            "Button input is not available via the Remote Play protocol.  "
            "Only standby() is supported for PS5 Remote Play sessions."
        )

    async def close(self) -> None:
        """Close the Remote Play session."""
        await self._rp_session.close()


# ---------------------------------------------------------------------------
# RSA encryption helper
# ---------------------------------------------------------------------------


def _rsa_encrypt_seed(seed: bytes) -> bytes:
    """
    RSA-encrypt a 16-byte seed using the hardcoded PlayStation public key
    (PKCS#1 v1.5 padding, as used in handshake.ts).
    """
    public_key = load_der_public_key(_HANDSHAKE_PUBLIC_KEY_DER)
    return public_key.encrypt(seed, asym_padding.PKCS1v15())  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# Connection procedure
# ---------------------------------------------------------------------------


async def _handshake_proc(stream: _EncryptedStream) -> None:
    """
    Execute the ClientHello / ServerHello / Handshake exchange.

    After this completes the stream is switched to encrypted mode.
    """
    # Send ClientHello (plaintext — codec not active yet)
    await stream.write_raw(build_client_hello())
    logger.debug("Sent ClientHello")

    # Receive ServerHello (also plaintext)
    # ServerHello is 28 bytes total (same layout as ClientHello)
    raw = await stream.read_raw(28)
    hello = parse_server_hello(raw)
    logger.debug("Got ServerHello, seed=%s", hello.seed.hex())

    # RSA-encrypt the 16-byte seed → 256-byte ciphertext
    encrypted_seed = _rsa_encrypt_seed(hello.seed)

    # Send Handshake (still plaintext; codec activates after this)
    await stream.write_raw(build_handshake(encrypted_seed))
    logger.debug("Sent Handshake")

    # Activate AES codec — all subsequent packets are encrypted
    stream.activate_codec(hello.seed)


async def _login_proc(
    stream: _EncryptedStream,
    credential: str,
    account_id: str,
    pin_code: str = "",
) -> None:
    """Send Login, await LoginResult, send Status acknowledgement."""
    login_pkt = build_login(
        credential=credential,
        account_id=account_id,
        pin_code=pin_code,
    )
    await stream.write_packet(login_pkt)
    logger.debug("Sent Login")

    ptype, payload = await stream.read_packet()
    if ptype != PacketType.LOGIN_RESULT:
        raise ProtocolError(
            f"Expected LoginResult (0x{PacketType.LOGIN_RESULT:08x}), got 0x{ptype:08x}"
        )
    result = parse_login_result(payload)
    if not result.success:
        raise LoginError(result)
    logger.debug("LoginResult: success")

    # Acknowledge with Status(0)
    await stream.write_packet(build_status(0))
    logger.debug("Sent Status")


async def connect(
    device: DiscoveredDevice,
    credential: SecondScreenCredentials | RemotePlayCredentials,
    *,
    connect_timeout: float = 10.0,
    login_timeout: float = 15.0,
) -> Session:
    """
    Open a fully authenticated session with *device*.

    When *credential* is
    :class:`~playdirector.credentials.RemotePlayCredentials`, the Remote Play
    protocol (port 9295) is used:

    1. Sends UDP WAKEUP + LAUNCH priming datagrams (Remote Play format, ~1.6 s).
    2. Waits 0.3 s for the RP listener to mark itself ready.
    3. Performs the three-step Remote Play handshake (sess/init → sess/ctrl → Login).
    4. On 403 (e.g. previous session not yet released): re-primes and retries up
       to 2 more times with a 2.5 s back-off between attempts.
    5. Returns an active :class:`Session`.

    When *credential* is
    :class:`~playdirector.credentials.SecondScreenCredentials` (PS4 second-screen):

    1. Sends UDP WAKEUP + LAUNCH priming datagrams.
    2. Waits :data:`_POST_CONNECT_DELAY` seconds.
    3. Opens a TCP connection to the device.
    4. Runs the Handshake procedure (RSA + AES activation).
    5. Runs the Login procedure.
    6. Returns an active :class:`Session`.

    Parameters
    ----------
    device:
        A :class:`~playdirector.discovery.DiscoveredDevice` as returned by
        :func:`~playdirector.discovery.discover`.
    credential:
        A valid :class:`~playdirector.credentials.SecondScreenCredentials` or
        :class:`~playdirector.credentials.RemotePlayCredentials`.
    connect_timeout:
        TCP connection timeout in seconds.
    login_timeout:
        Time allowed for the full handshake + login sequence in seconds.
    """
    # ── Remote Play credentials (PS4 or PS5) → use port-9295 Remote Play protocol ──
    if isinstance(credential, RemotePlayCredentials):
        from .remoteplay_session import open_remoteplay_session  # local import to avoid cycles

        udp_port = _PS5_UDP_PORT if device.device_type == DeviceType.PS5 else _PS4_UDP_PORT
        if device.device_type == DeviceType.UNKNOWN:
            logger.warning(
                "Device type is UNKNOWN for %s; assuming PS5 UDP port for Remote Play priming. "
                "Set device_type=DeviceType.PS5 or DeviceType.PS4 for reliable priming.",
                device.ip,
            )

        # Prime the Remote Play listener before sess/init.  _send_udp_priming
        # already blocks ~1.6 s (WAKEUP×3 at 0.5 s intervals + LAUNCH); the
        # extra 0.3 s gives the PS5 RP service time to mark itself as ready.
        await _send_udp_priming(device.ip, udp_port, credential.credential, is_remote_play=True)
        await asyncio.sleep(0.3)

        # Retry on 403: the PS5 may return 403 (reason 80108b10) if a previous
        # session did not close cleanly.  Re-prime and retry after a short wait
        # to give the console time to release the old session.
        _MAX_RP_ATTEMPTS = 3
        _RP_RETRY_DELAY = 2.5
        last_exc: SessionInitError | None = None
        for attempt in range(_MAX_RP_ATTEMPTS):
            if attempt > 0:
                logger.warning(
                    "sess/init 403 on attempt %d/%d (reason=%s) — waiting %.1f s then re-priming",
                    attempt,
                    _MAX_RP_ATTEMPTS,
                    last_exc.reason if last_exc else "?",
                    _RP_RETRY_DELAY,
                )
                await asyncio.sleep(_RP_RETRY_DELAY)
                await _send_udp_priming(
                    device.ip, udp_port, credential.credential, is_remote_play=True
                )
                await asyncio.sleep(0.3)
            try:
                rp_sess = await open_remoteplay_session(
                    device,
                    credential,
                    timeout=connect_timeout + login_timeout,
                )
                return _RemotePlaySessionWrapper(rp_sess, device)
            except SessionInitError as exc:
                if exc.status_code == 403 and attempt < _MAX_RP_ATTEMPTS - 1:
                    last_exc = exc
                    continue
                raise
        # Unreachable, but keeps the type checker happy
        raise last_exc  # type: ignore[misc]

    udp_port = _PS5_UDP_PORT if device.device_type == DeviceType.PS5 else _PS4_UDP_PORT

    # UDP priming (wakes the device if in standby, starts the listener)
    await _send_udp_priming(device.ip, udp_port, credential.credential)

    logger.debug(
        "Connecting to %s:%d (timeout=%.1fs)",
        device.ip,
        device.port,
        connect_timeout,
    )
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(device.ip, device.port),
            timeout=connect_timeout,
        )
    except (TimeoutError, OSError) as exc:
        raise PlayDirectorConnectionError(
            f"Could not connect to {device.ip}:{device.port} — {exc}"
        ) from exc

    stream = _EncryptedStream(reader, writer)

    # Brief delay before starting the protocol — device needs time to accept
    await asyncio.sleep(_POST_CONNECT_DELAY)

    try:
        await asyncio.wait_for(
            _handshake_and_login(stream, credential),
            timeout=login_timeout,
        )
    except TimeoutError as exc:
        await stream.close()
        raise PlayDirectorConnectionError(
            f"Timed out during handshake/login with {device.ip}"
        ) from exc
    except Exception:
        await stream.close()
        raise

    return Session(stream=stream, device=device)


async def _handshake_and_login(
    stream: _EncryptedStream,
    credential: SecondScreenCredentials | RemotePlayCredentials,
) -> None:
    """Run the full handshake + login sequence on an open stream."""
    await _handshake_proc(stream)
    pin_code = ""
    await _login_proc(
        stream,
        credential=credential.credential,
        account_id=credential.account_id,
        pin_code=pin_code,
    )


# ---------------------------------------------------------------------------
# Async context-manager convenience wrapper
# ---------------------------------------------------------------------------


@asynccontextmanager
async def session_context(
    device: DiscoveredDevice,
    credential: SecondScreenCredentials | RemotePlayCredentials,
    *,
    connect_timeout: float = 10.0,
    login_timeout: float = 15.0,
) -> AsyncIterator[Session]:
    """
    Async context manager that opens a session and ensures it is closed.

    Usage::

        async with session_context(device, cred) as session:
            await session.send_keys([RemoteOperation.PS])
    """
    sess = await connect(
        device, credential, connect_timeout=connect_timeout, login_timeout=login_timeout
    )
    try:
        yield sess
    finally:
        await sess.close()
