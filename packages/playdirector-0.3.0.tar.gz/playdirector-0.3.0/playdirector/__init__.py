"""
playdirector — async Python library for PS4/PS5 second-screen control.

Quick start::

    import asyncio
    from playdirector import find, connect, RemoteOperation

    async def main():
        device = await find("192.168.1.50")
        from playdirector.credentials import JsonCredentialStorage
        cred = JsonCredentialStorage().load(device.device_id)
        async with connect(device, cred) as session:
            await session.send_keys([RemoteOperation.PS])

    asyncio.run(main())
"""

from .exceptions import (
    PlayDirectorConnectionError,
    PlayDirectorCredentialsError,
    PlayDirectorDeviceError,
    PlayDirectorError,
    PlayDirectorNotSupportedError,
    PlayDirectorPairingError,
)
from .playstation import (
    DeviceStatus,
    DeviceType,
    DiscoveredDevice,
    InternalRemoteOperation,
    JsonCredentialStorage,
    RemoteOperation,
    RemotePlayCredentials,
    SecondScreenCredentials,
    Session,
    SystemStatus,
    connect,
    find,
    get_status,
    go_home,
    pair,
    scan,
    send_buttons,
    standby,
    wake,
)

__version__ = "0.1.0"
__all__ = [
    # Core API
    "connect",
    "find",
    "get_status",
    "go_home",
    "pair",
    "scan",
    "send_buttons",
    "standby",
    "wake",
    # Types / enums
    "DiscoveredDevice",
    "DeviceType",
    "DeviceStatus",
    "SystemStatus",
    "Session",
    "RemoteOperation",
    "InternalRemoteOperation",
    # Credentials
    "SecondScreenCredentials",
    "RemotePlayCredentials",
    "JsonCredentialStorage",
    # Public exceptions
    "PlayDirectorError",
    "PlayDirectorConnectionError",
    "PlayDirectorDeviceError",
    "PlayDirectorNotSupportedError",
    "PlayDirectorPairingError",
    "PlayDirectorCredentialsError",
]
