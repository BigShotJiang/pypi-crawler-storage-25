"""
discovery.py — Async UDP device discovery for PS4 and PS5.

Broadcasts a ``SRCH`` datagram to the PlayStation second-screen discovery
ports and parses the HTTP/1.1-style text responses into DiscoveredDevice
instances.

Ports
-----
* PS4  — 987  (second-screen / DDP protocol)
* PS5  — 9302 (same DDP protocol, different port)

Usage::

    import asyncio
    from playdirector.discovery import scan, DeviceType

    async def main():
        async for device in scan(timeout=5):
            print(device)

    asyncio.run(main())
"""

from __future__ import annotations

import asyncio
import logging
import socket
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from enum import StrEnum

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BROADCAST_ADDR = "255.255.255.255"
PS4_DISCOVERY_PORT = 987
PS5_DISCOVERY_PORT = 9302
DISCOVERY_PORTS = (PS4_DISCOVERY_PORT, PS5_DISCOVERY_PORT)

# DDP SRCH request – sent as-is (no trailing newline required by firmware)
_SRCH_REQUEST = b"SRCH * HTTP/1.1\r\ndevice-discovery-protocol-version:00020020\r\n\r\n"


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


class DeviceType(StrEnum):
    PS4 = "PS4"
    PS5 = "PS5"
    UNKNOWN = "UNKNOWN"


class DeviceStatus(StrEnum):
    AWAKE = "awake"  # "200 Ok"  — device is on and ready
    STANDBY = "standby"  # "620 Server Standby" — in rest mode
    UNKNOWN = "unknown"


@dataclass
class DiscoveredDevice:
    """Represents a PlayStation device found on the local network."""

    ip: str
    port: int
    device_id: str  # "host-id" field from response
    name: str  # "host-name"
    status: DeviceStatus
    device_type: DeviceType
    system_version: str  # e.g. "09010000"
    running_app_titleid: str | None = None
    running_app_name: str | None = None
    # Raw parsed headers, for forward-compatibility
    raw_headers: dict[str, str] = field(default_factory=dict)

    def __str__(self) -> str:
        return (
            f"[{self.device_type.value}] {self.name} ({self.device_id}) "
            f"@ {self.ip}:{self.port} — {self.status.value}"
        )


# ---------------------------------------------------------------------------
# Response parser
# ---------------------------------------------------------------------------


def _parse_ddp_response(data: bytes, addr: tuple[str, int]) -> DiscoveredDevice | None:
    """
    Parse a raw DDP response datagram into a DiscoveredDevice.

    The wire format is HTTP/1.1-style text::

        HTTP/1.1 200 Ok\r\n
        host-id:AA:BB:CC:DD:EE:FF\r\n
        host-type:PS4\r\n
        host-name:Living Room PS4\r\n
        host-request-port:997\r\n
        running-app-titleid:CUSA12345\r\n
        running-app-name:Some Game\r\n
        device-discovery-protocol-version:00020020\r\n
        system-version:09010000\r\n
        \r\n

    Standby responses use status code 620 with fewer fields.
    """
    try:
        text = data.decode("utf-8", errors="replace")
    except Exception:
        return None

    lines = text.splitlines()
    if not lines:
        return None

    # --- Status line -------------------------------------------------------
    status_line = lines[0].strip()
    if not status_line.startswith("HTTP/1.1"):
        return None  # not a DDP response
    if status_line.startswith("HTTP/1.1 200"):
        status = DeviceStatus.AWAKE
    elif "620" in status_line:
        status = DeviceStatus.STANDBY
    else:
        status = DeviceStatus.UNKNOWN

    # --- Headers -----------------------------------------------------------
    headers: dict[str, str] = {}
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        if ":" in line:
            key, _, value = line.partition(":")
            headers[key.strip().lower()] = value.strip()

    device_id = headers.get("host-id", "")
    name = headers.get("host-name", "")
    system_version = headers.get("system-version", "")
    raw_type = headers.get("host-type", "").upper()

    if raw_type == "PS4":
        device_type = DeviceType.PS4
    elif raw_type == "PS5":
        device_type = DeviceType.PS5
    else:
        device_type = DeviceType.UNKNOWN

    ip, response_port = addr
    # Prefer the port the device advertises for TCP connections
    tcp_port_str = headers.get("host-request-port", "")
    try:
        tcp_port = int(tcp_port_str)
    except (ValueError, TypeError):
        tcp_port = response_port

    return DiscoveredDevice(
        ip=ip,
        port=tcp_port,
        device_id=device_id,
        name=name,
        status=status,
        device_type=device_type,
        system_version=system_version,
        running_app_titleid=headers.get("running-app-titleid"),
        running_app_name=headers.get("running-app-name"),
        raw_headers=headers,
    )


# ---------------------------------------------------------------------------
# asyncio DatagramProtocol
# ---------------------------------------------------------------------------


class _DiscoveryProtocol(asyncio.DatagramProtocol):
    """
    UDP protocol that sends SRCH datagrams to each discovery port and
    enqueues parsed DiscoveredDevice results.
    """

    def __init__(
        self,
        queue: asyncio.Queue[DiscoveredDevice | None],
        target_ip: str | None,
    ) -> None:
        self._queue = queue
        self._target_ip = target_ip
        self._transport: asyncio.DatagramTransport | None = None
        self._seen: set[str] = set()  # deduplicate by device_id

    # ------------------------------------------------------------------
    # asyncio.DatagramProtocol interface
    # ------------------------------------------------------------------

    def connection_made(self, transport: asyncio.DatagramTransport) -> None:  # type: ignore[override]
        self._transport = transport
        dest_ip = self._target_ip or BROADCAST_ADDR
        for port in DISCOVERY_PORTS:
            logger.debug("Sending SRCH to %s:%d", dest_ip, port)
            try:
                transport.sendto(_SRCH_REQUEST, (dest_ip, port))
            except Exception as exc:
                logger.warning("Failed to send SRCH to port %d: %s", port, exc)

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        logger.debug("DDP response from %s:%d (%d bytes)", addr[0], addr[1], len(data))
        device = _parse_ddp_response(data, addr)
        if device is None:
            return
        key = f"{device.ip}:{device.device_id}"
        if key in self._seen:
            return
        self._seen.add(key)
        self._queue.put_nowait(device)

    def error_received(self, exc: Exception) -> None:
        logger.warning("UDP discovery error: %s", exc)

    def connection_lost(self, exc: Exception | None) -> None:
        logger.debug("UDP discovery socket closed (exc=%s)", exc)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def scan(
    ip: str | None = None,
    timeout: float = 5.0,
) -> AsyncIterator[DiscoveredDevice]:
    """
    Async generator that yields :class:`DiscoveredDevice` instances found on
    the local network within *timeout* seconds.

    Parameters
    ----------
    ip:
        If provided, unicast the SRCH request to this specific IP instead of
        broadcasting.  Useful when the device IP is already known and broadcast
        is blocked (e.g. across VLANs).
    timeout:
        How long (seconds) to wait for responses before stopping.

    Yields
    ------
    DiscoveredDevice
        One instance per unique responding device (deduplicated by IP +
        device-id).

    Example
    -------
    ::

        async for device in scan(timeout=5):
            print(device)
    """
    queue: asyncio.Queue[DiscoveredDevice | None] = asyncio.Queue()
    loop = asyncio.get_running_loop()

    # Create a UDP socket with SO_BROADCAST so we can send to 255.255.255.255
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(False)
    sock.bind(("", 0))

    transport, protocol = await loop.create_datagram_endpoint(
        lambda: _DiscoveryProtocol(queue, ip),
        sock=sock,
    )

    deadline = loop.time() + timeout
    try:
        while True:
            remaining = deadline - loop.time()
            if remaining <= 0:
                break
            try:
                device = await asyncio.wait_for(queue.get(), timeout=remaining)
                if device is not None:
                    yield device
            except TimeoutError:
                break
    finally:
        transport.close()


async def _probe(
    ip: str | None = None,
    timeout: float = 5.0,
) -> DiscoveredDevice | None:
    """Internal: return the first device found by scan(), or None."""
    async for device in scan(ip=ip, timeout=timeout):
        return device
    return None
