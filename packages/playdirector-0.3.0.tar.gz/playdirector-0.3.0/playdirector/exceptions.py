"""
exceptions.py — Public exception hierarchy for playdirector.

All exceptions raised by the library are subclasses of :exc:`PlayDirectorError`
so callers can catch the base class for a catch-all, or a specific subclass to
handle distinct failure modes.

Hierarchy
---------
::

    PlayDirectorError
    ├── PlayDirectorConnectionError   # device unreachable / network failure
    ├── PlayDirectorDeviceError       # device reachable but refused the operation
    ├── PlayDirectorNotSupportedError # operation not valid for this device type
    ├── PlayDirectorPairingError      # wrong PIN or registration refused
    └── PlayDirectorCredentialsError  # expired or invalid credentials
"""

from __future__ import annotations


class PlayDirectorError(Exception):
    """Base class for all playdirector exceptions."""


class PlayDirectorConnectionError(PlayDirectorError):
    """
    Raised when a PlayStation device cannot be reached over the network.

    Common causes:

    * The console is powered off (not in standby).
    * The IP address is wrong or on a different network segment.
    * A firewall is blocking the discovery or TCP ports.
    * A network timeout occurred while connecting.

    **What to tell the user:** Check that the console is on and reachable at
    the given IP address.
    """


class PlayDirectorDeviceError(PlayDirectorError):
    """
    Raised when the device is reachable but actively refused or rejected an
    operation at the protocol level.

    Common causes:

    * Another Remote Play session is already active on the console.
    * The Remote Play listener was not primed before the session request.
    * The console rejected the standby command (e.g. a game is blocking it).

    **What to tell the user:** The console is online but is not accepting the
    request right now — check whether another session is active, or try again.
    """


class PlayDirectorNotSupportedError(PlayDirectorError):
    """
    Raised when an operation is not valid for the target device type.

    Common causes:

    * Calling a PS4-only function (e.g. ``send_buttons``) on a PS5.
    * Calling a PS5-only function (e.g. ``go_home``) on a PS4.

    **What to tell the user:** This operation is not supported on this console
    model — use the correct API for the device type.
    """


class PlayDirectorPairingError(PlayDirectorError):
    """
    Raised when a pairing attempt is rejected.

    Common causes:

    * The PIN entered does not match the one shown on the console.
    * The console refused the registration (e.g. too many attempts).
    * The NPSSO token is expired or invalid.

    **What to tell the user:** Check the PIN shown on the console screen and
    ensure the NPSSO token is current.
    """


class PlayDirectorCredentialsError(PlayDirectorError):
    """
    Raised when stored credentials are rejected by the device.

    Common causes:

    * The credentials have expired (PSN tokens rotate periodically).
    * The credential file is corrupt or was generated for a different account.
    * The device was factory-reset, invalidating previously registered clients.

    **What to tell the user:** Stored credentials are no longer valid — re-pair
    with the console to obtain fresh credentials.
    """
