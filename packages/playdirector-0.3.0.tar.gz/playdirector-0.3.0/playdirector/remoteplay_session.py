"""
remoteplay_session.py — PS5 Remote Play TCP session (port 9295).

Implements the three-step Remote Play connection protocol used by the
PlayStation official client:

  Step 1 — HTTP GET /sie/ps5/rp/sess/init
    Sends RP-RegistKey, receives RP-Nonce (16-byte server nonce, base64).

  Step 2 — HTTP GET /sie/ps5/rp/sess/ctrl
    Sends encrypted auth headers; the PS5 hijacks the TCP socket into a
    binary packet stream.

  Step 3 — Binary packet loop on the hijacked socket
    Packet format: [4B payload_len BE][2B type BE][2B 0x0000][NB encrypted payload]
    - AES-128-CFB with per-packet IV derived from HMAC-SHA256.
    - Send Login packet (type 0x0005), receive Login result.
    - Send Standby packet (type 0x0050) to power down the console.
    - Echo Heartbeat packets (type 0x00fe) to keep the session alive.

Crypto — createCodecForAuth (from dhleong/playactor modern.ts):
  Given rp_key (16 hex bytes from RP-Key field), server_nonce (16 bytes):

  AUTH_SEED (key for AES-128-CFB):
    key_offset = (server_nonce[7] >> 3) * 0x70
    seed[i] = (rp_key[i] + 0x18 + i) ^ server_nonce[i] ^ AUTH_SEED_KEYS_PS5[key_offset + i]

  AUTH_NONCE (msg prefix for HMAC):
    key_offset = (server_nonce[0] >> 3) * 0x70
    nonce[i] = (server_nonce[i] - 0x2d - i) ^ AUTH_NONCE_KEYS_PS5[key_offset + i]

  IV for counter N:
    HMAC-SHA256(key=PS5_HMAC_KEY, msg=auth_nonce || counter_as_8byte_BE)[:16]

  Encrypt/Decrypt:
    AES-128-CFB(key=auth_seed, iv=IV)
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import hashlib
import hmac as _hmac
import logging
import os
import struct
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from .auth_keys import (
    AUTH_NONCE_KEYS_PS4,
    AUTH_NONCE_KEYS_PS5,
    AUTH_SEED_KEYS_PS4,
    AUTH_SEED_KEYS_PS5,
)
from .connection import SessionInitError
from .credentials import RemotePlayCredentials
from .discovery import DeviceType, DiscoveredDevice

try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

    _HAS_CRYPTOGRAPHY = True
except ImportError:  # pragma: no cover
    _HAS_CRYPTOGRAPHY = False

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_RP_REGISTER_PORT = 9295
_USER_AGENT = "remoteplay Windows"

# RP-Version header value per device type (remotePlayVersionToString in model.ts)
_RP_VERSION = {
    DeviceType.PS5: "1.0",
    DeviceType.PS4: "10.0",  # latest firmware (≥ 8.0)
}

# HMAC keys for IV derivation (base.ts hmacKeys)
_HMAC_KEY = {
    DeviceType.PS5: bytes.fromhex("464687b349ca8ce859c5270f5d7a69d6"),
    DeviceType.PS4: bytes.fromhex("20d66f5904ea7c14e557ffc52e488ac8"),
}

# URL path fragments per device type
_SESS_INIT_PATH = {
    DeviceType.PS5: "/sie/ps5/rp/sess/init",
    DeviceType.PS4: "/sie/ps4/rp/sess/init",
}
_SESS_CTRL_PATH = {
    DeviceType.PS5: "/sie/ps5/rp/sess/ctrl",
    DeviceType.PS4: "/sie/ps4/rp/sess/ctrl",
}

# Auth key lookup tables per device type
_AUTH_NONCE_KEYS = {
    DeviceType.PS5: AUTH_NONCE_KEYS_PS5,
    DeviceType.PS4: AUTH_NONCE_KEYS_PS4,
}
_AUTH_SEED_KEYS = {
    DeviceType.PS5: AUTH_SEED_KEYS_PS5,
    DeviceType.PS4: AUTH_SEED_KEYS_PS4,
}

# DID layout: 10-byte prefix + 16 random bytes + 6-byte suffix = 32 bytes
_DID_PREFIX = bytes([0x00, 0x18, 0x00, 0x00, 0x00, 0x07, 0x00, 0x40, 0x00, 0x80])
_DID_SUFFIX = bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
_OS_TYPE = b"Win10.0.0"

# Remote Play packet type codes
_RPCMD_LOGIN = 0x0005
_RPCMD_STANDBY = 0x0050
_RPCMD_GO_HOME = 0x0014  # navigate to PS home screen
_RPCMD_HB_REQ = 0x00FE  # heartbeat request (PS5 → us)
_RPCMD_HB_REP = 0x01FE  # heartbeat reply  (us → PS5)
_RPCMD_HEARTBEAT = _RPCMD_HB_REQ  # alias for receive-side checks

# Packet header: [4B payload_len BE][2B type BE][2B 0x0000]
_RP_HEADER_FMT = ">IHH"
_RP_HEADER_SIZE = 8  # struct.calcsize(">IHH")


# ---------------------------------------------------------------------------
# Crypto helpers
# ---------------------------------------------------------------------------


def _generate_iv(
    auth_nonce: bytes, counter: int, device_type: DeviceType = DeviceType.PS5
) -> bytes:
    """
    IV for packet counter N:
      HMAC-SHA256(key=HMAC_KEY[device_type], msg=auth_nonce || counter_8bytes_BE)[:16]
    """
    counter_bytes = struct.pack(">Q", counter)
    hmac_key = _HMAC_KEY[device_type]
    h = _hmac.new(hmac_key, auth_nonce + counter_bytes, hashlib.sha256)
    return h.digest()[:16]


def _derive_auth_seed(
    rp_key: bytes, server_nonce: bytes, device_type: DeviceType = DeviceType.PS5
) -> bytes:
    """
    AUTH_SEED (16 bytes) — the AES-128-CFB key.

    PS5 (modern.ts generateAuthSeed PS5 branch):
      key_offset = (server_nonce[7] >> 3) * 0x70
      seed[i] = (rp_key[i] + 0x18 + i) ^ server_nonce[i] ^ AUTH_SEED_KEYS[device_type][key_offset + i]

    PS4 (modern.ts generateAuthSeed PS4 branch):
      key_offset = (server_nonce[7] >> 3) * 0x70
      seed[i] = (AUTH_SEED_KEYS[device_type][key_offset+i] ^ rp_key[i] + 0x21 + i) ^ server_nonce[i]
    """
    key_offset = (server_nonce[7] >> 3) * 0x70
    table = _AUTH_SEED_KEYS[device_type]
    seed = bytearray(16)
    if device_type == DeviceType.PS5:
        for i in range(16):
            key = table[key_offset + i]
            v = (rp_key[i] + 0x18 + i) & 0xFF
            v ^= server_nonce[i]
            v ^= key
            seed[i] = v
    else:  # PS4
        for i in range(16):
            key = table[key_offset + i]
            v = key ^ rp_key[i]
            v = (v + 0x21 + i) & 0xFF
            v ^= server_nonce[i]
            seed[i] = v
    return bytes(seed)


def _derive_auth_nonce(server_nonce: bytes, device_type: DeviceType = DeviceType.PS5) -> bytes:
    """
    AUTH_NONCE (16 bytes) — prefix for HMAC-SHA256.

    PS5: nonce[i] = (server_nonce[i] - 0x2d - i) ^ AUTH_NONCE_KEYS_PS5[key_offset + i]
    PS4: nonce[i] = (server_nonce[i] + 0x36 + i) ^ AUTH_NONCE_KEYS_PS4[key_offset + i]
    """
    key_offset = (server_nonce[0] >> 3) * 0x70
    table = _AUTH_NONCE_KEYS[device_type]
    nonce = bytearray(16)
    if device_type == DeviceType.PS5:
        for i in range(16):
            v = (server_nonce[i] - 0x2D - i) & 0xFF
            v ^= table[key_offset + i]
            nonce[i] = v
    else:  # PS4
        for i in range(16):
            v = (server_nonce[i] + 0x36 + i) & 0xFF
            v ^= table[key_offset + i]
            nonce[i] = v
    return bytes(nonce)


def _aes_cfb_encrypt(key: bytes, iv: bytes, plaintext: bytes) -> bytes:
    """AES-128-CFB encrypt (no padding)."""
    if not _HAS_CRYPTOGRAPHY:
        raise RuntimeError("cryptography package required; pip install cryptography")
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv))
    enc = cipher.encryptor()
    return enc.update(plaintext) + enc.finalize()


def _aes_cfb_decrypt(key: bytes, iv: bytes, ciphertext: bytes) -> bytes:
    """AES-128-CFB decrypt (no padding)."""
    if not _HAS_CRYPTOGRAPHY:
        raise RuntimeError("cryptography package required; pip install cryptography")
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv))
    dec = cipher.decryptor()
    return dec.update(ciphertext) + dec.finalize()


# ---------------------------------------------------------------------------
# RP-Key extraction
# ---------------------------------------------------------------------------


def _rp_key_from_creds(cred: RemotePlayCredentials) -> bytes:
    """
    Return the 16-byte RP-Key from the credentials.

    The RP-Key is the 32-hex-char key returned by the device during
    registration (the ``RP-Key`` field in the registration response body).
    """
    rp_key_hex = cred.rp_key
    if not rp_key_hex:
        raise ValueError(
            "Credentials missing RP-Key — re-pair with the device to obtain fresh credentials."
        )
    return bytes.fromhex(rp_key_hex)


# ---------------------------------------------------------------------------
# Packet codec
# ---------------------------------------------------------------------------


class _RemotePlayCodec:
    """
    Stateful codec for the Remote Play binary packet stream.

    Each call to encode/decode advances the independent encrypt/decrypt
    counters.  The codec is NOT thread-safe.
    """

    def __init__(
        self, auth_seed: bytes, auth_nonce: bytes, device_type: DeviceType = DeviceType.PS5
    ) -> None:
        self._auth_seed = auth_seed
        self._auth_nonce = auth_nonce
        self._device_type = device_type
        self._encrypt_counter = 0
        self._decrypt_counter = 0

    def encode_payload(self, plaintext: bytes) -> bytes:
        """Encrypt a packet payload, advancing the encrypt counter."""
        iv = _generate_iv(self._auth_nonce, self._encrypt_counter, self._device_type)
        self._encrypt_counter += 1
        return _aes_cfb_encrypt(self._auth_seed, iv, plaintext)

    def decode_payload(self, ciphertext: bytes) -> bytes:
        """Decrypt a packet payload, advancing the decrypt counter."""
        iv = _generate_iv(self._auth_nonce, self._decrypt_counter, self._device_type)
        self._decrypt_counter += 1
        return _aes_cfb_decrypt(self._auth_seed, iv, ciphertext)

    # Used for HTTP header encryption (separate counter object per field)
    @classmethod
    def header_encrypt(
        cls,
        auth_seed: bytes,
        auth_nonce: bytes,
        counter: int,
        plaintext: bytes,
        device_type: DeviceType = DeviceType.PS5,
    ) -> bytes:
        iv = _generate_iv(auth_nonce, counter, device_type)
        return _aes_cfb_encrypt(auth_seed, iv, plaintext)


# ---------------------------------------------------------------------------
# Low-level socket I/O helpers
# ---------------------------------------------------------------------------


def _build_packet(ptype: int, payload: bytes = b"") -> bytes:
    """Build a Remote Play binary packet."""
    header = struct.pack(_RP_HEADER_FMT, len(payload), ptype, 0)
    return header + payload


async def _read_exactly(reader: asyncio.StreamReader, n: int) -> bytes:
    return await reader.readexactly(n)


async def _read_packet(
    reader: asyncio.StreamReader,
    codec: _RemotePlayCodec,
) -> tuple[int, bytes]:
    """
    Read one packet from the hijacked TCP stream.

    Returns (packet_type, plaintext_payload).
    """
    header_raw = await _read_exactly(reader, _RP_HEADER_SIZE)
    payload_len, ptype, _reserved = struct.unpack(_RP_HEADER_FMT, header_raw)
    if payload_len > 0:
        ciphertext = await _read_exactly(reader, payload_len)
        payload = codec.decode_payload(ciphertext)
    else:
        payload = b""
    logger.debug("Received RP packet type=0x%04x payload_len=%d", ptype, payload_len)
    return ptype, payload


async def _write_packet(
    writer: asyncio.StreamWriter,
    codec: _RemotePlayCodec,
    ptype: int,
    plaintext: bytes = b"",
) -> None:
    """Encrypt *plaintext* (if non-empty) and send a packet."""
    ciphertext = codec.encode_payload(plaintext) if plaintext else b""
    raw = _build_packet(ptype, ciphertext)
    writer.write(raw)
    await writer.drain()
    logger.debug("Sent RP packet type=0x%04x payload_len=%d", ptype, len(plaintext))


# ---------------------------------------------------------------------------
# Step 1 — HTTP GET /sie/ps5/rp/sess/init
# ---------------------------------------------------------------------------


async def _session_init(
    ip: str,
    registration_key: str,
    rp_key: bytes,  # noqa: ARG001 — reserved for future ECDH use
    device_type: DeviceType = DeviceType.PS5,
) -> bytes:
    """
    Perform the session init request over raw TCP, returning the 16-byte
    server nonce.

    Sends a minimal HTTP/1.1 GET to /sie/{type}/rp/sess/init with correct
    header casing (RP-Registkey, Rp-Version) as observed in official client
    captures.  The device responds 200 OK with RP-Nonce (base64, 16 bytes).
    """
    url_path = _SESS_INIT_PATH[device_type]
    rp_version = _RP_VERSION[device_type]
    raw_request = (
        f"GET {url_path} HTTP/1.1\r\n"
        f"Host: {ip}:{_RP_REGISTER_PORT}\r\n"
        f"User-Agent: {_USER_AGENT}\r\n"
        f"Connection: close\r\n"
        f"Content-Length: 0\r\n"
        f"RP-Registkey: {registration_key}\r\n"
        f"Rp-Version: {rp_version}\r\n"
        f"\r\n"
    )

    logger.debug("Step 1: GET %s from %s:%d", url_path, ip, _RP_REGISTER_PORT)

    reader, writer = await asyncio.open_connection(ip, _RP_REGISTER_PORT)
    try:
        writer.write(raw_request.encode("utf-8"))
        await writer.drain()

        # Read HTTP response headers up to blank line
        response_lines: list[str] = []
        while True:
            line_bytes = await asyncio.wait_for(reader.readline(), timeout=15.0)
            line = line_bytes.decode("latin-1").rstrip("\r\n")
            if not line:
                break
            response_lines.append(line)
            logger.debug("sess/init response: %s", line)

        if not response_lines:
            raise RuntimeError("Empty HTTP response from /sess/init")

        status_line = response_lines[0]
        parts = status_line.split(None, 2)
        status_code = int(parts[1]) if len(parts) >= 2 else 0

        resp_headers: dict[str, str] = {}
        for line in response_lines[1:]:
            if ":" in line:
                k, _, v = line.partition(":")
                resp_headers[k.strip()] = v.strip()

        if status_code >= 300:
            reason = resp_headers.get("RP-Application-Reason", "")
            logger.error("sess/init failed: %s  headers=%s", status_line, resp_headers)
            raise SessionInitError(status_code, reason, status_line)

        nonce_b64 = resp_headers.get("RP-Nonce")
        if not nonce_b64:
            raise RuntimeError(
                f"Session init: missing RP-Nonce in response. Headers: {resp_headers}"
            )
        nonce = base64.b64decode(nonce_b64)
        if len(nonce) != 16:
            raise RuntimeError(f"Session init: unexpected nonce length {len(nonce)}, expected 16")
        logger.debug("Step 1 OK: server nonce=%s", nonce.hex())
        return nonce
    finally:
        writer.close()
        with contextlib.suppress(OSError):
            await writer.wait_closed()


# ---------------------------------------------------------------------------
# Step 2 — HTTP GET /sie/ps5/rp/sess/ctrl (socket hijack)
# ---------------------------------------------------------------------------


async def _open_control_socket(
    ip: str,
    registration_key: str,
    auth_seed: bytes,
    auth_nonce: bytes,
    device_type: DeviceType = DeviceType.PS5,
) -> tuple[asyncio.StreamReader, asyncio.StreamWriter, str | None]:
    """
    Send the /sess/ctrl request over a keep-alive TCP connection.

    The device responds with HTTP/1.1 200 headers and then immediately
    switches the same TCP socket to binary Remote Play packet framing.
    We extract the reader/writer from the underlying socket.

    Returns (reader, writer, server_type_b64) ready for binary packet I/O.
    """
    url_path = _SESS_CTRL_PATH[device_type]
    rp_version = _RP_VERSION[device_type]

    # Derive device ID: DID_PREFIX + 16 random bytes + DID_SUFFIX
    did_random = os.urandom(16)
    did = _DID_PREFIX + did_random + _DID_SUFFIX  # 32 bytes

    # Encrypt header fields (each uses an independent counter starting at 0)
    # Both PS4 (≥ 8.0) and PS5 send the same 5 encrypted headers.
    def henc(counter: int, data: bytes) -> bytes:
        return _RemotePlayCodec.header_encrypt(auth_seed, auth_nonce, counter, data, device_type)

    rp_auth_plain = bytes.fromhex(registration_key).ljust(16, b"\x00")[:16]
    rp_auth_enc = henc(0, rp_auth_plain)
    rp_did_enc = henc(1, did)
    rp_os_enc = henc(2, _OS_TYPE)
    # PS4 (≥ 8.0) and PS5 both send RP-StartBitrate and RP-StreamingType
    rp_start_bitrate_enc = henc(3, b"\x00\x00\x00\x00")
    rp_streaming_type_enc = henc(4, b"\x01\x00\x00\x00")  # LE int32 = 1

    rp_auth = base64.b64encode(rp_auth_enc).decode()
    rp_did = base64.b64encode(rp_did_enc).decode()
    rp_os = base64.b64encode(rp_os_enc).decode()
    rp_start_bitrate = base64.b64encode(rp_start_bitrate_enc).decode()
    rp_streaming = base64.b64encode(rp_streaming_type_enc).decode()

    headers_str = (
        f"GET {url_path} HTTP/1.1\r\n"
        f"Host: {ip}:{_RP_REGISTER_PORT}\r\n"
        f"User-Agent: {_USER_AGENT}\r\n"
        f"RP-Auth: {rp_auth}\r\n"
        f"RP-Version: {rp_version}\r\n"
        f"RP-Did: {rp_did}\r\n"
        f"RP-ControllerType: 3\r\n"
        f"RP-ClientType: 11\r\n"
        f"RP-OSType: {rp_os}\r\n"
        f"RP-ConPath: 1\r\n"
        f"RP-StartBitrate: {rp_start_bitrate}\r\n"
        f"RP-StreamingType: {rp_streaming}\r\n"
        f"Connection: keep-alive\r\n"
        f"Content-Length: 0\r\n"
        f"\r\n"
    )

    logger.debug("Step 2: opening TCP keep-alive to %s:%d", ip, _RP_REGISTER_PORT)
    reader, writer = await asyncio.open_connection(ip, _RP_REGISTER_PORT)

    writer.write(headers_str.encode("utf-8"))
    await writer.drain()

    # Read the HTTP response headers (up to the \r\n\r\n terminator)
    response_lines: list[str] = []
    while True:
        line_bytes = await asyncio.wait_for(reader.readline(), timeout=15.0)
        line = line_bytes.decode("latin-1").rstrip("\r\n")
        if not line:
            break  # blank line = end of headers
        response_lines.append(line)
        logger.debug("ctrl response header: %s", line)

    if not response_lines:
        raise RuntimeError("Empty HTTP response from /sess/ctrl")
    status_line = response_lines[0]
    if "200" not in status_line:
        raise RuntimeError(f"Session ctrl request failed: {status_line!r}")

    # Parse the response headers to extract rp-server-type (encrypted).
    # The caller will decrypt it with decryptCounter=0 to advance the counter
    # to 1 before the first binary packet arrives — mirroring Node.js behaviour.
    ctrl_resp_headers: dict[str, str] = {}
    for line in response_lines[1:]:
        if ":" in line:
            k, _, v = line.partition(":")
            ctrl_resp_headers[k.strip().lower()] = v.strip()

    server_type_b64 = ctrl_resp_headers.get("rp-server-type")
    logger.debug("Step 2 OK: TCP socket hijacked for binary protocol")
    return reader, writer, server_type_b64


# ---------------------------------------------------------------------------
# Step 3 — Binary packet loop (Login → Standby / Heartbeat)
# ---------------------------------------------------------------------------


async def _do_login(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    codec: _RemotePlayCodec,
) -> None:
    """Send Login packet and wait for the Login result."""
    logger.debug("Step 3: sending Login (0x%04x)", _RPCMD_LOGIN)
    await _write_packet(writer, codec, _RPCMD_LOGIN)

    # Drain until we get type 0x0005 (Login result), echoing heartbeats
    for _ in range(30):
        ptype, payload = await asyncio.wait_for(_read_packet(reader, codec), timeout=10.0)
        if ptype == _RPCMD_HB_REQ:
            logger.debug("Heartbeat received during login wait — echoing")
            await _write_packet(writer, codec, _RPCMD_HB_REP)
            continue
        if ptype == _RPCMD_LOGIN:
            # Login result; parse result code from first byte if present
            if payload and payload[0] != 0:
                raise RuntimeError(f"Remote Play Login rejected: result_code=0x{payload[0]:02x}")
            logger.debug("Login accepted")
            return
        logger.debug("Unexpected packet during login: type=0x%04x (ignoring)", ptype)

    raise RuntimeError("Remote Play Login: no response received")


async def _do_go_home(
    writer: asyncio.StreamWriter,
    codec: _RemotePlayCodec,
) -> None:
    """Send the Go Home command (navigate to PS home screen)."""
    # 16-byte payload observed in chiaki: first two bytes are 0x00 0xff, rest zeros.
    payload = bytes([0x00, 0xFF]) + bytes(14)
    logger.debug("Sending Go Home (0x%04x)", _RPCMD_GO_HOME)
    await _write_packet(writer, codec, _RPCMD_GO_HOME, payload)


async def _do_standby(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    codec: _RemotePlayCodec,
) -> None:
    """Send the Standby command (type 0x0050)."""
    logger.debug("Sending Standby (0x%04x)", _RPCMD_STANDBY)
    await _write_packet(writer, codec, _RPCMD_STANDBY)
    # The PS5 may or may not send a response before closing the connection;
    # wait briefly for optional confirmation or heartbeat.
    try:
        ptype, _payload = await asyncio.wait_for(_read_packet(reader, codec), timeout=3.0)
        logger.debug("Post-standby packet type=0x%04x (ignored)", ptype)
    except (TimeoutError, asyncio.IncompleteReadError, ConnectionError):
        pass  # expected — the PS5 closes the socket after standby
    logger.info("Standby command sent successfully")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


class RemotePlaySession:
    """
    A live Remote Play session with a PS5.

    Obtain via :func:`open_remoteplay_session` — do not instantiate directly.
    """

    def __init__(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        codec: _RemotePlayCodec,
        device: DiscoveredDevice,
    ) -> None:
        self._reader = reader
        self._writer = writer
        self._codec = codec
        self._device = device
        self._closed = False

    @property
    def device(self) -> DiscoveredDevice:
        return self._device

    async def go_home(self) -> None:
        """Navigate the PS5 to the home screen."""
        if self._closed:
            raise RuntimeError("Session is already closed")
        await _do_go_home(self._writer, self._codec)

    async def standby(self) -> None:
        """Put the PS5 into standby / rest mode via Remote Play."""
        if self._closed:
            raise RuntimeError("Session is already closed")
        await _do_standby(self._reader, self._writer, self._codec)

    async def close(self) -> None:
        """Close the underlying TCP connection."""
        if self._closed:
            return
        self._closed = True
        try:
            self._writer.close()
            await self._writer.wait_closed()
        except Exception:
            pass


async def open_remoteplay_session(
    device: DiscoveredDevice,
    cred: RemotePlayCredentials,
    *,
    timeout: float = 20.0,
) -> RemotePlaySession:
    """
    Open a Remote Play session with *device* using *cred*.

    Performs the full three-step handshake:

    1. HTTP GET /sie/ps5/rp/sess/init → server nonce
    2. HTTP GET /sie/ps5/rp/sess/ctrl → socket hijack
    3. Binary Login packet exchange

    Returns a :class:`RemotePlaySession` ready for :meth:`~RemotePlaySession.standby`.

    Parameters
    ----------
    device:
        A :class:`~playdirector.discovery.DiscoveredDevice`.
    cred:
        A :class:`~playdirector.credentials.RemotePlayCredentials`.
    timeout:
        Overall timeout in seconds for the entire handshake.
    """
    registration_key = cred.registration_key
    rp_key = _rp_key_from_creds(cred)
    device_type = device.device_type

    async def _connect() -> RemotePlaySession:
        # Step 1 — init: get server nonce
        server_nonce = await _session_init(device.ip, registration_key, rp_key, device_type)

        # Derive crypto material
        auth_seed = _derive_auth_seed(rp_key, server_nonce, device_type)
        auth_nonce = _derive_auth_nonce(server_nonce, device_type)
        logger.debug("auth_seed=%s auth_nonce=%s", auth_seed.hex(), auth_nonce.hex())

        # Step 2 — ctrl: hijack socket
        reader, writer, server_type_b64 = await _open_control_socket(
            device.ip, registration_key, auth_seed, auth_nonce, device_type
        )

        # Packet codec: encrypt counter starts at 5 (counters 0-4 consumed by
        # the 5 encrypted request headers). Decrypt counter starts at 0.
        codec = _RemotePlayCodec(auth_seed, auth_nonce, device_type)
        codec._encrypt_counter = 5

        # Decrypt rp-server-type (decryptCounter=0 → advances to 1).
        # Must match what the Node.js codec does before the first binary packet.
        if server_type_b64:
            server_type = codec.decode_payload(base64.b64decode(server_type_b64))
            logger.debug("RP-Server-Type decrypted: %s", server_type.hex())
        else:
            logger.warning("RP-Server-Type missing — decrypt counter stays at 0")

        try:
            # Step 3 — login
            await _do_login(reader, writer, codec)
        except Exception:
            writer.close()
            raise

        return RemotePlaySession(reader=reader, writer=writer, codec=codec, device=device)

    return await asyncio.wait_for(_connect(), timeout=timeout)


@asynccontextmanager
async def remoteplay_session_context(
    device: DiscoveredDevice,
    cred: RemotePlayCredentials,
    *,
    timeout: float = 30.0,
) -> AsyncIterator[RemotePlaySession]:
    """
    Async context manager wrapping :func:`open_remoteplay_session`.

    Usage::

        async with remoteplay_session_context(device, cred) as session:
            await session.standby()
    """
    sess = await open_remoteplay_session(device, cred, timeout=timeout)
    try:
        yield sess
    finally:
        await sess.close()
