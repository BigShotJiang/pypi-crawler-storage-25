"""
packets.py — Binary packet builders and parsers for the PS4/PS5
             second-screen (DDP/TCP) protocol.

All multi-byte fields are little-endian unless noted.  Every outgoing packet
starts with a 4-byte little-endian length prefix followed by a 4-byte
little-endian type code — the two fields that make up the common header.

Packet type codes
-----------------
Outgoing
  0x6f636e63  ClientHello
  0x28446f48  Handshake
  0x30426f4c  Login
  0x20536f53  Status
  0x24536f53  Standby
  0x10426f52  RemoteControl
  0x04536f42  Bye

Incoming
  0x6f636e64  ServerHello
  0x07006f4c  LoginResult
  0x08006f53  StandbyResult
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from enum import IntEnum, IntFlag

# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class RemoteOperation(IntFlag):
    """
    Button operations sent via RemoteControl packets (PS4 only).

    Values match remote.ts in the original playdirector project.
    Multiple buttons can be OR-ed together.
    """

    UP = 0x0001
    DOWN = 0x0002
    RIGHT = 0x0004
    LEFT = 0x0008
    ENTER = 0x0010
    BACK = 0x0020
    OPTION = 0x0040
    PS = 0x0080
    # 0x0100 reserved / unused in second-screen
    CANCEL = 0x0200


class InternalRemoteOperation(IntEnum):
    """
    Internal control operations used to bracket a RemoteControl session.

    These are sent as the ``op`` field of RemoteControl packets with
    ``hold_time = 0``.
    """

    KEY_OFF = 0x0100  # release all keys
    OPEN_RC = 0x0400  # begin remote-control session
    CLOSE_RC = 0x0800  # end remote-control session


# Convenience union type used by connection.py
AnyRemoteOp = RemoteOperation | InternalRemoteOperation


# ---------------------------------------------------------------------------
# Common header
# ---------------------------------------------------------------------------

# struct format for the 8-byte common header: <length (u32), type (u32)>
_HEADER_FMT = "<II"
_HEADER_SIZE = struct.calcsize(_HEADER_FMT)  # 8


def _pack_header(packet_type: int, payload: bytes) -> bytes:
    """Prepend the 8-byte length+type header to *payload*."""
    length = _HEADER_SIZE + len(payload)
    return struct.pack(_HEADER_FMT, length, packet_type) + payload


# ---------------------------------------------------------------------------
# Packet type codes
# ---------------------------------------------------------------------------


class PacketType(IntEnum):
    # Outgoing
    CLIENT_HELLO = 0x6F636E63
    HANDSHAKE = 0x28446F48
    LOGIN = 0x30426F4C
    STATUS = 0x20536F53
    STANDBY = 0x24536F53
    REMOTE_CONTROL = 0x10426F52
    BYE = 0x04536F42

    # Incoming
    SERVER_HELLO = 0x6F636E64
    LOGIN_RESULT = 0x07006F4C
    STANDBY_RESULT = 0x08006F53


# ---------------------------------------------------------------------------
# Outgoing packet builders
# ---------------------------------------------------------------------------


def build_client_hello() -> bytes:
    """
    ClientHello — 28 bytes total (8-byte header + 20-byte payload).

    Payload layout (little-endian)::

        u32  seed_offset    = 0x1C        (28 — byte offset to seed field)
        u32  crypto_offset  = 0x00
        u32  unknown1       = 0x00
        u32  unknown2       = 0x00
        u32  unknown3       = 0x00

    The seed field itself lives in the *ServerHello* response; this packet
    just advertises where the server should write it in its response.
    """
    payload = struct.pack(
        "<IIIII",
        0x1C,  # seed_offset
        0x00,  # crypto_offset
        0x00,
        0x00,
        0x00,
    )
    return _pack_header(PacketType.CLIENT_HELLO, payload)


def build_handshake(encrypted_seed: bytes) -> bytes:
    """
    Handshake — header + 256-byte RSA-encrypted seed.

    The caller (connection.py) RSA-encrypts the 16-byte seed from ServerHello
    using the device's public key and passes the 256-byte ciphertext here.
    """
    if len(encrypted_seed) != 256:
        raise ValueError(f"encrypted_seed must be 256 bytes, got {len(encrypted_seed)}")
    return _pack_header(PacketType.HANDSHAKE, encrypted_seed)


# Login packet fixed field sizes (bytes)
_LOGIN_PASSCODE_LEN = 32
_LOGIN_INFO_LEN = 8  # "iOS 14.7"  style string, NUL-padded
_LOGIN_CREDENTIAL_LEN = 64
_LOGIN_APPLABEL_LEN = 256
_LOGIN_OSVERSION_LEN = 16
_LOGIN_MODEL_LEN = 256
_LOGIN_PINCODE_LEN = 16

_LOGIN_PAYLOAD_FMT = (
    f"{_LOGIN_PASSCODE_LEN}s"
    f"{_LOGIN_INFO_LEN}s"
    f"{_LOGIN_CREDENTIAL_LEN}s"
    f"{_LOGIN_APPLABEL_LEN}s"
    f"{_LOGIN_OSVERSION_LEN}s"
    f"{_LOGIN_MODEL_LEN}s"
    f"{_LOGIN_PINCODE_LEN}s"
)
_LOGIN_PAYLOAD_SIZE = struct.calcsize(_LOGIN_PAYLOAD_FMT)  # 648 bytes


def _encode_field(value: str, size: int) -> bytes:
    """UTF-8 encode *value* and right-pad/truncate to exactly *size* bytes."""
    encoded = value.encode("utf-8")
    return encoded[:size].ljust(size, b"\x00")


def build_login(
    *,
    credential: str,
    account_id: str,
    passcode: str = "00000000",
    app_label: str = "PlayStation",
    os_version: str = "4.4",
    model: str = "PS4 Waker",
    pin_code: str = "",
) -> bytes:
    """
    Login packet — 8-byte header + 648-byte fixed payload.

    Parameters
    ----------
    credential:
        32-char hex credential string (from SecondScreenCredentials /
        RemotePlayCredentials).
    account_id:
        base64-encoded LE-uint64 account ID.
    passcode:
        4-8 digit passcode string (default ``"00000000"``).
    app_label:
        Identifying string for this client (shown on the PS4/PS5 UI).
    os_version:
        Host OS version string.
    model:
        Host model string.
    pin_code:
        Remote Play PIN code (PS5 only, leave empty for PS4).
    """
    # The ``info`` field carries the account_id, NUL-padded to 8 bytes.
    info_bytes = _encode_field(account_id, _LOGIN_INFO_LEN)

    payload = struct.pack(
        _LOGIN_PAYLOAD_FMT,
        _encode_field(passcode, _LOGIN_PASSCODE_LEN),
        info_bytes,
        _encode_field(credential, _LOGIN_CREDENTIAL_LEN),
        _encode_field(app_label, _LOGIN_APPLABEL_LEN),
        _encode_field(os_version, _LOGIN_OSVERSION_LEN),
        _encode_field(model, _LOGIN_MODEL_LEN),
        _encode_field(pin_code, _LOGIN_PINCODE_LEN),
    )
    return _pack_header(PacketType.LOGIN, payload)


def build_status(status_code: int = 0) -> bytes:
    """
    Status packet — 8-byte header + 4-byte little-endian status code.

    Sent immediately after a successful LoginResult to acknowledge the session.
    """
    payload = struct.pack("<I", status_code)
    return _pack_header(PacketType.STATUS, payload)


def build_standby() -> bytes:
    """
    Standby packet — 8-byte header + 4 zero bytes.

    Instructs the device to enter rest/standby mode.
    """
    payload = struct.pack("<I", 0)
    return _pack_header(PacketType.STANDBY, payload)


def build_remote_control(op: AnyRemoteOp, hold_time: int = 0) -> bytes:
    """
    RemoteControl packet — 8-byte header + 8-byte payload.

    Payload layout::

        u32  op         (RemoteOperation flags or InternalRemoteOperation)
        u32  hold_time  (milliseconds to hold; 0 for instantaneous / open/close)

    Parameters
    ----------
    op:
        The button(s) to press, or an InternalRemoteOperation control code.
    hold_time:
        Duration in milliseconds to hold the button(s).  Use 0 for
        OPEN_RC / CLOSE_RC / KEY_OFF control packets.
    """
    payload = struct.pack("<II", int(op), hold_time)
    return _pack_header(PacketType.REMOTE_CONTROL, payload)


def build_bye() -> bytes:
    """
    Bye packet — 8-byte header + 4 zero bytes.

    Gracefully terminates the TCP session.
    """
    payload = struct.pack("<I", 0)
    return _pack_header(PacketType.BYE, payload)


# ---------------------------------------------------------------------------
# Incoming packet parsers
# ---------------------------------------------------------------------------


@dataclass
class ServerHelloPacket:
    """Parsed ServerHello response from the device."""

    seed: bytes  # 16-byte AES seed used to derive session keys


@dataclass
class LoginResultPacket:
    """Parsed LoginResult response."""

    result_code: int  # 0 = success
    error_code: int  # extended error detail

    @property
    def success(self) -> bool:
        return self.result_code == 0


@dataclass
class StandbyResultPacket:
    """Parsed StandbyResult response."""

    result_code: int

    @property
    def success(self) -> bool:
        return self.result_code == 0


def parse_header(data: bytes) -> tuple[int, int]:
    """
    Parse the 8-byte common header.

    Returns
    -------
    (length, packet_type)
        *length* is the total packet size including the header itself.
        *packet_type* is the raw u32 type code.

    Raises
    ------
    ValueError
        If *data* is shorter than 8 bytes.
    """
    if len(data) < _HEADER_SIZE:
        raise ValueError(f"Header requires {_HEADER_SIZE} bytes, got {len(data)}")
    length, ptype = struct.unpack_from(_HEADER_FMT, data, 0)
    return length, ptype


def parse_server_hello(data: bytes) -> ServerHelloPacket:
    """
    Parse a complete ServerHello packet (header already stripped).

    The device response contains the same seed-offset structure as
    ClientHello; we extract the 16-byte seed starting at byte 20 of the
    payload (offset 0x1C from start of packet, minus the 8-byte header = 20).

    ``data`` should be the full packet bytes including the header.
    """
    # seed starts at byte offset 0x1C (28) from packet start
    seed_offset = 0x1C
    if len(data) < seed_offset + 16:
        raise ValueError(
            f"ServerHello too short: {len(data)} bytes (need at least {seed_offset + 16})"
        )
    seed = data[seed_offset : seed_offset + 16]
    return ServerHelloPacket(seed=seed)


def parse_login_result(payload: bytes) -> LoginResultPacket:
    """
    Parse the payload (after stripping header) of a LoginResult packet.

    Layout::

        u32  result_code
        u32  error_code
    """
    if len(payload) < 8:
        raise ValueError(f"LoginResult payload too short: {len(payload)}")
    result_code, error_code = struct.unpack_from("<II", payload, 0)
    return LoginResultPacket(result_code=result_code, error_code=error_code)


def parse_standby_result(payload: bytes) -> StandbyResultPacket:
    """
    Parse the payload (after stripping header) of a StandbyResult packet.

    Layout::

        u32  result_code
    """
    if len(payload) < 4:
        raise ValueError(f"StandbyResult payload too short: {len(payload)}")
    (result_code,) = struct.unpack_from("<I", payload, 0)
    return StandbyResultPacket(result_code=result_code)
