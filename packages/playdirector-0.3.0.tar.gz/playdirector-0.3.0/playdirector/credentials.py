"""
credentials.py — Credential dataclasses and storage for PS4/PS5.

PS4 credentials (SecondScreenCredentials) are obtained via the MIM/pairing
flow implemented in pairing.py.  PS5 credentials (RemotePlayCredentials) are
obtained via the OAuth + Remote Play device-PIN registration flow.

Persistent storage is a simple per-device-ID JSON file written to a
configurable directory (default: ~/.config/playdirector/).
"""

from __future__ import annotations

import base64
import dataclasses
import json
import struct
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Credential dataclasses
# ---------------------------------------------------------------------------


@dataclass
class SecondScreenCredentials:
    """
    PS4 second-screen ("MIM") credentials.

    ``credential`` is the 32-character hex string derived from the RegistKey
    that appears in the PS App WAKEUP broadcast, as intercepted by the
    pair_ps4_intercept() flow.

    ``account_id`` is the base64-encoded little-endian uint64 representation
    of the PSN user_id, inserted into Login packets.
    """

    device_id: str  # MAC-style identifier used as storage key
    credential: str  # 32-char hex string used in Login packets
    account_id: str  # base64(LE uint64 of PSN user_id)
    registration_key: str  # raw hex RegistKey from WAKEUP broadcast

    # Human-readable label – optional, not sent over the wire
    label: str | None = None


@dataclass
class RemotePlayCredentials:
    """
    PS5 Remote Play credentials.

    ``credential`` is derived from the RegistKey returned during the Remote
    Play device-registration handshake via registkey_to_credential().

    ``account_id`` is the base64-encoded LE-uint64 PSN account ID, computed
    by extract_account_id().
    """

    device_id: str  # used as storage key
    credential: str  # derived 32-char hex credential string
    account_id: str  # base64(LE uint64 of PSN user_id)
    registration_key: str  # raw RegistKey hex returned by device (PS5-RegistKey)
    rp_key: str  # 32-hex-char RP-Key from registration response (16 bytes, session crypto key)
    access_token: str  # PSN OAuth access token (for re-registration)
    refresh_token: str  # PSN OAuth refresh token

    label: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return a plain JSON-serialisable dict for developer-controlled persistence."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RemotePlayCredentials:
        """Reconstruct from a dict previously returned by :meth:`to_dict`."""

        fields = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in fields})


# ---------------------------------------------------------------------------
# Conversion helpers
# ---------------------------------------------------------------------------


def registkey_to_credential(registkey_hex: str) -> str:
    """
    Convert a raw RegistKey hex string to the 32-character credential string
    used in Login packets.

    Mirrors the logic in oauth/requester.ts::
        const buf = Buffer.from(registKey, 'hex');
        const str = buf.toString('utf8');
        const hex = Buffer.from(str, 'hex');
        const num = parseInt(hex.toString(), 16);   // big-endian parse
        return num.toString();

    Steps:
      1. Hex-decode the raw RegistKey bytes.
      2. Interpret those bytes as a UTF-8 string (the intermediate hex string).
      3. Hex-decode *that* string to get the final raw bytes.
      4. Parse those bytes as a big-endian integer and return its decimal
         string representation.
    """
    # Step 1 – hex → bytes
    raw_bytes = bytes.fromhex(registkey_hex)
    # Step 2 – bytes → UTF-8 string (itself a hex string)
    intermediate_hex = raw_bytes.decode("utf-8")
    # Step 3 – hex → bytes (final raw bytes)
    final_bytes = bytes.fromhex(intermediate_hex)
    # Step 4 – big-endian int → decimal string
    value = int.from_bytes(final_bytes, byteorder="big")
    return str(value)


def extract_account_id(user_id: int) -> str:
    """
    Convert a numeric PSN user_id to the base64-encoded little-endian uint64
    string used in Login packets.

    Mirrors the logic in oauth/requester.ts::
        const buf = Buffer.allocUnsafe(8);
        buf.writeBigUInt64LE(BigInt(userId));
        return buf.toString('base64');
    """
    packed = struct.pack("<Q", user_id)  # little-endian unsigned 64-bit
    return base64.b64encode(packed).decode("ascii")


# ---------------------------------------------------------------------------
# JSON credential storage
# ---------------------------------------------------------------------------

_DEFAULT_STORAGE_DIR = Path.home() / ".config" / "playdirector"


class JsonCredentialStorage:
    """
    Reads and writes credential files as JSON.

    Each device gets its own file:  ``<storage_dir>/<device_id>.json``

    Usage::

        storage = JsonCredentialStorage()
        cred = storage.load("AA:BB:CC:DD:EE:FF")   # returns None if absent
        storage.save(cred)
    """

    def __init__(self, storage_dir: Path | None = None) -> None:
        self._dir = Path(storage_dir) if storage_dir else _DEFAULT_STORAGE_DIR
        self._dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _path_for(self, device_id: str) -> Path:
        safe = device_id.replace(":", "_").replace("/", "_")
        return self._dir / f"{safe}.json"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self, device_id: str) -> SecondScreenCredentials | RemotePlayCredentials | None:
        """Return the stored credential for *device_id*, or ``None``."""
        p = self._path_for(device_id)
        if not p.exists():
            return None
        data = json.loads(p.read_text())
        cred_type = data.pop("_type", None)
        if cred_type == "RemotePlayCredentials":
            return RemotePlayCredentials(**data)
        if cred_type == "SecondScreenCredentials":
            return SecondScreenCredentials(**data)
        raise ValueError(f"Unknown credential type '{cred_type}' in {p}")

    def save(self, cred: SecondScreenCredentials | RemotePlayCredentials) -> None:
        """Persist *cred* to disk, overwriting any existing file."""
        p = self._path_for(cred.device_id)
        data = asdict(cred)
        data["_type"] = type(cred).__name__
        p.write_text(json.dumps(data, indent=2))

    def delete(self, device_id: str) -> bool:
        """Remove the stored credential for *device_id*. Returns True if deleted."""
        p = self._path_for(device_id)
        if p.exists():
            p.unlink()
            return True
        return False

    def list_device_ids(self) -> list[str]:
        """Return all device IDs that have stored credentials."""
        ids = []
        for p in self._dir.glob("*.json"):
            try:
                data = json.loads(p.read_text())
                ids.append(data.get("device_id", p.stem))
            except (json.JSONDecodeError, KeyError):
                pass
        return ids
