"""
playstation.py — Public API for playdirector.

This module is the single entry point for library users.  Import from here
(or from the top-level ``playdirector`` package) rather than from the
internal sub-modules.

Functions
---------
``scan(timeout)``
    Async generator — yields every :class:`DiscoveredDevice` found on the
    local network within *timeout* seconds.

``find(ip, timeout)``
    Targeted lookup — probe a known IP and return the device or ``None``.

``pair(ip, pin, npsso)``
    One-time PS4/PS5 pairing; returns stored credentials.

``wake(device, credential)``
    Send UDP WAKEUP datagrams — no full session required.

``connect(device, credential)``
    Async context manager — open a full authenticated :class:`Session`.

``standby(device, credential)``
    Convenience: connect and immediately enter standby (PS4 + PS5).

``send_buttons(device, credential, keys)``
    Convenience: connect and send button inputs (PS4 only).

``go_home(device, credential)``
    Convenience: connect and navigate to the home screen (PS5 only).

Typical usage
-------------
::

    import asyncio
    from playdirector import find, connect, RemoteOperation
    from playdirector.credentials import JsonCredentialStorage

    async def main():
        storage = JsonCredentialStorage()

        device = await find("192.168.1.50")
        if device is None:
            print("Device not found")
            return

        cred = storage.load(device.device_id)
        if cred is None:
            print("No credentials — pair first")
            return

        async with connect(device, cred) as session:
            await session.send_keys([RemoteOperation.PS])

    asyncio.run(main())
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from enum import StrEnum

from .connection import (
    LoginError,  # re-exported for callers
    Session,
    SessionInitError,  # re-exported for callers
    UnsupportedDeviceError,  # re-exported for callers
    _send_udp_priming,
    session_context,
)
from .credentials import (
    JsonCredentialStorage,
    RemotePlayCredentials,
    SecondScreenCredentials,
)
from .discovery import (
    PS4_DISCOVERY_PORT,
    PS5_DISCOVERY_PORT,
    DeviceStatus,
    DeviceType,
    DiscoveredDevice,
    _probe,
    scan,
)
from .exceptions import (
    PlayDirectorConnectionError,
    PlayDirectorCredentialsError,
    PlayDirectorDeviceError,
    PlayDirectorError,
    PlayDirectorNotSupportedError,
    PlayDirectorPairingError,
)
from .packets import InternalRemoteOperation, RemoteOperation
from .pairing import pair_ps4, pair_ps5

logger = logging.getLogger(__name__)


class SystemStatus(StrEnum):
    """
    The power / availability state of a PlayStation console as reported by
    the DDP discovery protocol.

    Values mirror what Sony's firmware returns so integrations can match
    against well-known strings without hard-coding magic numbers.
    """

    AWAKE = "awake"  # HTTP 200 Ok  — console is on and ready
    STANDBY = "standby"  # HTTP 620     — console is in rest/standby mode
    OFFLINE = "offline"  # No response  — console is off or unreachable


# Re-export everything callers are likely to need from a single import
__all__ = [
    # Core API
    "pair",
    "scan",
    "get_status",
    "find",
    "wake",
    "connect",
    "standby",
    "send_buttons",
    "go_home",
    # Useful types / enums
    "DiscoveredDevice",
    "DeviceType",
    "DeviceStatus",
    "Session",
    "RemoteOperation",
    "InternalRemoteOperation",
    # Credentials
    "SecondScreenCredentials",
    "RemotePlayCredentials",
    "JsonCredentialStorage",
    # Errors (public hierarchy)
    "PlayDirectorError",
    "PlayDirectorConnectionError",
    "PlayDirectorDeviceError",
    "PlayDirectorNotSupportedError",
    "PlayDirectorPairingError",
    "PlayDirectorCredentialsError",
    # Errors (internal — kept for backwards compatibility)
    "LoginError",
    "SessionInitError",
    "UnsupportedDeviceError",
    # Status enum
    "SystemStatus",
]

# ---------------------------------------------------------------------------
# get_status()
# ---------------------------------------------------------------------------


async def get_status(
    ip: str,
    *,
    timeout: float = 5.0,
) -> SystemStatus:
    """
    Return the current power state of a PlayStation console.

    Sends a single DDP discovery probe to *ip* and translates the response
    into a :class:`SystemStatus` value.  No credentials are required.

    Parameters
    ----------
    ip:
        IP address of the console to query.
    timeout:
        Seconds to wait for a DDP response before considering the device
        offline.

    Returns
    -------
    SystemStatus
        * :attr:`~SystemStatus.AWAKE`   — console is on and responding.
        * :attr:`~SystemStatus.STANDBY` — console is in rest/standby mode.
        * :attr:`~SystemStatus.OFFLINE` — no response within *timeout*.

    Example
    -------
    ::

        status = await get_status("192.168.1.50")
        if status == SystemStatus.AWAKE:
            print("Console is on!")
        elif status == SystemStatus.STANDBY:
            print("Console is in rest mode — call wake() first")
        else:
            print("Console appears to be off or unreachable")
    """
    device = await _probe(ip=ip, timeout=timeout)
    if device is None:
        return SystemStatus.OFFLINE
    if device.status == DeviceStatus.STANDBY:
        return SystemStatus.STANDBY
    return SystemStatus.AWAKE


# ---------------------------------------------------------------------------
# pair()
# ---------------------------------------------------------------------------


async def pair(
    ip: str,
    pin: str,
    npsso: str,
    *,
    timeout: float = 5.0,
) -> RemotePlayCredentials:
    """
    One-time pairing flow for PS4 or PS5 — call this once per console.

    Probes *ip* to identify the device type, then runs the appropriate
    pairing handshake.  The returned credentials should be saved with
    :class:`~playdirector.credentials.JsonCredentialStorage`.

    Parameters
    ----------
    ip:
        Local IP address of the console.
    pin:
        The 8-digit PIN shown on the console:

        * **PS5** — Settings → System → Remote Play → Link Device
        * **PS4** — Settings → Remote Play Connection Settings → Add Device
    npsso:
        Your PSN NPSSO token.  Obtain it by visiting
        ``https://ca.account.sony.com/api/v1/ssocookie`` after logging in.
    timeout:
        Seconds to wait for the device probe.

    Returns
    -------
    RemotePlayCredentials
        Call ``.to_dict()`` to serialise to JSON for storage.

    Raises
    ------
    RuntimeError
        If no device is found at *ip* within *timeout* seconds.
    PairingError
        On invalid PIN or registration failure.
    """
    device = await _probe(ip=ip, timeout=timeout)
    if device is None:
        raise PlayDirectorConnectionError(f"No device found at {ip} — check the IP and network.")
    if device.device_type == DeviceType.PS5:
        return await pair_ps5(device, pin=pin, npsso=npsso)
    return await pair_ps4(device, pin=pin, npsso=npsso)


# ---------------------------------------------------------------------------
# find()
# ---------------------------------------------------------------------------


async def find(
    ip: str,
    *,
    timeout: float = 5.0,
) -> DiscoveredDevice | None:
    """
    Probe a known IP address and return the device if it responds.

    Use this when you already know the console's IP.  For network-wide
    discovery of all devices use :func:`scan` instead.

    Parameters
    ----------
    ip:
        IP address of the console to probe.
    timeout:
        Seconds to wait for a response.

    Returns
    -------
    DiscoveredDevice or None
        The device if it responded within *timeout*, otherwise ``None``.

    Example
    -------
    ::

        device = await find("192.168.1.50")
        if device:
            print(device.name, device.status)
    """
    return await _probe(ip=ip, timeout=timeout)


# ---------------------------------------------------------------------------
# wake()
# ---------------------------------------------------------------------------
async def wake(
    device: DiscoveredDevice,
    credential: SecondScreenCredentials | RemotePlayCredentials,
) -> None:
    """
    Send UDP WAKEUP datagrams to bring a device out of standby.

    Unlike :func:`standby`, :func:`send_buttons`, and :func:`go_home`, this
    function does **not** open a TCP session — waking a console is a
    fire-and-forget UDP operation and must happen before any session is
    possible.

    After calling ``wake()``, poll :func:`find` until the device's
    :attr:`~playdirector.discovery.DiscoveredDevice.status` changes to
    :attr:`~playdirector.discovery.DeviceStatus.AWAKE` before connecting.

    Parameters
    ----------
    device:
        The device to wake.
    credential:
        A valid credential for the device (used in the WAKEUP header).

    Example
    -------
    ::

        device = await find("192.168.1.50")
        await wake(device, cred)

        import asyncio
        for _ in range(30):
            await asyncio.sleep(2)
            refreshed = await find(device.ip)
            if refreshed and refreshed.status == DeviceStatus.AWAKE:
                break
    """
    udp_port = PS5_DISCOVERY_PORT if device.device_type == DeviceType.PS5 else PS4_DISCOVERY_PORT
    is_rp = isinstance(credential, RemotePlayCredentials)
    await _send_udp_priming(device.ip, udp_port, credential.credential, is_remote_play=is_rp)
    logger.info("WAKEUP sent to %s", device.ip)


# ---------------------------------------------------------------------------
# connect()
# ---------------------------------------------------------------------------


@asynccontextmanager
async def connect(
    device: DiscoveredDevice,
    credential: SecondScreenCredentials | RemotePlayCredentials,
    *,
    connect_timeout: float = 10.0,
    login_timeout: float = 15.0,
) -> AsyncIterator[Session]:
    """
    Open an authenticated session as an async context manager.

    Use this when you need to perform **multiple operations** in one connection
    without reconnecting between them.  For single operations, prefer the
    convenience functions :func:`standby`, :func:`send_buttons`, and
    :func:`go_home` — they handle connecting and disconnecting for you.

    On exit the session is closed gracefully (Bye packet sent).

    Parameters
    ----------
    device:
        A :class:`~playdirector.discovery.DiscoveredDevice`.
    credential:
        A :class:`~playdirector.credentials.SecondScreenCredentials` (PS4) or
        :class:`~playdirector.credentials.RemotePlayCredentials` (PS5).
    connect_timeout:
        TCP connection timeout in seconds.
    login_timeout:
        Time allowed for the full handshake + login sequence in seconds.

    Yields
    ------
    Session
        An authenticated :class:`~playdirector.connection.Session`.

    Raises
    ------
    LoginError
        If the device rejects the login credentials.
    UnsupportedDeviceError
        If you call :meth:`~playdirector.connection.Session.send_buttons` on a PS5.
    PlayDirectorError
        For other protocol-level errors.

    Example
    -------
    ::

        # Multiple operations in one session:
        async with connect(device, cred) as session:
            await session.send_keys([RemoteOperation.UP])
            await session.send_keys([RemoteOperation.ENTER])
            await session.standby()
    """
    async with session_context(
        device,
        credential,
        connect_timeout=connect_timeout,
        login_timeout=login_timeout,
    ) as session:
        yield session


# ---------------------------------------------------------------------------
# standby()
# ---------------------------------------------------------------------------


async def standby(
    device: DiscoveredDevice,
    credential: SecondScreenCredentials | RemotePlayCredentials,
    *,
    connect_timeout: float = 10.0,
    login_timeout: float = 15.0,
) -> None:
    """
    Connect to *device* and immediately enter standby (rest mode).

    Works on both PS4 and PS5.

    Parameters
    ----------
    device:
        A :class:`~playdirector.discovery.DiscoveredDevice`.
    credential:
        A valid credential for the device.
    connect_timeout:
        TCP connection timeout in seconds.
    login_timeout:
        Time allowed for the full handshake + login sequence in seconds.

    Example
    -------
    ::

        device = await find("192.168.1.50")
        await standby(device, cred)
    """
    async with session_context(
        device,
        credential,
        connect_timeout=connect_timeout,
        login_timeout=login_timeout,
    ) as session:
        await session.standby()


# ---------------------------------------------------------------------------
# send_buttons()
# ---------------------------------------------------------------------------


async def send_buttons(
    device: DiscoveredDevice,
    credential: SecondScreenCredentials | RemotePlayCredentials,
    operations: list[RemoteOperation],
    *,
    hold_time: int = 0,
    connect_timeout: float = 10.0,
    login_timeout: float = 15.0,
) -> None:
    """
    Connect to a PS4 and send one or more button inputs.

    Raises :exc:`UnsupportedDeviceError` if called on a PS5.

    Parameters
    ----------
    device:
        A PS4 :class:`~playdirector.discovery.DiscoveredDevice`.
    credential:
        A valid credential for the device.
    operations:
        One or more :class:`~playdirector.packets.RemoteOperation` values.
    hold_time:
        Duration in milliseconds to hold each button.  0 = tap.
    connect_timeout:
        TCP connection timeout in seconds.
    login_timeout:
        Time allowed for the full handshake + login sequence in seconds.

    Raises
    ------
    UnsupportedDeviceError
        If *device* is a PS5.

    Example
    -------
    ::

        device = await find("192.168.1.100")  # PS4
        await send_buttons(device, cred, [RemoteOperation.PS])
    """
    async with session_context(
        device,
        credential,
        connect_timeout=connect_timeout,
        login_timeout=login_timeout,
    ) as session:
        await session.send_keys(operations, hold_time=hold_time)


# ---------------------------------------------------------------------------
# go_home()
# ---------------------------------------------------------------------------


async def go_home(
    device: DiscoveredDevice,
    credential: RemotePlayCredentials,
    *,
    connect_timeout: float = 10.0,
    login_timeout: float = 15.0,
) -> None:
    """
    Connect to a PS5 and navigate to the home screen.

    Parameters
    ----------
    device:
        A PS5 :class:`~playdirector.discovery.DiscoveredDevice`.
    credential:
        A :class:`~playdirector.credentials.RemotePlayCredentials`.
    connect_timeout:
        TCP connection timeout in seconds.
    login_timeout:
        Time allowed for the full handshake + login sequence in seconds.

    Raises
    ------
    UnsupportedDeviceError
        If *device* is not a PS5.
    LoginError
        If the device rejects the login credentials.

    Example
    -------
    ::

        device = await find("192.168.1.50")  # PS5
        await go_home(device, cred)
    """
    if device.device_type != DeviceType.PS5:
        raise UnsupportedDeviceError("go_home() is only supported on PS5 devices.")
    async with session_context(
        device,
        credential,
        connect_timeout=connect_timeout,
        login_timeout=login_timeout,
    ) as session:
        await session.go_home()
