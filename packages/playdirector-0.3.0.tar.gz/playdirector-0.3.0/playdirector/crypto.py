"""
crypto.py — AES-128-CBC streaming codec for the PS4/PS5 second-screen protocol.

After the Handshake completes, all TCP traffic is encrypted with AES-128-CBC
using the 16-byte seed exchanged in the Hello packets.

Key derivation
--------------
The seed from ServerHello is used directly as both the AES key and IV
(matching the behaviour of crypto-codec.ts in the original project).

Streaming semantics
-------------------
AES-CBC operates on 16-byte blocks.  The original TypeScript codec accumulates
partial blocks in an internal buffer and only decrypts complete 16-byte aligned
chunks — this module replicates that behaviour exactly so that the TCP stream
can be fed in arbitrary-sized chunks without block-boundary issues.

Usage::

    from playdirector.crypto import CryptoCodec

    codec = CryptoCodec(seed=seed_bytes)     # seed is 16 bytes

    # Encrypt a complete message before sending
    ciphertext = codec.encode(plaintext)

    # Feed raw TCP bytes; decoded plaintext is returned when full blocks arrive
    plaintext = codec.decode(ciphertext_chunk)
"""

from __future__ import annotations

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

_BLOCK_SIZE = 16  # AES block size in bytes


class CryptoCodec:
    """
    Stateful AES-128-CBC streaming codec.

    A single instance maintains independent encryptor and decryptor contexts
    so that the IV chaining state is preserved across multiple calls, exactly
    as a streaming CBC codec must work.

    Parameters
    ----------
    seed:
        16-byte seed from the ServerHello packet.  Used as both the AES-128
        key and the initial IV.
    """

    def __init__(self, seed: bytes) -> None:
        if len(seed) != _BLOCK_SIZE:
            raise ValueError(f"AES seed must be {_BLOCK_SIZE} bytes, got {len(seed)}")
        self._seed = seed
        enc_cipher = Cipher(algorithms.AES(seed), modes.CBC(seed))
        dec_cipher = Cipher(algorithms.AES(seed), modes.CBC(seed))
        self._encryptor = enc_cipher.encryptor()
        self._decryptor = dec_cipher.decryptor()

        # Buffer for incomplete incoming blocks (decode side only)
        self._decode_buffer = bytearray()

    # ------------------------------------------------------------------
    # Encode (outgoing)
    # ------------------------------------------------------------------

    def encode(self, data: bytes) -> bytes:
        """
        Encrypt *data* and return the ciphertext.

        If *data* is not a multiple of 16 bytes it is zero-padded to the next
        16-byte boundary before encryption — matching the behaviour of
        crypto-codec.ts which pads with ``0x00`` bytes.

        The encryptor context is stateful: the CBC IV for the next call is
        automatically derived from the last ciphertext block.
        """
        if not data:
            return b""
        remainder = len(data) % _BLOCK_SIZE
        if remainder:
            data = data + b"\x00" * (_BLOCK_SIZE - remainder)
        return self._encryptor.update(data)

    # ------------------------------------------------------------------
    # Decode (incoming)
    # ------------------------------------------------------------------

    def decode(self, data: bytes) -> bytes:
        """
        Decrypt *data* and return whatever complete plaintext blocks are ready.

        Incomplete blocks are buffered internally and will be included once
        enough bytes have accumulated.  This mirrors the chunk-buffering logic
        in ``crypto-codec.ts``::

            // accumulate
            this._buf = Buffer.concat([this._buf, data]);
            const alignedLen = Math.floor(this._buf.length / 16) * 16;
            if (!alignedLen) return;
            const toDecrypt = this._buf.slice(0, alignedLen);
            this._buf = this._buf.slice(alignedLen);
            // decrypt complete blocks
            return this._decipher.update(toDecrypt);

        Parameters
        ----------
        data:
            Raw bytes received from the TCP stream (may be any size).

        Returns
        -------
        bytes
            Decrypted plaintext for all complete 16-byte blocks available so
            far.  May be empty if there aren't enough bytes yet.
        """
        if not data:
            return b""

        self._decode_buffer.extend(data)

        aligned_len = (len(self._decode_buffer) // _BLOCK_SIZE) * _BLOCK_SIZE
        if aligned_len == 0:
            return b""

        to_decrypt = bytes(self._decode_buffer[:aligned_len])
        self._decode_buffer = self._decode_buffer[aligned_len:]

        return self._decryptor.update(to_decrypt)

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @property
    def pending_bytes(self) -> int:
        """Number of bytes buffered but not yet decryptable."""
        return len(self._decode_buffer)
