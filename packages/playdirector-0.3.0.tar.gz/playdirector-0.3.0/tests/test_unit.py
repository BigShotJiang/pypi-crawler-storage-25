"""
tests/test_unit.py — Unit tests for playdirector (no hardware required).

Run with:  uv run pytest  (or .venv/bin/pytest)
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import struct
import struct as _struct
import tempfile
from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from cryptography.hazmat.primitives.serialization import load_der_public_key

from playdirector import (
    PlayDirectorConnectionError,
    PlayDirectorCredentialsError,
    PlayDirectorError,
    connect,
    find,
    go_home,
    pair,
    send_buttons,
    standby,
    wake,
)
from playdirector.auth_keys import AUTH_NONCE_KEYS_PS5, AUTH_SEED_KEYS_PS5
from playdirector.connection import (
    _HANDSHAKE_PUBLIC_KEY_DER,
    _LAUNCH_FMT_RP,
    _LAUNCH_FMT_SS,
    _WAKEUP_FMT_RP,
    _WAKEUP_FMT_SS,
    LoginError,
    ProtocolError,
    StandbyError,
    UnsupportedDeviceError,
    _rsa_encrypt_seed,
)

# ---------------------------------------------------------------------------
# credentials
# ---------------------------------------------------------------------------
from playdirector.credentials import (
    JsonCredentialStorage,
    RemotePlayCredentials,
    SecondScreenCredentials,
    extract_account_id,
    registkey_to_credential,
)
from playdirector.crypto import CryptoCodec
from playdirector.discovery import (
    DeviceStatus,
    DeviceType,
    DiscoveredDevice,
    _parse_ddp_response,
)
from playdirector.packets import (
    InternalRemoteOperation,
    PacketType,
    RemoteOperation,
    build_bye,
    build_client_hello,
    build_handshake,
    build_login,
    build_remote_control,
    build_standby,
    build_status,
    parse_header,
    parse_login_result,
    parse_server_hello,
    parse_standby_result,
)
from playdirector.pairing import (
    _AesCfbCodec,
    _generate_aeropause_ps4,
    _generate_aeropause_ps5,
    _generate_iv_ps4,
    _generate_iv_ps5,
    _generate_seed_ps4,
    _generate_seed_ps5,
    _parse_ddp_headers,
    _parse_registration_body,
    _RemotePlayCrypto,
)
from playdirector.remoteplay_session import (
    _derive_auth_nonce,
    _derive_auth_seed,
    _generate_iv,
    _RemotePlayCodec,
)


class TestExtractAccountId:
    def test_known_value(self):
        aid = extract_account_id(123456789)
        decoded = struct.unpack("<Q", base64.b64decode(aid))[0]
        assert decoded == 123456789

    def test_zero(self):
        aid = extract_account_id(0)
        decoded = struct.unpack("<Q", base64.b64decode(aid))[0]
        assert decoded == 0

    def test_max_u64(self):
        max_val = 2**64 - 1
        aid = extract_account_id(max_val)
        decoded = struct.unpack("<Q", base64.b64decode(aid))[0]
        assert decoded == max_val

    def test_returns_ascii_string(self):
        aid = extract_account_id(1)
        assert isinstance(aid, str)
        base64.b64decode(aid)  # must not raise


class TestRegistkeyToCredential:
    def _build_registkey(self, inner_hex: str) -> str:
        """Construct a synthetic RegistKey hex that round-trips through the converter."""
        return inner_hex.encode("utf-8").hex()

    def test_deadbeef(self):
        rk = self._build_registkey("deadbeef")
        result = registkey_to_credential(rk)
        assert result == str(int("deadbeef", 16))

    def test_all_zeros(self):
        rk = self._build_registkey("00000000")
        result = registkey_to_credential(rk)
        assert result == "0"

    def test_returns_string(self):
        rk = self._build_registkey("ff")
        result = registkey_to_credential(rk)
        assert isinstance(result, str)
        int(result)  # must be a valid integer string


class TestJsonCredentialStorage:
    def _make_ps4_cred(self, device_id: str = "AA:BB:CC:DD:EE:FF") -> SecondScreenCredentials:
        return SecondScreenCredentials(
            device_id=device_id,
            credential="c" * 32,
            account_id=extract_account_id(42),
            registration_key="ab" * 16,
            label="test-ps4",
        )

    def _make_ps5_cred(self, device_id: str = "ps5-dev") -> RemotePlayCredentials:
        return RemotePlayCredentials(
            device_id=device_id,
            credential="d" * 32,
            account_id=extract_account_id(99),
            registration_key="cd" * 16,
            rp_key="ab" * 16,
            access_token="access",
            refresh_token="refresh",
        )

    def test_save_load_ps4(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = JsonCredentialStorage(tmpdir)
            cred = self._make_ps4_cred()
            storage.save(cred)
            loaded = storage.load(cred.device_id)
            assert isinstance(loaded, SecondScreenCredentials)
            assert loaded.credential == cred.credential
            assert loaded.label == cred.label

    def test_save_load_ps5(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = JsonCredentialStorage(tmpdir)
            cred = self._make_ps5_cred()
            storage.save(cred)
            loaded = storage.load(cred.device_id)
            assert isinstance(loaded, RemotePlayCredentials)
            assert loaded.access_token == "access"
            assert loaded.refresh_token == "refresh"

    def test_load_missing_returns_none(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = JsonCredentialStorage(tmpdir)
            assert storage.load("nonexistent") is None

    def test_delete(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = JsonCredentialStorage(tmpdir)
            cred = self._make_ps4_cred()
            storage.save(cred)
            assert storage.delete(cred.device_id) is True
            assert storage.load(cred.device_id) is None
            assert storage.delete(cred.device_id) is False

    def test_list_device_ids(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = JsonCredentialStorage(tmpdir)
            storage.save(self._make_ps4_cred("dev-1"))
            storage.save(self._make_ps4_cred("dev-2"))
            storage.save(self._make_ps5_cred("dev-3"))
            ids = storage.list_device_ids()
            assert set(ids) == {"dev-1", "dev-2", "dev-3"}

    def test_overwrite(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = JsonCredentialStorage(tmpdir)
            cred1 = self._make_ps4_cred()
            storage.save(cred1)
            cred2 = SecondScreenCredentials(
                device_id=cred1.device_id,
                credential="z" * 32,
                account_id=cred1.account_id,
                registration_key=cred1.registration_key,
            )
            storage.save(cred2)
            loaded = storage.load(cred1.device_id)
            assert loaded.credential == "z" * 32


class TestRemotePlayCredentialsSerialization:
    def _make(self) -> RemotePlayCredentials:
        return RemotePlayCredentials(
            device_id="test-ps5",
            credential="c" * 32,
            account_id=extract_account_id(7),
            registration_key="ab" * 16,
            rp_key="ef" * 16,
            access_token="tok_access",
            refresh_token="tok_refresh",
            label="my ps5",
        )

    def test_to_dict_round_trip(self):
        cred = self._make()
        d = cred.to_dict()
        restored = RemotePlayCredentials.from_dict(d)
        assert restored == cred

    def test_to_dict_contains_rp_key(self):
        assert "rp_key" in self._make().to_dict()

    def test_from_dict_ignores_unknown_keys(self):
        d = self._make().to_dict()
        d["unknown_future_field"] = "ignored"
        restored = RemotePlayCredentials.from_dict(d)
        assert restored.device_id == "test-ps5"


class TestSecondScreenCredentialsSerialization:
    def _make(self) -> SecondScreenCredentials:
        return SecondScreenCredentials(
            device_id="AA:BB:CC:DD:EE:FF",
            credential="c" * 32,
            account_id=extract_account_id(42),
            registration_key="ab" * 16,
            label="living room",
        )

    def test_round_trip_via_storage(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = JsonCredentialStorage(tmpdir)
            cred = self._make()
            storage.save(cred)
            loaded = storage.load(cred.device_id)
            assert isinstance(loaded, SecondScreenCredentials)
            assert loaded.credential == cred.credential
            assert loaded.label == cred.label

    def test_label_optional(self):
        cred = SecondScreenCredentials(
            device_id="X",
            credential="c" * 32,
            account_id=extract_account_id(1),
            registration_key="ab" * 16,
        )
        assert cred.label is None


# ---------------------------------------------------------------------------
# packets
# ---------------------------------------------------------------------------


class TestBuildClientHello:
    def test_total_size(self):
        pkt = build_client_hello()
        assert len(pkt) == 28

    def test_header(self):
        pkt = build_client_hello()
        length, ptype = parse_header(pkt)
        assert length == 28
        assert ptype == PacketType.CLIENT_HELLO

    def test_seed_offset_field(self):
        pkt = build_client_hello()
        # payload starts at byte 8; seed_offset is first u32 in payload
        (seed_offset,) = struct.unpack_from("<I", pkt, 8)
        assert seed_offset == 0x1C


class TestBuildHandshake:
    def test_correct_size(self):
        pkt = build_handshake(b"\xff" * 256)
        # 8 header + 256 payload
        assert len(pkt) == 264

    def test_wrong_size_raises(self):
        with pytest.raises(ValueError, match="256 bytes"):
            build_handshake(b"\x00" * 100)


class TestBuildLogin:
    def test_packet_type(self):
        pkt = build_login(credential="a" * 32, account_id="AAAA")
        _, ptype = parse_header(pkt)
        assert ptype == PacketType.LOGIN

    def test_total_size(self):
        pkt = build_login(credential="a" * 32, account_id="AAAA")
        # header(8) + 648 payload = 656
        length, _ = parse_header(pkt)
        assert length == 656
        assert len(pkt) == 656

    def test_credential_in_payload(self):
        cred = "abcdef1234567890" * 2  # 32 chars
        pkt = build_login(credential=cred, account_id="Z")
        # credential field starts at byte 8 (header) + 32 (passcode) + 8 (info) = 48
        raw_cred = pkt[48 : 48 + 64].rstrip(b"\x00")
        assert raw_cred == cred.encode("utf-8")


class TestBuildStandbyByeStatus:
    def test_standby_type(self):
        assert parse_header(build_standby())[1] == PacketType.STANDBY

    def test_bye_type(self):
        assert parse_header(build_bye())[1] == PacketType.BYE

    def test_status_type(self):
        assert parse_header(build_status(0))[1] == PacketType.STATUS

    def test_standby_minimal_size(self):
        pkt = build_standby()
        assert len(pkt) >= 8  # at minimum a valid header

    def test_bye_minimal_size(self):
        pkt = build_bye()
        assert len(pkt) >= 8

    def test_status_value_encoded(self):
        # status 1 vs 0 should produce different packets
        assert build_status(0) != build_status(1)


class TestBuildRemoteControl:
    def test_packet_type(self):
        pkt = build_remote_control(RemoteOperation.PS)
        assert parse_header(pkt)[1] == PacketType.REMOTE_CONTROL

    def test_op_and_hold_time_encoded(self):
        pkt = build_remote_control(RemoteOperation.ENTER, hold_time=500)
        # payload at offset 8: u32 op, u32 hold_time
        op, ht = struct.unpack_from("<II", pkt, 8)
        assert op == int(RemoteOperation.ENTER)
        assert ht == 500

    def test_open_rc_internal_op(self):
        pkt = build_remote_control(InternalRemoteOperation.OPEN_RC)
        op, ht = struct.unpack_from("<II", pkt, 8)
        assert op == int(InternalRemoteOperation.OPEN_RC)
        assert ht == 0


class TestParsePackets:
    def test_parse_login_result_success(self):
        payload = struct.pack("<II", 0, 0)
        result = parse_login_result(payload)
        assert result.success
        assert result.result_code == 0

    def test_parse_login_result_failure(self):
        payload = struct.pack("<II", 0x80, 0x12)
        result = parse_login_result(payload)
        assert not result.success
        assert result.error_code == 0x12

    def test_parse_standby_result_success(self):
        assert parse_standby_result(struct.pack("<I", 0)).success

    def test_parse_standby_result_failure(self):
        assert not parse_standby_result(struct.pack("<I", 1)).success

    def test_parse_server_hello_seed(self):
        data = bytearray(32)
        seed = bytes(range(16))
        data[0x1C : 0x1C + 16] = seed
        sh = parse_server_hello(bytes(data))
        assert sh.seed == seed

    def test_parse_header_too_short(self):
        with pytest.raises(ValueError, match="Header requires"):
            parse_header(b"\x00" * 4)


class TestRemoteOperationEnum:
    def test_individual_values(self):
        assert int(RemoteOperation.UP) == 0x0001
        assert int(RemoteOperation.DOWN) == 0x0002
        assert int(RemoteOperation.RIGHT) == 0x0004
        assert int(RemoteOperation.LEFT) == 0x0008
        assert int(RemoteOperation.ENTER) == 0x0010
        assert int(RemoteOperation.BACK) == 0x0020
        assert int(RemoteOperation.OPTION) == 0x0040
        assert int(RemoteOperation.PS) == 0x0080
        assert int(RemoteOperation.CANCEL) == 0x0200

    def test_flag_combination(self):
        combo = RemoteOperation.UP | RemoteOperation.LEFT
        assert int(combo) == 0x0009

    def test_internal_ops(self):
        assert int(InternalRemoteOperation.KEY_OFF) == 0x0100
        assert int(InternalRemoteOperation.OPEN_RC) == 0x0400
        assert int(InternalRemoteOperation.CLOSE_RC) == 0x0800


# ---------------------------------------------------------------------------
# crypto
# ---------------------------------------------------------------------------


class TestCryptoCodec:
    SEED = bytes(range(16))

    def _enc(self) -> CryptoCodec:
        return CryptoCodec(self.SEED)

    def _dec(self) -> CryptoCodec:
        return CryptoCodec(self.SEED)

    def test_wrong_seed_length(self):
        with pytest.raises(ValueError, match="16 bytes"):
            CryptoCodec(b"\x00" * 8)

    def test_encode_pads_to_block(self):
        enc = self._enc()
        ct = enc.encode(b"A" * 10)  # 10 → pad to 16
        assert len(ct) == 16

    def test_encode_already_aligned(self):
        enc = self._enc()
        ct = enc.encode(b"B" * 16)
        assert len(ct) == 16

    def test_encode_decode_roundtrip(self):
        enc = self._enc()
        dec = self._dec()
        msg = b"Hello PlayStation!"  # 18 bytes → pads to 32
        ct = enc.encode(msg)
        pt = dec.decode(ct)
        assert pt[: len(msg)] == msg
        assert pt[len(msg) :] == b"\x00" * (len(pt) - len(msg))

    def test_decode_buffers_partial_block(self):
        enc = self._enc()
        dec = self._dec()
        ct = enc.encode(b"C" * 32)
        # Feed only 10 bytes — nothing should come back yet
        r1 = dec.decode(ct[:10])
        assert r1 == b""
        assert dec.pending_bytes == 10
        # Feed remaining 22 bytes — should get 32 plaintext bytes
        r2 = dec.decode(ct[10:])
        assert len(r2) == 32
        assert dec.pending_bytes == 0

    def test_decode_streaming_single_bytes(self):
        enc = self._enc()
        dec = self._dec()
        msg = b"D" * 16
        ct = enc.encode(msg)
        result = b""
        for byte in ct:
            result += dec.decode(bytes([byte]))
        assert result == msg

    def test_encode_empty(self):
        enc = self._enc()
        assert enc.encode(b"") == b""

    def test_decode_empty(self):
        dec = self._dec()
        assert dec.decode(b"") == b""

    def test_stateful_chaining(self):
        """Encode two messages; decode must maintain CBC IV state."""
        enc = self._enc()
        dec = self._dec()
        m1 = b"First message!!!"  # exactly 16 bytes
        m2 = b"Second message!!"  # exactly 16 bytes
        ct = enc.encode(m1) + enc.encode(m2)
        pt = dec.decode(ct)
        assert pt == m1 + m2


# ---------------------------------------------------------------------------
# discovery
# ---------------------------------------------------------------------------


class TestParseDdpResponse:
    def _awake_ps4(self) -> bytes:
        return (
            b"HTTP/1.1 200 Ok\r\n"
            b"host-id:AA:BB:CC:DD:EE:FF\r\n"
            b"host-type:PS4\r\n"
            b"host-name:Living Room\r\n"
            b"host-request-port:997\r\n"
            b"system-version:09010000\r\n"
            b"\r\n"
        )

    def _standby_ps5(self) -> bytes:
        return (
            b"HTTP/1.1 620 Server Standby\r\n"
            b"host-id:11:22:33:44:55:66\r\n"
            b"host-type:PS5\r\n"
            b"host-name:My PS5\r\n"
            b"host-request-port:9302\r\n"
            b"system-version:02000000\r\n"
            b"\r\n"
        )

    def test_awake_ps4_type_and_status(self):
        dev = _parse_ddp_response(self._awake_ps4(), ("192.168.1.50", 987))
        assert dev is not None
        assert dev.device_type == DeviceType.PS4
        assert dev.status == DeviceStatus.AWAKE

    def test_awake_ps4_fields(self):
        dev = _parse_ddp_response(self._awake_ps4(), ("192.168.1.50", 987))
        assert dev.ip == "192.168.1.50"
        assert dev.port == 997  # from host-request-port
        assert dev.device_id == "AA:BB:CC:DD:EE:FF"
        assert dev.name == "Living Room"
        assert dev.system_version == "09010000"

    def test_standby_ps5_type_and_status(self):
        dev = _parse_ddp_response(self._standby_ps5(), ("192.168.1.51", 9302))
        assert dev is not None
        assert dev.device_type == DeviceType.PS5
        assert dev.status == DeviceStatus.STANDBY

    def test_fallback_port(self):
        # No host-request-port field → use addr port
        data = (
            b"HTTP/1.1 200 Ok\r\n"
            b"host-id:ZZ\r\n"
            b"host-type:PS4\r\n"
            b"host-name:X\r\n"
            b"system-version:00\r\n"
            b"\r\n"
        )
        dev = _parse_ddp_response(data, ("10.0.0.1", 987))
        assert dev.port == 987

    def test_running_app_fields(self):
        data = (
            b"HTTP/1.1 200 Ok\r\n"
            b"host-id:XY\r\n"
            b"host-type:PS4\r\n"
            b"host-name:Test\r\n"
            b"host-request-port:997\r\n"
            b"running-app-titleid:CUSA12345\r\n"
            b"running-app-name:Some Game\r\n"
            b"system-version:09010000\r\n"
            b"\r\n"
        )
        dev = _parse_ddp_response(data, ("1.2.3.4", 987))
        assert dev.running_app_titleid == "CUSA12345"
        assert dev.running_app_name == "Some Game"

    def test_empty_data_returns_none(self):
        assert _parse_ddp_response(b"", ("1.2.3.4", 987)) is None

    def test_garbage_data_returns_none(self):
        # Valid UTF-8 but not an HTTP/1.1 status line
        assert _parse_ddp_response(b"GARBAGE DATA\r\n", ("1.2.3.4", 987)) is None
        # Binary data
        assert _parse_ddp_response(b"\xfe\xff\x00\x01", ("1.2.3.4", 987)) is None

    def test_device_str(self):
        dev = _parse_ddp_response(self._awake_ps4(), ("192.168.1.50", 987))
        s = str(dev)
        assert "PS4" in s
        assert "Living Room" in s
        assert "awake" in s


# ---------------------------------------------------------------------------
# Remote Play session crypto  (vectors from test/remoteplay/crypto/modern-test.ts)
# ---------------------------------------------------------------------------


class TestDeriveAuthSeed:
    """Test _derive_auth_seed against known-good Node.js (generateAuthSeed PS5) vectors."""

    def test_known_vector(self):
        # Input: the RP-Key and server nonce from the modern-test.ts auth section
        # These are PS4 vectors in the test; we verify the PS5 formula here using
        # constructed inputs so the derivation path is exercised.
        server_nonce = bytes(
            [
                0xAE,
                0x92,
                0xE7,
                0x64,
                0x88,
                0x26,
                0x51,
                0xEF,
                0x89,
                0x01,
                0x8C,
                0xFA,
                0x69,
                0x6C,
                0x69,
                0x38,
            ]
        )
        rp_key = bytes(
            [
                0x74,
                0xA5,
                0x9C,
                0x96,
                0x93,
                0xC2,
                0x08,
                0x3B,
                0xA6,
                0xA8,
                0x4B,
                0xA0,
                0x50,
                0xFA,
                0x8E,
                0x5A,
            ]
        )
        seed = _derive_auth_seed(rp_key, server_nonce)
        # Manually reproduce formula to verify implementation is self-consistent
        key_offset = (server_nonce[7] >> 3) * 0x70
        expected = bytearray(16)
        for i in range(16):
            v = (rp_key[i] + 0x18 + i) & 0xFF
            v ^= server_nonce[i]
            v ^= AUTH_SEED_KEYS_PS5[key_offset + i]
            expected[i] = v
        assert seed == bytes(expected)


class TestDeriveAuthNonce:
    """Test _derive_auth_nonce against known-good Node.js (transformServerNonceForAuth PS5) vectors."""

    def test_known_vector(self):
        server_nonce = bytes(
            [
                0xAE,
                0x92,
                0xE7,
                0x64,
                0x88,
                0x26,
                0x51,
                0xEF,
                0x89,
                0x01,
                0x8C,
                0xFA,
                0x69,
                0x6C,
                0x69,
                0x38,
            ]
        )
        nonce = _derive_auth_nonce(server_nonce)
        key_offset = (server_nonce[0] >> 3) * 0x70
        expected = bytearray(16)
        for i in range(16):
            v = (server_nonce[i] - 0x2D - i) & 0xFF
            v ^= AUTH_NONCE_KEYS_PS5[key_offset + i]
            expected[i] = v
        assert nonce == bytes(expected)


class TestDeriveAuthPS4:
    """Smoke-test the PS4 crypto derivation paths."""

    SERVER_NONCE = bytes(
        [
            0xAE,
            0x92,
            0xE7,
            0x64,
            0x88,
            0x26,
            0x51,
            0xEF,
            0x89,
            0x01,
            0x8C,
            0xFA,
            0x69,
            0x6C,
            0x69,
            0x38,
        ]
    )
    RP_KEY = bytes(
        [
            0x74,
            0xA5,
            0x9C,
            0x96,
            0x93,
            0xC2,
            0x08,
            0x3B,
            0xA6,
            0xA8,
            0x4B,
            0xA0,
            0x50,
            0xFA,
            0x8E,
            0x5A,
        ]
    )

    def test_ps4_seed_length(self):
        seed = _derive_auth_seed(self.RP_KEY, self.SERVER_NONCE, DeviceType.PS4)
        assert len(seed) == 16

    def test_ps4_nonce_length(self):
        nonce = _derive_auth_nonce(self.SERVER_NONCE, DeviceType.PS4)
        assert len(nonce) == 16

    def test_ps4_seed_differs_from_ps5(self):
        seed_ps5 = _derive_auth_seed(self.RP_KEY, self.SERVER_NONCE, DeviceType.PS5)
        seed_ps4 = _derive_auth_seed(self.RP_KEY, self.SERVER_NONCE, DeviceType.PS4)
        assert seed_ps5 != seed_ps4

    def test_ps4_nonce_differs_from_ps5(self):
        nonce_ps5 = _derive_auth_nonce(self.SERVER_NONCE, DeviceType.PS5)
        nonce_ps4 = _derive_auth_nonce(self.SERVER_NONCE, DeviceType.PS4)
        assert nonce_ps5 != nonce_ps4


class TestGenerateIv:
    """Test _generate_iv (HMAC-SHA256 truncated to 16 bytes)."""

    def test_counter_0(self):
        key = bytes.fromhex("464687b349ca8ce859c5270f5d7a69d6")
        nonce = bytes(range(16))
        counter_bytes = _struct.pack(">Q", 0)
        h = hmac.new(key, nonce + counter_bytes, hashlib.sha256)
        expected = h.digest()[:16]
        assert _generate_iv(nonce, 0) == expected

    def test_counter_advances(self):
        nonce = bytes(range(16))
        iv0 = _generate_iv(nonce, 0)
        iv1 = _generate_iv(nonce, 1)
        assert iv0 != iv1


class TestRemotePlayCodecCounters:
    """Verify that the RemotePlayCodec counter increments correctly."""

    def test_encode_advances_encrypt_counter(self):
        seed = bytes(range(16))
        nonce = bytes(range(16, 32))
        codec = _RemotePlayCodec(seed, nonce)
        assert codec._encrypt_counter == 0
        _ = codec.encode_payload(b"\x00" * 16)
        assert codec._encrypt_counter == 1

    def test_decode_advances_decrypt_counter(self):
        seed = bytes(range(16))
        nonce = bytes(range(16, 32))
        codec = _RemotePlayCodec(seed, nonce)
        ciphertext = codec.encode_payload(b"\xab" * 16)
        assert codec._decrypt_counter == 0
        _ = codec.decode_payload(ciphertext)
        assert codec._decrypt_counter == 1

    def test_roundtrip(self):
        seed = bytes(range(16))
        nonce = bytes(range(16, 32))
        enc_codec = _RemotePlayCodec(seed, nonce)
        dec_codec = _RemotePlayCodec(seed, nonce)
        plaintext = b"hello remote play!"
        ciphertext = enc_codec.encode_payload(plaintext)
        recovered = dec_codec.decode_payload(ciphertext)
        assert recovered == plaintext


# ---------------------------------------------------------------------------
# Registration payload (vector from test/remoteplay/registration-test.ts)
# ---------------------------------------------------------------------------


class TestRemotePlayCryptoPayload:
    """Test _RemotePlayCrypto.create_signed_payload against the chiaki-derived vector."""

    def test_ps5_registration_payload(self):
        account_id = "AAAAAAAAAEI="
        pin = "13374201"
        nonce = bytes(
            [
                0x13,
                0x37,
                0xDE,
                0xAD,
                0xBE,
                0xEF,
                0xC0,
                0xFF,
                0xEE,
                0x42,
                0x63,
                0x68,
                0x69,
                0x61,
                0x6B,
                0x69,
            ]
        )
        # Expected hex (587 bytes) — verified to match Node.js test/remoteplay/registration-test.ts
        # (chiaki-derived vector for nonce=1337deadbeef..., pin=13374201)
        expected_hex = (
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414167dd36ad47d4c2ce4141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "41414141414141414141414141414141418ed494ee70eba06b41414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "4141414141414141414141414141414141414141414141414141414141414141"
            "b444c33edc7eaca50ca55f7988c31ec4fd893b5c64dd7741a324f483ee61919b"
            "dfc5b712343be1c66fb6ec0fc6f38bd6c653bd501115aaa75ed916405b312627"
            "fd8a98949dc8b245507cb7ec4fde1bdac6bd449964b3d6cedfc0dd95f39e4e47"
            "18c47c23bb45499830c465"
        )

        crypto = _RemotePlayCrypto(nonce, pin)
        payload = crypto.create_signed_payload(
            {
                "Client-Type": "dabfa2ec873de5839bee8d3f4c0239c4282c07c25c6077a2931afcf0adc0d34f",
                "Np-AccountId": account_id,
            }
        )

        assert len(payload) * 2 == len(expected_hex), (
            f"payload length mismatch: got {len(payload)} bytes, expected {len(expected_hex) // 2}"
        )
        assert payload.hex() == expected_hex


# ---------------------------------------------------------------------------
# connection.py — pure / non-network helpers
# ---------------------------------------------------------------------------


class TestExceptions:
    def test_login_error_is_playdirector_error(self):
        result = parse_login_result(struct.pack("<II", 0x80, 0x12))
        err = LoginError(result)
        assert isinstance(err, PlayDirectorCredentialsError)
        assert isinstance(err, PlayDirectorError)
        assert "0x80" in str(err)
        assert err.result is result

    def test_protocol_error_is_playdirector_error(self):
        assert issubclass(ProtocolError, PlayDirectorError)

    def test_standby_error_is_playdirector_error(self):
        assert issubclass(StandbyError, PlayDirectorError)

    def test_unsupported_device_error_is_playdirector_error(self):
        assert issubclass(UnsupportedDeviceError, PlayDirectorError)


class TestUdpMessageFormats:
    """Verify the WAKEUP / LAUNCH UDP datagram templates are well-formed."""

    def _check_fmt(self, fmt: str, credential: str = "TESTCRED") -> None:
        msg = fmt.format(credential=credential)
        lines = msg.split("\n")
        # First line must be a verb + path + protocol
        assert lines[0].startswith(("WAKEUP", "LAUNCH"))
        assert "HTTP/1.1" in lines[0]
        # credential line must contain the passed-in credential
        assert any(credential in line for line in lines)

    def test_wakeup_ss(self):
        self._check_fmt(_WAKEUP_FMT_SS)

    def test_launch_ss(self):
        self._check_fmt(_LAUNCH_FMT_SS)

    def test_wakeup_rp(self):
        self._check_fmt(_WAKEUP_FMT_RP)

    def test_launch_rp(self):
        self._check_fmt(_LAUNCH_FMT_RP)

    def test_rp_vs_ss_differ(self):
        """Remote Play and Second Screen packets must differ (different auth-type)."""
        assert _WAKEUP_FMT_RP != _WAKEUP_FMT_SS
        assert _LAUNCH_FMT_RP != _LAUNCH_FMT_SS

    def test_rp_app_type_r(self):
        assert "app-type:r" in _WAKEUP_FMT_RP

    def test_ss_app_type_c(self):
        assert "app-type:c" in _WAKEUP_FMT_SS


class TestRsaEncryptSeed:
    """RSA encrypt should produce a 256-byte ciphertext from a 16-byte seed.

    NOTE: The hardcoded _HANDSHAKE_PUBLIC_KEY_DER in connection.py is truncated
    (286 bytes instead of the required 294 for a 2048-bit RSA key). Tests that
    depend on it are marked xfail until the key bytes are corrected.
    """

    @pytest.mark.xfail(reason="_HANDSHAKE_PUBLIC_KEY_DER is truncated — 286 bytes instead of 294")
    def test_output_length(self):
        seed = bytes(range(16))
        ct = _rsa_encrypt_seed(seed)
        assert len(ct) == 256

    @pytest.mark.xfail(reason="_HANDSHAKE_PUBLIC_KEY_DER is truncated — 286 bytes instead of 294")
    def test_non_deterministic(self):
        """PKCS#1v1.5 padding includes random bytes — two encryptions must differ."""
        seed = bytes(range(16))
        ct1 = _rsa_encrypt_seed(seed)
        ct2 = _rsa_encrypt_seed(seed)
        assert ct1 != ct2

    @pytest.mark.xfail(reason="_HANDSHAKE_PUBLIC_KEY_DER is truncated — 286 bytes instead of 294")
    def test_public_key_der_loads(self):
        """Confirm the hardcoded DER key is a valid RSA public key."""
        key = load_der_public_key(_HANDSHAKE_PUBLIC_KEY_DER)
        assert key.key_size == 2048


# ---------------------------------------------------------------------------
# pairing.py — pure crypto helpers
# ---------------------------------------------------------------------------


class TestGenerateIvPairing:
    NONCE = bytes(range(16))

    def test_ps5_iv_length(self):
        assert len(_generate_iv_ps5(self.NONCE, 0)) == 16

    def test_ps4_iv_length(self):
        assert len(_generate_iv_ps4(self.NONCE, 0)) == 16

    def test_ps5_counter_changes_iv(self):
        assert _generate_iv_ps5(self.NONCE, 0) != _generate_iv_ps5(self.NONCE, 1)

    def test_ps4_counter_changes_iv(self):
        assert _generate_iv_ps4(self.NONCE, 0) != _generate_iv_ps4(self.NONCE, 1)

    def test_ps5_and_ps4_differ(self):
        assert _generate_iv_ps5(self.NONCE, 0) != _generate_iv_ps4(self.NONCE, 0)


class TestGenerateSeed:
    def test_ps5_seed_length(self):
        assert len(_generate_seed_ps5(12345678, 0)) == 16

    def test_ps4_seed_length(self):
        assert len(_generate_seed_ps4(12345678, 0)) == 16

    def test_pin_affects_seed(self):
        s1 = _generate_seed_ps5(11111111, 0)
        s2 = _generate_seed_ps5(22222222, 0)
        assert s1 != s2

    def test_offset_affects_seed(self):
        s1 = _generate_seed_ps5(12345678, 0)
        s2 = _generate_seed_ps5(12345678, 1)
        assert s1 != s2

    def test_ps5_and_ps4_differ(self):
        assert _generate_seed_ps5(12345678, 0) != _generate_seed_ps4(12345678, 0)


class TestGenerateAeropause:
    NONCE = bytes(range(16))

    def _padding(self) -> bytearray:
        return bytearray(b"A" * 512)

    def test_ps5_length(self):
        assert len(_generate_aeropause_ps5(self.NONCE, self._padding())) == 16

    def test_ps4_length(self):
        assert len(_generate_aeropause_ps4(self.NONCE, self._padding())) == 16

    def test_ps5_and_ps4_differ(self):
        pad = self._padding()
        assert _generate_aeropause_ps5(self.NONCE, pad) != _generate_aeropause_ps4(self.NONCE, pad)

    def test_nonce_affects_result(self):
        nonce2 = bytes(reversed(range(16)))
        pad = self._padding()
        assert _generate_aeropause_ps5(self.NONCE, pad) != _generate_aeropause_ps5(nonce2, pad)


class TestAesCfbCodec:
    def test_encode_decode_roundtrip(self):
        iv = bytes(range(16))
        key = bytes(reversed(range(16)))
        enc = _AesCfbCodec(iv, key)
        dec = _AesCfbCodec(iv, key)
        plaintext = b"Hello PlayStation pairing!"
        assert dec.decode(enc.encode(plaintext)) == plaintext

    def test_encode_length_preserved(self):
        iv = key = bytes(16)
        codec = _AesCfbCodec(iv, key)
        data = b"x" * 37
        assert len(codec.encode(data)) == 37


class TestParseDdpHeaders:
    def test_basic_parse(self):
        # _parse_ddp_headers skips the first line (status line, like HTTP)
        text = "HTTP/1.1 200 OK\r\nhost-id:AA:BB:CC\r\nhost-name:MyPS5\r\n"
        h = _parse_ddp_headers(text)
        assert h["host-id"] == "AA:BB:CC"
        assert h["host-name"] == "MyPS5"

    def test_empty_string(self):
        assert _parse_ddp_headers("") == {}

    def test_missing_colon_line_skipped(self):
        # First line is the status line; second line has no colon; third has key:val
        h = _parse_ddp_headers("STATUS\r\nno-colon-here\r\nkey:val\r\n")
        assert "key" in h
        assert len(h) == 1


class TestParseRegistrationBody:
    def test_basic(self):
        body = b"RP-Key: abc123\r\nPS5-RegistKey: def456\r\n"
        result = _parse_registration_body(body)
        assert result["RP-Key"] == "abc123"
        assert result["PS5-RegistKey"] == "def456"

    def test_empty(self):
        assert _parse_registration_body(b"") == {}

    def test_ignores_lines_without_colon(self):
        result = _parse_registration_body(b"no-colon\r\nKey: Value\r\n")
        assert list(result.keys()) == ["Key"]


class TestRemotePlayCryptoPS4:
    """Smoke-test the PS4 pairing crypto path."""

    NONCE = bytes(
        [
            0x13,
            0x37,
            0xDE,
            0xAD,
            0xBE,
            0xEF,
            0xC0,
            0xFF,
            0xEE,
            0x42,
            0x63,
            0x68,
            0x69,
            0x61,
            0x6B,
            0x69,
        ]
    )

    def test_payload_non_empty(self):
        crypto = _RemotePlayCrypto(self.NONCE, "12345678", ps4=True)
        payload = crypto.create_signed_payload({"Key": "Value"})
        assert len(payload) > 0

    def test_payload_differs_from_ps5(self):
        ps5 = _RemotePlayCrypto(self.NONCE, "12345678", ps4=False)
        ps4 = _RemotePlayCrypto(self.NONCE, "12345678", ps4=True)
        p5 = ps5.create_signed_payload({"Key": "Value"})
        p4 = ps4.create_signed_payload({"Key": "Value"})
        assert p5 != p4

    def test_invalid_nonce_length(self):
        with pytest.raises(ValueError, match="nonce"):
            _RemotePlayCrypto(b"\x00" * 8, "12345678")


# ---------------------------------------------------------------------------
# playstation.py — public API
# ---------------------------------------------------------------------------


def _make_device(device_type: DeviceType = DeviceType.PS5) -> DiscoveredDevice:
    return DiscoveredDevice(
        ip="192.168.1.50",
        port=9302,
        device_id="AA:BB:CC:DD:EE:FF",
        name="Test Console",
        status=DeviceStatus.AWAKE,
        device_type=device_type,
        system_version="02000000",
        running_app_titleid=None,
        running_app_name=None,
        raw_headers={},
    )


def _make_rp_cred() -> RemotePlayCredentials:
    return RemotePlayCredentials(
        device_id="AA:BB:CC:DD:EE:FF",
        credential="a" * 32,
        account_id="dGVzdA==",
        registration_key="b" * 32,
        rp_key="c" * 32,
        access_token="tok",
        refresh_token="",
    )


def _make_ss_cred() -> SecondScreenCredentials:
    return SecondScreenCredentials(
        device_id="AA:BB:CC:DD:EE:FF",
        credential="a" * 32,
        account_id="",
        registration_key="b" * 32,
    )


def _mock_session_context(session: MagicMock):
    """Return a patch for session_context that yields the given mock session."""

    @asynccontextmanager
    async def _ctx(device, credential, *, connect_timeout=10.0, login_timeout=15.0):
        yield session

    return patch("playdirector.playstation.session_context", new=_ctx)


class TestFind:
    @pytest.mark.asyncio
    async def test_returns_device_when_found(self):
        device = _make_device()
        with patch("playdirector.playstation._probe", new=AsyncMock(return_value=device)):
            result = await find("192.168.1.50")
        assert result is device

    @pytest.mark.asyncio
    async def test_returns_none_when_not_found(self):
        with patch("playdirector.playstation._probe", new=AsyncMock(return_value=None)):
            result = await find("192.168.1.50")
        assert result is None

    @pytest.mark.asyncio
    async def test_passes_ip_and_timeout(self):
        mock_probe = AsyncMock(return_value=None)
        with patch("playdirector.playstation._probe", new=mock_probe):
            await find("10.0.0.1", timeout=2.0)
        mock_probe.assert_called_once_with(ip="10.0.0.1", timeout=2.0)


class TestScan:
    @pytest.mark.asyncio
    async def test_yields_devices(self):
        devices = [_make_device(DeviceType.PS4), _make_device(DeviceType.PS5)]

        async def _fake_scan(**_kwargs):
            for d in devices:
                yield d

        with patch("playdirector.discovery.scan", new=_fake_scan):
            from playdirector.discovery import scan as discovery_scan

            result = [d async for d in discovery_scan(timeout=1.0)]

        assert len(result) == 2
        assert result[0].device_type == DeviceType.PS4
        assert result[1].device_type == DeviceType.PS5


class TestPair:
    @pytest.mark.asyncio
    async def test_raises_if_device_not_found(self):
        with (
            patch("playdirector.playstation._probe", new=AsyncMock(return_value=None)),
            pytest.raises(PlayDirectorConnectionError, match="No device found"),
        ):
            await pair("192.168.1.50", pin="12345678", npsso="tok")

    @pytest.mark.asyncio
    async def test_dispatches_to_pair_ps5(self):
        device = _make_device(DeviceType.PS5)
        cred = _make_rp_cred()
        with (
            patch("playdirector.playstation._probe", new=AsyncMock(return_value=device)),
            patch(
                "playdirector.playstation.pair_ps5", new=AsyncMock(return_value=cred)
            ) as mock_ps5,
            patch(
                "playdirector.playstation.pair_ps4", new=AsyncMock(return_value=cred)
            ) as mock_ps4,
        ):
            await pair("192.168.1.50", pin="12345678", npsso="tok")
        mock_ps5.assert_called_once()
        mock_ps4.assert_not_called()

    @pytest.mark.asyncio
    async def test_dispatches_to_pair_ps4(self):
        device = _make_device(DeviceType.PS4)
        cred = _make_rp_cred()
        with (
            patch("playdirector.playstation._probe", new=AsyncMock(return_value=device)),
            patch(
                "playdirector.playstation.pair_ps5", new=AsyncMock(return_value=cred)
            ) as mock_ps5,
            patch(
                "playdirector.playstation.pair_ps4", new=AsyncMock(return_value=cred)
            ) as mock_ps4,
        ):
            await pair("192.168.1.50", pin="12345678", npsso="tok")
        mock_ps4.assert_called_once()
        mock_ps5.assert_not_called()

    @pytest.mark.asyncio
    async def test_passes_pin_and_npsso(self):
        device = _make_device(DeviceType.PS5)
        cred = _make_rp_cred()
        mock_pair = AsyncMock(return_value=cred)
        with (
            patch("playdirector.playstation._probe", new=AsyncMock(return_value=device)),
            patch("playdirector.playstation.pair_ps5", new=mock_pair),
        ):
            await pair("192.168.1.50", pin="99887766", npsso="mytoken")
        mock_pair.assert_called_once_with(device, pin="99887766", npsso="mytoken")


class TestWake:
    @pytest.mark.asyncio
    async def test_sends_udp_priming(self):
        device = _make_device(DeviceType.PS5)
        cred = _make_rp_cred()
        mock_udp = AsyncMock()
        with patch("playdirector.playstation._send_udp_priming", new=mock_udp):
            await wake(device, cred)
        mock_udp.assert_called_once()

    @pytest.mark.asyncio
    async def test_uses_ps5_port_for_ps5(self):
        from playdirector.discovery import PS5_DISCOVERY_PORT

        device = _make_device(DeviceType.PS5)
        cred = _make_rp_cred()
        mock_udp = AsyncMock()
        with patch("playdirector.playstation._send_udp_priming", new=mock_udp):
            await wake(device, cred)
        assert mock_udp.call_args[0][1] == PS5_DISCOVERY_PORT

    @pytest.mark.asyncio
    async def test_uses_ps4_port_for_ps4(self):
        from playdirector.discovery import PS4_DISCOVERY_PORT

        device = _make_device(DeviceType.PS4)
        cred = _make_ss_cred()
        mock_udp = AsyncMock()
        with patch("playdirector.playstation._send_udp_priming", new=mock_udp):
            await wake(device, cred)
        assert mock_udp.call_args[0][1] == PS4_DISCOVERY_PORT

    @pytest.mark.asyncio
    async def test_remoteplay_flag_for_rp_cred(self):
        device = _make_device(DeviceType.PS5)
        cred = _make_rp_cred()
        mock_udp = AsyncMock()
        with patch("playdirector.playstation._send_udp_priming", new=mock_udp):
            await wake(device, cred)
        assert mock_udp.call_args[1]["is_remote_play"] is True

    @pytest.mark.asyncio
    async def test_secondscreen_flag_for_ss_cred(self):
        device = _make_device(DeviceType.PS4)
        cred = _make_ss_cred()
        mock_udp = AsyncMock()
        with patch("playdirector.playstation._send_udp_priming", new=mock_udp):
            await wake(device, cred)
        assert mock_udp.call_args[1]["is_remote_play"] is False


class TestStandby:
    @pytest.mark.asyncio
    async def test_calls_session_standby(self):
        device = _make_device()
        cred = _make_rp_cred()
        session = MagicMock()
        session.standby = AsyncMock()
        with _mock_session_context(session):
            await standby(device, cred)
        session.standby.assert_called_once()

    @pytest.mark.asyncio
    async def test_works_for_ps4(self):
        device = _make_device(DeviceType.PS4)
        cred = _make_ss_cred()
        session = MagicMock()
        session.standby = AsyncMock()
        with _mock_session_context(session):
            await standby(device, cred)
        session.standby.assert_called_once()


class TestSendButtons:
    @pytest.mark.asyncio
    async def test_calls_session_send_keys(self):
        device = _make_device(DeviceType.PS4)
        cred = _make_ss_cred()
        session = MagicMock()
        session.send_keys = AsyncMock()
        with _mock_session_context(session):
            await send_buttons(device, cred, [RemoteOperation.PS])
        session.send_keys.assert_called_once_with([RemoteOperation.PS], hold_time=0)

    @pytest.mark.asyncio
    async def test_passes_hold_time(self):
        device = _make_device(DeviceType.PS4)
        cred = _make_ss_cred()
        session = MagicMock()
        session.send_keys = AsyncMock()
        with _mock_session_context(session):
            await send_buttons(device, cred, [RemoteOperation.ENTER], hold_time=500)
        session.send_keys.assert_called_once_with([RemoteOperation.ENTER], hold_time=500)

    @pytest.mark.asyncio
    async def test_multiple_buttons(self):
        device = _make_device(DeviceType.PS4)
        cred = _make_ss_cred()
        session = MagicMock()
        session.send_keys = AsyncMock()
        ops = [RemoteOperation.UP, RemoteOperation.ENTER]
        with _mock_session_context(session):
            await send_buttons(device, cred, ops)
        session.send_keys.assert_called_once_with(ops, hold_time=0)


class TestGoHome:
    @pytest.mark.asyncio
    async def test_calls_session_go_home(self):
        device = _make_device(DeviceType.PS5)
        cred = _make_rp_cred()
        session = MagicMock()
        session.go_home = AsyncMock()
        with _mock_session_context(session):
            await go_home(device, cred)
        session.go_home.assert_called_once()

    @pytest.mark.asyncio
    async def test_raises_for_ps4(self):
        device = _make_device(DeviceType.PS4)
        cred = _make_rp_cred()
        session = MagicMock()
        session.go_home = AsyncMock()
        with (
            _mock_session_context(session),
            pytest.raises(UnsupportedDeviceError),
        ):
            await go_home(device, cred)


class TestConnect:
    @pytest.mark.asyncio
    async def test_yields_session(self):
        device = _make_device()
        cred = _make_rp_cred()
        session = MagicMock()
        with _mock_session_context(session):
            async with connect(device, cred) as s:
                assert s is session

    @pytest.mark.asyncio
    async def test_passes_timeouts(self):
        device = _make_device()
        cred = _make_rp_cred()
        session = MagicMock()
        captured = {}

        @asynccontextmanager
        async def _ctx(dev, cred, *, connect_timeout, login_timeout):
            captured["connect_timeout"] = connect_timeout
            captured["login_timeout"] = login_timeout
            yield session

        with patch("playdirector.playstation.session_context", new=_ctx):
            async with connect(device, cred, connect_timeout=3.0, login_timeout=7.0):
                pass

        assert captured["connect_timeout"] == 3.0
        assert captured["login_timeout"] == 7.0
