import json
from typing import Any, Dict, List, Literal, Optional

from aiograpi.extractors import json_value
from aiograpi.types import About, Guide, Highlight, Media, Relationship, RelationshipShort, User, UserShort
from fastapi import APIRouter, Depends, Form, HTTPException, Query
from pydantic import BaseModel, ValidationError

from aiograpi_rest.dependencies import ClientStorage, get_clients, get_sessionid
from aiograpi_rest.pagination import UserShortPage

router = APIRouter(
    prefix="/user",
    tags=["User"],
    responses={404: {"description": "Not found"}},
)


def _normalize_about(value: Any) -> About:
    if isinstance(value, dict):
        payload = dict(value)
    else:
        payload = value.model_dump()

    for field in ("username", "country", "date", "former_usernames"):
        field_value = payload.get(field)
        if isinstance(field_value, bool):
            payload[field] = ""
        elif field_value is not None and not isinstance(field_value, str):
            payload[field] = str(field_value)

    return About(**payload)


def _extract_about_from_last_json(data: Dict) -> About:
    payload = {}
    content = json_value(data, "layout", "bloks_payload", "data", 0, "data")
    if isinstance(content, dict):
        payload["country"] = content.get("initial")

    serialized = json.dumps(data, ensure_ascii=False, separators=(",", ":"), default=str)
    payload["is_verified"] = '"Verified"' in serialized
    date_found = False
    parts = serialized.split('")":')
    for index, value in enumerate(parts):
        if '"bold"}' in value:
            payload["username"] = value.strip().split(",")[0][1:-1]
        if date_found:
            payload["date"] = value.strip().split(",")[0][1:-1]
        if "Former usernames" in value:
            payload["former_usernames"] = parts[index + 2].strip().split(",")[0][1:-1]
        date_found = '"Date joined"' in value
    return _normalize_about(payload)


class CreatorInfoResponse(BaseModel):
    user: UserShort
    info: Dict[str, Any]


def _clean_username(username: str) -> str:
    return username.strip().lstrip("@")


def _clean_user_id(user_id: str) -> str:
    return user_id.strip()


def _ensure_single_user_selector(user_id: Optional[str], username: Optional[str]) -> None:
    if user_id and username:
        raise HTTPException(status_code=422, detail="Provide either user_id or username, not both")
    if not user_id and not username:
        raise HTTPException(status_code=422, detail="Provide user_id or username")


@router.get("/followers", response_model=UserShortPage)
async def user_followers(sessionid: str = Depends(get_sessionid),
                         user_id: str = Query(...),
                         amount: int = Query(50, ge=1, le=200),
                         cursor: str = Query(""),
                         clients: ClientStorage = Depends(get_clients)) -> UserShortPage:
    """Get a page of user's followers
    """
    cl = await clients.get(sessionid)
    items, next_cursor = await cl.user_followers_v1_chunk(user_id, amount, cursor or "")
    return UserShortPage(items=items, next_cursor=next_cursor or "")


@router.get("/following", response_model=UserShortPage)
async def user_following(sessionid: str = Depends(get_sessionid),
                         user_id: str = Query(...),
                         amount: int = Query(50, ge=1, le=200),
                         cursor: str = Query(""),
                         clients: ClientStorage = Depends(get_clients)) -> UserShortPage:
    """Get a page of user's following
    """
    cl = await clients.get(sessionid)
    items, next_cursor = await cl.user_following_v1_chunk(user_id, amount, cursor or "")
    return UserShortPage(items=items, next_cursor=next_cursor or "")


@router.get("", response_model=User)
async def user(sessionid: str = Depends(get_sessionid),
               user_id: Optional[str] = Query(None),
               username: Optional[str] = Query(None),
               use_cache: Optional[bool] = Query(True),
               clients: ClientStorage = Depends(get_clients)) -> User:
    """Get user profile by user id or username
    """
    _ensure_single_user_selector(user_id, username)

    cl = await clients.get(sessionid)
    if username:
        return await cl.user_info_by_username(_clean_username(username))

    assert user_id is not None
    return await cl.user_info(_clean_user_id(user_id))


@router.get("/about", response_model=About)
async def user_about(sessionid: str = Depends(get_sessionid),
                     user_id: str = Query(...),
                     clients: ClientStorage = Depends(get_clients)) -> About:
    """Get user about details (verification, country, join date)
    """
    cl = await clients.get(sessionid)
    try:
        about = await cl.user_about_v1(user_id)
    except ValidationError:
        last_json = getattr(cl, "last_json", None)
        if not last_json:
            raise
        return _extract_about_from_last_json(last_json)
    return _normalize_about(about)


@router.get("/profile/web", response_model=Dict[str, Any])
async def user_profile_web(sessionid: str = Depends(get_sessionid),
                           username: str = Query(...),
                           clients: ClientStorage = Depends(get_clients)) -> Dict[str, Any]:
    """Get user web profile info
    """
    cl = await clients.get(sessionid)
    return await cl.user_web_profile_info_v1(_clean_username(username))


@router.get("/stream", response_model=Dict[str, Any])
async def user_stream(sessionid: str = Depends(get_sessionid),
                      user_id: Optional[str] = Query(None),
                      username: Optional[str] = Query(None),
                      view: Literal["flat", "raw"] = Query("flat"),
                      clients: ClientStorage = Depends(get_clients)) -> Dict[str, Any]:
    """Get user profile stream
    """
    _ensure_single_user_selector(user_id, username)
    cl = await clients.get(sessionid)
    if username:
        clean_username = _clean_username(username)
        if view == "raw":
            return await cl.user_stream_by_username_v1(clean_username)
        return await cl.user_stream_by_username_flat(clean_username)

    assert user_id is not None
    clean_user_id = _clean_user_id(user_id)
    if view == "raw":
        return await cl.user_stream_by_id_v1(clean_user_id)
    return await cl.user_stream_by_id_flat(clean_user_id)


@router.get("/suggestions", response_model=Dict[str, Any])
async def user_suggestions(sessionid: str = Depends(get_sessionid),
                           user_id: str = Query(...),
                           clients: ClientStorage = Depends(get_clients)) -> Dict[str, Any]:
    """Get suggested users for a target user
    """
    cl = await clients.get(sessionid)
    return await cl.chaining(user_id)


@router.get("/suggestions/details", response_model=Dict[str, Any])
async def user_suggestion_details(sessionid: str = Depends(get_sessionid),
                                  user_id: str = Query(...),
                                  chained_ids: List[str] = Query(...),
                                  clients: ClientStorage = Depends(get_clients)) -> Dict[str, Any]:
    """Get expanded details for suggested users
    """
    cl = await clients.get(sessionid)
    return await cl.fetch_suggestion_details(user_id, chained_ids)


@router.get("/recommendations", response_model=Dict[str, Any])
async def user_recommendations(sessionid: str = Depends(get_sessionid),
                               user_id: str = Query(...),
                               clients: ClientStorage = Depends(get_clients)) -> Dict[str, Any]:
    """Get recommended accounts for a target user category
    """
    cl = await clients.get(sessionid)
    return await cl.discover_recommended_accounts_for_category_v1(user_id)


@router.get("/creator", response_model=CreatorInfoResponse)
async def user_creator(sessionid: str = Depends(get_sessionid),
                       user_id: str = Query(...),
                       entry_point: str = Query("direct_thread"),
                       clients: ClientStorage = Depends(get_clients)) -> CreatorInfoResponse:
    """Get creator info for a user
    """
    cl = await clients.get(sessionid)
    user, info = await cl.creator_info(user_id, entry_point=entry_point)
    return CreatorInfoResponse(user=user, info=info)


@router.post("/follow", response_model=bool)
async def user_follow(sessionid: str = Depends(get_sessionid),
                      user_id: int = Form(...),
                      clients: ClientStorage = Depends(get_clients)) -> bool:
    """Follow a user
    """
    cl = await clients.get(sessionid)
    return await cl.user_follow(user_id)


@router.delete("/follow", response_model=bool)
async def user_unfollow(sessionid: str = Depends(get_sessionid),
                        user_id: int = Query(...),
                        clients: ClientStorage = Depends(get_clients)) -> bool:
    """Unfollow a user
    """
    cl = await clients.get(sessionid)
    return await cl.user_unfollow(user_id)


@router.delete("/follower", response_model=bool)
async def user_remove_follower(sessionid: str = Depends(get_sessionid),
                               user_id: int = Query(...),
                               clients: ClientStorage = Depends(get_clients)) -> bool:
    """Remove a follower
    """
    cl = await clients.get(sessionid)
    return await cl.user_remove_follower(user_id)


@router.post("/close-friend", response_model=bool)
async def user_close_friend_add(sessionid: str = Depends(get_sessionid),
                                user_id: int = Form(...),
                                clients: ClientStorage = Depends(get_clients)) -> bool:
    """Add a user to close friends
    """
    cl = await clients.get(sessionid)
    return await cl.close_friend_add(user_id)


@router.delete("/close-friend", response_model=bool)
async def user_close_friend_remove(sessionid: str = Depends(get_sessionid),
                                   user_id: int = Query(...),
                                   clients: ClientStorage = Depends(get_clients)) -> bool:
    """Remove a user from close friends
    """
    cl = await clients.get(sessionid)
    return await cl.close_friend_remove(user_id)


@router.post("/mute/posts", response_model=bool)
async def mute_posts_from_follow(sessionid: str = Depends(get_sessionid),
                                 user_id: int = Form(...),
                                 revert: Optional[bool] = Form(False),
                                 clients: ClientStorage = Depends(get_clients)) -> bool:
    """Mute posts from following user
    """
    cl = await clients.get(sessionid)
    return await cl.mute_posts_from_follow(user_id, revert)


@router.delete("/mute/posts", response_model=bool)
async def unmute_posts_from_follow(sessionid: str = Depends(get_sessionid),
                                   user_id: int = Query(...),
                                   clients: ClientStorage = Depends(get_clients)) -> bool:
    """Unmute posts from following user
    """
    cl = await clients.get(sessionid)
    return await cl.unmute_posts_from_follow(user_id)


@router.post("/mute/stories", response_model=bool)
async def mute_stories_from_follow(sessionid: str = Depends(get_sessionid),
                                   user_id: int = Form(...),
                                   revert: Optional[bool] = Form(False),
                                   clients: ClientStorage = Depends(get_clients)) -> bool:
    """Mute stories from following user
    """
    cl = await clients.get(sessionid)
    return await cl.mute_stories_from_follow(user_id, revert)


@router.delete("/mute/stories", response_model=bool)
async def unmute_stories_from_follow(sessionid: str = Depends(get_sessionid),
                                     user_id: int = Query(...),
                                     clients: ClientStorage = Depends(get_clients)) -> bool:
    """Unmute stories from following user
    """
    cl = await clients.get(sessionid)
    return await cl.unmute_stories_from_follow(user_id)


@router.post("/notifications/posts", response_model=bool)
async def user_notifications_posts_enable(sessionid: str = Depends(get_sessionid),
                                          user_id: int = Form(...),
                                          clients: ClientStorage = Depends(get_clients)) -> bool:
    """Enable post notifications for a user
    """
    cl = await clients.get(sessionid)
    return await cl.enable_posts_notifications(user_id)


@router.delete("/notifications/posts", response_model=bool)
async def user_notifications_posts_disable(sessionid: str = Depends(get_sessionid),
                                           user_id: int = Query(...),
                                           clients: ClientStorage = Depends(get_clients)) -> bool:
    """Disable post notifications for a user
    """
    cl = await clients.get(sessionid)
    return await cl.disable_posts_notifications(user_id)


@router.post("/notifications/stories", response_model=bool)
async def user_notifications_stories_enable(sessionid: str = Depends(get_sessionid),
                                            user_id: int = Form(...),
                                            clients: ClientStorage = Depends(get_clients)) -> bool:
    """Enable story notifications for a user
    """
    cl = await clients.get(sessionid)
    return await cl.enable_stories_notifications(user_id)


@router.delete("/notifications/stories", response_model=bool)
async def user_notifications_stories_disable(sessionid: str = Depends(get_sessionid),
                                             user_id: int = Query(...),
                                             clients: ClientStorage = Depends(get_clients)) -> bool:
    """Disable story notifications for a user
    """
    cl = await clients.get(sessionid)
    return await cl.disable_stories_notifications(user_id)


@router.post("/notifications/reels", response_model=bool)
async def user_notifications_reels_enable(sessionid: str = Depends(get_sessionid),
                                          user_id: int = Form(...),
                                          clients: ClientStorage = Depends(get_clients)) -> bool:
    """Enable Reel notifications for a user
    """
    cl = await clients.get(sessionid)
    return await cl.enable_reels_notifications(user_id)


@router.delete("/notifications/reels", response_model=bool)
async def user_notifications_reels_disable(sessionid: str = Depends(get_sessionid),
                                           user_id: int = Query(...),
                                           clients: ClientStorage = Depends(get_clients)) -> bool:
    """Disable Reel notifications for a user
    """
    cl = await clients.get(sessionid)
    return await cl.disable_reels_notifications(user_id)


@router.post("/notifications/videos", response_model=bool)
async def user_notifications_videos_enable(sessionid: str = Depends(get_sessionid),
                                           user_id: int = Form(...),
                                           clients: ClientStorage = Depends(get_clients)) -> bool:
    """Enable video notifications for a user
    """
    cl = await clients.get(sessionid)
    return await cl.enable_videos_notifications(user_id)


@router.delete("/notifications/videos", response_model=bool)
async def user_notifications_videos_disable(sessionid: str = Depends(get_sessionid),
                                            user_id: int = Query(...),
                                            clients: ClientStorage = Depends(get_clients)) -> bool:
    """Disable video notifications for a user
    """
    cl = await clients.get(sessionid)
    return await cl.disable_videos_notifications(user_id)


@router.get("/friendship", response_model=Relationship)
async def user_friendship(sessionid: str = Depends(get_sessionid),
                          user_id: str = Query(...),
                          clients: ClientStorage = Depends(get_clients)) -> Relationship:
    """Get relationship with a user
    """
    cl = await clients.get(sessionid)
    return await cl.user_friendship_v1(user_id)


@router.get("/friendships", response_model=List[RelationshipShort])
async def user_friendships(sessionid: str = Depends(get_sessionid),
                           user_ids: List[str] = Query(...),
                           clients: ClientStorage = Depends(get_clients)) -> List[RelationshipShort]:
    """Get relationships with multiple users
    """
    cl = await clients.get(sessionid)
    return await cl.user_friendships_v1(user_ids)


@router.post("/block", response_model=bool)
async def user_block(sessionid: str = Depends(get_sessionid),
                     user_id: str = Form(...),
                     surface: Optional[str] = Form("profile"),
                     clients: ClientStorage = Depends(get_clients)) -> bool:
    """Block a user
    """
    cl = await clients.get(sessionid)
    return await cl.user_block(user_id, surface)


@router.delete("/block", response_model=bool)
async def user_unblock(sessionid: str = Depends(get_sessionid),
                       user_id: str = Query(...),
                       surface: Optional[str] = Query("profile"),
                       clients: ClientStorage = Depends(get_clients)) -> bool:
    """Unblock a user
    """
    cl = await clients.get(sessionid)
    return await cl.user_unblock(user_id, surface)


@router.get("/pinned/posts", response_model=List[Media])
async def user_pinned_posts(sessionid: str = Depends(get_sessionid),
                            user_id: int = Query(...),
                            clients: ClientStorage = Depends(get_clients)) -> List[Media]:
    """Get user pinned posts
    """
    cl = await clients.get(sessionid)
    return await cl.user_pinned_medias(user_id)


@router.get("/highlights", response_model=List[Highlight])
async def user_highlights(sessionid: str = Depends(get_sessionid),
                          user_id: int = Query(...),
                          amount: Optional[int] = Query(0),
                          clients: ClientStorage = Depends(get_clients)) -> List[Highlight]:
    """Get user highlights
    """
    cl = await clients.get(sessionid)
    return await cl.user_highlights(user_id, amount)


@router.get("/guides", response_model=List[Guide])
async def user_guides(sessionid: str = Depends(get_sessionid),
                      user_id: int = Query(...),
                      clients: ClientStorage = Depends(get_clients)) -> List[Guide]:
    """Get user guides
    """
    cl = await clients.get(sessionid)
    return await cl.user_guides_v1(user_id)
