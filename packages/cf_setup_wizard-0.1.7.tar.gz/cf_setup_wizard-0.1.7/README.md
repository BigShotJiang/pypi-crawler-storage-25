# cf-setup-wizard

Interactive terminal installation wizard for Cogniflow.

## Installation

```bash
pip install cf-setup-wizard
```

## Usage

```bash
# Launch the interactive wizard
cf wizard

# Or use the packaged script directly
cf-wizard
```

## Features

- Interactive TUI with futuristic dark cyan/blue theme
- System prerequisite checks (Python, pip, venv, cmake, git, node, npm)
- Profile selection (core, steps, web, full)
- Real-time progress bars and installation tracking
- Non-interactive fallback for CI/CD environments

`cf-setup-wizard` depends on `cf-setup` at runtime, so a plain `pip install cf-setup-wizard` is sufficient.

## Publishing

`cf-setup-wizard` is prepared for the dedicated Windows workflow:

- Workflow: `.github/workflows/cf_setup_wizard_windows_publish.yml`
- Package directory: `sandcastle/cf_setup_wizard`
- PyPI tag: `cf-setup-wizard-v<version>`
- TestPyPI tag: `cf-setup-wizard-v<version>-test`
- Release order: publish `cf-core-cli 0.1.5` first, then `cf-setup`, then `cf-setup-wizard`, then `cogniflow`

Local preflight:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/mimic_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_setup_wizard_windows_publish.yml `
  -PackageDir sandcastle/cf_setup_wizard `
  -PythonExe py `
  -PythonVersion 3.14
```

Queue a dry-run dispatch:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/queue_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_setup_wizard_windows_publish.yml `
  -PackageDir sandcastle/cf_setup_wizard `
  -PublishTarget testpypi `
  -Ref main `
  -RequireLocalPass `
  -DryRun `
  -ReleaseTag cf-setup-wizard-v0.1.6-test
```
