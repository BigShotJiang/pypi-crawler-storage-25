"""Stable action registry for the Setup TUI.

The registry defines the public automation contract for every TUI function.
All action IDs are stable and must remain unchanged once accepted.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

from .wizard_integration import INSTALL_PROFILES, CLEAN_PROFILES


_ACTIONS: List[Dict[str, Any]] = []


def _build_actions() -> List[Dict[str, Any]]:
    """Build the canonical action list from shared setup metadata."""
    actions: List[Dict[str, Any]] = []

    # Install source selection actions
    for source in ("repo_local", "pypi_demo"):
        actions.append(
            {
                "id": f"select.install_source.{source}",
                "description": f"Select install source '{source.replace('_', '-')}'",
                "category": "source_selection",
                "equivalent_command": ["cf", "setup", "install", "--mode", "distribution"] if source == "pypi_demo" else ["cf", "setup", "install"],
                "plan_field": "choices.install_source",
                "transcript_field": "choices.install_source",
                "scripted_input_path": f"plan.json#choices.install_source",
                "test_harness_api": f"WizardChoices(install_source='{source.replace('_', '-')}')",
                "visual_status": "planned",
            }
        )

    # Profile selection actions
    for profile in INSTALL_PROFILES:
        actions.append(
            {
                "id": f"select.install_profile.{profile}",
                "description": f"Select install profile '{profile}'",
                "category": "profile_selection",
                "equivalent_command": ["cf", "setup", "install", "--profile", profile],
                "plan_field": "choices.install_profile",
                "transcript_field": "choices.install_profile",
                "scripted_input_path": "plan.json#choices.install_profile",
                "test_harness_api": "WizardChoices(install_profile=...)",
                "visual_status": "planned",
            }
        )

    for profile in CLEAN_PROFILES:
        actions.append(
            {
                "id": f"select.clean_profile.{profile.replace('-', '_')}",
                "description": f"Select clean profile '{profile}'",
                "category": "clean_selection",
                "equivalent_command": ["cf", "setup", "clean", "--profile", profile],
                "plan_field": "choices.clean_profile",
                "transcript_field": "choices.clean_profile",
                "scripted_input_path": "plan.json#choices.clean_profile",
                "test_harness_api": "WizardChoices(clean_profile=...)",
                "visual_status": "planned",
            }
        )

    # Toggle / mode actions
    actions.append(
        {
            "id": "toggle.dry_run",
            "description": "Toggle dry-run mode",
            "category": "mode",
            "equivalent_command": None,
            "plan_field": "choices.dry_run",
            "transcript_field": "choices.dry_run",
            "scripted_input_path": "plan.json#choices.dry_run",
            "test_harness_api": "WizardChoices(dry_run=...)",
            "visual_status": "planned",
        }
    )
    actions.append(
        {
            "id": "toggle.run_demo.on",
            "description": "Enable run-demo mode (run the maintained demo after install)",
            "category": "mode",
            "equivalent_command": ["cf", "setup", "install", "--run-demo"],
            "plan_field": "choices.run_demo",
            "transcript_field": "choices.run_demo",
            "scripted_input_path": "plan.json#choices.run_demo",
            "test_harness_api": "WizardChoices(run_demo=True)",
            "visual_status": "implemented",
        }
    )
    actions.append(
        {
            "id": "toggle.run_demo.off",
            "description": "Disable run-demo mode",
            "category": "mode",
            "equivalent_command": ["cf", "setup", "install", "--no-run-demo"],
            "plan_field": "choices.run_demo",
            "transcript_field": "choices.run_demo",
            "scripted_input_path": "plan.json#choices.run_demo",
            "test_harness_api": "WizardChoices(run_demo=False)",
            "visual_status": "implemented",
        }
    )

    # Action items
    action_items = [
        {
            "id": "action.run_diagnostics",
            "description": "Run setup diagnostics",
            "category": "diagnostics",
            "equivalent_command": ["cf", "setup", "diagnose", "--format", "json"],
            "plan_field": None,
            "transcript_field": "executed_actions",
            "scripted_input_path": None,
            "test_harness_api": "cf_setup_wizard.cli.main(['--plain', '--profile', 'core'])",
            "visual_status": "implemented",
        },
        {
            "id": "action.view_install_plan",
            "description": "View install plan for selected profile",
            "category": "plan",
            "equivalent_command": ["cf", "setup", "plan", "--profile", "<profile>", "--mode", "repo", "--format", "json"],
            "plan_field": None,
            "transcript_field": "executed_actions",
            "scripted_input_path": None,
            "test_harness_api": "cf_setup_wizard.cli.main(['--emit-plan', 'plan.json', '--profile', 'core', '--dry-run'])",
            "visual_status": "implemented",
        },
        {
            "id": "action.emit_setup_plan",
            "description": "Emit a structured setup plan to a file",
            "category": "plan",
            "equivalent_command": ["cf", "setup", "wizard", "--emit-plan", "<path>", "--profile", "<profile>", "--dry-run"],
            "plan_field": None,
            "transcript_field": "executed_actions",
            "scripted_input_path": None,
            "test_harness_api": "cf_setup_wizard.wizard_integration.emit_plan(...)",
            "visual_status": "implemented",
        },
        {
            "id": "action.execute_setup_plan",
            "description": "Execute a structured setup plan from a file",
            "category": "plan",
            "equivalent_command": ["cf", "setup", "wizard", "--execute-plan", "<path>", "--record", "<path>"],
            "plan_field": None,
            "transcript_field": "executed_actions",
            "scripted_input_path": None,
            "test_harness_api": "cf_setup_wizard.wizard_integration.load_plan(...)",
            "visual_status": "implemented",
        },
        {
            "id": "action.record_transcript",
            "description": "Record a transcript of the session",
            "category": "transcript",
            "equivalent_command": ["cf", "setup", "wizard", "--record", "<path>"],
            "plan_field": None,
            "transcript_field": None,
            "scripted_input_path": None,
            "test_harness_api": "cf_setup_wizard.wizard_integration.build_transcript(...)",
            "visual_status": "implemented",
        },
        {
            "id": "action.run_install_dry_run",
            "description": "Run install in dry-run mode",
            "category": "install",
            "equivalent_command": ["cf", "setup", "install", "--profile", "<profile>", "--dry-run"],
            "plan_field": "choices.dry_run",
            "transcript_field": "executed_actions",
            "scripted_input_path": "plan.json#choices.dry_run",
            "test_harness_api": "cf_setup_wizard.cli.main(['--plain', '--profile', 'core', '--dry-run'])",
            "visual_status": "implemented",
        },
        {
            "id": "action.run_install",
            "description": "Run install execution",
            "category": "install",
            "equivalent_command": ["cf", "setup", "install", "--profile", "<profile>"],
            "plan_field": "choices.dry_run",
            "transcript_field": "executed_actions",
            "scripted_input_path": "plan.json#choices.dry_run",
            "test_harness_api": "cf_setup_wizard.cli.main(['--plain', '--profile', 'core'])",
            "visual_status": "implemented",
        },
        {
            "id": "action.run_clean_dry_run",
            "description": "Run clean dry-run for selected profile",
            "category": "clean",
            "equivalent_command": ["cf", "setup", "clean", "--profile", "<profile>", "--dry-run"],
            "plan_field": "choices.dry_run",
            "transcript_field": "executed_actions",
            "scripted_input_path": "plan.json#choices.dry_run",
            "test_harness_api": "cf_setup_wizard.cli.main(['--clean-profile', 'repo-clean', '--dry-run', '--summary'])",
            "visual_status": "implemented",
        },
        {
            "id": "action.run_clean",
            "description": "Run clean execution for selected profile",
            "category": "clean",
            "equivalent_command": ["cf", "setup", "clean", "--profile", "<profile>", "--yes"],
            "plan_field": "choices.dry_run",
            "transcript_field": "executed_actions",
            "scripted_input_path": "plan.json#choices.dry_run",
            "test_harness_api": "cf_setup_wizard.cli.main(['--clean-profile', 'repo-clean', '--yes', '--summary'])",
            "visual_status": "implemented",
        },
        {
            "id": "action.confirm_cleanup",
            "description": "Confirm destructive cleanup execution",
            "category": "confirmation",
            "equivalent_command": ["cf", "setup", "clean", "--profile", "<profile>", "--yes"],
            "plan_field": "choices.yes",
            "transcript_field": "choices.yes",
            "scripted_input_path": "plan.json#choices.yes",
            "test_harness_api": "WizardChoices(yes=True)",
            "visual_status": "implemented",
        },
        {
            "id": "action.cancel_cleanup",
            "description": "Cancel or reject destructive cleanup",
            "category": "confirmation",
            "equivalent_command": None,
            "plan_field": "choices.yes",
            "transcript_field": "choices.yes",
            "scripted_input_path": "plan.json#choices.yes",
            "test_harness_api": "WizardChoices(yes=False)",
            "visual_status": "implemented",
        },
        {
            "id": "action.show_equivalent_command",
            "description": "Show the equivalent CLI command for current choices",
            "category": "information",
            "equivalent_command": None,
            "plan_field": "equivalent_command",
            "transcript_field": "equivalent_command",
            "scripted_input_path": None,
            "test_harness_api": "cf_setup_wizard.wizard_integration.build_equivalent_command(...)",
            "visual_status": "implemented",
        },
        {
            "id": "action.show_help",
            "description": "Show help information",
            "category": "information",
            "equivalent_command": ["cf", "setup", "wizard", "--help"],
            "plan_field": None,
            "transcript_field": None,
            "scripted_input_path": None,
            "test_harness_api": "cf_setup_wizard.cli.main(['--help'])",
            "visual_status": "implemented",
        },
        {
            "id": "action.exit",
            "description": "Exit the TUI",
            "category": "navigation",
            "equivalent_command": None,
            "plan_field": None,
            "transcript_field": None,
            "scripted_input_path": None,
            "test_harness_api": "Keyboard interrupt or scripted abort",
            "visual_status": "implemented",
        },
    ]

    actions.extend(action_items)
    return actions


def list_actions() -> List[Dict[str, Any]]:
    """Return the canonical list of Setup TUI actions."""
    global _ACTIONS
    if not _ACTIONS:
        _ACTIONS = _build_actions()
    return _ACTIONS


def get_action(action_id: str) -> Dict[str, Any] | None:
    """Return a single action definition by ID, or None if not found."""
    for action in list_actions():
        if action["id"] == action_id:
            return action
    return None


def validate_registry() -> Dict[str, Any]:
    """Validate the registry and return a report dict.

    Checks:
    - uniqueness of action IDs
    - every action has at least one non-visual control path
    - action IDs follow the naming convention
    """
    actions = list_actions()
    ids = [a["id"] for a in actions]
    unique_ids = set(ids)

    report: Dict[str, Any] = {
        "valid": True,
        "total_actions": len(actions),
        "unique_ids": len(unique_ids),
        "duplicate_ids": [],
        "missing_non_visual_path": [],
        "invalid_id_prefix": [],
    }

    if len(ids) != len(unique_ids):
        report["valid"] = False
        seen = set()
        for aid in ids:
            if aid in seen:
                report["duplicate_ids"].append(aid)
            seen.add(aid)

    for action in actions:
        has_path = any(
            action.get(field) is not None
            for field in (
                "equivalent_command",
                "plan_field",
                "transcript_field",
                "scripted_input_path",
                "test_harness_api",
            )
        )
        if not has_path:
            report["valid"] = False
            report["missing_non_visual_path"].append(action["id"])

        if not any(
            action["id"].startswith(prefix)
            for prefix in ("select.", "toggle.", "action.")
        ):
            report["valid"] = False
            report["invalid_id_prefix"].append(action["id"])

    return report


def to_json() -> str:
    """Serialize the action list to a JSON string."""
    return json.dumps(list_actions(), indent=2)
