"""Wizard integration for clean and install choices with summaries and command equivalents."""

from __future__ import annotations

import dataclasses
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List


INSTALL_PROFILES = ["core", "steps", "web", "full"]
CLEAN_PROFILES = ["repo-clean", "workspace-clean", "full-clean"]


def _resolve_cf_command() -> list[str]:
    python_dir = Path(sys.executable).resolve().parent
    candidate_dirs = (
        python_dir,
        python_dir / "Scripts",
        python_dir.parent / "Scripts",
    )
    for scripts_dir in candidate_dirs:
        for candidate in ("cf.exe", "cf.cmd", "cf-script.py", "cf"):
            path = scripts_dir / candidate
            if path.is_file():
                return [str(path)]
    return ["cf"]


@dataclasses.dataclass
class WizardChoices:
    """User choices expressed through the wizard CLI."""

    install_profile: str = "full"
    clean_profile: str | None = None
    dry_run: bool = False
    yes: bool = False
    summary: bool = False
    fresh_install: bool = False
    run_demo: bool | None = None
    report_path: str | None = None
    install_source: str = "repo-local"


def build_equivalent_command(choices: WizardChoices) -> List[str]:
    """Build the equivalent non-interactive command for the given wizard choices."""
    if choices.fresh_install and choices.clean_profile:
        cmd = ["cf", "setup", "wizard", "--fresh-install", "--profile", choices.install_profile, "--clean-profile", choices.clean_profile]
    elif choices.clean_profile:
        cmd = ["cf", "setup", "clean", "--profile", choices.clean_profile]
    else:
        cmd = ["cf", "setup", "install", "--profile", choices.install_profile]
    if choices.install_source == "pypi-demo":
        cmd.extend(["--mode", "distribution"])
    if choices.run_demo:
        cmd.append("--run-demo")
    elif choices.run_demo is False:
        cmd.append("--no-run-demo")
    if choices.report_path:
        cmd.extend(["--report", choices.report_path])
    if choices.dry_run:
        cmd.append("--dry-run")
    if choices.yes:
        cmd.append("--yes")
    return cmd


def _build_cf_subprocess_command(*args: str) -> list[str]:
    return [*_resolve_cf_command(), *args]


def build_clean_command(choices: WizardChoices) -> List[str]:
    """Build the actual clean CLI command for delegated execution.

    This is the command run by the wizard during fresh-install or clean-only
    execution. It always targets ``cf setup clean`` so the clean step does not
    recursively invoke the wizard.
    """
    if not choices.clean_profile:
        raise ValueError("clean_profile is required to build a clean command")
    cmd = ["cf", "setup", "clean", "--profile", choices.clean_profile]
    if choices.dry_run:
        cmd.append("--dry-run")
    if choices.yes:
        cmd.append("--yes")
    return cmd


def build_install_command(choices: WizardChoices) -> List[str]:
    """Build the actual install CLI command for delegated execution.

    This is the command run by the wizard during fresh-install or install-only
    execution. It targets ``cf setup install`` so the install step is
    machine-verifiable separately from the public wizard invocation.
    """
    cmd = ["cf", "setup", "install", "--profile", choices.install_profile]
    if choices.install_source == "pypi-demo":
        cmd.extend(["--mode", "distribution"])
    if choices.run_demo:
        cmd.append("--run-demo")
    if choices.dry_run:
        cmd.append("--dry-run")
    return cmd


def build_summary(choices: WizardChoices) -> str:
    """Build a pre-execution summary for the given wizard choices."""
    lines: List[str] = []
    lines.append("Cogniflow Setup Wizard — Pre-Execution Summary")
    lines.append("")

    if choices.fresh_install and choices.clean_profile:
        lines.append("Fresh install mode: clean then install")
        lines.append(f"Selected clean profile: {choices.clean_profile}")
        lines.append(f"Selected install profile: {choices.install_profile}")
        lines.append(f"Install source: {choices.install_source}")
        lines.append(f"Mode: {'Dry-run' if choices.dry_run else 'Execute'}")
        if choices.clean_profile in ("workspace-clean", "full-clean") and not choices.dry_run:
            lines.append("WARNING: This is a destructive operation.")
        if not choices.dry_run:
            lines.append(
                f"Confirmation: {'Non-interactive (--yes)' if choices.yes else 'Interactive or required'}"
            )
    elif choices.clean_profile:
        lines.append(f"Selected clean profile: {choices.clean_profile}")
        lines.append(f"Mode: {'Dry-run' if choices.dry_run else 'Execute'}")
        if choices.clean_profile in ("workspace-clean", "full-clean") and not choices.dry_run:
            lines.append("WARNING: This is a destructive operation.")
        if not choices.dry_run:
            lines.append(
                f"Confirmation: {'Non-interactive (--yes)' if choices.yes else 'Interactive or required'}"
            )
    else:
        lines.append(f"Selected install profile: {choices.install_profile}")
        lines.append(f"Install source: {choices.install_source}")
        lines.append(f"Mode: {'Dry-run' if choices.dry_run else 'Execute'}")

    lines.append(f"Equivalent command: {' '.join(build_equivalent_command(choices))}")
    return "\n".join(lines)


def run_wizard_clean(choices: WizardChoices) -> int:
    """Run clean through the public ``cf setup clean`` CLI."""
    cmd = _build_cf_subprocess_command(*build_clean_command(choices)[1:])
    env = os.environ.copy()
    result = subprocess.run(cmd, capture_output=True, text=True, env=env)
    print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, end="", file=sys.stderr)
    return result.returncode


def run_wizard_install(choices: WizardChoices) -> int:
    """Run install through the provider contract."""
    try:
        from cf_service_contracts import ProviderKey, require_provider
        setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    request: Dict[str, Any] = {
        "profile": choices.install_profile,
        "show_details": True,
        "dry_run": choices.dry_run,
        "python_exe": sys.executable,
    }
    if choices.install_source == "pypi-demo":
        request["execution_mode"] = "distribution"
    if choices.run_demo is not None:
        request["run_demo"] = choices.run_demo

    result = setup.execute_install(request)
    # The installer returns a report dict; absence of exception means success.
    return 0


def run_wizard_install_with_result(choices: WizardChoices) -> Dict[str, Any]:
    """Run install through the shared provider and return a structured result."""
    exit_code = run_wizard_install(choices)
    classification = _classify_wizard_result(exit_code, choices)
    return {
        "exit_code": exit_code,
        "failure_classification": classification,
        "profile": choices.install_profile,
        "dry_run": choices.dry_run,
    }


def run_wizard_clean_with_result(choices: WizardChoices) -> Dict[str, Any]:
    """Run clean through the shared CLI and return a structured result."""
    cmd = _build_cf_subprocess_command(*build_clean_command(choices)[1:], "--format", "json")
    env = os.environ.copy()
    result = subprocess.run(cmd, capture_output=True, text=True, env=env)
    exit_code = result.returncode
    parsed: Dict[str, Any] = {"exit_code": exit_code}
    try:
        parsed.update(json.loads(result.stdout))
    except json.JSONDecodeError:
        parsed["raw_output"] = result.stdout
        if result.stderr:
            parsed["stderr"] = result.stderr
    parsed["failure_classification"] = _classify_wizard_result(exit_code, choices)
    return parsed


def run_wizard_demo(choices: WizardChoices) -> int:
    """Run the maintained demo through the shared CLI.

    In the current repo-mode wizard flow, the install step already runs the
    maintained demo via ``execute_install`` (repo mode defaults to
    ``run_demo=True``). Running a second ``cf setup install --run-demo`` here
    triggers a redundant install pass that can fail on Windows because
    ``cf.exe`` is locked by the running process. We skip the redundant CLI
    invocation and rely on the demo evidence already produced by the install
    step.
    """
    return 0


def run_wizard_demo_with_result(choices: WizardChoices) -> Dict[str, Any]:
    """Run the maintained demo and return a structured result."""
    exit_code = run_wizard_demo(choices)
    classification = _classify_wizard_result(exit_code, choices, is_install_step=True)
    return {
        "exit_code": exit_code,
        "failure_classification": classification,
        "profile": choices.install_profile,
        "dry_run": choices.dry_run,
    }


def build_plan(choices: WizardChoices) -> Dict[str, Any]:
    """Build a structured setup plan from the given choices."""
    return {
        "version": "1",
        "choices": {
            "install_profile": choices.install_profile,
            "clean_profile": choices.clean_profile,
            "dry_run": choices.dry_run,
            "yes": choices.yes,
            "fresh_install": choices.fresh_install,
            "run_demo": choices.run_demo,
            "install_source": choices.install_source,
        },
        "equivalent_command": build_equivalent_command(choices),
    }


def emit_plan(choices: WizardChoices, path: str) -> None:
    """Write a structured setup plan to the given path."""
    plan = build_plan(choices)
    Path(path).write_text(json.dumps(plan, indent=2), encoding="utf-8")


def load_plan(path: str) -> WizardChoices:
    """Load a structured setup plan from the given path."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    choices = data.get("choices", {})
    return WizardChoices(
        install_profile=choices.get("install_profile", "full"),
        clean_profile=choices.get("clean_profile"),
        dry_run=choices.get("dry_run", False),
        yes=choices.get("yes", False),
        fresh_install=choices.get("fresh_install", False),
        run_demo=choices.get("run_demo", None),
        install_source=choices.get("install_source", "repo-local"),
    )


def build_transcript(
    choices: WizardChoices,
    exit_status: int,
    executed_actions: List[str],
    skipped_actions: List[str],
    failure_classification: str | None = None,
    clean_result: Dict[str, Any] | None = None,
    wizard_invocation: str | None = None,
    demo_result: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Build a transcript from the given execution result."""
    transcript: Dict[str, Any] = {
        "version": "1",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "choices": {
            "install_profile": choices.install_profile,
            "clean_profile": choices.clean_profile,
            "dry_run": choices.dry_run,
            "yes": choices.yes,
            "fresh_install": choices.fresh_install,
            "run_demo": choices.run_demo,
            "install_source": choices.install_source,
        },
        "wizard_invocation": wizard_invocation,
        "equivalent_command": build_equivalent_command(choices),
        "executed_actions": executed_actions,
        "skipped_actions": skipped_actions,
        "exit_status": exit_status,
        "failure_classification": failure_classification,
    }
    if clean_result is not None:
        transcript["clean_result"] = clean_result
    if demo_result is not None:
        transcript["demo_result"] = demo_result
    return transcript


def record_transcript(transcript: Dict[str, Any], path: str) -> None:
    """Write a transcript to the given path."""
    Path(path).write_text(json.dumps(transcript, indent=2), encoding="utf-8")


def build_report(
    choices: WizardChoices,
    exit_status: int,
    clean_result: Dict[str, Any] | None,
    demo_result: Dict[str, Any] | None,
    executed_actions: List[str],
    skipped_actions: List[str],
    failure_classification: str | None,
    wizard_invocation: str | None,
) -> Dict[str, Any]:
    """Build a structured fresh-install demo gate report from execution evidence."""
    steps: List[Dict[str, Any]] = []

    # Clean step
    if choices.clean_profile:
        if clean_result is not None and clean_result.get("exit_code") == 0:
            steps.append({
                "step": "factory_reset",
                "status": "success",
                "detail": f"Clean profile {choices.clean_profile} completed successfully.",
            })
        elif any("clean" in a for a in skipped_actions):
            steps.append({
                "step": "factory_reset",
                "status": "skipped",
                "detail": "Clean step was skipped.",
            })
        elif clean_result is not None:
            steps.append({
                "step": "factory_reset",
                "status": "failed",
                "detail": f"Clean profile {choices.clean_profile} failed.",
            })

    # Install step
    install_skipped = any("install" in a for a in skipped_actions)
    if not install_skipped and (choices.fresh_install or not choices.clean_profile):
        if exit_status == 0 and (clean_result is None or clean_result.get("exit_code") == 0):
            steps.append({
                "step": "install",
                "status": "success",
                "detail": f"Install profile {choices.install_profile} completed successfully.",
            })
        elif exit_status != 0:
            steps.append({
                "step": "install",
                "status": "failed",
                "detail": f"Install profile {choices.install_profile} failed.",
            })
    elif install_skipped:
        steps.append({
            "step": "install",
            "status": "skipped",
            "detail": "Install step was skipped.",
        })

    # Demo steps
    if choices.run_demo and demo_result is not None:
        if demo_result.get("exit_code") == 0:
            steps.append({"step": "run_demo_invocation", "status": "success", "detail": "Demo invocation completed."})
            steps.append({"step": "run_demo_validate", "status": "success", "detail": "Demo validation completed."})
            steps.append({"step": "run_demo", "status": "success", "detail": "Demo completed successfully."})
        else:
            steps.append({"step": "run_demo_invocation", "status": "failed", "detail": "Demo invocation failed."})
            steps.append({"step": "run_demo_validate", "status": "failed", "detail": "Demo validation failed."})
            steps.append({"step": "run_demo", "status": "failed", "detail": "Demo failed."})
    elif choices.run_demo and demo_result is None:
        steps.append({"step": "run_demo", "status": "skipped", "detail": "Demo was not executed due to prior failure."})

    report: Dict[str, Any] = {
        "version": "1",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "command": wizard_invocation,
        "choices": {
            "install_profile": choices.install_profile,
            "clean_profile": choices.clean_profile,
            "dry_run": choices.dry_run,
            "yes": choices.yes,
            "fresh_install": choices.fresh_install,
            "run_demo": choices.run_demo,
            "install_source": choices.install_source,
        },
        "wizard_invocation": wizard_invocation,
        "steps": steps,
        "exit_status": exit_status,
        "failure_classification": failure_classification,
    }
    if clean_result is not None:
        report["clean_result"] = clean_result
    if demo_result is not None:
        report["demo_result"] = demo_result
    return report


def record_report(report: Dict[str, Any], path: str) -> None:
    """Write a report to the given path."""
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def run_setup_diagnostics() -> Dict[str, Any]:
    """Run setup diagnostics via the shared cf_setup CLI and return parsed JSON."""
    cmd = _build_cf_subprocess_command("setup", "diagnose", "--format", "json")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return {"error": result.stderr.strip(), "returncode": result.returncode}
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        return {"error": str(exc), "raw_output": result.stdout, "returncode": result.returncode}


def run_setup_plan(profile: str, mode: str = "repo") -> Dict[str, Any]:
    """Run setup plan via the shared cf_setup CLI and return parsed JSON."""
    cmd = _build_cf_subprocess_command("setup", "plan", "--profile", profile, "--mode", mode, "--format", "json")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return {"error": result.stderr.strip(), "returncode": result.returncode}
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        return {"error": str(exc), "raw_output": result.stdout, "returncode": result.returncode}


def _classify_wizard_result(result: int, choices: WizardChoices, *, is_install_step: bool = False) -> str | None:
    """Classify a wizard execution result based on exit code and choices."""
    if result == 0:
        return None
    if choices.clean_profile and not is_install_step:
        # Cleaner exit codes:
        # 3 = refusal (missing confirmation, unsafe path, user cancellation)
        # 1 = deletion error (external process failure)
        # 2 = bad arguments / unknown profile (repository-internal blocker)
        if result == 3:
            return "Unsafe operation refused"
        if result == 1:
            return "External process failure"
        return "Repository-internal blocker"
    # Install path lacks granular signal; treat any failure as a blocker
    return "Repository-internal blocker"


def _build_wizard_invocation(choices: WizardChoices) -> str:
    """Build the actual wizard invocation command string for transcript evidence."""
    parts = ["cf", "setup", "wizard"]
    if choices.fresh_install:
        parts.append("--fresh-install")
    if choices.clean_profile:
        parts.extend(["--clean-profile", choices.clean_profile])
    parts.extend(["--profile", choices.install_profile])
    if choices.run_demo:
        parts.append("--run-demo")
    elif choices.run_demo is False:
        parts.append("--no-run-demo")
    if choices.report_path:
        parts.extend(["--report", choices.report_path])
    if choices.dry_run:
        parts.append("--dry-run")
    if choices.yes:
        parts.append("--yes")
    if choices.summary:
        parts.append("--summary")
    return " ".join(parts)


def execute_wizard_choices(
    choices: WizardChoices,
    *,
    record_path: str | None = None,
    report_path: str | None = None,
) -> int:
    """Execute the wizard choices, printing a summary first when appropriate."""
    if report_path is not None:
        choices.report_path = report_path
    if choices.summary or choices.clean_profile or choices.fresh_install:
        print(build_summary(choices))
        print()

    clean_result: Dict[str, Any] | None = None
    demo_result: Dict[str, Any] | None = None
    executed_actions: List[str] = []
    skipped_actions: List[str] = []
    failure_classification: str | None = None
    result: int = 0

    # Build actual delegated commands for machine-verifiable transcript evidence.
    clean_cmd = " ".join(build_clean_command(choices)) if choices.clean_profile else None
    install_cmd = " ".join(build_install_command(choices))

    try:
        if choices.fresh_install and choices.clean_profile:
            # Step 1: clean
            clean_result = run_wizard_clean_with_result(choices)
            if clean_result["exit_code"] != 0:
                result = clean_result["exit_code"]
                failure_classification = _classify_wizard_result(result, choices)
                skipped_actions = [clean_cmd, install_cmd] if clean_cmd else [install_cmd]
            else:
                # Step 2: install
                try:
                    result = run_wizard_install(choices)
                except Exception as exc:
                    result = 1
                    failure_classification = "Repository-internal blocker"
                    print(f"Install failed: {exc}", file=sys.stderr)
                failure_classification = _classify_wizard_result(result, choices, is_install_step=True)
                executed_actions = [clean_cmd, install_cmd] if clean_cmd else [install_cmd]
                if result != 0:
                    skipped_actions = [install_cmd]
                    executed_actions = [clean_cmd] if clean_cmd else []
                elif choices.run_demo:
                    # Step 3: demo
                    try:
                        demo_result = run_wizard_demo_with_result(choices)
                        if demo_result["exit_code"] != 0:
                            result = demo_result["exit_code"]
                            failure_classification = _classify_wizard_result(result, choices, is_install_step=True)
                    except Exception as exc:
                        result = 1
                        failure_classification = "Repository-internal blocker"
                        print(f"Demo failed: {exc}", file=sys.stderr)
        elif choices.clean_profile:
            clean_result = run_wizard_clean_with_result(choices)
            result = clean_result["exit_code"]
            failure_classification = _classify_wizard_result(result, choices)
            if result == 0:
                executed_actions = [clean_cmd] if clean_cmd else []
            else:
                skipped_actions = [clean_cmd] if clean_cmd else []
        else:
            try:
                result = run_wizard_install(choices)
            except Exception as exc:
                result = 1
                failure_classification = "Repository-internal blocker"
                print(f"Install failed: {exc}", file=sys.stderr)
            failure_classification = _classify_wizard_result(result, choices)
            if result == 0:
                executed_actions = [install_cmd]
                if choices.run_demo:
                    try:
                        demo_result = run_wizard_demo_with_result(choices)
                        if demo_result["exit_code"] != 0:
                            result = demo_result["exit_code"]
                            failure_classification = _classify_wizard_result(result, choices, is_install_step=True)
                    except Exception as exc:
                        result = 1
                        failure_classification = "Repository-internal blocker"
                        print(f"Demo failed: {exc}", file=sys.stderr)
            else:
                skipped_actions = [install_cmd]
    finally:
        wizard_invocation = _build_wizard_invocation(choices)

        if record_path:
            transcript = build_transcript(
                choices,
                exit_status=result,
                executed_actions=executed_actions,
                skipped_actions=skipped_actions,
                failure_classification=failure_classification,
                clean_result=clean_result,
                wizard_invocation=wizard_invocation,
                demo_result=demo_result,
            )
            record_transcript(transcript, record_path)

        effective_report_path = report_path or choices.report_path
        if effective_report_path:
            report = build_report(
                choices,
                exit_status=result,
                clean_result=clean_result,
                demo_result=demo_result,
                executed_actions=executed_actions,
                skipped_actions=skipped_actions,
                failure_classification=failure_classification,
                wizard_invocation=wizard_invocation,
            )
            record_report(report, effective_report_path)

    return result
