"""Header widget with futuristic design."""

from textual.widgets import Static


class WizardHeader(Static):
    """The main header showing the Cogniflow logo and title."""

    def __init__(self, title: str = "Cogniflow Setup", subtitle: str = "", **kwargs):
        super().__init__("", **kwargs)
        self.title = title
        self.subtitle = subtitle

    def on_mount(self) -> None:
        text = self.title
        if self.subtitle:
            text += "\n" + self.subtitle
        self.update(text)


class StepHeader(Static):
    """Header showing current step in the wizard."""

    def __init__(self, step_number: int, total_steps: int, step_name: str, **kwargs):
        super().__init__("", **kwargs)
        self.step_number = step_number
        self.total_steps = total_steps
        self.step_name = step_name

    def on_mount(self) -> None:
        self.update(f"[cyan]Step {self.step_number}/{self.total_steps}:[/] {self.step_name}")


CogniflowLogo = r"""
    ____                  _____
   / __ \________  _  __/ ___/___  ____ _   ___
  / /_/ / ___/ / / / /\__ \/ _ \/ __ `/ | / /
 / _, _/ /  / /_/ / /__/ / __/ /_/ /| |/ / /
/_/ |_/_/   \__, / /____/\___/\__,_/_/|___/
           /____/
"""