"""Progress bar widget with anime-style display."""

from textual.widgets import Static


class ProgressBar(Static):
    """A progress bar widget with percentage display."""

    def __init__(self, total: float = 100.0, show_percentage: bool = True, show_eta: bool | None = None, **kwargs):
        super().__init__("", **kwargs)
        self.total = total
        self.value = 0.0
        self.show_percentage = show_percentage
        self.show_eta = show_eta
        self.bar_width = 30

    def on_mount(self) -> None:
        self._render_progress()

    def update_progress(self, value: float) -> None:
        """Update progress to a new value."""
        self.value = min(max(value, 0), self.total)
        self._render_progress()

    def _render_progress(self) -> None:
        percent = (self.value / self.total) * 100 if self.total > 0 else 0
        filled = int((self.value / self.total) * self.bar_width) if self.total > 0 else 0
        bar = "█" * filled + "░" * (self.bar_width - filled)

        if self.show_percentage:
            self.update(f"[cyan]{bar}[/] {percent:.1f}%")
        else:
            self.update(f"[cyan]{bar}[/]")
