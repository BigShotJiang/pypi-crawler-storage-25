"""Interactive checklist widget."""

from dataclasses import dataclass
from typing import Callable

from textual import on
from textual.widget import Widget
from textual.widgets import Static, Button


@dataclass
class ChecklistItem:
    """An item in a checklist."""

    id: str
    label: str
    selected: bool = False
    enabled: bool = True


class ChecklistView(Widget):
    """An interactive checklist with selectable items."""

    def __init__(self, items: list[ChecklistItem] | None = None, **kwargs):
        super().__init__(**kwargs)
        self.items = items or []

    def compose(self):
        for item in self.items:
            yield Static(
                f"{'[x]' if item.selected else '[ ]'} {item.label}",
                classes="checklist-item" + (" disabled" if not item.enabled else ""),
            )

    def watch_items(self) -> None:
        self.remove_children(".checklist-item")
        for item in self.compose():
            self.mount(item)