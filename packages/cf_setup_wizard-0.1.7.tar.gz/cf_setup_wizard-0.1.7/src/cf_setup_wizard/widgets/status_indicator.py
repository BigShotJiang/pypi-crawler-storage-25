"""Status indicator widget for showing check/cross/warning states."""

from textual.widgets import Static


class StatusIndicator(Static):
    """A status indicator showing ✓, ✗, or ⚠ with appropriate colors."""

    def __init__(self, status: str = "pending", label: str = "", **kwargs):
        super().__init__("", **kwargs)
        self.status = status
        self.label = label

    def on_mount(self) -> None:
        self._update_text()

    def _update_text(self) -> None:
        icons = {
            "success": "✓",
            "error": "✗",
            "warning": "⚠",
            "pending": "○",
        }
        self.update(f" {icons.get(self.status, '○')} {self.label}")


