"""CLI entry point for ``cf wizard``."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cf wizard", description="Cogniflow setup wizard")
    parser.add_argument("--profile", default="full", choices=["core", "steps", "web", "full"])
    parser.add_argument("--tui", action="store_true", help="Launch the interactive TUI (default when no automation flags are given)")
    parser.add_argument("--no-tui", action="store_true", help="Use the classic installer instead of the wizard")
    parser.add_argument("--resume-install", action="store_true", help="Resume directly into the install flow.")
    parser.add_argument("--run-demo", dest="run_demo", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--show-details", dest="show_details", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--fresh-install", action="store_true", help="Run clean then install (requires --clean-profile)")
    parser.add_argument(
        "--clean-profile",
        choices=["repo-clean", "workspace-clean", "full-clean"],
        help="Select a clean profile to run (implies non-interactive mode)",
    )
    parser.add_argument("--install-source", choices=["repo-local", "pypi-demo"], default="repo-local", help="Select the install source mode")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be done without making changes")
    parser.add_argument("--yes", action="store_true", help="Confirm destructive cleanup non-interactively")
    parser.add_argument("--summary", action="store_true", help="Show pre-execution summary")
    parser.add_argument("--emit-plan", metavar="PATH", help="Emit a structured setup plan to the given path")
    parser.add_argument("--execute-plan", metavar="PATH", help="Execute a structured setup plan from the given path")
    parser.add_argument("--record", metavar="PATH", help="Record a transcript of the wizard run to the given path")
    parser.add_argument("--report", metavar="PATH", help="Write a structured fresh-install demo gate report to the given path")
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument("--plain", action="store_true", help="Force plain deterministic text output (implies non-interactive)")
    parser.add_argument("--script", metavar="PATH", help="Alias for --execute-plan (scripted answer file)")
    parser.add_argument("--list-actions", action="store_true", help="List available TUI actions")
    parser.add_argument("--format", choices=["json", "text"], default="text", help="Output format for --list-actions")
    parser.add_argument("--test-mode", action="store_true", help="Run TUI in deterministic non-interactive test mode")
    parser.add_argument("--test-script", metavar="PATH", help="Action sequence JSON file for test mode")
    parser.add_argument("--actions", metavar="ACTIONS", help="Comma-separated list of action IDs to execute in test mode (implies --test-mode)")
    parser.add_argument("--replay-transcript", metavar="PATH", help="Replay executed_actions from a recorded transcript in test mode")
    args = parser.parse_args(argv if argv is not None else None)

    from .wizard_integration import WizardChoices, execute_wizard_choices, emit_plan, load_plan, build_summary

    record_path = getattr(args, "record", None)
    report_path = getattr(args, "report", None)

    if args.list_actions:
        from . import action_registry
        actions = action_registry.list_actions()
        if args.format == "json":
            print(json.dumps(actions, indent=2))
        else:
            for action in actions:
                print(f"{action['id']}: {action['description']}")
        return 0

    if args.emit_plan:
        choices = WizardChoices(
            install_profile=args.profile,
            clean_profile=args.clean_profile,
            dry_run=args.dry_run,
            yes=args.yes,
            fresh_install=args.fresh_install,
            run_demo=args.run_demo if args.run_demo is not None else True,
            install_source=args.install_source,
        )
        if args.summary or args.plain:
            print(build_summary(choices))
        emit_plan(choices, args.emit_plan)
        return 0

    plan_path = args.execute_plan or args.script
    if plan_path:
        choices = load_plan(plan_path)
        # CLI overrides take precedence over plan contents
        if args.clean_profile:
            choices.clean_profile = args.clean_profile
        if args.dry_run:
            choices.dry_run = True
        if args.yes:
            choices.yes = True
        if args.fresh_install:
            choices.fresh_install = True
        if args.run_demo is not None:
            choices.run_demo = args.run_demo
        if args.install_source:
            choices.install_source = args.install_source
        choices.summary = args.summary or args.plain
        return execute_wizard_choices(choices, record_path=record_path, report_path=report_path)

    if args.test_mode or args.test_script or args.replay_transcript or args.actions:
        # Test-mode must short-circuit before plain/no-color classic install
        # routing so that combined --tui --plain --no-color --test-mode reaches
        # TUINavigator instead of install behavior.
        action_sequence: list[str] = []
        if args.test_script:
            action_sequence = json.loads(Path(args.test_script).read_text(encoding="utf-8"))
        elif args.actions:
            action_sequence = [a.strip() for a in args.actions.split(",") if a.strip()]
        from .tui_shell import TUINavigator
        navigator = TUINavigator(
            test_mode=True,
            plain=args.plain,
            no_color=args.no_color,
            profile=args.profile,
            clean_profile=args.clean_profile,
            dry_run=args.dry_run,
            yes=args.yes,
            record_path=record_path,
            install_source=args.install_source,
        )
        if args.replay_transcript:
            return navigator.replay_from_transcript(args.replay_transcript)
        return navigator.run(action_sequence)

    if args.plain or args.no_color:
        # Force non-interactive path with deterministic plain output
        if args.clean_profile:
            choices = WizardChoices(
                install_profile=args.profile,
                clean_profile=args.clean_profile,
                dry_run=args.dry_run,
                yes=args.yes,
                summary=args.summary,
                fresh_install=args.fresh_install,
                run_demo=args.run_demo if args.run_demo is not None else True,
                install_source=args.install_source,
            )
            return execute_wizard_choices(choices, record_path=record_path, report_path=report_path)
        return run_classic_install(args.profile, dry_run=args.dry_run)

    if args.clean_profile:
        choices = WizardChoices(
            install_profile=args.profile,
            clean_profile=args.clean_profile,
            dry_run=args.dry_run,
            yes=args.yes,
            summary=args.summary,
            fresh_install=args.fresh_install,
            run_demo=args.run_demo if args.run_demo is not None else True,
            install_source=args.install_source,
        )
        return execute_wizard_choices(choices, record_path=record_path, report_path=report_path)

    if args.no_tui:
        return run_classic_install(args.profile, dry_run=args.dry_run)

    return run_textual_app(
        args.profile,
        resume_install=args.resume_install,
        run_demo=args.run_demo if args.run_demo is not None else True,
        show_details=args.show_details,
    )


def run_textual_app(
    profile: str,
    *,
    resume_install: bool = False,
    run_demo: bool = True,
    show_details: bool = True,
) -> int:
    try:
        from .app import CogniflowWizardApp
        app = CogniflowWizardApp(
            profile,
            resume_install=resume_install,
            run_demo_default=run_demo,
            show_details_default=show_details,
        )
        app.run(mouse=False)
        return 0
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 1


def run_classic_install(profile: str, *, dry_run: bool = False) -> int:
    try:
        from cf_service_contracts import ProviderKey, require_provider
        setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
        setup.execute_install({
            "profile": profile,
            "show_details": True,
            "dry_run": dry_run,
            "python_exe": sys.executable,
        })
        # The installer returns a report dict; absence of exception means success.
        return 0
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
