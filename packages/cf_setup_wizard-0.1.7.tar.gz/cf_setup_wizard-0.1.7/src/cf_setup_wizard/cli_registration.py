"""Wizard CLI registration for cf_core_cli."""

import argparse


def _add_wizard_parser(subparsers) -> argparse.ArgumentParser:
    parser = subparsers.add_parser(
        "wizard",
        help="Launch interactive Cogniflow setup wizard",
    )
    parser.add_argument("--profile", default="full", choices=["core", "steps", "web", "full"])
    parser.add_argument("--tui", action="store_true", help="Launch the interactive TUI (default when no automation flags are given)")
    parser.add_argument("--no-tui", action="store_true", help="Run non-interactive install instead of TUI")
    parser.add_argument("--fresh-install", action="store_true", help="Run clean then install (requires --clean-profile)")
    parser.add_argument(
        "--clean-profile",
        choices=["repo-clean", "workspace-clean", "full-clean"],
        help="Select a clean profile to run (implies non-interactive mode)",
    )
    parser.add_argument("--run-demo", dest="run_demo", action=argparse.BooleanOptionalAction, default=None, help="Run the maintained demo after install")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be done without making changes")
    parser.add_argument("--yes", action="store_true", help="Confirm destructive cleanup non-interactively")
    parser.add_argument("--summary", action="store_true", help="Show pre-execution summary")
    parser.add_argument("--emit-plan", metavar="PATH", help="Emit a structured setup plan to the given path")
    parser.add_argument("--execute-plan", metavar="PATH", help="Execute a structured setup plan from the given path")
    parser.add_argument("--record", metavar="PATH", help="Record a transcript of the wizard run to the given path")
    parser.add_argument("--report", metavar="PATH", help="Write a structured fresh-install demo gate report to the given path")
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument("--plain", action="store_true", help="Force plain deterministic text output (implies non-interactive)")
    parser.add_argument("--script", metavar="PATH", help="Alias for --execute-plan (scripted answer file)")
    parser.add_argument("--list-actions", action="store_true", help="List available TUI actions")
    parser.add_argument("--format", choices=["json", "text"], default="text", help="Output format for --list-actions")
    parser.add_argument("--test-mode", action="store_true", help="Run TUI in deterministic non-interactive test mode")
    parser.add_argument("--test-script", metavar="PATH", help="Action sequence JSON file for test mode")
    parser.add_argument("--replay-transcript", metavar="PATH", help="Replay executed_actions from a recorded transcript in test mode")
    parser.set_defaults(_cf_handler=_run_wizard)
    return parser


def _run_wizard(args):
    from cf_setup_wizard.cli import main as wizard_main
    profile = getattr(args, "profile", "full")
    forwarded = ["--profile", profile]
    if getattr(args, "tui", False):
        forwarded.append("--tui")
    if getattr(args, "no_tui", False):
        forwarded.append("--no-tui")
    if getattr(args, "fresh_install", False):
        forwarded.append("--fresh-install")
    if getattr(args, "clean_profile", None):
        forwarded.extend(["--clean-profile", args.clean_profile])
    if getattr(args, "dry_run", False):
        forwarded.append("--dry-run")
    if getattr(args, "yes", False):
        forwarded.append("--yes")
    if getattr(args, "run_demo", None) is True:
        forwarded.append("--run-demo")
    elif getattr(args, "run_demo", None) is False:
        forwarded.append("--no-run-demo")
    if getattr(args, "summary", False):
        forwarded.append("--summary")
    if getattr(args, "emit_plan", None):
        forwarded.extend(["--emit-plan", args.emit_plan])
    if getattr(args, "execute_plan", None):
        forwarded.extend(["--execute-plan", args.execute_plan])
    if getattr(args, "record", None):
        forwarded.extend(["--record", args.record])
    if getattr(args, "report", None):
        forwarded.extend(["--report", args.report])
    if getattr(args, "no_color", False):
        forwarded.append("--no-color")
    if getattr(args, "plain", False):
        forwarded.append("--plain")
    if getattr(args, "script", None):
        forwarded.extend(["--script", args.script])
    if getattr(args, "list_actions", False):
        forwarded.append("--list-actions")
    if getattr(args, "format", "text") != "text":
        forwarded.extend(["--format", args.format])
    if getattr(args, "test_mode", False):
        forwarded.append("--test-mode")
    if getattr(args, "test_script", None):
        forwarded.extend(["--test-script", args.test_script])
    if getattr(args, "replay_transcript", None):
        forwarded.extend(["--replay-transcript", args.replay_transcript])
    return wizard_main(forwarded)


def _add_tui_parser(subparsers) -> argparse.ArgumentParser:
    parser = subparsers.add_parser(
        "tui",
        help="Launch interactive Cogniflow setup TUI (alias for wizard --tui)",
    )
    parser.add_argument("--profile", default="full", choices=["core", "steps", "web", "full"])
    parser.add_argument("--fresh-install", action="store_true", help="Run clean then install (requires --clean-profile)")
    parser.add_argument(
        "--clean-profile",
        choices=["repo-clean", "workspace-clean", "full-clean"],
        help="Select a clean profile to run (implies non-interactive mode)",
    )
    parser.add_argument("--run-demo", dest="run_demo", action=argparse.BooleanOptionalAction, default=None, help="Run the maintained demo after install")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be done without making changes")
    parser.add_argument("--yes", action="store_true", help="Confirm destructive cleanup non-interactively")
    parser.add_argument("--summary", action="store_true", help="Show pre-execution summary")
    parser.add_argument("--emit-plan", metavar="PATH", help="Emit a structured setup plan to the given path")
    parser.add_argument("--execute-plan", metavar="PATH", help="Execute a structured setup plan from the given path")
    parser.add_argument("--record", metavar="PATH", help="Record a transcript of the wizard run to the given path")
    parser.add_argument("--report", metavar="PATH", help="Write a structured fresh-install demo gate report to the given path")
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument("--plain", action="store_true", help="Force plain deterministic text output (implies non-interactive)")
    parser.add_argument("--script", metavar="PATH", help="Alias for --execute-plan (scripted answer file)")
    parser.add_argument("--list-actions", action="store_true", help="List available TUI actions")
    parser.add_argument("--format", choices=["json", "text"], default="text", help="Output format for --list-actions")
    parser.add_argument("--test-mode", action="store_true", help="Run TUI in deterministic non-interactive test mode")
    parser.add_argument("--test-script", metavar="PATH", help="Action sequence JSON file for test mode")
    parser.add_argument("--replay-transcript", metavar="PATH", help="Replay executed_actions from a recorded transcript in test mode")
    parser.set_defaults(_cf_handler=_run_tui)
    return parser


def _run_tui(args):
    from cf_setup_wizard.cli import main as wizard_main
    profile = getattr(args, "profile", "full")
    forwarded = ["--profile", profile, "--tui"]
    if getattr(args, "fresh_install", False):
        forwarded.append("--fresh-install")
    if getattr(args, "clean_profile", None):
        forwarded.extend(["--clean-profile", args.clean_profile])
    if getattr(args, "dry_run", False):
        forwarded.append("--dry-run")
    if getattr(args, "yes", False):
        forwarded.append("--yes")
    if getattr(args, "run_demo", None) is True:
        forwarded.append("--run-demo")
    elif getattr(args, "run_demo", None) is False:
        forwarded.append("--no-run-demo")
    if getattr(args, "summary", False):
        forwarded.append("--summary")
    if getattr(args, "emit_plan", None):
        forwarded.extend(["--emit-plan", args.emit_plan])
    if getattr(args, "execute_plan", None):
        forwarded.extend(["--execute-plan", args.execute_plan])
    if getattr(args, "record", None):
        forwarded.extend(["--record", args.record])
    if getattr(args, "report", None):
        forwarded.extend(["--report", args.report])
    if getattr(args, "no_color", False):
        forwarded.append("--no-color")
    if getattr(args, "plain", False):
        forwarded.append("--plain")
    if getattr(args, "script", None):
        forwarded.extend(["--script", args.script])
    if getattr(args, "list_actions", False):
        forwarded.append("--list-actions")
    if getattr(args, "format", "text") != "text":
        forwarded.extend(["--format", args.format])
    if getattr(args, "test_mode", False):
        forwarded.append("--test-mode")
    if getattr(args, "test_script", None):
        forwarded.extend(["--test-script", args.test_script])
    if getattr(args, "replay_transcript", None):
        forwarded.extend(["--replay-transcript", args.replay_transcript])
    return wizard_main(forwarded)


def register_cli(registry) -> None:
    registry.register_root_command(
        "wizard",
        _add_wizard_parser,
        command_help="Launch interactive Cogniflow setup wizard",
    )
    registry.register_command(
        "setup",
        "wizard",
        _add_wizard_parser,
        group_help="Cogniflow setup commands",
        command_help="Launch interactive Cogniflow setup wizard",
    )
    registry.register_command(
        "setup",
        "tui",
        _add_tui_parser,
        group_help="Cogniflow setup commands",
        command_help="Launch interactive Cogniflow setup TUI (alias for wizard --tui)",
    )
