"""Integration with cf_setup planner and installer."""

from __future__ import annotations

import asyncio
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Awaitable


@dataclass
class PlannedModule:
    """A planned module from the installer."""

    package_name: str
    path: str
    version: str | None
    editable: bool
    reason: str


@dataclass
class InstallPlanResult:
    """Result of planning an installation."""

    profile: str
    modules: list[PlannedModule]
    hooks: list[str]


def _resolve_repo_root() -> Path | None:
    try:
        from cf_service_contracts import ProviderKey, require_provider
        setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
        resolved = setup.resolve_repo_root()
        if resolved:
            return Path(resolved)
    except Exception:
        pass
    return None


class CfSetupIntegrator:
    """Bridge to cf_setup for planning and installing."""

    def __init__(self, repo_root: Path | None = None):
        self.repo_root = repo_root or _resolve_repo_root()

    def _find_repo_root(self) -> Path | None:
        return _resolve_repo_root()

    def plan_installation(
        self,
        profile: str = "full",
        manifest_path: Path | None = None,
        execution_mode: str = "auto",
    ) -> InstallPlanResult:
        """Plan an installation using cf_setup."""
        from cf_service_contracts import ProviderKey, require_provider

        try:
            setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
        except Exception as exc:
            raise RuntimeError(
                "Setup orchestration provider is not installed. "
                "Install cf-setup or use a distribution profile that includes cf-setup."
            ) from exc

        manifest_path_str = str(manifest_path) if manifest_path else setup.default_manifest_path()
        repo_root_str = str(self.repo_root) if self.repo_root else None

        plan_result = setup.plan_installation({
            "repo_root": repo_root_str,
            "manifest_path": manifest_path_str,
            "profile": profile,
            "execution_mode": execution_mode,
            "editable": [],
        })

        modules = [
            PlannedModule(
                package_name=item["package_name"],
                path=item["path"],
                version=item["local_version"] or item["pypi_version"],
                editable=item["editable"],
                reason=item["reason"],
            )
            for item in plan_result.get("ordered_modules", [])
        ]

        hooks = [hook["hook_id"] for hook in plan_result.get("hooks", [])]

        return InstallPlanResult(
            profile=profile,
            modules=modules,
            hooks=hooks,
        )

    def _get_manifest_path(self) -> Path | None:
        try:
            from cf_service_contracts import ProviderKey, require_provider
            setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
            return Path(setup.default_manifest_path())
        except Exception:
            return None


InstallerCallback = Callable[[str, float, str], None]


class CfSetupInstaller:
    """Executor for cf_setup installation with progress callbacks."""

    def __init__(self, repo_root: Path | None = None):
        self.repo_root = repo_root or _resolve_repo_root()
        self._cancelled = False

    def execute_install(
        self,
        profile: str = "full",
        python_exe: str | None = None,
        show_details: bool = True,
        progress_callback: Callable[[str, float, str], None] | None = None,
    ) -> bool:
        """Execute the installation with progress updates."""
        from cf_service_contracts import ProviderKey, require_provider

        try:
            setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
        except Exception as exc:
            raise RuntimeError(
                "Setup orchestration provider is not installed. "
                "Install cf-setup or use a distribution profile that includes cf-setup."
            ) from exc

        result = setup.execute_install({
            "profile": profile,
            "python_exe": python_exe,
            "execution_mode": "auto",
            "show_details": show_details,
            "dry_run": False,
        })
        return result.get("success", False)

    def cancel(self) -> None:
        """Cancel the ongoing installation."""
        self._cancelled = True


def run_installation_async(
    profile: str = "full",
    progress_callback: Callable[[str, float, str], None] | None = None,
) -> Awaitable[bool]:
    """Run installation asynchronously."""
    loop = asyncio.get_event_loop()
    return loop.run_in_executor(
        None,
        CfSetupInstaller().execute_install,
        profile,
        None,
        progress_callback,
    )


def plan_modules(profile: str) -> list[PlannedModule]:
    """Quick helper to plan modules."""
    return CfSetupIntegrator().plan_installation(profile).modules