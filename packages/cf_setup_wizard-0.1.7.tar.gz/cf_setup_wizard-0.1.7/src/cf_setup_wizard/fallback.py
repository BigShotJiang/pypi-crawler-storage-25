"""Non-interactive fallback handler when terminal is not available."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def is_interactive_terminal() -> bool:
    """Check if we're running in an interactive terminal."""
    if os.environ.get("NO_TTY", "").lower() in ("1", "true", "yes"):
        return False

    if not hasattr(sys.stdin, "isatty") or not sys.stdin.isatty():
        return False

    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False

    return True


def run_fallback_install(
    profile: str = "full",
    show_details: bool = True,
    python_exe: str | None = None,
) -> int:
    """Run cf_setup install in non-interactive mode using the orchestration contract."""
    try:
        from cf_service_contracts import ProviderKey, require_provider
        setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
        result = setup.execute_install({
            "profile": profile,
            "python_exe": python_exe,
            "show_details": show_details,
            "dry_run": False,
        })
        return 0 if result.get("success", False) else 1
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


def check_and_run_fallback(
    profile: str = "full",
    show_details: bool = True,
) -> int | None:
    """Check terminal and run fallback if needed. Returns None if TTY available."""
    if is_interactive_terminal():
        return None

    return run_fallback_install(profile, show_details)


NO_TTY_ENV = os.environ.get("NO_TTY", "").lower()
FORCE_TTY = os.environ.get("CF_FORCE_TTY", "").lower() in ("1", "true", "yes")


def should_use_wizard() -> bool:
    """Determine if we should use the wizard or fallback."""
    if FORCE_TTY:
        return True
    return is_interactive_terminal()


def handle_no_tty(profile: str = "full") -> int:
    """Handle non-interactive mode - run fallback or exit."""
    if not should_use_wizard():
        return run_fallback_install(profile, show_details=True)
    return 0
