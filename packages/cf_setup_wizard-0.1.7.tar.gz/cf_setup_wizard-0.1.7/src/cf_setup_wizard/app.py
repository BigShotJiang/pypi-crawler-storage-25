"""Interactive CogniFlow setup wizard."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from importlib import metadata
from pathlib import Path
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import tomllib

from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import ContentSwitcher, DataTable, ProgressBar, Static, Switch
from rich.text import Text

from cf_service_contracts import ProviderKey, require_provider

from .license_text import GPL_3_TEXT
from .styles import PALETTE, WELCOME_TEXT, build_app_css


DUCKDB_VERSION = "1.4.2"
NATIVE_ARCH = "x64-windows-static"
JAVA_VERSION = "21.0.10+7"
SETUP_TASK_ROWS = [
    ("task:build_web", "Task", "web build", "build"),
    ("task:pip_check", "Task", "pip check", "verify"),
    ("task:semantics_init", "Task", "semantics init", "initialize"),
    ("task:provider_registry", "Task", "provider registry", "refresh"),
    ("task:hook:ingest-installed-steps", "Task", "hook ingest steps", "run hook"),
    ("task:hook:prime-pipeline-editor-steps", "Task", "hook prewarm editor", "run hook"),
    ("task:run_demo_prepare", "Task", "demo prepare", "run demo"),
    ("task:run_demo_pipeline", "Task", "demo pipeline", "run demo"),
    ("task:run_demo_server", "Task", "demo opcua server", "run demo"),
    ("task:run_demo_invocation", "Task", "demo invocation", "run demo"),
    ("task:run_demo_validate", "Task", "demo validate", "run demo"),
]


@dataclass(frozen=True)
class PreviewRow:
    key: str
    category: str
    component: str
    current: str
    target: str
    planned_action: str
    note: str
    status_icon: str = "..."

    @property
    def compact_item(self) -> str:
        prefix = {
            "CogniFlow": "CF",
            "Prereq": "SYS",
            "Third-Party": "EXT",
            "Task": "JOB",
        }.get(self.category, self.category[:3].upper())
        return f"{prefix} {self.component}"

    @property
    def compact_prefix(self) -> str:
        return self.compact_item.split(" ", 1)[0]

    @property
    def compact_name(self) -> str:
        return self.compact_item.split(" ", 1)[1]


class HelpScreen(Screen):
    """Help screen showing keyboard shortcuts and status legend."""

    BINDINGS = [
        Binding("escape", "pop_screen", show=False),
        Binding("q", "pop_screen", show=False),
    ]

    def compose(self) -> ComposeResult:
        with Vertical(id="help-screen"):
            yield Static("Setup TUI Help", classes="section-title")
            yield Static("", id="help-shortcuts")
            yield Static("", id="help-legend")
            yield Static("Press Esc or Q to close this help.", id="help-close-hint")

    def on_mount(self) -> None:
        self.query_one("#help-shortcuts", Static).update(
            "\n".join([
                "Keyboard shortcuts:",
                "  Enter / I   Start install",
                "  D           Toggle RunDemo",
                "  S           Toggle ShowDetails",
                "  R           Refresh preview",
                "  H           Show this help",
                "  Esc / Q     Quit / close help",
            ])
        )
        self.query_one("#help-legend", Static).update(
            "\n".join([
                "Status legend:",
                "  ✔  done      completed",
                "  ✖  failed    failed",
                "  >  running   currently running",
                "  ~  batched   queued in batch",
                "  ... pending   waiting",
                "  -  skipped   skipped",
            ])
        )


class CogniflowWizardApp(App[None]):
    """Full-install neon setup wizard."""

    CSS = build_app_css()
    BINDINGS = [
        Binding("enter", "confirm", show=False),
        Binding("i", "start_install", show=False),
        Binding("d", "toggle_run_demo", show=False),
        Binding("s", "toggle_show_details", show=False),
        Binding("r", "refresh_preview", show=False),
        Binding("h", "show_help", show=False),
        Binding("q", "quit_app", show=False),
        Binding("escape", "quit_app", show=False),
        Binding("ctrl+c", "quit_app", show=False),
    ]

    def __init__(
        self,
        profile: str = "full",
        *,
        resume_install: bool = False,
        run_demo_default: bool = True,
        show_details_default: bool = True,
    ) -> None:
        super().__init__()
        self.profile = profile
        self.repo_root = self._resolve_repo_root()
        self.log_root = self.repo_root / ".logs" / "cf_setup_wizard"
        self.resume_install = resume_install
        self.run_demo = run_demo_default
        self.show_details = show_details_default
        self.current_screen = "install" if resume_install else "welcome"
        self.wizard_version = self._resolve_wizard_version()
        self.setup_version = self._resolve_cf_setup_version()
        self.welcome_index = 0
        self.welcome_complete = False
        self.cursor_visible = True
        self.preview_rows: list[PreviewRow] = []
        self.preview_ready = False
        self.preview_error: str | None = None
        self.install_percent = 0
        self.install_status = "Waiting for install start."
        self.install_phase_message = "Waiting for install start."
        self.install_started_at: float | None = None
        self.install_activity_frame = 0
        self.install_report_path: Path | None = None
        self.install_log_path: Path | None = None
        self.install_event_path: Path | None = None
        self.install_failed = False
        self.install_running = False
        self.install_item_states: dict[str, str] = {}
        self.install_item_details: dict[str, str] = {}
        self.install_item_order: dict[str, int] = {}
        self.install_event_counter = 0
        self.current_batch_packages: list[str] = []
        self.current_batch_label = ""
        self.last_failed_step: str | None = None
        self.last_failed_package: str | None = None
        self.done_message_base = ""
        self.done_close_seconds: int | None = None
        self.done_success = False
        self.checklist_states: dict[str, str] = {
            "bootstrap": "pending",
            "prereqs": "pending",
            "packages": "pending",
            "demo": "pending",
            "finish": "pending",
        }

    def compose(self) -> ComposeResult:
        initial_screen = "install-screen" if self.resume_install else "welcome-screen"
        with Vertical(id="root"):
            with Horizontal(id="header"):
                yield Static("CogniFlow Setup", id="header-title")
                yield Static("", id="header-meta")
            with ContentSwitcher(id="body", initial=initial_screen):
                with Vertical(id="welcome-screen"):
                    with Vertical(id="welcome-card"):
                        yield Static("COGNIFLOW // SETUP LINK ONLINE", id="welcome-intro")
                        yield Static("", id="welcome-text")
                        yield Static("", id="welcome-hint")
                with Vertical(id="license-screen"):
                    with Vertical(id="license-card"):
                        yield Static("GNU GPL 3.0", id="license-title")
                        with VerticalScroll(id="license-scroll"):
                            yield Static(GPL_3_TEXT, id="license-copy")
                        yield Static("Press Enter to accept the GPL 3.0 terms and continue.", id="license-hint")
                with Vertical(id="main-screen"):
                    with Vertical(id="main-card"):
                        with Vertical(id="main-controls"):
                            yield Static("Install Controls", classes="section-title")
                            yield Static("Full Install aligned with `cf_setup`.")
                            with Horizontal(classes="toggle-row"):
                                yield Static("RunDemo", classes="toggle-label")
                                yield Switch(value=True, id="toggle-run-demo")
                            with Horizontal(classes="toggle-row"):
                                yield Static("ShowDetails", classes="toggle-label")
                                yield Switch(value=True, id="toggle-show-details")
                            yield Static("Press `I` or `Enter` to start the install.", id="main-message")
                        with Vertical(id="preview-panel"):
                            yield Static("System And Install Preview", classes="section-title")
                            yield Static("Preparing package and prerequisite preview...", id="preview-meta")
                            with VerticalScroll(id="preview-table-shell"):
                                yield DataTable(id="preview-table", zebra_stripes=True, cursor_type="row")
                with Vertical(id="install-screen"):
                    with Vertical(id="install-layout"):
                        with Vertical(id="status-card"):
                            yield Static("Install Progress", classes="section-title")
                            with Horizontal(id="install-topline"):
                                yield Static(".  ", id="install-activity")
                                yield Static("Waiting for install start.", id="install-meta")
                                yield Static("00:00", id="install-timer")
                            with Horizontal(id="install-progress-row"):
                                yield ProgressBar(total=100, show_eta=False, show_percentage=False, id="overall-progress")
                            yield Static("", id="checklist")
                            yield Static("", id="install-overview")
                with Vertical(id="done-screen"):
                    with Vertical(id="done-card"):
                        yield Static("Install Complete", classes="section-title")
                        yield Static("", id="done-summary")
                        yield Static("", id="done-message")
                        yield Static("", id="done-paths")
            yield Static("", id="footer-text")

    def on_mount(self) -> None:
        self._configure_table(self.query_one("#preview-table", DataTable), include_status=False)
        self._set_screen(self.current_screen)
        if not self.resume_install:
            self._render_welcome()
        self._render_header()
        self.query_one("#toggle-run-demo", Switch).value = self.run_demo
        self.query_one("#toggle-show-details", Switch).value = self.show_details
        if not self.resume_install:
            self.set_interval(0.04, self._tick_welcome)
            self.set_interval(0.5, self._blink_cursor)
        self.set_interval(1.0, self._render_header)
        self.set_interval(0.12, self._pulse_glow)
        self.set_interval(1.0, self._tick_install_timer)
        self.set_interval(1.0, self._tick_done_countdown)
        if self.resume_install:
            self.call_after_refresh(self._resume_install_flow)

    def action_confirm(self) -> None:
        if self.current_screen == "welcome":
            if not self.welcome_complete:
                self.welcome_index = len(WELCOME_TEXT)
                self.welcome_complete = True
                self._render_welcome()
                return
            self._set_screen("license")
            self._render_welcome()
            return
        if self.current_screen == "license":
            self._set_screen("main")
            self.refresh_preview()
            return
        if self.current_screen == "main":
            self.start_install()
            return
        if self.current_screen == "done":
            self.exit()

    def action_start_install(self) -> None:
        if self.current_screen == "main":
            self.start_install()

    def action_toggle_run_demo(self) -> None:
        if self.current_screen == "main":
            self._set_run_demo(not self.run_demo)

    def action_toggle_show_details(self) -> None:
        if self.current_screen == "main":
            self._set_show_details(not self.show_details)

    def action_refresh_preview(self) -> None:
        if self.current_screen == "main":
            self.refresh_preview()

    def action_show_help(self) -> None:
        self.push_screen(HelpScreen())

    def action_quit_app(self) -> None:
        self.exit()

    @on(Switch.Changed, "#toggle-run-demo")
    def _on_run_demo_changed(self, event: Switch.Changed) -> None:
        self._set_run_demo(bool(event.value), from_switch=True)

    @on(Switch.Changed, "#toggle-show-details")
    def _on_show_details_changed(self, event: Switch.Changed) -> None:
        self._set_show_details(bool(event.value), from_switch=True)

    def _set_run_demo(self, value: bool, *, from_switch: bool = False) -> None:
        self.run_demo = value
        if not from_switch:
            self.query_one("#toggle-run-demo", Switch).value = value
        self._render_footer()
        self._render_main_message()

    def _set_show_details(self, value: bool, *, from_switch: bool = False) -> None:
        self.show_details = value
        if not from_switch:
            self.query_one("#toggle-show-details", Switch).value = value
        self._render_footer()
        self._render_main_message()

    def _set_screen(self, screen: str) -> None:
        self.current_screen = screen
        mapping = {
            "welcome": "welcome-screen",
            "license": "license-screen",
            "main": "main-screen",
            "install": "install-screen",
            "done": "done-screen",
        }
        self.query_one(ContentSwitcher).current = mapping[screen]
        if screen == "main":
            self.call_after_refresh(self.query_one("#preview-table", DataTable).focus)
        show_header = screen in {"main", "install", "done"}
        self.query_one("#header").display = show_header
        self._render_header()
        self._render_footer()
        self._render_main_message()

    def _resume_install_flow(self) -> None:
        try:
            self.preview_rows = self._build_preview_rows()
            self.preview_ready = True
            self._apply_preview_rows()
        except Exception as exc:
            self._apply_preview_error(str(exc))
            self.notify("Preview unavailable, continuing with install.", severity="warning")
        self.start_install()

    def _render_header(self) -> None:
        clock = datetime.now().strftime("%H:%M:%S")
        title = Text("CogniFlow Setup", style=f"bold {PALETTE.title}")
        title.append(" ")
        title.append(f"({self.wizard_version})", style=f"bold {PALETTE.accent}")
        self.query_one("#header-title", Static).update(title)
        self.query_one("#header-meta", Static).update(
            f"cf_setup {self.setup_version}   |   {clock}"
        )

    def _render_footer(self) -> None:
        text = {
            "welcome": "Enter continue   H help   Esc/Q quit",
            "license": "Enter accept GPL 3.0   H help   Esc/Q quit",
            "main": (
                f"I/Enter install   D RunDemo [{'on' if self.run_demo else 'off'}]   "
                f"S ShowDetails [{'on' if self.show_details else 'off'}]   R refresh   H help   Esc/Q quit"
            ),
            "install": "H help   Esc/Q quit",
            "done": self._done_footer_text(),
        }[self.current_screen]
        self.query_one("#footer-text", Static).update(text)

    def _done_footer_text(self) -> str:
        if self.done_success and self.done_close_seconds is not None:
            return f"Enter close   H help   Esc/Q quit   Auto close in {self.done_close_seconds}s"
        return "Enter close   H help   Esc/Q quit"

    def _tick_done_countdown(self) -> None:
        if self.current_screen != "done" or not self.done_success or self.done_close_seconds is None:
            return
        self.done_close_seconds -= 1
        if self.done_close_seconds <= 0:
            self.exit()
            return
        self._render_footer()
        self._render_done_message_suffix()

    def _render_done_message_suffix(self) -> None:
        if not self.done_success or self.done_close_seconds is None:
            return
        if not self.done_message_base:
            return
        self.query_one("#done-message", Static).update(
            f"{self.done_message_base}\n\nClosing in {self.done_close_seconds}s"
        )

    def _tick_welcome(self) -> None:
        if self.current_screen != "welcome" or self.welcome_complete:
            return
        self.welcome_index = min(self.welcome_index + 1, len(WELCOME_TEXT))
        if self.welcome_index >= len(WELCOME_TEXT):
            self.welcome_complete = True
        self._render_welcome()

    def _blink_cursor(self) -> None:
        self.cursor_visible = not self.cursor_visible
        if self.current_screen == "welcome":
            self._render_welcome()

    def _render_welcome(self) -> None:
        visible = WELCOME_TEXT[: self.welcome_index]
        cursor = f"[b {PALETTE.accent}]|[/]" if self.cursor_visible else " "
        if self.welcome_complete:
            text = visible + (cursor if self.cursor_visible else "")
            hint = "Press Enter to continue"
        else:
            text = visible + cursor
            hint = "Press Enter to skip the animation"
        self.query_one("#welcome-text", Static).update(text)
        self.query_one("#welcome-hint", Static).update(hint)

    def _pulse_glow(self) -> None:
        self._render_install_activity()

    def _tick_install_timer(self) -> None:
        if self.current_screen != "install" or self.install_started_at is None:
            return
        elapsed_seconds = max(int(time.monotonic() - self.install_started_at), 0)
        minutes, seconds = divmod(elapsed_seconds, 60)
        self.query_one("#install-timer", Static).update(f"{minutes:02d}:{seconds:02d}")

    def _render_install_activity(self) -> None:
        if self.current_screen != "install":
            return
        if not self.install_running:
            self.query_one("#install-activity", Static).update("   ")
            return
        frames = (".  ", ".. ", "...", " ..", "  .", "   ")
        frame = frames[self.install_activity_frame % len(frames)]
        self.install_activity_frame += 1
        self.query_one("#install-activity", Static).update(frame)

    def _render_main_message(self) -> None:
        self.query_one("#main-message", Static).update(
            "Ready to install. RunDemo is {demo}. ShowDetails is {details}. "
            "Press I or Enter to start, H for help, Esc/Q to quit."
            .format(
                demo="enabled" if self.run_demo else "disabled",
                details="enabled" if self.show_details else "disabled",
            )
        )

    def _configure_table(self, table: DataTable, *, include_status: bool) -> None:
        columns = ["Item", "Now", "Target", "Next"]
        if include_status:
            table.add_columns("State", *columns)
        else:
            table.add_columns(*columns)

    @work(thread=True)
    def refresh_preview(self) -> None:
        self.preview_ready = False
        self.preview_error = None
        self.call_from_thread(
            self.query_one("#preview-meta", Static).update,
            "Refreshing install preview...",
        )
        try:
            rows = self._build_preview_rows()
        except Exception as exc:
            self.preview_error = str(exc)
            self.call_from_thread(self._apply_preview_error, str(exc))
            return
        self.preview_rows = rows
        self.preview_ready = True
        self.call_from_thread(self._apply_preview_rows)

    def _apply_preview_error(self, message: str) -> None:
        self.query_one("#preview-meta", Static).update(f"[red]Preview failed: {message}[/]")
        table = self.query_one("#preview-table", DataTable)
        table.clear()

    def _apply_preview_rows(self) -> None:
        self.query_one("#preview-meta", Static).update(
            f"{len(self.preview_rows)} components planned for validation or installation."
        )
        self._fill_table(self.query_one("#preview-table", DataTable), self.preview_rows, include_status=False)
        if self.current_screen == "install":
            self._render_install_overview()

    def _fill_table(self, table: DataTable, rows: list[PreviewRow], *, include_status: bool) -> None:
        table.clear()
        for row in rows:
            values = [
                self._render_item_cell(row),
                self._compact_text(row.current, 16),
                self._compact_text(row.target, 16),
                self._render_action_cell(self._display_action_for_row(row)),
            ]
            if include_status:
                table.add_row(self._render_status_cell(self._status_icon_for_row(row.key)), *values, key=row.key)
            else:
                table.add_row(*values, key=row.key)

    def _compact_text(self, value: str, width: int) -> str:
        text = " ".join(value.split())
        if len(text) <= width:
            return text
        if width <= 1:
            return text[:width]
        return text[: width - 1] + "…"

    def _render_item_cell(self, row: PreviewRow) -> Text:
        prefix_style = {
            "CF": f"bold {PALETTE.accent}",
            "SYS": f"bold {PALETTE.warning}",
            "EXT": f"bold {PALETTE.pink}",
        }.get(row.compact_prefix, f"bold {PALETTE.title}")
        cell = Text()
        cell.append(f"{row.compact_prefix} ", style=prefix_style)
        cell.append(self._compact_text(row.compact_name, 24), style=PALETTE.text)
        return cell

    def _display_action_for_row(self, row: PreviewRow) -> str:
        if self.current_screen in {"install", "done"}:
            state = self.install_item_states.get(row.key, "pending")
            if state == "running":
                return self.install_item_details.get(row.key, "installing")
            if state == "batched":
                return self.install_item_details.get(row.key, "queued in batch")
            if state == "done":
                return self.install_item_details.get(row.key, "completed")
            if state == "failed":
                return self.install_item_details.get(row.key, "failed")
        return row.planned_action

    def _render_action_cell(self, action_text: str) -> Text:
        action = self._compact_text(action_text, 14)
        lowered = action_text.lower()
        if "install" in lowered and "verify" not in lowered and "reuse" not in lowered:
            style = f"bold {PALETTE.success}"
        elif "running" in lowered or "building" in lowered or "processing" in lowered:
            style = f"bold {PALETTE.warning}"
        elif "done" in lowered or "completed" in lowered or "installed" in lowered or "ready" in lowered:
            style = f"bold {PALETTE.success}"
        elif "verify" in lowered or "reuse" in lowered:
            style = f"bold {PALETTE.accent_soft}"
        elif "missing" in lowered or "fail" in lowered:
            style = f"bold {PALETTE.error}"
        else:
            style = f"bold {PALETTE.warning}"
        return Text(action, style=style)

    def _status_icon_for_row(self, row_key: str) -> str:
        state = self.install_item_states.get(row_key, "pending")
        return {
            "pending": "...",
            "running": ">",
            "batched": "~",
            "done": "✔",
            "failed": "✖",
            "skipped": "-",
        }.get(state, "...")

    def _render_status_cell(self, status_icon: str) -> Text:
        style = {
            "✔": f"bold {PALETTE.success}",
            "✖": f"bold {PALETTE.error}",
            ">": f"bold {PALETTE.warning}",
            "~": f"bold {PALETTE.accent}",
            "...": PALETTE.muted,
        }.get(status_icon, PALETTE.text)
        return Text(status_icon, style=style)

    def _build_preview_rows(self) -> list[PreviewRow]:
        self._ensure_preview_dependencies()
        self._ensure_service_contracts_import_path()

        try:
            setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
        except Exception as exc:
            raise RuntimeError(
                "Setup orchestration provider is not installed. "
                "Install cf-setup or use a distribution profile that includes cf-setup."
            ) from exc

        manifest_path = setup.default_manifest_path()
        plan_result = setup.plan_installation({
            "repo_root": str(self.repo_root),
            "manifest_path": manifest_path,
            "profile": self.profile,
            "execution_mode": "repo",
            "editable": [],
        })

        rows: list[PreviewRow] = []
        for item in plan_result.get("ordered_modules", []):
            current = self._installed_version(item["package_name"])
            target = item["local_version"] or item["pypi_version"] or "-"
            action = "re-install" if current != "-" else "install"
            note = item["source"]
            rows.append(
                PreviewRow(
                    key=f"module:{item['package_name']}",
                    category="CogniFlow",
                    component=item["package_name"],
                    current=current,
                    target=target,
                    planned_action=action,
                    note=note,
                )
            )

        diagnostics = setup.diagnose_prerequisites()
        prereq_names = ("python", "pip", "venv", "git", "cmake", "node", "npm", "msvc")
        for name in prereq_names:
            tool = diagnostics.get(name, {})
            available = tool.get("available", False)
            version = tool.get("version") or tool.get("detail") or "-"
            current = str(version) if available else "missing"
            action = "verify" if available else "missing prerequisite"
            rows.append(
                PreviewRow(
                    key=f"tool:{name}",
                    category="Prereq",
                    component=name,
                    current=current,
                    target="required",
                    planned_action=action,
                    note=str(tool.get("source") or tool.get("detail") or "PATH"),
                )
            )

        rows.extend(self._third_party_rows("6.0.0"))
        rows.extend(self._task_rows())
        return rows

    def _third_party_rows(self, fuseki_version: str) -> list[PreviewRow]:
        home = Path.home() / ".cogniflow"
        duckdb_dir = home / "cache" / "native" / "duckdb" / DUCKDB_VERSION / NATIVE_ARCH
        open62541_dir = home / "cache" / "native" / "open62541" / NATIVE_ARCH
        fuseki_dir = home / "tools" / "fuseki" / fuseki_version
        java_dir = home / "tools" / "java" / JAVA_VERSION
        java_current = self._command_first_line(["java", "-version"])

        return [
            PreviewRow(
                key="thirdparty:java",
                category="Third-Party",
                component="java",
                current=java_current or (JAVA_VERSION if java_dir.exists() else "missing"),
                target=JAVA_VERSION,
                planned_action="managed install" if not java_dir.exists() and not java_current else "verify / reuse",
                note=str(java_dir),
            ),
            PreviewRow(
                key="thirdparty:fuseki",
                category="Third-Party",
                component="fuseki",
                current=fuseki_version if fuseki_dir.exists() else "missing",
                target=fuseki_version,
                planned_action="managed install" if not fuseki_dir.exists() else "verify / reuse",
                note=str(fuseki_dir),
            ),
            PreviewRow(
                key="thirdparty:duckdb",
                category="Third-Party",
                component="duckdb native",
                current=DUCKDB_VERSION if duckdb_dir.exists() else "missing",
                target=f"{DUCKDB_VERSION} / {NATIVE_ARCH}",
                planned_action="managed install" if not duckdb_dir.exists() else "verify / reuse",
                note=str(duckdb_dir),
            ),
            PreviewRow(
                key="thirdparty:open62541",
                category="Third-Party",
                component="open62541",
                current=NATIVE_ARCH if open62541_dir.exists() else "missing",
                target=NATIVE_ARCH,
                planned_action="managed install" if not open62541_dir.exists() else "verify / reuse",
                note=str(open62541_dir),
            ),
        ]

    def _task_rows(self) -> list[PreviewRow]:
        rows = [
            PreviewRow(
                key=key,
                category=category,
                component=component,
                current="-",
                target="required",
                planned_action=action,
                note="setup task",
            )
            for key, category, component, action in SETUP_TASK_ROWS
        ]
        if not self.run_demo:
            return [row for row in rows if not row.key.startswith("task:run_demo_")]
        return rows

    def _installed_version(self, package_name: str) -> str:
        try:
            return metadata.version(package_name)
        except metadata.PackageNotFoundError:
            return "-"

    def _command_first_line(self, command: list[str]) -> str | None:
        try:
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=5,
                check=False,
            )
        except Exception:
            return None
        output = (completed.stdout or completed.stderr).strip().splitlines()
        return output[0] if output else None

    def _resolve_cf_setup_version(self) -> str:
        try:
            return metadata.version("cf-setup")
        except metadata.PackageNotFoundError:
            pyproject = self.repo_root / "sandcastle" / "cf_setup" / "pyproject.toml"
            if pyproject.exists():
                data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
                return str(data.get("project", {}).get("version", "local"))
            return "local"

    def _resolve_wizard_version(self) -> str:
        try:
            return metadata.version("cf-setup-wizard")
        except metadata.PackageNotFoundError:
            pyproject = self.repo_root / "sandcastle" / "cf_setup_wizard" / "pyproject.toml"
            if pyproject.exists():
                data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
                return str(data.get("project", {}).get("version", "local"))
            return "local"

    def _ensure_preview_dependencies(self) -> None:
        self._ensure_runtime_dependency("packaging", "packaging>=24")

    def _ensure_runtime_dependency(self, module_name: str, package_spec: str) -> None:
        probe = subprocess.run(
            [
                sys.executable,
                "-c",
                f"import importlib.util, sys; sys.exit(0 if importlib.util.find_spec({module_name!r}) else 1)",
            ],
            cwd=str(self.repo_root),
            capture_output=True,
            text=True,
            check=False,
        )
        if probe.returncode == 0:
            return
        subprocess.run(
            [sys.executable, "-m", "pip", "install", package_spec],
            cwd=str(self.repo_root),
            check=True,
        )

    def _ensure_service_contracts_import_path(self) -> None:
        candidates = [
            self.repo_root / "sandcastle" / "cf_service_contracts" / "src",
        ]
        for candidate in candidates:
            candidate_text = str(candidate)
            if candidate.exists() and candidate_text not in sys.path:
                sys.path.insert(0, candidate_text)

    def _resolve_repo_root(self) -> Path:
        try:
            self._ensure_service_contracts_import_path()
            setup = require_provider(ProviderKey.SETUP_ORCHESTRATION)
            resolved = setup.resolve_repo_root()
            if resolved:
                return Path(resolved).resolve()
        except Exception:
            pass
        return Path.cwd().resolve()

    def _allocate_install_paths(self) -> tuple[Path, Path, Path]:
        self.log_root.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        stem = f"full_install_{timestamp}"
        return (
            self.log_root / f"{stem}.json",
            self.log_root / f"{stem}.log",
            self.log_root / f"{stem}.events.jsonl",
        )

    def _cleanup_invalid_site_packages(self) -> list[str]:
        site_packages = self.repo_root / ".venv" / "Lib" / "site-packages"
        if not site_packages.exists():
            return []
        removed: list[str] = []
        for path in sorted(site_packages.iterdir()):
            if not path.name.startswith("~"):
                continue
            try:
                if path.is_dir():
                    shutil.rmtree(path)
                else:
                    path.unlink()
                removed.append(path.name)
            except Exception:
                continue
        return removed

    def _wait_for_cli_unlock(self, timeout_seconds: float = 15.0) -> None:
        cli_path = self.repo_root / ".venv" / "Scripts" / "cf.exe"
        if not cli_path.exists():
            return
        deadline = time.monotonic() + timeout_seconds
        last_error: Exception | None = None
        while time.monotonic() < deadline:
            try:
                with cli_path.open("rb"):
                    return
            except OSError as exc:
                last_error = exc
                time.sleep(0.25)
        if last_error is not None:
            raise RuntimeError(f"Timed out waiting for cf.exe to unlock: {last_error}")

    @work(thread=True)
    def start_install(self) -> None:
        if self.install_running:
            return
        if self._should_relaunch_for_install():
            self._relaunch_for_install()
            return
        self.install_running = True
        self.install_failed = False
        self.call_from_thread(self._prepare_install_view)
        try:
            self._wait_for_cli_unlock()
            (
                self.install_report_path,
                self.install_log_path,
                self.install_event_path,
            ) = self._allocate_install_paths()
            removed_entries = self._cleanup_invalid_site_packages()
            self.call_from_thread(self._announce_install_paths, removed_entries)
            command = self._build_install_command(
                self.install_report_path,
                self.install_log_path,
                self.install_event_path,
            )
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                cwd=str(self.repo_root),
            )
            event_thread = threading.Thread(
                target=self._tail_install_events,
                args=(process,),
                daemon=True,
            )
            event_thread.start()
            assert process.stdout is not None
            for line in process.stdout:
                self.call_from_thread(self._append_install_log, line.rstrip())
            process.wait()
            event_thread.join(timeout=2.0)
            report_payload = self._read_report_payload(self.install_report_path)
            self.call_from_thread(self._finish_install, int(process.returncode or 0), report_payload)
        except Exception as exc:
            self.call_from_thread(self._finish_install, 1, None, str(exc))
        finally:
            self.install_running = False

    def _build_install_command(self, report_path: Path, log_path: Path, event_path: Path) -> list[str]:
        bootstrap = self.repo_root / "sandcastle" / "cf_setup" / "src" / "cf_setup" / "bootstrap.py"
        python_exe = self.repo_root / ".venv" / "Scripts" / "python.exe"
        if not python_exe.exists():
            python_exe = Path(sys.executable)
        command = [
            str(python_exe),
            str(bootstrap),
            "install",
            "--profile",
            self.profile,
            "--duckdb-version",
            DUCKDB_VERSION,
            "--native-arch",
            NATIVE_ARCH,
            "--output",
            str(report_path),
            "--log-path",
            str(log_path),
            "--event-path",
            str(event_path),
        ]
        if self.show_details:
            command.append("--show-details")
        if not self.run_demo:
            command.append("--no-run-demo")
        return command

    def _should_relaunch_for_install(self) -> bool:
        return not self.resume_install

    def _relaunch_for_install(self) -> None:
        python_exe = self.repo_root / ".venv" / "Scripts" / "python.exe"
        if not python_exe.exists():
            python_exe = Path(sys.executable)
        env = dict(os.environ)
        entries = [
            str(self.repo_root / "sandcastle" / "cf_setup_wizard" / "src"),
            str(self.repo_root / "sandcastle" / "cf_setup" / "src"),
            str(self.repo_root / "sandcastle" / "cf_service_contracts" / "src"),
        ]
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = os.pathsep.join([*entries, existing] if existing else entries)
        command = [
            str(python_exe),
            "-m",
            "cf_setup_wizard.cli",
            "--profile",
            self.profile,
            "--resume-install",
            "--run-demo" if self.run_demo else "--no-run-demo",
            "--show-details" if self.show_details else "--no-show-details",
        ]
        subprocess.Popen(
            command,
            cwd=str(self.repo_root),
            env=env,
        )
        self.call_from_thread(self.notify, "Wizard relaunched via python to release cf.exe.")
        self.call_from_thread(self.exit)

    def _prepare_install_view(self) -> None:
        self.install_percent = 0
        self.install_status = "Launching cf_setup"
        self.install_phase_message = "Launching cf_setup"
        self.install_started_at = time.monotonic()
        self.install_activity_frame = 0
        self.done_success = False
        self.done_message_base = ""
        self.done_close_seconds = None
        self.current_batch_packages = []
        self.current_batch_label = ""
        self.last_failed_step = None
        self.last_failed_package = None
        self.install_item_states = {row.key: "pending" for row in self.preview_rows}
        self.install_item_details = {row.key: row.planned_action for row in self.preview_rows}
        self.install_item_order = {}
        self.install_event_counter = 0
        self.checklist_states = {
            "bootstrap": "running",
            "prereqs": "pending",
            "packages": "pending",
            "demo": "pending" if self.run_demo else "skipped",
            "finish": "pending",
        }
        self.query_one("#overall-progress", ProgressBar).update(progress=0)
        self.query_one("#install-timer", Static).update("00:00")
        self.query_one("#install-meta", Static).update(self.install_status)
        self._render_install_overview()
        self._render_checklist()
        self._render_install_activity()
        self._set_screen("install")

    def _announce_install_paths(self, removed_entries: list[str]) -> None:
        if removed_entries:
            self.install_status = (
                "Cleaned invalid site-packages entries: " + ", ".join(removed_entries)
            )
            self.query_one("#install-meta", Static).update(self.install_status)
        self._render_install_overview()

    def _append_install_log(self, line: str) -> None:
        return

    def _tail_install_events(self, process: subprocess.Popen[str]) -> None:
        path = self.install_event_path
        if path is None:
            return
        offset = 0
        buffered = ""
        while process.poll() is None or (path.exists() and path.stat().st_size > offset):
            if path.exists():
                with path.open("r", encoding="utf-8", errors="replace") as handle:
                    handle.seek(offset)
                    chunk = handle.read()
                    offset = handle.tell()
                if chunk:
                    buffered += chunk
                    lines = buffered.splitlines(keepends=True)
                    if lines and not lines[-1].endswith(("\n", "\r")):
                        buffered = lines.pop()
                    else:
                        buffered = ""
                    for raw_line in lines:
                        self._dispatch_install_event(raw_line)
            time.sleep(0.1)
        if buffered.strip():
            self._dispatch_install_event(buffered)

    def _dispatch_install_event(self, raw_line: str) -> None:
        try:
            payload = json.loads(raw_line)
        except json.JSONDecodeError:
            return
        if isinstance(payload, dict):
            self.call_from_thread(self._apply_install_event, payload)

    def _apply_install_event(self, event: dict[str, object]) -> None:
        event_type = str(event.get("type") or "")
        if event_type == "install_started":
            self._set_install_phase("bootstrap", "done", 18, "cf_setup started")
            self._set_install_phase("prereqs", "running", 28, "Resolving prerequisites")
            return
        if event_type == "install_finished":
            status = str(event.get("status") or "success")
            if status == "success":
                self._set_install_phase("finish", "running", 99, "Finalizing report")
            else:
                self.install_failed = True
            return
        if event_type == "batch_started":
            raw_packages = event.get("packages")
            package_names = [str(item) for item in raw_packages if isinstance(item, str)] if isinstance(raw_packages, list) else []
            if package_names:
                self._set_batch_state(package_names)
                self._set_install_phase("packages", "running", 78, self.current_batch_label)
            return
        if event_type == "batch_finished":
            if str(event.get("status") or "") == "failed":
                self.install_failed = True
                self.last_failed_step = str(event.get("step") or "pip_install_batch")
                self.query_one("#install-meta", Static).update("Package batch failed")
            self._clear_batch_state()
            return
        if event_type == "progress":
            detail = str(event.get("detail") or "")
            if detail:
                self._apply_progress_event(detail)
            return
        if event_type == "module_state_changed":
            package_name = str(event.get("package") or "")
            state = str(event.get("state") or "")
            if package_name and state == "installing":
                self._set_package_status(package_name, ">", f"Installing {package_name}")
            elif package_name and state == "in_batch":
                self._set_package_status(package_name, "~", f"Queued in batch for {package_name}")
            elif package_name and state == "installed":
                self._set_package_status(package_name, "✔", f"Completed {package_name}")
            elif package_name and state == "failed":
                self._set_package_status(package_name, "✖", f"Failed {package_name}")
                self.install_failed = True
                self.last_failed_package = package_name
            return
        if event_type in {"step_started", "step_finished"}:
            self._apply_step_event(event_type, event)

    def _apply_step_event(self, event_type: str, event: dict[str, object]) -> None:
        step = str(event.get("step") or "")
        status = str(event.get("status") or ("running" if event_type == "step_started" else ""))
        detail = str(event.get("detail") or step)

        if step == "native_deps":
            if event_type == "step_started":
                self._set_install_phase("prereqs", "running", 36, detail)
            elif status == "success":
                self._set_install_phase("prereqs", "done", 52, detail)
                self._set_install_phase("packages", "running", 62, detail)
            elif status == "skipped":
                self._set_install_phase("prereqs", "done", 52, detail)
            elif status == "failed":
                self.checklist_states["prereqs"] = "failed"
                self.install_failed = True
                self.last_failed_step = step
            return

        task_key = {
            "build_web": "task:build_web",
            "pip_check": "task:pip_check",
            "semantics_init": "task:semantics_init",
            "provider_registry": "task:provider_registry",
            "hook:ingest-installed-steps": "task:hook:ingest-installed-steps",
            "hook:prime-pipeline-editor-steps": "task:hook:prime-pipeline-editor-steps",
            "run_demo_prepare": "task:run_demo_prepare",
            "run_demo_pipeline": "task:run_demo_pipeline",
            "run_demo_server": "task:run_demo_server",
            "run_demo_invocation": "task:run_demo_invocation",
            "run_demo_validate": "task:run_demo_validate",
        }.get(step)
        if task_key is not None:
            if event_type == "step_started":
                self._set_row_state(task_key, "running", detail)
                self.query_one("#install-meta", Static).update(detail)
            elif status == "success":
                self._set_row_state(task_key, "done", "completed")
            elif status == "skipped":
                self._set_row_state(task_key, "skipped", "skipped")
            elif status == "failed":
                self._set_row_state(task_key, "failed", "failed")
                self.install_failed = True
                self.last_failed_step = step
            return

        if step.startswith("install:") and event_type == "step_finished":
            package_name = step.split(":", 1)[1]
            if status == "success":
                self._set_package_status(package_name, "✔", f"Completed {package_name}")
            elif status == "failed":
                self._set_package_status(package_name, "✖", f"Failed {package_name}")
                self.install_failed = True
                self.last_failed_step = step
                self.last_failed_package = package_name
            return

        if step.startswith("run_demo") and event_type == "step_finished" and status == "success":
            self._set_install_phase("demo", "done", 97, detail)

    def _apply_progress_event(self, detail: str) -> None:
        self.install_status = detail
        self.query_one("#install-meta", Static).update(detail)

        hook_match = re.search(r"Running post-install hook '([^']+)'", detail)
        if hook_match:
            task_key = {
                "ingest-installed-steps": "task:hook:ingest-installed-steps",
                "prime-pipeline-editor-steps": "task:hook:prime-pipeline-editor-steps",
            }.get(hook_match.group(1))
            if task_key is not None:
                self._set_row_state(task_key, "running", "running")
                self._set_install_phase("packages", "running", 86, detail)
            return

        demo_task_key = {
            "Preparing demo resources": "task:run_demo_prepare",
            "Preparing pipeline": "task:run_demo_pipeline",
            "Persisting pipeline revision": "task:run_demo_pipeline",
            "Preparing manager-backed pipeline state": "task:run_demo_pipeline",
            "Starting OPC UA server": "task:run_demo_server",
            "Running invocation": "task:run_demo_invocation",
            "Validating Data Hive output": "task:run_demo_validate",
        }.get(detail)
        if demo_task_key is not None:
            self._set_install_phase("packages", "done", 86, detail)
            self._set_install_phase("demo", "running", 92, detail)
            self._set_row_state(demo_task_key, "running", "running")
            return

        if detail == "Starting demo after installation":
            self._set_install_phase("packages", "done", 86, detail)
            self._set_install_phase("demo", "running", 92, detail)

    def _sync_table_with_log(self, line: str, lowered: str, normalized: str) -> None:
        return

    def _mark_row_group(self, categories: set[str], state: str, detail: str) -> None:
        changed = False
        for row in self.preview_rows:
            if row.category not in categories:
                continue
            if self.install_item_states.get(row.key) == "failed":
                continue
            if self.install_item_states.get(row.key) != state or self.install_item_details.get(row.key) != detail:
                self.install_item_states[row.key] = state
                self.install_item_details[row.key] = detail
                changed = True
        if changed:
            self._refresh_install_progress()

    def _set_package_status(self, package_name: str, status_icon: str, status_text: str) -> None:
        match_name = package_name.lower()
        changed = False
        for row in self.preview_rows:
            if row.category == "CogniFlow" and row.component.lower() == match_name:
                new_state = {
                    ">": "running",
                    "~": "batched",
                    "✔": "done",
                    "✖": "failed",
                    "...": "pending",
                }[status_icon]
                if self.install_item_states.get(row.key) != new_state or self.install_item_details.get(row.key) != status_text:
                    self.install_item_states[row.key] = new_state
                    self.install_item_details[row.key] = status_text
                    self.install_event_counter += 1
                    self.install_item_order[row.key] = self.install_event_counter
                    changed = True
        if changed:
            self._refresh_install_progress()

    def _row_by_key(self, row_key: str) -> PreviewRow:
        for row in self.preview_rows:
            if row.key == row_key:
                return row
        raise KeyError(row_key)

    def _set_row_state(self, row_key: str, state: str, detail: str) -> None:
        if row_key not in self.install_item_states:
            return
        if self.install_item_states.get(row_key) == state and self.install_item_details.get(row_key) == detail:
            return
        self.install_item_states[row_key] = state
        self.install_item_details[row_key] = detail
        self.install_event_counter += 1
        self.install_item_order[row_key] = self.install_event_counter
        self._refresh_install_progress()

    def _render_install_overview(self) -> None:
        counts = {
            "done": sum(1 for state in self.install_item_states.values() if state == "done"),
            "running": sum(1 for state in self.install_item_states.values() if state == "running"),
            "batched": sum(1 for state in self.install_item_states.values() if state == "batched"),
            "pending": sum(1 for state in self.install_item_states.values() if state == "pending"),
            "failed": sum(1 for state in self.install_item_states.values() if state == "failed"),
        }
        active = [row for row in self.preview_rows if self.install_item_states.get(row.key) == "running"]
        recent = sorted(
            [row for row in self.preview_rows if self.install_item_states.get(row.key) in {"done", "failed"}],
            key=lambda row: self.install_item_order.get(row.key, 0),
            reverse=True,
        )[:8]
        waiting = [row for row in self.preview_rows if self.install_item_states.get(row.key) == "pending"][:5]

        lines = ["Current"]
        if self.current_batch_packages:
            lines.append(f"- {self.current_batch_label}")
            preview = ", ".join(self.current_batch_packages[:5])
            suffix = "..." if len(self.current_batch_packages) > 5 else ""
            lines.append(f"- packages: {preview}{suffix}")
        elif active:
            lines.extend(self._overview_lines_for_rows(active[:5]))
        else:
            lines.append("- no active task")
        lines.extend(["", "Recent"])
        if recent:
            lines.extend(self._overview_lines_for_rows(recent))
        else:
            lines.append("- no completed task yet")
        lines.extend(["", "Next Up"])
        if waiting:
            lines.extend(self._overview_lines_for_rows(waiting))
        else:
            lines.append("- queue empty")
        lines.extend(["", "Diagnostics"])
        lines.append(
            (
                f"- done {counts['done']}   running {counts['running']}   "
                f"batch {counts['batched']}   pending {counts['pending']}   failed {counts['failed']}"
            )
        )
        if self.last_failed_step is not None:
            lines.append(f"- failed step: {self.last_failed_step}")
        if self.last_failed_package is not None:
            lines.append(f"- package: {self.last_failed_package}")
        lines.append(f"- report: {self.install_report_path or 'n/a'}")
        lines.append(f"- log: {self.install_log_path or 'n/a'}")
        lines.append(f"- events: {self.install_event_path or 'n/a'}")
        self.query_one("#install-overview", Static).update("\n".join(lines))

    def _overview_lines_for_rows(self, rows: list[PreviewRow]) -> list[str]:
        lines: list[str] = []
        for row in rows:
            state = self._status_icon_for_row(row.key)
            detail = self._compact_text(self.install_item_details.get(row.key, row.planned_action), 20)
            item = self._compact_text(row.compact_item, 28)
            lines.append(f"{state} {item:<30} {detail}")
        return lines

    def _set_batch_state(self, package_names: list[str]) -> None:
        preview = ", ".join(package_names[:4])
        suffix = "..." if len(package_names) > 4 else ""
        self.current_batch_packages = package_names
        self.current_batch_label = f"Installing batch ({len(package_names)}): {preview}{suffix}"
        for package_name in package_names:
            self._set_package_status(package_name, "~", f"Queued in batch for {package_name}")

    def _clear_batch_state(self) -> None:
        self.current_batch_packages = []
        self.current_batch_label = ""
        self._render_install_overview()

    def _refresh_install_progress(self) -> None:
        total = len(self.preview_rows)
        if total <= 0:
            return
        completed = sum(
            1 for row in self.preview_rows if self.install_item_states.get(row.key) in {"done", "skipped"}
        )
        failed = sum(1 for row in self.preview_rows if self.install_item_states.get(row.key) == "failed")
        percent = int(((completed + failed) / total) * 100)
        if self.install_running and percent >= 100:
            percent = 99
        self.install_percent = percent
        self.query_one("#overall-progress", ProgressBar).update(progress=percent)
        self._render_install_overview()

    def _set_install_phase(self, name: str, status: str, percent: int, message: str) -> None:
        current = self.checklist_states.get(name, "pending")
        if current == "done" and status in {"running", "pending"}:
            return
        self.checklist_states[name] = status
        self.install_phase_message = message
        self.install_status = message
        self.query_one("#install-meta", Static).update(message)
        self._render_checklist()

    def _render_checklist(self) -> None:
        markers = {
            "pending": "...",
            "running": ">>>",
            "done": "ok",
            "failed": "xx",
            "skipped": "--",
        }
        labels = {
            "bootstrap": "Bootstrap",
            "prereqs": "Prereqs",
            "packages": "Packages",
            "demo": "Demo",
            "finish": "Finish",
        }
        parts = [f"{labels[name]} {markers[self.checklist_states[name]]}" for name in labels]
        self.query_one("#checklist", Static).update("   |   ".join(parts))

    def _read_report_payload(self, path: Path | None) -> dict[str, object] | None:
        if path is None or not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def _finish_install(
        self,
        returncode: int,
        report_payload: dict[str, object] | None,
        start_error: str | None = None,
    ) -> None:
        self.install_started_at = None
        self.query_one("#install-activity", Static).update("   ")
        if start_error:
            self.checklist_states["finish"] = "failed"
            self.done_success = False
            self.done_close_seconds = None
            self.query_one("#done-summary", Static).update(f"[red]{start_error}[/]")
            self.done_message_base = "The install process could not be started."
            self.query_one("#done-message", Static).update(self.done_message_base)
            self.query_one("#done-paths", Static).update(self._format_log_paths())
            self._render_checklist()
            self._set_screen("done")
            return

        if returncode == 0:
            for key, value in list(self.checklist_states.items()):
                if value == "running":
                    self.checklist_states[key] = "done"
            for row in self.preview_rows:
                if self.install_item_states.get(row.key) not in {"done", "failed", "skipped"}:
                    self.install_item_states[row.key] = "done"
                    self.install_item_details[row.key] = "completed"
            if not self.run_demo:
                self.checklist_states["demo"] = "skipped"
            self.checklist_states["finish"] = "done"
            self.done_success = True
            self.done_close_seconds = 10
            self.install_percent = 100
            self.query_one("#overall-progress", ProgressBar).update(progress=100)
            self.query_one("#done-summary", Static).update("[green]CogniFlow full install completed successfully.[/]")
            self.done_message_base = self._done_message(report_payload, success=True)
            self.query_one("#done-message", Static).update(self.done_message_base)
            self.query_one("#done-paths", Static).update(self._format_log_paths())
            self._render_done_message_suffix()
        else:
            failing = next((name for name, value in self.checklist_states.items() if value == "running"), "finish")
            self.checklist_states[failing] = "failed"
            self.checklist_states["finish"] = "failed"
            self.done_success = False
            self.done_close_seconds = None
            self.query_one("#done-summary", Static).update("[red]CogniFlow full install failed.[/]")
            self.done_message_base = self._done_message(report_payload, success=False)
            self.query_one("#done-message", Static).update(self.done_message_base)
            self.query_one("#done-paths", Static).update(self._format_log_paths())

        self._render_checklist()
        self._apply_report_to_install_table(report_payload)
        self._set_screen("done")

    def _done_message(self, report_payload: dict[str, object] | None, *, success: bool) -> str:
        if not report_payload:
            return "No installation report was produced. Review the report, log, and event files."
        module_rows = report_payload.get("modules", [])
        if not isinstance(module_rows, list):
            return "Installation report produced an unexpected structure."
        installed = sum(1 for item in module_rows if isinstance(item, dict) and item.get("result") in {"installed", "re-installed"})
        reused = sum(1 for item in module_rows if isinstance(item, dict) and item.get("result") == "already installed")
        failed = sum(1 for item in module_rows if isinstance(item, dict) and item.get("result") == "failed")
        if success:
            return f"Installed/refreshed {installed} packages. Reused {reused} existing packages."
        return f"Completed {installed} package actions before failure. Failed packages in report: {failed}."

    def _format_log_paths(self) -> str:
        report = str(self.install_report_path) if self.install_report_path else "n/a"
        log = str(self.install_log_path) if self.install_log_path else "n/a"
        events = str(self.install_event_path) if self.install_event_path else "n/a"
        return f"Report\n{report}\n\nLog\n{log}\n\nEvents\n{events}"

    def _apply_report_to_install_table(self, report_payload: dict[str, object] | None) -> None:
        if not report_payload:
            return
        result_by_package: dict[str, str] = {}
        module_rows = report_payload.get("modules")
        if not isinstance(module_rows, list):
            return
        for item in module_rows:
            if isinstance(item, dict):
                result_by_package[str(item.get("package_name"))] = str(item.get("result") or "pending")

        for row in self.preview_rows:
            if row.category == "CogniFlow":
                result = result_by_package.get(row.component, "pending")
                if result in {"installed", "re-installed", "already installed"}:
                    self.install_item_states[row.key] = "done"
                    self.install_item_details[row.key] = result.replace("-", " ")
                    self.install_event_counter += 1
                    self.install_item_order[row.key] = self.install_event_counter
                elif result == "failed":
                    self.install_item_states[row.key] = "failed"
                    self.install_item_details[row.key] = "failed"
                    self.install_event_counter += 1
                    self.install_item_order[row.key] = self.install_event_counter
                elif result == "planned":
                    self.install_item_states[row.key] = "pending"
                    self.install_item_details[row.key] = row.planned_action
        self._render_install_overview()


def run_wizard(profile: str = "full") -> None:
    CogniflowWizardApp(profile).run()


if __name__ == "__main__":
    run_wizard()
