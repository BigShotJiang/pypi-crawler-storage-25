"""Confirm screen."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Button


class ConfirmScreen(Screen):
    """Confirm installation screen."""

    def compose(self) -> ComposeResult:
        yield Static("=== CONFIRM ===", id="title")
        yield Static("Ready to install Cogniflow packages.", id="message")
        yield Button("Install Now", id="install", variant="primary")
        yield Button("Back", id="back")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "install":
            self.app.push_screen("install")
        elif event.button.id == "back":
            self.app.pop_screen()