"""Complete screen."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Button


class CompleteScreen(Screen):
    """Complete screen."""

    def compose(self) -> ComposeResult:
        yield Static("=== COMPLETE ===", id="title")
        yield Static("Installation complete!", id="message")
        yield Static("Run 'cf install' anytime to reinstall", id="next-steps")
        yield Button("Close", id="close", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close":
            self.app.exit()