"""Install screen."""

import time
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Button


class InstallScreen(Screen):
    """Install progress screen."""

    def compose(self) -> ComposeResult:
        yield Static("=== INSTALLING ===", id="title")
        yield Static("Installing packages...", id="status")
        yield Static("[use cf install instead]", id="hint")

    def on_mount(self) -> None:
        self.app.push_screen("complete")


class CompleteScreen(Screen):
    """Complete screen."""

    def compose(self) -> ComposeResult:
        yield Static("=== COMPLETE ===", id="title")
        yield Static("Installation complete!", id="message")
        yield Button("Close", id="close", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close":
            self.app.exit()