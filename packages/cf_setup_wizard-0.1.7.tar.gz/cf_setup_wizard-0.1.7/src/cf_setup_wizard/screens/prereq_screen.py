"""Prerequisite check screen."""

import sys
import shutil
import subprocess
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Button


class PrereqScreen(Screen):
    """Screen for checking prerequisites."""

    def compose(self) -> ComposeResult:
        yield Static("=== SYSTEM CHECK ===", id="title")
        yield Static("Checking system tools...", id="status")
        yield Button("Continue", id="continue", variant="primary")
        yield Button("Back", id="back")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "continue":
            self.app.push_screen("profile")
        elif event.button.id == "back":
            self.app.pop_screen()