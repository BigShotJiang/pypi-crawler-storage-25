"""Profile selection screen."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Button


class ProfileScreen(Screen):
    """Screen for selecting installation profile."""

    def compose(self) -> ComposeResult:
        yield Static("=== SELECT PROFILE ===", id="title")
        yield Static("1. Core - Core packages (15)", id="core")
        yield Static("2. Steps - Pipeline steps (4)", id="steps")
        yield Static("3. Web - Web server (1)", id="web")
        yield Static("4. Full - All packages (20)", id="full")
        yield Static("(Full recommended)", id="hint")
        yield Button("Next ->", id="next", variant="primary")
        yield Button("Back", id="back")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "next":
            self.app.push_screen("confirm")
        elif event.button.id == "back":
            self.app.pop_screen()