"""Welcome screen."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Button


class WelcomeScreen(Screen):
    """The welcome screen."""

    def compose(self) -> ComposeResult:
        yield Static("COGNIFLOW", id="logo")
        yield Static("Setup Wizard", id="title")
        yield Button("Begin Setup", id="begin", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "begin":
            self.app.push_screen("prereq")