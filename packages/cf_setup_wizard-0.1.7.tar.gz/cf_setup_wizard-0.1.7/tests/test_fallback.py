from __future__ import annotations

import importlib
from pathlib import Path
import sys
import types

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

fallback = importlib.import_module("cf_setup_wizard.fallback")


def test_run_fallback_install_uses_provider_contract(monkeypatch) -> None:
    """Fallback install now delegates to the setup orchestration provider contract."""
    from cf_service_contracts import ProviderKey
    from unittest.mock import MagicMock, patch

    fake_provider = MagicMock()
    fake_provider.execute_install.return_value = {"success": True}

    def fake_require(key):
        if key == ProviderKey.SETUP_ORCHESTRATION:
            return fake_provider
        raise LookupError(key)

    with patch("cf_service_contracts.require_provider", side_effect=fake_require):
        result = fallback.run_fallback_install(profile="full", show_details=True, python_exe="python-custom")

    assert result == 0
    fake_provider.execute_install.assert_called_once()
    call_kwargs = fake_provider.execute_install.call_args[0][0]
    assert call_kwargs.get("profile") == "full"
    assert call_kwargs.get("python_exe") == "python-custom"
    assert call_kwargs.get("show_details") is True


def test_handle_no_tty_runs_fallback(monkeypatch) -> None:
    monkeypatch.setattr(fallback, "should_use_wizard", lambda: False)
    monkeypatch.setattr(fallback, "run_fallback_install", lambda profile, show_details=True: 23)

    assert fallback.handle_no_tty("core") == 23
