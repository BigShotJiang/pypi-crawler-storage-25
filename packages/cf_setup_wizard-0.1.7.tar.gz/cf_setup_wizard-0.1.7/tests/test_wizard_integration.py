from __future__ import annotations

import importlib
import os
from pathlib import Path
import subprocess
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

wizard_integration = importlib.import_module("cf_setup_wizard.wizard_integration")
cli = importlib.import_module("cf_setup_wizard.cli")


def _cf_script_path() -> Path:
    python_dir = Path(sys.executable).resolve().parent
    candidate_dirs = (
        python_dir,
        python_dir / "Scripts",
        python_dir.parent / "Scripts",
    )
    for scripts_dir in candidate_dirs:
        for candidate in ("cf.exe", "cf.cmd", "cf-script.py", "cf"):
            path = scripts_dir / candidate
            if path.is_file():
                return path
    raise FileNotFoundError(
        f"cf console script not found near interpreter {Path(sys.executable).resolve()}"
    )


def test_summary_for_repo_clean_dry_run() -> None:
    choices = wizard_integration.WizardChoices(
        clean_profile="repo-clean",
        dry_run=True,
    )
    summary = wizard_integration.build_summary(choices)
    assert "repo-clean" in summary
    assert "Dry-run" in summary
    assert "Equivalent command: cf setup clean --profile repo-clean --dry-run" in summary


def test_summary_for_workspace_clean_execution() -> None:
    choices = wizard_integration.WizardChoices(
        clean_profile="workspace-clean",
        dry_run=False,
    )
    summary = wizard_integration.build_summary(choices)
    assert "workspace-clean" in summary
    assert "Execute" in summary
    assert "WARNING: This is a destructive operation." in summary
    assert "Equivalent command: cf setup clean --profile workspace-clean" in summary


def test_summary_for_full_clean_dry_run() -> None:
    choices = wizard_integration.WizardChoices(
        clean_profile="full-clean",
        dry_run=True,
    )
    summary = wizard_integration.build_summary(choices)
    assert "full-clean" in summary
    assert "Dry-run" in summary
    assert "Equivalent command: cf setup clean --profile full-clean --dry-run" in summary


def test_summary_for_install() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="core",
        dry_run=False,
    )
    summary = wizard_integration.build_summary(choices)
    assert "core" in summary
    assert "Execute" in summary
    assert "Equivalent command: cf setup install --profile core" in summary


def test_equivalent_command_for_repo_clean_with_yes() -> None:
    choices = wizard_integration.WizardChoices(
        clean_profile="repo-clean",
        yes=True,
        dry_run=True,
    )
    cmd = wizard_integration.build_equivalent_command(choices)
    assert cmd == ["cf", "setup", "clean", "--profile", "repo-clean", "--dry-run", "--yes"]


def test_equivalent_command_for_install_dry_run() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="steps",
        dry_run=True,
    )
    cmd = wizard_integration.build_equivalent_command(choices)
    assert cmd == ["cf", "setup", "install", "--profile", "steps", "--dry-run"]


def test_run_wizard_clean_passes_correct_command(monkeypatch) -> None:
    calls: list[list[str]] = []

    class FakeResult:
        returncode = 0
        stdout = "dry-run output"
        stderr = ""

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return FakeResult()

    monkeypatch.setattr(subprocess, "run", fake_run)

    choices = wizard_integration.WizardChoices(
        clean_profile="repo-clean",
        dry_run=True,
    )
    result = wizard_integration.run_wizard_clean(choices)

    assert result == 0
    assert len(calls) == 1
    assert Path(calls[0][0]).name.lower().startswith("cf")
    assert calls[0][1:] == ["setup", "clean", "--profile", "repo-clean", "--dry-run"]


def test_run_wizard_clean_refusal_without_yes(monkeypatch) -> None:
    calls: list[list[str]] = []

    class FakeResult:
        returncode = 3
        stdout = "Refused: repo-clean requires --yes in non-interactive mode."
        stderr = ""

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return FakeResult()

    monkeypatch.setattr(subprocess, "run", fake_run)

    choices = wizard_integration.WizardChoices(
        clean_profile="repo-clean",
        yes=False,
    )
    result = wizard_integration.run_wizard_clean(choices)

    assert result == 3
    assert "--yes" not in calls[0]


def test_execute_wizard_choices_routes_to_clean(monkeypatch) -> None:
    choices = wizard_integration.WizardChoices(clean_profile="repo-clean", dry_run=True)
    clean_calls: list[wizard_integration.WizardChoices] = []

    def fake_run_wizard_clean_with_result(c):
        clean_calls.append(c)
        return {"exit_code": 0}

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)

    result = wizard_integration.execute_wizard_choices(choices)

    assert result == 0
    assert len(clean_calls) == 1
    assert clean_calls[0].clean_profile == "repo-clean"


def test_execute_wizard_choices_routes_to_install(monkeypatch) -> None:
    choices = wizard_integration.WizardChoices(install_profile="core")
    install_calls: list[wizard_integration.WizardChoices] = []

    def fake_run_wizard_install(c):
        install_calls.append(c)
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    result = wizard_integration.execute_wizard_choices(choices)

    assert result == 0
    assert len(install_calls) == 1
    assert install_calls[0].install_profile == "core"


def test_cli_main_routes_to_clean_when_clean_profile_given(monkeypatch) -> None:
    calls: list[tuple[wizard_integration.WizardChoices, dict]] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append((choices, {"record_path": record_path, "report_path": report_path}))
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    result = cli.main(["--clean-profile", "repo-clean", "--dry-run", "--yes"])

    assert result == 0
    assert len(calls) == 1
    assert calls[0][0].clean_profile == "repo-clean"
    assert calls[0][0].dry_run is True
    assert calls[0][0].yes is True


def test_cli_main_routes_to_classic_install_when_no_tui_without_clean_profile(monkeypatch) -> None:
    install_calls: list[tuple[str, bool]] = []

    def fake_run_classic_install(profile: str, *, dry_run: bool = False) -> int:
        install_calls.append((profile, dry_run))
        return 0

    monkeypatch.setattr(cli, "run_classic_install", fake_run_classic_install)

    result = cli.main(["--no-tui", "--profile", "steps"])

    assert result == 0
    assert install_calls == [("steps", False)]


def test_cli_main_routes_to_textual_app_without_clean_profile(monkeypatch) -> None:
    app_calls: list[tuple[str, bool, bool, bool]] = []

    def fake_run_textual_app(
        profile: str,
        *,
        resume_install: bool = False,
        run_demo: bool = True,
        show_details: bool = True,
    ) -> int:
        app_calls.append((profile, resume_install, run_demo, show_details))
        return 0

    monkeypatch.setattr(cli, "run_textual_app", fake_run_textual_app)

    result = cli.main(["--profile", "web", "--resume-install", "--no-run-demo"])

    assert result == 0
    assert app_calls == [("web", True, False, True)]


def test_wizard_help_surface_includes_clean_options() -> None:
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--help"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "--clean-profile" in combined
    assert "--dry-run" in combined
    assert "--yes" in combined
    assert "--summary" in combined


def test_wizard_repo_clean_dry_run_integration() -> None:
    """Integration test: run the real wizard CLI with repo-clean dry-run."""
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "repo-clean", "--dry-run", "--summary"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "Pre-Execution Summary" in combined
    assert "repo-clean" in combined
    assert "Dry-run" in combined


def test_wizard_workspace_clean_dry_run_integration() -> None:
    """Integration test: run the real wizard CLI with workspace-clean dry-run."""
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "workspace-clean", "--dry-run", "--summary"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "Pre-Execution Summary" in combined
    assert "workspace-clean" in combined
    assert "Dry-run" in combined


def test_wizard_full_clean_dry_run_integration() -> None:
    """Integration test: run the real wizard CLI with full-clean dry-run."""
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "full-clean", "--dry-run", "--summary"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "Pre-Execution Summary" in combined
    assert "full-clean" in combined
    assert "Dry-run" in combined


def test_emit_plan_creates_json_file(tmp_path: Path) -> None:
    plan_path = tmp_path / "plan.json"
    choices = wizard_integration.WizardChoices(
        install_profile="core",
        clean_profile="repo-clean",
        dry_run=True,
        yes=False,
    )
    wizard_integration.emit_plan(choices, str(plan_path))
    assert plan_path.exists()
    import json
    data = json.loads(plan_path.read_text(encoding="utf-8"))
    assert data["version"] == "1"
    assert data["choices"]["install_profile"] == "core"
    assert data["choices"]["clean_profile"] == "repo-clean"
    assert data["choices"]["dry_run"] is True
    assert data["choices"]["yes"] is False
    assert data["equivalent_command"] == ["cf", "setup", "clean", "--profile", "repo-clean", "--dry-run"]


def test_load_plan_reads_json_file(tmp_path: Path) -> None:
    plan_path = tmp_path / "plan.json"
    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "steps",
            "clean_profile": "workspace-clean",
            "dry_run": False,
            "yes": True,
            "run_demo": False,
        },
        "equivalent_command": ["cf", "setup", "clean", "--profile", "workspace-clean", "--yes"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    loaded = wizard_integration.load_plan(str(plan_path))
    assert loaded.install_profile == "steps"
    assert loaded.clean_profile == "workspace-clean"
    assert loaded.dry_run is False
    assert loaded.yes is True


def test_execute_plan_from_file_runs_clean(tmp_path: Path, monkeypatch) -> None:
    plan_path = tmp_path / "plan.json"
    calls: list[wizard_integration.WizardChoices] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append(choices)
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "full",
            "clean_profile": "repo-clean",
            "dry_run": True,
            "yes": False,
        },
        "equivalent_command": ["cf", "setup", "clean", "--profile", "repo-clean", "--dry-run"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    result = cli.main(["--execute-plan", str(plan_path)])
    assert result == 0
    assert len(calls) == 1
    assert calls[0].clean_profile == "repo-clean"
    assert calls[0].dry_run is True


def test_script_alias_for_execute_plan(tmp_path: Path, monkeypatch) -> None:
    plan_path = tmp_path / "answers.json"
    calls: list[wizard_integration.WizardChoices] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append(choices)
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "core",
            "clean_profile": "full-clean",
            "dry_run": False,
            "yes": True,
        },
        "equivalent_command": ["cf", "setup", "clean", "--profile", "full-clean", "--yes"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    result = cli.main(["--script", str(plan_path)])
    assert result == 0
    assert len(calls) == 1
    assert calls[0].clean_profile == "full-clean"
    assert calls[0].yes is True


def test_transcript_recorded_after_execution(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)

    choices = wizard_integration.WizardChoices(clean_profile="repo-clean", dry_run=True)
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 0
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert data["version"] == "1"
    assert data["choices"]["clean_profile"] == "repo-clean"
    assert data["exit_status"] == 0
    assert data["failure_classification"] is None
    assert any("cf setup clean" in action for action in data["executed_actions"])
    assert data["skipped_actions"] == []


def test_transcript_records_failure_classification_on_error(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 2}

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)

    choices = wizard_integration.WizardChoices(clean_profile="workspace-clean", dry_run=False, yes=True)
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 2
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text())
    assert data["exit_status"] == 2
    assert data["failure_classification"] == "Repository-internal blocker"
    assert data["executed_actions"] == []
    assert any("cf setup clean" in action for action in data["skipped_actions"])


def test_transcript_classifies_refusal_as_unsafe_operation(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 3}

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)

    choices = wizard_integration.WizardChoices(clean_profile="workspace-clean", dry_run=False, yes=False)
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 3
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text())
    assert data["exit_status"] == 3
    assert data["failure_classification"] == "Unsafe operation refused"
    assert data["executed_actions"] == []
    assert any("cf setup clean" in action for action in data["skipped_actions"])


def test_transcript_classifies_deletion_error_as_external_process_failure(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 1}

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)

    choices = wizard_integration.WizardChoices(clean_profile="repo-clean", dry_run=False, yes=True)
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 1
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text())
    assert data["exit_status"] == 1
    assert data["failure_classification"] == "External process failure"
    assert data["executed_actions"] == []
    assert any("cf setup clean" in action for action in data["skipped_actions"])


def test_transcript_includes_clean_result_on_success(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {
            "exit_code": 0,
            "profile": "repo-clean",
            "mode": "execute",
            "deleted_count": 1,
            "failure_classification": None,
        }

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)

    choices = wizard_integration.WizardChoices(clean_profile="repo-clean", dry_run=False, yes=True)
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 0
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert "clean_result" in data
    assert data["clean_result"]["profile"] == "repo-clean"
    assert data["clean_result"]["mode"] == "execute"
    assert data["clean_result"]["deleted_count"] == 1


def test_transcript_includes_clean_result_on_refusal(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {
            "exit_code": 3,
            "profile": "workspace-clean",
            "mode": "execute",
            "deleted_count": 0,
            "failure_classification": "Unsafe operation refused",
        }

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)

    choices = wizard_integration.WizardChoices(clean_profile="workspace-clean", dry_run=False, yes=False)
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 3
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert "clean_result" in data
    assert data["clean_result"]["profile"] == "workspace-clean"
    assert data["clean_result"]["failure_classification"] == "Unsafe operation refused"


def test_transcript_omits_clean_result_for_install(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_install(choices):
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    choices = wizard_integration.WizardChoices(install_profile="core")
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 0
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert "clean_result" not in data


def test_plain_mode_routes_to_non_interactive_clean(monkeypatch) -> None:
    calls: list[tuple[wizard_integration.WizardChoices, dict]] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append((choices, {"record_path": record_path, "report_path": report_path}))
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    result = cli.main(["--plain", "--clean-profile", "repo-clean", "--dry-run"])
    assert result == 0
    assert len(calls) == 1
    assert calls[0][0].clean_profile == "repo-clean"
    assert calls[0][0].dry_run is True


def test_no_color_mode_routes_to_non_interactive_clean(monkeypatch) -> None:
    calls: list[tuple[wizard_integration.WizardChoices, dict]] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append((choices, {"record_path": record_path, "report_path": report_path}))
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    result = cli.main(["--no-color", "--clean-profile", "workspace-clean", "--dry-run", "--yes"])
    assert result == 0
    assert len(calls) == 1
    assert calls[0][0].clean_profile == "workspace-clean"
    assert calls[0][0].yes is True


def test_plain_mode_routes_to_classic_install_without_clean_profile(monkeypatch) -> None:
    install_calls: list[tuple[str, bool]] = []

    def fake_run_classic_install(profile: str, *, dry_run: bool = False) -> int:
        install_calls.append((profile, dry_run))
        return 0

    monkeypatch.setattr(cli, "run_classic_install", fake_run_classic_install)

    result = cli.main(["--plain", "--profile", "steps"])

    assert result == 0
    assert install_calls == [("steps", False)]


def test_wizard_help_surface_includes_automation_options() -> None:
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--help"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "--emit-plan" in combined
    assert "--execute-plan" in combined
    assert "--record" in combined
    assert "--no-color" in combined
    assert "--plain" in combined
    assert "--script" in combined


def test_plan_execution_dry_run_does_not_mutate(tmp_path: Path, monkeypatch) -> None:
    """Dry-run plan execution must not delete files."""
    plan_path = tmp_path / "plan.json"
    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "core",
            "clean_profile": "repo-clean",
            "dry_run": True,
            "yes": False,
        },
        "equivalent_command": ["cf", "setup", "clean", "--profile", "repo-clean", "--dry-run"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")

    subprocess_calls: list[list[str]] = []

    class FakeResult:
        returncode = 0
        stdout = "dry-run output"
        stderr = ""

    def fake_run(cmd, **kwargs):
        subprocess_calls.append(cmd)
        return FakeResult()

    monkeypatch.setattr(subprocess, "run", fake_run)

    result = cli.main(["--execute-plan", str(plan_path)])
    assert result == 0
    assert any("--dry-run" in arg for arg in subprocess_calls[0])


def test_plan_execution_preserves_confirmation_for_destructive_cleanup(tmp_path: Path, monkeypatch) -> None:
    """Plan execution without --yes must not include --yes in the delegated command."""
    plan_path = tmp_path / "plan.json"
    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "core",
            "clean_profile": "workspace-clean",
            "dry_run": False,
            "yes": False,
        },
        "equivalent_command": ["cf", "setup", "clean", "--profile", "workspace-clean"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")

    subprocess_calls: list[list[str]] = []

    class FakeResult:
        returncode = 3
        stdout = "Refused"
        stderr = ""

    def fake_run(cmd, **kwargs):
        subprocess_calls.append(cmd)
        return FakeResult()

    monkeypatch.setattr(subprocess, "run", fake_run)

    result = cli.main(["--execute-plan", str(plan_path)])
    assert result == 3
    assert "--yes" not in subprocess_calls[0]


def test_tui_alias_help_surface() -> None:
    """Integration test: cf setup tui --help shows the TUI alias help."""
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "tui", "--help"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "--profile" in combined
    assert "--clean-profile" in combined
    assert "--dry-run" in combined
    assert "--emit-plan" in combined


def test_tui_alias_routes_to_wizard_main(monkeypatch) -> None:
    """The cf setup tui alias must delegate to the same wizard main with --tui."""
    calls: list[list[str]] = []

    def fake_wizard_main(argv):
        calls.append(argv)
        return 0

    monkeypatch.setattr(cli, "main", fake_wizard_main)

    from cf_setup_wizard.cli_registration import _run_tui
    import argparse
    args = argparse.Namespace(
        profile="steps",
        clean_profile=None,
        dry_run=False,
        yes=False,
        summary=False,
        emit_plan=None,
        execute_plan=None,
        record=None,
        no_color=False,
        plain=False,
        script=None,
    )
    result = _run_tui(args)
    assert result == 0
    assert calls == [["--profile", "steps", "--tui"]]


def test_wizard_help_includes_tui_flag() -> None:
    """Integration test: cf setup wizard --help documents the --tui flag."""
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--help"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "--tui" in combined


def test_wizard_install_dry_run_integration() -> None:
    """Integration test: run the real wizard CLI with install dry-run."""
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--plain", "--profile", "core", "--dry-run"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "Package summary" in combined
    assert "planned" in combined


def test_wizard_plain_install_dry_run_integration() -> None:
    """Integration test: plain mode install dry-run produces deterministic output."""
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--plain", "--profile", "steps", "--dry-run"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert "Package summary" in combined
    assert "planned" in combined


def test_wizard_repo_clean_execution_accepted(tmp_path: Path) -> None:
    """Integration test: repo-clean execution with --yes removes allowed targets."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    build = repo / "build"
    build.mkdir()
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "repo-clean", "--yes", "--summary"],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(repo),
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert not build.exists()
    assert "repo-clean" in combined


def test_wizard_repo_clean_execution_refused(tmp_path: Path) -> None:
    """Integration test: repo-clean execution without --yes is refused."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    build = repo / "build"
    build.mkdir()
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "repo-clean", "--summary"],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(repo),
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 3, combined
    assert build.exists()
    assert "Interactive or required" in combined or "requires --yes" in combined


def test_wizard_workspace_clean_execution_accepted(tmp_path: Path) -> None:
    """Integration test: workspace-clean execution with --yes removes workspace."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    env = os.environ.copy()
    env["COGNIFLOW_HOME"] = str(workspace)
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "workspace-clean", "--yes", "--summary"],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(repo),
        env=env,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert not workspace.exists()


def test_wizard_workspace_clean_execution_refused(tmp_path: Path) -> None:
    """Integration test: workspace-clean execution without --yes is refused."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    env = os.environ.copy()
    env["COGNIFLOW_HOME"] = str(workspace)
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "workspace-clean", "--summary"],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(repo),
        env=env,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 3, combined
    assert workspace.exists()
    assert "Interactive or required" in combined or "requires --yes" in combined


def test_wizard_full_clean_refused_without_yes(tmp_path: Path) -> None:
    """Integration test: full-clean execution without --yes is refused."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    build = repo / "build"
    build.mkdir()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    env = os.environ.copy()
    env["COGNIFLOW_HOME"] = str(workspace)
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "full-clean", "--summary"],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(repo),
        env=env,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 3, combined
    assert build.exists()
    assert workspace.exists()
    assert "Interactive or required" in combined or "requires --yes" in combined


def test_wizard_transcript_records_success(tmp_path: Path) -> None:
    """Integration test: transcript records success for a clean dry-run."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    build = repo / "build"
    build.mkdir()
    transcript_path = tmp_path / "transcript.json"
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "repo-clean", "--dry-run", "--record", str(transcript_path), "--summary"],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(repo),
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert data["exit_status"] == 0
    assert data["failure_classification"] is None
    assert data["choices"]["clean_profile"] == "repo-clean"
    assert data["choices"]["dry_run"] is True
    assert any("cf setup clean" in action for action in data["executed_actions"])
    assert data["skipped_actions"] == []


def test_wizard_transcript_records_refusal(tmp_path: Path) -> None:
    """Integration test: transcript records refusal when confirmation is missing."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    env = os.environ.copy()
    env["COGNIFLOW_HOME"] = str(workspace)
    transcript_path = tmp_path / "transcript.json"
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "workspace-clean", "--record", str(transcript_path), "--summary"],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(repo),
        env=env,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 3, combined
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert data["exit_status"] == 3
    assert data["failure_classification"] == "Unsafe operation refused"
    assert data["choices"]["clean_profile"] == "workspace-clean"
    assert data["choices"]["yes"] is False
    assert data["executed_actions"] == []
    assert any("cf setup clean" in action for action in data["skipped_actions"])


def test_wizard_full_clean_transcript_success(tmp_path: Path) -> None:
    """Integration test: transcript records success for full-clean dry-run."""
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    build = repo / "build"
    build.mkdir()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    env = os.environ.copy()
    env["COGNIFLOW_HOME"] = str(workspace)
    transcript_path = tmp_path / "transcript.json"
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--clean-profile", "full-clean", "--dry-run", "--record", str(transcript_path), "--summary"],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(repo),
        env=env,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert data["exit_status"] == 0
    assert data["failure_classification"] is None
    assert data["choices"]["clean_profile"] == "full-clean"
    assert data["choices"]["dry_run"] is True
    assert any("cf setup clean" in action for action in data["executed_actions"])
    assert data["skipped_actions"] == []


def test_plan_emission_install_equivalent_command(tmp_path: Path) -> None:
    """Integration test: plan emission includes correct install equivalent command."""
    plan_path = tmp_path / "plan.json"
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--emit-plan", str(plan_path), "--profile", "steps", "--dry-run"],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert plan_path.exists()
    import json
    data = json.loads(plan_path.read_text(encoding="utf-8"))
    assert data["choices"]["install_profile"] == "steps"
    assert data["choices"]["dry_run"] is True
    assert data["equivalent_command"][:5] == ["cf", "setup", "install", "--profile", "steps"]
    assert "--dry-run" in data["equivalent_command"]


def test_execute_plan_install_dry_run(tmp_path: Path) -> None:
    """Integration test: execute an install plan with dry-run."""
    plan_path = tmp_path / "plan.json"
    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "core",
            "clean_profile": None,
            "dry_run": True,
            "yes": False,
        },
        "equivalent_command": ["cf", "setup", "install", "--profile", "core", "--dry-run"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    transcript_path = tmp_path / "transcript.json"
    result = subprocess.run(
        [str(_cf_script_path()), "setup", "wizard", "--execute-plan", str(plan_path), "--record", str(transcript_path)],
        check=False,
        capture_output=True,
        text=True,
    )
    combined = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined
    assert transcript_path.exists()
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert data["exit_status"] == 0
    assert data["failure_classification"] is None
    assert data["choices"]["install_profile"] == "core"
    assert data["choices"]["dry_run"] is True
    assert any("cf setup install" in action for action in data["executed_actions"])
    assert data["skipped_actions"] == []


def test_summary_for_fresh_install() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
    )
    summary = wizard_integration.build_summary(choices)
    assert "Fresh install mode: clean then install" in summary
    assert "full-clean" in summary
    assert "full" in summary
    assert "Equivalent command: cf setup wizard --fresh-install --profile full --clean-profile full-clean --yes" in summary


def test_equivalent_command_for_fresh_install() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="steps",
        clean_profile="repo-clean",
        dry_run=True,
        yes=False,
        fresh_install=True,
    )
    cmd = wizard_integration.build_equivalent_command(choices)
    assert cmd == ["cf", "setup", "wizard", "--fresh-install", "--profile", "steps", "--clean-profile", "repo-clean", "--dry-run"]


def test_clean_command_for_fresh_install_is_not_wizard() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="steps",
        clean_profile="repo-clean",
        dry_run=True,
        yes=False,
        fresh_install=True,
    )
    cmd = wizard_integration.build_clean_command(choices)
    assert cmd == ["cf", "setup", "clean", "--profile", "repo-clean", "--dry-run"]
    assert "wizard" not in cmd
    assert "--fresh-install" not in cmd


def test_clean_command_for_fresh_install_preserves_yes() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
    )
    cmd = wizard_integration.build_clean_command(choices)
    assert cmd == ["cf", "setup", "clean", "--profile", "full-clean", "--yes"]


def test_run_wizard_clean_with_result_uses_clean_command_in_fresh_install(monkeypatch) -> None:
    calls: list[list[str]] = []

    class FakeResult:
        returncode = 0
        stdout = "{}"
        stderr = ""

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return FakeResult()

    monkeypatch.setattr(subprocess, "run", fake_run)

    choices = wizard_integration.WizardChoices(
        install_profile="core",
        clean_profile="repo-clean",
        dry_run=True,
        fresh_install=True,
    )
    result = wizard_integration.run_wizard_clean_with_result(choices)

    assert result["exit_code"] == 0
    assert len(calls) == 1
    assert Path(calls[0][0]).name.lower().startswith("cf")
    assert calls[0][1:] == ["setup", "clean", "--profile", "repo-clean", "--dry-run", "--format", "json"]


def test_run_wizard_clean_uses_clean_command_in_fresh_install(monkeypatch) -> None:
    calls: list[list[str]] = []

    class FakeResult:
        returncode = 0
        stdout = "clean output"
        stderr = ""

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return FakeResult()

    monkeypatch.setattr(subprocess, "run", fake_run)

    choices = wizard_integration.WizardChoices(
        install_profile="core",
        clean_profile="repo-clean",
        dry_run=True,
        fresh_install=True,
    )
    result = wizard_integration.run_wizard_clean(choices)

    assert result == 0
    assert len(calls) == 1
    assert Path(calls[0][0]).name.lower().startswith("cf")
    assert calls[0][1:] == ["setup", "clean", "--profile", "repo-clean", "--dry-run"]


def test_execute_wizard_choices_fresh_install_delegates_clean_to_setup_clean(monkeypatch) -> None:
    """Fresh-install execution must invoke ``cf setup clean`` for the clean step,
    not recursively invoke ``cf setup wizard --fresh-install``.
    """
    choices = wizard_integration.WizardChoices(
        install_profile="core",
        clean_profile="repo-clean",
        dry_run=True,
        fresh_install=True,
    )
    subprocess_calls: list[list[str]] = []
    install_calls: list[wizard_integration.WizardChoices] = []

    class FakeResult:
        returncode = 0
        stdout = "{}"
        stderr = ""

    def fake_run(cmd, **kwargs):
        subprocess_calls.append(cmd)
        return FakeResult()

    def fake_run_wizard_install(c):
        install_calls.append(c)
        return 0

    monkeypatch.setattr(subprocess, "run", fake_run)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    result = wizard_integration.execute_wizard_choices(choices)

    assert result == 0
    # Clean step must use cf setup clean, not cf setup wizard --fresh-install
    assert any(Path(cmd[0]).name.lower().startswith("cf") and cmd[1:4] == ["setup", "clean", "--profile"] for cmd in subprocess_calls)
    assert not any("--fresh-install" in arg for cmd in subprocess_calls for arg in cmd)
    assert len(install_calls) == 1


def test_execute_wizard_choices_fresh_install_runs_clean_then_install(monkeypatch) -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="core",
        clean_profile="repo-clean",
        dry_run=True,
        fresh_install=True,
    )
    clean_calls: list[wizard_integration.WizardChoices] = []
    install_calls: list[wizard_integration.WizardChoices] = []

    def fake_run_wizard_clean_with_result(c):
        clean_calls.append(c)
        return {"exit_code": 0}

    def fake_run_wizard_install(c):
        install_calls.append(c)
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    result = wizard_integration.execute_wizard_choices(choices)

    assert result == 0
    assert len(clean_calls) == 1
    assert len(install_calls) == 1
    assert clean_calls[0].clean_profile == "repo-clean"
    assert install_calls[0].install_profile == "core"


def test_execute_wizard_choices_fresh_install_skips_install_when_clean_fails(monkeypatch) -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="core",
        clean_profile="repo-clean",
        dry_run=True,
        fresh_install=True,
    )
    install_calls: list[wizard_integration.WizardChoices] = []

    def fake_run_wizard_clean_with_result(c):
        return {"exit_code": 3}

    def fake_run_wizard_install(c):
        install_calls.append(c)
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    result = wizard_integration.execute_wizard_choices(choices)

    assert result == 3
    assert len(install_calls) == 0


def test_fresh_install_transcript_records_wizard_invocation(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    def fake_run_wizard_install(choices):
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
    )
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 0
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert data["version"] == "1"
    assert data["choices"]["fresh_install"] is True
    assert data["wizard_invocation"] == "cf setup wizard --fresh-install --clean-profile full-clean --profile full --yes"
    assert any("--fresh-install" in part for part in data["equivalent_command"])
    assert any("cf setup install" in action for action in data["executed_actions"])
    assert data["skipped_actions"] == []


def test_fresh_install_transcript_records_failure_when_install_fails(tmp_path: Path, monkeypatch) -> None:
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    def fake_run_wizard_install(choices):
        return 1

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    choices = wizard_integration.WizardChoices(
        install_profile="steps",
        clean_profile="repo-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
    )
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 1
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert data["exit_status"] == 1
    assert data["failure_classification"] == "Repository-internal blocker"
    # Transcript must record the actual delegated clean command, not the public wizard invocation.
    assert any("cf setup clean" in action for action in data["executed_actions"])
    assert any("cf setup install" in action for action in data["skipped_actions"])


def test_cli_main_routes_to_fresh_install_when_fresh_install_and_clean_profile_given(monkeypatch) -> None:
    calls: list[tuple[wizard_integration.WizardChoices, dict]] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append((choices, {"record_path": record_path, "report_path": report_path}))
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    result = cli.main(["--fresh-install", "--clean-profile", "repo-clean", "--dry-run", "--yes"])

    assert result == 0
    assert len(calls) == 1
    assert calls[0][0].fresh_install is True
    assert calls[0][0].clean_profile == "repo-clean"
    assert calls[0][0].dry_run is True
    assert calls[0][0].yes is True


def test_plan_loads_fresh_install_flag(tmp_path: Path) -> None:
    plan_path = tmp_path / "plan.json"
    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "full",
            "clean_profile": "full-clean",
            "dry_run": False,
            "yes": True,
            "fresh_install": True,
        },
        "equivalent_command": ["cf", "setup", "wizard", "--fresh-install", "--profile", "full", "--clean-profile", "full-clean", "--yes"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    loaded = wizard_integration.load_plan(str(plan_path))
    assert loaded.fresh_install is True
    assert loaded.clean_profile == "full-clean"


def test_emit_plan_includes_fresh_install(tmp_path: Path) -> None:
    plan_path = tmp_path / "plan.json"
    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
    )
    wizard_integration.emit_plan(choices, str(plan_path))
    assert plan_path.exists()
    import json
    data = json.loads(plan_path.read_text(encoding="utf-8"))
    assert data["choices"]["fresh_install"] is True
    assert "--fresh-install" in data["equivalent_command"]


def test_fresh_install_transcript_records_actual_delegated_commands(tmp_path: Path, monkeypatch) -> None:
    """Fresh-install transcript must record actual delegated clean and install commands,
    not the public wizard invocation, as the executed/skipped actions."""
    transcript_path = tmp_path / "transcript.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    def fake_run_wizard_install(choices):
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
    )
    result = wizard_integration.execute_wizard_choices(choices, record_path=str(transcript_path))
    assert result == 0
    assert transcript_path.exists()
    import json
    data = json.loads(transcript_path.read_text(encoding="utf-8"))
    assert data["exit_status"] == 0
    # executed_actions must contain actual delegated commands, not the public wizard invocation.
    assert any("cf setup clean" in action for action in data["executed_actions"])
    assert any("cf setup install" in action for action in data["executed_actions"])
    assert not any("cf setup wizard --fresh-install" in action for action in data["executed_actions"])
    assert data["skipped_actions"] == []


def test_fresh_install_report_generation(tmp_path: Path, monkeypatch) -> None:
    """Fresh-install execution with --report must produce a structured gate report."""
    transcript_path = tmp_path / "transcript.json"
    report_path = tmp_path / "report.json"

    def fake_run_wizard_clean_with_result(choices):
        return {
            "exit_code": 0,
            "profile": "full-clean",
            "mode": "execute",
            "phases": {
                "repo_clean": {
                    "repository_root": str(tmp_path / "repo"),
                    "targets": [],
                    "target_count": 0,
                    "deleted_count": 0,
                    "warnings": [],
                    "failure_classification": None,
                },
                "workspace_clean": {
                    "workspace_path": str(tmp_path / ".cogniflow"),
                    "path_exists": False,
                    "top_level_count": 0,
                    "deleted_count": 0,
                    "warnings": [],
                    "failure_classification": None,
                },
            },
            "overall_failure_classification": None,
        }

    def fake_run_wizard_install(choices):
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
        run_demo=False,
    )
    result = wizard_integration.execute_wizard_choices(
        choices, record_path=str(transcript_path), report_path=str(report_path)
    )
    assert result == 0
    assert report_path.exists()
    import json
    data = json.loads(report_path.read_text(encoding="utf-8"))
    assert data["version"] == "1"
    assert data["choices"]["fresh_install"] is True
    assert data["choices"]["run_demo"] is False
    assert data["exit_status"] == 0
    assert data["failure_classification"] is None
    # Report must contain steps with status for validator consumption.
    step_names = {s["step"]: s["status"] for s in data["steps"]}
    assert step_names.get("factory_reset") == "success"
    assert step_names.get("install") == "success"
    assert data["clean_result"] is not None


def test_fresh_install_report_with_demo_records_demo_steps(tmp_path: Path, monkeypatch) -> None:
    """Fresh-install execution with run_demo=True must record demo steps in the report."""
    transcript_path = tmp_path / "transcript.json"
    report_path = tmp_path / "report.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    def fake_run_wizard_install(choices):
        return 0

    def fake_run_wizard_demo_with_result(choices):
        return {"exit_code": 0, "failure_classification": None}

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)
    monkeypatch.setattr(wizard_integration, "run_wizard_demo_with_result", fake_run_wizard_demo_with_result)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
        run_demo=True,
    )
    result = wizard_integration.execute_wizard_choices(
        choices, record_path=str(transcript_path), report_path=str(report_path)
    )
    assert result == 0
    assert report_path.exists()
    import json
    data = json.loads(report_path.read_text(encoding="utf-8"))
    step_names = {s["step"]: s["status"] for s in data["steps"]}
    assert step_names.get("run_demo_invocation") == "success"
    assert step_names.get("run_demo_validate") == "success"
    assert step_names.get("run_demo") == "success"


def test_fresh_install_report_when_demo_fails(tmp_path: Path, monkeypatch) -> None:
    """If demo fails, report must record failed demo steps and non-zero exit."""
    transcript_path = tmp_path / "transcript.json"
    report_path = tmp_path / "report.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    def fake_run_wizard_install(choices):
        return 0

    def fake_run_wizard_demo_with_result(choices):
        return {"exit_code": 1, "failure_classification": "Repository-internal blocker"}

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)
    monkeypatch.setattr(wizard_integration, "run_wizard_demo_with_result", fake_run_wizard_demo_with_result)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
        run_demo=True,
    )
    result = wizard_integration.execute_wizard_choices(
        choices, record_path=str(transcript_path), report_path=str(report_path)
    )
    assert result == 1
    assert report_path.exists()
    import json
    data = json.loads(report_path.read_text(encoding="utf-8"))
    assert data["exit_status"] == 1
    step_names = {s["step"]: s["status"] for s in data["steps"]}
    assert step_names.get("run_demo") == "failed"


def test_report_path_via_choices_attribute(tmp_path: Path, monkeypatch) -> None:
    """choices.report_path must be respected when no explicit report_path kwarg is passed."""
    report_path = tmp_path / "report.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    def fake_run_wizard_install(choices):
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    choices = wizard_integration.WizardChoices(
        install_profile="core",
        clean_profile="repo-clean",
        dry_run=True,
        report_path=str(report_path),
    )
    result = wizard_integration.execute_wizard_choices(choices)
    assert result == 0
    assert report_path.exists()
    import json
    data = json.loads(report_path.read_text(encoding="utf-8"))
    assert data["exit_status"] == 0


def test_cli_main_passes_run_demo_and_report_to_execute(monkeypatch) -> None:
    calls: list[tuple[wizard_integration.WizardChoices, dict]] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append((choices, {"record_path": record_path, "report_path": report_path}))
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    result = cli.main([
        "--fresh-install", "--clean-profile", "repo-clean",
        "--run-demo", "--report", ".logs/report.json",
        "--dry-run", "--yes",
    ])

    assert result == 0
    assert len(calls) == 1
    assert calls[0][0].run_demo is True
    assert calls[0][0].fresh_install is True
    assert calls[1][1]["report_path"] == ".logs/report.json" if len(calls) > 1 else calls[0][1]["report_path"] == ".logs/report.json"


def test_build_install_command_includes_run_demo() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="steps",
        run_demo=True,
    )
    cmd = wizard_integration.build_install_command(choices)
    assert cmd == ["cf", "setup", "install", "--profile", "steps", "--run-demo"]


def test_build_install_command_omits_run_demo_when_false() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="core",
        run_demo=False,
    )
    cmd = wizard_integration.build_install_command(choices)
    assert cmd == ["cf", "setup", "install", "--profile", "core"]


def test_run_wizard_forwards_run_demo(monkeypatch) -> None:
    """Registered cf setup wizard must forward --run-demo to the inner CLI."""
    calls: list[list[str]] = []

    def fake_wizard_main(argv):
        calls.append(argv)
        return 0

    monkeypatch.setattr(cli, "main", fake_wizard_main)

    from cf_setup_wizard.cli_registration import _run_wizard
    import argparse
    args = argparse.Namespace(
        profile="full",
        tui=False,
        no_tui=False,
        fresh_install=False,
        clean_profile=None,
        dry_run=False,
        yes=False,
        summary=False,
        emit_plan=None,
        execute_plan=None,
        record=None,
        report=None,
        no_color=False,
        plain=False,
        script=None,
        list_actions=False,
        format="text",
        test_mode=False,
        test_script=None,
        replay_transcript=None,
        run_demo=True,
    )
    result = _run_wizard(args)
    assert result == 0
    assert "--run-demo" in calls[0]


def test_run_wizard_forwards_no_run_demo(monkeypatch) -> None:
    """Registered cf setup wizard must forward --no-run-demo to the inner CLI."""
    calls: list[list[str]] = []

    def fake_wizard_main(argv):
        calls.append(argv)
        return 0

    monkeypatch.setattr(cli, "main", fake_wizard_main)

    from cf_setup_wizard.cli_registration import _run_wizard
    import argparse
    args = argparse.Namespace(
        profile="full",
        tui=False,
        no_tui=False,
        fresh_install=False,
        clean_profile=None,
        dry_run=False,
        yes=False,
        summary=False,
        emit_plan=None,
        execute_plan=None,
        record=None,
        report=None,
        no_color=False,
        plain=False,
        script=None,
        list_actions=False,
        format="text",
        test_mode=False,
        test_script=None,
        replay_transcript=None,
        run_demo=False,
    )
    result = _run_wizard(args)
    assert result == 0
    assert "--no-run-demo" in calls[0]


def test_run_wizard_omits_run_demo_when_none(monkeypatch) -> None:
    """Registered cf setup wizard must not forward demo flag when omitted."""
    calls: list[list[str]] = []

    def fake_wizard_main(argv):
        calls.append(argv)
        return 0

    monkeypatch.setattr(cli, "main", fake_wizard_main)

    from cf_setup_wizard.cli_registration import _run_wizard
    import argparse
    args = argparse.Namespace(
        profile="full",
        tui=False,
        no_tui=False,
        fresh_install=False,
        clean_profile=None,
        dry_run=False,
        yes=False,
        summary=False,
        emit_plan=None,
        execute_plan=None,
        record=None,
        report=None,
        no_color=False,
        plain=False,
        script=None,
        list_actions=False,
        format="text",
        test_mode=False,
        test_script=None,
        replay_transcript=None,
        run_demo=None,
    )
    result = _run_wizard(args)
    assert result == 0
    assert "--run-demo" not in calls[0]
    assert "--no-run-demo" not in calls[0]


def test_run_tui_forwards_run_demo(monkeypatch) -> None:
    """Registered cf setup tui must forward --run-demo to the inner CLI."""
    calls: list[list[str]] = []

    def fake_wizard_main(argv):
        calls.append(argv)
        return 0

    monkeypatch.setattr(cli, "main", fake_wizard_main)

    from cf_setup_wizard.cli_registration import _run_tui
    import argparse
    args = argparse.Namespace(
        profile="full",
        fresh_install=False,
        clean_profile=None,
        dry_run=False,
        yes=False,
        summary=False,
        emit_plan=None,
        execute_plan=None,
        record=None,
        report=None,
        no_color=False,
        plain=False,
        script=None,
        list_actions=False,
        format="text",
        test_mode=False,
        test_script=None,
        replay_transcript=None,
        run_demo=True,
    )
    result = _run_tui(args)
    assert result == 0
    assert "--run-demo" in calls[0]


def test_plan_execution_preserves_run_demo_false_when_no_cli_override(tmp_path: Path, monkeypatch) -> None:
    """--execute-plan must preserve stored run_demo=false when no CLI demo flag is given."""
    plan_path = tmp_path / "plan.json"
    calls: list[wizard_integration.WizardChoices] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append(choices)
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "full",
            "clean_profile": "full-clean",
            "dry_run": False,
            "yes": True,
            "fresh_install": True,
            "run_demo": False,
        },
        "equivalent_command": ["cf", "setup", "wizard", "--fresh-install", "--profile", "full", "--clean-profile", "full-clean", "--yes"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    result = cli.main(["--execute-plan", str(plan_path)])
    assert result == 0
    assert len(calls) == 1
    assert calls[0].run_demo is False


def test_plan_execution_overrides_run_demo_with_explicit_cli_flag(tmp_path: Path, monkeypatch) -> None:
    """--execute-plan with explicit --run-demo must override stored run_demo=false."""
    plan_path = tmp_path / "plan.json"
    calls: list[wizard_integration.WizardChoices] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append(choices)
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "full",
            "clean_profile": "full-clean",
            "dry_run": False,
            "yes": True,
            "fresh_install": True,
            "run_demo": False,
        },
        "equivalent_command": ["cf", "setup", "wizard", "--fresh-install", "--profile", "full", "--clean-profile", "full-clean", "--yes"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    result = cli.main(["--execute-plan", str(plan_path), "--run-demo"])
    assert result == 0
    assert len(calls) == 1
    assert calls[0].run_demo is True


def test_plan_execution_overrides_run_demo_true_with_no_run_demo(tmp_path: Path, monkeypatch) -> None:
    """--execute-plan with explicit --no-run-demo must override stored run_demo=true."""
    plan_path = tmp_path / "plan.json"
    calls: list[wizard_integration.WizardChoices] = []

    def fake_execute(choices, *, record_path=None, report_path=None):
        calls.append(choices)
        return 0

    monkeypatch.setattr(wizard_integration, "execute_wizard_choices", fake_execute)

    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "full",
            "clean_profile": "full-clean",
            "dry_run": False,
            "yes": True,
            "fresh_install": True,
            "run_demo": True,
        },
        "equivalent_command": ["cf", "setup", "wizard", "--fresh-install", "--profile", "full", "--clean-profile", "full-clean", "--run-demo", "--yes"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    result = cli.main(["--execute-plan", str(plan_path), "--no-run-demo"])
    assert result == 0
    assert len(calls) == 1
    assert calls[0].run_demo is False


def test_equivalent_command_includes_run_demo_and_report() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        fresh_install=True,
        run_demo=True,
        report_path=".logs/report.json",
    )
    cmd = wizard_integration.build_equivalent_command(choices)
    assert "--run-demo" in cmd
    assert "--report" in cmd
    assert ".logs/report.json" in cmd


def test_wizard_invocation_includes_run_demo_and_report() -> None:
    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        fresh_install=True,
        run_demo=True,
        report_path=".logs/report.json",
    )
    invocation = wizard_integration._build_wizard_invocation(choices)
    assert "--run-demo" in invocation
    assert "--report" in invocation
    assert ".logs/report.json" in invocation


def test_report_command_includes_run_demo_and_report(tmp_path: Path, monkeypatch) -> None:
    """Report command field must include --run-demo and --report when selected."""
    report_path = tmp_path / "report.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    def fake_run_wizard_install(choices):
        return 0

    def fake_run_wizard_demo_with_result(choices):
        return {"exit_code": 0, "failure_classification": None}

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)
    monkeypatch.setattr(wizard_integration, "run_wizard_demo_with_result", fake_run_wizard_demo_with_result)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        dry_run=False,
        yes=True,
        fresh_install=True,
        run_demo=True,
        report_path=str(report_path),
    )
    result = wizard_integration.execute_wizard_choices(choices, report_path=str(report_path))
    assert result == 0
    assert report_path.exists()
    import json
    data = json.loads(report_path.read_text(encoding="utf-8"))
    assert "--run-demo" in data["command"]
    assert "--report" in data["command"]
    assert str(report_path) in data["command"]
    assert "--run-demo" in data["wizard_invocation"]
    assert "--report" in data["wizard_invocation"]


def test_equivalent_command_includes_no_run_demo_when_explicitly_false() -> None:
    """build_equivalent_command must include --no-run-demo when run_demo is explicitly False."""
    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        fresh_install=True,
        run_demo=False,
    )
    cmd = wizard_integration.build_equivalent_command(choices)
    assert "--no-run-demo" in cmd
    assert "--run-demo" not in cmd


def test_wizard_invocation_includes_no_run_demo_when_explicitly_false() -> None:
    """_build_wizard_invocation must include --no-run-demo when run_demo is explicitly False."""
    choices = wizard_integration.WizardChoices(
        install_profile="full",
        clean_profile="full-clean",
        fresh_install=True,
        run_demo=False,
    )
    invocation = wizard_integration._build_wizard_invocation(choices)
    assert "--no-run-demo" in invocation
    assert "--run-demo" not in invocation


def test_cli_main_report_path_appears_in_report_command_and_wizard_invocation(tmp_path: Path, monkeypatch) -> None:
    """Report generated via cli.main([... '--report', path]) must include --report in command and wizard_invocation."""
    report_path = tmp_path / "report.json"

    def fake_run_wizard_clean_with_result(choices):
        return {"exit_code": 0}

    def fake_run_wizard_install(choices):
        return 0

    monkeypatch.setattr(wizard_integration, "run_wizard_clean_with_result", fake_run_wizard_clean_with_result)
    monkeypatch.setattr(wizard_integration, "run_wizard_install", fake_run_wizard_install)

    result = cli.main([
        "--fresh-install", "--clean-profile", "repo-clean",
        "--profile", "full", "--yes", "--dry-run", "--no-run-demo",
        "--report", str(report_path),
    ])
    assert result == 0
    assert report_path.exists()
    import json
    data = json.loads(report_path.read_text(encoding="utf-8"))
    assert "--report" in data["command"]
    assert str(report_path) in data["command"]
    assert "--report" in data["wizard_invocation"]
    assert str(report_path) in data["wizard_invocation"]


def test_plan_load_omitted_run_demo_defaults_to_none(tmp_path: Path) -> None:
    """load_plan must default run_demo to None when the plan omits the key."""
    plan_path = tmp_path / "plan.json"
    import json
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "core",
            "clean_profile": "repo-clean",
            "dry_run": True,
            "yes": False,
        },
        "equivalent_command": ["cf", "setup", "clean", "--profile", "repo-clean", "--dry-run"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    loaded = wizard_integration.load_plan(str(plan_path))
    assert loaded.run_demo is None


# WP05: Provider request contract tests


def test_WP05_run_wizard_install_pypi_demo_sends_execution_mode_distribution(monkeypatch) -> None:
    """WP05: run_wizard_install with install_source=pypi-demo must send execution_mode=distribution to the provider."""
    captured_requests: list[dict] = []

    class FakeSetup:
        def execute_install(self, request):
            captured_requests.append(dict(request))
            return {}

    class FakeProviderKey:
        SETUP_ORCHESTRATION = "SETUP_ORCHESTRATION"

    def fake_require_provider(key):
        return FakeSetup()

    import cf_setup_wizard.wizard_integration as wi
    import sys

    monkeypatch.setattr("cf_setup_wizard.wizard_integration.__builtins__", __builtins__)

    # Monkeypatch the import inside run_wizard_install by patching the module-level import path
    import types
    fake_contracts = types.ModuleType("cf_service_contracts")
    fake_contracts.ProviderKey = FakeProviderKey
    fake_contracts.require_provider = fake_require_provider
    monkeypatch.setitem(sys.modules, "cf_service_contracts", fake_contracts)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        install_source="pypi-demo",
        run_demo=True,
        dry_run=False,
    )
    result = wizard_integration.run_wizard_install(choices)
    assert result == 0
    assert len(captured_requests) == 1
    req = captured_requests[0]
    assert req.get("execution_mode") == "distribution", f"expected execution_mode=distribution, got: {req}"
    assert req.get("run_demo") is True, f"expected run_demo=True, got: {req}"
    assert req.get("profile") == "full"
    assert req.get("dry_run") is False


def test_WP05_run_wizard_install_dry_run_pypi_demo_sends_execution_mode_and_run_demo(monkeypatch) -> None:
    """WP05: run_wizard_install dry-run with pypi-demo must send execution_mode=distribution and run_demo=True."""
    captured_requests: list[dict] = []

    class FakeSetup:
        def execute_install(self, request):
            captured_requests.append(dict(request))
            return {}

    class FakeProviderKey:
        SETUP_ORCHESTRATION = "SETUP_ORCHESTRATION"

    def fake_require_provider(key):
        return FakeSetup()

    import types
    import sys
    fake_contracts = types.ModuleType("cf_service_contracts")
    fake_contracts.ProviderKey = FakeProviderKey
    fake_contracts.require_provider = fake_require_provider
    monkeypatch.setitem(sys.modules, "cf_service_contracts", fake_contracts)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        install_source="pypi-demo",
        run_demo=True,
        dry_run=True,
    )
    result = wizard_integration.run_wizard_install(choices)
    assert result == 0
    assert len(captured_requests) == 1
    req = captured_requests[0]
    assert req.get("execution_mode") == "distribution", f"expected execution_mode=distribution, got: {req}"
    assert req.get("run_demo") is True, f"expected run_demo=True, got: {req}"
    assert req.get("dry_run") is True


def test_WP05_run_wizard_install_repo_local_does_not_send_execution_mode(monkeypatch) -> None:
    """WP05: run_wizard_install with install_source=repo-local must NOT send execution_mode=distribution."""
    captured_requests: list[dict] = []

    class FakeSetup:
        def execute_install(self, request):
            captured_requests.append(dict(request))
            return {}

    class FakeProviderKey:
        SETUP_ORCHESTRATION = "SETUP_ORCHESTRATION"

    def fake_require_provider(key):
        return FakeSetup()

    import types
    import sys
    fake_contracts = types.ModuleType("cf_service_contracts")
    fake_contracts.ProviderKey = FakeProviderKey
    fake_contracts.require_provider = fake_require_provider
    monkeypatch.setitem(sys.modules, "cf_service_contracts", fake_contracts)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        install_source="repo-local",
        run_demo=None,
        dry_run=False,
    )
    result = wizard_integration.run_wizard_install(choices)
    assert result == 0
    assert len(captured_requests) == 1
    req = captured_requests[0]
    # No execution_mode should be set for repo-local source
    assert "execution_mode" not in req, f"unexpected execution_mode in repo-local request: {req}"
    # run_demo=None should not be forwarded
    assert "run_demo" not in req, f"unexpected run_demo in request when choices.run_demo is None: {req}"


def test_WP05_run_wizard_install_pypi_demo_run_demo_false(monkeypatch) -> None:
    """WP05: run_wizard_install pypi-demo with run_demo=False must send run_demo=False and execution_mode=distribution."""
    captured_requests: list[dict] = []

    class FakeSetup:
        def execute_install(self, request):
            captured_requests.append(dict(request))
            return {}

    class FakeProviderKey:
        SETUP_ORCHESTRATION = "SETUP_ORCHESTRATION"

    def fake_require_provider(key):
        return FakeSetup()

    import types
    import sys
    fake_contracts = types.ModuleType("cf_service_contracts")
    fake_contracts.ProviderKey = FakeProviderKey
    fake_contracts.require_provider = fake_require_provider
    monkeypatch.setitem(sys.modules, "cf_service_contracts", fake_contracts)

    choices = wizard_integration.WizardChoices(
        install_profile="full",
        install_source="pypi-demo",
        run_demo=False,
        dry_run=False,
    )
    result = wizard_integration.run_wizard_install(choices)
    assert result == 0
    assert len(captured_requests) == 1
    req = captured_requests[0]
    assert req.get("execution_mode") == "distribution", f"expected execution_mode=distribution, got: {req}"
    assert req.get("run_demo") is False, f"expected run_demo=False, got: {req}"
