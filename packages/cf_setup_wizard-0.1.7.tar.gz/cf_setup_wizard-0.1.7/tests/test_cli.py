from __future__ import annotations

import importlib
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

cli = importlib.import_module("cf_setup_wizard.cli")


def test_main_runs_classic_install_when_no_tui(monkeypatch) -> None:
    monkeypatch.setattr(cli, "run_classic_install", lambda profile, *, dry_run=False: 17)

    assert cli.main(["--no-tui", "--profile", "steps"]) == 17


def test_main_runs_textual_app_with_selected_flags(monkeypatch) -> None:
    calls: list[tuple[str, bool, bool, bool]] = []

    def fake_run_textual_app(
        profile: str,
        *,
        resume_install: bool = False,
        run_demo: bool = True,
        show_details: bool = True,
    ) -> int:
        calls.append((profile, resume_install, run_demo, show_details))
        return 0

    monkeypatch.setattr(cli, "run_textual_app", fake_run_textual_app)

    result = cli.main(["--profile", "web", "--resume-install", "--no-run-demo", "--no-show-details"])

    assert result == 0
    assert calls == [("web", True, False, False)]


def test_main_runs_textual_app_when_tui_flag_given(monkeypatch) -> None:
    calls: list[tuple[str, bool, bool, bool]] = []

    def fake_run_textual_app(
        profile: str,
        *,
        resume_install: bool = False,
        run_demo: bool = True,
        show_details: bool = True,
    ) -> int:
        calls.append((profile, resume_install, run_demo, show_details))
        return 0

    monkeypatch.setattr(cli, "run_textual_app", fake_run_textual_app)

    result = cli.main(["--tui", "--profile", "core"])

    assert result == 0
    assert calls == [("core", False, True, True)]


def test_main_runs_classic_install_when_tui_and_no_tui_both_given(monkeypatch) -> None:
    """--no-tui takes precedence over --tui when both are provided."""
    monkeypatch.setattr(cli, "run_classic_install", lambda profile, *, dry_run=False: 17)

    assert cli.main(["--tui", "--no-tui", "--profile", "steps"]) == 17
