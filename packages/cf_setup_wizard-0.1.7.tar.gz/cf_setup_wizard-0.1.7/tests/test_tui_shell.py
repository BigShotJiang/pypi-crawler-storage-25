from __future__ import annotations

import importlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

tui_shell = importlib.import_module("cf_setup_wizard.tui_shell")
cli = importlib.import_module("cf_setup_wizard.cli")
action_registry = importlib.import_module("cf_setup_wizard.action_registry")


def test_navigator_starts_in_main_menu() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    assert nav.current_state == tui_shell.STATE_MAIN_MENU


def test_dispatch_help_transitions_to_help_state() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.show_help")

    assert result["recognized"] is True
    assert result["available"] is True
    assert result["transition"] == tui_shell.STATE_HELP
    assert nav.current_state == tui_shell.STATE_HELP
    assert "action.show_help" in nav.executed_actions


def test_dispatch_exit_transitions_to_exit_state() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.exit")

    assert result["recognized"] is True
    assert result["available"] is True
    assert result["transition"] == tui_shell.STATE_EXIT
    assert nav.current_state == tui_shell.STATE_EXIT
    assert "action.exit" in nav.executed_actions


def test_dispatch_cancel_cleanup_returns_to_main_menu() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.current_state = tui_shell.STATE_HELP
    result = nav.dispatch("action.cancel_cleanup")

    assert result["recognized"] is True
    assert result["available"] is True
    assert result["transition"] == tui_shell.STATE_MAIN_MENU
    assert nav.current_state == tui_shell.STATE_MAIN_MENU


def test_dispatch_unknown_action_is_skipped() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.unknown_action")

    assert result["recognized"] is False
    assert result["available"] is False
    assert "action.unknown_action" in nav.skipped_actions


def test_dispatch_unavailable_action_in_state_is_skipped() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.current_state = tui_shell.STATE_EXIT
    result = nav.dispatch("select.install_profile.core")

    assert result["recognized"] is True
    assert result["available"] is False
    assert "select.install_profile.core" in nav.skipped_actions


def test_run_test_mode_with_sequence(capsys) -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    exit_code = nav.run(["action.show_help", "action.exit"])

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "STATE: main_menu" in captured.out
    assert "ACTION: action.show_help" in captured.out
    assert "transition: help" in captured.out
    assert "ACTION: action.exit" in captured.out
    assert "transition: exit" in captured.out
    assert "FINAL_STATE: exit" in captured.out


def test_run_test_mode_stops_at_exit(capsys) -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    exit_code = nav.run(["action.exit", "action.show_help"])

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "FINAL_STATE: exit" in captured.out
    assert "ACTION: action.show_help" not in captured.out


def test_run_test_mode_records_executed_and_skipped(capsys) -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["action.show_help", "action.unknown", "action.exit"])

    captured = capsys.readouterr()
    assert "EXECUTED: action.show_help,action.exit" in captured.out
    assert "SKIPPED: action.unknown" in captured.out


def test_render_screen_includes_actions_and_status() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    text = nav.render_screen()

    assert "Main navigation menu" in text
    assert "action.show_help" in text
    assert "action.exit" in text
    assert "Current install profile: full" in text
    assert "Current clean profile: none" in text
    assert "Dry-run mode: off" in text


def test_get_available_actions_returns_screen_actions() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    actions = nav.get_available_actions()

    assert "action.show_help" in actions
    assert "action.exit" in actions
    assert "select.install_profile.core" in actions


def test_navigator_uses_action_registry_for_validation() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    # All available actions from the registry should be recognized
    for action_id in nav.get_available_actions():
        result = nav.dispatch(action_id)
        assert result["recognized"] is True, f"Action {action_id} not recognized"


def test_cli_routes_test_mode_to_navigator(monkeypatch, tmp_path) -> None:
    script_path = tmp_path / "actions.json"
    script_path.write_text(json.dumps(["action.show_help", "action.exit"]), encoding="utf-8")

    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)

    result = cli.main(["--test-mode", "--test-script", str(script_path)])
    assert result == 0
    combined = "\n".join(captured)
    assert "STATE: main_menu" in combined
    assert "transition: help" in combined


def test_cli_routes_test_mode_without_script(monkeypatch) -> None:
    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)

    result = cli.main(["--test-mode", "--profile", "core"])
    assert result == 0
    combined = "\n".join(captured)
    assert "STATE: main_menu" in combined
    assert "FINAL_STATE: main_menu" in combined


def test_navigator_records_transcript_when_record_path_set(tmp_path) -> None:
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(
        test_mode=True,
        record_path=str(record_path),
    )
    nav.run(["action.show_help", "action.exit"])

    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["version"] == "1"
    assert "executed_actions" in data
    assert "action.show_help" in data["executed_actions"]
    assert "action.exit" in data["executed_actions"]
    assert "skipped_actions" in data


def test_navigator_profile_selection_updates_state() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("select.install_profile.core")

    assert result["recognized"] is True
    assert result["available"] is True
    assert "Selected install profile: core" == result["message"]
    assert nav.install_profile == "core"
    assert "select.install_profile.core" in nav.executed_actions


def test_navigator_clean_profile_selection_updates_state() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("select.clean_profile.repo_clean")

    assert result["recognized"] is True
    assert result["available"] is True
    assert "Selected clean profile: repo-clean" == result["message"]
    assert nav.clean_profile == "repo-clean"
    assert "select.clean_profile.repo_clean" in nav.executed_actions


def test_navigator_toggle_dry_run_updates_state() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("toggle.dry_run")

    assert result["recognized"] is True
    assert result["available"] is True
    assert "Dry-run mode: on" == result["message"]
    assert nav.dry_run is True
    assert "toggle.dry_run" in nav.executed_actions

    # Toggling again should turn it off
    result2 = nav.dispatch("toggle.dry_run")
    assert result2["message"] == "Dry-run mode: off"
    assert nav.dry_run is False


def test_navigator_dispatch_does_not_use_screenshots_or_coordinates() -> None:
    """Ensure dispatch operates purely on action IDs and state, never visual interpretation."""
    nav = tui_shell.TUINavigator(test_mode=True)
    # All state transitions are deterministic and ID-based
    for _ in range(3):
        nav.dispatch("action.show_help")
        assert nav.current_state == tui_shell.STATE_HELP
        nav.dispatch("action.cancel_cleanup")
        assert nav.current_state == tui_shell.STATE_MAIN_MENU


def test_cli_combined_plain_no_color_test_mode_avoids_classic_install(monkeypatch) -> None:
    """--plain --no-color --test-mode must reach TUINavigator, not classic install."""
    monkeypatch.setattr(cli, "run_classic_install", lambda profile, *, dry_run=False: 99)
    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)

    result = cli.main(["--tui", "--plain", "--no-color", "--test-mode", "--profile", "core"])
    assert result == 0
    combined = "\n".join(captured)
    assert "STATE: main_menu" in combined
    assert "FINAL_STATE: main_menu" in combined


def test_cli_tui_alias_plain_no_color_test_mode_avoids_classic_install(monkeypatch) -> None:
    """Forwarded cf setup tui args must reach TUINavigator, not classic install."""
    monkeypatch.setattr(cli, "run_classic_install", lambda profile, *, dry_run=False: 99)
    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)

    # _run_tui forwards: --profile <profile> --tui --plain --no-color --test-mode
    result = cli.main(["--profile", "core", "--tui", "--plain", "--no-color", "--test-mode"])
    assert result == 0
    combined = "\n".join(captured)
    assert "STATE: main_menu" in combined
    assert "FINAL_STATE: main_menu" in combined


# TUI-WP08: Profile and clean selection screen tests


def test_all_install_profile_selections_update_state() -> None:
    """Every supported install profile must be selectable and update navigator state."""
    from cf_setup_wizard.wizard_integration import INSTALL_PROFILES

    for profile in INSTALL_PROFILES:
        nav = tui_shell.TUINavigator(test_mode=True)
        action_id = f"select.install_profile.{profile}"
        result = nav.dispatch(action_id)
        assert result["recognized"] is True, f"Action {action_id} not recognized"
        assert result["available"] is True, f"Action {action_id} not available"
        assert nav.install_profile == profile, f"Expected install_profile={profile}, got {nav.install_profile}"
        assert action_id in nav.executed_actions


def test_all_clean_profile_selections_update_state() -> None:
    """Every required clean profile must be selectable and update navigator state."""
    from cf_setup_wizard.wizard_integration import CLEAN_PROFILES

    for profile in CLEAN_PROFILES:
        nav = tui_shell.TUINavigator(test_mode=True)
        action_id = f"select.clean_profile.{profile.replace('-', '_')}"
        result = nav.dispatch(action_id)
        assert result["recognized"] is True, f"Action {action_id} not recognized"
        assert result["available"] is True, f"Action {action_id} not available"
        assert nav.clean_profile == profile, f"Expected clean_profile={profile}, got {nav.clean_profile}"
        assert action_id in nav.executed_actions


def test_test_mode_shows_profile_state_and_equivalent_command(capsys) -> None:
    """Deterministic output must reflect selected profiles and equivalent command."""
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["select.install_profile.core", "toggle.dry_run", "action.exit"])

    captured = capsys.readouterr()
    assert "FINAL_INSTALL_PROFILE: core" in captured.out
    assert "FINAL_CLEAN_PROFILE: none" in captured.out
    assert "FINAL_DRY_RUN: on" in captured.out
    assert "EQUIVALENT_COMMAND: cf setup install --profile core --dry-run" in captured.out


def test_test_mode_clean_profile_equivalent_command(capsys) -> None:
    """Selecting a clean profile must produce the correct equivalent command."""
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["select.clean_profile.workspace_clean", "action.exit"])

    captured = capsys.readouterr()
    assert "FINAL_CLEAN_PROFILE: workspace-clean" in captured.out
    assert "EQUIVALENT_COMMAND: cf setup clean --profile workspace-clean" in captured.out


def test_transcript_records_selected_profiles_and_dry_run(tmp_path) -> None:
    """Transcript must contain structured choices including install profile, clean profile, and dry_run."""
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(
        test_mode=True,
        record_path=str(record_path),
    )
    nav.run([
        "select.install_profile.steps",
        "select.clean_profile.full_clean",
        "toggle.dry_run",
        "action.exit",
    ])

    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["choices"]["install_profile"] == "steps"
    assert data["choices"]["clean_profile"] == "full-clean"
    assert data["choices"]["dry_run"] is True
    assert "select.install_profile.steps" in data["executed_actions"]
    assert "select.clean_profile.full_clean" in data["executed_actions"]
    assert "toggle.dry_run" in data["executed_actions"]
    assert data["equivalent_command"] == ["cf", "setup", "clean", "--profile", "full-clean", "--dry-run"]


def test_cli_test_mode_with_clean_profile_and_dry_run(monkeypatch) -> None:
    """CLI must forward clean_profile and dry_run into TUINavigator test mode."""
    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)

    result = cli.main([
        "--test-mode",
        "--profile", "web",
        "--clean-profile", "repo-clean",
        "--dry-run",
    ])
    assert result == 0
    combined = "\n".join(captured)
    assert "INSTALL_PROFILE: web" in combined
    assert "CLEAN_PROFILE: repo-clean" in combined
    assert "DRY_RUN: on" in combined


def test_render_screen_reflects_selected_profiles() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.dispatch("select.install_profile.web")
    nav.dispatch("select.clean_profile.full_clean")
    nav.dispatch("toggle.dry_run")
    text = nav.render_screen()

    assert "Current install profile: web" in text
    assert "Current clean profile: full-clean" in text
    assert "Dry-run mode: on" in text


def test_profile_selection_derived_from_shared_metadata() -> None:
    """All selectable profile actions must match shared setup metadata."""
    from cf_setup_wizard.wizard_integration import INSTALL_PROFILES, CLEAN_PROFILES

    nav = tui_shell.TUINavigator(test_mode=True)
    available = nav.get_available_actions()

    install_actions = sorted([a for a in available if a.startswith("select.install_profile.")])
    expected_install = sorted([f"select.install_profile.{p}" for p in INSTALL_PROFILES])
    assert install_actions == expected_install

    clean_actions = sorted([a for a in available if a.startswith("select.clean_profile.")])
    expected_clean = sorted([f"select.clean_profile.{p.replace('-', '_')}" for p in CLEAN_PROFILES])
    assert clean_actions == expected_clean


# TUI-WP09: Diagnostics and plan view tests


def test_diagnostics_action_reachable_and_updates_state(monkeypatch) -> None:
    """Diagnostics action must be reachable and store result in navigator state."""
    fake = {"provider": "windows", "tools": [{"name": "python", "available": True}]}
    monkeypatch.setattr(tui_shell, "run_setup_diagnostics", lambda: fake)
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.run_diagnostics")
    assert result["recognized"] is True
    assert result["available"] is True
    assert "Diagnostics completed" in result["message"]
    assert nav.last_diagnostics_result == fake
    assert "action.run_diagnostics" in nav.executed_actions


def test_plan_view_action_reachable_and_updates_state(monkeypatch) -> None:
    """Plan view action must be reachable and store result for selected profile."""
    fake = {"profile": "core", "ordered_modules": [{"package_name": "cf-core-cli", "source": "local-build"}]}
    monkeypatch.setattr(tui_shell, "run_setup_plan", lambda profile, mode="repo": fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.view_install_plan")
    assert result["recognized"] is True
    assert result["available"] is True
    assert "Plan for profile 'core'" in result["message"]
    assert nav.last_plan_result == fake
    assert "action.view_install_plan" in nav.executed_actions


def test_test_mode_shows_diagnostics_summary(capsys, monkeypatch) -> None:
    """Deterministic output must include diagnostics summary when action is executed."""
    fake = {"provider": "windows", "tools": [{"name": "python", "available": True}, {"name": "cmake", "available": False}]}
    monkeypatch.setattr(tui_shell, "run_setup_diagnostics", lambda: fake)
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["action.run_diagnostics", "action.exit"])
    captured = capsys.readouterr()
    assert "DIAGNOSTICS_TOOLS_COUNT: 2" in captured.out
    assert "python: pass" in captured.out
    assert "cmake: fail" in captured.out


def test_test_mode_shows_plan_summary(capsys, monkeypatch) -> None:
    """Deterministic output must include plan summary when action is executed."""
    fake = {"profile": "steps", "ordered_modules": [{"package_name": "cf-core-cli", "source": "local-build"}, {"package_name": "cf-pipeline-sdk", "source": "local-build"}]}
    monkeypatch.setattr(tui_shell, "run_setup_plan", lambda profile, mode="repo": fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="steps")
    nav.run(["action.view_install_plan", "action.exit"])
    captured = capsys.readouterr()
    assert "PLAN_PROFILE: steps" in captured.out
    assert "PLAN_MODULES_COUNT: 2" in captured.out
    assert "cf-core-cli: local-build" in captured.out


def test_transcript_records_diagnostics_and_plan_results(tmp_path, monkeypatch) -> None:
    """Transcript must contain structured diagnostics and plan results."""
    fake_diag = {"provider": "windows", "tools": [{"name": "python", "available": True}]}
    fake_plan = {"profile": "web", "ordered_modules": [{"package_name": "cf-core-cli", "source": "local-build"}]}
    monkeypatch.setattr(tui_shell, "run_setup_diagnostics", lambda: fake_diag)
    monkeypatch.setattr(tui_shell, "run_setup_plan", lambda profile, mode="repo": fake_plan)
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, record_path=str(record_path))
    nav.run(["action.run_diagnostics", "action.view_install_plan", "action.exit"])
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["diagnostics_result"] == fake_diag
    assert data["plan_result"] == fake_plan


def test_diagnostics_failure_classified_correctly(monkeypatch) -> None:
    """Diagnostics failure must update exit code and message."""
    fake = {"error": "subprocess failed", "returncode": 1}
    monkeypatch.setattr(tui_shell, "run_setup_diagnostics", lambda: fake)
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.run_diagnostics")
    assert "Diagnostics failed" in result["message"]
    assert nav.exit_code == 1


def test_plan_failure_classified_correctly(monkeypatch) -> None:
    """Plan failure must update exit code and message."""
    fake = {"error": "manifest not found", "returncode": 2}
    monkeypatch.setattr(tui_shell, "run_setup_plan", lambda profile, mode="repo": fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.view_install_plan")
    assert "Plan failed" in result["message"]
    assert nav.exit_code == 2


def test_diagnostics_and_plan_real_subprocess_end_to_end() -> None:
    """Prove that shared diagnostics and plan commands are reachable through the TUI shell."""
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.run_diagnostics")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.last_diagnostics_result is not None
    assert "error" not in nav.last_diagnostics_result or "tools" in nav.last_diagnostics_result

    nav2 = tui_shell.TUINavigator(test_mode=True, profile="core")
    result2 = nav2.dispatch("action.view_install_plan")
    assert result2["recognized"] is True
    assert result2["available"] is True
    assert nav2.last_plan_result is not None
    assert "ordered_modules" in nav2.last_plan_result


def test_main_menu_actions_derived_from_registry_not_hardcoded() -> None:
    """Main menu profile/clean actions must come from shared metadata, not a static list."""
    from cf_setup_wizard.wizard_integration import INSTALL_PROFILES, CLEAN_PROFILES
    actions = tui_shell._build_main_menu_actions()
    install_actions = sorted([a for a in actions if a.startswith("select.install_profile.")])
    expected_install = sorted([f"select.install_profile.{p}" for p in INSTALL_PROFILES])
    assert install_actions == expected_install
    clean_actions = sorted([a for a in actions if a.startswith("select.clean_profile.")])
    expected_clean = sorted([f"select.clean_profile.{p.replace('-', '_')}" for p in CLEAN_PROFILES])
    assert clean_actions == expected_clean


# TUI-WP10: Install and clean execution flow tests


def test_install_dry_run_action_reachable_and_updates_state(monkeypatch) -> None:
    fake = {"exit_code": 0, "failure_classification": None, "profile": "core", "dry_run": True}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.run_install_dry_run")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.last_install_result == fake
    assert "action.run_install_dry_run" in nav.executed_actions
    assert nav.exit_code == 0


def test_install_execution_action_reachable_and_updates_state(monkeypatch) -> None:
    fake = {"exit_code": 0, "failure_classification": None, "profile": "core", "dry_run": False}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.run_install")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.last_install_result == fake
    assert "action.run_install" in nav.executed_actions
    assert nav.exit_code == 0


def test_install_execution_failure_classified(monkeypatch) -> None:
    fake = {"exit_code": 1, "failure_classification": "Repository-internal blocker", "profile": "core", "dry_run": False}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.run_install")
    assert "failed" in result["message"]
    assert nav.exit_code == 1


def test_clean_dry_run_action_reachable_for_repo_clean(monkeypatch) -> None:
    fake = {"profile": "repo-clean", "mode": "dry-run", "target_count": 2, "deleted_count": 0, "exit_code": 0, "failure_classification": None}
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean")
    result = nav.dispatch("action.run_clean_dry_run")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.last_clean_result == fake
    assert "action.run_clean_dry_run" in nav.executed_actions
    assert nav.exit_code == 0


def test_clean_dry_run_action_reachable_for_workspace_clean(monkeypatch) -> None:
    fake = {"profile": "workspace-clean", "mode": "dry-run", "path_exists": True, "top_level_count": 3, "deleted_count": 0, "exit_code": 0, "failure_classification": None}
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="workspace-clean")
    result = nav.dispatch("action.run_clean_dry_run")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.last_clean_result == fake
    assert "action.run_clean_dry_run" in nav.executed_actions


def test_clean_dry_run_action_reachable_for_full_clean(monkeypatch) -> None:
    fake = {"profile": "full-clean", "mode": "dry-run", "phases": {"repo_clean": {"target_count": 1}, "workspace_clean": {"path_exists": True}}, "exit_code": 0, "failure_classification": None}
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="full-clean")
    result = nav.dispatch("action.run_clean_dry_run")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.last_clean_result == fake
    assert "action.run_clean_dry_run" in nav.executed_actions


def test_clean_execution_confirmed_in_safe_fixture(tmp_path: Path, monkeypatch) -> None:
    import os
    repo = tmp_path / "repo"
    repo.mkdir()
    build = repo / "build"
    build.mkdir()
    original_cwd = os.getcwd()
    try:
        os.chdir(repo)
        nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False)
        result1 = nav.dispatch("action.run_clean")
        assert nav.pending_confirmation is True
        assert "requires confirmation" in result1["message"]
        result2 = nav.dispatch("action.confirm_cleanup")
        assert nav.pending_confirmation is False
        assert nav.yes is True
        assert nav.last_clean_result is not None
        assert nav.last_clean_result["exit_code"] == 0
        assert nav.last_clean_result["deleted_count"] == 1
        assert not build.exists()
        assert "action.confirm_cleanup" in nav.executed_actions
    finally:
        os.chdir(original_cwd)


def test_clean_execution_rejected() -> None:
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False)
    result1 = nav.dispatch("action.run_clean")
    assert nav.pending_confirmation is True
    result2 = nav.dispatch("action.cancel_cleanup")
    assert nav.pending_confirmation is False
    assert "cancelled" in nav.confirmation_decisions
    assert nav.current_state == tui_shell.STATE_MAIN_MENU
    assert nav.last_clean_result is None
    assert "action.cancel_cleanup" in nav.executed_actions


def test_clean_execution_refused_without_force(monkeypatch) -> None:
    called: list = []
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: called.append(choices) or {})
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False)
    result = nav.dispatch("action.run_clean")
    assert not called
    assert nav.pending_confirmation is True
    assert "requires confirmation" in result["message"]
    assert "action.run_clean" in nav.executed_actions


def test_unsafe_clean_operation_refused(monkeypatch) -> None:
    fake = {"exit_code": 3, "failure_classification": "Unsafe operation refused", "profile": "repo-clean", "mode": "execute"}
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False, yes=True)
    result = nav.dispatch("action.run_clean")
    assert nav.last_clean_result == fake
    assert nav.exit_code == 3
    assert "Unsafe operation refused" in result["message"]


def test_clean_execution_no_profile_skipped() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.run_clean_dry_run")
    assert result["recognized"] is True
    assert result["available"] is True
    assert "No clean profile selected" in result["message"]
    assert "action.run_clean_dry_run" in nav.skipped_actions


def test_run_clean_with_dry_run_toggle_runs_dry_run(monkeypatch) -> None:
    fake = {"profile": "repo-clean", "mode": "dry-run", "target_count": 1, "deleted_count": 0, "exit_code": 0, "failure_classification": None}
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=True)
    result = nav.dispatch("action.run_clean")
    assert nav.last_clean_result == fake
    assert nav.pending_confirmation is False
    assert "dry-run completed" in result["message"]


def test_run_clean_with_yes_directly_executes(monkeypatch) -> None:
    fake = {"profile": "repo-clean", "mode": "execute", "deleted_count": 1, "exit_code": 0, "failure_classification": None}
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False, yes=True)
    result = nav.dispatch("action.run_clean")
    assert nav.last_clean_result == fake
    assert nav.pending_confirmation is False
    assert "completed" in result["message"]


def test_confirm_cleanup_without_pending_is_skipped() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.confirm_cleanup")
    assert result["recognized"] is True
    assert result["available"] is True
    assert "No pending cleanup" in result["message"]
    assert "action.confirm_cleanup" in nav.skipped_actions


def test_test_mode_shows_install_and_clean_result(capsys, monkeypatch) -> None:
    fake_install = {"exit_code": 0, "failure_classification": None, "profile": "core", "dry_run": True}
    fake_clean = {"profile": "repo-clean", "mode": "dry-run", "target_count": 2, "deleted_count": 0, "exit_code": 0, "failure_classification": None}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake_install)
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake_clean)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core", clean_profile="repo-clean")
    nav.run(["action.run_install_dry_run", "action.run_clean_dry_run", "action.exit"])
    captured = capsys.readouterr()
    assert "INSTALL_RESULT_EXIT_CODE: 0" in captured.out
    assert "CLEAN_RESULT_EXIT_CODE: 0" in captured.out
    assert "CLEAN_RESULT_MODE: dry-run" in captured.out
    assert "CLEAN_RESULT_DELETED_COUNT: 0" in captured.out
    assert "CLEAN_RESULT_TARGET_COUNT: 2" in captured.out


def test_transcript_records_install_and_clean_results(tmp_path: Path, monkeypatch) -> None:
    fake_install = {"exit_code": 0, "failure_classification": None, "profile": "core", "dry_run": True}
    fake_clean = {"profile": "repo-clean", "mode": "dry-run", "target_count": 2, "deleted_count": 0, "exit_code": 0, "failure_classification": None}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake_install)
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake_clean)
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, profile="core", clean_profile="repo-clean", record_path=str(record_path))
    nav.run(["action.run_install_dry_run", "action.run_clean_dry_run", "action.exit"])
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["install_result"] == fake_install
    assert data["clean_result"] == fake_clean


def test_transcript_records_confirmation_decisions(tmp_path: Path) -> None:
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False)
    record_path = tmp_path / "transcript.json"
    nav.record_path = str(record_path)
    nav.run(["action.run_clean", "action.confirm_cleanup", "action.exit"])
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert "confirmed" in data["confirmation_decisions"]
    assert "action.confirm_cleanup" in data["executed_actions"]


def test_transcript_records_cancelled_decision(tmp_path: Path) -> None:
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False)
    record_path = tmp_path / "transcript.json"
    nav.record_path = str(record_path)
    nav.run(["action.run_clean", "action.cancel_cleanup", "action.exit"])
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert "cancelled" in data["confirmation_decisions"]
    assert "action.cancel_cleanup" in data["executed_actions"]


# TUI-WP11: Plan, replay, and transcript integration tests


def test_emit_setup_plan_action_emits_machine_readable_plan(tmp_path: Path) -> None:
    plan_path = tmp_path / "setup-plan.json"
    nav = tui_shell.TUINavigator(test_mode=True, profile="core", clean_profile="repo-clean", dry_run=True, plan_path=str(plan_path))
    result = nav.dispatch("action.emit_setup_plan")
    assert result["recognized"] is True
    assert result["available"] is True
    assert plan_path.exists()
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    assert plan["version"] == "1"
    assert plan["choices"]["install_profile"] == "core"
    assert plan["choices"]["clean_profile"] == "repo-clean"
    assert plan["choices"]["dry_run"] is True
    assert plan["equivalent_command"] == ["cf", "setup", "clean", "--profile", "repo-clean", "--dry-run"]
    assert "action_ids" in plan
    assert "action.emit_setup_plan" in plan["action_ids"]["executed"]


def test_plan_includes_stable_action_ids_and_session_state(tmp_path: Path) -> None:
    plan_path = tmp_path / "setup-plan.json"
    nav = tui_shell.TUINavigator(test_mode=True, profile="steps", plan_path=str(plan_path))
    nav.run([
        "select.install_profile.steps",
        "toggle.dry_run",
        "action.emit_setup_plan",
        "action.exit",
    ])
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    assert "action_ids" in plan
    assert "select.install_profile.steps" in plan["action_ids"]["executed"]
    assert "toggle.dry_run" in plan["action_ids"]["executed"]
    assert "action.emit_setup_plan" in plan["action_ids"]["executed"]
    # Plan captures state at emission time, which is before action.exit transitions
    assert plan["session"]["current_state"] == "main_menu"
    assert plan["session"]["pending_confirmation"] is False


def test_execute_setup_plan_action_executes_plan_without_visual_tui(tmp_path: Path, monkeypatch) -> None:
    plan_path = tmp_path / "setup-plan.json"
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "core",
            "clean_profile": None,
            "dry_run": True,
            "yes": False,
        },
        "equivalent_command": ["cf", "setup", "install", "--profile", "core", "--dry-run"],
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")

    executed: list = []
    monkeypatch.setattr(tui_shell, "execute_wizard_choices", lambda choices: executed.append(choices) or 0)

    nav = tui_shell.TUINavigator(test_mode=True, plan_path=str(plan_path))
    result = nav.dispatch("action.execute_setup_plan")
    assert result["recognized"] is True
    assert result["available"] is True
    assert "Plan executed" in result["message"]
    assert len(executed) == 1
    assert executed[0].install_profile == "core"
    assert executed[0].dry_run is True


def test_execute_setup_plan_failure_classified(tmp_path: Path, monkeypatch) -> None:
    plan_path = tmp_path / "setup-plan.json"
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "core",
            "clean_profile": None,
            "dry_run": False,
            "yes": False,
        },
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")

    monkeypatch.setattr(tui_shell, "execute_wizard_choices", lambda choices: 1)

    nav = tui_shell.TUINavigator(test_mode=True, plan_path=str(plan_path))
    result = nav.dispatch("action.execute_setup_plan")
    assert nav.exit_code == 1
    assert "Repository-internal blocker" == result.get("failure_classification") or nav._classify_result(1)


def test_record_transcript_action_writes_transcript_immediately(tmp_path: Path) -> None:
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, profile="web", record_path=str(record_path))
    nav.run(["select.install_profile.web", "action.record_transcript", "action.exit"])
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["choices"]["install_profile"] == "web"
    assert "select.install_profile.web" in data["executed_actions"]
    assert "action.record_transcript" in data["executed_actions"]


def test_record_transcript_action_skipped_when_no_path_set() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.record_transcript")
    assert result["recognized"] is True
    assert "No record_path set" in result["message"]
    assert "action.record_transcript" in nav.skipped_actions


def test_replay_from_transcript_is_deterministic(tmp_path: Path) -> None:
    transcript_path = tmp_path / "transcript.json"
    transcript = {
        "version": "1",
        "executed_actions": [
            "select.install_profile.core",
            "toggle.dry_run",
            "action.exit",
        ],
    }
    transcript_path.write_text(json.dumps(transcript), encoding="utf-8")

    nav = tui_shell.TUINavigator(test_mode=True)
    exit_code = nav.replay_from_transcript(str(transcript_path))
    assert exit_code == 0
    assert nav.profile == "core"
    assert nav.dry_run is True
    assert nav.current_state == "exit"


def test_replay_action_sequence_directly() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    exit_code = nav.replay([
        "select.clean_profile.repo_clean",
        "action.exit",
    ])
    assert exit_code == 0
    assert nav.clean_profile == "repo-clean"
    assert nav.current_state == "exit"


def test_transcript_includes_failure_classifications_for_failed_flows(tmp_path: Path, monkeypatch) -> None:
    fake_install = {"exit_code": 1, "failure_classification": "Repository-internal blocker", "profile": "core", "dry_run": False}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake_install)
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, profile="core", record_path=str(record_path))
    nav.run(["action.run_install", "action.exit"])
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["failure_classification"] == "Repository-internal blocker"
    assert data["install_result"] == fake_install


def test_transcript_includes_skipped_and_refused_actions(tmp_path: Path) -> None:
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, record_path=str(record_path))
    nav.run(["action.run_clean_dry_run", "action.confirm_cleanup", "action.exit"])
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert "action.run_clean_dry_run" in data["skipped_actions"]
    assert "action.confirm_cleanup" in data["skipped_actions"]
    assert data["action_ids"]["skipped"] == ["action.run_clean_dry_run", "action.confirm_cleanup"]


def test_test_mode_shows_plan_emit_and_transcript_paths(capsys, tmp_path: Path) -> None:
    plan_path = tmp_path / "plan.json"
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(
        test_mode=True,
        profile="steps",
        plan_path=str(plan_path),
        record_path=str(record_path),
    )
    nav.run(["action.emit_setup_plan", "action.record_transcript", "action.exit"])
    captured = capsys.readouterr()
    assert "PLAN_EMIT_PATH:" in captured.out
    assert "TRANSCRIPT_RECORD_PATH:" in captured.out


def test_cli_replay_transcript_routes_to_navigator(monkeypatch, tmp_path: Path) -> None:
    transcript_path = tmp_path / "transcript.json"
    transcript = {
        "version": "1",
        "executed_actions": ["select.install_profile.core", "action.exit"],
    }
    transcript_path.write_text(json.dumps(transcript), encoding="utf-8")

    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)

    result = cli.main(["--replay-transcript", str(transcript_path)])
    assert result == 0
    combined = "\n".join(captured)
    assert "STATE: main_menu" in combined
    assert "FINAL_INSTALL_PROFILE: core" in combined
    assert "FINAL_STATE: exit" in combined


def test_emit_and_execute_round_trip(tmp_path: Path, monkeypatch) -> None:
    """Emit a plan from navigator state, then execute it, proving round-trip."""
    plan_path = tmp_path / "round-trip-plan.json"
    nav = tui_shell.TUINavigator(
        test_mode=True,
        profile="web",
        clean_profile="repo-clean",
        dry_run=True,
        plan_path=str(plan_path),
    )
    nav.dispatch("action.emit_setup_plan")
    assert plan_path.exists()

    executed: list = []
    monkeypatch.setattr(tui_shell, "execute_wizard_choices", lambda choices: executed.append(choices) or 0)

    nav2 = tui_shell.TUINavigator(test_mode=True, plan_path=str(plan_path))
    nav2.dispatch("action.execute_setup_plan")
    assert len(executed) == 1
    assert executed[0].install_profile == "web"
    assert executed[0].clean_profile == "repo-clean"
    assert executed[0].dry_run is True


def test_transcript_records_plan_emit_and_execute_paths(tmp_path: Path, monkeypatch) -> None:
    plan_path = tmp_path / "plan.json"
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(
        test_mode=True,
        profile="core",
        plan_path=str(plan_path),
        record_path=str(record_path),
    )
    monkeypatch.setattr(tui_shell, "execute_wizard_choices", lambda choices: 0)
    nav.run([
        "action.emit_setup_plan",
        "action.execute_setup_plan",
        "action.exit",
    ])
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data.get("plan_emit_path") == str(plan_path)
    assert data.get("plan_execute_path") == str(plan_path)


def test_transcript_records_equivalent_command_and_action_ids(tmp_path: Path) -> None:
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(
        test_mode=True,
        profile="core",
        dry_run=True,
        record_path=str(record_path),
    )
    nav.run(["action.emit_setup_plan", "action.exit"])
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["equivalent_command"] == ["cf", "setup", "install", "--profile", "core", "--dry-run"]
    assert "action.emit_setup_plan" in data["action_ids"]["executed"]


def test_plan_execution_updates_navigator_state_from_plan(tmp_path: Path, monkeypatch) -> None:
    plan_path = tmp_path / "plan.json"
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "steps",
            "clean_profile": "workspace-clean",
            "dry_run": True,
            "yes": True,
        },
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    monkeypatch.setattr(tui_shell, "execute_wizard_choices", lambda choices: 0)

    nav = tui_shell.TUINavigator(test_mode=True, plan_path=str(plan_path))
    nav.dispatch("action.execute_setup_plan")
    assert nav.profile == "steps"
    assert nav.clean_profile == "workspace-clean"
    assert nav.dry_run is True
    assert nav.yes is True


# TUI-WP03: run_demo toggle and --actions flag tests


def test_toggle_run_demo_on_sets_run_demo_true() -> None:
    """toggle.run_demo.on must set run_demo=True on the navigator."""
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("toggle.run_demo.on")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.run_demo is True
    assert "Run-demo mode: on" == result["message"]
    assert "toggle.run_demo.on" in nav.executed_actions


def test_toggle_run_demo_off_sets_run_demo_false() -> None:
    """toggle.run_demo.off must set run_demo=False on the navigator."""
    nav = tui_shell.TUINavigator(test_mode=True, run_demo=True)
    result = nav.dispatch("toggle.run_demo.off")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.run_demo is False
    assert "Run-demo mode: off" == result["message"]
    assert "toggle.run_demo.off" in nav.executed_actions


def test_test_mode_shows_run_demo_state(capsys) -> None:
    """Deterministic output must include RUN_DEMO field."""
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["toggle.run_demo.on", "action.exit"])
    captured = capsys.readouterr()
    assert "RUN_DEMO: on" in captured.out
    assert "FINAL_RUN_DEMO: on" in captured.out


def test_transcript_records_run_demo_choice(tmp_path: Path) -> None:
    """Transcript must contain run_demo in choices when toggled."""
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, record_path=str(record_path))
    nav.run(["select.install_source.pypi_demo", "toggle.run_demo.on", "action.exit"])
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["choices"]["install_source"] == "pypi-demo"
    assert data["choices"]["run_demo"] is True
    assert "toggle.run_demo.on" in data["executed_actions"]


def test_pypi_demo_selection_produces_correct_equivalent_command(capsys) -> None:
    """Selecting pypi_demo install source and full profile must produce --mode distribution command."""
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run([
        "select.install_source.pypi_demo",
        "select.install_profile.full",
        "toggle.run_demo.on",
        "action.exit",
    ])
    captured = capsys.readouterr()
    assert "FINAL_INSTALL_SOURCE: pypi-demo" in captured.out
    assert "FINAL_INSTALL_PROFILE: full" in captured.out
    assert "FINAL_RUN_DEMO: on" in captured.out
    # Equivalent command must include --mode distribution and --run-demo
    assert "--mode distribution" in captured.out
    assert "--run-demo" in captured.out


def test_pypi_demo_transcript_has_install_source_field(tmp_path: Path) -> None:
    """Transcript for pypi-demo path must record install_source=pypi-demo."""
    record_path = tmp_path / "tui-transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, record_path=str(record_path))
    nav.run([
        "select.install_source.pypi_demo",
        "select.install_profile.full",
        "toggle.run_demo.on",
        "action.exit",
    ])
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["choices"]["install_source"] == "pypi-demo"
    assert data["choices"]["install_profile"] == "full"
    assert data["choices"]["run_demo"] is True
    # Equivalent command in transcript must reflect distribution mode
    assert "--mode" in data["equivalent_command"]
    assert "distribution" in data["equivalent_command"]


def test_cli_actions_flag_routes_to_navigator(capsys) -> None:
    """--actions flag must route to TUINavigator with parsed action sequence."""
    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    import builtins
    orig = builtins.print
    builtins.print = fake_print
    try:
        result = cli.main([
            "--plain", "--no-color", "--test-mode",
            "--actions", "select.install_source.pypi_demo,select.install_profile.full,toggle.run_demo.on,action.exit",
        ])
    finally:
        builtins.print = orig

    assert result == 0
    combined = "\n".join(captured)
    assert "FINAL_INSTALL_SOURCE: pypi-demo" in combined
    assert "FINAL_INSTALL_PROFILE: full" in combined
    assert "FINAL_RUN_DEMO: on" in combined


def test_cli_actions_flag_implies_test_mode(capsys) -> None:
    """--actions without --test-mode must still route to TUINavigator."""
    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    import builtins
    orig = builtins.print
    builtins.print = fake_print
    try:
        result = cli.main([
            "--plain", "--no-color",
            "--actions", "select.install_source.pypi_demo,action.exit",
        ])
    finally:
        builtins.print = orig

    assert result == 0
    combined = "\n".join(captured)
    assert "FINAL_INSTALL_SOURCE: pypi-demo" in combined


def test_toggle_run_demo_on_in_action_registry() -> None:
    """toggle.run_demo.on and toggle.run_demo.off must be in the action registry."""
    on_action = action_registry.get_action("toggle.run_demo.on")
    off_action = action_registry.get_action("toggle.run_demo.off")
    assert on_action is not None, "toggle.run_demo.on not found in registry"
    assert off_action is not None, "toggle.run_demo.off not found in registry"
    assert on_action["category"] == "mode"
    assert off_action["category"] == "mode"
    assert on_action["transcript_field"] == "choices.run_demo"
    assert off_action["transcript_field"] == "choices.run_demo"


def test_toggle_run_demo_actions_available_in_main_menu() -> None:
    """toggle.run_demo.on and toggle.run_demo.off must be available from main menu."""
    nav = tui_shell.TUINavigator(test_mode=True)
    available = nav.get_available_actions()
    assert "toggle.run_demo.on" in available
    assert "toggle.run_demo.off" in available


def test_install_source_pypi_demo_not_repo_relative() -> None:
    """Selecting pypi-demo install source must not produce repo-local or repo-relative command."""
    from cf_setup_wizard.wizard_integration import WizardChoices, build_equivalent_command
    choices = WizardChoices(
        install_source="pypi-demo",
        install_profile="full",
        run_demo=True,
    )
    cmd = build_equivalent_command(choices)
    cmd_str = " ".join(cmd)
    # Must use --mode distribution, not repo-local
    assert "--mode distribution" in cmd_str
    # Must not reference local repo paths
    assert "repo-local" not in cmd_str
    assert "bootstrap" not in cmd_str
    assert "scripts" not in cmd_str


# ---------------------------------------------------------------------------
# WP04: TUI install execution routing — action.run_install choice propagation
# ---------------------------------------------------------------------------


def test_action_run_install_passes_pypi_demo_install_source(monkeypatch) -> None:
    """action.run_install must pass install_source=pypi-demo from navigator state."""
    captured: list = []

    def fake_run_install_with_result(choices):
        captured.append(choices)
        return {"exit_code": 0, "failure_classification": None}

    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", fake_run_install_with_result)

    nav = tui_shell.TUINavigator(test_mode=True)
    nav.dispatch("select.install_source.pypi_demo")
    nav.dispatch("select.install_profile.full")
    nav.dispatch("toggle.run_demo.on")
    nav.dispatch("action.run_install")

    assert len(captured) == 1, "run_wizard_install_with_result must be called exactly once"
    passed_choices = captured[0]
    assert passed_choices.install_source == "pypi-demo", (
        f"Expected install_source='pypi-demo', got '{passed_choices.install_source}'"
    )
    assert passed_choices.run_demo is True, (
        f"Expected run_demo=True, got {passed_choices.run_demo!r}"
    )
    assert passed_choices.install_profile == "full", (
        f"Expected install_profile='full', got '{passed_choices.install_profile}'"
    )
    assert passed_choices.dry_run is False, (
        f"Expected dry_run=False, got {passed_choices.dry_run!r}"
    )


def test_action_run_install_does_not_silently_revert_to_repo_local(monkeypatch) -> None:
    """action.run_install must not silently revert install_source to repo-local."""
    captured: list = []

    def fake_run_install_with_result(choices):
        captured.append(choices)
        return {"exit_code": 0, "failure_classification": None}

    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", fake_run_install_with_result)

    nav = tui_shell.TUINavigator(test_mode=True)
    nav.dispatch("select.install_source.pypi_demo")
    nav.dispatch("action.run_install")

    assert captured, "run_wizard_install_with_result must be called"
    assert captured[0].install_source != "repo-local", (
        "action.run_install must not revert install_source to repo-local after pypi_demo selection"
    )


def test_action_run_install_dry_run_passes_pypi_demo_install_source(monkeypatch) -> None:
    """action.run_install_dry_run must pass install_source=pypi-demo from navigator state."""
    captured: list = []

    def fake_run_install_with_result(choices):
        captured.append(choices)
        return {"exit_code": 0, "failure_classification": None}

    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", fake_run_install_with_result)

    nav = tui_shell.TUINavigator(test_mode=True)
    nav.dispatch("select.install_source.pypi_demo")
    nav.dispatch("select.install_profile.full")
    nav.dispatch("toggle.run_demo.on")
    nav.dispatch("action.run_install_dry_run")

    assert len(captured) == 1, "run_wizard_install_with_result must be called exactly once"
    passed_choices = captured[0]
    assert passed_choices.install_source == "pypi-demo", (
        f"Expected install_source='pypi-demo', got '{passed_choices.install_source}'"
    )
    assert passed_choices.run_demo is True, (
        f"Expected run_demo=True, got {passed_choices.run_demo!r}"
    )
    assert passed_choices.dry_run is True, (
        f"Expected dry_run=True, got {passed_choices.dry_run!r}"
    )


def test_action_run_install_dry_run_does_not_silently_drop_run_demo(monkeypatch) -> None:
    """action.run_install_dry_run must not silently drop run_demo after toggle.run_demo.on."""
    captured: list = []

    def fake_run_install_with_result(choices):
        captured.append(choices)
        return {"exit_code": 0, "failure_classification": None}

    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", fake_run_install_with_result)

    nav = tui_shell.TUINavigator(test_mode=True)
    nav.dispatch("select.install_source.pypi_demo")
    nav.dispatch("toggle.run_demo.on")
    nav.dispatch("action.run_install_dry_run")

    assert captured, "run_wizard_install_with_result must be called"
    assert captured[0].run_demo is True, (
        "action.run_install_dry_run must not drop run_demo after toggle.run_demo.on"
    )


def test_build_install_command_includes_mode_distribution_for_pypi_demo() -> None:
    """build_install_command must include --mode distribution for pypi-demo install source."""
    from cf_setup_wizard.wizard_integration import WizardChoices, build_install_command
    choices = WizardChoices(
        install_source="pypi-demo",
        install_profile="full",
        run_demo=True,
    )
    cmd = build_install_command(choices)
    cmd_str = " ".join(cmd)
    assert "--mode distribution" in cmd_str, (
        f"build_install_command must include '--mode distribution' for pypi-demo, got: {cmd_str}"
    )
    assert "--run-demo" in cmd_str, (
        f"build_install_command must include '--run-demo' when run_demo=True, got: {cmd_str}"
    )


def test_build_install_command_repo_local_has_no_mode_flag() -> None:
    """build_install_command must not include --mode for repo-local install source."""
    from cf_setup_wizard.wizard_integration import WizardChoices, build_install_command
    choices = WizardChoices(
        install_source="repo-local",
        install_profile="full",
    )
    cmd = build_install_command(choices)
    cmd_str = " ".join(cmd)
    assert "--mode" not in cmd_str, (
        f"build_install_command must not include '--mode' for repo-local, got: {cmd_str}"
    )


def test_action_run_install_execution_choices_agree_with_equivalent_command(monkeypatch) -> None:
    """Choices passed to run_wizard_install_with_result must agree with build_equivalent_command output."""
    from cf_setup_wizard.wizard_integration import build_install_command, build_equivalent_command

    captured: list = []

    def fake_run_install_with_result(choices):
        captured.append(choices)
        return {"exit_code": 0, "failure_classification": None}

    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", fake_run_install_with_result)

    nav = tui_shell.TUINavigator(test_mode=True)
    nav.dispatch("select.install_source.pypi_demo")
    nav.dispatch("select.install_profile.full")
    nav.dispatch("toggle.run_demo.on")
    nav.dispatch("action.run_install")

    assert captured, "run_wizard_install_with_result must be called"
    passed_choices = captured[0]

    equiv_cmd = build_equivalent_command(passed_choices)
    install_cmd = build_install_command(passed_choices)

    equiv_str = " ".join(equiv_cmd)
    install_str = " ".join(install_cmd)

    # Both commands must reflect the pypi-demo selection
    assert "--mode distribution" in equiv_str, f"equivalent_command missing --mode distribution: {equiv_str}"
    assert "--mode distribution" in install_str, f"build_install_command missing --mode distribution: {install_str}"
    assert "--run-demo" in equiv_str, f"equivalent_command missing --run-demo: {equiv_str}"
    assert "--run-demo" in install_str, f"build_install_command missing --run-demo: {install_str}"
