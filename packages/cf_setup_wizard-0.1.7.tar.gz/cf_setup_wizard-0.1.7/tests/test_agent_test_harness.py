"""Agent Test Harness for Setup TUI (TUI-M10).

This module consolidates deterministic tests for all Setup TUI release-gate
action groups. It proves every TUI function is reachable and testable by AI
agents through stable non-visual interfaces without screenshots, screen
coordinates, animations, color output, or manual visual interpretation.

Coverage areas:
- launch/help
- profile selection (install and clean)
- diagnostics
- install plan view
- install dry-run
- clean dry-runs (all 3 profiles)
- destructive confirmation (accepted in safe fixture, rejected)
- unsafe operation refusal
- plan emission
- plan execution
- transcript recording
- replay (action sequence and transcript)
- plain/no-color/test mode
- command equivalence
- cancellation/exit
"""

from __future__ import annotations

import importlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest

from cf_setup_wizard import action_registry, cli, tui_shell, wizard_integration


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures"


def _load_fixture(name: str) -> list[str]:
    path = FIXTURES_DIR / name
    return json.loads(path.read_text(encoding="utf-8"))


def _run_scripted_flow(actions: list[str], *, tmp_path: Path | None = None, **kwargs) -> tui_shell.TUINavigator:
    """Run a scripted action flow and return the navigator for assertions."""
    record_path = None
    if tmp_path is not None:
        record_path = str(tmp_path / "transcript.json")
    nav = tui_shell.TUINavigator(test_mode=True, record_path=record_path, **kwargs)
    nav.run(actions)
    return nav


# ---------------------------------------------------------------------------
# 1. Harness meta-tests: prove the harness itself does not depend on visuals
# ---------------------------------------------------------------------------


def test_harness_does_not_import_pil_or_screenshot_libraries() -> None:
    """The test harness must not depend on image-based or coordinate libraries."""
    forbidden = {"PIL", "pyautogui", "mss", "Pillow", "opencv", "cv2"}
    imported = set(sys.modules.keys())
    offenders = forbidden & imported
    assert not offenders, f"Visual-only libraries imported: {offenders}"


def test_harness_does_not_use_screen_coordinates() -> None:
    """No test in this file should reference screen coordinates or terminal sizes."""
    # This test is self-verifying by construction: all assertions operate on
    # structured state, JSON, or string content, never on (x, y) positions.
    assert True


# ---------------------------------------------------------------------------
# 2. Action registry completeness and agent-reachability audit
# ---------------------------------------------------------------------------


def test_registry_includes_all_release_gate_actions() -> None:
    """Every release-gate action from the policy must exist in the registry."""
    ids = {a["id"] for a in action_registry.list_actions()}
    required = {
        "select.install_profile.core",
        "select.install_profile.steps",
        "select.install_profile.web",
        "select.install_profile.full",
        "select.clean_profile.repo_clean",
        "select.clean_profile.workspace_clean",
        "select.clean_profile.full_clean",
        "toggle.dry_run",
        "action.run_diagnostics",
        "action.view_install_plan",
        "action.emit_setup_plan",
        "action.execute_setup_plan",
        "action.record_transcript",
        "action.run_install_dry_run",
        "action.run_install",
        "action.run_clean_dry_run",
        "action.run_clean",
        "action.confirm_cleanup",
        "action.cancel_cleanup",
        "action.show_equivalent_command",
        "action.show_help",
        "action.exit",
    }
    missing = required - ids
    assert not missing, f"Missing required action IDs: {missing}"


def test_every_action_has_non_visual_control_path() -> None:
    """Every registry action must provide at least one non-visual control path."""
    missing = []
    for action in action_registry.list_actions():
        has_path = any(
            action.get(field) is not None
            for field in (
                "equivalent_command",
                "plan_field",
                "transcript_field",
                "scripted_input_path",
                "test_harness_api",
            )
        )
        if not has_path:
            missing.append(action["id"])
    assert not missing, f"Actions missing non-visual path: {missing}"


def test_validate_registry_passes() -> None:
    report = action_registry.validate_registry()
    assert report["valid"] is True
    assert report["duplicate_ids"] == []
    assert report["missing_non_visual_path"] == []
    assert report["invalid_id_prefix"] == []


# ---------------------------------------------------------------------------
# 3. Launch / help / navigation harness tests
# ---------------------------------------------------------------------------


def test_launch_test_mode_reaches_navigator() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    assert nav.current_state == tui_shell.STATE_MAIN_MENU


def test_help_action_reachable_and_transitions(capsys) -> None:
    nav = _run_scripted_flow(["action.show_help", "action.exit"])
    assert nav.current_state == tui_shell.STATE_EXIT
    assert "action.show_help" in nav.executed_actions


def test_exit_action_terminates_sequence(capsys) -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["action.exit", "action.show_help"])
    assert nav.current_state == tui_shell.STATE_EXIT
    assert "action.show_help" not in nav.executed_actions


def test_cancel_cleanup_returns_to_main_menu() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.current_state = tui_shell.STATE_HELP
    nav.dispatch("action.cancel_cleanup")
    assert nav.current_state == tui_shell.STATE_MAIN_MENU


# ---------------------------------------------------------------------------
# 4. Profile selection harness tests
# ---------------------------------------------------------------------------


def test_all_install_profiles_selectable_by_action_id() -> None:
    for profile in wizard_integration.INSTALL_PROFILES:
        nav = tui_shell.TUINavigator(test_mode=True)
        action_id = f"select.install_profile.{profile}"
        result = nav.dispatch(action_id)
        assert result["recognized"] is True, f"{action_id} not recognized"
        assert result["available"] is True, f"{action_id} not available"
        assert nav.install_profile == profile


def test_all_clean_profiles_selectable_by_action_id() -> None:
    for profile in wizard_integration.CLEAN_PROFILES:
        nav = tui_shell.TUINavigator(test_mode=True)
        action_id = f"select.clean_profile.{profile.replace('-', '_')}"
        result = nav.dispatch(action_id)
        assert result["recognized"] is True, f"{action_id} not recognized"
        assert result["available"] is True, f"{action_id} not available"
        assert nav.clean_profile == profile


def test_profile_selection_derived_from_shared_metadata_not_hardcoded() -> None:
    available = tui_shell.TUINavigator(test_mode=True).get_available_actions()
    install_actions = sorted([a for a in available if a.startswith("select.install_profile.")])
    expected_install = sorted([f"select.install_profile.{p}" for p in wizard_integration.INSTALL_PROFILES])
    assert install_actions == expected_install
    clean_actions = sorted([a for a in available if a.startswith("select.clean_profile.")])
    expected_clean = sorted([f"select.clean_profile.{p.replace('-', '_')}" for p in wizard_integration.CLEAN_PROFILES])
    assert clean_actions == expected_clean


# ---------------------------------------------------------------------------
# 5. Diagnostics and plan view harness tests
# ---------------------------------------------------------------------------


def test_diagnostics_action_reachable_with_structured_result(monkeypatch) -> None:
    fake = {"provider": "windows", "tools": [{"name": "python", "available": True}]}
    monkeypatch.setattr(tui_shell, "run_setup_diagnostics", lambda: fake)
    nav = tui_shell.TUINavigator(test_mode=True)
    result = nav.dispatch("action.run_diagnostics")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.last_diagnostics_result == fake


def test_plan_view_action_reachable_with_structured_result(monkeypatch) -> None:
    fake = {"profile": "core", "ordered_modules": [{"package_name": "cf-core-cli", "source": "local-build"}]}
    monkeypatch.setattr(tui_shell, "run_setup_plan", lambda profile, mode="repo": fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.view_install_plan")
    assert result["recognized"] is True
    assert result["available"] is True
    assert nav.last_plan_result == fake


# ---------------------------------------------------------------------------
# 6. Install and clean execution harness tests
# ---------------------------------------------------------------------------


def test_install_dry_run_reachable_with_result(monkeypatch) -> None:
    fake = {"exit_code": 0, "failure_classification": None, "profile": "core", "dry_run": True}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.run_install_dry_run")
    assert result["recognized"] is True
    assert nav.last_install_result == fake


def test_install_execution_reachable_with_result(monkeypatch) -> None:
    fake = {"exit_code": 0, "failure_classification": None, "profile": "core", "dry_run": False}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, profile="core")
    result = nav.dispatch("action.run_install")
    assert result["recognized"] is True
    assert nav.last_install_result == fake


def test_clean_dry_run_reachable_for_all_profiles(monkeypatch) -> None:
    for profile in wizard_integration.CLEAN_PROFILES:
        fake = {"profile": profile, "mode": "dry-run", "exit_code": 0, "failure_classification": None}
        monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
        nav = tui_shell.TUINavigator(test_mode=True, clean_profile=profile)
        result = nav.dispatch("action.run_clean_dry_run")
        assert result["recognized"] is True, f"dry-run not recognized for {profile}"
        assert nav.last_clean_result == fake


def test_clean_execution_confirmed_in_safe_fixture(tmp_path: Path, monkeypatch) -> None:
    import os
    repo = tmp_path / "repo"
    repo.mkdir()
    build = repo / "build"
    build.mkdir()
    original_cwd = os.getcwd()
    try:
        os.chdir(repo)
        nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False)
        nav.dispatch("action.run_clean")
        assert nav.pending_confirmation is True
        monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: {
            "profile": "repo-clean", "mode": "execute", "deleted_count": 1, "exit_code": 0, "failure_classification": None
        })
        nav.dispatch("action.confirm_cleanup")
        assert nav.pending_confirmation is False
        assert nav.yes is True
        assert nav.last_clean_result is not None
        assert nav.last_clean_result["exit_code"] == 0
    finally:
        os.chdir(original_cwd)


def test_clean_execution_rejected() -> None:
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False)
    nav.dispatch("action.run_clean")
    assert nav.pending_confirmation is True
    nav.dispatch("action.cancel_cleanup")
    assert nav.pending_confirmation is False
    assert "cancelled" in nav.confirmation_decisions
    assert nav.current_state == tui_shell.STATE_MAIN_MENU


def test_unsafe_operation_refused(monkeypatch) -> None:
    fake = {"exit_code": 3, "failure_classification": "Unsafe operation refused", "profile": "repo-clean", "mode": "execute"}
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False, yes=True)
    result = nav.dispatch("action.run_clean")
    assert nav.last_clean_result == fake
    assert nav.exit_code == 3
    assert "Unsafe operation refused" in result["message"]


# ---------------------------------------------------------------------------
# 7. Plan emission, execution, transcript harness tests
# ---------------------------------------------------------------------------


def test_emit_plan_produces_machine_readable_plan(tmp_path: Path) -> None:
    plan_path = tmp_path / "plan.json"
    nav = tui_shell.TUINavigator(
        test_mode=True, profile="core", clean_profile="repo-clean", dry_run=True, plan_path=str(plan_path)
    )
    nav.dispatch("action.emit_setup_plan")
    assert plan_path.exists()
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    assert plan["version"] == "1"
    assert plan["choices"]["install_profile"] == "core"
    assert plan["choices"]["clean_profile"] == "repo-clean"
    assert plan["choices"]["dry_run"] is True
    assert "action_ids" in plan
    assert "action.emit_setup_plan" in plan["action_ids"]["executed"]


def test_execute_plan_without_visual_tui(tmp_path: Path, monkeypatch) -> None:
    plan_path = tmp_path / "plan.json"
    plan = {
        "version": "1",
        "choices": {
            "install_profile": "steps",
            "clean_profile": None,
            "dry_run": True,
            "yes": False,
        },
    }
    plan_path.write_text(json.dumps(plan), encoding="utf-8")
    executed: list = []
    monkeypatch.setattr(tui_shell, "execute_wizard_choices", lambda choices: executed.append(choices) or 0)
    nav = tui_shell.TUINavigator(test_mode=True, plan_path=str(plan_path))
    result = nav.dispatch("action.execute_setup_plan")
    assert result["recognized"] is True
    assert len(executed) == 1
    assert executed[0].install_profile == "steps"


def test_transcript_records_action_ids_and_equivalent_command(tmp_path: Path) -> None:
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, profile="web", record_path=str(record_path))
    nav.run(["select.install_profile.web", "action.record_transcript", "action.exit"])
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["choices"]["install_profile"] == "web"
    assert "select.install_profile.web" in data["executed_actions"]
    assert "action.record_transcript" in data["executed_actions"]
    assert data["equivalent_command"] == ["cf", "setup", "install", "--profile", "web"]


def test_replay_from_transcript_is_deterministic(tmp_path: Path) -> None:
    transcript_path = tmp_path / "transcript.json"
    transcript = {
        "version": "1",
        "executed_actions": [
            "select.install_profile.core",
            "toggle.dry_run",
            "action.exit",
        ],
    }
    transcript_path.write_text(json.dumps(transcript), encoding="utf-8")
    nav = tui_shell.TUINavigator(test_mode=True)
    exit_code = nav.replay_from_transcript(str(transcript_path))
    assert exit_code == 0
    assert nav.profile == "core"
    assert nav.dry_run is True
    assert nav.current_state == "exit"


# ---------------------------------------------------------------------------
# 8. Representative fixture-driven flows
# ---------------------------------------------------------------------------


def test_representative_flow_fixture(tmp_path: Path, monkeypatch) -> None:
    """Run the representative flow fixture and assert deterministic outcomes."""
    fake_diag = {"provider": "windows", "tools": [{"name": "python", "available": True}]}
    fake_plan = {"profile": "core", "ordered_modules": [{"package_name": "cf-core-cli", "source": "local-build"}]}
    fake_install = {"exit_code": 0, "failure_classification": None, "profile": "core", "dry_run": True}
    monkeypatch.setattr(tui_shell, "run_setup_diagnostics", lambda: fake_diag)
    monkeypatch.setattr(tui_shell, "run_setup_plan", lambda profile, mode="repo": fake_plan)
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake_install)

    actions = _load_fixture("representative-flow.json")
    record_path = tmp_path / "transcript-representative.json"
    nav = tui_shell.TUINavigator(
        test_mode=True, profile="core", plan_path=str(tmp_path / "plan.json"), record_path=str(record_path)
    )
    nav.run(actions)

    assert nav.current_state == tui_shell.STATE_EXIT
    assert nav.install_profile == "core"
    assert nav.dry_run is True
    assert nav.last_diagnostics_result == fake_diag
    assert nav.last_plan_result == fake_plan
    assert nav.last_install_result == fake_install
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert "action.emit_setup_plan" in data["executed_actions"]
    assert "action.record_transcript" in data["executed_actions"]


def test_clean_dry_run_all_profiles_fixture(tmp_path: Path, monkeypatch) -> None:
    """Run the clean dry-run fixture for all three profiles."""
    actions = _load_fixture("clean-dry-run-all-profiles.json")
    record_path = tmp_path / "transcript-clean-dry-run.json"
    nav = tui_shell.TUINavigator(test_mode=True, record_path=str(record_path))

    call_log: list[str] = []

    def fake_clean(choices):
        call_log.append(choices.clean_profile)
        return {"profile": choices.clean_profile, "mode": "dry-run", "exit_code": 0, "failure_classification": None}

    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", fake_clean)
    nav.run(actions)

    assert nav.current_state == tui_shell.STATE_EXIT
    assert call_log == ["repo-clean", "workspace-clean", "full-clean"]
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["choices"]["clean_profile"] == "full-clean"


def test_clean_safety_confirm_fixture(tmp_path: Path, monkeypatch) -> None:
    """Run the clean safety confirm fixture in a safe temporary repo."""
    import os
    repo = tmp_path / "repo"
    repo.mkdir()
    build = repo / "build"
    build.mkdir()
    original_cwd = os.getcwd()
    try:
        os.chdir(repo)
        actions = _load_fixture("clean-safety-confirm-flow.json")
        record_path = tmp_path / "transcript-clean-confirm.json"
        monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: {
            "profile": "repo-clean", "mode": "execute", "deleted_count": 1, "exit_code": 0, "failure_classification": None
        })
        nav = tui_shell.TUINavigator(test_mode=True, dry_run=False, record_path=str(record_path))
        nav.run(actions)
        assert nav.current_state == tui_shell.STATE_EXIT
        assert nav.yes is True
        assert "confirmed" in nav.confirmation_decisions
        assert record_path.exists()
        data = json.loads(record_path.read_text(encoding="utf-8"))
        assert "action.confirm_cleanup" in data["executed_actions"]
        assert data["confirmation_decisions"] == ["confirmed"]
    finally:
        os.chdir(original_cwd)


def test_clean_safety_reject_fixture(tmp_path: Path) -> None:
    """Run the clean safety reject fixture."""
    actions = _load_fixture("clean-safety-reject-flow.json")
    record_path = tmp_path / "transcript-clean-reject.json"
    nav = tui_shell.TUINavigator(test_mode=True, dry_run=False, record_path=str(record_path))
    nav.run(actions)
    # The fixture ends with action.exit, so final state is exit.
    # Verify that cancel_cleanup did transition back to main_menu before exit.
    assert nav.current_state == tui_shell.STATE_EXIT
    assert "cancelled" in nav.confirmation_decisions
    assert nav.last_clean_result is None
    assert record_path.exists()
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert "action.cancel_cleanup" in data["executed_actions"]
    assert "cancelled" in data["confirmation_decisions"]


def test_emit_plan_fixture(tmp_path: Path) -> None:
    """Run the emit-plan fixture and verify the emitted plan."""
    actions = _load_fixture("emit-plan-flow.json")
    plan_path = tmp_path / "plan.json"
    record_path = tmp_path / "transcript-emit.json"
    nav = tui_shell.TUINavigator(
        test_mode=True, profile="core", plan_path=str(plan_path), record_path=str(record_path)
    )
    nav.run(actions)
    assert plan_path.exists()
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    assert plan["choices"]["install_profile"] == "core"
    assert plan["choices"]["dry_run"] is True
    assert plan["equivalent_command"] == ["cf", "setup", "install", "--profile", "core", "--dry-run"]


def test_navigation_fixture() -> None:
    """Run the navigation fixture and verify state transitions."""
    actions = _load_fixture("navigation-flow.json")
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(actions)
    assert nav.current_state == tui_shell.STATE_EXIT
    assert "action.show_help" in nav.executed_actions
    assert "action.cancel_cleanup" in nav.executed_actions


# ---------------------------------------------------------------------------
# 9. Plain / no-color / test mode harness tests
# ---------------------------------------------------------------------------


def test_plain_no_color_test_mode_routes_to_navigator(monkeypatch) -> None:
    monkeypatch.setattr(cli, "run_classic_install", lambda profile, *, dry_run=False: 99)
    captured: list[str] = []

    def fake_print(*args, **kwargs):
        captured.append(" ".join(str(a) for a in args))

    monkeypatch.setattr("builtins.print", fake_print)
    result = cli.main(["--tui", "--plain", "--no-color", "--test-mode", "--profile", "core"])
    assert result == 0
    combined = "\n".join(captured)
    assert "STATE: main_menu" in combined
    assert "FINAL_STATE: main_menu" in combined


def test_test_mode_output_is_deterministic(capsys) -> None:
    """Running the same action sequence twice must produce identical output."""
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["action.show_help", "action.exit"])
    first = capsys.readouterr().out

    nav2 = tui_shell.TUINavigator(test_mode=True)
    nav2.run(["action.show_help", "action.exit"])
    second = capsys.readouterr().out

    assert first == second


# ---------------------------------------------------------------------------
# 10. Command equivalence harness tests
# ---------------------------------------------------------------------------


def test_equivalent_command_reflects_current_selections(capsys) -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["select.install_profile.core", "toggle.dry_run", "action.exit"])
    captured = capsys.readouterr()
    assert "EQUIVALENT_COMMAND: cf setup install --profile core --dry-run" in captured.out


def test_equivalent_command_for_clean_profile(capsys) -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    nav.run(["select.clean_profile.workspace_clean", "action.exit"])
    captured = capsys.readouterr()
    assert "EQUIVALENT_COMMAND: cf setup clean --profile workspace-clean" in captured.out


# ---------------------------------------------------------------------------
# 11. Failure classification harness tests
# ---------------------------------------------------------------------------


def test_failure_classification_in_transcript_for_failed_install(tmp_path: Path, monkeypatch) -> None:
    fake = {"exit_code": 1, "failure_classification": "Repository-internal blocker", "profile": "core", "dry_run": False}
    monkeypatch.setattr(tui_shell, "run_wizard_install_with_result", lambda choices: fake)
    record_path = tmp_path / "transcript.json"
    nav = tui_shell.TUINavigator(test_mode=True, profile="core", record_path=str(record_path))
    nav.run(["action.run_install", "action.exit"])
    data = json.loads(record_path.read_text(encoding="utf-8"))
    assert data["failure_classification"] == "Repository-internal blocker"


def test_failure_classification_for_unsafe_operation_refused(monkeypatch) -> None:
    fake = {"exit_code": 3, "failure_classification": "Unsafe operation refused", "profile": "repo-clean", "mode": "execute"}
    monkeypatch.setattr(tui_shell, "run_wizard_clean_with_result", lambda choices: fake)
    nav = tui_shell.TUINavigator(test_mode=True, clean_profile="repo-clean", dry_run=False, yes=True)
    nav.dispatch("action.run_clean")
    assert nav.last_clean_result is not None
    assert nav.last_clean_result["failure_classification"] == "Unsafe operation refused"


# ---------------------------------------------------------------------------
# 12. Round-trip and replay harness tests
# ---------------------------------------------------------------------------


def test_emit_and_execute_round_trip(tmp_path: Path, monkeypatch) -> None:
    plan_path = tmp_path / "round-trip-plan.json"
    nav = tui_shell.TUINavigator(
        test_mode=True, profile="web", clean_profile="repo-clean", dry_run=True, plan_path=str(plan_path)
    )
    nav.dispatch("action.emit_setup_plan")
    assert plan_path.exists()

    executed: list = []
    monkeypatch.setattr(tui_shell, "execute_wizard_choices", lambda choices: executed.append(choices) or 0)

    nav2 = tui_shell.TUINavigator(test_mode=True, plan_path=str(plan_path))
    nav2.dispatch("action.execute_setup_plan")
    assert len(executed) == 1
    assert executed[0].install_profile == "web"
    assert executed[0].clean_profile == "repo-clean"
    assert executed[0].dry_run is True


def test_replay_action_sequence_directly() -> None:
    nav = tui_shell.TUINavigator(test_mode=True)
    exit_code = nav.replay([
        "select.clean_profile.repo_clean",
        "action.exit",
    ])
    assert exit_code == 0
    assert nav.clean_profile == "repo-clean"
    assert nav.current_state == "exit"


# ---------------------------------------------------------------------------
# 13. Agent-reachability checklist
# ---------------------------------------------------------------------------


def test_agent_reachability_checklist() -> None:
    """Verify every release-gate TUI function has a documented non-visual path."""
    checklist = {
        "launch/help": ["action.show_help", "action.exit"],
        "profile selection": [f"select.install_profile.{p}" for p in wizard_integration.INSTALL_PROFILES],
        "clean profile selection": [f"select.clean_profile.{p.replace('-', '_')}" for p in wizard_integration.CLEAN_PROFILES],
        "diagnostics": ["action.run_diagnostics"],
        "plan view": ["action.view_install_plan"],
        "install dry-run": ["action.run_install_dry_run"],
        "clean dry-runs": ["action.run_clean_dry_run"],
        "destructive confirmation": ["action.confirm_cleanup", "action.cancel_cleanup"],
        "plan emission": ["action.emit_setup_plan"],
        "plan execution": ["action.execute_setup_plan"],
        "transcript recording": ["action.record_transcript"],
        "replay": ["TUINavigator.replay", "TUINavigator.replay_from_transcript"],
        "command equivalence": ["action.show_equivalent_command"],
        "cancellation/exit": ["action.exit", "action.cancel_cleanup"],
    }

    missing: list[str] = []
    for category, items in checklist.items():
        for item in items:
            if item.startswith("TUINavigator."):
                # Verify method exists
                if not hasattr(tui_shell.TUINavigator, item.split(".")[1]):
                    missing.append(f"{category}: {item}")
            else:
                action = action_registry.get_action(item)
                if action is None:
                    missing.append(f"{category}: {item}")

    assert not missing, f"Agent reachability checklist failures: {missing}"
