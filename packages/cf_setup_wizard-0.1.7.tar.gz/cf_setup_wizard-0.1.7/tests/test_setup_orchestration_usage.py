from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch
import inspect


class TestSetupOrchestrationContractDelegation:
    """Behavioral tests verifying wizard flows call the setup orchestration provider
    with expected request payloads."""

    def test_cli_run_classic_install_calls_provider_with_expected_payload(self):
        """Classic install flow calls execute_install with profile and details flag."""
        from cf_setup_wizard import cli
        from cf_service_contracts import ProviderKey

        fake_result = {"success": True}
        fake_provider = MagicMock()
        fake_provider.execute_install.return_value = fake_result

        def fake_require(key):
            if key == ProviderKey.SETUP_ORCHESTRATION:
                return fake_provider
            raise LookupError(key)

        with patch("cf_service_contracts.require_provider", side_effect=fake_require):
            result = cli.run_classic_install("full")

        fake_provider.execute_install.assert_called_once()
        call_kwargs = fake_provider.execute_install.call_args[0][0]
        assert call_kwargs.get("profile") == "full"
        assert "show_details" in call_kwargs
        assert call_kwargs.get("dry_run") is False

    def test_fallback_run_fallback_install_calls_provider_with_expected_payload(self):
        """Fallback install flow calls execute_install with profile and details flag."""
        from cf_setup_wizard import fallback
        from cf_service_contracts import ProviderKey

        fake_result = {"success": True}
        fake_provider = MagicMock()
        fake_provider.execute_install.return_value = fake_result

        def fake_require(key):
            if key == ProviderKey.SETUP_ORCHESTRATION:
                return fake_provider
            raise LookupError(key)

        with patch("cf_service_contracts.require_provider", side_effect=fake_require):
            result = fallback.run_fallback_install("full")

        fake_provider.execute_install.assert_called_once()
        call_kwargs = fake_provider.execute_install.call_args[0][0]
        assert call_kwargs.get("profile") == "full"
        assert "show_details" in call_kwargs
        assert call_kwargs.get("dry_run") is False

    def test_fallback_run_fallback_install_propagates_python_executable(self):
        """Fallback propagates python_exe to provider."""
        from cf_setup_wizard import fallback
        from cf_service_contracts import ProviderKey

        fake_provider = MagicMock()
        fake_provider.execute_install.return_value = {"success": True}

        def fake_require(key):
            if key == ProviderKey.SETUP_ORCHESTRATION:
                return fake_provider
            raise LookupError(key)

        with patch("cf_service_contracts.require_provider", side_effect=fake_require):
            fallback.run_fallback_install("core", python_exe="/custom/python")

        call_kwargs = fake_provider.execute_install.call_args[0][0]
        assert call_kwargs.get("python_exe") == "/custom/python"

    def test_integrator_calls_provider_plan_installation(self):
        """CfSetupIntegrator.plan_installation calls provider.plan_installation."""
        from cf_setup_wizard.integrate import CfSetupIntegrator
        from cf_service_contracts import ProviderKey

        fake_provider = MagicMock()
        fake_provider.default_manifest_path.return_value = str(Path("/fake/manifest.toml"))
        fake_provider.plan_installation.return_value = {
            "profile": "full",
            "ordered_modules": [],
            "hooks": [],
        }

        def fake_require(key):
            if key == ProviderKey.SETUP_ORCHESTRATION:
                return fake_provider
            raise LookupError(key)

        with patch("cf_service_contracts.require_provider", side_effect=fake_require):
            integrator = CfSetupIntegrator(repo_root=None)
            result = integrator.plan_installation(profile="full")

        fake_provider.plan_installation.assert_called_once()
        call_kwargs = fake_provider.plan_installation.call_args[0][0]
        assert call_kwargs.get("profile") == "full"

    def test_installer_calls_provider_execute_install(self):
        """CfSetupInstaller.execute_install calls provider.execute_install."""
        from cf_setup_wizard.integrate import CfSetupInstaller
        from cf_service_contracts import ProviderKey

        fake_provider = MagicMock()
        fake_provider.execute_install.return_value = {"success": True}

        def fake_require(key):
            if key == ProviderKey.SETUP_ORCHESTRATION:
                return fake_provider
            raise LookupError(key)

        with patch("cf_service_contracts.require_provider", side_effect=fake_require):
            installer = CfSetupInstaller(repo_root=None)
            result = installer.execute_install(profile="steps")

        fake_provider.execute_install.assert_called_once()
        call_kwargs = fake_provider.execute_install.call_args[0][0]
        assert call_kwargs.get("profile") == "steps"
        assert call_kwargs.get("dry_run") is False


class TestImportSurface:
    def test_cli_module_imports_cleanly(self):
        from cf_setup_wizard import cli
        assert hasattr(cli, "main")
        assert hasattr(cli, "run_classic_install")

    def test_fallback_module_imports_cleanly(self):
        from cf_setup_wizard import fallback
        assert hasattr(fallback, "run_fallback_install")
        assert hasattr(fallback, "is_interactive_terminal")

    def test_integrate_module_imports_cleanly(self):
        from cf_setup_wizard import integrate
        assert hasattr(integrate, "CfSetupIntegrator")
        assert hasattr(integrate, "CfSetupInstaller")
        assert hasattr(integrate, "PlannedModule")


class TestNoInternalPathCoupling:
    def test_cli_no_internal_path_reference(self):
        from cf_setup_wizard import cli
        source = inspect.getsource(cli.run_classic_install)
        assert "cf_setup/src" not in source
        assert "bootstrap.py" not in source

    def test_fallback_no_internal_path_reference(self):
        from cf_setup_wizard import fallback
        source = inspect.getsource(fallback.run_fallback_install)
        assert "cf_setup/src" not in source
        assert "bootstrap.py" not in source

    def test_integrate_no_internal_path_reference(self):
        from cf_setup_wizard import integrate
        source = inspect.getsource(integrate.CfSetupInstaller.execute_install)
        assert "cf_setup/src" not in source
        assert "bootstrap.py" not in source

    def test_integrate_no_direct_cf_setup_import(self):
        from cf_setup_wizard import integrate
        source = inspect.getsource(integrate)
        assert "from cf_setup" not in source
        assert "import cf_setup" not in source

    def test_cf_setup_wizard_package_has_no_source_tree_coupling(self):
        from cf_setup_wizard import cli, fallback, integrate
        for module in (cli, fallback, integrate):
            source = inspect.getsource(module)
            assert "cf_setup/src" not in source, f"{module.__name__} contains cf_setup/src path"


class TestNoModuleNameCommandCoupling:
    def test_cli_no_subprocess_with_module_flag(self):
        from cf_setup_wizard import cli
        source = inspect.getsource(cli.run_classic_install)
        assert "subprocess" not in source
        assert '"-m"' not in source
        assert "'-m'" not in source

    def test_fallback_no_subprocess_with_module_flag(self):
        from cf_setup_wizard import fallback
        source = inspect.getsource(fallback.run_fallback_install)
        assert "subprocess" not in source
        assert '"-m"' not in source
        assert "'-m'" not in source


class TestBackendDelegation:
    def test_cli_delegates_to_backend(self):
        from cf_setup_wizard import cli
        source = inspect.getsource(cli.run_classic_install)
        assert "require_provider" in source or "execute_install" in source

    def test_fallback_delegates_to_backend(self):
        from cf_setup_wizard import fallback
        source = inspect.getsource(fallback.run_fallback_install)
        assert "require_provider" in source or "execute_install" in source


class TestContractBehavior:
    def test_cli_uses_contract_delegation(self):
        from cf_setup_wizard import cli
        source = inspect.getsource(cli.run_classic_install)
        assert "require_provider" in source

    def test_fallback_uses_contract_delegation(self):
        from cf_setup_wizard import fallback
        source = inspect.getsource(fallback.run_fallback_install)
        assert "require_provider" in source