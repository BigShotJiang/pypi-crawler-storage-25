from __future__ import annotations

import importlib
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from rich.text import Text

app_module = importlib.import_module("cf_setup_wizard.app")


def test_resolve_wizard_version_uses_distribution(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    app.repo_root = Path(__file__).resolve().parents[3]

    monkeypatch.setattr(app_module.metadata, "version", lambda name: "0.1.2")

    assert app._resolve_wizard_version() == "0.1.2"


def test_ensure_runtime_dependency_skips_install_when_module_exists(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    app.repo_root = Path(__file__).resolve().parents[3]
    calls: list[list[str]] = []

    class Completed:
        def __init__(self, returncode: int) -> None:
            self.returncode = returncode

    def fake_run(command, cwd=None, capture_output=False, text=False, check=False):
        calls.append(command)
        return Completed(0)

    monkeypatch.setattr(app_module.subprocess, "run", fake_run)

    app._ensure_runtime_dependency("packaging", "packaging>=24")

    assert calls == [[sys.executable, "-c", "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('packaging') else 1)"]]


def test_ensure_runtime_dependency_installs_when_missing(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    app.repo_root = Path(__file__).resolve().parents[3]
    calls: list[list[str]] = []

    class Completed:
        def __init__(self, returncode: int) -> None:
            self.returncode = returncode

    def fake_run(command, cwd=None, capture_output=False, text=False, check=False):
        calls.append(command)
        if command[1] == "-c":
            return Completed(1)
        return Completed(0)

    monkeypatch.setattr(app_module.subprocess, "run", fake_run)

    app._ensure_runtime_dependency("packaging", "packaging>=24")

    assert calls[1] == [sys.executable, "-m", "pip", "install", "packaging>=24"]


def test_render_header_shows_wizard_version(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    app.wizard_version = "0.1.2"
    app.setup_version = "0.1.4"

    updates: dict[str, object] = {}

    class DummyStatic:
        def __init__(self, key: str) -> None:
            self.key = key

        def update(self, value) -> None:
            updates[self.key] = value

    class FakeDateTime:
        @staticmethod
        def now():
            from datetime import datetime

            return datetime(2026, 4, 20, 16, 0, 0)

    monkeypatch.setattr(app_module, "datetime", FakeDateTime)
    monkeypatch.setattr(app, "query_one", lambda selector, _type=None: DummyStatic(selector))

    app._render_header()

    title = updates["#header-title"]
    assert isinstance(title, Text)
    assert "CogniFlow Setup (0.1.2)" == title.plain
    assert updates["#header-meta"] == "cf_setup 0.1.4   |   16:00:00"


def test_resume_install_flow_continues_after_preview_failure(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    messages: list[tuple[str, str]] = []
    started: list[bool] = []
    applied: list[str] = []

    monkeypatch.setattr(app, "_build_preview_rows", lambda: (_ for _ in ()).throw(RuntimeError("No module named 'packaging'")))
    monkeypatch.setattr(app, "_apply_preview_error", lambda message: applied.append(message))
    monkeypatch.setattr(app, "notify", lambda message, severity="information": messages.append((message, severity)))
    monkeypatch.setattr(app, "start_install", lambda: started.append(True))

    app._resume_install_flow()

    assert applied == ["No module named 'packaging'"]
    assert messages == [("Preview unavailable, continuing with install.", "warning")]
    assert started == [True]


def test_progress_bar_can_hide_percentage() -> None:
    progress_module = importlib.import_module("cf_setup_wizard.widgets.progress_bar")
    widget = progress_module.ProgressBar(total=100, show_percentage=False)
    rendered: list[str] = []

    widget.update = rendered.append  # type: ignore[method-assign]
    widget.update_progress(25)

    assert rendered
    assert "25.0%" not in rendered[-1]


def test_prepare_install_view_does_not_require_removed_progress_label(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    app.install_status = "Launching cf_setup"
    app.install_started_at = None
    app.install_activity_frame = 0
    app.done_success = False
    app.done_message_base = ""
    app.done_close_seconds = None
    app.current_batch_packages = []
    app.current_batch_label = ""
    app.last_failed_step = None
    app.last_failed_package = None
    app.preview_rows = []
    app.install_item_states = {}
    app.install_item_details = {}
    app.install_item_order = {}
    app.install_event_counter = 0
    app.run_demo = True

    updates: list[tuple[str, object]] = []

    class DummyNode:
        def __init__(self, selector: str) -> None:
            self.selector = selector

        def update(self, *args, **kwargs) -> None:
            updates.append((self.selector, kwargs if kwargs else args))

    monkeypatch.setattr(app, "query_one", lambda selector, _type=None: DummyNode(selector))
    monkeypatch.setattr(app, "_render_install_overview", lambda: updates.append(("overview", None)))
    monkeypatch.setattr(app, "_render_checklist", lambda: updates.append(("checklist", None)))
    monkeypatch.setattr(app, "_render_install_activity", lambda: updates.append(("activity", None)))
    monkeypatch.setattr(app, "_set_screen", lambda screen: updates.append(("screen", screen)))

    app._prepare_install_view()

    selectors = [item[0] for item in updates]
    assert "#progress-label" not in selectors
    assert "#overall-progress" in selectors


def test_bindings_include_help_and_quit() -> None:
    keys = {b.key: b.action for b in app_module.CogniflowWizardApp.BINDINGS}
    assert keys.get("h") == "show_help"
    assert keys.get("q") == "quit_app"
    assert keys.get("escape") == "quit_app"


def test_footer_includes_help_key(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    app.run_demo = True
    app.show_details = True
    app.done_success = False
    app.done_close_seconds = None

    updates: dict[str, object] = {}

    class DummyNode:
        def __init__(self, selector: str) -> None:
            self.selector = selector

        def update(self, value) -> None:
            updates[self.selector] = value

    monkeypatch.setattr(app, "query_one", lambda selector, _type=None: DummyNode(selector))

    for screen in ("welcome", "license", "main", "install", "done"):
        app.current_screen = screen
        app._render_footer()
        footer = str(updates.get("#footer-text", ""))
        assert "H help" in footer, f"missing H help on {screen}"


def test_main_message_includes_summary_and_help(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    app.run_demo = True
    app.show_details = True

    updates: dict[str, object] = {}

    class DummyNode:
        def __init__(self, selector: str) -> None:
            self.selector = selector

        def update(self, value) -> None:
            updates[self.selector] = value

    monkeypatch.setattr(app, "query_one", lambda selector, _type=None: DummyNode(selector))
    app._render_main_message()
    text = str(updates.get("#main-message", ""))
    assert "Ready to install" in text
    assert "H for help" in text
    assert "Esc/Q to quit" in text


def test_status_icons_have_textual_meaning() -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    app.install_item_states = {
        "a": "pending",
        "b": "running",
        "c": "done",
        "d": "failed",
        "e": "skipped",
    }
    assert app._status_icon_for_row("a") == "..."
    assert app._status_icon_for_row("b") == ">"
    assert app._status_icon_for_row("c") == "✔"
    assert app._status_icon_for_row("d") == "✖"
    assert app._status_icon_for_row("e") == "-"


def test_action_show_help_pushes_help_screen(monkeypatch) -> None:
    app = object.__new__(app_module.CogniflowWizardApp)
    screens_pushed: list[type] = []
    monkeypatch.setattr(app, "push_screen", lambda screen: screens_pushed.append(type(screen)))
    app.action_show_help()
    assert len(screens_pushed) == 1
    assert screens_pushed[0] is app_module.HelpScreen
