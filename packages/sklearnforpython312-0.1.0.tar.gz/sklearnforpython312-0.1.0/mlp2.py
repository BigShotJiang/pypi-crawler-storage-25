import numpy as np
X=np.array([[0,0],[0,1],[1,0],[1,1]]) 
y=np.array([[0],[1],[1],[0]])
np.random.seed(1)
w1=np.random.rand(2,2)
w2=np.random.rand(2,1)
lr=0.1
def sigmoid(x):
return 1/(1+np.exp(-x))
def sigmoid_derivative(x):
return x*(1-x)
for _ in range(10000):
h=sigmoid(np.dot(X,w1))
output=sigmoid(np.dot(h,w2))
error=y-output
d_output=error*sigmoid_derivative(out
put)
error_hidden=d_output.dot(w2.T)
d_hidden=error_hidden*sigmoid_deriva
tive(h)
w2+=h.T.dot(d_output)*lr
w1+=X.T.dot(d_hidden)*lr
print("predicted output:")
print(np.round(output))