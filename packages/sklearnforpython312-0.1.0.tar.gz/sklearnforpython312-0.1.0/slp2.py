X=[(0,0),(0,1),(1,0),(1,1)]
y=[0,0,0,1]
w1,w2=0,0
b=0
lr=0.1
for epoch in range(10):
print("epoch:",epoch+1)
for i in range (len(X)):
x1,x2=X[i]
target=y[i]
net=x1*w1+x2*w2+b
out=1 if net >=0 else 0
error=target-out
w1+=lr*error*x1
w2+=lr*error*x2
b+=lr*error
print(X[i],"output:",out,"target:",target)
print("final weight:",w1,w2)
print("final bias:",b)