import numpy as np
def sigmoid(x):
return 1 / (1 + np.exp(-x))
def sigmoid_derivative(x):
return x * (1 - x)
X = np.array([[0,0],[0,1], [1,0], [1,1]])
y = np.array([[0],[0],[0],[1]])
np.random.seed(1)
w1 = np.random.rand(2, 2)
b1 = np.random.rand(1, 2)
w2 = np.random.rand(2, 1)
b2 = np.random.rand(1, 1)
lr = 0.5
epochs = 100000
for i in range(epochs):
h = sigmoid(np.dot(X, w1) + b1)
out = sigmoid(np.dot(h, w2) + b2)
error = y - out
delta2 = error * sigmoid_derivative(out)
delta1 = np.dot(delta2, w2.T) * 
sigmoid_derivative(h)
w2 += np.dot(h.T, delta2) * lr
b2 += np.sum(delta2, axis=0, 
keepdims=True) * lr
w1 += np.dot(X.T, delta1) * lr
b1 += np.sum(delta1, axis=0, 
keepdims=True) * lr
print("Input :", X)
print("Predicted Output :", np.round(out))
print("Actual Output :", y)