import numpy as np
from sklearn.linear_model import 
LinearRegression
import matplotlib.pyplot as plt
tem=np.array([20,22,24,26,28,30,32]).resh
ape(-1,1)
sal=np.array([100,120,150,170,200,230,26
0])
model=LinearRegression()
model.fit(tem,sal)
print("slope(m):",model.coef_[0])
print("intercept(c):",model.intercept_)
new_tem=27
predicted_sales=model.predict([[new_tem]
])
print(f"prdicted ice-cream sales 
at:",predicted_sales)
plt.scatter(tem,sal,label="data points")
plt.plot(tem,model.predict(tem),label="bes
t fit lines")
plt.xlabel("temperature")
plt.ylabel("ice-cream sales")
plt.title("linear regression:temp vs sales")
plt.legend()
plt.show() 