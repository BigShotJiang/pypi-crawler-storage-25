import numpy as np
X=np.array([[0,0],[0,1],[1,0],[1,1]]) 
y=np.array([[0],[1],[1],[0]])
np.random.seed(1)
w1=np.random.rand(2,2)
w2=np.random.rand(2,1)
def sigmoid(x):
return 1/(1+np.exp(-x))
for i in range(10000):
h=sigmoid(np.dot(X,w1))
output=sigmoid(np.dot(h,w2))
print("predicted output:")
print(np.round(output))