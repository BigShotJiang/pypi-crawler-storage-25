from sklearn.datasets import load_iris
from sklearn.model_selection import 
train_test_split
from sklearn.naive_bayes import 
GaussianNB
from sklearn.metrics import 
accuracy_score,classification_report
iris=load_iris()
x=iris.data
y=iris.target
x_train,x_test,y_train,y_test=train_test_spl
it(x,y,test_size=0.4,random_state=42)
nb=GaussianNB()
nb.fit(x_train,y_train)
y_pred=nb.predict(x_test)
acc=accuracy_score(y_test,y_pred)
print("accuracy:",acc*100)
print(classification_report(y_test,y_pred))