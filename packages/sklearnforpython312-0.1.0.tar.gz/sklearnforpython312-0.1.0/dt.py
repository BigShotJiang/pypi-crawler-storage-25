import pandas as pd
from sklearn.datasets import load_iris
from sklearn.tree import 
DecisionTreeClassifier
from sklearn.model_selection import 
train_test_split
from sklearn.metrics import accuracy_score
iris = load_iris()
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = 
train_test_split(X, y, test_size=0.3, 
random_state=42)
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy of Decision Tree classifier:", 
accuracy)
sample = [[5.1, 3.5, 1.4, 0.2]]
prediction = clf.predict(sample)[0]
print(f"Predicted species for sample is: 
{iris.target_names[prediction]}")