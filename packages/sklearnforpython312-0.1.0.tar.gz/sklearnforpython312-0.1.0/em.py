import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
from sklearn.preprocessing import 
StandardScaler
import matplotlib.pyplot as plt
data = pd.read_csv("data.csv")
X = data.values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
k = 2
gmm = GaussianMixture(
n_components=k,
covariance_type='full',
random_state=42
)
gmm.fit(X_scaled)
em_labels = gmm.predict(X_scaled)
print("EM Algorithm cluster labels:")
print(em_labels)
kmeans = KMeans(
n_clusters=k,
random_state=42,
n_init=10
)
kmeans.fit(X_scaled)
kmeans_labels = kmeans.labels_
print("\nK-Means cluster labels:")
print(kmeans_labels)