import numpy as np
import matplotlib.pyplot as p
from sklearn.svm import SVC
X=np.array([
[1,2],[2,3],[3,1],[3,3],[6,6],[7,8],[8,6],[9,
7]
])
y=np.array([0,0,0,0,1,1,1,1])
model=SVC(kernel='rbf',gamma='scale',C
=10)
model.fit(X,y)
p.scatter(X[:,0], X[:,1], c=y, 
cmap='coolwarm', s=80)
p.xlabel("feature 1:")
p.ylabel("feature 2:")
p.title("non linear svm:")
ax=p.gca()
xlim=ax.get_xlim()
ylim=ax.get_ylim()
xx=np.linspace(xlim[0],xlim[1],200)
yy=np.linspace(xlim[0],xlim[1],200)
YY,XX=np.meshgrid(yy,xx)
xy=np.vstack([XX.ravel(),YY.ravel()]).T
Z=model.decision_function(xy).reshape(X
X.shape)
ax.contour(XX,YY,Z,levels=[0],linewidths
=2)
p.show()