from sklearn.datasets import load_iris
from sklearn.neighbors import 
KNeighborsClassifier
from sklearn.model_selection import 
train_test_split
iris = load_iris()
X = iris.data
y = iris.target
target_names = iris.target_names
X_train,X_test,y_train,y_test=train_test_s
plit(X,y,test_size=0.3,random_state=42)
knn = 
KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train,y_train)
y_pred=knn.predict(X_test)
print("correct prediction:")
for i in range(len(y_test)):
if y_test[i]==y_pred[i]:
print(f"sample{i}:actual={target_nam
es[y_test[i]]},"
f"predicted={target_names[y_pred[i]]
}")