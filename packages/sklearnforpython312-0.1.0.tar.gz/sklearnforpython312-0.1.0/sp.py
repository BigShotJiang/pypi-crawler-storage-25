from sklearn.feature_extraction.text import 
CountVectorizer
from sklearn.naive_bayes import 
MultinomialNB
emails=["hello,how are you today?","click 
here for a prize","meeing tomorrow at 10 
am","urgent:your account is been 
suspend,click the link to fix"]
labels=[0,1,0,1]
new_email="get a huge discount and amzing 
offer toady!"
x=CountVectorizer().fit_transform(emails)
model=MultinomialNB().fit(x,labels)
pred=model.predict(CountVectorizer().fit(ema
ils).transform([new_email]))
print(pred)