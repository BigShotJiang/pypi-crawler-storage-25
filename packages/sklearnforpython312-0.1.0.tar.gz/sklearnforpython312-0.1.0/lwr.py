import numpy as np
import math
def lwr(x, y, x0, tau):
numerator = 0
denominator = 0
for i in range(len(x))
wi = math.exp(-((x[i] - x0) ** 2) / (2 * tau 
** 2))
numerator += wi * y[i]
denominator += wi
return numerator / denominator
x = np.array([1, 2, 8])
y = np.array([2, 4, 6])
x0 = 2.5
tau = 2.5
y_pred = lwr(x, y, x0, tau)
print("Predicted value at x =", x0, "is", y_pred)