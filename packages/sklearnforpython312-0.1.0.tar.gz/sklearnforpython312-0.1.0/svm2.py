import numpy as np
import matplotlib.pyplot as p
from sklearn.svm import SVC
X = 
np.array([[2,400],[3,450],[5,300],[6,520],[
7,580],[8,220]])
y = np.array([0,0,0,0,1,1])
model = SVC(kernel='linear')
model.fit(X, y)
p.scatter(X[:,0], X[:,1], c=y, 
cmap='coolwarm', s=80)
p.xlabel("annual income (in lakhs)")
p.ylabel("credit score")
p.title("svm for loan approval")
w = model.coef_[0]
b = model.intercept_[0]
x_vals = np.linspace(1, 10, 100)
y_vals = -(w[0]*x_vals + b) / w[1]
p.plot(x_vals, y_vals, 'k--', linewidth=2)
p.show()