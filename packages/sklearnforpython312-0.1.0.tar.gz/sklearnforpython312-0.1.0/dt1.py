import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.tree import 
DecisionTreeClassifier,plot_tree
iris=load_iris()
X,y=iris.data,iris.target
df=DecisionTreeClassifier().fit(X,y)
plt.figure(figsize=(10,8))
plot_tree(df,filled=True,feature_names=iris.fe
ature_names,class_names=iris.target_names)
plt.show()