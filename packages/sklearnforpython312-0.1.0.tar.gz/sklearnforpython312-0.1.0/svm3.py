import numpy as np
import matplotlib.pyplot as p
from sklearn.svm import SVC
from mpl_toolkits.mplot3d import axes3d
x = 
np.array([[30,120,180],[35,125,190],[40,1
30,200],[45,135,210],[50,150,240],[55,155
,240]])
y = np.array([0,0,0,0,1,1])
model = SVC(kernel='linear')
model.fit(x, y)
w = model.coef_[0]
b = model.intercept_[0]
fig=p.figure()
ax=fig.add_subplot(111,projection="3d")
ax.scatter(x[y==0,0],x[y==0,1],x[y==0,2],l
abel='no disease')
ax.scatter(x[y==1,0],x[y==1,1],x[y==1,2],l
abel='disease')
ax.set_xlabel('age')
ax.set_ylabel('bp')
ax.set_zlabel('ch')
ax.set_title("3 feature svm")
p.show()
p.legend()