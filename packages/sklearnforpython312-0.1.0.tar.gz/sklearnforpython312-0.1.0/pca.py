import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
data = pd.read_csv("data.csv")
X = data.values
X_meaned = X - np.mean(X, axis=0)
cov_matrix = np.cov(X_meaned.T)
eigen_values, eigen_vectors = 
np.linalg.eig(cov_matrix)
idx = np.argsort(eigen_values)[::-1]
eigen_vectors = eigen_vectors[:, idx]
eigen_values = eigen_values[idx]
k = 1
principal_components = eigen_vectors[:, :k]
X_pca = X_meaned @ principal_components
print("Reduced Data after PCA:")
print(X_pca)
plt.scatter(X_pca, np.zeros_like(X_pca))
plt.xlabel("Principal Component 1")
plt.title("PCA Reduced Data")
plt.tight_layout()
plt.show()