from sklearn.datasets import load_iris
from sklearn.neighbors import 
KNeighborsClassifier
iris = load_iris()
X = iris.data
y = iris.target
knn = 
KNeighborsClassifier(n_neighbors=3)
knn.fit(X, y)
pred = knn.predict(X)
print("Correct predictions:")
for i in range(len(y)):
if y[i] == pred[i]:
print(i, y[i], pred[i])
print("\nWrong predictions:")
for i in range(len(y)):
if y[i] != pred[i]:
print(i, y[i], pred[i])