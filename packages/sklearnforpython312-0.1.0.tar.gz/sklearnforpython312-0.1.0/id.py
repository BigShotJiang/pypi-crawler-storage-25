import math

def entropy(data):
    total = len(data)
    yes = data.count('yes')
    no = data.count('no')
    if yes == 0 or no == 0:
        return 0
    p_yes = yes / total
    p_no = no / total
    return -p_yes * math.log2(p_yes) - p_no * math.log2(p_no)

def info_gain(data, attr_data):
    total_entropy = entropy(data)
    gain = total_entropy
    for value in set(attr_data):
        subset = [data[i] for i in range(len(data)) if attr_data[i] == value]
        gain -= (len(subset) / len(data)) * entropy(subset)
    return gain

play = ['no', 'no', 'yes', 'yes']
outlook = ['sunny', 'sunny', 'overcast', 'rain']
temp = ['hot', 'hot', 'hot', 'mild']
wind = ['weak', 'strong', 'weakj', 'weak']
humidity = ['high', 'high', 'high', 'high']

print("entropy:", entropy(play))
print("information gain(outlook):", info_gain(play, outlook))
print("information gain(temp):", info_gain(play, temp))
print("information gain(wind):", info_gain(play, wind))
print("information gain(humidity):", info_gain(play, humidity))