import numpy as np 
from sklearn.linear_model import 
LogisticRegression
import matplotlib.pyplot as plt
tem=np.array([20,22,24,26,28,30,32]).resh
ape(-1,1)
sal=np.array([100,120,150,170,200,230,26
0])
y=(sal>200).astype(int)
model=LogisticRegression()
model.fit(tem,y)
new_tem=27
pred=model.predict([[new_tem]])[0]
print("temp:",new_tem)
print("high sales:",pred)