"""Metadata migration helpers for legacy ds-crawler datasets."""

from __future__ import annotations

import logging
from copy import deepcopy
from pathlib import Path
from typing import Any

from ._dataset_contract import DATASET_CONTRACT_VERSION, parse_dataset_head
from .artifacts import (
    DATASET_SPLIT_KIND,
    build_index_artifact,
    build_split_artifact,
)
from .config import (
    CONFIG_FILENAME,
    CRAWLER_CONFIG_KIND,
    CRAWLER_CONFIG_VERSION,
    DatasetConfig,
)
from .validation import DATASET_INDEX_KIND, DATASET_INDEX_VERSION, validate_output
from ._version import get_package_version
from .zip_utils import (
    DATASET_HEAD_FILENAME,
    OUTPUT_FILENAME,
    METADATA_DIR,
    is_zip_path,
    list_metadata_json_filenames,
    read_metadata_json,
    write_metadata_json_batch,
    write_metadata_json,
)


_LEGACY_STRUCTURAL_KEYS = frozenset({
    "dataset_contract_version",
    "name",
    "path",
    "type",
    "basename_regex",
    "id_regex",
    "path_regex",
    "id_regex_join_char",
    "hierarchy_regex",
    "named_capture_group_value_separator",
    "flat_ids_unique",
    "id_override",
    "path_filters",
    "output_json",
    "file_extensions",
    "sampled",
    "dataset",
})
_LEGACY_OUTPUT_FILENAME = "output.json"


def _get_logger(logger: logging.Logger | None) -> logging.Logger:
    return logger or logging.getLogger(__name__)


def _slugify(value: str) -> str:
    cleaned = "".join(
        ch.lower() if ch.isalnum() else "_"
        for ch in value.strip()
    )
    cleaned = "_".join(token for token in cleaned.split("_") if token)
    return cleaned or "dataset"


def _unwrap_single_output(value: Any, context: str) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, list):
        if len(value) != 1:
            raise ValueError(f"{context} must contain exactly one dataset entry")
        value = value[0]
    if not isinstance(value, dict):
        raise ValueError(f"{context} must be an object")
    return value


def _is_new_config(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and isinstance(value.get("contract"), dict)
        and value["contract"].get("kind") == CRAWLER_CONFIG_KIND
    )


def _is_new_output(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and isinstance(value.get("contract"), dict)
        and value["contract"].get("kind") == DATASET_INDEX_KIND
    )


def _is_new_split(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and isinstance(value.get("contract"), dict)
        and value["contract"].get("kind") == DATASET_SPLIT_KIND
    )


def _legacy_properties(value: dict[str, Any]) -> dict[str, Any]:
    raw_properties = value.get("properties", {})
    if raw_properties is None:
        raw_properties = {}
    if not isinstance(raw_properties, dict):
        raise ValueError("legacy properties must be an object")

    properties = dict(raw_properties)
    for key in ("meta", "euler_train", "euler_loading"):
        if key in value and key not in properties:
            properties[key] = value[key]

    for key, item in value.items():
        if key in _LEGACY_STRUCTURAL_KEYS or key in properties:
            continue
        properties[key] = item
    return properties


def _normalize_legacy_addons(
    properties: dict[str, Any],
    *,
    modality_key: str,
) -> dict[str, dict[str, Any]]:
    addons: dict[str, dict[str, Any]] = {}
    for key in sorted(list(properties.keys())):
        if key not in ("euler_train", "euler_loading") and not key.startswith("euler_"):
            continue
        value = properties.pop(key)
        if not isinstance(value, dict):
            continue
        payload = dict(value)
        payload.setdefault("version", DATASET_CONTRACT_VERSION)
        legacy_modality_type = payload.pop("modality_type", None)
        if legacy_modality_type is not None and legacy_modality_type != modality_key:
            raise ValueError(
                f"Cannot migrate {key}.modality_type={legacy_modality_type!r} "
                f"for modality.key={modality_key!r}"
            )
        addons[key] = payload
    return addons


def _build_head_from_legacy(
    dataset_path: Path,
    *,
    legacy_config: dict[str, Any] | None,
    legacy_output: dict[str, Any] | None,
) -> dict[str, Any]:
    source = legacy_output or legacy_config
    if source is None:
        raise ValueError("Cannot migrate dataset head without legacy metadata")

    properties = _legacy_properties(source)
    name = source.get("name") or dataset_path.stem
    if not isinstance(name, str) or not name:
        raise ValueError("Legacy metadata is missing a usable name")

    modality_key = source.get("type")
    if not isinstance(modality_key, str) or not modality_key:
        euler_train = properties.get("euler_train")
        if isinstance(euler_train, dict):
            maybe_type = euler_train.get("modality_type")
            if isinstance(maybe_type, str) and maybe_type:
                modality_key = maybe_type
    if not isinstance(modality_key, str) or not modality_key:
        raise ValueError("Legacy metadata is missing a usable modality type")

    meta = properties.pop("meta", None)

    dataset_attributes: dict[str, Any] = {}
    explicit_attributes = properties.pop("dataset", None)
    if explicit_attributes is not None:
        if not isinstance(explicit_attributes, dict):
            raise ValueError("Legacy properties.dataset must be an object when present")
        dataset_attributes.update(explicit_attributes)
    dataset_attributes.update(properties)

    addons = _normalize_legacy_addons(dataset_attributes, modality_key=modality_key)

    return parse_dataset_head(
        {
            "contract": {
                "kind": "dataset_head",
                "version": DATASET_CONTRACT_VERSION,
            },
            "dataset": {
                "id": _slugify(name),
                "name": name,
                "attributes": dataset_attributes,
            },
            "modality": {
                "key": modality_key,
                "meta": meta,
            },
            "addons": addons,
        },
        context="dataset_head",
    ).to_mapping()


def _relativize_source_path(dataset_path: Path, value: Any) -> str:
    if not isinstance(value, str) or not value:
        return "."
    path = Path(value)
    if not path.is_absolute():
        return value
    try:
        rel = path.relative_to(dataset_path)
    except ValueError:
        return value
    rel_str = str(rel)
    return rel_str or "."


def _build_crawler_config_from_legacy(
    dataset_path: Path,
    *,
    head_file: str,
    legacy_config: dict[str, Any] | None,
    legacy_output: dict[str, Any] | None,
) -> dict[str, Any]:
    source = legacy_config or legacy_output
    if source is None:
        raise ValueError("Cannot migrate crawler config without legacy metadata")

    indexing: dict[str, Any] = {
        "constraints": {
            "flat_ids_unique": bool(source.get("flat_ids_unique", False)),
        },
    }
    id_regex = source.get("id_regex")
    has_id_regex = isinstance(id_regex, str) and bool(id_regex)
    if has_id_regex:
        indexing["id"] = {
            "regex": id_regex,
            "join_char": source.get("id_regex_join_char", "+"),
        }

    hierarchy_regex = source.get("hierarchy_regex")
    if isinstance(hierarchy_regex, str) and hierarchy_regex:
        indexing["hierarchy"] = {"regex": hierarchy_regex}
        separator = source.get("named_capture_group_value_separator")
        if isinstance(separator, str) and separator:
            indexing["hierarchy"]["separator"] = separator

    properties_cfg: dict[str, Any] = {}
    path_regex = source.get("path_regex")
    if isinstance(path_regex, str) and path_regex:
        properties_cfg["path"] = {"regex": path_regex}
    basename_regex = source.get("basename_regex")
    if isinstance(basename_regex, str) and basename_regex:
        properties_cfg["basename"] = {"regex": basename_regex}
    if properties_cfg:
        indexing["properties"] = properties_cfg

    files_cfg: dict[str, Any] = {}
    file_extensions = source.get("file_extensions")
    if isinstance(file_extensions, list) and file_extensions:
        files_cfg["extensions"] = list(file_extensions)
    path_filters = source.get("path_filters")
    if isinstance(path_filters, dict) and path_filters:
        files_cfg["path_filters"] = deepcopy(path_filters)
    if files_cfg:
        indexing["files"] = files_cfg

    id_override = source.get("id_override")
    if has_id_regex and isinstance(id_override, str) and id_override:
        indexing["id"]["override"] = id_override

    source_cfg: dict[str, Any] = {
        "path": _relativize_source_path(dataset_path, source.get("path")),
    }
    legacy_output_json = legacy_config.get("output_json") if legacy_config else None
    if isinstance(legacy_output_json, str) and legacy_output_json:
        source_cfg["prebuilt_index_file"] = legacy_output_json
    elif legacy_output is not None and not has_id_regex:
        source_cfg["prebuilt_index_file"] = OUTPUT_FILENAME

    config = {
        "contract": {
            "kind": CRAWLER_CONFIG_KIND,
            "version": CRAWLER_CONFIG_VERSION,
        },
        "head_file": head_file,
        "source": source_cfg,
        "indexing": indexing,
    }
    return config


def _strip_legacy_camera_fields(node: Any) -> Any:
    if not isinstance(node, dict):
        return node

    result: dict[str, Any] = {}
    for key, value in node.items():
        if key in {"camera_intrinsics", "camera_extrinsics"}:
            continue
        if key == "children" and isinstance(value, dict):
            result[key] = {
                child_key: _strip_legacy_camera_fields(child_value)
                for child_key, child_value in value.items()
            }
        else:
            result[key] = deepcopy(value)
    return result


def _build_output_from_legacy(
    *,
    head: dict[str, Any],
    legacy_config: dict[str, Any] | None,
    legacy_output: dict[str, Any],
) -> dict[str, Any]:
    if "dataset" not in legacy_output or not isinstance(legacy_output["dataset"], dict):
        raise ValueError("Legacy output.json must contain a dataset object")

    output = {
        "contract": {
            "kind": DATASET_INDEX_KIND,
            "version": DATASET_INDEX_VERSION,
        },
        "head_file": DATASET_HEAD_FILENAME,
        "head": deepcopy(head),
        "generator": {
            "name": "ds_crawler",
            "version": get_package_version(),
        },
        "indexing": _build_crawler_config_from_legacy(
            Path("."),
            head_file=DATASET_HEAD_FILENAME,
            legacy_config=legacy_config,
            legacy_output=legacy_output,
        )["indexing"],
        "execution": {},
        "index": _strip_legacy_camera_fields(legacy_output["dataset"]),
    }
    sampled = legacy_output.get("sampled")
    if isinstance(sampled, int) and sampled > 0:
        output["execution"]["sampled"] = sampled
    if not output["execution"]:
        output["execution"] = {}
    return output


def _read_metadata_mapping(
    dataset_root: Path,
    filename: str,
    *,
    allowed_filenames: set[str] | None = None,
) -> dict[str, Any] | None:
    if allowed_filenames is not None and filename not in allowed_filenames:
        return None
    return _unwrap_single_output(
        read_metadata_json(dataset_root, filename),
        filename,
    )


def _require_metadata_dir_entries(
    dataset_root: Path,
    *,
    logger: logging.Logger,
) -> set[str]:
    metadata_filenames = set(list_metadata_json_filenames(dataset_root))
    if not metadata_filenames:
        message = (
            f"No metadata JSON files found under {METADATA_DIR}/ at {dataset_root}"
        )
        logger.warning(message)
        raise FileNotFoundError(message)
    if (
        CONFIG_FILENAME not in metadata_filenames
        and _LEGACY_OUTPUT_FILENAME not in metadata_filenames
    ):
        message = (
            f"Metadata under {METADATA_DIR}/ at {dataset_root} must include "
            f"{CONFIG_FILENAME} or {_LEGACY_OUTPUT_FILENAME}"
        )
        logger.warning(message)
        raise FileNotFoundError(message)
    return metadata_filenames


def _iter_zip_paths(folder_path: Path, *, recursive: bool) -> list[Path]:
    if not folder_path.is_dir():
        raise NotADirectoryError(f"Not a directory: {folder_path}")

    candidates = folder_path.rglob("*") if recursive else folder_path.iterdir()
    return sorted(
        path
        for path in candidates
        if path.is_file() and path.suffix.lower() == ".zip"
    )


def migrate_dataset_metadata(
    dataset_path: str | Path,
    *,
    write_output: bool = True,
    logger: logging.Logger | None = None,
    require_metadata_dir: bool = False,
) -> dict[str, Any]:
    """Rewrite one legacy dataset's metadata into the new schema."""
    logger = _get_logger(logger)
    dataset_root = Path(dataset_path)
    logger.info("Migrating dataset metadata for %s", dataset_root)

    allowed_filenames: set[str] | None = None
    if require_metadata_dir:
        allowed_filenames = _require_metadata_dir_entries(
            dataset_root,
            logger=logger,
        )
        logger.debug(
            "Found %s metadata files for %s: %s",
            METADATA_DIR,
            dataset_root,
            ", ".join(sorted(allowed_filenames)),
        )

    raw_config = _read_metadata_mapping(
        dataset_root,
        CONFIG_FILENAME,
        allowed_filenames=allowed_filenames,
    )
    raw_output = _read_metadata_mapping(
        dataset_root,
        _LEGACY_OUTPUT_FILENAME,
        allowed_filenames=allowed_filenames,
    )

    legacy_config = None if _is_new_config(raw_config) else raw_config
    legacy_output = None if _is_new_output(raw_output) else raw_output

    if legacy_config is None and legacy_output is None:
        message = (
            f"No legacy {CONFIG_FILENAME} or {_LEGACY_OUTPUT_FILENAME} found at {dataset_root}"
        )
        logger.warning(message)
        raise FileNotFoundError(message)

    head = _build_head_from_legacy(
        dataset_root,
        legacy_config=legacy_config,
        legacy_output=legacy_output,
    )
    config = _build_crawler_config_from_legacy(
        dataset_root,
        head_file=DATASET_HEAD_FILENAME,
        legacy_config=legacy_config,
        legacy_output=legacy_output,
    )
    dataset_config = DatasetConfig.from_dict(
        config,
        dataset_root=dataset_root,
        dataset_head=head,
    )

    output_written = False
    metadata_updates: dict[str, Any] = {
        DATASET_HEAD_FILENAME: head,
        CONFIG_FILENAME: config,
    }
    if legacy_output is not None and write_output:
        output = _build_output_from_legacy(
            head=head,
            legacy_config=legacy_config,
            legacy_output=legacy_output,
        )
        validate_output(output)
        metadata_updates[OUTPUT_FILENAME] = build_index_artifact(output)
        output_written = True

    migrated_splits: list[str] = []
    for filename in list_metadata_json_filenames(dataset_root):
        if not (
            filename.startswith("split_")
            and filename.endswith(".json")
        ):
            continue
        node = read_metadata_json(dataset_root, filename)
        if node is None:
            continue
        if _is_new_split(node):
            metadata_updates[filename] = node
            migrated_splits.append(filename)
            continue

        migrated_node = _strip_legacy_camera_fields(node)
        split_name = filename[len("split_"):-len(".json")]
        metadata_updates[filename] = build_split_artifact(
            {
                "index": migrated_node,
                "generator": {
                    "name": "ds_crawler",
                    "version": get_package_version(),
                },
            },
            split_name=split_name,
        )
        migrated_splits.append(filename)

    if (
        migrated_splits
        and not write_output
        and dataset_config.prebuilt_index_file is not None
        and Path(dataset_config.prebuilt_index_file).name == OUTPUT_FILENAME
    ):
        raise ValueError(
            "Cannot migrate split metadata without writing index.json for a "
            "prebuilt-index dataset"
        )

    if is_zip_path(dataset_root):
        logger.debug(
            "Rewriting %s once with %d metadata files",
            dataset_root,
            len(metadata_updates),
        )
        write_metadata_json_batch(dataset_root, metadata_updates)
    else:
        for filename, payload in metadata_updates.items():
            logger.debug("Writing %s for %s", filename, dataset_root)
            write_metadata_json(dataset_root, filename, payload)

    result = {
        "path": str(dataset_root),
        "wrote_head": True,
        "wrote_config": True,
        "wrote_output": output_written,
        "migrated_splits": migrated_splits,
    }
    logger.info(
        "Migrated dataset metadata for %s (output=%s, splits=%d)",
        dataset_root,
        output_written,
        len(migrated_splits),
    )
    return result


def migrate_inline_splits(
    dataset_path: str | Path,
    *,
    logger: logging.Logger | None = None,
    require_metadata_dir: bool = False,
) -> dict[str, Any]:
    """Migrate only split files for a partially-migrated dataset.

    Requires that index.json already exists in the new schema format,
    indicating that the core metadata files (dataset-head.json,
    ds-crawler.json, index.json) have already been migrated.
    """
    logger = _get_logger(logger)
    dataset_root = Path(dataset_path)
    logger.info("Migrating inline splits for %s", dataset_root)

    if require_metadata_dir:
        _require_metadata_dir_entries(dataset_root, logger=logger)

    raw_output = read_metadata_json(dataset_root, OUTPUT_FILENAME)
    if raw_output is None or not _is_new_output(raw_output):
        raise FileNotFoundError(
            f"index.json not found or not yet migrated at {dataset_root}; "
            "run full migration first"
        )

    migrated_splits: list[str] = []
    metadata_updates: dict[str, Any] = {}

    for filename in list_metadata_json_filenames(dataset_root):
        if not (
            filename.startswith("split_")
            and filename.endswith(".json")
        ):
            continue
        node = read_metadata_json(dataset_root, filename)
        if node is None:
            continue
        if _is_new_split(node):
            migrated_splits.append(filename)
            continue

        migrated_node = _strip_legacy_camera_fields(node)
        split_name = filename[len("split_"):-len(".json")]
        metadata_updates[filename] = build_split_artifact(
            {
                "index": migrated_node,
                "generator": {
                    "name": "ds_crawler",
                    "version": get_package_version(),
                },
            },
            split_name=split_name,
        )
        migrated_splits.append(filename)

    if is_zip_path(dataset_root):
        if metadata_updates:
            write_metadata_json_batch(dataset_root, metadata_updates)
    else:
        for filename, payload in metadata_updates.items():
            logger.debug("Writing %s for %s", filename, dataset_root)
            write_metadata_json(dataset_root, filename, payload)

    result = {
        "path": str(dataset_root),
        "migrated_splits": migrated_splits,
    }
    logger.info(
        "Migrated inline splits for %s (splits=%d)",
        dataset_root,
        len(migrated_splits),
    )
    return result


def migrate_dataset_zip(
    zip_path: str | Path,
    *,
    write_output: bool = True,
    logger: logging.Logger | None = None,
) -> dict[str, Any]:
    """Migrate one dataset archive in-place.

    ZIP migrations are strict: legacy metadata must already live under
    ``.ds_crawler/`` inside the archive.
    """
    logger = _get_logger(logger)
    archive_path = Path(zip_path)
    if archive_path.suffix.lower() != ".zip":
        raise ValueError(f"Dataset archive must be a .zip file, got: {archive_path}")
    if not archive_path.is_file():
        raise FileNotFoundError(f"Dataset archive not found: {archive_path}")
    if not is_zip_path(archive_path):
        raise ValueError(f"Dataset archive is not a readable .zip file: {archive_path}")

    logger.info("Migrating dataset archive %s", archive_path)
    return migrate_dataset_metadata(
        archive_path,
        write_output=write_output,
        logger=logger,
        require_metadata_dir=True,
    )


def migrate_dataset_zips_in_folder(
    folder_path: str | Path,
    *,
    recursive: bool = True,
    write_output: bool = True,
    logger: logging.Logger | None = None,
) -> dict[str, Any]:
    """Scan a folder for dataset ZIPs and attempt migration on each archive."""
    logger = _get_logger(logger)
    folder = Path(folder_path)
    zip_paths = _iter_zip_paths(folder, recursive=recursive)

    logger.info(
        "Scanning %s for dataset archives (%s)",
        folder,
        "recursive" if recursive else "top-level",
    )
    if not zip_paths:
        logger.warning("No .zip archives found in %s", folder)

    migrated: list[dict[str, Any]] = []
    failed: list[dict[str, str]] = []

    for archive_path in zip_paths:
        logger.info("Attempting archive migration for %s", archive_path)
        try:
            result = migrate_dataset_zip(
                archive_path,
                write_output=write_output,
                logger=logger,
            )
        except Exception as exc:
            logger.warning("Archive migration failed for %s: %s", archive_path, exc)
            failed.append({
                "path": str(archive_path),
                "error": str(exc),
            })
            continue
        migrated.append(result)

    logger.info(
        "Archive migration scan complete for %s (scanned=%d, migrated=%d, failed=%d)",
        folder,
        len(zip_paths),
        len(migrated),
        len(failed),
    )
    return {
        "path": str(folder),
        "recursive": recursive,
        "scanned": len(zip_paths),
        "migrated": migrated,
        "failed": failed,
    }
