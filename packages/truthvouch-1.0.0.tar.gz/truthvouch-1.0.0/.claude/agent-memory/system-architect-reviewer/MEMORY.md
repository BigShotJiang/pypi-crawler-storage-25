# Memory Index

## SDK Architecture
- [Plan 397 Python SDK consolidation review](review_plan397_sdk_consolidation.md) — Consolidated SDK passes review; transport/rest.py exception fields unpopulated
