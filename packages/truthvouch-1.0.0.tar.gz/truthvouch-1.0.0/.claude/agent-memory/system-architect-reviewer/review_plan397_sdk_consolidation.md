---
name: Plan 397 SDK Consolidation Review
description: Python SDK consolidation review findings — transport/rest.py exception attributes never populated, docstring stale class name
type: project
---

Plan 397 merged two Python SDKs (sdk/ governance guards + src/python-sdk/ gateway proxy) into a single `truthvouch` package.

**Pass 2 review (2026-04-02):** 0 critical, 3 warnings, 3 suggestions. All 414 tests pass.

Key warnings:
- `transport/rest.py` constructs `QuotaExceededError` without populating `retry_after_seconds` (always None)
- `transport/rest.py` constructs `UpstreamProviderError` without populating `upstream_status_code` (always None)
- Test docstring in `tests/gateway/test_client.py` still says "TruthVouchClient"

**Why:** These fields exist on the exception classes and are documented, but the only code path that raises them (the HTTP transport) never extracts the values from the response body.

**How to apply:** When fixing, reuse the already-parsed `body` variable in `_raise_for_status` rather than re-parsing JSON. This is a quick fix localized to one method.

Package structure validated:
- Top-level: TruthVouch (gateway proxy), GovernanceReport, 12 exceptions
- governance/: GovernanceClient (sync), AsyncGovernanceClient (async), guards, adapters
- providers/: openai, anthropic, google facades
- transport/rest.py, resilience.py, streaming.py, batch.py
- telemetry/: audit.py (sync+async buffers), otel.py (OTel+Prometheus, optional)
- API key prefixes: `tv_` for gateway, `vt_live_` for governance
