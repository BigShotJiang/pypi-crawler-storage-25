"""Shared utility functions for the TruthVouch SDK."""

from __future__ import annotations

from truthvouch.exceptions import AuthenticationError

_API_KEY_PREFIX = "vt_live_"


def validate_api_key(api_key: str) -> None:
    """Validate that the API key has the expected prefix.

    Args:
        api_key: API key to validate.

    Raises:
        AuthenticationError: If the key does not start with ``vt_live_``.
    """
    if not api_key or not api_key.startswith(_API_KEY_PREFIX):
        raise AuthenticationError(
            f"Invalid API key format. Keys must start with '{_API_KEY_PREFIX}'. "
            "Generate a key at https://app.truthvouch.ai/settings/api-keys"
        )
