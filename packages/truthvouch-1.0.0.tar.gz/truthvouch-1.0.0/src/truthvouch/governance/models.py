"""Shared dataclasses for the TruthVouch governance SDK."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from truthvouch._version import __version__


class GuardVerdict(Enum):
    """Verdict returned by a guard evaluation.

    Values:
        PASS: Text is clean; processing continues.
        FLAG: Text has suspicious content; processing continues with a warning.
        BLOCK: Text is unsafe; processing must halt.
    """

    PASS = "pass"
    FLAG = "flag"
    BLOCK = "block"


@dataclass
class GuardResult:
    """Result of a single guard evaluation.

    Attributes:
        guard_name: Identifier of the guard that produced this result.
        verdict: The guard's PASS / FLAG / BLOCK decision.
        details: Guard-specific metadata (matched patterns, scores, etc.).
        duration_ms: Wall-clock time taken to evaluate this guard, in ms.
        message: Actionable human-readable explanation of the verdict.
    """

    guard_name: str
    verdict: GuardVerdict
    details: dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0
    message: str = ""


@dataclass
class EvaluationResult:
    """Aggregated result of running all guards against a piece of text.

    Attributes:
        blocked: True if any guard returned BLOCK.
        flagged: True if any guard returned FLAG (and none returned BLOCK).
        block_reasons: Human-readable messages from guards that blocked.
        flag_reasons: Human-readable messages from guards that flagged.
        guard_results: All individual guard results in evaluation order.
        direction: Either "input" or "output".
        total_duration_ms: Total wall-clock time for all guard evaluations.
    """

    blocked: bool
    flagged: bool
    block_reasons: list[str]
    flag_reasons: list[str]
    guard_results: list[GuardResult]
    direction: str
    total_duration_ms: float = 0.0


@dataclass
class Event:
    """A telemetry event to be pushed to the audit trail.

    Field names and values match the .NET ``SdkTelemetryEventDto`` contract.

    Attributes:
        event_type: DTO event type — one of ``llm_call``, ``guard_triggered``,
            ``tool_call``, ``bootstrap``, ``error``.
        direction: ``"input"`` or ``"output"`` (SDK-internal; not sent).
        guard_verdict: Final verdict string for the DTO — ``"pass"``, ``"flag"``,
            or ``"block"``.
        model: LLM model identifier provided by the caller.
        provider: LLM provider name (e.g. ``"openai"``, ``"anthropic"``).
        guards_triggered: List of guard name strings that flagged or blocked.
        input_tokens: Number of input tokens consumed (0 if unknown).
        output_tokens: Number of output tokens consumed (0 if unknown).
        estimated_cost_usd: Estimated cost in USD (0.0 if unknown).
        duration_ms: Total evaluation duration in milliseconds.
        framework: Orchestration framework name (e.g. ``"langgraph"``).
        sdk_version: SDK version string.
        timestamp: Unix timestamp (seconds) when the event was created (internal only;
            not included in to_dict() output — not part of the .NET DTO).
        metadata: Additional caller-supplied key/value pairs.
    """

    event_type: str
    direction: str
    guard_verdict: str
    model: str
    guards_triggered: list[str] = field(default_factory=list)
    provider: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    estimated_cost_usd: float = 0.0
    duration_ms: float = 0.0
    framework: str = ""
    sdk_version: str = field(default_factory=lambda: __version__)
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)

    # Back-compat alias so existing code that reads .verdict still works.
    @property
    def verdict(self) -> str:
        """Alias for guard_verdict (back-compat).

        Returns:
            The guard verdict string.
        """
        return self.guard_verdict

    def to_dict(self) -> dict[str, Any]:
        """Serialize event to a camelCase JSON-compatible dict.

        Produces the shape expected by the .NET ``SdkTelemetryEventDto``.
        The ``timestamp`` field is intentionally omitted — it is not part of
        the .NET DTO and would inflate every telemetry payload unnecessarily.

        Returns:
            Dictionary representation suitable for HTTP POST body.
        """
        return {
            "eventType": self.event_type,
            "model": self.model,
            "provider": self.provider,
            "inputTokens": self.input_tokens,
            "outputTokens": self.output_tokens,
            "estimatedCostUsd": self.estimated_cost_usd,
            "durationMs": int(self.duration_ms),
            "guardsTriggered": self.guards_triggered,
            "guardVerdict": self.guard_verdict,
            "framework": self.framework,
            "sdkVersion": self.sdk_version,
            "metadata": self.metadata,
        }


@dataclass
class GuardContext:
    """Contextual information passed to each guard during evaluation.

    Attributes:
        direction: "input" or "output".
        model: LLM model identifier.
        config: The current ClientConfig from bootstrap.
        metadata: Caller-supplied extra context.
    """

    direction: str
    model: str
    config: Any  # ClientConfig — avoids circular import
    metadata: dict[str, Any] = field(default_factory=dict)
