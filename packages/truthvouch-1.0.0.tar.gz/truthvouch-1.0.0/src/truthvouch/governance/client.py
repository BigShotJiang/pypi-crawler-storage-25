"""GovernanceClient — synchronous entry point for the TruthVouch governance SDK."""

from __future__ import annotations

import logging
import threading
import time
from typing import Any

from truthvouch._utils import validate_api_key as _validate_api_key
from truthvouch.governance.config import ClientConfig, parse_bootstrap_response
from truthvouch.exceptions import AuthenticationError
from truthvouch.governance.guards.banned_phrases import BannedPhrasesGuard
from truthvouch.governance.guards.base import Guard
from truthvouch.governance.guards.cost import CostGuard
from truthvouch.governance.guards.injection import InjectionGuard
from truthvouch.governance.guards.pii_regex import PiiRegexGuard
from truthvouch.governance.guards.pii_remote import PiiRemoteGuard
from truthvouch.governance.guards.truth import TruthGuard
from truthvouch.governance.http import BOOTSTRAP_TIMEOUT, HttpClient
from truthvouch.governance.models import EvaluationResult, Event, GuardContext, GuardResult, GuardVerdict
from truthvouch.telemetry.audit import AuditBuffer

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "https://api.truthvouch.ai"


class GovernanceClient:
    """Synchronous TruthVouch governance client.

    Evaluates text (LLM inputs and outputs) through a layered guard pipeline:
    local guards run first (fast, in-process), remote guards only run if all
    local guards pass.

    Thread-safe: multiple threads may call evaluate_input/evaluate_output
    concurrently.  Guards are stateless; the config reference is updated
    atomically.

    Args:
        api_key: TruthVouch API key (must start with ``vt_live_``).
        base_url: API base URL. Defaults to ``https://api.truthvouch.ai``.
        policy_refresh_interval_s: Seconds between background policy refreshes.
            0 disables the refresh loop.
        timeout_s: Default request timeout in seconds (unused directly;
            individual guards use GUARD_TIMEOUT / BOOTSTRAP_TIMEOUT).

    Example::

        client = GovernanceClient(api_key="vt_live_abc123...")
        result = client.evaluate_input("My SSN is 123-45-6789", model="gpt-4o")
        if result.blocked:
            print(result.block_reasons)
        client.shutdown()

    Context manager usage::

        with GovernanceClient(api_key="vt_live_abc123...") as client:
            result = client.evaluate_output(llm_response, model="gpt-4o")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        policy_refresh_interval_s: int = 300,
    ) -> None:
        """Initialise the client.

        Args:
            api_key: TruthVouch API key.
            base_url: API base URL (HTTPS required for non-localhost).
            policy_refresh_interval_s: Seconds between policy refreshes.

        Raises:
            AuthenticationError: If the API key format is invalid.
        """
        _validate_api_key(api_key)

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._policy_refresh_interval_s = policy_refresh_interval_s

        # Start with a degraded config; bootstrap will update it
        self._config = ClientConfig(degraded=True)
        self._config_lock = threading.Lock()

        # HTTP client
        self._http = HttpClient(api_key=api_key, base_url=self._base_url)

        # Telemetry buffer (started immediately; degraded if bootstrap fails)
        self._audit_buffer: AuditBuffer | None = None

        # Guards — order matters: local first, then remote
        self._local_guards: list[Guard] = [
            PiiRegexGuard(),
            BannedPhrasesGuard(),
            InjectionGuard(),
            CostGuard(),
        ]
        self._remote_guards: list[Guard] = [
            TruthGuard(http_client=self._http),
            PiiRemoteGuard(http_client=self._http),
        ]

        # Bootstrap in background to avoid blocking __init__
        self._bootstrap_event = threading.Event()
        self._bootstrap_thread = threading.Thread(
            target=self._bootstrap,
            name="truthvouch-bootstrap",
            daemon=True,
        )
        self._bootstrap_thread.start()

        # Policy refresh thread (started after bootstrap)
        self._stop_refresh = threading.Event()
        if policy_refresh_interval_s > 0:
            self._refresh_thread = threading.Thread(
                target=self._refresh_loop,
                name="truthvouch-policy-refresh",
                daemon=True,
            )
            self._refresh_thread.start()
        else:
            self._refresh_thread = None

    # ------------------------------------------------------------------
    # Bootstrap and policy refresh
    # ------------------------------------------------------------------

    def _bootstrap(self) -> None:
        """Fetch bootstrap configuration from the API.

        On success: updates config, starts telemetry buffer.
        On failure: leaves config in degraded mode (local guards only).
        """
        try:
            data = self._http.get("/api/v1/sdk/bootstrap", timeout=BOOTSTRAP_TIMEOUT)
            config = parse_bootstrap_response(data, api_base_url=self._base_url)
            config.degraded = False
            with self._config_lock:
                self._config = config
            # Start telemetry only after successful bootstrap
            self._audit_buffer = AuditBuffer(
                http_client=self._http,
                flush_interval_s=5.0,
            )
            logger.info(
                "GovernanceClient: bootstrap complete (tier=%s, banned_phrases=%d)",
                config.tier,
                len(config.banned_phrases),
            )
        except AuthenticationError:
            logger.error(
                "GovernanceClient: bootstrap authentication failed — check API key"
            )
        except Exception as exc:
            logger.warning(
                "GovernanceClient: bootstrap failed (%s) — running in degraded mode", exc
            )
        finally:
            self._bootstrap_event.set()

    def _refresh_loop(self) -> None:
        """Background thread that periodically refreshes policy config."""
        # Wait for initial bootstrap before starting refresh cycle
        self._bootstrap_event.wait()

        while not self._stop_refresh.is_set():
            interval = self._config.policy_refresh_interval_s or self._policy_refresh_interval_s
            self._stop_refresh.wait(timeout=interval)
            if self._stop_refresh.is_set():
                break
            self._refresh_config()

    def _refresh_config(self) -> None:
        """Fetch and apply an updated policy config from the API."""
        try:
            data = self._http.get("/api/v1/sdk/bootstrap", timeout=BOOTSTRAP_TIMEOUT)
            config = parse_bootstrap_response(data, api_base_url=self._base_url)
            config.degraded = False
            with self._config_lock:
                self._config = config
            logger.debug("GovernanceClient: policy refreshed")
        except Exception as exc:
            logger.warning("GovernanceClient: policy refresh failed: %s", exc)

    def _get_config(self) -> ClientConfig:
        """Return a consistent snapshot of the current config.

        Returns:
            Current ClientConfig instance.
        """
        with self._config_lock:
            return self._config

    # ------------------------------------------------------------------
    # Guard evaluation
    # ------------------------------------------------------------------

    def _run_guards(
        self,
        text: str,
        direction: str,
        model: str,
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult:
        """Run all guards and aggregate results.

        Local guards always run.  Remote guards are skipped if the config is
        in degraded mode OR if any local guard returns BLOCK.

        Args:
            text: Text to evaluate.
            direction: ``"input"`` or ``"output"``.
            model: LLM model identifier.
            metadata: Optional caller metadata passed to guards.

        Returns:
            EvaluationResult aggregating all guard verdicts.
        """
        config = self._get_config()
        context = GuardContext(
            direction=direction,
            model=model,
            config=config,
            metadata=metadata or {},
        )

        all_results: list[GuardResult] = []
        block_reasons: list[str] = []
        flag_reasons: list[str] = []
        overall_start = time.monotonic()

        # Local guards — always run
        local_blocked = False
        for guard in self._local_guards:
            result = guard.evaluate(text, direction, context)
            all_results.append(result)
            if result.verdict == GuardVerdict.BLOCK:
                block_reasons.append(result.message or f"{guard.name}: blocked")
                local_blocked = True
            elif result.verdict == GuardVerdict.FLAG and result.message:
                flag_reasons.append(result.message)

        # Remote guards — skip in degraded mode or if already blocked
        if not config.degraded and not local_blocked:
            for guard in self._remote_guards:
                result = guard.evaluate(text, direction, context)
                all_results.append(result)
                if result.verdict == GuardVerdict.BLOCK:
                    block_reasons.append(result.message or f"{guard.name}: blocked")
                elif result.verdict == GuardVerdict.FLAG and result.message:
                    flag_reasons.append(result.message)

        total_duration_ms = (time.monotonic() - overall_start) * 1000
        blocked = bool(block_reasons)
        flagged = bool(flag_reasons) and not blocked

        return EvaluationResult(
            blocked=blocked,
            flagged=flagged,
            block_reasons=block_reasons,
            flag_reasons=flag_reasons,
            guard_results=all_results,
            direction=direction,
            total_duration_ms=total_duration_ms,
        )

    def _emit_event(self, result: EvaluationResult, model: str) -> None:
        """Push an evaluation result to the audit buffer.

        No-ops if the audit buffer is not available (degraded mode).

        Args:
            result: Completed evaluation result.
            model: LLM model identifier.
        """
        if self._audit_buffer is None:
            return

        guard_verdict = "block" if result.blocked else ("flag" if result.flagged else "pass")
        # Collect names of guards that flagged or blocked (excluded PASS verdicts).
        guards_triggered = [
            r.guard_name
            for r in result.guard_results
            if r.verdict != GuardVerdict.PASS
        ]

        event = Event(
            event_type="llm_call",
            direction=result.direction,
            guard_verdict=guard_verdict,
            model=model,
            guards_triggered=guards_triggered,
            duration_ms=result.total_duration_ms,
        )
        self._audit_buffer.push(event)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate_input(
        self,
        text: str,
        model: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult:
        """Evaluate a user/tool input before sending it to the LLM.

        Args:
            text: The prompt or input text to evaluate.
            model: LLM model that will receive this input.
            metadata: Optional key/value pairs included in telemetry events.

        Returns:
            EvaluationResult with blocked, block_reasons, flag_reasons, etc.
        """
        result = self._run_guards(text, direction="input", model=model, metadata=metadata)
        self._emit_event(result, model)
        return result

    def evaluate_output(
        self,
        text: str,
        model: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult:
        """Evaluate an LLM output before returning it to the caller.

        Args:
            text: The LLM response text to evaluate.
            model: LLM model that produced the output.
            metadata: Optional key/value pairs included in telemetry events.

        Returns:
            EvaluationResult with blocked, block_reasons, flag_reasons, etc.
        """
        result = self._run_guards(text, direction="output", model=model, metadata=metadata)
        self._emit_event(result, model)
        return result

    def shutdown(self) -> None:
        """Gracefully shut down the client.

        Stops background threads and flushes the telemetry buffer with a
        5-second timeout.  After calling shutdown, the client must not be
        used.
        """
        self._stop_refresh.set()
        if self._audit_buffer is not None:
            self._audit_buffer.shutdown(timeout_s=5.0)
        self._http.close()
        logger.debug("GovernanceClient: shutdown complete")

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    def __enter__(self) -> "GovernanceClient":
        """Enter the context manager.

        Returns:
            self
        """
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit the context manager and shut down the client.

        Args:
            exc_type: Exception type (if any).
            exc_val: Exception value (if any).
            exc_tb: Traceback (if any).
        """
        self.shutdown()
