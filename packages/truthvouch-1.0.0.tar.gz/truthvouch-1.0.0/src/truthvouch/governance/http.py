"""HTTP client wrapper with retries and standard headers."""

from __future__ import annotations

import asyncio
import logging
import platform
import time
from typing import Any

import httpx

from truthvouch._version import __version__
from truthvouch.exceptions import AuthenticationError, TruthVouchError

logger = logging.getLogger(__name__)

# Retry configuration
_MAX_RETRIES = 3
_BACKOFF_DELAYS = [0.5, 1.0, 2.0]  # seconds between attempts

# Timeout presets (connect_timeout, read_timeout) in seconds
GUARD_TIMEOUT = httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=5.0)
BOOTSTRAP_TIMEOUT = httpx.Timeout(connect=5.0, read=10.0, write=5.0, pool=5.0)
TELEMETRY_TIMEOUT = httpx.Timeout(connect=5.0, read=10.0, write=5.0, pool=5.0)

_RETRYABLE_STATUS_CODES = frozenset({500, 502, 503, 504})


def _build_user_agent() -> str:
    """Compose the SDK User-Agent header value.

    Returns:
        User-Agent string in the format:
        ``truthvouch-sdk/{version} python/{python_version}``.
    """
    py_version = platform.python_version()
    return f"truthvouch-sdk/{__version__} python/{py_version}"


class HttpClient:
    """Synchronous HTTP client wrapper around httpx.

    Adds:
    - Automatic Authorization header injection.
    - Standard User-Agent header.
    - Retry logic (3 attempts, exponential backoff) on 5xx and network errors.
    - TLS enforcement (HTTPS required except for localhost/127.0.0.1).

    Args:
        api_key: Bearer token sent with every request.
        base_url: Base URL for all requests (scheme + host, no trailing slash).
    """

    def __init__(self, api_key: str, base_url: str) -> None:
        """Initialise the synchronous HTTP client.

        Args:
            api_key: TruthVouch API key (Bearer token).
            base_url: API base URL.
        """
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._user_agent = _build_user_agent()
        self._client = httpx.Client(
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": self._user_agent,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )

    def _is_retryable(self, exc: Exception | None, status: int | None) -> bool:
        """Determine whether a request should be retried.

        Args:
            exc: The exception raised (if any).
            status: HTTP status code (if a response was received).

        Returns:
            True if the request should be retried.
        """
        if status is not None and status in _RETRYABLE_STATUS_CODES:
            return True
        if isinstance(exc, (httpx.ConnectError, httpx.TimeoutException, httpx.RemoteProtocolError)):
            return True
        return False

    def _enforce_tls(self, url: str) -> None:
        """Raise if the URL uses plain HTTP against a non-local host.

        Args:
            url: Full URL to validate.

        Raises:
            TruthVouchError: If HTTP is used against a remote host.
        """
        if url.startswith("http://"):
            host = url[7:].split("/")[0].split(":")[0]
            if host not in ("localhost", "127.0.0.1", "::1"):
                raise TruthVouchError(
                    f"TLS required: use HTTPS instead of HTTP for {host}"
                )

    def get(
        self,
        path: str,
        timeout: httpx.Timeout = BOOTSTRAP_TIMEOUT,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a GET request with retries.

        Args:
            path: URL path (appended to base_url).
            timeout: Request timeout configuration.
            params: Optional query string parameters.

        Returns:
            Parsed JSON response body.

        Raises:
            AuthenticationError: On 401/403 responses.
            TruthVouchError: On non-retryable errors after all retries exhausted.
        """
        url = f"{self._base_url}{path}"
        self._enforce_tls(url)
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                response = self._client.get(url, timeout=timeout, params=params)
                if response.status_code in (401, 403):
                    raise AuthenticationError(
                        f"Authentication failed: HTTP {response.status_code}"
                    )
                if not self._is_retryable(None, response.status_code):
                    response.raise_for_status()
                    return response.json()
                logger.warning(
                    "HTTP GET %s returned %d; retrying (attempt %d/%d)",
                    path, response.status_code, attempt + 1, _MAX_RETRIES,
                )
                last_exc = httpx.HTTPStatusError(
                    f"HTTP {response.status_code}", request=response.request, response=response
                )
            except AuthenticationError:
                raise
            except httpx.HTTPStatusError as exc:
                if not self._is_retryable(None, exc.response.status_code):
                    raise TruthVouchError(f"HTTP error: {exc}") from exc
                last_exc = exc
                logger.warning("HTTP GET %s error %s; retrying", path, exc)
            except Exception as exc:
                if not self._is_retryable(exc, None):
                    raise TruthVouchError(f"Request failed: {exc}") from exc
                last_exc = exc
                logger.warning("HTTP GET %s network error %s; retrying", path, exc)

            if attempt < _MAX_RETRIES - 1:
                time.sleep(_BACKOFF_DELAYS[attempt])

        raise TruthVouchError(f"Request failed after {_MAX_RETRIES} attempts: {last_exc}")

    def post(
        self,
        path: str,
        body: dict[str, Any] | list[Any],
        timeout: httpx.Timeout = GUARD_TIMEOUT,
    ) -> dict[str, Any]:
        """Send a POST request with retries.

        Args:
            path: URL path (appended to base_url).
            body: JSON-serializable request body.
            timeout: Request timeout configuration.

        Returns:
            Parsed JSON response body.

        Raises:
            AuthenticationError: On 401/403 responses.
            TruthVouchError: On non-retryable errors after all retries exhausted.
        """
        url = f"{self._base_url}{path}"
        self._enforce_tls(url)
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                response = self._client.post(url, json=body, timeout=timeout)
                if response.status_code in (401, 403):
                    raise AuthenticationError(
                        f"Authentication failed: HTTP {response.status_code}"
                    )
                if not self._is_retryable(None, response.status_code):
                    response.raise_for_status()
                    return response.json()
                logger.warning(
                    "HTTP POST %s returned %d; retrying (attempt %d/%d)",
                    path, response.status_code, attempt + 1, _MAX_RETRIES,
                )
                last_exc = httpx.HTTPStatusError(
                    f"HTTP {response.status_code}", request=response.request, response=response
                )
            except AuthenticationError:
                raise
            except httpx.HTTPStatusError as exc:
                if not self._is_retryable(None, exc.response.status_code):
                    raise TruthVouchError(f"HTTP error: {exc}") from exc
                last_exc = exc
                logger.warning("HTTP POST %s error %s; retrying", path, exc)
            except Exception as exc:
                if not self._is_retryable(exc, None):
                    raise TruthVouchError(f"Request failed: {exc}") from exc
                last_exc = exc
                logger.warning("HTTP POST %s network error %s; retrying", path, exc)

            if attempt < _MAX_RETRIES - 1:
                time.sleep(_BACKOFF_DELAYS[attempt])

        raise TruthVouchError(f"Request failed after {_MAX_RETRIES} attempts: {last_exc}")

    def close(self) -> None:
        """Close the underlying httpx client and release connections."""
        self._client.close()


class AsyncHttpClient:
    """Asynchronous HTTP client wrapper around httpx.AsyncClient.

    Same contract as HttpClient but uses async/await.

    Args:
        api_key: Bearer token sent with every request.
        base_url: Base URL for all requests.
    """

    def __init__(self, api_key: str, base_url: str) -> None:
        """Initialise the async HTTP client.

        Args:
            api_key: TruthVouch API key.
            base_url: API base URL.
        """
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._user_agent = _build_user_agent()
        self._client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": self._user_agent,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )

    def _enforce_tls(self, url: str) -> None:
        """Raise if the URL uses plain HTTP against a non-local host.

        Args:
            url: Full URL to validate.

        Raises:
            TruthVouchError: If HTTP is used against a remote host.
        """
        if url.startswith("http://"):
            host = url[7:].split("/")[0].split(":")[0]
            if host not in ("localhost", "127.0.0.1", "::1"):
                raise TruthVouchError(
                    f"TLS required: use HTTPS instead of HTTP for {host}"
                )

    async def get(
        self,
        path: str,
        timeout: httpx.Timeout = BOOTSTRAP_TIMEOUT,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send an async GET request with retries.

        Args:
            path: URL path (appended to base_url).
            timeout: Request timeout configuration.
            params: Optional query string parameters.

        Returns:
            Parsed JSON response body.

        Raises:
            AuthenticationError: On 401/403 responses.
            TruthVouchError: On errors after retries exhausted.
        """
        url = f"{self._base_url}{path}"
        self._enforce_tls(url)
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                response = await self._client.get(url, timeout=timeout, params=params)
                if response.status_code in (401, 403):
                    raise AuthenticationError(
                        f"Authentication failed: HTTP {response.status_code}"
                    )
                if response.status_code not in _RETRYABLE_STATUS_CODES:
                    response.raise_for_status()
                    return response.json()
                last_exc = httpx.HTTPStatusError(
                    f"HTTP {response.status_code}", request=response.request, response=response
                )
            except AuthenticationError:
                raise
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code not in _RETRYABLE_STATUS_CODES:
                    raise TruthVouchError(f"HTTP error: {exc}") from exc
                last_exc = exc
            except Exception as exc:
                last_exc = exc

            if attempt < _MAX_RETRIES - 1:
                await asyncio.sleep(_BACKOFF_DELAYS[attempt])

        raise TruthVouchError(f"Request failed after {_MAX_RETRIES} attempts: {last_exc}")

    async def post(
        self,
        path: str,
        body: dict[str, Any] | list[Any],
        timeout: httpx.Timeout = GUARD_TIMEOUT,
    ) -> dict[str, Any]:
        """Send an async POST request with retries.

        Args:
            path: URL path (appended to base_url).
            body: JSON-serializable request body.
            timeout: Request timeout configuration.

        Returns:
            Parsed JSON response body.

        Raises:
            AuthenticationError: On 401/403 responses.
            TruthVouchError: On errors after retries exhausted.
        """
        url = f"{self._base_url}{path}"
        self._enforce_tls(url)
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                response = await self._client.post(url, json=body, timeout=timeout)
                if response.status_code in (401, 403):
                    raise AuthenticationError(
                        f"Authentication failed: HTTP {response.status_code}"
                    )
                if response.status_code not in _RETRYABLE_STATUS_CODES:
                    response.raise_for_status()
                    return response.json()
                last_exc = httpx.HTTPStatusError(
                    f"HTTP {response.status_code}", request=response.request, response=response
                )
            except AuthenticationError:
                raise
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code not in _RETRYABLE_STATUS_CODES:
                    raise TruthVouchError(f"HTTP error: {exc}") from exc
                last_exc = exc
            except Exception as exc:
                last_exc = exc

            if attempt < _MAX_RETRIES - 1:
                await asyncio.sleep(_BACKOFF_DELAYS[attempt])

        raise TruthVouchError(f"Request failed after {_MAX_RETRIES} attempts: {last_exc}")

    async def aclose(self) -> None:
        """Close the underlying async httpx client."""
        await self._client.aclose()
