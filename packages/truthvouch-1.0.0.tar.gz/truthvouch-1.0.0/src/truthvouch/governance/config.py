"""ClientConfig dataclass and bootstrap response parsing."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ModelPricing:
    """Per-token pricing for a single LLM model.

    Attributes:
        input_cost_per_1k: Cost in USD per 1,000 input tokens.
        output_cost_per_1k: Cost in USD per 1,000 output tokens.
    """

    input_cost_per_1k: float = 0.0
    output_cost_per_1k: float = 0.0


# Sensible default pricing table used when bootstrap does not supply one.
_DEFAULT_MODEL_PRICING: dict[str, ModelPricing] = {
    "gpt-4o": ModelPricing(input_cost_per_1k=0.005, output_cost_per_1k=0.015),
    "gpt-4o-mini": ModelPricing(input_cost_per_1k=0.00015, output_cost_per_1k=0.0006),
    "gpt-4-turbo": ModelPricing(input_cost_per_1k=0.01, output_cost_per_1k=0.03),
    "gpt-3.5-turbo": ModelPricing(input_cost_per_1k=0.0005, output_cost_per_1k=0.0015),
    "claude-3-5-sonnet-20241022": ModelPricing(input_cost_per_1k=0.003, output_cost_per_1k=0.015),
    "claude-3-5-haiku-20241022": ModelPricing(input_cost_per_1k=0.0008, output_cost_per_1k=0.004),
    "claude-3-opus-20240229": ModelPricing(input_cost_per_1k=0.015, output_cost_per_1k=0.075),
    "gemini-1.5-pro": ModelPricing(input_cost_per_1k=0.00125, output_cost_per_1k=0.005),
    "gemini-1.5-flash": ModelPricing(input_cost_per_1k=0.000075, output_cost_per_1k=0.0003),
}


@dataclass
class ClientConfig:
    """Configuration resolved from the /api/v1/sdk/bootstrap endpoint.

    All fields have safe defaults so the SDK works in degraded mode even
    when bootstrap fails.

    Attributes:
        banned_phrases: List of phrases that cause a BLOCK verdict.
        pii_entity_types: PII entity types to check locally.
        pii_scan_enabled: Whether local PII regex scanning is enabled.
        pii_confidence_threshold: Confidence threshold for PII detection.
        injection_check_enabled: Whether local injection check is enabled.
        injection_confidence_threshold: Confidence threshold for injection detection.
        truth_scan_enabled: Whether the remote truth-nugget check is enabled.
        pii_remote_enabled: Whether the remote full Presidio PII scan is enabled.
        allowed_models: List of allowed LLM model identifiers (empty = all allowed).
        max_tokens_per_request: Maximum tokens per request (0 = no limit).
        cost_tracking_enabled: Whether cost tracking is enabled.
        budget_usd: Remaining budget in USD this period (0 = no limit / unknown).
        budget_spent_usd: Budget already consumed this period.
        client_id: Client identifier from the bootstrap response.
        policy_refresh_interval_s: How often (in seconds) to refresh policies.
        model_pricing: Per-model pricing table.
        api_base_url: Base URL for TruthVouch API calls.
        tier: Client subscription tier identifier.
        degraded: True when bootstrap failed; only local guards run.
    """

    banned_phrases: list[str] = field(default_factory=list)
    pii_entity_types: list[str] = field(default_factory=lambda: [
        "SSN", "CREDIT_CARD", "EMAIL", "PHONE", "PASSPORT",
        "ADDRESS", "PERSON_NAME", "DATE_OF_BIRTH", "NATIONAL_ID",
    ])
    pii_scan_enabled: bool = True
    pii_confidence_threshold: float = 0.5
    injection_check_enabled: bool = True
    injection_confidence_threshold: float = 0.85
    truth_scan_enabled: bool = False
    pii_remote_enabled: bool = False
    allowed_models: list[str] = field(default_factory=list)
    max_tokens_per_request: int = 8192
    cost_tracking_enabled: bool = True
    budget_usd: float = 0.0
    budget_spent_usd: float = 0.0
    client_id: str = ""
    policy_refresh_interval_s: int = 300
    model_pricing: dict[str, ModelPricing] = field(
        default_factory=lambda: dict(_DEFAULT_MODEL_PRICING)
    )
    api_base_url: str = ""
    tier: str = "free"
    degraded: bool = False


def parse_bootstrap_response(data: dict[str, Any], api_base_url: str) -> ClientConfig:
    """Parse a camelCase bootstrap API response into a ClientConfig.

    The .NET ``SdkBootstrapResponse`` has a nested structure with ``config``,
    ``budget``, and ``sdkConfig`` sub-objects.  All fields fall back to safe
    defaults so the SDK operates in a reduced-capability mode rather than
    raising on unexpected server responses.

    Args:
        data: Parsed JSON from GET /api/v1/sdk/bootstrap.
        api_base_url: The base URL used for subsequent API calls.

    Returns:
        Populated ClientConfig instance.
    """
    config = ClientConfig(api_base_url=api_base_url)

    # Navigate the nested sub-objects returned by .NET.
    config_data: dict[str, Any] = data.get("config", {})
    budget_data: dict[str, Any] = data.get("budget", {})
    sdk_config: dict[str, Any] = data.get("sdkConfig", {})

    # --- top-level fields ---
    config.client_id = str(data.get("clientId", ""))
    config.tier = str(data.get("tier", "free"))

    # --- policy config sub-object ---
    if "bannedPhrases" in config_data and isinstance(config_data["bannedPhrases"], list):
        config.banned_phrases = [str(p) for p in config_data["bannedPhrases"]]

    if "piiEntityTypes" in config_data and isinstance(config_data["piiEntityTypes"], list):
        config.pii_entity_types = [str(t) for t in config_data["piiEntityTypes"]]

    if "allowedModels" in config_data and isinstance(config_data["allowedModels"], list):
        config.allowed_models = [str(m) for m in config_data["allowedModels"]]

    config.pii_scan_enabled = bool(config_data.get("piiScanEnabled", True))
    config.injection_check_enabled = bool(config_data.get("injectionCheckEnabled", True))
    config.truth_scan_enabled = bool(config_data.get("truthScanEnabled", False))
    config.cost_tracking_enabled = bool(config_data.get("costTrackingEnabled", True))

    # Back-compat: some older server responses may omit the nested wrapper.
    # Fall through to flat keys if nested values were absent.
    if not config_data:
        config.truth_scan_enabled = bool(data.get("truthScanEnabled", False))
        config.pii_remote_enabled = bool(data.get("piiRemoteEnabled", False))
        if "bannedPhrases" in data and isinstance(data["bannedPhrases"], list):
            config.banned_phrases = [str(p) for p in data["bannedPhrases"]]
        if "piiEntityTypes" in data and isinstance(data["piiEntityTypes"], list):
            config.pii_entity_types = [str(t) for t in data["piiEntityTypes"]]
    else:
        config.pii_remote_enabled = bool(data.get("piiRemoteEnabled", False))

    try:
        config.pii_confidence_threshold = float(
            config_data.get("piiConfidenceThreshold", 0.5)
        )
    except (TypeError, ValueError):
        logger.warning("bootstrap: invalid piiConfidenceThreshold; defaulting to 0.5")

    try:
        config.injection_confidence_threshold = float(
            config_data.get("injectionConfidenceThreshold", 0.85)
        )
    except (TypeError, ValueError):
        logger.warning("bootstrap: invalid injectionConfidenceThreshold; defaulting to 0.85")

    try:
        config.max_tokens_per_request = int(config_data.get("maxTokensPerRequest", 8192))
    except (TypeError, ValueError):
        logger.warning("bootstrap: invalid maxTokensPerRequest; defaulting to 8192")

    # --- budget sub-object ---
    try:
        # remaining is the usable budget left this period.
        config.budget_usd = float(budget_data.get("remaining", 0.0))
    except (TypeError, ValueError):
        logger.warning("bootstrap: invalid budget.remaining value; defaulting to 0")

    # Back-compat: flat budgetUsd key.
    if not budget_data:
        try:
            config.budget_usd = float(data.get("budgetUsd", 0.0))
        except (TypeError, ValueError):
            logger.warning("bootstrap: invalid budgetUsd value; defaulting to 0")

    try:
        config.budget_spent_usd = float(budget_data.get("spentThisPeriod", 0.0))
    except (TypeError, ValueError):
        logger.warning("bootstrap: invalid budget.spentThisPeriod value; defaulting to 0")

    # Back-compat: flat budgetSpentUsd key.
    if not budget_data:
        try:
            config.budget_spent_usd = float(data.get("budgetSpentUsd", 0.0))
        except (TypeError, ValueError):
            logger.warning("bootstrap: invalid budgetSpentUsd value; defaulting to 0")

    # --- sdkConfig sub-object ---
    try:
        config.policy_refresh_interval_s = int(
            sdk_config.get("policyRefreshIntervalS", 300)
        )
    except (TypeError, ValueError):
        logger.warning("bootstrap: invalid sdkConfig.policyRefreshIntervalS; defaulting to 300")

    # Back-compat: flat policyRefreshIntervalS key.
    if not sdk_config:
        try:
            config.policy_refresh_interval_s = int(data.get("policyRefreshIntervalS", 300))
        except (TypeError, ValueError):
            logger.warning("bootstrap: invalid policyRefreshIntervalS; defaulting to 300")

    # --- model pricing table (not part of nested structure — optional extension) ---
    raw_pricing = data.get("modelPricing")
    if isinstance(raw_pricing, dict):
        for model, pricing_data in raw_pricing.items():
            if not isinstance(pricing_data, dict):
                continue
            try:
                config.model_pricing[model] = ModelPricing(
                    input_cost_per_1k=float(pricing_data.get("inputCostPer1k", 0.0)),
                    output_cost_per_1k=float(pricing_data.get("outputCostPer1k", 0.0)),
                )
            except (TypeError, ValueError):
                logger.warning("bootstrap: invalid pricing for model %s; skipping", model)

    return config
