"""TruthVouch Governance SDK — guard-based input/output evaluation.

Usage:
    from truthvouch.governance import GovernanceClient, AsyncGovernanceClient

    client = GovernanceClient(api_key="vt_live_...")
    result = client.evaluate_input("Hello", model="gpt-4o")
"""

from truthvouch.governance.client import GovernanceClient
from truthvouch.governance.async_client import AsyncGovernanceClient
from truthvouch.governance.models import (
    EvaluationResult,
    Event,
    GuardContext,
    GuardResult,
    GuardVerdict,
)

__all__ = [
    "GovernanceClient",
    "AsyncGovernanceClient",
    "EvaluationResult",
    "Event",
    "GuardContext",
    "GuardResult",
    "GuardVerdict",
]
