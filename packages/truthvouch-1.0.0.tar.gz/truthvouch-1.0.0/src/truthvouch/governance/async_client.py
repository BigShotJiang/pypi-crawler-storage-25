"""AsyncGovernanceClient — async/await entry point for the TruthVouch governance SDK."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from truthvouch._utils import validate_api_key as _validate_api_key
from truthvouch.governance.config import ClientConfig, parse_bootstrap_response
from truthvouch.exceptions import AuthenticationError
from truthvouch.governance.guards.banned_phrases import BannedPhrasesGuard
from truthvouch.governance.guards.base import Guard
from truthvouch.governance.guards.cost import CostGuard
from truthvouch.governance.guards.injection import InjectionGuard
from truthvouch.governance.guards.pii_regex import PiiRegexGuard
from truthvouch.governance.guards.pii_remote import PiiRemoteGuard
from truthvouch.governance.guards.truth import TruthGuard
from truthvouch.governance.http import BOOTSTRAP_TIMEOUT, AsyncHttpClient
from truthvouch.governance.models import EvaluationResult, Event, GuardContext, GuardResult, GuardVerdict
from truthvouch.telemetry.audit import AsyncAuditBuffer

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "https://api.truthvouch.ai"


class AsyncGovernanceClient:
    """Asynchronous TruthVouch governance client.

    Same contract as GovernanceClient but uses async/await.
    Uses httpx.AsyncClient for network I/O and asyncio.Task for background work.

    Args:
        api_key: TruthVouch API key (must start with ``vt_live_``).
        base_url: API base URL. Defaults to ``https://api.truthvouch.ai``.
        policy_refresh_interval_s: Seconds between policy refreshes.

    Example::

        async with AsyncGovernanceClient(api_key="vt_live_abc123...") as client:
            result = await client.evaluate_input("Hello", model="gpt-4o")
            if result.blocked:
                print(result.block_reasons)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        policy_refresh_interval_s: int = 300,
    ) -> None:
        """Initialise the async client.

        Args:
            api_key: TruthVouch API key.
            base_url: API base URL.
            policy_refresh_interval_s: Seconds between policy refreshes.

        Raises:
            AuthenticationError: If the API key format is invalid.
        """
        _validate_api_key(api_key)

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._policy_refresh_interval_s = policy_refresh_interval_s

        self._config = ClientConfig(degraded=True)
        self._config_lock = asyncio.Lock()

        self._http = AsyncHttpClient(api_key=api_key, base_url=self._base_url)
        self._audit_buffer: AsyncAuditBuffer | None = None

        self._local_guards: list[Guard] = [
            PiiRegexGuard(),
            BannedPhrasesGuard(),
            InjectionGuard(),
            CostGuard(),
        ]
        self._remote_guards: list[Guard] = [
            TruthGuard(http_client=self._http),
            PiiRemoteGuard(http_client=self._http),
        ]

        self._refresh_task: asyncio.Task[None] | None = None
        self._bootstrap_done = asyncio.Event()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def _bootstrap(self) -> None:
        """Fetch bootstrap configuration asynchronously."""
        try:
            data = await self._http.get("/api/v1/sdk/bootstrap", timeout=BOOTSTRAP_TIMEOUT)
            config = parse_bootstrap_response(data, api_base_url=self._base_url)
            config.degraded = False
            async with self._config_lock:
                self._config = config
            self._audit_buffer = AsyncAuditBuffer(http_client=self._http)
            self._audit_buffer.start()
            logger.info(
                "AsyncGovernanceClient: bootstrap complete (tier=%s)", config.tier
            )
        except AuthenticationError:
            logger.error("AsyncGovernanceClient: bootstrap auth failed — check API key")
        except Exception as exc:
            logger.warning(
                "AsyncGovernanceClient: bootstrap failed (%s) — degraded mode", exc
            )
        finally:
            self._bootstrap_done.set()

    async def _refresh_loop(self) -> None:
        """Background task that periodically refreshes policy config."""
        await self._bootstrap_done.wait()
        while True:
            async with self._config_lock:
                interval = self._config.policy_refresh_interval_s
            await asyncio.sleep(interval or self._policy_refresh_interval_s)
            await self._refresh_config()

    async def _refresh_config(self) -> None:
        """Fetch and apply an updated policy config."""
        try:
            data = await self._http.get("/api/v1/sdk/bootstrap", timeout=BOOTSTRAP_TIMEOUT)
            config = parse_bootstrap_response(data, api_base_url=self._base_url)
            config.degraded = False
            async with self._config_lock:
                self._config = config
        except Exception as exc:
            logger.warning("AsyncGovernanceClient: policy refresh failed: %s", exc)

    async def start(self) -> None:
        """Bootstrap and start background tasks.

        Call this if not using the async context manager.
        """
        await self._bootstrap()
        if self._policy_refresh_interval_s > 0:
            self._refresh_task = asyncio.create_task(
                self._refresh_loop(), name="truthvouch-policy-refresh"
            )

    async def shutdown(self) -> None:
        """Shut down the client and flush remaining telemetry."""
        if self._refresh_task is not None:
            self._refresh_task.cancel()
        if self._audit_buffer is not None:
            await self._audit_buffer.shutdown()
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncGovernanceClient":
        """Enter async context manager.

        Returns:
            self after bootstrapping.
        """
        await self.start()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager and shut down.

        Args:
            exc_type: Exception type (if any).
            exc_val: Exception value (if any).
            exc_tb: Traceback (if any).
        """
        await self.shutdown()

    # ------------------------------------------------------------------
    # Guard evaluation
    # ------------------------------------------------------------------

    async def _get_config(self) -> ClientConfig:
        """Return a consistent snapshot of the current config.

        Returns:
            Current ClientConfig.
        """
        async with self._config_lock:
            return self._config

    async def _run_guards(
        self,
        text: str,
        direction: str,
        model: str,
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult:
        """Run all guards asynchronously.

        Local guards (synchronous) are run directly.  Remote guards implement
        the synchronous Guard interface but are called within asyncio.
        For a future iteration, remote guards can be made truly async.

        Args:
            text: Text to evaluate.
            direction: ``"input"`` or ``"output"``.
            model: LLM model identifier.
            metadata: Optional caller metadata.

        Returns:
            EvaluationResult aggregating all guard verdicts.
        """
        config = await self._get_config()
        context = GuardContext(
            direction=direction,
            model=model,
            config=config,
            metadata=metadata or {},
        )

        all_results: list[GuardResult] = []
        block_reasons: list[str] = []
        flag_reasons: list[str] = []
        overall_start = time.monotonic()

        local_blocked = False
        for guard in self._local_guards:
            # Local guards are pure CPU (regex / in-memory) — call directly to avoid
            # unnecessary thread-pool overhead (typically <5 ms each).
            result = guard.evaluate(text, direction, context)
            all_results.append(result)
            if result.verdict == GuardVerdict.BLOCK:
                block_reasons.append(result.message or f"{guard.name}: blocked")
                local_blocked = True
            elif result.verdict == GuardVerdict.FLAG and result.message:
                flag_reasons.append(result.message)

        if not config.degraded and not local_blocked:
            for guard in self._remote_guards:
                # Remote guards perform synchronous HTTP calls; run in executor to
                # avoid blocking the event loop.
                result = await asyncio.get_running_loop().run_in_executor(
                    None, guard.evaluate, text, direction, context
                )
                all_results.append(result)
                if result.verdict == GuardVerdict.BLOCK:
                    block_reasons.append(result.message or f"{guard.name}: blocked")
                elif result.verdict == GuardVerdict.FLAG and result.message:
                    flag_reasons.append(result.message)

        total_duration_ms = (time.monotonic() - overall_start) * 1000
        blocked = bool(block_reasons)
        flagged = bool(flag_reasons) and not blocked

        return EvaluationResult(
            blocked=blocked,
            flagged=flagged,
            block_reasons=block_reasons,
            flag_reasons=flag_reasons,
            guard_results=all_results,
            direction=direction,
            total_duration_ms=total_duration_ms,
        )

    def _emit_event(self, result: EvaluationResult, model: str) -> None:
        """Push evaluation result to the audit buffer.

        Args:
            result: Completed evaluation result.
            model: LLM model identifier.
        """
        if self._audit_buffer is None:
            return

        guard_verdict = "block" if result.blocked else ("flag" if result.flagged else "pass")
        # Collect names of guards that flagged or blocked (excluded PASS verdicts).
        guards_triggered = [
            r.guard_name
            for r in result.guard_results
            if r.verdict != GuardVerdict.PASS
        ]

        event = Event(
            event_type="llm_call",
            direction=result.direction,
            guard_verdict=guard_verdict,
            model=model,
            guards_triggered=guards_triggered,
            duration_ms=result.total_duration_ms,
        )
        self._audit_buffer.push(event)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def evaluate_input(
        self,
        text: str,
        model: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult:
        """Evaluate a user/tool input asynchronously.

        Args:
            text: The prompt or input text to evaluate.
            model: LLM model that will receive this input.
            metadata: Optional caller metadata.

        Returns:
            EvaluationResult with blocked, block_reasons, flag_reasons, etc.
        """
        result = await self._run_guards(text, direction="input", model=model, metadata=metadata)
        self._emit_event(result, model)
        return result

    async def evaluate_output(
        self,
        text: str,
        model: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult:
        """Evaluate an LLM output asynchronously.

        Args:
            text: The LLM response text to evaluate.
            model: LLM model that produced the output.
            metadata: Optional caller metadata.

        Returns:
            EvaluationResult with blocked, block_reasons, flag_reasons, etc.
        """
        result = await self._run_guards(text, direction="output", model=model, metadata=metadata)
        self._emit_event(result, model)
        return result
