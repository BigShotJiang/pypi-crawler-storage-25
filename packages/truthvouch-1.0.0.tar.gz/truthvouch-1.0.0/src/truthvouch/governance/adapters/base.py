"""Framework adapter base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class FrameworkAdapter(ABC):
    """Base class for framework-specific governance adapters.

    Adapters wrap framework callbacks/hooks and delegate to a
    GovernanceClient (sync) or AsyncGovernanceClient (async) for policy evaluation.
    """

    @abstractmethod
    def wrap_llm(self, llm: Any) -> Any:
        """Wrap an LLM client to add governance checks.

        Args:
            llm: The framework-specific LLM client to wrap.

        Returns:
            A governance-aware wrapper around the LLM client.
        """
        ...
