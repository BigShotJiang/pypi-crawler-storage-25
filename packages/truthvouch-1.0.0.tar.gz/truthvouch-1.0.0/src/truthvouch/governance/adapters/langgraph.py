"""LangGraph/LangChain callback handler adapter.

Integrates TruthVouch governance into LangChain/LangGraph pipelines via the
standard callback interface.

Usage::

    from truthvouch.governance.adapters.langgraph import TruthVouchCallbackHandler

    handler = TruthVouchCallbackHandler(client)
    # Sync usage:
    chain.invoke(inputs, config={"callbacks": [handler]})

    # Async usage with AsyncGovernanceClient:
    handler = TruthVouchCallbackHandler(async_client)
    await chain.ainvoke(inputs, config={"callbacks": [handler]})

The handler implements the LangChain BaseCallbackHandler interface without
importing LangChain at package load time — imports are deferred to avoid
making langchain a hard dependency.
"""

from __future__ import annotations

import logging
from typing import Any, Union

from truthvouch.exceptions import GovernanceBlockError

logger = logging.getLogger(__name__)


class TruthVouchCallbackHandler:
    """LangChain callback handler that enforces TruthVouch governance.

    Hooks into the LangChain callback system:
    - ``on_llm_start``: evaluates the input prompt; raises GovernanceBlockError
      if blocked.
    - ``on_llm_end``: evaluates the LLM response; replaces generation text
      with a block message if blocked.
    - ``on_tool_start`` / ``on_tool_end``: logs tool invocations to telemetry.

    Works with both sync GovernanceClient and async AsyncGovernanceClient.
    When an async client is provided, async callback methods (``on_llm_start``,
    ``on_llm_end``, etc.) are expected to be awaited by the caller.

    Args:
        client: GovernanceClient or AsyncGovernanceClient instance.
        model: LLM model identifier to tag telemetry events with.
        block_message: Text to substitute for blocked LLM outputs.
    """

    def __init__(
        self,
        client: Any,
        model: str = "",
        block_message: str = "[Response blocked by TruthVouch governance policy]",
    ) -> None:
        """Initialise the callback handler.

        Args:
            client: TruthVouch client (sync or async).
            model: LLM model identifier for telemetry.
            block_message: Replacement text for blocked outputs.
        """
        self._client = client
        self._model = model
        self._block_message = block_message
        self._is_async = hasattr(client, "evaluate_input") and hasattr(
            client.evaluate_input, "__await__"
        ) or _is_coroutine_function(getattr(client, "evaluate_input", None))

    # ------------------------------------------------------------------
    # LangChain BaseCallbackHandler interface (sync)
    # ------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        **kwargs: Any,
    ) -> None:
        """Evaluate LLM input prompts before they are sent to the LLM.

        Args:
            serialized: Serialized LLM config dict (provided by LangChain).
            prompts: List of prompt strings to evaluate.
            **kwargs: Additional LangChain callback kwargs.

        Raises:
            GovernanceBlockError: If any prompt is blocked by a guard.
        """
        combined = "\n".join(prompts)
        result = self._client.evaluate_input(combined, model=self._model)
        if result.blocked:
            raise GovernanceBlockError(
                "LLM input blocked by TruthVouch governance",
                block_reasons=result.block_reasons,
                guard_results=[
                    {"guard_name": r.guard_name, "verdict": r.verdict.value}
                    for r in result.guard_results
                ],
            )
        if result.flagged:
            logger.warning(
                "TruthVouchCallbackHandler: input flagged: %s", result.flag_reasons
            )

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        """Evaluate LLM output after generation.

        If blocked, replaces all generation texts with the block message.

        Args:
            response: LangChain LLMResult object.
            **kwargs: Additional LangChain callback kwargs.
        """
        try:
            text = _extract_llm_result_text(response)
        except Exception as exc:
            logger.warning("TruthVouchCallbackHandler: could not extract LLM text: %s", exc)
            return

        result = self._client.evaluate_output(text, model=self._model)
        if result.blocked:
            _replace_llm_result_text(response, self._block_message)
            logger.warning(
                "TruthVouchCallbackHandler: output blocked: %s", result.block_reasons
            )
        elif result.flagged:
            logger.warning(
                "TruthVouchCallbackHandler: output flagged: %s", result.flag_reasons
            )

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> None:
        """Log tool invocation start to telemetry.

        Args:
            serialized: Serialized tool config.
            input_str: Tool input string.
            **kwargs: Additional kwargs.
        """
        tool_name = serialized.get("name", "unknown_tool")
        logger.debug("TruthVouchCallbackHandler: tool_start tool=%s", tool_name)

    def on_tool_end(self, output: str, **kwargs: Any) -> None:
        """Log tool invocation end to telemetry.

        Args:
            output: Tool output string.
            **kwargs: Additional kwargs.
        """
        logger.debug("TruthVouchCallbackHandler: tool_end output_len=%d", len(output))

    def on_llm_error(self, error: Union[Exception, KeyboardInterrupt], **kwargs: Any) -> None:
        """Log LLM errors.

        Args:
            error: The error that occurred.
            **kwargs: Additional kwargs.
        """
        logger.error("TruthVouchCallbackHandler: LLM error: %s", error)

    def on_tool_error(self, error: Union[Exception, KeyboardInterrupt], **kwargs: Any) -> None:
        """Log tool errors.

        Args:
            error: The error that occurred.
            **kwargs: Additional kwargs.
        """
        logger.error("TruthVouchCallbackHandler: tool error: %s", error)

    # ------------------------------------------------------------------
    # Async variants (used by AsyncGovernanceClient)
    # ------------------------------------------------------------------

    async def on_llm_start_async(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        **kwargs: Any,
    ) -> None:
        """Async version of on_llm_start.

        Args:
            serialized: Serialized LLM config dict.
            prompts: List of prompts to evaluate.
            **kwargs: Additional kwargs.

        Raises:
            GovernanceBlockError: If any prompt is blocked.
        """
        combined = "\n".join(prompts)
        result = await self._client.evaluate_input(combined, model=self._model)
        if result.blocked:
            raise GovernanceBlockError(
                "LLM input blocked by TruthVouch governance",
                block_reasons=result.block_reasons,
            )
        if result.flagged:
            logger.warning(
                "TruthVouchCallbackHandler: input flagged: %s", result.flag_reasons
            )

    async def on_llm_end_async(self, response: Any, **kwargs: Any) -> None:
        """Async version of on_llm_end.

        Args:
            response: LangChain LLMResult object.
            **kwargs: Additional kwargs.
        """
        try:
            text = _extract_llm_result_text(response)
        except Exception as exc:
            logger.warning("TruthVouchCallbackHandler: could not extract LLM text: %s", exc)
            return

        result = await self._client.evaluate_output(text, model=self._model)
        if result.blocked:
            _replace_llm_result_text(response, self._block_message)
            logger.warning(
                "TruthVouchCallbackHandler: output blocked: %s", result.block_reasons
            )


def _is_coroutine_function(func: Any) -> bool:
    """Check if a callable is a coroutine function.

    Args:
        func: Callable to inspect.

    Returns:
        True if the function is defined with ``async def``.
    """
    import inspect
    return func is not None and inspect.iscoroutinefunction(func)


def _extract_llm_result_text(response: Any) -> str:
    """Extract flat text from a LangChain LLMResult.

    Handles both LLMResult objects and plain dicts/strings gracefully.

    Args:
        response: LangChain LLMResult or compatible object.

    Returns:
        Concatenated generation text.
    """
    if isinstance(response, str):
        return response

    # LangChain LLMResult: response.generations is list[list[Generation]]
    generations = getattr(response, "generations", None)
    if generations is not None:
        texts = []
        for gen_list in generations:
            for gen in gen_list:
                text = getattr(gen, "text", None) or str(gen)
                texts.append(text)
        return "\n".join(texts)

    # dict fallback
    if isinstance(response, dict):
        return str(response.get("text", response))

    return str(response)


def _replace_llm_result_text(response: Any, replacement: str) -> None:
    """Replace all generation texts in an LLMResult with replacement.

    Args:
        response: LangChain LLMResult (mutated in place).
        replacement: Text to substitute.
    """
    generations = getattr(response, "generations", None)
    if generations is None:
        return
    for gen_list in generations:
        for gen in gen_list:
            if hasattr(gen, "text"):
                gen.text = replacement
