"""CrewAI middleware adapter.

Wraps a CrewAI-compatible LLM client (e.g., ChatOpenAI) to add TruthVouch
governance checks to every LLM call made by a CrewAI agent.

Usage::

    from truthvouch.governance.adapters.crewai import TruthVouchMiddleware
    from crewai import Agent
    from langchain_openai import ChatOpenAI

    middleware = TruthVouchMiddleware(client)
    llm = middleware.wrap_llm(ChatOpenAI(model="gpt-4o"))
    agent = Agent(llm=llm, ...)

The wrapper intercepts ``invoke`` / ``__call__`` / ``generate`` calls,
evaluates inputs and outputs, and raises GovernanceBlockError on violations.
"""

from __future__ import annotations

import logging
from typing import Any

from truthvouch.governance.adapters.base import FrameworkAdapter
from truthvouch.exceptions import GovernanceBlockError

logger = logging.getLogger(__name__)

_BLOCK_MESSAGE = "[Response blocked by TruthVouch governance policy]"


class _GovernanceLLMWrapper:
    """Thin wrapper around an LLM client that adds TruthVouch checks.

    Delegates all attribute access to the underlying LLM except for
    ``invoke``, ``__call__``, and ``generate``, which are intercepted
    to run governance guards.

    Args:
        llm: The original LLM client.
        client: GovernanceClient or AsyncGovernanceClient.
        model: Model identifier for telemetry tagging.
    """

    def __init__(self, llm: Any, client: Any, model: str) -> None:
        """Initialise the governance wrapper.

        Args:
            llm: Underlying LLM client to wrap.
            client: TruthVouch client instance.
            model: LLM model identifier.
        """
        object.__setattr__(self, "_llm", llm)
        object.__setattr__(self, "_client", client)
        object.__setattr__(self, "_model", model)

    def __getattr__(self, name: str) -> Any:
        """Proxy all attribute access to the underlying LLM.

        Args:
            name: Attribute name.

        Returns:
            Attribute from the wrapped LLM.
        """
        return getattr(object.__getattribute__(self, "_llm"), name)

    def _extract_input_text(self, *args: Any, **kwargs: Any) -> str:
        """Extract a flat string from positional / keyword arguments.

        Args:
            *args: Positional arguments passed to invoke / __call__.
            **kwargs: Keyword arguments.

        Returns:
            Flat string representation of the input.
        """
        if args:
            first = args[0]
            if isinstance(first, str):
                return first
            if isinstance(first, list):
                return "\n".join(
                    m.get("content", str(m)) if isinstance(m, dict) else str(m)
                    for m in first
                )
            return str(first)
        prompt = kwargs.get("prompt") or kwargs.get("messages") or kwargs.get("input")
        if prompt is None:
            return ""
        if isinstance(prompt, str):
            return prompt
        if isinstance(prompt, list):
            return "\n".join(str(p) for p in prompt)
        return str(prompt)

    def _extract_output_text(self, response: Any) -> str:
        """Extract a flat string from an LLM response.

        Args:
            response: LLM response object.

        Returns:
            Flat text string.
        """
        if isinstance(response, str):
            return response
        # LangChain AIMessage / BaseMessage
        content = getattr(response, "content", None)
        if content is not None:
            return str(content)
        # LLMResult
        generations = getattr(response, "generations", None)
        if generations is not None:
            texts = []
            for gen_list in generations:
                for gen in gen_list:
                    texts.append(getattr(gen, "text", str(gen)))
            return "\n".join(texts)
        return str(response)

    def _check_input(self, text: str) -> None:
        """Run input guards; raise on block.

        Args:
            text: Input text to evaluate.

        Raises:
            GovernanceBlockError: If blocked.
        """
        client = object.__getattribute__(self, "_client")
        model = object.__getattribute__(self, "_model")
        result = client.evaluate_input(text, model=model)
        if result.blocked:
            raise GovernanceBlockError(
                "LLM input blocked by TruthVouch governance",
                block_reasons=result.block_reasons,
            )
        if result.flagged:
            logger.warning("TruthVouchMiddleware: input flagged: %s", result.flag_reasons)

    def _check_output(self, text: str) -> None:
        """Run output guards; log on block.

        Args:
            text: Output text to evaluate.

        Raises:
            GovernanceBlockError: If blocked.
        """
        client = object.__getattribute__(self, "_client")
        model = object.__getattribute__(self, "_model")
        result = client.evaluate_output(text, model=model)
        if result.blocked:
            raise GovernanceBlockError(
                "LLM output blocked by TruthVouch governance",
                block_reasons=result.block_reasons,
            )
        if result.flagged:
            logger.warning("TruthVouchMiddleware: output flagged: %s", result.flag_reasons)

    def invoke(self, *args: Any, **kwargs: Any) -> Any:
        """Intercept invoke() to add governance checks.

        Args:
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Returns:
            LLM response.

        Raises:
            GovernanceBlockError: If input or output is blocked.
        """
        llm = object.__getattribute__(self, "_llm")
        text = self._extract_input_text(*args, **kwargs)
        self._check_input(text)
        response = llm.invoke(*args, **kwargs)
        output = self._extract_output_text(response)
        self._check_output(output)
        return response

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Intercept __call__ to add governance checks.

        Args:
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Returns:
            LLM response.

        Raises:
            GovernanceBlockError: If input or output is blocked.
        """
        llm = object.__getattribute__(self, "_llm")
        text = self._extract_input_text(*args, **kwargs)
        self._check_input(text)
        response = llm(*args, **kwargs)
        output = self._extract_output_text(response)
        self._check_output(output)
        return response

    def generate(self, *args: Any, **kwargs: Any) -> Any:
        """Intercept generate() to add governance checks.

        Args:
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Returns:
            LLM generation result.

        Raises:
            GovernanceBlockError: If input or output is blocked.
        """
        llm = object.__getattribute__(self, "_llm")
        text = self._extract_input_text(*args, **kwargs)
        self._check_input(text)
        response = llm.generate(*args, **kwargs)
        output = self._extract_output_text(response)
        self._check_output(output)
        return response


class TruthVouchMiddleware(FrameworkAdapter):
    """CrewAI middleware that wraps an LLM client with TruthVouch governance.

    Args:
        client: GovernanceClient or AsyncGovernanceClient.
        model: LLM model identifier used for telemetry tagging.
            If not supplied, tries to infer from the LLM's model_name attribute.
    """

    def __init__(self, client: Any, model: str = "") -> None:
        """Initialise the middleware.

        Args:
            client: TruthVouch client instance.
            model: LLM model identifier.
        """
        self._client = client
        self._model = model

    def wrap_llm(self, llm: Any) -> _GovernanceLLMWrapper:
        """Wrap an LLM client to add governance checks.

        Args:
            llm: LangChain-compatible LLM client (e.g. ChatOpenAI).

        Returns:
            A governance-aware wrapper that proxies all LLM calls.
        """
        model = self._model or getattr(llm, "model_name", "") or getattr(llm, "model", "")
        return _GovernanceLLMWrapper(llm=llm, client=self._client, model=model)
