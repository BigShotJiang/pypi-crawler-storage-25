"""Remote full PII scan guard.

Calls the Governance Gateway PII endpoint for a thorough Presidio-backed
PII scan.  Disabled by default (opt-in via ``pii_remote_enabled`` bootstrap
flag).

Returns FLAG on any PII detection — the remote scan is informational;
callers may escalate to BLOCK based on entity types found.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from truthvouch.governance.guards.base import Guard
from truthvouch.governance.http import GUARD_TIMEOUT
from truthvouch.governance.models import GuardContext, GuardResult, GuardVerdict

logger = logging.getLogger(__name__)


class PiiRemoteGuard(Guard):
    """Remote guard that calls the Governance Gateway PII endpoint.

    Args:
        http_client: An HttpClient instance for making API calls.
    """

    def __init__(self, http_client: Any) -> None:
        """Initialise the remote PII guard.

        Args:
            http_client: HttpClient or compatible object with a .post() method.
        """
        self._http = http_client

    @property
    def name(self) -> str:
        """Guard identifier.

        Returns:
            ``"pii_remote"``
        """
        return "pii_remote"

    @property
    def is_local(self) -> bool:
        """Whether this guard runs in-process.

        Returns:
            False — this guard makes remote API calls.
        """
        return False

    def evaluate(self, text: str, direction: str, context: GuardContext) -> GuardResult:
        """Run remote full PII scan.

        Skipped if ``context.config.pii_remote_enabled`` is False.
        On API failure, returns PASS to avoid blocking on infrastructure
        issues (the local pii_regex guard provides a fast fallback).

        Args:
            text: Text to scan.
            direction: ``"input"`` or ``"output"``.
            context: Evaluation context with config.

        Returns:
            GuardResult with PASS or FLAG verdict.
        """
        start = time.monotonic()

        if not context.config.pii_remote_enabled:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"skipped": "pii_remote_enabled is False"},
                duration_ms=(time.monotonic() - start) * 1000,
                message="",
            )

        try:
            response = self._http.post(
                "/api/v1/sdk/pii-scan",
                body={"text": text, "action": "detect"},
                timeout=GUARD_TIMEOUT,
            )
        except Exception as exc:
            logger.warning("PiiRemoteGuard: API call failed: %s — passing", exc)
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"error": str(exc), "failed_open": True},
                duration_ms=(time.monotonic() - start) * 1000,
                message="",
            )

        duration_ms = (time.monotonic() - start) * 1000

        entities: list[dict[str, Any]] = response.get("entities", [])
        total_count: int = response.get("totalPiiCount", len(entities))

        if total_count == 0:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"entities": [], "total_count": 0},
                duration_ms=duration_ms,
                message="",
            )

        by_type: dict[str, int] = {}
        for entity in entities:
            etype = entity.get("entityType", "UNKNOWN")
            by_type[etype] = by_type.get(etype, 0) + 1

        summary = ", ".join(f"{count} {etype}" for etype, count in sorted(by_type.items()))
        return GuardResult(
            guard_name=self.name,
            verdict=GuardVerdict.FLAG,
            details={
                "entities": entities,
                "entity_counts": by_type,
                "total_count": total_count,
            },
            duration_ms=duration_ms,
            message=f"Remote PII scan found: {summary}. Review before proceeding.",
        )
