"""Local PII regex guard.

Detects Personally Identifiable Information using compiled regular expressions.
This is a deliberate copy of the patterns from src/python/services/pii_detector.py
— the SDK is a standalone deployment unit with its own release cycle.

Patterns covered:
    EMAIL, SSN (dashed + context-required plain), CREDIT_CARD (Luhn-validated),
    PHONE (US/CA/UK/DE/FR), PASSPORT, ADDRESS.

Returns FLAG (not BLOCK) — regex detection has false positives; remote
full-scan guards provide higher-confidence blocking decisions.
"""

from __future__ import annotations

import re
import time
from typing import Any

from truthvouch.governance.guards.base import Guard
from truthvouch.governance.models import GuardContext, GuardResult, GuardVerdict

# ---------------------------------------------------------------------------
# Regex patterns (copied from src/python/services/pii_detector.py)
# ---------------------------------------------------------------------------

_EMAIL_RE = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b",
    re.IGNORECASE,
)

# SSN dashed: 123-45-6789 — most reliable form
_SSN_DASHED_RE = re.compile(r"\b(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b")

# SSN plain: 9 contiguous digits — only matched when near SSN context words
_SSN_PLAIN_RE = re.compile(r"\b(?!000000000)(?!666\d{6})(?!9\d{8})\d{9}\b")

# Credit card: 13–19 digit groups separated by spaces or dashes
_CC_RE = re.compile(r"\b(?:\d[ \-]?){13,18}\d\b")

# Phone: US (with and without country code) and common EU formats
_PHONE_RE = re.compile(
    r"(?:"
    r"\+?1[\s.\-]?\(?\d{3}\)?[\s.\-]?\d{3}[\s.\-]?\d{4}"          # US/CA with +1
    r"|\(\d{3}\)[\s.\-]\d{3}[\s.\-]\d{4}"                           # US (NXX) NXX-XXXX
    r"|\d{3}[\s.\-]\d{3}[\s.\-]\d{4}"                               # US NXX-NXX-XXXX
    r"|\+44[\s.\-]?\d{2,4}[\s.\-]?\d{3,4}[\s.\-]?\d{3,4}"          # UK with +44 (no leading 0)
    r"|(?:\+?44[\s.\-]?)?0\d{2,4}[\s.\-]?\d{3,4}[\s.\-]?\d{3,4}"   # UK with/without +44 + leading 0
    r"|\+?49[\s.\-]?\d{2,5}[\s.\-]?\d{4,10}"                        # DE
    r"|\+?33[\s.\-]?[1-9](?:[\s.\-]?\d{2}){4}"                      # FR
    r")"
)

# Passport: common patterns (US/UK format: 1-2 letters + 6-9 digits)
_PASSPORT_RE = re.compile(r"\b[A-Z]{1,2}\d{6,9}\b")

# Address heuristic: number + word + road type
_ADDRESS_RE = re.compile(
    r"\b\d{1,5}\s+[A-Za-z\s]{3,30}"
    r"(?:Street|St|Avenue|Ave|Boulevard|Blvd|Road|Rd|Lane|Ln|Drive|Dr|"
    r"Court|Ct|Place|Pl|Way|Terrace|Ter|Circle|Cir)\b",
    re.IGNORECASE,
)

# SSN context keywords for plain 9-digit validation
_SSN_CONTEXT_KEYWORDS = ("ssn", "social security", "sin", "taxpayer")

# Canonical entity type constants
ENTITY_EMAIL = "EMAIL"
ENTITY_SSN = "SSN"
ENTITY_CREDIT_CARD = "CREDIT_CARD"
ENTITY_PHONE = "PHONE"
ENTITY_PASSPORT = "PASSPORT"
ENTITY_ADDRESS = "ADDRESS"

# Ordered list of (entity_type, pattern) pairs
_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (ENTITY_EMAIL, _EMAIL_RE),
    (ENTITY_SSN, _SSN_DASHED_RE),
    (ENTITY_SSN, _SSN_PLAIN_RE),
    (ENTITY_PHONE, _PHONE_RE),
    (ENTITY_CREDIT_CARD, _CC_RE),
    (ENTITY_PASSPORT, _PASSPORT_RE),
    (ENTITY_ADDRESS, _ADDRESS_RE),
]


def _luhn_valid(number: str) -> bool:
    """Return True if *number* (digit-only string) passes the Luhn check.

    Args:
        number: String containing only digit characters.

    Returns:
        True if the Luhn checksum is valid.
    """
    digits = [int(d) for d in number]
    digits.reverse()
    total = 0
    for i, digit in enumerate(digits):
        if i % 2 == 1:
            doubled = digit * 2
            total += doubled - 9 if doubled > 9 else doubled
        else:
            total += digit
    return total % 10 == 0


def _redact(entity_type: str, raw: str) -> str:
    """Return a redacted version of a matched PII string.

    Preserves enough structural context (length category, last-4 digits) for
    debugging without exposing the actual PII value in telemetry.

    Args:
        entity_type: The PII entity type constant.
        raw: The raw matched text.

    Returns:
        Redacted string safe for logging and telemetry.
    """
    if entity_type == ENTITY_SSN:
        # Show last 4 digits: ***-**-6789
        digits = re.sub(r"[^\d]", "", raw)
        return f"***-**-{digits[-4:]}" if len(digits) >= 4 else "***-**-****"
    if entity_type == ENTITY_CREDIT_CARD:
        digits = re.sub(r"[^\d]", "", raw)
        return f"****-****-****-{digits[-4:]}" if len(digits) >= 4 else "****-****-****-****"
    if entity_type == ENTITY_EMAIL:
        at_pos = raw.find("@")
        if at_pos > 0:
            return f"{'*' * min(at_pos, 3)}***{raw[at_pos:]}"
        return "***@***"
    if entity_type == ENTITY_PHONE:
        digits = re.sub(r"[^\d]", "", raw)
        return f"***-***-{digits[-4:]}" if len(digits) >= 4 else "***-***-****"
    if entity_type == ENTITY_PASSPORT:
        return f"{raw[:2]}{'*' * (len(raw) - 2)}" if len(raw) > 2 else "****"
    # Default: replace all but first and last character with asterisks
    if len(raw) <= 2:
        return "*" * len(raw)
    return f"{raw[0]}{'*' * (len(raw) - 2)}{raw[-1]}"


def _scan(text: str, entity_types: set[str]) -> list[dict[str, Any]]:
    """Run all configured regex patterns against *text*.

    Matched PII text is redacted before being included in the result to
    prevent raw PII from appearing in telemetry or guard details.

    Args:
        text: Input text to scan.
        entity_types: Set of entity type strings to detect.

    Returns:
        List of match dicts with keys: entity_type, redacted_text, start, end.
    """
    matches: list[dict[str, Any]] = []
    seen_spans: set[tuple[str, int, int]] = set()

    for entity_type, pattern in _PATTERNS:
        if entity_type not in entity_types:
            continue

        for match in pattern.finditer(text):
            raw = match.group(0)
            span_key = (entity_type, match.start(), match.end())

            if span_key in seen_spans:
                continue

            # Credit card extra validation via Luhn
            if entity_type == ENTITY_CREDIT_CARD:
                digits_only = re.sub(r"[^\d]", "", raw)
                if len(digits_only) < 13 or not _luhn_valid(digits_only):
                    continue

            # Plain 9-digit SSN: only flag when near SSN context words
            if entity_type == ENTITY_SSN and pattern is _SSN_PLAIN_RE:
                ctx_start = max(0, match.start() - 40)
                ctx_end = min(len(text), match.end() + 40)
                ctx = text[ctx_start:ctx_end].lower()
                if not any(kw in ctx for kw in _SSN_CONTEXT_KEYWORDS):
                    continue

            seen_spans.add(span_key)
            matches.append({
                "entity_type": entity_type,
                "redacted_text": _redact(entity_type, raw),
                "start": match.start(),
                "end": match.end(),
            })

    return matches


class PiiRegexGuard(Guard):
    """Local regex-based PII detection guard.

    Scans text for personally identifiable information using compiled regex
    patterns. Returns FLAG on detection — regex has false positives so
    remote guards are needed for authoritative BLOCK decisions.

    Configuration (from GuardContext.config):
        pii_entity_types: List of entity types to detect.
    """

    @property
    def name(self) -> str:
        """Guard identifier.

        Returns:
            ``"pii_regex"``
        """
        return "pii_regex"

    def evaluate(self, text: str, direction: str, context: GuardContext) -> GuardResult:
        """Scan text for PII and return FLAG if any is found.

        Args:
            text: Text to evaluate.
            direction: ``"input"`` or ``"output"``.
            context: Evaluation context with current policy config.

        Returns:
            GuardResult with PASS or FLAG verdict.
        """
        if not context.config.pii_scan_enabled:
            return GuardResult(guard_name=self.name, verdict=GuardVerdict.PASS)

        start = time.monotonic()

        entity_types: set[str] = set(context.config.pii_entity_types)
        matches = _scan(text, entity_types)

        duration_ms = (time.monotonic() - start) * 1000

        if not matches:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"matches": []},
                duration_ms=duration_ms,
                message="",
            )

        # Summarise findings
        by_type: dict[str, int] = {}
        for m in matches:
            by_type[m["entity_type"]] = by_type.get(m["entity_type"], 0) + 1

        summary = ", ".join(f"{count} {etype}" for etype, count in sorted(by_type.items()))
        message = f"PII detected: {summary}. Review before sending."

        return GuardResult(
            guard_name=self.name,
            verdict=GuardVerdict.FLAG,
            details={
                "matches": matches,
                "entity_counts": by_type,
            },
            duration_ms=duration_ms,
            message=message,
        )
