"""Cost estimation and budget enforcement guard.

Estimates token count from text, looks up per-model pricing, and blocks
requests that would exceed the remaining budget.

Token estimation: 1 token ~ 0.75 words (word count / 0.75).
Budget is tracked in the ClientConfig and refreshed from bootstrap.
"""

from __future__ import annotations

import re
import time

from truthvouch.governance.config import ModelPricing, _DEFAULT_MODEL_PRICING
from truthvouch.governance.guards.base import Guard
from truthvouch.governance.models import GuardContext, GuardResult, GuardVerdict


def estimate_tokens(text: str) -> int:
    """Estimate the number of LLM tokens in text.

    Uses the heuristic: 1 token ~ 0.75 words, where words are whitespace-
    separated non-empty tokens.

    Args:
        text: Input text to estimate.

    Returns:
        Estimated token count (minimum 1 for non-empty text).
    """
    words = len(re.findall(r"\S+", text))
    if words == 0:
        return 0
    return max(1, int(words / 0.75))


def get_model_pricing(model: str, config_pricing: dict[str, ModelPricing]) -> ModelPricing:
    """Resolve pricing for a model name.

    Checks config_pricing first (from bootstrap), then falls back to the
    built-in default table.  If the model is not found in either table, a
    zero-cost pricing entry is returned (no budget enforcement for unknown
    models to avoid false positives).

    Args:
        model: LLM model identifier (e.g. ``"gpt-4o"``).
        config_pricing: Per-model pricing from ClientConfig.

    Returns:
        ModelPricing with input_cost_per_1k and output_cost_per_1k.
    """
    if model in config_pricing:
        return config_pricing[model]
    if model in _DEFAULT_MODEL_PRICING:
        return _DEFAULT_MODEL_PRICING[model]
    return ModelPricing(input_cost_per_1k=0.0, output_cost_per_1k=0.0)


class CostGuard(Guard):
    """Guard that enforces per-session USD budget limits.

    For input direction, estimates cost based on input token pricing.
    For output direction, estimates cost based on output token pricing.
    Returns BLOCK when estimated cost would exceed the remaining budget.

    If budget_usd is 0 (unset) or no pricing data is available for the
    model, the guard always returns PASS.
    """

    @property
    def name(self) -> str:
        """Guard identifier.

        Returns:
            ``"cost"``
        """
        return "cost"

    def evaluate(self, text: str, direction: str, context: GuardContext) -> GuardResult:
        """Check whether processing text would exceed the budget.

        Args:
            text: Text to cost-estimate.
            direction: ``"input"`` or ``"output"``.
            context: Evaluation context with current policy config.

        Returns:
            GuardResult with PASS or BLOCK verdict.
        """
        start = time.monotonic()

        config = context.config
        budget_usd = config.budget_usd
        budget_spent_usd = config.budget_spent_usd

        # No budget configured — always pass
        if budget_usd <= 0.0:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"budget_usd": 0.0, "budget_spent_usd": 0.0},
                duration_ms=(time.monotonic() - start) * 1000,
                message="",
            )

        tokens = estimate_tokens(text)
        pricing = get_model_pricing(context.model, config.model_pricing)

        if direction == "input":
            cost_per_1k = pricing.input_cost_per_1k
        else:
            cost_per_1k = pricing.output_cost_per_1k

        # Unknown model pricing — pass through
        if cost_per_1k == 0.0:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={
                    "estimated_tokens": tokens,
                    "estimated_cost_usd": 0.0,
                    "reason": "no pricing data for model",
                    "model": context.model,
                },
                duration_ms=(time.monotonic() - start) * 1000,
                message="",
            )

        estimated_cost = (tokens / 1000.0) * cost_per_1k
        remaining = budget_usd - budget_spent_usd
        duration_ms = (time.monotonic() - start) * 1000

        if estimated_cost > remaining:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.BLOCK,
                details={
                    "estimated_tokens": tokens,
                    "estimated_cost_usd": round(estimated_cost, 6),
                    "budget_usd": budget_usd,
                    "budget_spent_usd": budget_spent_usd,
                    "remaining_usd": round(remaining, 6),
                    "model": context.model,
                    "direction": direction,
                },
                duration_ms=duration_ms,
                message=(
                    f"Budget exceeded: estimated cost ${estimated_cost:.4f} exceeds "
                    f"remaining budget ${remaining:.4f}. "
                    "Upgrade your plan or reset your budget to continue."
                ),
            )

        return GuardResult(
            guard_name=self.name,
            verdict=GuardVerdict.PASS,
            details={
                "estimated_tokens": tokens,
                "estimated_cost_usd": round(estimated_cost, 6),
                "budget_usd": budget_usd,
                "budget_spent_usd": budget_spent_usd,
                "remaining_usd": round(remaining, 6),
                "model": context.model,
                "direction": direction,
            },
            duration_ms=duration_ms,
            message="",
        )
