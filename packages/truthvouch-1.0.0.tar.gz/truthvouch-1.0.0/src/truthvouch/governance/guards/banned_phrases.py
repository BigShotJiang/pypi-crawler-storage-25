"""Banned phrase matching guard.

Performs case-insensitive substring match against a configurable list of
banned phrases loaded from the bootstrap configuration.
Returns BLOCK immediately on any match.
"""

from __future__ import annotations

import time

from truthvouch.governance.guards.base import Guard
from truthvouch.governance.models import GuardContext, GuardResult, GuardVerdict


class BannedPhrasesGuard(Guard):
    """Guard that blocks text containing any configured banned phrase.

    Phrase matching is case-insensitive substring search.  Phrases come
    from ``context.config.banned_phrases``, which is refreshed periodically
    from the bootstrap/policy endpoint.
    """

    @property
    def name(self) -> str:
        """Guard identifier.

        Returns:
            ``"banned_phrases"``
        """
        return "banned_phrases"

    def evaluate(self, text: str, direction: str, context: GuardContext) -> GuardResult:
        """Check text for banned phrases.

        Args:
            text: Text to evaluate.
            direction: ``"input"`` or ``"output"``.
            context: Evaluation context with current policy config.

        Returns:
            GuardResult with PASS or BLOCK verdict.
        """
        start = time.monotonic()

        banned_phrases: list[str] = context.config.banned_phrases
        if not banned_phrases:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"matched_phrases": []},
                duration_ms=(time.monotonic() - start) * 1000,
                message="",
            )

        lower_text = text.lower()
        matched: list[str] = [
            phrase for phrase in banned_phrases
            if phrase.lower() in lower_text
        ]

        duration_ms = (time.monotonic() - start) * 1000

        if not matched:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"matched_phrases": []},
                duration_ms=duration_ms,
                message="",
            )

        message = (
            f"Banned phrase(s) detected: {', '.join(repr(p) for p in matched)}. "
            "Request blocked by policy."
        )
        return GuardResult(
            guard_name=self.name,
            verdict=GuardVerdict.BLOCK,
            details={"matched_phrases": matched},
            duration_ms=duration_ms,
            message=message,
        )
