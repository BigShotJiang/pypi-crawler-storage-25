"""Remote truth nugget verification guard.

Calls POST /api/v1/sdk/verify to check whether an LLM output contains
hallucinated or unverifiable claims.

Only active on ``direction="output"`` and when
``context.config.truth_scan_enabled`` is True.

Trust score mapping:
    >= 0.80 → PASS
    >= 0.50 → FLAG
    <  0.50 → BLOCK
"""

from __future__ import annotations

import logging
import time
from typing import Any

from truthvouch.exceptions import GuardError
from truthvouch.governance.guards.base import Guard
from truthvouch.governance.http import GUARD_TIMEOUT
from truthvouch.governance.models import GuardContext, GuardResult, GuardVerdict

logger = logging.getLogger(__name__)


class TruthGuard(Guard):
    """Remote guard that verifies LLM output against truth nuggets.

    Args:
        http_client: An HttpClient instance for making API calls.
    """

    def __init__(self, http_client: Any) -> None:
        """Initialise the truth guard.

        Args:
            http_client: HttpClient or compatible object with a .post() method.
        """
        self._http = http_client

    @property
    def name(self) -> str:
        """Guard identifier.

        Returns:
            ``"truth"``
        """
        return "truth"

    @property
    def is_local(self) -> bool:
        """Whether this guard runs in-process.

        Returns:
            False — this guard makes remote API calls.
        """
        return False

    def evaluate(self, text: str, direction: str, context: GuardContext) -> GuardResult:
        """Call the verify endpoint and return a verdict based on trust score.

        Only runs for output direction when truth_scan_enabled is True.
        If the API call fails, returns FLAG (fail open to avoid blocking
        on infrastructure issues).

        Args:
            text: LLM output text to verify.
            direction: ``"input"`` or ``"output"``.
            context: Evaluation context with config and model info.

        Returns:
            GuardResult with PASS, FLAG, or BLOCK verdict.
        """
        start = time.monotonic()

        # Only verify outputs
        if direction != "output":
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"skipped": "input direction not verified"},
                duration_ms=(time.monotonic() - start) * 1000,
                message="",
            )

        if not context.config.truth_scan_enabled:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"skipped": "truth_scan_enabled is False"},
                duration_ms=(time.monotonic() - start) * 1000,
                message="",
            )

        try:
            response = self._http.post(
                "/api/v1/sdk/verify",
                body={"text": text, "model": context.model},
                timeout=GUARD_TIMEOUT,
            )
        except Exception as exc:
            logger.warning("TruthGuard: verify API call failed: %s — failing open", exc)
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.FLAG,
                details={"error": str(exc), "failed_open": True},
                duration_ms=(time.monotonic() - start) * 1000,
                message="Truth verification unavailable; review output manually.",
            )

        duration_ms = (time.monotonic() - start) * 1000

        try:
            trust_score = float(response.get("trustScore", response.get("trust_score", 0.0)))
        except (TypeError, ValueError) as exc:
            raise GuardError(
                f"TruthGuard: unexpected response format: {response}", guard_name=self.name
            ) from exc

        details: dict[str, Any] = {
            "trust_score": trust_score,
            "model": context.model,
            "response": response,
        }

        if trust_score >= 0.80:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details=details,
                duration_ms=duration_ms,
                message="",
            )

        if trust_score >= 0.50:
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.FLAG,
                details=details,
                duration_ms=duration_ms,
                message=(
                    f"Output trust score {trust_score:.2f} is below 0.80. "
                    "Review for potential hallucinations."
                ),
            )

        return GuardResult(
            guard_name=self.name,
            verdict=GuardVerdict.BLOCK,
            details=details,
            duration_ms=duration_ms,
            message=(
                f"Output trust score {trust_score:.2f} is below 0.50. "
                "High hallucination risk — output blocked."
            ),
        )
