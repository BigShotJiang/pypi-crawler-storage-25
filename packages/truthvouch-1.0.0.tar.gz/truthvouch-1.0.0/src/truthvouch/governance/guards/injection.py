"""Prompt injection detection guard.

Two-layer heuristic detector — no LLM calls.

Layer 1: 15+ compiled regex patterns (direct override, role-switching,
         system markers, jailbreak, safety bypass, delimiter injection,
         prompt leaking).
Layer 2: Composite heuristic scoring — instruction density, role-switching
         vocabulary, delimiter anomalies. Threshold: 0.55.

Verdict mapping:
    Layer 1 pattern confidence >= 0.90 → BLOCK
    Layer 1 pattern confidence <  0.90 → FLAG
    Layer 2 composite      >= 0.55 → FLAG
    No detection                   → PASS

Patterns are a deliberate copy from
``src/governance-gateway/gateway/scanners/injection_detector.py`` — the SDK
is a standalone deployment unit with its own release cycle.
"""

from __future__ import annotations

import base64
import binascii
import re
import time
import unicodedata
from urllib.parse import unquote

from truthvouch.governance.guards.base import Guard
from truthvouch.governance.models import GuardContext, GuardResult, GuardVerdict

# ---------------------------------------------------------------------------
# Version constant
# ---------------------------------------------------------------------------

PATTERN_VERSION = "1.0.0"

# ---------------------------------------------------------------------------
# Layer 1 — regex patterns
# Each entry: (compiled_pattern, injection_type, base_confidence, description)
# ---------------------------------------------------------------------------

_LAYER1_PATTERNS: list[tuple[re.Pattern[str], str, float, str]] = [
    (
        re.compile(r"\bignore\s+(all\s+)?previous\s+instructions?\b", re.IGNORECASE),
        "direct", 0.95, "ignore previous instructions",
    ),
    (
        re.compile(r"\bforget\s+(everything|all\s+(previous|prior))\b", re.IGNORECASE),
        "direct", 0.92, "forget everything directive",
    ),
    (
        re.compile(r"\bnew\s+instructions?\s*:", re.IGNORECASE),
        "direct", 0.90, "new instructions override",
    ),
    (
        re.compile(
            r"\bdo\s+not\s+follow\b.{0,40}(rules?|instructions?|guidelines?)",
            re.IGNORECASE,
        ),
        "direct", 0.90, "do not follow rules directive",
    ),
    (
        re.compile(r"\byou\s+are\s+now\b", re.IGNORECASE),
        "jailbreak", 0.88, "you are now persona switch",
    ),
    (
        re.compile(
            r"\bact\s+as\b.{0,60}(assistant|ai|bot|gpt|claude|llm|model)",
            re.IGNORECASE,
        ),
        "jailbreak", 0.85, "act as persona override",
    ),
    (
        re.compile(r"\bpretend\s+(you\s+are|to\s+be)\b", re.IGNORECASE),
        "jailbreak", 0.82, "pretend to be persona override",
    ),
    (
        re.compile(r"\byour\s+(new\s+)?(role|persona|identity|name)\s+is\b", re.IGNORECASE),
        "jailbreak", 0.87, "role/persona reassignment",
    ),
    (
        re.compile(r"(^|\n)\s*SYSTEM\s*:\s*\S", re.MULTILINE),
        "indirect", 0.85, "SYSTEM: role marker injection",
    ),
    (
        re.compile(r"(^|\n)\s*system\s*:\s*\S", re.MULTILINE),
        "indirect", 0.82, "system: role marker injection (lowercase)",
    ),
    (
        re.compile(r"\[SYSTEM\]|\<SYSTEM\>|<<SYSTEM>>", re.IGNORECASE),
        "indirect", 0.80, "bracketed SYSTEM tag injection",
    ),
    (
        re.compile(
            r"\b(developer|dev|god|jailbreak|dan|dna|unrestricted|uncensored)\s+mode\b",
            re.IGNORECASE,
        ),
        "jailbreak", 0.90, "special mode activation attempt",
    ),
    (
        re.compile(
            r"\b(disregard|override|bypass|circumvent)\s+(your\s+)?(rules?|ethics?|"
            r"restrictions?|constraints?|guidelines?|safety)\b",
            re.IGNORECASE,
        ),
        "jailbreak", 0.92, "explicit safety bypass directive",
    ),
    (
        re.compile(
            r"\byou\s+(must|should|will)\s+(now\s+)?(ignore|forget|disregard)\b",
            re.IGNORECASE,
        ),
        "direct", 0.88, "must ignore directive",
    ),
    (
        re.compile(
            r"\b(disable|turn\s+off|remove)\s+(your\s+)?(filter|safety|restriction|"
            r"limitation|guard)\b",
            re.IGNORECASE,
        ),
        "jailbreak", 0.91, "safety filter disable attempt",
    ),
    (
        re.compile(
            r"---+\s*(END|BEGIN|OVERRIDE|IGNORE)\s*(PROMPT|CONTEXT|INSTRUCTIONS?)\s*---+",
            re.IGNORECASE,
        ),
        "indirect", 0.80, "hidden delimiter injection",
    ),
    (
        re.compile(
            r"\b(repeat|print|output|reveal|show|tell\s+me)\s+(your\s+)?"
            r"(system\s+prompt|instructions?|original\s+prompt|base\s+prompt)\b",
            re.IGNORECASE,
        ),
        "indirect", 0.78, "system prompt extraction attempt",
    ),
]

# ---------------------------------------------------------------------------
# Layer 2 — heuristic constants
# ---------------------------------------------------------------------------

_IMPERATIVE_VERBS: frozenset[str] = frozenset([
    "ignore", "forget", "disregard", "override", "bypass", "circumvent",
    "pretend", "act", "roleplay", "simulate", "impersonate", "become",
    "respond", "answer", "reply", "output", "print", "write", "generate",
    "reveal", "show", "tell", "list", "describe", "explain", "summarize",
    "translate", "convert", "change", "switch", "reset", "restart",
    "disable", "enable", "remove", "delete", "execute", "run", "do",
    "stop", "start", "always", "never",
])

_ROLE_SWITCH_VOCAB: frozenset[str] = frozenset([
    "you are", "you're", "you will be", "your name is", "your role is",
    "your persona is", "your identity is", "act as", "acting as",
    "pretend you are", "pretend to be", "role-play as", "roleplay as",
    "masquerade as", "pose as", "speak as", "respond as",
    "now you are", "from now on you are", "henceforth you are",
])

_BASE64_BLOCK_RE = re.compile(r"[A-Za-z0-9+/]{20,}={0,2}")
_HEX_BLOCK_RE = re.compile(r"(?:0x)?[0-9a-fA-F]{20,}")
_URL_ENCODE_RE = re.compile(r"(?:%[0-9a-fA-F]{2}){5,}")
_CODE_BLOCK_RE = re.compile(r"```[\s\S]{0,2000}?```")
_HTML_ROLE_RE = re.compile(
    r"<\s*(system|assistant|user|instruction)\s*>|role\s*=\s*[\"']?(system|assistant)[\"']?",
    re.IGNORECASE,
)
_XML_ROLE_RE = re.compile(
    r"<\s*(prompt|instruction|command|directive|task)\s*>",
    re.IGNORECASE,
)
_DELIMITER_RE = re.compile(r"([=\-|#*]{5,})")

_UNICODE_CONFUSABLE_MAP: dict[str, str] = {
    "\u0069\u0307": "i",
    "\u0456": "i",
    "\u0435": "e",
    "\u0430": "a",
    "\u043e": "o",
    "\u0440": "r",
    "\u0441": "c",
    "\u0445": "x",
    "\u0443": "y",
}

_INJECTION_KEYWORDS: list[str] = [
    "ignore", "forget", "system", "instructions", "override", "bypass",
    "jailbreak", "developer mode", "act as", "you are now", "pretend",
]

# Layer 2 scoring thresholds
_LAYER2_THRESHOLD = 0.55
_DENSITY_WEIGHT = 0.30
_ROLE_WEIGHT = 0.50
_DELIMITER_WEIGHT = 0.20


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _normalize_text(text: str) -> str:
    """Normalize Unicode and replace homoglyphs.

    Args:
        text: Raw input text.

    Returns:
        NFKC-normalized text with known homoglyphs replaced.
    """
    normalized = unicodedata.normalize("NFKC", text)
    for confusable, replacement in _UNICODE_CONFUSABLE_MAP.items():
        normalized = normalized.replace(confusable, replacement)
    return normalized


def _contains_injection_keywords(text: str) -> bool:
    """Check decoded payload for injection-related keywords.

    Args:
        text: Text to check.

    Returns:
        True if any injection keyword is present.
    """
    lower = text.lower()
    return any(kw in lower for kw in _INJECTION_KEYWORDS)


def _try_decode_base64(block: str) -> str | None:
    """Attempt to decode a base64 block.

    Args:
        block: Candidate base64 string.

    Returns:
        Decoded UTF-8 text if successful, None otherwise.
    """
    padding = 4 - len(block) % 4
    if padding != 4:
        block = block + "=" * padding
    try:
        return base64.b64decode(block).decode("utf-8", errors="ignore")
    except (binascii.Error, ValueError):
        return None


def _detect_encoded_injections(text: str) -> tuple[bool, str]:
    """Scan for base64/hex/URL-encoded blocks hiding injection payloads.

    Args:
        text: Normalized input text.

    Returns:
        Tuple of (detected, detail_message).
    """
    for match in _BASE64_BLOCK_RE.finditer(text):
        decoded = _try_decode_base64(match.group())
        if decoded and _contains_injection_keywords(decoded):
            return True, f"Base64-encoded injection payload (preview: {decoded[:80]!r})"

    for match in _HEX_BLOCK_RE.finditer(text):
        block = match.group().lstrip("0x")
        if len(block) % 2 == 0:
            try:
                decoded = bytes.fromhex(block).decode("utf-8", errors="ignore")
                if _contains_injection_keywords(decoded):
                    return True, f"Hex-encoded injection payload (preview: {decoded[:80]!r})"
            except ValueError:
                pass

    for match in _URL_ENCODE_RE.finditer(text):
        try:
            decoded = unquote(match.group())
            if _contains_injection_keywords(decoded):
                return True, f"URL-encoded injection payload (preview: {decoded[:80]!r})"
        except Exception:
            pass

    return False, ""


def _score_instruction_density(text: str) -> float:
    """Score density of imperative instruction verbs.

    Args:
        text: Normalized input text.

    Returns:
        Density score in [0.0, 1.0].
    """
    words = re.findall(r"\b\w+\b", text.lower())
    if not words:
        return 0.0
    count = sum(1 for w in words if w in _IMPERATIVE_VERBS)
    return min(1.0, count / max(1, len(words)))


def _score_role_switching(text: str) -> float:
    """Score likelihood of role-switching / persona redefinition.

    Args:
        text: Normalized input text.

    Returns:
        Score in [0.0, 1.0].
    """
    lower = text.lower()
    hits = sum(1 for phrase in _ROLE_SWITCH_VOCAB if phrase in lower)
    return min(1.0, hits * 0.45)


def _score_delimiter_anomalies(text: str) -> float:
    """Detect unusual delimiter patterns used to smuggle instructions.

    Args:
        text: Input text.

    Returns:
        Score in [0.0, 1.0].
    """
    score = 0.0

    for match in _CODE_BLOCK_RE.finditer(text):
        if _contains_injection_keywords(match.group()):
            score = max(score, 0.70)

    if _HTML_ROLE_RE.search(text):
        score = max(score, 0.75)

    if _XML_ROLE_RE.search(text):
        score = max(score, 0.72)

    if len(_DELIMITER_RE.findall(text)) >= 3:
        score = max(score, 0.40)

    return score


# ---------------------------------------------------------------------------
# Guard class
# ---------------------------------------------------------------------------


class InjectionGuard(Guard):
    """Local prompt injection detection guard.

    Runs Layer 1 regex patterns then Layer 2 heuristic scoring if no
    pattern match. Thread-safe — no instance state is mutated.
    """

    @property
    def name(self) -> str:
        """Guard identifier.

        Returns:
            ``"injection"``
        """
        return "injection"

    def evaluate(self, text: str, direction: str, context: GuardContext) -> GuardResult:
        """Evaluate text for prompt injection attempts.

        Args:
            text: Text to evaluate.
            direction: ``"input"`` or ``"output"``.
            context: Evaluation context.

        Returns:
            GuardResult with PASS, FLAG, or BLOCK verdict.
        """
        if not context.config.injection_check_enabled:
            return GuardResult(guard_name=self.name, verdict=GuardVerdict.PASS)

        start = time.monotonic()

        if not text or not text.strip():
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.PASS,
                details={"layer": 0},
                duration_ms=(time.monotonic() - start) * 1000,
                message="",
            )

        normalized = _normalize_text(text)

        # Layer 1 — regex patterns
        for pattern, inj_type, confidence, description in _LAYER1_PATTERNS:
            if pattern.search(normalized):
                verdict = GuardVerdict.BLOCK if confidence >= 0.90 else GuardVerdict.FLAG
                duration_ms = (time.monotonic() - start) * 1000
                return GuardResult(
                    guard_name=self.name,
                    verdict=verdict,
                    details={
                        "layer": 1,
                        "injection_type": inj_type,
                        "confidence": confidence,
                        "description": description,
                        "pattern_version": PATTERN_VERSION,
                    },
                    duration_ms=duration_ms,
                    message=f"Injection pattern detected: {description} (confidence={confidence:.2f})",
                )

        # Layer 2 — encoding detection
        encoding_detected, encoding_detail = _detect_encoded_injections(normalized)
        if encoding_detected:
            duration_ms = (time.monotonic() - start) * 1000
            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.FLAG,
                details={
                    "layer": 2,
                    "injection_type": "encoding",
                    "confidence": 0.85,
                    "description": encoding_detail,
                    "pattern_version": PATTERN_VERSION,
                },
                duration_ms=duration_ms,
                message=f"Encoded injection payload detected: {encoding_detail}",
            )

        # Layer 2 — composite heuristic scoring
        density = _score_instruction_density(normalized)
        role = _score_role_switching(normalized)
        delimiters = _score_delimiter_anomalies(normalized)
        composite = density * _DENSITY_WEIGHT + role * _ROLE_WEIGHT + delimiters * _DELIMITER_WEIGHT

        duration_ms = (time.monotonic() - start) * 1000

        if composite >= _LAYER2_THRESHOLD:
            if role >= delimiters and role >= density:
                inj_type = "jailbreak"
                dominant = f"role-switching score={role:.2f}"
            elif delimiters >= density:
                inj_type = "indirect"
                dominant = f"delimiter anomaly score={delimiters:.2f}"
            else:
                inj_type = "indirect"
                dominant = f"instruction density score={density:.2f}"

            return GuardResult(
                guard_name=self.name,
                verdict=GuardVerdict.FLAG,
                details={
                    "layer": 2,
                    "injection_type": inj_type,
                    "confidence": round(composite, 3),
                    "density_score": density,
                    "role_score": role,
                    "delimiter_score": delimiters,
                    "composite_score": composite,
                    "pattern_version": PATTERN_VERSION,
                },
                duration_ms=duration_ms,
                message=f"Heuristic injection signal: {dominant} (composite={composite:.2f})",
            )

        return GuardResult(
            guard_name=self.name,
            verdict=GuardVerdict.PASS,
            details={
                "layer": 0,
                "composite_score": round(composite, 3),
                "pattern_version": PATTERN_VERSION,
            },
            duration_ms=duration_ms,
            message="",
        )
