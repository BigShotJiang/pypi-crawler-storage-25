"""Guard base class and related abstractions."""

from __future__ import annotations

from abc import ABC, abstractmethod

from truthvouch.governance.models import GuardContext, GuardResult


class Guard(ABC):
    """Abstract base class for all TruthVouch guards.

    Guards are stateless. Any configuration they need is read from the
    GuardContext passed to evaluate(). This makes guards safe to share
    across threads.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Stable identifier for this guard.

        Returns:
            Snake-case guard name (e.g. ``"pii_regex"``).
        """
        ...

    @property
    def is_local(self) -> bool:
        """Whether this guard runs entirely in-process.

        Local guards never make network calls and should complete in <5ms.
        Remote guards call TruthVouch API endpoints.

        Returns:
            True for local guards (default); override to False for remote.
        """
        return True

    @abstractmethod
    def evaluate(self, text: str, direction: str, context: GuardContext) -> GuardResult:
        """Evaluate a piece of text.

        Args:
            text: The text to evaluate.
            direction: Either ``"input"`` (user/tool prompt) or
                ``"output"`` (LLM response).
            context: Current evaluation context including policy config.

        Returns:
            GuardResult with verdict, details, and an optional message.
        """
        ...
