"""
TruthVouch SDK — Circuit Breaker + Retry Logic.

The circuit breaker protects the caller from repeatedly hammering a down gateway.

States:
  CLOSED   — normal operation; all calls pass through.
  OPEN     — gateway is failing; calls are blocked or bypassed depending on fail_mode.
  HALF_OPEN — recovery probe; one call is allowed through to test recovery.

Transitions:
  CLOSED  → OPEN:       after `threshold` consecutive failures.
  OPEN    → HALF_OPEN:  after `recovery_seconds` have elapsed.
  HALF_OPEN → CLOSED:   on a successful probe call.
  HALF_OPEN → OPEN:     on a failed probe call.

Retry policy:
  Exponential backoff with jitter: delay = base * (2 ** attempt) + random(0, jitter).
  HTTP 429 / 503 are retried; 400 / 401 / 403 are NOT retried.
"""

from __future__ import annotations

import asyncio
import random
import time
from enum import Enum
from typing import Any, Callable, TypeVar

from truthvouch.exceptions import GatewayUnreachableError

T = TypeVar("T")

# ---------------------------------------------------------------------------
# Circuit breaker states
# ---------------------------------------------------------------------------


class CircuitState(Enum):
    """Circuit breaker state machine states."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


# ---------------------------------------------------------------------------
# Circuit breaker
# ---------------------------------------------------------------------------


class CircuitBreaker:
    """Thread-safe async circuit breaker for Governance Gateway calls.

    Example:
        breaker = CircuitBreaker(threshold=5, recovery_seconds=60, fail_mode="open")
        result = await breaker.call(my_async_function, arg1, kwarg=val)
    """

    def __init__(
        self,
        threshold: int = 5,
        recovery_seconds: float = 60.0,
        fail_mode: str = "open",
    ) -> None:
        """Initialise the circuit breaker.

        Args:
            threshold: Consecutive failures before circuit opens.
            recovery_seconds: Seconds before attempting recovery (half-open).
            fail_mode: "open" (bypass gateway) or "closed" (raise error).
        """
        self.threshold = threshold
        self.recovery_seconds = recovery_seconds
        self.fail_mode = fail_mode

        self._state: CircuitState = CircuitState.CLOSED
        self._failure_count: int = 0
        self._last_failure_time: float = 0.0
        self._lock = asyncio.Lock()

    @property
    def state(self) -> CircuitState:
        """Current circuit breaker state."""
        return self._state

    @property
    def is_open(self) -> bool:
        """True when the circuit is OPEN (gateway bypassed/blocked)."""
        return self._state == CircuitState.OPEN

    async def call(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Execute func through the circuit breaker.

        If the circuit is OPEN and recovery_seconds have not elapsed, either
        bypasses (fail_mode="open") or raises GatewayUnreachableError.

        Args:
            func: Async callable to wrap.
            *args: Positional arguments for func.
            **kwargs: Keyword arguments for func.

        Returns:
            Return value of func.

        Raises:
            GatewayUnreachableError: When fail_mode="closed" and circuit is open.
        """
        async with self._lock:
            if self._state == CircuitState.OPEN:
                if time.monotonic() - self._last_failure_time >= self.recovery_seconds:
                    self._state = CircuitState.HALF_OPEN
                else:
                    if self.fail_mode == "closed":
                        raise GatewayUnreachableError(
                            "Governance Gateway circuit breaker is open"
                        )
                    # fail_mode="open": signal caller to bypass
                    raise _CircuitOpenBypass("circuit open — bypass gateway")

        try:
            result = await func(*args, **kwargs)
            await self._on_success()
            return result
        except _CircuitOpenBypass:
            raise
        except GatewayUnreachableError:
            await self._on_failure()
            raise
        except Exception:
            await self._on_failure()
            raise

    async def _on_success(self) -> None:
        """Reset the circuit after a successful call."""
        async with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0

    async def _on_failure(self) -> None:
        """Increment failure count and possibly open the circuit."""
        async with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.monotonic()
            if self._failure_count >= self.threshold:
                self._state = CircuitState.OPEN


class _CircuitOpenBypass(Exception):
    """Internal sentinel raised when fail_mode='open' and circuit is open."""


# ---------------------------------------------------------------------------
# Retry helper
# ---------------------------------------------------------------------------

# HTTP status codes that should be retried
_RETRYABLE_STATUS_CODES: frozenset[int] = frozenset({429, 500, 502, 503, 504})

# HTTP status codes that should NEVER be retried
_NON_RETRYABLE_STATUS_CODES: frozenset[int] = frozenset({400, 401, 403, 404, 422})


async def retry_with_backoff(
    func: Callable[..., Any],
    *args: Any,
    max_retries: int = 3,
    base_delay: float = 0.5,
    max_delay: float = 10.0,
    jitter: float = 0.5,
    retryable_exceptions: tuple[type[Exception], ...] = (GatewayUnreachableError,),
    **kwargs: Any,
) -> Any:
    """Execute func with exponential backoff retry.

    Args:
        func: Async callable to execute.
        *args: Positional arguments.
        max_retries: Maximum number of retry attempts.
        base_delay: Base delay in seconds before first retry.
        max_delay: Maximum delay cap in seconds.
        jitter: Maximum random jitter to add to delay.
        retryable_exceptions: Exception types that trigger a retry.
        **kwargs: Keyword arguments.

    Returns:
        Return value of func on success.

    Raises:
        Last exception after max_retries attempts are exhausted.
    """
    last_exc: Exception | None = None

    for attempt in range(max_retries + 1):
        try:
            return await func(*args, **kwargs)
        except tuple(retryable_exceptions) as exc:  # type: ignore[misc]
            last_exc = exc
            if attempt >= max_retries:
                break
            delay = min(base_delay * (2**attempt) + random.uniform(0, jitter), max_delay)
            await asyncio.sleep(delay)
        except Exception:
            raise  # Non-retryable — propagate immediately

    raise last_exc  # type: ignore[misc]


def is_retryable_status(status_code: int) -> bool:
    """Return True if the HTTP status code warrants a retry.

    Args:
        status_code: HTTP response status code.

    Returns:
        True if retryable, False otherwise.
    """
    return status_code in _RETRYABLE_STATUS_CODES
