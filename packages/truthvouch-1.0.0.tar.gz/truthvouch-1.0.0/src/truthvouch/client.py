"""
TruthVouch SDK — Core client.

TruthVouch is the main entry point. It manages:
- Connection lifecycle (persistent httpx.AsyncClient)
- Provider-specific facades (OpenAI, Anthropic, Google AI)
- Batch scan client
- Circuit breaker
- Context manager support (async with)
"""

from __future__ import annotations

from typing import Any

from truthvouch.batch import BatchScanClient
from truthvouch.config import TruthVouchConfig
from truthvouch.providers.anthropic import AnthropicProvider
from truthvouch.providers.google import GoogleAIProvider
from truthvouch.providers.openai import OpenAIProvider, ChatCompletionsClient
from truthvouch.resilience import CircuitBreaker, _CircuitOpenBypass
from truthvouch.transport.rest import RestTransport
from truthvouch.exceptions import GatewayUnreachableError


class TruthVouch:
    """Main TruthVouch SDK client.

    Manages HTTP transport, circuit breaker, and provider facades.
    Supports both direct instantiation and async context manager usage.

    Example (direct):
        client = TruthVouch(gateway_url="https://gateway.example.com", api_key="tv_...")
        await client.connect()
        resp = await client.openai.chat.completions.create(model="gpt-4o", messages=[...])
        await client.close()

    Example (context manager):
        async with TruthVouch(gateway_url=..., api_key=...) as client:
            resp = await client.openai.chat.completions.create(...)
    """

    def __init__(
        self,
        gateway_url: str,
        api_key: str,
        fail_mode: str = "open",
        timeout: float = 30.0,
        max_retries: int = 3,
        circuit_breaker_threshold: int = 5,
        circuit_breaker_recovery_seconds: float = 60.0,
        verify_ssl: bool = True,
    ) -> None:
        """Initialise the TruthVouch client.

        Args:
            gateway_url: Base URL of the Governance Gateway (required).
                Example: "https://gateway.truthvouch.com"
            api_key: API key for authentication (required). Never hardcode — use env vars.
            fail_mode: "open" (bypass gateway on failure) or "closed" (raise error).
            timeout: HTTP request timeout in seconds. Default 30.
            max_retries: Maximum retry attempts for transient errors. Default 3.
            circuit_breaker_threshold: Consecutive failures before circuit opens. Default 5.
            circuit_breaker_recovery_seconds: Recovery probe interval in seconds. Default 60.
            verify_ssl: Verify TLS certificates. Default True.
        """
        self._config = TruthVouchConfig(
            gateway_url=gateway_url,
            api_key=api_key,
            fail_mode=fail_mode,  # type: ignore[arg-type]
            timeout=timeout,
            max_retries=max_retries,
            circuit_breaker_threshold=circuit_breaker_threshold,
            circuit_breaker_recovery_seconds=circuit_breaker_recovery_seconds,
            verify_ssl=verify_ssl,
        )
        self._transport = RestTransport(
            gateway_url=self._config.gateway_url,
            api_key=self._config.api_key,
            timeout=self._config.timeout,
            max_retries=self._config.max_retries,
            verify_ssl=self._config.verify_ssl,
        )
        self._circuit_breaker = CircuitBreaker(
            threshold=self._config.circuit_breaker_threshold,
            recovery_seconds=self._config.circuit_breaker_recovery_seconds,
            fail_mode=self._config.fail_mode,
        )

        # Provider facades — share the same transport instance
        self._openai = OpenAIProvider(self._transport)
        self._anthropic = AnthropicProvider(self._transport)
        self._google = GoogleAIProvider(self._transport)
        self._batch = BatchScanClient(self._transport)

        # Convenience: direct chat.completions interface (OpenAI-style default)
        self._chat = self._openai.chat

    # ── Context manager ──

    async def __aenter__(self) -> "TruthVouch":
        await self.connect()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ── Connection lifecycle ──

    async def connect(self) -> None:
        """Open the underlying HTTP connection pool.

        Called automatically by the async context manager. Only needed when
        using the client without `async with`.
        """
        await self._transport.connect()

    async def close(self) -> None:
        """Close the underlying HTTP connection pool and release resources.

        Called automatically by the async context manager. Only needed when
        using the client without `async with`.
        """
        await self._transport.close()

    # ── Provider facades ──

    @property
    def openai(self) -> OpenAIProvider:
        """OpenAI-compatible provider facade.

        Usage: client.openai.chat.completions.create(...)
        """
        return self._openai

    @property
    def anthropic(self) -> AnthropicProvider:
        """Anthropic-compatible provider facade.

        Usage: client.anthropic.messages.create(...)
        """
        return self._anthropic

    @property
    def google(self) -> GoogleAIProvider:
        """Google AI-compatible provider facade.

        Usage: client.google.generate_content(...)
        """
        return self._google

    @property
    def chat(self) -> Any:
        """Direct chat.completions interface (OpenAI-compatible default).

        Usage: client.chat.completions.create(...)
        """
        return self._chat

    @property
    def batch(self) -> BatchScanClient:
        """Batch scan client.

        Usage:
            job = await client.batch.submit(source_url=..., format="jsonl")
            status = await client.batch.get_status(job.id)
        """
        return self._batch

    @property
    def circuit_breaker(self) -> CircuitBreaker:
        """Underlying circuit breaker instance (read-only)."""
        return self._circuit_breaker

    @property
    def config(self) -> TruthVouchConfig:
        """Immutable configuration snapshot."""
        return self._config
