"""
TruthVouch SDK — GovernanceReport dataclass.

Every response from the Governance Gateway includes a GovernanceReport that
describes the full policy verdict, PII/injection detection, and truth scan results.

The report is attached as the `governance` attribute on chat completion responses
and as `governance_report` on the final chunk of a streaming response.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class GovernanceReport:
    """Full governance metadata returned by the Governance Gateway.

    Attributes:
        verdict: Overall policy decision — "allowed", "blocked", or "flagged".
        pii_detected: True if personally identifiable information was detected in
            either the request or the response.
        injection_detected: True if a prompt injection attempt was detected.
        truth_scan: Truth-check results, or None if truth scanning was not performed.
            When present: {"confidence": float, "contradictions": list[str]}.
        policy_violations: List of policy rule names that were triggered.
        overhead_ms: Time added by the governance pipeline in milliseconds.
        request_id: Gateway-assigned request ID for distributed tracing.
    """

    verdict: str = "allowed"
    pii_detected: bool = False
    injection_detected: bool = False
    truth_scan: dict[str, Any] | None = None
    policy_violations: list[str] = field(default_factory=list)
    overhead_ms: float = 0.0
    request_id: str = ""

    @classmethod
    def from_gateway_response(cls, data: dict[str, Any]) -> "GovernanceReport":
        """Parse a GovernanceReport from a gateway JSON response payload.

        Args:
            data: Raw dict from the gateway's governance metadata section.

        Returns:
            Populated GovernanceReport.
        """
        return cls(
            verdict=data.get("verdict", "allowed"),
            pii_detected=bool(data.get("pii_detected", False)),
            injection_detected=bool(data.get("injection_detected", False)),
            truth_scan=data.get("truth_scan"),
            policy_violations=list(data.get("policy_violations", [])),
            overhead_ms=float(data.get("overhead_ms", 0.0)),
            request_id=str(data.get("request_id", "")),
        )

    @classmethod
    def blocked(
        cls,
        violations: list[str],
        request_id: str = "",
        overhead_ms: float = 0.0,
    ) -> "GovernanceReport":
        """Create a 'blocked' GovernanceReport for convenience.

        Args:
            violations: List of policy rule names that triggered the block.
            request_id: Gateway request ID.
            overhead_ms: Gateway processing time in milliseconds.

        Returns:
            GovernanceReport with verdict="blocked".
        """
        return cls(
            verdict="blocked",
            policy_violations=violations,
            request_id=request_id,
            overhead_ms=overhead_ms,
        )
