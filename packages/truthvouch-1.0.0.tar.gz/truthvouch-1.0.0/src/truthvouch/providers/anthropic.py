"""
TruthVouch SDK — Anthropic-compatible provider wrapper.

Drop-in replacement for anthropic.Anthropic().messages.create():
  Before: client = anthropic.Anthropic()
  After:  client = TruthVouch(...).anthropic

The gateway translates Anthropic message format to the upstream provider and back.
The response mirrors the anthropic.types.Message structure with an extra
.governance attribute.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, AsyncGenerator

from truthvouch.models import GovernanceReport
from truthvouch.streaming import ChatChunk, stream_chat_completions
from truthvouch.transport.rest import RestTransport

# Gateway request format uses OpenAI-style messages; the gateway translates.
# The SDK adds a provider hint so the gateway routes to Anthropic.
_ANTHROPIC_PROVIDER_HINT = "anthropic"


# ---------------------------------------------------------------------------
# Response models mirroring Anthropic SDK structure
# ---------------------------------------------------------------------------


@dataclass
class ContentBlock:
    """A single content block in an Anthropic response (type: "text")."""

    type: str = "text"
    text: str = ""


@dataclass
class AnthropicUsage:
    """Token usage mirrors anthropic.types.Usage."""

    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class GovernedAnthropicResponse:
    """Anthropic Message response with governance metadata.

    Mirrors anthropic.types.Message with an extra .governance attribute.

    Attributes:
        id: Message ID.
        model: Model that generated the response.
        role: Always "assistant" for responses.
        content: List of ContentBlock objects.
        stop_reason: Why the model stopped ("end_turn", "max_tokens", etc.).
        usage: Token usage.
        governance: GovernanceReport with policy verdict, PII, and truth scan results.
    """

    id: str = ""
    model: str = ""
    role: str = "assistant"
    content: list[ContentBlock] = field(default_factory=list)
    stop_reason: str = "end_turn"
    usage: AnthropicUsage = field(default_factory=AnthropicUsage)
    governance: GovernanceReport = field(default_factory=GovernanceReport)

    @property
    def text(self) -> str:
        """Convenience accessor for the concatenated text of all content blocks."""
        return "".join(block.text for block in self.content if block.type == "text")


# ---------------------------------------------------------------------------
# MessagesClient
# ---------------------------------------------------------------------------


class MessagesClient:
    """Anthropic messages-compatible interface routing through the gateway.

    Access via TruthVouch(...).anthropic.messages.
    """

    _PATH = "/v1/proxy/chat/completions"
    _STREAM_PATH = "/v1/proxy/chat/completions/stream"

    def __init__(self, transport: RestTransport) -> None:
        """Initialise with a shared transport instance.

        Args:
            transport: RestTransport for HTTP communication with the gateway.
        """
        self._transport = transport

    async def create(
        self,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int = 1024,
        system: str | None = None,
        stream: bool = False,
        temperature: float | None = None,
        **kwargs: Any,
    ) -> GovernedAnthropicResponse | AsyncGenerator[ChatChunk, None]:
        """Create an Anthropic message (mirroring anthropic.messages.create).

        Args:
            model: Anthropic model ID (e.g. "claude-3.5-sonnet-20241022").
            messages: Conversation messages in Anthropic format.
            max_tokens: Maximum output tokens. Required for Anthropic. Default 1024.
            system: Optional system prompt text.
            stream: If True, return an async generator of ChatChunk objects.
            temperature: Optional temperature override.
            **kwargs: Additional parameters forwarded to the gateway.

        Returns:
            GovernedAnthropicResponse for non-streaming calls.
            AsyncGenerator[ChatChunk, None] for streaming calls.
        """
        # Convert Anthropic messages to OpenAI format for the gateway
        openai_messages = _convert_to_openai_messages(messages, system)

        body: dict[str, Any] = {
            "model": model,
            "messages": openai_messages,
            "max_tokens": max_tokens,
            "provider_hint": _ANTHROPIC_PROVIDER_HINT,
            **kwargs,
        }
        if temperature is not None:
            body["temperature"] = temperature

        if stream:
            return self._stream(body)
        return await self._complete(body)

    async def _complete(self, body: dict[str, Any]) -> GovernedAnthropicResponse:
        data = await self._transport.post(self._PATH, json_body=body)
        return _parse_anthropic_response(data)

    async def _stream(self, body: dict[str, Any]) -> AsyncGenerator[ChatChunk, None]:
        byte_stream = self._transport.post_stream(self._STREAM_PATH, json_body=body)
        async for chunk in stream_chat_completions(byte_stream):
            yield chunk


# ---------------------------------------------------------------------------
# AnthropicProvider facade
# ---------------------------------------------------------------------------


class AnthropicProvider:
    """Anthropic-compatible provider facade.

    Exposes a .messages.create() interface identical to the Anthropic SDK.

    Example:
        client = TruthVouch(gateway_url=..., api_key=...)
        resp = await client.anthropic.messages.create(
            model="claude-3.5-sonnet-20241022",
            messages=[{"role": "user", "content": "Hello"}],
            max_tokens=512,
        )
        print(resp.text)
        print(resp.governance.verdict)
    """

    def __init__(self, transport: RestTransport) -> None:
        """Initialise with a shared transport instance."""
        self.messages = MessagesClient(transport)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _convert_to_openai_messages(
    anthropic_messages: list[dict[str, Any]],
    system: str | None,
) -> list[dict[str, Any]]:
    """Convert Anthropic message format to OpenAI format for the gateway.

    Args:
        anthropic_messages: Messages in Anthropic format.
        system: Optional system prompt.

    Returns:
        Messages list in OpenAI format.
    """
    openai_messages: list[dict[str, Any]] = []

    if system:
        openai_messages.append({"role": "system", "content": system})

    for msg in anthropic_messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        # Anthropic content can be a list of blocks; extract text
        if isinstance(content, list):
            text = " ".join(
                block.get("text", "") for block in content if block.get("type") == "text"
            )
        else:
            text = str(content)
        openai_messages.append({"role": role, "content": text})

    return openai_messages


def _parse_anthropic_response(data: dict[str, Any]) -> GovernedAnthropicResponse:
    """Parse a raw gateway response dict into a GovernedAnthropicResponse.

    Args:
        data: Raw dict from the gateway chat completions endpoint.

    Returns:
        GovernedAnthropicResponse with content blocks and governance.
    """
    # Extract text from OpenAI-format response
    choices = data.get("choices", [])
    text = ""
    stop_reason = "end_turn"
    if choices:
        msg = choices[0].get("message", {})
        text = msg.get("content", "")
        finish = choices[0].get("finish_reason", "stop")
        stop_reason = "end_turn" if finish == "stop" else finish

    usage_raw = data.get("usage", {})
    usage = AnthropicUsage(
        input_tokens=int(usage_raw.get("prompt_tokens", 0)),
        output_tokens=int(usage_raw.get("completion_tokens", 0)),
    )

    governance = GovernanceReport.from_gateway_response(data.get("governance", {}))

    return GovernedAnthropicResponse(
        id=data.get("id", ""),
        model=data.get("model", ""),
        content=[ContentBlock(type="text", text=text)],
        stop_reason=stop_reason,
        usage=usage,
        governance=governance,
    )
