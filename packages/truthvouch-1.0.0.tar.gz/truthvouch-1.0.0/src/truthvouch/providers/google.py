"""
TruthVouch SDK — Google AI-compatible provider wrapper.

Drop-in replacement for google.generativeai.GenerativeModel().generate_content():
  Before: model = genai.GenerativeModel("gemini-1.5-pro")
  After:  client = TruthVouch(...).google

The gateway translates Google AI format to the upstream provider and back.
The response mirrors google.generativeai.types.GenerateContentResponse with
an extra .governance attribute.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, AsyncGenerator

from truthvouch.models import GovernanceReport
from truthvouch.streaming import ChatChunk, stream_chat_completions
from truthvouch.transport.rest import RestTransport

_GOOGLE_PROVIDER_HINT = "google"


# ---------------------------------------------------------------------------
# Response models mirroring Google AI SDK structure
# ---------------------------------------------------------------------------


@dataclass
class GooglePart:
    """A single part in a Google AI response (text part)."""

    text: str = ""


@dataclass
class GoogleContent:
    """Content block in a Google AI response."""

    role: str = "model"
    parts: list[GooglePart] = field(default_factory=list)


@dataclass
class GoogleCandidate:
    """A single candidate in a Google AI response."""

    index: int = 0
    content: GoogleContent = field(default_factory=GoogleContent)
    finish_reason: str = "STOP"


@dataclass
class GovernedGoogleResponse:
    """Google AI GenerateContent response with governance metadata.

    Mirrors google.generativeai.types.GenerateContentResponse with an extra
    .governance attribute.

    Attributes:
        candidates: List of generated candidates.
        governance: GovernanceReport with policy verdict, PII, and truth scan results.
    """

    candidates: list[GoogleCandidate] = field(default_factory=list)
    governance: GovernanceReport = field(default_factory=GovernanceReport)

    @property
    def text(self) -> str:
        """Convenience accessor for the text of the first candidate's first part."""
        if self.candidates and self.candidates[0].content.parts:
            return self.candidates[0].content.parts[0].text
        return ""

    @property
    def parts(self) -> list[GooglePart]:
        """Convenience accessor for the first candidate's parts."""
        if self.candidates:
            return self.candidates[0].content.parts
        return []


# ---------------------------------------------------------------------------
# GenerativeModelClient
# ---------------------------------------------------------------------------


class GenerativeModelClient:
    """Google AI generate_content-compatible interface routing through the gateway.

    Access via TruthVouch(...).google.
    """

    _PATH = "/v1/proxy/chat/completions"
    _STREAM_PATH = "/v1/proxy/chat/completions/stream"

    def __init__(self, transport: RestTransport, default_model: str = "gemini-1.5-pro") -> None:
        """Initialise with a shared transport instance.

        Args:
            transport: RestTransport for HTTP communication with the gateway.
            default_model: Default model to use when not specified per-call.
        """
        self._transport = transport
        self._default_model = default_model

    async def generate_content(
        self,
        contents: str | list[Any],
        model: str | None = None,
        stream: bool = False,
        generation_config: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> GovernedGoogleResponse | AsyncGenerator[ChatChunk, None]:
        """Generate content (mirroring google.generativeai.GenerativeModel.generate_content).

        Args:
            contents: Input prompt — either a string or a list of content parts.
            model: Model identifier (e.g. "gemini-1.5-pro"). Uses default if None.
            stream: If True, return an async generator of ChatChunk objects.
            generation_config: Optional generation config dict
                (e.g. {"temperature": 0.7, "max_output_tokens": 1024}).
            **kwargs: Additional parameters forwarded to the gateway.

        Returns:
            GovernedGoogleResponse for non-streaming calls.
            AsyncGenerator[ChatChunk, None] for streaming calls.
        """
        effective_model = model or self._default_model

        # Convert Google contents format to OpenAI messages format
        messages = _convert_contents_to_messages(contents)

        body: dict[str, Any] = {
            "model": effective_model,
            "messages": messages,
            "provider_hint": _GOOGLE_PROVIDER_HINT,
            **kwargs,
        }

        if generation_config:
            if "temperature" in generation_config:
                body["temperature"] = generation_config["temperature"]
            if "max_output_tokens" in generation_config:
                body["max_tokens"] = generation_config["max_output_tokens"]

        if stream:
            return self._stream(body)
        return await self._complete(body)

    async def _complete(self, body: dict[str, Any]) -> GovernedGoogleResponse:
        data = await self._transport.post(self._PATH, json_body=body)
        return _parse_google_response(data)

    async def _stream(self, body: dict[str, Any]) -> AsyncGenerator[ChatChunk, None]:
        byte_stream = self._transport.post_stream(self._STREAM_PATH, json_body=body)
        async for chunk in stream_chat_completions(byte_stream):
            yield chunk


# ---------------------------------------------------------------------------
# GoogleAIProvider facade
# ---------------------------------------------------------------------------


class GoogleAIProvider:
    """Google AI-compatible provider facade.

    Exposes a .generate_content() interface similar to the Google AI SDK.

    Example:
        client = TruthVouch(gateway_url=..., api_key=...)
        resp = await client.google.generate_content(
            "Explain quantum computing",
            model="gemini-1.5-pro",
        )
        print(resp.text)
        print(resp.governance.verdict)
    """

    def __init__(self, transport: RestTransport, default_model: str = "gemini-1.5-pro") -> None:
        """Initialise with a shared transport instance.

        Args:
            transport: RestTransport for HTTP communication.
            default_model: Default Gemini model to use.
        """
        self._client = GenerativeModelClient(transport, default_model=default_model)

    async def generate_content(
        self,
        contents: str | list[Any],
        model: str | None = None,
        stream: bool = False,
        generation_config: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> GovernedGoogleResponse | AsyncGenerator[ChatChunk, None]:
        """Generate content routed through the Governance Gateway.

        See GenerativeModelClient.generate_content for full documentation.
        """
        return await self._client.generate_content(
            contents=contents,
            model=model,
            stream=stream,
            generation_config=generation_config,
            **kwargs,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _convert_contents_to_messages(
    contents: str | list[Any],
) -> list[dict[str, Any]]:
    """Convert Google AI contents format to OpenAI messages format.

    Args:
        contents: String prompt or list of Google AI content objects.

    Returns:
        Messages list in OpenAI format.
    """
    if isinstance(contents, str):
        return [{"role": "user", "content": contents}]

    messages: list[dict[str, Any]] = []
    for item in contents:
        if isinstance(item, str):
            messages.append({"role": "user", "content": item})
        elif isinstance(item, dict):
            role = item.get("role", "user")
            parts = item.get("parts", [])
            text = " ".join(
                p.get("text", "") if isinstance(p, dict) else str(p) for p in parts
            )
            # Google uses "model" for assistant role
            openai_role = "assistant" if role == "model" else role
            messages.append({"role": openai_role, "content": text})

    return messages or [{"role": "user", "content": str(contents)}]


def _parse_google_response(data: dict[str, Any]) -> GovernedGoogleResponse:
    """Parse a raw gateway response dict into a GovernedGoogleResponse.

    Args:
        data: Raw dict from the gateway chat completions endpoint.

    Returns:
        GovernedGoogleResponse with candidates and governance.
    """
    choices = data.get("choices", [])
    candidates = []
    for choice in choices:
        msg = choice.get("message", {})
        text = msg.get("content", "")
        finish = choice.get("finish_reason", "stop")
        candidates.append(
            GoogleCandidate(
                index=choice.get("index", 0),
                content=GoogleContent(
                    role="model",
                    parts=[GooglePart(text=text)],
                ),
                finish_reason="STOP" if finish == "stop" else finish.upper(),
            )
        )

    governance = GovernanceReport.from_gateway_response(data.get("governance", {}))

    return GovernedGoogleResponse(
        candidates=candidates,
        governance=governance,
    )
