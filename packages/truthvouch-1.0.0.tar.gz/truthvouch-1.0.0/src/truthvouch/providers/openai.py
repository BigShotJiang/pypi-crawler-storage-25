"""
TruthVouch SDK — OpenAI-compatible provider wrapper.

Drop-in replacement for openai.OpenAI / openai.AsyncOpenAI:
  Before: client = openai.OpenAI()
  After:  client = TruthVouch(...).openai

The wrapper has the same API surface as the OpenAI Python SDK's ChatCompletion
interface but routes every call through the Governance Gateway.

Streaming:
  stream=True returns an async generator that yields ChatChunk objects.
  The final chunk carries governance_report.

Response model:
  Non-streaming responses return a GovernedChatResponse whose fields mirror
  the OpenAI ChatCompletion response object (choices, usage, model, id).
  The extra .governance attribute carries the GovernanceReport.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, AsyncGenerator

from truthvouch.models import GovernanceReport
from truthvouch.streaming import ChatChunk, stream_chat_completions
from truthvouch.transport.rest import RestTransport


# ---------------------------------------------------------------------------
# Response models mirroring OpenAI SDK structure
# ---------------------------------------------------------------------------


@dataclass
class MessageContent:
    """Content of a chat message (mirrors openai.types.chat.ChatCompletionMessage)."""

    role: str = "assistant"
    content: str = ""


@dataclass
class Choice:
    """A single completion choice (mirrors openai.types.chat.Choice)."""

    index: int = 0
    message: MessageContent = field(default_factory=MessageContent)
    finish_reason: str = "stop"


@dataclass
class Usage:
    """Token usage statistics (mirrors openai.types.CompletionUsage)."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class GovernedChatResponse:
    """Chat completion response with governance metadata.

    Mirrors the openai.ChatCompletion response object with an extra
    .governance attribute carrying the GovernanceReport.

    Attributes:
        id: Completion ID.
        model: Model that generated the response.
        choices: List of completion choices (usually one).
        usage: Token usage statistics.
        governance: GovernanceReport with policy verdict, PII, and truth scan results.
    """

    id: str = ""
    model: str = ""
    choices: list[Choice] = field(default_factory=list)
    usage: Usage = field(default_factory=Usage)
    governance: GovernanceReport = field(default_factory=GovernanceReport)

    @property
    def content(self) -> str:
        """Convenience accessor for the first choice's message content."""
        if self.choices:
            return self.choices[0].message.content
        return ""


# ---------------------------------------------------------------------------
# ChatCompletionsClient
# ---------------------------------------------------------------------------


class ChatCompletionsClient:
    """OpenAI chat.completions-compatible interface routing through the gateway.

    This class is not instantiated directly — access it via TruthVouch(...).chat.
    """

    _PATH = "/v1/proxy/chat/completions"
    _STREAM_PATH = "/v1/proxy/chat/completions/stream"

    def __init__(self, transport: RestTransport) -> None:
        """Initialise with a shared transport instance.

        Args:
            transport: RestTransport for HTTP communication with the gateway.
        """
        self._transport = transport

    async def create(
        self,
        model: str,
        messages: list[dict[str, Any]],
        stream: bool = False,
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> GovernedChatResponse | AsyncGenerator[ChatChunk, None]:
        """Create a chat completion (mirroring openai.chat.completions.create).

        Args:
            model: LLM model identifier (e.g. "gpt-4o", "claude-3.5-sonnet").
            messages: Conversation messages in OpenAI format.
            stream: If True, return an async generator of ChatChunk objects.
            temperature: Optional temperature override (0.0–2.0).
            max_tokens: Optional max output tokens.
            **kwargs: Additional provider-specific parameters forwarded to the gateway.

        Returns:
            GovernedChatResponse for non-streaming calls.
            AsyncGenerator[ChatChunk, None] for streaming calls.

        Raises:
            PolicyBlockedError: If governance policy blocks the request.
            AuthenticationError: If the API key is invalid.
            GatewayUnreachableError: If the gateway cannot be reached.
            UpstreamProviderError: If the LLM provider returns an error.
        """
        body: dict[str, Any] = {
            "model": model,
            "messages": messages,
            **kwargs,
        }
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens is not None:
            body["max_tokens"] = max_tokens

        if stream:
            return self._stream(body)
        return await self._complete(body)

    async def _complete(self, body: dict[str, Any]) -> GovernedChatResponse:
        """Execute a non-streaming chat completion request.

        Args:
            body: Request body dict.

        Returns:
            GovernedChatResponse with governance metadata.
        """
        data = await self._transport.post(self._PATH, json_body=body)
        return _parse_chat_response(data)

    async def _stream(
        self, body: dict[str, Any]
    ) -> AsyncGenerator[ChatChunk, None]:
        """Execute a streaming chat completion request.

        Args:
            body: Request body dict.

        Yields:
            ChatChunk objects; final chunk has done=True and governance_report set.
        """
        byte_stream = self._transport.post_stream(self._STREAM_PATH, json_body=body)
        async for chunk in stream_chat_completions(byte_stream):
            yield chunk


# ---------------------------------------------------------------------------
# OpenAI provider facade
# ---------------------------------------------------------------------------


class OpenAIProvider:
    """OpenAI-compatible provider facade.

    Exposes a .chat.completions.create() interface identical to the OpenAI SDK.

    Example:
        client = TruthVouch(gateway_url=..., api_key=...)
        resp = await client.openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
        print(resp.choices[0].message.content)
        print(resp.governance.verdict)
    """

    def __init__(self, transport: RestTransport) -> None:
        """Initialise with a shared transport instance.

        Args:
            transport: RestTransport for HTTP communication.
        """
        self.chat = _ChatNamespace(transport)


class _ChatNamespace:
    """Namespace mirroring the openai.chat namespace."""

    def __init__(self, transport: RestTransport) -> None:
        self.completions = ChatCompletionsClient(transport)


# ---------------------------------------------------------------------------
# Response parser
# ---------------------------------------------------------------------------


def _parse_chat_response(data: dict[str, Any]) -> GovernedChatResponse:
    """Parse a raw gateway response dict into a GovernedChatResponse.

    Args:
        data: Raw dict from the gateway chat completions endpoint.

    Returns:
        GovernedChatResponse with choices, usage, and governance.
    """
    choices = []
    for raw in data.get("choices", []):
        msg_raw = raw.get("message", {})
        choices.append(
            Choice(
                index=raw.get("index", 0),
                message=MessageContent(
                    role=msg_raw.get("role", "assistant"),
                    content=msg_raw.get("content", ""),
                ),
                finish_reason=raw.get("finish_reason", "stop"),
            )
        )

    usage_raw = data.get("usage", {})
    usage = Usage(
        prompt_tokens=int(usage_raw.get("prompt_tokens", 0)),
        completion_tokens=int(usage_raw.get("completion_tokens", 0)),
        total_tokens=int(usage_raw.get("total_tokens", 0)),
    )

    governance_raw = data.get("governance", {})
    governance = GovernanceReport.from_gateway_response(governance_raw)

    return GovernedChatResponse(
        id=data.get("id", ""),
        model=data.get("model", ""),
        choices=choices,
        usage=usage,
        governance=governance,
    )
