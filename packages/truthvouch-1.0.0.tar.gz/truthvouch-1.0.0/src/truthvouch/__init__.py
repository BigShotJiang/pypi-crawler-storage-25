"""TruthVouch Python SDK — drop-in LLM governance for Python.

Quick start:
    from truthvouch import TruthVouch

    async with TruthVouch(gateway_url="https://gateway.truthvouch.com", api_key="tv_...") as client:
        resp = await client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "What is quantum computing?"}],
        )
        print(resp.choices[0].message.content)
        print(resp.governance.verdict)   # "allowed"

See README.md for full documentation and examples.
"""

from truthvouch._version import __version__
from truthvouch.client import TruthVouch
from truthvouch.models import GovernanceReport
from truthvouch.exceptions import (
    TruthVouchError,
    AuthenticationError,
    BootstrapError,
    GatewayUnreachableError,
    GovernanceBlockError,
    GuardError,
    InvalidRequestError,
    PolicyBlockedError,
    QuotaExceededError,
    TelemetryError,
    TierUpgradeRequired,
    UpstreamProviderError,
)

__all__ = [
    "__version__",
    "TruthVouch",
    "GovernanceReport",
    # Exceptions
    "TruthVouchError",
    "AuthenticationError",
    "BootstrapError",
    "GatewayUnreachableError",
    "GovernanceBlockError",
    "GuardError",
    "InvalidRequestError",
    "PolicyBlockedError",
    "QuotaExceededError",
    "TelemetryError",
    "TierUpgradeRequired",
    "UpstreamProviderError",
]
