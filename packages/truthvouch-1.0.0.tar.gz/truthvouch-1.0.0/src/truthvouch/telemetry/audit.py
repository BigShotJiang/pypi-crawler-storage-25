"""AuditBuffer and AsyncAuditBuffer — background telemetry batch push."""

from __future__ import annotations

import asyncio
import logging
import queue
import threading
import time
from typing import Any

from truthvouch.governance.models import Event

logger = logging.getLogger(__name__)

# AuditBuffer (sync) constants
_MAX_QUEUE_SIZE = 10_000
_BATCH_SIZE = 100
_FLUSH_INTERVAL_S = 5.0
_SHUTDOWN_FLUSH_TIMEOUT_S = 5.0
_RETRY_DELAY_S = 1.0


class AuditBuffer:
    """Thread-safe background audit event buffer.

    Collects governance events, then batch-pushes them to the telemetry
    endpoint on a background daemon thread.  Designed to have negligible
    impact on the caller's hot path.

    Overflow policy: when the queue reaches _MAX_QUEUE_SIZE, the oldest
    event is dropped to make room for the new one.

    Args:
        http_client: An HttpClient instance (sync) with a .post() method.
        flush_interval_s: How many seconds between automatic flushes.
    """

    def __init__(self, http_client: Any, flush_interval_s: float = _FLUSH_INTERVAL_S) -> None:
        """Initialise the AuditBuffer and start the background flush thread.

        Args:
            http_client: HTTP client for posting telemetry batches.
            flush_interval_s: Seconds between background flushes.
        """
        self._http = http_client
        self._flush_interval_s = flush_interval_s
        self._queue: queue.Queue[Event] = queue.Queue(maxsize=_MAX_QUEUE_SIZE)
        self._stop_event = threading.Event()
        self._thread = threading.Thread(
            target=self._flush_loop,
            name="truthvouch-audit-buffer",
            daemon=True,
        )
        self._thread.start()

    def push(self, event: Event) -> None:
        """Add an event to the buffer.

        If the queue is full, the oldest event is dropped and the new event
        is added (overflow = drop oldest).

        Args:
            event: Governance event to buffer.
        """
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            # Drop the oldest event to make room
            try:
                self._queue.get_nowait()
                logger.warning(
                    "AuditBuffer: queue full (%d events); dropping oldest event",
                    _MAX_QUEUE_SIZE,
                )
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait(event)
            except queue.Full:
                pass  # Best-effort drop

    def shutdown(self, timeout_s: float = _SHUTDOWN_FLUSH_TIMEOUT_S) -> None:
        """Signal the background thread to stop and flush remaining events.

        Args:
            timeout_s: Maximum seconds to wait for the final flush.
        """
        self._stop_event.set()
        self._thread.join(timeout=timeout_s)
        # Do one final synchronous flush of anything remaining
        self._flush_batch()

    def _flush_loop(self) -> None:
        """Background thread main loop.

        Sleeps for flush_interval_s between flushes, then drains up to
        _BATCH_SIZE events per cycle.
        """
        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=self._flush_interval_s)
            self._flush_batch()

    def _drain_batch(self) -> list[Event]:
        """Drain up to _BATCH_SIZE events from the queue non-blocking.

        Returns:
            List of Event objects ready to send.
        """
        batch: list[Event] = []
        while len(batch) < _BATCH_SIZE:
            try:
                batch.append(self._queue.get_nowait())
            except queue.Empty:
                break
        return batch

    def _flush_batch(self) -> None:
        """Drain the queue and POST events to the telemetry endpoint.

        Retries once after _RETRY_DELAY_S on failure.  Drops the batch
        after one retry to avoid blocking the thread indefinitely.
        """
        batch = self._drain_batch()
        if not batch:
            return

        payload = [event.to_dict() for event in batch]
        success = self._post_batch(payload)

        if not success:
            logger.warning(
                "AuditBuffer: telemetry push failed; retrying once in %ss", _RETRY_DELAY_S
            )
            time.sleep(_RETRY_DELAY_S)
            self._post_batch(payload)  # Second attempt; drop on failure

    def _post_batch(self, payload: list[dict[str, Any]]) -> bool:
        """POST a batch of events to /api/v1/sdk/telemetry.

        Args:
            payload: List of serialized event dicts.

        Returns:
            True if the POST succeeded, False otherwise.
        """
        try:
            self._http.post("/api/v1/sdk/telemetry", body={"events": payload})
            logger.debug("AuditBuffer: flushed %d events", len(payload))
            return True
        except Exception as exc:
            logger.warning("AuditBuffer: telemetry push failed: %s", exc)
            return False

    @property
    def queue_size(self) -> int:
        """Current number of events waiting to be flushed.

        Returns:
            Approximate queue depth (non-blocking).
        """
        return self._queue.qsize()


class AsyncAuditBuffer:
    """Async counterpart to AuditBuffer — uses asyncio.Queue and asyncio.Task.

    Args:
        http_client: An AsyncHttpClient instance.
        flush_interval_s: Seconds between automatic flushes.
    """

    _MAX_QUEUE_SIZE = 10_000
    _BATCH_SIZE = 100
    _RETRY_DELAY_S = 1.0

    def __init__(self, http_client: Any, flush_interval_s: float = 5.0) -> None:
        """Initialise the async audit buffer.

        Args:
            http_client: Async HTTP client for posting telemetry batches.
            flush_interval_s: Seconds between flushes.
        """
        self._http = http_client
        self._flush_interval_s = flush_interval_s
        self._queue: asyncio.Queue[Event] = asyncio.Queue(maxsize=self._MAX_QUEUE_SIZE)
        self._flush_task: asyncio.Task[None] | None = None

    def start(self) -> None:
        """Start the background flush task.

        Must be called from within a running event loop.
        """
        self._flush_task = asyncio.create_task(self._flush_loop(), name="truthvouch-audit-buffer")

    def push(self, event: Event) -> None:
        """Add an event to the buffer (non-blocking).

        Drops the oldest event on overflow.

        Args:
            event: Governance event to buffer.
        """
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            try:
                self._queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
            try:
                self._queue.put_nowait(event)
            except asyncio.QueueFull:
                pass

    async def shutdown(self, timeout_s: float = 5.0) -> None:
        """Stop the flush task and do a final flush.

        Args:
            timeout_s: Maximum seconds to wait.
        """
        if self._flush_task is not None:
            self._flush_task.cancel()
            try:
                await asyncio.wait_for(asyncio.shield(self._flush_task), timeout=timeout_s)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        await self._flush_batch()

    async def _flush_loop(self) -> None:
        """Background coroutine that flushes on an interval."""
        while True:
            await asyncio.sleep(self._flush_interval_s)
            await self._flush_batch()

    async def _flush_batch(self) -> None:
        """Drain queue and POST to telemetry endpoint."""
        batch: list[Event] = []
        while len(batch) < self._BATCH_SIZE:
            try:
                batch.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break

        if not batch:
            return

        payload = [e.to_dict() for e in batch]
        success = await self._post_batch(payload)
        if not success:
            await asyncio.sleep(self._RETRY_DELAY_S)
            await self._post_batch(payload)

    async def _post_batch(self, payload: list[dict[str, Any]]) -> bool:
        """POST a batch to /api/v1/sdk/telemetry.

        Args:
            payload: Serialized event dicts.

        Returns:
            True on success.
        """
        try:
            await self._http.post("/api/v1/sdk/telemetry", body={"events": payload})
            return True
        except Exception as exc:
            logger.warning("AsyncAuditBuffer: telemetry push failed: %s", exc)
            return False
