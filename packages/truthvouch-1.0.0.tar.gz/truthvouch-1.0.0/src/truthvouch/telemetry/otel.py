"""
TruthVouch SDK — Optional Telemetry (OpenTelemetry + Prometheus).

Gracefully no-ops when opentelemetry or prometheus_client are not installed.
Import this module unconditionally — it will use no-op stubs when the
optional dependencies are absent.

OpenTelemetry:
  Wraps transport calls in spans with gateway URL and request metadata.

Prometheus:
  Exposes counters and histograms via prometheus_client.
  Metrics are only registered when prometheus_client is available.
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# OpenTelemetry — optional
# ---------------------------------------------------------------------------

try:
    from opentelemetry import trace
    from opentelemetry.trace import Span, Tracer

    _OTEL_AVAILABLE = True
    _tracer: Tracer = trace.get_tracer("truthvouch.sdk", "1.0.0")
except ImportError:
    _OTEL_AVAILABLE = False
    _tracer = None  # type: ignore[assignment]


def get_tracer() -> Any:
    """Return the OTel Tracer if opentelemetry is installed, else None.

    Returns:
        opentelemetry.trace.Tracer or None.
    """
    return _tracer


def start_span(name: str, attributes: dict[str, Any] | None = None) -> Any:
    """Start an OTel span if opentelemetry is installed.

    Args:
        name: Span name (e.g. "truthvouch.chat.completions").
        attributes: Optional span attributes.

    Returns:
        Context manager span, or a no-op context manager.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return _NoOpSpan()

    span = _tracer.start_span(name)
    if attributes:
        for key, value in attributes.items():
            span.set_attribute(key, value)
    return span


class _NoOpSpan:
    """No-op span context manager used when OTel is not installed."""

    def __enter__(self) -> "_NoOpSpan":
        return self

    def __exit__(self, *args: Any) -> None:
        pass

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def record_exception(self, exc: Exception) -> None:
        pass

    def set_status(self, status: Any) -> None:
        pass


# ---------------------------------------------------------------------------
# Prometheus — optional
# ---------------------------------------------------------------------------

try:
    from prometheus_client import Counter, Histogram

    _PROMETHEUS_AVAILABLE = True

    _request_counter = Counter(
        "truthvouch_requests_total",
        "Total number of Governance Gateway requests",
        ["method", "status"],
    )
    _latency_histogram = Histogram(
        "truthvouch_request_duration_seconds",
        "Governance Gateway request duration in seconds",
        ["method"],
        buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
    )
    _governance_overhead_histogram = Histogram(
        "truthvouch_governance_overhead_seconds",
        "Governance pipeline overhead in seconds",
        buckets=[0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5],
    )
    _circuit_breaker_counter = Counter(
        "truthvouch_circuit_breaker_trips_total",
        "Number of times the circuit breaker opened",
    )
    _policy_block_counter = Counter(
        "truthvouch_policy_blocks_total",
        "Number of requests blocked by governance policy",
    )

except ImportError:
    _PROMETHEUS_AVAILABLE = False
    _request_counter = None  # type: ignore[assignment]
    _latency_histogram = None  # type: ignore[assignment]
    _governance_overhead_histogram = None  # type: ignore[assignment]
    _circuit_breaker_counter = None  # type: ignore[assignment]
    _policy_block_counter = None  # type: ignore[assignment]


def record_request(method: str, status: str, duration_seconds: float) -> None:
    """Record a completed request in Prometheus (no-op if prometheus_client absent).

    Args:
        method: HTTP method or operation name (e.g. "chat.completions").
        status: Status label — "success", "error", "blocked".
        duration_seconds: Request duration in seconds.
    """
    if not _PROMETHEUS_AVAILABLE:
        return
    _request_counter.labels(method=method, status=status).inc()  # type: ignore[union-attr]
    _latency_histogram.labels(method=method).observe(duration_seconds)  # type: ignore[union-attr]


def record_governance_overhead(overhead_seconds: float) -> None:
    """Record governance pipeline overhead in Prometheus.

    Args:
        overhead_seconds: Governance overhead in seconds.
    """
    if not _PROMETHEUS_AVAILABLE:
        return
    _governance_overhead_histogram.observe(overhead_seconds)  # type: ignore[union-attr]


def record_circuit_breaker_trip() -> None:
    """Increment the circuit breaker trip counter in Prometheus."""
    if not _PROMETHEUS_AVAILABLE:
        return
    _circuit_breaker_counter.inc()  # type: ignore[union-attr]


def record_policy_block() -> None:
    """Increment the policy block counter in Prometheus."""
    if not _PROMETHEUS_AVAILABLE:
        return
    _policy_block_counter.inc()  # type: ignore[union-attr]


def is_otel_available() -> bool:
    """Return True if opentelemetry is installed and OTel tracing is active."""
    return _OTEL_AVAILABLE


def is_prometheus_available() -> bool:
    """Return True if prometheus_client is installed and metrics are registered."""
    return _PROMETHEUS_AVAILABLE
