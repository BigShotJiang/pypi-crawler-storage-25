"""TruthVouch SDK — Telemetry subsystem.

Exports audit event buffering (sync and async) and optional
OpenTelemetry / Prometheus instrumentation.
"""

from truthvouch.telemetry.audit import AuditBuffer, AsyncAuditBuffer

__all__ = ["AuditBuffer", "AsyncAuditBuffer"]

# OTel exports are intentionally NOT imported here to avoid pulling in
# optional dependencies at import time. Import from truthvouch.telemetry.otel
# directly when needed.
