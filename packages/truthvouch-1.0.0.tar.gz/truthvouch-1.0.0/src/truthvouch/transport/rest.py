"""
TruthVouch SDK — REST/HTTP Transport Layer.

Wraps httpx.AsyncClient with:
- Authorization header injection: Bearer {api_key}
- Retry with exponential backoff for transient errors
- Structured error mapping (4xx/5xx → TruthVouch exceptions)
- Connection pooling via persistent AsyncClient
"""

from __future__ import annotations

import json
from typing import Any, AsyncGenerator

import httpx

from truthvouch.exceptions import (
    AuthenticationError,
    GatewayUnreachableError,
    InvalidRequestError,
    PolicyBlockedError,
    QuotaExceededError,
    TruthVouchError,
    UpstreamProviderError,
)
from truthvouch.resilience import is_retryable_status, retry_with_backoff


class RestTransport:
    """Async HTTP transport for Governance Gateway REST API.

    Manages a persistent httpx.AsyncClient session with automatic auth header
    injection, retry logic, and gateway-specific error mapping.

    Usage:
        async with RestTransport(gateway_url=url, api_key=key) as transport:
            response = await transport.post("/v1/proxy/chat/completions", json=body)
    """

    def __init__(
        self,
        gateway_url: str,
        api_key: str,
        timeout: float = 30.0,
        max_retries: int = 3,
        verify_ssl: bool = True,
    ) -> None:
        """Initialise the REST transport.

        Args:
            gateway_url: Base URL of the Governance Gateway (no trailing slash).
            api_key: API key injected as Bearer token.
            timeout: Request timeout in seconds.
            max_retries: Max retry attempts for transient errors.
            verify_ssl: Verify TLS certificates.
        """
        self._gateway_url = gateway_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout
        self._max_retries = max_retries
        self._verify_ssl = verify_ssl
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "RestTransport":
        await self.connect()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def connect(self) -> None:
        """Open the underlying HTTP client connection pool."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._gateway_url,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "User-Agent": "truthvouch-python-sdk/1.0.0",
                },
                timeout=self._timeout,
                verify=self._verify_ssl,
            )

    async def close(self) -> None:
        """Close the underlying HTTP client and release connections."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def post(
        self,
        path: str,
        json_body: dict[str, Any],
    ) -> dict[str, Any]:
        """Send a POST request and return the parsed JSON response.

        Args:
            path: API path (e.g. "/v1/proxy/chat/completions").
            json_body: Request body to serialise as JSON.

        Returns:
            Parsed JSON response body as a dict.

        Raises:
            GatewayUnreachableError: On network timeout or connection error.
            AuthenticationError: On HTTP 401.
            PolicyBlockedError: On HTTP 403 with policy violation payload.
            QuotaExceededError: On HTTP 429.
            InvalidRequestError: On HTTP 400 or 422.
            UpstreamProviderError: On HTTP 502 from the upstream LLM provider.
            TruthVouchError: On other gateway errors.
        """
        await self._ensure_connected()

        async def _do_request() -> dict[str, Any]:
            try:
                resp = await self._client.post(path, json=json_body)  # type: ignore[union-attr]
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                raise GatewayUnreachableError(
                    f"Gateway connection failed: {type(exc).__name__}: {exc}"
                ) from exc

            return self._handle_response(resp)

        return await retry_with_backoff(
            _do_request,
            max_retries=self._max_retries,
            retryable_exceptions=(GatewayUnreachableError,),
        )

    async def get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a GET request and return the parsed JSON response.

        Args:
            path: API path (e.g. "/v1/scan/batch/{job_id}").
            params: Optional query parameters.

        Returns:
            Parsed JSON response body as a dict.

        Raises:
            GatewayUnreachableError: On network timeout or connection error.
            AuthenticationError: On HTTP 401.
            TruthVouchError: On other gateway errors.
        """
        await self._ensure_connected()

        async def _do_request() -> dict[str, Any]:
            try:
                resp = await self._client.get(path, params=params)  # type: ignore[union-attr]
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                raise GatewayUnreachableError(
                    f"Gateway connection failed: {type(exc).__name__}: {exc}"
                ) from exc
            return self._handle_response(resp)

        return await retry_with_backoff(
            _do_request,
            max_retries=self._max_retries,
            retryable_exceptions=(GatewayUnreachableError,),
        )

    async def post_stream(
        self,
        path: str,
        json_body: dict[str, Any],
    ) -> AsyncGenerator[bytes, None]:
        """Send a POST request and stream raw SSE bytes.

        Args:
            path: API path (e.g. "/v1/proxy/chat/completions/stream").
            json_body: Request body.

        Yields:
            Raw bytes of each SSE line as received.

        Raises:
            GatewayUnreachableError: On network / timeout error.
            AuthenticationError: On HTTP 401.
            TruthVouchError: On other gateway errors.
        """
        await self._ensure_connected()

        try:
            async with self._client.stream("POST", path, json=json_body) as response:  # type: ignore[union-attr]
                if response.status_code != 200:
                    content = await response.aread()
                    self._raise_for_status(response.status_code, content)
                async for chunk in response.aiter_bytes():
                    yield chunk
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            raise GatewayUnreachableError(
                f"Gateway streaming connection failed: {type(exc).__name__}: {exc}"
            ) from exc

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Parse response body and raise appropriate exception for error status codes.

        Args:
            response: httpx Response object.

        Returns:
            Parsed JSON dict.

        Raises:
            TruthVouchError subclass for error status codes.
        """
        self._raise_for_status(response.status_code, response.content)
        try:
            return response.json()
        except json.JSONDecodeError as exc:
            raise TruthVouchError(
                f"Gateway returned non-JSON response: {response.text[:200]}"
            ) from exc

    def _raise_for_status(self, status_code: int, content: bytes) -> None:
        """Map HTTP status codes to TruthVouch exceptions.

        Args:
            status_code: HTTP response status code.
            content: Raw response body bytes.

        Raises:
            Appropriate TruthVouchError subclass for error codes; does nothing on 2xx.
        """
        if status_code < 400:
            return

        # Attempt to parse error body for request_id and detail
        request_id: str | None = None
        detail: str = f"HTTP {status_code}"
        policy_violations: list[str] = []

        try:
            body = json.loads(content)
            request_id = body.get("request_id") or body.get("x-request-id")
            detail = body.get("detail") or body.get("message") or detail
            policy_violations = body.get("policy_violations", [])
        except (json.JSONDecodeError, AttributeError):
            pass

        if status_code == 401:
            raise AuthenticationError(
                message=detail,
                request_id=request_id,
            )
        if status_code == 403:
            raise PolicyBlockedError(
                message=detail,
                request_id=request_id,
            )
        if status_code == 429:
            raise QuotaExceededError(
                message=detail,
                request_id=request_id,
            )
        if status_code in (400, 422):
            raise InvalidRequestError(
                message=detail,
                request_id=request_id,
            )
        if status_code == 502:
            raise UpstreamProviderError(
                message=f"Upstream LLM provider error: {detail}",
                request_id=request_id,
            )
        if is_retryable_status(status_code):
            raise GatewayUnreachableError(
                message=f"Gateway temporarily unavailable: {detail}",
                request_id=request_id,
            )

        raise TruthVouchError(
            message=f"Gateway error {status_code}: {detail}",
            request_id=request_id,
        )

    async def _ensure_connected(self) -> None:
        """Lazily open the client connection pool if not already connected."""
        if self._client is None:
            await self.connect()
