"""Single source of truth for the SDK version string."""

__version__ = "1.0.0"
