"""
TruthVouch SDK — Streaming support.

Parses Server-Sent Events (SSE) from the Governance Gateway streaming endpoint
and yields ChatChunk objects. The final chunk carries the complete GovernanceReport.

SSE line format:
  data: {"choices":[{"delta":{"content":"..."}}], "governance": {...}, "done": false}

The last SSE line has "done": true and includes the full governance report.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator

from truthvouch.models import GovernanceReport


@dataclass
class DeltaContent:
    """A content delta from a streaming chunk."""

    content: str | None = None
    role: str | None = None


@dataclass
class StreamChoice:
    """A single choice within a streaming chunk."""

    index: int = 0
    delta: DeltaContent = field(default_factory=DeltaContent)
    finish_reason: str | None = None


@dataclass
class ChatChunk:
    """A single streaming chunk from the Governance Gateway.

    Attributes:
        id: Unique chunk identifier.
        model: The LLM model that produced this chunk.
        choices: List of streaming choices (usually one).
        governance_report: Populated on the final chunk; None for intermediate chunks.
        done: True for the last chunk in the stream.
    """

    id: str = ""
    model: str = ""
    choices: list[StreamChoice] = field(default_factory=list)
    governance_report: GovernanceReport | None = None
    done: bool = False

    @property
    def content(self) -> str:
        """Convenience accessor for the first choice's delta content."""
        if self.choices:
            return self.choices[0].delta.content or ""
        return ""


def _parse_sse_line(line: str) -> dict[str, Any] | None:
    """Parse a single SSE data line into a dict.

    Args:
        line: Raw SSE line string (may include "data: " prefix).

    Returns:
        Parsed dict if the line is a valid data event, None otherwise.
    """
    line = line.strip()
    if not line or line.startswith(":"):
        return None  # comment or heartbeat
    if line.startswith("data: "):
        data_str = line[6:]
        if data_str == "[DONE]":
            return None
        try:
            return json.loads(data_str)
        except json.JSONDecodeError:
            return None
    return None


def _dict_to_chunk(data: dict[str, Any]) -> ChatChunk:
    """Convert a parsed SSE data dict to a ChatChunk.

    Args:
        data: Parsed JSON dict from SSE event.

    Returns:
        ChatChunk with populated fields.
    """
    choices = []
    for raw_choice in data.get("choices", []):
        delta_raw = raw_choice.get("delta", {})
        delta = DeltaContent(
            content=delta_raw.get("content"),
            role=delta_raw.get("role"),
        )
        choices.append(
            StreamChoice(
                index=raw_choice.get("index", 0),
                delta=delta,
                finish_reason=raw_choice.get("finish_reason"),
            )
        )

    governance_report: GovernanceReport | None = None
    if "governance" in data and data.get("done", False):
        governance_report = GovernanceReport.from_gateway_response(data["governance"])

    return ChatChunk(
        id=data.get("id", ""),
        model=data.get("model", ""),
        choices=choices,
        governance_report=governance_report,
        done=bool(data.get("done", False)),
    )


async def stream_chat_completions(
    byte_stream: AsyncGenerator[bytes, None],
) -> AsyncGenerator[ChatChunk, None]:
    """Parse an SSE byte stream into ChatChunk objects.

    Args:
        byte_stream: Async generator of raw bytes from the transport layer.

    Yields:
        ChatChunk for each SSE data event. The final chunk has done=True and
        carries the GovernanceReport.

    Example:
        async for chunk in stream_chat_completions(transport.post_stream(...)):
            if chunk.content:
                print(chunk.content, end="", flush=True)
            if chunk.done:
                report = chunk.governance_report
    """
    buffer = ""

    async for raw_bytes in byte_stream:
        text = raw_bytes.decode("utf-8", errors="replace")
        buffer += text

        while "\n" in buffer:
            line, buffer = buffer.split("\n", 1)
            data = _parse_sse_line(line)
            if data is not None:
                chunk = _dict_to_chunk(data)
                yield chunk
                if chunk.done:
                    return

    # Flush any remaining buffer content
    if buffer.strip():
        data = _parse_sse_line(buffer)
        if data is not None:
            yield _dict_to_chunk(data)
