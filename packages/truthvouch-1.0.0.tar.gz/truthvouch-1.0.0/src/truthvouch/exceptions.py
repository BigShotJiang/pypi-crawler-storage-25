"""
TruthVouch SDK — Unified exception hierarchy.

All exceptions carry:
- error_code: machine-readable string from the TV_* or GOV_* namespace
- governance_report: GovernanceReport if available at the time of the error
- request_id: gateway request ID for tracing

Gateway error codes (TV_* namespace):
  TV_GATEWAY_UNREACHABLE  GatewayUnreachableError
  TV_POLICY_BLOCKED       PolicyBlockedError
  TV_AUTH_FAILED          AuthenticationError
  TV_QUOTA_EXCEEDED       QuotaExceededError
  TV_INVALID_REQUEST      InvalidRequestError
  TV_UPSTREAM_ERROR       UpstreamProviderError

Governance error codes (GOV_* namespace):
  GOV_BLOCKED             GovernanceBlockError
  GOV_GUARD_ERROR         GuardError
  GOV_BOOTSTRAP_FAILED    BootstrapError
  GOV_TIER_REQUIRED       TierUpgradeRequired
  GOV_TELEMETRY_ERROR     TelemetryError
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from truthvouch.models import GovernanceReport


class TruthVouchError(Exception):
    """Base exception for all TruthVouch SDK errors.

    Attributes:
        message: Human-readable error description.
        error_code: Machine-readable code from the TV_* or GOV_* namespace.
        governance_report: GovernanceReport if the gateway returned one before failing.
        request_id: Gateway request ID for distributed tracing.
    """

    def __init__(
        self,
        message: str,
        error_code: str | None = None,
        governance_report: Any = None,
        request_id: str | None = None,
    ) -> None:
        """Initialise TruthVouchError.

        Args:
            message: Human-readable error description.
            error_code: Machine-readable code (e.g. "TV_GATEWAY_UNREACHABLE").
            governance_report: GovernanceReport if available.
            request_id: Gateway request ID for tracing.
        """
        super().__init__(message)
        self.error_code = error_code
        self.governance_report = governance_report
        self.request_id = request_id

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"message={str(self)!r}, "
            f"error_code={self.error_code!r}, "
            f"request_id={self.request_id!r})"
        )


# ---------------------------------------------------------------------------
# Gateway exceptions (TV_* namespace)
# ---------------------------------------------------------------------------


class GatewayUnreachableError(TruthVouchError):
    """Raised when the Governance Gateway cannot be reached.

    In fail-open mode the SDK bypasses the gateway and calls the LLM directly.
    In fail-closed mode this exception is propagated to the caller.

    Error code: TV_GATEWAY_UNREACHABLE
    """

    def __init__(
        self,
        message: str = "Governance Gateway is unreachable",
        request_id: str | None = None,
    ) -> None:
        """Initialise GatewayUnreachableError.

        Args:
            message: Human-readable error description.
            request_id: Gateway request ID for tracing.
        """
        super().__init__(
            message=message,
            error_code="TV_GATEWAY_UNREACHABLE",
            request_id=request_id,
        )


class PolicyBlockedError(TruthVouchError):
    """Raised when the Governance Gateway blocks a request due to policy violation.

    The governance_report attribute contains the full policy verdict details.

    Error code: TV_POLICY_BLOCKED
    """

    def __init__(
        self,
        message: str = "Request blocked by governance policy",
        governance_report: Any = None,
        request_id: str | None = None,
    ) -> None:
        """Initialise PolicyBlockedError.

        Args:
            message: Human-readable error description.
            governance_report: GovernanceReport containing policy verdict details.
            request_id: Gateway request ID for tracing.
        """
        super().__init__(
            message=message,
            error_code="TV_POLICY_BLOCKED",
            governance_report=governance_report,
            request_id=request_id,
        )


class AuthenticationError(TruthVouchError):
    """Raised when the API key is invalid or expired.

    Error code: TV_AUTH_FAILED
    """

    def __init__(
        self,
        message: str = "Authentication failed: invalid or expired API key",
        request_id: str | None = None,
    ) -> None:
        """Initialise AuthenticationError.

        Args:
            message: Human-readable error description.
            request_id: Gateway request ID for tracing.
        """
        super().__init__(
            message=message,
            error_code="TV_AUTH_FAILED",
            request_id=request_id,
        )


class QuotaExceededError(TruthVouchError):
    """Raised when the gateway rate limit or quota has been exceeded.

    Attributes:
        retry_after_seconds: Number of seconds to wait before retrying, if provided
            by the gateway response. None if the gateway did not specify a back-off
            period.

    Error code: TV_QUOTA_EXCEEDED
    """

    def __init__(
        self,
        message: str = "API quota or rate limit exceeded",
        request_id: str | None = None,
        retry_after_seconds: float | None = None,
    ) -> None:
        """Initialise QuotaExceededError.

        Args:
            message: Human-readable error description.
            request_id: Gateway request ID for tracing.
            retry_after_seconds: Seconds to wait before retrying, or None if unknown.
        """
        super().__init__(
            message=message,
            error_code="TV_QUOTA_EXCEEDED",
            request_id=request_id,
        )
        self.retry_after_seconds = retry_after_seconds


class InvalidRequestError(TruthVouchError):
    """Raised when the request payload is malformed or missing required fields.

    Error code: TV_INVALID_REQUEST
    """

    def __init__(
        self,
        message: str = "Invalid request",
        request_id: str | None = None,
    ) -> None:
        """Initialise InvalidRequestError.

        Args:
            message: Human-readable error description.
            request_id: Gateway request ID for tracing.
        """
        super().__init__(
            message=message,
            error_code="TV_INVALID_REQUEST",
            request_id=request_id,
        )


class UpstreamProviderError(TruthVouchError):
    """Raised when the upstream LLM provider (OpenAI, Anthropic, etc.) returns an error.

    Attributes:
        upstream_status_code: HTTP status code returned by the upstream provider, or
            None if the error occurred before an HTTP response was received.

    Error code: TV_UPSTREAM_ERROR
    """

    def __init__(
        self,
        message: str = "Upstream LLM provider error",
        governance_report: Any = None,
        request_id: str | None = None,
        upstream_status_code: int | None = None,
    ) -> None:
        """Initialise UpstreamProviderError.

        Args:
            message: Human-readable error description.
            governance_report: GovernanceReport if available at the time of the error.
            request_id: Gateway request ID for tracing.
            upstream_status_code: HTTP status code from the upstream provider, or None.
        """
        super().__init__(
            message=message,
            error_code="TV_UPSTREAM_ERROR",
            governance_report=governance_report,
            request_id=request_id,
        )
        self.upstream_status_code = upstream_status_code


# ---------------------------------------------------------------------------
# Governance exceptions (GOV_* namespace)
# ---------------------------------------------------------------------------


class GovernanceBlockError(TruthVouchError):
    """Raised by framework adapters when a guard blocks a request.

    Attributes:
        block_reasons: List of human-readable reasons for the block.
        guard_results: Raw guard result details.

    Error code: GOV_BLOCKED
    """

    def __init__(
        self,
        message: str,
        block_reasons: list[str] | None = None,
        guard_results: list[dict] | None = None,
    ) -> None:
        """Initialise GovernanceBlockError.

        Args:
            message: Human-readable description.
            block_reasons: Reasons why the request was blocked.
            guard_results: Raw guard evaluation results.
        """
        super().__init__(message, error_code="GOV_BLOCKED")
        self.block_reasons = block_reasons or []
        self.guard_results = guard_results or []


class GuardError(TruthVouchError):
    """Raised when a guard evaluation fails unexpectedly.

    Attributes:
        guard_name: Name of the guard that failed.

    Error code: GOV_GUARD_ERROR
    """

    def __init__(self, message: str, guard_name: str = "") -> None:
        """Initialise GuardError.

        Args:
            message: Human-readable description of the failure.
            guard_name: Identifier of the guard that failed.
        """
        super().__init__(message, error_code="GOV_GUARD_ERROR")
        self.guard_name = guard_name


class BootstrapError(TruthVouchError):
    """Raised when the SDK cannot fetch bootstrap configuration from the API.

    Error code: GOV_BOOTSTRAP_FAILED
    """

    def __init__(self, message: str) -> None:
        """Initialise BootstrapError.

        Args:
            message: Human-readable error description.
        """
        super().__init__(message, error_code="GOV_BOOTSTRAP_FAILED")


class TierUpgradeRequired(TruthVouchError):
    """Raised when the client's tier does not support a requested feature.

    Attributes:
        current_tier: The client's current subscription tier.
        required_tier: The minimum tier needed for the feature.
        upgrade_url: URL to upgrade the subscription.

    Error code: GOV_TIER_REQUIRED
    """

    def __init__(
        self,
        message: str,
        current_tier: str = "",
        required_tier: str = "",
        upgrade_url: str = "",
    ) -> None:
        """Initialise TierUpgradeRequired.

        Args:
            message: Human-readable description of the limitation.
            current_tier: The client's current tier identifier.
            required_tier: The tier required to use the feature.
            upgrade_url: URL where the client can upgrade their plan.
        """
        super().__init__(message, error_code="GOV_TIER_REQUIRED")
        self.current_tier = current_tier
        self.required_tier = required_tier
        self.upgrade_url = upgrade_url


class TelemetryError(TruthVouchError):
    """Raised when a telemetry push fails.

    Error code: GOV_TELEMETRY_ERROR
    """

    def __init__(self, message: str) -> None:
        """Initialise TelemetryError.

        Args:
            message: Human-readable error description.
        """
        super().__init__(message, error_code="GOV_TELEMETRY_ERROR")
