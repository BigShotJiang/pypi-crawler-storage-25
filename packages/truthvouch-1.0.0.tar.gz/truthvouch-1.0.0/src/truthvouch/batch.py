"""
TruthVouch SDK — Batch Scan Client.

Submits document corpora for offline governance analysis and polls for results.

Endpoints:
  POST /v1/scan/batch          — submit a batch scan job
  GET  /v1/scan/batch/{job_id} — get job status and results

Batch jobs are asynchronous: submit returns a BatchJob with a job ID,
then poll get_status() until status == "completed" or "failed".
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from truthvouch.transport.rest import RestTransport


@dataclass
class BatchJob:
    """A submitted batch scan job.

    Attributes:
        id: Unique job identifier (UUID).
        status: Current job status — "pending", "processing", "completed", or "failed".
        estimated_completion: ISO 8601 timestamp estimate, or None if unknown.
        total_documents: Total number of documents to scan.
        scanned: Number of documents scanned so far.
        callback_url: Webhook URL for completion notification, or None.
        created_at: ISO 8601 timestamp when the job was created.
    """

    id: str
    status: str = "pending"
    estimated_completion: str | None = None
    total_documents: int = 0
    scanned: int = 0
    callback_url: str | None = None
    created_at: str = ""

    @property
    def progress_percent(self) -> float:
        """Percentage of documents scanned (0–100)."""
        if self.total_documents == 0:
            return 0.0
        return round(self.scanned / self.total_documents * 100, 1)


@dataclass
class BatchStatus:
    """Status of a batch scan job with results.

    Attributes:
        job_id: Job identifier.
        status: "pending" | "processing" | "completed" | "failed".
        total: Total documents in the batch.
        scanned: Number of documents scanned.
        results: List of per-document scan results (populated when completed).
        error_message: Non-empty if the job failed.
    """

    job_id: str
    status: str = "pending"
    total: int = 0
    scanned: int = 0
    results: list[dict[str, Any]] = field(default_factory=list)
    error_message: str = ""

    @property
    def progress_percent(self) -> float:
        """Percentage of documents scanned (0–100)."""
        if self.total == 0:
            return 0.0
        return round(self.scanned / self.total * 100, 1)

    @property
    def is_terminal(self) -> bool:
        """True if the job has finished (completed or failed)."""
        return self.status in ("completed", "failed")


class BatchScanClient:
    """Client for submitting and polling batch governance scan jobs.

    Example:
        async with client as c:
            job = await c.batch.submit(
                source_url="s3://my-bucket/docs.jsonl",
                format="jsonl",
                scan_mode="deep",
                callback_url="https://my-app.com/webhooks/scan-complete",
            )
            status = await c.batch.get_status(job.id)
    """

    _PATH_SUBMIT = "/v1/scan/batch"
    _PATH_STATUS = "/v1/scan/batch/{job_id}"

    def __init__(self, transport: RestTransport) -> None:
        """Initialise the batch scan client.

        Args:
            transport: RestTransport instance for HTTP communication.
        """
        self._transport = transport

    async def submit(
        self,
        source_url: str,
        format: str = "jsonl",
        scan_mode: str = "standard",
        callback_url: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> BatchJob:
        """Submit a batch scan job.

        Args:
            source_url: URL of the document corpus (e.g. s3://, https://).
            format: Document format — "jsonl", "csv", "pdf", or "text". Default "jsonl".
            scan_mode: Scan depth — "standard" or "deep". Default "standard".
            callback_url: Optional webhook URL for completion notification.
            metadata: Optional metadata dict attached to the job.

        Returns:
            BatchJob with the assigned job ID and initial status.

        Raises:
            InvalidRequestError: If source_url or format are invalid.
            AuthenticationError: If the API key is invalid.
            TruthVouchError: On other gateway errors.
        """
        body: dict[str, Any] = {
            "source_url": source_url,
            "format": format,
            "scan_mode": scan_mode,
        }
        if callback_url is not None:
            body["callback_url"] = callback_url
        if metadata is not None:
            body["metadata"] = metadata

        data = await self._transport.post(self._PATH_SUBMIT, json_body=body)

        return BatchJob(
            id=data.get("job_id") or data.get("id", ""),
            status=data.get("status", "pending"),
            estimated_completion=data.get("estimated_completion"),
            total_documents=int(data.get("total_documents", 0)),
            scanned=int(data.get("scanned", 0)),
            callback_url=callback_url,
            created_at=data.get("created_at", ""),
        )

    async def get_status(self, job_id: str) -> BatchStatus:
        """Retrieve the current status and results of a batch job.

        Args:
            job_id: Job ID returned by submit().

        Returns:
            BatchStatus with current progress and results if completed.

        Raises:
            InvalidRequestError: If job_id is not found.
            AuthenticationError: If the API key is invalid.
            TruthVouchError: On other gateway errors.
        """
        path = self._PATH_STATUS.format(job_id=job_id)
        data = await self._transport.get(path)

        return BatchStatus(
            job_id=job_id,
            status=data.get("status", "pending"),
            total=int(data.get("total_documents", 0)),
            scanned=int(data.get("scanned", 0)),
            results=list(data.get("results", [])),
            error_message=data.get("error_message", ""),
        )
