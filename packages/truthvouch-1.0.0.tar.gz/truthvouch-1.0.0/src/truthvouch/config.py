"""
TruthVouch SDK — Configuration model.

All SDK settings are captured in TruthVouchConfig, validated by Pydantic v2.
Environment variable names follow the TV_* prefix convention.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class TruthVouchConfig(BaseModel):
    """SDK configuration.

    Attributes:
        gateway_url: Base URL of the Governance Gateway (no trailing slash).
        api_key: API key for gateway authentication (TV_ prefix recommended).
        fail_mode: Behaviour when the gateway is unreachable.
            "open" (default): bypass the gateway and call LLM directly.
            "closed": raise GatewayUnreachableError.
        timeout: Request timeout in seconds. Default 30.0.
        max_retries: Maximum retry attempts with exponential backoff. Default 3.
        circuit_breaker_threshold: Consecutive failures before circuit opens. Default 5.
        circuit_breaker_recovery_seconds: Seconds before half-open probe. Default 60.
        verify_ssl: Verify TLS certificates. Default True.
            Set False only in local development with self-signed certs.
    """

    gateway_url: str = Field(..., description="Base URL of the Governance Gateway")
    api_key: str = Field(..., description="API key for gateway authentication")
    fail_mode: Literal["open", "closed"] = Field(
        default="open",
        description="open=bypass on gateway failure; closed=raise error",
    )
    timeout: float = Field(default=30.0, gt=0, description="HTTP request timeout (seconds)")
    max_retries: int = Field(default=3, ge=0, description="Max retry attempts")
    circuit_breaker_threshold: int = Field(
        default=5, ge=1, description="Failures before circuit opens"
    )
    circuit_breaker_recovery_seconds: float = Field(
        default=60.0, gt=0, description="Seconds before half-open recovery probe"
    )
    verify_ssl: bool = Field(default=True, description="Verify TLS certificates")

    model_config = {"frozen": True}

    @field_validator("gateway_url")
    @classmethod
    def strip_trailing_slash(cls, v: str) -> str:
        """Remove trailing slash from gateway URL to avoid double-slash in paths."""
        return v.rstrip("/")

    @field_validator("api_key")
    @classmethod
    def api_key_not_empty(cls, v: str) -> str:
        """Ensure API key is not blank."""
        if not v.strip():
            raise ValueError("api_key must not be blank")
        return v

    @model_validator(mode="after")
    def validate_ratios(self) -> "TruthVouchConfig":
        """Validate that circuit breaker settings are coherent."""
        if self.circuit_breaker_threshold < 1:
            raise ValueError("circuit_breaker_threshold must be >= 1")
        return self
