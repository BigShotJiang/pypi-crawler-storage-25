"""Verify the unified exception hierarchy has correct error_code values."""

import pytest

from truthvouch.exceptions import (
    TruthVouchError,
    AuthenticationError,
    BootstrapError,
    GatewayUnreachableError,
    GovernanceBlockError,
    GuardError,
    InvalidRequestError,
    PolicyBlockedError,
    QuotaExceededError,
    TelemetryError,
    TierUpgradeRequired,
    UpstreamProviderError,
)


class TestBaseException:
    def test_base_attributes(self):
        err = TruthVouchError("test", error_code="TEST", request_id="req-1")
        assert str(err) == "test"
        assert err.error_code == "TEST"
        assert err.request_id == "req-1"
        assert err.governance_report is None

    def test_repr(self):
        err = TruthVouchError("test", error_code="TEST", request_id="req-1")
        r = repr(err)
        assert "TruthVouchError" in r
        assert "TEST" in r
        assert "req-1" in r


class TestGatewayExceptions:
    def test_gateway_unreachable(self):
        err = GatewayUnreachableError()
        assert err.error_code == "TV_GATEWAY_UNREACHABLE"
        assert isinstance(err, TruthVouchError)

    def test_policy_blocked(self):
        err = PolicyBlockedError(governance_report={"verdict": "blocked"})
        assert err.error_code == "TV_POLICY_BLOCKED"
        assert err.governance_report == {"verdict": "blocked"}

    def test_authentication_error(self):
        err = AuthenticationError()
        assert err.error_code == "TV_AUTH_FAILED"

    def test_quota_exceeded(self):
        err = QuotaExceededError(retry_after_seconds=30.0)
        assert err.error_code == "TV_QUOTA_EXCEEDED"
        assert err.retry_after_seconds == 30.0

    def test_quota_exceeded_default(self):
        err = QuotaExceededError()
        assert err.retry_after_seconds is None

    def test_invalid_request(self):
        err = InvalidRequestError()
        assert err.error_code == "TV_INVALID_REQUEST"

    def test_upstream_provider_error(self):
        err = UpstreamProviderError(upstream_status_code=502)
        assert err.error_code == "TV_UPSTREAM_ERROR"
        assert err.upstream_status_code == 502

    def test_upstream_provider_default(self):
        err = UpstreamProviderError()
        assert err.upstream_status_code is None


class TestGovernanceExceptions:
    def test_governance_block(self):
        err = GovernanceBlockError(
            "blocked",
            block_reasons=["PII detected"],
            guard_results=[{"guard": "pii", "verdict": "BLOCK"}],
        )
        assert err.error_code == "GOV_BLOCKED"
        assert err.block_reasons == ["PII detected"]
        assert len(err.guard_results) == 1

    def test_guard_error(self):
        err = GuardError("failed", guard_name="pii_regex")
        assert err.error_code == "GOV_GUARD_ERROR"
        assert err.guard_name == "pii_regex"

    def test_bootstrap_error(self):
        err = BootstrapError("cannot connect")
        assert err.error_code == "GOV_BOOTSTRAP_FAILED"

    def test_tier_upgrade_required(self):
        err = TierUpgradeRequired(
            "feature not available",
            current_tier="starter",
            required_tier="enterprise",
            upgrade_url="https://truthvouch.com/upgrade",
        )
        assert err.error_code == "GOV_TIER_REQUIRED"
        assert err.current_tier == "starter"
        assert err.required_tier == "enterprise"
        assert err.upgrade_url == "https://truthvouch.com/upgrade"

    def test_telemetry_error(self):
        err = TelemetryError("push failed")
        assert err.error_code == "GOV_TELEMETRY_ERROR"


class TestInheritance:
    def test_all_inherit_from_base(self):
        classes = [
            GatewayUnreachableError, PolicyBlockedError, AuthenticationError,
            QuotaExceededError, InvalidRequestError, UpstreamProviderError,
            GovernanceBlockError, GuardError, BootstrapError,
            TierUpgradeRequired, TelemetryError,
        ]
        for cls in classes:
            assert issubclass(cls, TruthVouchError), f"{cls.__name__} not subclass"
            assert issubclass(cls, Exception), f"{cls.__name__} not Exception subclass"
