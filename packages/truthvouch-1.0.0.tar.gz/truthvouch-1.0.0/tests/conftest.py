"""Shared pytest fixtures for TruthVouch SDK tests."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from truthvouch.governance.config import ClientConfig, ModelPricing
from truthvouch.governance.models import GuardContext


@pytest.fixture
def default_config() -> ClientConfig:
    """A minimal ClientConfig suitable for local-guard testing."""
    return ClientConfig(
        banned_phrases=["confidential", "top secret"],
        pii_entity_types=["EMAIL", "SSN", "CREDIT_CARD", "PHONE", "PASSPORT", "ADDRESS"],
        truth_scan_enabled=False,
        pii_remote_enabled=False,
        budget_usd=10.0,
        budget_spent_usd=0.0,
        degraded=False,
        model_pricing={
            "gpt-4o": ModelPricing(input_cost_per_1k=0.005, output_cost_per_1k=0.015),
            "gpt-4o-mini": ModelPricing(input_cost_per_1k=0.00015, output_cost_per_1k=0.0006),
        },
    )


@pytest.fixture
def degraded_config() -> ClientConfig:
    """A ClientConfig in degraded mode (no remote guards, no telemetry)."""
    return ClientConfig(degraded=True)


@pytest.fixture
def input_context(default_config: ClientConfig) -> GuardContext:
    """GuardContext for input direction with default config."""
    return GuardContext(direction="input", model="gpt-4o", config=default_config)


@pytest.fixture
def output_context(default_config: ClientConfig) -> GuardContext:
    """GuardContext for output direction with default config."""
    return GuardContext(direction="output", model="gpt-4o", config=default_config)


@pytest.fixture
def mock_http_client() -> MagicMock:
    """A mock HttpClient that returns empty dicts by default."""
    client = MagicMock()
    client.get.return_value = {}
    client.post.return_value = {}
    return client
