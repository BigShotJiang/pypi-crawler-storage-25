"""
Tests for Anthropic-compatible provider: API surface, message conversion, response parsing.
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from truthvouch.models import GovernanceReport
from truthvouch.providers.anthropic import (
    AnthropicProvider,
    GovernedAnthropicResponse,
    MessagesClient,
    _convert_to_openai_messages,
    _parse_anthropic_response,
)
from truthvouch.transport.rest import RestTransport


def _make_gateway_response(content: str = "Anthropic test response") -> dict:
    return {
        "id": "msg-test-456",
        "model": "claude-3.5-sonnet-20241022",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
        "usage": {"prompt_tokens": 12, "completion_tokens": 24, "total_tokens": 36},
        "governance": {
            "verdict": "allowed",
            "pii_detected": False,
            "injection_detected": False,
            "policy_violations": [],
            "overhead_ms": 8.0,
            "request_id": "req-def-789",
        },
    }


class TestConvertToOpenAIMessages:
    """Unit tests for Anthropic → OpenAI message format conversion."""

    def test_simple_user_message(self) -> None:
        messages = [{"role": "user", "content": "Hello"}]
        result = _convert_to_openai_messages(messages, system=None)
        assert result == [{"role": "user", "content": "Hello"}]

    def test_system_prompt_prepended(self) -> None:
        messages = [{"role": "user", "content": "Hello"}]
        result = _convert_to_openai_messages(messages, system="You are helpful.")
        assert result[0] == {"role": "system", "content": "You are helpful."}
        assert result[1] == {"role": "user", "content": "Hello"}

    def test_no_system_prompt_no_system_message(self) -> None:
        messages = [{"role": "user", "content": "Hello"}]
        result = _convert_to_openai_messages(messages, system=None)
        assert all(m["role"] != "system" for m in result)

    def test_list_content_blocks_converted(self) -> None:
        messages = [
            {"role": "user", "content": [{"type": "text", "text": "Hello there"}]}
        ]
        result = _convert_to_openai_messages(messages, system=None)
        assert result[0]["content"] == "Hello there"

    def test_multi_turn_messages_preserved(self) -> None:
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there"},
            {"role": "user", "content": "How are you?"},
        ]
        result = _convert_to_openai_messages(messages, system=None)
        assert len(result) == 3
        assert result[0]["role"] == "user"
        assert result[1]["role"] == "assistant"
        assert result[2]["role"] == "user"


class TestParseAnthropicResponse:
    """Unit tests for _parse_anthropic_response."""

    def test_parses_text_content(self) -> None:
        data = _make_gateway_response(content="Test response")
        resp = _parse_anthropic_response(data)
        assert resp.text == "Test response"

    def test_text_convenience_accessor(self) -> None:
        data = _make_gateway_response(content="Hello from Claude")
        resp = _parse_anthropic_response(data)
        assert resp.text == "Hello from Claude"

    def test_parses_governance(self) -> None:
        data = _make_gateway_response()
        resp = _parse_anthropic_response(data)
        assert isinstance(resp.governance, GovernanceReport)
        assert resp.governance.verdict == "allowed"

    def test_parses_token_usage(self) -> None:
        data = _make_gateway_response()
        resp = _parse_anthropic_response(data)
        assert resp.usage.input_tokens == 12
        assert resp.usage.output_tokens == 24

    def test_stop_reason_end_turn_for_stop(self) -> None:
        data = _make_gateway_response()
        resp = _parse_anthropic_response(data)
        assert resp.stop_reason == "end_turn"

    def test_content_blocks_populated(self) -> None:
        data = _make_gateway_response(content="Block content")
        resp = _parse_anthropic_response(data)
        assert len(resp.content) == 1
        assert resp.content[0].type == "text"
        assert resp.content[0].text == "Block content"


class TestMessagesClient:
    """Integration-style tests for MessagesClient with mocked transport."""

    def _make_transport(self, response_data: dict) -> RestTransport:
        transport = RestTransport(
            gateway_url="https://gateway.example.com",
            api_key="tv_test",
        )
        transport.post = AsyncMock(return_value=response_data)
        return transport

    @pytest.mark.asyncio
    async def test_create_returns_governed_response(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = MessagesClient(transport)

        resp = await client.create(
            model="claude-3.5-sonnet-20241022",
            messages=[{"role": "user", "content": "Hello"}],
        )
        assert isinstance(resp, GovernedAnthropicResponse)

    @pytest.mark.asyncio
    async def test_create_passes_provider_hint(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = MessagesClient(transport)

        await client.create(
            model="claude-3.5-sonnet-20241022",
            messages=[{"role": "user", "content": "Hello"}],
        )
        body = transport.post.call_args[1]["json_body"]
        assert body.get("provider_hint") == "anthropic"

    @pytest.mark.asyncio
    async def test_create_passes_max_tokens(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = MessagesClient(transport)

        await client.create(
            model="claude-3.5-sonnet-20241022",
            messages=[],
            max_tokens=512,
        )
        body = transport.post.call_args[1]["json_body"]
        assert body["max_tokens"] == 512

    @pytest.mark.asyncio
    async def test_create_prepends_system_prompt(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = MessagesClient(transport)

        await client.create(
            model="claude-3.5-sonnet-20241022",
            messages=[{"role": "user", "content": "Hi"}],
            system="You are a helpful assistant.",
        )
        body = transport.post.call_args[1]["json_body"]
        assert body["messages"][0]["role"] == "system"
        assert body["messages"][0]["content"] == "You are a helpful assistant."
