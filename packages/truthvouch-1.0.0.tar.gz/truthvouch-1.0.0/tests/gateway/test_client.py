"""
Tests for TruthVouch gateway client: init, context manager, connection management.
"""

from __future__ import annotations

import pytest
import httpx
from unittest.mock import AsyncMock, MagicMock, patch

from truthvouch import TruthVouch
from truthvouch.client import TruthVouch as TruthVouchClient
from truthvouch.config import TruthVouchConfig
from truthvouch.exceptions import GatewayUnreachableError


class TestClientInit:
    """Test client initialisation and configuration."""

    def test_client_initialises_with_required_params(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        assert client.config.gateway_url == "https://gateway.example.com"
        assert client.config.api_key == "tv_test_key"

    def test_gateway_url_trailing_slash_stripped(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com/",
            api_key="tv_test_key",
        )
        assert not client.config.gateway_url.endswith("/")

    def test_default_fail_mode_is_open(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        assert client.config.fail_mode == "open"

    def test_fail_mode_closed_accepted(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
            fail_mode="closed",
        )
        assert client.config.fail_mode == "closed"

    def test_default_timeout_is_30(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        assert client.config.timeout == 30.0

    def test_custom_timeout_accepted(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
            timeout=60.0,
        )
        assert client.config.timeout == 60.0

    def test_truthvouch_alias_works(self) -> None:
        """The public TruthVouch alias is the same class."""
        client = TruthVouch(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        assert isinstance(client, TruthVouchClient)

    def test_empty_api_key_raises(self) -> None:
        with pytest.raises(Exception):
            TruthVouchClient(
                gateway_url="https://gateway.example.com",
                api_key="",
            )


class TestClientProviderFacades:
    """Test that provider facades are accessible and wired to the same transport."""

    def test_openai_facade_accessible(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        from truthvouch.providers.openai import OpenAIProvider
        assert isinstance(client.openai, OpenAIProvider)

    def test_anthropic_facade_accessible(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        from truthvouch.providers.anthropic import AnthropicProvider
        assert isinstance(client.anthropic, AnthropicProvider)

    def test_google_facade_accessible(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        from truthvouch.providers.google import GoogleAIProvider
        assert isinstance(client.google, GoogleAIProvider)

    def test_batch_client_accessible(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        from truthvouch.batch import BatchScanClient
        assert isinstance(client.batch, BatchScanClient)

    def test_chat_shortcut_is_openai_chat(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        # client.chat is a shortcut for client.openai.chat
        assert client.chat is client.openai.chat


class TestClientContextManager:
    """Test async context manager (connect/close lifecycle)."""

    @pytest.mark.asyncio
    async def test_context_manager_connects_and_closes(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        with patch.object(client._transport, "connect", new_callable=AsyncMock) as mock_connect, \
             patch.object(client._transport, "close", new_callable=AsyncMock) as mock_close:
            async with client:
                mock_connect.assert_called_once()
            mock_close.assert_called_once()

    @pytest.mark.asyncio
    async def test_context_manager_closes_on_exception(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        with patch.object(client._transport, "connect", new_callable=AsyncMock), \
             patch.object(client._transport, "close", new_callable=AsyncMock) as mock_close:
            try:
                async with client:
                    raise RuntimeError("test error")
            except RuntimeError:
                pass
            mock_close.assert_called_once()

    @pytest.mark.asyncio
    async def test_manual_connect_and_close(self) -> None:
        client = TruthVouchClient(
            gateway_url="https://gateway.example.com",
            api_key="tv_test_key",
        )
        with patch.object(client._transport, "connect", new_callable=AsyncMock) as mock_connect, \
             patch.object(client._transport, "close", new_callable=AsyncMock) as mock_close:
            await client.connect()
            mock_connect.assert_called_once()
            await client.close()
            mock_close.assert_called_once()
