"""
Tests for BatchScanClient: submit, poll, dataclass behaviour.
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from truthvouch.batch import BatchJob, BatchScanClient, BatchStatus
from truthvouch.transport.rest import RestTransport


def _make_transport_with_mock(response: dict) -> RestTransport:
    transport = RestTransport(
        gateway_url="https://gateway.example.com",
        api_key="tv_test",
    )
    transport.post = AsyncMock(return_value=response)
    transport.get = AsyncMock(return_value=response)
    return transport


class TestBatchJobDataclass:
    """Unit tests for BatchJob dataclass."""

    def test_progress_percent_zero_when_no_documents(self) -> None:
        job = BatchJob(id="j1", total_documents=0, scanned=0)
        assert job.progress_percent == 0.0

    def test_progress_percent_calculates_correctly(self) -> None:
        job = BatchJob(id="j1", total_documents=100, scanned=50)
        assert job.progress_percent == 50.0

    def test_progress_percent_100_when_complete(self) -> None:
        job = BatchJob(id="j1", total_documents=200, scanned=200)
        assert job.progress_percent == 100.0


class TestBatchStatusDataclass:
    """Unit tests for BatchStatus dataclass."""

    def test_is_terminal_false_for_processing(self) -> None:
        status = BatchStatus(job_id="j1", status="processing")
        assert not status.is_terminal

    def test_is_terminal_true_for_completed(self) -> None:
        status = BatchStatus(job_id="j1", status="completed")
        assert status.is_terminal

    def test_is_terminal_true_for_failed(self) -> None:
        status = BatchStatus(job_id="j1", status="failed")
        assert status.is_terminal

    def test_progress_percent_zero_when_no_total(self) -> None:
        status = BatchStatus(job_id="j1", total=0, scanned=0)
        assert status.progress_percent == 0.0


class TestBatchScanClientSubmit:
    """Integration tests for BatchScanClient.submit with mocked transport."""

    @pytest.mark.asyncio
    async def test_submit_returns_batch_job(self) -> None:
        mock_response = {
            "job_id": "job-abc-123",
            "status": "pending",
            "total_documents": 0,
            "scanned": 0,
            "created_at": "2026-03-01T00:00:00Z",
        }
        transport = _make_transport_with_mock(mock_response)
        client = BatchScanClient(transport)

        job = await client.submit(
            source_url="s3://my-bucket/docs.jsonl",
            format="jsonl",
            scan_mode="deep",
        )
        assert isinstance(job, BatchJob)
        assert job.id == "job-abc-123"
        assert job.status == "pending"

    @pytest.mark.asyncio
    async def test_submit_posts_to_correct_path(self) -> None:
        mock_response = {"job_id": "j1", "status": "pending"}
        transport = _make_transport_with_mock(mock_response)
        client = BatchScanClient(transport)

        await client.submit(source_url="s3://bucket/docs.jsonl", format="jsonl")
        transport.post.assert_called_once()
        path = transport.post.call_args[0][0]
        assert path == "/v1/scan/batch"

    @pytest.mark.asyncio
    async def test_submit_includes_source_url_in_body(self) -> None:
        mock_response = {"job_id": "j1", "status": "pending"}
        transport = _make_transport_with_mock(mock_response)
        client = BatchScanClient(transport)

        await client.submit(source_url="s3://my-bucket/data.jsonl", format="jsonl")
        body = transport.post.call_args[1]["json_body"]
        assert body["source_url"] == "s3://my-bucket/data.jsonl"

    @pytest.mark.asyncio
    async def test_submit_includes_callback_url_when_provided(self) -> None:
        mock_response = {"job_id": "j2", "status": "pending"}
        transport = _make_transport_with_mock(mock_response)
        client = BatchScanClient(transport)

        await client.submit(
            source_url="https://example.com/docs.jsonl",
            callback_url="https://my-app.com/webhooks/done",
        )
        body = transport.post.call_args[1]["json_body"]
        assert body["callback_url"] == "https://my-app.com/webhooks/done"

    @pytest.mark.asyncio
    async def test_submit_omits_callback_url_when_not_provided(self) -> None:
        mock_response = {"job_id": "j3", "status": "pending"}
        transport = _make_transport_with_mock(mock_response)
        client = BatchScanClient(transport)

        await client.submit(source_url="s3://bucket/docs.jsonl")
        body = transport.post.call_args[1]["json_body"]
        assert "callback_url" not in body


class TestBatchScanClientGetStatus:
    """Integration tests for BatchScanClient.get_status with mocked transport."""

    @pytest.mark.asyncio
    async def test_get_status_returns_batch_status(self) -> None:
        mock_response = {
            "status": "processing",
            "total_documents": 500,
            "scanned": 250,
            "results": [],
            "error_message": "",
        }
        transport = _make_transport_with_mock(mock_response)
        client = BatchScanClient(transport)

        status = await client.get_status("job-abc-123")
        assert isinstance(status, BatchStatus)
        assert status.status == "processing"
        assert status.total == 500
        assert status.scanned == 250

    @pytest.mark.asyncio
    async def test_get_status_calls_correct_path(self) -> None:
        mock_response = {"status": "completed", "total_documents": 10, "scanned": 10}
        transport = _make_transport_with_mock(mock_response)
        client = BatchScanClient(transport)

        await client.get_status("my-job-id")
        transport.get.assert_called_once()
        path = transport.get.call_args[0][0]
        assert "my-job-id" in path

    @pytest.mark.asyncio
    async def test_get_status_populated_results_when_completed(self) -> None:
        mock_response = {
            "status": "completed",
            "total_documents": 2,
            "scanned": 2,
            "results": [
                {"document_id": "d1", "verdict": "allowed"},
                {"document_id": "d2", "verdict": "flagged"},
            ],
        }
        transport = _make_transport_with_mock(mock_response)
        client = BatchScanClient(transport)

        status = await client.get_status("job-done")
        assert len(status.results) == 2
        assert status.results[0]["document_id"] == "d1"
