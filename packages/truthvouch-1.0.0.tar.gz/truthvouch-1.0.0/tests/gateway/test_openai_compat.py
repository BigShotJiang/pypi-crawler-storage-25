"""
Tests for OpenAI-compatible provider: API surface, response parsing, governance.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from truthvouch.models import GovernanceReport
from truthvouch.providers.openai import (
    ChatCompletionsClient,
    GovernedChatResponse,
    OpenAIProvider,
    _parse_chat_response,
)
from truthvouch.transport.rest import RestTransport


def _make_gateway_response(
    content: str = "Test response",
    verdict: str = "allowed",
    model: str = "gpt-4o",
    prompt_tokens: int = 10,
    completion_tokens: int = 20,
) -> dict:
    """Build a mock gateway JSON response in the expected format."""
    return {
        "id": "chatcmpl-test-123",
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
        "governance": {
            "verdict": verdict,
            "pii_detected": False,
            "injection_detected": False,
            "policy_violations": [],
            "overhead_ms": 12.5,
            "request_id": "req-abc-123",
        },
    }


class TestParseChatResponse:
    """Unit tests for _parse_chat_response (no network calls needed)."""

    def test_parses_choices(self) -> None:
        data = _make_gateway_response(content="Hello world")
        resp = _parse_chat_response(data)
        assert len(resp.choices) == 1
        assert resp.choices[0].message.content == "Hello world"
        assert resp.choices[0].message.role == "assistant"

    def test_content_convenience_accessor(self) -> None:
        data = _make_gateway_response(content="Hello world")
        resp = _parse_chat_response(data)
        assert resp.content == "Hello world"

    def test_parses_usage(self) -> None:
        data = _make_gateway_response(prompt_tokens=15, completion_tokens=25)
        resp = _parse_chat_response(data)
        assert resp.usage.prompt_tokens == 15
        assert resp.usage.completion_tokens == 25
        assert resp.usage.total_tokens == 40

    def test_parses_governance_verdict(self) -> None:
        data = _make_gateway_response(verdict="allowed")
        resp = _parse_chat_response(data)
        assert resp.governance.verdict == "allowed"

    def test_parses_governance_pii_flag(self) -> None:
        data = _make_gateway_response()
        data["governance"]["pii_detected"] = True
        resp = _parse_chat_response(data)
        assert resp.governance.pii_detected is True

    def test_parses_governance_overhead_ms(self) -> None:
        data = _make_gateway_response()
        resp = _parse_chat_response(data)
        assert resp.governance.overhead_ms == 12.5

    def test_parses_governance_request_id(self) -> None:
        data = _make_gateway_response()
        resp = _parse_chat_response(data)
        assert resp.governance.request_id == "req-abc-123"

    def test_parses_model(self) -> None:
        data = _make_gateway_response(model="gpt-4o-mini")
        resp = _parse_chat_response(data)
        assert resp.model == "gpt-4o-mini"

    def test_empty_choices_returns_empty_content(self) -> None:
        data = _make_gateway_response()
        data["choices"] = []
        resp = _parse_chat_response(data)
        assert resp.content == ""

    def test_policy_violations_parsed(self) -> None:
        data = _make_gateway_response(verdict="blocked")
        data["governance"]["policy_violations"] = ["pii_leak", "injection_attempt"]
        resp = _parse_chat_response(data)
        assert resp.governance.policy_violations == ["pii_leak", "injection_attempt"]


class TestChatCompletionsClientCreate:
    """Integration-style tests for ChatCompletionsClient with mocked transport."""

    def _make_transport(self, response_data: dict) -> RestTransport:
        transport = RestTransport(
            gateway_url="https://gateway.example.com",
            api_key="tv_test",
        )
        transport.post = AsyncMock(return_value=response_data)
        return transport

    @pytest.mark.asyncio
    async def test_create_calls_post_endpoint(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = ChatCompletionsClient(transport)

        resp = await client.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
        transport.post.assert_called_once()
        call_args = transport.post.call_args
        assert call_args[0][0] == "/v1/proxy/chat/completions"

    @pytest.mark.asyncio
    async def test_create_passes_model_in_body(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = ChatCompletionsClient(transport)

        await client.create(model="gpt-4o", messages=[])
        body = transport.post.call_args[1]["json_body"]
        assert body["model"] == "gpt-4o"

    @pytest.mark.asyncio
    async def test_create_passes_messages_in_body(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = ChatCompletionsClient(transport)

        messages = [{"role": "user", "content": "Hi"}]
        await client.create(model="gpt-4o", messages=messages)
        body = transport.post.call_args[1]["json_body"]
        assert body["messages"] == messages

    @pytest.mark.asyncio
    async def test_create_passes_temperature_when_provided(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = ChatCompletionsClient(transport)

        await client.create(model="gpt-4o", messages=[], temperature=0.7)
        body = transport.post.call_args[1]["json_body"]
        assert body["temperature"] == 0.7

    @pytest.mark.asyncio
    async def test_create_omits_temperature_when_not_provided(self) -> None:
        data = _make_gateway_response()
        transport = self._make_transport(data)
        client = ChatCompletionsClient(transport)

        await client.create(model="gpt-4o", messages=[])
        body = transport.post.call_args[1]["json_body"]
        assert "temperature" not in body

    @pytest.mark.asyncio
    async def test_create_returns_governed_chat_response(self) -> None:
        data = _make_gateway_response(content="Test content")
        transport = self._make_transport(data)
        client = ChatCompletionsClient(transport)

        resp = await client.create(model="gpt-4o", messages=[])
        assert isinstance(resp, GovernedChatResponse)
        assert resp.content == "Test content"
        assert isinstance(resp.governance, GovernanceReport)
