"""
Tests for GovernanceReport: parsing, factory methods, attribute access.
"""

from __future__ import annotations

import pytest

from truthvouch.models import GovernanceReport


class TestGovernanceReportFromGatewayResponse:
    """Tests for GovernanceReport.from_gateway_response()."""

    def test_parses_verdict(self) -> None:
        report = GovernanceReport.from_gateway_response({"verdict": "allowed"})
        assert report.verdict == "allowed"

    def test_parses_blocked_verdict(self) -> None:
        report = GovernanceReport.from_gateway_response({"verdict": "blocked"})
        assert report.verdict == "blocked"

    def test_parses_pii_detected_true(self) -> None:
        report = GovernanceReport.from_gateway_response({"pii_detected": True})
        assert report.pii_detected is True

    def test_parses_pii_detected_false(self) -> None:
        report = GovernanceReport.from_gateway_response({"pii_detected": False})
        assert report.pii_detected is False

    def test_parses_injection_detected(self) -> None:
        report = GovernanceReport.from_gateway_response({"injection_detected": True})
        assert report.injection_detected is True

    def test_parses_truth_scan(self) -> None:
        truth_scan = {"confidence": 0.95, "contradictions": []}
        report = GovernanceReport.from_gateway_response({"truth_scan": truth_scan})
        assert report.truth_scan is not None
        assert report.truth_scan["confidence"] == 0.95

    def test_truth_scan_none_when_absent(self) -> None:
        report = GovernanceReport.from_gateway_response({})
        assert report.truth_scan is None

    def test_parses_policy_violations(self) -> None:
        report = GovernanceReport.from_gateway_response(
            {"policy_violations": ["pii_leak", "injection"]}
        )
        assert report.policy_violations == ["pii_leak", "injection"]

    def test_empty_policy_violations_by_default(self) -> None:
        report = GovernanceReport.from_gateway_response({})
        assert report.policy_violations == []

    def test_parses_overhead_ms(self) -> None:
        report = GovernanceReport.from_gateway_response({"overhead_ms": 15.5})
        assert report.overhead_ms == 15.5

    def test_parses_request_id(self) -> None:
        report = GovernanceReport.from_gateway_response({"request_id": "req-xyz"})
        assert report.request_id == "req-xyz"

    def test_defaults_for_missing_fields(self) -> None:
        """All fields should have safe defaults when the response is empty."""
        report = GovernanceReport.from_gateway_response({})
        assert report.verdict == "allowed"
        assert report.pii_detected is False
        assert report.injection_detected is False
        assert report.truth_scan is None
        assert report.policy_violations == []
        assert report.overhead_ms == 0.0
        assert report.request_id == ""


class TestGovernanceReportBlockedFactory:
    """Tests for GovernanceReport.blocked() convenience factory."""

    def test_blocked_sets_verdict(self) -> None:
        report = GovernanceReport.blocked(violations=["pii_leak"])
        assert report.verdict == "blocked"

    def test_blocked_sets_policy_violations(self) -> None:
        report = GovernanceReport.blocked(violations=["rule_A", "rule_B"])
        assert report.policy_violations == ["rule_A", "rule_B"]

    def test_blocked_sets_request_id(self) -> None:
        report = GovernanceReport.blocked(violations=[], request_id="req-block-1")
        assert report.request_id == "req-block-1"

    def test_blocked_sets_overhead_ms(self) -> None:
        report = GovernanceReport.blocked(violations=[], overhead_ms=9.0)
        assert report.overhead_ms == 9.0


class TestGovernanceReportDefaults:
    """Test GovernanceReport default-constructed state."""

    def test_default_verdict_is_allowed(self) -> None:
        report = GovernanceReport()
        assert report.verdict == "allowed"

    def test_default_pii_detected_is_false(self) -> None:
        report = GovernanceReport()
        assert report.pii_detected is False

    def test_default_policy_violations_is_empty(self) -> None:
        report = GovernanceReport()
        assert report.policy_violations == []

    def test_default_overhead_ms_is_zero(self) -> None:
        report = GovernanceReport()
        assert report.overhead_ms == 0.0
