"""
Tests for CircuitBreaker: CLOSED/OPEN/HALF_OPEN states, fail_mode, retry backoff.
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, patch

import pytest

from truthvouch.exceptions import GatewayUnreachableError
from truthvouch.resilience import (
    CircuitBreaker,
    CircuitState,
    _CircuitOpenBypass,
    is_retryable_status,
    retry_with_backoff,
)


class TestCircuitBreakerInitialState:
    """Test initial circuit breaker state."""

    def test_initial_state_is_closed(self) -> None:
        breaker = CircuitBreaker(threshold=3)
        assert breaker.state == CircuitState.CLOSED

    def test_is_open_false_initially(self) -> None:
        breaker = CircuitBreaker(threshold=3)
        assert not breaker.is_open

    def test_failure_count_zero_initially(self) -> None:
        breaker = CircuitBreaker(threshold=3)
        assert breaker._failure_count == 0


class TestCircuitBreakerFailures:
    """Test circuit breaker opens after threshold failures."""

    @pytest.mark.asyncio
    async def test_circuit_opens_after_threshold_failures(self) -> None:
        breaker = CircuitBreaker(threshold=3, fail_mode="open")

        async def failing_func() -> None:
            raise GatewayUnreachableError("gateway down")

        for _ in range(3):
            try:
                await breaker.call(failing_func)
            except (GatewayUnreachableError, _CircuitOpenBypass):
                pass

        assert breaker.state == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_circuit_stays_closed_below_threshold(self) -> None:
        breaker = CircuitBreaker(threshold=5, fail_mode="open")

        async def failing_func() -> None:
            raise GatewayUnreachableError("gateway down")

        # Only 2 failures, threshold is 5
        for _ in range(2):
            try:
                await breaker.call(failing_func)
            except GatewayUnreachableError:
                pass

        assert breaker.state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_success_resets_failure_count(self) -> None:
        breaker = CircuitBreaker(threshold=5, fail_mode="open")
        call_count = 0

        async def sometimes_fails() -> str:
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                raise GatewayUnreachableError("down")
            return "ok"

        # 2 failures
        for _ in range(2):
            try:
                await breaker.call(sometimes_fails)
            except GatewayUnreachableError:
                pass

        # 1 success
        await breaker.call(sometimes_fails)

        assert breaker.state == CircuitState.CLOSED
        assert breaker._failure_count == 0


class TestCircuitBreakerFailMode:
    """Test fail_mode=open vs fail_mode=closed behaviour."""

    @pytest.mark.asyncio
    async def test_fail_mode_open_raises_bypass_when_open(self) -> None:
        """fail_mode=open raises _CircuitOpenBypass so callers can bypass the gateway."""
        breaker = CircuitBreaker(threshold=1, recovery_seconds=9999.0, fail_mode="open")

        async def failing_func() -> None:
            raise GatewayUnreachableError("down")

        # Trip the circuit
        try:
            await breaker.call(failing_func)
        except GatewayUnreachableError:
            pass

        assert breaker.state == CircuitState.OPEN

        # Next call should get _CircuitOpenBypass (fail-open mode)
        with pytest.raises(_CircuitOpenBypass):
            await breaker.call(failing_func)

    @pytest.mark.asyncio
    async def test_fail_mode_closed_raises_gateway_unreachable_when_open(self) -> None:
        """fail_mode=closed raises GatewayUnreachableError when circuit is open."""
        breaker = CircuitBreaker(threshold=1, recovery_seconds=9999.0, fail_mode="closed")

        async def failing_func() -> None:
            raise GatewayUnreachableError("down")

        # Trip the circuit
        try:
            await breaker.call(failing_func)
        except GatewayUnreachableError:
            pass

        assert breaker.state == CircuitState.OPEN

        # Next call should get GatewayUnreachableError (fail-closed mode)
        with pytest.raises(GatewayUnreachableError):
            await breaker.call(failing_func)


class TestCircuitBreakerRecovery:
    """Test circuit breaker recovery from OPEN to HALF_OPEN to CLOSED."""

    @pytest.mark.asyncio
    async def test_transitions_to_half_open_after_recovery_period(self) -> None:
        """After recovery_seconds, the circuit should move to HALF_OPEN."""
        breaker = CircuitBreaker(threshold=1, recovery_seconds=0.01, fail_mode="closed")

        async def failing_func() -> None:
            raise GatewayUnreachableError("down")

        # Trip the circuit
        try:
            await breaker.call(failing_func)
        except GatewayUnreachableError:
            pass

        assert breaker.state == CircuitState.OPEN

        # Wait for recovery
        await asyncio.sleep(0.05)

        # Manually manipulate to test transition: the next call triggers half-open
        async def successful_func() -> str:
            return "recovered"

        result = await breaker.call(successful_func)
        assert result == "recovered"
        assert breaker.state == CircuitState.CLOSED


class TestIsRetryableStatus:
    """Test HTTP status code retryability classification."""

    def test_429_is_retryable(self) -> None:
        assert is_retryable_status(429)

    def test_500_is_retryable(self) -> None:
        assert is_retryable_status(500)

    def test_503_is_retryable(self) -> None:
        assert is_retryable_status(503)

    def test_200_is_not_retryable(self) -> None:
        assert not is_retryable_status(200)

    def test_400_is_not_retryable(self) -> None:
        assert not is_retryable_status(400)

    def test_401_is_not_retryable(self) -> None:
        assert not is_retryable_status(401)

    def test_403_is_not_retryable(self) -> None:
        assert not is_retryable_status(403)


class TestRetryWithBackoff:
    """Test retry_with_backoff helper function."""

    @pytest.mark.asyncio
    async def test_succeeds_on_first_try(self) -> None:
        async def always_succeeds() -> str:
            return "ok"

        result = await retry_with_backoff(always_succeeds, max_retries=3)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_retries_on_retryable_exception(self) -> None:
        call_count = 0

        async def fails_twice() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise GatewayUnreachableError("transient")
            return "ok"

        result = await retry_with_backoff(
            fails_twice,
            max_retries=3,
            base_delay=0.0,
            jitter=0.0,
        )
        assert result == "ok"
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_raises_after_max_retries(self) -> None:
        async def always_fails() -> None:
            raise GatewayUnreachableError("always down")

        with pytest.raises(GatewayUnreachableError):
            await retry_with_backoff(
                always_fails,
                max_retries=2,
                base_delay=0.0,
                jitter=0.0,
            )

    @pytest.mark.asyncio
    async def test_does_not_retry_non_retryable_exception(self) -> None:
        call_count = 0

        async def raises_value_error() -> None:
            nonlocal call_count
            call_count += 1
            raise ValueError("non-retryable")

        with pytest.raises(ValueError):
            await retry_with_backoff(
                raises_value_error,
                max_retries=3,
                base_delay=0.0,
            )

        assert call_count == 1  # Only called once, no retries
