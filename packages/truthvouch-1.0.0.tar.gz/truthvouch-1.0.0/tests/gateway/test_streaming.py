"""
Tests for SSE streaming: _parse_sse_line, _dict_to_chunk, stream_chat_completions.
"""

from __future__ import annotations

import json
from typing import AsyncGenerator

import pytest

from truthvouch.streaming import (
    ChatChunk,
    _dict_to_chunk,
    _parse_sse_line,
    stream_chat_completions,
)


class TestParseSSELine:
    """Unit tests for SSE line parsing."""

    def test_parses_data_line(self) -> None:
        data = _parse_sse_line('data: {"id": "chunk-1", "choices": []}')
        assert data is not None
        assert data["id"] == "chunk-1"

    def test_returns_none_for_comment(self) -> None:
        assert _parse_sse_line(": heartbeat") is None

    def test_returns_none_for_empty_line(self) -> None:
        assert _parse_sse_line("") is None

    def test_returns_none_for_done_sentinel(self) -> None:
        assert _parse_sse_line("data: [DONE]") is None

    def test_returns_none_for_invalid_json(self) -> None:
        assert _parse_sse_line("data: not-json") is None

    def test_strips_whitespace(self) -> None:
        data = _parse_sse_line('  data: {"done": false}  ')
        assert data is not None
        assert data["done"] is False


class TestDictToChunk:
    """Unit tests for converting parsed SSE dicts to ChatChunk."""

    def test_populates_id_and_model(self) -> None:
        chunk = _dict_to_chunk({"id": "c1", "model": "gpt-4o", "choices": []})
        assert chunk.id == "c1"
        assert chunk.model == "gpt-4o"

    def test_done_false_by_default(self) -> None:
        chunk = _dict_to_chunk({"choices": []})
        assert chunk.done is False

    def test_done_true_when_set(self) -> None:
        chunk = _dict_to_chunk({"choices": [], "done": True})
        assert chunk.done is True

    def test_parses_delta_content(self) -> None:
        data = {
            "choices": [{"index": 0, "delta": {"content": "Hello"}, "finish_reason": None}]
        }
        chunk = _dict_to_chunk(data)
        assert chunk.content == "Hello"

    def test_governance_report_on_final_chunk(self) -> None:
        data = {
            "choices": [],
            "done": True,
            "governance": {
                "verdict": "allowed",
                "pii_detected": False,
                "injection_detected": False,
                "policy_violations": [],
                "overhead_ms": 5.0,
                "request_id": "req-123",
            },
        }
        chunk = _dict_to_chunk(data)
        assert chunk.governance_report is not None
        assert chunk.governance_report.verdict == "allowed"
        assert chunk.governance_report.overhead_ms == 5.0

    def test_no_governance_on_intermediate_chunk(self) -> None:
        data = {"choices": [{"delta": {"content": "partial"}}], "done": False}
        chunk = _dict_to_chunk(data)
        assert chunk.governance_report is None


class TestStreamChatCompletions:
    """Integration tests for stream_chat_completions async generator."""

    async def _make_byte_stream(self, lines: list[str]) -> AsyncGenerator[bytes, None]:
        """Helper: simulate SSE byte stream from a list of lines."""
        async def gen() -> AsyncGenerator[bytes, None]:
            for line in lines:
                yield (line + "\n").encode("utf-8")
        return gen()

    @pytest.mark.asyncio
    async def test_yields_chunks_from_sse(self) -> None:
        lines = [
            'data: {"id": "c1", "choices": [{"delta": {"content": "Hello"}}], "done": false}',
            'data: {"id": "c2", "choices": [{"delta": {"content": " World"}}], "done": false}',
            'data: {"choices": [], "done": true, "governance": {"verdict": "allowed", "pii_detected": false, "injection_detected": false, "policy_violations": [], "overhead_ms": 3.0, "request_id": "r1"}}',
        ]
        byte_stream = await self._make_byte_stream(lines)

        chunks = []
        async for chunk in stream_chat_completions(byte_stream):
            chunks.append(chunk)

        assert len(chunks) == 3
        assert chunks[0].content == "Hello"
        assert chunks[1].content == " World"
        assert chunks[2].done is True

    @pytest.mark.asyncio
    async def test_final_chunk_has_governance_report(self) -> None:
        lines = [
            'data: {"choices": [{"delta": {"content": "Hi"}}], "done": false}',
            'data: {"choices": [], "done": true, "governance": {"verdict": "flagged", "pii_detected": true, "injection_detected": false, "policy_violations": ["pii_leak"], "overhead_ms": 7.5, "request_id": "r2"}}',
        ]
        byte_stream = await self._make_byte_stream(lines)

        chunks = []
        async for chunk in stream_chat_completions(byte_stream):
            chunks.append(chunk)

        final = chunks[-1]
        assert final.governance_report is not None
        assert final.governance_report.verdict == "flagged"
        assert final.governance_report.pii_detected is True
        assert "pii_leak" in final.governance_report.policy_violations

    @pytest.mark.asyncio
    async def test_skips_comment_lines(self) -> None:
        lines = [
            ": heartbeat",
            'data: {"choices": [{"delta": {"content": "Real content"}}], "done": false}',
            'data: {"choices": [], "done": true, "governance": {"verdict": "allowed", "pii_detected": false, "injection_detected": false, "policy_violations": [], "overhead_ms": 0.0, "request_id": ""}}',
        ]
        byte_stream = await self._make_byte_stream(lines)

        chunks = []
        async for chunk in stream_chat_completions(byte_stream):
            chunks.append(chunk)

        assert len(chunks) == 2
        assert chunks[0].content == "Real content"

    @pytest.mark.asyncio
    async def test_stops_after_done_chunk(self) -> None:
        lines = [
            'data: {"choices": [], "done": true, "governance": {"verdict": "allowed", "pii_detected": false, "injection_detected": false, "policy_violations": [], "overhead_ms": 0.0, "request_id": ""}}',
            'data: {"choices": [{"delta": {"content": "Should not appear"}}], "done": false}',
        ]
        byte_stream = await self._make_byte_stream(lines)

        chunks = []
        async for chunk in stream_chat_completions(byte_stream):
            chunks.append(chunk)

        assert len(chunks) == 1
        assert chunks[0].done is True
