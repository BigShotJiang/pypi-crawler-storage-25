"""Tests for the async HTTP client wrapper."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from truthvouch.exceptions import AuthenticationError, TruthVouchError
from truthvouch.governance.http import AsyncHttpClient


class TestAsyncHttpClientTls:
    def test_http_localhost_allowed(self) -> None:
        client = AsyncHttpClient(api_key="vt_live_test", base_url="http://localhost:8080")
        # Should not raise
        client._enforce_tls("http://localhost:8080/path")

    def test_http_remote_raises(self) -> None:
        client = AsyncHttpClient(api_key="vt_live_test", base_url="http://api.example.com")
        with pytest.raises(TruthVouchError, match="TLS required"):
            client._enforce_tls("http://api.example.com/path")


class TestAsyncHttpClientGet:
    async def test_auth_error_on_401(self) -> None:
        with patch.object(httpx.AsyncClient, "get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 401
            mock_get.return_value = mock_response

            client = AsyncHttpClient(api_key="vt_live_test", base_url="http://localhost")
            with pytest.raises(AuthenticationError):
                await client.get("/test")
            assert mock_get.call_count == 1
            await client.aclose()

    async def test_retries_on_500(self) -> None:
        with patch.object(httpx.AsyncClient, "get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 500
            mock_response.request = MagicMock()
            mock_get.return_value = mock_response

            with patch("asyncio.sleep", new_callable=AsyncMock):
                client = AsyncHttpClient(api_key="vt_live_test", base_url="http://localhost")
                with pytest.raises(TruthVouchError):
                    await client.get("/test")
                assert mock_get.call_count == 3
                await client.aclose()

    async def test_success_response(self) -> None:
        with patch.object(httpx.AsyncClient, "get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"key": "value"}
            mock_get.return_value = mock_response

            client = AsyncHttpClient(api_key="vt_live_test", base_url="http://localhost")
            result = await client.get("/test")
            assert result == {"key": "value"}
            await client.aclose()

    async def test_auth_error_on_403(self) -> None:
        with patch.object(httpx.AsyncClient, "get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 403
            mock_get.return_value = mock_response

            client = AsyncHttpClient(api_key="vt_live_test", base_url="http://localhost")
            with pytest.raises(AuthenticationError):
                await client.get("/test")
            await client.aclose()


class TestAsyncHttpClientPost:
    async def test_success_response(self) -> None:
        with patch.object(httpx.AsyncClient, "post") as mock_post:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"posted": True}
            mock_post.return_value = mock_response

            client = AsyncHttpClient(api_key="vt_live_test", base_url="http://localhost")
            result = await client.post("/test", body={"data": "value"})
            assert result == {"posted": True}
            await client.aclose()

    async def test_retries_on_502(self) -> None:
        with patch.object(httpx.AsyncClient, "post") as mock_post:
            fail_response = MagicMock()
            fail_response.status_code = 502
            fail_response.request = MagicMock()

            success_response = MagicMock()
            success_response.status_code = 200
            success_response.json.return_value = {"ok": True}

            mock_post.side_effect = [fail_response, success_response]

            with patch("asyncio.sleep", new_callable=AsyncMock):
                client = AsyncHttpClient(api_key="vt_live_test", base_url="http://localhost")
                result = await client.post("/test", body={})
                assert result == {"ok": True}
                await client.aclose()

    async def test_auth_error_on_401(self) -> None:
        with patch.object(httpx.AsyncClient, "post") as mock_post:
            mock_response = MagicMock()
            mock_response.status_code = 401
            mock_post.return_value = mock_response

            client = AsyncHttpClient(api_key="vt_live_test", base_url="http://localhost")
            with pytest.raises(AuthenticationError):
                await client.post("/test", body={})
            await client.aclose()
