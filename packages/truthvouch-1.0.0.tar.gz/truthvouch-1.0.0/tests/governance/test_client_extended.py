"""Extended tests for GovernanceClient covering bootstrap success, refresh, and telemetry."""

from __future__ import annotations

import threading
import time
from unittest.mock import MagicMock, patch

import pytest

from truthvouch.governance.client import GovernanceClient
from truthvouch.governance.config import ClientConfig
from truthvouch.exceptions import AuthenticationError


class TestBootstrapSuccess:
    def test_bootstrap_updates_config(self) -> None:
        """Successful bootstrap should update config and clear degraded flag."""
        bootstrap_data = {
            "bannedPhrases": ["forbidden"],
            "tier": "pro",
            "budgetUsd": 100.0,
            "budgetSpentUsd": 10.0,
            "truthScanEnabled": True,
            "piiRemoteEnabled": False,
            "policyRefreshIntervalS": 300,
        }
        with patch("truthvouch.governance.http.HttpClient.get", return_value=bootstrap_data):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.wait(timeout=2.0)
            assert client._config.degraded is False
            assert client._config.tier == "pro"
            assert "forbidden" in client._config.banned_phrases
            client.shutdown()

    def test_bootstrap_auth_failure_stays_degraded(self) -> None:
        with patch(
            "truthvouch.governance.http.HttpClient.get",
            side_effect=AuthenticationError("bad key"),
        ):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.wait(timeout=2.0)
            assert client._config.degraded is True
            client.shutdown()


class TestPolicyRefresh:
    def test_refresh_config_updates_config(self) -> None:
        with patch.object(GovernanceClient, "_bootstrap"):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.set()

            refresh_data = {
                "bannedPhrases": ["refreshed"],
                "tier": "enterprise",
                "budgetUsd": 200.0,
                "budgetSpentUsd": 0.0,
            }
            with patch("truthvouch.governance.http.HttpClient.get", return_value=refresh_data):
                client._refresh_config()
            assert "refreshed" in client._config.banned_phrases
            client.shutdown()

    def test_refresh_config_failure_does_not_crash(self) -> None:
        with patch.object(GovernanceClient, "_bootstrap"):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.set()

            with patch("truthvouch.governance.http.HttpClient.get", side_effect=Exception("network down")):
                client._refresh_config()  # Should not raise
            client.shutdown()


class TestTelemetryEmit:
    def test_telemetry_event_emitted_on_pass(self) -> None:
        with patch.object(GovernanceClient, "_bootstrap"):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.set()
            mock_buffer = MagicMock()
            client._audit_buffer = mock_buffer

            client.evaluate_input("Hello!", model="gpt-4o")
            mock_buffer.push.assert_called_once()
            client.shutdown()

    def test_telemetry_event_not_emitted_without_buffer(self) -> None:
        with patch.object(GovernanceClient, "_bootstrap"):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.set()
            # audit_buffer is None (degraded mode)
            assert client._audit_buffer is None
            # Should not raise
            client.evaluate_input("Hello!", model="gpt-4o")
            client.shutdown()

    def test_block_verdict_in_event(self) -> None:
        with patch.object(GovernanceClient, "_bootstrap"):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.set()
            client._config = ClientConfig(banned_phrases=["blocked"], degraded=True)
            mock_buffer = MagicMock()
            client._audit_buffer = mock_buffer

            client.evaluate_input("this is blocked text", model="gpt-4o")

            event = mock_buffer.push.call_args[0][0]
            assert event.verdict == "block"
            client.shutdown()

    def test_flag_verdict_in_event(self) -> None:
        with patch.object(GovernanceClient, "_bootstrap"):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.set()
            mock_buffer = MagicMock()
            client._audit_buffer = mock_buffer

            client.evaluate_input("My SSN is 123-45-6789.", model="gpt-4o")

            event = mock_buffer.push.call_args[0][0]
            # SSN should flag
            assert event.verdict in ("flag", "pass")
            client.shutdown()


class TestRemoteGuardsRunWhenNotDegraded:
    def test_remote_guards_run_on_output_when_not_degraded(self) -> None:
        """When config is not degraded and truth_scan_enabled, TruthGuard should be called."""
        with patch.object(GovernanceClient, "_bootstrap"):
            client = GovernanceClient(
                api_key="vt_live_test",
                base_url="http://localhost",
                policy_refresh_interval_s=0,
            )
            client._bootstrap_event.set()
            from truthvouch.governance.config import ClientConfig
            client._config = ClientConfig(
                truth_scan_enabled=True,
                degraded=False,
            )

            with patch("truthvouch.governance.guards.truth.TruthGuard.evaluate") as mock_truth:
                from truthvouch.governance.models import GuardResult, GuardVerdict
                mock_truth.return_value = GuardResult(
                    guard_name="truth", verdict=GuardVerdict.PASS
                )
                client.evaluate_output("Some output.", model="gpt-4o")
                mock_truth.assert_called_once()
            client.shutdown()
