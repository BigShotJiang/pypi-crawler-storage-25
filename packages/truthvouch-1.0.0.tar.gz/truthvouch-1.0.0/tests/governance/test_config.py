"""Tests for config.py bootstrap parsing."""

from __future__ import annotations

import pytest

from truthvouch.governance.config import ClientConfig, ModelPricing, parse_bootstrap_response


# ---------------------------------------------------------------------------
# Full nested structure (matches .NET SdkBootstrapResponse exactly)
# ---------------------------------------------------------------------------

_NESTED_RESPONSE: dict = {
    "clientId": "00000000-0000-0000-0000-000000000001",
    "config": {
        "piiScanEnabled": True,
        "piiEntityTypes": ["PERSON", "EMAIL"],
        "piiConfidenceThreshold": 0.5,
        "injectionCheckEnabled": True,
        "injectionConfidenceThreshold": 0.85,
        "truthScanEnabled": True,
        "bannedPhrases": ["forbidden"],
        "allowedModels": ["gpt-4o"],
        "maxTokensPerRequest": 8192,
        "costTrackingEnabled": True,
    },
    "budget": {
        "totalBudget": 5000.00,
        "spentThisPeriod": 3200.00,
        "remaining": 1800.00,
        "period": "monthly",
        "alerts": [],
    },
    "sdkConfig": {
        "telemetryBatchIntervalS": 5,
        "telemetryMaxBatchSize": 100,
        "policyRefreshIntervalS": 300,
        "bootstrapCacheTtlS": 300,
        "minSdkVersion": "0.1.0",
    },
}


class TestParseBootstrapResponseNested:
    """Tests using the real nested .NET response structure."""

    def test_client_id_parsed(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="https://api.truthvouch.ai")
        assert config.client_id == "00000000-0000-0000-0000-000000000001"

    def test_pii_entity_types_from_config_block(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.pii_entity_types == ["PERSON", "EMAIL"]

    def test_truth_scan_enabled_from_config_block(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.truth_scan_enabled is True

    def test_banned_phrases_from_config_block(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.banned_phrases == ["forbidden"]

    def test_allowed_models_from_config_block(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.allowed_models == ["gpt-4o"]

    def test_max_tokens_from_config_block(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.max_tokens_per_request == 8192

    def test_budget_remaining_maps_to_budget_usd(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.budget_usd == 1800.00

    def test_budget_spent_maps_to_budget_spent_usd(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.budget_spent_usd == 3200.00

    def test_policy_refresh_interval_from_sdk_config(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.policy_refresh_interval_s == 300

    def test_cost_tracking_enabled_from_config_block(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.cost_tracking_enabled is True

    def test_api_base_url_set(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="https://my.server.com")
        assert config.api_base_url == "https://my.server.com"

    def test_degraded_false_after_parse(self) -> None:
        config = parse_bootstrap_response(_NESTED_RESPONSE, api_base_url="")
        assert config.degraded is False


# ---------------------------------------------------------------------------
# Back-compat: flat key format (pre-nested server responses)
# ---------------------------------------------------------------------------

class TestParseBootstrapResponse:
    def test_empty_dict_returns_defaults(self) -> None:
        config = parse_bootstrap_response({}, api_base_url="https://api.truthvouch.ai")
        assert config.banned_phrases == []
        assert config.truth_scan_enabled is False
        assert config.pii_remote_enabled is False
        assert config.budget_usd == 0.0
        assert config.tier == "free"
        assert config.degraded is False

    def test_api_base_url_set(self) -> None:
        config = parse_bootstrap_response({}, api_base_url="https://my.server.com")
        assert config.api_base_url == "https://my.server.com"

    def test_banned_phrases_parsed(self) -> None:
        config = parse_bootstrap_response(
            {"bannedPhrases": ["secret", "confidential"]},
            api_base_url="",
        )
        assert config.banned_phrases == ["secret", "confidential"]

    def test_pii_entity_types_parsed(self) -> None:
        config = parse_bootstrap_response(
            {"piiEntityTypes": ["EMAIL", "SSN"]},
            api_base_url="",
        )
        assert config.pii_entity_types == ["EMAIL", "SSN"]

    def test_truth_scan_enabled_parsed(self) -> None:
        config = parse_bootstrap_response({"truthScanEnabled": True}, api_base_url="")
        assert config.truth_scan_enabled is True

    def test_pii_remote_enabled_parsed(self) -> None:
        config = parse_bootstrap_response({"piiRemoteEnabled": True}, api_base_url="")
        assert config.pii_remote_enabled is True

    def test_budget_parsed(self) -> None:
        config = parse_bootstrap_response(
            {"budgetUsd": 50.0, "budgetSpentUsd": 12.5},
            api_base_url="",
        )
        assert config.budget_usd == 50.0
        assert config.budget_spent_usd == 12.5

    def test_invalid_budget_defaults_to_zero(self) -> None:
        config = parse_bootstrap_response({"budgetUsd": "not-a-number"}, api_base_url="")
        assert config.budget_usd == 0.0

    def test_invalid_budget_spent_defaults_to_zero(self) -> None:
        config = parse_bootstrap_response({"budgetSpentUsd": None}, api_base_url="")
        assert config.budget_spent_usd == 0.0

    def test_policy_refresh_interval_parsed(self) -> None:
        config = parse_bootstrap_response({"policyRefreshIntervalS": 600}, api_base_url="")
        assert config.policy_refresh_interval_s == 600

    def test_invalid_refresh_interval_defaults(self) -> None:
        config = parse_bootstrap_response({"policyRefreshIntervalS": "bad"}, api_base_url="")
        assert config.policy_refresh_interval_s == 300

    def test_tier_parsed(self) -> None:
        config = parse_bootstrap_response({"tier": "enterprise"}, api_base_url="")
        assert config.tier == "enterprise"

    def test_model_pricing_parsed(self) -> None:
        config = parse_bootstrap_response(
            {
                "modelPricing": {
                    "my-model": {
                        "inputCostPer1k": 0.01,
                        "outputCostPer1k": 0.03,
                    }
                }
            },
            api_base_url="",
        )
        assert "my-model" in config.model_pricing
        assert config.model_pricing["my-model"].input_cost_per_1k == 0.01
        assert config.model_pricing["my-model"].output_cost_per_1k == 0.03

    def test_invalid_model_pricing_skipped(self) -> None:
        config = parse_bootstrap_response(
            {"modelPricing": {"bad-model": "not-a-dict"}},
            api_base_url="",
        )
        # Should not crash, just skip
        assert "bad-model" not in config.model_pricing

    def test_non_list_banned_phrases_skipped(self) -> None:
        config = parse_bootstrap_response({"bannedPhrases": "not-a-list"}, api_base_url="")
        assert config.banned_phrases == []

    def test_model_pricing_not_dict_ignored(self) -> None:
        config = parse_bootstrap_response({"modelPricing": "invalid"}, api_base_url="")
        # Should keep default pricing, not crash
        assert len(config.model_pricing) > 0


class TestClientConfigDefaults:
    def test_degraded_false_by_default(self) -> None:
        config = ClientConfig()
        assert config.degraded is False

    def test_default_pii_entity_types(self) -> None:
        config = ClientConfig()
        assert "SSN" in config.pii_entity_types
        assert "EMAIL" in config.pii_entity_types

    def test_model_pricing_has_defaults(self) -> None:
        config = ClientConfig()
        assert "gpt-4o" in config.model_pricing

    def test_new_fields_have_safe_defaults(self) -> None:
        config = ClientConfig()
        assert config.pii_scan_enabled is True
        assert config.injection_check_enabled is True
        assert config.cost_tracking_enabled is True
        assert config.max_tokens_per_request == 8192
        assert config.allowed_models == []
        assert config.client_id == ""
