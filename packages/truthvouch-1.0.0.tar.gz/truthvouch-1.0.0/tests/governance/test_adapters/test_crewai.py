"""Tests for the TruthVouchMiddleware (CrewAI adapter)."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from truthvouch.governance.adapters.crewai import TruthVouchMiddleware, _GovernanceLLMWrapper
from truthvouch.exceptions import GovernanceBlockError
from truthvouch.governance.models import EvaluationResult, GuardVerdict


def _make_pass_result(direction: str = "input") -> EvaluationResult:
    return EvaluationResult(
        blocked=False,
        flagged=False,
        block_reasons=[],
        flag_reasons=[],
        guard_results=[],
        direction=direction,
    )


def _make_block_result(direction: str = "input") -> EvaluationResult:
    return EvaluationResult(
        blocked=True,
        flagged=False,
        block_reasons=["banned phrase"],
        flag_reasons=[],
        guard_results=[],
        direction=direction,
    )


class TestTruthVouchMiddlewareWrapLlm:
    def test_wrap_returns_governance_wrapper(self) -> None:
        client = MagicMock()
        middleware = TruthVouchMiddleware(client, model="gpt-4o")
        mock_llm = MagicMock()
        wrapper = middleware.wrap_llm(mock_llm)
        assert isinstance(wrapper, _GovernanceLLMWrapper)

    def test_model_inferred_from_llm_attribute(self) -> None:
        client = MagicMock()
        middleware = TruthVouchMiddleware(client)
        mock_llm = MagicMock()
        mock_llm.model_name = "gpt-4o-mini"
        wrapper = middleware.wrap_llm(mock_llm)
        assert object.__getattribute__(wrapper, "_model") == "gpt-4o-mini"

    def test_explicit_model_overrides_llm_attribute(self) -> None:
        client = MagicMock()
        middleware = TruthVouchMiddleware(client, model="gpt-4o")
        mock_llm = MagicMock()
        mock_llm.model_name = "gpt-3.5-turbo"
        wrapper = middleware.wrap_llm(mock_llm)
        assert object.__getattribute__(wrapper, "_model") == "gpt-4o"


class TestGovernanceLLMWrapperInvoke:
    def _make_wrapper(
        self,
        input_result: EvaluationResult,
        output_result: EvaluationResult,
    ) -> _GovernanceLLMWrapper:
        client = MagicMock()
        client.evaluate_input.return_value = input_result
        client.evaluate_output.return_value = output_result
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = "LLM response"
        return _GovernanceLLMWrapper(llm=mock_llm, client=client, model="gpt-4o")

    def test_invoke_calls_llm_on_pass(self) -> None:
        wrapper = self._make_wrapper(
            _make_pass_result("input"),
            _make_pass_result("output"),
        )
        result = wrapper.invoke("Hello LLM")
        llm = object.__getattribute__(wrapper, "_llm")
        llm.invoke.assert_called_once_with("Hello LLM")
        assert result == "LLM response"

    def test_invoke_raises_on_blocked_input(self) -> None:
        wrapper = self._make_wrapper(
            _make_block_result("input"),
            _make_pass_result("output"),
        )
        with pytest.raises(GovernanceBlockError) as exc_info:
            wrapper.invoke("confidential data here")
        assert "blocked" in str(exc_info.value).lower()

    def test_invoke_raises_on_blocked_output(self) -> None:
        wrapper = self._make_wrapper(
            _make_pass_result("input"),
            _make_block_result("output"),
        )
        with pytest.raises(GovernanceBlockError):
            wrapper.invoke("normal input")

    def test_call_method_works(self) -> None:
        client = MagicMock()
        client.evaluate_input.return_value = _make_pass_result("input")
        client.evaluate_output.return_value = _make_pass_result("output")
        mock_llm = MagicMock()
        mock_llm.return_value = "called result"
        wrapper = _GovernanceLLMWrapper(llm=mock_llm, client=client, model="gpt-4o")
        result = wrapper("some prompt")
        assert result == "called result"


class TestGovernanceLLMWrapperGenerate:
    def test_generate_calls_underlying_llm(self) -> None:
        client = MagicMock()
        client.evaluate_input.return_value = _make_pass_result()
        client.evaluate_output.return_value = _make_pass_result("output")
        mock_llm = MagicMock()
        mock_llm.generate.return_value = "generated output"
        wrapper = _GovernanceLLMWrapper(llm=mock_llm, client=client, model="gpt-4o")
        result = wrapper.generate("test prompt")
        mock_llm.generate.assert_called_once_with("test prompt")
        assert result == "generated output"


class TestGovernanceLLMWrapperAttributeProxy:
    def test_attribute_access_proxied_to_llm(self) -> None:
        client = MagicMock()
        mock_llm = MagicMock()
        mock_llm.temperature = 0.7
        wrapper = _GovernanceLLMWrapper(llm=mock_llm, client=client, model="gpt-4o")
        assert wrapper.temperature == 0.7

    def test_unknown_attribute_raises(self) -> None:
        client = MagicMock()
        mock_llm = MagicMock(spec=["invoke"])
        wrapper = _GovernanceLLMWrapper(llm=mock_llm, client=client, model="gpt-4o")
        with pytest.raises(AttributeError):
            _ = wrapper.nonexistent_attribute_xyz


class TestExtractInputText:
    def _wrapper(self) -> _GovernanceLLMWrapper:
        return _GovernanceLLMWrapper(
            llm=MagicMock(), client=MagicMock(), model="gpt-4o"
        )

    def test_string_arg(self) -> None:
        w = self._wrapper()
        assert w._extract_input_text("hello") == "hello"

    def test_list_of_strings(self) -> None:
        w = self._wrapper()
        result = w._extract_input_text(["one", "two"])
        assert "one" in result and "two" in result

    def test_list_of_dicts(self) -> None:
        w = self._wrapper()
        result = w._extract_input_text([{"content": "msg1"}, {"content": "msg2"}])
        assert "msg1" in result

    def test_kwarg_prompt(self) -> None:
        w = self._wrapper()
        result = w._extract_input_text(prompt="kwarg prompt")
        assert result == "kwarg prompt"
