"""Extended tests for the LangGraph adapter — async callbacks."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from truthvouch.governance.adapters.langgraph import TruthVouchCallbackHandler
from truthvouch.exceptions import GovernanceBlockError
from truthvouch.governance.models import EvaluationResult, GuardVerdict


def _make_pass_result(direction: str = "input") -> EvaluationResult:
    return EvaluationResult(
        blocked=False, flagged=False, block_reasons=[], flag_reasons=[],
        guard_results=[], direction=direction,
    )


def _make_block_result(direction: str = "input") -> EvaluationResult:
    return EvaluationResult(
        blocked=True, flagged=False, block_reasons=["blocked"],
        flag_reasons=[], guard_results=[], direction=direction,
    )


def _make_flag_result(direction: str = "input") -> EvaluationResult:
    return EvaluationResult(
        blocked=False, flagged=True, block_reasons=[],
        flag_reasons=["PII detected"], guard_results=[], direction=direction,
    )


class _MockGeneration:
    def __init__(self, text: str) -> None:
        self.text = text


class _MockLLMResult:
    def __init__(self, text: str) -> None:
        self.generations = [[_MockGeneration(text)]]


class TestAsyncCallbacks:
    async def test_on_llm_start_async_passes(self) -> None:
        client = MagicMock()
        client.evaluate_input = AsyncMock(return_value=_make_pass_result())
        handler = TruthVouchCallbackHandler(client, model="gpt-4o")
        await handler.on_llm_start_async({}, ["Hello!"])
        client.evaluate_input.assert_called_once()

    async def test_on_llm_start_async_blocks(self) -> None:
        client = MagicMock()
        client.evaluate_input = AsyncMock(return_value=_make_block_result())
        handler = TruthVouchCallbackHandler(client)
        with pytest.raises(GovernanceBlockError):
            await handler.on_llm_start_async({}, ["injection text"])

    async def test_on_llm_end_async_passes(self) -> None:
        client = MagicMock()
        client.evaluate_output = AsyncMock(return_value=_make_pass_result("output"))
        handler = TruthVouchCallbackHandler(client)
        response = _MockLLMResult("normal response")
        await handler.on_llm_end_async(response)
        assert response.generations[0][0].text == "normal response"

    async def test_on_llm_end_async_blocks_replaces_text(self) -> None:
        client = MagicMock()
        client.evaluate_output = AsyncMock(return_value=_make_block_result("output"))
        handler = TruthVouchCallbackHandler(client, block_message="[BLOCKED]")
        response = _MockLLMResult("bad output")
        await handler.on_llm_end_async(response)
        assert response.generations[0][0].text == "[BLOCKED]"

    async def test_on_llm_end_async_bad_response_does_not_raise(self) -> None:
        client = MagicMock()
        client.evaluate_output = AsyncMock(return_value=_make_pass_result("output"))
        handler = TruthVouchCallbackHandler(client)
        # Response that raises on attribute access
        bad_response = MagicMock()
        bad_response.generations = None
        # _extract_llm_result_text should fall back gracefully
        await handler.on_llm_end_async(bad_response)


class TestSyncFlaggedCallbacks:
    def test_on_llm_start_flagged_does_not_raise(self) -> None:
        client = MagicMock()
        client.evaluate_input.return_value = _make_flag_result()
        handler = TruthVouchCallbackHandler(client)
        # FLAG should not raise, just log
        handler.on_llm_start({}, ["flagged prompt"])

    def test_on_llm_end_flagged_does_not_replace(self) -> None:
        client = MagicMock()
        client.evaluate_output.return_value = _make_flag_result("output")
        handler = TruthVouchCallbackHandler(client)
        response = _MockLLMResult("flagged output")
        handler.on_llm_end(response)
        # Text should be unchanged
        assert response.generations[0][0].text == "flagged output"

    def test_on_tool_error_does_not_raise(self) -> None:
        client = MagicMock()
        handler = TruthVouchCallbackHandler(client)
        handler.on_tool_error(RuntimeError("tool failed"))
