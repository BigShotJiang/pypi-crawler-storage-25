"""Tests for the HTTP client wrapper."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest

from truthvouch.exceptions import AuthenticationError, TruthVouchError
from truthvouch.governance.http import HttpClient, _build_user_agent


class TestUserAgent:
    def test_user_agent_format(self) -> None:
        ua = _build_user_agent()
        assert ua.startswith("truthvouch-sdk/")
        assert "python/" in ua


class TestTlsEnforcement:
    def test_http_localhost_allowed(self) -> None:
        client = HttpClient(api_key="vt_live_test", base_url="http://localhost:8080")
        # Should not raise on localhost
        client._enforce_tls("http://localhost:8080/api/v1/test")
        client.close()

    def test_http_127_allowed(self) -> None:
        client = HttpClient(api_key="vt_live_test", base_url="http://127.0.0.1")
        client._enforce_tls("http://127.0.0.1/api/v1/test")
        client.close()

    def test_http_remote_raises(self) -> None:
        client = HttpClient(api_key="vt_live_test", base_url="http://api.truthvouch.ai")
        with pytest.raises(TruthVouchError, match="TLS required"):
            client._enforce_tls("http://api.truthvouch.ai/api/v1/test")
        client.close()


class TestHttpClientRetries:
    def test_auth_error_on_401(self) -> None:
        """401 should raise AuthenticationError without retrying."""
        with patch("httpx.Client.get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 401
            mock_get.return_value = mock_response

            client = HttpClient(api_key="vt_live_test", base_url="http://localhost")
            with pytest.raises(AuthenticationError):
                client.get("/test")
            # Should only call once (no retry on auth failure)
            assert mock_get.call_count == 1
            client.close()

    def test_auth_error_on_403(self) -> None:
        with patch("httpx.Client.get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 403
            mock_get.return_value = mock_response

            client = HttpClient(api_key="vt_live_test", base_url="http://localhost")
            with pytest.raises(AuthenticationError):
                client.get("/test")
            client.close()

    def test_retries_on_500(self) -> None:
        """500 should retry up to 3 times."""
        with patch("httpx.Client.get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 500
            mock_response.request = MagicMock()
            mock_get.return_value = mock_response

            with patch("time.sleep"):
                client = HttpClient(api_key="vt_live_test", base_url="http://localhost")
                with pytest.raises(TruthVouchError):
                    client.get("/test")
                assert mock_get.call_count == 3
                client.close()

    def test_success_on_second_attempt(self) -> None:
        """Should succeed if a retry succeeds."""
        with patch("httpx.Client.get") as mock_get:
            fail_response = MagicMock()
            fail_response.status_code = 503
            fail_response.request = MagicMock()

            success_response = MagicMock()
            success_response.status_code = 200
            success_response.json.return_value = {"ok": True}

            mock_get.side_effect = [fail_response, success_response]

            with patch("time.sleep"):
                client = HttpClient(api_key="vt_live_test", base_url="http://localhost")
                result = client.get("/test")
                assert result == {"ok": True}
                assert mock_get.call_count == 2
                client.close()

    def test_authorization_header_sent(self) -> None:
        with patch("httpx.Client.get") as mock_get:
            success_response = MagicMock()
            success_response.status_code = 200
            success_response.json.return_value = {}
            mock_get.return_value = success_response

            client = HttpClient(api_key="vt_live_mykey", base_url="http://localhost")
            client.get("/test")
            client.close()

            # Verify the client was initialized with auth header
            # (headers are set at client init, not per-call)
            assert client._api_key == "vt_live_mykey"

    def test_post_retries_on_502(self) -> None:
        with patch("httpx.Client.post") as mock_post:
            fail_response = MagicMock()
            fail_response.status_code = 502
            fail_response.request = MagicMock()

            success_response = MagicMock()
            success_response.status_code = 200
            success_response.json.return_value = {"result": "ok"}

            mock_post.side_effect = [fail_response, success_response]

            with patch("time.sleep"):
                client = HttpClient(api_key="vt_live_test", base_url="http://localhost")
                result = client.post("/test", body={"key": "value"})
                assert result == {"result": "ok"}
                client.close()

    def test_network_error_retried(self) -> None:
        with patch("httpx.Client.get") as mock_get:
            mock_get.side_effect = httpx.ConnectError("connection refused")

            with patch("time.sleep"):
                client = HttpClient(api_key="vt_live_test", base_url="http://localhost")
                with pytest.raises(TruthVouchError):
                    client.get("/test")
                assert mock_get.call_count == 3
                client.close()
