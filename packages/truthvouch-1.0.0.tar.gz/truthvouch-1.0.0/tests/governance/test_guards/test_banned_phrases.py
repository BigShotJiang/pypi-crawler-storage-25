"""Tests for the BannedPhrasesGuard."""

from __future__ import annotations

import pytest

from truthvouch.governance.config import ClientConfig
from truthvouch.governance.guards.banned_phrases import BannedPhrasesGuard
from truthvouch.governance.models import GuardContext, GuardVerdict


def _make_context(phrases: list[str]) -> GuardContext:
    config = ClientConfig(banned_phrases=phrases, degraded=False)
    return GuardContext(direction="input", model="gpt-4o", config=config)


@pytest.fixture
def guard() -> BannedPhrasesGuard:
    return BannedPhrasesGuard()


class TestBannedPhrasesGuard:
    def test_name(self, guard: BannedPhrasesGuard) -> None:
        assert guard.name == "banned_phrases"

    def test_is_local(self, guard: BannedPhrasesGuard) -> None:
        assert guard.is_local is True

    def test_exact_match_blocks(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context(["confidential"])
        result = guard.evaluate("This is confidential information.", "input", ctx)
        assert result.verdict == GuardVerdict.BLOCK
        assert "confidential" in result.details["matched_phrases"]

    def test_case_insensitive_match(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context(["top secret"])
        result = guard.evaluate("This is TOP SECRET data.", "input", ctx)
        assert result.verdict == GuardVerdict.BLOCK

    def test_uppercase_phrase_matches_lowercase_text(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context(["BANNED"])
        result = guard.evaluate("this is banned content", "input", ctx)
        assert result.verdict == GuardVerdict.BLOCK

    def test_no_match_passes(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context(["confidential", "top secret"])
        result = guard.evaluate("This is a perfectly fine message.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert result.details["matched_phrases"] == []

    def test_empty_phrase_list_passes(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context([])
        result = guard.evaluate("Any text at all.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_multiple_phrases_all_reported(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context(["foo", "bar"])
        result = guard.evaluate("foo and bar are both here", "input", ctx)
        assert result.verdict == GuardVerdict.BLOCK
        assert set(result.details["matched_phrases"]) == {"foo", "bar"}

    def test_partial_word_match(self, guard: BannedPhrasesGuard) -> None:
        # Substring matching — "secret" matches inside "secretary"
        ctx = _make_context(["secret"])
        result = guard.evaluate("The secretary sent the email.", "input", ctx)
        assert result.verdict == GuardVerdict.BLOCK

    def test_message_contains_matched_phrase(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context(["classified"])
        result = guard.evaluate("This is classified data.", "input", ctx)
        assert result.verdict == GuardVerdict.BLOCK
        assert "classified" in result.message

    def test_output_direction(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context(["forbidden"])
        result = guard.evaluate("This output is forbidden.", "output", ctx)
        assert result.verdict == GuardVerdict.BLOCK

    def test_duration_ms_populated(self, guard: BannedPhrasesGuard) -> None:
        ctx = _make_context(["test"])
        result = guard.evaluate("hello", "input", ctx)
        assert result.duration_ms >= 0.0
