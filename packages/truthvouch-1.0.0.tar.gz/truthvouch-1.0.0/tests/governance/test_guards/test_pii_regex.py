"""Tests for the PiiRegexGuard."""

from __future__ import annotations

import pytest

from truthvouch.governance.config import ClientConfig
from truthvouch.governance.guards.pii_regex import PiiRegexGuard, _luhn_valid, _scan
from truthvouch.governance.models import GuardContext, GuardVerdict


def _make_context(entity_types: list[str] | None = None) -> GuardContext:
    config = ClientConfig(
        pii_entity_types=entity_types or ["EMAIL", "SSN", "CREDIT_CARD", "PHONE", "PASSPORT", "ADDRESS"],
        degraded=False,
    )
    return GuardContext(direction="input", model="gpt-4o", config=config)


@pytest.fixture
def guard() -> PiiRegexGuard:
    return PiiRegexGuard()


# ---------------------------------------------------------------------------
# Luhn validation
# ---------------------------------------------------------------------------

class TestLuhnValid:
    def test_valid_visa(self) -> None:
        # Classic test number known to pass Luhn
        assert _luhn_valid("4532015112830366") is True

    def test_valid_mastercard(self) -> None:
        assert _luhn_valid("5425233430109903") is True

    def test_invalid(self) -> None:
        assert _luhn_valid("1234567890123456") is False

    def test_single_digit_zero(self) -> None:
        # Luhn of "0" is valid (0 mod 10 == 0)
        assert _luhn_valid("0") is True


# ---------------------------------------------------------------------------
# SSN detection
# ---------------------------------------------------------------------------

class TestSSNDetection:
    def test_dashed_ssn_detected(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["SSN"])
        result = guard.evaluate("My SSN is 123-45-6789.", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG
        assert any(m["entity_type"] == "SSN" for m in result.details["matches"])

    def test_plain_ssn_with_context(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["SSN"])
        result = guard.evaluate("ssn 123456789 is private", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG

    def test_plain_ssn_without_context_not_detected(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["SSN"])
        # Plain 9-digit number with no SSN context words
        result = guard.evaluate("Call number 123456789 for help.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_invalid_ssn_prefix_not_detected(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["SSN"])
        # Starts with 000 — excluded by regex
        result = guard.evaluate("My SSN is 000-45-6789.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_dashed_ssn_excluded_000(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["SSN"])
        result = guard.evaluate("SSN: 666-45-6789", "input", ctx)
        # 666 prefix is excluded
        assert result.verdict == GuardVerdict.PASS


# ---------------------------------------------------------------------------
# Credit card detection
# ---------------------------------------------------------------------------

class TestCreditCardDetection:
    def test_valid_cc_detected(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["CREDIT_CARD"])
        result = guard.evaluate("Card: 4532015112830366", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG

    def test_luhn_invalid_cc_not_detected(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["CREDIT_CARD"])
        result = guard.evaluate("Card: 1234567890123456", "input", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_cc_with_spaces(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["CREDIT_CARD"])
        result = guard.evaluate("Card: 4532 0151 1283 0366", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG

    def test_cc_with_dashes(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["CREDIT_CARD"])
        result = guard.evaluate("Card: 4532-0151-1283-0366", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG


# ---------------------------------------------------------------------------
# Email detection
# ---------------------------------------------------------------------------

class TestEmailDetection:
    def test_email_detected(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["EMAIL"])
        result = guard.evaluate("Contact me at john.doe@example.com please.", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG
        assert any(m["entity_type"] == "EMAIL" for m in result.details["matches"])

    def test_email_in_middle_of_text(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["EMAIL"])
        result = guard.evaluate("Send to user+tag@sub.domain.org", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG

    def test_no_email_passes(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["EMAIL"])
        result = guard.evaluate("Hello, how are you today?", "input", ctx)
        assert result.verdict == GuardVerdict.PASS


# ---------------------------------------------------------------------------
# Phone detection
# ---------------------------------------------------------------------------

class TestPhoneDetection:
    @pytest.mark.parametrize("text", [
        "Call me at +1 (555) 123-4567",
        "Phone: 555.123.4567",
        "UK: +44 20 7946 0958",
        "DE: +49 30 12345678",
        "FR: +33 1 23 45 67 89",
    ])
    def test_phone_formats_detected(self, guard: PiiRegexGuard, text: str) -> None:
        ctx = _make_context(["PHONE"])
        result = guard.evaluate(text, "input", ctx)
        assert result.verdict == GuardVerdict.FLAG

    def test_no_phone_passes(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["PHONE"])
        result = guard.evaluate("No contact info here.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS


# ---------------------------------------------------------------------------
# Passport detection
# ---------------------------------------------------------------------------

class TestPassportDetection:
    def test_passport_detected(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["PASSPORT"])
        result = guard.evaluate("Passport: AB1234567", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG

    def test_single_letter_passport(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["PASSPORT"])
        result = guard.evaluate("Doc: A1234567", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG


# ---------------------------------------------------------------------------
# Address detection
# ---------------------------------------------------------------------------

class TestAddressDetection:
    def test_address_detected(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["ADDRESS"])
        result = guard.evaluate("I live at 123 Main Street, Springfield.", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG

    def test_no_address_passes(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["ADDRESS"])
        result = guard.evaluate("Generic text without location info.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS


# ---------------------------------------------------------------------------
# Guard properties
# ---------------------------------------------------------------------------

class TestPiiRegexGuardProperties:
    def test_name(self, guard: PiiRegexGuard) -> None:
        assert guard.name == "pii_regex"

    def test_is_local(self, guard: PiiRegexGuard) -> None:
        assert guard.is_local is True

    def test_clean_text_passes(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context()
        result = guard.evaluate("This is a perfectly clean sentence.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert result.details["matches"] == []

    def test_configurable_entity_types(self, guard: PiiRegexGuard) -> None:
        """When entity_types excludes EMAIL, emails should not be flagged."""
        ctx = _make_context(["SSN"])  # Only check SSN
        result = guard.evaluate("Contact me at user@example.com", "input", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_multiple_entity_types_in_one_text(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context(["EMAIL", "SSN"])
        result = guard.evaluate(
            "Email: user@example.com and SSN: 123-45-6789", "input", ctx
        )
        assert result.verdict == GuardVerdict.FLAG
        types = {m["entity_type"] for m in result.details["matches"]}
        assert "EMAIL" in types
        assert "SSN" in types

    def test_duration_populated(self, guard: PiiRegexGuard) -> None:
        ctx = _make_context()
        result = guard.evaluate("test", "input", ctx)
        assert result.duration_ms >= 0.0
