"""Tests for the CostGuard."""

from __future__ import annotations

import pytest

from truthvouch.governance.config import ClientConfig, ModelPricing
from truthvouch.governance.guards.cost import CostGuard, estimate_tokens, get_model_pricing
from truthvouch.governance.models import GuardContext, GuardVerdict


def _make_context(
    budget_usd: float = 10.0,
    budget_spent_usd: float = 0.0,
    model: str = "gpt-4o",
) -> GuardContext:
    config = ClientConfig(
        budget_usd=budget_usd,
        budget_spent_usd=budget_spent_usd,
        model_pricing={
            "gpt-4o": ModelPricing(input_cost_per_1k=0.005, output_cost_per_1k=0.015),
            "gpt-4o-mini": ModelPricing(input_cost_per_1k=0.00015, output_cost_per_1k=0.0006),
        },
        degraded=False,
    )
    return GuardContext(direction="input", model=model, config=config)


@pytest.fixture
def guard() -> CostGuard:
    return CostGuard()


class TestEstimateTokens:
    def test_empty_string_returns_zero(self) -> None:
        assert estimate_tokens("") == 0

    def test_single_word(self) -> None:
        # 1 word / 0.75 = 1.33 → int = 1 → max(1, 1) = 1
        assert estimate_tokens("hello") == 1

    def test_token_estimate_proportional(self) -> None:
        # 10 words / 0.75 = 13.33 → 13
        text = "one two three four five six seven eight nine ten"
        tokens = estimate_tokens(text)
        assert tokens == 13

    def test_whitespace_only_returns_zero(self) -> None:
        assert estimate_tokens("   \n\t  ") == 0


class TestGetModelPricing:
    def test_known_model_from_config(self) -> None:
        pricing_map = {"gpt-4o": ModelPricing(input_cost_per_1k=0.005, output_cost_per_1k=0.015)}
        p = get_model_pricing("gpt-4o", pricing_map)
        assert p.input_cost_per_1k == 0.005

    def test_falls_back_to_default_table(self) -> None:
        p = get_model_pricing("gpt-4o", {})
        assert p.input_cost_per_1k > 0.0

    def test_unknown_model_returns_zero_cost(self) -> None:
        p = get_model_pricing("unknown-model-xyz", {})
        assert p.input_cost_per_1k == 0.0
        assert p.output_cost_per_1k == 0.0


class TestCostGuard:
    def test_name(self, guard: CostGuard) -> None:
        assert guard.name == "cost"

    def test_is_local(self, guard: CostGuard) -> None:
        assert guard.is_local is True

    def test_under_budget_passes(self, guard: CostGuard) -> None:
        ctx = _make_context(budget_usd=10.0, budget_spent_usd=0.0)
        # Short text = tiny cost
        result = guard.evaluate("Hello!", "input", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_over_budget_blocks(self, guard: CostGuard) -> None:
        ctx = _make_context(budget_usd=0.001, budget_spent_usd=0.001)
        # Budget exhausted
        result = guard.evaluate("This is a test message.", "input", ctx)
        assert result.verdict == GuardVerdict.BLOCK
        assert "budget" in result.message.lower()

    def test_zero_budget_always_passes(self, guard: CostGuard) -> None:
        ctx = _make_context(budget_usd=0.0)
        result = guard.evaluate("Any text at all.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_unknown_model_passes(self, guard: CostGuard) -> None:
        """Unknown models have zero pricing — should pass to avoid false blocks."""
        ctx = _make_context(budget_usd=0.001, model="unknown-model-xyz")
        result = guard.evaluate("Hello world!", "input", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert result.details.get("reason") == "no pricing data for model"

    def test_output_direction_uses_output_pricing(self, guard: CostGuard) -> None:
        ctx = _make_context(budget_usd=10.0, budget_spent_usd=0.0)
        result = guard.evaluate("Short output text.", "output", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert result.details.get("direction") == "output"

    def test_details_include_token_estimate(self, guard: CostGuard) -> None:
        ctx = _make_context(budget_usd=10.0)
        result = guard.evaluate("Hello world", "input", ctx)
        assert "estimated_tokens" in result.details
        assert result.details["estimated_tokens"] >= 1

    def test_budget_nearly_exhausted_precise_block(self, guard: CostGuard) -> None:
        # Set spent to just 1 cent below limit
        ctx = _make_context(budget_usd=0.01, budget_spent_usd=0.0099)
        # A large text will cost more than $0.0001 remaining
        long_text = " ".join(["word"] * 1000)
        result = guard.evaluate(long_text, "input", ctx)
        assert result.verdict == GuardVerdict.BLOCK
