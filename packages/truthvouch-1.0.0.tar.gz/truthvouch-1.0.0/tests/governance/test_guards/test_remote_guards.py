"""Tests for TruthGuard and PiiRemoteGuard (remote guards)."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from truthvouch.governance.config import ClientConfig
from truthvouch.exceptions import GuardError
from truthvouch.governance.guards.pii_remote import PiiRemoteGuard
from truthvouch.governance.guards.truth import TruthGuard
from truthvouch.governance.models import GuardContext, GuardVerdict


def _make_context(
    direction: str = "output",
    truth_scan_enabled: bool = True,
    pii_remote_enabled: bool = True,
) -> GuardContext:
    config = ClientConfig(
        truth_scan_enabled=truth_scan_enabled,
        pii_remote_enabled=pii_remote_enabled,
        degraded=False,
    )
    return GuardContext(direction=direction, model="gpt-4o", config=config)


# ---------------------------------------------------------------------------
# TruthGuard
# ---------------------------------------------------------------------------

class TestTruthGuardProperties:
    def test_name(self) -> None:
        guard = TruthGuard(MagicMock())
        assert guard.name == "truth"

    def test_is_not_local(self) -> None:
        guard = TruthGuard(MagicMock())
        assert guard.is_local is False


class TestTruthGuardSkipConditions:
    def test_input_direction_skipped(self) -> None:
        http = MagicMock()
        guard = TruthGuard(http)
        ctx = _make_context(direction="input")
        result = guard.evaluate("Some text", "input", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert "input direction" in result.details.get("skipped", "")
        http.post.assert_not_called()

    def test_truth_scan_disabled_skipped(self) -> None:
        http = MagicMock()
        guard = TruthGuard(http)
        ctx = _make_context(direction="output", truth_scan_enabled=False)
        result = guard.evaluate("Some text", "output", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert "truth_scan_enabled" in result.details.get("skipped", "")
        http.post.assert_not_called()


class TestTruthGuardVerdicts:
    def test_high_trust_score_passes(self) -> None:
        http = MagicMock()
        http.post.return_value = {"trustScore": 0.95}
        guard = TruthGuard(http)
        ctx = _make_context()
        result = guard.evaluate("The sky is blue.", "output", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert result.details["trust_score"] == 0.95

    def test_medium_trust_score_flags(self) -> None:
        http = MagicMock()
        http.post.return_value = {"trustScore": 0.65}
        guard = TruthGuard(http)
        ctx = _make_context()
        result = guard.evaluate("Some claims.", "output", ctx)
        assert result.verdict == GuardVerdict.FLAG
        assert "0.65" in result.message

    def test_low_trust_score_blocks(self) -> None:
        http = MagicMock()
        http.post.return_value = {"trustScore": 0.30}
        guard = TruthGuard(http)
        ctx = _make_context()
        result = guard.evaluate("Possibly hallucinated content.", "output", ctx)
        assert result.verdict == GuardVerdict.BLOCK
        assert "0.30" in result.message

    def test_camel_case_trust_score_key(self) -> None:
        http = MagicMock()
        http.post.return_value = {"trustScore": 0.85}
        guard = TruthGuard(http)
        ctx = _make_context()
        result = guard.evaluate("Text.", "output", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_snake_case_trust_score_key(self) -> None:
        http = MagicMock()
        http.post.return_value = {"trust_score": 0.85}
        guard = TruthGuard(http)
        ctx = _make_context()
        result = guard.evaluate("Text.", "output", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_api_failure_fails_open_as_flag(self) -> None:
        http = MagicMock()
        http.post.side_effect = Exception("API unreachable")
        guard = TruthGuard(http)
        ctx = _make_context()
        result = guard.evaluate("Text.", "output", ctx)
        assert result.verdict == GuardVerdict.FLAG
        assert result.details.get("failed_open") is True

    def test_boundary_trust_score_08_is_pass(self) -> None:
        http = MagicMock()
        http.post.return_value = {"trustScore": 0.80}
        guard = TruthGuard(http)
        ctx = _make_context()
        result = guard.evaluate("Text.", "output", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_boundary_trust_score_05_is_flag(self) -> None:
        http = MagicMock()
        http.post.return_value = {"trustScore": 0.50}
        guard = TruthGuard(http)
        ctx = _make_context()
        result = guard.evaluate("Text.", "output", ctx)
        assert result.verdict == GuardVerdict.FLAG


# ---------------------------------------------------------------------------
# PiiRemoteGuard
# ---------------------------------------------------------------------------

class TestPiiRemoteGuardProperties:
    def test_name(self) -> None:
        guard = PiiRemoteGuard(MagicMock())
        assert guard.name == "pii_remote"

    def test_is_not_local(self) -> None:
        guard = PiiRemoteGuard(MagicMock())
        assert guard.is_local is False


class TestPiiRemoteGuardSkipConditions:
    def test_skipped_when_disabled(self) -> None:
        http = MagicMock()
        guard = PiiRemoteGuard(http)
        ctx = _make_context(pii_remote_enabled=False)
        result = guard.evaluate("text", "input", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert "pii_remote_enabled" in result.details.get("skipped", "")
        http.post.assert_not_called()


class TestPiiRemoteGuardVerdicts:
    def test_no_pii_found_passes(self) -> None:
        http = MagicMock()
        http.post.return_value = {"entities": [], "totalPiiCount": 0}
        guard = PiiRemoteGuard(http)
        ctx = _make_context()
        result = guard.evaluate("Clean text.", "input", ctx)
        assert result.verdict == GuardVerdict.PASS

    def test_pii_found_flags(self) -> None:
        http = MagicMock()
        http.post.return_value = {
            "entities": [
                {"entityType": "EMAIL", "text": "test@example.com", "start": 0, "end": 16}
            ],
            "totalPiiCount": 1,
        }
        guard = PiiRemoteGuard(http)
        ctx = _make_context()
        result = guard.evaluate("test@example.com is here.", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG
        assert result.details["total_count"] == 1

    def test_api_failure_fails_open(self) -> None:
        http = MagicMock()
        http.post.side_effect = Exception("connection refused")
        guard = PiiRemoteGuard(http)
        ctx = _make_context()
        result = guard.evaluate("some text", "input", ctx)
        assert result.verdict == GuardVerdict.PASS
        assert result.details.get("failed_open") is True

    def test_entity_type_counts_in_details(self) -> None:
        http = MagicMock()
        http.post.return_value = {
            "entities": [
                {"entityType": "EMAIL"},
                {"entityType": "SSN"},
                {"entityType": "EMAIL"},
            ],
            "totalPiiCount": 3,
        }
        guard = PiiRemoteGuard(http)
        ctx = _make_context()
        result = guard.evaluate("text", "input", ctx)
        assert result.verdict == GuardVerdict.FLAG
        assert result.details["entity_counts"]["EMAIL"] == 2
        assert result.details["entity_counts"]["SSN"] == 1
