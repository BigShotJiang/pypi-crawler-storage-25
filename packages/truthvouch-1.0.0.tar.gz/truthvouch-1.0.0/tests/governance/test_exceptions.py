"""Tests for SDK exception classes."""

from __future__ import annotations

import pytest

from truthvouch.exceptions import (
    AuthenticationError,
    BootstrapError,
    GovernanceBlockError,
    GuardError,
    TelemetryError,
    TierUpgradeRequired,
    TruthVouchError,
)


class TestExceptionHierarchy:
    def test_authentication_error_is_truthvouch_error(self) -> None:
        exc = AuthenticationError("bad key")
        assert isinstance(exc, TruthVouchError)

    def test_tier_upgrade_required_is_truthvouch_error(self) -> None:
        exc = TierUpgradeRequired("need upgrade", "free", "pro", "https://upgrade.example.com")
        assert isinstance(exc, TruthVouchError)

    def test_bootstrap_error_is_truthvouch_error(self) -> None:
        exc = BootstrapError("failed")
        assert isinstance(exc, TruthVouchError)

    def test_guard_error_is_truthvouch_error(self) -> None:
        exc = GuardError("guard failed", guard_name="pii_regex")
        assert isinstance(exc, TruthVouchError)

    def test_telemetry_error_is_truthvouch_error(self) -> None:
        exc = TelemetryError("push failed")
        assert isinstance(exc, TruthVouchError)

    def test_governance_block_error_is_truthvouch_error(self) -> None:
        exc = GovernanceBlockError("blocked", block_reasons=["a"], guard_results=[])
        assert isinstance(exc, TruthVouchError)


class TestTierUpgradeRequired:
    def test_attributes_set(self) -> None:
        exc = TierUpgradeRequired(
            "Need pro",
            current_tier="free",
            required_tier="pro",
            upgrade_url="https://upgrade.example.com",
        )
        assert exc.current_tier == "free"
        assert exc.required_tier == "pro"
        assert exc.upgrade_url == "https://upgrade.example.com"
        assert str(exc) == "Need pro"

    def test_defaults_empty_strings(self) -> None:
        exc = TierUpgradeRequired("message")
        assert exc.current_tier == ""
        assert exc.required_tier == ""
        assert exc.upgrade_url == ""


class TestGuardError:
    def test_guard_name_attribute(self) -> None:
        exc = GuardError("something failed", guard_name="injection")
        assert exc.guard_name == "injection"

    def test_default_guard_name_empty(self) -> None:
        exc = GuardError("failed")
        assert exc.guard_name == ""


class TestGovernanceBlockError:
    def test_block_reasons_set(self) -> None:
        exc = GovernanceBlockError("blocked", block_reasons=["reason1", "reason2"])
        assert exc.block_reasons == ["reason1", "reason2"]

    def test_guard_results_set(self) -> None:
        exc = GovernanceBlockError("blocked", guard_results=[{"guard": "test"}])
        assert exc.guard_results == [{"guard": "test"}]

    def test_defaults_empty_lists(self) -> None:
        exc = GovernanceBlockError("blocked")
        assert exc.block_reasons == []
        assert exc.guard_results == []
