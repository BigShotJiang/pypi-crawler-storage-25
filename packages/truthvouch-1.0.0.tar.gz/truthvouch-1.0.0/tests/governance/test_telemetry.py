"""Tests for AuditBuffer."""

from __future__ import annotations

import threading
import time
from unittest.mock import MagicMock, call

import pytest

from truthvouch.governance.models import Event
from truthvouch.telemetry.audit import AuditBuffer, _MAX_QUEUE_SIZE


def _make_event(event_type: str = "llm_call") -> Event:
    return Event(
        event_type=event_type,
        direction="input",
        guard_verdict="pass",
        model="gpt-4o",
    )


class TestAuditBufferFlush:
    def test_flush_posts_events(self) -> None:
        http = MagicMock()
        http.post.return_value = {}

        buf = AuditBuffer(http_client=http, flush_interval_s=100.0)
        event = _make_event()
        buf.push(event)
        buf.shutdown()

        assert http.post.called
        call_args = http.post.call_args
        # path is always the first positional arg
        assert call_args[0][0] == "/api/v1/sdk/telemetry"
        # body is now {"events": [...]} — a dict wrapping the list
        body = call_args[1].get("body") or (call_args[0][1] if len(call_args[0]) > 1 else {})
        assert isinstance(body, dict)
        assert "events" in body
        posted_events = body["events"]
        assert isinstance(posted_events, list)
        assert len(posted_events) >= 1
        # to_dict() now emits camelCase "eventType"
        assert posted_events[0]["eventType"] == "llm_call"

    def test_no_events_no_post(self) -> None:
        http = MagicMock()
        buf = AuditBuffer(http_client=http, flush_interval_s=100.0)
        buf.shutdown()
        http.post.assert_not_called()

    def test_multiple_events_batched(self) -> None:
        http = MagicMock()
        http.post.return_value = {}

        buf = AuditBuffer(http_client=http, flush_interval_s=100.0)
        for i in range(5):
            buf.push(_make_event(f"llm_call"))
        buf.shutdown()

        all_events: list[dict] = []
        for c in http.post.call_args_list:
            # body is now {"events": [...]}
            body = c[1].get("body") or (c[0][1] if len(c[0]) > 1 else {})
            all_events.extend(body.get("events", []))
        assert len(all_events) == 5


class TestAuditBufferOverflow:
    def test_overflow_drops_oldest(self) -> None:
        """When queue is full, push should not raise and should discard oldest."""
        http = MagicMock()
        http.post.return_value = {}

        # Create buffer with very short interval to prevent auto-flush interference
        buf = AuditBuffer(http_client=http, flush_interval_s=1000.0)

        # Directly stuff the queue to capacity
        for i in range(_MAX_QUEUE_SIZE):
            buf._queue.put_nowait(_make_event())

        # This push should trigger overflow handling
        buf.push(_make_event("overflow"))
        buf.shutdown()
        # No exception raised

    def test_queue_size_property(self) -> None:
        http = MagicMock()
        buf = AuditBuffer(http_client=http, flush_interval_s=1000.0)
        for _ in range(3):
            buf.push(_make_event())
        assert buf.queue_size == 3
        buf.shutdown()


class TestAuditBufferRetry:
    def test_retry_on_first_failure(self) -> None:
        http = MagicMock()
        # First call fails, second succeeds
        http.post.side_effect = [Exception("network error"), {}]

        buf = AuditBuffer(http_client=http, flush_interval_s=100.0)
        buf.push(_make_event())
        # Short sleep to let retry complete before shutdown
        time.sleep(0.01)
        buf.shutdown()

        # Should have retried: called twice
        assert http.post.call_count >= 1

    def test_drop_after_two_failures(self) -> None:
        http = MagicMock()
        http.post.side_effect = Exception("always fails")

        buf = AuditBuffer(http_client=http, flush_interval_s=100.0)
        buf.push(_make_event())
        buf.shutdown()
        # Should not raise; batch just dropped after retries


class TestAuditBufferShutdown:
    def test_shutdown_flushes_remaining(self) -> None:
        http = MagicMock()
        http.post.return_value = {}

        buf = AuditBuffer(http_client=http, flush_interval_s=1000.0)
        buf.push(_make_event())
        buf.shutdown(timeout_s=5.0)

        assert http.post.called

    def test_event_to_dict_serialization(self) -> None:
        event = _make_event()
        d = event.to_dict()
        # Verify camelCase DTO field names matching .NET SdkTelemetryEventDto
        assert d["eventType"] == "llm_call"
        assert d["guardVerdict"] == "pass"
        assert "timestamp" not in d
        assert isinstance(d["guardsTriggered"], list)
        assert "sdkVersion" in d
        assert "model" in d

    def test_event_verdict_alias(self) -> None:
        """Back-compat: event.verdict should return guard_verdict."""
        event = _make_event()
        assert event.verdict == event.guard_verdict
