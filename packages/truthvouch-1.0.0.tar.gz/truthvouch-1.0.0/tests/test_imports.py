"""Verify all public import paths work correctly after SDK consolidation."""


def test_top_level_imports():
    """Core imports from truthvouch package."""
    from truthvouch import TruthVouch, GovernanceReport, TruthVouchError, __version__
    assert __version__ == "1.0.0"
    assert TruthVouch is not None
    assert GovernanceReport is not None
    assert TruthVouchError is not None


def test_governance_imports():
    """Governance guard subsystem imports."""
    from truthvouch.governance import GovernanceClient, AsyncGovernanceClient
    from truthvouch.governance import EvaluationResult, GuardResult, GuardVerdict
    assert GovernanceClient is not None
    assert AsyncGovernanceClient is not None


def test_exception_imports():
    """All 11 exception classes importable from truthvouch.exceptions."""
    from truthvouch.exceptions import (
        TruthVouchError,
        AuthenticationError,
        BootstrapError,
        GatewayUnreachableError,
        GovernanceBlockError,
        GuardError,
        InvalidRequestError,
        PolicyBlockedError,
        QuotaExceededError,
        TelemetryError,
        TierUpgradeRequired,
        UpstreamProviderError,
    )
    # Verify all are distinct classes
    classes = {
        TruthVouchError, AuthenticationError, BootstrapError,
        GatewayUnreachableError, GovernanceBlockError, GuardError,
        InvalidRequestError, PolicyBlockedError, QuotaExceededError,
        TelemetryError, TierUpgradeRequired, UpstreamProviderError,
    }
    assert len(classes) == 12  # 1 base + 11 subclasses


def test_models_import():
    """GovernanceReport accessible from truthvouch.models."""
    from truthvouch.models import GovernanceReport
    assert GovernanceReport is not None


def test_telemetry_imports():
    """Telemetry audit buffer imports."""
    from truthvouch.telemetry.audit import AuditBuffer, AsyncAuditBuffer
    assert AuditBuffer is not None
    assert AsyncAuditBuffer is not None


def test_provider_imports():
    """Provider facades importable."""
    from truthvouch.providers.openai import OpenAIProvider
    from truthvouch.providers.anthropic import AnthropicProvider
    from truthvouch.providers.google import GoogleAIProvider
    assert OpenAIProvider is not None
    assert AnthropicProvider is not None
    assert GoogleAIProvider is not None


def test_no_circular_imports():
    """Import both top-level and governance in same session."""
    from truthvouch import TruthVouch
    from truthvouch.governance import GovernanceClient
    assert TruthVouch is not GovernanceClient
