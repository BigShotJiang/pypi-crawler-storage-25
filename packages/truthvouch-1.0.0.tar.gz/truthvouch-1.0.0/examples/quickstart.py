"""
TruthVouch SDK — Quickstart Example.

Demonstrates the minimal setup for governed LLM calls.
Run after installing: pip install truthvouch
"""

import asyncio
import os

from truthvouch import TruthVouch


async def main() -> None:
    gateway_url = os.environ["TV_GATEWAY_URL"]
    api_key = os.environ["TV_API_KEY"]

    async with TruthVouch(gateway_url=gateway_url, api_key=api_key) as client:
        response = await client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "What is quantum computing?"}],
        )

        print("Response:", response.content)
        print("Governance verdict:", response.governance.verdict)
        print("PII detected:", response.governance.pii_detected)
        print("Injection detected:", response.governance.injection_detected)
        print("Overhead:", response.governance.overhead_ms, "ms")
        print("Request ID:", response.governance.request_id)


if __name__ == "__main__":
    asyncio.run(main())
