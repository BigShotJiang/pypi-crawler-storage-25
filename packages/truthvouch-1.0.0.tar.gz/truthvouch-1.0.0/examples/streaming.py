"""
TruthVouch SDK — Streaming Example.

Demonstrates async streaming with governance metadata on the final chunk.
"""

import asyncio
import os

from truthvouch import TruthVouch


async def main() -> None:
    async with TruthVouch(
        gateway_url=os.environ["TV_GATEWAY_URL"],
        api_key=os.environ["TV_API_KEY"],
    ) as client:
        print("Streaming response:", end=" ", flush=True)

        governance_report = None

        async for chunk in await client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Explain AI governance in 3 sentences."}],
            stream=True,
        ):
            if chunk.content:
                print(chunk.content, end="", flush=True)

            if chunk.done and chunk.governance_report:
                governance_report = chunk.governance_report

        print("\n\n--- Governance Report (from final chunk) ---")
        if governance_report:
            print("Verdict:", governance_report.verdict)
            print("PII detected:", governance_report.pii_detected)
            print("Overhead:", governance_report.overhead_ms, "ms")
            print("Request ID:", governance_report.request_id)
        else:
            print("No governance report received.")


if __name__ == "__main__":
    asyncio.run(main())
