"""
TruthVouch SDK — OpenAI Drop-in Replacement Example.

Shows how to swap openai.OpenAI for TruthVouch with minimal code changes.

Before (direct OpenAI):
    from openai import AsyncOpenAI
    client = AsyncOpenAI()
    response = await client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "What is quantum computing?"}]
    )
    print(response.choices[0].message.content)

After (governed via TruthVouch):
    from truthvouch import TruthVouch
    client = TruthVouch(gateway_url="...", api_key="tv_...")
    response = await client.openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "What is quantum computing?"}]
    )
    print(response.choices[0].message.content)
    print(response.governance.verdict)  # Bonus: governance metadata
"""

import asyncio
import os

from truthvouch import TruthVouch


async def main() -> None:
    client = TruthVouch(
        gateway_url=os.environ["TV_GATEWAY_URL"],
        api_key=os.environ["TV_API_KEY"],
        fail_mode="open",   # bypass gateway if unavailable
    )

    async with client:
        # The openai.chat.completions.create() API surface
        response = await client.openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful AI assistant."},
                {"role": "user", "content": "Explain the water cycle in 2 sentences."},
            ],
            temperature=0.7,
            max_tokens=200,
        )

        # Same attributes as the real OpenAI SDK
        print("Content:", response.choices[0].message.content)
        print("Finish reason:", response.choices[0].finish_reason)
        print("Tokens used:", response.usage.total_tokens)

        # Extra governance metadata (not available in the real OpenAI SDK)
        print("\n--- Governance Report ---")
        print("Verdict:", response.governance.verdict)
        print("PII detected:", response.governance.pii_detected)
        print("Injection detected:", response.governance.injection_detected)
        if response.governance.truth_scan:
            print("Truth confidence:", response.governance.truth_scan["confidence"])
        print("Policy violations:", response.governance.policy_violations)
        print("Overhead:", response.governance.overhead_ms, "ms")


if __name__ == "__main__":
    asyncio.run(main())
