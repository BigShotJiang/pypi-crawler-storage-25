"""
TruthVouch SDK — Batch Scan Example.

Demonstrates submitting a document corpus for offline governance analysis
and polling for results.
"""

import asyncio
import os

from truthvouch import TruthVouch


async def main() -> None:
    async with TruthVouch(
        gateway_url=os.environ["TV_GATEWAY_URL"],
        api_key=os.environ["TV_API_KEY"],
    ) as client:
        # Submit a batch job
        job = await client.batch.submit(
            source_url="s3://my-company-bucket/llm-outputs/2026-03.jsonl",
            format="jsonl",
            scan_mode="deep",
            callback_url="https://my-app.com/webhooks/scan-complete",
        )
        print(f"Job submitted: {job.id}")
        print(f"Status: {job.status}")
        print(f"ETA: {job.estimated_completion}")

        # Poll for status
        print("\nPolling for completion...")
        max_polls = 20
        for i in range(max_polls):
            status = await client.batch.get_status(job.id)
            print(
                f"  Poll {i+1}: {status.status} — "
                f"{status.scanned}/{status.total} ({status.progress_percent}%)"
            )

            if status.is_terminal:
                break

            await asyncio.sleep(5)  # Poll every 5 seconds

        # Process results
        print(f"\nFinal status: {status.status}")
        if status.status == "completed":
            print(f"Total documents scanned: {status.total}")
            blocked = [r for r in status.results if r.get("verdict") == "blocked"]
            flagged = [r for r in status.results if r.get("verdict") == "flagged"]
            print(f"  Blocked: {len(blocked)}")
            print(f"  Flagged: {len(flagged)}")
            print(f"  Allowed: {status.total - len(blocked) - len(flagged)}")
        elif status.status == "failed":
            print(f"Error: {status.error_message}")


if __name__ == "__main__":
    asyncio.run(main())
