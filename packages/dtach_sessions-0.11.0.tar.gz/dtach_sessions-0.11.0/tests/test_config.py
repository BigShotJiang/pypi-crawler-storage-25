"""Tests for the config system (config helpers + build_* functions)."""

import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

from dsm.cli import (
    CONFIG_FILE,
    _resolve_config,
    build_docker_run_cmd,
    build_env_vars,
    build_port_mappings,
    build_volume_mounts,
    cmd_container,
    container_has_mount,
    create_git_worktree,
    create_worktree_in_container,
    discover_repos,
    ensure_container,
    expand_env_vars,
    get_container_state,
    get_default_branch,
    get_default_config,
    get_named_config,
    list_worktrees,
    load_config,
    slugify,
)


# ── get_default_config ─────────────────────────────────────────────────────


def test_default_config_structure():
    cfg = get_default_config()
    assert cfg["version"] == "1.0"
    assert cfg["default_config"] == "none"
    assert "none" in cfg["configs"]


# ── load_config ────────────────────────────────────────────────────────────


def test_load_config_missing_file(tmp_path, monkeypatch):
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", tmp_path / "nonexistent.json")
    cfg = load_config()
    assert cfg == get_default_config()


def test_load_config_valid_file(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "dev",
        "configs": {"dev": {"image": "myimage:latest"}},
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    cfg = load_config()
    assert cfg["default_config"] == "dev"
    assert cfg["configs"]["dev"]["image"] == "myimage:latest"


def test_load_config_invalid_json(tmp_path, monkeypatch, capsys):
    config_file = tmp_path / "config.json"
    config_file.write_text("{ not valid json")
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    cfg = load_config()
    assert cfg == get_default_config()
    assert "Warning" in capsys.readouterr().err


# ── get_named_config ──────────────────────────────────────────────────────


def test_get_named_config_explicit(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "none",
        "configs": {
            "none": {},
            "dev": {"image": "dev:latest"},
        },
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    result = get_named_config("dev")
    assert result["image"] == "dev:latest"


def test_get_named_config_uses_default(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "dev",
        "configs": {
            "dev": {"image": "dev:latest"},
        },
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    result = get_named_config(None)
    assert result["image"] == "dev:latest"


def test_get_named_config_missing_exits(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "none",
        "configs": {"none": {}},
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    with pytest.raises(SystemExit):
        get_named_config("nonexistent")


# ── _resolve_config (extends / inheritance) ───────────────────────────────


def test_resolve_config_no_extends():
    configs = {"base": {"image": "img:latest", "env": {"A": "1"}}}
    result = _resolve_config(configs, "base")
    assert result == {"image": "img:latest", "env": {"A": "1"}}


def test_resolve_config_simple_extends():
    configs = {
        "default": {"image": "img:latest", "env": {"A": "1", "B": "2"}, "repos_dir": "~/repos"},
        "child": {"extends": "default", "image": "custom:latest"},
    }
    result = _resolve_config(configs, "child")
    assert result["image"] == "custom:latest"
    assert result["env"] == {"A": "1", "B": "2"}
    assert result["repos_dir"] == "~/repos"


def test_resolve_config_nested_dict_merge():
    configs = {
        "default": {"ssh": {"enabled": True, "port": 2222}, "env": {"A": "1", "B": "2"}},
        "child": {"extends": "default", "env": {"B": "override", "C": "3"}},
    }
    result = _resolve_config(configs, "child")
    assert result["ssh"] == {"enabled": True, "port": 2222}
    assert result["env"] == {"A": "1", "B": "override", "C": "3"}


def test_resolve_config_list_replaces():
    configs = {
        "default": {"volumes": ["/a:/b", "/c:/d"]},
        "child": {"extends": "default", "volumes": ["/x:/y"]},
    }
    result = _resolve_config(configs, "child")
    assert result["volumes"] == ["/x:/y"]


def test_resolve_config_chained_extends():
    configs = {
        "base": {"image": "base:latest", "env": {"A": "1"}},
        "mid": {"extends": "base", "env": {"B": "2"}},
        "leaf": {"extends": "mid", "image": "leaf:latest"},
    }
    result = _resolve_config(configs, "leaf")
    assert result["image"] == "leaf:latest"
    assert result["env"] == {"A": "1", "B": "2"}


def test_resolve_config_circular_exits():
    configs = {
        "a": {"extends": "b"},
        "b": {"extends": "a"},
    }
    with pytest.raises(SystemExit):
        _resolve_config(configs, "a")


def test_resolve_config_missing_base_exits():
    configs = {
        "child": {"extends": "nonexistent"},
    }
    with pytest.raises(SystemExit):
        _resolve_config(configs, "child")


def test_get_named_config_with_extends(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "none",
        "configs": {
            "none": {},
            "default": {"image": "img:latest", "env": {"TOKEN": "x"}},
            "ion": {"extends": "default", "image": "rust:latest"},
        },
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    result = get_named_config("ion")
    assert result["image"] == "rust:latest"
    assert result["env"] == {"TOKEN": "x"}
    assert "extends" not in result


# ── expand_env_vars ───────────────────────────────────────────────────────


def test_expand_env_vars_simple(monkeypatch):
    monkeypatch.setenv("MY_TOKEN", "secret123")
    result = expand_env_vars({"TOKEN": "${MY_TOKEN}"})
    assert result["TOKEN"] == "secret123"


def test_expand_env_vars_multiple_in_one_value(monkeypatch):
    monkeypatch.setenv("HOST", "localhost")
    monkeypatch.setenv("PORT", "5432")
    result = expand_env_vars({"DB_URL": "postgres://${HOST}:${PORT}/db"})
    assert result["DB_URL"] == "postgres://localhost:5432/db"


def test_expand_env_vars_no_expansion():
    result = expand_env_vars({"STATIC": "plain_value"})
    assert result["STATIC"] == "plain_value"


def test_expand_env_vars_missing_var_exits(monkeypatch):
    monkeypatch.delenv("DEFINITELY_NOT_SET", raising=False)
    with pytest.raises(SystemExit):
        expand_env_vars({"KEY": "${DEFINITELY_NOT_SET}"})


def test_expand_env_vars_non_string_value(monkeypatch):
    monkeypatch.setenv("X", "yes")
    result = expand_env_vars({"NUM": 42, "REF": "${X}"})
    assert result["NUM"] == "42"
    assert result["REF"] == "yes"


# ── discover_repos ────────────────────────────────────────────────────────


def test_discover_repos_finds_git_dirs(tmp_path):
    # Create fake repos
    (tmp_path / "repo-a" / ".git").mkdir(parents=True)
    (tmp_path / "repo-b" / ".git").mkdir(parents=True)
    (tmp_path / "not-a-repo").mkdir()

    repos = discover_repos(str(tmp_path))
    repo_names = {r["name"] for r in repos}
    assert repo_names == {"repo-a", "repo-b"}
    # Check dict structure
    for r in repos:
        assert r["repo_type"] == "standard"
        assert "default_branch" in r
        assert r["path"] == str(tmp_path / r["name"])


def test_discover_repos_finds_bare_repos(tmp_path):
    (tmp_path / "bare-repo" / ".bare").mkdir(parents=True)

    repos = discover_repos(str(tmp_path))
    repo_names = {r["name"] for r in repos}
    assert "bare-repo" in repo_names
    bare = [r for r in repos if r["name"] == "bare-repo"][0]
    assert bare["repo_type"] == "bare-worktree"


def test_discover_repos_excludes_paths(tmp_path):
    (tmp_path / "repo-a" / ".git").mkdir(parents=True)
    (tmp_path / "repo-b" / ".git").mkdir(parents=True)

    exclude = [str(tmp_path / "repo-a")]
    repos = discover_repos(str(tmp_path), exclude)
    repo_names = {r["name"] for r in repos}
    assert repo_names == {"repo-b"}


def test_discover_repos_nonexistent_dir(capsys):
    repos = discover_repos("/tmp/definitely_not_a_real_dir_12345")
    assert repos == []
    assert "Warning" in capsys.readouterr().err


def test_discover_repos_scan_depth(tmp_path):
    # depth 1: repos at top level only
    (tmp_path / "top-repo" / ".git").mkdir(parents=True)
    (tmp_path / "subdir").mkdir()
    (tmp_path / "subdir" / "nested-repo" / ".git").mkdir(parents=True)

    # depth=1 should only find top-level
    repos = discover_repos(str(tmp_path), scan_depth=1)
    assert {r["name"] for r in repos} == {"top-repo"}

    # depth=2 should find both
    repos = discover_repos(str(tmp_path), scan_depth=2)
    assert {r["name"] for r in repos} == {"nested-repo", "top-repo"}


def test_discover_repos_sorted_by_name(tmp_path):
    for name in ("zeta", "alpha", "middle"):
        (tmp_path / name / ".git").mkdir(parents=True)

    repos = discover_repos(str(tmp_path))
    names = [r["name"] for r in repos]
    assert names == ["alpha", "middle", "zeta"]


# ── build_volume_mounts ──────────────────────────────────────────────────


def test_build_volume_mounts_ssh_dir(tmp_path, monkeypatch):
    ssh_dir = tmp_path / ".ssh"
    ssh_dir.mkdir()
    (ssh_dir / "id_ed25519").write_text("key")
    monkeypatch.setattr("dsm.cli.Path.home", lambda: tmp_path)

    config = {
        "ssh": {
            "enabled": True,
        }
    }
    volumes = build_volume_mounts(config, tmp_path, None, [], "ro")
    assert any("/home/ubuntu/.ssh:ro" in v for v in volumes)


def test_build_volume_mounts_repos_dir(tmp_path):
    repos_dir = tmp_path / "repos"
    (repos_dir / "proj-a" / ".git").mkdir(parents=True)
    (repos_dir / "proj-b" / ".git").mkdir(parents=True)

    config = {"repos_dir": str(repos_dir)}
    volumes = build_volume_mounts(config, tmp_path, None, [], "ro")
    mount_targets = {v.split(":")[-2] for v in volumes}
    assert "/mnt/proj-a" in mount_targets
    assert "/mnt/proj-b" in mount_targets


def test_build_volume_mounts_access_mode(tmp_path):
    repos_dir = tmp_path / "repos"
    (repos_dir / "proj" / ".git").mkdir(parents=True)

    config = {"repos_dir": str(repos_dir)}
    volumes = build_volume_mounts(config, tmp_path, None, [], "rw")
    assert all(v.endswith(":rw") for v in volumes)


def test_build_volume_mounts_extra_mounts(tmp_path):
    extra = tmp_path / "extra-dir"
    extra.mkdir()

    config = {}
    volumes = build_volume_mounts(config, tmp_path, None, [str(extra)], "ro")
    assert len(volumes) == 1
    assert "/mnt/extra-dir:ro" in volumes[0]


def test_build_volume_mounts_explicit_repos(tmp_path):
    repo = tmp_path / "my-lib"
    (repo / ".git").mkdir(parents=True)

    config = {"repos": [str(repo)]}
    volumes = build_volume_mounts(config, tmp_path, None, [], "ro")
    assert any("/mnt/my-lib:ro" in v for v in volumes)


def test_build_volume_mounts_missing_repo_warns(tmp_path, capsys):
    config = {"repos": ["/tmp/no_such_repo_xyz"]}
    volumes = build_volume_mounts(config, tmp_path, None, [], "ro")
    assert volumes == []
    assert "Warning" in capsys.readouterr().err


# ── build_port_mappings ──────────────────────────────────────────────────


def test_build_port_mappings_ssh_enabled():
    config = {"ssh": {"enabled": True, "port": 3333}}
    ports = build_port_mappings(config)
    assert ports == ["3333:22"]


def test_build_port_mappings_ssh_default_port():
    config = {"ssh": {"enabled": True}}
    ports = build_port_mappings(config)
    assert ports == ["2222:22"]


def test_build_port_mappings_ssh_disabled():
    config = {"ssh": {"enabled": False}}
    assert build_port_mappings(config) == []


def test_build_port_mappings_no_ssh_key():
    assert build_port_mappings({}) == []


# ── build_env_vars ───────────────────────────────────────────────────────


def test_build_env_vars_from_config(monkeypatch):
    monkeypatch.setenv("GH_TOKEN", "ghp_abc")
    config = {"env": {"GITHUB_TOKEN": "${GH_TOKEN}", "DEBUG": "1"}}
    result = build_env_vars(config, [])
    assert "-e" in result
    assert "GITHUB_TOKEN=ghp_abc" in result
    assert "DEBUG=1" in result


def test_build_env_vars_extra_cli():
    config = {}
    result = build_env_vars(config, ["FOO=bar", "BAZ=qux"])
    assert result == ["-e", "FOO=bar", "-e", "BAZ=qux"]


def test_build_env_vars_invalid_extra_warns(capsys):
    config = {}
    result = build_env_vars(config, ["BADFORMAT"])
    assert result == []
    assert "Warning" in capsys.readouterr().err


def test_build_env_vars_combined(monkeypatch):
    monkeypatch.setenv("SECRET", "s3cret")
    config = {"env": {"TOKEN": "${SECRET}"}}
    result = build_env_vars(config, ["EXTRA=val"])
    # Config env comes first, then CLI extras
    assert result == ["-e", "TOKEN=s3cret", "-e", "EXTRA=val"]


# ── build_docker_run_cmd ─────────────────────────────────────────────────


def test_build_docker_run_cmd_basic():
    repo = Path("/tmp/myrepo")

    cmd = build_docker_run_cmd(
        container_name="dsm_myrepo",
        mount_path=repo,
        image="myimage:latest",
        ports=["8080:80"],
        volumes=["/host/path:/container/path:ro"],
        env_vars=["-e", "FOO=bar"],
        branch=None,
    )

    assert cmd[:4] == ["docker", "run", "-d", "--name"]
    assert "dsm_myrepo" in cmd
    assert "-v" in cmd
    assert f"{repo}:/workspace:ro" in cmd  # no branch = repo root = read-only
    assert "-p" in cmd
    assert "8080:80" in cmd
    assert "/host/path:/container/path:ro" in cmd
    assert "FOO=bar" in cmd
    assert "ANTHROPIC_API_KEY" not in " ".join(cmd)
    assert cmd[-3:] == ["myimage:latest", "sleep", "infinity"]
    # DSM env vars injected
    cmd_str = " ".join(cmd)
    assert "DSM_CONTAINER=1" in cmd_str
    assert "DSM_CONTAINER_NAME=dsm_myrepo" in cmd_str
    assert "DSM_HOST_IP=" in cmd_str
    assert "DSM_PORT_FORWARDING=auto" in cmd_str


def test_build_docker_run_cmd_git_overlay_when_ro(tmp_path):
    """When workspace is ro and .git exists, a .git overlay mount is added."""
    repo = tmp_path / "myrepo"
    repo.mkdir()
    (repo / ".git").mkdir()  # simulate git repo

    cmd = build_docker_run_cmd(
        container_name="dsm_myrepo",
        mount_path=repo,
        image="img:latest",
        ports=[],
        volumes=[],
        env_vars=[],
        workspace_access="ro",
    )

    assert f"{repo}:/workspace:ro" in cmd
    assert f"{repo / '.git'}:/workspace/.git:rw" in cmd


def test_build_docker_run_cmd_no_git_overlay_when_rw(tmp_path):
    """When workspace is rw, no .git overlay is needed."""
    repo = tmp_path / "myrepo"
    repo.mkdir()
    (repo / ".git").mkdir()

    cmd = build_docker_run_cmd(
        container_name="dsm_myrepo",
        mount_path=repo,
        image="img:latest",
        ports=[],
        volumes=[],
        env_vars=[],
        workspace_access="rw",
    )

    assert f"{repo}:/workspace:rw" in cmd
    # No .git overlay when workspace is already rw
    assert not any("/workspace/.git:rw" in item for item in cmd)


def test_build_docker_run_cmd_no_git_overlay_when_no_git(tmp_path):
    """When workspace is ro but no .git exists, no overlay is added."""
    repo = tmp_path / "myrepo"
    repo.mkdir()
    # No .git directory

    cmd = build_docker_run_cmd(
        container_name="dsm_myrepo",
        mount_path=repo,
        image="img:latest",
        ports=[],
        volumes=[],
        env_vars=[],
        workspace_access="ro",
    )

    assert f"{repo}:/workspace:ro" in cmd
    assert not any("/workspace/.git:rw" in item for item in cmd)


def test_build_docker_run_cmd_with_branch():
    """Legacy path: caller mounts worktree dir directly, must pass rw explicitly."""
    worktree = Path("/tmp/myrepo-worktrees/feat")

    cmd = build_docker_run_cmd(
        container_name="dsm_myrepo_feat",
        mount_path=worktree,
        image="img:latest",
        ports=[],
        volumes=[],
        env_vars=[],
        branch="feat",
        workspace_access="rw",
    )

    assert f"{worktree}:/workspace:rw" in cmd


# ── get_container_state ──────────────────────────────────────────────────


def test_get_container_state_running(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="running\n")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert get_container_state("test_container") == "running"


def test_get_container_state_exited(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="exited\n")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert get_container_state("test_container") == "exited"


def test_get_container_state_not_found(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=1, stdout="")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert get_container_state("test_container") is None


# ── container_has_mount ──────────────────────────────────────────────────


def test_container_has_mount_found(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(
        returncode=0, stdout="/workspace /worktrees ",
    )
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert container_has_mount("test_ctr", "/worktrees") is True


def test_container_has_mount_missing(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="/workspace ")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert container_has_mount("test_ctr", "/worktrees") is False


def test_container_has_mount_inspect_fails(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=1, stdout="")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert container_has_mount("test_ctr", "/worktrees") is False


def test_container_has_mount_no_substring_match(monkeypatch):
    """'/work' should NOT match '/workspace' — split-based, not 'in' string."""
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="/workspace /worktrees ")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert container_has_mount("test_ctr", "/work") is False


# ── _container_layout_valid ──────────────────────────────────────────────


def test_container_layout_valid_all_mounts(monkeypatch):
    """Container with /worktrees and /workspace/.git overlay is valid for ro."""
    from dsm.cli import _container_layout_valid
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="/workspace /workspace/.git /worktrees ")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    repo = Path("/tmp/myrepo")
    monkeypatch.setattr(Path, "exists", lambda self: True)  # .git exists
    assert _container_layout_valid("test_ctr", repo, "ro") is True


def test_container_layout_valid_missing_git_overlay(monkeypatch):
    """Container with /worktrees but no .git overlay is invalid for ro."""
    from dsm.cli import _container_layout_valid
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="/workspace /worktrees ")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    repo = Path("/tmp/myrepo")
    monkeypatch.setattr(Path, "exists", lambda self: True)  # .git exists
    assert _container_layout_valid("test_ctr", repo, "ro") is False


def test_container_layout_valid_rw_no_overlay_needed(monkeypatch):
    """Container with rw workspace doesn't need .git overlay."""
    from dsm.cli import _container_layout_valid
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="/workspace /worktrees ")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    repo = Path("/tmp/myrepo")
    assert _container_layout_valid("test_ctr", repo, "rw") is True


def test_container_layout_valid_missing_worktrees(monkeypatch):
    """Container without /worktrees is always invalid."""
    from dsm.cli import _container_layout_valid
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="/workspace ")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    repo = Path("/tmp/myrepo")
    assert _container_layout_valid("test_ctr", repo, "ro") is False


# ── ensure_container ─────────────────────────────────────────────────────


def _mock_daemon_client(monkeypatch):
    """Set up a mock DsmClient for ensure_container tests."""
    from unittest.mock import MagicMock
    mock_client = MagicMock()
    mock_client.send.return_value = {}
    monkeypatch.setattr("dsm.cli._daemon_client_required", lambda: mock_client)
    return mock_client


def test_ensure_container_already_running(monkeypatch):
    mock_client = _mock_daemon_client(monkeypatch)
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: "running")
    monkeypatch.setattr("dsm.cli.container_has_mount", lambda name, dest: True)
    result = ensure_container("test", Path("/tmp/repo"), "img:latest")
    assert result == "already_running"
    mock_client.send.assert_called_once_with("start_container", container="test")


def test_ensure_container_already_running_missing_worktrees(monkeypatch, tmp_path):
    """Running container without /worktrees mount gets recreated."""
    mock_client = _mock_daemon_client(monkeypatch)
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: "running")
    monkeypatch.setattr("dsm.cli.container_has_mount", lambda name, dest: False)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: type("R", (), {"returncode": 0, "stdout": ""})())
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    result = ensure_container("test", repo_path, "img:latest")
    assert result == "created"
    # First call: remove_container (old layout), second: create_container (new layout)
    assert mock_client.send.call_count == 2
    assert mock_client.send.call_args_list[0][0][0] == "remove_container"
    assert mock_client.send.call_args_list[1][0][0] == "create_container"
    # Verify worktrees directory was created on recreate
    worktrees_dir = tmp_path / "repo-worktrees"
    assert worktrees_dir.is_dir()


def test_ensure_container_starts_stopped(monkeypatch):
    mock_client = _mock_daemon_client(monkeypatch)
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: "exited")
    monkeypatch.setattr("dsm.cli.container_has_mount", lambda name, dest: True)
    result = ensure_container("test", Path("/tmp/repo"), "img:latest")
    assert result == "started"
    mock_client.send.assert_called_once_with("start_container", container="test")


def test_ensure_container_start_fails(monkeypatch):
    from unittest.mock import MagicMock
    mock_client = _mock_daemon_client(monkeypatch)
    mock_client.send.side_effect = RuntimeError("Daemon error: cannot start")
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: "exited")
    monkeypatch.setattr("dsm.cli.container_has_mount", lambda name, dest: True)
    with pytest.raises(RuntimeError, match="cannot start"):
        ensure_container("test", Path("/tmp/repo"), "img:latest")


def test_ensure_container_creates_new(monkeypatch, tmp_path):
    mock_client = _mock_daemon_client(monkeypatch)
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: None)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: type("R", (), {"returncode": 0, "stdout": ""})())
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    result = ensure_container("test", repo_path, "img:latest")
    assert result == "created"
    mock_client.send.assert_called_once()
    call_args = mock_client.send.call_args
    assert call_args[0][0] == "create_container"
    # Verify worktrees directory was created
    worktrees_dir = tmp_path / "repo-worktrees"
    assert worktrees_dir.is_dir()
    # Verify /worktrees volume appears in the docker command
    docker_cmd = call_args[1]["docker_cmd"]
    assert f"{worktrees_dir}:/worktrees" in docker_cmd


def test_ensure_container_create_fails(monkeypatch, tmp_path):
    mock_client = _mock_daemon_client(monkeypatch)
    mock_client.send.side_effect = RuntimeError("Daemon error: image not found")
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: None)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: type("R", (), {"returncode": 0, "stdout": ""})())
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    with pytest.raises(RuntimeError, match="image not found"):
        ensure_container("test", repo_path, "img:latest")


# ── create_worktree_in_container ─────────────────────────────────────────


def test_create_worktree_tier1_success(monkeypatch):
    from unittest.mock import MagicMock, call
    calls = []

    def mock_run(cmd, **kw):
        calls.append(cmd)
        return MagicMock(returncode=0, stderr="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    result = create_worktree_in_container("ctr", "feat")
    assert result == "/worktrees/feat"
    # First call is rev-parse HEAD, second is tier 1 strategy
    assert len(calls) == 2
    assert "rev-parse" in calls[0]
    assert "--track" in calls[1]


def test_create_worktree_falls_through_to_tier3(monkeypatch):
    from unittest.mock import MagicMock
    call_count = [0]

    def mock_run(cmd, **kw):
        call_count[0] += 1
        # rev-parse succeeds, tier 1 and 2 fail, tier 3 succeeds
        if call_count[0] == 1:  # rev-parse
            return MagicMock(returncode=0, stderr="")
        if call_count[0] <= 3:  # tier 1, tier 2
            return MagicMock(returncode=1, stderr="fatal: branch exists")
        return MagicMock(returncode=0, stderr="")  # tier 3

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    result = create_worktree_in_container("ctr", "new-branch")
    assert result == "/worktrees/new-branch"
    assert call_count[0] == 4


def test_create_worktree_no_commits(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=1, stderr="fatal: bad revision")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    with pytest.raises(RuntimeError, match="no commits"):
        create_worktree_in_container("ctr", "feat")


def test_create_worktree_all_strategies_fail(monkeypatch):
    from unittest.mock import MagicMock
    call_count = [0]

    def mock_run(cmd, **kw):
        call_count[0] += 1
        if call_count[0] == 1:  # rev-parse succeeds
            return MagicMock(returncode=0, stderr="")
        return MagicMock(returncode=1, stderr="fatal: something broke")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    with pytest.raises(RuntimeError, match="Failed to create worktree"):
        create_worktree_in_container("ctr", "bad-branch")


# ── cmd_container ───────────────────────────────────────────────────────────


def _make_container_args(repo_path, branch=None, **overrides):
    """Build a minimal args namespace for cmd_container."""
    from types import SimpleNamespace
    defaults = dict(
        repo_path=str(repo_path),
        branch=branch,
        config="default",
        access=None,
        image=None,
        mount=[],
        volume=[],
        port=[],
        env=[],
        new=False,
        title=None,
        command=None,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def test_cmd_container_basic_no_branch(monkeypatch, tmp_path):
    """cmd_container creates container and session, then execs."""
    from unittest.mock import MagicMock
    repo_path = tmp_path / "myrepo"
    repo_path.mkdir()
    (repo_path / ".git").mkdir()

    monkeypatch.setattr("dsm.cli.get_named_config", lambda name: {})
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: None)

    mock_ensure = MagicMock(return_value="created")
    monkeypatch.setattr("dsm.cli.ensure_container", mock_ensure)

    exec_calls = []
    monkeypatch.setattr("os.execvp", lambda prog, args: exec_calls.append((prog, args)))
    # Prevent unique_id from colliding with real sessions
    monkeypatch.setattr("dsm.cli.DSM_DIR", tmp_path / "dsm_sessions")
    (tmp_path / "dsm_sessions").mkdir()

    args = _make_container_args(repo_path)
    cmd_container(args)

    mock_ensure.assert_called_once()
    call_kwargs = mock_ensure.call_args
    assert call_kwargs[0][0] == "dsm_myrepo"  # container_name
    assert call_kwargs[0][1] == repo_path      # repo_path
    # Verify exec was called with docker
    assert len(exec_calls) == 1
    assert exec_calls[0][0] == "docker"
    assert "/workspace" in " ".join(exec_calls[0][1])


def test_cmd_container_branch_keeps_ro(monkeypatch, tmp_path):
    """With .git overlay, branch no longer forces rw — workspace stays ro."""
    from unittest.mock import MagicMock
    repo_path = tmp_path / "myrepo"
    repo_path.mkdir()
    (repo_path / ".git").mkdir()

    monkeypatch.setattr("dsm.cli.get_named_config", lambda name: {"default_access": "ro"})
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: None)

    mock_ensure = MagicMock(return_value="created")
    monkeypatch.setattr("dsm.cli.ensure_container", mock_ensure)

    mock_worktree = MagicMock(return_value="/worktrees/feat")
    monkeypatch.setattr("dsm.cli.create_worktree_in_container", mock_worktree)

    monkeypatch.setattr("os.execvp", lambda prog, args: None)
    monkeypatch.setattr("dsm.cli.DSM_DIR", tmp_path / "dsm_sessions")
    (tmp_path / "dsm_sessions").mkdir()

    args = _make_container_args(repo_path, branch="feat")
    cmd_container(args)

    # workspace stays ro — .git overlay in build_docker_run_cmd handles git writes
    assert mock_ensure.call_args[1]["workspace_access"] == "ro"
    mock_worktree.assert_called_once_with("dsm_myrepo", "feat")


# ── slugify ─────────────────────────────────────────────────────────────────


def test_slugify_basic():
    assert slugify("Hello World") == "hello-world"


def test_slugify_max_length():
    assert slugify("a-very-long-branch-name-that-goes-on", max_length=10) == "a-very-lon"


def test_slugify_max_length_strips_trailing_hyphen():
    assert slugify("hello world foo", max_length=11) == "hello-world"


def test_slugify_no_max_length():
    long = "a" * 200
    assert len(slugify(long)) == 200


# ── list_worktrees ──────────────────────────────────────────────────────────


def test_list_worktrees_parses_porcelain(monkeypatch):
    from unittest.mock import MagicMock

    porcelain_output = (
        "worktree /home/user/repo\n"
        "branch refs/heads/main\n"
        "\n"
        "worktree /home/user/repo/feature\n"
        "branch refs/heads/feature\n"
        "\n"
    )
    mock_result = MagicMock(returncode=0, stdout=porcelain_output)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    result = list_worktrees("/home/user/repo")
    assert len(result) == 2
    assert result[0] == {"branch": "main", "path": "/home/user/repo", "is_bare": False}
    assert result[1] == {"branch": "feature", "path": "/home/user/repo/feature", "is_bare": False}


def test_list_worktrees_bare_entry(monkeypatch):
    from unittest.mock import MagicMock

    porcelain_output = (
        "worktree /home/user/repo/.bare\n"
        "bare\n"
        "\n"
        "worktree /home/user/repo/main\n"
        "branch refs/heads/main\n"
        "\n"
    )
    mock_result = MagicMock(returncode=0, stdout=porcelain_output)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    result = list_worktrees("/home/user/repo")
    assert len(result) == 2
    assert result[0]["is_bare"] is True
    assert result[1]["is_bare"] is False


def test_list_worktrees_git_failure(monkeypatch):
    from unittest.mock import MagicMock

    mock_result = MagicMock(returncode=1, stdout="")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    assert list_worktrees("/nonexistent") == []


def test_list_worktrees_no_trailing_newline(monkeypatch):
    from unittest.mock import MagicMock

    porcelain_output = (
        "worktree /home/user/repo\n"
        "branch refs/heads/main"
    )
    mock_result = MagicMock(returncode=0, stdout=porcelain_output)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    result = list_worktrees("/home/user/repo")
    assert len(result) == 1
    assert result[0]["branch"] == "main"


# ── get_default_branch ──────────────────────────────────────────────────────


def test_get_default_branch_from_origin_head(monkeypatch):
    from unittest.mock import MagicMock

    mock_result = MagicMock(returncode=0, stdout="refs/remotes/origin/main\n")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    assert get_default_branch("/some/repo") == "main"


def test_get_default_branch_fallback_to_main(monkeypatch):
    from unittest.mock import MagicMock
    call_count = [0]

    def mock_run(*args, **kw):
        call_count[0] += 1
        if call_count[0] == 1:  # symbolic-ref fails
            return MagicMock(returncode=1, stdout="")
        if call_count[0] == 2:  # rev-parse main succeeds
            return MagicMock(returncode=0, stdout="abc123\n")
        return MagicMock(returncode=1, stdout="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    assert get_default_branch("/some/repo") == "main"


def test_get_default_branch_fallback_to_master(monkeypatch):
    from unittest.mock import MagicMock
    call_count = [0]

    def mock_run(*args, **kw):
        call_count[0] += 1
        if call_count[0] == 1:  # symbolic-ref fails
            return MagicMock(returncode=1, stdout="")
        if call_count[0] == 2:  # rev-parse main fails
            return MagicMock(returncode=1, stdout="")
        if call_count[0] == 3:  # rev-parse master succeeds
            return MagicMock(returncode=0, stdout="abc123\n")
        return MagicMock(returncode=1, stdout="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    assert get_default_branch("/some/repo") == "master"


# ── create_git_worktree ────────────────────────────────────────────────────


def test_create_git_worktree_returns_path_standard(tmp_path, monkeypatch):
    """Standard repo (.git): worktree goes in sibling -worktrees dir."""
    from unittest.mock import MagicMock

    repo = tmp_path / "myrepo"
    (repo / ".git").mkdir(parents=True)

    call_count = [0]
    def mock_run(cmd, **kw):
        call_count[0] += 1
        return MagicMock(returncode=0, stdout="abc123\n", stderr="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    result = create_git_worktree(repo, "feature")

    assert result == tmp_path / "myrepo-worktrees" / "feature"
    assert isinstance(result, Path)


def test_create_git_worktree_returns_path_bare(tmp_path, monkeypatch):
    """Bare-worktree repo (.bare): worktree is sibling inside repo dir."""
    from unittest.mock import MagicMock

    repo = tmp_path / "myrepo"
    (repo / ".bare").mkdir(parents=True)

    def mock_run(cmd, **kw):
        return MagicMock(returncode=0, stdout="abc123\n", stderr="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    result = create_git_worktree(repo, "feature")

    assert result == repo / "feature"


def test_create_git_worktree_no_commits_raises(tmp_path, monkeypatch):
    from unittest.mock import MagicMock

    repo = tmp_path / "myrepo"
    (repo / ".git").mkdir(parents=True)

    mock_result = MagicMock(returncode=1, stdout="", stderr="fatal: bad revision")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    with pytest.raises(RuntimeError, match="no commits"):
        create_git_worktree(repo, "feature")


def test_create_git_worktree_all_tiers_fail_raises(tmp_path, monkeypatch):
    from unittest.mock import MagicMock

    repo = tmp_path / "myrepo"
    (repo / ".git").mkdir(parents=True)

    call_count = [0]
    def mock_run(cmd, **kw):
        call_count[0] += 1
        if call_count[0] == 1:  # rev-parse HEAD
            return MagicMock(returncode=0, stdout="abc123\n", stderr="")
        return MagicMock(returncode=1, stdout="", stderr="fatal: error")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)

    with pytest.raises(RuntimeError, match="Failed to create worktree"):
        create_git_worktree(repo, "feature")
