"""Tests for daemon state validation: missing-status reconciliation, container_gone signal propagation, and CLI single-path behavior."""

from __future__ import annotations

import asyncio
import io
import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from dsm.daemon import DsmDaemon
from dsm.ports import PortChange


# ── Helpers ──────────────────────────────────────────────────────────────────


async def _start_daemon(tmp_path: Path) -> DsmDaemon:
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
    await daemon.start()
    return daemon


async def _send_recv(socket_path: Path, request: dict) -> dict:
    reader, writer = await asyncio.open_unix_connection(str(socket_path))
    writer.write(json.dumps(request).encode() + b"\n")
    await writer.drain()
    line = await asyncio.wait_for(reader.readline(), timeout=5)
    writer.close()
    await writer.wait_closed()
    return json.loads(line)


def _docker_mock(running: set[str]):
    """Build a subprocess.run mock where `docker inspect <name>` returns 0 iff name in running."""
    def mock_run(cmd, **kw):
        result = MagicMock()
        result.returncode = 0
        result.stdout = ""
        result.stderr = ""
        # Catch `docker inspect -f {{.Id}} <name>`
        if len(cmd) >= 5 and cmd[0] == "docker" and cmd[1] == "inspect":
            name = cmd[-1]
            if name not in running:
                result.returncode = 1
                result.stderr = f"Error: No such object: {name}"
        return result
    return mock_run


# ── Startup validation ──────────────────────────────────────────────────────


def test_startup_validation_marks_missing(tmp_path: Path):
    """Daemon start validates registry entries and marks absent containers as missing."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    # Pre-populate registry with two containers
    from dsm.registry import ContainerRegistry
    reg = ContainerRegistry(reg_dir)
    reg.load()
    reg.register("alive_one", "id1", "10.0.0.1")
    reg.register("gone_one", "id2", "10.0.0.2")
    reg.persist_all()

    async def _run():
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock({"alive_one"})):
            await daemon.start()
            try:
                alive = daemon.registry.get("alive_one")
                gone = daemon.registry.get("gone_one")
                assert alive.status == "running"
                assert gone.status == "missing"
            finally:
                await daemon.stop()

    asyncio.run(_run())


def test_startup_validation_skips_missing_in_watcher_seed(tmp_path: Path):
    """Missing entries are excluded from the PortWatcher's initial container list."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    from dsm.registry import ContainerRegistry
    reg = ContainerRegistry(reg_dir)
    reg.load()
    reg.register("alive_one", "id1", "10.0.0.1")
    reg.register("gone_one", "id2", "10.0.0.2")
    reg.persist_all()

    async def _run():
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock({"alive_one"})):
            await daemon.start()
            try:
                seeded = daemon._port_watcher._containers
                assert "alive_one" in seeded
                assert "gone_one" not in seeded
            finally:
                await daemon.stop()

    asyncio.run(_run())


# ── validate command ────────────────────────────────────────────────────────


def test_validate_command_flips_missing_to_running(tmp_path: Path):
    """`dsm validate` recovers a missing container when Docker has it again."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    from dsm.registry import ContainerRegistry
    reg = ContainerRegistry(reg_dir)
    reg.load()
    entry = reg.register("zombie", "idz", "10.0.0.9")
    entry.status = "missing"
    reg.persist("zombie")

    async def _run():
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        # First start: container still gone
        with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock(set())):
            await daemon.start()
            # Stop the watcher so it doesn't race with validate via real docker calls
            await daemon._port_watcher.stop()
        try:
            # Now container reappears in Docker
            with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock({"zombie"})):
                resp = await _send_recv(daemon.socket_path, {
                    "id": "1", "cmd": "validate",
                })
            assert resp["error"] is None
            assert resp["result"]["recovered"] == ["zombie"]
            assert daemon.registry.get("zombie").status == "running"
            # Watcher picks it up (validate re-adds recovered containers)
            assert "zombie" in daemon._port_watcher._containers
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_validate_command_marks_newly_missing(tmp_path: Path):
    """`dsm validate` marks a previously-running container missing if Docker lost it."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    from dsm.registry import ContainerRegistry
    reg = ContainerRegistry(reg_dir)
    reg.load()
    reg.register("vanisher", "idv", "10.0.0.5")
    reg.persist("vanisher")

    async def _run():
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        # Start under a single mutable patch so we control state transitions
        with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock({"vanisher"})):
            await daemon.start()
            # Stop the watcher to prevent it from racing the validate command
            await daemon._port_watcher.stop()
        try:
            # Container disappears
            with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock(set())):
                resp = await _send_recv(daemon.socket_path, {
                    "id": "1", "cmd": "validate",
                })
            assert resp["error"] is None
            assert resp["result"]["missing"] == ["vanisher"]
            assert daemon.registry.get("vanisher").status == "missing"
        finally:
            await daemon.stop()

    asyncio.run(_run())


# ── _on_port_change container_gone wiring ───────────────────────────────────


def test_container_gone_change_marks_registry_missing(tmp_path: Path):
    """A container_gone PortChange routed through _on_port_change updates the registry."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    from dsm.registry import ContainerRegistry
    reg = ContainerRegistry(reg_dir)
    reg.load()
    reg.register("ghost", "idg", "10.0.0.3")
    reg.persist("ghost")

    async def _run():
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock({"ghost"})):
            await daemon.start()
        try:
            change = PortChange(container_name="ghost", port=None, action="container_gone", forward=None)
            daemon._on_port_change([change])
            # The mark is scheduled via run_coroutine_threadsafe; await it.
            await asyncio.sleep(0.05)
            assert daemon.registry.get("ghost").status == "missing"
        finally:
            await daemon.stop()

    asyncio.run(_run())


# ── Missing-state mutation rejection ────────────────────────────────────────


def test_start_container_rejects_missing(tmp_path: Path):
    """start_container on a missing entry raises a clear error."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    from dsm.registry import ContainerRegistry
    reg = ContainerRegistry(reg_dir)
    reg.load()
    entry = reg.register("dead", "idd", "10.0.0.8")
    entry.status = "missing"
    reg.persist("dead")

    async def _run():
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock(set())):
            await daemon.start()
        try:
            resp = await _send_recv(daemon.socket_path, {
                "id": "1", "cmd": "start_container", "container": "dead",
            })
            assert resp["error"] is not None
            assert "missing" in resp["error"]
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_start_forward_rejects_missing(tmp_path: Path):
    """start_forward on a missing entry raises a clear error."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    from dsm.registry import ContainerRegistry
    reg = ContainerRegistry(reg_dir)
    reg.load()
    entry = reg.register("ghosted", "idg", "10.0.0.7")
    entry.status = "missing"
    reg.persist("ghosted")

    async def _run():
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        with patch("dsm.daemon.subprocess.run", side_effect=_docker_mock(set())):
            await daemon.start()
        try:
            resp = await _send_recv(daemon.socket_path, {
                "id": "1", "cmd": "start_forward",
                "container": "ghosted", "port": 8080,
            })
            assert resp["error"] is not None
            assert "missing" in resp["error"]
        finally:
            await daemon.stop()

    asyncio.run(_run())


# ── CLI single-path behavior ────────────────────────────────────────────────


def test_daemon_client_required_exits_on_failure(tmp_path: Path, monkeypatch, capsys):
    """When the daemon can't start, the CLI prints a clean error and exits 1."""
    from dsm import cli

    def boom(*a, **kw):
        raise RuntimeError("daemon stub failed")

    monkeypatch.setattr(cli, "ensure_daemon_running", boom)

    with pytest.raises(SystemExit) as exc_info:
        cli._daemon_client_required()
    assert exc_info.value.code == 1
    err = capsys.readouterr().err
    assert "dsm daemon failed to start" in err
    assert "dsm daemon status" in err


def test_cmd_list_displays_missing_status_and_warning(tmp_path, monkeypatch, capsys):
    """cmd_list shows `missing` rows and prints a stderr footer."""
    from dsm import cli

    monkeypatch.setattr(cli, "DSM_DIR", tmp_path)

    fake_client = MagicMock()
    fake_client.send.return_value = [
        {
            "container_name": "ghost-app",
            "container_id": "abc",
            "container_ip": "10.0.0.1",
            "status": "missing",
            "created_at": "2026-05-06T10:00:00",
            "updated_at": "2026-05-06T10:00:00",
        },
        {
            "container_name": "live-app",
            "container_id": "def",
            "container_ip": "10.0.0.2",
            "status": "running",
            "created_at": "2026-05-06T10:00:00",
            "updated_at": "2026-05-06T10:00:00",
        },
    ]
    monkeypatch.setattr(cli, "_daemon_client_required", lambda: fake_client)

    cli.cmd_list(MagicMock())
    out = capsys.readouterr()
    assert "missing" in out.out
    assert "ghost-app" in out.out
    assert "live-app" in out.out
    assert "1 container(s) marked missing" in out.err
    assert "dsm validate" in out.err


def test_cmd_rm_finds_registry_only_container(tmp_path, monkeypatch, capsys):
    """cmd_rm falls back to registry lookup when no session dir matches the id."""
    from dsm import cli

    monkeypatch.setattr(cli, "DSM_DIR", tmp_path)

    sent = []

    fake_client = MagicMock()

    def fake_send(cmd, **kw):
        sent.append((cmd, kw))
        if cmd == "get_container":
            return {"container_name": kw["container"], "status": "missing"}
        if cmd == "remove_container":
            return {"removed": kw["container"]}
        return None

    fake_client.send.side_effect = fake_send
    monkeypatch.setattr(cli, "_daemon_client_required", lambda: fake_client)
    monkeypatch.setattr(cli, "container_alive", lambda name: False)

    args = MagicMock()
    args.id = "orphan-ctr"
    cli.cmd_rm(args)

    cmds = [s[0] for s in sent]
    assert "get_container" in cmds
    assert "remove_container" in cmds
    assert "orphan-ctr" in capsys.readouterr().out


def test_cmd_rm_errors_when_neither_session_nor_registry(tmp_path, monkeypatch, capsys):
    """cmd_rm exits with a clear error when no session dir and no registry entry exists."""
    from dsm import cli

    monkeypatch.setattr(cli, "DSM_DIR", tmp_path)

    fake_client = MagicMock()

    def fake_send(cmd, **kw):
        if cmd == "get_container":
            raise RuntimeError("Daemon error: container not found")
        return None

    fake_client.send.side_effect = fake_send
    monkeypatch.setattr(cli, "_daemon_client_required", lambda: fake_client)

    args = MagicMock()
    args.id = "nothere"
    with pytest.raises(SystemExit) as exc_info:
        cli.cmd_rm(args)
    assert exc_info.value.code == 1
    assert "no session or container found: nothere" in capsys.readouterr().err
