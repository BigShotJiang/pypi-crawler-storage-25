/**
 * DualList Widget configure with class="multi"
 */
jQuery(function () {
    $('select.cf-multi').each(function (_idx) {
        const cfg = $(this).data();
        $(this).multi(cfg);
    });
});