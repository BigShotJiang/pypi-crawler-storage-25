import webbrowser
from datetime import datetime
from typing import Annotated

import typer

from jobless import schemas
from jobless.commands.utils import (
    print_application,
    print_applications,
    resolve_field,
)
from jobless.context import AppContext
from jobless.enums import (
    ApplicationSortField,
    Location,
    OutputFormat,
    SortOrder,
    Status,
)
from jobless.repositories import (
    ApplicationRepository,
    CompanyRepository,
    ContactRepository,
    SkillRepository,
)

cli = typer.Typer(
    name="app",
    help="manage job applications",
    no_args_is_help=True,
    suggest_commands=True,
)


@cli.command("add")
def create(
    ctx: typer.Context,
    title: Annotated[
        str,
        typer.Option(
            "-t",
            "--title",
            prompt="job title",
            help="job title",
        ),
    ],
    company: Annotated[
        str,
        typer.Option(
            "-c",
            "--company",
            prompt="company name",
            help="company name",
        ),
    ],
    description: Annotated[
        str | None,
        typer.Option(
            "-d",
            "--description",
            help="job description",
        ),
    ] = None,
    salary: Annotated[
        str | None,
        typer.Option(
            "--salary",
            help="salary range (e.g. '50k-70k')",
        ),
    ] = None,
    url: Annotated[
        str | None,
        typer.Option(
            "-u",
            "--url",
            help="job posting URL",
        ),
    ] = None,
    location_type: Annotated[
        Location,
        typer.Option(
            "--location-type",
            help="work arrangement",
        ),
    ] = Location.ON_SITE,
    status: Annotated[
        Status,
        typer.Option(
            "--status",
            help="application status",
        ),
    ] = Status.SAVED,
    date_applied: Annotated[
        datetime | None,
        typer.Option(
            "--date-applied",
            help="submission date (YYYY-MM-DD)",
        ),
    ] = None,
    notes: Annotated[
        str | None,
        typer.Option(
            "--notes",
            help="additional notes",
        ),
    ] = None,
    skills: Annotated[
        list[str] | None,
        typer.Option(
            "--skill",
            help="add a skill; repeat to add multiple",
        ),
    ] = None,
    contacts: Annotated[
        list[int] | None,
        typer.Option(
            "--contact",
            help="link a contact by id; repeat to link multiple",
        ),
    ] = None,
):
    """
    Add a new job application.

    Examples:
      $ jobless app add --title "Backend Engineer" --company Acme
      $ jobless app add -t "SRE" -c Initech --status applied --skill Python --skill Go
      $ jobless app add -t "PM" -c Acme --contact 3 --contact 7
    """

    context: AppContext = ctx.obj
    with context.get_session() as session:
        app_repo = ApplicationRepository(session, context.mapper)
        company_repo = CompanyRepository(session, context.mapper)
        skill_repo = SkillRepository(session, context.mapper)
        contact_repo = ContactRepository(session, context.mapper)

        target_company = company_repo.get_or_create(company)

        skill_schemas = []
        if skills:
            skill_schemas = [skill_repo.get_or_create(s) for s in skills]

        contact_schemas = []
        if contacts:
            for contact_id in contacts:
                contact = contact_repo.get(contact_id)
                if not contact:
                    typer.echo(f"contact {contact_id} not found, skipping", err=True)
                    continue

                contact_schemas.append(contact)

        application = schemas.Application(
            title=title,
            company=target_company,
            description=description,
            salary=salary,
            url=url,
            location_type=location_type,
            status=status,
            date_applied=date_applied,
            notes=notes,
            skills=skill_schemas,
            contacts=contact_schemas,
        )

        app_repo.add(application)
        session.commit()

        typer.echo("Application added")


@cli.command("view")
def view(
    ctx: typer.Context,
    app_id: Annotated[
        int,
        typer.Argument(help="application id"),
    ],
    web: Annotated[
        bool,
        typer.Option(
            "-w",
            "--web",
            help="open the job posting URL if any.",
        ),
    ] = False,
):
    """
    Show details for a job application.

    Examples:
      $ jobless app view 3
      $ jobless app view 3 --web
    """

    context: AppContext = ctx.obj
    with context.get_session() as session:
        app_repo = ApplicationRepository(session, context.mapper)
        app = app_repo.get(app_id)
        if not app:
            typer.echo(f"application {app_id} not found.", err=True)
            raise typer.Exit(1)

        if web:
            if not app.url:
                typer.echo(f"application {app_id} has no URL ", err=True)
                raise typer.Exit(1)
            else:
                webbrowser.open(app.url)
                return

        print_application(app)


@cli.command("update")
def update(
    ctx: typer.Context,
    id: Annotated[
        int,
        typer.Argument(help="application id"),
    ],
    title: Annotated[
        str | None,
        typer.Option(
            "-t",
            "--title",
            help="new job title",
        ),
    ] = None,
    company: Annotated[
        str | None,
        typer.Option(
            "-c",
            "--company",
            help="new company name",
        ),
    ] = None,
    description: Annotated[
        str | None,
        typer.Option(
            "-d",
            "--description",
            help="new description; use '' to clear",
        ),
    ] = None,
    salary: Annotated[
        str | None,
        typer.Option(
            "--salary",
            help="new salary range; use '' to clear",
        ),
    ] = None,
    url: Annotated[
        str | None,
        typer.Option(
            "-u",
            "--url",
            help="new URL; use '' to clear",
        ),
    ] = None,
    location_type: Annotated[
        Location | None,
        typer.Option(
            "--location-type",
            help="new work arrangement",
        ),
    ] = None,
    status: Annotated[
        Status | None,
        typer.Option(
            "--status",
            help="new application status",
        ),
    ] = None,
    date_applied: Annotated[
        datetime | None,
        typer.Option(
            "--date-applied",
            help="new submission date (YYYY-MM-DD).",
        ),
    ] = None,
    follow_up_date: Annotated[
        datetime | None,
        typer.Option(
            "--follow-up-date",
            help="new follow up date (YYYY-MM-DD).",
        ),
    ] = None,
    notes: Annotated[
        str | None,
        typer.Option(
            "--notes",
            help="new notes; use '' to clear",
        ),
    ] = None,
    add_skills: Annotated[
        list[str] | None,
        typer.Option(
            "--add-skill",
            help="add a skill by name; repeat to add multiple",
        ),
    ] = None,
    remove_skills: Annotated[
        list[str] | None,
        typer.Option(
            "--remove-skill",
            help="remove a skill by name; repeat to add multiple",
        ),
    ] = None,
    add_contacts: Annotated[
        list[int] | None,
        typer.Option(
            "--add-contact",
            help="link a contact by id; repeat to link multiple",
        ),
    ] = None,
    remove_contacts: Annotated[
        list[int] | None,
        typer.Option(
            "--remove-contact",
            help="unlink a contact by id; repeat to unlink multiple",
        ),
    ] = None,
):
    """
    Update an existing job application.

    Only the fields provided will be changed. To clear an optional field
    pass an empty string.

    Examples:
      $ jobless app update 3 --status interviewing
      $ jobless app update 3 --add-skill Python --remove-skill Rust
      $ jobless app update 3 --remove-skill Go
      $ jobless app update 3 --notes ''
      $ jobless app update 3 --add-contact 5
      $ jobless app update 3 --remove-contact 2 --add-contact 9
    """

    context: AppContext = ctx.obj
    with context.get_session() as session:
        app_repo = ApplicationRepository(session, context.mapper)
        skill_repo = SkillRepository(session, context.mapper)

        existing_app = app_repo.get(id)
        if not existing_app:
            typer.echo(f"application {id} not found", err=True)
            raise typer.Exit(1)

        target_company = existing_app.company
        if company is not None:
            company_repo = CompanyRepository(session, context.mapper)
            target_company = company_repo.get_or_create(company)

        target_skills = existing_app.skills
        if add_skills or remove_skills:
            if remove_skills:
                remove_names = {s.lower() for s in remove_skills}
                target_skills = [
                    s for s in target_skills if s.name.lower() not in remove_names
                ]

            if add_skills:
                existing_names = {s.name.lower() for s in target_skills}
                for skill_name in add_skills:
                    if skill_name.lower() not in existing_names:
                        target_skills.append(skill_repo.get_or_create(skill_name))

        target_contacts = list(existing_app.contacts)
        if add_contacts or remove_contacts:
            contact_repo = ContactRepository(session, context.mapper)

            if remove_contacts:
                remove_ids = set(remove_contacts)
                target_contacts = [c for c in target_contacts if c.id not in remove_ids]

            if add_contacts:
                existing_ids = {c.id for c in target_contacts}
                for contact_id in add_contacts:
                    if contact_id in existing_ids:
                        continue

                    contact = contact_repo.get(contact_id)
                    if not contact:
                        typer.echo(
                            f"contact {contact_id} not found, skipping", err=True
                        )
                        continue

                    target_contacts.append(contact)

        updated_app = schemas.Application(
            id=existing_app.id,
            title=title if title is not None else existing_app.title,
            company=target_company,
            description=resolve_field(description, existing_app.description),
            salary=resolve_field(salary, existing_app.salary),
            url=resolve_field(url, existing_app.url),
            location_type=location_type
            if location_type is not None
            else existing_app.location_type,
            status=status if status is not None else existing_app.status,
            date_applied=resolve_field(date_applied, existing_app.date_applied),
            follow_up_date=resolve_field(follow_up_date, existing_app.follow_up_date),
            notes=resolve_field(notes, existing_app.notes),
            skills=target_skills,
            contacts=target_contacts,
        )

        app_repo.update(updated_app)
        session.commit()

        typer.echo("Application updated")


@cli.command("list")
def get_all(
    ctx: typer.Context,
    title: Annotated[
        str | None,
        typer.Option(
            "-t",
            "--title",
            help="filter by title",
        ),
    ] = None,
    statuses: Annotated[
        list[Status] | None,
        typer.Option(
            "--status",
            help="filter by status; repeat to match multiple",
        ),
    ] = None,
    locations: Annotated[
        list[Location] | None,
        typer.Option(
            "--location-type",
            help="filter by work arrangement; repeat to match multiple",
        ),
    ] = None,
    company: Annotated[
        str | None,
        typer.Option(
            "--company-name",
            help="filter by company name",
        ),
    ] = None,
    company_id: Annotated[
        int | None,
        typer.Option(
            "--company-id",
            help="filter by company id",
        ),
    ] = None,
    skills: Annotated[
        list[str] | None,
        typer.Option(
            "--skill",
            help="filter by skill; repeat to match multiple",
        ),
    ] = None,
    applied_after: Annotated[
        datetime | None,
        typer.Option(
            "--applied-after", help="filter by date submitted (on or after YYYY-MM-DD)"
        ),
    ] = None,
    applied_before: Annotated[
        datetime | None,
        typer.Option(
            "--applied-before",
            help="filter by date submitted (on or before YYYY-MM-DD)",
        ),
    ] = None,
    follow_up_after: Annotated[
        datetime | None,
        typer.Option(
            "--follow-up-after",
            help="filter by follow-up date (on or after YYYY-MM-DD)",
        ),
    ] = None,
    follow_up_before: Annotated[
        datetime | None,
        typer.Option(
            "--follow-up-before",
            help="filter by follow-up date (on or before YYYY-MM-DD)",
        ),
    ] = None,
    sort_by: Annotated[
        ApplicationSortField,
        typer.Option(
            "--sort-by",
            help="property to sort by",
        ),
    ] = ApplicationSortField.CREATED,
    sort_order: Annotated[
        SortOrder,
        typer.Option(
            "--order",
            help="sort order",
        ),
    ] = SortOrder.DESC,
    format: Annotated[
        OutputFormat,
        typer.Option(
            "--format",
            help="output format",
        ),
    ] = OutputFormat.TABLE,
    limit: Annotated[
        int | None,
        typer.Option(
            "--limit",
            min=1,
            help="limit the number of results",
        ),
    ] = None,
):
    """
    List job applications with optional filters.

    Examples:
      $ jobless app list --status applied --status interviewing
      $ jobless app list --location-type remote --skill python
      $ jobless app list --applied-after 2024-01-01
    """

    # TODO: add option to filter by contact::{name, url, email, etc.}

    context: AppContext = ctx.obj
    f = schemas.ApplicationFilter(
        title=title,
        statuses=statuses or [],
        location_types=locations or [],
        skills=skills or [],
        company_name=company,
        company_id=company_id,
        applied_after=applied_after.date() if applied_after else None,
        applied_before=applied_before.date() if applied_before else None,
        follow_up_date_after=follow_up_after.date() if follow_up_after else None,
        follow_up_date_before=follow_up_before.date() if follow_up_before else None,
        sort_by=sort_by,
        sort_order=sort_order,
        limit=limit,
    )
    with context.get_session() as session:
        app_repo = ApplicationRepository(session, context.mapper)
        applications = app_repo.filter(f)

        if not applications:
            typer.echo("No applications found", err=True)
            raise typer.Exit(1)

        print_applications(applications, format)


@cli.command("del")
def delete(
    ctx: typer.Context,
    app_ids: Annotated[
        list[int],
        typer.Argument(help="id(s) of applications to delete"),
    ],
    force: Annotated[
        bool,
        typer.Option(
            "-f",
            "--force",
            help="skip confirmation prompt(s)",
        ),
    ] = False,
):
    """
    Delete one or more job applications.

    Examples:
      $ jobless app del 4
      $ jobless app del 4 7 12 --force
    """

    context: AppContext = ctx.obj
    with context.get_session() as session:
        app_repo = ApplicationRepository(session, context.mapper)

        valid_apps = []
        for id in app_ids:
            app = app_repo.get(id)
            if app:
                valid_apps.append(app)
            else:
                typer.echo(f"application {id} not found. skipping", err=True)

        if not valid_apps:
            typer.echo("nothing to do")
            raise typer.Exit(1)

        for app in valid_apps:
            if not force:
                if not typer.confirm(
                    f"You're going to delete application {app.id}: '{app.title}'. Continue?",
                    default=False,
                ):
                    continue

            app_repo.delete(app.id)
            typer.echo(f"Application {app.id} deleted")

        session.commit()
