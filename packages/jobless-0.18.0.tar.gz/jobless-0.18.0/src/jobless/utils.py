import os
import sys
from pathlib import Path


def get_app_dir(app_name: str) -> Path:
    app_slug = app_name.lower().replace(" ", "-")

    if sys.platform.startswith("win"):
        base = Path(os.environ.get("APPDATA", Path.home()))
        return base / app_slug

    if sys.platform == "darwin":
        return Path.home() / "Library/Application Support" / app_name

    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg_config) if xdg_config else Path.home() / ".config"
    return base / app_slug
