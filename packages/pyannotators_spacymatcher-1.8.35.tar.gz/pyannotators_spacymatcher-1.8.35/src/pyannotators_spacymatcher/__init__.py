"""SpacyMatcher annotator using the spacy rule-matching engine"""

__version__ = "1.8.35"
