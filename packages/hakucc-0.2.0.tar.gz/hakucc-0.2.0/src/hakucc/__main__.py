"""CLI entry point for hakucc."""

from __future__ import annotations

import asyncio
import os
import signal
import sys
from pathlib import Path

import click

from . import logger
from .config import load_config, config_exists, ResolvedConfig
from .lock import (
    acquire_lock,
    release_lock,
    list_running,
    kill_profile,
    kill_all,
)
from .session import SessionStore


def _get_cwd() -> str:
    """Get working directory, preferring git root."""
    cwd = os.getcwd()
    # Walk up to find git root
    p = Path(cwd)
    for parent in [p] + list(p.parents):
        if (parent / ".git").exists():
            return str(parent)
    return cwd


def _print_profiles(cfg) -> None:
    """Print all profiles in a table."""
    from .config import list_profiles as lp

    profiles = lp(cfg)
    click.echo(f"{'Profile':<15} {'App ID':<25}")
    click.echo("-" * 40)
    for p in profiles:
        click.echo(f"{p['name']:<15} {p['app_id']:<25}")


def _cleanup_temp_files(data_dir: Path, profile: str | None = None, older_than_hours: int = 0) -> int:
    """Clean up temporary files."""
    import time

    temp_base = data_dir / "temp"
    if not temp_base.exists():
        return 0

    count = 0
    cutoff = time.time() - (older_than_hours * 3600) if older_than_hours > 0 else 0

    targets = [temp_base / profile] if profile else list(temp_base.iterdir())
    for target in targets:
        if not target.exists():
            continue
        for f in target.rglob("*"):
            if f.is_file():
                if cutoff and f.stat().st_mtime > cutoff:
                    continue
                f.unlink()
                count += 1
        # Remove empty dirs
        if target.is_dir() and not any(target.iterdir()):
            target.rmdir()

    return count


async def _run_bridge(cfg: ResolvedConfig, profile: str, cwd: str,
                       continue_session: bool, force: bool,
                       shutdown_event: asyncio.Event) -> None:
    """Start the bridge."""
    # Lazy import to avoid circular deps
    from .bridge import Bridge

    bridge = Bridge(cfg, profile)
    await bridge.start(
        cwd=cwd,
        continue_session=continue_session,
        force=force,
        shutdown_event=shutdown_event,
    )


@click.group(invoke_without_command=True)
@click.option("-d", "--daemon", is_flag=True, help="Run as daemon (background)")
@click.option("-c", "--continue", "continue_session", is_flag=True, help="Resume last session")
@click.option("-p", "--profile", default=None, help="Profile name")
@click.option("-f", "--force", is_flag=True, help="Kill existing process if locked")
@click.option("--cwd", default=None, help="Working directory")
@click.pass_context
def cli(ctx, daemon: bool, continue_session: bool, profile: str | None,
        force: bool, cwd: str | None) -> None:
    """hakucc — Claude Code on Feishu/Lark"""
    ctx.ensure_object(dict)

    if ctx.invoked_subcommand is not None:
        return

    # Must have config
    if not config_exists():
        click.echo("No configuration found. Run: hakucc setup")
        ctx.exit(1)
        return

    cfg = load_config()
    resolved = cfg.resolve(profile)
    profile_name = profile or "default"
    work_dir = cwd or _get_cwd()

    # Check lock
    lock = acquire_lock(resolved.lock_file, profile_name, work_dir, force)
    if lock is None:
        ctx.exit(1)
        return

    # Load session
    session = SessionStore(resolved.state_file)
    if continue_session:
        session.load()
        if session.has_session():
            logger.info(f"Resuming session: {session.session_id[:16]}...")
        else:
            logger.warn("No session to resume, starting fresh")

    # Setup signal handlers
    loop = asyncio.new_event_loop()
    shutdown_event = asyncio.Event()

    def _shutdown(signum, frame):
        logger.info("Shutting down...")
        shutdown_event.set()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    if daemon:
        # Fork to background
        pid = os.fork()
        if pid > 0:
            logger.success(f"Daemon started (PID {pid})")
            sys.exit(0)
        os.setsid()

    try:
        loop.run_until_complete(
            _run_bridge(resolved, profile_name, work_dir, continue_session, force, shutdown_event)
        )
    except KeyboardInterrupt:
        pass
    finally:
        release_lock(resolved.lock_file)
        loop.close()


@cli.command()
@click.option("-p", "--profile", default=None, help="Profile to configure")
def setup(profile: str | None) -> None:
    """Interactive configuration wizard."""
    asyncio.run(_run_setup_cli(profile))


async def _run_setup_cli(profile: str | None) -> None:
    from .setup import run_setup
    await run_setup(profile)


@cli.command("new-profile")
@click.argument("name")
def new_profile(name: str) -> None:
    """Create a new profile."""
    asyncio.run(_run_setup_cli(name))


@cli.command("list-profiles")
def list_profiles_cmd() -> None:
    """List all configured profiles."""
    if not config_exists():
        click.echo("No configuration found.")
        return
    cfg = load_config()
    _print_profiles(cfg)


@cli.command("reset-session")
@click.option("-p", "--profile", default=None, help="Profile to reset")
def reset_session(profile: str | None) -> None:
    """Clear session state for a profile."""
    cfg = load_config()
    resolved = cfg.resolve(profile)
    session = SessionStore(resolved.state_file)
    session.load()
    session.reset()
    logger.success("Session reset")


@cli.command("ps")
def ps_cmd() -> None:
    """List running hakucc processes."""
    data_dir = Path.home() / ".hakucc"
    running = list_running(data_dir)

    if not running:
        click.echo("No running processes.")
        return

    click.echo(f"{'Profile':<15} {'PID':<8} {'Started':<20} {'CWD'}")
    click.echo("-" * 70)
    import datetime
    for info in running:
        started = datetime.datetime.fromtimestamp(info.started_at).strftime("%Y-%m-%d %H:%M:%S")
        click.echo(f"{info.profile:<15} {info.pid:<8} {started:<20} {info.cwd}")


@cli.command("kill")
@click.argument("target")
def kill_cmd(target: str) -> None:
    """Kill a running process by profile name or PID."""
    data_dir = Path.home() / ".hakucc"
    if kill_profile(data_dir, target):
        logger.success(f"Killed {target}")
    else:
        logger.error(f"No process found for '{target}'")


@cli.command("kill-all")
def kill_all_cmd() -> None:
    """Kill all running hakucc processes."""
    data_dir = Path.home() / ".hakucc"
    count = kill_all(data_dir)
    logger.success(f"Killed {count} process(es)")


@cli.command("cleanup-tmp-files")
@click.option("-p", "--profile", default=None, help="Specific profile")
@click.option("--older-than", default=24, help="Only files older than N hours")
@click.option("--all-profiles", "all_profiles", is_flag=True, help="Clean all profiles")
def cleanup(profile: str | None, older_than: int, all_profiles: bool) -> None:
    """Clean up temporary files."""
    data_dir = Path.home() / ".hakucc"
    target = None if all_profiles else (profile or "default")
    count = _cleanup_temp_files(data_dir, target, older_than)
    logger.success(f"Cleaned up {count} file(s)")


@cli.command("sessions")
@click.option("-p", "--profile", default=None, help="Profile")
def sessions_cmd(profile: str | None) -> None:
    """List Claude sessions (SDK feature)."""
    cfg = load_config()
    resolved = cfg.resolve(profile)
    session = SessionStore(resolved.state_file)
    session.load()

    if not session.has_session():
        click.echo("No active session.")
        return

    click.echo(f"Session ID: {session.session_id}")
    click.echo(f"Chat ID:    {session.chat_id}")
    click.echo(f"Owner:      {session.owner_open_id or '(not set)'}")


if __name__ == "__main__":
    cli()
