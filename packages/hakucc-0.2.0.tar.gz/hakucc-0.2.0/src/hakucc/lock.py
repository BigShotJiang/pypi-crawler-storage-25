"""Process lock management for hakucc."""

from __future__ import annotations

import json
import os
import signal
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from . import logger


@dataclass
class LockInfo:
    """Information stored in a lock file."""

    pid: int
    cwd: str
    started_at: float
    profile: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> LockInfo:
        return cls(
            pid=d["pid"],
            cwd=d["cwd"],
            started_at=d["started_at"],
            profile=d["profile"],
        )


def _is_running(pid: int) -> bool:
    """Check if a process with given PID is running."""
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


def acquire_lock(lock_file: Path, profile: str, cwd: str, force: bool = False) -> LockInfo | None:
    """Try to acquire a process lock. Returns None if locked by another process."""
    lock_file.parent.mkdir(parents=True, exist_ok=True)

    if lock_file.exists():
        try:
            data = json.loads(lock_file.read_text(encoding="utf-8"))
            existing = LockInfo.from_dict(data)
        except (json.JSONDecodeError, KeyError):
            # Corrupted lock file, remove it
            lock_file.unlink()
            existing = None

        if existing and _is_running(existing.pid):
            if force:
                logger.warn(f"Force-killing existing process (PID {existing.pid})")
                release_lock(lock_file, kill=True)
            else:
                elapsed = time.time() - existing.started_at
                logger.error(
                    f"Profile '{profile}' is already running "
                    f"(PID {existing.pid}, {elapsed:.0f}s ago, cwd: {existing.cwd})"
                )
                logger.info("Use --force to kill the existing process")
                return None

        # Stale lock file (process died)
        if existing:
            logger.info(f"Removing stale lock (PID {existing.pid} is gone)")
            lock_file.unlink()

    lock_info = LockInfo(
        pid=os.getpid(),
        cwd=cwd,
        started_at=time.time(),
        profile=profile,
    )
    lock_file.write_text(
        json.dumps(lock_info.to_dict(), indent=2),
        encoding="utf-8",
    )
    return lock_info


def release_lock(lock_file: Path, kill: bool = False) -> None:
    """Release the process lock."""
    if not lock_file.exists():
        return

    if kill:
        try:
            data = json.loads(lock_file.read_text(encoding="utf-8"))
            pid = data.get("pid", 0)
            if pid and _is_running(pid):
                logger.warn(f"Sending SIGTERM to PID {pid}")
                os.kill(pid, signal.SIGTERM)
                # Wait briefly, then force kill
                for _ in range(10):
                    time.sleep(0.5)
                    if not _is_running(pid):
                        break
                if _is_running(pid):
                    logger.warn(f"Sending SIGKILL to PID {pid}")
                    os.kill(pid, signal.SIGKILL)
        except (json.JSONDecodeError, KeyError, ProcessLookupError):
            pass

    try:
        lock_file.unlink()
    except FileNotFoundError:
        pass


def list_running(lock_dir: Path) -> list[LockInfo]:
    """List all running profile processes."""
    results: list[LockInfo] = []
    if not lock_dir.exists():
        return results

    for lock_file in lock_dir.glob("lock-*.json"):
        try:
            data = json.loads(lock_file.read_text(encoding="utf-8"))
            info = LockInfo.from_dict(data)
            if _is_running(info.pid):
                results.append(info)
            else:
                # Clean stale lock
                lock_file.unlink()
        except (json.JSONDecodeError, KeyError):
            lock_file.unlink(missing_ok=True)

    return results


def kill_profile(lock_dir: Path, target: str) -> bool:
    """Kill a process by profile name or PID string."""
    lock_file = lock_dir / f"lock-{target}.json"

    # Try as profile name first
    if lock_file.exists():
        release_lock(lock_file, kill=True)
        return True

    # Try as PID
    try:
        pid = int(target)
        os.kill(pid, signal.SIGTERM)
        logger.success(f"Sent SIGTERM to PID {pid}")
        return True
    except (ValueError, ProcessLookupError, PermissionError):
        pass

    return False


def kill_all(lock_dir: Path) -> int:
    """Kill all running hakucc processes. Returns count killed."""
    running = list_running(lock_dir)
    for info in running:
        lock_file = lock_dir / f"lock-{info.profile}.json"
        release_lock(lock_file, kill=True)
    return len(running)
