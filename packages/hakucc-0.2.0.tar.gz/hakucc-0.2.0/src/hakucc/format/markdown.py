"""Markdown optimization and sanitization for Feishu cards."""

from __future__ import annotations

import re


def optimize_for_card(markdown: str) -> str:
    """Optimize Markdown for Feishu card display.

    - Demote headings (H1→H4, H2→H5, H3-H6→H5)
    - Remove external images (replace with links)
    - Strip blob URLs
    - Protect code blocks during transformation
    - Safe truncation (detect unclosed code blocks)
    """
    # Protect code blocks
    code_blocks: list[str] = []
    counter = [0]

    def _save_block(m: re.Match) -> str:
        code_blocks.append(m.group(0))
        placeholder = f"__CODE_BLOCK_{counter[0]}__"
        counter[0] += 1
        return placeholder

    markdown = re.sub(r"```[\s\S]*?```", _save_block, markdown)

    # Demote headings
    lines = markdown.split("\n")
    for i, line in enumerate(lines):
        m = re.match(r"^(#{1,6})\s", line)
        if m:
            level = len(m.group(1))
            rest = line[level + 1:]
            if level == 1:
                lines[i] = f"#### {rest}"
            elif level == 2:
                lines[i] = f"##### {rest}"
            else:
                lines[i] = f"##### {rest}"
    markdown = "\n".join(lines)

    # Remove external images → plain links
    markdown = re.sub(
        r"!\[([^\]]*)\]\(https?://[^)]+\)",
        r"[\1]",
        markdown,
    )

    # Strip blob URLs
    markdown = re.sub(r"https?://blob:[^\s)\]]+", "", markdown)

    # Restore code blocks
    for i, block in enumerate(code_blocks):
        markdown = markdown.replace(f"__CODE_BLOCK_{i}__", block)

    # Safe truncation: unclosed code blocks
    count = len(re.findall(r"```", markdown))
    if count % 2 != 0:
        markdown += "\n```"

    return markdown


def safe_truncate(text: str, max_length: int = 30000) -> str:
    """Safely truncate text, preserving code blocks and tables."""
    if len(text) <= max_length:
        return text

    truncated = text[:max_length]

    # Check for unclosed code blocks
    code_count = len(re.findall(r"```", truncated))
    if code_count % 2 != 0:
        truncated += "\n```"

    # Check for unclosed tables (partial | at end)
    if truncated.rstrip().endswith("|"):
        truncated = truncated.rstrip()[:-1].rstrip()

    return truncated + "\n\n...(truncated)"


def strip_thinking_tags(text: str) -> str:
    """Remove <thinking>...</thinking> tags from text."""
    return re.sub(r"<thinking>[\s\S]*?</thinking>", "", text).strip()


def extract_thinking(text: str) -> tuple[str, str]:
    """Extract thinking content, return (thinking, rest)."""
    match = re.search(r"<thinking>([\s\S]*?)</thinking>", text)
    if match:
        thinking = match.group(1).strip()
        rest = text[:match.start()] + text[match.end():]
        return thinking, rest.strip()
    return "", text
