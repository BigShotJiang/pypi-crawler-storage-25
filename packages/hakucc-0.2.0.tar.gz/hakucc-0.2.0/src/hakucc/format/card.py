"""Card JSON construction helpers for Feishu interactive cards."""

from __future__ import annotations

import json
from typing import Any


def build_card(
    markdown: str,
    title: str = "Claude",
    header_icon_img_key: str = "",
    template: str = "blue",
    tags: list[dict[str, str]] | None = None,
    subtitle: str = "",
) -> str:
    """Build a simple markdown card JSON string."""
    header: dict[str, Any] = {
        "title": {"tag": "plain_text", "content": title},
        "template": template,
    }
    if header_icon_img_key:
        header["icon"] = {"tag": "custom_icon", "img_key": header_icon_img_key}
    else:
        header["icon"] = {"tag": "standard_icon", "token": "larkcommunity_colorful"}
    if subtitle:
        header["subtitle"] = {"tag": "plain_text", "content": subtitle}
    if tags:
        header["text_tag_list"] = tags

    card: dict[str, Any] = {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": header,
        "body": {"elements": [{"tag": "markdown", "content": markdown}]},
    }
    return json.dumps(card, ensure_ascii=False)


def build_multi_element_card(
    elements: list[dict[str, Any]],
    title: str = "Claude",
    header_icon_img_key: str = "",
    template: str = "blue",
    tags: list[dict[str, str]] | None = None,
) -> str:
    """Build a card with multiple body elements."""
    header: dict[str, Any] = {
        "title": {"tag": "plain_text", "content": title},
        "template": template,
    }
    if header_icon_img_key:
        header["icon"] = {"tag": "custom_icon", "img_key": header_icon_img_key}
    else:
        header["icon"] = {"tag": "standard_icon", "token": "larkcommunity_colorful"}
    if tags:
        header["text_tag_list"] = tags

    card: dict[str, Any] = {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": header,
        "body": {"elements": elements},
    }
    return json.dumps(card, ensure_ascii=False)


def build_text_tag(text: str, color: str = "blue") -> dict[str, str]:
    """Build a single header text tag."""
    return {
        "tag": "text_tag",
        "text": {"tag": "plain_text", "content": text},
        "color": color,
    }


def build_hr() -> dict[str, Any]:
    """Build a horizontal rule element."""
    return {"tag": "hr"}


def build_markdown_element(content: str, text_size: str | None = None) -> dict[str, Any]:
    """Build a markdown element."""
    el: dict[str, Any] = {"tag": "markdown", "content": content}
    if text_size:
        el["text_size"] = text_size
    return el


def build_note_element(content: str) -> dict[str, Any]:
    """Build a grey note element."""
    return {
        "tag": "markdown",
        "content": f"<font color='grey'>{content}</font>",
        "text_size": "notation",
    }


def build_header_tags(
    model: str | None = None,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    duration_ms: int | None = None,
    tool_count: int | None = None,
) -> list[dict[str, str]]:
    """Build colorful header tag list for stats."""
    tags: list[dict[str, str]] = []
    if model:
        short = model.replace("claude-", "")
        tags.append({
            "tag": "text_tag",
            "text": {"tag": "plain_text", "content": short},
            "color": "blue",
        })
    if input_tokens is not None and output_tokens is not None:
        total = input_tokens + output_tokens
        tags.append({
            "tag": "text_tag",
            "text": {"tag": "plain_text", "content": f"{total:,} tokens"},
            "color": "turquoise",
        })
    if duration_ms is not None:
        seconds = duration_ms / 1000
        text = f"{seconds:.0f}s" if seconds >= 60 else f"{seconds:.1f}s"
        tags.append({
            "tag": "text_tag",
            "text": {"tag": "plain_text", "content": text},
            "color": "orange",
        })
    if tool_count:
        tags.append({
            "tag": "text_tag",
            "text": {"tag": "plain_text", "content": f"{tool_count} tools"},
            "color": "purple",
        })
    return tags


def build_thinking_panel(thinking: str, duration_ms: int | None = None) -> dict[str, Any]:
    """Build a collapsible panel for thinking content."""
    duration_text = ""
    if duration_ms is not None:
        seconds = duration_ms / 1000
        duration_text = f" {seconds:.1f}s"
    display = thinking[:3000] + "..." if len(thinking) > 3000 else thinking
    return {
        "tag": "collapsible_panel",
        "expanded": False,
        "header": {
            "title": {"tag": "markdown", "content": f"Thinking{duration_text}"},
            "vertical_align": "center",
            "icon": {
                "tag": "standard_icon",
                "token": "down-small-ccm_outlined",
                "size": "16px 16px",
            },
            "icon_position": "follow_text",
            "icon_expanded_angle": -180,
        },
        "border": {"color": "grey", "corner_radius": "5px"},
        "vertical_spacing": "8px",
        "padding": "8px",
        "elements": [
            {"tag": "markdown", "content": display, "text_size": "notation"},
        ],
    }


def build_stats_footer(
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    tool_count: int | None = None,
) -> dict[str, Any]:
    """Build a stats footer element."""
    parts = []
    if input_tokens is not None:
        parts.append(f"in: {input_tokens:,}")
    if output_tokens is not None:
        parts.append(f"out: {output_tokens:,}")
    if tool_count is not None:
        parts.append(f"tools: {tool_count}")
    if not parts:
        return {"tag": "hr"}
    text = " | ".join(parts)
    return {"tag": "markdown", "content": f"<font color='grey'>{text}</font>", "text_size": "notation"}


def build_reply_card(
    markdown: str,
    title: str = "Claude",
    header_icon_img_key: str = "",
    template: str = "blue",
    tags: list[dict[str, str]] | None = None,
    thinking: str | None = None,
    stats: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a full reply card dict (header + thinking + markdown + stats)."""
    elements: list[dict[str, Any]] = []
    if thinking:
        elements.append(build_thinking_panel(thinking, stats.get("duration_ms") if stats else None))
        elements.append({"tag": "hr"})
    elements.append({"tag": "markdown", "content": markdown})
    if stats:
        elements.append({"tag": "hr"})
        elements.append(build_stats_footer(
            input_tokens=stats.get("input_tokens"),
            output_tokens=stats.get("output_tokens"),
            tool_count=stats.get("tool_count"),
        ))
    header: dict[str, Any] = {
        "title": {"tag": "plain_text", "content": title},
        "template": template,
    }
    if header_icon_img_key:
        header["icon"] = {"tag": "custom_icon", "img_key": header_icon_img_key}
    else:
        header["icon"] = {"tag": "standard_icon", "token": "larkcommunity_colorful"}
    if tags:
        header["text_tag_list"] = tags
    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": header,
        "body": {"elements": elements},
    }


def build_tool_card(
    label: str,
    detail: str,
    status: str = "running",
    tool_name: str | None = None,
) -> dict[str, Any]:
    """Build a tool execution status card dict."""
    elements: list[dict[str, Any]] = [
        {"tag": "markdown", "content": f"**{label}**"},
    ]
    if detail:
        display = detail[:500] + "..." if len(detail) > 500 else detail
        elements.append({"tag": "markdown", "content": f"`{display}`", "text_size": "notation"})
    templates = {"running": "turquoise", "done": "green", "error": "red"}
    title_text = f"{label}" if not tool_name else f"{tool_name}: {label}"
    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": title_text},
            "template": templates.get(status, "turquoise"),
            "icon": {"tag": "standard_icon", "token": "larkcommunity_colorful"},
        },
        "body": {"elements": elements},
    }
