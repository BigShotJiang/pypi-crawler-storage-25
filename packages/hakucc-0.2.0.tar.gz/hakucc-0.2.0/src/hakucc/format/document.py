"""Markdown → Feishu document block conversion.

Converts Markdown content to Feishu DocX API block format for
cloud document creation.
"""

from __future__ import annotations

import re
from typing import Any


# Language mapping for code blocks (75+ languages)
CODE_LANG_MAP: dict[str, int] = {
    "plaintext": 1, "text": 1, "txt": 1,
    "javascript": 2, "js": 2,
    "typescript": 3, "ts": 3,
    "python": 4, "py": 4,
    "java": 5,
    "go": 6, "golang": 6,
    "rust": 7, "rs": 7,
    "c": 8,
    "cpp": 9, "c++": 9, "cc": 9,
    "csharp": 10, "c#": 10, "cs": 10,
    "ruby": 11, "rb": 11,
    "php": 12,
    "swift": 13,
    "kotlin": 14, "kt": 14,
    "dart": 15,
    "r": 16,
    "matlab": 17,
    "scala": 18,
    "lua": 19,
    "perl": 20,
    "haskell": 21,
    "elixir": 22,
    "clojure": 23,
    "sql": 24,
    "shell": 25, "bash": 25, "sh": 25, "zsh": 25,
    "powershell": 26,
    "html": 27,
    "css": 28,
    "json": 29,
    "yaml": 30, "yml": 30,
    "xml": 31,
    "markdown": 32, "md": 32,
    "dockerfile": 33,
    "makefile": 34,
    "toml": 35,
    "ini": 36,
    "diff": 37,
}


def markdown_to_blocks(markdown: str) -> list[dict[str, Any]]:
    """Convert Markdown to a list of Feishu DocX block dictionaries.

    Supports:
    - Headings (H1-H6)
    - Paragraphs
    - Code blocks with language
    - Tables (degraded to code blocks for complex cases)
    - Callout blocks (> [!TYPE])
    - Horizontal rules
    - Lists (ordered/unordered)
    - Bold/italic/inline code
    """
    blocks: list[dict[str, Any]] = []
    lines = markdown.split("\n")
    i = 0

    while i < len(lines):
        line = lines[i]

        # Empty line
        if not line.strip():
            i += 1
            continue

        # Code block
        if line.strip().startswith("```"):
            code_block, i = _parse_code_block(lines, i)
            blocks.append(code_block)
            continue

        # Callout (> [!TYPE])
        if re.match(r"^>\s*\[!(NOTE|TIP|WARNING|DANGER|CAUTION|INFO)\]", line, re.IGNORECASE):
            callout, i = _parse_callout(lines, i)
            blocks.append(callout)
            continue

        # Heading
        heading_match = re.match(r"^(#{1,6})\s+(.*)", line)
        if heading_match:
            level = len(heading_match.group(1))
            text = heading_match.group(2).strip()
            blocks.append(_heading_block(text, level))
            i += 1
            continue

        # Horizontal rule
        if re.match(r"^(-{3,}|\*{3,}|_{3,})\s*$", line.strip()):
            blocks.append({"block_type": 22})  # divider
            i += 1
            continue

        # Table
        if "|" in line and i + 1 < len(lines) and re.match(r"^\|[\s:\-|]+\|$", lines[i + 1].strip()):
            table_block, i = _parse_table(lines, i)
            blocks.append(table_block)
            continue

        # Unordered list
        if re.match(r"^\s*[-*+]\s+", line):
            list_block, i = _parse_unordered_list(lines, i)
            blocks.append(list_block)
            continue

        # Ordered list
        if re.match(r"^\s*\d+\.\s+", line):
            list_block, i = _parse_ordered_list(lines, i)
            blocks.append(list_block)
            continue

        # Regular paragraph
        para_lines = [line]
        i += 1
        while i < len(lines) and lines[i].strip() and not _is_block_start(lines[i]):
            para_lines.append(lines[i])
            i += 1
        text = " ".join(para_lines)
        blocks.append(_paragraph_block(text))

    return blocks


def _is_block_start(line: str) -> bool:
    """Check if a line starts a new block element."""
    if not line.strip():
        return True
    if line.strip().startswith("```"):
        return True
    if re.match(r"^#{1,6}\s", line):
        return True
    if re.match(r"^>\s*\[!", line):
        return True
    if re.match(r"^[-*+]\s", line):
        return True
    if re.match(r"^\d+\.\s", line):
        return True
    if re.match(r"^(-{3,}|\*{3,}|_{3,})\s*$", line.strip()):
        return True
    return False


def _parse_code_block(lines: list[str], start: int) -> tuple[dict, int]:
    """Parse a fenced code block."""
    first_line = lines[start].strip()
    lang = first_line[3:].strip().lower()
    lang_id = CODE_LANG_MAP.get(lang, 1)

    code_lines: list[str] = []
    i = start + 1
    while i < len(lines):
        if lines[i].strip().startswith("```"):
            i += 1
            break
        code_lines.append(lines[i])
        i += 1

    code_text = "\n".join(code_lines)

    return {
        "block_type": 14,  # code
        "code": {
            "language": lang_id,
            "text": {"elements": [_text_element(code_text)]},
        },
    }, i


def _parse_callout(lines: list[str], start: int) -> tuple[dict, int]:
    """Parse a callout block (> [!TYPE] content)."""
    first_line = lines[start].strip()
    match = re.match(r"^>\s*\[!(\w+)\]\s*(.*)", first_line, re.IGNORECASE)
    callout_type = match.group(1).upper() if match else "NOTE"
    emoji_map = {
        "NOTE": "💡", "TIP": "✅", "WARNING": "⚠️",
        "DANGER": "🔴", "CAUTION": "🟡", "INFO": "ℹ️",
    }
    emoji = emoji_map.get(callout_type, "💡")

    content_lines: list[str] = []
    # First line content after emoji
    first_content = match.group(2).strip() if match else ""
    if first_content:
        content_lines.append(first_content)

    i = start + 1
    while i < len(lines):
        line = lines[i]
        if not line.startswith(">"):
            break
        content_text = line.lstrip(">").strip()
        if content_text:
            content_lines.append(content_text)
        i += 1

    text = "\n".join(content_lines)

    return {
        "block_type": 23,  # callout
        "callout": {
            "text": {"elements": [_text_element(f"{emoji} {text}")]},
        },
    }, i


def _parse_table(lines: list[str], start: int) -> tuple[dict, int]:
    """Parse a markdown table (degraded to code block for complex cases)."""
    table_lines: list[str] = []
    i = start
    while i < len(lines) and "|" in lines[i]:
        table_lines.append(lines[i])
        i += 1

    # Simple approach: render as code block
    text = "\n".join(table_lines)
    return {
        "block_type": 14,
        "code": {
            "language": 1,
            "text": {"elements": [_text_element(text)]},
        },
    }, i


def _parse_unordered_list(lines: list[str], start: int) -> tuple[dict, int]:
    """Parse unordered list items."""
    items: list[dict] = []
    i = start
    while i < len(lines) and re.match(r"^\s*[-*+]\s+", lines[i]):
        text = re.sub(r"^\s*[-*+]\s+", "", lines[i])
        items.append({
            "block_type": 16,  # bullet
            "bullet": {
                "text": {"elements": _inline_elements(text)},
            },
        })
        i += 1

    return {
        "block_type": 15,  # unordered_list
        "unordered_list": {"items": items},
    }, i


def _parse_ordered_list(lines: list[str], start: int) -> tuple[dict, int]:
    """Parse ordered list items."""
    items: list[dict] = []
    i = start
    while i < len(lines) and re.match(r"^\s*\d+\.\s+", lines[i]):
        text = re.sub(r"^\s*\d+\.\s+", "", lines[i])
        items.append({
            "block_type": 17,  # ordered list item
            "ordered": {
                "text": {"elements": _inline_elements(text)},
            },
        })
        i += 1

    return {
        "block_type": 16,
        "ordered_list": {"items": items},
    }, i


def _heading_block(text: str, level: int) -> dict[str, Any]:
    """Build a heading block (H1=1, H2=2, ... H6=6)."""
    heading_types = {1: 3, 2: 4, 3: 5, 4: 6, 5: 7, 6: 8}
    return {
        "block_type": heading_types.get(level, 8),
        "heading" + str(level): {
            "text": {"elements": _inline_elements(text)},
        },
    }


def _paragraph_block(text: str) -> dict[str, Any]:
    """Build a paragraph block."""
    return {
        "block_type": 2,  # text
        "text": {
            "text": {"elements": _inline_elements(text)},
        },
    }


def _text_element(content: str) -> dict[str, Any]:
    """Build a simple text element."""
    return {"text_run": {"content": content}}


def _inline_elements(text: str) -> list[dict[str, Any]]:
    """Parse inline formatting (bold, italic, code, links)."""
    elements: list[dict[str, Any]] = []

    # Simple approach: handle bold, italic, code, links
    parts = re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[([^\]]+)\]\([^)]+\))", text)

    for part in parts:
        if not part:
            continue

        # Bold
        bold_match = re.match(r"^\*\*(.+)\*\*$", part)
        if bold_match:
            elements.append({
                "text_run": {
                    "content": bold_match.group(1),
                    "text_element_style": {"bold": True},
                }
            })
            continue

        # Italic
        italic_match = re.match(r"^\*([^*]+)\*$", part)
        if italic_match:
            elements.append({
                "text_run": {
                    "content": italic_match.group(1),
                    "text_element_style": {"italic": True},
                }
            })
            continue

        # Inline code
        code_match = re.match(r"^`([^`]+)`$", part)
        if code_match:
            elements.append({
                "text_run": {
                    "content": code_match.group(1),
                    "text_element_style": {"inline_code": True},
                }
            })
            continue

        # Regular text
        elements.append(_text_element(part))

    return elements or [_text_element(text)]
