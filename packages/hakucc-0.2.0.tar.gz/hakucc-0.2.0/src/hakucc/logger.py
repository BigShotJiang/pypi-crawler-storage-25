"""Rich-based colored logger for hakucc."""

from __future__ import annotations

from datetime import datetime

from rich.console import Console
from rich.theme import Theme

_theme = Theme(
    {
        "info": "cyan",
        "success": "green",
        "warn": "yellow",
        "error": "red bold",
        "tool": "magenta",
        "msg": "blue",
        "reply": "green",
        "dim": "dim",
    }
)

_console = Console(theme=_theme)


def _ts() -> str:
    return f"[dim]{datetime.now().strftime('%H:%M:%S')}[/dim]"


def info(msg: str) -> None:
    _console.print(f"{_ts()} [info]{msg}[/info]")


def success(msg: str) -> None:
    _console.print(f"{_ts()} [success]{msg}[/success]")


def warn(msg: str) -> None:
    _console.print(f"{_ts()} [warn]{msg}[/warn]")


def error(msg: str) -> None:
    _console.print(f"{_ts()} [error]{msg}[/error]")


def tool(msg: str) -> None:
    _console.print(f"{_ts()} [tool]{msg}[/tool]")


def msg(msg: str) -> None:
    text = msg[:60] + "…" if len(msg) > 60 else msg
    _console.print(f"{_ts()} [msg]{text}[/msg]")


def reply(msg: str) -> None:
    _console.print(f"{_ts()} [reply]{msg}[/reply]")


def dim(msg: str) -> None:
    _console.print(f"{_ts()} [dim]{msg}[/dim]")
