"""TOML configuration loading and merging for hakucc."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

import tomli_w

from . import logger

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class FeishuConfig:
    app_id: str = ""
    app_secret: str = ""
    owner_open_id: str = ""
    # domain auto-detected from app_id prefix


@dataclass
class AgentConfig:
    permission_mode: str = "acceptEdits"
    allowed_tools: list[str] = field(
        default_factory=lambda: ["Read", "Write", "Edit", "Bash", "Glob", "Grep"]
    )
    disallowed_tools: list[str] = field(default_factory=list)
    model: str | None = None
    thinking: dict[str, Any] | None = None
    effort: str | None = None


@dataclass
class OverflowDocumentConfig:
    threshold: int = 8000
    title_template: str = "{date} {profile} - {cwd}"
    cleanup_max_docs: int = 50


@dataclass
class OverflowConfig:
    mode: str = "document"  # chunk | document
    threshold: int = 8000
    max_tables_per_card: int = 5
    document: OverflowDocumentConfig = field(default_factory=OverflowDocumentConfig)


@dataclass
class StreamingConfig:
    enabled: bool = True
    mode: str = "cardkit"  # cardkit | update | none
    flush_interval_ms: int = 300
    thinking_enabled: bool = True
    fallback_on_error: bool = True


@dataclass
class CardConfig:
    title: str = "Claude"
    header_icon_img_key: str = ""
    max_tables_per_card: int = 5


@dataclass
class ReactionConfig:
    processing: str = "Typing"
    done: str = "DONE"
    error: str = "OnIt"
    timeout: str = "Clock"
    aborted: str = "OnIt"


@dataclass
class FileConfig:
    enabled: bool = True
    size_limit: int = 30 * 1024 * 1024  # 30MB
    temp_dir: str = ""
    prompt: str = "Please analyze this file: {filename} ({size}, {mime_type})"
    multifile_prompt: str = (
        "I'm providing multiple files for analysis. "
        "Here are the files:\n{files}\n\nAdditional context: {text}"
    )
    multifile_timeout: int = 300


@dataclass
class FormatConfig:
    guide_enabled: bool = True
    image_resolver_enabled: bool = True
    image_prompt: str = "Analyze the image and respond"


@dataclass
class ChannelPolicyConfig:
    dm_policy: str = "open"          # open | allowlist | disabled
    group_policy: str = "open"       # open | allowlist | admin_only | disabled
    require_mention: bool = True
    admins: list[str] = field(default_factory=list)
    allow_from: list[str] = field(default_factory=list)


@dataclass
class ChannelConfig:
    policy: ChannelPolicyConfig = field(default_factory=ChannelPolicyConfig)
    dedup_ttl_seconds: int = 43200   # 12 hours
    dedup_max_entries: int = 5000
    stale_message_window_ms: int = 30 * 60 * 1000  # 30 minutes


@dataclass
class ExecSecurityConfig:
    enabled: bool = True
    blacklist: list[str] = field(
        default_factory=lambda: [
            "rm -rf /",
            "rm -rf ~",
            "sudo",
            "mkfs",
            "dd if=",
            "chmod 777",
            "shutdown",
            "reboot",
            ":(){ :|:& }",
        ]
    )
    confirm_on_warning: bool = True


@dataclass
class ProfileConfig:
    feishu: FeishuConfig = field(default_factory=FeishuConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    overflow: OverflowConfig = field(default_factory=OverflowConfig)
    streaming: StreamingConfig = field(default_factory=StreamingConfig)
    card: CardConfig = field(default_factory=CardConfig)
    reaction: ReactionConfig = field(default_factory=ReactionConfig)
    file: FileConfig = field(default_factory=FileConfig)
    format: FormatConfig = field(default_factory=FormatConfig)
    channel: ChannelConfig = field(default_factory=ChannelConfig)
    exec_security: ExecSecurityConfig = field(default_factory=ExecSecurityConfig)
    commands: dict[str, str] = field(default_factory=dict)
    exec_commands: dict[str, str] = field(default_factory=dict)
    processing_timeout_ms: int = 3_600_000  # 1 hour


@dataclass
class Config(ProfileConfig):
    """Full configuration with profile support."""

    profiles: dict[str, ProfileConfig] = field(default_factory=dict)

    def resolve(self, profile: str | None = None) -> ResolvedConfig:
        """Resolve to a flat config for a specific profile."""
        base = self
        if profile and profile in self.profiles:
            overlay = self.profiles[profile]
            return _merge_profile(base, overlay, profile)
        return _to_resolved(base, profile or "default")


# ---------------------------------------------------------------------------
# Resolved (flat) config — what the rest of the app uses
# ---------------------------------------------------------------------------


@dataclass
class ResolvedConfig:
    profile: str
    feishu: FeishuConfig
    agent: AgentConfig
    overflow: OverflowConfig
    streaming: StreamingConfig
    card: CardConfig
    reaction: ReactionConfig
    file: FileConfig
    format: FormatConfig
    channel: ChannelConfig
    exec_security: ExecSecurityConfig
    commands: dict[str, str]
    exec_commands: dict[str, str]
    processing_timeout_ms: int

    @property
    def data_dir(self) -> Path:
        return Path.home() / ".hakucc"

    @property
    def state_file(self) -> Path:
        return self.data_dir / f"state-{self.profile}.json"

    @property
    def lock_file(self) -> Path:
        return self.data_dir / f"lock-{self.profile}.json"

    @property
    def doc_registry_file(self) -> Path:
        return self.data_dir / f"doc-registry-{self.profile}.json"

    @property
    def temp_dir(self) -> Path:
        d = self.data_dir / "temp" / self.profile
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def feishu_domain(self) -> str:
        """Auto-detect Feishu domain from app_id prefix."""
        if self.feishu.app_id.startswith("cli_a"):
            return "https://open.feishu.cn"
        return "https://open.larksuite.com"


# ---------------------------------------------------------------------------
# Merging helpers
# ---------------------------------------------------------------------------


def _merge_profile(base: Config, overlay: ProfileConfig, name: str) -> ResolvedConfig:
    """Merge profile overlay onto base config."""
    feishu = FeishuConfig(
        app_id=overlay.feishu.app_id or base.feishu.app_id,
        app_secret=overlay.feishu.app_secret or base.feishu.app_secret,
        owner_open_id=overlay.feishu.owner_open_id or base.feishu.owner_open_id,
    )
    agent = AgentConfig(
        permission_mode=overlay.agent.permission_mode or base.agent.permission_mode,
        allowed_tools=overlay.agent.allowed_tools or base.agent.allowed_tools,
        disallowed_tools=overlay.agent.disallowed_tools or base.agent.disallowed_tools,
        model=overlay.agent.model or base.agent.model,
        thinking=overlay.agent.thinking or base.agent.thinking,
        effort=overlay.agent.effort or base.agent.effort,
    )
    return ResolvedConfig(
        profile=name,
        feishu=feishu,
        agent=agent,
        overflow=overlay.overflow or base.overflow,
        streaming=overlay.streaming or base.streaming,
        card=overlay.card or base.card,
        reaction=overlay.reaction or base.reaction,
        file=overlay.file or base.file,
        format=overlay.format or base.format,
        channel=overlay.channel or base.channel,
        exec_security=overlay.exec_security or base.exec_security,
        commands={**base.commands, **overlay.commands},
        exec_commands={**base.exec_commands, **overlay.exec_commands},
        processing_timeout_ms=overlay.processing_timeout_ms or base.processing_timeout_ms,
    )


def _to_resolved(cfg: ProfileConfig, name: str) -> ResolvedConfig:
    return ResolvedConfig(
        profile=name,
        feishu=cfg.feishu,
        agent=cfg.agent,
        overflow=cfg.overflow,
        streaming=cfg.streaming,
        card=cfg.card,
        reaction=cfg.reaction,
        file=cfg.file,
        format=cfg.format,
        channel=cfg.channel,
        exec_security=cfg.exec_security,
        commands=cfg.commands,
        exec_commands=cfg.exec_commands,
        processing_timeout_ms=cfg.processing_timeout_ms,
    )


# ---------------------------------------------------------------------------
# TOML parsing
# ---------------------------------------------------------------------------


def _parse_feishu(d: dict[str, Any]) -> FeishuConfig:
    return FeishuConfig(
        app_id=d.get("app_id", ""),
        app_secret=d.get("app_secret", ""),
        owner_open_id=d.get("owner_open_id", ""),
    )


def _parse_agent(d: dict[str, Any]) -> AgentConfig:
    return AgentConfig(
        permission_mode=d.get("permission_mode", "acceptEdits"),
        allowed_tools=d.get("allowed_tools", ["Read", "Write", "Edit", "Bash", "Glob", "Grep"]),
        disallowed_tools=d.get("disallowed_tools", []),
        model=d.get("model"),
        thinking=d.get("thinking"),
        effort=d.get("effort"),
    )


def _parse_overflow(d: dict[str, Any]) -> OverflowConfig:
    doc_d = d.get("document", {})
    return OverflowConfig(
        mode=d.get("mode", "document"),
        threshold=d.get("threshold", 8000),
        max_tables_per_card=d.get("max_tables_per_card", 5),
        document=OverflowDocumentConfig(
            threshold=doc_d.get("threshold", 8000),
            title_template=doc_d.get("title_template", "{date} {profile} - {cwd}"),
            cleanup_max_docs=doc_d.get("cleanup_max_docs", 50),
        ),
    )


def _parse_streaming(d: dict[str, Any]) -> StreamingConfig:
    return StreamingConfig(
        enabled=d.get("enabled", True),
        mode=d.get("mode", "cardkit"),
        flush_interval_ms=d.get("flush_interval_ms", 300),
        thinking_enabled=d.get("thinking_enabled", True),
        fallback_on_error=d.get("fallback_on_error", True),
    )


def _parse_card(d: dict[str, Any]) -> CardConfig:
    return CardConfig(
        title=d.get("title", "Claude"),
        header_icon_img_key=d.get("header_icon_img_key", ""),
        max_tables_per_card=d.get("max_tables_per_card", 5),
    )


def _parse_reaction(d: dict[str, Any]) -> ReactionConfig:
    return ReactionConfig(
        processing=d.get("processing", "Typing"),
        done=d.get("done", "DONE"),
        error=d.get("error", "OnIt"),
        timeout=d.get("timeout", "Clock"),
        aborted=d.get("aborted", "OnIt"),
    )


def _parse_file(d: dict[str, Any]) -> FileConfig:
    return FileConfig(
        enabled=d.get("enabled", True),
        size_limit=d.get("size_limit", 30 * 1024 * 1024),
        temp_dir=d.get("temp_dir", ""),
        prompt=d.get(
            "prompt", "Please analyze this file: {filename} ({size}, {mime_type})"
        ),
        multifile_prompt=d.get(
            "multifile_prompt",
            "I'm providing multiple files for analysis. "
            "Here are the files:\n{files}\n\nAdditional context: {text}",
        ),
        multifile_timeout=d.get("multifile_timeout", 300),
    )


def _parse_format(d: dict[str, Any]) -> FormatConfig:
    return FormatConfig(
        guide_enabled=d.get("guide_enabled", True),
        image_resolver_enabled=d.get("image_resolver_enabled", True),
        image_prompt=d.get("image_prompt", "Analyze the image and respond"),
    )


def _parse_channel(d: dict[str, Any]) -> ChannelConfig:
    policy_d = d.get("policy", {})
    return ChannelConfig(
        policy=ChannelPolicyConfig(
            dm_policy=policy_d.get("dm_policy", "open"),
            group_policy=policy_d.get("group_policy", "open"),
            require_mention=policy_d.get("require_mention", True),
            admins=policy_d.get("admins", []),
            allow_from=policy_d.get("allow_from", []),
        ),
        dedup_ttl_seconds=d.get("dedup_ttl_seconds", 43200),
        dedup_max_entries=d.get("dedup_max_entries", 5000),
        stale_message_window_ms=d.get("stale_message_window_ms", 30 * 60 * 1000),
    )


def _parse_exec_security(d: dict[str, Any]) -> ExecSecurityConfig:
    return ExecSecurityConfig(
        enabled=d.get("enabled", True),
        blacklist=d.get(
            "blacklist",
            [
                "rm -rf /",
                "rm -rf ~",
                "sudo",
                "mkfs",
                "dd if=",
                "chmod 777",
                "shutdown",
                "reboot",
                ":(){ :|:& }",
            ],
        ),
        confirm_on_warning=d.get("confirm_on_warning", True),
    )


def _parse_profile(d: dict[str, Any]) -> ProfileConfig:
    return ProfileConfig(
        feishu=_parse_feishu(d.get("feishu", {})),
        agent=_parse_agent(d.get("agent", {})),
        overflow=_parse_overflow(d.get("overflow", {})),
        streaming=_parse_streaming(d.get("streaming", {})),
        card=_parse_card(d.get("card", {})),
        reaction=_parse_reaction(d.get("reaction", {})),
        file=_parse_file(d.get("file", {})),
        format=_parse_format(d.get("format", {})),
        channel=_parse_channel(d.get("channel", {})),
        exec_security=_parse_exec_security(d.get("exec_security", {})),
        commands=d.get("commands", {}),
        exec_commands=d.get("exec_commands", {}),
        processing_timeout_ms=d.get("processing_timeout_ms", 3_600_000),
    )


def _parse_config(d: dict[str, Any]) -> Config:
    profiles: dict[str, ProfileConfig] = {}
    for name, pd in d.get("profiles", {}).items():
        profiles[name] = _parse_profile(pd)

    return Config(
        feishu=_parse_feishu(d.get("feishu", {})),
        agent=_parse_agent(d.get("agent", {})),
        overflow=_parse_overflow(d.get("overflow", {})),
        streaming=_parse_streaming(d.get("streaming", {})),
        card=_parse_card(d.get("card", {})),
        reaction=_parse_reaction(d.get("reaction", {})),
        file=_parse_file(d.get("file", {})),
        format=_parse_format(d.get("format", {})),
        exec_security=_parse_exec_security(d.get("exec_security", {})),
        commands=d.get("commands", {}),
        exec_commands=d.get("exec_commands", {}),
        processing_timeout_ms=d.get("processing_timeout_ms", 3_600_000),
        profiles=profiles,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_GLOBAL_CONFIG = Path.home() / ".hakucc" / "config.toml"
_PROJECT_CONFIG = ".hakucc.toml"


def config_path() -> Path:
    return _GLOBAL_CONFIG


def config_exists() -> bool:
    return _GLOBAL_CONFIG.exists()


def load_config(profile: str | None = None) -> Config:
    """Load and merge configuration files."""
    # Start with global config
    d: dict[str, Any] = {}
    if _GLOBAL_CONFIG.exists():
        with open(_GLOBAL_CONFIG, "rb") as f:
            d = tomllib.load(f)

    # Layer project config (only non-feishu settings)
    project_file = Path(_PROJECT_CONFIG)
    if project_file.exists():
        with open(project_file, "rb") as f:
            proj = tomllib.load(f)
        # Project config can only override agent/format/streaming/overflow
        for key in ("agent", "overflow", "streaming", "card", "format", "file"):
            if key in proj:
                d.setdefault(key, {}).update(proj[key])
        if "commands" in proj:
            d.setdefault("commands", {}).update(proj["commands"])
        if "exec_commands" in proj:
            d.setdefault("exec_commands", {}).update(proj["exec_commands"])

    return _parse_config(d)


def save_config(cfg: Config) -> None:
    """Save config to ~/.hakucc/config.toml."""
    _GLOBAL_CONFIG.parent.mkdir(parents=True, exist_ok=True)

    d: dict[str, Any] = {
        "feishu": {
            "app_id": cfg.feishu.app_id,
            "app_secret": cfg.feishu.app_secret,
        },
    }
    if cfg.feishu.owner_open_id:
        d["feishu"]["owner_open_id"] = cfg.feishu.owner_open_id

    # Only save non-default values for agent
    if cfg.agent.permission_mode != "acceptEdits":
        d.setdefault("agent", {})["permission_mode"] = cfg.agent.permission_mode
    if cfg.agent.allowed_tools != ["Read", "Write", "Edit", "Bash", "Glob", "Grep"]:
        d.setdefault("agent", {})["allowed_tools"] = cfg.agent.allowed_tools
    if cfg.agent.model:
        d.setdefault("agent", {})["model"] = cfg.agent.model
    if cfg.agent.thinking:
        d.setdefault("agent", {})["thinking"] = cfg.agent.thinking
    if cfg.agent.effort:
        d.setdefault("agent", {})["effort"] = cfg.agent.effort

    # Save profiles
    for name, prof in cfg.profiles.items():
        pd: dict[str, Any] = {}
        if prof.feishu.app_id:
            pd.setdefault("feishu", {})["app_id"] = prof.feishu.app_id
        if prof.feishu.app_secret:
            pd.setdefault("feishu", {})["app_secret"] = prof.feishu.app_secret
        if prof.agent.permission_mode != "acceptEdits":
            pd.setdefault("agent", {})["permission_mode"] = prof.agent.permission_mode
        if pd:
            d.setdefault("profiles", {})[name] = pd

    with open(_GLOBAL_CONFIG, "wb") as f:
        tomli_w.dump(d, f)

    logger.success(f"Config saved to {_GLOBAL_CONFIG}")


def save_owner_open_id(profile: str, owner_open_id: str) -> None:
    """Append owner_open_id to config without full rewrite."""
    cfg = load_config()
    if profile == "default":
        cfg.feishu.owner_open_id = owner_open_id
    elif profile in cfg.profiles:
        cfg.profiles[profile].feishu.owner_open_id = owner_open_id
    save_config(cfg)


def list_profiles(cfg: Config) -> list[dict[str, str]]:
    """List all profiles with their info."""
    result = [{"name": "default", "app_id": cfg.feishu.app_id or "(empty)"}]
    for name, prof in cfg.profiles.items():
        result.append({"name": name, "app_id": prof.feishu.app_id or "(empty)"})
    return result
