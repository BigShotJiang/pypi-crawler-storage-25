"""hakucc — Claude Code ↔ Feishu bridge."""

__version__ = "0.2.0"
