"""Core bridge: orchestrates Feishu ↔ Claude Agent communication."""

from __future__ import annotations

import asyncio
import base64
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions
from claude_agent_sdk.types import (
    PermissionResultAllow,
    PermissionResultDeny,
    ToolPermissionContext,
    AssistantMessage,
    ResultMessage,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
    ServerToolUseBlock,
    UserMessage,
)
from lark_oapi.channel import (
    FeishuChannel,
    PolicyConfig,
    SafetyConfig,
    DedupConfig,
    SendOpts,
)
from lark_oapi.channel.types import InboundMessage, MediaSource

from . import logger
from . import commands  # noqa: F401 — register built-in commands
from .config import ResolvedConfig
from .session import SessionStore
from .lock import release_lock
from .feishu.document import DocClient, create_document_with_content
from .format.card import (
    build_header_tags,
    build_reply_card,
    build_tool_card,
)
from .format.image_resolver import resolve_external_images, has_external_images

# Tools that don't need card visualization
_SILENT_TOOLS = {"ExitPlanMode", "TodoWrite", "NotebookEdit", "CronCreate", "CronDelete", "CronList"}

# Tool name -> Chinese label mapping
_TOOL_LABELS: dict[str, str] = {
    "Read": "读取文件",
    "Write": "写入文件",
    "Edit": "编辑文件",
    "Bash": "执行命令",
    "Glob": "搜索文件",
    "Grep": "搜索内容",
    "Agent": "子任务",
    "WebSearch": "搜索网络",
    "mcp__web_reader__webReader": "读取网页",
    "AskUserQuestion": "用户确认",
}


def _tool_label(name: str) -> str:
    return _TOOL_LABELS.get(name, name)


def _tool_detail(name: str, inp: dict[str, Any]) -> str:
    """Format tool input for display."""
    if name == "Read":
        return inp.get("file_path", "")
    if name == "Write":
        return inp.get("file_path", "")
    if name == "Edit":
        return inp.get("file_path", "")
    if name == "Bash":
        cmd = inp.get("command", "")
        return cmd[:120] + "..." if len(cmd) > 120 else cmd
    if name == "Glob":
        return inp.get("pattern", "")
    if name == "Grep":
        return inp.get("pattern", "")
    return json.dumps(inp, ensure_ascii=False)[:120]


def _detect_image_mime(data: bytes) -> str:
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return "image/jpeg"


@dataclass
class EventAccumulator:
    """Accumulates text and thinking from agent events."""

    text: str = ""
    thinking: str = ""
    stream_text: str = ""
    tool_count: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    duration_ms: int = 0
    cost_usd: float = 0.0
    model: str | None = None
    _start_time: float = field(default_factory=time.time)

    def accumulate_text(self, text: str) -> None:
        self.text += text

    def accumulate_thinking(self, thinking: str) -> None:
        self.thinking += thinking

    def accumulate_stream(self, text: str) -> None:
        self.stream_text += text

    def increment_tool_count(self) -> None:
        self.tool_count += 1

    def set_usage(self, usage: Any, cost: float | None, duration_ms: int | None) -> None:
        if usage:
            if isinstance(usage, dict):
                self.input_tokens = usage.get("input_tokens", 0) or 0
                self.output_tokens = usage.get("output_tokens", 0) or 0
            else:
                self.input_tokens = getattr(usage, "input_tokens", 0) or 0
                self.output_tokens = getattr(usage, "output_tokens", 0) or 0
        if cost is not None:
            self.cost_usd = cost
        if duration_ms is not None:
            self.duration_ms = duration_ms
        else:
            self.duration_ms = int((time.time() - self._start_time) * 1000)

    @property
    def full_text(self) -> str:
        return self.stream_text or self.text

    def reset(self) -> None:
        self.text = ""
        self.thinking = ""
        self.stream_text = ""
        self.tool_count = 0
        self.input_tokens = 0
        self.output_tokens = 0
        self.duration_ms = 0
        self.cost_usd = 0.0
        self.model = None
        self._start_time = time.time()


class Bridge:
    """Core orchestrator connecting FeishuChannel messages with Claude Agent."""

    def __init__(self, config: ResolvedConfig, profile: str):
        self.config = config
        self.profile = profile
        self.channel: FeishuChannel | None = None
        self.agent: ClaudeSDKClient | None = None
        self.session: SessionStore | None = None

        self._processing = False
        self._events = EventAccumulator()
        self._tool_cards: dict[str, str] = {}  # tool_use_id -> message_id
        self._format_guide: str = ""

        # Reaction tracking
        self._reaction_id: str | None = None
        self._reaction_msg_id: str | None = None

    async def start(
        self,
        cwd: str,
        continue_session: bool = False,
        force: bool = False,
        shutdown_event: asyncio.Event | None = None,
    ) -> None:
        """Initialize and start the bridge."""
        self._shutdown_event = shutdown_event
        self._cwd = cwd
        logger.info(f"Starting hakucc bridge (profile={self.profile}, cwd={cwd})")

        # Init session
        self.session = SessionStore(self.config.state_file)
        self.session.load()

        # Load format guide
        self._format_guide = self._load_format_guide()

        # Build FeishuChannel
        cfg = self.config
        ch_cfg = cfg.channel

        # Map owner_open_id -> policy admins if not explicitly set
        admins = ch_cfg.policy.admins
        if not admins and cfg.feishu.owner_open_id:
            admins = [cfg.feishu.owner_open_id]

        self.channel = FeishuChannel(
            app_id=cfg.feishu.app_id,
            app_secret=cfg.feishu.app_secret,
            domain=cfg.feishu_domain,
            policy=PolicyConfig(
                dm_policy=ch_cfg.policy.dm_policy,
                group_policy=ch_cfg.policy.group_policy,
                require_mention=ch_cfg.policy.require_mention,
                admins=admins or None,
                allow_from=ch_cfg.policy.allow_from or None,
            ),
            safety=SafetyConfig(
                dedup=DedupConfig(
                    ttl_seconds=ch_cfg.dedup_ttl_seconds,
                    max_entries=ch_cfg.dedup_max_entries,
                ),
                stale_message_window_ms=ch_cfg.stale_message_window_ms,
            ),
        )

        # Register message handler
        self.channel.on("message", self._on_message)

        # Connect (starts WS in background thread)
        logger.success("hakucc bridge ready, connecting to Feishu WS...")
        await self.channel.connect()

        # Send startup notification
        chat_id = self.session.chat_id if self.session else None
        if chat_id:
            session_note = "（续接上次对话）" if continue_session else "（新会话）"
            profile_label = f" [{self.profile}]" if self.profile != "default" else ""
            try:
                await self.channel.send(
                    chat_id,
                    {"text": f"✅ hakucc 已连接{profile_label} {session_note}\n📁 当前项目：`{cwd}`"},
                )
                logger.success("Startup notification sent")
            except Exception as e:
                logger.error(f"Startup notification failed: {e}")
        else:
            logger.dim("No chat_id yet — send any message to the bot first")

        # Wait for shutdown signal
        if self._shutdown_event:
            await self._shutdown_event.wait()
            await self.shutdown()

    async def shutdown(self) -> None:
        """Graceful shutdown with timeout protection."""
        logger.info("Shutting down bridge...")

        # Disconnect notification (3s timeout)
        chat_id = self.session.chat_id if self.session else None
        if chat_id and self.channel:
            profile_label = f" [{self.profile}]" if self.profile != "default" else ""
            cwd = getattr(self, "_cwd", "?")
            try:
                async with asyncio.timeout(3):
                    await self.channel.send(
                        chat_id,
                        {"text": f"👋 hakucc 已断开{profile_label}\n📁 项目：`{cwd}`"},
                    )
                    logger.info("Disconnect notification sent")
            except Exception as e:
                logger.warn(f"Disconnect notification failed: {e}")

        # Agent disconnect
        if self.agent:
            try:
                async with asyncio.timeout(5):
                    await self.agent.disconnect()
            except Exception:
                pass
            self.agent = None

        # Channel disconnect
        if self.channel:
            try:
                async with asyncio.timeout(5):
                    await self.channel.disconnect()
            except Exception:
                pass

        release_lock(self.config.lock_file)
        logger.success("Bridge shutdown complete")

    # --- FeishuChannel message handler ---

    async def _on_message(self, msg: InboundMessage) -> None:
        """Handle a normalized inbound message from FeishuChannel.

        FeishuChannel already handles: dedup, stale filter, bot-self filter,
        group @mention detection, owner/admin policy check, chat queue.
        """
        try:
            # Auto-detect owner (first sender)
            if self.session and not self.session.owner_open_id:
                self.session.owner_open_id = msg.sender.open_id
                self.session.save()

            # Concurrent request protection
            if self._processing:
                elapsed = time.time() - self._events._start_time
                await self.channel.send(
                    msg.chat_id,
                    {"text": f"Processing... ({elapsed:.0f}s elapsed). Please wait."},
                    SendOpts(reply_to=msg.id),
                )
                return

            # Extract content
            text, images, files = await self._extract_content(msg)
            if not text and not images and not files:
                return

            # Check for commands
            if text:
                cmd_result = await self._try_command(text, msg.id, msg.chat_id)
                if cmd_result:
                    return

            # Save chat_id for startup notification
            if self.session and not self.session.chat_id:
                self.session.chat_id = msg.chat_id
                self.session.save()

            logger.msg(text or "(file/image)")
            await self._handle_turn(text, images, files, msg.id, msg.chat_id)

        except Exception as e:
            logger.error(f"Message handling error: {e}")
            import traceback
            traceback.print_exc()

    async def _extract_content(
        self, msg: InboundMessage
    ) -> tuple[str, list[dict], list[dict]]:
        """Extract text, images, and files from a normalized InboundMessage."""
        text = msg.content_text  # Always available, flat-text rendering
        images: list[dict] = []
        files: list[dict] = []

        for res in msg.resources:
            if res.type == "image":
                data = await self.channel.download_resource(res.file_key, "image", msg.id)
                if data:
                    images.append({
                        "base64": base64.b64encode(data).decode("ascii"),
                        "media_type": _detect_image_mime(data),
                    })

            elif res.type == "file":
                filename = res.file_name or "unnamed"
                try:
                    path = await self.channel.download_resource_to_file(
                        res.file_key,
                        resource_type="file",
                        message_id=msg.id,
                        dest_dir=self.config.temp_dir,
                        file_name=filename,
                    )
                    p = Path(path)
                    files.append({
                        "filepath": str(p),
                        "filename": filename,
                        "size": p.stat().st_size,
                        "mime_type": "application/octet-stream",
                    })
                except Exception as e:
                    logger.error(f"File download failed: {e}")

        return text.strip(), images, files

    # --- Agent interaction ---

    async def _handle_turn(
        self,
        text: str,
        images: list[dict],
        files: list[dict],
        message_id: str,
        chat_id: str,
    ) -> None:
        """Execute one conversation turn."""
        self._processing = True
        self._events.reset()
        self._message_id = message_id
        self._chat_id = chat_id

        timeout_seconds = self.config.processing_timeout_ms / 1000

        try:
            # Set reaction
            await self._set_reaction(message_id, self.config.reaction.processing)

            # Connect agent if needed
            if self.agent is None:
                await self._connect_agent()

            # Build prompt content
            prompt = self._build_prompt(text, images, files)

            # Streaming mode
            if self.config.streaming.enabled:
                stream_ctrl = None

                async def _producer(ctrl):
                    nonlocal stream_ctrl
                    stream_ctrl = ctrl
                    await self.agent.query(prompt)
                    async for message in self.agent.receive_response():
                        await self._on_agent_message(message, ctrl)

                async with asyncio.timeout(timeout_seconds):
                    await self.channel.stream(
                        chat_id,
                        {"markdown": _producer},
                        SendOpts(reply_to=message_id),
                    )
            else:
                # Non-streaming mode
                async with asyncio.timeout(timeout_seconds):
                    await self.agent.query(prompt)
                    async for message in self.agent.receive_response():
                        await self._on_agent_message(message)

                await self._finalize_response(message_id, chat_id)

        except asyncio.TimeoutError:
            logger.warn(f"Turn timed out after {timeout_seconds}s")
            if self.agent:
                try:
                    await self.agent.interrupt()
                except Exception:
                    pass
            if self.channel:
                await self.channel.send(
                    chat_id,
                    {"text": f"⏰ Processing timed out ({timeout_seconds:.0f}s)"},
                    SendOpts(reply_to=message_id),
                )

        except asyncio.CancelledError:
            logger.warn("Turn cancelled")
            if self.agent:
                try:
                    await self.agent.interrupt()
                except Exception:
                    pass
            return

        except Exception as e:
            logger.error(f"Turn error: {e}")
            import traceback
            traceback.print_exc()
            if self.channel:
                try:
                    await self.channel.send(
                        chat_id,
                        {"text": f"Error: {str(e)[:500]}"},
                        SendOpts(reply_to=message_id),
                    )
                except Exception:
                    pass
            return

        finally:
            self._processing = False
            await self._clear_reaction()
            await self._set_reaction(message_id, self.config.reaction.done)

    async def _connect_agent(self) -> None:
        """Create and connect the Claude Agent SDK client."""
        system_prompt: dict[str, Any] = {
            "type": "preset",
            "preset": "claude_code",
        }
        if self._format_guide:
            system_prompt["append"] = self._format_guide

        options = ClaudeAgentOptions(
            system_prompt=system_prompt,
            permission_mode=self.config.agent.permission_mode,
            allowed_tools=self.config.agent.allowed_tools,
            disallowed_tools=self.config.agent.disallowed_tools or None,
            model=self.config.agent.model,
            cwd=self._cwd,
            resume=self.session.session_id if self.session and self.session.has_session() else None,
            include_partial_messages=True,
            can_use_tool=self._auto_approve,
            thinking=self.config.agent.thinking,
            effort=self.config.agent.effort,
            max_turns=200,
        )

        self.agent = ClaudeSDKClient(options)
        await self.agent.connect()
        logger.success("Claude Agent connected")

    async def _auto_approve(
        self, tool_name: str, input_data: dict[str, Any], context: ToolPermissionContext
    ) -> PermissionResultAllow | PermissionResultDeny:
        """Auto-approve tools based on config."""
        if tool_name in self.config.agent.allowed_tools:
            return PermissionResultAllow()

        if tool_name == "Bash" and self.config.exec_security.enabled:
            cmd = input_data.get("command", "")
            for pattern in self.config.exec_security.blacklist:
                if pattern in cmd:
                    return PermissionResultDeny(
                        message=f"Blocked: command matches security blacklist pattern '{pattern}'"
                    )

        return PermissionResultAllow()

    def _build_prompt(
        self, text: str, images: list[dict], files: list[dict]
    ) -> str | list[dict]:
        """Build the prompt content for the agent."""
        if not images and not files:
            return text

        blocks: list[dict[str, Any]] = []

        if text:
            blocks.append({"type": "text", "text": text})

        for img in images:
            blocks.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": img["media_type"],
                    "data": img["base64"],
                },
            })

        for f in files:
            prompt_template = self.config.file.prompt
            file_prompt = prompt_template.format(
                filename=f["filename"],
                size=f"{f['size']} bytes",
                mime_type=f.get("mime_type", "unknown"),
            )
            blocks.append({"type": "text", "text": file_prompt})

            if f.get("mime_type", "").startswith("text/"):
                try:
                    content = Path(f["filepath"]).read_text(encoding="utf-8", errors="replace")
                    blocks.append({"type": "text", "text": f"```\n{content}\n```"})
                except Exception:
                    pass

        return blocks

    async def _on_agent_message(self, message: Any, stream_ctrl=None) -> None:
        """Dispatch SDK messages to appropriate handlers."""
        if isinstance(message, AssistantMessage):
            await self._handle_assistant_message(message, stream_ctrl)
        elif isinstance(message, UserMessage):
            pass
        elif isinstance(message, ResultMessage):
            await self._handle_result_message(message)

    async def _handle_assistant_message(self, msg: AssistantMessage, stream_ctrl=None) -> None:
        """Handle an AssistantMessage from the SDK."""
        if msg.model:
            self._events.model = msg.model
        for block in msg.content:
            if isinstance(block, TextBlock):
                self._events.accumulate_text(block.text)
                if stream_ctrl:
                    self._events.accumulate_stream(block.text)
                    await stream_ctrl.append(block.text)
            elif isinstance(block, ThinkingBlock):
                self._events.accumulate_thinking(block.thinking)
            elif isinstance(block, ToolUseBlock):
                if block.name not in _SILENT_TOOLS:
                    await self._show_tool_start(block)

    async def _handle_result_message(self, msg: ResultMessage) -> None:
        """Handle the final ResultMessage."""
        if self.session and msg.session_id:
            self.session.session_id = msg.session_id
            self.session.save()

        self._events.set_usage(msg.usage, msg.total_cost_usd, msg.duration_ms)

    async def _show_tool_start(self, block: ToolUseBlock) -> None:
        """Show a tool execution card."""
        if not self.channel:
            return

        self._events.increment_tool_count()
        label = _tool_label(block.name)
        detail = _tool_detail(block.name, block.input)

        card = build_tool_card(label=label, detail=detail, status="running", tool_name=block.name)
        result = await self.channel.send(
            self._chat_id,
            {"card": card},
            SendOpts(reply_to=self._message_id),
        )
        if result.success and result.message_id:
            self._tool_cards[block.id] = result.message_id

    async def _finalize_response(self, message_id: str, chat_id: str) -> None:
        """Format and send the final response (non-streaming mode)."""
        text = self._events.full_text
        if not text.strip():
            return

        # Resolve external images
        if has_external_images(text) and self.config.format.image_resolver_enabled:
            text = await resolve_external_images(self.channel, text)

        # Check overflow
        overflow_config = self.config.overflow
        needs_overflow = len(text) > overflow_config.threshold

        # Build header tags
        tags = build_header_tags(
            model=self._events.model,
            input_tokens=self._events.input_tokens,
            output_tokens=self._events.output_tokens,
            duration_ms=self._events.duration_ms,
            tool_count=self._events.tool_count,
        )

        thinking = self._events.thinking if self._events.thinking else None
        stats = {
            "input_tokens": self._events.input_tokens,
            "output_tokens": self._events.output_tokens,
            "tool_count": self._events.tool_count,
            "duration_ms": self._events.duration_ms,
        }

        if needs_overflow and overflow_config.mode == "document":
            await self._send_overflow_document(text, message_id, chat_id, tags, thinking, stats)
        else:
            card = build_reply_card(
                markdown=text,
                title=self.config.card.title,
                header_icon_img_key=self.config.card.header_icon_img_key,
                template="green" if not thinking else "blue",
                tags=tags,
                thinking=thinking,
                stats=stats,
            )
            await self.channel.send(chat_id, {"card": card}, SendOpts(reply_to=message_id))

    async def _send_overflow_document(
        self,
        text: str,
        message_id: str,
        chat_id: str,
        tags: list[dict],
        thinking: str | None,
        stats: dict,
    ) -> None:
        """Send overflow content as a cloud document."""
        doc_client = DocClient(
            app_id=self.config.feishu.app_id,
            app_secret=self.config.feishu.app_secret,
            domain=self.config.feishu_domain,
        )
        doc_url = await create_document_with_content(
            doc_client, self.config, text, self.profile, self._cwd,
        )

        if doc_url:
            doc_card = f"📝 内容较长，已写入云文档：{doc_url}"
            card = build_reply_card(
                markdown=doc_card,
                title=self.config.card.title,
                header_icon_img_key=self.config.card.header_icon_img_key,
                template="green",
                tags=tags,
                thinking=thinking,
                stats=stats,
            )
        else:
            card = build_reply_card(
                markdown=text,
                title=self.config.card.title,
                header_icon_img_key=self.config.card.header_icon_img_key,
                template="green",
                tags=tags,
                thinking=thinking,
                stats=stats,
            )

        await self.channel.send(chat_id, {"card": card}, SendOpts(reply_to=message_id))

    # --- Reaction helpers ---

    async def _set_reaction(self, message_id: str, emoji: str) -> None:
        """Add a reaction emoji to a message."""
        if not self.channel:
            return
        try:
            self._reaction_msg_id = message_id
            result = await self.channel.add_reaction(message_id, emoji)
            raw = getattr(result, "raw", None) or {}
            data = raw.get("data", {}) if isinstance(raw, dict) else {}
            self._reaction_id = data.get("reaction_id")
        except Exception:
            self._reaction_id = None

    async def _clear_reaction(self) -> None:
        """Remove the current reaction."""
        if self._reaction_id and self._reaction_msg_id and self.channel:
            try:
                await self.channel.remove_reaction(self._reaction_msg_id, self._reaction_id)
            except Exception:
                pass
            self._reaction_id = None

    # --- Command handling ---

    async def _try_command(self, text: str, message_id: str, chat_id: str) -> bool:
        """Try to handle as a command. Returns True if handled."""
        if not text.startswith("/"):
            return False

        parts = text.split(None, 1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        from .commands.registry import match_command
        result = match_command(cmd, args, self.config, self)
        if result is not None:
            response = await result
            if response and self.channel:
                card = build_reply_card(
                    markdown=response,
                    title=self.config.card.title,
                    header_icon_img_key=self.config.card.header_icon_img_key,
                )
                await self.channel.send(chat_id, {"card": card}, SendOpts(reply_to=message_id))
            return True
        return False

    # --- Format guide ---

    def _load_format_guide(self) -> str:
        """Load the format guide (user > built-in)."""
        guide_path = Path.home() / ".hakucc" / "format-guide.md"
        if guide_path.exists():
            return guide_path.read_text(encoding="utf-8")
        return _BUILTIN_FORMAT_GUIDE

    # --- Utility ---

    async def send_message(self, text: str) -> None:
        """Send a message to the current chat."""
        if self.channel and self.session and self.session.chat_id:
            await self.channel.send(self.session.chat_id, {"text": text})


# Built-in format guide (Feishu-specific Markdown rules)
_BUILTIN_FORMAT_GUIDE = """# 飞书格式规范

你的回复会通过飞书展示。短内容显示为交互式卡片，长内容写入飞书云文档。

## 通用规则

### 代码块
- 必须标注语言：```typescript、```python、```bash 等
- 不要使用无语言标记的代码块

### 表格
- 列数不超过 5 列
- 单元格内容尽量简短

### 不要使用
- 外部图片链接 ![alt](https://...)
- HTML 标签
- 脚注 [^1]
- 折叠 <details>

## 卡片规则（短内容）

- 标题只用 #### (H4) 和 ##### (H5)
- 不要使用 # ## ###
- 不支持 $$ 数学公式
- 不支持嵌套列表

## 文档规则（长内容）

- Callout 语法：> [!NOTE]、> [!TIP]、> [!WARNING]、> [!DANGER]
- 代码块标注语言
- 标题使用 H1-H6
"""
