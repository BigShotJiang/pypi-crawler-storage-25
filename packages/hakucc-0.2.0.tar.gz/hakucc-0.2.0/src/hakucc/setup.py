"""Interactive configuration wizard for hakucc."""

from __future__ import annotations

import re
from getpass import getpass

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm

from . import logger
from .config import (
    Config,
    FeishuConfig,
    AgentConfig,
    save_config,
    config_exists,
    load_config,
)


console = Console()


def _validate_app_id(value: str) -> bool:
    """Validate Feishu app_id format."""
    return bool(re.match(r"^cli_[0-9a-z]+$", value.strip()))


def _detect_domain(app_id: str) -> str:
    """Detect domain from app_id prefix."""
    if app_id.startswith("cli_a"):
        return "Feishu (feishu.cn)"
    return "Lark Suite (larksuite.com)"


async def _test_connection(app_id: str, app_secret: str) -> bool:
    """Test Feishu API connection."""
    try:
        import httpx

        domain = "https://open.feishu.cn" if app_id.startswith("cli_a") else "https://open.larksuite.com"
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                f"{domain}/open-apis/auth/v3/tenant_access_token/internal",
                json={"app_id": app_id, "app_secret": app_secret},
            )
            data = resp.json()
            if data.get("code") == 0:
                logger.success("Connection test passed!")
                return True
            else:
                logger.error(f"Connection failed: {data.get('msg', 'Unknown error')}")
                return False
    except Exception as e:
        logger.error(f"Connection test failed: {e}")
        return False


async def run_setup(profile: str | None = None) -> Config:
    """Run the interactive setup wizard."""
    is_new_profile = profile is not None
    profile_display = profile or "default"

    console.print()
    console.print(Panel(
        f"hakucc Setup Wizard — [bold]{profile_display}[/bold] profile",
        style="bold cyan",
    ))
    console.print()

    # Load existing config if any
    cfg: Config
    if config_exists():
        cfg = load_config()
        if is_new_profile and profile in cfg.profiles:
            console.print(f"[yellow]Profile '{profile}' already exists. Updating.[/yellow]")
    else:
        cfg = Config()
        console.print("[dim]No existing config found. Creating new one.[/dim]")

    # --- Feishu credentials ---
    console.print("\n[bold]Step 1: Feishu App Credentials[/bold]")
    console.print("[dim]Create an app at: https://open.feishu.cn/app (or larksuite.com)[/dim]")
    console.print("[dim]Enable: Bot > Enable Bot, Event Subscription > WebSocket mode[/dim]\n")

    if is_new_profile:
        existing_app_id = ""
    else:
        existing_app_id = cfg.feishu.app_id
    if existing_app_id:
        console.print(f"[dim]Current app_id: {existing_app_id[:8]}...[/dim]")

    app_id = Prompt.ask(
        "[bold]App ID[/bold]",
        default=existing_app_id or "",
    ).strip()

    while app_id and not _validate_app_id(app_id):
        console.print("[red]Invalid format. Expected: cli_x_xxxxxxxx[/red]")
        app_id = Prompt.ask("[bold]App ID[/bold]", default="").strip()

    if is_new_profile:
        existing_secret = ""
    else:
        existing_secret = cfg.feishu.app_secret

    app_secret = getpass("App Secret (hidden): ").strip()
    if not app_secret:
        app_secret = existing_secret
        if app_secret:
            console.print("[dim](kept existing secret)[/dim]")

    # Detect domain
    if app_id:
        domain = _detect_domain(app_id)
        console.print(f"[green]Detected domain: {domain}[/green]")

    # Test connection
    if app_id and app_secret:
        console.print("\n[dim]Testing connection...[/dim]")
        test_ok = await _test_connection(app_id, app_secret)
        if not test_ok:
            if not Confirm.ask("[yellow]Connection test failed. Continue anyway?[/yellow]"):
                console.print("[red]Setup cancelled.[/red]")
                return cfg
    else:
        console.print("[yellow]Skipping connection test (no credentials provided).[/yellow]")

    # --- Agent settings ---
    console.print("\n[bold]Step 2: Agent Settings[/bold]\n")

    permission_mode = Prompt.ask(
        "[bold]Permission mode[/bold]",
        choices=["acceptEdits", "auto", "bypassPermissions", "default", "plan"],
        default=cfg.agent.permission_mode,
    )

    model = Prompt.ask(
        "[bold]Model[/bold] (leave empty for default)",
        default=cfg.agent.model or "",
    ).strip() or None

    # --- Save ---
    if is_new_profile:
        from .config import ProfileConfig
        cfg.profiles[profile] = ProfileConfig(
            feishu=FeishuConfig(app_id=app_id, app_secret=app_secret),
            agent=AgentConfig(permission_mode=permission_mode, model=model),
        )
    else:
        cfg.feishu.app_id = app_id
        cfg.feishu.app_secret = app_secret
        cfg.agent.permission_mode = permission_mode
        cfg.agent.model = model

    save_config(cfg)
    console.print()
    logger.success(f"Configuration saved for profile '{profile_display}'")
    console.print(Panel(
        "[bold green]Setup complete![/bold green]\n\n"
        "Run [bold]hakucc[/bold] to start the bot.\n"
        "Run [bold]hakucc --help[/bold] for more options.",
        style="green",
    ))

    return cfg
