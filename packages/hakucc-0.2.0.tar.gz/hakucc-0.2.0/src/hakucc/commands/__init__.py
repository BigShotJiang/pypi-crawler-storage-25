"""Command system for hakucc — import this package to register builtins."""

from . import builtin  # noqa: F401 — registers all built-in commands
