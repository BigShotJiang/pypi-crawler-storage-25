"""Built-in slash commands for hakucc."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any

from .registry import register
from ..config import ResolvedConfig


@register("help")
async def cmd_help(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show available commands."""
    from .registry import _REGISTRY

    lines = ["#### Available Commands", ""]
    for name, (_, desc) in sorted(_REGISTRY.items()):
        lines.append(f"- `/{name}` — {desc}" if desc else f"- `/{name}`")

    # Custom commands
    if config.commands:
        lines.append("")
        lines.append("#### Custom Commands")
        for name in sorted(config.commands):
            lines.append(f"- `/{name}`")

    if config.exec_commands:
        lines.append("")
        lines.append("#### Exec Commands")
        for name in sorted(config.exec_commands):
            lines.append(f"- `/{name}`")

    return "\n".join(lines)


@register("status")
async def cmd_status(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show current status."""
    lines = [
        "#### Status",
        f"- **Profile**: {bridge.profile}",
        f"- **CWD**: `{bridge._cwd}`",
        f"- **Session**: {bridge.session.session_id[:16] + '...' if bridge.session and bridge.session.session_id else 'none'}",
        f"- **Processing**: {bridge._processing}",
    ]

    if bridge._processing:
        elapsed = __import__('time').time() - bridge._events._start_time
        lines.append(f"- **Elapsed**: {elapsed:.0f}s")
        lines.append(f"- **Tools**: {bridge._events.tool_count}")

    return "\n".join(lines)


@register("stop")
async def cmd_stop(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Stop current processing."""
    if bridge.agent and bridge._processing:
        await bridge.agent.interrupt()
        return "Interrupted."
    return "Nothing to stop."


@register("cancel")
async def cmd_cancel(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Cancel current processing."""
    return await cmd_stop(args, config, bridge)


@register("reset")
async def cmd_reset(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Reset the session."""
    if bridge.session:
        bridge.session.reset()
    if bridge.agent:
        await bridge.agent.disconnect()
        bridge.agent = None
    return "Session reset. Next message will start a new session."


@register("model")
async def cmd_model(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Switch model."""
    if not args.strip():
        current = config.agent.model or "default"
        return f"Current model: `{current}`\n\nUsage: `/model claude-sonnet-4-5`"

    if bridge.agent:
        await bridge.agent.set_model(args.strip())
        return f"Switched to model: `{args.strip()}`"
    return f"Model will be set to `{args.strip()}` on next session."


@register("diff")
async def cmd_diff(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show git diff."""
    return await _run_git("git diff" + (f" {args}" if args else ""), bridge)


@register("log")
async def cmd_log(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show git log."""
    n = args.strip() or "10"
    return await _run_git(f"git log --oneline -{n}", bridge)


@register("branch")
async def cmd_branch(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show git branches."""
    return await _run_git("git branch -a", bridge)


@register("pwd")
async def cmd_pwd(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show current working directory."""
    cwd = bridge._cwd if hasattr(bridge, '_cwd') else os.getcwd()
    return f"```\n{cwd}\n```"


@register("ps")
async def cmd_ps(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show running processes."""
    from ..lock import list_running

    data_dir = Path.home() / ".hakucc"
    running = list_running(data_dir)
    if not running:
        return "No running processes."

    lines = ["#### Running Processes", ""]
    for info in running:
        elapsed = __import__('time').time() - info.started_at
        lines.append(f"- **{info.profile}**: PID {info.pid}, {elapsed:.0f}s, `{info.cwd}`")
    return "\n".join(lines)


@register("context")
async def cmd_context(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show context usage."""
    if not bridge.agent:
        return "No active session."

    try:
        usage = await bridge.agent.get_context_usage()
        lines = [
            f"#### Context Usage: {usage.get('percentage', 0):.1f}%",
            f"- **Total**: {usage.get('totalTokens', 0):,} / {usage.get('maxTokens', 0):,}",
            f"- **Model**: {usage.get('model', 'unknown')}",
        ]
        for cat in usage.get("categories", []):
            lines.append(f"- {cat.get('name', '?')}: {cat.get('tokens', 0):,}")
        return "\n".join(lines)
    except Exception as e:
        return f"Error: {e}"


@register("mcp")
async def cmd_mcp(args: str, config: ResolvedConfig, bridge: Any) -> str:
    """Show MCP server status."""
    if not bridge.agent:
        return "No active session."

    try:
        status = await bridge.agent.get_mcp_status()
        servers = status.get("mcpServers", [])
        if not servers:
            return "No MCP servers configured."

        lines = ["#### MCP Servers", ""]
        for s in servers:
            st = s.get("status", "unknown")
            icon = {"connected": "🟢", "pending": "🟡", "failed": "🔴", "disabled": "⚪"}.get(st, "⚪")
            lines.append(f"- {icon} **{s.get('name', '?')}**: {st}")
            if s.get("error"):
                lines.append(f"  - Error: {s['error']}")
        return "\n".join(lines)
    except Exception as e:
        return f"Error: {e}"


# --- Built-in prompt commands ---

@register("review")
async def cmd_review(args: str, config: ResolvedConfig, bridge: Any) -> str | None:
    """Review current code changes."""
    return None  # Handled by bridge → agent


@register("fix")
async def cmd_fix(args: str, config: ResolvedConfig, bridge: Any) -> str | None:
    """Fix issues in the code."""
    return None


@register("doc")
async def cmd_doc(args: str, config: ResolvedConfig, bridge: Any) -> str | None:
    """Generate documentation."""
    return None


@register("test")
async def cmd_test(args: str, config: ResolvedConfig, bridge: Any) -> str | None:
    """Run or write tests."""
    return None


@register("refactor")
async def cmd_refactor(args: str, config: ResolvedConfig, bridge: Any) -> str | None:
    """Refactor code."""
    return None


@register("explain")
async def cmd_explain(args: str, config: ResolvedConfig, bridge: Any) -> str | None:
    """Explain code."""
    return None


@register("perf")
async def cmd_perf(args: str, config: ResolvedConfig, bridge: Any) -> str | None:
    """Analyze performance."""
    return None


@register("security")
async def cmd_security(args: str, config: ResolvedConfig, bridge: Any) -> str | None:
    """Security review."""
    return None


# --- Helper ---

async def _run_git(command: str, bridge: Any) -> str:
    """Run a git command and return the output."""
    cwd = bridge._cwd if hasattr(bridge, '_cwd') else os.getcwd()
    try:
        proc = await asyncio.create_subprocess_exec(
            "bash", "-c", command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=15)
        output = stdout.decode("utf-8", errors="replace")
        if stderr:
            err = stderr.decode("utf-8", errors="replace")
            if err.strip():
                output += f"\n```\n{err}\n```"
        return f"```\n{output[:3000]}\n```" if output.strip() else "(no output)"
    except asyncio.TimeoutError:
        return "Command timed out"
    except Exception as e:
        return f"Error: {e}"
