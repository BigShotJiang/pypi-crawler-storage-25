"""Command registry for hakucc slash commands."""

from __future__ import annotations

from typing import Any, Callable, Coroutine

from ..config import ResolvedConfig

# Type for command handlers
CommandHandler = Callable[..., Coroutine[Any, Any, str | None]]

# Registry: name → (handler, description)
_REGISTRY: dict[str, tuple[CommandHandler, str]] = {}


def register(name: str, description: str = ""):
    """Decorator to register a command handler."""
    def decorator(func: CommandHandler) -> CommandHandler:
        _REGISTRY[name] = (func, description)
        return func
    return decorator


def match_command(
    cmd: str, args: str, config: ResolvedConfig, bridge: Any
) -> Coroutine[Any, Any, str | None] | None:
    """Match a command string to a handler. Returns coroutine or None."""
    # Strip leading /
    name = cmd.lstrip("/").lower()

    # Exact match
    if name in _REGISTRY:
        handler, _ = _REGISTRY[name]
        return handler(args, config, bridge)

    # Check custom commands from config
    if name in config.commands:
        prompt = config.commands[name]
        # Template substitution
        prompt = prompt.replace("{{args}}", args)
        prompt = prompt.replace("{{param}}", args)
        return _wrap_prompt_command(prompt, bridge)

    # Check exec commands
    if name in config.exec_commands:
        command = config.exec_commands[name]
        command = command.replace("{{args}}", args)
        return _wrap_exec_command(command, config, bridge)

    # Prefix match
    for reg_name, (handler, _) in _REGISTRY.items():
        if reg_name.startswith(name):
            return handler(args, config, bridge)

    return None


async def _wrap_prompt_command(prompt: str, bridge: Any) -> str | None:
    """Handle a custom prompt command by passing it through the agent."""
    # Custom prompt commands are handled by the bridge's normal flow
    # The caller should pass this prompt to the agent
    return None  # Let the bridge handle it


async def _wrap_exec_command(command: str, config: ResolvedConfig, bridge: Any) -> str:
    """Execute a command via exec and return the output."""
    import asyncio

    # Security check
    if config.exec_security.enabled:
        for pattern in config.exec_security.blacklist:
            if pattern in command:
                return f"Blocked: command matches security blacklist pattern '{pattern}'"

    try:
        proc = await asyncio.create_subprocess_exec(
            "bash", "-c", command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=bridge._cwd if hasattr(bridge, '_cwd') else None,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
        output = stdout.decode("utf-8", errors="replace")
        if stderr:
            output += "\n" + stderr.decode("utf-8", errors="replace")
        return f"```\n{output[:3000]}\n```" if output else "(no output)"
    except asyncio.TimeoutError:
        return "Command timed out (30s)"
    except Exception as e:
        return f"Error: {e}"
