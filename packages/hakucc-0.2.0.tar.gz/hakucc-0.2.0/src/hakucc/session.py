"""Session persistence for hakucc."""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from . import logger


@dataclass
class SessionState:
    """Persistent state for a single profile."""

    session_id: str = ""
    chat_id: str = ""
    owner_open_id: str = ""
    started_at: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> SessionState:
        return cls(
            session_id=d.get("session_id", ""),
            chat_id=d.get("chat_id", ""),
            owner_open_id=d.get("owner_open_id", ""),
            started_at=d.get("started_at", 0.0),
        )


class SessionStore:
    """Manages session state persistence on disk."""

    def __init__(self, state_file: Path):
        self._path = state_file
        self._state = SessionState()

    @property
    def state(self) -> SessionState:
        return self._state

    @property
    def session_id(self) -> str:
        return self._state.session_id

    @session_id.setter
    def session_id(self, value: str) -> None:
        self._state.session_id = value

    @property
    def chat_id(self) -> str:
        return self._state.chat_id

    @chat_id.setter
    def chat_id(self, value: str) -> None:
        self._state.chat_id = value

    @property
    def owner_open_id(self) -> str:
        return self._state.owner_open_id

    @owner_open_id.setter
    def owner_open_id(self, value: str) -> None:
        self._state.owner_open_id = value

    def load(self) -> SessionState:
        """Load state from disk."""
        if self._path.exists():
            try:
                data = json.loads(self._path.read_text(encoding="utf-8"))
                self._state = SessionState.from_dict(data)
            except (json.JSONDecodeError, KeyError, TypeError):
                logger.warn(f"Corrupted state file {self._path}, resetting")
                self._state = SessionState()
        return self._state

    def save(self) -> None:
        """Persist current state to disk."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(
            json.dumps(self._state.to_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def reset(self) -> None:
        """Clear session state."""
        self._state = SessionState()
        if self._path.exists():
            self._path.unlink()
            logger.info(f"Session state cleared: {self._path}")

    def has_session(self) -> bool:
        """Check if there's an active session to resume."""
        return bool(self._state.session_id)
