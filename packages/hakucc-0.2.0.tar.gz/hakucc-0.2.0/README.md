# hakucc

Claude Code on Feishu/Lark — Python implementation using [claude-agent-sdk](https://github.com/anthropics/claude-agent-sdk-python).

## Install

```bash
pip install hakucc
# or with image processing support
pip install hakucc[image]
```

## Quick Start

```bash
# Configure Feishu app credentials
hakucc setup

# Start the bot
hakucc

# Background mode
hakucc -d

# Resume last session
hakucc -c

# Use a specific profile
hakucc -p work
```

## Commands

| Command | Description |
|---------|-------------|
| `hakucc setup` | Interactive configuration wizard |
| `hakucc new-profile <name>` | Create a new profile |
| `hakucc list-profiles` | List all profiles |
| `hakucc ps` | List running processes |
| `hakucc kill <target>` | Kill a process |
| `hakucc kill-all` | Kill all processes |
| `hakucc reset-session` | Clear session state |
| `hakucc sessions` | Show session info |
| `hakucc cleanup-tmp-files` | Clean temp files |

## Configuration

Global config: `~/.hakucc/config.toml`

```toml
[feishu]
app_id = "cli_a_xxxx"
app_secret = "xxxx"

[agent]
# permission_mode = "acceptEdits"
# model = "claude-sonnet-4-5"

[streaming]
# mode = "cardkit"  # cardkit | update | none

[overflow]
# mode = "document"  # document | chunk
# threshold = 8000

# [profiles.work]
# feishu.app_id = "cli_a_yyyy"
```

## Development

```bash
pixi install
pixi run setup
pixi run start
```

## License

MIT
