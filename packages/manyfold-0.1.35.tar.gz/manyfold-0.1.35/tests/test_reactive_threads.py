from __future__ import annotations

import importlib
import os
import unittest
from threading import Event, get_ident
from unittest.mock import patch

from tests.test_support import load_manyfold_package


class RecordingDisposable:
    def __init__(self) -> None:
        self.disposed = Event()

    def dispose(self) -> None:
        self.disposed.set()


class ReactiveThreadsTests(unittest.TestCase):
    def setUp(self) -> None:
        load_manyfold_package()
        self.reactive_threads = importlib.import_module("manyfold.reactive_threads")
        self.rx = importlib.import_module("manyfold._rx")
        self.ops = importlib.import_module("manyfold._rx.operators")
        self.reactive_threads.reset_reactive_threading_state_for_tests()

    def tearDown(self) -> None:
        self.reactive_threads.reset_reactive_threading_state_for_tests()

    def test_reactive_threads_exports_are_tuple_shaped(self) -> None:
        self.assertIsInstance(self.reactive_threads.__all__, tuple)
        self.assertEqual(
            self.reactive_threads.__all__,
            tuple(sorted(self.reactive_threads.__all__)),
        )
        self.assertEqual(
            len(self.reactive_threads.__all__),
            len(set(self.reactive_threads.__all__)),
        )
        for name in self.reactive_threads.__all__:
            with self.subTest(name=name):
                self.assertTrue(hasattr(self.reactive_threads, name))

    def test_shared_schedulers_record_configured_worker_counts(self) -> None:
        env = {
            "MANYFOLD_RX_BACKGROUND_MAX_WORKERS": "7",
            "MANYFOLD_RX_BLOCKING_IO_MAX_WORKERS": "3",
            "MANYFOLD_RX_INPUT_MAX_WORKERS": "5",
        }
        with patch.dict(os.environ, env, clear=False):
            self.reactive_threads.background_scheduler()
            self.reactive_threads.blocking_io_scheduler()
            self.reactive_threads.input_scheduler()

        self.assertEqual(
            self.reactive_threads.scheduler_diagnostics(),
            {
                "background_max_workers": 7,
                "background_priority_queue_limit": 2048,
                "blocking_io_max_workers": 3,
                "input_max_workers": 5,
            },
        )

    def test_shared_schedulers_accept_heart_env_names_during_migration(self) -> None:
        with patch.dict(
            os.environ,
            {
                "HEART_RX_BACKGROUND_MAX_WORKERS": "6",
                "HEART_RX_BLOCKING_IO_MAX_WORKERS": "4",
                "HEART_RX_INPUT_MAX_WORKERS": "2",
            },
            clear=False,
        ):
            self.reactive_threads.background_scheduler()
            self.reactive_threads.blocking_io_scheduler()
            self.reactive_threads.input_scheduler()

        self.assertEqual(
            self.reactive_threads.scheduler_diagnostics(),
            {
                "background_max_workers": 6,
                "background_priority_queue_limit": 2048,
                "blocking_io_max_workers": 4,
                "input_max_workers": 2,
            },
        )

    def test_legacy_scheduler_env_errors_name_legacy_variable(self) -> None:
        with patch.dict(
            os.environ,
            {"HEART_RX_BACKGROUND_MAX_WORKERS": "many"},
            clear=False,
        ):
            with self.assertRaisesRegex(
                ValueError,
                "HEART_RX_BACKGROUND_MAX_WORKERS must be an integer",
            ):
                self.reactive_threads.background_scheduler()

    def test_thread_helpers_reject_invalid_thread_names(self) -> None:
        source = self.rx.Subject()

        for name in ("", " ", 7):
            with self.subTest(helper="create_default_thread_factory", name=name):
                with self.assertRaisesRegex(ValueError, "thread name"):
                    self.reactive_threads.create_default_thread_factory(name)

            with self.subTest(helper="interval_in_background", name=name):
                with self.assertRaisesRegex(ValueError, "thread name"):
                    self.reactive_threads.interval_in_background(
                        self.reactive_threads.timedelta(milliseconds=1),
                        name=name,
                    )

            with self.subTest(helper="pipe_to_background_event_loop", name=name):
                with self.assertRaisesRegex(ValueError, "thread name"):
                    self.reactive_threads.pipe_to_background_event_loop(source, name)

            with self.subTest(helper="pipe_to_background_thread", name=name):
                with self.assertRaisesRegex(ValueError, "thread name"):
                    self.reactive_threads.pipe_to_background_thread(source, name)

            with self.subTest(helper="background_threaded_observable", name=name):
                with self.assertRaisesRegex(ValueError, "thread name"):
                    with self.reactive_threads.background_threaded_observable(
                        source,
                        name=name,
                    ):
                        pass

    def test_thread_helpers_reject_invalid_observables(self) -> None:
        source = object()
        cases = (
            lambda: self.reactive_threads.deliver_on_frame_thread(source),
            lambda: self.reactive_threads.observe_on_background(source),
            lambda: self.reactive_threads.pipe_in_background(source),
            lambda: self.reactive_threads.pipe_in_main_thread(source),
            lambda: self.reactive_threads.pipe_to_background_event_loop(
                source,
                "worker-stream",
            ),
            lambda: self.reactive_threads.pipe_to_background_thread(
                source,
                "worker-stream",
            ),
        )

        for build in cases:
            with self.subTest(build=build):
                with self.assertRaisesRegex(ValueError, "source must be an Observable"):
                    build()

        with self.assertRaisesRegex(ValueError, "observable must be an Observable"):
            with self.reactive_threads.background_threaded_observable(
                source,
                name="worker-stream",
            ):
                pass

    def test_thread_name_validation_trims_outer_whitespace(self) -> None:
        thread_factory = self.reactive_threads.create_default_thread_factory(
            " worker-stream "
        )

        thread = thread_factory(lambda: None)

        self.assertEqual(thread.name, "worker-stream")

    def test_interval_in_background_rejects_invalid_periods(self) -> None:
        for period, message in (
            (0.001, "period must be a timedelta"),
            (self.reactive_threads.timedelta(0), "period must be positive"),
            (self.reactive_threads.timedelta(microseconds=-1), "period must be positive"),
        ):
            with self.subTest(period=period):
                with self.assertRaisesRegex(ValueError, message):
                    self.reactive_threads.interval_in_background(period)

    def test_legacy_scheduler_env_minimum_errors_name_legacy_variable(self) -> None:
        with patch.dict(
            os.environ,
            {"HEART_RX_BACKGROUND_MAX_WORKERS": "0"},
            clear=False,
        ):
            with self.assertRaisesRegex(
                ValueError,
                "HEART_RX_BACKGROUND_MAX_WORKERS must be at least 1",
            ):
                self.reactive_threads.background_scheduler()

    def test_deliver_on_frame_thread_coalesces_until_drained(self) -> None:
        source = self.rx.Subject()
        values: list[int] = []

        self.reactive_threads.deliver_on_frame_thread(source).subscribe(values.append)
        source.on_next(1)
        source.on_next(2)

        self.assertEqual(values, [])
        self.assertFalse(self.reactive_threads.on_frame_thread())
        self.assertEqual(self.reactive_threads.drain_frame_thread_queue(max_items=1), 1)
        self.assertEqual(values, [2])
        self.assertTrue(self.reactive_threads.on_frame_thread())
        self.assertEqual(self.reactive_threads.drain_frame_thread_queue(), 0)
        self.assertEqual(values, [2])

        latency = self.reactive_threads.delivery_latency_snapshot()
        self.assertEqual(
            latency[self.reactive_threads.FRAME_THREAD_LATENCY_STREAM].count,
            1,
        )

    def test_drain_frame_thread_queue_zero_limit_leaves_queue_pending(self) -> None:
        source = self.rx.Subject()
        values: list[int] = []

        self.reactive_threads.deliver_on_frame_thread(source).subscribe(values.append)
        source.on_next(1)

        self.assertEqual(self.reactive_threads.drain_frame_thread_queue(max_items=0), 0)
        self.assertEqual(values, [])
        self.assertEqual(self.reactive_threads.drain_frame_thread_queue(), 1)
        self.assertEqual(values, [1])

    def test_drain_frame_thread_queue_rejects_non_integer_limit(self) -> None:
        for max_items in (True, 1.5, "1"):
            with self.subTest(max_items=max_items):
                with self.assertRaisesRegex(
                    ValueError,
                    "max_items must be an integer or None",
                ):
                    self.reactive_threads.drain_frame_thread_queue(max_items=max_items)

    def test_drain_frame_thread_queue_rejects_negative_limit(self) -> None:
        with self.assertRaisesRegex(ValueError, "max_items must not be negative"):
            self.reactive_threads.drain_frame_thread_queue(max_items=-1)

    def test_latency_snapshot_reports_percentiles_from_sorted_samples(self) -> None:
        recorder = self.reactive_threads._LatencyRecorder()

        for delay_s in (0.005, 0.001, 0.010, 0.002):
            recorder.record("stream", delay_s)

        stats = recorder.snapshot()["stream"]

        self.assertEqual(stats.count, 4)
        self.assertEqual(stats.p50_ms, 2.0)
        self.assertEqual(stats.p95_ms, 10.0)
        self.assertEqual(stats.p99_ms, 10.0)
        self.assertEqual(stats.max_ms, 10.0)

    def test_latency_snapshot_clamps_non_finite_samples(self) -> None:
        recorder = self.reactive_threads._LatencyRecorder()

        for delay_s in (float("nan"), float("inf"), -0.001, 0.002):
            recorder.record("stream", delay_s)

        stats = recorder.snapshot()["stream"]

        self.assertEqual(stats.count, 4)
        self.assertEqual(stats.p50_ms, 0.0)
        self.assertEqual(stats.max_ms, 2.0)

    def test_latency_snapshot_orders_streams_by_name(self) -> None:
        recorder = self.reactive_threads._LatencyRecorder()

        recorder.record("z-stream", 0.001)
        recorder.record("a-stream", 0.002)

        self.assertEqual(list(recorder.snapshot()), ["a-stream", "z-stream"])

    def test_delivery_latency_stats_rejects_invalid_direct_construction(self) -> None:
        valid = {
            "count": 3,
            "p50_ms": 1.0,
            "p95_ms": 2.0,
            "p99_ms": 3.0,
            "max_ms": 4.0,
        }
        cases = (
            ({**valid, "count": True}, "count must be an integer"),
            ({**valid, "count": 0}, "count must be positive"),
            ({**valid, "p50_ms": False}, "p50_ms must be a number"),
            ({**valid, "p95_ms": float("nan")}, "p95_ms must be finite"),
            ({**valid, "p99_ms": -1.0}, "p99_ms must not be negative"),
            ({**valid, "p95_ms": 0.5}, "latency percentiles must be ordered"),
            ({**valid, "max_ms": 2.5}, "latency percentiles must be ordered"),
        )

        for kwargs, message in cases:
            with self.subTest(kwargs=kwargs):
                with self.assertRaisesRegex(ValueError, message):
                    self.reactive_threads.DeliveryLatencyStats(**kwargs)

    def test_latency_recorder_rejects_invalid_record_values(self) -> None:
        recorder = self.reactive_threads._LatencyRecorder()

        for stream_name in ("", " ", 7):
            with self.subTest(stream_name=stream_name):
                with self.assertRaisesRegex(ValueError, "stream_name must be"):
                    recorder.record(stream_name, 0.001)

        for delay_s in (False, "0.001", object()):
            with self.subTest(delay_s=delay_s):
                with self.assertRaisesRegex(ValueError, "delay_s must be a number"):
                    recorder.record("stream", delay_s)

    def test_latency_recorder_rejects_non_positive_history_size(self) -> None:
        for history_size in (0, -1, False, 1.5):
            with self.subTest(history_size=history_size):
                with self.assertRaisesRegex(
                    ValueError,
                    "history_size must be a positive integer",
                ):
                    self.reactive_threads._LatencyRecorder(history_size=history_size)

    def test_reset_reactive_threading_state_replaces_shutdown_subject(self) -> None:
        previous_shutdown = self.reactive_threads.shutdown
        previous_shutdown.on_completed()

        self.reactive_threads.reset_reactive_threading_state_for_tests()

        self.assertIsNot(self.reactive_threads.shutdown, previous_shutdown)
        values: list[int] = []
        self.reactive_threads.materialize_sequence([1]).pipe(
            self.ops.take_until(self.reactive_threads.shutdown)
        ).subscribe(values.append)
        self.assertEqual(values, [1])

    def test_disposed_frame_thread_delivery_drops_queued_callbacks(self) -> None:
        source = self.rx.Subject()
        values: list[int] = []

        subscription = self.reactive_threads.deliver_on_frame_thread(source).subscribe(
            values.append
        )
        source.on_next(1)
        subscription.dispose()

        self.assertEqual(self.reactive_threads.drain_frame_thread_queue(), 1)
        self.assertEqual(values, [])

    def test_observe_on_background_delivers_off_caller_thread(self) -> None:
        source = self.rx.Subject()
        caller_thread = get_ident()
        delivered = Event()
        values: list[tuple[int, int]] = []

        subscription = self.reactive_threads.observe_on_background(source).subscribe(
            lambda value: (values.append((value, get_ident())), delivered.set())
        )
        try:
            source.on_next(3)

            self.assertTrue(delivered.wait(timeout=1.0))
            self.assertEqual(values[0][0], 3)
            self.assertNotEqual(values[0][1], caller_thread)
        finally:
            subscription.dispose()

    def test_observe_on_background_coalesces_until_worker_runs(self) -> None:
        source = self.rx.Subject()
        started = Event()
        release = Event()
        delivered = Event()
        values: list[int] = []

        self.reactive_threads._enqueue_background_priority_task(
            lambda: (started.set(), release.wait(timeout=1.0)),
            priority=self.reactive_threads.StreamPriority.LOW,
        )
        self.assertTrue(started.wait(timeout=1.0))

        subscription = self.reactive_threads.observe_on_background(
            source,
            priority=self.reactive_threads.StreamPriority.LOW,
        ).subscribe(lambda value: (values.append(value), delivered.set()))
        try:
            source.on_next(1)
            source.on_next(2)
            release.set()

            self.assertTrue(delivered.wait(timeout=1.0))
            self.assertEqual(values, [2])
        finally:
            subscription.dispose()

    def test_background_priority_worker_prefers_higher_priority_pending_work(
        self,
    ) -> None:
        started = Event()
        release = Event()
        completed = Event()
        values: list[str] = []

        def record(value: str) -> None:
            values.append(value)
            if len(values) == 3:
                completed.set()

        self.reactive_threads._enqueue_background_priority_task(
            lambda: (started.set(), release.wait(timeout=1.0), record("low-blocking")),
            priority=self.reactive_threads.StreamPriority.LOW,
        )
        self.assertTrue(started.wait(timeout=1.0))
        self.reactive_threads._enqueue_background_priority_task(
            lambda: record("low-pending"),
            priority=self.reactive_threads.StreamPriority.LOW,
        )
        self.reactive_threads._enqueue_background_priority_task(
            lambda: record("high-pending"),
            priority=self.reactive_threads.StreamPriority.HIGH,
        )
        release.set()

        self.assertTrue(completed.wait(timeout=1.0))
        self.assertEqual(values, ["low-blocking", "high-pending", "low-pending"])

    def test_observe_on_background_can_promote_pending_work_with_dynamic_priority(
        self,
    ) -> None:
        source = self.rx.Subject()
        active = False
        started = Event()
        release = Event()
        completed = Event()
        values: list[str] = []

        def current_priority() -> object:
            if active:
                return self.reactive_threads.StreamPriority.HIGH
            return self.reactive_threads.StreamPriority.LOW

        def record(value: str) -> None:
            values.append(value)
            if len(values) == 3:
                completed.set()

        self.reactive_threads._enqueue_background_priority_task(
            lambda: (started.set(), release.wait(timeout=1.0), record("low-blocking")),
            priority=self.reactive_threads.StreamPriority.LOW,
        )
        self.assertTrue(started.wait(timeout=1.0))

        subscription = self.reactive_threads.observe_on_background(
            source,
            priority=current_priority,
        ).subscribe(lambda value: record(f"dynamic-{value}"))
        try:
            source.on_next(1)
            active = True
            source.on_next(2)
            self.reactive_threads._enqueue_background_priority_task(
                lambda: record("low-pending"),
                priority=self.reactive_threads.StreamPriority.LOW,
            )
            release.set()

            self.assertTrue(completed.wait(timeout=1.0))
            self.assertEqual(values, ["low-blocking", "dynamic-2", "low-pending"])
        finally:
            subscription.dispose()

    def test_observe_on_background_rejects_invalid_dynamic_priority_result(
        self,
    ) -> None:
        source = self.rx.Subject()
        errors: list[Exception] = []

        self.reactive_threads.observe_on_background(
            source,
            priority=lambda: "urgent",
        ).subscribe(on_error=errors.append)
        source.on_next(1)

        self.assertEqual(len(errors), 1)
        self.assertRegex(str(errors[0]), "priority must be a StreamPriority")

    def test_observe_on_background_rejects_invalid_priority(self) -> None:
        source = self.rx.Subject()

        for priority in (True, 7, "low"):
            with self.subTest(priority=priority):
                with self.assertRaisesRegex(
                    ValueError,
                    "priority must be a StreamPriority",
                ):
                    self.reactive_threads.observe_on_background(
                        source,
                        priority=priority,
                    )

    def test_pipe_helpers_apply_operators_and_materialized_streams(self) -> None:
        background_values: list[int] = []
        self.reactive_threads.pipe_in_background(
            self.rx.from_iterable([1, 2, 3]),
            self.ops.map(lambda value: value * 2),
        ).subscribe(background_values.append)

        main_thread_values: list[int] = []
        source = self.rx.Subject()
        self.reactive_threads.pipe_in_main_thread(
            source,
            self.ops.map(lambda value: value + 10),
        ).subscribe(main_thread_values.append)
        source.on_next(1)
        source.on_next(2)
        self.reactive_threads.drain_frame_thread_queue()

        self.assertEqual(background_values, [2, 4, 6])
        self.assertEqual(main_thread_values, [12])

    def test_pipe_in_background_emits_starting_value_once_per_subscription(
        self,
    ) -> None:
        source = self.rx.Subject()
        values: list[int | None] = []

        self.reactive_threads.pipe_in_background(
            source,
            starting_value=None,
        ).subscribe(values.append)
        source.on_next(1)
        source.on_next(2)

        self.assertEqual(values, [None, 1, 2])

    def test_start_with_once_prepends_value_to_source(self) -> None:
        values: list[int] = []

        self.rx.from_iterable([2, 3]).pipe(
            self.reactive_threads.start_with_once(1)
        ).subscribe(values.append)

        self.assertEqual(values, [1, 2, 3])

    def test_materialize_sequence_exposes_iterable_as_observable(self) -> None:
        values: list[str] = []

        self.reactive_threads.materialize_sequence(["a", "b"]).subscribe(values.append)

        self.assertEqual(values, ["a", "b"])

    def test_materialize_sequence_snapshots_one_shot_iterables(self) -> None:
        observable = self.reactive_threads.materialize_sequence(iter(["a", "b"]))
        first_values: list[str] = []
        second_values: list[str] = []

        observable.subscribe(first_values.append)
        observable.subscribe(second_values.append)

        self.assertEqual(first_values, ["a", "b"])
        self.assertEqual(second_values, ["a", "b"])

    def test_materialize_sequence_rejects_non_iterables(self) -> None:
        for sequence in (None, 7, object()):
            with self.subTest(sequence=sequence):
                with self.assertRaisesRegex(ValueError, "sequence must be iterable"):
                    self.reactive_threads.materialize_sequence(sequence)

    def test_background_threaded_observable_disposes_subscription_on_exit(self) -> None:
        subscribed = Event()
        disposable = RecordingDisposable()
        completed = Event()

        def subscribe(observer: object, scheduler: object | None = None) -> object:
            subscribed.set()
            return disposable

        with self.reactive_threads.background_threaded_observable(
            self.rx.create(subscribe),
            name="manyfold-test-background",
        ) as background:
            background.subscribe(on_completed=completed.set)
            self.assertTrue(subscribed.wait(timeout=1.0))
            self.assertFalse(disposable.disposed.is_set())

        self.assertTrue(disposable.disposed.wait(timeout=1.0))
        self.assertTrue(completed.wait(timeout=1.0))


if __name__ == "__main__":
    unittest.main()
