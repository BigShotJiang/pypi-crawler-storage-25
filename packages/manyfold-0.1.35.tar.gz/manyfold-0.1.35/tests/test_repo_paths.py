from __future__ import annotations

import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

from manyfold import _repo_paths


class RepoPathTests(unittest.TestCase):
    def test_ensure_path_on_sys_path_canonicalizes_relative_paths(self) -> None:
        expected = str(Path("python").resolve())

        with mock.patch.object(sys, "path", ["python", "/tmp/example"]):
            _repo_paths.ensure_path_on_sys_path(Path("python"))

            self.assertEqual(sys.path, [expected, "/tmp/example"])

    def test_ensure_path_on_sys_path_keeps_canonical_path_once(self) -> None:
        expected = str(Path("python").resolve())

        with mock.patch.object(sys, "path", [expected, "/tmp/example", expected]):
            _repo_paths.ensure_path_on_sys_path(Path("python"))

            self.assertEqual(sys.path, [expected, "/tmp/example"])

    def test_load_module_from_path_resolves_relative_module_file(self) -> None:
        module_name = "manyfold_relative_repo_path_test"
        with tempfile.TemporaryDirectory() as temp_dir:
            module_path = Path(temp_dir) / "loaded_module.py"
            module_path.write_text("LOADED_FILE = __file__\n", encoding="utf-8")
            relative_path = Path(os.path.relpath(module_path))

            try:
                loaded = _repo_paths.load_module_from_path(module_name, relative_path)

                self.assertEqual(loaded.LOADED_FILE, str(module_path.resolve()))
                self.assertIs(sys.modules[module_name], loaded)
            finally:
                sys.modules.pop(module_name, None)

    def test_load_module_from_path_restores_existing_module_after_failure(self) -> None:
        module_name = "manyfold_failed_repo_path_test"
        previous_module = types.ModuleType(module_name)
        with tempfile.TemporaryDirectory() as temp_dir:
            module_path = Path(temp_dir) / "loaded_module.py"
            module_path.write_text("raise RuntimeError('boom')\n", encoding="utf-8")

            with mock.patch.dict(sys.modules, {module_name: previous_module}):
                with self.assertRaisesRegex(RuntimeError, "boom"):
                    _repo_paths.load_module_from_path(module_name, module_path)

                self.assertIs(sys.modules[module_name], previous_module)

    def test_load_module_from_path_restores_none_marker_after_failure(self) -> None:
        module_name = "manyfold_failed_repo_path_none_test"
        with tempfile.TemporaryDirectory() as temp_dir:
            module_path = Path(temp_dir) / "loaded_module.py"
            module_path.write_text("raise RuntimeError('boom')\n", encoding="utf-8")

            with mock.patch.dict(sys.modules, {module_name: None}):
                with self.assertRaisesRegex(RuntimeError, "boom"):
                    _repo_paths.load_module_from_path(module_name, module_path)

                self.assertIn(module_name, sys.modules)
                self.assertIsNone(sys.modules[module_name])


if __name__ == "__main__":
    unittest.main()
