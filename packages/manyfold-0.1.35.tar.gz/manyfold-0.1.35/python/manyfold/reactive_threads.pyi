from collections.abc import Callable, Iterable, Iterator
from contextlib import AbstractContextManager
from dataclasses import dataclass
from datetime import timedelta
from enum import IntEnum
from threading import Thread
from typing import Any, TypeVar

from ._rx import Observable, Subject
from ._rx.abc import SchedulerBase
from ._rx.scheduler import TimeoutScheduler

T = TypeVar("T")
TStarting = TypeVar("TStarting")
StartableTarget = Callable[..., None]
StreamPriorityResolver = Callable[[], "StreamPriority"]

FRAME_THREAD_LATENCY_STREAM: str
DEFAULT_DELIVERY_LATENCY_HISTORY_SIZE: int
DEFAULT_BACKGROUND_PRIORITY_QUEUE_LIMIT: int
shutdown: Subject[Any]

class StreamPriority(IntEnum):
    HIGH = 0
    NORMAL = 10
    LOW = 20

@dataclass(frozen=True, slots=True)
class DeliveryLatencyStats:
    count: int
    p50_ms: float
    p95_ms: float
    p99_ms: float
    max_ms: float

def background_scheduler() -> SchedulerBase: ...
def blocking_io_scheduler() -> SchedulerBase: ...
def input_scheduler() -> SchedulerBase: ...
def interval_scheduler() -> SchedulerBase: ...
def coalesce_scheduler() -> SchedulerBase: ...
def replay_scheduler() -> TimeoutScheduler: ...
def create_default_thread_factory(name: str) -> Callable[[StartableTarget], Thread]: ...
def interval_in_background(
    period: timedelta,
    *,
    name: str | None = None,
    scheduler: SchedulerBase | None = None,
) -> Observable[int]: ...
def delivery_latency_snapshot() -> dict[str, DeliveryLatencyStats]: ...
def drain_frame_thread_queue(max_items: int | None = None) -> int: ...
def on_frame_thread() -> bool: ...
def deliver_on_frame_thread(source: Observable[T]) -> Observable[T]: ...
def observe_on_background(
    source: Observable[T],
    *,
    priority: StreamPriority | StreamPriorityResolver = ...,
) -> Observable[T]: ...
def start_with_once(value: TStarting) -> Callable[[Observable[T]], Observable[Any]]: ...
def pipe_in_background(
    source: Observable[T],
    *operators: Any,
    starting_value: TStarting | object = ...,
) -> Observable[Any]: ...
def pipe_in_main_thread(source: Observable[T], *operators: Any) -> Observable[Any]: ...
def pipe_to_background_event_loop(
    source: Observable[T],
    name: str,
    *operators: Any,
) -> Observable[Any]: ...
def pipe_to_background_thread(
    source: Observable[T],
    name: str,
    *operators: Any,
) -> Observable[Any]: ...
def background_threaded_observable(
    observable: Observable[T],
    name: str,
) -> AbstractContextManager[Iterator[Observable[T]]]: ...
def scheduler_diagnostics() -> dict[str, int | None]: ...
def reset_reactive_threading_state_for_tests() -> None: ...
def materialize_sequence(sequence: Iterable[T]) -> Observable[T]: ...
