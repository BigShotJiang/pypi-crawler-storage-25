"""Typed frozen view of a parsed ROBOT.md — consumed by backends."""

from __future__ import annotations

from dataclasses import dataclass

import yaml

from robot_md.parser import ParsedRobotMd


@dataclass(frozen=True)
class Intrinsic:
    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int
    distortion_model: str | None
    distortion_coeffs: tuple[float, ...] | None

    @classmethod
    def from_dict(cls, d: dict) -> Intrinsic:
        coeffs = d.get("distortion_coeffs")
        return cls(
            fx=float(d["fx"]),
            fy=float(d["fy"]),
            cx=float(d["cx"]),
            cy=float(d["cy"]),
            width=int(d["width"]),
            height=int(d["height"]),
            distortion_model=d.get("distortion_model"),
            distortion_coeffs=tuple(float(c) for c in coeffs) if coeffs else None,
        )


@dataclass(frozen=True)
class CameraStream:
    name: str
    intrinsic: Intrinsic | None
    baseline_m: float | None
    derived_from: tuple[str, ...] | None


@dataclass(frozen=True)
class DriverEntry:
    id: str
    protocol: str
    port: str | None
    baud_rate: int | None
    model: str | None
    count: int | None
    backend: str | None
    streams: dict[str, CameraStream]


@dataclass(frozen=True)
class SolverCamera:
    driver_id: str
    primary_stream: str
    mount: str
    extrinsic: tuple[float, ...] | None
    extrinsic_source: str | None = None


@dataclass(frozen=True)
class PoseDef:
    joints: dict[str, int]
    description: str | None
    source: str | None
    taught_at: str | None


@dataclass(frozen=True)
class Precondition:
    kind: str
    name: str | None
    detail: dict


@dataclass(frozen=True)
class CapabilityContract:
    preconditions: tuple[Precondition, ...]


@dataclass(frozen=True)
class ObjectDescriptor:
    id: str
    detector: str
    params: dict


@dataclass(frozen=True)
class VisionBlock:
    object_descriptors: tuple[ObjectDescriptor, ...]

    def find(self, descriptor_id: str) -> ObjectDescriptor | None:
        return next((d for d in self.object_descriptors if d.id == descriptor_id), None)


@dataclass(frozen=True)
class LearnedSkill:
    id: str
    status: str
    validated: tuple[str, ...]
    blocked_by: tuple[str, ...]
    notes: str | None
    recorded_at: str | None


@dataclass(frozen=True)
class MetadataBlock:
    robot_name: str
    rrn: str | None
    device_id: str | None
    manufacturer: str | None
    model: str | None
    version: str | None
    license: str | None


@dataclass(frozen=True)
class Workspace:
    from_pose: str | None
    bounds_mm: dict[str, tuple[float, float]]
    note: str | None


@dataclass(frozen=True)
class PhysicsBlock:
    type: str
    dof: int
    kinematics: tuple[dict, ...]
    solver: dict
    cameras: tuple[SolverCamera, ...]
    poses: dict[str, PoseDef]
    workspace: Workspace | None


@dataclass(frozen=True)
class SafetyBlock:
    max_joint_velocity_dps: float | None
    max_linear_velocity_ms: float | None
    payload_kg: float | None
    workspace_bounds_m: tuple[float, float, float] | None
    failsafe_behavior: str | None
    estop_software: bool
    estop_hardware: bool
    estop_response_ms: int
    hitl_gates: tuple[dict, ...]


@dataclass(frozen=True)
class BrainBlock:
    planning_provider: str | None
    planning_model: str | None
    planning_confidence_gate: float | None
    planning_timeout_ms: int
    reactive_provider: str | None
    reactive_model: str | None
    task_routing: dict[str, str]


@dataclass(frozen=True)
class RobotSpec:
    rcan_version: str
    metadata: MetadataBlock
    physics: PhysicsBlock
    drivers: tuple[DriverEntry, ...]
    safety: SafetyBlock
    capabilities: frozenset[str]
    brain: BrainBlock | None
    raw_yaml: str
    capability_contracts: dict[str, CapabilityContract]
    vision: VisionBlock
    learned_skills: tuple[LearnedSkill, ...]

    @classmethod
    def from_parsed(cls, parsed: ParsedRobotMd) -> RobotSpec:
        fm = parsed.frontmatter
        meta = fm.get("metadata", {}) or {}
        physics = fm.get("physics", {}) or {}
        solver = physics.get("solver", {}) or {}
        safety = fm.get("safety", {}) or {}
        estop = safety.get("estop", {}) or {}
        brain = fm.get("brain")

        drivers: list[DriverEntry] = []
        for d in fm.get("drivers", []) or []:
            streams: dict[str, CameraStream] = {}
            for name, s in (d.get("streams") or {}).items():
                intr = s.get("intrinsic") if isinstance(s, dict) else None
                streams[name] = CameraStream(
                    name=name,
                    intrinsic=Intrinsic.from_dict(intr) if isinstance(intr, dict) else None,
                    baseline_m=(s.get("baseline_m") if isinstance(s, dict) else None),
                    derived_from=(
                        tuple(s["derived_from"])
                        if isinstance(s, dict) and s.get("derived_from")
                        else None
                    ),
                )
            drivers.append(
                DriverEntry(
                    id=d.get("id", ""),
                    protocol=d.get("protocol", ""),
                    port=d.get("port"),
                    baud_rate=d.get("baud_rate"),
                    model=d.get("model"),
                    count=d.get("count"),
                    backend=d.get("backend"),
                    streams=streams,
                )
            )

        cams = tuple(
            SolverCamera(
                driver_id=c["driver_id"],
                primary_stream=c["primary_stream"],
                mount=c["mount"],
                extrinsic=tuple(c["extrinsic"]) if c.get("extrinsic") else None,
                extrinsic_source=c.get("extrinsic_source"),
            )
            for c in (solver.get("cameras") or [])
        )

        poses_raw = physics.get("poses") or {}
        poses: dict[str, PoseDef] = {
            name: PoseDef(
                joints=dict(p.get("joints") or {}),
                description=p.get("description"),
                source=p.get("source"),
                taught_at=p.get("taught_at"),
            )
            for name, p in poses_raw.items()
            if isinstance(p, dict)
        }

        ws_raw = physics.get("workspace")
        workspace: Workspace | None = None
        if isinstance(ws_raw, dict):
            b = ws_raw.get("bounds_mm") or {}
            bounds: dict[str, tuple[float, float]] = {}
            for k, v in b.items():
                if isinstance(v, list) and len(v) == 2:
                    bounds[k] = (float(v[0]), float(v[1]))
            workspace = Workspace(
                from_pose=ws_raw.get("from_pose"),
                bounds_mm=bounds,
                note=ws_raw.get("note"),
            )

        contracts_raw = fm.get("capability_contracts") or {}
        capability_contracts: dict[str, CapabilityContract] = {}
        for cap, c in contracts_raw.items():
            if not isinstance(c, dict):
                continue
            pres = tuple(
                Precondition(
                    kind=p.get("kind", ""),
                    name=p.get("name"),
                    detail=dict(p.get("detail") or {}),
                )
                for p in (c.get("preconditions") or [])
                if isinstance(p, dict)
            )
            capability_contracts[cap] = CapabilityContract(preconditions=pres)

        vision_raw = fm.get("vision") or {}
        descs = tuple(
            ObjectDescriptor(
                id=d["id"],
                detector=d["detector"],
                params=dict(d.get("params") or {}),
            )
            for d in (vision_raw.get("object_descriptors") or [])
            if isinstance(d, dict) and "id" in d and "detector" in d
        )
        vision_block = VisionBlock(object_descriptors=descs)

        ls_raw = fm.get("learned_skills") or []
        learned_skills = tuple(
            LearnedSkill(
                id=s.get("id", ""),
                status=s.get("status", "ok"),
                validated=tuple(s.get("validated") or ()),
                blocked_by=tuple(s.get("blocked_by") or ()),
                notes=s.get("notes"),
                recorded_at=s.get("recorded_at"),
            )
            for s in ls_raw
            if isinstance(s, dict)
        )

        safety_ws = safety.get("workspace_bounds_m")
        workspace_tuple: tuple[float, float, float] | None = None
        if safety_ws and len(safety_ws) == 3:
            workspace_tuple = (float(safety_ws[0]), float(safety_ws[1]), float(safety_ws[2]))

        brain_block: BrainBlock | None = None
        if isinstance(brain, dict):
            plan = brain.get("planning", {}) or {}
            react = brain.get("reactive", {}) or {}
            brain_block = BrainBlock(
                planning_provider=plan.get("provider"),
                planning_model=plan.get("model"),
                planning_confidence_gate=plan.get("confidence_gate"),
                planning_timeout_ms=int(plan.get("timeout_ms", 30000)),
                reactive_provider=react.get("provider"),
                reactive_model=react.get("model"),
                task_routing=dict(brain.get("task_routing") or {}),
            )

        return cls(
            rcan_version=fm.get("rcan_version", ""),
            metadata=MetadataBlock(
                robot_name=meta.get("robot_name", ""),
                rrn=meta.get("rrn"),
                device_id=meta.get("device_id"),
                manufacturer=meta.get("manufacturer"),
                model=meta.get("model"),
                version=meta.get("version"),
                license=meta.get("license"),
            ),
            physics=PhysicsBlock(
                type=physics.get("type", ""),
                dof=int(physics.get("dof", 0)),
                kinematics=tuple(physics.get("kinematics") or ()),
                solver=dict(solver),
                cameras=cams,
                poses=poses,
                workspace=workspace,
            ),
            drivers=tuple(drivers),
            safety=SafetyBlock(
                max_joint_velocity_dps=safety.get("max_joint_velocity_dps"),
                max_linear_velocity_ms=safety.get("max_linear_velocity_ms"),
                payload_kg=safety.get("payload_kg"),
                workspace_bounds_m=workspace_tuple,
                failsafe_behavior=safety.get("failsafe_behavior"),
                estop_software=bool(estop.get("software", True)),
                estop_hardware=bool(estop.get("hardware", False)),
                estop_response_ms=int(estop.get("response_ms", 100)),
                hitl_gates=tuple(safety.get("hitl_gates") or ()),
            ),
            capabilities=frozenset(fm.get("capabilities") or ()),
            brain=brain_block,
            raw_yaml=yaml.safe_dump(fm, sort_keys=False),
            capability_contracts=capability_contracts,
            vision=vision_block,
            learned_skills=learned_skills,
        )
