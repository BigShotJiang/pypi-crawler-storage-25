"""robot-md — parse, validate, and render ROBOT.md files."""

__version__ = "0.6.2"
