from fastapi import Request, Response
from fastapi.responses import HTMLResponse
from pyinstrument import Profiler
from starlette.middleware.base import BaseHTTPMiddleware

from nlbone.config.settings import get_settings


class InstrumentMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, trigger_query_param: str = "profile"):
        super().__init__(app)
        self.trigger_query_param = trigger_query_param

    async def dispatch(self, request: Request, call_next) -> Response:
        if get_settings().DEBUG and request.query_params.get(self.trigger_query_param) != "true":
            return await call_next(request)

        profiler = Profiler(interval=0.001, async_mode="enabled")
        profiler.start()

        try:
            _ = await call_next(request)
        finally:
            profiler.stop()

        return HTMLResponse(content=profiler.output_html(), status_code=200)
