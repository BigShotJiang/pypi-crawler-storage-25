import json
import threading
import time
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Set

from nlbone.core.ports.cache import CachePort


class InMemoryCache(CachePort):
    def __init__(self):
        self._data: Dict[str, tuple[bytes, Optional[float]]] = {}
        self._tags: Dict[str, Set[str]] = {}
        self._ns_ver: Dict[str, int] = {}
        self._lock = threading.RLock()

    @staticmethod
    def _split_ns(key: str) -> tuple[str, str]:
        try:
            return key.split(":", 1)
        except ValueError:
            return "app", key

    def _current_ver(self, namespace: str) -> int:
        return self._ns_ver.get(namespace, 0)

    def _full_key(self, key: str) -> str:
        ns, rest = self._split_ns(key)
        return f"{ns}:{self._current_ver(ns)}:{rest}"

    @staticmethod
    def _to_bytes(value: bytes | bytearray | memoryview | str) -> bytes:
        if isinstance(value, str):
            return value.encode("utf-8")
        if isinstance(value, (bytes, bytearray, memoryview)):
            return bytes(value)
        raise TypeError(f"Cache value must be bytes-like or str, got {type(value)!r}")

    def _expired(self, full_key: str) -> bool:
        v = self._data.get(full_key)
        if not v:
            return True
        _, exp = v
        return exp is not None and time.time() > exp

    def _detach_key_from_all_tags(self, full_key: str) -> None:
        empty_tags = []
        for tag, keys in self._tags.items():
            keys.discard(full_key)
            if not keys:
                empty_tags.append(tag)
        for tag in empty_tags:
            self._tags.pop(tag, None)

    def _delete_full_key(self, full_key: str) -> None:
        self._data.pop(full_key, None)
        self._detach_key_from_all_tags(full_key)

    def _gc(self, full_key: str) -> None:
        if self._expired(full_key):
            self._delete_full_key(full_key)

    def _attach_tags(self, full_key: str, tags: Optional[Iterable[str]]) -> None:
        if not tags:
            return
        for t in tags:
            self._tags.setdefault(t, set()).add(full_key)

    def get(self, key: str) -> Optional[bytes]:
        full_key = self._full_key(key)
        with self._lock:
            self._gc(full_key)
            v = self._data.get(full_key)
            return v[0] if v else None

    def set(self, key: str, value: bytes, *, ttl: Optional[int] = None, tags: Optional[Iterable[str]] = None) -> None:
        full_key = self._full_key(key)
        tags_list = tuple(tags) if tags else None
        with self._lock:
            if ttl is not None and ttl <= 0:
                self._delete_full_key(full_key)
                return

            exp = None if ttl is None else time.time() + ttl
            self._data[full_key] = (self._to_bytes(value), exp)
            self._attach_tags(full_key, tags_list)

    def delete(self, key: str) -> None:
        full_key = self._full_key(key)
        with self._lock:
            self._delete_full_key(full_key)

    def exists(self, key: str) -> bool:
        return self.get(key) is not None

    def ttl(self, key: str) -> Optional[int]:
        full_key = self._full_key(key)
        with self._lock:
            self._gc(full_key)
            v = self._data.get(full_key)
            if not v:
                return None
            _, exp = v
            if exp is None:
                return None
            rem = int(exp - time.time())
            return rem if rem >= 0 else 0

    def mget(self, keys: Sequence[str]) -> list[Optional[bytes]]:
        return [self.get(k) for k in keys]

    def mset(
        self, items: Mapping[str, bytes], *, ttl: Optional[int] = None, tags: Optional[Iterable[str]] = None
    ) -> None:
        tags_list = tuple(tags) if tags else None
        for k, v in items.items():
            self.set(k, v, ttl=ttl, tags=tags_list)

    def get_json(self, key: str) -> Optional[Any]:
        b = self.get(key)
        return None if b is None else json.loads(b)

    def set_json(
        self, key: str, value: Any, *, ttl: Optional[int] = None, tags: Optional[Iterable[str]] = None
    ) -> None:
        self.set(key, json.dumps(value).encode("utf-8"), ttl=ttl, tags=tags)

    def invalidate_tags(self, tags: Iterable[str]) -> int:
        tags_list = tuple(tags)
        if not tags_list:
            return 0

        removed = 0
        with self._lock:
            keys_to_remove: Set[str] = set()
            for t in tags_list:
                keys_to_remove.update(self._tags.pop(t, set()))

            for key in keys_to_remove:
                if key in self._data:
                    self._data.pop(key, None)
                    removed += 1

            if keys_to_remove:
                empty_tags = []
                for tag, keys in self._tags.items():
                    keys.difference_update(keys_to_remove)
                    if not keys:
                        empty_tags.append(tag)
                for tag in empty_tags:
                    self._tags.pop(tag, None)
        return removed

    def bump_namespace(self, namespace: str) -> int:
        with self._lock:
            self._ns_ver[namespace] = self._current_ver(namespace) + 1
            return self._ns_ver[namespace]

    def clear_namespace(self, namespace: str) -> int:
        with self._lock:
            prefix = f"{namespace}:"
            keys = [k for k in self._data.keys() if k.startswith(prefix)]
            for key in keys:
                self._delete_full_key(key)
            return len(keys)

    def get_or_set(self, key: str, producer, *, ttl: int, tags=None) -> bytes:
        with self._lock:
            b = self.get(key)
            if b is not None:
                return b

        val = producer()
        val_bytes = self._to_bytes(val)

        with self._lock:
            b = self.get(key)
            if b is not None:
                return b
            self.set(key, val_bytes, ttl=ttl, tags=tags)

        return val_bytes
