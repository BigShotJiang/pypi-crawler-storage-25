from __future__ import annotations

import asyncio
import contextlib
import inspect
import json
import logging
import os
import time
from typing import Any, Awaitable, Callable, Iterable, Mapping, Optional, Sequence, Union

from redis.asyncio import ConnectionPool, Redis
from redis.asyncio.client import Pipeline
from redis.asyncio.retry import Retry
from redis.backoff import ExponentialBackoff
from redis.exceptions import LockError, RedisError

from nlbone.config.settings import get_settings
from nlbone.core.ports.cache import AsyncCachePort

logger = logging.getLogger(__name__)


def _nsver_key(ns: str) -> str:
    return f"nsver:{ns}"


def _tag_key(tag: str) -> str:
    return f"tag:{tag}"


def _split_namespace(key: str) -> tuple[str, str]:
    try:
        ns, rest = key.split(":", 1)
        return ns, rest
    except ValueError:
        return "app", key


class AsyncRedisCache(AsyncCachePort):
    def __init__(
        self,
        url: str,
        *,
        invalidate_channel: Optional[str] = None,
        namespace_cache_ttl: float = 5.0,
        default_lock_timeout: float = 10.0,
        default_blocking_timeout: float = 5.0,
        default_poll_interval: float = 0.05,
        tag_index_ttl: int = 24 * 60 * 60,
        scan_count: int = 1000,
    ):
        settings = get_settings()

        self._pool = ConnectionPool.from_url(
            url,
            decode_responses=False,
            max_connections=int(getattr(settings, "REDIS_MAX_CONNECTIONS", 200)),
            socket_timeout=float(getattr(settings, "REDIS_TIMEOUT", 2.0)),
            socket_connect_timeout=float(getattr(settings, "REDIS_TIMEOUT", 2.0)),
            health_check_interval=float(getattr(settings, "REDIS_CHECK_INTERVAL", 30)),
            retry_on_timeout=True,
            retry=Retry(ExponentialBackoff(), 3),
        )
        self._r = Redis(connection_pool=self._pool)

        self._ch = invalidate_channel or os.getenv("NLBONE_REDIS_INVALIDATE_CHANNEL", "cache:invalidate")

        self._namespace_cache_ttl = max(0.0, namespace_cache_ttl)
        self._default_lock_timeout = max(1.0, default_lock_timeout)
        self._default_blocking_timeout = max(0.1, default_blocking_timeout)
        self._default_poll_interval = max(0.01, default_poll_interval)
        self._tag_index_ttl = max(60, tag_index_ttl)
        self._scan_count = max(100, scan_count)

        self._nsver_local: dict[str, tuple[int, float]] = {}
        self._closed = False

        self._listener_task: Optional[asyncio.Task] = None
        self._listener_stop = asyncio.Event()

    @property
    def redis(self) -> Redis:
        return self._r

    async def start_invalidation_listener(self) -> None:
        if self._listener_task and not self._listener_task.done():
            return

        self._listener_stop.clear()
        self._listener_task = asyncio.create_task(self._listen_for_invalidation())

    async def _listen_for_invalidation(self) -> None:
        pubsub = self._r.pubsub(ignore_subscribe_messages=True)
        await pubsub.subscribe(self._ch)

        try:
            while not self._listener_stop.is_set():
                message = await pubsub.get_message(timeout=1.0)
                if not message:
                    continue

                data = message.get("data")
                if not data:
                    continue

                try:
                    if isinstance(data, bytes):
                        payload = json.loads(data.decode("utf-8"))
                    elif isinstance(data, str):
                        payload = json.loads(data)
                    else:
                        continue
                except Exception:
                    logger.exception("failed to decode redis invalidation payload")
                    continue

                ns_bump = payload.get("ns_bump")
                ns_clear = payload.get("ns_clear")

                if ns_bump:
                    self._nsver_local.pop(ns_bump, None)

                if ns_clear:
                    self._nsver_local.pop(ns_clear, None)

        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("redis invalidation listener crashed")
        finally:
            with contextlib.suppress(Exception):
                await pubsub.unsubscribe(self._ch)
            with contextlib.suppress(Exception):
                if hasattr(pubsub, "aclose"):
                    await pubsub.aclose()
                else:
                    await pubsub.close()

    async def close(self):
        if self._closed:
            return

        self._closed = True
        self._listener_stop.set()

        if self._listener_task is not None:
            self._listener_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._listener_task

        with contextlib.suppress(Exception):
            if hasattr(self._r, "aclose"):
                await self._r.aclose()
            else:
                await self._r.close()

        with contextlib.suppress(Exception):
            await self._pool.disconnect()

    async def _current_ver(self, ns: str) -> int:
        now = time.monotonic()

        if self._namespace_cache_ttl > 0:
            cached = self._nsver_local.get(ns)
            if cached and cached[1] > now:
                return cached[0]

        try:
            v = await self._r.get(_nsver_key(ns))
            ver = int(v) if v else 0
        except (ValueError, TypeError):
            ver = 0
        except Exception:
            logger.exception("failed to load namespace version for %s", ns)
            ver = 0

        if self._namespace_cache_ttl > 0:
            self._nsver_local[ns] = (ver, now + self._namespace_cache_ttl)

        return ver

    async def _current_vers_bulk(self, namespaces: Sequence[str]) -> dict[str, int]:
        if not namespaces:
            return {}

        now = time.monotonic()
        result: dict[str, int] = {}
        missing: list[str] = []

        for ns in namespaces:
            if self._namespace_cache_ttl > 0:
                cached = self._nsver_local.get(ns)
                if cached and cached[1] > now:
                    result[ns] = cached[0]
                    continue
            missing.append(ns)

        if missing:
            try:
                async with self._r.pipeline(transaction=False) as pipe:
                    for ns in missing:
                        pipe.get(_nsver_key(ns))
                    raw_values = await pipe.execute()
            except Exception:
                logger.exception("failed to bulk load namespace versions")
                raw_values = [None] * len(missing)

            for ns, raw in zip(missing, raw_values):
                try:
                    ver = int(raw) if raw else 0
                except (ValueError, TypeError):
                    ver = 0

                result[ns] = ver
                if self._namespace_cache_ttl > 0:
                    self._nsver_local[ns] = (ver, now + self._namespace_cache_ttl)

        return result

    async def _full_key(self, key: str) -> str:
        ns, rest = _split_namespace(key)
        ver = await self._current_ver(ns)
        return f"{ns}:{ver}:{rest}"

    async def _full_keys(self, keys: Sequence[str]) -> list[str]:
        if not keys:
            return []

        parts = [_split_namespace(k) for k in keys]
        namespaces = list(dict.fromkeys(ns for ns, _ in parts))
        versions = await self._current_vers_bulk(namespaces)
        return [f"{ns}:{versions.get(ns, 0)}:{rest}" for ns, rest in parts]

    @staticmethod
    def _to_bytes(value: bytes | bytearray | memoryview | str) -> bytes:
        if isinstance(value, str):
            return value.encode("utf-8")
        if isinstance(value, (bytes, bytearray, memoryview)):
            return bytes(value)
        raise TypeError(f"Cache value must be bytes-like or str, got {type(value)!r}")

    async def _resolve_producer(
        self,
        producer: Callable[[], Union[bytes, str, Awaitable[Union[bytes, str]]]],
    ) -> bytes:
        produced = producer()
        if inspect.isawaitable(produced):
            produced = await produced
        return self._to_bytes(produced)

    def _queue_tag_ops(
        self,
        pipe: Pipeline,
        fk: str,
        ttl: Optional[int],
        tags: Optional[Iterable[str]],
    ) -> None:
        if not tags:
            return

        tags_list = tuple(tags)
        if not tags_list:
            return

        # TTL برای tag index را عمدا بلند می‌گیریم تا referenceها زودتر از خود key گم نشوند.
        tag_ttl = self._tag_index_ttl
        if ttl is not None and ttl > 0:
            tag_ttl = max(tag_ttl, ttl + 300)

        for tag in tags_list:
            tk = _tag_key(tag)
            pipe.sadd(tk, fk)
            pipe.expire(tk, tag_ttl)

    async def _delete_keys(self, keys: Sequence[bytes | str]) -> int:
        if not keys:
            return 0

        try:
            return int(await self._r.unlink(*keys))
        except Exception:
            logger.exception("redis UNLINK failed, falling back to DELETE")
            return int(await self._r.delete(*keys))

    async def _set_full_key(
        self,
        fk: str,
        value: bytes,
        *,
        ttl: Optional[int] = None,
        tags: Optional[Iterable[str]] = None,
    ) -> None:
        if ttl is not None and ttl <= 0:
            await self._delete_keys([fk])
            return

        async with self._r.pipeline(transaction=False) as pipe:
            if ttl is None:
                pipe.set(fk, value)
            else:
                pipe.setex(fk, ttl, value)

            self._queue_tag_ops(pipe, fk, ttl, tags)
            await pipe.execute()

    async def _set_if_absent_full_key(
        self,
        fk: str,
        value: bytes,
        *,
        ttl: Optional[int] = None,
        tags: Optional[Iterable[str]] = None,
    ) -> bool:
        if ttl is not None and ttl <= 0:
            return False

        if ttl is None:
            stored = await self._r.set(fk, value, nx=True)
        else:
            stored = await self._r.set(fk, value, ex=ttl, nx=True)

        if not stored:
            return False

        if tags:
            async with self._r.pipeline(transaction=False) as pipe:
                self._queue_tag_ops(pipe, fk, ttl, tags)
                await pipe.execute()

        return True

    # -------- basic --------

    async def get(self, key: str) -> Optional[bytes]:
        fk = await self._full_key(key)
        return await self._r.get(fk)

    async def set(
        self,
        key: str,
        value: bytes,
        *,
        ttl: Optional[int] = None,
        tags: Optional[Iterable[str]] = None,
    ) -> None:
        fk = await self._full_key(key)
        await self._set_full_key(fk, value, ttl=ttl, tags=tags)

    async def delete(self, key: str) -> None:
        fk = await self._full_key(key)
        await self._delete_keys([fk])

    async def exists(self, key: str) -> bool:
        fk = await self._full_key(key)
        return bool(await self._r.exists(fk))

    async def ttl(self, key: str) -> Optional[int]:
        fk = await self._full_key(key)
        t = await self._r.ttl(fk)
        return int(t) if t >= 0 else None

    # -------- multi --------

    async def mget(self, keys: Sequence[str]) -> list[Optional[bytes]]:
        if not keys:
            return []
        fks = await self._full_keys(keys)
        return await self._r.mget(fks)

    async def mset(
        self,
        items: Mapping[str, bytes],
        *,
        ttl: Optional[int] = None,
        tags: Optional[Iterable[str]] = None,
    ) -> None:
        if not items:
            return

        fks = await self._full_keys(list(items.keys()))
        values = list(items.values())

        async with self._r.pipeline(transaction=False) as pipe:
            for fk, value in zip(fks, values):
                if ttl is None:
                    pipe.set(fk, value)
                elif ttl <= 0:
                    pipe.unlink(fk)
                else:
                    pipe.setex(fk, ttl, value)

                self._queue_tag_ops(pipe, fk, ttl, tags)

            await pipe.execute()

    # -------- json --------

    async def get_json(self, key: str) -> Optional[Any]:
        b = await self.get(key)
        if b is None:
            return None
        try:
            return json.loads(b)
        except json.JSONDecodeError:
            logger.warning("invalid json in cache for key=%s", key)
            return None

    async def set_json(
        self,
        key: str,
        value: Any,
        *,
        ttl: Optional[int] = None,
        tags: Optional[Iterable[str]] = None,
    ) -> None:
        payload = json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        await self.set(key, payload, ttl=ttl, tags=tags)

    # -------- invalidation --------

    async def invalidate_tags(self, tags: Iterable[str]) -> int:
        tags_list = tuple(tags)
        if not tags_list:
            return 0

        removed = 0

        for tag in tags_list:
            tk = _tag_key(tag)
            cursor = 0

            while True:
                cursor, members = await self._r.sscan(tk, cursor=cursor, count=self._scan_count)
                if members:
                    removed += len(members)
                    await self._delete_keys(members)

                if cursor == 0:
                    break

            await self._delete_keys([tk])

        try:
            payload = json.dumps({"tags": list(tags_list)}, separators=(",", ":")).encode("utf-8")
            await self._r.publish(self._ch, payload)
        except RedisError:
            logger.exception("failed to publish tag invalidation")

        return removed

    async def bump_namespace(self, namespace: str) -> int:
        v = await self._r.incr(_nsver_key(namespace))
        self._nsver_local[namespace] = (int(v), time.monotonic() + self._namespace_cache_ttl)

        try:
            await self._r.publish(
                self._ch,
                json.dumps({"ns_bump": namespace}, separators=(",", ":")).encode("utf-8"),
            )
        except RedisError:
            logger.exception("failed to publish namespace bump for %s", namespace)

        return int(v)

    async def clear_namespace(self, namespace: str) -> int:
        new_ver = await self.bump_namespace(namespace)
        current_prefix = f"{namespace}:{new_ver}:".encode("utf-8")

        removed = 0
        cursor = 0
        pattern = f"{namespace}:*"

        while True:
            cursor, keys = await self._r.scan(cursor=cursor, match=pattern, count=self._scan_count)
            if keys:
                old_keys = [k for k in keys if not k.startswith(current_prefix)]
                if old_keys:
                    removed += await self._delete_keys(old_keys)

            if cursor == 0:
                break

        try:
            await self._r.publish(
                self._ch,
                json.dumps({"ns_clear": namespace}, separators=(",", ":")).encode("utf-8"),
            )
        except RedisError:
            logger.exception("failed to publish namespace clear for %s", namespace)

        return removed

    # -------- dogpile-safe get_or_set --------

    async def get_or_set(
        self,
        key: str,
        producer: Callable[[], Union[bytes, str, Awaitable[Union[bytes, str]]]],
        *,
        ttl: int,
        tags: Optional[Iterable[str]] = None,
        store_none: bool = False,
    ) -> bytes:
        """
        Dogpile-safe read-through cache.

        رفتار:
        - اول GET
        - اگر miss شد، با lock فقط یک نفر producer را اجرا می‌کند
        - اگر lock نگرفتیم، چند بار poll می‌کنیم
        - اگر هنوز چیزی نبود، compute می‌کنیم ولی با SET NX می‌نویسیم
        """
        if ttl <= 0:
            raise ValueError("ttl must be > 0")

        fk = await self._full_key(key)

        val = await self._r.get(fk)
        if val is not None:
            return val

        lock_name = f"lock:{fk}"
        lock = self._r.lock(
            lock_name,
            timeout=self._default_lock_timeout,
            blocking_timeout=self._default_blocking_timeout,
            sleep=self._default_poll_interval,
        )

        try:
            async with lock:
                val = await self._r.get(fk)
                if val is not None:
                    return val

                produced = await self._resolve_producer(producer)

                if not store_none and produced is None:
                    return b""

                await self._set_full_key(fk, produced, ttl=ttl, tags=tags)
                return produced

        except LockError:
            logger.warning("cache lock timeout for key=%s", key)

        except Exception:
            logger.exception("unexpected get_or_set failure for key=%s", key)

        # fallback path
        delays = (
            self._default_poll_interval,
            self._default_poll_interval * 2,
            self._default_poll_interval * 4,
            self._default_poll_interval * 8,
        )
        for delay in delays:
            await asyncio.sleep(delay)
            val = await self._r.get(fk)
            if val is not None:
                return val

        produced = await self._resolve_producer(producer)

        stored = await self._set_if_absent_full_key(
            fk,
            produced,
            ttl=ttl,
            tags=tags,
        )
        if stored:
            return produced

        val = await self._r.get(fk)
        if val is not None:
            return val

        return produced