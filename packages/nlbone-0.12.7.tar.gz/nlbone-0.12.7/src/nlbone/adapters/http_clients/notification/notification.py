from enum import Enum
from typing import Any, Dict, Optional

import httpx
from pydantic import BaseModel

from nlbone.adapters.auth.token_provider import ClientTokenProvider
from nlbone.config.settings import get_settings
from nlbone.utils.http import normalize_https_base


class NotificationError(RuntimeError):
    def __init__(self, status: int, detail: Any | None = None):
        super().__init__(f"Notification HTTP {status}: {detail}")
        self.status = status
        self.detail = detail


class Receiver(BaseModel):
    to: str
    params: dict[str, Any]


class NotificationChannel(str, Enum):
    SMS = "sms"
    EMAIL = "email"
    PUSH = "push"
    CALL = "call"
    MESSENGER = "messenger"


class NotificationService:
    def __init__(
        self,
        token_provider: ClientTokenProvider,
        base_url: Optional[str] = None,
        timeout_seconds: Optional[float] = None,
        client: httpx.Client | None = None,
    ) -> None:
        s = get_settings()
        self._base_url = normalize_https_base(base_url or str(s.NOTIFICATION_BASE_URL), enforce_https=False)
        self._timeout = timeout_seconds or float(s.HTTP_TIMEOUT_SECONDS)
        self._client = client or httpx.Client(
            timeout=self._timeout,
            verify=True if s.ENV == "prod" else False,
        )
        self._token_provider = token_provider

    def send_notification(
        self,
        receivers: list[Receiver | Dict[str, Any]],
        template_key: str,
        channel: NotificationChannel,
        provider_id: int | None = None,
    ) -> None:
        payload = {
            "receivers": [r.model_dump() if hasattr(r, "model_dump") else r for r in receivers],
            "template_key": template_key,
            "channel": channel.value,
        }

        if provider_id is not None:
            payload["provider_id"] = provider_id

        try:
            response = self._client.post(
                f"{self._base_url}/messages",
                json=payload,
                headers={
                    "Authorization": self._token_provider.get_auth_header(),
                    "X-Api-Key": get_settings().NOTIFICATION_STATIC_API_KEY,
                },
            )
            response.raise_for_status()

        except httpx.HTTPStatusError as e:
            raise NotificationError(status=e.response.status_code, detail=e.response.text)

        except httpx.RequestError as e:
            raise NotificationError(status=500, detail=f"Network Error: {str(e)}")
