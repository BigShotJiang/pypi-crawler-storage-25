from typing import Any, Dict

import httpx

from nlbone.adapters.auth.async_token_provider import AsyncClientTokenProvider
from nlbone.adapters.http_clients.notification.notification import NotificationChannel, NotificationError, Receiver
from nlbone.config.settings import get_settings
from nlbone.utils.http import normalize_https_base


class AsyncNotificationService:
    def __init__(
        self,
        token_provider: AsyncClientTokenProvider,
        base_url: str | None = None,
        timeout_seconds: float | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        s = get_settings()
        self._base_url = normalize_https_base(base_url or str(s.NOTIFICATION_BASE_URL), enforce_https=False)
        self._timeout = timeout_seconds or float(s.HTTP_TIMEOUT_SECONDS)
        self._token_provider = token_provider
        self._client = client or httpx.AsyncClient(
            timeout=self._timeout,
            verify=True if s.ENV == "prod" else False,
            limits=httpx.Limits(
                max_keepalive_connections=s.HTTPX_MAX_KEEPALIVE_CONNECTIONS, max_connections=s.HTTPX_MAX_CONNECTIONS
            ),
        )

    async def send_notification(
        self,
        receivers: list[Receiver | Dict[str, Any]],
        template_key: str,
        channel: NotificationChannel,
        provider_id: int | None = None,
    ) -> None:
        payload = {
            "receivers": [r.model_dump() if hasattr(r, "model_dump") else r for r in receivers],
            "template_key": template_key,
            "channel": channel.value,
        }

        if provider_id is not None:
            payload["provider_id"] = provider_id

        try:
            response = await self._client.post(
                f"{self._base_url}/messages",
                json=payload,
                headers={
                    "Authorization": await self._token_provider.get_auth_header(),
                    "X-Api-Key": get_settings().NOTIFICATION_STATIC_API_KEY,
                },
            )
            response.raise_for_status()

        except httpx.HTTPStatusError as e:
            raise NotificationError(status=e.response.status_code, detail=e.response.text) from e

        except httpx.RequestError as e:
            raise NotificationError(status=500, detail=f"Network Error: {str(e)}") from e
