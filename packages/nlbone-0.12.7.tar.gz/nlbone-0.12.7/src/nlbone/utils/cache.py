from __future__ import annotations

import asyncio
import dataclasses
import hashlib
import inspect
import json
import logging
import random
from enum import Enum
from typing import Any, Callable, Iterable, Optional, Type, Union, get_args, get_origin

import orjson
from makefun import wraps as mf_wraps

from nlbone.utils.cache_registry import get_cache

logger = logging.getLogger(__name__)

try:
    from pydantic import BaseModel  # pydantic v1/v2
except Exception:  # pragma: no cover
    class BaseModel:  # type: ignore[no-redef]
        pass


PRIMITIVES = (str, int, float, bool, type(None))
CACHE_NONE_SENTINEL = b"__nlbone_cache_none_v1__"


def _bind(func: Callable, args, kwargs):
    sig = inspect.signature(func)
    bound = sig.bind_partial(*args, **kwargs)
    bound.apply_defaults()
    return bound


def _is_pydantic_model_type(tp: Any) -> bool:
    return inspect.isclass(tp) and issubclass(tp, BaseModel)


def _unwrap_optional(tp: Any) -> Any:
    origin = get_origin(tp)
    if origin is Union:
        args = [arg for arg in get_args(tp) if arg is not type(None)]
        if len(args) == 1:
            return args[0]
    return tp


def _safe_object_identity(obj: Any) -> dict[str, Any]:
    """
    Lightweight, non-recursive representation for arbitrary objects.
    Suitable for cache key generation, not for data serialization.
    """
    out: dict[str, Any] = {
        "__class__": obj.__class__.__name__,
    }

    for attr in ("id", "pk", "uuid", "key", "name", "code"):
        if hasattr(obj, attr):
            try:
                value = getattr(obj, attr)
                if isinstance(value, PRIMITIVES):
                    out[attr] = value
                    return out
            except Exception:
                pass

    return out


def to_jsonable(obj: Any, *, _seen: set[int] | None = None, _depth: int = 0) -> Any:
    """
    Convert arguments to a stable, recursion-safe JSONable structure for key generation.
    This is intentionally conservative for arbitrary objects.
    """
    if _seen is None:
        _seen = set()

    if isinstance(obj, PRIMITIVES):
        return obj

    if isinstance(obj, (bytes, bytearray, memoryview)):
        return {"__bytes__": bytes(obj).hex()}

    if isinstance(obj, Enum):
        return obj.value

    if _depth > 6:
        return f"<max_depth:{obj.__class__.__name__}>"

    obj_id = id(obj)
    if obj_id in _seen:
        return f"<recursion:{obj.__class__.__name__}>"

    if isinstance(obj, dict):
        _seen.add(obj_id)
        try:
            return {
                str(k): to_jsonable(v, _seen=_seen, _depth=_depth + 1)
                for k, v in obj.items()
            }
        finally:
            _seen.discard(obj_id)

    if isinstance(obj, (list, tuple, set, frozenset)):
        _seen.add(obj_id)
        try:
            return [to_jsonable(v, _seen=_seen, _depth=_depth + 1) for v in obj]
        finally:
            _seen.discard(obj_id)

    if dataclasses.is_dataclass(obj):
        _seen.add(obj_id)
        try:
            return {
                "__dataclass__": obj.__class__.__name__,
                "fields": {
                    k: to_jsonable(v, _seen=_seen, _depth=_depth + 1)
                    for k, v in dataclasses.asdict(obj).items()
                },
            }
        finally:
            _seen.discard(obj_id)

    if isinstance(obj, BaseModel):
        _seen.add(obj_id)
        try:
            if hasattr(obj, "model_dump"):  # pydantic v2
                dumped = obj.model_dump(mode="json")
            else:
                dumped = obj.dict()  # pydantic v1

            return {
                "__pydantic__": obj.__class__.__name__,
                "data": to_jsonable(dumped, _seen=_seen, _depth=_depth + 1),
            }
        finally:
            _seen.discard(obj_id)

    # برای objectهای arbitrary عمدا وارد __dict__ نمی‌شویم
    # چون اغلب cyclic / huge / unstable هستند.
    return _safe_object_identity(obj)


def _normalize_bound_arguments(bound_arguments: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}

    for key, value in bound_arguments.items():
        if key == "self":
            out[key] = _safe_object_identity(value)
            continue

        if key == "cls" and inspect.isclass(value):
            out[key] = f"<class:{value.__name__}>"
            continue

        out[key] = to_jsonable(value)

    return out


def _default_key_from_args(func: Callable, args, kwargs) -> str:
    bound = _bind(func, args, kwargs)
    clean_args = _normalize_bound_arguments(bound.arguments)
    payload = json.dumps(clean_args, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    digest = hashlib.sha1(payload.encode("utf-8")).hexdigest()
    return f"{func.__module__}:{func.__qualname__}:{digest}"


def _key_from_template(
    tpl: Optional[str],
    func: Callable,
    args,
    kwargs,
) -> str:
    bound = _bind(func, args, kwargs)
    if tpl:
        return tpl.format(**bound.arguments)
    return _default_key_from_args(func, args, kwargs)


def _key_from_builder(
    builder: Optional[Callable[..., str]],
    func: Callable,
    args,
    kwargs,
) -> str:
    if builder is None:
        raise ValueError("key_builder is not provided")
    return builder(*args, **kwargs)


def _format_tags(
    tag_tpls: Optional[Iterable[str]],
    func: Callable,
    args,
    kwargs,
) -> list[str] | None:
    if not tag_tpls:
        return None
    bound = _bind(func, args, kwargs)
    return [t.format(**bound.arguments) for t in tag_tpls]


def _json_default(obj: Any) -> Any:
    if isinstance(obj, BaseModel):
        if hasattr(obj, "model_dump"):
            return obj.model_dump(mode="json")
        return obj.dict()

    if isinstance(obj, Enum):
        return obj.value

    if dataclasses.is_dataclass(obj):
        return dataclasses.asdict(obj)

    if isinstance(obj, set):
        return list(obj)

    if hasattr(obj, "__dict__"):
        return vars(obj)

    raise TypeError(f"Unsupported type for JSON serialization: {type(obj)!r}")


def default_serialize(val: Any) -> bytes:
    if val is None:
        return b"null"

    if isinstance(val, (bytes, bytearray, memoryview)):
        return bytes(val)

    if isinstance(val, str):
        return orjson.dumps(val)

    return orjson.dumps(
        val,
        default=_json_default,
        option=(orjson.OPT_NON_STR_KEYS | orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_UTC_Z),
    )


def default_deserialize(b: bytes) -> Any:
    if b is None or b == b"":
        return None

    try:
        return orjson.loads(b)
    except orjson.JSONDecodeError:
        return b


def make_typed_deserializer(type_hint: Any) -> Callable[[bytes], Any]:
    type_hint = _unwrap_optional(type_hint)
    origin = get_origin(type_hint)
    args = get_args(type_hint)

    single_model_type: Optional[Type[BaseModel]] = None
    collection_origin = None

    if _is_pydantic_model_type(type_hint):
        single_model_type = type_hint
    elif origin in (list, tuple, set) and args:
        inner = _unwrap_optional(args[0])
        if _is_pydantic_model_type(inner):
            single_model_type = inner
            collection_origin = origin

    def _build_model(item: Any) -> Any:
        if single_model_type is None:
            return item
        if item is None:
            return None
        if hasattr(single_model_type, "model_validate"):
            return single_model_type.model_validate(item)
        return single_model_type.parse_obj(item)

    def deser(data: bytes) -> Any:
        raw = default_deserialize(data)

        if single_model_type is None:
            return raw

        if collection_origin in (list, tuple, set):
            if raw is None:
                return raw
            built = [_build_model(x) for x in raw]
            if collection_origin is tuple:
                return tuple(built)
            if collection_origin is set:
                return set(built)
            return built

        return _build_model(raw)

    return deser


def _run_maybe_async(func: Callable, *args, **kwargs):
    result = func(*args, **kwargs)
    if inspect.isawaitable(result):
        try:
            return asyncio.run(result)
        except RuntimeError:
            if hasattr(result, "close"):
                result.close()
            raise
    return result


def _compute_ttl(ttl: int, ttl_jitter: int | tuple[int, int] | None) -> int:
    if ttl_jitter is None or ttl_jitter == 0:
        return ttl

    if isinstance(ttl_jitter, int):
        return max(1, ttl + random.randint(0, ttl_jitter))

    lo, hi = ttl_jitter
    return max(1, ttl + random.randint(lo, hi))


def cached(
    *,
    ttl: int,
    key: str | None = None,
    key_builder: Callable[..., str] | None = None,
    tags: Iterable[str] | None = None,
    serializer: Callable[[Any], bytes] = default_serialize,
    deserializer: Callable[[bytes], Any] = default_deserialize,
    cache_resolver: Optional[Callable[[], Any]] = None,
    cache_none: bool = False,
    none_sentinel: bytes = CACHE_NONE_SENTINEL,
    ttl_jitter: int | tuple[int, int] | None = None,
):
    if ttl <= 0:
        raise ValueError("ttl must be > 0")

    if key and key_builder:
        raise ValueError("use either key or key_builder, not both")

    def deco(func: Callable):
        is_async_func = inspect.iscoroutinefunction(func)

        def _build_key(args, kwargs) -> str:
            if key_builder is not None:
                return _key_from_builder(key_builder, func, args, kwargs)
            return _key_from_template(key, func, args, kwargs)

        if is_async_func:

            @mf_wraps(func)
            async def aw(*args, **kwargs):
                try:
                    cache = (cache_resolver or get_cache)()
                except Exception:
                    logger.exception("cache_resolver failed for %s", func.__qualname__)
                    cache = None

                if not cache:
                    return await func(*args, **kwargs)

                ttl_effective = _compute_ttl(ttl, ttl_jitter)
                k = _build_key(args, kwargs)
                tg = _format_tags(tags, func, args, kwargs)

                async def producer() -> bytes:
                    result = await func(*args, **kwargs)
                    if result is None:
                        return none_sentinel
                    return serializer(result)

                try:
                    if hasattr(cache, "get_or_set"):
                        cached_bytes = await cache.get_or_set(
                            k,
                            producer,
                            ttl=ttl_effective,
                            tags=tg,
                            store_none=cache_none,
                        )
                    else:
                        cached_bytes = await cache.get(k)
                        if cached_bytes is None:
                            result = await func(*args, **kwargs)
                            if result is None:
                                if cache_none:
                                    await cache.set(k, none_sentinel, ttl=ttl_effective, tags=tg)
                                return None
                            data = serializer(result)
                            await cache.set(k, data, ttl=ttl_effective, tags=tg)
                            return result

                    if cached_bytes == none_sentinel:
                        return None

                    return deserializer(cached_bytes)

                except Exception:
                    logger.exception("cache wrapper failed for %s, key=%s", func.__qualname__, k)
                    return await func(*args, **kwargs)

            return aw

        @mf_wraps(func)
        def sw(*args, **kwargs):
            try:
                cache = (cache_resolver or get_cache)()
            except Exception:
                logger.exception("cache_resolver failed for %s", func.__qualname__)
                cache = None

            if not cache:
                return func(*args, **kwargs)

            ttl_effective = _compute_ttl(ttl, ttl_jitter)
            k = _build_key(args, kwargs)
            tg = _format_tags(tags, func, args, kwargs)

            def producer() -> bytes:
                result = func(*args, **kwargs)
                if result is None:
                    return none_sentinel
                return serializer(result)

            try:
                if hasattr(cache, "get_or_set"):
                    cached_bytes = _run_maybe_async(
                        cache.get_or_set,
                        k,
                        producer,
                        ttl=ttl_effective,
                        tags=tg,
                        store_none=cache_none,
                    )
                else:
                    cached_bytes = _run_maybe_async(cache.get, k)
                    if cached_bytes is None:
                        result = func(*args, **kwargs)
                        if result is None:
                            if cache_none:
                                _run_maybe_async(cache.set, k, none_sentinel, ttl=ttl_effective, tags=tg)
                            return None
                        data = serializer(result)
                        _run_maybe_async(cache.set, k, data, ttl=ttl_effective, tags=tg)
                        return result

                if cached_bytes == none_sentinel:
                    return None

                return deserializer(cached_bytes)

            except Exception:
                logger.exception("cache wrapper failed for %s, key=%s", func.__qualname__, k)
                return func(*args, **kwargs)

        return sw

    return deco


def invalidate_by_tags(tags_builder: Callable[..., Iterable[str]]):
    def deco(func: Callable):
        is_async_func = inspect.iscoroutinefunction(func)

        if is_async_func:

            @mf_wraps(func)
            async def aw(*args, **kwargs):
                out = await func(*args, **kwargs)

                try:
                    cache = get_cache()
                except Exception:
                    logger.exception("get_cache failed in invalidate_by_tags for %s", func.__qualname__)
                    cache = None

                if not cache:
                    return out

                try:
                    tags = list(tags_builder(*args, **kwargs))
                    if tags:
                        await cache.invalidate_tags(tags)
                except Exception:
                    logger.exception("invalidate_by_tags failed for %s", func.__qualname__)

                return out

            return aw

        @mf_wraps(func)
        def sw(*args, **kwargs):
            out = func(*args, **kwargs)

            try:
                cache = get_cache()
            except Exception:
                logger.exception("get_cache failed in invalidate_by_tags for %s", func.__qualname__)
                cache = None

            if not cache:
                return out

            try:
                tags = list(tags_builder(*args, **kwargs))
                if tags:
                    _run_maybe_async(cache.invalidate_tags, tags)
            except Exception:
                logger.exception("invalidate_by_tags failed for %s", func.__qualname__)

            return out

        return sw

    return deco