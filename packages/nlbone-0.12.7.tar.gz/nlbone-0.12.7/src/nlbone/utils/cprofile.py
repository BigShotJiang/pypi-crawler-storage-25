import cProfile
import logging as logging_levels
import pstats
import tracemalloc
from pathlib import Path
from typing import Optional

from nlbone.config import logging

logger = logging.get_logger(__name__)


class PerformanceMonitor:
    def __init__(
        self,
        name: str = "Block",
        output_file: Optional[str] = None,
        sort_key: str = "cumtime",
        print_top: Optional[int] = 100,
        enable_memory: bool = False,
        log_level: int = logging_levels.INFO,
    ):
        self.name = name
        self.output_file = output_file
        self.sort_key = sort_key
        self.print_top = print_top
        self.enable_memory = enable_memory
        self.log_level = log_level
        self.prof: Optional[cProfile.Profile] = None
        self.start_snapshot = None

    def __enter__(self):
        self.prof = cProfile.Profile()
        self.prof.enable()
        if self.enable_memory:
            tracemalloc.start()
            self.start_snapshot = tracemalloc.take_snapshot()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if not self.prof:
                return False

            self.prof.disable()
            stats = pstats.Stats(self.prof).sort_stats(self.sort_key)

            if self.print_top is not None:
                logger.log(self.log_level, f"\n[{self.name}] Performance Report:")
                stats.print_stats(self.print_top)

            if self.output_file:
                Path(self.output_file).parent.mkdir(parents=True, exist_ok=True)
                stats.dump_stats(self.output_file)

            if self.enable_memory and self.start_snapshot:
                self._log_memory_stats()

        except Exception as e:
            logger.error(f"[{self.name}] Profiling failed: {e}", exc_info=True)
        finally:
            if self.enable_memory:
                tracemalloc.stop()
        return False

    def _log_memory_stats(self):
        end_snapshot = tracemalloc.take_snapshot()
        top_stats = end_snapshot.compare_to(self.start_snapshot, "lineno")[:5]
        logger.info(f"[{self.name}] Memory top allocations:")
        for stat in top_stats:
            logger.info(f"  {stat}")
