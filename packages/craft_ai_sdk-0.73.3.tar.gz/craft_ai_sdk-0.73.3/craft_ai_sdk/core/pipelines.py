import io
import os
import tarfile
from typing import Any, TypedDict, TypeVar, Union, cast, overload

import requests
from typing_extensions import NotRequired

from ..constants import CREATION_PARAMETER_VALUE
from ..io import Input, Output
from ..sdk import BaseCraftAiSdk
from ..shared.helpers import wait_create_until_ready
from ..shared.logger import log_action, log_func_result
from ..shared.request_response_handler import handle_data_store_response
from ..shared.types import Log
from ..utils import datetime_to_timestamp_in_ms, multipartify, remove_keys_from_dict
from ..utils.dict_utils import remove_none_values
from .pipeline_templates import PipelineTemplateReference

T = TypeVar("T")

CreationParameter = Union[T, CREATION_PARAMETER_VALUE, None]


class ContainerConfigBase(TypedDict):
    language: NotRequired[CreationParameter[str]]
    requirements_path: NotRequired[CreationParameter[str]]
    included_folders: NotRequired[CreationParameter[list[str]]]
    system_dependencies: NotRequired[CreationParameter[list[str]]]
    dockerfile_path: NotRequired[CreationParameter[str]]


class ContainerConfigWithGit(ContainerConfigBase):
    repository_url: NotRequired[CreationParameter[str]]
    repository_branch: NotRequired[CreationParameter[str]]
    repository_deploy_key: NotRequired[CreationParameter[str]]


class ContainerConfigWithLocalFolder(ContainerConfigBase):
    local_folder: str


ContainerConfig = Union[ContainerConfigWithGit, ContainerConfigWithLocalFolder]


class PipelineParameter(TypedDict):
    pipeline_name: str
    function_path: str
    function_name: str
    description: str
    inputs: list[Input]
    outputs: list[Output]
    container_config: ContainerConfig


class PipelineCreationInfo(TypedDict):
    created_at: str
    created_by: str
    commit_id: str
    status: str
    origin: str
    last_execution_id: str
    pipeline_template: Union[PipelineTemplateReference, None]


class Pipeline(TypedDict):
    parameters: PipelineParameter
    creation_info: PipelineCreationInfo


class PipelineListItem(TypedDict):
    pipeline_name: str
    created_at: str
    status: str


class PipelineDeletedPipeline(TypedDict):
    name: str


class PipelineDeletedDeployment(TypedDict):
    name: str
    execution_rule: str


class PipelineDeleted(TypedDict):
    pipeline: PipelineDeletedPipeline
    deployments: list[PipelineDeletedDeployment]


def _compress_folder_to_memory(local_folder: str, include: list[str]):
    tar_data = io.BytesIO()
    # Remove leading slashes from the paths
    include = [item.lstrip("/") for item in include]
    with tarfile.open(fileobj=tar_data, mode="w:gz") as tar:
        for item in include:
            tar.add(os.path.join(os.path.abspath(local_folder), item), arcname=item)
    tar_data.seek(0)
    return tar_data


def _validate_create_pipeline_parameters(
    inputs: Union[list[Input], None],
    outputs: Union[list[Output], None],
    timeout_s: Union[int, None],
):
    if timeout_s is not None and timeout_s <= 0:
        raise ValueError("The timeout must be greater than 0 or None.")

    if inputs is not None:
        if any(not isinstance(input_, Input) for input_ in inputs):
            raise ValueError("'inputs' must be a list of instances of Input.")

    if outputs is not None:
        if any(not isinstance(output_, Output) for output_ in outputs):
            raise ValueError("'outputs' must be a list of instances of Output.")


def _map_container_config_pipeline_parameter(container_config: ContainerConfig):
    """
    Maps container config with :obj:`CREATION_PARAMETER_VALUE` enum values to final
    container config. `None` is considered to be equivalent to
    :obj:`CREATION_PARAMETER_VALUE.FALLBACK_PROJECT`, and should not be projected to
    output
    """
    ret: dict[str, Any] = {}
    for key in container_config:
        if key == "local_folder":
            continue
        val = container_config[key]
        if val is CREATION_PARAMETER_VALUE.NULL:
            ret[key] = None
        elif val is not CREATION_PARAMETER_VALUE.FALLBACK_PROJECT and val is not None:
            ret[key] = val
    return ret


def _prepare_create_pipeline_data(
    function_path: Union[str, None],
    function_name: Union[str, None],
    description: Union[str, None],
    container_config: ContainerConfig,
    inputs: Union[list[Input], None],
    outputs: Union[list[Output], None],
    pipeline_name: str,
):
    data = remove_none_values(
        {
            "pipeline_name": pipeline_name,
            "function_path": function_path,
            "function_name": function_name,
            "description": description,
            "container_config": _map_container_config_pipeline_parameter(
                container_config
            ),
        }
    )

    if inputs is not None:
        data["inputs"] = [inp.to_dict() for inp in inputs]

    if outputs is not None:
        data["outputs"] = [output.to_dict() for output in outputs]

    return data


def _prepare_create_pipeline_files(
    sdk: BaseCraftAiSdk,
    container_config: ContainerConfigWithLocalFolder,
    data: dict,
    function_path: Union[str, None],
):
    url = f"{sdk.base_environment_api_url}/project-information"
    project_information = sdk._get(url)

    included = [
        *(
            data.get("container_config", {}).get(
                "included_folders", project_information.get("included_folders")
            )
            or []
        ),
        data.get("container_config", {}).get(
            "requirements_path", project_information.get("requirements_path")
        ),
        function_path,
    ]

    tar_data = _compress_folder_to_memory(
        container_config["local_folder"], include=list(filter(None, included))
    )
    return {"step_file": tar_data}


def _create_pipeline_from_template(
    sdk: BaseCraftAiSdk, pipeline_name: str, pipeline_template_name: str
) -> None:
    url = f"{sdk.base_environment_api_url}/pipelines"
    body = {
        "pipeline_name": pipeline_name,
        "pipeline_template_name": pipeline_template_name,
    }

    log_action(
        sdk,
        f'Please wait while pipeline "{pipeline_name}" is being created. '
        "This may take a while...",
    )

    sdk._post(url, json=body, allow_redirects=False)


@overload
def create_pipeline(
    sdk: BaseCraftAiSdk,
    pipeline_name: str,
    function_path: Union[str, None] = None,
    function_name: Union[str, None] = None,
    description: Union[str, None] = None,
    container_config: Union[ContainerConfig, None] = None,
    inputs: Union[list[Input], None] = None,
    outputs: Union[list[Output], None] = None,
    wait_for_completion: bool = True,
    timeout_s: Union[int, None] = None,
) -> Pipeline: ...
@overload
def create_pipeline(
    sdk: BaseCraftAiSdk,
    pipeline_name: str,
    *,
    pipeline_template_name: str,
    wait_for_completion: bool = True,
    timeout_s: Union[int, None] = None,
) -> Pipeline: ...
@log_func_result("Pipeline creation")
def create_pipeline(
    sdk: BaseCraftAiSdk,
    pipeline_name: str,
    function_path: Union[str, None] = None,
    function_name: Union[str, None] = None,
    description: Union[str, None] = None,
    container_config: Union[ContainerConfig, None] = None,
    inputs: Union[list[Input], None] = None,
    outputs: Union[list[Output], None] = None,
    wait_for_completion: bool = True,
    timeout_s: Union[int, None] = None,
    *,
    pipeline_template_name: Union[str, None] = None,
    **kwargs,
) -> Pipeline:
    """Create a pipeline via two main creation modes:

    **Function-based pipeline creation**
      Create a pipeline from a function located on a remote repository or locally.
      It requires :obj:`function_path` and :obj:`function_name` parameters
      to be specified.

      Use :obj:`CREATION_PARAMETER_VALUE` to explicitly set a value to null or fall back
      on project information.
      You can also use :obj:`container_config.included_folders` to specify the files and
      folders required for the pipeline execution. This is useful if your repository
      contains large files that are not required for the pipeline execution, such as
      documentation or test files. Indeed there is a maximum limit of 5MB for the
      total size of the content specified with :obj:`included_folders`.

    **Template-based pipeline creation**
      Create a pipeline from a predefined pipeline template by specifying the
      :obj:`pipeline_template_name`. Function parameters should not be specified in
      this case, as the template defines them.

    In both cases, there are two optional parameters to control the pipeline creation
    process: :obj:`wait_for_completion` and :obj:`timeout_s`.


    Args:
        pipeline_name (:obj:`str`): Name of the pipeline to be created.
        function_path (:obj:`str`, optional): Path to the file that contains the
            function. This parameter is required if parameter "dockerfile_path"
            is not specified.
        function_name (:obj:`str`, optional): Name of the function in that file.
            This parameter is required if parameter "dockerfile_path" is not
            specified.
        description (:obj:`str`, optional): Description. Defaults to None.
        container_config (:obj:`dict[str, str]`, optional): Some pipeline configuration,
            with the following optional keys:

            * ``"language"`` (:obj:`str`): Language and version used for the pipeline.
              Defaults to falling back on project information. The accepted formats
              are "python:3.X-slim", where "3.X" is a supported version of Python,
              and "python-cuda:3.X-Y.Z" for GPU environments, where "Y.Z" is a
              supported version of CUDA. The list of supported versions is available
              on the official documentation website at
              https://mlops-platform-documentation.craft.ai.
            * ``"repository_url"`` (:obj:`str`): Remote repository url.
              Defaults to falling back on project information.
            * ``"repository_branch"`` (:obj:`str`): Branch name. Defaults to falling
              back on project information.
            * ``"repository_deploy_key"`` (:obj:`str`): Private SSH key of the
              repository.
              Defaults to falling back on project information, can be set to null.
              The key should retain the header/footer beacon with : "BEGIN/END RSA
              PRIVATE KEY".
            * ``"requirements_path"`` (:obj:`str`): Path to the requirements.txt
              file. Environment variables created through
              :func:`create_or_update_environment_variable` can be used
              in requirements.txt, as in ``"${ENV_VAR}"``.
              Defaults to falling back on project information, can be set to null.
            * ``"included_folders"`` (:obj:`list[str]`): List of folders and files
              in the repository required for the pipeline execution.
              Defaults to falling back on project information, can be set to null.
              Total size of included_folders must be less than 5MB.
            * ``"system_dependencies"`` (:obj:`list[str]`): List of system
              dependencies.
              Defaults to falling back on project information, can be set to null.
            * ``"dockerfile_path"`` (:obj:`str`): Path to the Dockerfile. This
              parameter should only be used as a last resort and for advanced use.
              When specified, the following parameters should be set to null:
              ``"function_path"``, ``"function_name"``, ``"language"``,
              ``"requirements_path"`` and ``"system_dependencies"``.
            * ``"local_folder`` (:obj:`str`): Path to local folder where the pipeline is
              stored.

        inputs(`list` of instances of :class:`Input`): List of inputs. Each
            parameter of the pipeline function should be specified as an instance of
            :class:`Input` via this parameter `inputs`.
            During the execution of the pipeline, the value of the inputs would be
            passed as function arguments.
        outputs(`list` of instances of :class:`Output`): List of the pipeline
            outputs. For the pipeline to have outputs, the function should return a
            :obj:`dict` with the name of the output as keys and the value of the
            output as values. Each output should be specified as an instance
            of :class:`Output` via this parameter `outputs`.

        pipeline_template_name (:obj:`str`, keyword-only): Name of the pipeline template
            to use.
        wait_for_completion (:obj:`bool`, optional): Whether to wait for the pipeline
            to be created. Defaults to ``True``.
        timeout_s (:obj:`int`): Maximum time (in seconds) to wait for the pipeline to
            be created. Set to None to wait indefinitely. Defaults to None.
            Only applicable if ``wait_for_completion`` is ``True``.

    Returns:
        :obj:`dict`: Created pipeline represented as :obj:`dict` with the following
        keys:

        * ``"parameters"`` (:obj:`dict`): Information used to create the pipeline with
          the following keys:

          * ``"pipeline_name"`` (:obj:`str`): Name of the pipeline.
          * ``"function_path"`` (:obj:`str`): Path to the file that contains the
            function.
          * ``"function_name"`` (:obj:`str`): Name of the function in that file.
          * ``"description"`` (:obj:`str`): Description.
          * ``"inputs"`` (:obj:`list` of :obj:`dict`): List of inputs represented
            as a :obj:`dict` with the following keys:

            * ``"name"`` (:obj:`str`): Input name.
            * ``"data_type"`` (:obj:`str`): Input data type.
            * ``"is_required"`` (:obj:`bool`): Whether the input is required.
            * ``"default_value"`` (:obj:`str`): Input default value.

          * ``"outputs"`` (:obj:`list` of :obj:`dict`): List of outputs
            represented as a :obj:`dict` with the following keys:

            * ``"name"`` (:obj:`str`): Output name.
            * ``"data_type"`` (:obj:`str`): Output data type.
            * ``"description"`` (:obj:`str`): Output description.

          * ``"container_config"`` (:obj:`dict[str, str]`): Some pipeline
            configuration, with the following optional keys:

            * ``"language"`` (:obj:`str`): Language and version used for the pipeline.
              The accepted formats are "python:3.X-slim", where "3.X" is a supported
              version of Python, and "python-cuda:3.X-Y.Z" for GPU environments,
              where "Y.Z" is a supported version of CUDA. The list of supported
              versions is available on the official documentation website at
              https://mlops-platform-documentation.craft.ai.
            * ``"repository_url"`` (:obj:`str`): Remote repository url.
            * ``"repository_branch"`` (:obj:`str`): Branch name.
            * ``"included_folders"`` (:obj:`list[str]`): List of folders and
              files in the repository required for the pipeline execution.
            * ``"system_dependencies"`` (:obj:`list[str]`): List of system
              dependencies.
            * ``"dockerfile_path"`` (:obj:`str`): Path to the Dockerfile.
            * ``"requirements_path"`` (:obj:`str`): Path to the requirements.txt
              file.

        * ``"creation_info"`` (:obj:`dict`): Information about the pipeline creation:

          * ``"created_at"`` (:obj:`str`): The creation date in ISO format.
          * ``"commit_id"`` (:obj:`str`): The commit id on which the pipeline was
            built.
          * ``"status"`` (:obj:`str`): either ``"creation_pending"`` or ``"ready"``.
          * ``"origin"`` (:obj:`str`): The origin of the pipeline, can be
            ``"git_repository"`` or ``"local"``.
          * ``"pipeline_template"`` (:obj:`dict` or :obj:`None`): The pipeline template
            used to create the pipeline, :obj:`None` if the pipeline was not created
            from a template. If not :obj:`None`, the dictionary has the following keys:

            * ``"name"`` (:obj:`str`): Name of the pipeline template used as an
              identifier to create the pipeline.
            * ``"version"`` (:obj:`str`): Version of the pipeline template.
            * ``"display_name"`` (:obj:`str`): Display name of the pipeline
              template.
            * ``"description"`` (:obj:`str`): Description of the pipeline template.
            * ``"hosting_type"`` (:obj:`str`): Either ``"self-hosted"`` if the model
              runs on the environment's infrastructure, or ``"private-api"`` if the
              model inference is done through an external API.
            * ``"model_family"`` (:obj:`str`): Model family of the pipeline
              template.
          * ``"last_execution_id"`` (:obj:`str`): The id of the last execution of
            the pipeline.
    """
    # Pipeline creation from a template
    if pipeline_template_name is not None:
        if (
            function_path is not None
            or function_name is not None
            or description is not None
            or container_config is not None
            or inputs is not None
            or outputs is not None
            or len(kwargs) != 0
        ):
            raise ValueError(
                "create_pipeline() got unexpected arguments. When specifying the "
                "'pipeline_template_name' keyword argument, no other argument than "
                "'pipeline_name' should be provided."
            )

        _create_pipeline_from_template(sdk, pipeline_name, pipeline_template_name)
        return get_pipeline(sdk, pipeline_name, wait_for_completion, timeout_s)

    if len(kwargs) != 0:
        raise ValueError(
            f"create_pipeline() got unexpected keyword arguments: {kwargs}"
        )

    container_config = (
        cast(ContainerConfig, {})
        if container_config is None
        else cast(ContainerConfig, container_config.copy())
    )
    _validate_create_pipeline_parameters(inputs, outputs, timeout_s)

    url = f"{sdk.base_environment_api_url}/pipelines"
    data = _prepare_create_pipeline_data(
        function_path,
        function_name,
        description,
        container_config,
        inputs,
        outputs,
        pipeline_name=pipeline_name,
    )
    files = (
        _prepare_create_pipeline_files(
            sdk,
            cast(ContainerConfigWithLocalFolder, container_config),
            data,
            function_path,
        )
        if "local_folder" in container_config
        else {}
    )

    log_action(
        sdk,
        f'Please wait while pipeline "{pipeline_name}" is being created. '
        "This may take a while...",
    )

    sdk._post(url, data=multipartify(data), files=files, allow_redirects=False)

    return get_pipeline(sdk, pipeline_name, wait_for_completion, timeout_s)


def get_pipeline(
    sdk: BaseCraftAiSdk, pipeline_name, wait_for_completion=False, timeout_s=None
) -> Pipeline:
    """Get a single pipeline if it exists.

    Args:
        pipeline_name (:obj:`str`): Name of the pipeline to get.
        wait_for_completion (:obj:`bool`, optional): Whether to wait for the pipeline
            to be created. Defaults to ``False``.
        timeout_s (:obj:`int`): Maximum time (in seconds) to wait for the pipeline to
            be created. Set to None to wait indefinitely. Defaults to None.
            Only applicable if ``wait_for_completion`` is ``True``.

    Returns:
        None if the pipeline does not exist, otherwise pipeline information, with
        the following keys:

        * ``"parameters"`` (:obj:`dict`): Information used to create the pipeline with
          the following keys:

          * ``"pipeline_name"`` (:obj:`str`): Name of the pipeline.
          * ``"function_path"`` (:obj:`str`): Path to the file that contains the
            function.
          * ``"function_name"`` (:obj:`str`): Name of the function in that file.
          * ``"description"`` (:obj:`str`): Description.
          * ``"inputs"`` (:obj:`list` of :obj:`dict`): List of inputs represented
            as a :obj:`dict` with the following keys:

            * ``"name"`` (:obj:`str`): Input name.
            * ``"data_type"`` (:obj:`str`): Input data type.
            * ``"is_required"`` (:obj:`bool`): Whether the input is required.
            * ``"default_value"`` (:obj:`str`): Input default value.
            * ``"description"`` (:obj:`str`): Output description.

          * ``"outputs"`` (:obj:`list` of :obj:`dict`): List of outputs
            represented as a :obj:`dict` with the following keys:

            * ``"name"`` (:obj:`str`): Output name.
            * ``"data_type"`` (:obj:`str`): Output data type.
            * ``"description"`` (:obj:`str`): Output description.

          * ``"container_config"`` (:obj:`dict[str, str]`): Some pipeline
            configuration, with the following optional keys:

            * ``"language"`` (:obj:`str`): Language and version used for the pipeline.
              The accepted formats are "python:3.X-slim", where "3.X" is a supported
              version of Python, and "python-cuda:3.X-Y.Z" for GPU environments,
              where "Y.Z" is a supported version of CUDA. The list of supported
              versions is available on the official documentation website at
              https://mlops-platform-documentation.craft.ai.
            * ``"repository_url"`` (:obj:`str`): Remote repository url.
            * ``"repository_branch"`` (:obj:`str`): Branch name.
            * ``"included_folders"`` (:obj:`list[str]`): List of folders and
              files in the repository required for the pipeline execution.
            * ``"system_dependencies"`` (:obj:`list[str]`): List of system
              dependencies.
            * ``"dockerfile_path"`` (:obj:`str`): Path to the Dockerfile.
            * ``"requirements_path"`` (:obj:`str`): Path to the requirements.txt
              file.

        * ``"creation_info"`` (:obj:`dict`): Information about the pipeline creation:

          * ``"created_at"`` (:obj:`str`): The creation date in ISO format.
          * ``"created_by"`` (:obj:`str`): The user who created the pipeline.
          * ``"commit_id"`` (:obj:`str`): The commit id on which the pipeline was
            built.
          * ``"status"`` (:obj:`str`): either ``"creation_pending"`` or ``"ready"``.
          * ``"origin"`` (:obj:`str`): The origin of the pipeline, can be
            ``"git_repository"`` or ``"local"``.
          * ``"pipeline_template"`` (:obj:`dict` or :obj:`None`): The pipeline template
            used to create the pipeline, :obj:`None` if the pipeline was not created
            from a template. If not :obj:`None`, the dictionary has the following keys:

            * ``"name"`` (:obj:`str`): Name of the pipeline template used as an
              identifier to create the pipeline.
            * ``"version"`` (:obj:`str`): Version of the pipeline template.
            * ``"display_name"`` (:obj:`str`): Display name of the pipeline
              template.
            * ``"description"`` (:obj:`str`): Description of the pipeline template.
            * ``"hosting_type"`` (:obj:`str`): Either ``"self-hosted"`` if the model
              runs on the environment's infrastructure, or ``"private-api"`` if the
              model inference is done through an external API.
            * ``"model_family"`` (:obj:`str`): Model family of the pipeline
              template.
          * ``"last_execution_id"`` (:obj:`str`): The id of the last execution of
            the pipeline.
    """
    base_url = f"{sdk.base_environment_api_url}/pipelines/{pipeline_name}"
    log_action(sdk, f'Get pipeline: "{pipeline_name}", "{wait_for_completion}".')
    if wait_for_completion:
        pipeline = wait_create_until_ready(
            sdk,
            pipeline_name,
            lambda sdk, _: sdk._get(
                f"{base_url}?wait_for_completion=true", allow_redirects=False
            ),
            timeout_s,
            sdk._get_time(),
            get_pipeline_logs,
        )
    else:
        pipeline = sdk._get(base_url)
    log_action(sdk, "Get pipeline done.")

    latest_execution = sdk._get(
        f"{sdk.base_environment_api_url}/pipelines/{pipeline_name}/executions/latest"
    )
    pipeline["creation_info"]["last_execution_id"] = (
        latest_execution.get("execution_id", None)
        if latest_execution is not None
        else None
    )
    return remove_keys_from_dict(
        pipeline, {"creation_info.is_archived", "creation_info.id"}
    )


def list_pipelines(sdk: BaseCraftAiSdk) -> list[PipelineListItem]:
    """Get the list of all pipelines.

    Returns:
        :obj:`list` of :obj:`dict`: List of pipelines represented as :obj:`dict`
        with the following keys:

        * ``"pipeline_name"`` (:obj:`str`): Name of the pipeline.
        * ``"created_at"`` (:obj:`str`): Pipeline date of creation.
        * ``"status"`` (:obj:`str`): Status of the pipeline.
    """
    url = f"{sdk.base_environment_api_url}/pipelines"

    return sdk._get(url)


@log_func_result("Pipeline deletion")
def delete_pipeline(
    sdk: BaseCraftAiSdk, pipeline_name: str, force_deployments_deletion=False
) -> PipelineDeleted:
    """Delete a pipeline identified by its name.

    Args:
        pipeline_name (:obj:`str`): Name of the pipeline.
        force_deployments_deletion (:obj:`bool`, optional): if True the associated
            endpoints will be deleted too. Defaults to False.

    Returns:
        :obj:`dict`: The deleted pipeline and its associated deleted deployments
        represented as a :obj:`dict` with the following keys:

            * ``"pipeline"`` (:obj:`dict`): Deleted pipeline represented as
              :obj:`dict` with the following keys:

              * ``"name"`` (:obj:`str`): Name of the deleted pipeline.

            * ``"deployments"`` (:obj:`list`): List of deleted deployments
              represented as :obj:`dict` with the following keys:

              * ``"name"`` (:obj:`str`): Name of the deleted deployments.
              * ``"execution_rule"`` (:obj:`str`): Execution rule of the deleted
                deployments.
    """
    url = f"{sdk.base_environment_api_url}/pipelines/{pipeline_name}"
    params = {
        "force_deployments_deletion": force_deployments_deletion,
    }
    return sdk._delete(url, params=params)


def _get_download_presigned_url(sdk: BaseCraftAiSdk, pipeline_name: str) -> str:
    url = f"{sdk.base_environment_api_url}/pipelines/{pipeline_name}/download"
    presigned_url = sdk._get(url)["signed_url"]
    return presigned_url


@log_func_result("pipeline download")
def download_pipeline_local_folder(
    sdk: BaseCraftAiSdk, pipeline_name: str, folder: str
):
    """Download a pipeline's local folder as a `.tgz` archive.

    Only available if the pipeline's ``origin`` is ``"local_folder"``. This archive
    contains the files that were in the ``local_folder`` parameter provided during
    pipeline creation, and that were included based on the pipeline's
    ``container_config`` property.

    Args:
        pipeline_name (:obj:`str`): Name of the pipline to be downloaded.
        folder (:obj:`str`): Path to the folder where the file will be saved.

    Returns:
        None
    """
    presigned_url = _get_download_presigned_url(sdk, pipeline_name)
    resp = requests.get(presigned_url)
    object_content = handle_data_store_response(resp)

    if isinstance(folder, str):
        path = os.path.join(os.path.abspath(folder), f"{pipeline_name}.tgz")
        with open(path, "wb") as f:
            f.write(object_content)
    else:
        raise ValueError("'folder' must be a string")


@log_func_result("Pipeline logs")
def get_pipeline_logs(
    sdk: BaseCraftAiSdk,
    pipeline_name,
    from_datetime=None,
    to_datetime=None,
    limit=None,
) -> list[Log]:
    """Get the logs of a pipeline.

    Args:
        pipeline_name (:obj:`str`): Name of the pipeline.
        from_datetime (:obj:`datetime.time`, optional): Datetime from which the logs
            are collected.
        to_datetime (:obj:`datetime.time`, optional): Datetime until which the logs
            are collected.
        limit (:obj:`int`, optional): Maximum number of logs that are collected.

    Returns:
        :obj:`list` of :obj:`dict`: List of collected logs represented as dict with
        the following keys:

        * ``"timestamp"`` (:obj:`str`): Timestamp of the log.
        * ``"message"`` (:obj:`str`): Log message.
    """
    url = f"{sdk.base_environment_api_url}/pipelines/{pipeline_name}/logs"

    data = {}
    if from_datetime is not None:
        data["from"] = datetime_to_timestamp_in_ms(from_datetime)
    if to_datetime is not None:
        data["to"] = datetime_to_timestamp_in_ms(to_datetime)
    if limit is not None:
        data["limit"] = limit

    log_action(
        sdk,
        "Please wait while logs are being fetched. This may take a while...",
    )
    logs = sdk._post(url, json=data)

    return logs
