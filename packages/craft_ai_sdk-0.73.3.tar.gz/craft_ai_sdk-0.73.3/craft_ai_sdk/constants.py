from enum import Enum, auto
from typing import Literal, cast

from strenum import LowercaseStrEnum, StrEnum


class EXECUTION_STATUS(StrEnum):
    """Enumeration for execution statuses"""

    #: The execution is in queue, but not started
    PENDING = "Pending"
    #: The execution is currently running
    RUNNING = "Running"
    #: The execution completed successfully
    SUCCEEDED = "Succeeded"
    #: The execution conditions were not met (not used for now)
    SKIPPED = "Skipped"
    #: The user code encountered an error.
    FAILED = "Failed"
    #: The platform behaved incorrectly. You may want to submit a bug report.
    ERROR = "Error"


FAILED_EXECUTION_STATUSES = cast(
    set[Literal[EXECUTION_STATUS.FAILED] | Literal[EXECUTION_STATUS.ERROR]],
    {
        EXECUTION_STATUS.FAILED,
        EXECUTION_STATUS.ERROR,
    },
)

COMPLETED_EXECUTION_STATUSES = cast(
    set[
        Literal[EXECUTION_STATUS.FAILED]
        | Literal[EXECUTION_STATUS.ERROR]
        | Literal[EXECUTION_STATUS.SKIPPED]
        | Literal[EXECUTION_STATUS.SUCCEEDED]
    ],
    {
        EXECUTION_STATUS.FAILED,
        EXECUTION_STATUS.ERROR,
        EXECUTION_STATUS.SKIPPED,
        EXECUTION_STATUS.SUCCEEDED,
    },
)


class DEPLOYMENT_EXECUTION_RULES(LowercaseStrEnum):
    """Enumeration for deployments execution rules."""

    ENDPOINT = auto()
    PERIODIC = auto()


class DEPLOYMENT_MODES(LowercaseStrEnum):
    """Enumeration for deployments modes."""

    LOW_LATENCY = auto()
    ELASTIC = auto()


class DEPLOYMENT_STATUS(LowercaseStrEnum):
    """Enumeration for deployments status."""

    CREATION_PENDING = auto()
    UP = auto()
    CREATION_FAILED = auto()
    DOWN_RETRYING = auto()
    STANDBY = auto()
    DISABLED = auto()


CREATION_REQUESTS_RETRY_INTERVAL = 10


class CREATION_PARAMETER_VALUE(Enum):
    """Enumeration for creation parameters special values."""

    #: Special value to indicate that the parameter should be set to the
    #: project information value.
    FALLBACK_PROJECT = "FALLBACK_PROJECT"
    #: Special value to indicate that the parameter should be set to `None`.
    NULL = "NULL"
