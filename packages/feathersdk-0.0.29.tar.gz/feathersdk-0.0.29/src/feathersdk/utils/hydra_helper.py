from hydra import initialize_config_dir, compose
from omegaconf import OmegaConf
from feathersdk.utils.feathertypes import Any, Dict
import math


def load_hydra_config(config_dir: str, config_name: str) -> Dict[str, Any]:
    with initialize_config_dir(version_base=None, config_dir=config_dir):
        cfg_tree = compose(config_name=config_name)

    OmegaConf.register_new_resolver(
        "deg2rad",
        lambda deg: float(deg) * math.pi / 180.0,
        replace=True,
    )

    # Resolved config
    cfg = OmegaConf.to_container(
        cfg_tree,
        resolve=True,
        throw_on_missing=True
    )
    return cfg
