from machine import ADC

ADC_GP_PIN = 26  # pin 33, ADC0

# Linear map: divider_read at these points → battery voltage (V). Same slope extrapolates outside [48, 56].
_DIVIDER_LOW = 2.545
_DIVIDER_HIGH = 2.97
_VOLTAGE_LOW = 48.0
_VOLTAGE_HIGH = 56.0
_SLOPE = (_VOLTAGE_HIGH - _VOLTAGE_LOW) / (_DIVIDER_HIGH - _DIVIDER_LOW)

divider_read = ADC(ADC_GP_PIN).read_u16() * 3.3 / 65535
battery_voltage = _VOLTAGE_LOW + (divider_read - _DIVIDER_LOW) * _SLOPE
print(battery_voltage, divider_read)
