Optimizer
=========

.. automodule:: sf_quant.optimizer
   :no-members:
   :no-undoc-members:
   :no-imported-members:

.. currentmodule:: sf_quant.optimizer

.. autosummary::
   :toctree: optimizer
   :nosignatures:

   mve_optimizer
   dynamic_mve_optimizer
   FullInvestment
   ZeroInvestment
   LongOnly
   NoBuyingOnMargin
   UnitBeta
   ZeroBeta