# Copyright 2019 Camptocamp (https://www.camptocamp.com)
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

from odoo import fields
from odoo.tests import common, tagged


@tagged("post_install", "-at_install")
class PromiseReleaseCommonCase(common.TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.env = cls.env(context=dict(cls.env.context, tracking_disable=True))
        cls.wh = cls.env["stock.warehouse"].create(
            {
                "name": "Test Warehouse",
                "reception_steps": "one_step",
                "delivery_steps": "pick_ship",
                "code": "WHTEST",
                "delivery_pull": True,
            }
        )
        cls.loc_stock = cls.wh.lot_stock_id
        cls.loc_customer = cls.env.ref("stock.stock_location_customers")
        cls.product1 = cls.env["product.product"].create(
            {"name": "Product 1", "type": "consu", "is_storable": True}
        )
        cls.product2 = cls.env["product.product"].create(
            {"name": "Product 2", "type": "consu", "is_storable": True}
        )
        cls.product3 = cls.env["product.product"].create(
            {"name": "Product 3", "type": "consu", "is_storable": True}
        )
        cls.product4 = cls.env["product.product"].create(
            {"name": "Product 4", "type": "consu", "is_storable": True}
        )
        cls.uom_unit = cls.env.ref("uom.product_uom_unit")
        cls.partner_delta = cls.env.ref("base.res_partner_4")
        cls.loc_bin1 = cls.env["stock.location"].create(
            {"name": "Bin1", "location_id": cls.loc_stock.id}
        )

    @classmethod
    def _create_procurement_group(cls, move_type="direct"):
        cls.group = cls.env["procurement.group"].create(
            {
                "name": "TEST",
                "move_type": move_type,
                "partner_id": cls.partner_delta.id,
            }
        )

    @classmethod
    def _create_picking_chain(cls, wh, products=None, date=None, move_type="direct"):
        """Create picking chain

        It runs the procurement group to create the moves required for
        a product. According to the WH, it creates the pick+ship
        moves.

        Products must be a list of tuples (product, quantity) or
        (product, quantity, uom).
        One stock move will be created for each tuple.
        """

        if products is None:
            products = []

        cls._create_procurement_group(move_type=move_type)
        values = {
            "company_id": wh.company_id,
            "group_id": cls.group,
            "date_planned": date or fields.Datetime.now(),
            "warehouse_id": wh,
        }

        for row in products:
            if len(row) == 2:
                product, qty = row
                uom = product.uom_id
            elif len(row) == 3:
                product, qty, uom = row
            else:
                raise ValueError(
                    "Expect (product, quantity, uom) or (product, quantity)"
                )

            cls.env["procurement.group"].run(
                [
                    cls.env["procurement.group"].Procurement(
                        product,
                        qty,
                        uom,
                        cls.loc_customer,
                        "TEST",
                        "TEST",
                        wh.company_id,
                        values,
                    )
                ]
            )
        pickings = cls._pickings_in_group(cls.group)
        pickings.move_ids.write({"date_priority": date or fields.Datetime.now()})
        return pickings

    @classmethod
    def _pickings_in_group(cls, group, include_cancel=True):
        domain = [("group_id", "=", group.id)]
        if not include_cancel:
            domain.append(("state", "!=", "cancel"))
        return cls.env["stock.picking"].search(domain)

    @classmethod
    def _update_qty_in_location(cls, location, product, quantity):
        quants = cls.env["stock.quant"]._gather(product, location, strict=True)
        # this method adds the quantity to the current quantity, so remove it
        quantity -= sum(quants.mapped("quantity"))
        cls.env["stock.quant"]._update_available_quantity(product, location, quantity)
        cls.env["product.product"].invalidate_model(
            fnames=[
                "qty_available",
                "virtual_available",
                "incoming_qty",
                "outgoing_qty",
            ]
        )

    @classmethod
    def _prev_picking(cls, picking):
        return picking.move_ids.move_orig_ids.picking_id

    @classmethod
    def _out_picking(cls, pickings):
        return pickings.filtered(lambda r: r.picking_type_code == "outgoing")

    @classmethod
    def _get_backorder_for_pickings(cls, pickings):
        return cls.env["stock.picking"].search([("backorder_id", "in", pickings.ids)])

    @classmethod
    def _deliver(cls, picking, product_qty=None):
        picking.action_assign()
        if product_qty:
            lines = picking.move_ids.move_line_ids
            for product, qty in product_qty:
                line = lines.filtered(
                    lambda m, product=product: m.product_id == product
                )
                line.quantity = qty
                line.is_inventory = True
                line.picked = True
        else:
            for line in picking.move_ids.move_line_ids:
                line.picked = True
        picking._action_done()
