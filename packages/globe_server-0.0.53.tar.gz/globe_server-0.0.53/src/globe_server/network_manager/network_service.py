"""External API for network management functionality."""

import logging
from typing import List
from .network_fsm import NetworkFSM
from .models import NetworkInfo, NetworkState
from .platform import scan_networks, is_ap_mode_active
import asyncio

logger = logging.getLogger(__name__)

# Create global FSM instance that manages all network operations
logger.info("Creating network FSM instance...")
network_manager = NetworkFSM()
_initialized = False
_network_cache: List[NetworkInfo] = []


async def populate_network_cache() -> None:
    """Scan for networks and store the result in the cache."""
    global _network_cache
    logger.info("Populating network scan cache...")
    try:
        _network_cache = await scan_networks()
        logger.info(f"Network cache populated with {len(_network_cache)} networks")
    except Exception as e:
        logger.error(f"Failed to populate network cache: {e}")


def get_cached_networks() -> List[NetworkInfo]:
    """Return the cached network scan result."""
    return _network_cache

async def initialize_network_manager():
    """Initialize the network manager - should be called during app startup."""
    global _initialized
    if not _initialized:
        logger.info("Starting network state machine")
        await network_manager.start()
        logger.info("Transitioning network state machine to IDLE state")
        logger.info(f"Current FSM state before transition: {network_manager.context.current_state}")
        result = await network_manager.transition_to(NetworkState.IDLE)
        logger.info(f"Transition result: {result}")
        logger.info(f"Current FSM state after transition: {network_manager.context.current_state}")
        _initialized = True
        logger.info("Network state machine initialized")

async def shutdown_network_manager():
    """Shutdown the network manager - should be called during app shutdown."""
    global _initialized
    if _initialized:
        logger.info("Shutting down network manager")
        await network_manager.stop()
        _initialized = False
        logger.info("Network manager shut down")

async def connect_to_wifi(ssid: str, password: str) -> bool:
    """
    Request to connect to a specific WiFi network.
    Only accepted when in CONNECTED state - both devices must switch together.
    """
    if network_manager.context.current_state != NetworkState.CONNECTED:
        logger.warning(f"Cannot switch network - not in CONNECTED state (current: {network_manager.context.current_state.value})")
        return False

    return await network_manager.request_network_test(ssid, password)

async def scan_available_networks(force: bool = False) -> List[NetworkInfo]:
    """
    Return available WiFi networks.
    Uses cached results by default. Pass force=True to trigger a live scan
    and update the cache.

    Returns:
        List[NetworkInfo]: List of discovered networks
    """
    if force:
        await populate_network_cache()
    return get_cached_networks()