"""Linux-specific network operations using direct nmcli subprocess calls."""

import logging
import asyncio
from typing import List, Optional, Tuple

from .base_network import BaseNetworkManager, NetworkError
from globe_server.network_manager.models import NetworkInfo, ConnectionInfo, ConnectionType
from globe_server import config

logger = logging.getLogger(__name__)


class LinuxNetworkManager(BaseNetworkManager):
    """Linux-specific network operations using direct nmcli subprocess calls."""

    async def run_command(self, cmd: list[str]) -> Tuple[str, str]:
        """Run a system command asynchronously, returning (stdout, stderr)."""
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            return stdout.decode().strip(), stderr.decode().strip()
        except Exception as e:
            logger.error(f"Error running command {' '.join(cmd)}: {str(e)}", exc_info=True)
            raise NetworkError(f"Command execution failed: {str(e)}")

    async def _get_wifi_interface(self) -> Optional[str]:
        """Return the name of the first wifi interface found."""
        stdout, _ = await self.run_command([
            "nmcli", "-t", "-f", "DEVICE,TYPE", "device", "status"
        ])
        for line in stdout.splitlines():
            parts = line.split(":")
            if len(parts) >= 2 and parts[1] == "wifi":
                return parts[0]
        return None

    async def get_current_connection_info(self) -> ConnectionInfo:
        try:
            if await self.is_ap_mode_active():
                ip_address = await self._get_ip_for_interface("wlan0")
                return ConnectionInfo(
                    type=ConnectionType.AP,
                    ssid=config.AP_SSID,
                    ip_address=ip_address,
                    interface_name="wlan0",
                    is_connected=True
                )

            # Get active wifi connection: fields DEVICE,SSID,ACTIVE
            stdout, _ = await self.run_command([
                "nmcli", "-t", "-f", "DEVICE,SSID,ACTIVE,TYPE", "device", "wifi"
            ])

            interface_name = None
            ssid = None
            for line in stdout.splitlines():
                parts = line.split(":")
                # parts: device, ssid, active, type
                if len(parts) >= 4 and parts[2] == "yes" and parts[3] == "wifi":
                    interface_name = parts[0]
                    ssid = parts[1]
                    break

            if not interface_name:
                return ConnectionInfo(
                    type=ConnectionType.NONE,
                    ssid=None,
                    ip_address=None,
                    interface_name=None,
                    is_connected=False
                )

            # Get IP address for the interface
            ip_address = await self._get_ip_for_interface(interface_name)

            return ConnectionInfo(
                type=ConnectionType.WIFI,
                ssid=ssid,
                ip_address=ip_address,
                interface_name=interface_name,
                is_connected=True
            )

        except Exception as e:
            logger.error(f"Failed to get network info: {e}")
            return ConnectionInfo(
                type=ConnectionType.NONE,
                ssid=None,
                ip_address=None,
                interface_name=None,
                is_connected=False
            )

    async def _get_ip_for_interface(self, interface: str) -> Optional[str]:
        """Get the IPv4 address for a given interface via nmcli device show."""
        try:
            stdout, _ = await self.run_command([
                "nmcli", "-t", "-f", "IP4.ADDRESS", "device", "show", interface
            ])
            for line in stdout.splitlines():
                # e.g. IP4.ADDRESS[1]:192.168.1.10/24
                if line.startswith("IP4.ADDRESS"):
                    value = line.split(":", 1)[-1]
                    return value.split("/")[0]
        except Exception as e:
            logger.error(f"Failed to get IP for interface {interface}: {e}")
        return None

    async def is_ap_mode_active(self) -> bool:
        try:
            stdout, _ = await self.run_command([
                "nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status"
            ])
            for line in stdout.splitlines():
                parts = line.split(":")
                # parts: device, type, state, connection
                if len(parts) >= 4 and parts[1] == "wifi" and parts[2] == "connected":
                    if "hotspot" in parts[3].lower():
                        return True
            return False
        except Exception as e:
            logger.error(f"Error checking AP mode: {e}")
            return False

    async def enable_ap_mode(self) -> bool:
        try:
            _, stderr = await self.run_command([
                "nmcli", "device", "wifi", "hotspot",
                "con-name", "globe-hotspot",
                "ssid", config.AP_SSID,
                "password", config.AP_PASSWORD
            ])
            if stderr:
                logger.error(f"AP mode enable failed: {stderr}")
                return False
            return True
        except Exception as e:
            logger.error(f"Error enabling AP mode: {e}")
            return False

    async def disable_ap_mode(self) -> bool:
        try:
            _, stderr = await self.run_command([
                "nmcli", "connection", "down", "globe-hotspot"
            ])
            if stderr:
                logger.error(f"AP mode disable failed: {stderr}")
                return False
            return True
        except Exception as e:
            logger.error(f"Error disabling AP mode: {e}")
            return False

    async def _profile_exists(self, ssid: str) -> bool:
        """Check if a saved connection profile exists for the given SSID."""
        stdout, _ = await self.run_command([
            "nmcli", "-t", "-f", "NAME", "connection", "show"
        ])
        return ssid in stdout.splitlines()

    async def connect_to_network(self, ssid: str, password: str) -> bool:
        try:
            if await self._profile_exists(ssid):
                # Profile exists - patch it to ensure key-mgmt is set, then bring it up
                logger.info(f"Existing profile found for {ssid}, patching and reconnecting")
                _, stderr = await self.run_command([
                    "nmcli", "connection", "modify", ssid,
                    "802-11-wireless-security.key-mgmt", "wpa-psk",
                    "802-11-wireless-security.psk", password
                ])
                if stderr:
                    logger.error(f"Failed to patch profile for {ssid}: {stderr}")
                    return False
                _, stderr = await self.run_command([
                    "nmcli", "connection", "up", ssid
                ])
                if stderr:
                    logger.error(f"Failed to bring up connection {ssid}: {stderr}")
                    return False
                return True
            else:
                # No existing profile - create one explicitly so key-mgmt is always set
                logger.info(f"No existing profile for {ssid}, creating and connecting")
                interface = await self._get_wifi_interface()
                cmd = [
                    "nmcli", "connection", "add",
                    "type", "wifi",
                    "con-name", ssid,
                    "ifname", interface or "wlan0",
                    "ssid", ssid,
                    "--",
                    "802-11-wireless-security.key-mgmt", "wpa-psk",
                    "802-11-wireless-security.psk", password
                ]
                _, stderr = await self.run_command(cmd)
                if stderr:
                    logger.error(f"Failed to create profile for {ssid}: {stderr}")
                    return False
                _, stderr = await self.run_command([
                    "nmcli", "connection", "up", ssid
                ])
                if stderr:
                    logger.error(f"Failed to bring up connection {ssid}: {stderr}")
                    return False
                return True

        except Exception as e:
            logger.error(f"Error connecting to network: {e}", exc_info=True)
            return False

    async def disconnect_from_network(self) -> bool:
        try:
            conn_info = await self.get_current_connection_info()

            if not conn_info.is_connected:
                logger.info("No active connection to disconnect from")
                return True

            if conn_info.type == ConnectionType.AP:
                return await self.disable_ap_mode()

            if conn_info.interface_name:
                _, stderr = await self.run_command([
                    "nmcli", "device", "disconnect", conn_info.interface_name
                ])
                if stderr:
                    logger.error(f"Disconnect failed: {stderr}")
                    return False
                return True
            else:
                logger.error("No interface name found for current connection")
                return False
        except Exception as e:
            logger.error(f"Error disconnecting from network: {e}", exc_info=True)
            return False

    async def scan_networks(self) -> List[NetworkInfo]:
        try:
            # Trigger a rescan (best-effort, ignore errors)
            try:
                await self.run_command(["nmcli", "device", "wifi", "rescan"])
            except Exception:
                pass

            stdout, _ = await self.run_command([
                "nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi"
            ])

            seen = set()
            networks = []
            for line in stdout.splitlines():
                parts = line.split(":")
                if len(parts) < 3:
                    continue
                ssid, signal_str, security = parts[0], parts[1], parts[2]
                if not ssid or ssid in seen:
                    continue
                seen.add(ssid)
                try:
                    signal = int(signal_str)
                except ValueError:
                    signal = 0
                networks.append(NetworkInfo(
                    ssid=ssid,
                    signal_strength=signal,
                    security=security if security else "none"
                ))

            return sorted(networks, key=lambda x: x.signal_strength, reverse=True)

        except Exception as e:
            logger.error(f"Error scanning networks: {str(e)}")
            return []
