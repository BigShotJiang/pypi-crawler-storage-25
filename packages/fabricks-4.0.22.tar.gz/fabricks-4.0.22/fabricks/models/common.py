"""Common types and type aliases used across all models."""

from typing import Literal

from pydantic import BaseModel, ConfigDict

from fabricks.models.config import config

# Mode type definitions
AllowedModesBronze = Literal["memory", "append", "register"]
AllowedModesSilver = Literal["memory", "append", "latest", "update", "combine"]
AllowedModesGold = Literal["memory", "append", "complete", "update", "invoke", "register"]
AllowedModes = Literal[AllowedModesBronze, AllowedModesSilver, AllowedModesGold]

# File and operation types
AllowedFileFormats = Literal["json_array", "json", "jsonl", "csv", "parquet", "delta"]
AllowedOperations = Literal["upsert", "reload", "delete"]
AllowedTypes = Literal["manual", "default"]
AllowedOrigins = Literal["parser", "parent", "wait_for"]
AllowedFileFormatsRegister = Literal["delta", "parquet"]

# Constraint types
AllowedConstraintOptions = Literal["not enforced", "deferrable", "initially deferred", "norely", "rely"]
AllowedForeignKeyOptions = Literal["match full", "on update no action", "on delete no action"]

# Change Data Capture types
AllowedChangeDataCaptures = Literal["nocdc", "scd0", "scd1", "scd2"]


class SparkOptions(BaseModel):
    """Spark SQL and configuration options."""

    model_config = ConfigDict(extra=config.extra_config, frozen=True)

    sql: dict[str, str | bool | int] | None = None
    conf: dict[str, str | bool | int] | None = None


class BaseInvokerOptions(BaseModel):
    """Options for invoking notebooks during pre/post run operations."""

    model_config = ConfigDict(extra=config.extra_config, frozen=True)

    notebook: str | None = None
    timeout: int | None = None
    arguments: dict[str, str | bool | int] | None = None


class InvokerOptions(BaseModel):
    """Grouped invoker operations for pre/run/post execution."""

    model_config = ConfigDict(extra=config.extra_config, frozen=True)

    pre_run: list[BaseInvokerOptions] | None = None
    run: list[BaseInvokerOptions] | None = None
    post_run: list[BaseInvokerOptions] | None = None


class ExtenderOptions(BaseModel):
    """Configuration for runtime extenders."""

    model_config = ConfigDict(extra=config.extra_config, frozen=True)

    extender: str
    arguments: dict[str, str] | None = None


class UpdaterOptions(BaseModel):
    """Configuration for runtime updaters."""

    model_config = ConfigDict(extra=config.extra_config, frozen=True)

    columns: dict[str, str] | None = None


class RegisterOptions(BaseModel):
    """Options for registering tables."""

    model_config = ConfigDict(extra=config.extra_config, frozen=True)

    uri: str | None = None
    file_format: AllowedFileFormatsRegister | None = None


class DatabasePathOptions(BaseModel):
    """Path configuration for databases."""

    model_config = ConfigDict(extra=config.extra_config, frozen=True)

    storage: str


class Database(BaseModel):
    """Database configuration."""

    model_config = ConfigDict(extra=config.extra_config, frozen=True)

    name: str
    path_options: DatabasePathOptions
