"""Configuration models."""

import logging
import os
from typing import Literal

from pydantic import AliasChoices, BaseModel, ConfigDict, Field, computed_field, field_validator
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict

from fabricks.models.config.utils import HierarchicalFileSettingsSource
from fabricks.utils.path import GitPath, resolve_git_path

# Clean environment variables set to "none" (case-insensitive)
for var in os.environ:
    if var.startswith("FABRICKS_"):
        if os.environ[var].lower() == "none":
            del os.environ[var]


class ResolvedPathOptions(BaseModel):
    """Resolved path objects for main configuration."""

    model_config = ConfigDict(extra="allow", frozen=True, arbitrary_types_allowed=True)

    base: GitPath
    config: GitPath
    runtime: GitPath
    notebooks: GitPath
    variable: GitPath | None = None


class ConfigOptions(BaseSettings):
    """Main configuration options for Fabricks framework."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    base: str = Field(
        validation_alias=AliasChoices("FABRICKS_BASE", "base"),
        default="none",
    )
    path_to_config: str = Field(
        validation_alias=AliasChoices("FABRICKS_PATH_TO_CONFIG", "path_to_config"),
        default="none",
    )
    config: str = Field(
        validation_alias=AliasChoices("FABRICKS_CONFIG", "config"),
        default="none",
    )
    runtime: str = Field(
        validation_alias=AliasChoices("FABRICKS_RUNTIME", "runtime"),
        default="none",
    )
    variable: str | None = Field(
        validation_alias=AliasChoices("FABRICKS_VARIABLE", "variable"),
        default=None,
    )
    notebooks: str = Field(
        validation_alias=AliasChoices("FABRICKS_NOTEBOOKS", "notebooks"),
        default="none",
    )
    job_config_from_yaml: bool = Field(
        validation_alias=AliasChoices("FABRICKS_IS_JOB_CONFIG_FROM_YAML", "job_config_from_yaml"),
        default=False,
    )
    debugmode: bool = Field(
        validation_alias=AliasChoices("FABRICKS_IS_DEBUGMODE", "debugmode"),
        default=False,
    )
    funmode: bool = Field(
        validation_alias=AliasChoices("FABRICKS_IS_FUNMODE", "funmode"),
        default=False,
    )
    devmode: bool = Field(
        validation_alias=AliasChoices("FABRICKS_IS_DEVMODE", "devmode"),
        default=False,
    )
    testmode: bool = Field(
        validation_alias=AliasChoices("FABRICKS_IS_TESTMODE", "testmode"),
        default=False,
    )
    loglevel: int = Field(
        validation_alias=AliasChoices("FABRICKS_LOGLEVEL", "loglevel"),
        default=20,
    )
    extra_config: Literal["allow", "ignore", "forbid"] = Field(
        validation_alias=AliasChoices("FABRICKS_EXTRA_CONFIG", "extra_config"),
        default="ignore",
    )

    @field_validator("job_config_from_yaml", "debugmode", "funmode", "devmode", mode="before")
    @classmethod
    def validate_bool(cls, v):
        """
        Convert common string representations of boolean values to bool.

        Accepted case-insensitive string values are:
        - "true", "1", "yes" -> True
        - "false", "0", "no" -> False

        Non-string inputs or strings not matching the above values are returned unchanged.
        """
        if isinstance(v, bool):
            return v

        if isinstance(v, str):
            v_lower = str(v).lower()
            if v_lower in ("true", "1", "yes"):
                return True
            elif v_lower in ("false", "0", "no"):
                return False

        return v

    @field_validator("loglevel", mode="before")
    @classmethod
    def validate_loglevel(cls, v):
        """Validate log level."""
        if isinstance(v, str):
            levels = {
                "DEBUG": logging.DEBUG,
                "INFO": logging.INFO,
                "WARNING": logging.WARNING,
                "ERROR": logging.ERROR,
                "CRITICAL": logging.CRITICAL,
            }
            v_upper = v.upper()
            if v_upper in levels:
                return levels[v_upper]

            return logging.INFO  # Default log level

        return v

    @field_validator("notebooks", mode="before")
    @classmethod
    def validate_notebooks(cls, v):
        """Set default notebooks path if not provided."""
        if not v or v.lower() == "none":
            return "runtime/notebooks"

        return v

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ):
        # Order: env vars > hierarchical file > defaults
        return (
            init_settings,
            env_settings,
            HierarchicalFileSettingsSource(settings_cls),
            file_secret_settings,
        )

    def _resolve_paths(self) -> ResolvedPathOptions:
        """
        Get all paths resolved as Path objects.

        Args:
            runtime: The base runtime path (e.g., PATH_RUNTIME)

        Returns:
            ResolvedPathOptions with all paths resolved
        """
        # Collect all storage paths with variable substitution
        root = GitPath(self.base)

        return ResolvedPathOptions(
            base=resolve_git_path(path=self.base),
            config=resolve_git_path(path=self.config, base=root),
            runtime=resolve_git_path(path=self.runtime, base=root),
            notebooks=resolve_git_path(path=self.notebooks, base=root),
            variable=resolve_git_path(path=self.variable, base=root) if self.variable else None,
        )

    @computed_field
    @property
    def resolved_paths(self) -> ResolvedPathOptions:
        """Get all paths resolved as Path objects."""
        return self._resolve_paths()


config = ConfigOptions()
