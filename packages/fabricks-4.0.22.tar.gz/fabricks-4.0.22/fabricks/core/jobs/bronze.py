import os
from functools import cached_property
from typing import Optional, Sequence, Union

from pyspark.sql import DataFrame
from pyspark.sql.functions import expr, lit
from pyspark.sql.types import Row, TimestampType

from fabricks.cdc.nocdc import NoCDC
from fabricks.context import VARIABLES
from fabricks.context.log import DEFAULT_LOGGER
from fabricks.core.jobs.base.job import BaseJob
from fabricks.core.parsers.get_parser import get_parser
from fabricks.core.parsers.utils import clean
from fabricks.metastore.view import create_or_replace_global_temp_view
from fabricks.models import JobBronzeOptions, JobDependency, ParserOptions, StepBronzeConf, StepBronzeOptions
from fabricks.utils.helpers import add_hash, backticks
from fabricks.utils.path import FileSharePath
from fabricks.utils.read import read


class Bronze(BaseJob):
    def __init__(
        self,
        step: str,
        topic: Optional[str] = None,
        item: Optional[str] = None,
        job_id: Optional[str] = None,
        conf: Optional[Union[dict, Row]] = None,
    ):
        super().__init__(
            "bronze",
            step=step,
            topic=topic,
            item=item,
            job_id=job_id,
            conf=conf,
        )

    @property
    def stream(self) -> bool:
        return self.mode not in ["register"]

    @property
    def schema_drift(self) -> bool:
        return True

    @property
    def persist(self) -> bool:
        return self.mode in ["append", "register"]

    @property
    def virtual(self) -> bool:
        return False

    @property
    def options(self) -> JobBronzeOptions:
        """Direct access to typed bronze job options."""
        return self.conf.options  # type: ignore

    @property
    def step_conf(self) -> StepBronzeConf:
        """Direct access to typed bronze step conf."""
        return self.base_step_conf  # type: ignore

    @property
    def step_options(self) -> StepBronzeOptions:
        """Direct access to typed bronze step options."""
        return self.base_step_conf.options  # type: ignore

    @classmethod
    def from_job_id(cls, step: str, job_id: str, *, conf: Optional[Union[dict, Row]] = None):
        return cls(step=step, job_id=job_id, conf=conf)

    @classmethod
    def from_step_topic_item(cls, step: str, topic: str, item: str, *, conf: Optional[Union[dict, Row]] = None):
        return cls(step=step, topic=topic, item=item, conf=conf)

    @property
    def data_path(self) -> FileSharePath:
        uri = self.options.uri
        assert uri is not None, "no uri provided in options"
        path = FileSharePath.from_uri(uri, regex=VARIABLES)
        return path

    def get_dependencies(self, *s) -> Sequence[JobDependency]:
        dependencies = []

        parents = self.options.parents or []
        if parents:
            for p in parents:
                dependencies.append(JobDependency.from_parts(self.job_id, p, "parent"))

        wait_for = self.options.wait_for or []
        if wait_for:
            for w in wait_for:
                dependencies.append(JobDependency.from_parts(self.job_id, w, "wait_for"))

        return dependencies

    def register_external_table(self):
        options = self.conf.parser_options  # type: ignore
        if options and options.file_format:
            file_format = options.file_format
        else:
            file_format = "delta"

        DEFAULT_LOGGER.debug(f"register external table ({self.data_path})", extra={"label": self})

        try:
            df = self.spark.sql(f"select * from {file_format}.`{self.data_path}`")

            assert len(df.columns) > 1, "external table must have at least one column"
            if "__timestamp" in df.columns:
                assert isinstance(df.schema["__timestamp"].dataType, TimestampType), (
                    "__timestamp must be of type timestamp"
                )

        except Exception as e:
            DEFAULT_LOGGER.exception("read external table failed", extra={"label": self})
            raise e

        self._register_external_table(file_format=file_format, uri=self.data_path.string)

    def compute_statistics_external_table(self):
        DEFAULT_LOGGER.debug("compute statistics (external table)", extra={"label": self})
        self.spark.sql(f"analyze table {self.qualified_name} compute statistics")

    def vacuum_external_table(self, retention_hours: Optional[int] = 168):
        from delta import DeltaTable

        DEFAULT_LOGGER.debug("vacuum (external table)", extra={"label": self})
        try:
            dt = DeltaTable.forPath(self.spark, self.data_path.string)
            self.spark.sql("SET self.spark.databricks.delta.retentionDurationCheck.enabled = False")
            dt.vacuum(retention_hours)
        finally:
            self.spark.sql("SET self.spark.databricks.delta.retentionDurationCheck.enabled = True")

    def maintain_external_table(
        self,
        vacuum: Optional[bool] = True,
        compute_statistics: Optional[bool] = True,
    ):
        DEFAULT_LOGGER.debug("maintain (external table)", extra={"label": self})
        if vacuum:
            self.vacuum_external_table()

        if compute_statistics:
            self.compute_statistics_external_table()

    @cached_property
    def parser(self) -> str:
        assert self.mode not in ["register"], f"{self.mode} not allowed"
        parser = self.options.parser
        assert parser is not None, "parser not found"
        return parser

    def parse(self, stream: bool = False) -> DataFrame:
        """
        Parses the data based on the specified mode and returns a DataFrame.

        Args:
            stream (bool, optional): Indicates whether the data should be read as a stream. Defaults to False.

        Returns:
            DataFrame: The parsed data as a DataFrame.
        """
        options = self.conf.parser_options or None  # type: ignore

        if self.mode == "register":
            if stream:
                df = read(
                    stream=stream,
                    path=self.data_path,
                    file_format="delta",
                    # spark=self.spark, (BUG)
                )
            else:
                df = self.spark.sql(f"select * from {self}")

            # cleaning should be done by parser but for delta we do it here
            should_clean = True
            if options is not None and options.clean is not None:
                should_clean = options.clean
            elif self.step_options.clean is not None:
                should_clean = self.step_options.clean

            if should_clean:
                df = clean(df)

        else:
            if options is not None and options.clean is not None:
                # if parser options provided and clean set, use parser clean
                pass

            elif self.step_options.clean is not None:
                if options and options.clean is None:
                    # if parser options provided but clean not set, use step clean
                    options = options.model_copy(update={"clean": self.step_options.clean})
                elif options is None:
                    # if no parser options provided, use step clean
                    options = ParserOptions(clean=self.step_options.clean)

            parse = get_parser(self.parser, options)

            df = parse(
                stream=stream,
                data_path=self.data_path,
                schema_path=self.paths.to_schema,
                spark=self.spark,
            )

        return df

    def encrypt(self, df: DataFrame) -> DataFrame:
        encrypted_columns = self.options.encrypted_columns or []
        if encrypted_columns:
            if self.runtime_options.encryption_key is not None:
                from databricks.sdk.runtime import dbutils

                key = dbutils.secrets.get(
                    scope=self.runtime_options.secret_scope,
                    key=self.runtime_options.encryption_key,
                )
                if self.runtime_options.unity_catalog:
                    DEFAULT_LOGGER.warning(
                        "Unity Catalog enabled, use FABRICKS_ENCRYPTION_KEY instead",
                        extra={"label": self},
                    )

            else:
                key = os.environ.get("FABRICKS_ENCRYPTION_KEY")

            assert key, "encryption key not found in secrets nor in environment"

            for col in encrypted_columns:
                DEFAULT_LOGGER.debug(f"encrypt column: {col}", extra={"label": self})
                df = df.withColumn(col, expr(f"aes_encrypt({col}, '{key}')"))

        return df

    def get_data(
        self,
        stream: bool = False,
        transform: Optional[bool] = False,
        schema_only: Optional[bool] = False,
        **kwargs,
    ) -> Optional[DataFrame]:
        df = self.parse(stream)
        df = self.filter_where(df)
        df = self.encrypt(df)

        if transform:
            df = self.base_transform(df)

        if schema_only:
            df = df.limit(0)

        return df

    def add_calculated_columns(self, df: DataFrame) -> DataFrame:
        calculated_columns = self.options.calculated_columns or {}

        if calculated_columns:
            for key, value in calculated_columns.items():
                DEFAULT_LOGGER.debug(f"add calculated column ({key} -> {value})", extra={"label": self})
                df = df.withColumn(key, expr(f"{value}"))

        return df

    def add_key(self, df: DataFrame) -> DataFrame:
        if "__key" not in df.columns:
            fields = self.options.keys or []
            if fields:
                DEFAULT_LOGGER.debug(f"add key ({', '.join(fields)})", extra={"label": self})

                if "__source" in df.columns:
                    fields = fields + ["__source"]

                fields = backticks(fields)
                df = add_hash("__key", df, fields=fields)

        return df

    def add_hash(self, df: DataFrame) -> DataFrame:
        if "__hash" not in df.columns:
            fields = backticks([c for c in df.columns if not c.startswith("__")])
            DEFAULT_LOGGER.debug("add hash", extra={"label": self})

            if "__operation" in df.columns:
                fields += ["__operation == 'delete'"]

            if "__source" in df.columns:
                fields += ["__source"]

            df = add_hash("__hash", df, fields=fields)

        return df

    def add_source(self, df: DataFrame) -> DataFrame:
        if "__source" not in df.columns:
            source = self.options.source
            if source:
                DEFAULT_LOGGER.debug(f"add source ({source})", extra={"label": self})
                df = df.withColumn("__source", lit(source))

        return df

    def add_operation(self, df: DataFrame) -> DataFrame:
        if "__operation" not in df.columns:
            operation = self.options.operation
            if operation:
                DEFAULT_LOGGER.debug(f"add operation ({operation})", extra={"label": self})
                df = df.withColumn("__operation", lit(operation))

            else:
                df = df.withColumn("__operation", lit("upsert"))

        return df

    def add_metadata(self, df: DataFrame) -> DataFrame:
        if "__metadata" in df.columns:
            DEFAULT_LOGGER.debug("add metadata", extra={"label": self})

            if self.mode == "register":
                #  https://github.com/delta-io/delta/issues/2014 (BUG)
                df = df.withColumn(
                    "__metadata",
                    expr(
                        f"""
                        struct(
                            concat_ws('/', '{self.data_path}', __timestamp, __operation) as file_path,
                            __metadata.file_name as file_name,
                            __metadata.file_size as file_size,            
                            __metadata.file_modification_time as file_modification_time,
                            cast(current_date() as timestamp) as inserted
                        )
                        """
                    ),
                )

            else:
                df = df.withColumn(
                    "__metadata",
                    expr(
                        """
                        struct(
                            __metadata.file_path as file_path,
                            __metadata.file_name as file_name,
                            __metadata.file_size as file_size,            
                            __metadata.file_modification_time as file_modification_time,
                            cast(current_date() as timestamp) as inserted
                        )
                        """
                    ),
                )

        return df

    def base_transform(self, df: DataFrame) -> DataFrame:
        df = df.transform(self.extend)
        df = df.transform(self.add_calculated_columns)
        df = df.transform(self.add_hash)
        df = df.transform(self.add_operation)
        df = df.transform(self.add_source)
        df = df.transform(self.add_key)
        df = df.transform(self.add_metadata)

        return df

    def create_or_replace_view(self):
        DEFAULT_LOGGER.warning("create or replace view not allowed", extra={"label": self})

    def overwrite_schema(self, df: Optional[DataFrame] = None):
        DEFAULT_LOGGER.warning("schema overwrite not allowed", extra={"label": self})

    def get_cdc_context(self, df: DataFrame, reload: Optional[bool] = None) -> dict:
        return {}

    def for_each_batch(self, df: DataFrame, batch: Optional[int] = None, **kwargs):
        assert self.persist, f"{self.mode} not allowed"

        context = self.get_cdc_context(df)

        # if dataframe, reference is passed (BUG)
        name = f"{self.step}_{self.topic}_{self.item}__{batch}"
        global_temp_view = create_or_replace_global_temp_view(name=name, df=df, job=self)
        sql = f"select * from {global_temp_view}"

        check_df = self.spark.sql(sql)
        if check_df.isEmpty():
            DEFAULT_LOGGER.warning("no data", extra={"label": self})
            return

        assert isinstance(self.cdc, NoCDC)
        if self.mode == "append":
            self.cdc.append(sql, **context)

    def for_each_run(self, **kwargs):
        if self.mode == "register":
            DEFAULT_LOGGER.debug("register (no run)", extra={"label": self})

        elif self.mode == "memory":
            DEFAULT_LOGGER.debug("memory (no run)", extra={"label": self})

        else:
            super().for_each_run(**kwargs)

    def create(self):
        if self.mode == "register":
            self.register_external_table()

        elif self.mode == "memory":
            DEFAULT_LOGGER.info("memory (no table nor view)", extra={"label": self})

        else:
            super().create()

    def register(self):
        if self.mode == "register":
            self.register_external_table()

        elif self.mode == "memory":
            DEFAULT_LOGGER.info("memory (no table nor view)", extra={"label": self})

        else:
            super().register()

    def truncate(self):
        if self.mode == "register":
            DEFAULT_LOGGER.info("register (no truncate)", extra={"label": self})

        else:
            super().truncate()

    def restore(self, last_version: Optional[str] = None, last_batch: Optional[str] = None):
        if self.mode == "register":
            DEFAULT_LOGGER.info("register (no restore)", extra={"label": self})

        else:
            super().restore()

    def drop(self):
        if self.mode == "register":
            self._drop_external_table()

        super().drop()

    def maintain(
        self,
        vacuum: Optional[bool] = True,
        optimize: Optional[bool] = True,
        compute_statistics: Optional[bool] = True,
    ):
        if self.mode == "register":
            self.maintain_external_table(vacuum=vacuum, compute_statistics=compute_statistics)

        else:
            super().maintain(vacuum=vacuum, optimize=optimize, compute_statistics=compute_statistics)

    def vacuum(self):
        if self.mode == "memory":
            DEFAULT_LOGGER.info("memory (no vacuum)", extra={"label": self})

        elif self.mode == "register":
            self.vacuum_external_table()

        else:
            super().vacuum()

    def overwrite(self, schedule: Optional[str] = None, invoke: Optional[bool] = False):
        self.truncate()
        self.run(schedule=schedule, invoke=invoke)
