# telegram-potato-cli

Легкий Telegram-клиент в терминале для одного чата: `@RooniChat`.
Работает в обычном Linux terminal и Termux; по умолчанию включен compact-safe режим: шапка 1 строка, ввод 2 строки, без аватарки чата сверху. Ошибки пишутся в `~/.local/share/telegram-potato-cli/telegram-potato.log`.

## Установка

```bash
pip install telegram-potato-cli
telegram
```

Web-режим отдельным процессом:

```bash
telegram web --port 4823
```

Открой `http://127.0.0.1:4823`.

На Debian 12, если `pip` ругается на externally-managed-environment:

```bash
python3 -m pip install --user --break-system-packages telegram-potato-cli
~/.local/bin/telegram
```

## Возможности

- вход через QR или телефон + код;
- поддержка 2FA-пароля;
- сохранение сессии, повторный вход не нужен;
- realtime-новые и отредактированные сообщения;
- автопрокрутка как в Telegram: если ты внизу, новые сообщения двигают ленту вниз; если читаешь историю выше, позиция сохраняется;
- свои отправленные сообщения и файлы сразу появляются в ленте и прокручивают чат вниз;
- реакции обновляются после установки и через realtime updates;
- статус `печатает`;
- аватарки выключены по умолчанию; `F2` включает/выключает их вручную;
- аватарка, название, username и id чата в шапке;
- реакции, быстрые реакции `1..9`, двойной `Enter` с настраиваемой реакцией;
- HTML/Markdown/MarkdownV2/plain режимы отправки;
- встроенная команда `/ping` отправляет в чат реальный MTProto ping до Telegram;
- reply, search, delete, info panel;
- закрепление и открепление выбранного сообщения;
- админ-действия: удалить выбранное, удалить с report spam, удалить загруженную пачку, очистить историю;
- terminal mode по умолчанию отправляет текст в `auto` parse mode: `**bold**` как Markdown, `<blockquote expandable>` как HTML, `:parse md2` для базового MarkdownV2;
- отправка текста;
- отправка фото/файлов/медиа по пути, включая путь, вставленный drag-and-drop в терминал;
- скачивание и открытие выбранного медиа через `xdg-open`;
- terminal mode показывает легкий ASCII-предпросмотр фото, GIF, стикеров и Telegram video thumbnail без локального декодирования; `F3` включает/выключает превью.
- редактирование своих сообщений;
- управление стрелками, PgUp/PgDn, Home/End.
- web-интерфейс без Flask/FastAPI/React: чистый HTML/CSS/JS и stdlib asyncio HTTP server.
- кастомные web-панели без `alert/prompt`, красивый просмотр фото/видео/файлов поверх чата.
- быстрый web-load для больших чатов без сетевого lookup автора на каждое сообщение; поле ввода web закреплено снизу.
- web initial load рендерит 25 последних сообщений через быстрый `get_messages`, без массовых avatar-запросов в ленте.
- web-лента явно сортирует последние сообщения по id и обновляет существующие DOM-узлы без удаления, чтобы сообщения не пропадали при viewer/refresh.
- web отправляет в режимах Auto/HTML/Markdown/Plain и отображает Telegram entities: bold, italic, code, links, blockquote и expandable blockquote.
- web показывает ленивый предпросмотр фото, видео, GIF и webp-стикеров прямо в ленте, а медиа кэширует по message id.

## Клавиши

- `Enter` - отправить сообщение;
- `Up/Down` - выбрать сообщение;
- `PgUp/PgDn` - листать;
- `Ctrl+S` - отправить файл по пути из поля ввода;
- `Ctrl+D` - скачать медиа выбранного сообщения;
- `Ctrl+O` - открыть/посмотреть выбранное медиа;
- `Ctrl+E` - подготовить редактирование своего сообщения;
- `Ctrl+R` - ответить на выбранное сообщение;
- `F2` - включить/выключить аватарки;
- `F3` - включить/выключить предпросмотр медиа;
- `1..9` - быстрая реакция на выбранное сообщение;
- двойной `Enter` на пустом вводе - реакция по умолчанию;
- `F1` - скрыть/показать помощь;
- `Esc` - выйти.

## Команды

```text
:file /path/to/file
:photo /path/to/photo.jpg
:dl
:open
:edit новый текст
:reply
:react 👍
:defaultreact ❤️
:parse html
:parse auto
:html <b>жирный</b>
:md **жирный**
:md2 *жирный*
:search текст
:delete
:delspam
:purge yes
:clearhistory yes
:pin
:unpin
:refresh
:quit
```

Сессия, API-настройки и кэш аватарок лежат в `~/.local/share/telegram-potato-cli/`.
