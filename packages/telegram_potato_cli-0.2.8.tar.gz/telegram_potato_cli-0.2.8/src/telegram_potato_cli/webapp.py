from __future__ import annotations

import asyncio
import json
import mimetypes
import os
import random
import re
import time
import urllib.parse
from pathlib import Path
from typing import Any

import qrcode
import qrcode.image.svg
from telethon import TelegramClient, functions, types
from telethon.errors import SessionPasswordNeededError
from telethon.extensions import html as tg_html

from .app import (
    APP,
    CHAT_ID,
    CHAT_USERNAME,
    downloads_dir,
    avatars_dir,
    data_dir,
    load_config,
    log_error,
    save_config,
)

MAX_BODY = 22 * 1024 * 1024
SESSION = str(data_dir() / "potato")


def normalize_parse_mode(mode: str, text: str) -> str | None:
    selected = (mode or "auto").strip().lower().replace("-", "").replace("_", "")
    if selected in {"plain", "none", "off"}:
        return None
    if selected == "auto":
        if re.search(r"</?[a-z][\w:-]*(?:\s[^>]*)?>", text, re.I):
            return "html"
        if any(mark in text for mark in ("**", "__", "~~", "`", "[")):
            return "md"
        return None
    if selected in {"html", "htm"}:
        return "html"
    if selected in {"md", "markdown", "markdownv2", "md2"}:
        return "md"
    return None


class WebTelegram:
    def __init__(self) -> None:
        self.client: TelegramClient | None = None
        self.entity: Any = None
        self.me_id: int | None = None
        self.sender_cache: dict[int, dict[str, str]] = {}
        self.media_cache: dict[int, Path] = {}
        self.sent_code: Any = None
        self.sent_phone = ""
        self.qr: Any = None
        self.qr_status = "idle"
        self.qr_error = ""

    async def ensure_client(self) -> TelegramClient:
        if self.client:
            return self.client
        cfg = load_config()
        api_id = cfg.get("api_id")
        api_hash = cfg.get("api_hash")
        if not api_id or not api_hash:
            raise RuntimeError("api_config_required")
        self.client = TelegramClient(SESSION, int(api_id), str(api_hash))
        await self.client.connect()
        return self.client

    async def authorized(self) -> bool:
        try:
            client = await self.ensure_client()
            return bool(await client.is_user_authorized())
        except Exception:
            return False

    async def ensure_chat(self) -> None:
        client = await self.ensure_client()
        if not await client.is_user_authorized():
            raise RuntimeError("auth_required")
        if self.entity is None:
            try:
                self.entity = await client.get_entity(CHAT_USERNAME)
            except Exception:
                self.entity = await client.get_entity(CHAT_ID)
        if self.me_id is None:
            me = await client.get_me()
            self.me_id = me.id

    async def start_qr(self) -> str:
        client = await self.ensure_client()
        self.qr = await client.qr_login()
        self.qr_status = "waiting"
        self.qr_error = ""
        asyncio.create_task(self._wait_qr())
        return self.qr.url

    async def _wait_qr(self) -> None:
        try:
            await self.qr.wait()
            self.qr_status = "ok"
        except SessionPasswordNeededError:
            self.qr_status = "password"
        except Exception as exc:
            self.qr_status = "error"
            self.qr_error = str(exc)

    async def phone_start(self, phone: str) -> None:
        client = await self.ensure_client()
        self.sent_phone = phone
        self.sent_code = await client.send_code_request(phone)

    async def phone_code(self, code: str, password: str = "") -> str:
        client = await self.ensure_client()
        try:
            await client.sign_in(
                phone=self.sent_phone,
                code=code,
                phone_code_hash=self.sent_code.phone_code_hash,
            )
            return "ok"
        except SessionPasswordNeededError:
            if not password:
                return "password"
            await client.sign_in(password=password)
            return "ok"

    async def password(self, password: str) -> None:
        client = await self.ensure_client()
        await client.sign_in(password=password)

    async def message_json(self, msg: Any) -> dict[str, Any]:
        sender = getattr(msg, "sender", None)
        sender_id = getattr(sender, "id", None) or getattr(msg, "sender_id", None)
        cached = self.sender_cache.get(sender_id or 0, {})
        first = getattr(sender, "first_name", None) or ""
        last = getattr(sender, "last_name", None) or ""
        username = getattr(sender, "username", None) or ""
        name = " ".join(x for x in [first, last] if x).strip() or username or getattr(sender, "title", "") or cached.get("name") or str(sender_id or "?")
        if sender_id and (name or username):
            self.sender_cache[int(sender_id)] = {"name": name, "username": username}
        if not username:
            username = cached.get("username", "")
        reactions = []
        results = getattr(getattr(msg, "reactions", None), "results", None) or []
        for item in results:
            reaction = getattr(item, "reaction", None)
            emoji = getattr(reaction, "emoticon", None) or ("custom" if getattr(reaction, "document_id", None) else "?")
            reactions.append({"emoji": emoji, "count": getattr(item, "count", 0)})
        media = bool(getattr(msg, "media", None))
        reply_to = getattr(msg, "reply_to_msg_id", None) or 0
        reply_preview = f"message #{reply_to}" if reply_to else ""
        text = msg.message or ""
        html = ""
        entities = getattr(msg, "entities", None) or []
        if text and entities:
            with suppress_any():
                html = tg_html.unparse(text, entities)
        file_name = ""
        file_size = 0
        mime = ""
        media_kind = ""
        if media:
            if getattr(msg, "photo", None):
                media_kind = "photo"
            elif getattr(msg, "gif", None):
                media_kind = "gif"
            elif getattr(msg, "video", None):
                media_kind = "video"
            elif getattr(msg, "sticker", None):
                media_kind = "sticker"
            elif getattr(msg, "audio", None) or getattr(msg, "voice", None):
                media_kind = "audio"
            else:
                media_kind = "file"
            with suppress_any():
                file_name = msg.file.name or ""
                file_size = int(msg.file.size or 0)
                mime = msg.file.mime_type or ""
        return {
            "id": msg.id,
            "sender_id": sender_id,
            "name": name,
            "username": f"@{username}" if username else f"id:{sender_id}" if sender_id else "",
            "mine": bool(self.me_id and msg.sender_id == self.me_id),
            "text": text,
            "html": html,
            "date": msg.date.isoformat() if msg.date else "",
            "edited": bool(getattr(msg, "edit_date", None)),
            "media": media,
            "file_name": file_name,
            "file_size": file_size,
            "mime": mime,
            "media_kind": media_kind,
            "reactions": reactions,
            "reply_to": reply_to,
            "reply_preview": reply_preview,
        }

    async def messages(self, limit: int = 80, min_id: int = 0) -> list[dict[str, Any]]:
        await self.ensure_chat()
        assert self.client is not None
        safe_limit = min(max(limit, 1), 80)
        if not min_id:
            msgs = await self.client.get_messages(self.entity, limit=safe_limit)
            ordered = sorted((msg for msg in msgs if msg), key=lambda item: item.id)
            return [await self.message_json(msg) for msg in ordered]
        rows = []
        kwargs = {"limit": safe_limit, "reverse": True}
        if min_id:
            kwargs["min_id"] = min_id
        async for msg in self.client.iter_messages(self.entity, **kwargs):
            rows.append(await self.message_json(msg))
        return rows


class suppress_any:
    def __enter__(self) -> None:
        return None

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        return True


class TinyHttp:
    def __init__(self, app: WebTelegram) -> None:
        self.app = app

    async def serve(self, host: str, port: int) -> None:
        server = await asyncio.start_server(self.handle, host, port)
        addrs = ", ".join(str(sock.getsockname()) for sock in server.sockets or [])
        print(f"telegram web listening on http://127.0.0.1:{port} ({addrs})")
        async with server:
            await server.serve_forever()

    async def handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            req = await self.read_request(reader)
            status, headers, body = await self.route(req)
            await self.write(writer, status, headers, body)
        except Exception as exc:
            log_error("web_request", exc)
            await self.write(writer, 500, {"content-type": "application/json"}, jbytes({"ok": False, "error": "internal"}))
        finally:
            writer.close()
            await writer.wait_closed()

    async def read_request(self, reader: asyncio.StreamReader) -> dict[str, Any]:
        head = await reader.readuntil(b"\r\n\r\n")
        lines = head.decode("iso-8859-1").split("\r\n")
        method, target, _ = lines[0].split(" ", 2)
        headers = {}
        for line in lines[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.lower()] = v.strip()
        length = int(headers.get("content-length", "0") or 0)
        if length > MAX_BODY:
            raise RuntimeError("body_too_large")
        body = await reader.readexactly(length) if length else b""
        parsed = urllib.parse.urlsplit(target)
        return {"method": method, "path": parsed.path, "query": urllib.parse.parse_qs(parsed.query), "headers": headers, "body": body}

    async def route(self, req: dict[str, Any]) -> tuple[int, dict[str, str], bytes]:
        method = req["method"]
        path = req["path"]
        if method == "GET" and path == "/":
            return html_response(INDEX_HTML)
        if method == "GET" and path == "/api/status":
            cfg = load_config()
            return json_response({
                "ok": True,
                "configured": bool(cfg.get("api_id") and cfg.get("api_hash")),
                "authorized": await self.app.authorized(),
                "chat": CHAT_USERNAME,
            })
        if method == "POST" and path == "/api/config":
            data = parse_json(req)
            cfg = load_config()
            cfg["api_id"] = int(data["api_id"])
            cfg["api_hash"] = str(data["api_hash"])
            save_config(cfg)
            self.app.client = None
            return json_response({"ok": True})
        if method == "POST" and path == "/api/login/qr":
            url = await self.app.start_qr()
            return json_response({"ok": True, "url": url})
        if method == "GET" and path == "/api/login/qr.svg":
            if not self.app.qr:
                return json_response({"ok": False, "error": "no_qr"}, 404)
            img = qrcode.make(self.app.qr.url, image_factory=qrcode.image.svg.SvgPathImage)
            return 200, {"content-type": "image/svg+xml; charset=utf-8"}, img.to_string()
        if method == "GET" and path == "/api/login/qr/status":
            return json_response({"ok": True, "status": self.app.qr_status, "error": self.app.qr_error})
        if method == "POST" and path == "/api/login/phone":
            data = parse_json(req)
            await self.app.phone_start(data["phone"])
            return json_response({"ok": True})
        if method == "POST" and path == "/api/login/code":
            data = parse_json(req)
            status = await self.app.phone_code(str(data.get("code", "")), str(data.get("password", "")))
            return json_response({"ok": True, "status": status})
        if method == "POST" and path == "/api/login/password":
            data = parse_json(req)
            await self.app.password(str(data.get("password", "")))
            return json_response({"ok": True})
        if method == "GET" and path == "/api/messages":
            q = req["query"]
            rows = await self.app.messages(int(first(q, "limit", "80")), int(first(q, "after", "0")))
            return json_response({"ok": True, "messages": rows})
        if method == "GET" and path == "/api/search":
            await self.app.ensure_chat()
            q = first(req["query"], "q", "")
            rows = []
            async for msg in self.app.client.iter_messages(self.app.entity, search=q, limit=80, reverse=True):
                rows.append(await self.app.message_json(msg))
            return json_response({"ok": True, "messages": rows})
        if method == "GET" and path == "/api/profile":
            return await self.profile()
        if method == "POST" and path == "/api/send":
            await self.app.ensure_chat()
            data = parse_json(req)
            text = str(data.get("text", ""))
            if text == "/ping":
                started = time.perf_counter()
                await self.app.client(functions.PingRequest(ping_id=random.getrandbits(63)))
                text = f"🏓 Pong: {(time.perf_counter() - started) * 1000:.0f} ms до Telegram MTProto"
            parse_mode = normalize_parse_mode(str(data.get("parse_mode", "auto")), text)
            msg = await self.app.client.send_message(self.app.entity, text, reply_to=data.get("reply_to") or None, parse_mode=parse_mode)
            return json_response({"ok": True, "message": await self.app.message_json(msg)})
        if method == "POST" and path == "/api/react":
            await self.app.ensure_chat()
            data = parse_json(req)
            emoji = str(data.get("emoji", ""))
            reaction = [] if not emoji else [types.ReactionEmoji(emoticon=emoji)]
            await self.app.client(functions.messages.SendReactionRequest(peer=self.app.entity, msg_id=int(data["id"]), reaction=reaction))
            return json_response({"ok": True})
        if method == "POST" and path == "/api/delete":
            await self.app.ensure_chat()
            data = parse_json(req)
            if data.get("spam"):
                with suppress_any():
                    await self.app.client(functions.messages.ReportSpamRequest(peer=self.app.entity))
            await self.app.client.delete_messages(self.app.entity, [int(data["id"])], revoke=True)
            return json_response({"ok": True})
        if method == "POST" and path == "/api/pin":
            await self.app.ensure_chat()
            data = parse_json(req)
            if data.get("pin", True):
                await self.app.client.pin_message(self.app.entity, int(data["id"]), notify=False)
            else:
                await self.app.client.unpin_message(self.app.entity, int(data["id"]))
            return json_response({"ok": True})
        if method == "POST" and path == "/api/upload":
            return await self.upload(req)
        media = re.fullmatch(r"/api/media/(\d+)", path)
        if method == "GET" and media:
            return await self.media(int(media.group(1)))
        avatar = re.fullmatch(r"/api/avatar/(\d+)", path)
        if method == "GET" and avatar:
            return await self.avatar(int(avatar.group(1)))
        return json_response({"ok": False, "error": "not_found"}, 404)

    async def profile(self) -> tuple[int, dict[str, str], bytes]:
        await self.app.ensure_chat()
        entity = self.app.entity
        users = []
        with suppress_any():
            async for user in self.app.client.iter_participants(entity, limit=60):
                name = " ".join(x for x in [getattr(user, "first_name", None), getattr(user, "last_name", None)] if x).strip()
                users.append({
                    "id": user.id,
                    "name": name or getattr(user, "username", "") or str(user.id),
                    "username": f"@{user.username}" if getattr(user, "username", None) else "",
                    "bot": bool(getattr(user, "bot", False)),
                })
        return json_response({
            "ok": True,
            "id": getattr(entity, "id", CHAT_ID),
            "title": getattr(entity, "title", CHAT_USERNAME),
            "username": f"@{getattr(entity, 'username', CHAT_USERNAME)}",
            "participants": users,
        })

    async def upload(self, req: dict[str, Any]) -> tuple[int, dict[str, str], bytes]:
        await self.app.ensure_chat()
        ctype = req["headers"].get("content-type", "")
        match = re.search(r"boundary=([^;]+)", ctype)
        if not match:
            return json_response({"ok": False, "error": "multipart_required"}, 400)
        boundary = ("--" + match.group(1)).encode()
        body = req["body"]
        parts = body.split(boundary)
        file_bytes = b""
        filename = "upload.bin"
        caption = ""
        for part in parts:
            if b"\r\n\r\n" not in part:
                continue
            raw_head, content = part.split(b"\r\n\r\n", 1)
            content = content.rstrip(b"\r\n-")
            head = raw_head.decode("utf-8", "ignore")
            if 'name="caption"' in head:
                caption = content.decode("utf-8", "ignore")
            if 'name="file"' in head:
                m = re.search(r'filename="([^"]*)"', head)
                filename = Path(m.group(1) if m else "upload.bin").name
                file_bytes = content
        if not file_bytes:
            return json_response({"ok": False, "error": "no_file"}, 400)
        temp = downloads_dir() / f"web_upload_{int(time.time())}_{filename}"
        temp.write_bytes(file_bytes)
        msg = await self.app.client.send_file(self.app.entity, str(temp), caption=caption)
        return json_response({"ok": True, "message": await self.app.message_json(msg if not isinstance(msg, list) else msg[-1])})

    async def media(self, msg_id: int) -> tuple[int, dict[str, str], bytes]:
        await self.app.ensure_chat()
        cached = self.app.media_cache.get(msg_id)
        if cached and cached.exists():
            mime = mimetypes.guess_type(str(cached))[0] or "application/octet-stream"
            return 200, {"content-type": mime, "content-disposition": f'inline; filename="{cached.name}"', "cache-control": "max-age=86400"}, cached.read_bytes()
        msg = await self.app.client.get_messages(self.app.entity, ids=msg_id)
        if not msg or not msg.media:
            return json_response({"ok": False, "error": "no_media"}, 404)
        path = await msg.download_media(file=str(downloads_dir()))
        if not path:
            return json_response({"ok": False, "error": "download_failed"}, 500)
        media_path = Path(path)
        self.app.media_cache[msg_id] = media_path
        data = media_path.read_bytes()
        mime = getattr(getattr(msg, "file", None), "mime_type", None) or mimetypes.guess_type(path)[0] or "application/octet-stream"
        return 200, {"content-type": mime, "content-disposition": f'inline; filename="{media_path.name}"', "cache-control": "max-age=86400"}, data

    async def avatar(self, sender_id: int) -> tuple[int, dict[str, str], bytes]:
        await self.app.ensure_chat()
        path = avatars_dir() / f"web_{sender_id}.jpg"
        if not path.exists():
            entity = await self.app.client.get_entity(sender_id)
            got = await self.app.client.download_profile_photo(entity, file=str(path))
            if not got:
                return json_response({"ok": False}, 404)
        return 200, {"content-type": "image/jpeg", "cache-control": "max-age=86400"}, path.read_bytes()

    async def write(self, writer: asyncio.StreamWriter, status: int, headers: dict[str, str], body: bytes) -> None:
        reason = {200: "OK", 400: "Bad Request", 404: "Not Found", 500: "Server Error"}.get(status, "OK")
        base = {"content-length": str(len(body)), "connection": "close", "cache-control": "no-store"}
        base.update(headers)
        head = f"HTTP/1.1 {status} {reason}\r\n" + "".join(f"{k}: {v}\r\n" for k, v in base.items()) + "\r\n"
        writer.write(head.encode("utf-8") + body)
        await writer.drain()


def first(query: dict[str, list[str]], key: str, default: str) -> str:
    return query.get(key, [default])[0]


def parse_json(req: dict[str, Any]) -> dict[str, Any]:
    if not req["body"]:
        return {}
    return json.loads(req["body"].decode("utf-8"))


def jbytes(data: Any) -> bytes:
    return json.dumps(data, ensure_ascii=False).encode("utf-8")


def json_response(data: Any, status: int = 200) -> tuple[int, dict[str, str], bytes]:
    return status, {"content-type": "application/json; charset=utf-8"}, jbytes(data)


def html_response(text: str) -> tuple[int, dict[str, str], bytes]:
    return 200, {"content-type": "text/html; charset=utf-8"}, text.encode("utf-8")


INDEX_HTML = r"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Telegram Potato Web</title>
<style>
:root{--bg:#0b1117;--panel:#121a23;--panel2:#17222d;--line:#243241;--text:#e6edf3;--muted:#8fa3b7;--blue:#38bdf8;--green:#34d399;--red:#fb7185}
*{box-sizing:border-box}body{margin:0;height:100vh;overflow:hidden;background:#0e1621;color:var(--text);font:14px system-ui,-apple-system,Segoe UI,sans-serif}
button,input{font:inherit}.hidden{display:none!important}.app{height:100vh;background:#0e1621}
.top{position:fixed;left:0;right:0;top:0;height:56px;display:flex;align-items:center;gap:12px;padding:8px 12px;background:#17212b;border-bottom:1px solid #22303d;z-index:5}.chatava{width:40px;height:40px;border-radius:50%;background:#2aabee;display:grid;place-items:center;color:white;font-weight:900}
.title{min-width:0}.title b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.title span{font-size:12px;color:#8aa1b4}.tools{margin-left:auto;display:flex;gap:7px}.btn{border:0;background:#233241;color:#dbe6f0;border-radius:9px;padding:8px 11px;cursor:pointer}.btn:hover{background:#2b3e50}.btn.primary{background:#2aabee;color:white;font-weight:800}.btn.danger{background:#3a2028;color:#fecdd3}
.messages{position:fixed;left:0;right:0;top:56px;bottom:62px;overflow:auto;padding:18px 12px;background:#0e1621}.msg{display:grid;grid-template-columns:38px minmax(0,1fr);gap:9px;margin:0 0 10px;max-width:820px}.msg.mine{margin-left:auto;grid-template-columns:minmax(0,1fr) 38px}.ava{width:38px;height:38px;border-radius:50%;background:#243241;object-fit:cover}.avaTxt{width:38px;height:38px;border-radius:50%;background:#25384a;color:#cfe8ff;display:grid;place-items:center;font-weight:800}.bubble{background:#182533;border-radius:10px 10px 10px 2px;padding:8px 10px;min-width:0}.mine .bubble{background:#2b5278;border-radius:10px 10px 2px 10px}.meta{display:flex;gap:8px;align-items:center;color:#a8bdcf;font-size:12px;margin-bottom:4px}.meta b{color:#e6edf3}.reply{border-left:3px solid var(--green);background:rgba(52,211,153,.12);border-radius:6px;padding:5px 7px;margin:3px 0 6px;color:#d1fae5;font-size:12px;cursor:pointer}.text{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.35}.text blockquote{margin:6px 0;padding:6px 9px;border-left:3px solid var(--green);background:rgba(52,211,153,.1);border-radius:7px;color:#dff7eb}.text pre{white-space:pre-wrap;background:rgba(0,0,0,.22);border-radius:8px;padding:8px;overflow:auto}.text code{background:rgba(0,0,0,.22);border-radius:5px;padding:1px 4px}.text a{color:#7dd3fc}.reactions{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px}.reaction{background:rgba(255,255,255,.09);border:0;color:#dbeafe;border-radius:999px;padding:3px 8px;font-size:12px}.mediaCard{display:flex;align-items:center;gap:9px;margin-top:8px;background:rgba(0,0,0,.16);border-radius:9px;padding:9px;cursor:pointer}.mediaPreview{position:relative;margin-top:8px;max-width:min(390px,72vw);border-radius:11px;overflow:hidden;background:#0b1117;cursor:pointer}.mediaPreview img,.mediaPreview video{display:block;width:100%;max-height:360px;object-fit:contain;background:#05080c}.mediaBadge{position:absolute;left:8px;bottom:8px;background:rgba(5,10,16,.72);color:white;border-radius:999px;padding:4px 8px;font-size:12px}.stickerPreview{max-width:190px;background:transparent}.stickerPreview img{max-height:190px;background:transparent}.mediaIcon{width:34px;height:34px;border-radius:9px;background:#203850;display:grid;place-items:center}.replyBar{position:fixed;left:0;right:0;bottom:62px;display:none;align-items:center;justify-content:space-between;gap:10px;background:#1f2f3f;border-top:1px solid #2f4b62;color:#d1fae5;padding:7px 12px;z-index:7}.replyBar.show{display:flex}.composer{position:fixed;left:0;right:0;bottom:0;height:62px;display:grid;grid-template-columns:auto 1fr auto auto;gap:8px;padding:9px 10px;background:#17212b;border-top:1px solid #22303d;z-index:6}.composer input,.composer select{width:100%;border:0;background:#242f3d;color:var(--text);border-radius:999px;padding:12px 15px;outline:0}.composer select{width:auto;max-width:120px;appearance:none}
.login{max-width:500px;margin:7vh auto;background:rgba(18,26,35,.98);border:1px solid var(--line);border-radius:16px;padding:22px;box-shadow:0 24px 70px rgba(0,0,0,.35)}.login h2{margin:0 0 6px}.login input{width:100%;margin:7px 0;padding:11px;border-radius:10px;border:1px solid var(--line);background:#0b1117;color:white}.row{display:flex;gap:8px;flex-wrap:wrap}.status{color:var(--muted);margin:8px 0}.qr{background:white;padding:10px;border-radius:12px;width:220px;height:220px}
.menu,.panel,.viewer{position:fixed;background:rgba(18,26,35,.98);border:1px solid var(--line);box-shadow:0 24px 70px rgba(0,0,0,.42);z-index:20}.menu{right:12px;top:62px;border-radius:12px;padding:8px;display:none;gap:7px;flex-direction:column}.menu.show{display:flex}.panel{right:12px;top:68px;width:min(420px,calc(100vw - 24px));max-height:calc(100vh - 88px);overflow:auto;border-radius:14px;padding:14px;display:none}.panel.show{display:block}.panel h3{margin:0 0 10px}.member{display:flex;align-items:center;gap:8px;padding:7px;border-bottom:1px solid #203040;color:#cbd5e1}.viewer{inset:0;display:none;place-items:center;background:rgba(4,8,12,.9);border:0}.viewer.show{display:grid}.viewerBox{max-width:94vw;max-height:90vh}.viewer img,.viewer video{max-width:94vw;max-height:82vh;border-radius:12px;background:#05080c}.viewerTop{display:flex;justify-content:space-between;gap:10px;margin-bottom:10px;color:white}.searchBox{display:flex;gap:8px;margin-bottom:10px}.searchBox input{flex:1;border:1px solid var(--line);background:#0b1117;color:white;border-radius:9px;padding:10px}
@media(max-width:650px){.tools .btn{padding:7px}.msg{max-width:100%}.app{grid-template-rows:54px 1fr 58px}.title span{display:none}}
</style></head>
<body>
<div id="login" class="login hidden"><h2>Telegram Potato Web</h2><div class="status" id="loginStatus"></div>
 <div id="apiBox"><input id="apiId" placeholder="API ID"><input id="apiHash" placeholder="API HASH"><button class="btn primary" onclick="saveApi()">Сохранить API</button></div>
 <div class="row"><button class="btn" onclick="startQr()">QR вход</button><button class="btn" onclick="phoneStart()">Телефон</button></div>
 <div id="qrBox" class="hidden"><p>Сканируй QR в Telegram -> Devices</p><img class="qr" src="/api/login/qr.svg" id="qrImg"></div>
 <input id="phone" placeholder="+79990000000"><input id="code" placeholder="Код"><input id="password" placeholder="2FA пароль" type="password"><button class="btn" onclick="sendCode()">Отправить код</button>
</div>
<div id="app" class="app hidden"><div class="top"><div class="chatava">RC</div><div class="title"><b>@RooniChat</b><span id="state">connecting</span></div><div class="tools"><button class="btn" onclick="showInfo()">Info</button><button class="btn" onclick="openSearch()">Search</button><button class="btn" onclick="refresh()">Refresh</button><button class="btn primary" onclick="pickFile()">File</button></div></div><div class="messages" id="messages"></div><div id="replyBar" class="replyBar"><span id="replyText"></span><button class="btn" onclick="cancelReply()">Cancel</button></div><form class="composer" onsubmit="send();return false"><select id="parse" title="Parse mode"><option value="auto">Auto</option><option value="html">HTML</option><option value="md">Markdown</option><option value="plain">Plain</option></select><input id="text" placeholder="Message, /ping, HTML/Markdown"><button class="btn primary">Send</button><button type="button" class="btn" onclick="pickFile()">+</button><input id="file" type="file" hidden onchange="upload()"></form></div>
<div id="menu" class="menu"><button class="btn" onclick="reply()">Reply</button><button class="btn" onclick="react('👍')">👍 Like</button><button class="btn" onclick="react('❤️')">❤️ Heart</button><button class="btn" onclick="pin(true)">Pin</button><button class="btn" onclick="pin(false)">Unpin</button><button class="btn danger" onclick="del(false)">Delete</button><button class="btn danger" onclick="del(true)">Spam+Delete</button></div>
<div id="panel" class="panel"></div><div id="viewer" class="viewer" onclick="closeViewer(event)"><div class="viewerBox"><div class="viewerTop"><b id="viewerTitle"></b><button class="btn" onclick="hideViewer()">Close</button></div><div id="viewerBody"></div></div></div>
<script>
let last=0,selected=0,replyTo=0;const $=id=>document.getElementById(id);
async function api(path,data){let r=await fetch(path,{method:data?'POST':'GET',headers:data?{'content-type':'application/json'}:{},body:data?JSON.stringify(data):null});return r.json()}
function esc(s){return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
async function boot(){let s=await api('/api/status');if(!s.configured||!s.authorized){$('login').classList.remove('hidden');$('apiBox').style.display=s.configured?'none':'block';$('loginStatus').textContent=s.configured?'Войди в Telegram':'Введи API данные';return}$('app').classList.remove('hidden');refresh();setInterval(poll,1600)}
async function saveApi(){await api('/api/config',{api_id:$('apiId').value,api_hash:$('apiHash').value});location.reload()}
async function startQr(){await api('/api/login/qr',{});$('qrBox').classList.remove('hidden');$('qrImg').src='/api/login/qr.svg?t='+Date.now();let t=setInterval(async()=>{let s=await api('/api/login/qr/status');$('loginStatus').textContent='QR: '+s.status;if(s.status==='ok'){clearInterval(t);location.reload()}},1200)}
async function phoneStart(){await api('/api/login/phone',{phone:$('phone').value});$('loginStatus').textContent='Код отправлен'} async function sendCode(){let r=await api('/api/login/code',{code:$('code').value,password:$('password').value});if(r.status==='ok')location.reload();else $('loginStatus').textContent='Нужен 2FA пароль'}
function mediaHtml(m){if(!m.media)return'';let name=esc(m.file_name||m.mime||m.media_kind||'media'),mime=m.mime||'',kind=m.media_kind||'',src='/api/media/'+m.id;if(mime.startsWith('image/')||kind==='photo')return `<div class="mediaPreview ${kind==='sticker'?'stickerPreview':''}" onclick="openMedia(${m.id},'${esc(mime)}','${name}')"><img loading=lazy src="${src}" alt="${name}"><span class=mediaBadge>${kind==='sticker'?'sticker':(mime==='image/gif'?'gif':'photo')}</span></div>`;if(mime.startsWith('video/')||kind==='video'||kind==='gif')return `<div class=mediaPreview onclick="openMedia(${m.id},'${esc(mime)}','${name}')"><video preload=metadata muted loop playsinline src="${src}"></video><span class=mediaBadge>${kind==='gif'?'gif':'video'}</span></div>`;return `<div class=mediaCard onclick="openMedia(${m.id},'${esc(mime)}','${name}')"><div class=mediaIcon>${kind==='audio'?'♪':'📎'}</div><div><b>${name}</b><br><span>${esc(mime||kind||'file')}</span></div></div>`}
function initials(n){return (n||'?').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase()||'?'}
function msgHtml(m){let ava=`<div class=avaTxt>${esc(initials(m.name))}</div>`;let reacts=(m.reactions||[]).map(r=>`<button class=reaction onclick="event.stopPropagation();react('${esc(r.emoji)}',${m.id})">${esc(r.emoji)} ${r.count}</button>`).join('');let reply=m.reply_to?`<div class=reply onclick="event.stopPropagation();jumpReply(${m.reply_to})">↩ ${esc(m.reply_preview||('#'+m.reply_to))}</div>`:'';let body=m.html||esc(m.text);let bubble=`<div class=bubble><div class=meta><b>${esc(m.name)}</b><span>${esc(m.username)}</span><span>${new Date(m.date).toLocaleTimeString()}</span></div>${reply}<div class=text>${body}</div>${mediaHtml(m)}<div class=reactions>${reacts}</div></div>`;return m.mine?bubble+ava:ava+bubble}
function render(list,{replace=false}={}){let box=$('messages'),bottom=box.scrollTop+box.clientHeight>box.scrollHeight-90;if(replace){box.innerHTML='';last=0}let frag=document.createDocumentFragment();for(let m of list){last=Math.max(last,m.id);let existing=$('m'+m.id);if(existing){existing.className='msg '+(m.mine?'mine':'');existing.innerHTML=msgHtml(m);continue}let d=document.createElement('div');d.className='msg '+(m.mine?'mine':'');d.id='m'+m.id;d.onclick=e=>select(m.id,e);d.innerHTML=msgHtml(m);frag.appendChild(d)}box.appendChild(frag);if(bottom||replace)box.scrollTop=box.scrollHeight}
function jumpReply(id){let el=$('m'+id);if(el){el.scrollIntoView({block:'center'});el.style.outline='2px solid var(--green)';setTimeout(()=>el.style.outline='',1200)}}
async function refresh(){let r=await api('/api/messages?limit=25');render(r.messages||[],{replace:true})}
async function poll(){let r=await api('/api/messages?after='+last+'&limit=40');if(r.messages&&r.messages.length)render(r.messages);$('state').textContent='online'}
async function send(){let text=$('text').value.trim();if(!text)return;let r=await api('/api/send',{text,reply_to:replyTo||null,parse_mode:$('parse').value});$('text').value='';cancelReply();if(r.message)render([r.message]);$('messages').scrollTop=$('messages').scrollHeight}
function select(id,e){selected=id;document.querySelectorAll('.msg').forEach(x=>x.style.outline='');$('m'+id).style.outline='2px solid var(--blue)';let m=$('menu');m.classList.add('show');m.style.top=Math.min(e.clientY+8,innerHeight-250)+'px'}
function reply(){replyTo=selected;$('replyText').textContent='Reply to #'+selected;$('replyBar').classList.add('show');$('text').placeholder='Reply message';$('menu').classList.remove('show');$('text').focus()}
function cancelReply(){replyTo=0;$('replyBar').classList.remove('show');$('text').placeholder='Message, /ping, HTML/Markdown'}
async function react(emoji,id){await api('/api/react',{id:id||selected,emoji});refresh()} async function pin(v){await api('/api/pin',{id:selected,pin:v});$('menu').classList.remove('show')} async function del(spam){await api('/api/delete',{id:selected,spam});$('m'+selected)?.remove();$('menu').classList.remove('show')}
function pickFile(){$('file').click()} async function upload(){let f=$('file').files[0];if(!f)return;let fd=new FormData();fd.append('file',f);let r=await fetch('/api/upload',{method:'POST',body:fd});let j=await r.json();if(j.message)render([j.message])}
function showPanel(html){$('panel').innerHTML=html;$('panel').classList.add('show')} function closePanel(){$('panel').classList.remove('show')}
function openSearch(){showPanel(`<h3>Search</h3><div class=searchBox><input id=sq placeholder="text"><button class="btn primary" onclick="runSearch()">Find</button><button class=btn onclick="closePanel()">Close</button></div><div id=sres></div>`);setTimeout(()=>$('sq').focus(),20)}
async function runSearch(){let q=$('sq').value.trim();if(!q)return;let r=await api('/api/search?q='+encodeURIComponent(q));render(r.messages||[],{replace:true});closePanel()}
async function showInfo(){let p=await api('/api/profile');let members=(p.participants||[]).map(u=>`<div class=member><img class=ava src="/api/avatar/${u.id}" onerror="this.style.visibility='hidden'"><div><b>${esc(u.name)}</b><br><span>${esc(u.username)} ${u.bot?'bot':''}</span></div></div>`).join('');showPanel(`<h3>${esc(p.title)} ${esc(p.username)}</h3><p class=status>id: ${p.id}; loaded members: ${(p.participants||[]).length}</p>${members}<p><button class=btn onclick="closePanel()">Close</button></p>`)}
function openMedia(id,mime,name){$('viewerTitle').textContent=name;let src='/api/media/'+id;if((mime||'').startsWith('image'))$('viewerBody').innerHTML=`<img src="${src}">`;else if((mime||'').startsWith('video'))$('viewerBody').innerHTML=`<video src="${src}" controls autoplay></video>`;else $('viewerBody').innerHTML=`<p>${esc(name)}</p><a class="btn primary" href="${src}" target="_blank">Download / Open</a>`;$('viewer').classList.add('show')}
function hideViewer(){$('viewer').classList.remove('show');$('viewerBody').innerHTML=''} function closeViewer(e){if(e.target.id==='viewer')hideViewer()}
document.addEventListener('click',e=>{if(!e.target.closest('.menu')&&!e.target.closest('.msg'))$('menu').classList.remove('show')});boot();
</script></body></html>"""


async def run_web(port: int = 4823, host: str = "127.0.0.1") -> None:
    await TinyHttp(WebTelegram()).serve(host, port)


def web_main(argv: list[str]) -> None:
    port = 4823
    host = "127.0.0.1"
    if "--port" in argv:
        port = int(argv[argv.index("--port") + 1])
    if "--host" in argv:
        host = argv[argv.index("--host") + 1]
    try:
        asyncio.run(run_web(port, host))
    except KeyboardInterrupt:
        print("\ntelegram web stopped")
