"""Telegram Potato CLI."""

__version__ = "0.2.8"
