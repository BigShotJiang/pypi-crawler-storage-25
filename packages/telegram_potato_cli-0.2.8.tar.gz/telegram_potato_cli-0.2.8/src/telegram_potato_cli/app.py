from __future__ import annotations

import asyncio
import curses
import getpass
import html as std_html
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import textwrap
import time
import random
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from telethon import TelegramClient, events, functions, types
from telethon.errors import SessionPasswordNeededError
from telethon.tl.types import Message, User

APP = "telegram-potato-cli"
CHAT_USERNAME = "RooniChat"
CHAT_ID = 2863094147
MAX_MESSAGES = 220
MIN_WIDTH = 56
MIN_HEIGHT = 18
AVATAR_W = 8
AVATAR_H = 4
AVATAR_JOBS = 2
MEDIA_PREVIEW_W = 30
MEDIA_PREVIEW_H = 8
MEDIA_PREVIEW_JOBS = 1
MEDIA_PREVIEW_MAX_FULL = 8 * 1024 * 1024
QUICK_REACTIONS = ["👍", "❤️", "🔥", "👏", "😁", "😢", "🤯", "😡", "🎉"]
AUTO_REFRESH_SECONDS = 45
REACTION_NAMES = {
    "👍": "+1",
    "❤️": "heart",
    "❤": "heart",
    "🔥": "fire",
    "👏": "clap",
    "😁": "smile",
    "😢": "sad",
    "🤯": "mind",
    "😡": "angry",
    "🎉": "party",
}


def data_dir() -> Path:
    root = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    path = root / APP
    path.mkdir(parents=True, exist_ok=True)
    return path


def config_path() -> Path:
    return data_dir() / "config.json"


def log_path() -> Path:
    return data_dir() / "telegram-potato.log"


def log_error(context: str, exc: BaseException | str) -> None:
    with suppress(Exception):
        with log_path().open("a", encoding="utf-8") as fh:
            fh.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {context}: {exc}\n")


def downloads_dir() -> Path:
    path = Path.home() / "Downloads" / "telegram-potato"
    path.mkdir(parents=True, exist_ok=True)
    return path


def avatars_dir() -> Path:
    path = data_dir() / "avatars"
    path.mkdir(parents=True, exist_ok=True)
    return path


def previews_dir() -> Path:
    path = data_dir() / "previews"
    path.mkdir(parents=True, exist_ok=True)
    return path


def load_config() -> dict[str, Any]:
    path = config_path()
    if not path.exists():
        return {}
    with suppress(Exception):
        return json.loads(path.read_text("utf-8"))
    return {}


def save_config(config: dict[str, Any]) -> None:
    config_path().write_text(json.dumps(config, indent=2), "utf-8")
    config_path().chmod(0o600)


def clear() -> None:
    print("\033[2J\033[H", end="")


def banner() -> None:
    clear()
    print("╔══════════════════════════════════════════════╗")
    print("║        TELEGRAM POTATO CLI / DEBIAN         ║")
    print("║     один чат, мало RAM, максимум пользы     ║")
    print("╚══════════════════════════════════════════════╝")
    print()


def ask_api_config() -> tuple[int, str]:
    config = load_config()
    api_id = config.get("api_id")
    api_hash = config.get("api_hash")
    if api_id and api_hash:
        return int(api_id), str(api_hash)

    banner()
    print("Первый запуск. Нужны Telegram API ID и API HASH с my.telegram.org.")
    print("Они сохранятся локально в ~/.local/share/telegram-potato-cli/config.json")
    print()
    while True:
        raw = input("API ID: ").strip()
        if raw.isdigit():
            api_id = int(raw)
            break
        print("API ID должен быть числом.")
    while True:
        api_hash = input("API HASH: ").strip()
        if api_hash:
            break
    config.update({"api_id": api_id, "api_hash": api_hash})
    save_config(config)
    return api_id, api_hash


def make_client() -> TelegramClient:
    api_id, api_hash = ask_api_config()
    session = str(data_dir() / "potato")
    return TelegramClient(session, api_id, api_hash)


async def qr_login(client: TelegramClient) -> bool:
    try:
        import qrcode
    except Exception:
        print("qrcode не установлен, QR-вход недоступен.")
        return False

    qr = await client.qr_login()
    print()
    print("Отсканируй QR в Telegram: Настройки -> Устройства -> Подключить устройство")
    print()
    code = qrcode.QRCode(border=1)
    code.add_data(qr.url)
    code.make(fit=True)
    code.print_ascii(tty=True)
    print()
    print("Если QR не читается, открой ссылку:")
    print(qr.url)
    print()
    print("Жду вход 90 секунд...")
    try:
        await asyncio.wait_for(qr.wait(), timeout=90)
        return True
    except asyncio.TimeoutError:
        print("QR устарел.")
        return False
    except SessionPasswordNeededError:
        password = getpass.getpass("Пароль 2FA: ")
        await client.sign_in(password=password)
        return True


async def phone_login(client: TelegramClient) -> None:
    phone = input("Телефон (+79990000000): ").strip()
    sent = await client.send_code_request(phone)
    code = input("Код из Telegram/SMS: ").strip().replace(" ", "")
    try:
        await client.sign_in(phone=phone, code=code, phone_code_hash=sent.phone_code_hash)
    except SessionPasswordNeededError:
        password = getpass.getpass("Пароль 2FA: ")
        await client.sign_in(password=password)


async def ensure_login(client: TelegramClient) -> None:
    await client.connect()
    if await client.is_user_authorized():
        return
    banner()
    print("Вход в Telegram")
    print()
    print("1 - QR code")
    print("2 - телефон + код")
    print()
    choice = input("Выбор [1/2]: ").strip()
    if choice == "1":
        ok = await qr_login(client)
        if ok:
            return
        print()
        print("Перехожу на вход по телефону.")
    await phone_login(client)


def safe_text(value: Any, width: int) -> str:
    text = str(value or "")
    text = text.replace("\n", " ").replace("\r", " ")
    if len(text) > width:
        return text[: max(0, width - 1)] + "…"
    return text


def clean_multiline(value: Any) -> str:
    text = str(value or "")
    text = text.replace("\r", "")
    return "\n".join(part.rstrip() for part in text.splitlines()).strip()


def normalize_parse_mode(mode: str | None, text: str) -> str | None:
    selected = (mode or "auto").strip().lower().replace("-", "").replace("_", "")
    if selected in {"plain", "none", "off"}:
        return None
    if selected == "auto":
        if re_html_tag(text):
            return "html"
        if any(mark in text for mark in ("**", "__", "~~", "`", "[")):
            return "md"
        return None
    if selected in {"html", "htm"}:
        return "html"
    if selected in {"md", "markdown"}:
        return "md"
    if selected in {"md2", "markdownv2"}:
        return "html"
    return None


def normalize_parse_payload(mode: str | None, text: str) -> tuple[str, str | None]:
    selected = (mode or "auto").strip().lower().replace("-", "").replace("_", "")
    if selected in {"md2", "markdownv2"}:
        return markdown_v2_to_html(text), "html"
    return text, normalize_parse_mode(mode, text)


def re_html_tag(text: str) -> bool:
    return bool(re.search(r"</?[a-z][\w:-]*(?:\s[^>]*)?>", text, re.I))


def markdown_v2_to_html(text: str) -> str:
    escaped = std_html.escape(text)
    replacements = [
        (r"\|\|(.+?)\|\|", r"<spoiler>\1</spoiler>"),
        (r"\*\*(.+?)\*\*", r"<strong>\1</strong>"),
        (r"\*(.+?)\*", r"<strong>\1</strong>"),
        (r"__(.+?)__", r"<u>\1</u>"),
        (r"_(.+?)_", r"<em>\1</em>"),
        (r"~~(.+?)~~", r"<s>\1</s>"),
        (r"~(.+?)~", r"<s>\1</s>"),
        (r"```(.+?)```", r"<pre>\1</pre>"),
        (r"`(.+?)`", r"<code>\1</code>"),
        (r"\[(.+?)\]\((https?://[^\s)]+)\)", r'<a href="\2">\1</a>'),
    ]
    for pattern, replacement in replacements:
        escaped = re.sub(pattern, replacement, escaped, flags=re.S)
    return escaped


def initials(name: str) -> str:
    parts = [p for p in name.replace("_", " ").split() if p]
    if not parts:
        return "??"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][:1] + parts[1][:1]).upper()


def xterm_color(r: int, g: int, b: int) -> int:
    if max(r, g, b) - min(r, g, b) < 10:
        gray = int(round(((r + g + b) / 3 - 8) / 10))
        return 232 + max(0, min(23, gray))
    rr = int(round(r / 255 * 5))
    gg = int(round(g / 255 * 5))
    bb = int(round(b / 255 * 5))
    return 16 + 36 * rr + 6 * gg + bb


def fit_line(text: str, width: int) -> str:
    if width <= 0:
        return ""
    return safe_text(text, width).ljust(width)


def media_label(msg: Message) -> str:
    if not msg.media:
        return ""
    name = None
    with suppress(Exception):
        name = msg.file.name
    kind = "media"
    with suppress(Exception):
        kind = msg.file.mime_type or kind
    size = ""
    with suppress(Exception):
        if msg.file.size:
            size = f" {msg.file.size // 1024}KB"
    return f"[{kind}{size}{': ' + name if name else ''}]"


def message_media_kind(msg: Message) -> str:
    if not msg.media:
        return ""
    if getattr(msg, "photo", None):
        return "photo"
    if getattr(msg, "sticker", None):
        return "sticker"
    if getattr(msg, "gif", None):
        return "gif"
    if getattr(msg, "video", None):
        return "video"
    if getattr(msg, "audio", None) or getattr(msg, "voice", None):
        return "audio"
    return "file"


def message_media_size(msg: Message) -> int:
    with suppress(Exception):
        return int(msg.file.size or 0)
    return 0


def file_kind(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tiff"}:
        return "фото"
    if ext in {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v"}:
        return "видео"
    if ext in {".mp3", ".ogg", ".flac", ".wav", ".m4a", ".opus"}:
        return "аудио"
    return "файл"


def normalize_drop_path(text: str) -> Path | None:
    raw = text.strip()
    if not raw:
        return None
    if raw.startswith("file://"):
        raw = raw[7:]
    raw = raw.strip("'\"")
    path = Path(raw).expanduser()
    if path.exists():
        return path
    return None


@dataclass
class ChatLine:
    msg: Message
    sender_name: str
    sender_username: str
    sender_id: int | None
    mine: bool
    line_count: int = 1


@dataclass
class UiState:
    lines: list[ChatLine] = field(default_factory=list)
    input_text: str = ""
    input_pos: int = 0
    scroll: int = 0
    selected: int = 0
    status: str = "готов"
    typing: str = ""
    help_open: bool = False
    running: bool = True
    dirty: bool = True
    command_mode: bool = False
    show_meta: bool = True
    info_open: bool = True
    reply_to: int | None = None
    reply_label: str = ""
    parse_mode: str | None = "auto"
    default_reaction: str = "👍"


class AvatarCache:
    def __init__(self, client: TelegramClient) -> None:
        self.client = client
        self.items: dict[int, list[list[int]] | None] = {}
        self.pending: set[int] = set()
        self.enabled = True
        self.sem = asyncio.Semaphore(AVATAR_JOBS)

    def get(self, sender_id: int | None) -> list[list[int]] | None:
        if sender_id is None:
            return None
        return self.items.get(sender_id)

    def request(self, sender: Any, dirty: Any) -> None:
        if not self.enabled:
            return
        sender_id = getattr(sender, "id", None)
        if sender_id is None or sender_id in self.items or sender_id in self.pending:
            return
        self.pending.add(sender_id)
        asyncio.create_task(self._load(sender, sender_id, dirty))

    async def _load(self, sender: Any, sender_id: int, dirty: Any) -> None:
        async with self.sem:
            try:
                photo = avatars_dir() / f"{sender_id}.jpg"
                if not photo.exists():
                    path = await self.client.download_profile_photo(sender, file=str(photo))
                    if not path:
                        self.items[sender_id] = None
                        return
                self.items[sender_id] = await asyncio.to_thread(self._render, photo)
            except Exception:
                self.items[sender_id] = None
            finally:
                self.pending.discard(sender_id)
                dirty()

    def _render(self, photo: Path) -> list[list[int]] | None:
        try:
            from PIL import Image
        except Exception:
            self.enabled = False
            return None
        with Image.open(photo) as img:
            img = img.convert("RGB")
            img.thumbnail((96, 96))
            side = min(img.size)
            left = (img.width - side) // 2
            top = (img.height - side) // 2
            img = img.crop((left, top, left + side, top + side))
            img = img.resize((AVATAR_W, AVATAR_H), Image.Resampling.LANCZOS)
            rows: list[list[int]] = []
            for y in range(AVATAR_H):
                row: list[int] = []
                for x in range(AVATAR_W):
                    row.append(xterm_color(*img.getpixel((x, y))))
                rows.append(row)
            return rows


class MediaPreviewCache:
    def __init__(self, owner: Any) -> None:
        self.owner = owner
        self.items: dict[int, list[str] | None] = {}
        self.pending: set[int] = set()
        self.enabled = bool(load_config().get("media_previews_enabled", True))
        self.sem = asyncio.Semaphore(MEDIA_PREVIEW_JOBS)

    def get(self, msg: Message) -> list[str] | None:
        return self.items.get(msg.id)

    def loading(self, msg: Message) -> bool:
        return msg.id in self.pending

    def request(self, msg: Message) -> None:
        if not self.enabled or not msg.media or msg.id in self.items or msg.id in self.pending:
            return
        kind = message_media_kind(msg)
        if kind in {"audio", "file"}:
            self.items[msg.id] = None
            return
        size = message_media_size(msg)
        if size > MEDIA_PREVIEW_MAX_FULL and kind not in {"photo", "sticker"}:
            self.items[msg.id] = None
            return
        self.pending.add(msg.id)
        asyncio.create_task(self._load(msg))

    async def _load(self, msg: Message) -> None:
        async with self.sem:
            try:
                path = await self._download_preview_file(msg)
                if not path:
                    self.items[msg.id] = None
                    return
                self.items[msg.id] = await asyncio.to_thread(self._render, Path(path), message_media_kind(msg), msg.id)
            except Exception as exc:
                log_error("media_preview", exc)
                self.items[msg.id] = None
            finally:
                self.pending.discard(msg.id)
                self.owner.mark_dirty()

    async def _download_preview_file(self, msg: Message) -> str | None:
        target = previews_dir() / f"m{msg.id}"
        for old in previews_dir().glob(f"m{msg.id}*"):
            if old.is_file():
                return str(old)
        with suppress(Exception):
            path = await self.owner.client.download_media(msg, file=str(target), thumb=0)
            if path:
                return path
        if message_media_size(msg) <= MEDIA_PREVIEW_MAX_FULL:
            return await self.owner.cached_media_path(msg, quiet=True)
        return None

    def _render(self, path: Path, kind: str, msg_id: int) -> list[str] | None:
        image_path = path
        image_exts = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tiff"}
        if path.suffix.lower() not in image_exts and kind == "video":
            return None
        try:
            from PIL import Image
        except Exception:
            return None
        chars = " .:-=+*#%@"
        try:
            with Image.open(image_path) as img:
                with suppress(Exception):
                    img.seek(0)
                img = img.convert("L")
                img.thumbnail((MEDIA_PREVIEW_W, MEDIA_PREVIEW_H), Image.Resampling.LANCZOS)
                rows: list[str] = []
                for y in range(img.height):
                    row = []
                    for x in range(img.width):
                        value = img.getpixel((x, y))
                        row.append(chars[min(len(chars) - 1, value * len(chars) // 256)])
                    rows.append("".join(row).rstrip() or ".")
                label = {"photo": "photo", "sticker": "sticker", "gif": "gif", "video": "video"}.get(kind, "media")
                return [f"[{label} preview]"] + rows[:MEDIA_PREVIEW_H]
        except Exception:
            return None


class PotatoTui:
    def __init__(self, client: TelegramClient, entity: Any) -> None:
        self.client = client
        self.entity = entity
        self.me_id: int | None = None
        self.state = UiState()
        self.loop = asyncio.get_running_loop()
        self.last_typing = 0.0
        self.last_progress = 0.0
        self.last_empty_enter = 0.0
        self.avatars = AvatarCache(client)
        self.avatars.enabled = False
        self.media_previews = MediaPreviewCache(self)
        self.media_paths: dict[int, Path] = {}
        self.bg_pairs: dict[int, int] = {}
        self.next_pair = 40
        self.chat_title = getattr(entity, "title", None) or getattr(entity, "username", None) or CHAT_USERNAME
        self.chat_username = getattr(entity, "username", None) or CHAT_USERNAME
        self.chat_id = getattr(entity, "id", None)
        self.chat_avatar: list[list[int]] | None = None
        self.refresh_task: asyncio.Task[None] | None = None
        self.state.default_reaction = str(load_config().get("default_reaction", QUICK_REACTIONS[0]))
        self.termux = bool(os.environ.get("TERMUX_VERSION"))
        if load_config().get("avatars_enabled"):
            self.avatars.enabled = True

    async def load_initial(self) -> None:
        me = await self.client.get_me()
        self.me_id = me.id
        rows: list[ChatLine] = []
        async for msg in self.client.iter_messages(self.entity, limit=80, reverse=True):
            rows.append(await self.to_line(msg))
        self.state.lines = rows[-MAX_MESSAGES:]
        self.state.selected = max(0, len(self.state.lines) - 1)
        self.state.status = "чат загружен"

    async def to_line(self, msg: Message) -> ChatLine:
        sender = await msg.get_sender()
        name = "?"
        username = ""
        sender_id = getattr(sender, "id", None)
        if isinstance(sender, User):
            pieces = [sender.first_name or "", sender.last_name or ""]
            name = " ".join(x for x in pieces if x).strip() or sender.username or str(sender.id)
            username = f"@{sender.username}" if sender.username else f"id:{sender.id}"
        elif sender is not None:
            name = getattr(sender, "title", None) or getattr(sender, "username", None) or str(getattr(sender, "id", "?"))
            user = getattr(sender, "username", None)
            username = f"@{user}" if user else f"id:{getattr(sender, 'id', '?')}"
        if sender is not None:
            self.avatars.request(sender, self.mark_dirty)
        mine = bool(self.me_id and msg.sender_id == self.me_id)
        return ChatLine(msg=msg, sender_name=name, sender_username=username, sender_id=sender_id, mine=mine)

    def mark_dirty(self) -> None:
        self.state.dirty = True

    async def load_chat_avatar(self) -> None:
        try:
            photo = avatars_dir() / f"chat_{self.chat_id or CHAT_USERNAME}.jpg"
            if not photo.exists():
                path = await self.client.download_profile_photo(self.entity, file=str(photo))
                if not path:
                    return
            self.chat_avatar = await asyncio.to_thread(self.avatars._render, photo)
        except Exception:
            self.chat_avatar = None

    def spawn(self, coro: Any, label: str = "task") -> None:
        task = asyncio.create_task(coro)

        def done(done_task: asyncio.Task[Any]) -> None:
            with suppress(asyncio.CancelledError):
                exc = done_task.exception()
                if exc:
                    log_error(label, exc)
                    self.state.status = "готов"
                    self.state.dirty = True

        task.add_done_callback(done)

    def toggle_avatars(self) -> None:
        self.avatars.enabled = not self.avatars.enabled
        config = load_config()
        config["avatars_enabled"] = self.avatars.enabled
        save_config(config)
        if not self.avatars.enabled:
            self.chat_avatar = None
        self.state.status = "аватарки включены" if self.avatars.enabled else "аватарки выключены"
        self.state.dirty = True

    def toggle_media_previews(self) -> None:
        self.media_previews.enabled = not self.media_previews.enabled
        config = load_config()
        config["media_previews_enabled"] = self.media_previews.enabled
        save_config(config)
        self.state.status = "превью медиа включены" if self.media_previews.enabled else "превью медиа выключены"
        self.state.dirty = True

    def register_events(self) -> None:
        @self.client.on(events.NewMessage(chats=self.entity))
        async def on_new(event: events.NewMessage.Event) -> None:
            at_bottom = self.is_at_bottom()
            await self.upsert_message(event.message)
            if at_bottom:
                self.go_bottom()
                self.state.status = "новое сообщение"
            else:
                self.keep_history_position()
                self.state.status = "новое ниже - End вниз"
            self.state.dirty = True

        @self.client.on(events.MessageEdited(chats=self.entity))
        async def on_edit(event: events.MessageEdited.Event) -> None:
            for i, line in enumerate(self.state.lines):
                if line.msg.id == event.message.id:
                    self.state.lines[i] = await self.to_line(event.message)
                    self.state.status = "сообщение изменено"
                    self.state.dirty = True
                    break

        @self.client.on(events.Raw)
        async def on_raw(event: Any) -> None:
            name = type(event).__name__.lower()
            if "reaction" not in name:
                return
            msg_id = getattr(event, "msg_id", None)
            if msg_id:
                await self.refresh_message(msg_id)

        @self.client.on(events.MessageDeleted(chats=self.entity))
        async def on_delete(event: events.MessageDeleted.Event) -> None:
            deleted = set(event.deleted_ids)
            before = len(self.state.lines)
            self.state.lines = [line for line in self.state.lines if line.msg.id not in deleted]
            if len(self.state.lines) != before:
                self.state.selected = min(self.state.selected, max(0, len(self.state.lines) - 1))
                if self.state.scroll:
                    self.state.scroll = min(self.state.scroll, max(0, len(self.state.lines) - 1))
                self.state.status = "сообщение удалено"
                self.state.dirty = True

        @self.client.on(events.MessageRead(chats=self.entity))
        async def on_read(event: events.MessageRead.Event) -> None:
            if event.outbox:
                self.state.status = f"прочитано до #{event.max_id}"
                self.state.dirty = True

        @self.client.on(events.UserUpdate)
        async def on_user(event: events.UserUpdate.Event) -> None:
            if getattr(event, "typing", False):
                user = await event.get_user()
                if user:
                    self.state.typing = f"{getattr(user, 'first_name', None) or getattr(user, 'username', 'кто-то')} печатает..."
                    self.state.dirty = True
                    self.loop.call_later(4, self.clear_typing)
            elif getattr(event, "online", None):
                user = await event.get_user()
                if user:
                    name = getattr(user, "first_name", None) or getattr(user, "username", "кто-то")
                    self.state.status = f"{name} онлайн"
                    self.state.dirty = True

    def clear_typing(self) -> None:
        self.state.typing = ""
        self.state.dirty = True

    async def upsert_message(self, msg: Message) -> None:
        line = await self.to_line(msg)
        for idx, existing in enumerate(self.state.lines):
            if existing.msg.id == msg.id:
                self.state.lines[idx] = line
                self.state.dirty = True
                return
        self.state.lines.append(line)
        self.state.lines = self.state.lines[-MAX_MESSAGES:]
        self.state.dirty = True

    async def refresh_message(self, msg_id: int) -> None:
        try:
            msgs = await self.client.get_messages(self.entity, ids=[msg_id])
            msg = msgs[0] if isinstance(msgs, list) else msgs
            if msg:
                await self.upsert_message(msg)
                self.state.dirty = True
        except Exception:
            return

    async def send_typing(self) -> None:
        now = time.monotonic()
        if now - self.last_typing < 3:
            return
        self.last_typing = now
        with suppress(Exception):
            async with self.client.action(self.entity, "typing"):
                await asyncio.sleep(0.1)

    async def send_current(self) -> None:
        text = self.state.input_text.strip()
        if not text:
            return
        self.state.input_text = ""
        self.state.input_pos = 0
        self.state.dirty = True
        if text.startswith(":"):
            self.spawn(self.command(text), "command")
            return
        if text == "/ping":
            self.state.status = "замеряю ping до Telegram..."
            self.spawn(self.send_ping(), "ping")
            return
        dropped = normalize_drop_path(text)
        if dropped:
            self.spawn(self.send_file(dropped), "send_file")
            return
        self.state.status = "отправляю сообщение..."
        self.spawn(self.send_text(text), "send_text")

    async def send_ping(self) -> None:
        started = time.perf_counter()
        try:
            ping_id = random.getrandbits(63)
            await self.client(functions.PingRequest(ping_id=ping_id))
            ms = (time.perf_counter() - started) * 1000
            await self.client.send_message(
                self.entity,
                f"🏓 Pong: {ms:.0f} ms до Telegram MTProto",
                reply_to=self.state.reply_to,
            )
            self.clear_reply()
            self.state.status = f"ping: {ms:.0f} ms"
        except Exception as exc:
            log_error("ping", exc)
            self.state.status = "ping не выполнен"
        self.state.dirty = True

    async def send_text(self, text: str) -> None:
        try:
            reply_to = self.state.reply_to
            payload, parse_mode = normalize_parse_payload(self.state.parse_mode, text)
            msg = await self.client.send_message(self.entity, payload, reply_to=reply_to, parse_mode=parse_mode)
            await self.upsert_message(msg)
            self.go_bottom()
            self.state.status = "сообщение отправлено"
            self.clear_reply()
        except Exception as exc:
            log_error("send_text", exc)
            self.state.status = "не отправлено"
        self.state.dirty = True

    async def command(self, raw: str) -> None:
        args = shlex.split(raw[1:])
        if not args:
            return
        cmd = args[0].lower()
        try:
            if cmd in {"q", "quit", "exit"}:
                self.state.running = False
            elif cmd in {"h", "help"}:
                self.state.help_open = not self.state.help_open
            elif cmd in {"m", "meta"}:
                self.state.show_meta = not self.state.show_meta
            elif cmd in {"i", "info"}:
                self.state.info_open = not self.state.info_open
            elif cmd in {"r", "reply"}:
                self.set_reply()
            elif cmd in {"cancel", "unreply"}:
                self.clear_reply()
            elif cmd in {"react", "reaction"}:
                await self.react_selected(args[1] if len(args) > 1 else "👍")
            elif cmd in {"unreact", "noreact"}:
                await self.react_selected("")
            elif cmd in {"defaultreact", "dreaction", "doubletap"}:
                self.set_default_reaction(args[1] if len(args) > 1 else QUICK_REACTIONS[0])
            elif cmd in {"parse", "mode"}:
                self.set_parse_mode(args[1] if len(args) > 1 else "auto")
            elif cmd in {"html", "md", "markdown", "md2", "markdownv2", "plain"}:
                await self.send_formatted(cmd, raw.split(" ", 1)[1] if " " in raw else "")
            elif cmd in {"del", "delete"}:
                await self.delete_selected()
            elif cmd in {"delspam", "spamdelete", "reportspam"}:
                await self.delete_selected(report_spam=True)
            elif cmd == "purge":
                await self.purge_loaded(args[1] if len(args) > 1 else "")
            elif cmd in {"clearhistory", "wipehistory"}:
                await self.clear_history(args[1] if len(args) > 1 else "")
            elif cmd == "pin":
                await self.pin_selected(True)
            elif cmd in {"unpin", "unfix"}:
                await self.pin_selected(False)
            elif cmd in {"search", "find"} and len(args) >= 2:
                await self.search_messages(" ".join(args[1:]))
            elif cmd in {"latest", "tail"}:
                await self.load_initial()
                self.state.scroll = 0
            elif cmd in {"file", "send", "photo"} and len(args) >= 2:
                path = Path(" ".join(args[1:])).expanduser()
                await self.send_file(path)
            elif cmd in {"dl", "download"}:
                await self.download_selected()
            elif cmd in {"open", "view"}:
                await self.open_selected()
            elif cmd == "edit":
                await self.edit_selected(" ".join(args[1:]))
            elif cmd == "refresh":
                await self.load_initial()
            else:
                self.state.status = f"неизвестная команда: {cmd}"
        except Exception as exc:
            log_error(f"command {cmd}", exc)
            self.state.status = "не выполнено"
        self.state.dirty = True

    async def send_file(self, path: Path) -> None:
        if not path.exists():
            self.state.status = f"нет файла: {path}"
            return
        kind = file_kind(path)
        self.state.status = f"отправляю {kind}: {path.name}"
        self.state.dirty = True

        def progress(done: int, total: int) -> None:
            if total <= 0:
                return
            now = time.monotonic()
            if done < total and now - self.last_progress < 0.12:
                return
            self.last_progress = now
            pct = int(done * 100 / total)
            self.state.status = f"отправляю {kind}: {pct}%"
            self.state.dirty = True

        sent = await self.client.send_file(
            self.entity,
            str(path),
            caption="",
            reply_to=self.state.reply_to,
            progress_callback=progress,
        )
        if isinstance(sent, list):
            for msg in sent:
                await self.upsert_message(msg)
        elif sent:
            await self.upsert_message(sent)
        self.go_bottom()
        if self.state.reply_to:
            self.clear_reply()
        self.state.status = f"{kind} отправлен: {path.name}"

    async def download_selected(self) -> Path | None:
        if not self.state.lines:
            return None
        msg = self.state.lines[self.state.selected].msg
        if not msg.media:
            self.state.status = "у сообщения нет медиа"
            return None
        self.state.status = "скачиваю медиа..."
        self.state.dirty = True

        def progress(done: int, total: int) -> None:
            if total <= 0:
                return
            now = time.monotonic()
            if done < total and now - self.last_progress < 0.12:
                return
            self.last_progress = now
            self.state.status = f"скачиваю медиа: {int(done * 100 / total)}%"
            self.state.dirty = True

        path = await self.cached_media_path(msg, progress_callback=progress)
        if not path:
            self.state.status = "не удалось скачать"
            return None
        self.state.status = f"скачано: {path}"
        return Path(path)

    async def cached_media_path(self, msg: Message, progress_callback: Any = None, quiet: bool = False) -> str | None:
        cached = self.media_paths.get(msg.id)
        if cached and cached.exists():
            if not quiet:
                self.state.status = f"уже скачано: {cached}"
            return str(cached)
        path = await msg.download_media(file=str(downloads_dir()), progress_callback=progress_callback)
        if path:
            self.media_paths[msg.id] = Path(path)
        return path

    async def open_selected(self) -> None:
        path = await self.download_selected()
        if not path:
            return
        opener = shutil.which("xdg-open") or shutil.which("see") or shutil.which("open")
        if opener:
            subprocess.Popen([opener, str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.state.status = f"открываю: {path.name}"
        else:
            self.state.status = f"файл: {path}"

    async def edit_selected(self, new_text: str) -> None:
        if not new_text:
            self.state.status = "используй :edit новый текст"
            return
        if not self.state.lines:
            return
        msg = self.state.lines[self.state.selected].msg
        if not msg.out:
            self.state.status = "можно редактировать только свои сообщения"
            return
        payload, parse_mode = normalize_parse_payload(self.state.parse_mode, new_text)
        await self.client.edit_message(self.entity, msg.id, payload, parse_mode=parse_mode)
        self.state.status = "изменено"

    def selected_line(self) -> ChatLine | None:
        if not self.state.lines:
            return None
        if not 0 <= self.state.selected < len(self.state.lines):
            return None
        return self.state.lines[self.state.selected]

    def set_reply(self) -> None:
        line = self.selected_line()
        if not line:
            return
        preview = safe_text(clean_multiline(line.msg.message) or media_label(line.msg) or "message", 42)
        self.state.reply_to = line.msg.id
        self.state.reply_label = f"{line.sender_name}: {preview}"
        self.state.status = f"ответ на #{line.msg.id}"
        self.state.dirty = True

    def clear_reply(self) -> None:
        self.state.reply_to = None
        self.state.reply_label = ""
        self.state.dirty = True

    async def react_selected(self, emoji: str) -> None:
        line = self.selected_line()
        if not line:
            return
        reaction = [] if not emoji else [types.ReactionEmoji(emoticon=emoji)]
        await self.client(functions.messages.SendReactionRequest(peer=self.entity, msg_id=line.msg.id, reaction=reaction))
        await self.refresh_message(line.msg.id)
        self.state.status = "реакция убрана" if not emoji else f"реакция {emoji} отправлена"

    def set_default_reaction(self, emoji: str) -> None:
        self.state.default_reaction = emoji
        config = load_config()
        config["default_reaction"] = emoji
        save_config(config)
        self.state.status = f"двойной Enter теперь ставит {emoji}"
        self.state.dirty = True

    def set_parse_mode(self, mode: str) -> None:
        mapping = {
            "auto": "auto",
            "plain": None,
            "none": None,
            "off": None,
            "html": "html",
            "md": "md",
            "markdown": "md",
            "md2": "md2",
            "markdownv2": "md2",
        }
        key = mode.lower()
        if key not in mapping:
            self.state.status = "parse modes: auto, plain, html, md, markdown, md2"
            return
        self.state.parse_mode = mapping[key]
        self.state.status = f"parse mode: {key}"
        self.state.dirty = True

    async def send_formatted(self, mode: str, text: str) -> None:
        if not text:
            self.state.status = f"используй :{mode} текст"
            return
        old = self.state.parse_mode
        self.set_parse_mode(mode)
        await self.send_text(text)
        self.state.parse_mode = old

    async def delete_selected(self, report_spam: bool = False) -> None:
        line = self.selected_line()
        if not line:
            return
        if report_spam:
            with suppress(Exception):
                await self.client(functions.messages.ReportSpamRequest(peer=self.entity))
        await self.client.delete_messages(self.entity, [line.msg.id], revoke=True)
        self.state.lines = [row for row in self.state.lines if row.msg.id != line.msg.id]
        self.state.selected = min(self.state.selected, max(0, len(self.state.lines) - 1))
        self.state.status = "спам отправлен, сообщение удалено" if report_spam else "сообщение удалено"

    async def purge_loaded(self, confirm: str) -> None:
        if confirm.lower() != "yes":
            self.state.status = "для удаления загруженных сообщений: :purge yes"
            return
        ids = [line.msg.id for line in self.state.lines]
        if not ids:
            self.state.status = "нечего удалять"
            return
        self.state.status = f"удаляю сообщений: {len(ids)}"
        self.state.dirty = True
        for i in range(0, len(ids), 100):
            await self.client.delete_messages(self.entity, ids[i : i + 100], revoke=True)
        self.state.lines = []
        self.state.selected = 0
        self.state.scroll = 0
        self.state.status = f"удалено сообщений: {len(ids)}"

    async def clear_history(self, confirm: str) -> None:
        if confirm.lower() != "yes":
            self.state.status = "для очистки истории: :clearhistory yes"
            return
        self.state.status = "очищаю историю..."
        self.state.dirty = True
        await self.client(functions.messages.DeleteHistoryRequest(peer=self.entity, max_id=0, revoke=True))
        self.state.lines = []
        self.state.selected = 0
        self.state.scroll = 0
        self.state.status = "история очищена"

    async def pin_selected(self, pin: bool) -> None:
        line = self.selected_line()
        if not line:
            return
        if pin:
            await self.client.pin_message(self.entity, line.msg.id, notify=False)
            self.state.status = f"закреплено #{line.msg.id}"
        else:
            await self.client.unpin_message(self.entity, line.msg.id)
            self.state.status = f"откреплено #{line.msg.id}"
        self.state.dirty = True

    async def search_messages(self, query: str) -> None:
        self.state.status = f"ищу: {query}"
        self.state.dirty = True
        rows: list[ChatLine] = []
        async for msg in self.client.iter_messages(self.entity, search=query, limit=80, reverse=True):
            rows.append(await self.to_line(msg))
        self.state.lines = rows[-MAX_MESSAGES:]
        self.state.selected = max(0, len(self.state.lines) - 1)
        self.state.scroll = 0
        self.state.status = f"найдено: {len(rows)}"

    def draw(self, stdscr: Any) -> None:
        h, w = stdscr.getmaxyx()
        stdscr.erase()
        with suppress(curses.error):
            curses.curs_set(1)
        self.ensure_colors()
        if h < MIN_HEIGHT or w < MIN_WIDTH:
            self.put(stdscr, 0, 0, f"Terminal too small: need {MIN_WIDTH}x{MIN_HEIGHT}", w)
            stdscr.refresh()
            return

        self.draw_header(stdscr, w)

        help_h = 4 if self.state.help_open and h > 16 else 0
        if help_h:
            self.draw_help(stdscr, 1, w)

        input_h = 2
        chat_top = 1 + help_h
        chat_bottom = h - input_h
        self.draw_messages(stdscr, chat_top, chat_bottom, w)
        self.draw_input(stdscr, h - input_h, w)
        stdscr.refresh()
        self.state.dirty = False

    def put(self, stdscr: Any, y: int, x: int, text: str, width: int, attr: int = 0) -> None:
        if width <= 0 or y < 0 or x < 0:
            return
        try:
            h, w = stdscr.getmaxyx()
            if y >= h or x >= w:
                return
            max_width = max(0, min(width, w - x - 1))
            if max_width <= 0:
                return
            stdscr.addnstr(y, x, safe_text(text, max_width), max_width, attr)
        except curses.error:
            return

    def clear_line(self, stdscr: Any, y: int) -> None:
        with suppress(curses.error):
            stdscr.move(y, 0)
            stdscr.clrtoeol()

    def draw_header(self, stdscr: Any, w: int) -> None:
        title = f"{self.chat_title}  @{self.chat_username}"
        parse = self.state.parse_mode or "plain"
        right = self.state.typing or self.state.status
        self.clear_line(stdscr, 0)
        avatar_note = "av:on" if self.avatars.enabled else "av:off"
        preview_note = "pv:on" if self.media_previews.enabled else "pv:off"
        header = f"{title} | {right} | F1 help F2 {avatar_note} F3 {preview_note} | parse:{parse}"
        self.put(stdscr, 0, 0, fit_line(header, w), w, curses.color_pair(1) | curses.A_BOLD)

    def paint_header_avatar(self, stdscr: Any) -> None:
        if self.chat_avatar:
            for row_idx, row in enumerate(self.chat_avatar):
                for col_idx, color in enumerate(row):
                    with suppress(curses.error):
                        self.put(stdscr, row_idx, 1 + col_idx * 2, "  ", 2, self.bg_pair(color))
            return
        label = initials(str(self.chat_title)).center(AVATAR_W * 2)
        attr = curses.color_pair(6) | curses.A_BOLD
        with suppress(curses.error):
            self.put(stdscr, 0, 1, "┌" + "─" * (AVATAR_W * 2 - 2) + "┐", AVATAR_W * 2, attr)
            self.put(stdscr, 1, 1, fit_line(label, AVATAR_W * 2), AVATAR_W * 2, attr)
            self.put(stdscr, 2, 1, fit_line("", AVATAR_W * 2), AVATAR_W * 2, attr)
            self.put(stdscr, 3, 1, "└" + "─" * (AVATAR_W * 2 - 2) + "┘", AVATAR_W * 2, attr)

    def draw_help(self, stdscr: Any, y: int, w: int) -> None:
        keys = [
            "Enter send text/path. Ctrl+S send path. Ctrl+D download. Ctrl+O open in system viewer. Ctrl+R reply.",
            "Up/Down select. PgUp/PgDn history. End bottom. F2 avatars. F3 media previews. :pin/:react/:search.",
            "Drag-and-drop inserts path; Enter or Ctrl+S sends it. Errors are logged, not spammed on screen.",
        ]
        for i in range(4):
            self.put(stdscr, y + i, 1, " " * max(0, w - 2), max(0, w - 2), curses.color_pair(6))
        self.put(stdscr, y, 2, " Help ", max(0, w - 4), curses.color_pair(6) | curses.A_BOLD)
        for i, line in enumerate(keys, 1):
            self.put(stdscr, y + i, 2, safe_text(line, w - 4), max(0, w - 4), curses.color_pair(6))

    def draw_messages(self, stdscr: Any, top: int, bottom: int, w: int) -> None:
        for y in range(top, bottom):
            self.clear_line(stdscr, y)
        height = max(1, bottom - top)
        rows = self.visible_rows(w, height)
        y = top
        for idx, text, attr, avatar in rows:
            if y >= bottom:
                break
            selected = idx == self.state.selected
            line_attr = attr | (curses.A_REVERSE if selected else 0)
            self.put(stdscr, y, 0, text, w, line_attr)
            if avatar:
                self.paint_inline_avatar(stdscr, y, self.state.lines[idx], selected)
            y += 1

    def draw_input(self, stdscr: Any, y: int, w: int) -> None:
        for row in range(2):
            self.clear_line(stdscr, y + row)
        prompt = "Сообщение> "
        text_w = max(1, w - len(prompt) - 1)
        cursor = max(0, min(self.state.input_pos, len(self.state.input_text)))
        start = max(0, cursor - text_w + 1)
        view = self.state.input_text[start : start + text_w]
        self.put(stdscr, y + 1, 0, prompt, w, curses.A_BOLD)
        self.put(stdscr, y + 1, len(prompt), view.ljust(text_w), text_w)
        cursor_x = len(prompt) + cursor - start
        with suppress(curses.error):
            stdscr.move(y + 1, min(w - 1, cursor_x))

    def message_body(self, line: ChatLine) -> str:
        msg = line.msg
        body = clean_multiline(msg.message) or media_label(msg) or "<service>"
        if msg.media and msg.message:
            body = f"{body}\n{media_label(msg)}"
        return body

    def format_block(self, idx: int, w: int) -> list[str]:
        line = self.state.lines[idx]
        msg = line.msg
        inner = max(18, w - 4)
        name = safe_text(line.sender_name, max(8, min(18, w // 4)))
        stamp = msg.date.strftime("%H:%M") if msg.date else "--:--"
        edited = " edited" if getattr(msg, "edit_date", None) else ""
        media = " media" if msg.media else ""
        react = self.reactions_text(msg)
        tag = safe_text(line.sender_username, max(8, min(18, w // 4)))
        prefix = "me" if line.mine else initials(name)
        head = f"{prefix:>2} | {name} {tag} | {stamp}{edited}{media}"
        if react:
            head = f"{head} | {react}"
        rows = [safe_text(head, inner)]
        for raw in self.message_body(line).splitlines() or [""]:
            wrapped = textwrap.wrap(raw, width=inner, replace_whitespace=False, drop_whitespace=False) or [""]
            rows.extend("   " + item for item in wrapped[:8])
        if msg.media and self.media_previews.enabled:
            self.media_previews.request(msg)
            preview = self.media_previews.get(msg)
            if preview:
                rows.extend("   " + safe_text(item, inner - 3) for item in preview[: MEDIA_PREVIEW_H + 1])
            elif self.media_previews.loading(msg):
                rows.append("   [preview loading...]")
        if len(rows) > 10:
            rows = rows[:9] + ["   ..."]
        return rows

    def visible_rows(self, w: int, height: int) -> list[tuple[int, str, int, bool]]:
        if not self.state.lines:
            return []
        self.state.selected = max(0, min(self.state.selected, len(self.state.lines) - 1))
        end = max(0, len(self.state.lines) - self.state.scroll)
        if end <= self.state.selected:
            end = self.state.selected + 1
        selected_attr = curses.color_pair(3)
        rows: list[tuple[int, str, int, bool]] = []
        used = 0
        for idx in range(end - 1, -1, -1):
            line = self.state.lines[idx]
            attr = curses.color_pair(3 if line.mine else self.sender_pair(line.sender_name))
            block = self.format_block(idx, w)
            block_rows: list[tuple[int, str, int, bool]] = []
            for row_no, text in enumerate(block):
                block_rows.append((idx, fit_line(text, w), attr if row_no == 0 else curses.color_pair(4), row_no == 0 and self.avatars.enabled))
            block_rows.append((idx, fit_line("", w), selected_attr, False))
            if rows and used + len(block_rows) > height:
                break
            rows = block_rows + rows
            used += len(block_rows)
            if used >= height:
                break
        return rows[-height:]

    def visible_blocks(self, w: int, height: int) -> list[tuple[int, list[str]]]:
        if not self.state.lines:
            return []
        self.state.selected = max(0, min(self.state.selected, len(self.state.lines) - 1))
        end = max(0, len(self.state.lines) - self.state.scroll)
        if end <= self.state.selected:
            end = self.state.selected + 1
        used = 0
        blocks: list[tuple[int, list[str]]] = []
        for idx in range(end - 1, -1, -1):
            block = self.format_block(idx, w)
            block_h = max(len(block) + 2, AVATAR_H)
            if blocks and used + block_h > height:
                break
            used += block_h
            blocks.append((idx, block))
            if used >= height:
                break
        return list(reversed(blocks))

    def paint_block(self, stdscr: Any, y: int, w: int, line: ChatLine, rows: list[str], selected: bool) -> None:
        bubble_w = min(74, max(34, w - 18))
        inner = bubble_w - 4
        avatar_space = AVATAR_W * 2 + 2
        x = max(1, w - bubble_w - avatar_space - 2) if line.mine and w > 90 else avatar_space + 1
        attr = curses.color_pair(3 if line.mine else self.sender_pair(line.sender_name))
        if selected:
            attr |= curses.A_REVERSE
        top = "┌" + "─" * (bubble_w - 2) + "┐"
        bottom = "└" + "─" * (bubble_w - 2) + "┘"
        with suppress(curses.error):
            stdscr.addnstr(y, x, top, bubble_w, attr)
        for offset, row in enumerate(rows, 1):
            with suppress(curses.error):
                stdscr.addnstr(y + offset, x, "│ " + fit_line(row, inner) + " │", bubble_w, attr)
        with suppress(curses.error):
            stdscr.addnstr(y + len(rows) + 1, x, bottom, bubble_w, attr)
        self.paint_avatar(stdscr, y, x, bubble_w, line, selected)

    def paint_avatar(self, stdscr: Any, y: int, bubble_x: int, bubble_w: int, line: ChatLine, selected: bool) -> None:
        avatar = self.avatars.get(line.sender_id)
        term_w = stdscr.getmaxyx()[1]
        if line.mine and bubble_x + bubble_w + AVATAR_W * 2 + 1 < term_w:
            x = bubble_x + bubble_w + 1
        else:
            x = max(0, bubble_x - AVATAR_W * 2 - 1)
        if avatar:
            for row_idx, row in enumerate(avatar):
                for col_idx, color in enumerate(row):
                    attr = self.bg_pair(color)
                    if selected:
                        attr |= curses.A_REVERSE
                    with suppress(curses.error):
                        stdscr.addnstr(y + row_idx, x + col_idx * 2, "  ", 2, attr)
            return
        label = initials(line.sender_name).center(AVATAR_W * 2)
        attr = curses.color_pair(self.sender_pair(line.sender_name))
        if selected:
            attr |= curses.A_REVERSE
        with suppress(curses.error):
            stdscr.addnstr(y, x, "┌" + "─" * (AVATAR_W * 2 - 2) + "┐", AVATAR_W * 2, attr)
            stdscr.addnstr(y + 1, x, fit_line(label, AVATAR_W * 2), AVATAR_W * 2, attr | curses.A_BOLD)
            stdscr.addnstr(y + 2, x, "└" + "─" * (AVATAR_W * 2 - 2) + "┘", AVATAR_W * 2, attr)

    def paint_inline_avatar(self, stdscr: Any, y: int, line: ChatLine, selected: bool) -> None:
        if y < 0:
            return
        avatar = self.avatars.get(line.sender_id)
        attr = curses.color_pair(self.sender_pair(line.sender_name))
        if selected:
            attr |= curses.A_REVERSE
        if avatar and curses.COLORS >= 16:
            # Two tiny color cells: enough to identify people without wrecking layout.
            sample = [avatar[0][0], avatar[min(len(avatar) - 1, 1)][min(len(avatar[0]) - 1, 1)]]
            for col, color in enumerate(sample):
                self.put(stdscr, y, col * 2, "  ", 2, self.bg_pair(color) | (curses.A_REVERSE if selected else 0))
            return
        self.put(stdscr, y, 0, initials(line.sender_name)[:2].rjust(2), 2, attr | curses.A_BOLD)

    def bg_pair(self, color: int) -> int:
        if not curses.has_colors():
            return curses.A_NORMAL
        if curses.COLORS < 256:
            color = self.basic_color(color)
        if color not in self.bg_pairs:
            pair = self.next_pair
            max_pairs = getattr(curses, "COLOR_PAIRS", 64)
            if pair >= max_pairs:
                return curses.color_pair(4)
            with suppress(curses.error):
                curses.init_pair(pair, curses.COLOR_BLACK, color)
            self.bg_pairs[color] = pair
            self.next_pair += 1
        return curses.color_pair(self.bg_pairs[color])

    def basic_color(self, color: int) -> int:
        if color < 16:
            return color % 8
        idx = color - 16
        r = idx // 36
        g = (idx // 6) % 6
        b = idx % 6
        if r >= g and r >= b:
            return curses.COLOR_RED if r > 2 else curses.COLOR_BLACK
        if g >= r and g >= b:
            return curses.COLOR_GREEN
        if b >= r and b >= g:
            return curses.COLOR_BLUE
        return curses.COLOR_WHITE

    def sender_pair(self, name: str) -> int:
        pairs = [4, 7, 8, 9, 10, 11]
        return pairs[sum(ord(ch) for ch in name) % len(pairs)]

    def reactions_text(self, msg: Message) -> str:
        reactions = getattr(msg, "reactions", None)
        results = getattr(reactions, "results", None)
        if not results:
            return ""
        parts: list[str] = []
        for item in results[:8]:
            reaction = getattr(item, "reaction", None)
            emoji = getattr(reaction, "emoticon", None)
            if not emoji and getattr(reaction, "document_id", None):
                emoji = "custom"
            if not emoji:
                emoji = "?"
            if self.termux:
                emoji = REACTION_NAMES.get(emoji, "react")
            count = getattr(item, "count", 0)
            parts.append(f"{emoji}x{count}")
        return "react " + " ".join(parts)

    def selected_status(self) -> str:
        line = self.selected_line()
        if not line:
            return ""
        msg = line.msg
        media = media_label(msg)
        text = safe_text(clean_multiline(msg.message), 48)
        return f"Selected #{msg.id}: {line.sender_name} {line.sender_username} {media or text}"

    def ensure_colors(self) -> None:
        if not curses.has_colors():
            return
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_CYAN)
        curses.init_pair(2, curses.COLOR_YELLOW, -1)
        curses.init_pair(3, curses.COLOR_GREEN, -1)
        curses.init_pair(4, curses.COLOR_WHITE, -1)
        curses.init_pair(5, curses.COLOR_CYAN, -1)
        curses.init_pair(6, curses.COLOR_BLACK, curses.COLOR_YELLOW)
        curses.init_pair(7, curses.COLOR_MAGENTA, -1)
        curses.init_pair(8, curses.COLOR_BLUE, -1)
        curses.init_pair(9, curses.COLOR_RED, -1)
        curses.init_pair(10, curses.COLOR_YELLOW, -1)
        curses.init_pair(11, curses.COLOR_CYAN, -1)

    async def input_loop(self, stdscr: Any) -> None:
        stdscr.nodelay(True)
        stdscr.keypad(True)
        while self.state.running:
            if self.state.dirty:
                self.draw(stdscr)
            try:
                key = stdscr.get_wch()
            except curses.error:
                await asyncio.sleep(0.01)
                continue
            if isinstance(key, str):
                await self.handle_char(key)
            else:
                await self.handle_key(key)
            self.state.dirty = True

    async def handle_char(self, ch: str) -> None:
        if ch in {"\n", "\r"}:
            if not self.state.input_text.strip():
                now = time.monotonic()
                if now - self.last_empty_enter < 0.45:
                    self.spawn(self.react_selected(self.state.default_reaction), "react")
                    self.last_empty_enter = 0.0
                else:
                    self.last_empty_enter = now
                    self.state.status = f"Enter еще раз быстро = {self.state.default_reaction} на выбранное"
                return
            await self.send_current()
        elif ch == "\x1b":
            self.state.running = False
        elif ch in {"\x7f", "\b", "\x08"}:
            self.backspace_input()
        elif ch == "\x13":
            path = Path(self.state.input_text.strip().strip("'\"")).expanduser()
            self.state.input_text = ""
            self.state.input_pos = 0
            self.spawn(self.send_file(path), "send_file")
        elif ch == "\x04":
            self.spawn(self.download_selected(), "download")
        elif ch == "\x0f":
            self.spawn(self.open_selected(), "open")
        elif ch == "\x05":
            if self.state.lines:
                current = self.state.lines[self.state.selected].msg.message or ""
                self.state.input_text = ":edit " + current
                self.state.input_pos = len(self.state.input_text)
        elif ch == "\x12":
            self.set_reply()
        elif ch in "123456789" and not self.state.input_text:
            self.spawn(self.react_selected(QUICK_REACTIONS[int(ch) - 1]), "react")
        elif ch.isprintable():
            i = self.state.input_pos
            self.state.input_text = self.state.input_text[:i] + ch + self.state.input_text[i:]
            self.state.input_pos += 1
            self.spawn(self.send_typing(), "typing")

    def backspace_input(self) -> None:
        if self.state.input_pos <= 0:
            return
        i = self.state.input_pos - 1
        self.state.input_text = self.state.input_text[:i] + self.state.input_text[self.state.input_pos :]
        self.state.input_pos -= 1
        self.state.dirty = True

    def delete_input(self) -> None:
        if self.state.input_pos >= len(self.state.input_text):
            return
        i = self.state.input_pos
        self.state.input_text = self.state.input_text[:i] + self.state.input_text[i + 1 :]
        self.state.dirty = True

    async def handle_key(self, key: int) -> None:
        if key == curses.KEY_F1:
            self.state.help_open = not self.state.help_open
        elif key == curses.KEY_F2:
            self.toggle_avatars()
        elif key == curses.KEY_F3:
            self.toggle_media_previews()
        elif key == curses.KEY_UP:
            self.state.selected = max(0, self.state.selected - 1)
            self.focus_selected()
        elif key == curses.KEY_DOWN:
            self.state.selected = min(max(0, len(self.state.lines) - 1), self.state.selected + 1)
            self.focus_selected()
        elif key in {getattr(curses, "KEY_SR", -1), 566}:
            self.state.selected = max(0, self.state.selected - 5)
            self.focus_selected()
        elif key in {getattr(curses, "KEY_SF", -1), 525}:
            self.state.selected = min(max(0, len(self.state.lines) - 1), self.state.selected + 5)
            self.focus_selected()
        elif key == curses.KEY_PPAGE:
            self.state.scroll = min(len(self.state.lines), self.state.scroll + 10)
            self.state.selected = max(0, len(self.state.lines) - self.state.scroll - 1)
        elif key == curses.KEY_NPAGE:
            self.state.scroll = max(0, self.state.scroll - 10)
            self.state.selected = max(0, len(self.state.lines) - self.state.scroll - 1)
        elif key == curses.KEY_HOME:
            self.state.selected = 0
            self.state.scroll = max(0, len(self.state.lines) - 30)
        elif key == curses.KEY_END:
            self.state.selected = max(0, len(self.state.lines) - 1)
            self.state.scroll = 0
        elif key == curses.KEY_LEFT:
            self.state.input_pos = max(0, self.state.input_pos - 1)
        elif key == curses.KEY_RIGHT:
            self.state.input_pos = min(len(self.state.input_text), self.state.input_pos + 1)
        elif key in {curses.KEY_BACKSPACE, 127, 8, 263, 330}:
            self.backspace_input()
        elif key == curses.KEY_DC:
            self.delete_input()

    def focus_selected(self) -> None:
        if not self.state.lines:
            self.state.scroll = 0
            return
        self.state.scroll = max(0, len(self.state.lines) - self.state.selected - 1)

    def is_at_bottom(self) -> bool:
        return self.state.scroll == 0 and self.state.selected >= max(0, len(self.state.lines) - 2)

    def go_bottom(self) -> None:
        self.state.selected = max(0, len(self.state.lines) - 1)
        self.state.scroll = 0

    def keep_history_position(self) -> None:
        if not self.state.lines:
            self.state.selected = 0
            self.state.scroll = 0
            return
        self.state.selected = max(0, min(self.state.selected, len(self.state.lines) - 1))
        self.state.scroll = max(1, min(self.state.scroll, len(self.state.lines) - 1))

    async def run(self, stdscr: Any) -> None:
        await self.load_initial()
        self.register_events()
        self.refresh_task = asyncio.create_task(self.refresh_loop())
        try:
            await self.input_loop(stdscr)
        finally:
            if self.refresh_task:
                self.refresh_task.cancel()
                with suppress(asyncio.CancelledError):
                    await self.refresh_task

    async def refresh_loop(self) -> None:
        while self.state.running:
            await asyncio.sleep(AUTO_REFRESH_SECONDS)
            try:
                last_id = self.state.lines[-1].msg.id if self.state.lines else 0
                new_lines: list[ChatLine] = []
                async for msg in self.client.iter_messages(self.entity, min_id=last_id, reverse=True):
                    new_lines.append(await self.to_line(msg))
                if new_lines:
                    at_bottom = self.is_at_bottom()
                    self.state.lines.extend(new_lines)
                    self.state.lines = self.state.lines[-MAX_MESSAGES:]
                    if at_bottom:
                        self.go_bottom()
                        self.state.status = "лента обновлена"
                    else:
                        self.keep_history_position()
                        self.state.status = "лента обновлена ниже"
                    self.state.dirty = True
            except Exception as exc:
                log_error("refresh", exc)
                self.state.dirty = True


async def async_main() -> None:
    client = make_client()
    await ensure_login(client)
    try:
        entity = await client.get_entity(CHAT_USERNAME)
    except Exception:
        entity = await client.get_entity(CHAT_ID)

    tui = PotatoTui(client, entity)

    async def wrapped(stdscr: Any) -> None:
        await tui.run(stdscr)

    try:
        await curses_async(wrapped)
    finally:
        await client.disconnect()
        await asyncio.sleep(0)


async def curses_async(coro_factory: Any) -> None:
    stdscr = curses.initscr()
    curses.noecho()
    curses.cbreak()
    try:
        await coro_factory(stdscr)
    finally:
        curses.nocbreak()
        stdscr.keypad(False)
        curses.echo()
        curses.endwin()


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "web":
        from .webapp import web_main

        web_main(sys.argv[2:])
        return
    if sys.version_info < (3, 9):
        print("Нужен Python 3.9+.")
        raise SystemExit(2)
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(async_main())
        finally:
            pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
            for task in pending:
                task.cancel()
            if pending:
                loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.close()
    except KeyboardInterrupt:
        pass
    except curses.error as exc:
        print("Терминал слишком маленький или не поддерживает curses:", exc)
        raise SystemExit(1)
