from setuptools import setup, find_packages
import sys
import subprocess
import os

# Default dependencies - numpy, scipy, tqdm, matplotlib are required
REQUIRED_DEPENDENCIES = [
    'numpy==1.26.4', #k-wave-python 0.3.5 requires numpy<1.27.0,>=1.22.2
    'scipy==1.13.1', # k-wave-python 0.3.5 requires scipy==1.13.1
    'tqdm==4.60.0',
    'matplotlib==3.9.2', # k-wave-python 0.3.5 requires matplotlib==3.9.2
]

# Optional dependencies
OPTIONAL_DEPENDENCIES = {
    'acoustic': [
        'k-wave-python==0.3.5',  # For acoustic simulation
    ],
}


def check_cuda_available():
    """Check if CUDA is available on the system."""
    try:
        # Check for nvcc (NVIDIA CUDA Compiler)
        result = subprocess.run(['nvcc', '--version'], 
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, 
                              text=True)
        return result.returncode == 0
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def detect_cuda_version():
    """Detect CUDA version and return appropriate CuPy package name."""
    try:
        # Try to get CUDA version from nvcc
        result = subprocess.run(['nvcc', '--version'], 
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True)
        output = result.stdout + result.stderr
        
        # Parse version from output like "release 12.2"
        import re
        match = re.search(r'release (\d+)\.(\d+)', output)
        if match:
            major = match.group(1)
            # Map CUDA major version to CuPy package
            # CUDA 11.x -> cupy-cuda11x
            # CUDA 12.x -> cupy-cuda12x
            # CUDA 13.x -> cupy-cuda13x
            # CUDA 14.x -> cupy-cuda14x
            return f'cupy-cuda{major}x>=12.0.0'
        
        # If we can't parse, try common versions in order
        # Check which cupy package is available
        for version in ['14x', '13x', '12x', '11x']:
            try:
                # Try to import to see if it's available
                __import__(f'cupy_cuda{version}')
                return f'cupy-cuda{version}>=12.0.0'
            except ImportError:
                continue
        
        # Default to cupy-cuda12x as most common
        return 'cupy-cuda12x>=12.0.0'
    except Exception:
        # If we can't detect, return None to skip CuPy
        return None


def get_install_requires():
    """Get the install requirements based on command line arguments and environment."""
    # Default: include GPU and acoustic
    use_gpu = os.environ.get('AOT_BIOMAPS_CPU_ONLY', '').lower() != 'true'
    use_acoustic = os.environ.get('AOT_BIOMAPS_WITHOUT_ACOUSTIC', '').lower() != 'true'
    
    # Also check command line arguments (for setup.py direct calls)
    if '--cpu' in sys.argv:
        use_gpu = False
        sys.argv.remove('--cpu')
    
    if '--without-acoustic' in sys.argv:
        use_acoustic = False
        sys.argv.remove('--without-acoustic')
    
    # Build install requirements
    install_requires = REQUIRED_DEPENDENCIES.copy()
    
    # Add GPU dependencies if requested
    if use_gpu:
        if check_cuda_available():
            cupy_pkg = detect_cuda_version()
            if cupy_pkg:
                install_requires.append(cupy_pkg)
                print(f"CUDA detected - including {cupy_pkg} for GPU acceleration")
            else:
                print("CUDA detected but couldn't determine version. Install CuPy manually: pip install cupy-cudaXXx")
        else:
            print("CUDA not detected. For GPU support, install CuPy manually: pip install cupy-cudaXXx")
    else:
        print("CPU-only installation requested - CuPy will not be installed")
    
    # Add acoustic dependencies if requested (default: yes)
    if use_acoustic:
        install_requires.extend(OPTIONAL_DEPENDENCIES['acoustic'])
        print("Including kWave for acoustic simulation")
    else:
        print("Acoustic simulation disabled - kWave will not be installed")
    
    return install_requires


# Get the install requirements
install_requires = get_install_requires()

# Package data - include CUDA source file for compilation with CuPy
package_data = {
    'AOT_biomaps': [
        'AOT_Recon/AOT_biomaps_kernels.cu',
    ],
}

# Entry points for command line installation options
entry_points = {
    'console_scripts': [
        'aot-biomaps = AOT_biomaps.__main__:main',
    ],
}

setup(
    name='aot-biomaps',
    version='2.9.526',
    packages=find_packages(),
    package_dir={'': '.'},  # Look for packages in current directory
    include_package_data=True,
    package_data=package_data,
    
    # Core dependencies (always installed)
    install_requires=install_requires,
    
    # Optional dependencies that can be installed with:
    # pip install aot-biomaps[acoustic]
    extras_require={
        'acoustic': OPTIONAL_DEPENDENCIES['acoustic'],
    },
    
    author='Lucas Duclos',
    author_email='lucas.duclos@universite-paris-saclay.fr',
    description='Acousto-Optic Tomography Reconstruction Library',
    long_description=open('README.md', encoding='utf-8').read() if os.path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    url='https://github.com/LucasDuclos/AcoustoOpticTomography',
    project_urls={
        'Documentation': 'https://github.com/LucasDuclos/AcoustoOpticTomography',
        'Source': 'https://github.com/LucasDuclos/AcoustoOpticTomography',
        'PyPI': 'https://pypi.org/project/aot-biomaps/',
    },
    
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Scientific/Engineering :: Bio-Informatics',
        'Topic :: Scientific/Engineering :: Physics',
        'Topic :: Scientific/Engineering :: Image Recognition',
    ],
    
    python_requires='>=3.8',
    
    # Entry points
    entry_points=entry_points,
)



