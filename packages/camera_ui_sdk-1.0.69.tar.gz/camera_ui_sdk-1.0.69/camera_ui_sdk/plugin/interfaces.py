from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    Literal,
    NotRequired,
    Protocol,
    TypedDict,
    runtime_checkable,
)

from typing_extensions import TypeVar as ExtTypeVar

from ..camera import DetectionEvent, EventTriggerType, NvrPreviewResult
from ..sensor import ClassifierDetection, Detection, FaceDetection, LicensePlateDetection
from ..sensor.audio import BaseAudioLabel
from ..sensor.motion import DetectionAttribute, DetectionLabel
from .api import PluginAPI

if TYPE_CHECKING:
    from ..camera import CameraConfig, CameraDevice
    from ..manager import DiscoveredCamera
    from ..storage import DeviceStorage, JsonSchemaWithoutCallbacks
    from ..types import LoggerService

from ..storage import JsonSchema

# Special filter value matching classifier-produced types not in the standard set.
EVENT_TYPE_OTHER: Literal["__other__"] = "__other__"

# Union of all known event type filters + "__other__" + arbitrary strings.
EventTypeFilter = DetectionLabel | DetectionAttribute | EventTriggerType | Literal["__other__"] | str

# TypeVar for generic storage typing in BasePlugin
# Using Mapping as bound since TypedDict is compatible with Mapping but not dict
StorageT = ExtTypeVar("StorageT", bound=Mapping[str, Any], default=dict[str, Any])
"""TypeVar for plugin storage values type. Defaults to dict[str, Any]."""


class ImageMetadata(TypedDict):
    """Image metadata for detection test requests."""

    width: int
    height: int


class AudioMetadata(TypedDict):
    """Audio metadata for detection test requests."""

    mimeType: Literal["audio/mpeg", "audio/wav", "audio/ogg"]


class MotionDetectionPluginResponse(TypedDict):
    """Response from a motion detection test."""

    detected: bool
    detections: list[Detection]
    videoData: NotRequired[bytes]


class ObjectDetectionPluginResponse(TypedDict):
    """Response from an object detection test."""

    detected: bool
    detections: list[Detection]


class AudioDetectionPluginResponse(TypedDict):
    """Response from an audio detection test."""

    detected: bool
    detections: list[Detection]
    decibels: NotRequired[float]


class FaceDetectionPluginResponse(TypedDict):
    """Response from a face detection test."""

    detected: bool
    detections: list[FaceDetection]
    embeddingModel: NotRequired[str]


class LicensePlateDetectionPluginResponse(TypedDict):
    """Response from a license plate detection test."""

    detected: bool
    detections: list[LicensePlateDetection]


class ClassifierDetectionPluginResponse(TypedDict):
    """Response from a classifier detection test."""

    detected: bool
    detections: list[ClassifierDetection]


class BasePlugin(ABC, Generic[StorageT]):
    """
    Base class for all plugins.

    Plugins must extend this class and implement the abstract methods
    for camera lifecycle management.

    Generic type parameter `StorageT` allows typed access to storage.values.

    Example:
        ```python
        class MyStorageValues(TypedDict):
            model_path: str
            threshold: float


        class MyPlugin(BasePlugin[MyStorageValues]):
            async def configureCameras(self, cameras: list[CameraDevice]) -> None:
                # storage.values is typed as MyStorageValues
                model_path = self.storage.values.get("model_path")  # str
                for camera in cameras:
                    await self.onCameraAdded(camera)

            async def onCameraAdded(self, camera: CameraDevice) -> None:
                # Initialize camera controller
                pass

            async def onCameraReleased(self, camera_id: str) -> None:
                # Cleanup camera controller
                pass
        ```
    """

    def __init__(self, logger: LoggerService, api: PluginAPI, storage: DeviceStorage[StorageT]) -> None:
        self.logger = logger
        self.api = api
        self.storage: DeviceStorage[StorageT] = storage

    @property
    def storage_schema(self) -> list[JsonSchema]:
        """Override to define plugin storage schema."""
        return []

    @abstractmethod
    async def configureCameras(self, cameraDevices: list[CameraDevice]) -> None:
        """
        Called on startup with all assigned cameras.

        Args:
            cameraDevices: List of cameras assigned to this plugin
        """
        ...

    @abstractmethod
    async def onCameraAdded(self, camera: CameraDevice) -> None:
        """
        Called when a camera is added/assigned to this plugin at runtime.

        Args:
            camera: The camera device that was added
        """
        ...

    @abstractmethod
    async def onCameraReleased(self, cameraId: str) -> None:
        """
        Called when a camera is removed/unassigned from this plugin at runtime.

        Args:
            cameraId: ID of the camera that was released
        """
        ...


@runtime_checkable
class DiscoveryProvider(Protocol):
    async def onDiscoverCameras(self) -> list[DiscoveredCamera]:
        """
        Scan for cameras and return discovered devices.
        Called by backend when polling or when user triggers manual rescan.

        Returns:
            List of discovered cameras
        """
        ...

    async def onGetCameraSettings(self, camera: DiscoveredCamera) -> list[JsonSchemaWithoutCallbacks]:
        """
        Get connection schema for a specific discovered camera.
        Returns form fields for credentials/settings needed to connect.

        Args:
            camera: The discovered camera

        Returns:
            JSON schema array for the connection form
        """
        ...

    async def onAdoptCamera(
        self, camera: DiscoveredCamera, cameraSettings: dict[str, object]
    ) -> CameraConfig:
        """
        Adopt a discovered camera.
        Provider probes the device and returns camera configuration.
        The backend will create the camera and call onCameraAdded().

        Args:
            camera: The discovered camera
            cameraSettings: User-provided settings from the connection form

        Returns:
            Camera configuration with sources
        """
        ...


@runtime_checkable
class MotionDetectionInterface(Protocol):
    """Interface for plugins that provide motion detection."""

    async def testMotionDetection(
        self, video_data: bytes, config: dict[str, Any]
    ) -> MotionDetectionPluginResponse | None: ...

    async def motionDetectionSettings(self) -> list[JsonSchema] | None: ...


@runtime_checkable
class ObjectDetectionInterface(Protocol):
    """Interface for plugins that provide object detection."""

    async def testObjectDetection(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> ObjectDetectionPluginResponse | None: ...

    async def objectDetectionSettings(self) -> list[JsonSchema] | None: ...


@runtime_checkable
class AudioDetectionInterface(Protocol):
    """Interface for plugins that provide audio detection."""

    async def testAudioDetection(
        self, audio_data: bytes, metadata: AudioMetadata, config: dict[str, Any]
    ) -> AudioDetectionPluginResponse | None: ...

    async def audioDetectionSettings(self) -> list[JsonSchema] | None: ...


@runtime_checkable
class FaceDetectionInterface(Protocol):
    """Interface for plugins that provide face detection."""

    async def testFaceDetection(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> FaceDetectionPluginResponse | None: ...

    async def faceDetectionSettings(self) -> list[JsonSchema] | None: ...


@runtime_checkable
class LicensePlateDetectionInterface(Protocol):
    """Interface for plugins that provide license plate detection."""

    async def testLicensePlateDetection(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> LicensePlateDetectionPluginResponse | None: ...

    async def licensePlateDetectionSettings(self) -> list[JsonSchema] | None: ...


@runtime_checkable
class ClassifierDetectionInterface(Protocol):
    """Interface for plugins that provide classifier detection."""

    async def testClassifierDetection(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> ClassifierDetectionPluginResponse | None: ...

    async def classifierDetectionSettings(self) -> list[JsonSchema] | None: ...


class CameraStorageStats(TypedDict):
    """Storage usage for a single camera."""

    usedBytes: int
    segmentCount: int
    oldestDay: str
    newestDay: str
    daysCount: int
    bandwidthMBh: float
    recordingMode: str
    isRecording: bool


class StorageStats(TypedDict):
    """Overall storage and per-camera usage statistics."""

    diskTotalGB: float
    diskUsedGB: float
    diskFreeGB: float
    diskFreePercent: float
    nvrUsedGB: float
    nvrQuotaGB: float
    retentionDays: int
    cameras: dict[str, CameraStorageStats]


class RecordingSegment(TypedDict):
    """A continuous recording time range."""

    startTime: int  # Unix ms
    endTime: int  # Unix ms


class RecordingState(TypedDict):
    """Current recording status of a camera."""

    cameraId: str
    state: Literal["recording", "stopped"]
    timestamp: int  # Unix ms


class GetEventsOptions(TypedDict, total=False):
    """Server-side filter options for getEvents()."""

    types: list[EventTypeFilter]
    """Filter events by detection type. Use "__other__" to match classifier-produced types outside the standard set."""

    triggers: list[EventTriggerType | str]
    """Filter events that have at least one trigger with matching type (e.g. ["motion", "contact"])."""

    triggerLabels: list[BaseAudioLabel | str]
    """Filter events that have at least one trigger with matching label (e.g. ["doorbell", "glass_break"])."""

    attributes: list[DetectionAttribute | str]
    """Filter events that have at least one segment attribute with matching type (e.g. ["face", "license_plate"])."""

    state: Literal["active", "ended"]
    """Filter by event lifecycle state."""

    search: str
    """Case-insensitive substring match across all detection labels."""

    hasDetections: bool
    """Only return events with detection types beyond just motion/audio."""


class EventThumbnails(TypedDict, total=False):
    """All thumbnails for a single event, grouped by category."""

    scenes: dict[str, bytes]
    """Scene thumbnails per segment index. Key: segment index as string ("0", "1", ...)."""

    detections: dict[str, bytes]
    """Detection thumbnails per segment+label. Key: "{segIdx}:{label}"."""

    attributes: dict[str, bytes]
    """Attribute thumbnails keyed by "{type}:{label}" (e.g. "face:John", "license_plate:ABC123")."""


class NvrExportOptions(TypedDict, total=False):
    """Options for NVR export (trim/timelapse)."""

    timelapseIntervalSec: int
    """Timelapse interval in seconds. 0 or omitted means no timelapse."""

    format: Literal["mp4"]
    """Output format (currently only mp4)."""


class HeatmapPoint(TypedDict):
    """A single detection center point for heatmap rendering. Coordinates are normalized 0-1."""

    x: float
    """Center X (0-1)."""

    y: float
    """Center Y (0-1)."""


class DetectionHeatmapResult(TypedDict):
    """Aggregated detection center points for heatmap rendering."""

    points: list[HeatmapPoint]
    """Detection center points (normalized 0-1)."""

    count: int
    """Total number of events scanned."""


class NvrExportResult(TypedDict):
    """Result of an NVR export operation."""

    url: str
    """Download URL for the exported file."""

    filename: str
    """Filename of the exported file."""

    size: int
    """File size in bytes."""

    durationMs: int
    """Duration of the exported clip in milliseconds."""


@runtime_checkable
class NVRInterface(Protocol):
    """Interface for NVR plugins that persist and query detection events."""

    async def getEvents(
        self, cameraID: str, startMs: int, endMs: int, opts: GetEventsOptions | None = None
    ) -> list[DetectionEvent]:
        """Query events WITHOUT thumbnails. Use getEventThumbnails() for lazy loading."""
        ...

    async def getEventThumbnails(self, cameraID: str, startMs: int, eventID: str) -> EventThumbnails:
        """Get all thumbnails for a specific event.

        Args:
            cameraID: Camera ID.
            startMs: The event's startTime in milliseconds (used to locate the DB).
            eventID: The event's UUID (DetectionEvent.id).
        """
        ...

    async def getRecordingSegments(
        self, cameraID: str, startMs: int, endMs: int
    ) -> list[RecordingSegment]: ...
    async def getRecordingDays(self, cameraID: str, year: int, month: int) -> list[str]: ...
    def onRecordingState(self, cameraID: str, callback: Any) -> Any: ...
    async def getManagedCameraIds(self) -> list[str]: ...
    async def getStorageStats(self) -> StorageStats: ...
    async def nvrPreviewFrames(
        self, cameraID: str, startUs: int, endUs: int, count: int = 12
    ) -> NvrPreviewResult: ...
    async def nvrExport(
        self, cameraID: str, startUs: int, endUs: int, options: NvrExportOptions | None = None
    ) -> NvrExportResult: ...
    async def getDetectionHeatmap(self, cameraID: str, startMs: int, endMs: int) -> DetectionHeatmapResult:
        """Get aggregated detection center points for heatmap rendering."""
        ...

    # Face recognition
    async def matchFaces(
        self, embeddings: list[list[float]], embeddingModel: str
    ) -> list[FaceMatchResult | None]: ...
    async def enrollFace(self, name: str, imageData: bytes, facePluginName: str) -> None: ...
    async def enrollFromEvent(self, name: str, unknownFaceId: str) -> None: ...
    async def listKnownFaces(self) -> list[FaceProfile]: ...
    async def deleteFace(self, name: str) -> None: ...
    async def getFaceImages(self, name: str) -> list[bytes]: ...
    async def getUnknownFaces(self, limit: int = 50) -> list[UnknownFace]: ...


class FaceMatchResult(TypedDict):
    identity: str
    score: float


class FaceProfile(TypedDict):
    name: str
    imageCount: int
    createdAt: int
    updatedAt: int


class UnknownFace(TypedDict):
    id: str
    cameraId: str
    timestamp: int
    embeddingModel: str
    thumbnail: NotRequired[bytes]
