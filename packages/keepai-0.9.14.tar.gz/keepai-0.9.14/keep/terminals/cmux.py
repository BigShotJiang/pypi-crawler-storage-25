"""Cmux terminal backend for keep.

Group-container model
-----------------------
A group = one cmux **workspace**. The container ref is the native cmux
ref ``workspace:N`` returned by ``cmux new-workspace``.

Layout inside the workspace:

  * supervisor+0 = the workspace's initial surface (tab). Titled ``supervisor``.
  * reviewer+0   = right-split of the supervisor surface. Titled ``reviewer``.
  * worker+0     = down-split from the supervisor surface. Titled ``worker-1``.
    This creates a new pane. Subsequent workers land as additional tabs
    inside that pane.
  * worker+N>=1  = ``new-surface --pane <worker-pane>`` inside the worker-1
    pane. Titled ``worker-{N+1}``.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shlex
import socket
import subprocess
import time


_log = logging.getLogger(__name__)


# --- Module-level private RPC helpers ---

SOCKET_PATH = os.environ.get(
    "CMUX_SOCKET_PATH",
    os.path.expanduser("~/Library/Application Support/cmux/cmux.sock"),
)


def _rpc(method: str, params: dict | None = None) -> dict:
    payload = {"id": "keep", "method": method, "params": params or {}}
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
        s.connect(SOCKET_PATH)
        s.sendall(json.dumps(payload).encode() + b"\n")
        s.settimeout(10)
        data = s.recv(65536).decode()
    resp = json.loads(data)
    if not resp.get("ok"):
        error = resp.get("error", {})
        msg = error.get("message", str(error)) if isinstance(error, dict) else str(error)
        raise RuntimeError(f"cmux {method}: {msg}")
    return resp.get("result", {})


def _parse_first(prefix: str, stdout: str) -> str | None:
    for token in stdout.split():
        if token.startswith(prefix):
            return token
    return None


def _list_surfaces(workspace: str) -> list[dict]:
    """Return surface dicts for a workspace via the ``surface.list`` RPC.

    Each dict carries at minimum ``ref`` (``surface:N``), ``pane_ref``,
    ``title``, ``index`` (workspace-wide), ``index_in_pane``.
    """
    result = _rpc("surface.list", {"workspace_id": workspace})
    return result.get("surfaces", []) or []


def _find_surface_by_title(workspace: str, title: str) -> str:
    for s in _list_surfaces(workspace):
        t = s.get("title") or ""
        if t == title or t.startswith(f"{title} ") or t.startswith(f"{title}:"):
            return s["ref"]
    raise RuntimeError(
        f"cmux: could not find a surface titled {title!r} in workspace {workspace!r}"
    )


def _find_worker_pane(workspace: str) -> str:
    for s in _list_surfaces(workspace):
        t = s.get("title") or ""
        if t == "worker-1" or t.startswith("worker-1 ") or t.startswith("worker-1:"):
            return s["pane_ref"]
    raise RuntimeError(
        f"cmux: no 'worker-1' surface found in workspace {workspace!r}"
    )


def _rename_surface(workspace: str, surface_ref: str, title: str) -> None:
    """Best-effort rename; skip gracefully if the CLI rejects the surface."""
    try:
        subprocess.run(
            ["cmux", "rename-tab", "--workspace", workspace,
             "--surface", surface_ref, title],
            check=True, capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        _log.warning(
            "cmux rename-tab %s → %s failed: %s",
            surface_ref, title, exc.stderr.decode() if exc.stderr else exc,
        )


def _send_cmd(surface_ref: str, cwd: str, cmd: str) -> None:
    _rpc("surface.send_text", {"surface_id": surface_ref, "text": f"cd {shlex.quote(cwd)} && {cmd}"})
    time.sleep(0.5)
    _rpc("surface.send_key", {"surface_id": surface_ref, "key": "Enter"})


class CmuxTerminal:
    def ensure_group_container(self, group_id: str) -> str:
        """Create a new cmux workspace for this group. Returns ``workspace:N``.

        cmux does not expose a "find workspace by name" lookup, so we always
        create a fresh workspace and rely on ``group["terminal_container"]``
        as the source of truth: once created, the ref is persisted in state.
        """
        result = subprocess.run(
            ["cmux", "new-workspace", "--cwd", "/tmp"],
            capture_output=True, text=True, check=True,
        )
        workspace_ref = _parse_first("workspace:", result.stdout)
        if workspace_ref is None:
            raise RuntimeError(
                f"cmux new-workspace: could not parse workspace ref from "
                f"output {result.stdout!r}"
            )
        # Give cmux a moment to materialise the default surface.
        time.sleep(0.3)
        # Rename the workspace for legibility in the cmux UI.
        try:
            _rpc("workspace.rename", {
                "workspace_id": workspace_ref,
                "title": f"keep-{group_id}",
            })
        except RuntimeError as exc:
            _log.warning("cmux workspace.rename failed: %s", exc)
        return workspace_ref

    def spawn_in_container(
        self,
        container_ref: str,
        role: str,
        role_index: int,
        cwd: str,
        cmd: str,
    ) -> str:
        """Place a user surface in the workspace; run cmd; return surface ref."""
        workspace = container_ref

        if role == "supervisor" and role_index == 0:
            surfaces = _list_surfaces(workspace)
            if not surfaces:
                raise RuntimeError(
                    f"cmux: workspace {workspace!r} has no surfaces (expected "
                    f"a default one created by new-workspace)"
                )
            surface_ref = surfaces[0]["ref"]
            _rename_surface(workspace, surface_ref, "supervisor")
            _send_cmd(surface_ref, cwd, cmd)
            return surface_ref

        if role == "reviewer" and role_index == 0:
            sup_surface = _find_surface_by_title(workspace, "supervisor")
            result = subprocess.run(
                ["cmux", "new-split", "right",
                 "--workspace", workspace,
                 "--surface", sup_surface],
                capture_output=True, text=True, check=True,
            )
            surface_ref = _parse_first("surface:", result.stdout)
            if surface_ref is None:
                raise RuntimeError(
                    f"cmux new-split right: could not parse new surface from "
                    f"{result.stdout!r}"
                )
            _rename_surface(workspace, surface_ref, "reviewer")
            _send_cmd(surface_ref, cwd, cmd)
            return surface_ref

        if role == "worker" and role_index == 0:
            sup_surface = _find_surface_by_title(workspace, "supervisor")
            result = subprocess.run(
                ["cmux", "new-split", "down",
                 "--workspace", workspace,
                 "--surface", sup_surface],
                capture_output=True, text=True, check=True,
            )
            surface_ref = _parse_first("surface:", result.stdout)
            if surface_ref is None:
                raise RuntimeError(
                    f"cmux new-split down: could not parse new surface from "
                    f"{result.stdout!r}"
                )
            _rename_surface(workspace, surface_ref, "worker-1")
            _send_cmd(surface_ref, cwd, cmd)
            return surface_ref

        if role == "worker" and role_index >= 1:
            worker_pane = _find_worker_pane(workspace)
            result = subprocess.run(
                ["cmux", "new-surface",
                 "--workspace", workspace,
                 "--pane", worker_pane],
                capture_output=True, text=True, check=True,
            )
            surface_ref = _parse_first("surface:", result.stdout)
            if surface_ref is None:
                raise RuntimeError(
                    f"cmux new-surface: could not parse new surface from "
                    f"{result.stdout!r}"
                )
            _rename_surface(workspace, surface_ref, f"worker-{role_index + 1}")
            _send_cmd(surface_ref, cwd, cmd)
            return surface_ref

        raise ValueError(f"cmux: unsupported role/index combo: {role!r}+{role_index}")

    def close_group_container(self, container_ref: str) -> None:
        """Close the workspace (cmux tears down every surface in it)."""
        try:
            _rpc("workspace.close", {"workspace_id": container_ref})
        except RuntimeError as exc:
            # Fall back to closing surfaces one-by-one if the RPC shape
            # changes or rejects the workspace (e.g. already gone).
            _log.warning(
                "cmux workspace.close %s failed (%s); falling back to "
                "per-surface close",
                container_ref, exc,
            )
            try:
                for s in _list_surfaces(container_ref):
                    try:
                        _rpc("surface.close", {"surface_id": s["ref"]})
                    except RuntimeError as inner:
                        _log.warning(
                            "cmux close surface %s: %s", s.get("ref"), inner,
                        )
            except RuntimeError as inner:
                _log.warning(
                    "cmux close_group_container %s: %s", container_ref, inner,
                )

    def send_text(self, target_id: str, text: str) -> None:
        """Send text to the session, wait for processing, then send Enter.

        Collapse blank lines (``\\n\\n+``) into a single space before send.
        Claude Code's Ink TUI submits on every ``\\n`` and discards empty
        submits, which splits multi-paragraph messages at each blank line.
        Replacing blank lines with a space preserves per-paragraph ``\\n``
        as multiline input while eliminating the empty-submit trigger —
        the whole message arrives as one turn.

        NOTE: this is a best-effort workaround; no cleaner fix found.
        Attempts that did NOT work:
          - Wrapping text in bracketed-paste envelope
            (``\\x1b[200~ ... \\x1b[201~``): Ink renders the marker bytes
            literally because cmux/ghostty terminal caps don't make Ink
            enable bracketed-paste mode.
          - cmux RPC exposes no paste-dedicated method (only generic
            ``surface.send_text`` / ``surface.send_key``).
        Side effect: paragraph-separating blank lines collapse to a single
        space — visual separation is lost but message semantics preserved.
        """
        text = re.sub(r"\n\n+", " ", text)
        _rpc("surface.send_text", {"surface_id": target_id, "text": text})
        time.sleep(2)
        _rpc("surface.send_key", {"surface_id": target_id, "key": "Enter"})

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to the session."""
        key_map = {"escape": "escape", "enter": "Enter", "ctrl-c": "ctrl-c"}
        cmux_key = key_map.get(key, key)
        _rpc("surface.send_key", {"surface_id": target_id, "key": cmux_key})

    def read_screen(self, target_id: str) -> str:
        """Return current visible screen content via cmux CLI."""
        result = subprocess.run(
            ["cmux", "read-screen", "--surface", target_id],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout

    def close(self, target_id: str) -> None:
        """Close the surface via RPC."""
        try:
            _rpc("surface.close", {"surface_id": target_id})
        except RuntimeError as e:
            _log.warning("close %s: %s", target_id, e)

    def resolve_target_id(self, pid: int) -> str | None:
        """Read CMUX_SURFACE_ID from the running process's env."""
        try:
            result = subprocess.run(
                ["ps", "eww", "-p", str(pid)],
                capture_output=True, text=True, timeout=5,
            )
        except Exception:
            return None
        for token in result.stdout.replace("\n", " ").split(" "):
            if token.startswith("CMUX_SURFACE_ID="):
                return token.split("=", 1)[1]
        return None
