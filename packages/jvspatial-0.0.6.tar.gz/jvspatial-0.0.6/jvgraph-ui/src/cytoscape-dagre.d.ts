declare module 'cytoscape-dagre'
