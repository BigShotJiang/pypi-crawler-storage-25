"""Test utilities for jvspatial."""
