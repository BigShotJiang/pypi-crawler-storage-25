"""
### Tribulnation Btcmarkets
> An SDK to connect Btcmarkets with the Tribulnation ecosystem.

- Details
"""