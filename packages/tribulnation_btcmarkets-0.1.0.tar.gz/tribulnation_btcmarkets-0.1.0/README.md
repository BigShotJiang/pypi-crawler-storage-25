# Tribulnation Btcmarkets SDK

> An SDK to connect Btcmarkets with the Tribulnation ecosystem.

🚧 Under construction.