# Policy Reference

Policies are YAML files stored in `.surak/` at your repo root. Each file defines one policy — which workflows it targets, which environments it applies to, and which rules to enforce.

## Contents

- [`applies-to`](#applies-to)
- [`environments`](#environments)
- [Prebuilt policies](#prebuilt-policies)
  - [`actor_allowlist`](#actor_allowlist)
  - [`runner_type`](#runner_type)
  - [`runner_os`](#runner_os)
  - [`runner_arch`](#runner_arch)
  - [`runner_image`](#runner_image)
  - [`branch_protection`](#branch_protection)
  - [`required_checks`](#required_checks)
- [Recommended layout](#recommended-layout)

---

## File format

```yaml
surak: v2                          # required — must be "v2"
id: prod-deployment                # unique identifier, used in reports
name: Production Deployment Policy # human-readable label

applies-to:                        # which workflows this policy covers
  - .github/workflows/deploy.yml
  # or: applies-to: "*"

environments:                      # optional — scope to specific environments
  - production
  # or: environments: "*"

policies:
  actor_allowlist:
    enabled: true
    allow:
      - octocat

  runner_type:
    enabled: true
    require: github-hosted

  runner_os:
    enabled: true
    allow:
      - Linux

  runner_arch:
    enabled: true
    allow:
      - X64

  runner_image:
    enabled: true
    skip_if_self_hosted: true
    allow:
      - ubuntu-22.04
      - ubuntu-24.04

  branch_protection:
    enabled: true
    require: main

  required_checks:
    enabled: true
    checks:
      - Tests
      - Security Scan
```

---

## `applies-to`

Controls which workflow files this policy is evaluated against.

```yaml
applies-to:
  - .github/workflows/deploy.yml
  - .github/workflows/release.yml

# or all workflows
applies-to: "*"
```

Paths are matched relative to the repo root. Leading `./` is ignored.

---

## `environments`

Declares which GitHub environments are permitted for this policy. When present, Surak checks the `ENVIRONMENT` variable set automatically by GHA when `environment:` is declared in a workflow job.

```yaml
# specific environments
environments:
  - production

# multiple environments
environments:
  - staging
  - beta

# any environment — but one must be declared
environments: "*"
```

**Enforcement rules:**

| Situation | Result |
|---|---|
| Policy has no `environments` block | Always evaluates — environment is irrelevant |
| `environments` set, `environment:` declared and in the list | Evaluates all policies |
| `environments` set, `environment:` declared but not in the list | **Fails** |
| `environments` set, `environment:` not declared in the job | **Fails** |

**GitHub environments are job-level only** — there is no workflow-level `environment:` in GitHub Actions. Each job declares its own environment independently.

**Important:** GitHub does not automatically expose `environment:` as a shell environment variable. You must pass it explicitly to the Surak eval step:

```yaml
jobs:
  policy-gate:
    runs-on: ubuntu-22.04
    environment: production
    outputs:
      environment: production

    steps:
      - uses: actions/checkout@v4

      - name: Evaluate policies
        run: surak eval .surak/ --json-output
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          SURAK_ENVIRONMENT: production        # must be set explicitly
```

The recommended pattern using the action — pass `ENVIRONMENT` explicitly and inherit downstream:

```yaml
jobs:
  policy-gate:
    runs-on: ubuntu-22.04
    environment: production
    outputs:
      environment: production

    steps:
      - uses: actions/checkout@v4
      - uses: spockops/surak-action@v1
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          SURAK_ENVIRONMENT: production        # must be set explicitly

  deploy:
    runs-on: ubuntu-22.04
    environment: ${{ needs.policy-gate.outputs.environment }}   # inherited
    needs: policy-gate
    steps:
      - run: echo "deploying to ${{ needs.policy-gate.outputs.environment }}"
```

This way the environment string is declared once on `policy-gate`, enforced by Surak, and all downstream jobs inherit it without repeating the value.

---

## Prebuilt policies

### `actor_allowlist`

Restricts who can trigger the workflow.

```yaml
actor_allowlist:
  enabled: true
  allow:
    - octocat
    - "dependabot[bot]"
    - "bot-*"              # glob patterns supported
```

Source: `$GITHUB_ACTOR`

---

### `runner_type`

Enforces whether the runner must be GitHub-hosted or self-hosted. This is the primary security boundary between managed and unmanaged infrastructure.

```yaml
runner_type:
  enabled: true
  require: github-hosted    # or: self-hosted
```

Source: `$RUNNER_ENVIRONMENT`

---

### `runner_os`

Enforces the runner operating system.

```yaml
runner_os:
  enabled: true
  allow:
    - Linux
    - macOS
```

Source: `$RUNNER_OS`. Values: `Linux`, `Windows`, `macOS`.

---

### `runner_arch`

Enforces the runner CPU architecture.

```yaml
runner_arch:
  enabled: true
  allow:
    - X64
    - ARM64
```

Source: `$RUNNER_ARCH`. Values: `X64`, `ARM64`, `X86`.

---

### `runner_image`

Enforces the specific runner image. Only available on GitHub-hosted runners.

```yaml
runner_image:
  enabled: true
  skip_if_self_hosted: true   # silently pass on self-hosted (recommended)
  allow:
    - ubuntu-22.04
    - ubuntu-24.04
    - macos-14
    - ubuntu-*                # glob patterns supported
```

Source: `$ImageOS` → synthesised to canonical label.

| `ImageOS` | Canonical |
|---|---|
| `ubuntu22` | `ubuntu-22.04` |
| `ubuntu24` | `ubuntu-24.04` |
| `win22` | `windows-2022` |
| `macos14` | `macos-14` |

Set `skip_if_self_hosted: true` to silently pass on self-hosted runners where `ImageOS` is not available.

---

### `branch_protection`

Enforces that the workflow runs from a specific branch.

```yaml
branch_protection:
  enabled: true
  require: main

# glob patterns:
branch_protection:
  enabled: true
  require: "release/*"
```

Source: `$GITHUB_REF`, normalised (`refs/heads/main` → `main`).

---

### `required_checks`

Enforces that named check suites have passed. Requires `GITHUB_TOKEN` with `checks: read`.

```yaml
required_checks:
  enabled: true
  checks:
    - Tests
    - Security Scan
    - "Tests (3.11)"     # matrix job names must match exactly as shown in GitHub UI
```

Add to your workflow job:

```yaml
permissions:
  checks: read
```

A check passes if `status=completed` and `conclusion` is `success` or `neutral`.

---

## Recommended layout

```
.surak/
├── governance.yml      # applies-to: "*" — global runner rules
├── production.yml      # environment-scoped production gate
├── staging.yml         # environment-scoped staging gate
└── publish.yml         # workflow-specific publish gate
```