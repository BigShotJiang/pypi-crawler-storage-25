# CLI Usage

## Installation

```bash
pip install surak
# or
uv pip install surak
```

Verify:

```bash
surak --version
surak haiku
```

---

## Commands

### `eval` — evaluate policies

The primary enforcement command. Loads policies, resolves context, exits non-zero if any policy fails.

```bash
surak eval <policies> [options]
```

| Option | Description |
|---|---|
| `--workflow` | Workflow file path to evaluate against |
| `--dummy` | Use built-in dummy context (local dev only) |
| `--context` | Path to a context JSON file |
| `--json-output` | Output results as JSON |
| `--no-strict` | Don't exit 1 on failure |

```bash
# Inside GitHub Actions — auto-detects context from env vars
surak eval .surak/

# Local dev with dummy context
surak eval .surak/ --workflow .github/workflows/deploy.yml --dummy

# With a context file
surak eval .surak/ --workflow .github/workflows/deploy.yml --context ctx.json

# JSON output
surak eval .surak/ --workflow .github/workflows/deploy.yml --dummy --json-output
```

**JSON output shape:**

```json
{
  "status": "pass",
  "workflow": ".github/workflows/deploy.yml",
  "total": 2,
  "passed": 2,
  "failed": 0,
  "results": [
    {
      "policy_id": "prod-deployment",
      "policy_name": "Production Deployment Policy",
      "passed": true,
      "violations": [],
      "warnings": []
    }
  ]
}
```

---

### `check` — preview which policies apply

Dry-run matching without evaluating. The workflow file must exist on disk.

```bash
surak check .surak/ --workflow .github/workflows/deploy.yml
```

```
Workflow: .github/workflows/deploy.yml

✓ 2 of 3 policy(ies) apply:

  ◆ prod-deployment  —  Production Deployment Policy
  ◆ runner-governance  —  Runner Governance

○ 1 skipped:

  ○ ci-policy  —  CI Workflow Policy  (applies-to: ['.github/workflows/tests.yml'])
```

---

### `validate` — check policy syntax

```bash
surak validate .surak/deploy.yml
```

```
✓ Policy is valid

  ID:         prod-deployment
  Name:       Production Deployment Policy
  Applies to: ['.github/workflows/deploy.yml']
  Policies:   actor_allowlist, runner_type, runner_os, runner_image, branch_protection
```

---

### `list` — list all policies

```bash
surak list .surak/
```

---

## Context resolution

When running inside GitHub Actions, Surak auto-resolves context from environment variables — no `--context` flag needed.

| Field | Source |
|---|---|
| `actor` | `$GITHUB_ACTOR` |
| `branch` | `$GITHUB_REF` (normalised) |
| `runner_type` | `$RUNNER_ENVIRONMENT` |
| `runner_os` | `$RUNNER_OS` |
| `runner_arch` | `$RUNNER_ARCH` |
| `runner_image` | `$ImageOS` → synthesised to `ubuntu-22.04` etc. |
| `workflow_path` | `$GITHUB_WORKFLOW_REF` |
| `environment` | `$SURAK_ENVIRONMENT` — set explicitly in your step env block |

---

## Context JSON format

For local runs with `--context`:

```json
{
  "actor": "octocat",
  "branch": "main",
  "runner_name": "my-runner",
  "runner_os": "Linux",
  "runner_labels": ["github-hosted", "Linux", "ubuntu-22.04", "X64"],
  "workflow_path": ".github/workflows/deploy.yml",
  "event_name": "push",
  "check_statuses": {
    "Tests": { "status": "completed", "conclusion": "success" },
    "Security Scan": { "status": "completed", "conclusion": "success" }
  }
}
```

The `runner_labels` array is the source of truth for runner policies — include `github-hosted` or `self-hosted`, the OS, image label, and arch.