"""Surak v2 engine — loads policies, resolves context, evaluates."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Union

import yaml

from .context.base import ResolvedContext
from .policies import (
    ActorAllowlistEvaluator,
    BranchProtectionEvaluator,
    PolicyResult,
    RequiredChecksEvaluator,
    RunnerArchEvaluator,
    RunnerImageEvaluator,
    RunnerOsEvaluator,
    RunnerTypeEvaluator,
)
from .schema import PolicyV2


# ---------------------------------------------------------------------------
# Evaluation result
# ---------------------------------------------------------------------------

@dataclass
class EvaluationResult:
    """Result for a single PolicyV2 evaluated against a context."""

    policy_id: str
    policy_name: str
    passed: bool
    results: list[PolicyResult] = field(default_factory=list)

    @property
    def violations(self) -> list[str]:
        return [v for r in self.results for v in r.violations]

    @property
    def warnings(self) -> list[str]:
        return [w for r in self.results for w in r.warnings]


@dataclass
class SurakReport:
    """Aggregated report across all evaluated policies."""

    workflow_path: Optional[str]
    total: int
    passed: int
    failed: int
    results: list[EvaluationResult] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.failed == 0

    def as_dict(self) -> dict:
        return {
            "status": "pass" if self.ok else "fail",
            "workflow": self.workflow_path,
            "total": self.total,
            "passed": self.passed,
            "failed": self.failed,
            "results": [
                {
                    "policy_id": r.policy_id,
                    "policy_name": r.policy_name,
                    "passed": r.passed,
                    "violations": r.violations,
                    "warnings": r.warnings,
                }
                for r in self.results
            ],
        }


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class SurakEngine:
    """
    Core policy engine — stateless, instantiate once.

    Usage (in GHA):
        engine = SurakEngine()
        policies = engine.load_dir(Path(".surak"))
        ctx = GHAContext().build()
        report = engine.evaluate_all(policies, ctx, workflow_path=ctx.workflow_path)

    Usage (in SpockOps):
        policies = engine.load_file(Path("..."))
        ctx = WebhookContext.from_payload(payload).build()
        applicable = engine.for_workflow(".github/workflows/deploy.yml", policies)
        report = engine.evaluate_all(applicable, ctx)
    """

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_file(self, path: Path) -> PolicyV2:
        return PolicyV2.from_file(path)

    def load_dir(self, directory: Path) -> list[PolicyV2]:
        """Load all *.yml / *.yaml files in a directory as v2 policies."""
        policies: list[PolicyV2] = []
        for ext in ("*.yml", "*.yaml"):
            for path in sorted(directory.glob(ext)):
                try:
                    policies.append(self.load_file(path))
                except Exception as exc:
                    raise ValueError(f"Failed to load policy '{path}': {exc}") from exc
        return policies

    def load_files(self, paths: list[Path]) -> list[PolicyV2]:
        return [self.load_file(p) for p in paths]

    # ------------------------------------------------------------------
    # Workflow matching
    # ------------------------------------------------------------------

    def for_workflow(
        self,
        workflow_path: str,
        policies: list[PolicyV2],
    ) -> list[PolicyV2]:
        """Return only the policies that apply to the given workflow file path."""
        return [p for p in policies if p.matches_workflow(workflow_path)]

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(
        self,
        policy: PolicyV2,
        ctx: ResolvedContext,
    ) -> EvaluationResult:
        """Evaluate a single policy against a resolved context."""
        results: list[PolicyResult] = []
        pb = policy.policies

        # Environment enforcement
        if policy.is_environment_scoped:
            env = ctx.environment
            allowed = policy.environments

            if env is None:
                # Policy declares environments but workflow didn't — hard fail
                return EvaluationResult(
                    policy_id=policy.id,
                    policy_name=policy.name,
                    passed=False,
                    results=[PolicyResult(
                        policy_id="environment",
                        passed=False,
                        violations=[
                            f"Policy requires environment to be declared. "
                            f"Add 'environment: {allowed[0] if isinstance(allowed, list) else '<name>'}' "  # type: ignore[index]
                            f"to your workflow job. "
                            f"Permitted environments: {', '.join(allowed) if allowed != '*' else 'any'}."  # type: ignore[arg-type]
                        ],
                    )],
                )

            if allowed != "*" and env not in allowed:  # type: ignore[operator]
                # Environment declared but not in allowlist — fail
                return EvaluationResult(
                    policy_id=policy.id,
                    policy_name=policy.name,
                    passed=False,
                    results=[PolicyResult(
                        policy_id="environment",
                        passed=False,
                        violations=[
                            f"Environment '{env}' is not permitted. "
                            f"Allowed: {', '.join(allowed)}."  # type: ignore[arg-type]
                        ],
                    )],
                )

        if pb.actor_allowlist and pb.actor_allowlist.enabled:
            results.append(ActorAllowlistEvaluator(pb.actor_allowlist).evaluate(ctx))

        if pb.runner_type and pb.runner_type.enabled:
            results.append(RunnerTypeEvaluator(pb.runner_type).evaluate(ctx))

        if pb.runner_os and pb.runner_os.enabled:
            results.append(RunnerOsEvaluator(pb.runner_os).evaluate(ctx))

        if pb.runner_arch and pb.runner_arch.enabled:
            results.append(RunnerArchEvaluator(pb.runner_arch).evaluate(ctx))

        if pb.runner_image and pb.runner_image.enabled:
            results.append(RunnerImageEvaluator(pb.runner_image).evaluate(ctx))

        if pb.branch_protection and pb.branch_protection.enabled:
            results.append(BranchProtectionEvaluator(pb.branch_protection).evaluate(ctx))

        if pb.required_checks and pb.required_checks.enabled:
            results.append(RequiredChecksEvaluator(pb.required_checks).evaluate(ctx))

        passed = all(r.passed for r in results)

        return EvaluationResult(
            policy_id=policy.id,
            policy_name=policy.name,
            passed=passed,
            results=results,
        )

    def evaluate_all(
        self,
        policies: list[PolicyV2],
        ctx: ResolvedContext,
        workflow_path: Optional[str] = None,
    ) -> SurakReport:
        """Evaluate all policies and return an aggregated report."""
        results: list[EvaluationResult] = []

        for policy in policies:
            results.append(self.evaluate(policy, ctx))

        passed = sum(1 for r in results if r.passed)
        failed = len(results) - passed

        return SurakReport(
            workflow_path=workflow_path or ctx.workflow_path,
            total=len(results),
            passed=passed,
            failed=failed,
            results=results,
        )