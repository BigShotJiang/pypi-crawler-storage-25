"""Surak v2 policy schema — Pydantic models."""

from __future__ import annotations

from typing import Literal, Optional, Union
import yaml
from pathlib import Path
from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------------
# Per-policy config blocks
# ---------------------------------------------------------------------------

class ActorAllowlistConfig(BaseModel):
    enabled: bool = True
    allow: list[str] = Field(default_factory=list)
    teams: list[str] = Field(default_factory=list)


class RunnerTypeConfig(BaseModel):
    enabled: bool = True
    require: Literal["github-hosted", "self-hosted"]


class RunnerOsConfig(BaseModel):
    enabled: bool = True
    allow: list[str] = Field(default_factory=list)


class RunnerArchConfig(BaseModel):
    enabled: bool = True
    allow: list[str] = Field(default_factory=list)


class RunnerImageConfig(BaseModel):
    enabled: bool = True
    allow: list[str] = Field(default_factory=list)
    skip_if_self_hosted: bool = False


class BranchProtectionConfig(BaseModel):
    enabled: bool = True
    require: str


class RequiredChecksConfig(BaseModel):
    enabled: bool = True
    checks: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Top-level policies block
# ---------------------------------------------------------------------------

class PoliciesBlock(BaseModel):
    actor_allowlist: Optional[ActorAllowlistConfig] = None
    runner_type: Optional[RunnerTypeConfig] = None
    runner_os: Optional[RunnerOsConfig] = None
    runner_arch: Optional[RunnerArchConfig] = None
    runner_image: Optional[RunnerImageConfig] = None
    branch_protection: Optional[BranchProtectionConfig] = None
    required_checks: Optional[RequiredChecksConfig] = None

    @model_validator(mode="after")
    def at_least_one_policy(self) -> "PoliciesBlock":
        fields = [
            self.actor_allowlist,
            self.runner_type,
            self.runner_os,
            self.runner_arch,
            self.runner_image,
            self.branch_protection,
            self.required_checks,
        ]
        if not any(f is not None for f in fields):
            raise ValueError("At least one policy must be defined.")
        return self


# ---------------------------------------------------------------------------
# Top-level policy
# ---------------------------------------------------------------------------

class PolicyV2(BaseModel):
    surak: Literal["v2"]
    id: str
    name: str
    applies_to: Union[Literal["*"], list[str]] = Field(alias="applies-to")
    environments: Union[Literal["*"], list[str], None] = None
    policies: PoliciesBlock

    model_config = {"populate_by_name": True}

    # ------------------------------------------------------------------
    # Matching
    # ------------------------------------------------------------------

    def matches_workflow(self, workflow_path: str) -> bool:
        if self.applies_to == "*":
            return True
        def _norm(p: str) -> str:
            return p.lstrip("./")
        needle = _norm(workflow_path)
        return any(_norm(p) == needle for p in self.applies_to)  # type: ignore[union-attr]

    def matches_environment(self, environment: Optional[str]) -> bool:
        """
        Returns True if this policy should be evaluated for the given environment.

        Rules:
          - No environments block → always matches (non-environment-scoped policy)
          - environments: "*" → matches any environment, but REQUIRES one to be set
          - environments: [production, staging] → matches only those values
          - In all environment-scoped cases: if environment is None (not declared
            in the workflow), the policy FAILS — not skips.
        """
        if self.environments is None:
            return True
        # Policy is environment-scoped — environment MUST be declared
        return True  # matched/failed is handled in engine, not here

    @property
    def is_environment_scoped(self) -> bool:
        return self.environments is not None

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_file(cls, path: Path) -> "PolicyV2":
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls.model_validate(data)

    @classmethod
    def from_dict(cls, data: dict) -> "PolicyV2":
        return cls.model_validate(data)

    @classmethod
    def from_yaml(cls, text: str) -> "PolicyV2":
        return cls.model_validate(yaml.safe_load(text))

    @classmethod
    def build(
        cls,
        id: str,
        name: str,
        applies_to: Union[Literal["*"], list[str]],
        *,
        environments: Union[Literal["*"], list[str], None] = None,
        actor_allowlist: Optional[list[str]] = None,
        runner_type: Optional[Literal["github-hosted", "self-hosted"]] = None,
        runner_os: Optional[list[str]] = None,
        runner_arch: Optional[list[str]] = None,
        runner_image: Optional[list[str]] = None,
        runner_image_skip_if_self_hosted: bool = False,
        branch_protection: Optional[str] = None,
        required_checks: Optional[list[str]] = None,
    ) -> "PolicyV2":
        policies: dict = {}

        if actor_allowlist is not None:
            policies["actor_allowlist"] = {"enabled": True, "allow": actor_allowlist}
        if runner_type is not None:
            policies["runner_type"] = {"enabled": True, "require": runner_type}
        if runner_os is not None:
            policies["runner_os"] = {"enabled": True, "allow": runner_os}
        if runner_arch is not None:
            policies["runner_arch"] = {"enabled": True, "allow": runner_arch}
        if runner_image is not None:
            policies["runner_image"] = {
                "enabled": True,
                "allow": runner_image,
                "skip_if_self_hosted": runner_image_skip_if_self_hosted,
            }
        if branch_protection is not None:
            policies["branch_protection"] = {"enabled": True, "require": branch_protection}
        if required_checks is not None:
            policies["required_checks"] = {"enabled": True, "checks": required_checks}

        if not policies:
            raise ValueError("At least one policy constraint must be provided.")

        data: dict = {
            "surak": "v2",
            "id": id,
            "name": name,
            "applies-to": applies_to,
            "policies": policies,
        }
        if environments is not None:
            data["environments"] = environments

        return cls.model_validate(data)