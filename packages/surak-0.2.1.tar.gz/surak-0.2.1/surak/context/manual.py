"""Manual context builder — for dry-runs, testing, and CLI --dry-run flag."""

from __future__ import annotations

from typing import Any, Optional

from .base import CheckStatus, ResolvedContext


class ManualContext:
    def __init__(
        self,
        actor: Optional[str] = None,
        branch: Optional[str] = None,
        runner_name: Optional[str] = None,
        runner_os: Optional[str] = None,
        runner_labels: Optional[list[str]] = None,
        workflow_path: Optional[str] = None,
        workflow_name: Optional[str] = None,
        event_name: Optional[str] = None,
        environment: Optional[str] = None,
        check_statuses: Optional[dict[str, Any]] = None,
    ) -> None:
        self._actor = actor
        self._branch = branch
        self._runner_name = runner_name
        self._runner_os = runner_os
        self._runner_labels = runner_labels or []
        self._workflow_path = workflow_path
        self._workflow_name = workflow_name
        self._event_name = event_name
        self._environment = environment
        self._raw_checks = check_statuses or {}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ManualContext":
        return cls(
            actor=data.get("actor"),
            branch=data.get("branch"),
            runner_name=data.get("runner_name"),
            runner_os=data.get("runner_os"),
            runner_labels=data.get("runner_labels", []),
            workflow_path=data.get("workflow_path"),
            workflow_name=data.get("workflow_name"),
            event_name=data.get("event_name"),
            environment=data.get("environment"),
            check_statuses=data.get("check_statuses", {}),
        )

    def build(self) -> ResolvedContext:
        check_statuses: dict[str, CheckStatus] = {}
        for name, info in self._raw_checks.items():
            if isinstance(info, dict):
                check_statuses[name] = CheckStatus(
                    name=name,
                    status=info.get("status", "unknown"),
                    conclusion=info.get("conclusion"),
                )
            elif isinstance(info, str):
                check_statuses[name] = CheckStatus(name=name, status=info)

        return ResolvedContext(
            actor=self._actor,
            branch=self._branch,
            runner_name=self._runner_name,
            runner_os=self._runner_os,
            runner_labels=self._runner_labels,
            workflow_path=self._workflow_path,
            workflow_name=self._workflow_name,
            event_name=self._event_name,
            environment=self._environment,
            check_statuses=check_statuses,
            source="manual",
        )