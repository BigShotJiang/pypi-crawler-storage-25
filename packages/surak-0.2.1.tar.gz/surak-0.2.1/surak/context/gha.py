"""GHA context builder — resolves context from GitHub Actions environment variables."""

from __future__ import annotations

import json
import os
from typing import Optional

import httpx

from .base import CheckStatus, ResolvedContext


def _normalise_ref(ref: Optional[str]) -> Optional[str]:
    """Convert refs/heads/main → main, refs/tags/v1.0 → v1.0, etc."""
    if not ref:
        return None
    for prefix in ("refs/heads/", "refs/tags/", "refs/"):
        if ref.startswith(prefix):
            return ref[len(prefix):]
    return ref


def _image_os_to_canonical(image_os: str) -> Optional[str]:
    """
    Convert GHA ImageOS env var to canonical runs-on label.

    ImageOS values:       Canonical:
      ubuntu22       →    ubuntu-22.04
      ubuntu24       →    ubuntu-24.04
      ubuntu20       →    ubuntu-20.04
      win22          →    windows-2022
      win19          →    windows-2019
      macos14        →    macos-14
      macos13        →    macos-13
      macos12        →    macos-12
    """
    mapping = {
        "ubuntu20": "ubuntu-20.04",
        "ubuntu22": "ubuntu-22.04",
        "ubuntu24": "ubuntu-24.04",
        "win19":    "windows-2019",
        "win22":    "windows-2022",
        "macos12":  "macos-12",
        "macos13":  "macos-13",
        "macos14":  "macos-14",
        "macos15":  "macos-15",
    }
    return mapping.get(image_os.lower())


class GHAContext:
    """
    Builds a ResolvedContext from GitHub Actions environment variables.

    Env vars used:
        GITHUB_ACTOR          — who triggered the run
        GITHUB_REF            — refs/heads/main etc.
        RUNNER_NAME           — internal runner name (not the runs-on label)
        RUNNER_OS             — Linux | Windows | macOS
        ImageOS               — ubuntu22 | win22 | macos14 (github-hosted only)
        RUNNER_ENVIRONMENT    — github-hosted | self-hosted
        RUNNER_LABELS         — JSON array (self-hosted runners only)
        GITHUB_WORKFLOW_REF   — owner/repo/.github/workflows/x.yml@refs/heads/main
        GITHUB_WORKFLOW       — workflow name
        GITHUB_EVENT_NAME     — push | pull_request | workflow_dispatch etc.
        GITHUB_TOKEN          — required for required_checks policy
        GITHUB_REPOSITORY     — owner/repo
        GITHUB_SHA            — commit SHA
        SURAK_ENVIRONMENT     — set this explicitly in your workflow step env block.
                                GitHub does not expose environment: as a shell variable.
    """

    def __init__(self, token: Optional[str] = None) -> None:
        self._token = token or os.getenv("GITHUB_TOKEN")

    def build(self) -> ResolvedContext:
        raw_ref = os.getenv("GITHUB_REF")
        workflow_ref = os.getenv("GITHUB_WORKFLOW_REF", "")

        # GITHUB_WORKFLOW_REF: octocat/hello/.github/workflows/deploy.yml@refs/heads/main
        workflow_path: Optional[str] = None
        if workflow_ref and "/" in workflow_ref:
            parts = workflow_ref.split("/", 2)
            if len(parts) == 3:
                workflow_path = parts[2].split("@")[0]

        # Build runner label set from all available sources
        runner_labels_raw = os.getenv("RUNNER_LABELS", "[]")
        try:
            runner_labels: list[str] = json.loads(runner_labels_raw)
        except (json.JSONDecodeError, TypeError):
            runner_labels = []

        runner_name = os.getenv("RUNNER_NAME")
        runner_os = os.getenv("RUNNER_OS")          # Linux | Windows | macOS
        image_os = os.getenv("ImageOS")             # ubuntu22 | win22 | macos14
        runner_env = os.getenv("RUNNER_ENVIRONMENT") # github-hosted | self-hosted

        for label in [runner_name, runner_os, image_os, runner_env]:
            if label and label not in runner_labels:
                runner_labels.append(label)

        # Synthesise canonical label (ubuntu-22.04) from ImageOS (ubuntu22)
        # so policies can use the same label as runs-on:
        if image_os:
            canonical = _image_os_to_canonical(image_os)
            if canonical and canonical not in runner_labels:
                runner_labels.append(canonical)

        # ubuntu-latest resolves to a specific version — add it as a label
        # if we detect a github-hosted ubuntu runner so policies can allow "ubuntu-latest"
        if runner_env == "github-hosted" and runner_os == "Linux":
            if "ubuntu-latest" not in runner_labels:
                runner_labels.append("ubuntu-latest")

        return ResolvedContext(
            actor=os.getenv("GITHUB_ACTOR"),
            branch=_normalise_ref(raw_ref),
            runner_name=runner_name,
            runner_os=runner_os,
            runner_labels=runner_labels,
            workflow_path=workflow_path,
            workflow_name=os.getenv("GITHUB_WORKFLOW"),
            event_name=os.getenv("GITHUB_EVENT_NAME"),
            environment=os.getenv("SURAK_ENVIRONMENT"),
            source="gha_env",
        )

    def fetch_check_statuses(self, check_names: list[str]) -> dict[str, CheckStatus]:
        """
        Fetch check suite statuses from the GitHub API.
        Requires GITHUB_TOKEN with checks: read permission.
        """
        if not self._token:
            raise RuntimeError(
                "GITHUB_TOKEN is required to evaluate required_checks policy. "
                "Add 'permissions: checks: read' to your workflow job."
            )

        repo = os.getenv("GITHUB_REPOSITORY")
        sha = os.getenv("GITHUB_SHA")

        if not repo or not sha:
            raise RuntimeError(
                "GITHUB_REPOSITORY and GITHUB_SHA must be set to fetch check statuses."
            )

        url = f"https://api.github.com/repos/{repo}/commits/{sha}/check-runs"
        headers = {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

        statuses: dict[str, CheckStatus] = {}
        page = 1

        while True:
            resp = httpx.get(url, headers=headers, params={"per_page": 100, "page": page})
            resp.raise_for_status()
            data = resp.json()
            runs = data.get("check_runs", [])

            for run in runs:
                name = run["name"]
                if name in check_names:
                    statuses[name] = CheckStatus(
                        name=name,
                        status=run["status"],
                        conclusion=run.get("conclusion"),
                    )

            if len(runs) < 100:
                break
            page += 1

        return statuses