"""
Surak v2 — Universal Policy Engine for CI/CD.

Constructing policies:
    PolicyV2.build(...)         — programmatic, no files (SpockOps, APIs)
    PolicyV2.from_yaml(text)    — from raw YAML text (GitHub API file contents)
    PolicyV2.from_file(path)    — from a file on disk (CLI, reusable action)
    PolicyV2.from_dict(data)    — from an already-parsed dict

Running the engine:
    from surak import SurakEngine, PolicyV2
    from surak.context import WebhookContext

    engine = SurakEngine()
    policy = PolicyV2.build(id="gate", name="Gate", applies_to=["*"],
                            actor_allowlist=["octocat"])
    ctx = WebhookContext.from_payload(payload).build()
    report = engine.evaluate_all([policy], ctx)
"""

from .engine import EvaluationResult, SurakEngine, SurakReport
from .schema import (
    ActorAllowlistConfig,
    BranchProtectionConfig,
    PoliciesBlock,
    PolicyV2,
    RequiredChecksConfig,
    RunnerArchConfig,
    RunnerImageConfig,
    RunnerOsConfig,
    RunnerTypeConfig,
)

__all__ = [
    "SurakEngine",
    "SurakReport",
    "EvaluationResult",
    "PolicyV2",
    "PoliciesBlock",
    "ActorAllowlistConfig",
    "RunnerTypeConfig",
    "RunnerOsConfig",
    "RunnerArchConfig",
    "RunnerImageConfig",
    "BranchProtectionConfig",
    "RequiredChecksConfig",
]

__version__ = "0.2.1"