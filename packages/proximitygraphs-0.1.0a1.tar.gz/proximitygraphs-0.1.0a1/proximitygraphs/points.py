# https://hpaulkeeler.com/ para point process

import numpy as np

from scipy.stats import poisson, uniform
from scipy.optimize import minimize
from matplotlib.pyplot import savefig, subplots

from .utils import points_on_sphere


def _require_gis_dependencies():
    try:
        import geopandas as gpd
    except ImportError as exc:
        raise ImportError(
            "GeoPandas support requires the optional GIS dependencies. "
            "Install them with: pip install -e .[gis]"
        ) from exc

    try:
        from shapely.geometry import Point
    except ImportError as exc:
        raise ImportError(
            "Shapely support requires the optional GIS dependencies. "
            "Install them with: pip install -e .[gis]"
        ) from exc

    return gpd, Point


class SetPoints:
    """
    Represent an ordered collection of points in the plane.

    Attributes:
        n (int): The number of points in the collection.
        points (numpy.ndarray): An 2-dimensional numpy array the points.
    """

    # ATTRIBUTES

    @property
    def n(self):
        return self.__n

    @property
    def dim(self):
        return self.__dim

    @property
    def points(self):
        return self.__points

    @property
    def pos(self):
        return dict(enumerate(self.__points))

    @property
    def centroid(self):
        return np.mean(self.__points, axis=0)

    # CONSTRUCTORS

    def __init__(self, points, seed=None):
        """
        Base constructor for SetPoints.
        attributes:
        ----------
        points : numpy.ndarray
            A 2D numpy array of shape (n, dim) where n is the number of points and dim is the dimension of each point.
        seed : int, optional
            A seed for the random number generator to ensure reproducibility. If None, a default random generator is used.
        Raises:
        ------
        TypeError: If points is not a numpy.ndarray.


        returns  a SetPoints object containing the points.
        """

        if not isinstance(points, np.ndarray):
            raise TypeError("Input 'points' must be a numpy.ndarray.")
        self.__points = points
        self.__n, self.__dim = np.shape(points)
        if seed is None:
            self._rng = np.random.default_rng()
        else:
            self._rng = np.random.default_rng(seed)

    def __add__(self, other):
        new_points = np.concatenate((self.points, other.points), axis=0)
        return SetPoints(new_points)

    def copy(self):
        return SetPoints(self.points)

    @classmethod
    def uniform_square(cls, n=10, seed=None):
        """
        Generate a random uniform sample of points in the unit square [0,1]^2.

        Mechanism
        ---------
        Let X = (X1, X2) in R^2. Sample coordinates independently:
            X1 ~ U(0,1),  X2 ~ U(0,1)  (i.i.d.)
        Then X is uniform over the unit square (constant density on [0,1]^2).

        Parameters
        ----------
        n : int
            Number of points.
        seed : int or None
            RNG seed. If None, uses entropy from the OS (non-deterministic).

        Returns
        -------
        cls
            Instance with points of shape (n, 2).
        """
        if not isinstance(n, int) or n <= 0:
            raise ValueError("n must be a positive integer")

        rng = np.random.default_rng(seed)
        points = rng.random((n, 2))
        return cls(points)

    @classmethod
    def uniform_over_sphere(cls, n=10, seed=None):
        """
        Generate a random uniform sample of points on the unit circle S^1 subset R^2.

        Mechanism
        ---------
        Draw Z ~ N(0, I2), then project onto the circle:
            X = Z / ||Z||2
        This produces a rotationally-invariant (uniform) distribution on S^1.

        Parameters
        ----------
        n : int
            Number of points.
        seed : int or None
            RNG seed. If None, uses entropy from the OS (non-deterministic).

        Returns
        -------
        cls
            Instance with points of shape (n, 2).
        """
        if not isinstance(n, int) or n <= 0:
            raise ValueError("n must be a positive integer")

        rng = np.random.default_rng(seed)
        points = points_on_sphere(n, 2, rng=rng)
        return cls(points)

    @classmethod
    def uniform_sphere(cls, n=10, seed=None):
        """
        Generate a random uniform sample of points in the unit disk B^2 subset R^2.

        Mechanism
        ---------
        1) Sample a direction uniformly on S^1 via U = Z / ||Z||2, with Z ~ N(0, I2).
        2) Sample radius with area-correct scaling: if V ~ U(0,1), set R = sqrt(V).
        This gives P(R <= r) = r^2, which matches uniform area in the disk.
        3) Set X = R * U.

        Parameters
        ----------
        n : int
            Number of points.
        seed : int or None
            RNG seed. If None, uses entropy from the OS (non-deterministic).

        Returns
        -------
        cls
            Instance with points of shape (n, 2).
        """
        if not isinstance(n, int) or n <= 0:
            raise ValueError("n must be a positive integer")

        rng = np.random.default_rng(seed)

        radius = np.sqrt(rng.random((n, 1)))
        direction = points_on_sphere(n, 2, rng=rng)  # points on S^1
        points = radius * direction
        return cls(points)

    @classmethod
    def normal_dist(cls, n=10, seed=None):
        """
        Generate a random sample of points from the bivariate standard normal N(0, I2).

        Mechanism
        ---------
        Draw X in R^2 with mean vector 0 and covariance matrix I2.
        Components are independent with unit variance.

        Parameters
        ----------
        n : int
            Number of points.
        seed : int or None
            RNG seed. If None, uses entropy from the OS (non-deterministic).

        Returns
        -------
        cls
            Instance with points of shape (n, 2).
        """
        if not isinstance(n, int) or n <= 0:
            raise ValueError("n must be a positive integer")

        rng = np.random.default_rng(seed)
        mean = np.zeros(2)
        cov = np.eye(2)
        points = rng.multivariate_normal(mean, cov, n)
        return cls(points)

    @classmethod
    def grid(cls, shape=(3, 3)):
        """
        Generates a regular 2D grid of points.

        The points form a 2D grid. The `shape` parameter is a tuple (n_x, n_y)
        defining the number of steps along each axis.

        Coordinates are integers on each axis. This implementation uses:
            x in {0, 1, ..., n_x}
            y in {0, 1, ..., n_y}
        via numpy.arange(0, n_i + 1), then builds all combinations with meshgrid.

        Parameters
        ----------
        shape : tuple of int
            A tuple (n_x, n_y). Only 2D grids are supported.

        Returns
        -------
        cls
            Instance with points of shape ((n_x+1)*(n_y+1), 2).
        """
        if not isinstance(shape, tuple):
            raise ValueError("shape must be a tuple")
        if len(shape) != 2:
            raise ValueError("shape must be a tuple of length 2: (n_x, n_y)")
        nx, ny = shape
        if not (isinstance(nx, int) and isinstance(ny, int)) or nx <= 0 or ny <= 0:
            raise ValueError("shape entries must be positive integers")

        axes = [np.arange(0, nx), np.arange(0, ny)]
        mesh = np.meshgrid(*axes, indexing="ij")
        points = np.column_stack([m.ravel() for m in mesh])
        return cls(points)

    @classmethod
    def hexagonal(cls, n_x=3, n_y=3):
        """
        Generates points forming a hexagonal lattice in a 2D plane.

        A hexagonal lattice can be represented as the union of two interleaved
        rectangular (or oblique) grids. This implementation constructs it as such.
        Points in a hexagonal grid are centers of hexagons in a tessellation.

        The method first generates a base grid (`grid_1`). The x-coordinates in
        this grid are spaced by alternating increments (e.g., 1, 2, 1, 2,...),
        and y-coordinates are spaced by `sqrt(3)` (or `2*sqrt(3)` depending on interpretation).
        A second grid (`grid_2`) is then generated. Its x-coordinates are also
        spaced by alternating increments but offset from `grid_1` (e.g., by -0.5
        relative to a scaled version of `grid_1`'s x-pattern). The y-coordinates
        of `grid_2` are also spaced by `sqrt(3)` but are offset vertically from
        `grid_1`'s y-coordinates by `0.5 * sqrt(3)`.

        The combination of these two grids results in the characteristic hexagonal
        pattern where each point has 6 equidistant neighbors (assuming appropriate
        scaling).

        Note: This implementation is for 2D hexagonal grids only.
        The `n_x` and `n_y` parameters control the extent of the grid.

        Parameters:
        ----------
        n_x : int
            Determines the extent of the hexagonal grid along an axis roughly aligned
            with the x-direction. It influences the number of columns.
        n_y : int
            Determines the extent of the hexagonal grid along an axis roughly aligned
            with the y-direction. It influences the number of rows.
        """
        try:
            if n_x <= 0 or n_y <= 0:
                raise ValueError("n_x and n_y must be positive integers")
        except ValueError as e:
            print(e)

        x = np.cumsum(np.array([1, 2] * n_x))
        x = np.insert(x, 0, 0)
        y = np.cumsum(np.array([np.sqrt(3)] * 2 * n_y))
        y = np.insert(y, 0, 0)
        xv, yv = np.meshgrid(x, y)
        grid_1 = np.array(list(zip(xv.flat, yv.flat)))
        x = np.cumsum(np.array([2, 1] * n_x))
        x = np.insert(x, 0, 0) - 0.5
        y = np.cumsum(np.array([np.sqrt(3)] * 2 * n_y))
        y = np.insert(y, 0, 0)
        y = y + 0.5 * np.sqrt(3)
        xv, yv = np.meshgrid(x, y)
        grid_2 = np.array(list(zip(xv.flat, yv.flat)))
        points = np.concatenate((grid_1, grid_2))
        return cls(points)

    @classmethod
    def triangular(cls, n_x=3, n_y=3):
        """
        Generates points forming a triangular lattice in a 2D plane.

        A triangular lattice can be seen as the centers of a triangular tessellation
        of the plane. It is constructed by combining two offset grids:

        1.  The first grid (`grid_1`) has points `(i, j * sqrt(3))` where `i` ranges
            from `0` to `n_x` and `j` ranges over multiples for `n_y` rows.
            Specifically, x-coordinates are `0, 1, 2, ..., n_x`.
            Y-coordinates are `0, sqrt(3), 2*sqrt(3), ...`.

        2.  The second grid (`grid_2`) is offset from the first. Its points are
            `(i + 0.5, (j + 0.5) * sqrt(3))`.
            Specifically, x-coordinates are `0.5, 1.5, 2.5, ...`.
            Y-coordinates are `0.5*sqrt(3), 1.5*sqrt(3), ...`.

        The combination of these two grids forms a triangular lattice. Each point in
        this lattice has 6 equidistant neighbors, forming equilateral triangles.
        The term `sqrt(3)` arises from the height of an equilateral triangle with
        side length 1 (if x-spacing is 1 unit between points on the same horizontal line
        of a sub-grid).

        Note: This implementation is for 2D triangular grids only.
        The `n_x` and `n_y` parameters control the extent of the grid.
        The existing docstring has a typo: "surface of the hexagon" should be
        related to triangles.

        Parameters:
        ----------
        n_x : int
            Determines the extent of the triangular grid along the x-direction.
            It influences the number of points in horizontal rows of the sub-grids.
        n_y : int
            Determines the extent of the triangular grid along the y-direction.
            It influences the number of rows in the sub-grids.
        """
        try:
            if n_x <= 0 or n_y <= 0:
                raise ValueError("n_x and n_y must be positive integers")
        except ValueError as e:
            print(e)

        x = np.arange(0, n_x + 1)
        y = np.arange(0, np.sqrt(3) * np.floor(n_y / 2) + 1, np.sqrt(3))
        xv, yv = np.meshgrid(x, y)
        grid_1 = np.array(list(zip(xv.flat, yv.flat)))
        x = x + 0.5
        y = np.arange(np.sqrt(3) / 2, np.sqrt(3) * np.ceil(n_y / 2), np.sqrt(3))
        xv, yv = np.meshgrid(x, y)
        grid_2 = np.array(list(zip(xv.flat, yv.flat)))
        points = np.concatenate((grid_1, grid_2))
        return cls(points)

    @classmethod
    def poissonprocess_square(cls, intensity=10, limit=1, seed=None):
        """
        Generates points according to a homogeneous Poisson point process in a square region.

        A 2D homogeneous Poisson point process is characterized by a constant intensity
        (lambda, denoted as `intensity` here) which represents the average number of
        points per unit area.

        The generation process involves two steps:
        1.  The number of points, `N`, to be generated in the square region is drawn
            from a Poisson distribution with mean `L = intensity * area`. The `area`
            is calculated as `(xmax - xmin) * (ymax - ymin)`, where the simulation
            window is defined by `(xmin, ymin)` to `(xmax, ymax)`. In this method,
            `xmin` and `ymin` are 0, and `xmax` and `ymax` are `limit`. So, `area = limit^2`.
        2.  Given `N` points, their x-coordinates are drawn independently from a
            uniform distribution U(0, `limit`), and their y-coordinates are drawn
            independently from a uniform distribution U(0, `limit`).

        This results in a set of points whose locations are random and uniformly
        distributed within the square defined by `(0,0)` and `(limit, limit)`.

        Parameters:
        ----------
        intensity : float
            The intensity (lambda) of the Poisson process, representing the average
            number of points per unit area. Must be a positive value.
        limit : float
            The side length of the square simulation window, which extends from
            (0,0) to (limit, limit). Must be a positive value.
        seed : int, optional
            A seed for the random number generator to ensure reproducibility.
            If None, the RNG is initialized without a specific seed. Defaults to None.
        """
        try:
            if intensity <= 0 or limit <= 0:
                raise ValueError("intensity and limit must be positive values")
        except ValueError as e:
            print(e)

        rng = np.random.default_rng(seed=seed)
        limits = ((0, limit), (0, limit))
        # Simulation window parameters
        xmin, xmax = limits[0]
        ymin, ymax = limits[1]
        xdelta = xmax - xmin
        ydelta = ymax - ymin
        area = xdelta * ydelta
        n_points = poisson(intensity * area).rvs(random_state=rng)
        x = xdelta * uniform.rvs(0, 1, size=((n_points, 1)), random_state=rng) + xmin
        y = ydelta * uniform.rvs(0, 1, size=((n_points, 1)), random_state=rng) + ymin
        points = np.hstack((x, y))
        return cls(points, seed=rng.integers(low=0, high=2**32 - 1))

    @classmethod
    def poissonprocess_circle(cls, intensity=10, radius=1, seed=None):
        """
        Generates points according to a homogeneous Poisson point process on the circumference of a circle.

        This method simulates points positioned on the perimeter of a circle of a given `radius`.
        The process is homogeneous, meaning the intensity of points is uniform along the circumference.

        The generation process involves two main steps:
        1.  The number of points, `N`, to be placed on the circumference is drawn
            from a Poisson distribution. The mean of this distribution is
            `L = intensity * length`, where `length` is the circumference of the
            circle (2 * pi * `radius`). The `intensity` parameter here represents the
            average number of points per unit length along the circumference.
        2.  Given `N` points, their angular positions (theta) are drawn independently
            from a uniform distribution U(0, 2*pi). These angles are then converted
            to Cartesian coordinates (x, y) using the standard transformation:
            x = `radius` * cos(theta)
            y = `radius` * sin(theta)

        This results in a set of points randomly distributed along the circumference
        of the circle.

        Parameters:
        ----------
        intensity : float
            The intensity (lambda) of the Poisson process, representing the average
            number of points per unit length along the circumference.
        radius : float
            The radius of the circle on whose circumference the points will be generated.
            Must be a positive value.
        seed : int, optional
            A seed for the random number generator to ensure reproducibility.
            If None, the RNG is initialized without a specific seed. Defaults to None.
        """
        rng = np.random.default_rng(seed=seed)
        length = 2 * np.pi * radius
        n_points = rng.poisson(intensity * length)
        theta = 2 * np.pi * rng.uniform(0, 1, n_points)
        x = radius * np.cos(theta)
        y = radius * np.sin(theta)
        points = np.stack((x, y), axis=1)
        return cls(points, seed=rng.integers(low=0, high=2**32 - 1))

    @classmethod
    def poissonprocess_inhomogeneus(
        cls,
        fun_lambda=lambda x, y: x + y,
        n_sim=1,  # This parameter is unused
        limit=1,
        seed=None,
    ):
        """
        Generates points according to an inhomogeneous Poisson point process in a square region using thinning.

        An inhomogeneous (or nonhomogeneous) Poisson point process is characterized by an
        intensity function `fun_lambda(x,y)` that varies spatially. The value of
        `fun_lambda(x,y)` at a point (x,y) dictates the likelihood of finding a point
        in the infinitesimal area around (x,y).

        This method uses the thinning algorithm (also known as acceptance-rejection sampling):
        1.  **Find Maximum Intensity (`lambda_max`)**: The maximum value of the intensity
            function `fun_lambda(x,y)` within the simulation window `(0, limit) x (0, limit)`
            is determined. This is done by numerically minimizing `-fun_lambda(x,y)`
            using `scipy.optimize.minimize`.
        2.  **Generate Homogeneous Proposal Points**: A set of proposal points is generated
            from a homogeneous Poisson point process with constant intensity `lambda_max`
            over the square simulation window (area = `limit`*`limit`). The number of these
            proposal points, `N_prop`, is drawn from Poisson(`lambda_max` * area).
            Their coordinates are uniformly distributed within the square.
        3.  **Thinning**: Each proposal point `(x_i, y_i)` is "kept" or "thinned"
            (discarded) based on a spatially dependent probability. The probability of
            keeping a point at `(x_i, y_i)` is `p(x_i, y_i) = fun_lambda(x_i, y_i) / lambda_max`.
            This is achieved by generating a random number `u_i` from U(0,1) for each
            proposal point and keeping the point if `u_i < p(x_i, y_i)`.

        The resulting set of retained points follows the inhomogeneous Poisson process
        defined by `fun_lambda(x,y)`.

        Parameters:
        ----------
        fun_lambda : callable
            A function that takes two arguments (x, y coordinates) and returns the
            intensity of the Poisson process at that point.
            Example: `lambda x, y: x + y`
        n_sim : int
            This parameter appears in the original signature but is not used in the
            current implementation. (Consider for future review/deprecation).
        limit : float
            The side length of the square simulation window, which extends from
            (0,0) to (limit, limit). The process is simulated within this area.
        seed : int, optional
            A seed for the random number generator to ensure reproducibility.
            If None, the RNG is initialized without a specific seed. Defaults to None.
        """
        rng = np.random.default_rng(seed=seed)
        limits = ((0, limit), (0, limit))
        # fun_lambda = lambda x,y: np.cos(2*x)+np.cos(2*y)
        xmin, xmax = limits[0]
        ymin, ymax = limits[1]
        xdelta = xmax - xmin
        ydelta = ymax - ymin
        area = xdelta * ydelta

        # Find maximum lambda
        def fun_neg(x):
            return -fun_lambda(x[0], x[1])

        xy0 = [(xmin + xmax) / 2, (ymin + ymax) / 2]
        results_opt = minimize(fun_neg, xy0, bounds=((xmin, xmax), (ymin, ymax)))
        lambda_neg_min = results_opt.fun
        lambda_max = -lambda_neg_min

        # define thinning probability function
        def fun_p(x, y):
            return fun_lambda(x, y) / lambda_max

        # Simulate a Poisson point process
        # Corrected n_poins to n_points
        n_points = rng.poisson(area * lambda_max)
        x = rng.uniform(0, xdelta, size=((n_points, 1))) + xmin
        y = rng.uniform(0, ydelta, size=((n_points, 1))) + ymin
        # calculate spatially-dependent thinning probabilities
        p = fun_p(x, y)
        # Generate Bernoulli variables (ie coin flips) for thinning
        retained = rng.uniform(0, 1, size=((n_points, 1))) < p
        # x/y locations of retained points
        x_retained = x[retained]
        y_retained = y[retained]
        points = np.stack((x_retained, y_retained), axis=1)
        return cls(points, seed=rng.integers(low=0, high=2**32 - 1))

    @classmethod
    def cluster_square(
        cls,
        intensity=(10, 10),
        cluster={"name": "Matern", "param": 0.1},
        limit=1,
        seed=None,
    ):
        """
        Generates points according to a Neyman-Scott cluster process in a square region.

        A Neyman-Scott process is a type of cluster point process where "parent" points
        are first generated by a Poisson process. Then, for each parent, a random
        number of "daughter" points are scattered around it according to some
        distribution. This method implements two types of daughter point distributions:
        Matern and Thomas.

        The generation process involves:
        1.  **Parent Point Generation**:
            *   Parent points are generated from a homogeneous Poisson point process with
                intensity `intensity[0]`.
            *   This generation occurs in an "extended window" larger than the final
                simulation window `(0, limit) x (0, limit)`. The extension size depends
                on the cluster type (`radius` for Matern, `5*sigma` for Thomas) to
                mitigate edge effects where clusters centered near the boundary might
                incorrectly have fewer points within the final window.

        2.  **Daughter Point Generation (Clustering)**:
            *   For each parent point, a number of daughter points is drawn from a
                Poisson distribution with mean `intensity[1]`.
            *   The spatial distribution of these daughter points around their parent
                depends on the `cluster["name"]`:
                *   **"Matern"**: Daughter points are uniformly distributed within a disk
                    of `radius = cluster["param"]` centered at the parent point. This is
                    achieved by generating points in polar coordinates (rho, theta) where
                    theta is U(0, 2*pi) and rho is `radius * sqrt(U(0,1))`.
                *   **"Thomas"**: Daughter points are distributed according to an isotropic
                    bivariate Gaussian (Normal) distribution centered at the parent point,
                    with standard deviation `sigma = cluster["param"]` for both x and y
                    directions.

        3.  **Thinning to Final Window**:
            *   All generated daughter points are considered. Only those points that fall
                within the original simulation window defined by `(0, limit) x (0, limit)`
                are retained in the final output.

        Parameters:
        ----------
        intensity : tuple of float
            A tuple `(intensity_parent, intensity_daughter)`.
            `intensity[0]` is the intensity of the parent Poisson process.
            `intensity[1]` is the mean number of daughter points per parent.
        cluster : dict
            A dictionary specifying the cluster generation mechanism.
            It must contain:
            `"name"`: str, either "Matern" or "Thomas".
            `"param"`: float, the parameter for the chosen mechanism
                       (disk radius for Matern, standard deviation sigma for Thomas).
        limit : float
            The side length of the square simulation window `(0, limit) x (0, limit)`.
            Must be a positive value.
        seed : int, optional
            A seed for the random number generator to ensure reproducibility.
            If None, the RNG is initialized without a specific seed. Defaults to None.
        """
        rng = np.random.default_rng(seed=seed)
        limits = ((0, limit), (0, limit))
        # intensity[0] - density of parent Poisson point process
        # indensity[1] - mean number of points in each cluster
        # Extended simulation window parameters
        xmin, xmax = limits[0]
        ymin, ymax = limits[1]
        if cluster["name"] == "Matern":
            radius = cluster["param"]
        elif cluster["name"] == "Thomas":
            radius = 5 * cluster["param"]
        xmin_ext = xmin - radius
        xmax_ext = xmax + radius
        ymin_ext = ymin - radius
        ymax_ext = ymax + radius
        xdelta = xmax_ext - xmin_ext
        ydelta = ymax_ext - ymin_ext
        area = xdelta * ydelta
        # Simulated Poisson points process for the parents
        n_points_parent = rng.poisson(area * intensity[0])
        x_parent = xmin_ext + xdelta * rng.uniform(0, 1, n_points_parent)
        y_parent = ymin_ext + ydelta * rng.uniform(0, 1, n_points_parent)
        # Simulate Poisson point process for the daughters
        n_points_daughter = rng.poisson(intensity[1], size=n_points_parent)
        n_points = sum(n_points_daughter)
        if cluster["name"] == "Matern":
            # Generate the (relative) locations in polar coordinates
            theta = 2 * np.pi * rng.uniform(0, 1, n_points)
            rho = radius * np.sqrt(rng.uniform(0, 1, n_points))
            # Convert from polar to Cartesian coordinates
            x_aux = rho * np.cos(theta)
            y_aux = rho * np.sin(theta)
        elif cluster["name"] == "Thomas":
            # Generate the (relative) locations in Cartesian coordinates
            x_aux = rng.normal(0, cluster["param"], n_points)
            y_aux = rng.normal(0, cluster["param"], n_points)
        # replicate parent points (ie centres of disks/clusters)
        x = np.repeat(x_parent, n_points_daughter)
        y = np.repeat(y_parent, n_points_daughter)
        x = x + x_aux
        y = y + y_aux
        # thin points if outside the simulation window
        inside = (x >= xmin) & (x <= xmax) & (y >= ymin) & (y <= ymax)
        # retain points inside simulation window
        x = x[inside]
        y = y[inside]
        points = np.stack((x, y), axis=1)
        return cls(points, seed=rng.integers(low=0, high=2**32 - 1))

    @classmethod
    def from_geopandas(cls, geoseries, seed=None):
        """
        Creates a SetPoints object from a geopandas.GeoSeries of Points.

        Parameters:
        ----------
        geoseries : geopandas.GeoSeries
            A GeoSeries containing shapely.geometry.Point objects.
        seed : int, optional
            A seed for the random number generator.

        Returns:
        -------
        SetPoints
            A new SetPoints object.

        Raises:
        ------
        TypeError
            If geoseries is not a geopandas.GeoSeries.
        ValueError
            If geoseries is empty or contains non-Point geometries.
        """
        gpd, Point = _require_gis_dependencies()

        if not isinstance(geoseries, gpd.GeoSeries):
            raise TypeError("Input 'geoseries' must be a geopandas.GeoSeries.")

        if geoseries.empty:
            raise ValueError("Input 'geoseries' cannot be empty.")

        if not all(isinstance(geom, Point) for geom in geoseries):
            raise ValueError(
                "All geometries in 'geoseries' must be shapely.geometry.Point instances."
            )

        coords = np.array([(point.x, point.y) for point in geoseries])
        return cls(coords, seed=seed)

    # METHODS

    def draw(
        self,
        figsize=(6, 6),
        v_size=8,
        v_color="#00072D",
        v_alpha=1,
        title=True,
        fontsize=10,
        details=False,
        axis=False,
        save=None,
        *,
        fig_kwargs=None,
        v_kwargs=None,
        title_kwargs=None,
        savefig_kwargs=None,
    ):
        """
        Draws 2D points using Matplotlib.

        Parameters
        ----------
        figsize : tuple of (float, float), optional
            Figure size in inches. Default (6, 6).
        v_size : float, optional
            Marker size for points. 0 disables scatter. Default 3.
        v_color : str, optional
            Point color passed to Matplotlib. Default "#00072D".
        v_alpha : float, optional
            Point alpha (transparency) in [0,1]. Default 1.
        title : bool, optional
            Whether to set a title. Default True.
        fontsize : float, optional
            Title font size. Default 10.
        details : bool, optional
            If True, appends self.details to the title (if present). Default False.
        axis : bool, optional
            If True, show axes. Default False.
        save : str or None, optional
            If set, saves a ".png" at save + ".png". If None, returns (fig, ax).

        Other Parameters
        ----------------
        fig_kwargs : dict, optional
            Extra keyword arguments passed to matplotlib.pyplot.subplots.
        v_kwargs : dict, optional
            Extra keyword arguments passed to ax.scatter.
            These override v_size, v_color, v_alpha if duplicated.
        title_kwargs : dict, optional
            Extra keyword arguments passed to ax.set_title.
            These override fontsize if duplicated.
        savefig_kwargs : dict, optional
            Extra keyword arguments passed to matplotlib.pyplot.savefig.

        Returns
        -------
        (fig, ax) : tuple
            Matplotlib figure and axes.
        """
        fig_kwargs = {} if fig_kwargs is None else dict(fig_kwargs)
        v_kwargs = {} if v_kwargs is None else dict(v_kwargs)
        title_kwargs = {} if title_kwargs is None else dict(title_kwargs)
        savefig_kwargs = {} if savefig_kwargs is None else dict(savefig_kwargs)

        # enforce 2D
        if not hasattr(self, "points"):
            raise AttributeError("Object has no attribute 'points'")
        if self.points.ndim != 2 or self.points.shape[1] != 2:
            raise ValueError(
                f"draw() is 2D-only: expected points with shape (n, 2); got {self.points.shape}"
            )

        # figure and axes (same as geometric graphs)
        fig, ax = subplots(figsize=figsize, **fig_kwargs)

        # points (same naming as vertices)
        if self.points.shape[0] > 0 and v_size > 0:
            scatter_kwargs = dict(
                s=v_size,
                c=v_color,
                alpha=v_alpha,
                linewidths=0,  # no outline
                edgecolors="none",  # no outline
            )
            scatter_kwargs.update(v_kwargs)  # user overrides defaults
            ax.scatter(self.points[:, 0], self.points[:, 1], **scatter_kwargs)

        # title (same logic as geometric graphs)
        if title:
            plot_title = getattr(self, "name", self.__class__.__name__)
            if details and getattr(self, "details", None):
                plot_title += f"\n{self.details}"
            title_args = dict(fontsize=fontsize)
            title_args.update(title_kwargs)
            ax.set_title(plot_title, **title_args)

        # axes (same as geometric graphs)
        if not axis:
            ax.set_axis_off()
        else:
            ax.set_axis_on()
        ax.set_aspect("equal", adjustable="box")

        # save or return (same as geometric graphs)
        if save is None:
            return fig, ax
        else:
            savefig(save + ".png", bbox_inches="tight", **savefig_kwargs)
            return fig, ax

    def __affin_transformation(self, matrix=None, c=None):
        """
        Applies a general affine transformation to the set of points.

        An affine transformation combines a linear transformation (like rotation,
        scaling, or shear) and a translation. If `P` is the original `n x dim` matrix
        of points (where `n` is the number of points and `dim` is their dimension),
        `M` is a `dim x dim` transformation matrix, and `t` is a `1 x dim` translation
        vector, the new set of points `P'` is computed as:

        `P'_i = P_i @ M + t` for each point `P_i` (row in `P`).

        Or, in matrix form for all points:
        `P' = P @ M + t_broadcasted`
        where `t_broadcasted` is the translation vector `t` broadcasted to apply
        to each row of `P @ M`.

        This method is a general helper used by more specific transformations like
        rotation, scaling, and translation.

        Parameters:
        ----------
        matrix : numpy.ndarray, optional
            The `dim x dim` linear transformation matrix. If None, an identity matrix
            of the appropriate dimension is used (implying no linear transformation).
            Defaults to None.
        c : numpy.ndarray, optional
            The `1 x dim` translation vector. If None, a zero vector is used
            (implying no translation). Defaults to None.

        Returns:
        -------
        SetPoints
            A new SetPoints object containing the transformed points.
        """
        if matrix is None:
            matrix = np.eye(self.dim)
        if c is None:
            c = np.zeros(self.dim)

        matrix = np.asarray(matrix)
        c = np.asarray(c)
        trasnformation = self.points @ matrix + c
        return SetPoints(np.asanyarray(trasnformation))

    def rotation(self, angle, degree=True):
        """
        Applies a 2D rotation to the set of points around the origin (0,0).

        This method rotates the points counter-clockwise by a given angle `theta`.
        The transformation is only defined for 2D points (i.e., `self.dim` must be 2).

        The rotation is achieved by applying an affine transformation with a specific
        rotation matrix and no translation. The 2D counter-clockwise rotation matrix is:
          M = [[cos(theta),  sin(theta)],
               [-sin(theta), cos(theta)]]
        If `P_i = (x_i, y_i)` is an original point, the rotated point `P'_i = (x'_i, y'_i)`
        is calculated as:
          x'_i = x_i * cos(theta) - y_i * sin(theta)
          y'_i = x_i * sin(theta) + y_i * cos(theta)
        This corresponds to `P' = P @ M.T` if using row vectors for points, or `P' = M @ P` if using column vectors.
        The code implements `P @ matrix` where `matrix` is as defined above.

        Parameters:
        ----------
        angle : float
            The angle of rotation.
        degree : bool, optional
            If True (default), the `angle` is interpreted as degrees and will be
            converted to radians. If False, the `angle` is interpreted as radians.

        Returns:
        -------
        SetPoints
            A new SetPoints object containing the rotated points.

        Raises:
        ------
        ValueError
            If the dimension of the points is not 2.
        """
        if self.dim != 2:
            raise ValueError("Rotation is only implemented for 2D points.")
        if degree:
            angle = np.radians(angle)
        cos = np.cos(angle)
        sin = np.sin(angle)
        matrix = np.matrix([[cos, sin], [-sin, cos]])
        return self.__affin_transformation(matrix)

    def scaling(self, scale):
        """
        Applies a scaling transformation to the set of points, relative to the origin.

        This method scales the coordinates of each point. The scaling can be uniform
        across all dimensions (if `scale` is a scalar) or different for each
        dimension (if `scale` is a vector).

        The transformation is an affine transformation `P' = P @ M`, where `M` is a
        diagonal matrix.
        If `scale` is a scalar `s`, then `M` is `s * I`, where `I` is the identity
        matrix. Each coordinate of each point is multiplied by `s`.
          `p'_j = p_j * s` for each coordinate `j`.
        If `scale` is a vector `(s_0, s_1, ..., s_{dim-1})`, then `M` is a diagonal
        matrix with these scaling factors on its diagonal:
          M = [[s_0,   0, ...,   0],
               [  0, s_1, ...,   0],
               [  ..., ..., ..., ...],
               [  0,   0, ..., s_{dim-1}]]
        Each coordinate `j` of a point `p` is multiplied by the corresponding
        scaling factor `s_j`:
          `p'_j = p_j * s_j`.

        The scaling is performed relative to the origin (0,0,...,0).

        Parameters:
        ----------
        scale : float or array-like
            The scaling factor(s).
            If a scalar (float), all dimensions are scaled by this factor.
            If an array-like (e.g., list, tuple, numpy.ndarray) of length `self.dim`,
            each dimension is scaled by the corresponding element in the array.

        Returns:
        -------
        SetPoints
            A new SetPoints object containing the scaled points.

        Raises:
        ------
        ValueError
            If `scale` is an array-like and its shape is not `(self.dim,)`.
        """
        if np.isscalar(scale):
            scale = np.full(self.dim, scale)

        scale = np.asarray(scale)
        if scale.shape != (self.dim,):
            raise ValueError(
                f"Scale vector must have shape ({self.dim},), but got {scale.shape}"
            )

        matrix = np.diag(scale)
        return self.__affin_transformation(matrix=matrix)

    def traslation(self, c):
        """
        Applies a translation to the set of points.

        This method shifts all points in the set by a given vector `c`.
        It's an affine transformation where the linear transformation matrix `M` is
        the identity matrix, and the translation vector is `c`.
        The transformation is: `P' = P + c_broadcasted`.
        For each point `P_i` in the set `P`, the new point `P'_i` is:
          `P'_i = P_i + c`

        If `c` is a scalar, it is treated as a vector where all components are equal
        to `c`. For example, if `dim=3` and `c=5`, the translation vector is `(5,5,5)`.

        Parameters:
        ----------
        c : float or array-like
            The translation vector or scalar.
            If a scalar (float), all dimensions are translated by this value.
            If an array-like (e.g., list, tuple, numpy.ndarray) of length `self.dim`,
            each dimension `j` is translated by the corresponding element `c_j`.

        Returns:
        -------
        SetPoints
            A new SetPoints object containing the translated points.

        Raises:
        ------
        ValueError
            If `c` is an array-like and its shape is not `(self.dim,)`.
        """
        if np.isscalar(c):
            c = np.full(self.dim, c)
        else:
            c = np.asarray(c)
            if c.shape != (self.dim,):
                raise ValueError(
                    f"Translation vector must have shape ({self.dim},), but got {c.shape}"
                )

        return self.__affin_transformation(c=c)

    def perturb(self, radius):
        """
        Applies a random perturbation to each point in the set.

        Each point `p` in the original set is moved to a new location `p' = p + v`,
        where `v` is a random perturbation vector. The perturbation `v` is generated
        such that it is uniformly distributed within a `dim`-dimensional sphere of
        the given `radius` centered at the origin.

        The generation of each perturbation vector `v` involves two steps:
        1.  **Direction**: A random direction is chosen by generating a point uniformly
            on the surface of a `dim`-dimensional unit sphere. This is achieved using
            the `points_on_sphere` utility function (which normalizes a vector of
            standard normal variates). Let this unit vector be `u`.
        2.  **Magnitude**: A random magnitude `m` for the perturbation is determined by
            drawing a random number `r_raw` from a uniform distribution U(0, `radius`).
            To ensure uniform distribution *within* the sphere (not concentrated towards
            the center or edge for higher dimensions), this raw radius is transformed:
            `m = r_raw^(1/dim)`, where `dim` is the number of dimensions.
            Actually, looking at the code `r = np.random.uniform(0, radius, self.n)**(1/self.dim)`,
            it seems `r_raw` is `U(0, radius^dim)` if we want `m` to be `U(0,radius)`.
            Or, more standardly, if `r_sample` is `U(0,1)`, then actual random radius for uniform
            distribution in a d-ball of radius R is `R * r_sample^(1/d)`.
            The code is `r_scalar_factors = np.random.uniform(0, radius, self.n)**(1/self.dim)`.
            This means each point `i` gets a scalar factor `s_i = unif(0, radius)^(1/dim)`.
            This is not standard for uniform distribution *within* a sphere of `radius`.
            If `radius` is, say, 5, then `unif(0,5)^(1/dim)` is taken.
            Let's stick to describing what the code does:
            A scalar `s_i` is generated for each point `i` as `s_i = U_i^(1/dim)`, where `U_i` is
            drawn from `Uniform(0, radius)`. This `s_i` is used as the magnitude for the
            perturbation of point `i`. So `v_i = s_i * u_i`.

        The effect is that each original point is displaced to a new random position.
        The displacement vectors are such that their directions are isotropic, and
        their magnitudes `s_i` are distributed according to `(U(0, radius))^(1/dim)`.
        This means points are more likely to be perturbed by a larger fraction of `radius`
        than a smaller fraction, especially in higher dimensions.

        Note: The docstring of the code `unit_sphere_surface = points_on_sphere(self.n, self.dim)`
        implies `points_on_sphere` is called once for all points.

        Parameters:
        ----------
        radius : float
            The maximum radius for the perturbation. Each random perturbation vector's
            magnitude is determined based on this value, specifically as
            `(U(0, radius))^(1/dim)`. Must be a positive value.

        Returns:
        -------
        SetPoints
            A new SetPoints object containing the perturbed points.

        Raises:
        ------
        ValueError
            If `radius` is not positive.
        """
        if radius < 0:
            raise ValueError("Radius must be positive")

        # Ensure self._rng exists, initialized in __init__
        if not hasattr(self, "_rng") or self._rng is None:
            rng_to_use = np.random.default_rng()
        else:
            rng_to_use = self._rng

        r_magnitudes = rng_to_use.uniform(0, radius, self.n) ** (1 / self.dim)

        unit_sphere_surface = points_on_sphere(self.n, self.dim, rng=rng_to_use)

        perturbations = r_magnitudes.reshape(-1, 1) * unit_sphere_surface
        new_seed_for_next_instance = rng_to_use.integers(low=0, high=2**32 - 1)

        return SetPoints(self.points + perturbations, seed=new_seed_for_next_instance)
