"""Aliyun API interfaces."""
