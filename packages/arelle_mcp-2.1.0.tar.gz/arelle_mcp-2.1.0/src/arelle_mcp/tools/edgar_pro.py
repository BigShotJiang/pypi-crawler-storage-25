"""
Stream 5: EDGAR Pro tools.

Full-text search, company profiles, filing indexes, bulk data,
and insider trading from SEC EDGAR.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.constants import SEC_EDGAR_SUBMISSIONS, SEC_EDGAR_USER_AGENT
from arelle_mcp.truncation import safe_json_dumps

# ─── Shared SEC client ────────────────────────────────────────────────────────

async def _sec_get(url: str) -> dict[str, Any]:
    async with httpx.AsyncClient(
        headers={
            "User-Agent": SEC_EDGAR_USER_AGENT,
            "Accept": "application/json",
            "Accept-Encoding": "gzip, deflate",
        },
        timeout=30.0,
        follow_redirects=True,
    ) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        return resp.json()


def _pad_cik(cik: str) -> str:
    return cik.strip().lstrip("0").zfill(10)


# ─── Input Models ─────────────────────────────────────────────────────────────

class EdgarSearchInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    query: str = Field(..., description="Search text (company name, keyword, etc.)", min_length=1)
    filing_types: list[str] | None = Field(
        default=None, description="Filter by form types: ['10-K', '10-Q', '8-K']"
    )
    date_from: str | None = Field(default=None, description="Start date (YYYY-MM-DD)")
    date_to: str | None = Field(default=None, description="End date (YYYY-MM-DD)")
    limit: int = Field(default=10, ge=1, le=50)


class EdgarCompanyInfoInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    cik: str | None = Field(default=None, description="SEC CIK number")
    ticker: str | None = Field(default=None, description="Stock ticker symbol")


class EdgarFilingIndexInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    cik: str = Field(..., description="SEC CIK number")
    accession_number: str = Field(..., description="Accession number (e.g., '0001628280-25-045968')")


class EdgarBulkFactsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    ciks: list[str] = Field(..., description="List of CIK numbers", min_length=1, max_length=10)
    concepts: list[str] = Field(
        ..., description="List of concept names (e.g., ['Assets', 'Revenues'])",
        min_length=1, max_length=10,
    )
    taxonomy: str = Field(default="us-gaap")


class EdgarInsiderInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    cik: str = Field(..., description="SEC CIK number of the company")
    limit: int = Field(default=20, ge=1, le=100)


# ─── Tool Registration ────────────────────────────────────────────────────────

def register_edgar_pro_tools(mcp: Any) -> None:
    """Register EDGAR Pro tools."""

    @mcp.tool(
        name="xbrl_edgar_search",
        annotations={
            "title": "Search SEC EDGAR",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_edgar_search(params: EdgarSearchInput, ctx: Context) -> str:
        """Full-text search across SEC EDGAR filings.

        Search by company name, keyword, or filing content.
        Returns matching filings with metadata.

        Args:
            params: Search query, optional type/date filters, limit.

        Returns:
            str: JSON with matching filings.
        """
        url = "https://efts.sec.gov/LATEST/search-index"
        query_params: dict[str, Any] = {
            "q": params.query,
            "from": 0,
            "size": params.limit,
        }
        if params.filing_types:
            query_params["forms"] = ",".join(params.filing_types)
        if params.date_from:
            query_params["startdt"] = params.date_from
        if params.date_to:
            query_params["enddt"] = params.date_to

        try:
            async with httpx.AsyncClient(
                headers={"User-Agent": SEC_EDGAR_USER_AGENT},
                timeout=30.0,
            ) as client:
                resp = await client.get(url, params=query_params)
                resp.raise_for_status()
                data = resp.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 403:
                # EFTS may block — fall back to submissions search
                return json.dumps({
                    "error": "SEARCH_UNAVAILABLE",
                    "message": "SEC full-text search returned 403. Try xbrl_edgar_company_info instead.",
                    "suggestion": "Use xbrl_edgar_company_info with a ticker or CIK.",
                })
            return json.dumps({"error": "SEC_API_ERROR", "message": str(e)})
        except Exception as e:
            return json.dumps({"error": "NETWORK_ERROR", "message": str(e)})

        hits = data.get("hits", {}).get("hits", [])
        results = []
        for h in hits[:params.limit]:
            src = h.get("_source", {})
            results.append({
                "company": src.get("display_names", [None])[0] if src.get("display_names") else None,
                "form_type": src.get("form_type"),
                "filed": src.get("file_date"),
                "period": src.get("period_of_report"),
                "accession": src.get("accession_no"),
                "file_url": src.get("file_url"),
            })

        return safe_json_dumps({
            "query": params.query,
            "results": results,
            "total_hits": data.get("hits", {}).get("total", {}).get("value", 0),
        })

    @mcp.tool(
        name="xbrl_edgar_company_info",
        annotations={
            "title": "SEC Company Profile",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_edgar_company_info(params: EdgarCompanyInfoInput, ctx: Context) -> str:
        """Get comprehensive company profile from SEC EDGAR.

        Returns: name, CIK, SIC code, state, addresses, former names,
        and recent filing history by type.

        Args:
            params: CIK or ticker.

        Returns:
            str: JSON with company profile.
        """
        cik = params.cik
        if not cik and params.ticker:
            from arelle_mcp.tools.edgar import _resolve_ticker_to_cik
            cik = await _resolve_ticker_to_cik(params.ticker)
            if not cik:
                return json.dumps({"error": "TICKER_NOT_FOUND", "message": f"Cannot resolve {params.ticker}"})
        if not cik:
            return json.dumps({"error": "MISSING_INPUT", "message": "Provide cik or ticker"})

        padded = _pad_cik(cik)
        try:
            data = await _sec_get(SEC_EDGAR_SUBMISSIONS.format(cik=padded))
        except Exception as e:
            return json.dumps({"error": "SEC_API_ERROR", "message": str(e)})

        # Filing summary by type
        recent = data.get("filings", {}).get("recent", {})
        forms = recent.get("form", [])
        form_counts: dict[str, int] = {}
        for f in forms:
            form_counts[f] = form_counts.get(f, 0) + 1

        profile = {
            "name": data.get("name"),
            "cik": cik,
            "sic": data.get("sic"),
            "sic_description": data.get("sicDescription"),
            "state": data.get("stateOfIncorporation"),
            "fiscal_year_end": data.get("fiscalYearEnd"),
            "tickers": data.get("tickers", []),
            "exchanges": data.get("exchanges", []),
            "category": data.get("category"),
            "former_names": [
                fn.get("name") for fn in data.get("formerNames", [])
            ],
            "addresses": {
                "business": data.get("addresses", {}).get("business", {}),
                "mailing": data.get("addresses", {}).get("mailing", {}),
            },
            "filing_counts": dict(sorted(form_counts.items(), key=lambda x: -x[1])[:15]),
            "total_filings": len(forms),
        }

        return safe_json_dumps(profile)

    @mcp.tool(
        name="xbrl_edgar_filing_index",
        annotations={
            "title": "Filing Document Index",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_edgar_filing_index(params: EdgarFilingIndexInput, ctx: Context) -> str:
        """Get the full index of documents within a specific SEC filing.

        Lists all exhibits, schemas, instances, and other documents
        in a filing with their types, sizes, and URLs.

        Args:
            params: CIK and accession number.

        Returns:
            str: JSON with document list.
        """
        padded = _pad_cik(params.cik)
        accession_clean = params.accession_number.replace("-", "")
        index_url = f"https://www.sec.gov/Archives/edgar/data/{padded}/{accession_clean}/index.json"

        try:
            data = await _sec_get(index_url)
        except Exception as e:
            return json.dumps({"error": "SEC_API_ERROR", "message": str(e)})

        items = data.get("directory", {}).get("item", [])
        documents = []
        for item in items:
            name = item.get("name", "")
            doc_url = f"https://www.sec.gov/Archives/edgar/data/{padded}/{accession_clean}/{name}"
            documents.append({
                "filename": name,
                "type": item.get("type", ""),
                "size": item.get("size"),
                "url": doc_url,
                "description": item.get("description", ""),
            })

        return safe_json_dumps({
            "cik": params.cik,
            "accession": params.accession_number,
            "documents": documents,
            "count": len(documents),
        })

    @mcp.tool(
        name="xbrl_edgar_bulk_facts",
        annotations={
            "title": "Bulk Company Facts",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_edgar_bulk_facts(params: EdgarBulkFactsInput, ctx: Context) -> str:
        """Bulk download fact data for multiple concepts across multiple companies.

        Returns a matrix of company × concept with the most recent value.
        No filing load required.

        Args:
            params: List of CIKs, list of concepts, taxonomy.

        Returns:
            str: JSON matrix of values.
        """
        from arelle_mcp.constants import SEC_EDGAR_COMPANY_CONCEPT

        results = []
        for cik in params.ciks:
            padded = _pad_cik(cik)
            company_data: dict[str, Any] = {"cik": cik}

            for concept in params.concepts:
                url = SEC_EDGAR_COMPANY_CONCEPT.format(
                    cik=padded, taxonomy=params.taxonomy, concept=concept,
                )
                try:
                    data = await _sec_get(url)
                    company_data["name"] = data.get("entityName", "?")

                    # Get most recent value
                    units = data.get("units", {})
                    latest_val = None
                    latest_date = ""
                    for unit_entries in units.values():
                        for entry in unit_entries:
                            end = entry.get("end", entry.get("instant", ""))
                            if end > latest_date:
                                latest_date = end
                                latest_val = entry.get("val")

                    company_data[concept] = {
                        "value": latest_val,
                        "period": latest_date,
                    }
                except Exception:
                    company_data[concept] = {"value": None, "error": "not found"}

            results.append(company_data)

        return safe_json_dumps({
            "companies": results,
            "concepts": params.concepts,
            "taxonomy": params.taxonomy,
        })

    @mcp.tool(
        name="xbrl_edgar_insider_trades",
        annotations={
            "title": "Insider Trading Data",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_edgar_insider_trades(params: EdgarInsiderInput, ctx: Context) -> str:
        """Get insider trading data from SEC Forms 3, 4, 5.

        Returns recent insider transactions including the filer name,
        form type, and filing date.

        Args:
            params: Company CIK and limit.

        Returns:
            str: JSON with insider filing list.
        """
        padded = _pad_cik(params.cik)
        try:
            data = await _sec_get(SEC_EDGAR_SUBMISSIONS.format(cik=padded))
        except Exception as e:
            return json.dumps({"error": "SEC_API_ERROR", "message": str(e)})

        recent = data.get("filings", {}).get("recent", {})
        forms = recent.get("form", [])
        dates = recent.get("filingDate", [])
        accessions = recent.get("accessionNumber", [])
        primary_docs = recent.get("primaryDocument", [])
        descriptions = recent.get("primaryDocDescription", [])

        insider_forms = {"3", "4", "5", "3/A", "4/A", "5/A"}
        trades = []

        for i, form in enumerate(forms):
            if form in insider_forms and len(trades) < params.limit:
                trades.append({
                    "form": form,
                    "date": dates[i] if i < len(dates) else None,
                    "accession": accessions[i] if i < len(accessions) else None,
                    "document": primary_docs[i] if i < len(primary_docs) else None,
                    "description": descriptions[i] if i < len(descriptions) else None,
                })

        return safe_json_dumps({
            "company": data.get("name"),
            "cik": params.cik,
            "insider_filings": trades,
            "count": len(trades),
            "note": "For detailed transaction data, load individual Form 4 filings.",
        })
