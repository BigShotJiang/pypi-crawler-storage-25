"""
Stream 2: Document Intelligence tools.

Extract text content, search within filings, map document structure,
and access the full HTML/iXBRL document beyond just XBRL-tagged facts.
"""

from __future__ import annotations

import json
import re
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.truncation import safe_json_dumps

# ─── Input Models ─────────────────────────────────────────────────────────────

class ExtractTextInput(BaseModel):
    """Input for extracting text from a filing section."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    section: str = Field(
        default="all",
        description=(
            "Section to extract: 'mda' (MD&A), 'risk_factors', 'financial_statements', "
            "'notes', 'controls', 'legal', 'cover', 'all'. Default: 'all'"
        ),
    )
    max_chars: int = Field(
        default=10000,
        description="Max characters to return (default 10000)",
        ge=100, le=100000,
    )


class SearchTextInput(BaseModel):
    """Input for full-text search within a filing."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    query: str = Field(..., description="Search text (case-insensitive)", min_length=1)
    context_chars: int = Field(
        default=300,
        description="Characters of context around each match (default 300)",
        ge=50, le=2000,
    )
    max_results: int = Field(default=10, ge=1, le=50)


class FootnotesInput(BaseModel):
    """Input for extracting footnotes."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    concept_name: str | None = Field(
        default=None, description="Filter footnotes linked to this concept"
    )
    limit: int = Field(default=20, ge=1, le=100)


class SectionsInput(BaseModel):
    """Input for listing document sections."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")


class CoverPageInput(BaseModel):
    """Input for extracting cover page data."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")


class HtmlTablesInput(BaseModel):
    """Input for extracting HTML tables."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    search: str | None = Field(default=None, description="Filter tables containing this text")
    table_index: int | None = Field(default=None, description="Get specific table by index (0-based)")
    max_tables: int = Field(default=5, ge=1, le=20)
    max_rows: int = Field(default=30, ge=1, le=200)


class ExhibitsInput(BaseModel):
    """Input for listing exhibits."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")


class RawXmlInput(BaseModel):
    """Input for accessing raw XML content."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    xpath: str | None = Field(
        default=None,
        description="XPath expression to query (e.g., '//table', '//h2')",
    )
    max_chars: int = Field(default=5000, ge=100, le=50000)


# ─── Helper Functions ─────────────────────────────────────────────────────────

def _get_xml_doc(model: Any) -> Any:
    """Get the lxml document from a model."""
    if model.modelDocument and model.modelDocument.xmlDocument is not None:
        return model.modelDocument.xmlDocument
    return None


def _extract_all_text(xml_doc: Any) -> str:
    """Extract all visible text from an XML/HTML document, stripping tags."""

    # Get root element
    root = xml_doc.getroot() if hasattr(xml_doc, "getroot") else xml_doc

    # Walk all text content, skip script/style
    texts = []
    for elem in root.iter():
        tag = elem.tag if isinstance(elem.tag, str) else ""
        # Strip namespace
        local_tag = tag.split("}")[-1] if "}" in tag else tag

        if local_tag.lower() in ("script", "style", "meta", "link"):
            continue

        if elem.text and elem.text.strip():
            texts.append(elem.text.strip())
        if elem.tail and elem.tail.strip():
            texts.append(elem.tail.strip())

    return "\n".join(texts)


def _find_section_boundaries(full_text: str, section: str) -> tuple[int, int]:
    """Find start/end positions for a named section in filing text."""
    section_patterns = {
        "mda": [
            r"(?i)MANAGEMENT.{0,5}S?\s+DISCUSSION\s+AND\s+ANALYSIS",
            r"(?i)Item\s+2\.\s+Management",
        ],
        "risk_factors": [
            r"(?i)RISK\s+FACTORS",
            r"(?i)Item\s+1A\.\s+Risk\s+Factors",
        ],
        "financial_statements": [
            r"(?i)FINANCIAL\s+STATEMENTS",
            r"(?i)Item\s+8\.\s+Financial\s+Statements",
            r"(?i)CONSOLIDATED\s+BALANCE\s+SHEETS",
        ],
        "notes": [
            r"(?i)NOTES\s+TO\s+(CONSOLIDATED\s+)?FINANCIAL\s+STATEMENTS",
            r"(?i)Note\s+1[\.\s]",
        ],
        "controls": [
            r"(?i)CONTROLS\s+AND\s+PROCEDURES",
            r"(?i)Item\s+4\.\s+Controls",
        ],
        "legal": [
            r"(?i)LEGAL\s+PROCEEDINGS",
            r"(?i)Item\s+1\.\s+Legal",
        ],
        "cover": [
            r"(?i)COVER\s+PAGE",
            r"(?i)UNITED\s+STATES\s+SECURITIES",
        ],
    }

    patterns = section_patterns.get(section, [])
    start = 0
    for pattern in patterns:
        match = re.search(pattern, full_text)
        if match:
            start = match.start()
            break

    if start == 0 and section != "all":
        return -1, -1  # Section not found

    # Find end: next section heading or end of document
    if start > 0:
        next_section = re.search(
            r"(?i)\n\s*(Item\s+\d+[A-Z]?\.|PART\s+[IVX]+)",
            full_text[start + 100:],
        )
        end = (start + 100 + next_section.start()) if next_section else len(full_text)
    else:
        end = len(full_text)

    return start, end


def _parse_table_to_rows(table_elem: Any) -> list[list[str]]:
    """Parse an HTML table element into rows of cell text."""
    rows = []
    for tr in table_elem.iter():
        tag = tr.tag if isinstance(tr.tag, str) else ""
        local_tag = tag.split("}")[-1] if "}" in tag else tag
        if local_tag.lower() != "tr":
            continue

        cells = []
        for td in tr:
            td_tag = td.tag if isinstance(td.tag, str) else ""
            td_local = td_tag.split("}")[-1] if "}" in td_tag else td_tag
            if td_local.lower() in ("td", "th"):
                text = "".join(td.itertext()).strip()
                text = re.sub(r"\s+", " ", text)
                cells.append(text)
        if cells:
            rows.append(cells)
    return rows


# ─── Tool Registration ────────────────────────────────────────────────────────

def register_document_tools(mcp: Any) -> None:
    """Register Document Intelligence tools."""

    @mcp.tool(
        name="xbrl_extract_text",
        annotations={
            "title": "Extract Text from Filing Section",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_extract_text(params: ExtractTextInput, ctx: Context) -> str:
        """Extract clean text from a specific section of a loaded filing.

        Sections: 'mda' (Management Discussion & Analysis), 'risk_factors',
        'financial_statements', 'notes', 'controls', 'legal', 'cover', 'all'.

        This extracts the actual human-readable text from the iXBRL/HTML document,
        not just XBRL-tagged data points. Useful for MD&A analysis, risk assessment,
        and qualitative content extraction.

        Args:
            params: Filing ID, section name, and max characters.

        Returns:
            str: Clean text content from the requested section.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        xml_doc = _get_xml_doc(model)
        if xml_doc is None:
            return json.dumps({
                "error": "NO_DOCUMENT",
                "message": "Filing has no parseable XML/HTML document",
            })

        full_text = _extract_all_text(xml_doc)

        if params.section == "all":
            text = full_text[:params.max_chars]
        else:
            start, end = _find_section_boundaries(full_text, params.section)
            if start == -1:
                return json.dumps({
                    "error": "SECTION_NOT_FOUND",
                    "message": f"Section '{params.section}' not found in filing",
                    "available_sections": ["mda", "risk_factors", "financial_statements",
                                           "notes", "controls", "legal", "cover", "all"],
                    "hint": "Try 'all' to get the full document text",
                })
            text = full_text[start:end][:params.max_chars]

        return safe_json_dumps({
            "section": params.section,
            "text": text,
            "chars": len(text),
            "truncated": len(text) >= params.max_chars,
        })

    @mcp.tool(
        name="xbrl_search_text",
        annotations={
            "title": "Search Text in Filing",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_search_text(params: SearchTextInput, ctx: Context) -> str:
        """Full-text search within a loaded filing's content.

        Searches the entire document text (not just XBRL facts) for the query string.
        Returns matching passages with surrounding context.
        Useful for finding guidance, forward-looking statements, specific disclosures, etc.

        Args:
            params: Filing ID, search query, context size, max results.

        Returns:
            str: JSON with matching passages and their positions.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        xml_doc = _get_xml_doc(model)
        if xml_doc is None:
            return json.dumps({"error": "NO_DOCUMENT", "message": "No parseable document"})

        full_text = _extract_all_text(xml_doc)
        query_lower = params.query.lower()
        text_lower = full_text.lower()

        matches = []
        search_start = 0
        while len(matches) < params.max_results:
            pos = text_lower.find(query_lower, search_start)
            if pos == -1:
                break

            ctx_start = max(0, pos - params.context_chars)
            ctx_end = min(len(full_text), pos + len(params.query) + params.context_chars)
            passage = full_text[ctx_start:ctx_end]

            matches.append({
                "position": pos,
                "passage": passage,
            })
            search_start = pos + len(params.query)

        return safe_json_dumps({
            "query": params.query,
            "match_count": len(matches),
            "matches": matches,
            "document_length": len(full_text),
        })

    @mcp.tool(
        name="xbrl_get_footnotes",
        annotations={
            "title": "Get Fact Footnotes",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_get_footnotes(params: FootnotesInput, ctx: Context) -> str:
        """Extract footnotes linked to XBRL facts.

        XBRL filings can attach footnotes to specific facts, providing additional
        context or explanations. This tool extracts those footnotes.

        Args:
            params: Filing ID, optional concept filter, limit.

        Returns:
            str: JSON with footnotes and their linked facts.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        footnotes = []
        try:
            from arelle import XbrlConst
            fn_rel_set = model.relationshipSet(XbrlConst.factFootnote)

            for rel in fn_rel_set.modelRelationships:
                if len(footnotes) >= params.limit:
                    break

                from_obj = rel.fromModelObject
                to_obj = rel.toModelObject

                if from_obj is None or to_obj is None:
                    continue

                # Filter by concept if specified
                if params.concept_name:
                    local = params.concept_name.split(":")[-1]
                    if from_obj.qname and local.lower() not in str(from_obj.qname).lower():
                        continue

                fn_text = ""
                if hasattr(to_obj, "textValue"):
                    fn_text = to_obj.textValue
                elif hasattr(to_obj, "stringValue"):
                    fn_text = to_obj.stringValue
                else:
                    fn_text = "".join(to_obj.itertext()) if hasattr(to_obj, "itertext") else str(to_obj)

                footnotes.append({
                    "fact_concept": str(from_obj.qname) if hasattr(from_obj, "qname") else "?",
                    "fact_value": getattr(from_obj, "effectiveValue", "?"),
                    "footnote": fn_text.strip()[:2000],  # Cap footnote length
                    "language": getattr(to_obj, "xmlLang", None),
                })
        except Exception as e:
            return json.dumps({
                "footnotes": [],
                "count": 0,
                "note": f"Footnote extraction error: {e}",
            })

        return safe_json_dumps({
            "footnotes": footnotes,
            "count": len(footnotes),
        })

    @mcp.tool(
        name="xbrl_list_sections",
        annotations={
            "title": "List Document Sections",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_list_sections(params: SectionsInput, ctx: Context) -> str:
        """Map the complete document structure of a filing.

        Identifies major sections (Items, Parts) and their approximate positions
        and sizes. Useful for navigating large 10-K/10-Q documents.

        Args:
            params: Filing ID.

        Returns:
            str: JSON with section titles, positions, and sizes.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        xml_doc = _get_xml_doc(model)
        if xml_doc is None:
            return json.dumps({"error": "NO_DOCUMENT", "message": "No parseable document"})

        full_text = _extract_all_text(xml_doc)

        # Find section headings
        section_pattern = re.compile(
            r"(?i)((?:PART\s+[IVX]+|Item\s+\d+[A-Z]?)\.\s*.{5,80})"
        )

        sections = []
        for match in section_pattern.finditer(full_text):
            title = re.sub(r"\s+", " ", match.group(1)).strip()
            sections.append({
                "title": title[:100],
                "position": match.start(),
            })

        # Calculate sizes
        for i, sec in enumerate(sections):
            next_pos = sections[i + 1]["position"] if i + 1 < len(sections) else len(full_text)
            sec["approx_chars"] = next_pos - sec["position"]

        return safe_json_dumps({
            "sections": sections,
            "count": len(sections),
            "total_document_chars": len(full_text),
        })

    @mcp.tool(
        name="xbrl_get_cover_page",
        annotations={
            "title": "Get Filing Cover Page",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_get_cover_page(params: CoverPageInput, ctx: Context) -> str:
        """Extract complete cover page data from a filing.

        Returns all DEI (Document Entity Information) facts as a structured object:
        company name, CIK, ticker, fiscal year, filing date, period, shares, etc.

        Args:
            params: Filing ID.

        Returns:
            str: JSON with all DEI facts.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        dei_facts: dict[str, Any] = {}
        for fact in model.facts:
            if fact.qname and fact.qname.prefix and "dei" in fact.qname.prefix.lower():
                name = fact.qname.localName
                value = fact.effectiveValue
                if name in dei_facts:
                    # Keep the most recent / non-empty value
                    if value and len(str(value)) > len(str(dei_facts[name])):
                        dei_facts[name] = value
                else:
                    dei_facts[name] = value

        return safe_json_dumps({
            "dei_facts": dei_facts,
            "count": len(dei_facts),
        })

    @mcp.tool(
        name="xbrl_get_html_tables",
        annotations={
            "title": "Extract HTML Tables",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_get_html_tables(params: HtmlTablesInput, ctx: Context) -> str:
        """Extract HTML tables from the filing document.

        Finds tables in the HTML content, with optional text search filter.
        Returns tables as structured row/column data.

        Args:
            params: Filing ID, optional search filter, table index, limits.

        Returns:
            str: JSON with table data.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        xml_doc = _get_xml_doc(model)
        if xml_doc is None:
            return json.dumps({"error": "NO_DOCUMENT", "message": "No parseable document"})

        root = xml_doc.getroot() if hasattr(xml_doc, "getroot") else xml_doc

        # Find all <table> elements (any namespace)
        tables_found = []
        for elem in root.iter():
            tag = elem.tag if isinstance(elem.tag, str) else ""
            local_tag = tag.split("}")[-1] if "}" in tag else tag
            if local_tag.lower() == "table":
                tables_found.append(elem)

        # Filter by specific index
        if params.table_index is not None:
            if params.table_index < len(tables_found):
                tables_found = [tables_found[params.table_index]]
            else:
                return json.dumps({
                    "error": "TABLE_NOT_FOUND",
                    "message": f"Table index {params.table_index} out of range (0-{len(tables_found)-1})",
                })

        results = []
        for i, table_elem in enumerate(tables_found):
            if len(results) >= params.max_tables:
                break

            rows = _parse_table_to_rows(table_elem)
            if not rows:
                continue

            # Filter by search text
            if params.search:
                table_text = " ".join(" ".join(row) for row in rows).lower()
                if params.search.lower() not in table_text:
                    continue

            # Truncate rows
            truncated = len(rows) > params.max_rows
            rows = rows[:params.max_rows]

            results.append({
                "table_index": i,
                "rows": rows,
                "row_count": len(rows),
                "col_count": max(len(r) for r in rows) if rows else 0,
                "truncated": truncated,
            })

        return safe_json_dumps({
            "tables": results,
            "total_tables_in_document": len(tables_found),
            "returned": len(results),
        })

    @mcp.tool(
        name="xbrl_get_exhibits",
        annotations={
            "title": "List Filing Exhibits",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_get_exhibits(params: ExhibitsInput, ctx: Context) -> str:
        """List exhibits attached to a filing.

        SEC filings include exhibits like press releases (EX-99.1),
        certifications (EX-31, EX-32), and other documents.
        Returns exhibit list with types and descriptions.

        Args:
            params: Filing ID.

        Returns:
            str: JSON with exhibit list.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        # Extract exhibit info from DEI facts and document references
        exhibits = []

        # Check all DTS documents for exhibit-like references
        for url, _doc in model.urlDocs.items():
            filename = url.split("/")[-1] if "/" in url else url
            # Detect exhibit pattern in filenames
            for pattern in [r"ex-?(\d+)", r"EX-?(\d+)", r"exhibit"]:
                if re.search(pattern, filename, re.IGNORECASE):
                    exhibits.append({
                        "filename": filename,
                        "url": url,
                        "type": _classify_exhibit(filename),
                    })
                    break

        # Also check for exhibit references in facts
        for fact in model.facts:
            if fact.qname and "ExhibitType" in str(fact.qname.localName):
                exhibits.append({
                    "type": fact.effectiveValue,
                    "source": "xbrl_fact",
                })

        return safe_json_dumps({
            "exhibits": exhibits,
            "count": len(exhibits),
            "note": "For full exhibit content, load the exhibit URL with xbrl_load_filing or access via SEC EDGAR.",
        })

    @mcp.tool(
        name="xbrl_get_raw_xml",
        annotations={
            "title": "Get Raw XML/HTML Content",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_get_raw_xml(params: RawXmlInput, ctx: Context) -> str:
        """Access raw XML/HTML content from the filing document.

        Allows XPath queries against the document tree.
        Useful for advanced extraction when other tools don't cover a specific need.

        Args:
            params: Filing ID, optional XPath, max chars.

        Returns:
            str: Raw XML string of matched elements.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        xml_doc = _get_xml_doc(model)
        if xml_doc is None:
            return json.dumps({"error": "NO_DOCUMENT", "message": "No parseable document"})

        from lxml import etree

        root = xml_doc.getroot() if hasattr(xml_doc, "getroot") else xml_doc

        if params.xpath:
            try:
                # Handle namespaces
                nsmap = {k: v for k, v in root.nsmap.items() if k is not None}
                elements = root.xpath(params.xpath, namespaces=nsmap)
            except Exception as e:
                return json.dumps({
                    "error": "XPATH_ERROR",
                    "message": f"XPath error: {e}",
                    "hint": "Try simpler XPath like '//*[local-name()=\"table\"]'",
                })

            results = []
            total_chars = 0
            for elem in elements:
                if total_chars >= params.max_chars:
                    break
                if hasattr(elem, "tag"):
                    xml_str = etree.tostring(elem, encoding="unicode", pretty_print=True)
                else:
                    xml_str = str(elem)
                results.append(xml_str[:params.max_chars - total_chars])
                total_chars += len(results[-1])

            return safe_json_dumps({
                "xpath": params.xpath,
                "match_count": len(elements),
                "returned": len(results),
                "content": results,
            })
        else:
            # Return document info
            xml_str = etree.tostring(root, encoding="unicode")
            return safe_json_dumps({
                "document_size": len(xml_str),
                "root_tag": root.tag,
                "namespaces": dict(root.nsmap),
                "child_count": len(list(root)),
                "hint": "Use xpath parameter to query specific elements",
            })


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _classify_exhibit(filename: str) -> str:
    """Classify exhibit type from filename."""
    fl = filename.lower()
    if "ex-99" in fl or "ex99" in fl:
        return "EX-99 (Press Release / Other)"
    if "ex-31" in fl or "ex31" in fl:
        return "EX-31 (Officer Certification - SOX 302)"
    if "ex-32" in fl or "ex32" in fl:
        return "EX-32 (Officer Certification - SOX 906)"
    if "ex-23" in fl or "ex23" in fl:
        return "EX-23 (Auditor Consent)"
    if "ex-21" in fl or "ex21" in fl:
        return "EX-21 (Subsidiaries)"
    if "ex-10" in fl or "ex10" in fl:
        return "EX-10 (Material Contract)"
    return "Unknown Exhibit"
