"""
Stream 4: Formula & Extended Validation tools.

Run XBRL formulas, compare DTS schemas, check calculations,
and perform granular validation.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.truncation import safe_json_dumps

# ─── Input Models ─────────────────────────────────────────────────────────────

class RunFormulaInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    trace: bool = Field(default=False, description="Enable formula trace output for debugging")


class ListFormulasInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")


class DtsComparisonInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id_1: str = Field(..., description="First filing (baseline)")
    filing_id_2: str = Field(..., description="Second filing (comparison)")


class CheckCalculationsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    concept_name: str | None = Field(default=None, description="Check specific total concept")
    max_results: int = Field(default=20, ge=1, le=100)


class ValidateExtendedInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str | None = Field(default=None, description="Filing ID of loaded filing")
    file_path: str | None = Field(default=None, description="Or path/URL to filing")
    checks: list[str] = Field(
        default=["xbrl21", "calculations", "dimensions"],
        description="Checks to run: 'xbrl21', 'calculations', 'dimensions', 'utr', 'duplicates'",
    )
    severity_filter: str = Field(
        default="all", description="Filter: 'error', 'warning', 'all'"
    )
    max_messages: int = Field(default=30, ge=1, le=100)


# ─── Tool Registration ────────────────────────────────────────────────────────

def register_formula_tools(mcp: Any) -> None:
    """Register Formula & Validation+ tools."""

    @mcp.tool(
        name="xbrl_run_formula",
        annotations={
            "title": "Run XBRL Formulas",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_run_formula(params: RunFormulaInput, ctx: Context) -> str:
        """Execute XBRL formulas defined in the filing's linkbase.

        Runs value assertions, existence assertions, and consistency assertions.
        Returns pass/fail results for each formula.

        Args:
            params: Filing ID and trace option.

        Returns:
            str: JSON with formula execution results.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            info = manager.get_filing_info(params.filing_id)
            file_path = info.get("uri")
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        from arelle.api.Session import Session
        from arelle.RuntimeOptions import RuntimeOptions

        options = RuntimeOptions(
            entrypointFile=file_path,
            formulaAction="run",
            validate=True,
            keepOpen=False,
            logFormat="[%(messageCode)s] %(message)s - %(file)s",
        )

        if params.trace:
            options.formulaVarsOrder = True

        try:
            with Session() as session:
                session.run(options)
                logs_raw = session.get_logs("json")

            import json as json_mod
            log_entries = []
            try:
                parsed = json_mod.loads(logs_raw) if isinstance(logs_raw, str) else logs_raw
                if isinstance(parsed, list):
                    log_entries = parsed
                elif isinstance(parsed, dict) and "log" in parsed:
                    log_entries = parsed["log"]
            except Exception:
                log_entries = [{"raw": str(logs_raw)}]

            formula_results = [
                e for e in log_entries
                if any(k in str(e.get("code", e.get("messageCode", "")))
                       for k in ["formula", "assertion", "Formula", "Assertion"])
            ]

            return safe_json_dumps({
                "formula_messages": formula_results[:30],
                "total_messages": len(formula_results),
                "all_log_count": len(log_entries),
            })

        except Exception as e:
            return json.dumps({"error": "FORMULA_ERROR", "message": str(e)})

    @mcp.tool(
        name="xbrl_list_formulas",
        annotations={
            "title": "List Filing Formulas",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_list_formulas(params: ListFormulasInput, ctx: Context) -> str:
        """List all formulas, assertions, and validation rules in a filing's DTS.

        Args:
            params: Filing ID.

        Returns:
            str: JSON with formula names, types, and descriptions.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        formulas = []
        try:
            rel_set = model.relationshipSet("XBRL-formula")
            for rel in rel_set.modelRelationships:
                from_obj = rel.fromModelObject
                if from_obj is None:
                    continue

                formula_info = {
                    "name": str(getattr(from_obj, "qname", "?")),
                    "type": type(from_obj).__name__,
                    "arcrole": rel.arcrole.split("/")[-1] if rel.arcrole else "?",
                }

                if hasattr(from_obj, "xlinkLabel"):
                    formula_info["label"] = from_obj.xlinkLabel

                formulas.append(formula_info)
        except Exception as e:
            return json.dumps({
                "formulas": [],
                "count": 0,
                "note": f"Formula enumeration: {e}",
            })

        # Dedup
        seen = set()
        unique = []
        for f in formulas:
            key = f["name"]
            if key not in seen:
                seen.add(key)
                unique.append(f)

        return safe_json_dumps({
            "formulas": unique[:50],
            "count": len(unique),
        })

    @mcp.tool(
        name="xbrl_dts_comparison",
        annotations={
            "title": "Compare Two DTS/Filings",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_dts_comparison(params: DtsComparisonInput, ctx: Context) -> str:
        """Compare two taxonomy/filing schemas.

        Identifies concepts, relationships, and labels that were added,
        removed, or changed between two filings or taxonomy versions.

        Args:
            params: Two filing IDs.

        Returns:
            str: JSON with added/removed/changed concepts and relationships.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model1 = manager.get_model(params.filing_id_1)
            model2 = manager.get_model(params.filing_id_2)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        # Compare concepts
        concepts1 = {str(qn) for qn in model1.qnameConcepts}
        concepts2 = {str(qn) for qn in model2.qnameConcepts}

        added = sorted(concepts2 - concepts1)
        removed = sorted(concepts1 - concepts2)

        # Compare role types
        roles1 = set(model1.roleTypes.keys())
        roles2 = set(model2.roleTypes.keys())
        added_roles = sorted(roles2 - roles1)
        removed_roles = sorted(roles1 - roles2)

        return safe_json_dumps({
            "concepts": {
                "filing1_count": len(concepts1),
                "filing2_count": len(concepts2),
                "added": added[:30],
                "removed": removed[:30],
                "added_count": len(added),
                "removed_count": len(removed),
            },
            "roles": {
                "added": added_roles[:10],
                "removed": removed_roles[:10],
            },
        })

    @mcp.tool(
        name="xbrl_check_calculations",
        annotations={
            "title": "Check Calculation Consistency",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_check_calculations(params: CheckCalculationsInput, ctx: Context) -> str:
        """Verify calculation consistency for totals and their components.

        For each calculation relationship, compares the reported total
        with the sum of components, reporting mismatches.

        Args:
            params: Filing ID, optional concept filter, max results.

        Returns:
            str: JSON with calculation check results.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        from arelle_mcp.constants import ARCROLE_SUMMATION_ITEM

        results = []
        rel_set = model.relationshipSet(ARCROLE_SUMMATION_ITEM)

        for root in rel_set.rootConcepts:
            if params.concept_name:
                local = params.concept_name.split(":")[-1]
                if local.lower() not in str(root.qname).lower():
                    continue

            children = rel_set.fromModelObject(root)
            if not children:
                continue

            # Get reported total value (default dimension, most recent)
            total_facts = list(model.factsByQname.get(root.qname, set()))
            total_facts = [f for f in total_facts if f.isNumeric and not f.isNil
                          and f.context and not f.context.qnameDims]
            if not total_facts:
                continue

            for total_fact in total_facts[:2]:  # Check up to 2 periods
                try:
                    reported_total = float(total_fact.xValue)
                except (ValueError, TypeError):
                    continue

                # Sum components
                computed_sum = 0.0
                components = []
                for rel in children:
                    child = rel.toModelObject
                    if child is None:
                        continue
                    weight = float(rel.weight)
                    child_facts = list(model.factsByQname.get(child.qname, set()))
                    # Match context
                    matching = [
                        f for f in child_facts
                        if f.isNumeric and not f.isNil
                        and f.contextID == total_fact.contextID
                    ]
                    if matching:
                        try:
                            val = float(matching[0].xValue)
                            computed_sum += val * weight
                            components.append({
                                "concept": child.qname.localName,
                                "value": val,
                                "weight": weight,
                            })
                        except (ValueError, TypeError):
                            pass

                diff = abs(reported_total - computed_sum)
                is_ok = diff < 1.0  # Allow $1 rounding tolerance

                results.append({
                    "total_concept": root.qname.localName,
                    "reported_total": reported_total,
                    "computed_sum": round(computed_sum, 2),
                    "difference": round(diff, 2),
                    "status": "PASS" if is_ok else "MISMATCH",
                    "components": components[:10],
                    "context_id": total_fact.contextID,
                })

                if len(results) >= params.max_results:
                    break
            if len(results) >= params.max_results:
                break

        passed = sum(1 for r in results if r["status"] == "PASS")
        failed = sum(1 for r in results if r["status"] == "MISMATCH")

        return safe_json_dumps({
            "checks": results,
            "summary": {"passed": passed, "failed": failed, "total": len(results)},
        })

    @mcp.tool(
        name="xbrl_validate_extended",
        annotations={
            "title": "Extended Validation",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_validate_extended(params: ValidateExtendedInput, ctx: Context) -> str:
        """Extended validation with granular control over which checks to run.

        Supports: xbrl21, calculations, dimensions, utr, duplicates.
        Returns results grouped by category with severity filtering.

        Args:
            params: Filing ID or path, checks to run, severity filter.

        Returns:
            str: JSON with categorized validation results.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        file_path = params.file_path
        if not file_path and params.filing_id:
            try:
                info = manager.get_filing_info(params.filing_id)
                file_path = info.get("uri")
            except KeyError as e:
                return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        if not file_path:
            return json.dumps({"error": "MISSING_INPUT", "message": "Provide filing_id or file_path"})

        from arelle.api.Session import Session
        from arelle.RuntimeOptions import RuntimeOptions

        calcs = "xbrl21" if "calculations" in params.checks else "none"
        check_utr = "utr" in params.checks

        options = RuntimeOptions(
            entrypointFile=file_path,
            validate=True,
            calcs=calcs,
            utrValidate=check_utr,
            keepOpen=False,
            logFormat="[%(messageCode)s] %(message)s - %(file)s",
        )

        try:
            with Session() as session:
                session.run(options)
                logs_raw = session.get_logs("json")

            import json as json_mod
            log_entries = []
            try:
                parsed = json_mod.loads(logs_raw) if isinstance(logs_raw, str) else logs_raw
                if isinstance(parsed, list):
                    log_entries = parsed
                elif isinstance(parsed, dict) and "log" in parsed:
                    log_entries = parsed["log"]
            except Exception:
                log_entries = []

            # Filter by severity
            if params.severity_filter == "error":
                log_entries = [e for e in log_entries if _is_error_entry(e)]
            elif params.severity_filter == "warning":
                log_entries = [e for e in log_entries if _is_warning_entry(e)]

            return safe_json_dumps({
                "messages": log_entries[:params.max_messages],
                "total_count": len(log_entries),
                "checks_performed": params.checks,
            })

        except Exception as e:
            return json.dumps({"error": "VALIDATION_ERROR", "message": str(e)})


def _is_error_entry(e: dict[str, Any]) -> bool:
    level = str(e.get("level", e.get("severity", ""))).lower()
    return level in ("error", "err", "critical", "fatal")


def _is_warning_entry(e: dict[str, Any]) -> bool:
    level = str(e.get("level", e.get("severity", ""))).lower()
    return level in ("warning", "warn")
