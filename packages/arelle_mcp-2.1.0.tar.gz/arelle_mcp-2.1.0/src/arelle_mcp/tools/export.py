"""
Stream 6: Export & Instance Creation tools.

Export filing data to JSON, CSV, Excel formats.
Create new XBRL instances from scratch.
"""

from __future__ import annotations

import csv
import io
import json
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.serializers import serialize_fact
from arelle_mcp.truncation import safe_json_dumps

# ─── Input Models ─────────────────────────────────────────────────────────────

class ExportJsonInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    include_dimensions: bool = Field(default=True, description="Include dimensional data")
    numeric_only: bool = Field(default=False, description="Only numeric facts")
    limit: int = Field(default=200, ge=1, le=2000)


class ExportCsvInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    columns: list[str] = Field(
        default=["concept", "value", "unit", "period", "dimensions"],
        description="Columns to include",
    )
    numeric_only: bool = Field(default=True, description="Only numeric facts (default true for CSV)")
    exclude_dimensions: bool = Field(default=True, description="Exclude dimensional facts")
    limit: int = Field(default=500, ge=1, le=5000)


class ExportConceptsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    namespace: str | None = Field(default=None, description="Filter by namespace prefix (e.g., 'us-gaap')")
    with_facts_only: bool = Field(default=True, description="Only concepts that have reported facts")
    limit: int = Field(default=200, ge=1, le=2000)


class ExportDtsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")


class CreateInstanceInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    schema_ref: str = Field(..., description="URL of the taxonomy schema to use")
    entity_id: str = Field(..., description="Entity identifier (e.g., CIK number)")
    entity_scheme: str = Field(
        default="http://www.sec.gov/CIK",
        description="Entity identifier scheme",
    )
    facts: list[dict[str, Any]] = Field(
        ...,
        description="List of facts: [{concept, value, period_end, unit?, decimals?}]",
        min_length=1,
    )


# ─── Tool Registration ────────────────────────────────────────────────────────

def register_export_tools(mcp: Any) -> None:
    """Register Export & Instance Creation tools."""

    @mcp.tool(
        name="xbrl_export_json",
        annotations={
            "title": "Export Facts to JSON",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_export_json(params: ExportJsonInput, ctx: Context) -> str:
        """Export all facts from a filing as structured JSON.

        Returns a complete JSON export of filing facts, suitable for
        data pipelines, database import, or further processing.

        Args:
            params: Filing ID, filters, and limit.

        Returns:
            str: JSON array of serialized facts.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        facts = list(model.facts)

        if params.numeric_only:
            facts = [f for f in facts if f.isNumeric]

        # Dedup
        seen: set[str] = set()
        deduped = []
        for f in facts:
            key = f"{f.qname}|{f.contextID}|{f.effectiveValue}"
            if key not in seen:
                seen.add(key)
                deduped.append(f)

        facts = deduped[:params.limit]
        serialized = [serialize_fact(f, include_dimensions=params.include_dimensions) for f in facts]

        info = manager.get_filing_info(params.filing_id)

        return safe_json_dumps({
            "filing": {
                "entity": info.get("entity_name"),
                "period": info.get("period_end_date"),
                "type": info.get("document_type"),
            },
            "facts": serialized,
            "count": len(serialized),
            "total_in_filing": len(model.facts),
        })

    @mcp.tool(
        name="xbrl_export_csv",
        annotations={
            "title": "Export Facts to CSV",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_export_csv(params: ExportCsvInput, ctx: Context) -> str:
        """Export facts as CSV format for spreadsheet analysis.

        Returns CSV string with customizable columns.

        Args:
            params: Filing ID, columns, filters, limit.

        Returns:
            str: CSV-formatted string.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        facts = list(model.facts)

        if params.numeric_only:
            facts = [f for f in facts if f.isNumeric]

        if params.exclude_dimensions:
            facts = [f for f in facts if not f.context or not f.context.qnameDims]

        # Dedup
        seen: set[str] = set()
        deduped = []
        for f in facts:
            key = f"{f.qname}|{f.contextID}|{f.effectiveValue}"
            if key not in seen:
                seen.add(key)
                deduped.append(f)

        facts = deduped[:params.limit]

        # Build CSV
        output = io.StringIO()
        writer = csv.writer(output)

        # Header
        header = []
        col_map = {
            "concept": lambda f: f.qname.localName if f.qname else "",
            "namespace": lambda f: f.qname.prefix if f.qname else "",
            "value": lambda f: f.effectiveValue or "",
            "unit": lambda f: (
                str(f.unit.measures[0][0].localName)
                if f.unit and f.unit.measures and f.unit.measures[0] else ""
            ),
            "decimals": lambda f: f.decimals or "",
            "period": lambda f: _get_period_str(f),
            "entity": lambda f: (
                f.context.entityIdentifier[1] if f.context and f.context.entityIdentifier else ""
            ),
            "dimensions": lambda f: _get_dims_str(f),
        }

        for col in params.columns:
            if col in col_map:
                header.append(col)
        writer.writerow(header)

        for f in facts:
            row = []
            for col in header:
                try:
                    row.append(col_map[col](f))
                except Exception:
                    row.append("")
            writer.writerow(row)

        csv_str = output.getvalue()

        return safe_json_dumps({
            "csv": csv_str,
            "rows": len(facts),
            "columns": header,
        })

    @mcp.tool(
        name="xbrl_export_concepts",
        annotations={
            "title": "Export Taxonomy Concepts",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_export_concepts(params: ExportConceptsInput, ctx: Context) -> str:
        """Export taxonomy concepts as structured data.

        Returns all concepts in the filing's DTS with their properties.

        Args:
            params: Filing ID, namespace filter, with_facts_only flag.

        Returns:
            str: JSON with concept list.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        # Filter out infrastructure
        infra = {"xl", "xlink", "link", "xbrli", "xbrldt", "xbrldi", "gen"}
        concepts = [
            c for c in model.qnameConcepts.values()
            if not (c.qname and c.qname.prefix and c.qname.prefix in infra)
        ]

        if params.namespace:
            ns = params.namespace.lower()
            concepts = [c for c in concepts if c.qname and c.qname.prefix and ns in c.qname.prefix.lower()]

        if params.with_facts_only:
            concepts = [c for c in concepts if c.qname in model.factsByQname and model.factsByQname[c.qname]]

        concepts = concepts[:params.limit]

        exported = []
        for c in concepts:
            label = None
            try:
                label = c.label(lang="en-US", fallbackToQname=True)
            except Exception:
                label = str(c.qname)

            exported.append({
                "qname": str(c.qname),
                "label": label,
                "type": str(c.typeQname) if c.typeQname else None,
                "period_type": getattr(c, "periodType", None),
                "balance": getattr(c, "balance", None),
                "abstract": getattr(c, "isAbstract", False),
            })

        return safe_json_dumps({
            "concepts": exported,
            "count": len(exported),
        })

    @mcp.tool(
        name="xbrl_export_dts",
        annotations={
            "title": "Export DTS Document Map",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_export_dts(params: ExportDtsInput, ctx: Context) -> str:
        """Export the Discoverable Taxonomy Set (DTS) document map.

        Lists all schemas, linkbases, and instance documents in the DTS
        with their types and URLs.

        Args:
            params: Filing ID.

        Returns:
            str: JSON with DTS document list.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        from arelle.ModelDocument import Type as DocType

        type_names = {
            DocType.SCHEMA: "Schema",
            DocType.LINKBASE: "Linkbase",
            DocType.INSTANCE: "Instance",
            DocType.INLINEXBRL: "Inline XBRL",
            DocType.INLINEXBRLDOCUMENTSET: "iXBRL Document Set",
        }

        documents = []
        for url, doc in model.urlDocs.items():
            doc_type = type_names.get(doc.type, str(doc.type)) if doc.type else "Unknown"
            documents.append({
                "url": url,
                "type": doc_type,
                "is_entry": doc.uri == model.uri if hasattr(model, "uri") else False,
            })

        # Sort: entry doc first, then by type
        documents.sort(key=lambda d: (0 if d.get("is_entry") else 1, d.get("type", "")))

        return safe_json_dumps({
            "dts_documents": documents[:50],
            "total": len(documents),
        })

    @mcp.tool(
        name="xbrl_create_instance",
        annotations={
            "title": "Create XBRL Instance",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": False,
            "openWorldHint": False,
        },
    )
    async def xbrl_create_instance(params: CreateInstanceInput, ctx: Context) -> str:
        """Create a new XBRL instance document from scratch.

        Generates a valid XBRL instance with the specified facts, contexts,
        and units. Returns the XML as a string.

        Args:
            params: Schema ref, entity info, and list of facts.

        Returns:
            str: JSON with the generated XBRL XML.
        """
        # Build a minimal XBRL instance XML
        ns = "http://www.xbrl.org/2003/instance"
        lines = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            f'<xbrli:xbrl xmlns:xbrli="{ns}"',
            '  xmlns:link="http://www.xbrl.org/2003/linkbase"',
            '  xmlns:xlink="http://www.w3.org/1999/xlink"',
            '  xmlns:us-gaap="http://fasb.org/us-gaap/2024"',
            '  xmlns:dei="http://xbrl.sec.gov/dei/2024"',
            '  xmlns:iso4217="http://www.xbrl.org/2003/iso4217">',
            '',
            f'  <link:schemaRef xlink:type="simple" xlink:href="{params.schema_ref}"/>',
        ]

        # Create contexts and units
        context_ids: dict[str, str] = {}
        unit_ids: dict[str, str] = {}
        fact_lines = []

        for i, fact_data in enumerate(params.facts):
            period = fact_data.get("period_end", "2024-12-31")
            ctx_id = f"ctx_{period.replace('-', '')}"
            unit = fact_data.get("unit", "USD")
            unit_id = f"unit_{unit}"

            if ctx_id not in context_ids:
                context_ids[ctx_id] = period
                lines.append(f'  <xbrli:context id="{ctx_id}">')
                lines.append('    <xbrli:entity>')
                lines.append(f'      <xbrli:identifier scheme="{params.entity_scheme}">{params.entity_id}</xbrli:identifier>')
                lines.append('    </xbrli:entity>')
                lines.append('    <xbrli:period>')
                lines.append(f'      <xbrli:instant>{period}</xbrli:instant>')
                lines.append('    </xbrli:period>')
                lines.append('  </xbrli:context>')

            if unit_id not in unit_ids:
                unit_ids[unit_id] = unit
                lines.append(f'  <xbrli:unit id="{unit_id}">')
                lines.append(f'    <xbrli:measure>iso4217:{unit}</xbrli:measure>')
                lines.append('  </xbrli:unit>')

            concept = fact_data.get("concept", f"us-gaap:Item{i}")
            value = fact_data.get("value", "0")
            decimals = fact_data.get("decimals", "-3")
            fact_lines.append(
                f'  <{concept} contextRef="{ctx_id}" unitRef="{unit_id}" decimals="{decimals}">{value}</{concept}>'
            )

        lines.extend(fact_lines)
        lines.append('</xbrli:xbrl>')

        xml_output = "\n".join(lines)

        return safe_json_dumps({
            "xbrl_xml": xml_output,
            "facts_count": len(params.facts),
            "contexts_count": len(context_ids),
            "units_count": len(unit_ids),
            "note": "This is a basic XBRL instance. For production use, validate with xbrl_validate.",
        })


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _get_period_str(fact: Any) -> str:
    if not fact.context:
        return ""
    if fact.context.isInstantPeriod:
        dt = fact.context.instantDatetime
        return dt.isoformat()[:10] if dt else ""
    elif fact.context.isStartEndPeriod:
        end = fact.context.endDatetime
        return end.isoformat()[:10] if end else ""
    return ""


def _get_dims_str(fact: Any) -> str:
    if not fact.context or not fact.context.qnameDims:
        return ""
    parts = []
    for dq, dv in fact.context.qnameDims.items():
        dim = dq.localName if dq else str(dq)
        mem = dv.memberQname.localName if dv.isExplicit and dv.memberQname else "?"
        parts.append(f"{dim}={mem}")
    return "; ".join(parts)
