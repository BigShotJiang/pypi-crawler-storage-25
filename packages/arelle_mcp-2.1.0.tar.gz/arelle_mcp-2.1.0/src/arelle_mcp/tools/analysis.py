"""
Stream 3: Analysis Engine tools.

Financial ratios, trend analysis, segment breakdowns, anomaly detection,
and LLM-optimized smart summaries.
"""

from __future__ import annotations

import json
from decimal import InvalidOperation
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.truncation import safe_json_dumps

# ─── Input Models ─────────────────────────────────────────────────────────────

class FinancialRatiosInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")


class TrendAnalysisInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    concepts: list[str] = Field(
        default=["Revenues", "NetIncomeLoss", "Assets", "StockholdersEquity",
                 "EarningsPerShareBasic"],
        description="Concepts to analyze across periods",
    )


class SegmentBreakdownInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    concept_name: str = Field(
        ..., description="Concept to break down (e.g., 'Revenues', 'Assets')"
    )
    dimension_name: str | None = Field(
        default=None, description="Specific dimension to use (e.g., 'ProductOrService')"
    )


class AnomalyDetectionInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")


class SmartSummaryInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    focus: str = Field(
        default="all",
        description="Focus area: 'income', 'balance', 'cash_flow', 'all'",
    )


class PeerComparisonInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    concept: str = Field(..., description="Concept to compare (e.g., 'Assets')")
    taxonomy: str = Field(default="us-gaap")
    unit: str = Field(default="USD")
    period: str = Field(
        ...,
        description="Period: 'CY2024Q3I' (instant) or 'CY2024Q3' (duration)",
    )
    limit: int = Field(default=20, ge=1, le=100)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _get_fact_value(model: Any, local_name: str, period_type: str | None = None,
                    default_dim_only: bool = True) -> list[dict[str, Any]]:
    """Get fact values for a concept, grouped by period."""
    facts = list(model.factsByLocalName.get(local_name, set()))
    results = []
    for f in facts:
        if not f.isNumeric or f.isNil:
            continue
        if default_dim_only and f.context and f.context.qnameDims:
            continue
        if period_type == "instant" and f.context and not f.context.isInstantPeriod:
            continue
        if period_type == "duration" and f.context and not f.context.isStartEndPeriod:
            continue

        try:
            val = float(f.xValue) if f.xValue is not None else None
        except (ValueError, TypeError, InvalidOperation):
            continue

        if val is None:
            continue

        period_key = ""
        if f.context:
            if f.context.isInstantPeriod:
                dt = f.context.instantDatetime
                period_key = dt.isoformat()[:10] if dt else "?"
            elif f.context.isStartEndPeriod:
                end = f.context.endDatetime
                start = f.context.startDatetime
                period_key = end.isoformat()[:10] if end else "?"
                if start and end:
                    days = (end - start).days
                    if 80 <= days <= 100:
                        period_key = f"Q {period_key}"
                    elif 355 <= days <= 375:
                        period_key = f"FY {period_key}"

        results.append({"value": val, "period": period_key})

    results.sort(key=lambda x: x["period"], reverse=True)
    return results


def _safe_ratio(numerator: float | None, denominator: float | None) -> float | None:
    """Compute ratio safely."""
    if numerator is None or denominator is None or denominator == 0:
        return None
    return round(numerator / denominator, 4)


def _latest_value(values: list[dict[str, Any]]) -> float | None:
    """Get the most recent value."""
    return values[0]["value"] if values else None


# ─── Tool Registration ────────────────────────────────────────────────────────

def register_analysis_tools(mcp: Any) -> None:
    """Register Analysis Engine tools."""

    @mcp.tool(
        name="xbrl_financial_ratios",
        annotations={
            "title": "Compute Financial Ratios",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_financial_ratios(params: FinancialRatiosInput, ctx: Context) -> str:
        """Compute standard financial ratios from a loaded filing.

        Returns liquidity, profitability, leverage, and per-share ratios
        calculated from the most recent period's data.

        Args:
            params: Filing ID.

        Returns:
            str: JSON with computed ratios and their interpretations.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        # Extract key values
        def latest(name: str, pt: str | None = None) -> float | None:
            return _latest_value(_get_fact_value(model, name, pt))

        # Balance sheet (instant)
        assets = latest("Assets", "instant")
        current_assets = latest("AssetsCurrent", "instant")
        current_liabilities = latest("LiabilitiesCurrent", "instant")
        total_liabilities = latest("Liabilities", "instant")
        equity = latest("StockholdersEquity", "instant")
        cash = latest("CashAndCashEquivalentsAtCarryingValue", "instant")
        inventory = latest("InventoryNet", "instant")


        # Income statement (duration)
        revenue = latest("Revenues") or latest("RevenueFromContractWithCustomerExcludingAssessedTax")
        net_income = latest("NetIncomeLoss")
        gross_profit = latest("GrossProfit")
        operating_income = latest("OperatingIncomeLoss")


        # Per share
        eps_basic = latest("EarningsPerShareBasic")
        eps_diluted = latest("EarningsPerShareDiluted")

        ratios: dict[str, Any] = {
            "liquidity": {
                "current_ratio": _safe_ratio(current_assets, current_liabilities),
                "quick_ratio": _safe_ratio(
                    (current_assets or 0) - (inventory or 0), current_liabilities
                ) if current_assets is not None else None,
                "cash_ratio": _safe_ratio(cash, current_liabilities),
            },
            "profitability": {
                "gross_margin": _safe_ratio(gross_profit, revenue),
                "operating_margin": _safe_ratio(operating_income, revenue),
                "net_margin": _safe_ratio(net_income, revenue),
                "roe": _safe_ratio(net_income, equity),
                "roa": _safe_ratio(net_income, assets),
            },
            "leverage": {
                "debt_to_equity": _safe_ratio(total_liabilities, equity),
                "debt_to_assets": _safe_ratio(total_liabilities, assets),
                "equity_ratio": _safe_ratio(equity, assets),
            },
            "per_share": {
                "eps_basic": eps_basic,
                "eps_diluted": eps_diluted,
            },
            "raw_values": {
                "revenue": revenue,
                "net_income": net_income,
                "total_assets": assets,
                "total_equity": equity,
                "total_liabilities": total_liabilities,
                "cash": cash,
            },
        }

        return safe_json_dumps(ratios)

    @mcp.tool(
        name="xbrl_trend_analysis",
        annotations={
            "title": "Analyze Multi-Period Trends",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_trend_analysis(params: TrendAnalysisInput, ctx: Context) -> str:
        """Analyze trends across periods within a single filing.

        10-K filings contain 3 years of data, 10-Q has 2 quarters.
        Computes absolute and percentage changes for specified concepts.

        Args:
            params: Filing ID and list of concepts.

        Returns:
            str: JSON with per-concept period values and changes.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        trends = []
        for concept in params.concepts:
            local_name = concept.split(":")[-1]
            values = _get_fact_value(model, local_name)

            # Dedup by period
            seen = set()
            deduped = []
            for v in values:
                if v["period"] not in seen:
                    seen.add(v["period"])
                    deduped.append(v)

            if len(deduped) < 2:
                trends.append({
                    "concept": concept,
                    "periods": deduped,
                    "change": None,
                    "note": "Need at least 2 periods for trend",
                })
                continue

            # Compute changes
            latest_val = deduped[0]["value"]
            prior_val = deduped[1]["value"]
            abs_change = latest_val - prior_val
            pct_change = _safe_ratio(abs_change, abs(prior_val)) if prior_val != 0 else None

            trends.append({
                "concept": concept,
                "periods": deduped[:5],  # Show up to 5 periods
                "latest": latest_val,
                "prior": prior_val,
                "absolute_change": round(abs_change, 2),
                "percent_change": round(pct_change * 100, 2) if pct_change is not None else None,
                "direction": "up" if abs_change > 0 else "down" if abs_change < 0 else "flat",
            })

        return safe_json_dumps({"trends": trends})

    @mcp.tool(
        name="xbrl_segment_breakdown",
        annotations={
            "title": "Segment Breakdown",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_segment_breakdown(params: SegmentBreakdownInput, ctx: Context) -> str:
        """Extract dimensional breakdowns for a concept.

        Shows how a total (e.g., Revenue) breaks down by segments,
        geographies, products, or other dimensions.

        Args:
            params: Filing ID, concept name, optional dimension filter.

        Returns:
            str: JSON with dimensional breakdown including values and percentages.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        local_name = params.concept_name.split(":")[-1]
        facts = list(model.factsByLocalName.get(local_name, set()))

        # Get total (no dimensions)
        total_val = None
        for f in facts:
            if f.isNumeric and f.context and not f.context.qnameDims:
                try:
                    total_val = float(f.xValue)
                    break
                except (ValueError, TypeError, InvalidOperation):
                    pass

        # Get dimensional breakdowns
        breakdowns: dict[str, list[dict[str, Any]]] = {}
        for f in facts:
            if not f.isNumeric or f.isNil or not f.context or not f.context.qnameDims:
                continue

            try:
                val = float(f.xValue)
            except (ValueError, TypeError, InvalidOperation):
                continue

            for dim_qn, dim_val in f.context.qnameDims.items():
                dim_name = dim_qn.localName if dim_qn else str(dim_qn)

                if params.dimension_name and params.dimension_name.lower() not in dim_name.lower():
                    continue

                if dim_val.isExplicit and dim_val.memberQname:
                    member = dim_val.memberQname.localName
                else:
                    continue

                if dim_name not in breakdowns:
                    breakdowns[dim_name] = []

                pct = round(val / total_val * 100, 1) if total_val and total_val != 0 else None

                breakdowns[dim_name].append({
                    "member": member,
                    "value": val,
                    "percent_of_total": pct,
                })

        # Sort by value descending
        for dim in breakdowns.values():
            dim.sort(key=lambda x: abs(x["value"]), reverse=True)

        return safe_json_dumps({
            "concept": params.concept_name,
            "total_value": total_val,
            "breakdowns": breakdowns,
            "dimension_count": len(breakdowns),
        })

    @mcp.tool(
        name="xbrl_anomaly_detection",
        annotations={
            "title": "Detect Anomalies",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_anomaly_detection(params: AnomalyDetectionInput, ctx: Context) -> str:
        """Detect unusual patterns or potential issues in a filing.

        Checks for: negative values where unexpected, extreme period changes,
        calculation mismatches, missing expected concepts, zero values.

        Args:
            params: Filing ID.

        Returns:
            str: JSON with anomaly list, severity, and descriptions.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        anomalies = []

        # Check for negative values in normally-positive concepts
        positive_concepts = ["Assets", "Revenues", "StockholdersEquity",
                            "CashAndCashEquivalentsAtCarryingValue"]
        for concept in positive_concepts:
            values = _get_fact_value(model, concept)
            for v in values:
                if v["value"] < 0:
                    anomalies.append({
                        "type": "negative_value",
                        "severity": "high",
                        "concept": concept,
                        "value": v["value"],
                        "period": v["period"],
                        "description": f"{concept} is negative ({v['value']})",
                    })

        # Check for extreme period-over-period changes
        key_concepts = ["Revenues", "NetIncomeLoss", "Assets", "OperatingIncomeLoss"]
        for concept in key_concepts:
            values = _get_fact_value(model, concept)
            seen = set()
            deduped = [v for v in values if v["period"] not in seen and not seen.add(v["period"])]
            if len(deduped) >= 2:
                latest = deduped[0]["value"]
                prior = deduped[1]["value"]
                if prior != 0:
                    pct = abs((latest - prior) / prior)
                    if pct > 1.0:  # >100% change
                        anomalies.append({
                            "type": "extreme_change",
                            "severity": "medium",
                            "concept": concept,
                            "latest": latest,
                            "prior": prior,
                            "change_pct": round(pct * 100, 1),
                            "description": f"{concept} changed by {round(pct*100)}% ({prior} → {latest})",
                        })

        # Check for expected concepts that are missing
        expected = ["Revenues", "Assets", "Liabilities", "NetIncomeLoss"]
        for concept in expected:
            facts = list(model.factsByLocalName.get(concept, set()))
            numeric_facts = [f for f in facts if f.isNumeric and not f.isNil]
            if not numeric_facts:
                # Try alternative names
                alt = {"Revenues": "RevenueFromContractWithCustomerExcludingAssessedTax"}
                alt_name = alt.get(concept)
                if alt_name:
                    alt_facts = list(model.factsByLocalName.get(alt_name, set()))
                    if [f for f in alt_facts if f.isNumeric]:
                        continue
                anomalies.append({
                    "type": "missing_concept",
                    "severity": "low",
                    "concept": concept,
                    "description": f"Expected concept '{concept}' not found or has no numeric values",
                })

        # Check validation errors
        if model.errors:
            anomalies.append({
                "type": "validation_errors",
                "severity": "high",
                "count": len(model.errors),
                "description": f"Filing has {len(model.errors)} validation error(s)",
            })

        anomalies.sort(key=lambda x: {"high": 0, "medium": 1, "low": 2}.get(x["severity"], 3))

        return safe_json_dumps({
            "anomalies": anomalies[:20],
            "total_count": len(anomalies),
            "summary": {
                "high": sum(1 for a in anomalies if a["severity"] == "high"),
                "medium": sum(1 for a in anomalies if a["severity"] == "medium"),
                "low": sum(1 for a in anomalies if a["severity"] == "low"),
            },
        })

    @mcp.tool(
        name="xbrl_smart_summary",
        annotations={
            "title": "Smart Filing Summary",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_smart_summary(params: SmartSummaryInput, ctx: Context) -> str:
        """Generate an LLM-optimized structured summary of a filing.

        Returns a compact (<4K tokens) JSON with company info, key metrics,
        period comparisons, and notable items. Designed for efficient use
        of LLM context windows.

        Args:
            params: Filing ID and focus area.

        Returns:
            str: Compact JSON summary.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        info = manager.get_filing_info(params.filing_id)

        def latest(name: str) -> float | None:
            return _latest_value(_get_fact_value(model, name))

        summary: dict[str, Any] = {
            "company": {
                "name": info.get("entity_name"),
                "cik": info.get("entity_cik"),
                "period": info.get("period_end_date"),
                "document_type": info.get("document_type"),
            },
        }

        if params.focus in ("income", "all"):
            rev = latest("Revenues") or latest("RevenueFromContractWithCustomerExcludingAssessedTax")
            summary["income"] = {
                "revenue": rev,
                "cost_of_revenue": latest("CostOfRevenue"),
                "gross_profit": latest("GrossProfit"),
                "operating_income": latest("OperatingIncomeLoss"),
                "net_income": latest("NetIncomeLoss"),
                "eps_basic": latest("EarningsPerShareBasic"),
                "eps_diluted": latest("EarningsPerShareDiluted"),
            }

        if params.focus in ("balance", "all"):
            summary["balance_sheet"] = {
                "total_assets": latest("Assets"),
                "current_assets": latest("AssetsCurrent"),
                "cash": latest("CashAndCashEquivalentsAtCarryingValue"),
                "total_liabilities": latest("Liabilities"),
                "current_liabilities": latest("LiabilitiesCurrent"),
                "long_term_debt": latest("LongTermDebt"),
                "equity": latest("StockholdersEquity"),
                "shares_outstanding": latest("CommonStockSharesOutstanding"),
            }

        if params.focus in ("cash_flow", "all"):
            summary["cash_flow"] = {
                "operating": latest("NetCashProvidedByOperatingActivities"),
                "investing": latest("NetCashProvidedByUsedInInvestingActivities"),
                "financing": latest("NetCashProvidedByUsedInFinancingActivities"),
                "capex": latest("PaymentsToAcquirePropertyPlantAndEquipment"),
                "buybacks": latest("PaymentsForRepurchaseOfCommonStock"),
                "dividends": latest("PaymentsOfDividends"),
            }

        summary["fact_count"] = info.get("fact_count", 0)

        return safe_json_dumps(summary)

    @mcp.tool(
        name="xbrl_peer_comparison",
        annotations={
            "title": "Peer Company Comparison",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_peer_comparison(params: PeerComparisonInput, ctx: Context) -> str:
        """Compare a concept across multiple companies using SEC EDGAR Frames API.

        Returns a ranked list of companies with values for the specified concept
        in the given period. No filing load required.

        Args:
            params: Concept, taxonomy, unit, period, limit.

        Returns:
            str: JSON with ranked company list.
        """
        import httpx

        from arelle_mcp.constants import SEC_EDGAR_FRAMES, SEC_EDGAR_USER_AGENT

        url = SEC_EDGAR_FRAMES.format(
            taxonomy=params.taxonomy,
            concept=params.concept,
            unit=params.unit,
            period=params.period,
        )

        try:
            async with httpx.AsyncClient(
                headers={"User-Agent": SEC_EDGAR_USER_AGENT, "Accept": "application/json"},
                timeout=30.0,
                follow_redirects=True,
            ) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                data = resp.json()
        except Exception as e:
            return json.dumps({
                "error": "SEC_API_ERROR",
                "message": str(e),
                "hint": "Period format: CY2024Q3I (instant) or CY2024Q3 (duration)",
            })

        companies = data.get("data", [])
        companies.sort(key=lambda x: abs(x.get("val", 0)), reverse=True)

        results = []
        for c in companies[:params.limit]:
            results.append({
                "company": c.get("entityName"),
                "cik": c.get("cik"),
                "value": c.get("val"),
                "accession": c.get("accn"),
                "filed": c.get("filed"),
            })

        return safe_json_dumps({
            "concept": f"{params.taxonomy}:{params.concept}",
            "period": params.period,
            "unit": params.unit,
            "companies": results,
            "total_filers": len(companies),
        })
