"""
arelle-mcp server: The definitive MCP server for XBRL processing.

This is the entry point. It creates the FastMCP instance, manages the
Arelle lifecycle via the lifespan pattern, and registers all tools,
resources, and prompts.
"""

from __future__ import annotations

import logging
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.constants import DEFAULT_MAX_CACHED_FILINGS

# ─── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=os.environ.get("ARELLE_MCP_LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,  # MCP stdio requires stderr for logging
)
logger = logging.getLogger("arelle_mcp")


# ─── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def arelle_lifespan(server: FastMCP) -> AsyncIterator[ArelleManager]:
    """Manage the ArelleManager lifecycle.

    Initializes the manager on server startup and cleans up all loaded
    filings and resources on shutdown. The manager is available to all
    tools via ctx.request_context.lifespan_context.
    """
    max_filings = int(os.environ.get("ARELLE_MCP_MAX_FILINGS", DEFAULT_MAX_CACHED_FILINGS))
    cache_dir = os.environ.get("ARELLE_MCP_CACHE_DIR", None)

    manager = ArelleManager(
        max_cached_filings=max_filings,
        cache_dir=cache_dir,
    )
    logger.info(
        "arelle-mcp v1.0.0 starting — max_filings=%d",
        max_filings,
    )

    try:
        yield manager
    finally:
        await manager.close_all()
        logger.info("arelle-mcp shut down cleanly")


# ─── Server Instance ──────────────────────────────────────────────────────────

mcp = FastMCP(
    "arelle_mcp",
    lifespan=arelle_lifespan,
    instructions=(
        "XBRL processing and financial analysis server powered by Arelle.\n\n"
        "WORKFLOW:\n"
        "1. Load: xbrl_load_filing or xbrl_fetch_sec_filing → get filing_id\n"
        "2. Quick overview: xbrl_smart_summary or xbrl_get_cover_page\n"
        "3. Financial data: xbrl_extract_facts, xbrl_financial_ratios, xbrl_trend_analysis\n"
        "4. Document content: xbrl_extract_text, xbrl_search_text, xbrl_get_html_tables\n"
        "5. Structure: xbrl_presentation_tree, xbrl_calculation_tree, xbrl_dimension_structure\n"
        "6. Deep analysis: xbrl_segment_breakdown, xbrl_anomaly_detection, xbrl_peer_comparison\n"
        "7. Validation: xbrl_validate\n"
        "8. Rendering: xbrl_render_statement\n\n"
        "SEC EDGAR (no filing load needed):\n"
        "- xbrl_search_sec_concept, xbrl_company_facts, xbrl_peer_comparison\n\n"
        "31 tools across 3 streams: Core, Document Intelligence, Analysis Engine.\n"
    ),
)


# ─── Register Everything ─────────────────────────────────────────────────────

def _register_all() -> None:
    """Register all tools, resources, and prompts on the MCP server."""
    # Stream 1: Core (existing)
    # Resources & Prompts
    from arelle_mcp.prompts import register_prompts
    from arelle_mcp.resources import register_resources

    # Stream 3: Analysis Engine
    from arelle_mcp.tools.analysis import register_analysis_tools

    # Stream 2: Document Intelligence
    from arelle_mcp.tools.document import register_document_tools
    from arelle_mcp.tools.edgar import register_edgar_tools

    # Stream 5: EDGAR Pro
    from arelle_mcp.tools.edgar_pro import register_edgar_pro_tools

    # Stream 6: Export & Instance Creation
    from arelle_mcp.tools.export import register_export_tools
    from arelle_mcp.tools.facts import register_facts_tools
    from arelle_mcp.tools.filing import register_filing_tools

    # Stream 4: Formula & Validation+
    from arelle_mcp.tools.formula import register_formula_tools
    from arelle_mcp.tools.relationships import register_relationship_tools
    from arelle_mcp.tools.rendering import register_rendering_tools
    from arelle_mcp.tools.taxonomy import register_taxonomy_tools
    from arelle_mcp.tools.validation import register_validation_tools

    # Register all
    register_filing_tools(mcp)
    register_validation_tools(mcp)
    register_facts_tools(mcp)
    register_taxonomy_tools(mcp)
    register_relationship_tools(mcp)
    register_edgar_tools(mcp)
    register_rendering_tools(mcp)
    register_document_tools(mcp)    # Stream 2
    register_analysis_tools(mcp)    # Stream 3
    register_formula_tools(mcp)     # Stream 4
    register_edgar_pro_tools(mcp)   # Stream 5
    register_export_tools(mcp)      # Stream 6
    register_resources(mcp)
    register_prompts(mcp)

    logger.info("All tools registered — 6 streams, 47 tools")


_register_all()


# ─── Entry Point ──────────────────────────────────────────────────────────────

def main() -> None:
    """Run the arelle-mcp server."""
    transport = os.environ.get("ARELLE_MCP_TRANSPORT", "stdio")

    if transport == "streamable-http":
        port = int(os.environ.get("ARELLE_MCP_PORT", "8000"))
        logger.info("Starting arelle-mcp on HTTP port %d", port)
        mcp.run(transport="streamable-http", port=port)
    else:
        logger.info("Starting arelle-mcp on stdio")
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
