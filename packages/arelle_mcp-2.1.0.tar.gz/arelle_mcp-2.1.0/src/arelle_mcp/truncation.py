"""
Global output truncation for arelle-mcp.

Prevents any tool from returning >50KB, which causes MCP clients
to save to file instead of displaying inline.
"""

from __future__ import annotations

import json
from typing import Any

MAX_OUTPUT_BYTES = 50_000  # ~50KB ≈ ~12K tokens


def truncate_output(result: str, max_bytes: int = MAX_OUTPUT_BYTES) -> str:
    """Truncate output with helpful message if too large."""
    encoded = result.encode("utf-8", errors="replace")
    if len(encoded) <= max_bytes:
        return result

    # Find a clean cut point (newline)
    truncated = result[: max_bytes].rsplit("\n", 1)[0]

    # Add truncation notice
    size_kb = len(encoded) // 1024
    return (
        truncated
        + f"\n\n[OUTPUT TRUNCATED: {size_kb}KB total, showing first ~{max_bytes // 1024}KB. "
        "Use filters, pagination (offset/limit), or more specific parameters to reduce output.]"
    )


def safe_json_dumps(data: Any, max_bytes: int = MAX_OUTPUT_BYTES, **kwargs: Any) -> str:
    """JSON dumps with automatic truncation."""
    kwargs.setdefault("indent", 2)
    kwargs.setdefault("default", str)
    result = json.dumps(data, **kwargs)
    return truncate_output(result, max_bytes)
