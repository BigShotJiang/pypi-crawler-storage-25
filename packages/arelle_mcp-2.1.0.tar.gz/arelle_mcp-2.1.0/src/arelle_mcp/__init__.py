"""
arelle-mcp: The definitive MCP server for XBRL processing, validation, and financial analysis.

Powered by Arelle — the world's only free, open-source XBRL-certified processor.
Exposes 12 production-grade tools for loading, validating, extracting, browsing,
traversing, comparing, rendering, and analyzing XBRL/iXBRL financial filings.

No existing XBRL MCP server exists anywhere. This is the first.
"""

__version__ = "2.1.0"
__author__ = "King Hippopotamus"
__license__ = "Apache-2.0"
