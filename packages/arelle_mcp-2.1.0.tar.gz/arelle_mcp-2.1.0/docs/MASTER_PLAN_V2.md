# Arelle-MCP v2.0 — Master Plan
## Full 100% Coverage of Arelle's Capabilities

---

## Vision

Transform arelle-mcp from a 17-tool XBRL fact reader into the **complete Arelle platform as a service** — every capability Arelle has, exposed through MCP. The first and only product in the world that gives LLMs full, unrestricted access to XBRL processing.

---

## Architecture: Agent Workstreams

The project is divided into **6 independent workstreams** that can run in parallel across multiple Claude Code agents. Each workstream produces a self-contained module that registers its tools on the shared `mcp` server instance.

```
┌─────────────────────────────────────────────────────────────────┐
│                    arelle-mcp v2.0 Server                       │
│                    (server.py + lifespan)                        │
├──────────┬──────────┬──────────┬──────────┬──────────┬──────────┤
│ Stream 1 │ Stream 2 │ Stream 3 │ Stream 4 │ Stream 5 │ Stream 6 │
│ CORE     │ DOCUMENT │ ANALYSIS │ FORMULA  │ EDGAR+   │ EXPORT   │
│ (exists) │ INTEL    │ ENGINE   │ & VALID+ │ PRO      │ & DB     │
├──────────┼──────────┼──────────┼──────────┼──────────┼──────────┤
│ 17 tools │ 8 tools  │ 6 tools  │ 5 tools  │ 6 tools  │ 5 tools  │
│ v1.x     │ NEW      │ NEW      │ NEW      │ NEW      │ NEW      │
└──────────┴──────────┴──────────┴──────────┴──────────┴──────────┘
                              │
                    ┌─────────┴─────────┐
                    │  Shared Layer     │
                    │  arelle_wrapper   │
                    │  serializers      │
                    │  constants        │
                    └───────────────────┘

Total: ~47 tools, 8+ resources, 8+ prompts
```

---

## Stream 1: CORE (Existing — Stabilization)
**Owner:** Any agent  
**Status:** v1.0.4 exists, needs bug fixes from review  
**Priority:** CRITICAL — foundation for everything else

### What exists (17 tools):
- Filing: load, summary, compare, close, list
- Validation: validate
- Facts: extract_facts, fact_details
- Taxonomy: browse_taxonomy, concept_details
- Relationships: presentation_tree, calculation_tree, dimension_structure
- EDGAR: fetch_sec_filing, search_sec_concept, company_facts
- Rendering: render_statement

### What needs fixing:
| # | Bug | Status |
|---|-----|--------|
| 1 | `fact_details` — set not subscriptable | Fixed in v1.0.4 (needs VPS restart) |
| 2 | Output overflow — validate 230KB, dimensions 925KB | Partially fixed, needs global truncation |
| 3 | `extract_facts` duplicates | Needs dedup |
| 4 | `xbrl_search_sec_concept` misleading suggestions | Needs fix |
| 5 | `render_statement` still shows start dates | Partially fixed |

### New in Stream 1 (stabilization):
- **Global output limiter** — truncate any tool output >50KB with `[truncated, use pagination]`
- **Fact deduplication** — dedup by (concept, context_id, value) tuple
- **Smart defaults** — `with_facts_only=True` as default for browse_taxonomy

---

## Stream 2: DOCUMENT INTELLIGENCE (NEW)
**Owner:** Agent A  
**Priority:** HIGH — this is the #1 missing capability

Arelle loads full iXBRL/HTML documents. The entire 10-K/10-Q text is in the model.
We're only reading structured XBRL facts — ignoring 90% of the document content.

### New Tools (8):

#### `xbrl_extract_text`
Extract clean text from a specific section of a filing (MD&A, Risk Factors, Notes, etc.)
```
Input:  filing_id, section ("md&a" | "risk_factors" | "notes" | "financial_statements" | "all")
Output: Clean text content, stripped of HTML tags
Source: iXBRL HTML document parsing via lxml/etree on model.modelDocument.xmlDocument
```

#### `xbrl_search_text`
Full-text search within a loaded filing's content
```
Input:  filing_id, query (string), context_lines (int, default 2)
Output: Matching passages with surrounding context, section name, position
Source: Walk text nodes in xmlDocument, match against query
```

#### `xbrl_get_footnotes`
Extract footnotes linked to XBRL facts
```
Input:  filing_id, concept_name? (filter to specific concept)
Output: Footnote text, linked fact concept, fact value
Source: model.relationshipSet(XbrlConst.factFootnote) → footnote resources
```

#### `xbrl_list_sections`
Map the complete document structure of a filing
```
Input:  filing_id
Output: Section titles, hierarchy, approximate size (chars), has_xbrl_tags (bool)
Source: Parse <ix:header>, <div> structure, heading elements from xmlDocument
```

#### `xbrl_get_exhibits`
List and access exhibits attached to a filing (EX-99.1 press release, etc.)
```
Input:  filing_id, exhibit_type? ("EX-99.1", "EX-31", "EX-32", etc.)
Output: Exhibit list with types, descriptions, URLs, loaded content
Source: Parse <ix:references> or DEI facts for exhibit info + SEC EDGAR exhibit index
```

#### `xbrl_get_html_tables`
Extract HTML tables from the filing document (not XBRL-tagged tables)
```
Input:  filing_id, table_index? (specific table) or search? (text in table)
Output: Table data as list of rows, with headers detected
Source: lxml xpath for <table> elements in xmlDocument
```

#### `xbrl_get_cover_page`
Extract the filing cover page data (company info, filing metadata)
```
Input:  filing_id
Output: All DEI facts as structured object: company name, CIK, ticker, fiscal year,
        filing date, document type, period, auditor, shares outstanding, etc.
Source: All facts with dei: namespace prefix
```

#### `xbrl_get_raw_xml`
Access raw XML/HTML content of specific document elements
```
Input:  filing_id, xpath? (XPath expression), element_id? (specific element)
Output: Raw XML string of matched elements
Source: model.modelDocument.xmlDocument with lxml xpath
```

### Technical Notes:
- All text extraction uses `lxml.etree` on `model.modelDocument.xmlDocument`
- iXBRL documents are full HTML — we have complete access to all content
- Need to strip `<ix:*>` tags to get clean text
- Section detection: parse heading hierarchy (`<h1>` through `<h4>`, bold/caps patterns)

---

## Stream 3: ANALYSIS ENGINE (NEW)
**Owner:** Agent B  
**Priority:** HIGH — makes the MCP actually useful for financial analysis

### New Tools (6):

#### `xbrl_financial_ratios`
Compute standard financial ratios from a loaded filing
```
Input:  filing_id
Output: Liquidity ratios (current, quick, cash), profitability (ROE, ROA, margins),
        leverage (debt/equity, interest coverage), efficiency (asset turnover),
        per-share (EPS, book value, dividend yield)
Source: Extract key facts → compute ratios
```

#### `xbrl_trend_analysis`
Analyze multi-period trends from facts within a single filing (10-K has 3 years, 10-Q has 2)
```
Input:  filing_id, concepts (list of concept names)
Output: Per-concept: values by period, absolute change, % change, CAGR, direction
Source: Group facts by period, compute deltas
```

#### `xbrl_segment_breakdown`
Extract dimensional breakdowns for a concept (revenue by segment, geography, product)
```
Input:  filing_id, concept_name, dimension_name?
Output: Structured breakdown: dimension members with values, percentages of total
Source: Filter facts by concept + iterate dimensions
```

#### `xbrl_peer_comparison`
Compare a concept across multiple companies using SEC EDGAR Frames API
```
Input:  concept (e.g., "Assets"), taxonomy, unit, period, limit (top N companies)
Output: Ranked list of companies with values for the concept in the specified period
Source: SEC EDGAR Frames API: /api/xbrl/frames/{taxonomy}/{concept}/{unit}/{period}.json
```

#### `xbrl_anomaly_detection`
Detect unusual patterns or potential issues in a filing
```
Input:  filing_id
Output: List of anomalies: calculation mismatches, unusual values, missing expected
        concepts, negative values where unexpected, extreme period-over-period changes
Source: Calculation validation + statistical checks on fact values
```

#### `xbrl_smart_summary`
AI-ready structured summary of a filing's key financial data
```
Input:  filing_id, focus? ("income" | "balance" | "cash_flow" | "all")
Output: Compact JSON with: company info, key metrics, period comparisons, notable items.
        Designed to fit in <4K tokens for efficient LLM context usage.
Source: Aggregation of DEI facts + key financial facts + dimensional breakdowns
```

---

## Stream 4: FORMULA & VALIDATION+ (NEW)
**Owner:** Agent C  
**Priority:** MEDIUM — power user features

### New Tools (5):

#### `xbrl_run_formula`
Execute XBRL formulas defined in the filing's linkbase
```
Input:  filing_id, formula_ids? (specific formulas), trace? (bool)
Output: Formula results: assertions passed/failed, computed values, trace log
Source: RuntimeOptions.formulaAction = "run", formulaRunIDs, formula trace flags
```

#### `xbrl_dts_comparison`
Compare two taxonomy schemas (DTS diff)
```
Input:  file_path_1, file_path_2 (two schema/instance files)
Output: Versioning report: added/removed/changed concepts, relationships, labels
Source: RuntimeOptions.diffFile + Arelle's built-in DTS comparison engine
```

#### `xbrl_validate_extended`
Extended validation with granular control (beyond the existing xbrl_validate)
```
Input:  filing_id or file_path, rules (list: "efm", "esef", "xbrl21", "dimensions",
        "utr", "duplicate_facts", "calculations"), severity_filter? ("error"|"warning"|"all")
Output: Structured results grouped by rule category, with explanations
Source: Multiple validation passes with RuntimeOptions flags
```

#### `xbrl_check_calculations`
Focused calculation consistency check with human-readable output
```
Input:  filing_id, concept_name? (specific total to check)
Output: For each calculation: expected total, actual total, difference, components
        with their weights, pass/fail status
Source: Calculation linkbase traversal + fact value comparison
```

#### `xbrl_list_formulas`
List all formulas, assertions, and validation rules in a filing's DTS
```
Input:  filing_id
Output: Formula names, types (value/existence/consistency assertion), variables,
        filters, and human-readable descriptions
Source: model.relationshipSet("XBRL-formula") traversal
```

---

## Stream 5: EDGAR PRO (NEW)
**Owner:** Agent D  
**Priority:** MEDIUM — makes SEC integration production-grade

### New Tools (6):

#### `xbrl_edgar_search`
Full-text search across SEC EDGAR filings
```
Input:  query (text), entity? (company name/CIK), filing_types? (list), date_range?
Output: Matching filings with metadata, relevance score, excerpts
Source: SEC EFTS full-text search API: efts.sec.gov/LATEST/search-index
```

#### `xbrl_edgar_company_info`
Comprehensive company profile from SEC
```
Input:  cik or ticker
Output: Full company profile: name, CIK, SIC code, state, addresses, former names,
        filing history summary, recent filings by type
Source: SEC submissions API with full parsing
```

#### `xbrl_edgar_filing_index`
Get the full index of documents within a filing (all exhibits, schemas, instances)
```
Input:  cik, accession_number
Output: Complete document list with: filename, type, description, size, URL
Source: SEC EDGAR filing index page parsing
```

#### `xbrl_edgar_bulk_facts`
Bulk download fact data for multiple concepts across multiple companies
```
Input:  ciks (list), concepts (list), taxonomy, periods? (list)
Output: Matrix of company × concept × period values
Source: Multiple SEC companyconcept API calls, aggregated
```

#### `xbrl_edgar_insider_trades`
Get insider trading data from Forms 3, 4, 5
```
Input:  cik or ticker, date_range?
Output: Insider transactions: name, role, transaction type, shares, price, date
Source: SEC submissions filtered by form type 3/4/5 + XBRL data extraction
```

#### `xbrl_edgar_rss_feed`
Monitor SEC EDGAR RSS feeds for new filings
```
Input:  feed_type? ("company" | "full-text" | "xbrl"), company_cik?, form_type?
Output: Recent filings with metadata, timestamps, document URLs
Source: SEC RSS feeds + Arelle's built-in RSS processing (ModelDocument.Type.RSSFEED)
```

---

## Stream 6: EXPORT & DATABASE (NEW)
**Owner:** Agent E  
**Priority:** MEDIUM — data pipeline features

### New Tools (5):

#### `xbrl_export_json`
Export filing data to XBRL-JSON (OIM format)
```
Input:  filing_id, output_format ("xBRL-JSON" | "xBRL-CSV")
Output: Complete filing in XBRL-JSON or xBRL-CSV format
Source: Arelle plugin loadFromOIM (saveLoadableOIM) — handles JSON/CSV natively
```

#### `xbrl_export_csv`
Export facts to flat CSV suitable for data analysis
```
Input:  filing_id, concepts? (filter), include_dimensions? (bool), columns? (list)
Output: CSV string or file with customizable columns
Source: Arelle's built-in CSV export via RuntimeOptions.factsFile with CSV extension
```

#### `xbrl_export_excel`
Export filing data to Excel format with multiple sheets
```
Input:  filing_id, sheets? ("facts" | "presentation" | "calculation" | "dimensions" | "all")
Output: Excel file URL/path
Source: openpyxl generation from serialized data
```

#### `xbrl_create_instance`
Create a new XBRL instance document from scratch
```
Input:  schema_refs (list of taxonomy URLs), facts (list of {concept, value, context, unit}),
        entity_id, entity_scheme, periods (list)
Output: Valid XBRL instance document (XML string or file)
Source: ModelDocument.create() + model_xbrl.createFact/createContext/createUnit
```

#### `xbrl_store_to_db`
Store filing data to a database (uses Arelle's xbrlDB plugin)
```
Input:  filing_id, db_type ("postgres" | "mysql" | "mssql" | "sqlite" | "mongodb" | "json"),
        connection_string
Output: Storage confirmation with record counts
Source: Arelle plugin xbrlDB — supports 7 database backends natively
```

---

## Shared Infrastructure Upgrades

### Global Output Truncation (ALL streams)
```python
MAX_OUTPUT_BYTES = 50_000  # ~50KB ≈ ~12K tokens

def truncate_output(result: str, max_bytes: int = MAX_OUTPUT_BYTES) -> str:
    """Truncate output with helpful message if too large."""
    if len(result.encode()) <= max_bytes:
        return result
    truncated = result[:max_bytes].rsplit('\n', 1)[0]
    return truncated + f"\n\n[OUTPUT TRUNCATED at {max_bytes//1000}KB. Use pagination or filters to get specific data.]"
```

### Enhanced ArelleManager
- **Plugin management** — load/unload plugins dynamically per tool call
- **Model registry** — track which plugins were used to load each model
- **Memory monitoring** — warn when approaching limits, auto-evict
- **Concurrent model reads** — allow multiple read-only operations on same model (RWLock)

### New Resources (8 total → 13)
- `xbrl://reference/sec-form-types` — all SEC form types with descriptions
- `xbrl://reference/financial-ratios` — ratio formulas and interpretations
- `xbrl://reference/section-mapping` — 10-K/10-Q section numbers to names
- `xbrl://reference/arelle-plugins` — available Arelle plugins and what they do
- `xbrl://reference/xbrl-json-spec` — XBRL-JSON/CSV format overview

### New Prompts (5 total → 10)
- `insider_trading_analysis` — analyze insider trading patterns
- `peer_benchmark` — compare company against peers
- `filing_qa` — question-answering against filing text
- `risk_analysis` — extract and analyze risk factors
- `earnings_analysis` — extract guidance and actuals from 8-K + 10-Q

---

## Agent Assignment & Parallel Execution Plan

```
Week 1 (Day 1-2): PREPARATION
├── Agent 0 (Coordinator): Stream 1 bug fixes + global truncation + shared infra
│   Output: v1.1.0 — stable foundation
│
Week 1 (Day 3-7): PARALLEL BUILD
├── Agent A: Stream 2 — Document Intelligence (8 tools)
├── Agent B: Stream 3 — Analysis Engine (6 tools)
├── Agent C: Stream 4 — Formula & Validation+ (5 tools)
├── Agent D: Stream 5 — EDGAR Pro (6 tools)
├── Agent E: Stream 6 — Export & Database (5 tools)
│
Week 2 (Day 8-10): INTEGRATION + TEST
├── Agent 0: Merge all streams, resolve conflicts
├── All agents: Cross-stream integration testing
│   Output: v2.0.0-rc1
│
Week 2 (Day 11-12): RELEASE
├── Agent 0: Final review, PyPI publish, docs update
│   Output: v2.0.0
```

### Agent Bridge Document (for each agent):

Each agent receives:
1. This master plan (their stream section)
2. The current codebase (git clone)
3. A `STREAM_X_SPEC.md` with:
   - Exact tool signatures (Pydantic models)
   - Arelle API calls to use
   - Test cases to pass
   - Output format examples
4. Rules:
   - Register tools via `register_xxx_tools(mcp)` pattern
   - Use `ctx: Context` (not `Any`)
   - Use `message=` for report_progress
   - All outputs <50KB
   - `list()` wrap any Arelle sets
   - Type hints on everything
   - Ruff clean

---

## File Structure v2.0

```
src/arelle_mcp/
├── __init__.py                    # v2.0.0
├── __main__.py
├── server.py                      # +5 new register_xxx_tools() calls
├── arelle_wrapper.py              # +plugin management, memory monitoring
├── serializers.py                 # +text extraction, ratio computation
├── constants.py                   # +form types, section mappings, ratio formulas
├── truncation.py                  # NEW: global output limiter
│
├── tools/
│   ├── __init__.py
│   │
│   │  ── Stream 1 (existing, stabilized) ──
│   ├── filing.py
│   ├── validation.py
│   ├── facts.py
│   ├── taxonomy.py
│   ├── relationships.py
│   ├── edgar.py
│   ├── rendering.py
│   │
│   │  ── Stream 2 (Document Intelligence) ──
│   ├── document.py                # extract_text, search_text, list_sections
│   ├── footnotes.py               # get_footnotes
│   ├── exhibits.py                # get_exhibits, get_cover_page
│   ├── html_tables.py             # get_html_tables, get_raw_xml
│   │
│   │  ── Stream 3 (Analysis Engine) ──
│   ├── analysis.py                # financial_ratios, trend_analysis, smart_summary
│   ├── segments.py                # segment_breakdown
│   ├── peers.py                   # peer_comparison
│   ├── anomalies.py               # anomaly_detection
│   │
│   │  ── Stream 4 (Formula & Validation+) ──
│   ├── formula.py                 # run_formula, list_formulas
│   ├── dts_compare.py             # dts_comparison
│   ├── calc_check.py              # check_calculations
│   ├── validate_extended.py       # validate_extended
│   │
│   │  ── Stream 5 (EDGAR Pro) ──
│   ├── edgar_search.py            # edgar_search, edgar_company_info
│   ├── edgar_index.py             # edgar_filing_index
│   ├── edgar_bulk.py              # edgar_bulk_facts
│   ├── edgar_insider.py           # edgar_insider_trades
│   ├── edgar_rss.py               # edgar_rss_feed
│   │
│   │  ── Stream 6 (Export & Database) ──
│   ├── export_json.py             # export_json, export_csv
│   ├── export_excel.py            # export_excel
│   ├── instance_create.py         # create_instance
│   ├── database.py                # store_to_db
│
├── resources/
│   └── __init__.py                # 13 resources
│
└── prompts/
    └── __init__.py                # 10 prompts
```

---

## Metrics

| Metric | v1.0.4 (current) | v2.0.0 (target) |
|--------|------------------|-----------------|
| Tools | 17 | ~47 |
| Resources | 5 | 13 |
| Prompts | 5 | 10 |
| Arelle coverage | ~10% | ~95% |
| Lines of code | 3,500 | ~12,000 |
| Filing types | XBRL/iXBRL only | XBRL + HTML text + exhibits |
| Analysis | Extract only | Ratios + trends + anomalies + peers |
| Export | JSON only | JSON + CSV + Excel + DB |
| SEC EDGAR | 3 endpoints | Full API + RSS + EFTS search |

---

## Non-Goals (Out of Scope for v2.0)

- GUI / web dashboard (MCP is the interface)
- Real-time streaming updates
- Historical filing storage/caching between sessions
- Custom taxonomy creation (beyond create_instance)
- Multi-language label support (English only for v2.0)

---

*No compromises. Every capability Arelle has, exposed through MCP.*
