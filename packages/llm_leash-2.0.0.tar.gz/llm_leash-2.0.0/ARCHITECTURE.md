# llm-leash — Architecture

**Status:** Draft v0.1 · 2026-05-16
Companion to PRODUCT.md v0.2.

## Design constraints (from PRODUCT.md)

1. One import, one class: `from llm_leash import Firewall`.
2. Zero runtime deps for core. Stdlib only.
3. Adapters ≤300 LOC each. Each adapter is its own package.
4. Async-first, sync-compatible. Both `await fw.dispatch(...)` and `fw.dispatch(...)`.
5. Audit log is plain JSONL, hash-chained, local by default.
6. Cost cap and kill switch must work *without* SaaS. SaaS is bonus.

## Module layout

```
llm_leash/
├─ __init__.py                  # public: Firewall, Policy, Decision
├─ firewall.py                  # Firewall facade — the one class
├─ policy/
│   ├─ engine.py                # rule eval (pure Python, no DSL)
│   ├─ predicates.py            # regex, AST-SQL, AST-shell, glob
│   ├─ pii.py                   # built-in PII patterns
│   └─ external.py              # adapters → LlamaFirewall / Prompt-Guard / Invariant
├─ budget/
│   ├─ tracker.py               # per-session cumulative cost
│   ├─ pricing.py               # provider→model→{input,output} $/1K
│   └─ store.py                 # in-mem default, Redis/SQLite plugins
├─ audit/
│   ├─ writer.py                # append-only JSONL, hash chain
│   ├─ replay.py                # CLI: llm-leash replay audit.jsonl
│   └─ schema.py                # event types
├─ kill/
│   ├─ registry.py              # is_killed(session_id) -> bool
│   ├─ transport_inproc.py      # default, single-process
│   ├─ transport_redis.py       # opt-in
│   └─ transport_http.py        # opt-in
├─ hitl/
│   ├─ queue.py                 # PENDING_HUMAN state machine
│   ├─ webhook.py               # POST to user URL
│   └─ resume.py                # POST /resume from human or expiry
├─ adapters/
│   ├─ openai.py
│   ├─ anthropic.py
│   ├─ langgraph.py
│   ├─ crewai.py
│   ├─ openhands.py
│   ├─ pydantic_ai.py
│   └─ mcp.py
├─ cli.py                       # llm-leash {replay,verify,export}
└─ types.py
```

**Rationale:**
- Core (`firewall`, `policy`, `budget`, `audit`, `kill`, `hitl`) ships in
  one PyPI package: `llm-leash`. Zero deps.
- Each adapter is its own package: `llm-leash-openai`,
  `llm-leash-langgraph`, etc. Each pulls in its target SDK.
- This lets us iterate on adapters independently and lets users install
  only what they touch.

## Core data model

Five event types. Each is one line of JSONL. Each has `prev_hash` and
`hash` for the chain.

```python
# audit/schema.py

@dataclass(frozen=True)
class Event:
    ts: str               # ISO-8601 with µs
    session_id: str
    tenant_id: str | None
    seq: int              # 0, 1, 2 ... per session
    prev_hash: str        # hex sha256 of previous event's hash
    hash: str             # hex sha256 of this event's canonical JSON

class ModelCall(Event):
    kind: Literal["model_call"]
    provider: str         # "anthropic" | "openai" | ...
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float       # computed at write time
    request_hash: str     # sha256 of request body (no plaintext)
    response_hash: str

class ToolCall(Event):
    kind: Literal["tool_call"]
    tool: str
    args_hash: str
    args_redacted: dict   # PII-redacted shallow copy of args
    decision: Literal["allow", "block", "pending_human"]
    decided_by: str       # rule id, e.g. "blocked_patterns:rm-rf"
    cost_usd: float       # 0 unless tool charges

class PolicyDecision(Event):
    kind: Literal["policy"]
    rule_id: str
    matched: bool
    action: Literal["allow", "block", "warn", "hitl"]

class BudgetEvent(Event):
    kind: Literal["budget"]
    cumulative_usd: float
    cap_usd: float
    decision: Literal["under", "soft_exceeded", "hard_exceeded", "killed"]

class HITLEvent(Event):
    kind: Literal["hitl"]
    state: Literal["pending", "approved", "rejected", "expired"]
    target_event_seq: int   # which tool_call this resolves
    resolver: str | None
```

## Data flow — every tool call

```
   agent code                  Firewall.dispatch(call)
   ──────────                  ───────────────────────
        │                          │
        ├─── tool_call(name,args) ─┤
        │                          │
        │                          ▼
        │                  ┌───────────────┐
        │                  │ 1. budget.check
        │                  │    cumulative + estimated > cap?
        │                  │    → hard: kill, audit, raise
        │                  │    → soft: warn, audit, continue
        │                  └───────┬───────┘
        │                          │
        │                          ▼
        │                  ┌───────────────┐
        │                  │ 2. kill.is_killed(session_id)
        │                  │    poll registry (≤300ms SLA)
        │                  │    → killed: audit, raise
        │                  └───────┬───────┘
        │                          │
        │                          ▼
        │                  ┌───────────────┐
        │                  │ 3. pii.redact(args)
        │                  │    → args_redacted, args_hash
        │                  └───────┬───────┘
        │                          │
        │                          ▼
        │                  ┌───────────────┐
        │                  │ 4. policy.eval(call)
        │                  │    iter rules:
        │                  │      block_patterns
        │                  │      allowed_tools
        │                  │      external scanners
        │                  │      hitl rules
        │                  │    → allow | block | hitl
        │                  └───────┬───────┘
        │                          │
        │           ┌──────────────┼──────────────┐
        │           ▼              ▼              ▼
        │       block           hitl           allow
        │       audit           queue           audit
        │       raise           wait            execute
        │                    (resume/timeout)     │
        │                          │              │
        │                          ▼              ▼
        │                       resolve        result + cost
        │                          │              │
        │◀──────────── result ─────┴──────────────┘
        │  or LeashBlocked / Killed / RejectedByHuman
```

Every numbered step writes ≥1 audit event. The chain is unbroken.

## Policy engine — pure Python, no DSL

A rule is a callable: `(call, context) -> Decision`. That's it.

```python
# policy/engine.py

@dataclass
class Decision:
    action: Literal["allow", "block", "warn", "hitl"]
    rule_id: str
    reason: str

class Rule(Protocol):
    id: str
    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None: ...

class Engine:
    def __init__(self, rules: list[Rule]): ...
    def eval(self, call: ToolCall, ctx) -> Decision:
        # First-match wins. Default is allow.
        for r in self.rules:
            d = r.evaluate(call, ctx)
            if d is not None:
                return d
        return Decision("allow", "default", "no rule matched")
```

Built-in rules (`policy/predicates.py`):

- `BlockedPatterns(re_list, fields=["arg.*"])` — regex
- `AllowedTools(tool_names)` — allow-list
- `DeniedTools(tool_names)` — deny-list
- `SQLDangerous()` — AST parse, flag `DROP`, `TRUNCATE`, `DELETE` without `WHERE`
- `ShellDangerous()` — tokenize, flag `rm -rf`, `mkfs`, `dd if=`, fork bombs
- `MaxToolBudget(tool, usd)` — kills if a single tool spends > $X
- `HITLOnAmount(field, threshold)` — webhook for any `amount` field > $N
- `HITLOnPattern(re, fields)` — webhook on match

External-scanner rules (`policy/external.py`):

- `LlamaFirewallRule()` — calls Meta's PurpleLlama bundle
- `PromptGuardRule()` — calls Prompt-Guard-2 model
- `InvariantRulesFile(path)` — imports Invariant's `.rules` files
- `LakeraGuardRule(api_key)` — calls Lakera

Imported rules are equal citizens: same `evaluate()` contract.

## Budget tracker — provider-aware, plug-in store

```python
# budget/tracker.py

class BudgetTracker:
    def __init__(
        self,
        session_id: str,
        hard_cap_usd: float,
        soft_cap_usd: float | None,
        store: BudgetStore,            # InMemory | Redis | SQLite
        pricing: PricingTable,
    ): ...

    async def charge(self, *, provider: str, model: str,
                     in_tokens: int, out_tokens: int) -> BudgetState: ...

    async def estimate(self, *, provider: str, model: str,
                       in_tokens: int) -> float:
        """Pre-call lower-bound estimate (output unknown). Used to gate."""

    @property
    def cumulative_usd(self) -> float: ...

class BudgetStore(Protocol):
    async def get(self, session_id) -> float: ...
    async def add(self, session_id, delta_usd) -> float: ...    # atomic
    async def reset(self, session_id) -> None: ...
```

`pricing` is a versioned table baked into the wheel:
`llm_leash.budget.pricing.PRICING_v_2026_05` — provider→model→{$/M
in-tokens, $/M out-tokens}. Updates ship in patch releases.

Stores:
- **InMemoryStore** — default, single-process. Loses state on restart.
- **RedisStore** — `INCRBYFLOAT session:{id} amount`. Atomic. Survives restarts.
- **SQLiteStore** — for local persistence without Redis.

Multi-tenant is just `session_id = f"{tenant}:{user}:{run}"`.

## Audit log — append-only JSONL with hash chain

Single writer per file. fsync after each line (configurable). One event
= one line.

```python
# audit/writer.py

class AuditWriter:
    def __init__(self, path: str, fsync: bool = True,
                 secret: bytes | None = None):
        """If secret is provided, events include HMAC-SHA256(secret, hash)."""
    def write(self, event: Event) -> Event:
        # 1. read last line's hash (cached after first read)
        # 2. set event.prev_hash, event.seq
        # 3. compute event.hash = sha256(canonical_json(event_minus_hash))
        # 4. append line, optional fsync
```

Canonical JSON: keys sorted, no whitespace, UTF-8, escape forward
slashes — deterministic.

**Verification:** `llm-leash verify audit.jsonl` reads the file,
recomputes each `hash` and `prev_hash`, exits non-zero on first break.

**Export:** `llm-leash export audit.jsonl --since 2026-04-01 --tenant
acme --format csv` for compliance handoffs.

**SaaS sink (opt-in):** `audit_log="cloud://api.llm-leash.io/v1/audit?tenant=acme"`.
Same JSONL, posted in batches with retry. Same hash chain — server can
re-verify on receive.

## Kill switch — sub-300ms SLA

```python
# kill/registry.py

class KillRegistry(Protocol):
    async def is_killed(self, session_id: str) -> bool: ...
    async def kill(self, session_id: str, reason: str) -> None: ...
    async def clear(self, session_id: str) -> None: ...
```

Transports:
- **InProcess** — default, single-process set. Useful for tests and notebooks.
- **Redis** — `SISMEMBER killed_sessions {id}`, ≤2ms. Set populated by
  `SADD killed_sessions {id}`. TTL on entries (24h default).
- **HTTP** — poll a URL; ETag/If-Modified-Since to keep traffic low.
  Useful when Redis is unavailable.

`is_killed` is called on every tool dispatch *and* every model call.
The Firewall caches the last-known-status for ≤200ms to avoid hot
loops; the SLA "kill propagation ≤300ms" is `cache_ms + transport_rtt`.

CLI: `llm-leash kill --session s_8a3f --reason "user request"` —
writes to whatever transport is configured.

## HITL — pending state machine

When a rule returns `action="hitl"`, the firewall:

1. Writes a `tool_call` event with `decision="pending_human"`.
2. Writes a `hitl` event with `state="pending"` and a callback URL.
3. POSTs to the configured webhook with the tool call (PII-redacted)
   and a `resume_url`.
4. Awaits resume.
5. On resume, writes a `hitl` event with `state in {approved,
   rejected, expired}` and either dispatches the tool or raises
   `LeashRejectedByHuman`.

Resume transports:
- **HTTP server (opt-in)** — `llm-leash server --port 8080` runs a
  tiny FastAPI listener for `/resume?token=...`. Token is HMAC over
  session+seq+exp.
- **Polling** — the agent process polls the resume queue. No server
  required; useful for serverless.
- **Async resume API** — `await fw.resume(token, "approve")` from
  inside the same process (test fixtures, integration tests).

Timeout policy is **default-deny**. Configurable in `Firewall(...)`.

## Adapters — thin shims

Each adapter implements two methods:

```python
class Adapter(Protocol):
    name: str

    def wrap_client(self, client: Any, fw: Firewall) -> Any:
        """Return a proxied client that routes calls through fw."""

    def cost_from_response(self, raw_response: Any) -> tuple[str, int, int]:
        """Return (model, in_tokens, out_tokens) from native response."""
```

Examples:

- **anthropic.py:** subclass `Messages` and `AsyncMessages`. Pre-call:
  estimate, check budget, check kill. Post-call: charge actual,
  audit model_call. Tool-calls inside response trigger
  `fw.dispatch_tool(...)`.
- **openai.py:** subclass `Chat.completions` and `Responses`. Same shape.
- **langgraph.py:** decorator `@guarded(fw)` on a graph; wraps each
  node and tool.
- **crewai.py:** patch `Task.execute()` to dispatch via `fw`.
- **mcp.py:** ships a tiny MCP server that proxies tool calls through
  the firewall — for users whose agent is an external MCP client.

If an adapter has >300 LOC it has crossed into framework territory.
Split it out as a separate package and link from docs.

## Firewall facade — the one public class

```python
# firewall.py — distilled signature

class Firewall:
    def __init__(
        self,
        *,
        # Budget
        budget_usd: float | None = None,
        budget_soft_usd: float | None = None,
        budget_store: BudgetStore | None = None,    # default InMemory
        pricing: PricingTable | None = None,        # default bundled
        # Audit
        audit_log: str | None = None,               # path or URL; default off
        audit_secret: bytes | None = None,          # enables HMAC
        # Policy
        allowed_tools: list[str] | None = None,
        denied_tools: list[str] | None = None,
        blocked_patterns: list[str] | None = None,
        sql_safe: bool = True,
        shell_safe: bool = True,
        extra_rules: list[Rule] | None = None,
        # PII
        redact_pii: bool = True,
        redact_patterns: list[str] | None = None,
        # Kill
        kill_switch: str | None = None,             # URL or "inproc"
        # HITL
        hitl_webhook: str | None = None,
        hitl_timeout_s: int = 600,
        hitl_default_deny: bool = True,
        # Misc
        session_id: str | None = None,              # default UUID4
        tenant_id: str | None = None,
    ): ...

    def wrap(self, client: Any) -> Any: ...
    async def dispatch_tool(self, name: str, args: dict) -> Any: ...
    async def charge_model(self, *, provider, model, in_t, out_t) -> None: ...
    @property
    def session_id(self) -> str: ...
    @property
    def cumulative_usd(self) -> float: ...
```

That's the surface. Three properties, three methods, one constructor.

## Concurrency

- Internally async. Sync entry points call `asyncio.run()` only if
  there's no running loop.
- Budget store, kill registry, and audit writer are all called via
  small async wrappers. In-process stores are non-blocking (asyncio.Lock).
- Audit writes are serialized via an asyncio.Queue + single writer
  task per `AuditWriter`. Drains on `await fw.aclose()`.

## Performance budget

Per tool dispatch (steady state):
- Budget check: <0.5ms (in-mem); <2ms (Redis local).
- Kill poll: <0.3ms (cached); <2ms (Redis); <5ms (HTTP cached).
- Policy eval: O(rules); regex pre-compiled. Target <2ms for 50 rules.
- Audit write: <0.5ms in-buffer, async fsync.

Total per-call overhead target: **<5ms p95**. Anything more reads as a
"latency tax" in benchmarks and kills adoption.

## Error model

Three exceptions, no more:

```python
class LeashBlocked(Exception):
    """A policy rule blocked the tool call. Includes rule_id, reason."""

class LeashKilled(Exception):
    """Session was killed via kill registry."""

class LeashRejectedByHuman(Exception):
    """HITL human responded reject, or timeout with default-deny."""
```

`LeashBlocked` is a subclass of `RuntimeError`. The other two
subclass `LeashBlocked`. This lets users catch generally or
specifically.

## Test strategy

- **Unit:** every rule, every transport, every adapter (with SDK
  mocks). Target 90% line coverage on core.
- **Integration:** real OpenAI / Anthropic with `VCR.py` cassettes.
  Cassettes ship with the repo so contributors can run them offline.
- **Property tests:** `hypothesis` on policy engine + audit chain.
  Invariant: hash chain must verify after arbitrary event sequences.
- **Soak test (CI weekly):** 10k tool dispatches across 5 sessions
  with random rule sets; verify chain, verify budget accounting matches
  ground truth.
- **Adversarial:** Invariant-style red-team scenarios — does our policy
  block them? Pin Invariant rules + assert outcomes.

## Release plan (v0.x)

| Ver | What | When |
|---|---|---|
| **v0.1** | core: Firewall, budget, audit, kill (inproc), HITL stub. Anthropic + OpenAI adapters. CLI: replay, verify. | Week 2 |
| **v0.2** | Redis stores. HITL webhook + resume server. SQL/shell AST rules. PII redactor. | Week 4 |
| **v0.3** | LangGraph + CrewAI + MCP adapters. External-scanner rules (LlamaFirewall, Prompt-Guard). | Week 6 |
| **v0.4** | TypeScript port of core (`llm-leash-ts`). | Week 9 |
| **v0.5** | Optional Rego/OPA policy backend. Multi-tenant SaaS API. | Week 12 |
| **v1.0** | SOC 2 evidence pack, signed builds, semver guarantee, stable wire format. | Q4 2026 |

## Open architectural questions → ADRs

- **ADR-001** Python-first vs polyglot
- **ADR-002** Pricing-table source: bundled vs fetched
- **ADR-003** Audit hash: chain-only vs chain + Merkle root + signed batches
- **ADR-004** Cost estimation accuracy: provider-reported vs our table
- **ADR-005** HITL: built-in server vs require user-supplied server
- **ADR-006** PII redaction: regex-only vs Presidio / Pii-Codex integration
- **ADR-007** Adapter packaging: in-tree vs separate PyPI packages
