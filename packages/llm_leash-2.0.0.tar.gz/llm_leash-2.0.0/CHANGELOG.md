# Changelog

All notable changes are recorded here. Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning: [SemVer](https://semver.org/) — public top-level surface is stable from v1.0.

## [2.0.0] — 2026-05-17

### v2.0.0 GA — Production/Stable

First production-stable release of the proxy / multi-replica /
behavioral-baseline stack. All v2.x alpha capabilities (PR-1' through
PR-19) are now part of the semver-stable public surface alongside the
v1.x in-process firewall.

### Added — GA blockers (PR-20)

- **GA-1 Redis backend for proxy state** — `budget.backend = "redis"` and
  `kill.backend = "redis"` wire `RedisBudgetStore` / `RedisKillRegistry`
  through `ProxyState.from_config`. Multiple proxy replicas behind a load
  balancer now share budget cumulatives and kill state. Lazy import — the
  `redis` package is only required when the backend is selected
  (`pip install "llm-leash[redis]"`). SQLite backend is wired the same
  way for single-node durable persistence.

- **GA-2 Mid-stream cancellation on hard-cap exceeded** — the streaming
  paths in `providers/anthropic.py` and `providers/openai.py` project
  the running cost after each upstream SSE chunk
  (`cumulative_before + cost_of(running tokens)`) against the hard cap.
  When the projection exceeds the cap mid-flight, the proxy injects a
  synthetic `event: error` / `data: error` + terminal frame and aborts
  the upstream connection. Final accounting still charges what was
  actually consumed. OpenAI streams use a content-char/4 heuristic
  (`approx_output_tokens`) — conservative; fires slightly early.

- **GA-3 Per-agent budget caps** — `BudgetConfig.per_agent_caps`
  (loaded from `[budget.per_agent_caps]` in TOML) enables agent-level
  cost ceilings. Cap resolution precedence in `tracker_for`:
  per-agent → per-tenant → default → none. Multiple agents in the same
  session each get their own cap-aware tracker while sharing the
  cumulative balance keyed by `session_id`.

### Notes

- Public API surface unchanged from v1.0 and forward-compatible — no
  breaking changes. `__version__ = "2.0.0"`.
- `Development Status :: 5 - Production/Stable` (was Beta in 2.3.0a1).
- 709 tests pass across in-process firewall, proxy, console UI, alerts
  sidecar, semantic guard, behavioral baseline, and the new GA paths.

## [2.3.0a1] — 2026-05-17

### Added — Behavioral baseline (PR-19)

- **`BehavioralBaselineRule`** — learns normal traffic per
  `(tenant_id, agent_name)` pair and flags deviations:
  - **Token spikes** — > mean + sigma_threshold × stddev
  - **New models** — agent first seen using a model it never used
  - **Off-hours calls** — outside configurable business window
  - **Tool spam** — same tool called > threshold times

  Welford's online algorithm: O(1) memory per agent, exact updates.
  Warmup phase (default 50 calls) collects baseline silently before
  decisions fire.

- **`BaselineStore` protocol** + two implementations:
  - **`InMemoryBaselineStore`** — single-process, lost on restart
  - **`SQLiteBaselineStore`** — durable, multi-process safe

\`\`\`python
from llm_leash import Firewall, BehavioralBaselineRule, SQLiteBaselineStore

store = SQLiteBaselineStore("/var/lib/llm-leash/baseline.db")
fw = Firewall(rules=[
    BehavioralBaselineRule(
        store,
        warmup_calls=50, sigma_threshold=3.0,
        flag_new_models=True, flag_off_hours=True,
        business_hours=(9, 18), on_anomaly="hitl",
    ),
])
\`\`\`

### Test bar at 2.3.0a1
- **687 tests** (up from 661 at 2.2.0a1)
- 26 new baseline tests: Welford convergence, store round-trip + persistence,
  warmup gating, token spike / new model / off-hours / tool spam paths.

## [2.2.0a1] — 2026-05-17

### Added — Semantic threat detection (PR-17)

- **`LLMGuardRule`** — uses a cheap LLM classifier (Haiku /
  gpt-4o-mini) to detect prompt injection, jailbreak, and data
  exfiltration in user input. The classifier returns JSON with per-
  category scores; if any exceeds the threshold, the rule blocks
  (or routes to HITL).

- Duck-typed guard client: works with `anthropic.Anthropic`,
  `openai.OpenAI`, or anything matching their shape.

- **Sampling rate** (`sampling_rate=0.1` etc.) keeps cost / latency
  bounded for high-QPS deployments. Combine with deterministic
  rules (BlockedShell, SecretsRule) that always fire.

- **Fail-open** on classifier errors: network failure, malformed
  JSON, or unsupported client shape → return None, allow the call
  through. Operators monitoring the classifier should watch the
  `llm_leash.policy.llm_guard` logger for fail-open warnings.

\`\`\`python
from llm_leash import Firewall, LLMGuardRule
from anthropic import Anthropic

guard_client = Anthropic()                # un-wrapped — separate from the fw client
fw = Firewall(rules=[
    LLMGuardRule(
        guard_client,
        guard_model="claude-haiku-4-5",
        score_threshold=0.7,
        sampling_rate=0.1,                # check 10% of calls
        on_detect="block",
    ),
])
\`\`\`

### Test bar at 2.2.0a1
- **661 tests** (up from 634 at 2.1.0a2)
- 27 new LLMGuard tests covering Anthropic + OpenAI shapes, action
  modes, sampling, fail-open paths, malformed responses,
  category filtering.

## [2.1.0a2] — 2026-05-17

### Added — Alerts sidecar (PR-15)

- **`llm-leash-alerts`** — new binary, sidecar that tails the audit
  log and fires alerts to Slack and PagerDuty when policy / spend / kill
  patterns match operator-defined rules.

- **`AlertEngine`** with three rule types:
  - `SingleEventRule` — fire immediately when an event matches
  - `WindowCountRule` — fire when ≥ N matching events in a sliding window
  - `WindowSumRule` — fire when sum of a numeric field exceeds a threshold
  - Per-rule cooldown (default 60s) prevents alert storms

- **Dispatchers** — duck-typed `AlertTarget` protocol; built-in:
  - `SlackTarget` (incoming webhook, colored attachments by severity)
  - `PagerDutyTarget` (Events API v2, dedup-key per rule, severity filter)
  - `StdoutTarget` (dev / fallback)

- **TOML config** with env-var override for secrets
  (`SLACK_WEBHOOK_URL`, `PAGERDUTY_ROUTING_KEY`,
  `LLM_LEASH_ALERTS_AUDIT_LOG`).

- **CLI**: `llm-leash-alerts --config alerts.toml`

Sample config:

\`\`\`toml
audit_log = "/var/log/llmleash/audit.jsonl"

[targets.slack]
webhook_url = "https://hooks.slack.com/services/..."

[[rules]]
type = "single"
name = "secret_leaked"
severity = "critical"
match = { kind = "secrets_detected" }
template = "🔐 Secret detected by {detectors}, agent {agent_name}"

[[rules]]
type = "window_count"
name = "kill_burst"
severity = "warning"
window_secs = 600
count_threshold = 3
match = { kind = "kill" }
template = "{count} kills in 10m, latest reason: {reason}"

[[rules]]
type = "window_sum"
name = "spend_spike"
severity = "warning"
window_secs = 3600
sum_field = "cost_usd"
sum_threshold = 10.0
match = { kind = "model_call", tenant_id = "acme" }
template = "💸 Tenant {tenant_id} spent \${sum:.2f} in last hour"
\`\`\`

### Test bar at 2.1.0a2
- **634 tests** (up from 588 at 2.1.0a1)
- 96 % line coverage
- 46 new alerts tests: engine matchers, window aggregators, cooldowns,
  Slack/PagerDuty dispatch (mocked httpx), TOML config round-trip,
  env-var override, end-to-end runner tailing a log file.

## [2.1.0a1] — 2026-05-17

### Added — Operator console (PR-14)

- **`llm-leash-console`** — new binary, read-only Web UI for operators.
  Connects to a running `llm-leash-proxy` over its admin API and tails
  the audit log file directly.
- Single-file HTML dashboard built with Alpine.js (CDN, no build step):
  - KPI cards: active sessions, cumulative spend, HITL pending,
    policy rules loaded, PII redactor state
  - Top spenders table (by session)
  - Per-agent spend ranking (computed live from audit events)
  - Recent events live tail (last 30, auto-updates)
  - Dark mode (CSS prefers-color-scheme)
- WebSocket `/ws/audit` — pushes new audit events as they're appended
  (1-second polling on the file; sub-second latency via inotify ships
  in a future release).
- Endpoints:
  - `GET /` — dashboard HTML
  - `GET /api/stats` — proxies upstream `/admin/stats` (requires admin
    token); standalone mode returns empty blob
  - `GET /api/audit?n=200` — last N parsed audit events
  - `WS /ws/audit` — live event tail
  - `GET /healthz` — liveness
- CLI:
  ```bash
  llm-leash-console \
      --port 8080 \
      --audit-log /var/log/llmleash/audit.jsonl \
      --proxy http://localhost:8000 \
      --admin-token $LLM_LEASH_ADMIN_TOKEN
  ```

### Out of scope for this alpha

- In-UI write actions (kill session, approve HITL) — operators still
  use the CLI (`llm-leash kill --proxy ...`, `llm-leash hitl approve
  --proxy ...`). Ship in 2.1.0a2.
- Slack / PagerDuty alerts sidecar (PR-15) — ships in 2.1.0a2.

### Test bar at 2.1.0a1
- **588 tests** (up from 574)
- 96 % line coverage
- ruff + mypy clean
- New `tests/console/` directory with 14 endpoint tests including
  WebSocket live-push

## [2.0.0a2] — 2026-05-17

### Added (since 2.0.0a1)
- **Streaming SSE** for both `/v1/messages` and `/v1/chat/completions`.
  Bytes pass through unchanged; tokens accounted at end-of-stream;
  OpenAI auto-injects `stream_options.include_usage=true`.
- **End-to-end tests** with real `anthropic` and `openai` SDKs pointed
  at a live proxy on an ephemeral port (mocked upstream via MockTransport).
- **Dockerfile** + `docker-compose.example.yml` + `prometheus.example.yml`.
- **k8s manifest** (`k8s/llm-leash-proxy.example.yaml`) — namespace,
  Secret, ConfigMap, Deployment with health/readiness probes, hardened
  SecurityContext, Service.
- **`docs/PROXY.md`** — operator guide covering install, config, identity
  model, endpoints, CLI, streaming, audit, k8s, production checklist.

### Test bar at 2.0.0a2
- **574 tests** (up from 543 at 2.0.0a1)
- **96 % coverage**
- Same acceptance gate: ruff + mypy + pytest + coverage ≥ 85 % + smoke

## [2.0.0a1] — 2026-05-17

**Alpha release** of the HTTP proxy mode. Adds zero-code-change enforcement
for any LLM agent by inserting `llm-leash-proxy` between the agent and the
provider. Existing in-process middleware (`Firewall.wrap()`) is unchanged
and remains supported.

### Added — Proxy mode (NEW)

- **`llm-leash-proxy` binary** — Starlette ASGI server intercepting
  `POST /v1/messages` (Anthropic) and `POST /v1/chat/completions`
  (OpenAI/OpenRouter), with full enforcement: kill switch, budget cap,
  policy engine, PII redactor, audit log, HITL queue.
- **Identity model** — extracts session_id, tenant_id, and agent_name
  from `X-LLM-Leash-*` headers, with fallback chain (XFF, auth hash).
- **Per-tenant budget caps** — `[budget.per_tenant_caps]` in `proxy.toml`.
- **`SecretsRule`** — built-in detection for 9 credential shapes (AWS,
  GitHub PAT, Stripe, OpenAI/Anthropic API keys, Slack, JWT, PEM private
  keys, high-entropy strings). Three modes: block / redact / hitl.
- **HITL queue wired into proxy** — operators approve/reject pending
  requests via `/admin/hitl/{id}/approve|reject` or `llm-leash hitl --proxy`.
- **Admin HTTP API** — bearer-token gated `/admin/*` endpoints for kill,
  tenant pause, HITL ops, aggregate stats.
- **CLI remote ops** — `llm-leash kill <session> --proxy URL`, `llm-leash
  status --proxy URL`, `llm-leash hitl ... --proxy URL`.
- **Prometheus `/metrics`** — `llm_leash_requests_total`,
  `llm_leash_cost_usd_total`, `llm_leash_active_sessions`,
  `llm_leash_hitl_pending`. Zero new deps (in-process collector).
- **Per-component `/readyz`** — concrete checks for `http_client`,
  `budget_store`, `kill_registry`; 503 if any required component fails.
- **`agent_name` field in audit events** — `ModelCall`, `ToolCallEvent`,
  `SecretsDetected` gain optional `agent_name`. Backwards-compat: old
  chains without the field still verify.

### Added — Library (used by both modes)

- `SecretsRule` exported at top level.
- `audit.schema.SecretsDetected` event kind.
- `policy.engine.PolicyEngine.rules` property (read-only view).

### Changed

- `Development Status` classifier: `5 - Production/Stable` → `4 - Beta`
  for the alpha series. Will return to `5` at the v2.0 final release.

### Installation

\`\`\`bash
pip install llm-leash==2.0.0a1                # core (in-process, zero deps)
pip install "llm-leash[proxy]==2.0.0a1"       # + proxy mode
pip install "llm-leash[anthropic,proxy]==2.0.0a1"
pip install "llm-leash[all]==2.0.0a1"
\`\`\`

### Quickstart (proxy mode, NEW)

\`\`\`bash
# 1. Start the proxy
llm-leash-proxy --listen 127.0.0.1:8000 --audit-log audit.jsonl \\
    --budget-usd 50.00

# 2. Point your agent at it — only env var changes
export ANTHROPIC_BASE_URL=http://localhost:8000
export OPENAI_BASE_URL=http://localhost:8000
python my_agent_using_anthropic_or_openai_sdk.py

# 3. Operator monitors / controls
llm-leash status --proxy http://localhost:8000  # set LLM_LEASH_ADMIN_TOKEN first
curl http://localhost:8000/metrics              # Prometheus scrape
\`\`\`

### Out of scope for this alpha

These ship in 2.0.0a2 / 2.0.0:
- **Streaming SSE** (PR-7') — `stream: true` currently treated as
  non-streaming. Full streaming with mid-stream cancellation lands next.
- **End-to-end smoke with real Anthropic / OpenAI SDKs** (PR-11)
- **Docker image + k8s manifests** (PR-12)

### Test bar

- **543 tests** (up from 314 at v1.3.0 release)
- **96% line coverage**
- ruff + mypy clean across 60+ source files
- CI matrix: Python 3.11 + 3.12

## [1.3.1] — 2026-05-16

### Added
- **Expanded Anthropic pricing coverage** in `PRICING_v_2026_05`. Real-world
  agent orchestrators (CrewAI, OpenRouter routing tables, OpenHands) pin
  model names from across the Claude family — not just the latest. Adds:
  `claude-opus-4-6`, `claude-opus-4-5`, `claude-sonnet-4-5`,
  `claude-sonnet-3-5`, `claude-haiku-3-5`.
- Patch-level only: zero behaviour changes outside the pricing table.

### Why
First field integration (Minctrl crypto-orchestrator) surfaced an
`UnknownModel` error on `claude-opus-4-6`. The table was 2026-05-future-leaning
and missed names still common in production today. v1.3.1 closes the gap.

## [1.3.0] — 2026-05-16

### Added
- **SOC 2 evidence pack generator** — `llm_leash.audit.soc2.generate_report(...)`
  turns any `audit.jsonl` into six artefacts an auditor can attach to
  their evidence binder directly:
  - `executive-summary.html` — single-page overview with integrity verdict
  - `cc6_access_control.csv` — per-session/tenant activity (CC6.1, CC6.6)
  - `cc7_monitoring.csv` — security events with reasons (CC7.1, CC7.3)
  - `cc7_integrity.json` — hash-chain verification (CC7.2)
  - `anomalies.csv` — outlier detection (kill spikes, p95 spend, tool spam)
  - `bom.json` — bill of materials with sha256 of source log and every artefact
- **CLI** — `llm-leash soc2 audit.jsonl --out DIR --period-start ISO --period-end ISO`.
  Exit code `2` when the source chain is broken.
- **`docs/SOC2.md`** — Trust Service Criteria mapping, anomaly heuristics,
  reproducibility notes.
- 314 tests, 96 % coverage.

## [1.2.0] — 2026-05-16

### Added
- **Durable HITL queue** — `HitlQueue` protocol with two backends:
  - `InMemoryHitlQueue` for tests and single-process apps
  - `SQLiteHitlQueue` for multi-process production; state survives restarts
- **`QueueBackedHitlGate`** — plugs a queue into the existing `HitlGate`
  surface so the firewall blocks (with timeout) until an operator
  approves/rejects via the queue.
- **`hitl.resume`** helpers — `pending()` / `approve()` / `reject()`
  convenience functions for operator UIs, Slack bots, CLI integrations.
- **`HTTPKillRegistry`** — kill-switch backed by a tiny HTTP service
  (GET/POST/DELETE \`/kill/{session_id}\`). Stdlib `urllib` only. Reads
  fail-open so a flaky control-plane never blocks traffic.
- **CLI `hitl` subcommand** — `llm-leash hitl list|approve|reject <queue.db>`
  for operator workflows.
- 302 tests, 96 % coverage.

## [1.1.0] — 2026-05-16

### Added
- **OpenHands adapter** — wraps `openhands.llm.LLM.completion()` (LiteLLM-shaped),
  routes `provider/model` prefixes (anthropic/openai).
- **Pydantic-AI adapter** — wraps `Model.request()` (async), handles both the
  new `input_tokens` / `output_tokens` Usage shape and the legacy
  `request_tokens` / `response_tokens` one.
- **LlamaFirewallRule** — converts a LlamaFirewall scanner's `ScanResult`
  into a `Decision` (BLOCK / HITL / ALLOW). Score-threshold gated.
- **PresidioRule** — blocks calls when Presidio detects PII entities above a
  configurable score; for redaction-instead-of-block, use `PiiRedactor`.
- Both external scanners are **duck-typed** — no `llama-firewall` or
  `presidio-analyzer` import at module level.
- 266 tests, 96 % coverage.

### Changed
- `Firewall.wrap()` dispatch order extended: Anthropic → OpenAI → LangChain →
  MCP → **OpenHands → Pydantic-AI** → CrewAI → pass-through.

## [1.0.0] — 2026-05-16

First stable release. Public surface is semver-locked.

### Added
- **Stability promise** documented in API.md. Top-level imports, audit JSONL
  schema, and CLI sub-commands (`verify`, `replay`, `export`) will not change
  without a major-version bump.
- **PyPI publication workflow** — tag `v*.*.*` to push a release.
- **Per-adapter examples** in README for Anthropic, OpenAI, LangGraph/LangChain,
  CrewAI, and MCP.

## [0.7.0] — 2026-05-16

### Added
- `audit.replay(path)` — iterator over events.
- `audit.export_csv(path, out)` / `audit.export_json(path, out)`.
- CLI `replay` and `export --format csv|json` sub-commands.
- `SQLiteBudgetStore` and `SQLiteKillRegistry` — persistent, multi-worker safe,
  stdlib `sqlite3` only.
- 229 tests, 96 % line coverage.

## [0.6.0] — 2026-05-16

### Added
- **LangChain / LangGraph adapter** — wraps `ChatAnthropic` / `ChatOpenAI`
  `.invoke()` / `.ainvoke()`.
- **CrewAI adapter** — wraps `crewai.LLM.call()` (LiteLLM-shaped responses,
  routes `anthropic/...` prefixes correctly).
- **MCP adapter** — wraps `ClientSession.call_tool()` with policy / HITL / audit.
  No token charge (tool calls are free).
- `ToolCallEvent` in the audit schema.
- `docs/TESTING.md` + `scripts/release_check.sh` — acceptance gate enforces
  ruff + mypy + pytest + coverage ≥ 85 % + smoke before tagging.
- Smoke test for the README five-line demo.

### Changed
- `Firewall.wrap()` dispatch order: Anthropic → OpenAI → LangChain → MCP → CrewAI → pass-through.

## [0.5.0] — 2026-05-16

### Added
- `HitlGate` protocol + `InMemoryHitlGate` (auto-approve/reject for tests).
- `WebhookHitlGate` — stdlib-only POST + polling, configurable timeout, zero deps.
- `HitlThreshold` rule — triggers HITL approval at a configurable % of budget cap.
- Firewall + every adapter wires `hitl_gate=`. Default-deny if no gate configured.

## [0.4.0] — 2026-05-16

### Added
- `RedisBudgetStore` and `RedisKillRegistry` — duck-typed Redis client support.
- Integration test wiring Firewall to Redis-backed stores via a fake Redis.

## [0.3.0] — 2026-05-16

### Added
- `BlockedSql` rule — keyword tokenizer with `read_only` / `no_ddl` modes.
- `BlockedShell` rule — 10-pattern shell-command blocklist.

## [0.2.0] — 2026-05-16

### Added
- `PolicyEngine` + `Rule` protocol — first non-`None` decision wins.
- `BlockedPatterns` and `BudgetThreshold` built-in rules.
- `PiiRedactor` — stdlib regex redactor for email, SSN, credit cards, phone.

## [0.1.0] — 2026-05-16

### Added
- `Firewall`, `BudgetTracker`, `AuditWriter` (hash-chained JSONL), kill switch.
- Anthropic adapter (`client.messages.create`).
- OpenAI adapter (`client.chat.completions.create`).
- `cost_for(provider, model, in_tokens, out_tokens)` with built-in pricing
  table `PRICING_v_2026_05`.
- CLI `verify` sub-command.
- 46 tests covering budget arithmetic, hash-chain integrity (property tests),
  adapter dispatch, kill-switch propagation.

[2.3.0a1]: https://github.com/avelikiy/llm-leash/releases/tag/v2.3.0a1
[2.2.0a1]: https://github.com/avelikiy/llm-leash/releases/tag/v2.2.0a1
[2.1.0a2]: https://github.com/avelikiy/llm-leash/releases/tag/v2.1.0a2
[2.1.0a1]: https://github.com/avelikiy/llm-leash/releases/tag/v2.1.0a1
[2.0.0a2]: https://github.com/avelikiy/llm-leash/releases/tag/v2.0.0a2
[2.0.0a1]: https://github.com/avelikiy/llm-leash/releases/tag/v2.0.0a1
[1.3.1]: https://github.com/avelikiy/llm-leash/releases/tag/v1.3.1
[1.3.0]: https://github.com/avelikiy/llm-leash/releases/tag/v1.3.0
[1.2.0]: https://github.com/avelikiy/llm-leash/releases/tag/v1.2.0
[1.1.0]: https://github.com/avelikiy/llm-leash/releases/tag/v1.1.0
[1.0.0]: https://github.com/avelikiy/llm-leash/releases/tag/v1.0.0
[0.7.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.7.0
[0.6.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.6.0
[0.5.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.5.0
[0.4.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.4.0
[0.3.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.3.0
[0.2.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.2.0
[0.1.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.1.0
