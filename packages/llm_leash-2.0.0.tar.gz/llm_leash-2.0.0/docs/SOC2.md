# SOC 2 Evidence Pack

`llm-leash` ships with a SOC 2 evidence generator that turns an
`audit.jsonl` log into a binder of artefacts an auditor can attach to
their evidence repository without any post-processing.

## Generating a pack

```bash
llm-leash soc2 /var/log/agent-audit.jsonl \
  --out ./evidence-2026-Q2/ \
  --period-start 2026-04-01T00:00:00Z \
  --period-end   2026-06-30T23:59:59Z \
  --org "Acme Inc"
```

Exit code:
- `0` — pack generated and the source log's hash chain verified
- `2` — pack generated but the chain is broken (printed to stderr); the pack still contains the integrity verdict so the auditor sees what went wrong

Or, from Python:

```python
from llm_leash.audit.soc2 import generate_report

report = generate_report(
    audit_log_path="audit.jsonl",
    output_dir="./evidence-2026-Q2/",
    period_start="2026-04-01T00:00:00Z",
    period_end="2026-06-30T23:59:59Z",
    organization_name="Acme Inc",
)
print(report.integrity_ok)        # True
print(report.summary["total_events"], "events")
```

## What's in the pack

Each generation produces six files in the output directory:

| File | Purpose |
|---|---|
| `executive-summary.html` | One-page overview an auditor can open in any browser |
| `cc6_access_control.csv` | Per-session/tenant activity log |
| `cc7_monitoring.csv` | Security events (kill events, hard-cap breaches) |
| `cc7_integrity.json` | Hash-chain verification result |
| `anomalies.csv` | Outliers (kill spikes, p95 spend, tool spam) |
| `bom.json` | Bill of materials: sha256 of source log + every artefact |

## Trust Service Criteria mapping

The pack covers the controls below. Each artefact lists the TSC reference
inline in `executive-summary.html` and `bom.json` for auditor convenience.

| TSC | Control | Evidence |
|---|---|---|
| **CC6.1** | Logical access controls (who accessed what) | `cc6_access_control.csv` — one row per (session, tenant), aggregating model calls, tool calls, kills, $ spent, distinct models/tools |
| **CC6.6** | Restrict transmission of data outside the system boundary | `cc6_access_control.csv` (tool_calls column) — every outbound tool invocation is logged with hashed arguments |
| **CC7.1** | System monitoring | `cc7_monitoring.csv` — every kill event and budget breach |
| **CC7.2** | Log integrity + anomaly detection | `cc7_integrity.json` (sha256 hash chain proof) + `anomalies.csv` (outlier detection) |
| **CC7.3** | Security event response | `cc7_monitoring.csv` row per kill — includes reason text |

## How the auditor uses the pack

1. Open `executive-summary.html` — read the green/red integrity verdict and high-level counts.
2. Open `bom.json` — every output file lists its sha256 and size. The auditor can independently verify each file's hash to confirm the pack was not tampered with after generation.
3. Run `llm-leash verify <source-log>` themselves to reproduce the integrity verdict.
4. Grep `cc6_access_control.csv` for any session_id of interest and see exactly what that session did.
5. Cross-reference `cc7_monitoring.csv` against the auditee's incident response runbook to confirm every security event has a recorded response.

## Reproducibility

The pack is deterministic except for the `generated_at` timestamp and
the order of `cc6_access_control.csv` rows (Python dict iteration is
insertion-ordered, so it depends on event order in the source log).

To produce a fully byte-identical pack from the same source log on
multiple machines, set `SOURCE_DATE_EPOCH` and pin the
`llm-leash` version (which is recorded in `executive-summary.html`).

## Anomaly heuristics

The thresholds in `anomalies.csv` are intentionally conservative — better
to under-flag than to fill the auditor's view with false positives.

| Anomaly | Threshold |
|---|---|
| `kill_spike` | ≥ 3 kill events in one session |
| `spend_p95` | Session total cost above the 95th percentile (requires ≥ 20 sessions for percentile to be meaningful) |
| `tool_spam` | > 100 calls to the same tool by one session |

Custom thresholds can be added by editing
`src/llm_leash/audit/soc2.py:_compute_anomalies` — the function is a
plain Python that takes the period-filtered events list. Production
deployments may want to subclass it and inject org-specific rules.

## Limitations (v1.3)

- HITL approvals/rejections are not yet first-class audit events — they
  do not appear in `cc7_monitoring.csv`. Track them via the HITL queue
  (`llm-leash hitl list`) in the meantime.
- PII redactor activity is not separately logged. The fact that PII
  scrubbing happened can only be inferred from the absence of
  recognisable PII in audit records.
- Anomaly heuristics are global; per-tenant thresholds require manual
  patching of `_compute_anomalies` today.

These are tracked for v1.4.
