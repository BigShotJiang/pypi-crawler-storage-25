# ADR-001 — Python-first, TypeScript later

**Status:** Accepted
**Date:** 2026-05-16

## Context

`llm-leash` wraps LLM agents. Agent frameworks live in two ecosystems:

- **Python:** LangGraph, CrewAI, OpenHands, Pydantic-AI, Anthropic SDK, OpenAI SDK, MCP servers (Python is the dominant SDK target).
- **TypeScript:** Vercel AI SDK, Mastra, AI-Town, MCP TypeScript SDK.

Shipping both at once costs ≥2× engineering effort for the same v0.1 feature set and forces every API change to land in two repos before it can be released.

## Decision

Ship Python first. Lock the core API surface in v0.1 (Python). Port to TypeScript in v0.4, after the v0.1–v0.3 design has been validated by real users.

Concretely:

- `llm-leash` (PyPI) is the canonical implementation.
- `llm-leash-ts` (npm) will mirror the same API and the same JSONL wire format.
- The audit log format is **language-agnostic** from day one — JSONL events written by Python are readable + verifiable by the future TS port and vice versa.

## Consequences

- **Pro:** faster to v0.1 working code, faster to Show HN, lower maintenance burden during shape-changes.
- **Pro:** the Python agent ecosystem (which is where the bulk of the in-pain audience lives) gets a v0.1 they can actually use.
- **Con:** TS-only users (Vercel AI SDK, Mastra) wait ~6 weeks for v0.4.
- **Con:** if v0.4 diverges from v0.1 in API shape, we've created two products. Mitigation: lock the API in `API.md` and treat it as a wire contract.

## Alternatives considered

- **Polyglot from day 1.** Rejected — doubles cost for an unproven product.
- **TypeScript-first.** Rejected — the Python agent ecosystem is larger and more in pain (CrewAI/LangGraph/OpenHands have no native budget/audit), and the author's existing toolchain (`great_cto`) is Python-compatible.
- **Rust core with Python + TS bindings.** Rejected — over-engineering for v0.1. Core is small enough that pure Python latency is fine (<5ms p95 per dispatch, see ARCHITECTURE.md §13).
