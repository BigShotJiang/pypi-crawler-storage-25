# `llm-leash-proxy` — Operator Guide

`llm-leash-proxy` is the **HTTP proxy mode** for llm-leash. It sits
between an LLM agent and the provider API (Anthropic, OpenAI,
OpenRouter, any OpenAI-compatible endpoint), enforces budget caps and
policy, writes a hash-chained audit log, and exposes operator controls.

**Zero code change in the agent** — only one environment variable.

---

## Install

```bash
pip install "llm-leash[proxy]==2.0.0a2"   # or pin to your version
```

Or via Docker:

```bash
docker pull ghcr.io/avelikiy/llm-leash-proxy:2.0.0a2
```

---

## Quickstart (Python, local)

```bash
# 1. Start the proxy
llm-leash-proxy \
    --listen 127.0.0.1:8000 \
    --audit-log audit.jsonl \
    --budget-usd 50.00
```

In a second terminal:

```bash
# 2. Point your agent at it
export ANTHROPIC_BASE_URL=http://localhost:8000
export OPENAI_BASE_URL=http://localhost:8000/v1

# 3. Run your agent — no code changes required
python my_agent.py
```

The agent's requests now flow through the proxy. Budget, audit log, and
kill switch are enforced; the agent sees normal provider responses (or
proper `402 Payment Required` / `403 Forbidden` / `408 Request Timeout`
on enforcement events).

---

## Quickstart (Docker)

```bash
# Build (or pull) the image
docker build -t llm-leash-proxy:local .

# Run
docker run -d --name leash \
    -p 8000:8000 \
    -e LLM_LEASH_PROXY_BUDGET_CAP_USD=50.0 \
    -e LLM_LEASH_PROXY_ADMIN_TOKEN=$(openssl rand -hex 16) \
    -v $PWD/audit:/var/log/llmleash \
    llm-leash-proxy:local

curl http://localhost:8000/healthz
```

Or use the provided `docker-compose.example.yml`:

```bash
echo "ADMIN_TOKEN=$(openssl rand -hex 16)" > .env
docker compose -f docker-compose.example.yml up
```

---

## Config

The proxy reads config in priority order: **CLI flags > env vars > TOML
file > built-in defaults**.

### TOML file (`proxy.toml`)

```toml
listen = "0.0.0.0:8000"
log_level = "info"
audit_log = "/var/log/llmleash/audit.jsonl"
admin_token = "<set via env: LLM_LEASH_PROXY_ADMIN_TOKEN>"

[budget]
backend = "inmemory"        # 'inmemory' for v2.0a2; redis/sqlite ship next
default_cap_usd = 50.0
per_tenant_caps = { acme = 200.0, beta = 10.0 }

[kill]
backend = "inmemory"

[hitl]
backend = "sqlite"          # 'none' | 'inmemory' | 'sqlite'
sqlite_path = "/var/lib/llmleash/hitl.db"
timeout_secs = 600

[policy]
# Dotted Python import path; module must define `rules = [...]`.
rules_module = "myorg.llm_rules"
pii_redactor = true
```

Run with:

```bash
llm-leash-proxy --config proxy.toml
```

### Environment variables

| Variable | Equivalent CLI flag |
|---|---|
| `LLM_LEASH_PROXY_LISTEN` | `--listen` |
| `LLM_LEASH_PROXY_LOG_LEVEL` | `--log-level` |
| `LLM_LEASH_PROXY_AUDIT_LOG` | `--audit-log` |
| `LLM_LEASH_PROXY_ADMIN_TOKEN` | (no flag; env-only for safety) |
| `LLM_LEASH_PROXY_BUDGET_CAP_USD` | `--budget-usd` |
| `LLM_LEASH_PROXY_BUDGET_BACKEND` | (config-only) |
| `LLM_LEASH_PROXY_KILL_BACKEND` | (config-only) |
| `LLM_LEASH_PROXY_HITL_BACKEND` | (config-only) |
| `LLM_LEASH_PROXY_REDIS_URL` | (config-only) |

---

## Identity model

Each request gets a deterministic `session_id`, `tenant_id`, and
optional `agent_name` from headers:

| Header | Purpose |
|---|---|
| `X-LLM-Leash-Session-Id` | Caller-supplied stable identifier |
| `X-LLM-Leash-Tenant-Id` | Multi-tenant grouping (per-tenant budget caps) |
| `X-LLM-Leash-Agent-Name` | Which agent in a multi-agent system made the call |

If no session header is set, the proxy falls through:
1. `X-Forwarded-For` → `ip-{sha256(client_ip)[:12]}`
2. `Authorization: Bearer <key>` → `key-{sha256(token)[:12]}`
3. `anonymous`

Raw keys / IPs never appear in audit — only short hashes.

---

## Endpoints

### Data plane (agent traffic)

| Method + path | Provider |
|---|---|
| `POST /v1/messages` | Anthropic |
| `POST /v1/chat/completions` | OpenAI / OpenRouter / any OpenAI-compatible |

Both support streaming (`stream: true`).

### Probes

| Path | Purpose |
|---|---|
| `GET /healthz` | Liveness — returns 200 if event loop responsive |
| `GET /readyz` | Readiness — per-component health (http_client, budget_store, kill_registry); 503 if degraded |
| `GET /metrics` | Prometheus text-format metrics (no auth — bind separately for access control) |

### Admin API (bearer auth required)

All admin endpoints require `Authorization: Bearer $admin_token`. If
`admin_token` is not configured, admin routes return 503.

| Method + path | Effect |
|---|---|
| `GET /admin/kill/{session_id}` | kill status |
| `POST /admin/kill/{session_id}` | mark killed (body: `{"reason":"..."}`) |
| `DELETE /admin/kill/{session_id}` | clear kill |
| `POST /admin/tenant/{tenant}/pause` | kill tenant-pseudo-session |
| `GET /admin/hitl/pending` | list pending HITL requests |
| `POST /admin/hitl/{id}/approve` | approve |
| `POST /admin/hitl/{id}/reject` | reject (body: `{"reason":"..."}`) |
| `GET /admin/stats` | aggregate: sessions, spend, hitl pending |

---

## CLI for operators

Once the proxy is running with an admin token, operate it remotely:

```bash
export LLM_LEASH_ADMIN_TOKEN=...

llm-leash status --proxy http://prod-proxy:8000

llm-leash kill <session-id> --proxy http://prod-proxy:8000 --reason "spending spike"

llm-leash hitl list --proxy http://prod-proxy:8000
llm-leash hitl approve <request-id> --proxy http://prod-proxy:8000
llm-leash hitl reject  <request-id> --proxy http://prod-proxy:8000 --reason "not now"
```

---

## Streaming

Set `stream: true` in the request body (as you would calling the
provider directly). The proxy switches to SSE streaming mode:

- Every byte from upstream is forwarded to the client unchanged
- Tokens are accounted at **end of stream** (charge + audit row written
  after `message_stop` / `[DONE]`)
- Pre-call `max_tokens` estimate still refuses obvious runaway requests
  before they start

For OpenAI streaming, the proxy auto-injects
`stream_options.include_usage=true` if you didn't set it — needed so
the final chunk carries token counts.

---

## Audit log

Each successful call writes one JSONL line, hash-chained for tamper
evidence. Same format as the in-process middleware (v1.x); a single
chain can serve both modes simultaneously.

Verify integrity:

```bash
llm-leash verify /var/log/llmleash/audit.jsonl
```

Generate a SOC 2 evidence pack:

```bash
llm-leash soc2 /var/log/llmleash/audit.jsonl \
    --out /var/log/llmleash/q2-2026 \
    --period-start 2026-04-01T00:00:00Z \
    --period-end   2026-06-30T23:59:59Z \
    --org "Acme Inc"
```

---

## Kubernetes

A working reference deployment lives at
`k8s/llm-leash-proxy.example.yaml`. Highlights:

- `runAsNonRoot: true`, `readOnlyRootFilesystem: true`,
  `capabilities: drop: [ALL]`, `seccompProfile: RuntimeDefault`
- Prometheus annotations on the pod for auto-scraping
- `livenessProbe` → `/healthz`, `readinessProbe` → `/readyz`
- ConfigMap for `proxy.toml`, Secret for `admin-token`
- Replicas: 2 with rolling update; surge=1, maxUnavailable=0

Switch the `emptyDir` volumes to PersistentVolumeClaims for durable
audit + SQLite HITL queue across pod restarts.

---

## Production checklist

Before you put this in front of real agents:

- [ ] Admin token set via env or k8s Secret (NOT in the TOML file)
- [ ] Audit log on durable storage (PVC / managed disk)
- [ ] HITL queue on durable storage if you have HITL workflows
- [ ] Proxy bound to internal interface, NOT `0.0.0.0` exposed to the public internet
- [ ] `/metrics` either internal-only or fronted by an authenticating reverse proxy
- [ ] Policy module pinned to a specific version in your image
- [ ] Liveness + readiness probes wired up to your platform (k8s, ECS, Nomad, …)
- [ ] Replica count ≥ 2 — if the proxy is down, no agent can reach an LLM
- [ ] Resource limits set (default Docker image is happy with 100m CPU / 128Mi memory baseline)

---

## What's NOT in v2.0.0a2

- **Mid-stream cancellation** when cumulative cost exceeds the hard cap
  during a stream. Pre-call estimate is the only enforcement during streaming.
- **Redis / SQLite backends** for budget and kill state — only in-memory
  in this alpha. Multi-replica deployments share state imperfectly until
  the Redis backend ships. (HITL queue does have SQLite backend.)
- **Per-agent budget caps** — only per-tenant. Identity propagation
  works, but the per-agent cap configuration ships later.
- **Built-in dashboard UI** — see Prometheus + `/admin/stats` for now.
  Web UI ships in v2.1.

---

## Reporting bugs

This is an alpha — surface issues at
<https://github.com/avelikiy/llm-leash/issues>.
