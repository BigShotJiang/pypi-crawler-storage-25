# Testing Strategy

This document defines the testing strategy for `llm-leash`. Every release must
pass `bash scripts/release_check.sh` before tagging.

## Test pyramid

| Layer | Location | Purpose | Required pass rate |
|---|---|---|---|
| **Unit** | `tests/<module>/test_*.py` | Pure function behaviour, isolated from I/O | 100 % |
| **Integration** | `tests/test_firewall_integration.py` | Firewall + real (or fake) adapter end-to-end | 100 % |
| **Property** | `tests/audit/test_writer_property.py`, others marked `@given` | Invariants under random input (hash chain, budget arithmetic, redactor idempotence) | 100 % |
| **Smoke** | `tests/smoke/` | The 5-line user demo runs and produces expected artefacts | 100 % |

Coverage gate: **≥ 85 %** line coverage on `src/llm_leash/`. Hard fail below.

## What MUST be tested per module

| Module | Required scenarios |
|---|---|
| `budget/tracker` | cost arithmetic, threshold trigger, cumulative reset, unknown model error |
| `budget/store` | InMemory + Redis (faked) round-trip, concurrent increments |
| `audit/writer` | hash chain integrity (property: tampering one event breaks `verify`), seq monotonicity |
| `audit/verify` | valid chain → returns N; broken chain → raises |
| `kill/registry` | InProcess + Redis: kill propagates, idempotent, scoped by session_id |
| `policy/engine` | rule chain order, first non-None wins, empty chain → None |
| `policy/predicates` | each predicate: positive match, negative match, edge cases |
| `policy/pii` | each pattern: email, SSN, CC, phone; idempotence; non-string input passthrough |
| `hitl/gate` | InMemory approve/reject; record kept |
| `hitl/webhook` | POST issued, polling honours timeout, rejected → raises |
| `adapters/<sdk>` | wrap returns proxy; `.messages.create` (or equivalent) charges + audits; sync-from-async path; LeashKilled bubbles through |

## Per-release acceptance gate

Before tagging any release, run:

```bash
bash scripts/release_check.sh
```

The script enforces, in this order:

1. **Format / lint** — `ruff check src/ tests/`
2. **Type check** — `mypy src/llm_leash`
3. **Test suite** — `pytest tests/ -q --tb=short`
4. **Coverage** — `coverage run -m pytest && coverage report --fail-under=85`
5. **Import smoke** — `python -c "import llm_leash; print(llm_leash.__version__)"`
6. **Demo smoke** — `python -m pytest tests/smoke -q` (executes the README five-line demo)

If any step fails, the release is **not** allowed to proceed. Fix the issue,
re-run, then tag.

## CI

`.github/workflows/ci.yml` calls the same script on every push and PR. Local
and CI parity is intentional: anything that passes locally must pass in CI.

## When adding new code

1. Write the failing test first (TDD).
2. Implement the minimum to make it green.
3. Add a property test if there is an invariant that should hold for *any*
   input (chain integrity, idempotent redaction, etc.).
4. Update this document if you add a new module — record the required
   scenarios in the table above.

## Coverage exclusions

The following are excluded from the coverage gate (see `pyproject.toml`
`[tool.coverage.report]`):

- `if TYPE_CHECKING:` blocks
- `@overload` decorators
- `raise NotImplementedError` stubs in protocols
- `__repr__`, `__str__` methods

Do not add ad-hoc `# pragma: no cover` unless the line is truly defensive
(e.g. an `assert False` after an exhaustive match).
