#!/usr/bin/env bash
# Release acceptance gate for llm-leash.
# Run before tagging any release. CI runs the same script.
#
# Usage:  bash scripts/release_check.sh
# Exit:   0 → all green, ready to tag
#         non-zero → fix the failing step before releasing
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

bold() { printf "\n\033[1m== %s ==\033[0m\n" "$1"; }
ok()   { printf "\033[32m✓\033[0m %s\n" "$1"; }
fail() { printf "\033[31m✗\033[0m %s\n" "$1"; exit 1; }

bold "1/6 Ruff lint"
ruff check src/ tests/ || fail "ruff failed"
ok "ruff clean"

bold "2/6 Mypy type check"
mypy src/llm_leash || fail "mypy failed"
ok "mypy clean"

bold "3/6 Pytest"
python -m pytest tests/ -q --tb=short || fail "pytest failed"
ok "all tests pass"

bold "4/6 Coverage gate (>=85%)"
coverage run --source=src/llm_leash -m pytest -q > /dev/null || fail "coverage run failed"
coverage report --fail-under=85 || fail "coverage below 85%"
ok "coverage >= 85%"

bold "5/6 Import smoke"
VERSION=$(python -c "import llm_leash; print(llm_leash.__version__)")
[ -n "$VERSION" ] || fail "import smoke failed"
ok "imports clean; version = $VERSION"

bold "6/6 Demo smoke"
if [ -d tests/smoke ]; then
  python -m pytest tests/smoke -q || fail "smoke tests failed"
  ok "smoke tests pass"
else
  ok "no tests/smoke directory (skipped)"
fi

printf "\n\033[32m═══ RELEASE READY ═══\033[0m  llm-leash %s\n" "$VERSION"
