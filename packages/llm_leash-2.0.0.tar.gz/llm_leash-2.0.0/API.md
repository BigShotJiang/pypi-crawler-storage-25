# API Reference

Stable, semver-guaranteed surface for `llm-leash` v1.0.

Anything imported from `llm_leash` at the top level is **stable**: breaking
changes require a major-version bump. Everything else (`llm_leash.adapters.*`,
`llm_leash.audit.*`, `llm_leash.policy.*`) is **public but versioned at the
minor level**; new methods and parameters can land in minor releases, but
existing signatures will not change without a deprecation cycle.

## Top-level imports

```python
from llm_leash import (
    Firewall,             # facade
    # exception types
    LeashKilled, LeashBlocked, LeashRejectedByHuman,
    # rule types
    Rule, Decision, Action, PolicyContext, ToolCall, PolicyEngine,
    # built-in rules
    BlockedPatterns, BlockedShell, BlockedSql, BudgetThreshold,
    HitlThreshold, PiiRedactor,
    # HITL
    HitlGate, InMemoryHitlGate, WebhookHitlGate,
    # backing stores
    RedisBudgetStore, RedisKillRegistry,
    SQLiteBudgetStore, SQLiteKillRegistry,
)
```

## `Firewall`

The single entry point.

```python
Firewall(
    *,
    budget_usd: float | None = None,
    budget_soft_usd: float | None = None,
    audit_log: str | None = None,
    kill_registry: KillRegistry | None = None,
    session_id: str | None = None,
    tenant_id: str | None = None,
    rules: list[Rule] | None = None,
    pii_redactor: PiiRedactor | None = None,
    hitl_gate: HitlGate | None = None,
)
```

### Methods

| Method | Returns | Description |
|---|---|---|
| `wrap(client)` | wrapped client | Dispatches to the right adapter by client shape |
| `await kill(reason)` | `None` | Marks the session killed; next call raises `LeashKilled` |
| `await cumulative_usd()` | `float` | Total spend for this session so far |
| `await aclose()` | `None` | Flushes audit log |

### Adapter dispatch

`fw.wrap(client)` detects the client shape and chooses an adapter:

| Client shape | Adapter |
|---|---|
| `client.messages.create(...)` | **Anthropic** |
| `client.chat.completions.create(...)` | **OpenAI** |
| `client.invoke(messages)` + `.model_name` or `.model` | **LangChain / LangGraph** |
| `client.call_tool(name, args)` | **MCP** |
| `client.call(messages)` + `.model` | **CrewAI** |
| Unknown | pass-through (no wrapping) |

The wrapped client preserves the original surface — all unrelated attributes
delegate to the underlying object.

## Exceptions

| Exception | When |
|---|---|
| `LeashKilled` | Hard budget cap exceeded **or** kill switch tripped |
| `LeashBlocked` | A policy rule returned `action="block"` |
| `LeashRejectedByHuman` | A HITL gate denied (explicitly or by timeout) |

Each carries `rule_id: str` and `reason: str`.

## Rules

A `Rule` is any object implementing the protocol:

```python
class MyRule:
    id: str = "my_rule"
    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None: ...
```

Return `None` to abstain; return `Decision(action=..., rule_id=..., reason=...)`
to act. The engine evaluates rules in order; the **first non-`None`** decision
wins.

`Decision.action` is one of: `"allow"`, `"block"`, `"warn"`, `"hitl"`.

### Built-in rules

| Rule | Purpose |
|---|---|
| `BlockedPatterns([regex, ...])` | Block requests whose stringified args match any pattern |
| `BlockedSql(mode="read_only" \| "no_ddl", extra_deny=[...])` | SQL keyword denylist |
| `BlockedShell()` | 10-pattern shell command blocklist (rm -rf, curl\|bash, etc.) |
| `BudgetThreshold(threshold_pct=0.8)` | Emit `warn` decisions as the cap approaches |
| `HitlThreshold(threshold_pct=0.8)` | Trigger HITL approval as the cap approaches |
| `PiiRedactor()` | Not a rule — passed via `pii_redactor=` to scrub args |

### Custom rule example

```python
from llm_leash import Decision, Firewall

class DenyToolByName:
    id = "deny_tool"
    def __init__(self, names: set[str]) -> None:
        self._names = names
    def evaluate(self, call, ctx):
        if call.tool in self._names:
            return Decision(action="block", rule_id=self.id,
                            reason=f"tool {call.tool} is on the denylist")
        return None

fw = Firewall(rules=[DenyToolByName({"shell_exec", "delete_file"})])
```

## Human-in-the-loop

```python
class HitlGate(Protocol):
    async def request(self, call: ToolCall, decision: Decision) -> None: ...
```

A call that returns from `request()` is **approved**. To reject, raise
`LeashRejectedByHuman`.

Built-in implementations:

- **`InMemoryHitlGate(default="approve" | "reject")`** — fixtures and tests.
- **`WebhookHitlGate(url, timeout_secs=60, poll_interval_secs=2)`** —
  `POST {url}/requests` then poll `GET {url}/requests/{id}`. Stdlib `urllib`,
  zero deps.

If a rule returns `Decision(action="hitl")` and **no gate is configured**,
the call is **default-denied** with `LeashRejectedByHuman`.

## Audit log

Every model call and tool call writes one JSON line, sha256-chained:

```jsonc
{
  "kind": "model_call",
  "ts": "2026-05-16T12:34:56.789Z",
  "session_id": "s_…", "tenant_id": null,
  "seq": 42, "prev_hash": "9af…", "hash": "0c1…",
  "provider": "anthropic", "model": "claude-opus-4-7",
  "input_tokens": 1024, "output_tokens": 256,
  "cost_usd": 0.1234,
  "request_hash": "…", "response_hash": "…"
}
```

Event kinds: `model_call`, `tool_call`, `budget`, `kill`.

### CLI

```bash
llm-leash verify  audit.jsonl                # exits 0 if chain is intact, 2 if broken
llm-leash replay  audit.jsonl                # prints events as JSON lines
llm-leash export  audit.jsonl --format csv   # CSV with stable column order
llm-leash export  audit.jsonl --format json  # full JSON array
```

### Programmatic access

```python
from llm_leash.audit.replay import replay, export_csv, export_json
from llm_leash.audit.verify import verify_chain

verify_chain("audit.jsonl")                  # → int (event count); raises ChainBroken
list(replay("audit.jsonl"))                  # iterator of event dicts
export_csv("audit.jsonl", sys.stdout)        # CSV writer
export_json("audit.jsonl", sys.stdout)       # JSON-array writer
```

## Backing stores

By default, budget and kill state live in-process and are lost on restart.
For multi-worker production, swap in a persistent backend:

```python
from llm_leash import Firewall, SQLiteBudgetStore, SQLiteKillRegistry

budget_store = SQLiteBudgetStore("/var/lib/myapp/budget.db")
kill_registry = SQLiteKillRegistry("/var/lib/myapp/kill.db")

fw = Firewall(budget_usd=100.0, kill_registry=kill_registry)
fw._budget._store = budget_store  # explicit swap; constructor wiring lands in v1.1
```

Redis equivalents — `RedisBudgetStore(redis_client)` / `RedisKillRegistry(redis_client)`
— accept any duck-typed Redis client (e.g. `redis.Redis`, `fakeredis.FakeRedis`).

## Type definitions

```python
@dataclass(frozen=True)
class ToolCall:
    tool: str
    args: dict[str, Any]
    session_id: str
    tenant_id: str | None

@dataclass(frozen=True)
class PolicyContext:
    cumulative_usd: float
    budget_cap_usd: float | None
    soft_cap_usd: float | None
    tenant_id: str | None

@dataclass(frozen=True)
class Decision:
    action: Action               # "allow" | "block" | "warn" | "hitl"
    rule_id: str
    reason: str
```

## Version

```python
import llm_leash
llm_leash.__version__   # → "1.0.0"
```

## Stability promise

From v1.0:
- The top-level exports listed above are **semver-stable**.
- The audit JSONL schema is **stable**: existing fields will not be removed
  or change meaning. New fields may be added.
- The CLI sub-commands `verify`, `replay`, `export` are **stable**.
- Breaking changes in any of the above require a **major-version** bump.
- Anything in `llm_leash.adapters.*`, `llm_leash.audit.*`, `llm_leash.policy.*`,
  `llm_leash.budget.*`, `llm_leash.kill.*` is **public but versioned at the
  minor level** — back-compat across minor releases unless a deprecation
  warning was emitted in the prior minor.
