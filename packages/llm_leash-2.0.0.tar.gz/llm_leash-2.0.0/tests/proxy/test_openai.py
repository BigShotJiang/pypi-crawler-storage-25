"""End-to-end tests for OpenAI / OpenRouter provider (PR-4).

Mirrors test_anthropic.py structure. Uses httpx.MockTransport for upstream
isolation — no real network.
"""
from __future__ import annotations

import asyncio
import json

import httpx
import pytest
from starlette.testclient import TestClient

from llm_leash.audit.verify import verify_chain
from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.providers.openai import (
    _extract_tokens,
    _forward_headers,
    _split_provider_model,
)
from llm_leash.proxy.server import build_app

# ─── Helpers ──────────────────────────────────────────────────────


def _ok_openai_response(
    *,
    prompt_tokens: int = 100,
    completion_tokens: int = 50,
    content: str = "ok",
    model: str = "gpt-4o",
) -> dict:
    return {
        "id": "chatcmpl-test",
        "object": "chat.completion",
        "created": 1700000000,
        "model": model,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": content},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
    }


class _UpstreamRecorder:
    def __init__(self, response: dict | None = None, status: int = 200) -> None:
        self.requests: list[httpx.Request] = []
        self._response_body = response
        self._status = status

    def handler(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        body = self._response_body if self._response_body is not None else _ok_openai_response()
        return httpx.Response(self._status, json=body)


def _make_client(
    cfg: ProxyConfig,
    upstream: _UpstreamRecorder,
) -> tuple[TestClient, _UpstreamRecorder]:
    transport = httpx.MockTransport(upstream.handler)

    def factory() -> httpx.AsyncClient:
        return httpx.AsyncClient(transport=transport)

    app = build_app(cfg, http_client_factory=factory)
    return TestClient(app), upstream


def _basic_body(model: str = "gpt-4o", max_tokens: int = 50) -> dict:
    return {
        "model": model,
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": "x"}],
    }


@pytest.fixture
def cfg(tmp_path):
    c = ProxyConfig()
    c.audit_log = str(tmp_path / "audit.jsonl")
    return c


# ─── Helper unit tests ────────────────────────────────────────────


def test_split_provider_model_bare_defaults_openai():
    assert _split_provider_model("gpt-4o") == ("openai", "gpt-4o")


def test_split_provider_model_anthropic_prefix():
    assert _split_provider_model("anthropic/claude-haiku-4-5") == (
        "anthropic", "claude-haiku-4-5",
    )


def test_split_provider_model_openai_explicit():
    assert _split_provider_model("openai/gpt-4o") == ("openai", "gpt-4o")


def test_split_provider_model_case_normalized():
    """Provider names are lowercased so 'Anthropic/...' still matches."""
    assert _split_provider_model("Anthropic/claude-haiku-4-5")[0] == "anthropic"


def test_extract_tokens_openai_shape():
    body = {"usage": {"prompt_tokens": 11, "completion_tokens": 22, "total_tokens": 33}}
    assert _extract_tokens(body) == (11, 22)


def test_extract_tokens_missing_usage():
    assert _extract_tokens({}) == (0, 0)


def test_extract_tokens_partial_usage():
    """If only one field is present, missing one defaults to 0."""
    body = {"usage": {"prompt_tokens": 11}}
    assert _extract_tokens(body) == (11, 0)


def test_forward_headers_preserves_openai_specific():
    from starlette.datastructures import Headers
    h = Headers({
        "authorization": "Bearer sk-x",
        "openai-beta": "responses=v1",
        "openai-organization": "org-xyz",
        "openai-project": "proj-xyz",
        "http-referer": "https://app.example.com",
        "x-title": "MyApp",
        "host": "localhost",
        "x-llm-leash-session-id": "s",
    })
    class _Req:
        headers = h
    out = _forward_headers(_Req())
    assert out["authorization"] == "Bearer sk-x"
    assert out["openai-beta"] == "responses=v1"
    assert out["openai-organization"] == "org-xyz"
    assert out["http-referer"] == "https://app.example.com"
    assert out["x-title"] == "MyApp"
    assert "host" not in out
    assert "x-llm-leash-session-id" not in out


# ─── Happy path ───────────────────────────────────────────────────


def test_chat_happy_path_returns_upstream_body(cfg):
    upstream = _UpstreamRecorder(response=_ok_openai_response(content="hi there"))
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post("/v1/chat/completions", json=_basic_body())
    assert resp.status_code == 200
    body = resp.json()
    assert body["choices"][0]["message"]["content"] == "hi there"


def test_chat_forwards_to_openai_by_default(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        client.post("/v1/chat/completions", json=_basic_body())
    assert len(upstream.requests) == 1
    assert str(upstream.requests[0].url) == "https://api.openai.com/v1/chat/completions"


def test_chat_charges_budget_openai_pricing(cfg):
    upstream = _UpstreamRecorder(
        response=_ok_openai_response(prompt_tokens=1000, completion_tokens=500),
    )
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/chat/completions",
            headers={"x-llm-leash-session-id": "test-session"},
            json=_basic_body(model="gpt-4o", max_tokens=100),
        )
        state = client.app.state.llm_leash
        cumulative = asyncio.run(state.budget_store.get("test-session"))
    # gpt-4o: $2.50/M in + $10/M out → 0.0025 + 0.005 = 0.0075
    assert abs(cumulative - 0.0075) < 1e-9


def test_chat_writes_audit_entry(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post("/v1/chat/completions", json=_basic_body(max_tokens=100))
    line = open(cfg.audit_log).read().strip().splitlines()[0]
    event = json.loads(line)
    assert event["kind"] == "model_call"
    assert event["provider"] == "openai"
    assert event["model"] == "gpt-4o"


def test_chat_audit_chain_verifies(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        for _ in range(3):
            client.post("/v1/chat/completions", json=_basic_body())
    assert verify_chain(cfg.audit_log) == 3


# ─── OpenRouter routing ───────────────────────────────────────────


def test_openrouter_anthropic_prefix_uses_anthropic_pricing(cfg):
    """OpenRouter passes ``anthropic/claude-haiku-4-5`` — pricing must use
    the anthropic table, not openai (which would have no entry for that
    model and raise UnknownModel)."""
    upstream = _UpstreamRecorder(
        response=_ok_openai_response(prompt_tokens=1000, completion_tokens=500),
    )
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/chat/completions",
            headers={
                "x-llm-leash-session-id": "or-test",
                "x-llm-leash-upstream": "https://openrouter.ai/api",
            },
            json=_basic_body(model="anthropic/claude-haiku-4-5"),
        )
        state = client.app.state.llm_leash
        cumulative = asyncio.run(state.budget_store.get("or-test"))
    # claude-haiku-4-5: $0.80/M in + $4.00/M out → 0.0028
    assert abs(cumulative - 0.0028) < 1e-9


def test_upstream_header_overrides_default_target(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/chat/completions",
            headers={"x-llm-leash-upstream": "https://openrouter.ai/api"},
            json=_basic_body(),
        )
    assert str(upstream.requests[0].url) == "https://openrouter.ai/api/v1/chat/completions"


def test_audit_records_provider_anthropic_when_prefixed(cfg):
    """Audit log's `provider` field should be `anthropic` for OpenRouter
    routing of an anthropic model."""
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/chat/completions",
            json=_basic_body(model="anthropic/claude-haiku-4-5"),
        )
    event = json.loads(open(cfg.audit_log).read().strip().splitlines()[0])
    assert event["provider"] == "anthropic"
    assert event["model"] == "claude-haiku-4-5"


# ─── Identity propagation ─────────────────────────────────────────


def test_explicit_session_header_drives_session_id(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/chat/completions",
            headers={"x-llm-leash-session-id": "my-session"},
            json=_basic_body(),
        )
    event = json.loads(open(cfg.audit_log).read().strip().splitlines()[0])
    assert event["session_id"] == "my-session"


def test_tenant_header_propagated_to_audit(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/chat/completions",
            headers={
                "x-llm-leash-session-id": "s1",
                "x-llm-leash-tenant-id": "acme",
            },
            json=_basic_body(),
        )
    event = json.loads(open(cfg.audit_log).read().strip().splitlines()[0])
    assert event["tenant_id"] == "acme"


def test_proxy_internal_headers_not_forwarded(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/chat/completions",
            headers={
                "x-llm-leash-session-id": "s1",
                "x-llm-leash-tenant-id": "acme",
                "x-llm-leash-upstream": "https://openrouter.ai/api",
            },
            json=_basic_body(),
        )
    req = upstream.requests[0]
    for h in (
        "x-llm-leash-session-id", "x-llm-leash-tenant-id", "x-llm-leash-upstream",
    ):
        assert h not in {k.lower() for k in req.headers}


def test_authorization_header_forwarded(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/chat/completions",
            headers={"authorization": "Bearer sk-test-key-xyz"},
            json=_basic_body(),
        )
    assert upstream.requests[0].headers.get("authorization") == "Bearer sk-test-key-xyz"


# ─── Bad request ──────────────────────────────────────────────────


def test_missing_model_returns_400(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post("/v1/chat/completions", json={"messages": []})
    assert resp.status_code == 400


def test_invalid_json_returns_400(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post(
            "/v1/chat/completions",
            content="not json",
            headers={"content-type": "application/json"},
        )
    assert resp.status_code == 400


# ─── Kill switch ──────────────────────────────────────────────────


def test_killed_session_returns_402(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        state = client.app.state.llm_leash
        asyncio.run(state.kill.kill("killed-sess", reason="abuse"))

        resp = client.post(
            "/v1/chat/completions",
            headers={"x-llm-leash-session-id": "killed-sess"},
            json=_basic_body(),
        )
    assert resp.status_code == 402
    assert resp.json()["error"]["code"] == "session_killed"
    assert upstream.requests == []


# ─── Budget cap ───────────────────────────────────────────────────


def test_pre_call_estimate_blocks_before_upstream(cfg):
    cfg.budget.default_cap_usd = 0.001  # 0.1 cent
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        resp = client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o",
                "max_tokens": 10_000_000,  # 10M at $2.50/M = $25 estimate
                "messages": [{"role": "user", "content": "x"}],
            },
        )
    assert resp.status_code == 402
    assert resp.json()["error"]["rule_id"] == "budget:pre_call_estimate"
    assert upstream.requests == []


def test_no_cap_allows_call(cfg):
    cfg.budget.default_cap_usd = None
    upstream = _UpstreamRecorder(
        response=_ok_openai_response(prompt_tokens=1_000_000, completion_tokens=1_000_000),
    )
    client, _ = _make_client(cfg, upstream)
    with client:
        resp = client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o", "max_tokens": 1_000_000,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
    assert resp.status_code == 200


# ─── Upstream errors ──────────────────────────────────────────────


def test_upstream_401_passes_through(cfg):
    upstream = _UpstreamRecorder(
        response={"error": {"message": "Invalid API key", "type": "invalid_request_error"}},
        status=401,
    )
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post("/v1/chat/completions", json=_basic_body())
    assert resp.status_code == 401
    assert resp.json()["error"]["type"] == "invalid_request_error"


def test_upstream_429_passes_through(cfg):
    upstream = _UpstreamRecorder(
        response={"error": {"message": "Rate limited", "type": "rate_limit_error"}},
        status=429,
    )
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post("/v1/chat/completions", json=_basic_body())
    assert resp.status_code == 429


# ─── Route registration ──────────────────────────────────────────


def test_chat_completions_get_returns_405(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        resp = client.get("/v1/chat/completions")
    assert resp.status_code == 405


def test_root_lists_chat_completions(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        body = client.get("/").json()
    assert "/v1/chat/completions" in body["endpoints"]
    assert "/v1/messages" in body["endpoints"]  # Anthropic still there from PR-3


# ─── Both providers coexist ──────────────────────────────────────


def test_both_providers_share_same_audit_log(cfg):
    """Anthropic /v1/messages and OpenAI /v1/chat/completions write to the
    same chained audit log. verify_chain must accept the interleaved chain."""

    def handler(req):
        if "messages" in str(req.url) and "chat" not in str(req.url):
            # Anthropic response shape
            return httpx.Response(200, json={
                "id": "msg_x", "type": "message", "role": "assistant",
                "model": "claude-haiku-4-5",
                "content": [{"type": "text", "text": "ok"}],
                "stop_reason": "end_turn",
                "usage": {"input_tokens": 10, "output_tokens": 5},
            })
        return httpx.Response(200, json=_ok_openai_response(prompt_tokens=10, completion_tokens=5))

    transport = httpx.MockTransport(handler)

    def factory():
        return httpx.AsyncClient(transport=transport)

    app = build_app(cfg, http_client_factory=factory)
    with TestClient(app) as client:
        client.post(
            "/v1/messages",
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
        client.post("/v1/chat/completions", json=_basic_body())
    assert verify_chain(cfg.audit_log) == 2

    # And providers in audit are distinguishable.
    lines = open(cfg.audit_log).read().strip().splitlines()
    providers = [json.loads(line)["provider"] for line in lines]
    assert "anthropic" in providers
    assert "openai" in providers
