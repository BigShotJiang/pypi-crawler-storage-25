"""Tests for proxy error envelope helpers (PR-3)."""
from __future__ import annotations

import json

from llm_leash.proxy.errors import (
    bad_request_response,
    hitl_timeout_response,
    leash_blocked_response,
    leash_killed_response,
    leash_rejected_response,
    upstream_error_response,
)
from llm_leash.types import LeashBlocked, LeashKilled, LeashRejectedByHuman


def _body(resp) -> dict:
    return json.loads(resp.body)


# ─── leash_killed ─────────────────────────────────────────────────


def test_killed_budget_returns_402_with_code():
    exc = LeashKilled(rule_id="budget:pre_call_estimate", reason="cap exceeded")
    resp = leash_killed_response(exc)
    assert resp.status_code == 402
    b = _body(resp)
    assert b["error"]["type"] == "leash_killed"
    assert b["error"]["code"] == "budget_exceeded"
    assert b["error"]["rule_id"] == "budget:pre_call_estimate"
    assert b["error"]["message"] == "cap exceeded"


def test_killed_via_kill_switch_distinct_code():
    """Kill switch (operator-triggered) and budget cap both return 402 but
    surface different `code` values so clients can branch."""
    exc = LeashKilled(rule_id="kill:registry", reason="manual abort")
    resp = leash_killed_response(exc)
    assert _body(resp)["error"]["code"] == "session_killed"


# ─── leash_blocked ────────────────────────────────────────────────


def test_blocked_returns_403():
    exc = LeashBlocked(rule_id="blocked_shell", reason="rm -rf detected")
    resp = leash_blocked_response(exc)
    assert resp.status_code == 403
    b = _body(resp)
    assert b["error"]["type"] == "leash_blocked"
    assert b["error"]["code"] == "policy_block"
    assert b["error"]["rule_id"] == "blocked_shell"


# ─── leash_rejected_by_human ──────────────────────────────────────


def test_rejected_by_human_returns_403_distinct_type():
    """Policy block (machine) and human rejection both return 403 but
    have distinct `type` fields so clients can retry differently."""
    exc = LeashRejectedByHuman(rule_id="hitl_threshold", reason="not now")
    resp = leash_rejected_response(exc)
    assert resp.status_code == 403
    assert _body(resp)["error"]["type"] == "leash_rejected_by_human"


# ─── hitl_timeout ─────────────────────────────────────────────────


def test_hitl_timeout_returns_408():
    resp = hitl_timeout_response(timeout_secs=600.0)
    assert resp.status_code == 408
    b = _body(resp)
    assert b["error"]["type"] == "leash_hitl_timeout"
    assert "600" in b["error"]["message"]


# ─── bad_request ──────────────────────────────────────────────────


def test_bad_request_returns_400():
    resp = bad_request_response("model field missing")
    assert resp.status_code == 400
    b = _body(resp)
    assert b["error"]["type"] == "invalid_request"
    assert "model field missing" in b["error"]["message"]


# ─── upstream_error_response ──────────────────────────────────────


def test_upstream_error_preserves_status_and_json():
    """Pass-through for upstream provider errors keeps the original shape."""
    upstream_body = json.dumps({
        "type": "error", "error": {"type": "invalid_api_key", "message": "bad key"},
    }).encode()
    resp = upstream_error_response(401, upstream_body)
    assert resp.status_code == 401
    body = _body(resp)
    assert body["error"]["type"] == "invalid_api_key"


def test_upstream_error_wraps_non_json():
    """If upstream returned non-JSON, we wrap it in our error envelope so
    clients still get usable structure."""
    resp = upstream_error_response(502, b"Bad Gateway HTML page")
    assert resp.status_code == 502
    b = _body(resp)
    assert b["error"]["type"] == "upstream_error"
    assert "non-JSON" in b["error"]["message"]
    assert b["error"]["upstream_status"] == 502
    assert "Bad Gateway" in b["error"]["upstream_body_preview"]
