"""Tests for proxy /admin/* endpoints (PR-9')."""
from __future__ import annotations

import asyncio

import httpx
import pytest
from starlette.testclient import TestClient

from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.server import build_app
from llm_leash.proxy.state import ProxyState

_TOKEN = "test-admin-token"  # noqa: S105 (test fixture)


def _ok_anthropic() -> dict:
    return {
        "id": "m", "type": "message", "role": "assistant",
        "model": "claude-haiku-4-5",
        "content": [{"type": "text", "text": "ok"}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 10, "output_tokens": 5},
    }


def _build(cfg: ProxyConfig):
    transport = httpx.MockTransport(lambda req: httpx.Response(200, json=_ok_anthropic()))
    state = ProxyState.from_config(cfg)
    state.http_client = httpx.AsyncClient(transport=transport)
    return build_app(cfg, state=state), state


@pytest.fixture
def cfg(tmp_path):
    c = ProxyConfig()
    c.audit_log = str(tmp_path / "audit.jsonl")
    c.admin_token = _TOKEN
    c.hitl.backend = "inmemory"
    return c


def _auth() -> dict[str, str]:
    return {"Authorization": f"Bearer {_TOKEN}"}


# ─── Auth ──────────────────────────────────────────────────────────


def test_admin_requires_auth(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/admin/stats")
    assert resp.status_code == 401
    assert resp.json()["error"]["type"] == "unauthorized"


def test_admin_wrong_token_returns_401(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/admin/stats", headers={"Authorization": "Bearer wrong"})
    assert resp.status_code == 401


def test_admin_returns_503_when_no_token_configured(cfg):
    """If config has no admin_token, every admin route returns 503."""
    cfg.admin_token = None
    app, _ = _build(cfg)
    with TestClient(app) as client:
        # Even with valid-looking auth, still 503 because feature is off.
        resp = client.get("/admin/stats", headers=_auth())
    assert resp.status_code == 503
    assert resp.json()["error"]["type"] == "admin_not_configured"


def test_admin_correct_token_succeeds(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/admin/stats", headers=_auth())
    assert resp.status_code == 200


# ─── Kill switch ───────────────────────────────────────────────────


def test_kill_status_when_not_killed(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/admin/kill/s1", headers=_auth())
    assert resp.status_code == 200
    body = resp.json()
    assert body["session_id"] == "s1"
    assert body["killed"] is False
    assert body["reason"] is None


def test_kill_set_marks_session(cfg):
    app, state = _build(cfg)
    with TestClient(app) as client:
        resp = client.post(
            "/admin/kill/s1",
            headers=_auth(),
            json={"reason": "abuse"},
        )
    assert resp.status_code == 200
    body = resp.json()
    assert body["killed"] is True
    assert body["reason"] == "abuse"
    # Verify state actually updated.
    assert asyncio.run(state.kill.is_killed("s1")) is True
    assert asyncio.run(state.kill.reason_for("s1")) == "abuse"


def test_kill_set_without_reason_uses_default(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.post("/admin/kill/s1", headers=_auth())
    assert resp.status_code == 200
    assert "operator kill" in resp.json()["reason"]


def test_kill_clear_removes_kill(cfg):
    app, state = _build(cfg)
    asyncio.run(state.kill.kill("s1", reason="x"))
    with TestClient(app) as client:
        resp = client.delete("/admin/kill/s1", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["killed"] is False
    assert asyncio.run(state.kill.is_killed("s1")) is False


def test_kill_then_request_returns_402(cfg):
    """End-to-end: admin kills session, real /v1/messages call returns 402."""
    app, _ = _build(cfg)
    with TestClient(app) as client:
        client.post("/admin/kill/killed-sess", headers=_auth(), json={"reason": "test"})
        resp = client.post(
            "/v1/messages",
            headers={"x-llm-leash-session-id": "killed-sess"},
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
    assert resp.status_code == 402
    assert resp.json()["error"]["code"] == "session_killed"


# ─── Tenant pause ──────────────────────────────────────────────────


def test_tenant_pause_marks_pseudo_session(cfg):
    app, state = _build(cfg)
    with TestClient(app) as client:
        resp = client.post("/admin/tenant/acme/pause", headers=_auth())
    assert resp.status_code == 200
    body = resp.json()
    assert body["tenant"] == "acme"
    assert body["tenant_marker"] == "tenant:acme"
    assert asyncio.run(state.kill.is_killed("tenant:acme")) is True


# ─── HITL pending list ──────────────────────────────────────────────


def test_hitl_pending_empty(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/admin/hitl/pending", headers=_auth())
    assert resp.status_code == 200
    body = resp.json()
    assert body["pending"] == []
    assert body["hitl_backend"] == "inmemory"


def test_hitl_pending_with_request(cfg):
    app, state = _build(cfg)
    from llm_leash.types import Decision, ToolCall
    rid = asyncio.run(state.hitl_queue.enqueue(
        ToolCall(tool="t", args={}, session_id="s1", tenant_id="acme"),
        Decision(action="hitl", rule_id="rule1", reason="needs review"),
    ))
    with TestClient(app) as client:
        resp = client.get("/admin/hitl/pending", headers=_auth())
    body = resp.json()
    assert len(body["pending"]) == 1
    assert body["pending"][0]["request_id"] == rid
    assert body["pending"][0]["session_id"] == "s1"
    assert body["pending"][0]["tenant_id"] == "acme"


def test_hitl_pending_when_backend_none(cfg):
    cfg.hitl.backend = "none"
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/admin/hitl/pending", headers=_auth())
    body = resp.json()
    assert body["pending"] == []
    assert body["hitl_backend"] == "none"


# ─── HITL approve / reject ─────────────────────────────────────────


def test_hitl_approve_via_admin(cfg):
    app, state = _build(cfg)
    from llm_leash.types import Decision, ToolCall
    rid = asyncio.run(state.hitl_queue.enqueue(
        ToolCall(tool="t", args={}, session_id="s", tenant_id=None),
        Decision(action="hitl", rule_id="r", reason="x"),
    ))
    with TestClient(app) as client:
        resp = client.post(f"/admin/hitl/{rid}/approve", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["decision"] == "approved"
    status, _ = asyncio.run(state.hitl_queue.status(rid))
    assert status == "approved"


def test_hitl_reject_via_admin(cfg):
    app, state = _build(cfg)
    from llm_leash.types import Decision, ToolCall
    rid = asyncio.run(state.hitl_queue.enqueue(
        ToolCall(tool="t", args={}, session_id="s", tenant_id=None),
        Decision(action="hitl", rule_id="r", reason="x"),
    ))
    with TestClient(app) as client:
        resp = client.post(
            f"/admin/hitl/{rid}/reject",
            headers=_auth(),
            json={"reason": "not appropriate"},
        )
    assert resp.status_code == 200
    body = resp.json()
    assert body["decision"] == "rejected"
    assert body["reason"] == "not appropriate"


def test_hitl_approve_when_backend_none_returns_503(cfg):
    cfg.hitl.backend = "none"
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.post("/admin/hitl/some-id/approve", headers=_auth())
    assert resp.status_code == 503
    assert resp.json()["error"]["type"] == "hitl_disabled"


# ─── Stats ──────────────────────────────────────────────────────────


def test_stats_empty_state(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/admin/stats", headers=_auth())
    body = resp.json()
    assert body["active_sessions"] == 0
    assert body["total_spend_usd"] == 0.0
    assert body["top_sessions"] == []
    assert body["hitl_pending"] == 0
    assert body["hitl_backend"] == "inmemory"
    assert body["policy_rules"] == 0


def test_stats_after_some_traffic(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        for sid in ["alice", "bob"]:
            client.post(
                "/v1/messages",
                headers={"x-llm-leash-session-id": sid},
                json={
                    "model": "claude-haiku-4-5", "max_tokens": 50,
                    "messages": [{"role": "user", "content": "x"}],
                },
            )
        resp = client.get("/admin/stats", headers=_auth())
    body = resp.json()
    assert body["active_sessions"] == 2
    assert body["total_spend_usd"] > 0
    assert {row["session_id"] for row in body["top_sessions"]} == {"alice", "bob"}
