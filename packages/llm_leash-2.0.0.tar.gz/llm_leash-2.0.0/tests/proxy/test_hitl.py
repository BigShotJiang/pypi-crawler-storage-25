"""Tests for HITL queue wiring in proxy mode (PR-8').

Uses httpx.AsyncClient with ASGITransport so the proxy's lifespan and
async handlers run real coroutines — needed because HITL flow involves
two coroutines (one waits on the gate, another approves via the queue).
"""
from __future__ import annotations

import asyncio
import sys
import textwrap
from types import ModuleType

import httpx
import pytest

from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.server import build_app
from llm_leash.proxy.state import ProxyState

# ─── Helpers ───────────────────────────────────────────────────────


def _ok_anthropic_response() -> dict:
    return {
        "id": "msg_x", "type": "message", "role": "assistant",
        "model": "claude-haiku-4-5",
        "content": [{"type": "text", "text": "approved!"}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 10, "output_tokens": 5},
    }


class _UpstreamRecorder:
    def __init__(self) -> None:
        self.requests: list[httpx.Request] = []

    def handler(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        return httpx.Response(200, json=_ok_anthropic_response())


def _install_hitl_rule_module(name: str) -> None:
    """Inject a rule module that ALWAYS asks for HITL approval."""
    mod = ModuleType(name)
    exec(  # noqa: S102
        textwrap.dedent("""
            from llm_leash import Decision

            class _AlwaysHitl:
                id = "always_hitl"
                def evaluate(self, call, ctx):
                    return Decision(
                        action="hitl", rule_id=self.id,
                        reason="every call needs human approval",
                    )

            rules = [_AlwaysHitl()]
        """),
        mod.__dict__,
    )
    sys.modules[name] = mod


@pytest.fixture
def cfg(tmp_path):
    c = ProxyConfig()
    c.audit_log = str(tmp_path / "audit.jsonl")
    c.hitl.backend = "inmemory"
    c.hitl.timeout_secs = 5.0
    return c


def _build(cfg: ProxyConfig, upstream: _UpstreamRecorder):
    """Build an app whose state.http_client is preset (bypasses lifespan).

    httpx.ASGITransport does not run Starlette's lifespan handler, so we
    set the outbound client up front. The app's lifespan would be a no-op
    on http_client (already set) but state.aclose() runs only via the
    AsyncClient context manager exit — fine for tests.
    """
    upstream_transport = httpx.MockTransport(upstream.handler)
    state = ProxyState.from_config(cfg)
    state.http_client = httpx.AsyncClient(transport=upstream_transport)
    return build_app(cfg, state=state), state


def _basic_body() -> dict:
    return {
        "model": "claude-haiku-4-5",
        "max_tokens": 50,
        "messages": [{"role": "user", "content": "hi"}],
    }


# ─── State factory ─────────────────────────────────────────────────


def test_state_no_hitl_when_backend_none():
    cfg = ProxyConfig()
    cfg.hitl.backend = "none"
    state = ProxyState.from_config(cfg)
    assert state.hitl_gate is None
    assert state.hitl_queue is None


def test_state_inmemory_hitl():
    cfg = ProxyConfig()
    cfg.hitl.backend = "inmemory"
    state = ProxyState.from_config(cfg)
    assert state.hitl_gate is not None
    assert state.hitl_queue is not None


def test_state_sqlite_hitl_requires_path():
    cfg = ProxyConfig()
    cfg.hitl.backend = "sqlite"
    with pytest.raises(ValueError, match=r"requires hitl\.sqlite_path"):
        ProxyState.from_config(cfg)


def test_state_sqlite_hitl_with_path(tmp_path):
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.hitl.backend = "sqlite"
    cfg.hitl.sqlite_path = str(tmp_path / "hitl.db")
    state = ProxyState.from_config(cfg)
    assert state.hitl_gate is not None
    assert state.hitl_queue is not None
    # close the queue so the next test doesn't see a locked db
    asyncio.run(state.aclose())


def test_state_unsupported_hitl_backend():
    cfg = ProxyConfig()
    cfg.hitl.backend = "kafka"
    with pytest.raises(ValueError, match="Unsupported hitl backend"):
        ProxyState.from_config(cfg)


# ─── Default-deny when backend=none (regression of PR-5' behaviour) ──


@pytest.mark.asyncio
async def test_hitl_no_gate_returns_403(cfg, tmp_path):
    """When hitl.backend='none' and a rule emits hitl, default-deny."""
    cfg.hitl.backend = "none"
    _install_hitl_rule_module("_hitl_default_deny")
    cfg.policy.rules_module = "_hitl_default_deny"
    upstream = _UpstreamRecorder()
    app, _state = _build(cfg, upstream)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post("/v1/messages", json=_basic_body())
    assert resp.status_code == 403
    body = resp.json()
    assert body["error"]["type"] == "leash_rejected_by_human"
    assert "no gate configured" in body["error"]["message"]


# ─── Approve flow ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_hitl_approve_unblocks_request(cfg):
    """Rule asks for HITL → request hangs on the queue → operator approves
    via state.hitl_queue.approve(id) → request completes with 200."""
    _install_hitl_rule_module("_hitl_approve_flow")
    cfg.policy.rules_module = "_hitl_approve_flow"
    upstream = _UpstreamRecorder()
    app, state = _build(cfg, upstream)

    async def operator_loop():
        # Poll the queue until something appears, then approve it.
        for _ in range(50):
            pending = await state.hitl_queue.list_pending()
            if pending:
                await state.hitl_queue.approve(pending[0].request_id)
                return
            await asyncio.sleep(0.05)
        raise AssertionError("operator: nothing pending after 2.5s")

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as ac:
        # Start request and operator approval in parallel.
        op_task = asyncio.create_task(operator_loop())
        resp = await ac.post("/v1/messages", json=_basic_body())
        await op_task

    assert resp.status_code == 200
    assert resp.json()["content"][0]["text"] == "approved!"
    # Upstream was hit exactly once.
    assert len(upstream.requests) == 1


# ─── Reject flow ───────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_hitl_reject_returns_403(cfg):
    """Operator rejects via queue.reject(id, reason) → request returns 403."""
    _install_hitl_rule_module("_hitl_reject_flow")
    cfg.policy.rules_module = "_hitl_reject_flow"
    upstream = _UpstreamRecorder()
    app, state = _build(cfg, upstream)

    async def operator_loop():
        for _ in range(50):
            pending = await state.hitl_queue.list_pending()
            if pending:
                await state.hitl_queue.reject(
                    pending[0].request_id, reason="too risky today",
                )
                return
            await asyncio.sleep(0.05)
        raise AssertionError("operator: nothing pending")

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as ac:
        op_task = asyncio.create_task(operator_loop())
        resp = await ac.post("/v1/messages", json=_basic_body())
        await op_task

    assert resp.status_code == 403
    body = resp.json()
    assert body["error"]["type"] == "leash_rejected_by_human"
    assert "too risky today" in body["error"]["message"]
    # Upstream was NOT hit.
    assert upstream.requests == []


# ─── Timeout flow ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_hitl_timeout_returns_408(cfg):
    """If no operator decides within timeout_secs, return 408."""
    cfg.hitl.timeout_secs = 0.2  # 200 ms — fast test
    _install_hitl_rule_module("_hitl_timeout_flow")
    cfg.policy.rules_module = "_hitl_timeout_flow"
    upstream = _UpstreamRecorder()
    app, _state = _build(cfg, upstream)

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post("/v1/messages", json=_basic_body())

    assert resp.status_code == 408
    body = resp.json()
    assert body["error"]["type"] == "leash_hitl_timeout"
    assert "0.2" in body["error"]["message"]
    assert upstream.requests == []


# ─── OpenAI path also wired ────────────────────────────────────────


@pytest.mark.asyncio
async def test_hitl_openai_approve_path(cfg):
    """Same HITL plumbing for /v1/chat/completions."""
    _install_hitl_rule_module("_hitl_openai_flow")
    cfg.policy.rules_module = "_hitl_openai_flow"

    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={
            "id": "x", "object": "chat.completion", "created": 1,
            "model": "gpt-4o",
            "choices": [{
                "index": 0, "finish_reason": "stop",
                "message": {"role": "assistant", "content": "approved!"},
            }],
            "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
        })

    upstream_transport = httpx.MockTransport(handler)
    state = ProxyState.from_config(cfg)
    state.http_client = httpx.AsyncClient(transport=upstream_transport)
    app = build_app(cfg, state=state)

    async def operator_loop():
        for _ in range(50):
            pending = await state.hitl_queue.list_pending()
            if pending:
                await state.hitl_queue.approve(pending[0].request_id)
                return
            await asyncio.sleep(0.05)
        raise AssertionError("operator: nothing pending")

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as ac:
        op_task = asyncio.create_task(operator_loop())
        resp = await ac.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
        await op_task

    assert resp.status_code == 200
    assert resp.json()["choices"][0]["message"]["content"] == "approved!"


# ─── HITL request carries identity ─────────────────────────────────


@pytest.mark.asyncio
async def test_hitl_request_carries_session_tenant_agent(cfg):
    """The HitlRequest enqueued for operator review should include enough
    identity for the operator to make a decision."""
    _install_hitl_rule_module("_hitl_identity")
    cfg.policy.rules_module = "_hitl_identity"
    upstream = _UpstreamRecorder()
    app, state = _build(cfg, upstream)

    captured: list = []

    async def operator_loop():
        for _ in range(50):
            pending = await state.hitl_queue.list_pending()
            if pending:
                captured.append(pending[0])
                await state.hitl_queue.approve(pending[0].request_id)
                return
            await asyncio.sleep(0.05)
        raise AssertionError("nothing pending")

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as ac:
        op_task = asyncio.create_task(operator_loop())
        await ac.post(
            "/v1/messages",
            headers={
                "x-llm-leash-session-id": "minctrl-run-1",
                "x-llm-leash-tenant-id": "acme",
                "x-llm-leash-agent-name": "devops",
            },
            json=_basic_body(),
        )
        await op_task

    assert len(captured) == 1
    req = captured[0]
    assert req.session_id == "minctrl-run-1"
    assert req.tenant_id == "acme"
    # Note: HitlRequest doesn't currently track agent_name on the dataclass;
    # rule's id + reason is what operator sees. Add this assertion when
    # HitlRequest grows an agent_name field (future PR).
    assert req.rule_id == "always_hitl"
