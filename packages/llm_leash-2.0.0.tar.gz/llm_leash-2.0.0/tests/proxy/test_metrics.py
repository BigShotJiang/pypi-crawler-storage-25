"""Tests for the in-process Prometheus collector + /metrics endpoint."""
from __future__ import annotations

import httpx
import pytest
from starlette.testclient import TestClient

from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.metrics import Counter, Gauge, Registry, build_registry
from llm_leash.proxy.server import build_app
from llm_leash.proxy.state import ProxyState

# ─── Counter ───────────────────────────────────────────────────────


def test_counter_inc_default_amount():
    c = Counter("foo", "test counter")
    c.inc(provider="anthropic")
    c.inc(provider="anthropic")
    items = dict(c.items())
    assert items[(("provider", "anthropic"),)] == 2.0


def test_counter_inc_custom_amount():
    c = Counter("foo", "test")
    c.inc(0.5, x="a")
    c.inc(1.5, x="a")
    items = dict(c.items())
    assert items[(("x", "a"),)] == 2.0


def test_counter_distinct_label_sets():
    c = Counter("foo", "test")
    c.inc(provider="anthropic", model="claude")
    c.inc(provider="openai", model="gpt-4o")
    items = dict(c.items())
    assert len(items) == 2


def test_counter_label_keys_sorted_for_stability():
    """Same labels in different order → same key (so we don't double-count)."""
    c = Counter("foo", "test")
    c.inc(a="1", b="2")
    c.inc(b="2", a="1")
    items = dict(c.items())
    assert len(items) == 1
    assert next(iter(items.values())) == 2.0


# ─── Gauge ─────────────────────────────────────────────────────────


def test_gauge_set_and_read():
    g = Gauge("g", "test")
    g.set(42.0, region="eu")
    g.set(7.0, region="us")
    items = dict(g.items())
    assert items[(("region", "eu"),)] == 42.0
    assert items[(("region", "us"),)] == 7.0


def test_gauge_callback_no_labels():
    g = Gauge("active", "test", callback=lambda: 5.0)
    items = g.items()
    assert items == [((), 5.0)]


def test_gauge_callback_with_labels():
    def cb():
        return [({"tenant": "a"}, 3.0), ({"tenant": "b"}, 5.0)]
    g = Gauge("by_tenant", "test", callback=cb)
    items = dict(g.items())
    assert items[(("tenant", "a"),)] == 3.0
    assert items[(("tenant", "b"),)] == 5.0


# ─── Registry rendering ────────────────────────────────────────────


def test_registry_renders_help_type_lines():
    r = Registry()
    c = Counter("my_total", "my help text")
    c.inc(provider="x")
    r.register(c)
    out = r.render()
    assert "# HELP my_total my help text" in out
    assert "# TYPE my_total counter" in out
    assert 'my_total{provider="x"} 1' in out


def test_registry_escapes_label_values():
    r = Registry()
    c = Counter("foo", "test")
    c.inc(reason='has "quotes" and \\backslash')
    r.register(c)
    out = r.render()
    assert '\\"quotes\\"' in out
    assert "\\\\backslash" in out


def test_registry_integer_values_no_decimal():
    """Counters that are whole numbers render as integers."""
    r = Registry()
    c = Counter("count", "test")
    c.inc(x="a")
    c.inc(x="a")
    c.inc(x="a")
    r.register(c)
    out = r.render()
    assert '{x="a"} 3\n' in out
    assert '{x="a"} 3.0' not in out


def test_registry_empty_no_label_metric():
    r = Registry()
    g = Gauge("plain", "test", callback=lambda: 7.0)
    r.register(g)
    out = r.render()
    assert "plain 7\n" in out  # no label braces when empty


# ─── build_registry integration ────────────────────────────────────


def test_build_registry_attaches_metrics_to_state():
    cfg = ProxyConfig()
    state = ProxyState.from_config(cfg)
    build_registry(state)
    assert state.metrics is not None
    assert hasattr(state.metrics, "requests_total")
    assert hasattr(state.metrics, "cost_usd_total")


def test_build_registry_active_sessions_gauge_reflects_trackers():
    cfg = ProxyConfig()
    state = ProxyState.from_config(cfg)
    build_registry(state)
    out = state.metrics.registry.render()
    assert "llm_leash_active_sessions 0\n" in out

    state.tracker_for("alice", None)
    state.tracker_for("bob", None)
    out = state.metrics.registry.render()
    assert "llm_leash_active_sessions 2\n" in out


# ─── /metrics endpoint end-to-end ──────────────────────────────────


def _ok_anthropic() -> dict:
    return {
        "id": "m", "type": "message", "role": "assistant",
        "model": "claude-haiku-4-5",
        "content": [{"type": "text", "text": "ok"}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 100, "output_tokens": 50},
    }


def _build(cfg: ProxyConfig):
    transport = httpx.MockTransport(lambda req: httpx.Response(200, json=_ok_anthropic()))
    state = ProxyState.from_config(cfg)
    state.http_client = httpx.AsyncClient(transport=transport)
    return build_app(cfg, state=state), state


@pytest.fixture
def cfg(tmp_path):
    c = ProxyConfig()
    c.audit_log = str(tmp_path / "audit.jsonl")
    return c


def test_metrics_endpoint_returns_prometheus_text(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/metrics")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/plain")
    body = resp.text
    # All metric names should be advertised even with zero traffic.
    assert "# HELP llm_leash_requests_total" in body
    assert "# HELP llm_leash_cost_usd_total" in body
    assert "# HELP llm_leash_active_sessions" in body
    assert "# HELP llm_leash_hitl_pending" in body


def test_metrics_count_requests_per_provider_agent(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        for _ in range(3):
            client.post(
                "/v1/messages",
                headers={"x-llm-leash-agent-name": "analyst"},
                json={
                    "model": "claude-haiku-4-5", "max_tokens": 50,
                    "messages": [{"role": "user", "content": "x"}],
                },
            )
        body = client.get("/metrics").text
    assert 'llm_leash_requests_total{agent="analyst",model="claude-haiku-4-5",' \
           'outcome="ok",provider="anthropic"} 3' in body


def test_metrics_track_cumulative_cost(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        client.post(
            "/v1/messages",
            headers={
                "x-llm-leash-agent-name": "devops",
                "x-llm-leash-session-id": "s1",
            },
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
        body = client.get("/metrics").text
    # cost_usd_total appears with the agent label
    assert "llm_leash_cost_usd_total{" in body
    assert 'agent="devops"' in body


def test_metrics_open_to_all_no_admin_token_required(cfg):
    """The /metrics endpoint is intentionally public (typical Prometheus
    pattern) — operators wanting access control should bind separately."""
    cfg.admin_token = None  # no admin token configured
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/metrics")
    assert resp.status_code == 200


# ─── /readyz upgrades ─────────────────────────────────────────────


def test_readyz_reports_concrete_checks(cfg):
    app, _ = _build(cfg)
    with TestClient(app) as client:
        resp = client.get("/readyz")
    body = resp.json()
    assert resp.status_code == 200
    assert body["status"] == "ready"
    checks = body["checks"]
    assert checks["http_client"] is True
    assert checks["budget_store"] is True
    assert checks["kill_registry"] is True
    assert checks["hitl_backend"] in ("none", "inmemory", "sqlite")


def test_readyz_503_when_http_client_unset(cfg):
    """Without lifespan running, http_client is None → degraded."""
    state = ProxyState.from_config(cfg)
    # Override the default factory with one that returns a client we
    # immediately clear, so lifespan can't fix it.
    app = build_app(cfg, state=state, http_client_factory=lambda: None)  # type: ignore[arg-type]
    # NOT using `with` — lifespan doesn't run → http_client stays None.
    client = TestClient(app)
    resp = client.get("/readyz")
    assert resp.status_code == 503
    assert resp.json()["status"] == "degraded"