"""Tests for ProxyState container (PR-3)."""
from __future__ import annotations

import pytest

from llm_leash.audit.writer import AuditWriter
from llm_leash.budget.store import InMemoryStore
from llm_leash.kill.registry import InProcessKillRegistry
from llm_leash.policy.engine import PolicyEngine
from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.state import ProxyState

# ─── from_config ──────────────────────────────────────────────────


def test_from_config_default_uses_in_memory():
    cfg = ProxyConfig()  # all defaults → inmemory
    cfg.audit_log = ""  # skip file writer
    state = ProxyState.from_config(cfg)
    assert isinstance(state.budget_store, InMemoryStore)
    assert isinstance(state.kill, InProcessKillRegistry)
    assert isinstance(state.engine, PolicyEngine)
    assert state.engine.rules == []


def test_from_config_audit_writer_when_path_set(tmp_path):
    cfg = ProxyConfig()
    cfg.audit_log = str(tmp_path / "audit.jsonl")
    state = ProxyState.from_config(cfg)
    assert isinstance(state.audit, AuditWriter)


def test_from_config_noop_audit_when_path_empty():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    state = ProxyState.from_config(cfg)
    # Anything non-AuditWriter that quacks like one is OK.
    assert hasattr(state.audit, "write")
    assert hasattr(state.audit, "close")


def test_from_config_unsupported_backend_rejected():
    cfg = ProxyConfig()
    cfg.budget.backend = "postgres"  # not in v2.0 PR-3
    with pytest.raises(ValueError, match="Unsupported budget backend"):
        ProxyState.from_config(cfg)


def test_from_config_unsupported_kill_backend_rejected():
    cfg = ProxyConfig()
    cfg.kill.backend = "nats"  # not in v2.0 PR-3
    with pytest.raises(ValueError, match="Unsupported kill backend"):
        ProxyState.from_config(cfg)


# ─── tracker_for ──────────────────────────────────────────────────


def test_tracker_for_caches_per_session():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.default_cap_usd = 10.0
    state = ProxyState.from_config(cfg)
    t1 = state.tracker_for("session-a", None)
    t2 = state.tracker_for("session-a", None)
    assert t1 is t2


def test_tracker_for_distinct_sessions_independent():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.default_cap_usd = 10.0
    state = ProxyState.from_config(cfg)
    assert state.tracker_for("a", None) is not state.tracker_for("b", None)


def test_tracker_for_uses_tenant_cap_when_present():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.default_cap_usd = 10.0
    cfg.budget.per_tenant_caps = {"acme": 100.0}
    state = ProxyState.from_config(cfg)
    t = state.tracker_for("s1", "acme")
    assert t._hard == 100.0


def test_tracker_for_falls_back_to_default_cap():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.default_cap_usd = 5.0
    cfg.budget.per_tenant_caps = {"acme": 100.0}
    state = ProxyState.from_config(cfg)
    t = state.tracker_for("s1", "no-such-tenant")
    assert t._hard == 5.0


def test_tracker_for_no_cap_at_all_when_not_configured():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    state = ProxyState.from_config(cfg)
    t = state.tracker_for("s1", None)
    assert t._hard is None  # no cap → never refuses on budget


# ─── GA-3: per-agent cap precedence ───────────────────────────────


def test_tracker_for_per_agent_cap_overrides_tenant():
    """agent cap (highest) wins over tenant cap."""
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.default_cap_usd = 5.0
    cfg.budget.per_tenant_caps = {"acme": 100.0}
    cfg.budget.per_agent_caps = {"prod-writer": 25.0}
    state = ProxyState.from_config(cfg)
    t = state.tracker_for("s1", "acme", "prod-writer")
    assert t._hard == 25.0  # per-agent wins


def test_tracker_for_falls_back_to_tenant_when_agent_unknown():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.default_cap_usd = 5.0
    cfg.budget.per_tenant_caps = {"acme": 100.0}
    cfg.budget.per_agent_caps = {"prod-writer": 25.0}
    state = ProxyState.from_config(cfg)
    t = state.tracker_for("s1", "acme", "some-other-agent")
    assert t._hard == 100.0  # falls back to tenant


def test_tracker_for_falls_back_to_default_when_no_agent_or_tenant_match():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.default_cap_usd = 5.0
    cfg.budget.per_agent_caps = {"prod-writer": 25.0}
    state = ProxyState.from_config(cfg)
    t = state.tracker_for("s1", None, None)
    assert t._hard == 5.0


def test_tracker_for_agent_cap_with_no_tenant():
    """Per-agent cap fires even when tenant is unset."""
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.default_cap_usd = 5.0
    cfg.budget.per_agent_caps = {"prod-writer": 25.0}
    state = ProxyState.from_config(cfg)
    t = state.tracker_for("s1", None, "prod-writer")
    assert t._hard == 25.0


def test_tracker_for_caches_per_session_and_agent():
    """Different agents on the same session get distinct trackers
    (so each gets its own cap) but share the underlying budget store."""
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.per_agent_caps = {"a1": 10.0, "a2": 20.0}
    state = ProxyState.from_config(cfg)
    t1 = state.tracker_for("session-a", None, "a1")
    t2 = state.tracker_for("session-a", None, "a2")
    t1_again = state.tracker_for("session-a", None, "a1")
    assert t1 is t1_again       # cached
    assert t1 is not t2         # different agent → different tracker
    assert t1._hard == 10.0
    assert t2._hard == 20.0
    # Same underlying store → balance shared.
    assert t1._store is t2._store


# ─── GA-3: TOML round-trip ────────────────────────────────────────


def test_from_toml_parses_per_agent_caps(tmp_path):
    """[budget.per_agent_caps] table is parsed into BudgetConfig."""
    from llm_leash.proxy.config import from_toml
    cfg = from_toml({
        "budget": {
            "default_cap_usd": 5.0,
            "per_tenant_caps": {"acme": 100.0},
            "per_agent_caps": {"writer-prod": 25.0, "reader-prod": 10.0},
        },
    })
    assert cfg.budget.per_agent_caps == {"writer-prod": 25.0, "reader-prod": 10.0}


# ─── aclose is idempotent ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_aclose_is_idempotent():
    cfg = ProxyConfig()
    cfg.audit_log = ""
    state = ProxyState.from_config(cfg)
    await state.aclose()
    await state.aclose()  # second call must not raise
