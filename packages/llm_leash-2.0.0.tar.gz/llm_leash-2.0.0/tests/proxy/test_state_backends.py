"""Tests for proxy backend wiring: sqlite + redis (v2.0 GA)."""
from __future__ import annotations

import asyncio

import pytest

from llm_leash.budget.redis_store import RedisBudgetStore
from llm_leash.budget.sqlite_store import SQLiteBudgetStore
from llm_leash.budget.store import InMemoryStore
from llm_leash.kill.redis_registry import RedisKillRegistry
from llm_leash.kill.registry import InProcessKillRegistry
from llm_leash.kill.sqlite_registry import SQLiteKillRegistry
from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.state import ProxyState


class _FakeRedis:
    """Minimal in-memory Redis stand-in. Same shape as v0.4 tests."""

    def __init__(self) -> None:
        self._data: dict[str, bytes] = {}

    def get(self, key: str) -> bytes | None:
        return self._data.get(key)

    def set(self, key: str, value: str | bytes) -> None:
        self._data[key] = value.encode() if isinstance(value, str) else value

    def delete(self, key: str) -> None:
        self._data.pop(key, None)

    def exists(self, key: str) -> int:
        return 1 if key in self._data else 0

    def incrbyfloat(self, key: str, amount: float) -> float:
        current = float(self._data.get(key, b"0"))
        new = current + amount
        self._data[key] = str(new).encode()
        return new


# ─── Budget backend selection ──────────────────────────────────


def test_budget_inmemory_is_default():
    cfg = ProxyConfig()
    state = ProxyState.from_config(cfg)
    assert isinstance(state.budget_store, InMemoryStore)


def test_budget_sqlite_requires_path():
    cfg = ProxyConfig()
    cfg.budget.backend = "sqlite"
    with pytest.raises(ValueError, match=r"requires budget\.sqlite_path"):
        ProxyState.from_config(cfg)


def test_budget_sqlite_constructs(tmp_path):
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.budget.backend = "sqlite"
    cfg.budget.sqlite_path = str(tmp_path / "budget.db")
    state = ProxyState.from_config(cfg)
    assert isinstance(state.budget_store, SQLiteBudgetStore)
    asyncio.run(state.aclose())


def test_budget_redis_requires_url():
    cfg = ProxyConfig()
    cfg.budget.backend = "redis"
    with pytest.raises(ValueError, match=r"requires budget\.redis_url"):
        ProxyState.from_config(cfg)


def test_budget_unsupported_backend_rejected():
    cfg = ProxyConfig()
    cfg.budget.backend = "postgres"
    with pytest.raises(ValueError, match="Unsupported budget backend"):
        ProxyState.from_config(cfg)


# ─── Kill backend selection ────────────────────────────────────


def test_kill_inmemory_is_default():
    cfg = ProxyConfig()
    state = ProxyState.from_config(cfg)
    assert isinstance(state.kill, InProcessKillRegistry)


def test_kill_sqlite_requires_path():
    cfg = ProxyConfig()
    cfg.kill.backend = "sqlite"
    with pytest.raises(ValueError, match=r"requires kill\.sqlite_path"):
        ProxyState.from_config(cfg)


def test_kill_sqlite_constructs(tmp_path):
    cfg = ProxyConfig()
    cfg.audit_log = ""
    cfg.kill.backend = "sqlite"
    cfg.kill.sqlite_path = str(tmp_path / "kill.db")
    state = ProxyState.from_config(cfg)
    assert isinstance(state.kill, SQLiteKillRegistry)
    asyncio.run(state.aclose())


def test_kill_redis_requires_url():
    cfg = ProxyConfig()
    cfg.kill.backend = "redis"
    with pytest.raises(ValueError, match=r"requires kill\.redis_url"):
        ProxyState.from_config(cfg)


def test_kill_unsupported_backend_rejected():
    cfg = ProxyConfig()
    cfg.kill.backend = "etcd"
    with pytest.raises(ValueError, match="Unsupported kill backend"):
        ProxyState.from_config(cfg)


# ─── Redis backends with injected client (full integration via FakeRedis) ──


def test_redis_budget_store_round_trip_via_fake_redis():
    """Direct unit test of RedisBudgetStore using FakeRedis (bypasses proxy
    state factory — the factory only constructs a real redis.Redis, but we
    want to exercise the actual store logic without a server)."""
    fake = _FakeRedis()
    store = RedisBudgetStore(fake)
    asyncio.run(store.add("session-x", 0.10))
    asyncio.run(store.add("session-x", 0.25))
    total = asyncio.run(store.get("session-x"))
    assert total == pytest.approx(0.35)


def test_redis_kill_registry_round_trip_via_fake_redis():
    fake = _FakeRedis()
    reg = RedisKillRegistry(fake)
    asyncio.run(reg.kill("session-x", reason="abuse"))
    assert asyncio.run(reg.is_killed("session-x")) is True
    assert asyncio.run(reg.reason_for("session-x")) == "abuse"
    asyncio.run(reg.clear("session-x"))
    assert asyncio.run(reg.is_killed("session-x")) is False


# ─── End-to-end: proxy with sqlite backends + budget enforcement ──


def test_end_to_end_sqlite_budget_cap(tmp_path):
    """Proxy with sqlite budget store enforces cap correctly across requests."""
    import httpx
    from starlette.testclient import TestClient

    from llm_leash.proxy.server import build_app

    def upstream_handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={
            "id": "m", "type": "message", "role": "assistant",
            "model": "claude-haiku-4-5",
            "content": [{"type": "text", "text": "ok"}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 1_000_000, "output_tokens": 0},  # ~$0.80
        })

    cfg = ProxyConfig()
    cfg.audit_log = str(tmp_path / "audit.jsonl")
    cfg.budget.backend = "sqlite"
    cfg.budget.sqlite_path = str(tmp_path / "budget.db")
    cfg.budget.default_cap_usd = 1.0  # $1 cap, each call costs $0.80

    state = ProxyState.from_config(cfg)
    state.http_client = httpx.AsyncClient(transport=httpx.MockTransport(upstream_handler))
    app = build_app(cfg, state=state)

    with TestClient(app) as client:
        # First call: $0.80 ≤ $1.00 → succeeds.
        resp = client.post(
            "/v1/messages",
            headers={"x-llm-leash-session-id": "ga-budget-test"},
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
        assert resp.status_code == 200

        # Second call: $0.80 + $0.80 = $1.60 > $1.00 → pre-call estimate refuses.
        # The pre-call estimate uses max_tokens=50, so estimate is tiny.
        # The actual blocker is the cumulative-before check.
        # With max_tokens=10_000_000, the estimate alone exceeds cap.
        resp = client.post(
            "/v1/messages",
            headers={"x-llm-leash-session-id": "ga-budget-test"},
            json={
                "model": "claude-haiku-4-5", "max_tokens": 10_000_000,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
        assert resp.status_code == 402

    asyncio.run(state.aclose())
