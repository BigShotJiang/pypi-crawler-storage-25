"""Tests for proxy identity extraction (PR-2)."""
from __future__ import annotations

from llm_leash.proxy.identity import (
    AUTH_HEADER,
    FORWARDED_HEADER,
    SESSION_HEADER,
    TENANT_HEADER,
    extract_identity,
)

# ─── Explicit headers ─────────────────────────────────────────────


def test_session_header_wins():
    ident = extract_identity({SESSION_HEADER: "explicit-s1"})
    assert ident.session_id == "explicit-s1"
    assert ident.source == "header"
    assert ident.tenant_id is None


def test_tenant_header_captured():
    ident = extract_identity({
        SESSION_HEADER: "s1",
        TENANT_HEADER: "acme",
    })
    assert ident.tenant_id == "acme"


def test_session_header_is_case_insensitive():
    ident = extract_identity({"X-LLM-Leash-Session-Id": "weird-case"})
    assert ident.session_id == "weird-case"


def test_session_header_overrides_lower_precedence():
    """Explicit session header trumps both X-Forwarded-For and Authorization."""
    ident = extract_identity({
        SESSION_HEADER: "explicit",
        FORWARDED_HEADER: "1.2.3.4",
        AUTH_HEADER: "Bearer sk-test-123",
    })
    assert ident.session_id == "explicit"
    assert ident.source == "header"


# ─── Forwarded-For fallback ───────────────────────────────────────


def test_forwarded_for_fallback():
    ident = extract_identity({FORWARDED_HEADER: "203.0.113.42"})
    assert ident.source == "forwarded_for"
    assert ident.session_id.startswith("ip-")
    assert len(ident.session_id) == len("ip-") + 12  # 12 hex chars of sha256


def test_forwarded_for_uses_leftmost_in_chain():
    """The leftmost IP in the X-Forwarded-For chain is the original client."""
    ident_one = extract_identity({FORWARDED_HEADER: "1.1.1.1, 2.2.2.2, 3.3.3.3"})
    ident_two = extract_identity({FORWARDED_HEADER: "1.1.1.1"})
    assert ident_one.session_id == ident_two.session_id


def test_forwarded_for_different_ips_distinct_sessions():
    a = extract_identity({FORWARDED_HEADER: "1.1.1.1"})
    b = extract_identity({FORWARDED_HEADER: "2.2.2.2"})
    assert a.session_id != b.session_id


# ─── Authorization fallback ───────────────────────────────────────


def test_auth_bearer_fallback():
    ident = extract_identity({AUTH_HEADER: "Bearer sk-test-key-123"})
    assert ident.source == "auth_hash"
    assert ident.session_id.startswith("key-")


def test_auth_bearer_is_deterministic():
    a = extract_identity({AUTH_HEADER: "Bearer sk-key"})
    b = extract_identity({AUTH_HEADER: "Bearer sk-key"})
    assert a.session_id == b.session_id


def test_different_bearer_tokens_distinct_sessions():
    a = extract_identity({AUTH_HEADER: "Bearer sk-key-a"})
    b = extract_identity({AUTH_HEADER: "Bearer sk-key-b"})
    assert a.session_id != b.session_id


def test_auth_non_bearer_scheme_ignored():
    """Basic auth or anything non-Bearer falls through to anonymous."""
    ident = extract_identity({AUTH_HEADER: "Basic dXNlcjpwYXNz"})
    assert ident.source == "anonymous"


def test_raw_key_not_in_session_id():
    """Audit logs must never contain the raw API key — only its hash."""
    raw_key = "sk-supersecret-do-not-leak-12345"
    ident = extract_identity({AUTH_HEADER: f"Bearer {raw_key}"})
    assert raw_key not in ident.session_id


# ─── Anonymous fallback ───────────────────────────────────────────


def test_no_signal_returns_anonymous():
    ident = extract_identity({})
    assert ident.session_id == "anonymous"
    assert ident.source == "anonymous"


def test_empty_session_header_falls_through():
    """An empty/whitespace session header doesn't count — fall through."""
    ident = extract_identity({SESSION_HEADER: "  "})
    assert ident.source == "anonymous"


# ─── Tenant propagation ───────────────────────────────────────────


def test_tenant_propagates_regardless_of_session_source():
    """Tenant_id is independent of how session_id was derived."""
    for headers in [
        {SESSION_HEADER: "s", TENANT_HEADER: "acme"},
        {FORWARDED_HEADER: "1.1.1.1", TENANT_HEADER: "acme"},
        {AUTH_HEADER: "Bearer sk", TENANT_HEADER: "acme"},
    ]:
        assert extract_identity(headers).tenant_id == "acme"
