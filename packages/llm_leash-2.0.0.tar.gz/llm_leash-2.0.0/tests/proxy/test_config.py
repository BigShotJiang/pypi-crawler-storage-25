"""Tests for proxy config loader (PR-2)."""
from __future__ import annotations

import pytest

from llm_leash.proxy.config import (
    DEFAULT_BUDGET_BACKEND,
    DEFAULT_HITL_TIMEOUT_SECS,
    DEFAULT_LISTEN_HOST,
    DEFAULT_LISTEN_PORT,
    ProxyConfig,
    _split_listen,
    from_toml,
    load_config,
    load_toml,
    overlay_env,
)

# ─── Defaults ─────────────────────────────────────────────────────


def test_defaults_match_documented():
    cfg = ProxyConfig()
    assert cfg.listen_host == DEFAULT_LISTEN_HOST
    assert cfg.listen_port == DEFAULT_LISTEN_PORT
    assert cfg.budget.backend == DEFAULT_BUDGET_BACKEND
    assert cfg.hitl.timeout_secs == DEFAULT_HITL_TIMEOUT_SECS


# ─── _split_listen ────────────────────────────────────────────────


def test_split_listen_ok():
    assert _split_listen("127.0.0.1:8000") == ("127.0.0.1", 8000)


def test_split_listen_0000():
    assert _split_listen("0.0.0.0:9999") == ("0.0.0.0", 9999)  # noqa: S104


def test_split_listen_missing_port_errors():
    with pytest.raises(ValueError):
        _split_listen("127.0.0.1")


def test_split_listen_bad_port_errors():
    with pytest.raises(ValueError):
        _split_listen("127.0.0.1:not-an-int")


def test_split_listen_port_out_of_range_errors():
    with pytest.raises(ValueError):
        _split_listen("127.0.0.1:99999")


# ─── from_toml ────────────────────────────────────────────────────


def test_from_toml_empty_returns_defaults():
    cfg = from_toml({})
    assert cfg.listen_host == DEFAULT_LISTEN_HOST
    assert cfg.listen_port == DEFAULT_LISTEN_PORT


def test_from_toml_top_level_keys():
    cfg = from_toml({
        "listen": "10.0.0.1:9090",
        "log_level": "debug",
        "audit_log": "/var/log/audit.jsonl",
        "admin_token": "secret-admin-token",
    })
    assert cfg.listen_host == "10.0.0.1"
    assert cfg.listen_port == 9090
    assert cfg.log_level == "debug"
    assert cfg.audit_log == "/var/log/audit.jsonl"
    assert cfg.admin_token == "secret-admin-token"  # noqa: S105 (test fixture, not a real secret)


def test_from_toml_budget_section():
    cfg = from_toml({
        "budget": {
            "backend": "sqlite",
            "sqlite_path": "/var/lib/budget.db",
            "default_cap_usd": 50.0,
            "per_tenant_caps": {"acme": 200.0, "beta": 10.0},
        }
    })
    assert cfg.budget.backend == "sqlite"
    assert cfg.budget.sqlite_path == "/var/lib/budget.db"
    assert cfg.budget.default_cap_usd == 50.0
    assert cfg.budget.per_tenant_caps == {"acme": 200.0, "beta": 10.0}


def test_from_toml_kill_section():
    cfg = from_toml({"kill": {"backend": "redis", "redis_url": "redis://localhost:6379/0"}})
    assert cfg.kill.backend == "redis"
    assert cfg.kill.redis_url == "redis://localhost:6379/0"


def test_from_toml_hitl_section():
    cfg = from_toml({"hitl": {"backend": "sqlite", "sqlite_path": "/db/hitl.db",
                              "timeout_secs": 120}})
    assert cfg.hitl.backend == "sqlite"
    assert cfg.hitl.sqlite_path == "/db/hitl.db"
    assert cfg.hitl.timeout_secs == 120.0


def test_from_toml_policy_section():
    cfg = from_toml({"policy": {"rules_module": "myco.rules"}})
    assert cfg.policy.rules_module == "myco.rules"


def test_from_toml_unknown_keys_ignored():
    """Forward-compat: future TOML keys must not break the loader."""
    cfg = from_toml({"_future_field": "ignored", "listen": "127.0.0.1:8080"})
    assert cfg.listen_port == 8080


def test_from_toml_malformed_listen_errors():
    with pytest.raises(ValueError):
        from_toml({"listen": "not-host-port"})


# ─── load_toml from disk ──────────────────────────────────────────


def test_load_toml_round_trip(tmp_path):
    p = tmp_path / "proxy.toml"
    p.write_text(
        'listen = "0.0.0.0:8001"\n'
        'log_level = "warning"\n'
        '[budget]\n'
        'backend = "sqlite"\n'
        'default_cap_usd = 25.5\n'
    )
    data = load_toml(p)
    cfg = from_toml(data)
    assert cfg.listen_port == 8001
    assert cfg.log_level == "warning"
    assert cfg.budget.default_cap_usd == 25.5


# ─── overlay_env ──────────────────────────────────────────────────


def test_env_overrides_defaults(tmp_path):
    cfg = ProxyConfig()
    audit_path = str(tmp_path / "audit.jsonl")
    overlay_env(cfg, {
        "LLM_LEASH_PROXY_LISTEN": "0.0.0.0:9000",
        "LLM_LEASH_PROXY_LOG_LEVEL": "debug",
        "LLM_LEASH_PROXY_AUDIT_LOG": audit_path,
        "LLM_LEASH_PROXY_BUDGET_CAP_USD": "12.5",
    })
    assert cfg.listen_host == "0.0.0.0"  # noqa: S104
    assert cfg.listen_port == 9000
    assert cfg.log_level == "debug"
    assert cfg.audit_log == audit_path
    assert cfg.budget.default_cap_usd == 12.5


def test_env_redis_url_propagates_to_both_stores():
    """A single env var should not be set twice. Redis URL applies to whatever
    backends are configured to use Redis."""
    cfg = ProxyConfig()
    overlay_env(cfg, {"LLM_LEASH_PROXY_REDIS_URL": "redis://r:6379/0"})
    assert cfg.budget.redis_url == "redis://r:6379/0"
    assert cfg.kill.redis_url == "redis://r:6379/0"


def test_env_does_not_overwrite_explicit_redis_url():
    """If TOML already specifies a per-store URL, env-fallback shouldn't squash it."""
    cfg = ProxyConfig()
    cfg.budget.redis_url = "redis://specific:6379/9"
    overlay_env(cfg, {"LLM_LEASH_PROXY_REDIS_URL": "redis://default:6379/0"})
    assert cfg.budget.redis_url == "redis://specific:6379/9"


def test_env_empty_dict_is_noop():
    before = ProxyConfig()
    after = overlay_env(ProxyConfig(), {})
    assert after.listen_host == before.listen_host
    assert after.listen_port == before.listen_port


# ─── load_config (top-level) ──────────────────────────────────────


def test_load_config_no_file_no_env_returns_defaults():
    cfg = load_config(config_path=None, env={})
    assert cfg.listen_host == DEFAULT_LISTEN_HOST


def test_load_config_toml_then_env_wins(tmp_path):
    p = tmp_path / "proxy.toml"
    p.write_text('listen = "1.1.1.1:8001"\n')
    cfg = load_config(
        config_path=p,
        env={"LLM_LEASH_PROXY_LISTEN": "2.2.2.2:9002"},
    )
    # Env overlay applied AFTER TOML → env wins.
    assert cfg.listen_host == "2.2.2.2"
    assert cfg.listen_port == 9002
