"""End-to-end tests for Anthropic provider in proxy mode (PR-3).

Uses ``httpx.MockTransport`` to intercept outbound calls to
api.anthropic.com — no real network. Starlette's ``TestClient`` drives
the proxy itself.
"""
from __future__ import annotations

import asyncio
import json

import httpx
import pytest
from starlette.testclient import TestClient

from llm_leash.audit.verify import verify_chain
from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.providers.anthropic import _extract_tokens, _forward_headers
from llm_leash.proxy.server import build_app

# ─── Helpers / fixtures ───────────────────────────────────────────


def _ok_anthropic_response(
    *,
    in_tokens: int = 100,
    out_tokens: int = 50,
    text: str = "ok",
    model: str = "claude-haiku-4-5",
) -> dict:
    return {
        "id": "msg_test",
        "type": "message",
        "role": "assistant",
        "model": model,
        "content": [{"type": "text", "text": text}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": in_tokens, "output_tokens": out_tokens},
    }


class _UpstreamRecorder:
    """Captures the request the proxy forwards to api.anthropic.com."""

    def __init__(self, response: dict | None = None, status: int = 200) -> None:
        self.requests: list[httpx.Request] = []
        self._response_body = response
        self._status = status

    def handler(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        if self._response_body is None:
            body = _ok_anthropic_response()
        else:
            body = self._response_body
        return httpx.Response(self._status, json=body)


def _make_client(
    cfg: ProxyConfig,
    upstream: _UpstreamRecorder,
) -> tuple[TestClient, _UpstreamRecorder]:
    transport = httpx.MockTransport(upstream.handler)

    def factory() -> httpx.AsyncClient:
        return httpx.AsyncClient(transport=transport)

    app = build_app(cfg, http_client_factory=factory)
    return TestClient(app), upstream


@pytest.fixture
def cfg(tmp_path):
    c = ProxyConfig()
    c.audit_log = str(tmp_path / "audit.jsonl")
    return c


# ─── Happy path ───────────────────────────────────────────────────


def test_messages_happy_path_returns_upstream_body(cfg):
    upstream = _UpstreamRecorder(response=_ok_anthropic_response(text="hi there"))
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post(
            "/v1/messages",
            json={
                "model": "claude-haiku-4-5",
                "max_tokens": 100,
                "messages": [{"role": "user", "content": "hi"}],
            },
        )
    assert resp.status_code == 200
    body = resp.json()
    assert body["content"][0]["text"] == "hi there"


def test_messages_forwards_to_anthropic(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        client.post(
            "/v1/messages",
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 50,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    assert len(upstream.requests) == 1
    req = upstream.requests[0]
    assert str(req.url) == "https://api.anthropic.com/v1/messages"
    assert req.method == "POST"


def test_messages_charges_budget(cfg):
    upstream = _UpstreamRecorder(response=_ok_anthropic_response(in_tokens=1000, out_tokens=500))
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/messages",
            headers={"x-llm-leash-session-id": "test-session"},
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 100,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
        state = client.app.state.llm_leash
        cumulative = asyncio.run(state.budget_store.get("test-session"))
    # claude-haiku-4-5: $0.80/M in + $4.00/M out → 0.0008 + 0.002 = 0.0028
    assert abs(cumulative - 0.0028) < 1e-9


def test_messages_writes_audit_entry(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/messages",
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 100,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    lines = open(cfg.audit_log).read().strip().splitlines()
    assert len(lines) == 1
    event = json.loads(lines[0])
    assert event["kind"] == "model_call"
    assert event["provider"] == "anthropic"
    assert event["model"] == "claude-haiku-4-5"
    assert event["input_tokens"] == 100
    assert event["output_tokens"] == 50


def test_messages_audit_chain_verifies(cfg):
    """End-to-end: chain produced by the proxy passes `verify_chain`."""
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        for _ in range(3):
            client.post(
                "/v1/messages",
                json={

                    "model": "claude-haiku-4-5",

                    "max_tokens": 50,

                    "messages": [{"role": "user", "content": "x"}],

                },
            )
    assert verify_chain(cfg.audit_log) == 3


# ─── Identity propagation ─────────────────────────────────────────


def test_explicit_session_header_drives_session_id(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/messages",
            headers={"x-llm-leash-session-id": "my-session"},
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 50,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    line = open(cfg.audit_log).read().strip().splitlines()[0]
    event = json.loads(line)
    assert event["session_id"] == "my-session"


def test_tenant_header_propagated_to_audit(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/messages",
            headers={
                "x-llm-leash-session-id": "s1",
                "x-llm-leash-tenant-id": "acme",
            },
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 50,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    event = json.loads(open(cfg.audit_log).read().strip().splitlines()[0])
    assert event["tenant_id"] == "acme"


def test_proxy_internal_headers_not_forwarded(cfg):
    """X-LLM-Leash-* are proxy-internal and must never reach upstream."""
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/messages",
            headers={
                "x-llm-leash-session-id": "s1",
                "x-llm-leash-tenant-id": "acme",
                "x-llm-leash-upstream": "https://api.anthropic.com",
            },
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 50,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    req = upstream.requests[0]
    for h in ("x-llm-leash-session-id", "x-llm-leash-tenant-id", "x-llm-leash-upstream"):
        assert h not in {k.lower() for k in req.headers}


def test_authorization_header_forwarded(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        client.post(
            "/v1/messages",
            headers={"authorization": "Bearer sk-test-key-xyz"},
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 50,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    assert upstream.requests[0].headers.get("authorization") == "Bearer sk-test-key-xyz"


# ─── Bad request ──────────────────────────────────────────────────


def test_missing_model_returns_400(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post("/v1/messages", json={"messages": []})
    assert resp.status_code == 400
    assert resp.json()["error"]["type"] == "invalid_request"


def test_invalid_json_body_returns_400(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post(
            "/v1/messages",
            content="not valid json",
            headers={"content-type": "application/json"},
        )
    assert resp.status_code == 400


# ─── Kill switch ──────────────────────────────────────────────────


def test_killed_session_returns_402(cfg):
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        state = client.app.state.llm_leash
        asyncio.run(state.kill.kill("killed-sess", reason="manual abort"))

        resp = client.post(
            "/v1/messages",
            headers={"x-llm-leash-session-id": "killed-sess"},
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 50,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    assert resp.status_code == 402
    body = resp.json()
    assert body["error"]["type"] == "leash_killed"
    assert body["error"]["code"] == "session_killed"
    # Upstream should never have been hit.
    assert upstream.requests == []


# ─── Budget cap ────────────────────────────────────────────────────


def test_budget_cap_pre_call_estimate_returns_402(cfg):
    """A `max_tokens` so large that the estimated cost alone exceeds the
    per-session cap should refuse BEFORE hitting upstream."""
    cfg.budget.default_cap_usd = 0.001  # one tenth of a cent
    upstream = _UpstreamRecorder()
    client, _ = _make_client(cfg, upstream)
    with client:
        resp = client.post(
            "/v1/messages",
            json={
                "model": "claude-opus-4-7",   # $15/M input
                "max_tokens": 10_000_000,     # 10M tokens → ~$150 estimate
                "messages": [{"role": "user", "content": "x"}],
            },
        )
    assert resp.status_code == 402
    body = resp.json()
    assert body["error"]["code"] == "budget_exceeded"
    assert body["error"]["rule_id"] == "budget:pre_call_estimate"
    assert upstream.requests == []


def test_no_cap_allows_call(cfg):
    """default_cap_usd=None → never refuses on budget."""
    cfg.budget.default_cap_usd = None
    upstream = _UpstreamRecorder(
        response=_ok_anthropic_response(in_tokens=1_000_000, out_tokens=1_000_000),
    )
    client, _ = _make_client(cfg, upstream)
    with client:
        resp = client.post(
            "/v1/messages",
            json={
                "model": "claude-opus-4-7",
                "max_tokens": 1_000_000,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
    assert resp.status_code == 200


# ─── Upstream errors ──────────────────────────────────────────────


def test_upstream_4xx_passes_through(cfg):
    """Provider's own auth/quota errors must reach the client unchanged."""
    upstream = _UpstreamRecorder(
        response={"type": "error", "error": {"type": "invalid_api_key", "message": "bad key"}},
        status=401,
    )
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post(
            "/v1/messages",
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 50,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    assert resp.status_code == 401
    assert resp.json()["error"]["type"] == "invalid_api_key"


def test_upstream_5xx_passes_through(cfg):
    upstream = _UpstreamRecorder(
        response={"error": {"message": "service unavailable"}},
        status=503,
    )
    with _make_client(cfg, upstream)[0] as client:
        resp = client.post(
            "/v1/messages",
            json={

                "model": "claude-haiku-4-5",

                "max_tokens": 50,

                "messages": [{"role": "user", "content": "x"}],

            },
        )
    assert resp.status_code == 503


# ─── Helper units ─────────────────────────────────────────────────


def test_extract_tokens_present():
    body = {"usage": {"input_tokens": 11, "output_tokens": 22}}
    assert _extract_tokens(body) == (11, 22)


def test_extract_tokens_missing():
    assert _extract_tokens({}) == (0, 0)


def test_forward_headers_drops_internal_and_hop_by_hop():
    from starlette.datastructures import Headers
    h = Headers({
        "host": "localhost",
        "authorization": "Bearer x",
        "content-length": "10",
        "anthropic-version": "2023-06-01",
        "x-llm-leash-session-id": "s",
    })
    # Build a minimal Request mock
    class _Req:
        headers = h
    out = _forward_headers(_Req())
    assert "host" not in out
    assert "content-length" not in out
    assert "x-llm-leash-session-id" not in out
    assert out["authorization"] == "Bearer x"
    assert out["anthropic-version"] == "2023-06-01"


# ─── /v1/messages requires POST ───────────────────────────────────


def test_messages_get_returns_405(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        resp = client.get("/v1/messages")
    assert resp.status_code == 405


# ─── Root endpoint advertises new route ───────────────────────────


def test_root_lists_v1_messages(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream)[0] as client:
        body = client.get("/").json()
    assert "/v1/messages" in body["endpoints"]
