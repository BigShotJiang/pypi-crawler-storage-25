"""Tests for PR-5': agent_name field + policy/PII wiring from config."""
from __future__ import annotations

import asyncio
import json
import sys
import textwrap
from types import ModuleType

import httpx
import pytest
from starlette.testclient import TestClient

from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.identity import AGENT_HEADER, extract_identity
from llm_leash.proxy.server import build_app
from llm_leash.proxy.state import ProxyState

# ─── Helpers ───────────────────────────────────────────────────────


def _ok_anthropic_response(in_t: int = 10, out_t: int = 5) -> dict:
    return {
        "id": "msg_x", "type": "message", "role": "assistant",
        "model": "claude-haiku-4-5",
        "content": [{"type": "text", "text": "ok"}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": in_t, "output_tokens": out_t},
    }


def _ok_openai_response(in_t: int = 10, out_t: int = 5) -> dict:
    return {
        "id": "chatcmpl-x", "object": "chat.completion",
        "created": 1700000000, "model": "gpt-4o",
        "choices": [{
            "index": 0, "finish_reason": "stop",
            "message": {"role": "assistant", "content": "ok"},
        }],
        "usage": {"prompt_tokens": in_t, "completion_tokens": out_t,
                  "total_tokens": in_t + out_t},
    }


class _UpstreamRecorder:
    def __init__(self) -> None:
        self.requests: list[httpx.Request] = []

    def handler(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        if "messages" in str(request.url) and "chat" not in str(request.url):
            return httpx.Response(200, json=_ok_anthropic_response())
        return httpx.Response(200, json=_ok_openai_response())


def _make_client(cfg: ProxyConfig, upstream: _UpstreamRecorder) -> TestClient:
    transport = httpx.MockTransport(upstream.handler)

    def factory() -> httpx.AsyncClient:
        return httpx.AsyncClient(transport=transport)

    return TestClient(build_app(cfg, http_client_factory=factory))


@pytest.fixture
def cfg(tmp_path):
    c = ProxyConfig()
    c.audit_log = str(tmp_path / "audit.jsonl")
    return c


# ─── Identity: agent_name extraction ───────────────────────────────


def test_extract_identity_agent_name_from_header():
    ident = extract_identity({
        "x-llm-leash-session-id": "s1",
        AGENT_HEADER: "analyst",
    })
    assert ident.agent_name == "analyst"


def test_extract_identity_agent_name_independent_of_session_source():
    """agent_name is captured regardless of how session_id was derived."""
    for headers in [
        {"x-llm-leash-session-id": "s", AGENT_HEADER: "devops"},
        {"x-forwarded-for": "1.1.1.1", AGENT_HEADER: "devops"},
        {"authorization": "Bearer sk-x", AGENT_HEADER: "devops"},
    ]:
        assert extract_identity(headers).agent_name == "devops"


def test_extract_identity_agent_name_none_when_absent():
    ident = extract_identity({"x-llm-leash-session-id": "s1"})
    assert ident.agent_name is None


def test_extract_identity_agent_header_case_insensitive():
    ident = extract_identity({
        "x-llm-leash-session-id": "s1",
        "X-LLM-Leash-Agent-Name": "ANALYST",
    })
    assert ident.agent_name == "ANALYST"


def test_extract_identity_empty_agent_name_treated_as_absent():
    ident = extract_identity({
        "x-llm-leash-session-id": "s1",
        AGENT_HEADER: "  ",
    })
    assert ident.agent_name is None


# ─── Schema: agent_name in audit events ────────────────────────────


def test_anthropic_audit_includes_agent_name(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        client.post(
            "/v1/messages",
            headers={AGENT_HEADER: "analyst"},
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
    event = json.loads(open(cfg.audit_log).read().strip().splitlines()[0])
    assert event["agent_name"] == "analyst"


def test_openai_audit_includes_agent_name(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        client.post(
            "/v1/chat/completions",
            headers={AGENT_HEADER: "devops"},
            json={
                "model": "gpt-4o", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
    event = json.loads(open(cfg.audit_log).read().strip().splitlines()[0])
    assert event["agent_name"] == "devops"


def test_audit_agent_name_null_when_header_absent(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        client.post(
            "/v1/messages",
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
            },
        )
    event = json.loads(open(cfg.audit_log).read().strip().splitlines()[0])
    assert event["agent_name"] is None


def test_per_agent_audit_distinguishable(cfg):
    """Multiple agents in the same session can be told apart in audit."""
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        for agent in ["analyst", "architect", "devops"]:
            client.post(
                "/v1/messages",
                headers={
                    "x-llm-leash-session-id": "minctrl-run-1",
                    AGENT_HEADER: agent,
                },
                json={
                    "model": "claude-haiku-4-5", "max_tokens": 50,
                    "messages": [{"role": "user", "content": "x"}],
                },
            )
    lines = open(cfg.audit_log).read().strip().splitlines()
    agents = [json.loads(line)["agent_name"] for line in lines]
    assert agents == ["analyst", "architect", "devops"]
    # All share the same session_id but have distinct agent_name.
    sessions = {json.loads(line)["session_id"] for line in lines}
    assert sessions == {"minctrl-run-1"}


# ─── Audit chain backwards compat ──────────────────────────────────


def test_chain_with_agent_name_field_still_verifies(cfg):
    """Adding agent_name to the schema must not break verify_chain on
    a chain that was written WITH the new field."""
    from llm_leash.audit.verify import verify_chain
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        for _ in range(3):
            client.post(
                "/v1/messages",
                headers={AGENT_HEADER: "analyst"},
                json={
                    "model": "claude-haiku-4-5", "max_tokens": 50,
                    "messages": [{"role": "user", "content": "x"}],
                },
            )
    assert verify_chain(cfg.audit_log) == 3


# ─── Policy: rules_module loading ──────────────────────────────────


def _install_fake_module(name: str, body: str) -> None:
    """Inject a Python module into sys.modules for the duration of the test."""
    mod = ModuleType(name)
    exec(textwrap.dedent(body), mod.__dict__)  # noqa: S102 (test fixture)
    sys.modules[name] = mod


def test_state_loads_rules_from_dotted_path(tmp_path):
    _install_fake_module("_fake_rules_pr5", """
        from llm_leash import BlockedShell
        rules = [BlockedShell()]
    """)
    cfg = ProxyConfig()
    cfg.audit_log = str(tmp_path / "audit.jsonl")
    cfg.policy.rules_module = "_fake_rules_pr5"
    state = ProxyState.from_config(cfg)
    assert len(state.engine.rules) == 1
    assert state.engine.rules[0].id == "blocked_shell"


def test_state_no_rules_module_means_empty_engine(tmp_path):
    cfg = ProxyConfig()
    cfg.audit_log = str(tmp_path / "audit.jsonl")
    state = ProxyState.from_config(cfg)
    assert state.engine.rules == []


def test_state_rules_module_missing_rules_attr_errors(tmp_path):
    _install_fake_module("_fake_no_rules_attr", "# nothing here")
    cfg = ProxyConfig()
    cfg.audit_log = str(tmp_path / "audit.jsonl")
    cfg.policy.rules_module = "_fake_no_rules_attr"
    with pytest.raises(ValueError, match="must define a module-level 'rules'"):
        ProxyState.from_config(cfg)


def test_state_rules_module_wrong_type_errors(tmp_path):
    _install_fake_module("_fake_rules_wrong_type", "rules = 'not a list'")
    cfg = ProxyConfig()
    cfg.audit_log = str(tmp_path / "audit.jsonl")
    cfg.policy.rules_module = "_fake_rules_wrong_type"
    with pytest.raises(ValueError, match="must be a list"):
        ProxyState.from_config(cfg)


# ─── Policy: rules actually fire in proxy ──────────────────────────


def test_anthropic_blocks_via_loaded_rules(cfg):
    """Rules loaded from rules_module actually fire in the request path."""
    _install_fake_module("_fake_rules_block", """
        from llm_leash import BlockedShell
        rules = [BlockedShell()]
    """)
    cfg.policy.rules_module = "_fake_rules_block"
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        resp = client.post(
            "/v1/messages",
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "please run: rm -rf /"}],
            },
        )
    assert resp.status_code == 403
    assert resp.json()["error"]["type"] == "leash_blocked"
    assert upstream.requests == []


def test_openai_blocks_via_loaded_rules(cfg):
    _install_fake_module("_fake_rules_block_oai", """
        from llm_leash import BlockedPatterns
        rules = [BlockedPatterns([r'\\bDROP\\s+TABLE\\b'])]
    """)
    cfg.policy.rules_module = "_fake_rules_block_oai"
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        resp = client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o", "max_tokens": 50,
                "messages": [{"role": "user", "content": "DROP TABLE users"}],
            },
        )
    assert resp.status_code == 403
    assert upstream.requests == []


# ─── PII redaction wiring ──────────────────────────────────────────


def test_pii_redactor_disabled_by_default(cfg):
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        client.post(
            "/v1/messages",
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "email user@corp.io"}],
            },
        )
    # Without redactor, raw email reaches upstream.
    forwarded = upstream.requests[0].content.decode()
    assert "user@corp.io" in forwarded


def test_pii_redactor_enabled_scrubs_outgoing_anthropic(cfg):
    cfg.policy.pii_redactor = True
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        client.post(
            "/v1/messages",
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "email me at user@corp.io"}],
            },
        )
    forwarded = upstream.requests[0].content.decode()
    assert "user@corp.io" not in forwarded
    assert "[REDACTED:EMAIL]" in forwarded


def test_pii_redactor_enabled_scrubs_outgoing_openai(cfg):
    cfg.policy.pii_redactor = True
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o", "max_tokens": 50,
                "messages": [{"role": "user", "content": "my email user@corp.io"}],
            },
        )
    forwarded = upstream.requests[0].content.decode()
    assert "user@corp.io" not in forwarded


def test_state_pii_redactor_none_by_default():
    cfg = ProxyConfig()
    state = ProxyState.from_config(cfg)
    assert state.pii_redactor is None


def test_state_pii_redactor_installed_when_enabled():
    cfg = ProxyConfig()
    cfg.policy.pii_redactor = True
    state = ProxyState.from_config(cfg)
    assert state.pii_redactor is not None


# ─── Config TOML round-trip ────────────────────────────────────────


def test_toml_policy_pii_redactor_loaded(tmp_path):
    from llm_leash.proxy.config import from_toml
    cfg = from_toml({
        "policy": {
            "rules_module": "my_org.rules",
            "pii_redactor": True,
        },
    })
    assert cfg.policy.rules_module == "my_org.rules"
    assert cfg.policy.pii_redactor is True


# ─── Per-agent budget cap (via tenant_caps-like extension) ─────────


def test_agent_name_does_not_break_session_isolation(cfg):
    """Multiple agents in same session share the same BudgetTracker; the
    cap is enforced at session level (not per agent for now). agent_name
    is purely identifying — per-agent caps land in a future PR if needed."""
    cfg.budget.default_cap_usd = 100.0  # generous
    upstream = _UpstreamRecorder()
    with _make_client(cfg, upstream) as client:
        for agent in ["a", "b", "c"]:
            client.post(
                "/v1/messages",
                headers={
                    "x-llm-leash-session-id": "shared",
                    AGENT_HEADER: agent,
                },
                json={
                    "model": "claude-haiku-4-5", "max_tokens": 50,
                    "messages": [{"role": "user", "content": "x"}],
                },
            )
        state = client.app.state.llm_leash
        spent = asyncio.run(state.budget_store.get("shared"))
    # Three calls at ~$0.000048 each = tiny but nonzero
    assert spent > 0
