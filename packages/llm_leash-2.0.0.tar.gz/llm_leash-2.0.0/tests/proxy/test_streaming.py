"""Tests for SSE streaming in the proxy (PR-7').

Two layers:
  - SSE parser + token accumulator unit tests (no HTTP)
  - End-to-end streaming through the proxy with mocked upstream
    streaming response
"""
from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator

import httpx
import pytest

from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.server import build_app
from llm_leash.proxy.state import ProxyState
from llm_leash.proxy.streaming import (
    AnthropicTokenAccumulator,
    OpenAITokenAccumulator,
    SSEEvent,
    SSEParser,
)

# ─── SSE parser ──────────────────────────────────────────────────────


def test_parser_single_event():
    p = SSEParser()
    events = p.feed(b"event: foo\ndata: {\"x\":1}\n\n")
    assert len(events) == 1
    assert events[0].event == "foo"
    assert events[0].data == '{"x":1}'


def test_parser_data_only_no_event_field():
    """OpenAI uses data-only frames."""
    p = SSEParser()
    events = p.feed(b'data: {"x":1}\n\n')
    assert len(events) == 1
    assert events[0].event is None
    assert events[0].data == '{"x":1}'


def test_parser_multiple_events_one_feed():
    p = SSEParser()
    raw = b'data: {"a":1}\n\ndata: {"b":2}\n\n'
    events = p.feed(raw)
    assert len(events) == 2
    assert events[0].data == '{"a":1}'
    assert events[1].data == '{"b":2}'


def test_parser_split_across_chunks():
    """An event split across two `feed` calls reassembles correctly."""
    p = SSEParser()
    e1 = p.feed(b'data: {"x":1')
    e2 = p.feed(b"}\n\n")
    assert e1 == []
    assert len(e2) == 1
    assert e2[0].data == '{"x":1}'


def test_parser_chunk_with_trailing_partial():
    """One complete event followed by partial. Partial held until next feed."""
    p = SSEParser()
    e1 = p.feed(b"data: A\n\ndata: B")
    e2 = p.feed(b"\n\n")
    assert len(e1) == 1
    assert e1[0].data == "A"
    assert len(e2) == 1
    assert e2[0].data == "B"


def test_parser_crlf_line_endings():
    """SSE spec allows CRLF; we handle both."""
    p = SSEParser()
    events = p.feed(b"data: hello\r\n\r\n")
    assert len(events) == 1
    assert events[0].data == "hello"


def test_parser_multi_line_data_concatenated():
    """Multiple data: lines in one event are joined by newlines."""
    p = SSEParser()
    events = p.feed(b"data: line1\ndata: line2\n\n")
    assert events[0].data == "line1\nline2"


def test_parser_comment_lines_ignored():
    p = SSEParser()
    events = p.feed(b": this is a comment\ndata: real\n\n")
    assert len(events) == 1
    assert events[0].data == "real"


def test_parser_drain_returns_trailing_incomplete():
    p = SSEParser()
    p.feed(b"data: trailing")
    drained = p.drain()
    assert len(drained) == 1
    assert drained[0].data == "trailing"


def test_parser_drain_skips_whitespace_only_buffer():
    p = SSEParser()
    p.feed(b"data: full\n\n  \n")  # only whitespace after complete event
    drained = p.drain()
    assert drained == []


def test_parser_optional_leading_space_in_value():
    """SSE spec: a single leading space after the colon is stripped."""
    p = SSEParser()
    events = p.feed(b"data:no_space\n\ndata: with_space\n\n")
    assert events[0].data == "no_space"
    assert events[1].data == "with_space"


# ─── Anthropic accumulator ──────────────────────────────────────────


def test_anthropic_input_tokens_from_message_start():
    acc = AnthropicTokenAccumulator()
    acc.feed_event(SSEEvent(event="message_start", data=json.dumps({
        "type": "message_start",
        "message": {"usage": {"input_tokens": 100, "output_tokens": 1}},
    })))
    assert acc.input_tokens == 100
    assert acc.output_tokens == 0


def test_anthropic_output_tokens_from_message_delta():
    acc = AnthropicTokenAccumulator()
    acc.feed_event(SSEEvent(event="message_delta", data=json.dumps({
        "type": "message_delta",
        "usage": {"output_tokens": 42},
    })))
    assert acc.output_tokens == 42


def test_anthropic_output_tokens_use_latest_delta():
    """Anthropic's output_tokens in message_delta is cumulative."""
    acc = AnthropicTokenAccumulator()
    for n in [5, 15, 42]:
        acc.feed_event(SSEEvent(event="message_delta", data=json.dumps({
            "type": "message_delta",
            "usage": {"output_tokens": n},
        })))
    assert acc.output_tokens == 42


def test_anthropic_message_stop_marks_finished():
    acc = AnthropicTokenAccumulator()
    acc.feed_event(SSEEvent(event="message_stop", data=json.dumps({
        "type": "message_stop",
    })))
    assert acc.finished is True


def test_anthropic_ignores_unknown_event_types():
    acc = AnthropicTokenAccumulator()
    acc.feed_event(SSEEvent(event="ping", data='{"type":"ping"}'))
    assert acc.input_tokens == 0
    assert acc.finished is False


def test_anthropic_ignores_invalid_json():
    acc = AnthropicTokenAccumulator()
    acc.feed_event(SSEEvent(event="x", data="not json"))
    # Should not raise.
    assert acc.input_tokens == 0


# ─── OpenAI accumulator ─────────────────────────────────────────────


def test_openai_usage_from_final_chunk():
    """OpenAI includes usage in the final chunk before [DONE]."""
    acc = OpenAITokenAccumulator()
    acc.feed_event(SSEEvent(data=json.dumps({
        "choices": [{"delta": {"content": "hi"}}],
    })))
    assert acc.output_tokens == 0
    acc.feed_event(SSEEvent(data=json.dumps({
        "usage": {"prompt_tokens": 10, "completion_tokens": 5},
    })))
    assert acc.input_tokens == 10
    assert acc.output_tokens == 5


def test_openai_done_sentinel_marks_finished():
    acc = OpenAITokenAccumulator()
    acc.feed_event(SSEEvent(data="[DONE]"))
    assert acc.finished is True


def test_openai_ignores_chunks_without_usage():
    acc = OpenAITokenAccumulator()
    for _ in range(10):
        acc.feed_event(SSEEvent(data=json.dumps({
            "choices": [{"delta": {"content": "tok"}}],
        })))
    assert acc.input_tokens == 0
    assert acc.output_tokens == 0


# ─── End-to-end Anthropic streaming ──────────────────────────────────


def _anthropic_stream_chunks(in_t: int = 100, out_t: int = 50) -> list[bytes]:
    """Produce a realistic Anthropic SSE byte stream."""
    return [
        b"event: message_start\n"
        b"data: " + json.dumps({
            "type": "message_start",
            "message": {
                "id": "msg_x", "role": "assistant", "model": "claude-haiku-4-5",
                "content": [],
                "usage": {"input_tokens": in_t, "output_tokens": 1},
            },
        }).encode() + b"\n\n",

        b"event: content_block_start\n"
        b'data: {"type":"content_block_start","index":0,"content_block":'
        b'{"type":"text","text":""}}\n\n',

        b"event: content_block_delta\n"
        b'data: {"type":"content_block_delta","index":0,'
        b'"delta":{"type":"text_delta","text":"Hello "}}\n\n',

        b"event: content_block_delta\n"
        b'data: {"type":"content_block_delta","index":0,'
        b'"delta":{"type":"text_delta","text":"world"}}\n\n',

        b"event: content_block_stop\n"
        b'data: {"type":"content_block_stop","index":0}\n\n',

        b"event: message_delta\n"
        b"data: " + json.dumps({
            "type": "message_delta",
            "delta": {"stop_reason": "end_turn"},
            "usage": {"output_tokens": out_t},
        }).encode() + b"\n\n",

        b"event: message_stop\n"
        b'data: {"type":"message_stop"}\n\n',
    ]


def _build_streaming_upstream(chunks: list[bytes]) -> httpx.MockTransport:
    async def stream_body() -> AsyncIterator[bytes]:
        for c in chunks:
            yield c

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            content=stream_body(),
            headers={"content-type": "text/event-stream"},
        )

    return httpx.MockTransport(handler)


def _build_app(cfg: ProxyConfig, transport: httpx.MockTransport):
    state = ProxyState.from_config(cfg)
    state.http_client = httpx.AsyncClient(transport=transport)
    return build_app(cfg, state=state), state


@pytest.fixture
def cfg(tmp_path):
    c = ProxyConfig()
    c.audit_log = str(tmp_path / "audit.jsonl")
    return c


@pytest.mark.asyncio
async def test_anthropic_stream_passes_through_chunks(cfg):
    """Client receives the same SSE bytes the upstream sent."""
    chunks = _anthropic_stream_chunks()
    transport = _build_streaming_upstream(chunks)
    app, _ = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        async with ac.stream(
            "POST", "/v1/messages",
            json={
                "model": "claude-haiku-4-5",
                "max_tokens": 100,
                "stream": True,
                "messages": [{"role": "user", "content": "hi"}],
            },
        ) as resp:
            assert resp.status_code == 200
            assert "text/event-stream" in resp.headers["content-type"]
            body = b""
            async for chunk in resp.aiter_raw():
                body += chunk
    # The reassembled body should contain all the deltas and the
    # message_stop event.
    assert b"Hello " in body
    assert b"world" in body
    assert b"message_stop" in body


@pytest.mark.asyncio
async def test_anthropic_stream_charges_at_end(cfg):
    """After the stream completes, tokens are charged + audit written."""
    chunks = _anthropic_stream_chunks(in_t=200, out_t=80)
    transport = _build_streaming_upstream(chunks)
    app, state = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        async with ac.stream(
            "POST", "/v1/messages",
            headers={"x-llm-leash-session-id": "stream-sess"},
            json={
                "model": "claude-haiku-4-5",
                "max_tokens": 100,
                "stream": True,
                "messages": [{"role": "user", "content": "hi"}],
            },
        ) as resp:
            async for _ in resp.aiter_raw():
                pass
        # Allow any pending finally-block coroutines to settle.
        await asyncio.sleep(0.01)

    cumulative = await state.budget_store.get("stream-sess")
    # claude-haiku-4-5: $0.80/M in + $4.00/M out
    # 200/M * 0.8 + 80/M * 4 = 0.00016 + 0.00032 = 0.00048
    assert abs(cumulative - 0.00048) < 1e-9

    def _read_audit() -> list[str]:
        with open(cfg.audit_log) as f:
            return f.read().strip().splitlines()

    audit_lines = await asyncio.to_thread(_read_audit)
    assert len(audit_lines) == 1
    event = json.loads(audit_lines[0])
    assert event["kind"] == "model_call"
    assert event["input_tokens"] == 200
    assert event["output_tokens"] == 80
    assert event["response_hash"] == "streaming"


# ─── End-to-end OpenAI streaming ────────────────────────────────────


def _openai_stream_chunks(prompt_tokens: int = 10, completion_tokens: int = 5):
    return [
        b'data: {"id":"x","object":"chat.completion.chunk",'
        b'"choices":[{"index":0,"delta":{"role":"assistant"}}]}\n\n',
        b'data: {"choices":[{"index":0,"delta":{"content":"Hello"}}]}\n\n',
        b'data: {"choices":[{"index":0,"delta":{"content":" world"}}]}\n\n',
        b'data: {"choices":[{"index":0,"finish_reason":"stop","delta":{}}]}\n\n',
        b"data: " + json.dumps({
            "usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            },
        }).encode() + b"\n\n",
        b"data: [DONE]\n\n",
    ]


@pytest.mark.asyncio
async def test_openai_stream_charges_at_end(cfg):
    chunks = _openai_stream_chunks(prompt_tokens=1000, completion_tokens=500)
    captured: list[bytes] = []

    async def stream_body():
        for c in chunks:
            yield c

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request.content)
        return httpx.Response(
            200,
            content=stream_body(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)
    app, state = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        async with ac.stream(
            "POST", "/v1/chat/completions",
            headers={"x-llm-leash-session-id": "oai-stream"},
            json={
                "model": "gpt-4o",
                "max_tokens": 100,
                "stream": True,
                "messages": [{"role": "user", "content": "hi"}],
            },
        ) as resp:
            async for _ in resp.aiter_raw():
                pass
        await asyncio.sleep(0.01)

    cumulative = await state.budget_store.get("oai-stream")
    # gpt-4o: 1000 * 2.5/M + 500 * 10/M = 0.0025 + 0.005 = 0.0075
    assert abs(cumulative - 0.0075) < 1e-9


@pytest.mark.asyncio
async def test_openai_stream_auto_injects_include_usage(cfg):
    """Proxy must inject stream_options.include_usage=true so OpenAI returns
    usage data in the final chunk."""
    chunks = _openai_stream_chunks()
    captured_body: list[dict] = []

    async def stream_body():
        for c in chunks:
            yield c

    def handler(request: httpx.Request) -> httpx.Response:
        captured_body.append(json.loads(request.content))
        return httpx.Response(
            200, content=stream_body(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)
    app, _ = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        async with ac.stream(
            "POST", "/v1/chat/completions",
            json={
                "model": "gpt-4o",
                "max_tokens": 100,
                "stream": True,
                "messages": [{"role": "user", "content": "hi"}],
                # Caller did NOT set stream_options; proxy should inject.
            },
        ) as resp:
            async for _ in resp.aiter_raw():
                pass

    forwarded = captured_body[0]
    assert forwarded["stream"] is True
    assert forwarded["stream_options"]["include_usage"] is True


@pytest.mark.asyncio
async def test_openai_stream_preserves_user_stream_options(cfg):
    """If caller already sets stream_options, only `include_usage` gets a default."""
    chunks = _openai_stream_chunks()
    captured_body: list[dict] = []

    async def stream_body():
        for c in chunks:
            yield c

    def handler(request: httpx.Request) -> httpx.Response:
        captured_body.append(json.loads(request.content))
        return httpx.Response(
            200, content=stream_body(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)
    app, _ = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        async with ac.stream(
            "POST", "/v1/chat/completions",
            json={
                "model": "gpt-4o",
                "stream": True,
                "stream_options": {"include_usage": False, "custom": "x"},
                "messages": [{"role": "user", "content": "hi"}],
            },
        ) as resp:
            async for _ in resp.aiter_raw():
                pass

    so = captured_body[0]["stream_options"]
    # User's explicit `include_usage=false` is preserved (setdefault doesn't override).
    assert so["include_usage"] is False
    assert so["custom"] == "x"


# ─── Non-streaming path still works after the streaming branch ──────


@pytest.mark.asyncio
async def test_non_streaming_anthropic_still_works(cfg):
    """Confirm the streaming branch addition doesn't regress non-streaming."""
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={
            "id": "m", "type": "message", "role": "assistant",
            "model": "claude-haiku-4-5",
            "content": [{"type": "text", "text": "ok"}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 10, "output_tokens": 5},
        })

    transport = httpx.MockTransport(handler)
    app, _ = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        resp = await ac.post(
            "/v1/messages",
            json={
                "model": "claude-haiku-4-5", "max_tokens": 50,
                "messages": [{"role": "user", "content": "x"}],
                # No stream=true → non-streaming path.
            },
        )
    assert resp.status_code == 200
    assert resp.json()["content"][0]["text"] == "ok"


# ─── GA-2: Mid-stream cancellation when cumulative > hard_cap ───────


def _anthropic_runaway_chunks() -> list[bytes]:
    """Stream that escalates output_tokens fast — designed to blow a tiny cap."""
    return [
        b"event: message_start\n"
        b"data: " + json.dumps({
            "type": "message_start",
            "message": {
                "id": "msg_x", "role": "assistant", "model": "claude-haiku-4-5",
                "content": [],
                "usage": {"input_tokens": 100, "output_tokens": 1},
            },
        }).encode() + b"\n\n",

        b"event: content_block_delta\n"
        b'data: {"type":"content_block_delta","index":0,'
        b'"delta":{"type":"text_delta","text":"warm-up"}}\n\n',

        # Spike — output jumps to 10M tokens (way over any reasonable cap).
        b"event: message_delta\n"
        b'data: {"type":"message_delta","delta":{"stop_reason":null},'
        b'"usage":{"output_tokens":10000000}}\n\n',

        # This should never reach the client — connection should be cancelled.
        b"event: content_block_delta\n"
        b'data: {"type":"content_block_delta","index":0,'
        b'"delta":{"type":"text_delta","text":"SHOULD_NOT_REACH"}}\n\n',

        b"event: message_stop\n"
        b'data: {"type":"message_stop"}\n\n',
    ]


@pytest.mark.asyncio
async def test_anthropic_mid_stream_cancel_on_hard_cap(cfg):
    """When the cumulative-cost projection blows the cap mid-stream, the proxy
    must inject a synthetic `event: error` frame + `message_stop`, then stop.
    Bytes after the cancel point must NOT reach the client."""
    cfg.budget.default_cap_usd = 1.0  # $1 cap
    chunks = _anthropic_runaway_chunks()
    transport = _build_streaming_upstream(chunks)
    app, state = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        async with ac.stream(
            "POST", "/v1/messages",
            headers={"x-llm-leash-session-id": "runaway-sess"},
            json={
                "model": "claude-haiku-4-5",
                "max_tokens": 100,  # tiny estimate so pre-call doesn't block
                "stream": True,
                "messages": [{"role": "user", "content": "hi"}],
            },
        ) as resp:
            assert resp.status_code == 200
            body = b""
            async for chunk in resp.aiter_raw():
                body += chunk
        await asyncio.sleep(0.01)

    # Synthetic error + message_stop injected.
    assert b"budget:mid_stream" in body
    assert b"leash_killed" in body
    # The "after the cancel" delta must NOT have been forwarded.
    assert b"SHOULD_NOT_REACH" not in body
    # State was still charged what we observed (10M output tokens worth).
    cumulative = await state.budget_store.get("runaway-sess")
    assert cumulative > 1.0  # blew the cap


@pytest.mark.asyncio
async def test_anthropic_under_cap_runs_to_completion(cfg):
    """Sanity check: small streams under the cap aren't cancelled."""
    cfg.budget.default_cap_usd = 1.0
    chunks = _anthropic_stream_chunks(in_t=100, out_t=50)
    transport = _build_streaming_upstream(chunks)
    app, _ = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        async with ac.stream(
            "POST", "/v1/messages",
            json={
                "model": "claude-haiku-4-5", "max_tokens": 100,
                "stream": True,
                "messages": [{"role": "user", "content": "hi"}],
            },
        ) as resp:
            body = b""
            async for chunk in resp.aiter_raw():
                body += chunk
    # No synthetic error event; real upstream ran to completion.
    assert b"budget:mid_stream" not in body
    assert b"message_stop" in body


def _openai_runaway_chunks(n_chunks: int = 50) -> list[bytes]:
    """OpenAI stream with many big content deltas — triggers approx-token cancel."""
    chunks = [
        b'data: {"choices":[{"index":0,"delta":{"role":"assistant"}}]}\n\n',
    ]
    # Each chunk ~4000 chars ≈ 1000 approx tokens. 50 chunks → 50K approx tokens.
    big = "x" * 4000
    payload = json.dumps({"choices": [{"index": 0, "delta": {"content": big}}]})
    for _ in range(n_chunks):
        chunks.append(b"data: " + payload.encode() + b"\n\n")
    chunks.append(b'data: [DONE]\n\n')
    return chunks


@pytest.mark.asyncio
async def test_openai_mid_stream_cancel_on_hard_cap(cfg):
    """OpenAI streams use approx_output_tokens (content-char/4) to test the cap."""
    cfg.budget.default_cap_usd = 0.001  # very tight cap
    chunks = _openai_runaway_chunks(n_chunks=50)
    transport = _build_streaming_upstream(chunks)
    app, state = _build_app(cfg, transport)
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://test") as ac:
        async with ac.stream(
            "POST", "/v1/chat/completions",
            headers={"x-llm-leash-session-id": "oai-runaway"},
            json={
                "model": "gpt-4o", "max_tokens": 100,
                "stream": True,
                "messages": [{"role": "user", "content": "hi"}],
            },
        ) as resp:
            assert resp.status_code == 200
            body = b""
            async for chunk in resp.aiter_raw():
                body += chunk
        await asyncio.sleep(0.01)

    assert b"budget:mid_stream" in body
    assert b"[DONE]" in body
    # Approx-tokens charged to the store.
    cumulative = await state.budget_store.get("oai-runaway")
    assert cumulative > 0  # something was charged based on approx tokens
