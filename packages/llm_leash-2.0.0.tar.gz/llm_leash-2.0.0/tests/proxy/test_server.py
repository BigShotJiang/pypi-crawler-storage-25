"""Tests for the v2.0 proxy skeleton: health endpoints + CLI."""
from __future__ import annotations

import pytest
from starlette.testclient import TestClient

from llm_leash import __version__
from llm_leash.proxy.server import build_app, main


@pytest.fixture
def client():
    # `with TestClient(...)` runs the lifespan handler, which initialises
    # ProxyState.http_client. Without it, /readyz reports "starting".
    with TestClient(build_app()) as c:
        yield c


# ─── /healthz ─────────────────────────────────────────────────────


def test_healthz_returns_200(client):
    resp = client.get("/healthz")
    assert resp.status_code == 200


def test_healthz_includes_version_and_mode(client):
    body = client.get("/healthz").json()
    assert body["status"] == "ok"
    assert body["version"] == __version__
    assert body["mode"] == "proxy"


# ─── /readyz ──────────────────────────────────────────────────────


def test_readyz_returns_200(client):
    resp = client.get("/readyz")
    assert resp.status_code == 200


def test_readyz_includes_checks_field(client):
    body = client.get("/readyz").json()
    assert body["status"] == "ready"
    assert "checks" in body
    assert isinstance(body["checks"], dict)


# ─── / (root) ─────────────────────────────────────────────────────


def test_root_lists_endpoints(client):
    body = client.get("/").json()
    assert body["service"] == "llm-leash-proxy"
    assert body["version"] == __version__
    assert "/healthz" in body["endpoints"]
    assert "/readyz" in body["endpoints"]


# ─── Method enforcement ───────────────────────────────────────────


def test_healthz_rejects_post(client):
    resp = client.post("/healthz")
    assert resp.status_code == 405


def test_unknown_path_returns_404(client):
    assert client.get("/nope").status_code == 404


# ─── CLI parser ───────────────────────────────────────────────────


def test_cli_version_flag(capsys):
    """`--version` exits 0 with the package version."""
    with pytest.raises(SystemExit) as exc_info:
        main(["--version"])
    assert exc_info.value.code == 0
    captured = capsys.readouterr()
    assert __version__ in captured.out


def test_cli_listen_invalid_format_errors(capsys):
    """`--listen` without HOST:PORT structure must error out cleanly."""
    with pytest.raises(SystemExit):
        main(["--listen", "not-a-host-port"])
    err = capsys.readouterr().err
    assert "HOST:PORT" in err
