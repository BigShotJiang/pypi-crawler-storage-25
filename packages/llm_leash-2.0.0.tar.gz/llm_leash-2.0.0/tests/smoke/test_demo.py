"""Smoke test: the README five-line demo runs and produces a chained audit log."""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _load_demo():
    spec = importlib.util.spec_from_file_location("demo", ROOT / "demo.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules["demo"] = module
    spec.loader.exec_module(module)
    return module


def test_demo_exits_zero_and_writes_chained_audit(tmp_path, capsys):
    demo = _load_demo()
    audit = tmp_path / "audit.jsonl"

    rc = demo.main(str(audit))
    assert rc == 0

    captured = capsys.readouterr().out
    assert "BLOCKED" in captured
    assert "llm-leash demo" in captured

    # Audit log must exist and be a valid chain.
    assert audit.exists()
    from llm_leash.audit.verify import verify_chain
    n = verify_chain(str(audit))
    assert n >= 1
