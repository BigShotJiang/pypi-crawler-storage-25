"""Tests for llm-leash-console (PR-14).

Coverage:
  - GET /              renders the dashboard HTML
  - GET /healthz       returns version + mode
  - GET /api/audit     reads recent events from the audit file
  - GET /api/stats     standalone mode (no proxy) returns empty blob
  - GET /api/stats     with proxy + token returns upstream stats
  - GET /api/stats     proxy unreachable → 502
  - GET /api/stats     no admin token configured → 503
  - WS  /ws/audit      pushes a newly-appended event
"""
from __future__ import annotations

import json

import httpx
from starlette.testclient import TestClient

from llm_leash.console.server import build_app

# ─── HTML + healthz ──────────────────────────────────────────────


def test_index_serves_dashboard(tmp_path):
    log = tmp_path / "audit.jsonl"
    log.write_text("")
    app = build_app(audit_log=str(log))
    with TestClient(app) as client:
        resp = client.get("/")
    assert resp.status_code == 200
    assert "llm-leash console" in resp.text
    assert "alpinejs" in resp.text.lower()


def test_healthz_returns_version_and_mode(tmp_path):
    log = tmp_path / "audit.jsonl"
    log.write_text("")
    app = build_app(audit_log=str(log))
    with TestClient(app) as client:
        body = client.get("/healthz").json()
    assert body["status"] == "ok"
    assert body["mode"] == "console"
    assert "version" in body


# ─── /api/audit ───────────────────────────────────────────────────


def test_api_audit_returns_events_from_file(tmp_path):
    log = tmp_path / "audit.jsonl"
    log.write_text(
        '{"kind":"model_call","seq":0,"session_id":"a","cost_usd":0.001}\n'
        '{"kind":"model_call","seq":1,"session_id":"b","cost_usd":0.002}\n'
        '{"kind":"kill","seq":2,"session_id":"a","reason":"manual"}\n',
    )
    app = build_app(audit_log=str(log))
    with TestClient(app) as client:
        body = client.get("/api/audit").json()
    assert body["audit_log"] == str(log)
    assert len(body["events"]) == 3
    assert body["events"][2]["kind"] == "kill"


def test_api_audit_n_query_param(tmp_path):
    """`?n=K` returns only the last K events."""
    log = tmp_path / "audit.jsonl"
    log.write_text("\n".join(
        json.dumps({"kind": "model_call", "seq": i, "cost_usd": 0.001 * i})
        for i in range(10)
    ) + "\n")
    app = build_app(audit_log=str(log))
    with TestClient(app) as client:
        body = client.get("/api/audit?n=3").json()
    assert len(body["events"]) == 3
    assert [e["seq"] for e in body["events"]] == [7, 8, 9]


def test_api_audit_empty_file_returns_empty(tmp_path):
    log = tmp_path / "audit.jsonl"
    log.write_text("")
    app = build_app(audit_log=str(log))
    with TestClient(app) as client:
        body = client.get("/api/audit").json()
    assert body["events"] == []


def test_api_audit_skips_malformed_lines(tmp_path):
    log = tmp_path / "audit.jsonl"
    log.write_text(
        '{"kind":"model_call","seq":0}\n'
        'not-json-at-all\n'
        '{"kind":"kill","seq":1}\n',
    )
    app = build_app(audit_log=str(log))
    with TestClient(app) as client:
        body = client.get("/api/audit").json()
    assert len(body["events"]) == 2


def test_api_audit_missing_file_returns_empty(tmp_path):
    """Console started before proxy wrote anything — file doesn't exist yet."""
    app = build_app(audit_log=str(tmp_path / "not-yet.jsonl"))
    with TestClient(app) as client:
        body = client.get("/api/audit").json()
    assert body["events"] == []


# ─── /api/stats — standalone ─────────────────────────────────────


def test_api_stats_standalone_returns_empty_blob(tmp_path):
    """No --proxy → return zero stats so the UI renders cleanly."""
    app = build_app(audit_log=str(tmp_path / "audit.jsonl"))
    with TestClient(app) as client:
        body = client.get("/api/stats").json()
    assert body["active_sessions"] == 0
    assert body["total_spend_usd"] == 0.0
    assert body["proxy_url"] is None


def test_api_stats_proxy_set_but_no_token_returns_503(tmp_path):
    app = build_app(
        audit_log=str(tmp_path / "audit.jsonl"),
        proxy_url="http://localhost:8000",
        admin_token=None,
    )
    with TestClient(app) as client:
        resp = client.get("/api/stats")
    assert resp.status_code == 503
    assert resp.json()["error"]["type"] == "no_admin_token"


# ─── /api/stats — proxy passthrough ──────────────────────────────


def _proxy_stats_handler(
    upstream_status: int = 200,
    upstream_body: dict | None = None,
):
    """Build an httpx.MockTransport responder for /admin/stats."""
    def handler(request: httpx.Request) -> httpx.Response:
        # The console must include Authorization header.
        assert "authorization" in {k.lower() for k in request.headers}
        assert request.url.path.endswith("/admin/stats")
        body = upstream_body if upstream_body is not None else {
            "active_sessions": 3,
            "total_spend_usd": 0.42,
            "top_sessions": [{"session_id": "alice", "cost_usd": 0.42}],
            "hitl_pending": 0,
            "hitl_backend": "inmemory",
            "policy_rules": 2,
            "pii_redactor_enabled": True,
        }
        return httpx.Response(upstream_status, json=body)
    return httpx.MockTransport(handler)


def test_api_stats_proxies_to_admin_stats(tmp_path):
    transport = _proxy_stats_handler()
    client = httpx.AsyncClient(transport=transport)
    app = build_app(
        audit_log=str(tmp_path / "audit.jsonl"),
        proxy_url="http://proxy:8000",
        admin_token="tok",  # noqa: S106 (test fixture)
        http_client=client,
    )
    with TestClient(app) as tc:
        body = tc.get("/api/stats").json()
    assert body["active_sessions"] == 3
    assert body["proxy_url"] == "http://proxy:8000"
    assert body["top_sessions"][0]["session_id"] == "alice"


def test_api_stats_proxy_unreachable_returns_502(tmp_path):
    def fail(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("no route to host")

    client = httpx.AsyncClient(transport=httpx.MockTransport(fail))
    app = build_app(
        audit_log=str(tmp_path / "audit.jsonl"),
        proxy_url="http://proxy:8000",
        admin_token="tok",  # noqa: S106
        http_client=client,
    )
    with TestClient(app) as tc:
        resp = tc.get("/api/stats")
    assert resp.status_code == 502
    assert resp.json()["error"]["type"] == "proxy_unreachable"


def test_api_stats_proxy_4xx_passes_through(tmp_path):
    transport = _proxy_stats_handler(upstream_status=401, upstream_body={
        "error": {"type": "unauthorized", "message": "bad token"},
    })
    client = httpx.AsyncClient(transport=transport)
    app = build_app(
        audit_log=str(tmp_path / "audit.jsonl"),
        proxy_url="http://proxy:8000",
        admin_token="wrong",  # noqa: S106
        http_client=client,
    )
    with TestClient(app) as tc:
        resp = tc.get("/api/stats")
    assert resp.status_code == 401


# ─── WebSocket /ws/audit ─────────────────────────────────────────


def test_ws_audit_streams_new_events(tmp_path):
    """Appending to the audit file pushes the new line to the WS client."""
    log = tmp_path / "audit.jsonl"
    log.write_text("")  # start at byte 0
    app = build_app(audit_log=str(log))

    with TestClient(app) as client:
        with client.websocket_connect("/ws/audit") as ws:
            # Server starts tailing at end-of-file. Append after a moment
            # so the polling loop has captured the initial size.
            import time
            time.sleep(0.1)

            with log.open("a") as f:
                f.write('{"kind":"model_call","seq":1,"agent_name":"analyst"}\n')

            # Server polls once per second. receive_text blocks until
            # a message arrives (or the connection drops on test timeout).
            data = ws.receive_text()
            event = json.loads(data)
            assert event["kind"] == "model_call"
            assert event["agent_name"] == "analyst"


def test_ws_audit_ignores_partial_writes(tmp_path):
    """Lines without trailing newline aren't pushed (we wait for completion)."""
    log = tmp_path / "audit.jsonl"
    log.write_text("")
    app = build_app(audit_log=str(log))

    # We can't easily assert "WS sends NOTHING" without a long sleep; this
    # is a smoke test that simply verifies the WS endpoint accepts the
    # connection even when the log file is mid-write.
    with TestClient(app) as client:
        with client.websocket_connect("/ws/audit") as ws:
            assert ws is not None  # connected
