"""SQLiteBudgetStore tests — round trip, persistence, concurrent safety."""
from __future__ import annotations

import asyncio

import pytest

from llm_leash.budget.sqlite_store import SQLiteBudgetStore


@pytest.mark.asyncio
async def test_get_returns_zero_for_unknown_session(tmp_path):
    store = SQLiteBudgetStore(str(tmp_path / "budget.db"))
    assert await store.get("never_seen") == 0.0
    store.close()


@pytest.mark.asyncio
async def test_add_returns_new_cumulative(tmp_path):
    store = SQLiteBudgetStore(str(tmp_path / "budget.db"))
    assert await store.add("s1", 0.10) == pytest.approx(0.10)
    assert await store.add("s1", 0.25) == pytest.approx(0.35)
    assert await store.get("s1") == pytest.approx(0.35)
    store.close()


@pytest.mark.asyncio
async def test_reset_clears_session(tmp_path):
    store = SQLiteBudgetStore(str(tmp_path / "budget.db"))
    await store.add("s1", 1.0)
    await store.reset("s1")
    assert await store.get("s1") == 0.0
    store.close()


@pytest.mark.asyncio
async def test_persists_across_instances(tmp_path):
    path = str(tmp_path / "budget.db")
    s1 = SQLiteBudgetStore(path)
    await s1.add("session-a", 0.42)
    s1.close()

    s2 = SQLiteBudgetStore(path)
    assert await s2.get("session-a") == pytest.approx(0.42)
    s2.close()


@pytest.mark.asyncio
async def test_concurrent_adds_are_atomic(tmp_path):
    """50 parallel `add` calls of 0.01 each must yield exactly 0.50 cumulative."""
    store = SQLiteBudgetStore(str(tmp_path / "budget.db"))
    await asyncio.gather(*(store.add("hot", 0.01) for _ in range(50)))
    total = await store.get("hot")
    assert total == pytest.approx(0.50, abs=1e-9)
    store.close()


@pytest.mark.asyncio
async def test_isolated_sessions_do_not_cross(tmp_path):
    store = SQLiteBudgetStore(str(tmp_path / "budget.db"))
    await store.add("s_a", 0.10)
    await store.add("s_b", 0.20)
    assert await store.get("s_a") == pytest.approx(0.10)
    assert await store.get("s_b") == pytest.approx(0.20)
    store.close()
