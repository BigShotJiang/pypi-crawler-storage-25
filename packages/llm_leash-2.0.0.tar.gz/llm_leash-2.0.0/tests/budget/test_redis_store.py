"""RedisBudgetStore tests. Uses FakeRedis — no real server needed."""
from __future__ import annotations

import pytest

from llm_leash.budget.redis_store import RedisBudgetStore


class FakeRedis:
    def __init__(self) -> None:
        self._data: dict[str, bytes] = {}

    def get(self, key: str) -> bytes | None:
        return self._data.get(key)

    def delete(self, key: str) -> None:
        self._data.pop(key, None)

    def incrbyfloat(self, key: str, amount: float) -> float:
        current = float(self._data.get(key, b"0"))
        new = current + amount
        self._data[key] = str(new).encode()
        return new


@pytest.mark.asyncio
async def test_get_returns_zero_initially():
    store = RedisBudgetStore(FakeRedis())
    assert await store.get("s1") == 0.0


@pytest.mark.asyncio
async def test_add_returns_new_total():
    store = RedisBudgetStore(FakeRedis())
    result = await store.add("s1", 0.50)
    assert abs(result - 0.50) < 1e-9


@pytest.mark.asyncio
async def test_add_accumulates():
    store = RedisBudgetStore(FakeRedis())
    await store.add("s1", 0.10)
    await store.add("s1", 0.20)
    total = await store.get("s1")
    assert abs(total - 0.30) < 1e-9


@pytest.mark.asyncio
async def test_reset_clears_session():
    store = RedisBudgetStore(FakeRedis())
    await store.add("s1", 1.00)
    await store.reset("s1")
    assert await store.get("s1") == 0.0


@pytest.mark.asyncio
async def test_sessions_are_isolated():
    r = FakeRedis()
    store = RedisBudgetStore(r)
    await store.add("s1", 5.00)
    assert await store.get("s2") == 0.0


@pytest.mark.asyncio
async def test_two_stores_share_state_via_same_client():
    r = FakeRedis()
    store1 = RedisBudgetStore(r)
    store2 = RedisBudgetStore(r)
    await store1.add("s1", 1.23)
    total = await store2.get("s1")
    assert abs(total - 1.23) < 1e-9


@pytest.mark.asyncio
async def test_custom_key_prefix():
    store = RedisBudgetStore(FakeRedis(), key_prefix="myapp:budget:")
    await store.add("s1", 0.5)
    assert abs(await store.get("s1") - 0.5) < 1e-9


@pytest.mark.asyncio
async def test_small_increments_precise():
    store = RedisBudgetStore(FakeRedis())
    for _ in range(10):
        await store.add("s1", 0.001)
    total = await store.get("s1")
    assert abs(total - 0.010) < 1e-6
