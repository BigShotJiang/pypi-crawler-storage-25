from __future__ import annotations

import asyncio

import pytest

from llm_leash.budget.store import InMemoryStore


@pytest.mark.asyncio
async def test_new_session_starts_at_zero():
    store = InMemoryStore()
    assert await store.get("s1") == 0.0


@pytest.mark.asyncio
async def test_add_returns_new_total():
    store = InMemoryStore()
    total = await store.add("s1", 0.50)
    assert total == 0.50
    total = await store.add("s1", 0.25)
    assert total == 0.75


@pytest.mark.asyncio
async def test_sessions_are_isolated():
    store = InMemoryStore()
    await store.add("s1", 1.00)
    await store.add("s2", 2.00)
    assert await store.get("s1") == 1.00
    assert await store.get("s2") == 2.00


@pytest.mark.asyncio
async def test_reset_clears_session():
    store = InMemoryStore()
    await store.add("s1", 5.00)
    await store.reset("s1")
    assert await store.get("s1") == 0.0


@pytest.mark.asyncio
async def test_concurrent_adds_are_atomic():
    store = InMemoryStore()
    async def bump():
        for _ in range(100):
            await store.add("s1", 0.01)
    await asyncio.gather(*[bump() for _ in range(10)])
    total = await store.get("s1")
    assert total == pytest.approx(10.0, abs=1e-6)
