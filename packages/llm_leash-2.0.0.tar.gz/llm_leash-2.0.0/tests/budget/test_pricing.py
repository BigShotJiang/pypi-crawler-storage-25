from __future__ import annotations

import pytest

from llm_leash.budget.pricing import (
    PRICING_v_2026_05,
    UnknownModel,
    cost_for,
)


def test_pricing_table_has_anthropic_and_openai_keys():
    assert "anthropic" in PRICING_v_2026_05
    assert "openai" in PRICING_v_2026_05


def test_pricing_table_has_claude_opus_4_7():
    entry = PRICING_v_2026_05["anthropic"]["claude-opus-4-7"]
    assert entry["input_per_million_usd"] > 0
    assert entry["output_per_million_usd"] > 0


def test_cost_for_known_model():
    cost = cost_for(
        provider="anthropic",
        model="claude-opus-4-7",
        in_tokens=1_000_000,
        out_tokens=0,
    )
    expected = PRICING_v_2026_05["anthropic"]["claude-opus-4-7"]["input_per_million_usd"]
    assert cost == pytest.approx(expected)


def test_cost_for_mixed_tokens():
    cost = cost_for(
        provider="anthropic",
        model="claude-opus-4-7",
        in_tokens=500_000,
        out_tokens=500_000,
    )
    entry = PRICING_v_2026_05["anthropic"]["claude-opus-4-7"]
    expected = entry["input_per_million_usd"] * 0.5 + entry["output_per_million_usd"] * 0.5
    assert cost == pytest.approx(expected)


def test_cost_for_unknown_provider_raises():
    with pytest.raises(UnknownModel):
        cost_for(provider="cohere", model="command-r", in_tokens=100, out_tokens=100)


def test_cost_for_unknown_model_raises():
    with pytest.raises(UnknownModel):
        cost_for(provider="anthropic", model="claude-fictional-7", in_tokens=100, out_tokens=100)


def test_cost_for_zero_tokens_is_zero():
    cost = cost_for(provider="anthropic", model="claude-opus-4-7", in_tokens=0, out_tokens=0)
    assert cost == 0.0


# ─── Extended Anthropic naming coverage (v1.3.1) ───────────────────────


@pytest.mark.parametrize("model", [
    "claude-opus-4-5", "claude-opus-4-6",
    "claude-sonnet-4-5",
    "claude-3-5-sonnet", "claude-3-5-haiku",
    "claude-sonnet-3-5", "claude-haiku-3-5",
])
def test_anthropic_extended_names_are_priced(model):
    """Real-world deployments (orchestrators, OpenRouter routing tables) pin
    model names from across the Claude family. v1.3.1 expands the table to
    cover the named variants we've seen in third-party catalogs.
    """
    cost = cost_for(provider="anthropic", model=model, in_tokens=1000, out_tokens=500)
    assert cost > 0


def test_opus_4_5_priced_at_opus_tier():
    """Opus variants (4-5, 4-6, 4-7) share the top-tier $15/$75 pricing."""
    c45 = cost_for(provider="anthropic", model="claude-opus-4-5",
                   in_tokens=1_000_000, out_tokens=0)
    c47 = cost_for(provider="anthropic", model="claude-opus-4-7",
                   in_tokens=1_000_000, out_tokens=0)
    assert c45 == c47 == pytest.approx(15.0)


def test_haiku_aliases_same_price():
    """`claude-3-5-haiku` and `claude-haiku-3-5` are equivalent third-party names."""
    a = cost_for(provider="anthropic", model="claude-3-5-haiku",
                 in_tokens=1_000_000, out_tokens=1_000_000)
    b = cost_for(provider="anthropic", model="claude-haiku-3-5",
                 in_tokens=1_000_000, out_tokens=1_000_000)
    assert a == b
