from __future__ import annotations

import pytest

from llm_leash.budget.store import InMemoryStore
from llm_leash.budget.tracker import BudgetTracker
from llm_leash.types import LeashKilled


@pytest.mark.asyncio
async def test_charge_increments_cumulative():
    t = BudgetTracker(session_id="s1", hard_cap_usd=100.0, soft_cap_usd=None, store=InMemoryStore())
    state = await t.charge(provider="anthropic", model="claude-haiku-4-5",
                           in_tokens=1_000_000, out_tokens=0)
    # haiku-4-5 input = $0.80/M
    assert state.cumulative_usd == pytest.approx(0.80)
    assert state.decision == "under"


@pytest.mark.asyncio
async def test_soft_cap_emits_warn_but_continues():
    t = BudgetTracker(session_id="s1", hard_cap_usd=100.0, soft_cap_usd=1.0, store=InMemoryStore())
    state = await t.charge(provider="anthropic", model="claude-haiku-4-5",
                           in_tokens=2_000_000, out_tokens=0)  # $1.60, exceeds soft $1
    assert state.cumulative_usd == pytest.approx(1.60)
    assert state.decision == "soft_exceeded"


@pytest.mark.asyncio
async def test_hard_cap_raises_leash_killed():
    t = BudgetTracker(session_id="s1", hard_cap_usd=1.0, soft_cap_usd=None, store=InMemoryStore())
    with pytest.raises(LeashKilled) as exc:
        await t.charge(provider="anthropic", model="claude-opus-4-7",
                       in_tokens=1_000_000, out_tokens=0)  # $15
    assert "budget" in str(exc.value).lower()
    assert exc.value.rule_id == "budget:hard_cap"


@pytest.mark.asyncio
async def test_estimate_does_not_charge():
    store = InMemoryStore()
    t = BudgetTracker(session_id="s1", hard_cap_usd=100.0, soft_cap_usd=None, store=store)
    est = await t.estimate(provider="anthropic", model="claude-haiku-4-5", in_tokens=1_000_000)
    assert est == pytest.approx(0.80)
    assert await store.get("s1") == 0.0


@pytest.mark.asyncio
async def test_cumulative_property_reads_store():
    store = InMemoryStore()
    await store.add("s1", 3.50)
    t = BudgetTracker(session_id="s1", hard_cap_usd=100.0, soft_cap_usd=None, store=store)
    assert await t.cumulative_usd() == pytest.approx(3.50)


@pytest.mark.asyncio
async def test_no_caps_never_raises():
    t = BudgetTracker(session_id="s1", hard_cap_usd=None, soft_cap_usd=None, store=InMemoryStore())
    state = await t.charge(provider="anthropic", model="claude-opus-4-7",
                           in_tokens=10_000_000, out_tokens=10_000_000)
    assert state.decision == "under"
