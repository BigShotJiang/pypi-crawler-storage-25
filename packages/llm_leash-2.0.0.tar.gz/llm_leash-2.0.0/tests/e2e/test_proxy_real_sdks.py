"""End-to-end smoke tests: real `anthropic` / `openai` SDKs pointed at the proxy.

Validates the most important contract: an unmodified agent SDK
(installed from PyPI) talks to `llm-leash-proxy` correctly when its
`base_url` env var is flipped.

We DON'T hit real provider APIs — outbound calls from the proxy are
intercepted via httpx MockTransport at the proxy's `http_client`.
The SDKs hit the proxy in-process via Starlette's ASGI bridge.

Each test runs the proxy on a real ephemeral TCP port (uvicorn) so the
SDK's httpx client speaks real HTTP — this exercises starlette routing,
JSON body marshalling, and Response object construction end-to-end.
"""
from __future__ import annotations

import socket
import threading
import time

import httpx
import pytest

try:
    import anthropic  # type: ignore[import-not-found]
    import openai  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover
    anthropic = None  # type: ignore[assignment]
    openai = None  # type: ignore[assignment]

from llm_leash.proxy.config import ProxyConfig
from llm_leash.proxy.server import build_app
from llm_leash.proxy.state import ProxyState

pytestmark = pytest.mark.skipif(
    anthropic is None or openai is None,
    reason="requires anthropic + openai SDKs (install dev extras)",
)


# ─── Mock upstream (intercepts proxy's outbound httpx calls) ─────────


def _ok_anthropic(text: str = "hello from anthropic") -> dict:
    return {
        "id": "msg_e2e", "type": "message", "role": "assistant",
        "model": "claude-haiku-4-5",
        "content": [{"type": "text", "text": text}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 12, "output_tokens": 8},
    }


def _ok_openai(text: str = "hello from openai") -> dict:
    return {
        "id": "chatcmpl-e2e", "object": "chat.completion",
        "created": 1700000000, "model": "gpt-4o",
        "choices": [{
            "index": 0, "finish_reason": "stop",
            "message": {"role": "assistant", "content": text},
        }],
        "usage": {
            "prompt_tokens": 12, "completion_tokens": 8, "total_tokens": 20,
        },
    }


def _upstream_handler(request: httpx.Request) -> httpx.Response:
    url = str(request.url)
    if "/v1/messages" in url:
        return httpx.Response(200, json=_ok_anthropic())
    if "/v1/chat/completions" in url:
        return httpx.Response(200, json=_ok_openai())
    return httpx.Response(404, json={"error": "no such mock endpoint"})


# ─── Live proxy server fixture (uvicorn on ephemeral port) ────────────


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def live_proxy(tmp_path):
    """Spin up `llm-leash-proxy` on a real ephemeral port. Mocked upstream."""
    import uvicorn

    port = _free_port()
    cfg = ProxyConfig()
    cfg.audit_log = str(tmp_path / "audit.jsonl")
    cfg.budget.default_cap_usd = 100.0
    cfg.listen_host = "127.0.0.1"
    cfg.listen_port = port

    state = ProxyState.from_config(cfg)
    state.http_client = httpx.AsyncClient(
        transport=httpx.MockTransport(_upstream_handler),
    )
    app = build_app(cfg, state=state)

    server_config = uvicorn.Config(app, host=cfg.listen_host, port=port, log_level="warning")
    server = uvicorn.Server(server_config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    # Wait for server to start (poll /healthz).
    base_url = f"http://127.0.0.1:{port}"
    for _ in range(50):
        try:
            r = httpx.get(f"{base_url}/healthz", timeout=0.5)
            if r.status_code == 200:
                break
        except httpx.HTTPError:
            time.sleep(0.05)
    else:
        pytest.fail("proxy did not start within 2.5s")

    yield base_url, cfg

    server.should_exit = True
    thread.join(timeout=3)


# ─── Anthropic SDK against proxy ───────────────────────────────────


def test_anthropic_sdk_through_proxy(live_proxy):
    """anthropic.Anthropic(base_url=proxy) → proxy → mocked upstream."""
    base_url, _ = live_proxy
    client = anthropic.Anthropic(
        api_key="sk-test-not-real",
        base_url=base_url,
    )
    resp = client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=50,
        messages=[{"role": "user", "content": "hi"}],
    )
    assert resp.content[0].text == "hello from anthropic"
    assert resp.usage.input_tokens == 12
    assert resp.usage.output_tokens == 8


def test_anthropic_sdk_charges_budget_through_proxy(live_proxy):
    base_url, cfg = live_proxy
    client = anthropic.Anthropic(api_key="sk-test", base_url=base_url)
    client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=50,
        extra_headers={"x-llm-leash-session-id": "e2e-anth"},
        messages=[{"role": "user", "content": "hi"}],
    )
    # Spend recorded in audit log.
    import json
    with open(cfg.audit_log) as f:
        last = json.loads(f.read().strip().splitlines()[-1])
    assert last["session_id"] == "e2e-anth"
    assert last["provider"] == "anthropic"
    assert last["input_tokens"] == 12
    assert last["output_tokens"] == 8


# ─── OpenAI SDK against proxy ──────────────────────────────────────


def test_openai_sdk_through_proxy(live_proxy):
    base_url, _ = live_proxy
    client = openai.OpenAI(
        api_key="sk-test-not-real",
        base_url=base_url + "/v1",  # openai SDK appends path itself
    )
    resp = client.chat.completions.create(
        model="gpt-4o",
        max_tokens=50,
        messages=[{"role": "user", "content": "hi"}],
    )
    assert resp.choices[0].message.content == "hello from openai"
    assert resp.usage.prompt_tokens == 12


def test_openai_sdk_normal_call_succeeds(live_proxy):
    """Smoke: OpenAI SDK can make a normal call through the proxy.

    Kill-semantics validation lives in test_admin.py — those tests use
    the in-process kill registry directly. Re-validating via the live
    SDK here would require admin_token plumbing in the live_proxy
    fixture, which is overkill for the smoke layer.
    """
    base_url, _ = live_proxy
    client = openai.OpenAI(api_key="sk-test", base_url=base_url + "/v1")
    resp = client.chat.completions.create(
        model="gpt-4o",
        max_tokens=10,
        messages=[{"role": "user", "content": "x"}],
    )
    assert resp.choices[0].message.content is not None


# ─── Mixing both SDKs against the same proxy ──────────────────────


def test_both_sdks_share_one_audit_log(live_proxy):
    """Confirm the same proxy serves both providers and they share one chain."""
    base_url, cfg = live_proxy

    a_client = anthropic.Anthropic(api_key="sk-a", base_url=base_url)
    o_client = openai.OpenAI(api_key="sk-o", base_url=base_url + "/v1")

    a_client.messages.create(
        model="claude-haiku-4-5", max_tokens=10,
        messages=[{"role": "user", "content": "hi from a"}],
    )
    o_client.chat.completions.create(
        model="gpt-4o", max_tokens=10,
        messages=[{"role": "user", "content": "hi from o"}],
    )

    # Verify both events in the audit chain and chain integrity.
    from llm_leash.audit.verify import verify_chain
    assert verify_chain(cfg.audit_log) == 2

    import json
    lines = open(cfg.audit_log).read().strip().splitlines()
    providers = {json.loads(line)["provider"] for line in lines}
    assert providers == {"anthropic", "openai"}
