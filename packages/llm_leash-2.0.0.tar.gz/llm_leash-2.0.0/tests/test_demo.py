from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_demo_runs_and_blocks(tmp_path):
    repo_root = Path(__file__).resolve().parents[1]
    audit_path = tmp_path / "audit.jsonl"
    result = subprocess.run(  # noqa: S603
        [sys.executable, str(repo_root / "demo.py"), str(audit_path)],
        capture_output=True, text=True, timeout=20,
    )
    # Demo prints a banner, runs until LeashKilled, exits 0.
    assert result.returncode == 0, f"stderr: {result.stderr}"
    assert "BLOCKED" in result.stdout
    assert audit_path.exists()
    assert audit_path.stat().st_size > 0


def test_demo_audit_log_verifies(tmp_path):
    repo_root = Path(__file__).resolve().parents[1]
    audit_path = tmp_path / "audit.jsonl"
    subprocess.run(  # noqa: S603
        [sys.executable, str(repo_root / "demo.py"), str(audit_path)],
        capture_output=True, text=True, timeout=20, check=True,
    )
    verify = subprocess.run(  # noqa: S603
        [sys.executable, "-m", "llm_leash.cli", "verify", str(audit_path)],
        capture_output=True, text=True, timeout=10,
    )
    assert verify.returncode == 0
    assert "OK" in verify.stdout
