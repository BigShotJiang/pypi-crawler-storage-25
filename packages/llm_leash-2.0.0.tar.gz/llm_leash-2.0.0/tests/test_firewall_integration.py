"""End-to-end test of the 5-line user demo."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from llm_leash import Firewall, LeashKilled


@dataclass
class _Usage:
    input_tokens: int
    output_tokens: int


@dataclass
class _Response:
    model: str
    usage: _Usage
    content: list[dict[str, Any]]


class _FakeMessages:
    def create(self, **kwargs: Any) -> _Response:
        return _Response(
            model=kwargs["model"],
            usage=_Usage(input_tokens=10_000, output_tokens=10_000),
            content=[{"type": "text", "text": "ok"}],
        )


class _FakeAnthropic:
    def __init__(self) -> None:
        self.messages = _FakeMessages()


def test_five_line_demo_blocks_on_budget(tmp_path):
    fw = Firewall(
        budget_usd=0.50,
        audit_log=str(tmp_path / "audit.jsonl"),
        session_id="demo",
    )
    client = fw.wrap(_FakeAnthropic())

    # First call: 10k in + 10k out at opus-4-7 = $0.15 + $0.75 = $0.90 → exceeds $0.50
    with pytest.raises(LeashKilled):
        for _ in range(10):
            client.messages.create(
                model="claude-opus-4-7", max_tokens=10_000,
                messages=[{"role": "user", "content": "burn budget"}],
            )


def test_audit_log_is_chained(tmp_path):
    log = tmp_path / "audit.jsonl"
    fw = Firewall(
        budget_usd=100.0,
        audit_log=str(log),
        session_id="demo",
    )
    client = fw.wrap(_FakeAnthropic())

    for _ in range(3):
        client.messages.create(
            model="claude-haiku-4-5", max_tokens=100,
            messages=[{"role": "user", "content": "hi"}],
        )

    from llm_leash.audit.verify import verify_chain
    n = verify_chain(str(log))
    assert n == 3


def test_kill_switch_stops_session(tmp_path):
    fw = Firewall(
        budget_usd=100.0,
        audit_log=str(tmp_path / "audit.jsonl"),
        session_id="demo",
    )
    client = fw.wrap(_FakeAnthropic())

    # Manually kill the session.
    import asyncio
    asyncio.run(fw.kill("manual abort"))

    with pytest.raises(LeashKilled):
        client.messages.create(
            model="claude-haiku-4-5", max_tokens=10,
            messages=[{"role": "user", "content": "hi"}],
        )


# ─── Policy engine integration ───────────────────────────────────────────────


def _make_response(in_t: int = 100, out_t: int = 50) -> _Response:
    return _Response(
        model="claude-haiku-4-5",
        usage=_Usage(input_tokens=in_t, output_tokens=out_t),
        content=[{"type": "text", "text": "ok"}],
    )


class FakeAnthropic:
    def __init__(self, response: _Response | None = None) -> None:
        self.messages = _FakeMessages() if response is None else _FixedMessages(response)


class _FixedMessages:
    def __init__(self, response: _Response) -> None:
        self._response = response

    def create(self, **kwargs: Any) -> _Response:
        return self._response


@pytest.mark.asyncio
async def test_blocked_pattern_raises_leash_blocked():
    from llm_leash.policy.predicates import BlockedPatterns
    from llm_leash.types import LeashBlocked

    fw = Firewall(rules=[BlockedPatterns([r"rm\s+-rf"])])
    client = FakeAnthropic(response=_make_response(in_t=100, out_t=50))
    wrapped = fw.wrap(client)
    with pytest.raises(LeashBlocked) as exc_info:
        wrapped.messages.create(
            model="claude-haiku-4-5", max_tokens=128,
            messages=[{"role": "user", "content": "please run: rm -rf /"}],
        )
    assert exc_info.value.rule_id == "blocked_patterns"


@pytest.mark.asyncio
async def test_budget_threshold_warn_does_not_raise():
    from llm_leash.policy.predicates import BudgetThreshold

    fw = Firewall(budget_usd=1.0, rules=[BudgetThreshold(threshold_pct=0.0)])
    client = FakeAnthropic(response=_make_response(in_t=100, out_t=50))
    wrapped = fw.wrap(client)
    resp = wrapped.messages.create(
        model="claude-haiku-4-5", max_tokens=128,
        messages=[{"role": "user", "content": "hello"}],
    )
    assert resp is not None


@pytest.mark.asyncio
async def test_pii_redactor_scrubs_messages(tmp_path):
    from llm_leash.policy.pii import PiiRedactor

    log = str(tmp_path / "audit.log")
    fw = Firewall(audit_log=log, pii_redactor=PiiRedactor())
    captured: list[dict[str, Any]] = []

    class CapturingMessages:
        def create(self, **kwargs: Any) -> _Response:
            captured.append(dict(kwargs))
            return _make_response(in_t=10, out_t=5)

    class CapturingClient:
        def __init__(self) -> None:
            self.messages = CapturingMessages()

    wrapped = fw.wrap(CapturingClient())
    wrapped.messages.create(
        model="claude-haiku-4-5", max_tokens=128,
        messages=[{"role": "user", "content": "my email is test@corp.io"}],
    )
    content = captured[0]["messages"][0]["content"]
    assert "test@corp.io" not in content
    assert "[REDACTED:EMAIL]" in content


# ─── Redis stores integration ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_firewall_with_redis_stores():
    """Firewall works end-to-end with Redis-backed kill + budget stores."""
    from llm_leash.budget.redis_store import RedisBudgetStore
    from llm_leash.kill.redis_registry import RedisKillRegistry

    class _FakeRedis:
        def __init__(self) -> None:
            self._data: dict[str, bytes] = {}

        def get(self, key: str) -> bytes | None:
            return self._data.get(key)

        def set(self, key: str, value: str | bytes) -> None:
            self._data[key] = value.encode() if isinstance(value, str) else value

        def delete(self, key: str) -> None:
            self._data.pop(key, None)

        def exists(self, key: str) -> int:
            return 1 if key in self._data else 0

        def incrbyfloat(self, key: str, amount: float) -> float:
            current = float(self._data.get(key, b"0"))
            new = current + amount
            self._data[key] = str(new).encode()
            return new

    r = _FakeRedis()
    kill_reg = RedisKillRegistry(r)
    budget_store = RedisBudgetStore(r)

    fw = Firewall(budget_usd=1.0, kill_registry=kill_reg, session_id="redis-test")
    fw._budget._store = budget_store

    client = fw.wrap(_FakeAnthropic())
    client.messages.create(
        model="claude-haiku-4-5", max_tokens=10,
        messages=[{"role": "user", "content": "hi"}],
    )
    spent = await fw.cumulative_usd()
    assert spent > 0

    await kill_reg.kill("redis-test", reason="redis kill test")
    with pytest.raises(LeashKilled):
        client.messages.create(
            model="claude-haiku-4-5", max_tokens=10,
            messages=[{"role": "user", "content": "hi"}],
        )


# ─── HITL integration ─────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_hitl_gate_approve_allows_call():
    from llm_leash.hitl.gate import InMemoryHitlGate
    from llm_leash.policy.predicates import HitlThreshold

    gate = InMemoryHitlGate(default="approve")
    fw = Firewall(
        budget_usd=1.0,
        rules=[HitlThreshold(threshold_pct=0.0)],
        hitl_gate=gate,
    )
    client = fw.wrap(FakeAnthropic(response=_make_response(in_t=10, out_t=5)))
    resp = client.messages.create(
        model="claude-haiku-4-5", max_tokens=10,
        messages=[{"role": "user", "content": "hi"}],
    )
    assert resp is not None
    assert len(gate.requests) == 1


@pytest.mark.asyncio
async def test_hitl_gate_reject_raises():
    from llm_leash.hitl.gate import InMemoryHitlGate
    from llm_leash.policy.predicates import HitlThreshold
    from llm_leash.types import LeashRejectedByHuman

    gate = InMemoryHitlGate(default="reject", reject_reason="not today")
    fw = Firewall(
        budget_usd=1.0,
        rules=[HitlThreshold(threshold_pct=0.0)],
        hitl_gate=gate,
    )
    client = fw.wrap(FakeAnthropic(response=_make_response(in_t=10, out_t=5)))
    with pytest.raises(LeashRejectedByHuman) as exc_info:
        client.messages.create(
            model="claude-haiku-4-5", max_tokens=10,
            messages=[{"role": "user", "content": "hi"}],
        )
    assert "not today" in str(exc_info.value)


@pytest.mark.asyncio
async def test_hitl_no_gate_default_denies():
    from llm_leash.policy.predicates import HitlThreshold
    from llm_leash.types import LeashRejectedByHuman

    fw = Firewall(
        budget_usd=1.0,
        rules=[HitlThreshold(threshold_pct=0.0)],
    )
    client = fw.wrap(FakeAnthropic(response=_make_response(in_t=10, out_t=5)))
    with pytest.raises(LeashRejectedByHuman):
        client.messages.create(
            model="claude-haiku-4-5", max_tokens=10,
            messages=[{"role": "user", "content": "hi"}],
        )
