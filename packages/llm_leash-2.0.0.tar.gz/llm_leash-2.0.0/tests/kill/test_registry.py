from __future__ import annotations

import pytest

from llm_leash.kill.registry import InProcessKillRegistry


@pytest.mark.asyncio
async def test_unknown_session_not_killed():
    r = InProcessKillRegistry()
    assert await r.is_killed("s1") is False


@pytest.mark.asyncio
async def test_kill_sets_state():
    r = InProcessKillRegistry()
    await r.kill("s1", reason="test")
    assert await r.is_killed("s1") is True


@pytest.mark.asyncio
async def test_clear_removes_state():
    r = InProcessKillRegistry()
    await r.kill("s1", reason="test")
    await r.clear("s1")
    assert await r.is_killed("s1") is False


@pytest.mark.asyncio
async def test_sessions_isolated():
    r = InProcessKillRegistry()
    await r.kill("s1", reason="test")
    assert await r.is_killed("s2") is False


@pytest.mark.asyncio
async def test_reason_retrievable():
    r = InProcessKillRegistry()
    await r.kill("s1", reason="budget exhausted")
    assert await r.reason_for("s1") == "budget exhausted"
    assert await r.reason_for("s2") is None
