"""RedisKillRegistry tests. Uses FakeRedis — no real server needed."""
from __future__ import annotations

import pytest

from llm_leash.kill.redis_registry import RedisKillRegistry


class FakeRedis:
    def __init__(self) -> None:
        self._data: dict[str, bytes] = {}

    def get(self, key: str) -> bytes | None:
        return self._data.get(key)

    def set(self, key: str, value: str | bytes) -> None:
        self._data[key] = value.encode() if isinstance(value, str) else value

    def delete(self, key: str) -> None:
        self._data.pop(key, None)

    def exists(self, key: str) -> int:
        return 1 if key in self._data else 0


@pytest.mark.asyncio
async def test_not_killed_initially():
    reg = RedisKillRegistry(FakeRedis())
    assert not await reg.is_killed("s1")


@pytest.mark.asyncio
async def test_kill_marks_session():
    reg = RedisKillRegistry(FakeRedis())
    await reg.kill("s1", reason="over budget")
    assert await reg.is_killed("s1")


@pytest.mark.asyncio
async def test_reason_for_returns_reason():
    reg = RedisKillRegistry(FakeRedis())
    await reg.kill("s1", reason="test reason")
    assert await reg.reason_for("s1") == "test reason"


@pytest.mark.asyncio
async def test_reason_for_returns_none_if_not_killed():
    reg = RedisKillRegistry(FakeRedis())
    assert await reg.reason_for("s1") is None


@pytest.mark.asyncio
async def test_clear_removes_kill():
    reg = RedisKillRegistry(FakeRedis())
    await reg.kill("s1", reason="test")
    await reg.clear("s1")
    assert not await reg.is_killed("s1")


@pytest.mark.asyncio
async def test_kill_different_sessions_isolated():
    r = FakeRedis()
    reg = RedisKillRegistry(r)
    await reg.kill("s1", reason="reason1")
    assert not await reg.is_killed("s2")
    assert await reg.is_killed("s1")


@pytest.mark.asyncio
async def test_custom_key_prefix():
    reg = RedisKillRegistry(FakeRedis(), key_prefix="myapp:kill:")
    await reg.kill("s1", reason="x")
    assert await reg.is_killed("s1")


@pytest.mark.asyncio
async def test_two_registries_share_state_via_same_client():
    r = FakeRedis()
    reg1 = RedisKillRegistry(r)
    reg2 = RedisKillRegistry(r)
    await reg1.kill("s1", reason="from reg1")
    assert await reg2.is_killed("s1")
