"""SQLiteKillRegistry tests — kill, idempotent kill, persistence, clear."""
from __future__ import annotations

import pytest

from llm_leash.kill.sqlite_registry import SQLiteKillRegistry


@pytest.mark.asyncio
async def test_not_killed_by_default(tmp_path):
    reg = SQLiteKillRegistry(str(tmp_path / "kill.db"))
    assert await reg.is_killed("s1") is False
    assert await reg.reason_for("s1") is None
    reg.close()


@pytest.mark.asyncio
async def test_kill_and_check(tmp_path):
    reg = SQLiteKillRegistry(str(tmp_path / "kill.db"))
    await reg.kill("s1", reason="manual abort")
    assert await reg.is_killed("s1") is True
    assert await reg.reason_for("s1") == "manual abort"
    reg.close()


@pytest.mark.asyncio
async def test_kill_is_idempotent_and_updates_reason(tmp_path):
    reg = SQLiteKillRegistry(str(tmp_path / "kill.db"))
    await reg.kill("s1", reason="first")
    await reg.kill("s1", reason="second")  # idempotent — overrides reason
    assert await reg.is_killed("s1") is True
    assert await reg.reason_for("s1") == "second"
    reg.close()


@pytest.mark.asyncio
async def test_clear_restores_session(tmp_path):
    reg = SQLiteKillRegistry(str(tmp_path / "kill.db"))
    await reg.kill("s1", reason="x")
    await reg.clear("s1")
    assert await reg.is_killed("s1") is False
    reg.close()


@pytest.mark.asyncio
async def test_persists_across_instances(tmp_path):
    path = str(tmp_path / "kill.db")
    r1 = SQLiteKillRegistry(path)
    await r1.kill("session-a", reason="persistent")
    r1.close()

    r2 = SQLiteKillRegistry(path)
    assert await r2.is_killed("session-a") is True
    assert await r2.reason_for("session-a") == "persistent"
    r2.close()


@pytest.mark.asyncio
async def test_sessions_are_independent(tmp_path):
    reg = SQLiteKillRegistry(str(tmp_path / "kill.db"))
    await reg.kill("s1", reason="r1")
    assert await reg.is_killed("s1") is True
    assert await reg.is_killed("s2") is False
    reg.close()
