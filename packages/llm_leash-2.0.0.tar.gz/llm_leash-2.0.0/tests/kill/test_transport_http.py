"""Tests for HTTPKillRegistry. Mocks urllib.request.urlopen at the module level."""
from __future__ import annotations

import io
import json
from unittest.mock import MagicMock, patch
from urllib.error import HTTPError

import pytest

from llm_leash.kill.transport_http import HTTPKillRegistry


def _ok_response(body: dict) -> MagicMock:
    cm = MagicMock()
    cm.__enter__.return_value = io.BytesIO(json.dumps(body).encode())
    cm.__exit__.return_value = False
    return cm


def _empty_response() -> MagicMock:
    cm = MagicMock()
    cm.__enter__.return_value = io.BytesIO(b"")
    cm.__exit__.return_value = False
    return cm


@pytest.mark.asyncio
async def test_http_is_killed_returns_true_when_service_says_so():
    reg = HTTPKillRegistry("http://kill.local")
    with patch(
        "llm_leash.kill.transport_http.urlopen",
        return_value=_ok_response({"killed": True, "reason": "abuse"}),
    ):
        assert await reg.is_killed("s1") is True


@pytest.mark.asyncio
async def test_http_is_killed_returns_false_when_not_killed():
    reg = HTTPKillRegistry("http://kill.local")
    with patch(
        "llm_leash.kill.transport_http.urlopen",
        return_value=_ok_response({"killed": False, "reason": None}),
    ):
        assert await reg.is_killed("s1") is False


@pytest.mark.asyncio
async def test_http_is_killed_fail_open_on_404():
    reg = HTTPKillRegistry("http://kill.local")
    err = HTTPError("http://kill.local/kill/x", 404, "not found", {}, None)
    with patch("llm_leash.kill.transport_http.urlopen", side_effect=err):
        assert await reg.is_killed("s1") is False


@pytest.mark.asyncio
async def test_http_is_killed_fail_open_on_network_error():
    from urllib.error import URLError
    reg = HTTPKillRegistry("http://kill.local")
    with patch(
        "llm_leash.kill.transport_http.urlopen",
        side_effect=URLError("connection refused"),
    ):
        # Network failure → fail-open on reads.
        assert await reg.is_killed("s1") is False


@pytest.mark.asyncio
async def test_http_kill_posts_reason():
    reg = HTTPKillRegistry("http://kill.local")
    captured = {}

    def fake_urlopen(req, timeout=None):
        captured["url"] = req.full_url
        captured["method"] = req.get_method()
        captured["body"] = req.data
        return _empty_response()

    with patch("llm_leash.kill.transport_http.urlopen", side_effect=fake_urlopen):
        await reg.kill("session-x", reason="manual abort")

    assert captured["url"].endswith("/kill/session-x")
    assert captured["method"] == "POST"
    assert json.loads(captured["body"]) == {"reason": "manual abort"}


@pytest.mark.asyncio
async def test_http_clear_issues_delete():
    reg = HTTPKillRegistry("http://kill.local")
    captured = {}

    def fake_urlopen(req, timeout=None):
        captured["method"] = req.get_method()
        return _empty_response()

    with patch("llm_leash.kill.transport_http.urlopen", side_effect=fake_urlopen):
        await reg.clear("session-x")

    assert captured["method"] == "DELETE"


@pytest.mark.asyncio
async def test_http_clear_tolerates_404():
    reg = HTTPKillRegistry("http://kill.local")
    err = HTTPError("http://kill.local/kill/x", 404, "not found", {}, None)
    with patch("llm_leash.kill.transport_http.urlopen", side_effect=err):
        await reg.clear("session-x")  # no raise


@pytest.mark.asyncio
async def test_http_reason_for_returns_reason():
    reg = HTTPKillRegistry("http://kill.local")
    with patch(
        "llm_leash.kill.transport_http.urlopen",
        return_value=_ok_response({"killed": True, "reason": "exceeded budget"}),
    ):
        assert await reg.reason_for("s1") == "exceeded budget"


@pytest.mark.asyncio
async def test_http_reason_for_missing_returns_none():
    reg = HTTPKillRegistry("http://kill.local")
    err = HTTPError("http://kill.local/kill/x", 404, "not found", {}, None)
    with patch("llm_leash.kill.transport_http.urlopen", side_effect=err):
        assert await reg.reason_for("s1") is None
