"""Tests for HitlQueue (InMemory + SQLite) and QueueBackedHitlGate."""
from __future__ import annotations

import asyncio

import pytest

from llm_leash.hitl.queue import (
    InMemoryHitlQueue,
    QueueBackedHitlGate,
    SQLiteHitlQueue,
)
from llm_leash.types import Decision, LeashRejectedByHuman, ToolCall


def _call() -> ToolCall:
    return ToolCall(
        tool="read_file", args={"path": "/etc/hosts"},
        session_id="s1", tenant_id=None,
    )


def _decision() -> Decision:
    return Decision(action="hitl", rule_id="r", reason="needs approval")


# ─── InMemoryHitlQueue ──────────────────────────────────────


@pytest.mark.asyncio
async def test_inmem_enqueue_returns_id():
    q = InMemoryHitlQueue()
    rid = await q.enqueue(_call(), _decision())
    assert isinstance(rid, str)
    assert len(rid) > 0


@pytest.mark.asyncio
async def test_inmem_status_pending_after_enqueue():
    q = InMemoryHitlQueue()
    rid = await q.enqueue(_call(), _decision())
    status, reason = await q.status(rid)
    assert status == "pending"
    assert reason is None


@pytest.mark.asyncio
async def test_inmem_approve_resolves():
    q = InMemoryHitlQueue()
    rid = await q.enqueue(_call(), _decision())
    await q.approve(rid)
    status, _ = await q.status(rid)
    assert status == "approved"


@pytest.mark.asyncio
async def test_inmem_reject_resolves_with_reason():
    q = InMemoryHitlQueue()
    rid = await q.enqueue(_call(), _decision())
    await q.reject(rid, reason="rate-limited")
    status, reason = await q.status(rid)
    assert status == "rejected"
    assert reason == "rate-limited"


@pytest.mark.asyncio
async def test_inmem_status_unknown_id():
    q = InMemoryHitlQueue()
    status, _ = await q.status("no-such-id")
    assert status == "rejected"


@pytest.mark.asyncio
async def test_inmem_approve_unknown_is_noop():
    q = InMemoryHitlQueue()
    await q.approve("no-such-id")  # no exception


@pytest.mark.asyncio
async def test_inmem_double_approve_noop():
    q = InMemoryHitlQueue()
    rid = await q.enqueue(_call(), _decision())
    await q.approve(rid)
    await q.approve(rid)  # idempotent
    status, _ = await q.status(rid)
    assert status == "approved"


@pytest.mark.asyncio
async def test_inmem_list_pending_includes_only_pending():
    q = InMemoryHitlQueue()
    r1 = await q.enqueue(_call(), _decision())
    r2 = await q.enqueue(_call(), _decision())
    await q.approve(r1)
    items = await q.list_pending()
    assert len(items) == 1
    assert items[0].request_id == r2


# ─── SQLiteHitlQueue ────────────────────────────────────────


@pytest.mark.asyncio
async def test_sqlite_round_trip(tmp_path):
    q = SQLiteHitlQueue(str(tmp_path / "hitl.db"))
    rid = await q.enqueue(_call(), _decision())
    status, _ = await q.status(rid)
    assert status == "pending"
    await q.approve(rid)
    status, _ = await q.status(rid)
    assert status == "approved"
    q.close()


@pytest.mark.asyncio
async def test_sqlite_persists_across_instances(tmp_path):
    path = str(tmp_path / "hitl.db")
    q1 = SQLiteHitlQueue(path)
    rid = await q1.enqueue(_call(), _decision())
    q1.close()

    q2 = SQLiteHitlQueue(path)
    items = await q2.list_pending()
    assert len(items) == 1
    assert items[0].request_id == rid
    assert items[0].tool == "read_file"
    assert items[0].args == {"path": "/etc/hosts"}
    q2.close()


@pytest.mark.asyncio
async def test_sqlite_reject_with_reason_persists(tmp_path):
    q = SQLiteHitlQueue(str(tmp_path / "hitl.db"))
    rid = await q.enqueue(_call(), _decision())
    await q.reject(rid, reason="not today")
    status, reason = await q.status(rid)
    assert status == "rejected"
    assert reason == "not today"
    q.close()


@pytest.mark.asyncio
async def test_sqlite_status_unknown_id(tmp_path):
    q = SQLiteHitlQueue(str(tmp_path / "hitl.db"))
    status, _ = await q.status("ghost-id")
    assert status == "rejected"
    q.close()


# ─── QueueBackedHitlGate ────────────────────────────────────


@pytest.mark.asyncio
async def test_gate_approves_when_operator_approves():
    q = InMemoryHitlQueue()
    gate = QueueBackedHitlGate(q, timeout_secs=5.0, poll_interval_secs=0.01)

    async def operator() -> None:
        await asyncio.sleep(0.02)
        items = await q.list_pending()
        assert len(items) == 1
        await q.approve(items[0].request_id)

    op_task = asyncio.create_task(operator())
    # request() returns normally on approve
    await gate.request(_call(), _decision())
    await op_task


@pytest.mark.asyncio
async def test_gate_rejects_when_operator_rejects():
    q = InMemoryHitlQueue()
    gate = QueueBackedHitlGate(q, timeout_secs=5.0, poll_interval_secs=0.01)

    async def operator() -> None:
        await asyncio.sleep(0.02)
        items = await q.list_pending()
        await q.reject(items[0].request_id, reason="denied by operator")

    op_task = asyncio.create_task(operator())
    with pytest.raises(LeashRejectedByHuman) as exc_info:
        await gate.request(_call(), _decision())
    assert "denied by operator" in str(exc_info.value)
    await op_task


@pytest.mark.asyncio
async def test_gate_times_out_when_no_decision():
    q = InMemoryHitlQueue()
    gate = QueueBackedHitlGate(q, timeout_secs=0.05, poll_interval_secs=0.01)
    with pytest.raises(LeashRejectedByHuman) as exc_info:
        await gate.request(_call(), _decision())
    assert "timeout" in str(exc_info.value).lower()
    # Item gets auto-rejected on timeout, no longer pending
    pending = await q.list_pending()
    assert pending == []
