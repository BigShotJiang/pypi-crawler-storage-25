"""Tests for hitl.resume convenience helpers."""
from __future__ import annotations

import pytest

from llm_leash.hitl.queue import InMemoryHitlQueue
from llm_leash.hitl.resume import approve, pending, reject
from llm_leash.types import Decision, ToolCall


def _call() -> ToolCall:
    return ToolCall(tool="t", args={"x": 1}, session_id="s", tenant_id=None)


def _decision() -> Decision:
    return Decision(action="hitl", rule_id="r", reason="ask")


@pytest.mark.asyncio
async def test_pending_returns_only_pending_items():
    q = InMemoryHitlQueue()
    r1 = await q.enqueue(_call(), _decision())
    r2 = await q.enqueue(_call(), _decision())
    await q.approve(r1)
    items = await pending(q)
    assert [i.request_id for i in items] == [r2]


@pytest.mark.asyncio
async def test_approve_helper():
    q = InMemoryHitlQueue()
    rid = await q.enqueue(_call(), _decision())
    await approve(q, rid)
    status, _ = await q.status(rid)
    assert status == "approved"


@pytest.mark.asyncio
async def test_reject_helper_records_reason():
    q = InMemoryHitlQueue()
    rid = await q.enqueue(_call(), _decision())
    await reject(q, rid, "no")
    status, reason = await q.status(rid)
    assert status == "rejected"
    assert reason == "no"
