"""WebhookHitlGate tests. urllib.request.urlopen is mocked."""
from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from llm_leash.hitl.webhook import WebhookHitlGate
from llm_leash.types import Decision, LeashRejectedByHuman, ToolCall


def _call() -> ToolCall:
    return ToolCall(
        tool="anthropic.call",
        args={"model": "claude-haiku-4-5"},
        session_id="s1",
    )


def _decision() -> Decision:
    return Decision(action="hitl", rule_id="hitl_threshold", reason="80% of cap")


def _mock_response(body: dict[str, Any]) -> MagicMock:
    resp = MagicMock()
    resp.read.return_value = json.dumps(body).encode()
    resp.__enter__ = lambda s: s
    resp.__exit__ = MagicMock(return_value=False)
    return resp


@pytest.mark.asyncio
async def test_approved_on_first_poll():
    post_resp = _mock_response({"request_id": "r1", "status": "pending"})
    poll_resp = _mock_response({"status": "approved"})

    with patch("llm_leash.hitl.webhook.urlopen", side_effect=[post_resp, poll_resp]):
        gate = WebhookHitlGate("http://example.com/hitl", poll_interval_secs=0)
        await gate.request(_call(), _decision())


@pytest.mark.asyncio
async def test_rejected_raises():
    post_resp = _mock_response({"request_id": "r1", "status": "pending"})
    poll_resp = _mock_response({"status": "rejected", "reason": "no go"})

    with patch("llm_leash.hitl.webhook.urlopen", side_effect=[post_resp, poll_resp]):
        gate = WebhookHitlGate("http://example.com/hitl", poll_interval_secs=0)
        with pytest.raises(LeashRejectedByHuman) as exc_info:
            await gate.request(_call(), _decision())
        assert "no go" in str(exc_info.value)


@pytest.mark.asyncio
async def test_pending_then_approved():
    post_resp = _mock_response({"request_id": "r1", "status": "pending"})
    poll1 = _mock_response({"status": "pending"})
    poll2 = _mock_response({"status": "pending"})
    poll3 = _mock_response({"status": "approved"})

    with patch("llm_leash.hitl.webhook.urlopen", side_effect=[post_resp, poll1, poll2, poll3]):
        gate = WebhookHitlGate("http://example.com/hitl", poll_interval_secs=0)
        await gate.request(_call(), _decision())


@pytest.mark.asyncio
async def test_timeout_raises():
    post_resp = _mock_response({"request_id": "r1", "status": "pending"})
    always_pending = _mock_response({"status": "pending"})

    with patch("llm_leash.hitl.webhook.urlopen") as mock_open:
        mock_open.side_effect = [post_resp] + [always_pending] * 100
        gate = WebhookHitlGate(
            "http://example.com/hitl",
            timeout_secs=0.01,
            poll_interval_secs=0,
        )
        with pytest.raises(LeashRejectedByHuman) as exc_info:
            await gate.request(_call(), _decision())
        assert "timeout" in str(exc_info.value).lower()


@pytest.mark.asyncio
async def test_post_body_contains_session_id():
    post_resp = _mock_response({"request_id": "r1", "status": "pending"})
    poll_resp = _mock_response({"status": "approved"})

    captured: list[Any] = []

    def fake_urlopen(req: Any, *a: Any, **kw: Any) -> Any:
        captured.append(req)
        if len(captured) == 1:
            return post_resp
        return poll_resp

    with patch("llm_leash.hitl.webhook.urlopen", side_effect=fake_urlopen):
        gate = WebhookHitlGate("http://example.com/hitl", poll_interval_secs=0)
        await gate.request(_call(), _decision())

    body = json.loads(captured[0].data)
    assert body["session_id"] == "s1"
    assert body["rule_id"] == "hitl_threshold"
