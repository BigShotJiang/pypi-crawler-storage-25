"""InMemoryHitlGate tests."""
from __future__ import annotations

import pytest

from llm_leash.hitl.gate import InMemoryHitlGate
from llm_leash.types import Decision, LeashRejectedByHuman, ToolCall


def _call() -> ToolCall:
    return ToolCall(tool="anthropic.call", args={"model": "claude-haiku-4-5"}, session_id="s1")


def _decision() -> Decision:
    return Decision(action="hitl", rule_id="hitl_threshold", reason="approaching budget cap")


@pytest.mark.asyncio
async def test_default_approve_does_not_raise():
    gate = InMemoryHitlGate(default="approve")
    await gate.request(_call(), _decision())


@pytest.mark.asyncio
async def test_default_reject_raises():
    gate = InMemoryHitlGate(default="reject")
    with pytest.raises(LeashRejectedByHuman) as exc_info:
        await gate.request(_call(), _decision())
    assert exc_info.value.rule_id == "hitl_threshold"


@pytest.mark.asyncio
async def test_requests_recorded():
    gate = InMemoryHitlGate(default="approve")
    assert gate.requests == []
    await gate.request(_call(), _decision())
    assert len(gate.requests) == 1
    assert gate.requests[0]["call"].session_id == "s1"


@pytest.mark.asyncio
async def test_multiple_requests_all_recorded():
    gate = InMemoryHitlGate(default="approve")
    for _ in range(3):
        await gate.request(_call(), _decision())
    assert len(gate.requests) == 3


@pytest.mark.asyncio
async def test_reject_reason_preserved():
    gate = InMemoryHitlGate(default="reject", reject_reason="not approved")
    with pytest.raises(LeashRejectedByHuman) as exc_info:
        await gate.request(_call(), _decision())
    assert "not approved" in str(exc_info.value)


@pytest.mark.asyncio
async def test_approve_after_reject_is_independent():
    gate_a = InMemoryHitlGate(default="approve")
    gate_r = InMemoryHitlGate(default="reject")
    await gate_a.request(_call(), _decision())
    with pytest.raises(LeashRejectedByHuman):
        await gate_r.request(_call(), _decision())
