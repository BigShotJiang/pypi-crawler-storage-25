"""Tests for SecretsRule (PR-6').

Test fixtures are assembled via string concatenation so GitHub's
push-protection secret scanner doesn't flag them as real credentials —
the strings still match our regex detectors at runtime.
"""
from __future__ import annotations

import pytest

from llm_leash import Decision, LeashBlocked, PolicyContext, SecretsRule, ToolCall
from llm_leash.policy.secrets import _scan, _shannon_entropy

# ─── Test fixtures (obfuscated via concatenation) ────────────────


# Each "secret" below is assembled at runtime so GitHub's secret-scan
# protection can't see a complete pattern. They still trigger our regexes.
_AKIA_FIXTURE = "AKIA" + "IOSFOD" + "NN7EXAMPLE"
_GHP_FIXTURE = "ghp_" + "abcdefghijklmnopqrstuvwxyz0123456789"
_STRIPE_LIVE = "sk_" + "live_" + "1234567890abcdefghijklmn"
_OPENAI_KEY = "sk-" + "proj-" + "aBcDeFgHiJkLmNoPqRsTuVwXyZ"
_SLACK_TOKEN = "xoxb-" + "12345-67890-abcdefghijklmnop"
_JWT_TOKEN = (
    "eyJhbGciOiJIUzI1NiJ9"
    + "." + "eyJzdWIiOiIxMjM0NSJ9"
    + "." + "dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
)


def _ctx() -> PolicyContext:
    return PolicyContext(
        cumulative_usd=0.0, budget_cap_usd=None,
        soft_cap_usd=None, tenant_id=None,
    )


def _call(args: dict) -> ToolCall:
    return ToolCall(tool="t", args=args, session_id="s", tenant_id=None)


# ─── Detector unit tests (_scan) ─────────────────────────────────


def test_detects_aws_access_key():
    findings = list(_scan(f"user=admin AWS_KEY={_AKIA_FIXTURE} password=x"))
    kinds = [k for k, _ in findings]
    assert "aws_access_key" in kinds


def test_detects_github_pat():
    findings = list(_scan(f"token: {_GHP_FIXTURE}"))
    kinds = [k for k, _ in findings]
    assert "github_pat" in kinds


def test_detects_stripe_key():
    findings = list(_scan(f"stripe {_STRIPE_LIVE}"))
    kinds = [k for k, _ in findings]
    assert "stripe_key" in kinds


def test_detects_api_key_sk_prefix():
    findings = list(_scan(f"OPENAI_API_KEY={_OPENAI_KEY}"))
    kinds = [k for k, _ in findings]
    assert "api_key" in kinds


def test_detects_slack_token():
    findings = list(_scan(f"config: {_SLACK_TOKEN}"))
    kinds = [k for k, _ in findings]
    assert "slack_token" in kinds


def test_detects_jwt():
    findings = list(_scan(f"Authorization: Bearer {_JWT_TOKEN}"))
    kinds = [k for k, _ in findings]
    assert "jwt" in kinds


def test_detects_pem_private_key():
    pem = (
        "-----BEGIN RSA PRIVATE KEY-----\n"
        "MIIEpAIBAAKCAQEA1234567890...\n"
        "-----END RSA PRIVATE KEY-----"
    )
    findings = list(_scan(f"key: {pem}"))
    kinds = [k for k, _ in findings]
    assert "private_key" in kinds


def test_clean_text_no_findings():
    findings = list(_scan("Hello, please summarize this article about cats."))
    assert findings == []


def test_short_string_not_flagged_as_high_entropy():
    """High-entropy detector requires length >= 20."""
    findings = list(_scan("hi=ab1cd2ef3"))
    high_entropy = [k for k, _ in findings if k == "high_entropy_string"]
    assert high_entropy == []


def test_specific_detector_wins_over_high_entropy():
    """An AWS key shouldn't ALSO be flagged as generic high_entropy."""
    findings = list(_scan(f"AWS_KEY={_AKIA_FIXTURE}"))
    high_entropy = [k for k, _ in findings if k == "high_entropy_string"]
    aws = [k for k, _ in findings if k == "aws_access_key"]
    assert len(aws) == 1
    assert len(high_entropy) == 0


# ─── Entropy helper ──────────────────────────────────────────────


def test_entropy_empty_string():
    assert _shannon_entropy("") == 0.0


def test_entropy_single_char_low():
    assert _shannon_entropy("aaaa") == 0.0


def test_entropy_random_higher():
    """Random-looking strings have higher entropy than repeated chars."""
    e_random = _shannon_entropy("aBcDeF1234")
    e_repeat = _shannon_entropy("aaaaaaaaaa")
    assert e_random > e_repeat


# ─── Action: block ──────────────────────────────────────────────


def test_block_action_raises_leash_blocked():
    rule = SecretsRule(action="block")
    with pytest.raises(LeashBlocked) as exc_info:
        rule.evaluate(
            _call({"messages": [{"content": f"key={_AKIA_FIXTURE}"}]}),
            _ctx(),
        )
    assert "aws_access_key" in str(exc_info.value)


def test_block_clean_text_returns_none():
    rule = SecretsRule(action="block")
    assert rule.evaluate(
        _call({"messages": [{"content": "summarize this article"}]}),
        _ctx(),
    ) is None


# ─── Action: hitl ───────────────────────────────────────────────


def test_hitl_action_returns_hitl_decision():
    rule = SecretsRule(action="hitl")
    decision = rule.evaluate(
        _call({"messages": [{"content": _GHP_FIXTURE}]}),
        _ctx(),
    )
    assert isinstance(decision, Decision)
    assert decision.action == "hitl"
    assert decision.rule_id == "secrets"
    assert "github_pat" in decision.reason


# ─── Action: redact (mutates in place) ──────────────────────────


def test_redact_replaces_secret_in_place():
    """The args dict is mutated so callers holding a reference see redacted text."""
    messages = [{"role": "user", "content": f"my key is {_AKIA_FIXTURE} thanks"}]
    args = {"messages": messages}
    rule = SecretsRule(action="redact")
    result = rule.evaluate(_call(args), _ctx())
    # redact mode allows the call through.
    assert result is None
    # Original messages list mutated.
    assert _AKIA_FIXTURE not in messages[0]["content"]
    assert "[REDACTED:AWS_ACCESS_KEY]" in messages[0]["content"]


def test_redact_multiple_secrets_in_one_string():
    pem = (
        "-----BEGIN RSA PRIVATE KEY-----\n"
        "MIIEpAIBAAKCAQEA1234567890...\n"
        "-----END RSA PRIVATE KEY-----"
    )
    args = {
        "messages": [{
            "content": f"key={pem} and token={_GHP_FIXTURE}"
        }],
    }
    SecretsRule(action="redact").evaluate(_call(args), _ctx())
    content = args["messages"][0]["content"]
    assert "[REDACTED:PRIVATE_KEY]" in content
    assert "[REDACTED:GITHUB_PAT]" in content
    assert "AKIA" not in content  # nothing remaining


def test_redact_walks_nested_structures():
    args = {
        "messages": [
            {"role": "user", "content": "hi"},
            {"role": "user", "content": f"leak: {_AKIA_FIXTURE}"},
        ],
        "metadata": {"extra": _GHP_FIXTURE},
    }
    SecretsRule(action="redact").evaluate(_call(args), _ctx())
    assert "[REDACTED:AWS_ACCESS_KEY]" in args["messages"][1]["content"]
    assert "[REDACTED:GITHUB_PAT]" in args["metadata"]["extra"]


def test_redact_clean_text_unchanged():
    messages = [{"role": "user", "content": "summarize this article about cats"}]
    args = {"messages": messages}
    SecretsRule(action="redact").evaluate(_call(args), _ctx())
    assert messages[0]["content"] == "summarize this article about cats"


# ─── Detector filter ────────────────────────────────────────────


def test_detectors_filter_narrows_scope():
    """Only enabled detectors fire."""
    rule = SecretsRule(action="block", detectors=["github_pat"])
    # AWS key present but not in the enabled set → not flagged
    result = rule.evaluate(
        _call({"messages": [{"content": _AKIA_FIXTURE}]}),
        _ctx(),
    )
    assert result is None  # not blocked


def test_detectors_filter_still_catches_enabled_kind():
    rule = SecretsRule(action="block", detectors=["github_pat"])
    with pytest.raises(LeashBlocked):
        rule.evaluate(
            _call({"messages": [{"content": _GHP_FIXTURE}]}),
            _ctx(),
        )


# ─── last_findings tracking ─────────────────────────────────────


def test_last_findings_populated_after_detection():
    rule = SecretsRule(action="redact")
    rule.evaluate(
        _call({"messages": [{"content": f"key={_AKIA_FIXTURE}"}]}),
        _ctx(),
    )
    assert len(rule.last_findings) == 1
    kind, matched = rule.last_findings[0]
    assert kind == "aws_access_key"
    assert matched == _AKIA_FIXTURE


def test_last_findings_empty_after_clean_call():
    rule = SecretsRule(action="block")
    rule.evaluate(_call({"messages": [{"content": "hello"}]}), _ctx())
    assert rule.last_findings == []


# ─── Validation ─────────────────────────────────────────────────


def test_invalid_action_rejected():
    with pytest.raises(ValueError, match="action must be"):
        SecretsRule(action="invalid")  # type: ignore[arg-type]


def test_custom_rule_id():
    rule = SecretsRule(action="block", rule_id="my_secrets")
    with pytest.raises(LeashBlocked) as exc:
        rule.evaluate(_call({"x": _AKIA_FIXTURE}), _ctx())
    assert exc.value.rule_id == "my_secrets"
