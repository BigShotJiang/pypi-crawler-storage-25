import pytest

from llm_leash.policy.engine import PolicyEngine
from llm_leash.types import Decision, LeashBlocked, PolicyContext, ToolCall


def _ctx() -> PolicyContext:
    return PolicyContext(
        cumulative_usd=0.0, budget_cap_usd=None,
        soft_cap_usd=None, tenant_id=None,
    )


def _call() -> ToolCall:
    return ToolCall(tool="llm.call", args={"model": "gpt-4o"}, session_id="s1")


class AllowRule:
    id = "allow_all"
    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        return Decision(action="allow", rule_id=self.id, reason="ok")


class BlockRule:
    id = "block_all"
    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        return Decision(action="block", rule_id=self.id, reason="blocked")


class AbstainRule:
    id = "abstain"
    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        return None


def test_empty_rules_returns_allow():
    engine = PolicyEngine([])
    decision = engine.evaluate(_call(), _ctx())
    assert decision.action == "allow"
    assert decision.rule_id == "engine:default"


def test_first_allow_rule_wins():
    engine = PolicyEngine([AllowRule(), BlockRule()])
    decision = engine.evaluate(_call(), _ctx())
    assert decision.action == "allow"
    assert decision.rule_id == "allow_all"


def test_abstain_then_block():
    engine = PolicyEngine([AbstainRule(), BlockRule()])
    with pytest.raises(LeashBlocked) as exc_info:
        engine.evaluate(_call(), _ctx())
    assert exc_info.value.rule_id == "block_all"


def test_all_abstain_returns_default_allow():
    engine = PolicyEngine([AbstainRule(), AbstainRule()])
    decision = engine.evaluate(_call(), _ctx())
    assert decision.action == "allow"


def test_block_raises_leash_blocked():
    engine = PolicyEngine([BlockRule()])
    with pytest.raises(LeashBlocked) as exc_info:
        engine.evaluate(_call(), _ctx())
    assert "blocked" in str(exc_info.value)
