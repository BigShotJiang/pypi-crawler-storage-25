"""Tests for external scanner Rules (LlamaFirewall, Presidio)."""
from __future__ import annotations

from llm_leash.policy.external import LlamaFirewallRule, PresidioRule, _flatten_text
from llm_leash.types import PolicyContext, ToolCall


def _ctx() -> PolicyContext:
    return PolicyContext(
        cumulative_usd=0.0, budget_cap_usd=None,
        soft_cap_usd=None, tenant_id=None,
    )


def _call(args: dict) -> ToolCall:
    return ToolCall(tool="t", args=args, session_id="s", tenant_id=None)


# ─── _flatten_text ─────────────────────────────────────────


def test_flatten_text_walks_nested_structures():
    args = {
        "messages": [
            {"role": "user", "content": "hello"},
            {"role": "user", "content": "world"},
        ],
        "model": "gpt-4o",
    }
    text = _flatten_text(args)
    assert "hello" in text
    assert "world" in text
    assert "gpt-4o" in text


def test_flatten_text_empty_dict():
    assert _flatten_text({}) == ""


def test_flatten_text_ignores_non_string_scalars():
    text = _flatten_text({"k": 42, "m": True, "n": None, "s": "real"})
    assert text == "real"


# ─── LlamaFirewallRule ─────────────────────────────────────


class _FakeLlamaResult:
    def __init__(self, decision: str, score: float) -> None:
        self.decision = decision
        self.score = score


class _FakeLlamaScanner:
    def __init__(self, decision: str = "ALLOW", score: float = 0.0) -> None:
        self._d = decision
        self._s = score
        self.calls = 0

    def scan(self, messages):
        self.calls += 1
        return _FakeLlamaResult(self._d, self._s)


def test_llama_abstains_when_below_threshold():
    rule = LlamaFirewallRule(_FakeLlamaScanner("BLOCK", 0.3), score_threshold=0.5)
    assert rule.evaluate(_call({"messages": [{"content": "hi"}]}), _ctx()) is None


def test_llama_blocks_above_threshold():
    rule = LlamaFirewallRule(_FakeLlamaScanner("BLOCK", 0.9), score_threshold=0.5)
    d = rule.evaluate(_call({"messages": [{"content": "rm -rf /"}]}), _ctx())
    assert d is not None
    assert d.action == "block"
    assert "0.90" in d.reason


def test_llama_hitl_for_human_review():
    rule = LlamaFirewallRule(
        _FakeLlamaScanner("HUMAN_IN_THE_LOOP_REQUIRED", 0.8),
        score_threshold=0.5,
    )
    d = rule.evaluate(_call({"messages": [{"content": "test"}]}), _ctx())
    assert d is not None
    assert d.action == "hitl"


def test_llama_allow_returns_none():
    rule = LlamaFirewallRule(_FakeLlamaScanner("ALLOW", 1.0), score_threshold=0.5)
    assert rule.evaluate(_call({"messages": [{"content": "hello"}]}), _ctx()) is None


def test_llama_empty_args_skipped():
    scanner = _FakeLlamaScanner("BLOCK", 1.0)
    rule = LlamaFirewallRule(scanner)
    assert rule.evaluate(_call({}), _ctx()) is None
    assert scanner.calls == 0


def test_llama_custom_rule_id():
    rule = LlamaFirewallRule(
        _FakeLlamaScanner("BLOCK", 0.9), rule_id="custom_llama",
    )
    d = rule.evaluate(_call({"messages": [{"content": "x"}]}), _ctx())
    assert d is not None
    assert d.rule_id == "custom_llama"


# ─── PresidioRule ──────────────────────────────────────────


class _FakeRecognizerResult:
    def __init__(self, entity_type: str, score: float) -> None:
        self.entity_type = entity_type
        self.score = score


class _FakePresidioAnalyzer:
    def __init__(self, findings: list[_FakeRecognizerResult] | None = None) -> None:
        self._findings = findings or []
        self.last_call: dict | None = None

    def analyze(self, text, language="en", **kwargs):
        self.last_call = {"text": text, "language": language, **kwargs}
        return self._findings


def test_presidio_blocks_when_pii_above_threshold():
    rule = PresidioRule(
        _FakePresidioAnalyzer([
            _FakeRecognizerResult("EMAIL_ADDRESS", 0.95),
            _FakeRecognizerResult("PHONE_NUMBER", 0.92),
        ]),
        block_above_score=0.85,
    )
    d = rule.evaluate(_call({"messages": [{"content": "test"}]}), _ctx())
    assert d is not None
    assert d.action == "block"
    assert "EMAIL_ADDRESS" in d.reason
    assert "PHONE_NUMBER" in d.reason


def test_presidio_abstains_below_threshold():
    rule = PresidioRule(
        _FakePresidioAnalyzer([_FakeRecognizerResult("EMAIL_ADDRESS", 0.4)]),
        block_above_score=0.85,
    )
    assert rule.evaluate(_call({"messages": [{"content": "x"}]}), _ctx()) is None


def test_presidio_no_findings_returns_none():
    rule = PresidioRule(_FakePresidioAnalyzer([]))
    assert rule.evaluate(_call({"messages": [{"content": "x"}]}), _ctx()) is None


def test_presidio_passes_entities_filter_to_analyzer():
    analyzer = _FakePresidioAnalyzer([])
    rule = PresidioRule(analyzer, entities=["EMAIL_ADDRESS", "PHONE_NUMBER"])
    rule.evaluate(_call({"messages": [{"content": "x"}]}), _ctx())
    assert analyzer.last_call is not None
    assert analyzer.last_call["entities"] == ["EMAIL_ADDRESS", "PHONE_NUMBER"]


def test_presidio_empty_args_skipped():
    analyzer = _FakePresidioAnalyzer([_FakeRecognizerResult("EMAIL_ADDRESS", 0.99)])
    rule = PresidioRule(analyzer)
    assert rule.evaluate(_call({}), _ctx()) is None
    assert analyzer.last_call is None


def test_presidio_custom_rule_id():
    rule = PresidioRule(
        _FakePresidioAnalyzer([_FakeRecognizerResult("SSN", 0.99)]),
        rule_id="my_presidio",
    )
    d = rule.evaluate(_call({"messages": [{"content": "x"}]}), _ctx())
    assert d is not None
    assert d.rule_id == "my_presidio"
