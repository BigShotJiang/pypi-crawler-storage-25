from llm_leash.policy.pii import PiiRedactor


class TestRedact:
    def test_email_redacted(self):
        r = PiiRedactor()
        out = r.redact("contact alice@example.com today")
        assert "alice@example.com" not in out
        assert "[REDACTED:EMAIL]" in out

    def test_ssn_redacted(self):
        r = PiiRedactor()
        out = r.redact("SSN: 123-45-6789")
        assert "123-45-6789" not in out
        assert "[REDACTED:SSN]" in out

    def test_phone_redacted(self):
        r = PiiRedactor()
        out = r.redact("call me at 555-867-5309")
        assert "555-867-5309" not in out
        assert "[REDACTED:PHONE]" in out

    def test_credit_card_redacted(self):
        r = PiiRedactor()
        out = r.redact("card: 4111 1111 1111 1111")
        assert "4111" not in out
        assert "[REDACTED:CREDIT_CARD]" in out

    def test_clean_text_unchanged(self):
        r = PiiRedactor()
        text = "The weather is nice today."
        assert r.redact(text) == text

    def test_multiple_pii_in_one_string(self):
        r = PiiRedactor()
        out = r.redact("email: bob@corp.io SSN: 999-88-7777")
        assert "[REDACTED:EMAIL]" in out
        assert "[REDACTED:SSN]" in out


class TestScan:
    def test_scan_finds_email(self):
        r = PiiRedactor()
        types = r.scan("hello user@example.org")
        assert "EMAIL" in types

    def test_scan_returns_sorted_unique(self):
        r = PiiRedactor()
        types = r.scan("a@b.com c@d.com 123-45-6789")
        assert types == sorted(set(types))
        assert types.count("EMAIL") == 1

    def test_scan_clean_returns_empty(self):
        r = PiiRedactor()
        assert r.scan("hello world") == []


class TestRedactArgs:
    def test_flat_dict(self):
        r = PiiRedactor()
        args = {"prompt": "write to alice@x.com"}
        out = r.redact_args(args)
        assert "alice@x.com" not in out["prompt"]
        assert "[REDACTED:EMAIL]" in out["prompt"]

    def test_nested_dict(self):
        r = PiiRedactor()
        args = {"messages": [{"role": "user", "content": "SSN 111-22-3333"}]}
        out = r.redact_args(args)
        assert "111-22-3333" not in out["messages"][0]["content"]

    def test_does_not_mutate_original(self):
        r = PiiRedactor()
        args = {"text": "email: a@b.com"}
        r.redact_args(args)
        assert "a@b.com" in args["text"]
