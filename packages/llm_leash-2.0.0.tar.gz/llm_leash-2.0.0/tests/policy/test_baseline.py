"""Tests for BehavioralBaselineRule + BaselineStore implementations."""
from __future__ import annotations

import asyncio
from datetime import datetime

import pytest

from llm_leash import Decision, PolicyContext, ToolCall
from llm_leash.policy.baseline import (
    AgentProfile,
    BehavioralBaselineRule,
    InMemoryBaselineStore,
    SQLiteBaselineStore,
    _update_token_stats,
)


def _ctx() -> PolicyContext:
    return PolicyContext(
        cumulative_usd=0.0, budget_cap_usd=None,
        soft_cap_usd=None, tenant_id="acme",
    )


def _call(
    *,
    agent: str = "analyst",
    model: str = "claude-haiku-4-5",
    max_tokens: int = 100,
    tool: str = "anthropic.messages.create",
    messages: list | None = None,
) -> ToolCall:
    args: dict = {
        "agent_name": agent,
        "model": model,
        "max_tokens": max_tokens,
    }
    if messages is not None:
        args["messages"] = messages
    return ToolCall(tool=tool, args=args, session_id="s1", tenant_id="acme")


class _FixedClock:
    def __init__(self, hour: int = 12) -> None:
        self._hour = hour

    def __call__(self) -> datetime:
        return datetime(2026, 5, 17, self._hour, 0, 0)


# ─── Welford running stats ──────────────────────────────────────


def test_welford_single_sample_mean_equals_value_stddev_zero():
    p = AgentProfile(tenant_id="t", agent_name="a")
    _update_token_stats(p, 100)
    assert p.tokens_n == 1
    assert p.tokens_mean == 100
    assert p.tokens_stddev == 0.0


def test_welford_two_samples_correct_mean_and_stddev():
    p = AgentProfile(tenant_id="t", agent_name="a")
    _update_token_stats(p, 100)
    _update_token_stats(p, 200)
    assert p.tokens_n == 2
    assert p.tokens_mean == 150
    # sample stddev of [100, 200] = sqrt(((100-150)^2 + (200-150)^2) / 1) = sqrt(5000)
    assert p.tokens_stddev == pytest.approx(70.71, rel=0.01)


def test_welford_many_samples_converges():
    """100 samples around 100 ± 10 should give mean ≈ 100, stddev ≈ 10."""
    p = AgentProfile(tenant_id="t", agent_name="a")
    samples = [90, 100, 110, 95, 105, 100, 100, 90, 110, 100] * 10
    for v in samples:
        _update_token_stats(p, v)
    assert p.tokens_n == 100
    assert p.tokens_mean == pytest.approx(100, abs=0.5)
    assert p.tokens_stddev == pytest.approx(7.0, abs=1.5)


# ─── InMemoryBaselineStore ──────────────────────────────────────


@pytest.mark.asyncio
async def test_inmem_store_get_missing_returns_none():
    store = InMemoryBaselineStore()
    assert await store.get("t", "a") is None


@pytest.mark.asyncio
async def test_inmem_store_save_then_get_round_trip():
    store = InMemoryBaselineStore()
    p = AgentProfile(
        tenant_id="t", agent_name="a",
        tokens_n=5, tokens_mean=100, tokens_m2=400,
        models_seen={"claude-haiku-4-5"},
        tool_counts={"x": 3},
    )
    p.hour_histogram[12] = 5
    await store.save(p)

    got = await store.get("t", "a")
    assert got is not None
    assert got.tokens_n == 5
    assert got.tokens_mean == 100
    assert got.models_seen == {"claude-haiku-4-5"}
    assert got.tool_counts == {"x": 3}
    assert got.hour_histogram[12] == 5


@pytest.mark.asyncio
async def test_inmem_store_get_returns_copy_not_reference():
    """Mutating the returned profile must not affect stored state."""
    store = InMemoryBaselineStore()
    await store.save(AgentProfile(
        tenant_id="t", agent_name="a", tokens_n=1, models_seen={"m1"},
    ))
    got = await store.get("t", "a")
    assert got is not None
    got.models_seen.add("LEAKED")
    got.tokens_n = 999

    re_get = await store.get("t", "a")
    assert re_get is not None
    assert "LEAKED" not in re_get.models_seen
    assert re_get.tokens_n == 1


# ─── SQLiteBaselineStore ────────────────────────────────────────


@pytest.mark.asyncio
async def test_sqlite_store_round_trip(tmp_path):
    db_path = tmp_path / "baseline.db"
    store = SQLiteBaselineStore(str(db_path))
    p = AgentProfile(
        tenant_id="acme", agent_name="analyst",
        tokens_n=10, tokens_mean=150.0, tokens_m2=2000.0,
        models_seen={"haiku", "sonnet"},
        tool_counts={"tool_a": 5, "tool_b": 3},
    )
    p.hour_histogram[14] = 7
    await store.save(p)

    got = await store.get("acme", "analyst")
    assert got is not None
    assert got.tokens_n == 10
    assert got.tokens_mean == 150.0
    assert got.models_seen == {"haiku", "sonnet"}
    assert got.tool_counts == {"tool_a": 5, "tool_b": 3}
    assert got.hour_histogram[14] == 7
    store.close()


@pytest.mark.asyncio
async def test_sqlite_store_upsert_overwrites(tmp_path):
    db_path = tmp_path / "baseline.db"
    store = SQLiteBaselineStore(str(db_path))
    await store.save(AgentProfile(
        tenant_id="t", agent_name="a", tokens_n=5,
    ))
    await store.save(AgentProfile(
        tenant_id="t", agent_name="a", tokens_n=10,
    ))
    got = await store.get("t", "a")
    assert got is not None
    assert got.tokens_n == 10  # overwritten
    store.close()


@pytest.mark.asyncio
async def test_sqlite_store_persists_across_instances(tmp_path):
    db_path = tmp_path / "baseline.db"
    s1 = SQLiteBaselineStore(str(db_path))
    await s1.save(AgentProfile(
        tenant_id="t", agent_name="a", tokens_n=42,
        models_seen={"m1"},
    ))
    s1.close()

    s2 = SQLiteBaselineStore(str(db_path))
    got = await s2.get("t", "a")
    assert got is not None
    assert got.tokens_n == 42
    assert got.models_seen == {"m1"}
    s2.close()


# ─── BehavioralBaselineRule — warmup ────────────────────────────


def test_warmup_period_returns_none_even_for_obvious_anomalies():
    """During warmup the rule only observes — no decisions fire."""
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=10, sigma_threshold=3.0,
        flag_new_models=True, on_anomaly="block",
        clock=_FixedClock(),
    )
    # First call sets baseline. Even a wildly different second call shouldn't
    # fire until warmup_calls is reached.
    for _ in range(5):
        result = rule.evaluate(_call(max_tokens=100), _ctx())
        assert result is None

    # Massive deviation but still in warmup — no fire.
    result = rule.evaluate(_call(max_tokens=100_000), _ctx())
    assert result is None


def test_no_agent_name_returns_none():
    """Calls without agent_name are ignored — can't profile."""
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(store, warmup_calls=2, clock=_FixedClock())
    call = ToolCall(tool="t", args={"model": "x"}, session_id="s", tenant_id="t")
    assert rule.evaluate(call, _ctx()) is None


# ─── Anomaly detection (post-warmup) ────────────────────────────


def test_token_spike_after_warmup_fires():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=5, sigma_threshold=3.0,
        flag_new_models=False, clock=_FixedClock(),
    )
    # Warmup with variable token counts so stddev > 0.
    for tokens in [80, 90, 100, 110, 120]:
        rule.evaluate(_call(max_tokens=tokens), _ctx())

    # Massive spike — far beyond mean(=100) + 3·sigma(≈16) = 148.
    decision = rule.evaluate(_call(max_tokens=100_000), _ctx())
    assert isinstance(decision, Decision)
    assert decision.action == "hitl"  # default on_anomaly
    assert "token_spike" in decision.reason


def test_token_spike_within_sigma_does_not_fire():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=5, sigma_threshold=3.0,
        flag_new_models=False, clock=_FixedClock(),
    )
    # Warmup with variability.
    for tokens in [90, 100, 110, 95, 105]:
        rule.evaluate(_call(max_tokens=tokens), _ctx())

    # Within ~3sigma — should NOT fire.
    result = rule.evaluate(_call(max_tokens=120), _ctx())
    assert result is None


def test_new_model_fires_when_enabled():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=3, flag_new_models=True,
        clock=_FixedClock(),
    )
    for _ in range(3):
        rule.evaluate(_call(model="haiku"), _ctx())

    decision = rule.evaluate(_call(model="opus", max_tokens=100), _ctx())
    assert isinstance(decision, Decision)
    assert "new_model" in decision.reason
    assert "opus" in decision.reason


def test_new_model_silent_when_disabled():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=3, flag_new_models=False,
        clock=_FixedClock(),
    )
    for _ in range(3):
        rule.evaluate(_call(model="haiku"), _ctx())

    result = rule.evaluate(_call(model="opus"), _ctx())
    assert result is None


def test_off_hours_fires_when_enabled():
    store = InMemoryBaselineStore()
    clock = _FixedClock(hour=3)  # 03:00 — well outside 9-18
    rule = BehavioralBaselineRule(
        store, warmup_calls=3, flag_new_models=False,
        flag_off_hours=True, business_hours=(9, 18),
        clock=clock,
    )
    for _ in range(3):
        rule.evaluate(_call(max_tokens=100), _ctx())

    decision = rule.evaluate(_call(max_tokens=100), _ctx())
    assert isinstance(decision, Decision)
    assert "off_hours" in decision.reason


def test_off_hours_silent_within_business_window():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=3, flag_new_models=False,
        flag_off_hours=True, business_hours=(9, 18),
        clock=_FixedClock(hour=14),  # within window
    )
    for _ in range(3):
        rule.evaluate(_call(max_tokens=100), _ctx())

    result = rule.evaluate(_call(max_tokens=100), _ctx())
    assert result is None


def test_tool_spam_fires():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=1, flag_new_models=False,
        tool_spam_threshold=10, clock=_FixedClock(),
    )
    # Warm up.
    rule.evaluate(_call(), _ctx())
    # Fire same tool >10 times.
    for _ in range(11):
        rule.evaluate(_call(), _ctx())
    # Next call should observe tool_count > threshold.
    decision = rule.evaluate(_call(), _ctx())
    assert isinstance(decision, Decision)
    assert "tool_spam" in decision.reason


# ─── Action modes ───────────────────────────────────────────────


def test_on_anomaly_block_raises_LeashBlocked():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=3, sigma_threshold=2.0,
        flag_new_models=True, on_anomaly="block",
        clock=_FixedClock(),
    )
    # block mode: anomaly returns Decision(action="block").
    # PolicyEngine.evaluate raises LeashBlocked when it sees action=block.
    # But BehavioralBaselineRule itself just returns the Decision —
    # the engine does the raise. So evaluate returns Decision(block).
    for _ in range(3):
        rule.evaluate(_call(model="haiku"), _ctx())
    decision = rule.evaluate(_call(model="opus"), _ctx())
    assert isinstance(decision, Decision)
    assert decision.action == "block"


def test_on_anomaly_warn_returns_warn_decision():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(
        store, warmup_calls=3, flag_new_models=True, on_anomaly="warn",
        clock=_FixedClock(),
    )
    for _ in range(3):
        rule.evaluate(_call(model="haiku"), _ctx())
    decision = rule.evaluate(_call(model="opus"), _ctx())
    assert isinstance(decision, Decision)
    assert decision.action == "warn"


# ─── Validation ─────────────────────────────────────────────────


def test_invalid_on_anomaly_rejected():
    store = InMemoryBaselineStore()
    with pytest.raises(ValueError, match="on_anomaly"):
        BehavioralBaselineRule(store, on_anomaly="bad")  # type: ignore[arg-type]


def test_invalid_sigma_rejected():
    store = InMemoryBaselineStore()
    with pytest.raises(ValueError, match="sigma_threshold"):
        BehavioralBaselineRule(store, sigma_threshold=-1.0)


def test_invalid_warmup_rejected():
    store = InMemoryBaselineStore()
    with pytest.raises(ValueError, match="warmup_calls"):
        BehavioralBaselineRule(store, warmup_calls=0)


def test_invalid_business_hours_rejected():
    store = InMemoryBaselineStore()
    with pytest.raises(ValueError, match="business_hours"):
        BehavioralBaselineRule(store, business_hours=(18, 9))


# ─── Profile updates accumulate across calls ─────────────────────


def test_profile_updates_persist_between_calls():
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(store, warmup_calls=100, clock=_FixedClock())
    for tokens in [100, 200, 300]:
        rule.evaluate(_call(max_tokens=tokens), _ctx())

    # Fetch profile directly from store to assert updates landed.
    profile = asyncio.run(store.get("acme", "analyst"))
    assert profile is not None
    assert profile.tokens_n == 3
    assert profile.tokens_mean == 200
    assert "claude-haiku-4-5" in profile.models_seen
    assert profile.tool_counts["anthropic.messages.create"] == 3
    assert profile.hour_histogram[12] == 3


def test_tokens_estimate_from_messages_when_no_max_tokens():
    """When max_tokens isn't set, estimate via len(message content) / 4."""
    store = InMemoryBaselineStore()
    rule = BehavioralBaselineRule(store, warmup_calls=100, clock=_FixedClock())
    rule.evaluate(
        ToolCall(
            tool="t",
            args={
                "agent_name": "analyst",
                "model": "haiku",
                # 40 chars → ~10 tokens estimate
                "messages": [{"role": "user", "content": "x" * 40}],
            },
            session_id="s", tenant_id="acme",
        ),
        _ctx(),
    )
    profile = asyncio.run(store.get("acme", "analyst"))
    assert profile is not None
    assert profile.tokens_n == 1
    assert profile.tokens_mean == 10  # 40 / 4
