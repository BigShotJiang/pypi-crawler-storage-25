"""CLI tests for `llm-leash` verify / replay / export."""
from __future__ import annotations

import csv
import io
import json

import pytest

from llm_leash.cli import main


@pytest.fixture
def good_log(tmp_path):
    """Two valid chained model_call events."""
    from llm_leash.audit.schema import ModelCall
    from llm_leash.audit.writer import AuditWriter

    log = tmp_path / "audit.jsonl"
    w = AuditWriter(str(log), fsync=False)
    for _seq in range(2):
        w.write(ModelCall(
            ts="2026-05-16T00:00:00Z",
            session_id="s", tenant_id=None,
            seq=0, prev_hash="x",
            provider="openai", model="gpt-4o",
            input_tokens=10, output_tokens=5, cost_usd=0.001,
            request_hash="r", response_hash="s",
        ))
    w.close()
    return log


def test_cli_verify_good_log_returns_zero(good_log, capsys):
    rc = main(["verify", str(good_log)])
    assert rc == 0
    out = capsys.readouterr().out
    assert "2 events verified" in out


def test_cli_verify_missing_file_returns_one(tmp_path, capsys):
    rc = main(["verify", str(tmp_path / "no_such.jsonl")])
    # Non-existent file → verify_chain returns 0 (no exception) → exit 0.
    # FileNotFoundError path is for explicit broken-state files.
    assert rc == 0


def test_cli_verify_broken_chain_returns_two(tmp_path, capsys):
    log = tmp_path / "broken.jsonl"
    log.write_text(
        '{"kind":"kill","seq":1,"ts":"t","session_id":"s","tenant_id":null,'
        '"prev_hash":"WRONG","reason":"r","hash":"BAD"}\n'
    )
    rc = main(["verify", str(log)])
    assert rc == 2
    err = capsys.readouterr().err
    assert "BROKEN" in err


def test_cli_replay_outputs_jsonl(good_log, capsys):
    rc = main(["replay", str(good_log)])
    assert rc == 0
    out = capsys.readouterr().out.strip().splitlines()
    assert len(out) == 2
    for line in out:
        ev = json.loads(line)
        assert ev["kind"] == "model_call"


def test_cli_export_csv(good_log, capsys):
    rc = main(["export", str(good_log), "--format", "csv"])
    assert rc == 0
    out = capsys.readouterr().out
    rows = list(csv.DictReader(io.StringIO(out)))
    assert len(rows) == 2
    assert rows[0]["model"] == "gpt-4o"


def test_cli_export_json_default(good_log, capsys):
    rc = main(["export", str(good_log)])
    assert rc == 0
    out = capsys.readouterr().out
    arr = json.loads(out)
    assert len(arr) == 2
    assert arr[0]["provider"] == "openai"


@pytest.fixture
def hitl_db(tmp_path):
    """A populated SQLite HITL queue: one pending entry."""
    import asyncio

    from llm_leash.hitl.queue import SQLiteHitlQueue
    from llm_leash.types import Decision, ToolCall

    path = tmp_path / "hitl.db"
    q = SQLiteHitlQueue(str(path))
    rid = asyncio.run(q.enqueue(
        ToolCall(tool="t", args={"x": 1}, session_id="s", tenant_id=None),
        Decision(action="hitl", rule_id="r", reason="needs review"),
    ))
    q.close()
    return path, rid


def test_cli_hitl_list_shows_pending(hitl_db, capsys):
    path, rid = hitl_db
    rc = main(["hitl", "list", str(path)])
    assert rc == 0
    out = capsys.readouterr().out
    row = json.loads(out.strip().splitlines()[0])
    assert row["request_id"] == rid
    assert row["tool"] == "t"


def test_cli_hitl_approve(hitl_db, capsys):
    import asyncio

    from llm_leash.hitl.queue import SQLiteHitlQueue
    path, rid = hitl_db
    rc = main(["hitl", "approve", str(path), rid])
    assert rc == 0
    q = SQLiteHitlQueue(str(path))
    status, _ = asyncio.run(q.status(rid))
    q.close()
    assert status == "approved"


def test_cli_soc2_generates_evidence_pack(good_log, tmp_path, capsys):
    out = tmp_path / "evidence"
    rc = main([
        "soc2", str(good_log),
        "--out", str(out),
        "--period-start", "2026-01-01T00:00:00Z",
        "--period-end", "2026-12-31T23:59:59Z",
        "--org", "Test Co",
    ])
    assert rc == 0  # valid chain → exit 0
    assert (out / "executive-summary.html").exists()
    assert (out / "cc6_access_control.csv").exists()
    assert (out / "cc7_integrity.json").exists()
    assert (out / "bom.json").exists()
    err = capsys.readouterr().err
    assert "SOC 2 pack generated" in err
    assert "VERIFIED" in err


def test_cli_soc2_returns_two_on_broken_chain(tmp_path, capsys):
    log = tmp_path / "broken.jsonl"
    log.write_text(
        '{"kind":"kill","seq":1,"ts":"2026-06-01T00:00:00Z","session_id":"s",'
        '"tenant_id":null,"prev_hash":"WRONG","reason":"r","hash":"BAD"}\n'
    )
    out = tmp_path / "evidence"
    rc = main([
        "soc2", str(log),
        "--out", str(out),
        "--period-start", "2026-01-01T00:00:00Z",
        "--period-end", "2026-12-31T23:59:59Z",
    ])
    assert rc == 2


def test_cli_hitl_reject_records_reason(hitl_db, capsys):
    import asyncio

    from llm_leash.hitl.queue import SQLiteHitlQueue
    path, rid = hitl_db
    rc = main(["hitl", "reject", str(path), rid, "--reason", "not now"])
    assert rc == 0
    q = SQLiteHitlQueue(str(path))
    status, reason = asyncio.run(q.status(rid))
    q.close()
    assert status == "rejected"
    assert reason == "not now"


# ─── Remote ops (CLI → proxy admin API) ────────────────────────────


def test_cli_kill_calls_admin_api(monkeypatch, capsys):
    """`llm-leash kill <id> --proxy URL --admin-token T` POSTs to admin API."""
    captured = {}

    def fake_http(method, base, path, token, body=None, timeout=10.0):
        captured["method"] = method
        captured["base"] = base
        captured["path"] = path
        captured["token"] = token
        captured["body"] = body
        return 200, {"killed": True, "reason": body["reason"]}

    monkeypatch.setattr("llm_leash.cli._http_call", fake_http)
    rc = main([
        "kill", "session-x",
        "--proxy", "http://localhost:8000",
        "--admin-token", "tok",
        "--reason", "abuse",
    ])
    assert rc == 0
    assert captured["method"] == "POST"
    assert captured["base"] == "http://localhost:8000"
    assert captured["path"] == "/admin/kill/session-x"
    assert captured["token"] == "tok"  # noqa: S105 (test fixture)
    assert captured["body"]["reason"] == "abuse"


def test_cli_kill_admin_token_from_env(monkeypatch):
    monkeypatch.setattr("llm_leash.cli._http_call",
                        lambda *a, **kw: (200, {"killed": True}))
    monkeypatch.setenv("LLM_LEASH_ADMIN_TOKEN", "env-token")
    rc = main(["kill", "s", "--proxy", "http://x:8000"])
    assert rc == 0


def test_cli_kill_missing_token_errors(monkeypatch, capsys):
    monkeypatch.delenv("LLM_LEASH_ADMIN_TOKEN", raising=False)
    with pytest.raises(SystemExit):
        main(["kill", "s", "--proxy", "http://x:8000"])


def test_cli_status_prints_summary(monkeypatch, capsys):
    def fake_http(method, base, path, token, body=None, timeout=10.0):
        assert method == "GET"
        assert path == "/admin/stats"
        return 200, {
            "active_sessions": 2,
            "total_spend_usd": 1.2345,
            "hitl_backend": "sqlite",
            "hitl_pending": 1,
            "policy_rules": 3,
            "pii_redactor_enabled": True,
            "top_sessions": [{"session_id": "alice", "cost_usd": 1.0}],
        }

    monkeypatch.setattr("llm_leash.cli._http_call", fake_http)
    rc = main(["status", "--proxy", "http://x:8000", "--admin-token", "t"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "active sessions:    2" in out
    assert "$1.2345" in out
    assert "policy rules:       3" in out
    assert "alice" in out


def test_cli_hitl_list_via_proxy(monkeypatch, capsys):
    def fake_http(method, base, path, token, body=None, timeout=10.0):
        assert path == "/admin/hitl/pending"
        return 200, {
            "hitl_backend": "inmemory",
            "pending": [
                {
                    "request_id": "r1", "created_ts": 0.0,
                    "session_id": "s", "tenant_id": None,
                    "tool": "t", "rule_id": "r", "reason": "x",
                },
            ],
        }

    monkeypatch.setattr("llm_leash.cli._http_call", fake_http)
    rc = main(["hitl", "list", "--proxy", "http://x:8000", "--admin-token", "t"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "r1" in out


def test_cli_hitl_approve_via_proxy(monkeypatch, capsys):
    calls = []

    def fake_http(method, base, path, token, body=None, timeout=10.0):
        calls.append((method, path))
        return 200, {"decision": "approved"}

    monkeypatch.setattr("llm_leash.cli._http_call", fake_http)
    rc = main([
        "hitl", "approve",
        "--proxy", "http://x:8000",
        "--admin-token", "t",
        "abc-123",
    ])
    assert rc == 0
    assert calls[0] == ("POST", "/admin/hitl/abc-123/approve")
    assert "approved abc-123" in capsys.readouterr().out


def test_cli_hitl_reject_via_proxy(monkeypatch):
    calls = []

    def fake_http(method, base, path, token, body=None, timeout=10.0):
        calls.append((method, path, body))
        return 200, {"decision": "rejected"}

    monkeypatch.setattr("llm_leash.cli._http_call", fake_http)
    rc = main([
        "hitl", "reject",
        "--proxy", "http://x:8000",
        "--admin-token", "t",
        "abc-123",
        "--reason", "no",
    ])
    assert rc == 0
    assert calls[0][0] == "POST"
    assert calls[0][1] == "/admin/hitl/abc-123/reject"
    assert calls[0][2]["reason"] == "no"


def test_cli_hitl_requires_path_or_proxy(capsys):
    """`hitl list` with neither <queue.db> nor --proxy errors out."""
    rc = main(["hitl", "list"])
    # No queue_path and no --proxy → returns 2.
    assert rc == 2
    assert "pass <queue.db> or --proxy" in capsys.readouterr().err
