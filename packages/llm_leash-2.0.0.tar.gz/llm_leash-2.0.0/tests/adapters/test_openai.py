"""OpenAI adapter tests. No real API calls — uses FakeOpenAI."""
import pytest

from llm_leash import (
    Firewall,
    HitlThreshold,
    InMemoryHitlGate,
    PiiRedactor,
)
from llm_leash.types import LeashKilled, LeashRejectedByHuman


class _Usage:
    def __init__(self, prompt_tokens: int, completion_tokens: int) -> None:
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _Choice:
    def __init__(self, content: str) -> None:
        self.message = type("Msg", (), {"content": content})()


class _FakeResponse:
    def __init__(self, content: str, in_t: int = 100, out_t: int = 50) -> None:
        self.choices = [_Choice(content)]
        self.usage = _Usage(prompt_tokens=in_t, completion_tokens=out_t)
        self.model = "gpt-4o"


class _FakeCompletions:
    def __init__(self, response: _FakeResponse) -> None:
        self._response = response

    def create(self, **kwargs):
        return self._response


class _FakeChat:
    def __init__(self, response: _FakeResponse) -> None:
        self.completions = _FakeCompletions(response)


class FakeOpenAI:
    def __init__(self, response: _FakeResponse | None = None) -> None:
        self.chat = _FakeChat(response or _FakeResponse("Hello!"))


@pytest.mark.asyncio
async def test_openai_wrap_returns_wrapped_client():
    fw = Firewall()
    client = FakeOpenAI()
    wrapped = fw.wrap(client)
    assert wrapped is not client
    assert hasattr(wrapped.chat, "completions")


@pytest.mark.asyncio
async def test_openai_successful_call_charges_budget():
    fw = Firewall(budget_usd=5.0)
    client = FakeOpenAI(_FakeResponse("hi", in_t=1000, out_t=500))
    wrapped = fw.wrap(client)
    resp = wrapped.chat.completions.create(
        model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
    )
    assert resp.choices[0].message.content == "hi"
    spent = await fw.cumulative_usd()
    # gpt-4o: $2.50/M input + $10/M output
    # 1000 * 2.50/1e6 + 500 * 10/1e6 = 0.0025 + 0.005 = 0.0075
    assert abs(spent - 0.0075) < 1e-6


@pytest.mark.asyncio
async def test_openai_hard_cap_raises_after_first_call():
    fw = Firewall(budget_usd=0.001)  # tiny cap: 1 millidollar
    client = FakeOpenAI(_FakeResponse("hi", in_t=1000, out_t=500))
    wrapped = fw.wrap(client)
    with pytest.raises(LeashKilled) as exc_info:
        wrapped.chat.completions.create(
            model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
        )
    assert "budget" in str(exc_info.value).lower()


@pytest.mark.asyncio
async def test_openai_kill_blocks_call():
    fw = Firewall()
    await fw.kill("test kill")
    client = FakeOpenAI()
    wrapped = fw.wrap(client)
    with pytest.raises(LeashKilled):
        wrapped.chat.completions.create(model="gpt-4o", messages=[])


@pytest.mark.asyncio
async def test_openai_pii_redactor_scrubs_messages():
    captured: list[dict] = []

    class _CapturingCompletions:
        def create(self, **kwargs):
            captured.append(dict(kwargs))
            return _FakeResponse("ok", in_t=10, out_t=5)

    class _CapturingChat:
        completions = _CapturingCompletions()

    class CapturingClient:
        chat = _CapturingChat()

    fw = Firewall(pii_redactor=PiiRedactor())
    wrapped = fw.wrap(CapturingClient())
    wrapped.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "email me at test@corp.io"}],
    )
    sent = captured[0]["messages"][0]["content"]
    assert "test@corp.io" not in sent
    assert "[REDACTED:EMAIL]" in sent


@pytest.mark.asyncio
async def test_openai_hitl_no_gate_default_denies():
    fw = Firewall(budget_usd=1.0, rules=[HitlThreshold(threshold_pct=0.0)])
    wrapped = fw.wrap(FakeOpenAI(_FakeResponse("hi", in_t=10, out_t=5)))
    with pytest.raises(LeashRejectedByHuman) as exc_info:
        wrapped.chat.completions.create(
            model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
        )
    assert "no gate configured" in str(exc_info.value)


@pytest.mark.asyncio
async def test_openai_hitl_gate_approve():
    gate = InMemoryHitlGate(default="approve")
    fw = Firewall(
        budget_usd=1.0,
        rules=[HitlThreshold(threshold_pct=0.0)],
        hitl_gate=gate,
    )
    wrapped = fw.wrap(FakeOpenAI(_FakeResponse("hi", in_t=10, out_t=5)))
    resp = wrapped.chat.completions.create(
        model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
    )
    assert resp is not None
    assert len(gate.requests) == 1


@pytest.mark.asyncio
async def test_openai_pre_call_estimate_blocks_huge_max_tokens():
    """A huge max_tokens upfront exceeds cap → blocked before SDK call."""
    fw = Firewall(budget_usd=0.01)
    wrapped = fw.wrap(FakeOpenAI())
    with pytest.raises(LeashKilled) as exc_info:
        wrapped.chat.completions.create(
            model="gpt-4o",
            max_tokens=10_000_000,  # 10M tokens at $2.5/M = $25 -> exceeds $0.01
            messages=[{"role": "user", "content": "hi"}],
        )
    assert "pre_call_estimate" in exc_info.value.rule_id


def test_openai_wrapped_chat_attribute_error_on_unknown():
    """Attempting to access non-existent chat sub-API surfaces AttributeError."""
    fw = Firewall()
    wrapped = fw.wrap(FakeOpenAI())
    with pytest.raises(AttributeError):
        wrapped.chat.nonexistent_subapi  # noqa: B018


def test_openai_wrapped_client_delegates_unknown_attrs():
    """Unknown attrs on top-level wrapped client delegate to raw."""
    raw = FakeOpenAI()
    raw.organization = "org-xyz"  # type: ignore[attr-defined]
    fw = Firewall()
    wrapped = fw.wrap(raw)
    assert wrapped.organization == "org-xyz"


def test_openai_run_from_sync_context_no_running_loop():
    """Direct sync entry (no asyncio loop) goes through asyncio.run path."""
    fw = Firewall(budget_usd=1.0)
    wrapped = fw.wrap(FakeOpenAI(_FakeResponse("hi", in_t=10, out_t=5)))
    resp = wrapped.chat.completions.create(
        model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
    )
    assert resp.choices[0].message.content == "hi"


def test_openai_hash_response_handles_non_serializable():
    """_hash_response falls back to str() for objects that aren't JSON-serializable."""
    from llm_leash.adapters.openai import _hash_response

    class NotSerializable:
        pass

    h = _hash_response([NotSerializable()])
    assert len(h) == 64  # sha256 hex
