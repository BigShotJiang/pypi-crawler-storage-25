"""CrewAI adapter tests. No real crewai/litellm — uses FakeCrewLLM."""
from __future__ import annotations

import pytest

from llm_leash import Firewall, HitlThreshold, InMemoryHitlGate, PiiRedactor
from llm_leash.adapters.crewai import _extract_tokens, _split_provider_model
from llm_leash.types import LeashKilled, LeashRejectedByHuman


class _Usage:
    def __init__(self, prompt_tokens: int, completion_tokens: int) -> None:
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _LiteLLMResponse:
    def __init__(self, content: str, in_t: int, out_t: int) -> None:
        self.choices = [type("C", (), {"message": type("M", (), {"content": content})()})()]
        self.usage = _Usage(in_t, out_t)


class FakeCrewLLM:
    """Imitates crewai.LLM."""

    def __init__(
        self,
        model: str = "gpt-4o",
        response: _LiteLLMResponse | None = None,
    ) -> None:
        self.model = model
        self._response = response or _LiteLLMResponse("ok", 100, 50)
        self.last_messages: list = []

    def call(self, messages, **kwargs):
        self.last_messages = messages
        return self._response


# ─── Provider/model splitting ──────────────────────────────────────


def test_split_provider_model_with_prefix():
    assert _split_provider_model("anthropic/claude-haiku-4-5") == (
        "anthropic", "claude-haiku-4-5"
    )


def test_split_provider_model_without_prefix_defaults_to_openai():
    assert _split_provider_model("gpt-4o") == ("openai", "gpt-4o")


def test_split_provider_model_openai_explicit():
    assert _split_provider_model("openai/gpt-4o") == ("openai", "gpt-4o")


# ─── Token extraction ──────────────────────────────────────


def test_extract_tokens_from_usage_object():
    resp = _LiteLLMResponse("x", 11, 22)
    assert _extract_tokens(resp) == (11, 22)


def test_extract_tokens_from_dict():
    resp = {"usage": {"prompt_tokens": 11, "completion_tokens": 22}}
    assert _extract_tokens(resp) == (11, 22)


def test_extract_tokens_from_string_returns_zero():
    assert _extract_tokens("just a plain answer string") == (0, 0)


# ─── Wrap dispatch ──────────────────────────────────────


def test_firewall_wraps_crewai_llm():
    fw = Firewall()
    wrapped = fw.wrap(FakeCrewLLM())
    assert hasattr(wrapped, "call")


# ─── End-to-end ──────────────────────────────────────


@pytest.mark.asyncio
async def test_crewai_charges_budget():
    fw = Firewall(budget_usd=5.0)
    wrapped = fw.wrap(FakeCrewLLM("gpt-4o", _LiteLLMResponse("ok", 1000, 500)))
    resp = wrapped.call([{"role": "user", "content": "hi"}])
    assert resp.choices[0].message.content == "ok"
    spent = await fw.cumulative_usd()
    # gpt-4o: $2.50/M in + $10/M out = 0.0025 + 0.005 = 0.0075
    assert abs(spent - 0.0075) < 1e-6


@pytest.mark.asyncio
async def test_crewai_anthropic_provider_prefix_charges_correctly():
    fw = Firewall(budget_usd=5.0)
    wrapped = fw.wrap(FakeCrewLLM(
        "anthropic/claude-haiku-4-5",
        _LiteLLMResponse("ok", 1000, 500),
    ))
    wrapped.call([{"role": "user", "content": "hi"}])
    spent = await fw.cumulative_usd()
    # claude-haiku-4-5: $0.80/M in + $4.00/M out = 0.0008 + 0.002 = 0.0028
    assert abs(spent - 0.0028) < 1e-6


@pytest.mark.asyncio
async def test_crewai_kill_blocks():
    fw = Firewall()
    await fw.kill("stop")
    wrapped = fw.wrap(FakeCrewLLM())
    with pytest.raises(LeashKilled):
        wrapped.call([{"role": "user", "content": "hi"}])


@pytest.mark.asyncio
async def test_crewai_hard_cap_raises():
    fw = Firewall(budget_usd=0.0001)
    wrapped = fw.wrap(FakeCrewLLM("gpt-4o", _LiteLLMResponse("ok", 10_000, 10_000)))
    with pytest.raises(LeashKilled) as exc_info:
        wrapped.call([{"role": "user", "content": "hi"}])
    assert "hard_cap" in exc_info.value.rule_id


@pytest.mark.asyncio
async def test_crewai_pii_redaction():
    raw = FakeCrewLLM()
    fw = Firewall(pii_redactor=PiiRedactor())
    wrapped = fw.wrap(raw)
    wrapped.call([{"role": "user", "content": "email me at u@corp.io"}])
    seen = raw.last_messages[0]["content"]
    assert "u@corp.io" not in seen


@pytest.mark.asyncio
async def test_crewai_hitl_approve():
    gate = InMemoryHitlGate(default="approve")
    fw = Firewall(
        budget_usd=1.0,
        rules=[HitlThreshold(threshold_pct=0.0)],
        hitl_gate=gate,
    )
    wrapped = fw.wrap(FakeCrewLLM())
    resp = wrapped.call([{"role": "user", "content": "hi"}])
    assert resp is not None
    assert len(gate.requests) == 1


@pytest.mark.asyncio
async def test_crewai_hitl_no_gate_default_denies():
    fw = Firewall(budget_usd=1.0, rules=[HitlThreshold(threshold_pct=0.0)])
    wrapped = fw.wrap(FakeCrewLLM())
    with pytest.raises(LeashRejectedByHuman):
        wrapped.call([{"role": "user", "content": "hi"}])


def test_crewai_wrapped_delegates_unknown_attrs():
    raw = FakeCrewLLM()
    raw.temperature = 0.9  # type: ignore[attr-defined]
    fw = Firewall()
    wrapped = fw.wrap(raw)
    assert wrapped.temperature == 0.9
