"""MCP adapter tests. No real mcp package — uses FakeMcpSession."""
from __future__ import annotations

import json

import pytest

from llm_leash import (
    BlockedPatterns,
    BlockedShell,
    Firewall,
    InMemoryHitlGate,
    PiiRedactor,
)
from llm_leash.types import Decision, LeashBlocked, LeashKilled, LeashRejectedByHuman


class _CallToolResult:
    def __init__(self, content):
        self.content = content


class FakeMcpSession:
    """Imitates mcp.client.session.ClientSession."""

    def __init__(self, result=None):
        self._result = result or _CallToolResult([{"type": "text", "text": "ok"}])
        self.invocations: list[tuple[str, dict]] = []

    async def call_tool(self, name, arguments=None):
        self.invocations.append((name, arguments or {}))
        return self._result


# ─── Wrap dispatch ────────────────────────────────────────────────


def test_firewall_wraps_mcp_session():
    fw = Firewall()
    wrapped = fw.wrap(FakeMcpSession())
    assert hasattr(wrapped, "call_tool")


# ─── Happy path ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_mcp_call_tool_passes_through_when_allowed(tmp_path):
    log = tmp_path / "audit.jsonl"
    fw = Firewall(audit_log=str(log))
    raw = FakeMcpSession()
    wrapped = fw.wrap(raw)
    result = await wrapped.call_tool("read_file", {"path": "/etc/hosts"})
    assert result is not None
    assert raw.invocations == [("read_file", {"path": "/etc/hosts"})]


@pytest.mark.asyncio
async def test_mcp_call_tool_writes_audit(tmp_path):
    log = tmp_path / "audit.jsonl"
    fw = Firewall(audit_log=str(log))
    wrapped = fw.wrap(FakeMcpSession())
    await wrapped.call_tool("read_file", {"path": "/etc/hosts"})

    lines = log.read_text().strip().splitlines()
    assert len(lines) == 1
    event = json.loads(lines[0])
    assert event["kind"] == "tool_call"
    assert event["tool"] == "read_file"
    assert "request_hash" in event
    assert "response_hash" in event


# ─── Kill switch ────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_mcp_kill_blocks():
    fw = Firewall()
    await fw.kill("stop")
    wrapped = fw.wrap(FakeMcpSession())
    with pytest.raises(LeashKilled):
        await wrapped.call_tool("read_file", {})


# ─── Policy: tool blocklist ─────────────────────────────────────


class _DenyToolByName:
    """Simple rule that blocks specific tool names."""
    id = "deny_tool"

    def __init__(self, denied: set[str]) -> None:
        self._denied = denied

    def evaluate(self, call, ctx):
        if call.tool in self._denied:
            return Decision(action="block", rule_id=self.id, reason=f"tool '{call.tool}' is denied")
        return None


@pytest.mark.asyncio
async def test_mcp_policy_blocks_dangerous_tool():
    fw = Firewall(rules=[_DenyToolByName({"shell_exec"})])
    wrapped = fw.wrap(FakeMcpSession())
    with pytest.raises(LeashBlocked) as exc_info:
        await wrapped.call_tool("shell_exec", {"cmd": "ls"})
    assert "shell_exec" in str(exc_info.value)


@pytest.mark.asyncio
async def test_mcp_policy_blocks_shell_pattern_in_args():
    fw = Firewall(rules=[BlockedShell()])
    wrapped = fw.wrap(FakeMcpSession())
    with pytest.raises(LeashBlocked):
        await wrapped.call_tool("run_shell", {"cmd": "rm -rf /"})


@pytest.mark.asyncio
async def test_mcp_policy_blocks_pattern_in_args():
    fw = Firewall(rules=[BlockedPatterns([r"DROP\s+TABLE"])])
    wrapped = fw.wrap(FakeMcpSession())
    with pytest.raises(LeashBlocked):
        await wrapped.call_tool("query", {"sql": "DROP TABLE users"})


# ─── HITL ──────────────────────────────────────────────────────


class _HitlForTool:
    """Asks HITL for a specific tool."""
    id = "hitl_tool"

    def __init__(self, tool_name: str) -> None:
        self._tool = tool_name

    def evaluate(self, call, ctx):
        if call.tool == self._tool:
            return Decision(
                action="hitl",
                rule_id=self.id,
                reason=f"manual approval for {call.tool}",
            )
        return None


@pytest.mark.asyncio
async def test_mcp_hitl_gate_approves():
    gate = InMemoryHitlGate(default="approve")
    fw = Firewall(rules=[_HitlForTool("delete_file")], hitl_gate=gate)
    wrapped = fw.wrap(FakeMcpSession())
    await wrapped.call_tool("delete_file", {"path": "target.txt"})
    assert len(gate.requests) == 1


@pytest.mark.asyncio
async def test_mcp_hitl_no_gate_default_denies():
    fw = Firewall(rules=[_HitlForTool("delete_file")])
    wrapped = fw.wrap(FakeMcpSession())
    with pytest.raises(LeashRejectedByHuman):
        await wrapped.call_tool("delete_file", {"path": "target.txt"})


# ─── PII redaction ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_mcp_pii_redaction_on_args():
    raw = FakeMcpSession()
    fw = Firewall(pii_redactor=PiiRedactor())
    wrapped = fw.wrap(raw)
    await wrapped.call_tool("send_email", {"to": "user@corp.io", "body": "hi"})
    seen = raw.invocations[0][1]
    assert "user@corp.io" not in json.dumps(seen)


def test_mcp_wrapped_delegates_unknown_attrs():
    raw = FakeMcpSession()
    raw.session_id = "abc"  # type: ignore[attr-defined]
    fw = Firewall()
    wrapped = fw.wrap(raw)
    assert wrapped.session_id == "abc"
