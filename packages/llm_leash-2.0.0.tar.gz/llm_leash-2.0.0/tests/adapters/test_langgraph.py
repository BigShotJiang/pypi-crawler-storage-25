"""LangChain / LangGraph adapter tests. No real langchain — uses FakeChatModel."""
from __future__ import annotations

import pytest

from llm_leash import Firewall, HitlThreshold, InMemoryHitlGate, PiiRedactor
from llm_leash.adapters.langgraph import _extract_tokens
from llm_leash.types import LeashKilled, LeashRejectedByHuman


class _AIMessage:
    def __init__(
        self,
        content: str,
        usage_metadata: dict | None = None,
        response_metadata: dict | None = None,
    ) -> None:
        self.content = content
        if usage_metadata is not None:
            self.usage_metadata = usage_metadata
        if response_metadata is not None:
            self.response_metadata = response_metadata
        self.type = "ai"


class FakeChatAnthropic:
    """Imitates langchain_anthropic.ChatAnthropic."""

    def __init__(self, model: str = "claude-haiku-4-5", response: _AIMessage | None = None) -> None:
        self.model = model
        self._response = response or _AIMessage(
            "hello", usage_metadata={"input_tokens": 100, "output_tokens": 50}
        )
        self.last_messages: list = []

    def invoke(self, messages, **kwargs):
        self.last_messages = messages
        return self._response


class FakeChatOpenAI:
    """Imitates langchain_openai.ChatOpenAI."""

    def __init__(self, model: str = "gpt-4o", response: _AIMessage | None = None) -> None:
        self.model_name = model
        self._response = response or _AIMessage(
            "hi",
            response_metadata={"token_usage": {"prompt_tokens": 100, "completion_tokens": 50}},
        )
        self.last_messages: list = []

    def invoke(self, messages, **kwargs):
        self.last_messages = messages
        return self._response


# ─── Wrap dispatch ────────────────────────────────────────────────────


def test_firewall_wraps_chat_model():
    fw = Firewall()
    wrapped = fw.wrap(FakeChatAnthropic())
    assert hasattr(wrapped, "invoke")
    assert hasattr(wrapped, "ainvoke")


def test_unknown_client_without_invoke_passes_through():
    class _Unknown:
        pass
    fw = Firewall()
    raw = _Unknown()
    assert fw.wrap(raw) is raw


def test_wrap_skips_client_without_model_attr():
    """Plain callable with .invoke but no model/model_name → not a chat model, passes through."""
    class _PlainInvoker:
        def invoke(self, x):
            return x
    fw = Firewall()
    raw = _PlainInvoker()
    assert fw.wrap(raw) is raw


# ─── Anthropic-style chat model ───────────────────────────────────────


@pytest.mark.asyncio
async def test_anthropic_chat_charges_budget():
    fw = Firewall(budget_usd=5.0)
    raw = FakeChatAnthropic(
        response=_AIMessage("ok", usage_metadata={"input_tokens": 1000, "output_tokens": 500})
    )
    wrapped = fw.wrap(raw)
    resp = wrapped.invoke([{"role": "user", "content": "hi"}])
    assert resp.content == "ok"
    spent = await fw.cumulative_usd()
    # claude-haiku-4-5: $0.80/M in + $4.00/M out = 0.0008 + 0.002 = 0.0028
    assert spent > 0
    assert spent < 0.01


@pytest.mark.asyncio
async def test_chat_model_kill_blocks():
    fw = Firewall()
    await fw.kill("manual")
    wrapped = fw.wrap(FakeChatAnthropic())
    with pytest.raises(LeashKilled):
        wrapped.invoke([{"role": "user", "content": "hi"}])


@pytest.mark.asyncio
async def test_chat_model_ainvoke_works():
    """Native async path — for users running inside an event loop."""
    fw = Firewall(budget_usd=5.0)
    wrapped = fw.wrap(FakeChatAnthropic())
    resp = await wrapped.ainvoke([{"role": "user", "content": "hi"}])
    assert resp.content == "hello"


# ─── OpenAI-style chat model (token extraction via response_metadata) ──


@pytest.mark.asyncio
async def test_openai_chat_token_extraction_via_response_metadata():
    fw = Firewall(budget_usd=5.0)
    raw = FakeChatOpenAI(
        response=_AIMessage(
            "yo",
            response_metadata={"token_usage": {"prompt_tokens": 2000, "completion_tokens": 100}},
        )
    )
    wrapped = fw.wrap(raw)
    wrapped.invoke([{"role": "user", "content": "hi"}])
    spent = await fw.cumulative_usd()
    assert spent > 0


# ─── Token extraction unit tests ──────────────────────────────────────


def test_extract_tokens_prefers_usage_metadata():
    msg = _AIMessage(
        "x",
        usage_metadata={"input_tokens": 11, "output_tokens": 22},
        response_metadata={"token_usage": {"prompt_tokens": 999, "completion_tokens": 999}},
    )
    assert _extract_tokens(msg) == (11, 22)


def test_extract_tokens_falls_back_to_response_metadata_openai_style():
    msg = _AIMessage(
        "x",
        response_metadata={"token_usage": {"prompt_tokens": 11, "completion_tokens": 22}},
    )
    assert _extract_tokens(msg) == (11, 22)


def test_extract_tokens_falls_back_to_response_metadata_anthropic_style():
    msg = _AIMessage(
        "x",
        response_metadata={"usage": {"input_tokens": 11, "output_tokens": 22}},
    )
    assert _extract_tokens(msg) == (11, 22)


def test_extract_tokens_returns_zero_when_missing():
    msg = _AIMessage("x")
    assert _extract_tokens(msg) == (0, 0)


# ─── Hard cap + policy ────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_chat_model_post_call_hard_cap_raises():
    fw = Firewall(budget_usd=0.0001)  # 0.01 cent
    raw = FakeChatAnthropic(
        response=_AIMessage(
            "ok", usage_metadata={"input_tokens": 10_000, "output_tokens": 10_000}
        )
    )
    wrapped = fw.wrap(raw)
    with pytest.raises(LeashKilled) as exc_info:
        wrapped.invoke([{"role": "user", "content": "hi"}])
    assert "hard_cap" in exc_info.value.rule_id


@pytest.mark.asyncio
async def test_chat_model_pii_redaction():
    raw = FakeChatAnthropic()
    fw = Firewall(pii_redactor=PiiRedactor())
    wrapped = fw.wrap(raw)
    wrapped.invoke([{"role": "user", "content": "email me at user@corp.io"}])
    seen = raw.last_messages[0]["content"]
    assert "user@corp.io" not in seen
    assert "[REDACTED:EMAIL]" in seen


@pytest.mark.asyncio
async def test_chat_model_hitl_approve():
    gate = InMemoryHitlGate(default="approve")
    fw = Firewall(
        budget_usd=1.0,
        rules=[HitlThreshold(threshold_pct=0.0)],
        hitl_gate=gate,
    )
    wrapped = fw.wrap(FakeChatAnthropic())
    resp = wrapped.invoke([{"role": "user", "content": "hi"}])
    assert resp is not None
    assert len(gate.requests) == 1


@pytest.mark.asyncio
async def test_chat_model_hitl_no_gate_default_denies():
    fw = Firewall(budget_usd=1.0, rules=[HitlThreshold(threshold_pct=0.0)])
    wrapped = fw.wrap(FakeChatAnthropic())
    with pytest.raises(LeashRejectedByHuman):
        wrapped.invoke([{"role": "user", "content": "hi"}])


def test_chat_model_delegates_unknown_attrs():
    raw = FakeChatAnthropic()
    raw.temperature = 0.7  # type: ignore[attr-defined]
    fw = Firewall()
    wrapped = fw.wrap(raw)
    assert wrapped.temperature == 0.7
