"""Pydantic-AI adapter tests. No real pydantic-ai — uses FakePAIModel."""
from __future__ import annotations

import pytest

from llm_leash import Firewall, HitlThreshold, InMemoryHitlGate, PiiRedactor
from llm_leash.adapters.pydantic_ai import _extract_tokens
from llm_leash.types import LeashKilled, LeashRejectedByHuman


class _Usage:
    """Newer pydantic-ai shape: input_tokens / output_tokens."""

    def __init__(self, in_t: int, out_t: int) -> None:
        self.input_tokens = in_t
        self.output_tokens = out_t


class _UsageOld:
    """Older pydantic-ai shape: request_tokens / response_tokens."""

    def __init__(self, in_t: int, out_t: int) -> None:
        self.request_tokens = in_t
        self.response_tokens = out_t


class _ModelResponse:
    def __init__(self, content: str) -> None:
        self.content = content


class FakePAIModelAnthropic:
    """Imitates pydantic_ai.models.anthropic.AnthropicModel."""

    def __init__(self, model: str = "claude-haiku-4-5", usage=None, response=None) -> None:
        self.model_name = model
        # Force module-name detection to "anthropic"
        type(self).__module__ = "fake_pydantic_ai_anthropic"
        self._usage = usage or _Usage(100, 50)
        self._response = response or _ModelResponse("hello")
        self.last_messages = None

    async def request(self, messages, *args, **kwargs):
        self.last_messages = messages
        return (self._response, self._usage)


class FakePAIModelOpenAI:
    """Imitates pydantic_ai.models.openai.OpenAIModel."""

    def __init__(self, model: str = "gpt-4o", usage=None, response=None) -> None:
        self.model_name = model
        self._usage = usage or _Usage(100, 50)
        self._response = response or _ModelResponse("hi")
        self.last_messages = None

    async def request(self, messages, *args, **kwargs):
        self.last_messages = messages
        return (self._response, self._usage)


# ─── Token extraction ──────────────────────────────────────


def test_extract_tokens_new_shape():
    assert _extract_tokens((_ModelResponse("x"), _Usage(11, 22))) == (11, 22)


def test_extract_tokens_old_shape():
    assert _extract_tokens((_ModelResponse("x"), _UsageOld(11, 22))) == (11, 22)


def test_extract_tokens_response_with_usage_attr():
    resp = _ModelResponse("x")
    resp.usage = _Usage(11, 22)  # type: ignore[attr-defined]
    assert _extract_tokens(resp) == (11, 22)


def test_extract_tokens_missing_returns_zero():
    assert _extract_tokens(_ModelResponse("x")) == (0, 0)


# ─── Dispatch ──────────────────────────────────────


def test_firewall_wraps_pydantic_ai_model():
    fw = Firewall()
    wrapped = fw.wrap(FakePAIModelOpenAI())
    assert hasattr(wrapped, "request")


# ─── End-to-end ─────────────────────────────────────


@pytest.mark.asyncio
async def test_pai_openai_charges_budget():
    fw = Firewall(budget_usd=5.0)
    wrapped = fw.wrap(FakePAIModelOpenAI(
        "gpt-4o", usage=_Usage(1000, 500),
    ))
    result = await wrapped.request([{"role": "user", "content": "hi"}])
    assert result is not None
    spent = await fw.cumulative_usd()
    assert abs(spent - 0.0075) < 1e-6


@pytest.mark.asyncio
async def test_pai_anthropic_provider_detected():
    fw = Firewall(budget_usd=5.0)
    wrapped = fw.wrap(FakePAIModelAnthropic(
        "claude-haiku-4-5", usage=_Usage(1000, 500),
    ))
    await wrapped.request([{"role": "user", "content": "hi"}])
    spent = await fw.cumulative_usd()
    # claude-haiku-4-5: $0.80/M in + $4.00/M out
    assert abs(spent - 0.0028) < 1e-6


@pytest.mark.asyncio
async def test_pai_kill_blocks():
    fw = Firewall()
    await fw.kill("stop")
    wrapped = fw.wrap(FakePAIModelOpenAI())
    with pytest.raises(LeashKilled):
        await wrapped.request([{"role": "user", "content": "hi"}])


@pytest.mark.asyncio
async def test_pai_hard_cap():
    fw = Firewall(budget_usd=0.0001)
    wrapped = fw.wrap(FakePAIModelOpenAI(
        "gpt-4o", usage=_Usage(10_000, 10_000),
    ))
    with pytest.raises(LeashKilled) as exc:
        await wrapped.request([{"role": "user", "content": "hi"}])
    assert "hard_cap" in exc.value.rule_id


@pytest.mark.asyncio
async def test_pai_pii_redaction():
    raw = FakePAIModelOpenAI()
    fw = Firewall(pii_redactor=PiiRedactor())
    wrapped = fw.wrap(raw)
    await wrapped.request([{"role": "user", "content": "email me at u@corp.io"}])
    seen = raw.last_messages[0]["content"]
    assert "u@corp.io" not in seen


@pytest.mark.asyncio
async def test_pai_hitl_approve():
    gate = InMemoryHitlGate(default="approve")
    fw = Firewall(
        budget_usd=1.0,
        rules=[HitlThreshold(threshold_pct=0.0)],
        hitl_gate=gate,
    )
    wrapped = fw.wrap(FakePAIModelOpenAI())
    result = await wrapped.request([{"role": "user", "content": "hi"}])
    assert result is not None
    assert len(gate.requests) == 1


@pytest.mark.asyncio
async def test_pai_hitl_no_gate_default_denies():
    fw = Firewall(budget_usd=1.0, rules=[HitlThreshold(threshold_pct=0.0)])
    wrapped = fw.wrap(FakePAIModelOpenAI())
    with pytest.raises(LeashRejectedByHuman):
        await wrapped.request([{"role": "user", "content": "hi"}])
