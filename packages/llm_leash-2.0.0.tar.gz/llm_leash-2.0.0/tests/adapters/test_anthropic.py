"""Adapter tests use a FakeAnthropicClient so the SDK doesn't need to be installed."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from llm_leash.adapters.anthropic import AnthropicAdapter
from llm_leash.audit.writer import AuditWriter
from llm_leash.budget.store import InMemoryStore
from llm_leash.budget.tracker import BudgetTracker
from llm_leash.kill.registry import InProcessKillRegistry
from llm_leash.types import LeashKilled


@dataclass
class _Usage:
    input_tokens: int
    output_tokens: int


@dataclass
class _Response:
    model: str
    usage: _Usage
    content: list[dict[str, Any]]


class FakeMessages:
    """Mimics anthropic.resources.messages.Messages.create."""
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def create(self, **kwargs: Any) -> _Response:
        self.calls.append(kwargs)
        return _Response(
            model=kwargs["model"],
            usage=_Usage(input_tokens=100, output_tokens=200),
            content=[{"type": "text", "text": "ok"}],
        )


class FakeAnthropic:
    def __init__(self) -> None:
        self.messages = FakeMessages()


@pytest.mark.asyncio
async def test_wrapped_client_charges_on_response(tmp_path):
    audit = AuditWriter(str(tmp_path / "audit.jsonl"), fsync=False)
    budget = BudgetTracker(
        session_id="s1", hard_cap_usd=100.0, soft_cap_usd=None,
        store=InMemoryStore(),
    )
    kill = InProcessKillRegistry()
    adapter = AnthropicAdapter(session_id="s1", budget=budget, audit=audit, kill=kill)

    raw = FakeAnthropic()
    wrapped = adapter.wrap_client(raw)

    resp = wrapped.messages.create(
        model="claude-opus-4-7",
        max_tokens=200,
        messages=[{"role": "user", "content": "hi"}],
    )
    assert resp.usage.output_tokens == 200
    # 100 in + 200 out at opus-4-7 (15/M in, 75/M out)
    expected = 15.0 * (100 / 1_000_000) + 75.0 * (200 / 1_000_000)
    assert await budget.cumulative_usd() == pytest.approx(expected)


@pytest.mark.asyncio
async def test_wrapped_client_raises_when_budget_exhausted(tmp_path):
    audit = AuditWriter(str(tmp_path / "audit.jsonl"), fsync=False)
    budget = BudgetTracker(
        session_id="s1", hard_cap_usd=0.001, soft_cap_usd=None,  # tiny cap
        store=InMemoryStore(),
    )
    kill = InProcessKillRegistry()
    adapter = AnthropicAdapter(session_id="s1", budget=budget, audit=audit, kill=kill)

    raw = FakeAnthropic()
    wrapped = adapter.wrap_client(raw)

    with pytest.raises(LeashKilled):
        wrapped.messages.create(
            model="claude-opus-4-7",
            max_tokens=200,
            messages=[{"role": "user", "content": "hi"}],
        )


@pytest.mark.asyncio
async def test_wrapped_client_raises_when_session_killed(tmp_path):
    audit = AuditWriter(str(tmp_path / "audit.jsonl"), fsync=False)
    budget = BudgetTracker(
        session_id="s1", hard_cap_usd=100.0, soft_cap_usd=None,
        store=InMemoryStore(),
    )
    kill = InProcessKillRegistry()
    await kill.kill("s1", reason="manual")
    adapter = AnthropicAdapter(session_id="s1", budget=budget, audit=audit, kill=kill)

    raw = FakeAnthropic()
    wrapped = adapter.wrap_client(raw)

    with pytest.raises(LeashKilled):
        wrapped.messages.create(
            model="claude-opus-4-7", max_tokens=10,
            messages=[{"role": "user", "content": "x"}],
        )


@pytest.mark.asyncio
async def test_audit_log_records_model_call(tmp_path):
    audit_path = tmp_path / "audit.jsonl"
    audit = AuditWriter(str(audit_path), fsync=False)
    budget = BudgetTracker(
        session_id="s1", hard_cap_usd=100.0, soft_cap_usd=None,
        store=InMemoryStore(),
    )
    kill = InProcessKillRegistry()
    adapter = AnthropicAdapter(session_id="s1", budget=budget, audit=audit, kill=kill)

    wrapped = adapter.wrap_client(FakeAnthropic())
    wrapped.messages.create(
        model="claude-opus-4-7", max_tokens=200,
        messages=[{"role": "user", "content": "hi"}],
    )

    import json
    lines = audit_path.read_text().splitlines()
    kinds = [json.loads(line)["kind"] for line in lines]
    assert "model_call" in kinds
