"""OpenHands adapter tests. No real openhands — uses FakeOpenHandsLLM."""
from __future__ import annotations

import pytest

from llm_leash import Firewall, HitlThreshold, InMemoryHitlGate, PiiRedactor
from llm_leash.adapters.openhands import _split_provider_model
from llm_leash.types import LeashKilled, LeashRejectedByHuman


class _Usage:
    def __init__(self, prompt_tokens: int, completion_tokens: int) -> None:
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _ModelResponse:
    def __init__(self, content: str, in_t: int, out_t: int) -> None:
        self.choices = [type("C", (), {"message": type("M", (), {"content": content})()})()]
        self.usage = _Usage(in_t, out_t)


class _Config:
    def __init__(self, model: str) -> None:
        self.model = model


class FakeOpenHandsLLM:
    """Imitates openhands.llm.LLM."""

    def __init__(self, model: str = "gpt-4o", response=None):
        self.config = _Config(model)
        self._response = response or _ModelResponse("ok", 100, 50)
        self.last_messages = None

    def completion(self, messages=None, **kwargs):
        self.last_messages = messages
        return self._response


def test_split_provider_model_with_prefix():
    assert _split_provider_model("anthropic/claude-haiku-4-5") == ("anthropic", "claude-haiku-4-5")


def test_split_provider_model_without_prefix():
    assert _split_provider_model("gpt-4o") == ("openai", "gpt-4o")


def test_firewall_wraps_openhands_llm():
    fw = Firewall()
    wrapped = fw.wrap(FakeOpenHandsLLM())
    assert hasattr(wrapped, "completion")


@pytest.mark.asyncio
async def test_openhands_charges_budget():
    fw = Firewall(budget_usd=5.0)
    wrapped = fw.wrap(FakeOpenHandsLLM("gpt-4o", _ModelResponse("ok", 1000, 500)))
    resp = wrapped.completion(messages=[{"role": "user", "content": "hi"}])
    assert resp.choices[0].message.content == "ok"
    spent = await fw.cumulative_usd()
    assert abs(spent - 0.0075) < 1e-6


@pytest.mark.asyncio
async def test_openhands_anthropic_prefix():
    fw = Firewall(budget_usd=5.0)
    wrapped = fw.wrap(FakeOpenHandsLLM(
        "anthropic/claude-haiku-4-5", _ModelResponse("ok", 1000, 500)
    ))
    wrapped.completion(messages=[{"role": "user", "content": "hi"}])
    spent = await fw.cumulative_usd()
    assert abs(spent - 0.0028) < 1e-6


@pytest.mark.asyncio
async def test_openhands_kill_blocks():
    fw = Firewall()
    await fw.kill("stop")
    wrapped = fw.wrap(FakeOpenHandsLLM())
    with pytest.raises(LeashKilled):
        wrapped.completion(messages=[{"role": "user", "content": "hi"}])


@pytest.mark.asyncio
async def test_openhands_hard_cap():
    fw = Firewall(budget_usd=0.0001)
    wrapped = fw.wrap(FakeOpenHandsLLM("gpt-4o", _ModelResponse("ok", 10_000, 10_000)))
    with pytest.raises(LeashKilled) as exc:
        wrapped.completion(messages=[{"role": "user", "content": "hi"}])
    assert "hard_cap" in exc.value.rule_id


@pytest.mark.asyncio
async def test_openhands_pii_redaction():
    raw = FakeOpenHandsLLM()
    fw = Firewall(pii_redactor=PiiRedactor())
    wrapped = fw.wrap(raw)
    wrapped.completion(messages=[{"role": "user", "content": "email user@corp.io"}])
    seen = raw.last_messages[0]["content"]
    assert "user@corp.io" not in seen


@pytest.mark.asyncio
async def test_openhands_hitl_approve():
    gate = InMemoryHitlGate(default="approve")
    fw = Firewall(
        budget_usd=1.0,
        rules=[HitlThreshold(threshold_pct=0.0)],
        hitl_gate=gate,
    )
    wrapped = fw.wrap(FakeOpenHandsLLM())
    resp = wrapped.completion(messages=[{"role": "user", "content": "hi"}])
    assert resp is not None
    assert len(gate.requests) == 1


@pytest.mark.asyncio
async def test_openhands_hitl_no_gate_default_denies():
    fw = Firewall(budget_usd=1.0, rules=[HitlThreshold(threshold_pct=0.0)])
    wrapped = fw.wrap(FakeOpenHandsLLM())
    with pytest.raises(LeashRejectedByHuman):
        wrapped.completion(messages=[{"role": "user", "content": "hi"}])
