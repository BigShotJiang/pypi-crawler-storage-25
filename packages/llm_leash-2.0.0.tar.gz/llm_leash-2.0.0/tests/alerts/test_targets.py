"""Tests for alert dispatchers (Slack, PagerDuty, stdout)."""
from __future__ import annotations

import asyncio
import json

import httpx

from llm_leash.alerts.engine import Alert
from llm_leash.alerts.targets import (
    PagerDutyTarget,
    SlackTarget,
    StdoutTarget,
    parse_payload_summary,
)

# ─── Helpers ────────────────────────────────────────────────────


def _alert(severity: str = "warning") -> Alert:
    return Alert(
        rule_name="test_rule",
        severity=severity,
        message="something happened",
        triggered_event={"kind": "model_call"},
        context={"count": 3, "window_secs": 600},
    )


# ─── SlackTarget ────────────────────────────────────────────────


def test_slack_target_posts_to_webhook():
    captured: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append({"url": str(request.url), "body": json.loads(request.content)})
        return httpx.Response(200, json={"ok": True})

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    target = SlackTarget("https://hooks.slack.com/services/T/B/X", client=client)

    asyncio.run(target.send(_alert()))

    assert len(captured) == 1
    assert captured[0]["url"] == "https://hooks.slack.com/services/T/B/X"
    body = captured[0]["body"]
    assert "test_rule" in body["text"]
    assert body["attachments"][0]["color"] == "#d97706"  # warning color
    # Fields include rule, severity, and context.
    field_names = [f["title"] for f in body["attachments"][0]["fields"]]
    assert "rule" in field_names
    assert "severity" in field_names
    assert "count" in field_names


def test_slack_target_severity_emoji_picked():
    captured: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(json.loads(request.content))
        return httpx.Response(200)

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    target = SlackTarget("https://x", client=client)

    asyncio.run(target.send(_alert(severity="critical")))

    text = captured[0]["text"]
    # Slack auto-renders the shortcode :rotating_light: as 🚨 in the UI.
    assert ":rotating_light:" in text
    assert "critical" in text


def test_slack_target_swallows_500_silently_after_retries():
    """Repeated 5xx responses are logged but don't raise (the runner
    should keep going)."""
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(503, json={"error": "down"})

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    target = SlackTarget("https://x", client=client, retries=1, timeout=1.0)

    # Should not raise.
    asyncio.run(target.send(_alert()))


# ─── PagerDutyTarget ────────────────────────────────────────────


def test_pagerduty_target_posts_to_events_api():
    captured: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append({"url": str(request.url), "body": json.loads(request.content)})
        return httpx.Response(202, json={"status": "success"})

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    target = PagerDutyTarget("pd-routing-key-abc", client=client)

    asyncio.run(target.send(_alert(severity="critical")))

    assert len(captured) == 1
    assert "events.pagerduty.com/v2/enqueue" in captured[0]["url"]
    body = captured[0]["body"]
    assert body["routing_key"] == "pd-routing-key-abc"
    assert body["event_action"] == "trigger"
    assert body["payload"]["severity"] == "critical"
    assert body["payload"]["summary"] == "something happened"


def test_pagerduty_target_skips_info_by_default():
    """Default trigger_on_severity excludes 'info' to avoid spam."""
    captured: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(json.loads(request.content))
        return httpx.Response(202)

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    target = PagerDutyTarget("k", client=client)

    asyncio.run(target.send(_alert(severity="info")))
    assert captured == []  # info filtered


def test_pagerduty_target_explicit_severity_filter():
    """Operator can opt to receive 'info' alerts too."""
    captured: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(json.loads(request.content))
        return httpx.Response(202)

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    target = PagerDutyTarget(
        "k", client=client,
        trigger_on_severity=("info", "warning", "critical"),
    )

    asyncio.run(target.send(_alert(severity="info")))
    assert len(captured) == 1


def test_pagerduty_dedup_key_per_rule():
    """Same rule_name → same dedup_key, so PagerDuty dedupes."""
    captured: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(json.loads(request.content))
        return httpx.Response(202)

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    target = PagerDutyTarget("k", client=client)

    asyncio.run(target.send(_alert(severity="warning")))
    asyncio.run(target.send(_alert(severity="warning")))

    assert captured[0]["dedup_key"] == captured[1]["dedup_key"]
    assert captured[0]["dedup_key"] == "llm-leash:test_rule"


# ─── StdoutTarget ────────────────────────────────────────────────


def test_stdout_target_prints(capsys):
    target = StdoutTarget()
    asyncio.run(target.send(_alert(severity="critical")))
    out = capsys.readouterr().out
    assert "CRITICAL" in out
    assert "test_rule" in out
    assert "something happened" in out


# ─── parse_payload_summary helper ────────────────────────────────


def test_summary_format():
    text = parse_payload_summary(_alert(severity="warning"))
    assert "warning" in text
    assert "test_rule" in text
    assert "something happened" in text
