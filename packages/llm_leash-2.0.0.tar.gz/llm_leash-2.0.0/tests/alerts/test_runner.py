"""Tests for the alerts runner: TOML config + end-to-end log tailing."""
from __future__ import annotations

import asyncio
import textwrap

import pytest

from llm_leash.alerts.engine import (
    Alert,
    SingleEventRule,
    WindowCountRule,
    WindowSumRule,
)
from llm_leash.alerts.runner import (
    AlertsConfig,
    _build_rule,
    _build_targets,
    dispatch,
    load_config,
    run_loop,
)
from llm_leash.alerts.targets import (
    PagerDutyTarget,
    SlackTarget,
    StdoutTarget,
)

# ─── _build_rule ────────────────────────────────────────────────


def test_build_rule_single():
    spec = {
        "type": "single",
        "name": "secret",
        "severity": "critical",
        "match": {"kind": "secrets_detected"},
        "template": "leak {agent_name}",
    }
    rule = _build_rule(spec)
    assert isinstance(rule, SingleEventRule)
    assert rule.name == "secret"
    assert rule.severity == "critical"
    assert rule.match == {"kind": "secrets_detected"}


def test_build_rule_window_count():
    spec = {
        "type": "window_count", "name": "burst", "severity": "warning",
        "match": {"kind": "kill"}, "template": "{count} kills",
        "window_secs": 600, "count_threshold": 3,
    }
    rule = _build_rule(spec)
    assert isinstance(rule, WindowCountRule)
    assert rule.window_secs == 600.0
    assert rule.count_threshold == 3


def test_build_rule_window_sum():
    spec = {
        "type": "window_sum", "name": "spike", "severity": "warning",
        "match": {"tenant_id": "acme"}, "template": "${sum}",
        "window_secs": 3600, "sum_field": "cost_usd", "sum_threshold": 10.0,
    }
    rule = _build_rule(spec)
    assert isinstance(rule, WindowSumRule)
    assert rule.sum_field == "cost_usd"
    assert rule.sum_threshold == 10.0


def test_build_rule_unknown_type_raises():
    with pytest.raises(ValueError, match="Unknown rule type"):
        _build_rule({"type": "asdf", "name": "x", "template": "t"})


# ─── _build_targets ─────────────────────────────────────────────


def test_build_targets_slack():
    targets = _build_targets({"slack": {"webhook_url": "https://x"}})
    assert len(targets) == 1
    assert isinstance(targets[0], SlackTarget)


def test_build_targets_pagerduty():
    targets = _build_targets({"pagerduty": {"routing_key": "abc"}})
    assert len(targets) == 1
    assert isinstance(targets[0], PagerDutyTarget)


def test_build_targets_both_plus_stdout():
    targets = _build_targets({
        "slack": {"webhook_url": "https://x"},
        "pagerduty": {"routing_key": "y"},
        "stdout": True,
    })
    kinds = {type(t).__name__ for t in targets}
    assert kinds == {"SlackTarget", "PagerDutyTarget", "StdoutTarget"}


def test_build_targets_slack_missing_webhook_errors():
    with pytest.raises(ValueError, match="webhook_url"):
        _build_targets({"slack": {}})


def test_build_targets_pagerduty_missing_key_errors():
    with pytest.raises(ValueError, match="routing_key"):
        _build_targets({"pagerduty": {}})


def test_build_targets_empty_returns_empty():
    assert _build_targets({}) == []


# ─── load_config ────────────────────────────────────────────────


def test_load_config_round_trip(tmp_path):
    cfg_path = tmp_path / "alerts.toml"
    cfg_path.write_text(textwrap.dedent("""
        audit_log = "/var/log/audit.jsonl"
        min_interval_secs = 30
        poll_interval_secs = 0.5

        [targets]
        stdout = true

        [[rules]]
        type = "single"
        name = "leak"
        severity = "critical"
        template = "x"
        match = { kind = "secrets_detected" }

        [[rules]]
        type = "window_count"
        name = "kill_burst"
        severity = "warning"
        template = "{count} kills"
        window_secs = 600
        count_threshold = 5
        match = { kind = "kill" }
    """))
    cfg = load_config(cfg_path)
    assert isinstance(cfg, AlertsConfig)
    assert cfg.audit_log == "/var/log/audit.jsonl"
    assert cfg.min_interval_secs == 30.0
    assert cfg.poll_interval_secs == 0.5
    assert len(cfg.rules) == 2
    assert len(cfg.targets) == 1
    assert isinstance(cfg.targets[0], StdoutTarget)


def test_load_config_env_overrides_secrets(tmp_path, monkeypatch):
    cfg_path = tmp_path / "alerts.toml"
    cfg_path.write_text(textwrap.dedent("""
        audit_log = "/var/log/audit.jsonl"
        [targets.slack]
        webhook_url = "https://placeholder"
    """))
    monkeypatch.setenv("SLACK_WEBHOOK_URL", "https://real-secret-url")
    monkeypatch.setenv("PAGERDUTY_ROUTING_KEY", "rk-from-env")
    cfg = load_config(cfg_path)
    # Both targets present even though TOML had only slack.
    target_kinds = {type(t).__name__ for t in cfg.targets}
    assert target_kinds == {"SlackTarget", "PagerDutyTarget"}
    # Slack URL got overridden.
    slack = next(t for t in cfg.targets if isinstance(t, SlackTarget))
    assert slack._url == "https://real-secret-url"
    pd = next(t for t in cfg.targets if isinstance(t, PagerDutyTarget))
    assert pd._routing_key == "rk-from-env"


def test_load_config_audit_log_env_override(tmp_path, monkeypatch):
    cfg_path = tmp_path / "alerts.toml"
    cfg_path.write_text(textwrap.dedent("""
        audit_log = "/wrong/path"
        [targets]
        stdout = true
    """))
    monkeypatch.setenv("LLM_LEASH_ALERTS_AUDIT_LOG", "/correct/path")
    cfg = load_config(cfg_path)
    assert cfg.audit_log == "/correct/path"


def test_load_config_no_audit_log_raises(tmp_path):
    cfg_path = tmp_path / "alerts.toml"
    cfg_path.write_text(textwrap.dedent("""
        [targets]
        stdout = true
    """))
    with pytest.raises(ValueError, match="audit_log"):
        load_config(cfg_path)


def test_load_config_no_targets_adds_stdout_fallback(tmp_path):
    cfg_path = tmp_path / "alerts.toml"
    cfg_path.write_text(textwrap.dedent("""
        audit_log = "/var/log/audit.jsonl"
        [[rules]]
        type = "single"
        name = "r"
        template = "t"
    """))
    cfg = load_config(cfg_path)
    assert len(cfg.targets) == 1
    assert isinstance(cfg.targets[0], StdoutTarget)


# ─── dispatch ────────────────────────────────────────────────────


class _RecordingTarget:
    def __init__(self) -> None:
        self.sent: list[Alert] = []

    async def send(self, alert: Alert) -> None:
        self.sent.append(alert)


@pytest.mark.asyncio
async def test_dispatch_sends_each_alert_to_each_target():
    t1, t2 = _RecordingTarget(), _RecordingTarget()
    a1 = Alert(
        rule_name="r1", severity="warning", message="m1",
        triggered_event={}, context={},
    )
    a2 = Alert(
        rule_name="r2", severity="critical", message="m2",
        triggered_event={}, context={},
    )
    await dispatch([a1, a2], [t1, t2])
    assert [a.rule_name for a in t1.sent] == ["r1", "r2"]
    assert [a.rule_name for a in t2.sent] == ["r1", "r2"]


@pytest.mark.asyncio
async def test_dispatch_target_failure_does_not_crash():
    """If one target raises, others still get the alert."""

    class _BadTarget:
        async def send(self, alert: Alert) -> None:
            raise RuntimeError("boom")

    good = _RecordingTarget()
    bad = _BadTarget()
    a = Alert(rule_name="r", severity="warning", message="m",
              triggered_event={}, context={})
    # Should not raise even though one target fails.
    await dispatch([a], [bad, good])
    assert len(good.sent) == 1


# ─── End-to-end runner loop ─────────────────────────────────────


@pytest.mark.asyncio
async def test_run_loop_fires_on_appended_event(tmp_path):
    """Append a matching event to the log → engine fires → target receives."""
    log = tmp_path / "audit.jsonl"
    log.write_text("")  # start empty so EOF == 0

    recorder = _RecordingTarget()
    cfg = AlertsConfig(
        audit_log=str(log),
        rules=[SingleEventRule(
            name="any_kill", severity="warning", template="kill: {reason}",
            match={"kind": "kill"},
        )],
        targets=[recorder],
        min_interval_secs=0.0,
        poll_interval_secs=0.05,  # tight polling so the test is fast
    )

    runner_task = asyncio.create_task(run_loop(cfg))
    try:
        # Let runner reach EOF baseline.
        await asyncio.sleep(0.1)
        with log.open("a") as f:
            f.write('{"kind":"kill","reason":"manual abort"}\n')
            f.flush()
        # Allow runner one polling cycle + dispatch.
        await asyncio.sleep(0.3)
    finally:
        runner_task.cancel()
        try:
            await runner_task
        except asyncio.CancelledError:
            pass

    assert len(recorder.sent) == 1
    assert recorder.sent[0].rule_name == "any_kill"
    assert "manual abort" in recorder.sent[0].message


@pytest.mark.asyncio
async def test_run_loop_ignores_malformed_lines(tmp_path):
    """Garbage lines in the audit log don't crash the runner."""
    log = tmp_path / "audit.jsonl"
    log.write_text("")

    recorder = _RecordingTarget()
    cfg = AlertsConfig(
        audit_log=str(log),
        rules=[SingleEventRule(
            name="r", severity="warning", template="t",
            match={"kind": "k"},
        )],
        targets=[recorder],
        min_interval_secs=0.0,
        poll_interval_secs=0.05,
    )
    runner_task = asyncio.create_task(run_loop(cfg))
    try:
        await asyncio.sleep(0.1)
        with log.open("a") as f:
            f.write("not-json\n")
            f.write('{"kind":"k"}\n')
            f.flush()
        await asyncio.sleep(0.3)
    finally:
        runner_task.cancel()
        try:
            await runner_task
        except asyncio.CancelledError:
            pass
    assert len(recorder.sent) == 1
