"""Tests for AlertEngine (rule matcher + sliding windows)."""
from __future__ import annotations

import pytest

from llm_leash.alerts.engine import (
    AlertEngine,
    SingleEventRule,
    WindowCountRule,
    WindowSumRule,
    _matches,
    _render,
)


class FakeClock:
    """Monotonically increasing fake clock for window tests."""

    def __init__(self) -> None:
        self.now = 0.0

    def __call__(self) -> float:
        return self.now

    def advance(self, secs: float) -> None:
        self.now += secs


# ─── _matches ────────────────────────────────────────────────────


def test_matches_empty_conditions_matches_everything():
    assert _matches({"kind": "model_call"}, {}) is True


def test_matches_all_conditions_must_pass():
    ev = {"kind": "model_call", "tenant_id": "acme"}
    assert _matches(ev, {"kind": "model_call", "tenant_id": "acme"}) is True
    assert _matches(ev, {"kind": "model_call", "tenant_id": "beta"}) is False


def test_matches_missing_field_does_not_match():
    assert _matches({"kind": "model_call"}, {"agent_name": "analyst"}) is False


# ─── _render ─────────────────────────────────────────────────────


def test_render_simple_placeholder():
    assert _render("hi {name}", {"name": "bob"}) == "hi bob"


def test_render_nested_one_level():
    ctx = {"latest": {"reason": "bad"}}
    assert _render("reason={latest.reason}", ctx) == "reason=bad"


def test_render_missing_renders_marker():
    assert _render("v={ghost}", {"x": 1}) == "v=<missing:ghost>"


def test_render_unclosed_brace_kept_as_is():
    assert _render("hello {oops", {"oops": "v"}) == "hello {oops"


# ─── SingleEventRule ─────────────────────────────────────────────


def test_single_event_fires_on_match():
    clock = FakeClock()
    rule = SingleEventRule(
        name="secret_leaked",
        severity="critical",
        template="leak: {agent_name}",
        match={"kind": "secrets_detected"},
    )
    eng = AlertEngine([rule], clock=clock, min_interval_secs=10.0)
    alerts = eng.feed({"kind": "secrets_detected", "agent_name": "analyst"})
    assert len(alerts) == 1
    assert alerts[0].rule_name == "secret_leaked"
    assert alerts[0].severity == "critical"
    assert "analyst" in alerts[0].message


def test_single_event_does_not_fire_on_non_match():
    rule = SingleEventRule(
        name="x", severity="warning", template="t",
        match={"kind": "secrets_detected"},
    )
    eng = AlertEngine([rule])
    alerts = eng.feed({"kind": "model_call"})
    assert alerts == []


def test_single_event_cooldown_suppresses_repeats():
    clock = FakeClock()
    rule = SingleEventRule(
        name="leak", severity="critical", template="x",
        match={"kind": "secrets_detected"},
    )
    eng = AlertEngine([rule], clock=clock, min_interval_secs=60.0)

    # Three rapid-fire events; only the first should fire.
    fired = []
    for _ in range(3):
        fired.extend(eng.feed({"kind": "secrets_detected"}))
        clock.advance(5)  # 5s apart, well under 60s cooldown
    assert len(fired) == 1

    # After cooldown elapses, next event fires again.
    clock.advance(120)
    fired_again = eng.feed({"kind": "secrets_detected"})
    assert len(fired_again) == 1


# ─── WindowCountRule ─────────────────────────────────────────────


def test_window_count_fires_at_threshold():
    clock = FakeClock()
    rule = WindowCountRule(
        name="shell_burst", severity="warning",
        template="{count} shells in {window_secs}s",
        match={"kind": "model_call", "rule_id": "blocked_shell"},
        window_secs=600.0,
        count_threshold=3,
    )
    eng = AlertEngine([rule], clock=clock, min_interval_secs=60.0)

    # First two don't fire; third does.
    assert eng.feed({"kind": "model_call", "rule_id": "blocked_shell"}) == []
    clock.advance(1)
    assert eng.feed({"kind": "model_call", "rule_id": "blocked_shell"}) == []
    clock.advance(1)
    fired = eng.feed({"kind": "model_call", "rule_id": "blocked_shell"})
    assert len(fired) == 1
    assert fired[0].context["count"] == 3


def test_window_count_evicts_old_events():
    """Events older than window_secs don't count toward threshold."""
    clock = FakeClock()
    rule = WindowCountRule(
        name="r", severity="warning", template="t",
        match={"kind": "k"},
        window_secs=10.0,
        count_threshold=3,
    )
    eng = AlertEngine([rule], clock=clock, min_interval_secs=0.0)

    # 2 events at t=0
    eng.feed({"kind": "k"})
    eng.feed({"kind": "k"})

    # Wait past window — those 2 expire.
    clock.advance(15)

    # Only 1 fresh event — well below threshold.
    fired = eng.feed({"kind": "k"})
    assert fired == []


def test_window_count_only_matches_count_not_unrelated():
    """Other events don't increment the window."""
    clock = FakeClock()
    rule = WindowCountRule(
        name="r", severity="warning", template="t",
        match={"kind": "kill"},
        window_secs=60.0, count_threshold=2,
    )
    eng = AlertEngine([rule], clock=clock, min_interval_secs=0.0)
    eng.feed({"kind": "model_call"})  # ignored
    eng.feed({"kind": "kill"})         # 1
    eng.feed({"kind": "model_call"})  # ignored
    fired = eng.feed({"kind": "kill"})  # 2 → fire
    assert len(fired) == 1


# ─── WindowSumRule ───────────────────────────────────────────────


def test_window_sum_fires_when_threshold_exceeded():
    clock = FakeClock()
    rule = WindowSumRule(
        name="spend_spike", severity="warning",
        template="spent ${sum:.2f}",
        match={"kind": "model_call", "tenant_id": "acme"},
        window_secs=3600.0,
        sum_field="cost_usd",
        sum_threshold=10.0,
    )
    eng = AlertEngine([rule], clock=clock, min_interval_secs=0.0)

    assert eng.feed({"kind": "model_call", "tenant_id": "acme", "cost_usd": 4.0}) == []
    assert eng.feed({"kind": "model_call", "tenant_id": "acme", "cost_usd": 4.0}) == []
    fired = eng.feed({"kind": "model_call", "tenant_id": "acme", "cost_usd": 5.0})
    assert len(fired) == 1
    assert fired[0].context["sum"] == pytest.approx(13.0)
    # Template substitution worked.
    assert "spent" in fired[0].message


def test_window_sum_ignores_non_numeric_field():
    clock = FakeClock()
    rule = WindowSumRule(
        name="r", severity="warning", template="t",
        match={"kind": "k"}, window_secs=60.0,
        sum_field="cost_usd", sum_threshold=1.0,
    )
    eng = AlertEngine([rule], clock=clock, min_interval_secs=0.0)
    # cost_usd is a string — should not contribute.
    fired = eng.feed({"kind": "k", "cost_usd": "not-a-number"})
    assert fired == []


def test_window_sum_no_match_skipped():
    clock = FakeClock()
    rule = WindowSumRule(
        name="r", severity="warning", template="t",
        match={"tenant_id": "acme"},
        window_secs=60.0, sum_field="cost_usd", sum_threshold=1.0,
    )
    eng = AlertEngine([rule], clock=clock, min_interval_secs=0.0)
    # tenant_id different — must not contribute.
    fired = eng.feed({"kind": "model_call", "tenant_id": "beta", "cost_usd": 100.0})
    assert fired == []


# ─── Multi-rule engine ──────────────────────────────────────────


def test_multiple_rules_all_evaluated():
    rules = [
        SingleEventRule(
            name="secret", severity="critical", template="x",
            match={"kind": "secrets_detected"},
        ),
        SingleEventRule(
            name="kill", severity="warning", template="x",
            match={"kind": "kill"},
        ),
    ]
    eng = AlertEngine(rules, min_interval_secs=0.0)
    assert len(eng.feed({"kind": "secrets_detected"})) == 1
    assert len(eng.feed({"kind": "kill"})) == 1
    assert eng.feed({"kind": "model_call"}) == []


def test_rules_property_returns_copy():
    """Mutating the returned list doesn't affect engine state."""
    rules = [SingleEventRule(name="r", severity="warning", template="t")]
    eng = AlertEngine(rules)
    snapshot = eng.rules
    snapshot.clear()
    assert len(eng.rules) == 1
