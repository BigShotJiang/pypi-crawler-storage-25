from __future__ import annotations

import pathlib

import pytest

from llm_leash.audit.schema import ModelCall
from llm_leash.audit.verify import ChainBroken, verify_chain
from llm_leash.audit.writer import AuditWriter


def make_call(seq: int) -> ModelCall:
    return ModelCall(
        ts="2026-05-16T12:00:00.000000Z", session_id="s1", tenant_id=None,
        seq=seq, prev_hash="0" * 64,
        provider="anthropic", model="claude-opus-4-7",
        input_tokens=100, output_tokens=50, cost_usd=0.00525,
        request_hash="a" * 64, response_hash="b" * 64,
    )


def test_verify_empty_file_passes(tmp_path: pathlib.Path):
    p = tmp_path / "audit.jsonl"
    p.touch()
    assert verify_chain(str(p)) == 0


def test_verify_clean_chain_returns_event_count(tmp_path: pathlib.Path):
    p = tmp_path / "audit.jsonl"
    w = AuditWriter(str(p), fsync=False)
    for i in range(5):
        w.write(make_call(i))
    assert verify_chain(str(p)) == 5


def test_verify_detects_tampered_hash(tmp_path: pathlib.Path):
    p = tmp_path / "audit.jsonl"
    w = AuditWriter(str(p), fsync=False)
    w.write(make_call(0))
    w.write(make_call(1))
    w.close()

    # Flip one character of the first line's hash.
    lines = p.read_text().splitlines()
    lines[0] = lines[0].replace('"hash":"', '"hash":"X', 1)
    p.write_text("\n".join(lines) + "\n")

    with pytest.raises(ChainBroken) as exc:
        verify_chain(str(p))
    assert "line 1" in str(exc.value).lower() or "seq 0" in str(exc.value).lower()


def test_verify_detects_broken_prev_hash(tmp_path: pathlib.Path):
    p = tmp_path / "audit.jsonl"
    w = AuditWriter(str(p), fsync=False)
    w.write(make_call(0))
    w.write(make_call(1))
    w.close()

    # Replace second line's prev_hash with all zeros (breaks linkage).
    lines = p.read_text().splitlines()
    import json as _j
    second = _j.loads(lines[1])
    second["prev_hash"] = "0" * 64
    lines[1] = _j.dumps(second, sort_keys=True, separators=(",", ":"))
    p.write_text("\n".join(lines) + "\n")

    with pytest.raises(ChainBroken):
        verify_chain(str(p))
