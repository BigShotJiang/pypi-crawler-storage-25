from __future__ import annotations

import json
import pathlib

from llm_leash.audit.schema import BudgetEvent, ModelCall
from llm_leash.audit.writer import AuditWriter


def make_model_call(seq: int, prev: str) -> ModelCall:
    return ModelCall(
        ts="2026-05-16T12:00:00.000000Z",
        session_id="s1", tenant_id=None, seq=seq, prev_hash=prev,
        provider="anthropic", model="claude-opus-4-7",
        input_tokens=100, output_tokens=50, cost_usd=0.00525,
        request_hash="a" * 64, response_hash="b" * 64,
    )


def test_writer_appends_one_line_per_event(tmp_path: pathlib.Path):
    path = tmp_path / "audit.jsonl"
    w = AuditWriter(str(path), fsync=False)
    ev = make_model_call(seq=0, prev="0" * 64)
    written = w.write(ev)
    assert written.seq == 0
    assert written.prev_hash == "0" * 64
    assert written.hash and len(written.hash) == 64

    lines = path.read_text().strip().split("\n")
    assert len(lines) == 1
    parsed = json.loads(lines[0])
    assert parsed["hash"] == written.hash
    assert parsed["kind"] == "model_call"


def test_writer_chains_prev_hash(tmp_path: pathlib.Path):
    path = tmp_path / "audit.jsonl"
    w = AuditWriter(str(path), fsync=False)
    e0 = w.write(make_model_call(seq=0, prev="0" * 64))
    e1 = w.write(make_model_call(seq=1, prev="ignored"))  # writer should overwrite

    assert e1.prev_hash == e0.hash
    assert e1.hash != e0.hash


def test_writer_assigns_seq_automatically(tmp_path: pathlib.Path):
    path = tmp_path / "audit.jsonl"
    w = AuditWriter(str(path), fsync=False)
    e0 = w.write(make_model_call(seq=999, prev="x"))
    e1 = w.write(make_model_call(seq=999, prev="y"))
    assert e0.seq == 0
    assert e1.seq == 1


def test_writer_resumes_from_existing_file(tmp_path: pathlib.Path):
    path = tmp_path / "audit.jsonl"
    w1 = AuditWriter(str(path), fsync=False)
    first = w1.write(make_model_call(seq=0, prev="0" * 64))

    w2 = AuditWriter(str(path), fsync=False)
    second = w2.write(make_model_call(seq=0, prev="0" * 64))
    assert second.seq == 1
    assert second.prev_hash == first.hash


def test_writer_handles_budget_event(tmp_path: pathlib.Path):
    path = tmp_path / "audit.jsonl"
    w = AuditWriter(str(path), fsync=False)
    ev = BudgetEvent(
        ts="2026-05-16T12:00:00.000000Z", session_id="s1", tenant_id=None,
        seq=0, prev_hash="0" * 64,
        cumulative_usd=1.5, cap_usd=10.0, decision="under",
    )
    written = w.write(ev)
    assert written.hash
    parsed = json.loads(path.read_text().strip())
    assert parsed["kind"] == "budget"
