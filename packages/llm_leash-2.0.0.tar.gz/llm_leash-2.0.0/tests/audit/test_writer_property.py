from __future__ import annotations

import hashlib
import json

from hypothesis import given, settings
from hypothesis import strategies as st

from llm_leash.audit.schema import BudgetEvent, KillEvent, ModelCall
from llm_leash.audit.writer import AuditWriter


def _arbitrary_event(seq: int, prev: str):
    return ModelCall(
        ts="2026-05-16T12:00:00.000000Z", session_id="s1", tenant_id=None,
        seq=seq, prev_hash=prev,
        provider="anthropic", model="claude-opus-4-7",
        input_tokens=1, output_tokens=1, cost_usd=0.0001,
        request_hash="r" * 64, response_hash="x" * 64,
    )


@settings(max_examples=50, deadline=None)
@given(n=st.integers(min_value=1, max_value=30))
def test_chain_is_unbroken_for_any_length(tmp_path_factory, n):
    path = tmp_path_factory.mktemp("a") / "audit.jsonl"
    w = AuditWriter(str(path), fsync=False)
    for i in range(n):
        w.write(_arbitrary_event(seq=i, prev="0" * 64))

    lines = path.read_text().splitlines()
    assert len(lines) == n

    prev = "0" * 64
    for line in lines:
        parsed = json.loads(line)
        assert parsed["prev_hash"] == prev
        # Recompute hash from canonical JSON excluding hash field.
        without_hash = {k: v for k, v in parsed.items() if k != "hash"}
        canon = json.dumps(without_hash, sort_keys=True, separators=(",", ":"),
                           ensure_ascii=False).encode("utf-8")
        recomputed = hashlib.sha256(canon).hexdigest()
        assert recomputed == parsed["hash"]
        prev = parsed["hash"]


@settings(max_examples=30, deadline=None)
@given(
    kinds=st.lists(
        st.sampled_from(["model", "budget", "kill"]),
        min_size=1, max_size=15,
    )
)
def test_mixed_event_kinds_preserve_chain(tmp_path_factory, kinds):
    path = tmp_path_factory.mktemp("b") / "audit.jsonl"
    w = AuditWriter(str(path), fsync=False)

    for i, kind in enumerate(kinds):
        if kind == "model":
            ev = _arbitrary_event(seq=i, prev="x")
        elif kind == "budget":
            ev = BudgetEvent(
                ts="2026-05-16T12:00:00.000000Z", session_id="s1", tenant_id=None,
                seq=i, prev_hash="x",
                cumulative_usd=float(i), cap_usd=100.0, decision="under",
            )
        else:
            ev = KillEvent(
                ts="2026-05-16T12:00:00.000000Z", session_id="s1", tenant_id=None,
                seq=i, prev_hash="x", reason="hypothesis",
            )
        w.write(ev)

    prev = "0" * 64
    for line in path.read_text().splitlines():
        parsed = json.loads(line)
        assert parsed["prev_hash"] == prev
        prev = parsed["hash"]
