from __future__ import annotations

from llm_leash.audit.schema import (
    BudgetEvent,
    KillEvent,
    ModelCall,
    canonical_json,
)


def test_model_call_serializes_to_canonical_json():
    ev = ModelCall(
        ts="2026-05-16T12:00:00.000000Z",
        session_id="s1",
        tenant_id=None,
        seq=0,
        prev_hash="0" * 64,
        provider="anthropic",
        model="claude-opus-4-7",
        input_tokens=100,
        output_tokens=50,
        cost_usd=0.00525,
        request_hash="a" * 64,
        response_hash="b" * 64,
    )
    out = canonical_json(ev)
    # Keys sorted, no whitespace.
    assert b'"kind":"model_call"' in out
    assert b'"seq":0' in out
    assert b' ' not in out


def test_canonical_json_is_deterministic():
    ev1 = BudgetEvent(
        ts="2026-05-16T12:00:00.000000Z", session_id="s1", tenant_id=None, seq=1,
        prev_hash="0" * 64, cumulative_usd=1.0, cap_usd=10.0, decision="under",
    )
    ev2 = BudgetEvent(
        ts="2026-05-16T12:00:00.000000Z", session_id="s1", tenant_id=None, seq=1,
        prev_hash="0" * 64, cumulative_usd=1.0, cap_usd=10.0, decision="under",
    )
    assert canonical_json(ev1) == canonical_json(ev2)


def test_kill_event_canonical_json_includes_reason():
    ev = KillEvent(
        ts="2026-05-16T12:00:00.000000Z", session_id="s1", tenant_id=None, seq=2,
        prev_hash="0" * 64, reason="manual kill",
    )
    out = canonical_json(ev)
    assert b'"reason":"manual kill"' in out
    assert b'"kind":"kill"' in out
