"""Tests for the SOC 2 evidence pack generator."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

from llm_leash.audit.schema import KillEvent, ModelCall, ToolCallEvent
from llm_leash.audit.soc2 import SOC2Report, generate_report
from llm_leash.audit.writer import AuditWriter


def _write_log(path: Path, events: list) -> None:
    """Write a real hash-chained log with the given events."""
    w = AuditWriter(str(path), fsync=False)
    for ev in events:
        w.write(ev)
    w.close()


# ─── Fixtures ──────────────────────────────────────────────────────


@pytest.fixture
def valid_log(tmp_path):
    """A small chained log: 3 model_calls + 1 kill + 1 tool_call."""
    p = tmp_path / "audit.jsonl"
    _write_log(p, [
        ModelCall(
            ts="2026-06-01T00:00:00Z", session_id="alice", tenant_id="acme",
            seq=0, prev_hash="x",
            provider="openai", model="gpt-4o",
            input_tokens=100, output_tokens=50, cost_usd=0.01,
            request_hash="r1", response_hash="s1",
        ),
        ModelCall(
            ts="2026-06-02T00:00:00Z", session_id="alice", tenant_id="acme",
            seq=0, prev_hash="x",
            provider="anthropic", model="claude-haiku-4-5",
            input_tokens=200, output_tokens=100, cost_usd=0.02,
            request_hash="r2", response_hash="s2",
        ),
        ModelCall(
            ts="2026-06-03T00:00:00Z", session_id="bob", tenant_id="acme",
            seq=0, prev_hash="x",
            provider="openai", model="gpt-4o",
            input_tokens=50, output_tokens=25, cost_usd=0.005,
            request_hash="r3", response_hash="s3",
        ),
        ToolCallEvent(
            ts="2026-06-04T00:00:00Z", session_id="alice", tenant_id="acme",
            seq=0, prev_hash="x",
            tool="read_file",
            request_hash="r4", response_hash="s4",
        ),
        KillEvent(
            ts="2026-06-05T00:00:00Z", session_id="bob", tenant_id="acme",
            seq=0, prev_hash="x",
            reason="manual abort",
        ),
    ])
    return p


# ─── Smoke / API ──────────────────────────────────────────────────


def test_generate_report_returns_soc2report(tmp_path):
    log = tmp_path / "audit.jsonl"
    log.write_text("")
    r = generate_report(
        str(log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    assert isinstance(r, SOC2Report)
    assert r.output_dir.exists()


def test_generate_report_creates_all_six_artefacts(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    for name in (
        "executive-summary.html",
        "cc6_access_control.csv",
        "cc7_monitoring.csv",
        "cc7_integrity.json",
        "anomalies.csv",
        "bom.json",
    ):
        assert (r.output_dir / name).exists(), f"missing artefact: {name}"


# ─── Period filtering ─────────────────────────────────────────────


def test_filters_to_period(tmp_path):
    log = tmp_path / "audit.jsonl"
    _write_log(log, [
        ModelCall(
            ts="2026-01-15T00:00:00Z", session_id="s1", tenant_id=None,
            seq=0, prev_hash="x",
            provider="openai", model="gpt-4o",
            input_tokens=10, output_tokens=5, cost_usd=0.001,
            request_hash="r", response_hash="s",
        ),
        ModelCall(
            ts="2026-06-15T00:00:00Z", session_id="s2", tenant_id=None,
            seq=0, prev_hash="x",
            provider="openai", model="gpt-4o",
            input_tokens=10, output_tokens=5, cost_usd=0.002,
            request_hash="r", response_hash="s",
        ),
    ])
    r = generate_report(
        str(log), str(tmp_path / "out"),
        period_start="2026-04-01T00:00:00Z",
        period_end="2026-06-30T23:59:59Z",
    )
    assert r.summary["total_events"] == 1


# ─── Integrity ─────────────────────────────────────────────────────


def test_integrity_ok_on_valid_chain(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    integrity = json.loads((r.output_dir / "cc7_integrity.json").read_text())
    assert integrity["verified"] is True
    assert integrity["event_count"] == 5
    assert integrity["error"] is None
    assert r.integrity_ok is True


def test_integrity_broken_chain_reported(tmp_path):
    log = tmp_path / "broken.jsonl"
    log.write_text(
        '{"kind":"kill","seq":1,"ts":"2026-06-01T00:00:00Z","session_id":"s",'
        '"tenant_id":null,"prev_hash":"WRONG","reason":"r","hash":"BAD"}\n'
    )
    r = generate_report(
        str(log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    integrity = json.loads((r.output_dir / "cc7_integrity.json").read_text())
    assert integrity["verified"] is False
    assert "WRONG" in (integrity["error"] or "")
    assert r.integrity_ok is False


# ─── CC6 access control ───────────────────────────────────────────


def test_cc6_one_row_per_session_tenant(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    rows = list(csv.DictReader((r.output_dir / "cc6_access_control.csv").open()))
    # alice and bob, both tenant=acme
    assert len(rows) == 2
    alice = next(r for r in rows if r["session_id"] == "alice")
    bob = next(r for r in rows if r["session_id"] == "bob")
    assert alice["model_calls"] == "2"
    assert alice["tool_calls"] == "1"
    assert alice["kills"] == "0"
    assert "claude-haiku-4-5" in alice["unique_models"]
    assert "gpt-4o" in alice["unique_models"]
    assert bob["kills"] == "1"


def test_cc6_aggregates_cost(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    rows = list(csv.DictReader((r.output_dir / "cc6_access_control.csv").open()))
    alice = next(r for r in rows if r["session_id"] == "alice")
    assert float(alice["cost_usd_total"]) == pytest.approx(0.03, abs=1e-9)


# ─── CC7 monitoring ───────────────────────────────────────────────


def test_cc7_monitoring_lists_kill_events(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    rows = list(csv.DictReader((r.output_dir / "cc7_monitoring.csv").open()))
    assert len(rows) == 1
    assert rows[0]["event_type"] == "kill"
    assert rows[0]["session_id"] == "bob"
    assert "manual abort" in rows[0]["reason"]


# ─── Anomalies ────────────────────────────────────────────────────


def test_anomalies_kill_spike_flagged(tmp_path):
    log = tmp_path / "audit.jsonl"
    # Three kill events on the same session → flagged
    _write_log(log, [
        KillEvent(
            ts=f"2026-06-0{i + 1}T00:00:00Z", session_id="hot", tenant_id=None,
            seq=0, prev_hash="x", reason=f"abort #{i}",
        )
        for i in range(3)
    ])
    r = generate_report(
        str(log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    rows = list(csv.DictReader((r.output_dir / "anomalies.csv").open()))
    assert any(r["kind"] == "kill_spike" and r["session_id"] == "hot" for r in rows)


def test_anomalies_empty_when_no_outliers(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    rows = list(csv.DictReader((r.output_dir / "anomalies.csv").open()))
    # valid_log has only 1 kill on bob — not enough for kill_spike (need ≥3)
    assert all(r["session_id"] != "bob" or r["kind"] != "kill_spike" for r in rows)


# ─── BOM ──────────────────────────────────────────────────────────


def test_bom_contains_file_manifest(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    bom = json.loads((r.output_dir / "bom.json").read_text())
    assert bom["source_audit_log"]["sha256"]
    assert bom["source_audit_log"]["size_bytes"] > 0
    file_names = {f["path"] for f in bom["files"]}
    expected = {
        "executive-summary.html", "cc6_access_control.csv",
        "cc7_monitoring.csv", "cc7_integrity.json", "anomalies.csv",
    }
    assert expected.issubset(file_names)
    for entry in bom["files"]:
        assert len(entry["sha256"]) == 64  # sha256 hex
        assert entry["size_bytes"] >= 0


def test_bom_records_integrity_verdict(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    bom = json.loads((r.output_dir / "bom.json").read_text())
    assert bom["integrity"]["verified"] is True
    assert bom["integrity"]["event_count"] == 5


# ─── Executive summary HTML ───────────────────────────────────────


def test_html_contains_period_and_verdict(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-04-01T00:00:00Z",
        period_end="2026-06-30T23:59:59Z",
        organization_name="Acme Inc",
    )
    html_text = (r.output_dir / "executive-summary.html").read_text()
    assert "Acme Inc" in html_text
    assert "2026-04-01T00:00:00Z" in html_text
    assert "VERIFIED" in html_text
    assert "<table" in html_text


def test_html_escapes_organization_name(tmp_path, valid_log):
    r = generate_report(
        str(valid_log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
        organization_name="<script>alert(1)</script>",
    )
    html_text = (r.output_dir / "executive-summary.html").read_text()
    assert "<script>alert(1)</script>" not in html_text
    assert "&lt;script&gt;" in html_text


def test_html_broken_chain_shows_bad_verdict(tmp_path):
    log = tmp_path / "broken.jsonl"
    log.write_text(
        '{"kind":"kill","seq":1,"ts":"2026-06-01T00:00:00Z","session_id":"s",'
        '"tenant_id":null,"prev_hash":"WRONG","reason":"r","hash":"BAD"}\n'
    )
    r = generate_report(
        str(log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    html_text = (r.output_dir / "executive-summary.html").read_text()
    assert "BROKEN" in html_text


# ─── Empty log ────────────────────────────────────────────────────


def test_empty_log_generates_clean_report(tmp_path):
    log = tmp_path / "empty.jsonl"
    log.write_text("")
    r = generate_report(
        str(log), str(tmp_path / "out"),
        period_start="2026-01-01T00:00:00Z",
        period_end="2026-12-31T23:59:59Z",
    )
    assert r.summary["total_events"] == 0
    assert (r.output_dir / "executive-summary.html").exists()
