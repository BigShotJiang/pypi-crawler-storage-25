"""Tests for audit.replay (replay generator + CSV/JSON export)."""
from __future__ import annotations

import csv
import io
import json

import pytest

from llm_leash import Firewall
from llm_leash.audit.replay import export_csv, export_json, replay


@pytest.fixture
def populated_log(tmp_path):
    """A real Firewall run produces a chained audit log with 3 model_call events."""
    log = tmp_path / "audit.jsonl"
    fw = Firewall(budget_usd=10.0, audit_log=str(log), session_id="s1")

    class _FakeMsgs:
        def create(self, **kwargs):
            from dataclasses import dataclass
            @dataclass
            class U:
                input_tokens: int
                output_tokens: int
            @dataclass
            class R:
                model: str
                usage: U
                content: list
            return R(
                model=kwargs["model"],
                usage=U(100, 50),
                content=[{"type": "text", "text": "ok"}],
            )

    class _FakeClient:
        def __init__(self):
            self.messages = _FakeMsgs()

    client = fw.wrap(_FakeClient())
    for _ in range(3):
        client.messages.create(
            model="claude-haiku-4-5", max_tokens=100,
            messages=[{"role": "user", "content": "hi"}],
        )
    return log


# ─── replay() ──────────────────────────────────────────────


def test_replay_yields_events_in_order(populated_log):
    events = list(replay(str(populated_log)))
    assert len(events) == 3
    seqs = [e["seq"] for e in events]
    assert seqs == [0, 1, 2]
    assert all(e["kind"] == "model_call" for e in events)


def test_replay_empty_file_yields_nothing(tmp_path):
    p = tmp_path / "empty.jsonl"
    p.write_text("")
    assert list(replay(str(p))) == []


def test_replay_missing_file_yields_nothing(tmp_path):
    assert list(replay(str(tmp_path / "no_such_file.jsonl"))) == []


def test_replay_skips_blank_lines(tmp_path):
    p = tmp_path / "audit.jsonl"
    p.write_text('\n{"kind":"kill","seq":1,"ts":"x","session_id":"s","tenant_id":null,'
                 '"prev_hash":"x","reason":"r","hash":"h"}\n\n')
    events = list(replay(str(p)))
    assert len(events) == 1


# ─── export_json ──────────────────────────────────────────


def test_export_json_round_trips(populated_log):
    buf = io.StringIO()
    n = export_json(str(populated_log), buf)
    assert n == 3
    arr = json.loads(buf.getvalue())
    assert len(arr) == 3
    assert arr[0]["seq"] == 0


# ─── export_csv ───────────────────────────────────────────


def test_export_csv_has_expected_columns(populated_log):
    buf = io.StringIO()
    n = export_csv(str(populated_log), buf)
    assert n == 3
    buf.seek(0)
    reader = csv.DictReader(buf)
    rows = list(reader)
    assert len(rows) == 3
    for row in rows:
        for col in ("ts", "session_id", "seq", "kind", "provider", "model"):
            assert col in row
        assert row["kind"] == "model_call"
        assert row["model"] == "claude-haiku-4-5"


def test_export_csv_handles_mixed_event_kinds(tmp_path):
    """CSV export must include columns from every kind present."""
    log = tmp_path / "audit.jsonl"
    log.write_text(
        '{"kind":"model_call","seq":1,"ts":"t","session_id":"s","tenant_id":null,'
        '"prev_hash":"x","provider":"openai","model":"gpt-4o","input_tokens":10,'
        '"output_tokens":5,"cost_usd":0.01,"request_hash":"a","response_hash":"b","hash":"h1"}\n'
        '{"kind":"kill","seq":2,"ts":"t","session_id":"s","tenant_id":null,'
        '"prev_hash":"h1","reason":"manual","hash":"h2"}\n'
        '{"kind":"tool_call","seq":3,"ts":"t","session_id":"s","tenant_id":null,'
        '"prev_hash":"h2","tool":"read_file","request_hash":"r","response_hash":"s","hash":"h3"}\n'
    )
    buf = io.StringIO()
    n = export_csv(str(log), buf)
    assert n == 3
    buf.seek(0)
    rows = list(csv.DictReader(buf))
    # Each row should have all union columns; missing fields are empty strings.
    assert rows[0]["model"] == "gpt-4o"
    assert rows[0]["reason"] == ""
    assert rows[0]["tool"] == ""
    assert rows[1]["reason"] == "manual"
    assert rows[1]["model"] == ""
    assert rows[2]["tool"] == "read_file"


def test_export_empty_log_writes_header_only(tmp_path):
    p = tmp_path / "empty.jsonl"
    p.write_text("")
    buf = io.StringIO()
    n = export_csv(str(p), buf)
    assert n == 0
    buf.seek(0)
    reader = csv.reader(buf)
    rows = list(reader)
    assert len(rows) == 1  # header only
