"""llm-leash — cost ceiling, audit log, and kill switch for LLM agents.

Public API. Everything imported here is part of the semver-stable
surface from v1.0 onwards. See API.md for the full contract.
"""
from .audit.soc2 import SOC2Report
from .audit.soc2 import generate_report as generate_soc2_report
from .budget.redis_store import RedisBudgetStore
from .budget.sqlite_store import SQLiteBudgetStore
from .firewall import Firewall
from .hitl import (
    HitlGate,
    HitlQueue,
    HitlRequest,
    InMemoryHitlGate,
    InMemoryHitlQueue,
    QueueBackedHitlGate,
    SQLiteHitlQueue,
    WebhookHitlGate,
)
from .kill.redis_registry import RedisKillRegistry
from .kill.sqlite_registry import SQLiteKillRegistry
from .kill.transport_http import HTTPKillRegistry
from .policy import (
    AgentProfile,
    BaselineStore,
    BehavioralBaselineRule,
    BlockedPatterns,
    BlockedShell,
    BlockedSql,
    BudgetThreshold,
    HitlThreshold,
    InMemoryBaselineStore,
    LlamaFirewallRule,
    LLMGuardRule,
    PiiRedactor,
    PolicyEngine,
    PresidioRule,
    SecretsRule,
    SQLiteBaselineStore,
)
from .types import (
    Action,
    Decision,
    LeashBlocked,
    LeashKilled,
    LeashRejectedByHuman,
    PolicyContext,
    Rule,
    ToolCall,
)

__version__ = "2.0.0"

__all__ = [
    "Action",
    "AgentProfile",
    "BaselineStore",
    "BehavioralBaselineRule",
    "BlockedPatterns",
    "BlockedShell",
    "BlockedSql",
    "BudgetThreshold",
    "Decision",
    "Firewall",
    "HTTPKillRegistry",
    "HitlGate",
    "HitlQueue",
    "HitlRequest",
    "HitlThreshold",
    "InMemoryBaselineStore",
    "InMemoryHitlGate",
    "InMemoryHitlQueue",
    "LLMGuardRule",
    "LeashBlocked",
    "LeashKilled",
    "LeashRejectedByHuman",
    "LlamaFirewallRule",
    "PiiRedactor",
    "PolicyContext",
    "PolicyEngine",
    "PresidioRule",
    "QueueBackedHitlGate",
    "RedisBudgetStore",
    "RedisKillRegistry",
    "Rule",
    "SOC2Report",
    "SQLiteBaselineStore",
    "SQLiteBudgetStore",
    "SQLiteHitlQueue",
    "SQLiteKillRegistry",
    "SecretsRule",
    "ToolCall",
    "WebhookHitlGate",
    "__version__",
    "generate_soc2_report",
]
