"""Alert engine: match audit events against rules + sliding-window aggregates.

Each rule is declarative. Three flavours:

  - Single-event match: any event whose fields match triggers immediately.
  - Sliding-window count: trigger when ≥ N matching events arrive within
    a window of T seconds.
  - Sliding-window sum: trigger when the sum of a numeric field across
    matching events exceeds a threshold within the window.

This module is **pure logic** — no I/O. `runner.py` feeds events into
``AlertEngine.feed(event)`` and gets back a list of ``Alert`` objects
to dispatch.
"""
from __future__ import annotations

import time
from collections import deque
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

# ─── Alert dataclasses ───────────────────────────────────────────────


@dataclass(frozen=True)
class Alert:
    """A fired alert, ready to be dispatched to targets."""
    rule_name: str
    severity: str           # "info" | "warning" | "critical"
    message: str
    triggered_event: Mapping[str, Any]
    context: Mapping[str, Any]   # window count / sum / etc.


# ─── Rule types ──────────────────────────────────────────────────────


def _matches(event: Mapping[str, Any], conditions: Mapping[str, Any]) -> bool:
    """Return True iff every (k, v) in conditions matches event[k] == v.

    Missing fields don't match. Empty conditions match everything.
    """
    for k, v in conditions.items():
        if event.get(k) != v:
            return False
    return True


def _render(template: str, context: Mapping[str, Any]) -> str:
    """Render a {placeholder} template using the supplied context.

    Supports nested access via ``{section.key}`` (one level). Missing
    keys render as ``<missing:foo>`` rather than raising — alerts
    fired with partial data are still useful.
    """
    out = []
    i = 0
    while i < len(template):
        if template[i] == "{":
            end = template.find("}", i)
            if end < 0:
                out.append(template[i:])
                break
            key = template[i + 1 : end]
            value: Any = context
            for part in key.split("."):
                if isinstance(value, Mapping) and part in value:
                    value = value[part]
                else:
                    value = f"<missing:{key}>"
                    break
            out.append(str(value))
            i = end + 1
        else:
            out.append(template[i])
            i += 1
    return "".join(out)


@dataclass
class SingleEventRule:
    """Fire immediately when an event matches `match`."""
    name: str
    severity: str
    template: str
    match: dict[str, Any] = field(default_factory=dict)


@dataclass
class WindowCountRule:
    """Fire when ≥ count_threshold matching events fall inside window_secs.

    Tracks ALL matching events in a deque; expires entries older than
    window_secs on each feed.
    """
    name: str
    severity: str
    template: str
    window_secs: float
    count_threshold: int
    match: dict[str, Any] = field(default_factory=dict)


@dataclass
class WindowSumRule:
    """Fire when the sum of `sum_field` across matching events in the
    window exceeds `sum_threshold`."""
    name: str
    severity: str
    template: str
    window_secs: float
    sum_field: str
    sum_threshold: float
    match: dict[str, Any] = field(default_factory=dict)


Rule = SingleEventRule | WindowCountRule | WindowSumRule


# ─── Engine ──────────────────────────────────────────────────────────


class AlertEngine:
    """Stateful alert evaluator.

    Holds per-rule sliding windows. Single-event rules consume zero
    state. Window rules deque events tagged with arrival timestamp.

    Anti-spam: each rule has a cooldown (default ``min_interval_secs``).
    Once a rule fires, suppress subsequent fires for the cooldown
    period. Reset when no matches arrive for ``min_interval_secs``
    consecutively.
    """

    def __init__(
        self,
        rules: list[Rule],
        *,
        clock: Any = time.monotonic,
        min_interval_secs: float = 60.0,
    ) -> None:
        self._rules = rules
        self._clock = clock
        self._min_interval = min_interval_secs
        # Per-rule state.
        self._windows: dict[str, deque[tuple[float, Mapping[str, Any]]]] = {
            r.name: deque() for r in rules
            if isinstance(r, WindowCountRule | WindowSumRule)
        }
        self._last_fired: dict[str, float] = {}

    @property
    def rules(self) -> list[Rule]:
        """Read-only view."""
        return list(self._rules)

    def feed(self, event: Mapping[str, Any]) -> list[Alert]:
        """Process one event. Return any alerts that fire."""
        now = self._clock()
        alerts: list[Alert] = []

        for rule in self._rules:
            if not _matches(event, rule.match):
                continue

            if isinstance(rule, SingleEventRule):
                alerts.extend(self._maybe_fire_single(rule, event, now))
            elif isinstance(rule, WindowCountRule):
                alerts.extend(self._handle_window_count(rule, event, now))
            elif isinstance(rule, WindowSumRule):
                alerts.extend(self._handle_window_sum(rule, event, now))

        return alerts

    def _maybe_fire_single(
        self,
        rule: SingleEventRule,
        event: Mapping[str, Any],
        now: float,
    ) -> list[Alert]:
        if self._cooled_down(rule.name, now):
            return []
        self._last_fired[rule.name] = now
        return [Alert(
            rule_name=rule.name,
            severity=rule.severity,
            message=_render(rule.template, {**event, "latest": event}),
            triggered_event=dict(event),
            context={},
        )]

    def _handle_window_count(
        self,
        rule: WindowCountRule,
        event: Mapping[str, Any],
        now: float,
    ) -> list[Alert]:
        window = self._windows[rule.name]
        window.append((now, event))
        self._evict_old(window, now - rule.window_secs)
        if len(window) < rule.count_threshold:
            return []
        if self._cooled_down(rule.name, now):
            return []
        self._last_fired[rule.name] = now
        context = {
            "count": len(window),
            "latest": event,
            **event,
        }
        return [Alert(
            rule_name=rule.name,
            severity=rule.severity,
            message=_render(rule.template, context),
            triggered_event=dict(event),
            context={"count": len(window), "window_secs": rule.window_secs},
        )]

    def _handle_window_sum(
        self,
        rule: WindowSumRule,
        event: Mapping[str, Any],
        now: float,
    ) -> list[Alert]:
        window = self._windows[rule.name]
        # Only tracked events contribute to the sum; we skip events
        # where sum_field is missing or not numeric.
        val = event.get(rule.sum_field)
        if not isinstance(val, int | float):
            return []
        window.append((now, event))
        self._evict_old(window, now - rule.window_secs)
        total = sum(
            float(e.get(rule.sum_field, 0.0) or 0.0)
            for _, e in window
        )
        if total < rule.sum_threshold:
            return []
        if self._cooled_down(rule.name, now):
            return []
        self._last_fired[rule.name] = now
        context = {
            "sum": total,
            "count": len(window),
            "latest": event,
            **event,
        }
        return [Alert(
            rule_name=rule.name,
            severity=rule.severity,
            message=_render(rule.template, context),
            triggered_event=dict(event),
            context={
                "sum": total, "count": len(window),
                "window_secs": rule.window_secs,
            },
        )]

    def _evict_old(
        self,
        window: deque[tuple[float, Mapping[str, Any]]],
        cutoff: float,
    ) -> None:
        while window and window[0][0] < cutoff:
            window.popleft()

    def _cooled_down(self, rule_name: str, now: float) -> bool:
        last = self._last_fired.get(rule_name)
        if last is None:
            return False
        return (now - last) < self._min_interval


__all__ = [
    "Alert",
    "AlertEngine",
    "Rule",
    "SingleEventRule",
    "WindowCountRule",
    "WindowSumRule",
]
