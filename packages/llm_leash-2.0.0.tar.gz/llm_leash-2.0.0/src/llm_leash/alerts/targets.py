"""Alert dispatch targets: Slack incoming webhook + PagerDuty Events API.

Each target implements ``async send(alert)``. Targets are stateless;
the runner builds them once at startup and feeds every fired ``Alert``
through them.

Duck-typed protocol via ``AlertTarget`` — users can supply custom
targets (e.g. Discord, Microsoft Teams, internal webhook) without
patching the package.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Protocol, runtime_checkable

import httpx

from .engine import Alert

log = logging.getLogger("llm_leash.alerts.targets")


@runtime_checkable
class AlertTarget(Protocol):
    async def send(self, alert: Alert) -> None: ...


# ─── Slack ────────────────────────────────────────────────────────────


_SLACK_SEVERITY_EMOJI = {
    "info": ":information_source:",
    "warning": ":warning:",
    "critical": ":rotating_light:",
}
_SLACK_SEVERITY_COLOR = {
    "info": "#3b82f6",
    "warning": "#d97706",
    "critical": "#dc2626",
}


class SlackTarget:
    """Send alerts to a Slack incoming webhook URL.

    Uses Slack's `attachments` block so severity gets a color bar.
    Falls back to plain `text` if attachments fail to format.
    """

    def __init__(
        self,
        webhook_url: str,
        *,
        client: httpx.AsyncClient | None = None,
        timeout: float = 10.0,
        retries: int = 2,
    ) -> None:
        self._url = webhook_url
        self._client = client
        self._timeout = timeout
        self._retries = retries

    async def send(self, alert: Alert) -> None:
        emoji = _SLACK_SEVERITY_EMOJI.get(alert.severity, "•")
        color = _SLACK_SEVERITY_COLOR.get(alert.severity, "#6b7280")
        payload = {
            "text": f"{emoji} *{alert.rule_name}* — {alert.severity}",
            "attachments": [{
                "color": color,
                "text": alert.message,
                "fields": [
                    {"title": "rule", "value": alert.rule_name, "short": True},
                    {"title": "severity", "value": alert.severity, "short": True},
                ] + [
                    {"title": k, "value": str(v), "short": True}
                    for k, v in alert.context.items()
                ],
            }],
        }
        await _post_with_retry(
            self._url, payload, self._client, self._timeout, self._retries,
        )


# ─── PagerDuty ───────────────────────────────────────────────────────


_PD_SEVERITY_MAP = {
    "info": "info",
    "warning": "warning",
    "critical": "critical",
}


class PagerDutyTarget:
    """Send alerts to PagerDuty Events API v2.

    See https://developer.pagerduty.com/docs/events-api-v2/overview/
    Routing key is the integration key for the service receiving alerts.
    """

    EVENTS_URL = "https://events.pagerduty.com/v2/enqueue"

    def __init__(
        self,
        routing_key: str,
        *,
        client: httpx.AsyncClient | None = None,
        timeout: float = 10.0,
        retries: int = 2,
        # PagerDuty doesn't accept "info" — collapse to "warning" by default.
        trigger_on_severity: tuple[str, ...] = ("warning", "critical"),
    ) -> None:
        self._routing_key = routing_key
        self._client = client
        self._timeout = timeout
        self._retries = retries
        self._trigger_on = trigger_on_severity

    async def send(self, alert: Alert) -> None:
        if alert.severity not in self._trigger_on:
            return
        payload = {
            "routing_key": self._routing_key,
            "event_action": "trigger",
            "dedup_key": f"llm-leash:{alert.rule_name}",
            "payload": {
                "summary": alert.message,
                "source": "llm-leash-alerts",
                "severity": _PD_SEVERITY_MAP.get(alert.severity, "warning"),
                "custom_details": {
                    "rule_name": alert.rule_name,
                    "context": dict(alert.context),
                    "triggered_event": dict(alert.triggered_event),
                },
            },
        }
        await _post_with_retry(
            self.EVENTS_URL, payload, self._client,
            self._timeout, self._retries,
        )


# ─── Stdout (default for dev / debugging) ────────────────────────────


class StdoutTarget:
    """Print alerts to stdout. Default target so misconfigured deploys
    still surface alerts visibly."""

    async def send(self, alert: Alert) -> None:
        print(f"[{alert.severity.upper()}] {alert.rule_name}: {alert.message}")


# ─── Helpers ──────────────────────────────────────────────────────────


async def _post_with_retry(
    url: str,
    payload: dict[str, Any],
    client: httpx.AsyncClient | None,
    request_timeout: float,
    retries: int,
) -> None:
    """POST JSON; retry on 5xx and network errors up to `retries` times.

    Doesn't raise — failure to deliver an alert is logged, but the
    runner keeps processing other events. Operators monitoring this
    should also wire a self-monitoring path (Prometheus alert on
    `llm_leash_alerts_dispatch_failed_total` once that metric ships).
    """
    own_client = client is None
    active = client if client is not None else httpx.AsyncClient(timeout=request_timeout)
    try:
        last_exc: Exception | None = None
        for attempt in range(retries + 1):
            try:
                resp = await active.post(url, json=payload, timeout=request_timeout)
                if resp.status_code < 500:
                    return
                last_exc = RuntimeError(f"upstream {resp.status_code}: {resp.text[:200]}")
            except httpx.HTTPError as exc:
                last_exc = exc
            # exponential back-off: 0.5s, 1s, 2s ...
            await asyncio.sleep(0.5 * (2 ** attempt))
        log.warning(
            "alert dispatch failed after %d attempts to %s: %s",
            retries + 1, url, last_exc,
        )
    finally:
        if own_client:
            await active.aclose()


def parse_payload_summary(alert: Alert) -> str:
    """Plain-text summary suitable for any target (used by StdoutTarget)."""
    return f"[{alert.severity}] {alert.rule_name}: {alert.message}"


# Aliases for testing — easier to import.
__all__ = [
    "AlertTarget",
    "PagerDutyTarget",
    "SlackTarget",
    "StdoutTarget",
    "parse_payload_summary",
]
