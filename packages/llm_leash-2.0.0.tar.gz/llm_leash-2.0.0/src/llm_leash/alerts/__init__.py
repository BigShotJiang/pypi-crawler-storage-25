"""llm-leash-alerts — sidecar that tails the audit log and fires alerts.

Stateless rule matcher with sliding-window aggregates (count, sum) and
dispatchers for Slack incoming webhooks and PagerDuty Events API v2.

Configured via TOML. Designed to run as a separate process from the
proxy so an alerts-dispatch outage doesn't affect agent traffic.

CLI: ``llm-leash-alerts --config alerts.toml``
"""
from __future__ import annotations

from .engine import (
    Alert,
    AlertEngine,
    Rule,
    SingleEventRule,
    WindowCountRule,
    WindowSumRule,
)
from .targets import AlertTarget, PagerDutyTarget, SlackTarget, StdoutTarget

__all__ = [
    "Alert",
    "AlertEngine",
    "AlertTarget",
    "PagerDutyTarget",
    "Rule",
    "SingleEventRule",
    "SlackTarget",
    "StdoutTarget",
    "WindowCountRule",
    "WindowSumRule",
]
