"""Alerts runner: tail audit.jsonl, feed events into AlertEngine,
dispatch fired alerts to configured targets.

Config (TOML):

    audit_log = "/var/log/llmleash/audit.jsonl"

    [targets.slack]
    webhook_url = "https://hooks.slack.com/services/..."

    [targets.pagerduty]
    routing_key = "abc123..."

    [[rules]]
    name = "shell_block_burst"
    type = "window_count"
    severity = "warning"
    match = { kind = "model_call", rule_id = "blocked_shell" }
    window_secs = 600
    count_threshold = 3
    template = "{count} shell blocks in last 10m. Latest: {reason}"

    [[rules]]
    name = "secret_leaked"
    type = "single"
    severity = "critical"
    match = { kind = "secrets_detected" }
    template = "🔐 Secret detected by detector {detectors}, agent {agent_name}"

    [[rules]]
    name = "spend_spike"
    type = "window_sum"
    severity = "warning"
    match = { kind = "model_call", tenant_id = "acme" }
    window_secs = 3600
    sum_field = "cost_usd"
    sum_threshold = 10.0
    template = "💸 Tenant {tenant_id} spent ${sum:.2f} in last hour"
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .engine import (
    AlertEngine,
    Rule,
    SingleEventRule,
    WindowCountRule,
    WindowSumRule,
)
from .targets import AlertTarget, PagerDutyTarget, SlackTarget, StdoutTarget

log = logging.getLogger("llm_leash.alerts.runner")


# ─── Config loading ─────────────────────────────────────────────────


@dataclass
class AlertsConfig:
    audit_log: str
    rules: list[Rule]
    targets: list[AlertTarget]
    min_interval_secs: float = 60.0
    poll_interval_secs: float = 1.0


def _build_rule(spec: dict[str, Any]) -> Rule:
    kind = spec.get("type", "single")
    name = str(spec["name"])
    severity = str(spec.get("severity", "warning"))
    template = str(spec.get("template", ""))
    match = dict(spec.get("match", {}))

    if kind == "single":
        return SingleEventRule(
            name=name, severity=severity, template=template, match=match,
        )
    if kind == "window_count":
        return WindowCountRule(
            name=name, severity=severity, template=template, match=match,
            window_secs=float(spec["window_secs"]),
            count_threshold=int(spec["count_threshold"]),
        )
    if kind == "window_sum":
        return WindowSumRule(
            name=name, severity=severity, template=template, match=match,
            window_secs=float(spec["window_secs"]),
            sum_field=str(spec["sum_field"]),
            sum_threshold=float(spec["sum_threshold"]),
        )
    raise ValueError(
        f"Unknown rule type {kind!r}; expected single, window_count, window_sum"
    )


def _build_targets(spec: dict[str, Any]) -> list[AlertTarget]:
    targets: list[AlertTarget] = []
    if "slack" in spec and isinstance(spec["slack"], dict):
        url = spec["slack"].get("webhook_url")
        if not url:
            raise ValueError("[targets.slack] requires webhook_url")
        targets.append(SlackTarget(str(url)))
    if "pagerduty" in spec and isinstance(spec["pagerduty"], dict):
        rk = spec["pagerduty"].get("routing_key")
        if not rk:
            raise ValueError("[targets.pagerduty] requires routing_key")
        trigger = tuple(spec["pagerduty"].get(
            "trigger_on_severity", ["warning", "critical"],
        ))
        targets.append(PagerDutyTarget(str(rk), trigger_on_severity=trigger))
    if spec.get("stdout", False):
        targets.append(StdoutTarget())
    return targets


def load_config(path: str | Path) -> AlertsConfig:
    """Load alerts config from TOML, with env var overrides for secrets.

    Recognised env overrides:
      LLM_LEASH_ALERTS_AUDIT_LOG  — overrides audit_log path
      SLACK_WEBHOOK_URL           — overrides targets.slack.webhook_url
      PAGERDUTY_ROUTING_KEY       — overrides targets.pagerduty.routing_key
    """
    with open(path, "rb") as f:
        data = tomllib.load(f)

    audit_log = os.environ.get(
        "LLM_LEASH_ALERTS_AUDIT_LOG",
        data.get("audit_log", ""),
    )
    if not audit_log:
        raise ValueError(
            "audit_log must be set in TOML or via "
            "LLM_LEASH_ALERTS_AUDIT_LOG env var",
        )

    targets_spec = dict(data.get("targets") or {})
    # Env-var overrides for credentials (keeps tokens out of TOML in git).
    if (slack_url := os.environ.get("SLACK_WEBHOOK_URL")):
        targets_spec.setdefault("slack", {})["webhook_url"] = slack_url
    if (pd_key := os.environ.get("PAGERDUTY_ROUTING_KEY")):
        targets_spec.setdefault("pagerduty", {})["routing_key"] = pd_key
    targets = _build_targets(targets_spec)

    rules: list[Rule] = []
    for spec in data.get("rules") or []:
        rules.append(_build_rule(spec))

    if not targets:
        log.warning("no targets configured — alerts will fire but go nowhere; "
                    "adding StdoutTarget as a fallback")
        targets = [StdoutTarget()]

    return AlertsConfig(
        audit_log=audit_log,
        rules=rules,
        targets=targets,
        min_interval_secs=float(data.get("min_interval_secs", 60.0)),
        poll_interval_secs=float(data.get("poll_interval_secs", 1.0)),
    )


# ─── Runner loop ─────────────────────────────────────────────────────


async def run_loop(config: AlertsConfig) -> None:
    """Main loop: tail audit log, feed engine, dispatch alerts."""
    engine = AlertEngine(
        config.rules,
        min_interval_secs=config.min_interval_secs,
    )
    log_path = Path(config.audit_log)

    def _size_if_exists() -> int:
        return log_path.stat().st_size if log_path.exists() else 0

    def _read_tail(seek_at: int) -> bytes:
        if not log_path.exists():
            return b""
        with log_path.open("rb") as f:
            f.seek(seek_at)
            return f.read()

    # Start at EOF — don't replay history (operators replay manually).
    last_size = await asyncio.to_thread(_size_if_exists)

    log.info(
        "alerts runner started: audit_log=%s rules=%d targets=%d",
        config.audit_log, len(config.rules), len(config.targets),
    )

    while True:
        await asyncio.sleep(config.poll_interval_secs)
        current_size = await asyncio.to_thread(_size_if_exists)
        if current_size == last_size:
            continue
        if current_size < last_size:
            # File rotated / truncated.
            last_size = 0
        new_bytes = await asyncio.to_thread(_read_tail, last_size)
        last_size = current_size

        for raw in new_bytes.splitlines():
            line = raw.decode("utf-8", errors="replace").strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            alerts = engine.feed(event)
            if not alerts:
                continue
            await dispatch(alerts, config.targets)


async def dispatch(
    alerts: list[Any], targets: list[AlertTarget],
) -> None:
    """Send every alert to every target concurrently. Failures are
    logged (in targets.py) but never crash the runner."""
    tasks: list[Any] = []
    for alert in alerts:
        for target in targets:
            tasks.append(target.send(alert))
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


# ─── CLI ──────────────────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="llm-leash-alerts",
        description="Tail llm-leash audit log and fire alerts to Slack / PagerDuty.",
    )
    parser.add_argument("--config", required=True, help="Path to alerts.toml")
    parser.add_argument(
        "--log-level", default="info",
        choices=["debug", "info", "warning", "error"],
    )
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=args.log_level.upper(),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    config = load_config(args.config)
    try:
        asyncio.run(run_loop(config))
    except KeyboardInterrupt:
        log.info("alerts runner stopped (ctrl-c)")
        return 0
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
