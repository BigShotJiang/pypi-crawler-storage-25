"""HITL gate protocol and in-memory implementation."""
from __future__ import annotations

from typing import Any, Literal, Protocol, runtime_checkable

from ..types import Decision, LeashRejectedByHuman, ToolCall


@runtime_checkable
class HitlGate(Protocol):
    """Async gate for human-in-the-loop approval.

    Returns normally → approved. Raises LeashRejectedByHuman → rejected.
    """

    async def request(self, call: ToolCall, decision: Decision) -> None: ...


class InMemoryHitlGate:
    """Test-friendly gate. Auto-approves or auto-rejects all requests."""

    def __init__(
        self,
        *,
        default: Literal["approve", "reject"] = "approve",
        reject_reason: str = "rejected by InMemoryHitlGate",
    ) -> None:
        self._default = default
        self._reject_reason = reject_reason
        self.requests: list[dict[str, Any]] = []

    async def request(self, call: ToolCall, decision: Decision) -> None:
        self.requests.append({"call": call, "decision": decision})
        if self._default == "reject":
            raise LeashRejectedByHuman(
                rule_id=decision.rule_id,
                reason=self._reject_reason,
            )


__all__ = ["HitlGate", "InMemoryHitlGate"]
