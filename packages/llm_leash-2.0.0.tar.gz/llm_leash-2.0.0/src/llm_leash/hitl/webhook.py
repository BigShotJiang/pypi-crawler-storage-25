"""WebhookHitlGate — sends HTTP webhook and polls for human decision.

Uses stdlib urllib only. Zero runtime dependencies.

Protocol:
  POST {url}/requests  body: JSON
  GET  {url}/requests/{request_id}  → {"status": "pending"|"approved"|"rejected", "reason": ...}
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import Any
from urllib.request import Request, urlopen

from ..types import Decision, LeashRejectedByHuman, ToolCall


class WebhookHitlGate:
    """HITL gate that POSTs to a webhook and polls for approval."""

    def __init__(
        self,
        url: str,
        *,
        timeout_secs: float = 60.0,
        poll_interval_secs: float = 2.0,
    ) -> None:
        self._url = url.rstrip("/")
        self._timeout = timeout_secs
        self._poll_interval = poll_interval_secs

    async def request(self, call: ToolCall, decision: Decision) -> None:
        request_id = str(uuid.uuid4())
        await asyncio.to_thread(self._post, request_id, call, decision)
        await self._poll(request_id, decision)

    def _post(self, request_id: str, call: ToolCall, decision: Decision) -> None:
        body = json.dumps({
            "request_id": request_id,
            "session_id": call.session_id,
            "tool": call.tool,
            "args": call.args,
            "rule_id": decision.rule_id,
            "reason": decision.reason,
        }).encode()
        req = Request(  # noqa: S310
            f"{self._url}/requests",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urlopen(req) as _:  # noqa: S310
            pass

    async def _poll(self, request_id: str, decision: Decision) -> None:
        deadline = time.monotonic() + self._timeout
        while True:
            if time.monotonic() >= deadline:
                raise LeashRejectedByHuman(
                    rule_id="hitl:timeout",
                    reason=f"HITL approval timeout after {self._timeout}s",
                )
            status, reason = await asyncio.to_thread(self._check, request_id)
            if status == "approved":
                return
            if status == "rejected":
                raise LeashRejectedByHuman(
                    rule_id=decision.rule_id,
                    reason=reason or "rejected by human",
                )
            # Avoid busy-waiting with 0 poll_interval
            sleep_time = max(self._poll_interval, 0.001)
            await asyncio.sleep(sleep_time)

    def _check(self, request_id: str) -> tuple[str, str]:
        req = Request(f"{self._url}/requests/{request_id}", method="GET")  # noqa: S310
        with urlopen(req) as resp:  # noqa: S310
            data: dict[str, Any] = json.loads(resp.read())
        return data.get("status", "pending"), data.get("reason", "")


__all__ = ["WebhookHitlGate"]
