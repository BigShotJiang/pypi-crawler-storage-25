"""Durable HITL request queue.

The `HitlQueue` protocol lets operators approve/reject calls from a
separate process (operator UI, Slack bot, CLI). `QueueBackedHitlGate`
plugs a queue into the existing `HitlGate` interface so the firewall
treats it like any other gate.

Workflow:
    1. Firewall calls `gate.request(call, decision)`.
    2. Gate enqueues, gets a `request_id`, then polls `queue.status()`.
    3. Operator (humans, another service, CLI) calls
       `queue.approve(request_id)` or `queue.reject(request_id, reason)`.
    4. Gate returns (approved) or raises `LeashRejectedByHuman`.

If `timeout_secs` elapses with no decision, the gate rejects with reason
`hitl: timeout`. Pending entries stay in the queue for later inspection.

Two backends ship with v1.2:
    - `InMemoryHitlQueue` for tests and single-process apps.
    - `SQLiteHitlQueue` for multi-process production (survives restarts).
"""
from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Protocol, runtime_checkable

from ..types import Decision, LeashRejectedByHuman, ToolCall

Status = Literal["pending", "approved", "rejected"]


@dataclass(frozen=True)
class HitlRequest:
    """One outstanding HITL request as seen from operator side."""
    request_id: str
    created_ts: float
    session_id: str
    tenant_id: str | None
    tool: str
    args: dict[str, Any]
    rule_id: str
    reason: str
    status: Status
    decision_reason: str | None


@runtime_checkable
class HitlQueue(Protocol):
    async def enqueue(self, call: ToolCall, decision: Decision) -> str: ...
    async def status(self, request_id: str) -> tuple[Status, str | None]: ...
    async def approve(self, request_id: str) -> None: ...
    async def reject(self, request_id: str, *, reason: str) -> None: ...
    async def list_pending(self) -> list[HitlRequest]: ...


# ─── InMemoryHitlQueue ─────────────────────────────────────────────


class InMemoryHitlQueue:
    """In-process durable-ish queue. Loses state on restart."""

    def __init__(self) -> None:
        self._items: dict[str, HitlRequest] = {}
        self._lock = asyncio.Lock()

    async def enqueue(self, call: ToolCall, decision: Decision) -> str:
        rid = str(uuid.uuid4())
        req = HitlRequest(
            request_id=rid,
            created_ts=time.time(),
            session_id=call.session_id,
            tenant_id=call.tenant_id,
            tool=call.tool,
            args=dict(call.args),
            rule_id=decision.rule_id,
            reason=decision.reason,
            status="pending",
            decision_reason=None,
        )
        async with self._lock:
            self._items[rid] = req
        return rid

    async def status(self, request_id: str) -> tuple[Status, str | None]:
        async with self._lock:
            req = self._items.get(request_id)
        if req is None:
            return "rejected", "unknown request_id"
        return req.status, req.decision_reason

    async def approve(self, request_id: str) -> None:
        async with self._lock:
            req = self._items.get(request_id)
            if req is None or req.status != "pending":
                return
            self._items[request_id] = HitlRequest(
                **{**req.__dict__, "status": "approved", "decision_reason": None}
            )

    async def reject(self, request_id: str, *, reason: str) -> None:
        async with self._lock:
            req = self._items.get(request_id)
            if req is None or req.status != "pending":
                return
            self._items[request_id] = HitlRequest(
                **{**req.__dict__, "status": "rejected", "decision_reason": reason}
            )

    async def list_pending(self) -> list[HitlRequest]:
        async with self._lock:
            return [r for r in self._items.values() if r.status == "pending"]


# ─── SQLiteHitlQueue ───────────────────────────────────────────────


_SCHEMA = """
CREATE TABLE IF NOT EXISTS hitl_requests (
    request_id      TEXT PRIMARY KEY,
    created_ts      REAL NOT NULL,
    session_id      TEXT NOT NULL,
    tenant_id       TEXT,
    tool            TEXT NOT NULL,
    args_json       TEXT NOT NULL,
    rule_id         TEXT NOT NULL,
    reason          TEXT NOT NULL,
    status          TEXT NOT NULL CHECK (status IN ('pending','approved','rejected')),
    decision_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_hitl_status ON hitl_requests(status);
"""


def _row_to_request(row: tuple[Any, ...]) -> HitlRequest:
    return HitlRequest(
        request_id=row[0],
        created_ts=float(row[1]),
        session_id=row[2],
        tenant_id=row[3],
        tool=row[4],
        args=json.loads(row[5]),
        rule_id=row[6],
        reason=row[7],
        status=row[8],
        decision_reason=row[9],
    )


class SQLiteHitlQueue:
    """File-backed durable HITL queue. Multi-process safe via sqlite locking."""

    def __init__(self, path: str) -> None:
        self._path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL")
        for stmt in _SCHEMA.strip().split(";"):
            s = stmt.strip()
            if s:
                self._conn.execute(s)

    # sync helpers run inside asyncio.to_thread
    def _sync_enqueue(self, req: HitlRequest) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO hitl_requests "
                "(request_id, created_ts, session_id, tenant_id, tool, args_json, "
                "rule_id, reason, status, decision_reason) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                (
                    req.request_id, req.created_ts, req.session_id, req.tenant_id,
                    req.tool, json.dumps(req.args, sort_keys=True, default=str),
                    req.rule_id, req.reason, req.status, req.decision_reason,
                ),
            )

    def _sync_status(self, request_id: str) -> tuple[Status, str | None]:
        with self._lock:
            row = self._conn.execute(
                "SELECT status, decision_reason FROM hitl_requests WHERE request_id = ?",
                (request_id,),
            ).fetchone()
        if row is None:
            return "rejected", "unknown request_id"
        return row[0], row[1]

    def _sync_resolve(self, request_id: str, status: Status, reason: str | None) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE hitl_requests SET status = ?, decision_reason = ? "
                "WHERE request_id = ? AND status = 'pending'",
                (status, reason, request_id),
            )

    def _sync_list_pending(self) -> list[HitlRequest]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT request_id, created_ts, session_id, tenant_id, tool, "
                "args_json, rule_id, reason, status, decision_reason "
                "FROM hitl_requests WHERE status = 'pending' ORDER BY created_ts ASC"
            ).fetchall()
        return [_row_to_request(r) for r in rows]

    # async surface

    async def enqueue(self, call: ToolCall, decision: Decision) -> str:
        rid = str(uuid.uuid4())
        req = HitlRequest(
            request_id=rid,
            created_ts=time.time(),
            session_id=call.session_id,
            tenant_id=call.tenant_id,
            tool=call.tool,
            args=dict(call.args),
            rule_id=decision.rule_id,
            reason=decision.reason,
            status="pending",
            decision_reason=None,
        )
        await asyncio.to_thread(self._sync_enqueue, req)
        return rid

    async def status(self, request_id: str) -> tuple[Status, str | None]:
        return await asyncio.to_thread(self._sync_status, request_id)

    async def approve(self, request_id: str) -> None:
        await asyncio.to_thread(self._sync_resolve, request_id, "approved", None)

    async def reject(self, request_id: str, *, reason: str) -> None:
        await asyncio.to_thread(self._sync_resolve, request_id, "rejected", reason)

    async def list_pending(self) -> list[HitlRequest]:
        return await asyncio.to_thread(self._sync_list_pending)

    def close(self) -> None:
        with self._lock:
            self._conn.close()


# ─── QueueBackedHitlGate ───────────────────────────────────────────


class QueueBackedHitlGate:
    """A `HitlGate` that delegates approval to a `HitlQueue`.

    The firewall's calling thread blocks (with timeout) while polling the
    queue for a decision. State survives process restarts when paired
    with `SQLiteHitlQueue`.
    """

    def __init__(
        self,
        queue: HitlQueue,
        *,
        timeout_secs: float = 60.0,
        poll_interval_secs: float = 1.0,
    ) -> None:
        self._queue = queue
        self._timeout = timeout_secs
        self._poll = max(poll_interval_secs, 0.001)

    async def request(self, call: ToolCall, decision: Decision) -> None:
        request_id = await self._queue.enqueue(call, decision)
        deadline = time.monotonic() + self._timeout
        while True:
            if time.monotonic() >= deadline:
                await self._queue.reject(
                    request_id, reason=f"hitl: timeout after {self._timeout}s"
                )
                raise LeashRejectedByHuman(
                    rule_id="hitl:timeout",
                    reason=f"HITL approval timeout after {self._timeout}s",
                )
            status, reason = await self._queue.status(request_id)
            if status == "approved":
                return
            if status == "rejected":
                raise LeashRejectedByHuman(
                    rule_id=decision.rule_id,
                    reason=reason or "rejected by human",
                )
            await asyncio.sleep(self._poll)


__all__ = [
    "HitlQueue",
    "HitlRequest",
    "InMemoryHitlQueue",
    "QueueBackedHitlGate",
    "SQLiteHitlQueue",
    "Status",
]
