"""Operator helpers for resolving pending HITL requests.

Tiny convenience layer over `HitlQueue` so an operator UI, Slack bot, or
the CLI can list and act on outstanding requests without re-implementing
the same code each time.

Typical use:
    queue = SQLiteHitlQueue("/var/lib/hitl.db")
    for req in await pending(queue):
        print(req.request_id, req.tool, req.reason)
    await approve(queue, request_id)
    await reject(queue, request_id, "rate-limited")
"""
from __future__ import annotations

from .queue import HitlQueue, HitlRequest


async def pending(queue: HitlQueue) -> list[HitlRequest]:
    """Return every request still waiting for a human decision."""
    return await queue.list_pending()


async def approve(queue: HitlQueue, request_id: str) -> None:
    """Approve a pending request. No-op if already resolved or unknown."""
    await queue.approve(request_id)


async def reject(queue: HitlQueue, request_id: str, reason: str) -> None:
    """Reject a pending request with an operator-supplied reason."""
    await queue.reject(request_id, reason=reason)


__all__ = ["approve", "pending", "reject"]
