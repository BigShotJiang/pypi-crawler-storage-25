"""Append-only JSONL audit log with sha256 hash chain.

Single writer per file. Each line is one event. Each event includes
`prev_hash` (previous line's hash, or `"0" * 64` for the genesis) and
`hash` (sha256 of canonical JSON of this event with the `hash` field
excluded).

`verify_chain` (in audit.verify) replays the file and confirms the
chain is unbroken — that's how tamper-evidence works.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import os
from pathlib import Path
from typing import IO

from .schema import Event, canonical_json

GENESIS = "0" * 64


class AuditWriter:
    """Synchronous, file-backed writer with hash chain."""

    def __init__(self, path: str, *, fsync: bool = True) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._fsync = fsync
        self._last_hash, self._next_seq = self._resume()
        self._fh: IO[bytes] = self._path.open("ab", buffering=0)

    def _resume(self) -> tuple[str, int]:
        """Read existing file (if any), return (last_hash, next_seq)."""
        if not self._path.exists() or self._path.stat().st_size == 0:
            return GENESIS, 0
        last_hash = GENESIS
        seq = 0
        with self._path.open("rb") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parsed = json.loads(line)
                last_hash = parsed["hash"]
                seq = parsed["seq"] + 1
        return last_hash, seq

    def write(self, event: Event) -> Event:
        # Re-stamp seq and prev_hash from our authoritative state.
        event = dataclasses.replace(event, seq=self._next_seq, prev_hash=self._last_hash)
        canon = canonical_json(event, exclude_hash=True)
        h = hashlib.sha256(canon).hexdigest()

        # Build the on-disk dict (event fields + hash).
        on_disk = json.loads(canon.decode("utf-8"))
        on_disk["hash"] = h
        line = json.dumps(on_disk, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False).encode("utf-8") + b"\n"
        self._fh.write(line)
        if self._fsync:
            self._fh.flush()
            os.fsync(self._fh.fileno())

        self._last_hash = h
        self._next_seq += 1

        # Return the event annotated with its computed hash (as a new
        # attribute) so callers can chain. We use a small wrapper dict
        # via dataclasses.replace; the schema doesn't carry `hash`,
        # so we attach it as a separate attribute.
        object.__setattr__(event, "hash", h)
        return event

    def close(self) -> None:
        self._fh.close()

    def __enter__(self) -> AuditWriter:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


__all__ = ["GENESIS", "AuditWriter"]
