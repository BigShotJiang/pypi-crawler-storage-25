"""SOC 2 evidence pack generator.

Reads `audit.jsonl` and emits a directory of artefacts an auditor can
attach to their evidence binder directly:

    executive-summary.html      — period overview, integrity verdict
    cc6_access_control.csv      — per-session activity
    cc7_monitoring.csv          — security events (kills, breaches)
    cc7_integrity.json          — hash-chain verification result
    anomalies.csv               — outliers (kill spikes, p95 spenders)
    bom.json                    — bill of materials with sha256s

Trust Service Criteria mapping is documented in docs/SOC2.md.

Zero new runtime dependencies — pure stdlib.
"""
from __future__ import annotations

import csv
import hashlib
import html
import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .replay import replay
from .verify import ChainBroken, verify_chain


@dataclass
class SOC2Report:
    """Result handle for `generate_report`."""
    output_dir: Path
    files: list[Path] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)
    integrity_ok: bool = False


# ─── Helpers ──────────────────────────────────────────────────────────


def _parse_ts(ts: str) -> datetime:
    # Accept either trailing 'Z' or explicit offset
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def _iter_period_events(
    log_path: str,
    period_start: str,
    period_end: str,
) -> list[dict[str, Any]]:
    start = _parse_ts(period_start)
    end = _parse_ts(period_end)
    out: list[dict[str, Any]] = []
    for ev in replay(log_path):
        ts = ev.get("ts")
        if not isinstance(ts, str):
            continue
        try:
            t = _parse_ts(ts)
        except ValueError:
            continue
        if start <= t <= end:
            out.append(ev)
    return out


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ─── Artefact writers ─────────────────────────────────────────────────


def _write_integrity(
    log_path: str,
    period_start: str,
    period_end: str,
    out_path: Path,
) -> tuple[bool, dict[str, Any]]:
    integrity: dict[str, Any] = {
        "period_start": period_start,
        "period_end": period_end,
        "source_log": log_path,
        "verified": False,
        "event_count": 0,
        "error": None,
    }
    try:
        n = verify_chain(log_path)
        integrity["verified"] = True
        integrity["event_count"] = n
    except ChainBroken as exc:
        integrity["verified"] = False
        integrity["error"] = str(exc)
    except FileNotFoundError as exc:
        integrity["verified"] = False
        integrity["error"] = f"file not found: {exc}"
    out_path.write_text(json.dumps(integrity, indent=2) + "\n", encoding="utf-8")
    return integrity["verified"], integrity


def _write_cc6_access_control(events: list[dict[str, Any]], out_path: Path) -> int:
    """One row per (session_id, tenant_id). Aggregates activity."""
    agg: dict[tuple[str, str | None], dict[str, Any]] = {}
    for ev in events:
        key = (ev.get("session_id", ""), ev.get("tenant_id"))
        bucket = agg.setdefault(key, {
            "session_id": key[0],
            "tenant_id": key[1] or "",
            "events": 0,
            "model_calls": 0,
            "tool_calls": 0,
            "kills": 0,
            "cost_usd_total": 0.0,
            "models": set(),
            "tools": set(),
            "first_seen": ev.get("ts", ""),
            "last_seen": ev.get("ts", ""),
        })
        bucket["events"] += 1
        kind = ev.get("kind")
        if kind == "model_call":
            bucket["model_calls"] += 1
            bucket["cost_usd_total"] += float(ev.get("cost_usd", 0.0) or 0.0)
            model = ev.get("model")
            if model:
                bucket["models"].add(model)
        elif kind == "tool_call":
            bucket["tool_calls"] += 1
            tool = ev.get("tool")
            if tool:
                bucket["tools"].add(tool)
        elif kind == "kill":
            bucket["kills"] += 1
        ts = ev.get("ts", "")
        if ts and ts < bucket["first_seen"]:
            bucket["first_seen"] = ts
        if ts and ts > bucket["last_seen"]:
            bucket["last_seen"] = ts

    cols = [
        "session_id", "tenant_id",
        "events", "model_calls", "tool_calls", "kills",
        "cost_usd_total",
        "unique_models", "unique_tools",
        "first_seen", "last_seen",
    ]
    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        for bucket in agg.values():
            row = {**bucket}
            row["unique_models"] = ";".join(sorted(bucket["models"]))
            row["unique_tools"] = ";".join(sorted(bucket["tools"]))
            row.pop("models", None)
            row.pop("tools", None)
            row["cost_usd_total"] = f"{bucket['cost_usd_total']:.6f}"
            writer.writerow({c: row.get(c, "") for c in cols})
    return len(agg)


def _write_cc7_monitoring(events: list[dict[str, Any]], out_path: Path) -> int:
    """One row per security-relevant event (kill, budget breach, hitl escalation)."""
    cols = [
        "ts", "session_id", "tenant_id",
        "event_type", "rule_id", "reason",
    ]
    rows: list[dict[str, Any]] = []
    for ev in events:
        kind = ev.get("kind")
        if kind == "kill":
            rows.append({
                "ts": ev.get("ts", ""),
                "session_id": ev.get("session_id", ""),
                "tenant_id": ev.get("tenant_id") or "",
                "event_type": "kill",
                "rule_id": "kill:registry",
                "reason": ev.get("reason", ""),
            })
        elif kind == "budget":
            decision = ev.get("decision", "")
            if decision in {"hard_exceeded", "soft_exceeded"}:
                rows.append({
                    "ts": ev.get("ts", ""),
                    "session_id": ev.get("session_id", ""),
                    "tenant_id": ev.get("tenant_id") or "",
                    "event_type": f"budget:{decision}",
                    "rule_id": "budget:tracker",
                    "reason": (
                        f"cumulative ${ev.get('cumulative_usd', 0):.4f} "
                        f"vs cap ${ev.get('cap_usd', 0)}"
                    ),
                })
    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def _compute_anomalies(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Detect outlier sessions: kill spikes, p95 spend, tool spam."""
    kills_by_session: dict[str, int] = {}
    spend_by_session: dict[str, float] = {}
    tool_calls_by_session_tool: dict[tuple[str, str], int] = {}

    for ev in events:
        sid = ev.get("session_id", "")
        kind = ev.get("kind")
        if kind == "kill":
            kills_by_session[sid] = kills_by_session.get(sid, 0) + 1
        elif kind == "model_call":
            spend_by_session[sid] = (
                spend_by_session.get(sid, 0.0) + float(ev.get("cost_usd", 0) or 0)
            )
        elif kind == "tool_call":
            tool = ev.get("tool", "")
            key = (sid, tool)
            tool_calls_by_session_tool[key] = tool_calls_by_session_tool.get(key, 0) + 1

    anomalies: list[dict[str, Any]] = []

    # Kill spikes (>= 3 kills in one session).
    for sid, count in kills_by_session.items():
        if count >= 3:
            anomalies.append({
                "kind": "kill_spike",
                "session_id": sid,
                "metric": "kill_events",
                "value": count,
                "threshold": 3,
                "detail": f"{count} kill events in one session",
            })

    # Spend outliers (above p95).
    spend_values = list(spend_by_session.values())
    if len(spend_values) >= 20:
        sorted_v = sorted(spend_values)
        p95_idx = max(int(len(sorted_v) * 0.95) - 1, 0)
        p95 = sorted_v[p95_idx]
        for sid, total in spend_by_session.items():
            if total > p95 and total > 0:
                anomalies.append({
                    "kind": "spend_p95",
                    "session_id": sid,
                    "metric": "cost_usd_total",
                    "value": round(total, 6),
                    "threshold": round(p95, 6),
                    "detail": f"spend ${total:.4f} above p95 ${p95:.4f}",
                })

    # Tool spam (> 100 calls of the same tool in one session).
    for (sid, tool), count in tool_calls_by_session_tool.items():
        if count > 100:
            anomalies.append({
                "kind": "tool_spam",
                "session_id": sid,
                "metric": f"tool_calls:{tool}",
                "value": count,
                "threshold": 100,
                "detail": f"{count} calls to tool '{tool}' in one session",
            })

    return anomalies


def _write_anomalies(events: list[dict[str, Any]], out_path: Path) -> int:
    rows = _compute_anomalies(events)
    cols = ["kind", "session_id", "metric", "value", "threshold", "detail"]
    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def _render_html(
    *,
    organization_name: str | None,
    period_start: str,
    period_end: str,
    integrity: dict[str, Any],
    event_count: int,
    counts_by_kind: dict[str, int],
    counts_by_provider: dict[str, int],
    total_spend_usd: float,
    top_spenders: list[tuple[str, float]],
    anomaly_count: int,
    llm_leash_version: str,
) -> str:
    org = html.escape(organization_name or "—")
    integrity_class = "verdict-ok" if integrity["verified"] else "verdict-bad"
    integrity_label = "✓ VERIFIED" if integrity["verified"] else "✗ BROKEN"
    integrity_detail = html.escape(integrity.get("error") or "Chain intact.")

    counts_kind_rows = "".join(
        f"<tr><td>{html.escape(k)}</td><td class='r'>{v}</td></tr>"
        for k, v in sorted(counts_by_kind.items())
    )
    counts_provider_rows = "".join(
        f"<tr><td>{html.escape(p)}</td><td class='r'>{v}</td></tr>"
        for p, v in sorted(counts_by_provider.items())
    )
    top_spend_rows = "".join(
        f"<tr><td><code>{html.escape(sid)}</code></td><td class='r'>${v:.4f}</td></tr>"
        for sid, v in top_spenders
    )

    generated_at = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SOC 2 Evidence — {org}</title>
<style>
body {{ font-family: -apple-system, system-ui, sans-serif; max-width: 920px;
       margin: 2rem auto; padding: 0 1rem; color: #1c1c1c; }}
h1 {{ margin-bottom: 0; }}
.sub {{ color: #666; margin-top: 0.25rem; }}
.verdict {{ font-size: 1.4rem; padding: 1rem 1.5rem; border-radius: 8px;
            margin: 1.5rem 0; font-weight: 600; }}
.verdict-ok {{ background: #e7f8ef; color: #166534; border: 1px solid #16a34a; }}
.verdict-bad {{ background: #fef2f2; color: #991b1b; border: 1px solid #dc2626; }}
.detail {{ font-weight: 400; font-size: 0.95rem; margin-top: 0.5rem; }}
section {{ margin: 1.5rem 0; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ text-align: left; padding: 0.4rem 0.6rem; border-bottom: 1px solid #eee; }}
td.r {{ text-align: right; font-variant-numeric: tabular-nums; }}
code {{ font-size: 0.9rem; background: #f5f5f5; padding: 0.1rem 0.3rem;
        border-radius: 3px; }}
.kpi {{ display: inline-block; padding: 1rem 1.5rem; margin-right: 1rem;
        background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; }}
.kpi b {{ display: block; font-size: 1.6rem; }}
.kpi span {{ color: #64748b; font-size: 0.9rem; }}
footer {{ color: #888; font-size: 0.85rem; margin-top: 3rem;
          border-top: 1px solid #eee; padding-top: 1rem; }}
</style>
</head>
<body>
<h1>SOC 2 Evidence Pack</h1>
<p class="sub">Organization: <b>{org}</b><br>
Period: <code>{html.escape(period_start)}</code> &rarr; <code>{html.escape(period_end)}</code></p>

<div class="verdict {integrity_class}">
  {integrity_label}
  <div class="detail">{integrity_detail}</div>
</div>

<section>
  <div class="kpi"><b>{event_count}</b><span>events in period</span></div>
  <div class="kpi"><b>${total_spend_usd:.2f}</b><span>total LLM spend</span></div>
  <div class="kpi"><b>{anomaly_count}</b><span>anomalies flagged</span></div>
</section>

<section>
  <h2>Event counts by kind</h2>
  <table><thead><tr><th>kind</th><th class="r">count</th></tr></thead>
  <tbody>{counts_kind_rows or '<tr><td colspan="2"><i>no events</i></td></tr>'}</tbody>
  </table>
</section>

<section>
  <h2>Model calls by provider</h2>
  <table><thead><tr><th>provider</th><th class="r">count</th></tr></thead>
  <tbody>{counts_provider_rows or '<tr><td colspan="2"><i>no model calls</i></td></tr>'}</tbody>
  </table>
</section>

<section>
  <h2>Top spenders (sessions)</h2>
  <table><thead><tr><th>session_id</th><th class="r">cost (USD)</th></tr></thead>
  <tbody>{top_spend_rows or '<tr><td colspan="2"><i>no spend</i></td></tr>'}</tbody>
  </table>
</section>

<section>
  <h2>Artefacts in this pack</h2>
  <ul>
    <li><code>cc6_access_control.csv</code> — per-session activity (CC6.1, CC6.6)</li>
    <li><code>cc7_monitoring.csv</code> — security events (CC7.1, CC7.3)</li>
    <li><code>cc7_integrity.json</code> — hash-chain verification (CC7.2)</li>
    <li><code>anomalies.csv</code> — outlier detection (CC7.2)</li>
    <li><code>bom.json</code> — file manifest with sha256 hashes</li>
  </ul>
</section>

<footer>
  Generated {generated_at} by <code>llm-leash {html.escape(llm_leash_version)}</code>.<br>
  This pack is reproducible: every artefact lists its sha256 in <code>bom.json</code>.
</footer>
</body>
</html>
"""


def _write_bom(
    audit_log_path: str,
    output_dir: Path,
    files: list[Path],
    integrity: dict[str, Any],
    period_start: str,
    period_end: str,
) -> Path:
    bom_path = output_dir / "bom.json"
    log_path = Path(audit_log_path)
    bom = {
        "generated_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "period_start": period_start,
        "period_end": period_end,
        "source_audit_log": {
            "path": str(audit_log_path),
            "sha256": _sha256_file(log_path) if log_path.exists() else None,
            "size_bytes": log_path.stat().st_size if log_path.exists() else 0,
        },
        "integrity": {
            "verified": integrity["verified"],
            "event_count": integrity["event_count"],
            "error": integrity["error"],
        },
        "files": [
            {
                "path": p.name,
                "sha256": _sha256_file(p),
                "size_bytes": p.stat().st_size,
            }
            for p in sorted(files, key=lambda f: f.name) if p.exists()
        ],
    }
    bom_path.write_text(json.dumps(bom, indent=2) + "\n", encoding="utf-8")
    return bom_path


# ─── Top-level entry point ────────────────────────────────────────────


def generate_report(
    audit_log_path: str,
    output_dir: str,
    *,
    period_start: str,
    period_end: str,
    organization_name: str | None = None,
) -> SOC2Report:
    """Generate a full SOC 2 evidence pack from an audit log.

    Returns a `SOC2Report` describing every artefact written.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # 1. Integrity (covers the whole log, not just the period — auditors want this).
    integrity_path = out / "cc7_integrity.json"
    ok, integrity = _write_integrity(
        audit_log_path, period_start, period_end, integrity_path,
    )

    # 2. Period-scoped events for the rest of the artefacts.
    events = _iter_period_events(audit_log_path, period_start, period_end)

    # 3. CC6 access control.
    cc6_path = out / "cc6_access_control.csv"
    sessions = _write_cc6_access_control(events, cc6_path)

    # 4. CC7 monitoring.
    cc7_mon_path = out / "cc7_monitoring.csv"
    security_events = _write_cc7_monitoring(events, cc7_mon_path)

    # 5. Anomalies.
    anomalies_path = out / "anomalies.csv"
    anomaly_count = _write_anomalies(events, anomalies_path)

    # 6. Executive summary HTML.
    counts_by_kind: dict[str, int] = {}
    counts_by_provider: dict[str, int] = {}
    total_spend_usd = 0.0
    spend_by_session: dict[str, float] = {}
    for ev in events:
        k = ev.get("kind", "")
        counts_by_kind[k] = counts_by_kind.get(k, 0) + 1
        if k == "model_call":
            p = ev.get("provider", "")
            counts_by_provider[p] = counts_by_provider.get(p, 0) + 1
            cost = float(ev.get("cost_usd", 0) or 0)
            total_spend_usd += cost
            sid = ev.get("session_id", "")
            spend_by_session[sid] = spend_by_session.get(sid, 0.0) + cost

    top_spenders = sorted(
        spend_by_session.items(), key=lambda kv: kv[1], reverse=True,
    )[:3]

    from .. import __version__ as _ll_version

    html_str = _render_html(
        organization_name=organization_name,
        period_start=period_start,
        period_end=period_end,
        integrity=integrity,
        event_count=len(events),
        counts_by_kind=counts_by_kind,
        counts_by_provider=counts_by_provider,
        total_spend_usd=total_spend_usd,
        top_spenders=top_spenders,
        anomaly_count=anomaly_count,
        llm_leash_version=_ll_version,
    )
    html_path = out / "executive-summary.html"
    html_path.write_text(html_str, encoding="utf-8")

    # 7. BOM (last — covers all prior artefacts).
    files_so_far = [integrity_path, cc6_path, cc7_mon_path, anomalies_path, html_path]
    bom_path = _write_bom(
        audit_log_path, out, files_so_far, integrity,
        period_start, period_end,
    )

    summary = {
        "total_events": len(events),
        "sessions": sessions,
        "security_events": security_events,
        "anomalies": anomaly_count,
        "total_spend_usd": total_spend_usd,
        "counts_by_kind": counts_by_kind,
        "counts_by_provider": counts_by_provider,
    }
    return SOC2Report(
        output_dir=out,
        files=[*files_so_far, bom_path],
        summary=summary,
        integrity_ok=ok,
    )


__all__ = ["SOC2Report", "generate_report"]
