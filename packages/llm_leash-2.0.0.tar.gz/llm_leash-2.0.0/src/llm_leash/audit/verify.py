"""Replay an audit JSONL and verify the hash chain."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .writer import GENESIS


class ChainBroken(Exception):
    """Raised when the hash chain doesn't verify."""


def verify_chain(path: str) -> int:
    """Verify the chain in `path`. Returns the number of events.

    Raises ChainBroken with a message naming the first bad line.
    """
    p = Path(path)
    if not p.exists() or p.stat().st_size == 0:
        return 0

    prev = GENESIS
    count = 0
    with p.open("rb") as f:
        for line_no, raw in enumerate(f, start=1):
            raw = raw.strip()
            if not raw:
                continue
            parsed = json.loads(raw)
            claimed_hash = parsed.get("hash")
            claimed_prev = parsed.get("prev_hash")
            seq = parsed.get("seq")

            if claimed_prev != prev:
                raise ChainBroken(
                    f"line {line_no} (seq {seq}): prev_hash {claimed_prev[:12]}... "
                    f"does not match previous line's hash {prev[:12]}..."
                )

            without_hash = {k: v for k, v in parsed.items() if k != "hash"}
            canon = json.dumps(
                without_hash, sort_keys=True, separators=(",", ":"),
                ensure_ascii=False,
            ).encode("utf-8")
            recomputed = hashlib.sha256(canon).hexdigest()
            if recomputed != claimed_hash:
                raise ChainBroken(
                    f"line {line_no} (seq {seq}): hash mismatch "
                    f"(stored {claimed_hash[:12]}..., recomputed {recomputed[:12]}...)"
                )
            prev = claimed_hash
            count += 1
    return count


__all__ = ["ChainBroken", "verify_chain"]
