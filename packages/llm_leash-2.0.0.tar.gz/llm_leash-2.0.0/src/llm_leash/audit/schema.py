"""Audit event schema. One dataclass per `kind`.

Canonical JSON: keys sorted, no whitespace, UTF-8, no escape of forward
slashes. Deterministic — bytes-identical for equal events.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from typing import Literal


@dataclass(frozen=True)
class _Base:
    ts: str
    session_id: str
    tenant_id: str | None
    seq: int
    prev_hash: str


@dataclass(frozen=True)
class ModelCall(_Base):
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    request_hash: str
    response_hash: str
    agent_name: str | None = None
    kind: Literal["model_call"] = "model_call"


@dataclass(frozen=True)
class BudgetEvent(_Base):
    cumulative_usd: float
    cap_usd: float | None
    decision: Literal["under", "soft_exceeded", "hard_exceeded"]
    kind: Literal["budget"] = "budget"


@dataclass(frozen=True)
class KillEvent(_Base):
    reason: str
    kind: Literal["kill"] = "kill"


@dataclass(frozen=True)
class SecretsDetected(_Base):
    """Audit event for secrets/credentials detected in outgoing args.

    Emitted by `SecretsRule` (and any custom rule that wants to surface
    secret detections in the audit trail) so SOC 2 reports can show
    "we found N AWS keys this month, M of which were redacted before
    the LLM saw them".
    """
    detectors: list[str]  # e.g. ["aws_access_key", "github_pat"]
    redacted_count: int   # 0 if action was block/hitl
    action: str           # "block" | "redact" | "hitl"
    agent_name: str | None = None
    kind: Literal["secrets_detected"] = "secrets_detected"


@dataclass(frozen=True)
class ToolCallEvent(_Base):
    """Non-LLM tool invocation (e.g. MCP `call_tool`).

    Audited but does not charge the budget — tool calls usually don't
    consume tokens. `request_hash` covers (tool, arguments); `response_hash`
    covers the result.
    """
    tool: str
    request_hash: str
    response_hash: str
    agent_name: str | None = None
    kind: Literal["tool_call"] = "tool_call"


Event = ModelCall | BudgetEvent | KillEvent | ToolCallEvent | SecretsDetected


def canonical_json(event: Event, *, exclude_hash: bool = True) -> bytes:
    """Serialize an event deterministically.

    If `exclude_hash` is True (default), omits the `hash` field — used
    when computing the hash itself. If False, includes whatever `hash`
    is present (used when storing the final line).
    """
    d = asdict(event)
    if exclude_hash:
        d.pop("hash", None)
    return json.dumps(
        d,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


__all__ = [
    "BudgetEvent",
    "Event",
    "KillEvent",
    "ModelCall",
    "SecretsDetected",
    "ToolCallEvent",
    "canonical_json",
]
