"""Replay an audit JSONL: iterate raw event dicts, export to CSV / JSON.

`replay(path)` yields one dict per event in chain order. Does NOT verify
the hash chain — call `verify_chain` first if integrity matters.

`export_csv(path, out)` writes a flat CSV with a stable column order, one
row per event. Columns common to all event kinds come first; kind-specific
columns are appended. Missing fields render as empty strings.

`export_json(path, out)` writes a JSON array of events to `out`. Hash and
prev_hash are preserved.
"""
from __future__ import annotations

import csv
import json
from collections.abc import Iterator
from pathlib import Path
from typing import IO, Any

# Canonical column order for CSV export.
_BASE_COLS = ["ts", "session_id", "tenant_id", "seq", "kind"]
_KIND_COLS: dict[str, list[str]] = {
    "model_call": [
        "provider", "model",
        "input_tokens", "output_tokens", "cost_usd",
    ],
    "budget": ["cumulative_usd", "cap_usd", "decision"],
    "kill": ["reason"],
    "tool_call": ["tool"],
}


def replay(path: str) -> Iterator[dict[str, Any]]:
    """Yield each audit event as a dict, in order."""
    p = Path(path)
    if not p.exists() or p.stat().st_size == 0:
        return
    with p.open("r", encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if not stripped:
                continue
            yield json.loads(stripped)


def export_json(path: str, out: IO[str]) -> int:
    """Write all events as a JSON array. Returns event count."""
    events = list(replay(path))
    json.dump(events, out, ensure_ascii=False, indent=2)
    out.write("\n")
    return len(events)


def export_csv(path: str, out: IO[str]) -> int:
    """Write all events as CSV. Returns event count.

    Columns: ts, session_id, tenant_id, seq, kind, then union of
    kind-specific fields in a stable order.
    """
    events = list(replay(path))
    seen_kinds: list[str] = []
    for ev in events:
        k = ev.get("kind", "")
        if k not in seen_kinds:
            seen_kinds.append(k)
    extra_cols: list[str] = []
    for k in seen_kinds:
        for col in _KIND_COLS.get(k, []):
            if col not in extra_cols:
                extra_cols.append(col)
    columns = _BASE_COLS + extra_cols
    writer = csv.DictWriter(out, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    for ev in events:
        writer.writerow({col: ev.get(col, "") for col in columns})
    return len(events)


__all__ = ["export_csv", "export_json", "replay"]
