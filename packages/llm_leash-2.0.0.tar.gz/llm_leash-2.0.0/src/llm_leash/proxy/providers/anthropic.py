"""Anthropic provider handler for proxy mode (PR-3, non-streaming only).

Forwards ``POST /v1/messages`` to ``https://api.anthropic.com/v1/messages``
with full enforcement:

  1. Kill check
  2. Policy engine (rules wired in PR-5; engine is present but empty for now)
  3. PII redaction (wired in PR-5)
  4. Pre-call budget estimate (refuse with 402 if would exceed cap)
  5. Upstream call via shared ``httpx.AsyncClient``
  6. Charge actual token usage from response
  7. Audit-log the call

Streaming responses (``stream: true``) are out of scope for PR-3 — they
land in PR-6. For now, if the inbound body has ``stream: true``, the
proxy treats it as non-streaming for accounting (forwards and ignores
chunks beyond the final ``message_stop`` event).
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
from typing import Any

import httpx
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, StreamingResponse

from ...audit.schema import KillEvent, ModelCall
from ...types import (
    LeashBlocked,
    LeashKilled,
    LeashRejectedByHuman,
    PolicyContext,
    ToolCall,
)
from ..errors import (
    bad_request_response,
    hitl_timeout_response,
    leash_blocked_response,
    leash_killed_response,
    leash_rejected_response,
    upstream_error_response,
)
from ..identity import extract_identity
from ..state import ProxyState
from ..streaming import AnthropicTokenAccumulator, SSEParser

ANTHROPIC_UPSTREAM = "https://api.anthropic.com"
"""Default upstream. Overridable per-request via the ``X-LLM-Leash-Upstream``
header (useful for testing and for Bedrock / Vertex flavours of Claude that
expose the same wire protocol)."""


def _now_iso() -> str:
    return _dt.datetime.now(_dt.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _hash_payload(payload: Any) -> str:
    try:
        s = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    except TypeError:
        s = str(payload)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _forward_headers(inbound: Request) -> dict[str, str]:
    """Pick which inbound headers to forward to Anthropic.

    Drops hop-by-hop and proxy-meta headers; preserves everything that
    legitimately addresses the upstream (``Authorization``,
    ``anthropic-version``, ``anthropic-beta``, etc).
    """
    DROP = {
        "host", "content-length", "connection", "keep-alive",
        "proxy-authenticate", "proxy-authorization", "te", "trailers",
        "transfer-encoding", "upgrade",
        # proxy-internal — never forward
        "x-llm-leash-session-id", "x-llm-leash-tenant-id",
        "x-llm-leash-upstream",
    }
    return {k: v for k, v in inbound.headers.items() if k.lower() not in DROP}


def _extract_tokens(response_body: dict[str, Any]) -> tuple[int, int]:
    usage = response_body.get("usage") or {}
    return int(usage.get("input_tokens", 0)), int(usage.get("output_tokens", 0))


async def handle_messages(request: Request) -> Response:
    """``POST /v1/messages`` handler.

    Lives as a free function so Starlette can route to it directly; the
    ``ProxyState`` is pulled off ``request.app.state``.
    """
    state: ProxyState = request.app.state.llm_leash
    assert state.http_client is not None, "http_client must be set by lifespan handler"

    # 1. Parse body.
    try:
        body_bytes = await request.body()
        body: dict[str, Any] = json.loads(body_bytes)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return bad_request_response(f"body is not valid JSON: {exc}")

    model = body.get("model")
    messages = body.get("messages")
    if not isinstance(model, str) or not isinstance(messages, list):
        return bad_request_response(
            "request must include 'model' (string) and 'messages' (array)"
        )
    max_tokens = int(body.get("max_tokens") or 0)

    # 2. Identity.
    identity = extract_identity(request.headers)
    session_id = identity.session_id
    tenant_id = identity.tenant_id
    agent_name = identity.agent_name
    tracker = state.tracker_for(session_id, tenant_id, agent_name)

    # 3. Kill check.
    try:
        if await state.kill.is_killed(session_id):
            reason = await state.kill.reason_for(session_id) or "session killed"
            state.audit.write(KillEvent(
                ts=_now_iso(), session_id=session_id, tenant_id=tenant_id,
                seq=0, prev_hash="x", reason=reason,
            ))
            raise LeashKilled(rule_id="kill:registry", reason=reason)
    except LeashKilled as exc:
        return leash_killed_response(exc)

    # 4. Policy engine.
    if state.engine.rules:
        cumulative = await tracker.cumulative_usd()
        ctx = PolicyContext(
            cumulative_usd=cumulative,
            budget_cap_usd=tracker._hard,
            soft_cap_usd=tracker._soft,
            tenant_id=tenant_id,
        )
        call = ToolCall(
            tool="anthropic.messages.create",
            args={"model": model, "messages": messages},
            session_id=session_id,
            tenant_id=tenant_id,
        )
        try:
            decision = state.engine.evaluate(call, ctx)
        except LeashBlocked as exc:
            return leash_blocked_response(exc)
        if decision.action == "hitl":
            if state.hitl_gate is None:
                # No gate configured → default-deny (operator must opt-in
                # to HITL backend in config to allow approvals).
                return leash_rejected_response(
                    LeashRejectedByHuman(
                        rule_id=decision.rule_id,
                        reason="hitl: no gate configured; "
                               "set [hitl] backend = inmemory|sqlite to enable",
                    )
                )
            # Long-poll the queue until operator decides or timeout.
            try:
                await state.hitl_gate.request(call, decision)
            except LeashRejectedByHuman as exc:
                if exc.rule_id == "hitl:timeout":
                    return hitl_timeout_response(state.config.hitl.timeout_secs)
                return leash_rejected_response(exc)

    # 4b. PII redaction (before forwarding upstream).
    if state.pii_redactor is not None:
        messages = state.pii_redactor.redact_args({"messages": messages})["messages"]
        body["messages"] = messages
        body_bytes = json.dumps(body).encode("utf-8")

    # 5. Pre-call budget estimate.
    try:
        estimated = await tracker.estimate(
            provider="anthropic", model=model, in_tokens=max_tokens,
        )
        cumulative_before = await tracker.cumulative_usd()
        if tracker._hard is not None and cumulative_before + estimated > tracker._hard:
            raise LeashKilled(
                rule_id="budget:pre_call_estimate",
                reason=(
                    f"pre-call estimate ${estimated:.4f} on top of "
                    f"${cumulative_before:.4f} would exceed cap ${tracker._hard:.4f}"
                ),
            )
    except LeashKilled as exc:
        return leash_killed_response(exc)

    # 6. Forward to upstream.
    upstream_base = request.headers.get("x-llm-leash-upstream") or ANTHROPIC_UPSTREAM
    upstream_url = f"{upstream_base.rstrip('/')}/v1/messages"
    request_hash = _hash_payload({"model": model, "messages": messages})
    is_stream = bool(body.get("stream"))

    if is_stream:
        return await _handle_streaming(
            request=request,
            state=state,
            tracker=tracker,
            upstream_url=upstream_url,
            body_bytes=body_bytes,
            model=model,
            session_id=session_id,
            tenant_id=tenant_id,
            agent_name=agent_name,
            request_hash=request_hash,
        )

    try:
        upstream_resp = await state.http_client.post(
            upstream_url,
            content=body_bytes,
            headers=_forward_headers(request),
        )
    except httpx.HTTPError as exc:
        return upstream_error_response(
            502, f'{{"error":"upstream_unreachable","message":"{exc}"}}'.encode()
        )

    # Non-2xx → pass-through (preserves provider's own error shape).
    if upstream_resp.status_code >= 400:
        return upstream_error_response(
            upstream_resp.status_code,
            upstream_resp.content,
            content_type=upstream_resp.headers.get("content-type", "application/json"),
        )

    # 7. Parse upstream body, extract tokens, charge.
    try:
        resp_body: dict[str, Any] = upstream_resp.json()
    except (json.JSONDecodeError, ValueError):
        return upstream_error_response(502, upstream_resp.content)

    in_tokens, out_tokens = _extract_tokens(resp_body)
    state_obj = await tracker.charge(
        provider="anthropic", model=model,
        in_tokens=in_tokens, out_tokens=out_tokens,
    )

    # 8. Audit.
    state.audit.write(ModelCall(
        ts=_now_iso(), session_id=session_id, tenant_id=tenant_id,
        seq=0, prev_hash="x",
        provider="anthropic", model=model,
        input_tokens=in_tokens, output_tokens=out_tokens,
        cost_usd=state_obj.cumulative_usd,
        request_hash=request_hash,
        response_hash=_hash_payload(resp_body.get("content")),
        agent_name=agent_name,
    ))

    # 9. Metrics.
    if state.metrics is not None:
        state.metrics.requests_total.inc(
            provider="anthropic", model=model,
            agent=agent_name or "_unknown", outcome="ok",
        )
        state.metrics.cost_usd_total.inc(
            state_obj.cumulative_usd,
            provider="anthropic", session=session_id,
            agent=agent_name or "_unknown",
        )

    # 10. Return upstream response verbatim.
    return JSONResponse(resp_body, status_code=upstream_resp.status_code)


async def _handle_streaming(
    *,
    request: Request,
    state: ProxyState,
    tracker: Any,
    upstream_url: str,
    body_bytes: bytes,
    model: str,
    session_id: str,
    tenant_id: str | None,
    agent_name: str | None,
    request_hash: str,
) -> Response:
    """Stream Anthropic SSE through to the client, accounting at end-of-stream.

    Pass-through: every byte the upstream sends reaches the client
    unchanged unless a mid-stream cancel fires. The accumulator inspects
    chunks but doesn't rewrite them. After ``message_stop`` (or stream
    end / cancel), charge + audit.

    GA-2: if cumulative cost (before-request balance + running stream
    cost) exceeds the hard cap mid-flight, abort the upstream connection,
    emit a synthetic SSE error event, and charge what was actually
    consumed up to that point. This protects against runaway generations
    where the pre-call ``max_tokens`` estimate is permissive but actual
    output blows the budget partway through.
    """
    assert state.http_client is not None
    parser = SSEParser()
    accumulator = AnthropicTokenAccumulator()
    cumulative_before = await tracker.cumulative_usd()
    hard_cap = tracker.hard_cap_usd

    async def body_iterator() -> Any:
        cancelled = False
        try:
            async with state.http_client.stream(  # type: ignore[union-attr]
                "POST",
                upstream_url,
                content=body_bytes,
                headers=_forward_headers(request),
            ) as upstream_resp:
                # Upstream error → pass through one synthetic chunk and stop.
                if upstream_resp.status_code >= 400:
                    err_body = await upstream_resp.aread()
                    yield err_body
                    return
                async for raw_chunk in upstream_resp.aiter_raw():
                    if not raw_chunk:
                        continue
                    # Parse to update accumulator, but yield original bytes.
                    for event in parser.feed(raw_chunk):
                        accumulator.feed_event(event)
                    yield raw_chunk
                    # GA-2: mid-stream cap check after each chunk's events.
                    if hard_cap is not None and (accumulator.input_tokens
                                                  or accumulator.output_tokens):
                        running_cost = tracker.cost_of(
                            provider="anthropic", model=model,
                            in_tokens=accumulator.input_tokens,
                            out_tokens=accumulator.output_tokens,
                        )
                        if cumulative_before + running_cost > hard_cap:
                            cancelled = True
                            err_msg = (
                                f"budget: mid-stream cost "
                                f"${cumulative_before + running_cost:.4f} "
                                f"exceeded hard cap ${hard_cap:.4f}; "
                                "upstream cancelled"
                            )
                            yield (
                                f'event: error\ndata: {{"type":"leash_killed",'
                                f'"rule_id":"budget:mid_stream","message":"{err_msg}"}}'
                                f'\n\n'
                            ).encode()
                            yield b"event: message_stop\ndata: {\"type\":\"message_stop\"}\n\n"
                            break
                if not cancelled:
                    # Drain any final event without trailing blank line.
                    for event in parser.drain():
                        accumulator.feed_event(event)
        except httpx.HTTPError as exc:
            yield f'event: error\ndata: {{"type":"upstream_error","message":"{exc}"}}\n\n'.encode()
        finally:
            # End-of-stream: charge what we observed. `charge()` raises
            # LeashKilled when cumulative > hard cap; for a cancelled
            # stream we already told the client — swallow it and still
            # write the audit row from the store's post-charge value.
            in_t = accumulator.input_tokens
            out_t = accumulator.output_tokens
            if in_t or out_t:
                try:
                    state_obj = await tracker.charge(
                        provider="anthropic", model=model,
                        in_tokens=in_t, out_tokens=out_t,
                    )
                    cumulative_after = state_obj.cumulative_usd
                except LeashKilled:
                    cumulative_after = await tracker.cumulative_usd()
                outcome = "cancelled_stream" if cancelled else "ok_stream"
                state.audit.write(ModelCall(
                    ts=_now_iso(), session_id=session_id, tenant_id=tenant_id,
                    seq=0, prev_hash="x",
                    provider="anthropic", model=model,
                    input_tokens=in_t, output_tokens=out_t,
                    cost_usd=cumulative_after,
                    request_hash=request_hash,
                    response_hash="streaming",  # response is the stream itself
                    agent_name=agent_name,
                ))
                if state.metrics is not None:
                    state.metrics.requests_total.inc(
                        provider="anthropic", model=model,
                        agent=agent_name or "_unknown", outcome=outcome,
                    )
                    state.metrics.cost_usd_total.inc(
                        cumulative_after,
                        provider="anthropic", session=session_id,
                        agent=agent_name or "_unknown",
                    )

    return StreamingResponse(
        body_iterator(),
        media_type="text/event-stream",
        headers={"cache-control": "no-cache"},
    )


__all__ = ["ANTHROPIC_UPSTREAM", "handle_messages"]
