"""OpenAI / OpenRouter provider handler for proxy mode (PR-4, non-streaming).

Forwards ``POST /v1/chat/completions`` to ``https://api.openai.com``
(default) or to any OpenAI-compatible upstream (OpenRouter, Together,
Anyscale, vLLM, Ollama, …) via the ``X-LLM-Leash-Upstream`` header.

Enforcement order mirrors the Anthropic provider:

  1. Kill check
  2. Policy engine (rules wired in PR-5)
  3. PII redaction (wired in PR-5)
  4. Pre-call budget estimate
  5. Upstream call via shared ``httpx.AsyncClient``
  6. Charge actual token usage from ``response.usage``
  7. Audit-log the call

OpenRouter routing: if the inbound ``model`` field looks like
``"anthropic/claude-haiku-4-5"`` (provider prefix), we use ``anthropic``
for pricing lookup so the cost matches what OpenRouter actually bills
us. Bare model names (``"gpt-4o"``) default to ``openai``.

Streaming responses are out of scope for PR-4 — they land in PR-7.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
from typing import Any

import httpx
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, StreamingResponse

from ...audit.schema import KillEvent, ModelCall
from ...types import (
    LeashBlocked,
    LeashKilled,
    LeashRejectedByHuman,
    PolicyContext,
    ToolCall,
)
from ..errors import (
    bad_request_response,
    hitl_timeout_response,
    leash_blocked_response,
    leash_killed_response,
    leash_rejected_response,
    upstream_error_response,
)
from ..identity import extract_identity
from ..state import ProxyState
from ..streaming import OpenAITokenAccumulator, SSEParser

OPENAI_UPSTREAM = "https://api.openai.com"
"""Default upstream. Overridable per-request via ``X-LLM-Leash-Upstream``
for OpenRouter (``https://openrouter.ai/api``), Together, Anyscale,
vLLM, Ollama, or any OpenAI-compatible endpoint."""


def _now_iso() -> str:
    return _dt.datetime.now(_dt.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _hash_payload(payload: Any) -> str:
    try:
        s = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    except TypeError:
        s = str(payload)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _split_provider_model(model_str: str) -> tuple[str, str]:
    """``anthropic/claude-haiku-4-5`` → (``anthropic``, ``claude-haiku-4-5``).

    Bare model id (no slash) defaults to ``openai`` — the most common case
    for callers hitting the OpenAI API directly.
    """
    if "/" in model_str:
        prov, _, name = model_str.partition("/")
        return prov.lower(), name
    return "openai", model_str


def _extract_tokens(response_body: dict[str, Any]) -> tuple[int, int]:
    """Pull (prompt_tokens, completion_tokens) from OpenAI-shape response."""
    usage = response_body.get("usage") or {}
    return (
        int(usage.get("prompt_tokens", 0)),
        int(usage.get("completion_tokens", 0)),
    )


def _forward_headers(inbound: Request) -> dict[str, str]:
    """Pick which inbound headers to forward upstream.

    Drops hop-by-hop and proxy-internal headers; preserves
    ``Authorization``, ``OpenAI-Beta``, ``OpenAI-Organization``,
    ``OpenAI-Project``, and the OpenRouter-specific ``HTTP-Referer`` /
    ``X-Title`` headers Minctrl-style integrations rely on.
    """
    DROP = {
        "host", "content-length", "connection", "keep-alive",
        "proxy-authenticate", "proxy-authorization", "te", "trailers",
        "transfer-encoding", "upgrade",
        # proxy-internal — never forward
        "x-llm-leash-session-id", "x-llm-leash-tenant-id",
        "x-llm-leash-upstream",
    }
    return {k: v for k, v in inbound.headers.items() if k.lower() not in DROP}


async def handle_chat_completions(request: Request) -> Response:
    """``POST /v1/chat/completions`` handler."""
    state: ProxyState = request.app.state.llm_leash
    assert state.http_client is not None, "http_client must be set by lifespan handler"

    # 1. Parse body.
    try:
        body_bytes = await request.body()
        body: dict[str, Any] = json.loads(body_bytes)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return bad_request_response(f"body is not valid JSON: {exc}")

    model_str = body.get("model")
    messages = body.get("messages")
    if not isinstance(model_str, str) or not isinstance(messages, list):
        return bad_request_response(
            "request must include 'model' (string) and 'messages' (array)"
        )
    max_tokens = int(body.get("max_tokens") or 0)
    provider, model = _split_provider_model(model_str)

    # 2. Identity.
    identity = extract_identity(request.headers)
    session_id = identity.session_id
    tenant_id = identity.tenant_id
    agent_name = identity.agent_name
    tracker = state.tracker_for(session_id, tenant_id, agent_name)

    # 3. Kill check.
    try:
        if await state.kill.is_killed(session_id):
            reason = await state.kill.reason_for(session_id) or "session killed"
            state.audit.write(KillEvent(
                ts=_now_iso(), session_id=session_id, tenant_id=tenant_id,
                seq=0, prev_hash="x", reason=reason,
            ))
            raise LeashKilled(rule_id="kill:registry", reason=reason)
    except LeashKilled as exc:
        return leash_killed_response(exc)

    # 4. Policy engine.
    if state.engine.rules:
        cumulative = await tracker.cumulative_usd()
        ctx = PolicyContext(
            cumulative_usd=cumulative,
            budget_cap_usd=tracker._hard,
            soft_cap_usd=tracker._soft,
            tenant_id=tenant_id,
        )
        call = ToolCall(
            tool="openai.chat.completions.create",
            args={"model": model_str, "messages": messages},
            session_id=session_id,
            tenant_id=tenant_id,
        )
        try:
            decision = state.engine.evaluate(call, ctx)
        except LeashBlocked as exc:
            return leash_blocked_response(exc)
        if decision.action == "hitl":
            if state.hitl_gate is None:
                return leash_rejected_response(
                    LeashRejectedByHuman(
                        rule_id=decision.rule_id,
                        reason="hitl: no gate configured; "
                               "set [hitl] backend = inmemory|sqlite to enable",
                    )
                )
            try:
                await state.hitl_gate.request(call, decision)
            except LeashRejectedByHuman as exc:
                if exc.rule_id == "hitl:timeout":
                    return hitl_timeout_response(state.config.hitl.timeout_secs)
                return leash_rejected_response(exc)

    # 4b. PII redaction (before forwarding upstream).
    if state.pii_redactor is not None:
        messages = state.pii_redactor.redact_args({"messages": messages})["messages"]
        body["messages"] = messages
        body_bytes = json.dumps(body).encode("utf-8")

    # 5. Pre-call budget estimate.
    try:
        estimated = await tracker.estimate(
            provider=provider, model=model, in_tokens=max_tokens,
        )
        cumulative_before = await tracker.cumulative_usd()
        if tracker._hard is not None and cumulative_before + estimated > tracker._hard:
            raise LeashKilled(
                rule_id="budget:pre_call_estimate",
                reason=(
                    f"pre-call estimate ${estimated:.4f} on top of "
                    f"${cumulative_before:.4f} would exceed cap ${tracker._hard:.4f}"
                ),
            )
    except LeashKilled as exc:
        return leash_killed_response(exc)

    # 6. Forward to upstream.
    upstream_base = request.headers.get("x-llm-leash-upstream") or OPENAI_UPSTREAM
    upstream_url = f"{upstream_base.rstrip('/')}/v1/chat/completions"
    request_hash = _hash_payload({"model": model_str, "messages": messages})

    if bool(body.get("stream")):
        # Auto-inject stream_options.include_usage=true so the final
        # chunk carries token counts. Don't override if caller set it.
        stream_options = body.get("stream_options") or {}
        if not isinstance(stream_options, dict):
            stream_options = {}
        stream_options.setdefault("include_usage", True)
        body["stream_options"] = stream_options
        body_bytes = json.dumps(body).encode("utf-8")

        return await _handle_streaming(
            request=request,
            state=state,
            tracker=tracker,
            upstream_url=upstream_url,
            body_bytes=body_bytes,
            provider=provider,
            model=model,
            model_str=model_str,
            session_id=session_id,
            tenant_id=tenant_id,
            agent_name=agent_name,
            request_hash=request_hash,
        )

    try:
        upstream_resp = await state.http_client.post(
            upstream_url,
            content=body_bytes,
            headers=_forward_headers(request),
        )
    except httpx.HTTPError as exc:
        return upstream_error_response(
            502, f'{{"error":"upstream_unreachable","message":"{exc}"}}'.encode(),
        )

    if upstream_resp.status_code >= 400:
        return upstream_error_response(
            upstream_resp.status_code,
            upstream_resp.content,
            content_type=upstream_resp.headers.get("content-type", "application/json"),
        )

    # 7. Parse upstream body, extract tokens, charge.
    try:
        resp_body: dict[str, Any] = upstream_resp.json()
    except (json.JSONDecodeError, ValueError):
        return upstream_error_response(502, upstream_resp.content)

    in_tokens, out_tokens = _extract_tokens(resp_body)
    state_obj = await tracker.charge(
        provider=provider, model=model,
        in_tokens=in_tokens, out_tokens=out_tokens,
    )

    # 8. Audit.
    state.audit.write(ModelCall(
        ts=_now_iso(), session_id=session_id, tenant_id=tenant_id,
        seq=0, prev_hash="x",
        provider=provider, model=model,
        input_tokens=in_tokens, output_tokens=out_tokens,
        cost_usd=state_obj.cumulative_usd,
        request_hash=request_hash,
        response_hash=_hash_payload(resp_body.get("choices")),
        agent_name=agent_name,
    ))

    # 9. Metrics.
    if state.metrics is not None:
        state.metrics.requests_total.inc(
            provider=provider, model=model,
            agent=agent_name or "_unknown", outcome="ok",
        )
        state.metrics.cost_usd_total.inc(
            state_obj.cumulative_usd,
            provider=provider, session=session_id,
            agent=agent_name or "_unknown",
        )

    # 10. Return upstream response verbatim.
    return JSONResponse(resp_body, status_code=upstream_resp.status_code)


async def _handle_streaming(
    *,
    request: Request,
    state: ProxyState,
    tracker: Any,
    upstream_url: str,
    body_bytes: bytes,
    provider: str,
    model: str,
    model_str: str,
    session_id: str,
    tenant_id: str | None,
    agent_name: str | None,
    request_hash: str,
) -> Response:
    """Stream OpenAI SSE through to the client, accounting at end-of-stream.

    See providers/anthropic.py:_handle_streaming for the design notes —
    same pattern, different token field names.
    """
    assert state.http_client is not None
    parser = SSEParser()
    accumulator = OpenAITokenAccumulator()
    cumulative_before = await tracker.cumulative_usd()
    hard_cap = tracker.hard_cap_usd

    async def body_iterator() -> Any:
        cancelled = False
        try:
            async with state.http_client.stream(  # type: ignore[union-attr]
                "POST",
                upstream_url,
                content=body_bytes,
                headers=_forward_headers(request),
            ) as upstream_resp:
                if upstream_resp.status_code >= 400:
                    err_body = await upstream_resp.aread()
                    yield err_body
                    return
                async for raw_chunk in upstream_resp.aiter_raw():
                    if not raw_chunk:
                        continue
                    for event in parser.feed(raw_chunk):
                        accumulator.feed_event(event)
                    yield raw_chunk
                    # GA-2: mid-stream cap check using approx output tokens.
                    if hard_cap is not None and accumulator.approx_output_tokens:
                        running_cost = tracker.cost_of(
                            provider=provider, model=model,
                            in_tokens=accumulator.input_tokens,
                            out_tokens=accumulator.approx_output_tokens,
                        )
                        if cumulative_before + running_cost > hard_cap:
                            cancelled = True
                            err_msg = (
                                f"budget: mid-stream cost "
                                f"${cumulative_before + running_cost:.4f} "
                                f"exceeded hard cap ${hard_cap:.4f}; "
                                "upstream cancelled"
                            )
                            yield (
                                f'data: {{"error":{{"type":"leash_killed",'
                                f'"rule_id":"budget:mid_stream","message":"{err_msg}"}}}}'
                                f'\n\ndata: [DONE]\n\n'
                            ).encode()
                            # Persist approximate output_tokens so finally charges it.
                            if not accumulator.output_tokens:
                                accumulator.output_tokens = accumulator.approx_output_tokens
                            break
                if not cancelled:
                    for event in parser.drain():
                        accumulator.feed_event(event)
        except httpx.HTTPError as exc:
            yield (
                f'data: {{"error":"upstream_unreachable","message":"{exc}"}}'
                f'\n\ndata: [DONE]\n\n'
            ).encode()
        finally:
            in_t = accumulator.input_tokens
            out_t = accumulator.output_tokens
            if in_t or out_t:
                try:
                    state_obj = await tracker.charge(
                        provider=provider, model=model,
                        in_tokens=in_t, out_tokens=out_t,
                    )
                    cumulative_after = state_obj.cumulative_usd
                except LeashKilled:
                    cumulative_after = await tracker.cumulative_usd()
                outcome = "cancelled_stream" if cancelled else "ok_stream"
                state.audit.write(ModelCall(
                    ts=_now_iso(), session_id=session_id, tenant_id=tenant_id,
                    seq=0, prev_hash="x",
                    provider=provider, model=model,
                    input_tokens=in_t, output_tokens=out_t,
                    cost_usd=cumulative_after,
                    request_hash=request_hash,
                    response_hash="streaming",
                    agent_name=agent_name,
                ))
                if state.metrics is not None:
                    state.metrics.requests_total.inc(
                        provider=provider, model=model,
                        agent=agent_name or "_unknown", outcome=outcome,
                    )
                    state.metrics.cost_usd_total.inc(
                        cumulative_after,
                        provider=provider, session=session_id,
                        agent=agent_name or "_unknown",
                    )

    return StreamingResponse(
        body_iterator(),
        media_type="text/event-stream",
        headers={"cache-control": "no-cache"},
    )


__all__ = ["OPENAI_UPSTREAM", "handle_chat_completions"]
