"""Provider-shape adapters for proxy mode.

Each provider module translates between the on-wire protocol of a
specific LLM provider (Anthropic, OpenAI, OpenRouter) and the internal
``ToolCall`` / ``ModelCall`` types the firewall expects.

v2.0 skeleton: empty. Implementations land in PR-3 (Anthropic),
PR-4 (OpenAI), and PR-7 (streaming).
"""
