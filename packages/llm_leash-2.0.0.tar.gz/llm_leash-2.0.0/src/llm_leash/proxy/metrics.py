"""Prometheus-compatible metrics for the proxy.

We don't pull `prometheus_client` as a dependency — the text exposition
format is tiny and easy to render ourselves. This keeps the proxy's
optional-dep set small (starlette + httpx + uvicorn only) and avoids
shared global registries that fight with operator-side observability
stacks.

Two metric types are enough for v2.0:
  Counter: monotonic accumulator (request counts, total cost in USD)
  Gauge:   point-in-time value (active sessions, pending HITL)

Histograms / Summaries are deferred until someone asks. Operators who
want p99 request duration can scrape /admin/stats or wire a real
Prometheus client themselves (the proxy doesn't preclude that).
"""
from __future__ import annotations

import threading
from collections.abc import Callable
from typing import Any

# A label set is a sorted tuple of (k, v) pairs so it's hashable + stable.
_LabelSet = tuple[tuple[str, str], ...]


def _normalise_labels(labels: dict[str, Any]) -> _LabelSet:
    return tuple(sorted((k, str(v)) for k, v in labels.items()))


def _format_labels(label_set: _LabelSet) -> str:
    if not label_set:
        return ""
    parts = [f'{k}="{_escape(v)}"' for k, v in label_set]
    return "{" + ",".join(parts) + "}"


def _escape(value: str) -> str:
    """Prometheus label-value escaping rules: \\ → \\\\, " → \\\", newline → \\n."""
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


class Counter:
    """Monotonic accumulator. Thread-safe for the writes we do."""

    def __init__(self, name: str, help_text: str) -> None:
        self.name = name
        self.help_text = help_text
        self._values: dict[_LabelSet, float] = {}
        self._lock = threading.Lock()

    def inc(self, amount: float = 1.0, **labels: Any) -> None:
        key = _normalise_labels(labels)
        with self._lock:
            self._values[key] = self._values.get(key, 0.0) + amount

    def items(self) -> list[tuple[_LabelSet, float]]:
        with self._lock:
            return list(self._values.items())


class Gauge:
    """Point-in-time value. Can go up or down; supports a callback model.

    Use `set(value, **labels)` for static gauges, or pass a `callback`
    that's invoked at scrape time for live values (e.g. read from a
    queue). Callbacks return either a float (no labels) or a list of
    (labels_dict, value) tuples.
    """

    def __init__(
        self,
        name: str,
        help_text: str,
        callback: Callable[[], float | list[tuple[dict[str, Any], float]]] | None = None,
    ) -> None:
        self.name = name
        self.help_text = help_text
        self._callback = callback
        self._values: dict[_LabelSet, float] = {}
        self._lock = threading.Lock()

    def set(self, value: float, **labels: Any) -> None:
        key = _normalise_labels(labels)
        with self._lock:
            self._values[key] = value

    def items(self) -> list[tuple[_LabelSet, float]]:
        # Callbacks take precedence over set() values.
        if self._callback is not None:
            result = self._callback()
            if isinstance(result, list | tuple):
                return [(_normalise_labels(lbls), float(val)) for lbls, val in result]
            return [((), float(result))]
        with self._lock:
            return list(self._values.items())


class Registry:
    """Holds all the metrics the proxy exposes."""

    def __init__(self) -> None:
        self._metrics: list[Counter | Gauge] = []

    def register(self, metric: Counter | Gauge) -> None:
        self._metrics.append(metric)

    def render(self) -> str:
        """Produce Prometheus text-format output."""
        lines: list[str] = []
        for m in self._metrics:
            mtype = "counter" if isinstance(m, Counter) else "gauge"
            lines.append(f"# HELP {m.name} {m.help_text}")
            lines.append(f"# TYPE {m.name} {mtype}")
            for label_set, value in m.items():
                # Prometheus convention: counters end with _total; we put
                # the value on the same line as the labels.
                # Integers render without decimal point for readability.
                if value == int(value):
                    rendered = str(int(value))
                else:
                    rendered = repr(value)
                lines.append(f"{m.name}{_format_labels(label_set)} {rendered}")
        return "\n".join(lines) + "\n"


# ─── Build the registry for a given ProxyState ────────────────────────


def build_registry(state: Any) -> Registry:
    """Build the registry of metrics, bound to a ``ProxyState``.

    Counters increment as requests flow through the providers (so each
    request handler does ``state.metrics.requests_total.inc(...)``).
    Gauges are callback-based so they reflect live state at scrape time.
    """
    reg = Registry()

    requests_total = Counter(
        "llm_leash_requests_total",
        "Total proxy requests, labelled by provider, model, agent, outcome",
    )
    cost_usd_total = Counter(
        "llm_leash_cost_usd_total",
        "Cumulative LLM spend in USD, labelled by provider, agent, session",
    )
    errors_total = Counter(
        "llm_leash_errors_total",
        "Total proxy errors (4xx/5xx returned), labelled by outcome",
    )

    def _active_sessions() -> float:
        return float(len(state._trackers))

    def _hitl_pending() -> float:
        if state.hitl_queue is None:
            return 0.0
        # Synchronous gauge — peek at the InMemory queue's dict directly
        # when present (avoids spinning an event loop just to scrape).
        # SQLiteHitlQueue.list_pending() is async; for the simple case,
        # we cache last-known count via the providers updating it.
        inner = getattr(state.hitl_queue, "_items", None)
        if inner is not None:
            return float(sum(1 for r in inner.values() if r.status == "pending"))
        # Fallback: 0 (operator can call /admin/hitl/pending for live count).
        return 0.0

    active_sessions = Gauge(
        "llm_leash_active_sessions",
        "Active sessions tracked by this proxy worker (restart-scoped)",
        callback=_active_sessions,
    )
    hitl_pending = Gauge(
        "llm_leash_hitl_pending",
        "HITL requests awaiting human decision (InMemory queue only; "
        "for SQLite see /admin/hitl/pending)",
        callback=_hitl_pending,
    )

    reg.register(requests_total)
    reg.register(cost_usd_total)
    reg.register(errors_total)
    reg.register(active_sessions)
    reg.register(hitl_pending)

    # Stash on the state so handlers can increment.
    state.metrics = _MetricsBundle(
        registry=reg,
        requests_total=requests_total,
        cost_usd_total=cost_usd_total,
        errors_total=errors_total,
    )
    return reg


class _MetricsBundle:
    """Attached to ProxyState by build_registry. Providers import via
    ``state.metrics.requests_total.inc(...)``."""

    def __init__(
        self,
        *,
        registry: Registry,
        requests_total: Counter,
        cost_usd_total: Counter,
        errors_total: Counter,
    ) -> None:
        self.registry = registry
        self.requests_total = requests_total
        self.cost_usd_total = cost_usd_total
        self.errors_total = errors_total


__all__ = ["Counter", "Gauge", "Registry", "build_registry"]
