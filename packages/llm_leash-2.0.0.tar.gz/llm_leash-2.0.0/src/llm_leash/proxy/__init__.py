"""HTTP proxy mode for llm-leash.

Optional component shipped under ``pip install "llm-leash[proxy]"``. The
core library has zero runtime dependencies; importing this package will
fail if Starlette / httpx / uvicorn are missing.

See ``docs/PROXY.md`` for deployment recipes.
"""
from __future__ import annotations

# Probe required deps eagerly so import errors are clearer than "no attribute".
try:
    import httpx  # noqa: F401
    import starlette  # noqa: F401
    import uvicorn  # noqa: F401
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        'llm-leash proxy mode requires extra dependencies. '
        'Install with:  pip install "llm-leash[proxy]"'
    ) from exc

from .server import build_app, main

__all__ = ["build_app", "main"]
