"""Admin HTTP endpoints for proxy operator workflows.

All endpoints require ``Authorization: Bearer <admin_token>`` matching
``config.admin_token``. Missing or wrong token → 401. If
``config.admin_token is None`` the admin routes are still mounted but
respond 503 (operator must explicitly configure a token to enable).

Endpoints (mounted at ``/admin/*``):

  GET    /admin/kill/{session_id}              status
  POST   /admin/kill/{session_id}    {reason}  mark killed
  DELETE /admin/kill/{session_id}              clear kill
  POST   /admin/tenant/{tenant}/pause          kill every session in the tenant
                                               (uses heuristic: kill SESSION_ID for
                                               every audit entry where tenant matches —
                                               for v2.0 we just kill the tenant as a
                                               special session_id 'tenant:<name>';
                                               wider coverage in v2.1 metrics PR)

  GET    /admin/hitl/pending                   list pending HitlRequest objects
  POST   /admin/hitl/{request_id}/approve      approve pending request
  POST   /admin/hitl/{request_id}/reject       {reason} reject

  GET    /admin/stats                          aggregate across budget store
                                               (proxy-restart-scoped: counts in-memory
                                                trackers; for cross-restart use the
                                                /metrics endpoint in PR-10')

Designed to be paired with the CLI: ``llm-leash kill <session> --proxy URL``,
``llm-leash hitl approve <id> --proxy URL``, etc.
"""
from __future__ import annotations

import json
from typing import Any

from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from .errors import bad_request_response
from .state import ProxyState


def _unauthorized(message: str = "missing or invalid admin token") -> JSONResponse:
    return JSONResponse(
        {"error": {"type": "unauthorized", "message": message}},
        status_code=401,
    )


def _not_configured() -> JSONResponse:
    return JSONResponse(
        {"error": {
            "type": "admin_not_configured",
            "message": "Admin endpoints disabled. Set admin_token in proxy.toml "
                       "or LLM_LEASH_PROXY_ADMIN_TOKEN to enable.",
        }},
        status_code=503,
    )


def _require_admin(request: Request) -> ProxyState | Response:
    """Returns ProxyState when authorized, or a Response (401/503) otherwise."""
    state: ProxyState = request.app.state.llm_leash
    expected = state.config.admin_token
    if not expected:
        return _not_configured()
    auth = request.headers.get("authorization", "")
    prefix = "Bearer "
    if not auth.startswith(prefix) or auth[len(prefix):] != expected:
        return _unauthorized()
    return state


# ─── Kill switch ──────────────────────────────────────────────────────


async def admin_kill_status(request: Request) -> Response:
    state_or_resp = _require_admin(request)
    if isinstance(state_or_resp, Response):
        return state_or_resp
    state = state_or_resp
    session_id = request.path_params["session_id"]
    killed = await state.kill.is_killed(session_id)
    reason = await state.kill.reason_for(session_id)
    return JSONResponse({
        "session_id": session_id,
        "killed": killed,
        "reason": reason,
    })


async def admin_kill_set(request: Request) -> Response:
    state_or_resp = _require_admin(request)
    if isinstance(state_or_resp, Response):
        return state_or_resp
    state = state_or_resp
    session_id = request.path_params["session_id"]
    try:
        body = await request.body()
        data: dict[str, Any] = json.loads(body) if body else {}
    except json.JSONDecodeError:
        return bad_request_response("body must be JSON or empty")
    reason = str(data.get("reason") or "operator kill via admin API")
    await state.kill.kill(session_id, reason=reason)
    return JSONResponse({
        "session_id": session_id, "killed": True, "reason": reason,
    })


async def admin_kill_clear(request: Request) -> Response:
    state_or_resp = _require_admin(request)
    if isinstance(state_or_resp, Response):
        return state_or_resp
    state = state_or_resp
    session_id = request.path_params["session_id"]
    await state.kill.clear(session_id)
    return JSONResponse({"session_id": session_id, "killed": False})


async def admin_tenant_pause(request: Request) -> Response:
    """Pause a tenant by killing the tenant-scoped session and every
    in-process session whose tenant_id matches.

    Iterates the in-process ``_trackers`` cache so any session that this
    proxy worker has seen this restart gets killed. For multi-worker
    deployments, the operator should also issue this against each worker
    (or use a shared Redis/SQLite kill registry — PR-10').
    """
    state_or_resp = _require_admin(request)
    if isinstance(state_or_resp, Response):
        return state_or_resp
    state = state_or_resp
    tenant = request.path_params["tenant"]
    killed_sessions: list[str] = []
    # Tracker cache keys are (session_id, agent_name); collapse to unique
    # session_ids so we kill each session once.
    seen_sessions: set[str] = set()
    for session_id, _agent in list(state._trackers.keys()):
        if session_id in seen_sessions:
            continue
        seen_sessions.add(session_id)
        # We don't currently carry tenant in the tracker dataclass, so
        # check via the session_id namespacing convention (tenant:<name>
        # pseudo-session OR "<tenant>:<id>" prefix).
        if session_id.startswith(f"{tenant}:") or session_id == tenant:
            await state.kill.kill(session_id, reason=f"tenant {tenant!r} paused")
            killed_sessions.append(session_id)
    # Also kill the pseudo "tenant:<name>" session id so future calls fail.
    pseudo_session = f"tenant:{tenant}"
    await state.kill.kill(pseudo_session, reason=f"tenant {tenant!r} paused")
    return JSONResponse({
        "tenant": tenant,
        "paused_at_sessions": killed_sessions,
        "tenant_marker": pseudo_session,
    })


# ─── HITL ─────────────────────────────────────────────────────────────


async def admin_hitl_pending(request: Request) -> Response:
    state_or_resp = _require_admin(request)
    if isinstance(state_or_resp, Response):
        return state_or_resp
    state = state_or_resp
    if state.hitl_queue is None:
        return JSONResponse({"pending": [], "hitl_backend": "none"})
    items = await state.hitl_queue.list_pending()
    return JSONResponse({
        "hitl_backend": state.config.hitl.backend,
        "pending": [
            {
                "request_id": r.request_id,
                "created_ts": r.created_ts,
                "session_id": r.session_id,
                "tenant_id": r.tenant_id,
                "tool": r.tool,
                "rule_id": r.rule_id,
                "reason": r.reason,
            }
            for r in items
        ],
    })


async def admin_hitl_approve(request: Request) -> Response:
    state_or_resp = _require_admin(request)
    if isinstance(state_or_resp, Response):
        return state_or_resp
    state = state_or_resp
    if state.hitl_queue is None:
        return JSONResponse(
            {"error": {"type": "hitl_disabled",
                       "message": "set [hitl] backend in proxy config"}},
            status_code=503,
        )
    request_id = request.path_params["request_id"]
    await state.hitl_queue.approve(request_id)
    return JSONResponse({"request_id": request_id, "decision": "approved"})


async def admin_hitl_reject(request: Request) -> Response:
    state_or_resp = _require_admin(request)
    if isinstance(state_or_resp, Response):
        return state_or_resp
    state = state_or_resp
    if state.hitl_queue is None:
        return JSONResponse(
            {"error": {"type": "hitl_disabled",
                       "message": "set [hitl] backend in proxy config"}},
            status_code=503,
        )
    request_id = request.path_params["request_id"]
    try:
        body = await request.body()
        data: dict[str, Any] = json.loads(body) if body else {}
    except json.JSONDecodeError:
        return bad_request_response("body must be JSON or empty")
    reason = str(data.get("reason") or "rejected by operator")
    await state.hitl_queue.reject(request_id, reason=reason)
    return JSONResponse({
        "request_id": request_id, "decision": "rejected", "reason": reason,
    })


# ─── Stats ────────────────────────────────────────────────────────────


async def admin_stats(request: Request) -> Response:
    """Aggregate stats from in-process trackers + queue state.

    Restart-scoped: a fresh proxy worker shows zeros until traffic hits it.
    For durable cross-restart stats, use /metrics (PR-10').
    """
    state_or_resp = _require_admin(request)
    if isinstance(state_or_resp, Response):
        return state_or_resp
    state = state_or_resp

    # Tracker cache is keyed by (session_id, agent_name). Multiple agents
    # in the same session share a budget balance, so collapse to unique
    # session_ids before reading the store.
    by_session: list[dict[str, Any]] = []
    total_spend = 0.0
    unique_sessions = {sid for sid, _agent in state._trackers}
    for session_id in unique_sessions:
        cumulative = await state.budget_store.get(session_id)
        by_session.append({
            "session_id": session_id,
            "cost_usd": cumulative,
        })
        total_spend += cumulative
    by_session.sort(key=lambda x: x["cost_usd"], reverse=True)

    hitl_pending = 0
    if state.hitl_queue is not None:
        hitl_pending = len(await state.hitl_queue.list_pending())

    return JSONResponse({
        "active_sessions": len(unique_sessions),
        "total_spend_usd": round(total_spend, 6),
        "top_sessions": by_session[:20],
        "hitl_pending": hitl_pending,
        "hitl_backend": state.config.hitl.backend,
        "policy_rules": len(state.engine.rules),
        "pii_redactor_enabled": state.pii_redactor is not None,
    })


# ─── Routes registration ──────────────────────────────────────────────


def admin_routes() -> list[Route]:
    """All /admin/* routes for plugging into the main Starlette app."""
    return [
        Route("/admin/kill/{session_id}", admin_kill_status, methods=["GET"]),
        Route("/admin/kill/{session_id}", admin_kill_set, methods=["POST"]),
        Route("/admin/kill/{session_id}", admin_kill_clear, methods=["DELETE"]),
        Route("/admin/tenant/{tenant}/pause", admin_tenant_pause, methods=["POST"]),
        Route("/admin/hitl/pending", admin_hitl_pending, methods=["GET"]),
        Route("/admin/hitl/{request_id}/approve", admin_hitl_approve, methods=["POST"]),
        Route("/admin/hitl/{request_id}/reject", admin_hitl_reject, methods=["POST"]),
        Route("/admin/stats", admin_stats, methods=["GET"]),
    ]


__all__ = ["admin_routes"]
