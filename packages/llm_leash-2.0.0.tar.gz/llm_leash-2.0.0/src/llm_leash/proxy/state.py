"""Per-process state for the proxy.

The proxy holds one ``ProxyState`` for the lifetime of the app. State
contains:
  - a single ``AuditWriter`` (one log file shared across all sessions)
  - a single ``BudgetStore`` (cumulative spend per session_id)
  - a per-session ``BudgetTracker`` cache (so cap config can vary by
    tenant without rebuilding the store)
  - a single ``KillRegistry``
  - a single ``PolicyEngine`` (rules apply equally to every session)
  - an optional ``PiiRedactor`` (applied to outgoing args when enabled)
  - an ``httpx.AsyncClient`` for outbound provider calls

The httpx client is set in the Starlette lifespan handler — passing it
through ``set_http_client`` rather than at construction time keeps
``build_app`` and tests decoupled from connection lifecycle.
"""
from __future__ import annotations

import importlib
from dataclasses import dataclass, field
from typing import Any

import httpx

from ..audit.writer import AuditWriter
from ..budget.redis_store import RedisBudgetStore
from ..budget.sqlite_store import SQLiteBudgetStore
from ..budget.store import BudgetStore, InMemoryStore
from ..budget.tracker import BudgetTracker
from ..hitl.gate import HitlGate
from ..hitl.queue import (
    HitlQueue,
    InMemoryHitlQueue,
    QueueBackedHitlGate,
    SQLiteHitlQueue,
)
from ..kill.redis_registry import RedisKillRegistry
from ..kill.registry import InProcessKillRegistry, KillRegistry
from ..kill.sqlite_registry import SQLiteKillRegistry
from ..policy.engine import PolicyEngine
from ..policy.pii import PiiRedactor
from ..types import Rule
from .config import ProxyConfig


class _NoopAuditWriter:
    """When no audit_log is configured. Same interface as AuditWriter."""

    def write(self, event):  # type: ignore[no-untyped-def]
        return event

    def close(self) -> None:
        pass


@dataclass
class ProxyState:
    """Everything a request handler needs, in one place."""

    config: ProxyConfig
    audit: AuditWriter | _NoopAuditWriter
    budget_store: BudgetStore
    kill: KillRegistry
    engine: PolicyEngine
    pii_redactor: PiiRedactor | None = None
    hitl_gate: HitlGate | None = None
    # Underlying queue — exposed so admin endpoints / tests can call
    # approve/reject/list_pending against it directly.
    hitl_queue: HitlQueue | None = None

    # Populated by `build_app` via `metrics.build_registry(state)`.
    metrics: Any = None

    # Set by the Starlette lifespan handler in `server.build_app`.
    http_client: httpx.AsyncClient | None = None

    # Lazy per-session BudgetTracker cache.
    _trackers: dict[tuple[str, str], BudgetTracker] = field(default_factory=dict)

    @classmethod
    def from_config(cls, config: ProxyConfig) -> ProxyState:
        """Build state with the backends specified in `config`.

        In-memory + SQLite backends supported in this PR. Redis / HTTP
        backends ship in a later PR per the roadmap.
        """
        audit: AuditWriter | _NoopAuditWriter
        if config.audit_log:
            audit = AuditWriter(config.audit_log, fsync=False)
        else:
            audit = _NoopAuditWriter()
        gate, queue = _make_hitl(config)
        return cls(
            config=config,
            audit=audit,
            budget_store=_make_budget_store(config),
            kill=_make_kill_registry(config),
            engine=_make_policy_engine(config),
            pii_redactor=_make_pii_redactor(config),
            hitl_gate=gate,
            hitl_queue=queue,
        )

    def tracker_for(
        self,
        session_id: str,
        tenant_id: str | None,
        agent_name: str | None = None,
    ) -> BudgetTracker:
        """Return (or create) a BudgetTracker for a (session, agent) pair.

        Cap precedence (highest to lowest):
          1. per-agent cap   (``config.budget.per_agent_caps[agent_name]``)
          2. per-tenant cap  (``config.budget.per_tenant_caps[tenant_id]``)
          3. default cap     (``config.budget.default_cap_usd``)
          4. no cap          (``None`` — never refuses on budget)

        Cumulative cost is keyed by ``session_id`` in the underlying
        store, so multiple agents in the same session share a balance;
        the cap that fires is the one for the currently-calling agent.
        """
        cache_key = (session_id, agent_name or "")
        if cache_key not in self._trackers:
            cap = self.config.budget.default_cap_usd
            if tenant_id and tenant_id in self.config.budget.per_tenant_caps:
                cap = self.config.budget.per_tenant_caps[tenant_id]
            if agent_name and agent_name in self.config.budget.per_agent_caps:
                cap = self.config.budget.per_agent_caps[agent_name]
            self._trackers[cache_key] = BudgetTracker(
                session_id=session_id,
                hard_cap_usd=cap,
                soft_cap_usd=None,
                store=self.budget_store,
            )
        return self._trackers[cache_key]

    async def aclose(self) -> None:
        """Release resources. Idempotent."""
        if hasattr(self.audit, "close"):
            self.audit.close()
        if self.http_client is not None:
            await self.http_client.aclose()
            self.http_client = None
        if isinstance(self.hitl_queue, SQLiteHitlQueue):
            self.hitl_queue.close()
        if isinstance(self.budget_store, SQLiteBudgetStore):
            self.budget_store.close()
        if isinstance(self.kill, SQLiteKillRegistry):
            self.kill.close()


def _make_budget_store(config: ProxyConfig) -> BudgetStore:
    """Build the budget store backend.

    - inmemory: single-process, dict-backed
    - sqlite:   file-backed, multi-process safe via WAL
    - redis:    multi-replica safe; duck-typed Redis client constructed from
                ``budget.redis_url`` via ``redis.Redis.from_url`` if the
                ``redis`` package is installed
    """
    backend = config.budget.backend
    if backend == "inmemory":
        return InMemoryStore()
    if backend == "sqlite":
        if not config.budget.sqlite_path:
            raise ValueError("budget.backend=sqlite requires budget.sqlite_path")
        return SQLiteBudgetStore(config.budget.sqlite_path)
    if backend == "redis":
        if not config.budget.redis_url:
            raise ValueError("budget.backend=redis requires budget.redis_url")
        return RedisBudgetStore(_make_redis_client(config.budget.redis_url))
    raise ValueError(
        f"Unsupported budget backend: {backend!r} "
        "(supported: 'inmemory', 'sqlite', 'redis')"
    )


def _make_kill_registry(config: ProxyConfig) -> KillRegistry:
    """Build the kill registry backend.

    - inmemory: single-process dict
    - sqlite:   file-backed, multi-process safe
    - redis:    multi-replica safe
    - http:     ship-later (PR for HTTP cross-process not yet wired into proxy)
    """
    backend = config.kill.backend
    if backend == "inmemory":
        return InProcessKillRegistry()
    if backend == "sqlite":
        if not config.kill.sqlite_path:
            raise ValueError("kill.backend=sqlite requires kill.sqlite_path")
        return SQLiteKillRegistry(config.kill.sqlite_path)
    if backend == "redis":
        if not config.kill.redis_url:
            raise ValueError("kill.backend=redis requires kill.redis_url")
        return RedisKillRegistry(_make_redis_client(config.kill.redis_url))
    raise ValueError(
        f"Unsupported kill backend: {backend!r} "
        "(supported: 'inmemory', 'sqlite', 'redis')"
    )


def _make_redis_client(url: str) -> Any:
    """Construct a sync ``redis.Redis`` client from a URL.

    The redis package is an optional dependency (``pip install
    'llm-leash[redis]'``). We import inside the function so the rest of
    the proxy works without it installed.
    """
    try:
        import redis  # type: ignore[import-not-found,unused-ignore]
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "backend=redis requires the 'redis' package. "
            'Install with: pip install "llm-leash[redis]"'
        ) from exc
    return redis.Redis.from_url(url)


def _make_policy_engine(config: ProxyConfig) -> PolicyEngine:
    """Load rules from `config.policy.rules_module` (dotted Python path).

    The target module must expose a module-level ``rules: list[Rule]``.
    Each item is duck-typed (must have ``id`` and ``evaluate`` callable).

    No module configured → empty engine (never blocks).
    """
    rules: list[Rule] = []
    module_path = config.policy.rules_module
    if module_path:
        module = importlib.import_module(module_path)
        loaded = getattr(module, "rules", None)
        if loaded is None:
            raise ValueError(
                f"policy.rules_module={module_path!r} must define a "
                f"module-level 'rules' attribute (list of Rule objects)"
            )
        if not isinstance(loaded, list):
            raise ValueError(
                f"policy.rules_module={module_path!r}.rules must be a list, "
                f"got {type(loaded).__name__}"
            )
        rules = loaded
    return PolicyEngine(rules)


def _make_pii_redactor(config: ProxyConfig) -> PiiRedactor | None:
    """Return a `PiiRedactor` instance when enabled in config, else None."""
    if config.policy.pii_redactor:
        return PiiRedactor()
    return None


def _make_hitl(
    config: ProxyConfig,
) -> tuple[HitlGate | None, HitlQueue | None]:
    """Build (gate, queue) pair from config.

    The gate is what providers call when a rule decides ``action="hitl"``;
    the queue is what operator admin endpoints (PR-9') talk to to
    approve / reject / list pending requests.

    Backends:
      "none"     → (None, None)         no HITL — rules returning hitl get default-deny
      "inmemory" → InMemoryHitlQueue    state lost on restart
      "sqlite"   → SQLiteHitlQueue      durable across restarts
    """
    backend = config.hitl.backend
    queue: HitlQueue | None
    if backend == "none":
        return None, None
    if backend == "inmemory":
        queue = InMemoryHitlQueue()
    elif backend == "sqlite":
        if not config.hitl.sqlite_path:
            raise ValueError("hitl.backend=sqlite requires hitl.sqlite_path")
        queue = SQLiteHitlQueue(config.hitl.sqlite_path)
    else:
        raise ValueError(
            f"Unsupported hitl backend: {backend!r} "
            "(supported: 'none', 'inmemory', 'sqlite')"
        )
    gate = QueueBackedHitlGate(
        queue,
        timeout_secs=config.hitl.timeout_secs,
        poll_interval_secs=0.1,
    )
    return gate, queue


__all__ = ["ProxyState"]
