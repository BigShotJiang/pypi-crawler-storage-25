"""HTTP error responses for proxy-side enforcement decisions.

Per ``docs/superpowers/plans/2026-05-16-llm-leash-v2.0-proxy.md`` §7,
internal ``Leash*`` exceptions map to HTTP status codes with a JSON body
shaped like the provider's own error envelope. Clients using the
``openai`` or ``anthropic`` SDK then surface them cleanly through their
normal error paths.

The body always nests under a top-level ``error`` object — matches both
OpenAI and Anthropic error conventions so the same SDK error class
handles them.
"""
from __future__ import annotations

from typing import Any

from starlette.responses import JSONResponse

from ..types import LeashBlocked, LeashKilled, LeashRejectedByHuman


def _envelope(
    error_type: str,
    message: str,
    *,
    code: str | None = None,
    rule_id: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"error": {"type": error_type, "message": message}}
    if code is not None:
        body["error"]["code"] = code
    if rule_id is not None:
        body["error"]["rule_id"] = rule_id
    if extra:
        body["error"].update(extra)
    return body


def leash_killed_response(exc: LeashKilled) -> JSONResponse:
    """LeashKilled → 402 Payment Required.

    Code disambiguates *why* killed: ``budget_exceeded`` (cap hit) vs
    ``session_killed`` (operator pulled the trigger). Both surface as
    402 so clients can apply the same back-off logic.
    """
    code = "session_killed" if exc.rule_id == "kill:registry" else "budget_exceeded"
    return JSONResponse(
        _envelope("leash_killed", exc.reason, code=code, rule_id=exc.rule_id),
        status_code=402,
    )


def leash_blocked_response(exc: LeashBlocked) -> JSONResponse:
    """LeashBlocked → 403 Forbidden."""
    return JSONResponse(
        _envelope(
            "leash_blocked", exc.reason,
            code="policy_block", rule_id=exc.rule_id,
        ),
        status_code=403,
    )


def leash_rejected_response(exc: LeashRejectedByHuman) -> JSONResponse:
    """LeashRejectedByHuman → 403 Forbidden.

    Distinguished from `leash_blocked` only by ``type`` field, so clients
    that want to retry-with-different-args on policy blocks but NOT on
    operator rejections can branch on it.
    """
    return JSONResponse(
        _envelope(
            "leash_rejected_by_human", exc.reason,
            code="human_rejected", rule_id=exc.rule_id,
        ),
        status_code=403,
    )


def hitl_timeout_response(timeout_secs: float) -> JSONResponse:
    """No human decision before ``timeout_secs`` → 408 Request Timeout."""
    return JSONResponse(
        _envelope(
            "leash_hitl_timeout",
            f"No human decision after {timeout_secs:.1f}s",
            code="hitl_timeout",
        ),
        status_code=408,
    )


def bad_request_response(message: str) -> JSONResponse:
    """Malformed body / missing required field → 400."""
    return JSONResponse(
        _envelope("invalid_request", message, code="bad_request"),
        status_code=400,
    )


def upstream_error_response(
    status_code: int,
    body_bytes: bytes,
    content_type: str = "application/json",
) -> JSONResponse:
    """Pass-through for upstream provider errors.

    Preserves the original status code so client SDK error handlers
    fire as if they'd called the provider directly. Body is passed
    through verbatim (best effort — if upstream sent malformed JSON,
    we wrap it in our envelope so clients still get usable structure).
    """
    import json
    try:
        # Try to keep the upstream body shape intact.
        parsed = json.loads(body_bytes)
        return JSONResponse(parsed, status_code=status_code)
    except (json.JSONDecodeError, ValueError):
        return JSONResponse(
            _envelope(
                "upstream_error",
                f"Provider returned {status_code} with non-JSON body",
                code="upstream_non_json",
                extra={"upstream_status": status_code,
                       "upstream_body_preview": body_bytes[:200].decode(
                           "utf-8", errors="replace")},
            ),
            status_code=status_code,
        )


__all__ = [
    "bad_request_response",
    "hitl_timeout_response",
    "leash_blocked_response",
    "leash_killed_response",
    "leash_rejected_response",
    "upstream_error_response",
]
