"""Starlette ASGI app for llm-leash proxy mode.

PR-3: wires Anthropic ``POST /v1/messages`` with full enforcement
(kill, policy stub, budget, audit). Streaming, OpenAI, HITL, admin
endpoints, metrics land in later PRs per the v2.0 plan.
"""
from __future__ import annotations

import argparse
import sys
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from typing import Any

import httpx
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from .. import __version__
from .admin import admin_routes
from .config import ProxyConfig, load_config
from .metrics import build_registry
from .providers.anthropic import handle_messages as anthropic_messages
from .providers.openai import handle_chat_completions as openai_chat_completions
from .state import ProxyState

# ─── Endpoints ────────────────────────────────────────────────────────


async def healthz(_request: Request) -> Response:
    return JSONResponse(
        {"status": "ok", "version": __version__, "mode": "proxy"},
        status_code=200,
    )


async def readyz(request: Request) -> Response:
    """Readiness probe.

    Reports concrete component health rather than a binary "is up":
      - http_client:  set by lifespan; needed for any /v1/* call
      - budget_store: can read (sanity-check round-trip)
      - kill:         can read (sanity-check)
      - hitl_queue:   present when backend != 'none'; otherwise n/a

    200 if every component the proxy NEEDS is healthy. The proxy doesn't
    need hitl_queue (None when backend=='none' is valid), so that one is
    informational only.
    """
    state: ProxyState | None = getattr(request.app.state, "llm_leash", None)
    if state is None:
        return JSONResponse({"status": "starting"}, status_code=503)

    checks: dict[str, Any] = {}
    checks["http_client"] = state.http_client is not None

    # Budget store: read a sentinel session_id. Failure = store unreachable.
    try:
        await state.budget_store.get("_readyz_probe")
        checks["budget_store"] = True
    except Exception as exc:
        checks["budget_store"] = False
        checks["budget_store_error"] = str(exc)

    # Kill registry: same idea.
    try:
        await state.kill.is_killed("_readyz_probe")
        checks["kill_registry"] = True
    except Exception as exc:
        checks["kill_registry"] = False
        checks["kill_registry_error"] = str(exc)

    checks["hitl_backend"] = state.config.hitl.backend

    required_ok = (
        bool(checks["http_client"])
        and bool(checks["budget_store"])
        and bool(checks["kill_registry"])
    )
    body = {
        "status": "ready" if required_ok else "degraded",
        "version": __version__,
        "checks": checks,
    }
    return JSONResponse(body, status_code=200 if required_ok else 503)


async def root(_request: Request) -> Response:
    return JSONResponse({
        "service": "llm-leash-proxy",
        "version": __version__,
        "docs": "https://github.com/avelikiy/llm-leash/blob/main/docs/PROXY.md",
        "endpoints": [
            "/", "/healthz", "/readyz", "/metrics",
            "/v1/messages", "/v1/chat/completions",
            "/admin/kill/{session_id}", "/admin/hitl/pending",
            "/admin/hitl/{id}/approve", "/admin/hitl/{id}/reject",
            "/admin/tenant/{tenant}/pause", "/admin/stats",
        ],
    })


async def metrics(request: Request) -> Response:
    """Prometheus text-format metrics. Public — no auth required.

    Operators wanting to lock this down should expose it on a separate
    bind address behind a firewall, not via the proxy data port.
    """
    state: ProxyState = request.app.state.llm_leash
    body = state.metrics.registry.render() if state.metrics is not None else ""
    return Response(
        content=body,
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )


# ─── App factory ──────────────────────────────────────────────────────


HttpClientFactory = Callable[[], httpx.AsyncClient]


def _default_http_client_factory() -> httpx.AsyncClient:
    # Reasonable defaults: keepalive, modest timeouts (LLMs can be slow on
    # long generations — 120s read).
    timeout = httpx.Timeout(connect=5.0, read=120.0, write=10.0, pool=5.0)
    return httpx.AsyncClient(timeout=timeout, follow_redirects=False)


def build_app(
    config: ProxyConfig | None = None,
    *,
    http_client_factory: HttpClientFactory | None = None,
    state: ProxyState | None = None,
    **_options: Any,
) -> Starlette:
    """Construct the proxy ASGI app.

    ``config`` is the loaded ``ProxyConfig``. For tests, pass ``state``
    directly with a pre-built ``ProxyState`` (skips the lifespan setup
    of ``http_client`` — set it manually on the state object).

    ``http_client_factory`` lets tests inject a transport-mocked client.
    """
    cfg = config or ProxyConfig()
    final_state = state if state is not None else ProxyState.from_config(cfg)
    # Always wire metrics — fast, in-process, no external deps.
    if final_state.metrics is None:
        build_registry(final_state)

    factory = http_client_factory or _default_http_client_factory

    @asynccontextmanager
    async def lifespan(_app: Starlette) -> AsyncIterator[None]:
        if final_state.http_client is None:
            final_state.http_client = factory()
        try:
            yield
        finally:
            await final_state.aclose()

    routes = [
        Route("/", root, methods=["GET"]),
        Route("/healthz", healthz, methods=["GET"]),
        Route("/readyz", readyz, methods=["GET"]),
        Route("/metrics", metrics, methods=["GET"]),
        Route("/v1/messages", anthropic_messages, methods=["POST"]),
        Route("/v1/chat/completions", openai_chat_completions, methods=["POST"]),
        *admin_routes(),
    ]
    app = Starlette(routes=routes, lifespan=lifespan)
    app.state.llm_leash = final_state
    return app


# ─── CLI entry point ──────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> int:
    import uvicorn

    parser = argparse.ArgumentParser(
        prog="llm-leash-proxy",
        description="HTTP proxy that enforces budget, audit, kill switch, "
                    "and policy for LLM calls.",
    )
    parser.add_argument(
        "--config",
        default=None,
        help="Path to proxy.toml. CLI flags and env vars override file values.",
    )
    parser.add_argument(
        "--listen",
        default=None,
        help="HOST:PORT to bind (default: 127.0.0.1:8000). "
             "Overrides config file and LLM_LEASH_PROXY_LISTEN.",
    )
    parser.add_argument(
        "--audit-log",
        default=None,
        help="Path to write hash-chained audit JSONL.",
    )
    parser.add_argument(
        "--budget-usd",
        type=float,
        default=None,
        help="Default per-session hard cap in USD. Per-tenant caps set via TOML.",
    )
    parser.add_argument(
        "--log-level",
        default=None,
        choices=["debug", "info", "warning", "error", "critical"],
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"llm-leash-proxy {__version__}",
    )

    args = parser.parse_args(argv)
    config = load_config(args.config)

    # CLI flag overrides win over both TOML and env.
    if args.listen is not None:
        host, _, port_str = args.listen.partition(":")
        if not host or not port_str.isdigit():
            parser.error(f"--listen must be HOST:PORT, got: {args.listen}")
            return 2  # pragma: no cover
        config.listen_host = host
        config.listen_port = int(port_str)
    if args.audit_log is not None:
        config.audit_log = args.audit_log
    if args.budget_usd is not None:
        config.budget.default_cap_usd = args.budget_usd
    if args.log_level is not None:
        config.log_level = args.log_level

    app = build_app(config)
    uvicorn.run(
        app,
        host=config.listen_host,
        port=config.listen_port,
        log_level=config.log_level,
    )
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
