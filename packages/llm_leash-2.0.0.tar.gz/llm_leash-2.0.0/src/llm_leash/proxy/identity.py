"""Identity extraction for proxy requests.

Per ``docs/superpowers/plans/2026-05-16-llm-leash-v2.0-proxy.md`` §6:

  1. ``X-LLM-Leash-Session-Id`` header  → session_id
  2. ``X-LLM-Leash-Tenant-Id`` header   → tenant_id
  3. ``X-Forwarded-For`` (leftmost IP)  → session fallback for unauth flows
  4. ``Authorization: Bearer <key>``    → ``sha256(key)[:12]`` as session

The contract: every request gets a deterministic, non-PII session_id.
We never log raw keys, IPs, or tokens — only hashes.
"""
from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass

SESSION_HEADER = "x-llm-leash-session-id"
TENANT_HEADER = "x-llm-leash-tenant-id"
AGENT_HEADER = "x-llm-leash-agent-name"
AUTH_HEADER = "authorization"
FORWARDED_HEADER = "x-forwarded-for"


@dataclass(frozen=True)
class RequestIdentity:
    """Identity attributes attached to an inbound proxy request.

    ``source`` records *how* the session_id was derived so operators can
    triage when sessions collide unexpectedly (typically: someone shares
    an API key across two callers).

    ``agent_name`` identifies which agent in a multi-agent system made
    the call — e.g. "analyst" / "architect" / "devops" in a CrewAI or
    LangGraph deployment. Independent of session_id (one session can
    run many agents).
    """
    session_id: str
    tenant_id: str | None
    source: str  # "header" | "forwarded_for" | "auth_hash" | "anonymous"
    agent_name: str | None = None


def _hash_secret(value: str) -> str:
    """First 12 hex chars of sha256(value). Stable, non-reversible, short."""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]


def _normalise_headers(headers: Mapping[str, str]) -> dict[str, str]:
    return {k.lower(): v for k, v in headers.items()}


def extract_identity(headers: Mapping[str, str]) -> RequestIdentity:
    """Derive ``(session_id, tenant_id, source)`` from request headers.

    Falls through the precedence chain documented above. Returns an
    ``anonymous`` identity (hash of an empty string) only when literally
    no signal is present — operators should monitor this case via the
    ``llm_leash_requests_total{outcome="anonymous"}`` metric.
    """
    h = _normalise_headers(headers)

    explicit_session = h.get(SESSION_HEADER, "").strip()
    tenant = h.get(TENANT_HEADER, "").strip() or None
    agent = h.get(AGENT_HEADER, "").strip() or None

    if explicit_session:
        return RequestIdentity(
            session_id=explicit_session, tenant_id=tenant,
            source="header", agent_name=agent,
        )

    forwarded = h.get(FORWARDED_HEADER, "").strip()
    if forwarded:
        # X-Forwarded-For can be a chain "client, proxy1, proxy2"; the
        # leftmost is the original client.
        client_ip = forwarded.split(",")[0].strip()
        if client_ip:
            return RequestIdentity(
                session_id=f"ip-{_hash_secret(client_ip)}",
                tenant_id=tenant,
                source="forwarded_for",
                agent_name=agent,
            )

    auth = h.get(AUTH_HEADER, "").strip()
    if auth.lower().startswith("bearer "):
        token = auth[len("Bearer "):].strip()
        if token:
            return RequestIdentity(
                session_id=f"key-{_hash_secret(token)}",
                tenant_id=tenant,
                source="auth_hash",
                agent_name=agent,
            )

    return RequestIdentity(
        session_id="anonymous", tenant_id=tenant,
        source="anonymous", agent_name=agent,
    )


__all__ = [
    "AGENT_HEADER",
    "AUTH_HEADER",
    "FORWARDED_HEADER",
    "SESSION_HEADER",
    "TENANT_HEADER",
    "RequestIdentity",
    "extract_identity",
]
