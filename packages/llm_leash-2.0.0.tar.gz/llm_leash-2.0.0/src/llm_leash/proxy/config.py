"""Configuration for ``llm-leash-proxy``.

Source precedence (high to low):

  1. CLI flags (parsed by ``server.main``)
  2. Environment variables (``LLM_LEASH_PROXY_*``)
  3. ``proxy.toml`` config file (``--config``)
  4. Built-in defaults

This module provides the dataclass + parser. Wiring into the live app
factory lands in PR-3 onwards.
"""
from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ─── Defaults ─────────────────────────────────────────────────────────


DEFAULT_LISTEN_HOST = "127.0.0.1"
DEFAULT_LISTEN_PORT = 8000
DEFAULT_LOG_LEVEL = "info"
DEFAULT_AUDIT_LOG = "audit.jsonl"
DEFAULT_BUDGET_BACKEND = "inmemory"  # inmemory | sqlite | redis
DEFAULT_KILL_BACKEND = "inmemory"
DEFAULT_HITL_BACKEND = "none"  # opt-in: "inmemory" or "sqlite"
DEFAULT_HITL_TIMEOUT_SECS = 600.0


# ─── Dataclasses ──────────────────────────────────────────────────────


@dataclass
class BudgetConfig:
    backend: str = DEFAULT_BUDGET_BACKEND
    sqlite_path: str | None = None
    redis_url: str | None = None
    default_cap_usd: float | None = None
    per_tenant_caps: dict[str, float] = field(default_factory=dict)
    per_agent_caps: dict[str, float] = field(default_factory=dict)


@dataclass
class KillConfig:
    backend: str = DEFAULT_KILL_BACKEND
    sqlite_path: str | None = None
    redis_url: str | None = None
    http_url: str | None = None


@dataclass
class HitlConfig:
    backend: str = DEFAULT_HITL_BACKEND
    sqlite_path: str | None = None
    timeout_secs: float = DEFAULT_HITL_TIMEOUT_SECS


@dataclass
class PolicyConfig:
    rules_module: str | None = None  # dotted path; module exposes `rules = [...]`
    pii_redactor: bool = False       # when True, install PiiRedactor() globally


@dataclass
class ProxyConfig:
    listen_host: str = DEFAULT_LISTEN_HOST
    listen_port: int = DEFAULT_LISTEN_PORT
    log_level: str = DEFAULT_LOG_LEVEL
    audit_log: str = DEFAULT_AUDIT_LOG
    admin_token: str | None = None
    admin_listen_port: int | None = None  # bind admin on separate port if set

    budget: BudgetConfig = field(default_factory=BudgetConfig)
    kill: KillConfig = field(default_factory=KillConfig)
    hitl: HitlConfig = field(default_factory=HitlConfig)
    policy: PolicyConfig = field(default_factory=PolicyConfig)


# ─── Loaders ──────────────────────────────────────────────────────────


def _split_listen(value: str) -> tuple[str, int]:
    """Parse ``HOST:PORT``. Raises ValueError on malformed input."""
    host, _, port_str = value.partition(":")
    if not host or not port_str:
        raise ValueError(f"--listen must be HOST:PORT, got: {value!r}")
    try:
        port = int(port_str)
    except ValueError as exc:
        raise ValueError(f"port must be an integer, got: {port_str!r}") from exc
    if not (1 <= port <= 65535):
        raise ValueError(f"port must be in 1..65535, got: {port}")
    return host, port


def load_toml(path: str | Path) -> dict[str, Any]:
    """Read a proxy.toml file. Returns the raw dict (no validation)."""
    with open(path, "rb") as f:
        return tomllib.load(f)


def from_toml(data: dict[str, Any]) -> ProxyConfig:
    """Build a ProxyConfig from a parsed TOML dict.

    Unknown keys are ignored (forward-compat). Missing sections take
    the dataclass defaults.
    """
    cfg = ProxyConfig()

    if "listen" in data:
        cfg.listen_host, cfg.listen_port = _split_listen(str(data["listen"]))
    if "log_level" in data:
        cfg.log_level = str(data["log_level"])
    if "audit_log" in data:
        cfg.audit_log = str(data["audit_log"])
    if "admin_token" in data:
        cfg.admin_token = str(data["admin_token"])
    if "admin_listen_port" in data:
        cfg.admin_listen_port = int(data["admin_listen_port"])

    if (b := data.get("budget")) and isinstance(b, dict):
        cfg.budget = BudgetConfig(
            backend=str(b.get("backend", DEFAULT_BUDGET_BACKEND)),
            sqlite_path=b.get("sqlite_path"),
            redis_url=b.get("redis_url"),
            default_cap_usd=b.get("default_cap_usd"),
            per_tenant_caps=dict(b.get("per_tenant_caps") or {}),
            per_agent_caps=dict(b.get("per_agent_caps") or {}),
        )

    if (k := data.get("kill")) and isinstance(k, dict):
        cfg.kill = KillConfig(
            backend=str(k.get("backend", DEFAULT_KILL_BACKEND)),
            sqlite_path=k.get("sqlite_path"),
            redis_url=k.get("redis_url"),
            http_url=k.get("http_url"),
        )

    if (hi := data.get("hitl")) and isinstance(hi, dict):
        cfg.hitl = HitlConfig(
            backend=str(hi.get("backend", DEFAULT_HITL_BACKEND)),
            sqlite_path=hi.get("sqlite_path"),
            timeout_secs=float(hi.get("timeout_secs", DEFAULT_HITL_TIMEOUT_SECS)),
        )

    if (p := data.get("policy")) and isinstance(p, dict):
        cfg.policy = PolicyConfig(
            rules_module=p.get("rules_module"),
            pii_redactor=bool(p.get("pii_redactor", False)),
        )

    return cfg


_ENV_MAP = {
    "LLM_LEASH_PROXY_LISTEN": "listen",
    "LLM_LEASH_PROXY_LOG_LEVEL": "log_level",
    "LLM_LEASH_PROXY_AUDIT_LOG": "audit_log",
    "LLM_LEASH_PROXY_ADMIN_TOKEN": "admin_token",
    "LLM_LEASH_PROXY_BUDGET_CAP_USD": "budget_cap",
    "LLM_LEASH_PROXY_BUDGET_BACKEND": "budget_backend",
    "LLM_LEASH_PROXY_KILL_BACKEND": "kill_backend",
    "LLM_LEASH_PROXY_HITL_BACKEND": "hitl_backend",
    "LLM_LEASH_PROXY_REDIS_URL": "redis_url",
}


def overlay_env(cfg: ProxyConfig, env: dict[str, str] | None = None) -> ProxyConfig:
    """Apply ``LLM_LEASH_PROXY_*`` overrides on top of an existing config."""
    e = env if env is not None else dict(os.environ)
    if (v := e.get("LLM_LEASH_PROXY_LISTEN")):
        cfg.listen_host, cfg.listen_port = _split_listen(v)
    if (v := e.get("LLM_LEASH_PROXY_LOG_LEVEL")):
        cfg.log_level = v
    if (v := e.get("LLM_LEASH_PROXY_AUDIT_LOG")):
        cfg.audit_log = v
    if (v := e.get("LLM_LEASH_PROXY_ADMIN_TOKEN")):
        cfg.admin_token = v
    if (v := e.get("LLM_LEASH_PROXY_BUDGET_CAP_USD")):
        cfg.budget.default_cap_usd = float(v)
    if (v := e.get("LLM_LEASH_PROXY_BUDGET_BACKEND")):
        cfg.budget.backend = v
    if (v := e.get("LLM_LEASH_PROXY_KILL_BACKEND")):
        cfg.kill.backend = v
    if (v := e.get("LLM_LEASH_PROXY_HITL_BACKEND")):
        cfg.hitl.backend = v
    if (v := e.get("LLM_LEASH_PROXY_REDIS_URL")):
        # Shared default — any backend set to "redis" picks this up.
        cfg.budget.redis_url = cfg.budget.redis_url or v
        cfg.kill.redis_url = cfg.kill.redis_url or v
    return cfg


def load_config(
    config_path: str | Path | None = None,
    env: dict[str, str] | None = None,
) -> ProxyConfig:
    """Top-level loader. TOML file (if any) → env overlay → return.

    CLI flag overrides are applied separately by ``server.main`` after
    this returns, so they have final say.
    """
    if config_path is not None:
        cfg = from_toml(load_toml(config_path))
    else:
        cfg = ProxyConfig()
    return overlay_env(cfg, env)


__all__ = [
    "BudgetConfig",
    "HitlConfig",
    "KillConfig",
    "PolicyConfig",
    "ProxyConfig",
    "from_toml",
    "load_config",
    "load_toml",
    "overlay_env",
]
