"""Server-Sent Events (SSE) parser + provider-specific token accumulators.

Used by the streaming paths in providers/anthropic.py and openai.py to:
  - parse arbitrary chunk boundaries into well-formed SSE events
  - track cumulative token usage as deltas arrive
  - pass raw bytes through unchanged so the client receives the same
    SSE stream the upstream produced

We don't try to canonicalise events — every byte the upstream sends is
forwarded verbatim. The parser only inspects bytes we've buffered to
extract token counts; it never rewrites the wire format.

v2.0.0a2 scope: end-of-stream accounting only. Mid-stream cancellation
on hard-cap exceeded is a future enhancement — pre-call ``max_tokens``
estimate still refuses obvious runaway requests before they start.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field


@dataclass
class SSEEvent:
    """One parsed SSE event.

    ``data`` is the concatenated payload (SSE supports multiple
    ``data:`` lines per event; the spec joins them with newlines).
    ``event`` is the event type from ``event:`` lines (Anthropic uses
    these; OpenAI does not). Other field types (``id:``, ``retry:``)
    are kept as raw lines so we don't lose information.
    """
    event: str | None = None
    data: str = ""
    raw_lines: list[bytes] = field(default_factory=list)


class SSEParser:
    """Streaming SSE parser.

    Feed bytes via ``feed(chunk)`` and call ``drain()`` to get any
    complete events. Maintains an internal buffer that handles
    arbitrary chunk boundaries (a single SSE event can span multiple
    network reads, or one read can contain multiple events).
    """

    def __init__(self) -> None:
        self._buffer: bytes = b""

    def feed(self, chunk: bytes) -> list[SSEEvent]:
        """Append bytes to the buffer; return any complete events."""
        self._buffer += chunk
        events: list[SSEEvent] = []
        # SSE event delimiter: blank line (LF LF or CR LF CR LF).
        while True:
            sep_idx = self._find_event_boundary()
            if sep_idx < 0:
                break
            block = self._buffer[:sep_idx]
            # Advance past the delimiter. Handle both "\n\n" and "\r\n\r\n".
            if self._buffer[sep_idx : sep_idx + 4] == b"\r\n\r\n":
                self._buffer = self._buffer[sep_idx + 4 :]
            else:
                self._buffer = self._buffer[sep_idx + 2 :]
            event = self._parse_block(block)
            if event is not None:
                events.append(event)
        return events

    def drain(self) -> list[SSEEvent]:
        """Flush any trailing event without a terminating blank line.

        Real upstream servers always emit the blank line, but defensive
        callers may want to call this at end-of-stream to catch a
        malformed final event rather than silently dropping it.
        """
        if not self._buffer.strip():
            self._buffer = b""
            return []
        event = self._parse_block(self._buffer)
        self._buffer = b""
        return [event] if event is not None else []

    def _find_event_boundary(self) -> int:
        # Find the first blank-line separator.
        candidates = [self._buffer.find(b"\n\n"), self._buffer.find(b"\r\n\r\n")]
        candidates = [c for c in candidates if c >= 0]
        return min(candidates) if candidates else -1

    def _parse_block(self, block: bytes) -> SSEEvent | None:
        if not block.strip():
            return None
        ev = SSEEvent()
        data_lines: list[str] = []
        for raw_line in block.split(b"\n"):
            line = raw_line.rstrip(b"\r")
            if not line:
                continue
            if line.startswith(b":"):
                # SSE comment — preserve in raw_lines for forwarding.
                ev.raw_lines.append(raw_line)
                continue
            ev.raw_lines.append(raw_line)
            if b":" not in line:
                # Field with no value (allowed by spec; treat as ignored).
                continue
            field_name, _, field_value = line.partition(b":")
            # Optional single leading space in field value, per spec.
            if field_value.startswith(b" "):
                field_value = field_value[1:]
            try:
                value_str = field_value.decode("utf-8")
            except UnicodeDecodeError:
                value_str = field_value.decode("utf-8", errors="replace")
            field_name_str = field_name.decode("utf-8", errors="replace")
            if field_name_str == "event":
                ev.event = value_str
            elif field_name_str == "data":
                data_lines.append(value_str)
            # Other fields (id, retry) are kept in raw_lines but not
            # surfaced — accumulator doesn't need them.
        ev.data = "\n".join(data_lines)
        return ev


# ─── Token accumulators ───────────────────────────────────────────────


class _BaseAccumulator:
    """Common state: cumulative input + output tokens."""

    def __init__(self) -> None:
        self.input_tokens: int = 0
        self.output_tokens: int = 0
        self.finished: bool = False

    def feed_event(self, event: SSEEvent) -> None:
        raise NotImplementedError


class AnthropicTokenAccumulator(_BaseAccumulator):
    """Track tokens across an Anthropic streaming response.

    Anthropic emits:
      message_start  -> message.usage.input_tokens (final input count)
                                    .output_tokens (=1 placeholder)
      message_delta  -> usage.output_tokens (cumulative running total)
      message_stop   -> end of stream

    We take input_tokens from message_start (it never changes mid-stream)
    and output_tokens from the LAST message_delta we saw.
    """

    def feed_event(self, event: SSEEvent) -> None:
        if not event.data:
            return
        try:
            payload = json.loads(event.data)
        except json.JSONDecodeError:
            return
        if not isinstance(payload, dict):
            return
        kind = payload.get("type") or event.event
        if kind == "message_start":
            msg = payload.get("message") or {}
            usage = msg.get("usage") or {}
            if "input_tokens" in usage:
                self.input_tokens = int(usage["input_tokens"])
            # output_tokens here is just a placeholder (=1), ignore.
        elif kind == "message_delta":
            usage = payload.get("usage") or {}
            if "output_tokens" in usage:
                self.output_tokens = int(usage["output_tokens"])
        elif kind == "message_stop":
            self.finished = True


class OpenAITokenAccumulator(_BaseAccumulator):
    """Track tokens across an OpenAI streaming response.

    OpenAI emits chunks; authoritative token counts land in the final
    chunk only when the client includes ``stream_options.include_usage=true``.
    The proxy auto-injects that flag (see providers/openai.py) so we
    always get usage. Terminal sentinel is ``[DONE]``.

    For mid-stream cancellation (GA-2) we also maintain a rough running
    estimate ``approx_output_tokens`` derived from ``delta.content``
    character length (~4 chars per token, the GPT-family rule of thumb).
    This estimate is conservative — slightly higher than the real BPE
    count — so it triggers cancel ~early rather than ~late. Final
    accounting in ``output_tokens`` is replaced with the authoritative
    usage value when the final chunk arrives.
    """

    def __init__(self) -> None:
        super().__init__()
        self.approx_output_tokens: int = 0
        self._content_chars: int = 0

    def feed_event(self, event: SSEEvent) -> None:
        # OpenAI uses data-only frames; event field is unused.
        if not event.data:
            return
        if event.data.strip() == "[DONE]":
            self.finished = True
            return
        try:
            payload = json.loads(event.data)
        except json.JSONDecodeError:
            return
        if not isinstance(payload, dict):
            return
        # Running content-char count for mid-stream cap check.
        choices = payload.get("choices")
        if isinstance(choices, list):
            for choice in choices:
                if not isinstance(choice, dict):
                    continue
                delta = choice.get("delta") or {}
                content = delta.get("content") if isinstance(delta, dict) else None
                if isinstance(content, str):
                    self._content_chars += len(content)
        self.approx_output_tokens = max(1, self._content_chars // 4)
        usage = payload.get("usage")
        if isinstance(usage, dict):
            if "prompt_tokens" in usage:
                self.input_tokens = int(usage["prompt_tokens"])
            if "completion_tokens" in usage:
                self.output_tokens = int(usage["completion_tokens"])


__all__ = [
    "AnthropicTokenAccumulator",
    "OpenAITokenAccumulator",
    "SSEEvent",
    "SSEParser",
]
