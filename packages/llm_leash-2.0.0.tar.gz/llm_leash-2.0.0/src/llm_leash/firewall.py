"""Firewall facade — the single public class.

Composes BudgetTracker + AuditWriter + KillRegistry + PolicyEngine.
`wrap(client)` dispatches to the right adapter based on client shape.
"""
from __future__ import annotations

import uuid
from typing import Any

from .audit.writer import AuditWriter
from .budget.store import InMemoryStore
from .budget.tracker import BudgetTracker
from .hitl.gate import HitlGate
from .kill.registry import InProcessKillRegistry, KillRegistry
from .policy.engine import PolicyEngine
from .policy.pii import PiiRedactor
from .types import Rule


class _NoopAuditWriter:
    """Used when no audit_log path is configured."""
    def write(self, event: Any) -> Any:
        return event
    def close(self) -> None:
        pass


class Firewall:
    """One class. One construction. See API.md."""

    def __init__(
        self,
        *,
        budget_usd: float | None = None,
        budget_soft_usd: float | None = None,
        audit_log: str | None = None,
        kill_registry: KillRegistry | None = None,
        session_id: str | None = None,
        tenant_id: str | None = None,
        rules: list[Rule] | None = None,
        pii_redactor: PiiRedactor | None = None,
        hitl_gate: HitlGate | None = None,
    ) -> None:
        self._session_id = session_id or f"s_{uuid.uuid4().hex[:12]}"
        self._tenant_id = tenant_id

        self._budget = BudgetTracker(
            session_id=self._session_id,
            hard_cap_usd=budget_usd,
            soft_cap_usd=budget_soft_usd,
            store=InMemoryStore(),
        )
        self._audit: Any = (
            AuditWriter(audit_log, fsync=False) if audit_log else _NoopAuditWriter()
        )
        self._kill: KillRegistry = kill_registry or InProcessKillRegistry()
        self._engine = PolicyEngine(rules or [])
        self._pii_redactor = pii_redactor
        self._hitl_gate = hitl_gate

    # ── Properties ──────────────────────────────────────────────

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def tenant_id(self) -> str | None:
        return self._tenant_id

    async def cumulative_usd(self) -> float:
        return await self._budget.cumulative_usd()

    # ── Operations ──────────────────────────────────────────────

    def wrap(self, client: Any) -> Any:
        # Anthropic-shaped: client.messages.create
        if hasattr(client, "messages") and hasattr(client.messages, "create"):
            from .adapters.anthropic import AnthropicAdapter
            adapter: Any = AnthropicAdapter(
                session_id=self._session_id,
                budget=self._budget,
                audit=self._audit,
                kill=self._kill,
                tenant_id=self._tenant_id,
                engine=self._engine,
                pii_redactor=self._pii_redactor,
                hitl_gate=self._hitl_gate,
            )
            return adapter.wrap_client(client)

        # OpenAI-shaped: client.chat.completions.create
        if (hasattr(client, "chat") and hasattr(client.chat, "completions")
                and hasattr(client.chat.completions, "create")):
            from .adapters.openai import OpenAIAdapter
            oa: Any = OpenAIAdapter(
                session_id=self._session_id,
                budget=self._budget,
                audit=self._audit,
                kill=self._kill,
                tenant_id=self._tenant_id,
                engine=self._engine,
                pii_redactor=self._pii_redactor,
                hitl_gate=self._hitl_gate,
            )
            return oa.wrap_client(client)

        # LangChain / LangGraph chat-model-shaped: client.invoke(messages)
        if (hasattr(client, "invoke") and callable(client.invoke)
                and (hasattr(client, "model_name") or hasattr(client, "model"))):
            from .adapters.langgraph import LangChainAdapter
            lc: Any = LangChainAdapter(
                session_id=self._session_id,
                budget=self._budget,
                audit=self._audit,
                kill=self._kill,
                tenant_id=self._tenant_id,
                engine=self._engine,
                pii_redactor=self._pii_redactor,
                hitl_gate=self._hitl_gate,
            )
            return lc.wrap_client(client)

        # MCP ClientSession-shaped: client.call_tool(name, arguments)
        if hasattr(client, "call_tool") and callable(client.call_tool):
            from .adapters.mcp import MCPAdapter
            mcp: Any = MCPAdapter(
                session_id=self._session_id,
                audit=self._audit,
                kill=self._kill,
                tenant_id=self._tenant_id,
                engine=self._engine,
                pii_redactor=self._pii_redactor,
                hitl_gate=self._hitl_gate,
            )
            return mcp.wrap_client(client)

        # OpenHands LLM-shaped: client.completion(messages) (LiteLLM-style)
        if (hasattr(client, "completion") and callable(client.completion)
                and (hasattr(client, "model") or hasattr(client, "config"))):
            from .adapters.openhands import OpenHandsAdapter
            oh: Any = OpenHandsAdapter(
                session_id=self._session_id,
                budget=self._budget,
                audit=self._audit,
                kill=self._kill,
                tenant_id=self._tenant_id,
                engine=self._engine,
                pii_redactor=self._pii_redactor,
                hitl_gate=self._hitl_gate,
            )
            return oh.wrap_client(client)

        # Pydantic-AI Model-shaped: async client.request(messages) + .model_name|.model
        if (hasattr(client, "request") and callable(client.request)
                and (hasattr(client, "model_name") or hasattr(client, "model"))
                and not hasattr(client, "chat")):
            from .adapters.pydantic_ai import PydanticAIAdapter
            pa: Any = PydanticAIAdapter(
                session_id=self._session_id,
                budget=self._budget,
                audit=self._audit,
                kill=self._kill,
                tenant_id=self._tenant_id,
                engine=self._engine,
                pii_redactor=self._pii_redactor,
                hitl_gate=self._hitl_gate,
            )
            return pa.wrap_client(client)

        # CrewAI LLM-shaped: client.call(messages) + client.model
        if (hasattr(client, "call") and callable(client.call)
                and hasattr(client, "model")):
            from .adapters.crewai import CrewAIAdapter
            cr: Any = CrewAIAdapter(
                session_id=self._session_id,
                budget=self._budget,
                audit=self._audit,
                kill=self._kill,
                tenant_id=self._tenant_id,
                engine=self._engine,
                pii_redactor=self._pii_redactor,
                hitl_gate=self._hitl_gate,
            )
            return cr.wrap_client(client)

        # Unknown client — pass through unchanged.
        return client

    async def kill(self, reason: str) -> None:
        await self._kill.kill(self._session_id, reason=reason)

    async def aclose(self) -> None:
        if hasattr(self._audit, "close"):
            self._audit.close()


__all__ = ["Firewall"]
