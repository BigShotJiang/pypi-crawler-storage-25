"""llm-leash CLI.

Subcommands:
  verify <path>                        — verify the hash chain of an audit log
  replay <path>                        — pretty-print events as JSON lines
  export <path> --format csv|json      — export events to stdout (CSV or JSON)
  soc2 <path> --out DIR --period-start ISO --period-end ISO
                                       — generate a SOC 2 evidence pack
  hitl list   <queue.db>               — list pending HITL requests
  hitl approve <queue.db> <request_id> — approve a pending request
  hitl reject  <queue.db> <request_id> --reason TEXT — reject a pending request

Remote ops (against a running llm-leash-proxy):
  hitl list/approve/reject --proxy URL --admin-token T
                                       — operate against the proxy's admin API
  kill <session_id> --proxy URL --admin-token T [--reason TEXT]
                                       — mark a session killed
  status --proxy URL --admin-token T   — show active sessions + spend + pending HITL

Admin token can also come from $LLM_LEASH_ADMIN_TOKEN.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .audit.replay import export_csv, export_json, replay
from .audit.soc2 import generate_report
from .audit.verify import ChainBroken, verify_chain
from .hitl.queue import SQLiteHitlQueue

# ─── HTTP helpers for remote proxy admin API ─────────────────────────


def _admin_token(args: argparse.Namespace) -> str:
    token = getattr(args, "admin_token", None) or os.environ.get("LLM_LEASH_ADMIN_TOKEN")
    if not token:
        print(
            "error: --admin-token or $LLM_LEASH_ADMIN_TOKEN required for --proxy ops",
            file=sys.stderr,
        )
        sys.exit(2)
    return token


def _http_call(
    method: str,
    base_url: str,
    path: str,
    admin_token: str,
    body: dict[str, Any] | None = None,
    timeout: float = 10.0,
) -> tuple[int, dict[str, Any] | None]:
    url = f"{base_url.rstrip('/')}{path}"
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = Request(  # noqa: S310 (admin API, scheme controlled by operator)
        url, data=data, method=method,
        headers={
            "Authorization": f"Bearer {admin_token}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urlopen(req, timeout=timeout) as resp:  # noqa: S310
            status = resp.status
            raw = resp.read()
    except HTTPError as exc:
        status = exc.code
        raw = exc.read()
    except URLError as exc:
        print(f"error: cannot reach proxy at {base_url}: {exc}", file=sys.stderr)
        return 0, None
    try:
        return status, json.loads(raw) if raw else None
    except (json.JSONDecodeError, ValueError):
        return status, None


def _cmd_verify(args: argparse.Namespace) -> int:
    try:
        n = verify_chain(args.path)
    except ChainBroken as exc:
        print(f"BROKEN: {exc}", file=sys.stderr)
        return 2
    except FileNotFoundError:
        print(f"file not found: {args.path}", file=sys.stderr)
        return 1
    print(f"OK: {n} events verified")
    return 0


def _cmd_replay(args: argparse.Namespace) -> int:
    count = 0
    for ev in replay(args.path):
        sys.stdout.write(json.dumps(ev, ensure_ascii=False) + "\n")
        count += 1
    print(f"# replayed {count} events", file=sys.stderr)
    return 0


def _cmd_export(args: argparse.Namespace) -> int:
    if args.format == "csv":
        n = export_csv(args.path, sys.stdout)
    else:
        n = export_json(args.path, sys.stdout)
    print(f"# exported {n} events as {args.format}", file=sys.stderr)
    return 0


def _cmd_soc2(args: argparse.Namespace) -> int:
    report = generate_report(
        args.path, args.out,
        period_start=args.period_start,
        period_end=args.period_end,
        organization_name=args.org,
    )
    verdict = "VERIFIED" if report.integrity_ok else "BROKEN"
    print(
        f"SOC 2 pack generated → {report.output_dir}/  "
        f"({report.summary['total_events']} events; integrity: {verdict})",
        file=sys.stderr,
    )
    print(str(report.output_dir / "executive-summary.html"))
    return 0 if report.integrity_ok else 2


def _cmd_hitl(args: argparse.Namespace) -> int:
    # Remote path: operate against a running proxy via its admin API.
    if getattr(args, "proxy", None):
        token = _admin_token(args)
        if args.hitl_cmd == "list":
            status, body = _http_call("GET", args.proxy, "/admin/hitl/pending", token)
            if status != 200 or body is None:
                print(f"error: status={status} body={body}", file=sys.stderr)
                return 1
            for req in body.get("pending", []):
                sys.stdout.write(json.dumps(req, ensure_ascii=False) + "\n")
            print(f"# {len(body.get('pending', []))} pending "
                  f"({body.get('hitl_backend')})", file=sys.stderr)
            return 0
        if args.hitl_cmd == "approve":
            status, body = _http_call(
                "POST", args.proxy,
                f"/admin/hitl/{args.request_id}/approve", token,
            )
            if status != 200:
                print(f"error: status={status} body={body}", file=sys.stderr)
                return 1
            print(f"approved {args.request_id}")
            return 0
        if args.hitl_cmd == "reject":
            status, body = _http_call(
                "POST", args.proxy,
                f"/admin/hitl/{args.request_id}/reject", token,
                body={"reason": args.reason},
            )
            if status != 200:
                print(f"error: status={status} body={body}", file=sys.stderr)
                return 1
            print(f"rejected {args.request_id}: {args.reason}")
            return 0
        return 1

    # Local path: operate directly on the SQLite queue file.
    if not getattr(args, "queue_path", None):
        print("error: pass <queue.db> or --proxy URL", file=sys.stderr)
        return 2
    queue = SQLiteHitlQueue(args.queue_path)
    try:
        if args.hitl_cmd == "list":
            items = asyncio.run(queue.list_pending())
            for req in items:
                row = {
                    "request_id": req.request_id,
                    "created_ts": req.created_ts,
                    "session_id": req.session_id,
                    "tenant_id": req.tenant_id,
                    "tool": req.tool,
                    "rule_id": req.rule_id,
                    "reason": req.reason,
                }
                sys.stdout.write(json.dumps(row, ensure_ascii=False) + "\n")
            print(f"# {len(items)} pending", file=sys.stderr)
            return 0
        if args.hitl_cmd == "approve":
            asyncio.run(queue.approve(args.request_id))
            print(f"approved {args.request_id}")
            return 0
        if args.hitl_cmd == "reject":
            asyncio.run(queue.reject(args.request_id, reason=args.reason))
            print(f"rejected {args.request_id}: {args.reason}")
            return 0
        return 1
    finally:
        queue.close()


def _cmd_kill(args: argparse.Namespace) -> int:
    """Mark a session killed via the proxy's admin API."""
    token = _admin_token(args)
    reason = args.reason or "operator kill via CLI"
    status, body = _http_call(
        "POST", args.proxy, f"/admin/kill/{args.session_id}", token,
        body={"reason": reason},
    )
    if status != 200:
        print(f"error: status={status} body={body}", file=sys.stderr)
        return 1
    print(f"killed {args.session_id}: {reason}")
    return 0


def _cmd_status(args: argparse.Namespace) -> int:
    """Show aggregate proxy stats."""
    token = _admin_token(args)
    status, body = _http_call("GET", args.proxy, "/admin/stats", token)
    if status != 200 or body is None:
        print(f"error: status={status} body={body}", file=sys.stderr)
        return 1
    print(f"active sessions:    {body['active_sessions']}")
    print(f"total spend (USD):  ${body['total_spend_usd']:.4f}")
    print(f"HITL backend:       {body['hitl_backend']}  "
          f"({body['hitl_pending']} pending)")
    print(f"policy rules:       {body['policy_rules']}")
    print(f"PII redactor:       {'on' if body['pii_redactor_enabled'] else 'off'}")
    if body["top_sessions"]:
        print()
        print("Top spenders:")
        for row in body["top_sessions"][:10]:
            print(f"  {row['session_id']:<40} ${row['cost_usd']:.4f}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="llm-leash")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_verify = sub.add_parser("verify", help="Verify the hash chain of an audit log.")
    p_verify.add_argument("path", help="Path to audit.jsonl")

    p_replay = sub.add_parser("replay", help="Print events from an audit log as JSON lines.")
    p_replay.add_argument("path", help="Path to audit.jsonl")

    p_export = sub.add_parser("export", help="Export an audit log as CSV or JSON.")
    p_export.add_argument("path", help="Path to audit.jsonl")
    p_export.add_argument(
        "--format", choices=["csv", "json"], default="json",
        help="Output format (default: json).",
    )

    p_soc2 = sub.add_parser("soc2", help="Generate a SOC 2 evidence pack from an audit log.")
    p_soc2.add_argument("path", help="Path to audit.jsonl")
    p_soc2.add_argument("--out", required=True, help="Output directory for the evidence pack.")
    p_soc2.add_argument(
        "--period-start", required=True,
        help="Report period start (ISO 8601, e.g. 2026-04-01T00:00:00Z).",
    )
    p_soc2.add_argument(
        "--period-end", required=True,
        help="Report period end (ISO 8601).",
    )
    p_soc2.add_argument(
        "--org", default=None,
        help="Organization name (printed in the executive summary).",
    )

    p_hitl = sub.add_parser("hitl", help="Operator commands for the HITL queue.")
    hitl_sub = p_hitl.add_subparsers(dest="hitl_cmd", required=True)

    def _hitl_remote_args(p: argparse.ArgumentParser) -> None:
        # Either positional <queue_path> (local SQLite) OR --proxy URL (remote API).
        p.add_argument(
            "queue_path", nargs="?", default=None,
            help="Path to the SQLite HITL queue (omit if using --proxy).",
        )
        p.add_argument(
            "--proxy", default=None,
            help="URL of a running llm-leash-proxy (e.g. http://localhost:8000).",
        )
        p.add_argument(
            "--admin-token", default=None,
            help="Admin bearer token for --proxy. Defaults to $LLM_LEASH_ADMIN_TOKEN.",
        )

    p_hitl_list = hitl_sub.add_parser("list", help="List pending HITL requests.")
    _hitl_remote_args(p_hitl_list)
    p_hitl_app = hitl_sub.add_parser("approve", help="Approve a pending request.")
    _hitl_remote_args(p_hitl_app)
    p_hitl_app.add_argument("request_id")
    p_hitl_rej = hitl_sub.add_parser("reject", help="Reject a pending request.")
    _hitl_remote_args(p_hitl_rej)
    p_hitl_rej.add_argument("request_id")
    p_hitl_rej.add_argument("--reason", required=True, help="Why the request was rejected.")

    p_kill = sub.add_parser(
        "kill", help="Mark a session killed via a running proxy's admin API.",
    )
    p_kill.add_argument("session_id")
    p_kill.add_argument("--proxy", required=True, help="URL of running llm-leash-proxy.")
    p_kill.add_argument(
        "--admin-token", default=None,
        help="Admin bearer token. Defaults to $LLM_LEASH_ADMIN_TOKEN.",
    )
    p_kill.add_argument("--reason", default=None, help="Reason for the kill.")

    p_status = sub.add_parser(
        "status", help="Show proxy aggregate stats (sessions, spend, pending HITL).",
    )
    p_status.add_argument("--proxy", required=True, help="URL of running llm-leash-proxy.")
    p_status.add_argument(
        "--admin-token", default=None,
        help="Admin bearer token. Defaults to $LLM_LEASH_ADMIN_TOKEN.",
    )

    args = parser.parse_args(argv)
    if args.cmd == "verify":
        return _cmd_verify(args)
    if args.cmd == "replay":
        return _cmd_replay(args)
    if args.cmd == "export":
        return _cmd_export(args)
    if args.cmd == "soc2":
        return _cmd_soc2(args)
    if args.cmd == "hitl":
        return _cmd_hitl(args)
    if args.cmd == "kill":
        return _cmd_kill(args)
    if args.cmd == "status":
        return _cmd_status(args)
    return 1


if __name__ == "__main__":
    sys.exit(main())
