"""Shared types and exceptions. Public surface — see API.md."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Protocol, runtime_checkable

Action = Literal["allow", "block", "warn", "hitl"]


@dataclass(frozen=True)
class Decision:
    """Outcome of a single rule evaluation."""

    action: Action
    rule_id: str
    reason: str


@dataclass(frozen=True)
class ToolCall:
    """A single tool invocation passing through the firewall."""

    tool: str
    args: dict[str, Any]
    session_id: str
    tenant_id: str | None = None


@runtime_checkable
class Rule(Protocol):
    """A rule is any object with an `id` and an `evaluate()` method.

    `evaluate` returns a Decision to take effect, or `None` to abstain
    (the engine then tries the next rule). First non-None decision wins.
    """

    id: str

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None: ...


@dataclass
class PolicyContext:
    """Mutable context handed to each rule. Stays small on purpose."""

    cumulative_usd: float
    budget_cap_usd: float | None
    soft_cap_usd: float | None
    tenant_id: str | None


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class LeashBlocked(RuntimeError):
    """Base exception raised when the firewall intervenes.

    Catch this to handle all intervention modes uniformly.
    """

    def __init__(self, *, rule_id: str, reason: str):
        super().__init__(reason)
        self.rule_id = rule_id
        self.reason = reason


class LeashKilled(LeashBlocked):
    """Raised when the session was killed via the kill registry, or when
    the hard budget cap was exceeded."""


class LeashRejectedByHuman(LeashBlocked):
    """Raised when HITL approval timed out (default-deny) or was rejected."""


__all__ = [
    "Action",
    "Decision",
    "LeashBlocked",
    "LeashKilled",
    "LeashRejectedByHuman",
    "PolicyContext",
    "Rule",
    "ToolCall",
]
