"""BehavioralBaselineRule — learn normal traffic per agent, flag deviations.

Builds a running profile per ``(tenant_id, agent_name)``:
  - token count distribution (running mean + variance via Welford)
  - set of models the agent has ever used
  - count of how many times each tool was called
  - hour-of-day histogram (24 bins)

Once ``warmup_calls`` samples accumulated, every new call is compared
to the baseline. If any of these conditions triggers, the rule fires
with ``Decision(action=on_anomaly)``:

  - New model never seen before (when ``flag_new_models=True``)
  - Token count > baseline_mean + sigma_threshold * baseline_stddev
  - Off-hours call (when ``flag_off_hours=True`` with a configured
    business-hours window)

Two storage backends:
  - ``InMemoryBaselineStore`` — for tests / single-process apps
  - ``SQLiteBaselineStore``  — durable across restarts, multi-process safe

Both implement the ``BaselineStore`` Protocol.
"""
from __future__ import annotations

import asyncio
import json
import math
import sqlite3
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, Protocol, runtime_checkable

from ..types import Decision, PolicyContext, ToolCall

# ─── Profile data class ──────────────────────────────────────────────


@dataclass
class AgentProfile:
    """Running stats for one ``(tenant_id, agent_name)`` pair.

    Token stats use Welford's online algorithm:
      tokens_n      sample count
      tokens_mean   running mean
      tokens_m2     running second moment (variance = m2 / (n - 1))
    """
    tenant_id: str
    agent_name: str
    tokens_n: int = 0
    tokens_mean: float = 0.0
    tokens_m2: float = 0.0
    models_seen: set[str] = field(default_factory=set)
    tool_counts: dict[str, int] = field(default_factory=dict)
    hour_histogram: list[int] = field(default_factory=lambda: [0] * 24)

    @property
    def tokens_stddev(self) -> float:
        if self.tokens_n < 2:
            return 0.0
        variance = self.tokens_m2 / (self.tokens_n - 1)
        return math.sqrt(max(variance, 0.0))


# ─── BaselineStore protocol + implementations ────────────────────────


@runtime_checkable
class BaselineStore(Protocol):
    """Storage for ``AgentProfile`` keyed by (tenant_id, agent_name)."""

    async def get(
        self, tenant_id: str, agent_name: str,
    ) -> AgentProfile | None: ...

    async def save(self, profile: AgentProfile) -> None: ...


class InMemoryBaselineStore:
    """Dict-backed, asyncio-Lock guarded. Loses state on restart."""

    def __init__(self) -> None:
        self._profiles: dict[tuple[str, str], AgentProfile] = {}
        self._lock = asyncio.Lock()

    async def get(
        self, tenant_id: str, agent_name: str,
    ) -> AgentProfile | None:
        async with self._lock:
            existing = self._profiles.get((tenant_id, agent_name))
        if existing is None:
            return None
        # Return a shallow copy so callers can mutate without races.
        return AgentProfile(
            tenant_id=existing.tenant_id,
            agent_name=existing.agent_name,
            tokens_n=existing.tokens_n,
            tokens_mean=existing.tokens_mean,
            tokens_m2=existing.tokens_m2,
            models_seen=set(existing.models_seen),
            tool_counts=dict(existing.tool_counts),
            hour_histogram=list(existing.hour_histogram),
        )

    async def save(self, profile: AgentProfile) -> None:
        async with self._lock:
            self._profiles[(profile.tenant_id, profile.agent_name)] = profile


_SCHEMA = """
CREATE TABLE IF NOT EXISTS baseline_profiles (
    tenant_id     TEXT NOT NULL,
    agent_name    TEXT NOT NULL,
    tokens_n      INTEGER NOT NULL DEFAULT 0,
    tokens_mean   REAL NOT NULL DEFAULT 0.0,
    tokens_m2     REAL NOT NULL DEFAULT 0.0,
    models_json   TEXT NOT NULL DEFAULT '[]',
    tools_json    TEXT NOT NULL DEFAULT '{}',
    hours_json    TEXT NOT NULL DEFAULT '[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
    PRIMARY KEY (tenant_id, agent_name)
)
"""


class SQLiteBaselineStore:
    """File-backed BaselineStore. Safe for multiple readers / writers."""

    def __init__(self, path: str) -> None:
        self._path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(_SCHEMA)

    def _row_to_profile(
        self, row: tuple[Any, ...], tenant_id: str, agent_name: str,
    ) -> AgentProfile:
        return AgentProfile(
            tenant_id=tenant_id,
            agent_name=agent_name,
            tokens_n=int(row[0]),
            tokens_mean=float(row[1]),
            tokens_m2=float(row[2]),
            models_seen=set(json.loads(row[3])),
            tool_counts=dict(json.loads(row[4])),
            hour_histogram=list(json.loads(row[5])),
        )

    def _sync_get(self, tenant_id: str, agent_name: str) -> AgentProfile | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT tokens_n, tokens_mean, tokens_m2, models_json, "
                "tools_json, hours_json FROM baseline_profiles "
                "WHERE tenant_id = ? AND agent_name = ?",
                (tenant_id, agent_name),
            ).fetchone()
        if row is None:
            return None
        return self._row_to_profile(row, tenant_id, agent_name)

    def _sync_save(self, profile: AgentProfile) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO baseline_profiles "
                "(tenant_id, agent_name, tokens_n, tokens_mean, tokens_m2, "
                " models_json, tools_json, hours_json) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(tenant_id, agent_name) DO UPDATE SET "
                "  tokens_n = excluded.tokens_n, "
                "  tokens_mean = excluded.tokens_mean, "
                "  tokens_m2 = excluded.tokens_m2, "
                "  models_json = excluded.models_json, "
                "  tools_json = excluded.tools_json, "
                "  hours_json = excluded.hours_json",
                (
                    profile.tenant_id, profile.agent_name,
                    profile.tokens_n, profile.tokens_mean, profile.tokens_m2,
                    json.dumps(sorted(profile.models_seen)),
                    json.dumps(profile.tool_counts),
                    json.dumps(profile.hour_histogram),
                ),
            )

    async def get(
        self, tenant_id: str, agent_name: str,
    ) -> AgentProfile | None:
        return await asyncio.to_thread(self._sync_get, tenant_id, agent_name)

    async def save(self, profile: AgentProfile) -> None:
        await asyncio.to_thread(self._sync_save, profile)

    def close(self) -> None:
        with self._lock:
            self._conn.close()


# ─── Welford update ──────────────────────────────────────────────────


def _update_token_stats(profile: AgentProfile, value: float) -> None:
    """In-place Welford update for the token-count running statistics."""
    profile.tokens_n += 1
    n = profile.tokens_n
    delta = value - profile.tokens_mean
    profile.tokens_mean += delta / n
    delta2 = value - profile.tokens_mean
    profile.tokens_m2 += delta * delta2


# ─── BehavioralBaselineRule ──────────────────────────────────────────


class BehavioralBaselineRule:
    """Detect deviations from learned per-agent behaviour.

    The rule is **stateful**: every evaluated call updates the agent's
    profile in the backing store. During the warmup window
    (``warmup_calls`` per agent), it only observes — no decisions fire.

    After warmup:
      - New model never seen before               (if ``flag_new_models``)
      - Tokens > mean + ``sigma_threshold`` * sigma   (always)
      - Tool spam: tool used > ``tool_spam_threshold`` times in profile
      - Off-hours call                            (if ``flag_off_hours``)

    On a hit, returns ``Decision(action=on_anomaly)`` (default ``hitl``).

    Calls without an ``agent_name`` in the ToolCall args are ignored —
    pair this rule with the ``X-LLM-Leash-Agent-Name`` header on the
    proxy or set ``agent_name`` in your in-process audit events.

    The rule is **synchronous** (Rule protocol requires it) and uses
    ``asyncio.run`` to bridge to the async store when called from sync
    contexts. In proxy mode (already inside an event loop) it runs the
    store coroutines on a worker thread to avoid nested-loop errors.
    """

    id = "behavioural_baseline"

    def __init__(
        self,
        store: BaselineStore,
        *,
        warmup_calls: int = 50,
        sigma_threshold: float = 3.0,
        flag_new_models: bool = True,
        flag_off_hours: bool = False,
        business_hours: tuple[int, int] = (9, 18),
        tool_spam_threshold: int = 1000,
        on_anomaly: Literal["block", "hitl", "warn"] = "hitl",
        rule_id: str = "behavioural_baseline",
        clock: Any = None,
    ) -> None:
        if on_anomaly not in ("block", "hitl", "warn"):
            raise ValueError(
                f"on_anomaly must be 'block', 'hitl', or 'warn'; got {on_anomaly!r}",
            )
        if sigma_threshold <= 0:
            raise ValueError("sigma_threshold must be > 0")
        if warmup_calls < 1:
            raise ValueError("warmup_calls must be >= 1")
        bh_start, bh_end = business_hours
        if not (0 <= bh_start < bh_end <= 24):
            raise ValueError(
                "business_hours must be (start, end) with 0 <= start < end <= 24",
            )

        self.id = rule_id
        self._store = store
        self._warmup = warmup_calls
        self._sigma = sigma_threshold
        self._flag_new_models = flag_new_models
        self._flag_off_hours = flag_off_hours
        self._business_hours = business_hours
        self._tool_spam = tool_spam_threshold
        self._on_anomaly: Literal["block", "hitl", "warn"] = on_anomaly
        self._clock = clock if clock is not None else datetime.utcnow

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        agent_name = self._agent_of(call)
        if not agent_name:
            return None  # no agent_name → can't profile

        tenant_id = call.tenant_id or "_anon"
        tokens_estimate = self._tokens_estimate(call)
        model = self._model_of(call)
        tool = call.tool
        hour = self._clock().hour

        profile = self._sync_get(tenant_id, agent_name) or AgentProfile(
            tenant_id=tenant_id, agent_name=agent_name,
        )

        # Compute anomalies BEFORE mutating the profile, so we measure
        # against the prior baseline.
        anomalies: list[str] = []
        if profile.tokens_n >= self._warmup:
            # Token spike check.
            if profile.tokens_stddev > 0:
                if tokens_estimate > profile.tokens_mean + self._sigma * profile.tokens_stddev:
                    anomalies.append(
                        f"token_spike: {tokens_estimate} > mean {profile.tokens_mean:.0f} "
                        f"+ {self._sigma}sigma {profile.tokens_stddev:.0f}",
                    )
            # New-model check.
            if (
                self._flag_new_models
                and model
                and model not in profile.models_seen
            ):
                anomalies.append(f"new_model: {model!r} never seen before")
            # Off-hours check.
            if self._flag_off_hours:
                start, end = self._business_hours
                if not (start <= hour < end):
                    anomalies.append(
                        f"off_hours: call at {hour}:00 outside business "
                        f"hours {start}-{end}",
                    )
            # Tool-spam check (cumulative — fires once the agent crosses
            # the threshold for that tool).
            prior = profile.tool_counts.get(tool, 0)
            if prior >= self._tool_spam:
                anomalies.append(
                    f"tool_spam: {tool!r} used {prior + 1} times by {agent_name!r}",
                )

        # Update the profile regardless of anomaly outcome — learn from
        # both normal and anomalous traffic, even when we fire (operators
        # who approve via HITL effectively bless the new pattern; future
        # work could exclude unapproved-anomalies from baseline).
        _update_token_stats(profile, float(tokens_estimate))
        if model:
            profile.models_seen.add(model)
        profile.tool_counts[tool] = profile.tool_counts.get(tool, 0) + 1
        profile.hour_histogram[hour] = profile.hour_histogram[hour] + 1
        self._sync_save(profile)

        if not anomalies:
            return None
        return Decision(
            action=self._on_anomaly,
            rule_id=self.id,
            reason=f"behavioural baseline: {'; '.join(anomalies)}",
        )

    # ── helpers ─────────────────────────────────────────────────

    def _agent_of(self, call: ToolCall) -> str | None:
        """Look up agent_name from ToolCall args. The proxy sets this
        when ``X-LLM-Leash-Agent-Name`` header is present."""
        # First, args may have an explicit "agent_name" key.
        explicit = call.args.get("agent_name")
        if isinstance(explicit, str) and explicit:
            return explicit
        return None

    def _model_of(self, call: ToolCall) -> str:
        m = call.args.get("model")
        return str(m) if isinstance(m, str) else ""

    def _tokens_estimate(self, call: ToolCall) -> int:
        """Pre-call estimate: ``max_tokens`` if present, else len(messages)/4 chars."""
        max_tokens = call.args.get("max_tokens")
        if isinstance(max_tokens, int):
            return max_tokens
        messages = call.args.get("messages") or []
        if isinstance(messages, list):
            char_count = 0
            for m in messages:
                if isinstance(m, dict):
                    c = m.get("content")
                    if isinstance(c, str):
                        char_count += len(c)
            return char_count // 4
        return 0

    def _sync_get(self, tenant_id: str, agent_name: str) -> AgentProfile | None:
        result = _run_sync(self._store.get(tenant_id, agent_name))
        if result is None:
            return None
        assert isinstance(result, AgentProfile)
        return result

    def _sync_save(self, profile: AgentProfile) -> None:
        _run_sync(self._store.save(profile))


def _run_sync(coro: Any) -> Any:
    """Run an async coroutine from sync context.

    If we're inside an event loop, dispatch to a worker thread (same
    pattern as the in-process adapters). Otherwise use asyncio.run.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    result: dict[str, Any] = {}

    def _runner() -> None:
        try:
            result["value"] = asyncio.run(coro)
        except BaseException as exc:
            result["error"] = exc

    t = threading.Thread(target=_runner, daemon=True)
    t.start()
    t.join()
    if "error" in result:
        raise result["error"]
    return result.get("value")


__all__ = [
    "AgentProfile",
    "BaselineStore",
    "BehavioralBaselineRule",
    "InMemoryBaselineStore",
    "SQLiteBaselineStore",
]
