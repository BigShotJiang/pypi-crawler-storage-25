"""Built-in Rule implementations."""
from __future__ import annotations

import re
from typing import Any, Literal

from ..types import Decision, LeashBlocked, PolicyContext, ToolCall


def _iter_strings(value: Any) -> list[str]:
    """Recursively yield all string leaves from a dict/list/str."""
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        result: list[str] = []
        for v in value.values():
            result.extend(_iter_strings(v))
        return result
    if isinstance(value, list):
        result = []
        for v in value:
            result.extend(_iter_strings(v))
        return result
    return []


class BlockedPatterns:
    """Block calls whose args contain any of the given regex patterns."""

    def __init__(
        self,
        patterns: list[str],
        *,
        rule_id: str = "blocked_patterns",
    ) -> None:
        self.id = rule_id
        self._compiled = [re.compile(p, re.IGNORECASE) for p in patterns]

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        for text in _iter_strings(call.args):
            for pattern in self._compiled:
                if pattern.search(text):
                    raise LeashBlocked(
                        rule_id=self.id,
                        reason=f"arg matched blocked pattern /{pattern.pattern}/",
                    )
        return None


class BudgetThreshold:
    """Warn (not block) when cumulative spend exceeds threshold_pct of cap."""

    def __init__(
        self,
        threshold_pct: float = 0.9,
        *,
        rule_id: str = "budget_threshold",
    ) -> None:
        self.id = rule_id
        self._threshold_pct = threshold_pct

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        if ctx.budget_cap_usd is None:
            return None
        ratio = ctx.cumulative_usd / ctx.budget_cap_usd
        if ratio >= self._threshold_pct:
            pct = int(self._threshold_pct * 100)
            return Decision(
                action="warn",
                rule_id=self.id,
                reason=f"budget at {ratio * 100:.1f}% of cap "
                       f"(threshold {pct}%): ${ctx.cumulative_usd:.4f} / ${ctx.budget_cap_usd:.4f}",
            )
        return None


class HitlThreshold:
    """Trigger HITL review when cumulative spend exceeds threshold_pct of cap.

    Returns Decision(action="hitl"). Does NOT block. Requires hitl_gate= on Firewall.
    """

    def __init__(
        self,
        threshold_pct: float = 0.8,
        *,
        rule_id: str = "hitl_threshold",
    ) -> None:
        self.id = rule_id
        self._threshold_pct = threshold_pct

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        if ctx.budget_cap_usd is None:
            return None
        ratio = ctx.cumulative_usd / ctx.budget_cap_usd
        if ratio >= self._threshold_pct:
            pct = int(self._threshold_pct * 100)
            return Decision(
                action="hitl",
                rule_id=self.id,
                reason=f"budget at {ratio * 100:.1f}% of cap "
                       f"(threshold {pct}%): ${ctx.cumulative_usd:.4f} / ${ctx.budget_cap_usd:.4f}",
            )
        return None


_COMMENT_LINE = re.compile(r"--[^\n]*")
_COMMENT_BLOCK = re.compile(r"/\*.*?\*/", re.DOTALL)
_FIRST_TOKEN = re.compile(r"[A-Za-z_]\w*")

_READ_ONLY_ALLOW = frozenset(["SELECT", "WITH", "SHOW", "DESCRIBE", "DESC", "EXPLAIN"])

_DDL_DENY = frozenset([
    "DROP", "CREATE", "ALTER", "TRUNCATE", "RENAME",
    "COMMENT", "GRANT", "REVOKE",
])


def _first_sql_token(text: str) -> str:
    """Strip comments and return the uppercased first keyword."""
    text = _COMMENT_LINE.sub("", text)
    text = _COMMENT_BLOCK.sub("", text)
    m = _FIRST_TOKEN.search(text)
    return m.group(0).upper() if m else ""


def _iter_sql_fields(value: Any) -> list[str]:
    """Recursively yield all 'sql' field values from a dict/list."""
    if isinstance(value, str):
        return []
    if isinstance(value, dict):
        result: list[str] = []
        for k, v in value.items():
            if k == "sql" and isinstance(v, str):
                result.append(v)
            else:
                result.extend(_iter_sql_fields(v))
        return result
    if isinstance(value, list):
        result = []
        for v in value:
            result.extend(_iter_sql_fields(v))
        return result
    return []


class BlockedSql:
    """Block SQL statements that are not read-safe.

    mode="read_only"  — only SELECT / WITH / SHOW / DESCRIBE / EXPLAIN pass
    mode="no_ddl"     — DML (INSERT/UPDATE/DELETE) passes; DDL is blocked
    """

    def __init__(
        self,
        mode: Literal["read_only", "no_ddl"] = "read_only",
        *,
        extra_deny: list[str] | None = None,
        rule_id: str = "blocked_sql",
    ) -> None:
        self.id = rule_id
        self._mode = mode
        self._extra: frozenset[str] = frozenset(
            kw.upper() for kw in (extra_deny or [])
        )

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        for text in _iter_sql_fields(call.args):
            token = _first_sql_token(text)
            if not token:
                continue
            if self._is_denied(token):
                raise LeashBlocked(
                    rule_id=self.id,
                    reason=f"SQL statement '{token}' is not permitted "
                           f"(mode={self._mode!r})",
                )
        return None

    def _is_denied(self, token: str) -> bool:
        if token in self._extra:
            return True
        if self._mode == "read_only":
            return token not in _READ_ONLY_ALLOW
        return token in _DDL_DENY


_SHELL_DENY_DEFAULTS: list[str] = [
    r"rm\s+(-[a-zA-Z]*[rf][a-zA-Z]*\s|--recursive|--force)",
    r"(curl|wget)\s+[^\|]+\|\s*(ba?sh|sh|zsh|fish|dash)",
    r"\bdd\s+[^\n]*\bof=",
    r"\bmkfs\b",
    r":\s*\(\s*\)\s*\{[^}]*:\|:",
    r">\s*/dev/(sd[a-z]|nvme\d|hd[a-z])",
    r"\b(shutdown|reboot|halt|poweroff)(\s|$)",
    r"\bsudo\s+(rm|chmod|dd|mkfs|shutdown|reboot|halt)\b",
    r"\b(eval|exec)\s+.*(\$\(|`[^`]*`)",
    r"\bchmod\s+[0-7]*[2367][0-7]{2}\b",
]


class BlockedShell:
    """Block dangerous shell commands using a curated regex deny-list.

    Defaults cover rm -rf, curl|bash, dd disk writes, fork bombs,
    shutdown/reboot, sudo+destructive, and eval with command substitution.

    Pass extra_patterns to extend (not replace) the default set.
    """

    def __init__(
        self,
        *,
        extra_patterns: list[str] | None = None,
        rule_id: str = "blocked_shell",
    ) -> None:
        self.id = rule_id
        patterns = _SHELL_DENY_DEFAULTS + (extra_patterns or [])
        self._compiled = [
            re.compile(p, re.IGNORECASE | re.DOTALL) for p in patterns
        ]

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        for text in _iter_strings(call.args):
            for pattern in self._compiled:
                if pattern.search(text):
                    raise LeashBlocked(
                        rule_id=self.id,
                        reason=f"shell command matched dangerous pattern "
                               f"/{pattern.pattern}/",
                    )
        return None


__all__ = ["BlockedPatterns", "BlockedShell", "BlockedSql", "BudgetThreshold", "HitlThreshold"]
