"""SecretsRule — detect API keys / passwords / private keys / JWT in args.

Built-in detection uses regex + Shannon entropy — zero deps, works
out of the box. Covers the most common credential shapes:

  - AWS access key id           AKIA + 16 alnum
  - AWS secret access key       40-char base64
  - GitHub Personal Access Token  ghp_ / gho_ / ghu_ / ghs_ / ghr_
  - Stripe live/test key        sk_live_… / sk_test_…
  - OpenAI / Anthropic key      sk-…
  - PEM private key             -----BEGIN ... PRIVATE KEY-----
  - JWT                         3 base64url segments joined by '.'
  - Slack bot/user token        xoxb-… / xoxp-… / xoxa-… / xoxr-…
  - Generic high-entropy        Shannon entropy >= 4.5 on ≥ 20-char alnum

Three action modes:
  - "block":   raise LeashBlocked (engine surfaces as 403 in proxy)
  - "hitl":    return Decision(action="hitl") — route through gate
  - "redact":  mutate args in place to replace each secret with
               "[REDACTED:KIND]"; return None so the call proceeds

In redact mode the rule SIDE-EFFECTS the args dict: any caller holding
a reference to ``call.args`` or nested mutable values sees the
replacement. This matches the behaviour of ``PiiRedactor`` and lets
the proxy / adapter forward the redacted body without extra plumbing.
"""
from __future__ import annotations

import math
import re
from collections.abc import Iterator
from typing import Any, Literal

from ..types import Decision, LeashBlocked, PolicyContext, ToolCall

# ─── Detectors (regex + entropy helpers) ──────────────────────────────


_AWS_ACCESS_KEY = re.compile(r"\b(AKIA|ASIA|AGPA|AIDA|AROA|ANPA|ANVA|ASCA|APKA)[A-Z0-9]{16}\b")
_AWS_SECRET_KEY = re.compile(r"\b[A-Za-z0-9/+=]{40}\b")
_GITHUB_PAT = re.compile(r"\bgh[opusr]_[A-Za-z0-9]{36,255}\b")
_STRIPE_KEY = re.compile(r"\bsk_(?:live|test)_[A-Za-z0-9]{16,99}\b")
_GENERIC_SK_KEY = re.compile(r"\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}\b")
_SLACK_TOKEN = re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b")
_PEM_PRIVATE_KEY = re.compile(
    r"-----BEGIN (?:RSA |DSA |EC |OPENSSH |ENCRYPTED |PGP )?PRIVATE KEY-----"
    r".*?"
    r"-----END (?:RSA |DSA |EC |OPENSSH |ENCRYPTED |PGP )?PRIVATE KEY-----",
    re.DOTALL,
)
_JWT = re.compile(r"\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b")

# Generic high-entropy: long alnum/symbol strings (broader catch).
_GENERIC_HIGH_ENTROPY = re.compile(r"\b[A-Za-z0-9+/=_-]{20,}\b")


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts: dict[str, int] = {}
    for ch in s:
        counts[ch] = counts.get(ch, 0) + 1
    total = len(s)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


# Returned by detectors: (kind, matched_text).
_Finding = tuple[str, str]


def _scan(text: str, *, entropy_threshold: float = 4.5) -> Iterator[_Finding]:
    """Yield (kind, matched_substring) pairs for each detected secret.

    Specific detectors run first (high precision). Generic high-entropy
    runs last and only on remaining text — if a substring already matched
    a specific detector we don't re-flag it as ``high_entropy``.
    """
    already_matched: list[tuple[int, int]] = []

    def _overlaps(start: int, end: int) -> bool:
        return any(not (end <= s or start >= e) for s, e in already_matched)

    for kind, pattern in [
        ("aws_access_key", _AWS_ACCESS_KEY),
        ("github_pat", _GITHUB_PAT),
        ("stripe_key", _STRIPE_KEY),
        ("api_key", _GENERIC_SK_KEY),
        ("slack_token", _SLACK_TOKEN),
        ("jwt", _JWT),
        ("private_key", _PEM_PRIVATE_KEY),
    ]:
        for m in pattern.finditer(text):
            already_matched.append(m.span())
            yield kind, m.group(0)

    # AWS secret key — 40-char base64 is too broad on its own. Only flag
    # when entropy is high (real secrets are ~5.0+).
    for m in _AWS_SECRET_KEY.finditer(text):
        if _overlaps(*m.span()):
            continue
        if _shannon_entropy(m.group(0)) >= 4.5:
            already_matched.append(m.span())
            yield "aws_secret_key", m.group(0)

    # Generic high-entropy fallback.
    for m in _GENERIC_HIGH_ENTROPY.finditer(text):
        if _overlaps(*m.span()):
            continue
        candidate = m.group(0)
        if _shannon_entropy(candidate) >= entropy_threshold:
            yield "high_entropy_string", candidate


def _walk_strings(value: Any) -> Iterator[tuple[str, Any, Any]]:
    """Yield (string_value, parent, key) for every string in a nested structure.

    Lets callers REPLACE strings in place via ``parent[key] = new_value``.
    Parent is either a dict (key is a hashable) or a list (key is an int).
    """
    if isinstance(value, dict):
        for k, v in list(value.items()):
            if isinstance(v, str):
                yield v, value, k
            else:
                yield from _walk_strings(v)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            if isinstance(v, str):
                yield v, value, i
            else:
                yield from _walk_strings(v)


# ─── SecretsRule ──────────────────────────────────────────────────────


class SecretsRule:
    """Detect secrets in outgoing args; block / redact / route to HITL.

    Example:
        from llm_leash import Firewall, SecretsRule

        fw = Firewall(rules=[SecretsRule(action="redact")])
        # An AWS key inside any string in the messages will be replaced
        # with "[REDACTED:AWS_ACCESS_KEY]" before reaching the LLM.

    Parameters:
        action: "block" | "redact" | "hitl"
        entropy_threshold: minimum Shannon entropy for the generic
            high-entropy detector. Default 4.5. Lower = more findings
            (and more false positives).
        detectors: subset of detector kinds to enable. None = all.
            Possible kinds: "aws_access_key", "aws_secret_key",
            "github_pat", "stripe_key", "api_key", "slack_token", "jwt",
            "private_key", "high_entropy_string".
        rule_id: identifier emitted in Decision / audit events.
    """

    def __init__(
        self,
        *,
        action: Literal["block", "redact", "hitl"] = "redact",
        entropy_threshold: float = 4.5,
        detectors: list[str] | None = None,
        rule_id: str = "secrets",
    ) -> None:
        if action not in ("block", "redact", "hitl"):
            raise ValueError(
                f"SecretsRule action must be 'block', 'redact', or 'hitl'; "
                f"got {action!r}"
            )
        self.id = rule_id
        self._action: Literal["block", "redact", "hitl"] = action
        self._entropy_threshold = entropy_threshold
        self._detectors = set(detectors) if detectors is not None else None
        # Tracks detections from the most recent evaluate() call, so the
        # proxy / adapter can emit a SecretsDetected audit event.
        self.last_findings: list[tuple[str, str]] = []

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        findings: list[tuple[str, str, list[Any], Any]] = []  # (kind, text, parent, key)

        for text, parent, key in _walk_strings(call.args):
            for kind, matched in _scan(text, entropy_threshold=self._entropy_threshold):
                if self._detectors is not None and kind not in self._detectors:
                    continue
                findings.append((kind, matched, parent, key))

        self.last_findings = [(k, m) for k, m, _, _ in findings]

        if not findings:
            return None

        if self._action == "block":
            kinds = sorted({k for k, _, _, _ in findings})
            raise LeashBlocked(
                rule_id=self.id,
                reason=f"secrets detected: {', '.join(kinds)}",
            )

        if self._action == "hitl":
            kinds = sorted({k for k, _, _, _ in findings})
            return Decision(
                action="hitl",
                rule_id=self.id,
                reason=f"secrets detected, awaiting human approval: {', '.join(kinds)}",
            )

        # action == "redact": mutate strings in place.
        # Group by (parent, key) so each string is rewritten once.
        by_target: dict[tuple[int, Any], list[tuple[str, str]]] = {}
        for kind, matched, parent, key in findings:
            by_target.setdefault((id(parent), key), []).append((kind, matched))
            # Stash parent on lookup table so we can find it again
        # Re-walk; this time we know which (parent, key) needs rewriting.
        targets: dict[tuple[int, Any], tuple[list[Any], Any]] = {}
        for _k, _m, parent, key in findings:
            targets[(id(parent), key)] = (parent, key)

        for (_pid, _key), (parent, key) in targets.items():
            original = parent[key]
            new = original
            for kind, matched in by_target[(_pid, _key)]:
                new = new.replace(matched, f"[REDACTED:{kind.upper()}]")
            parent[key] = new

        return None


__all__ = ["SecretsRule"]
