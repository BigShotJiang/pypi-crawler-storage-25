"""Rule wrappers for external scanners (LlamaFirewall, Presidio).

These are thin adapters that turn an external scanner's output into a
`Decision`. Both scanners are duck-typed: nothing is imported at module
level, so installing `llm-leash` does not pull in heavy dependencies.

Install separately when you need them:
    pip install llm-leash[external-scanners]

Or pass in any object that matches the protocol — we never type-check
against the upstream classes.
"""
from __future__ import annotations

from typing import Any, Protocol

from ..types import Decision, PolicyContext, ToolCall


def _flatten_text(args: dict[str, Any]) -> str:
    """Concatenate every string-ish value in `args` into one blob.

    The scanners expect plain text, not a structured payload.
    """
    parts: list[str] = []

    def _walk(x: Any) -> None:
        if isinstance(x, str):
            parts.append(x)
        elif isinstance(x, dict):
            for v in x.values():
                _walk(v)
        elif isinstance(x, list | tuple):
            for v in x:
                _walk(v)

    _walk(args)
    return "\n".join(parts)


# ─── LlamaFirewall ──────────────────────────────────────────────


class _LlamaScanner(Protocol):
    def scan(self, messages: Any) -> Any: ...


class LlamaFirewallRule:
    """Wraps a LlamaFirewall scanner instance as a `Rule`.

    The scanner's `.scan()` result is expected to expose `decision`
    (string-like: 'ALLOW' / 'BLOCK' / 'HUMAN_IN_THE_LOOP_REQUIRED') and
    `score` (float). We map:
        BLOCK                          -> Decision(action="block")
        HUMAN_IN_THE_LOOP_REQUIRED     -> Decision(action="hitl")
        anything else (ALLOW / unset)  -> None (abstain)

    Pass `score_threshold` (default 0.5) to ignore borderline detections.
    """

    id = "llama_firewall"

    def __init__(
        self,
        scanner: _LlamaScanner,
        *,
        score_threshold: float = 0.5,
        rule_id: str = "llama_firewall",
    ) -> None:
        self._scanner = scanner
        self._threshold = score_threshold
        self.id = rule_id

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        text = _flatten_text(call.args)
        if not text:
            return None
        # LlamaFirewall accepts a list of messages; wrap our flat string.
        result = self._scanner.scan([{"role": "user", "content": text}])
        decision_str = str(getattr(result, "decision", "ALLOW")).upper()
        score = float(getattr(result, "score", 0.0))
        if score < self._threshold:
            return None
        if decision_str == "BLOCK":
            return Decision(
                action="block",
                rule_id=self.id,
                reason=f"LlamaFirewall: BLOCK (score={score:.2f})",
            )
        if decision_str in {"HUMAN_IN_THE_LOOP_REQUIRED", "HITL"}:
            return Decision(
                action="hitl",
                rule_id=self.id,
                reason=f"LlamaFirewall: HITL required (score={score:.2f})",
            )
        return None


# ─── Presidio ───────────────────────────────────────────────────


class _PresidioAnalyzer(Protocol):
    def analyze(self, text: str, language: str = ..., **kwargs: Any) -> list[Any]: ...


class PresidioRule:
    """Wraps a Presidio AnalyzerEngine as a `Rule`.

    Each detected entity has `entity_type` and `score`. The rule blocks
    the call if any entity is found above `block_above_score`, listing
    the entity types in the reason.

    Note: if you want to *redact* rather than block, use `PiiRedactor`
    instead — that runs before audit/redaction in the firewall pipeline.
    `PresidioRule` is for the harder line: "if Presidio sees PII at all,
    don't even make the call."
    """

    id = "presidio"

    def __init__(
        self,
        analyzer: _PresidioAnalyzer,
        *,
        block_above_score: float = 0.85,
        language: str = "en",
        entities: list[str] | None = None,
        rule_id: str = "presidio",
    ) -> None:
        self._analyzer = analyzer
        self._threshold = block_above_score
        self._language = language
        self._entities = entities
        self.id = rule_id

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision | None:
        text = _flatten_text(call.args)
        if not text:
            return None
        kwargs: dict[str, Any] = {"language": self._language}
        if self._entities is not None:
            kwargs["entities"] = self._entities
        findings = self._analyzer.analyze(text, **kwargs)
        hits = [
            f for f in findings
            if float(getattr(f, "score", 0.0)) >= self._threshold
        ]
        if not hits:
            return None
        kinds = sorted({str(getattr(h, "entity_type", "UNKNOWN")) for h in hits})
        return Decision(
            action="block",
            rule_id=self.id,
            reason=f"Presidio detected PII: {', '.join(kinds)}",
        )


__all__ = ["LlamaFirewallRule", "PresidioRule"]
