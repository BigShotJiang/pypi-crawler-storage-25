"""PII detection and redaction. Zero runtime deps (stdlib re only)."""
from __future__ import annotations

import copy
import re
from typing import Any

_PATTERNS: list[tuple[str, str]] = [
    ("EMAIL",       r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"),
    ("SSN",         r"\b\d{3}-\d{2}-\d{4}\b"),
    ("CREDIT_CARD", r"\b(?:4\d{3}|5[1-5]\d{2}|3[47]\d{2}|6011)"
                    r"[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b"),
    ("PHONE",       r"\b(?:\+1[\s\-]?)?\(?\d{3}\)?[\s.\-]\d{3}[\s.\-]\d{4}\b"),
]

_COMPILED = [(name, re.compile(pat)) for name, pat in _PATTERNS]


class PiiRedactor:
    """Regex-based PII redactor. Zero runtime dependencies."""

    def redact(self, text: str) -> str:
        for name, pattern in _COMPILED:
            text = pattern.sub(f"[REDACTED:{name}]", text)
        return text

    def scan(self, text: str) -> list[str]:
        found: set[str] = set()
        for name, pattern in _COMPILED:
            if pattern.search(text):
                found.add(name)
        return sorted(found)

    def redact_args(self, args: dict[str, Any]) -> dict[str, Any]:
        result = copy.deepcopy(args)
        self._redact_value(result)
        return result

    def _redact_value(self, value: Any) -> None:
        if isinstance(value, dict):
            for k, v in value.items():
                if isinstance(v, str):
                    value[k] = self.redact(v)
                else:
                    self._redact_value(v)
        elif isinstance(value, list):
            for i, item in enumerate(value):
                if isinstance(item, str):
                    value[i] = self.redact(item)
                else:
                    self._redact_value(item)


__all__ = ["PiiRedactor"]
