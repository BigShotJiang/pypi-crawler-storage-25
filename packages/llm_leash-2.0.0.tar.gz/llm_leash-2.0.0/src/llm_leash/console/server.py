"""``llm-leash-console`` — Starlette app + WebSocket audit tail.

Endpoints:
  GET  /              — single-file HTML dashboard (Alpine.js)
  GET  /api/stats     — proxy through to {proxy}/admin/stats
  GET  /api/audit     — last N audit events (JSON)
  WS   /ws/audit      — live tail: pushes new audit events as they arrive
  GET  /healthz       — liveness

Doesn't talk to LLMs itself, doesn't enforce anything — pure read-only
operator surface. Connects to a running ``llm-leash-proxy`` via its
admin HTTP API for live metrics + control surfaces.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import Any

import httpx
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, Response
from starlette.routing import Route, WebSocketRoute
from starlette.websockets import WebSocket, WebSocketDisconnect

from .. import __version__

# ─── Index HTML ───────────────────────────────────────────────────────


def _index_html() -> str:
    """Load the single-file dashboard from ``index.html`` next to this module."""
    path = Path(__file__).with_name("index.html")
    return path.read_text(encoding="utf-8")


async def index(_request: Request) -> Response:
    return HTMLResponse(_index_html())


async def healthz(_request: Request) -> Response:
    return JSONResponse({"status": "ok", "version": __version__, "mode": "console"})


# ─── Audit tail ───────────────────────────────────────────────────────


async def api_audit(request: Request) -> Response:
    """Return the last N audit events as JSON."""
    audit_path: str = request.app.state.audit_log
    n = int(request.query_params.get("n", "200"))
    events = _tail_audit_file(audit_path, n)
    return JSONResponse({"events": events, "audit_log": audit_path})


def _tail_audit_file(path: str, n: int) -> list[dict[str, Any]]:
    """Return the last ``n`` parsed events from the audit log.

    Read the whole file (audit logs are bounded by retention policy)
    and parse each non-empty line. For production with multi-GB logs,
    swap this for a reverse-line iterator — but the simple version is
    fine for v2.1.0a1.
    """
    p = Path(path)
    if not p.exists() or p.stat().st_size == 0:
        return []
    out: list[dict[str, Any]] = []
    with p.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return out[-n:]


async def ws_audit(websocket: WebSocket) -> None:
    """Stream new audit events to the client as they're appended.

    Polls the audit file every second; emits any new lines as JSON
    messages over the WebSocket. v2.1.0a1 uses polling for simplicity;
    a future enhancement could use inotify / kqueue for sub-second
    latency, but operators on second-scale UIs don't notice.
    """
    await websocket.accept()
    audit_path: str = websocket.app.state.audit_log
    p = Path(audit_path)

    def _size_if_exists() -> int:
        return p.stat().st_size if p.exists() else 0

    def _read_tail(seek_at: int) -> bytes:
        if not p.exists():
            return b""
        with p.open("rb") as f:
            f.seek(seek_at)
            return f.read()

    # Start at end-of-file so we don't replay history (use /api/audit for that).
    last_size = await asyncio.to_thread(_size_if_exists)

    try:
        while True:
            await asyncio.sleep(1.0)
            current_size = await asyncio.to_thread(_size_if_exists)
            if current_size == last_size:
                continue
            if current_size < last_size:
                # File rotated / truncated. Start over.
                last_size = 0
            new_bytes = await asyncio.to_thread(_read_tail, last_size)
            last_size = current_size
            for raw in new_bytes.splitlines():
                line = raw.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                await websocket.send_text(json.dumps(event, ensure_ascii=False))
    except WebSocketDisconnect:
        return


# ─── Proxy passthrough for stats ──────────────────────────────────────


async def api_stats(request: Request) -> Response:
    """Proxy GET /admin/stats from the upstream proxy. Read-only."""
    proxy_url: str | None = request.app.state.proxy_url
    admin_token: str | None = request.app.state.admin_token
    if not proxy_url:
        # Stand-alone mode — return a synthetic empty stats blob.
        return JSONResponse({
            "active_sessions": 0,
            "total_spend_usd": 0.0,
            "top_sessions": [],
            "hitl_pending": 0,
            "hitl_backend": "n/a",
            "policy_rules": 0,
            "pii_redactor_enabled": False,
            "proxy_url": None,
        })
    if not admin_token:
        return JSONResponse(
            {"error": {"type": "no_admin_token",
                       "message": "Set --admin-token or LLM_LEASH_ADMIN_TOKEN to "
                                  "fetch live stats from the proxy."}},
            status_code=503,
        )
    client: httpx.AsyncClient = request.app.state.http_client
    try:
        upstream = await client.get(
            f"{proxy_url.rstrip('/')}/admin/stats",
            headers={"Authorization": f"Bearer {admin_token}"},
            timeout=5.0,
        )
    except httpx.HTTPError as exc:
        return JSONResponse(
            {"error": {"type": "proxy_unreachable", "message": str(exc)}},
            status_code=502,
        )
    if upstream.status_code != 200:
        return Response(content=upstream.content, status_code=upstream.status_code,
                        media_type="application/json")
    try:
        body = upstream.json()
    except (json.JSONDecodeError, ValueError):
        return Response(content=upstream.content, status_code=502)
    body["proxy_url"] = proxy_url
    return JSONResponse(body)


# ─── App factory ──────────────────────────────────────────────────────


def build_app(
    *,
    audit_log: str,
    proxy_url: str | None = None,
    admin_token: str | None = None,
    http_client: httpx.AsyncClient | None = None,
) -> Starlette:
    """Construct the console ASGI app.

    Tests can pre-build the http_client (e.g. with a MockTransport for
    upstream simulation). Production code lets the default constructor
    fire on first request.
    """
    routes = [
        Route("/", index, methods=["GET"]),
        Route("/healthz", healthz, methods=["GET"]),
        Route("/api/stats", api_stats, methods=["GET"]),
        Route("/api/audit", api_audit, methods=["GET"]),
        WebSocketRoute("/ws/audit", ws_audit),
    ]
    app = Starlette(routes=routes)
    app.state.audit_log = audit_log
    app.state.proxy_url = proxy_url
    app.state.admin_token = admin_token
    app.state.http_client = http_client or httpx.AsyncClient(timeout=10.0)
    return app


# ─── CLI ──────────────────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="llm-leash-console",
        description="Read-only Web UI for llm-leash-proxy.",
    )
    parser.add_argument(
        "--port", type=int, default=8080,
        help="Port to bind (default: 8080).",
    )
    parser.add_argument(
        "--host", default="127.0.0.1",
        help="Host to bind (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--audit-log", required=True,
        help="Path to the audit JSONL file (typically the same path "
             "the proxy is writing to).",
    )
    parser.add_argument(
        "--proxy", default=None,
        help="URL of running llm-leash-proxy for live stats "
             "(e.g. http://localhost:8000). Without it, /api/stats "
             "returns an empty blob.",
    )
    parser.add_argument(
        "--admin-token", default=None,
        help="Bearer token for the proxy's admin API. Defaults to "
             "$LLM_LEASH_ADMIN_TOKEN.",
    )
    parser.add_argument(
        "--version", action="version",
        version=f"llm-leash-console {__version__}",
    )

    args = parser.parse_args(argv)

    import os
    admin_token = args.admin_token or os.environ.get("LLM_LEASH_ADMIN_TOKEN")

    app = build_app(
        audit_log=args.audit_log,
        proxy_url=args.proxy,
        admin_token=admin_token,
    )
    import uvicorn
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
