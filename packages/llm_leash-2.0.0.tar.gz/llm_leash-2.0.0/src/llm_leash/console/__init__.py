"""llm-leash-console — read-only Web UI for operators.

Separate binary (``llm-leash-console``) from the proxy data plane so a
crash in the UI doesn't take down agent traffic. Connects to a running
``llm-leash-proxy`` over its admin HTTP API and tails the audit log
file directly.

v2.1.0a1 scope: read-only views.
  - Live aggregate stats (spend, sessions, hitl pending)
  - Per-agent / per-session ranking
  - Live audit-log tail via WebSocket
  - One-click links to CLI commands (no in-UI mutations yet)

Operator write actions (kill, HITL approve/reject) ship in 2.1.0a2.
"""
from __future__ import annotations

# Probe required deps eagerly so import errors are clearer than missing attrs.
try:
    import httpx  # noqa: F401
    import starlette  # noqa: F401
    import uvicorn  # noqa: F401
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        'llm-leash-console requires extras. Install with:  pip install "llm-leash[proxy]"'
    ) from exc

from .server import build_app, main

__all__ = ["build_app", "main"]
