"""Redis-backed kill registry. Shares kill state across worker processes.

Requires the optional `[redis]` extra: pip install llm-leash[redis]

The client is duck-typed — any object implementing:
  .get(key) -> bytes | None
  .set(key, value) -> None
  .delete(key) -> None
  .exists(key) -> int
"""
from __future__ import annotations

import asyncio
from typing import Any


class RedisKillRegistry:
    """Kill registry backed by Redis. Drop-in for InProcessKillRegistry."""

    def __init__(
        self,
        client: Any,
        *,
        key_prefix: str = "llm_leash:kill:",
    ) -> None:
        self._client = client
        self._prefix = key_prefix

    def _key(self, session_id: str) -> str:
        return f"{self._prefix}{session_id}"

    async def kill(self, session_id: str, *, reason: str) -> None:
        key = self._key(session_id)
        await asyncio.to_thread(self._client.set, key, reason)

    async def is_killed(self, session_id: str) -> bool:
        key = self._key(session_id)
        result = await asyncio.to_thread(self._client.exists, key)
        return bool(result)

    async def reason_for(self, session_id: str) -> str | None:
        key = self._key(session_id)
        value = await asyncio.to_thread(self._client.get, key)
        if value is None:
            return None
        return value.decode() if isinstance(value, bytes) else str(value)

    async def clear(self, session_id: str) -> None:
        key = self._key(session_id)
        await asyncio.to_thread(self._client.delete, key)


__all__ = ["RedisKillRegistry"]
