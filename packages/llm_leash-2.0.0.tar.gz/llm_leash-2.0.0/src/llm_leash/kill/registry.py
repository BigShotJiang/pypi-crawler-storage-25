"""Kill registry: which session_ids have been told to stop.

v0.1 ships InProcessKillRegistry. Redis / HTTP transports ship in v0.2.
"""
from __future__ import annotations

import asyncio
from typing import Protocol, runtime_checkable


@runtime_checkable
class KillRegistry(Protocol):
    async def is_killed(self, session_id: str) -> bool: ...
    async def kill(self, session_id: str, *, reason: str) -> None: ...
    async def clear(self, session_id: str) -> None: ...
    async def reason_for(self, session_id: str) -> str | None: ...


class InProcessKillRegistry:
    """Single-process kill set. Useful for tests, notebooks, single-worker prod."""

    def __init__(self) -> None:
        self._killed: dict[str, str] = {}
        self._lock = asyncio.Lock()

    async def is_killed(self, session_id: str) -> bool:
        async with self._lock:
            return session_id in self._killed

    async def kill(self, session_id: str, *, reason: str) -> None:
        async with self._lock:
            self._killed[session_id] = reason

    async def clear(self, session_id: str) -> None:
        async with self._lock:
            self._killed.pop(session_id, None)

    async def reason_for(self, session_id: str) -> str | None:
        async with self._lock:
            return self._killed.get(session_id)


__all__ = ["InProcessKillRegistry", "KillRegistry"]
