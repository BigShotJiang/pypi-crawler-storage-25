"""HTTP-backed KillRegistry.

For deployments where many workers share a centralised kill service
(rather than Redis/SQLite). Stdlib `urllib` only — zero dependencies.

Service contract:
    GET    {base}/kill/{session_id}            -> 200 {"killed": bool, "reason": str|null}
                                                  404 if unknown
    POST   {base}/kill/{session_id}            <- {"reason": "..."} body, 200 OK on success
    DELETE {base}/kill/{session_id}            -> 200 OK on success

Network errors are treated as "not killed" by `is_killed()` so a flaky
control-plane never blocks production traffic. `kill()` raises on
network errors so callers know the kill order did not land.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class HTTPKillRegistry:
    """KillRegistry backed by a small HTTP service. Stdlib only."""

    def __init__(self, base_url: str, *, timeout_secs: float = 5.0) -> None:
        self._base = base_url.rstrip("/")
        self._timeout = timeout_secs

    def _url(self, session_id: str) -> str:
        return f"{self._base}/kill/{session_id}"

    def _sync_get(self, session_id: str) -> tuple[bool, str | None]:
        req = Request(self._url(session_id), method="GET")  # noqa: S310
        try:
            with urlopen(req, timeout=self._timeout) as resp:  # noqa: S310
                data: dict[str, Any] = json.loads(resp.read())
        except HTTPError as exc:
            if exc.code == 404:
                return False, None
            raise
        except URLError:
            # Treat transport failures as "not killed" — fail-open for reads.
            return False, None
        return bool(data.get("killed", False)), data.get("reason")

    def _sync_post(self, session_id: str, reason: str) -> None:
        body = json.dumps({"reason": reason}).encode()
        req = Request(  # noqa: S310
            self._url(session_id),
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urlopen(req, timeout=self._timeout) as _:  # noqa: S310
            pass

    def _sync_delete(self, session_id: str) -> None:
        req = Request(self._url(session_id), method="DELETE")  # noqa: S310
        try:
            with urlopen(req, timeout=self._timeout) as _:  # noqa: S310
                pass
        except HTTPError as exc:
            if exc.code == 404:
                return
            raise

    # ── async surface ────────────────────────────────────────────

    async def is_killed(self, session_id: str) -> bool:
        killed, _ = await asyncio.to_thread(self._sync_get, session_id)
        return killed

    async def kill(self, session_id: str, *, reason: str) -> None:
        await asyncio.to_thread(self._sync_post, session_id, reason)

    async def clear(self, session_id: str) -> None:
        await asyncio.to_thread(self._sync_delete, session_id)

    async def reason_for(self, session_id: str) -> str | None:
        _, reason = await asyncio.to_thread(self._sync_get, session_id)
        return reason


__all__ = ["HTTPKillRegistry"]
