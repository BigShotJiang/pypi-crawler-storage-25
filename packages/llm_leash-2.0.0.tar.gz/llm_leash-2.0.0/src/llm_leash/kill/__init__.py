"""Kill switch: per-session stop signal."""
from .redis_registry import RedisKillRegistry
from .registry import InProcessKillRegistry, KillRegistry
from .sqlite_registry import SQLiteKillRegistry
from .transport_http import HTTPKillRegistry

__all__ = [
    "HTTPKillRegistry",
    "InProcessKillRegistry",
    "KillRegistry",
    "RedisKillRegistry",
    "SQLiteKillRegistry",
]
