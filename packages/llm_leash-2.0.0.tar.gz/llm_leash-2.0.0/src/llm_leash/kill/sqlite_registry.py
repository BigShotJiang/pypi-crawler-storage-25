"""SQLite-backed KillRegistry.

Survives process restarts; safe across workers reading the same file.
Stdlib `sqlite3` only.
"""
from __future__ import annotations

import asyncio
import sqlite3
import threading
from pathlib import Path

_SCHEMA = """
CREATE TABLE IF NOT EXISTS killed_sessions (
    session_id TEXT PRIMARY KEY,
    reason TEXT NOT NULL
)
"""


class SQLiteKillRegistry:
    """File-backed kill set. Idempotent kill, cross-process safe."""

    def __init__(self, path: str) -> None:
        self._path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(_SCHEMA)

    # ── sync helpers ──────────────────────────────────────────────

    def _sync_is_killed(self, session_id: str) -> bool:
        with self._lock:
            row = self._conn.execute(
                "SELECT 1 FROM killed_sessions WHERE session_id = ?",
                (session_id,),
            ).fetchone()
        return row is not None

    def _sync_kill(self, session_id: str, reason: str) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO killed_sessions (session_id, reason) VALUES (?, ?) "
                "ON CONFLICT(session_id) DO UPDATE SET reason = excluded.reason",
                (session_id, reason),
            )

    def _sync_clear(self, session_id: str) -> None:
        with self._lock:
            self._conn.execute(
                "DELETE FROM killed_sessions WHERE session_id = ?",
                (session_id,),
            )

    def _sync_reason(self, session_id: str) -> str | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT reason FROM killed_sessions WHERE session_id = ?",
                (session_id,),
            ).fetchone()
        return row[0] if row else None

    # ── async surface ─────────────────────────────────────────────

    async def is_killed(self, session_id: str) -> bool:
        return await asyncio.to_thread(self._sync_is_killed, session_id)

    async def kill(self, session_id: str, *, reason: str) -> None:
        await asyncio.to_thread(self._sync_kill, session_id, reason)

    async def clear(self, session_id: str) -> None:
        await asyncio.to_thread(self._sync_clear, session_id)

    async def reason_for(self, session_id: str) -> str | None:
        return await asyncio.to_thread(self._sync_reason, session_id)

    def close(self) -> None:
        with self._lock:
            self._conn.close()


__all__ = ["SQLiteKillRegistry"]
