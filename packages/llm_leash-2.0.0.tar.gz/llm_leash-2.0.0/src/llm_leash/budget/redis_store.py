"""Redis-backed budget store. Shares spend state across worker processes.

Requires the optional `[redis]` extra: pip install llm-leash[redis]

The client is duck-typed — any object implementing:
  .get(key) -> bytes | None
  .incrbyfloat(key, amount) -> float
  .delete(key) -> None
"""
from __future__ import annotations

import asyncio
from typing import Any


class RedisBudgetStore:
    """Budget store backed by Redis. Drop-in for InMemoryStore."""

    def __init__(
        self,
        client: Any,
        *,
        key_prefix: str = "llm_leash:budget:",
    ) -> None:
        self._client = client
        self._prefix = key_prefix

    def _key(self, session_id: str) -> str:
        return f"{self._prefix}{session_id}"

    async def get(self, session_id: str) -> float:
        key = self._key(session_id)
        value = await asyncio.to_thread(self._client.get, key)
        if value is None:
            return 0.0
        return float(value)

    async def add(self, session_id: str, delta_usd: float) -> float:
        key = self._key(session_id)
        result = await asyncio.to_thread(self._client.incrbyfloat, key, delta_usd)
        return float(result)

    async def reset(self, session_id: str) -> None:
        key = self._key(session_id)
        await asyncio.to_thread(self._client.delete, key)


__all__ = ["RedisBudgetStore"]
