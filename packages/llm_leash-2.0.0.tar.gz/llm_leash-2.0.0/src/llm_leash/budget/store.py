"""Budget stores: persistent cumulative spend per session.

v0.1 ships InMemoryStore. Redis / SQLite ship in v0.2.
The Protocol is the contract — write your own to back any KV.
"""
from __future__ import annotations

import asyncio
from typing import Protocol, runtime_checkable


@runtime_checkable
class BudgetStore(Protocol):
    """Async, atomic cumulative spend per session_id."""

    async def get(self, session_id: str) -> float: ...
    async def add(self, session_id: str, delta_usd: float) -> float: ...
    async def reset(self, session_id: str) -> None: ...


class InMemoryStore:
    """Single-process, asyncio-Lock guarded. Loses state on restart."""

    def __init__(self) -> None:
        self._totals: dict[str, float] = {}
        self._lock = asyncio.Lock()

    async def get(self, session_id: str) -> float:
        async with self._lock:
            return self._totals.get(session_id, 0.0)

    async def add(self, session_id: str, delta_usd: float) -> float:
        async with self._lock:
            new = self._totals.get(session_id, 0.0) + delta_usd
            self._totals[session_id] = new
            return new

    async def reset(self, session_id: str) -> None:
        async with self._lock:
            self._totals.pop(session_id, None)


__all__ = ["BudgetStore", "InMemoryStore"]
