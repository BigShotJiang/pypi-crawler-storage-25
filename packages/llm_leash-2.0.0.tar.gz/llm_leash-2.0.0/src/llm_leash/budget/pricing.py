"""Pricing tables for LLM providers. Versioned, baked into the wheel.

PRICING_v_2026_05 reflects published list prices as of 2026-05.
Patch releases update these constants. Do not edit a published version's
table — add a new one (PRICING_v_2026_06) and let users opt in.

Source: provider pricing pages, captured 2026-05-15.
"""
from __future__ import annotations

from typing import TypedDict


class _ModelPrice(TypedDict):
    input_per_million_usd: float
    output_per_million_usd: float


PRICING_v_2026_05: dict[str, dict[str, _ModelPrice]] = {
    "anthropic": {
        # Latest line
        "claude-opus-4-7":     {"input_per_million_usd": 15.0,  "output_per_million_usd": 75.0},
        "claude-sonnet-4-6":   {"input_per_million_usd":  3.0,  "output_per_million_usd": 15.0},
        "claude-haiku-4-5":    {"input_per_million_usd":  0.80, "output_per_million_usd":  4.0},
        # Predecessors still in heavy use (orchestrators pin model names)
        "claude-opus-4-6":     {"input_per_million_usd": 15.0,  "output_per_million_usd": 75.0},
        "claude-opus-4-5":     {"input_per_million_usd": 15.0,  "output_per_million_usd": 75.0},
        "claude-sonnet-4-5":   {"input_per_million_usd":  3.0,  "output_per_million_usd": 15.0},
        # 3.x line — common in OpenRouter routing tables
        "claude-3-5-sonnet":   {"input_per_million_usd":  3.0,  "output_per_million_usd": 15.0},
        "claude-3-5-haiku":    {"input_per_million_usd":  0.80, "output_per_million_usd":  4.0},
        # Hyphenated variants seen in third-party catalogs (OpenRouter, LiteLLM)
        "claude-haiku-3-5":    {"input_per_million_usd":  0.80, "output_per_million_usd":  4.0},
        "claude-sonnet-3-5":   {"input_per_million_usd":  3.0,  "output_per_million_usd": 15.0},
    },
    "openai": {
        "gpt-4o":              {"input_per_million_usd":  2.50, "output_per_million_usd": 10.0},
        "gpt-4o-mini":         {"input_per_million_usd":  0.15, "output_per_million_usd":  0.60},
        "o1":                  {"input_per_million_usd": 15.0,  "output_per_million_usd": 60.0},
        "o1-mini":             {"input_per_million_usd":  3.0,  "output_per_million_usd": 12.0},
    },
}


class UnknownModel(KeyError):
    """Raised when (provider, model) is not in the active pricing table."""


def cost_for(
    *,
    provider: str,
    model: str,
    in_tokens: int,
    out_tokens: int,
    table: dict[str, dict[str, _ModelPrice]] | None = None,
) -> float:
    """Compute USD cost for a single model call.

    Raises UnknownModel if the (provider, model) is not in the table.
    Token counts of 0 are valid and return 0.0.
    """
    tbl = table if table is not None else PRICING_v_2026_05
    try:
        entry = tbl[provider][model]
    except KeyError as exc:
        raise UnknownModel(f"{provider}/{model} not in pricing table") from exc
    return (
        entry["input_per_million_usd"]  * (in_tokens  / 1_000_000)
      + entry["output_per_million_usd"] * (out_tokens / 1_000_000)
    )


__all__ = ["PRICING_v_2026_05", "UnknownModel", "cost_for"]
