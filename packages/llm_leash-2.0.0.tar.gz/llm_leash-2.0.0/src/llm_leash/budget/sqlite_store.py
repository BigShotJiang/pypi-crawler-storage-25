"""SQLite-backed BudgetStore.

Persists cumulative spend per session across process restarts. Zero
external dependencies — stdlib `sqlite3` only. Async-safe via
`asyncio.to_thread`; SQLite handles cross-process atomicity through its
own locking (default journal mode) so multiple workers on the same file
do not corrupt totals.
"""
from __future__ import annotations

import asyncio
import sqlite3
import threading
from pathlib import Path

_SCHEMA = """
CREATE TABLE IF NOT EXISTS budget (
    session_id TEXT PRIMARY KEY,
    cumulative_usd REAL NOT NULL DEFAULT 0.0
)
"""


class SQLiteBudgetStore:
    """File-backed BudgetStore. Safe for multiple writers on the same file."""

    def __init__(self, path: str) -> None:
        self._path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        # In-process lock to serialize writes against the single connection.
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(_SCHEMA)

    # ── sync helpers (run in a worker thread) ──────────────────────

    def _sync_get(self, session_id: str) -> float:
        with self._lock:
            row = self._conn.execute(
                "SELECT cumulative_usd FROM budget WHERE session_id = ?",
                (session_id,),
            ).fetchone()
        return float(row[0]) if row else 0.0

    def _sync_add(self, session_id: str, delta_usd: float) -> float:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                row = self._conn.execute(
                    "SELECT cumulative_usd FROM budget WHERE session_id = ?",
                    (session_id,),
                ).fetchone()
                current = float(row[0]) if row else 0.0
                new = current + delta_usd
                self._conn.execute(
                    "INSERT INTO budget (session_id, cumulative_usd) "
                    "VALUES (?, ?) "
                    "ON CONFLICT(session_id) DO UPDATE SET cumulative_usd = ?",
                    (session_id, new, new),
                )
                self._conn.execute("COMMIT")
            except Exception:
                self._conn.execute("ROLLBACK")
                raise
        return new

    def _sync_reset(self, session_id: str) -> None:
        with self._lock:
            self._conn.execute(
                "DELETE FROM budget WHERE session_id = ?", (session_id,)
            )

    # ── async surface ─────────────────────────────────────────────

    async def get(self, session_id: str) -> float:
        return await asyncio.to_thread(self._sync_get, session_id)

    async def add(self, session_id: str, delta_usd: float) -> float:
        return await asyncio.to_thread(self._sync_add, session_id, delta_usd)

    async def reset(self, session_id: str) -> None:
        await asyncio.to_thread(self._sync_reset, session_id)

    def close(self) -> None:
        with self._lock:
            self._conn.close()


__all__ = ["SQLiteBudgetStore"]
