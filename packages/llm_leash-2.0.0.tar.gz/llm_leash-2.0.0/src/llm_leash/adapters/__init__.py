"""SDK adapters. Optional — each pulls in its target SDK as extra."""
from .anthropic import AnthropicAdapter

__all__ = ["AnthropicAdapter"]
