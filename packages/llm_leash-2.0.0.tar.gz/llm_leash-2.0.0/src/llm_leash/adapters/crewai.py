"""CrewAI adapter — wraps crewai.LLM.call(messages).

Duck-typed: no crewai import at module level.

Shape required:
    client.call(messages, **kwargs) -> response (LiteLLM-shaped or str)
    client.model: model id string (e.g. "gpt-4o", "anthropic/claude-haiku-4-5")

Token extraction:
    response.usage.prompt_tokens / completion_tokens (LiteLLM full object)
    OR response["usage"]["prompt_tokens"] / ["completion_tokens"] (dict)
    OR (0, 0) if response is a plain string

Provider detection from model string prefix: "anthropic/..." → anthropic,
"openai/..." or bare → openai.
"""
from __future__ import annotations

import asyncio
import datetime as _dt
import hashlib
import json
import threading
from typing import Any

from ..audit.schema import KillEvent, ModelCall
from ..audit.writer import AuditWriter
from ..budget.tracker import BudgetTracker
from ..hitl.gate import HitlGate
from ..kill.registry import KillRegistry
from ..policy.engine import PolicyEngine
from ..policy.pii import PiiRedactor
from ..types import LeashKilled, LeashRejectedByHuman, PolicyContext, ToolCall


def _now_iso() -> str:
    return _dt.datetime.now(_dt.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _hash(payload: Any) -> str:
    try:
        s = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    except TypeError:
        s = str(payload)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _run(coro: Any) -> Any:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    result: dict[str, Any] = {}

    def _runner() -> None:
        try:
            result["value"] = asyncio.run(coro)
        except BaseException as exc:
            result["error"] = exc

    t = threading.Thread(target=_runner, daemon=True)
    t.start()
    t.join()
    if "error" in result:
        raise result["error"]
    return result.get("value")


def _split_provider_model(model_str: str) -> tuple[str, str]:
    """`anthropic/claude-haiku-4-5` → (`anthropic`, `claude-haiku-4-5`).

    Bare `gpt-4o` defaults to openai.
    """
    if "/" in model_str:
        prov, _, name = model_str.partition("/")
        return prov.lower(), name
    return "openai", model_str


def _extract_tokens(response: Any) -> tuple[int, int]:
    """Pull (input_tokens, output_tokens) from a LiteLLM-style response."""
    usage = getattr(response, "usage", None)
    if usage is not None:
        in_t = getattr(usage, "prompt_tokens", None)
        out_t = getattr(usage, "completion_tokens", None)
        if in_t is not None and out_t is not None:
            return int(in_t), int(out_t)
    if isinstance(response, dict):
        u = response.get("usage") or {}
        return int(u.get("prompt_tokens", 0)), int(u.get("completion_tokens", 0))
    return 0, 0


class _WrappedCrewLLM:
    def __init__(self, raw: Any, adapter: CrewAIAdapter) -> None:
        self._raw = raw
        self._adapter = adapter

    def call(self, messages: Any, **kwargs: Any) -> Any:
        return self._adapter._run_sync(self._raw, messages, kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


class CrewAIAdapter:
    name = "crewai"

    def __init__(
        self,
        *,
        session_id: str,
        budget: BudgetTracker,
        audit: AuditWriter,
        kill: KillRegistry,
        tenant_id: str | None = None,
        engine: PolicyEngine | None = None,
        pii_redactor: PiiRedactor | None = None,
        hitl_gate: HitlGate | None = None,
    ) -> None:
        self._session_id = session_id
        self._tenant_id = tenant_id
        self._budget = budget
        self._audit = audit
        self._kill = kill
        self._engine = engine
        self._pii_redactor = pii_redactor
        self._hitl_gate = hitl_gate

    def wrap_client(self, raw: Any) -> Any:
        return _WrappedCrewLLM(raw, self)

    def _run_sync(self, raw: Any, messages: Any, kwargs: dict[str, Any]) -> Any:
        return _run(self._call(raw, messages, kwargs))

    async def _call(self, raw: Any, messages: Any, kwargs: dict[str, Any]) -> Any:
        model_str = getattr(raw, "model", "unknown")
        provider, model = _split_provider_model(model_str)

        # 1. Kill check.
        if await self._kill.is_killed(self._session_id):
            reason = await self._kill.reason_for(self._session_id) or "session killed"
            self._audit.write(KillEvent(
                ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
                seq=0, prev_hash="x", reason=reason,
            ))
            raise LeashKilled(rule_id="kill:registry", reason=reason)

        # 1b. Policy engine.
        if self._engine is not None:
            cumulative_now = await self._budget.cumulative_usd()
            ctx = PolicyContext(
                cumulative_usd=cumulative_now,
                budget_cap_usd=self._budget._hard,
                soft_cap_usd=self._budget._soft,
                tenant_id=self._tenant_id,
            )
            call_obj = ToolCall(
                tool="crewai.call",
                args={"model": model_str, "messages": messages},
                session_id=self._session_id,
                tenant_id=self._tenant_id,
            )
            decision = self._engine.evaluate(call_obj, ctx)
            if decision.action == "hitl":
                if self._hitl_gate is None:
                    raise LeashRejectedByHuman(
                        rule_id=decision.rule_id,
                        reason="hitl: no gate configured (set hitl_gate= on Firewall)",
                    )
                await self._hitl_gate.request(call_obj, decision)

        # 1c. PII redaction.
        if self._pii_redactor is not None:
            messages = self._pii_redactor.redact_args({"messages": messages})["messages"]

        # 2. Call underlying LLM.
        response = raw.call(messages, **kwargs)

        # 3. Charge actual usage.
        in_t, out_t = _extract_tokens(response)
        state = await self._budget.charge(
            provider=provider, model=model,
            in_tokens=in_t, out_tokens=out_t,
        )

        # 4. Audit.
        self._audit.write(ModelCall(
            ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
            seq=0, prev_hash="x",
            provider=provider, model=model,
            input_tokens=in_t, output_tokens=out_t,
            cost_usd=state.cumulative_usd,
            request_hash=_hash({"model": model_str, "messages": messages}),
            response_hash=_hash(getattr(response, "choices", response)),
        ))

        # 5. Post-call hard cap.
        if self._budget._hard is not None and state.cumulative_usd > self._budget._hard:
            raise LeashKilled(
                rule_id="budget:hard_cap",
                reason=(
                    f"cumulative ${state.cumulative_usd:.4f} "
                    f"exceeds cap ${self._budget._hard:.4f}"
                ),
            )

        return response


__all__ = ["CrewAIAdapter"]
