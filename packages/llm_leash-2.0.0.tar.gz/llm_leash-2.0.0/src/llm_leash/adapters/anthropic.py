"""Anthropic adapter — wraps a client to route through the firewall.

The adapter does not import `anthropic` at module level; it duck-types
on the wrapped client. This keeps the optional dep optional and makes
testing trivial (any object with a `.messages.create(...)` works).
"""
from __future__ import annotations

import asyncio
import datetime as _dt
import hashlib
import json
from typing import Any

from ..audit.schema import KillEvent, ModelCall
from ..audit.writer import AuditWriter
from ..budget.tracker import BudgetTracker
from ..hitl.gate import HitlGate
from ..kill.registry import KillRegistry
from ..policy.engine import PolicyEngine
from ..policy.pii import PiiRedactor
from ..types import LeashKilled, LeashRejectedByHuman, PolicyContext, ToolCall


def _now_iso() -> str:
    return _dt.datetime.now(_dt.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _hash_request(model: str, kwargs: dict[str, Any]) -> str:
    payload = {"model": model, "messages": kwargs.get("messages")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _hash_response(content: Any) -> str:
    try:
        payload = json.dumps(content, sort_keys=True, separators=(",", ":"), default=str)
    except TypeError:
        payload = str(content)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _run(coro: Any) -> Any:
    """Run an async coroutine from a sync method, even if a loop exists.

    If no loop is running, use asyncio.run. If a loop IS running on the
    current thread (e.g. we were called sync-from-async, as in pytest-asyncio
    tests), we cannot block on it from inside — that's a deadlock. Instead
    we run the coroutine on a fresh loop in a worker thread.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    import threading

    result: dict[str, Any] = {}

    def _runner() -> None:
        try:
            result["value"] = asyncio.run(coro)
        except BaseException as exc:
            result["error"] = exc

    t = threading.Thread(target=_runner, daemon=True)
    t.start()
    t.join()
    if "error" in result:
        raise result["error"]
    return result.get("value")


class _WrappedMessages:
    def __init__(self, raw: Any, adapter: AnthropicAdapter) -> None:
        self._raw = raw
        self._adapter = adapter

    def create(self, **kwargs: Any) -> Any:
        return self._adapter._run_create_sync(self._raw, kwargs)


class _WrappedClient:
    def __init__(self, raw: Any, adapter: AnthropicAdapter) -> None:
        self._raw = raw
        self.messages = _WrappedMessages(raw.messages, adapter)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


class AnthropicAdapter:
    name = "anthropic"

    def __init__(
        self,
        *,
        session_id: str,
        budget: BudgetTracker,
        audit: AuditWriter,
        kill: KillRegistry,
        tenant_id: str | None = None,
        engine: PolicyEngine | None = None,
        pii_redactor: PiiRedactor | None = None,
        hitl_gate: HitlGate | None = None,
    ) -> None:
        self._session_id = session_id
        self._tenant_id = tenant_id
        self._budget = budget
        self._audit = audit
        self._kill = kill
        self._engine = engine
        self._pii_redactor = pii_redactor
        self._hitl_gate = hitl_gate

    def wrap_client(self, raw: Any) -> Any:
        return _WrappedClient(raw, self)

    # ── internal sync entry ────────────────────────────────────────

    def _run_create_sync(self, raw_messages: Any, kwargs: dict[str, Any]) -> Any:
        return _run(self._create(raw_messages, kwargs))

    async def _create(self, raw_messages: Any, kwargs: dict[str, Any]) -> Any:
        model = kwargs["model"]
        request_hash = _hash_request(model, kwargs)

        # 1. Kill check.
        if await self._kill.is_killed(self._session_id):
            reason = await self._kill.reason_for(self._session_id) or "session killed"
            self._audit.write(KillEvent(
                ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
                seq=0, prev_hash="x", reason=reason,
            ))
            raise LeashKilled(rule_id="kill:registry", reason=reason)

        # 1b. Policy engine evaluation.
        if self._engine is not None:
            cumulative_now = await self._budget.cumulative_usd()
            ctx = PolicyContext(
                cumulative_usd=cumulative_now,
                budget_cap_usd=self._budget._hard,
                soft_cap_usd=self._budget._soft,
                tenant_id=self._tenant_id,
            )
            call_obj = ToolCall(
                tool="anthropic.call",
                args={"model": model, "messages": kwargs.get("messages", [])},
                session_id=self._session_id,
                tenant_id=self._tenant_id,
            )
            decision = self._engine.evaluate(call_obj, ctx)  # raises LeashBlocked on block
            if decision.action == "hitl":
                if self._hitl_gate is None:
                    raise LeashRejectedByHuman(
                        rule_id=decision.rule_id,
                        reason="hitl: no gate configured (set hitl_gate= on Firewall)",
                    )
                await self._hitl_gate.request(call_obj, decision)

        # 1c. PII redaction of outgoing messages.
        if self._pii_redactor is not None and "messages" in kwargs:
            kwargs = {**kwargs, "messages": self._pii_redactor.redact_args(
                {"messages": kwargs["messages"]}
            )["messages"]}

        # 2. Pre-call estimate (input tokens unknown until response;
        #    we use max_tokens as upper bound for the gate).
        max_tokens = int(kwargs.get("max_tokens", 0))
        estimated = await self._budget.estimate(
            provider="anthropic", model=model, in_tokens=max_tokens,
        )
        cumulative_before = await self._budget.cumulative_usd()
        if self._budget._hard is not None and cumulative_before + estimated > self._budget._hard:
            raise LeashKilled(
                rule_id="budget:pre_call_estimate",
                reason=f"pre-call estimate ${estimated:.4f} on top of "
                       f"${cumulative_before:.4f} would exceed cap ${self._budget._hard:.4f}",
            )

        # 3. Call the underlying SDK.
        response = raw_messages.create(**kwargs)

        # 4. Charge actual.
        usage = response.usage
        in_t = int(getattr(usage, "input_tokens", 0))
        out_t = int(getattr(usage, "output_tokens", 0))
        state = await self._budget.charge(
            provider="anthropic", model=model,
            in_tokens=in_t, out_tokens=out_t,
        )

        # 5. Audit.
        self._audit.write(ModelCall(
            ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
            seq=0, prev_hash="x",
            provider="anthropic", model=model,
            input_tokens=in_t, output_tokens=out_t,
            cost_usd=state.cumulative_usd,
            request_hash=request_hash,
            response_hash=_hash_response(getattr(response, "content", None)),
        ))

        return response


__all__ = ["AnthropicAdapter"]
