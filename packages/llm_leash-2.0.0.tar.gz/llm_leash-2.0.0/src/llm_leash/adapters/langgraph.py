"""LangChain / LangGraph adapter — wraps ChatAnthropic / ChatOpenAI .invoke().

Duck-typed: no langchain import at module level.

Shape required:
    client.invoke(messages, **kwargs) -> AIMessage-like
    client.model_name OR client.model  (the model id, e.g. "claude-opus-4-7")
    AIMessage.usage_metadata = {"input_tokens": int, "output_tokens": int}
        OR  AIMessage.response_metadata["token_usage"] (OpenAI-style)

Provider is auto-detected from class name: "Anthropic" → anthropic, else openai.
LangGraph users wrap the chat model used inside their graph nodes — the graph
orchestration layer itself is not intercepted; the model is.
"""
from __future__ import annotations

import asyncio
import datetime as _dt
import hashlib
import json
import threading
from typing import Any

from ..audit.schema import KillEvent, ModelCall
from ..audit.writer import AuditWriter
from ..budget.tracker import BudgetTracker
from ..hitl.gate import HitlGate
from ..kill.registry import KillRegistry
from ..policy.engine import PolicyEngine
from ..policy.pii import PiiRedactor
from ..types import LeashKilled, LeashRejectedByHuman, PolicyContext, ToolCall


def _now_iso() -> str:
    return _dt.datetime.now(_dt.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _hash_request(model: str, messages: Any) -> str:
    try:
        msg_repr: Any = [
            {"role": getattr(m, "type", "user"), "content": getattr(m, "content", str(m))}
            for m in messages
        ] if isinstance(messages, list) else str(messages)
    except Exception:
        msg_repr = str(messages)
    payload = {"model": model, "messages": msg_repr}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()


def _hash_response(content: Any) -> str:
    try:
        payload = json.dumps(content, sort_keys=True, separators=(",", ":"), default=str)
    except TypeError:
        payload = str(content)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _run(coro: Any) -> Any:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    result: dict[str, Any] = {}

    def _runner() -> None:
        try:
            result["value"] = asyncio.run(coro)
        except BaseException as exc:
            result["error"] = exc

    t = threading.Thread(target=_runner, daemon=True)
    t.start()
    t.join()
    if "error" in result:
        raise result["error"]
    return result.get("value")


def _extract_tokens(response: Any) -> tuple[int, int]:
    """Pull (input_tokens, output_tokens) out of an AIMessage-shaped response.

    Tries usage_metadata (LangChain >=0.2) first, then response_metadata
    (OpenAI-style), then 0/0 as a last-resort fallback.
    """
    meta = getattr(response, "usage_metadata", None)
    if isinstance(meta, dict):
        return int(meta.get("input_tokens", 0)), int(meta.get("output_tokens", 0))
    rmeta = getattr(response, "response_metadata", None)
    if isinstance(rmeta, dict):
        usage = rmeta.get("token_usage") or rmeta.get("usage") or {}
        in_t = usage.get("prompt_tokens") or usage.get("input_tokens") or 0
        out_t = usage.get("completion_tokens") or usage.get("output_tokens") or 0
        return int(in_t), int(out_t)
    return 0, 0


def _detect_provider(client: Any) -> str:
    cls = type(client).__name__.lower()
    module = type(client).__module__.lower()
    if "anthropic" in cls or "anthropic" in module:
        return "anthropic"
    return "openai"


def _get_model_name(client: Any) -> str:
    return (
        getattr(client, "model_name", None)
        or getattr(client, "model", None)
        or "unknown"
    )


class _WrappedChatModel:
    """Wraps a langchain BaseChatModel-shaped object."""

    def __init__(self, raw: Any, adapter: LangChainAdapter) -> None:
        self._raw = raw
        self._adapter = adapter

    def invoke(self, messages: Any, **kwargs: Any) -> Any:
        return self._adapter._run_sync(self._raw, messages, kwargs)

    async def ainvoke(self, messages: Any, **kwargs: Any) -> Any:
        return await self._adapter._invoke(self._raw, messages, kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


class LangChainAdapter:
    name = "langchain"

    def __init__(
        self,
        *,
        session_id: str,
        budget: BudgetTracker,
        audit: AuditWriter,
        kill: KillRegistry,
        tenant_id: str | None = None,
        engine: PolicyEngine | None = None,
        pii_redactor: PiiRedactor | None = None,
        hitl_gate: HitlGate | None = None,
    ) -> None:
        self._session_id = session_id
        self._tenant_id = tenant_id
        self._budget = budget
        self._audit = audit
        self._kill = kill
        self._engine = engine
        self._pii_redactor = pii_redactor
        self._hitl_gate = hitl_gate

    def wrap_client(self, raw: Any) -> Any:
        return _WrappedChatModel(raw, self)

    def _run_sync(self, raw: Any, messages: Any, kwargs: dict[str, Any]) -> Any:
        return _run(self._invoke(raw, messages, kwargs))

    async def _invoke(self, raw: Any, messages: Any, kwargs: dict[str, Any]) -> Any:
        provider = _detect_provider(raw)
        model = _get_model_name(raw)
        request_hash = _hash_request(model, messages)

        # 1. Kill check.
        if await self._kill.is_killed(self._session_id):
            reason = await self._kill.reason_for(self._session_id) or "session killed"
            self._audit.write(KillEvent(
                ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
                seq=0, prev_hash="x", reason=reason,
            ))
            raise LeashKilled(rule_id="kill:registry", reason=reason)

        # 1b. Policy engine.
        if self._engine is not None:
            cumulative_now = await self._budget.cumulative_usd()
            ctx = PolicyContext(
                cumulative_usd=cumulative_now,
                budget_cap_usd=self._budget._hard,
                soft_cap_usd=self._budget._soft,
                tenant_id=self._tenant_id,
            )
            call_obj = ToolCall(
                tool="langchain.invoke",
                args={"model": model, "messages": messages},
                session_id=self._session_id,
                tenant_id=self._tenant_id,
            )
            decision = self._engine.evaluate(call_obj, ctx)
            if decision.action == "hitl":
                if self._hitl_gate is None:
                    raise LeashRejectedByHuman(
                        rule_id=decision.rule_id,
                        reason="hitl: no gate configured (set hitl_gate= on Firewall)",
                    )
                await self._hitl_gate.request(call_obj, decision)

        # 1c. PII redaction.
        if self._pii_redactor is not None:
            messages = self._pii_redactor.redact_args({"messages": messages})["messages"]

        # 2. Call underlying model.
        response = raw.invoke(messages, **kwargs)

        # 3. Charge actual usage.
        in_t, out_t = _extract_tokens(response)
        state = await self._budget.charge(
            provider=provider, model=model,
            in_tokens=in_t, out_tokens=out_t,
        )

        # 4. Audit.
        content = getattr(response, "content", None)
        self._audit.write(ModelCall(
            ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
            seq=0, prev_hash="x",
            provider=provider, model=model,
            input_tokens=in_t, output_tokens=out_t,
            cost_usd=state.cumulative_usd,
            request_hash=request_hash,
            response_hash=_hash_response(content),
        ))

        # 5. Post-call hard-cap check.
        if self._budget._hard is not None and state.cumulative_usd > self._budget._hard:
            raise LeashKilled(
                rule_id="budget:hard_cap",
                reason=(
                    f"cumulative ${state.cumulative_usd:.4f} "
                    f"exceeds cap ${self._budget._hard:.4f}"
                ),
            )

        return response


__all__ = ["LangChainAdapter"]
