"""Pydantic-AI adapter — wraps a pydantic_ai Model's `request()`.

Duck-typed: no pydantic_ai import at module level.

Shape required:
    async client.request(messages, ...) -> (ModelResponse, Usage)
    client.model_name OR client.model -> model id string

Pydantic-AI's `Model.request()` is the native async surface used inside
`Agent.run()`. Wrapping it intercepts every LLM call the agent makes,
no matter how the user composed the agent on top.

Token extraction tries (in order):
  - returned Usage object: .request_tokens / .response_tokens (pydantic-ai)
  - returned Usage object: .input_tokens / .output_tokens (newer pydantic-ai)
  - ModelResponse.usage attribute with same fields
  - fallback (0, 0) — better to log a miss than to refuse the call
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
from typing import Any

from ..audit.schema import KillEvent, ModelCall
from ..audit.writer import AuditWriter
from ..budget.tracker import BudgetTracker
from ..hitl.gate import HitlGate
from ..kill.registry import KillRegistry
from ..policy.engine import PolicyEngine
from ..policy.pii import PiiRedactor
from ..types import LeashKilled, LeashRejectedByHuman, PolicyContext, ToolCall


def _now_iso() -> str:
    return _dt.datetime.now(_dt.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _hash(payload: Any) -> str:
    try:
        s = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    except TypeError:
        s = str(payload)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _detect_provider(client: Any) -> str:
    cls = type(client).__name__.lower()
    module = type(client).__module__.lower()
    if "anthropic" in cls or "anthropic" in module:
        return "anthropic"
    return "openai"


def _get_model_name(client: Any) -> str:
    return (
        getattr(client, "model_name", None)
        or getattr(client, "model", None)
        or "unknown"
    )


def _read_usage(obj: Any) -> tuple[int, int] | None:
    if obj is None:
        return None
    # Newer pydantic-ai: input_tokens / output_tokens
    in_t = getattr(obj, "input_tokens", None)
    out_t = getattr(obj, "output_tokens", None)
    if in_t is not None and out_t is not None:
        return int(in_t), int(out_t)
    # Older pydantic-ai: request_tokens / response_tokens
    in_t = getattr(obj, "request_tokens", None)
    out_t = getattr(obj, "response_tokens", None)
    if in_t is not None and out_t is not None:
        return int(in_t), int(out_t)
    return None


def _extract_tokens(result: Any) -> tuple[int, int]:
    # The result is typically a (response, usage) tuple.
    if isinstance(result, tuple) and len(result) == 2:
        response, usage = result
        u = _read_usage(usage) or _read_usage(getattr(response, "usage", None))
        if u is not None:
            return u
    # Or a response with .usage attached.
    u = _read_usage(getattr(result, "usage", None))
    if u is not None:
        return u
    return 0, 0


class _WrappedPydanticAIModel:
    def __init__(self, raw: Any, adapter: PydanticAIAdapter) -> None:
        self._raw = raw
        self._adapter = adapter

    async def request(self, messages: Any, *args: Any, **kwargs: Any) -> Any:
        return await self._adapter._request(self._raw, messages, args, kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


class PydanticAIAdapter:
    name = "pydantic_ai"

    def __init__(
        self,
        *,
        session_id: str,
        budget: BudgetTracker,
        audit: AuditWriter,
        kill: KillRegistry,
        tenant_id: str | None = None,
        engine: PolicyEngine | None = None,
        pii_redactor: PiiRedactor | None = None,
        hitl_gate: HitlGate | None = None,
    ) -> None:
        self._session_id = session_id
        self._tenant_id = tenant_id
        self._budget = budget
        self._audit = audit
        self._kill = kill
        self._engine = engine
        self._pii_redactor = pii_redactor
        self._hitl_gate = hitl_gate

    def wrap_client(self, raw: Any) -> Any:
        return _WrappedPydanticAIModel(raw, self)

    async def _request(
        self,
        raw: Any,
        messages: Any,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Any:
        provider = _detect_provider(raw)
        model = _get_model_name(raw)

        if await self._kill.is_killed(self._session_id):
            reason = await self._kill.reason_for(self._session_id) or "session killed"
            self._audit.write(KillEvent(
                ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
                seq=0, prev_hash="x", reason=reason,
            ))
            raise LeashKilled(rule_id="kill:registry", reason=reason)

        if self._engine is not None:
            cumulative_now = await self._budget.cumulative_usd()
            ctx = PolicyContext(
                cumulative_usd=cumulative_now,
                budget_cap_usd=self._budget._hard,
                soft_cap_usd=self._budget._soft,
                tenant_id=self._tenant_id,
            )
            call_obj = ToolCall(
                tool="pydantic_ai.request",
                args={"model": model, "messages": messages},
                session_id=self._session_id,
                tenant_id=self._tenant_id,
            )
            decision = self._engine.evaluate(call_obj, ctx)
            if decision.action == "hitl":
                if self._hitl_gate is None:
                    raise LeashRejectedByHuman(
                        rule_id=decision.rule_id,
                        reason="hitl: no gate configured (set hitl_gate= on Firewall)",
                    )
                await self._hitl_gate.request(call_obj, decision)

        if self._pii_redactor is not None:
            messages = self._pii_redactor.redact_args({"messages": messages})["messages"]

        result = await raw.request(messages, *args, **kwargs)

        in_t, out_t = _extract_tokens(result)
        state = await self._budget.charge(
            provider=provider, model=model,
            in_tokens=in_t, out_tokens=out_t,
        )

        self._audit.write(ModelCall(
            ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
            seq=0, prev_hash="x",
            provider=provider, model=model,
            input_tokens=in_t, output_tokens=out_t,
            cost_usd=state.cumulative_usd,
            request_hash=_hash({"model": model, "messages": messages}),
            response_hash=_hash(result),
        ))

        if self._budget._hard is not None and state.cumulative_usd > self._budget._hard:
            raise LeashKilled(
                rule_id="budget:hard_cap",
                reason=(
                    f"cumulative ${state.cumulative_usd:.4f} "
                    f"exceeds cap ${self._budget._hard:.4f}"
                ),
            )

        return result


__all__ = ["PydanticAIAdapter"]
