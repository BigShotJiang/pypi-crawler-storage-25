"""MCP (Model Context Protocol) adapter — wraps ClientSession.call_tool().

Duck-typed: no mcp import at module level.

Shape required:
    async client.call_tool(name: str, arguments: dict) -> CallToolResult-like

MCP tool calls don't consume LLM tokens (no budget charge) but they DO need:
  - kill-switch enforcement (an agent killed mid-flight shouldn't keep calling tools)
  - policy engine (BlockedPatterns / BlockedSql / BlockedShell on args, deny tools by name)
  - PII redaction on outgoing arguments
  - HITL gates on dangerous tools
  - audit trail (ToolCallEvent)

The wrapped session preserves all other attributes/methods (list_tools, etc).
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
from typing import Any

from ..audit.schema import KillEvent, ToolCallEvent
from ..audit.writer import AuditWriter
from ..hitl.gate import HitlGate
from ..kill.registry import KillRegistry
from ..policy.engine import PolicyEngine
from ..policy.pii import PiiRedactor
from ..types import LeashKilled, LeashRejectedByHuman, PolicyContext, ToolCall


def _now_iso() -> str:
    return _dt.datetime.now(_dt.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _hash(payload: Any) -> str:
    try:
        s = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    except TypeError:
        s = str(payload)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


class _WrappedMcpSession:
    def __init__(self, raw: Any, adapter: MCPAdapter) -> None:
        self._raw = raw
        self._adapter = adapter

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        return await self._adapter._call_tool(self._raw, name, arguments or {})

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


class MCPAdapter:
    name = "mcp"

    def __init__(
        self,
        *,
        session_id: str,
        audit: AuditWriter,
        kill: KillRegistry,
        tenant_id: str | None = None,
        engine: PolicyEngine | None = None,
        pii_redactor: PiiRedactor | None = None,
        hitl_gate: HitlGate | None = None,
    ) -> None:
        self._session_id = session_id
        self._tenant_id = tenant_id
        self._audit = audit
        self._kill = kill
        self._engine = engine
        self._pii_redactor = pii_redactor
        self._hitl_gate = hitl_gate

    def wrap_client(self, raw: Any) -> Any:
        return _WrappedMcpSession(raw, self)

    async def _call_tool(
        self, raw: Any, name: str, arguments: dict[str, Any]
    ) -> Any:
        # 1. Kill check.
        if await self._kill.is_killed(self._session_id):
            reason = await self._kill.reason_for(self._session_id) or "session killed"
            self._audit.write(KillEvent(
                ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
                seq=0, prev_hash="x", reason=reason,
            ))
            raise LeashKilled(rule_id="kill:registry", reason=reason)

        # 1b. Policy engine.
        if self._engine is not None:
            ctx = PolicyContext(
                cumulative_usd=0.0,
                budget_cap_usd=None,
                soft_cap_usd=None,
                tenant_id=self._tenant_id,
            )
            call_obj = ToolCall(
                tool=name,
                args=arguments,
                session_id=self._session_id,
                tenant_id=self._tenant_id,
            )
            decision = self._engine.evaluate(call_obj, ctx)
            if decision.action == "hitl":
                if self._hitl_gate is None:
                    raise LeashRejectedByHuman(
                        rule_id=decision.rule_id,
                        reason="hitl: no gate configured (set hitl_gate= on Firewall)",
                    )
                await self._hitl_gate.request(call_obj, decision)

        # 1c. PII redaction of arguments.
        if self._pii_redactor is not None:
            arguments = self._pii_redactor.redact_args(arguments)

        # 2. Call underlying MCP session.
        result = await raw.call_tool(name, arguments)

        # 3. Audit.
        self._audit.write(ToolCallEvent(
            ts=_now_iso(), session_id=self._session_id, tenant_id=self._tenant_id,
            seq=0, prev_hash="x",
            tool=name,
            request_hash=_hash({"tool": name, "arguments": arguments}),
            response_hash=_hash(getattr(result, "content", result)),
        ))

        return result


__all__ = ["MCPAdapter"]
