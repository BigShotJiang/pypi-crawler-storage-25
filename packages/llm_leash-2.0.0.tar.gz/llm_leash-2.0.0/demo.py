"""5-line demo of llm-leash.

Runs a fake Anthropic-shaped client through a Firewall with a tiny
budget cap. Expected to exit cleanly after llm-leash blocks the third
call, prints a savings summary, and writes a chained audit log.

Usage:
    python demo.py [audit_path]
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Any

from llm_leash import Firewall, LeashKilled

# ── Fake Anthropic client (the demo runs offline) ────────────────────

@dataclass
class _Usage:
    input_tokens: int
    output_tokens: int


@dataclass
class _Response:
    model: str
    usage: _Usage
    content: list[dict[str, Any]]


class _FakeMessages:
    def create(self, **kwargs: Any) -> _Response:
        return _Response(
            model=kwargs["model"],
            usage=_Usage(input_tokens=5_000, output_tokens=5_000),
            content=[{"type": "text", "text": "burning tokens..."}],
        )


class FakeAnthropic:
    """Stand-in for `anthropic.Anthropic()`. Same shape, no SDK needed."""
    def __init__(self) -> None:
        self.messages = _FakeMessages()


# ── 5-line demo ──────────────────────────────────────────────────────

def main(audit_path: str = "audit.jsonl") -> int:
    print("=" * 60)
    print("llm-leash demo — runaway agent meets a $0.50 budget cap")
    print("=" * 60)

    fw = Firewall(budget_usd=0.50, audit_log=audit_path, session_id="demo")
    client = fw.wrap(FakeAnthropic())  # ← line 2

    call = 0
    try:
        while True:
            call += 1
            client.messages.create(
                model="claude-opus-4-7",
                max_tokens=5_000,
                messages=[{"role": "user", "content": "keep going"}],
            )
            print(f"  call {call:>2}: ok")
    except LeashKilled as e:                       # ← line 3
        print(f"  call {call:>2}: BLOCKED — {e.reason}")

    print("=" * 60)
    print(f"Audit log: {audit_path}  (run `llm-leash verify {audit_path}`)")
    print("Saved you the rest. Done.")
    return 0


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "audit.jsonl"
    sys.exit(main(path))
