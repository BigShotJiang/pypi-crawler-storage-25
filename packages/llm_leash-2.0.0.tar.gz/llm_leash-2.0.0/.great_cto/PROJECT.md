# llm-leash

## Type
primary: library-sdk
secondary: agent-platform
archetype: devtools
approval-level: gates-only
review_mode: auto

## Stack
- python: 3.11.8 (supports 3.11–3.13)
- build-backend: hatchling>=1.21
- test: pytest>=8.0, pytest-asyncio>=0.24, hypothesis>=6.100, vcrpy>=6.0
- lint: ruff>=0.6
- types: mypy>=1.10 (strict)
- optional-anthropic: anthropic>=0.40
- optional-openai: openai>=1.50
- optional-langgraph: langgraph>=0.2
- optional-crewai: crewai>=0.80
- optional-redis: redis>=5.0
- infra: none (library, no server infra)

## Domain
agent-safety, llm-cost-control, audit-compliance, kill-switch, human-in-the-loop

## Compliance signals
- EU AI Act Article 12 (audit log evidence)
- SOC 2 Type II (planned v1.0)
- Zero runtime deps core (non-negotiable per PRODUCT.md)

## Env
- no runtime env vars required for core
- AUDIT_LOG_PATH: optional, path to JSONL audit file
- REDIS_URL: optional, for RedisStore / RedisKillRegistry

## L3
p0-threshold: test_suite_failures > 0
p1-threshold: mypy_errors > 0
error-log: (no server — library; errors raised as LeashBlocked / LeashKilled)

## Team
size: 1
authors: avelikiy@users.noreply.github.com

## Last Audit
date: 2026-05-16
findings: P0:5 P1:5 P2:4 P3:0
next-audit: 2026-08-14
