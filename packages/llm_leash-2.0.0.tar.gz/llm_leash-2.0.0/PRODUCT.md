# llm-leash — Product Definition

**Status:** Draft v0.2 · 2026-05-16 · positioning revised after competitive scan
**Author:** Alexander Velikiy

## What changed in v0.2

Competitive scan (Invariant Labs, NeMo Guardrails, Guardrails AI,
LlamaFirewall, Prompt-Guard) showed that **the content-safety layer is
crowded.** Tool-call interception with pattern matching is solved by
Invariant; prompt-injection detection by LlamaFirewall + Prompt-Guard;
I/O validation by Guardrails AI; dialog rails by NeMo.

So `llm-leash` is **not** another safety scanner. It is the **boring,
uncontested layer** that every one of those tools depends on but none
of them owns:

> **llm-leash is the cost-and-audit control plane for LLM agents.**
> Hard USD budget. Immutable audit log. Kill switch. Human-in-the-loop.

The safety scanners (Invariant, LlamaFirewall) are *callable from
inside* llm-leash's policy engine. We are not a competitor to them.
We are the enforcement-and-accounting layer beneath them.

## One-liner

The cost ceiling, audit log, and kill switch your LLM agent should
never run without. 5 lines. Open source. Reads like Finance and Legal
wrote the spec.

## Elevator pitch — the four scenarios

You ship agents to prod. Four things keep your team up at night. Other
tools cover none of them as a primary feature.

1. **The runaway bill.** A tool retries 1,400 times. The agent spends
   $2,387 in 14 minutes. You find out when the invoice arrives. →
   `llm-leash` enforces a hard per-session USD cap. Soft cap warns,
   hard cap kills the run.

2. **The auditor's question.** "Show me every action this agent took
   for customer X between Mar 1 and Apr 30." Your Langfuse retention is
   30 days. Your CloudWatch logs don't have token counts. → `llm-leash`
   writes an immutable JSONL of every tool call, model call, token
   count, cost, decision, redaction event, optionally hashed I/O.
   `jq`-able. Months of retention. EU AI Act Article 12 evidence pack.

3. **The hot fix at 2am.** Agent is doing something wrong, you don't
   know what, you need to stop it *now*. → `llm-leash` has a
   process-level kill switch (HTTP, signal, or session-id from CLI).
   Every wrapped agent polls the kill registry on each tool call. SLA:
   ≤300ms from kill to next-action-blocked.

4. **The confidence gate.** Agent wants to send a $4,000 wire transfer
   or delete a customer record. → `llm-leash` HITL hook: any tool
   call matching a policy can be queued for human approval via webhook,
   Slack, or async resume. Default-deny on timeout.

Optional add-ons (off by default, opt-in by config):

- **Permission engine** — allow-list / deny-list of tool calls with
  regex/AST patterns on arguments. Yes, the same surface as Invariant,
  but library-shaped, not proxy-shaped, and integrated with budget.
- **PII redaction** — pre-tool-dispatch redaction of common patterns
  (SSN, credit-card, IBAN, custom regex). Configurable.
- **Safety scanner adapters** — call out to LlamaFirewall /
  Prompt-Guard / Invariant for content-layer checks. Their model, our
  enforcement-and-accounting wrapper.

## Who it is for — sharpened

| Persona | Pain | Buys |
|---|---|---|
| **Finance / FP&A at AI startup** | "Engineering spent $47K on tokens last month. I don't know why." | OSS lib (cost cap) → managed budget dashboard SaaS |
| **Platform engineer at Series B** | "We need to deploy 6 agents to prod. Compliance is blocking us." | OSS lib → SOC 2 audit-log SaaS |
| **CISO at regulated org (fintech/health/gov)** | "EU AI Act Aug 2026. Article 12 requires evidence. We have none." | Enterprise: signed audit log, BAA, tenant isolation, retention |
| **Solo dev / indie** | "I don't want to wake up to a $5K bill." | OSS lib. Free. Stars the repo. Tells friends. |
| **Red-team / pentester** | "How do I prove this agent can be coerced into spending money?" | OSS lib + replay CLI. Free. Generates great blog posts. |

Notice: three of five buyers don't care about prompt injection at all.
They care about money, paperwork, and the panic button.

## What it is NOT — explicit non-goals

- **Not a prompt-injection classifier.** Call Prompt-Guard from inside
  a policy if you need that.
- **Not a content guardrail.** Call NeMo / Guardrails AI from inside a
  policy if you need that.
- **Not an eval framework.** Use PromptFoo / DeepEval.
- **Not an observability platform.** Use Langfuse / LangSmith /
  Helicone. Our audit log is compliance evidence, not product
  analytics. JSONL ships into theirs in one cmd.
- **Not a model router.** Use LiteLLM / OpenRouter. We respect their
  cost reporting and enforce caps on top.
- **Not an agent framework.** We wrap whatever you already have.

## Wedge map (post-scan)

```
                        Content layer        Action layer
                        ─────────────        ────────────
   Pattern detection    LlamaFirewall        Invariant (proxy)
                        Prompt-Guard         llm-leash (lib)  ←
                        NeMo
                        Guardrails AI

   Cost enforcement     —                    llm-leash  ★
   Audit (compliance)   —                    llm-leash  ★
   Kill switch          —                    llm-leash  ★
   HITL queue           —                    llm-leash  ★
   Observability        Langfuse (read)      Langfuse / LangSmith
                                             (read-only)
```

★ = currently uncontested. This is where we lead.

## Differentiation from the closest neighbours

- **vs Invariant Labs:** Invariant is a *proxy/gateway*. You point
  your agent at it. llm-leash is a *library* — `from llm_leash
  import Firewall; fw.wrap(agent)`. No network hop, no separate
  process, no proxy config. Also: Invariant has no USD budgets, no
  kill switch, no compliance-shaped audit log. We integrate with
  Invariant's rule format (import their .rules files) instead of
  rewriting their pattern catalog.
- **vs LlamaFirewall:** LlamaFirewall is a *scanner suite* — input
  prompt classifier, alignment check, code shield. We are an
  *enforcement and accounting wrapper*. Use both: scanners on the
  content, llm-leash on the actions.
- **vs Langfuse / LangSmith:** Their job is *understanding* (traces,
  spans, evals). Our job is *enforcement* (block, kill, cap) and
  *evidence* (signed JSONL). They're the dashboard; we're the
  fuse-box.

## Killer demo (30 seconds, post-pivot)

```python
from llm_leash import Firewall
from anthropic import Anthropic

fw = Firewall(
    budget_usd=2.00,                  # hard cap, kills on exceed
    budget_soft_usd=1.50,             # warning threshold
    audit_log="audit.jsonl",          # append-only, hash-chained
    kill_switch="redis://localhost",  # poll on every tool call
    hitl_webhook="https://you.com/approve",
)

agent = fw.wrap(Anthropic())
agent.messages.create(model="claude-sonnet-4-6", messages=[...])
```

The terminal:
```
[llm-leash] session=s_8a3f model_call cost=$0.0042 cumulative=$0.0042
[llm-leash] session=s_8a3f tool=bash arg="ls /" decision=ALLOW
[llm-leash] session=s_8a3f model_call cost=$0.038  cumulative=$0.94
[llm-leash] session=s_8a3f SOFT_BUDGET_EXCEEDED  cumulative=$1.51
[llm-leash] session=s_8a3f tool=wire_transfer amount=$4000
              policy=hitl reason="amount>$500"  decision=PENDING_HUMAN
[llm-leash] session=s_8a3f human_approval received=APPROVE  decision=ALLOW
[llm-leash] session=s_8a3f model_call cost=$0.067  cumulative=$2.01
[llm-leash] session=s_8a3f HARD_BUDGET_EXCEEDED cumulative=$2.01 cap=$2.00
              decision=KILL
```

Then `llm-leash replay audit.jsonl --session s_8a3f` shows the full
timeline. Hash-chained, so tampering shows up as a broken chain.

This demo is more boring than "agent tries `rm -rf` → BLOCK" — but it
hits the actual nerve in B2B: **money and accountability**.

## Pricing (unchanged from v0.1)

| Tier | Who | What | Price |
|---|---|---|---|
| **OSS** | everyone | full firewall, JSONL, replay CLI | $0 forever, MIT |
| **Cloud** | platform teams | hosted audit log, search, alerts, retention | $20 / seat / mo |
| **Enterprise** | regulated | SAML, tenant isolation, signed log, BAA, AI-Act pack | $50K+ / yr |

## Distribution (sharpened)

- **Day 0 — Show HN:** "llm-leash — your AI agent should not be able
  to spend $5,000 without asking" + the budget-cap demo.
- **Day 7 — content:** "We let an LLM agent loose on 100 prod tasks
  with no budget cap. Here's what happened." Public dataset, replayable.
- **Week 2 — adapter blitz:** plugins for LangGraph, CrewAI, OpenHands,
  Pydantic-AI, MCP, OpenAI Assistants. One PR per repo with a
  one-pager.
- **Month 2 — compliance landing:** EU AI Act Article 12 evidence-pack
  page. Direct outreach: 10 DACH fintechs, 10 EU health-tech.
- **CVE-driven loop:** every CVE in any agent framework → "would
  llm-leash have logged + blocked this? yes, here's the rule." Free
  growth.

## Non-negotiables

1. **OSS firewall, MIT.** Budgets and audit are *never* paywalled.
2. **No phone-home.** Audit log local by default. SaaS opt-in by URL.
3. **JSONL, hash-chained.** Compatible with `jq`, `duckdb`,
   anything-that-reads-lines.
4. **One import, one class.** `from llm_leash import Firewall`.
5. **Adapters ≤300 LOC each.** If they grow, the core is wrong.
6. **Async-first, sync-compatible.**
7. **Zero deps for core.** stdlib only. Adapters bring their own deps.

## Decisions deferred to ADRs

- **ADR-001** Python-first or polyglot? (Python-first; TS in v0.3)
- **ADR-002** Policy engine: pure-Python or Rego/OPA? (Python v0.1; OPA optional later)
- **ADR-003** Audit log: hash chain only, or hash-chain + Merkle root + signed batches?
- **ADR-004** Cost model: token-based estimation, or strict per-provider price tables?
- **ADR-005** Kill switch transport: Redis pubsub, HTTP poll, or signal? (Probably all three, plug-in.)
- **ADR-006** HITL: webhook only, or built-in Slack/Discord/email senders?

## Risks worth naming

- **Risk: this is unsexy.** "Budget caps + audit logs" doesn't trend
  on HN as easily as "stop your agent from running `rm -rf`". The
  killer-demo script must lead with the *money* line, not the *rm*
  line, to convert the boring story into a viral one.
- **Risk: SaaS is the real product.** OSS lib is free forever and may
  cap at ~3-8K⭐. Revenue requires audit-log SaaS to be sticky enough
  that fintechs actually pay. This is a separate engineering bet.
- **Risk: Invariant pivots to library form.** They could. Counter:
  ship adapters and audit-log SaaS faster, and partner with them on
  rule compatibility rather than competing on pattern catalogs.
- **Risk: EU AI Act effective date slips.** If Aug 2026 → 2027, the
  compliance urgency softens. Counter: position around SOC 2 + GDPR
  Article 30 (record of processing activities), both already in force.
