"""Calculate Extended Spin."""

import numpy as np
import xarray as xr
from numpy.typing import NDArray

from imap_processing.ultra.constants import UltraConstants
from imap_processing.ultra.l1b.ultra_l1b_culling import (
    count_rejected_events_per_spin,
    expand_bin_flags_to_spins,
    flag_attitude,
    flag_high_energy,
    flag_hk,
    flag_imap_instruments,
    flag_low_voltage,
    flag_rates,
    flag_spectral_events,
    flag_statistical_outliers,
    flag_upstream_ion,
    get_binned_energy_ranges,
    get_binned_spins_edges,
    get_energy_histogram,
    get_energy_range_flags,
    get_pulses_per_spin,
)
from imap_processing.ultra.l1c.l1c_lookup_utils import build_energy_bins
from imap_processing.ultra.utils.ultra_l1_utils import create_dataset

FILLVAL_UINT16 = 65535
FILLVAL_FLOAT32 = -1.0e31


def calculate_extendedspin(
    dict_datasets: dict[str, xr.Dataset],
    de_dataset: xr.Dataset,
    name: str,
    instrument_id: int,
) -> xr.Dataset:
    """
    Create dataset with defined datatypes for Extended Spin Data.

    Parameters
    ----------
    dict_datasets : dict
        Dictionary containing all the datasets.
    de_dataset : xarray.Dataset
        Dataset containing the direct event data.
    name : str
        Name of the dataset.
    instrument_id : int
        Instrument ID.

    Returns
    -------
    extendedspin_dataset : xarray.Dataset
        Dataset containing the data.
    """
    aux_dataset = dict_datasets[f"imap_ultra_l1a_{instrument_id}sensor-aux"]
    rates_dataset = dict_datasets[f"imap_ultra_l1a_{instrument_id}sensor-rates"]
    status_dataset = dict_datasets[f"imap_ultra_l1b_{instrument_id}sensor-status"]

    extendedspin_dict = {}
    rates_qf, spin, energy_bin_geometric_mean, n_sigma_per_energy = flag_rates(
        de_dataset["spin"].values,
        de_dataset["energy"].values,
    )
    count_rates, _, _counts, _ = get_energy_histogram(
        de_dataset["spin"].values, de_dataset["energy"].values
    )
    attitude_qf, spin_rates, spin_period, spin_starttime = flag_attitude(
        de_dataset["spin"].values, aux_dataset
    )
    # TODO: We will add to this later
    hk_qf = flag_hk(de_dataset["spin"].values)
    inst_qf = flag_imap_instruments(de_dataset["spin"].values)

    spin_bin_size = UltraConstants.SPIN_BIN_SIZE
    spin_tbin_edges = get_binned_spins_edges(
        spin, spin_period, spin_starttime, spin_bin_size
    )
    # Calculate goodtime quality flags.
    # The culling algorithms should be called in the following order
    # 1. Low voltage
    # 2. High energy (energy dependent)
    # 3. Upstream ion (with first set of energy channels)
    # 4. Upstream ion (with second set of energy channels)
    # 5. Spectral cull
    # 6. Statistical outliers (energy dependent)
    voltage_qf = flag_low_voltage(spin_tbin_edges, status_dataset)
    # Get energy bins used at l1c
    intervals, _, _ = build_energy_bins()
    # Get the energy ranges
    energy_ranges = get_binned_energy_ranges(intervals)
    energy_bin_flags = get_energy_range_flags(energy_ranges)
    # Calculate the high energy quality flags
    energy_thresholds = UltraConstants.HIGH_ENERGY_CULL_THRESHOLDS
    high_energy_qf = flag_high_energy(
        de_dataset,
        spin_tbin_edges,
        energy_ranges,
        voltage_qf,
        energy_thresholds,
        instrument_id,
    )
    # For the following culls, mask the spins that have already been flagged for
    # low voltage
    mask = np.repeat(
        voltage_qf[np.newaxis, :], len(energy_ranges) - 1, axis=0
    )  # Shape (n_energy_bins, n_spins_bins)
    upstream_ion_qf_1 = flag_upstream_ion(
        de_dataset,
        spin_tbin_edges,
        energy_ranges,
        mask,
        UltraConstants.UPSTREAM_ION_ENERGY_CHANNELS_1,
        instrument_id,
    )
    upstream_ion_qf_2 = flag_upstream_ion(
        de_dataset,
        spin_tbin_edges,
        energy_ranges,
        mask,
        UltraConstants.UPSTREAM_ION_ENERGY_CHANNELS_2,
        instrument_id,
    )
    spectral_qf = flag_spectral_events(
        de_dataset,
        spin_tbin_edges,
        energy_ranges,
        UltraConstants.SPECTRAL_ENERGY_CHANNELS,
        instrument_id,
    )
    # Update mask to include high energy,  upstream ion flags and spectral flags
    # before flagging statistical outliers
    mask = mask | upstream_ion_qf_1 | upstream_ion_qf_2 | spectral_qf | high_energy_qf
    stat_outliers_qf, _, _, _ = flag_statistical_outliers(
        de_dataset,
        spin_tbin_edges,
        energy_ranges,
        mask,
        instrument_id,
    )
    # Get the number of pulses per spin.
    pulses = get_pulses_per_spin(aux_dataset, rates_dataset)

    # Track rejected events in each spin based on
    # quality flags in de l1b data.
    rejected_counts = count_rejected_events_per_spin(
        de_dataset["spin"].values,
        de_dataset["quality_scattering"].values,
        de_dataset["quality_outliers"].values,
    )

    # These will be the coordinates.
    extendedspin_dict["spin_number"] = spin
    extendedspin_dict["energy_bin_geometric_mean"] = energy_bin_geometric_mean

    extendedspin_dict["ena_rates"] = count_rates
    extendedspin_dict["ena_rates_threshold"] = n_sigma_per_energy
    extendedspin_dict["spin_start_time"] = spin_starttime
    extendedspin_dict["spin_period"] = spin_period
    extendedspin_dict["spin_rate"] = spin_rates

    # Get index of pulses.unique_spins corresponding to each spin.
    idx: NDArray[np.intp] = np.searchsorted(pulses.unique_spins, spin)

    # Validate that the spin values match
    valid = (idx < pulses.unique_spins.size) & (pulses.unique_spins[idx] == spin)

    start_per_spin: np.ndarray = np.full(len(spin), FILLVAL_FLOAT32, dtype=np.float32)
    stop_per_spin: np.ndarray = np.full(len(spin), FILLVAL_FLOAT32, dtype=np.float32)
    coin_per_spin: np.ndarray = np.full(len(spin), FILLVAL_FLOAT32, dtype=np.float32)

    # Fill only the valid ones
    start_per_spin[valid] = pulses.start_per_spin[idx[valid]]
    stop_per_spin[valid] = pulses.stop_per_spin[idx[valid]]
    coin_per_spin[valid] = pulses.coin_per_spin[idx[valid]]

    # To be consistent with the ULTRA IT implementation, apply the low voltage mask
    # to the high energy and upstream ion flags
    upstream_ion_qf_2 |= voltage_qf
    upstream_ion_qf_1 |= voltage_qf
    high_energy_qf |= voltage_qf
    spectral_qf |= voltage_qf
    # high energy and statistical outlier flags are energy dependent boolean arrays
    # with shape (n_energy_bins, n_spin_bins). We want to collapse the energy dimension
    # using a bitwise OR to get a single boolean flag per spin.
    high_energy_qf = np.bitwise_or.reduce(
        high_energy_qf * energy_bin_flags[:, np.newaxis], axis=0
    )
    stat_outliers_qf = np.bitwise_or.reduce(
        stat_outliers_qf * energy_bin_flags[:, np.newaxis], axis=0
    )
    # Low voltage and upstream ion flags are shape (n_spin_bins,) but we want to
    # convert from a boolean to a bitwise flag to be consistent with the other flags,
    # where each spin that is flagged will have the bitflag of all the energy flags
    # combined.
    combined_flags = np.bitwise_or.reduce(energy_bin_flags)
    voltage_qf = voltage_qf * combined_flags
    upstream_ion_qf_1 = upstream_ion_qf_1 * combined_flags
    upstream_ion_qf_2 = upstream_ion_qf_2 * combined_flags
    spectral_qf = spectral_qf * combined_flags
    # Expand binned quality flags to individual spins.
    high_energy_qf = expand_bin_flags_to_spins(len(spin), high_energy_qf, spin_bin_size)
    voltage_qf = expand_bin_flags_to_spins(len(spin), voltage_qf, spin_bin_size)
    spectral_qf = expand_bin_flags_to_spins(len(spin), spectral_qf, spin_bin_size)
    upstream_ion_qf_1 = expand_bin_flags_to_spins(
        len(spin), upstream_ion_qf_1, spin_bin_size
    )
    upstream_ion_qf_2 = expand_bin_flags_to_spins(
        len(spin), upstream_ion_qf_2, spin_bin_size
    )
    stat_outliers_qf = expand_bin_flags_to_spins(
        len(spin), stat_outliers_qf, spin_bin_size
    )
    # account for rates spins which are not in the direct event spins
    extendedspin_dict["start_pulses_per_spin"] = start_per_spin
    extendedspin_dict["stop_pulses_per_spin"] = stop_per_spin
    extendedspin_dict["coin_pulses_per_spin"] = coin_per_spin
    extendedspin_dict["rejected_events_per_spin"] = rejected_counts
    extendedspin_dict["quality_attitude"] = attitude_qf
    extendedspin_dict["quality_ena_rates"] = rates_qf
    extendedspin_dict["quality_hk"] = hk_qf
    extendedspin_dict["quality_instruments"] = inst_qf
    extendedspin_dict["quality_low_voltage"] = voltage_qf  # shape (nspin,)
    extendedspin_dict["quality_upstream_ion_1"] = upstream_ion_qf_1  # shape (nspin,)
    extendedspin_dict["quality_upstream_ion_2"] = upstream_ion_qf_2  # shape (nspin,)
    extendedspin_dict["quality_spectral"] = spectral_qf  # shape (nspin,)
    extendedspin_dict["quality_statistics"] = stat_outliers_qf  # shape (nspin,)
    extendedspin_dict["quality_high_energy"] = high_energy_qf  # shape (nspin,)
    # ISTP requires stable dimension sizes, so this field must always remain size 16.
    # If fewer bins are used, pad the remaining entries with 0.
    energy_flags: np.ndarray = np.full(
        UltraConstants.MAX_ENERGY_RANGES, 0, dtype=np.uint16
    )
    energy_flags[: len(energy_bin_flags)] = energy_bin_flags
    extendedspin_dict["energy_range_flags"] = energy_flags
    extendedspin_dict["energy_range_flags_dim"] = np.arange(
        UltraConstants.MAX_ENERGY_RANGES
    )

    # Initialize array of energy range edges with fill value, then fill in the valid
    # energy ranges. Set the length to be the max number of energy bins we expect to
    # use for culling. The number of edges is one more than the number of bins (17).
    ranges: np.ndarray = np.full(
        (UltraConstants.MAX_ENERGY_RANGE_EDGES,), FILLVAL_FLOAT32, dtype=np.float32
    )
    ranges[: len(energy_ranges)] = energy_ranges
    extendedspin_dict["energy_range_edges"] = ranges
    extendedspin_dict["energy_range_edges_dim"] = np.arange(
        UltraConstants.MAX_ENERGY_RANGE_EDGES
    )

    extendedspin_dataset = create_dataset(extendedspin_dict, name, "l1b")
    return extendedspin_dataset
