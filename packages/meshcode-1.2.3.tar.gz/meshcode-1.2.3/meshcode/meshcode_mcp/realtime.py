"""Supabase Realtime listener for the MeshCode MCP server.

Connects to Supabase Realtime via WebSocket (no supabase-py dep — uses
the `websockets` package directly to keep the install light).

When a new mc_message INSERT arrives for the current agent, it:
  1. Pushes the message into an in-memory deque (consumed by meshcode_check tool)
  2. Calls the registered notify_callback (FastMCP session.send_resource_updated)
"""
import asyncio
import json
import logging
from collections import deque
from typing import Any, Awaitable, Callable, Deque, Dict, Optional

try:
    import websockets
    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False

log = logging.getLogger("meshcode-mcp.realtime")


class RealtimeListener:
    """Connects to Supabase Realtime and forwards mc_messages INSERTs to a callback."""

    def __init__(
        self,
        supabase_url: str,
        supabase_key: str,
        project_id: str,
        agent_name: str,
        notify_callback: Optional[Callable[[Dict], Awaitable[None]]] = None,
    ):
        self.supabase_url = supabase_url
        self.supabase_key = supabase_key
        self.project_id = project_id
        self.agent_name = agent_name
        self.notify_callback = notify_callback

        # Last 100 unread messages — drained by meshcode_check tool
        self.queue: Deque[Dict] = deque(maxlen=100)
        self._task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()
        self._connected = False

    @property
    def ws_url(self) -> str:
        host = self.supabase_url.replace("https://", "").replace("http://", "").rstrip("/")
        return f"wss://{host}/realtime/v1/websocket?apikey={self.supabase_key}&vsn=1.0.0"

    async def start(self) -> None:
        if not WEBSOCKETS_AVAILABLE:
            log.warning("websockets package not installed — Realtime disabled")
            return
        if self._task and not self._task.done():
            return
        self._stop.clear()
        self._task = asyncio.create_task(self._run(), name="meshcode-realtime")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _run(self) -> None:
        """Outer loop: reconnect with exponential backoff on disconnect."""
        backoff = 1
        while not self._stop.is_set():
            try:
                await self._connect_and_listen()
                backoff = 1  # reset on clean disconnect
            except asyncio.CancelledError:
                return
            except Exception as e:
                log.warning(f"Realtime connection error: {e}; reconnecting in {backoff}s")
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=backoff)
                    return  # stop signaled
                except asyncio.TimeoutError:
                    pass
                backoff = min(backoff * 2, 30)

    async def _connect_and_listen(self) -> None:
        """Single connection lifecycle: connect, subscribe, listen."""
        async with websockets.connect(self.ws_url, ping_interval=20, ping_timeout=10) as ws:
            self._connected = True
            log.info(f"Realtime connected for agent={self.agent_name}")

            # Phoenix channel join: phoenix realtime topic
            topic = f"realtime:{self.project_id}-{self.agent_name}"
            join_msg = {
                "topic": topic,
                "event": "phx_join",
                "payload": {
                    "config": {
                        "postgres_changes": [
                            {
                                "event": "INSERT",
                                "schema": "meshcode",
                                "table": "mc_messages",
                                "filter": f"to_agent=eq.{self.agent_name}",
                            }
                        ]
                    }
                },
                "ref": "1",
            }
            await ws.send(json.dumps(join_msg))

            # Heartbeat task to keep the connection alive
            heartbeat_task = asyncio.create_task(self._heartbeat(ws))
            try:
                async for raw in ws:
                    if self._stop.is_set():
                        break
                    try:
                        msg = json.loads(raw)
                    except Exception:
                        continue
                    await self._handle_message(msg)
            finally:
                heartbeat_task.cancel()
                self._connected = False

    async def _heartbeat(self, ws) -> None:
        """Send phoenix heartbeats every 25s to keep the channel alive."""
        ref = 0
        while not self._stop.is_set():
            await asyncio.sleep(25)
            ref += 1
            try:
                await ws.send(json.dumps({
                    "topic": "phoenix",
                    "event": "heartbeat",
                    "payload": {},
                    "ref": str(ref),
                }))
            except Exception:
                return

    async def _handle_message(self, msg: Dict[str, Any]) -> None:
        event = msg.get("event")
        payload = msg.get("payload") or {}

        # postgres_changes payload structure:
        # {"event": "postgres_changes", "payload": {"data": {"record": {...}, "type": "INSERT", ...}}}
        if event == "postgres_changes":
            data = payload.get("data") or {}
            if data.get("type") == "INSERT":
                record = data.get("record") or {}
                if record.get("to_agent") == self.agent_name:
                    enriched = {
                        "from": record.get("from_agent"),
                        "type": record.get("type", "msg"),
                        "ts": record.get("created_at"),
                        "payload": record.get("payload", {}),
                        "id": record.get("id"),
                    }
                    self.queue.append(enriched)
                    log.info(f"new message from {enriched['from']}")
                    if self.notify_callback:
                        try:
                            await self.notify_callback(enriched)
                        except Exception as e:
                            log.warning(f"notify_callback failed: {e}")

    def drain(self) -> list:
        """Pop and return all queued messages."""
        out = list(self.queue)
        self.queue.clear()
        return out

    @property
    def is_connected(self) -> bool:
        return self._connected
