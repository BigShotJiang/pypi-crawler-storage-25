"""Run via: python -m meshcode_mcp serve"""
import sys
from .server import run_server


def main():
    args = sys.argv[1:]
    if args and args[0] == "serve":
        run_server()
    else:
        print("Usage: python -m meshcode_mcp serve", file=sys.stderr)
        print("       (env vars: MESHCODE_PROJECT, MESHCODE_AGENT, SUPABASE_URL, SUPABASE_KEY)", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
