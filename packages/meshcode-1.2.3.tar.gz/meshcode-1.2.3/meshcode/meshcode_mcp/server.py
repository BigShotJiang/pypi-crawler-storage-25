"""MeshCode MCP server — exposes meshcode tools to MCP clients (Claude Code, etc).

Tools:    meshcode_send, meshcode_broadcast, meshcode_read, meshcode_check,
          meshcode_status, meshcode_register, meshcode_set_status
Resources: meshcode://inbox, meshcode://board, meshcode://history

Run with:
    MESHCODE_PROJECT=my-app MESHCODE_AGENT=backend python -m meshcode_mcp serve
"""
import asyncio
import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

from . import backend as be
from .realtime import RealtimeListener

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print(
        "[meshcode-mcp] ERROR: mcp package not installed. Run: pip install 'mcp[cli]>=1.0'",
        file=sys.stderr,
    )
    sys.exit(2)

logging.basicConfig(level=logging.INFO, stream=sys.stderr,
                    format="[meshcode-mcp] %(message)s")
log = logging.getLogger("meshcode-mcp")


# ============================================================
# Server context — agent identity from env vars
# ============================================================

PROJECT_NAME = os.environ.get("MESHCODE_PROJECT", "")
AGENT_NAME = os.environ.get("MESHCODE_AGENT", "")
AGENT_ROLE = os.environ.get("MESHCODE_ROLE", "")

if not PROJECT_NAME or not AGENT_NAME:
    print(
        "[meshcode-mcp] ERROR: MESHCODE_PROJECT and MESHCODE_AGENT env vars required",
        file=sys.stderr,
    )
    sys.exit(2)


# Resolve project_id once at startup; auto-register the agent
_PROJECT_ID: Optional[str] = be.get_project_id(PROJECT_NAME)
if not _PROJECT_ID:
    print(f"[meshcode-mcp] ERROR: project '{PROJECT_NAME}' not found", file=sys.stderr)
    sys.exit(2)

_register_result = be.register_agent(PROJECT_NAME, AGENT_NAME, AGENT_ROLE or "MCP-connected agent")
if isinstance(_register_result, dict) and _register_result.get("error"):
    print(f"[meshcode-mcp] WARNING: register failed: {_register_result['error']}", file=sys.stderr)

# Flip to online so the dashboard reflects the live MCP session.
# Without this the agent stays in 'needs_setup' / 'offline' even though
# heartbeat is running. The set_status helper updates status + last_heartbeat.
try:
    be.set_status(_PROJECT_ID, AGENT_NAME, "online", "MCP session active")
except Exception as _e:
    print(f"[meshcode-mcp] WARNING: could not flip status to online: {_e}", file=sys.stderr)


# ============================================================
# Realtime listener (created in lifespan)
# ============================================================

_REALTIME: Optional[RealtimeListener] = None


async def _on_new_message(msg: Dict[str, Any]) -> None:
    """Best-effort: try to push an MCP resource-updated notification.

    If the underlying session supports send_resource_updated_notification,
    use it. If not (older MCP versions or unsupported), the message is
    still queued and meshcode_check / next-tool-call will surface it.
    """
    try:
        srv = mcp._mcp_server  # FastMCP exposes the lowlevel server here
        ctx = getattr(srv, "request_context", None)
        if ctx and getattr(ctx, "session", None):
            from pydantic import AnyUrl
            await ctx.session.send_resource_updated(AnyUrl("meshcode://inbox"))
            log.info(f"sent MCP resource_updated notification for msg from {msg.get('from')}")
    except Exception as e:
        log.debug(f"send_resource_updated unavailable: {e}")


async def _heartbeat_loop():
    while True:
        try:
            be.sb_rpc("mc_heartbeat", {"p_project_id": _PROJECT_ID, "p_agent_name": AGENT_NAME})
            log.debug(f"heartbeat ok for {AGENT_NAME}")
        except Exception as e:
            log.warning(f"heartbeat failed: {e}")
        await asyncio.sleep(30)


@asynccontextmanager
async def lifespan(_app):
    """Start the Realtime listener when the MCP server boots; stop on shutdown."""
    global _REALTIME
    _REALTIME = RealtimeListener(
        supabase_url=be.SUPABASE_URL,
        supabase_key=be.SUPABASE_KEY,
        project_id=_PROJECT_ID,
        agent_name=AGENT_NAME,
        notify_callback=_on_new_message,
    )
    await _REALTIME.start()
    hb_task = asyncio.create_task(_heartbeat_loop())
    log.info(f"lifespan started — Realtime + heartbeat (30s) active for {AGENT_NAME}")
    try:
        yield {"realtime": _REALTIME}
    finally:
        log.info("lifespan shutdown — stopping heartbeat + realtime")
        hb_task.cancel()
        try:
            await hb_task
        except asyncio.CancelledError:
            pass
        await _REALTIME.stop()


# ============================================================
# FastMCP server
# ============================================================

mcp = FastMCP(name=f"meshcode-{PROJECT_NAME}-{AGENT_NAME}", lifespan=lifespan)


# ----------------- TOOLS -----------------

@mcp.tool()
def meshcode_send(to: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Send a message to another agent in the meshwork.

    Args:
        to: Name of the recipient agent.
        payload: Structured message payload (use protocol keys: need/done/fyi/blocked).
    """
    return be.send_message(_PROJECT_ID, AGENT_NAME, to, payload, msg_type="msg")


@mcp.tool()
def meshcode_broadcast(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Send a message to ALL agents in the meshwork (except yourself).

    Args:
        payload: Structured message payload.
    """
    agents = be.get_board(_PROJECT_ID)
    sent = 0
    for a in agents:
        if a["name"] != AGENT_NAME:
            be.send_message(_PROJECT_ID, AGENT_NAME, a["name"], payload, msg_type="broadcast")
            sent += 1
    return {"broadcast": True, "agents_notified": sent}


@mcp.tool()
def meshcode_read() -> Dict[str, Any]:
    """Read all pending (unread) messages for this agent. Marks them as read and ACKs senders."""
    messages = be.read_inbox(_PROJECT_ID, AGENT_NAME)
    return {
        "count": len(messages),
        "messages": [
            {
                "from": m["from_agent"],
                "type": m.get("type", "msg"),
                "ts": m.get("created_at"),
                "payload": m.get("payload", {}),
            }
            for m in messages
        ],
    }


@mcp.tool()
def meshcode_check() -> Dict[str, Any]:
    """Quick poll: returns pending message count + any messages buffered by the
    Realtime listener since the last check.

    Use this to check if there's anything new without marking messages as read.
    Useful as the first call in a tool loop or after a long thinking phase.
    """
    pending = be.count_pending(_PROJECT_ID, AGENT_NAME)
    realtime_buffered = _REALTIME.drain() if _REALTIME else []
    return {
        "pending": pending,
        "agent": AGENT_NAME,
        "project": PROJECT_NAME,
        "realtime_connected": _REALTIME.is_connected if _REALTIME else False,
        "buffered": realtime_buffered,
    }


@mcp.tool()
def meshcode_status() -> Dict[str, Any]:
    """Get the meshwork status board: all agents with their status, role, and current task."""
    agents = be.get_board(_PROJECT_ID)
    return {
        "project": PROJECT_NAME,
        "agents": [
            {
                "name": a["name"],
                "role": a.get("role", ""),
                "status": a.get("status", "?"),
                "task": a.get("task", ""),
                "last_heartbeat": a.get("last_heartbeat"),
            }
            for a in agents
        ],
    }


@mcp.tool()
def meshcode_register(role: str = "") -> Dict[str, Any]:
    """Re-register this agent in the meshwork. Use if you got disconnected or
    want to update your role description.
    """
    return be.register_agent(PROJECT_NAME, AGENT_NAME, role or AGENT_ROLE)


@mcp.tool()
def meshcode_set_status(status: str, task: str = "") -> Dict[str, Any]:
    """Update your status in the board.

    Args:
        status: One of: working, idle, standby, blocked, done, online.
        task: Optional human-readable task description.
    """
    return be.set_status(_PROJECT_ID, AGENT_NAME, status, task)


@mcp.tool()
def meshcode_init(project: str, agent: str, role: str = "") -> Dict[str, Any]:
    """Re-initialize this MCP session for a different (project, agent). Use ONLY
    if you need to dynamically switch context — normally the env vars set at
    server start are correct.
    """
    global PROJECT_NAME, AGENT_NAME, AGENT_ROLE, _PROJECT_ID
    PROJECT_NAME = project
    AGENT_NAME = agent
    AGENT_ROLE = role
    pid = be.get_project_id(project)
    if not pid:
        return {"error": f"project '{project}' not found"}
    _PROJECT_ID = pid
    result = be.register_agent(project, agent, role or "MCP-connected agent")
    return {"ok": True, "project": project, "agent": agent, "register": result}


# ----------------- RESOURCES -----------------

@mcp.resource("meshcode://inbox")
def inbox_resource() -> str:
    """Current pending messages for this agent. Read-only — does NOT mark as read."""
    pending = be.sb_select(
        "mc_messages",
        f"project_id=eq.{_PROJECT_ID}&to_agent=eq.{AGENT_NAME}&read=eq.false",
        order="created_at.asc",
    )
    return json.dumps({
        "count": len(pending),
        "messages": [
            {
                "from": m["from_agent"],
                "type": m.get("type", "msg"),
                "ts": m.get("created_at"),
                "payload": m.get("payload", {}),
            }
            for m in pending
        ],
    }, indent=2)


@mcp.resource("meshcode://board")
def board_resource() -> str:
    """Snapshot of the meshwork board (all agents and their status)."""
    agents = be.get_board(_PROJECT_ID)
    return json.dumps({
        "project": PROJECT_NAME,
        "agents": agents,
    }, indent=2, default=str)


@mcp.resource("meshcode://history")
def history_resource() -> str:
    """Recent message history for this meshwork (last 20 non-ack messages)."""
    history = be.get_history(_PROJECT_ID, limit=20)
    return json.dumps({
        "project": PROJECT_NAME,
        "history": history,
    }, indent=2, default=str)


# ============================================================
# Entry point
# ============================================================

def run_server():
    """Start the MCP server on stdio (default for Claude Code)."""
    print(
        f"[meshcode-mcp] Starting server for {AGENT_NAME}@{PROJECT_NAME}",
        file=sys.stderr,
    )
    mcp.run()
