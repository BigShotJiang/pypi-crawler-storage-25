"""Per-client MCP server config writers for `meshcode setup <client>`.

Supported clients: claude-code, cursor, cline, claude-desktop.

Each writer:
1. Resolves the right config file path for the current OS.
2. Loads existing JSON (or empty dict) and merges the meshcode MCP server entry
   under "mcpServers". Never clobbers other entries.
3. Writes back atomically (temp file + rename).
4. Prints a success message with the path and "restart {client}" instructions.
"""
import json
import os
import platform
import sys
from pathlib import Path
from typing import Dict, Any


def _load_credentials() -> Dict[str, str]:
    creds_path = Path.home() / ".meshcode" / "credentials.json"
    if not creds_path.exists():
        print("[meshcode] ERROR: No credentials found. Run `meshcode login <api_key>` first.", file=sys.stderr)
        sys.exit(2)
    return json.loads(creds_path.read_text())


def _load_supabase_env() -> Dict[str, str]:
    """Read SUPABASE_URL/SUPABASE_KEY from env or ~/.meshcode/env."""
    url = os.environ.get("SUPABASE_URL", "")
    key = os.environ.get("SUPABASE_KEY", "")
    if not url or not key:
        env_file = Path.home() / ".meshcode" / "env"
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                line = line.strip()
                if line.startswith("export "):
                    line = line[7:]
                if "=" in line:
                    k, v = line.split("=", 1)
                    v = v.strip().strip('"').strip("'")
                    if k == "SUPABASE_URL" and not url:
                        url = v
                    elif k == "SUPABASE_KEY" and not key:
                        key = v
    if not url:
        url = "https://wwgzzmydrwrjgaebspdo.supabase.co"
    if not key:
        key = "sb_publishable_0qf0U1GURopPIxLR8Vu7eQ_5grflPP4"
    return {"SUPABASE_URL": url, "SUPABASE_KEY": key}


CLIENT_CONFIG_PATHS = {
    "claude-code": {
        "Darwin":  Path.home() / ".claude.json",
        "Linux":   Path.home() / ".claude.json",
        "Windows": Path.home() / ".claude.json",
    },
    "cursor": {
        "Darwin":  Path.home() / ".cursor" / "mcp.json",
        "Linux":   Path.home() / ".cursor" / "mcp.json",
        "Windows": Path.home() / ".cursor" / "mcp.json",
    },
    "cline": {
        "Darwin":  Path.home() / "Library" / "Application Support" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        "Linux":   Path.home() / ".config" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        "Windows": Path.home() / "AppData" / "Roaming" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
    },
    "claude-desktop": {
        "Darwin":  Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json",
        "Linux":   Path.home() / ".config" / "Claude" / "claude_desktop_config.json",
        "Windows": Path.home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json",
    },
}

CLIENT_DISPLAY_NAMES = {
    "claude-code":    "Claude Code",
    "cursor":         "Cursor",
    "cline":          "Cline (VS Code)",
    "claude-desktop": "Claude Desktop",
}


def _atomic_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(path)


def setup(client: str, project: str, agent: str, role: str = "") -> int:
    """Write MCP server config block for the given client. Returns 0 on success."""
    if client not in CLIENT_CONFIG_PATHS:
        print(f"[meshcode] ERROR: Unknown client '{client}'. Supported: {', '.join(CLIENT_CONFIG_PATHS)}", file=sys.stderr)
        return 2

    creds = _load_credentials()
    sb = _load_supabase_env()
    api_key = creds.get("api_key", "")

    os_name = platform.system()
    config_path = CLIENT_CONFIG_PATHS[client].get(os_name)
    if config_path is None:
        print(f"[meshcode] ERROR: '{client}' is not supported on {os_name}", file=sys.stderr)
        return 2

    existing: Dict[str, Any] = {}
    if config_path.exists():
        try:
            existing = json.loads(config_path.read_text())
        except json.JSONDecodeError:
            print(f"[meshcode] WARNING: {config_path} exists but is not valid JSON. Overwriting may break {CLIENT_DISPLAY_NAMES[client]}.", file=sys.stderr)
            return 2

    if not isinstance(existing, dict):
        existing = {}

    servers = existing.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        print(f"[meshcode] ERROR: 'mcpServers' in {config_path} is not an object", file=sys.stderr)
        return 2

    server_id = f"meshcode-{project}-{agent}"
    servers[server_id] = {
        "command": sys.executable or "python3",
        "args": ["-m", "meshcode.meshcode_mcp", "serve"],
        "env": {
            "MESHCODE_PROJECT": project,
            "MESHCODE_AGENT": agent,
            "MESHCODE_ROLE": role or "MCP-connected agent",
            "MESHCODE_API_KEY": api_key,
            "SUPABASE_URL": sb["SUPABASE_URL"],
            "SUPABASE_KEY": sb["SUPABASE_KEY"],
        },
    }

    _atomic_write_json(config_path, existing)

    display = CLIENT_DISPLAY_NAMES[client]
    print(f"[meshcode] MCP server '{server_id}' added to {display} config")
    print(f"[meshcode]   Path: {config_path}")
    print(f"[meshcode]   Restart {display} to load the server.")
    print(f"[meshcode]   Inside {display}, verify with /mcp — you should see '{server_id}' connected.")
    print(f"[meshcode]   Tools: meshcode_send, meshcode_check, meshcode_read, meshcode_status, meshcode_set_status, ...")
    return 0
