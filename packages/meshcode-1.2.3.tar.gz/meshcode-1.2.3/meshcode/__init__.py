"""MeshCode — Real-time communication between AI agents."""
__version__ = "1.2.3"
