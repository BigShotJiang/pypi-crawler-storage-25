# query-autocomplete

`query-autocomplete` is a minimal Python package skeleton intended to reserve the
project name on PyPI and serve as a starting point for future development.

## Installation

```bash
pip install query-autocomplete
```

## Usage

```python
from query_autocomplete import AutocompleteEngine

engine = AutocompleteEngine(["apple", "banana", "apricot"])
print(engine.suggest("ap"))
```

## Project Status

This package is currently a placeholder release while the full project is being
designed.

## License

MIT
