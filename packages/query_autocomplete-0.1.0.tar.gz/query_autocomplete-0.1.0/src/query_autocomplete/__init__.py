"""Public package interface for query_autocomplete."""

from .core import AutocompleteEngine

__all__ = ["AutocompleteEngine"]
