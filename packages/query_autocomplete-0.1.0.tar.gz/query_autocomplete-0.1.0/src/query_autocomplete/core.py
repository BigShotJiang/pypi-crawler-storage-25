"""Small starter implementation for query autocomplete experiments."""


class AutocompleteEngine:
    """Suggest values from a static collection based on a string prefix."""

    def __init__(self, entries):
        self._entries = [str(entry) for entry in entries]

    def suggest(self, prefix, limit=10):
        normalized = str(prefix).casefold()
        matches = [
            entry for entry in self._entries if entry.casefold().startswith(normalized)
        ]
        return matches[:limit]
