# Changelog

## 0.2.0 — 2026-05-16

Security hardening.

### Breaking

- `open_session(app, *, name=...)` no longer accepts a `commit` parameter.
  It was silently ignored — callers expecting auto-commit ran without one.
  Manage the session lifecycle (close/commit/rollback) yourself.

### Changed

- `Database.get` emits a WARNING when a non-`primary` engine is requested
  but only `primary` is registered, so silently-misrouted replicas are
  discoverable from logs.
- `run_migrations` raises a clear `RuntimeError` instead of nested-loop
  errors when invoked from inside a running event loop.
- The active-database registry uses `WeakKeyDictionary` to eliminate the
  `id(app)` ABA hazard.

## 0.1.0 — 2026-05-16

Initial release.

- Async engine + sessionmaker factory; SQLite-aware pool kwargs.
- `init_database(app, ...)` with three shapes: `url=`, `config=`, or `databases={...}`.
- Multi-database registry — register any number of named engines (`primary`, `replica`, shards). Replica falls back to primary when absent.
- DI: `Depends(get_session)`, `Depends(get_replica_session)`, `session_for(name)`. Auto-commit on success, rollback on exception.
- `Base`, `DataclassBase`, `TimestampMixin`, `UUIDMixin`.
- Healthchecks: `session_healthy`, `database_healthy`, `all_healthy`.
- Alembic helper `hawkapi_sqlalchemy.alembic.run_migrations` — handles both online and offline modes.
- Pytest helpers `temporary_database` / `temporary_session` (in-memory SQLite, schema lifecycle).
- Extras: `[postgres]` (asyncpg), `[mysql]` (aiomysql).
