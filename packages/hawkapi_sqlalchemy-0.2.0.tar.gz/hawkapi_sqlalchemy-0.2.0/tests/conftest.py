"""Shared fixtures — a tiny User model on top of a fresh in-memory database."""

from __future__ import annotations

from collections.abc import AsyncIterator

import pytest
from sqlalchemy import Integer, String
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from hawkapi_sqlalchemy import Base, Database, DatabaseConfig, TimestampMixin


class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False, default="")


@pytest.fixture
async def db() -> AsyncIterator[Database]:
    database = Database()
    database.add("primary", DatabaseConfig(url="sqlite+aiosqlite:///:memory:"))
    engine = database.get("primary").engine
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    try:
        yield database
    finally:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
        await database.dispose()


@pytest.fixture
async def session(db: Database) -> AsyncIterator[AsyncSession]:
    async with db.session() as sess:
        yield sess
