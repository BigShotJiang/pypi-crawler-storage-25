"""Helpers in hawkapi_sqlalchemy._testing."""

from __future__ import annotations

from sqlalchemy import select

from hawkapi_sqlalchemy import Base, temporary_database, temporary_session

from .conftest import User


async def test_temporary_database_creates_and_drops_schema() -> None:
    async with temporary_database(Base.metadata) as db:
        async with db.session() as sess:
            sess.add(User(email="a@b.c", name="A"))
        async with db.session() as sess:
            row = (await sess.execute(select(User))).scalar_one()
            assert row.email == "a@b.c"


async def test_temporary_session_yields_working_session() -> None:
    async with temporary_session(Base.metadata) as sess:
        sess.add(User(email="x@y.z", name="X"))
        await sess.flush()
        row = (await sess.execute(select(User))).scalar_one()
        assert row.name == "X"
