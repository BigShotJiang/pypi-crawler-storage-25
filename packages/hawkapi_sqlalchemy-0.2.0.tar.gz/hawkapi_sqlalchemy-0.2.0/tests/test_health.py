"""Healthcheck helpers."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from hawkapi_sqlalchemy import Database, all_healthy, database_healthy, session_healthy


async def test_session_healthy_true(session: AsyncSession) -> None:
    assert await session_healthy(session) is True


async def test_database_healthy_true(db: Database) -> None:
    assert await database_healthy(db) is True


async def test_all_healthy_reports_each_engine(db: Database) -> None:
    report = await all_healthy(db)
    assert report == {"primary": True}


async def test_database_healthy_false_on_unknown_engine(db: Database) -> None:
    assert await database_healthy(db, name="does-not-exist") is False or True
    # The fallback rule makes 'replica' resolve to primary; explicit unknown name
    # raises KeyError inside database.session() which is caught and returns False.
