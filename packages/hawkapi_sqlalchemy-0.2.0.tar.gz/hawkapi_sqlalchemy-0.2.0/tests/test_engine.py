"""Engine + sessionmaker creation."""

from __future__ import annotations

from hawkapi_sqlalchemy import DatabaseConfig, create_engine


async def test_create_engine_sqlite() -> None:
    eng = create_engine(DatabaseConfig(url="sqlite+aiosqlite:///:memory:"))
    assert eng.engine is not None
    assert eng.sessionmaker is not None
    await eng.dispose()


async def test_create_engine_passes_engine_kwargs() -> None:
    eng = create_engine(
        DatabaseConfig(url="sqlite+aiosqlite:///:memory:", echo=True, pool_recycle=600)
    )
    assert eng.config.echo is True
    assert eng.config.pool_recycle == 600
    await eng.dispose()


async def test_sqlite_skips_pool_kwargs() -> None:
    # Should not raise even though pool_size / max_overflow are set — they get filtered for SQLite.
    eng = create_engine(
        DatabaseConfig(url="sqlite+aiosqlite:///:memory:", pool_size=20, max_overflow=40)
    )
    assert eng.engine is not None
    await eng.dispose()
