"""Database registry — multi-engine routing + session context manager."""

from __future__ import annotations

import pytest
from sqlalchemy import select

from hawkapi_sqlalchemy import Database, DatabaseConfig

from .conftest import User


async def test_session_commits_on_clean_exit(db: Database) -> None:
    async with db.session() as sess:
        sess.add(User(email="a@b.c", name="Alice"))
    # Reopen — row should be visible.
    async with db.session() as sess:
        result = await sess.execute(select(User).where(User.email == "a@b.c"))
        row = result.scalar_one()
        assert row.name == "Alice"


async def test_session_rolls_back_on_exception(db: Database) -> None:
    with pytest.raises(RuntimeError):
        async with db.session() as sess:
            sess.add(User(email="x@y.z", name="Bob"))
            await sess.flush()
            raise RuntimeError("boom")
    async with db.session() as sess:
        result = await sess.execute(select(User).where(User.email == "x@y.z"))
        assert result.first() is None


async def test_session_commit_false_skips_commit(db: Database) -> None:
    async with db.session(commit=False) as sess:
        sess.add(User(email="nope@x.com", name="Nope"))
    async with db.session() as sess:
        result = await sess.execute(select(User).where(User.email == "nope@x.com"))
        assert result.first() is None


async def test_replica_falls_back_to_primary(db: Database) -> None:
    # Only primary registered — asking for replica returns primary.
    primary = db.get("primary")
    replica = db.get("replica")
    assert primary is replica


def test_unknown_engine_falls_back_to_primary(db: Database) -> None:
    # By design, any non-'primary' name falls back to primary when not registered.
    assert db.get("anything-else") is db.get("primary")


def test_unknown_engine_raises_when_primary_missing() -> None:
    empty = Database()
    with pytest.raises(KeyError, match="orphan"):
        empty.get("orphan")


async def test_multi_database_registration() -> None:
    database = Database()
    database.add("primary", DatabaseConfig(url="sqlite+aiosqlite:///:memory:"))
    database.add("analytics", DatabaseConfig(url="sqlite+aiosqlite:///:memory:"))
    assert "primary" in database.engines
    assert "analytics" in database.engines
    # Both engines are independent objects.
    assert database.get("primary") is not database.get("analytics")
    await database.dispose()
