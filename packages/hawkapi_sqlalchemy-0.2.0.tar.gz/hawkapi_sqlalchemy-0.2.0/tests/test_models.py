"""Mixins — TimestampMixin, UUIDMixin."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import String
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from hawkapi_sqlalchemy import Base, TimestampMixin, UUIDMixin

from .conftest import User


class Doc(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "docs"
    title: Mapped[str] = mapped_column(String(255), nullable=False)


async def test_timestamps_populated_on_insert(session: AsyncSession) -> None:
    user = User(email="t@u.v", name="T")
    session.add(user)
    await session.flush()
    assert isinstance(user.created_at, datetime)
    assert isinstance(user.updated_at, datetime)


async def test_uuid_mixin_assigns_string_id(db) -> None:  # type: ignore[no-untyped-def]
    # The conftest fixture didn't create the docs table — recreate metadata for this test only.
    engine = db.get("primary").engine
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with db.session() as sess:
        doc = Doc(title="hello")
        sess.add(doc)
        await sess.flush()
        assert isinstance(doc.id, str)
        assert len(doc.id) == 36  # uuid4 string length
