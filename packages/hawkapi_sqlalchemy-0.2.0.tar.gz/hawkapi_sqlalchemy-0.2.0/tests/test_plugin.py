"""Plugin entry point + DI sessions."""

from __future__ import annotations

from typing import Any

import pytest
from hawkapi import Depends, HawkAPI
from hawkapi.testing import TestClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from hawkapi_sqlalchemy import (
    Base,
    DatabaseConfig,
    get_session,
    init_database,
    resolve_database,
)

from .conftest import User


def test_init_database_with_url_string() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    db = init_database(app, url="sqlite+aiosqlite:///:memory:")
    assert app.state.db is db
    assert "primary" in db.engines


def test_init_database_requires_exactly_one_shape() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    with pytest.raises(ValueError, match="exactly one"):
        init_database(app)
    with pytest.raises(ValueError, match="exactly one"):
        init_database(
            app, url="sqlite:///:memory:", config=DatabaseConfig(url="sqlite:///:memory:")
        )


def test_init_database_multi_requires_primary() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    with pytest.raises(ValueError, match="primary"):
        init_database(
            app, databases={"replica": DatabaseConfig(url="sqlite+aiosqlite:///:memory:")}
        )


def test_resolve_database_falls_back_to_last() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    init_database(app, url="sqlite+aiosqlite:///:memory:")
    assert resolve_database(None) is not None  # falls back to _LAST_DATABASE


def test_get_session_dep_yields_working_session() -> None:
    import asyncio

    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    db = init_database(app, url="sqlite+aiosqlite:///:memory:")

    async def _create_schema() -> None:
        engine = db.get("primary").engine
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    asyncio.run(_create_schema())

    @app.post("/users")
    async def create_user(email: str, sess: AsyncSession = Depends(get_session)) -> dict[str, Any]:
        sess.add(User(email=email, name="x"))
        await sess.flush()
        return {"ok": True}

    @app.get("/users/{email}")
    async def get_user(email: str, sess: AsyncSession = Depends(get_session)) -> dict[str, Any]:
        result = await sess.execute(select(User).where(User.email == email))
        row = result.first()
        return {"found": row is not None}

    client = TestClient(app)
    r = client.post("/users?email=x@y.z")
    assert r.status_code in (200, 201)
    r = client.get("/users/x@y.z")
    assert r.status_code == 200
    assert r.json() == {"found": True}


def test_get_session_500_when_not_configured() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)

    @app.get("/x")
    async def view(sess: AsyncSession = Depends(get_session)) -> dict[str, Any]:
        return {"ok": True}

    import hawkapi_sqlalchemy._database as _d

    saved = _d._LAST_DATABASE[0]
    _d._LAST_DATABASE[0] = None
    _d._ACTIVE_DATABASES.pop(app, None)
    try:
        client = TestClient(app)
        r = client.get("/x")
        assert r.status_code == 500
    finally:
        _d._LAST_DATABASE[0] = saved


async def test_init_database_with_databases_dict() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    db = init_database(
        app,
        databases={
            "primary": DatabaseConfig(url="sqlite+aiosqlite:///:memory:"),
            "replica": DatabaseConfig(url="sqlite+aiosqlite:///:memory:"),
        },
    )
    assert {"primary", "replica"} <= set(db.engines)
