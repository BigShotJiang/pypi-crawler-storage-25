"""Regression tests for 0.2.0 hardening fixes."""

from __future__ import annotations

import logging

import pytest
from hawkapi import HawkAPI

from hawkapi_sqlalchemy import (
    Database,
    DatabaseConfig,
    init_database,
    open_session,
)


def test_open_session_no_commit_param() -> None:
    """The misleading ``commit`` kwarg must be gone."""
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    init_database(app, url="sqlite+aiosqlite:///:memory:")
    import asyncio

    async def _go() -> None:
        with pytest.raises(TypeError):
            await open_session(app, commit=True)  # type: ignore[call-arg]

    asyncio.run(_go())


def test_replica_fallback_warns(caplog: pytest.LogCaptureFixture) -> None:
    """Looking up an unregistered engine must log a WARNING when it falls back."""
    db = Database()
    db.add("primary", DatabaseConfig(url="sqlite+aiosqlite:///:memory:"))

    with caplog.at_level(logging.WARNING, logger="hawkapi_sqlalchemy"):
        engine = db.get("replica")
    assert engine is db.engines["primary"]
    assert any("falling back to primary" in record.message for record in caplog.records), [
        r.message for r in caplog.records
    ]
