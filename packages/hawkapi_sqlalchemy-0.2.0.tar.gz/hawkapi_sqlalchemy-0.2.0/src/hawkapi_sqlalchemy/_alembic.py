"""Alembic env.py helpers.

Drop this into your migrations ``env.py``:

.. code-block:: python

    from hawkapi_sqlalchemy.alembic import run_migrations
    from myapp.db import Base, settings   # your declarative Base + URL

    run_migrations(target_metadata=Base.metadata, url=settings.database_url)

That single call handles both online (live connection) and offline (`--sql`) modes.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import create_async_engine

if TYPE_CHECKING:  # pragma: no cover
    from sqlalchemy import MetaData


def run_migrations(
    *,
    target_metadata: MetaData,
    url: str,
    compare_type: bool = True,
    render_as_batch: bool | None = None,
    configure_kwargs: dict[str, Any] | None = None,
) -> None:
    """Drive Alembic for the current command context.

    Picks online vs offline mode based on ``context.is_offline_mode()``.
    """
    from alembic import context  # imported lazily so this module is import-safe outside Alembic

    if render_as_batch is None:
        render_as_batch = url.startswith("sqlite")

    if context.is_offline_mode():
        context.configure(
            url=url,
            target_metadata=target_metadata,
            literal_binds=True,
            compare_type=compare_type,
            render_as_batch=render_as_batch,
            dialect_opts={"paramstyle": "named"},
            **(configure_kwargs or {}),
        )
        with context.begin_transaction():
            context.run_migrations()
        return

    # ``asyncio.run`` cannot be invoked from inside a running loop — produce a
    # clear error rather than the obscure RuntimeError that nested loops give.
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        running = False
    else:
        running = True
    if running:
        raise RuntimeError("run_migrations must be called from a non-async context")
    asyncio.run(_run_online(target_metadata, url, compare_type, render_as_batch, configure_kwargs))


async def _run_online(
    target_metadata: MetaData,
    url: str,
    compare_type: bool,
    render_as_batch: bool,
    configure_kwargs: dict[str, Any] | None,
) -> None:
    connectable = create_async_engine(url, poolclass=pool.NullPool, future=True)
    async with connectable.connect() as connection:
        await connection.run_sync(
            lambda sync_conn: _apply(
                sync_conn, target_metadata, compare_type, render_as_batch, configure_kwargs
            )
        )
    await connectable.dispose()


def _apply(
    connection: Connection,
    target_metadata: MetaData,
    compare_type: bool,
    render_as_batch: bool,
    configure_kwargs: dict[str, Any] | None,
) -> None:
    from alembic import context

    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=compare_type,
        render_as_batch=render_as_batch,
        **(configure_kwargs or {}),
    )
    with context.begin_transaction():
        context.run_migrations()


__all__ = ["run_migrations"]
