"""DI helpers — per-request sessions with auto-commit / rollback."""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from typing import Any

from hawkapi import HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession

from ._database import resolve_database


async def get_session(request: Request) -> AsyncIterator[AsyncSession]:
    """DI dependency — yields a ``primary`` session, commits on success, rolls back on error."""
    async for sess in _session_iter(request, name="primary"):
        yield sess


async def get_replica_session(request: Request) -> AsyncIterator[AsyncSession]:
    """DI dependency — yields a ``replica`` session (falls back to ``primary`` if unset).

    Never auto-commits — replicas are read-only by convention.
    """
    async for sess in _session_iter(request, name="replica", commit=False):
        yield sess


def session_for(
    name: str, *, commit: bool = True
) -> Callable[[Request], AsyncIterator[AsyncSession]]:
    """Build a DI dependency that opens a session against the engine named ``name``."""

    async def _dep(request: Request) -> AsyncIterator[AsyncSession]:
        async for sess in _session_iter(request, name=name, commit=commit):
            yield sess

    return _dep


async def _session_iter(
    request: Request, *, name: str, commit: bool = True
) -> AsyncIterator[AsyncSession]:
    db = resolve_database(request.scope.get("app"))
    if db is None:
        raise HTTPException(
            500, detail="Database not configured — call init_database(app, ...) first"
        )
    async with db.session(name, commit=commit) as sess:
        yield sess


# Helper for non-handler code — e.g. background workers.
async def open_session(app: Any, *, name: str = "primary") -> AsyncSession:
    """Open a raw session without going through DI.

    The caller owns the session lifecycle — close, commit, and rollback are the
    caller's responsibility. This API intentionally has no ``commit`` flag:
    historically one was accepted but ignored, which encouraged callers to
    assume auto-commit semantics that never existed (CWE-400).
    """
    db = resolve_database(app)
    if db is None:
        raise RuntimeError("Database not configured — call init_database(app, ...) first")
    engine = db.get(name)
    return engine.sessionmaker()


__all__ = ["get_replica_session", "get_session", "open_session", "session_for"]
