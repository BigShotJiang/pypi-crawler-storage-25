"""Engine + sessionmaker creation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)


@dataclass(slots=True)
class DatabaseConfig:
    url: str
    echo: bool = False
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: float = 30.0
    pool_recycle: int = 3600
    pool_pre_ping: bool = True
    connect_args: dict[str, Any] = field(default_factory=dict)
    engine_kwargs: dict[str, Any] = field(default_factory=dict)
    session_kwargs: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Engine:
    """Engine + sessionmaker pair."""

    engine: AsyncEngine
    sessionmaker: async_sessionmaker[AsyncSession]
    config: DatabaseConfig

    async def dispose(self) -> None:
        await self.engine.dispose()


def create_engine(config: DatabaseConfig) -> Engine:
    kwargs: dict[str, Any] = {
        "echo": config.echo,
        "pool_pre_ping": config.pool_pre_ping,
        "pool_recycle": config.pool_recycle,
    }
    # SQLite (aiosqlite) does not accept pool_size / max_overflow / pool_timeout.
    if not config.url.startswith("sqlite"):
        kwargs["pool_size"] = config.pool_size
        kwargs["max_overflow"] = config.max_overflow
        kwargs["pool_timeout"] = config.pool_timeout
    if config.connect_args:
        kwargs["connect_args"] = config.connect_args
    kwargs.update(config.engine_kwargs)

    engine = create_async_engine(config.url, **kwargs)
    smaker = async_sessionmaker(
        bind=engine,
        expire_on_commit=False,
        autoflush=False,
        **config.session_kwargs,
    )
    return Engine(engine=engine, sessionmaker=smaker, config=config)


__all__ = ["DatabaseConfig", "Engine", "create_engine"]
