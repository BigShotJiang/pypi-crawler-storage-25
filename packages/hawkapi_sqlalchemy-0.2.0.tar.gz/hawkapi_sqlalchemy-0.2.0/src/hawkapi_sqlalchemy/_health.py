"""Healthcheck helpers."""

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from ._database import Database


async def session_healthy(session: AsyncSession) -> bool:
    """Run a trivial ``SELECT 1`` against an open session — returns False on any error."""
    try:
        result = await session.execute(text("SELECT 1"))
        row = result.scalar_one()
        return row == 1
    except Exception:
        return False


async def database_healthy(database: Database, *, name: str = "primary") -> bool:
    """Open a fresh session against ``name`` and verify connectivity."""
    try:
        async with database.session(name, commit=False) as sess:
            return await session_healthy(sess)
    except Exception:
        return False


async def all_healthy(database: Database) -> dict[str, bool]:
    """Run :func:`database_healthy` against every registered engine."""
    return {name: await database_healthy(database, name=name) for name in database.engines}


__all__ = ["all_healthy", "database_healthy", "session_healthy"]
