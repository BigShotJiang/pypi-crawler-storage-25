"""Base declarative class + reusable mixins."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import DateTime, String, func
from sqlalchemy.orm import DeclarativeBase, Mapped, MappedAsDataclass, mapped_column


class Base(DeclarativeBase):
    """Declarative base for hawkapi-sqlalchemy users.

    Subclass this for ordinary ORM models. Use :class:`DataclassBase` if you want
    SQLAlchemy 2.0's dataclass-style declarative mode.
    """


class DataclassBase(MappedAsDataclass, DeclarativeBase, kw_only=True):
    """Same as :class:`Base` but with dataclass-style ``__init__`` / ``__repr__``."""


class TimestampMixin:
    """Adds ``created_at`` / ``updated_at`` columns with DB-side defaults."""

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=func.current_timestamp(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=func.current_timestamp(),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )


class UUIDMixin:
    """Adds a string ``id`` column with a uuid4 default."""

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )


__all__ = ["Base", "DataclassBase", "TimestampMixin", "UUIDMixin"]
