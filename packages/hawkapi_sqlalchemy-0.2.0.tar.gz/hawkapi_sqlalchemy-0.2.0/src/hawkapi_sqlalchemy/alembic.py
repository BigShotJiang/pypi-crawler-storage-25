"""Public alias for the Alembic helper.

Imported from your ``alembic/env.py`` as ``from hawkapi_sqlalchemy.alembic import run_migrations``.
"""

from ._alembic import run_migrations

__all__ = ["run_migrations"]
