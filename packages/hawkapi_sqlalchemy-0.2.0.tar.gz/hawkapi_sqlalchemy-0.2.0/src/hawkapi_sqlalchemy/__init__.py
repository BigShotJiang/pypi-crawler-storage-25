"""hawkapi-sqlalchemy — SQLAlchemy integration for HawkAPI.

Async engines, multi-database routing (primary / replica / shards), per-request
sessions with auto-commit/rollback, Alembic helpers, and pytest fixtures.
"""

from __future__ import annotations

from ._alembic import run_migrations
from ._database import Database, init_database, resolve_database
from ._engine import DatabaseConfig, Engine, create_engine
from ._health import all_healthy, database_healthy, session_healthy
from ._models import Base, DataclassBase, TimestampMixin, UUIDMixin
from ._session import get_replica_session, get_session, open_session, session_for
from ._testing import temporary_database, temporary_session

__version__ = "0.2.0"

__all__ = [
    "Base",
    "DataclassBase",
    "Database",
    "DatabaseConfig",
    "Engine",
    "TimestampMixin",
    "UUIDMixin",
    "__version__",
    "all_healthy",
    "create_engine",
    "database_healthy",
    "get_replica_session",
    "get_session",
    "init_database",
    "open_session",
    "resolve_database",
    "run_migrations",
    "session_for",
    "session_healthy",
    "temporary_database",
    "temporary_session",
]
