"""Pytest helpers — build an in-memory engine, manage schema lifecycle."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from sqlalchemy.ext.asyncio import AsyncSession

from ._database import Database
from ._engine import DatabaseConfig

if TYPE_CHECKING:  # pragma: no cover
    from sqlalchemy import MetaData


@asynccontextmanager
async def temporary_database(
    metadata: MetaData,
    *,
    url: str = "sqlite+aiosqlite:///:memory:",
) -> AsyncGenerator[Database, None]:
    """Yields a :class:`Database` whose schema is created up-front and dropped on exit."""
    db = Database()
    db.add("primary", DatabaseConfig(url=url))
    engine = db.get("primary").engine
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)
    try:
        yield db
    finally:
        try:
            async with engine.begin() as conn:
                await conn.run_sync(metadata.drop_all)
        finally:
            await db.dispose()


@asynccontextmanager
async def temporary_session(
    metadata: MetaData,
    *,
    url: str = "sqlite+aiosqlite:///:memory:",
) -> AsyncGenerator[AsyncSession, None]:
    """Convenience — yield a session against a fresh in-memory database."""
    async with temporary_database(metadata, url=url) as db, db.session() as sess:
        yield sess


__all__ = ["temporary_database", "temporary_session"]
