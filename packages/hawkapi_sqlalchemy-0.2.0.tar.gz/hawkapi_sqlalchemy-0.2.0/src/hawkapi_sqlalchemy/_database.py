"""Database registry — multi-engine routing + plugin entry point.

A :class:`Database` owns one or more :class:`Engine` instances keyed by name.
The convention is:

* ``primary`` — read/write engine (the default).
* ``replica`` — optional read-only engine; if absent we fall back to ``primary``.

You can register any number of named engines (e.g. ``analytics``, ``shard_1``)
and ask for them by name via :func:`get_session(name=...)`.
"""

from __future__ import annotations

import contextlib
import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any
from weakref import WeakKeyDictionary

from sqlalchemy.ext.asyncio import AsyncSession

from ._engine import DatabaseConfig, Engine, create_engine

logger = logging.getLogger("hawkapi_sqlalchemy")


@dataclass
class Database:
    engines: dict[str, Engine] = field(default_factory=dict)

    def add(self, name: str, config: DatabaseConfig) -> Engine:
        engine = create_engine(config)
        self.engines[name] = engine
        return engine

    def get(self, name: str = "primary") -> Engine:
        if name in self.engines:
            return self.engines[name]
        if name != "primary" and "primary" in self.engines:
            # Fall back to primary for replicas / analytics shards that are not
            # configured. Warn so misconfigured replicas don't silently route
            # to the primary forever (CWE-440-ish).
            logger.warning("falling back to primary for engine %r — not configured", name)
            return self.engines["primary"]
        raise KeyError(f"no engine registered under {name!r}")

    @asynccontextmanager
    async def session(
        self, name: str = "primary", *, commit: bool = True
    ) -> AsyncGenerator[AsyncSession, None]:
        """Open a session bound to ``name``. Commits on clean exit; rolls back on exception."""
        engine = self.get(name)
        async with engine.sessionmaker() as sess:
            try:
                yield sess
                if commit:
                    await sess.commit()
            except Exception:
                await sess.rollback()
                raise

    async def dispose(self) -> None:
        for engine in self.engines.values():
            await engine.dispose()


# ---------------------------------------------------------------------------
# Plugin registry
# ---------------------------------------------------------------------------


class _StateNamespace:
    db: Any


# WeakKeyDictionary avoids the ``id(app)`` ABA hazard if an app is GC'd and
# Python reuses the address for a new object.
_ACTIVE_DATABASES: WeakKeyDictionary[Any, Database] = WeakKeyDictionary()
_LAST_DATABASE: list[Database | None] = [None]


def init_database(
    app: Any,
    *,
    url: str | None = None,
    config: DatabaseConfig | None = None,
    databases: dict[str, DatabaseConfig] | None = None,
    dispose_on_shutdown: bool = True,
) -> Database:
    """Attach a :class:`Database` to ``app.state.db`` and register it for DI lookup.

    The three argument shapes (mutually exclusive):

    1. ``url=...`` — convenience, creates a single ``primary`` engine.
    2. ``config=DatabaseConfig(...)`` — single ``primary`` engine with custom config.
    3. ``databases={"primary": ..., "replica": ...}`` — register multiple engines.
    """
    if sum(x is not None for x in (url, config, databases)) != 1:
        raise ValueError("init_database requires exactly one of url=, config=, or databases=")

    database = Database()
    if url is not None:
        database.add("primary", DatabaseConfig(url=url))
    elif config is not None:
        database.add("primary", config)
    else:
        assert databases is not None
        if "primary" not in databases:
            raise ValueError("databases must include a 'primary' entry")
        for name, cfg in databases.items():
            database.add(name, cfg)

    if getattr(app, "state", None) is None:
        app.state = _StateNamespace()
    app.state.db = database
    with contextlib.suppress(TypeError):
        _ACTIVE_DATABASES[app] = database
    _LAST_DATABASE[0] = database

    if dispose_on_shutdown and hasattr(app, "on_shutdown"):

        async def _dispose() -> None:
            await database.dispose()

        app.on_shutdown(_dispose)
    return database


def resolve_database(app: Any) -> Database | None:
    if app is None:
        return _LAST_DATABASE[0]
    try:
        db = _ACTIVE_DATABASES.get(app)
    except TypeError:
        db = None
    if db is not None:
        return db
    state = getattr(app, "state", None)
    if state is not None and hasattr(state, "db"):
        return state.db  # type: ignore[no-any-return]
    return _LAST_DATABASE[0]


__all__ = ["Database", "init_database", "resolve_database"]
