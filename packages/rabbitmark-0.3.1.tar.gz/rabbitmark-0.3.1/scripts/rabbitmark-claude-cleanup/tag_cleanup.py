"""
Tag cleanup script for the RabbitMark bookmark database.

Normalizes tag formatting and consolidates duplicates per the cleanup plan.
Operates directly on the SQLite database, with all changes in a single
transaction so they can be rolled back on error.
"""
import sqlite3
import sys

DB_PATH = "rabbitmark-tmp.db"


def get_tag_id(cur, text):
    "Look up a tag ID by its text. Returns None if not found."
    cur.execute("SELECT id FROM tags WHERE text = ?", (text,))
    row = cur.fetchone()
    return row[0] if row else None


def ensure_tag(cur, text):
    "Get tag ID, creating the tag if it doesn't exist."
    tag_id = get_tag_id(cur, text)
    if tag_id is None:
        cur.execute("INSERT INTO tags (text) VALUES (?)", (text,))
        tag_id = cur.lastrowid
        print(f"  Created tag: '{text}' (id={tag_id})")
    return tag_id


def merge_tags(cur, sources, target):
    """
    Merge one or more source tags into target.

    Moves all bookmark associations from each source tag to the target,
    skipping duplicates, then deletes the source tags.
    """
    target_id = ensure_tag(cur, target)

    for source in sources:
        source_id = get_tag_id(cur, source)
        if source_id is None:
            print(f"  WARNING: source tag '{source}' not found, skipping")
            continue

        # Move associations that don't already exist on the target
        cur.execute(
            """
            INSERT OR IGNORE INTO mark_tag_assoc (mark_id, tag_id)
            SELECT mark_id, ? FROM mark_tag_assoc WHERE tag_id = ?
            """,
            (target_id, source_id),
        )
        moved = cur.rowcount

        # Delete old associations and the source tag
        cur.execute(
            "DELETE FROM mark_tag_assoc WHERE tag_id = ?",
            (source_id,),
        )
        cur.execute("DELETE FROM tags WHERE id = ?", (source_id,))
        print(
            f"  Merged '{source}' -> '{target}'"
            f" ({moved} new associations)"
        )


def rename_tag(cur, old_text, new_text):
    "Rename a tag by updating its text."
    tag_id = get_tag_id(cur, old_text)
    if tag_id is None:
        print(f"  WARNING: tag '{old_text}' not found, skipping rename")
        return
    cur.execute(
        "UPDATE tags SET text = ? WHERE id = ?", (new_text, tag_id)
    )
    print(f"  Renamed '{old_text}' -> '{new_text}'")


def delete_tag(cur, text):
    "Delete a tag and all its associations."
    tag_id = get_tag_id(cur, text)
    if tag_id is None:
        print(f"  WARNING: tag '{text}' not found, skipping delete")
        return
    cur.execute(
        "DELETE FROM mark_tag_assoc WHERE tag_id = ?", (tag_id,)
    )
    removed = cur.rowcount
    cur.execute("DELETE FROM tags WHERE id = ?", (tag_id,))
    print(f"  Deleted tag '{text}' ({removed} associations removed)")


def add_tag_to_bookmark(cur, mark_id, tag_text):
    "Add a tag to a bookmark, creating the tag if needed."
    tag_id = ensure_tag(cur, tag_text)
    cur.execute(
        "INSERT OR IGNORE INTO mark_tag_assoc (mark_id, tag_id) "
        "VALUES (?, ?)",
        (mark_id, tag_id),
    )


def remove_tag_from_bookmark(cur, mark_id, tag_text):
    "Remove a specific tag from a bookmark."
    tag_id = get_tag_id(cur, tag_text)
    if tag_id is None:
        return
    cur.execute(
        "DELETE FROM mark_tag_assoc WHERE mark_id = ? AND tag_id = ?",
        (mark_id, tag_id),
    )


def apply_changes(cur):
    # === Section 1: Merge duplicate tags ===
    print("\n== 1. Merging duplicate tags ==")
    merge_tags(cur, ["AI", "ChatGPT"], "ai")
    merge_tags(cur, ["spaced-repetition"], "spaced repetition")
    merge_tags(cur, ["relationship"], "relationships")
    merge_tags(cur, ["poly"], "polyamory")
    merge_tags(cur, ["game"], "games")
    merge_tags(cur, ["tech"], "technology")
    merge_tags(cur, ["metarationality"], "rationality")
    merge_tags(cur, ["employment", "jobs"], "career")

    # === Section 2: Lowercase uppercase tags ===
    print("\n== 2. Lowercasing tags ==")
    for old, new in [
        ("Alice", "alice"),
        ("COVID", "covid"),
        ("Christmas Festival", "christmas festival"),
        ("Donald Trump", "donald trump"),
        ("Ole Choir", "ole choir"),
    ]:
        rename_tag(cur, old, new)

    # === Section 3: Convert skewer-case to spaces ===
    print("\n== 3. Converting skewer-case to spaces ==")
    skewer_tags = [
        "air-quality",
        "association-for-computational-heresy",
        "azure-devops",
        "mental-illness",
        "open-source",
        "public-health",
        "semantic-linebreaks",
        "time-wasters",
    ]
    for tag in skewer_tags:
        rename_tag(cur, tag, tag.replace("-", " "))

    # === Section 4: Rename/remove tags ===
    print("\n== 4. Renaming and removing tags ==")

    # demi -> asexuality
    rename_tag(cur, "demi", "asexuality")

    # history (general) -> history
    merge_tags(cur, ["history (general)"], "history")

    # ERs: delete (after adding tags in section 7)
    # _import: delete (after adding tags in section 6)
    # These deletions happen after sections 6 & 7 below.

    # === Section 5: Tag untagged bookmarks ===
    print("\n== 5. Tagging untagged bookmarks ==")
    untagged = {
        779: ["rationalism", "wisdom"],
        812: ["rationalism", "fiction"],
        785: ["aviation", "history"],
        795: ["technology", "hardware"],
        820: ["culture", "psychology"],
        910: ["parenting", "philosophy"],
        915: ["history", "technology", "ai"],
        829: ["technology", "history (computing)", "design"],
        850: ["play"],
        777: ["curiosity", "philosophy"],
        851: ["minneapolis", "data"],
        917: ["essay"],
    }
    for mark_id, tags in untagged.items():
        for tag in tags:
            add_tag_to_bookmark(cur, mark_id, tag)
        print(f"  Bookmark {mark_id}: added {tags}")

    # === Section 6: Tag _import-only bookmarks, then delete _import ===
    print("\n== 6. Tagging _import bookmarks ==")
    import_bookmarks = {
        747: ["consciousness", "science"],
        749: ["education", "data"],
        750: ["learning", "spaced repetition", "education"],
        751: ["literature", "essay"],
        752: ["politics"],
        754: ["essay"],
        755: ["essay", "politics"],
        756: ["politics", "donald trump"],
        757: ["essay"],
        758: ["essay"],
        759: ["covid", "science", "politics"],
        760: ["learning", "education"],
        761: ["culture"],
        762: ["philosophy", "ethics", "ai"],
        763: ["career", "work"],
        746: ["internet", "culture"],
    }
    for mark_id, tags in import_bookmarks.items():
        for tag in tags:
            add_tag_to_bookmark(cur, mark_id, tag)
        print(f"  Bookmark {mark_id}: added {tags}")

    delete_tag(cur, "_import")

    # === Section 7: Add missing tags to existing bookmarks ===
    print("\n== 7. Adding missing tags ==")
    missing_tags = [
        (16, "python"),
        (436, "python"),
        (868, "philosophy"),
        (627, "spaced repetition"),
        (865, "asexuality"),
        (722, "technology"),
        (81, "essay"),
    ]
    for mark_id, tag in missing_tags:
        add_tag_to_bookmark(cur, mark_id, tag)
        print(f"  Bookmark {mark_id}: added '{tag}'")

    # Replace 'writing' with 'essay' on bookmarks 3 and 142
    for mark_id in (3, 142):
        remove_tag_from_bookmark(cur, mark_id, "writing")
        add_tag_to_bookmark(cur, mark_id, "essay")
        print(f"  Bookmark {mark_id}: replaced 'writing' with 'essay'")

    # Now delete ERs (associations already exist from section 7)
    delete_tag(cur, "ERs")


def run_verification(cur):
    print("\n== Verification ==")

    # 1. Non-lowercase tags (should only be IT)
    cur.execute(
        "SELECT text FROM tags WHERE text != lower(text)"
    )
    rows = [r[0] for r in cur.fetchall()]
    status = "PASS" if rows == ["IT"] else "FAIL"
    print(f"  [{status}] Non-lowercase tags: {rows} (expected: ['IT'])")

    # 2. Hyphenated tags (should only be sci-fi)
    cur.execute(
        "SELECT text FROM tags WHERE text LIKE '%-%'"
        " AND text != 'sci-fi'"
    )
    rows = [r[0] for r in cur.fetchall()]
    status = "PASS" if rows == [] else "FAIL"
    print(
        f"  [{status}] Unexpected hyphenated tags: {rows}"
        f" (expected: none)"
    )

    # 3. _import tag should be gone
    cur.execute("SELECT text FROM tags WHERE text = '_import'")
    rows = cur.fetchall()
    status = "PASS" if rows == [] else "FAIL"
    print(f"  [{status}] _import tag exists: {bool(rows)} (expected: False)")

    # 4. No untagged bookmarks
    cur.execute(
        "SELECT b.id FROM bookmarks b"
        " LEFT JOIN mark_tag_assoc m ON b.id = m.mark_id"
        " WHERE m.tag_id IS NULL"
    )
    rows = [r[0] for r in cur.fetchall()]
    status = "PASS" if rows == [] else "FAIL"
    print(f"  [{status}] Untagged bookmark IDs: {rows} (expected: none)")

    # 5. Spot-check merged tag counts
    for tag, expected_min in [("ai", 9), ("spaced repetition", 6)]:
        cur.execute(
            "SELECT COUNT(*) FROM mark_tag_assoc"
            " WHERE tag_id = (SELECT id FROM tags WHERE text = ?)",
            (tag,),
        )
        count = cur.fetchone()[0]
        status = "PASS" if count >= expected_min else "FAIL"
        print(
            f"  [{status}] '{tag}' has {count} bookmarks"
            f" (expected >= {expected_min})"
        )

    # Summary stats
    cur.execute("SELECT COUNT(*) FROM tags")
    tag_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM mark_tag_assoc")
    assoc_count = cur.fetchone()[0]
    print(f"\n  Final: {tag_count} tags, {assoc_count} associations")


def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    try:
        apply_changes(cur)
        run_verification(cur)
        conn.commit()
        print("\nAll changes committed successfully.")
    except Exception as e:
        conn.rollback()
        print(f"\nERROR: {e}", file=sys.stderr)
        print("All changes rolled back.", file=sys.stderr)
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    main()
