<!-- This file is generated. DO NOT EDIT -->

# uv-python

This crate is an internal component of [uv](https://crates.io/crates/uv). The Rust API exposed here
is unstable and will have frequent breaking changes.

This version (0.0.40) is a component of [uv 0.11.7](https://crates.io/crates/uv/0.11.7). The source
can be found [here](https://github.com/astral-sh/uv/blob/0.11.7/crates/uv-python).

See uv's
[crate versioning policy](https://docs.astral.sh/uv/reference/policies/versioning/#crate-versioning)
for details on versioning.
