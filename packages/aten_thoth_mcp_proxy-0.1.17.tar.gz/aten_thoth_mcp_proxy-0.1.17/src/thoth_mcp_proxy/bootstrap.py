"""Local bootstrap helpers for Thoth runtime defaults."""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
from typing import MutableMapping

_DEFAULT_APEX_DOMAIN = "atensecurity.com"


@dataclass(frozen=True)
class BootstrapResult:
    thoth_home: str
    created_paths: list[str]
    env_updates: dict[str, str]


def _get_clean(mapping: MutableMapping[str, str], name: str) -> str:
    value = mapping.get(name)
    return value.strip() if isinstance(value, str) else ""


def _safe_chmod(path: Path, mode: int) -> None:
    try:
        path.chmod(mode)
    except OSError:
        return


def _write_json_if_missing(path: Path, payload: dict[str, object]) -> bool:
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return True


def bootstrap_local_profile(
    *,
    env: MutableMapping[str, str] | None = None,
    home: Path | None = None,
    tenant_id: str | None = None,
    user_id: str | None = None,
    endpoint_id: str | None = None,
    thoth_env: str | None = None,
    apex_domain: str | None = None,
) -> BootstrapResult:
    """Initialize local Thoth profile files and runtime environment defaults."""

    target_env = os.environ if env is None else env
    env_updates: dict[str, str] = {}

    def set_default(name: str, value: str | None) -> None:
        candidate = (value or "").strip()
        if not candidate:
            return
        current = _get_clean(target_env, name)
        if current:
            return
        target_env[name] = candidate
        env_updates[name] = candidate

    set_default("THOTH_TENANT_ID", tenant_id)
    set_default("THOTH_USER_ID", user_id)
    set_default("THOTH_ENDPOINT_ID", endpoint_id)
    set_default("THOTH_ENV", (thoth_env or "prod").strip().lower() or "prod")

    resolved_apex = (apex_domain or _get_clean(target_env, "THOTH_APEX_DOMAIN")).strip() or _DEFAULT_APEX_DOMAIN
    set_default("THOTH_APEX_DOMAIN", resolved_apex)

    thoth_home = (home or Path.home()) / ".thoth"
    created_paths: list[str] = []
    if not thoth_home.exists():
        thoth_home.mkdir(parents=True, exist_ok=True)
        created_paths.append(str(thoth_home))
    _safe_chmod(thoth_home, 0o700)

    intent_map_path = thoth_home / "intent_map.json"
    if _write_json_if_missing(intent_map_path, {}):
        created_paths.append(str(intent_map_path))

    api_key_file_path = thoth_home / "proxy_api_key.json"
    if _write_json_if_missing(api_key_file_path, {}):
        created_paths.append(str(api_key_file_path))
    _safe_chmod(api_key_file_path, 0o600)

    set_default("THOTH_API_KEY_FILE", str(api_key_file_path))

    canonical_govapi = _get_clean(target_env, "THOTH_GOVAPI_URL")
    legacy_govapi = _get_clean(target_env, "THOTH_GOV_API_URL")
    if legacy_govapi and not canonical_govapi:
        set_default("THOTH_GOVAPI_URL", legacy_govapi)
        canonical_govapi = legacy_govapi
    if canonical_govapi and not legacy_govapi:
        set_default("THOTH_GOV_API_URL", canonical_govapi)

    resolved_tenant = _get_clean(target_env, "THOTH_TENANT_ID")
    if resolved_tenant:
        default_enforcer_url = f"https://enforce.{resolved_tenant}.{resolved_apex}"
        default_govapi_url = f"https://grid.{resolved_tenant}.{resolved_apex}"
        set_default("THOTH_ENFORCER_URL", default_enforcer_url)
        set_default("THOTH_GOVAPI_URL", default_govapi_url)
        set_default("THOTH_GOV_API_URL", default_govapi_url)

    return BootstrapResult(
        thoth_home=str(thoth_home),
        created_paths=created_paths,
        env_updates=env_updates,
    )
