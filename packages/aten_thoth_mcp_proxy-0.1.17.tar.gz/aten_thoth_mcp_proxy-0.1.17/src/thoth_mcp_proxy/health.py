"""Health snapshot command for Jamf Extension Attribute ingestion."""

from __future__ import annotations

from dataclasses import asdict
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
from typing import Any, TextIO, cast

import httpx

from thoth_mcp_proxy import __version__
from thoth_mcp_proxy.credentials import load_revoked_key_ids, resolve_credential
from thoth_mcp_proxy.execution_context import assess_least_privilege
from thoth_mcp_proxy.fleet import build_govapi_headers, resolve_endpoint_identity, resolve_govapi_url
from thoth_mcp_proxy.runtime_policy import RuntimePolicyManager
from thoth_mcp_proxy.status import _default_config_path, _parse_governed_entry
from thoth_mcp_proxy.tls import TLSCertPinVerifier, httpx_verify_value, resolve_tls_config


def _utc_now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _resolve_enforcer_failure_decision() -> str:
    raw = os.getenv("THOTH_ENFORCER_FAILURE_DECISION", "").strip().lower()
    if raw and raw != "block":
        return "BLOCK"
    return "BLOCK"


def _load_config(config_path: str | None) -> dict[str, Any] | None:
    path: Path | None
    if config_path:
        path = Path(config_path)
    else:
        path = _default_config_path()
    if path is None or not path.exists():
        return None
    with path.open() as fh:
        loaded = json.load(fh)
    if not isinstance(loaded, dict):
        return None
    return cast(dict[str, Any], loaded)


def _config_drift(config_path: str | None) -> tuple[bool, int, int]:
    cfg = _load_config(config_path)
    if not cfg:
        return False, 0, 0
    servers: dict[str, Any] = cfg.get("mcpServers") or {}
    if not servers:
        return False, 0, 0

    governed = 0
    total = 0
    for entry in servers.values():
        total += 1
        is_governed, _, _ = _parse_governed_entry(entry)
        if is_governed:
            governed += 1
    return governed < total, governed, total


def _normalize_sha256(raw: str | None) -> str | None:
    if raw is None:
        return None
    normalized = raw.strip().lower()
    if normalized.startswith("sha256:"):
        normalized = normalized.removeprefix("sha256:")
    normalized = normalized.replace(":", "").replace(" ", "")
    if not normalized:
        return None
    if len(normalized) != 64 or any(ch not in "0123456789abcdef" for ch in normalized):
        return None
    return normalized


def _sha256_file(path: Path | None) -> str | None:
    if path is None or not path.is_file():
        return None
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(1024 * 64)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _resolve_proxy_integrity_path() -> Path | None:
    configured = os.getenv("THOTH_PROXY_BINARY_PATH", "").strip()
    if configured:
        return Path(configured).expanduser()

    argv0 = os.getenv("THOTH_PROXY_BINARY", "").strip() or sys.argv[0]
    if not argv0:
        return None
    direct = Path(argv0).expanduser()
    if direct.is_file():
        return direct
    resolved = shutil.which(argv0)
    if resolved:
        return Path(resolved)
    return None


def _resolve_config_path(config_path: str | None) -> Path | None:
    if config_path:
        return Path(config_path)
    return _default_config_path()


def _tamper_detection(config_path: str | None) -> dict[str, Any]:
    proxy_path = _resolve_proxy_integrity_path()
    config_file_path = _resolve_config_path(config_path)

    current_proxy_sha256 = _sha256_file(proxy_path)
    current_config_sha256 = _sha256_file(config_file_path)
    expected_proxy_sha256 = _normalize_sha256(os.getenv("THOTH_EXPECTED_PROXY_SHA256"))
    expected_config_sha256 = _normalize_sha256(os.getenv("THOTH_EXPECTED_CONFIG_SHA256"))

    proxy_matches_expected = None if expected_proxy_sha256 is None else (current_proxy_sha256 == expected_proxy_sha256)
    config_matches_expected = None if expected_config_sha256 is None else (current_config_sha256 == expected_config_sha256)

    tamper_detected = bool((proxy_matches_expected is False) or (config_matches_expected is False))
    hash_checks_configured = bool(expected_proxy_sha256 or expected_config_sha256)

    raw_required = os.getenv("THOTH_TAMPER_DETECTION_REQUIRED", "").strip().lower()
    if raw_required in {"1", "true", "yes", "on"}:
        required = True
    elif raw_required in {"0", "false", "no", "off"}:
        required = False
    else:
        required = False
    tamper_gate_ok = (not required) or (hash_checks_configured and not tamper_detected)

    return {
        "required": required,
        "gate_ok": tamper_gate_ok,
        "hash_checks_configured": hash_checks_configured,
        "tamper_detected": tamper_detected,
        "proxy_binary": {
            "path": str(proxy_path) if proxy_path else None,
            "expected_sha256": expected_proxy_sha256,
            "current_sha256": current_proxy_sha256,
            "matches_expected": proxy_matches_expected,
        },
        "config_file": {
            "path": str(config_file_path) if config_file_path else None,
            "expected_sha256": expected_config_sha256,
            "current_sha256": current_config_sha256,
            "matches_expected": config_matches_expected,
        },
    }


def _endpoint_health_from_govapi(
    govapi_url: str | None,
    tenant_id: str | None,
    endpoint_id: str,
    *,
    fallback_api_key: str | None = None,
    fallback_api_key_id: str | None = None,
) -> dict[str, Any]:
    if not govapi_url or not tenant_id:
        return {"checked": False, "ok": None, "error": "govapi_url_or_tenant_missing"}

    headers = build_govapi_headers(
        fallback_api_key=fallback_api_key,
        fallback_api_key_id=fallback_api_key_id,
    )
    endpoint_url = f"{govapi_url}/{tenant_id}/thoth/endpoints/{endpoint_id}"
    try:
        tls_config = resolve_tls_config()
        TLSCertPinVerifier(tls_config).verify(govapi_url)
        with httpx.Client(
            timeout=httpx.Timeout(connect=2.0, read=4.0, write=2.0, pool=2.0),
            verify=httpx_verify_value(tls_config),
        ) as client:
            resp = client.get(endpoint_url, headers=headers)
        if resp.status_code != 200:
            return {
                "checked": True,
                "ok": False,
                "error": f"http_{resp.status_code}",
                "status_code": resp.status_code,
            }

        body = resp.json()
        status = body.get("status")
        last_seen = body.get("last_seen")
        endpoint_proxy_version = body.get("proxy_version")
        endpoint_environment = body.get("environment")
        endpoint_enrollment = body.get("enrollment")
        ok = status in {"online", "stale"}
        return {
            "checked": True,
            "ok": ok,
            "status": status,
            "last_seen": last_seen,
            "proxy_version": endpoint_proxy_version,
            "environment": endpoint_environment,
            "enrollment": endpoint_enrollment,
        }
    except Exception as exc:
        return {"checked": True, "ok": False, "error": str(exc)}


def health_snapshot(config_path: str | None = None) -> dict[str, Any]:
    identity = resolve_endpoint_identity()
    least_privilege = assess_least_privilege()
    runtime_policy = RuntimePolicyManager.from_env()
    runtime_policy.refresh()
    runtime_policy_meta = runtime_policy.metadata()
    tenant_id = os.getenv("THOTH_TENANT_ID", "").strip() or None
    govapi_url = resolve_govapi_url()
    expected_version = os.getenv("THOTH_EXPECTED_PROXY_VERSION", "").strip() or None
    current_version_ok = expected_version is None or expected_version == __version__
    tls_config_error: str | None = None
    try:
        tls_config = resolve_tls_config()
        tls_runtime = {
            "verify_enabled": tls_config.verify,
            "ca_bundle_configured": bool(tls_config.ca_bundle),
            "pin_count": len(tls_config.pinned_cert_sha256),
            "require_aws_backed_certs": tls_config.require_aws_backed_certs,
            "aws_acm_cert_arn": tls_config.aws_acm_cert_arn,
            "aws_private_ca_arn": tls_config.aws_private_ca_arn,
        }
    except Exception as exc:
        tls_config_error = str(exc)
        tls_runtime = {
            "verify_enabled": False,
            "ca_bundle_configured": False,
            "pin_count": 0,
            "require_aws_backed_certs": False,
            "aws_acm_cert_arn": None,
            "aws_private_ca_arn": None,
        }

    config_drifted, governed_servers, total_servers = _config_drift(config_path)
    tamper_detection = _tamper_detection(config_path)
    api_credential = resolve_credential(
        explicit_value=None,
        value_env="THOTH_API_KEY",
        file_env="THOTH_API_KEY_FILE",
        key_id_env="THOTH_API_KEY_ID",
        expires_env="THOTH_API_KEY_EXPIRES_AT",
    )
    key_days_to_expiry = api_credential.days_to_expiry()
    rotate_within_days_raw = os.getenv("THOTH_API_KEY_ROTATE_WITHIN_DAYS", "").strip()
    try:
        rotate_within_days = int(rotate_within_days_raw) if rotate_within_days_raw else 7
    except ValueError:
        rotate_within_days = 7
    key_rotation_required = key_days_to_expiry is not None and key_days_to_expiry <= max(0, rotate_within_days)
    revoked_key_ids = load_revoked_key_ids()
    key_revoked = bool(api_credential.key_id and api_credential.key_id in revoked_key_ids)

    endpoint_health = _endpoint_health_from_govapi(
        govapi_url,
        tenant_id,
        identity.endpoint_id,
        fallback_api_key=api_credential.value,
        fallback_api_key_id=api_credential.key_id,
    )

    registration_ok = endpoint_health.get("ok")
    raw_required = os.getenv("THOTH_HEALTH_REQUIRE_REGISTRATION", "").strip().lower()
    if raw_required in {"1", "true", "yes", "on"}:
        registration_required = True
    elif raw_required in {"0", "false", "no", "off"}:
        registration_required = False
    else:
        registration_required = identity.environment in {"staging", "prod"}

    raw_api_required = os.getenv("THOTH_HEALTH_REQUIRE_API_KEY", "").strip().lower()
    if raw_api_required in {"1", "true", "yes", "on"}:
        api_key_required = True
    elif raw_api_required in {"0", "false", "no", "off"}:
        api_key_required = False
    else:
        api_key_required = identity.environment in {"staging", "prod"}

    registration_gate_ok = registration_ok is True if registration_required else (registration_ok is not False)
    api_key_gate_ok = (api_credential.configured and not api_credential.expired and not key_revoked) if api_key_required else True
    tamper_gate_ok = bool(tamper_detection.get("gate_ok"))
    tls_gate_ok = tls_config_error is None
    least_privilege_gate_ok = least_privilege.gate_ok
    healthy = (not config_drifted) and current_version_ok and registration_gate_ok and api_key_gate_ok and tamper_gate_ok and tls_gate_ok and least_privilege_gate_ok
    smart_groups = {
        "healthy_current_version": healthy and current_version_ok and not config_drifted,
        "drifted_config": config_drifted,
        "proxy_unreachable": registration_required and registration_ok is not True,
        "outdated_version": not current_version_ok,
    }

    return {
        "status": "healthy" if healthy else "degraded",
        "healthy": healthy,
        "timestamp": _utc_now_iso(),
        "proxy_reachable": True,
        "proxy_version": __version__,
        "expected_proxy_version": expected_version,
        "current_version_ok": current_version_ok,
        "config_drifted": config_drifted,
        "governed_servers": governed_servers,
        "total_servers": total_servers,
        "tamper_detection": tamper_detection,
        "tamper_gate_ok": tamper_gate_ok,
        "tls": tls_runtime,
        "tls_gate_ok": tls_gate_ok,
        "tls_error": tls_config_error,
        "least_privilege": {
            "gate_ok": least_privilege.gate_ok,
            "reasons": list(least_privilege.reasons),
            "require_non_root": least_privilege.require_non_root,
            "expected_user": least_privilege.expected_user,
            "expected_uid": least_privilege.expected_uid,
            "identity": {
                "uid": least_privilege.identity.uid,
                "gid": least_privilege.identity.gid,
                "username": least_privilege.identity.username,
                "is_root": least_privilege.identity.is_root,
            },
        },
        "least_privilege_gate_ok": least_privilege_gate_ok,
        "tenant_id": tenant_id,
        "govapi_url": govapi_url,
        "registration_required": registration_required,
        "registration_ok": registration_ok,
        "enforcer_failure_decision": _resolve_enforcer_failure_decision(),
        "api_key_required": api_key_required,
        "api_key_gate_ok": api_key_gate_ok,
        "smart_groups": smart_groups,
        "api_key": {
            "configured": api_credential.configured,
            "source": api_credential.source,
            "key_id": api_credential.key_id,
            "file_path": api_credential.file_path,
            "error": api_credential.error,
            "expires_at": api_credential.expires_at.isoformat() if api_credential.expires_at else None,
            "expired": api_credential.expired,
            "days_to_expiry": key_days_to_expiry,
            "rotation_required": key_rotation_required,
            "rotate_within_days": rotate_within_days,
            "revoked": key_revoked,
        },
        "endpoint_health": endpoint_health,
        "endpoint": asdict(identity),
        "runtime_policy": {
            "policy_version": runtime_policy_meta.policy_version,
            "policy_source": runtime_policy_meta.policy_source,
            "policy_profile_id": runtime_policy_meta.policy_profile_id,
            "signature_valid": runtime_policy_meta.signature_valid,
            "rollback_active": runtime_policy_meta.rollback_active,
        },
    }


def show_health(
    *,
    json_output: bool,
    config_path: str | None = None,
    out: TextIO | None = None,
) -> int:
    if out is None:
        out = sys.stdout

    snapshot = health_snapshot(config_path=config_path)
    if json_output:
        out.write(json.dumps(snapshot, indent=2) + "\n")
        return 0

    out.write(f"status: {snapshot['status']}\n")
    out.write(f"healthy: {snapshot['healthy']}\n")
    out.write(f"proxy_version: {snapshot['proxy_version']}\n")
    out.write(f"config_drifted: {snapshot['config_drifted']}\n")
    out.write(f"registration_ok: {snapshot['registration_ok']}\n")
    endpoint = snapshot["endpoint"]
    out.write(f"endpoint_id: {endpoint['endpoint_id']}\n")
    out.write(f"environment: {endpoint['environment']}\n")
    out.write(f"enrollment: {endpoint['enrollment']}\n")
    return 0
