# thoth_mcp_proxy/proxy.py
"""
MCP stdio proxy with Thoth governance enforcement.

Architecture
------------
Claude Desktop <─stdin/stdout─> MCPProxy <─subprocess stdin/stdout─> upstream MCP server

The proxy passes all JSON-RPC messages through transparently EXCEPT for
``tools/call`` requests, which are checked against the Thoth enforcer first.

Message framing: newline-delimited JSON (one JSON-RPC object per line).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
import hashlib
from importlib.metadata import PackageNotFoundError, version as _pkg_version
import inspect
import ipaddress
import json
import logging
import os
from pathlib import Path
import re
import sys
from typing import Any
from urllib.parse import urlparse
import uuid

import anyio
import anyio.abc
import httpx

from thoth_mcp_proxy.bootstrap import bootstrap_local_profile
from thoth_mcp_proxy.credentials import CredentialState, load_revoked_key_ids, resolve_credential
from thoth_mcp_proxy.fleet import CheckinTelemetry, FleetReporter, build_govapi_headers, resolve_endpoint_identity, resolve_govapi_url
from thoth_mcp_proxy.process_resolver import (
    ProcessResolutionError,
    ResolvedProcessCommand,
    resolve_upstream_command,
    validate_exec_command,
    validate_runtime_environment,
)
from thoth_mcp_proxy.runtime_policy import RuntimePolicyManager
from thoth_mcp_proxy.tls import TLSCertPinVerifier, httpx_verify_value, resolve_tls_config

logger = logging.getLogger(__name__)

# MCP JSON-RPC error codes
_MCP_INTERNAL_ERROR = -32603
_THOTH_BLOCK_CODE = -32001  # Custom: tool call blocked by policy
_THOTH_STEP_UP_CODE = -32002  # Custom: tool call requires step-up auth

_DEFAULT_ENFORCER_URL = "http://enforcer:8080"
_ENFORCE_TIMEOUT = httpx.Timeout(connect=2.0, read=5.0, write=2.0, pool=2.0)
_DEFAULT_SPAWN_PATH_POSIX = "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
_DEFAULT_SPAWN_PATH_WINDOWS = r"C:\Windows\System32;C:\Windows"
_TOOL_ARGS_INLINE_MAX_BYTES = 16 * 1024
_TOOL_ARGS_PREVIEW_MAX_CHARS = 4096
PHI_FILENAME_PATTERNS = re.compile(
    r"(phi|patient|sensitive|ssn|pii|hipaa|mrn|dob|medical|health|rx|confidential)",
    re.IGNORECASE,
)
_SENSITIVE_INTENT_ALLOW_PATTERNS = re.compile(
    r"(phi|hipaa|medical|health|clinical|care|patient|eligibility)",
    re.IGNORECASE,
)
try:
    _PROXY_VERSION = _pkg_version("aten-thoth-mcp-proxy")
except PackageNotFoundError:
    _PROXY_VERSION = "0.0.0"


@dataclass
class ProxyConfig:
    agent_id: str
    tenant_id: str
    approved_scope: list[str] = field(default_factory=list)
    user_id: str = "system"
    enforcement_mode: str = "progressive"
    api_key: str | None = None
    api_key_id: str | None = None
    event_ingest_token: str | None = None
    enforcer_url: str = _DEFAULT_ENFORCER_URL
    govapi_url: str | None = None
    session_intent: str | None = None


@dataclass
class EnforceResult:
    decision: str
    reason: str | None = None
    violation_id: str | None = None
    hold_token: str | None = None
    enforcement_trace_id: str | None = None
    pack_id: str | None = None
    pack_version: str | None = None
    rule_version: int | None = None
    regulatory_regimes: list[str] = field(default_factory=list)
    matched_rule_ids: list[str] = field(default_factory=list)
    matched_control_ids: list[str] = field(default_factory=list)
    policy_references: list[str] = field(default_factory=list)
    model_signals: list[str] = field(default_factory=list)


def is_sensitive_path(arguments: dict[str, Any] | None) -> bool:
    if not isinstance(arguments, dict):
        return False
    path = arguments.get("path", "") or ""
    paths = arguments.get("paths", [])
    all_paths = [path] + (paths if isinstance(paths, list) else [])
    return any(PHI_FILENAME_PATTERNS.search(str(p)) for p in all_paths if p)


def _intent_allows_sensitive_access(session_intent: str | None) -> bool:
    if not session_intent:
        return False
    return bool(_SENSITIVE_INTENT_ALLOW_PATTERNS.search(session_intent))


def _enforce_sensitive_path_guard(
    *,
    decision: str,
    reason: str | None,
    sensitive_path_match: bool,
    session_intent: str | None,
) -> tuple[str, str | None]:
    if not sensitive_path_match:
        return decision, reason
    if decision == "BLOCK":
        return decision, reason
    if _intent_allows_sensitive_access(session_intent):
        if decision == "ALLOW":
            return (
                "STEP_UP",
                "Sensitive filename detected in tool arguments; elevated to STEP_UP by proxy preflight guard",
            )
        return decision, reason
    return (
        "BLOCK",
        (f"Sensitive filename detected in tool arguments and session_intent='{session_intent or 'unset'}' is not authorized for PHI access"),
    )


def _normalize_str_list(values: Any) -> list[str]:
    if values is None:
        return []
    if isinstance(values, str):
        values = [values]
    if not isinstance(values, list):
        return []
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value).strip()
        if not text or text in seen:
            continue
        seen.add(text)
        out.append(text)
    return out


class MCPProxy:
    """
    Stdio JSON-RPC proxy that intercepts ``tools/call`` messages and enforces
    Thoth governance policy before forwarding to the upstream MCP server.
    """

    def __init__(self, config: ProxyConfig) -> None:
        self._config = config
        self._session_id = str(uuid.uuid4())
        self._tool_calls: list[str] = []
        self._violations_today = 0
        _resolve_enforcer_failure_decision()
        self._revoked_api_key_ids: set[str] = set()
        self._api_credential = self._resolve_api_credential()
        self._tls_config = resolve_tls_config()
        self._tls_pin_verifier = TLSCertPinVerifier(self._tls_config)
        self._http = httpx.AsyncClient(
            base_url=config.enforcer_url,
            headers={},
            timeout=_ENFORCE_TIMEOUT,
            verify=httpx_verify_value(self._tls_config),
        )
        self._apply_api_credential(self._api_credential)
        self._runtime_policy = RuntimePolicyManager.from_env()
        self._runtime_policy.refresh()
        self._client_stdout: anyio.AsyncFile[Any] | anyio.abc.ByteSendStream | None = None
        self._event_ingest_warned = False
        endpoint_identity = resolve_endpoint_identity()
        self._fleet = FleetReporter(
            govapi_url=config.govapi_url or resolve_govapi_url(config.enforcer_url),
            tenant_id=config.tenant_id,
            endpoint=endpoint_identity,
            proxy_version=_PROXY_VERSION,
            enforcement_mode=config.enforcement_mode,
            headers=build_govapi_headers(
                fallback_api_key=self._api_credential.value,
                fallback_api_key_id=self._api_credential.key_id,
            ),
            timeout=httpx.Timeout(connect=2.0, read=4.0, write=2.0, pool=2.0),
            tls_config=self._tls_config,
        )

    async def run(self, upstream_cmd: list[str]) -> int:
        """
        Start the upstream MCP server subprocess and bridge stdio.
        Returns the upstream process exit code.
        """
        try:
            resolved = resolve_upstream_command(upstream_cmd)
        except ProcessResolutionError as exc:
            logger.error(
                "thoth-proxy: failed to resolve upstream command: %s",
                json.dumps(exc.to_dict(), sort_keys=True),
            )
            return 127

        try:
            full_cmd = _build_spawn_command(resolved)
        except RuntimeError as exc:
            logger.error("thoth-proxy: invalid spawn command: %s", exc)
            return 127
        env = _build_spawn_env(resolved, full_cmd)

        launch_payload: dict[str, object] = {
            "resolved_executable": resolved.executable,
            "args": resolved.args,
            "full_command": full_cmd,
            "cwd": resolved.cwd or str(Path.cwd()),
            "PATH": env.get("PATH", ""),
            "source": resolved.source,
        }
        logger.debug("thoth-proxy: upstream launch config: %s", json.dumps(launch_payload, sort_keys=True))

        try:
            validate_exec_command(resolved.executable, resolved.args, cwd=resolved.cwd)
        except ProcessResolutionError as exc:
            logger.error(
                "thoth-proxy: resolved upstream command failed preflight validation: %s",
                json.dumps(exc.to_dict(), sort_keys=True),
            )
            return 127

        if not validate_runtime_environment(
            resolved,
            enforcement_mode=self._config.enforcement_mode,
            stderr=sys.stderr,
        ):
            return 127

        if not await self._startup_preflight():
            return 127

        # Init client_stdout BEFORE spawning the upstream process
        self._client_stdout = anyio.wrap_file(sys.stdout.buffer)
        _emit_spawn_debug(launch_payload)

        try:
            process_cm = await anyio.open_process(
                full_cmd,
                env=env,
                cwd=resolved.cwd or None,
            )
        except FileNotFoundError as exc:
            logger.error(
                "SPAWN FAILURE DEBUG",
                extra={
                    "cmd": full_cmd,
                    "executable_exists": Path(full_cmd[0]).exists(),
                    "script_exists": Path(full_cmd[1]).exists() if len(full_cmd) > 1 else None,
                    "cwd": resolved.cwd or str(Path.cwd()),
                    "PATH": env.get("PATH"),
                },
            )
            error_payload = {
                "full_command": full_cmd,
                "cwd": resolved.cwd or str(Path.cwd()),
                "PATH": env.get("PATH"),
                "error": str(exc),
            }
            logger.error("thoth-proxy: failed to spawn upstream process: %s", json.dumps(error_payload, sort_keys=True))
            return 127
        except Exception:
            logger.exception("thoth-proxy: unexpected error while spawning upstream process")
            return 127

        async with process_cm as process:
            up_stdin: anyio.abc.ByteSendStream = process.stdin  # type: ignore[assignment]
            up_stdout: anyio.abc.ByteReceiveStream = process.stdout  # type: ignore[assignment]
            up_stderr: anyio.abc.ByteReceiveStream = process.stderr  # type: ignore[assignment]
            stop_event = anyio.Event()

            async def _client_to_upstream_task() -> None:
                # Do not end the session immediately when client stdin closes.
                # We still need to flush any in-flight upstream responses.
                await self._client_to_upstream(up_stdin)

            async def _upstream_to_client_task() -> None:
                try:
                    await self._upstream_to_client(up_stdout)
                finally:
                    stop_event.set()

            async def _forward_stderr_task() -> None:
                try:
                    await self._forward_stderr(up_stderr)
                finally:
                    stop_event.set()

            if self._fleet.enabled:
                try:
                    await self._fleet.register()
                    await self._fleet.checkin(self._telemetry_snapshot())
                except Exception:
                    logger.warning(
                        "thoth-proxy: endpoint registration/check-in failed during startup",
                        exc_info=True,
                    )

            # Initialize client stdout eagerly so error responses before the first
            # client message always go through the JSON-RPC response channel.
            self._client_stdout = anyio.wrap_file(sys.stdout.buffer)

            async with anyio.create_task_group() as tg:
                tg.start_soon(_client_to_upstream_task)
                tg.start_soon(_upstream_to_client_task)
                tg.start_soon(_forward_stderr_task)
                tg.start_soon(self._fleet.checkin_loop, stop_event, self._telemetry_snapshot)
                await stop_event.wait()
                tg.cancel_scope.cancel()
        return process.returncode or 0

    # ── Stream bridges ────────────────────────────────────────────────────────

    async def _client_to_upstream(self, up_stdin: anyio.abc.ByteSendStream) -> None:
        """Read from Claude Desktop (our stdin), enforce, forward to upstream."""
        client_stdin = anyio.wrap_file(sys.stdin.buffer)
        try:
            async for raw_line in client_stdin:
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    logger.debug("thoth-proxy: malformed line from client: %r", line[:200])
                    await _write_bytes(up_stdin, raw_line)
                    continue

                if msg.get("method") == "tools/call":
                    await self._handle_tools_call(msg, up_stdin)
                else:
                    await _write_bytes(up_stdin, raw_line)
        except anyio.EndOfStream:
            pass
        finally:
            await up_stdin.aclose()

    async def _upstream_to_client(self, up_stdout: anyio.abc.ByteReceiveStream) -> None:
        """Read from upstream stdout, write to Claude Desktop (our stdout)."""
        # Use the eagerly initialized client_stdout from run() to avoid
        # race conditions during startup.
        if self._client_stdout is None:
            # Tests may call this method directly without invoking run().
            self._client_stdout = anyio.wrap_file(sys.stdout.buffer)
        client_stdout = self._client_stdout
        buffer = b""
        try:
            async for chunk in up_stdout:
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    line = line + b"\n"
                    if not line.strip():
                        continue
                    if not _is_json_rpc_line(line):
                        extracted = _extract_embedded_json_rpc_line(line)
                        if extracted is not None:
                            prefix, json_line, suffix = extracted
                            # stdout must remain JSON-RPC only; send any non-JSON
                            # prefixes/suffixes to stderr.
                            if prefix.strip():
                                sys.stderr.buffer.write(prefix)
                            await _write_bytes(client_stdout, json_line)
                            if suffix.strip():
                                sys.stderr.buffer.write(suffix)
                            if prefix.strip() or suffix.strip():
                                sys.stderr.buffer.flush()
                            continue
                        # stdout must remain JSON-RPC only; send banners/noise to stderr.
                        sys.stderr.buffer.write(line)
                        sys.stderr.buffer.flush()
                        continue
                    await _write_bytes(client_stdout, line)
            # Flush any remaining buffer content after stream ends
            if buffer.strip():
                if _is_json_rpc_line(buffer):
                    await _write_bytes(client_stdout, buffer)
                else:
                    extracted = _extract_embedded_json_rpc_line(buffer)
                    if extracted is not None:
                        prefix, json_line, suffix = extracted
                        if prefix.strip():
                            sys.stderr.buffer.write(prefix)
                        await _write_bytes(client_stdout, json_line)
                        if suffix.strip():
                            sys.stderr.buffer.write(suffix)
                        if prefix.strip() or suffix.strip():
                            sys.stderr.buffer.flush()
                    else:
                        sys.stderr.buffer.write(buffer)
                        sys.stderr.buffer.flush()
        except anyio.EndOfStream:
            pass

    async def _forward_stderr(self, up_stderr: anyio.abc.ByteReceiveStream) -> None:
        """Forward upstream stderr → our stderr so server logs are visible."""
        try:
            async for line in up_stderr:
                sys.stderr.buffer.write(line)
                sys.stderr.buffer.flush()
        except anyio.EndOfStream:
            pass

    # ── Enforcement ───────────────────────────────────────────────────────────

    async def _handle_tools_call(
        self,
        msg: dict[str, Any],
        up_stdin: anyio.abc.ByteSendStream,
    ) -> None:
        """Enforce the tools/call message and either forward or reject it."""
        params = msg.get("params") or {}
        tool_name: str = params.get("name", "")
        msg_id = msg.get("id")
        tool_arguments = params.get("arguments")
        content = self._serialize_tool_call_content(tool_name, tool_arguments)
        effective_scope, effective_mode, effective_intent = self._resolve_effective_policy_inputs()
        enforcement_trace_id = str(uuid.uuid4())
        self._refresh_revoked_api_keys()
        self._refresh_api_credential()

        await self._emit_tool_event(
            event_type="TOOL_CALL_PRE",
            tool_name=tool_name,
            content=content,
            approved_scope=effective_scope,
            enforcement_mode=effective_mode,
            metadata={
                "decision": "PRECHECK",
                "session_intent": effective_intent,
                "enforcement_trace_id": enforcement_trace_id,
            },
            mcp_request_id=msg_id,
            tool_arguments=tool_arguments,
        )

        result = await self._enforce_with_details(
            tool_name,
            effective_scope=effective_scope,
            effective_mode=effective_mode,
            effective_intent=effective_intent,
            tool_args=tool_arguments if isinstance(tool_arguments, dict) else None,
            enforcement_trace_id=enforcement_trace_id,
            tool_call={
                "name": tool_name,
                "arguments": tool_arguments,
                "mcp_request_id": msg_id,
            },
        )
        decision, reason = result.decision, result.reason

        if decision == "ALLOW":
            self._tool_calls.append(tool_name)
            raw = (json.dumps(msg) + "\n").encode()
            await _write_bytes(up_stdin, raw)
            await self._emit_tool_event(
                event_type="TOOL_CALL_POST",
                tool_name=tool_name,
                content=content,
                approved_scope=effective_scope,
                enforcement_mode=effective_mode,
                metadata=self._build_enforcement_event_metadata(
                    decision=decision,
                    reason=reason,
                    session_intent=effective_intent,
                    result=result,
                ),
                mcp_request_id=msg_id,
                tool_arguments=tool_arguments,
            )
        elif decision == "BLOCK":
            self._violations_today += 1
            await self._emit_tool_event(
                event_type="TOOL_CALL_BLOCK",
                tool_name=tool_name,
                content=content,
                approved_scope=effective_scope,
                enforcement_mode=effective_mode,
                violation_id=result.violation_id,
                metadata=self._build_enforcement_event_metadata(
                    decision=decision,
                    reason=reason,
                    session_intent=effective_intent,
                    result=result,
                ),
                mcp_request_id=msg_id,
                tool_arguments=tool_arguments,
            )
            await self._send_error(
                msg_id,
                code=_THOTH_BLOCK_CODE,
                message=f"Tool call blocked by Thoth policy: {reason or tool_name}",
            )
        elif decision == "STEP_UP":
            self._violations_today += 1
            await self._emit_tool_event(
                event_type="TOOL_CALL_BLOCK",
                tool_name=tool_name,
                content=content,
                approved_scope=effective_scope,
                enforcement_mode=effective_mode,
                violation_id=result.violation_id,
                metadata=self._build_enforcement_event_metadata(
                    decision=decision,
                    reason=reason,
                    session_intent=effective_intent,
                    result=result,
                ),
                mcp_request_id=msg_id,
                tool_arguments=tool_arguments,
            )
            await self._send_error(
                msg_id,
                code=_THOTH_STEP_UP_CODE,
                message=(f"Tool call requires step-up authorization: {reason or tool_name}. A supervisor has been notified. Please retry after approval."),
            )
        else:
            self._violations_today += 1
            await self._emit_tool_event(
                event_type="TOOL_CALL_BLOCK",
                tool_name=tool_name,
                content=content,
                approved_scope=effective_scope,
                enforcement_mode=effective_mode,
                violation_id=result.violation_id,
                metadata=self._build_enforcement_event_metadata(
                    decision=decision,
                    reason=reason or "unknown decision from enforcer",
                    session_intent=effective_intent,
                    result=result,
                ),
                mcp_request_id=msg_id,
                tool_arguments=tool_arguments,
            )
            await self._send_error(
                msg_id,
                code=_THOTH_BLOCK_CODE,
                message=f"Tool call blocked by Thoth policy: {reason or 'unknown decision from enforcer'}",
            )

    async def _enforce(self, tool_name: str) -> tuple[str, str | None]:
        """
        Call POST /v1/enforce.  Returns (decision, reason).
        Fails closed when the enforcer call cannot be completed.
        """
        result = await self._enforce_with_details(tool_name)
        return result.decision, result.reason

    def _resolve_effective_policy_inputs(self) -> tuple[list[str], str, str | None]:
        self._runtime_policy.refresh()
        effective_scope = self._runtime_policy.effective_approved_scope(self._config.approved_scope)
        effective_mode = self._runtime_policy.effective_enforcement_mode(self._config.enforcement_mode)
        effective_intent = self._runtime_policy.effective_session_intent(self._config.session_intent)
        return effective_scope, effective_mode, effective_intent

    async def _enforce_with_details(
        self,
        tool_name: str,
        *,
        effective_scope: list[str] | None = None,
        effective_mode: str | None = None,
        effective_intent: str | None = None,
        tool_args: dict[str, Any] | None = None,
        enforcement_trace_id: str | None = None,
        tool_call: dict[str, Any] | None = None,
    ) -> EnforceResult:
        """
        Call POST /v1/enforce. Returns decision details including violation_id.
        Fails closed (BLOCK) on network/status errors.
        """
        trace_id = (enforcement_trace_id or "").strip() or str(uuid.uuid4())
        self._refresh_revoked_api_keys()
        self._refresh_api_credential()
        if self._api_key_required():
            if not self._api_credential.configured:
                logger.error("thoth-proxy: API key required but not configured")
                return EnforceResult(decision="BLOCK", reason="proxy API key is missing", enforcement_trace_id=trace_id)
            if self._api_credential.expired:
                logger.error("thoth-proxy: configured API key is expired")
                return EnforceResult(decision="BLOCK", reason="proxy API key is expired", enforcement_trace_id=trace_id)
        if self._api_credential.key_id and self._api_credential.key_id in self._revoked_api_key_ids:
            logger.error("thoth-proxy: configured API key id is revoked: %s", self._api_credential.key_id)
            return EnforceResult(decision="BLOCK", reason="proxy API key is revoked", enforcement_trace_id=trace_id)
        if effective_scope is None or effective_mode is None:
            resolved_scope, resolved_mode, resolved_intent = self._resolve_effective_policy_inputs()
            effective_scope = resolved_scope if effective_scope is None else effective_scope
            effective_mode = resolved_mode if effective_mode is None else effective_mode
            if effective_intent is None:
                effective_intent = resolved_intent
        sensitive_path_match = is_sensitive_path(tool_args)

        payload: dict[str, Any] = {
            "agent_id": self._config.agent_id,
            "tenant_id": self._config.tenant_id,
            "user_id": self._config.user_id,
            "tool_name": tool_name,
            "session_id": self._session_id,
            "session_tool_calls": list(self._tool_calls),
            "approved_scope": effective_scope,
            "enforcement_mode": effective_mode,
            "enforcement_trace_id": trace_id,
            "environment": (os.getenv("THOTH_ENV", "prod").strip().lower() or "prod"),
            "metadata": {
                "endpoint_id": self._fleet.endpoint.endpoint_id,
                "fleet_id": self._fleet.endpoint.fleet_id,
                "hostname": self._fleet.endpoint.hostname,
                "provider": self._fleet.endpoint.provider,
                "proxy_version": _PROXY_VERSION,
                "enforcement_trace_id": trace_id,
            },
        }
        if tool_args is not None:
            payload["tool_args"] = tool_args
        if tool_call is not None:
            payload["metadata"]["tool_call"] = tool_call
        elif tool_args is not None:
            payload["metadata"]["tool_call"] = {"name": tool_name, "arguments": tool_args}
        if sensitive_path_match:
            payload["metadata"]["sensitive_path_match"] = True
        if effective_intent:
            payload["session_intent"] = effective_intent
        if self._tls_pin_verifier.enabled:
            try:
                self._tls_pin_verifier.verify(self._config.enforcer_url)
            except Exception:
                logger.error(
                    "thoth-proxy: outbound TLS verification failed for enforcer %s",
                    self._config.enforcer_url,
                    exc_info=True,
                )
                return EnforceResult(decision="BLOCK", reason="enforcer TLS verification failed", enforcement_trace_id=trace_id)
        try:
            resp = await self._http.post("/v1/enforce", json=payload)
            resp.raise_for_status()
            body = resp.json()
            raw_decision = str(body.get("decision", "BLOCK")).upper()
            decision = raw_decision if raw_decision in {"ALLOW", "STEP_UP", "BLOCK"} else "BLOCK"
            reason = body.get("reason")
            decision, reason = _enforce_sensitive_path_guard(
                decision=decision,
                reason=reason,
                sensitive_path_match=sensitive_path_match,
                session_intent=effective_intent,
            )
            raw_rule_version = body.get("rule_version")
            try:
                parsed_rule_version = int(raw_rule_version) if raw_rule_version is not None else None
            except (TypeError, ValueError):
                parsed_rule_version = None
            return EnforceResult(
                decision=decision,
                reason=reason,
                violation_id=body.get("violation_id"),
                hold_token=body.get("hold_token") if decision == "STEP_UP" else None,
                enforcement_trace_id=trace_id,
                pack_id=str(body.get("pack_id", "")).strip() or None,
                pack_version=str(body.get("pack_version", "")).strip() or None,
                rule_version=parsed_rule_version,
                regulatory_regimes=_normalize_str_list(body.get("regulatory_regimes")),
                matched_rule_ids=_normalize_str_list(body.get("matched_rule_ids")),
                matched_control_ids=_normalize_str_list(body.get("matched_control_ids")),
                policy_references=_normalize_str_list(body.get("policy_references")),
                model_signals=_normalize_str_list(body.get("model_signals")),
            )
        except httpx.HTTPStatusError as exc:
            status_code = exc.response.status_code if exc.response is not None else 0
            if status_code in {401, 403}:
                logger.error(
                    "thoth-proxy: enforcer rejected proxy credentials (HTTP %s); failing closed for %s",
                    status_code,
                    tool_name,
                    exc_info=True,
                )
                return EnforceResult(
                    decision="BLOCK",
                    reason=f"enforcer authorization failed with HTTP {status_code} and fallback mode is BLOCK",
                    enforcement_trace_id=trace_id,
                )
            logger.warning(
                "thoth-proxy: enforcer returned HTTP %s, failing closed for %s",
                status_code,
                tool_name,
                exc_info=True,
            )
            return EnforceResult(
                decision="BLOCK",
                reason=f"enforcer returned HTTP {status_code} and fallback mode is BLOCK",
                enforcement_trace_id=trace_id,
            )
        except Exception:
            logger.warning(
                "thoth-proxy: enforcer unreachable, failing closed for %s",
                tool_name,
                exc_info=True,
            )
            return EnforceResult(
                decision="BLOCK",
                reason="enforcer unreachable and fallback mode is BLOCK",
                enforcement_trace_id=trace_id,
            )

    async def _emit_tool_event(
        self,
        *,
        event_type: str,
        tool_name: str,
        content: str,
        approved_scope: list[str],
        enforcement_mode: str,
        metadata: dict[str, Any] | None = None,
        violation_id: str | None = None,
        mcp_request_id: Any | None = None,
        tool_arguments: Any = None,
    ) -> None:
        merged_metadata = self._build_proxy_event_metadata(
            tool_name=tool_name,
            mcp_request_id=mcp_request_id,
            tool_arguments=tool_arguments,
            extra=metadata,
        )
        event = {
            "event_id": str(uuid.uuid4()),
            "tenant_id": self._config.tenant_id,
            "agent_id": self._config.agent_id,
            "session_id": self._session_id,
            "user_id": self._config.user_id,
            "source_type": "agent_tool_call",
            "event_type": event_type,
            "tool_name": tool_name,
            "endpoint_id": self._fleet.endpoint.endpoint_id,
            "hostname": self._fleet.endpoint.hostname,
            "content": content,
            "metadata": merged_metadata,
            "approved_scope": list(approved_scope),
            "enforcement_mode": enforcement_mode,
            "session_tool_calls": list(self._tool_calls),
            "occurred_at": datetime.now(UTC).isoformat(),
            "violation_id": violation_id,
        }
        try:
            headers: dict[str, str] | None = None
            event_ingest_token = (self._config.event_ingest_token or "").strip()
            if event_ingest_token:
                headers = {"X-Thoth-Event-Ingest-Token": event_ingest_token}

            resp = await self._http.post("/v1/events/batch", json=[event], headers=headers)
            resp.raise_for_status()
            self._event_ingest_warned = False
        except Exception as exc:
            if not self._event_ingest_warned:
                logger.warning(
                    "thoth-proxy: behavioral event ingest unavailable; continuing without event stream updates (%s)",
                    exc,
                )
                self._event_ingest_warned = True

    def _build_proxy_event_metadata(
        self,
        *,
        tool_name: str,
        mcp_request_id: Any | None,
        tool_arguments: Any,
        extra: dict[str, Any] | None,
    ) -> dict[str, Any]:
        endpoint = self._fleet.endpoint
        metadata: dict[str, Any] = {
            "endpoint_id": endpoint.endpoint_id,
            "hostname": endpoint.hostname,
            "endpoint_hostname": endpoint.hostname,
            "endpoint_os": endpoint.os_name,
            "endpoint_os_version": endpoint.os_version,
            "endpoint_enrollment": endpoint.enrollment,
            "endpoint_environment": endpoint.environment,
            "fleet_id": endpoint.fleet_id,
            "provider": endpoint.provider,
            "proxy_version": _PROXY_VERSION,
            "tool_call": self._build_tool_call_metadata(
                tool_name=tool_name,
                mcp_request_id=mcp_request_id,
                tool_arguments=tool_arguments,
            ),
        }
        if extra:
            metadata.update(extra)
        return metadata

    def _build_enforcement_event_metadata(
        self,
        *,
        decision: str,
        reason: str | None,
        session_intent: str | None,
        result: EnforceResult,
    ) -> dict[str, Any]:
        metadata: dict[str, Any] = {
            "decision": decision,
            "reason": reason,
            "session_intent": session_intent,
            "hold_token": result.hold_token,
            "enforcement_trace_id": result.enforcement_trace_id,
            "pack_id": result.pack_id,
            "pack_version": result.pack_version,
            "rule_version": result.rule_version,
            "regulatory_regimes": list(result.regulatory_regimes),
            "matched_rule_ids": list(result.matched_rule_ids),
            "matched_control_ids": list(result.matched_control_ids),
            "policy_references": list(result.policy_references),
            "model_signals": list(result.model_signals),
        }
        return {key: value for key, value in metadata.items() if value is not None}

    def _build_tool_call_metadata(
        self,
        *,
        tool_name: str,
        mcp_request_id: Any | None,
        tool_arguments: Any,
    ) -> dict[str, Any]:
        details: dict[str, Any] = {
            "name": tool_name,
            "mcp_request_id": mcp_request_id,
        }
        if tool_arguments is None:
            return details

        serialized: str
        try:
            serialized = json.dumps(tool_arguments, sort_keys=True, separators=(",", ":"))
            serializable = True
        except Exception:
            serialized = str(tool_arguments)
            serializable = False

        serialized_bytes = serialized.encode("utf-8", errors="replace")
        details["arguments_sha256"] = hashlib.sha256(serialized_bytes).hexdigest()
        details["arguments_size_bytes"] = len(serialized_bytes)

        if serializable and len(serialized_bytes) <= _TOOL_ARGS_INLINE_MAX_BYTES:
            details["arguments"] = tool_arguments
            return details

        details["arguments_preview"] = serialized[:_TOOL_ARGS_PREVIEW_MAX_CHARS] + ("...[truncated]" if len(serialized) > _TOOL_ARGS_PREVIEW_MAX_CHARS else "")
        details["arguments_truncated"] = len(serialized_bytes) > _TOOL_ARGS_INLINE_MAX_BYTES or not serializable
        return details

    def _serialize_tool_call_content(self, tool_name: str, arguments: Any) -> str:
        if arguments is None:
            return tool_name
        try:
            serialized = json.dumps(arguments, sort_keys=True, separators=(",", ":"))
        except Exception:
            serialized = str(arguments)
        if len(serialized) > 4096:
            return f"{serialized[:4096]}...[truncated]"
        return serialized

    async def _send_error(self, msg_id: Any, *, code: int, message: str) -> None:
        """Write a JSON-RPC error response directly to Claude Desktop."""
        error_resp = {
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {"code": code, "message": message},
        }
        line = (json.dumps(error_resp) + "\n").encode()
        # _client_stdout is initialized eagerly in run() before task startup.
        # Keep a defensive fallback for direct method calls in tests.
        stdout = self._client_stdout or anyio.wrap_file(sys.stdout.buffer)
        await _write_bytes(stdout, line)

    async def aclose(self) -> None:
        await self._fleet.aclose()
        await self._http.aclose()

    def _telemetry_snapshot(self) -> CheckinTelemetry:
        self._refresh_revoked_api_keys()
        self._refresh_api_credential()
        self._runtime_policy.refresh()
        metadata = self._runtime_policy.metadata()
        return CheckinTelemetry(
            proxy_version=_PROXY_VERSION,
            agent_ids=[self._config.agent_id],
            risk_score=0.0,
            violations_today=self._violations_today,
            sessions_today=1,
            policy_version=metadata.policy_version,
            policy_source=metadata.policy_source,
            policy_profile_id=metadata.policy_profile_id,
            policy_signature_valid=metadata.signature_valid,
            policy_rollback_active=metadata.rollback_active,
            api_key_id=self._api_credential.key_id,
            api_key_source=self._api_credential.source,
            api_key_expired=self._api_credential.expired if self._api_credential.expires_at else None,
            api_key_revoked=(self._api_credential.key_id in self._revoked_api_key_ids if self._api_credential.key_id else None),
        )

    def _resolve_api_credential(self) -> CredentialState:
        return resolve_credential(
            explicit_value=self._config.api_key,
            explicit_key_id=self._config.api_key_id,
            value_env="THOTH_API_KEY",
            file_env="THOTH_API_KEY_FILE",
            key_id_env="THOTH_API_KEY_ID",
            expires_env="THOTH_API_KEY_EXPIRES_AT",
        )

    def _apply_api_credential(self, cred: CredentialState) -> None:
        if cred.value:
            self._http.headers["x-api-key"] = cred.value
        else:
            self._http.headers.pop("x-api-key", None)
        self._config.api_key = cred.value
        self._config.api_key_id = cred.key_id

    def _refresh_api_credential(self) -> None:
        refreshed = self._resolve_api_credential()
        if refreshed == self._api_credential:
            return
        self._api_credential = refreshed
        self._apply_api_credential(refreshed)
        self._fleet.update_headers(
            build_govapi_headers(
                fallback_api_key=refreshed.value,
                fallback_api_key_id=refreshed.key_id,
            )
        )

    def _refresh_revoked_api_keys(self) -> None:
        self._revoked_api_key_ids = load_revoked_key_ids()

    def _api_key_required(self) -> bool:
        raw = os.getenv("THOTH_REQUIRE_API_KEY", "").strip().lower()
        if raw in {"1", "true", "yes", "on"}:
            return True
        if raw in {"0", "false", "no", "off"}:
            return False
        env = os.getenv("THOTH_ENV", "prod").strip().lower()
        return env in {"staging", "prod"}

    async def _startup_preflight(self) -> bool:
        checks = [
            ("enforcer", self._config.enforcer_url, self._config.enforcement_mode not in {"observe", "progressive"}),
            ("govapi", self._fleet.govapi_url, False),
        ]
        for name, url, required in checks:
            if not url:
                continue
            if await _is_url_reachable(url, tls_config=self._tls_config, pin_verifier=self._tls_pin_verifier):
                continue
            if required:
                logger.error("thoth-proxy: startup preflight failed: %s endpoint unreachable: %s", name, url)
                return False
            logger.warning("thoth-proxy: startup preflight warning: %s endpoint unreachable: %s", name, url)
        return True


# ── Helpers ───────────────────────────────────────────────────────────────────


async def _write_bytes(stream: Any, data: bytes) -> None:
    """Write bytes to a stream-like object used in proxy transport paths."""
    send = getattr(stream, "send", None)
    if callable(send):
        await send(data)
        return

    write = getattr(stream, "write", None)
    if callable(write):
        result = write(data)
        if inspect.isawaitable(result):
            await result

        flush = getattr(stream, "flush", None)
        if callable(flush):
            flush_result = flush()
            if inspect.isawaitable(flush_result):
                await flush_result
        return

    raise TypeError(f"Unsupported stream object for byte writes: {type(stream)!r}")


def _is_json_rpc_line(line: bytes) -> bool:
    try:
        payload = json.loads(line)
    except Exception:
        return False
    if not isinstance(payload, dict):
        return False
    if payload.get("jsonrpc") != "2.0":
        return False
    return any(key in payload for key in ("id", "method", "result", "error"))


def _extract_embedded_json_rpc_line(line: bytes) -> tuple[bytes, bytes, bytes] | None:
    """
    Attempt to recover a JSON-RPC payload from a mixed stdout line that also
    contains non-JSON banner text.
    """
    text = line.decode("utf-8", errors="replace")
    decoder = json.JSONDecoder()

    start = text.find("{")
    while start != -1:
        candidate = text[start:]
        try:
            payload, end_index = decoder.raw_decode(candidate)
        except json.JSONDecodeError:
            start = text.find("{", start + 1)
            continue

        if isinstance(payload, dict) and payload.get("jsonrpc") == "2.0" and any(key in payload for key in ("id", "method", "result", "error")):
            prefix = text[:start].encode("utf-8", errors="replace")
            json_line = (candidate[:end_index].rstrip("\r\n") + "\n").encode("utf-8", errors="replace")
            suffix = candidate[end_index:].encode("utf-8", errors="replace")
            return prefix, json_line, suffix

        start = text.find("{", start + 1)

    return None


async def _is_url_reachable(
    url: str,
    *,
    tls_config: Any,
    pin_verifier: TLSCertPinVerifier | None = None,
) -> bool:
    try:
        if pin_verifier and pin_verifier.enabled:
            pin_verifier.verify(url)
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(connect=2.0, read=2.0, write=2.0, pool=2.0),
            verify=httpx_verify_value(tls_config),
        ) as client:
            resp = await client.get(url)
        return resp.status_code > 0
    except Exception:
        return False


def _spawn_debug_enabled() -> bool:
    raw = os.getenv("THOTH_DEBUG_SPAWN", "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _emit_spawn_debug(payload: dict[str, object]) -> None:
    if not _spawn_debug_enabled():
        return
    sys.stderr.write(f"thoth-proxy spawn debug: {json.dumps(payload, sort_keys=True)}\n")
    sys.stderr.flush()


def _build_spawn_command(cmd: ResolvedProcessCommand) -> list[str]:
    assert isinstance(cmd.executable, str)
    assert all(isinstance(arg, str) for arg in cmd.args)

    full_cmd = [cmd.executable, *cmd.args]
    full_cmd = [str(token) for token in full_cmd]

    if len(full_cmd) >= 2 and full_cmd[0].endswith("node") and full_cmd[1].endswith(".js"):
        full_cmd = [full_cmd[0], full_cmd[1], *full_cmd[2:]]

    for i, token in enumerate(full_cmd):
        if not token or token.strip() != token:
            raise RuntimeError(f"Invalid token at index {i}: {token!r}")
    return full_cmd


def _build_spawn_env(cmd: ResolvedProcessCommand, full_cmd: list[str]) -> dict[str, str]:
    env = dict(cmd.env)
    default_path = _DEFAULT_SPAWN_PATH_WINDOWS if os.name == "nt" else _DEFAULT_SPAWN_PATH_POSIX
    path_value = env.get("PATH", "") or default_path
    node_dir = str(Path(full_cmd[0]).parent) if full_cmd else ""
    if node_dir:
        path_value = f"{node_dir}{os.pathsep}{path_value}"
    env["PATH"] = path_value

    env.setdefault("HOME", str(Path("~").expanduser()))
    if os.name != "nt":
        env.setdefault("TMPDIR", "/tmp")
    return env


def build_proxy_from_env(
    agent_id: str,
    tenant_id: str,
    *,
    approved_scope: list[str] | None = None,
    user_id: str | None = None,
    enforcement_mode: str = "progressive",
    api_key: str | None = None,
    event_ingest_token: str | None = None,
    enforcer_url: str | None = None,
    session_intent: str | None = None,
) -> MCPProxy:
    """Construct an MCPProxy, resolving api_key, enforcer_url, and user_id from env vars."""
    explicit_enforcer = bool(enforcer_url and enforcer_url.strip())
    inferred_apex = _derive_apex_domain_from_url(enforcer_url or "") if explicit_enforcer else None
    bootstrap_local_profile(
        tenant_id=tenant_id,
        user_id=user_id,
        apex_domain=inferred_apex,
    )
    resolved_credential = resolve_credential(
        explicit_value=api_key,
        value_env="THOTH_API_KEY",
        file_env="THOTH_API_KEY_FILE",
        key_id_env="THOTH_API_KEY_ID",
        expires_env="THOTH_API_KEY_EXPIRES_AT",
    )
    resolved_key = resolved_credential.value
    resolved_url = enforcer_url or os.getenv("THOTH_ENFORCER_URL") or _DEFAULT_ENFORCER_URL
    _validate_enforcer_url_for_environment(resolved_url)
    resolved_govapi_url = resolve_govapi_url(resolved_url)
    resolved_user = user_id or os.getenv("THOTH_USER_ID") or "system"
    resolved_event_ingest_token = event_ingest_token if event_ingest_token is not None else os.getenv("THOTH_EVENT_INGEST_TOKEN")
    if resolved_event_ingest_token is not None:
        resolved_event_ingest_token = resolved_event_ingest_token.strip() or None
    config = ProxyConfig(
        agent_id=agent_id,
        tenant_id=tenant_id,
        approved_scope=approved_scope or [],
        user_id=resolved_user,
        enforcement_mode=enforcement_mode,
        api_key=resolved_key,
        api_key_id=resolved_credential.key_id,
        event_ingest_token=resolved_event_ingest_token,
        enforcer_url=resolved_url.rstrip("/"),
        govapi_url=resolved_govapi_url,
        session_intent=session_intent,
    )
    return MCPProxy(config)


def _derive_apex_domain_from_url(url: str) -> str | None:
    if not url:
        return None
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").strip().lower()
    if not hostname:
        return None
    labels = hostname.split(".")
    if len(labels) < 3:
        return None
    if labels[0] not in {"enforce", "grid", "enforcer", "govapi"}:
        return None
    return ".".join(labels[2:])


def _resolve_enforcer_failure_decision() -> str:
    raw = os.getenv("THOTH_ENFORCER_FAILURE_DECISION", "").strip().lower()
    if raw and raw != "block":
        logger.warning(
            "thoth-proxy: THOTH_ENFORCER_FAILURE_DECISION=%s ignored; fail-closed BLOCK is enforced",
            raw,
        )
    return "BLOCK"


def _validate_enforcer_url_for_environment(enforcer_url: str) -> None:
    parsed = urlparse(enforcer_url)
    scheme = parsed.scheme.lower()
    if scheme not in {"http", "https"}:
        raise ValueError(f"THOTH_ENFORCER_URL must use http or https, got: {enforcer_url}")
    if not parsed.hostname:
        raise ValueError(f"THOTH_ENFORCER_URL must include a hostname, got: {enforcer_url}")

    env = os.getenv("THOTH_ENV", "").strip().lower()
    if env not in {"staging", "prod"}:
        return
    if scheme == "https":
        return
    if _is_loopback_host(parsed.hostname):
        return
    raise ValueError(
        "THOTH_ENFORCER_URL must use https in staging/prod (http is allowed only for localhost/loopback).",
    )


def _is_loopback_host(hostname: str) -> bool:
    value = hostname.strip().lower()
    if value == "localhost":
        return True
    try:
        return ipaddress.ip_address(value).is_loopback
    except ValueError:
        return False
