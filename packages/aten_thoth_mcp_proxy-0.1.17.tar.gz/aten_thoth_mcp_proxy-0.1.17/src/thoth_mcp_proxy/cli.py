# thoth_mcp_proxy/cli.py
"""
CLI entry point for thoth / thoth-mcp-proxy.

Subcommands
-----------
thoth run      [OPTIONS] -- <upstream cmd>    proxy runtime
thoth wrap-config [OPTIONS] [FILE]            transform a claude_desktop_config.json
thoth status                                  show governance state on local config
thoth health --json                           emit machine-readable health for Jamf EA
"""

from __future__ import annotations

import argparse
import json
import logging
import os
from pathlib import Path
import shutil
import sys
from urllib.parse import urlparse

import anyio

from thoth_mcp_proxy import __version__
from thoth_mcp_proxy.bootstrap import bootstrap_local_profile
from thoth_mcp_proxy.execution_context import assess_least_privilege
from thoth_mcp_proxy.health import show_health
from thoth_mcp_proxy.process_resolver import ProcessResolutionError, build_clean_env, resolve_executable
from thoth_mcp_proxy.proxy import build_proxy_from_env
from thoth_mcp_proxy.status import show_status
from thoth_mcp_proxy.wrap_config import wrap_config


def _add_run_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--agent-id", required=True, help="Thoth agent identifier")
    p.add_argument("--tenant-id", required=True, help="Thoth tenant identifier")
    p.add_argument(
        "--session-intent",
        default=None,
        metavar="INTENT",
        help="HIPAA session intent (e.g. phi_eligibility_check, calendar_management)",
    )
    p.add_argument(
        "--approved-scope",
        default="",
        metavar="TOOLS",
        help="Comma-separated list of approved tool names (default: empty — policy decides all)",
    )
    p.add_argument(
        "--enforcement-mode",
        default="progressive",
        choices=["observe", "block", "step_up", "progressive"],
        help="Enforcement mode (default: progressive)",
    )
    p.add_argument(
        "--api-key",
        default=None,
        help="Thoth agent API key (overrides THOTH_API_KEY env var)",
    )
    p.add_argument(
        "--enforcer-url",
        default=None,
        metavar="URL",
        help="Enforcer base URL (overrides THOTH_ENFORCER_URL env var)",
    )
    p.add_argument(
        "--user-id",
        default=None,
        help="User identifier for audit events (default: system or THOTH_USER_ID env var)",
    )
    p.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Log level (default: WARNING)",
    )
    p.add_argument(
        "upstream",
        nargs=argparse.REMAINDER,
        help="Upstream MCP server command (everything after --)",
    )


def _add_wrap_config_args(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "file",
        nargs="?",
        default=None,
        metavar="FILE",
        help="Path to claude_desktop_config.json (default: stdin)",
    )
    p.add_argument("--tenant-id", required=True, help="Thoth tenant identifier")
    p.add_argument(
        "--api-key",
        default=None,
        help="Thoth agent API key (falls back to THOTH_API_KEY env var)",
    )
    p.add_argument(
        "--embed-api-key",
        action="store_true",
        help="Embed --api-key into generated config args (not recommended; use env/file-backed secrets).",
    )
    p.add_argument(
        "--enforcer-url",
        default=None,
        metavar="URL",
        help="Enforcer base URL (falls back to THOTH_ENFORCER_URL env var)",
    )
    p.add_argument(
        "--agent-id",
        default=None,
        help="Global agent-id override for all servers (default: per-server name)",
    )
    thoth_bin_group = p.add_mutually_exclusive_group()
    thoth_bin_group.add_argument(
        "--thoth-bin",
        default=None,
        metavar="PATH",
        help=("Absolute path to thoth executable used as wrapped command (example: /Library/Frameworks/Python.framework/Versions/3.13/bin/thoth)"),
    )
    thoth_bin_group.add_argument(
        "--auto-thoth-bin",
        action="store_true",
        help="Auto-resolve the full thoth executable path (same behavior as default resolution).",
    )
    p.add_argument(
        "--env",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help=("Inject env var into wrapped server config; may be passed multiple times (example: --env THOTH_APEX_DOMAIN=atensecurity.com)"),
    )
    p.add_argument(
        "--inherit-path",
        action="store_true",
        help="Inject current PATH into each wrapped server env after de-duplicating entries.",
    )
    p.add_argument(
        "--enforcement-mode",
        default="progressive",
        choices=["observe", "block", "step_up", "progressive"],
        help="Enforcement mode (default: progressive)",
    )
    p.add_argument(
        "--session-intent",
        default=None,
        metavar="INTENT",
        help="Global session intent for all servers (overridden per-server by --intent-map)",
    )
    p.add_argument(
        "--intent-map",
        default=None,
        metavar="FILE",
        help="JSON file mapping server name → session_intent",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print transformed JSON to stdout without writing",
    )
    p.add_argument(
        "--output",
        default=None,
        metavar="FILE",
        help="Write output to FILE instead of stdout",
    )


def _add_status_args(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--config",
        default=None,
        metavar="FILE",
        help="Path to claude_desktop_config.json (default: platform-specific location)",
    )


def _add_health_args(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Emit health snapshot as JSON (recommended for Jamf Extension Attributes)",
    )
    p.add_argument(
        "--config",
        default=None,
        metavar="FILE",
        help="Path to claude_desktop_config.json (optional, for config drift checks)",
    )


def _parse_upstream(remainder: list[str]) -> list[str]:
    """Strip leading '--' separator from upstream command args."""
    if remainder and remainder[0] == "--":
        return remainder[1:]
    return remainder


def _derive_apex_domain_from_url(url: str) -> str | None:
    if not url:
        return None
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").strip().lower()
    if not hostname:
        return None
    labels = hostname.split(".")
    if len(labels) < 3:
        return None
    if labels[0] not in {"enforce", "grid", "enforcer", "govapi"}:
        return None
    return ".".join(labels[2:])


def _parse_env_assignments(assignments: list[str]) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for item in assignments:
        key, sep, value = item.partition("=")
        if not sep or not key.strip():
            raise ValueError(f"invalid --env assignment: {item!r} (expected KEY=VALUE)")
        parsed[key.strip()] = value
    return parsed


def _dedupe_path_entries(path_value: str) -> str:
    sep = os.pathsep
    seen: set[str] = set()
    deduped: list[str] = []
    for raw_part in path_value.split(sep):
        part = raw_part.strip()
        if not part or part in seen:
            continue
        seen.add(part)
        deduped.append(part)
    return sep.join(deduped)


def _resolve_default_thoth_bin() -> str:
    if sys.executable:
        py_bin_dir = Path(sys.executable).resolve().parent
        candidate_names = ["thoth.exe", "thoth.cmd", "thoth.bat", "thoth"] if os.name == "nt" else ["thoth"]
        for name in candidate_names:
            candidate = py_bin_dir / name
            if candidate.exists():
                return str(candidate)

    resolved = shutil.which("thoth")
    if resolved:
        return resolved

    raise RuntimeError(
        "unable to resolve thoth executable path; pass --thoth-bin /full/path/to/thoth or ensure thoth is installed on PATH",
    )


def _run_command(args: argparse.Namespace) -> None:
    bootstrap_local_profile(
        tenant_id=args.tenant_id,
        user_id=args.user_id,
        apex_domain=_derive_apex_domain_from_url(args.enforcer_url or ""),
    )

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(levelname)s thoth-proxy: %(message)s",
        stream=sys.stderr,
    )

    upstream_cmd = _parse_upstream(args.upstream)
    if not upstream_cmd:
        sys.stderr.write("error: upstream MCP server command is required (after --)\n")
        sys.exit(2)

    privilege = assess_least_privilege()
    if not privilege.gate_ok:
        joined = "; ".join(privilege.reasons)
        sys.stderr.write(f"error: least-privilege check failed: {joined}\n")
        sys.exit(2)

    approved_scope = [t.strip() for t in args.approved_scope.split(",") if t.strip()] if args.approved_scope else []

    proxy = build_proxy_from_env(
        agent_id=args.agent_id,
        tenant_id=args.tenant_id,
        approved_scope=approved_scope,
        user_id=args.user_id,
        enforcement_mode=args.enforcement_mode,
        api_key=args.api_key,
        enforcer_url=args.enforcer_url,
        session_intent=args.session_intent,
    )

    async def _run() -> None:
        try:
            exit_code = await proxy.run(upstream_cmd)
        finally:
            await proxy.aclose()
        sys.exit(exit_code)

    anyio.run(_run)


def _wrap_config_command(args: argparse.Namespace) -> None:
    bootstrap_local_profile(
        tenant_id=args.tenant_id,
    )

    # Read input
    if args.file:
        with open(args.file) as fh:
            try:
                config = json.load(fh)
            except json.JSONDecodeError as exc:
                sys.stderr.write(f"error: invalid JSON in {args.file}: {exc}\n")
                sys.exit(1)
    else:
        try:
            config = json.load(sys.stdin)
        except json.JSONDecodeError as exc:
            sys.stderr.write(f"error: invalid JSON on stdin: {exc}\n")
            sys.exit(1)

    # Load intent map if provided
    intent_map: dict[str, str] | None = None
    if args.intent_map:
        with open(args.intent_map) as fh:
            intent_map = json.load(fh)

    # Resolve api_key from env fallback
    api_key = args.api_key or os.getenv("THOTH_API_KEY")
    enforcer_url = args.enforcer_url or os.getenv("THOTH_ENFORCER_URL")
    try:
        env_updates = _parse_env_assignments(args.env)
    except ValueError as exc:
        sys.stderr.write(f"error: {exc}\n")
        sys.exit(2)

    if args.inherit_path:
        inherited_path = _dedupe_path_entries(os.getenv("PATH", ""))
        if inherited_path:
            env_updates.setdefault("PATH", inherited_path)

    try:
        if args.thoth_bin:
            thoth_bin = args.thoth_bin
        elif args.auto_thoth_bin:
            thoth_bin = _resolve_default_thoth_bin()
        else:
            thoth_bin = _resolve_default_thoth_bin()
    except RuntimeError as exc:
        sys.stderr.write(f"error: {exc}\n")
        sys.exit(2)

    result = wrap_config(
        config,
        tenant_id=args.tenant_id,
        agent_id=args.agent_id,
        api_key=api_key,
        enforcer_url=enforcer_url,
        enforcement_mode=args.enforcement_mode,
        session_intent=args.session_intent,
        intent_map=intent_map,
        embed_api_key=args.embed_api_key,
        thoth_bin=thoth_bin,
        env_updates=env_updates,
    )

    output_json = json.dumps(result, indent=2)

    if args.dry_run or args.output is None:
        print(output_json)

    if not args.dry_run and args.output is not None:
        with open(args.output, "w") as fh:
            fh.write(output_json + "\n")


def _status_command(args: argparse.Namespace) -> None:
    bootstrap_local_profile()
    sys.exit(show_status(args.config))


def _health_command(args: argparse.Namespace) -> None:
    bootstrap_local_profile()
    sys.exit(show_health(json_output=args.json_output, config_path=args.config))


def _doctor_command(_args: argparse.Namespace) -> None:
    bootstrap_local_profile()

    env = build_clean_env()

    failures = 0
    checks = [
        ("node", True),
        ("npm", True),
        ("npx", False),
    ]

    for executable, required in checks:
        try:
            resolved = resolve_executable(executable, env=env)
            print(f"[ok]   {executable}: {resolved}")
        except ProcessResolutionError as exc:
            level = "fail" if required else "warn"
            print(f"[{level}] {executable}: {exc}")
            if exc.suggestion:
                print(f"       suggestion: {exc.suggestion}")
            if required:
                failures += 1

    key_file = os.getenv("THOTH_API_KEY_FILE", "").strip()
    if key_file:
        exists = Path(key_file).exists()
        print(f"[{'ok' if exists else 'warn'}] THOTH_API_KEY_FILE: {key_file}")
        if not exists:
            print("       suggestion: file does not exist; update THOTH_API_KEY_FILE or create the file.")
    else:
        print("[warn] THOTH_API_KEY_FILE is not set")

    tenant_id = os.getenv("THOTH_TENANT_ID", "").strip()
    govapi_url = os.getenv("THOTH_GOVAPI_URL", "").strip()
    govapi_legacy = os.getenv("THOTH_GOV_API_URL", "").strip()
    resolved_govapi_url = govapi_url or govapi_legacy
    print(f"[{'ok' if tenant_id else 'warn'}] THOTH_TENANT_ID: {tenant_id or '<unset>'}")
    print(f"[{'ok' if resolved_govapi_url else 'warn'}] THOTH_GOVAPI_URL: {resolved_govapi_url or '<unset>'}")
    print(f"[{'ok' if resolved_govapi_url else 'warn'}] THOTH_GOV_API_URL: {resolved_govapi_url or '<unset>'}")
    print(f"[info] PATH: {env.get('PATH', '')}")

    sys.exit(1 if failures else 0)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="thoth",
        description="Thoth governance proxy for Claude Desktop / MCP servers.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    run_p = sub.add_parser(
        "run",
        help="Start the governance proxy for an upstream MCP server",
        epilog="Everything after -- is the upstream MCP server command.",
    )
    _add_run_args(run_p)

    wrap_p = sub.add_parser(
        "wrap-config",
        help="Transform a claude_desktop_config.json to add Thoth governance",
    )
    _add_wrap_config_args(wrap_p)

    status_p = sub.add_parser(
        "status",
        help="Show governance state of the local Claude Desktop config",
    )
    _add_status_args(status_p)

    health_p = sub.add_parser(
        "health",
        help="Show endpoint health and fleet registration state",
    )
    _add_health_args(health_p)

    sub.add_parser(
        "doctor",
        help="Diagnose local runtime prerequisites and executable resolution",
    )

    return parser


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "run":
        _run_command(args)
    elif args.command == "wrap-config":
        _wrap_config_command(args)
    elif args.command == "status":
        _status_command(args)
    elif args.command == "health":
        _health_command(args)
    elif args.command == "doctor":
        _doctor_command(args)
