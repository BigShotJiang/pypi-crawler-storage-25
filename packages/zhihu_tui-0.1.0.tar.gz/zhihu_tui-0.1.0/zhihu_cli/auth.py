"""Authentication for Zhihu.

Strategy:
1. Try loading saved credential from ~/.zhihu-cli/credential.json
2. Try extracting cookies from local browsers via browser-cookie3
3. Fallback: manual cookie input from user
"""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Literal

import aiohttp

logger = logging.getLogger(__name__)

CONFIG_DIR = Path.home() / ".zhihu-cli"
CREDENTIAL_FILE = CONFIG_DIR / "credential.json"

REQUIRED_COOKIES = {"z_c0"}

CREDENTIAL_TTL_DAYS = 7
_CREDENTIAL_TTL_SECONDS = CREDENTIAL_TTL_DAYS * 86400

AuthMode = Literal["optional", "read", "write"]


class ZhihuCredential:
    """Simple credential container for Zhihu cookies."""

    def __init__(
        self,
        z_c0: str = "",
        xsrf_token: str = "",
        _xsrf: str = "",
        user_agent: str = "",
    ):
        self.z_c0 = z_c0
        self.xsrf_token = xsrf_token
        self._xsrf = _xsrf
        self.user_agent = user_agent

    def as_cookie_header(self) -> str:
        """Build a Cookie header string."""
        parts = []
        if self.z_c0:
            parts.append(f"z_c0={self.z_c0}")
        if self._xsrf:
            parts.append(f"_xsrf={self._xsrf}")
        return "; ".join(parts)

    def as_dict(self) -> dict[str, str]:
        return {
            "z_c0": self.z_c0,
            "xsrf_token": self.xsrf_token,
            "_xsrf": self._xsrf,
            "user_agent": self.user_agent,
        }


def get_credential(mode: AuthMode = "read") -> ZhihuCredential | None:
    """Try auth methods in order and return credential according to mode.

    - optional: only load saved credential (no network validation, no browser scan)
    - read: prefer validated credential; fallback to browser cookies
    - write: same as read, but require xsrf_token
    """
    require_write = mode == "write"

    # 1. Saved credential file
    cred = _load_saved_credential()
    if cred:
        if _is_credential_stale():
            logger.info("Credential older than %d days, attempting browser refresh", CREDENTIAL_TTL_DAYS)
            fresh = _extract_browser_credential()
            if fresh:
                validation = _validate_credential(fresh, require_write=require_write)
                if validation is True:
                    logger.info("Refreshed credential from browser")
                    save_credential(fresh)
                    return fresh
            logger.warning(
                "Credential is %d+ days old; browser refresh failed. Validating existing credential...",
                CREDENTIAL_TTL_DAYS,
            )

        if mode == "optional":
            return cred
        validation = _validate_credential(cred, require_write=require_write)
        if validation is True:
            logger.info("Loaded valid credential from %s", CREDENTIAL_FILE)
            return cred
        if validation is None:
            logger.warning("Credential validation failed due to network; using saved credential as best effort")
            return cred
        if validation is False:
            logger.warning("Saved credential is expired, clearing")
            clear_credential()

    if mode == "optional":
        return None

    # 2. Browser cookie extraction
    cred = _extract_browser_credential()
    if cred:
        validation = _validate_credential(cred, require_write=require_write)
        if validation is True:
            logger.info("Extracted valid credential from local browser")
            save_credential(cred)
            return cred
        if validation is None:
            logger.warning("Skipping browser credential validation due to network; using best effort")
            return cred
        if validation is False:
            logger.warning("Browser cookies are expired/invalid")

    return None


def _is_credential_stale() -> bool:
    """Check if saved credential file is older than TTL."""
    if not CREDENTIAL_FILE.exists():
        return False
    try:
        data = json.loads(CREDENTIAL_FILE.read_text())
        saved_at = data.get("saved_at", 0)
        if not saved_at:
            return True
        return (time.time() - saved_at) > _CREDENTIAL_TTL_SECONDS
    except (json.JSONDecodeError, OSError):
        return False


def _validate_credential(cred: ZhihuCredential, require_write: bool = False) -> bool | None:
    """Check if a credential is valid.

    Returns:
      - True: credential validated by API
      - False: credential confirmed invalid or missing required fields
      - None: validation is indeterminate due to network/runtime issues
    """
    if not cred.z_c0:
        return False
    if require_write and not (cred.xsrf_token or cred._xsrf):
        return False

    async def _check():
        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    "User-Agent": _get_user_agent(),
                    "Cookie": cred.as_cookie_header(),
                }
                async with session.get(
                    "https://www.zhihu.com/api/v4/me",
                    headers=headers,
                ) as resp:
                    if resp.status == 200:
                        return True
                    if resp.status in (401, 403):
                        return False
                    return None
        except (aiohttp.ClientError, asyncio.TimeoutError):
            return None

    try:
        return asyncio.run(_check())
    except Exception:
        return None


def _load_saved_credential() -> ZhihuCredential | None:
    """Load credential from saved file."""
    if not CREDENTIAL_FILE.exists():
        return None

    try:
        data = json.loads(CREDENTIAL_FILE.read_text())
        z_c0 = data.get("z_c0", "")
        if not z_c0:
            return None
        return ZhihuCredential(
            z_c0=z_c0,
            xsrf_token=data.get("xsrf_token", ""),
            _xsrf=data.get("_xsrf", ""),
            user_agent=data.get("user_agent", ""),
        )
    except (json.JSONDecodeError, KeyError) as e:
        logger.warning("Failed to load saved credential: %s", e)
        return None


def _get_user_agent() -> str:
    return (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/133.0.0.0 Safari/537.36"
    )


def _extract_browser_credential() -> ZhihuCredential | None:
    """Extract Zhihu cookies from local browsers using browser-cookie3."""
    extract_script = '''
import json, sys
try:
    import browser_cookie3 as bc3
except ImportError:
    print(json.dumps({"error": "not_installed"}))
    sys.exit(0)

browsers = [
    ("Chrome", bc3.chrome),
    ("Firefox", bc3.firefox),
    ("Edge", bc3.edge),
    ("Brave", bc3.brave),
]

for name, loader in browsers:
    try:
        cj = loader(domain_name=".zhihu.com")
        cookies = {c.name: c.value for c in cj if "zhihu.com" in (c.domain or "")}
        if "z_c0" in cookies:
            print(json.dumps({"browser": name, "cookies": cookies}))
            sys.exit(0)
    except Exception:
        pass

print(json.dumps({"error": "no_cookies"}))
'''

    try:
        result = subprocess.run(
            [sys.executable, "-c", extract_script],
            capture_output=True,
            text=True,
            timeout=15,
        )

        if result.returncode != 0:
            logger.debug("Cookie extraction subprocess failed: %s", result.stderr)
            return None

        output = result.stdout.strip()
        if not output:
            return None

        data = json.loads(output)

        if "error" in data:
            if data["error"] == "not_installed":
                logger.debug("browser-cookie3 not installed, skipping")
            else:
                logger.debug("No valid Zhihu cookies found in any browser")
            return None

        cookies = data["cookies"]
        browser_name = data["browser"]
        logger.info("Found valid cookies in %s (%d cookies)", browser_name, len(cookies))

        return ZhihuCredential(
            z_c0=cookies.get("z_c0", ""),
            xsrf_token=cookies.get("xsrf_token", ""),
            _xsrf=cookies.get("_xsrf", ""),
        )

    except subprocess.TimeoutExpired:
        logger.warning(
            "Cookie extraction timed out (browser may be running). "
            "Try closing your browser or use `zhihu login`."
        )
        return None
    except (json.JSONDecodeError, KeyError) as e:
        logger.warning("Cookie extraction parse error: %s", e)
        return None


def save_credential(credential: ZhihuCredential):
    """Save credential to config file with timestamp for TTL tracking."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    data = {
        "z_c0": credential.z_c0,
        "xsrf_token": credential.xsrf_token,
        "_xsrf": credential._xsrf,
        "user_agent": credential.user_agent,
        "saved_at": time.time(),
    }
    CREDENTIAL_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    CREDENTIAL_FILE.chmod(0o600)
    logger.info("Credential saved to %s", CREDENTIAL_FILE)


def clear_credential():
    """Remove saved credential file."""
    if CREDENTIAL_FILE.exists():
        CREDENTIAL_FILE.unlink()
        logger.info("Credential removed: %s", CREDENTIAL_FILE)


def manual_login(z_c0: str, xsrf_token: str = "", _xsrf: str = "") -> ZhihuCredential:
    """Create credential from manually provided cookies."""
    cred = ZhihuCredential(
        z_c0=z_c0.strip(),
        xsrf_token=xsrf_token.strip(),
        _xsrf=_xsrf.strip(),
    )
    save_credential(cred)
    return cred
