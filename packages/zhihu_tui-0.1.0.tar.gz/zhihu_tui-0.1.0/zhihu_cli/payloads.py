"""Stable structured payload builders for zhihu-cli commands."""

from __future__ import annotations

import re
from typing import Any


def _to_int(value: object, default: int = 0) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        try:
            return int(value.strip())
        except ValueError:
            return default
    return default


def _strip_html(text: object) -> str:
    if not isinstance(text, str):
        return ""
    return re.sub(r"<[^>]+>", "", text).strip()


def normalize_user(info: dict[str, Any]) -> dict[str, Any]:
    """Normalize user info from /api/v4/members/{url_token} or /api/v4/me."""
    return {
        "id": info.get("id", ""),
        "url_token": info.get("url_token", ""),
        "name": info.get("name", ""),
        "headline": info.get("headline", ""),
        "description": info.get("description", ""),
        "avatar_url": info.get("avatar_url", ""),
        "follower_count": _to_int(info.get("follower_count"), 0),
        "following_count": _to_int(info.get("following_count"), 0),
        "answer_count": _to_int(info.get("answer_count"), 0),
        "articles_count": _to_int(info.get("articles_count"), 0),
        "question_count": _to_int(info.get("question_count"), 0),
        "pins_count": _to_int(info.get("pins_count"), 0),
        "columns_count": _to_int(info.get("columns_count"), 0),
        "favorite_count": _to_int(info.get("favorite_count"), 0),
    }


def normalize_question(info: dict[str, Any]) -> dict[str, Any]:
    """Normalize question info."""
    result: dict[str, Any] = {
        "id": _to_int(info.get("id"), 0),
        "title": _strip_html(info.get("title", "")),
        "url": f"https://www.zhihu.com/question/{info.get('id', '')}",
    }

    # 只包含有值的可选字段
    answer_count = _to_int(info.get("answer_count"), 0)
    if answer_count:
        result["answer_count"] = answer_count
    follower_count = _to_int(info.get("follower_count"), 0)
    if follower_count:
        result["follower_count"] = follower_count
    for field in ("excerpt", "detail"):
        val = info.get(field, "")
        if val:
            result[field] = _strip_html(val) if field == "detail" else val
    if info.get("created"):
        result["created_time"] = info.get("created")

    author = info.get("author")
    if isinstance(author, dict) and author.get("name"):
        result["author"] = _normalize_author(author)

    return result


def normalize_answer(info: dict[str, Any]) -> dict[str, Any]:
    """Normalize answer info."""
    question = info.get("question", {}) if isinstance(info.get("question"), dict) else {}
    result: dict[str, Any] = {
        "id": _to_int(info.get("id"), 0),
        "question_id": _to_int(question.get("id"), 0),
        "question_title": _strip_html(question.get("title", "")),
        "excerpt": info.get("excerpt", ""),
        "voteup_count": _to_int(info.get("voteup_count"), 0),
        "url": f"https://www.zhihu.com/question/{question.get('id', '')}/answer/{info.get('id', '')}",
    }

    content = info.get("content", "")
    if content:
        result["content"] = _strip_html(content)
    comment_count = _to_int(info.get("comment_count"), 0)
    if comment_count:
        result["comment_count"] = comment_count
    if info.get("created_time"):
        result["created_time"] = info["created_time"]
    if info.get("updated_time"):
        result["updated_time"] = info["updated_time"]
    author = info.get("author")
    if isinstance(author, dict) and author.get("name"):
        result["author"] = _normalize_author(author)

    return result


def normalize_article(info: dict[str, Any]) -> dict[str, Any]:
    """Normalize article info."""
    result: dict[str, Any] = {
        "id": _to_int(info.get("id"), 0),
        "title": _strip_html(info.get("title", "")),
        "excerpt": info.get("excerpt", ""),
        "content": _strip_html(info.get("content", "")),
        "comment_count": _to_int(info.get("comment_count"), 0),
        "voteup_count": _to_int(info.get("voteup_count"), 0),
        "created_time": info.get("created", 0),
        "updated_time": info.get("updated", 0),
        "url": info.get("url", f"https://zhuanlan.zhihu.com/p/{info.get('id', '')}"),
        "author": _normalize_author(info.get("author", {})),
    }
    column = info.get("column")
    if isinstance(column, dict) and column.get("name"):
        result["column"] = _normalize_column(column)
    return result


def normalize_pin(info: dict[str, Any]) -> dict[str, Any]:
    """Normalize pin (想法) info."""
    # pin 的 content 是数组，拼接文本内容
    content_parts = info.get("content", [])
    if isinstance(content_parts, list):
        text = " ".join(_strip_html(p.get("content", "")) for p in content_parts if p.get("type") == "text")
    else:
        text = _strip_html(str(content_parts))

    result: dict[str, Any] = {
        "id": _to_int(info.get("id"), 0),
        "content": text,
        "like_count": _to_int(info.get("like_count"), 0),
        "comment_count": _to_int(info.get("comment_count"), 0),
        "repin_count": _to_int(info.get("repin_count"), 0),
        "url": f"https://www.zhihu.com/pin/{info.get('id', '')}",
    }
    author = info.get("author")
    if isinstance(author, dict) and author.get("name"):
        result["author"] = _normalize_author(author)
    tags = info.get("tags")
    if isinstance(tags, list) and tags:
        result["tags"] = tags
    if info.get("created"):
        result["created_time"] = info["created"]
    if info.get("updated"):
        result["updated_time"] = info["updated"]
    return result


def normalize_comment(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a comment."""
    # 评论的 author 结构是 {member: {name, url_token}}，需要展平
    raw_author = item.get("author", {})
    if isinstance(raw_author, dict) and "member" in raw_author:
        raw_author = raw_author["member"]
    result: dict[str, Any] = {
        "id": _to_int(item.get("id"), 0),
        "content": _strip_html(item.get("content", "")),
        "author": _normalize_author(raw_author),
    }
    # 评论 API 用 vote_count，不是 voteup_count
    vote_count = _to_int(item.get("vote_count") or item.get("voteup_count"), 0)
    if vote_count:
        result["vote_count"] = vote_count
    if item.get("created_time"):
        result["created_time"] = item["created_time"]
    return result


def normalize_search_result(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a search result item."""
    obj = item.get("object", {}) if isinstance(item.get("object"), dict) else {}
    obj_type = obj.get("type", "") if isinstance(obj, dict) else ""
    return {
        "type": obj_type,
        "id": _to_int(obj.get("id"), 0),
        "title": _strip_html(obj.get("title") or obj.get("name", "")),
        "excerpt": _strip_html(obj.get("excerpt", "") or obj.get("headline", "")),
        "author": _normalize_author(obj.get("author", {})),
        "voteup_count": _to_int(obj.get("voteup_count"), 0),
        "answer_count": _to_int(obj.get("answer_count"), 0),
        "follower_count": _to_int(obj.get("follower_count"), 0),
        "url": _build_page_url(obj_type, obj),
    }


def _build_page_url(obj_type: str, obj: dict[str, Any]) -> str:
    """Build a human-visitable page URL from search result object."""
    obj_id = obj.get("id", "")
    url_token = obj.get("url_token", "")

    if obj_type == "people":
        if url_token:
            return f"https://www.zhihu.com/people/{url_token}"
    elif obj_type == "topic":
        if obj_id:
            return f"https://www.zhihu.com/topic/{obj_id}"
    elif obj_type == "question":
        if obj_id:
            return f"https://www.zhihu.com/question/{obj_id}"
    elif obj_type == "answer":
        question = obj.get("question", {})
        qid = question.get("id", "") if isinstance(question, dict) else ""
        if qid and obj_id:
            return f"https://www.zhihu.com/question/{qid}/answer/{obj_id}"
    elif obj_type == "article":
        if obj_id:
            return f"https://zhuanlan.zhihu.com/p/{obj_id}"
    elif obj_type == "column":
        if obj_id:
            return f"https://www.zhihu.com/column/{obj_id}"
    elif obj_type == "pin_general":
        if obj_id:
            return f"https://www.zhihu.com/pin/{obj_id}"
    elif obj_type == "zvideo":
        vid = obj.get("zvideo_id", "") or obj_id
        if vid:
            return f"https://www.zhihu.com/zvideo/{vid}"
    # fallback: return raw URL or empty
    return obj.get("url", "")


def normalize_hot_item(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a hot list item."""
    target = item.get("target", {}) if isinstance(item.get("target"), dict) else {}
    return {
        "id": _to_int(target.get("id"), 0),
        "title": _strip_html(target.get("title", "")),
        "excerpt": target.get("excerpt", ""),
        "url": f"https://www.zhihu.com/question/{target.get('id', '')}",
        "detail_text": item.get("detail_text", ""),
        "heat": _to_int(item.get("detail_text", "").replace("万热度", "").strip(), 0),
    }


def normalize_feed_item(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a feed item."""
    target = item.get("target", {}) if isinstance(item.get("target"), dict) else {}
    item_type = item.get("type", "")
    return {
        "type": item_type,
        "id": _to_int(target.get("id"), 0),
        "title": _strip_html(target.get("title", "")),
        "excerpt": target.get("excerpt", ""),
        "author": _normalize_author(target.get("author", {})),
        "voteup_count": _to_int(target.get("voteup_count"), 0),
        "comment_count": _to_int(target.get("comment_count"), 0),
    }


def normalize_following_user(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a following user item."""
    return normalize_user(item)


def normalize_favorite_item(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a favorite (bookmark) item."""
    content = item.get("content", {}) if isinstance(item.get("content"), dict) else {}
    item_type = content.get("type", item.get("type", ""))
    return {
        "id": _to_int(content.get("id", item.get("id", 0)), 0),
        "type": item_type,
        "title": _strip_html(content.get("title", "")),
        "excerpt": content.get("excerpt", ""),
        "url": content.get("url", ""),
    }


def normalize_collection(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a collection (收藏夹)."""
    return {
        "id": _to_int(item.get("id"), 0),
        "title": item.get("title", ""),
        "description": item.get("description", ""),
        "item_count": _to_int(item.get("item_count"), 0),
        "follower_count": _to_int(item.get("follower_count"), 0),
    }


def action_result(action: str, *, success: bool = True, **fields: Any) -> dict[str, Any]:
    """Build a standard action result payload."""
    payload: dict[str, Any] = {"success": success, "action": action}
    payload.update(fields)
    return payload


def _normalize_author(author: dict[str, Any]) -> dict[str, Any]:
    """Normalize an author object."""
    if not isinstance(author, dict):
        return {"name": "", "url_token": ""}
    return {
        "name": author.get("name", ""),
        "url_token": author.get("url_token", ""),
        "headline": author.get("headline", ""),
    }


def _normalize_column(column: dict[str, Any]) -> dict[str, Any]:
    """Normalize a column object."""
    if not isinstance(column, dict):
        return {"name": "", "id": 0}
    return {
        "id": _to_int(column.get("id"), 0),
        "name": column.get("name", ""),
        "url_token": column.get("url_token", ""),
    }
