"""Search command."""

from __future__ import annotations

import re

import click
from rich.table import Table

from .. import payloads
from . import common

_SEARCH_TYPES = [
    "content", "people", "scholar", "column",
    "km_general", "publication", "ring", "topic", "zvideo",
]

_TYPE_LABELS = {
    "content": "综合",
    "people": "用户",
    "scholar": "论文",
    "column": "专栏",
    "km_general": "盐选内容",
    "publication": "电子书",
    "ring": "圈子",
    "topic": "话题",
    "zvideo": "视频",
}

_OBJ_TYPE_NAMES = {
    "answer": "回答",
    "question": "问题",
    "article": "文章",
    "people": "用户",
    "topic": "话题",
    "pin_general": "想法",
    "scholar": "论文",
    "column": "专栏",
    "zvideo": "视频",
    "ring_box": "圈子",
}


@click.command(name="search")
@click.argument("keyword")
@click.option("--type", "search_type", default="content", type=click.Choice(_SEARCH_TYPES), help="搜索类型 (默认 content)。")
@click.option("--limit", "-n", "count", default=20, type=click.IntRange(1), help="显示数量 (默认 20)。")
@common.structured_output_options
def search_cmd(keyword: str, search_type: str, count: int, as_json: bool, as_yaml: bool):
    """搜索知乎内容。"""
    from .. import client

    # content → general for the API
    api_type = "general" if search_type == "content" else search_type
    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.get_credential(mode="optional")
    data = common.run_or_exit(
        client.search(keyword, search_type=api_type, limit=count, credential=cred),
        "搜索失败",
    )

    items = data.get("data", [])
    # Filter out ads
    items = [item for item in items if item.get("type") != "ad"]

    if common.emit_structured([payloads.normalize_search_result(item) for item in items[:count]], output_format):
        return

    if not items:
        common.console.print(f"[yellow]未找到与 '{keyword}' 相关的内容[/yellow]")
        return

    type_label = _TYPE_LABELS.get(search_type, search_type)
    table = Table(title=f"🔍 {type_label}搜索: {keyword}", border_style="blue")
    table.add_column("#", style="dim", width=4)
    table.add_column("类型", no_wrap=False, overflow="fold")
    table.add_column("标题/名称", no_wrap=False, overflow="fold")
    table.add_column("作者", no_wrap=False, overflow="fold")
    table.add_column("赞同", width=8, justify="right")
    table.add_column("链接", no_wrap=False, overflow="fold")

    for i, item in enumerate(items[:count], 1):
        obj = item.get("object", {})
        obj_type = obj.get("type", "") or item.get("type", "")
        raw_title = obj.get("title") or obj.get("name", "")
        clean_title = re.sub(r"<[^>]+>", "", raw_title) if raw_title else ""

        if obj_type == "people":
            author_name = clean_title
            count_val = obj.get("follower_count", 0)
        else:
            author = obj.get("author", {})
            author_name = author.get("name", "")
            count_val = obj.get("voteup_count", 0)

        table.add_row(
            str(i),
            _OBJ_TYPE_NAMES.get(obj_type, obj_type),
            clean_title,
            author_name,
            common.format_count(count_val),
            payloads._build_page_url(obj_type, obj),
        )
    common.console.print(table)
