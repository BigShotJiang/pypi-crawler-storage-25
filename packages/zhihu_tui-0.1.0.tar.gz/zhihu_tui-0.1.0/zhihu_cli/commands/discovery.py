"""Discovery commands (hot)."""

from __future__ import annotations

import click
from rich.table import Table

from .. import payloads
from . import common


@click.command(name="hot")
@click.option("--limit", "-n", "count", default=30, type=click.IntRange(1, 30), help="显示数量 (默认 30，最多 30)。")
@common.structured_output_options
def hot_cmd(count: int, as_json: bool, as_yaml: bool):
    """查看知乎热榜。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.get_credential(mode="optional")
    data = common.run_or_exit(client.get_hot_list(limit=count, credential=cred), "获取热榜失败")

    items = data.get("data", [])

    if common.emit_structured([payloads.normalize_hot_item(item) for item in items[:count]], output_format):
        return

    if not items:
        common.console.print("[yellow]未获取到热榜数据[/yellow]")
        return

    table = Table(title="🔥 知乎热榜", border_style="red")
    table.add_column("#", style="bold", width=4)
    table.add_column("问题", no_wrap=False, overflow="fold")
    table.add_column("热度", width=12, justify="right")

    for i, item in enumerate(items[:count], 1):
        target = item.get("target", {})
        detail_text = item.get("detail_text", "")
        table.add_row(
            str(i),
            target.get("title", ""),
            detail_text,
        )
    common.console.print(table)
