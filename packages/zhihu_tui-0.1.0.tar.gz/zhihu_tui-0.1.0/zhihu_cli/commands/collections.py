"""Collection and timeline related commands."""

from __future__ import annotations

import click
from rich.table import Table

from .. import payloads
from . import common


@click.command()
@click.option("--offset", "-o", default=0, type=click.IntRange(0), help="偏移量 (默认 0)。")
@click.option("--limit", "-n", default=20, type=click.IntRange(1), help="显示数量 (默认 20)。")
@common.structured_output_options
def favorites(offset: int, limit: int, as_json: bool, as_yaml: bool):
    """查看我的收藏夹列表。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.require_login(message="需要登录才能查看收藏。使用 [bold]zhihu login[/bold] 登录。")

    data = common.run_or_exit(
        client.get_favorites(offset=offset, limit=limit, credential=cred),
        "获取收藏失败",
    )
    items = data.get("data", [])

    if common.emit_structured([payloads.normalize_collection(item) for item in items], output_format):
        return

    if not items:
        common.console.print("[yellow]暂无收藏夹[/yellow]")
        return

    table = Table(title="⭐ 我的收藏夹", border_style="blue")
    table.add_column("#", style="dim", width=4)
    table.add_column("ID", style="cyan", width=10)
    table.add_column("名称", no_wrap=False, overflow="fold")
    table.add_column("条目数", width=8, justify="right")
    table.add_column("关注者", width=8, justify="right")

    for i, item in enumerate(items, offset + 1):
        table.add_row(
            str(i),
            str(item.get("id", "")),
            item.get("title", "") or "",
            str(item.get("item_count", 0)),
            str(item.get("follower_count", 0)),
        )
    common.console.print(table)


@click.command(name="following")
@click.option("--offset", "-o", default=0, type=click.IntRange(0), help="偏移量 (默认 0)。")
@click.option("--limit", "-n", default=20, type=click.IntRange(1), help="显示数量 (默认 20)。")
@common.structured_output_options
def following_cmd(offset: int, limit: int, as_json: bool, as_yaml: bool):
    """查看我关注的人。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.require_login()

    me = common.run_or_exit(client.get_self_info(cred), "获取用户信息失败")
    url_token = me.get("url_token", "")
    if not url_token:
        common.exit_error("获取用户 url_token 失败")

    data = common.run_or_exit(
        client.get_following(url_token, offset=offset, limit=limit, credential=cred),
        "获取关注列表失败",
    )
    items = data.get("data", [])

    if common.emit_structured([payloads.normalize_following_user(item) for item in items], output_format):
        return

    if not items:
        common.console.print("[yellow]关注列表为空[/yellow]")
        return

    table = Table(title="🔔 关注列表", border_style="blue")
    table.add_column("#", style="dim", width=4)
    table.add_column("ID", style="cyan", width=16)
    table.add_column("用户名", no_wrap=False, overflow="fold")
    table.add_column("简介", no_wrap=False, overflow="fold")

    for i, u in enumerate(items, offset + 1):
        table.add_row(
            str(i),
            u.get("url_token", ""),
            u.get("name", ""),
            u.get("headline", "") or "",
        )
    common.console.print(table)


@click.command(name="collections")
@click.argument("url_token", required=False)
@click.option("--offset", "-o", default=0, type=click.IntRange(0), help="偏移量 (默认 0)。")
@click.option("--limit", "-n", default=20, type=click.IntRange(1), help="显示数量 (默认 20)。")
@common.structured_output_options
def collections_cmd(url_token: str | None, offset: int, limit: int, as_json: bool, as_yaml: bool):
    """查看收藏夹列表。

    URL_TOKEN 为用户 ID。不提供则查看自己的。
    """
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = None

    if not url_token:
        cred = common.require_login()
        me = common.run_or_exit(client.get_self_info(cred), "获取用户信息失败")
        url_token = me.get("url_token", "")
        if not url_token:
            common.exit_error("获取用户 url_token 失败")
    else:
        cred = common.get_credential(mode="optional")

    data = common.run_or_exit(
        client.get_collections(url_token, offset=offset, limit=limit, credential=cred),
        "获取收藏夹失败",
    )
    items = data.get("data", [])

    if common.emit_structured([payloads.normalize_collection(item) for item in items], output_format):
        return

    if not items:
        common.console.print("[yellow]暂无收藏夹[/yellow]")
        return

    table = Table(title=f"📂 {url_token} 的收藏夹", border_style="blue")
    table.add_column("#", style="dim", width=4)
    table.add_column("ID", style="cyan", width=10)
    table.add_column("名称", no_wrap=False, overflow="fold")
    table.add_column("条目数", width=8, justify="right")
    table.add_column("关注者", width=8, justify="right")

    for i, c in enumerate(items, offset + 1):
        table.add_row(
            str(i),
            str(c.get("id", "")),
            c.get("title", "") or "",
            str(c.get("item_count", 0)),
            str(c.get("follower_count", 0)),
        )
    common.console.print(table)


@click.command()
@click.option("--page", "-p", default=0, type=click.IntRange(0), help="页码 (默认 0)。")
@click.option("--limit", "-n", default=10, type=click.IntRange(1), help="显示数量 (默认 10)。")
@common.structured_output_options
def feed(page: int, limit: int, as_json: bool, as_yaml: bool):
    """查看个性化 Feed。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.require_login()

    data = common.run_or_exit(
        client.get_feed(page_number=page, limit=limit, credential=cred),
        "获取 feed 失败",
    )
    items = data.get("data", [])

    if common.emit_structured([payloads.normalize_feed_item(item) for item in items], output_format):
        return

    if not items:
        common.console.print("[yellow]暂无 feed 内容[/yellow]")
        return

    common.console.print("[bold]📰 Feed[/bold]\n")
    for item in items[:limit]:
        target = item.get("target", {})
        author = target.get("author", {})
        title = target.get("title", "")
        excerpt = target.get("excerpt", "")
        name = author.get("name", "")
        voteup = target.get("voteup_count", 0)
        comment = target.get("comment_count", 0)

        if title:
            common.console.print(f"  [bold]{title}[/bold]")
        common.console.print(f"  [cyan]{name}[/cyan]  [dim]👍 {voteup}  💬 {comment}[/dim]")
        if excerpt:
            common.console.print(f"  [dim]{excerpt[:100]}[/dim]")
        common.console.print()
