"""User related commands."""

from __future__ import annotations

import click
from rich.panel import Panel
from rich.table import Table

from .. import payloads
from . import common


@click.command(name="user")
@click.argument("url_token")
@common.structured_output_options
def user_cmd(url_token: str, as_json: bool, as_yaml: bool):
    """查看用户资料。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.get_credential(mode="optional")
    info = common.run_or_exit(client.get_user_info(url_token, credential=cred), "获取用户信息失败")

    payload = common.success_payload({"user": payloads.normalize_user(info)})
    if common.emit_structured(payload, output_format):
        return

    headline = info.get("headline", "").strip()
    description = info.get("description", "").strip()
    avatar_url = info.get("avatar_url", "")

    lines = [
        f"👤 [bold]{info.get('name', '')}[/bold]  ({url_token})",
    ]
    if headline:
        lines.append(f"📝 {headline}")
    if description:
        lines.append(f"📖 {description}")
    if avatar_url:
        lines.append(f"🖼️  {avatar_url}")
    lines.append(
        f"👥 粉丝 {common.format_count(info.get('follower_count', 0))}  |  "
        f"🔔 关注 {common.format_count(info.get('following_count', 0))}"
    )
    lines.append(
        f"💬 回答 {info.get('answer_count', 0)}  |  📰 文章 {info.get('articles_count', 0)}  |  ❓ 提问 {info.get('question_count', 0)}"
    )
    lines.append(
        f"💡 想法 {info.get('pins_count', 0)}  |  📚 专栏 {info.get('columns_count', 0)}  |  ⭐ 收藏 {info.get('favorite_count', 0)}"
    )

    common.console.print(Panel(
        "\n".join(lines),
        title="用户信息",
        border_style="cyan",
    ))


@click.command(name="user-answers")
@click.argument("url_token")
@click.option("--limit", "-n", default=10, type=click.IntRange(1), help="显示数量 (默认 10)。")
@common.structured_output_options
def user_answers(url_token: str, limit: int, as_json: bool, as_yaml: bool):
    """查看用户的回答列表。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.get_credential(mode="optional")
    data = common.run_or_exit(
        client.get_user_answers(url_token, limit=limit, credential=cred),
        "获取用户回答失败",
    )
    items = data.get("data", [])

    if common.emit_structured([payloads.normalize_answer(a) for a in items], output_format):
        return

    if not items:
        common.console.print("[yellow]该用户暂无回答[/yellow]")
        return

    table = Table(title=f"📝 {url_token} 的回答 (共 {len(items)} 个)", border_style="blue")
    table.add_column("#", style="dim", width=4)
    table.add_column("ID", style="cyan", width=10)
    table.add_column("问题", no_wrap=False, overflow="fold")
    table.add_column("赞同", width=8, justify="right")
    table.add_column("评论", width=6, justify="right")

    for i, a in enumerate(items, 1):
        question = a.get("question", {})
        table.add_row(
            str(i),
            str(a.get("id", "")),
            question.get("title", "") or "",
            common.format_count(a.get("voteup_count", 0)),
            str(a.get("comment_count", 0)),
        )
    common.console.print(table)


@click.command(name="user-articles")
@click.argument("url_token")
@click.option("--limit", "-n", default=10, type=click.IntRange(1), help="显示数量 (默认 10)。")
@common.structured_output_options
def user_articles(url_token: str, limit: int, as_json: bool, as_yaml: bool):
    """查看用户的文章列表。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.get_credential(mode="optional")
    data = common.run_or_exit(
        client.get_user_articles(url_token, limit=limit, credential=cred),
        "获取用户文章失败",
    )
    items = data.get("data", [])

    if common.emit_structured([payloads.normalize_article(a) for a in items], output_format):
        return

    if not items:
        common.console.print("[yellow]该用户暂无文章[/yellow]")
        return

    table = Table(title=f"📰 {url_token} 的文章 (共 {len(items)} 篇)", border_style="blue")
    table.add_column("#", style="dim", width=4)
    table.add_column("ID", style="cyan", width=10)
    table.add_column("标题", no_wrap=False, overflow="fold")
    table.add_column("赞同", width=8, justify="right")
    table.add_column("评论", width=6, justify="right")

    for i, a in enumerate(items, 1):
        table.add_row(
            str(i),
            str(a.get("id", "")),
            a.get("title", "") or "",
            common.format_count(a.get("voteup_count", 0)),
            str(a.get("comment_count", 0)),
        )
    common.console.print(table)


@click.command(name="user-pins")
@click.argument("url_token")
@click.option("--limit", "-n", default=10, type=click.IntRange(1), help="显示数量 (默认 10)。")
@common.structured_output_options
def user_pins(url_token: str, limit: int, as_json: bool, as_yaml: bool):
    """查看用户的想法列表。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.get_credential(mode="optional")
    data = common.run_or_exit(
        client.get_user_pins(url_token, limit=limit, credential=cred),
        "获取用户想法失败",
    )
    items = data.get("data", [])

    if common.emit_structured([payloads.normalize_pin(p) for p in items], output_format):
        return

    if not items:
        common.console.print("[yellow]该用户暂无想法[/yellow]")
        return

    table = Table(title=f"💡 {url_token} 的想法 (共 {len(items)} 条)", border_style="blue")
    table.add_column("#", style="dim", width=4)
    table.add_column("ID", style="cyan", width=10)
    table.add_column("内容", no_wrap=False, overflow="fold")
    table.add_column("赞同", width=8, justify="right")
    table.add_column("评论", width=6, justify="right")

    for i, p in enumerate(items, 1):
        import re as _re
        content_parts = p.get("content", [])
        if isinstance(content_parts, list):
            text = " ".join(
                _re.sub(r"<[^>]+>", "", cp.get("content", ""))
                for cp in content_parts
                if cp.get("type") == "text"
            )
        else:
            text = _re.sub(r"<[^>]+>", "", str(content_parts))
        table.add_row(
            str(i),
            str(p.get("id", "")),
            text[:120],
            common.format_count(p.get("like_count", 0)),
            str(p.get("comment_count", 0)),
        )
    common.console.print(table)
