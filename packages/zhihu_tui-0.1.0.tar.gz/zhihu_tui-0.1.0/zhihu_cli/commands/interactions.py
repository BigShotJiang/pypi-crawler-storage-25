"""Interaction commands (vote, follow, unfollow)."""

from __future__ import annotations

import click

from .. import payloads
from . import common


@click.command(name="vote")
@click.argument("content_type", type=click.Choice(["answer", "article", "pin"]))
@click.argument("content_id", type=int)
@click.option("--down", is_flag=True, help="取消赞同。")
@common.structured_output_options
def vote_cmd(content_type: str, content_id: int, down: bool, as_json: bool, as_yaml: bool):
    """赞同回答、文章或想法。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.require_login(require_write=True)

    if content_type == "answer":
        if down:
            common.run_or_exit(client.unlike_answer(content_id, cred), "取消赞同失败")
        else:
            common.run_or_exit(client.like_answer(content_id, cred), "赞同失败")
    elif content_type == "article":
        if down:
            common.exit_error("文章不支持取消赞同", code="invalid_input")
        common.run_or_exit(client.like_article(content_id, cred), "赞同失败")
    elif content_type == "pin":
        if down:
            common.run_or_exit(client.unlike_pin(content_id, cred), "取消赞同失败")
        else:
            common.run_or_exit(client.like_pin(content_id, cred), "赞同失败")

    action_name = "unvote" if down else "vote"
    payload = payloads.action_result(action_name, content_type=content_type, content_id=content_id)

    def render() -> None:
        if down:
            common.console.print(f"[yellow]👎 已取消赞同 {content_type} {content_id}[/yellow]")
        else:
            common.console.print(f"[green]👍 已赞同 {content_type} {content_id}[/green]")

    if common.emit_or_print(payload, output_format, render):
        return


@click.command(name="follow")
@click.argument("target_type", type=click.Choice(["user", "question"]))
@click.argument("target_id")
@common.structured_output_options
def follow_cmd(target_type: str, target_id: str, as_json: bool, as_yaml: bool):
    """关注用户或问题。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.require_login(require_write=True)

    if target_type == "user":
        common.run_or_exit(client.follow_user(target_id, cred), "关注用户失败")
    else:
        common.run_or_exit(client.follow_question(int(target_id), cred), "关注问题失败")

    payload = payloads.action_result("follow", target_type=target_type, target_id=target_id)

    def render() -> None:
        common.console.print(f"[green]✅ 已关注 {target_type}: {target_id}[/green]")

    if common.emit_or_print(payload, output_format, render):
        return


@click.command(name="unfollow")
@click.argument("target_type", type=click.Choice(["user", "question"]))
@click.argument("target_id")
@click.option("--yes", is_flag=True, help="跳过确认。")
@common.structured_output_options
def unfollow_cmd(target_type: str, target_id: str, yes: bool, as_json: bool, as_yaml: bool):
    """取消关注用户或问题。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.require_login(require_write=True)

    if not yes:
        confirmed = click.confirm(f"确认取消关注 {target_type} {target_id} 吗？", default=False)
        if not confirmed:
            common.console.print("[yellow]已取消操作[/yellow]")
            return

    if target_type == "user":
        common.run_or_exit(client.unfollow_user(target_id, cred), "取消关注失败")
    else:
        common.run_or_exit(client.unfollow_question(int(target_id), cred), "取消关注失败")

    payload = payloads.action_result("unfollow", target_type=target_type, target_id=target_id)

    def render() -> None:
        common.console.print(f"[green]✅ 已取消关注 {target_type}: {target_id}[/green]")

    if common.emit_or_print(payload, output_format, render):
        return
