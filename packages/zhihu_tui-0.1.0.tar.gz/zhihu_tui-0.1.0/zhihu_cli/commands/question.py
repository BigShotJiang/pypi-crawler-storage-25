"""Question related command."""

from __future__ import annotations

import re
from typing import Any

import click
from rich.table import Table

from .. import payloads
from ..exceptions import ZhihuError
from . import common


@click.command(name="question")
@click.argument("id_or_url")
@click.option("--limit", "-n", default=10, type=click.IntRange(1), help="回答数量 (默认 10)。")
@common.structured_output_options
def question_cmd(id_or_url: str, limit: int, as_json: bool, as_yaml: bool):
    """查看问题详情。

    ID_OR_URL 可以是问题 ID 或知乎 URL。
    """
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)

    try:
        question_id = client.extract_question_id(id_or_url)
    except ZhihuError as e:
        common.exit_error(f"解析问题 ID 失败: {e}", code="invalid_input")

    cred = common.get_credential(mode="optional")
    info = common.run_or_exit(client.get_question(question_id, credential=cred), "获取问题详情失败")

    answer_items: list[dict] = []
    answer_total: int = 0

    data = common.run_optional(
        client.get_question_answers(question_id, limit=limit, credential=cred),
        "获取回答失败",
    )
    if data is not None:
        answer_items = data.get("data", [])
        answer_total = data.get("paging", {}).get("totals", len(answer_items))

    structured: dict[str, Any] = {
        "question": payloads.normalize_question(info),
    }
    if answer_items:
        structured["answers"] = [payloads.normalize_answer(a) for a in answer_items]
    if common.emit_structured(structured, output_format):
        return

    # Rich output
    table = Table(title=f"❓ {info.get('title', '')}", show_header=False, border_style="blue")
    table.add_column("Field", style="bold cyan", width=12)
    table.add_column("Value", no_wrap=False, overflow="fold")

    table.add_row("ID", str(question_id))
    table.add_row("标题", info.get("title", ""))
    answer_count = info.get("answer_count", 0)
    table.add_row("回答数", str(answer_count) if answer_count else "-")
    follower_count = info.get("follower_count", 0)
    table.add_row("关注数", common.format_count(follower_count) if follower_count else "-")
    table.add_row("链接", f"https://www.zhihu.com/question/{question_id}")

    detail = info.get("detail", "").strip()
    if detail:
        detail_text = re.sub(r"<[^>]+>", "", detail)[:200]
        table.add_row("详情", detail_text)

    common.console.print(table)

    if answer_items:
        common.console.print(f"\n[bold]📝 回答 (共 {answer_total} 个，显示 {len(answer_items)} 个):[/bold]\n")
        atable = Table(border_style="blue")
        atable.add_column("#", style="dim", width=4)
        atable.add_column("ID", style="cyan", width=20)
        atable.add_column("作者", no_wrap=False, overflow="fold")
        atable.add_column("赞同", width=8, justify="right")
        atable.add_column("评论", width=6, justify="right")
        atable.add_column("摘要", no_wrap=False, overflow="fold")

        for i, a in enumerate(answer_items[:limit], 1):
            author = a.get("author", {})
            atable.add_row(
                str(i),
                str(a.get("id", "")),
                author.get("name", ""),
                common.format_count(a.get("voteup_count", 0)),
                str(a.get("comment_count", 0)),
                a.get("excerpt", "") or "",
            )
        common.console.print(atable)
