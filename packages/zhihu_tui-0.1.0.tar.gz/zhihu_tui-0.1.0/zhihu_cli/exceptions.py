"""Custom exceptions for zhihu-cli."""


class ZhihuError(Exception):
    """Base exception for zhihu-cli errors."""


class InvalidIdError(ZhihuError):
    """Raised when a content ID cannot be parsed or is malformed."""


class NetworkError(ZhihuError):
    """Raised when upstream network/API requests fail."""


class AuthenticationError(ZhihuError):
    """Raised when authentication data is missing or invalid."""


class RateLimitError(ZhihuError):
    """Raised when Zhihu rate-limits the request."""


class NotFoundError(ZhihuError):
    """Raised when a question, answer, user, or resource is not found."""
