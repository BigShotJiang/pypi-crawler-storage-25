"""Shared test fixtures."""

import os

import pytest

os.environ.setdefault("OUTPUT", "rich")


@pytest.fixture
def mock_credential():
    """A fake credential for testing."""
    from zhihu_cli.auth import ZhihuCredential
    return ZhihuCredential(z_c0="test_z_c0", _xsrf="test_xsrf", xsrf_token="test_xsrf_token")


@pytest.fixture
def mock_user_info():
    """Sample user info response."""
    return {
        "id": "12345",
        "url_token": "testuser",
        "name": "TestUser",
        "headline": "测试用户",
        "description": "这是描述",
        "avatar_url": "https://pic.zhimg.com/test.jpg",
        "follower_count": 1000,
        "following_count": 200,
        "answer_count": 50,
        "articles_count": 10,
        "question_count": 5,
    }


@pytest.fixture
def mock_question_info():
    """Sample question info response."""
    return {
        "id": 123456,
        "title": "这是一个测试问题？",
        "detail": "<p>问题详情</p>",
        "excerpt": "问题摘要",
        "answer_count": 42,
        "follower_count": 1000,
        "comment_count": 10,
        "author": {"name": "提问者", "url_token": "asker"},
    }


@pytest.fixture
def mock_answer_info():
    """Sample answer info response."""
    return {
        "id": 789,
        "question": {"id": 123456, "title": "这是一个测试问题？"},
        "author": {"name": "回答者", "url_token": "answerer"},
        "content": "<p>回答内容</p>",
        "excerpt": "回答摘要",
        "voteup_count": 500,
        "comment_count": 20,
        "thanks_count": 10,
        "created_time": 1700000000,
        "updated_time": 1700001000,
    }
