"""Tests for CLI commands using Click CliRunner."""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import yaml
from click.testing import CliRunner

from zhihu_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


def _load_yaml(text: str):
    return yaml.safe_load(text)


# ===== Status/Logout =====


def test_status_not_logged_in(runner):
    with patch("zhihu_cli.commands.common.get_credential", return_value=None):
        result = runner.invoke(cli, ["status"])
        assert "未登录" in result.output
        assert result.exit_code != 0


def test_status_logged_in(runner, mock_user_info):
    mock_cred = MagicMock()
    with patch("zhihu_cli.commands.common.get_credential", return_value=mock_cred), \
         patch("zhihu_cli.client.get_self_info", new_callable=AsyncMock, return_value=mock_user_info):
        result = runner.invoke(cli, ["status"])
        assert "TestUser" in result.output
        assert "✅" in result.output


def test_status_yaml_output(runner, mock_user_info):
    mock_cred = MagicMock()
    with patch("zhihu_cli.commands.common.get_credential", return_value=mock_cred), \
         patch("zhihu_cli.client.get_self_info", new_callable=AsyncMock, return_value=mock_user_info):
        result = runner.invoke(cli, ["status", "--yaml"])
        assert result.exit_code == 0
        data = _load_yaml(result.output)
        assert data["ok"] is True
        assert data["data"]["authenticated"] is True
        assert data["data"]["user"]["name"] == "TestUser"


def test_logout(runner):
    with patch("zhihu_cli.commands.common.clear_credential") as mock_clear:
        result = runner.invoke(cli, ["logout"])
        assert "已注销" in result.output
        mock_clear.assert_called_once()


def test_whoami_not_logged_in(runner):
    with patch("zhihu_cli.commands.common.get_credential", return_value=None):
        result = runner.invoke(cli, ["whoami"])
        assert result.exit_code != 0
        assert "未登录" in result.output


def test_whoami_json(runner, mock_user_info):
    mock_cred = MagicMock()
    with patch("zhihu_cli.commands.common.get_credential", return_value=mock_cred), \
         patch("zhihu_cli.client.get_self_info", new_callable=AsyncMock, return_value=mock_user_info):
        result = runner.invoke(cli, ["whoami", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True
        assert data["data"]["user"]["name"] == "TestUser"


# ===== Question =====


def test_question(runner, mock_question_info):
    with patch("zhihu_cli.client.extract_question_id", return_value=123456), \
         patch("zhihu_cli.client.get_question", new_callable=AsyncMock, return_value=mock_question_info):
        result = runner.invoke(cli, ["question", "123456"])
        assert result.exit_code == 0
        assert "测试问题" in result.output


def test_question_yaml(runner, mock_question_info):
    with patch("zhihu_cli.client.extract_question_id", return_value=123456), \
         patch("zhihu_cli.client.get_question", new_callable=AsyncMock, return_value=mock_question_info):
        result = runner.invoke(cli, ["question", "123456", "--yaml"])
        assert result.exit_code == 0
        data = _load_yaml(result.output)
        assert data["ok"] is True
        assert data["data"]["question"]["title"] == "这是一个测试问题？"


# ===== Answer =====


def test_answer(runner, mock_answer_info):
    with patch("zhihu_cli.client.extract_answer_id", return_value=789), \
         patch("zhihu_cli.client.get_answer", new_callable=AsyncMock, return_value=mock_answer_info):
        result = runner.invoke(cli, ["answer", "789"])
        assert result.exit_code == 0
        assert "回答者" in result.output


# ===== Hot =====


def test_hot(runner):
    mock_data = {
        "data": [
            {"target": {"id": 1, "title": "热搜1"}, "detail_text": "100万热度"},
            {"target": {"id": 2, "title": "热搜2"}, "detail_text": "50万热度"},
        ]
    }
    with patch("zhihu_cli.client.get_hot_list", new_callable=AsyncMock, return_value=mock_data):
        result = runner.invoke(cli, ["hot"])
        assert result.exit_code == 0
        assert "热搜1" in result.output


# ===== Search =====


def test_search(runner):
    mock_data = {
        "data": [
            {
                "type": "search_result",
                "object": {
                    "id": 1,
                    "title": "搜索结果1",
                    "author": {"name": "作者"},
                    "voteup_count": 100,
                },
            }
        ]
    }
    with patch("zhihu_cli.client.search", new_callable=AsyncMock, return_value=mock_data):
        result = runner.invoke(cli, ["search", "测试"])
        assert result.exit_code == 0
        assert "搜索结果1" in result.output


# ===== User =====


def test_user(runner, mock_user_info):
    with patch("zhihu_cli.client.get_user_info", new_callable=AsyncMock, return_value=mock_user_info):
        result = runner.invoke(cli, ["user", "testuser"])
        assert result.exit_code == 0
        assert "TestUser" in result.output


# ===== Like =====


def test_like_requires_login(runner):
    with patch("zhihu_cli.commands.common.get_credential", return_value=None):
        result = runner.invoke(cli, ["like", "answer", "123"])
        assert result.exit_code != 0
