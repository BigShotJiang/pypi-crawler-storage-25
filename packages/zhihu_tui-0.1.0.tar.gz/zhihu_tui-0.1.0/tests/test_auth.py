"""Tests for auth module."""

import json
from unittest.mock import AsyncMock, patch

from zhihu_cli.auth import (
    ZhihuCredential,
    _load_saved_credential,
    clear_credential,
    get_credential,
    manual_login,
    save_credential,
)


def test_credential_as_cookie_header():
    cred = ZhihuCredential(z_c0="abc", _xsrf="xyz")
    assert cred.as_cookie_header() == "z_c0=abc; _xsrf=xyz"


def test_credential_as_dict():
    cred = ZhihuCredential(z_c0="abc", xsrf_token="tok", _xsrf="xsrf")
    d = cred.as_dict()
    assert d["z_c0"] == "abc"
    assert d["xsrf_token"] == "tok"
    assert d["_xsrf"] == "xsrf"


def test_save_and_load(tmp_path):
    from zhihu_cli import auth
    cred_file = tmp_path / "cred.json"
    with patch("zhihu_cli.auth.CREDENTIAL_FILE", cred_file), \
         patch("zhihu_cli.auth.CONFIG_DIR", tmp_path):
        cred = ZhihuCredential(z_c0="test_z", _xsrf="test_x")
        save_credential(cred)
        assert cred_file.exists()

        loaded = _load_saved_credential()
        assert loaded is not None
        assert loaded.z_c0 == "test_z"
        assert loaded._xsrf == "test_x"


def test_load_missing_file(tmp_path):
    with patch("zhihu_cli.auth.CREDENTIAL_FILE", tmp_path / "nope.json"):
        assert _load_saved_credential() is None


def test_load_corrupt_file(tmp_path):
    cred_file = tmp_path / "bad.json"
    cred_file.write_text("not json")
    with patch("zhihu_cli.auth.CREDENTIAL_FILE", cred_file):
        assert _load_saved_credential() is None


def test_load_empty_z_c0(tmp_path):
    cred_file = tmp_path / "empty.json"
    cred_file.write_text(json.dumps({"z_c0": "", "_xsrf": "x"}))
    with patch("zhihu_cli.auth.CREDENTIAL_FILE", cred_file):
        assert _load_saved_credential() is None


def test_clear_credential(tmp_path):
    cred_file = tmp_path / "cred.json"
    cred_file.write_text("{}")
    with patch("zhihu_cli.auth.CREDENTIAL_FILE", cred_file):
        clear_credential()
        assert not cred_file.exists()


def test_manual_login(tmp_path):
    cred_file = tmp_path / "cred.json"
    with patch("zhihu_cli.auth.CREDENTIAL_FILE", cred_file), \
         patch("zhihu_cli.auth.CONFIG_DIR", tmp_path):
        cred = manual_login(z_c0="manual_z_c0", _xsrf="manual_xsrf")
        assert cred.z_c0 == "manual_z_c0"
        assert cred_file.exists()


def test_get_credential_optional_with_saved(tmp_path):
    cred_file = tmp_path / "cred.json"
    cred_data = {"z_c0": "saved", "_xsrf": "x", "xsrf_token": "", "saved_at": 0}
    cred_file.write_text(json.dumps(cred_data))
    with patch("zhihu_cli.auth.CREDENTIAL_FILE", cred_file), \
         patch("zhihu_cli.auth._extract_browser_credential", return_value=None):
        cred = get_credential(mode="optional")
        assert cred is not None
        assert cred.z_c0 == "saved"


def test_get_credential_optional_no_file(tmp_path):
    with patch("zhihu_cli.auth.CREDENTIAL_FILE", tmp_path / "nope.json"):
        assert get_credential(mode="optional") is None
