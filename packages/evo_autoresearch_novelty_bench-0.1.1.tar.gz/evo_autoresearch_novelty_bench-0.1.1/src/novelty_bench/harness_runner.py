"""Generic harness adapter: drives the benchmark from any orchestrator.

Useful for any optimizer / harness / CI loop that consumes a per-task score
map. The contract is the common `run(task_ids) -> dict[task_id, score]`
pattern most benchmark harnesses already expect.

    from novelty_bench import NoveltyBenchRunner

    runner = NoveltyBenchRunner(agent="claude-code", split="test")
    results = runner.run()                          # full test split
    results = runner.run(["snap_codex_v3_k0922"])   # subset
    mean    = NoveltyBenchRunner.val_score(results) # aggregate

Tasks are snapshot_ids; scores are set_scores (higher is better). Failed
snapshots are omitted from the dict, so callers can treat missing keys
however they want (skip, penalize, retry).

Shells out to the scaffold's run.py and parses the resulting results.csv.
"""

from __future__ import annotations

import csv
import os
import subprocess
import sys
from pathlib import Path

import novelty_bench as nb


class NoveltyBenchRunner:
    """Adapter so an external harness can drive the benchmark.

    Args:
        agent: built-in adapter name ("claude-code" / "codex"), or None if using agent_cmd
        agent_cmd: shell template with {workspace} placeholder (custom agent)
        split: "test" (default, 24 snapshots) / "dev" (16) / "all" (40)
        scaffold_dir: path to autoresearch-novelty-bench-scaffold checkout
        out_root: where to write results/ subdirs (default: scaffold_dir/results)
        n_candidates: candidate proposals per snapshot (default 5)
        embedding_backend: "openai" (default) or "bge"
        judge_backend: "llm-hybrid" (default, gpt-5-mini reasoning) or "cosine" (deterministic)
        parallel: concurrent agent invocations (default 1)
        timeout_s: per-snapshot agent timeout
        task_prompt: override the agent's task prompt (sweepable knob)
    """

    def __init__(
        self,
        *,
        agent: str | None = "claude-code",
        agent_cmd: str | None = None,
        split: str = "test",
        scaffold_dir: Path | str | None = None,
        out_root: Path | str | None = None,
        n_candidates: int = 5,
        embedding_backend: str = "openai",
        judge_backend: str = "llm-hybrid",
        parallel: int = 1,
        timeout_s: int | None = None,
        task_prompt: str | None = None,
    ):
        if (agent is None) == (agent_cmd is None):
            raise ValueError("Provide exactly one of agent or agent_cmd")
        self.agent = agent
        self.agent_cmd = agent_cmd
        self.split = split
        self.scaffold_dir = Path(scaffold_dir).resolve() if scaffold_dir else _find_scaffold_dir()
        self.out_root = Path(out_root).resolve() if out_root else (self.scaffold_dir / "results")
        self.n_candidates = n_candidates
        self.embedding_backend = embedding_backend
        self.judge_backend = judge_backend
        self.parallel = parallel
        self.timeout_s = timeout_s
        self.task_prompt = task_prompt

    def list_tasks(self) -> list[str]:
        """Return the snapshot_ids in this split (for harness task selection)."""
        snaps = nb.load_snapshots()
        if self.split == "all":
            return sorted(snaps["snapshot_id"].tolist())
        return sorted(snaps[snaps["split"] == self.split]["snapshot_id"].tolist())

    def run(self, task_ids: list[str] | None = None) -> dict[str, float]:
        """Run the agent on the given snapshots, return {snapshot_id: set_score}.

        If task_ids is None, runs the full split. If given, runs only that
        subset. Missing snapshots in the return dict = run failed for that
        snapshot — caller decides how to handle.
        """
        cmd = [
            sys.executable, str(self.scaffold_dir / "run.py"),
            "--out", str(self.out_root.parent),
            "--n-candidates", str(self.n_candidates),
            "--embedding-backend", self.embedding_backend,
            "--parallel", str(self.parallel),
        ]
        cmd += ["--judge-backend", self.judge_backend]
        if self.timeout_s is not None:
            cmd += ["--timeout", str(self.timeout_s)]
        if self.task_prompt is not None:
            cmd += ["--task-prompt", self.task_prompt]
        if self.agent:
            cmd += ["--agent", self.agent]
        else:
            cmd += ["--agent-cmd", self.agent_cmd]
        if task_ids:
            cmd += ["--snapshots", ",".join(task_ids)]
        else:
            cmd += ["--split", self.split]

        prev_runs = set(p.name for p in self.out_root.glob("*")) if self.out_root.exists() else set()
        proc = subprocess.run(cmd, check=False)
        if proc.returncode != 0:
            raise RuntimeError(f"scaffold run.py exited rc={proc.returncode}")
        new_runs = [p for p in self.out_root.glob("*") if p.name not in prev_runs and p.is_dir()]
        if not new_runs:
            raise RuntimeError(f"could not locate new run dir under {self.out_root}")
        run_dir = max(new_runs, key=lambda p: p.stat().st_mtime)

        results: dict[str, float] = {}
        results_csv = run_dir / "results.csv"
        if not results_csv.exists():
            raise RuntimeError(f"results.csv missing in {run_dir}")
        with results_csv.open() as f:
            for row in csv.DictReader(f):
                sid = row["snapshot_id"]
                raw = row.get("set_score", "")
                if raw == "" or raw.lower() == "none":
                    continue
                try:
                    results[sid] = float(raw)
                except ValueError:
                    continue
        return results

    @staticmethod
    def val_score(results: dict[str, float]) -> float:
        """Mean reward across results. Empty input returns 0.0."""
        if not results:
            return 0.0
        return sum(results.values()) / len(results)


def _find_scaffold_dir() -> Path:
    env = os.environ.get("NOVELTY_BENCH_SCAFFOLD_DIR")
    if env:
        return Path(env).expanduser().resolve()
    candidates = [
        Path.cwd() / "autoresearch-novelty-bench-scaffold",
        Path.cwd().parent / "autoresearch-novelty-bench-scaffold",
    ]
    for c in candidates:
        if c.is_dir() and (c / "run.py").exists():
            return c.resolve()
    raise RuntimeError(
        "Couldn't locate autoresearch-novelty-bench-scaffold. Set "
        "NOVELTY_BENCH_SCAFFOLD_DIR or pass scaffold_dir=<path> to NoveltyBenchRunner."
    )
