"""novelty-bench: a benchmark for measuring novelty in AI research agent proposals.

Public API (the only stable surface):

  load_ideas, load_runs, load_val_trajectories, load_snapshots,
  load_mechanism_extractions, load_idea_embeddings, load_calibration_cases
      Read each parquet table as a pandas DataFrame. Equality filters as kwargs.

  build_state(snapshot_id)
      Construct the agent-visible workspace state for a snapshot.
      (Lands alongside the snapshots table — not yet implemented.)

  score(proposal, snapshot)
      Run the judge pipeline on a proposal. Returns a Result.
      (Lands alongside the judge — not yet implemented.)

Everything else is internal.
"""

from .access import (
    load_calibration_cases,
    load_current_recipe,
    load_experiments,
    load_ideas,
    load_idea_embeddings,
    load_mechanism_extractions,
    load_proposal_embeddings,
    load_proposals,
    load_runs,
    load_snapshots,
    load_val_trajectories,
)
from .judge import (
    ProposalClassification,
    ProposedCandidate,
    ScoringResult,
    parse_proposal_file,
    score,
)
from .harness_runner import NoveltyBenchRunner

__version__ = "0.1.1"

__all__ = [
    "NoveltyBenchRunner",
    "ProposalClassification",
    "ProposedCandidate",
    "ScoringResult",
    "load_calibration_cases",
    "load_current_recipe",
    "load_experiments",
    "load_idea_embeddings",
    "load_ideas",
    "load_mechanism_extractions",
    "load_proposal_embeddings",
    "load_proposals",
    "load_runs",
    "load_snapshots",
    "load_val_trajectories",
    "parse_proposal_file",
    "score",
]
