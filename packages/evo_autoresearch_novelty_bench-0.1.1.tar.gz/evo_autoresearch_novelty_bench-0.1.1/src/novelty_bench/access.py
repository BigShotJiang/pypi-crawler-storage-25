"""Dataset access functions: thin wrappers over parquet reads.

Each load_* function returns a pandas DataFrame matching the schema of the
underlying parquet file. Kwargs become equality filters on the matching column.

Resolution order for each table:
1. If `data_root=` is passed explicitly, use it.
2. Else if `NOVELTY_BENCH_DATA_ROOT` env var is set, use it.
3. Else if `./data/out/<file>` exists in the cwd (dev mode), use it.
4. Else auto-download from Hugging Face (`evo-hq/autoresearch-novelty-bench`)
   into the HF cache (`~/.cache/huggingface/hub/`).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pandas as pd


_HF_REPO_ID = "evo-hq/autoresearch-novelty-bench"


def _default_data_root() -> Path | None:
    """Return the user's explicit data root, or None if HF download should be used.

    Env var wins over the dev-mode `./data/out/` directory; both fall through
    to HF auto-download if missing.
    """
    env = os.environ.get("NOVELTY_BENCH_DATA_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    dev = Path("data/out").resolve()
    if dev.exists():
        return dev
    return None


def _resolve_path(root: Path | None, relative: str) -> Path:
    """Return a local Path for `relative`, downloading from HF if missing.

    `root` is the data directory (explicit or env-derived); pass None to skip
    the local lookup and go straight to HF. Falls through to
    `huggingface_hub.hf_hub_download`, which caches under ~/.cache/huggingface.
    """
    if root is not None:
        local = root / relative
        if local.exists():
            return local

    try:
        from huggingface_hub import hf_hub_download
    except ImportError as e:
        raise FileNotFoundError(
            f"{relative} not available locally and `huggingface_hub` is not installed. "
            f"Install it to enable auto-download: pip install huggingface_hub"
        ) from e

    try:
        return Path(hf_hub_download(_HF_REPO_ID, filename=relative, repo_type="dataset"))
    except Exception as e:
        raise FileNotFoundError(
            f"could not locate {relative} (tried local roots and HF repo {_HF_REPO_ID}): {e}"
        ) from e


def _read_parquet_with_filters(
    root: Path | None, relative: str, table_name: str, filters: dict[str, Any]
) -> pd.DataFrame:
    """Read a parquet file, apply equality filters on columns, return a DataFrame.

    Empty filters (`None` values) are ignored. Filters whose column doesn't exist
    in the table raise KeyError with a list of available columns.
    """
    path = _resolve_path(root, relative)
    df = pd.read_parquet(path)
    for col, value in filters.items():
        if value is None:
            continue
        if col not in df.columns:
            raise KeyError(
                f"unknown filter column {col!r} for {table_name}. "
                f"available columns: {sorted(df.columns)}"
            )
        df = df[df[col] == value]
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Public loaders
# ---------------------------------------------------------------------------


def load_ideas(
    *,
    agent: str | None = None,
    wave: str | None = None,
    verdict: str | None = None,
    on_frontier_walk: bool | None = None,
    rejection_class: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load the ideas table.

    Filters apply as equality matches on the matching columns. Pass `None` (the
    default) to skip a filter.
    """
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "ideas.parquet",
        "ideas",
        {
            "agent": agent,
            "wave": wave,
            "verdict": verdict,
            "on_frontier_walk": on_frontier_walk,
            "rejection_class": rejection_class,
        },
    )


def load_runs(
    *,
    agent: str | None = None,
    wave: str | None = None,
    idea_id: str | None = None,
    hit_target: bool | None = None,
    status: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load the runs table."""
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "runs.parquet",
        "runs",
        {
            "agent": agent,
            "wave": wave,
            "idea_id": idea_id,
            "hit_target": hit_target,
            "status": status,
        },
    )


def load_val_trajectories(
    *,
    run_id: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load validation checkpoint trajectories.

    Without `run_id`, this returns ~370k rows — useful for global analysis but
    expensive to materialize. Prefer filtering by run_id when possible.
    """
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "val_trajectories.parquet",
        "val_trajectories",
        {"run_id": run_id},
    )


def load_experiments(
    *,
    agent: str | None = None,
    wave: str | None = None,
    verdict: str | None = None,
    description_source: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load the experiments catalog (one row per training run).

    This is the benchmark's primary catalog: every research attempt the agents
    made, with description text and timestamp. Snapshots are pivoted on this
    table; the judge looks up priors and future improvements from it.

    Filter by ``description_source`` to inspect rows by provenance:
    "idea_writeup", "variant_docstring", "run_id_only", "llm_generated".
    """
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "experiments.parquet",
        "experiments",
        {
            "agent": agent,
            "wave": wave,
            "verdict": verdict,
            "description_source": description_source,
        },
    )


def load_proposals(
    *,
    agent: str | None = None,
    wave: str | None = None,
    proposal_type: str | None = None,
    verdict: str | None = None,
    parent_idea_id: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load the proposal catalog (one row per variant.py).

    Proposals are the unit the judge scores: each variant.py the agent generated
    is one row, including HP sweep cells and seed reps that were never written
    up as formal ideas. Use ``proposal_type`` to filter to formal_idea, baseline,
    or variant_only.
    """
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "proposals.parquet",
        "proposals",
        {
            "agent": agent,
            "wave": wave,
            "proposal_type": proposal_type,
            "verdict": verdict,
            "parent_idea_id": parent_idea_id,
        },
    )


def load_snapshots(
    *,
    split: str | None = None,
    agent: str | None = None,
    wave: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load the snapshots table."""
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "snapshots.parquet",
        "snapshots",
        {"split": split, "agent": agent, "wave": wave},
    )


def load_mechanism_extractions(
    *,
    idea_id: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load cached mechanism-extraction tuples (one per idea).

    These are pre-computed via an LLM extractor at dataset-build time so users
    never re-compute them. Not yet emitted; raises FileNotFoundError until the
    extractor module is wired in.
    """
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "mechanism_extractions.parquet",
        "mechanism_extractions",
        {"idea_id": idea_id},
    )


def load_idea_embeddings(
    *,
    idea_id: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load pre-computed BGE-large embeddings for dataset ideas.

    Returns a DataFrame with one row per idea and an `embedding` column holding
    a 1024-dim numpy array. Computed once at dataset-build time over the cached
    mechanism summaries. Not yet emitted; raises FileNotFoundError until then.
    """
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "idea_embeddings.parquet",
        "idea_embeddings",
        {"idea_id": idea_id},
    )


def load_current_recipe(
    snapshot_id: str,
    *,
    data_root: Path | str | None = None,
) -> str | None:
    """Return the variant.py source for a snapshot's current_recipe, or None.

    The current_recipe is the most-recent improver at the snapshot's wall_clock
    — what the agent's working code would look like if they had been the
    original team. Shipped per-snapshot at data_root/current_recipes/<id>.py.

    Returns None if the snapshot has no current_recipe at wall_clock (early
    snapshots) OR the variant source couldn't be resolved at dataset-build
    time (rare; ~5 of 40 snapshots).
    """
    root = Path(data_root) if data_root else _default_data_root()
    try:
        path = _resolve_path(root, f"current_recipes/{snapshot_id}.py")
    except FileNotFoundError:
        return None
    return path.read_text(encoding="utf-8")


def load_proposal_embeddings(
    *,
    backend: str = "openai",
    proposal_id: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load pre-computed proposal embeddings.

    ``backend`` selects which embedding model's table to load:
      - ``"openai"`` → text-embedding-3-large, 3072-dim
      - ``"bge"``    → BAAI/bge-large-en-v1.5, 1024-dim

    The two live in incompatible vector spaces; the judge uses one consistently
    per scoring run.
    """
    if backend not in ("openai", "bge"):
        raise ValueError(f"unknown embedding backend {backend!r}; use 'openai' or 'bge'")
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        f"proposal_embeddings_{backend}.parquet",
        f"proposal_embeddings_{backend}",
        {"proposal_id": proposal_id},
    )


def load_calibration_cases(
    *,
    expected_status: str | None = None,
    data_root: Path | str | None = None,
) -> pd.DataFrame:
    """Load the judge validation set (hand-labeled cases).

    Used to verify the judge's automated labels agree with human judgment. Not
    yet emitted; raises FileNotFoundError until the calibration set is built.
    """
    root = Path(data_root) if data_root else _default_data_root()
    return _read_parquet_with_filters(
        root,
        "calibration_cases.parquet",
        "calibration_cases",
        {"expected_status": expected_status},
    )
