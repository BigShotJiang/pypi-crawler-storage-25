"""nb.score(snapshot, proposals) — additive N-set scoring against a snapshot.

The math:

  set_score = sum(per_proposal_scores)
              + diversity_weight * mean_pairwise_cosine_distance
              + validity_weight  * fraction_valid

Per-proposal classification:
  - invalid           (-1.0): structural issues with the .md (missing Proposal
                              section, no title, empty body)
  - rediscovery       (-0.5): cosine to a prior_proposal_id > rediscovery_threshold
  - novel_unvalidated (+0.3): no prior match AND no future match — the
                              proposer hypothesized something the original
                              agents never tried
  - novel_validated   (variable): no prior match; matches a future proposal that
                                  the original agent actually ran
                                  score = 1.0 * impact_multiplier where
                                  impact_multiplier ∈ {1.0 frontier, 0.6 improved,
                                  0.3 neutral, 0.1 regressed}

The rediscovery_threshold (default 0.85) needs calibration against hand-labeled
pairs (task #28) — the v0 number is a reasonable starting point given the
[0.58, 0.82] cross-idea distribution we measured.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd

from .. import access
from ..embeddings import bge_backend, openai_backend
from .models import (
    PerProposalScore,
    ProposalClassification,
    ProposedCandidate,
    ScoringResult,
)

DEFAULT_REDISCOVERY_THRESHOLD = 0.75  # tuned via calibration sweep (87% accuracy, best F1)
DEFAULT_JUDGE_BACKEND = "llm-hybrid"  # gpt-5-mini reasoning; falls back to cosine on LLM error
                                      # opt out with judge_backend="cosine" for deterministic runs
DEFAULT_LLM_TOP_K = 20  # how many nearest priors/futures to pass to the LLM

# Rediscovery score multipliers by the matched prior's rejection_class.
# A candidate that resembles a rejected prior is graded more harshly — the
# agent should have learned from the failure. `none` keeps the base score.
REJECTION_MULTIPLIER = {
    "none": 1.0,                 # not rejected → base -0.5
    "failed": 1.4,               # ran but errored
    "family_ruled_out": 1.6,     # stuck-detector killed the family
    "audit_noncompliant": 1.6,   # broke the wave's rules
    "existence_killed": 2.0,     # was itself a rediscovery — doubly stale
}
DEFAULT_DIVERSITY_WEIGHT = 0.5
DEFAULT_VALIDITY_WEIGHT = 0.1

INVALID_SCORE = -1.0
REDISCOVERY_SCORE = -0.5
NOVEL_UNVALIDATED_SCORE = 0.3

IMPACT_MULTIPLIER = {
    "frontier_idea": 1.0,
    "improved_idea": 0.6,
    "improved_experiment": 0.4,
    "frontier_experiment": 0.5,
}


# ---------------------------------------------------------------------------
# Parsing proposed .md files
# ---------------------------------------------------------------------------

_TITLE_RE = re.compile(r"^\s*#\s+(.+?)\s*$", re.MULTILINE)
_SECTION_RE = re.compile(r"^\s*##\s+(.+?)\s*$", re.MULTILINE)


def parse_proposal_file(path: str | Path) -> ProposedCandidate:
    """Parse one proposer-written .md file into a ProposedCandidate."""
    p = Path(path)
    text = p.read_text(encoding="utf-8", errors="replace")
    return _parse_text(text, source_path=str(p))


def _parse_text(text: str, source_path: str | None = None) -> ProposedCandidate:
    title_match = _TITLE_RE.search(text)
    title = title_match.group(1).strip() if title_match else ""

    # Split into ## sections
    sections: dict[str, str] = {}
    section_iter = list(_SECTION_RE.finditer(text))
    for i, m in enumerate(section_iter):
        start = m.end()
        end = section_iter[i + 1].start() if i + 1 < len(section_iter) else len(text)
        key = _normalize_section_name(m.group(1))
        sections[key] = text[start:end].strip()

    proposal_text = sections.get("proposal", "")
    return ProposedCandidate(
        source_path=source_path,
        title=title,
        proposal_text=proposal_text,
        raw_text=text,
        sections=sections,
    )


def _normalize_section_name(s: str) -> str:
    return s.strip().lower().replace(" ", "_")


# ---------------------------------------------------------------------------
# Public entrypoint
# ---------------------------------------------------------------------------


def score(
    snapshot,
    proposals: Sequence[str | Path | ProposedCandidate],
    *,
    embedding_backend: str = "openai",
    judge_backend: str = DEFAULT_JUDGE_BACKEND,
    rediscovery_threshold: float = DEFAULT_REDISCOVERY_THRESHOLD,
    diversity_weight: float = DEFAULT_DIVERSITY_WEIGHT,
    validity_weight: float = DEFAULT_VALIDITY_WEIGHT,
    data_root: str | Path | None = None,
    llm_model: str | None = None,
    llm_top_k: int = DEFAULT_LLM_TOP_K,
) -> ScoringResult:
    """Score N proposed candidates against a snapshot.

    Args:
        snapshot: one row from nb.load_snapshots() — pandas Series or dict.
        proposals: list of .md paths (parsed lazily) or pre-parsed ProposedCandidate.
        embedding_backend: "openai" (default) or "bge".
        rediscovery_threshold: cosine cutoff above which a candidate counts as
            rediscovery of a prior proposal. Default 0.85.
        diversity_weight / validity_weight: aggregate-term weights.
        data_root: override NOVELTY_BENCH_DATA_ROOT for parquet lookups.

    Returns:
        ScoringResult with per-candidate breakdown.
    """
    if hasattr(snapshot, "to_dict"):
        snap = snapshot.to_dict()
    elif isinstance(snapshot, dict):
        snap = snapshot
    else:
        raise TypeError(f"snapshot must be a pd.Series or dict, got {type(snapshot)}")

    candidates = [_to_candidate(p) for p in proposals]
    n = len(candidates)

    embeddings_df = _load_experiment_embeddings(embedding_backend, data_root)
    experiments_df = access.load_experiments(data_root=data_root)

    # Embed the new candidates
    cand_texts = [_candidate_text_source(c) for c in candidates]
    cand_emb = _embed_candidates(cand_texts, backend=embedding_backend)

    # Build lookup tables for prior / future embeddings (experiment-level)
    prior_ids = _safe_list(snap.get("prior_experiment_ids"))
    future_frontier_ids = _safe_list(snap.get("future_frontier_experiment_ids"))
    future_improved_ids = _safe_list(snap.get("future_improved_experiment_ids"))
    future_frontier_idea_ids = set(_safe_list(snap.get("future_frontier_idea_ids")))
    future_improved_idea_ids = set(_safe_list(snap.get("future_improved_idea_ids")))

    prior_matrix, prior_id_order = _embedding_matrix(embeddings_df, prior_ids,
                                                     id_col="experiment_id")
    future_pool = sorted(set(future_frontier_ids) | set(future_improved_ids))
    future_matrix, future_id_order = _embedding_matrix(embeddings_df, future_pool,
                                                       id_col="experiment_id")

    # linked_idea_id lookup for matched experiments → idea-level pools
    exp_to_parent = dict(zip(experiments_df["experiment_id"], experiments_df["linked_idea_id"]))

    # rejection_class lookup so the rediscovery branch can scale penalty
    ideas_df = access.load_ideas(data_root=data_root)
    idea_to_rejection = dict(zip(ideas_df["idea_id"], ideas_df["rejection_class"]))

    # When llm-hybrid: pre-load descriptions for the experiments we may show the LLM
    exp_descriptions: dict[str, str] = {}
    if judge_backend == "llm-hybrid":
        all_pool_ids = set(prior_id_order) | set(future_id_order)
        if all_pool_ids:
            pool_exps = experiments_df[experiments_df["experiment_id"].isin(all_pool_ids)]
            exp_descriptions = dict(zip(
                pool_exps["experiment_id"], pool_exps["description_text"].fillna("")
            ))

    per_proposal: list[PerProposalScore] = []
    for i, cand in enumerate(candidates):
        valid, invalid_reason = _validity_check(cand)
        if not valid:
            per_proposal.append(PerProposalScore(
                candidate_idx=i, title=cand.title or "(no title)",
                classification=ProposalClassification.INVALID,
                score=INVALID_SCORE, invalid_reason=invalid_reason,
            ))
            continue

        cand_vec = cand_emb[i]

        # Compute both matches up front
        nearest_prior_id, nearest_prior_sim = _nearest(cand_vec, prior_matrix, prior_id_order)
        matched_future_id, matched_future_sim = _nearest(cand_vec, future_matrix, future_id_order)

        # LLM-hybrid path: use reasoning model on top-K instead of cosine threshold
        if judge_backend == "llm-hybrid":
            per_proposal.append(_classify_via_llm(
                i, cand, cand_vec,
                prior_matrix, prior_id_order, future_matrix, future_id_order,
                exp_descriptions, future_frontier_ids, future_improved_ids,
                future_frontier_idea_ids, future_improved_idea_ids,
                exp_to_parent, idea_to_rejection,
                top_k=llm_top_k, llm_model=llm_model,
                nearest_prior_id=nearest_prior_id, nearest_prior_sim=nearest_prior_sim,
            ))
            continue

        # Priority order:
        #  1. Future match (anticipation) — wins even if prior is also close, because
        #     the future is "what ended up working"; matching it means the proposer
        #     identified a winning thread, not rediscovered a stale prior.
        #  2. Prior match (rediscovery) — only if no future match
        #  3. Novel unvalidated — neither match
        future_matched = (
            matched_future_id is not None and matched_future_sim >= rediscovery_threshold
        )
        prior_matched = (
            nearest_prior_sim is not None and nearest_prior_sim >= rediscovery_threshold
        )

        if future_matched:
            matched_parent = exp_to_parent.get(matched_future_id)
            pool, multiplier = _classify_future_match(
                matched_future_id, matched_parent,
                future_frontier_ids, future_improved_ids,
                future_frontier_idea_ids, future_improved_idea_ids,
            )
            per_proposal.append(PerProposalScore(
                candidate_idx=i, title=cand.title,
                classification=ProposalClassification.NOVEL_VALIDATED,
                score=multiplier,
                nearest_prior_id=nearest_prior_id,
                nearest_prior_similarity=float(nearest_prior_sim) if nearest_prior_sim is not None else None,
                matched_future_id=matched_future_id,
                matched_future_pool=pool,
                impact_multiplier=multiplier,
            ))
        elif prior_matched:
            # Scale penalty by the matched prior's rejection class —
            # rediscovering a known failure is worse than rediscovering an
            # inconclusive prior.
            matched_parent_idea = exp_to_parent.get(nearest_prior_id)
            rejection_class = (
                idea_to_rejection.get(matched_parent_idea, "none")
                if matched_parent_idea is not None else "none"
            )
            multiplier = REJECTION_MULTIPLIER.get(rejection_class, 1.0)
            per_proposal.append(PerProposalScore(
                candidate_idx=i, title=cand.title,
                classification=ProposalClassification.REDISCOVERY,
                score=REDISCOVERY_SCORE * multiplier,
                nearest_prior_id=nearest_prior_id,
                nearest_prior_similarity=float(nearest_prior_sim),
                matched_prior_rejection_class=rejection_class,
                rejection_multiplier=multiplier,
            ))
        else:
            per_proposal.append(PerProposalScore(
                candidate_idx=i, title=cand.title,
                classification=ProposalClassification.NOVEL_UNVALIDATED,
                score=NOVEL_UNVALIDATED_SCORE,
                nearest_prior_id=nearest_prior_id,
                nearest_prior_similarity=float(nearest_prior_sim) if nearest_prior_sim is not None else None,
            ))

    # Aggregate terms
    sum_per_proposal = sum(p.score for p in per_proposal)
    diversity = _mean_pairwise_distance(cand_emb)
    validity_frac = sum(1 for p in per_proposal if p.classification != ProposalClassification.INVALID) / n
    set_score = sum_per_proposal + diversity_weight * diversity + validity_weight * validity_frac

    return ScoringResult(
        snapshot_id=snap["snapshot_id"],
        n_candidates=n,
        set_score=float(set_score),
        sum_per_proposal=float(sum_per_proposal),
        diversity_bonus=float(diversity),
        validity_term=float(validity_frac),
        per_proposal=per_proposal,
        embedding_backend=embedding_backend,
        diversity_weight=diversity_weight,
        validity_weight=validity_weight,
        rediscovery_threshold=rediscovery_threshold,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_list(v) -> list:
    """Coerce snapshot list fields to a plain Python list.

    Parquet round-trips list[str] columns as numpy arrays; `or []` and
    truthiness don't work on those.
    """
    if v is None:
        return []
    if hasattr(v, "tolist"):
        return list(v.tolist())
    return list(v)


def _to_candidate(p) -> ProposedCandidate:
    if isinstance(p, ProposedCandidate):
        return p
    return parse_proposal_file(p)


def _candidate_text_source(c: ProposedCandidate) -> str:
    """Build the text we'll embed for a new candidate.

    Matches dataset-side semantics in embeddings/text_source.py: title + the
    full markdown body (minus the H1 title line, which would be duplicated).
    Truncate to MAX_PROPOSAL_TEXT_CHARS to match the dataset's truncation.

    We avoid using just `c.proposal_text` (the ## Proposal section content)
    because most idea writeups have multiple H2 subsections that terminate the
    Proposal section early — the parser would give us only the first few
    sentences, not the full mechanism description.
    """
    from ..embeddings.text_source import MAX_PROPOSAL_TEXT_CHARS

    # Strip H1 lines from raw_text so the title doesn't appear twice
    lines = [ln for ln in c.raw_text.splitlines() if not ln.lstrip().startswith("# ")]
    body = "\n".join(lines).strip()[:MAX_PROPOSAL_TEXT_CHARS]
    return f"{c.title}\n\n{body}".strip()


def _embed_candidates(texts: list[str], *, backend: str) -> np.ndarray:
    if backend == "openai":
        emb, _ = openai_backend.embed_texts(texts, show_progress=False)
    elif backend == "bge":
        emb = bge_backend.embed_texts(texts, show_progress=False)
    else:
        raise ValueError(f"unknown backend {backend!r}")
    return emb


def _embedding_matrix(
    embeddings_df: pd.DataFrame, ids: list[str], *, id_col: str = "experiment_id"
) -> tuple[np.ndarray, list[str]]:
    """Stack embeddings for the given ids into a (K, D) ndarray."""
    if not ids:
        return np.zeros((0, 0), dtype=np.float32), []
    sub = embeddings_df[embeddings_df[id_col].isin(ids)]
    if sub.empty:
        return np.zeros((0, 0), dtype=np.float32), []
    matrix = np.stack(sub["embedding"].tolist()).astype(np.float32)
    return matrix, sub[id_col].tolist()


def _load_experiment_embeddings(backend: str, data_root):
    """Load experiment_embeddings_{backend}.parquet directly (no public access fn yet)."""
    from pathlib import Path
    import os
    root = Path(data_root) if data_root else Path(os.environ.get("NOVELTY_BENCH_DATA_ROOT", "data/out"))
    path = root / f"experiment_embeddings_{backend}.parquet"
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run: "
            f"python -m novelty_bench.embeddings --table experiments --backend {backend}"
        )
    return pd.read_parquet(path)


def _nearest(
    vec: np.ndarray, matrix: np.ndarray, id_order: list[str]
) -> tuple[str | None, float | None]:
    """Nearest-neighbor cosine similarity. Assumes both vec and matrix are
    L2-normalized (which OpenAI and BGE backends both produce)."""
    if matrix.size == 0:
        return None, None
    sims = matrix @ vec
    best = int(np.argmax(sims))
    return id_order[best], float(sims[best])


def _top_k(
    vec: np.ndarray, matrix: np.ndarray, id_order: list[str], k: int
) -> list[tuple[str, float]]:
    """Top-K nearest by cosine. Returns [(id, similarity), ...] sorted desc."""
    if matrix.size == 0:
        return []
    sims = matrix @ vec
    k = min(k, len(sims))
    idx = np.argpartition(-sims, k - 1)[:k]
    idx = idx[np.argsort(-sims[idx])]
    return [(id_order[int(i)], float(sims[int(i)])) for i in idx]


def _classify_via_llm(
    candidate_idx: int,
    cand: ProposedCandidate,
    cand_vec: np.ndarray,
    prior_matrix: np.ndarray, prior_id_order: list[str],
    future_matrix: np.ndarray, future_id_order: list[str],
    exp_descriptions: dict[str, str],
    future_frontier_ids: list[str], future_improved_ids: list[str],
    future_frontier_idea_ids: set[str], future_improved_idea_ids: set[str],
    exp_to_parent: dict, idea_to_rejection: dict,
    *, top_k: int, llm_model: str | None,
    nearest_prior_id: str | None, nearest_prior_sim: float | None,
) -> PerProposalScore:
    """Build top-K prior + future pools, ask the reasoning LLM to classify."""
    from .llm_judge import classify_with_llm, DEFAULT_MODEL

    top_priors = [
        {"experiment_id": eid, "similarity": sim,
         "description_text": exp_descriptions.get(eid, "")}
        for eid, sim in _top_k(cand_vec, prior_matrix, prior_id_order, top_k)
    ]
    top_futures = [
        {"experiment_id": eid, "similarity": sim,
         "description_text": exp_descriptions.get(eid, "")}
        for eid, sim in _top_k(cand_vec, future_matrix, future_id_order, top_k)
    ]

    body = cand.proposal_text[:2000] if cand.proposal_text else cand.raw_text[:2000]
    result = classify_with_llm(
        candidate_title=cand.title,
        candidate_body=body,
        top_priors=top_priors, top_futures=top_futures,
        model=llm_model or DEFAULT_MODEL,
    )

    # LLM error / unknown → fall back to cosine classification
    if result["classification"] == "error":
        return _cosine_fallback(
            candidate_idx, cand, nearest_prior_id, nearest_prior_sim,
            future_matrix, future_id_order, cand_vec, exp_to_parent,
            future_frontier_ids, future_improved_ids,
            future_frontier_idea_ids, future_improved_idea_ids,
            idea_to_rejection,
            llm_reasoning=result.get("reasoning"),
        )

    cls = result["classification"]
    matched_id = result.get("matched_id")
    confidence = result.get("match_confidence", 0.0)
    reasoning = result.get("reasoning", "")

    # Expected-value scoring: scale every LLM-derived classification by the
    # model's reported confidence (P(class | candidate)). Cosine-only path
    # (and the structural invalid check) don't use confidence.
    if cls == "novel_validated" and matched_id:
        matched_parent = exp_to_parent.get(matched_id)
        pool, multiplier = _classify_future_match(
            matched_id, matched_parent,
            future_frontier_ids, future_improved_ids,
            future_frontier_idea_ids, future_improved_idea_ids,
        )
        return PerProposalScore(
            candidate_idx=candidate_idx, title=cand.title,
            classification=ProposalClassification.NOVEL_VALIDATED,
            score=multiplier * confidence, impact_multiplier=multiplier,
            matched_future_id=matched_id, matched_future_pool=pool,
            nearest_prior_id=nearest_prior_id,
            nearest_prior_similarity=nearest_prior_sim,
            llm_reasoning=reasoning, llm_match_confidence=confidence,
            llm_model=result.get("_model"),
        )

    if cls == "rediscovery" and matched_id:
        matched_parent_idea = exp_to_parent.get(matched_id)
        rejection_class = (
            idea_to_rejection.get(matched_parent_idea, "none")
            if matched_parent_idea is not None else "none"
        )
        multiplier = REJECTION_MULTIPLIER.get(rejection_class, 1.0)
        return PerProposalScore(
            candidate_idx=candidate_idx, title=cand.title,
            classification=ProposalClassification.REDISCOVERY,
            score=REDISCOVERY_SCORE * multiplier * confidence,
            nearest_prior_id=matched_id,
            nearest_prior_similarity=nearest_prior_sim,
            matched_prior_rejection_class=rejection_class,
            rejection_multiplier=multiplier,
            llm_reasoning=reasoning, llm_match_confidence=confidence,
            llm_model=result.get("_model"),
        )

    # novel_unvalidated: the "no match" default; also scaled by confidence so
    # low-confidence "I'm not sure there's no match" cases get less of the
    # baseline exploration credit.
    return PerProposalScore(
        candidate_idx=candidate_idx, title=cand.title,
        classification=ProposalClassification.NOVEL_UNVALIDATED,
        score=NOVEL_UNVALIDATED_SCORE * confidence,
        nearest_prior_id=nearest_prior_id,
        nearest_prior_similarity=nearest_prior_sim,
        llm_reasoning=reasoning, llm_match_confidence=confidence,
        llm_model=result.get("_model"),
    )


def _cosine_fallback(
    candidate_idx, cand, nearest_prior_id, nearest_prior_sim,
    future_matrix, future_id_order, cand_vec, exp_to_parent,
    future_frontier_ids, future_improved_ids,
    future_frontier_idea_ids, future_improved_idea_ids,
    idea_to_rejection,
    *, llm_reasoning: str | None = None,
) -> PerProposalScore:
    """If the LLM call fails, fall back to the cosine-threshold classifier."""
    matched_future_id, matched_future_sim = _nearest(cand_vec, future_matrix, future_id_order)
    future_matched = (matched_future_id is not None and matched_future_sim >= DEFAULT_REDISCOVERY_THRESHOLD)
    prior_matched = (nearest_prior_sim is not None and nearest_prior_sim >= DEFAULT_REDISCOVERY_THRESHOLD)
    if future_matched:
        matched_parent = exp_to_parent.get(matched_future_id)
        pool, multiplier = _classify_future_match(
            matched_future_id, matched_parent,
            future_frontier_ids, future_improved_ids,
            future_frontier_idea_ids, future_improved_idea_ids,
        )
        return PerProposalScore(
            candidate_idx=candidate_idx, title=cand.title,
            classification=ProposalClassification.NOVEL_VALIDATED,
            score=multiplier, impact_multiplier=multiplier,
            matched_future_id=matched_future_id, matched_future_pool=pool,
            nearest_prior_id=nearest_prior_id,
            nearest_prior_similarity=nearest_prior_sim,
            llm_reasoning=f"[cosine fallback: {llm_reasoning}]" if llm_reasoning else None,
        )
    if prior_matched:
        matched_parent_idea = exp_to_parent.get(nearest_prior_id)
        rejection_class = (
            idea_to_rejection.get(matched_parent_idea, "none")
            if matched_parent_idea is not None else "none"
        )
        multiplier = REJECTION_MULTIPLIER.get(rejection_class, 1.0)
        return PerProposalScore(
            candidate_idx=candidate_idx, title=cand.title,
            classification=ProposalClassification.REDISCOVERY,
            score=REDISCOVERY_SCORE * multiplier,
            nearest_prior_id=nearest_prior_id,
            nearest_prior_similarity=nearest_prior_sim,
            matched_prior_rejection_class=rejection_class,
            rejection_multiplier=multiplier,
            llm_reasoning=f"[cosine fallback: {llm_reasoning}]" if llm_reasoning else None,
        )
    return PerProposalScore(
        candidate_idx=candidate_idx, title=cand.title,
        classification=ProposalClassification.NOVEL_UNVALIDATED,
        score=NOVEL_UNVALIDATED_SCORE,
        nearest_prior_id=nearest_prior_id,
        nearest_prior_similarity=nearest_prior_sim,
        llm_reasoning=f"[cosine fallback: {llm_reasoning}]" if llm_reasoning else None,
    )


def _classify_future_match(
    matched_experiment_id: str,
    matched_parent_idea_id: str | None,
    future_frontier_ids: list[str],
    future_improved_ids: list[str],
    future_frontier_idea_ids: set[str],
    future_improved_idea_ids: set[str],
) -> tuple[str, float]:
    """Pick the strongest impact pool the matched future experiment lands in."""
    if matched_parent_idea_id and matched_parent_idea_id in future_frontier_idea_ids:
        return "frontier_idea", IMPACT_MULTIPLIER["frontier_idea"]
    if matched_parent_idea_id and matched_parent_idea_id in future_improved_idea_ids:
        return "improved_idea", IMPACT_MULTIPLIER["improved_idea"]
    if matched_experiment_id in future_frontier_ids:
        return "frontier_experiment", IMPACT_MULTIPLIER["frontier_experiment"]
    if matched_experiment_id in future_improved_ids:
        return "improved_experiment", IMPACT_MULTIPLIER["improved_experiment"]
    return "improved_experiment", IMPACT_MULTIPLIER["improved_experiment"]


def _mean_pairwise_distance(matrix: np.ndarray) -> float:
    """Mean of (1 - cosine) over all pairs in an L2-normalized matrix."""
    if len(matrix) < 2:
        return 0.0
    sims = matrix @ matrix.T
    n = len(matrix)
    iu = np.triu_indices(n, k=1)
    return float(np.mean(1.0 - sims[iu]))


def _validity_check(c: ProposedCandidate) -> tuple[bool, str | None]:
    """Structural checks on a proposed .md.

    v0 rules:
      - Title (H1) must be non-empty
      - Proposal section must exist and have >= 50 chars of content
    """
    if not c.title or len(c.title) < 3:
        return False, "missing or trivial title"
    if "proposal" not in c.sections:
        return False, "missing ## Proposal section"
    if len(c.proposal_text) < 50:
        return False, "Proposal section too short (<50 chars)"
    return True, None
