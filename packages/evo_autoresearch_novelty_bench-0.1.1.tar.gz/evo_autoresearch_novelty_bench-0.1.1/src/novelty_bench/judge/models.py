"""Result types for the judge."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ProposalClassification(str, Enum):
    INVALID = "invalid"
    REDISCOVERY = "rediscovery"
    NOVEL_UNVALIDATED = "novel_unvalidated"
    NOVEL_VALIDATED = "novel_validated"


class ProposedCandidate(BaseModel):
    """One proposal the proposer agent produced — parsed from a .md file."""

    source_path: Optional[str] = None  # the .md path; None if constructed in-memory
    title: str
    proposal_text: str  # the body of the Proposal section
    raw_text: str
    sections: dict[str, str] = Field(default_factory=dict)


class PerProposalScore(BaseModel):
    """Per-proposal breakdown of how the set_score was computed."""

    candidate_idx: int
    title: str
    classification: ProposalClassification
    score: float
    nearest_prior_id: Optional[str] = None
    nearest_prior_similarity: Optional[float] = None
    matched_future_id: Optional[str] = None
    matched_future_pool: Optional[str] = None  # "frontier" / "improved" / None
    impact_multiplier: Optional[float] = None
    invalid_reason: Optional[str] = None

    # Set on rediscovery rows; documents which rejection severity tier the
    # matched prior fell into and what multiplier scaled the base -0.5 score.
    matched_prior_rejection_class: Optional[str] = None
    rejection_multiplier: Optional[float] = None

    # Set when judge_backend="llm-hybrid": the reasoning model's natural-
    # language explanation for the classification decision.
    llm_reasoning: Optional[str] = None
    llm_match_confidence: Optional[float] = None
    llm_model: Optional[str] = None


class ScoringResult(BaseModel):
    """What nb.score() returns."""

    snapshot_id: str
    n_candidates: int
    set_score: float
    sum_per_proposal: float
    diversity_bonus: float
    validity_term: float
    per_proposal: list[PerProposalScore]
    embedding_backend: str
    diversity_weight: float
    validity_weight: float
    rediscovery_threshold: float

    def explain(self) -> str:
        """Human-readable summary."""
        lines = [
            f"snapshot {self.snapshot_id}  •  {self.n_candidates} candidates  "
            f"•  backend={self.embedding_backend}",
            f"set_score = {self.set_score:+.3f}",
            f"  sum(per-proposal) = {self.sum_per_proposal:+.3f}",
            f"  + {self.diversity_weight} × diversity ({self.diversity_bonus:.3f}) "
            f"= {self.diversity_weight * self.diversity_bonus:+.3f}",
            f"  + {self.validity_weight} × validity  ({self.validity_term:.3f}) "
            f"= {self.validity_weight * self.validity_term:+.3f}",
            "",
            "Per-proposal:",
        ]
        for p in self.per_proposal:
            tag = p.classification.value
            extras = []
            if p.nearest_prior_id and p.classification == ProposalClassification.REDISCOVERY:
                rej = ""
                if p.matched_prior_rejection_class and p.matched_prior_rejection_class != "none":
                    rej = f", rejection={p.matched_prior_rejection_class} ×{p.rejection_multiplier}"
                extras.append(
                    f"matches prior `{p.nearest_prior_id}` (cos {p.nearest_prior_similarity:.3f}{rej})"
                )
            if p.matched_future_id:
                extras.append(
                    f"validated by `{p.matched_future_id}` ({p.matched_future_pool}, "
                    f"impact ×{p.impact_multiplier})"
                )
            if p.invalid_reason:
                extras.append(p.invalid_reason)
            extra_str = "  —  " + "; ".join(extras) if extras else ""
            lines.append(
                f"  [{p.candidate_idx}] {p.score:+.3f}  {tag:<19s}  "
                f"{p.title[:55]}{extra_str}"
            )
        return "\n".join(lines)
