"""Judge — score a set of N proposed candidates against a snapshot.

Public entrypoint:

  nb.score(snapshot, proposals, *, embedding_backend="openai") -> ScoringResult

Where `proposals` is a list of file paths (one per candidate .md) or a list of
already-parsed ProposedCandidate objects. `snapshot` is one row from
snapshots.parquet (pandas Series or dict).

The result decomposes into per-proposal scores + a diversity bonus + a
validity term; see ScoringResult for the full breakdown.
"""

from .models import (
    ProposalClassification,
    ProposedCandidate,
    ScoringResult,
)
from .score import parse_proposal_file, score

__all__ = [
    "ProposalClassification",
    "ProposedCandidate",
    "ScoringResult",
    "parse_proposal_file",
    "score",
]
