"""LLM-hybrid judge: top-K cosine retrieval + reasoning-model classification.

The embedding judge is fast/cheap but has a paraphrase gap (the same mechanism
in completely different words scores cosine < threshold and slips through as
novel). For semantic mechanism-equivalence we need actual reasoning.

This module wraps the cosine retrieval with an LLM reasoning step:
  1. Embed the candidate
  2. Top-K nearest priors + top-K nearest futures (cosine retrieval, fast)
  3. Pass candidate + 2K short descriptions to a reasoning model
  4. Reasoning model returns structured JSON: classification + matched_id + reasoning

Default model: gpt-5-mini with reasoning_effort="medium".
Cost per N=5 candidate call: ~$0.005-0.01.
"""

from __future__ import annotations

import json
import os

DEFAULT_MODEL = "gpt-5-mini"
DEFAULT_REASONING_EFFORT = "medium"
DEFAULT_TOP_K = 20

SYSTEM_PROMPT = """\
You are judging whether a research-proposal candidate matches any of the
prior or future experiments shown. Your output decides the candidate's
classification.

Classifications (pick one):
- "rediscovery": the candidate proposes a mechanism the PRIOR pool already
  contains. Cosmetic renames, paraphrases, hyperparameter tweaks, and
  trivial compositions of an existing prior all count as rediscovery.
- "novel_validated": the candidate's mechanism is the SAME as one in the
  FUTURE pool — meaning other researchers later validated this exact
  mechanism. The candidate anticipates a winning direction.
- "novel_unvalidated": genuinely new — different mechanism family from both
  pools. The candidate is exploring an untested direction.

Mechanism equivalence (use this judgment, not surface text):
- Same intervention target (optimizer-update, preconditioner, schedule,
  init, loss, etc.) PLUS same core idea = same mechanism.
- Different HP values of the same mechanism = same mechanism.
- Same mechanism with different name = same mechanism.
- Two papers solving the same problem with different machinery = different.

Output JSON only. Schema:
{
  "classification": "rediscovery" | "novel_validated" | "novel_unvalidated",
  "matched_id": "<experiment_id from pool, or null if novel_unvalidated>",
  "match_confidence": <float 0-1>,
  "reasoning": "<one short paragraph explaining the decision>"
}
"""


def _format_pool(name: str, entries: list[dict], k: int = DEFAULT_TOP_K) -> str:
    """Render the top-K pool entries as a compact list for the prompt."""
    out = [f"## {name} pool (top {len(entries[:k])} nearest by embedding)"]
    for e in entries[:k]:
        desc = (e.get("description_text") or "").strip().split("\n", 1)[0][:240]
        sim = e.get("similarity")
        sim_str = f" (cos={sim:.3f})" if sim is not None else ""
        out.append(f"- `{e['experiment_id']}`{sim_str}: {desc}")
    return "\n".join(out)


def classify_with_llm(
    *,
    candidate_title: str,
    candidate_body: str,
    top_priors: list[dict],
    top_futures: list[dict],
    model: str = DEFAULT_MODEL,
    reasoning_effort: str = DEFAULT_REASONING_EFFORT,
) -> dict:
    """Call the reasoning model. Returns a dict matching the JSON schema in
    the system prompt, or {"classification": "error", "reasoning": "<msg>"}
    on failure.

    top_priors / top_futures are dicts shaped:
      {"experiment_id": str, "description_text": str, "similarity": float}
    """
    if not os.environ.get("OPENAI_API_KEY"):
        return {"classification": "error", "reasoning": "OPENAI_API_KEY not set"}

    from openai import OpenAI
    client = OpenAI()

    user_msg = (
        f"# Candidate\n\n"
        f"**Title**: {candidate_title}\n\n"
        f"**Proposal**:\n{candidate_body[:2000]}\n\n"
        f"{_format_pool('Prior', top_priors)}\n\n"
        f"{_format_pool('Future', top_futures)}\n\n"
        f"Classify the candidate. Output JSON only."
    )

    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            reasoning_effort=reasoning_effort,
            response_format={"type": "json_object"},
        )
        raw = resp.choices[0].message.content
        result = json.loads(raw)
        # Validate minimal shape
        cls = result.get("classification")
        if cls not in ("rediscovery", "novel_validated", "novel_unvalidated"):
            return {"classification": "error",
                    "reasoning": f"LLM returned unknown classification: {cls!r}"}
        return {
            "classification": cls,
            "matched_id": result.get("matched_id"),
            "match_confidence": float(result.get("match_confidence", 0.0)),
            "reasoning": result.get("reasoning", "").strip(),
            "_model": model,
            "_input_tokens": resp.usage.prompt_tokens,
            "_output_tokens": resp.usage.completion_tokens,
        }
    except Exception as e:  # noqa: BLE001
        return {"classification": "error", "reasoning": f"LLM call failed: {e}"}
