"""Generate the calibration set from dev snapshots.

For each dev snapshot, sample 5 candidates with known expected classifications:

  prior_verbatim     - description from a snapshot.prior_experiment            -> rediscovery
  future_verbatim    - description from a snapshot.future_improved_experiment  -> novel_validated
  prior_paraphrase   - LLM-paraphrased prior (tests paraphrase invariance)     -> rediscovery
  cross_scope_novel  - description from a different scope's experiment         -> novel_unvalidated
  malformed          - missing Proposal section                                -> invalid

Output: calibration_cases.parquet with columns:
  case_id, snapshot_id, source_type, source_experiment_id,
  candidate_title, candidate_md_text, expected_classification
"""

from __future__ import annotations

import argparse
import os
import random
import sys
from pathlib import Path

import pandas as pd

import novelty_bench as nb


SOURCE_TYPES_AND_EXPECTED = {
    "prior_verbatim": "rediscovery",
    "future_verbatim": "novel_validated",
    "prior_paraphrase": "rediscovery",
    "cross_scope_novel": "novel_unvalidated",
    "malformed": "invalid",
}


def _wrap_as_md(title: str, body: str, novelty_note: str = "see prior") -> str:
    return (
        f"# {title}\n\n"
        f"## Proposal\n\n"
        f"{body}\n\n"
        f"## Novelty\n\n"
        f"{novelty_note}\n"
    )


def _paraphrase(text: str, *, model: str = "gpt-4o-mini") -> str:
    """Rewrite a mechanism description in different words. Tests paraphrase invariance."""
    from openai import OpenAI
    client = OpenAI()
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content":
             "Rewrite the user's text in different words and sentence structure, "
             "keeping the technical content (mechanism, hyperparameters, intent) "
             "exactly the same. Don't add new ideas. Don't editorialize. "
             "Match the original's terse-technical tone."},
            {"role": "user", "content": text},
        ],
        max_tokens=400,
        temperature=0.0,
    )
    return resp.choices[0].message.content.strip()


def _sample_prior_verbatim(snap, experiments_df, rng) -> dict | None:
    pri_ids = list(snap["prior_experiment_ids"])
    if not pri_ids:
        return None
    candidates = experiments_df[experiments_df["experiment_id"].isin(pri_ids)]
    candidates = candidates[candidates["description_text"].str.len() > 100]
    if candidates.empty:
        return None
    pick = candidates.sample(1, random_state=rng.randint(0, 10**9)).iloc[0]
    title = pick["experiment_id"][:60]
    body = pick["description_text"][:1500]
    return {
        "source_experiment_id": pick["experiment_id"],
        "candidate_title": title,
        "candidate_md_text": _wrap_as_md(title, body, "builds on prior"),
    }


def _sample_future_verbatim(snap, experiments_df, rng) -> dict | None:
    fut_ids = list(snap["future_improved_experiment_ids"])
    if not fut_ids:
        return None
    candidates = experiments_df[experiments_df["experiment_id"].isin(fut_ids)]
    candidates = candidates[candidates["description_text"].str.len() > 100]
    if candidates.empty:
        return None
    pick = candidates.sample(1, random_state=rng.randint(0, 10**9)).iloc[0]
    title = pick["experiment_id"][:60]
    body = pick["description_text"][:1500]
    return {
        "source_experiment_id": pick["experiment_id"],
        "candidate_title": title,
        "candidate_md_text": _wrap_as_md(title, body, "exploring an unexplored direction"),
    }


def _sample_prior_paraphrase(snap, experiments_df, rng) -> dict | None:
    base = _sample_prior_verbatim(snap, experiments_df, rng)
    if base is None:
        return None
    pri = experiments_df[experiments_df["experiment_id"] == base["source_experiment_id"]].iloc[0]
    paraphrased = _paraphrase(pri["description_text"][:1500])
    return {
        "source_experiment_id": base["source_experiment_id"],
        "candidate_title": base["candidate_title"],
        "candidate_md_text": _wrap_as_md(base["candidate_title"], paraphrased,
                                          "different wording, same mechanism"),
    }


def _sample_cross_scope_novel(snap, experiments_df, rng) -> dict | None:
    # Pick from a DIFFERENT (agent, wave) than the snapshot — guaranteed not in prior/future pool
    other_scope = experiments_df[
        ~((experiments_df["agent"] == snap["agent"]) &
          (experiments_df["wave"] == snap["wave"]))
    ]
    other_scope = other_scope[other_scope["description_text"].str.len() > 100]
    if other_scope.empty:
        return None
    pick = other_scope.sample(1, random_state=rng.randint(0, 10**9)).iloc[0]
    title = pick["experiment_id"][:60]
    body = pick["description_text"][:1500]
    return {
        "source_experiment_id": pick["experiment_id"],
        "candidate_title": title,
        "candidate_md_text": _wrap_as_md(title, body, "from a different research thread"),
    }


def _malformed(snap, rng) -> dict:
    return {
        "source_experiment_id": None,
        "candidate_title": "Stub",
        "candidate_md_text": "# Stub\n\nNothing here, just a placeholder.\n",
    }


SAMPLERS = {
    "prior_verbatim": _sample_prior_verbatim,
    "future_verbatim": _sample_future_verbatim,
    "prior_paraphrase": _sample_prior_paraphrase,
    "cross_scope_novel": _sample_cross_scope_novel,
}


def generate_cases(
    *,
    splits: tuple[str, ...] = ("dev",),
    include_paraphrase: bool = True,
    seed: int = 42,
) -> pd.DataFrame:
    """Generate calibration cases. Returns a DataFrame ready to write to parquet."""
    rng = random.Random(seed)
    snaps = nb.load_snapshots()
    snaps = snaps[snaps["split"].isin(splits)]
    print(f"Generating cases for {len(snaps)} {'+'.join(splits)} snapshots")

    experiments = nb.load_experiments()

    rows: list[dict] = []
    case_id = 0
    for _, snap in snaps.iterrows():
        for source_type, expected in SOURCE_TYPES_AND_EXPECTED.items():
            if source_type == "prior_paraphrase" and not include_paraphrase:
                continue

            if source_type == "malformed":
                sample = _malformed(snap, rng)
            else:
                sampler = SAMPLERS[source_type]
                sample = sampler(snap, experiments, rng)
                if sample is None:
                    continue  # snapshot too sparse for this type

            rows.append({
                "case_id": f"calib_{case_id:04d}",
                "snapshot_id": snap["snapshot_id"],
                "source_type": source_type,
                "source_experiment_id": sample["source_experiment_id"],
                "candidate_title": sample["candidate_title"],
                "candidate_md_text": sample["candidate_md_text"],
                "expected_classification": expected,
            })
            case_id += 1

    return pd.DataFrame(rows)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m novelty_bench.calibration.generate")
    p.add_argument("--data-root", type=Path, default=Path("data/out"))
    p.add_argument("--splits", nargs="+", default=["dev"],
                   help="Snapshot splits to draw from (default: dev only)")
    p.add_argument("--no-paraphrase", action="store_true",
                   help="Skip LLM paraphrase cases (avoids OpenAI call)")
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args(argv)

    include_paraphrase = not args.no_paraphrase
    if include_paraphrase and not os.environ.get("OPENAI_API_KEY"):
        print("warning: OPENAI_API_KEY not set; paraphrase cases will fail. "
              "Use --no-paraphrase to skip them.", file=sys.stderr)

    df = generate_cases(
        splits=tuple(args.splits),
        include_paraphrase=include_paraphrase,
        seed=args.seed,
    )
    print(f"\nGenerated {len(df)} calibration cases")
    print("Cases per source_type:")
    print(df["source_type"].value_counts().to_string())

    out_path = args.data_root / "calibration_cases.parquet"
    df.to_parquet(out_path, index=False)
    print(f"\nWrote {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
