"""Run the judge against the calibration set; report agreement metrics."""

from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

import pandas as pd

import novelty_bench as nb
from ..judge.score import score


def _write_candidate_to_file(case_row: pd.Series, out_dir: Path) -> Path:
    path = out_dir / f"{case_row['case_id']}.md"
    path.write_text(case_row["candidate_md_text"], encoding="utf-8")
    return path


def evaluate_calibration(
    *,
    cases_df: pd.DataFrame,
    embedding_backend: str = "openai",
    rediscovery_threshold: float = 0.85,
    data_root: Path | None = None,
) -> pd.DataFrame:
    """For each case, run the judge and record (expected, predicted, score, top_match)."""
    snaps = nb.load_snapshots(data_root=data_root)

    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        # Group by snapshot to amortize the snapshot lookup
        for snap_id, grp in cases_df.groupby("snapshot_id"):
            snap = snaps[snaps["snapshot_id"] == snap_id].iloc[0]
            # Write each candidate to disk so score() can parse it
            candidate_paths = [_write_candidate_to_file(row, tmp) for _, row in grp.iterrows()]
            try:
                result = score(
                    snap, candidate_paths,
                    embedding_backend=embedding_backend,
                    rediscovery_threshold=rediscovery_threshold,
                    data_root=data_root,
                )
            except Exception as e:
                for _, row in grp.iterrows():
                    rows.append({
                        "case_id": row["case_id"],
                        "snapshot_id": snap_id,
                        "source_type": row["source_type"],
                        "expected_classification": row["expected_classification"],
                        "predicted_classification": "error",
                        "score": None,
                        "error": str(e),
                    })
                continue

            for (_, row), per in zip(grp.iterrows(), result.per_proposal):
                rows.append({
                    "case_id": row["case_id"],
                    "snapshot_id": snap_id,
                    "source_type": row["source_type"],
                    "expected_classification": row["expected_classification"],
                    "predicted_classification": per.classification.value,
                    "score": per.score,
                    "nearest_prior_id": per.nearest_prior_id,
                    "nearest_prior_sim": per.nearest_prior_similarity,
                    "matched_future_id": per.matched_future_id,
                    "matched_future_pool": per.matched_future_pool,
                    "invalid_reason": per.invalid_reason,
                })

    return pd.DataFrame(rows)


def agreement_summary(eval_df: pd.DataFrame) -> dict:
    """Compute overall + per-class agreement (precision, recall, F1)."""
    if eval_df.empty:
        return {"n": 0}
    correct = (eval_df["expected_classification"] == eval_df["predicted_classification"]).sum()
    n = len(eval_df)
    summary = {
        "n": n,
        "overall_accuracy": round(correct / n, 3),
        "per_source_type": {},
        "per_class": {},
    }

    # Per source_type accuracy
    for src_type, grp in eval_df.groupby("source_type"):
        match = (grp["expected_classification"] == grp["predicted_classification"]).sum()
        summary["per_source_type"][src_type] = {
            "n": len(grp),
            "accuracy": round(match / len(grp), 3),
            "mode_predicted": grp["predicted_classification"].mode().iloc[0] if len(grp) else None,
        }

    # Per-class precision/recall/F1
    classes = sorted(set(eval_df["expected_classification"]) | set(eval_df["predicted_classification"]))
    for cls in classes:
        true_pos = ((eval_df["expected_classification"] == cls) & (eval_df["predicted_classification"] == cls)).sum()
        false_pos = ((eval_df["expected_classification"] != cls) & (eval_df["predicted_classification"] == cls)).sum()
        false_neg = ((eval_df["expected_classification"] == cls) & (eval_df["predicted_classification"] != cls)).sum()
        precision = true_pos / (true_pos + false_pos) if (true_pos + false_pos) else 0.0
        recall = true_pos / (true_pos + false_neg) if (true_pos + false_neg) else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        summary["per_class"][cls] = {
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "f1": round(f1, 3),
            "support": int((eval_df["expected_classification"] == cls).sum()),
        }
    return summary


def sweep_threshold(
    *,
    cases_df: pd.DataFrame,
    thresholds: tuple[float, ...] = (0.70, 0.75, 0.80, 0.85, 0.90, 0.95),
    embedding_backend: str = "openai",
    data_root: Path | None = None,
) -> pd.DataFrame:
    """Run evaluate_calibration at each threshold and report agreement."""
    rows = []
    for thresh in thresholds:
        print(f"\n=== threshold = {thresh} ===")
        eval_df = evaluate_calibration(
            cases_df=cases_df,
            embedding_backend=embedding_backend,
            rediscovery_threshold=thresh,
            data_root=data_root,
        )
        summary = agreement_summary(eval_df)
        print(f"  accuracy: {summary['overall_accuracy']}")
        for src, s in summary["per_source_type"].items():
            print(f"  {src:<20s} acc={s['accuracy']:.2f}  mode_predicted={s['mode_predicted']}")
        rows.append({
            "threshold": thresh,
            "overall_accuracy": summary["overall_accuracy"],
            **{f"acc_{k}": v["accuracy"] for k, v in summary["per_source_type"].items()},
            **{f"f1_{cls}": s["f1"] for cls, s in summary["per_class"].items()},
        })
    return pd.DataFrame(rows)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m novelty_bench.calibration.evaluate")
    p.add_argument("--data-root", type=Path, default=Path("data/out"))
    p.add_argument("--backend", choices=("openai", "bge"), default="openai")
    p.add_argument("--threshold", type=float, default=0.85,
                   help="Single threshold; or use --sweep to sweep")
    p.add_argument("--sweep", action="store_true",
                   help="Sweep thresholds 0.70..0.95 step 0.05")
    args = p.parse_args(argv)

    cases_path = args.data_root / "calibration_cases.parquet"
    if not cases_path.exists():
        print(f"error: {cases_path} not found. Run "
              f"`python -m novelty_bench.calibration.generate` first.", file=sys.stderr)
        return 2
    cases_df = pd.read_parquet(cases_path)
    print(f"Loaded {len(cases_df)} calibration cases\n")

    if args.sweep:
        sweep_df = sweep_threshold(
            cases_df=cases_df, embedding_backend=args.backend, data_root=args.data_root,
        )
        out_path = args.data_root / "calibration_sweep.parquet"
        sweep_df.to_parquet(out_path, index=False)
        print(f"\nWrote sweep results -> {out_path}")
        print(sweep_df.to_string(index=False))
    else:
        eval_df = evaluate_calibration(
            cases_df=cases_df, embedding_backend=args.backend,
            rediscovery_threshold=args.threshold, data_root=args.data_root,
        )
        out_path = args.data_root / "calibration_eval.parquet"
        eval_df.to_parquet(out_path, index=False)
        summary = agreement_summary(eval_df)
        print("\nAgreement summary:")
        import json
        print(json.dumps(summary, indent=2))
        print(f"\nWrote per-case results -> {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
