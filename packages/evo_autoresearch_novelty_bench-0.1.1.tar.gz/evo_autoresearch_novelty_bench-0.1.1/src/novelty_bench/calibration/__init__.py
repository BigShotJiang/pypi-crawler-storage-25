"""Calibration set + judge agreement metrics.

The calibration set is a labeled set of (snapshot, candidate, expected_class)
tuples we use to:
  1. Validate the judge agrees with human-derived ground truth
  2. Tune the cosine rediscovery_threshold
  3. Run anti-cheat tests (paraphrase invariance, etc.)

Cases are generated programmatically from dev snapshots, so labels are
deterministic (we know what we sampled).
"""

from .generate import generate_cases
from .evaluate import evaluate_calibration, sweep_threshold

__all__ = ["generate_cases", "evaluate_calibration", "sweep_threshold"]
