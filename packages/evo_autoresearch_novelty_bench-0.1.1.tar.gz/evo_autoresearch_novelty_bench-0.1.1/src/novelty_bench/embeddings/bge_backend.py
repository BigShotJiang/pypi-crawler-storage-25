"""Local BGE-large-en-v1.5 backend.

1024-dim, free, offline. ~1.3GB one-time model download to ~/.cache/huggingface.
Slower than OpenAI on CPU (~5 embeddings/sec) but no API key required.
"""

from __future__ import annotations

import time

import numpy as np

MODEL = "BAAI/bge-large-en-v1.5"
EMBED_DIM = 1024


def embed_texts(texts: list[str], *, batch_size: int = 32,
                show_progress: bool = True) -> np.ndarray:
    """Return an (N, 1024) float32 ndarray of L2-normalized embeddings."""
    if not texts:
        return np.zeros((0, EMBED_DIM), dtype=np.float32)
    from sentence_transformers import SentenceTransformer  # lazy import

    print(f"  loading {MODEL} (first run downloads ~1.3GB)...")
    t0 = time.time()
    model = SentenceTransformer(MODEL)
    print(f"  loaded in {time.time() - t0:.1f}s")

    t0 = time.time()
    embeddings = model.encode(
        texts,
        batch_size=batch_size,
        normalize_embeddings=True,
        show_progress_bar=show_progress,
        convert_to_numpy=True,
    )
    elapsed = time.time() - t0
    rate = len(texts) / elapsed if elapsed > 0 else 0
    print(f"  encoded {len(texts)} texts in {elapsed:.1f}s ({rate:.1f} texts/s)")
    return embeddings.astype(np.float32)
