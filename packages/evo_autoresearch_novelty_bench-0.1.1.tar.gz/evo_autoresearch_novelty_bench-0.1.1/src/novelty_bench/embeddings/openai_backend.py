"""OpenAI text-embedding-3-large backend.

3072-dim, ~$0.13/1M tokens. Requires OPENAI_API_KEY env var (or passed via
the OpenAI client kwargs). Embeds in batches; falls back to one-by-one if a
batch fails.
"""

from __future__ import annotations

import os
import time
from typing import Iterable

import numpy as np

MODEL = "text-embedding-3-large"
EMBED_DIM = 3072
PRICE_PER_M_TOKENS = 0.13  # text-embedding-3-large pricing (USD)
DEFAULT_BATCH_SIZE = 100  # OpenAI accepts up to 2048 inputs but smaller batches retry cleanly


def embed_texts(texts: list[str], *, batch_size: int = DEFAULT_BATCH_SIZE,
                show_progress: bool = True) -> tuple[np.ndarray, dict]:
    """Embed N texts. Returns (embeddings, usage_dict).

    usage_dict has exact token counts from response.usage:
      {"prompt_tokens": int, "total_tokens": int, "cost_usd": float, "model": str}
    """
    if not texts:
        return np.zeros((0, EMBED_DIM), dtype=np.float32), _empty_usage()
    if not os.environ.get("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY not set. Set it or use --backend bge for the local model."
        )
    from openai import OpenAI  # imported lazily so users without the dep aren't blocked

    client = OpenAI()
    out = np.zeros((len(texts), EMBED_DIM), dtype=np.float32)
    n_batches = (len(texts) + batch_size - 1) // batch_size
    total_prompt_tokens = 0
    total_tokens = 0
    t_start = time.time()
    for batch_idx in range(n_batches):
        lo = batch_idx * batch_size
        hi = min(lo + batch_size, len(texts))
        batch = texts[lo:hi]
        embeddings, usage = _embed_batch(client, batch)
        out[lo:hi] = embeddings
        total_prompt_tokens += usage["prompt_tokens"]
        total_tokens += usage["total_tokens"]
        if show_progress:
            elapsed = time.time() - t_start
            done = hi
            rate = done / elapsed if elapsed > 0 else 0
            print(
                f"  embedded {done:>5d}/{len(texts):>5d}  "
                f"({rate:.1f} texts/s, batch {batch_idx + 1}/{n_batches}, "
                f"running cost ${total_prompt_tokens / 1_000_000 * PRICE_PER_M_TOKENS:.4f})"
            )

    # L2-normalize (text-embedding-3-large returns unnormalized vectors)
    norms = np.linalg.norm(out, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return (out / norms).astype(np.float32), {
        "model": MODEL,
        "prompt_tokens": total_prompt_tokens,
        "total_tokens": total_tokens,
        "cost_usd": round(total_prompt_tokens / 1_000_000 * PRICE_PER_M_TOKENS, 6),
    }


def _embed_batch(client, batch: list[str]) -> tuple[np.ndarray, dict]:
    """One API call. Returns (embeddings_array, usage_dict)."""
    try:
        resp = client.embeddings.create(model=MODEL, input=batch)
        return _unpack(resp)
    except Exception as e:  # noqa: BLE001
        print(f"  batch failed ({e}); retrying once...")
        try:
            resp = client.embeddings.create(model=MODEL, input=batch)
            return _unpack(resp)
        except Exception:
            print(f"  retry failed; falling back to per-item")
            out = np.zeros((len(batch), EMBED_DIM), dtype=np.float32)
            prompt_toks = 0
            total_toks = 0
            for i, text in enumerate(batch):
                try:
                    r = client.embeddings.create(model=MODEL, input=text)
                    arr, usage = _unpack(r)
                    out[i] = arr[0]
                    prompt_toks += usage["prompt_tokens"]
                    total_toks += usage["total_tokens"]
                except Exception as e2:  # noqa: BLE001
                    print(f"    item {i} failed: {e2}; leaving as zeros")
            return out, {"prompt_tokens": prompt_toks, "total_tokens": total_toks}


def _unpack(resp) -> tuple[np.ndarray, dict]:
    arr = np.array([d.embedding for d in resp.data], dtype=np.float32)
    usage = {"prompt_tokens": resp.usage.prompt_tokens, "total_tokens": resp.usage.total_tokens}
    return arr, usage


def _empty_usage() -> dict:
    return {"model": MODEL, "prompt_tokens": 0, "total_tokens": 0, "cost_usd": 0.0}


def measure_cost_from_sample(texts: list[str], sample_size: int = 50) -> dict:
    """Get an accurate pre-run cost estimate by actually embedding a sample.

    Uses the API's own token count to extrapolate, since chars/4 heuristics
    are off by 2-5x for technical ML text.
    """
    if not texts:
        return {"sampled": 0, "extrapolated_total": 0, "extrapolated_cost_usd": 0.0}
    sample = texts[: min(sample_size, len(texts))]
    _, usage = embed_texts(sample, show_progress=False)
    avg_tokens_per_text = usage["prompt_tokens"] / len(sample)
    extrapolated_tokens = int(avg_tokens_per_text * len(texts))
    return {
        "sampled": len(sample),
        "sample_tokens": usage["prompt_tokens"],
        "avg_tokens_per_text": round(avg_tokens_per_text, 1),
        "extrapolated_total": extrapolated_tokens,
        "extrapolated_cost_usd": round(extrapolated_tokens / 1_000_000 * PRICE_PER_M_TOKENS, 4),
    }
