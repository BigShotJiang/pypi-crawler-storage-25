"""Proposal embeddings — pluggable backends, precomputed and shipped with the dataset.

Two backends supported:
  - "openai":  text-embedding-3-large (3072-dim). Default. Needs OPENAI_API_KEY.
  - "bge":     BAAI/bge-large-en-v1.5 (1024-dim). Local CPU/GPU, free, offline.

The judge picks a backend at score time; both produce comparable scores within
their own embedding space. We ship both tables so users can switch without
regenerating.
"""

from .text_source import build_text_sources

__all__ = ["build_text_sources"]
