"""Derive the text we feed to the embedding model for each proposal.

Until mechanism extraction (task #24) lands, we use the best-available text:
  - If the proposal has a parent_idea_id: parent idea's title + proposal_text
    (the formal writeup the agent produced for this mechanism family)
  - Otherwise: the variant_stem (filename encodes the differentiating signal —
    e.g. `abp001_alpha002_clip3_exact3450` says alpha=0.02 on the abp001 family)

When mechanism extraction lands, swap the source to mechanism_summary +
intervention_target — much sharper and discriminates HP cells of the same idea.

Returns a DataFrame with columns:
  proposal_id, text_source, text_source_type
"""

from __future__ import annotations

import pandas as pd

MAX_PROPOSAL_TEXT_CHARS = 1500  # enough to capture mechanism; well under any model limit


def build_text_sources(proposals_df: pd.DataFrame, ideas_df: pd.DataFrame) -> pd.DataFrame:
    """Return per-proposal text + provenance tag.

    Both inputs are the standard parquet shapes from nb.load_*().
    """
    ideas_idx = ideas_df.set_index("idea_id")[["title", "proposal_text"]]

    rows: list[dict] = []
    for _, p in proposals_df.iterrows():
        parent_id = p.get("parent_idea_id")
        if pd.notna(parent_id) and parent_id in ideas_idx.index:
            idea = ideas_idx.loc[parent_id]
            title = (idea["title"] or "").strip()
            body = (idea["proposal_text"] or "").strip()[:MAX_PROPOSAL_TEXT_CHARS]
            text = f"{title}\n\n{body}".strip() if body else title
            source_type = "parent_idea_writeup"
        else:
            text = p["variant_stem"].replace("_", " ").replace("-", " ")
            source_type = "variant_stem"
        rows.append({
            "proposal_id": p["proposal_id"],
            "text_source": text,
            "text_source_type": source_type,
        })
    return pd.DataFrame(rows)
