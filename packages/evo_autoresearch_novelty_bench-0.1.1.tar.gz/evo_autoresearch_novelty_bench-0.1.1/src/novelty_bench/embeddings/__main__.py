"""CLI: compute embeddings for a parquet table and write back to parquet.

  python -m novelty_bench.embeddings --table experiments --backend openai
  python -m novelty_bench.embeddings --table experiments --backend bge
  python -m novelty_bench.embeddings --table proposals   --backend openai
  python -m novelty_bench.embeddings --table experiments --backend openai --limit 5  # dry run

Tables:
  experiments — embeds experiments.description_text, keyed by experiment_id
                Output: {out}/experiment_embeddings_{backend}.parquet
  proposals   — embeds proposals via the text_source helper (legacy path)
                Output: {out}/proposal_embeddings_{backend}.parquet
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

import novelty_bench as nb

from .text_source import build_text_sources


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m novelty_bench.embeddings")
    p.add_argument("--table", choices=("experiments", "proposals"), default="experiments")
    p.add_argument("--backend", choices=("openai", "bge"), required=True)
    p.add_argument("--out", type=Path, default=Path("data/out"))
    p.add_argument("--limit", type=int, default=None,
                   help="Embed only the first N rows (dry-run / smoke test)")
    p.add_argument("--data-root", type=Path, default=None,
                   help="Override NOVELTY_BENCH_DATA_ROOT for the input parquets")
    args = p.parse_args(argv)

    args.out.mkdir(parents=True, exist_ok=True)

    # Load + build text sources by table
    if args.table == "experiments":
        df = nb.load_experiments(data_root=args.data_root)
        if args.limit:
            df = df.head(args.limit)
        sources = df[["experiment_id", "description_text", "description_source"]].rename(
            columns={"description_text": "text_source", "description_source": "text_source_type"}
        )
        id_col = "experiment_id"
        print(f"Embedding {len(df):,} experiments")
    else:
        proposals = nb.load_proposals(data_root=args.data_root)
        ideas = nb.load_ideas(data_root=args.data_root)
        if args.limit:
            proposals = proposals.head(args.limit)
        print(f"Building text sources for {len(proposals):,} proposals")
        sources = build_text_sources(proposals, ideas)
        id_col = "proposal_id"

    src_counts = sources["text_source_type"].value_counts().to_dict()
    print(f"  source mix: {src_counts}")

    texts = sources["text_source"].tolist()

    if args.backend == "openai":
        from .openai_backend import MODEL, embed_texts, measure_cost_from_sample
        print(f"Backend: openai ({MODEL})")
        if len(texts) > 50:
            print("  measuring cost on a 50-item sample (real API call)...")
            est = measure_cost_from_sample(texts, sample_size=50)
            print(
                f"  sampled {est['sampled']} -> {est['sample_tokens']} tokens "
                f"(avg {est['avg_tokens_per_text']}/text)"
            )
            print(
                f"  extrapolated for {len(texts):,} texts: "
                f"~{est['extrapolated_total']:,} tokens  ~${est['extrapolated_cost_usd']:.4f}"
            )
        embeddings, usage = embed_texts(texts)
        print(f"\nActual usage from API:")
        print(f"  prompt_tokens: {usage['prompt_tokens']:,}")
        print(f"  cost: ${usage['cost_usd']:.6f}")
    else:
        from .bge_backend import MODEL, embed_texts
        print(f"Backend: bge ({MODEL})  (free, local)")
        embeddings = embed_texts(texts)
        usage = {"model": MODEL, "cost_usd": 0.0}

    if embeddings.shape[0] != len(sources):
        print(f"error: got {embeddings.shape[0]} embeddings but {len(sources)} rows",
              file=sys.stderr)
        return 2

    out_df = sources.copy()
    out_df["embedding"] = list(embeddings)
    out_df["embedding_model"] = MODEL

    out_filename = (
        f"experiment_embeddings_{args.backend}.parquet"
        if args.table == "experiments"
        else f"proposal_embeddings_{args.backend}.parquet"
    )
    out_path = args.out / out_filename
    out_df.to_parquet(out_path, index=False)
    print(f"\nWrote {len(out_df):,} embeddings -> {out_path}")
    print(f"  dim: {embeddings.shape[1]}, dtype: {embeddings.dtype}")
    print(f"  file size: {out_path.stat().st_size / 1024 / 1024:.1f} MB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
