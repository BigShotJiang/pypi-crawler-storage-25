"""Extract per-run variant source code embedded in modded-nanogpt training logs.

Every modded-nanogpt run starts by opening its own .py file and printing it
to stdout, followed by a 100-char `====...====` delimiter. The log file thus
embeds the exact source that ran — even if the variant.py file on disk was
later edited (as agents did with v1/codex and v3/codex shared templates).

This module scans every run's log file, extracts the embedded source, hashes
it, and writes it to:
    data/out/recovered_variants/{experiment_id}.py

Also writes `recovered_variant_sources.parquet` with:
    experiment_id, recovered_path, sha256, source_bytes

Coverage:
  - codex/novelty, v2, v3, claude-code/novelty: most runs embed source
  - claude-code/v1, v2, v3: log format doesn't embed (no recovery)
  - Recovers ~1,120 previously-unlinked + adds gold-standard code for many
    already-linked runs (where variants/ file was edited post-launch).
"""

from __future__ import annotations

import argparse
import hashlib
import sys
import time
from pathlib import Path

import pandas as pd

DELIMITER = "=" * 100


def extract_embedded_source(log_path: Path) -> bytes | None:
    """Return everything up to the first `====...====` line, or None."""
    try:
        text = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    if DELIMITER not in text:
        return None
    head = text.split(DELIMITER, 1)[0]
    return head.encode("utf-8")


def extract_all(
    *,
    runs_df: pd.DataFrame,
    pi_repo: Path,
    out_dir: Path,
) -> pd.DataFrame:
    """Extract embedded source for every run whose log has it. Returns a
    DataFrame keyed by experiment_id with: recovered_path, sha256, source_bytes.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    t0 = time.time()
    n_total = len(runs_df)
    n_recovered = 0

    for i, (_, run) in enumerate(runs_df.iterrows(), 1):
        log_path = run.get("log_path")
        if not isinstance(log_path, str) or not log_path:
            continue
        full = pi_repo / log_path
        if not full.exists():
            continue
        source = extract_embedded_source(full)
        if source is None:
            continue

        sha = hashlib.sha256(source).hexdigest()
        run_id = run["run_id"]
        dest = out_dir / f"{run_id}.py"
        try:
            dest.write_bytes(source)
        except OSError:
            continue

        rows.append({
            "experiment_id": run_id,
            "recovered_path": str(dest.relative_to(out_dir.parent)) if out_dir.parent in dest.parents else str(dest),
            "sha256": sha,
            "source_bytes": len(source),
        })
        n_recovered += 1

        if i % 500 == 0:
            elapsed = time.time() - t0
            rate = i / elapsed if elapsed > 0 else 0
            print(f"  scanned {i:>5d}/{n_total} runs, recovered {n_recovered:>5d}  "
                  f"({rate:.0f}/s)")

    print(f"\nRecovered embedded source for {n_recovered:,} of {n_total:,} runs "
          f"({100*n_recovered/n_total:.0f}%)")
    return pd.DataFrame(rows)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m novelty_bench.indexer.extract_embedded_sources")
    p.add_argument("--pi-repo", required=True, type=Path,
                   help="Path to a cloned experiments-autonomous-speedrunning repo")
    p.add_argument("--data-root", type=Path, default=Path("data/out"))
    p.add_argument("--out-subdir", type=Path, default=Path("recovered_variants"),
                   help="Subdir under --data-root for recovered .py files")
    args = p.parse_args(argv)

    runs_path = args.data_root / "runs.parquet"
    if not runs_path.exists():
        print(f"error: {runs_path} not found. Run the indexer first.", file=sys.stderr)
        return 2

    runs_df = pd.read_parquet(runs_path)
    print(f"Loaded {len(runs_df):,} runs from {runs_path}")

    out_dir = args.data_root / args.out_subdir
    recovered_df = extract_all(runs_df=runs_df, pi_repo=args.pi_repo, out_dir=out_dir)

    parquet_path = args.data_root / "recovered_variant_sources.parquet"
    recovered_df.to_parquet(parquet_path, index=False)
    print(f"Wrote {len(recovered_df):,} recovered-source records -> {parquet_path}")
    print(f"  files at: {out_dir}")
    total_bytes = recovered_df["source_bytes"].sum() if len(recovered_df) else 0
    print(f"  total size: {total_bytes / 1024 / 1024:.1f} MB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
