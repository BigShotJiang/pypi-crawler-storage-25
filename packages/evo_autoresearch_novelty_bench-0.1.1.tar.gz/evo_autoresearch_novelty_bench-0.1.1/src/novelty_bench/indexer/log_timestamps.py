"""Extract launch timestamps from training log files.

Many runs (especially claude-code's, all of codex/v1's) don't have launched_at
in runs.jsonl. But every training log has one of these markers in the first
~30 lines:

  1. `### start_iso: 2026-04-29T19:22:39Z` or `### START_ISO=2026-05-02T15:42:04Z`
     — explicit ISO timestamp set by the launch wrapper. Most reliable.

  2. `W0429 19:22:41.795000 ... torch/distributed/run.py:852]`
     — pytorch's distributed launcher warning lines. Format is MMDD HH:MM:SS.us.
     Year is inferred from the dataset (2026).

This module reads only the first few KB of each log to avoid scanning the
whole file (some are megabytes). Returns log_basename → ISO timestamp string.
"""

from __future__ import annotations

import re
from pathlib import Path

# Pattern 1: explicit ISO marker in shell-script wrapper header
_ISO_RE = re.compile(
    r"###\s*start[_]?iso[:=\s]+(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?)Z?",
    re.IGNORECASE,
)

# Pattern 2: pytorch distributed launcher warning. e.g. "W0502 17:15:22.778000"
# The year isn't encoded — we assume the dataset year (2026).
_PT_W_RE = re.compile(r"^W(\d{2})(\d{2})\s+(\d{2}:\d{2}:\d{2})")

# Read only this many bytes from each log to find the marker
_HEAD_BYTES = 8192
# All Prime Intellect runs happened in 2026
_ASSUMED_YEAR = 2026


def extract_log_timestamp(log_path: str | Path) -> str | None:
    """Return ISO 8601 UTC timestamp string for a single log, or None."""
    p = Path(log_path)
    if not p.exists() or not p.is_file():
        return None
    try:
        with open(p, "rb") as f:
            head = f.read(_HEAD_BYTES).decode("utf-8", errors="replace")
    except OSError:
        return None

    # Try ISO marker first
    m = _ISO_RE.search(head)
    if m:
        return _normalize_iso(m.group(1))

    # Fall back to pytorch W-line scanner
    for line in head.splitlines():
        m = _PT_W_RE.match(line)
        if m:
            month = int(m.group(1))
            day = int(m.group(2))
            hms = m.group(3)
            return f"{_ASSUMED_YEAR}-{month:02d}-{day:02d}T{hms}+00:00"
    return None


def extract_all_log_timestamps(pi_repo: str | Path) -> dict[str, str]:
    """Walk every log in the PI repo, return {basename_without_ext: iso_ts}."""
    root = Path(pi_repo)
    out: dict[str, str] = {}
    for log_path in root.glob("*/*/scratchpad/runs/*.log"):
        ts = extract_log_timestamp(log_path)
        if ts is None:
            continue
        # Strip common log suffixes from basename to match runs.jsonl run_ids
        basename = log_path.name
        for suffix in (".console.log", ".sbatch.log", ".sbatch.out", ".log"):
            if basename.endswith(suffix):
                basename = basename[: -len(suffix)]
                break
        out[basename] = ts
    return out


def _normalize_iso(s: str) -> str:
    """Ensure trailing UTC offset for cleaner downstream parsing."""
    if s.endswith("Z"):
        return s[:-1] + "+00:00"
    if "+" in s or s.endswith("00:00"):
        return s
    return s + "+00:00"
