"""Parse each scratchpad's runs.jsonl into normalized Run records.

The runs.jsonl schema varies across (agent, wave) — different field names, different
structure (sometimes flat, sometimes nested with a `final` dict). This module normalizes
all variants into the Run schema. Outcomes that can't be parsed from runs.jsonl are left
as None; the training-log parser fills them later from the authoritative source.

Run IDs are derived from the run's identifier field when present, else from the log
basename, else (rarely) from the UUID. We deduplicate within a scratchpad on run_id.
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from .schema import Agent, Run, RunStatus, ScratchpadInventory, Wave

# Field-name unification: each normalized key maps to a list of legacy aliases in
# precedence order. The first found in the JSON line wins.
FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "run_id": ("run_id", "uuid"),
    "step_to_3_28": (
        "step_to_3_28",
        "step_to_target",
        "step_to_3.28",
        "first_step_le_3p28",
        "first_observed_step_le_3_28",
    ),
    "final_step": ("final_step", "train_steps", "total_steps", "last_step_logged"),
    "final_val_loss": ("final_val_loss",),
    "min_val_loss": ("min_val_loss", "best_val_loss"),
    "num_val_points": ("num_val_points",),
    "train_time_s": ("train_time_s",),
    "step_avg_ms": ("step_avg_ms",),
    "hit_target": ("hit_target",),
    "log_path": ("log_path", "log", "stdout_log", "path"),
    "variant_path": ("variant", "script"),
    "slurm_job_id": ("slurm_job_id", "slurm_job", "jobid"),
    "launched_at": ("time_utc", "time", "launched"),
    "status": ("status",),
}


def parse_runs_jsonl(inv: ScratchpadInventory) -> list[Run]:
    """Parse one scratchpad's runs.jsonl into Run records.

    Returns an empty list if the file doesn't exist or is empty. Malformed lines
    are skipped silently — runs.jsonl was the agent's own append log and sometimes
    contains partial writes during preemption.
    """
    if not inv.runs_jsonl:
        return []
    path = Path(inv.runs_jsonl)
    if not path.exists():
        return []

    runs: dict[str, Run] = {}
    with path.open("r", encoding="utf-8") as f:
        for raw_line in f:
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            try:
                row = json.loads(raw_line)
            except json.JSONDecodeError:
                continue

            run = _row_to_run(row, inv.agent, inv.wave)
            if run is None:
                continue
            # Last write wins — later entries for the same run_id supersede earlier ones,
            # which matches the agent's append-and-update pattern.
            runs[run.run_id] = run

    return list(runs.values())


def _row_to_run(row: dict[str, Any], agent: Agent, wave: Wave) -> Run | None:
    """Normalize one raw runs.jsonl row into a Run. Returns None if unsalvageable."""
    pick = lambda name: _pick(row, FIELD_ALIASES[name])

    # Some novelty/codex rows wrap outcomes in a nested `final` dict.
    final_dict = row.get("final") if isinstance(row.get("final"), dict) else {}

    log_path = pick("log_path")
    run_id = pick("run_id") or _run_id_from_log(log_path)
    if not run_id:
        return None

    variant_path = pick("variant_path")
    seed = _extract_seed(run_id, variant_path)

    step_to_3_28 = pick("step_to_3_28")
    final_step = pick("final_step") or final_dict.get("step") or final_dict.get("train_steps")
    final_val_loss = pick("final_val_loss") or final_dict.get("val_loss")
    min_val_loss = pick("min_val_loss")
    train_time_s = pick("train_time_s") or final_dict.get("train_time_s")

    hit_target = pick("hit_target")
    if hit_target is None and step_to_3_28 is not None:
        # If a step_to_target was logged, the run hit the target by definition.
        hit_target = True

    launched_at = _parse_dt(pick("launched_at"))
    status = _parse_status(pick("status"))

    return Run(
        run_id=str(run_id),
        agent=agent,
        wave=wave,
        launched_at=launched_at,
        variant_path=_normalize_scratchpad_path(variant_path, agent, wave, "variants"),
        log_path=_normalize_scratchpad_path(log_path, agent, wave, "runs") or "",
        final_val_loss=_as_float(final_val_loss),
        min_val_loss=_as_float(min_val_loss),
        step_to_3_28=_as_int(step_to_3_28),
        final_step=_as_int(final_step),
        train_time_s=_as_float(train_time_s),
        step_avg_ms=_as_float(pick("step_avg_ms")),
        num_val_points=_as_int(pick("num_val_points")),
        hit_target=bool(hit_target) if hit_target is not None else None,
        status=status,
        seed=seed,
    )


# Match a trailing `-s<digits>`, `-seed<digits>`, `_s<digits>`, or `_seed<digits>` in slug
_SEED_RE = re.compile(r"[-_](?:s|seed)(\d+)(?=$|\.|[-_])", re.IGNORECASE)


def _extract_seed(run_id: str | None, variant_path: str | None) -> int | None:
    """Parse the seed integer from a run_id or variant filename. Looks for
    `-sN`, `-seedN`, `_sN`, `_seedN` patterns. Returns None when not present."""
    for candidate in (run_id, variant_path):
        if not candidate:
            continue
        m = _SEED_RE.search(str(candidate))
        if m:
            try:
                return int(m.group(1))
            except ValueError:
                continue
    return None


def _pick(row: dict[str, Any], aliases: tuple[str, ...]) -> Any:
    for key in aliases:
        if key in row and row[key] is not None:
            return row[key]
    return None


def _run_id_from_log(log_path: Any) -> str | None:
    """Derive a run_id from a log path's basename (without extensions)."""
    if not log_path or not isinstance(log_path, str):
        return None
    name = Path(log_path).name
    # Strip common suffixes: .log, .console.log, .sbatch.log, .out
    for suffix in (".console.log", ".sbatch.log", ".sbatch.out", ".log", ".txt", ".out"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
            break
    return name or None


def _normalize_scratchpad_path(path: Any, agent: Agent, wave: Wave, subdir: str) -> str | None:
    """Map any flavor of variant/log path to `{wave}/{agent}/scratchpad/{subdir}/{basename}`.

    PI's runs.jsonl carries paths from many sources:
      - /beegfs/elie/<agent-rundir>/records/track_3_optimization/ai/scratchpad/...
      - records/track_3_optimization/ai/scratchpad/...
      - scratchpad/variants/foo.py
      - foo.py
    All have the same basename within the wave/agent scratchpad. The actual file
    in our repo checkout always lives at `{wave}/{agent}/scratchpad/{subdir}/{basename}`,
    so we collapse to that canonical form. Downstream consumers (build_workspace,
    embeddings) can join with --pi-repo to get the absolute path.
    """
    if not path or not isinstance(path, str):
        return None
    basename = Path(path).name
    if not basename:
        return None
    return f"{wave.value}/{agent.value}/scratchpad/{subdir}/{basename}"


def _parse_dt(value: Any) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    if not isinstance(value, str):
        return None
    # Try ISO 8601 first
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        pass
    # Then YYYY-MM-DD
    try:
        return datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        return None


def _parse_status(value: Any) -> RunStatus:
    if value is None:
        return RunStatus.UNKNOWN
    s = str(value).strip().lower()
    # Novelty/codex uses "0" / nonzero for exit codes
    if s == "0":
        return RunStatus.COMPLETED
    if s.isdigit():
        return RunStatus.FAILED
    if s in ("completed", "ok", "success", "done"):
        return RunStatus.COMPLETED
    if s in ("preempted",):
        return RunStatus.PREEMPTED
    if s in ("failed", "error"):
        return RunStatus.FAILED
    if s in ("canceled", "cancelled"):
        return RunStatus.CANCELED
    if s in ("timeout", "timed_out"):
        return RunStatus.TIMEOUT
    return RunStatus.UNKNOWN


def _as_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _as_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return None
