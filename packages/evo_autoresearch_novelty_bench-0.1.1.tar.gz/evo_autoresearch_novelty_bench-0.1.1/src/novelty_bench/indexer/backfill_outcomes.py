"""Backfill missing run outcomes from val trajectories.

Some scratchpads' runs.jsonl files are launch-only (e.g. claude-code/v3 records
just `{run_id, script, slurm_job, variant, launched, purpose}` — no outcomes).
For those runs the indexer ends up with step_to_3_28 / final_val_loss / min_val_loss
all None, even though the training logs were parsed successfully and we have
the validation trajectory.

This module fills in the outcome fields from the trajectories themselves:
  - step_to_3_28 = step of first val checkpoint with val_loss <= TARGET
  - final_val_loss = val_loss at the latest checkpoint
  - min_val_loss = lowest val_loss across all checkpoints
  - num_val_points = number of checkpoints

Already-populated fields are left alone — we only fill in Nones.
"""

from __future__ import annotations

from collections import defaultdict

from .schema import Run, RunStatus, ValCheckpoint

TARGET_VAL_LOSS = 3.28
# Heuristic: runs whose val trajectory has at least this many checkpoints ran
# long enough to be considered "completed" (val cadence is ~125 steps, so 20
# checkpoints ≈ 2500 trained steps — substantially most of any submitted run).
COMPLETED_MIN_CHECKPOINTS = 20


def backfill_run_outcomes(runs: list[Run], val_checkpoints: list[ValCheckpoint]) -> int:
    """Mutate Run records in place: derive missing outcome fields from val_checkpoints.

    Returns the number of runs that had at least one field backfilled.
    """
    by_run: dict[str, list[ValCheckpoint]] = defaultdict(list)
    for ck in val_checkpoints:
        by_run[ck.run_id].append(ck)
    # Ensure each run's checkpoints are sorted by step
    for ck_list in by_run.values():
        ck_list.sort(key=lambda c: c.step)

    backfilled = 0
    for run in runs:
        cks = by_run.get(run.run_id)
        if not cks:
            continue
        touched = False

        # step_to_3_28: first checkpoint with val_loss <= TARGET
        if run.step_to_3_28 is None:
            for ck in cks:
                if ck.val_loss <= TARGET_VAL_LOSS:
                    run.step_to_3_28 = ck.step
                    if run.hit_target is None:
                        run.hit_target = True
                    touched = True
                    break

        # final_val_loss: last checkpoint
        if run.final_val_loss is None:
            run.final_val_loss = cks[-1].val_loss
            touched = True

        # min_val_loss: min across all checkpoints
        if run.min_val_loss is None:
            run.min_val_loss = min(ck.val_loss for ck in cks)
            touched = True

        # num_val_points
        if run.num_val_points is None:
            run.num_val_points = len(cks)
            touched = True

        # final_step
        if run.final_step is None:
            run.final_step = cks[-1].step
            touched = True

        # train_time_s, step_avg_ms — from the last checkpoint
        if run.train_time_s is None:
            run.train_time_s = cks[-1].train_time_s
            touched = True
        if run.step_avg_ms is None:
            run.step_avg_ms = cks[-1].step_avg_ms
            touched = True

        if touched:
            backfilled += 1

    return backfilled


def derive_run_status(runs: list[Run], val_checkpoints: list[ValCheckpoint]) -> int:
    """For runs whose status is UNKNOWN, derive a better label.

    Rules:
      - If step_to_3_28 is set → COMPLETED (run hit target; it ran)
      - Else if val_trajectory has ≥ COMPLETED_MIN_CHECKPOINTS → COMPLETED
        (ran long enough to be a real attempt, just didn't hit target)
      - Else if val_trajectory has 1..(COMPLETED_MIN_CHECKPOINTS-1) → PREEMPTED
        (cut short before finishing)
      - Else → leave as UNKNOWN
    """
    by_run: dict[str, int] = defaultdict(int)
    for ck in val_checkpoints:
        by_run[ck.run_id] += 1

    derived = 0
    for run in runs:
        if run.status is not RunStatus.UNKNOWN:
            continue
        cks = by_run.get(run.run_id, 0)
        if run.step_to_3_28 is not None:
            run.status = RunStatus.COMPLETED
            derived += 1
        elif cks >= COMPLETED_MIN_CHECKPOINTS:
            run.status = RunStatus.COMPLETED
            derived += 1
        elif cks > 0:
            run.status = RunStatus.PREEMPTED
            derived += 1
    return derived
