"""Combine all rejection signals into Idea.rejection_class.

Four signals, priority order (most-explicit wins):

  existence_killed     # idea was killed by an arXiv existence check (novelty wave)
  audit_noncompliant   # idea was found to violate benchmark hard rules
  family_ruled_out     # idea's family hit the stuck-detector (30 consecutive non-improvements)
  failed               # idea was tried; verdict in {regressed, failed_to_run}
  none                 # default

If multiple signals apply, the highest-priority one wins. Evidence text is
preserved from whatever signal won.
"""

from __future__ import annotations

import re
from collections import defaultdict

import pandas as pd

from .parse_rejections import RejectionRecord
from .schema import Agent, Idea, RejectionClass, Verdict, Wave

# Patterns that indicate an idea writeup was killed by the novelty existence check.
# Conservative — only fires on explicit "killed by existence check" wording.
_EXISTENCE_KILL_PATTERNS = (
    re.compile(r"killed by existence check", re.IGNORECASE),
    re.compile(r"killed.*existence.*check", re.IGNORECASE),
    re.compile(r"existence check.*killed", re.IGNORECASE),
)


def apply_rejections(
    ideas: list[Idea],
    audit_records: dict[tuple[Agent, Wave, str], RejectionRecord],
    family_rule_outs: dict[tuple[Agent, Wave, str], int],
) -> None:
    """Set Idea.rejection_class + rejection_evidence_text + rejected_at_position in place.

    Priority order (later overrides earlier):
      1. failed  (from Verdict)
      2. family_ruled_out  (from stuck detector)
      3. audit_noncompliant  (from audits.md / rule_checks)
      4. existence_killed  (from idea text)
    """
    for idea in ideas:
        rclass, evidence, at_position = _classify(idea, audit_records, family_rule_outs)
        idea.rejection_class = rclass
        idea.rejection_evidence_text = evidence
        idea.rejected_at_position = at_position


def _classify(
    idea: Idea,
    audit_records: dict[tuple[Agent, Wave, str], RejectionRecord],
    family_rule_outs: dict[tuple[Agent, Wave, str], int],
) -> tuple[RejectionClass, str | None, int | None]:
    rclass = RejectionClass.NONE
    evidence: str | None = None
    at_pos: int | None = None

    # Lowest priority: failed verdict
    if idea.verdict in (Verdict.REGRESSED, Verdict.FAILED_TO_RUN):
        rclass = RejectionClass.FAILED
        evidence = f"Run outcome verdict: {idea.verdict.value}"
        at_pos = idea.position

    # Family ruled out
    key = (idea.agent, idea.wave, idea.idea_id)
    if key in family_rule_outs:
        rclass = RejectionClass.FAMILY_RULED_OUT
        evidence = (
            f"Family's slug prefix exceeded 30 consecutive runs without "
            f"step_to_target improvement (stuck detector triggered at run "
            f"index {family_rule_outs[key]})."
        )
        at_pos = idea.position  # we don't precisely map run-index to position; use idea's

    # Audit non-compliant
    rec = audit_records.get(key)
    if rec is not None and "NON-COMPLIANT" in rec.verdict.upper():
        rclass = RejectionClass.AUDIT_NONCOMPLIANT
        evidence = rec.evidence_text
        at_pos = idea.position

    # Existence killed (top priority)
    if _check_existence_killed(idea):
        rclass = RejectionClass.EXISTENCE_KILLED
        evidence = "Idea writeup marked as killed by existence check (arXiv prior art found)."
        at_pos = idea.position

    return rclass, evidence, at_pos


def _check_existence_killed(idea: Idea) -> bool:
    """Scan the idea's text for explicit existence-check-killed markers."""
    text = (idea.proposal_text or "") + " " + (idea.novelty_rationale or "")
    if not text:
        return False
    for pattern in _EXISTENCE_KILL_PATTERNS:
        if pattern.search(text):
            return True
    return False


def summarize_rejections(ideas: list[Idea]) -> dict[str, int]:
    """Count ideas per rejection_class for reporting."""
    counts: dict[str, int] = defaultdict(int)
    for idea in ideas:
        counts[idea.rejection_class.value] += 1
    return dict(counts)
