"""Augment run-to-idea linking using THREAD.md cross-references.

The agent's THREAD.md often mentions runs and ideas together in the same line
or paragraph. Examples:

    "SPM (8720) at step 2000: val 3.71 vs baseline 3.42 ..."
    "Launched ema-start2000-decay0995-seed0 for the EMA endgame weights idea..."
    "muon-spm-K4-kd5-ks2-s1 hit at step 3375"

For each agent×wave:
  1. Walk THREAD.md line by line.
  2. On each line, find every match-key reference (idea_id, alias, code-prefix).
  3. On each line, find run-id-like tokens (`<slug>-s\\d+`, `<slug>-r\\d+`, etc.).
  4. If a line has exactly one (or a clearly-dominant) idea reference and one or
     more run-id tokens, link those runs to that idea.

Returns: {(agent, wave, run_id): idea_id} mapping. Used by the linker as a
supplementary signal that overrides weak-substring matches.
"""

from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path
from typing import Iterable

from .abbreviations import extract_aliases_for_idea
from .schema import Agent, Idea, ScratchpadInventory, Wave

# A run-id-like token: contains a `-` or `_`, ends with `-s\d+` / `-r\d+` /
# `-seed\d+` / `-jobid` patterns common in the agents' naming.
_RUN_ID_TOKEN_RE = re.compile(r"\b([a-z][a-z0-9]*(?:[-_][a-z0-9]+){1,8}-(?:s|r|seed)\d+)\b")

# A bareword-with-hyphens that could also be a run_id (no seed suffix).
_LOOSE_RUN_ID_RE = re.compile(r"\b([a-z][a-z0-9]*(?:[-_][a-z0-9]+){2,8})\b")


def thread_walk_links(
    inv: ScratchpadInventory,
    ideas: list[Idea],
    known_run_ids: set[str],
) -> dict[str, str]:
    """Parse THREAD.md and infer run-id → idea-id links.

    Returns {run_id: idea_id} for runs in `known_run_ids` that we could link.
    """
    if not inv.thread_md:
        return {}
    thread_path = Path(inv.thread_md)
    if not thread_path.exists():
        return {}
    text = thread_path.read_text(encoding="utf-8", errors="replace")

    # Build the lookup: every alias / match-key → idea_id, longest first.
    key_to_idea: list[tuple[str, str]] = []
    for idea in ideas:
        keys = {_normalize(idea.idea_id)}
        first = _first_token(idea.idea_id)
        if first and any(c.isdigit() for c in first):
            keys.add(_normalize(first))
        for alias in extract_aliases_for_idea(idea.idea_id, idea.title, idea.proposal_text):
            keys.add(alias)
        for key in keys:
            if len(key) >= 3:
                key_to_idea.append((idea.idea_id, key))
    key_to_idea.sort(key=lambda p: -len(p[1]))

    # Walk THREAD line by line.
    out: dict[str, str] = {}
    for line in text.splitlines():
        lowered = line.lower()
        ideas_on_line = _ideas_referenced(lowered, key_to_idea)
        if not ideas_on_line:
            continue

        # If exactly one idea is referenced, attribute all run tokens on this line to it.
        # If multiple, attribute only when one CLEARLY dominates (occurrence count).
        if len(ideas_on_line) == 1:
            target_idea = next(iter(ideas_on_line))
        else:
            sorted_ids = sorted(ideas_on_line.items(), key=lambda p: -p[1])
            if sorted_ids[0][1] >= 2 and sorted_ids[0][1] > sorted_ids[1][1]:
                target_idea = sorted_ids[0][0]
            else:
                continue

        for token in _run_tokens_on_line(line):
            if token in known_run_ids and token not in out:
                out[token] = target_idea
    return out


def _ideas_referenced(lowered_line: str, key_to_idea: list[tuple[str, str]]) -> dict[str, int]:
    """Count idea references on a line.

    A reference fires when a match key appears as a whole-word substring of the
    line (after normalization). Returns {idea_id: count}.
    """
    counts: dict[str, int] = defaultdict(int)
    seen_positions: set[tuple[str, int]] = set()  # avoid double-counting same idea via overlapping keys

    # Normalize the line by stripping non-alphanumerics for substring search,
    # while preserving original positions for dedup.
    normalized_line = "".join(ch if ch.isalnum() else " " for ch in lowered_line)

    for idea_id, key in key_to_idea:
        pos = 0
        while True:
            idx = normalized_line.find(key, pos)
            if idx < 0:
                break
            # Require word boundary (preceded/followed by non-alpha or start/end)
            before_ok = idx == 0 or not normalized_line[idx - 1].isalnum()
            end = idx + len(key)
            after_ok = end >= len(normalized_line) or not normalized_line[end].isalnum()
            if before_ok and after_ok:
                if (idea_id, idx) not in seen_positions:
                    counts[idea_id] += 1
                    seen_positions.add((idea_id, idx))
            pos = idx + 1
    return dict(counts)


def _run_tokens_on_line(line: str) -> Iterable[str]:
    """Extract run-id-like tokens from a line. Prefer ones with -s\\d+ suffix."""
    yielded: set[str] = set()
    # Strict run ids first
    for m in _RUN_ID_TOKEN_RE.finditer(line.lower()):
        token = m.group(1)
        if token not in yielded:
            yielded.add(token)
            yield token
    # Loose tokens for things like "ema-start2000-decay0995-seed0"
    for m in _LOOSE_RUN_ID_RE.finditer(line.lower()):
        token = m.group(1)
        if token not in yielded:
            yielded.add(token)
            yield token


def _normalize(s: str) -> str:
    return "".join(ch for ch in s.lower() if ch.isalnum())


def _first_token(s: str) -> str:
    out: list[str] = []
    for ch in s:
        if ch.isalnum():
            out.append(ch)
        elif out:
            break
    return "".join(out)


def collect_thread_walk_links(
    inventories: list[ScratchpadInventory],
    ideas: list[Idea],
    runs_by_scope: dict[tuple[Agent, Wave], list],
) -> dict[tuple[Agent, Wave, str], str]:
    """Apply thread_walk_links across all scratchpads."""
    ideas_by_scope: dict[tuple[Agent, Wave], list[Idea]] = defaultdict(list)
    for idea in ideas:
        ideas_by_scope[(idea.agent, idea.wave)].append(idea)

    out: dict[tuple[Agent, Wave, str], str] = {}
    for inv in inventories:
        scope_ideas = ideas_by_scope.get((inv.agent, inv.wave), [])
        if not scope_ideas:
            continue
        scope_runs = runs_by_scope.get((inv.agent, inv.wave), [])
        known_run_ids = {r.run_id for r in scope_runs if r.run_id}
        if not known_run_ids:
            continue
        links = thread_walk_links(inv, scope_ideas, known_run_ids)
        for run_id, idea_id in links.items():
            out[(inv.agent, inv.wave, run_id)] = idea_id
    return out
