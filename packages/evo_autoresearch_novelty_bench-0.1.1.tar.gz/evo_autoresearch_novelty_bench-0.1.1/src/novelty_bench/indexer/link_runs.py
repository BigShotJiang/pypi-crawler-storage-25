"""Link Run records to Idea records via slug matching on filenames.

Naming conventions vary widely across (agent, wave):

- codex/novelty: idea filenames carry the full description, but variants/logs use
  only the 3-letter+3-digit code prefix (`abp001_alpha001_*` corresponds to
  `abp001_adam_biproduct_polar_muon.md`). Matched via the leading-code key.
- codex/v1: variants encode the whole modifier stack
  (`normuon-b090to080-mlpprojlr124375-adabeliefopt1-...`). The new idea is the
  most recent modifier; abbreviations like `adabeliefopt1` for `adabelief-optimizer1`
  would need fuzzy matching, which this linker doesn't do.
- codex/v2/v3: variants like `pmi02_ts3000.py`, `v3_aurora1_rolelr2_lookahead_ts3037.py`.
- claude-code/v1: runs typically have no variant_path; we fall back to log basename.
- claude-code/v3: variant_path is just `v15` (version marker); most v3 runs are
  not linkable from filename alone.

Matcher does three things per idea:
1. Build the full normalized idea_id as one match key.
2. If the idea_id starts with a code-like token (alphanumeric containing digits),
   add that token as a separate match key — handles the codex/novelty case.
3. Sort match keys by length descending so the most specific match wins.

For each run, three candidate slugs are tried: the variant basename, the run_id,
and the log basename. We keep the longest match across all (candidate, key) pairs.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from .abbreviations import extract_aliases_for_idea
from .schema import Agent, Idea, Run, Wave

# A match is "kept" only if at least this many chars line up. Avoids false matches
# on short common prefixes like "v1", "v15", "adam".
_MIN_MATCH_LEN = 4


@dataclass
class LinkStats:
    agent: Agent
    wave: Wave
    total_runs: int
    linked_runs: int
    unique_ideas_linked: int

    @property
    def link_rate(self) -> float:
        return self.linked_runs / max(1, self.total_runs)


def link_runs_to_ideas(
    runs: list[Run],
    ideas: list[Idea],
    external_links: dict[tuple[Agent, Wave, str], str] | None = None,
) -> list[LinkStats]:
    """Set Run.idea_id in place for every run that finds a match.

    `external_links`, if provided, is consulted FIRST (highest priority) — used to
    feed in matches from THREAD-walking or LLM-based matchers. Whatever it doesn't
    cover falls through to the heuristic prefix/substring matcher.

    Returns per-scratchpad stats.
    """
    # Group ideas by (agent, wave) for fast per-scratchpad lookup
    ideas_by_scope: dict[tuple[Agent, Wave], list[Idea]] = defaultdict(list)
    for idea in ideas:
        ideas_by_scope[(idea.agent, idea.wave)].append(idea)

    runs_by_scope: dict[tuple[Agent, Wave], list[Run]] = defaultdict(list)
    for run in runs:
        runs_by_scope[(run.agent, run.wave)].append(run)

    # First pass: external links (highest authority)
    if external_links:
        external_linked = 0
        for run in runs:
            key = (run.agent, run.wave, run.run_id)
            if key in external_links:
                run.idea_id = external_links[key]
                external_linked += 1
        # Heuristic pass only fills in what external didn't cover.

    stats: list[LinkStats] = []
    for scope, scope_runs in runs_by_scope.items():
        scope_ideas = ideas_by_scope.get(scope, [])
        if not scope_ideas:
            stats.append(LinkStats(scope[0], scope[1], len(scope_runs), 0, 0))
            continue
        # Only run heuristic on runs still unlinked after external pass
        unlinked = [r for r in scope_runs if not r.idea_id]
        _link_within_scope(unlinked, scope_ideas)
        linked = sum(1 for r in scope_runs if r.idea_id)
        stats.append(
            LinkStats(
                agent=scope[0],
                wave=scope[1],
                total_runs=len(scope_runs),
                linked_runs=linked,
                unique_ideas_linked=len({r.idea_id for r in scope_runs if r.idea_id}),
            )
        )
    return stats


def _link_within_scope(scope_runs: list[Run], scope_ideas: list[Idea]) -> int:
    """Link runs to ideas within a single (agent, wave). Returns linked count."""
    # Build a lookup: list of (idea_id, match_key) pairs. Each idea contributes
    # at least its full normalized id, plus any code-prefix keys.
    pairs: list[tuple[str, str]] = []
    for idea in scope_ideas:
        for key in _idea_match_keys(idea):
            if len(key) >= _MIN_MATCH_LEN:
                pairs.append((idea.idea_id, key))

    # Sort by key length descending so longer (more specific) keys win when
    # multiple ideas match the same candidate.
    pairs.sort(key=lambda p: -len(p[1]))

    linked_count = 0
    for run in scope_runs:
        match_id = _find_best_match(run, pairs)
        if match_id is not None:
            run.idea_id = match_id
            linked_count += 1
    return linked_count


def _idea_match_keys(idea: Idea) -> list[str]:
    """Generate match keys for an idea.

    Always includes the full normalized idea_id. Additionally:
    - The first token if it contains digits (catches codex/novelty's `abp001`
      pattern where idea_id = `<code>_<full_desc>` and variants reference `<code>`).
    - All abbreviation aliases extracted from the idea writeup (catches
      claude-code/novelty's `acn`/`arm`/`spm`/`agmuon` patterns).
    """
    keys = [_normalize(idea.idea_id)]
    first_token = _first_token(idea.idea_id)
    if first_token and any(c.isdigit() for c in first_token):
        keys.append(_normalize(first_token))
    # Pull abbreviation aliases from the idea writeup
    aliases = extract_aliases_for_idea(idea.idea_id, idea.title, idea.proposal_text)
    keys.extend(aliases)
    return keys


def _first_token(s: str) -> str:
    """Return the first run of alphanumerics in the string."""
    out: list[str] = []
    for ch in s:
        if ch.isalnum():
            out.append(ch)
        elif out:
            break
    return "".join(out)


def _find_best_match(run: Run, key_pairs: list[tuple[str, str]]) -> str | None:
    """Try multiple slug candidates from the run, find the longest match key.
    Returns the original idea_id, or None if no candidate meets the threshold."""
    candidates = _slug_candidates(run)
    if not candidates:
        return None

    best_id: str | None = None
    best_len = _MIN_MATCH_LEN - 1  # require strictly more than this

    for cand in candidates:
        cand_norm = _normalize(cand)
        if not cand_norm:
            continue
        for original_id, key in key_pairs:
            # Two acceptable shapes:
            # 1. Candidate STARTS with key (key is the head of the variant slug)
            # 2. Candidate CONTAINS key (key is a modifier embedded in the slug)
            # Prefix is preferred; substring requires a longer key to avoid noise.
            if cand_norm.startswith(key) and len(key) > best_len:
                best_len = len(key)
                best_id = original_id
            elif (
                key in cand_norm
                and len(key) > best_len
                and len(key) >= _MIN_MATCH_LEN + 2
            ):
                best_len = len(key)
                best_id = original_id
    return best_id


def _slug_candidates(run: Run) -> list[str]:
    """Pull every slug-like string from a run for matching against idea IDs."""
    candidates: list[str] = []
    if run.variant_path:
        name = Path(run.variant_path).name
        # Strip common prefix used by the modded-nanogpt convention
        for prefix in ("train_gpt_simple_", "legal_"):
            if name.startswith(prefix):
                name = name[len(prefix) :]
                break
        # Strip .py suffix
        if name.endswith(".py"):
            name = name[:-3]
        if name:
            candidates.append(name)
    if run.run_id:
        candidates.append(run.run_id)
    if run.log_path:
        log_name = Path(run.log_path).stem
        if log_name and log_name not in candidates:
            candidates.append(log_name)
    return candidates


def _normalize(s: str) -> str:
    """Lowercase, keep only alphanumerics. Aggressive — drops dashes, underscores,
    dots, slashes, all whitespace. Two strings that differ only in separators
    collapse to the same form."""
    return "".join(ch for ch in s.lower() if ch.isalnum())
