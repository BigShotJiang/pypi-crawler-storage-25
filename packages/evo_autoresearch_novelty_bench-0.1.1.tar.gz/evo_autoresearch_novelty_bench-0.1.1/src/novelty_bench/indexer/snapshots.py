"""Build snapshots.parquet — agent-visible states the judge scores against.

A snapshot is "the world as the agent saw it at wall_clock T in (agent, wave)".
We sort each scope's experiments by first_seen_at and pick K wall-clock anchors
at time percentiles. Every filter (prior_*, future_*, rejected_*, other_agent_*)
is a time comparison against that wall_clock.

Snapshots pivot on EXPERIMENTS (every research attempt = one Run). All 8 scopes
have substantial real-timestamp coverage (~99.5%), so all are viable here.
Previously snapshots pivoted on PROPOSALS (variant.py files), which had broken
per-row timestamps for claude-code/* and codex/v1.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Iterable

import pandas as pd

from .schema import Agent, Snapshot, Wave

DEFAULT_PERCENTILES = (10, 30, 50, 70, 90)
MIN_SCOPE_SIZE = 20

WAVE_CONSTRAINTS: dict[str, str] = {
    "v1": (
        "Open exploration: any optimizer / loss / init / regularizer change is "
        "fair game. Must beat Muon-3500 baseline (val_loss<=3.28 in <3500 steps) "
        "to count as improvement."
    ),
    "novelty": (
        "Mechanism must not have been tried before in this scratchpad. Include "
        "an Existence Check section that searches prior ideas and prior_art. "
        "Match-then-extend is allowed only if the extension is mechanistically "
        "distinct."
    ),
    "v2": (
        "Build on the v1 frontier. Mutations and compositions of validated "
        "recipes preferred over from-scratch redesigns."
    ),
    "v3": (
        "Slug-stack at most 3 levels deep: a v3 variant may compose at most 3 "
        "validated v2 ideas before requiring fresh justification. Continue from "
        "the v2 frontier."
    ),
}


def _percentile_pivots(times: pd.Series, percentiles: Iterable[int]) -> list[pd.Timestamp]:
    if len(times) == 0:
        return []
    sorted_times = times.sort_values().reset_index(drop=True)
    n = len(sorted_times)
    seen: set[pd.Timestamp] = set()
    picks: list[pd.Timestamp] = []
    for p in percentiles:
        idx = max(0, min(n - 1, round((p / 100.0) * (n - 1))))
        t = sorted_times.iloc[idx]
        if t not in seen:
            seen.add(t)
            picks.append(t)
    return picks


def _compute_idea_first_seen(experiments_df: pd.DataFrame) -> pd.Series:
    """For each linked idea, earliest first_seen_at across its experiments."""
    valid = experiments_df.dropna(subset=["first_seen_at", "linked_idea_id"]).copy()
    if valid.empty:
        return pd.Series(dtype="datetime64[ns, UTC]")
    valid["first_seen_at"] = pd.to_datetime(
        valid["first_seen_at"], utc=True, format="ISO8601"
    )
    return valid.groupby("linked_idea_id")["first_seen_at"].min()


def _current_recipe_for(prior_experiments: pd.DataFrame) -> tuple[str | None, int | None]:
    improved = prior_experiments[
        (prior_experiments["verdict"] == "improved")
        & (prior_experiments["step_to_3_28"].notna())
    ]
    if len(improved) == 0:
        return None, None
    ranked = improved.sort_values(
        ["first_seen_at", "step_to_3_28"], ascending=[False, True]
    )
    row = ranked.iloc[0]
    return row["experiment_id"], int(row["step_to_3_28"])


def build_snapshots(
    ideas_df: pd.DataFrame,
    experiments_df: pd.DataFrame,
    *,
    percentiles: Iterable[int] = DEFAULT_PERCENTILES,
    min_scope_size: int = MIN_SCOPE_SIZE,
) -> list[Snapshot]:
    """Pick time-anchored snapshots across all (agent, wave) scopes."""
    idea_first_seen = _compute_idea_first_seen(experiments_df)
    experiments_df = experiments_df.copy()
    experiments_df["first_seen_at"] = pd.to_datetime(
        experiments_df["first_seen_at"], utc=True, errors="coerce", format="ISO8601"
    )

    out: list[Snapshot] = []
    skipped: list[tuple[str, str, str]] = []
    for (agent, wave), scope in experiments_df.groupby(["agent", "wave"]):
        timed = scope.dropna(subset=["first_seen_at"]).copy()
        if len(timed) < min_scope_size:
            skipped.append((agent, wave, f"size={len(timed)}<{min_scope_size}"))
            continue

        scope_ideas = ideas_df[
            (ideas_df["agent"] == agent) & (ideas_df["wave"] == wave)
        ].copy()
        scope_ideas["_first_seen"] = scope_ideas["idea_id"].map(idea_first_seen)
        scope_ideas["_first_seen"] = scope_ideas["_first_seen"].fillna(
            pd.to_datetime(scope_ideas["timestamp"], utc=True, errors="coerce", format="ISO8601")
        )

        other_agent = "claude-code" if agent == "codex" else "codex"
        other_scope_ideas = ideas_df[
            (ideas_df["agent"] == other_agent) & (ideas_df["wave"] == wave)
        ].copy()
        other_scope_ideas["_first_seen"] = other_scope_ideas["idea_id"].map(idea_first_seen)
        other_scope_ideas["_first_seen"] = other_scope_ideas["_first_seen"].fillna(
            pd.to_datetime(other_scope_ideas["timestamp"], utc=True, errors="coerce", format="ISO8601")
        )
        other_scope_exps = experiments_df[
            (experiments_df["agent"] == other_agent) & (experiments_df["wave"] == wave)
        ]

        pivots = _percentile_pivots(timed["first_seen_at"], percentiles)
        for wall_clock in pivots:
            k = int((timed["first_seen_at"] <= wall_clock).sum())
            snap = _build_one(
                agent=agent, wave=wave, k=k, wall_clock=wall_clock,
                scope_ideas=scope_ideas,
                scope_experiments=timed,
                other_scope_ideas=other_scope_ideas,
                other_scope_experiments=other_scope_exps,
            )
            out.append(snap)

    if skipped:
        for a, w, reason in skipped:
            print(f"  skipping {a}/{w} ({reason})")
    _assign_splits(out)
    return out


def _build_one(
    *,
    agent: str,
    wave: str,
    k: int,
    wall_clock: pd.Timestamp,
    scope_ideas: pd.DataFrame,
    scope_experiments: pd.DataFrame,
    other_scope_ideas: pd.DataFrame,
    other_scope_experiments: pd.DataFrame,
) -> Snapshot:
    cutoff = pd.Timestamp(wall_clock)

    prior_exps = scope_experiments[scope_experiments["first_seen_at"] <= cutoff]
    future_exps = scope_experiments[scope_experiments["first_seen_at"] > cutoff]

    prior_ideas = scope_ideas[scope_ideas["_first_seen"] <= cutoff]
    future_ideas = scope_ideas[scope_ideas["_first_seen"] > cutoff]

    current_recipe_id, current_recipe_step = _current_recipe_for(prior_exps)

    future_frontier_idea_ids = (
        future_ideas[future_ideas["on_frontier_walk"] == True]["idea_id"].tolist()  # noqa: E712
    )
    future_improved_idea_ids = future_ideas[future_ideas["verdict"] == "improved"][
        "idea_id"
    ].tolist()
    future_improved_experiment_ids = future_exps[future_exps["verdict"] == "improved"][
        "experiment_id"
    ].tolist()
    future_frontier_experiment_ids = future_exps[
        future_exps["step_to_3_28"].notna() & (future_exps["step_to_3_28"] < 3500)
    ]["experiment_id"].tolist()

    rejected_idea_ids = prior_ideas[prior_ideas["rejection_class"] != "none"][
        "idea_id"
    ].tolist()

    other_visible_ideas = other_scope_ideas[other_scope_ideas["_first_seen"] < cutoff]
    other_exp_ts = pd.to_datetime(
        other_scope_experiments["first_seen_at"], utc=True, errors="coerce", format="ISO8601"
    )
    other_visible_exps = other_scope_experiments[other_exp_ts < cutoff]

    return Snapshot(
        snapshot_id=f"snap_{agent}_{wave}_k{k:04d}",
        agent=Agent(agent),
        wave=Wave(wave),
        k=k,
        wall_clock=cutoff.to_pydatetime(),
        split="test",
        wave_constraint=WAVE_CONSTRAINTS.get(wave, ""),
        current_recipe_experiment_id=current_recipe_id,
        current_recipe_step_to_3_28=current_recipe_step,
        prior_idea_ids=prior_ideas["idea_id"].tolist(),
        prior_experiment_ids=prior_exps["experiment_id"].tolist(),
        future_frontier_idea_ids=future_frontier_idea_ids,
        future_improved_idea_ids=future_improved_idea_ids,
        future_improved_experiment_ids=future_improved_experiment_ids,
        future_frontier_experiment_ids=future_frontier_experiment_ids,
        rejected_idea_ids=rejected_idea_ids,
        other_agent_visible_idea_ids=other_visible_ideas["idea_id"].tolist(),
        other_agent_visible_experiment_ids=other_visible_exps["experiment_id"].tolist(),
    )


def _assign_splits(snapshots: list[Snapshot]) -> None:
    by_scope: dict[tuple[Agent, Wave], list[Snapshot]] = defaultdict(list)
    for s in snapshots:
        by_scope[(s.agent, s.wave)].append(s)
    for scope_list in by_scope.values():
        scope_list.sort(key=lambda s: s.k)
        for i, s in enumerate(scope_list):
            s.split = "dev" if (i % 4 == 0) else "test"
