"""Walk the Prime Intellect speedrun repo and discover scratchpad contents.

The PI repo structure is:

    <root>/
      v1/{claude-code,codex}/scratchpad/...
      novelty/{claude-code,codex}/scratchpad/...
      v2/{claude-code,codex}/scratchpad/...
      v3/{claude-code,codex}/scratchpad/...

Each scratchpad contains a mix of: THREAD.md, runs.jsonl, ideas/, papers/, variants/,
runs/ (training logs), audits.md, picklist.md, rule_checks/ (novelty wave). Not every
file is present in every (agent, wave) — Claude Code v1 in particular has very few
idea files.

This module returns a typed inventory; it does not parse contents.
"""

from __future__ import annotations

from pathlib import Path

from .schema import Agent, RepoInventory, ScratchpadInventory, Wave

WAVES: tuple[Wave, ...] = (Wave.V1, Wave.NOVELTY, Wave.V2, Wave.V3)
AGENTS: tuple[Agent, ...] = (Agent.CLAUDE_CODE, Agent.CODEX)


def walk_pi_repo(root: str | Path) -> RepoInventory:
    """Walk the repo and produce a typed inventory of every scratchpad.

    Missing files are recorded as None; missing directories produce empty lists.
    """
    root_path = Path(root).resolve()
    if not root_path.exists():
        raise FileNotFoundError(f"PI repo root does not exist: {root_path}")

    scratchpads: list[ScratchpadInventory] = []
    for wave in WAVES:
        for agent in AGENTS:
            wave_dir = root_path / wave.value / agent.value
            if not wave_dir.exists():
                # Not every combination exists (e.g., novelty/codex exists but layout varies)
                continue
            scratch = _walk_scratchpad(wave_dir, agent, wave)
            if scratch is not None:
                scratchpads.append(scratch)

    return RepoInventory(repo_root=str(root_path), scratchpads=scratchpads)


def _walk_scratchpad(wave_agent_dir: Path, agent: Agent, wave: Wave) -> ScratchpadInventory | None:
    """Walk one (agent, wave) directory and produce its inventory."""
    scratchpad_dir = wave_agent_dir / "scratchpad"
    if not scratchpad_dir.exists():
        return None

    inv = ScratchpadInventory(
        agent=agent,
        wave=wave,
        scratchpad_dir=str(scratchpad_dir),
    )

    # Top-level files
    for fname, attr in [
        ("runs.jsonl", "runs_jsonl"),
        ("THREAD.md", "thread_md"),
        ("picklist.md", "picklist_md"),
        ("audits.md", "audits_md"),
    ]:
        path = scratchpad_dir / fname
        if path.exists():
            setattr(inv, attr, str(path))

    # plan/goal/AGENTS sit in the wave_agent dir, not the scratchpad dir
    for fname, attr in [
        ("plan.md", "plan_md"),
        ("goal.md", "goal_md"),
        ("AGENTS.md", "agents_md"),
    ]:
        path = wave_agent_dir / fname
        if path.exists():
            setattr(inv, attr, str(path))

    # Sub-directories with file lists
    for subdir_name, dir_attr, files_attr, pattern in [
        ("ideas", "ideas_dir", "idea_files", "*.md"),
        ("papers", "papers_dir", "paper_files", "*.md"),
        ("variants", "variants_dir", "variant_files", "*.py"),
        ("runs", "runs_logs_dir", "run_log_files", "*.log"),
        ("rule_checks", "rule_checks_dir", "rule_check_files", "*.md"),
    ]:
        subdir = scratchpad_dir / subdir_name
        if subdir.exists() and subdir.is_dir():
            setattr(inv, dir_attr, str(subdir))
            files = sorted(str(p) for p in subdir.glob(pattern) if p.is_file())
            setattr(inv, files_attr, files)

    return inv


def summarize_inventory(inv: RepoInventory) -> str:
    """Human-readable summary, useful for CLI debugging."""
    lines = [f"repo_root: {inv.repo_root}", f"scratchpads: {len(inv.scratchpads)}"]
    for s in inv.scratchpads:
        lines.append(
            f"  {s.agent.value}/{s.wave.value}: "
            f"ideas={len(s.idea_files):4d}  "
            f"papers={len(s.paper_files):3d}  "
            f"variants={len(s.variant_files):4d}  "
            f"runs={len(s.run_log_files):5d}  "
            f"rule_checks={len(s.rule_check_files):3d}"
        )
    return "\n".join(lines)
