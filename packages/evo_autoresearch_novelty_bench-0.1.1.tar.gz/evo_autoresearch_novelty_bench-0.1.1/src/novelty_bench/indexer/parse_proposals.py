"""Build the Proposal catalog from variant.py files.

A Proposal is one variant.py — the unit the judge actually scores. Where an
Idea is the prose writeup an agent produced (ideas/*.md), a Proposal is the
concrete code change. Many proposals descend from one idea (HP sweep cells,
seed reps); some proposals have no formal idea writeup at all.

This module runs AFTER:
  - parse_runs: gives us Run.variant_path → run_id mapping
  - link_runs: gives us Run.idea_id (the link from a run back to its writeup)

Linkage logic for a variant.py file:
  - run_ids: every Run whose variant_path basename matches this file's basename
    in the same (agent, wave)
  - parent_idea_id: most common idea_id across this variant's runs; tie-break
    on run count, then earliest launched_at
  - first_seen_at: earliest launched_at across this variant's runs, fall back
    to file mtime
  - proposal_type: BASELINE if filename has baseline marker; else FORMAL_IDEA
    when parent_idea_id resolved; else VARIANT_ONLY
"""

from __future__ import annotations

import hashlib
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from .schema import (
    Agent,
    Proposal,
    ProposalType,
    Run,
    ScratchpadInventory,
    Verdict,
    Wave,
)

_BASELINE_PATTERNS = (
    re.compile(r"^baseline[-_]"),
    re.compile(r"^muon[-_]?3500"),
    re.compile(r"^v\d_base(?:[-_]|$)"),
    re.compile(r"^v\d_baseline"),
)

_DOCSTRING_RE = re.compile(r'^\s*("""|\'\'\')(.*?)\1', re.DOTALL)


def _is_baseline(stem: str) -> bool:
    s = stem.lower()
    return any(p.search(s) for p in _BASELINE_PATTERNS)


def _hash_and_size(path: Path) -> tuple[str, int]:
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as f:
        while chunk := f.read(1 << 16):
            h.update(chunk)
            size += len(chunk)
    return h.hexdigest(), size


def _extract_header_docstring(path: Path, max_chars: int = 800) -> str | None:
    """First top-of-file triple-string. Returns None if absent."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    m = _DOCSTRING_RE.match(text)
    if not m:
        return None
    body = m.group(2).strip()
    if not body:
        return None
    return body[:max_chars]


def _variant_stem(path_str: str) -> str:
    return Path(path_str).stem


def parse_proposals_for_scratchpad(
    inv: ScratchpadInventory,
    runs: list[Run],
    repo_root: Path,
) -> list[Proposal]:
    """Build Proposal rows for one (agent, wave) scratchpad.

    `runs` may include runs from other scratchpads; we filter to this one. We
    match variants to runs by basename within this scratchpad, since absolute
    paths in different `runs.jsonl` files vary (per-worktree paths).
    """
    scope_runs = [r for r in runs if r.agent == inv.agent and r.wave == inv.wave]

    # Index runs by variant basename for cheap lookup
    runs_by_variant_basename: dict[str, list[Run]] = defaultdict(list)
    for r in scope_runs:
        if not r.variant_path:
            continue
        base = Path(r.variant_path).name
        runs_by_variant_basename[base].append(r)

    proposals: list[Proposal] = []
    for variant_path_str in inv.variant_files:
        p = Path(variant_path_str)
        if not p.exists() or not p.is_file():
            continue
        stem = p.stem
        basename = p.name
        try:
            rel_path = str(p.relative_to(repo_root))
        except ValueError:
            rel_path = str(p)

        sha, size = _hash_and_size(p)
        header = _extract_header_docstring(p)

        matched_runs = runs_by_variant_basename.get(basename, [])

        # parent_idea_id: most common across this variant's runs
        idea_counter: Counter[str] = Counter()
        for r in matched_runs:
            if r.idea_id:
                idea_counter[r.idea_id] += 1
        parent_idea_id = idea_counter.most_common(1)[0][0] if idea_counter else None

        # first_seen_at: earliest launched_at over matched runs, else file mtime
        launch_times = [r.launched_at for r in matched_runs if r.launched_at]
        if launch_times:
            first_seen_at = min(launch_times)
            first_seen_source = "run_launched_at"
        else:
            try:
                first_seen_at = datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc)
                first_seen_source = "mtime"
            except OSError:
                first_seen_at = None
                first_seen_source = None

        # Rollup over this variant's runs
        scored = [r for r in matched_runs if r.step_to_3_28 is not None]
        if scored:
            best_run = min(scored, key=lambda r: r.step_to_3_28)  # type: ignore[arg-type]
            best_run_id = best_run.run_id
            best_step_to_3_28 = best_run.step_to_3_28
            best_final_val_loss = best_run.final_val_loss
        else:
            best_run_id = None
            best_step_to_3_28 = None
            # Fall back to a final_val_loss aggregate for variants that didn't hit target
            losses = [r.final_val_loss for r in matched_runs if r.final_val_loss is not None]
            best_final_val_loss = min(losses) if losses else None

        # Verdict: compare against Muon-3500 baseline (3500 steps)
        if best_step_to_3_28 is None:
            verdict = Verdict.UNKNOWN if not matched_runs else Verdict.INCONCLUSIVE
        elif best_step_to_3_28 <= 3400:
            verdict = Verdict.IMPROVED
        elif best_step_to_3_28 <= 3550:
            verdict = Verdict.NEUTRAL
        else:
            verdict = Verdict.REGRESSED

        if _is_baseline(stem):
            proposal_type = ProposalType.BASELINE
        elif parent_idea_id:
            proposal_type = ProposalType.FORMAL_IDEA
        else:
            proposal_type = ProposalType.VARIANT_ONLY

        proposals.append(
            Proposal(
                proposal_id=f"{inv.agent.value}--{inv.wave.value}--{stem}",
                agent=inv.agent,
                wave=inv.wave,
                variant_path=rel_path,
                variant_stem=stem,
                sha256=sha,
                file_size_bytes=size,
                first_seen_at=first_seen_at,
                first_seen_source=first_seen_source,
                parent_idea_id=parent_idea_id,
                run_ids=[r.run_id for r in matched_runs],
                num_runs=len(matched_runs),
                proposal_type=proposal_type,
                best_run_id=best_run_id,
                best_step_to_3_28=best_step_to_3_28,
                best_final_val_loss=best_final_val_loss,
                verdict=verdict,
                header_docstring=header,
            )
        )
    return proposals


def parse_all_proposals(
    scratchpads: list[ScratchpadInventory],
    runs: list[Run],
    repo_root: Path,
) -> list[Proposal]:
    out: list[Proposal] = []
    for inv in scratchpads:
        out.extend(parse_proposals_for_scratchpad(inv, runs, repo_root))
    return out
