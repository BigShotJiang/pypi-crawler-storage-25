"""Build experiments.parquet — one row per research attempt (= one Run).

This is the benchmark's primary catalog. Whereas proposals.parquet indexes
the variant.py files the agents saved (3,249 rows), experiments.parquet
indexes every actual training run (~10,380 rows). For benchmark purposes the
experiment is the unit-of-research: each represents an idea the agent
hypothesized and tested, regardless of whether the launched source code is
still cleanly recoverable.

Description text source (ladder, applied in order):
  1. parent idea writeup (idea title + proposal_text)  — when run.idea_id resolves
  2. variant header docstring                          — when run.variant_path resolves AND has a docstring
  3. run_id only (shorthand, e.g. "tailema-b0999-s2000-ts3025-s0")
                                                       — when neither resolves

Rows in source (3) get description_source="run_id_only" and are the candidates
for the LLM augmentation pass in experiments_llm_augment.py.
"""

from __future__ import annotations

from collections import defaultdict

import pandas as pd

from .schema import (
    Experiment,
    Idea,
    Proposal,
    Run,
    Verdict,
)

# Verdict thresholds match parse_proposals.py
VERDICT_IMPROVED_MAX = 3400
VERDICT_NEUTRAL_MAX = 3550


def build_experiments(
    runs: list[Run],
    ideas: list[Idea],
    proposals: list[Proposal],
) -> list[Experiment]:
    """Construct one Experiment per Run. Annotates with description text + linkage."""
    ideas_by_id: dict[str, Idea] = {i.idea_id: i for i in ideas}
    proposals_by_path: dict[str, Proposal] = {p.variant_path: p for p in proposals}

    out: list[Experiment] = []
    for r in runs:
        verdict, step = _verdict_for_run(r)
        idea = ideas_by_id.get(r.idea_id) if r.idea_id else None
        prop = proposals_by_path.get(r.variant_path) if r.variant_path else None

        description, source = _build_description(r, idea, prop)

        out.append(Experiment(
            experiment_id=r.run_id,
            agent=r.agent,
            wave=r.wave,
            first_seen_at=r.launched_at,
            verdict=verdict,
            step_to_3_28=step,
            final_val_loss=r.final_val_loss,
            hit_target=r.hit_target,
            linked_variant_path=r.variant_path,
            linked_proposal_id=prop.proposal_id if prop else None,
            linked_idea_id=r.idea_id,
            seed=r.seed,
            description_text=description,
            description_source=source,
        ))
    _assign_positions(out)
    return out


def _verdict_for_run(r: Run) -> tuple[Verdict, int | None]:
    step = r.step_to_3_28
    if step is None:
        # Has the run been attempted? If we have a final_val_loss we know it ran
        # but didn't hit the target; otherwise it's truly unknown.
        if r.final_val_loss is not None:
            return Verdict.INCONCLUSIVE, None
        return Verdict.UNKNOWN, None
    if step <= VERDICT_IMPROVED_MAX:
        return Verdict.IMPROVED, step
    if step <= VERDICT_NEUTRAL_MAX:
        return Verdict.NEUTRAL, step
    return Verdict.REGRESSED, step


def _build_description(
    r: Run, idea: Idea | None, prop: Proposal | None
) -> tuple[str, str]:
    """Return (description_text, source_tag) per the ladder."""
    if idea is not None:
        title = (idea.title or "").strip()
        body = (idea.proposal_text or "").strip()
        if body:
            text = f"{title}\n\n{body}"[:2000].strip()
            if len(text) >= 80:
                return text, "idea_writeup"

    if prop is not None and prop.header_docstring:
        title = prop.variant_stem.replace("_", " ").replace("-", " ")
        text = f"{title}\n\n{prop.header_docstring}"[:2000].strip()
        if len(text) >= 80:
            return text, "variant_docstring"

    # Fallback — just the run_id shorthand. LLM augmentation will rewrite these.
    text = r.run_id.replace("_", " ").replace("-", " ")
    return text, "run_id_only"


def _assign_positions(experiments: list[Experiment]) -> None:
    """1-indexed position within each (agent, wave) by first_seen_at."""
    by_scope: dict[tuple, list[Experiment]] = defaultdict(list)
    for e in experiments:
        by_scope[(e.agent, e.wave)].append(e)
    from datetime import datetime, timezone
    sentinel = datetime.max.replace(tzinfo=timezone.utc)
    for scope in by_scope.values():
        scope.sort(key=lambda e: (
            e.first_seen_at is None,
            e.first_seen_at if e.first_seen_at is not None else sentinel,
            e.experiment_id,
        ))
        for i, e in enumerate(scope, start=1):
            e.position = i


def summarize(experiments: list[Experiment]) -> dict:
    """Coverage summary for the manifest."""
    df = pd.DataFrame([e.model_dump(mode="json") for e in experiments])
    return {
        "total_experiments": len(df),
        "with_first_seen_at": int(df["first_seen_at"].notna().sum()),
        "by_description_source": df["description_source"].value_counts().to_dict(),
        "by_verdict": df["verdict"].value_counts().to_dict(),
        "by_scope": df.groupby(["agent", "wave"]).size().to_dict(),
        "by_scope_with_real_timestamps": (
            df[df["first_seen_at"].notna()]
            .groupby(["agent", "wave"]).size().to_dict()
        ),
    }
