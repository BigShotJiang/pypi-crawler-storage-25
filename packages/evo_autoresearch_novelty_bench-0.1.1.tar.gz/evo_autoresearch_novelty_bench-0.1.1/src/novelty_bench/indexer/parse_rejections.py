"""Parse audits.md and rule_checks/*.md for rule-compliance verdicts.

Two distinct formats across the dataset:

1. `audits.md` — a single markdown file per scratchpad (only `novelty/claude-code/`
   has one in the current data). Contains a table with `| Idea | ... | Verdict |`
   rows. Idea names are in backticks in column 1; verdict appears in the last
   column or as inline text.

2. `rule_checks/<id>_rule_check.md` — one file per audited idea (only
   `novelty/codex/scratchpad/rule_checks/` in the current data). Top-level
   `Verdict: <text>.` line. Filename prefix is the idea's 3-letter+3-digit code
   (e.g., `awr001_rule_check.md` covers `awr001_alignment_weight_decay_relief_muon`).

Both produce: {(agent, wave, idea_id): {verdict: str, evidence_text: str}}.
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from .schema import Agent, ScratchpadInventory, Wave

# Patterns used to recognize verdict tokens. Order matters — longer first.
_VERDICT_TOKENS: tuple[str, ...] = (
    "NON-COMPLIANT",
    "NONCOMPLIANT",
    "NOT COMPLIANT",
    "PASS CONDITIONAL",
    "PASS",
    "FAIL",
    "COMPLIANT",
)


@dataclass
class RejectionRecord:
    agent: Agent
    wave: Wave
    idea_id: str          # full idea_id (resolved from code prefix when needed)
    verdict: str          # e.g. "NON-COMPLIANT", "PASS", "PASS CONDITIONAL"
    evidence_text: str    # short rationale extracted from the source
    source_file: str      # which file produced this record


def parse_rejections_for_scratchpad(
    inv: ScratchpadInventory,
    known_idea_ids: list[str],
) -> list[RejectionRecord]:
    """Parse all audit/rule-check files in a scratchpad.

    `known_idea_ids` is the list of idea_ids in this scratchpad — needed to
    resolve code-prefix filenames (`awr001_rule_check.md`) to full idea_ids.
    """
    records: list[RejectionRecord] = []
    records.extend(_parse_audits_md(inv))
    records.extend(_parse_rule_check_files(inv, known_idea_ids))
    return records


# ---------------------------------------------------------------------------
# audits.md table parser
# ---------------------------------------------------------------------------


_BACKTICK_RE = re.compile(r"`([^`]+)`")


def _parse_audits_md(inv: ScratchpadInventory) -> list[RejectionRecord]:
    if not inv.audits_md:
        return []
    path = Path(inv.audits_md)
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8", errors="replace")

    records: list[RejectionRecord] = []
    for line in text.splitlines():
        # Markdown table rows start with `|`
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 2:
            continue
        # Skip header / separator rows ("| --- | --- |")
        if all(re.fullmatch(r":?-+:?", c) for c in cells if c):
            continue
        first_cell = cells[0]
        # Idea name in first cell, in backticks
        m = _BACKTICK_RE.search(first_cell)
        if not m:
            continue
        idea_id = m.group(1)
        verdict = _extract_verdict(line)
        if not verdict:
            continue
        # Evidence = the row content, trimmed for length
        evidence = line.strip()
        if len(evidence) > 800:
            evidence = evidence[:800] + "…"
        records.append(
            RejectionRecord(
                agent=inv.agent,
                wave=inv.wave,
                idea_id=idea_id,
                verdict=verdict,
                evidence_text=evidence,
                source_file=str(path),
            )
        )
    return records


# ---------------------------------------------------------------------------
# rule_checks/*.md parser
# ---------------------------------------------------------------------------


_VERDICT_LINE_RE = re.compile(r"^Verdict:\s*(.+?)$", re.MULTILINE)


def _parse_rule_check_files(
    inv: ScratchpadInventory, known_idea_ids: list[str]
) -> list[RejectionRecord]:
    if not inv.rule_check_files:
        return []

    # Build a code-prefix lookup: idea_ids that start with a digit-containing
    # token map their code → full idea_id.
    code_to_idea: dict[str, str] = {}
    for iid in known_idea_ids:
        code = _first_token(iid).lower()
        if code and any(c.isdigit() for c in code):
            code_to_idea[code] = iid

    records: list[RejectionRecord] = []
    for path_str in inv.rule_check_files:
        path = Path(path_str)
        name = path.stem
        # Filename like `awr001_rule_check.md` → strip suffix
        for suffix in ("_rule_check", "_rule_audit", "_rules_check"):
            if name.endswith(suffix):
                code = name[: -len(suffix)]
                break
        else:
            code = name  # fallback

        idea_id = code_to_idea.get(code.lower())
        if not idea_id:
            continue  # rule_check for an idea we don't have a writeup for — skip

        text = path.read_text(encoding="utf-8", errors="replace")
        m = _VERDICT_LINE_RE.search(text)
        if not m:
            continue
        verdict_line = m.group(1).strip().rstrip(".")
        verdict = _extract_verdict(verdict_line) or verdict_line
        # Evidence = the verdict line itself
        evidence = f"Verdict: {verdict_line}"

        records.append(
            RejectionRecord(
                agent=inv.agent,
                wave=inv.wave,
                idea_id=idea_id,
                verdict=verdict,
                evidence_text=evidence,
                source_file=str(path),
            )
        )
    return records


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _extract_verdict(text: str) -> str | None:
    upper = text.upper()
    for token in _VERDICT_TOKENS:
        if token in upper:
            return token
    return None


def _first_token(s: str) -> str:
    out: list[str] = []
    for ch in s:
        if ch.isalnum():
            out.append(ch)
        elif out:
            break
    return "".join(out)


def parse_rejections_all(
    inventories: list[ScratchpadInventory],
    ideas_by_scope: dict[tuple[Agent, Wave], list[str]],
) -> dict[tuple[Agent, Wave, str], RejectionRecord]:
    """Aggregate rejection records across all scratchpads.

    Returns a dict keyed by (agent, wave, idea_id). When multiple records
    exist for one idea, the last one wins (later audits supersede earlier ones).
    """
    out: dict[tuple[Agent, Wave, str], RejectionRecord] = {}
    for inv in inventories:
        known = ideas_by_scope.get((inv.agent, inv.wave), [])
        for rec in parse_rejections_for_scratchpad(inv, known):
            out[(rec.agent, rec.wave, rec.idea_id)] = rec
    return out
