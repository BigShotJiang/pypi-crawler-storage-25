"""Recover variant.py linkage for claude-code runs via pytorch dynamo warnings.

Claude-code's launch wrapper doesn't dump the variant source into the log
(unlike codex's wrapper, which embeds it before the ====...==== delimiter).
But pytorch's torch._dynamo compiler emits warnings during runtime that
include the FULL FILE PATH of the function being compiled:

  [rank5]:W0512 11:01:12 ... function: 'muon_update'
  (/beegfs/elie/.../scratchpad/variants/train_gpt_simple_v32wd026.py:208)

We parse those warnings to recover (run_id -> variant_path). Resolves the
basename against `{wave}/{agent}/scratchpad/variants/` to confirm the file
exists in the public archive.

Recovers ~1,274 of 2,224 claude-code unlinked runs (57%). Combined with the
embedded-source extractor (codex side), pushes total code coverage from 65%
to 77%.
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from pathlib import Path

import pandas as pd

# Matches the variant.py path inside torch._dynamo recompile warnings.
_VARIANT_RE = re.compile(r"/scratchpad/variants/([\w\-.]+\.py):\d+\)")


def extract_variant_from_log(log_path: Path) -> str | None:
    """Return the most-mentioned variant.py basename in this log, or None."""
    try:
        text = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    matches = _VARIANT_RE.findall(text)
    if not matches:
        return None
    return Counter(matches).most_common(1)[0][0]


def recover_linkages(
    *,
    experiments_df: pd.DataFrame,
    runs_df: pd.DataFrame,
    pi_repo: Path,
) -> tuple[pd.DataFrame, dict]:
    """Update experiments_df with newly-recovered linked_variant_path.

    Returns (updated_experiments_df, stats_dict). Only touches rows where
    linked_variant_path is currently null.
    """
    log_paths = runs_df.set_index("run_id")["log_path"]
    unlinked = experiments_df[experiments_df["linked_variant_path"].isna()]

    recovered: dict[str, str] = {}
    n_no_log = 0
    n_no_warning = 0
    n_resolved_to_disk = 0
    n_basename_not_on_disk = 0

    for i, (_, row) in enumerate(unlinked.iterrows(), 1):
        rid = row["experiment_id"]
        lp = log_paths.get(rid)
        if not isinstance(lp, str) or not lp:
            n_no_log += 1
            continue
        full = pi_repo / lp
        if not full.exists():
            n_no_log += 1
            continue
        basename = extract_variant_from_log(full)
        if basename is None:
            n_no_warning += 1
            continue
        # Confirm it exists in {wave}/{agent}/scratchpad/variants/
        candidate = pi_repo / row["wave"] / row["agent"] / "scratchpad" / "variants" / basename
        if candidate.exists():
            recovered[rid] = f"{row['wave']}/{row['agent']}/scratchpad/variants/{basename}"
            n_resolved_to_disk += 1
        else:
            n_basename_not_on_disk += 1

        if i % 500 == 0:
            print(f"  scanned {i:>5d}/{len(unlinked)} unlinked, recovered {n_resolved_to_disk:>5d}")

    # Apply the recovered linkages
    n_updated = 0
    for rid, path in recovered.items():
        mask = experiments_df["experiment_id"] == rid
        experiments_df.loc[mask, "linked_variant_path"] = path
        n_updated += int(mask.sum())

    stats = {
        "unlinked_scanned": len(unlinked),
        "no_log_file": n_no_log,
        "no_dynamo_warning": n_no_warning,
        "basename_not_on_disk": n_basename_not_on_disk,
        "resolved_to_disk": n_resolved_to_disk,
        "experiments_updated": n_updated,
    }
    return experiments_df, stats


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m novelty_bench.indexer.link_via_dynamo_warnings")
    p.add_argument("--pi-repo", required=True, type=Path)
    p.add_argument("--data-root", type=Path, default=Path("data/out"))
    args = p.parse_args(argv)

    exp_path = args.data_root / "experiments.parquet"
    runs_path = args.data_root / "runs.parquet"
    if not exp_path.exists() or not runs_path.exists():
        print(f"error: experiments.parquet or runs.parquet not found in {args.data_root}",
              file=sys.stderr)
        return 2

    experiments_df = pd.read_parquet(exp_path)
    runs_df = pd.read_parquet(runs_path)
    before = experiments_df["linked_variant_path"].notna().sum()
    print(f"Loaded {len(experiments_df)} experiments; "
          f"{before} have linked_variant_path before recovery")

    experiments_df, stats = recover_linkages(
        experiments_df=experiments_df, runs_df=runs_df, pi_repo=args.pi_repo,
    )
    after = experiments_df["linked_variant_path"].notna().sum()

    print(f"\nRecovery stats:")
    for k, v in stats.items():
        print(f"  {k}: {v}")
    print(f"\nlinked_variant_path coverage: {before} -> {after}")

    experiments_df.to_parquet(exp_path, index=False)
    print(f"Wrote updated experiments to {exp_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
