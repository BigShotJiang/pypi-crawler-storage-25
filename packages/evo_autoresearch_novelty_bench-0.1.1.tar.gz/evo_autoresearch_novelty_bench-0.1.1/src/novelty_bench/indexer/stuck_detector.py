"""Recompute the agent's stuck-detector from runs.

Original rule (from PI's AGENTS.md lawful core, rule 3):

    At 30 consecutive runs in one family without `step_to_target` improvement,
    the family is mandatorily ruled out and the agent pivots.

A "family" is the slug prefix — the first 1–3 tokens of a variant or run slug.
We approximate the agent's notion of family by taking the first token (the part
of a run_id before the first separator) as the family key.

For each (agent, wave) trajectory:
  1. Walk runs in chronological order (by launched_at, falling back to position
     of the linked idea).
  2. Maintain a per-family streak counter that increments on every run in that
     family without an improvement, and resets to zero when a run in that family
     beats the family's running best step_to_target.
  3. When a family's streak hits 30, mark `family_ruled_out_at_position` for
     every idea_id in that family from that point on.

Returns a mapping of (agent, wave, idea_id) -> rule-out position (the integer
position of the run that triggered the rule-out). Ideas in families that never
got ruled out don't appear in the mapping.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

import pandas as pd

from .schema import Agent, Wave

STUCK_THRESHOLD = 30


@dataclass
class FamilyRuleOut:
    agent: Agent
    wave: Wave
    family: str
    ruled_out_at_run_index: int
    affected_idea_ids: set[str]


def compute_family_rule_outs(
    runs_df: pd.DataFrame,
    ideas_df: pd.DataFrame,
) -> list[FamilyRuleOut]:
    """Walk per-(agent, wave) run sequences and identify stuck families."""
    out: list[FamilyRuleOut] = []

    # Map idea_id -> position (for the "ruled_out_at_position" attribution later)
    idea_position = dict(zip(ideas_df["idea_id"], ideas_df["position"]))

    for (agent_val, wave_val), scope_runs in runs_df.groupby(["agent", "wave"]):
        # Order runs chronologically. Some runs have no launched_at; fall back
        # to the position of the linked idea, then to original index.
        scope_runs = scope_runs.copy()
        scope_runs["_order"] = scope_runs.apply(
            lambda r: _ordering_key(r, idea_position), axis=1
        )
        scope_runs = scope_runs.sort_values("_order").reset_index(drop=True)

        family_streak: dict[str, int] = defaultdict(int)
        family_best: dict[str, int] = {}
        family_ideas: dict[str, set[str]] = defaultdict(set)
        already_ruled_out: set[str] = set()

        for run_idx, row in scope_runs.iterrows():
            family = _family_key(row)
            if not family:
                continue
            idea_id = row.get("idea_id")
            if isinstance(idea_id, str) and idea_id:
                family_ideas[family].add(idea_id)
            if family in already_ruled_out:
                continue

            step = row.get("step_to_3_28")
            if pd.notna(step):
                prior_best = family_best.get(family)
                if prior_best is None or step < prior_best:
                    family_best[family] = int(step)
                    family_streak[family] = 0
                    continue

            family_streak[family] += 1
            if family_streak[family] >= STUCK_THRESHOLD:
                already_ruled_out.add(family)
                out.append(
                    FamilyRuleOut(
                        agent=Agent(agent_val),
                        wave=Wave(wave_val),
                        family=family,
                        ruled_out_at_run_index=int(run_idx),
                        affected_idea_ids=set(family_ideas[family]),
                    )
                )
    return out


def _ordering_key(row: pd.Series, idea_position: dict[str, int]) -> tuple:
    """Stable chronological key.

    Prefer launched_at; otherwise use the linked idea's position; otherwise 0.
    """
    launched = row.get("launched_at")
    if pd.notna(launched):
        # pandas may give us a Timestamp or a string; convert to comparable repr
        return (0, str(launched))
    idea_id = row.get("idea_id")
    if isinstance(idea_id, str) and idea_id in idea_position:
        pos = idea_position.get(idea_id)
        if pos is not None and pd.notna(pos):
            return (1, int(pos))
    return (2, 0)


def _family_key(row: pd.Series) -> str | None:
    """First-token of the run_id (lowercased). Empty/non-string returns None."""
    rid = row.get("run_id")
    if not isinstance(rid, str) or not rid:
        return None
    out: list[str] = []
    for ch in rid.lower():
        if ch.isalnum():
            out.append(ch)
        elif out:
            break
    token = "".join(out)
    return token or None


def collect_ruled_out_idea_ids(
    rule_outs: list[FamilyRuleOut],
) -> dict[tuple[Agent, Wave, str], int]:
    """Flatten rule-out records into per-idea map: (agent, wave, idea_id) -> position."""
    out: dict[tuple[Agent, Wave, str], int] = {}
    for ro in rule_outs:
        for iid in ro.affected_idea_ids:
            key = (ro.agent, ro.wave, iid)
            # First rule-out wins (earliest)
            if key not in out:
                out[key] = ro.ruled_out_at_run_index
    return out
