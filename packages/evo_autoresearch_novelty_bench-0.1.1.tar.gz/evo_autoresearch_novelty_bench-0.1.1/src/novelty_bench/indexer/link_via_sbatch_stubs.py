"""Recover variant.py linkage from per-run sbatch stub scripts.

Each scratchpad has `scratchpad/sbatch-stubs/<run_id>.sh` that the agent
generated when launching the run. The stub explicitly references the variant
file it launched:

  codex format:  python parse_and_index.py --variant ".../variants/<file>.py"
  claude-code:   torchrun ... records/.../scratchpad/variants/<file>.py

We parse both formats. For each unlinked experiment, look up its stub by
filename, extract the variant basename, and confirm it exists in
{wave}/{agent}/scratchpad/variants/.

Combined with the earlier recovery passes (runs.jsonl, embedded source,
dynamo warnings), this closes most of the remaining linkage gap.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import pandas as pd

# `--variant "/path/to/variants/<file>.py"` (or with single-quotes / no quotes)
_VARIANT_FLAG_RE = re.compile(r"""--variant\s+["']?([^"'\s]+/variants/[\w\-.]+\.py)""")
# `torchrun ... variants/<file>.py` — the .py is the last token on a torchrun line
_TORCHRUN_PY_RE = re.compile(r"""torchrun\b.*?\s+([\S]+\.py)\b""")


def extract_variant_from_stub(stub_path: Path) -> str | None:
    """Return the variant.py basename referenced in this sbatch stub, or None."""
    try:
        text = stub_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    m = _VARIANT_FLAG_RE.search(text)
    if m:
        return Path(m.group(1)).name
    for line in text.splitlines():
        if "torchrun" not in line:
            continue
        m = _TORCHRUN_PY_RE.search(line)
        if not m:
            continue
        target = m.group(1)
        # Only count it if it's pointing into a variants/ dir
        if "/variants/" in target:
            return Path(target).name
    return None


def recover_linkages(
    *,
    experiments_df: pd.DataFrame,
    pi_repo: Path,
) -> tuple[pd.DataFrame, dict]:
    """Walk unlinked experiments, look up their sbatch stubs, recover linkage."""
    unlinked = experiments_df[experiments_df["linked_variant_path"].isna()]

    n_no_stub = 0
    n_no_variant_ref = 0
    n_basename_not_on_disk = 0
    n_resolved = 0
    recovered: dict[str, str] = {}

    for i, (_, row) in enumerate(unlinked.iterrows(), 1):
        rid = row["experiment_id"]
        stub_path = pi_repo / row["wave"] / row["agent"] / "scratchpad" / "sbatch-stubs" / f"{rid}.sh"
        if not stub_path.exists():
            n_no_stub += 1
            continue
        basename = extract_variant_from_stub(stub_path)
        if basename is None:
            n_no_variant_ref += 1
            continue
        candidate = pi_repo / row["wave"] / row["agent"] / "scratchpad" / "variants" / basename
        if candidate.exists():
            recovered[rid] = f"{row['wave']}/{row['agent']}/scratchpad/variants/{basename}"
            n_resolved += 1
        else:
            n_basename_not_on_disk += 1

        if i % 500 == 0:
            print(f"  scanned {i:>5d}/{len(unlinked)} unlinked, recovered {n_resolved:>5d}")

    n_updated = 0
    for rid, path in recovered.items():
        mask = experiments_df["experiment_id"] == rid
        experiments_df.loc[mask, "linked_variant_path"] = path
        n_updated += int(mask.sum())

    stats = {
        "unlinked_scanned": len(unlinked),
        "no_stub_file": n_no_stub,
        "no_variant_ref_in_stub": n_no_variant_ref,
        "basename_not_on_disk": n_basename_not_on_disk,
        "resolved_to_disk": n_resolved,
        "experiments_updated": n_updated,
    }
    return experiments_df, stats


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m novelty_bench.indexer.link_via_sbatch_stubs")
    p.add_argument("--pi-repo", required=True, type=Path)
    p.add_argument("--data-root", type=Path, default=Path("data/out"))
    args = p.parse_args(argv)

    exp_path = args.data_root / "experiments.parquet"
    if not exp_path.exists():
        print(f"error: {exp_path} not found", file=sys.stderr)
        return 2

    experiments_df = pd.read_parquet(exp_path)
    before = experiments_df["linked_variant_path"].notna().sum()
    print(f"Loaded {len(experiments_df)} experiments; "
          f"{before} have linked_variant_path before this pass")

    experiments_df, stats = recover_linkages(experiments_df=experiments_df, pi_repo=args.pi_repo)
    after = experiments_df["linked_variant_path"].notna().sum()

    print("\nRecovery stats:")
    for k, v in stats.items():
        print(f"  {k}: {v}")
    print(f"\nlinked_variant_path coverage: {before} -> {after} (+{after-before})")

    experiments_df.to_parquet(exp_path, index=False)
    print(f"Wrote updated experiments to {exp_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
