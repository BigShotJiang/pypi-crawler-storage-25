"""LLM-augment description text for experiments whose run_id is all we have.

For runs that lack a parent_idea writeup and a recoverable variant header
docstring (~3,800 of 10,380), the description text starts out as just the
run_id shorthand. This module sends each distinct run-family to a small,
fast LLM (default: gpt-4o-mini) and rewrites the description into a 1-2
sentence mechanism summary that the embedding model can match against.

Families are deduped by stripping seed/replicate suffixes; all family members
get the same generated description (they share the mechanism, only seed
differs). This typically cuts the LLM call count by ~3x.

Cost (default gpt-4o-mini, ~1,100 families × ~500 tokens):
  ~$0.15 total. Set --model gpt-4o for higher fidelity (~$5).
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_PARALLEL = 10  # concurrent API requests

# Strip these patterns from the tail of a run_id to get a "family key".
# All runs sharing a family key get one LLM call.
_FAMILY_STRIP = (
    re.compile(r"[-_]s(?:eed)?\d+$"),  # -s0, -seed3
    re.compile(r"[-_]r(?:ep)?\d+$"),    # -r1, -rep2
    re.compile(r"[-_]final$"),
    re.compile(r"[-_]extraval$"),
    re.compile(r"[-_]local$"),
)


def _family_key(run_id: str) -> str:
    s = run_id
    while True:
        changed = False
        for rx in _FAMILY_STRIP:
            new = rx.sub("", s)
            if new != s:
                s = new
                changed = True
        if not changed:
            break
    return s


SYSTEM_PROMPT = """You are decomposing experiment run_ids from the modded-nanogpt training-step speedrun (target: val_loss <= 3.28 on FineWeb with a 124M GPT in fewest steps; Muon baseline = 3500 steps).

Style: terse, technical, comma-separated facts. NO preamble like "This run tests" or "The mechanism explored is". NO hedging like "likely", "focus on", "novelty in training dynamics". Match the way researchers actually describe an optimizer variant in a one-line note.

Run_id vocabulary:
- mlr / muon_lr / mu / mu<N>: Muon learning rate or momentum (mu097 = mu=0.97)
- wd / mwd: weight decay
- b1 / b2 / beta1 / beta2 / b<NNN>: Adam betas (b108 = beta1=1.08 sometimes; b2097 = beta2=0.97)
- ts<N>: target step count (ts3025 = train 3025 steps)
- s<N> / seed<N>: random seed (typically dropped — same mechanism)
- ema: exponential moving average over weights
- contra / contrastive: contrastive loss term
- aurora: v3-wave Muon variant family
- mucd / mu-cool / mucool: Muon cooldown schedule
- ks / k<N> / K<N>: Newton-Schulz iterations in Muon
- soap / shampoo: second-order optimizer families
- tail: late-training behavior (tail-EMA, tail-radius, etc.)
- horizon / sched / cooldown: LR schedule parameters
- v<N>: agent-internal variant numbering
- cgi / difc: v3-specific mechanism abbreviations
- loo<NN>: leave-one-out ablation (loo03 = ablation #3)
- baseline: control (no modification beyond named optimizer)

Output ONE description, 1-2 sentences max. Lead with the mechanism family, then list differentiating HPs. End with a brief "tests whether..." clause only if it adds non-obvious signal."""

FEW_SHOT_EXAMPLES = [
    # (agent, wave, run_id, log_excerpt, description)
    (
        "codex", "novelty", "muon-mu097-s1", "",
        "Muon optimizer with momentum mu=0.97, default LR schedule. Tests whether higher momentum reduces cooldown-phase variance."
    ),
    (
        "claude-code", "v2", "ema-start2000-decay0995-s0",
        "muon_lr=0.045\ntrain_steps=3025\nema_start_step=2000\nema_decay=0.995",
        "Late-EMA over weights: start at step 2000, decay=0.995. Averages only post-stabilization."
    ),
    (
        "claude-code", "v3", "tailema-b0999-s2000-ts3025-s0", "",
        "Tail-EMA with beta=0.999 applied after step 2000, training to step 3025. Swaps no-averaging to long-window averaging late in the run."
    ),
    (
        "claude-code", "v3", "loo03-no-muwarmup-s1", "",
        "Leave-one-out ablation #3: drops Muon learning-rate warmup from the recipe. Isolates the warmup's contribution."
    ),
]


def _build_messages(agent: str, wave: str, run_id: str, log_excerpt: str = "") -> list[dict]:
    """System + few-shot examples + the actual user query."""
    msgs = [{"role": "system", "content": SYSTEM_PROMPT}]
    for ex_agent, ex_wave, ex_run, ex_log, ex_desc in FEW_SHOT_EXAMPLES:
        user_content = f"Agent: {ex_agent}\nWave: {ex_wave}\nrun_id: {ex_run}"
        if ex_log:
            user_content += f"\nLog excerpt:\n{ex_log}"
        msgs.append({"role": "user", "content": user_content})
        msgs.append({"role": "assistant", "content": ex_desc})
    user_content = f"Agent: {agent}\nWave: {wave}\nrun_id: {run_id}"
    if log_excerpt:
        user_content += f"\nLog excerpt:\n{log_excerpt}"
    msgs.append({"role": "user", "content": user_content})
    return msgs


def _log_excerpt_for(run_id: str, log_path: str | None, pi_repo: Path | None,
                     max_chars: int = 2000) -> str:
    """Return ~80 lines of the run's log file, with pytorch warning noise stripped."""
    if not log_path or not pi_repo:
        return ""
    full = pi_repo / log_path
    if not full.exists() or not full.is_file():
        return ""
    try:
        text = full.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    # Keep first ~120 lines; drop pytorch warnings (W0... lines), drop step:* training lines
    keep: list[str] = []
    for line in text.splitlines()[:120]:
        s = line.strip()
        if not s:
            continue
        if s.startswith("W0") and "torch" in s:
            continue
        if s.startswith("step:") and "val_loss:" in s:
            continue
        keep.append(line)
        if sum(len(k) for k in keep) > max_chars:
            break
    return "\n".join(keep)[:max_chars]


def augment_descriptions(
    experiments_df: pd.DataFrame,
    *,
    model: str = DEFAULT_MODEL,
    parallel: int = DEFAULT_PARALLEL,
    limit: int | None = None,
    family_subset: list[str] | None = None,
    runs_df: pd.DataFrame | None = None,
    pi_repo: Path | None = None,
) -> tuple[pd.DataFrame, dict]:
    """Augment description_text for rows where description_source == 'run_id_only'.

    Returns (updated_df, usage_dict). Mutates description_text and
    description_source in-place for affected rows.
    """
    if not os.environ.get("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY not set")

    todo = experiments_df[experiments_df["description_source"] == "run_id_only"].copy()
    if family_subset is not None:
        todo = todo[todo["experiment_id"].apply(_family_key).isin(family_subset)]
    if todo.empty:
        return experiments_df, {"families_processed": 0, "rows_updated": 0, "cost_usd": 0.0}

    # Group by family
    todo["family"] = todo["experiment_id"].apply(_family_key)
    families = todo[["family", "agent", "wave"]].drop_duplicates(subset=["family"]).reset_index(drop=True)
    if limit:
        families = families.head(limit)

    # Resolve a representative log_path per family (used for log-excerpt context)
    log_path_lookup: dict[str, str] = {}
    if runs_df is not None:
        # Use the first run in each family that has a log_path
        runs_with_family = runs_df.copy()
        runs_with_family["family"] = runs_with_family["run_id"].apply(_family_key)
        for fam, grp in runs_with_family.groupby("family"):
            log_paths = grp["log_path"].dropna().tolist()
            if log_paths:
                log_path_lookup[fam] = log_paths[0]

    print(f"  augmenting {len(families)} distinct families "
          f"(covers {len(todo[todo['family'].isin(families['family'])])} rows)")
    print(f"  log-excerpt context: {sum(1 for f in families['family'] if f in log_path_lookup)}/{len(families)} families")

    # Fire off concurrent API calls
    from openai import OpenAI
    client = OpenAI()

    descriptions: dict[str, str] = {}
    total_prompt_tokens = 0
    total_completion_tokens = 0
    failed_families: list[str] = []
    t_start = time.time()

    def call_one(family_row):
        family = family_row["family"]
        log_excerpt = _log_excerpt_for(family, log_path_lookup.get(family), pi_repo)
        messages = _build_messages(
            agent=family_row["agent"],
            wave=family_row["wave"],
            run_id=family,
            log_excerpt=log_excerpt,
        )
        try:
            resp = client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=180,
                temperature=0.0,
            )
            text = resp.choices[0].message.content.strip()
            return family, text, resp.usage.prompt_tokens, resp.usage.completion_tokens, None
        except Exception as e:  # noqa: BLE001
            return family, None, 0, 0, str(e)

    with ThreadPoolExecutor(max_workers=parallel) as pool:
        futures = [pool.submit(call_one, row) for _, row in families.iterrows()]
        done = 0
        for f in as_completed(futures):
            family, text, ptok, ctok, err = f.result()
            done += 1
            if err is not None:
                failed_families.append((family, err))
                continue
            descriptions[family] = text
            total_prompt_tokens += ptok
            total_completion_tokens += ctok
            if done % 50 == 0 or done == len(futures):
                elapsed = time.time() - t_start
                rate = done / elapsed if elapsed > 0 else 0
                running_cost = _cost(total_prompt_tokens, total_completion_tokens, model)
                print(f"    {done}/{len(futures)} families  ({rate:.1f}/s, running cost ${running_cost:.4f})")

    # Apply descriptions back to the experiments DataFrame
    rows_updated = 0
    for idx, row in experiments_df.iterrows():
        if row["description_source"] != "run_id_only":
            continue
        family = _family_key(row["experiment_id"])
        if family in descriptions:
            experiments_df.at[idx, "description_text"] = descriptions[family]
            experiments_df.at[idx, "description_source"] = "llm_generated"
            rows_updated += 1

    cost = _cost(total_prompt_tokens, total_completion_tokens, model)
    usage = {
        "model": model,
        "families_processed": len(descriptions),
        "families_failed": len(failed_families),
        "rows_updated": rows_updated,
        "prompt_tokens": total_prompt_tokens,
        "completion_tokens": total_completion_tokens,
        "cost_usd": round(cost, 4),
    }
    if failed_families:
        print(f"  {len(failed_families)} families failed; sample: {failed_families[:3]}")
    return experiments_df, usage


def _cost(prompt_tokens: int, completion_tokens: int, model: str) -> float:
    """USD per token, current OpenAI pricing for the models we use."""
    prices = {
        "gpt-4o-mini": (0.15, 0.60),   # input, output per 1M tokens
        "gpt-4o":      (2.50, 10.00),
    }
    pin, pout = prices.get(model, (0.15, 0.60))
    return (prompt_tokens * pin + completion_tokens * pout) / 1_000_000


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m novelty_bench.indexer.experiments_llm_augment")
    p.add_argument("--data-root", type=Path, default=Path("data/out"))
    p.add_argument("--pi-repo", type=Path, default=None,
                   help="PI repo path for log-excerpt context (highly recommended)")
    p.add_argument("--model", default=DEFAULT_MODEL)
    p.add_argument("--parallel", type=int, default=DEFAULT_PARALLEL)
    p.add_argument("--limit", type=int, default=None,
                   help="Augment only the first N families (dry run / sample)")
    p.add_argument("--reset", action="store_true",
                   help="Re-augment families already marked llm_generated (re-run prompt)")
    args = p.parse_args(argv)

    exp_path = args.data_root / "experiments.parquet"
    if not exp_path.exists():
        print(f"error: {exp_path} not found. Run the indexer first.", file=sys.stderr)
        return 2

    exp_df = pd.read_parquet(exp_path)
    print(f"Loaded {len(exp_df)} experiments")

    if args.reset:
        mask = exp_df["description_source"] == "llm_generated"
        n = int(mask.sum())
        # Restore description to run_id form and mark as needing re-augmentation
        exp_df.loc[mask, "description_text"] = exp_df.loc[mask, "experiment_id"].str.replace(
            r"[-_]", " ", regex=True
        )
        exp_df.loc[mask, "description_source"] = "run_id_only"
        print(f"  reset {n} previously-augmented rows back to run_id_only")

    runs_df = pd.read_parquet(args.data_root / "runs.parquet") if (args.data_root / "runs.parquet").exists() else None
    exp_df, usage = augment_descriptions(
        exp_df, model=args.model, parallel=args.parallel, limit=args.limit,
        runs_df=runs_df, pi_repo=args.pi_repo,
    )
    print(f"\nUsage: {usage}")

    exp_df.to_parquet(exp_path, index=False)
    print(f"Wrote updated experiments to {exp_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
