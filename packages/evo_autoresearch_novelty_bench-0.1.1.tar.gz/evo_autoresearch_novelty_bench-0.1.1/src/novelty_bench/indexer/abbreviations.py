"""Extract abbreviation aliases for ideas.

Variant filenames in some scratchpads use abbreviations (`spm`, `acn`, `arm`,
`agmuon`) that don't appear as substrings of the full idea_id. This module pulls
those aliases out of the idea writeups so the linker can match them.

Three patterns we recognize:

1. Explicit family slug declaration in the proposal text:
       **Family slug:** `agmuon` (proposed prefix; sub-slugs `agmuon-epsX`, ...)
   The first backticked token after "family slug" is the alias.

2. Parenthesized initialism in the title or first line:
       "adam-rms-muon — Per-element raw-gradient (ARM-muon) ..."
       "spectral-momentum (SPM)"
   The 2-5 letter capital block in parens.

3. Initials of the idea-id tokens, if not already captured:
       "anti-correlation-nesterov" -> "acn"
       "cross-block-ortho" -> "cbo"
   Only included for ideas whose idea_id has ≥3 dash/underscore-separated tokens,
   since shorter ids would produce too-generic 2-letter codes.

Returns idea_id -> list of unique alias strings (lowercase, alphanumeric-only).
"""

from __future__ import annotations

import re
from typing import Iterable

# Match "Family slug: `xxx`" with optional bold, varied capitalization
_FAMILY_SLUG_RE = re.compile(
    r"\*{0,2}family[\s_-]*slug\*{0,2}\s*:?\s*`([a-zA-Z0-9_-]+)`",
    re.IGNORECASE,
)

# Match "Idea ID: `xxx`" — explicit alternate id
_IDEA_ID_BACKTICKED_RE = re.compile(
    r"\*{0,2}idea[\s_-]*id\*{0,2}\s*:?\s*`([a-zA-Z0-9_-]+)`",
    re.IGNORECASE,
)

# Match parenthesized 2-5 letter all-caps blocks, possibly with a digit suffix.
# Examples: "(SPM)", "(ARM-Muon)", "(ACN)"
_PARENS_INITIALS_RE = re.compile(r"\(([A-Z]{2,5}(?:-?[A-Za-z]+)?)\)")


def extract_aliases_for_idea(idea_id: str, title: str, proposal_text: str) -> list[str]:
    """Return all alias keys for one idea, lowercased and alphanumeric-only."""
    aliases: list[str] = []
    seen: set[str] = set()

    def add(alias: str) -> None:
        normalized = _normalize(alias)
        if not normalized or len(normalized) < 2 or normalized in seen:
            return
        # Don't re-add the full normalized idea_id
        if normalized == _normalize(idea_id):
            return
        seen.add(normalized)
        aliases.append(normalized)

    text = (title or "") + "\n" + (proposal_text[:800] if proposal_text else "")

    # Pattern 1: Family slug declaration
    for m in _FAMILY_SLUG_RE.finditer(text):
        add(m.group(1))

    # Also: explicit Idea ID declaration (sometimes differs from filename)
    for m in _IDEA_ID_BACKTICKED_RE.finditer(text):
        add(m.group(1))

    # Pattern 2: Parenthesized initialism
    for m in _PARENS_INITIALS_RE.finditer(text):
        candidate = m.group(1)
        # Only accept if first letters match the idea-id's tokens (sanity check)
        if _initialism_consistent(candidate, idea_id):
            add(candidate)

    # Pattern 3: Synthesize a few candidate abbreviations from the idea_id tokens
    tokens = [t for t in re.split(r"[-_]+", idea_id) if t]
    if len(tokens) >= 2:
        # Initials of all tokens (e.g., "anti-correlation-nesterov" -> "acn")
        add("".join(t[0] for t in tokens))
        # Truncate the first token to 3-4 chars (e.g., "spectral-momentum" -> "spec")
        # First-token-prefix sometimes shows up in variant slugs.
        if len(tokens[0]) >= 4:
            add(tokens[0][:4])
        if len(tokens[0]) >= 3:
            add(tokens[0][:3])
        # First token + last token's initial (e.g., "trust-region-muon" -> "trm")
        if len(tokens) >= 2:
            add(tokens[0][:2] + tokens[-1][0])

    return aliases


def extract_all_aliases(
    ideas: Iterable[tuple[str, str, str]],
) -> dict[str, list[str]]:
    """Bulk-extract for many ideas. Input: iterable of (idea_id, title, proposal_text)."""
    out: dict[str, list[str]] = {}
    for idea_id, title, proposal_text in ideas:
        aliases = extract_aliases_for_idea(idea_id, title, proposal_text)
        if aliases:
            out[idea_id] = aliases
    return out


def _initialism_consistent(candidate: str, idea_id: str) -> bool:
    """Check whether `candidate` plausibly forms from the idea_id's token initials.

    Used to filter out random parens content like "(see appendix)" or "(N=4)"
    while keeping legit acronyms like "(SPM)" for "spectral-momentum".
    """
    cand_letters = "".join(ch for ch in candidate.lower() if ch.isalpha())
    if not cand_letters:
        return False
    id_tokens = [t for t in re.split(r"[-_]+", idea_id.lower()) if t]
    if not id_tokens:
        return False
    # The candidate's first letter must match the first token's first letter
    return cand_letters[0] == id_tokens[0][0]


def _normalize(s: str) -> str:
    return "".join(ch for ch in s.lower() if ch.isalnum())
