"""Roll up per-idea outcomes from linked runs.

After link_runs sets Run.idea_id, each idea has zero or more associated runs.
This module aggregates them into the Idea record:

- primary_variant_path / all_variant_paths: from the linked runs' variant_path fields
- best_run_id, best_step_to_3_28, best_final_val_loss: the strongest run
- verdict: improved | neutral | regressed | failed_to_run | unknown

"Best" run: lowest step_to_3_28 among runs that hit the target (i.e., step_to_3_28
not None). Ties broken by lowest final_val_loss. When no run hit target, fall back
to lowest final_val_loss. When no run has a final_val_loss either, the idea is
treated as failed_to_run.

Verdict logic, against the Muon-3500 baseline (the original benchmark's starting line):

- improved        : best_step_to_3_28 < 3500
- neutral         : best_step_to_3_28 == 3500 (matched but didn't beat)
- regressed       : best_final_val_loss > 3.28 + noise_margin (didn't hit at all)
- failed_to_run   : no runs had any val_loss data
- unknown         : default when no linked runs exist
"""

from __future__ import annotations

from collections import defaultdict

from .schema import Idea, Run, Verdict

# Muon-3500 baseline. The benchmark's starting line — anything below counts as progress.
BASELINE_STEP_TO_TARGET = 3500
# Empirical noise margin from PI agents' "noise floor" estimates
VAL_LOSS_NOISE_FLOOR = 0.001


def rollup_idea_outcomes(ideas: list[Idea], runs: list[Run]) -> None:
    """Mutate ideas in place: set primary_variant_path, all_variant_paths,
    best_run_id, best_step_to_3_28, best_final_val_loss, verdict."""
    runs_by_idea: dict[str, list[Run]] = defaultdict(list)
    for run in runs:
        if run.idea_id:
            runs_by_idea[run.idea_id].append(run)

    for idea in ideas:
        linked = runs_by_idea.get(idea.idea_id, [])
        if not linked:
            # No linked runs — leave verdict at UNKNOWN
            continue

        # Variant paths (deduplicated, preserving first-seen order)
        seen_variants: list[str] = []
        for r in linked:
            if r.variant_path and r.variant_path not in seen_variants:
                seen_variants.append(r.variant_path)
        idea.all_variant_paths = seen_variants
        if seen_variants:
            idea.primary_variant_path = seen_variants[0]

        # Best run selection
        best = _pick_best_run(linked)
        if best is not None:
            idea.best_run_id = best.run_id
            idea.best_step_to_3_28 = best.step_to_3_28
            idea.best_final_val_loss = best.final_val_loss

        idea.verdict = _derive_verdict(linked, best)


def _pick_best_run(runs: list[Run]) -> Run | None:
    """Pick the strongest run from a list. Preference order:

    1. Runs that hit the target (step_to_3_28 is not None): lowest step_to_3_28,
       tie-broken by lowest final_val_loss.
    2. Otherwise: lowest final_val_loss across all runs.
    3. If no run has a final_val_loss either, return the first one (just for
       traceability — verdict will be failed_to_run).
    """
    hit = [r for r in runs if r.step_to_3_28 is not None]
    if hit:
        return min(
            hit,
            key=lambda r: (
                r.step_to_3_28,
                r.final_val_loss if r.final_val_loss is not None else float("inf"),
            ),
        )
    with_loss = [r for r in runs if r.final_val_loss is not None]
    if with_loss:
        return min(with_loss, key=lambda r: r.final_val_loss)
    return runs[0] if runs else None


def _derive_verdict(runs: list[Run], best: Run | None) -> Verdict:
    """Derive a verdict for an idea from its linked runs and its best."""
    if best is None:
        return Verdict.UNKNOWN

    # Hit the target?
    if best.step_to_3_28 is not None:
        if best.step_to_3_28 < BASELINE_STEP_TO_TARGET:
            return Verdict.IMPROVED
        if best.step_to_3_28 == BASELINE_STEP_TO_TARGET:
            return Verdict.NEUTRAL
        # step_to_3_28 > 3500 is unusual but possible — treat as regressed
        return Verdict.REGRESSED

    # Didn't hit target. Look at final_val_loss
    if best.final_val_loss is None:
        return Verdict.FAILED_TO_RUN

    # Didn't reach 3.28. Outside noise floor = regressed; inside = inconclusive
    if best.final_val_loss > 3.28 + VAL_LOSS_NOISE_FLOOR:
        return Verdict.REGRESSED
    return Verdict.INCONCLUSIVE
