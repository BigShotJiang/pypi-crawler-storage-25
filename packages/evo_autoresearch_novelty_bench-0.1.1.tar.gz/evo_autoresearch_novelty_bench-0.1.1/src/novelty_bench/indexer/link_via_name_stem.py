"""Fuzzy variant linkage via run_id name-stem matching.

Many agent run_ids follow the pattern `<mechanism-stem>-s<N>` (or `-r<N>`),
where the variant file lives at `train_gpt_simple_<stem-with-underscores>.py`
or just `<stem-with-underscores>.py`. Examples:

  v37-newton-muon-s5    ->  train_gpt_simple_v37_newton_muon.py
  rrm-galore-k8-s1      ->  rrm_galore_k8.py
  v17-klshampoo-s0      ->  train_gpt_simple_v17_klshampoo.py

This is the lowest-precision recovery technique (the previous passes are
either exact or evidence-based). We use it only as a final pass for
experiments still unlinked after extract_embedded_sources +
link_via_dynamo_warnings + link_via_sbatch_stubs.

False-positive risk is low because run_id stems in PI's archive are
mechanism-distinctive and rarely collide.

Recovery: ~751 of the remaining 1,211 unlinked runs.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import pandas as pd

_STRIP_SEED = re.compile(r"-s\d+$")
_STRIP_REP = re.compile(r"-r\d+$")


def _stem_candidates(run_id: str) -> list[str]:
    """Variant filename candidates to try for a given run_id."""
    stem = run_id
    while True:
        new = _STRIP_REP.sub("", _STRIP_SEED.sub("", stem))
        if new == stem:
            break
        stem = new
    underscored = stem.replace("-", "_")
    return [
        f"train_gpt_simple_{underscored}.py",
        f"{underscored}.py",
        f"train_gpt_simple_{stem}.py",
        f"{stem}.py",
    ]


def recover_linkages(
    *,
    experiments_df: pd.DataFrame,
    pi_repo: Path,
) -> tuple[pd.DataFrame, dict]:
    unlinked = experiments_df[experiments_df["linked_variant_path"].isna()]
    recovered: dict[str, str] = {}

    for _, row in unlinked.iterrows():
        var_dir = pi_repo / row["wave"] / row["agent"] / "scratchpad" / "variants"
        for candidate in _stem_candidates(row["experiment_id"]):
            if (var_dir / candidate).exists():
                recovered[row["experiment_id"]] = (
                    f"{row['wave']}/{row['agent']}/scratchpad/variants/{candidate}"
                )
                break

    n_updated = 0
    for rid, path in recovered.items():
        mask = experiments_df["experiment_id"] == rid
        experiments_df.loc[mask, "linked_variant_path"] = path
        n_updated += int(mask.sum())

    return experiments_df, {
        "unlinked_scanned": len(unlinked),
        "experiments_updated": n_updated,
    }


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m novelty_bench.indexer.link_via_name_stem")
    p.add_argument("--pi-repo", required=True, type=Path)
    p.add_argument("--data-root", type=Path, default=Path("data/out"))
    args = p.parse_args(argv)

    exp_path = args.data_root / "experiments.parquet"
    if not exp_path.exists():
        print(f"error: {exp_path} not found", file=sys.stderr)
        return 2

    experiments_df = pd.read_parquet(exp_path)
    before = experiments_df["linked_variant_path"].notna().sum()
    print(f"Loaded {len(experiments_df)} experiments; {before} linked before this pass")

    experiments_df, stats = recover_linkages(experiments_df=experiments_df, pi_repo=args.pi_repo)
    after = experiments_df["linked_variant_path"].notna().sum()
    print(f"Stats: {stats}")
    print(f"\nlinked_variant_path coverage: {before} -> {after} (+{after-before})")
    experiments_df.to_parquet(exp_path, index=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
