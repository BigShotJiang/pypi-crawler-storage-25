"""Assign trajectory positions to ideas.

Position = the integer index of when an idea entered the agent's trajectory.
0 = first idea proposed, N-1 = last. Used downstream to define snapshots
(at position k, the proposer sees ideas 0..k-1 and tries to anticipate k+1..N).

Heuristic, applied per (agent, wave):

1. Read THREAD.md as plain text. For each idea, find the byte-offset of its
   first occurrence (case-insensitive substring on the idea_id, with both `-`
   and `_` accepted as separators).
2. Sort ideas by first-mention offset; assign position 0..K.
3. Ideas never mentioned in THREAD.md (audit-style files, ideas only referenced
   by abbreviation we couldn't resolve) get positions K..N appended after the
   THREAD-mentioned ones, ordered by file mtime.

This is best-effort and approximate. The dataset card needs to flag that positions
are heuristic and can differ from the agent's actual proposal order in edge cases.
"""

from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path

from .schema import Agent, Idea, ScratchpadInventory, Wave


def assign_positions(
    ideas: list[Idea],
    inventories: list[ScratchpadInventory],
) -> dict[tuple[Agent, Wave], int]:
    """Set Idea.position in place for every idea, per (agent, wave) trajectory.

    Returns a dict of (agent, wave) -> count_mentioned_in_thread, for reporting.
    """
    ideas_by_scope: dict[tuple[Agent, Wave], list[Idea]] = defaultdict(list)
    for idea in ideas:
        ideas_by_scope[(idea.agent, idea.wave)].append(idea)

    inv_by_scope: dict[tuple[Agent, Wave], ScratchpadInventory] = {
        (i.agent, i.wave): i for i in inventories
    }

    mentioned_counts: dict[tuple[Agent, Wave], int] = {}
    for scope, scope_ideas in ideas_by_scope.items():
        inv = inv_by_scope.get(scope)
        thread_text = _read_thread(inv) if inv is not None else ""
        offsets = _compute_first_offsets(scope_ideas, thread_text)
        _assign_within_scope(scope_ideas, offsets)
        mentioned_counts[scope] = sum(1 for off in offsets.values() if off is not None)
    return mentioned_counts


def _read_thread(inv: ScratchpadInventory) -> str:
    if not inv.thread_md:
        return ""
    try:
        return Path(inv.thread_md).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _compute_first_offsets(
    ideas: list[Idea], thread_text: str
) -> dict[str, int | None]:
    """Return idea_id -> first-mention byte offset, or None if never mentioned."""
    out: dict[str, int | None] = {}
    if not thread_text:
        for idea in ideas:
            out[idea.idea_id] = None
        return out

    lowered = thread_text.lower()
    for idea in ideas:
        out[idea.idea_id] = _first_mention(idea.idea_id, lowered)
    return out


# Match `-` or `_` interchangeably when looking up idea IDs in THREAD prose.
def _first_mention(idea_id: str, lowered_text: str) -> int | None:
    """Find the byte offset of the first mention of an idea_id in THREAD text.

    Tries:
    1. The full idea_id (with both `-` and `_` accepted as separators)
    2. The first token of the idea_id, if it contains digits (catches `abp001`,
       `v3u2950`, etc. — the code prefix used in shorthand references)
    """
    candidates = [idea_id.lower()]
    first_tok = _first_token(idea_id)
    if first_tok and any(c.isdigit() for c in first_tok):
        candidates.append(first_tok.lower())

    best: int | None = None
    for cand in candidates:
        pattern = re.escape(cand).replace("\\-", "[-_]").replace("_", "[-_]")
        try:
            m = re.search(pattern, lowered_text)
        except re.error:
            continue
        if m is not None and (best is None or m.start() < best):
            best = m.start()
    return best


def _first_token(s: str) -> str:
    out: list[str] = []
    for ch in s:
        if ch.isalnum():
            out.append(ch)
        elif out:
            break
    return "".join(out)


def _assign_within_scope(ideas: list[Idea], offsets: dict[str, int | None]) -> None:
    """Sort ideas by (mentioned-first, then offset; unmentioned-last, then mtime),
    then assign sequential positions 0..N."""
    def sort_key(idea: Idea) -> tuple:
        offset = offsets.get(idea.idea_id)
        if offset is not None:
            # Group 0: mentioned in THREAD, sorted by offset
            return (0, offset, 0.0)
        # Group 1: not mentioned, sorted by mtime (older = earlier position)
        ts = idea.timestamp.timestamp() if idea.timestamp is not None else float("inf")
        return (1, 0, ts)

    sorted_ideas = sorted(ideas, key=sort_key)
    for position, idea in enumerate(sorted_ideas):
        idea.position = position
