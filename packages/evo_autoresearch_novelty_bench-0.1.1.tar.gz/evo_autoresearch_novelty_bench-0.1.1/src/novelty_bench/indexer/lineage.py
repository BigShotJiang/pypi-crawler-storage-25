r"""Extract explicit parent/inspired-by lineage from idea writeups.

Reads each idea's proposal_text + novelty_rationale and looks for explicit
references to other ideas in the same (agent, wave). Two reference shapes:

1. Codex-novelty style:
   "Closest local priors: ADV001 (`N + alpha N diag(c)` ...), BAM001 (bias-only ...)"
   → references are uppercase-3-letter + 3-digit codes that map to idea_id
   prefixes (`abp001_adam_biproduct_polar_muon`'s leading code is `abp001`).

2. General style:
   Backtick-quoted slugs like \`some-idea-slug\` are literal mentions of other
   ideas in the same scope.

We use the existing prior_art_cited list as the candidate pool (already extracted
by parse_ideas), filter out arXiv refs (those are external prior art, not
ancestors in the tree), and resolve local idea-code refs to full idea_ids.

If multiple local refs are found, the strongest one (longest text match in the
proposal) becomes parent_idea_id; the rest become inspired_by_ids.

This is rule-based — no LLM. A future phase (lineage v2) can use a reasoning model
over THREAD.md for cases this misses.
"""

from __future__ import annotations

from collections import defaultdict

from .schema import Agent, Idea, Wave


def extract_lineage(ideas: list[Idea]) -> dict[tuple[Agent, Wave], int]:
    """Set Idea.parent_idea_id and Idea.inspired_by_ids in place.

    Returns (agent, wave) -> count_ideas_with_parent, for reporting.
    """
    ideas_by_scope: dict[tuple[Agent, Wave], list[Idea]] = defaultdict(list)
    for idea in ideas:
        ideas_by_scope[(idea.agent, idea.wave)].append(idea)

    parent_counts: dict[tuple[Agent, Wave], int] = {}
    for scope, scope_ideas in ideas_by_scope.items():
        # Build code-prefix lookup so codex/novelty's "ADV001" → full idea_id
        code_to_idea: dict[str, str] = {}
        for idea in scope_ideas:
            code = _first_token(idea.idea_id).lower()
            if code and any(c.isdigit() for c in code):
                code_to_idea[code] = idea.idea_id

        # Full normalized-id lookup, used for literal references like `cross-block-ortho`
        norm_to_idea: dict[str, str] = {
            _normalize(idea.idea_id): idea.idea_id for idea in scope_ideas
        }

        with_parent = 0
        for idea in scope_ideas:
            local_refs = _resolve_local_refs(
                idea,
                code_to_idea=code_to_idea,
                norm_to_idea=norm_to_idea,
            )
            if not local_refs:
                continue
            idea.inspired_by_ids = local_refs
            # First (highest-priority) ref becomes the parent
            idea.parent_idea_id = local_refs[0]
            with_parent += 1
        parent_counts[scope] = with_parent
    return parent_counts


def _resolve_local_refs(
    idea: Idea,
    *,
    code_to_idea: dict[str, str],
    norm_to_idea: dict[str, str],
) -> list[str]:
    """Return a deduplicated list of local idea_ids this idea refers to.

    Order roughly reflects priority (first = most-prominent reference).
    Self-references are excluded.
    """
    refs: list[str] = []
    seen: set[str] = set()

    def add(idea_id: str) -> None:
        if idea_id == idea.idea_id or idea_id in seen:
            return
        seen.add(idea_id)
        refs.append(idea_id)

    # Process prior_art_cited (already extracted by parse_ideas). Skip arXiv refs.
    for ref in idea.prior_art_cited:
        if ref.startswith("arXiv:"):
            continue
        # Codex novelty's 3-letter+3-digit codes (e.g., ADV001)
        norm = ref.lower()
        if norm in code_to_idea:
            add(code_to_idea[norm])

    # Also scan the proposal text for literal idea_id mentions. Find backtick-quoted
    # slugs that match a known idea.
    text = (idea.proposal_text or "") + " " + (idea.novelty_rationale or "")
    for backtick_slug in _extract_backticked_slugs(text):
        norm = _normalize(backtick_slug)
        if norm in norm_to_idea:
            add(norm_to_idea[norm])

    return refs


def _extract_backticked_slugs(text: str) -> list[str]:
    """Pull out content of single-backtick spans. Returns up to ~30 unique slugs."""
    import re

    found: list[str] = []
    seen: set[str] = set()
    for m in re.finditer(r"`([^`\n]{2,60})`", text):
        slug = m.group(1).strip()
        # Heuristic filter: looks like an idea slug (alphanumeric + dashes/underscores)
        if re.fullmatch(r"[A-Za-z][A-Za-z0-9_\-]+", slug):
            if slug not in seen:
                seen.add(slug)
                found.append(slug)
            if len(found) >= 30:
                break
    return found


def _normalize(s: str) -> str:
    return "".join(ch for ch in s.lower() if ch.isalnum())


def _first_token(s: str) -> str:
    out: list[str] = []
    for ch in s:
        if ch.isalnum():
            out.append(ch)
        elif out:
            break
    return "".join(out)
