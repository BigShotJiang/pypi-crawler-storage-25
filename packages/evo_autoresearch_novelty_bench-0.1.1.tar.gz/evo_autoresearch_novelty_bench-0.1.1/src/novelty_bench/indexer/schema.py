"""Pydantic schemas for indexer outputs — Idea, Run, ValCheckpoint.

Fields populated by enrichment steps that may not run on every indexer invocation
(lineage, frontier walk, mechanism extraction) are typed as Optional with default
None.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class Agent(str, Enum):
    CLAUDE_CODE = "claude-code"
    CODEX = "codex"


class Wave(str, Enum):
    V1 = "v1"
    NOVELTY = "novelty"
    V2 = "v2"
    V3 = "v3"


class RunStatus(str, Enum):
    COMPLETED = "completed"
    PREEMPTED = "preempted"
    FAILED = "failed"
    CANCELED = "canceled"
    TIMEOUT = "timeout"
    UNKNOWN = "unknown"


class Verdict(str, Enum):
    IMPROVED = "improved"
    NEUTRAL = "neutral"
    REGRESSED = "regressed"
    FAILED_TO_RUN = "failed_to_run"
    INCONCLUSIVE = "inconclusive"
    UNKNOWN = "unknown"


class RejectionClass(str, Enum):
    NONE = "none"
    FAILED = "failed"
    AUDIT_NONCOMPLIANT = "audit_noncompliant"
    EXISTENCE_KILLED = "existence_killed"
    FAMILY_RULED_OUT = "family_ruled_out"


class ProposalType(str, Enum):
    """Classification of how a variant.py was conceived.

    - FORMAL_IDEA: variant is bound to an ideas/*.md writeup the agent produced
    - BASELINE: variant is a baseline (muon-3500, v1-base, etc.) and not a proposal per se
    - VARIANT_ONLY: variant was launched without a formal idea writeup (HP cell,
      quick test, sub-variant of a family the agent didn't separately write up)
    """

    FORMAL_IDEA = "formal_idea"
    BASELINE = "baseline"
    VARIANT_ONLY = "variant_only"


class InterventionTarget(str, Enum):
    """Fixed taxonomy for mechanism extraction.

    Defined here so it's stable across the indexer and the judge. Populated by
    the mechanism extractor (LLM call); the basic parsing pass leaves it null.
    """

    OPTIMIZER_UPDATE = "optimizer-update"
    PRECONDITIONER = "preconditioner"
    NORMALIZATION = "normalization"
    MOMENTUM_TRACKING = "momentum-tracking"
    EMA_OR_AVERAGING = "ema-or-averaging"
    SCHEDULE = "schedule"
    INIT = "init"
    REGULARIZATION = "regularization"
    LOSS_MODIFICATION = "loss-modification"
    DATA_PIPELINE = "data-pipeline"
    HYPERPARAMETER_ONLY = "hyperparameter-only"
    MULTI_MECHANISM = "multi-mechanism"


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------


class ValCheckpoint(BaseModel):
    """A single validation checkpoint inside a training log."""

    run_id: str
    step: int
    val_loss: float
    train_time_s: float
    step_avg_ms: float


class Run(BaseModel):
    """One executed training run."""

    run_id: str
    agent: Agent
    wave: Wave
    launched_at: Optional[datetime] = None

    # Linked idea — set by the run-to-idea linker (link_runs.py)
    idea_id: Optional[str] = None

    # File pointers (relative to the PI repo root)
    variant_path: Optional[str] = None
    log_path: str

    # Outcomes parsed from runs.jsonl
    final_val_loss: Optional[float] = None
    min_val_loss: Optional[float] = None
    step_to_3_28: Optional[int] = None
    final_step: Optional[int] = None
    train_time_s: Optional[float] = None
    step_avg_ms: Optional[float] = None
    num_val_points: Optional[int] = None
    hit_target: Optional[bool] = None

    status: RunStatus = RunStatus.UNKNOWN
    seed: Optional[int] = None

    # Populated by the val-trajectory parser
    val_trajectory_count: Optional[int] = None


class Idea(BaseModel):
    """One distinct idea proposed."""

    idea_id: str
    agent: Agent
    wave: Wave

    # Filesystem
    source_path: str  # relative path to the ideas/*.md file
    timestamp: Optional[datetime] = None  # file mtime as a v0 stand-in

    # Content
    title: str = ""
    proposal_text: str = ""
    novelty_rationale: Optional[str] = None
    prior_art_cited: list[str] = Field(default_factory=list)
    rule_gate_verdict: Optional[str] = None  # PASS / NON-COMPLIANT / etc., where present

    # Code linkage — set by the outcome rollup after runs are linked
    primary_variant_path: Optional[str] = None
    all_variant_paths: list[str] = Field(default_factory=list)

    # Outcome rollup — set by rollup.py once linked runs exist
    best_run_id: Optional[str] = None
    best_step_to_3_28: Optional[int] = None
    best_final_val_loss: Optional[float] = None
    verdict: Verdict = Verdict.UNKNOWN

    # Trajectory position — set by position.py (THREAD.md cross-reference + mtime fallback)
    position: Optional[int] = None

    # Lineage — set by lineage.py (explicit prior-art references in idea writeups)
    parent_idea_id: Optional[str] = None
    inspired_by_ids: list[str] = Field(default_factory=list)

    # Rejection state — set by rejection.py (combines failure, audit, stuck-detector, existence-kill signals)
    rejection_class: RejectionClass = RejectionClass.NONE
    rejection_evidence_text: Optional[str] = None
    rejected_at_position: Optional[int] = None

    # Frontier walk membership — set by the frontier-walk module once it's wired in
    on_frontier_walk: Optional[bool] = None

    # Mechanism extraction — populated by the LLM extractor at dataset-build time
    mechanism_extracted: Optional[dict[str, Any]] = None


class Proposal(BaseModel):
    """One distinct variant.py the agent created — the unit the judge scores.

    Whereas Idea is one entry in ideas/*.md (formal proposal writeup), Proposal
    is one .py file in scratchpad/variants/. A formal idea typically expands into
    multiple variants (HP sweep cells, seed reps, micro-edits) — each becomes its
    own Proposal row, so the catalog spans all ~3,249 distinct things proposed
    rather than only the ~646 written-up ideas.
    """

    proposal_id: str  # f"{agent}--{wave}--{variant_stem}"
    agent: Agent
    wave: Wave

    # File pointers
    variant_path: str  # relative to PI repo root
    variant_stem: str  # filename without .py
    sha256: str
    file_size_bytes: int

    # Earliest time we have signal this proposal existed: prefer the first run's
    # launched_at when any run references this variant; fall back to file mtime.
    first_seen_at: Optional[datetime] = None
    first_seen_source: Optional[str] = None  # "run_launched_at" or "mtime"

    # Linkage
    parent_idea_id: Optional[str] = None  # ideas/*.md writeup that proposed this family
    run_ids: list[str] = Field(default_factory=list)
    num_runs: int = 0

    proposal_type: ProposalType = ProposalType.VARIANT_ONLY

    # Rollup over the variant's runs (mirrors Idea rollup but per-variant)
    best_run_id: Optional[str] = None
    best_step_to_3_28: Optional[int] = None
    best_final_val_loss: Optional[float] = None
    verdict: Verdict = Verdict.UNKNOWN

    # Position in the parent scratchpad's chronology — assigned analogously to
    # Idea.position so the judge can answer "what existed at position k".
    position: Optional[int] = None

    # Top-of-file docstring (first 800 chars) — useful raw text for the
    # mechanism extractor even when no ideas/*.md writeup exists.
    header_docstring: Optional[str] = None


class Experiment(BaseModel):
    """One research attempt — the benchmark's unit of evaluation.

    An Experiment is "an agent tried something at time T and got result R".
    Whereas Run captures raw launch + outcome data and Proposal captures the
    variant.py code, Experiment is the benchmark-facing view: every research
    attempt gets a description text + an embedding + a position in its scope.

    For ~63% of runs the description comes from a parent idea writeup; for the
    rest it's built from the variant header docstring, the run_id shorthand,
    or an LLM-generated 1-2 sentence summary.
    """

    experiment_id: str  # equals Run.run_id
    agent: Agent
    wave: Wave
    first_seen_at: Optional[datetime] = None  # from Run.launched_at (~99.5% populated)

    # Outcome
    verdict: Verdict = Verdict.UNKNOWN
    step_to_3_28: Optional[int] = None
    final_val_loss: Optional[float] = None
    hit_target: Optional[bool] = None

    # Linkage (sparse; fields are None when the link couldn't be made)
    linked_variant_path: Optional[str] = None
    linked_proposal_id: Optional[str] = None
    linked_idea_id: Optional[str] = None
    seed: Optional[int] = None

    # Position within (agent, wave) by first_seen_at — 1-indexed
    position: Optional[int] = None

    # Frontier-walk membership (joins running best by >=100 steps)
    on_frontier_walk: bool = False

    # Description text — what we embed for similarity comparisons
    description_text: str = ""
    description_source: str = ""  # "idea_writeup" | "variant_docstring" | "run_id_only" | "llm_generated"

    # Per-run source code recovered from the log's embedded ====...==== block.
    # When set, this is the ACTUAL code that ran (gold standard) — distinct from
    # linked_variant_path which points at the (possibly post-edited) variants/
    # file. None for claude-code runs (their logs don't embed source).
    recovered_source_path: Optional[str] = None
    recovered_source_sha256: Optional[str] = None


class Snapshot(BaseModel):
    """One agent-visible state of the world — the input to build_workspace().

    A snapshot describes "what the agent had seen by position k in (agent, wave)".
    The judge uses it to score a set of proposals: prior_* tells us what is NOT
    novel (already proposed); future_* tells us which proposals end up being
    breakthroughs (used to compute the lookahead-impact term).

    Built by the indexer's snapshots module after ideas/proposals are linked
    and rolled up. build_workspace(snapshot, scaffold_dir, output_dir) renders
    the actual AGENTS.md / scratchpad files the proposer agent sees.
    """

    snapshot_id: str  # f"snap_{agent}_{wave}_pos{k:04d}"
    agent: Agent
    wave: Wave
    k: int                          # 1-indexed position cutoff (proposals at pos <= k are visible)
    wall_clock: Optional[datetime] = None
    split: str                      # "dev" or "test"
    wave_constraint: str            # short prose describing the wave's gating rule

    # Current recipe at position k — the most-recently-improved experiment the
    # agent has seen succeed in this scope by wall_clock <= T. Anchors the
    # workspace's "current best you have" framing.
    current_recipe_experiment_id: Optional[str] = None
    current_recipe_step_to_3_28: Optional[int] = None

    # Prior ideas/experiments — what the agent has already considered/tested
    prior_idea_ids: list[str] = Field(default_factory=list)
    prior_experiment_ids: list[str] = Field(default_factory=list)

    # Future breakthrough sets — used to compute lookahead impact
    # 1) Ideas that ended up on the canonical frontier walk (≥100-step improver)
    future_frontier_idea_ids: list[str] = Field(default_factory=list)
    # 2) Ideas with verdict=improved at pos>k (broader pool for partial credit)
    future_improved_idea_ids: list[str] = Field(default_factory=list)
    # 3) Experiments with verdict=improved at wall_clock > T (finest pool)
    future_improved_experiment_ids: list[str] = Field(default_factory=list)
    # 4) Experiments that beat Muon-3500 baseline (any step_to_3_28 < 3500)
    future_frontier_experiment_ids: list[str] = Field(default_factory=list)

    # Rejected priors — ideas the agent has seen be killed via audits
    rejected_idea_ids: list[str] = Field(default_factory=list)

    # Other-agent visible — time-bounded by wall_clock, same wave
    other_agent_visible_idea_ids: list[str] = Field(default_factory=list)
    other_agent_visible_experiment_ids: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Intermediate representations used during walking / parsing
# ---------------------------------------------------------------------------


class ScratchpadInventory(BaseModel):
    """Files discovered for one (agent, wave) scratchpad."""

    agent: Agent
    wave: Wave

    scratchpad_dir: str  # absolute
    runs_jsonl: Optional[str] = None
    thread_md: Optional[str] = None
    plan_md: Optional[str] = None
    goal_md: Optional[str] = None
    agents_md: Optional[str] = None
    picklist_md: Optional[str] = None
    audits_md: Optional[str] = None

    ideas_dir: Optional[str] = None
    papers_dir: Optional[str] = None
    variants_dir: Optional[str] = None
    runs_logs_dir: Optional[str] = None
    rule_checks_dir: Optional[str] = None

    idea_files: list[str] = Field(default_factory=list)
    paper_files: list[str] = Field(default_factory=list)
    variant_files: list[str] = Field(default_factory=list)
    run_log_files: list[str] = Field(default_factory=list)
    rule_check_files: list[str] = Field(default_factory=list)


class RepoInventory(BaseModel):
    """Top-level inventory across all (agent, wave) combinations."""

    repo_root: str
    scratchpads: list[ScratchpadInventory]
