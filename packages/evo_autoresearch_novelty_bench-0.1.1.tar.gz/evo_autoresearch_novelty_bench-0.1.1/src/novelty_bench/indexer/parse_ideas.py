"""Parse idea markdown files into Idea records.

Format conventions across agents and waves vary widely:

- Codex novelty wave: highly structured. `## Proposal`, `## Rule Gate`, `## Novelty Gate`
  sections, often with verdict tokens like PASS / NOVEL-ENOUGH / NON-COMPLIANT.
- Codex v1/v2/v3 (open waves): looser, often a single proposal with implementation notes,
  no novelty gate.
- Claude Code novelty wave: structured but headings are numbered ("## 1. Cross-check
  existing ideas").
- Claude Code v1: very free-form prose. The lone v1 file (trasmuon.md) has its own
  layout entirely.

Strategy: extract what's present, leave fields None when absent. Section extraction is
a simple `## heading` scanner — take everything between one `## ` line and the next.

This module populates basic content fields only. Position, lineage, rejection_class,
on_frontier_walk, and mechanism_extracted are filled by dedicated modules that run
after parsing.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path

from .schema import Idea, ScratchpadInventory, Verdict

# Headings we care about. Match by lowercased prefix to absorb minor variations like
# "## Novelty Gate", "## Novelty gate", "## NOVELTY GATE", "## 2. Novelty gate".
_SECTION_KEYS: dict[str, tuple[str, ...]] = {
    "proposal": ("proposal",),
    "novelty_gate": ("novelty gate", "novelty", "existence check"),
    "rule_gate": ("rule gate", "rule check", "rules compliance"),
    "prior_art": ("prior art", "cross-check existing ideas", "closest priors"),
}

# arXiv reference pattern: matches "arXiv 2602.13498", "arxiv:2602.13498", "(arXiv 2602.13498)"
_ARXIV_RE = re.compile(r"\barxiv[:\s]*([0-9]{4}\.[0-9]{4,5})", re.IGNORECASE)
# Local idea-ID references (uppercase 3-letter + digits): "ADV001", "BAM001"
_LOCAL_ID_RE = re.compile(r"\b([A-Z]{3}\d{3})\b")
# Rule-gate verdict tokens (case-insensitive). Order matters: longer phrases first.
_VERDICT_TOKENS: tuple[str, ...] = (
    "NON-COMPLIANT",
    "NONCOMPLIANT",
    "NOT COMPLIANT",
    "NOVEL-ENOUGH",
    "PASS CONDITIONAL",
    "PASS",
    "FAIL",
    "KILL",
)


def parse_idea_file(path: str | Path, inv: ScratchpadInventory) -> Idea | None:
    """Parse one idea markdown file into an Idea record.

    Returns None if the file is empty or unreadable.
    """
    p = Path(path)
    if not p.exists():
        return None
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    if not text.strip():
        return None

    idea_id = p.stem  # filename without .md
    title = _extract_title(text) or idea_id
    sections = _split_sections(text)

    proposal_text = sections.get("proposal") or text  # fall back to full text if no section
    novelty_rationale = sections.get("novelty_gate")
    rule_gate_text = sections.get("rule_gate") or ""
    rule_gate_verdict = _extract_verdict(rule_gate_text) if rule_gate_text else None

    # Prior art: pull arXiv refs from novelty gate + cross-check section + full doc as fallback
    prior_art_corpus = (
        (novelty_rationale or "")
        + " "
        + (sections.get("prior_art") or "")
        + " "
        + text
    )
    prior_art_cited = _extract_prior_art(prior_art_corpus)

    timestamp = _file_mtime(p)

    return Idea(
        idea_id=idea_id,
        agent=inv.agent,
        wave=inv.wave,
        source_path=_relativize(p, inv),
        timestamp=timestamp,
        title=title,
        proposal_text=proposal_text,
        novelty_rationale=novelty_rationale,
        prior_art_cited=prior_art_cited,
        rule_gate_verdict=rule_gate_verdict,
        verdict=Verdict.UNKNOWN,  # populated when runs are linked
    )


def parse_all_ideas(inv: ScratchpadInventory) -> list[Idea]:
    """Parse every ideas/*.md file in a scratchpad."""
    out: list[Idea] = []
    for path in inv.idea_files:
        idea = parse_idea_file(path, inv)
        if idea is not None:
            out.append(idea)
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_title(text: str) -> str | None:
    """Return the first H1 line content (without the `# ` prefix), stripped."""
    for line in text.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("# "):
            return stripped[2:].strip()
        if stripped.startswith("#") and len(stripped) > 1 and stripped[1] != "#":
            return stripped[1:].strip()
    return None


def _split_sections(text: str) -> dict[str, str]:
    """Split a markdown doc into sections keyed by canonical name.

    Walks the file line by line. When a `## ` heading is encountered, look up
    which canonical section it represents (if any) and accumulate subsequent
    lines until the next `## ` heading.
    """
    sections: dict[str, list[str]] = {}
    current_key: str | None = None
    for line in text.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("## "):
            heading = stripped[3:].strip().lower()
            # Strip leading number like "1. " or "2. "
            heading_clean = re.sub(r"^\d+\.\s*", "", heading)
            current_key = _match_canonical_section(heading_clean)
            if current_key and current_key not in sections:
                sections[current_key] = []
        elif current_key is not None:
            sections[current_key].append(line)

    return {key: "\n".join(lines).strip() for key, lines in sections.items() if lines}


def _match_canonical_section(heading: str) -> str | None:
    """Map a free-form section heading to a canonical key (or None)."""
    for canonical, aliases in _SECTION_KEYS.items():
        for alias in aliases:
            if heading.startswith(alias):
                return canonical
    return None


def _extract_verdict(rule_gate_text: str) -> str | None:
    """Find the first verdict token in a Rule Gate section."""
    upper = rule_gate_text.upper()
    for token in _VERDICT_TOKENS:
        if token in upper:
            return token
    return None


def _extract_prior_art(text: str) -> list[str]:
    """Extract a deduplicated list of references cited as prior art.

    Picks up arXiv IDs and local idea IDs (uppercase-3-letter + 3-digit format used
    by Codex novelty wave). Returns up to ~30 unique refs to keep rows small.
    """
    refs: list[str] = []
    seen: set[str] = set()
    for match in _ARXIV_RE.finditer(text):
        ref = f"arXiv:{match.group(1)}"
        if ref not in seen:
            seen.add(ref)
            refs.append(ref)
    for match in _LOCAL_ID_RE.finditer(text):
        ref = match.group(1)
        if ref not in seen:
            seen.add(ref)
            refs.append(ref)
        if len(refs) >= 30:
            break
    return refs


def _file_mtime(p: Path) -> datetime | None:
    """Return file mtime as a UTC datetime. Used as a v0 stand-in for position
    until THREAD.md cross-reference fills in actual positions."""
    try:
        return datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc)
    except OSError:
        return None


def _relativize(p: Path, inv: ScratchpadInventory) -> str:
    """Return the path relative to the PI repo root.

    scratchpad_dir is `<pi_repo>/<wave>/<agent>/scratchpad`, so the repo root is
    three parents up. Keeping all path columns repo-relative makes downstream
    consumers (build_workspace, dataset packaging) consistent.
    """
    try:
        repo_root = Path(inv.scratchpad_dir).parent.parent.parent
        return str(p.relative_to(repo_root))
    except ValueError:
        return str(p)
