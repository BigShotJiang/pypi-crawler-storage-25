"""Parse training logs into validation checkpoint trajectories.

Every modded-nanogpt training run logs lines like:

    step:0/3200 val_loss:10.82584 train_time:0.016s step_avg:16.50ms
    step:1/3200 train_time:56.900s step_avg:56899.90ms
    step:125/3200 val_loss:6.42 train_time:71.234s step_avg:569.87ms
    ...

We extract every line that carries a val_loss (validation checkpoints — typically every
~125 steps and at the end). Train-only lines (no val_loss) are skipped — we don't need
per-step timing detail for the benchmark.

Port of the PI repo's scratchpad/parse_log.py, but generalized to return all records
rather than only the summary, and tolerant of malformed/truncated logs.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

from .schema import ScratchpadInventory, ValCheckpoint

# The exact pattern used in the PI parser. Tolerates extra whitespace and EMA variants.
_VAL_PATTERN = re.compile(
    r"^step:(?P<step>\d+)/(?P<total>\d+)\s+"
    r"val_loss:(?P<loss>[0-9.]+)\s+"
    r"train_time:(?P<time>[0-9.]+)s\s+"
    r"step_avg:(?P<step_avg>[0-9.]+)ms"
)


def parse_val_trajectory(log_path: str | Path, run_id: str) -> list[ValCheckpoint]:
    """Parse one training log into ValCheckpoint records.

    Returns an empty list on missing/unreadable files or no val_loss lines found
    (preempted-mid-init logs sometimes have zero val points).
    """
    p = Path(log_path)
    if not p.exists() or not p.is_file():
        return []

    records: list[ValCheckpoint] = []
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    for line in text.splitlines():
        m = _VAL_PATTERN.match(line.strip())
        if not m:
            continue
        try:
            records.append(
                ValCheckpoint(
                    run_id=run_id,
                    step=int(m.group("step")),
                    val_loss=float(m.group("loss")),
                    train_time_s=float(m.group("time")),
                    step_avg_ms=float(m.group("step_avg")),
                )
            )
        except (ValueError, TypeError):
            # Malformed numbers — skip the line, keep parsing
            continue
    return records


def parse_all_val_trajectories(
    inv: ScratchpadInventory,
) -> Iterable[tuple[str, Path, list[ValCheckpoint]]]:
    """Yield (run_id, source_log_path, trajectory) for every training log in the scratchpad.

    Skips `.console.log` and `.sbatch.log` siblings when a canonical `.log`
    exists for the same run — otherwise we'd parse the same checkpoints twice
    (val_loss lines are echoed to both files in the PI agents' launch wrapper).

    For each canonical log emitted, the second element is the absolute Path the
    parser read from. Callers should relativize it to the repo root when writing
    back to a Run.log_path field. When BOTH `.log` and a `.console.log` sibling
    contain val checkpoints (the canonical one parses to non-empty), we always
    prefer the canonical. When the canonical exists but has zero checkpoints
    (codex/v1's `.log` files are actually variant source code, not stdout) we
    fall back to the `.console.log` sidecar.
    """
    canonical: dict[str, Path] = {}
    sidecars: dict[str, Path] = {}  # one sidecar per run_id, prefer .console.log over .sbatch.log
    for log_str in inv.run_log_files:
        p = Path(log_str)
        run_id = _run_id_from_log_name(p.name)
        if not run_id:
            continue
        if p.name.endswith(".log") and not p.name.endswith((".console.log", ".sbatch.log")):
            canonical[run_id] = p
        else:
            existing = sidecars.get(run_id)
            if existing is None or p.name.endswith(".console.log"):
                sidecars[run_id] = p

    # Emit canonical; fall back to sidecar when canonical produces no checkpoints
    seen: set[str] = set()
    for run_id, p in canonical.items():
        traj = parse_val_trajectory(p, run_id)
        if not traj and run_id in sidecars:
            sidecar = sidecars[run_id]
            traj = parse_val_trajectory(sidecar, run_id)
            if traj:
                yield run_id, sidecar, traj
                seen.add(run_id)
                continue
        yield run_id, p, traj
        seen.add(run_id)
    for run_id, p in sidecars.items():
        if run_id in seen:
            continue
        traj = parse_val_trajectory(p, run_id)
        if traj:
            yield run_id, p, traj
            seen.add(run_id)


def _run_id_from_log_name(name: str) -> str | None:
    """Strip common suffixes from a log filename to get a run_id."""
    for suffix in (".console.log", ".sbatch.log", ".sbatch.out", ".log", ".txt", ".out"):
        if name.endswith(suffix):
            return name[: -len(suffix)] or None
    return name or None
