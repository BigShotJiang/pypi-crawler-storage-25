"""Indexer: turns the raw Prime Intellect speedrun repo into normalized parquet tables.

Walks the repo, parses ideas/runs/logs, enriches with run-idea linkage, outcome
rollup, trajectory positions, parent/inspired-by lineage, and rejection classification.
Emits ideas.parquet, runs.parquet, val_trajectories.parquet, manifest.json.

Mechanism extraction (LLM-based, optional, populates Idea.mechanism_extracted),
snapshot construction, and embedding pre-computation land separately as their
own modules — none are wired in yet.

Re-run when the source repo or schema changes:
    python -m novelty_bench.indexer --pi-repo <path> --out <dir>
"""
