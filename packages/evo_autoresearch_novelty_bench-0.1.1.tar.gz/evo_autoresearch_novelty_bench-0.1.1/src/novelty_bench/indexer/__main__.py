"""Module entrypoint: `python -m novelty_bench.indexer --pi-repo <path> --out <dir>`.

Walks the PI repo, parses ideas/runs/logs, enriches with linkage/rollup/position/
lineage, writes parquet outputs + manifest. Run when you need to regenerate the
dataset from a fresh PI clone.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from .. import __version__
from .backfill_outcomes import backfill_run_outcomes, derive_run_status
from .experiments import build_experiments, summarize as summarize_experiments
from .frontier import apply_frontier_walk, compute_frontier_walks
from .lineage import extract_lineage
from .link_runs import link_runs_to_ideas
from .log_timestamps import extract_all_log_timestamps
from .parse_ideas import parse_all_ideas
from .parse_proposals import parse_all_proposals
from .parse_rejections import parse_rejections_all
from .parse_runs import parse_runs_jsonl
from .parse_val_trajectories import parse_all_val_trajectories
from .position import assign_positions
from .rejection import apply_rejections, summarize_rejections
from .rollup import rollup_idea_outcomes
from .schema import Agent, Run, Wave
from .snapshots import build_snapshots
from .stuck_detector import collect_ruled_out_idea_ids, compute_family_rule_outs
from .thread_walk import collect_thread_walk_links
from .walk import summarize_inventory, walk_pi_repo


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m novelty_bench.indexer",
        description="Index the Prime Intellect speedrun repo into normalized parquet tables.",
    )
    parser.add_argument(
        "--pi-repo",
        type=Path,
        required=True,
        help="Path to a cloned experiments-autonomous-speedrunning repo.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("data/out"),
        help="Output directory for parquet tables + manifest (default: data/out).",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Print per-scratchpad detail.",
    )
    args = parser.parse_args(argv)

    pi_repo = args.pi_repo.resolve()
    out = args.out.resolve()
    if not pi_repo.is_dir():
        print(f"error: --pi-repo does not exist or is not a directory: {pi_repo}", file=sys.stderr)
        return 2
    out.mkdir(parents=True, exist_ok=True)

    print(f"Walking {pi_repo}")
    inv = walk_pi_repo(pi_repo)
    if args.verbose:
        print(summarize_inventory(inv))

    print("Extracting launch timestamps from training-log headers")
    log_ts = extract_all_log_timestamps(pi_repo)
    print(f"  recovered timestamps for {len(log_ts):,} logs")

    all_ideas = []
    all_runs = []
    all_val_records = []
    per_scratchpad_counts: dict[str, dict[str, int]] = {}

    for s in inv.scratchpads:
        key = f"{s.agent.value}/{s.wave.value}"
        ideas = parse_all_ideas(s)
        runs_by_id = {r.run_id: r for r in parse_runs_jsonl(s)}

        val_records_for_scratchpad = 0
        for run_id, source_log_path, traj in parse_all_val_trajectories(s):
            if not traj:
                continue
            val_records_for_scratchpad += len(traj)
            all_val_records.extend(traj)
            authoritative_log_path = _relativize_to_repo(str(source_log_path), str(pi_repo))
            if run_id not in runs_by_id:
                runs_by_id[run_id] = Run(
                    run_id=run_id,
                    agent=s.agent,
                    wave=s.wave,
                    log_path=authoritative_log_path,
                    val_trajectory_count=len(traj),
                )
            else:
                # Overwrite log_path with the file we actually parsed — runs.jsonl
                # may have pointed to a sibling or had an empty path.
                runs_by_id[run_id].log_path = authoritative_log_path
                runs_by_id[run_id].val_trajectory_count = len(traj)

        all_ideas.extend(ideas)
        all_runs.extend(runs_by_id.values())

        per_scratchpad_counts[key] = {
            "ideas": len(ideas),
            "runs": len(runs_by_id),
            "val_records": val_records_for_scratchpad,
        }
        if args.verbose:
            print(
                f"  {key}: ideas={len(ideas)}  runs={len(runs_by_id)}  "
                f"val_records={val_records_for_scratchpad}"
            )

    # Backfill launched_at from log-header timestamps where missing
    backfilled = 0
    for r in all_runs:
        if r.launched_at is not None:
            continue
        ts = log_ts.get(r.run_id)
        if ts is None:
            continue
        try:
            r.launched_at = datetime.fromisoformat(ts)
            backfilled += 1
        except ValueError:
            pass
    print(f"  backfilled launched_at from log headers for {backfilled:,} runs")
    timestamped_total = sum(1 for r in all_runs if r.launched_at is not None)
    print(f"  total runs with launched_at: {timestamped_total:,}/{len(all_runs):,}")

    print("Backfilling run outcomes from val trajectories")
    outcome_backfilled = backfill_run_outcomes(all_runs, all_val_records)
    with_step = sum(1 for r in all_runs if r.step_to_3_28 is not None)
    with_val_loss = sum(1 for r in all_runs if r.final_val_loss is not None)
    print(
        f"  backfilled outcomes for {outcome_backfilled:,} runs; "
        f"now {with_step:,} have step_to_3_28, {with_val_loss:,} have final_val_loss"
    )
    status_derived = derive_run_status(all_runs, all_val_records)
    print(f"  derived status for {status_derived:,} previously-unknown runs")

    print("Linking runs to ideas")
    # Phase A: heuristic prefix/substring + abbreviation matching (in-place baseline)
    # Phase B: augment with THREAD-walk cross-references
    runs_by_scope: dict[tuple[Agent, Wave], list[Run]] = {}
    for r in all_runs:
        runs_by_scope.setdefault((r.agent, r.wave), []).append(r)
    thread_links = collect_thread_walk_links(inv.scratchpads, all_ideas, runs_by_scope)
    print(f"  thread-walk found {len(thread_links)} run→idea links")

    # Phase C: external LLM-matcher links, if a saved file exists
    llm_links = _load_llm_links(out)
    if llm_links:
        print(f"  llm-matcher contributing {len(llm_links)} run→idea links")

    external_links = {**thread_links, **llm_links}  # llm overrides thread on conflict
    link_stats = link_runs_to_ideas(all_runs, all_ideas, external_links=external_links)
    total_linked = sum(s.linked_runs for s in link_stats)
    print(
        f"  total linked {total_linked}/{len(all_runs)} runs "
        f"({100 * total_linked / max(1, len(all_runs)):.1f}%)"
    )

    print("Rolling up idea outcomes")
    rollup_idea_outcomes(all_ideas, all_runs)
    with_verdict = sum(1 for i in all_ideas if i.verdict.value != "unknown")
    print(f"  {with_verdict}/{len(all_ideas)} ideas with verdict")

    print("Assigning idea positions")
    position_counts = assign_positions(all_ideas, inv.scratchpads)
    thread_mentioned = sum(position_counts.values())
    print(
        f"  {thread_mentioned}/{len(all_ideas)} ideas found in THREAD.md "
        f"(remainder use mtime ordering)"
    )

    print("Extracting lineage")
    lineage_counts = extract_lineage(all_ideas)
    with_parent = sum(lineage_counts.values())
    print(f"  {with_parent}/{len(all_ideas)} ideas have a parent_idea_id")

    print("Classifying rejections")
    ideas_by_scope: dict = {}
    for i in all_ideas:
        ideas_by_scope.setdefault((i.agent, i.wave), []).append(i.idea_id)
    audit_records = parse_rejections_all(inv.scratchpads, ideas_by_scope)

    # Stuck detector needs DataFrames; build temporary ones from current state.
    runs_df_tmp = pd.DataFrame([r.model_dump(mode="json") for r in all_runs])
    ideas_df_tmp = pd.DataFrame([i.model_dump(mode="json") for i in all_ideas])
    rule_outs = compute_family_rule_outs(runs_df_tmp, ideas_df_tmp)
    family_rule_outs = collect_ruled_out_idea_ids(rule_outs)

    apply_rejections(all_ideas, audit_records, family_rule_outs)
    rejection_counts = summarize_rejections(all_ideas)
    print(
        "  rejection_class distribution: "
        + ", ".join(f"{k}={v}" for k, v in sorted(rejection_counts.items()) if v)
    )

    print("Computing frontier walks")
    runs_df_tmp = pd.DataFrame([r.model_dump(mode="json") for r in all_runs])
    ideas_df_tmp = pd.DataFrame([i.model_dump(mode="json") for i in all_ideas])
    frontier_entries = compute_frontier_walks(runs_df_tmp, ideas_df_tmp)
    on_frontier = apply_frontier_walk(all_ideas, frontier_entries)
    print(f"  {on_frontier}/{len(all_ideas)} ideas on a frontier walk")

    print("Building proposal catalog (one row per variant.py)")
    # v1/codex and claude-code waves don't record `variant` in runs.jsonl, and
    # log-content matching fails for them (v1/codex mutates variant files
    # post-launch; claude-code logs carry no embedded source). Proposals from
    # those scratchpads land in the catalog with num_runs=0 — they are still
    # indexed (so the agent's full proposal vocabulary is captured), just
    # without per-variant verdicts.
    proposals = parse_all_proposals(inv.scratchpads, all_runs, pi_repo)
    _assign_proposal_positions(proposals)
    type_counts: dict[str, int] = {}
    for p in proposals:
        type_counts[p.proposal_type.value] = type_counts.get(p.proposal_type.value, 0) + 1
    with_parent_idea = sum(1 for p in proposals if p.parent_idea_id)
    with_runs = sum(1 for p in proposals if p.num_runs > 0)
    print(
        f"  {len(proposals):,} proposals  "
        f"({with_parent_idea:,} linked to an idea writeup; "
        f"{with_runs:,} have ≥1 run)"
    )
    print(
        "  proposal_type: "
        + ", ".join(f"{k}={v:,}" for k, v in sorted(type_counts.items()))
    )

    print("Building experiments catalog (one row per training run)")
    experiments = build_experiments(all_runs, all_ideas, proposals)
    exp_summary = summarize_experiments(experiments)
    print(
        f"  {exp_summary['total_experiments']:,} experiments  "
        f"({exp_summary['with_first_seen_at']:,} have real timestamps)"
    )
    print(f"  description_source: {exp_summary['by_description_source']}")
    print(f"  verdicts: {exp_summary['by_verdict']}")

    print("Writing parquet outputs")
    ideas_df = pd.DataFrame([i.model_dump(mode="json") for i in all_ideas])
    runs_df = pd.DataFrame([r.model_dump(mode="json") for r in all_runs])
    val_df = pd.DataFrame([v.model_dump(mode="json") for v in all_val_records])
    proposals_df = pd.DataFrame([p.model_dump(mode="json") for p in proposals])
    experiments_df = pd.DataFrame([e.model_dump(mode="json") for e in experiments])

    ideas_path = out / "ideas.parquet"
    runs_path = out / "runs.parquet"
    val_path = out / "val_trajectories.parquet"
    proposals_path = out / "proposals.parquet"
    experiments_path = out / "experiments.parquet"

    ideas_df.to_parquet(ideas_path, index=False)
    runs_df.to_parquet(runs_path, index=False)
    val_df.to_parquet(val_path, index=False)
    proposals_df.to_parquet(proposals_path, index=False)
    experiments_df.to_parquet(experiments_path, index=False)

    print("Building snapshots (stratified across position arc per scope)")
    snapshots = build_snapshots(ideas_df, experiments_df)
    snapshots_df = pd.DataFrame([s.model_dump(mode="json") for s in snapshots])
    snapshots_path = out / "snapshots.parquet"
    snapshots_df.to_parquet(snapshots_path, index=False)
    split_counts = snapshots_df["split"].value_counts().to_dict() if len(snapshots_df) else {}
    scope_counts = (
        snapshots_df.groupby(["agent", "wave"]).size().to_dict()
        if len(snapshots_df) else {}
    )
    print(
        f"  {len(snapshots)} snapshots  "
        f"(split: {split_counts})  "
        f"per-scope: {{{', '.join(f'{k}={v}' for k, v in scope_counts.items())}}}"
    )

    # Counts by verdict (collected after rollup ran)
    verdict_counts: dict[str, int] = {}
    for i in all_ideas:
        verdict_counts[i.verdict.value] = verdict_counts.get(i.verdict.value, 0) + 1
    best_step = min(
        (i.best_step_to_3_28 for i in all_ideas if i.best_step_to_3_28 is not None),
        default=None,
    )

    manifest = {
        "dataset_version": __version__,
        "generated_at": datetime.now(tz=timezone.utc).isoformat(timespec="seconds"),
        "source_repo": str(pi_repo),
        "tables": {
            "ideas.parquet": {"rows": len(ideas_df), "path": str(ideas_path)},
            "runs.parquet": {"rows": len(runs_df), "path": str(runs_path)},
            "val_trajectories.parquet": {"rows": len(val_df), "path": str(val_path)},
            "proposals.parquet": {"rows": len(proposals_df), "path": str(proposals_path)},
            "experiments.parquet": {"rows": len(experiments_df), "path": str(experiments_path)},
            "snapshots.parquet": {"rows": len(snapshots_df), "path": str(snapshots_path)},
        },
        "by_scratchpad": per_scratchpad_counts,
        "summary": {
            "ideas_by_verdict": verdict_counts,
            "ideas_by_rejection_class": rejection_counts,
            "ideas_with_parent_id": with_parent,
            "ideas_in_thread_md": thread_mentioned,
            "best_step_to_3_28": best_step,
            "runs_linked_to_ideas": {
                "total_runs": len(all_runs),
                "linked_runs": sum(s.linked_runs for s in link_stats),
                "overall_link_rate": round(
                    sum(s.linked_runs for s in link_stats) / max(1, len(all_runs)), 3
                ),
                "per_scratchpad": [
                    {
                        "agent": s.agent.value,
                        "wave": s.wave.value,
                        "total_runs": s.total_runs,
                        "linked_runs": s.linked_runs,
                        "unique_ideas_linked": s.unique_ideas_linked,
                        "link_rate": round(s.link_rate, 3),
                    }
                    for s in link_stats
                ],
            },
            "audit_records_parsed": len(audit_records),
            "stuck_families_ruled_out": len(rule_outs),
            "ideas_on_frontier_walk": on_frontier,
            "frontier_steps_total": len(frontier_entries),
            "proposals_total": len(proposals),
            "proposals_by_type": type_counts,
            "proposals_linked_to_idea": with_parent_idea,
            "proposals_with_runs": with_runs,
            "snapshots_total": len(snapshots),
            "snapshots_by_split": split_counts,
            "snapshots_by_scope": {f"{k[0]}/{k[1]}": v for k, v in scope_counts.items()},
            "experiments_summary": exp_summary,
        },
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("\nDone.")
    print(f"  ideas:            {len(ideas_df):>8,} rows  ->  {ideas_path}")
    print(f"  runs:             {len(runs_df):>8,} rows  ->  {runs_path}")
    print(f"  val_trajectories: {len(val_df):>8,} rows  ->  {val_path}")
    print(f"  proposals:        {len(proposals_df):>8,} rows  ->  {proposals_path}")
    print(f"  experiments:      {len(experiments_df):>8,} rows  ->  {experiments_path}")
    print(f"  snapshots:        {len(snapshots_df):>8,} rows  ->  {snapshots_path}")
    print(f"  manifest:                          ->  {out / 'manifest.json'}")
    return 0


def _assign_proposal_positions(proposals: list) -> None:
    """Rank proposals within each (agent, wave) by first_seen_at.

    Proposals with no first_seen_at sort to the end (assigned positions after
    all timestamped ones). Position is 1-indexed.
    """
    from collections import defaultdict

    by_scope: dict[tuple, list] = defaultdict(list)
    for p in proposals:
        by_scope[(p.agent, p.wave)].append(p)
    for scope_list in by_scope.values():
        scope_list.sort(
            key=lambda p: (
                p.first_seen_at is None,
                p.first_seen_at if p.first_seen_at is not None else datetime.max.replace(tzinfo=timezone.utc),
                p.proposal_id,
            )
        )
        for i, p in enumerate(scope_list, start=1):
            p.position = i


def _load_llm_links(out_dir: Path) -> dict[tuple[Agent, Wave, str], str]:
    """Load LLM-matcher links from data/out/llm_matches.json if present.

    Format on disk:
        {"matches": [
            {"agent": "claude-code", "wave": "novelty", "run_id": "...", "idea_id": "..."},
            ...
        ]}
    Missing file is non-fatal — just returns empty.
    """
    path = out_dir / "llm_matches.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    out: dict[tuple[Agent, Wave, str], str] = {}
    for entry in data.get("matches", []):
        try:
            key = (Agent(entry["agent"]), Wave(entry["wave"]), entry["run_id"])
            out[key] = entry["idea_id"]
        except (KeyError, ValueError):
            continue
    return out


def _relativize_to_repo(absolute_path: str, repo_root: str) -> str:
    if not absolute_path:
        return ""
    try:
        return str(Path(absolute_path).resolve().relative_to(Path(repo_root).resolve()))
    except ValueError:
        return Path(absolute_path).name


if __name__ == "__main__":
    sys.exit(main())
