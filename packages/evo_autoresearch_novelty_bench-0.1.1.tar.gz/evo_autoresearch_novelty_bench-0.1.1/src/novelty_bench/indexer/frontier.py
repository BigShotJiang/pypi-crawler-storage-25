"""Compute frontier-walk membership per idea.

For each (agent, wave), walk linked runs in chronological order. Track the running
best `step_to_3_28`. When a run beats it by at least the noise-floor gate, the run's
linked idea joins the frontier walk and the running best updates.

The "frontier walk" is the trajectory of committed improvers — the ideas that actually
moved the agent's record on this task. Used by the scorer as an impact multiplier
when matching a proposal to a future idea (frontier match → 1.0; non-frontier
match → 0.5).

Lawful-core context (from the original agents' AGENTS.md):
  - Noise floor for step_to_3_28 ≈ 50 steps.
  - Lawful core rule 2: any new "passing" candidate must beat prior best by ≥ 2x
    the noise floor.
  - So: an improvement is a new frontier entry only if step_to_3_28 < current_best - 100.

This approximation skips the 2-seed reproduction requirement (we can't enforce it
without per-seed granularity in this pass). Single-seed lucky wins that hit the
2x-noise-floor gate still get marked frontier; downstream consumers can tighten
by joining on per-seed counts if needed.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

import pandas as pd

from .schema import Agent, Idea, Wave

# From the lawful core in the original agents' AGENTS.md
NOISE_FLOOR_STEPS = 50
MIN_IMPROVEMENT_STEPS = 2 * NOISE_FLOOR_STEPS  # 100

# Muon baseline starting point for every agent's trajectory
BASELINE_STEP_TO_TARGET = 3500


@dataclass
class FrontierEntry:
    """One step in an agent×wave's frontier walk."""
    agent: Agent
    wave: Wave
    idea_id: str
    run_id: str
    step_to_3_28: int
    prior_best_step: int
    chronological_index: int   # 0-based ordering within agent×wave


def compute_frontier_walks(
    runs_df: pd.DataFrame,
    ideas_df: pd.DataFrame,
) -> list[FrontierEntry]:
    """Walk runs chronologically per (agent, wave); return frontier entries.

    Runs without `idea_id` or `step_to_3_28` are skipped (they can't contribute
    to the walk). Chronological order falls back to idea position when
    `launched_at` is missing.
    """
    out: list[FrontierEntry] = []
    idea_position = dict(zip(ideas_df["idea_id"], ideas_df["position"]))

    for (agent_val, wave_val), scope_runs in runs_df.groupby(["agent", "wave"]):
        ordered = scope_runs.copy()
        ordered["_order"] = ordered.apply(
            lambda r: _ordering_key(r, idea_position), axis=1
        )
        ordered = ordered.sort_values("_order").reset_index(drop=True)

        current_best = BASELINE_STEP_TO_TARGET
        for run_idx, row in ordered.iterrows():
            idea_id = row.get("idea_id")
            step = row.get("step_to_3_28")
            if not isinstance(idea_id, str) or not idea_id:
                continue
            if pd.isna(step):
                continue
            step = int(step)
            if step < current_best - MIN_IMPROVEMENT_STEPS:
                out.append(
                    FrontierEntry(
                        agent=Agent(agent_val),
                        wave=Wave(wave_val),
                        idea_id=idea_id,
                        run_id=str(row.get("run_id", "")),
                        step_to_3_28=step,
                        prior_best_step=current_best,
                        chronological_index=int(run_idx),
                    )
                )
                current_best = step
    return out


def apply_frontier_walk(ideas: list[Idea], entries: list[FrontierEntry]) -> int:
    """Set Idea.on_frontier_walk = True for ideas in the frontier set.

    All other ideas with at least one linked run get on_frontier_walk = False
    (so the field reads as "we know" rather than "unknown"). Ideas with no
    linked runs stay None.
    """
    frontier_keys = {(e.agent, e.wave, e.idea_id) for e in entries}
    runs_per_idea: dict[tuple[Agent, Wave, str], int] = defaultdict(int)
    # We don't have run counts here — best_run_id is the proxy. If an idea has
    # a best_run_id, it had at least one linked run.

    marked_frontier = 0
    for idea in ideas:
        key = (idea.agent, idea.wave, idea.idea_id)
        if key in frontier_keys:
            idea.on_frontier_walk = True
            marked_frontier += 1
        elif idea.best_run_id is not None:
            idea.on_frontier_walk = False
        # else: leave as None (no linked runs, we don't know)
    return marked_frontier


def _ordering_key(row: pd.Series, idea_position: dict[str, int]) -> tuple:
    launched = row.get("launched_at")
    if pd.notna(launched):
        return (0, str(launched))
    idea_id = row.get("idea_id")
    if isinstance(idea_id, str) and idea_id in idea_position:
        pos = idea_position.get(idea_id)
        if pos is not None and pd.notna(pos):
            return (1, int(pos))
    return (2, 0)
