# 🍬 candy-ai v20 BETA

> ⚠️ **Version bêta** — Moteur **Cedric8-Thinking**

**Framework IA Python professionnel**

```bash
pip install candy-ai==20.0.0b1
```

---

## Quick Start

```python
from candy import Coding

response = Coding.ask("Write a binary search in Python")
print(response)
```

---

## 🆕 Nouveautés v20

### ⚡ Async natif
```python
import asyncio
from candy import Coding

# ask async
result = asyncio.run(Coding.ask_async("Write a bubble sort"))

# streaming async
async def main():
    async for token in Coding.stream_async("Explain recursion"):
        print(token, end="", flush=True)

asyncio.run(main())

# batch async — toutes les requêtes en parallèle
results = asyncio.run(Coding.batch_async(["sort", "reverse", "binary search"]))
```

### 🔀 Mix — Fusion de personnalités
```python
from candy import Mix, Coding, Security, Reviewer

# Une seule requête avec l'expertise combinée
result = Mix(Coding, Security).ask("Écris un serveur HTTP sécurisé en Python")
print(result)

# Avec profil personnalisé
result = Mix(Coding, Security).use("A").ask("...")

# Async
result = asyncio.run(Mix(Coding, Security).ask_async("..."))
```

### ⛓️ Chain — Pipeline séquentiel
```python
from candy import Chain, Coding, Reviewer, Debugger

# Chaque étape reçoit le résultat de la précédente
result = Chain([Coding, Reviewer, Debugger]).run("Écris une API REST")
print(result["final"])
print(result["steps"])   # résultats intermédiaires

# Async
result = asyncio.run(Chain([Coding, Reviewer]).run_async("..."))
```

### 🔁 Retry automatique + Cache offline
```python
from candy import Coding

# Retry auto avec backoff exponentiel (1.5s → 3s → 6s)
# configuré via profil (max_retries)

# Cache : si l'API est down, répond depuis le cache
result = Coding.ask("Explain decorators", use_cache=True)
```

### 💬 Conversation améliorée
```python
from candy import Conversation, Coding

chat = Conversation(Coding, profile="A", auto_compress=True)
print(chat.say("Explique les décorateurs Python"))
print(chat.say("Donne un exemple avec une classe"))

print(chat.title)               # titre auto-généré
chat.show_history()
chat.export_md("conversation.md")           # export Markdown
chat.save("chat.json")
chat.save("chat.json", append=True)         # fusion sans écraser
chat.load("chat.json")
```

### 🎨 ImageGen amélioré
```python
from candy import ImageGen

# Édition / inpainting (v20)
ImageGen.edit(
    "photo.jpg",
    mask="mask.png",
    prompt="remplace le fond par un coucher de soleil",
    save="edited.png"
)

# Upscale x2 ou x4 (v20)
ImageGen.upscale("small.png", scale=4, save="big.png")

# Création standard
ImageGen.create("un chat astronaute", style="photorealistic", save="chat.png")
ImageGen.variation("original.png", strength=0.6, save="variation.png")
desc = ImageGen.describe("photo.jpg", lang="FR")
images = ImageGen.batch(["forêt", "ville", "portrait"], save_dir="./output/")
```

### 🩺 CLI amélioré
```bash
candy --doctor    # diagnostic complet : connexion, quota, cache
candy --update    # met à jour candy-ai automatiquement
candy --status    # statut API
candy --ask "mon prompt" --stream
candy --score "mon prompt"
candy --fix "mon prompt"
candy --version
```

---

## Streaming

```python
from candy import Writing

for token in Writing.stream("Write a short story about a lighthouse keeper"):
    print(token, end="", flush=True)
```

---

## Context support

```python
from candy import Analytic

data = """
Month,Revenue
Jan,12000
Feb,15400
"""
response = Analytic.ask("What trend do you see?", context=data)
```

---

## Check your quota

```python
from candy import Math
print(Math.quota())
# {'ip': '...', 'quota_used_today': 12, 'quota_limit': 500, 'quota_remaining': 488}
```

---

## Available personalities (120)

50 originales + 40 v13 + 30 v17 = 120 personnalités.
Voir la liste complète sur [client.hubworld.net](https://client.hubworld.net).

---

## Powered by Cedric8-Thinking

candy connecte au moteur **Cedric8-Thinking**.
Usage soumis à un quota journalier (500 requêtes/jour par défaut).

---

## License

MIT
