"""Embedding query cache — P1.4 from plan-performance-roadmap.md.

Shipped 2026-05-09 after P1.3 tool result cache. Closes the
"same query string is embedded multiple times within and across chat
sessions" pattern that wastes Ollama round-trips on identical inputs.

Worked example: a user asks the agent to research "Stockholm energy
market" three times across a day. Each call to ``VaultEmbeddings.search``
re-embeds the same string (~50-100ms Ollama round-trip per call). Same
hot path fires when the orchestrator embeds the dispatched task for
Voyager skill retrieval, AND when the entity registry resolves a
fuzzy-matched name. The cache returns the prior vector in microseconds.

Architecture (deliberately distinct from P1.3 tool_result_cache):

* **Cross-turn / cross-session by design** — an embedding is a pure
  function of (text, model). Two different chat turns asking about
  "Stockholm" produce the same vector. Sharing across turns is the
  whole point. NO correlation_id in the key.

* **In-memory only** — vectors are deterministic and stable; persisting
  across restarts adds bookkeeping for marginal gain. The vault's own
  ``vault_embeddings`` SQLite table already persists DOCUMENT chunk
  vectors. This cache is for QUERY vectors, which are by nature
  ephemeral and one-off.

* **Long TTL + LRU eviction** — embeddings don't go "stale" unless the
  model changes (handled by including model_identity in the key). The
  default 1-hour TTL is a memory-creep guard for long-running servers,
  not a correctness mechanism. LRU + max_bytes cap is the primary
  bound.

* **Total failure-tolerance** — every method is wrapped; cache errors
  degrade to "miss" cleanly. Cache MUST NEVER raise on a query path.
  Same fail-open posture as ``research_cache``, ``tool_result_cache``,
  and ``tool_result_store``.

Locked by unit tests + activity telemetry. The ``embedding_cache_hit``
and ``embedding_cache_write`` events fire low-importance so users
see savings accumulate live in /activity without spam.
"""

from __future__ import annotations

import hashlib
import logging
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)


# arch:deterministic — engine substrate defaults. Tuned via
# `_meta/embedding-query-cache/config/cache.yaml` per Rule 12.
_DEFAULT_ENABLED: bool = True
_DEFAULT_TTL_SECONDS: int = 3600  # 1 hour — memory-creep guard, not staleness
_DEFAULT_MAX_ENTRIES: int = 1000
# 1024-dim float32 = 4096 bytes per vector. 1000 entries = 4 MB.
_DEFAULT_MAX_BYTES: int = 8 * 1024 * 1024  # 8 MB — generous headroom


def _hash_text(text: str) -> str:
    """sha256 of the input text. Deterministic + collision-safe enough
    for cache keys at the scale we care about (millions of queries).
    """
    if not text:
        return ""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def compute_key(model_identity: str, text: str) -> str:
    """Compose the canonical cache key. Pure function, no I/O.

    Returns empty string when inputs can't produce a stable key
    (uncacheable — caller skips the cache entirely).
    """
    if not model_identity or not text:
        return ""
    h = _hash_text(text)
    if not h:
        return ""
    return f"{model_identity}::{h}"


def _vec_byte_size(vec: list[float]) -> int:
    """Estimate bytes used by a Python list[float]. 1024-dim → ~28 KB
    of CPython object overhead; we approximate with float-payload
    only (8 bytes per float). Close enough for budget enforcement.
    """
    if not vec:
        return 0
    return len(vec) * 8


@dataclass
class CacheRecord:
    """One cached embedding vector. Pure data."""

    key: str
    model_identity: str
    text_hash: str  # for diagnostics — original text NOT stored (privacy + size)
    vector: list[float]
    created_at: float
    expires_at: float
    bytes_size: int = 0
    hit_count: int = 0  # bumped on every retrieval

    def is_expired(self, now: float | None = None) -> bool:
        return (now if now is not None else time.time()) >= self.expires_at


@dataclass
class CacheStats:
    """Aggregate counters for the /admin perf panel."""

    hits: int = 0
    misses: int = 0
    writes: int = 0
    evictions: int = 0
    expired_purged: int = 0
    bytes_in_cache: int = 0
    entries: int = 0
    by_model: dict[str, dict[str, int]] = field(default_factory=dict)

    def record_hit(self, model_identity: str) -> None:
        self.hits += 1
        bucket = self.by_model.setdefault(
            model_identity, {"hits": 0, "misses": 0, "writes": 0}
        )
        bucket["hits"] += 1

    def record_miss(self, model_identity: str) -> None:
        self.misses += 1
        bucket = self.by_model.setdefault(
            model_identity, {"hits": 0, "misses": 0, "writes": 0}
        )
        bucket["misses"] += 1

    def record_write(self, model_identity: str) -> None:
        self.writes += 1
        bucket = self.by_model.setdefault(
            model_identity, {"hits": 0, "misses": 0, "writes": 0}
        )
        bucket["writes"] += 1

    def to_public_dict(self) -> dict[str, Any]:
        total = self.hits + self.misses
        hit_rate = float(self.hits) / float(total) if total > 0 else 0.0
        return {
            "hits": self.hits,
            "misses": self.misses,
            "writes": self.writes,
            "evictions": self.evictions,
            "expired_purged": self.expired_purged,
            "hit_rate": round(hit_rate, 4),
            "bytes_in_cache": self.bytes_in_cache,
            "entries": self.entries,
            "by_model": dict(self.by_model),
        }


class EmbeddingQueryCache:
    """In-memory LRU + TTL cache for query embeddings.

    Constructor is total — never raises. Missing config falls back
    to deterministic defaults. A broken activity logger is silently
    swallowed. The cache is opt-in via YAML ``enabled`` flag (default
    on).

    Thread-safe via ``threading.RLock``. Hot paths are sync (called
    from ``VaultEmbeddings.search`` which is async but the embed call
    itself is sync) AND from sync executor threads (entity registry).

    Key shape: ``{model_identity}::{sha256(text)}``. Model identity in
    the key handles model swaps automatically — old vectors fall out
    of LRU naturally; we don't bother actively invalidating because
    the typical case is "user keeps using bge-m3 forever".
    """

    def __init__(
        self,
        *,
        config: dict[str, Any] | None = None,
        activity_logger: Any = None,
    ) -> None:
        cfg = config or {}
        self._enabled = bool(cfg.get("enabled", _DEFAULT_ENABLED))
        self._ttl_seconds = max(1, int(cfg.get("ttl_seconds", _DEFAULT_TTL_SECONDS)))
        self._max_entries = max(1, int(cfg.get("max_entries", _DEFAULT_MAX_ENTRIES)))
        self._max_bytes = max(1024, int(cfg.get("max_bytes", _DEFAULT_MAX_BYTES)))
        self._activity = activity_logger

        # OrderedDict preserves LRU ordering; ``move_to_end`` on read
        # bumps recency.
        self._entries: OrderedDict[str, CacheRecord] = OrderedDict()
        self._lock = threading.RLock()
        self._stats = CacheStats()

    # ── Configuration probes ──

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def ttl_seconds(self) -> int:
        return self._ttl_seconds

    # ── Read path ──

    def get(self, model_identity: str, text: str) -> list[float] | None:
        """Return the cached vector for (model, text), or None on miss.

        Total — never raises. A corrupt entry, lock contention, or
        bookkeeping failure all degrade to None (treated as miss by
        the caller).
        """
        if not self._enabled:
            return None
        try:
            key = compute_key(model_identity, text)
            if not key:
                return None
            with self._lock:
                record = self._entries.get(key)
                if record is None:
                    self._stats.record_miss(model_identity)
                    return None
                if record.is_expired():
                    # Lazy eviction on read.
                    del self._entries[key]
                    self._stats.bytes_in_cache = max(
                        0, self._stats.bytes_in_cache - record.bytes_size
                    )
                    self._stats.entries = len(self._entries)
                    self._stats.expired_purged += 1
                    self._stats.record_miss(model_identity)
                    return None
                # Recency bump.
                self._entries.move_to_end(key)
                record.hit_count += 1
                self._stats.record_hit(model_identity)
                self._emit_activity(
                    "embedding_cache_hit",
                    {
                        "model": model_identity,
                        "text_hash_prefix": record.text_hash[:8],
                        "hits": record.hit_count,
                    },
                    importance="low",
                )
                # Return a copy — never let callers mutate the cached
                # list (would corrupt subsequent hits).
                return list(record.vector)
        except Exception:
            log.debug("embedding_query_cache.get failed", exc_info=True)
            return None

    # ── Write path ──

    def put(
        self,
        model_identity: str,
        text: str,
        vector: list[float],
    ) -> None:
        """Store (model, text) → vector. Total — never raises.

        Overwrites any prior entry for the same key (refreshes TTL).
        Honors max_entries + max_bytes by evicting LRU until inside
        budget BEFORE inserting.
        """
        if not self._enabled:
            return
        try:
            if not vector:
                # Don't cache empty vectors — they're useless to readers
                # and would mask future re-embed attempts.
                return
            key = compute_key(model_identity, text)
            if not key:
                return
            now = time.time()
            size = _vec_byte_size(vector)
            record = CacheRecord(
                key=key,
                model_identity=model_identity,
                text_hash=_hash_text(text),
                vector=list(vector),  # store a copy
                created_at=now,
                expires_at=now + self._ttl_seconds,
                bytes_size=size,
            )
            with self._lock:
                # If overwriting an existing entry, account for its bytes.
                old = self._entries.pop(key, None)
                if old is not None:
                    self._stats.bytes_in_cache = max(
                        0, self._stats.bytes_in_cache - old.bytes_size
                    )

                self._entries[key] = record
                self._stats.bytes_in_cache += size
                self._stats.entries = len(self._entries)
                self._stats.record_write(model_identity)

                # Enforce budget. LRU eviction = pop oldest from front.
                while (
                    len(self._entries) > self._max_entries
                    or self._stats.bytes_in_cache > self._max_bytes
                ):
                    if not self._entries:
                        break
                    _, evicted = self._entries.popitem(last=False)
                    self._stats.bytes_in_cache = max(
                        0, self._stats.bytes_in_cache - evicted.bytes_size
                    )
                    self._stats.evictions += 1
                self._stats.entries = len(self._entries)

            self._emit_activity(
                "embedding_cache_write",
                {
                    "model": model_identity,
                    "text_hash_prefix": record.text_hash[:8],
                    "vector_dim": len(vector),
                    "bytes": size,
                },
                importance="low",
            )
        except Exception:
            log.debug("embedding_query_cache.put failed", exc_info=True)

    # ── Convenience: get-or-compute ──

    def get_or_embed(
        self,
        model: Any,
        text: str,
        *,
        model_identity: str | None = None,
    ) -> list[float] | None:
        """Return cached vector OR call ``model.embed([text])[0]`` and
        store the result. Returns None when ``text`` is empty or the
        embed call raises (caller handles fallback).

        ``model_identity`` defaults to ``getattr(model, "model", "")``
        wrapped in the canonical ``ollama:<name>`` shape used by
        VaultEmbeddings. Callers can pass an explicit identity to
        match whatever scheme they're storing under.
        """
        if not text or not text.strip():
            return None
        identity = model_identity
        if identity is None:
            mname = getattr(model, "model", "") or ""
            identity = f"ollama:{mname}" if mname else "unknown"

        cached = self.get(identity, text)
        if cached is not None:
            return cached

        try:
            vectors = model.embed([text])
        except Exception:
            # Caller decides how to handle (log + fallback to FTS5,
            # disable embedder, etc.). We don't swallow embed failures
            # silently here — return None so caller's existing error
            # path runs.
            return None

        if not vectors or not vectors[0]:
            return None
        vec = list(vectors[0])
        self.put(identity, text, vec)
        return vec

    # ── Maintenance ──

    def purge_expired(self) -> int:
        """Evict every expired entry. Returns count purged.

        Cheap to call periodically (e.g. from a heartbeat tick) but
        not strictly required — get() lazily evicts expired entries
        on access.
        """
        if not self._enabled:
            return 0
        purged = 0
        try:
            now = time.time()
            with self._lock:
                expired_keys = [
                    k for k, r in self._entries.items() if r.is_expired(now)
                ]
                for k in expired_keys:
                    record = self._entries.pop(k)
                    self._stats.bytes_in_cache = max(
                        0, self._stats.bytes_in_cache - record.bytes_size
                    )
                    purged += 1
                self._stats.expired_purged += purged
                self._stats.entries = len(self._entries)
        except Exception:
            log.debug("embedding_query_cache.purge_expired failed", exc_info=True)
        return purged

    def clear(self) -> None:
        """Drop all entries (e.g. on test teardown or model swap).
        Counters are NOT reset — the user's lifetime stats survive."""
        with self._lock:
            self._entries.clear()
            self._stats.bytes_in_cache = 0
            self._stats.entries = 0

    def stats(self) -> dict[str, Any]:
        """Public stats dict for the perf panel + tests."""
        with self._lock:
            return self._stats.to_public_dict()

    # ── Diagnostics ──

    def __len__(self) -> int:
        with self._lock:
            return len(self._entries)

    # ── Activity logger plumbing ──

    def _emit_activity(
        self,
        action: str,
        details: dict[str, Any],
        *,
        importance: str = "low",
    ) -> None:
        """Fire-and-forget activity event. Broken loggers swallowed."""
        if self._activity is None:
            return
        try:
            self._activity.log(
                category="performance",
                action=action,
                summary=f"embedding_query_cache {action}",
                details=details,
                importance=importance,
            )
        except Exception:
            log.debug("embedding_query_cache: activity logger failed", exc_info=True)
