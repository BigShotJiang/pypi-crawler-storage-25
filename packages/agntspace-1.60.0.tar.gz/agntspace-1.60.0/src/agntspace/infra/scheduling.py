"""Scheduling discipline — Sprint α-bis (P-α-bis, 2026-05-09).

Closes the architectural gap that lets background work compete with
foreground user interaction. Every autonomous machinery firing site
(daily cycle, EOD report, weekly reflection, evolution mining, memory
consolidation, fabrication detector, news watcher, etc.) checks
``user_activity_monitor.is_user_active()`` BEFORE starting heavy work.
If active → defer to next tick. The user's chat / clicks / typing
always take priority on the local LLM resource.

Three pieces:

* ``UserActivityMonitor`` — reads existing ``ActivityLogger`` signals
  (last chat / last user activity / last journal write). Computes
  ``is_user_active()`` from configurable thresholds.

* ``defer_if_active(name, fn, *, monitor, importance)`` — async helper
  that checks the monitor and either runs the function OR records a
  ``deferred`` activity event and returns None. Lets callers wrap
  any async/sync work with one line.

* ``ModelLock`` — async context manager for local-mode Ollama
  exclusivity. Foreground requests acquire immediately; background
  requests wait or yield. Solves the "user typing while daily cycle
  runs" race where Ollama serializes inference per model.

The pattern is OS-level scheduling discipline (systemd ``OnIdle``,
macOS DAS, iOS background-fetch) applied to an agent framework.
Adoption, not invention — but no peer agent framework I've audited
applies it. Hermes skips because no autonomous work; OpenClaw probably
has it but I haven't seen the code.

Failure-tolerant at every edge. Missing monitor / broken signals /
stale timestamps all degrade to "treat as active" (= defer the work)
since that's the safer side. Better to miss one round of evolution
mining than to freeze the chat for 6 minutes.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Any, TypeVar

log = logging.getLogger(__name__)

T = TypeVar("T")


# arch:deterministic — engine substrate defaults. Tunable via the
# ``_meta/scheduling/config/quiet_hours.yaml`` skill substrate (Rule 12).
# These are the safe defaults for "what counts as the user being here."
_DEFAULT_ACTIVE_WINDOW_SECONDS: int = 90  # any signal within 90s = active
_DEFAULT_CHAT_WINDOW_SECONDS: int = 600   # last chat within 10 min = active
_DEFAULT_FALLBACK_TO_ACTIVE: bool = True  # broken/missing monitor → safer side


class UserActivityMonitor:
    """Lightweight wrapper around ``ActivityLogger`` that exposes a
    boolean "is the user actively using the app right now" signal.

    Backed by signals the activity logger already tracks
    (``_last_user_activity``, ``_last_user_chat``, ``_last_journal_write``).
    No new state, no new persistence. Just a discipline.

    Construction is total — pass an activity_logger that's None or
    broken and ``is_user_active()`` returns ``True`` (the safe side
    that defers heavy work). Better to miss one cycle of evolution
    mining than to freeze the chat.
    """

    def __init__(
        self,
        activity_logger: Any = None,
        *,
        active_window_seconds: int = _DEFAULT_ACTIVE_WINDOW_SECONDS,
        chat_window_seconds: int = _DEFAULT_CHAT_WINDOW_SECONDS,
        fallback_to_active: bool = _DEFAULT_FALLBACK_TO_ACTIVE,
    ) -> None:
        self._activity = activity_logger
        self._active_window = max(1, int(active_window_seconds))
        self._chat_window = max(1, int(chat_window_seconds))
        self._fallback_to_active = bool(fallback_to_active)

    def _seconds_since(self, iso_ts: str | None) -> float | None:
        """Return seconds since the timestamp, or None if it can't parse."""
        if not iso_ts:
            return None
        try:
            last = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
            if last.tzinfo is None:
                last = last.replace(tzinfo=UTC)
            return (datetime.now(UTC) - last).total_seconds()
        except Exception:
            return None

    def seconds_since_last_signal(self) -> float | None:
        """Smallest of (chat / journal / activity) ages. None if all unset."""
        if self._activity is None:
            return None
        try:
            chat = self._seconds_since(getattr(self._activity, "_last_user_chat", ""))
            journal = self._seconds_since(getattr(self._activity, "_last_journal_write", ""))
            activity = self._seconds_since(getattr(self._activity, "_last_user_activity", ""))
        except Exception:
            return None
        candidates = [v for v in (chat, journal, activity) if v is not None]
        if not candidates:
            return None
        return min(candidates)

    def is_user_active(self) -> bool:
        """True iff the user has interacted recently enough to count.

        - Any activity (chat / journal / api) within ``active_window_seconds``
          (default 90s) → active.
        - Chat within ``chat_window_seconds`` (default 600s = 10 min) → active.
          Wider window because chat sessions span multiple turns with gaps.
        - Broken / missing monitor → ``fallback_to_active`` (True by default;
          safer to defer work than freeze chat).
        """
        try:
            if self._activity is None:
                return self._fallback_to_active

            ago = self.seconds_since_last_signal()
            if ago is not None and ago <= self._active_window:
                return True

            chat_ago = self._seconds_since(
                getattr(self._activity, "_last_user_chat", "")
            )
            if chat_ago is not None and chat_ago <= self._chat_window:
                return True

            return False
        except Exception:
            log.debug("UserActivityMonitor.is_user_active failed", exc_info=True)
            return self._fallback_to_active

    def status(self) -> dict[str, Any]:
        """Diagnostic snapshot for /admin perf panel."""
        return {
            "is_active": self.is_user_active(),
            "seconds_since_last_signal": self.seconds_since_last_signal(),
            "active_window_seconds": self._active_window,
            "chat_window_seconds": self._chat_window,
            "wired": self._activity is not None,
        }


async def defer_if_active(
    name: str,
    fn: Callable[[], Awaitable[T] | T],
    *,
    monitor: UserActivityMonitor | None,
    activity_logger: Any = None,
    importance: str = "low",
) -> T | None:
    """Run ``fn`` only if the user is idle. Otherwise log + skip.

    The standard wrapper for any heavy autonomous work that shouldn't
    run while the user is interacting. Examples: daily cycle, EOD
    report, weekly reflection, evolution mining, memory consolidation,
    fabrication audit, news watcher, taxonomy scan.

    Returns ``fn()``'s result on run, or ``None`` on defer.

    Why a single wrapper instead of inline checks at every site:
      1. ONE place to log the deferral (debug-level, traceable).
      2. ONE place to emit an activity event so users can SEE in
         /activity that work was deferred (not silently skipped).
      3. ONE place to handle the wired-vs-unwired-monitor degenerate
         case so call sites don't need defensive guards.

    Failure-tolerant: a broken monitor / broken activity logger /
    raised callable all degrade gracefully. The callable's exception
    propagates as before — we don't swallow user errors. Only the
    deferral / logging machinery is bulletproofed.
    """
    if monitor is None:
        # No monitor wired — run immediately. Pre-Sprint-α-bis behavior.
        result = fn()
        if asyncio.iscoroutine(result):
            return await result  # type: ignore[return-value]
        return result  # type: ignore[return-value]

    try:
        active = monitor.is_user_active()
    except Exception:
        log.debug("defer_if_active: monitor probe failed", exc_info=True)
        active = True  # safer side

    if active:
        log.debug(
            "defer_if_active: deferring %s — user is active "
            "(seconds_since_last_signal=%s)",
            name, monitor.seconds_since_last_signal(),
        )
        # Emit an activity event so the user can SEE that work was
        # deferred, not silently skipped. Low importance — this is
        # the system working correctly, not an alert.
        if activity_logger is not None:
            try:
                activity_logger.log(
                    category="performance",
                    action="background_work_deferred",
                    summary=f"{name} deferred while user is active",
                    details={
                        "task": name,
                        "seconds_since_last_signal": monitor.seconds_since_last_signal(),
                        "reason": "user_active",
                    },
                    importance=importance,
                )
            except Exception:
                log.debug("defer_if_active: activity log failed", exc_info=True)
        return None

    # User idle — run the work.
    result = fn()
    if asyncio.iscoroutine(result):
        return await result  # type: ignore[return-value]
    return result  # type: ignore[return-value]


# ── ModelLock — local-mode Ollama exclusivity ───────────────────────────


class ModelLock:
    """Async exclusivity primitive for the local LLM model.

    Local Ollama serializes inference per loaded model. If a daily-
    cycle LLM call is mid-flight, a chat turn arriving simultaneously
    blocks behind it on the Ollama side. The user perceives a 6-min
    chat freeze while a background task hogs the model.

    ModelLock fixes this by acquiring an asyncio lock around the
    Ollama call. Foreground requests acquire with priority. Background
    requests wait — and crucially, expose ``acquired_by_foreground``
    so a long-running background acquirer can voluntarily yield if
    a foreground request arrived while it held the lock.

    In cloud mode this is a no-op (cloud providers handle their own
    concurrency). The lock is keyed on model name; multiple distinct
    models can be in flight concurrently.

    Total — never raises on acquire/release. Broken state self-heals
    on next acquire.
    """

    def __init__(self) -> None:
        self._locks: dict[str, asyncio.Lock] = {}
        # Tracks who holds the lock per model: "foreground" / "background" / "".
        # Background holders should periodically check and yield if a
        # foreground waiter is queued.
        self._holder_priority: dict[str, str] = {}

    def _lock_for(self, model: str) -> asyncio.Lock:
        """Lazily allocate the asyncio.Lock for a model. Cheap; just a dict."""
        if model not in self._locks:
            self._locks[model] = asyncio.Lock()
        return self._locks[model]

    @asynccontextmanager
    async def acquire(self, model: str, *, priority: str = "background"):
        """Async context manager. Acquires the lock for ``model``.

        ``priority`` ∈ ``{"foreground", "background"}``. Foreground
        callers should pass "foreground" so background callers can see
        they exist via ``has_foreground_waiter``.

        Use:
            async with model_lock.acquire("ollama/qwen2.5:14b", priority="foreground"):
                response = await llm.complete(...)
        """
        if not model:
            # Defensive: empty model = no lock
            yield
            return

        lock = self._lock_for(model)
        try:
            async with lock:
                self._holder_priority[model] = priority
                try:
                    yield
                finally:
                    self._holder_priority[model] = ""
        except asyncio.CancelledError:
            # Cancellation is fine — the lock auto-releases on context exit.
            self._holder_priority[model] = ""
            raise

    def has_foreground_waiter(self, model: str) -> bool:
        """True iff a foreground caller is queued waiting for this model.

        Background long-runners should check this periodically and
        voluntarily yield (release the lock so the foreground request
        can run). Without this signal, a 6-min background LLM call
        still freezes user chat — even with the lock — because the
        user request just queues behind it.

        Today this is a heuristic: returns True when the lock is
        contended (waiters queued) AND the holder is background. A
        future refinement could expose actual waiter priorities
        (would require asyncio internals).
        """
        try:
            lock = self._locks.get(model)
            if lock is None:
                return False
            holder_priority = self._holder_priority.get(model, "")
            # Lock is held + locked() AND holder is background: a waiter
            # is plausibly foreground. Conservative — we can't know for
            # sure without exposing the waiter list.
            return lock.locked() and holder_priority == "background"
        except Exception:
            return False

    def status(self) -> dict[str, Any]:
        """Diagnostic snapshot for /admin perf panel."""
        return {
            "models_tracked": list(self._locks.keys()),
            "holders": dict(self._holder_priority),
            "locked": {m: lock.locked() for m, lock in self._locks.items()},
        }
