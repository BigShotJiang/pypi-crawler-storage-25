"""AGENTS.md manifest builder — portable operating manual at vault root.

This file is the cross-tool portability primitive. AgntSpace's own agent AND
any other AI tool reading the vault (Claude Desktop, Cursor, Codex via MCP,
future LLMs) can consume `<vault_root>/AGENTS.md` to understand who the user
is, how the vault is organized, what the agent is permitted to do, and the
conventions for writing into the vault.

Architecture:
- Pure builder ``build_agents_manifest(inputs)`` — takes a small dict of
  pre-extracted strings, returns markdown. Easy to unit-test.
- IO wrapper ``write_agents_manifest(...)`` — reads identity files via
  VaultReader, calls builder, writes to ``<root>/AGENTS.md``. Idempotent
  via sha256-of-content compare; skips when unchanged.

Sources synthesized:
- ``system/identity/SOUL.md``      → operating principles section
- ``system/identity/USER.md``      → owner section
- ``system/identity/CONTRACT.md``  → permissions summary
- ``system/identity/RELATIONSHIP.md`` → communication style (optional)

Output location: ``<root_dir>/AGENTS.md`` (vault root, not under any logical
prefix). The file is a DERIVED VIEW — regenerated on every boot AND on
identity-file edits. Edit the source files, not this. Direct disk write
bypasses VaultWriter contract gate (this is infra concern, not user action);
an activity event is logged for visibility.

Failure mode: every IO is wrapped; the writer NEVER raises into the caller.
A broken identity file degrades a section to a placeholder, never the whole
file. Missing RELATIONSHIP.md is fine; missing SOUL.md / USER.md / CONTRACT.md
each degrade with a clear warning section.
"""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

# Stable section markers so other tools can reliably find what they need.
# Marked deterministic — these are structural keys, not strategy.
_HEADER_BANNER: str = (
    "This vault is operated by **AgntSpace**. Other AI agents "
    "(Claude Desktop, Cursor, Codex via MCP, future LLM tools) "
    "reading this vault should follow the rules below to stay "
    "consistent with how AgntSpace itself operates."
)  # arch:deterministic — banner text is structural, not tunable strategy

_REGEN_NOTICE: str = (
    "> **This file is auto-regenerated** from "
    "`agntspace/system/identity/{SOUL,USER,CONTRACT,RELATIONSHIP}.md` on "
    "every AgntSpace boot and whenever those files are edited. Edit the "
    "source files — your changes here will be overwritten on next boot."
)  # arch:deterministic — instruction to readers; structural

_VAULT_LAYOUT_TABLE: str = """\
| Logical path | Physical location | What lives here |
|---|---|---|
| `inbox/`     | `agntspace-inbox/`     | Drop zone — files here are auto-ingested |
| `journal/`   | `agntspace-journal/`   | User journal (`user/`) + agent observations (`agnt/`) |
| `knowledge/` | `agntspace-knowledge/` | Knowledge bases — sources + wiki + library per KB |
| `projects/`  | `agntspace-projects/`  | Project containers — tasks + notes + output |
| `goals/`     | `agntspace-goals/`     | First-class goals (cross-project) |
| `finance/`   | `agntspace-finance/`   | Receipts → drafts → ledger |
| `system/`    | `agntspace/system/`    | Identity, agents, skills, contract |
| `memory/`    | `agntspace/memory/`    | Memory summaries + knowledge graph |"""  # arch:deterministic — vault layout is structural

_CONVENTIONS_BLOCK: str = """\
- **Frontmatter on every agent-authored file**: `date:`, `author:`, optional `entity_type:` / `taxonomy_path:` / `citations:` / `provenance:` / `language_*` fields.
- **Wikilinks**: every proper noun + concept uses `[[wikilinks]]` for graph traversability.
- **Source files**: digests of scrapes/web/PDFs live under `knowledge/<kb>/library/`; their summaries under `knowledge/<kb>/wiki/digests/`.
- **Wiki article structure**: every article opens with a `## Summary` section as the first H2 — 2-3 sentence self-contained lede so future readers (human or LLM) can decide relevance in 10 seconds.
- **Recency markers**: date-sensitive claims carry `(as of YYYY-MM, source-name)` inline. Wikipedia-style parenthetical citations.
- **Citations**: place `[Source: filename]` BEFORE the sentence-ending period (Wikipedia/academic convention).
- **User journal is user-only**: `journal/user/` is never written by the agent. Rule of separation.
- **Never modify user content**: folders at the vault root other than `agntspace*/` are user files — read-only for knowledge."""  # arch:deterministic — conventions are structural

_ENTRY_POINTS_BLOCK: str = """\
- **Drop a file** → place it in `agntspace-inbox/` (auto-ingested by AgntSpace's watcher within 30 seconds).
- **Read knowledge** → walk `agntspace-knowledge/<kb>/wiki/` (each article opens with `## Summary`).
- **Read user identity** → `agntspace/system/identity/USER.md`.
- **Read agent identity** → `agntspace/system/identity/SOUL.md`.
- **Read permissions** → `agntspace/system/identity/CONTRACT.md` (machine-enforced YAML block).
- **Query the knowledge graph** → SPO triples at `agntspace/memory/graph/triples.json`; entities at `agntspace/memory/graph/entities.json`."""  # arch:deterministic — entry-point pointers are structural


@dataclass
class _ManifestInputs:
    """Pre-extracted strings ready to render. Pure data."""

    owner_section: str
    operating_principles: str
    communication_style: str
    permissions_summary: str
    version: str
    generated_at_iso: str


def _safe_read(reader: Any, logical_path: str) -> tuple[dict[str, Any], str] | None:
    """Read a vault file; return (frontmatter_dict, body_str) or None on failure."""
    try:
        result = reader.read(logical_path)
    except Exception as exc:  # noqa: BLE001 — degrade gracefully
        log.debug("agents_manifest: read failed for %s: %s", logical_path, exc)
        return None

    if not isinstance(result, dict):
        return None

    metadata = result.get("metadata") or result.get("frontmatter") or {}
    body = result.get("content") or result.get("body") or ""
    if not isinstance(metadata, dict):
        metadata = {}
    if not isinstance(body, str):
        body = ""

    return (metadata, body)


def _extract_user_section(user_doc: tuple[dict[str, Any], str] | None) -> str:
    """Render the Owner section from USER.md."""
    if user_doc is None:
        return (
            "_USER.md is missing. Edit `agntspace/system/identity/USER.md` "
            "to fill in name, role, and timezone._"
        )

    _meta, body = user_doc

    # Pull `- **Key**: Value` lines from the body. USER.md uses this format
    # explicitly so callers (system prompt + this manifest) can parse it.
    fields: dict[str, str] = {}
    for line in body.splitlines():
        m = re.match(r"^\s*-\s+\*\*([^*]+)\*\*:\s*(.+?)\s*$", line)
        if m:
            key = m.group(1).strip()
            value = m.group(2).strip()
            # Skip placeholder values like "[Your name]"
            if value.startswith("[") and value.endswith("]"):
                continue
            fields[key] = value

    if not fields:
        return (
            "_USER.md exists but has no filled-in fields yet. Edit "
            "`agntspace/system/identity/USER.md` to fill in name, role, "
            "timezone — those are the fields parsed by the agent._"
        )

    # Render as a clean bullet list, preserving the order USER.md presents them.
    preferred_order = ("Name", "Role", "Location", "Timezone", "Language",
                       "Work hours", "Companies")
    rendered: list[str] = []
    for key in preferred_order:
        if key in fields:
            rendered.append(f"- **{key}**: {fields[key]}")
    # Append any other fields not in the preferred list, alphabetically.
    extra_keys = sorted(k for k in fields if k not in preferred_order)
    for key in extra_keys:
        rendered.append(f"- **{key}**: {fields[key]}")

    return "\n".join(rendered)


def _extract_operating_principles(soul_doc: tuple[dict[str, Any], str] | None) -> str:
    """Render the Operating Principles section from SOUL.md.

    Strategy: pull the SOUL.md identity (Name, Role, Purpose) plus the first
    section of the body (typically Personality / Operating Principles).
    Truncate at ~2000 chars so the manifest stays scannable.
    """
    if soul_doc is None:
        return (
            "_SOUL.md is missing. The agent has no declared identity — "
            "edit `agntspace/system/identity/SOUL.md` to define operating "
            "principles._"
        )

    _meta, body = soul_doc

    # Extract Name / Role / Purpose from the `- **Key**: Value` block.
    fields: dict[str, str] = {}
    for line in body.splitlines():
        m = re.match(r"^\s*-\s+\*\*([^*]+)\*\*:\s*(.+?)\s*$", line)
        if m:
            key = m.group(1).strip()
            value = m.group(2).strip()
            if not (value.startswith("[") and value.endswith("]")):
                fields[key] = value

    out_lines: list[str] = []
    for key in ("Name", "Role", "Purpose"):
        if key in fields:
            out_lines.append(f"- **{key}**: {fields[key]}")

    if out_lines:
        out_lines.append("")  # separator

    # Pull a slice of the body — Personality + adjacent sections — to give
    # other agents a feel for how this agent thinks. Cap to keep manifest tight.
    max_chars = 2000
    body_slice = body.strip()
    if len(body_slice) > max_chars:
        body_slice = body_slice[:max_chars].rstrip()
        # Don't break a heading mid-line.
        last_h2 = body_slice.rfind("\n## ")
        if last_h2 > max_chars // 2:
            body_slice = body_slice[:last_h2].rstrip()
        body_slice += (
            "\n\n_(truncated — full content in "
            "`agntspace/system/identity/SOUL.md`)_"
        )

    out_lines.append(body_slice)
    return "\n".join(out_lines)


def _extract_communication_style(rel_doc: tuple[dict[str, Any], str] | None) -> str:
    """Render the Communication Style section from RELATIONSHIP.md."""
    if rel_doc is None:
        return (
            "_No relationship notes yet. As you work with this vault, "
            "the agent accumulates communication-style observations in "
            "`agntspace/system/identity/RELATIONSHIP.md`._"
        )

    _meta, body = rel_doc
    body = body.strip()
    if not body:
        return "_RELATIONSHIP.md exists but is empty._"

    # Look for the "Communication Style" section specifically; fall back to
    # the first non-empty section.
    comm_match = re.search(
        r"^##\s+Communication\s+Style\s*\n(.+?)(?=\n##\s|\Z)",
        body, flags=re.IGNORECASE | re.DOTALL | re.MULTILINE,
    )
    if comm_match:
        section = comm_match.group(1).strip()
        if section:
            return section

    # Fallback: first 600 chars of the body so the manifest carries SOME signal.
    snippet = body[:600].rstrip()
    if len(body) > 600:
        snippet += "\n\n_(see full file at `agntspace/system/identity/RELATIONSHIP.md`)_"
    return snippet


_ALLOW_RE = re.compile(r"^allow:\s*$", flags=re.MULTILINE)
_CONFIRM_RE = re.compile(r"^confirm:\s*$", flags=re.MULTILINE)
_BLOCK_RE = re.compile(r"^block:\s*$", flags=re.MULTILINE)


def _extract_yaml_list(yaml_text: str, key: str) -> list[str]:
    """Pull the list of bare names under a top-level YAML key like ``allow:``.

    Stops at the next top-level key (zero-indent, ends in ``:``) or end of text.
    Ignores comment lines and blank lines.
    """
    pattern = re.compile(rf"^{re.escape(key)}:\s*$", flags=re.MULTILINE)
    m = pattern.search(yaml_text)
    if not m:
        return []

    start = m.end()
    # Find the next top-level key (line starting at column 0 ending with ':').
    next_key = re.search(r"^[a-zA-Z_][a-zA-Z0-9_]*:\s*$", yaml_text[start:], flags=re.MULTILINE)
    end = start + next_key.start() if next_key else len(yaml_text)

    chunk = yaml_text[start:end]
    items: list[str] = []
    for line in chunk.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        # Tolerate `- name` and `- name # comment`
        if s.startswith("- "):
            value = s[2:].split("#", 1)[0].strip()
            if value:
                items.append(value)
    return items


def _extract_permissions_summary(contract_doc: tuple[dict[str, Any], str] | None) -> str:
    """Render the Permissions Summary section from CONTRACT.md."""
    if contract_doc is None:
        return (
            "_CONTRACT.md is missing. The contract engine falls back to "
            "default-deny when this happens. Edit "
            "`agntspace/system/identity/CONTRACT.md` to grant permissions._"
        )

    _meta, body = contract_doc

    # Pull the YAML block (between ```yaml and ``` fences).
    yaml_match = re.search(
        r"```yaml\s*\n(.+?)\n```",
        body, flags=re.DOTALL,
    )
    if not yaml_match:
        return (
            "_CONTRACT.md exists but the YAML permissions block was not found. "
            "The contract engine falls back to default-deny when this happens._"
        )

    yaml_text = yaml_match.group(1)
    allow_list = _extract_yaml_list(yaml_text, "allow")
    confirm_list = _extract_yaml_list(yaml_text, "confirm")
    block_list = _extract_yaml_list(yaml_text, "block")

    def _format_list(items: list[str], cap: int = 8) -> str:
        if not items:
            return "_(none)_"
        shown = items[:cap]
        out = ", ".join(f"`{a}`" for a in shown)
        if len(items) > cap:
            out += f" _(+{len(items) - cap} more)_"
        return out

    lines = [
        f"- **Allow** ({len(allow_list)}): {_format_list(allow_list)}",
        f"- **Confirm** ({len(confirm_list)}): {_format_list(confirm_list)}",
        f"- **Block** ({len(block_list)}): {_format_list(block_list)}",
        "",
        "_See `agntspace/system/identity/CONTRACT.md` for the full machine-enforced YAML._",
    ]
    return "\n".join(lines)


def build_agents_manifest(inputs: _ManifestInputs) -> str:
    """Pure renderer: combine pre-extracted sections into the AGENTS.md markdown."""
    sections = [
        "# AGENTS.md",
        "",
        _HEADER_BANNER,
        "",
        _REGEN_NOTICE,
        "",
        "---",
        "",
        "## Owner",
        "",
        inputs.owner_section,
        "",
        "## Operating principles",
        "",
        inputs.operating_principles,
        "",
        "## Communication style",
        "",
        inputs.communication_style,
        "",
        "---",
        "",
        "## Vault layout",
        "",
        _VAULT_LAYOUT_TABLE,
        "",
        "User content (other folders at the vault root) is **never modified** by the agent — only read for knowledge.",
        "",
        "## Permissions",
        "",
        inputs.permissions_summary,
        "",
        "## Conventions",
        "",
        _CONVENTIONS_BLOCK,
        "",
        "## Entry points for tools reading this vault",
        "",
        _ENTRY_POINTS_BLOCK,
        "",
        "---",
        "",
        f"_Generated {inputs.generated_at_iso} by AgntSpace v{inputs.version}. Source files: SOUL.md, USER.md, CONTRACT.md, RELATIONSHIP.md._",
        "",
    ]
    return "\n".join(sections)


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def _resolve_version() -> str:
    """Best-effort version lookup — never raises."""
    try:
        from importlib.metadata import PackageNotFoundError
        from importlib.metadata import version as _pkg_version
        try:
            return _pkg_version("agntspace")
        except PackageNotFoundError:
            return "dev"
    except Exception:  # noqa: BLE001
        return "dev"


def write_agents_manifest(
    *,
    root_dir: Path,
    reader: Any,
    activity_logger: Any | None = None,
) -> dict[str, Any]:
    """Read identity files, build manifest, write to ``<root_dir>/AGENTS.md``.

    Idempotent: skips disk write when content hash matches existing file.
    Fail-open: any error returns a result dict with reason; never raises.

    Returns:
        ``{"written": bool, "skipped_reason": str | None, "path": str,
          "bytes": int, "hash": str}``
    """
    target = Path(root_dir) / "AGENTS.md"
    result: dict[str, Any] = {
        "written": False,
        "skipped_reason": None,
        "path": str(target),
        "bytes": 0,
        "hash": "",
    }

    try:
        user_doc = _safe_read(reader, "system/identity/USER.md")
        soul_doc = _safe_read(reader, "system/identity/SOUL.md")
        contract_doc = _safe_read(reader, "system/identity/CONTRACT.md")
        rel_doc = _safe_read(reader, "system/identity/RELATIONSHIP.md")

        inputs = _ManifestInputs(
            owner_section=_extract_user_section(user_doc),
            operating_principles=_extract_operating_principles(soul_doc),
            communication_style=_extract_communication_style(rel_doc),
            permissions_summary=_extract_permissions_summary(contract_doc),
            version=_resolve_version(),
            generated_at_iso=datetime.now(tz=UTC).strftime("%Y-%m-%d %H:%M UTC"),
        )

        body = build_agents_manifest(inputs)
        result["bytes"] = len(body.encode("utf-8"))
        result["hash"] = _hash_text(body)

        # Idempotency check — skip if existing content matches (avoid mtime churn).
        if target.exists():
            try:
                existing = target.read_text(encoding="utf-8")
                # Strip the timestamp footer when comparing — it changes every run.
                # Compare everything BEFORE the final "_Generated" marker.
                def _strip_footer(t: str) -> str:
                    idx = t.rfind("_Generated ")
                    return t[:idx].rstrip() if idx > 0 else t
                if _strip_footer(existing) == _strip_footer(body):
                    result["skipped_reason"] = "unchanged"
                    return result
            except Exception:  # noqa: BLE001
                pass  # if comparison fails, fall through and write

        # Write atomically: write to .tmp then rename.
        tmp = target.with_suffix(".md.tmp")
        try:
            tmp.write_text(body, encoding="utf-8", newline="\n")
            tmp.replace(target)
        except Exception as exc:  # noqa: BLE001
            log.warning("agents_manifest: write failed for %s: %s", target, exc)
            result["skipped_reason"] = f"write_failed: {type(exc).__name__}"
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:  # noqa: BLE001
                pass
            return result

        result["written"] = True

        # Activity event (Rule 13 — agent-side derived write, low importance).
        if activity_logger is not None:
            try:
                activity_logger.log(
                    category="system",
                    action="agents_manifest_written",
                    summary=f"Regenerated AGENTS.md ({result['bytes']} bytes)",
                    importance="low",
                    details={"path": str(target), "hash": result["hash"][:16]},
                )
            except Exception as exc:  # noqa: BLE001
                log.debug("agents_manifest: activity log failed: %s", exc)

        return result

    except Exception as exc:  # noqa: BLE001 — never raise from this writer
        log.warning("agents_manifest: unexpected failure: %s", exc, exc_info=True)
        result["skipped_reason"] = f"unexpected_error: {type(exc).__name__}"
        return result
