"""SQLite database connection and schema management.

VAULT ISOLATION: each vault owns its own database at
root_dir/agntspace/agntspace.db. Conversations, decisions, dispatch logs,
canvas items — everything vault-specific — lives inside the vault folder
and travels with it. Switching vaults naturally switches databases.

The old shared location (~/.agntspace/agntspace.db) is migrated once on
first boot via ``_migrate_shared_db()`` in main.py.
"""

from __future__ import annotations

import logging
from pathlib import Path

import aiosqlite

log = logging.getLogger(__name__)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id),
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    token_count INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_messages_conversation
    ON messages(conversation_id, created_at);

CREATE VIRTUAL TABLE IF NOT EXISTS vault_fts USING fts5(
    path,
    title,
    content,
    tokenize='porter unicode61'
);

-- dispatch_log moved to audit.db in Stage B.2 round 4 (2026-05-05).
-- Schema is now owned by ``agent/orchestrator.py:init_dispatch_log_schema``.
-- Existing agntspace.db installs may still have the legacy table from
-- prior boots; the migration helper reads from it on first boot and the
-- table becomes stale thereafter. A far-future cleanup PR could DROP it.

CREATE TABLE IF NOT EXISTS vault_index (
    path TEXT PRIMARY KEY,
    title TEXT,
    content_hash TEXT,
    indexed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dm_allowlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    approved_at TEXT NOT NULL,
    UNIQUE(channel, sender_id)
);

CREATE TABLE IF NOT EXISTS dm_pairing (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    code TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    UNIQUE(channel, sender_id, code)
);

CREATE INDEX IF NOT EXISTS idx_dm_allowlist_lookup
    ON dm_allowlist(channel, sender_id);

CREATE TABLE IF NOT EXISTS canvas_items (
    id TEXT PRIMARY KEY,
    title TEXT DEFAULT '',
    content TEXT NOT NULL,
    content_type TEXT NOT NULL DEFAULT 'markdown',
    pinned INTEGER NOT NULL DEFAULT 0,
    collapsed INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0,
    user_note TEXT DEFAULT '',
    pushed_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS canvas_snapshots (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    items_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

-- Regression tests: curated correlation_id chains the user wants to
-- preserve as expected-behavior baselines. Reuses the existing decision
-- log + correlation_id substrate; this table only adds the CURATION
-- layer (naming, description, archive, replay status tracking).
CREATE TABLE IF NOT EXISTS regression_tests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    correlation_id TEXT NOT NULL,
    captured_at TEXT NOT NULL,
    baseline_snapshot TEXT NOT NULL DEFAULT '{}',
    archived INTEGER NOT NULL DEFAULT 0,
    last_replay_correlation_id TEXT DEFAULT NULL,
    last_replay_status TEXT DEFAULT NULL,
    last_replay_at TEXT DEFAULT NULL,
    last_replay_diff TEXT DEFAULT NULL
);

CREATE INDEX IF NOT EXISTS idx_regression_correlation
    ON regression_tests(correlation_id);
CREATE INDEX IF NOT EXISTS idx_regression_archived
    ON regression_tests(archived, captured_at DESC);

-- scope_file_writes moved to audit.db in Stage B.2 round 3 (2026-05-05).
-- Schema is now owned by ``vault/scope_writes.py:_get_conn`` (the
-- ScopeWritesRecorder self-creates the table on first connection).
-- Existing agntspace.db installs may still have the legacy table from
-- prior boots; the migration helper reads from it on first boot and the
-- table becomes stale thereafter. A far-future cleanup PR could DROP it.
"""


async def get_db(db_path: Path) -> aiosqlite.Connection:
    """Open an async SQLite connection. Creates the file if needed."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db = await aiosqlite.connect(str(db_path))
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA foreign_keys=ON")
    # busy_timeout: wait up to 30 s for a write lock instead of failing
    # instantly with "database is locked". Bumped 5s → 30s on 2026-04-29
    # after a Telegram receipt was silently lost — KB compile pipeline
    # was holding the lock for ~3.4s during graph + entity_registry saves
    # combined with decision_log writes per structural triple, easily
    # exceeding the prior 5s window on heavy vaults. The receipt's ledger
    # commit + chat-mirror + merchant upsert all failed silently because
    # they shared the same locked DB. 30 s comfortably covers the longest
    # observed compile transactions on a 1700+ article vault. Trade-off:
    # a single hung transaction now blocks new writes for up to 30s
    # instead of 5s — but a hung transaction at that scale is a real
    # incident that surfaces via heartbeat anyway, NOT a quiet drop.
    # Critical because the vault writes through a SEPARATE
    # sqlite3.Connection in vault/scope_writes.py (also WAL) during
    # pipeline operations — WAL allows concurrent readers but only ONE
    # writer at a time, so without this pragma our async writes
    # (orchestrator dispatch log, work queue enqueue, decision log, cost
    # tracker) race the sync scope-writes connection and lose.
    await db.execute("PRAGMA busy_timeout=30000")
    # synchronous=NORMAL is the recommended pairing with WAL — still crash-
    # safe (no committed data lost), just skips extra fsyncs that FULL adds.
    # Cuts commit latency noticeably on Windows where fsync is expensive.
    await db.execute("PRAGMA synchronous=NORMAL")
    # WAL auto-checkpoint at 200 pages (~800 KB). Default is 1000 pages
    # (~4 MB). Without this, on a busy vault the WAL file grew to 4+ MB
    # within a few hours and every read had to walk the entire WAL —
    # measured 8s+ on /api/health. Same fix that audit.db and automation.db
    # already have. Lower threshold = more frequent passive checkpoints,
    # but each checkpoint is small and runs in the background.
    await db.execute("PRAGMA wal_autocheckpoint=200")
    # One-time TRUNCATE checkpoint at open to flush any pre-existing WAL
    # accumulation (e.g. agntspace.db-wal sitting at 4 MB after hours of
    # uptime under the old auto-checkpoint default). Safe — WAL is durable
    # until checkpoint fires; the checkpoint just merges it back into the
    # main db file. After this call, agntspace.db-wal is empty (or nearly
    # so) and read latency drops.
    try:
        await db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except Exception:
        log.debug("agntspace.db wal_checkpoint failed (non-fatal)", exc_info=True)
    return db


async def get_db_read(db_path: Path) -> aiosqlite.Connection:
    """Open a READ-ONLY aiosqlite connection for the same file as :func:`get_db`.

    Why this exists (P2.2, 2026-05-11 night-4): a single :class:`aiosqlite.Connection`
    is backed by ONE dedicated worker thread; every operation on the connection
    queues through that thread. So even though SQLite WAL would happily allow
    concurrent readers across separate file-level connections, our read paths
    (chat history fetch, FTS search, dashboard polls) sit behind every in-flight
    write on the same connection — a multi-second KB-ingest commit gives every
    concurrent read a multi-second tail.

    The fix is structural: open a SECOND aiosqlite connection at ``mode=ro``.
    SQLite's WAL handles cross-connection concurrency cleanly (readers see a
    consistent snapshot, writers don't block readers); aiosqlite's per-connection
    serialization is what we're routing around.

    Read-only enforcement: the URI ``file:<path>?mode=ro`` means SQLite refuses
    any mutating statement at the engine level. A caller that accidentally
    routes a write through the read connection raises ``OperationalError`` —
    visible failure, not silent drift. This is the defense-in-depth layer; the
    primary discipline is that services route write methods through ``_db`` and
    read methods through ``_db_read``.

    PRAGMAs: ``journal_mode`` and ``synchronous`` are write-side concerns and
    are ignored on read-only connections. ``busy_timeout`` still applies (the
    reader waits for shared-lock acquisition, which is a non-issue under WAL
    but harmless to set). ``wal_autocheckpoint`` is similarly a write-side
    knob, not set here. Row factory matches :func:`get_db` so callers using
    ``aiosqlite.Row`` results work uniformly across both connections.
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)
    # URI form is required for ?mode=ro. ``uri=True`` activates URI parsing.
    db = await aiosqlite.connect(f"file:{db_path}?mode=ro", uri=True)
    db.row_factory = aiosqlite.Row
    # busy_timeout still applies even on read-only — see PRAGMA docs.
    await db.execute("PRAGMA busy_timeout=30000")
    return db


async def init_schema(db: aiosqlite.Connection) -> None:
    """Create tables if they don't exist, and run migrations."""
    await db.executescript(_SCHEMA)
    # Migration: add archived column to conversations
    try:
        await db.execute("ALTER TABLE conversations ADD COLUMN archived INTEGER NOT NULL DEFAULT 0")
    except Exception:
        pass  # column already exists
    # Migration: add provenance column to messages (JSON — kind, source_channel, etc.)
    try:
        await db.execute("ALTER TABLE messages ADD COLUMN provenance TEXT DEFAULT NULL")
    except Exception:
        pass  # column already exists
    # NOTE: the goal_id ALTER for dispatch_log used to live here. dispatch_log
    # moved to audit.db in Stage B.2 round 4 (2026-05-05); the new schema
    # owned by orchestrator.init_dispatch_log_schema() includes goal_id from
    # the start, so this ALTER is no longer needed against agntspace.db.
    # Migration: add artifact tracking to conversations (feedback loop)
    try:
        await db.execute("ALTER TABLE conversations ADD COLUMN artifact_type TEXT DEFAULT NULL")
    except Exception:
        pass
    try:
        await db.execute("ALTER TABLE conversations ADD COLUMN artifact_path TEXT DEFAULT NULL")
    except Exception:
        pass
    try:
        await db.execute("ALTER TABLE conversations ADD COLUMN artifact_meta TEXT DEFAULT NULL")
    except Exception:
        pass
    await db.commit()
