"""Tool-call result cache — P1.3 from plan-performance-roadmap.md.

Shipped 2026-05-08 night-2 after P1.2 research cache. Closes the
"agent re-queries the same data inside a single tool loop" pattern
that wastes LLM round-trips on identical reads.

Worked example: in a single chat turn the agent calls ``vault_search``
to find a wiki article, then `query_knowledge` to look up the same
slug, then `list_tasks` filtered to that project, then ``vault_search``
AGAIN for the same query. The fourth call is wasted — we already have
the result. The cache returns the prior result in microseconds and
the LLM tool loop skips a round.

Architecture (deliberately distinct from siblings):

* **In-memory only** — no SQLite. Tool results are scoped to a single
  chat turn / tool loop. A cache hit a day later is meaningless
  (state may have changed). Persisting across restarts adds no value.

* **Per-turn isolation via correlation_id** — cache key includes the
  current ``correlation_id`` so results don't leak across distinct
  user turns. Without this, two different chat sessions would share
  cached search results — confusing at best, leaky at worst.

* **Allowlist of cacheable tools** — only ``read``-shaped tools
  (vault_search, list_tasks, query_knowledge, etc.) are eligible.
  Mutating tools (create_task, send_email, save_draft) are never
  cached. Allowlist is YAML-driven (Rule 12); engine-side enforcement
  is a closed deny-by-default check.

* **Per-tool TTL** — each cacheable tool can declare its own TTL.
  Defaults: 60s (search-shaped) / 30s (list-shaped) / 120s (memory
  recall). Short by design — tool results are LIVE state that may
  drift even mid-conversation.

* **LRU + size cap** — bounded entries (default 500) and total bytes
  (default 10 MB). Eviction by oldest-touched. The 50 MB cap from
  ``tool_result_store.py`` is the upper bound for FULL results
  (truncate-and-stash); this 10 MB cap is for the smaller payloads
  read tools typically return.

* **Distinct from `tool_result_store`** — that module stashes large
  results so the LLM can fetch them later (truncation reflow). This
  module avoids re-running the tool when the answer is already known
  (cache). Different concerns, different lifecycles, deliberate
  separate modules.

* **Total failure-tolerance** — every method is wrapped in try/except;
  a corrupt entry / lock contention / sqlite hiccup degrades to
  "cache miss". The user gets a fresh tool dispatch instead of an
  error. Same fail-open posture as ``research_cache`` and the
  existing tool_result_store.

Locked by 36 unit tests + 5 e2e workflow tests. Activity events fire
on every hit + write so the user can see savings accumulate live.
"""

from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)


# arch:deterministic — engine substrate defaults. Tuned via
# `_meta/tool-result-cache/config/cache.yaml` per Rule 12.
_DEFAULT_ENABLED: bool = True
_DEFAULT_DEFAULT_TTL_SECONDS: int = 60
_DEFAULT_MAX_ENTRIES: int = 500
_DEFAULT_MAX_BYTES: int = 10 * 1024 * 1024  # 10 MB
# Default per-tool TTLs. Override per-tool in YAML; tools not on
# the allowlist (or the allowlist itself if empty) default to NO
# caching at all (deny-by-default). The inline marker on the next line
# is the arch-test signal (block-style marker comments above the
# constant don't count per the same-line marker convention).
_DEFAULT_TTLS: dict[str, int] = {  # arch:deterministic — fallback when tool-result-cache skill YAML is missing; values mirror the shipped YAML ttls block
    "vault_search": 60,
    "search_vault": 60,
    "list_tasks": 30,
    "list_goals": 30,
    "list_projects": 30,
    "list_subagents": 30,
    "get_inbox_count": 30,
    "query_knowledge": 120,
    "query_memory_graph": 120,
    "recall_memory": 120,
    "deep_memory_recall": 120,
    "read_inbox": 60,
    "read_email": 60,
    "research_kb": 90,
}


def _hash_args(tool_input: dict[str, Any] | None) -> str:
    """Stable, sorted JSON hash of the tool input dict.

    Returns the hex sha256 of `json.dumps(input, sort_keys=True)`.
    Falls back to the empty string on any serialization failure
    (the cache treats empty hash as "uncacheable" — see ``compute_key``).
    """
    if tool_input is None:
        tool_input = {}
    try:
        canonical = json.dumps(tool_input, sort_keys=True, default=str)
    except Exception:
        return ""
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def compute_key(
    tool_name: str,
    tool_input: dict[str, Any] | None,
    correlation_id: str,
) -> str:
    """Compose the canonical cache key. Pure function, no I/O.

    Returns empty string when the inputs can't produce a stable key
    (uncacheable). Empty key is the signal to skip the cache entirely
    rather than store under an ambiguous key.
    """
    if not tool_name:
        return ""
    args_hash = _hash_args(tool_input)
    if not args_hash:
        return ""
    return f"{tool_name}::{correlation_id}::{args_hash}"


@dataclass
class CacheRecord:
    """One cached tool result. Pure data."""

    key: str
    tool_name: str
    correlation_id: str
    result: Any  # whatever the tool returned (typically a dict)
    created_at: float
    expires_at: float
    bytes_size: int = 0
    hit_count: int = 0  # bumped on every retrieval
    duration_saved_ms: float = 0.0  # tracked across all hits

    def is_expired(self, now: float | None = None) -> bool:
        return (now if now is not None else time.time()) >= self.expires_at


@dataclass
class CacheStats:
    """Aggregate counters for the /admin perf panel."""

    hits: int = 0
    misses: int = 0
    writes: int = 0
    evictions: int = 0
    expired_purged: int = 0
    total_duration_saved_ms: float = 0.0
    bytes_in_cache: int = 0
    entries: int = 0
    by_tool: dict[str, dict[str, int]] = field(default_factory=dict)

    def record_hit(self, tool_name: str) -> None:
        self.hits += 1
        bucket = self.by_tool.setdefault(tool_name, {"hits": 0, "misses": 0, "writes": 0})
        bucket["hits"] += 1

    def record_miss(self, tool_name: str) -> None:
        self.misses += 1
        bucket = self.by_tool.setdefault(tool_name, {"hits": 0, "misses": 0, "writes": 0})
        bucket["misses"] += 1

    def record_write(self, tool_name: str) -> None:
        self.writes += 1
        bucket = self.by_tool.setdefault(tool_name, {"hits": 0, "misses": 0, "writes": 0})
        bucket["writes"] += 1

    def to_public_dict(self) -> dict[str, Any]:
        hit_rate = (
            float(self.hits) / float(self.hits + self.misses)
            if (self.hits + self.misses) > 0
            else 0.0
        )
        return {
            "hits": self.hits,
            "misses": self.misses,
            "writes": self.writes,
            "evictions": self.evictions,
            "expired_purged": self.expired_purged,
            "hit_rate": round(hit_rate, 4),
            "total_duration_saved_ms": round(self.total_duration_saved_ms, 2),
            "bytes_in_cache": self.bytes_in_cache,
            "entries": self.entries,
            "by_tool": dict(self.by_tool),
        }


class ToolResultCache:
    """In-memory LRU + TTL cache for read-only tool results.

    Constructor is total — never raises. Missing config falls back
    to deterministic defaults. A broken activity logger is silently
    swallowed. The cache is OPT-IN per tool via the YAML allowlist.

    Thread-safe via ``threading.RLock`` (the chat path is asyncio
    but tool execution routes through a thread pool; the same thread
    that's storing might run cleanup).

    Per-tool TTLs come from YAML. If the YAML doesn't list a tool,
    that tool is NOT cached (deny-by-default — accidental caching of
    a stateful read like ``read_email`` could mask new mail).
    """

    def __init__(
        self,
        *,
        config: dict[str, Any] | None = None,
        activity_logger: Any = None,
    ) -> None:
        cfg = config or {}
        self._enabled = bool(cfg.get("enabled", _DEFAULT_ENABLED))
        self._default_ttl = int(cfg.get("default_ttl_seconds", _DEFAULT_DEFAULT_TTL_SECONDS))
        self._max_entries = int(cfg.get("max_entries", _DEFAULT_MAX_ENTRIES))
        self._max_bytes = int(cfg.get("max_bytes", _DEFAULT_MAX_BYTES))
        self._activity = activity_logger

        # Per-tool TTL allowlist. The allowlist KEY itself doubles as
        # "this tool is cacheable" — tools missing from the dict are
        # NOT cached (deny-by-default). YAML overrides defaults but
        # never relaxes the allowlist semantics.
        ttls_from_yaml = cfg.get("ttls") or {}
        self._ttls: dict[str, int] = dict(_DEFAULT_TTLS)
        if isinstance(ttls_from_yaml, dict):
            for k, v in ttls_from_yaml.items():
                try:
                    if k and isinstance(k, str):
                        self._ttls[k] = max(1, int(v))
                except Exception:
                    log.debug(
                        "tool_result_cache: skipping malformed ttl entry %r=%r",
                        k, v,
                    )

        # Optional explicit deny list (YAML — never cache these tools
        # regardless of allowlist membership). Lets users bypass for a
        # specific tool without disabling the whole cache.
        self._deny: set[str] = set()
        deny_yaml = cfg.get("deny") or []
        if isinstance(deny_yaml, list):
            for name in deny_yaml:
                if isinstance(name, str) and name:
                    self._deny.add(name)

        # OrderedDict for LRU ordering. ``move_to_end`` on every read
        # bumps recency.
        self._entries: OrderedDict[str, CacheRecord] = OrderedDict()
        self._lock = threading.RLock()
        self._stats = CacheStats()

    # ── Configuration probes ──

    @property
    def enabled(self) -> bool:
        return self._enabled

    def is_cacheable(self, tool_name: str) -> bool:
        """Pure check: would this tool's result be cached if invoked?

        Useful for callers (Agent._execute_tool) to short-circuit cache
        lookup entirely on tools that aren't on the allowlist.
        """
        if not self._enabled:
            return False
        if not tool_name:
            return False
        if tool_name in self._deny:
            return False
        return tool_name in self._ttls

    def ttl_for(self, tool_name: str) -> int:
        """Resolve TTL for a tool (in seconds)."""
        return self._ttls.get(tool_name, self._default_ttl)

    # ── Activity helper (graceful degrade) ──

    def _log_activity(
        self,
        action: str,
        summary: str,
        *,
        importance: str = "low",
        details: dict[str, Any] | None = None,
    ) -> None:
        if not self._activity:
            return
        try:
            self._activity.log(
                category="user",
                action=action,
                summary=summary,
                importance=importance,
                details=details or {},
            )
        except Exception:
            log.debug("tool_result_cache: activity logger emit failed", exc_info=True)

    # ── Read path ──

    def get(
        self,
        *,
        tool_name: str,
        tool_input: dict[str, Any] | None,
        correlation_id: str,
    ) -> Any | None:
        """Look up a cached tool result. Returns None on miss / disabled
        / not cacheable / expired.

        Side effects on hit: bumps LRU position + hit_count, records
        a stats hit, emits a low-importance activity event.
        """
        if not self.is_cacheable(tool_name):
            return None
        key = compute_key(tool_name, tool_input, correlation_id)
        if not key:
            return None

        with self._lock:
            record = self._entries.get(key)
            if record is None:
                self._stats.record_miss(tool_name)
                return None
            if record.is_expired():
                # Silent cleanup; caller treats as miss.
                del self._entries[key]
                self._stats.expired_purged += 1
                self._stats.bytes_in_cache = max(
                    0, self._stats.bytes_in_cache - record.bytes_size,
                )
                self._stats.entries = len(self._entries)
                self._stats.record_miss(tool_name)
                return None
            # LRU bump.
            self._entries.move_to_end(key)
            record.hit_count += 1
            self._stats.record_hit(tool_name)

        self._log_activity(
            "tool_result_cache_hit",
            f"Tool '{tool_name}' returned cached result",
            importance="low",
            details={
                "tool": tool_name,
                "correlation_id": correlation_id,
                "hit_count": record.hit_count,
                "age_seconds": int(time.time() - record.created_at),
            },
        )

        return record.result

    # ── Write path ──

    def put(
        self,
        *,
        tool_name: str,
        tool_input: dict[str, Any] | None,
        correlation_id: str,
        result: Any,
        duration_saved_ms: float = 0.0,
    ) -> bool:
        """Insert or replace a cached entry. Returns True on success.

        Validation: tool must be on the allowlist (caller already
        checked via ``is_cacheable``, but this is the second-line
        guard). Empty key (un-stable args) → no-op.
        """
        if not self.is_cacheable(tool_name):
            return False
        if result is None:
            return False
        key = compute_key(tool_name, tool_input, correlation_id)
        if not key:
            return False

        # Compute size best-effort. Failures default to 0 so a non-
        # serializable result still gets cached (we just can't enforce
        # the byte cap accurately for it).
        try:
            payload = json.dumps(result, default=str)
            size_bytes = len(payload.encode("utf-8"))
        except Exception:
            size_bytes = 0

        ttl = self.ttl_for(tool_name)
        now = time.time()
        record = CacheRecord(
            key=key,
            tool_name=tool_name,
            correlation_id=correlation_id,
            result=result,
            created_at=now,
            expires_at=now + ttl,
            bytes_size=size_bytes,
            duration_saved_ms=duration_saved_ms,
        )

        with self._lock:
            existing = self._entries.get(key)
            if existing is not None:
                # Subtract the old size before overwriting.
                self._stats.bytes_in_cache = max(
                    0, self._stats.bytes_in_cache - existing.bytes_size,
                )
            self._entries[key] = record
            self._entries.move_to_end(key)
            self._stats.bytes_in_cache += size_bytes
            self._stats.record_write(tool_name)
            # Enforce caps.
            self._evict_if_over_limit()
            self._stats.entries = len(self._entries)

        self._log_activity(
            "tool_result_cache_write",
            f"Cached tool '{tool_name}' result (ttl={ttl}s)",
            importance="low",
            details={
                "tool": tool_name,
                "ttl_seconds": ttl,
                "bytes": size_bytes,
            },
        )
        return True

    def record_hit_savings(
        self,
        *,
        tool_name: str,
        duration_saved_ms: float,
    ) -> None:
        """Aggregate the wall-clock savings from a cache hit. Called by
        the caller after they decide whether the hit was meaningful.

        Separated from ``get`` so the caller can measure the saved
        time using the original tool's known typical latency without
        the cache having to predict it.
        """
        if duration_saved_ms <= 0 or not tool_name:
            return
        with self._lock:
            self._stats.total_duration_saved_ms += duration_saved_ms
            record = next(
                (r for r in self._entries.values() if r.tool_name == tool_name),
                None,
            )
            if record is not None:
                record.duration_saved_ms += duration_saved_ms

    # ── Maintenance ──

    def purge_expired(self) -> int:
        """Delete all expired entries. Returns count purged."""
        purged = 0
        now = time.time()
        with self._lock:
            keys_to_drop: list[str] = []
            for key, record in self._entries.items():
                if record.is_expired(now):
                    keys_to_drop.append(key)
            for key in keys_to_drop:
                record = self._entries.pop(key)
                self._stats.bytes_in_cache = max(
                    0, self._stats.bytes_in_cache - record.bytes_size,
                )
                purged += 1
            self._stats.expired_purged += purged
            self._stats.entries = len(self._entries)
        return purged

    def invalidate_correlation(self, correlation_id: str) -> int:
        """Drop every entry tagged with the given correlation_id.

        Used at chat turn boundaries — when a new turn starts under a
        different correlation_id, the old turn's cache is dead weight.
        Bounded purge keeps the cache small without waiting for TTL.
        Returns count dropped.
        """
        if not correlation_id:
            return 0
        dropped = 0
        with self._lock:
            keys_to_drop = [
                key
                for key, record in self._entries.items()
                if record.correlation_id == correlation_id
            ]
            for key in keys_to_drop:
                record = self._entries.pop(key)
                self._stats.bytes_in_cache = max(
                    0, self._stats.bytes_in_cache - record.bytes_size,
                )
                dropped += 1
            self._stats.entries = len(self._entries)
        return dropped

    def clear(self) -> int:
        """Drop every entry. Returns count cleared."""
        with self._lock:
            count = len(self._entries)
            self._entries.clear()
            self._stats.bytes_in_cache = 0
            self._stats.entries = 0
        return count

    def stats(self) -> dict[str, Any]:
        """Snapshot of cache stats. Total — never raises."""
        with self._lock:
            self._stats.entries = len(self._entries)
            return self._stats.to_public_dict()

    # ── Internal helpers ──

    def _evict_if_over_limit(self) -> None:
        """LRU + size-based eviction. Caller MUST hold ``self._lock``."""
        # Entry-count cap.
        while len(self._entries) > self._max_entries:
            try:
                _, evicted = self._entries.popitem(last=False)  # FIFO = oldest
            except KeyError:
                break
            self._stats.bytes_in_cache = max(
                0, self._stats.bytes_in_cache - evicted.bytes_size,
            )
            self._stats.evictions += 1
        # Total-bytes cap.
        while (
            self._stats.bytes_in_cache > self._max_bytes
            and self._entries
        ):
            try:
                _, evicted = self._entries.popitem(last=False)
            except KeyError:
                break
            self._stats.bytes_in_cache = max(
                0, self._stats.bytes_in_cache - evicted.bytes_size,
            )
            self._stats.evictions += 1
