"""Process-mode plumbing — Phase 2 opener of the process split.

The plan ([tasks/archive/plans/plan-process-split.md](../../../../tasks/archive/plans/plan-process-split.md))
breaks the single Python process per vault into three kinds — ``web``,
``worker``, ``scheduler`` — sharing one vault via SQLite work queues +
filesystem state. This module is the **plumbing** that future phases
extend with actual process entry points. For Phase 2 opener: every
subsystem that the future split would relocate now consults a single
helper that returns True in the default ``singleton`` mode. Behavior is
identical to the pre-Phase-2 code path; only the wiring is in place.

Modes
-----

``singleton``
    The default. One Python process serves HTTP, runs the work queue
    dispatcher, runs the cron scheduler, and runs the file watchers.
    Every ``should_*`` helper returns True. This is what the entire
    existing codebase assumes; flipping any other mode without further
    extraction would silently break features.

``web``
    Future. Serves HTTP/WS only. Skips work-queue dispatch, scheduler,
    watchers. Long-running work enqueues into the shared work queue;
    the ``worker`` process drains it.

``worker``
    Future. Drains the work queue. Runs the kanban reclaim sweep
    (worker-side liveness contract). Does NOT serve HTTP and does NOT
    run cron — those are ``web`` and ``scheduler`` respectively.

``scheduler``
    Future. Runs cron + heartbeat + daily-cycle + watchers + channel
    pollers. Enqueues into the work queue; does NOT dispatch. Does NOT
    serve HTTP.

Resolution
----------

Priority (highest wins):

1. Explicit env var ``AGNTSPACE_PROCESS_MODE`` (set by the CLI entry
   points ``agntspace worker`` / ``agntspace scheduler`` once those
   ship in Phase 2.1+).
2. ``config.toml [system].process_mode``.
3. Default ``singleton``.

Unknown values fall through to ``singleton`` with a logged warning
rather than crashing — misconfiguration must NEVER break boot.

Design constraints
------------------

* Pure functions. Every helper takes the mode explicitly as input.
  Module-level state is forbidden: testing must be able to assert all
  four modes from one test file without monkey-patching globals.
* The mapping (which subsystem belongs to which kind) lives here, not
  scattered across the lifespan. Future phases can adjust by editing
  one function; the call sites stay generic.
* No imports outside the stdlib. Settings consumes us; we never
  consume settings (avoids circular import + makes us trivial to
  unit-test).
"""

from __future__ import annotations

import logging
import os
from enum import Enum

log = logging.getLogger(__name__)


__all__ = [
    "ProcessMode",
    "resolve_mode",
    "current_mode",
    "should_serve_http",
    "should_dispatch_jobs",
    "should_run_scheduler",
    "should_run_watchers",
    "should_run_channels",
    "should_use_external_tools",
    "classify_auto_launch_service",
]


class ProcessMode(str, Enum):
    """The four supported process kinds. String-valued so config-toml +
    env-var serialization is trivial.
    """

    SINGLETON = "singleton"
    WEB = "web"
    WORKER = "worker"
    SCHEDULER = "scheduler"


# Module-level lookup of canonical lowercase string → enum value.
# Built once at import time. Used by ``resolve_mode``.
_MODE_LOOKUP: dict[str, ProcessMode] = {m.value: m for m in ProcessMode}


def resolve_mode(value: str | None) -> ProcessMode:
    """Parse a user-supplied string into a ``ProcessMode``.

    * ``None`` / empty / whitespace → ``SINGLETON`` (no log; that's the
      common path).
    * Recognized value (case-insensitive, trimmed) → matching enum.
    * Unknown value → ``SINGLETON`` with a warning log so misconfiguration
      is visible but non-fatal.

    Never raises. Boot must not crash because the user typoed
    ``process_mode = "workr"`` in config.toml.
    """

    if value is None:
        return ProcessMode.SINGLETON
    cleaned = value.strip().lower()
    if not cleaned:
        return ProcessMode.SINGLETON
    mode = _MODE_LOOKUP.get(cleaned)
    if mode is None:
        log.warning(
            "Unknown process_mode %r — falling back to singleton. "
            "Valid values: singleton, web, worker, scheduler.",
            value,
        )
        return ProcessMode.SINGLETON
    return mode


def current_mode(settings_value: str | None = None) -> ProcessMode:
    """Resolve the active mode for THIS process.

    Env-var override wins so the future ``agntspace worker`` /
    ``agntspace scheduler`` CLI entry points can set the mode at spawn
    time without editing config. Falls through to the supplied
    ``settings_value`` (typically read from ``Settings.process_mode``),
    then to ``singleton``.
    """

    env = os.environ.get("AGNTSPACE_PROCESS_MODE")
    if env:
        return resolve_mode(env)
    return resolve_mode(settings_value)


# ── Capability gates ─────────────────────────────────────────────────
#
# Each gate maps a runtime capability (serving HTTP, draining the work
# queue, running cron, polling the inbox, polling channels) to the set
# of process modes where that capability MUST be active.
#
# Singleton lives in every set. That's the load-bearing invariant:
# adding a new gate without adding singleton to its set silently
# regresses the default deployment.

_HTTP_MODES = frozenset({ProcessMode.SINGLETON, ProcessMode.WEB})
_DISPATCH_MODES = frozenset({ProcessMode.SINGLETON, ProcessMode.WORKER})
_SCHEDULER_MODES = frozenset({ProcessMode.SINGLETON, ProcessMode.SCHEDULER})
_WATCHER_MODES = frozenset({ProcessMode.SINGLETON, ProcessMode.SCHEDULER})
_CHANNEL_MODES = frozenset({ProcessMode.SINGLETON, ProcessMode.SCHEDULER})
# External tools (MCP servers) are consumed by every mode that runs
# the agent's tool loop. Scheduler enqueues into the work queue and
# never calls tools directly, so it doesn't need MCP connections.
_EXTERNAL_TOOL_MODES = frozenset(
    {ProcessMode.SINGLETON, ProcessMode.WEB, ProcessMode.WORKER},
)


def should_serve_http(mode: ProcessMode) -> bool:
    """True iff this process should mount FastAPI routes + WebSocket
    endpoints. The HTTP tier serves the UI and accepts user actions;
    long-running work is delegated through the shared work queue.
    """

    return mode in _HTTP_MODES


def should_dispatch_jobs(mode: ProcessMode) -> bool:
    """True iff this process should drain the work queue. The dispatcher
    is the workhorse: it pulls pending jobs, runs the handler, and
    writes back status. Worker-only in the split, singleton in v1.
    """

    return mode in _DISPATCH_MODES


def should_run_scheduler(mode: ProcessMode) -> bool:
    """True iff this process should run cron + heartbeat + daily cycle.

    Heartbeat is the central clock — goal pursuit, silence checks,
    LLM-health probes, evolution mining, editor-quality-pass all
    cadence-fire from here. Scheduler-only in the split.
    """

    return mode in _SCHEDULER_MODES


def should_run_watchers(mode: ProcessMode) -> bool:
    """True iff this process should run the filesystem watchers — inbox
    drop zones (raw + finance) + vault-edit observer + fs_events
    bridge. Watchers wake up scheduler work; they belong with the
    scheduler.
    """

    return mode in _WATCHER_MODES


def should_run_channels(mode: ProcessMode) -> bool:
    """True iff this process should run channel pollers (Telegram, IMAP
    poll, etc.). Channels accept inbound messages from the outside
    world; the agent's chat path then handles them. Scheduler-side in
    the split because the polling cadence is timer-driven.
    """

    return mode in _CHANNEL_MODES


def should_use_external_tools(mode: ProcessMode) -> bool:
    """True iff this process needs MCP external-tool connections.

    Singleton / web / worker all dispatch the agent's tool loop —
    chat tools, work-queue handlers, watcher-triggered ingest all
    end up calling tools at some point. Scheduler is enqueue-only:
    it fires cron events into the work queue and never invokes the
    agent directly, so spawning per-server MCP connections is pure
    overhead with zero payoff in that mode.

    The gate covers both the boot-time ``auto_connect_all()`` task
    and the periodic ``start_health_probe()`` loop — neither has
    value in scheduler mode.
    """

    return mode in _EXTERNAL_TOOL_MODES


# ── Auto-launch service classification ──────────────────────────────
#
# The lifespan's auto-launch loop walks a hard-coded list of
# (name, service) tuples. Each name maps to a "kind" — worker or
# scheduler — so future modes can filter the list without changing
# how the loop is structured.

_WORKER_KIND_SERVICES = frozenset({"work_queue", "kanban"})  # arch:deterministic — service-name → kind classifier; names are stable Python identifiers, not user-tunable strategy
_SCHEDULER_KIND_SERVICES = frozenset(  # arch:deterministic — service-name → kind classifier; matches the auto_launch list in main.py:lifespan, not tunable strategy
    {
        "heartbeat",
        "scheduler",
        "daily_cycle",
        "cron",
        "raw_watcher",
        "finance_inbox_watcher",
        "vault_edit_watcher",
        "fs_bridge",
    }
)


def classify_auto_launch_service(name: str) -> str:
    """Return ``"worker"`` / ``"scheduler"`` / ``"unknown"`` for the
    named auto-launch service. ``unknown`` falls through to "include
    in every mode" so that an un-classified service can't accidentally
    disappear from the singleton path during refactoring.
    """

    if name in _WORKER_KIND_SERVICES:
        return "worker"
    if name in _SCHEDULER_KIND_SERVICES:
        return "scheduler"
    return "unknown"


def should_launch_service(name: str, mode: ProcessMode) -> bool:
    """True iff the named auto-launch service should start in this
    process. Unknown service names default to True (singleton
    behavior) so an unclassified add doesn't get silently dropped.
    """

    kind = classify_auto_launch_service(name)
    if kind == "worker":
        return should_dispatch_jobs(mode)
    if kind == "scheduler":
        return should_run_scheduler(mode)
    # "unknown" — default include. Belt-and-braces against future
    # additions that forget to register here.
    return True
