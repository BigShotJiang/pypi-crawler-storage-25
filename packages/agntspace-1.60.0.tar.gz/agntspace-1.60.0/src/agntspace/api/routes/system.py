"""System-load surface — the small honest signal under the logo.

``GET /api/system/busy`` is the lightweight endpoint the UI's
``<SystemLoadIndicator>`` polls every 5 seconds. Returns one of four levels
(calm / working / busy / overloaded) plus a list of what's actually
running, so the user gets ambient feedback the system is alive and doing
work — instead of staring at a slow UI assuming it's broken.

**Architectural rule** (from ``tasks/plan-architecture-restructure.md``):
this endpoint must NEVER walk the filesystem. Reads only from in-memory
state objects (work_queue counts, orchestrator active dispatches,
decision-logger health, watcher status). Cached 2 seconds so high-frequency
polling from multiple browser tabs is cheap. If this endpoint is slow,
the indicator that's supposed to show "system is busy" becomes the very
thing making it busy.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from fastapi import APIRouter, Request

log = logging.getLogger(__name__)
router = APIRouter()


# ── Pure-function level classifier (testable, no I/O) ──────────────


def classify_load_level(
    *,
    active_dispatches: int,
    queue_running_live: int,
    queue_running_orphan: int,
    queue_pending: int,
    recent_lock_errors: int,
    longest_op_seconds: float,
    decision_failure_rate: float,
    # ── Phase 2 signals (added 2026-05-07): event-loop, memory,
    # watcher cycle health, cron in-flight. All default to safe values
    # so legacy callers without these signals classify identically.
    event_loop_blocks_over_5s_last_minute: int = 0,
    event_loop_blocks_over_500ms_last_minute: int = 0,
    memory_action: str = "ok",
    watcher_cycle_overrun: bool = False,
    cron_running_count: int = 0,
) -> str:
    """Map raw signals to one of {calm, working, busy, overloaded}.

    Pure function. Engine-only — strategy lives here intentionally
    because the thresholds are deterministic UX-feel decisions, not
    user-tunable strategy. If a future maintainer wants to tweak them,
    edit the constants below.

    ``memory_action``: lowercase string from ``MemoryAction`` enum —
    ``"ok"`` / ``"warn_crossed"`` / ``"alarm_crossed"`` /
    ``"ceiling_exceeded"`` / ``"no_data"``. Anything containing
    ``"warn"`` is BUSY-level; anything containing ``"alarm"`` or
    ``"ceiling"`` is OVERLOADED.
    """
    # OVERLOADED: hard signals the system is stretched beyond healthy
    if recent_lock_errors >= 3:
        return "overloaded"
    if decision_failure_rate > 0.10:
        return "overloaded"
    if queue_running_orphan > 0 and queue_running_orphan >= 3:
        return "overloaded"
    if longest_op_seconds > 180:
        return "overloaded"
    # Event-loop block storm: a single 5+ second block in the last
    # minute means the loop was hard-frozen. The user perceives this
    # as the app being broken.
    if event_loop_blocks_over_5s_last_minute >= 1:
        return "overloaded"
    # Memory at alarm or ceiling = process is in danger.
    if "alarm" in memory_action or "ceiling" in memory_action:
        return "overloaded"

    # BUSY: noticeable concurrent load — user should expect latency
    total_active = active_dispatches + queue_running_live
    if total_active >= 4:
        return "busy"
    if longest_op_seconds > 30:
        return "busy"
    if queue_pending >= 10:
        return "busy"
    # Event-loop sustained pressure: 3+ half-second blocks in 60s =
    # something on the loop is doing too much sync work.
    if event_loop_blocks_over_500ms_last_minute >= 3:
        return "busy"
    # Memory warn: heavy work has bumped RSS past the warning floor.
    if "warn" in memory_action:
        return "busy"
    # Watcher cycle overrun: last cycle took 2x longer than its
    # interval — the heavy filesystem work is colliding with the
    # event loop. Surfaces the canonical "app struggles, but no
    # dispatch is registered" failure mode.
    if watcher_cycle_overrun:
        return "busy"

    # WORKING: normal background activity — give it a few seconds
    if total_active >= 1 or queue_pending >= 1:
        return "working"
    # Cron job currently executing counts as background activity even
    # when it doesn't go through the orchestrator dispatch path.
    if cron_running_count >= 1:
        return "working"

    # CALM: nothing happening
    return "calm"


# ── 2-second cache so polling is cheap ─────────────────────────────


_cache: dict[str, Any] = {"ts": 0.0, "payload": None}
_CACHE_TTL_SECONDS = 2.0


def _now_seconds() -> float:
    return time.time()


# ── Endpoint ───────────────────────────────────────────────────────


@router.get("/system/busy")
async def system_busy(request: Request) -> dict:
    """Live system-load snapshot. Cached 2 seconds.

    Returns:
        ``{level, summary, active_dispatches, queue, operations,
           decision_logger, recent_lock_errors, longest_op_seconds,
           generated_at}``

    Where:
        - ``level``: "calm" | "working" | "busy" | "overloaded"
        - ``summary``: one-line human-readable status
        - ``operations``: list of `{kind, target, elapsed_s}` for each
          active op so the tooltip can list them
    """
    # Cache check
    now = _now_seconds()
    cached = _cache.get("payload")
    if cached and (now - _cache["ts"]) < _CACHE_TTL_SECONDS:
        return cached  # type: ignore[return-value]

    state = request.app.state
    operations: list[dict[str, Any]] = []
    longest_op_seconds = 0.0

    # Active orchestrator dispatches (in-memory dict)
    active_dispatches: dict[str, Any] = {}
    try:
        orch = getattr(state, "orchestrator", None)
        if orch is not None:
            active_dispatches = orch.get_active_dispatches() or {}
    except Exception:
        log.debug("orchestrator.get_active_dispatches failed", exc_info=True)

    for key, info in active_dispatches.items():
        if not isinstance(info, dict):
            continue
        started_at = info.get("started_at")
        elapsed = 0.0
        if started_at:
            try:
                from datetime import UTC, datetime
                if isinstance(started_at, str):
                    parsed = datetime.fromisoformat(started_at.replace("Z", "+00:00"))
                    if parsed.tzinfo is None:
                        parsed = parsed.replace(tzinfo=UTC)
                    elapsed = (datetime.now(UTC) - parsed).total_seconds()
            except Exception:
                elapsed = 0.0
        longest_op_seconds = max(longest_op_seconds, elapsed)
        operations.append({
            "kind": info.get("task_summary") or info.get("agent") or "dispatch",
            "agent": info.get("agent") or key,
            "target": info.get("target", ""),
            "elapsed_s": round(elapsed, 1),
        })

    # Work queue snapshot (in-memory aggregation, fast)
    queue_status: dict[str, Any] = {
        "pending": 0, "retrying": 0,
        "running_live": 0, "running_orphan": 0,
        "completed": 0, "dead_letter": 0,
    }
    try:
        wq = getattr(state, "work_queue", None)
        if wq is not None:
            wq_status = await wq.get_status()
            counts = wq_status.get("counts", {}) if isinstance(wq_status, dict) else {}
            for k in queue_status:
                queue_status[k] = int(counts.get(k, 0))
    except Exception:
        log.debug("work_queue.get_status failed", exc_info=True)

    # Decision logger health (lock errors, failure rate)
    decision_health: dict[str, Any] = {
        "attempts": 0, "failures": 0, "rate": 0.0,
        "last_error": "", "last_error_age_s": None,
    }
    recent_lock_errors = 0
    try:
        dec = getattr(state, "decisions", None)
        if dec is not None:
            h = dec.health()
            decision_health["attempts"] = int(h.get("record_attempts", 0))
            decision_health["failures"] = int(h.get("record_failures", 0))
            decision_health["rate"] = (
                decision_health["failures"] / max(1, decision_health["attempts"])
            )
            decision_health["last_error"] = str(h.get("last_error", ""))[:160]
            last_err_ts = h.get("last_error_ts", "")
            if last_err_ts:
                try:
                    from datetime import UTC, datetime
                    parsed = datetime.fromisoformat(last_err_ts.replace("Z", "+00:00"))
                    if parsed.tzinfo is None:
                        parsed = parsed.replace(tzinfo=UTC)
                    age_s = (datetime.now(UTC) - parsed).total_seconds()
                    decision_health["last_error_age_s"] = round(age_s, 0)
                    # Count as "recent" if within last 60 seconds
                    if age_s < 60 and "locked" in decision_health["last_error"].lower():
                        recent_lock_errors = 1
                except Exception:
                    pass
    except Exception:
        log.debug("decisions.health failed", exc_info=True)

    # ── Phase 2 signals (added 2026-05-07) ─────────────────────────
    # All four reads are in-memory or single-row SQL — no filesystem
    # walk per the architectural rule. Each block is fail-open: a
    # broken sub-source must NEVER prevent the endpoint from returning.

    # Event-loop tracker — captures the canonical "app frozen for 5+s"
    # signal that no other source sees (orchestrator + queue look fine
    # while the loop is starved). The summary() call is a pure
    # in-memory ring-buffer scan.
    el_blocks_500ms = 0
    el_blocks_5s = 0
    el_total_blocks_minute = 0
    try:
        tracker = getattr(state, "perf_tracker", None)
        if tracker is not None:
            s = tracker.summary() or {}
            el_total_blocks_minute = int(s.get("blocks_last_minute", 0))
            el_blocks_500ms = int(s.get("blocks_over_500ms_last_minute", 0))
            el_blocks_5s = int(s.get("blocks_over_5s_last_minute", 0))
    except Exception:
        log.debug("perf_tracker.summary failed", exc_info=True)

    # Memory monitor — read the LAST classified action, no fresh
    # sample. Heartbeat updates this every tick; busy endpoint just
    # surfaces it for cheap. Fail-soft to "ok".
    memory_action = "ok"
    memory_action_label = "ok"
    try:
        hb = getattr(state, "heartbeat", None)
        mm = getattr(hb, "_memory_monitor", None) if hb is not None else None
        if mm is not None and hasattr(mm, "last_action"):
            la = mm.last_action
            # MemoryAction enum has a .value (string); fall back to
            # str() for any stub / mock that exposes a different shape.
            memory_action = (getattr(la, "value", None) or str(la) or "ok").lower()
            memory_action_label = memory_action
    except Exception:
        log.debug("memory_monitor.last_action failed", exc_info=True)

    # Watcher cycle health — derive "currently overrunning" from the
    # cheap in-memory _last_cycle_at + _interval attributes. NEVER
    # call get_status() (it walks the quarantine dir).
    watcher_overrun = False
    watcher_overrun_seconds = 0.0
    watcher_running = False
    try:
        rw = getattr(state, "raw_watcher", None)
        if rw is not None:
            watcher_running = bool(getattr(rw, "_running", False))
            interval = float(getattr(rw, "_interval", 0.0) or 0.0)
            last_cycle_at = float(getattr(rw, "_last_cycle_at", 0.0) or 0.0)
            if watcher_running and interval > 0 and last_cycle_at > 0:
                age = max(0.0, now - last_cycle_at)
                # Overrun = no successful cycle in 2x the configured
                # interval. The watcher cycle itself is bounded; if
                # it's been silent that long, work is queued behind it.
                if age > 2.0 * interval:
                    watcher_overrun = True
                    watcher_overrun_seconds = age
    except Exception:
        log.debug("raw_watcher state read failed", exc_info=True)

    # Cron currently-running rows — single-row SQL COUNT against the
    # automation DB. No filesystem touch.
    cron_running = 0
    try:
        cron = getattr(state, "cron", None)
        cron_db = getattr(cron, "_db", None) if cron is not None else None
        if cron_db is not None:
            try:
                cur = await cron_db.execute(
                    "SELECT COUNT(*) FROM cron_history WHERE status='running'",
                )
                row = await cur.fetchone()
                if row is not None:
                    cron_running = int(row[0] or 0)
                await cur.close()
            except Exception:
                # Schema may not exist yet on a fresh boot — silently
                # treat as zero. The first check_and_run() creates it.
                log.debug("cron_history COUNT failed", exc_info=True)
    except Exception:
        log.debug("cron snapshot failed", exc_info=True)

    # Classify (now with Phase 2 signals widening the surface)
    level = classify_load_level(
        active_dispatches=len(active_dispatches),
        queue_running_live=queue_status["running_live"],
        queue_running_orphan=queue_status["running_orphan"],
        queue_pending=queue_status["pending"] + queue_status["retrying"],
        recent_lock_errors=recent_lock_errors,
        longest_op_seconds=longest_op_seconds,
        decision_failure_rate=decision_health["rate"],
        event_loop_blocks_over_5s_last_minute=el_blocks_5s,
        event_loop_blocks_over_500ms_last_minute=el_blocks_500ms,
        memory_action=memory_action,
        watcher_cycle_overrun=watcher_overrun,
        cron_running_count=cron_running,
    )

    # Human summary — what to show in the tooltip top line. The
    # priority order matches the classifier so the summary names the
    # FIRST condition that escalated the level (most actionable signal).
    if level == "calm":
        summary = "Idle"
    elif level == "working":
        bits = []
        if active_dispatches:
            bits.append(f"{len(active_dispatches)} agent(s) working")
        if queue_status["pending"] + queue_status["retrying"] > 0:
            bits.append(
                f"{queue_status['pending'] + queue_status['retrying']} job(s) queued",
            )
        if cron_running >= 1:
            bits.append(f"{cron_running} cron job(s) running")
        summary = " · ".join(bits) if bits else "Background work in progress"
    elif level == "busy":
        if el_blocks_500ms >= 3:
            summary = f"Event loop pressure ({el_blocks_500ms} stalls/min)"
        elif "warn" in memory_action:
            summary = "Memory pressure (warn threshold)"
        elif watcher_overrun:
            summary = f"Watcher cycle overrunning ({int(watcher_overrun_seconds)}s)"
        elif longest_op_seconds > 30:
            summary = f"Heavy operation in flight ({int(longest_op_seconds)}s)"
        else:
            summary = f"{len(active_dispatches) + queue_status['running_live']} ops running"
    else:  # overloaded
        if el_blocks_5s >= 1:
            summary = f"Event loop frozen ({el_blocks_5s} block(s) ≥5s in last minute)"
        elif "ceiling" in memory_action:
            summary = "Memory at hard ceiling — process may shut down"
        elif "alarm" in memory_action:
            summary = "Memory pressure (alarm threshold)"
        elif recent_lock_errors:
            summary = "Database contention detected"
        elif decision_health["rate"] > 0.10:
            summary = f"Elevated error rate ({decision_health['rate']:.0%})"
        elif queue_status["running_orphan"] >= 3:
            summary = f"{queue_status['running_orphan']} stuck workers"
        else:
            summary = "System under heavy load"

    payload = {
        "level": level,
        "summary": summary,
        "active_dispatches": len(active_dispatches),
        "queue": queue_status,
        "operations": operations,
        "decision_logger": decision_health,
        "recent_lock_errors": recent_lock_errors,
        "longest_op_seconds": round(longest_op_seconds, 1),
        # Phase 2 signals — surfaced for the tooltip + Admin debug view
        "event_loop": {
            "blocks_last_minute": el_total_blocks_minute,
            "blocks_over_500ms_last_minute": el_blocks_500ms,
            "blocks_over_5s_last_minute": el_blocks_5s,
        },
        "memory": {
            "action": memory_action_label,
        },
        "watcher": {
            "running": watcher_running,
            "cycle_overrun": watcher_overrun,
            "cycle_overrun_seconds": round(watcher_overrun_seconds, 1),
        },
        "cron": {
            "running_count": cron_running,
        },
        "generated_at": now,
    }
    _cache["ts"] = now
    _cache["payload"] = payload
    return payload
