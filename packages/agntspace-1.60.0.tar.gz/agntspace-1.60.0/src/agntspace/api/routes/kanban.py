"""Kanban boards + tasks REST API — v1 backend foundation.

Shipped 2026-05-08. P0 from
[plan-performance-roadmap.md](../../../../tasks/plan-performance-roadmap.md).
v1 ships the read + manual-mutation surface; v2 adds worker claim/handoff
endpoints (``POST /api/kanban/tasks/{id}/claim`` etc.); v3 adds the
slash-command entry point.

Route shape mirrors other CRUD subsystems (tasks, projects, goals):
- ``GET`` paths return Rule-20 shapes (``{items, total, has_more}``)
  for paginatable lists, single-record dicts for lookups.
- Every mutating endpoint has a workflow test under
  ``tests/e2e/workflows/`` (Rule 19).
- Every mutating endpoint is classified in ``activity_middleware``
  (Rule 13).
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

log = logging.getLogger(__name__)

router = APIRouter(prefix="/kanban", tags=["kanban"])


# ── Request bodies ──


class _BoardCreate(BaseModel):
    title: str
    description: str = ""
    project_slug: str = ""
    columns: list[str] | None = None
    slug_override: str = ""


class _BoardPatch(BaseModel):
    title: str | None = None
    description: str | None = None
    project_slug: str | None = None
    columns: list[str] | None = None


class _BoardArchive(BaseModel):
    archived: bool = True


class _TaskCreate(BaseModel):
    title: str
    description: str = ""
    column_name: str = "Backlog"
    priority: int = 0
    max_retries: int = Field(default=3, ge=0)
    payload: dict[str, Any] | None = None
    correlation_id: str = ""


class _TaskPatch(BaseModel):
    title: str | None = None
    description: str | None = None
    priority: int | None = None
    max_retries: int | None = Field(default=None, ge=0)
    payload: dict[str, Any] | None = None
    result: str | None = None
    error: str | None = None
    blocked_reason: str | None = None


class _TaskMove(BaseModel):
    column_name: str
    position: int | None = None


# ── v2 worker-loop request bodies ──


class _ClaimRequest(BaseModel):
    worker_id: str
    column: str = "Ready"


class _HeartbeatRequest(BaseModel):
    worker_id: str


class _CompleteRequest(BaseModel):
    worker_id: str
    result: str = ""


class _FailRequest(BaseModel):
    worker_id: str
    error: str
    retry: bool = True


# ── Helpers ──


def _service(request: Request):
    """Extract KanbanService from app.state, 503 when unwired."""
    svc = getattr(request.app.state, "kanban", None)
    if svc is None:
        raise HTTPException(
            status_code=503,
            detail="kanban service is not wired",
        )
    return svc


# ── Board routes ──


@router.get("/boards")
async def list_boards(request: Request, include_archived: bool = False) -> dict:
    """All boards. Default hides archived; ``?include_archived=true`` shows them.

    Returns Rule-20 shape: ``{items, total, has_more}``. Boards are bounded
    by domain (a vault rarely has more than tens of boards) so ``has_more``
    is always False, but the shape is stable for future pagination.
    """
    svc = _service(request)
    boards = await svc.list_boards(include_archived=include_archived)
    return {
        "items": [b.to_public_dict() for b in boards],
        "total": len(boards),
        "has_more": False,
    }


@router.post("/boards")
async def create_board(request: Request, body: _BoardCreate) -> dict:
    """Create a new board. Returns 400 on validation, 409 on slug collision."""
    svc = _service(request)
    try:
        board = await svc.create_board(
            title=body.title,
            description=body.description,
            project_slug=body.project_slug,
            columns=body.columns,
            slug_override=body.slug_override,
        )
    except ValueError as exc:
        msg = str(exc)
        if "already exists" in msg:
            raise HTTPException(status_code=409, detail=msg) from exc
        raise HTTPException(status_code=400, detail=msg) from exc
    return board.to_public_dict()


@router.get("/boards/{slug}")
async def get_board(request: Request, slug: str) -> dict:
    """Fetch board + tasks grouped by column in one round-trip.

    Returns 404 when the slug is unknown. Tasks within each column are
    position-ordered. Empty columns appear as empty lists so the UI
    doesn't reconcile against ``board.columns`` separately.
    """
    svc = _service(request)
    view = await svc.get_board_view(slug)
    if view is None:
        raise HTTPException(status_code=404, detail=f"board not found: {slug}")
    return view


@router.patch("/boards/{slug}")
async def update_board(request: Request, slug: str, body: _BoardPatch) -> dict:
    """Patch board fields. ``slug`` itself is immutable — to rename, archive
    + recreate."""
    svc = _service(request)
    try:
        board = await svc.update_board(
            slug,
            title=body.title,
            description=body.description,
            project_slug=body.project_slug,
            columns=body.columns,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return board.to_public_dict()


@router.post("/boards/{slug}/archive")
async def archive_board(request: Request, slug: str, body: _BoardArchive) -> dict:
    """Soft-delete (or restore) a board.

    POST with ``{"archived": true}`` archives; ``{"archived": false}`` restores.
    """
    svc = _service(request)
    try:
        board = await svc.archive_board(slug, archived=body.archived)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return board.to_public_dict()


# ── Task routes ──


@router.get("/boards/{slug}/tasks")
async def list_tasks(
    request: Request,
    slug: str,
    column: str | None = None,
) -> dict:
    """All tasks on a board. ``?column=Running`` filters to one column.

    Returns Rule-20 shape. Tasks are position-ordered within each column;
    when no column filter is given, ordered by ``(column_name, position)``.
    """
    svc = _service(request)
    try:
        tasks = await svc.list_tasks(slug, column_name=column)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {
        "items": [t.to_public_dict() for t in tasks],
        "total": len(tasks),
        "has_more": False,
    }


@router.post("/boards/{slug}/tasks")
async def create_task(request: Request, slug: str, body: _TaskCreate) -> dict:
    """Create a new task on a board.

    Returns 400 when title is empty / column is invalid / board archived;
    404 when the slug is unknown.
    """
    svc = _service(request)
    try:
        task = await svc.create_task(
            slug,
            title=body.title,
            description=body.description,
            column_name=body.column_name,
            priority=body.priority,
            max_retries=body.max_retries,
            payload=body.payload,
            correlation_id=body.correlation_id,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return task.to_public_dict()


@router.get("/tasks/{task_id}")
async def get_task(request: Request, task_id: int) -> dict:
    """Single-task lookup."""
    svc = _service(request)
    task = await svc.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"task not found: {task_id}")
    return task.to_public_dict()


@router.patch("/tasks/{task_id}")
async def update_task(request: Request, task_id: int, body: _TaskPatch) -> dict:
    """Patch task fields. Use ``POST /tasks/{id}/move`` to change columns
    (separate route so the move semantics + activity event are distinct
    from generic field edits)."""
    svc = _service(request)
    try:
        task = await svc.update_task(
            task_id,
            title=body.title,
            description=body.description,
            priority=body.priority,
            max_retries=body.max_retries,
            payload=body.payload,
            result=body.result,
            error=body.error,
            blocked_reason=body.blocked_reason,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return task.to_public_dict()


@router.post("/tasks/{task_id}/move")
async def move_task(request: Request, task_id: int, body: _TaskMove) -> dict:
    """Move a task to a different column.

    Returns 400 when target column isn't on the board's declared list;
    404 when the task is unknown.
    """
    svc = _service(request)
    try:
        task = await svc.move_task(
            task_id,
            column_name=body.column_name,
            position=body.position,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return task.to_public_dict()


# ── v2 worker-loop routes ──


@router.post("/boards/{slug}/claim")
async def claim_next(request: Request, slug: str, body: _ClaimRequest) -> dict:
    """Atomically claim the next task from a board's claim column.

    Returns the claimed task as a dict, or ``{"task": null}`` when no
    task is available. Returns 400 on invalid worker_id / unknown
    column / archived board; 404 on unknown board slug.

    v2 worker entry point. A worker poll loop calls this with its
    persistent ``worker_id``; on success it executes the task and pings
    ``/heartbeat`` every ~30s until calling ``/complete`` or ``/fail``.
    """
    svc = _service(request)
    try:
        task = await svc.claim_next_task(
            slug,
            worker_id=body.worker_id,
            column=body.column,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"task": task.to_public_dict() if task else None}


@router.post("/tasks/{task_id}/heartbeat")
async def heartbeat_task_route(
    request: Request,
    task_id: int,
    body: _HeartbeatRequest,
) -> dict:
    """Re-stamp the lease for a running task.

    Returns ``{"ok": true}`` if the worker still owns the task, or
    ``{"ok": false}`` if the lease was revoked (zombie reclaim already
    fired, the task was moved by user, or worker_id mismatch). A
    ``false`` return is a signal to the worker to STOP and bail rather
    than racing the new owner.
    """
    svc = _service(request)
    try:
        ok = await svc.heartbeat_task(task_id, body.worker_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"ok": bool(ok), "task_id": task_id}


@router.post("/tasks/{task_id}/complete")
async def complete_task_route(
    request: Request,
    task_id: int,
    body: _CompleteRequest,
) -> dict:
    """Mark a worker-claimed task complete.

    Validates the worker still owns the task. Moves to "Done", clears
    the lease, records the optional result.

    Returns 400 on stale-worker / non-running task; 404 on unknown id.
    """
    svc = _service(request)
    try:
        task = await svc.complete_task(
            task_id,
            body.worker_id,
            result=body.result,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return task.to_public_dict()


@router.post("/tasks/{task_id}/fail")
async def fail_task_route(
    request: Request,
    task_id: int,
    body: _FailRequest,
) -> dict:
    """Mark a worker-claimed task failed.

    If ``retry=true`` (default) AND attempts < max_retries → flip back
    to "Ready" with the lease cleared. Otherwise → dead-letter into
    "Blocked" with the failure reason.

    Returns 400 on stale-worker / non-running task; 404 on unknown id.
    """
    svc = _service(request)
    try:
        task = await svc.fail_task(
            task_id,
            body.worker_id,
            error=body.error,
            retry=body.retry,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return task.to_public_dict()


@router.post("/tasks/{task_id}/retry")
async def retry_task_route(request: Request, task_id: int) -> dict:
    """Move a dead-lettered task back to the claim column.

    User-initiated only. Resets attempts to 0; the next claim_next picks
    it up with a fresh budget. Returns 400 if the task isn't in the
    dead-letter column; 404 on unknown id.
    """
    svc = _service(request)
    try:
        task = await svc.retry_dead_letter_task(task_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return task.to_public_dict()


@router.post("/reclaim")
async def reclaim_route(request: Request) -> dict:
    """Manually trigger a zombie-reclaim sweep.

    Returns ``{"scanned": N, "reclaimed": M, "dead_lettered": K}``. The
    sweep also runs periodically in the background; this endpoint is
    for admin/UI "reclaim now" actions.
    """
    svc = _service(request)
    counts = await svc.reclaim_zombies()
    return counts


@router.delete("/tasks/{task_id}")
async def delete_task(request: Request, task_id: int) -> dict:
    """Hard-delete a task. Returns ``{deleted: bool, task_id}``;
    ``deleted=False`` indicates the id was already gone (idempotent)."""
    svc = _service(request)
    deleted = await svc.delete_task(task_id)
    if not deleted:
        # Stay 200-with-deleted=False rather than 404 so the UI's "delete
        # then refresh" flow is idempotent across concurrent tabs.
        return {"deleted": False, "task_id": task_id}
    return {"deleted": True, "task_id": task_id}
