"""Background job status + cancellation API.

Generic surface for any long-running operation that opted into the
``JobRegistry`` async-job pattern. Started life with ``kb_migrate_to_taxonomy``
as the first consumer (2026-04-27 evening); will grow as ``compile_wiki``,
``run_wiki_job``, ``repair_classifications --apply`` etc. migrate off the
synchronous-blocking shape.

Read-only endpoints (`GET`) are pure. The cancel endpoint sets a
cooperative flag the worker checks between items — workers exit cleanly
at the next checkpoint, leaving the vault in a coherent partial state.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

router = APIRouter(prefix="/jobs", tags=["jobs"])


@router.get("")
async def list_jobs(
    request: Request,
    limit: int = 50,
    kind: str | None = None,
) -> dict:
    """Newest-first list of recent jobs. Supports ``?kind=`` filter for
    "show me only KB migrations". Bounded by the registry's
    ``history_limit`` (50 by default) — finished jobs are evicted oldest-
    first when the bound is reached. Running jobs are never evicted.
    """
    registry = request.app.state.job_registry
    jobs = await registry.list_recent(limit=limit, kind=kind)
    total = await registry.count_recent(kind=kind)
    return {
        "jobs": [j.to_public_dict() for j in jobs],
        # Rule 20: ``count`` is post-slice. ``total`` is the true count
        # for the filter; ``has_more`` is True when the slice didn't
        # cover everything.
        "count": len(jobs),  # deprecated alias for backward compat
        "total": total,
        "has_more": len(jobs) < total,
    }


@router.get("/active")
async def list_active_jobs(request: Request) -> dict:
    """All jobs currently ``pending`` or ``running``. Used by the corner-
    badge indicator + active-jobs page so the user knows what's happening
    without polling every individual job."""
    registry = request.app.state.job_registry
    jobs = await registry.list_active()
    return {
        "jobs": [j.to_public_dict() for j in jobs],
        "count": len(jobs),
    }


@router.get("/{job_id}")
async def get_job(request: Request, job_id: str) -> dict:
    """Snapshot of a single job's current state — phase, progress,
    elapsed, ETA, result (when terminal), error (when failed). Returns
    404 if the job_id is unknown OR has been evicted from history (50-
    entry LRU)."""
    registry = request.app.state.job_registry
    job = await registry.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job not found: {job_id}")
    return job.to_public_dict()


@router.delete("/{job_id}")
async def cancel_job(request: Request, job_id: str) -> dict:
    """Request cooperative cancellation. Workers check the flag between
    items and exit cleanly at the next checkpoint, leaving the vault in
    a coherent state (each phase runs to completion before cancel is
    honored — no mid-phase aborts).

    Returns 404 for unknown job_id, 409 when the job is already terminal
    (completed / failed / cancelled), 200 with ``{cancelled: true}`` on
    a successful flag set."""
    registry = request.app.state.job_registry
    job = await registry.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job not found: {job_id}")
    if job.state in {"completed", "failed", "cancelled"}:
        raise HTTPException(
            status_code=409,
            detail=f"Job is already {job.state}; cannot cancel.",
        )
    ok = await registry.request_cancel(job_id)
    return {"cancelled": ok, "job_id": job_id, "state": job.state}
