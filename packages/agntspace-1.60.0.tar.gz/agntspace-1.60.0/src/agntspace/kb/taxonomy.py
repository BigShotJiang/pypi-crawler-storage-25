"""Knowledge taxonomy — hierarchical 3-level classification for wiki articles.

Loads the taxonomy tree from the bundled defaults and merges any user-supplied
vault override. The taxonomy uses 7 fixed Level-1 categories
(areas / projects / knowledge / entities / digests / workflows / reference).
The L1 set is locked — overrides cannot add an 8th. Level-2 and Level-3 are
freely extensible by users (manual YAML edit) and agents (proposal flow).

NOTE (2026-04-27): the L1 bucket was renamed from "sources" to "digests" to
align with the entity_type "digest" rename (source_summary → digest). Wiki
articles describing source material live at `wiki/digests/...`; the originals
live at `library/digests/...` (same path under both roots — wiki/library
mirror rule, see memory: feedback_wiki_library_mirror.md).
"""

from __future__ import annotations

import copy
import logging
import re
from pathlib import Path
from typing import Any

import yaml

log = logging.getLogger(__name__)

# Flat representation of a taxonomy node
TaxonomyNode = dict[str, Any]

# Fixed Level-1 categories — load-bearing for entity_type inference,
# library layout, and the wiki UI. Cannot be added to or removed via override.
# arch:deterministic — these are architectural slugs, not strategy.
FIXED_L1_SLUGS: tuple[str, ...] = (
    "areas",
    "projects",
    "knowledge",
    "entities",
    "digests",
    "workflows",
    "reference",
)

# Legacy slugs accepted as aliases during the transition period (2026-04-27).
# Any incoming `taxonomy_path` that begins with one of these should be
# mapped to the canonical L1 slug (or to a multi-segment v3 path). Drop
# this map once all live vaults have been migrated through the
# `migrate_to_taxonomy` orchestrator. The replacement value can be a
# single segment ("digests") OR a multi-segment path ("entities/places");
# the rewriter does string concatenation onto the remaining tail.
LEGACY_L1_ALIASES: dict[str, str] = {
    "sources":   "digests",                # source_summary → digest rename
    "concepts":  "knowledge",              # general knowledge articles
    "synthesis": "knowledge",              # syntheses are derived knowledge articles
    "decisions": "reference",              # decision records → reference material
    "org":       "entities/organizations", # legacy single-bucket → v3 sub-bucket
    "places":    "entities/places",
    "products":  "entities/products",
}

_SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

# Minimal degraded-mode tree if every load path fails. Mirrors FIXED_L1_SLUGS so
# downstream code that walks "is L1 in the set" never disagrees with reality.
_FALLBACK_TREE: list[dict] = [
    {"name": s.capitalize(), "slug": s, "description": ""} for s in FIXED_L1_SLUGS
]


def _vault_override_path(vault_dir: Path | None) -> Path | None:
    """Return the path to the vault-side taxonomy override file, or None.

    The override lives at:
      <vault>/agntspace/system/skills/_meta/knowledge-taxonomy/config/taxonomy.yaml
    """
    if not vault_dir:
        return None
    return (
        Path(vault_dir)
        / "agntspace"
        / "system"
        / "skills"
        / "_meta"
        / "knowledge-taxonomy"
        / "config"
        / "taxonomy.yaml"
    )


def _read_yaml(path: Path) -> dict:
    """Read a YAML file. Returns {} on any failure (logged)."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {}
    try:
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            log.warning("Taxonomy YAML at %s is not a mapping — ignoring", path)
            return {}
        return data
    except Exception:
        log.exception("Failed to parse taxonomy YAML at %s", path)
        return {}


def _validate_slug(slug: str) -> bool:
    """A slug must be lowercase ASCII, hyphen-separated, no leading/trailing hyphen."""
    return bool(slug) and bool(_SLUG_RE.match(slug))


def _index_by_slug(nodes: list[dict]) -> dict[str, dict]:
    """Index a list of nodes by their slug. Drops nodes without a valid slug."""
    out: dict[str, dict] = {}
    for n in nodes:
        slug = n.get("slug", "")
        if _validate_slug(slug):
            out[slug] = n
    return out


def _merge_subtree(bundled: list[dict], override: list[dict]) -> list[dict]:
    """Deep-merge two sibling lists by slug.

    - Bundled nodes are preserved in their original order.
    - Override nodes matching a bundled slug update name/description/entity_types
      in place and recurse into children.
    - Override nodes with a new slug append to the end.
    - Override nodes with an invalid slug are dropped (logged).
    """
    bundled_by = _index_by_slug(bundled)
    bundled_order = [n.get("slug", "") for n in bundled if _validate_slug(n.get("slug", ""))]
    override_by = _index_by_slug(override)

    merged: list[dict] = []
    seen: set[str] = set()

    # Pass 1 — bundled nodes (possibly updated by overrides)
    for slug in bundled_order:
        base = copy.deepcopy(bundled_by[slug])
        if slug in override_by:
            ovr = override_by[slug]
            for field in ("name", "description"):
                if isinstance(ovr.get(field), str) and ovr[field]:
                    base[field] = ovr[field]
            if isinstance(ovr.get("entity_types"), list):
                base["entity_types"] = list(ovr["entity_types"])
            base_children = base.get("children", []) or []
            ovr_children = ovr.get("children", []) or []
            if base_children or ovr_children:
                base["children"] = _merge_subtree(base_children, ovr_children)
        merged.append(base)
        seen.add(slug)

    # Pass 2 — new nodes from override (only at L2+, L1 is locked elsewhere)
    for slug, ovr in override_by.items():
        if slug in seen:
            continue
        new_node = copy.deepcopy(ovr)
        # Recurse so nested children pass through validation/normalization
        if isinstance(new_node.get("children"), list):
            new_node["children"] = _merge_subtree([], new_node["children"])
        merged.append(new_node)

    return merged


def _enforce_l1_lock(merged: list[dict], override_l1_slugs: list[str]) -> list[dict]:
    """Reject any override slug that is not in FIXED_L1_SLUGS.

    Returns the filtered tree. Logs a clear error for every rejected slug so
    misconfigurations are visible without crashing the loader.
    """
    fixed_set = set(FIXED_L1_SLUGS)
    extra = [s for s in override_l1_slugs if s and s not in fixed_set]
    if extra:
        log.error(
            "Taxonomy override attempted to add Level-1 categories not in the "
            "fixed set %s: %s — these have been ignored. The 7 Level-1 slugs "
            "are architectural and cannot be extended.",
            list(FIXED_L1_SLUGS),
            extra,
        )
    return [n for n in merged if n.get("slug") in fixed_set]


def load_taxonomy(skills_dir: Path, vault_dir: Path | None = None) -> list[dict]:
    """Load and merge the taxonomy tree.

    Resolution order:
      1. Bundled defaults at <skills_dir>/_meta/knowledge-taxonomy/config/taxonomy.yaml
      2. Vault override at <vault>/agntspace/system/skills/_meta/knowledge-taxonomy/config/taxonomy.yaml
         (partial — merges into bundled, keyed by slug)

    The merged tree is L1-locked — only the 7 fixed Level-1 slugs survive.
    Failures at any stage degrade gracefully to the fallback tree.
    """
    bundled_path = skills_dir / "_meta" / "knowledge-taxonomy" / "config" / "taxonomy.yaml"
    if not bundled_path.is_file():
        log.warning("Bundled taxonomy missing at %s — using fallback", bundled_path)
        return copy.deepcopy(_FALLBACK_TREE)

    bundled_data = _read_yaml(bundled_path)
    bundled_tree = bundled_data.get("taxonomy", []) or []
    if not isinstance(bundled_tree, list) or not bundled_tree:
        return copy.deepcopy(_FALLBACK_TREE)

    override_path = _vault_override_path(vault_dir)
    override_tree: list[dict] = []
    if override_path and override_path.is_file():
        override_data = _read_yaml(override_path)
        candidate = override_data.get("taxonomy", []) or []
        if isinstance(candidate, list):
            override_tree = candidate

    override_l1_slugs = [n.get("slug", "") for n in override_tree if isinstance(n, dict)]

    merged = _merge_subtree(bundled_tree, override_tree)
    merged = _enforce_l1_lock(merged, override_l1_slugs)
    return merged


def get_l1_slugs() -> tuple[str, ...]:
    """Return the fixed Level-1 slug set."""
    return FIXED_L1_SLUGS


def flatten_taxonomy(tree: list[dict], parent_path: str = "") -> list[TaxonomyNode]:
    """Flatten the taxonomy tree into a list of nodes with full paths.

    Each node receives:
      - path: "areas/self/health"
      - depth: 1, 2, or 3 (page title is not a level)
      - entity_types: only what the node DECLARES — not inherited from the parent.
        classify_article uses declared types so a person classifies to
        ``entities/people`` (declared) rather than to a random L3 leaf
        underneath.
    """
    nodes: list[TaxonomyNode] = []
    for node in tree:
        slug = node.get("slug", "")
        if not _validate_slug(slug):
            continue
        path = f"{parent_path}/{slug}" if parent_path else slug
        depth = path.count("/") + 1  # L1=1, L2=2, L3=3
        flat = {
            "name": node.get("name", slug),
            "slug": slug,
            "path": path,
            "depth": depth,
            "description": node.get("description", "") or "",
            "entity_types": list(node.get("entity_types", []) or []),
        }
        nodes.append(flat)
        children = node.get("children", []) or []
        if isinstance(children, list) and children:
            nodes.extend(flatten_taxonomy(children, path))
    return nodes


def is_valid_path(path: str, flat_nodes: list[TaxonomyNode]) -> bool:
    """Return True iff `path` matches an existing node in the merged tree.

    Empty path is treated as invalid (caller decides whether unclassified is OK).
    """
    if not path:
        return False
    return any(n["path"] == path for n in flat_nodes)


def classify_article(
    entity_type: str,
    category: str,
    title: str,
    flat_nodes: list[TaxonomyNode],
) -> str:
    """Determine the best primary taxonomy_path for an article.

    Strategy:
      1. entity_type match — prefer nodes whose declared ``entity_types`` include
         the article's entity_type, picking the DEEPEST match. Skip the broad
         L1 ``entities`` sweep when a deeper L2 like ``entities/people`` exists.
         The generic ``concept`` type falls through to keyword matching since
         ``knowledge`` (which declares concept at L1) is too coarse to be useful.
      2. Keyword match against slug + name + description over title + category.
      3. Empty string when nothing matches — caller (e.g. tree builder) treats
         empty as unclassified.
    """
    _GENERIC_CATEGORIES = {"article", "paper", "image", "data", "code", "uncategorized", ""}
    raw_category = category.lower().strip() if category else ""
    category_lower = "" if raw_category in _GENERIC_CATEGORIES else raw_category
    title_lower = title.lower().strip() if title else ""

    # 1. Declared entity_type match
    if entity_type and entity_type != "concept":
        et_matches = [n for n in flat_nodes if entity_type in n.get("entity_types", [])]
        if et_matches:
            et_matches.sort(key=lambda n: n["depth"], reverse=True)
            return et_matches[0]["path"]

    # 2. Keyword match
    best_match = ""
    best_score = 0.0
    search_text = f"{category_lower} {title_lower}"
    search_words = [w for w in search_text.split() if len(w) > 2]

    for node in flat_nodes:
        score = 0.0
        slug = node["slug"]
        name_lower = node["name"].lower()
        desc_lower = node["description"].lower()
        match_text = f"{slug} {name_lower} {desc_lower}"

        if category_lower and category_lower == slug:
            score += 10
        if category_lower:
            for word in category_lower.split():
                if len(word) > 2 and word in slug:
                    score += 3
                if len(word) > 2 and word in name_lower:
                    score += 2
        for word in search_words:
            if word in match_text:
                score += 2
        if score > 0:
            score += node["depth"] * 0.5

        if score > best_score:
            best_score = score
            best_match = node["path"]

    return best_match


# ─────────────────────────────────────────────────────────────────────
# Tree-with-counts (for the wiki UI)
# ─────────────────────────────────────────────────────────────────────


def _first_letter_bucket(title: str) -> str:
    """Bucket key for the first character of a title — 'A'-'Z' or '#'."""
    s = (title or "").strip()
    if not s:
        return "#"
    ch = s[0].upper()
    if "A" <= ch <= "Z":
        return ch
    return "#"


def _is_research_article(art: dict) -> bool:
    """Detect a research-produced wiki article.

    Pure function. An article counts as research-bearing when its
    frontmatter ``provenance`` is ``"researched"`` (set by every
    research-write path: ``research_topic`` / ``research_topic_deep`` /
    the legacy ``research_kb`` synthesis path). Returns False for any
    other provenance string AND for missing/empty values, so legacy
    articles without provenance frontmatter never spuriously count.
    """
    return str(art.get("provenance", "") or "").strip().lower() == "researched"


def build_taxonomy_tree_with_counts(
    tree: list[dict], articles: list[dict], *, lite: bool = False,
) -> list[dict]:
    """Build the taxonomy tree annotated with article counts per node.

    Each node carries:
        count             — articles filed directly at this node
        total             — count + sum(child totals)
        research_count    — articles at this node whose provenance is
                            "researched" (S3 dossier outputs).  Drives
                            the wiki-tree research-badge UX.
        research_total    — research_count + sum(child research_totals)
                            so any ancestor of a research-bearing node
                            shows the badge as well.
    """
    path_articles: dict[str, list[dict]] = {}
    unclassified: list[dict] = []
    for art in articles:
        tp = art.get("taxonomy_path", "")
        if tp:
            path_articles.setdefault(tp, []).append(art)
        else:
            cat = art.get("category", "")
            if cat:
                path_articles.setdefault(cat, []).append(art)
            else:
                unclassified.append(art)

    def _letter_counts(direct: list[dict]) -> dict[str, int]:
        buckets: dict[str, int] = {}
        for a in direct:
            key = _first_letter_bucket(a.get("title") or a.get("slug") or "")
            buckets[key] = buckets.get(key, 0) + 1
        return buckets

    def _research_count(direct: list[dict]) -> int:
        return sum(1 for a in direct if _is_research_article(a))

    def _annotate(nodes: list[dict], parent_path: str = "") -> list[dict]:
        result = []
        for node in nodes:
            slug = node.get("slug", "")
            path = f"{parent_path}/{slug}" if parent_path else slug
            children = node.get("children", []) or []

            direct = path_articles.get(path, [])
            annotated_children = _annotate(children, path) if children else []
            child_total = sum(c.get("total", 0) for c in annotated_children)
            child_research = sum(c.get("research_total", 0) for c in annotated_children)
            direct_research = _research_count(direct)

            entry: dict = {
                "name": node.get("name", slug),
                "slug": slug,
                "path": path,
                "description": node.get("description", "") or "",
                "count": len(direct),
                "total": len(direct) + child_total,
                "research_count": direct_research,
                "research_total": direct_research + child_research,
                "letter_counts": _letter_counts(direct),
                "children": annotated_children,
            }
            if not lite:
                entry["articles"] = [
                    {"slug": a.get("slug", ""), "title": a.get("title", "")}
                    for a in direct
                ]
            result.append(entry)
        return result

    annotated = _annotate(tree)

    if unclassified:
        unclass_research = _research_count(unclassified)
        u_entry: dict = {
            "name": "Unclassified",
            "slug": "unclassified",
            "path": "unclassified",
            "description": "Articles not yet classified into the taxonomy",
            "count": len(unclassified),
            "total": len(unclassified),
            "research_count": unclass_research,
            "research_total": unclass_research,
            "letter_counts": _letter_counts(unclassified),
            "children": [],
        }
        if not lite:
            u_entry["articles"] = [
                {"slug": a.get("slug", ""), "title": a.get("title", "")}
                for a in unclassified
            ]
        annotated.append(u_entry)

    return annotated


def articles_for_path(
    articles: list[dict],
    path: str,
    *,
    letter: str | None = None,
    offset: int = 0,
    limit: int = 200,
) -> dict:
    """Return a paginated slice of articles filed at a specific taxonomy path."""
    if limit < 1:
        limit = 1
    if limit > 1000:
        limit = 1000
    if offset < 0:
        offset = 0

    path = path.strip()

    matched: list[dict] = []
    for art in articles:
        tp = art.get("taxonomy_path", "")
        if not tp:
            tp = art.get("category", "")
        if path == "unclassified":
            if tp == "":
                matched.append(art)
        elif tp == path:
            matched.append(art)

    if letter:
        letter_u = letter.upper()
        matched = [
            art for art in matched
            if _first_letter_bucket(art.get("title") or art.get("slug") or "") == letter_u
        ]

    matched.sort(key=lambda a: (a.get("title") or a.get("slug") or "").lower())

    total = len(matched)
    page = matched[offset : offset + limit]
    return {
        "articles": [
            {
                "slug": a.get("slug", ""),
                "title": a.get("title", ""),
                "entity_type": a.get("entity_type", ""),
                "provenance": a.get("provenance", ""),
                "kb": a.get("kb", ""),
            }
            for a in page
        ],
        "total": total,
        "offset": offset,
        "limit": limit,
        "has_more": offset + limit < total,
    }


def taxonomy_for_prompt(tree: list[dict], indent: int = 0) -> str:
    """Render the taxonomy tree as indented text for LLM prompts."""
    lines = []
    prefix = "  " * indent
    for node in tree:
        name = node.get("name", "")
        slug = node.get("slug", "")
        desc = node.get("description", "") or ""
        lines.append(f"{prefix}- {name} (slug: {slug}) — {desc}")
        children = node.get("children", []) or []
        if children:
            lines.append(taxonomy_for_prompt(children, indent + 1))
    return "\n".join(lines)
