"""Kanban board + task service — v1 backend foundation + v2 worker loop.

v1 shipped 2026-05-08, v2 shipped 2026-05-11 evening (this commit). P0
from [plan-performance-roadmap.md](../../../../tasks/plan-performance-roadmap.md).
v1 = board + manual tasks. v2 adds the worker claim/handoff/zombie loop
on top of the lease/heartbeat columns the v1 schema already declared, so
v2 ships as a pure feature add with no migration — same architectural
shape the work_queue schema applied with its lease columns in P2 Phase
1 sub-piece 2 (2026-05-05).

Architecture decisions (locked):

1. **Two tables** on ``automation.db``: ``kanban_boards`` + ``kanban_tasks``.
   NO separate ``kanban_workers`` table — workers are processes already
   tracked in ``ProcessRegistry``. Tasks reference them by
   ``assigned_worker_id`` matching ``process_registry.process_id``
   (composite ``f"{pid}-{started_at}"``). Single source of truth for liveness.
2. **Default columns** stored per-board as JSON
   (``["Backlog","Ready","Running","Review","Done","Blocked"]``), but
   user-customizable per board on creation.
3. **State transitions** in v1 are pure column moves. No claim/handoff/zombie
   loop yet — v2's job. The schema declares ``last_heartbeat_at`` +
   ``lease_until`` + ``assigned_worker_id`` columns so v2 is additive.
4. **Slug** is URL-safe, derived from title, unique within ``kanban_boards``.
   Tasks have only integer IDs (titles can repeat).
5. **`correlation_id`** on tasks so completed tasks deep-link into
   ``/decisions`` for the causal chain.
6. **Position within column**: sparse integer (multiples of 10). Reorder
   inserts at midpoint between neighbours when possible; rebalance when
   gaps shrink.
7. **Soft delete**: ``archived=1`` flag on boards; cascades to tasks via
   service logic (not FK trigger so we keep tasks queryable for audit).

Concurrency: each method takes the connection's implicit transaction.
Boards + tasks rarely have hot-loop write contention (user-initiated
mutations) so optimistic concurrency is sufficient. v2's claim path will
add explicit CAS for the worker race.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import unicodedata
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

import aiosqlite

log = logging.getLogger(__name__)

# arch:deterministic — default board column ladder. Boards may override
# on creation; this is the seed that ships if the user just creates a
# board with title only.
DEFAULT_COLUMNS: tuple[str, ...] = (
    "Backlog",
    "Ready",
    "Running",
    "Review",
    "Done",
    "Blocked",
)

# arch:deterministic — sparse position spacing. Tasks insert at intervals
# of this value so reorder can find a midpoint without rebalancing in
# the common case. When gaps narrow below 1, the column triggers a
# full renumbering pass on next reorder.
_POSITION_STRIDE: int = 10

# arch:deterministic — terminal columns where attempts/heartbeat/lease
# are expected to be cleared. Used by the move-to-column logic to keep
# state coherent when work transitions from in-flight to done.
_TERMINAL_COLUMNS: frozenset[str] = frozenset({"Done"})

# arch:deterministic — v2 worker loop tuning constants. Mirror work_queue's
# numbers so a worker that already speaks the work_queue protocol can drive
# Kanban with the same intervals.
_DEFAULT_LEASE_SECONDS: int = 300  # 5 min; ~2× the heartbeat interval below × 2 for safety margin
_DEFAULT_HEARTBEAT_INTERVAL_SECONDS: int = 30  # worker re-pings every 30s during work
_DEFAULT_RECLAIM_INTERVAL_SECONDS: int = 60  # service sweeps for zombies every 60s
_DEFAULT_DEAD_LETTER_COLUMN: str = "Blocked"  # where exhausted-retry zombies land
_DEFAULT_CLAIM_COLUMN: str = "Ready"  # where claim_next pulls from


@dataclass
class KanbanBoard:
    """Snapshot of a board row. Use ``KanbanService`` to mutate."""

    id: int
    slug: str
    title: str
    description: str
    project_slug: str
    columns: list[str]
    created_at: str
    updated_at: str
    archived: bool

    def to_public_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class KanbanTask:
    """Snapshot of a task row. Use ``KanbanService`` to mutate."""

    id: int
    board_id: int
    title: str
    description: str
    column_name: str
    position: int
    assigned_worker_id: str
    priority: int
    max_retries: int
    attempts: int
    last_heartbeat_at: str
    lease_until: str
    payload: dict[str, Any] = field(default_factory=dict)
    result: str = ""
    error: str = ""
    blocked_reason: str = ""
    created_at: str = ""
    updated_at: str = ""
    started_at: str = ""
    completed_at: str = ""
    correlation_id: str = ""

    def to_public_dict(self) -> dict[str, Any]:
        return asdict(self)


def _slugify(text: str) -> str:
    """ASCII slug for URL-safe board ids.

    Mirrors ``finance/merchants.py::_slugify`` for cross-codebase consistency.
    Diacritics → ASCII via NFKD normalize + drop non-alphanumeric.
    Empty input → empty string; caller supplies a fallback.
    """
    if not text:
        return ""
    normalised = unicodedata.normalize("NFKD", text.strip().lower())
    ascii_only = normalised.encode("ascii", "ignore").decode("ascii")
    cleaned = re.sub(r"[^a-z0-9]+", "-", ascii_only)
    return cleaned.strip("-")


def _now_iso() -> str:
    """Current UTC time, ISO-8601. Single source so tests can monkeypatch one site."""
    return datetime.now(UTC).isoformat()


def _row_to_board(row: aiosqlite.Row) -> KanbanBoard:
    """Defensive row → dataclass. JSON column field decoded with fallback."""
    # ``SELECT *`` from the schema we created always returns the canonical
    # columns; the JSON-decode fallback below is the real defense against
    # corrupted column values written through manual SQL.
    cols_raw = row["columns"]
    try:
        cols = json.loads(cols_raw or "[]")
        if not isinstance(cols, list):
            cols = list(DEFAULT_COLUMNS)
    except Exception:
        cols = list(DEFAULT_COLUMNS)
    return KanbanBoard(
        id=int(row["id"]),
        slug=row["slug"] or "",
        title=row["title"] or "",
        description=row["description"] or "",
        project_slug=row["project_slug"] or "",
        columns=cols,
        created_at=row["created_at"] or "",
        updated_at=row["updated_at"] or "",
        archived=bool(row["archived"]),
    )


def _row_to_task(row: aiosqlite.Row) -> KanbanTask:
    """Defensive row → dataclass. Payload JSON decoded with fallback."""
    # Same convention as ``_row_to_board``: SELECT * over a known schema
    # always returns the canonical columns; the JSON-decode fallback below
    # defends against corrupted JSON values, which is the real risk.
    payload_raw = row["payload"]
    try:
        payload = json.loads(payload_raw or "{}")
        if not isinstance(payload, dict):
            payload = {}
    except Exception:
        payload = {}
    # max_retries: explicit-None defense (0 is a legitimate value — never
    # silently coerce to 3 via the `or` fallback the v1 code shipped with).
    raw_max_retries = row["max_retries"]
    max_retries_val = int(raw_max_retries) if raw_max_retries is not None else 3
    return KanbanTask(
        id=int(row["id"]),
        board_id=int(row["board_id"]),
        title=row["title"] or "",
        description=row["description"] or "",
        column_name=row["column_name"] or "Backlog",
        position=int(row["position"] or 0),
        assigned_worker_id=row["assigned_worker_id"] or "",
        priority=int(row["priority"] or 0),
        max_retries=max_retries_val,
        attempts=int(row["attempts"] or 0),
        last_heartbeat_at=row["last_heartbeat_at"] or "",
        lease_until=row["lease_until"] or "",
        payload=payload,
        result=row["result"] or "",
        error=row["error"] or "",
        blocked_reason=row["blocked_reason"] or "",
        created_at=row["created_at"] or "",
        updated_at=row["updated_at"] or "",
        started_at=row["started_at"] or "",
        completed_at=row["completed_at"] or "",
        correlation_id=row["correlation_id"] or "",
    )


class KanbanService:
    """Boards + tasks CRUD on automation.db.

    Idempotent ``init_schema()`` runs at boot. All write paths commit
    explicitly. Read paths use ``async with self._db.execute(...)`` for
    cursor cleanup.

    Activity logger is optional — every mutation emits an event when wired,
    no-ops gracefully when ``activity_logger=None`` (tests, minimal installs).
    """

    def __init__(
        self,
        db: aiosqlite.Connection,
        *,
        activity_logger: Any = None,
        lease_seconds: int | None = None,
        heartbeat_interval_seconds: int | None = None,
        reclaim_interval_seconds: int | None = None,
    ) -> None:
        self._db = db
        self._activity = activity_logger
        # v2 worker-loop knobs. Defaults mirror work_queue's lease numbers
        # so a Kanban worker can use the same heartbeat cadence as a
        # work_queue worker without re-tuning.
        self._lease_seconds = lease_seconds if lease_seconds is not None else _DEFAULT_LEASE_SECONDS
        self._heartbeat_interval_seconds = (
            heartbeat_interval_seconds
            if heartbeat_interval_seconds is not None
            else _DEFAULT_HEARTBEAT_INTERVAL_SECONDS
        )
        self._reclaim_interval_seconds = (
            reclaim_interval_seconds
            if reclaim_interval_seconds is not None
            else _DEFAULT_RECLAIM_INTERVAL_SECONDS
        )
        # Background reclaim loop handle. Set by start_reclaim_loop(); cleared
        # by stop_reclaim_loop(). None when no loop is running (tests, minimal
        # installs, or pre-startup).
        self._reclaim_task: asyncio.Task[None] | None = None

    # ── Schema ──

    async def init_schema(self) -> None:
        """Create kanban tables + indexes. Idempotent."""
        await self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS kanban_boards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                project_slug TEXT NOT NULL DEFAULT '',
                columns TEXT NOT NULL DEFAULT '[]',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                archived INTEGER NOT NULL DEFAULT 0
            );

            CREATE INDEX IF NOT EXISTS idx_kb_board_slug ON kanban_boards(slug);
            CREATE INDEX IF NOT EXISTS idx_kb_board_archived ON kanban_boards(archived);
            CREATE INDEX IF NOT EXISTS idx_kb_board_project ON kanban_boards(project_slug);

            CREATE TABLE IF NOT EXISTS kanban_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                board_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                column_name TEXT NOT NULL DEFAULT 'Backlog',
                position INTEGER NOT NULL DEFAULT 0,
                assigned_worker_id TEXT NOT NULL DEFAULT '',
                priority INTEGER NOT NULL DEFAULT 0,
                max_retries INTEGER NOT NULL DEFAULT 3,
                attempts INTEGER NOT NULL DEFAULT 0,
                last_heartbeat_at TEXT NOT NULL DEFAULT '',
                lease_until TEXT NOT NULL DEFAULT '',
                payload TEXT NOT NULL DEFAULT '{}',
                result TEXT NOT NULL DEFAULT '',
                error TEXT NOT NULL DEFAULT '',
                blocked_reason TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                started_at TEXT NOT NULL DEFAULT '',
                completed_at TEXT NOT NULL DEFAULT '',
                correlation_id TEXT NOT NULL DEFAULT ''
            );

            CREATE INDEX IF NOT EXISTS idx_kb_task_board ON kanban_tasks(board_id);
            CREATE INDEX IF NOT EXISTS idx_kb_task_column ON kanban_tasks(column_name);
            CREATE INDEX IF NOT EXISTS idx_kb_task_worker ON kanban_tasks(assigned_worker_id);
            CREATE INDEX IF NOT EXISTS idx_kb_task_heartbeat ON kanban_tasks(last_heartbeat_at);
            CREATE INDEX IF NOT EXISTS idx_kb_task_lease ON kanban_tasks(lease_until);
            CREATE INDEX IF NOT EXISTS idx_kb_task_correlation ON kanban_tasks(correlation_id);
            """,
        )
        await self._db.commit()

    # ── Activity logging helper (graceful degrade) ──

    def _log_activity(
        self,
        action: str,
        summary: str,
        *,
        importance: str = "low",
        details: dict[str, Any] | None = None,
    ) -> None:
        """Emit an activity event when logger is wired. Never raises."""
        if not self._activity:
            return
        try:
            self._activity.log(
                category="user",
                action=action,
                summary=summary,
                importance=importance,
                details=details or {},
            )
        except Exception:
            log.debug("kanban: activity logger emit failed", exc_info=True)

    # ── Board CRUD ──

    async def create_board(
        self,
        *,
        title: str,
        description: str = "",
        project_slug: str = "",
        columns: list[str] | None = None,
        slug_override: str = "",
    ) -> KanbanBoard:
        """Create a new board.

        Slug is derived from title unless ``slug_override`` is supplied.
        Collisions raise ``ValueError`` — caller picks a different title or
        passes a unique override. Empty title raises ``ValueError``.
        Empty ``columns`` falls back to ``DEFAULT_COLUMNS``.
        """
        title_clean = (title or "").strip()
        if not title_clean:
            raise ValueError("title is required")

        slug = (slug_override or _slugify(title_clean)).strip()
        if not slug:
            raise ValueError("could not derive a slug from title")

        cols = columns if columns else list(DEFAULT_COLUMNS)
        # Normalize and validate column list — strip whitespace, drop empties.
        cols = [c.strip() for c in cols if isinstance(c, str) and c.strip()]
        if not cols:
            cols = list(DEFAULT_COLUMNS)
        cols_json = json.dumps(cols)

        now = _now_iso()
        try:
            async with self._db.execute(
                """
                INSERT INTO kanban_boards
                    (slug, title, description, project_slug, columns, created_at, updated_at, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (slug, title_clean, description.strip(), project_slug.strip(), cols_json, now, now),
            ) as cursor:
                board_id = cursor.lastrowid
        except aiosqlite.IntegrityError as exc:
            raise ValueError(f"board slug already exists: {slug}") from exc
        await self._db.commit()

        self._log_activity(
            "kanban_board_created",
            f"Created Kanban board '{title_clean}'",
            importance="medium",
            details={"slug": slug, "board_id": board_id},
        )

        return KanbanBoard(
            id=int(board_id),
            slug=slug,
            title=title_clean,
            description=description.strip(),
            project_slug=project_slug.strip(),
            columns=cols,
            created_at=now,
            updated_at=now,
            archived=False,
        )

    async def list_boards(self, *, include_archived: bool = False) -> list[KanbanBoard]:
        """All boards newest-first."""
        if include_archived:
            sql = "SELECT * FROM kanban_boards ORDER BY created_at DESC"
            args: tuple = ()
        else:
            sql = "SELECT * FROM kanban_boards WHERE archived = 0 ORDER BY created_at DESC"
            args = ()
        boards: list[KanbanBoard] = []
        async with self._db.execute(sql, args) as cursor:
            cursor.row_factory = aiosqlite.Row
            async for row in cursor:
                boards.append(_row_to_board(row))
        return boards

    async def get_board_by_slug(self, slug: str) -> KanbanBoard | None:
        """Lookup by slug. Returns None on miss (caller emits 404)."""
        if not slug:
            return None
        async with self._db.execute(
            "SELECT * FROM kanban_boards WHERE slug = ?",
            (slug,),
        ) as cursor:
            cursor.row_factory = aiosqlite.Row
            row = await cursor.fetchone()
        if row is None:
            return None
        return _row_to_board(row)

    async def update_board(
        self,
        slug: str,
        *,
        title: str | None = None,
        description: str | None = None,
        project_slug: str | None = None,
        columns: list[str] | None = None,
    ) -> KanbanBoard:
        """Patch board fields. Keys with ``None`` value left unchanged.

        Note: ``slug`` is immutable — to rename, archive + recreate.
        Renaming the slug would break every task's ``board_id`` reference's
        lookup-by-slug paths and would require a migration step we don't
        want in v1.
        """
        existing = await self.get_board_by_slug(slug)
        if existing is None:
            raise KeyError(f"board not found: {slug}")

        new_title = (title.strip() if title is not None else existing.title) or existing.title
        new_description = description.strip() if description is not None else existing.description
        new_project = project_slug.strip() if project_slug is not None else existing.project_slug
        if columns is not None:
            cols = [c.strip() for c in columns if isinstance(c, str) and c.strip()]
            if not cols:
                cols = existing.columns
        else:
            cols = existing.columns
        cols_json = json.dumps(cols)
        now = _now_iso()

        await self._db.execute(
            """
            UPDATE kanban_boards
            SET title = ?, description = ?, project_slug = ?, columns = ?, updated_at = ?
            WHERE slug = ?
            """,
            (new_title, new_description, new_project, cols_json, now, slug),
        )
        await self._db.commit()

        self._log_activity(
            "kanban_board_updated",
            f"Updated Kanban board '{new_title}'",
            importance="low",
            details={"slug": slug},
        )

        return KanbanBoard(
            id=existing.id,
            slug=existing.slug,
            title=new_title,
            description=new_description,
            project_slug=new_project,
            columns=cols,
            created_at=existing.created_at,
            updated_at=now,
            archived=existing.archived,
        )

    async def archive_board(self, slug: str, *, archived: bool = True) -> KanbanBoard:
        """Soft-delete a board. Tasks remain queryable for audit.

        ``archived=False`` un-archives — used by the UI's restore action.
        """
        existing = await self.get_board_by_slug(slug)
        if existing is None:
            raise KeyError(f"board not found: {slug}")

        now = _now_iso()
        await self._db.execute(
            "UPDATE kanban_boards SET archived = ?, updated_at = ? WHERE slug = ?",
            (1 if archived else 0, now, slug),
        )
        await self._db.commit()

        action = "kanban_board_archived" if archived else "kanban_board_restored"
        verb = "Archived" if archived else "Restored"
        self._log_activity(
            action,
            f"{verb} Kanban board '{existing.title}'",
            importance="low",
            details={"slug": slug},
        )

        return KanbanBoard(
            id=existing.id,
            slug=existing.slug,
            title=existing.title,
            description=existing.description,
            project_slug=existing.project_slug,
            columns=existing.columns,
            created_at=existing.created_at,
            updated_at=now,
            archived=archived,
        )

    # ── Task CRUD ──

    async def _next_position(self, board_id: int, column_name: str) -> int:
        """Append-tail position. Sparse stride leaves room for inserts."""
        async with self._db.execute(
            "SELECT MAX(position) FROM kanban_tasks WHERE board_id = ? AND column_name = ?",
            (board_id, column_name),
        ) as cursor:
            row = await cursor.fetchone()
        current_max = int(row[0]) if row and row[0] is not None else 0
        return current_max + _POSITION_STRIDE

    async def create_task(
        self,
        board_slug: str,
        *,
        title: str,
        description: str = "",
        column_name: str = "Backlog",
        priority: int = 0,
        max_retries: int = 3,
        payload: dict[str, Any] | None = None,
        correlation_id: str = "",
    ) -> KanbanTask:
        """Create a new task on a board.

        Validates: title non-empty, column_name in board.columns, board not archived.
        """
        title_clean = (title or "").strip()
        if not title_clean:
            raise ValueError("title is required")

        board = await self.get_board_by_slug(board_slug)
        if board is None:
            raise KeyError(f"board not found: {board_slug}")
        if board.archived:
            raise ValueError(f"cannot add task to archived board: {board_slug}")

        col = (column_name or "Backlog").strip()
        if col not in board.columns:
            raise ValueError(
                f"column '{col}' not in board columns {board.columns}",
            )

        payload_json = json.dumps(payload or {}, sort_keys=True)
        now = _now_iso()
        position = await self._next_position(board.id, col)

        async with self._db.execute(
            """
            INSERT INTO kanban_tasks (
                board_id, title, description, column_name, position,
                priority, max_retries, attempts,
                payload, created_at, updated_at, correlation_id
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)
            """,
            (
                board.id, title_clean, description.strip(), col, position,
                int(priority), int(max_retries),
                payload_json, now, now, correlation_id.strip(),
            ),
        ) as cursor:
            task_id = cursor.lastrowid
        await self._db.commit()

        self._log_activity(
            "kanban_task_created",
            f"Created Kanban task '{title_clean}' on board '{board.title}'",
            importance="low",
            details={"board_slug": board_slug, "task_id": task_id, "column": col},
        )

        return KanbanTask(
            id=int(task_id),
            board_id=board.id,
            title=title_clean,
            description=description.strip(),
            column_name=col,
            position=position,
            assigned_worker_id="",
            priority=int(priority),
            max_retries=int(max_retries),
            attempts=0,
            last_heartbeat_at="",
            lease_until="",
            payload=payload or {},
            result="",
            error="",
            blocked_reason="",
            created_at=now,
            updated_at=now,
            started_at="",
            completed_at="",
            correlation_id=correlation_id.strip(),
        )

    async def list_tasks(
        self,
        board_slug: str,
        *,
        column_name: str | None = None,
    ) -> list[KanbanTask]:
        """List tasks for a board, optionally filtered to a column.

        Returns position-ordered tasks within each column. When
        ``column_name`` is None, returns all tasks ordered by
        ``(column_name, position)`` so the UI can group client-side.
        """
        board = await self.get_board_by_slug(board_slug)
        if board is None:
            raise KeyError(f"board not found: {board_slug}")

        if column_name:
            sql = """
                SELECT * FROM kanban_tasks
                WHERE board_id = ? AND column_name = ?
                ORDER BY position ASC, id ASC
            """
            args: tuple = (board.id, column_name)
        else:
            sql = """
                SELECT * FROM kanban_tasks
                WHERE board_id = ?
                ORDER BY column_name ASC, position ASC, id ASC
            """
            args = (board.id,)

        tasks: list[KanbanTask] = []
        async with self._db.execute(sql, args) as cursor:
            cursor.row_factory = aiosqlite.Row
            async for row in cursor:
                tasks.append(_row_to_task(row))
        return tasks

    async def get_task(self, task_id: int) -> KanbanTask | None:
        """Lookup task by id. Returns None on miss."""
        async with self._db.execute(
            "SELECT * FROM kanban_tasks WHERE id = ?",
            (int(task_id),),
        ) as cursor:
            cursor.row_factory = aiosqlite.Row
            row = await cursor.fetchone()
        if row is None:
            return None
        return _row_to_task(row)

    async def update_task(
        self,
        task_id: int,
        *,
        title: str | None = None,
        description: str | None = None,
        priority: int | None = None,
        max_retries: int | None = None,
        payload: dict[str, Any] | None = None,
        result: str | None = None,
        error: str | None = None,
        blocked_reason: str | None = None,
    ) -> KanbanTask:
        """Patch task fields. Column moves use ``move_task`` (separate
        method to keep the move semantics + activity event distinct)."""
        existing = await self.get_task(task_id)
        if existing is None:
            raise KeyError(f"task not found: {task_id}")

        new_title = (title.strip() if title is not None else existing.title) or existing.title
        new_description = description.strip() if description is not None else existing.description
        new_priority = int(priority) if priority is not None else existing.priority
        new_max_retries = int(max_retries) if max_retries is not None else existing.max_retries
        if payload is not None:
            payload_json = json.dumps(payload, sort_keys=True)
        else:
            payload_json = json.dumps(existing.payload, sort_keys=True)
        new_result = result if result is not None else existing.result
        new_error = error if error is not None else existing.error
        new_blocked = blocked_reason if blocked_reason is not None else existing.blocked_reason
        now = _now_iso()

        await self._db.execute(
            """
            UPDATE kanban_tasks SET
                title = ?, description = ?, priority = ?, max_retries = ?,
                payload = ?, result = ?, error = ?, blocked_reason = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                new_title, new_description, new_priority, new_max_retries,
                payload_json, new_result, new_error, new_blocked, now, task_id,
            ),
        )
        await self._db.commit()

        self._log_activity(
            "kanban_task_updated",
            f"Updated Kanban task '{new_title}'",
            importance="low",
            details={"task_id": task_id},
        )

        return KanbanTask(
            id=existing.id,
            board_id=existing.board_id,
            title=new_title,
            description=new_description,
            column_name=existing.column_name,
            position=existing.position,
            assigned_worker_id=existing.assigned_worker_id,
            priority=new_priority,
            max_retries=new_max_retries,
            attempts=existing.attempts,
            last_heartbeat_at=existing.last_heartbeat_at,
            lease_until=existing.lease_until,
            payload=payload if payload is not None else existing.payload,
            result=new_result,
            error=new_error,
            blocked_reason=new_blocked,
            created_at=existing.created_at,
            updated_at=now,
            started_at=existing.started_at,
            completed_at=existing.completed_at,
            correlation_id=existing.correlation_id,
        )

    async def move_task(
        self,
        task_id: int,
        *,
        column_name: str,
        position: int | None = None,
    ) -> KanbanTask:
        """Move a task to a different column.

        - Validates target column is one of the board's declared columns.
        - When ``position`` is None, appends to tail of the new column.
        - Setting column to a terminal column (``Done``) sets
          ``completed_at`` and clears any lease.
        - Setting column to ``Running`` sets ``started_at`` if empty.
        - Setting column AWAY from ``Running`` clears the lease (worker
          implicitly released; v2's worker logic will check this).
        """
        existing = await self.get_task(task_id)
        if existing is None:
            raise KeyError(f"task not found: {task_id}")

        col = (column_name or "").strip()
        if not col:
            raise ValueError("column_name is required")

        # Cross-check against the board's declared columns.
        async with self._db.execute(
            "SELECT columns FROM kanban_boards WHERE id = ?",
            (existing.board_id,),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            raise KeyError(f"board not found for task: {task_id}")
        try:
            board_cols = json.loads(row[0] or "[]")
            if not isinstance(board_cols, list):
                board_cols = list(DEFAULT_COLUMNS)
        except Exception:
            board_cols = list(DEFAULT_COLUMNS)

        if col not in board_cols:
            raise ValueError(f"column '{col}' not in board columns {board_cols}")

        # Compute final position: caller-specified, else append to tail.
        target_position = position if position is not None else (
            await self._next_position(existing.board_id, col)
        )
        target_position = int(target_position)

        now = _now_iso()
        # Side-effects of column transition.
        new_started_at = existing.started_at
        new_completed_at = existing.completed_at
        new_lease_until = existing.lease_until
        new_worker_id = existing.assigned_worker_id

        if col == "Running" and not existing.started_at:
            new_started_at = now
        if col in _TERMINAL_COLUMNS:
            if not existing.completed_at:
                new_completed_at = now
            new_lease_until = ""
            new_worker_id = ""
        if existing.column_name == "Running" and col != "Running":
            # Implicit lease release on move out of Running. Worker dies
            # quietly if it was holding one; v2's worker loop must
            # check the row's column to detect this race.
            new_lease_until = ""
            new_worker_id = ""

        await self._db.execute(
            """
            UPDATE kanban_tasks SET
                column_name = ?, position = ?, started_at = ?, completed_at = ?,
                lease_until = ?, assigned_worker_id = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                col, target_position, new_started_at, new_completed_at,
                new_lease_until, new_worker_id, now, task_id,
            ),
        )
        await self._db.commit()

        self._log_activity(
            "kanban_task_moved",
            f"Moved Kanban task '{existing.title}' to '{col}'",
            importance="low",
            details={
                "task_id": task_id,
                "from_column": existing.column_name,
                "to_column": col,
            },
        )

        return KanbanTask(
            id=existing.id,
            board_id=existing.board_id,
            title=existing.title,
            description=existing.description,
            column_name=col,
            position=target_position,
            assigned_worker_id=new_worker_id,
            priority=existing.priority,
            max_retries=existing.max_retries,
            attempts=existing.attempts,
            last_heartbeat_at=existing.last_heartbeat_at,
            lease_until=new_lease_until,
            payload=existing.payload,
            result=existing.result,
            error=existing.error,
            blocked_reason=existing.blocked_reason,
            created_at=existing.created_at,
            updated_at=now,
            started_at=new_started_at,
            completed_at=new_completed_at,
            correlation_id=existing.correlation_id,
        )

    async def delete_task(self, task_id: int) -> bool:
        """Hard-delete a task. Returns True if a row was deleted."""
        existing = await self.get_task(task_id)
        if existing is None:
            return False
        await self._db.execute("DELETE FROM kanban_tasks WHERE id = ?", (int(task_id),))
        await self._db.commit()
        self._log_activity(
            "kanban_task_deleted",
            f"Deleted Kanban task '{existing.title}'",
            importance="medium",
            details={"task_id": task_id, "board_id": existing.board_id},
        )
        return True

    # ── v2 worker loop (claim / heartbeat / complete / fail / reclaim) ──

    async def claim_next_task(
        self,
        board_slug: str,
        *,
        worker_id: str,
        column: str = _DEFAULT_CLAIM_COLUMN,
    ) -> KanbanTask | None:
        """Atomically claim the next available task from a board's claim column.

        v2 worker entry point. Picks the lowest-position task in ``column``
        (defaults to "Ready") and transitions it to "Running" with the
        worker's identity stamped in ``assigned_worker_id``, the lease
        stamped at ``now + lease_seconds``, and the first heartbeat stamp.
        Increments ``attempts``.

        Returns the claimed task, OR ``None`` if no task is available.

        Concurrency: uses a CAS-style UPDATE on
        ``(id, column_name, assigned_worker_id)`` so two workers racing
        the same row produce exactly one winner — the other gets a 0-row
        UPDATE result and a None return. The single-flight invariant is
        load-bearing for the v2 architectural commitment.

        Raises ``KeyError`` if the board doesn't exist, ``ValueError`` if
        the claim column isn't in the board's declared columns or the
        board is archived. ``worker_id`` must be non-empty.
        """
        worker_id_clean = (worker_id or "").strip()
        if not worker_id_clean:
            raise ValueError("worker_id is required")

        board = await self.get_board_by_slug(board_slug)
        if board is None:
            raise KeyError(f"board not found: {board_slug}")
        if board.archived:
            return None  # archived board has nothing claimable — quiet None, not an error
        col = (column or _DEFAULT_CLAIM_COLUMN).strip()
        if col not in board.columns:
            raise ValueError(f"column '{col}' not in board columns {board.columns}")
        if "Running" not in board.columns:
            raise ValueError(
                "board has no 'Running' column; v2 worker loop requires it",
            )

        # Pick the lowest-position unclaimed task in the claim column.
        # Excludes rows that already have an assigned_worker_id even if
        # they're still in the claim column — defensive against a half-
        # committed prior claim.
        async with self._db.execute(
            """SELECT id FROM kanban_tasks
               WHERE board_id = ?
                 AND column_name = ?
                 AND (assigned_worker_id IS NULL OR assigned_worker_id = '')
               ORDER BY position ASC, id ASC
               LIMIT 1""",
            (board.id, col),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return None
        candidate_id = int(row[0])

        # Atomic claim. The WHERE clause locks single-flight: any prior
        # claim of this row in the same window flips assigned_worker_id
        # to a non-empty string, so the second claimant's UPDATE matches
        # zero rows.
        now_dt = datetime.now(UTC)
        now_iso = now_dt.isoformat()
        lease_until = (now_dt + timedelta(seconds=self._lease_seconds)).isoformat()
        async with self._db.execute(
            """UPDATE kanban_tasks
               SET column_name = 'Running',
                   assigned_worker_id = ?,
                   last_heartbeat_at = ?,
                   lease_until = ?,
                   started_at = CASE WHEN started_at = '' THEN ? ELSE started_at END,
                   attempts = attempts + 1,
                   updated_at = ?
               WHERE id = ?
                 AND column_name = ?
                 AND (assigned_worker_id IS NULL OR assigned_worker_id = '')""",
            (worker_id_clean, now_iso, lease_until, now_iso, now_iso, candidate_id, col),
        ) as cursor:
            updated = cursor.rowcount
        await self._db.commit()

        if not updated:
            # Race lost: another worker claimed the same row between SELECT
            # and UPDATE. Return None; the caller can retry to find another.
            return None

        claimed = await self.get_task(candidate_id)
        if claimed is not None:
            self._log_activity(
                "kanban_task_claimed",
                f"Worker {worker_id_clean} claimed task '{claimed.title}'",
                importance="low",
                details={
                    "task_id": candidate_id,
                    "board_slug": board_slug,
                    "worker_id": worker_id_clean,
                    "attempts": claimed.attempts,
                },
            )
        return claimed

    async def heartbeat_task(
        self,
        task_id: int,
        worker_id: str,
    ) -> bool:
        """Re-stamp the lease + heartbeat for a running task.

        Returns True if the row was updated (worker still owns it), False
        if the worker_id doesn't match (the task was reclaimed by the
        zombie sweep, completed by someone else, or moved by user).

        A False return is a signal to the worker to STOP the current
        execution — its lease has been revoked. Workers should bail
        rather than racing the new owner.

        ``worker_id`` must be non-empty.
        """
        worker_id_clean = (worker_id or "").strip()
        if not worker_id_clean:
            raise ValueError("worker_id is required")

        now_dt = datetime.now(UTC)
        now_iso = now_dt.isoformat()
        lease_until = (now_dt + timedelta(seconds=self._lease_seconds)).isoformat()
        async with self._db.execute(
            """UPDATE kanban_tasks
               SET last_heartbeat_at = ?,
                   lease_until = ?,
                   updated_at = ?
               WHERE id = ?
                 AND assigned_worker_id = ?
                 AND column_name = 'Running'""",
            (now_iso, lease_until, now_iso, int(task_id), worker_id_clean),
        ) as cursor:
            updated = cursor.rowcount
        await self._db.commit()
        return bool(updated)

    async def complete_task(
        self,
        task_id: int,
        worker_id: str,
        *,
        result: str = "",
    ) -> KanbanTask:
        """Mark a worker-claimed task done.

        Validates the worker still owns the task. Moves to "Done",
        clears the lease + worker_id, sets completed_at + result.

        Raises ``KeyError`` if the task doesn't exist; ``ValueError``
        if the worker_id doesn't match (stale worker trying to commit).
        """
        worker_id_clean = (worker_id or "").strip()
        if not worker_id_clean:
            raise ValueError("worker_id is required")

        existing = await self.get_task(task_id)
        if existing is None:
            raise KeyError(f"task not found: {task_id}")
        # Check column FIRST — a never-claimed task is "not Running" before
        # it's "not owned by you", which is the more natural error for the
        # caller. Worker-ownership check is the second gate.
        if existing.column_name != "Running":
            raise ValueError(
                f"task {task_id} is not Running (column: '{existing.column_name}')",
            )
        if existing.assigned_worker_id != worker_id_clean:
            raise ValueError(
                f"worker '{worker_id_clean}' does not own task {task_id} "
                f"(actual worker: '{existing.assigned_worker_id}')",
            )

        now_iso = datetime.now(UTC).isoformat()
        await self._db.execute(
            """UPDATE kanban_tasks
               SET column_name = 'Done',
                   completed_at = ?,
                   result = ?,
                   error = '',
                   blocked_reason = '',
                   assigned_worker_id = '',
                   lease_until = '',
                   updated_at = ?
               WHERE id = ?""",
            (now_iso, result, now_iso, int(task_id)),
        )
        await self._db.commit()

        self._log_activity(
            "kanban_task_completed",
            f"Worker {worker_id_clean} completed task '{existing.title}'",
            importance="medium",
            details={"task_id": task_id, "worker_id": worker_id_clean},
        )

        return KanbanTask(
            id=existing.id,
            board_id=existing.board_id,
            title=existing.title,
            description=existing.description,
            column_name="Done",
            position=existing.position,
            assigned_worker_id="",
            priority=existing.priority,
            max_retries=existing.max_retries,
            attempts=existing.attempts,
            last_heartbeat_at=existing.last_heartbeat_at,
            lease_until="",
            payload=existing.payload,
            result=result,
            error="",
            blocked_reason="",
            created_at=existing.created_at,
            updated_at=now_iso,
            started_at=existing.started_at,
            completed_at=now_iso,
            correlation_id=existing.correlation_id,
        )

    async def fail_task(
        self,
        task_id: int,
        worker_id: str,
        *,
        error: str,
        retry: bool = True,
    ) -> KanbanTask:
        """Mark a worker-claimed task failed.

        If ``retry=True`` AND ``attempts < max_retries`` → flip back to
        the claim column ("Ready") with the lease cleared. The next
        claim_next will pick it up. Error is recorded on the row.

        Otherwise → flip to the dead-letter column ("Blocked") with the
        error in ``blocked_reason``. User-initiated retry via
        ``retry_dead_letter_task`` is the only way out.

        Raises ``KeyError`` if the task doesn't exist; ``ValueError`` if
        the worker_id doesn't match.
        """
        worker_id_clean = (worker_id or "").strip()
        if not worker_id_clean:
            raise ValueError("worker_id is required")

        existing = await self.get_task(task_id)
        if existing is None:
            raise KeyError(f"task not found: {task_id}")
        # Check column FIRST (same rationale as complete_task — natural error
        # ordering: a never-claimed task is "not Running" before it's "not
        # owned by you").
        if existing.column_name != "Running":
            raise ValueError(
                f"task {task_id} is not Running (column: '{existing.column_name}')",
            )
        if existing.assigned_worker_id != worker_id_clean:
            raise ValueError(
                f"worker '{worker_id_clean}' does not own task {task_id}",
            )

        now_iso = datetime.now(UTC).isoformat()
        should_retry = retry and existing.attempts < existing.max_retries

        if should_retry:
            # Back to claim column, lease cleared, error recorded, attempts kept.
            await self._db.execute(
                """UPDATE kanban_tasks
                   SET column_name = ?,
                       assigned_worker_id = '',
                       lease_until = '',
                       last_heartbeat_at = '',
                       error = ?,
                       updated_at = ?
                   WHERE id = ?""",
                (_DEFAULT_CLAIM_COLUMN, error, now_iso, int(task_id)),
            )
            new_column = _DEFAULT_CLAIM_COLUMN
            new_blocked = existing.blocked_reason
            action = "kanban_task_retried"
            summary = (
                f"Task '{existing.title}' failed (attempt {existing.attempts}/"
                f"{existing.max_retries}) — retrying"
            )
            importance = "low"
        else:
            # Dead-letter to "Blocked" with the failure reason. Only user
            # action (retry_dead_letter_task) brings it back.
            await self._db.execute(
                """UPDATE kanban_tasks
                   SET column_name = ?,
                       assigned_worker_id = '',
                       lease_until = '',
                       last_heartbeat_at = '',
                       error = ?,
                       blocked_reason = ?,
                       updated_at = ?
                   WHERE id = ?""",
                (
                    _DEFAULT_DEAD_LETTER_COLUMN,
                    error,
                    f"Exhausted retries after {existing.attempts} attempt(s): {error}"[:500],
                    now_iso,
                    int(task_id),
                ),
            )
            new_column = _DEFAULT_DEAD_LETTER_COLUMN
            new_blocked = f"Exhausted retries after {existing.attempts} attempt(s): {error}"[:500]
            action = "kanban_task_dead_letter"
            summary = (
                f"Task '{existing.title}' dead-lettered after "
                f"{existing.attempts}/{existing.max_retries} attempts"
            )
            importance = "high"

        await self._db.commit()

        self._log_activity(
            action,
            summary,
            importance=importance,
            details={
                "task_id": task_id,
                "worker_id": worker_id_clean,
                "attempts": existing.attempts,
                "max_retries": existing.max_retries,
                "error_preview": error[:200],
            },
        )

        return KanbanTask(
            id=existing.id,
            board_id=existing.board_id,
            title=existing.title,
            description=existing.description,
            column_name=new_column,
            position=existing.position,
            assigned_worker_id="",
            priority=existing.priority,
            max_retries=existing.max_retries,
            attempts=existing.attempts,
            last_heartbeat_at="",
            lease_until="",
            payload=existing.payload,
            result=existing.result,
            error=error,
            blocked_reason=new_blocked,
            created_at=existing.created_at,
            updated_at=now_iso,
            started_at=existing.started_at,
            completed_at=existing.completed_at,
            correlation_id=existing.correlation_id,
        )

    async def retry_dead_letter_task(self, task_id: int) -> KanbanTask:
        """Move a dead-lettered task back to the claim column.

        User-initiated. Resets ``attempts`` to 0, clears ``error`` +
        ``blocked_reason``, moves back to "Ready". The next claim_next
        picks it up with a fresh attempt counter.

        Raises ``KeyError`` if the task doesn't exist; ``ValueError`` if
        the task isn't in the dead-letter column.
        """
        existing = await self.get_task(task_id)
        if existing is None:
            raise KeyError(f"task not found: {task_id}")
        if existing.column_name != _DEFAULT_DEAD_LETTER_COLUMN:
            raise ValueError(
                f"task {task_id} is not in dead-letter column "
                f"('{existing.column_name}', expected '{_DEFAULT_DEAD_LETTER_COLUMN}')",
            )

        now_iso = datetime.now(UTC).isoformat()
        await self._db.execute(
            """UPDATE kanban_tasks
               SET column_name = ?,
                   attempts = 0,
                   error = '',
                   blocked_reason = '',
                   assigned_worker_id = '',
                   lease_until = '',
                   last_heartbeat_at = '',
                   updated_at = ?
               WHERE id = ?""",
            (_DEFAULT_CLAIM_COLUMN, now_iso, int(task_id)),
        )
        await self._db.commit()

        self._log_activity(
            "kanban_task_retry_requested",
            f"User retried dead-lettered task '{existing.title}'",
            importance="medium",
            details={"task_id": task_id},
        )

        return KanbanTask(
            id=existing.id,
            board_id=existing.board_id,
            title=existing.title,
            description=existing.description,
            column_name=_DEFAULT_CLAIM_COLUMN,
            position=existing.position,
            assigned_worker_id="",
            priority=existing.priority,
            max_retries=existing.max_retries,
            attempts=0,
            last_heartbeat_at="",
            lease_until="",
            payload=existing.payload,
            result=existing.result,
            error="",
            blocked_reason="",
            created_at=existing.created_at,
            updated_at=now_iso,
            started_at=existing.started_at,
            completed_at=existing.completed_at,
            correlation_id=existing.correlation_id,
        )

    async def reclaim_zombies(self) -> dict[str, int]:
        """Sweep "Running" tasks whose lease has expired.

        For each zombie found:
          - If ``attempts < max_retries`` → flip back to "Ready", clear
            lease/heartbeat/worker_id, record the timeout error.
          - Else → flip to "Blocked" (dead-letter) with the error message.

        Idempotent. Returns ``{"scanned": N, "reclaimed": M, "dead_lettered": K}``.

        Lease is the primary signal: rows whose ``lease_until`` is empty
        OR in the future are skipped. The reclaim sweep never touches a
        row with a fresh lease — that protects against a worker that
        just heartbeated being yanked.

        Idempotent. Mirror of ``WorkQueue.reclaim_zombies()``.
        """
        now_iso = datetime.now(UTC).isoformat()

        # Find candidates: column='Running' AND lease_until is set and expired.
        async with self._db.execute(
            """SELECT id, title, attempts, max_retries, assigned_worker_id, lease_until
               FROM kanban_tasks
               WHERE column_name = 'Running'
                 AND lease_until != ''
                 AND lease_until < ?""",
            (now_iso,),
        ) as cursor:
            zombies = await cursor.fetchall()

        if not zombies:
            return {"scanned": 0, "reclaimed": 0, "dead_lettered": 0}

        reclaimed = 0
        dead_lettered = 0
        for row in zombies:
            task_id, title, attempts, max_retries, worker_id, _lease = row
            attempts_int = int(attempts or 0)
            max_retries_int = int(max_retries or 0)
            should_retry = attempts_int < max_retries_int
            error_msg = (
                f"Worker '{worker_id}' lease expired without completion "
                f"(attempt {attempts_int}/{max_retries_int})"
            )

            if should_retry:
                await self._db.execute(
                    """UPDATE kanban_tasks
                       SET column_name = ?,
                           assigned_worker_id = '',
                           lease_until = '',
                           last_heartbeat_at = '',
                           error = ?,
                           updated_at = ?
                       WHERE id = ?""",
                    (_DEFAULT_CLAIM_COLUMN, error_msg, now_iso, int(task_id)),
                )
                reclaimed += 1
                self._log_activity(
                    "kanban_zombie_reclaimed",
                    f"Reclaimed task '{title}' (worker {worker_id} silent)",
                    importance="medium",
                    details={
                        "task_id": int(task_id),
                        "worker_id": worker_id,
                        "attempts": attempts_int,
                    },
                )
            else:
                blocked_reason = (
                    f"Lease expired after {attempts_int} attempt(s): {error_msg}"
                )[:500]
                await self._db.execute(
                    """UPDATE kanban_tasks
                       SET column_name = ?,
                           assigned_worker_id = '',
                           lease_until = '',
                           last_heartbeat_at = '',
                           error = ?,
                           blocked_reason = ?,
                           updated_at = ?
                       WHERE id = ?""",
                    (_DEFAULT_DEAD_LETTER_COLUMN, error_msg, blocked_reason, now_iso, int(task_id)),
                )
                dead_lettered += 1
                self._log_activity(
                    "kanban_zombie_dead_lettered",
                    f"Task '{title}' dead-lettered (exhausted retries)",
                    importance="high",
                    details={
                        "task_id": int(task_id),
                        "worker_id": worker_id,
                        "attempts": attempts_int,
                    },
                )

        await self._db.commit()
        return {
            "scanned": len(zombies),
            "reclaimed": reclaimed,
            "dead_lettered": dead_lettered,
        }

    # ── Background reclaim loop ──

    async def _reclaim_loop(self) -> None:
        """Background sweep that calls ``reclaim_zombies`` periodically.

        Cancelled by ``stop_reclaim_loop``. Survives transient DB errors —
        a single failed sweep logs at debug and the next iteration retries.
        Worker process death naturally cancels the task via the asyncio
        event loop shutdown.
        """
        try:
            while True:
                await asyncio.sleep(self._reclaim_interval_seconds)
                try:
                    await self.reclaim_zombies()
                except Exception:
                    log.debug("Kanban: reclaim sweep failed", exc_info=True)
        except asyncio.CancelledError:
            return

    def start_reclaim_loop(self) -> None:
        """Start the background reclaim loop. Idempotent.

        Call from lifespan startup after ``init_schema()``. Safe to call
        repeatedly — additional calls are no-ops while a task is running.
        """
        if self._reclaim_task is not None and not self._reclaim_task.done():
            return
        self._reclaim_task = asyncio.create_task(self._reclaim_loop())

    async def stop_reclaim_loop(self) -> None:
        """Cancel the background reclaim loop. Safe to call when not running."""
        if self._reclaim_task is None:
            return
        self._reclaim_task.cancel()
        try:
            await self._reclaim_task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        finally:
            self._reclaim_task = None

    # ── Aggregate read for board view ──

    async def get_board_view(self, slug: str) -> dict[str, Any] | None:
        """Single round-trip: board + all its tasks grouped by column.

        Returns ``None`` when the board is unknown so the route can 404.
        Tasks within each column are position-ordered. Empty columns
        appear in the result as empty lists so the UI doesn't have to
        reconcile against ``board.columns`` separately.
        """
        board = await self.get_board_by_slug(slug)
        if board is None:
            return None
        tasks = await self.list_tasks(slug)
        by_column: dict[str, list[dict[str, Any]]] = {col: [] for col in board.columns}
        for task in tasks:
            # If a task's column drifted off the board's declared list
            # (legacy data, manual SQL edit), surface it under a sentinel
            # so it's still visible. Don't drop silently.
            if task.column_name in by_column:
                by_column[task.column_name].append(task.to_public_dict())
            else:
                by_column.setdefault("(unknown)", []).append(task.to_public_dict())
        return {
            "board": board.to_public_dict(),
            "tasks_by_column": by_column,
            "task_count": len(tasks),
        }
