"""Multi-agent durable Kanban subsystem.

Shipped 2026-05-08 as P0 from the performance + smart-capability roadmap
([tasks/plan-performance-roadmap.md](../../../../tasks/plan-performance-roadmap.md)).
Borrowed from Hermes Agent v0.13.0's headline feature: a SQLite-backed
work board where multiple workers pick up tasks, hand off, close. v1 is
backend foundation only (schema + service + REST API + tests). v2 adds
the worker claim/handoff/zombie loop. v3 adds the chat slash command +
React board UI.

Tables live on ``automation.db`` (independent writer lock per the
DB-split architectural rule). Worker identity is composed from
``ProcessRegistry`` ``process_id`` rather than maintained in a separate
``kanban_workers`` table — single source of truth for what's alive.
"""

from agntspace.kanban.service import KanbanService

__all__ = ["KanbanService"]
