"""24h same-topic research cache — P1.2 from plan-performance-roadmap.md.

Shipped 2026-05-08 evening. Closes the S5 leftover from
plan-research-perplexity.md: re-running ``research_topic`` on the same
topic burned Perplexity credits every time. SQLite cache keyed
``(topic_slug, model, kind)`` with a configurable TTL (default 24h)
and ``force_fresh`` bypass.

Architecture:

* **One file per store** — ``research_cache.db`` at
  ``<vault>/agntspace/research/`` next to ``plans.db`` + ``proposals.db``.
  Independent writer lock per file (DB-isolation rule). Mirrors the
  PRAGMA discipline of ``research_persistence.py`` exactly.

* **Synchronous ``sqlite3``** like the other research stores. Keeps
  the ``ToolExecutor._exec_research_*`` paths sync-only — the cache
  is consulted INSIDE the existing sync method body. No async
  conversion needed.

* **Cache stores the Perplexity response, NOT the tool's full return
  shape.** On cache hit we re-emit a return dict with the cached
  ``result_path`` (the file ALREADY on disk from the original call) —
  so triple extraction + corroboration + mention indexing don't
  re-fire on a hit. This is the load-bearing UX promise of
  "I already researched this": the user gets the existing file
  instantly, the graph isn't double-bumped, no extra cost.

* **Self-heals when result_path goes missing** — if the cached file
  has been deleted out-of-band (vault reset, manual delete), the
  cache lookup treats it as a miss + fires the live Perplexity call.
  Without this guard, the user would get a "result_path: ..." that
  404s in the UI.

* **TTL is per-row** — each cache entry has its own ``expires_at``
  timestamp so the TTL is enforced even if the YAML default changes
  between cache write and cache read. ``purge_expired()`` runs at
  store construction (one-shot prune) AND can be called periodically
  by the heartbeat for ongoing hygiene.

* **Failure-tolerant** — every store method is wrapped in try/except;
  a corrupt cache row, a permission error, or a SQLite hiccup
  degrades to "cache miss" cleanly. The user gets a fresh Perplexity
  call instead of a hard error. Same fail-open pattern as
  ``research_persistence.init_db``.

Locked by 18 unit tests + 2 e2e workflow tests; arch-test registers
``research_cache.db`` under the per-store split.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from agntspace.agent.research_persistence import init_db

log = logging.getLogger(__name__)


# arch:deterministic — schema versioning. Bump only when a column
# rename / type change forces a non-additive migration. Additive
# columns go through ALTER TABLE in init_cache_db.
_SCHEMA_VERSION: int = 1


_CACHE_SCHEMA = """
CREATE TABLE IF NOT EXISTS research_cache (
    cache_key TEXT PRIMARY KEY,
    topic_slug TEXT NOT NULL,
    model TEXT NOT NULL,
    kind TEXT NOT NULL,
    target_kb TEXT NOT NULL DEFAULT '',
    response_text TEXT NOT NULL,
    citations_json TEXT NOT NULL DEFAULT '[]',
    result_path TEXT NOT NULL DEFAULT '',
    cost_usd REAL NOT NULL DEFAULT 0.0,
    extra_json TEXT NOT NULL DEFAULT '{}',
    created_at REAL NOT NULL,
    expires_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cache_expires ON research_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_cache_kind ON research_cache(kind);
CREATE INDEX IF NOT EXISTS idx_cache_topic ON research_cache(topic_slug);
"""


# arch:deterministic — closed enum of legal `kind` values. New
# research entry points add to this set + the YAML config.
VALID_KINDS: frozenset[str] = frozenset({"topic", "topic_deep", "paper"})


# arch:deterministic — engine substrate defaults. Tuned via
# `_meta/research-perplexity/config/cache.yaml` per Rule 12.
_DEFAULT_TTL_SECONDS: int = 86400  # 24h
_DEFAULT_ENABLED: bool = True


def init_cache_db(db_path: Path | str) -> sqlite3.Connection | None:
    """Open the research_cache.db connection. Returns None on any failure.

    Mirrors ``research_persistence.init_db`` — same PRAGMA discipline
    (WAL, busy_timeout=30s, autocheckpoint, one-time TRUNCATE), same
    fail-open semantics. The cache subsystem must NEVER raise during
    construction; a missing/corrupt cache file degrades to
    cache-disabled mode (every research call hits Perplexity live).
    """
    return init_db(db_path, _CACHE_SCHEMA)


def _cache_key(topic_slug: str, model: str, kind: str) -> str:
    """Compose the canonical primary key. Pure function, no I/O."""
    return f"{topic_slug}::{model}::{kind}"


@dataclass
class CacheEntry:
    """Snapshot of a cached research response. Pure data."""

    cache_key: str
    topic_slug: str
    model: str
    kind: str
    target_kb: str
    response_text: str
    citations: list[dict[str, Any]]
    result_path: str
    cost_usd: float
    extra: dict[str, Any] = field(default_factory=dict)
    created_at: float = 0.0
    expires_at: float = 0.0

    def to_public_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def age_seconds(self) -> float:
        return max(0.0, time.time() - self.created_at)

    @property
    def remaining_ttl_seconds(self) -> float:
        return max(0.0, self.expires_at - time.time())


class ResearchCache:
    """SQLite-backed 24h research cache.

    Constructor accepts ``conn`` (an already-opened sqlite3 connection)
    so tests can inject ``:memory:``. Production code passes a real
    file-backed connection from ``init_cache_db`` via main.py lifespan.

    All methods are total — they never raise on a corrupt row /
    permission error / sqlite hiccup. Every error path returns the
    sentinel "cache miss" or "no-op" so the live Perplexity call
    continues unaffected.

    Activity logger optional — every miss/hit/put emits an event
    when wired, silent when missing.
    """

    def __init__(
        self,
        *,
        conn: sqlite3.Connection | None,
        ttl_seconds: int = _DEFAULT_TTL_SECONDS,
        activity_logger: Any = None,
    ) -> None:
        self._conn = conn
        self._ttl_seconds = max(1, int(ttl_seconds))
        self._activity = activity_logger
        # One-shot prune at construction so stale rows from an earlier
        # boot don't accumulate unboundedly.
        self.purge_expired()

    # ── Activity helper (graceful degrade) ──

    def _log_activity(
        self,
        action: str,
        summary: str,
        *,
        importance: str = "low",
        details: dict[str, Any] | None = None,
    ) -> None:
        """Emit an activity event when logger is wired. Never raises."""
        if not self._activity:
            return
        try:
            self._activity.log(
                category="user",
                action=action,
                summary=summary,
                importance=importance,
                details=details or {},
            )
        except Exception:
            log.debug("research_cache: activity logger emit failed", exc_info=True)

    # ── Read path ──

    def get(
        self,
        *,
        topic_slug: str,
        model: str,
        kind: str,
        result_path_must_exist: bool = True,
        vault_root: Path | None = None,
    ) -> CacheEntry | None:
        """Look up a cached research response. Returns None on miss.

        Miss conditions (all degrade to None, no error raised):
        - Empty topic_slug or model.
        - Cache disabled (``self._conn is None``).
        - No row matches the key.
        - Row is past ``expires_at``.
        - ``result_path_must_exist`` is True AND the cached file is
          missing on disk (the user deleted it out-of-band).
        - Any sqlite exception during read.

        On hit, emits a ``research_cache_hit`` activity event with
        ``cost_saved_usd`` so the user can see savings accumulate.
        """
        if self._conn is None or not topic_slug or not model:
            return None
        if kind not in VALID_KINDS:
            return None

        key = _cache_key(topic_slug, model, kind)
        try:
            cursor = self._conn.execute(
                "SELECT * FROM research_cache WHERE cache_key = ?",
                (key,),
            )
            row = cursor.fetchone()
        except Exception:
            log.debug("research_cache.get: query failed for %s", key, exc_info=True)
            return None
        if row is None:
            return None

        entry = self._row_to_entry(row)
        if entry is None:
            # Corrupt row — best-effort delete + miss.
            self._delete_key(key)
            return None

        # TTL gate.
        now = time.time()
        if entry.expires_at <= now:
            self._delete_key(key)
            return None

        # Stale-file gate. The original file may have been wiped via
        # vault reset / manual delete. If the cache promises a path
        # that doesn't exist, treat as miss + clean up.
        if result_path_must_exist and entry.result_path and vault_root is not None:
            try:
                full_path = (vault_root / entry.result_path).resolve()
                if not full_path.exists():
                    log.info(
                        "research_cache: cached result_path missing on disk — treating as miss: %s",
                        entry.result_path,
                    )
                    self._delete_key(key)
                    return None
            except Exception:
                log.debug(
                    "research_cache: stale-file check failed for %s",
                    entry.result_path,
                    exc_info=True,
                )

        self._log_activity(
            "research_cache_hit",
            f"Returned cached research for '{entry.topic_slug}' (kind={kind})",
            importance="low",
            details={
                "topic_slug": entry.topic_slug,
                "model": entry.model,
                "kind": kind,
                "age_seconds": int(entry.age_seconds),
                "cost_saved_usd": round(entry.cost_usd, 6),
                "result_path": entry.result_path,
            },
        )
        return entry

    # ── Write path ──

    def put(
        self,
        *,
        topic_slug: str,
        model: str,
        kind: str,
        target_kb: str,
        response_text: str,
        citations: list[dict[str, Any]] | None = None,
        result_path: str = "",
        cost_usd: float = 0.0,
        extra: dict[str, Any] | None = None,
    ) -> bool:
        """Insert or replace a cache entry. Returns True on success.

        Validates: topic_slug + model non-empty, kind in VALID_KINDS,
        response_text non-empty. No-op + log on validation failure.
        Total — never raises.
        """
        if self._conn is None:
            return False
        if not topic_slug or not model or not response_text:
            return False
        if kind not in VALID_KINDS:
            log.debug("research_cache.put: invalid kind=%r", kind)
            return False

        key = _cache_key(topic_slug, model, kind)
        now = time.time()
        expires = now + self._ttl_seconds
        try:
            citations_json = json.dumps(citations or [], sort_keys=True)
        except Exception:
            citations_json = "[]"
        try:
            extra_json = json.dumps(extra or {}, sort_keys=True)
        except Exception:
            extra_json = "{}"

        try:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO research_cache (
                    cache_key, topic_slug, model, kind, target_kb,
                    response_text, citations_json, result_path, cost_usd,
                    extra_json, created_at, expires_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    key, topic_slug, model, kind, (target_kb or ""),
                    response_text, citations_json, (result_path or ""),
                    float(cost_usd or 0.0), extra_json, now, expires,
                ),
            )
        except Exception:
            log.debug("research_cache.put: write failed for %s", key, exc_info=True)
            return False

        self._log_activity(
            "research_cache_write",
            f"Cached research response for '{topic_slug}' (kind={kind}, ttl={self._ttl_seconds}s)",
            importance="low",
            details={
                "topic_slug": topic_slug,
                "model": model,
                "kind": kind,
                "cost_usd": round(float(cost_usd or 0.0), 6),
                "ttl_seconds": self._ttl_seconds,
            },
        )
        return True

    # ── Maintenance ──

    def purge_expired(self) -> int:
        """Delete all expired rows. Returns count purged."""
        if self._conn is None:
            return 0
        now = time.time()
        try:
            cursor = self._conn.execute(
                "DELETE FROM research_cache WHERE expires_at < ?",
                (now,),
            )
            return cursor.rowcount or 0
        except Exception:
            log.debug("research_cache.purge_expired: failed", exc_info=True)
            return 0

    def stats(self) -> dict[str, Any]:
        """Aggregate counters for the /admin perf panel.

        Returns ``{total, expired, by_kind, total_cost_saved_usd}``.
        Total — degrades to zeros on any error so the dashboard never
        breaks.
        """
        if self._conn is None:
            return {
                "total": 0,
                "expired": 0,
                "by_kind": {},
                "total_cost_saved_usd": 0.0,
                "available": False,
            }
        now = time.time()
        try:
            row = self._conn.execute(
                "SELECT COUNT(*) FROM research_cache",
            ).fetchone()
            total = int(row[0]) if row else 0
        except Exception:
            total = 0
        try:
            row = self._conn.execute(
                "SELECT COUNT(*) FROM research_cache WHERE expires_at < ?",
                (now,),
            ).fetchone()
            expired = int(row[0]) if row else 0
        except Exception:
            expired = 0
        by_kind: dict[str, int] = {}
        try:
            for kind, count in self._conn.execute(
                "SELECT kind, COUNT(*) FROM research_cache GROUP BY kind",
            ):
                by_kind[str(kind)] = int(count)
        except Exception:
            pass
        try:
            row = self._conn.execute(
                "SELECT COALESCE(SUM(cost_usd), 0.0) FROM research_cache "
                "WHERE expires_at >= ?",
                (now,),
            ).fetchone()
            total_cost_saved = float(row[0]) if row else 0.0
        except Exception:
            total_cost_saved = 0.0
        return {
            "total": total,
            "expired": expired,
            "by_kind": by_kind,
            "total_cost_saved_usd": round(total_cost_saved, 6),
            "available": True,
        }

    def clear(self) -> int:
        """Delete every row. Returns count cleared. Used by tests + admin."""
        if self._conn is None:
            return 0
        try:
            cursor = self._conn.execute("DELETE FROM research_cache")
            return cursor.rowcount or 0
        except Exception:
            log.debug("research_cache.clear: failed", exc_info=True)
            return 0

    # ── Internal helpers ──

    def _delete_key(self, key: str) -> None:
        """Best-effort row delete. Total — never raises."""
        if self._conn is None:
            return
        try:
            self._conn.execute(
                "DELETE FROM research_cache WHERE cache_key = ?", (key,),
            )
        except Exception:
            log.debug("research_cache._delete_key: delete failed for %s", key, exc_info=True)

    @staticmethod
    def _row_to_entry(row: Any) -> CacheEntry | None:
        """sqlite3.Row → CacheEntry. Returns None on parse failure."""
        try:
            citations_raw = row[6] if len(row) > 6 else "[]"
            try:
                citations = json.loads(citations_raw or "[]")
                if not isinstance(citations, list):
                    citations = []
            except Exception:
                citations = []
            extra_raw = row[9] if len(row) > 9 else "{}"
            try:
                extra = json.loads(extra_raw or "{}")
                if not isinstance(extra, dict):
                    extra = {}
            except Exception:
                extra = {}
            return CacheEntry(
                cache_key=str(row[0]),
                topic_slug=str(row[1]),
                model=str(row[2]),
                kind=str(row[3]),
                target_kb=str(row[4] or ""),
                response_text=str(row[5] or ""),
                citations=citations,
                result_path=str(row[7] or ""),
                cost_usd=float(row[8] or 0.0),
                extra=extra,
                created_at=float(row[10] or 0.0),
                expires_at=float(row[11] or 0.0),
            )
        except Exception:
            log.debug("research_cache: row → entry parse failed", exc_info=True)
            return None
