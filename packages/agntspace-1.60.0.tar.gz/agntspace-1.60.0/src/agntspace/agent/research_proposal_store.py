"""``research_update`` proposal registry (S3.B + persistence pass).

Plan: tasks/plan-research-perplexity.md S3.B.

When ``research_topic_deep`` finishes its synthesis, the
``## Recommended Vault Updates`` section is parsed bullet-by-bullet and
each item becomes a Rule 21 proposal in this store. The unified
``/proposals`` inbox surfaces them alongside taxonomy / capability /
dream-review proposals.

Architectural choices:

1. **In-memory dict + optional SQLite write-through.** Pass
   ``db_path=`` to the constructor and proposals survive restarts —
   approved-but-not-applied recommendations no longer vanish on
   server bounce. Without ``db_path`` the store is pure-in-memory
   (existing tests + minimal installs use this path). Same shape as
   the dispatch_state pattern: in-memory mirror is the read path,
   SQLite is the durability path.

2. **Status state machine**: pending → approved | rejected | dismissed
   ; approved → applying → applied | apply_failed; apply_failed →
   approved (via retry_apply); approved → applied(skipped) (via
   skip_apply). Approved means "user agreed with the recommendation";
   rejected means "the recommendation is wrong"; dismissed is a soft
   "I've seen it, no action needed." Each transition is recorded with
   a timestamp + optional rationale.

3. **Trust feedback channel** (S4): on approve / reject, the
   ``ResearchProposalStore`` doesn't touch the trust posterior
   directly — the API route does. This module just stores state +
   exposes it for downstream consumers.
"""

from __future__ import annotations

import secrets
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agntspace.agent.research_persistence import (
    delete_proposal as _persist_delete,
)
from agntspace.agent.research_persistence import (
    init_proposal_db,
    load_all_proposals,
    prune_proposals_older_than,
)
from agntspace.agent.research_persistence import (
    upsert_proposal as _persist_upsert,
)

# arch:deterministic — research_update proposal lifetime; 24 hours is
# the practical "I came back the next day to triage" window. Tuning
# beyond this should land in YAML (S3.B follow-up).
_DEFAULT_TTL_SECONDS: float = 24 * 3600.0


@dataclass
class ResearchProposal:
    """A research_update proposal awaiting user triage."""

    proposal_id: str
    topic: str
    target_kb: str
    recommendation: str  # the bullet text from ## Recommended Vault Updates
    severity: str  # high | medium | low
    source_synthesis_path: str  # the synthesis page that generated this
    correlation_id: str
    created_at: float
    # Status state machine:
    #   pending → approved | rejected | dismissed
    #   approved → applying → applied | apply_failed (Pass-3 apply path)
    # Approved and apply states can co-exist with the trust posterior
    # bump that fires on the approve transition (S4).
    status: str = "pending"
    decided_at: float | None = None
    rationale: str = ""
    # Pass-3 apply tracking. ``apply_outcome`` carries the parsed
    # ``APPLY OUTCOME: <status>`` line from the editor agent's narrative.
    # ``apply_started_at`` / ``apply_finished_at`` are wall-clock timestamps.
    apply_outcome: str = ""
    apply_summary: str = ""
    apply_started_at: float | None = None
    apply_finished_at: float | None = None
    apply_error: str = ""
    # Cite-back gap (#4): the article slug the editor reports having
    # updated/created, parsed from ``APPLIED ARTICLE: <slug>``. Empty
    # for non-applied outcomes (failures don't claim a target) and for
    # legacy rows + the `skipped` outcome (where no edit was made).
    # The UI uses this to render a click-through to /wiki/<slug>.
    applied_article_slug: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "topic": self.topic,
            "target_kb": self.target_kb,
            "recommendation": self.recommendation,
            "severity": self.severity,
            "source_synthesis_path": self.source_synthesis_path,
            "correlation_id": self.correlation_id,
            "created_at": self.created_at,
            "status": self.status,
            "decided_at": self.decided_at,
            "rationale": self.rationale,
            "apply_outcome": self.apply_outcome,
            "apply_summary": self.apply_summary,
            "apply_started_at": self.apply_started_at,
            "apply_finished_at": self.apply_finished_at,
            "apply_error": self.apply_error,
            "applied_article_slug": self.applied_article_slug,
        }


class ResearchProposalStore:
    """Process-wide research_update proposal registry.

    Pass ``db_path=`` to enable SQLite write-through persistence
    (proposals survive restarts). Without it the store is pure
    in-memory (existing tests + minimal installs).
    """

    def __init__(
        self,
        ttl_seconds: float = _DEFAULT_TTL_SECONDS,
        *,
        db_path: Path | str | None = None,
    ) -> None:
        self._ttl = float(ttl_seconds)
        self._proposals: dict[str, ResearchProposal] = {}
        self._lock = threading.Lock()
        self._db: sqlite3.Connection | None = None
        if db_path is not None:
            self._db = init_proposal_db(db_path)
            self._rehydrate_from_db()

    def _rehydrate_from_db(self) -> None:
        """Read every persisted proposal back into the in-memory dict.

        Runs once at construction time. Stale rows (older than TTL)
        are pruned on disk first, so no zombie rows leak in.
        Defensive — failures are logged at debug and the store
        continues empty (better than crashing on a malformed row).
        """
        if self._db is None:
            return
        cutoff = time.time() - self._ttl
        prune_proposals_older_than(self._db, cutoff)
        rows = load_all_proposals(self._db)
        for kwargs in rows:
            try:
                p = ResearchProposal(**kwargs)
                self._proposals[p.proposal_id] = p
            except Exception:
                # Single bad row should not block the rest.
                continue

    def _persist_locked(self, proposal: ResearchProposal) -> None:
        """Write-through under self._lock. Caller MUST hold the lock."""
        _persist_upsert(self._db, proposal)

    def _persist_delete_locked(self, proposal_id: str) -> None:
        _persist_delete(self._db, proposal_id)

    @staticmethod
    def _new_id() -> str:
        return "rprop_" + secrets.token_hex(8)

    @staticmethod
    def _heuristic_severity(recommendation: str) -> str:
        """Severity from the recommendation text shape.

        - Contains a [[wikilink]] → medium (specific target identified)
        - Starts with "Add new article" → low (suggestion, not a fix)
        - Contains "contradicts" / "outdated" / "stale" → high
        - Otherwise medium
        """
        rec = (recommendation or "").lower()
        if any(kw in rec for kw in ("contradict", "outdated", "stale", "wrong", "incorrect")):
            return "high"
        if rec.startswith("add new article") or rec.startswith("add article"):
            return "low"
        if "[[" in recommendation:
            return "medium"
        return "medium"

    def create(
        self,
        *,
        topic: str,
        target_kb: str,
        recommendation: str,
        source_synthesis_path: str,
        correlation_id: str = "",
        severity: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> ResearchProposal:
        """Create a pending research_update proposal."""
        sev = severity or self._heuristic_severity(recommendation)
        with self._lock:
            self._prune_locked()
            proposal = ResearchProposal(
                proposal_id=self._new_id(),
                topic=topic,
                target_kb=target_kb,
                recommendation=recommendation,
                severity=sev,
                source_synthesis_path=source_synthesis_path,
                correlation_id=correlation_id,
                created_at=time.time(),
                extra=dict(extra or {}),
            )
            self._proposals[proposal.proposal_id] = proposal
            self._persist_locked(proposal)
            return proposal

    def get(self, proposal_id: str) -> ResearchProposal | None:
        with self._lock:
            self._prune_locked()
            return self._proposals.get(proposal_id)

    def list_pending(self) -> list[ResearchProposal]:
        """Return every pending proposal, severity desc + newest first."""
        with self._lock:
            self._prune_locked()
            pending = [p for p in self._proposals.values() if p.status == "pending"]
            severity_rank = {"high": 0, "medium": 1, "low": 2}
            pending.sort(key=lambda p: (severity_rank.get(p.severity, 3), -p.created_at))
            return pending

    def list_all(self) -> list[ResearchProposal]:
        """Return every proposal regardless of status, newest first."""
        with self._lock:
            self._prune_locked()
            entries = list(self._proposals.values())
            entries.sort(key=lambda p: -p.created_at)
            return entries

    def approve(self, proposal_id: str, *, rationale: str = "") -> ResearchProposal | None:
        with self._lock:
            self._prune_locked()
            p = self._proposals.get(proposal_id)
            if p is None or p.status != "pending":
                return None
            p.status = "approved"
            p.decided_at = time.time()
            p.rationale = rationale or ""
            self._persist_locked(p)
            return p

    def reject(self, proposal_id: str, *, rationale: str = "") -> ResearchProposal | None:
        with self._lock:
            self._prune_locked()
            p = self._proposals.get(proposal_id)
            if p is None or p.status != "pending":
                return None
            p.status = "rejected"
            p.decided_at = time.time()
            p.rationale = rationale or ""
            self._persist_locked(p)
            return p

    def dismiss(self, proposal_id: str) -> ResearchProposal | None:
        with self._lock:
            self._prune_locked()
            p = self._proposals.get(proposal_id)
            if p is None or p.status != "pending":
                return None
            p.status = "dismissed"
            p.decided_at = time.time()
            self._persist_locked(p)
            return p

    def mark_applying(self, proposal_id: str) -> ResearchProposal | None:
        """Transition an approved proposal into the ``applying`` state.

        The route handler calls this BEFORE spawning the background
        invoke_skill task so the UI's next poll sees the in-flight
        state, not the stale ``approved``. Returns ``None`` when the
        proposal isn't in ``approved`` (already applying / applied /
        rejected / dismissed / pending) — the route maps that to a
        409 so the UI doesn't double-fire.
        """
        with self._lock:
            self._prune_locked()
            p = self._proposals.get(proposal_id)
            if p is None or p.status != "approved":
                return None
            p.status = "applying"
            p.apply_started_at = time.time()
            p.apply_outcome = ""
            p.apply_summary = ""
            p.apply_error = ""
            self._persist_locked(p)
            return p

    def mark_applied(
        self,
        proposal_id: str,
        *,
        outcome: str,
        summary: str = "",
        error: str = "",
        applied_article_slug: str = "",
    ) -> ResearchProposal | None:
        """Mark an in-flight apply task as finished.

        The background invoke_skill task calls this with the parsed
        ``APPLY OUTCOME: <status>`` line. Successful outcomes
        (``applied``) flip the status to ``applied``; everything else
        flips to ``apply_failed`` so the user can re-trigger or
        triage. ``applied_article_slug`` is the optional cite-back
        slug parsed from the editor's ``APPLIED ARTICLE: <slug>``
        line — only stamped on successful ``applied`` outcomes.
        Calling this when the proposal isn't in ``applying`` is a
        no-op + returns None (defensive against stale tasks).
        """
        with self._lock:
            self._prune_locked()
            p = self._proposals.get(proposal_id)
            if p is None or p.status != "applying":
                return None
            normalized = (outcome or "").strip().lower()
            terminal_status = "applied" if normalized == "applied" else "apply_failed"
            p.status = terminal_status
            p.apply_outcome = normalized or "crash"
            p.apply_summary = (summary or "").strip()
            p.apply_finished_at = time.time()
            p.apply_error = (error or "").strip()
            # Only record the article slug for genuine successful applies.
            # apply_failed outcomes don't have a target to point at; if
            # the editor reported one anyway it's almost certainly noise.
            if terminal_status == "applied":
                p.applied_article_slug = (applied_article_slug or "").strip()
            else:
                p.applied_article_slug = ""
            self._persist_locked(p)
            return p

    def retry_apply(self, proposal_id: str) -> ResearchProposal | None:
        """Reset an apply_failed proposal back to ``approved``.

        Lets the user re-trigger the editor agent after a transient
        failure (LLM timeout, target_unclear ambiguity that's since
        been resolved manually, etc.). State machine:
            apply_failed → approved → applying → applied | apply_failed

        Clears the apply_started_at / apply_finished_at / apply_outcome
        / apply_summary / apply_error so the next apply pass starts
        from a clean slate.

        Returns ``None`` when the proposal isn't in apply_failed
        (so calling on a fresh / approved / applying / applied
        proposal is a no-op the route maps to 409).
        """
        with self._lock:
            self._prune_locked()
            p = self._proposals.get(proposal_id)
            if p is None or p.status != "apply_failed":
                return None
            p.status = "approved"
            # Preserve decided_at + rationale (the original approve-time
            # values stay accurate). Clear only the apply-attempt state.
            p.apply_started_at = None
            p.apply_finished_at = None
            p.apply_outcome = ""
            p.apply_summary = ""
            p.apply_error = ""
            p.applied_article_slug = ""
            self._persist_locked(p)
            return p

    def skip_apply(self, proposal_id: str, *, rationale: str = "") -> ResearchProposal | None:
        """Mark an approved proposal as 'skipped' — done without applying.

        Used when the user wants to keep the Bayesian approve-signal
        ("yes, this recommendation was useful") but doesn't want the
        editor to actually mutate the vault — e.g. they'll handle it
        manually, or the vault is already up to date.

        Status transitions: approved → applied (with apply_outcome=
        "skipped"). The terminal state is the same as a real apply
        so the proposal moves out of the Ready-to-apply queue;
        apply_outcome=="skipped" lets the UI render it distinctly
        from a real applied edit.

        Returns ``None`` when the proposal isn't in ``approved``.
        """
        with self._lock:
            self._prune_locked()
            p = self._proposals.get(proposal_id)
            if p is None or p.status != "approved":
                return None
            now = time.time()
            p.status = "applied"
            p.apply_started_at = now
            p.apply_finished_at = now
            p.apply_outcome = "skipped"
            p.apply_summary = (rationale or "Marked complete without dispatching the editor.").strip()
            p.apply_error = ""
            self._persist_locked(p)
            return p

    def stats(self) -> dict[str, int]:
        with self._lock:
            self._prune_locked()
            counts = {
                "pending": 0,
                "approved": 0,
                "rejected": 0,
                "dismissed": 0,
                "applying": 0,
                "applied": 0,
                "apply_failed": 0,
            }
            for p in self._proposals.values():
                counts[p.status] = counts.get(p.status, 0) + 1
            counts["total"] = len(self._proposals)
            return counts

    def _prune_locked(self) -> None:
        """Remove proposals older than TTL. Caller must hold the lock."""
        cutoff = time.time() - self._ttl
        stale = [pid for pid, p in self._proposals.items() if p.created_at < cutoff]
        for pid in stale:
            del self._proposals[pid]
            self._persist_delete_locked(pid)
