"""Pending-plan registry for the research-deep budget gate.

S3.A of plan-research-perplexity.md.

When ``research_topic_deep`` is invoked from a chat scope (not
programmatically), the gap-analysis output is wrapped into a "plan" —
a list of queries with an estimated cost — and persisted here. The
user approves via ``POST /api/research/plan/{plan_id}/approve`` or
rejects via ``POST .../reject``.

Architectural choices:

1. **In-memory dict + optional SQLite write-through.** Pass
   ``db_path=`` to enable persistence (plans survive restarts).
   Without it the store is pure in-memory (existing tests +
   minimal installs use this path). Same shape as
   ResearchProposalStore.

2. **TTL pruning.** ``approve`` / ``reject`` / ``get_plan`` all run
   the cleanup before answering. Stale plans never accumulate.

3. **Single-flight.** Each plan has a unique 12-char ID. The approve
   route flips status to ``approved``; the executor consumes the plan
   exactly once via ``consume_plan``.

4. **No persistence boundary at the bridge.** The researcher tool is
   responsible for re-invoking ``_exec_research_topic_deep`` with
   ``force_no_plan_gate=True`` after approval. This module just stores
   the parameters needed to re-invoke.

5. **Thread-safe.** A ``threading.Lock`` guards mutations because the
   approve route may run on a different worker thread than the chat
   tool dispatch.

Failure model:
- ``get_plan`` returns None on unknown / expired plan IDs.
- ``approve_plan`` / ``reject_plan`` return False on unknown / expired
  / already-decided plans (caller maps to HTTP 404 / 409).
- ``consume_plan`` returns None on unknown / not-yet-approved plans.
"""

from __future__ import annotations

import secrets
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agntspace.agent.research_persistence import (
    delete_plan as _persist_delete,
)
from agntspace.agent.research_persistence import (
    init_plan_db,
    load_all_plans,
    prune_plans_older_than,
)
from agntspace.agent.research_persistence import (
    upsert_plan as _persist_upsert,
)

# arch:deterministic — TTL boundary. Plan storage is in-memory and
# bounded by user-perception lifetime ("I queued research, came back
# in an hour"). Tuning lives in the skill YAML for the guard logic;
# this constant pins the storage-layer floor.
_DEFAULT_TTL_SECONDS: float = 3600.0


@dataclass
class ResearchPlan:
    """A plan awaiting user approval.

    ``params`` carries everything the tool needs to re-invoke after
    approval. It deliberately mirrors the original ``research_topic_deep``
    args + the gap-analysis queries; the tool re-runs the gate-gated
    portion of the pipeline on approval.
    """

    plan_id: str
    topic: str
    target_kb: str
    queries: list[dict]
    estimated_cost_usd: float
    baseline_entities_used: int
    created_at: float
    status: str = "pending"  # pending | approved | rejected | consumed
    decided_at: float | None = None
    consumed_at: float | None = None
    correlation_id: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "plan_id": self.plan_id,
            "topic": self.topic,
            "target_kb": self.target_kb,
            "queries": list(self.queries),
            "estimated_cost_usd": self.estimated_cost_usd,
            "baseline_entities_used": self.baseline_entities_used,
            "created_at": self.created_at,
            "status": self.status,
            "decided_at": self.decided_at,
            "consumed_at": self.consumed_at,
            "correlation_id": self.correlation_id,
        }


class ResearchPlanStore:
    """Process-wide pending-plan registry.

    Pass ``db_path=`` to enable SQLite write-through persistence
    (plans survive restarts). Without it the store is pure
    in-memory (existing tests + minimal installs).
    """

    def __init__(
        self,
        ttl_seconds: float = _DEFAULT_TTL_SECONDS,
        *,
        db_path: Path | str | None = None,
    ) -> None:
        self._ttl = float(ttl_seconds)
        self._plans: dict[str, ResearchPlan] = {}
        self._lock = threading.Lock()
        self._db: sqlite3.Connection | None = None
        if db_path is not None:
            self._db = init_plan_db(db_path)
            self._rehydrate_from_db()

    def _rehydrate_from_db(self) -> None:
        """Read every persisted plan back into the in-memory dict."""
        if self._db is None:
            return
        cutoff = time.time() - self._ttl
        prune_plans_older_than(self._db, cutoff)
        rows = load_all_plans(self._db)
        for kwargs in rows:
            try:
                p = ResearchPlan(**kwargs)
                self._plans[p.plan_id] = p
            except Exception:
                continue

    def _persist_locked(self, plan: ResearchPlan) -> None:
        """Write-through under self._lock. Caller MUST hold the lock."""
        _persist_upsert(self._db, plan)

    def _persist_delete_locked(self, plan_id: str) -> None:
        _persist_delete(self._db, plan_id)

    @staticmethod
    def _new_plan_id() -> str:
        # 8 bytes → 16 hex chars; prefix with "plan_" for readability in
        # logs/UI. Uniqueness probability collision over a server's
        # lifetime is effectively zero.
        return "plan_" + secrets.token_hex(8)

    def create(
        self,
        *,
        topic: str,
        target_kb: str,
        queries: list[dict],
        estimated_cost_usd: float,
        baseline_entities_used: int,
        correlation_id: str = "",
        extra: dict[str, Any] | None = None,
    ) -> ResearchPlan:
        """Create a pending plan and return the full record."""
        with self._lock:
            self._prune_locked()
            plan = ResearchPlan(
                plan_id=self._new_plan_id(),
                topic=topic,
                target_kb=target_kb,
                queries=list(queries),
                estimated_cost_usd=float(estimated_cost_usd),
                baseline_entities_used=int(baseline_entities_used),
                created_at=time.time(),
                correlation_id=correlation_id,
                extra=dict(extra or {}),
            )
            self._plans[plan.plan_id] = plan
            self._persist_locked(plan)
            return plan

    def get(self, plan_id: str) -> ResearchPlan | None:
        """Look up a plan by id. Returns None when missing or expired."""
        with self._lock:
            self._prune_locked()
            return self._plans.get(plan_id)

    def list_pending(self) -> list[ResearchPlan]:
        """Return every pending plan, newest first."""
        with self._lock:
            self._prune_locked()
            pending = [p for p in self._plans.values() if p.status == "pending"]
            pending.sort(key=lambda p: -p.created_at)
            return pending

    def approve(self, plan_id: str) -> ResearchPlan | None:
        """Mark a pending plan as approved. Returns the updated record,
        or None if the plan is unknown / already decided / expired."""
        with self._lock:
            self._prune_locked()
            plan = self._plans.get(plan_id)
            if plan is None or plan.status != "pending":
                return None
            plan.status = "approved"
            plan.decided_at = time.time()
            self._persist_locked(plan)
            return plan

    def reject(self, plan_id: str) -> ResearchPlan | None:
        """Mark a pending plan as rejected. Returns the updated record,
        or None if the plan is unknown / already decided / expired."""
        with self._lock:
            self._prune_locked()
            plan = self._plans.get(plan_id)
            if plan is None or plan.status != "pending":
                return None
            plan.status = "rejected"
            plan.decided_at = time.time()
            self._persist_locked(plan)
            return plan

    def consume(self, plan_id: str) -> ResearchPlan | None:
        """Mark an approved plan as consumed (the tool has re-invoked
        and is now firing the queries). Returns the updated record, or
        None if the plan isn't approved or is missing."""
        with self._lock:
            self._prune_locked()
            plan = self._plans.get(plan_id)
            if plan is None or plan.status != "approved":
                return None
            plan.status = "consumed"
            plan.consumed_at = time.time()
            self._persist_locked(plan)
            return plan

    def stats(self) -> dict[str, int]:
        """Snapshot for /admin: counts by status."""
        with self._lock:
            self._prune_locked()
            counts = {"pending": 0, "approved": 0, "rejected": 0, "consumed": 0}
            for plan in self._plans.values():
                counts[plan.status] = counts.get(plan.status, 0) + 1
            counts["total"] = len(self._plans)
            return counts

    # ── Internal ──────────────────────────────────────────────────────

    def _prune_locked(self) -> None:
        """Remove plans older than TTL. Caller must hold the lock."""
        now = time.time()
        cutoff = now - self._ttl
        stale = [pid for pid, plan in self._plans.items() if plan.created_at < cutoff]
        for pid in stale:
            del self._plans[pid]
            self._persist_delete_locked(pid)
