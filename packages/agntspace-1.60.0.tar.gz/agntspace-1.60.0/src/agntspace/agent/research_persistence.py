"""SQLite-backed persistence for research plan + proposal stores.

Closes the persistence gap: in-memory dicts lose state on every server
restart. Approved-but-not-applied proposals just vanish, which is the
worst possible failure mode (user thought they triaged it, work lost).

Design:

* **One file per store** — ``research_plans.db`` + ``research_proposals.db``
  inside ``<vault>/agntspace/research/``. Independent writer locks
  per-file, no contention with the main agntspace.db. Same shape as
  the audit.db / automation.db / finance.db split (CLAUDE.md
  Rule 18).

* **Synchronous sqlite3** (NOT aiosqlite) so the existing store API
  stays sync. Converting to async would force every consumer
  (tools.py, route handlers, tests) to await. The sync path
  matches the pattern in ``vault/scope_writes.py`` — same connection
  PRAGMAs, same WAL mode, same timeout discipline.

* **Write-through on every mutation** under the existing
  ``threading.Lock``. The store mirrors the SQL row state exactly —
  no separate buffer that could drift.

* **Rehydrate on construction**. Pass ``db_path=`` and the store
  reads every row into the in-memory dict. Subsequent reads hit the
  dict (fast); writes update both.

* **TTL pruning works on disk too** — same logic, ``DELETE FROM ...
  WHERE created_at < ?`` runs on every rehydrate so stale rows
  never accumulate across restarts.

* **Defensive everywhere**. ``init_db`` returns None on every error
  path (corrupt file, permission denied, sqlite3 build issues).
  Callers MUST check ``if conn is not None:`` before using the
  connection. The store falls back to pure-in-memory mode when
  persistence fails.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


# arch:deterministic — schema versioning. Bump only when an
# incompatible column-rename / type-change lands. Additive changes
# (new column with a default) work via ALTER TABLE in the migration
# block of init_db so existing rows keep working.
_SCHEMA_VERSION: int = 1


_PLAN_SCHEMA = """
CREATE TABLE IF NOT EXISTS research_plans (
    plan_id TEXT PRIMARY KEY,
    topic TEXT NOT NULL,
    target_kb TEXT NOT NULL,
    queries_json TEXT NOT NULL,
    estimated_cost_usd REAL NOT NULL DEFAULT 0,
    baseline_entities_used INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    decided_at REAL,
    consumed_at REAL,
    correlation_id TEXT NOT NULL DEFAULT '',
    extra_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_plans_status ON research_plans(status);
CREATE INDEX IF NOT EXISTS idx_plans_created ON research_plans(created_at);
"""


_PROPOSAL_SCHEMA = """
CREATE TABLE IF NOT EXISTS research_proposals (
    proposal_id TEXT PRIMARY KEY,
    topic TEXT NOT NULL,
    target_kb TEXT NOT NULL,
    recommendation TEXT NOT NULL,
    severity TEXT NOT NULL,
    source_synthesis_path TEXT NOT NULL,
    correlation_id TEXT NOT NULL DEFAULT '',
    created_at REAL NOT NULL,
    status TEXT NOT NULL,
    decided_at REAL,
    rationale TEXT NOT NULL DEFAULT '',
    apply_outcome TEXT NOT NULL DEFAULT '',
    apply_summary TEXT NOT NULL DEFAULT '',
    apply_started_at REAL,
    apply_finished_at REAL,
    apply_error TEXT NOT NULL DEFAULT '',
    applied_article_slug TEXT NOT NULL DEFAULT '',
    extra_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_proposals_status ON research_proposals(status);
CREATE INDEX IF NOT EXISTS idx_proposals_created ON research_proposals(created_at);
"""


def init_db(db_path: Path | str, schema_sql: str) -> sqlite3.Connection | None:
    """Open + schema-init a sqlite3 connection for one store.

    Returns None on ANY failure path — corrupt file, permission
    denied, sqlite3 missing. Callers must check the return.
    Behaviour mirrors ``vault/scope_writes.py``: WAL mode + 30s
    busy_timeout + autocheckpoint, all wrapped in try/except so a
    pragma rejection doesn't crash the open.
    """
    try:
        path = Path(db_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(
            str(path),
            check_same_thread=False,
            timeout=30.0,
            isolation_level=None,  # autocommit — every execute commits
        )
    except Exception:
        log.exception("research_persistence: connect failed for %s", db_path)
        return None

    # PRAGMA discipline — same shape as scope_writes.py + the
    # audit/automation/finance.db files. Each pragma is fail-soft so a
    # corrupted DB or unsupported mode doesn't crash construction.
    for pragma in (
        "PRAGMA journal_mode=WAL",
        "PRAGMA synchronous=NORMAL",
        "PRAGMA busy_timeout=30000",
        "PRAGMA wal_autocheckpoint=200",
    ):
        try:
            conn.execute(pragma)
        except Exception:
            log.debug("research_persistence: pragma failed: %s", pragma, exc_info=True)

    # One-time WAL checkpoint truncate to avoid carrying a stale WAL
    # across boots (matches the pattern in get_audit_db).
    try:
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except Exception:
        pass

    # Schema. Idempotent — IF NOT EXISTS on every CREATE.
    try:
        conn.executescript(schema_sql)
    except Exception:
        log.exception("research_persistence: schema init failed for %s", db_path)
        try:
            conn.close()
        except Exception:
            pass
        return None

    return conn


def init_plan_db(db_path: Path | str) -> sqlite3.Connection | None:
    """Open the research_plans.db connection."""
    return init_db(db_path, _PLAN_SCHEMA)


def init_proposal_db(db_path: Path | str) -> sqlite3.Connection | None:
    """Open the research_proposals.db connection."""
    return init_db(db_path, _PROPOSAL_SCHEMA)


# ── Plan serialization ────────────────────────────────────────────────


def plan_to_row(plan: Any) -> dict[str, Any]:
    """Serialize a ResearchPlan dataclass to a SQL-friendly dict.

    ``queries`` is a list of dicts → JSON. ``extra`` is opaque dict →
    JSON. Everything else round-trips as native types.
    """
    return {
        "plan_id": plan.plan_id,
        "topic": plan.topic,
        "target_kb": plan.target_kb,
        "queries_json": json.dumps(plan.queries or []),
        "estimated_cost_usd": float(plan.estimated_cost_usd or 0.0),
        "baseline_entities_used": int(plan.baseline_entities_used or 0),
        "created_at": float(plan.created_at),
        "status": plan.status,
        "decided_at": plan.decided_at,
        "consumed_at": plan.consumed_at,
        "correlation_id": plan.correlation_id or "",
        "extra_json": json.dumps(plan.extra or {}),
    }


def plan_from_row(row: tuple) -> dict[str, Any] | None:
    """Inverse of plan_to_row — returns kwargs ready for ResearchPlan().

    Returns None if the JSON columns are malformed (defensive — a
    single corrupt row should not block rehydrate).
    """
    try:
        return {
            "plan_id": row[0],
            "topic": row[1],
            "target_kb": row[2],
            "queries": json.loads(row[3] or "[]"),
            "estimated_cost_usd": float(row[4] or 0.0),
            "baseline_entities_used": int(row[5] or 0),
            "created_at": float(row[6]),
            "status": row[7],
            "decided_at": row[8],
            "consumed_at": row[9],
            "correlation_id": row[10] or "",
            "extra": json.loads(row[11] or "{}"),
        }
    except Exception:
        log.debug("research_persistence: malformed plan row %s", row[:1], exc_info=True)
        return None


_PLAN_COLUMNS = (
    "plan_id, topic, target_kb, queries_json, estimated_cost_usd, "
    "baseline_entities_used, created_at, status, decided_at, consumed_at, "
    "correlation_id, extra_json"
)


def upsert_plan(conn: sqlite3.Connection | None, plan: Any) -> None:
    """Write-through insert/replace for one plan. No-op when conn is None."""
    if conn is None:
        return
    try:
        row = plan_to_row(plan)
        conn.execute(
            f"INSERT OR REPLACE INTO research_plans ({_PLAN_COLUMNS}) "
            f"VALUES (:plan_id, :topic, :target_kb, :queries_json, "
            f":estimated_cost_usd, :baseline_entities_used, :created_at, "
            f":status, :decided_at, :consumed_at, :correlation_id, :extra_json)",
            row,
        )
    except Exception:
        log.exception("research_persistence: upsert_plan failed for %s", plan.plan_id)


def delete_plan(conn: sqlite3.Connection | None, plan_id: str) -> None:
    """Delete one plan. No-op when conn is None or plan doesn't exist."""
    if conn is None:
        return
    try:
        conn.execute("DELETE FROM research_plans WHERE plan_id = ?", (plan_id,))
    except Exception:
        log.exception("research_persistence: delete_plan failed for %s", plan_id)


def load_all_plans(conn: sqlite3.Connection | None) -> list[dict[str, Any]]:
    """Read every plan row + return as kwargs lists. Empty on error."""
    if conn is None:
        return []
    try:
        cursor = conn.execute(f"SELECT {_PLAN_COLUMNS} FROM research_plans")
        rows = cursor.fetchall()
    except Exception:
        log.exception("research_persistence: load_all_plans failed")
        return []
    out: list[dict[str, Any]] = []
    for row in rows:
        kwargs = plan_from_row(row)
        if kwargs is not None:
            out.append(kwargs)
    return out


def prune_plans_older_than(conn: sqlite3.Connection | None, cutoff: float) -> int:
    """DELETE plans with created_at < cutoff. Returns rows-deleted count."""
    if conn is None:
        return 0
    try:
        cursor = conn.execute(
            "DELETE FROM research_plans WHERE created_at < ?", (cutoff,),
        )
        return int(cursor.rowcount or 0)
    except Exception:
        log.exception("research_persistence: prune_plans failed")
        return 0


# ── Proposal serialization ────────────────────────────────────────────


def proposal_to_row(prop: Any) -> dict[str, Any]:
    """Serialize a ResearchProposal dataclass to a SQL-friendly dict."""
    return {
        "proposal_id": prop.proposal_id,
        "topic": prop.topic,
        "target_kb": prop.target_kb,
        "recommendation": prop.recommendation,
        "severity": prop.severity,
        "source_synthesis_path": prop.source_synthesis_path,
        "correlation_id": prop.correlation_id or "",
        "created_at": float(prop.created_at),
        "status": prop.status,
        "decided_at": prop.decided_at,
        "rationale": prop.rationale or "",
        "apply_outcome": prop.apply_outcome or "",
        "apply_summary": prop.apply_summary or "",
        "apply_started_at": prop.apply_started_at,
        "apply_finished_at": prop.apply_finished_at,
        "apply_error": prop.apply_error or "",
        "applied_article_slug": prop.applied_article_slug or "",
        "extra_json": json.dumps(prop.extra or {}),
    }


def proposal_from_row(row: tuple) -> dict[str, Any] | None:
    """Inverse of proposal_to_row — returns kwargs ready for ResearchProposal()."""
    try:
        return {
            "proposal_id": row[0],
            "topic": row[1],
            "target_kb": row[2],
            "recommendation": row[3],
            "severity": row[4],
            "source_synthesis_path": row[5],
            "correlation_id": row[6] or "",
            "created_at": float(row[7]),
            "status": row[8],
            "decided_at": row[9],
            "rationale": row[10] or "",
            "apply_outcome": row[11] or "",
            "apply_summary": row[12] or "",
            "apply_started_at": row[13],
            "apply_finished_at": row[14],
            "apply_error": row[15] or "",
            "applied_article_slug": row[16] or "",
            "extra": json.loads(row[17] or "{}"),
        }
    except Exception:
        log.debug("research_persistence: malformed proposal row %s", row[:1], exc_info=True)
        return None


_PROPOSAL_COLUMNS = (
    "proposal_id, topic, target_kb, recommendation, severity, "
    "source_synthesis_path, correlation_id, created_at, status, "
    "decided_at, rationale, apply_outcome, apply_summary, "
    "apply_started_at, apply_finished_at, apply_error, "
    "applied_article_slug, extra_json"
)


def upsert_proposal(conn: sqlite3.Connection | None, prop: Any) -> None:
    """Write-through insert/replace for one proposal. No-op when conn is None."""
    if conn is None:
        return
    try:
        row = proposal_to_row(prop)
        conn.execute(
            f"INSERT OR REPLACE INTO research_proposals ({_PROPOSAL_COLUMNS}) "
            f"VALUES (:proposal_id, :topic, :target_kb, :recommendation, "
            f":severity, :source_synthesis_path, :correlation_id, "
            f":created_at, :status, :decided_at, :rationale, :apply_outcome, "
            f":apply_summary, :apply_started_at, :apply_finished_at, "
            f":apply_error, :applied_article_slug, :extra_json)",
            row,
        )
    except Exception:
        log.exception(
            "research_persistence: upsert_proposal failed for %s",
            prop.proposal_id,
        )


def delete_proposal(conn: sqlite3.Connection | None, proposal_id: str) -> None:
    if conn is None:
        return
    try:
        conn.execute(
            "DELETE FROM research_proposals WHERE proposal_id = ?", (proposal_id,),
        )
    except Exception:
        log.exception(
            "research_persistence: delete_proposal failed for %s", proposal_id,
        )


def load_all_proposals(conn: sqlite3.Connection | None) -> list[dict[str, Any]]:
    if conn is None:
        return []
    try:
        cursor = conn.execute(
            f"SELECT {_PROPOSAL_COLUMNS} FROM research_proposals",
        )
        rows = cursor.fetchall()
    except Exception:
        log.exception("research_persistence: load_all_proposals failed")
        return []
    out: list[dict[str, Any]] = []
    for row in rows:
        kwargs = proposal_from_row(row)
        if kwargs is not None:
            out.append(kwargs)
    return out


def prune_proposals_older_than(
    conn: sqlite3.Connection | None, cutoff: float,
) -> int:
    if conn is None:
        return 0
    try:
        cursor = conn.execute(
            "DELETE FROM research_proposals WHERE created_at < ?", (cutoff,),
        )
        return int(cursor.rowcount or 0)
    except Exception:
        log.exception("research_persistence: prune_proposals failed")
        return 0
