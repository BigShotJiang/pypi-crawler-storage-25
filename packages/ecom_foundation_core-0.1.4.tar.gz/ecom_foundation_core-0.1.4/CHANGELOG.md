# Changelog

## [0.1.4] - 2026-04-27

### Added

- Support for `additional_claims` in authentication tokens (multi-tenancy support)
- Introduction of temporary 2FA tokens for secure multi-step verification
- Support for temporary email verification tokens

### Changed

- Enforced email verification during login process
- Refactored `verify_email` service to handle both string tokens and request objects
- Improved token refresh flow with automatic `tenant_id` extraction
- Updated `InvalidCredentialsError` to support custom messages
- Enhanced `TwoFactorLoginRequest` schema for better flexibility

## [0.1.3] - 2026-04-23

### Fixed

- Stabilized release process and version alignment
- Injected resources update and stability fixes

## [0.1.2] - 2026-04-23

### Changed

- Production hardening and linting fixes

## [0.1.1] - 2026-04-23

### Changed

- Production hardening and linting fixes

## [0.1.0] - 2024-01-15

### Added

- Initial release with auth, notifications, and billing modules
- FastAPI application factory
- SQLAlchemy models and migrations
- SendGrid and Twilio integrations

### Changed

- N/A

### Deprecated

- N/A

### Removed

- N/A

### Fixed

- N/A
