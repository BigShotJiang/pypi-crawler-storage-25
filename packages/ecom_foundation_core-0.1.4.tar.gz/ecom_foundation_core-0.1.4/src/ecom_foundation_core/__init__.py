"""E-Com Foundation Core - Enterprise platform foundation for any applications."""

__version__ = "0.1.4"
__author__ = "e-com services limited"
__license__ = "Proprietary"

from .bootstrap import AppConfig, create_app
from .config import Settings, get_settings

# Export main components
__all__ = [
    "create_app",
    "AppConfig",
    "Settings",
    "get_settings",
    "__version__",
]
