"""
Authentication exceptions.
"""

from typing import Never

from fastapi import HTTPException, status


class AuthError(Exception):
    """Base authentication error."""

    def __init__(self, message: str = "Authentication error") -> None:
        self.message = message
        super().__init__(message)


class InvalidCredentialsError(AuthError):
    """Invalid username or password."""

    def __init__(self, message: str = "Invalid credentials") -> None:
        super().__init__(message)


class UserNotFoundError(AuthError):
    """User not found."""

    def __init__(self, identifier: str = "") -> None:
        message = f"User not found: {identifier}" if identifier else "User not found"
        super().__init__(message)


class UserAlreadyExistsError(AuthError):
    """User already exists."""

    def __init__(self, email: str) -> None:
        super().__init__(f"User with email {email} already exists")


class AccountLockedError(AuthError):
    """Account is locked due to too many failed attempts."""

    def __init__(self, unlock_at: str = "") -> None:
        message = "Account is locked"
        if unlock_at:
            message += f" until {unlock_at}"
        super().__init__(message)


class InvalidTokenError(AuthError):
    """Invalid or expired token."""

    def __init__(self, token_type: str = "") -> None:
        message = "Invalid token"
        if token_type:
            message += f" ({token_type})"
        super().__init__(message)


class InsufficientPermissionsError(AuthError):
    """User lacks required permissions."""

    def __init__(self, permission: str = "") -> None:
        message = "Insufficient permissions"
        if permission:
            message += f": {permission}"
        super().__init__(message)


class PasswordValidationError(AuthError):
    """Password validation failed."""

    def __init__(self, message: str = "Password does not meet requirements") -> None:
        super().__init__(message)


# HTTP Exceptions for FastAPI
def raise_http_exception(error: AuthError) -> Never:
    """Convert AuthError to appropriate HTTPException."""
    if isinstance(error, InvalidCredentialsError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=error.message,
            headers={"WWW-Authenticate": "Bearer"},
        )
    elif isinstance(error, UserNotFoundError):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=error.message,
        )
    elif isinstance(error, UserAlreadyExistsError):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=error.message,
        )
    elif isinstance(error, AccountLockedError):
        raise HTTPException(
            status_code=status.HTTP_423_LOCKED,
            detail=error.message,
        )
    elif isinstance(error, InvalidTokenError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=error.message,
            headers={"WWW-Authenticate": "Bearer"},
        )
    elif isinstance(error, InsufficientPermissionsError):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=error.message,
        )
    else:
        # Fallback for generic exceptions (like DBAPIError)
        detail = getattr(error, "message", str(error))
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=detail,
        )
