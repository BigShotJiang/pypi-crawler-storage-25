import logging
from typing import Any
from uuid import UUID

logger = logging.getLogger(__name__)

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.security import HTTPBearer

from ..common.rate_limiting import rate_limit
from .dependencies import (
    get_auth_service,
    get_current_active_user,
    get_current_superuser,
    get_current_user,
    has_permission,
    has_role,
    get_master_db,
)
from .exceptions import raise_http_exception
from .schemas import (
    EmailVerificationRequest,
    InvitationCreate,
    LoginRequest,
    PasswordResetConfirm,
    PasswordResetRequest,
    RefreshTokenRequest,
    SessionResponse,
    TokenResponse,
    TwoFactorLoginRequest,
    TwoFactorRequest,
    UserCreate,
    UserResponse,
    UserUpdate,
)
from .service import AuthService

# Export public interfaces
__all__ = [
    # Dependencies
    "get_current_user",
    "get_current_active_user",
    "get_current_superuser",
    "has_permission",
    "has_role",
    # Models
    "User",
    "Role",
    "Permission",
    # Schemas
    "UserCreate",
    "UserUpdate",
    "UserResponse",
    "LoginRequest",
    "TokenResponse",
    "RefreshTokenRequest",
    "PasswordResetRequest",
    "PasswordResetConfirm",
    "EmailVerificationRequest",
    "InvitationCreate",
    "TwoFactorRequest",
    "TwoFactorLoginRequest",
    "SessionResponse",
    # Service
    "AuthService",
    # Security
    "verify_password",
    "get_password_hash",
]


def setup_auth(app: FastAPI) -> None:
    """Setup authentication routes and dependencies."""

    # Add security scheme to OpenAPI
    security_scheme = HTTPBearer()
    app.state.security_scheme = security_scheme

    @app.post("/auth/register", response_model=TokenResponse)
    async def register(
        user_data: UserCreate,
        _rate_limit: dict = Depends(rate_limit(limit=3, window=3600)),  # 3/hour
        auth_service: AuthService = Depends(get_auth_service),
    ) -> TokenResponse:
        """Register a new user."""
        try:
            result = await auth_service.register(user_data)
            return result["tokens"]
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/login", response_model=TokenResponse)
    async def login(
        login_data: LoginRequest,
        request: Request,
        _rate_limit: dict = Depends(rate_limit(limit=5, window=300)),  # 5/5min
        auth_service: AuthService = Depends(get_auth_service),
    ) -> TokenResponse:
        """Login user."""
        try:
            # Extract tenant ID from header if present
            tenant_id = request.headers.get("X-Tenant-ID")

            # If no tenant ID, try to discover it by searching all tenants (Discovery Flow)
            if not tenant_id:
                # We need access to the master DB to list tenants
                # This assumes get_auth_service provides access to the current repo/db
                from ecom_foundation_core.modules.auth.exceptions import AuthError

                # Search across tenants
                # Note: This requires a way to list tenants.
                # Since foundation-core is generic, we'll try to find a tenant registry.
                # In this specific implementation, we'll look for a 'tenants' table if it exists.
                try:
                    from sqlalchemy import text
                    from .exceptions import AuthError

                    # 1. Search for tenant where this user is the admin (primary discovery)
                    # We use auth_service.user_repo.db which is currently on Master if no header
                    query = text("SELECT id FROM tenants WHERE admin_email = :email")
                    result_tenant = await auth_service.user_repo.db.execute(
                        query, {"email": login_data.email or login_data.username}
                    )
                    tenant_row = result_tenant.fetchone()

                    if tenant_row:
                        tenant_id = str(tenant_row[0])
                        logger.info(
                            f"DEBUG discovery: Found tenant_id={tenant_id} for admin_email {login_data.email}"
                        )
                    else:
                        # 2. Could implement more complex discovery here if needed
                        pass
                except Exception as e:
                    logger.warning(f"DEBUG discovery: Discovery failed: {e}")
                    pass

            if not tenant_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="X-Tenant-ID header is missing and could not be determined. Please provide it for login.",
                )

            additional_claims = {"tenant_id": tenant_id} if tenant_id else None

            result = await auth_service.login(
                login_data,
                ip_address=request.client.host if request.client else None,
                user_agent=request.headers.get("user-agent"),
                additional_claims=additional_claims,
            )
            if result["requires_2fa"]:
                raise HTTPException(
                    status_code=status.HTTP_202_ACCEPTED,
                    detail={
                        "requires_2fa": True,
                        "user_id": str(result["user_id"]),
                        "two_factor_method": result["two_factor_method"],
                        "2fa_token": result["2fa_token"],
                    },
                )

            # Combine tokens and user into response
            response = result["tokens"]

            # Sanitize user data
            user_dict = (
                result["user"].to_dict()
                if hasattr(result["user"], "to_dict")
                else result["user"].__dict__
            )
            # Remove sensitive fields
            for field in [
                "password",
                "hashed_password",
                "two_factor_secret",
                "backup_codes",
                "metadata_",
            ]:
                user_dict.pop(field, None)
            response.user = user_dict

            # Add tenant info if available
            if tenant_id:
                try:
                    query = text(
                        "SELECT id, name, subdomain FROM tenants WHERE id = :tid"
                    )
                    result_tenant = await auth_service.user_repo.db.execute(
                        query, {"tid": tenant_id}
                    )
                    tenant_row = result_tenant.fetchone()
                    if tenant_row:
                        response.tenant = {
                            "id": str(tenant_row[0]),
                            "name": tenant_row[1],
                            "subdomain": tenant_row[2],
                        }
                except:
                    response.tenant = {"id": tenant_id}

            return response
        except Exception as e:
            raise_http_exception(e)

    async def verify_2fa_token(auth_service: AuthService, token: str) -> dict[str, Any]:
        """Verify the temporary 2FA token and return payload."""
        try:
            from .security import decode_token
            from .constants import TOKEN_TYPE_2FA
            from .exceptions import AuthError

            payload = decode_token(token)
            token_type = payload.get("type")
            if token_type not in [TOKEN_TYPE_2FA, "access"]:
                raise AuthError(f"Invalid token type '{token_type}' for 2FA login")

            return payload
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/2fa/login", response_model=TokenResponse)
    async def login_2fa(
        login_data: TwoFactorLoginRequest,
        request: Request,
        _rate_limit: dict = Depends(rate_limit(limit=5, window=300)),
        auth_service: AuthService = Depends(get_auth_service),
        token_auth: Any = Depends(HTTPBearer()),
    ) -> TokenResponse:
        """Complete login with 2FA code."""
        try:
            # Try to get user_id from token first
            payload = await verify_2fa_token(auth_service, token_auth.credentials)
            user_id = UUID(payload["sub"])

            # Extract tenant ID from header or token payload
            tenant_id = request.headers.get("X-Tenant-ID") or payload.get("tenant_id")

            # If still missing, try discovery as a last resort
            if not tenant_id:
                try:
                    from sqlalchemy import text

                    # We need the email/username but we only have user_id from token.
                    # We can fetch the user to get their email.
                    user = await auth_service.user_repo.get_by_id(user_id)
                    if user and user.email:
                        query = text(
                            "SELECT id FROM tenants WHERE admin_email = :email"
                        )
                        result_tenant = await auth_service.user_repo.db.execute(
                            query, {"email": user.email}
                        )
                        tenant_row = result_tenant.fetchone()
                        if tenant_row:
                            tenant_id = str(tenant_row[0])
                            logger.info(
                                f"DEBUG discovery (2FA): Found tenant_id={tenant_id} for user {user.email}"
                            )
                except:
                    pass

            additional_claims = {"tenant_id": tenant_id} if tenant_id else None

            # Construct request object for service layer
            two_factor_data = TwoFactorRequest(method="any", code=login_data.code)

            result = await auth_service.verify_2fa(
                user_id,
                two_factor_data,
                additional_claims=additional_claims,
            )
            return result["tokens"]
        except Exception as e:
            # Fallback to user_id in body if token is not for 2FA or missing sub
            try:
                # If the above failed, try using user_id from body (legacy/fallback)
                two_factor_data = TwoFactorRequest(method="any", code=login_data.code)
                result = await auth_service.verify_2fa(
                    login_data.user_id,
                    two_factor_data,
                    additional_claims=additional_claims,
                )
                return result["tokens"]
            except:
                raise_http_exception(e)

    @app.post("/auth/2fa/verify")
    async def verify_2fa(
        two_factor_data: TwoFactorRequest,
        request: Request,
        current_user: dict = Depends(get_current_user),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, Any]:
        """Verify 2FA setup (finalize enabling 2FA)."""
        try:
            # Extract tenant ID from header if present
            tenant_id = request.headers.get("X-Tenant-ID")
            additional_claims = {"tenant_id": tenant_id} if tenant_id else None

            result = await auth_service.verify_2fa(
                current_user["user"].id,
                two_factor_data,
                additional_claims=additional_claims,
            )
            return {"message": "2FA verified and enabled", "tokens": result["tokens"]}
        except Exception as e:
            raise_http_exception(e)

    @app.get("/auth/email/verify")
    async def verify_email(
        token: str,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Verify email address."""
        success = await auth_service.verify_email(token)
        if not success:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired verification token",
            )
        return {"message": "Email verified successfully. You can now log in."}

    @app.post("/auth/2fa/enable")
    async def enable_2fa(
        two_factor_data: TwoFactorRequest,
        current_user: dict = Depends(get_current_user),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, Any]:
        """Enable 2FA for the current user."""
        try:
            result = await auth_service.enable_2fa(
                current_user["user"].id,
                two_factor_data.method,
            )
            return result
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/2fa/disable")
    async def disable_2fa(
        two_factor_data: TwoFactorRequest,
        current_user: dict = Depends(get_current_user),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Disable 2FA for the current user."""
        try:
            if not two_factor_data.code:
                raise HTTPException(
                    status_code=400, detail="Code required to disable 2FA"
                )

            await auth_service.disable_2fa(
                current_user["user"].id,
                two_factor_data.code,
            )
            return {"message": "2FA disabled successfully"}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/refresh", response_model=TokenResponse)
    async def refresh_token(
        refresh_data: RefreshTokenRequest,
        request: Request,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> TokenResponse:
        """Refresh access token."""
        # Extract tenant ID from header if present
        tenant_id = request.headers.get("X-Tenant-ID")
        additional_claims = {"tenant_id": tenant_id} if tenant_id else None

        try:
            return await auth_service.refresh_token(
                refresh_data.refresh_token, additional_claims=additional_claims
            )
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/logout")
    async def logout(
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_active_user),
    ) -> dict[str, str]:
        """Logout user."""
        try:
            # Get token from header
            # This would need access to request headers
            # For simplicity, we'll require token in body for logout
            return {"message": "Logout successful"}
        except Exception as e:
            raise_http_exception(e)

    @app.get("/auth/me", response_model=UserResponse)
    async def get_me(
        request: Request,
        current_user: dict = Depends(get_current_active_user),
        master_db: Any = Depends(get_master_db),
    ) -> Any:
        """Get current user with tenant info."""
        user = current_user["user"]

        # Try to resolve tenant info
        tenant_id = request.headers.get("X-Tenant-ID")

        # If not in header, try to get from current_user dict (if we added it there)
        # or from the request state (set by middleware)
        if not tenant_id and hasattr(request.state, "tenant_id"):
            tenant_id = request.state.tenant_id

        if tenant_id:
            try:
                from sqlalchemy import text

                query = text("SELECT id, name, subdomain FROM tenants WHERE id = :tid")
                result_tenant = await master_db.execute(query, {"tid": tenant_id})
                tenant_row = result_tenant.fetchone()
                if tenant_row:
                    user.tenant = {
                        "id": str(tenant_row[0]),
                        "name": tenant_row[1],
                        "subdomain": tenant_row[2],
                    }
            except:
                user.tenant = {"id": tenant_id}

        return user

    @app.put("/auth/me", response_model=UserResponse)
    async def update_me(
        update_data: UserUpdate,
        _rate_limit: dict = Depends(rate_limit(limit=5, window=300)),
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_active_user),
    ) -> UserResponse:
        """Update current user profile."""
        try:
            result = await auth_service.update_profile(
                current_user["user"].id,
                update_data,
            )
            return result["user"]
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/password/reset")
    async def request_password_reset(
        reset_data: PasswordResetRequest,
        _rate_limit: dict = Depends(rate_limit(limit=4, window=3600)),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Request password reset."""
        try:
            return await auth_service.request_password_reset(reset_data)
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/password/reset/confirm")
    async def confirm_password_reset(
        reset_data: PasswordResetConfirm,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Confirm password reset."""
        try:
            await auth_service.confirm_password_reset(reset_data)
            return {"message": "Password reset successful"}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/email/verify")
    async def verify_email_post(
        verification_data: EmailVerificationRequest,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Verify email address."""
        try:
            await auth_service.verify_email(verification_data)
            return {"message": "Email verified successfully"}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/email/verify/resend")
    async def resend_verification(
        email: str,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Resend email verification."""
        try:
            await auth_service.resend_verification(email)
            return {"message": "Verification email sent"}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/invitations")
    async def create_invitation(
        invitation_data: InvitationCreate,
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_active_user),
    ) -> dict[str, Any]:
        """Create an invitation."""
        try:
            result = await auth_service.create_invitation(
                current_user["user"].id,
                invitation_data,
            )
            return result
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/invitations/accept")
    async def accept_invitation(
        invitation_token: str,
        user_data: UserCreate,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, Any]:
        """Accept an invitation."""
        try:
            result = await auth_service.accept_invitation(
                invitation_token,
                user_data,
            )
            return result
        except Exception as e:
            raise_http_exception(e)

    @app.get("/auth/sessions")
    async def get_sessions(
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_active_user),
    ) -> list[SessionResponse]:
        """Get current user's active sessions."""
        try:
            sessions = await auth_service.get_sessions(current_user["user"].id)
            return sessions
        except Exception as e:
            raise_http_exception(e)

    # Admin endpoints (require superuser)
    @app.get("/admin/users")
    async def list_users(
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_superuser),
        skip: int = 0,
        limit: int = 100,
    ) -> list[UserResponse]:
        """List all users (admin only)."""
        try:
            users = await auth_service.user_repo.list(skip, limit)
            return users
        except Exception as e:
            raise_http_exception(e)

    return app
