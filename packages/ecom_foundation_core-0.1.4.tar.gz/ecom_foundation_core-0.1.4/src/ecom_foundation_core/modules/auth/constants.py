"""
Authentication constants.
"""

# Token types
TOKEN_TYPE_ACCESS = "access"
TOKEN_TYPE_REFRESH = "refresh"
TOKEN_TYPE_RESET = "reset"
TOKEN_TYPE_VERIFICATION = "verification"
TOKEN_TYPE_INVITATION = "invitation"
TOKEN_TYPE_2FA = "2fa"

# Token expiration (in seconds)
ACCESS_TOKEN_EXPIRE = 30 * 60  # 30 minutes
REFRESH_TOKEN_EXPIRE = 7 * 24 * 60 * 60  # 7 days
RESET_TOKEN_EXPIRE = 1 * 60 * 60  # 1 hour
VERIFICATION_TOKEN_EXPIRE = 24 * 60 * 60  # 24 hours
TOKEN_2FA_EXPIRE = 5 * 60  # 5 minutes

# User status
USER_STATUS_ACTIVE = "active"
USER_STATUS_INACTIVE = "inactive"
USER_STATUS_PENDING = "pending"
USER_STATUS_SUSPENDED = "suspended"
USER_STATUS_DELETED = "deleted"

# Role names
ROLE_SUPER_ADMIN = "super_admin"
ROLE_ADMIN = "admin"
ROLE_USER = "user"
ROLE_GUEST = "guest"

# Permission scopes
PERMISSION_SCOPE_USERS = "users"
PERMISSION_SCOPE_ROLES = "roles"
PERMISSION_SCOPE_AUTH = "auth"
PERMISSION_SCOPE_PROFILE = "profile"

# Actions
ACTION_CREATE = "create"
ACTION_READ = "read"
ACTION_UPDATE = "update"
ACTION_DELETE = "delete"
ACTION_MANAGE = "manage"

# OAuth providers
OAUTH_GOOGLE = "google"
OAUTH_FACEBOOK = "facebook"
OAUTH_GITHUB = "github"
OAUTH_MICROSOFT = "microsoft"

# Session management
SESSION_MAX_AGE = 30 * 24 * 60 * 60  # 30 days
MAX_SESSIONS_PER_USER = 10

# Security
MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_TIME = 15 * 60  # 15 minutes
PASSWORD_MIN_LENGTH = 8
PASSWORD_MAX_LENGTH = 128
