"""
Security utilities for authentication.
"""

import hmac
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID, uuid4

from jose import jwt
from jose.exceptions import ExpiredSignatureError, JWTError
from passlib.context import CryptContext

from ..common.config import get_settings
from .constants import (
    ACCESS_TOKEN_EXPIRE,
    REFRESH_TOKEN_EXPIRE,
    RESET_TOKEN_EXPIRE,
    TOKEN_TYPE_ACCESS,
    TOKEN_TYPE_2FA,
    TOKEN_2FA_EXPIRE,
    TOKEN_TYPE_INVITATION,
    TOKEN_TYPE_REFRESH,
    TOKEN_TYPE_RESET,
    TOKEN_TYPE_VERIFICATION,
    VERIFICATION_TOKEN_EXPIRE,
)
from .schemas import TokenResponse

settings = get_settings()

# Password hashing context
pwd_context = CryptContext(
    # Keep hashing backend pure-python for portability in tests/CI.
    schemes=["pbkdf2_sha256"],
    deprecated="auto",
)

# JWT configuration
ALGORITHM = settings.algorithm
SECRET_KEY = settings.secret_key


# Password utilities
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash."""
    return bool(pwd_context.verify(plain_password, hashed_password))


def get_password_hash(password: str) -> str:
    """Generate password hash."""
    return str(pwd_context.hash(password))


def generate_salt(length: int = 32) -> str:
    """Generate a random salt."""
    return secrets.token_urlsafe(length)


# Token generation and validation
def create_access_token(
    data: dict[str, Any],
    expires_delta: timedelta | None = None,
    token_type: str = TOKEN_TYPE_ACCESS,
) -> str:
    """Create a JWT token."""
    to_encode = data.copy()

    if expires_delta:
        expire = datetime.now(UTC) + expires_delta
    else:
        expire = datetime.now(UTC) + timedelta(seconds=ACCESS_TOKEN_EXPIRE)

    to_encode.update(
        {
            "exp": expire,
            "iat": datetime.now(UTC),
            "type": token_type,
            "jti": str(uuid4()),  # JWT ID for revocation tracking
        }
    )

    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return str(encoded_jwt)


def decode_token(token: str) -> dict[str, Any]:
    """Decode and validate a JWT token."""
    try:
        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM],
            options={"verify_exp": True},
        )
        return payload
    except ExpiredSignatureError:
        raise ValueError("Token has expired")
    except JWTError:
        raise ValueError("Invalid token")


def create_tokens(
    user_id: UUID,
    additional_claims: dict[str, Any] | None = None,
) -> TokenResponse:
    """Create access and refresh tokens for a user."""
    claims = {
        "sub": str(user_id),
        "user_id": str(user_id),
    }

    if additional_claims:
        claims.update(additional_claims)

    access_token = create_access_token(
        claims,
        expires_delta=timedelta(seconds=ACCESS_TOKEN_EXPIRE),
        token_type=TOKEN_TYPE_ACCESS,
    )

    refresh_payload = {"sub": str(user_id), "refresh": True}
    if additional_claims:
        refresh_payload.update(additional_claims)

    refresh_token = create_access_token(
        refresh_payload,
        expires_delta=timedelta(seconds=REFRESH_TOKEN_EXPIRE),
        token_type=TOKEN_TYPE_REFRESH,
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=ACCESS_TOKEN_EXPIRE,
        user_id=user_id,
    )


def create_reset_token(user_id: UUID) -> str:
    """Create a password reset token."""
    return create_access_token(
        {"sub": str(user_id), "purpose": "reset"},
        expires_delta=timedelta(seconds=RESET_TOKEN_EXPIRE),
        token_type=TOKEN_TYPE_RESET,
    )


def create_verification_token(
    user_id: UUID,
    additional_claims: dict[str, Any] | None = None,
) -> str:
    """Create a temporary token for email verification."""
    claims = {"sub": str(user_id), "purpose": "verify"}
    if additional_claims:
        claims.update(additional_claims)

    return create_access_token(
        claims,
        expires_delta=timedelta(seconds=VERIFICATION_TOKEN_EXPIRE),
        token_type=TOKEN_TYPE_VERIFICATION,
    )


def create_2fa_token(
    user_id: UUID,
    additional_claims: dict[str, Any] | None = None,
) -> str:
    """Create a temporary token for 2FA verification."""
    claims = {"sub": str(user_id)}
    if additional_claims:
        claims.update(additional_claims)

    return create_access_token(
        claims,
        expires_delta=timedelta(seconds=TOKEN_2FA_EXPIRE),
        token_type=TOKEN_TYPE_2FA,
    )


def create_invitation_token(
    email: str,
    inviter_id: UUID | None = None,
    role_ids: list | None = None,
) -> str:
    """Create an invitation token."""
    payload = {
        "email": email,
        "purpose": "invitation",
    }

    if inviter_id:
        payload["inviter_id"] = str(inviter_id)

    if role_ids:
        payload["role_ids"] = [str(role_id) for role_id in role_ids]

    return create_access_token(
        payload,
        expires_delta=timedelta(days=3),  # 3 days for invitations
        token_type=TOKEN_TYPE_INVITATION,
    )


def validate_reset_token(token: str) -> UUID | None:
    """Validate a password reset token and return user ID."""
    try:
        payload = decode_token(token)
        if payload.get("type") != TOKEN_TYPE_RESET:
            return None
        if payload.get("purpose") != "reset":
            return None
        return UUID(payload["sub"])
    except (jwt.InvalidTokenError, ValueError, KeyError):
        return None


def validate_verification_token(token: str) -> UUID | None:
    """Validate an email verification token and return user ID."""
    try:
        payload = decode_token(token)
        if payload.get("type") != TOKEN_TYPE_VERIFICATION:
            return None
        if payload.get("purpose") != "verify":
            return None
        return UUID(payload["sub"])
    except (jwt.InvalidTokenError, ValueError, KeyError):
        return None


def validate_invitation_token(token: str) -> dict[str, Any] | None:
    """Validate an invitation token and return its data."""
    try:
        payload = decode_token(token)
        if payload.get("type") != TOKEN_TYPE_INVITATION:
            return None
        if payload.get("purpose") != "invitation":
            return None

        result = {
            "email": payload["email"],
            "inviter_id": (
                UUID(payload["inviter_id"]) if payload.get("inviter_id") else None
            ),
        }

        if payload.get("role_ids"):
            result["role_ids"] = [UUID(role_id) for role_id in payload["role_ids"]]

        return result
    except (jwt.InvalidTokenError, ValueError, KeyError):
        return None


# Two-factor authentication
def generate_totp_secret() -> str:
    """Generate a TOTP secret."""
    return secrets.token_urlsafe(32)


def generate_2fa_code(length: int = 6) -> str:
    """Generate a 2FA code."""
    return "".join(str(secrets.randbelow(10)) for _ in range(length))


def verify_2fa_code(stored_code: str, provided_code: str) -> bool:
    """Verify a 2FA code (with timing-safe comparison)."""
    return hmac.compare_digest(stored_code, provided_code)


# Security headers and CSP
def get_security_headers() -> dict[str, str]:
    """Get security headers for responses."""
    return {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
    }


def get_csp_header() -> str:
    """Get Content Security Policy header."""
    return (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: https:; "
        "font-src 'self' data:; "
        "connect-src 'self' https:; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self'"
    )
