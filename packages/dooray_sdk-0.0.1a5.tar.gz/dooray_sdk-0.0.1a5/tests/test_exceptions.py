"""Tests for Dooray SDK exception classes.

This module contains comprehensive tests for the exception hierarchy
defined in dooray_sdk.exceptions.
"""

import pytest

from dooray_sdk.exceptions import (
    DooraySDKError,
    DoorayConnectionError,
    DoorayWebSocketError,
    DoorayAuthenticationError,
    DoorayTokenError,
    DoorayConfigurationError,
    DoorayRequestError,
    DoorayTimeoutError,
)


class TestDooraySDKError:
    """Tests for the base DooraySDKError class."""

    def test_basic_creation(self):
        """Test basic exception creation with message only."""
        error = DooraySDKError("Test error message")
        assert error.message == "Test error message"
        assert error.error_code is None
        assert error.context == {}

    def test_with_error_code(self):
        """Test exception creation with error code."""
        error = DooraySDKError("Test error", error_code="ERR001")
        assert error.message == "Test error"
        assert error.error_code == "ERR001"
        assert error.context == {}

    def test_with_context(self):
        """Test exception creation with context dictionary."""
        context = {"user_id": "123", "action": "connect"}
        error = DooraySDKError("Test error", context=context)
        assert error.message == "Test error"
        assert error.error_code is None
        assert error.context == context

    def test_with_all_parameters(self):
        """Test exception creation with all parameters."""
        context = {"key": "value"}
        error = DooraySDKError(
            "Full error",
            error_code="ERR002",
            context=context,
        )
        assert error.message == "Full error"
        assert error.error_code == "ERR002"
        assert error.context == context

    def test_str_message_only(self):
        """Test __str__ output with message only."""
        error = DooraySDKError("Simple message")
        assert str(error) == "Simple message"

    def test_str_with_error_code(self):
        """Test __str__ output with error code."""
        error = DooraySDKError("Error message", error_code="E001")
        assert str(error) == "Error message [E001]"

    def test_str_with_context(self):
        """Test __str__ output with context."""
        error = DooraySDKError("Error message", context={"key": "val"})
        assert str(error) == "Error message (key=val)"

    def test_str_with_all(self):
        """Test __str__ output with all parameters."""
        error = DooraySDKError(
            "Full error",
            error_code="E002",
            context={"a": 1, "b": 2},
        )
        result = str(error)
        assert "Full error" in result
        assert "[E002]" in result
        assert "a=1" in result
        assert "b=2" in result

    def test_exception_inheritance(self):
        """Test that DooraySDKError inherits from Exception."""
        error = DooraySDKError("Test")
        assert isinstance(error, Exception)

    def test_can_be_raised_and_caught(self):
        """Test that exception can be raised and caught."""
        with pytest.raises(DooraySDKError) as exc_info:
            raise DooraySDKError("Raised error", error_code="ERR")
        assert exc_info.value.message == "Raised error"
        assert exc_info.value.error_code == "ERR"


class TestDoorayConnectionError:
    """Tests for DoorayConnectionError."""

    def test_basic_creation(self):
        """Test basic connection error creation."""
        error = DoorayConnectionError("Connection failed")
        assert error.message == "Connection failed"
        assert error.service is None
        assert error.retry_count == 0

    def test_with_service(self):
        """Test connection error with service name."""
        error = DoorayConnectionError("Connection failed", service="messenger")
        assert error.message == "Connection failed"
        assert error.service == "messenger"
        assert error.retry_count == 0

    def test_with_retry_count(self):
        """Test connection error with retry count."""
        error = DoorayConnectionError("Connection failed", retry_count=3)
        assert error.message == "Connection failed"
        assert error.retry_count == 3

    def test_with_all_parameters(self):
        """Test connection error with all parameters."""
        error = DoorayConnectionError(
            "Connection failed",
            service="socket",
            retry_count=5,
            error_code="CONN001",
            context={"endpoint": "wss://example.com"},
        )
        assert error.message == "Connection failed"
        assert error.service == "socket"
        assert error.retry_count == 5
        assert error.error_code == "CONN001"
        assert error.context == {"endpoint": "wss://example.com"}

    def test_inheritance(self):
        """Test that DoorayConnectionError inherits from DooraySDKError."""
        error = DoorayConnectionError("Test")
        assert isinstance(error, DooraySDKError)
        assert isinstance(error, Exception)


class TestDoorayWebSocketError:
    """Tests for DoorayWebSocketError."""

    def test_basic_creation(self):
        """Test basic WebSocket error creation."""
        error = DoorayWebSocketError("WebSocket disconnected")
        assert error.message == "WebSocket disconnected"

    def test_inheritance(self):
        """Test exception hierarchy."""
        error = DoorayWebSocketError("Test")
        assert isinstance(error, DoorayConnectionError)
        assert isinstance(error, DooraySDKError)
        assert isinstance(error, Exception)

    def test_with_connection_attributes(self):
        """Test WebSocket error inherits connection attributes."""
        error = DoorayWebSocketError(
            "WebSocket error",
            service="socket_mode",
            retry_count=2,
        )
        assert error.service == "socket_mode"
        assert error.retry_count == 2


class TestDoorayAuthenticationError:
    """Tests for DoorayAuthenticationError."""

    def test_basic_creation(self):
        """Test basic authentication error creation."""
        error = DoorayAuthenticationError("Invalid credentials")
        assert error.message == "Invalid credentials"

    def test_inheritance(self):
        """Test exception hierarchy."""
        error = DoorayAuthenticationError("Test")
        assert isinstance(error, DooraySDKError)
        assert isinstance(error, Exception)

    def test_with_base_attributes(self):
        """Test authentication error with base attributes."""
        error = DoorayAuthenticationError(
            "Auth failed",
            error_code="AUTH001",
            context={"method": "token"},
        )
        assert error.error_code == "AUTH001"
        assert error.context == {"method": "token"}


class TestDoorayTokenError:
    """Tests for DoorayTokenError."""

    def test_basic_creation(self):
        """Test basic token error creation."""
        error = DoorayTokenError("Token expired")
        assert error.message == "Token expired"
        assert error.token_type is None

    def test_with_token_type(self):
        """Test token error with token type."""
        error = DoorayTokenError("Token invalid", token_type="access_token")
        assert error.message == "Token invalid"
        assert error.token_type == "access_token"

    def test_inheritance(self):
        """Test exception hierarchy."""
        error = DoorayTokenError("Test")
        assert isinstance(error, DoorayAuthenticationError)
        assert isinstance(error, DooraySDKError)
        assert isinstance(error, Exception)

    def test_with_all_attributes(self):
        """Test token error with all attributes."""
        error = DoorayTokenError(
            "Token refresh failed",
            token_type="refresh_token",
            error_code="TOKEN001",
            context={"expires_at": "2024-01-01"},
        )
        assert error.token_type == "refresh_token"
        assert error.error_code == "TOKEN001"


class TestDoorayConfigurationError:
    """Tests for DoorayConfigurationError."""

    def test_basic_creation(self):
        """Test basic configuration error creation."""
        error = DoorayConfigurationError("Missing required config")
        assert error.message == "Missing required config"

    def test_inheritance(self):
        """Test exception hierarchy."""
        error = DoorayConfigurationError("Test")
        assert isinstance(error, DooraySDKError)
        assert isinstance(error, Exception)


class TestDoorayRequestError:
    """Tests for DoorayRequestError."""

    def test_basic_creation(self):
        """Test basic request error creation."""
        error = DoorayRequestError("Request failed")
        assert error.message == "Request failed"
        assert error.status_code is None
        assert error.response_body is None

    def test_with_status_code(self):
        """Test request error with status code."""
        error = DoorayRequestError("Not found", status_code=404)
        assert error.status_code == 404

    def test_with_response_body(self):
        """Test request error with response body."""
        error = DoorayRequestError(
            "Bad request",
            response_body='{"error": "invalid field"}',
        )
        assert error.response_body == '{"error": "invalid field"}'

    def test_with_all_parameters(self):
        """Test request error with all parameters."""
        error = DoorayRequestError(
            "Server error",
            status_code=500,
            response_body="Internal server error",
            error_code="HTTP500",
            context={"endpoint": "/api/v1/messages"},
        )
        assert error.status_code == 500
        assert error.response_body == "Internal server error"
        assert error.error_code == "HTTP500"

    def test_inheritance(self):
        """Test exception hierarchy."""
        error = DoorayRequestError("Test")
        assert isinstance(error, DooraySDKError)
        assert isinstance(error, Exception)


class TestDoorayTimeoutError:
    """Tests for DoorayTimeoutError."""

    def test_basic_creation(self):
        """Test basic timeout error creation."""
        error = DoorayTimeoutError("Connection timeout")
        assert error.message == "Connection timeout"

    def test_inheritance(self):
        """Test exception hierarchy."""
        error = DoorayTimeoutError("Test")
        assert isinstance(error, DooraySDKError)
        assert isinstance(error, Exception)

    def test_with_context(self):
        """Test timeout error with context."""
        error = DoorayTimeoutError(
            "Request timeout",
            error_code="TIMEOUT",
            context={"timeout_seconds": 30},
        )
        assert error.error_code == "TIMEOUT"
        assert error.context == {"timeout_seconds": 30}


class TestExceptionHierarchy:
    """Tests for the exception class hierarchy relationships."""

    def test_all_inherit_from_base(self):
        """Test all exceptions inherit from DooraySDKError."""
        exceptions = [
            DoorayConnectionError("test"),
            DoorayWebSocketError("test"),
            DoorayAuthenticationError("test"),
            DoorayTokenError("test"),
            DoorayConfigurationError("test"),
            DoorayRequestError("test"),
            DoorayTimeoutError("test"),
        ]
        for exc in exceptions:
            assert isinstance(exc, DooraySDKError)
            assert isinstance(exc, Exception)

    def test_websocket_is_connection_error(self):
        """Test DoorayWebSocketError is a DoorayConnectionError."""
        assert issubclass(DoorayWebSocketError, DoorayConnectionError)

    def test_token_is_authentication_error(self):
        """Test DoorayTokenError is a DoorayAuthenticationError."""
        assert issubclass(DoorayTokenError, DoorayAuthenticationError)

    def test_catch_all_sdk_errors(self):
        """Test catching all SDK errors with base class."""
        errors = [
            DoorayConnectionError("conn"),
            DoorayWebSocketError("ws"),
            DoorayAuthenticationError("auth"),
            DoorayTokenError("token"),
            DoorayConfigurationError("config"),
            DoorayRequestError("request"),
            DoorayTimeoutError("timeout"),
        ]

        for error in errors:
            try:
                raise error
            except DooraySDKError as e:
                assert e.message is not None
            except Exception:
                pytest.fail(f"Expected DooraySDKError, got different exception")

    def test_catch_connection_errors_specifically(self):
        """Test catching connection errors specifically."""
        # WebSocket error should be caught as connection error
        with pytest.raises(DoorayConnectionError):
            raise DoorayWebSocketError("WebSocket failed")

    def test_catch_auth_errors_specifically(self):
        """Test catching authentication errors specifically."""
        # Token error should be caught as authentication error
        with pytest.raises(DoorayAuthenticationError):
            raise DoorayTokenError("Token invalid")


class TestExceptionImports:
    """Tests for exception imports from dooray_sdk."""

    def test_import_from_dooray_sdk(self):
        """Test exceptions can be imported from dooray_sdk package."""
        from dooray_sdk import (
            DooraySDKError,
            DoorayConnectionError,
            DoorayWebSocketError,
            DoorayAuthenticationError,
            DoorayTokenError,
            DoorayConfigurationError,
            DoorayRequestError,
            DoorayTimeoutError,
        )

        # Verify they are the correct types
        assert DooraySDKError.__name__ == "DooraySDKError"
        assert DoorayConnectionError.__name__ == "DoorayConnectionError"
        assert DoorayWebSocketError.__name__ == "DoorayWebSocketError"
        assert DoorayAuthenticationError.__name__ == "DoorayAuthenticationError"
        assert DoorayTokenError.__name__ == "DoorayTokenError"
        assert DoorayConfigurationError.__name__ == "DoorayConfigurationError"
        assert DoorayRequestError.__name__ == "DoorayRequestError"
        assert DoorayTimeoutError.__name__ == "DoorayTimeoutError"

    def test_exceptions_in_all(self):
        """Test exceptions are in __all__ list."""
        import dooray_sdk

        expected_exceptions = [
            "DooraySDKError",
            "DoorayConnectionError",
            "DoorayWebSocketError",
            "DoorayAuthenticationError",
            "DoorayTokenError",
            "DoorayConfigurationError",
            "DoorayRequestError",
            "DoorayTimeoutError",
        ]
        for exc_name in expected_exceptions:
            assert exc_name in dooray_sdk.__all__


class TestAgentConfigurationValidation:
    """Tests for Agent configuration validation using DoorayConfigurationError."""

    def test_agent_missing_token_raises_configuration_error(self, monkeypatch):
        """Test that missing token raises DoorayConfigurationError."""
        # Clear environment variables
        monkeypatch.delenv("DOORAY_AGENT_TOKEN", raising=False)
        monkeypatch.delenv("DOORAY_BOT_TOKEN", raising=False)
        monkeypatch.setenv("DOORAY_DOMAIN", "company.dooray.com")

        from dooray_sdk import Agent

        with pytest.raises(DoorayConfigurationError) as exc_info:
            Agent()
        assert exc_info.value.error_code == "MISSING_TOKEN"
        assert "token" in exc_info.value.message.lower() or "토큰" in exc_info.value.message

    def test_agent_missing_domain_raises_configuration_error(self, monkeypatch):
        """Test that missing domain raises DoorayConfigurationError."""
        monkeypatch.setenv("DOORAY_AGENT_TOKEN", "test_token")
        monkeypatch.delenv("DOORAY_DOMAIN", raising=False)

        from dooray_sdk import Agent

        with pytest.raises(DoorayConfigurationError) as exc_info:
            Agent()
        assert exc_info.value.error_code == "MISSING_DOMAIN"
        assert "domain" in exc_info.value.message.lower() or "도메인" in exc_info.value.message

    def test_agent_empty_token_raises_configuration_error(self, monkeypatch):
        """Test that empty token raises DoorayConfigurationError."""
        monkeypatch.setenv("DOORAY_DOMAIN", "company.dooray.com")

        from dooray_sdk import Agent

        with pytest.raises(DoorayConfigurationError) as exc_info:
            Agent(token="   ")
        assert exc_info.value.error_code == "MISSING_TOKEN"

    def test_agent_empty_domain_raises_configuration_error(self, monkeypatch):
        """Test that empty domain raises DoorayConfigurationError."""
        monkeypatch.setenv("DOORAY_AGENT_TOKEN", "test_token")

        from dooray_sdk import Agent

        with pytest.raises(DoorayConfigurationError) as exc_info:
            Agent(domain="   ")
        assert exc_info.value.error_code == "MISSING_DOMAIN"

    def test_agent_domain_with_spaces_raises_configuration_error(self, monkeypatch):
        """Test that domain with spaces raises DoorayConfigurationError."""
        monkeypatch.setenv("DOORAY_AGENT_TOKEN", "test_token")

        from dooray_sdk import Agent

        with pytest.raises(DoorayConfigurationError) as exc_info:
            Agent(domain="company dooray.com")
        assert exc_info.value.error_code == "INVALID_DOMAIN"
        assert "domain" in exc_info.value.context

    def test_agent_domain_with_protocol_raises_configuration_error(self, monkeypatch):
        """Test that domain with protocol raises DoorayConfigurationError."""
        monkeypatch.setenv("DOORAY_AGENT_TOKEN", "test_token")

        from dooray_sdk import Agent

        with pytest.raises(DoorayConfigurationError) as exc_info:
            Agent(domain="https://company.dooray.com")
        assert exc_info.value.error_code == "INVALID_DOMAIN"
        assert "https://" in exc_info.value.message or "프로토콜" in exc_info.value.message

    def test_agent_domain_with_http_raises_configuration_error(self, monkeypatch):
        """Test that domain with http:// raises DoorayConfigurationError."""
        monkeypatch.setenv("DOORAY_AGENT_TOKEN", "test_token")

        from dooray_sdk import Agent

        with pytest.raises(DoorayConfigurationError) as exc_info:
            Agent(domain="http://company.dooray.com")
        assert exc_info.value.error_code == "INVALID_DOMAIN"


class TestTokenParsingValidation:
    """Tests for token parsing validation using DoorayTokenError."""

    def test_parse_socket_mode_token_missing_access_token(self):
        """Test that missing access token raises DoorayTokenError."""
        from dooray_sdk.web.token import parse_socket_mode_token_response

        response = {
            "result": {
                "tenantId": "tenant123",
                "organizationMemberId": "member456",
            }
        }

        with pytest.raises(DoorayTokenError) as exc_info:
            parse_socket_mode_token_response(response)
        assert exc_info.value.token_type == "socket_mode"
        assert exc_info.value.error_code == "INVALID_TOKEN_RESPONSE"
        assert "accessToken" in exc_info.value.message

    def test_parse_socket_mode_token_missing_tenant_id(self):
        """Test that missing tenant ID raises DoorayTokenError."""
        from dooray_sdk.web.token import parse_socket_mode_token_response

        response = {
            "result": {
                "accessToken": "token123",
                "organizationMemberId": "member456",
            }
        }

        with pytest.raises(DoorayTokenError) as exc_info:
            parse_socket_mode_token_response(response)
        assert exc_info.value.token_type == "socket_mode"
        assert exc_info.value.error_code == "INVALID_TOKEN_RESPONSE"
        assert "tenantId" in exc_info.value.message

    def test_parse_socket_mode_token_missing_member_id(self):
        """Test that missing member ID raises DoorayTokenError."""
        from dooray_sdk.web.token import parse_socket_mode_token_response

        response = {
            "result": {
                "accessToken": "token123",
                "tenantId": "tenant123",
            }
        }

        with pytest.raises(DoorayTokenError) as exc_info:
            parse_socket_mode_token_response(response)
        assert exc_info.value.token_type == "socket_mode"
        assert exc_info.value.error_code == "INVALID_TOKEN_RESPONSE"
        assert "organizationMemberId" in exc_info.value.message

    def test_parse_socket_mode_token_empty_result(self):
        """Test that empty result raises DoorayTokenError."""
        from dooray_sdk.web.token import parse_socket_mode_token_response

        response = {"result": {}}

        with pytest.raises(DoorayTokenError) as exc_info:
            parse_socket_mode_token_response(response)
        assert exc_info.value.token_type == "socket_mode"
        assert exc_info.value.error_code == "INVALID_TOKEN_RESPONSE"

    def test_parse_socket_mode_token_success(self):
        """Test successful token parsing."""
        from dooray_sdk.web.token import parse_socket_mode_token_response

        response = {
            "result": {
                "accessToken": "token123",
                "tenantId": "tenant123",
                "organizationMemberId": "member456",
            }
        }

        result = parse_socket_mode_token_response(response)
        assert result["accessToken"] == "token123"
        assert result["tenantId"] == "tenant123"
        assert result["organizationMemberId"] == "member456"


class TestWebClientHttpErrorHandling:
    """Tests for WebClient HTTP error handling using DoorayRequestError."""

    def test_sync_client_http_404_raises_request_error(self):
        """Test that 404 error raises DoorayRequestError."""
        from unittest.mock import Mock, patch
        from dooray_sdk.web import WebClient

        mock_response = Mock()
        mock_response.status_code = 404
        mock_response.reason = "Not Found"
        mock_response.text = '{"error": "resource not found"}'
        mock_response.raise_for_status.side_effect = __import__('requests').HTTPError()

        with patch('dooray_sdk.web.client.requests.Session.request', return_value=mock_response):
            client = WebClient(token="test_token")

            with pytest.raises(DoorayRequestError) as exc_info:
                client.get("/v1/not-found")

            assert exc_info.value.status_code == 404
            assert exc_info.value.error_code == "CLIENT_ERROR"
            assert exc_info.value.response_body == '{"error": "resource not found"}'
            assert "url" in exc_info.value.context
            assert "method" in exc_info.value.context

    def test_sync_client_http_500_raises_request_error(self):
        """Test that 500 error raises DoorayRequestError with SERVER_ERROR code."""
        from unittest.mock import Mock, patch
        from dooray_sdk.web import WebClient

        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.reason = "Internal Server Error"
        mock_response.text = "Server error"
        mock_response.raise_for_status.side_effect = __import__('requests').HTTPError()

        with patch('dooray_sdk.web.client.requests.Session.request', return_value=mock_response):
            client = WebClient(token="test_token")

            with pytest.raises(DoorayRequestError) as exc_info:
                client.get("/v1/error")

            assert exc_info.value.status_code == 500
            assert exc_info.value.error_code == "SERVER_ERROR"

    def test_sync_client_network_error_raises_request_error(self):
        """Test that network error raises DoorayRequestError."""
        from unittest.mock import patch
        import requests
        from dooray_sdk.web import WebClient

        with patch('dooray_sdk.web.client.requests.Session.request') as mock_request:
            mock_request.side_effect = requests.ConnectionError("Connection refused")

            client = WebClient(token="test_token")

            with pytest.raises(DoorayRequestError) as exc_info:
                client.get("/v1/endpoint")

            assert exc_info.value.error_code == "NETWORK_ERROR"
            assert "Connection refused" in exc_info.value.message or "Network error" in exc_info.value.message


class TestAsyncWebClientHttpErrorHandling:
    """Tests for AsyncWebClient HTTP error handling using DoorayRequestError."""

    def test_async_client_http_404_raises_request_error(self):
        """Test that 404 error raises DoorayRequestError."""
        import asyncio
        from unittest.mock import AsyncMock, MagicMock, patch
        import aiohttp
        from dooray_sdk.web import AsyncWebClient

        async def run_test():
            # Create a mock response
            mock_response = MagicMock()
            mock_response.status = 404
            mock_response.text = AsyncMock(return_value='{"error": "not found"}')
            mock_response.json = AsyncMock(return_value={"error": "not found"})

            # Make raise_for_status raise ClientResponseError
            error = aiohttp.ClientResponseError(
                request_info=MagicMock(),
                history=(),
                status=404,
                message="Not Found",
            )
            mock_response.raise_for_status.side_effect = error

            # Mock the context manager
            mock_cm = MagicMock()
            mock_cm.__aenter__ = AsyncMock(return_value=mock_response)
            mock_cm.__aexit__ = AsyncMock(return_value=False)

            with patch.object(aiohttp.ClientSession, 'request', return_value=mock_cm):
                client = AsyncWebClient(token="test_token")
                client.session = aiohttp.ClientSession()

                try:
                    with pytest.raises(DoorayRequestError) as exc_info:
                        await client._request("GET", "/v1/not-found")

                    assert exc_info.value.status_code == 404
                    assert exc_info.value.error_code == "CLIENT_ERROR"
                    assert exc_info.value.response_body == '{"error": "not found"}'
                finally:
                    await client.session.close()

        asyncio.run(run_test())

    def test_async_client_http_500_raises_request_error(self):
        """Test that 500 error raises DoorayRequestError with SERVER_ERROR code."""
        import asyncio
        from unittest.mock import AsyncMock, MagicMock, patch
        import aiohttp
        from dooray_sdk.web import AsyncWebClient

        async def run_test():
            mock_response = MagicMock()
            mock_response.status = 500
            mock_response.text = AsyncMock(return_value="Internal Server Error")
            mock_response.json = AsyncMock(return_value={})

            error = aiohttp.ClientResponseError(
                request_info=MagicMock(),
                history=(),
                status=500,
                message="Internal Server Error",
            )
            mock_response.raise_for_status.side_effect = error

            mock_cm = MagicMock()
            mock_cm.__aenter__ = AsyncMock(return_value=mock_response)
            mock_cm.__aexit__ = AsyncMock(return_value=False)

            with patch.object(aiohttp.ClientSession, 'request', return_value=mock_cm):
                client = AsyncWebClient(token="test_token")
                client.session = aiohttp.ClientSession()

                try:
                    with pytest.raises(DoorayRequestError) as exc_info:
                        await client._request("GET", "/v1/error")

                    assert exc_info.value.status_code == 500
                    assert exc_info.value.error_code == "SERVER_ERROR"
                finally:
                    await client.session.close()

        asyncio.run(run_test())


class TestExceptionChaining:
    """Tests for exception chaining (from e syntax)."""

    def test_sync_client_exception_chaining(self):
        """Test that exception chaining preserves original exception."""
        from unittest.mock import Mock, patch
        import requests
        from dooray_sdk.web import WebClient

        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.reason = "Unauthorized"
        mock_response.text = "Invalid token"
        original_error = requests.HTTPError("401 Unauthorized")
        mock_response.raise_for_status.side_effect = original_error

        with patch('dooray_sdk.web.client.requests.Session.request', return_value=mock_response):
            client = WebClient(token="test_token")

            with pytest.raises(DoorayRequestError) as exc_info:
                client.get("/v1/endpoint")

            # Verify exception chaining
            assert exc_info.value.__cause__ is original_error
