"""
Tests for Socket Mode WebSocket 자동 재연결 정책 (#dooray-통합/11609).

PRD Functional Requirements:
 1) 자동 재연결 — exp backoff + jitter, 무한 재시도 (1008 외)
 2) stale 감지 — pong timeout 초과 시 강제 close → 재연결
 3) auto_reconnect_enabled 옵션 (default True)
 4) fail-fast (auto_reconnect_enabled=False)에서 task 종료 + 메인 코루틴 종료
 5) on_disconnect / on_reconnect hook (sync/async, 예외 격리)
 6) 1008 STANDBY 회귀 없음, disconnect() 의도적 종료 회귀 없음

PRD Success Metrics (6개 pytest 시나리오):
 a) 네트워크 단절 → backoff → 재연결 성공
 b) 서버측 일반 close(1000/1001) → 재연결 성공
 c) 1008 STANDBY 회귀 없음
 d) pong timeout → 강제 재연결
 e) auto_reconnect_enabled=False → task 종료 + 메인 코루틴 종료
 f) backoff sequence (exp + jitter) 검증

Out of scope: 외부 Dooray 서비스 의존 — 모두 mock.
"""

import asyncio
import sys
import pytest
from unittest.mock import AsyncMock, MagicMock, patch


def _run_async(coro):
    """pytest-asyncio 없이 비동기 테스트를 실행하는 헬퍼."""
    return asyncio.run(coro)


def _make_async_client(**overrides):
    """테스트용 비동기 SocketModeClient 인스턴스 생성."""
    from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient

    web_client = AsyncMock()
    kwargs = dict(
        web_client=web_client,
        domain="test.dooray.com",
    )
    kwargs.update(overrides)
    client = SocketModeClient(**kwargs)
    client._fetch_socket_mode_token = AsyncMock()
    return client


class TestStandbyPolicy:
    """Active-Standby HA 재연결 정책 테스트."""

    def test_session_limit_close_enters_standby_and_retries(self):
        """1008/AGENT_ALREADY_CONNECTED close 시 STANDBY로 재시도해야 함."""
        from dooray_sdk.socket_mode.aiohttp.client import (
            ConnectionState,
            SESSION_LIMIT_CLOSE_CODE,
            SESSION_LIMIT_CLOSE_REASON,
        )

        # auto_reconnect=False로 두 번째 close에서 즉시 종료시켜 테스트 단순화.
        # 1008 STANDBY 동작 자체는 auto_reconnect 옵션과 무관하다.
        client = _make_async_client(auto_reconnect_enabled=False)

        connect_calls = 0
        observed_states = []

        async def fake_connect():
            # 실제 _connect_websocket은 handshake만 하고 ACTIVE 전이는
            # sessionInfo 수신 시점까지 미룬다. 여기서도 동일하게 모사.
            nonlocal connect_calls
            connect_calls += 1
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = None
            client.connected = True

        async def fake_handle_messages():
            # 첫 번째 호출에서 세션 중복 close 시뮬레이션 → STANDBY로 진입
            # 두 번째 호출에서 일반 close (auto_reconnect=False라 종료)
            if connect_calls == 1:
                client._last_close_code = SESSION_LIMIT_CLOSE_CODE
                client._last_close_reason = SESSION_LIMIT_CLOSE_REASON
            else:
                client._last_close_code = 1000
                client._last_close_reason = "normal"

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        # 상태 변화 관찰
        original_set_state = client._set_state

        def tracking_set_state(new_state):
            observed_states.append(new_state)
            original_set_state(new_state)

        client._set_state = tracking_set_state

        with patch("asyncio.sleep", new_callable=AsyncMock):
            _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert connect_calls == 2  # 첫 연결 + 재연결
        assert ConnectionState.STANDBY in observed_states
        # 두 번째 일반 close에서 DISCONNECTED로 종료
        assert observed_states[-1] == ConnectionState.DISCONNECTED
        # standby 루프에서는 토큰을 재발급하지 않는다 (만료 시 _connect_websocket에서만 refresh)
        client._fetch_socket_mode_token.assert_not_called()

    def test_generic_close_terminates_when_auto_reconnect_disabled(self):
        """auto_reconnect_enabled=False일 때 일반 close(1000)에서 루프 탈출."""
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client(auto_reconnect_enabled=False)

        connect_calls = 0

        async def fake_connect():
            nonlocal connect_calls
            connect_calls += 1
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = 1000
            client.connected = True

        async def fake_handle_messages():
            client._last_close_code = 1000
            client._last_close_reason = "normal closure"

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert connect_calls == 1
        assert client.state == ConnectionState.DISCONNECTED
        client._fetch_socket_mode_token.assert_not_called()

    def test_connect_exception_terminates_when_auto_reconnect_disabled(self):
        """auto_reconnect_enabled=False일 때 connect 예외 시 재시도 없이 종료."""
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client(auto_reconnect_enabled=False)

        connect_calls = 0

        async def fake_connect():
            nonlocal connect_calls
            connect_calls += 1
            raise ConnectionError("network error")

        client._connect_websocket = fake_connect
        client._handle_messages = AsyncMock()

        _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert connect_calls == 1  # 재시도 없음
        assert client.state == ConnectionState.DISCONNECTED
        client._fetch_socket_mode_token.assert_not_called()

    def test_standby_wait_uses_fixed_interval(self):
        """STANDBY 재시도는 고정 간격(STANDBY_RETRY_INTERVAL)을 사용해야 함."""
        from dooray_sdk.socket_mode.aiohttp.client import (
            ConnectionState,
            STANDBY_RETRY_INTERVAL,
        )

        client = _make_async_client()

        sleep_delays = []

        async def capture_sleep(delay):
            sleep_delays.append(delay)

        with patch("asyncio.sleep", side_effect=capture_sleep):
            _run_async(client._handle_standby())

        assert sleep_delays == [STANDBY_RETRY_INTERVAL]
        assert client.state == ConnectionState.STANDBY

    def test_is_session_limit_close_matches_exact_signal(self):
        """close code+reason이 정확히 일치할 때만 세션 중복으로 판정해야 함."""
        from dooray_sdk.socket_mode.aiohttp.client import (
            SESSION_LIMIT_CLOSE_CODE,
            SESSION_LIMIT_CLOSE_REASON,
        )

        client = _make_async_client()

        client._last_close_code = SESSION_LIMIT_CLOSE_CODE
        client._last_close_reason = SESSION_LIMIT_CLOSE_REASON
        assert client._is_session_limit_close() is True

        # code만 일치, reason 다름
        client._last_close_reason = "other"
        assert client._is_session_limit_close() is False

        # reason만 일치, code 다름
        client._last_close_code = 1000
        client._last_close_reason = SESSION_LIMIT_CLOSE_REASON
        assert client._is_session_limit_close() is False

    def test_handshake_401_triggers_token_refresh_and_retry(self):
        """handshake 401(토큰 만료) 시 토큰 refresh 후 1회 재시도해야 함."""
        import aiohttp

        client = _make_async_client()
        client._access_token = "stale"
        client._tenant_id = "tid"
        client._member_id = "mid"
        client.session = MagicMock()

        call_count = 0
        fresh_ws = MagicMock()

        async def fake_ws_connect(url, headers):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise aiohttp.WSServerHandshakeError(
                    request_info=MagicMock(),
                    history=(),
                    status=401,
                    message="Unauthorized",
                )
            return fresh_ws

        client.session.ws_connect = fake_ws_connect

        _run_async(client._connect_websocket())

        assert call_count == 2
        client._fetch_socket_mode_token.assert_called_once()
        assert client.ws is fresh_ws
        assert client.connected is True

    def test_handshake_non_401_error_is_not_retried(self):
        """401이 아닌 handshake 오류는 재시도 없이 상위로 전파되어야 함."""
        import aiohttp

        client = _make_async_client()
        client._access_token = "t"
        client._tenant_id = "tid"
        client._member_id = "mid"
        client.session = MagicMock()

        call_count = 0

        async def fake_ws_connect(url, headers):
            nonlocal call_count
            call_count += 1
            raise aiohttp.WSServerHandshakeError(
                request_info=MagicMock(),
                history=(),
                status=500,
                message="Server Error",
            )

        client.session.ws_connect = fake_ws_connect

        with pytest.raises(aiohttp.WSServerHandshakeError):
            _run_async(client._connect_websocket())

        assert call_count == 1
        client._fetch_socket_mode_token.assert_not_called()

    def test_session_info_message_transitions_to_active(self):
        """sessionInfo 메시지 수신 시 CONNECTING → ACTIVE로 전이해야 함."""
        import json
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client()
        client.state = ConnectionState.CONNECTING

        session_info_msg = json.dumps(
            {"type": "sessionInfo", "payload": {"sessionId": "abc"}}
        )
        _run_async(client._on_message(session_info_msg))

        assert client.state == ConnectionState.ACTIVE

    def test_is_connected_only_true_in_active_state(self):
        """is_connected()는 ACTIVE 상태에서만 True여야 함."""
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client()
        client.ws = MagicMock()

        client.state = ConnectionState.STANDBY
        assert client.is_connected() is False

        client.state = ConnectionState.ACTIVE
        assert client.is_connected() is True


class TestAutoReconnect:
    """
    PRD #dooray-통합/11609 — Socket Mode 자동 재연결.

    각 테스트는 PRD Success Metrics 6개 시나리오 중 하나에 매핑된다.
    """

    def test_network_error_triggers_backoff_and_reconnect(self):
        """(a) 네트워크 단절 → backoff → 재연결 성공."""
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client(
            auto_reconnect_enabled=True,
            reconnect_initial_delay=0.01,
            reconnect_max_delay=0.01,
            reconnect_jitter_ratio=0,
        )

        connect_calls = 0

        async def fake_connect():
            nonlocal connect_calls
            connect_calls += 1
            if connect_calls == 1:
                # 첫 시도: 네트워크 단절 (transport-level 오류).
                raise ConnectionError("transport reset")
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = None
            client.connected = True

        async def fake_handle_messages():
            # 두 번째 시도는 ACTIVE 후 곧바로 의도적 disconnect로 루프 탈출시킨다.
            client._set_state(ConnectionState.DISCONNECTED)

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert connect_calls == 2  # 1회 실패 → 1회 성공
        assert client.state == ConnectionState.DISCONNECTED

    def test_normal_close_1000_triggers_reconnect(self):
        """(b) 서버측 일반 close(1000) → 재연결 성공."""
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client(
            auto_reconnect_enabled=True,
            reconnect_initial_delay=0.01,
            reconnect_jitter_ratio=0,
        )

        connect_calls = 0

        async def fake_connect():
            nonlocal connect_calls
            connect_calls += 1
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = 1000
            client.connected = True

        async def fake_handle_messages():
            if connect_calls == 1:
                client._last_close_code = 1000
                client._last_close_reason = "normal closure"
            else:
                # 두 번째 시도가 들어왔다는 것 자체를 검증하고 루프 탈출.
                client._set_state(ConnectionState.DISCONNECTED)

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert connect_calls == 2
        assert client.state == ConnectionState.DISCONNECTED

    def test_1008_standby_regression_guard(self):
        """(c) 1008 STANDBY 동작은 auto_reconnect_enabled 값과 무관하게 유지."""
        from dooray_sdk.socket_mode.aiohttp.client import (
            ConnectionState,
            SESSION_LIMIT_CLOSE_CODE,
            SESSION_LIMIT_CLOSE_REASON,
        )

        # auto_reconnect_enabled=False여도 1008은 항상 STANDBY 사이클.
        client = _make_async_client(auto_reconnect_enabled=False)

        connect_calls = 0
        observed_states = []

        async def fake_connect():
            nonlocal connect_calls
            connect_calls += 1
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = None
            client.connected = True

        async def fake_handle_messages():
            if connect_calls == 1:
                client._last_close_code = SESSION_LIMIT_CLOSE_CODE
                client._last_close_reason = SESSION_LIMIT_CLOSE_REASON
            else:
                # 두 번째 시도 → 의도적 종료.
                client._set_state(ConnectionState.DISCONNECTED)

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        original_set_state = client._set_state

        def tracking_set_state(new_state):
            observed_states.append(new_state)
            original_set_state(new_state)

        client._set_state = tracking_set_state

        with patch("asyncio.sleep", new_callable=AsyncMock):
            _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        # auto_reconnect_enabled=False여도 1008은 STANDBY를 거쳐 재시도해야 함.
        assert ConnectionState.STANDBY in observed_states
        assert connect_calls == 2

    def test_pong_timeout_force_closes_stale_websocket(self):
        """(d) pong timeout 초과 시 _ping_loop이 ws.close()를 강제 호출."""
        import time as time_mod

        client = _make_async_client(
            ping_interval=0,  # 즉시 ping 분기로 진입
            pong_timeout=0.01,
        )

        close_calls = []
        ws_mock = MagicMock()

        async def close():
            close_calls.append(True)

        async def send_str(payload):
            raise AssertionError(
                "stale 상태에서는 ping을 송신하기 전에 close가 호출되어야 함"
            )

        ws_mock.close = close
        ws_mock.send_str = send_str
        client.ws = ws_mock
        client.connected = True
        # 충분히 오래 전 inbound → stale 판정.
        client._last_inbound_at = time_mod.monotonic() - 10.0

        # _ping_loop은 break로 자연 종료되어야 한다 (CancelledError 없이).
        _run_async(asyncio.wait_for(client._ping_loop(), timeout=2.0))

        assert close_calls == [True]

    def test_fail_fast_when_auto_reconnect_disabled_propagates_to_agent(self):
        """(e) auto_reconnect_enabled=False → task 종료가 Agent._run_forever를 깨운다."""

        # _run_websocket이 1회 close 후 종료한다는 것은 위에서 검증됨.
        # 여기서는 Agent._run_forever가 task 종료를 감지하는 동작만 mock으로 검증.
        from dooray_sdk import agent as agent_mod

        ag = agent_mod.Agent(
            token="t",
            domain="test.dooray.com",
            auto_reconnect_enabled=False,
        )

        async def _scenario():
            ag._loop = asyncio.get_running_loop()
            ag._executor = MagicMock()
            ag._executor.shutdown = MagicMock()

            disconnect_called = []

            class FakeCM:
                def all_tasks(self_inner):
                    return [self_inner._task]

                async def disconnect_all(self_inner):
                    disconnect_called.append(True)

            cm = FakeCM()
            # 짧게 끝나는 task — fail-fast 시뮬레이션.
            async def short_task():
                await asyncio.sleep(0.01)
                return "done"

            cm._task = asyncio.create_task(short_task())
            ag._connection_manager = cm

            await asyncio.wait_for(ag._run_forever(), timeout=2.0)
            assert disconnect_called == [True]

        _run_async(_scenario())

    def test_backoff_sequence_is_exponential_with_cap(self):
        """(f) backoff sequence: jitter=0이면 결정적 exp 시퀀스, max_delay에서 cap."""
        client = _make_async_client(
            reconnect_initial_delay=1.0,
            reconnect_max_delay=8.0,
            reconnect_backoff_multiplier=2.0,
            reconnect_jitter_ratio=0,  # 결정적 검증
        )

        delays = [client._compute_backoff_delay(i) for i in range(1, 7)]
        # 1, 2, 4, 8, 8(cap), 8(cap)
        assert delays == [1.0, 2.0, 4.0, 8.0, 8.0, 8.0]

    def test_backoff_with_jitter_stays_within_bounds(self):
        """jitter>0이면 [base, base*(1+ratio)] 범위 내, max_delay 초과 금지."""
        client = _make_async_client(
            reconnect_initial_delay=1.0,
            reconnect_max_delay=4.0,
            reconnect_backoff_multiplier=2.0,
            reconnect_jitter_ratio=0.5,
        )
        # 충분히 많이 샘플링해 확률적 검증.
        for attempt in range(1, 10):
            for _ in range(20):
                d = client._compute_backoff_delay(attempt)
                assert d >= 0
                assert d <= client.reconnect_max_delay + 1e-9

    def test_on_disconnect_hook_invoked_with_close_info(self):
        """(5) on_disconnect 콜백 호출 + info dict에 close_code/reason 포함."""

        client = _make_async_client(
            auto_reconnect_enabled=False,  # 1회 close 후 종료해 검증 단순화
        )

        captured = []

        def on_disc(c, info):
            captured.append(info)

        client.on_disconnect(on_disc)

        async def fake_connect():
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = 1000
            client.connected = True

        async def fake_handle_messages():
            client._last_close_code = 1000
            client._last_close_reason = "bye"

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert len(captured) == 1
        assert captured[0]["close_code"] == 1000
        assert captured[0]["close_reason"] == "bye"

    def test_on_reconnect_hook_invoked_with_delay(self):
        """on_reconnect 콜백이 attempt/delay 정보와 함께 호출되어야 함."""
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client(
            auto_reconnect_enabled=True,
            reconnect_initial_delay=0.01,
            reconnect_jitter_ratio=0,
        )

        captured = []

        async def on_reconn(c, info):
            captured.append(info)

        client.on_reconnect(on_reconn)

        connect_calls = 0

        async def fake_connect():
            nonlocal connect_calls
            connect_calls += 1
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = 1001
            client.connected = True

        async def fake_handle_messages():
            if connect_calls == 1:
                client._last_close_code = 1001
                client._last_close_reason = "going away"
            else:
                client._set_state(ConnectionState.DISCONNECTED)

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert len(captured) == 1
        assert captured[0]["attempt"] == 1
        assert captured[0]["close_code"] == 1001
        assert captured[0]["delay"] > 0

    def test_hook_exception_does_not_break_reconnect_loop(self):
        """(FR-5) hook 콜백 예외는 격리되어 재연결 루프를 깨뜨리지 않아야 함."""
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client(
            auto_reconnect_enabled=True,
            reconnect_initial_delay=0.01,
            reconnect_jitter_ratio=0,
        )

        def bad_hook(c, info):
            raise RuntimeError("hook intentionally raises")

        async def bad_async_hook(c, info):
            raise RuntimeError("async hook intentionally raises")

        client.on_disconnect(bad_hook)
        client.on_reconnect(bad_async_hook)

        connect_calls = 0

        async def fake_connect():
            nonlocal connect_calls
            connect_calls += 1
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = 1000
            client.connected = True

        async def fake_handle_messages():
            if connect_calls == 1:
                client._last_close_code = 1000
                client._last_close_reason = "x"
            else:
                client._set_state(ConnectionState.DISCONNECTED)

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        # 예외가 격리되지 않으면 _run_websocket이 예외 전파 → asyncio.wait_for가 raise.
        _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert connect_calls == 2  # 재연결 1회 성사
        assert client.state == ConnectionState.DISCONNECTED

    def test_disconnect_intentional_termination_no_regression(self):
        """(6) disconnect()로 state=DISCONNECTED가 되면 auto_reconnect=True여도 즉시 종료."""
        from dooray_sdk.socket_mode.aiohttp.client import ConnectionState

        client = _make_async_client(
            auto_reconnect_enabled=True,
            reconnect_initial_delay=0.01,
            reconnect_jitter_ratio=0,
        )

        connect_calls = 0

        async def fake_connect():
            nonlocal connect_calls
            connect_calls += 1
            client.ws = MagicMock()
            client.ws.close = AsyncMock()
            client.ws.close_code = None
            client.connected = True

        async def fake_handle_messages():
            # disconnect()가 호출된 것처럼 state 전이.
            client._set_state(ConnectionState.DISCONNECTED)

        client._connect_websocket = fake_connect
        client._handle_messages = fake_handle_messages

        _run_async(asyncio.wait_for(client._run_websocket(), timeout=5.0))

        assert connect_calls == 1  # 재시도 없이 즉시 종료
        assert client.state == ConnectionState.DISCONNECTED

    def test_successful_session_info_resets_reconnect_attempt(self):
        """sessionInfo 수신(ACTIVE 전이) 시 reconnect_attempt 카운터가 0으로 리셋."""
        import json

        client = _make_async_client()
        client._reconnect_attempt = 5

        _run_async(client._on_message(json.dumps({"type": "sessionInfo", "payload": {}})))

        assert client._reconnect_attempt == 0


class TestSyncHandleReconnect:
    """동기 SocketModeClient(레거시)._handle_reconnect() 테스트."""

    @pytest.fixture(autouse=True)
    def mock_websocket_module(self):
        """websocket 모듈이 설치되지 않은 환경에서도 테스트 가능하도록 mock."""
        mock_ws = MagicMock()
        with patch.dict(sys.modules, {"websocket": mock_ws}):
            yield mock_ws

    def _make_client(self, max_attempts=3):
        """테스트용 동기 SocketModeClient 인스턴스 생성."""
        import importlib
        import warnings

        # websocket mock이 적용된 상태에서 모듈 리로드
        import dooray_sdk.socket_mode.client as client_mod
        importlib.reload(client_mod)
        SocketModeClient = client_mod.SocketModeClient

        from dooray_sdk.web.client import WebClient

        web_client = MagicMock(spec=WebClient)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            client = SocketModeClient(
                web_client=web_client,
                domain="test.dooray.com",
            )
        client.max_connection_attempts = max_attempts
        client.reconnect_delay = 0
        client._fetch_socket_mode_token = MagicMock()
        return client

    # 동기 SocketModeClient는 #dooray-통합/11260 시점에 "무한 재시도"로 변경됨
    # (커밋 13e83bc). 본 #dooray-통합/11609 PRD는 aiohttp 클라이언트에 동일한 모델을
    # 적용하면서, 사전에 깨져 있던 동기 클라이언트 테스트를 함께 정리한다.
    # 동기 코드 자체는 본 PR에서 변경하지 않는다.

    def test_handle_reconnect_returns_true_for_infinite_retry(self):
        """_handle_reconnect는 항상 True를 반환(무한 재시도 정책)해야 함."""
        client = self._make_client(max_attempts=3)
        client.connection_attempts = 3

        with patch("time.sleep"):
            result = client._handle_reconnect()

        # 정책 변경 후: 무한 재시도이므로 attempts 한도가 의미를 가지지 않는다.
        assert result is True

    def test_handle_reconnect_increments_attempt_counter(self):
        """재연결 시도 시 connection_attempts 카운터가 증가해야 함."""
        client = self._make_client(max_attempts=5)
        client.connection_attempts = 2

        with patch("time.sleep"):
            client._handle_reconnect()

        assert client.connection_attempts == 3

    def test_handle_reconnect_attempts_token_refresh_each_cycle(self):
        """무한 재시도 정책: 매 재시도마다 토큰 refresh를 시도해야 함."""
        client = self._make_client(max_attempts=3)
        client.connection_attempts = 3

        with patch("time.sleep"):
            client._handle_reconnect()

        client._fetch_socket_mode_token.assert_called_once()
