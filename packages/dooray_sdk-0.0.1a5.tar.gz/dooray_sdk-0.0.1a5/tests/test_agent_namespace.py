"""
Agent 신규 인터페이스 테스트 (PRD 11446 / ADR-001, ADR-002, ADR-004)

검증 대상:
- agent.messenger.<verb> 가 호출 가능 + 위임 동작 (ADR-001 듀얼 객체)
- (req, client) 시그니처 핸들러가 호출되는지 + (req) 단일 인자도 여전히 동작 (ADR-002)
- @agent.messenger 데코레이터(구독) 사용 시 DeprecationWarning 발생 + 핸들러 정상 등록
- req.reply(...) 호출 시 DeprecationWarning + agent.messenger.send_message 위임 (ADR-004)
- Agent.send_message 평면 메서드 deprecation 위임

외부 Dooray 서비스에 의존하지 않는다 — 모든 HTTP는 mock.
"""

import asyncio

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from dooray_sdk.agent import Agent, ServiceNamespace
from dooray_sdk.socket_mode.request import SocketModeRequest
from dooray_sdk.web.messenger import AsyncMessengerAPI


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@pytest.fixture
def agent():
    """Agent 인스턴스 + 비동기 transport 가 주입된 상태."""
    with patch.dict(
        "os.environ",
        {"DOORAY_AGENT_TOKEN": "test-token", "DOORAY_DOMAIN": "test.dooray.com"},
    ):
        agent = Agent()

    # _initialize 를 호출하지 않고도 messenger API가 동작하도록 transport mock 주입.
    mock_transport = MagicMock()
    mock_transport.post = AsyncMock(return_value={"ok": True})
    # AsyncWebClient.messenger 가 만들어내는 동일 lazy 패턴을 재현.
    mock_messenger = AsyncMessengerAPI(mock_transport)
    type(mock_transport).messenger = property(lambda self: mock_messenger)
    agent._message_client = mock_transport
    return agent


# ---------------------------------------------------------------------------
# ADR-001: 듀얼 객체 (네임스페이스 + 데코레이터)
# ---------------------------------------------------------------------------


class TestServiceNamespaceDualBehavior:
    """agent.messenger 가 호출(데코레이터) / 속성 접근(API) 양쪽으로 동작."""

    def test_messenger_property_returns_namespace(self, agent):
        ns = agent.messenger
        assert isinstance(ns, ServiceNamespace)

    def test_messenger_send_message_delegates_to_api(self, agent):
        """agent.messenger.send_message → AsyncMessengerAPI.send_message 위임."""
        asyncio.run(agent.messenger.send_message(channel="ch-1", text="hi"))

        # transport.post 로 endpoint가 잘 라우팅되었는지 검증.
        agent._message_client.post.assert_awaited_once()
        args, kwargs = agent._message_client.post.call_args
        assert args[0] == "/messenger/v1/channels/ch-1/logs"
        assert kwargs["data"] == {"text": "hi"}

    def test_decorator_usage_emits_deprecation_warning(self, agent):
        """@agent.messenger (구독) 사용 시 DeprecationWarning 발생."""
        with pytest.warns(DeprecationWarning, match="@agent.messenger"):
            @agent.messenger
            def handler(req):  # noqa: ARG001
                pass

        # 핸들러는 등록되어야 함 (deprecated 라도 기능 유지).
        assert len(agent._handlers["all"]) == 1
        assert agent._handlers["all"][0]["service"] == ["messenger"]

    def test_task_and_wiki_namespaces_exist(self, agent):
        """task/wiki 도 같은 패턴으로 노출되어야 함 (슬롯)."""
        from dooray_sdk.web.task import AsyncTaskAPI
        from dooray_sdk.web.wiki import AsyncWikiAPI

        assert isinstance(agent.task, ServiceNamespace)
        assert isinstance(agent.wiki, ServiceNamespace)
        # _api 가 슬롯 인스턴스로 설정되어 있어야 함.
        assert isinstance(agent.task._api, AsyncTaskAPI)
        assert isinstance(agent.wiki._api, AsyncWikiAPI)

    def test_namespace_attribute_access_without_api_raises_clear_error(self):
        """초기화 전 클라이언트 네임스페이스 접근은 명시적 에러로 안내."""
        with patch.dict(
            "os.environ",
            {"DOORAY_AGENT_TOKEN": "t", "DOORAY_DOMAIN": "test.dooray.com"},
        ):
            uninit_agent = Agent()  # _message_client = None

        with pytest.raises(AttributeError, match="not initialized yet"):
            uninit_agent.messenger.send_message  # noqa: B018


# ---------------------------------------------------------------------------
# ADR-002: (req, client) 시그니처 + (req) 하위호환
# ---------------------------------------------------------------------------


def _make_message_request() -> SocketModeRequest:
    return SocketModeRequest(
        envelope_id="ev-1",
        type="message",
        payload={"text": "hello", "channelId": "ch-1"},
        service="messenger",
        action="create",
    )


class TestHandlerSignatures:
    """ADR-002: 핸들러 시그니처 (req, client) 와 (req) 양쪽 지원."""

    def test_two_arg_async_handler_receives_client(self, agent):
        """(req, client) 비동기 핸들러 호출 시 두 번째 인자에 Agent 자신이 들어옴."""
        captured: dict = {}

        @agent.on("message")
        async def handle(req, client):  # noqa: ARG001
            captured["client"] = client
            captured["req"] = req

        handler_info = agent._handlers["message"][0]
        req = _make_message_request()

        async def runner():
            agent._loop = asyncio.get_running_loop()
            await agent._execute_handler(handler_info, req, is_message=True, text="hello")

        asyncio.run(runner())

        assert captured["client"] is agent
        assert captured["req"] is req

    def test_single_arg_async_handler_still_works(self, agent):
        """(req) 단일 인자 비동기 핸들러도 여전히 호출됨 (하위호환)."""
        captured: dict = {}

        @agent.on("message")
        async def handle(req):
            captured["req"] = req

        handler_info = agent._handlers["message"][0]
        req = _make_message_request()

        async def runner():
            agent._loop = asyncio.get_running_loop()
            await agent._execute_handler(handler_info, req, is_message=True, text="hello")

        asyncio.run(runner())

        assert captured["req"] is req

    def test_two_arg_sync_handler_with_req_first(self, agent):
        """첫 인자 이름이 'req' 인 동기 (req, client) 핸들러도 client 주입."""
        captured: dict = {}

        @agent.on("message")
        def handle(req, client):  # noqa: ARG001
            captured["client"] = client
            captured["req"] = req

        handler_info = agent._handlers["message"][0]
        req = _make_message_request()

        async def runner():
            agent._loop = asyncio.get_running_loop()
            await agent._execute_handler(
                handler_info, req, is_message=True, text="hello", channel="ch-1",
                sync_reply=None,
            )

        asyncio.run(runner())

        assert captured["client"] is agent
        assert captured["req"] is req


# ---------------------------------------------------------------------------
# ADR-004: req.reply / Agent 평면 메서드 deprecation 위임
# ---------------------------------------------------------------------------


class TestReqReplyDeprecation:
    """req.reply() 가 deprecation 경고와 함께 agent.messenger.send_message 로 위임."""

    def test_async_reply_delegates_to_agent_messenger(self, agent):
        """디스패처가 ``_client = agent`` 를 주입하면 reply 는 신규 표면으로 위임."""
        req = _make_message_request()
        req._client = agent
        req._is_async = True

        async def runner():
            with pytest.warns(DeprecationWarning, match="req.reply"):
                await req.reply("auto-routed")

        asyncio.run(runner())

        # 신규 표면 (transport.post) 가 호출되었는지 확인 — endpoint 경유 검증.
        agent._message_client.post.assert_awaited_once()
        args, kwargs = agent._message_client.post.call_args
        assert args[0] == "/messenger/v1/channels/ch-1/logs"
        assert kwargs["data"] == {"text": "auto-routed"}


class TestAgentFlatMethodsDeprecation:
    """Agent.send_message 등 평면 메서드는 deprecation 신호 + messenger 위임."""

    def test_agent_send_message_emits_deprecation_and_delegates(self, agent):
        async def runner():
            with pytest.warns(DeprecationWarning, match="Agent.send_message"):
                await agent.send_message("ch-9", "legacy call")

        asyncio.run(runner())

        # transport.post 가 messenger.send_message 경로로 호출됨.
        agent._message_client.post.assert_awaited_once()
        args, _ = agent._message_client.post.call_args
        assert args[0] == "/messenger/v1/channels/ch-9/logs"
