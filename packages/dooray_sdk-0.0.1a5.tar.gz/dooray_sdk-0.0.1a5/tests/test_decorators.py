"""
데코레이터 테스트
"""

import pytest
from unittest.mock import MagicMock, patch
from dooray_sdk.socket_mode.request import SocketModeRequest


class TestAgentDecorators:
    """Agent 클래스 데코레이터 테스트."""

    @pytest.fixture
    def agent(self):
        """Agent 인스턴스 생성."""
        with patch.dict('os.environ', {
            'DOORAY_BOT_TOKEN': 'test-token',
            'DOORAY_DOMAIN': 'test.dooray.com'
        }):
            from dooray_sdk.agent import Agent
            return Agent()

    def test_messenger_decorator(self, agent):
        """@agent.messenger 데코레이터 테스트."""
        @agent.messenger
        def handler(req):
            pass

        assert len(agent._handlers["all"]) == 1
        assert agent._handlers["all"][0]["func"] == handler
        assert agent._handlers["all"][0]["service"] == ["messenger"]

    def test_task_decorator(self, agent):
        """@agent.task 데코레이터 테스트."""
        @agent.task
        def handler(req):
            pass

        assert len(agent._handlers["all"]) == 1
        assert agent._handlers["all"][0]["func"] == handler
        assert agent._handlers["all"][0]["service"] == ["task"]

    def test_wiki_decorator(self, agent):
        """@agent.wiki 데코레이터 테스트."""
        @agent.wiki
        def handler(req):
            pass

        assert len(agent._handlers["all"]) == 1
        assert agent._handlers["all"][0]["func"] == handler
        assert agent._handlers["all"][0]["service"] == ["wiki"]

    def test_service_decorator_all(self, agent):
        """@agent.{service} 서비스 전체 데코레이터 테스트."""
        @agent.wiki
        def handler(req):
            pass

        # 서비스 전체는 "all"에 등록
        assert len(agent._handlers["all"]) == 1
        assert agent._handlers["all"][0]["func"] == handler
        assert agent._handlers["all"][0]["service"] == ["wiki"]

    def test_multiple_service_decorators(self, agent):
        """여러 서비스 데코레이터 테스트."""
        @agent.messenger
        def h1(req): pass

        @agent.task
        def h2(req): pass

        @agent.wiki
        def h3(req): pass

        assert len(agent._handlers["all"]) == 3

    def test_on_decorator_single_type(self, agent):
        """@agent.on() 단일 타입 테스트."""
        @agent.on("message")
        def handler(req):
            pass

        assert len(agent._handlers["message"]) == 1

    def test_on_decorator_multiple_types(self, agent):
        """@agent.on() 복수 타입 테스트."""
        @agent.on(["task", "page"])
        def handler(req):
            pass

        assert len(agent._handlers["task"]) == 1
        assert len(agent._handlers["page"]) == 1

    def test_on_decorator_with_action(self, agent):
        """@agent.on() 액션 필터 테스트."""
        @agent.on("task", action="create")
        def handler(req):
            pass

        handler_info = agent._handlers["task"][0]
        assert handler_info["action"] == ["create"]

    def test_on_decorator_with_multiple_actions(self, agent):
        """@agent.on() 복수 액션 필터 테스트."""
        @agent.on("task", action=["create", "update"])
        def handler(req):
            pass

        handler_info = agent._handlers["task"][0]
        assert handler_info["action"] == ["create", "update"]

    def test_on_decorator_with_service(self, agent):
        """@agent.on() 서비스 필터 테스트."""
        @agent.on(service="wiki")
        def handler(req):
            pass

        handler_info = agent._handlers["all"][0]
        assert handler_info["service"] == ["wiki"]

    def test_on_decorator_with_multiple_services(self, agent):
        """@agent.on() 복수 서비스 필터 테스트."""
        @agent.on(service=["task", "wiki"])
        def handler(req):
            pass

        handler_info = agent._handlers["all"][0]
        assert handler_info["service"] == ["task", "wiki"]

    def test_on_decorator_with_service_and_action(self, agent):
        """@agent.on() 서비스 + 액션 조합 테스트."""
        @agent.on(service="wiki", action="create")
        def handler(req):
            pass

        handler_info = agent._handlers["all"][0]
        assert handler_info["service"] == ["wiki"]
        assert handler_info["action"] == ["create"]

    def test_on_decorator_with_type_and_service(self, agent):
        """@agent.on() 타입 + 서비스 조합 테스트."""
        @agent.on("page", service="wiki")
        def handler(req):
            pass

        handler_info = agent._handlers["page"][0]
        assert handler_info["service"] == ["wiki"]

    def test_async_function_allowed(self, agent):
        """async 함수 허용 테스트 (통합 Agent 클래스)."""
        @agent.messenger
        async def handler(req):
            pass

        assert len(agent._handlers["all"]) == 1
        assert agent._handlers["all"][0]["is_async"] is True

    def test_sync_function_allowed(self, agent):
        """동기 함수 허용 테스트."""
        @agent.messenger
        def handler(text, reply):
            pass

        assert len(agent._handlers["all"]) == 1
        assert agent._handlers["all"][0]["is_async"] is False


class TestDoorayClientDecorators:
    """DoorayClient 클래스 데코레이터 테스트."""

    @pytest.fixture
    def client(self):
        """DoorayClient 인스턴스 생성."""
        from dooray_sdk.client import DoorayClient
        return DoorayClient(
            bot_token="test-token",
            domain="test.dooray.com"
        )

    def test_on_decorator_message(self, client):
        """@client.on("message") 테스트."""
        @client.on("message")
        async def handler(req):
            pass

        assert len(client._handlers["message"]) == 1

    def test_on_decorator_task(self, client):
        """@client.on("task") 테스트."""
        @client.on("task")
        async def handler(req):
            pass

        assert len(client._handlers["task"]) == 1

    def test_on_decorator_with_action(self, client):
        """@client.on() 액션 필터 테스트."""
        @client.on("task", action="create")
        async def handler(req):
            pass

        handler_info = client._handlers["task"][0]
        assert handler_info["action"] == ["create"]

    def test_on_decorator_multiple_types(self, client):
        """@client.on() 복수 타입 테스트."""
        @client.on(["task", "page"])
        async def handler(req):
            pass

        assert len(client._handlers["task"]) == 1
        assert len(client._handlers["page"]) == 1

    def test_on_decorator_multiple_actions(self, client):
        """@client.on() 복수 액션 테스트."""
        @client.on("task", action=["create", "update", "delete"])
        async def handler(req):
            pass

        handler_info = client._handlers["task"][0]
        assert handler_info["action"] == ["create", "update", "delete"]

    def test_add_handler(self, client):
        """add_handler 메서드 테스트."""
        def handler(req):
            pass

        client.add_handler("task", handler, action="create")

        assert len(client._handlers["task"]) == 1
        assert client._handlers["task"][0]["func"] == handler
        assert client._handlers["task"][0]["action"] == ["create"]

    def test_on_decorator_with_service(self, client):
        """@client.on() 서비스 필터 테스트."""
        @client.on(service="wiki")
        async def handler(req):
            pass

        handler_info = client._handlers["all"][0]
        assert handler_info["service"] == ["wiki"]

    def test_on_decorator_with_multiple_services(self, client):
        """@client.on() 복수 서비스 필터 테스트."""
        @client.on(service=["task", "wiki"])
        async def handler(req):
            pass

        handler_info = client._handlers["all"][0]
        assert handler_info["service"] == ["task", "wiki"]

    def test_on_decorator_with_service_and_action(self, client):
        """@client.on() 서비스 + 액션 조합 테스트."""
        @client.on(service="wiki", action="create")
        async def handler(req):
            pass

        handler_info = client._handlers["all"][0]
        assert handler_info["service"] == ["wiki"]
        assert handler_info["action"] == ["create"]

    def test_add_handler_with_service(self, client):
        """add_handler 서비스 필터 테스트."""
        def handler(req):
            pass

        client.add_handler("all", handler, action="create", service="wiki")

        handler_info = client._handlers["all"][0]
        assert handler_info["service"] == ["wiki"]
        assert handler_info["action"] == ["create"]


class TestHandlerMatching:
    """핸들러 매칭 로직 테스트."""

    def test_action_filter_match(self):
        """액션 필터 매칭 테스트."""
        handler_info = {
            "func": lambda req: None,
            "action": ["create", "update"]
        }

        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task",
            action="create"
        )

        # action 필터링 로직
        action_filter = handler_info.get("action")
        assert action_filter is None or req.action in action_filter

    def test_action_filter_no_match(self):
        """액션 필터 불일치 테스트."""
        handler_info = {
            "func": lambda req: None,
            "action": ["create"]
        }

        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task",
            action="delete"
        )

        action_filter = handler_info.get("action")
        assert action_filter is not None and req.action not in action_filter

    def test_no_action_filter(self):
        """액션 필터 없음 테스트."""
        handler_info = {
            "func": lambda req: None,
            "action": None
        }

        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task",
            action="delete"
        )

        action_filter = handler_info.get("action")
        # action 필터가 없으면 모든 액션 허용
        assert action_filter is None

    def test_service_filter_match(self):
        """서비스 필터 매칭 테스트."""
        handler_info = {
            "func": lambda req: None,
            "service": ["wiki", "task"]
        }

        req = SocketModeRequest(
            envelope_id="1",
            type="page",
            payload={},
            service="wiki",
            action="create"
        )

        service_filter = handler_info.get("service")
        assert service_filter is None or req.service in service_filter

    def test_service_filter_no_match(self):
        """서비스 필터 불일치 테스트."""
        handler_info = {
            "func": lambda req: None,
            "service": ["wiki"]
        }

        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task",
            action="create"
        )

        service_filter = handler_info.get("service")
        assert service_filter is not None and req.service not in service_filter

    def test_no_service_filter(self):
        """서비스 필터 없음 테스트."""
        handler_info = {
            "func": lambda req: None,
            "service": None
        }

        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task",
            action="create"
        )

        service_filter = handler_info.get("service")
        # service 필터가 없으면 모든 서비스 허용
        assert service_filter is None

    def test_combined_service_and_action_filter(self):
        """서비스 + 액션 조합 필터 테스트."""
        handler_info = {
            "func": lambda req: None,
            "service": ["wiki"],
            "action": ["create", "update"]
        }

        # 매칭 케이스
        req_match = SocketModeRequest(
            envelope_id="1",
            type="page",
            payload={},
            service="wiki",
            action="create"
        )

        service_filter = handler_info.get("service")
        action_filter = handler_info.get("action")

        service_ok = service_filter is None or req_match.service in service_filter
        action_ok = action_filter is None or req_match.action in action_filter
        assert service_ok and action_ok

        # 서비스 불일치 케이스
        req_service_mismatch = SocketModeRequest(
            envelope_id="2",
            type="task",
            payload={},
            service="task",
            action="create"
        )

        service_ok = service_filter is None or req_service_mismatch.service in service_filter
        assert not service_ok

        # 액션 불일치 케이스
        req_action_mismatch = SocketModeRequest(
            envelope_id="3",
            type="page",
            payload={},
            service="wiki",
            action="delete"
        )

        action_ok = action_filter is None or req_action_mismatch.action in action_filter
        assert not action_ok
