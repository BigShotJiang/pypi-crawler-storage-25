"""
Tests for Socket Mode components
"""

import pytest
from unittest.mock import Mock, patch
from dooray_sdk.socket_mode import SocketModeRequest, SocketModeResponse
from dooray_sdk.web import WebClient


class TestSocketModeRequest:
    """Test cases for SocketModeRequest."""
    
    def test_from_dict(self):
        """Test creating SocketModeRequest from dictionary."""
        data = {
            "envelope_id": "test_id",
            "type": "message",
            "payload": {"text": "Hello"},
            "accepts_response_payload": True
        }
        request = SocketModeRequest.from_dict(data)
        
        assert request.envelope_id == "test_id"
        assert request.type == "message"
        assert request.payload == {"text": "Hello"}
        assert request.accepts_response_payload is True
    
    def test_to_dict(self):
        """Test converting SocketModeRequest to dictionary."""
        request = SocketModeRequest(
            envelope_id="test_id",
            type="message",
            payload={"text": "Hello"},
            accepts_response_payload=True
        )
        
        data = request.to_dict()
        expected = {
            "envelope_id": "test_id",
            "type": "message",
            "payload": {"text": "Hello"},
            "accepts_response_payload": True,
            "service": "messenger",
            "action": "",
        }
        assert data == expected
    
    def test_is_message(self):
        """Test message type detection."""
        request = SocketModeRequest("test_id", "message", {})
        assert request.is_message is True
        
        request = SocketModeRequest("test_id", "event", {})
        assert request.is_message is False
    
    def test_get_message_text(self):
        """Test getting message text."""
        # Dooray format: payload["text"]
        request = SocketModeRequest("test_id", "message", {
            "text": "Hello"
        })
        assert request.get_message_text() == "Hello"

        request = SocketModeRequest("test_id", "event", {})
        assert request.get_message_text() is None

    def test_get_channel(self):
        """Test getting channel from request."""
        # Dooray format: payload["channelId"]
        request = SocketModeRequest("test_id", "message", {
            "channelId": "test_channel"
        })
        assert request.get_channel() == "test_channel"

        # No channel
        request = SocketModeRequest("test_id", "message", {})
        assert request.get_channel() is None


class TestSocketModeResponse:
    """Test cases for SocketModeResponse."""
    
    def test_to_dict(self):
        """Test converting SocketModeResponse to dictionary."""
        response = SocketModeResponse("test_id", {"result": "ok"})
        data = response.to_dict()
        
        expected = {
            "envelope_id": "test_id",
            "payload": {"result": "ok"}
        }
        assert data == expected
    
    def test_ack(self):
        """Test creating acknowledgment response."""
        response = SocketModeResponse.ack("test_id")
        assert response.envelope_id == "test_id"
        assert response.payload is None
    
    def test_error(self):
        """Test creating error response."""
        response = SocketModeResponse.error("test_id", "invalid_request", "Bad request")
        assert response.envelope_id == "test_id"
        assert response.payload == {
            "error": "invalid_request",
            "message": "Bad request"
        }
    
    def test_with_payload(self):
        """Test creating response with custom payload."""
        payload = {"result": "success", "data": {"id": 123}}
        response = SocketModeResponse.with_payload("test_id", payload)
        assert response.envelope_id == "test_id"
        assert response.payload == payload
