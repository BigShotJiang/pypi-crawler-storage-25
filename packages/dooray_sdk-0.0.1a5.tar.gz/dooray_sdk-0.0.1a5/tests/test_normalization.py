"""
Characterization Tests for WebSocket Message Normalization

이 테스트는 messenger format 처리 동작을 문서화합니다.
common WebSocket format과 messenger format 모두 통합 구조로 정규화됩니다.
"""

import pytest
from dooray_sdk.socket_mode.request import SocketModeRequest


class TestMessengerFormatCharacterization:
    """
    Messenger 포맷 메시지의 기존 동작을 캡처합니다.
    - req.data: payload와 동일
    - req.text: payload["text"]에서 추출
    - req.channel: payload["channelId"]에서 추출
    """

    def test_messenger_message_text_extraction(self):
        """메신저 메시지에서 text 필드 추출 동작 특성화."""
        # Arrange: messenger format
        data = {
            "envelope_id": "env-123",
            "type": "message",
            "service": "messenger",
            "action": "create",
            "payload": {
                "text": "Hello, World!",
                "channelId": "channel-456"
            }
        }

        # Act
        request = SocketModeRequest.from_dict(data)

        # Assert: 기존 동작 검증
        assert request.text == "Hello, World!"
        assert request.get_message_text() == "Hello, World!"

    def test_messenger_message_channel_extraction(self):
        """메신저 메시지에서 channelId 추출 동작 특성화."""
        # Arrange
        data = {
            "envelope_id": "env-123",
            "type": "message",
            "service": "messenger",
            "action": "create",
            "payload": {
                "text": "Test",
                "channelId": "channel-789"
            }
        }

        # Act
        request = SocketModeRequest.from_dict(data)

        # Assert
        assert request.channel == "channel-789"
        assert request.get_channel() == "channel-789"

    def test_messenger_message_data_property(self):
        """req.data 속성이 payload와 동일함을 특성화."""
        # Arrange
        payload = {
            "text": "Test message",
            "channelId": "ch-001",
            "extra": "metadata"
        }
        data = {
            "envelope_id": "env-001",
            "type": "message",
            "service": "messenger",
            "action": "create",
            "payload": payload
        }

        # Act
        request = SocketModeRequest.from_dict(data)

        # Assert
        assert request.data == payload
        assert request.data is request.payload

    def test_messenger_message_type_check(self):
        """메시지 타입 체크 메서드 동작 특성화."""
        # Arrange
        data = {
            "envelope_id": "env-002",
            "type": "message",
            "service": "messenger",
            "action": "update",
            "payload": {"text": "Updated"}
        }

        # Act
        request = SocketModeRequest.from_dict(data)

        # Assert
        assert request.is_message is True
        assert request.is_task is False
        assert request.is_page is False
        assert request.is_service("messenger") is True

    def test_messenger_service_and_action(self):
        """service와 action 필드 동작 특성화."""
        # Arrange
        data = {
            "envelope_id": "env-003",
            "type": "message",
            "service": "messenger",
            "action": "create",
            "payload": {}
        }

        # Act
        request = SocketModeRequest.from_dict(data)

        # Assert
        assert request.service == "messenger"
        assert request.action == "create"
        assert request.is_action_type("create") is True
        assert request.is_action_type(["create", "update"]) is True

    def test_task_message_basic_fields(self):
        """task 메시지 기본 필드 특성화."""
        # Arrange
        data = {
            "envelope_id": "env-004",
            "type": "task",
            "service": "task",
            "action": "create",
            "payload": {
                "id": "task-123",
                "subject": "New Task"
            }
        }

        # Act
        request = SocketModeRequest.from_dict(data)

        # Assert
        assert request.is_task is True
        assert request.service == "task"
        assert request.data["id"] == "task-123"
        assert request.payload["subject"] == "New Task"

    def test_wiki_page_basic_fields(self):
        """wiki page 메시지 기본 필드 특성화."""
        # Arrange
        data = {
            "envelope_id": "env-005",
            "type": "page",
            "service": "wiki",
            "action": "create",
            "payload": {
                "id": "page-456",
                "title": "New Page"
            }
        }

        # Act
        request = SocketModeRequest.from_dict(data)

        # Assert
        assert request.is_page is True
        assert request.service == "wiki"
        assert request.data["id"] == "page-456"

    def test_from_dict_backward_compatibility_content_field(self):
        """
        # @MX:NOTE: 하위 호환성 - content 필드 지원

        from_dict가 'content' 필드를 'payload'로 변환하는 동작 특성화.
        """
        # Arrange: old format with 'content' instead of 'payload'
        data = {
            "envelope_id": "env-006",
            "type": "message",
            "content": {"text": "Old format"},
            "service": "messenger",
            "action": "create"
        }

        # Act
        request = SocketModeRequest.from_dict(data)

        # Assert
        assert request.payload == {"text": "Old format"}
        assert request.text == "Old format"

    def test_to_dict_preserves_all_fields(self):
        """to_dict가 모든 필드를 보존하는 동작 특성화."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="env-007",
            type="message",
            payload={"text": "Test"},
            accepts_response_payload=True,
            service="messenger",
            action="create"
        )

        # Act
        result = request.to_dict()

        # Assert
        assert result["envelope_id"] == "env-007"
        assert result["type"] == "message"
        assert result["payload"] == {"text": "Test"}
        assert result["accepts_response_payload"] is True
        assert result["service"] == "messenger"
        assert result["action"] == "create"


class TestSocketModeRequestDefaults:
    """SocketModeRequest의 기본값 동작을 문서화합니다."""

    def test_default_service_is_messenger(self):
        """service 필드 기본값이 'messenger'임을 특성화."""
        # Act
        request = SocketModeRequest(
            envelope_id="env-008",
            type="message",
            payload={}
        )

        # Assert
        assert request.service == "messenger"

    def test_default_action_is_empty_string(self):
        """action 필드 기본값이 빈 문자열임을 특성화."""
        # Act
        request = SocketModeRequest(
            envelope_id="env-009",
            type="message",
            payload={}
        )

        # Assert
        assert request.action == ""

    def test_default_accepts_response_payload_is_false(self):
        """accepts_response_payload 기본값이 False임을 특성화."""
        # Act
        request = SocketModeRequest(
            envelope_id="env-010",
            type="message",
            payload={}
        )

        # Assert
        assert request.accepts_response_payload is False


class TestCommonWebSocketFormat:
    """Common WebSocket format 메시지 처리를 검증합니다."""

    def test_entity_type_extraction(self):
        """entity type 추출 테스트."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="env-002",
            type="task",
            payload={},
            entity={"type": "task", "task": {"id": "task-456"}}
        )

        # Assert
        assert request.entity.type == "task"

    def test_entity_data_extraction(self):
        """entity data 추출 테스트."""
        # Arrange
        task_data = {"id": "task-789", "subject": "Test Task"}
        request = SocketModeRequest(
            envelope_id="env-003",
            type="task",
            payload={},
            entity={"type": "task", "task": task_data}
        )

        # Assert
        assert request.entity.data == task_data
        assert request.entity.data["id"] == "task-789"
        assert request.entity.data["subject"] == "Test Task"

    def test_actor_id_extraction(self):
        """actor ID 추출 테스트."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="env-004",
            type="task",
            payload={},
            actor={"type": "organizationMember", "organizationMember": {"id": "member-123"}}
        )

        # Assert
        assert request.actor.id == "member-123"

    def test_actor_id_none_when_no_actor(self):
        """actor가 없을 때 actor_id는 None."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="env-005",
            type="task",
            payload={},
            entity={"type": "task", "task": {}}
        )

        # Assert
        assert request.actor.id is None

    def test_action_data_field(self):
        """action_data 필드 테스트."""
        # Arrange
        action_data = {"scope": "public", "expiredAt": "2024-12-31"}
        request = SocketModeRequest(
            envelope_id="env-006",
            type="driveFile",
            payload={},
            action="create",
            action_data=action_data
        )

        # Assert - action.data is now DataWrapper         assert request.action.data["scope"] == "public"
        assert request.action.data.get("expiredAt") == "2024-12-31"

    def test_common_format_with_all_fields(self):
        """common format 모든 필드 포함 테스트."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="env-007",
            type="driveFile",
            payload={"id": "file-001"},
            service="drive",
            action="createSharedLink",
            entity={
                "type": "driveFile",
                "driveFile": {"id": "file-001", "name": "test.pdf"}
            },
            actor={
                "type": "organizationMember",
                "organizationMember": {"id": "member-999", "name": "Test User"}
            },
            action_data={"scope": "internal", "expiredAt": "2025-01-01"}
        )

        # Assert
        assert request.entity.type == "driveFile"
        assert request.entity.data["id"] == "file-001"
        assert request.entity.data["name"] == "test.pdf"
        assert request.actor.id == "member-999"
        assert request.action.data["scope"] == "internal"

    def test_entity_type_none_when_no_entity(self):
        """entity가 없을 때 entity_type은 None."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="env-008",
            type="message",
            payload={}
        )

        # Assert
        assert request.entity.type is None
        assert request.entity.data is None


class TestMessageNormalization:
    """SocketModeClient의 정규화 함수들을 단위 테스트합니다."""

    def test_normalize_messenger_message_basic(self):
        """messenger 메시지 정규화 기본 테스트."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient
        from dooray_sdk.socket_mode.registry import ServiceMapping

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        mapping = ServiceMapping(service="messenger", type="message")
        data = {
            "service": "messenger",
            "type": "channelLog",
            "action": "create",
            "content": {"text": "Hello", "channelId": "ch-001"},
            "actor": {"type": "member", "member": {"id": "m-001"}}
        }

        # Act
        result = client._normalize_messenger_message(data, mapping)

        # Assert
        assert result["service"] == "messenger"
        assert result["type"] == "message"
        # action is now a unified dict structure         assert result["action"]["type"] == "create"
        assert result["payload"] == {"text": "Hello", "channelId": "ch-001"}
        assert result["entity"]["type"] == "message"
        assert result["actor"]["type"] == "member"

    def test_normalize_messenger_message_no_actor(self):
        """messenger 메시지 정규화 - actor 없는 경우."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient
        from dooray_sdk.socket_mode.registry import ServiceMapping

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        mapping = ServiceMapping(service="messenger", type="message")
        data = {
            "service": "messenger",
            "type": "channelLog",
            "action": "create",
            "content": {"text": "Hello"}
        }

        # Act
        result = client._normalize_messenger_message(data, mapping)

        # Assert
        assert result["actor"] is None

    def test_normalize_messenger_message_with_channel(self):
        """messenger 메시지 정규화 - channel 객체 별도 필드로 분리."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient
        from dooray_sdk.socket_mode.registry import ServiceMapping

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        mapping = ServiceMapping(service="messenger", type="message")
        data = {
            "service": "messenger",
            "type": "channelLog",
            "action": "create",
            "channel": {"scope": "direct", "type": "direct"},  # content 외부 필드
            "content": {"text": "Hello", "channelId": "ch-001"}
        }

        # Act
        result = client._normalize_messenger_message(data, mapping)

        # Assert: channel_data가 별도 필드로 존재 (id도 포함)
        assert result["channel_data"] == {"scope": "direct", "type": "direct", "id": "ch-001"}
        assert result["payload"]["text"] == "Hello"
        assert result["payload"]["channelId"] == "ch-001"
        # payload에는 channel이 없어야 함
        assert "channel" not in result["payload"]

    def test_normalize_messenger_message_channel_scope_types(self):
        """messenger 메시지 정규화 - 다양한 channel scope 타입."""
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient
        from dooray_sdk.socket_mode.registry import ServiceMapping

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")
        mapping = ServiceMapping(service="messenger", type="message")

        for scope_type in ["direct", "private", "thread"]:
            data = {
                "service": "messenger",
                "type": "channelLog",
                "action": "create",
                "channel": {"scope": scope_type, "type": scope_type},
                "content": {"text": "Hello"}
            }
            result = client._normalize_messenger_message(data, mapping)
            assert result["channel_data"]["scope"] == scope_type

    def test_normalize_common_message_basic(self):
        """common WebSocket 메시지 정규화 기본 테스트."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        data = {
            "service": "drive",
            "entity": {
                "type": "driveFile",
                "driveFile": {"id": "file-001", "name": "test.pdf"}
            },
            "actor": {
                "type": "organizationMember",
                "organizationMember": {"id": "member-123"}
            },
            "action": {
                "type": "createSharedLink",
                "createSharedLink": {"scope": "public", "expiredAt": "2025-01-01"}
            }
        }

        # Act
        result = client._normalize_common_message(data)

        # Assert
        assert result["service"] == "drive"
        assert result["type"] == "driveFile"
        assert result["action"] == "createSharedLink"
        assert result["payload"] == {"id": "file-001", "name": "test.pdf"}
        assert result["entity"]["type"] == "driveFile"
        assert result["actor"]["type"] == "organizationMember"
        assert result["action_data"] == {"scope": "public", "expiredAt": "2025-01-01"}

    def test_normalize_common_message_no_actor(self):
        """common WebSocket 메시지 정규화 - actor 없는 경우."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        data = {
            "service": "task",
            "entity": {
                "type": "task",
                "task": {"id": "task-001", "subject": "Test"}
            },
            "action": {
                "type": "create",
                "create": {}
            }
        }

        # Act
        result = client._normalize_common_message(data)

        # Assert
        assert result["actor"] == {}

    def test_normalize_common_message_empty_action_data(self):
        """common WebSocket 메시지 정규화 - action_data 없는 경우."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        data = {
            "service": "task",
            "entity": {
                "type": "task",
                "task": {"id": "task-002"}
            },
            "action": {
                "type": "update"
            }
        }

        # Act
        result = client._normalize_common_message(data)

        # Assert
        assert result["action_data"] == {}


class TestBackwardCompatibility:
    """기존 messenger format 사용자가 영향받지 않음을 보장합니다."""

    def test_existing_code_still_works(self):
        """기존 코드가 그대로 동작함을 검증."""
        # Arrange: 기존 방식대로 SocketModeRequest 생성
        data = {
            "envelope_id": "env-legacy",
            "type": "message",
            "payload": {"text": "Legacy message", "channelId": "ch-legacy"},
            "service": "messenger",
            "action": "create"
        }

        # Act: from_dict로 생성
        req = SocketModeRequest.from_dict(data)

        # Assert: 기존 API가 모두 동작
        assert req.text == "Legacy message"
        assert req.channel == "ch-legacy"
        assert req.data == {"text": "Legacy message", "channelId": "ch-legacy"}
        assert req.is_message is True
        assert req.service == "messenger"
        assert req.action == "create"

    def test_messenger_and_common_format_coexist(self):
        """messenger와 common format이 동시에 처리 가능함을 검증."""
        # messenger format
        req_messenger = SocketModeRequest(
            envelope_id="msg-001",
            type="message",
            payload={"text": "Hello"},
            service="messenger",
            action="create"
        )

        # common format (task with entity)
        req_common = SocketModeRequest(
            envelope_id="task-001",
            type="task",
            payload={"id": "task-v2"},
            service="task",
            action="create",
            entity={"type": "task", "task": {"id": "task-v2"}}
        )

        # Assert: 두 format 모두 정상 동작
        assert req_messenger.data == {"text": "Hello"}

        assert req_common.entity.type == "task"
        assert req_common.entity.data == {"id": "task-v2"}


class TestWrapperDotNotation:
    """
    EntityWrapper, ActorWrapper, ActionWrapper의 dot notation 접근을 검증합니다.
    예: req.entity.data.id, req.actor.data.name, req.action.data.scope
    """

    def test_entity_data_dot_notation_access(self):
        """entity.data 필드에 dot notation으로 접근."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-001",
            type="task",
            payload={},
            entity={"type": "task", "task": {"id": "task-123", "subject": "Test Task", "priority": "high"}}
        )

        # Assert: dot notation으로 entity.data 필드 접근
        assert request.entity.data.id == "task-123"
        assert request.entity.data.subject == "Test Task"
        assert request.entity.data.priority == "high"

    def test_actor_data_dot_notation_access(self):
        """actor.data 필드에 dot notation으로 접근."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-002",
            type="task",
            payload={},
            actor={"type": "member", "member": {"id": "m-001", "name": "Test User", "email": "test@example.com"}}
        )

        # Assert: dot notation으로 actor.data 필드 접근
        assert request.actor.id == "m-001"  # 편의 속성 유지
        assert request.actor.data.id == "m-001"
        assert request.actor.data.name == "Test User"
        assert request.actor.data.email == "test@example.com"

    def test_action_data_dot_notation_access(self):
        """action.data 필드에 dot notation으로 접근."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-003",
            type="driveFile",
            payload={},
            action="createSharedLink",
            action_data={"scope": "public", "expiredAt": "2025-12-31", "password": "secret"}
        )

        # Assert: dot notation으로 action.data 필드 접근
        assert request.action.data.scope == "public"
        assert request.action.data.expiredAt == "2025-12-31"
        assert request.action.data.password == "secret"

    def test_entity_data_dot_notation_attribute_error(self):
        """존재하지 않는 entity.data 필드 접근 시 AttributeError."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-004",
            type="task",
            payload={},
            entity={"type": "task", "task": {"id": "task-123"}}
        )

        # Assert
        with pytest.raises(AttributeError):
            _ = request.entity.data.nonexistent_field

    def test_actor_data_dot_notation_attribute_error(self):
        """존재하지 않는 actor.data 필드 접근 시 AttributeError."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-005",
            type="task",
            payload={},
            actor={"type": "member", "member": {"id": "m-001"}}
        )

        # Assert
        with pytest.raises(AttributeError):
            _ = request.actor.data.nonexistent_field

    def test_action_data_dot_notation_attribute_error(self):
        """존재하지 않는 action.data 필드 접근 시 AttributeError."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-006",
            type="driveFile",
            payload={},
            action="createSharedLink",
            action_data={"scope": "public"}
        )

        # Assert
        with pytest.raises(AttributeError):
            _ = request.action.data.nonexistent_field

    def test_empty_entity_data_is_none(self):
        """entity가 비어있을 때 entity.data는 None."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-007",
            type="message",
            payload={}
        )

        # Assert
        assert request.entity.data is None

    def test_empty_action_data_is_empty_wrapper(self):
        """action_data가 없을 때 action.data는 empty DataWrapper.

        With unified structure, action_data defaults to {} and is wrapped in DataWrapper.
        """
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-008",
            type="task",
            payload={},
            action="create"
        )

        # Assert - action.data is DataWrapper({}) with unified structure
        assert request.action.data is not None
        assert len(request.action.data) == 0  # empty DataWrapper

    def test_dot_notation_with_all_wrappers(self):
        """모든 wrapper 필드에 dot notation 접근 통합 테스트."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dot-009",
            type="driveFile",
            payload={"id": "file-001"},
            service="drive",
            action="createSharedLink",
            entity={
                "type": "driveFile",
                "driveFile": {"id": "file-001", "name": "document.pdf", "size": 1024}
            },
            actor={
                "type": "organizationMember",
                "organizationMember": {"id": "member-001", "name": "John Doe", "department": "Engineering"}
            },
            action_data={"scope": "internal", "expiredAt": "2025-06-30", "allowDownload": True}
        )

        # Assert: entity.data dot notation
        assert request.entity.data.id == "file-001"
        assert request.entity.data.name == "document.pdf"
        assert request.entity.data.size == 1024

        # Assert: actor.data dot notation
        assert request.actor.id == "member-001"  # 편의 속성
        assert request.actor.data.id == "member-001"
        assert request.actor.data.name == "John Doe"
        assert request.actor.data.department == "Engineering"

        # Assert: action.data dot notation
        assert request.action.data.scope == "internal"
        assert request.action.data.expiredAt == "2025-06-30"
        assert request.action.data.allowDownload is True

        # Assert: 기존 속성도 여전히 동작
        assert request.entity.type == "driveFile"
        assert request.entity.data["id"] == "file-001"  # dict 접근도 지원
        assert request.action == "createSharedLink"  # str 호환성

    def test_data_wrapper_dict_compatibility(self):
        """DataWrapper의 dict 호환성 테스트."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="dict-compat",
            type="task",
            payload={},
            entity={"type": "task", "task": {"id": "t-001", "subject": "Test", "tags": ["a", "b"]}}
        )

        # Assert: dict-like access
        assert request.entity.data["id"] == "t-001"
        assert request.entity.data.get("subject") == "Test"
        assert request.entity.data.get("missing", "default") == "default"
        assert "id" in request.entity.data
        assert "missing" not in request.entity.data
        assert list(request.entity.data.keys()) == ["id", "subject", "tags"]
        assert len(request.entity.data) == 3

    def test_message_data_wrapper_with_all_fields(self):
        """MessageData 래퍼로 channelLog 메시지 필드 접근 테스트."""
        # Arrange - 실제 channelLog 메시지 구조
        request = SocketModeRequest(
            envelope_id="msg-001",
            type="message",
            payload={},
            entity={
                "type": "message",
                "message": {
                    "id": "4289289044665801504",
                    "channelId": "4289267692156514763",
                    "directMemberId": "0",
                    "type": 0,
                    "senderId": "3182968374101474627",
                    "sentAt": 1773627099653,
                    "seq": 4,
                    "text": "테스트 메시지입니다",
                    "token": "14b8642a-48c6-47c4-9aa1-9d29a0ef3a1b",
                    "unreadCount": 0,
                    "mentionCount": 0,
                    "flags": 0,
                    "parentChannelId": "3883375440542388897",
                    "totalCount": 4,
                    "unreadFlag": False,
                    "threadTitle": "스레드 제목"
                }
            }
        )

        # Assert: MessageData 래퍼로 모든 필드 접근
        from dooray_sdk.socket_mode.request import MessageData
        assert isinstance(request.entity.data, MessageData)

        assert request.entity.data.id == "4289289044665801504"
        assert request.entity.data.channelId == "4289267692156514763"
        assert request.entity.data.directMemberId == "0"
        assert request.entity.data.type == 0
        assert request.entity.data.senderId == "3182968374101474627"
        assert request.entity.data.sentAt == 1773627099653
        assert request.entity.data.seq == 4
        assert request.entity.data.text == "테스트 메시지입니다"
        assert request.entity.data.token == "14b8642a-48c6-47c4-9aa1-9d29a0ef3a1b"
        assert request.entity.data.unreadCount == 0
        assert request.entity.data.mentionCount == 0
        assert request.entity.data.flags == 0
        assert request.entity.data.parentChannelId == "3883375440542388897"
        assert request.entity.data.totalCount == 4
        assert request.entity.data.unreadFlag is False
        assert request.entity.data.threadTitle == "스레드 제목"

        # Assert: dict 접근도 여전히 동작
        assert request.entity.data["id"] == "4289289044665801504"
        assert request.entity.data.get("text") == "테스트 메시지입니다"

    def test_non_message_entity_uses_data_wrapper(self):
        """message가 아닌 타입은 기본 DataWrapper 사용."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="task-001",
            type="task",
            payload={},
            entity={"type": "task", "task": {"id": "t-001", "subject": "업무"}}
        )

        # Assert: DataWrapper 사용 (MessageData 아님)
        from dooray_sdk.socket_mode.request import MessageData, DataWrapper
        assert isinstance(request.entity.data, DataWrapper)
        assert not isinstance(request.entity.data, MessageData)


class TestActorSenderIdFallback:
    """channelLog 메시지에서 senderId를 actor로 추출하는 기능 테스트."""

    def test_actor_exists_at_root_level_priority(self):
        """Scenario 1: root level에 actor가 있으면 해당 actor를 사용한다."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient
        from dooray_sdk.socket_mode.registry import ServiceMapping

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        mapping = ServiceMapping(service="messenger", type="message")
        data = {
            "type": "channelLog",
            "action": "create",
            "actor": {
                "type": "organizationMember",
                "organizationMember": {"id": "org-member-123", "name": "Test User"}
            },
            "content": {
                "text": "hello",
                "senderId": "different-user-456"  # This should be ignored
            }
        }

        # Act
        result = client._normalize_messenger_message(data, mapping)
        request = SocketModeRequest(
            envelope_id="test-1",
            type="message",
            payload=result["payload"],
            actor=result["actor"],
            action=result["action"]
        )

        # Assert - root level actor is used, not senderId
        assert request.actor.type == "organizationMember"
        assert request.actor.id == "org-member-123"

    def test_sender_id_fallback_when_no_actor(self):
        """Scenario 2: actor가 없고 senderId가 있으면 senderId로 actor를 생성한다."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient
        from dooray_sdk.socket_mode.registry import ServiceMapping

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        mapping = ServiceMapping(service="messenger", type="message")
        data = {
            "type": "channelLog",
            "action": "create",
            "content": {
                "text": "hello",
                "channelId": "ch123",
                "senderId": "user456"
            }
        }

        # Act
        result = client._normalize_messenger_message(data, mapping)
        request = SocketModeRequest(
            envelope_id="test-2",
            type="message",
            payload=result["payload"],
            actor=result["actor"],
            action=result["action"]
        )

        # Assert - actor created from senderId
        assert request.actor.type == "organizationMember"
        assert request.actor.id == "user456"

    def test_actor_none_when_no_actor_and_no_sender_id(self):
        """Scenario 3: actor도 senderId도 없으면 actor는 None이다."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient
        from dooray_sdk.socket_mode.registry import ServiceMapping

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        mapping = ServiceMapping(service="messenger", type="message")
        data = {
            "type": "channelLog",
            "action": "create",
            "content": {
                "text": "hello",
                "channelId": "ch123"
            }
        }

        # Act
        result = client._normalize_messenger_message(data, mapping)
        request = SocketModeRequest(
            envelope_id="test-3",
            type="message",
            payload=result["payload"],
            actor=result["actor"],
            action=result["action"]
        )

        # Assert - actor wraps None
        assert request.actor.id is None


class TestUnifiedActionStructure:
    """Action 구조 통일 테스트."""

    def test_action_unified_structure(self):
        """Scenario 5: action이 통일된 구조를 갖는다."""
        # Arrange
        from dooray_sdk.socket_mode.aiohttp.client import SocketModeClient
        from dooray_sdk.web.async_client import AsyncWebClient
        from dooray_sdk.socket_mode.registry import ServiceMapping

        web_client = AsyncWebClient(token="test", domain="test.dooray.com")
        client = SocketModeClient(web_client=web_client, domain="test.dooray.com")

        mapping = ServiceMapping(service="messenger", type="message")
        data = {
            "type": "channelLog",
            "action": "create",
            "action_data": {"scope": "public"},
            "content": {"text": "hello"}
        }

        # Act
        result = client._normalize_messenger_message(data, mapping)

        # Assert - action has unified structure
        assert result["action"]["type"] == "create"
        assert "create" in result["action"]

    def test_action_string_comparison_backward_compatibility(self):
        """Scenario 9: action은 여전히 str 비교가 가능하다."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="test-9",
            type="task",
            payload={},
            action="create"
        )

        # Assert - backward compatibility with string comparison
        assert request.action == "create"
        assert request.action.type == "create"
        assert str(request.action) == "create"


class TestDynamicAttributeAccess:
    """__getattr__를 통한 동적 속성 접근 테스트."""

    def test_actor_dynamic_attribute_access(self):
        """Scenario 6: req.actor.organizationMember로 접근할 수 있다."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="test-6",
            type="message",
            payload={},
            actor={
                "type": "organizationMember",
                "organizationMember": {"id": "member-123", "name": "John"}
            }
        )

        # Assert - dynamic attribute access via __getattr__
        assert request.actor.organizationMember.id == "member-123"
        assert request.actor.organizationMember.name == "John"

    def test_entity_dynamic_attribute_access(self):
        """Scenario 7: req.entity.task로 접근할 수 있다."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="test-7",
            type="task",
            payload={},
            entity={
                "type": "task",
                "task": {"id": "task-001", "subject": "Test Task"}
            }
        )

        # Assert - dynamic attribute access via __getattr__
        assert request.entity.task.id == "task-001"
        assert request.entity.task.subject == "Test Task"

    def test_action_dynamic_attribute_access(self):
        """Scenario 8: req.action.create로 접근할 수 있다."""
        # Arrange
        request = SocketModeRequest(
            envelope_id="test-8",
            type="task",
            payload={},
            action="create",
            action_data={"scope": "internal", "priority": "high"}
        )

        # Assert - dynamic attribute access via __getattr__
        assert request.action.create.scope == "internal"
        assert request.action.create.priority == "high"
