"""
SocketModeRequest 테스트
"""

import pytest
from dooray_sdk.socket_mode.request import SocketModeRequest


class TestSocketModeRequest:
    """SocketModeRequest 기본 테스트."""

    def test_create_message_request(self):
        """메시지 요청 생성 테스트."""
        req = SocketModeRequest(
            envelope_id="123",
            type="message",
            payload={"text": "hello", "channelId": "ch1"},
            service="messenger",
            action="create"
        )

        assert req.type == "message"
        assert req.service == "messenger"
        assert req.action == "create"
        assert req.text == "hello"
        assert req.channel == "ch1"

    def test_message_request_with_channel_info(self):
        """메시지 요청에 channel_info 객체 테스트."""
        req = SocketModeRequest(
            envelope_id="123",
            type="message",
            payload={"text": "hello", "channelId": "ch1"},
            channel_data={"id": "ch1", "scope": "direct", "type": "direct"},
            service="messenger",
            action="create"
        )

        assert req.channel_info is not None
        assert req.channel_info.id == "ch1"
        assert req.channel_info.scope == "direct"
        assert req.channel_info.type == "direct"

    def test_message_request_channel_scope_types(self):
        """다양한 channel scope 타입 테스트 (direct, private, thread)."""
        for scope_type in ["direct", "private", "thread"]:
            req = SocketModeRequest(
                envelope_id="123",
                type="message",
                payload={"text": "hello", "channelId": "ch1"},
                channel_data={"scope": scope_type, "type": scope_type},
                service="messenger",
                action="create"
            )
            assert req.channel_info.scope == scope_type

    def test_message_request_channel_info_empty(self):
        """channel_info가 없을 때 None 반환 테스트."""
        req = SocketModeRequest(
            envelope_id="123",
            type="message",
            payload={"text": "hello", "channelId": "ch1"},
            service="messenger",
            action="create"
        )

        assert req.channel_info is None

    def test_channel_property_deprecation_warning(self):
        """req.channel 사용 시 deprecation warning 발생 테스트."""
        import warnings

        req = SocketModeRequest(
            envelope_id="123",
            type="message",
            payload={"text": "hello", "channelId": "ch1"},
            service="messenger",
            action="create"
        )

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            _ = req.channel
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert "channel_info.id" in str(w[0].message)

    def test_create_task_request(self):
        """업무 요청 생성 테스트."""
        req = SocketModeRequest(
            envelope_id="456",
            type="task",
            payload={"subject": "새 업무", "taskId": "t1"},
            service="task",
            action="create"
        )

        assert req.type == "task"
        assert req.service == "task"
        assert req.action == "create"
        assert req.data["subject"] == "새 업무"

    def test_create_wiki_request(self):
        """위키 요청 생성 테스트."""
        req = SocketModeRequest(
            envelope_id="789",
            type="page",
            payload={"title": "새 문서", "pageId": "p1"},
            service="wiki",
            action="update"
        )

        assert req.type == "page"
        assert req.service == "wiki"
        assert req.action == "update"
        assert req.data["title"] == "새 문서"


class TestSocketModeRequestTypeCheck:
    """타입 체크 테스트."""

    def test_is_message(self):
        """is_message 테스트."""
        req = SocketModeRequest(
            envelope_id="1",
            type="message",
            payload={},
            service="messenger"
        )
        assert req.is_message is True
        assert req.is_task is False
        assert req.is_page is False

    def test_is_task(self):
        """is_task 테스트."""
        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task"
        )
        assert req.is_message is False
        assert req.is_task is True
        assert req.is_page is False

    def test_is_page(self):
        """is_page 테스트."""
        req = SocketModeRequest(
            envelope_id="1",
            type="page",
            payload={},
            service="wiki"
        )
        assert req.is_message is False
        assert req.is_task is False
        assert req.is_page is True

    def test_is_service(self):
        """is_service 테스트."""
        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task"
        )
        assert req.is_service("task") is True
        assert req.is_service("messenger") is False

    def test_is_action_type_string(self):
        """is_action_type 문자열 테스트."""
        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task",
            action="create"
        )
        assert req.is_action_type("create") is True
        assert req.is_action_type("update") is False

    def test_is_action_type_list(self):
        """is_action_type 리스트 테스트."""
        req = SocketModeRequest(
            envelope_id="1",
            type="task",
            payload={},
            service="task",
            action="update"
        )
        assert req.is_action_type(["create", "update"]) is True
        assert req.is_action_type(["delete", "comment"]) is False


class TestSocketModeRequestFromDict:
    """from_dict 테스트."""

    def test_from_dict_message(self):
        """딕셔너리에서 메시지 요청 생성."""
        data = {
            "envelope_id": "123",
            "type": "message",
            "content": {"text": "hello", "channelId": "ch1"},
            "service": "messenger",
            "action": "create"
        }

        req = SocketModeRequest.from_dict(data)

        assert req.envelope_id == "123"
        assert req.type == "message"
        assert req.service == "messenger"
        assert req.action == "create"
        assert req.text == "hello"

    def test_from_dict_task(self):
        """딕셔너리에서 업무 요청 생성."""
        data = {
            "envelope_id": "456",
            "type": "task",
            "content": {"subject": "새 업무"},
            "service": "task",
            "action": "create"
        }

        req = SocketModeRequest.from_dict(data)

        assert req.type == "task"
        assert req.service == "task"
        assert req.data["subject"] == "새 업무"

    def test_from_dict_default_service(self):
        """서비스 기본값 테스트."""
        data = {
            "envelope_id": "123",
            "type": "message",
            "content": {}
        }

        req = SocketModeRequest.from_dict(data)

        # 기본값은 messenger
        assert req.service == "messenger"


class TestSocketModeRequestToDict:
    """to_dict 테스트."""

    def test_to_dict(self):
        """딕셔너리로 변환 테스트."""
        req = SocketModeRequest(
            envelope_id="123",
            type="task",
            payload={"subject": "테스트"},
            service="task",
            action="create"
        )

        result = req.to_dict()

        assert result["envelope_id"] == "123"
        assert result["type"] == "task"
        assert result["service"] == "task"
        assert result["action"] == "create"
        assert result["payload"]["subject"] == "테스트"


class TestSyncReplyFunc:
    """동기 핸들러에서 req.reply() 호출 시 _sync_reply_func 사용 테스트."""

    def test_sync_reply_uses_sync_reply_func(self):
        """_sync_reply_func가 있으면 그것을 사용."""
        called_with = {}

        def mock_sync_reply(text):
            called_with["text"] = text
            return {"ok": True}

        req = SocketModeRequest(
            envelope_id="1",
            type="message",
            payload={"text": "hello", "channelId": "ch1"},
            service="messenger",
            action="create"
        )
        req._is_async = False
        req._sync_reply_func = mock_sync_reply

        result = req.reply("응답 메시지")

        assert called_with["text"] == "응답 메시지"
        assert result == {"ok": True}

    def test_sync_reply_without_func_uses_web_client(self):
        """_sync_reply_func가 없으면 _web_client.messenger.send_message()으로 fallback.

        ADR-005 이후 ``_web_client`` 가 ``messenger`` 네임스페이스를 가지면 그 경로로
        라우팅된다. 이 테스트는 신규 표면 경로를 검증한다.
        ADR-004로 ``req.reply()`` 자체는 deprecation 신호를 띄우지만 동작은 유지된다.
        """
        from unittest.mock import MagicMock

        mock_client = MagicMock()
        mock_client.messenger.send_message.return_value = {"ok": True}

        req = SocketModeRequest(
            envelope_id="2",
            type="message",
            payload={"text": "hello", "channelId": "ch1"},
            service="messenger",
            action="create"
        )
        req._is_async = False
        req._web_client = mock_client

        with pytest.warns(DeprecationWarning, match="req.reply"):
            result = req.reply("fallback 응답")

        mock_client.messenger.send_message.assert_called_once_with("ch1", "fallback 응답")
        assert result == {"ok": True}

    def test_sync_reply_legacy_transport_without_messenger(self):
        """messenger 네임스페이스가 없는 transport 도 호환 fallback 경로로 동작.

        구 SDK 사용자가 직접 ``_web_client`` 를 주입한 코드를 위한 안전망.
        """
        from unittest.mock import MagicMock

        legacy_transport = MagicMock(spec=["send_message"])
        legacy_transport.send_message.return_value = {"ok": True}

        req = SocketModeRequest(
            envelope_id="2b",
            type="message",
            payload={"text": "hello", "channelId": "ch1"},
            service="messenger",
            action="create",
        )
        req._is_async = False
        req._web_client = legacy_transport

        with pytest.warns(DeprecationWarning, match="req.reply"):
            result = req.reply("legacy 응답")

        legacy_transport.send_message.assert_called_once_with("ch1", "legacy 응답")
        assert result == {"ok": True}

    def test_sync_reply_no_channel_raises_error(self):
        """채널 정보가 없으면 ValueError 발생."""
        import pytest

        req = SocketModeRequest(
            envelope_id="3",
            type="message",
            payload={"text": "hello"},
            service="messenger",
            action="create"
        )
        req._is_async = False
        req._web_client = "dummy"  # non-None

        with pytest.raises(ValueError, match="Channel information not found"):
            req.reply("test")

    def test_sync_reply_no_client_raises_error(self):
        """_web_client도 _sync_reply_func도 없으면 RuntimeError 발생."""
        import pytest

        req = SocketModeRequest(
            envelope_id="4",
            type="message",
            payload={"text": "hello", "channelId": "ch1"},
            service="messenger",
            action="create"
        )
        req._is_async = False

        with pytest.raises(RuntimeError, match="reply\\(\\) can only be used inside a handler"):
            req.reply("test")


class TestActorLazyLoading:
    """
    ActorWrapper lazy loading 테스트.

    organizationMember 타입 actor의 상세 정보를 API로 가져오는 기능 테스트.
    새 API: req.actor.organizationMember.name (sync/async 모두 지원)
    """

    @pytest.fixture(autouse=True)
    def clear_cache(self):
        """각 테스트 전에 캐시 클리어."""
        from dooray_sdk.socket_mode.request import clear_member_cache
        clear_member_cache()
        yield
        clear_member_cache()

    def test_async_field_access(self):
        """await로 필드 접근 시 async fetch."""
        import asyncio
        from unittest.mock import AsyncMock, MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper

        async def run_test():
            mock_client = MagicMock()
            mock_client.get_member = AsyncMock(return_value={
                "id": "user123",
                "name": "홍길동",
                "externalEmailAddress": "hong@company.com"
            })

            actor = ActorWrapper(
                {"type": "organizationMember", "organizationMember": {"id": "user123"}},
                web_client=mock_client
            )

            # await로 필드 접근
            name = await actor.organizationMember.name
            email = await actor.organizationMember.externalEmailAddress

            assert name == "홍길동"
            assert email == "hong@company.com"
            # 캐시 덕분에 한 번만 호출
            assert mock_client.get_member.call_count == 1

        asyncio.run(run_test())

    def test_await_whole_member_data(self):
        """await로 전체 멤버 데이터 접근."""
        import asyncio
        from unittest.mock import AsyncMock, MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper, DataWrapper

        async def run_test():
            mock_client = MagicMock()
            mock_client.get_member = AsyncMock(return_value={
                "id": "user123",
                "name": "홍길동",
                "externalEmailAddress": "hong@company.com"
            })

            actor = ActorWrapper(
                {"type": "organizationMember", "organizationMember": {"id": "user123"}},
                web_client=mock_client
            )

            # await로 전체 데이터 접근
            result = await actor.organizationMember

            assert isinstance(result, DataWrapper)
            assert result.name == "홍길동"
            assert result.externalEmailAddress == "hong@company.com"

        asyncio.run(run_test())

    def test_sync_field_access_with_str(self):
        """str()로 필드 접근 시 sync fetch."""
        from unittest.mock import MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper

        mock_client = MagicMock()
        mock_client.get_member = MagicMock(return_value={
            "id": "user123",
            "name": "홍길동"
        })

        actor = ActorWrapper(
            {"type": "organizationMember", "organizationMember": {"id": "user123"}},
            web_client=mock_client
        )

        # str()로 sync 접근
        name = str(actor.organizationMember.name)

        assert name == "홍길동"
        mock_client.get_member.assert_called_once_with("user123")

    def test_sync_field_comparison(self):
        """== 비교 시 sync fetch."""
        from unittest.mock import MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper

        mock_client = MagicMock()
        mock_client.get_member = MagicMock(return_value={
            "id": "user123",
            "name": "홍길동"
        })

        actor = ActorWrapper(
            {"type": "organizationMember", "organizationMember": {"id": "user123"}},
            web_client=mock_client
        )

        # == 비교 시 sync fetch
        assert actor.organizationMember.name == "홍길동"
        mock_client.get_member.assert_called_once_with("user123")

    def test_sync_field_string_concatenation(self):
        """+ 연산자로 문자열 연결 시 sync fetch."""
        from unittest.mock import MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper, clear_member_cache

        clear_member_cache()

        mock_client = MagicMock()
        mock_client.get_member = MagicMock(return_value={
            "id": "user123",
            "name": "홍길동"
        })

        actor = ActorWrapper(
            {"type": "organizationMember", "organizationMember": {"id": "user123"}},
            web_client=mock_client
        )

        # field + str
        result1 = actor.organizationMember.name + "님 안녕하세요"
        assert result1 == "홍길동님 안녕하세요"

        # str + field
        result2 = "안녕하세요 " + actor.organizationMember.name
        assert result2 == "안녕하세요 홍길동"

        mock_client.get_member.assert_called_once_with("user123")

    def test_local_data_returned_immediately(self):
        """로컬 데이터(메시지에 포함된 정보)는 API 호출 없이 즉시 반환."""
        from unittest.mock import MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper

        mock_client = MagicMock()

        actor = ActorWrapper(
            {"type": "organizationMember", "organizationMember": {"id": "user123"}},
            web_client=mock_client
        )

        # id는 로컬 데이터이므로 API 호출 없이 즉시 반환
        assert actor.organizationMember.id == "user123"
        mock_client.get_member.assert_not_called()

    def test_caches_result(self):
        """두 번째 호출은 캐시된 데이터 사용."""
        import asyncio
        from unittest.mock import AsyncMock, MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper

        async def run_test():
            mock_client = MagicMock()
            mock_client.get_member = AsyncMock(return_value={
                "id": "user123",
                "name": "홍길동"
            })

            actor = ActorWrapper(
                {"type": "organizationMember", "organizationMember": {"id": "user123"}},
                web_client=mock_client
            )

            # First call
            await actor.organizationMember.name

            # Second call - 캐시 사용
            await actor.organizationMember.name

            # API는 한 번만 호출
            assert mock_client.get_member.call_count == 1

        asyncio.run(run_test())

    def test_global_cache_shared(self):
        """다른 ActorWrapper 인스턴스도 글로벌 캐시 공유."""
        import asyncio
        from unittest.mock import AsyncMock, MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper

        async def run_test():
            mock_client = MagicMock()
            mock_client.get_member = AsyncMock(return_value={
                "id": "user123",
                "name": "홍길동"
            })

            actor1 = ActorWrapper(
                {"type": "organizationMember", "organizationMember": {"id": "user123"}},
                web_client=mock_client
            )
            actor2 = ActorWrapper(
                {"type": "organizationMember", "organizationMember": {"id": "user123"}},
                web_client=mock_client
            )

            # First actor fetches
            await actor1.organizationMember.name

            # Second actor uses cache
            name = await actor2.organizationMember.name

            # API는 한 번만 호출
            assert mock_client.get_member.call_count == 1
            assert name == "홍길동"

        asyncio.run(run_test())

    def test_non_organization_member_returns_data_wrapper(self):
        """organizationMember가 아닌 타입은 DataWrapper 반환."""
        from dooray_sdk.socket_mode.request import ActorWrapper, DataWrapper

        actor = ActorWrapper(
            {"type": "bot", "bot": {"id": "bot123", "name": "MyBot"}},
            web_client=None
        )

        # bot 타입은 DataWrapper 반환 (LazyMemberData 아님)
        result = actor.bot
        assert isinstance(result, DataWrapper)
        assert result.id == "bot123"
        assert result.name == "MyBot"

    def test_no_web_client_returns_data_wrapper(self):
        """web_client가 없으면 DataWrapper 반환 (하위 호환)."""
        from dooray_sdk.socket_mode.request import ActorWrapper, DataWrapper

        actor = ActorWrapper(
            {"type": "organizationMember", "organizationMember": {"id": "user123"}},
            web_client=None
        )

        # web_client 없으면 DataWrapper 반환
        result = actor.organizationMember
        assert isinstance(result, DataWrapper)
        assert result.id == "user123"

    def test_api_error_propagates(self):
        """API 에러가 전파됨."""
        import asyncio
        from unittest.mock import AsyncMock, MagicMock
        from dooray_sdk.socket_mode.request import ActorWrapper
        from dooray_sdk.exceptions import DoorayRequestError

        async def run_test():
            mock_client = MagicMock()
            mock_client.get_member = AsyncMock(side_effect=DoorayRequestError(
                "Not Found",
                status_code=404,
                error_code="NOT_FOUND"
            ))

            actor = ActorWrapper(
                {"type": "organizationMember", "organizationMember": {"id": "nonexistent"}},
                web_client=mock_client
            )

            with pytest.raises(DoorayRequestError):
                await actor.organizationMember.name

        asyncio.run(run_test())

    def test_existing_properties_unchanged(self):
        """기존 속성들은 정상 작동 (하위 호환)."""
        from dooray_sdk.socket_mode.request import ActorWrapper

        actor = ActorWrapper(
            {"type": "organizationMember", "organizationMember": {"id": "user123", "name": "Test"}},
            web_client=None
        )

        # 기존 속성들
        assert actor.type == "organizationMember"
        assert actor.id == "user123"
        assert actor.data.name == "Test"
        assert actor.raw == {"type": "organizationMember", "organizationMember": {"id": "user123", "name": "Test"}}

    def test_actor_wrapper_with_socket_mode_request(self):
        """SocketModeRequest 내에서 ActorWrapper 동작 테스트."""
        from unittest.mock import MagicMock

        mock_client = MagicMock()

        req = SocketModeRequest(
            envelope_id="test-001",
            type="message",
            payload={"text": "hello"},
            service="messenger",
            action="create",
            actor={"type": "organizationMember", "organizationMember": {"id": "user123"}},
            _web_client=mock_client
        )

        # actor가 ActorWrapper로 변환됨
        assert req.actor.type == "organizationMember"
        assert req.actor.id == "user123"
        # web_client가 주입됨
        assert req.actor._web_client == mock_client
