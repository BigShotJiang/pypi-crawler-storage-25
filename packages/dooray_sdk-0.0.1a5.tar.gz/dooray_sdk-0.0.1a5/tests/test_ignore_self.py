"""
봇 자체 메시지 필터링 (ignore_self) 테스트
"""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch
from dooray_sdk.socket_mode.request import SocketModeRequest


class TestIgnoreSelf:
    """Agent의 ignore_self 기능 테스트."""

    @pytest.fixture
    def agent(self):
        """ignore_self=True (기본값) Agent 인스턴스."""
        with patch.dict('os.environ', {
            'DOORAY_BOT_TOKEN': 'test-token',
            'DOORAY_DOMAIN': 'test.dooray.com'
        }):
            from dooray_sdk.agent import Agent
            agent = Agent()
            agent._agent_member_id = "agent-member-123"
            agent._loop = asyncio.new_event_loop()
            agent._message_client = AsyncMock()
            return agent

    @pytest.fixture
    def agent_no_ignore(self):
        """ignore_self=False Agent 인스턴스."""
        with patch.dict('os.environ', {
            'DOORAY_BOT_TOKEN': 'test-token',
            'DOORAY_DOMAIN': 'test.dooray.com'
        }):
            from dooray_sdk.agent import Agent
            agent = Agent(ignore_self=False)
            agent._agent_member_id = "agent-member-123"
            agent._loop = asyncio.new_event_loop()
            agent._message_client = AsyncMock()
            return agent

    def _make_request(self, sender_id=None, actor_id=None, text="hello"):
        """테스트용 SocketModeRequest 생성."""
        payload = {"text": text, "channelId": "ch-1"}
        if sender_id:
            payload["senderId"] = sender_id

        actor_data = None
        if actor_id:
            actor_data = {"type": "organizationMember", "organizationMember": {"id": actor_id}}

        return SocketModeRequest(
            envelope_id="env-1",
            type="message",
            payload=payload,
            service="messenger",
            actor=actor_data,
        )

    def test_ignore_self_default_true(self):
        """ignore_self 기본값은 True."""
        with patch.dict('os.environ', {
            'DOORAY_BOT_TOKEN': 'test-token',
            'DOORAY_DOMAIN': 'test.dooray.com'
        }):
            from dooray_sdk.agent import Agent
            agent = Agent()
            assert agent._ignore_self is True

    def test_ignore_self_explicit_false(self):
        """ignore_self=False 명시적 설정."""
        with patch.dict('os.environ', {
            'DOORAY_BOT_TOKEN': 'test-token',
            'DOORAY_DOMAIN': 'test.dooray.com'
        }):
            from dooray_sdk.agent import Agent
            agent = Agent(ignore_self=False)
            assert agent._ignore_self is False

    @pytest.mark.asyncio
    async def test_self_message_filtered_by_sender_id(self, agent):
        """봇 자신의 senderId로 온 메시지가 필터링되는지 확인."""
        handler = MagicMock()
        agent.add_handler("message", handler)

        req = self._make_request(sender_id="agent-member-123", text="agent message")
        client = AsyncMock()

        await agent._dispatch(client, req)

        handler.assert_not_called()

    @pytest.mark.asyncio
    async def test_self_message_filtered_by_actor_id(self, agent):
        """봇 자신의 actor.id로 온 메시지가 필터링되는지 확인."""
        handler = MagicMock()
        agent.add_handler("message", handler)

        req = self._make_request(actor_id="agent-member-123", text="agent message")
        client = AsyncMock()

        await agent._dispatch(client, req)

        handler.assert_not_called()

    @pytest.mark.asyncio
    async def test_other_message_not_filtered(self, agent):
        """다른 사용자의 메시지는 정상 전달되는지 확인."""
        handler = AsyncMock()
        agent.add_handler("message", handler)

        req = self._make_request(sender_id="other-user-456", text="user message")
        client = AsyncMock()

        await agent._dispatch(client, req)

        handler.assert_called_once()

    @pytest.mark.asyncio
    async def test_ignore_self_false_passes_agent_message(self, agent_no_ignore):
        """ignore_self=False일 때 봇 메시지도 핸들러에 전달되는지 확인."""
        handler = AsyncMock()
        agent_no_ignore.add_handler("message", handler)

        req = self._make_request(sender_id="agent-member-123", text="agent message")
        client = AsyncMock()

        await agent_no_ignore._dispatch(client, req)

        handler.assert_called_once()

    @pytest.mark.asyncio
    async def test_ack_sent_before_filtering(self, agent):
        """봇 메시지 필터링 전에 ACK가 전송되는지 확인."""
        handler = MagicMock()
        agent.add_handler("message", handler)

        req = self._make_request(sender_id="agent-member-123", text="agent message")
        client = AsyncMock()

        await agent._dispatch(client, req)

        # ACK는 전송되어야 함
        client.send_socket_mode_response.assert_called_once()
        # 핸들러는 호출되지 않아야 함
        handler.assert_not_called()

    @pytest.mark.asyncio
    async def test_no_agent_member_id_no_filtering(self, agent):
        """agent_member_id가 없으면 필터링하지 않음."""
        agent._agent_member_id = None

        handler = AsyncMock()
        agent.add_handler("message", handler)

        req = self._make_request(sender_id="any-sender", text="message")
        client = AsyncMock()

        await agent._dispatch(client, req)

        handler.assert_called_once()

    @pytest.mark.asyncio
    async def test_no_sender_id_no_filtering(self, agent):
        """senderId와 actor.id 모두 없는 메시지는 필터링하지 않음."""
        handler = AsyncMock()
        agent.add_handler("message", handler)

        req = self._make_request(text="message without sender")
        client = AsyncMock()

        await agent._dispatch(client, req)

        handler.assert_called_once()


class TestConnectionManagerMemberId:
    """ConnectionManager의 member_id 프로퍼티 테스트."""

    def test_member_id_from_client(self):
        """연결된 클라이언트에서 member_id를 가져오는지 확인."""
        from dooray_sdk.socket_mode.connection_manager import ConnectionManager

        manager = ConnectionManager(
            web_client=MagicMock(),
            domain="test.dooray.com",
        )

        mock_client = MagicMock()
        mock_client._member_id = "agent-member-123"
        manager._clients["messenger"] = mock_client

        assert manager.member_id == "agent-member-123"

    def test_member_id_none_when_no_clients(self):
        """클라이언트가 없을 때 None 반환."""
        from dooray_sdk.socket_mode.connection_manager import ConnectionManager

        manager = ConnectionManager(
            web_client=MagicMock(),
            domain="test.dooray.com",
        )

        assert manager.member_id is None

    def test_member_id_none_when_client_has_no_id(self):
        """클라이언트의 member_id가 None일 때 None 반환."""
        from dooray_sdk.socket_mode.connection_manager import ConnectionManager

        manager = ConnectionManager(
            web_client=MagicMock(),
            domain="test.dooray.com",
        )

        mock_client = MagicMock()
        mock_client._member_id = None
        manager._clients["messenger"] = mock_client

        assert manager.member_id is None
