"""
서비스 레지스트리 테스트
"""

import pytest
from dooray_sdk.socket_mode.registry import (
    SERVICE_REGISTRY,
    SUPPORTED_SERVICES,
    SUPPORTED_ACTIONS,
    get_service_mapping,
    register_service,
    is_supported_service,
    is_supported_action,
    ServiceMapping,
)


class TestServiceRegistry:
    """서비스 레지스트리 테스트."""

    def test_default_registry_has_messenger(self):
        """기본 레지스트리에 messenger 포함."""
        assert "messenger/channelLog" in SERVICE_REGISTRY
        mapping = SERVICE_REGISTRY["messenger/channelLog"]
        assert mapping.service == "messenger"
        assert mapping.type == "message"

    def test_default_registry_has_task(self):
        """기본 레지스트리에 task 포함."""
        assert "task/task" in SERVICE_REGISTRY
        mapping = SERVICE_REGISTRY["task/task"]
        assert mapping.service == "task"
        assert mapping.type == "task"

    def test_default_registry_has_wiki(self):
        """기본 레지스트리에 wiki 포함."""
        assert "wiki/page" in SERVICE_REGISTRY
        mapping = SERVICE_REGISTRY["wiki/page"]
        assert mapping.service == "wiki"
        assert mapping.type == "page"


class TestGetServiceMapping:
    """get_service_mapping 함수 테스트."""

    def test_get_messenger_mapping(self):
        """메신저 매핑 조회."""
        mapping = get_service_mapping("messenger", "channelLog")
        assert mapping is not None
        assert mapping.service == "messenger"
        assert mapping.type == "message"

    def test_get_task_mapping(self):
        """업무 매핑 조회."""
        mapping = get_service_mapping("task", "task")
        assert mapping is not None
        assert mapping.service == "task"
        assert mapping.type == "task"

    def test_get_wiki_mapping(self):
        """위키 매핑 조회."""
        mapping = get_service_mapping("wiki", "page")
        assert mapping is not None
        assert mapping.service == "wiki"
        assert mapping.type == "page"

    def test_get_unknown_mapping(self):
        """알 수 없는 타입 조회."""
        mapping = get_service_mapping("unknown", "unknownType")
        assert mapping is None


class TestRegisterService:
    """register_service 함수 테스트."""

    def test_register_new_service(self):
        """새 서비스 등록."""
        # 새 서비스 등록
        register_service("calendar", "event", "event")

        # 등록 확인
        mapping = get_service_mapping("calendar", "event")
        assert mapping is not None
        assert mapping.service == "calendar"
        assert mapping.type == "event"

        # 지원 서비스 목록에 추가 확인
        assert "calendar" in SUPPORTED_SERVICES

        # 정리 (테스트 격리)
        del SERVICE_REGISTRY["calendar/event"]
        SUPPORTED_SERVICES.remove("calendar")


class TestSupportedChecks:
    """지원 여부 확인 테스트."""

    def test_is_supported_service_messenger(self):
        """messenger 지원 확인."""
        assert is_supported_service("messenger") is True

    def test_is_supported_service_task(self):
        """task 지원 확인."""
        assert is_supported_service("task") is True

    def test_is_supported_service_wiki(self):
        """wiki 지원 확인."""
        assert is_supported_service("wiki") is True

    def test_is_supported_service_unknown(self):
        """알 수 없는 서비스 확인."""
        assert is_supported_service("unknown") is False

    def test_is_supported_action_create(self):
        """create 액션 지원 확인."""
        assert is_supported_action("create") is True

    def test_is_supported_action_update(self):
        """update 액션 지원 확인."""
        assert is_supported_action("update") is True

    def test_is_supported_action_delete(self):
        """delete 액션 지원 확인."""
        assert is_supported_action("delete") is True

    def test_is_supported_action_comment(self):
        """comment 액션 지원 확인."""
        assert is_supported_action("comment") is True

    def test_is_supported_action_unknown(self):
        """알 수 없는 액션 확인."""
        assert is_supported_action("unknown") is False


class TestServiceMapping:
    """ServiceMapping 데이터클래스 테스트."""

    def test_create_service_mapping(self):
        """ServiceMapping 생성."""
        mapping = ServiceMapping(service="test", type="test_type")
        assert mapping.service == "test"
        assert mapping.type == "test_type"

    def test_service_mapping_equality(self):
        """ServiceMapping 동등성."""
        mapping1 = ServiceMapping(service="test", type="test_type")
        mapping2 = ServiceMapping(service="test", type="test_type")
        assert mapping1 == mapping2
