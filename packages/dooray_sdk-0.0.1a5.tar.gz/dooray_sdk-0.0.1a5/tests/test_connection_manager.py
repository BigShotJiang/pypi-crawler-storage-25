"""Tests for ConnectionManager error propagation.

These tests verify the error propagation behavior of ConnectionManager.
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from dooray_sdk.exceptions import DoorayConnectionError
from dooray_sdk.socket_mode.connection_manager import (
    ConnectionManager,
    SERVICE_WS_CONFIG,
)


def _run_async(coro):
    """Helper to run async tests without pytest-asyncio."""
    return asyncio.run(coro)


class TestConnectionManagerErrorPropagation:
    """Tests for ConnectionManager._connect_service error propagation."""

    @pytest.fixture
    def mock_web_client(self):
        """Create a mock AsyncWebClient."""
        return MagicMock()

    @pytest.fixture
    def connection_manager(self, mock_web_client):
        """Create a ConnectionManager instance."""
        return ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

    def test_connect_service_raises_dooray_connection_error(
        self, connection_manager
    ):
        """Test that _connect_service raises DoorayConnectionError on failure."""
        mock_client = MagicMock()
        mock_client.connect = AsyncMock(side_effect=ConnectionError("Network error"))

        with pytest.raises(DoorayConnectionError) as exc_info:
            _run_async(connection_manager._connect_service("messenger", mock_client))

        error = exc_info.value
        assert error.service == "messenger"
        assert error.error_code == "CONNECTION_FAILED"
        assert "original_error" in error.context
        assert "Network error" in error.context["original_error"]

    def test_connect_service_exception_chaining(self, connection_manager):
        """Test that exception chaining works via __cause__."""
        original_error = ValueError("Original connection error")
        mock_client = MagicMock()
        mock_client.connect = AsyncMock(side_effect=original_error)

        with pytest.raises(DoorayConnectionError) as exc_info:
            _run_async(connection_manager._connect_service("messenger", mock_client))

        error = exc_info.value
        assert error.__cause__ is original_error

    def test_connect_service_success(self, connection_manager):
        """Test that _connect_service succeeds when no error occurs."""
        mock_client = MagicMock()
        mock_client.connect = AsyncMock()

        # Should not raise
        _run_async(connection_manager._connect_service("messenger", mock_client))
        mock_client.connect.assert_called_once()


class TestConnectAllErrorHandling:
    """Tests for ConnectionManager.connect_all error handling."""

    @pytest.fixture
    def mock_web_client(self):
        """Create a mock AsyncWebClient."""
        return MagicMock()

    @pytest.fixture
    def connection_manager(self, mock_web_client):
        """Create a ConnectionManager instance with single service."""
        return ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

    def test_connect_all_raise_on_failure_true(self, mock_web_client):
        """Test that connect_all raises exception when raise_on_failure=True."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        async def run_test():
            with patch.object(
                manager,
                "_connect_service",
                side_effect=DoorayConnectionError(
                    "Connection failed",
                    service="messenger",
                    error_code="CONNECTION_FAILED",
                ),
            ):
                with pytest.raises(DoorayConnectionError) as exc_info:
                    await manager.connect_all(raise_on_failure=True)

                assert exc_info.value.service == "messenger"

        _run_async(run_test())

    def test_connect_all_raise_on_failure_false(self, mock_web_client):
        """Test that connect_all returns results when raise_on_failure=False."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        test_error = DoorayConnectionError(
            "Connection failed",
            service="messenger",
            error_code="CONNECTION_FAILED",
        )

        async def run_test():
            with patch.object(manager, "_connect_service", side_effect=test_error):
                results = await manager.connect_all(raise_on_failure=False)

                assert "messenger" in results
                assert results["messenger"] is test_error

        _run_async(run_test())

    def test_connect_all_success_returns_none_for_service(self, mock_web_client):
        """Test that connect_all returns None for successful connections."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        async def run_test():
            with patch.object(manager, "_connect_service", new_callable=AsyncMock):
                results = await manager.connect_all(raise_on_failure=True)

                assert "messenger" in results
                assert results["messenger"] is None

        _run_async(run_test())

    def test_connect_all_default_raises_on_failure(self, mock_web_client):
        """Test that connect_all raises by default (raise_on_failure=True is default)."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        async def run_test():
            with patch.object(
                manager,
                "_connect_service",
                side_effect=DoorayConnectionError(
                    "Connection failed",
                    service="messenger",
                    error_code="CONNECTION_FAILED",
                ),
            ):
                # Default behavior should raise
                with pytest.raises(DoorayConnectionError):
                    await manager.connect_all()

        _run_async(run_test())


class TestConnectionManagerBackwardCompatibility:
    """Tests ensuring backward compatibility of connect_all changes."""

    @pytest.fixture
    def mock_web_client(self):
        """Create a mock AsyncWebClient."""
        return MagicMock()

    def test_connect_all_can_be_called_without_arguments(self, mock_web_client):
        """Test that connect_all can still be called without any arguments."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        async def run_test():
            with patch.object(manager, "_connect_service", new_callable=AsyncMock):
                # Should work without arguments
                results = await manager.connect_all()
                assert isinstance(results, dict)

        _run_async(run_test())

    def test_connect_all_returns_dict(self, mock_web_client):
        """Test that connect_all returns a dict (new behavior)."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        async def run_test():
            with patch.object(manager, "_connect_service", new_callable=AsyncMock):
                results = await manager.connect_all()
                assert isinstance(results, dict)

        _run_async(run_test())


class TestConnectionErrorAttributes:
    """Tests verifying DoorayConnectionError attributes are properly set."""

    @pytest.fixture
    def mock_web_client(self):
        """Create a mock AsyncWebClient."""
        return MagicMock()

    def test_error_contains_service_name(self, mock_web_client):
        """Test that raised error contains the service name."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        mock_client = MagicMock()
        mock_client.connect = AsyncMock(side_effect=Exception("Test error"))

        with pytest.raises(DoorayConnectionError) as exc_info:
            _run_async(manager._connect_service("messenger", mock_client))

        assert exc_info.value.service == "messenger"

    def test_error_contains_error_code(self, mock_web_client):
        """Test that raised error contains CONNECTION_FAILED error code."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        mock_client = MagicMock()
        mock_client.connect = AsyncMock(side_effect=Exception("Test error"))

        with pytest.raises(DoorayConnectionError) as exc_info:
            _run_async(manager._connect_service("messenger", mock_client))

        assert exc_info.value.error_code == "CONNECTION_FAILED"

    def test_error_context_contains_original_error(self, mock_web_client):
        """Test that raised error context contains original error string."""
        manager = ConnectionManager(
            web_client=mock_web_client,
            domain="test.dooray.com",
            services=["messenger"],
        )

        mock_client = MagicMock()
        mock_client.connect = AsyncMock(side_effect=Exception("Specific error message"))

        with pytest.raises(DoorayConnectionError) as exc_info:
            _run_async(manager._connect_service("messenger", mock_client))

        assert "original_error" in exc_info.value.context
        assert "Specific error message" in exc_info.value.context["original_error"]
