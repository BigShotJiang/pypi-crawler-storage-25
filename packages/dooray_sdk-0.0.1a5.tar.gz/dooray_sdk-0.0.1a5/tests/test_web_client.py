"""
Tests for WebClient
"""

import pytest
from unittest.mock import Mock, patch
from dooray_sdk.web import WebClient


class TestWebClient:
    """Test cases for WebClient."""
    
    def test_init(self):
        """Test WebClient initialization."""
        client = WebClient(token="test_token")
        assert client.token == "test_token"
        assert client.base_url == "https://api.dooray.com/"
        assert client.timeout == 30
    
    def test_init_with_custom_params(self):
        """Test WebClient initialization with custom parameters."""
        client = WebClient(
            token="test_token",
            base_url="https://custom.dooray.com",
            timeout=60
        )
        assert client.token == "test_token"
        assert client.base_url == "https://custom.dooray.com/"
        assert client.timeout == 60
    
    @patch('dooray_sdk.web.client.requests.Session.request')
    def test_send_message(self, mock_request):
        """Test sending a message."""
        mock_response = Mock()
        expected_data = {"ok": True}
        mock_response.json.return_value = expected_data
        mock_request.return_value = mock_response

        client = WebClient(token="test_token")
        response = client.send_message(channel="test_channel", text="Hello")

        mock_request.assert_called_once()
        assert response == expected_data

    @patch('dooray_sdk.web.client.requests.Session.request')
    def test_get_channels(self, mock_request):
        """Test getting channels."""
        mock_response = Mock()
        expected_data = {"channels": []}
        mock_response.json.return_value = expected_data
        mock_request.return_value = mock_response

        client = WebClient(token="test_token")
        response = client.get_channels()

        mock_request.assert_called_once()
        assert response == expected_data

    @patch('dooray_sdk.web.client.requests.Session.request')
    def test_get_messages(self, mock_request):
        """Test getting messages."""
        mock_response = Mock()
        expected_data = {"messages": []}
        mock_response.json.return_value = expected_data
        mock_request.return_value = mock_response

        client = WebClient(token="test_token")
        response = client.get_messages(channel="test_channel", limit=10)

        mock_request.assert_called_once()
        assert response == expected_data

    @patch('dooray_sdk.web.client.requests.Session.request')
    def test_get_user_info(self, mock_request):
        """Test getting user info."""
        mock_response = Mock()
        expected_data = {"user": {"id": "test_user"}}
        mock_response.json.return_value = expected_data
        mock_request.return_value = mock_response

        client = WebClient(token="test_token")
        response = client.get_user_info()

        mock_request.assert_called_once()
        assert response == expected_data
