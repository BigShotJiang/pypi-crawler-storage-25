"""
MessengerAPI / AsyncMessengerAPI 테스트 (PRD 11446 / ADR-003, ADR-006, ADR-007)

검증 대상:
- send_message: 올바른 path/method/body
- reply_to_message: POST /messenger/v1/channels/{channel}/logs/{message_id}/reply
- reply_in_thread: NotImplementedError (메시지에 'ADR-007' 포함)

외부 Dooray 서비스에 의존하지 않는다 — 모든 HTTP는 mock.
"""

import asyncio

import pytest
from unittest.mock import AsyncMock, MagicMock

from dooray_sdk.web.messenger import (
    AsyncMessengerAPI,
    MessengerAPI,
)


# ---------------------------------------------------------------------------
# Async 짝
# ---------------------------------------------------------------------------


class TestAsyncMessengerAPI:
    """AsyncMessengerAPI 동작 검증."""

    @pytest.fixture
    def mock_transport(self):
        """AsyncWebClient를 흉내내는 mock. ``post`` 만 사용된다."""
        transport = MagicMock()
        transport.post = AsyncMock(return_value={"header": {"isSuccessful": True}})
        return transport

    @pytest.fixture
    def api(self, mock_transport):
        return AsyncMessengerAPI(mock_transport)

    def test_send_message_calls_correct_endpoint(self, api, mock_transport):
        """send_message → POST /messenger/v1/channels/{channel}/logs."""
        asyncio.run(api.send_message(channel="ch-1", text="hello"))

        mock_transport.post.assert_called_once()
        args, kwargs = mock_transport.post.call_args
        assert args[0] == "/messenger/v1/channels/ch-1/logs"
        assert kwargs["data"] == {"text": "hello"}

    def test_send_message_passes_extra_body_fields(self, api, mock_transport):
        """추가 **kwargs 는 body에 병합된다."""
        asyncio.run(api.send_message(channel="ch-1", text="hi", attachments=[1, 2]))
        _, kwargs = mock_transport.post.call_args
        assert kwargs["data"] == {"text": "hi", "attachments": [1, 2]}

    def test_reply_to_message_uses_reply_endpoint(self, api, mock_transport):
        """ADR-006: POST /messenger/v1/channels/{channel}/logs/{message_id}/reply."""
        asyncio.run(
            api.reply_to_message(
                channel="ch-X", message_id="log-42", text="quoted reply"
            )
        )

        mock_transport.post.assert_called_once()
        args, kwargs = mock_transport.post.call_args
        assert args[0] == "/messenger/v1/channels/ch-X/logs/log-42/reply"
        assert kwargs["data"] == {"text": "quoted reply"}

    def test_reply_in_thread_raises_not_implemented_with_adr_marker(self, api):
        """ADR-007: reply_in_thread 호출 시 NotImplementedError + ADR-007 마커."""
        with pytest.raises(NotImplementedError) as excinfo:
            asyncio.run(api.reply_in_thread(parent_channel_id="thread-1", text="x"))

        # 메시지에 ADR-007 및 대체 동사 안내가 포함되어 있어야 함.
        msg = str(excinfo.value)
        assert "ADR-007" in msg
        assert "send_message" in msg
        assert "reply_to_message" in msg


# ---------------------------------------------------------------------------
# Sync 짝 (ADR-003 동기/비동기 짝 강제)
# ---------------------------------------------------------------------------


class TestMessengerAPI:
    """동기 MessengerAPI — Async 짝과 1:1 표면."""

    @pytest.fixture
    def mock_transport(self):
        transport = MagicMock()
        transport.post = MagicMock(return_value={"header": {"isSuccessful": True}})
        return transport

    @pytest.fixture
    def api(self, mock_transport):
        return MessengerAPI(mock_transport)

    def test_send_message_calls_correct_endpoint(self, api, mock_transport):
        api.send_message(channel="ch-1", text="hello")

        mock_transport.post.assert_called_once()
        args, kwargs = mock_transport.post.call_args
        assert args[0] == "/messenger/v1/channels/ch-1/logs"
        assert kwargs["data"] == {"text": "hello"}

    def test_reply_to_message_uses_reply_endpoint(self, api, mock_transport):
        api.reply_to_message(channel="ch-X", message_id="log-42", text="quoted")

        args, kwargs = mock_transport.post.call_args
        assert args[0] == "/messenger/v1/channels/ch-X/logs/log-42/reply"
        assert kwargs["data"] == {"text": "quoted"}

    def test_reply_in_thread_raises_not_implemented_with_adr_marker(self, api):
        with pytest.raises(NotImplementedError) as excinfo:
            api.reply_in_thread(parent_channel_id="thread-1", text="x")
        assert "ADR-007" in str(excinfo.value)


# ---------------------------------------------------------------------------
# AsyncWebClient.messenger property 통합
# ---------------------------------------------------------------------------


class TestAsyncWebClientMessengerNamespace:
    """AsyncWebClient.messenger 가 AsyncMessengerAPI 인스턴스를 반환한다."""

    def test_messenger_property_returns_async_messenger_api(self):
        from dooray_sdk.web.async_client import AsyncWebClient

        client = AsyncWebClient(token="t")
        assert isinstance(client.messenger, AsyncMessengerAPI)

    def test_messenger_property_is_cached(self):
        """매번 새 인스턴스가 아니라 동일 인스턴스를 반환해야 함 (lazy + cache)."""
        from dooray_sdk.web.async_client import AsyncWebClient

        client = AsyncWebClient(token="t")
        assert client.messenger is client.messenger


class TestWebClientMessengerNamespace:
    """WebClient.messenger 가 MessengerAPI 인스턴스를 반환한다."""

    def test_messenger_property_returns_messenger_api(self):
        from dooray_sdk.web.client import WebClient

        client = WebClient(token="t")
        assert isinstance(client.messenger, MessengerAPI)

    def test_messenger_property_is_cached(self):
        from dooray_sdk.web.client import WebClient

        client = WebClient(token="t")
        assert client.messenger is client.messenger
