"""
User-Agent 헤더 빌더.

WebClient와 AsyncWebClient에서 공통으로 사용합니다.

슬랙 SDK 패턴 참고:
    python-dooray-sdk/0.1.0 Python/3.11.4 Darwin/22.5.0
"""

import platform
import sys

from .__version__ import __version__


def _build_user_agent(
    prefix: str = None,
    suffix: str = None,
) -> str:
    """
    User-Agent 문자열을 빌드합니다.

    Args:
        prefix: User-Agent 앞에 붙일 커스텀 문자열
        suffix: User-Agent 뒤에 붙일 커스텀 문자열

    Returns:
        str: User-Agent 문자열

    Examples:
        >>> _build_user_agent()
        'python-dooray-sdk/0.1.0 Python/3.11.4 Darwin/22.5.0'

        >>> _build_user_agent(prefix="my-bot/1.0")
        'my-bot/1.0 python-dooray-sdk/0.1.0 Python/3.11.4 Darwin/22.5.0'
    """
    python_version = sys.version.split(" ")[0]
    os_info = f"{platform.system()}/{platform.release()}"

    ua = f"python-dooray-sdk/{__version__} Python/{python_version} {os_info}"

    if prefix:
        ua = f"{prefix} {ua}"
    if suffix:
        ua = f"{ua} {suffix}"

    return ua


# 기본 User-Agent (모듈 로드 시 한 번만 생성)
USER_AGENT = _build_user_agent()
