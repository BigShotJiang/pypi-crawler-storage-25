"""
Agent - 통합 에이전트 인터페이스

동기/비동기 핸들러를 모두 지원합니다.
내부는 비동기(asyncio)로 동작합니다.

Example:
    from dooray_sdk import Agent

    agent = Agent()
    agent.reply_to("ping", "pong")
    agent.run()

    # 서비스별 데코레이터
    @agent.messenger
    def handle_msg(req):
        req.reply("Hello!")

    # 통합 데코레이터
    @agent.on("message")
    async def handle_message(req):
        print(f"메시지: {req.text}")
"""

import os
import asyncio
import inspect
import logging
import warnings
import concurrent.futures
from typing import Callable, Dict, Any, List, Union, Optional, TYPE_CHECKING

from .exceptions import DoorayConfigurationError

if TYPE_CHECKING:
    from .web.messenger import AsyncMessengerAPI
    from .web.task import AsyncTaskAPI
    from .web.wiki import AsyncWikiAPI

logger = logging.getLogger(__name__)


class ServiceNamespace:
    """
    서비스별 듀얼 객체 (ADR-001).

    한 마이너 동안 두 의미를 동시에 지원한다:

    - **호출(``__call__``)** = 이벤트 구독 데코레이터 (구 `ServiceDecorator` 의미).
      ``@agent.messenger`` 로 사용 시 ``DeprecationWarning`` 과 함께 동작.
    - **속성 접근(``.send_message`` 등)** = 서비스 클라이언트 네임스페이스.
      내부 ``_api`` (예: AsyncMessengerAPI) 에 위임한다. 경고 없음.

    Example:
        @agent.messenger                    # 데코레이터 (deprecated)
        def handle(req): ...

        await agent.messenger.send_message(channel="X", text="hi")   # 신규 표면
    """

    def __init__(self, agent: "Agent", service: str, api: Optional[Any] = None):
        # __setattr__ 우회는 필요 없음. 단 _api는 lazy 채울 수 있으므로 noinspection 친화.
        self._agent = agent
        self._service = service
        self._api = api

    def __call__(self, func: Callable) -> Callable:
        """``@agent.<service>`` 사용 시 구독 데코레이터로 동작 (deprecated)."""
        warnings.warn(
            f"@agent.{self._service} decorator is deprecated. "
            f"Use @agent.on(service='{self._service}') instead. "
            f"agent.{self._service} now also exposes the service client namespace "
            f"(e.g. agent.{self._service}.send_message).",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._agent.on(service=self._service)(func)

    def __getattr__(self, name: str) -> Any:
        """API 속성 접근을 내부 API 객체로 위임 (신규 표면, 경고 없음)."""
        if name.startswith("_"):
            raise AttributeError(
                f"'{type(self).__name__}' has no attribute '{name}'"
            )
        api = object.__getattribute__(self, "_api")
        if api is None:
            raise AttributeError(
                f"agent.{self._service} client namespace is not initialized yet. "
                f"Call agent.run()/start()/connect() first, or access "
                f"`agent.{self._service}` after the agent is initialized."
            )
        return getattr(api, name)


# 하위호환 alias — 외부에서 ServiceDecorator를 import 하는 코드를 깨지 않기 위해.
ServiceDecorator = ServiceNamespace


class Agent:
    """
    통합 에이전트 클래스.

    - 동기/비동기 핸들러 모두 지원 (자동 감지)
    - 내부 동작: 비동기 (효율적)

    환경변수:
        DOORAY_AGENT_TOKEN: 에이전트 토큰 (또는 DOORAY_BOT_TOKEN)
        DOORAY_DOMAIN: 두레이 도메인
        DOORAY_SERVICES: 서비스 목록 (쉼표 구분, 기본값: messenger)

    Example:
        agent = Agent()

        # 동기 핸들러
        @agent.messenger
        def handle(req):
            req.reply("Hello!")

        # 비동기 핸들러
        @agent.messenger
        async def handle(req):
            await req.reply("Hello!")

        agent.run()
    """

    def __init__(
        self,
        token: str = None,
        domain: str = None,
        services: List[str] = None,
        bot_token: str = None,  # DoorayClient 호환
        ignore_self: bool = True,
        auto_reconnect_enabled: bool = True,
        **kwargs
    ):
        # token 또는 bot_token 모두 허용 (하위 호환성)
        self.token = token or bot_token or os.environ.get("DOORAY_AGENT_TOKEN") or os.environ.get("DOORAY_BOT_TOKEN")
        self.domain = domain or os.environ.get("DOORAY_DOMAIN")

        # 서비스 목록 (환경변수 또는 파라미터)
        if services:
            self.services = services
        else:
            env_services = os.environ.get("DOORAY_SERVICES", "messenger")
            self.services = [s.strip() for s in env_services.split(",")]

        # Auto-reconnect 옵션은 ConnectionManager → SocketModeClient로 전달.
        self.auto_reconnect_enabled = auto_reconnect_enabled
        # SocketModeClient에 전달할 추가 kwargs (e.g. reconnect_*).
        # 사용자가 Agent 생성 시 미리 backoff 파라미터를 줄 수 있게 보존.
        self._socket_kwargs: Dict[str, Any] = dict(kwargs)

        # Validate configuration
        self._validate_config()

        # domain에서 API base URL 파싱
        # nhnent.dev.dooray.com → https://api.dev.dooray.com
        # self.gov-dooray.com → https://api.gov-dooray.com
        # company.dooray.com → https://api.dooray.com
        self.base_url = self._parse_api_base_url(self.domain)

        # 에이전트 자체 메시지 필터링
        self._ignore_self = ignore_self
        self._agent_member_id: Optional[str] = None

        # 이벤트 타입별 핸들러
        self._handlers: Dict[str, List[Dict]] = {
            "message": [],
            "all": [],
            "task": [],
            "page": [],  # wiki service
        }
        self._replies: Dict[str, str] = {}
        self._loop = None
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=10)
        self._message_client = None

        # Lifecycle hook 콜백 — _initialize 시점에 모든 SocketModeClient에 전달.
        self._on_disconnect_callbacks: List[Callable] = []
        self._on_reconnect_callbacks: List[Callable] = []

    def _validate_config(self) -> None:
        """Validate configuration settings.

        Raises:
            DoorayConfigurationError: If token or domain is missing or invalid.
        """
        if not self.token or not self.token.strip():
            raise DoorayConfigurationError(
                "Token is required. Set token parameter or DOORAY_AGENT_TOKEN environment variable.",
                error_code="MISSING_TOKEN",
            )

        if not self.domain or not self.domain.strip():
            raise DoorayConfigurationError(
                "Domain is required. Set domain parameter or DOORAY_DOMAIN environment variable.",
                error_code="MISSING_DOMAIN",
            )

        # Domain format validation
        domain = self.domain.strip()
        if " " in domain:
            raise DoorayConfigurationError(
                f"Invalid domain format: '{domain}'. Domain cannot contain spaces.",
                error_code="INVALID_DOMAIN",
                context={"domain": domain},
            )
        if domain.startswith(("http://", "https://")):
            raise DoorayConfigurationError(
                f"Invalid domain format: '{domain}'. Remove protocol (http://, https://). Example: company.dooray.com",
                error_code="INVALID_DOMAIN",
                context={"domain": domain},
            )

    @staticmethod
    def _parse_api_base_url(domain: str) -> str:
        """
        도메인에서 API base URL을 파싱합니다.

        첫 번째 서브도메인(테넌트명)을 제거하고 api.를 붙입니다.

        Args:
            domain: Dooray 도메인 (예: company.dooray.com)

        Returns:
            str: API base URL (예: https://api.dooray.com)

        Examples:
            company.dooray.com → https://api.dooray.com
            nhnent.dev.dooray.com → https://api.dev.dooray.com
            self.gov-dooray.com → https://api.gov-dooray.com
        """
        from ._domain import parse_api_base_url
        return parse_api_base_url(domain)

    # === 서비스 네임스페이스 (ADR-001 듀얼 객체) ===
    # 호출(`@agent.messenger`)은 deprecated 구독 데코레이터, 속성 접근은 클라이언트 API.

    @property
    def messenger(self) -> ServiceNamespace:
        """메신저 서비스 네임스페이스. ``agent.messenger.send_message(...)``."""
        return ServiceNamespace(self, "messenger", api=self._messenger_api())

    @property
    def task(self) -> ServiceNamespace:
        """업무 서비스 네임스페이스 (슬롯). 메서드는 후속 ADR에서 채움."""
        return ServiceNamespace(self, "task", api=self._task_api())

    @property
    def wiki(self) -> ServiceNamespace:
        """위키 서비스 네임스페이스 (슬롯). 메서드는 후속 ADR에서 채움."""
        return ServiceNamespace(self, "wiki", api=self._wiki_api())

    def _messenger_api(self) -> Optional["AsyncMessengerAPI"]:
        """현재 시점의 messenger API 객체. 초기화 전이면 None."""
        if self._message_client is None:
            return None
        # AsyncWebClient.messenger property 가 lazy 생성.
        return self._message_client.messenger

    def _task_api(self) -> Optional["AsyncTaskAPI"]:
        if self._message_client is None:
            return None
        from .web.task import AsyncTaskAPI
        if getattr(self, "_task_api_instance", None) is None:
            self._task_api_instance = AsyncTaskAPI(self._message_client)
        return self._task_api_instance

    def _wiki_api(self) -> Optional["AsyncWikiAPI"]:
        if self._message_client is None:
            return None
        from .web.wiki import AsyncWikiAPI
        if getattr(self, "_wiki_api_instance", None) is None:
            self._wiki_api_instance = AsyncWikiAPI(self._message_client)
        return self._wiki_api_instance

    # === 통합형 데코레이터 (유연한 사용) ===

    def on(
        self,
        event_type: Union[str, List[str]] = "all",
        action: Union[str, List[str]] = None,
        service: Union[str, List[str]] = None
    ) -> Callable:
        """
        통합 이벤트 핸들러. 동기/비동기 함수 모두 지원.

        @agent.on("message")
        def handle_msg(req):
            req.reply("Hello!")

        @agent.on("message")
        async def handle_msg(req):
            await req.reply("Hello!")

        @agent.on("message", action="create")
        def handle_new_message(req):
            print("새 메시지")

        @agent.on(service="messenger")
        def handle_all_messenger(req):
            print(f"메신저 이벤트: {req.type}/{req.action}")
        """
        def decorator(func: Callable) -> Callable:
            handler_info = {
                "func": func,
                "action": [action] if isinstance(action, str) else action,
                "service": [service] if isinstance(service, str) else service,
                "is_async": inspect.iscoroutinefunction(func),
            }

            # 이벤트 타입 등록
            event_types = [event_type] if isinstance(event_type, str) else event_type
            for et in event_types:
                if et not in self._handlers:
                    self._handlers[et] = []
                self._handlers[et].append(handler_info)

            return func
        return decorator

    # === Lifecycle hooks (Socket Mode 자동 재연결 관측) ===

    def on_disconnect(self, func: Callable) -> Callable:
        """
        WebSocket 연결이 끊겼을 때 호출되는 핸들러를 등록합니다.

        시그니처: ``func(client, info_dict)``. ``info_dict``는 attempt /
        error / close_code / close_reason 키를 포함합니다.

        동기/비동기 함수 모두 허용. 콜백 내 예외는 격리되어 재연결 루프를
        중단시키지 않습니다.

        Example:
            @agent.on_disconnect
            def report_drop(client, info):
                metrics.incr("ws.disconnect", tags={"code": info["close_code"]})
        """
        self._on_disconnect_callbacks.append(func)
        # 이미 초기화된 클라이언트가 있으면 즉시 전파.
        cm = getattr(self, "_connection_manager", None)
        if cm is not None:
            for client in cm._clients.values():
                client.on_disconnect(func)
        return func

    def on_reconnect(self, func: Callable) -> Callable:
        """
        재연결 시도 직전에 호출되는 핸들러를 등록합니다.

        시그니처: ``func(client, info_dict)``. ``info_dict``는 attempt /
        delay / error / close_code / close_reason 키를 포함합니다.

        동기/비동기 함수 모두 허용. 콜백 내 예외는 격리됩니다.

        Example:
            @agent.on_reconnect
            async def announce(client, info):
                await alert(f"reconnect attempt #{info['attempt']} in {info['delay']:.1f}s")
        """
        self._on_reconnect_callbacks.append(func)
        cm = getattr(self, "_connection_manager", None)
        if cm is not None:
            for client in cm._clients.values():
                client.on_reconnect(func)
        return func

    def add_handler(
        self,
        event_type: str,
        handler: Callable,
        action: Union[str, List[str]] = None,
        service: Union[str, List[str]] = None
    ) -> None:
        """
        이벤트 핸들러 등록 (비데코레이터 방식).

        Args:
            event_type: 이벤트 타입
            handler: 핸들러 함수
            action: 액션 필터
            service: 서비스 필터
        """
        if event_type not in self._handlers:
            self._handlers[event_type] = []

        handler_info = {
            "func": handler,
            "action": [action] if isinstance(action, str) else action,
            "service": [service] if isinstance(service, str) else service,
            "is_async": inspect.iscoroutinefunction(handler),
        }
        self._handlers[event_type].append(handler_info)

    def reply_to(self, trigger: str, response: str) -> None:
        """
        단순 응답 매핑.

        agent.reply_to("ping", "pong")
        """
        self._replies[trigger] = response

    def _make_sync_reply(self, channel: str) -> Callable:
        """동기 reply 함수 생성 (내부에서 비동기 호출).

        ADR-005 이후 내부 호출은 ``messenger.send_message`` 로 라우팅한다 —
        deprecation 신호가 사용자 핸들러에서만 발생하도록.
        """
        def reply(text: str) -> Dict[str, Any]:
            if self._loop is None or self._message_client is None:
                raise RuntimeError("Agent is not running")

            future = asyncio.run_coroutine_threadsafe(
                self._message_client.messenger.send_message(channel, text),
                self._loop
            )
            return future.result(timeout=30)

        return reply

    def _matches_filter(self, handler_info: Dict, req) -> bool:
        """핸들러의 service/action 필터가 요청과 일치하는지 확인합니다."""
        service_filter = handler_info.get("service")
        if service_filter and req.service not in service_filter:
            return False

        action_filter = handler_info.get("action")
        if action_filter and req.action not in action_filter:
            return False

        return True

    async def _execute_handler(self, handler_info: Dict, req, **context) -> None:
        """
        단일 핸들러를 실행합니다. 동기/비동기 자동 감지.

        ADR-002: 파라미터 수에 따라 ``(req, client)`` 또는 ``(req)`` 시그니처를
        지원한다. ``client`` 자리에는 Agent 자신을 주입한다
        (``agent.messenger.send_message(...)`` 가 가능하므로).

        Args:
            handler_info: 핸들러 정보 dict (func, is_async 등)
            req: SocketModeRequest
            **context: 추가 컨텍스트 (text, sync_reply, channel 등)
        """
        handler = handler_info["func"]
        is_async = handler_info.get("is_async", False)
        params = list(inspect.signature(handler).parameters.keys())
        param_count = len(params)

        text = context.get("text")
        sync_reply = context.get("sync_reply")
        channel = context.get("channel")
        is_message = context.get("is_message", False)

        # 데이터/페이로드 단일 인자 핸들러는 별도 경로.
        wants_data_only = param_count >= 1 and params[0] in ("data", "payload")

        try:
            if is_async:
                req._is_async = True
                if is_message and not wants_data_only and param_count >= 2 \
                        and params[0] not in ("req", "request"):
                    # 레거시: (text, reply) — 시그니처가 (req, client) 인 경우와 충돌하지 않도록
                    # 첫 인자 이름이 req/request 이면 신규 시그니처로 우선 처리.
                    await handler(text, req.reply)
                elif wants_data_only:
                    await handler(req.data)
                elif param_count >= 2:
                    # ADR-002 신규: (req, client)
                    await handler(req, self)
                else:
                    await handler(req)
            else:
                req._is_async = False
                if is_message:
                    req._sync_reply_func = sync_reply
                    if param_count >= 3:
                        # 레거시: (text, reply, channel)
                        await self._loop.run_in_executor(
                            self._executor, handler, text, sync_reply, channel
                        )
                    elif param_count >= 2:
                        if params[0] in ("req", "request"):
                            # ADR-002 신규: (req, client) 동기 핸들러
                            await self._loop.run_in_executor(
                                self._executor, handler, req, self
                            )
                        else:
                            # 레거시: (text, reply)
                            await self._loop.run_in_executor(
                                self._executor, handler, text, sync_reply
                            )
                    else:
                        await self._loop.run_in_executor(
                            self._executor, handler, req
                        )
                else:
                    if wants_data_only:
                        await self._loop.run_in_executor(
                            self._executor, handler, req.data
                        )
                    elif param_count >= 2:
                        # ADR-002 신규: (req, client) 비메시지 동기 핸들러
                        await self._loop.run_in_executor(
                            self._executor, handler, req, self
                        )
                    else:
                        await self._loop.run_in_executor(
                            self._executor, handler, req
                        )
        except Exception as e:
            logger.error(f"Handler error: {e}", exc_info=True)

    async def _dispatch(self, client, req) -> None:
        """내부 비동기 디스패처. 동기/비동기 핸들러 모두 지원."""
        from .socket_mode.response import SocketModeResponse

        # ACK 전송
        if req.envelope_id:
            response = SocketModeResponse.ack(req.envelope_id)
            await client.send_socket_mode_response(response)

        # 에이전트 자체 메시지 필터링 (ACK 전송 후, 핸들러 실행 전)
        if self._ignore_self and self._agent_member_id:
            sender_id = req.payload.get("senderId") or (req.actor.id if req.actor else None)
            if sender_id and sender_id == self._agent_member_id:
                logger.debug(f"Ignoring self-message from agent (sender_id={sender_id})")
                return

        # Request에 reply 기능을 위한 참조 주입.
        # ADR-004: `_client` 가 신규 deprecation 위임의 진입점 (Agent 자신).
        # `_web_client` 는 한 마이너 동안 fallback용으로 유지.
        req._web_client = self._message_client
        req._client = self

        # 해당 이벤트 타입의 핸들러 수집
        handlers = []
        if req.type in self._handlers:
            handlers.extend(self._handlers[req.type])
        handlers.extend(self._handlers.get("all", []))

        # 메시지 타입 특별 처리 (하위 호환성)
        if req.is_message:
            # req.channel 은 deprecated property라 직접 호출하면 경고가 발생.
            # 내부에서는 channel_info.id 또는 raw getter를 사용.
            text = req.text or ""
            channel_info = req.channel_info
            channel = channel_info.id if channel_info else req.get_channel()
            sync_reply = self._make_sync_reply(channel) if channel else None

            # 단순 응답 처리 (deprecation 신호가 사용자 코드에서만 발생하도록 messenger.* 사용)
            if text in self._replies and channel:
                await self._message_client.messenger.send_message(channel, self._replies[text])
                return

            context = {"text": text, "sync_reply": sync_reply, "channel": channel, "is_message": True}
        else:
            context = {"is_message": False}

        # 핸들러 실행 (필터링 + 실행 공통 로직)
        for handler_info in handlers:
            if self._matches_filter(handler_info, req):
                await self._execute_handler(handler_info, req, **context)

    async def _initialize(self) -> None:
        """
        내부 초기화: 웹 클라이언트, ConnectionManager 생성 및 연결.

        run(), start(), connect() 에서 공통으로 사용됩니다.
        """
        from .web.async_client import AsyncWebClient
        from .socket_mode.connection_manager import ConnectionManager

        self._loop = asyncio.get_running_loop()

        # API 클라이언트
        self._message_client = AsyncWebClient(
            token=self.token,
            base_url=self.base_url
        )

        # ConnectionManager로 멀티 서비스 연결.
        # auto_reconnect_enabled 및 reconnect_* 파라미터는 SocketModeClient
        # __init__로 전달된다(ConnectionManager.kwargs → SocketModeClient(**kwargs)).
        cm_kwargs = dict(self._socket_kwargs)
        cm_kwargs["auto_reconnect_enabled"] = self.auto_reconnect_enabled
        self._connection_manager = ConnectionManager(
            web_client=self._message_client,
            domain=self.domain,
            services=self.services,
            **cm_kwargs,
        )

        # 디스패처 등록 및 연결
        self._connection_manager.add_listener(self._dispatch)
        await self._connection_manager.connect_all()

        # 모든 클라이언트에 lifecycle hook 전파 (사전 등록분).
        for client in self._connection_manager._clients.values():
            for cb in self._on_disconnect_callbacks:
                client.on_disconnect(cb)
            for cb in self._on_reconnect_callbacks:
                client.on_reconnect(cb)

        # 에이전트 자체 메시지 필터링을 위해 member_id 저장
        if self._ignore_self:
            self._agent_member_id = self._connection_manager.member_id
            if self._agent_member_id:
                logger.info(f"Agent member_id: {self._agent_member_id} (self-message filtering enabled)")
            else:
                logger.warning("Could not retrieve agent member_id; self-message filtering disabled")

        logger.info(f"Agent started: {self.domain} (API: {self.base_url})")
        logger.info(f"Connected services: {self.services}")

    async def _run_forever(self) -> None:
        """
        Socket Mode background task가 살아있는 동안 메인 코루틴을 유지한다.

        ``auto_reconnect_enabled=True`` (기본): task가 영원히 살아있으므로
        ``asyncio.wait``는 cancellation으로만 깨어난다 (기존 동작과 동등).

        ``auto_reconnect_enabled=False``: SDK는 1회 close 후 task가 종료된다.
        이 경우 ``wait``가 깨어나며 메인 코루틴도 함께 종료되어, 상위 프로세스
        / 외부 오케스트레이터가 fail-fast 재기동을 트리거할 수 있다.
        이전 ``asyncio.sleep(float("inf"))`` 패턴은 task 종료를 인지하지 못해
        외부 오케스트레이터 모델조차 깨뜨렸으므로 제거됨 (ADR-001).
        """
        if self._replies:
            logger.info(f"Auto replies: {list(self._replies.keys())}")

        try:
            tasks = self._connection_manager.all_tasks()
            if not tasks:
                # 비정상: 연결된 task가 없으면 즉시 정리.
                logger.warning("No active Socket Mode tasks — exiting run loop")
            else:
                done, pending = await asyncio.wait(
                    tasks, return_when=asyncio.FIRST_COMPLETED
                )
                # task가 예외로 끝났으면 로그(전파는 하지 않음 — disconnect_all에서 정리).
                for t in done:
                    if t.cancelled():
                        continue
                    exc = t.exception()
                    if exc is not None:
                        logger.error(
                            "Socket Mode task exited with exception: %r", exc
                        )
                logger.info(
                    "Socket Mode background task ended — stopping agent "
                    "(auto_reconnect_enabled=%s)",
                    self.auto_reconnect_enabled,
                )
        except asyncio.CancelledError:
            pass
        finally:
            await self._connection_manager.disconnect_all()
            self._executor.shutdown(wait=False)

    def run(self) -> None:
        """에이전트 실행 (블로킹)."""

        async def _run():
            await self._initialize()
            await self._run_forever()

        try:
            asyncio.run(_run())
        except KeyboardInterrupt:
            logger.info("Shutdown")

    async def start(self) -> None:
        """
        비동기 시작 (async context에서 사용).

        Example:
            async def main():
                await agent.start()

            asyncio.run(main())
        """
        await self._initialize()
        await self._run_forever()

    async def connect(self) -> None:
        """Socket Mode 연결 (대기 없이 연결만 수행)."""
        await self._initialize()

    async def disconnect(self) -> None:
        """연결 종료."""
        if self._connection_manager:
            await self._connection_manager.disconnect_all()
            self._connection_manager = None
            logger.info("Disconnected")

    @property
    def is_connected(self) -> bool:
        """연결 상태 확인."""
        return (
            self._connection_manager is not None
            and self._connection_manager.is_connected()
        )

    # === 평면 API 메서드 (ADR-004 deprecation aliases) ===
    # 한 마이너 동안 위임 alias로 유지. 신규 코드는 agent.messenger.<verb>를 사용.

    async def send_message(self, channel: str, text: str, **kwargs) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``agent.messenger.send_message(...)`` instead (ADR-001/005).
        """
        warnings.warn(
            "Agent.send_message is deprecated. "
            "Use agent.messenger.send_message(channel=..., text=...) instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return await self._message_client.messenger.send_message(channel, text, **kwargs)

    async def get_channels(self, **kwargs) -> Dict[str, Any]:
        """
        .. deprecated::
            ``agent.messenger.get_channels(...)`` 슬롯이 채워지면 그곳으로 이동.
        """
        warnings.warn(
            "Agent.get_channels is deprecated. "
            "It will move under agent.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        # 내부 위임은 트랜스포트 직접 호출로 deprecation 중첩 방지.
        return await self._message_client.get("/v1/channels", params=kwargs)

    async def get_messages(self, channel: str, limit: Optional[int] = None, **kwargs) -> Dict[str, Any]:
        """
        .. deprecated::
            ``agent.messenger.get_messages(...)`` 슬롯이 채워지면 그곳으로 이동.
        """
        warnings.warn(
            "Agent.get_messages is deprecated. "
            "It will move under agent.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        params = {"channel": channel, **kwargs}
        if limit is not None:
            params["limit"] = limit
        return await self._message_client.get("/v1/messages", params=params)

    async def get_user_info(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        .. deprecated::
            ``agent.messenger.get_user_info(...)`` 슬롯이 채워지면 그곳으로 이동.
        """
        warnings.warn(
            "Agent.get_user_info is deprecated. "
            "It will move under agent.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        if user_id:
            return await self._message_client.get(f"/v1/users/{user_id}")
        return await self._message_client.get("/v1/users/me")

    @property
    def web(self) -> Any:
        """내부 웹 클라이언트 접근."""
        return self._message_client
