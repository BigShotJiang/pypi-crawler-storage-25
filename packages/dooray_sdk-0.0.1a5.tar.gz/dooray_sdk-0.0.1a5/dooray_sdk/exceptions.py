# dooray_sdk/exceptions.py
"""
Dooray SDK Exception Hierarchy.

This module defines the exception classes used throughout the Dooray SDK.
All exceptions inherit from DooraySDKError for consistent error handling.

Example:
    from dooray_sdk.exceptions import DooraySDKError, DoorayConnectionError

    try:
        client.connect()
    except DoorayConnectionError as e:
        print(f"Connection failed: {e.message}, service: {e.service}")
    except DooraySDKError as e:
        print(f"SDK error: {e}")
"""

from typing import Any, Dict, Optional


# @MX:ANCHOR: [AUTO] Base exception class for all SDK errors (fan_in >= 3)
# @MX:REASON: All SDK exceptions inherit from this class
class DooraySDKError(Exception):
    """Base exception class for Dooray SDK errors.

    All SDK-specific exceptions inherit from this class, providing
    consistent error handling with optional error codes and context.

    Attributes:
        message: Human-readable error description.
        error_code: Optional error code for programmatic handling.
        context: Optional dictionary with additional error context.
    """

    def __init__(
        self,
        message: str,
        *,
        error_code: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize DooraySDKError.

        Args:
            message: Human-readable error description.
            error_code: Optional error code for programmatic handling.
            context: Optional dictionary with additional error context.
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.context = context or {}

    def __str__(self) -> str:
        """Return formatted error string with code and context."""
        parts = [self.message]
        if self.error_code:
            parts.append(f"[{self.error_code}]")
        if self.context:
            context_str = ", ".join(f"{k}={v}" for k, v in self.context.items())
            parts.append(f"({context_str})")
        return " ".join(parts)


class DoorayConnectionError(DooraySDKError):
    """Exception raised for connection-related errors.

    This exception is raised when the SDK fails to establish or maintain
    a connection to Dooray services.

    Attributes:
        message: Human-readable error description.
        service: Optional name of the service that failed to connect.
        retry_count: Number of connection retry attempts made.
        error_code: Optional error code for programmatic handling.
        context: Optional dictionary with additional error context.
    """

    def __init__(
        self,
        message: str,
        *,
        service: Optional[str] = None,
        retry_count: int = 0,
        **kwargs: Any,
    ) -> None:
        """Initialize DoorayConnectionError.

        Args:
            message: Human-readable error description.
            service: Optional name of the service that failed to connect.
            retry_count: Number of connection retry attempts made.
            **kwargs: Additional arguments passed to DooraySDKError.
        """
        super().__init__(message, **kwargs)
        self.service = service
        self.retry_count = retry_count


class DoorayWebSocketError(DoorayConnectionError):
    """Exception raised for WebSocket connection errors.

    This exception is a specialized connection error for WebSocket-specific
    failures during Socket Mode communication.
    """

    pass


class DoorayAuthenticationError(DooraySDKError):
    """Exception raised for authentication-related errors.

    This exception is raised when authentication fails, such as
    invalid credentials or expired tokens.
    """

    pass


class DoorayTokenError(DoorayAuthenticationError):
    """Exception raised for token-related errors.

    This exception is raised when there are issues with tokens,
    such as missing, invalid, or expired tokens.

    Attributes:
        message: Human-readable error description.
        token_type: Optional type of token that caused the error.
        error_code: Optional error code for programmatic handling.
        context: Optional dictionary with additional error context.
    """

    def __init__(
        self,
        message: str,
        *,
        token_type: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize DoorayTokenError.

        Args:
            message: Human-readable error description.
            token_type: Optional type of token that caused the error.
            **kwargs: Additional arguments passed to DoorayAuthenticationError.
        """
        super().__init__(message, **kwargs)
        self.token_type = token_type


class DoorayConfigurationError(DooraySDKError):
    """Exception raised for configuration-related errors.

    This exception is raised when there are issues with SDK configuration,
    such as missing required settings or invalid configuration values.
    """

    pass


class DoorayRequestError(DooraySDKError):
    """Exception raised for HTTP request-related errors.

    This exception is raised when an HTTP request to Dooray API fails,
    providing details about the HTTP status and response.

    Attributes:
        message: Human-readable error description.
        status_code: Optional HTTP status code of the failed request.
        response_body: Optional response body from the failed request.
        error_code: Optional error code for programmatic handling.
        context: Optional dictionary with additional error context.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        response_body: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize DoorayRequestError.

        Args:
            message: Human-readable error description.
            status_code: Optional HTTP status code of the failed request.
            response_body: Optional response body from the failed request.
            **kwargs: Additional arguments passed to DooraySDKError.
        """
        super().__init__(message, **kwargs)
        self.status_code = status_code
        self.response_body = response_body


class DoorayTimeoutError(DooraySDKError):
    """Exception raised for timeout errors.

    This exception is raised when an operation times out,
    such as connection timeout or request timeout.
    """

    pass
