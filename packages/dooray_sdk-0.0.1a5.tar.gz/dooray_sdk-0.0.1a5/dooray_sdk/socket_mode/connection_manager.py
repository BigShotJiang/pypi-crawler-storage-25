"""
Connection Manager

멀티 WebSocket 연결을 관리합니다.
"""

import asyncio
import logging
import os
from typing import List, Dict, Callable, Optional

from .aiohttp.client import SocketModeClient
from ..exceptions import DoorayConnectionError
from ..web.async_client import AsyncWebClient


logger = logging.getLogger(__name__)


# 서비스별 WebSocket 설정
SERVICE_WS_CONFIG = {
    "messenger": {
        "host": None,  # None이면 domain 사용
        "port": None,  # None이면 기본 포트 (443)
        "ws_path": "/messenger/v5/ws",
        "default_service": "messenger",  # 메시지에 service 필드 없을 때 사용
    },
    "common": {
        "host": os.environ.get("DOORAY_COMMON_WS_HOST"),
        "port": None,
        "ws_path": "/inner/session",
        "default_service": None,
    },
}


class ConnectionManager:
    """
    멀티 WebSocket 연결 관리자.

    메신저와 common 서비스에 대해 별도의 WebSocket 연결을 관리합니다.

    Example:
        manager = ConnectionManager(
            web_client=web_client,
            domain="company.dooray.com",
            services=["messenger", "common"]
        )
        manager.add_listener(handle_request)
        await manager.connect_all()
    """

    def all_tasks(self) -> List[asyncio.Task]:
        """
        Background WebSocket tasks of every connected client.

        Agent._run_forever() uses this to detect a fail-fast termination
        (auto_reconnect_enabled=False path) and stop the main coroutine.
        """
        return [
            client.task
            for client in self._clients.values()
            if client.task is not None
        ]

    def __init__(
        self,
        web_client: AsyncWebClient,
        domain: str,
        services: List[str] = None,
        **kwargs
    ):
        """
        Initialize the ConnectionManager.

        Args:
            web_client: AsyncWebClient instance for API calls
            domain: Dooray domain
            services: List of services to connect ("messenger", "common")
            **kwargs: Additional arguments passed to SocketModeClient
        """
        self.web_client = web_client
        self.domain = domain
        self.services = services or ["messenger"]
        self.kwargs = kwargs

        # 서비스별 클라이언트
        self._clients: Dict[str, SocketModeClient] = {}

        # 공유 리스너
        self._listeners: List[Callable] = []

        logger.info(f"ConnectionManager initialized with services: {self.services}")

    def add_listener(self, listener: Callable) -> None:
        """
        리스너 추가. 모든 서비스의 메시지를 수신합니다.

        Args:
            listener: Async function to call when a request is received
        """
        self._listeners.append(listener)
        # 이미 생성된 클라이언트에도 리스너 추가
        for client in self._clients.values():
            client.add_listener(listener)

    def remove_listener(self, listener: Callable) -> None:
        """
        리스너 제거.

        Args:
            listener: Function to remove
        """
        if listener in self._listeners:
            self._listeners.remove(listener)
        for client in self._clients.values():
            client.remove_listener(listener)

    async def connect_all(
        self,
        *,
        raise_on_failure: bool = True,
    ) -> Dict[str, Optional[Exception]]:
        """
        모든 서비스에 연결합니다.

        Args:
            raise_on_failure: True면 첫 번째 실패 시 예외 발생.
                             False면 모든 서비스 연결 시도 후 결과 반환.

        Returns:
            서비스별 연결 결과 (성공: None, 실패: Exception)

        Raises:
            DoorayConnectionError: raise_on_failure=True이고 연결 실패 시
        """
        results: Dict[str, Optional[Exception]] = {}

        for service in self.services:
            if service not in SERVICE_WS_CONFIG:
                logger.warning(f"Unknown service: {service}, skipping")
                continue

            config = SERVICE_WS_CONFIG[service]
            # host가 설정되어 있으면 사용, 없으면 domain 사용
            ws_host = config.get("host") or self.domain
            ws_port = config.get("port")
            client = SocketModeClient(
                web_client=self.web_client,
                domain=ws_host,
                port=ws_port,
                ws_path=config["ws_path"],
                default_service=config["default_service"],
                **self.kwargs
            )

            # 기존 리스너 등록
            for listener in self._listeners:
                client.add_listener(listener)

            self._clients[service] = client

            try:
                await self._connect_service(service, client)
                results[service] = None
            except DoorayConnectionError as e:
                results[service] = e
                if raise_on_failure:
                    raise

        return results

    async def _connect_service(self, service: str, client: SocketModeClient) -> None:
        """개별 서비스에 연결합니다."""
        try:
            await client.connect()
            logger.info(f"Connected to {service} service")
        except Exception as e:
            logger.error(
                f"Failed to connect to {service} service: {e}",
                exc_info=True,
                extra={"service": service},
            )
            raise DoorayConnectionError(
                f"Service connection failed: {service}",
                service=service,
                error_code="CONNECTION_FAILED",
                context={"original_error": str(e)},
            ) from e

    async def disconnect_all(self) -> None:
        """
        모든 서비스 연결을 종료합니다.
        """
        tasks = []
        for service, client in self._clients.items():
            tasks.append(self._disconnect_service(service, client))

        if tasks:
            await asyncio.gather(*tasks)

        self._clients.clear()

    async def _disconnect_service(self, service: str, client: SocketModeClient) -> None:
        """개별 서비스 연결을 종료합니다."""
        try:
            await client.disconnect()
            logger.info(f"Disconnected from {service} service")
        except Exception as e:
            logger.error(
                f"Error disconnecting from {service} service: {e}",
                exc_info=True,
                extra={"service": service},
            )

    def is_connected(self, service: str = None) -> bool:
        """
        연결 상태를 확인합니다.

        Args:
            service: 특정 서비스만 확인 (None이면 모든 서비스)

        Returns:
            bool: 연결 여부
        """
        if service:
            client = self._clients.get(service)
            return client.is_connected() if client else False

        return all(client.is_connected() for client in self._clients.values())

    def get_client(self, service: str) -> Optional[SocketModeClient]:
        """
        특정 서비스의 클라이언트를 가져옵니다.

        Args:
            service: 서비스 이름

        Returns:
            SocketModeClient or None
        """
        return self._clients.get(service)

    @property
    def member_id(self) -> Optional[str]:
        """연결된 클라이언트에서 에이전트의 member_id를 가져옵니다."""
        for client in self._clients.values():
            if client._member_id:
                return client._member_id
        return None

    @property
    def connected_services(self) -> List[str]:
        """연결된 서비스 목록을 반환합니다."""
        return [
            service for service, client in self._clients.items()
            if client.is_connected()
        ]
