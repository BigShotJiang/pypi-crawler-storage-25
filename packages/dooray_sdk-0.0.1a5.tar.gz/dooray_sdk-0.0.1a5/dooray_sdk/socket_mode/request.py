"""
Socket Mode Request

Represents a request received from Dooray via Socket Mode.
"""

import time
import warnings
from typing import Awaitable, Callable, Dict, Any, Optional, Tuple, Union, List, TYPE_CHECKING
from dataclasses import dataclass, field

if TYPE_CHECKING:
    from ..web.async_client import AsyncWebClient
    from ..web.client import WebClient


# =============================================================================
# Global Member Cache
# =============================================================================
# Cache structure: {member_id: (data_dict, timestamp)}
_member_cache: Dict[str, Tuple[Dict[str, Any], float]] = {}
_MEMBER_CACHE_TTL = 600  # 10 minutes in seconds


def _get_cached_member(member_id: str) -> Optional[Dict[str, Any]]:
    """Get cached member info if not expired.

    Args:
        member_id: Organization member ID

    Returns:
        Cached member data dict if valid, None if expired or not found
    """
    if member_id in _member_cache:
        data, timestamp = _member_cache[member_id]
        if time.time() - timestamp < _MEMBER_CACHE_TTL:
            return data
        # Expired, remove from cache
        del _member_cache[member_id]
    return None


def _set_cached_member(member_id: str, data: Dict[str, Any]) -> None:
    """Cache member info with current timestamp.

    Args:
        member_id: Organization member ID
        data: Member data dict to cache
    """
    _member_cache[member_id] = (data, time.time())


def clear_member_cache() -> None:
    """Clear all cached member data.

    Useful for testing or when cache invalidation is needed.
    """
    _member_cache.clear()


# =============================================================================
# Lazy Loading Classes
# =============================================================================

class LazyField:
    """Lazy-loaded field that supports both sync and async access.

    Supports:
        - await field: async fetch
        - str(field), print(field): sync fetch
        - field == value: sync fetch for comparison

    Example:
        name = await req.actor.organizationMember.name  # async
        print(req.actor.organizationMember.name)        # sync
        if req.actor.organizationMember.name == "홍길동":  # sync
    """

    def __init__(self, lazy_data: "LazyMemberData", field_name: str):
        object.__setattr__(self, "_lazy_data", lazy_data)
        object.__setattr__(self, "_field_name", field_name)

    def _sync_get(self) -> Any:
        """Synchronously fetch and return the field value.

        Checks local data first to avoid unnecessary API calls.
        """
        # Check local data first (no API call needed)
        local_data = object.__getattribute__(self._lazy_data, "_local_data")
        if self._field_name in local_data:
            return local_data[self._field_name]

        # Not in local data - fetch from API
        data = self._lazy_data._sync_fetch()
        return data.get(self._field_name)

    async def _async_get(self) -> Any:
        """Asynchronously fetch and return the field value.

        Checks local data first to avoid unnecessary API calls.
        """
        # Check local data first (no API call needed)
        local_data = object.__getattribute__(self._lazy_data, "_local_data")
        if self._field_name in local_data:
            return local_data[self._field_name]

        # Not in local data - fetch from API
        data = await self._lazy_data._async_fetch()
        return data.get(self._field_name)

    def __await__(self):
        """Support: await field"""
        return self._async_get().__await__()

    def __str__(self) -> str:
        """Support: str(field), print(field)"""
        value = self._sync_get()
        return str(value) if value is not None else ""

    def __repr__(self) -> str:
        return f"LazyField({self._field_name})"

    def __eq__(self, other: Any) -> bool:
        """Support: field == value"""
        if isinstance(other, LazyField):
            return self._sync_get() == other._sync_get()
        return self._sync_get() == other

    def __ne__(self, other: Any) -> bool:
        """Support: field != value"""
        return not self.__eq__(other)

    def __hash__(self) -> int:
        """Support: hash(field)"""
        return hash(self._sync_get())

    def __bool__(self) -> bool:
        """Support: if field:"""
        return bool(self._sync_get())

    def __add__(self, other: Any) -> Any:
        """Support: field + value"""
        return self._sync_get() + other

    def __radd__(self, other: Any) -> Any:
        """Support: value + field"""
        return other + self._sync_get()


class LazyMemberData:
    """Lazy-loaded member data wrapper for organizationMember.

    Provides lazy loading for member information. Local data (from message)
    is returned immediately. Missing fields trigger API fetch.

    Example:
        # Local data (immediate)
        req.actor.organizationMember.id  # from message

        # Remote data (lazy loaded)
        await req.actor.organizationMember.name  # async fetch
        print(req.actor.organizationMember.name)  # sync fetch

    Attributes:
        id: Dooray Member ID
        idProviderType: ID 제공자 타입 (sso, service)
        idProviderUserId: ID 제공자 사용자 ID
        name: 멤버 이름
        userCode: 사용자 코드
        externalEmailAddress: 외부 이메일 주소
        defaultOrganization: 기본 조직 정보 (dict with id)
        locale: 로케일 설정
        timezoneName: 타임존
        englishName: 영문 이름
        nativeName: 본명
        nickname: 닉네임
        displayMemberId: 표시용 멤버 ID
    """

    def __init__(
        self,
        local_data: Dict[str, Any],
        member_id: str,
        web_client: Any
    ):
        object.__setattr__(self, "_local_data", local_data or {})
        object.__setattr__(self, "_member_id", member_id)
        object.__setattr__(self, "_web_client", web_client)
        object.__setattr__(self, "_remote_data", None)

    @property
    def id(self) -> "LazyField":
        """Dooray Member ID."""
        return LazyField(self, "id")

    @property
    def idProviderType(self) -> "LazyField":
        """ID 제공자 타입 (sso, service)."""
        return LazyField(self, "idProviderType")

    @property
    def idProviderUserId(self) -> "LazyField":
        """ID 제공자 사용자 ID."""
        return LazyField(self, "idProviderUserId")

    @property
    def name(self) -> "LazyField":
        """멤버 이름."""
        return LazyField(self, "name")

    @property
    def userCode(self) -> "LazyField":
        """사용자 코드."""
        return LazyField(self, "userCode")

    @property
    def externalEmailAddress(self) -> "LazyField":
        """외부 이메일 주소."""
        return LazyField(self, "externalEmailAddress")

    @property
    def defaultOrganization(self) -> "LazyField":
        """기본 조직 정보 (dict with id)."""
        return LazyField(self, "defaultOrganization")

    @property
    def locale(self) -> "LazyField":
        """로케일 설정."""
        return LazyField(self, "locale")

    @property
    def timezoneName(self) -> "LazyField":
        """타임존."""
        return LazyField(self, "timezoneName")

    @property
    def englishName(self) -> "LazyField":
        """영문 이름."""
        return LazyField(self, "englishName")

    @property
    def nativeName(self) -> "LazyField":
        """본명."""
        return LazyField(self, "nativeName")

    @property
    def nickname(self) -> "LazyField":
        """닉네임."""
        return LazyField(self, "nickname")

    @property
    def displayMemberId(self) -> "LazyField":
        """표시용 멤버 ID."""
        return LazyField(self, "displayMemberId")

    def _sync_fetch(self) -> Dict[str, Any]:
        """Synchronously fetch member data from API."""
        import asyncio
        import inspect

        if self._remote_data is not None:
            return self._remote_data

        # Check global cache first
        cached = _get_cached_member(self._member_id)
        if cached is not None:
            object.__setattr__(self, "_remote_data", cached)
            return cached

        # Fetch from API (sync)
        if self._web_client is None:
            raise RuntimeError("WebClient not available for API calls")

        # Check if get_member is a coroutine function (async client)
        if inspect.iscoroutinefunction(self._web_client.get_member):
            # Async client - run in event loop
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop is not None:
                # Already in async context - can't use sync access
                raise RuntimeError(
                    "Sync access not available in async context. "
                    "Use 'await' for async access: await req.actor.organizationMember.name"
                )
            else:
                # No running loop - create new one
                data = asyncio.run(self._web_client.get_member(self._member_id))
        else:
            # Sync WebClient
            data = self._web_client.get_member(self._member_id)

        _set_cached_member(self._member_id, data)
        object.__setattr__(self, "_remote_data", data)
        return data

    async def _async_fetch(self) -> Dict[str, Any]:
        """Asynchronously fetch member data from API."""
        if self._remote_data is not None:
            return self._remote_data

        # Check global cache first
        cached = _get_cached_member(self._member_id)
        if cached is not None:
            object.__setattr__(self, "_remote_data", cached)
            return cached

        # Fetch from API (async)
        if self._web_client is None:
            raise RuntimeError("WebClient not available for API calls")

        data = await self._web_client.get_member(self._member_id)
        _set_cached_member(self._member_id, data)
        object.__setattr__(self, "_remote_data", data)
        return data

    def __getattr__(self, name: str) -> Any:
        """Return local data immediately or LazyField for remote data."""
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

        local_data = object.__getattribute__(self, "_local_data")

        # Return local data if available
        if name in local_data:
            value = local_data[name]
            if isinstance(value, dict):
                return DataWrapper(value)
            return value

        # Return LazyField for remote data
        return LazyField(self, name)

    def __await__(self):
        """Support: await req.actor.organizationMember -> DataWrapper"""
        return self._await_impl().__await__()

    async def _await_impl(self) -> "DataWrapper":
        """Return full member data as DataWrapper."""
        remote = await self._async_fetch()
        merged = {**self._local_data, **remote}
        return DataWrapper(merged)

    def __repr__(self) -> str:
        return f"LazyMemberData(id={self._member_id})"


class DataWrapper:
    """dict 데이터를 dot notation으로 접근할 수 있는 래퍼 클래스.

    Example:
        data = DataWrapper({"id": "123", "name": "Test"})
        data.id       # "123"
        data.name     # "Test"
        data["id"]    # "123" (dict 접근도 지원)
        data.get("id")  # "123"
    """

    def __init__(self, data: Optional[Dict[str, Any]]):
        # __setattr__ 우회를 위해 object.__setattr__ 사용
        object.__setattr__(self, "_data", data or {})

    def __getattr__(self, name: str) -> Any:
        """dot notation으로 필드 접근."""
        data = object.__getattribute__(self, "_data")
        if name in data:
            return data[name]
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    def __getitem__(self, key: str) -> Any:
        """dict처럼 [] 접근 지원."""
        return self._data[key]

    def __contains__(self, key: str) -> bool:
        """in 연산자 지원."""
        return key in self._data

    def get(self, key: str, default: Any = None) -> Any:
        """dict.get() 지원."""
        return self._data.get(key, default)

    def keys(self):
        """dict.keys() 지원."""
        return self._data.keys()

    def values(self):
        """dict.values() 지원."""
        return self._data.values()

    def items(self):
        """dict.items() 지원."""
        return self._data.items()

    def __iter__(self):
        """iteration 지원."""
        return iter(self._data)

    def __len__(self) -> int:
        """len() 지원."""
        return len(self._data)

    def __bool__(self) -> bool:
        return bool(self._data)

    def __repr__(self) -> str:
        return f"DataWrapper({self._data})"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, DataWrapper):
            return self._data == other._data
        if isinstance(other, dict):
            return self._data == other
        return False


class ChannelInfo(DataWrapper):
    """채널 정보 래퍼 클래스 (IDE 자동완성 지원).

    Example:
        req.channel_info.id     # 채널 ID
        req.channel_info.scope  # 채널 scope
        req.channel_info.type   # 채널 타입 (direct, private, thread 등)
    """

    @property
    def id(self) -> str:
        """채널 ID."""
        return self._data.get("id", "")

    @property
    def scope(self) -> str:
        """채널 scope."""
        return self._data.get("scope", "")

    @property
    def type(self) -> str:
        """채널 타입 (direct, private, thread 등)."""
        return self._data.get("type", "")


class MessageData(DataWrapper):
    """channelLog 메시지용 래퍼 클래스 (IDE 자동완성 지원).

    Example:
        req.entity.data.text       # 메시지 텍스트
        req.entity.data.channelId  # 채널 ID
        req.entity.data.senderId   # 보낸 사람 ID
    """

    @property
    def id(self) -> str:
        """메시지 ID."""
        return self._data.get("id", "")

    @property
    def channelId(self) -> str:
        """채널 ID."""
        return self._data.get("channelId", "")

    @property
    def directMemberId(self) -> str:
        """DM 상대방 멤버 ID (DM인 경우)."""
        return self._data.get("directMemberId", "")

    @property
    def type(self) -> int:
        """메시지 타입 (0: 일반, 1: 시스템)."""
        return self._data.get("type", 0)

    @property
    def senderId(self) -> str:
        """보낸 사람 멤버 ID."""
        return self._data.get("senderId", "")

    @property
    def sentAt(self) -> int:
        """보낸 시간 (timestamp ms)."""
        return self._data.get("sentAt", 0)

    @property
    def seq(self) -> int:
        """메시지 시퀀스 번호."""
        return self._data.get("seq", 0)

    @property
    def text(self) -> str:
        """메시지 텍스트."""
        return self._data.get("text", "")

    @property
    def token(self) -> str:
        """메시지 토큰."""
        return self._data.get("token", "")

    @property
    def unreadCount(self) -> int:
        """읽지 않은 메시지 수."""
        return self._data.get("unreadCount", 0)

    @property
    def mentionCount(self) -> int:
        """멘션 수."""
        return self._data.get("mentionCount", 0)

    @property
    def flags(self) -> int:
        """메시지 플래그."""
        return self._data.get("flags", 0)

    @property
    def parentChannelId(self) -> str:
        """부모 채널 ID (스레드인 경우)."""
        return self._data.get("parentChannelId", "")

    @property
    def totalCount(self) -> int:
        """전체 메시지 수."""
        return self._data.get("totalCount", 0)

    @property
    def unreadFlag(self) -> bool:
        """읽지 않음 플래그."""
        return self._data.get("unreadFlag", False)

    @property
    def threadTitle(self) -> str:
        """스레드 제목."""
        return self._data.get("threadTitle", "")


class EntityWrapper:
    """Entity 래퍼 클래스.

    Example:
        req.entity.type       # "task"
        req.entity.data.id    # entity 데이터의 id 필드
        req.entity.data.subject  # entity 데이터의 subject 필드
    """

    def __init__(self, data: Optional[Dict[str, Any]]):
        self._data = data or {}
        self._data_wrapper: Optional[DataWrapper] = None

    @property
    def type(self) -> Optional[str]:
        """엔티티 타입 (task, page, driveFile 등)."""
        return self._data.get("type")

    @property
    def data(self) -> Optional[Union[DataWrapper, "MessageData"]]:
        """엔티티 상세 데이터 (dot notation 지원).

        Example:
            req.entity.data.id       # entity 데이터의 id
            req.entity.data.subject  # entity 데이터의 subject
            req.entity.data["id"]    # dict 접근도 가능

        Note:
            message 타입일 경우 MessageData를 반환하여 IDE 자동완성 지원.
        """
        if self.type:
            raw_data = self._data.get(self.type)
            if raw_data is not None:
                # 캐싱하여 매번 새 객체 생성 방지
                if self._data_wrapper is None:
                    # 타입별 전용 래퍼 반환
                    if self.type == "message":
                        self._data_wrapper = MessageData(raw_data)
                    else:
                        self._data_wrapper = DataWrapper(raw_data)
                return self._data_wrapper
        return None

    @property
    def raw(self) -> Dict[str, Any]:
        """원본 dict 데이터."""
        return self._data

    def get(self, key: str, default: Any = None) -> Any:
        """dict처럼 접근 지원."""
        return self._data.get(key, default)

    def __bool__(self) -> bool:
        return bool(self._data)

    def __repr__(self) -> str:
        return f"EntityWrapper({self._data})"

    def __getattr__(self, name: str) -> Any:
        """Dynamic attribute access support.

        Allows accessing entity data by type name:
            req.entity.task  # Returns DataWrapper for task data
            req.entity.page  # Returns DataWrapper for page data
        """
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
        if name in self._data:
            raw_data = self._data[name]
            if isinstance(raw_data, dict):
                return DataWrapper(raw_data)
            return raw_data
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")


class ActorWrapper:
    """Actor 래퍼 클래스.

    Example:
        req.actor.type       # "organizationMember"
        req.actor.id         # 액터 ID (편의 속성)
        req.actor.data.name  # actor 데이터의 name 필드

        # Lazy loading support
        # organizationMember 타입일 때 상세 정보 lazy loading
        await req.actor.organizationMember.name  # async fetch
        print(req.actor.organizationMember.name)  # sync fetch
    """

    def __init__(
        self,
        data: Optional[Dict[str, Any]],
        web_client: Optional[Union["AsyncWebClient", "WebClient"]] = None
    ):
        self._data = data or {}
        self._data_wrapper: Optional[DataWrapper] = None
        self._web_client = web_client
        self._lazy_member_data: Optional[LazyMemberData] = None

    @property
    def type(self) -> Optional[str]:
        """액터 타입 (member, organizationMember 등)."""
        return self._data.get("type")

    @property
    def id(self) -> Optional[str]:
        """액터 ID (편의 속성)."""
        if self.data:
            return self.data.get("id")
        return None

    @property
    def data(self) -> Optional[DataWrapper]:
        """액터 상세 데이터 (dot notation 지원).

        Example:
            req.actor.data.id     # actor 데이터의 id
            req.actor.data.name   # actor 데이터의 name
            req.actor.data["id"]  # dict 접근도 가능
        """
        if self.type:
            raw_data = self._data.get(self.type)
            if raw_data is not None:
                if self._data_wrapper is None:
                    self._data_wrapper = DataWrapper(raw_data)
                return self._data_wrapper
        return None

    @property
    def raw(self) -> Dict[str, Any]:
        """원본 dict 데이터."""
        return self._data

    @property
    def organizationMember(self) -> Optional[Union["LazyMemberData", "DataWrapper"]]:
        """조직 멤버 정보 (lazy loading 지원).

        웹소켓 메시지의 로컬 데이터는 즉시 반환되고,
        추가 정보는 API 호출을 통해 lazy loading됩니다.

        Example:
            # Async 접근 (await 사용)
            name = await req.actor.organizationMember.name
            email = await req.actor.organizationMember.externalEmailAddress

            # Sync 접근 (async 컨텍스트 외부에서만)
            print(req.actor.organizationMember.name)
            if req.actor.organizationMember.name == "홍길동":
                ...

        Returns:
            LazyMemberData: web_client가 있을 때 lazy loading 지원
            DataWrapper: web_client가 없을 때 로컬 데이터만 반환
            None: organizationMember 데이터가 없는 경우
        """
        raw_data = self._data.get("organizationMember")
        if raw_data is None or not isinstance(raw_data, dict):
            return None

        # web_client가 있으면 LazyMemberData 반환
        if self._web_client is not None:
            if self._lazy_member_data is None:
                member_id = raw_data.get("id")
                if member_id:
                    self._lazy_member_data = LazyMemberData(
                        local_data=raw_data,
                        member_id=member_id,
                        web_client=self._web_client
                    )
            if self._lazy_member_data is not None:
                return self._lazy_member_data

        # web_client가 없으면 DataWrapper 반환 (하위 호환)
        return DataWrapper(raw_data)

    def get(self, key: str, default: Any = None) -> Any:
        """dict처럼 접근 지원."""
        return self._data.get(key, default)

    def __bool__(self) -> bool:
        return bool(self._data)

    def __repr__(self) -> str:
        return f"ActorWrapper({self._data})"

    def __getattr__(self, name: str) -> Any:
        """Dynamic attribute access for other actor types.

        For non-organizationMember types, returns DataWrapper.
        organizationMember is handled by the explicit property.
        """
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

        if name in self._data:
            raw_data = self._data[name]
            if isinstance(raw_data, dict):
                return DataWrapper(raw_data)
            return raw_data

        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")


class ActionWrapper:
    """Action 래퍼 클래스 (str 하위호환).

    Unified structure pattern (same as Entity/Actor):
        {"type": "create", "create": {...action_data...}}

    Example:
        req.action == "create"       # str 비교 (하위호환)
        req.action.type              # "create"
        req.action.create            # action 데이터 (DataWrapper)
        req.action.data.scope        # action 데이터의 scope 필드 (legacy)
    """

    def __init__(self, data: Optional[Dict[str, Any]]):
        self._data = data or {}
        self._data_wrapper: Optional[DataWrapper] = None

    @property
    def type(self) -> Optional[str]:
        """액션 타입 (create, update, delete 등)."""
        return self._data.get("type")

    @property
    def data(self) -> Optional[DataWrapper]:
        """액션별 추가 데이터 (dot notation 지원).

        Example:
            req.action.data.scope        # action 데이터의 scope
            req.action.data["expiredAt"] # dict 접근도 가능
        """
        if self.type:
            raw_data = self._data.get(self.type)
            if raw_data is not None:
                if self._data_wrapper is None:
                    self._data_wrapper = DataWrapper(raw_data)
                return self._data_wrapper
        return None

    @property
    def raw(self) -> Dict[str, Any]:
        """원본 dict 데이터."""
        return self._data

    def get(self, key: str, default: Any = None) -> Any:
        """dict처럼 접근 지원."""
        return self._data.get(key, default)

    def __getattr__(self, name: str) -> Any:
        """Dynamic attribute access support.

        Allows accessing action data by type name:
            req.action.create  # Returns DataWrapper for create action data
            req.action.update  # Returns DataWrapper for update action data
        """
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
        if name in self._data:
            raw_data = self._data[name]
            if isinstance(raw_data, dict):
                return DataWrapper(raw_data)
            return raw_data
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

    # str 하위호환 메서드
    def __eq__(self, other: Any) -> bool:
        if isinstance(other, str):
            # Handle None type case for backward compatibility with empty string
            return (self.type or "") == other
        if isinstance(other, ActionWrapper):
            return (self.type or "") == (other.type or "")
        return False

    def __hash__(self) -> int:
        return hash(self.type or "")

    def __str__(self) -> str:
        return self.type or ""

    def __repr__(self) -> str:
        return f"ActionWrapper({self._data})"

    def __bool__(self) -> bool:
        return bool(self.type)


@dataclass
class SocketModeRequest:
    """
    Represents a request received from Dooray via Socket Mode.

    This class encapsulates the data received from Dooray's WebSocket connection,
    including the request type, payload, and metadata.

    Attributes:
        envelope_id: 요청 식별자
        type: 요청 타입 ("message", "task", "page" 등)
        payload: 요청 데이터
        accepts_response_payload: 응답 페이로드 수락 여부
        service: 서비스 타입 ("messenger", "task", "wiki")
        action: 이벤트 액션 ("create", "update", "delete", "comment" 등)
        entity: entity 필드 (optional)
        actor: actor 필드 (optional)
        action_data: action 데이터 (optional)

    Example:
        @client.on("message")
        async def handle(req):
            print(req.text)      # 메시지 텍스트
            print(req.channel)   # 채널 ID
            await req.reply("Hello!")  # 응답 전송

        @client.on("task", action="create")
        async def handle_task(req):
            print(req.service)   # "task"
            print(req.action)    # "create"
            print(req.data)      # 업무 데이터
            print(req.entity.type)    # "task"
            print(req.entity.data)    # task 상세 데이터
            print(req.actor.id)       # 액터 ID
            print(req.action.type)    # "create"
            print(req.action.data)    # 액션 추가 데이터
    """

    envelope_id: str
    type: str
    payload: Dict[str, Any]
    accepts_response_payload: bool = False
    service: str = "messenger"  # 서비스 타입 (기본값: messenger for backward compatibility)
    action: str = ""  # 이벤트 액션

    entity: Any = None  # EntityWrapper 또는 Dict (자동 변환)
    actor: Any = None   # ActorWrapper 또는 Dict (자동 변환)
    action_data: Optional[Dict[str, Any]] = None  # action.data로 접근 (내부용)
    channel_data: Optional[Dict[str, Any]] = None  # 채널 정보 (channel_info로 접근)

    # 내부 사용 (reply 기능용) - DoorayClient/Agent 에서 주입
    _web_client: Optional[Union["AsyncWebClient", "WebClient"]] = field(default=None, repr=False, compare=False)
    _is_async: bool = field(default=True, repr=False, compare=False)
    _sync_reply_func: Optional[Callable] = field(default=None, repr=False, compare=False)
    # ADR-004: 디스패처가 핸들러 호출 직전에 Agent 자신을 주입.
    # `reply()` deprecation 위임이 `agent.messenger.send_message` 로 라우팅하는 데 사용.
    _client: Optional[Any] = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        """Dict를 래퍼 객체로 자동 변환."""
        # entity: Dict -> EntityWrapper
        if self.entity is not None and not isinstance(self.entity, EntityWrapper):
            self.entity = EntityWrapper(self.entity)
        elif self.entity is None:
            self.entity = EntityWrapper(None)

        # actor: Dict -> ActorWrapper (with web_client for lazy loading)
        if self.actor is not None and not isinstance(self.actor, ActorWrapper):
            self.actor = ActorWrapper(self.actor, web_client=self._web_client)
        elif self.actor is None:
            self.actor = ActorWrapper(None, web_client=self._web_client)

        # action: str/dict -> ActionWrapper (unified structure)
        if not isinstance(self.action, ActionWrapper):
            if isinstance(self.action, str):
                action_type = self.action
                action_dict = {
                    "type": action_type,
                    action_type: self.action_data or {}
                } if action_type else {}
                self.action = ActionWrapper(action_dict)
            else:
                # Already a dict with unified structure
                self.action = ActionWrapper(self.action)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SocketModeRequest":
        """
        Create a SocketModeRequest from a dictionary.

        Args:
            data: Dictionary containing request data

        Returns:
            SocketModeRequest: The created request object
        """
        payload = data.get("payload") or data.get("content") or {}
        return cls(
            envelope_id=data.get("envelope_id", ""),
            type=data.get("type", ""),
            payload=payload,
            accepts_response_payload=data.get("accepts_response_payload", False),
            service=data.get("service", "messenger"),
            action=data.get("action", ""),
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the request to a dictionary.

        Returns:
            Dict[str, Any]: Dictionary representation of the request
        """
        return {
            "envelope_id": self.envelope_id,
            "type": self.type,
            "payload": self.payload,
            "accepts_response_payload": self.accepts_response_payload,
            "service": self.service,
            "action": str(self.action),
        }

    # === 타입 체크 속성 ===

    @property
    def is_message(self) -> bool:
        """Check if this is a message request."""
        return self.type == "message"

    @property
    def is_task(self) -> bool:
        """Check if this is a task request."""
        return self.type == "task"

    @property
    def is_page(self) -> bool:
        """Check if this is a wiki page request."""
        return self.type == "page"

    def is_service(self, service: str) -> bool:
        """Check if this request is from the specified service."""
        return self.service == service

    def is_action_type(self, action: Union[str, list]) -> bool:
        """Check if this request has the specified action(s)."""
        if isinstance(action, list):
            return self.action in action
        return self.action == action

    # === getter 메서드 ===

    def get_message_text(self) -> Optional[str]:
        """Get the message text if this is a message request."""
        if self.is_message:
            # Dooray channelLog format: payload["text"]
            if "text" in self.payload:
                return self.payload["text"]
        return None

    def get_channel(self) -> Optional[str]:
        """Get the channel ID from the request."""
        # Dooray channelLog format: payload["channelId"]
        if "channelId" in self.payload:
            return self.payload["channelId"]
        return None

    # === 단축 속성 ===

    @property
    def text(self) -> Optional[str]:
        """메시지 텍스트."""
        return self.get_message_text()

    @property
    def channel(self) -> Optional[str]:
        """채널 ID.

        .. deprecated::
            Use `channel_info.id` instead. This property will be removed in a future version.
        """
        warnings.warn(
            "req.channel is deprecated. Use req.channel_info.id instead.",
            DeprecationWarning,
            stacklevel=2
        )
        return self.get_channel()

    @property
    def channel_info(self) -> Optional[ChannelInfo]:
        """채널 정보 (id, scope, type 포함)."""
        if self.channel_data and isinstance(self.channel_data, dict):
            return ChannelInfo(self.channel_data)
        return None

    @property
    def data(self) -> Dict[str, Any]:
        """서비스 중립적 데이터 접근 (payload의 별칭)."""
        return self.payload

    # === 응답 메서드 ===

    def reply(self, text: str, **kwargs) -> Dict[str, Any]:
        """
        현재 채널에 응답 메시지 전송.

        .. deprecated::
            ADR-004로 인해 한 마이너 동안 deprecation alias로 유지된다.
            신규 코드는 ``client.messenger.send_message(channel=req.channel_info.id,
            text=...)`` 를 직접 호출하세요.

        Args:
            text: 응답 메시지
            **kwargs: 추가 메시지 옵션

        Returns:
            API 응답 (async의 경우 coroutine)
        """
        warnings.warn(
            "req.reply() is deprecated. "
            "Use client.messenger.send_message(channel=req.channel_info.id, text=...) "
            "from a (req, client) handler instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._is_async:
            return self._async_reply(text, **kwargs)
        else:
            return self._sync_reply(text, **kwargs)

    async def _async_reply(self, text: str, **kwargs) -> Dict[str, Any]:
        """비동기 응답 전송 (deprecation 위임 경로).

        ``_client`` 가 주입되어 있으면 신규 표면(``client.messenger.send_message``)
        으로 위임한다. fallback으로 기존 ``_web_client`` 트랜스포트의 메신저 API를
        호출한다 (deprecation 신호 중첩을 막기 위해 ``.messenger`` 경로 사용).
        """
        channel = self.get_channel()
        if self._client is not None:
            if not channel:
                raise ValueError("Channel information not found")
            return await self._client.messenger.send_message(channel, text, **kwargs)

        if not self._web_client:
            raise RuntimeError("reply() can only be used inside a DoorayClient handler")

        if not channel:
            raise ValueError("Channel information not found")

        # _web_client 가 messenger 속성을 가지면 사용, 아니면 평면 send_message fallback.
        messenger = getattr(self._web_client, "messenger", None)
        if messenger is not None:
            return await messenger.send_message(channel, text, **kwargs)
        return await self._web_client.send_message(channel, text, **kwargs)

    def _sync_reply(self, text: str, **kwargs) -> Dict[str, Any]:
        """동기 응답 전송 (deprecation 위임 경로).

        Agent에서 주입된 _sync_reply_func가 있으면 그것을 사용한다
        (비동기→동기 브릿지). 다음으로 `_client` 의 동기 messenger,
        마지막으로 `_web_client` fallback 순서.
        """
        # Agent에서 주입된 동기 reply 함수 사용 (비동기→동기 브릿지)
        if self._sync_reply_func is not None:
            return self._sync_reply_func(text)

        if not self._web_client:
            raise RuntimeError("reply() can only be used inside a handler")

        channel = self.get_channel()
        if not channel:
            raise ValueError("Channel information not found")

        # deprecation 중첩 방지를 위해 messenger 경로 우선.
        messenger = getattr(self._web_client, "messenger", None)
        if messenger is not None:
            return messenger.send_message(channel, text, **kwargs)
        return self._web_client.send_message(channel, text, **kwargs)
