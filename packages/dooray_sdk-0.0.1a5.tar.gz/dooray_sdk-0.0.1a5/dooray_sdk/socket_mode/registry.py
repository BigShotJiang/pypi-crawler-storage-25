"""
Service Registry

서비스 매핑 레지스트리 - WebSocket 메시지의 service/type을 SDK 내부 타입으로 매핑합니다.
"""

from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class ServiceMapping:
    """서비스 매핑 정보."""
    service: str  # 서비스 이름 (messenger, task, wiki)
    type: str     # 이벤트 타입 (message, task, page)


# service/type 복합 키 → SDK 내부 매핑
# 키 형식: "{service}/{ws_type}"
SERVICE_REGISTRY: Dict[str, ServiceMapping] = {
    # Messenger
    "messenger/channelLog": ServiceMapping(service="messenger", type="message"),

    # Task (업무)
    "task/task": ServiceMapping(service="task", type="task"),

    # Wiki
    "wiki/page": ServiceMapping(service="wiki", type="page"),
}

# 지원하는 서비스 목록
SUPPORTED_SERVICES = ["messenger", "task", "wiki"]

# 지원하는 액션 목록
SUPPORTED_ACTIONS = ["create", "update", "delete", "comment"]


def get_service_mapping(service: str, msg_type: str) -> Optional[ServiceMapping]:
    """
    service/type 복합 키로 매핑 정보를 가져옵니다.

    Args:
        service: 서비스 이름 (messenger, task, wiki 등)
        msg_type: WebSocket 메시지의 type 필드 값

    Returns:
        ServiceMapping or None if not found
    """
    key = f"{service}/{msg_type}"
    return SERVICE_REGISTRY.get(key)


def register_service(service: str, msg_type: str, event_type: str) -> None:
    """
    새로운 서비스 매핑을 등록합니다.

    Args:
        service: 서비스 이름
        msg_type: WebSocket 메시지의 type 필드 값
        event_type: SDK 내부 이벤트 타입
    """
    key = f"{service}/{msg_type}"
    SERVICE_REGISTRY[key] = ServiceMapping(service=service, type=event_type)
    if service not in SUPPORTED_SERVICES:
        SUPPORTED_SERVICES.append(service)


def is_supported_service(service: str) -> bool:
    """서비스가 지원되는지 확인합니다."""
    return service in SUPPORTED_SERVICES


def is_supported_action(action: str) -> bool:
    """액션이 지원되는지 확인합니다."""
    return action in SUPPORTED_ACTIONS
