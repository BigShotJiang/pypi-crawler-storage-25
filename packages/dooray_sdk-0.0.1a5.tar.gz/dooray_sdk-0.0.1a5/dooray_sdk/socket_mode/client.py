"""
Dooray Socket Mode Client (Legacy - Deprecated)

동기 WebSocket 클라이언트입니다.
이 모듈은 더 이상 사용되지 않습니다.
대신 dooray_sdk.socket_mode.aiohttp.client.SocketModeClient를 사용하세요.

Deprecated since: 0.2.0
"""

import json
import logging
import threading
import time
import warnings
from typing import List, Callable, Optional, Dict, Any, Tuple
from urllib.parse import urlparse

import websocket
from .request import SocketModeRequest
from .response import SocketModeResponse
from ..web.client import WebClient
from ..exceptions import DooraySDKError

# Type alias for listener error callback (sync version)
# Callback receives: (exception, listener_name, request)
ListenerErrorCallback = Callable[[Exception, str, "SocketModeRequest"], None]


logger = logging.getLogger(__name__)

# WebSocket 연결 로그를 기본 출력하도록 설정
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    ))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


class SocketModeClient:
    """
    A client for connecting to Dooray via Socket Mode (Legacy - Deprecated).

    .. deprecated:: 0.2.0
        이 동기 클라이언트는 더 이상 사용되지 않습니다.
        대신 ``dooray_sdk.socket_mode.aiohttp.client.SocketModeClient``를 사용하세요.

    Socket Mode allows real-time communication with Dooray using WebSockets
    instead of HTTP requests. This client manages the WebSocket connection
    and provides methods for sending responses back to Dooray.
    """

    def __init__(
        self,
        web_client: WebClient,
        domain: str,
        ping_interval: int = 30,
        ping_timeout: int = 10,
        **kwargs
    ):
        """
        Initialize the SocketModeClient.

        Args:
            web_client: WebClient instance for making API calls
            domain: Dooray domain
            ping_interval: Interval for ping messages (seconds)
            ping_timeout: Timeout for ping responses (seconds)
            **kwargs: Additional arguments
        """
        warnings.warn(
            "동기 SocketModeClient는 deprecated입니다. "
            "dooray_sdk.socket_mode.aiohttp.client.SocketModeClient를 사용하세요.",
            DeprecationWarning,
            stacklevel=2,
        )

        self.web_client = web_client
        self.domain = domain
        self.ping_interval = ping_interval
        self.ping_timeout = ping_timeout

        # Socket Mode credentials (fetched from API)
        self._access_token: Optional[str] = None
        self._tenant_id: Optional[str] = None
        self._member_id: Optional[str] = None

        # WebSocket connection
        self.ws: Optional[websocket.WebSocket] = None
        self.connected = False
        self.thread: Optional[threading.Thread] = None
        self.ping_thread: Optional[threading.Thread] = None
        self.stop_event = threading.Event()

        # Request listeners
        self.socket_mode_request_listeners: List[Callable] = []

        # Error handling
        self._error_callbacks: List[ListenerErrorCallback] = []
        self._raise_listener_errors: bool = False

        # Connection state
        self.connection_attempts = 0
        self.reconnect_delay = 1
        self.max_reconnect_delay = 60  # 최대 재연결 대기 시간 (초)

        logger.debug("SocketModeClient initialized")

    def _fetch_socket_mode_token(self) -> None:
        """
        Fetch Socket Mode token from Open-Api-Gateway.

        This method calls POST /common/v1/socket-mode/tokens to get
        accessToken, tenantId, and organizationMemberId.
        """
        logger.debug("Fetching Socket Mode token...")
        token_info = self.web_client.fetch_socket_mode_token()

        self._access_token = token_info["accessToken"]
        self._tenant_id = token_info["tenantId"]
        self._member_id = token_info["organizationMemberId"]

        logger.debug(f"Socket Mode token fetched: tenantId={self._tenant_id}, memberId={self._member_id}")

    def _build_websocket_url(self) -> str:
        """
        Build WebSocket URL from domain and credentials.
        """
        # Remove protocol if present
        parsed = urlparse(self.domain)
        if parsed.netloc:
            host = parsed.netloc
        else:
            host = parsed.path.split('/')[0]

        return f"wss://{host}/messenger/v5/ws/{self._tenant_id}/{self._member_id}"

    def connect(self) -> None:
        """
        Establish a WebSocket connection to Dooray Socket Mode.

        This method fetches a Socket Mode token, then starts a background thread
        to maintain the WebSocket connection and handle incoming messages.
        """
        if self.connected:
            logger.warning("Already connected to Socket Mode")
            return

        # Fetch Socket Mode token first
        self._fetch_socket_mode_token()

        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run_websocket, daemon=True)
        self.thread.start()

        # Wait for connection to be established
        timeout = 10
        start_time = time.time()
        while not self.connected and time.time() - start_time < timeout:
            time.sleep(0.1)

        if not self.connected:
            raise ConnectionError("Failed to connect to Dooray Socket Mode")

    def disconnect(self) -> None:
        """
        Disconnect from Dooray Socket Mode.

        This method closes the WebSocket connection and stops the background thread.
        """
        logger.info("Disconnecting from Socket Mode")
        self.stop_event.set()
        self.connected = False

        if self.ws:
            self.ws.close()
            self.ws = None

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=5)

    def send_socket_mode_response(self, response: SocketModeResponse) -> None:
        """
        Send a response back to Dooray via Socket Mode.

        Args:
            response: The response to send
        """
        if not self.connected or not self.ws:
            logger.error("Not connected to Socket Mode")
            return

        try:
            message = json.dumps(response.to_dict())
            self.ws.send(message)
            logger.debug(f"Sent response: {message}")
        except Exception as e:
            logger.error(f"Failed to send response: {e}")

    def _run_websocket(self) -> None:
        """Run the WebSocket connection in a background thread."""
        while not self.stop_event.is_set():
            ping_thread = None
            try:
                self._connect_websocket()
                self._handle_messages()
            except Exception as e:
                logger.error(f"WebSocket error: {e}")
            finally:
                self.connected = False
                if self.ws:
                    self.ws.close()
                    self.ws = None

            # 재접속 시도, max 초과 시 루프 탈출
            if not self.stop_event.is_set():
                if not self._handle_reconnect():
                    break

    def _ping_loop(self) -> None:
        """Send periodic ping messages to keep connection alive."""
        while self.connected and self.ws and not self.stop_event.is_set():
            try:
                time.sleep(self.ping_interval)
                if self.connected and self.ws:
                    self.ws.send('{"type":"ping"}')
                    logger.debug("Sent ping message")
            except Exception as e:
                logger.error(f"Failed to send ping: {e}")
                break

    def _connect_websocket(self) -> None:
        """Establish the WebSocket connection."""
        socket_mode_url = self._build_websocket_url()
        logger.info(f"Connecting to {socket_mode_url}")

        self.ws = websocket.WebSocketApp(
            socket_mode_url,
            on_open=self._on_open,
            on_message=self._on_message,
            on_error=self._on_error,
            on_close=self._on_close,
            header={"Authorization": f"Bearer {self._access_token}"},
        )
        self.ws.run_forever(
            ping_interval=self.ping_interval,
            ping_timeout=self.ping_timeout,
        )

    def _handle_messages(self) -> None:
        """Handle incoming messages from the WebSocket."""
        while self.connected and not self.stop_event.is_set():
            time.sleep(0.1)

    def _handle_reconnect(self) -> bool:
        """Handle reconnection logic with exponential backoff.

        Retries indefinitely with exponential backoff up to max_reconnect_delay.

        Returns:
            bool: Always True (infinite retry).
        """
        self.connection_attempts += 1
        delay = min(
            self.reconnect_delay * (2 ** self.connection_attempts),
            self.max_reconnect_delay
        )
        logger.info(f"Reconnecting in {delay} seconds (attempt {self.connection_attempts})")

        time.sleep(delay)

        # Refresh token before reconnection
        try:
            self._fetch_socket_mode_token()
        except Exception as e:
            logger.error(f"Failed to refresh Socket Mode token: {e}")

        return True

    def _on_open(self, ws: websocket.WebSocketApp) -> None:
        """Handle WebSocket connection open."""
        logger.info("Connected to Dooray Socket Mode")
        self.connected = True
        self.connection_attempts = 0

        # Start ping thread
        self.ping_thread = threading.Thread(target=self._ping_loop, daemon=True)
        self.ping_thread.start()

    def _on_message(self, ws: websocket.WebSocketApp, message: str) -> None:
        """Handle incoming WebSocket messages."""
        try:
            data = json.loads(message)
            logger.debug(f"Received message: {data}")

            # 내부 처리: SDK에서 필터링
            msg_type = data.get("type", "")
            msg_action = data.get("action", "")

            # sessionInfo는 로깅만 하고 사용자에게 전달하지 않음
            if msg_type == "sessionInfo":
                logger.debug(f"Session established: {data.get('content', {})}")
                return

            # channelLog + (create 또는 update) 만 사용자에게 전달
            if msg_type != "channelLog" or msg_action not in ("create", "update"):
                return

            # content 내 type이 1인 경우 필터링 (시스템 메시지 등)
            content = data.get("content", {})
            content_type = content.get("type")
            if content_type == 1:
                return

            # content에 channelId가 없으면 root에서 가져와서 추가
            if "channelId" not in content and "channelId" in data:
                content["channelId"] = data["channelId"]

            # Actor extraction with senderId fallback
            actor = data.get("actor")
            if actor is None and content.get("senderId"):
                actor = {
                    "type": "organizationMember",
                    "organizationMember": {"id": content["senderId"]}
                }

            # Action with unified structure
            action_str = data.get("action", "")
            action_data = data.get("action_data", {})
            action = {
                "type": action_str,
                action_str: action_data
            } if action_str else None

            # channelLog를 message로 매핑하여 request 생성
            request = SocketModeRequest(
                envelope_id=data.get("envelope_id", ""),
                type="message",  # channelLog → message
                payload=content,
                accepts_response_payload=data.get("accepts_response_payload", False),
                service="messenger",
                action=action,
                entity={"type": "message", "message": content},
                actor=actor,
            )

            # @MX:NOTE: [AUTO] Listener execution with enhanced error handling
            # Collects errors from all listeners, notifies callbacks, and optionally re-raises
            errors: List[Tuple[str, Exception]] = []
            for listener in self.socket_mode_request_listeners:
                listener_name = getattr(listener, "__name__", str(listener))
                try:
                    listener(self, request)
                except Exception as e:
                    logger.error(
                        f"Error in listener '{listener_name}': {e}",
                        exc_info=True,
                        extra={"listener": listener_name},
                    )
                    errors.append((listener_name, e))
                    self._notify_listener_error(e, listener_name, request)

            # Optional: re-raise first error if strict mode is enabled
            if errors and self._raise_listener_errors:
                first_name, first_error = errors[0]
                raise DooraySDKError(
                    f"Listener '{first_name}' failed",
                    error_code="LISTENER_ERROR",
                    context={"listener": first_name, "total_errors": len(errors)},
                ) from first_error

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse message as JSON: {e}", exc_info=True)
        except Exception as e:
            logger.error(f"Error handling message: {e}", exc_info=True)

    def _on_error(self, ws: websocket.WebSocketApp, error: Exception) -> None:
        """Handle WebSocket errors."""
        logger.error(f"WebSocket error: {error}", exc_info=True)

    def _on_close(self, ws: websocket.WebSocketApp, close_status_code: int, close_msg: str) -> None:
        """Handle WebSocket connection close."""
        logger.warning(f"WebSocket closed: {close_status_code} - {close_msg}")
        self.connected = False

    def add_listener(self, listener: Callable) -> None:
        """
        Add a request listener.

        Args:
            listener: Function to call when a request is received
        """
        self.socket_mode_request_listeners.append(listener)

    def remove_listener(self, listener: Callable) -> None:
        """
        Remove a request listener.

        Args:
            listener: Function to remove
        """
        if listener in self.socket_mode_request_listeners:
            self.socket_mode_request_listeners.remove(listener)

    def on_listener_error(self, callback: ListenerErrorCallback) -> None:
        """
        Register a callback for listener errors.

        The callback receives (exception, listener_name, request) and can be used
        for custom error logging, metrics, or alerting.

        Args:
            callback: Function to call when a listener raises an exception.
        """
        self._error_callbacks.append(callback)

    def set_raise_listener_errors(self, enabled: bool) -> None:
        """
        Enable or disable strict error mode.

        When enabled, the first listener error will be re-raised as DooraySDKError
        after all listeners have been executed.

        Args:
            enabled: True to enable strict mode, False to disable.
        """
        self._raise_listener_errors = enabled

    def _notify_listener_error(
        self,
        error: Exception,
        listener_name: str,
        request: SocketModeRequest,
    ) -> None:
        """
        Notify all error callbacks about a listener error.

        Args:
            error: The exception raised by the listener.
            listener_name: Name of the listener that raised the error.
            request: The SocketModeRequest being processed.
        """
        for callback in self._error_callbacks:
            try:
                callback(error, listener_name, request)
            except Exception as cb_error:
                logger.error(
                    f"Error callback failed: {cb_error}",
                    exc_info=True,
                )

    def is_connected(self) -> bool:
        """
        Check if the client is connected to Socket Mode.

        Returns:
            bool: True if connected, False otherwise
        """
        return self.connected and self.ws is not None
