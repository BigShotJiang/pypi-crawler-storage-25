"""
Dooray Socket Mode Client with aiohttp

Async WebSocket-based client for real-time communication with Dooray.
"""

from .client import SocketModeClient

__all__ = ["SocketModeClient"]
