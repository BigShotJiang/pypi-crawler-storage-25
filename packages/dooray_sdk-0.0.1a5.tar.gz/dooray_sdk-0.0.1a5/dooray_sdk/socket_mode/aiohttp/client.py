"""
Dooray Socket Mode Client with aiohttp

Async WebSocket-based client for real-time communication with Dooray.
"""

import asyncio
import inspect
import json
import logging
import random
import time
from enum import Enum
from typing import List, Callable, Optional, Dict, Any, Awaitable, Tuple, Union
from urllib.parse import urlparse

import aiohttp
from ..request import SocketModeRequest
from ..response import SocketModeResponse
from ..registry import get_service_mapping
from ...web.async_client import AsyncWebClient
from ...exceptions import DooraySDKError

# Type alias for listener error callback
# Callback receives: (exception, listener_name, request)
ListenerErrorCallback = Callable[
    [Exception, str, "SocketModeRequest"], Awaitable[None]
]

# Type alias for lifecycle hook callbacks (on_disconnect / on_reconnect).
# Callback receives: (client, info_dict). info keys include:
#   attempt: int, error: Optional[Exception], close_code: Optional[int],
#   close_reason: Optional[str], delay: Optional[float]
# Both sync and async callables are accepted; sync callbacks run in the event
# loop (do not block on long IO inside them).
LifecycleHook = Callable[
    ["SocketModeClient", Dict[str, Any]],
    Union[None, Awaitable[None]],
]


logger = logging.getLogger(__name__)


class ConnectionState(str, Enum):
    """Active-Standby HA 운영을 위한 Socket Mode 연결 상태."""

    DISCONNECTED = "DISCONNECTED"
    CONNECTING = "CONNECTING"
    ACTIVE = "ACTIVE"
    STANDBY = "STANDBY"


# 서버(messenger5-websocket)가 에이전트 세션 중복 거부 시 반환하는 시그널.
# messenger5-websocket#11155 - 에이전트 토큰당 웹소켓 세션 최대 1개 제한
SESSION_LIMIT_CLOSE_CODE = 1008
SESSION_LIMIT_CLOSE_REASON = "AGENT_ALREADY_CONNECTED"

# Standby 상태에서 재연결을 시도하는 고정 간격(초).
# 서버 Redis 락 TTL 30초 + 하트비트 10초를 고려한 값.
STANDBY_RETRY_INTERVAL = 15

# Auto-reconnect backoff defaults (slack_sdk와 유사한 값).
# 무한 재시도이므로 max_delay에서 cap. jitter는 thundering herd 회피.
DEFAULT_RECONNECT_INITIAL_DELAY = 1.0
DEFAULT_RECONNECT_MAX_DELAY = 30.0
DEFAULT_RECONNECT_BACKOFF_MULTIPLIER = 2.0
DEFAULT_RECONNECT_JITTER_RATIO = 0.5


class SocketModeClient:
    """
    An async client for connecting to Dooray via Socket Mode using aiohttp.

    Socket Mode allows real-time communication with Dooray using WebSockets
    instead of HTTP requests. This client manages the WebSocket connection
    and provides methods for sending responses back to Dooray.
    """

    def __init__(
        self,
        web_client: AsyncWebClient,
        domain: str,
        ping_interval: int = 30,
        ws_path: str = "/messenger/v5/ws",
        port: int = None,
        default_service: str = None,
        *,
        auto_reconnect_enabled: bool = True,
        reconnect_initial_delay: float = DEFAULT_RECONNECT_INITIAL_DELAY,
        reconnect_max_delay: float = DEFAULT_RECONNECT_MAX_DELAY,
        reconnect_backoff_multiplier: float = DEFAULT_RECONNECT_BACKOFF_MULTIPLIER,
        reconnect_jitter_ratio: float = DEFAULT_RECONNECT_JITTER_RATIO,
        pong_timeout: Optional[float] = None,
        **kwargs
    ):
        """
        Initialize the SocketModeClient.

        Args:
            web_client: AsyncWebClient instance for making API calls
            domain: Dooray domain
            ping_interval: Interval for ping messages (seconds)
            ws_path: WebSocket path (default: /messenger/v5/ws)
            port: WebSocket port (default: None, uses default 443)
            default_service: Default service name when message has no service field
            auto_reconnect_enabled: When True (default), the client transparently
                reconnects on close / network errors with exponential backoff +
                jitter. When False, a single close terminates the WebSocket task
                so the agent (or external orchestrator) can fail fast.
            reconnect_initial_delay: First backoff delay (seconds) after a close.
            reconnect_max_delay: Upper cap for exponential backoff (seconds).
            reconnect_backoff_multiplier: Backoff growth factor between attempts.
            reconnect_jitter_ratio: Fractional jitter applied to each delay
                (full-jitter variant); 0 disables jitter (determinism for tests).
            pong_timeout: Seconds to wait for a pong / inbound traffic before
                forcing the WebSocket closed as stale. Defaults to
                ``ping_interval * 2``.
            **kwargs: Additional arguments
        """
        self.web_client = web_client
        self.domain = domain
        self.ping_interval = ping_interval
        self.ws_path = ws_path
        self.port = port
        self.default_service = default_service

        # Auto-reconnect / stale-detection knobs (see open-questions.md for defaults).
        self.auto_reconnect_enabled = auto_reconnect_enabled
        self.reconnect_initial_delay = reconnect_initial_delay
        self.reconnect_max_delay = reconnect_max_delay
        self.reconnect_backoff_multiplier = reconnect_backoff_multiplier
        self.reconnect_jitter_ratio = reconnect_jitter_ratio
        self.pong_timeout = (
            pong_timeout if pong_timeout is not None else ping_interval * 2
        )

        # Socket Mode credentials (fetched from API)
        self._access_token: Optional[str] = None
        self._tenant_id: Optional[str] = None
        self._member_id: Optional[str] = None

        # WebSocket connection
        self.ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self.session: Optional[aiohttp.ClientSession] = None
        self.connected = False
        self.task: Optional[asyncio.Task] = None

        # Request listeners
        self.socket_mode_request_listeners: List[Callable] = []

        # Error handling
        self._error_callbacks: List[ListenerErrorCallback] = []
        self._raise_listener_errors: bool = False

        # Lifecycle hooks (auto-reconnect observability).
        self._on_disconnect_callbacks: List[LifecycleHook] = []
        self._on_reconnect_callbacks: List[LifecycleHook] = []

        # HA 상태 & 마지막 close 시그널
        self.state: ConnectionState = ConnectionState.DISCONNECTED
        self._last_close_code: Optional[int] = None
        self._last_close_reason: Optional[str] = None

        # Stale 감지: 마지막으로 inbound 트래픽(pong 포함)을 받은 시점(monotonic).
        # _ping_loop이 이 값을 기준으로 pong_timeout 초과 시 강제 close 트리거.
        self._last_inbound_at: Optional[float] = None

        # 재연결 시도 카운터 (성공 시 0으로 리셋, hook info에 노출).
        self._reconnect_attempt: int = 0

        # STANDBY 재시도 루프 진행 중 여부.
        # False = 초기/ACTIVE 상태, True = 이미 STANDBY 재시도를 1회 이상 수행.
        # 반복되는 상태 전이/연결 시도 로그를 DEBUG로 강등하는 데 쓰인다.
        self._in_standby_loop: bool = False

        logger.info(
            "Async SocketModeClient initialized "
            "(auto_reconnect_enabled=%s, pong_timeout=%s)",
            self.auto_reconnect_enabled,
            self.pong_timeout,
        )

    async def _fetch_socket_mode_token(self) -> None:
        """
        Fetch Socket Mode token from Open-Api-Gateway.

        This method calls POST /common/v1/socket-mode/tokens to get
        accessToken, tenantId, and organizationMemberId.
        """
        level = self._loop_log_level()
        logger.log(level, "Fetching Socket Mode token...")
        token_info = await self.web_client.fetch_socket_mode_token()

        self._access_token = token_info["accessToken"]
        self._tenant_id = token_info["tenantId"]
        self._member_id = token_info["organizationMemberId"]

        logger.log(
            level,
            f"Socket Mode token fetched: tenantId={self._tenant_id}, "
            f"memberId={self._member_id}",
        )

    def _loop_log_level(self) -> int:
        """
        반복 재시도 루프에서 쓰는 로그 레벨.

        STANDBY 사이클 진행 중에는 DEBUG, 최초/ACTIVE 상태에서는 INFO.
        """
        return logging.DEBUG if self._in_standby_loop else logging.INFO

    def _build_websocket_url(self) -> str:
        """
        Build WebSocket URL from domain and credentials.
        """
        # Remove protocol if present
        parsed = urlparse(self.domain)
        if parsed.netloc:
            host = parsed.netloc
        else:
            host = parsed.path.split('/')[0]

        # 포트가 지정된 경우 host에 포트 추가
        if self.port:
            # 기존 포트가 있으면 제거 후 새 포트 추가
            if ":" in host:
                host = host.split(":")[0]
            host = f"{host}:{self.port}"

        return f"wss://{host}{self.ws_path}/{self._tenant_id}/{self._member_id}"

    async def connect(self) -> None:
        """
        Establish a WebSocket connection to Dooray Socket Mode.

        This method fetches a Socket Mode token, then starts a background task
        to maintain the WebSocket connection and handle incoming messages.

        에이전트 세션이 이미 다른 인스턴스에 의해 점유된 경우, 이 메서드는
        standby 상태 진입을 성공으로 간주하고 반환합니다.
        """
        if self.state in (ConnectionState.ACTIVE, ConnectionState.STANDBY):
            logger.warning("Socket Mode already connected or standing by")
            return

        # Fetch Socket Mode token first
        await self._fetch_socket_mode_token()

        self.session = aiohttp.ClientSession()
        self.task = asyncio.create_task(self._run_websocket())

        # ACTIVE 또는 STANDBY 진입을 기다린다 (첫 시도가 세션 중복이면 STANDBY)
        timeout = 30
        start_time = time.monotonic()
        terminal = (ConnectionState.ACTIVE, ConnectionState.STANDBY)
        while self.state not in terminal and time.monotonic() - start_time < timeout:
            if self.task.done():
                # 태스크가 예외로 종료된 경우 원인 전파
                exc = self.task.exception()
                if exc:
                    raise exc
                break
            await asyncio.sleep(0.1)

        if self.state not in terminal:
            raise ConnectionError("Failed to connect to Dooray Socket Mode")

        logger.info(
            f"Socket Mode connect() returned with state={self.state.value}"
        )

    async def disconnect(self) -> None:
        """
        Disconnect from Dooray Socket Mode.

        This method closes the WebSocket connection and stops the background task.
        """
        logger.info("Disconnecting from Socket Mode")
        self.connected = False
        self._set_state(ConnectionState.DISCONNECTED)

        if self.ws:
            await self.ws.close()
            self.ws = None

        if self.task and not self.task.done():
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass

        if self.session:
            await self.session.close()
            self.session = None

    async def send_socket_mode_response(self, response: SocketModeResponse) -> None:
        """
        Send a response back to Dooray via Socket Mode.
        
        Args:
            response: The response to send
        """
        if not self.connected or not self.ws:
            logger.error("Not connected to Socket Mode")
            return
        
        try:
            message = json.dumps(response.to_dict())
            await self.ws.send_str(message)
            logger.debug(f"Sent response: {message}")
        except Exception as e:
            logger.error(f"Failed to send response: {e}")

    async def _run_websocket(self) -> None:
        """
        WebSocket 연결을 유지하는 백그라운드 루프.

        재연결 정책:
        - `1008 AGENT_ALREADY_CONNECTED`: 항상 STANDBY 진입 후 고정 간격 재시도
          (`auto_reconnect_enabled` 값과 무관 — 서버 측 세션 충돌은 SDK가 해결).
        - `auto_reconnect_enabled=True` (기본): 그 외 모든 close / 네트워크 오류 /
          stale(pong timeout) 시 exponential backoff + jitter로 무한 재시도.
        - `auto_reconnect_enabled=False`: 1회 close 후 루프 탈출 → task 종료.
          상위(`Agent._run_forever`)가 task 종료를 감지하고 fail-fast.

        ``disconnect()``에 의해 ``state == DISCONNECTED``로 전이되면 어떤 경우에도
        루프를 탈출한다(의도적 종료 회귀 방지).
        """
        connection_error: Optional[BaseException] = None
        while True:
            ping_task = None
            self._last_close_code = None
            self._last_close_reason = None
            connection_error = None
            self._last_inbound_at = time.monotonic()

            try:
                self._set_state(ConnectionState.CONNECTING)
                await self._connect_websocket()
                ping_task = asyncio.create_task(self._ping_loop())
                # Handle messages (blocks until connection closes)
                await self._handle_messages()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                connection_error = e
                # 재연결 정책이 backoff + retry이므로 통상은 노이즈. traceback은 DEBUG에서만.
                # 운영자 인지는 직후의 WARNING "WebSocket closed (code=..., reason=..., error=...) — reconnecting in ..."로 충분.
                logger.debug(f"WebSocket error: {e}", exc_info=True)
            finally:
                if ping_task and not ping_task.done():
                    ping_task.cancel()
                    try:
                        await ping_task
                    except asyncio.CancelledError:
                        pass
                self.connected = False
                if self.ws:
                    # close_code / close_reason fallback
                    if self._last_close_code is None:
                        self._last_close_code = self.ws.close_code
                    await self.ws.close()
                    self.ws = None

            if self.state == ConnectionState.DISCONNECTED:
                # disconnect()에 의한 의도적 종료
                break

            # 세션 중복은 auto_reconnect 옵션과 무관하게 항상 STANDBY 사이클을 돌린다.
            if connection_error is None and self._is_session_limit_close():
                await self._handle_standby()
                continue

            # close / 네트워크 오류 발생 → on_disconnect hook 호출
            await self._dispatch_lifecycle(
                self._on_disconnect_callbacks,
                {
                    "attempt": self._reconnect_attempt,
                    "error": connection_error,
                    "close_code": self._last_close_code,
                    "close_reason": self._last_close_reason,
                },
            )

            if not self.auto_reconnect_enabled:
                # fail-fast: 1회 close 후 종료. 상위가 task done을 감지.
                error_repr = repr(connection_error) if connection_error else None
                logger.info(
                    f"WebSocket closed and auto_reconnect_enabled=False — "
                    f"terminating run loop "
                    f"(code={self._last_close_code}, "
                    f"reason={self._last_close_reason!r}, "
                    f"error={error_repr})"
                )
                self._set_state(ConnectionState.DISCONNECTED)
                break

            # auto-reconnect 활성: backoff + jitter로 재시도.
            self._reconnect_attempt += 1
            delay = self._compute_backoff_delay(self._reconnect_attempt)
            logger.warning(
                "WebSocket closed (code=%s, reason=%r, error=%s) — "
                "reconnecting in %.2fs (attempt %d)",
                self._last_close_code,
                self._last_close_reason,
                repr(connection_error) if connection_error else None,
                delay,
                self._reconnect_attempt,
            )
            await self._dispatch_lifecycle(
                self._on_reconnect_callbacks,
                {
                    "attempt": self._reconnect_attempt,
                    "delay": delay,
                    "error": connection_error,
                    "close_code": self._last_close_code,
                    "close_reason": self._last_close_reason,
                },
            )
            await asyncio.sleep(delay)
            continue

    def _compute_backoff_delay(self, attempt: int) -> float:
        """
        Exponential backoff + full-jitter delay 계산.

        attempt=1 → initial_delay 부근 (jitter 적용), 이후 multiplier^k 곱하며
        max_delay에서 cap. jitter_ratio=0이면 결정적, 양수면 [base, base*(1+ratio)] 균등.

        결정적 시퀀스 검증(테스트 6)을 위해 jitter_ratio=0을 허용한다.

        무한 재시도 정책상 attempt 카운터가 수백~수만에 도달해도 안전해야 하므로,
        곱셈 단계에서 OverflowError가 나지 않도록 **곱하기 전에** max_delay 도달
        여부를 먼저 검사한다. (slack_sdk가 ``min`` 후 곱셈하는 패턴과 동일.)
        """
        if attempt <= 0:
            attempt = 1
        # 곱셈 overflow 방지: 누적 곱이 cap 넘는 지점 이후엔 그냥 cap.
        base = self.reconnect_initial_delay
        cap = self.reconnect_max_delay
        for _ in range(attempt - 1):
            if base >= cap:
                base = cap
                break
            base *= self.reconnect_backoff_multiplier
        base = min(base, cap)
        if self.reconnect_jitter_ratio <= 0:
            return base
        jitter = random.uniform(0.0, base * self.reconnect_jitter_ratio)
        return min(base + jitter, cap)

    async def _dispatch_lifecycle(
        self,
        callbacks: List[LifecycleHook],
        info: Dict[str, Any],
    ) -> None:
        """
        Lifecycle hook 콜백들을 순서대로 호출한다. 콜백 예외는 격리되어
        재연결 루프를 절대 중단시키지 않는다(PRD FR-5).
        """
        if not callbacks:
            return
        for cb in callbacks:
            try:
                result = cb(self, dict(info))
                if inspect.isawaitable(result):
                    await result
            except asyncio.CancelledError:
                raise
            except Exception as cb_error:
                logger.error(
                    "Lifecycle hook %r failed (isolated): %s",
                    getattr(cb, "__name__", str(cb)),
                    cb_error,
                    exc_info=True,
                )

    async def _ping_loop(self) -> None:
        """
        Send periodic ping messages and detect stale (half-open) connections.

        ping을 송신할 뿐 아니라 마지막 inbound 트래픽(pong 포함) 시각을 확인해
        ``pong_timeout`` 초과 시 ws를 강제 close한다. 강제 close는 상위
        ``_handle_messages``의 receive 루프를 종료시키고, ``_run_websocket``의
        재연결 사이클을 트리거한다.

        Stale 감지는 송신측만 살아있는 절반-끊김(half-open) 상태에서 close
        이벤트조차 발생하지 않는 시나리오를 해결한다.
        """
        while self.connected and self.ws:
            try:
                await asyncio.sleep(self.ping_interval)
                if not (self.connected and self.ws):
                    break

                # Stale 체크: 마지막 inbound로부터 너무 오래 지났으면 강제 close.
                if self._last_inbound_at is not None:
                    elapsed = time.monotonic() - self._last_inbound_at
                    if elapsed > self.pong_timeout:
                        logger.warning(
                            "Pong timeout — no inbound traffic for %.1fs "
                            "(threshold %.1fs); forcing WebSocket close",
                            elapsed,
                            self.pong_timeout,
                        )
                        # 강제 close → _handle_messages가 종료되고 _run_websocket이
                        # 재연결 분기로 진입한다. 여기서 break는 ping_task를 자연
                        # 종료시킨다.
                        try:
                            await self.ws.close()
                        except Exception as close_err:
                            logger.debug(
                                "Force-close after stale detection raised: %s",
                                close_err,
                            )
                        break

                await self.ws.send_str('{"type":"ping"}')
                logger.debug("Sent ping message")
            except asyncio.CancelledError:
                logger.debug("Ping loop cancelled")
                break
            except Exception as e:
                logger.error(f"Failed to send ping: {e}")
                break

    async def _connect_websocket(self) -> None:
        """
        WebSocket handshake를 수행한다.

        서버(messenger5-websocket)는 handshake를 일단 통과시킨 뒤 핸들러에서
        에이전트 세션 락을 검사하기 때문에, handshake 성공만으로는 ACTIVE로 볼 수
        없다. ACTIVE 전이는 서버가 `sessionInfo` 메시지를 내려줄 때까지 보류
        된다. 중복 세션이면 sessionInfo 대신 close(1008)가 오고, 상위 루프에서
        STANDBY로 전이된다.

        토큰 만료는 서버가 HTTP 401로 handshake를 거부한다. 이 경우에 한해
        현장에서 한 번만 토큰을 재발급하고 재시도한다 (무한 루프 방지). 다른
        handshake 오류는 그대로 상위로 전파되어 종료 경로로 간다.
        """
        socket_mode_url = self._build_websocket_url()
        level = self._loop_log_level()
        logger.log(level, f"Connecting to {socket_mode_url}")

        try:
            self.ws = await self.session.ws_connect(
                socket_mode_url,
                headers={"Authorization": f"Bearer {self._access_token}"},
            )
        except aiohttp.WSServerHandshakeError as e:
            if e.status != 401:
                raise
            logger.info(
                "WebSocket handshake rejected with 401 — refreshing token and retrying"
            )
            await self._fetch_socket_mode_token()
            self.ws = await self.session.ws_connect(
                socket_mode_url,
                headers={"Authorization": f"Bearer {self._access_token}"},
            )

        self.connected = True
        logger.log(level, "WebSocket handshake completed — awaiting sessionInfo")

    async def _handle_messages(self) -> None:
        """
        Handle incoming messages from the WebSocket.

        aiohttp의 `async for msg in ws` 이터레이터는 CLOSE/CLOSING/CLOSED를
        받으면 메시지를 emit하지 않고 StopAsyncIteration으로 루프를 끝낸다.
        세션 중복 close(1008) 판정에는 `msg.extra`(reason)가 필요하므로
        여기서는 명시적으로 `receive()`를 호출해 CLOSE frame을 직접 캡처한다.
        """
        while True:
            msg = await self.ws.receive()
            # 어떤 inbound 이벤트든 stale 감지 타이머를 갱신한다.
            self._last_inbound_at = time.monotonic()
            if msg.type == aiohttp.WSMsgType.TEXT:
                await self._on_message(msg.data)
            elif msg.type == aiohttp.WSMsgType.CLOSE:
                self._last_close_code = (
                    msg.data if isinstance(msg.data, int) else None
                )
                self._last_close_reason = msg.extra
                logger.log(
                    self._loop_log_level(),
                    f"WebSocket close frame received "
                    f"(code={self._last_close_code}, "
                    f"reason={self._last_close_reason!r})",
                )
                break
            elif msg.type in (
                aiohttp.WSMsgType.CLOSING,
                aiohttp.WSMsgType.CLOSED,
            ):
                logger.log(
                    self._loop_log_level(),
                    f"WebSocket connection closed (code={self.ws.close_code})",
                )
                break
            elif msg.type == aiohttp.WSMsgType.ERROR:
                logger.error(f"WebSocket error: {self.ws.exception()}")
                break

    def _is_session_limit_close(self) -> bool:
        """서버가 에이전트 세션 중복으로 연결을 거부했는지 여부."""
        return (
            self._last_close_code == SESSION_LIMIT_CLOSE_CODE
            and self._last_close_reason == SESSION_LIMIT_CLOSE_REASON
        )

    async def _handle_standby(self) -> None:
        """
        Standby 상태로 진입해 고정 간격으로 재시도 대기한다.

        토큰 재발급은 여기서 수행하지 않는다. 토큰은 최초 `connect()` 때
        한 번 받아두고 그대로 재사용하며, 만료되면 `_connect_websocket`에서
        401을 만나 그 시점에만 재발급한다.
        """
        self._set_state(ConnectionState.STANDBY)
        # 첫 진입은 WARNING(운영자 가시성), 이후 재시도는 DEBUG로 낮춘다.
        if not self._in_standby_loop:
            logger.warning(
                f"Session already held by another instance — entering standby "
                f"(retry in {STANDBY_RETRY_INTERVAL}s)"
            )
        else:
            logger.debug(
                f"Still in standby; retrying in {STANDBY_RETRY_INTERVAL}s"
            )
        await asyncio.sleep(STANDBY_RETRY_INTERVAL)
        self._in_standby_loop = True

    def _set_state(self, new_state: ConnectionState) -> None:
        if self.state == new_state:
            return
        # ACTIVE가 관여하는 전이는 중요한 이벤트(최초 승격/강등)라 항상 INFO.
        # STANDBY <-> CONNECTING 반복 전이는 사이클 2회차부터 DEBUG.
        if ConnectionState.ACTIVE in (self.state, new_state):
            level = logging.INFO
        else:
            level = self._loop_log_level()
        logger.log(
            level,
            f"Socket Mode state changed: "
            f"{self.state.value} -> {new_state.value}",
        )
        self.state = new_state

    def _normalize_messenger_message(self, data: dict, mapping) -> dict:
        """
        Messenger WebSocket 메시지를 통합 구조로 정규화합니다.

        Args:
            data: Raw WebSocket message data
            mapping: ServiceMapping for the message

        Returns:
            Normalized message dictionary
        """
        content = data.get("content", {})
        action_str = data.get("action", "")

        # Actor extraction with senderId fallback
        actor = data.get("actor")
        if actor is None and content.get("senderId"):
            actor = {
                "type": "organizationMember",
                "organizationMember": {"id": content["senderId"]}
            }

        # Action with unified structure
        action_data = data.get("action_data", {})
        action = {
            "type": action_str,
            action_str: action_data
        } if action_str else None

        # channel 정보 별도 추출 (content 외부 필드 + channelId)
        channel_data = None
        if "channel" in data:
            channel_data = dict(data["channel"])
            # channelId를 channel.id로 통합
            if "channelId" in content:
                channel_data["id"] = content["channelId"]

        return {
            "service": mapping.service,
            "type": mapping.type,
            "action": action,
            "entity": {"type": mapping.type, mapping.type: content},
            "actor": actor,
            "payload": content,
            "channel_data": channel_data,
        }

    def _normalize_common_message(self, data: dict) -> dict:
        """
        Common WebSocket 메시지를 통합 구조로 정규화합니다.

        Args:
            data: Raw WebSocket message data

        Returns:
            Normalized message dictionary
        """
        entity = data.get("entity", {})
        actor = data.get("actor", {})
        action_obj = data.get("action", {})

        entity_type = entity.get("type", "")
        action_type = action_obj.get("type", "")

        # payload는 entity 내부 데이터
        payload = entity.get(entity_type, {})

        return {
            "service": data.get("service", ""),
            "type": entity_type,
            "action": action_type,
            "entity": entity,
            "actor": actor,
            "action_data": action_obj.get(action_type, {}),
            "payload": payload,
        }

    async def _on_message(self, message: str) -> None:
        """
        WebSocket 메시지를 처리하고 정규화합니다.
        """
        try:
            data = json.loads(message)
            msg_type = data.get("type", "")

            # sessionInfo 수신 = 서버가 세션을 정상 수락. 이 시점에 ACTIVE 전이.
            if msg_type == "sessionInfo":
                logger.info(f"Session established: {data.get('payload', {})}")
                self._set_state(ConnectionState.ACTIVE)
                # ACTIVE 승격 → standby 루프 플래그 해제 (다음 강등 시 WARNING 재노출)
                self._in_standby_loop = False
                # 성공적으로 ACTIVE 전이 → 재연결 시도 카운터 리셋.
                self._reconnect_attempt = 0
                return

            # entity 필드 존재 여부로 메시지 포맷 감지
            if "entity" in data and isinstance(data.get("entity"), dict):
                # Common WebSocket 포맷
                normalized = self._normalize_common_message(data)
            else:
                # Messenger 포맷 → 통합 구조로 변환
                msg_action = data.get("action", "")
                msg_service = data.get("service") or self.default_service

                if not msg_service:
                    return

                mapping = get_service_mapping(msg_service, msg_type)
                if mapping is None:
                    return

                # 메신저의 경우 create, update만 처리
                if msg_service == "messenger" and msg_action not in ("create", "update"):
                    return

                # 시스템 메시지 필터링
                content = data.get("content", {})
                if content.get("type") == 1:
                    return

                # channelId 보정
                if "channelId" not in content and "channelId" in data:
                    content["channelId"] = data["channelId"]

                normalized = self._normalize_messenger_message(data, mapping)

            # 이벤트 메시지 로깅
            logger.debug(f"Received event: {normalized['service']}/{normalized['type']}/{normalized['action']}")

            # SocketModeRequest 생성 (with web_client for lazy loading)
            request = SocketModeRequest(
                envelope_id=data.get("envelope_id", ""),
                type=normalized["type"],
                payload=normalized["payload"],
                service=normalized["service"],
                action=normalized["action"],
                entity=normalized.get("entity"),
                actor=normalized.get("actor"),
                action_data=normalized.get("action_data"),
                channel_data=normalized.get("channel_data"),
                _web_client=self.web_client,
            )

            # @MX:NOTE: [AUTO] Listener execution with enhanced error handling
            # Collects errors from all listeners, notifies callbacks, and optionally re-raises
            errors: List[Tuple[str, Exception]] = []
            for listener in self.socket_mode_request_listeners:
                listener_name = getattr(listener, "__name__", str(listener))
                try:
                    await listener(self, request)
                except asyncio.CancelledError:
                    raise  # Always re-raise cancellation
                except Exception as e:
                    logger.error(
                        f"Error in listener '{listener_name}': {e}",
                        exc_info=True,
                        extra={"listener": listener_name},
                    )
                    errors.append((listener_name, e))
                    await self._notify_listener_error(e, listener_name, request)

            # Optional: re-raise first error if strict mode is enabled
            if errors and self._raise_listener_errors:
                first_name, first_error = errors[0]
                raise DooraySDKError(
                    f"Listener '{first_name}' failed",
                    error_code="LISTENER_ERROR",
                    context={"listener": first_name, "total_errors": len(errors)},
                ) from first_error

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse message as JSON: {e}", exc_info=True)
        except Exception as e:
            logger.error(f"Error handling message: {e}", exc_info=True)

    def add_listener(self, listener: Callable) -> None:
        """
        Add a request listener.
        
        Args:
            listener: Async function to call when a request is received
        """
        self.socket_mode_request_listeners.append(listener)

    def remove_listener(self, listener: Callable) -> None:
        """
        Remove a request listener.

        Args:
            listener: Function to remove
        """
        if listener in self.socket_mode_request_listeners:
            self.socket_mode_request_listeners.remove(listener)

    def on_disconnect(self, callback: LifecycleHook) -> LifecycleHook:
        """
        Register a callback fired when the WebSocket connection drops.

        The callback receives ``(client, info_dict)``. ``info_dict`` contains:
        ``attempt`` (consecutive failed-reconnect count so far), ``error``
        (Optional[Exception]), ``close_code``, ``close_reason``.

        Both sync and async callables are accepted. Exceptions raised by the
        callback are isolated (logged but never break the reconnect loop).

        Returns the callback unchanged so it can be used as a decorator.
        """
        self._on_disconnect_callbacks.append(callback)
        return callback

    def on_reconnect(self, callback: LifecycleHook) -> LifecycleHook:
        """
        Register a callback fired before each reconnect attempt's backoff sleep.

        The callback receives ``(client, info_dict)``. ``info_dict`` contains:
        ``attempt`` (which reconnect attempt this is, starting at 1),
        ``delay`` (seconds to sleep before the next ws_connect), ``error``,
        ``close_code``, ``close_reason``.

        Both sync and async callables are accepted. Exceptions are isolated.

        Returns the callback unchanged so it can be used as a decorator.
        """
        self._on_reconnect_callbacks.append(callback)
        return callback

    def on_listener_error(self, callback: ListenerErrorCallback) -> None:
        """
        Register a callback for listener errors.

        The callback receives (exception, listener_name, request) and can be used
        for custom error logging, metrics, or alerting.

        Args:
            callback: Async function to call when a listener raises an exception.
        """
        self._error_callbacks.append(callback)

    def set_raise_listener_errors(self, enabled: bool) -> None:
        """
        Enable or disable strict error mode.

        When enabled, the first listener error will be re-raised as DooraySDKError
        after all listeners have been executed.

        Args:
            enabled: True to enable strict mode, False to disable.
        """
        self._raise_listener_errors = enabled

    async def _notify_listener_error(
        self,
        error: Exception,
        listener_name: str,
        request: SocketModeRequest,
    ) -> None:
        """
        Notify all error callbacks about a listener error.

        Args:
            error: The exception raised by the listener.
            listener_name: Name of the listener that raised the error.
            request: The SocketModeRequest being processed.
        """
        for callback in self._error_callbacks:
            try:
                await callback(error, listener_name, request)
            except Exception as cb_error:
                logger.error(
                    f"Error callback failed: {cb_error}",
                    exc_info=True,
                )

    def is_connected(self) -> bool:
        """
        Check if the client is connected to Socket Mode.

        ACTIVE 상태에서만 True를 반환한다. STANDBY 상태는 연결을 기다리는
        단계이며 실제 메시지를 수신할 수 없으므로 False.

        Returns:
            bool: True if ACTIVE, False otherwise.
        """
        return self.state == ConnectionState.ACTIVE and self.ws is not None
