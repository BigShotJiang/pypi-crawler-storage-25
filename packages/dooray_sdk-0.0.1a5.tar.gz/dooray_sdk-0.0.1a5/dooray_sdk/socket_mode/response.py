"""
Socket Mode Response

Represents a response to be sent back to Dooray via Socket Mode.
"""

from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class SocketModeResponse:
    """
    Represents a response to be sent back to Dooray via Socket Mode.
    
    This class encapsulates the response data to be sent back to Dooray's
    WebSocket connection, including the envelope ID and optional payload.
    """
    
    envelope_id: str
    payload: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the response to a dictionary.
        
        Returns:
            Dict[str, Any]: Dictionary representation of the response
        """
        result = {"envelope_id": self.envelope_id}
        if self.payload is not None:
            result["payload"] = self.payload
        return result
    
    @classmethod
    def ack(cls, envelope_id: str) -> "SocketModeResponse":
        """
        Create an acknowledgment response.
        
        Args:
            envelope_id: The envelope ID to acknowledge
            
        Returns:
            SocketModeResponse: An acknowledgment response
        """
        return cls(envelope_id=envelope_id)
    
    @classmethod
    def error(
        cls,
        envelope_id: str,
        error: str,
        message: Optional[str] = None
    ) -> "SocketModeResponse":
        """
        Create an error response.
        
        Args:
            envelope_id: The envelope ID to respond to
            error: Error type
            message: Optional error message
            
        Returns:
            SocketModeResponse: An error response
        """
        payload = {"error": error}
        if message:
            payload["message"] = message
        return cls(envelope_id=envelope_id, payload=payload)
    
    @classmethod
    def with_payload(
        cls,
        envelope_id: str,
        payload: Dict[str, Any]
    ) -> "SocketModeResponse":
        """
        Create a response with custom payload.
        
        Args:
            envelope_id: The envelope ID to respond to
            payload: Custom payload data
            
        Returns:
            SocketModeResponse: A response with custom payload
        """
        return cls(envelope_id=envelope_id, payload=payload)
