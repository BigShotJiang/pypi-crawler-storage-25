"""
Dooray Client

Agent 클래스의 별칭입니다. 하위 호환성을 위해 유지됩니다.

Note:
    Agent, Bot, DoorayClient는 동일한 클래스입니다.
    동기/비동기 핸들러 모두 지원합니다.

Example:
    from dooray_sdk import Agent  # 또는 Bot, DoorayClient

    agent = Agent(
        token="...",
        domain="company.dooray.com"
    )

    # 동기 핸들러
    @agent.messenger
    def handle_sync(req):
        req.reply("Hello!")

    # 비동기 핸들러
    @agent.messenger
    async def handle_async(req):
        await req.reply("Hello!")

    agent.run()
"""

from .agent import Agent

# 하위 호환성을 위한 별칭
Bot = Agent
DoorayClient = Agent

__all__ = ["Agent", "Bot", "DoorayClient"]
