"""
Dooray SDK Command Line Interface

Usage:
    dooray-sdk list              # List available templates
    dooray-sdk init <template>   # Create project from template
"""
import argparse
import sys
from pathlib import Path


def get_templates_dir() -> Path:
    """Return the templates directory path."""
    return Path(__file__).parent / "templates"


def list_templates() -> list:
    """Return list of available template names."""
    templates_dir = get_templates_dir()
    if not templates_dir.exists():
        return []
    return [
        d.name for d in templates_dir.iterdir()
        if d.is_dir() and not d.name.startswith(("_", "."))
        and (d / "cookiecutter.json").exists()
    ]


def cmd_list(args):
    """List available templates."""
    templates = list_templates()
    if not templates:
        print("No templates available.")
        return

    print("Available templates:")
    for name in sorted(templates):
        print(f"  - {name}")


def cmd_init(args):
    """Create a new project from a template."""
    try:
        from cookiecutter.main import cookiecutter
    except ImportError:
        print("Error: cookiecutter is not installed.")
        print("")
        print("Install it with:")
        print('  pip install "dooray-sdk[templates]"')
        print("")
        print("Or install cookiecutter directly:")
        print("  pip install cookiecutter")
        sys.exit(1)

    template_name = args.template
    templates_dir = get_templates_dir()
    template_path = templates_dir / template_name

    if not template_path.exists():
        print(f"Error: Template '{template_name}' not found.")
        print("")
        available = list_templates()
        if available:
            print("Available templates:")
            for name in sorted(available):
                print(f"  - {name}")
        else:
            print("No templates available.")
        sys.exit(1)

    # Run cookiecutter
    output_dir = args.output or "."
    try:
        result = cookiecutter(
            str(template_path),
            output_dir=output_dir,
            no_input=args.no_input,
        )
        print(f"Project created: {result}")
    except Exception as e:
        print(f"Error creating project: {e}")
        sys.exit(1)


def cmd_version(args):
    """Show version information."""
    from .__version__ import __version__
    print(f"dooray-sdk {__version__}")


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="dooray-sdk",
        description="Dooray SDK Command Line Interface",
    )
    parser.add_argument(
        "-v", "--version",
        action="store_true",
        help="Show version and exit",
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # list command
    list_parser = subparsers.add_parser(
        "list",
        help="List available templates",
    )
    list_parser.set_defaults(func=cmd_list)

    # init command
    init_parser = subparsers.add_parser(
        "init",
        help="Create a new project from a template",
    )
    init_parser.add_argument(
        "template",
        help="Template name (use 'list' to see available templates)",
    )
    init_parser.add_argument(
        "-o", "--output",
        default=None,
        help="Output directory (default: current directory)",
    )
    init_parser.add_argument(
        "--no-input",
        action="store_true",
        help="Do not prompt for parameters, use defaults",
    )
    init_parser.set_defaults(func=cmd_init)

    # Parse arguments
    args = parser.parse_args()

    # Handle version flag
    if args.version:
        cmd_version(args)
        return

    # Handle commands
    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
