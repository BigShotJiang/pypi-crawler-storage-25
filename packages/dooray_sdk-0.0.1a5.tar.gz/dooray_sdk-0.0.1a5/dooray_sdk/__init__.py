"""
Python Dooray SDK

A Python SDK for Dooray.com with Socket Mode support.

Example:
    from dooray_sdk import Agent

    agent = Agent(
        token="...",
        domain="company.dooray.com"
    )

    @agent.messenger
    async def handle_message(req):
        if req.text == "ping":
            await req.reply("pong")

    agent.run()
"""

from .__version__ import __version__, VERSION
from .__version__ import VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH
from .__version__ import DEVELOPMENT_STATUS

__author__ = "Dooray SDK Team"


def __getattr__(name):
    """Lazy import."""
    if name == "Agent":
        from .agent import Agent
        return Agent
    elif name in ("Bot", "DoorayClient"):
        # Bot, DoorayClient는 Agent의 별칭 (하위 호환성)
        from .agent import Agent
        return Agent
    elif name == "AsyncWebClient":
        from .web.async_client import AsyncWebClient
        return AsyncWebClient
    elif name == "WebClient":
        from .web.client import WebClient
        return WebClient
    # Service API (ADR-005)
    elif name == "AsyncMessengerAPI":
        from .web.messenger import AsyncMessengerAPI
        return AsyncMessengerAPI
    elif name == "MessengerAPI":
        from .web.messenger import MessengerAPI
        return MessengerAPI
    elif name == "AsyncTaskAPI":
        from .web.task import AsyncTaskAPI
        return AsyncTaskAPI
    elif name == "TaskAPI":
        from .web.task import TaskAPI
        return TaskAPI
    elif name == "AsyncWikiAPI":
        from .web.wiki import AsyncWikiAPI
        return AsyncWikiAPI
    elif name == "WikiAPI":
        from .web.wiki import WikiAPI
        return WikiAPI
    elif name == "SocketModeClient":
        from .socket_mode.aiohttp.client import SocketModeClient
        return SocketModeClient
    elif name == "SocketModeRequest":
        from .socket_mode.request import SocketModeRequest
        return SocketModeRequest
    elif name == "SocketModeResponse":
        from .socket_mode.response import SocketModeResponse
        return SocketModeResponse
    # LLM classes
    elif name == "query":
        from .llm.query import query
        return query
    elif name == "QueryOptions":
        from .llm.options import QueryOptions
        return QueryOptions
    elif name == "Message":
        from .llm.message import Message
        return Message
    elif name == "ToolCall":
        from .llm.message import ToolCall
        return ToolCall
    # Exception classes
    elif name == "DooraySDKError":
        from .exceptions import DooraySDKError
        return DooraySDKError
    elif name == "DoorayConnectionError":
        from .exceptions import DoorayConnectionError
        return DoorayConnectionError
    elif name == "DoorayWebSocketError":
        from .exceptions import DoorayWebSocketError
        return DoorayWebSocketError
    elif name == "DoorayAuthenticationError":
        from .exceptions import DoorayAuthenticationError
        return DoorayAuthenticationError
    elif name == "DoorayTokenError":
        from .exceptions import DoorayTokenError
        return DoorayTokenError
    elif name == "DoorayConfigurationError":
        from .exceptions import DoorayConfigurationError
        return DoorayConfigurationError
    elif name == "DoorayRequestError":
        from .exceptions import DoorayRequestError
        return DoorayRequestError
    elif name == "DoorayTimeoutError":
        from .exceptions import DoorayTimeoutError
        return DoorayTimeoutError
    # LLM exceptions
    elif name == "DoorayLLMError":
        from .llm.exceptions import DoorayLLMError
        return DoorayLLMError
    elif name == "DoorayLLMConfigurationError":
        from .llm.exceptions import DoorayLLMConfigurationError
        return DoorayLLMConfigurationError
    elif name == "DoorayLLMRequestError":
        from .llm.exceptions import DoorayLLMRequestError
        return DoorayLLMRequestError
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Core classes
    "Agent",
    "Bot",           # Agent alias (backward compatibility)
    "DoorayClient",  # Agent alias (backward compatibility)
    "AsyncWebClient",
    "WebClient",
    "AsyncMessengerAPI",
    "MessengerAPI",
    "AsyncTaskAPI",
    "TaskAPI",
    "AsyncWikiAPI",
    "WikiAPI",
    "SocketModeClient",
    "SocketModeRequest",
    "SocketModeResponse",
    # LLM
    "query",
    "QueryOptions",
    "Message",
    "ToolCall",
    # Exceptions
    "DooraySDKError",
    "DoorayConnectionError",
    "DoorayWebSocketError",
    "DoorayAuthenticationError",
    "DoorayTokenError",
    "DoorayConfigurationError",
    "DoorayRequestError",
    "DoorayTimeoutError",
    "DoorayLLMError",
    "DoorayLLMConfigurationError",
    "DoorayLLMRequestError",
]
