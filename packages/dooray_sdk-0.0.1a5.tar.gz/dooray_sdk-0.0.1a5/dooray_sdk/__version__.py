"""
Version information for dooray-sdk
"""

__version__ = "0.0.1a5"
__version_info__ = (0, 0, 1, "a5")

# Version components
VERSION_MAJOR = 0
VERSION_MINOR = 0
VERSION_PATCH = 1
VERSION_BUILD = "a5"

# Full version string
VERSION = f"{VERSION_MAJOR}.{VERSION_MINOR}.{VERSION_PATCH}"
if VERSION_BUILD:
    VERSION += f".{VERSION_BUILD}"

# Development status
DEVELOPMENT_STATUS = "Alpha"  # Alpha, Beta, RC, Stable
