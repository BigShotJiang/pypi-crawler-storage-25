"""
Dooray domain parsing utilities.
"""

from typing import Optional


def validate_dooray_domain(domain: str) -> None:
    """Validate that the domain format is correct.

    Args:
        domain: Dooray domain to validate (e.g., company.dooray.com).

    Raises:
        ValueError: If the domain format is invalid.
    """
    if not domain or not domain.strip():
        raise ValueError("Domain cannot be empty.")

    domain = domain.strip()

    if " " in domain:
        raise ValueError(
            f"Invalid domain format: '{domain}'. Domain cannot contain spaces."
        )

    if domain.startswith(("http://", "https://")):
        raise ValueError(
            f"Invalid domain format: '{domain}'. "
            f"Remove protocol (http://, https://). Example: company.dooray.com"
        )

    # Basic format check: must have at least one dot
    if "." not in domain:
        raise ValueError(
            f"Invalid domain format: '{domain}'. "
            f"Example: company.dooray.com"
        )


def parse_api_base_url(domain: str, path_suffix: str = "") -> str:
    """Parse Dooray domain to API base URL.

    Strips the first subdomain (tenant name) and prepends 'api.'.

    Args:
        domain: Dooray domain (e.g., company.dooray.com).
        path_suffix: Optional URL path suffix (e.g., '/llm/v1').

    Returns:
        API base URL (e.g., https://api.dooray.com/llm/v1).

    Raises:
        ValueError: If the domain format is invalid.

    Examples:
        company.dooray.com → https://api.dooray.com
        nhnent.dev.dooray.com → https://api.dev.dooray.com
        self.gov-dooray.com → https://api.gov-dooray.com
        company.dooray.co.kr → https://api.dooray.co.kr
    """
    validate_dooray_domain(domain)

    parts = domain.split(".", 1)
    base_domain = parts[1]
    return f"https://api.{base_domain}{path_suffix}"
