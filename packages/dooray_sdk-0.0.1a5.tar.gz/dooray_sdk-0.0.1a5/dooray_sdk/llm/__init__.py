"""
LLM module for Dooray SDK.

This module provides a simple interface for querying LLM providers
using LangChain.

Supported Providers:
    - Dooray AI: Use DoorayAIConfig
    - OpenAI: Use OpenAIConfig
    - Azure OpenAI: Use AzureOpenAIConfig

Example:
    from dooray_sdk import query, QueryOptions
    from dooray_sdk.llm.langchain import DoorayAIConfig, OpenAIConfig, AzureOpenAIConfig
    from pydantic import SecretStr

    # Dooray AI
    options = QueryOptions(
        langchain_config=DoorayAIConfig(
            token=SecretStr("your-dooray-token"),
            domain="company.dooray.com",
            model="your-model",
        )
    )
    async for message in query(prompt="Hello!", options=options):
        print(message.text)

    # OpenAI
    options = QueryOptions(
        langchain_config=OpenAIConfig(
            api_key=SecretStr("your-key"),
            model="gpt-4o-mini",
        )
    )
    async for message in query(prompt="Hello!", options=options):
        print(message.text)

    # Azure OpenAI
    options = QueryOptions(
        langchain_config=AzureOpenAIConfig(
            azure_endpoint="https://xxx.openai.azure.com",
            model="gpt-4",
            api_key=SecretStr("your-key"),
        )
    )
    async for message in query(prompt="Hello!", options=options):
        print(message.text)
"""

from .exceptions import (
    DoorayLLMConfigurationError,
    DoorayLLMError,
    DoorayLLMRequestError,
)
from .message import Message, ToolCall
from .options import QueryOptions
from .query import query

__all__ = [
    "query",
    "QueryOptions",
    "Message",
    "ToolCall",
    "DoorayLLMError",
    "DoorayLLMConfigurationError",
    "DoorayLLMRequestError",
]
