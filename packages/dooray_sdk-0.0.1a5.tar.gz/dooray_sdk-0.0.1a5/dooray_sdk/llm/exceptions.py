"""
LLM-specific exceptions.

This module defines exception classes for LLM-related errors.
"""

from typing import Any, Optional
from ..exceptions import DooraySDKError


class DoorayLLMError(DooraySDKError):
    """Base exception class for LLM-related errors.

    This exception is raised for general LLM operation failures.
    """

    pass


class DoorayLLMConfigurationError(DoorayLLMError):
    """Exception raised for LLM configuration errors.

    This exception is raised when LLM configuration is missing or invalid,
    such as missing API key or base URL.
    """

    pass


class DoorayLLMRequestError(DoorayLLMError):
    """Exception raised for LLM API request errors.

    This exception is raised when an LLM API request fails.

    Attributes:
        message: Human-readable error description.
        status_code: Optional HTTP status code of the failed request.
        response_body: Optional response body from the failed request.
        error_code: Optional error code for programmatic handling.
        context: Optional dictionary with additional error context.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        response_body: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize DoorayLLMRequestError.

        Args:
            message: Human-readable error description.
            status_code: Optional HTTP status code of the failed request.
            response_body: Optional response body from the failed request.
            **kwargs: Additional arguments passed to DoorayLLMError.
        """
        super().__init__(message, **kwargs)
        self.status_code = status_code
        self.response_body = response_body
