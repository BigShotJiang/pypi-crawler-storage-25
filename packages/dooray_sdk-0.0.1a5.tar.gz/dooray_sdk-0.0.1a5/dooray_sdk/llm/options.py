"""
QueryOptions dataclass for LLM query configuration.
"""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

if TYPE_CHECKING:
    from .langchain.config import BaseLLMConfig


@dataclass
class QueryOptions:
    """Configuration options for LLM query.

    Supported Providers (via langchain_config):
        - OpenAI: Use OpenAIConfig
        - Azure OpenAI: Use AzureOpenAIConfig
        - Vertex AI Gemini: Use VertexGeminiConfig
        - Vertex AI Claude: Use VertexClaudeConfig

    Attributes:
        langchain_config: LangChain configuration for LLM provider.
            Required. Use AzureOpenAIConfig, OpenAIConfig, VertexGeminiConfig,
            or VertexClaudeConfig.
        system_prompt: System instruction.
        temperature: Temperature (0.0-2.0). Overrides config value if set.
        max_tokens: Maximum response tokens. Overrides config value if set.
        tools: List of tool definitions for function calling.
        tool_choice: Tool selection mode ("auto", "none", "required", or specific tool).
        stream: Whether to stream responses (default: True).
    """

    langchain_config: Optional["BaseLLMConfig"] = None
    system_prompt: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    tools: Optional[List[Dict[str, Any]]] = None
    tool_choice: Optional[Union[str, Dict[str, Any]]] = None
    stream: bool = True

    def __post_init__(self) -> None:
        """Validate field values after initialization."""
        if self.temperature is not None:
            if not (0.0 <= self.temperature <= 2.0):
                raise ValueError("temperature must be between 0.0 and 2.0")
        if self.max_tokens is not None:
            if self.max_tokens <= 0:
                raise ValueError("max_tokens must be positive")
