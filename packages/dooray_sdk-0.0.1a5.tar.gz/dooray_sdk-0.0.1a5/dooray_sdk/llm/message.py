"""
Message dataclass for LLM responses.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class ToolCall:
    """Represents a tool call from an LLM response.

    Attributes:
        id: Unique identifier for the tool call.
        name: Name of the function to call.
        arguments: JSON string of function arguments.
    """

    id: str
    name: str
    arguments: str

    def parse_arguments(self) -> Dict[str, Any]:
        """Parse the JSON arguments string into a dictionary.

        Returns:
            Dict[str, Any]: Parsed arguments.

        Raises:
            json.JSONDecodeError: If arguments is not valid JSON.
        """
        import json

        return json.loads(self.arguments)


@dataclass
class Message:
    """Represents a message from an LLM response.

    Attributes:
        role: Message role (assistant, user, system).
        content: Message text content.
        tool_calls: List of tool calls (for function calling).
    """

    role: str
    content: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None

    @property
    def text(self) -> Optional[str]:
        """Alias for content property for convenience.

        Returns:
            Optional[str]: The message content.
        """
        return self.content

    @property
    def has_tool_calls(self) -> bool:
        """Check if message contains tool calls.

        Returns:
            bool: True if message has tool calls.
        """
        return self.tool_calls is not None and len(self.tool_calls) > 0
