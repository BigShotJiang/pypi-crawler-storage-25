"""
Azure OpenAI configuration.
"""

from typing import Optional

from pydantic import SecretStr

from .base import BaseLLMConfig


DEFAULT_API_VERSION = "2024-02-01"


class AzureOpenAIConfig(BaseLLMConfig):
    """Configuration for Azure OpenAI.

    Attributes:
        azure_endpoint: Azure OpenAI endpoint URL.
        api_key: Azure OpenAI API key.
        api_version: API version (default: 2024-02-01).
        azure_deployment: Deployment name (defaults to model if not set).
        model: Model name.
    """

    azure_endpoint: str
    api_key: SecretStr
    api_version: str = DEFAULT_API_VERSION
    azure_deployment: Optional[str] = None

    def get_provider_type(self) -> str:
        """Return the provider type identifier."""
        return "azure_openai"

    def get_deployment(self) -> str:
        """Return the deployment name.

        Returns:
            str: Deployment name (azure_deployment or model).
        """
        return self.azure_deployment or self.model
