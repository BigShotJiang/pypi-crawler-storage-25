"""
Base configuration class for LangChain LLM providers.
"""

from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, SecretStr


class BaseLLMConfig(BaseModel):
    """Base configuration for LangChain LLM providers.

    Attributes:
        model: Model name or deployment name.
        temperature: Temperature for response generation (0.0-2.0).
        max_tokens: Maximum number of tokens in response.
        stop_sequences: List of stop sequences.
        streaming: Whether to stream responses.
        tools: List of tool definitions for function calling.
        tool_choice: Tool selection mode.
    """

    model: str
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    stop_sequences: Optional[List[str]] = None
    streaming: bool = True
    tools: Optional[List[Dict[str, Any]]] = None
    tool_choice: Optional[Union[str, Dict[str, Any]]] = None

    model_config = {"arbitrary_types_allowed": True}

    def get_provider_type(self) -> str:
        """Return the provider type identifier.

        Returns:
            str: Provider type (e.g., 'dooray_ai', 'azure_openai', 'openai').
        """
        raise NotImplementedError("Subclasses must implement get_provider_type()")

    def get_common_model_kwargs(self) -> Dict[str, Any]:
        """Return common optional model kwargs for LangChain models.

        Returns:
            Dict with temperature, max_tokens, stop if set.
        """
        kwargs: Dict[str, Any] = {}
        if self.temperature is not None:
            kwargs["temperature"] = self.temperature
        if self.max_tokens is not None:
            kwargs["max_tokens"] = self.max_tokens
        if self.stop_sequences is not None:
            kwargs["stop"] = self.stop_sequences
        return kwargs
