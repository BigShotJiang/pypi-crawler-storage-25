"""
OpenAI configuration.
"""

from typing import Any, Dict, Optional

from pydantic import SecretStr

from .base import BaseLLMConfig


class OpenAIConfig(BaseLLMConfig):
    """Configuration for OpenAI.

    Attributes:
        api_key: OpenAI API key.
        model: Model name (e.g., gpt-4o-mini, gpt-4-turbo).
        base_url: Optional custom base URL for API.
        extra_body: Optional extra body parameters.
    """

    api_key: SecretStr
    base_url: Optional[str] = None
    extra_body: Optional[Dict[str, Any]] = None

    def get_provider_type(self) -> str:
        """Return the provider type identifier."""
        return "openai"
