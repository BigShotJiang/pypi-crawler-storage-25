"""
Dooray AI configuration.
"""

from typing import Any, Dict, Optional

from pydantic import Field, SecretStr, model_validator

from .base import BaseLLMConfig


class DoorayAIConfig(BaseLLMConfig):
    """Configuration for Dooray AI (OpenAI-compatible).

    Uses Dooray Open API authentication (dooray-api token).
    The base_url is automatically derived from the domain.

    Attributes:
        token: Dooray API token.
        domain: Dooray domain (e.g., company.dooray.com).
        model: Model name.
        extra_body: Optional extra body parameters.

    Examples:
        company.dooray.com → https://api.dooray.com/llm/v1
        nhnent.dev.dooray.com → https://api.dev.dooray.com/llm/v1
    """

    token: SecretStr
    domain: str
    base_url: Optional[str] = Field(
        default=None,
        description="Override auto-derived API URL. Most users should leave this unset.",
    )
    extra_body: Optional[Dict[str, Any]] = None

    @model_validator(mode="after")
    def _set_base_url(self) -> "DoorayAIConfig":
        if self.base_url is None:
            from dooray_sdk._domain import parse_api_base_url
            self.base_url = parse_api_base_url(self.domain, path_suffix="/llm/v1")
        return self

    def get_provider_type(self) -> str:
        """Return the provider type identifier."""
        return "dooray_ai"
