"""
LangChain streaming handler.

Handles streaming responses from LangChain models and converts them to Message format.
"""

from typing import TYPE_CHECKING, Any, AsyncIterator, Dict, List, Optional, Union

from ..message import Message, ToolCall

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel
    from langchain_core.messages import BaseMessage


async def handle_langchain_streaming(
    model: "BaseChatModel",
    messages: List["BaseMessage"],
    tools: Optional[List[Dict[str, Any]]] = None,
    tool_choice: Optional[Union[str, Dict[str, Any]]] = None,
) -> AsyncIterator[Message]:
    """Handle streaming response from LangChain model.

    Args:
        model: LangChain chat model instance.
        messages: List of LangChain message objects.
        tools: Optional list of tool definitions.
        tool_choice: Optional tool choice configuration.

    Yields:
        Message: Streaming message chunks in SDK format.
    """
    # Bind tools if provided
    if tools is not None:
        bind_kwargs: Dict[str, Any] = {"tools": tools}
        if tool_choice is not None:
            bind_kwargs["tool_choice"] = tool_choice
        model = model.bind(**bind_kwargs)

    # Accumulate tool calls from streaming chunks
    accumulated_tool_calls: Dict[int, Dict[str, Any]] = {}
    has_tool_calls = False

    async for chunk in model.astream(messages):
        # Handle text content
        if chunk.content:
            # Content can be string or list (for multimodal)
            content = chunk.content if isinstance(chunk.content, str) else str(chunk.content)
            yield Message(
                role="assistant",
                content=content,
            )

        # Handle tool calls (AIMessageChunk.tool_call_chunks)
        if hasattr(chunk, "tool_call_chunks") and chunk.tool_call_chunks:
            has_tool_calls = True
            for tool_chunk in chunk.tool_call_chunks:
                idx = tool_chunk.get("index", 0)
                if idx not in accumulated_tool_calls:
                    accumulated_tool_calls[idx] = {
                        "id": tool_chunk.get("id", ""),
                        "name": tool_chunk.get("name", ""),
                        "arguments": "",
                    }

                if tool_chunk.get("id"):
                    accumulated_tool_calls[idx]["id"] = tool_chunk["id"]

                if tool_chunk.get("name"):
                    accumulated_tool_calls[idx]["name"] = tool_chunk["name"]

                if tool_chunk.get("args"):
                    accumulated_tool_calls[idx]["arguments"] += tool_chunk["args"]

    # Yield accumulated tool calls at the end
    if has_tool_calls and accumulated_tool_calls:
        tool_calls = _build_tool_calls(accumulated_tool_calls)
        yield Message(
            role="assistant",
            tool_calls=tool_calls,
        )


async def handle_langchain_non_streaming(
    model: "BaseChatModel",
    messages: List["BaseMessage"],
    tools: Optional[List[Dict[str, Any]]] = None,
    tool_choice: Optional[Union[str, Dict[str, Any]]] = None,
) -> AsyncIterator[Message]:
    """Handle non-streaming response from LangChain model.

    Args:
        model: LangChain chat model instance.
        messages: List of LangChain message objects.
        tools: Optional list of tool definitions.
        tool_choice: Optional tool choice configuration.

    Yields:
        Message: Single message with complete response.
    """
    # Bind tools if provided
    if tools is not None:
        bind_kwargs: Dict[str, Any] = {"tools": tools}
        if tool_choice is not None:
            bind_kwargs["tool_choice"] = tool_choice
        model = model.bind(**bind_kwargs)

    response = await model.ainvoke(messages)

    # Build tool calls if present
    tool_calls = None
    if hasattr(response, "tool_calls") and response.tool_calls:
        tool_calls = [
            ToolCall(
                id=tc.get("id", ""),
                name=tc.get("name", ""),
                arguments=tc.get("args", "") if isinstance(tc.get("args"), str) else _serialize_args(tc.get("args", {})),
            )
            for tc in response.tool_calls
        ]

    content = response.content if isinstance(response.content, str) else str(response.content) if response.content else None

    yield Message(
        role="assistant",
        content=content,
        tool_calls=tool_calls,
    )


def _build_tool_calls(accumulated: Dict[int, Dict[str, Any]]) -> List[ToolCall]:
    """Build ToolCall list from accumulated data.

    Args:
        accumulated: Dictionary of accumulated tool calls by index.

    Returns:
        List[ToolCall]: List of completed tool calls.
    """
    result = []
    for idx in sorted(accumulated.keys()):
        data = accumulated[idx]
        result.append(
            ToolCall(
                id=data["id"],
                name=data["name"],
                arguments=data["arguments"],
            )
        )
    return result


def _serialize_args(args: Any) -> str:
    """Serialize arguments to JSON string.

    Args:
        args: Arguments to serialize (dict or other).

    Returns:
        str: JSON string representation.
    """
    import json
    return json.dumps(args) if args else "{}"
