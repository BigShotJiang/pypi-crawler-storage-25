"""
LangChain Chat Model Factory.

Creates appropriate LangChain chat model instances based on configuration.
"""

import logging
from typing import TYPE_CHECKING, Any, Dict, Optional, Union

from ..exceptions import DoorayLLMConfigurationError
from .config import (
    AzureOpenAIConfig,
    BaseLLMConfig,
    DoorayAIConfig,
    OpenAIConfig,
)

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel

logger = logging.getLogger(__name__)


class LangchainChatModelFactory:
    """Factory for creating LangChain chat model instances."""

    @classmethod
    def new_model(
        cls,
        config: Union[AzureOpenAIConfig, DoorayAIConfig, OpenAIConfig],
        system_prompt: Optional[str] = None,
    ) -> "BaseChatModel":
        """Create a LangChain chat model based on configuration.

        Args:
            config: LLM configuration instance.
            system_prompt: Optional system prompt (not used directly, passed via messages).

        Returns:
            BaseChatModel: LangChain chat model instance.

        Raises:
            DoorayLLMConfigurationError: If required packages are not installed.
        """
        provider_type = config.get_provider_type()

        if provider_type == "azure_openai":
            return cls._create_azure_openai_model(config)
        elif provider_type == "dooray_ai":
            return cls._create_dooray_ai_model(config)
        elif provider_type == "openai":
            return cls._create_openai_model(config)
        else:
            raise DoorayLLMConfigurationError(
                f"Unknown provider type: {provider_type}",
                error_code="UNKNOWN_PROVIDER_TYPE",
            )

    @classmethod
    def _create_azure_openai_model(cls, config: AzureOpenAIConfig) -> "BaseChatModel":
        """Create Azure OpenAI chat model."""
        try:
            from langchain_openai import AzureChatOpenAI
        except ImportError as e:
            raise DoorayLLMConfigurationError(
                "langchain-openai package is required. Install with: pip install dooray-sdk[llm]",
                error_code="MISSING_LANGCHAIN_OPENAI",
            ) from e

        logger.info("Creating Azure OpenAI model: %s", config.model)

        model_kwargs: Dict[str, Any] = {
            "azure_endpoint": config.azure_endpoint,
            "api_key": config.api_key.get_secret_value(),
            "azure_deployment": config.get_deployment(),
            "model": config.model,
            "api_version": config.api_version,
            "streaming": config.streaming,
            **config.get_common_model_kwargs(),
        }

        return AzureChatOpenAI(**model_kwargs)

    @classmethod
    def _create_dooray_ai_model(cls, config: DoorayAIConfig) -> "BaseChatModel":
        """Create Dooray AI chat model (OpenAI-compatible with Dooray auth)."""
        try:
            from langchain_openai import ChatOpenAI
        except ImportError as e:
            raise DoorayLLMConfigurationError(
                "langchain-openai package is required. Install with: pip install dooray-sdk[llm]",
                error_code="MISSING_LANGCHAIN_OPENAI",
            ) from e

        logger.info("Creating Dooray AI model: %s", config.model)

        token = config.token.get_secret_value()

        model_kwargs: Dict[str, Any] = {
            # ChatOpenAI requires api_key, but Dooray AI uses dooray-api header auth.
            # This placeholder satisfies validation; actual auth is via default_headers.
            "api_key": "dooray-placeholder",
            "base_url": config.base_url,
            "model": config.model,
            "streaming": config.streaming,
            "default_headers": {"Authorization": f"dooray-api {token}"},
            **config.get_common_model_kwargs(),
        }

        if config.extra_body is not None:
            model_kwargs["extra_body"] = config.extra_body

        return ChatOpenAI(**model_kwargs)

    @classmethod
    def _create_openai_model(cls, config: OpenAIConfig) -> "BaseChatModel":
        """Create OpenAI chat model."""
        try:
            from langchain_openai import ChatOpenAI
        except ImportError as e:
            raise DoorayLLMConfigurationError(
                "langchain-openai package is required. Install with: pip install dooray-sdk[llm]",
                error_code="MISSING_LANGCHAIN_OPENAI",
            ) from e

        logger.info("Creating OpenAI model: %s", config.model)

        model_kwargs: Dict[str, Any] = {
            "api_key": config.api_key.get_secret_value(),
            "model": config.model,
            "streaming": config.streaming,
            **config.get_common_model_kwargs(),
        }

        if config.base_url is not None:
            model_kwargs["base_url"] = config.base_url

        if config.extra_body is not None:
            model_kwargs["extra_body"] = config.extra_body

        return ChatOpenAI(**model_kwargs)
