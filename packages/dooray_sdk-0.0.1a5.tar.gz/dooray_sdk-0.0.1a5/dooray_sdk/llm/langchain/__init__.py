"""
LangChain integration for Dooray SDK LLM module.

This module provides LangChain-based LLM support for Dooray AI, Azure OpenAI,
and OpenAI.

Example:
    from dooray_sdk import query, QueryOptions
    from dooray_sdk.llm.langchain import DoorayAIConfig, AzureOpenAIConfig, OpenAIConfig
    from pydantic import SecretStr

    # Dooray AI
    options = QueryOptions(
        langchain_config=DoorayAIConfig(
            token=SecretStr("your-dooray-token"),
            domain="company.dooray.com",
            model="your-model",
        )
    )
    async for msg in query(prompt="Hello", options=options):
        print(msg.text)

    # Azure OpenAI
    options = QueryOptions(
        langchain_config=AzureOpenAIConfig(
            azure_endpoint="https://xxx.openai.azure.com",
            model="gpt-4",
            api_key=SecretStr("your-key"),
        )
    )
    async for msg in query(prompt="Hello", options=options):
        print(msg.text)

    # OpenAI
    options = QueryOptions(
        langchain_config=OpenAIConfig(
            api_key=SecretStr("your-key"),
            model="gpt-4o-mini",
        )
    )
    async for msg in query(prompt="Hello", options=options):
        print(msg.text)
"""

from .config import (
    AzureOpenAIConfig,
    BaseLLMConfig,
    DoorayAIConfig,
    OpenAIConfig,
)
from .factory import LangchainChatModelFactory
from .handler import handle_langchain_non_streaming, handle_langchain_streaming

__all__ = [
    # Config classes
    "BaseLLMConfig",
    "AzureOpenAIConfig",
    "DoorayAIConfig",
    "OpenAIConfig",
    # Factory
    "LangchainChatModelFactory",
    # Handlers
    "handle_langchain_streaming",
    "handle_langchain_non_streaming",
]
