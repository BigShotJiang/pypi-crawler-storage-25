"""
LLM query function implementation using LangChain.
"""

from typing import Any, AsyncIterable, AsyncIterator, Dict, List, Optional, Union

from .exceptions import DoorayLLMConfigurationError, DoorayLLMRequestError
from .message import Message
from .options import QueryOptions


async def query(
    *,
    prompt: Union[str, AsyncIterable[Dict[str, Any]]],
    options: Optional[QueryOptions] = None,
) -> AsyncIterator[Message]:
    """Query an LLM with streaming response using LangChain.

    This function sends a prompt to an LLM provider and streams the response.
    Supports Dooray AI, Azure OpenAI, and OpenAI.

    Args:
        prompt: Either a string prompt or an async iterable of message dicts.
        options: QueryOptions with langchain_config set.

    Yields:
        Message: Streaming message chunks from the LLM response.
            - For text responses: Message with content field.
            - For tool calls: Message with tool_calls field (yielded once when complete).

    Raises:
        DoorayLLMConfigurationError: If langchain_config is not provided or invalid.
        DoorayLLMRequestError: If the LLM API request fails.

    Example:
        Dooray AI:
            from dooray_sdk import query, QueryOptions
            from dooray_sdk.llm.langchain import DoorayAIConfig
            from pydantic import SecretStr

            options = QueryOptions(
                langchain_config=DoorayAIConfig(
                    token=SecretStr("your-dooray-token"),
                    domain="company.dooray.com",
                    model="your-model",
                )
            )
            async for message in query(prompt="Hello!", options=options):
                print(message.text, end="")

        OpenAI:
            from dooray_sdk import query, QueryOptions
            from dooray_sdk.llm.langchain import OpenAIConfig
            from pydantic import SecretStr

            options = QueryOptions(
                langchain_config=OpenAIConfig(
                    api_key=SecretStr("your-key"),
                    model="gpt-4o-mini",
                )
            )
            async for message in query(prompt="Hello!", options=options):
                print(message.text, end="")

        Azure OpenAI:
            from dooray_sdk.llm.langchain import AzureOpenAIConfig

            options = QueryOptions(
                langchain_config=AzureOpenAIConfig(
                    azure_endpoint="https://xxx.openai.azure.com",
                    model="gpt-4",
                    api_key=SecretStr("your-key"),
                )
            )
            async for message in query(prompt="Hello!", options=options):
                print(message.text, end="")

        With tool calling:
            tools = [{
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "description": "Get weather for a location",
                    "parameters": {
                        "type": "object",
                        "properties": {"location": {"type": "string"}},
                        "required": ["location"]
                    }
                }
            }]
            options = QueryOptions(
                langchain_config=OpenAIConfig(
                    api_key=SecretStr("your-key"),
                    model="gpt-4o-mini",
                ),
                tools=tools,
            )
            async for message in query(prompt="What's the weather in Seoul?", options=options):
                if message.has_tool_calls:
                    for tool_call in message.tool_calls:
                        print(f"Call: {tool_call.name}({tool_call.arguments})")
                else:
                    print(message.text, end="")
    """
    if options is None:
        raise DoorayLLMConfigurationError(
            "options is required with langchain_config set.",
            error_code="MISSING_OPTIONS",
        )

    if options.langchain_config is None:
        raise DoorayLLMConfigurationError(
            "langchain_config is required. Use DoorayAIConfig, AzureOpenAIConfig, or OpenAIConfig.",
            error_code="MISSING_LANGCHAIN_CONFIG",
        )

    from .langchain.config import BaseLLMConfig
    from .langchain.factory import LangchainChatModelFactory
    from .langchain.handler import (
        handle_langchain_non_streaming,
        handle_langchain_streaming,
    )

    config = options.langchain_config
    if not isinstance(config, BaseLLMConfig):
        raise DoorayLLMConfigurationError(
            "langchain_config must be an instance of BaseLLMConfig",
            error_code="INVALID_LANGCHAIN_CONFIG",
        )

    # Import LangChain message types
    try:
        from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
    except ImportError as e:
        raise DoorayLLMConfigurationError(
            "langchain-core package is required. Install with: pip install dooray-sdk[llm]",
            error_code="MISSING_LANGCHAIN_CORE",
        ) from e

    # Apply options to config if not already set
    if options.temperature is not None and config.temperature is None:
        config.temperature = options.temperature

    if options.max_tokens is not None and config.max_tokens is None:
        config.max_tokens = options.max_tokens

    if options.tools is not None and config.tools is None:
        config.tools = options.tools

    if options.tool_choice is not None and config.tool_choice is None:
        config.tool_choice = options.tool_choice

    config.streaming = options.stream

    # Create model using factory
    model = LangchainChatModelFactory.new_model(config)

    # Build messages array
    messages: List[Any] = []

    # Add system prompt if provided
    if options.system_prompt:
        messages.append(SystemMessage(content=options.system_prompt))

    # Add user prompt
    if isinstance(prompt, str):
        messages.append(HumanMessage(content=prompt))
    else:
        # Handle AsyncIterable of message dicts
        async for msg in prompt:
            if not isinstance(msg, dict):
                raise DoorayLLMConfigurationError(
                    "Message must be a dictionary",
                    error_code="INVALID_MESSAGE_FORMAT",
                )
            role = msg.get("role")
            content = msg.get("content", "")

            if role == "system":
                messages.append(SystemMessage(content=content))
            elif role == "user":
                messages.append(HumanMessage(content=content))
            elif role == "assistant":
                # content가 None이면 빈 문자열로 처리 (tool_calls만 있는 경우)
                tool_calls = msg.get("tool_calls")
                if tool_calls:
                    import json
                    # LangChain 형식으로 tool_calls 변환
                    lc_tool_calls = []
                    for tc in tool_calls:
                        args_raw = tc.get("function", {}).get("arguments", "{}")
                        # args가 문자열이면 JSON 파싱
                        if isinstance(args_raw, str):
                            try:
                                args = json.loads(args_raw)
                            except json.JSONDecodeError:
                                args = {}
                        else:
                            args = args_raw or {}
                        lc_tool_calls.append({
                            "id": tc.get("id", ""),
                            "name": tc.get("function", {}).get("name", ""),
                            "args": args,
                        })
                    messages.append(AIMessage(content=content or "", tool_calls=lc_tool_calls))
                else:
                    messages.append(AIMessage(content=content or ""))
            elif role == "tool":
                # Tool response message
                tool_call_id = msg.get("tool_call_id", "")
                messages.append(ToolMessage(content=content or "", tool_call_id=tool_call_id))
            else:
                raise DoorayLLMConfigurationError(
                    f"Unknown message role: {role}",
                    error_code="INVALID_MESSAGE_ROLE",
                )

    try:
        if options.stream:
            async for message in handle_langchain_streaming(
                model, messages, config.tools, config.tool_choice
            ):
                yield message
        else:
            async for message in handle_langchain_non_streaming(
                model, messages, config.tools, config.tool_choice
            ):
                yield message
    except Exception as e:
        if isinstance(e, (DoorayLLMConfigurationError, DoorayLLMRequestError)):
            raise
        raise DoorayLLMRequestError(
            f"LLM request failed: {e}",
            error_code="REQUEST_FAILED",
            context={"model": config.model, "provider": config.get_provider_type()},
        ) from e
