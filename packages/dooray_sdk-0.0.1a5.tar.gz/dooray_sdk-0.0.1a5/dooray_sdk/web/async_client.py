"""
Dooray Async Web Client

Async HTTP-based API client for Dooray services.
"""

import warnings
from typing import Optional, Dict, Any, TYPE_CHECKING
from urllib.parse import urljoin

import aiohttp

from .token import SOCKET_MODE_TOKEN_ENDPOINT, parse_socket_mode_token_response
from .._user_agent import USER_AGENT, _build_user_agent
from ..exceptions import DoorayRequestError

if TYPE_CHECKING:
    from .messenger import AsyncMessengerAPI


# 평면 메신저 API 메서드들이 deprecation 안내에서 공통으로 가리키는 새 표면.
_MESSENGER_NEW_SURFACE = "client.messenger.<verb> (e.g. client.messenger.send_message)"


class AsyncWebClient:
    """
    An async client for making HTTP requests to Dooray APIs.
    """

    def __init__(
        self,
        token: str,
        base_url: str = "https://api.dooray.com",
        timeout: int = 30,
        user_agent_prefix: Optional[str] = None,
        user_agent_suffix: Optional[str] = None,
        **kwargs
    ):
        """
        Initialize the AsyncWebClient.

        Args:
            token: Dooray API token
            base_url: Base URL for Dooray API (default: https://api.dooray.com)
            timeout: Request timeout in seconds (default: 30)
            user_agent_prefix: User-Agent 앞에 붙일 커스텀 문자열
            user_agent_suffix: User-Agent 뒤에 붙일 커스텀 문자열
            **kwargs: Additional arguments passed to aiohttp.ClientSession
        """
        self.token = token
        self.base_url = base_url.rstrip("/") + "/"
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.session_kwargs = kwargs

        if user_agent_prefix or user_agent_suffix:
            self._user_agent = _build_user_agent(
                prefix=user_agent_prefix,
                suffix=user_agent_suffix
            )
        else:
            self._user_agent = USER_AGENT

        # ADR-005: 서비스별 네임스페이스. lazy 생성으로 import 사이클을 피한다.
        self._messenger_api: Optional["AsyncMessengerAPI"] = None

    @property
    def messenger(self) -> "AsyncMessengerAPI":
        """메신저 서비스 API (ADR-005). 동사 진입점은 여기로 옮겨졌다."""
        if self._messenger_api is None:
            from .messenger import AsyncMessengerAPI
            self._messenger_api = AsyncMessengerAPI(self)
        return self._messenger_api

    def _ensure_session(self) -> aiohttp.ClientSession:
        """
        세션이 없거나 닫혀 있으면 새로 생성합니다.

        Returns:
            aiohttp.ClientSession: 활성 세션
        """
        if not hasattr(self, 'session') or self.session.closed:
            self.session = aiohttp.ClientSession(
                timeout=self.timeout,
                headers={
                    "Authorization": f"dooray-api {self.token}",
                    "Content-Type": "application/json",
                    "User-Agent": self._user_agent
                },
                **self.session_kwargs
            )
        return self.session

    async def __aenter__(self):
        """Async context manager entry."""
        self._ensure_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if hasattr(self, 'session') and not self.session.closed:
            await self.session.close()

    async def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the Dooray API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            endpoint: API endpoint (e.g., "/v1/messages")
            data: Request body data
            params: Query parameters
            **kwargs: Additional arguments passed to aiohttp

        Returns:
            Dict[str, Any]: The parsed JSON response

        Raises:
            DoorayRequestError: If the HTTP request fails
            aiohttp.ClientError: For network-level errors
        """
        self._ensure_session()

        url = urljoin(self.base_url, endpoint.lstrip("/"))

        request_kwargs = {**kwargs}

        if data is not None:
            request_kwargs["json"] = data
        if params is not None:
            request_kwargs["params"] = params

        try:
            async with self.session.request(method, url, **request_kwargs) as response:
                try:
                    response.raise_for_status()
                except aiohttp.ClientResponseError as e:
                    response_text = await response.text()
                    error_code = "CLIENT_ERROR" if e.status < 500 else "SERVER_ERROR"
                    raise DoorayRequestError(
                        f"HTTP {e.status}: {e.message}",
                        status_code=e.status,
                        response_body=response_text,
                        error_code=error_code,
                        context={"url": url, "method": method},
                    ) from e
                return await response.json()
        except aiohttp.ClientError as e:
            if isinstance(e, aiohttp.ClientResponseError):
                raise  # Already wrapped above
            raise DoorayRequestError(
                f"Network error: {e}",
                error_code="NETWORK_ERROR",
                context={"url": url, "method": method},
            ) from e

    async def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """Make a GET request."""
        return await self._request("GET", endpoint, params=params, **kwargs)

    async def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """Make a POST request."""
        return await self._request("POST", endpoint, data=data, **kwargs)

    async def put(self, endpoint: str, data: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """Make a PUT request."""
        return await self._request("PUT", endpoint, data=data, **kwargs)

    async def delete(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make a DELETE request."""
        return await self._request("DELETE", endpoint, **kwargs)

    # Dooray-specific API methods (ADR-004 deprecation aliases)
    # 한 마이너 동안 위임 alias로 보존된다. 신규 코드는 self.messenger.<verb>를 사용.
    async def send_message(
        self,
        channel: str,
        text: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``client.messenger.send_message(...)`` instead (ADR-005).
        """
        warnings.warn(
            "AsyncWebClient.send_message is deprecated. "
            f"Use {_MESSENGER_NEW_SURFACE} instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return await self.messenger.send_message(channel, text, **kwargs)

    async def update_message(
        self,
        channel: str,
        message_id: str,
        text: str,
    ) -> Dict[str, Any]:
        """
        Update an existing message in a Dooray channel.

        Note: 이 동사는 ADR-005의 3종 답장 동사와 별개이며, 한 마이너 동안
        본 위치에 유지된다. 후속 ADR에서 ``messenger.update_message`` 로
        흡수될 예정.
        """
        data = {"text": text}
        return await self.put(f"/messenger/v1/channels/{channel}/logs/{message_id}", data=data)

    async def get_channels(self, **kwargs) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``client.messenger.get_channels(...)`` once the slot is filled
            (후속 ADR). 현재는 평면 표면을 유지하되 deprecation 신호만 발생.
        """
        warnings.warn(
            "AsyncWebClient.get_channels is deprecated. "
            "It will move under client.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        return await self.get("/v1/channels", params=kwargs)

    async def get_messages(
        self,
        channel: str,
        limit: Optional[int] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``client.messenger.get_messages(...)`` once the slot is filled.
        """
        warnings.warn(
            "AsyncWebClient.get_messages is deprecated. "
            "It will move under client.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        params = {"channel": channel, **kwargs}
        if limit is not None:
            params["limit"] = limit
        return await self.get("/v1/messages", params=params)

    async def get_user_info(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``client.messenger.get_user_info(...)`` once the slot is filled.
        """
        warnings.warn(
            "AsyncWebClient.get_user_info is deprecated. "
            "It will move under client.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        if user_id:
            return await self.get(f"/v1/users/{user_id}")
        return await self.get("/v1/users/me")

    async def get_member(self, member_id: str) -> Dict[str, Any]:
        """
        Get organization member information by ID.

        Args:
            member_id: Organization member ID

        Returns:
            Dict[str, Any]: Member information containing:
                - id: Dooray Member ID
                - name: Member name
                - externalEmailAddress: Email address
                - nickname: Nickname
                - englishName: English name
                - nativeName: Native name
                - locale: Locale setting
                - timezoneName: Timezone
                - defaultOrganization: Default organization info

        Raises:
            DoorayRequestError: If API call fails (400, 401, 403, 404, 500)
        """
        response = await self.get(f"/common/v1/members/{member_id}")
        return response.get("result", {})

    async def fetch_socket_mode_token(self) -> Dict[str, Any]:
        """
        Fetch Socket Mode token from Open-Api-Gateway.

        This method calls POST /common/v1/socket-mode/tokens to get
        accessToken, tenantId, and organizationMemberId for WebSocket connection.

        Returns:
            Dict[str, Any]: Token info containing:
                - accessToken: JWT token for WebSocket authentication
                - tenantId: Tenant ID for WebSocket URL
                - organizationMemberId: Member ID for WebSocket URL

        Raises:
            ValueError: If required fields are missing from response
        """
        response = await self.post(SOCKET_MODE_TOKEN_ENDPOINT)
        return parse_socket_mode_token_response(response)
