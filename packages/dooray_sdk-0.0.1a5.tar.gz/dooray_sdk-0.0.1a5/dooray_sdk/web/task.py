"""
Task Service API — 슬롯 모듈 (ADR-005)

1차 범위에서는 인터페이스 슬롯만 확보한다. 구체 HTTP 표면은 후속 작업에서
추가한다 (PRD §C-3, FR-4). 외부 표면이 미리 존재함으로써 사용자는
`agent.task` 네임스페이스를 IDE 자동완성으로 발견할 수 있고, 구현 추가 시
표면 변경 없이 메서드만 채워진다.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .async_client import AsyncWebClient
    from .client import WebClient


class AsyncTaskAPI:
    """
    비동기 업무(Task) 서비스 API — 1차 범위에서는 슬롯만.

    실제 메서드(create_task, get_task 등)는 후속 ADR에서 추가된다.
    """

    def __init__(self, transport: "AsyncWebClient"):
        self._transport = transport


class TaskAPI:
    """동기 업무 서비스 API — 1차 범위에서는 슬롯만."""

    def __init__(self, transport: "WebClient"):
        self._transport = transport


__all__ = ["AsyncTaskAPI", "TaskAPI"]
