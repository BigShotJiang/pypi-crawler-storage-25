"""
Messenger Service API

`agent.messenger` 네임스페이스 뒤에 붙는 메신저 서비스 클라이언트.

ADR-003 / ADR-006 / ADR-007:
- send_message       : 채널에 새 메시지 (POST /messenger/v1/channels/{channel}/logs)
- reply_to_message   : 특정 메시지에 인용 답장 (POST .../logs/{log_id}/reply)
- reply_in_thread    : 스레드 답장 (1차 NotImplementedError, ADR-007)

`AsyncMessengerAPI`(비동기) / `MessengerAPI`(동기) 두 쌍 모두 제공한다.
HTTP 트랜스포트는 `AsyncWebClient` / `WebClient` 인스턴스를 주입받아 위임한다.
"""

from typing import Any, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from .async_client import AsyncWebClient
    from .client import WebClient


# 모든 메신저 API에서 공통으로 쓰는 path prefix.
_MESSENGER_BASE = "/messenger/v1/channels"


def _build_send_message_path(channel: str) -> str:
    """POST endpoint: 채널 로그 생성."""
    return f"{_MESSENGER_BASE}/{channel}/logs"


def _build_reply_to_message_path(channel: str, message_id: str) -> str:
    """POST endpoint: 메시지(log) 답장.

    SDK 표면에서는 `message_id`로 노출하지만, Dooray API는 같은 ID를
    `log_id`로 부른다. 매핑은 이 path 구성 시점 한 군데에서만 일어난다
    (ADR-006).
    """
    return f"{_MESSENGER_BASE}/{channel}/logs/{message_id}/reply"


# ADR-007에서 채택한 미구현 안내 메시지. send/reply 동사와 일관된 표면이 보이도록
# raise 시점에 동일 문자열을 사용해 호출자가 alternative 동사를 쉽게 찾도록 한다.
_REPLY_IN_THREAD_NOT_IMPLEMENTED = (
    "reply_in_thread is not implemented yet. "
    "Tracked in docs/features/dooray-통합/11446/adr.md ADR-007. "
    "Use client.messenger.send_message() or client.messenger.reply_to_message() "
    "in the meantime."
)


class AsyncMessengerAPI:
    """
    비동기 메신저 서비스 API.

    `agent.messenger` 속성 뒤에서 노출되어 다음 세 동사를 제공한다:

        await client.messenger.send_message(channel, text)
        await client.messenger.reply_to_message(channel, message_id, text)
        await client.messenger.reply_in_thread(parent_channel_id, text)  # NotImplementedError

    Args:
        transport: HTTP 트랜스포트 (AsyncWebClient 인스턴스). post() 메서드를
                   가진 비동기 객체이면 무엇이든 주입 가능 (테스트 mock 친화).
    """

    def __init__(self, transport: "AsyncWebClient"):
        self._transport = transport

    async def send_message(
        self,
        channel: str,
        text: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """채널에 새 메시지를 보낸다 (ADR-003).

        Args:
            channel: 채널 ID
            text: 메시지 텍스트
            **kwargs: 추가 body 필드 (예: attachments 등)

        Returns:
            Dooray API 응답 JSON.
        """
        data: Dict[str, Any] = {"text": text, **kwargs}
        return await self._transport.post(_build_send_message_path(channel), data=data)

    async def reply_to_message(
        self,
        channel: str,
        message_id: str,
        text: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """특정 메시지에 인용 답장 (ADR-006).

        Endpoint: ``POST /messenger/v1/channels/{channel}/logs/{message_id}/reply``.

        Args:
            channel: 메시지가 속한 채널 ID
            message_id: 답장 대상 메시지 ID (Dooray 용어 "log id")
            text: 답장 메시지 본문
            **kwargs: 추가 body 필드
        """
        data: Dict[str, Any] = {"text": text, **kwargs}
        return await self._transport.post(
            _build_reply_to_message_path(channel, message_id), data=data
        )

    async def reply_in_thread(
        self,
        parent_channel_id: str,
        text: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """스레드 답장 (ADR-007, 1차에서는 미구현).

        호출 시 :class:`NotImplementedError` 가 발생한다. 외부 표면 안정성을
        위해 시그니처는 미리 노출되어 있다.
        """
        raise NotImplementedError(_REPLY_IN_THREAD_NOT_IMPLEMENTED)


class MessengerAPI:
    """
    동기 메신저 서비스 API.

    동기/비동기 짝(ADR-003) 유지를 위해 :class:`AsyncMessengerAPI`와
    1:1 메서드 표면을 제공한다.
    """

    def __init__(self, transport: "WebClient"):
        self._transport = transport

    def send_message(
        self,
        channel: str,
        text: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {"text": text, **kwargs}
        return self._transport.post(_build_send_message_path(channel), data=data)

    def reply_to_message(
        self,
        channel: str,
        message_id: str,
        text: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {"text": text, **kwargs}
        return self._transport.post(
            _build_reply_to_message_path(channel, message_id), data=data
        )

    def reply_in_thread(
        self,
        parent_channel_id: str,
        text: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        raise NotImplementedError(_REPLY_IN_THREAD_NOT_IMPLEMENTED)


__all__ = [
    "AsyncMessengerAPI",
    "MessengerAPI",
]
