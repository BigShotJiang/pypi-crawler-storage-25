"""
Wiki Service API — 슬롯 모듈 (ADR-005)

1차 범위에서는 인터페이스 슬롯만 확보한다. 구체 HTTP 표면은 후속 작업에서
추가한다 (PRD §C-3, FR-4).
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .async_client import AsyncWebClient
    from .client import WebClient


class AsyncWikiAPI:
    """
    비동기 위키 서비스 API — 1차 범위에서는 슬롯만.

    실제 메서드(create_page, get_page 등)는 후속 ADR에서 추가된다.
    """

    def __init__(self, transport: "AsyncWebClient"):
        self._transport = transport


class WikiAPI:
    """동기 위키 서비스 API — 1차 범위에서는 슬롯만."""

    def __init__(self, transport: "WebClient"):
        self._transport = transport


__all__ = ["AsyncWikiAPI", "WikiAPI"]
