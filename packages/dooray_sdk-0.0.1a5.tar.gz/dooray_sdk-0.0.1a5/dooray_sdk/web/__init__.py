"""
Dooray Web Client

HTTP-based API client for Dooray services.

ADR-005 로 서비스별 모듈로 분리되었다:
- ``client.py`` / ``async_client.py`` : HTTP 트랜스포트
- ``messenger.py`` : MessengerAPI / AsyncMessengerAPI (3종 동사)
- ``task.py`` / ``wiki.py`` : 슬롯 (후속 ADR에서 채움)
"""

from .async_client import AsyncWebClient
from .client import WebClient
from .messenger import AsyncMessengerAPI, MessengerAPI
from .task import AsyncTaskAPI, TaskAPI
from .wiki import AsyncWikiAPI, WikiAPI

__all__ = [
    "AsyncWebClient",
    "WebClient",
    "AsyncMessengerAPI",
    "MessengerAPI",
    "AsyncTaskAPI",
    "TaskAPI",
    "AsyncWikiAPI",
    "WikiAPI",
]
