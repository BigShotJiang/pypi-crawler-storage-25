"""
Dooray Web Client

HTTP-based API client for Dooray services.
"""

import warnings
from typing import Optional, Dict, Any, TYPE_CHECKING
from urllib.parse import urljoin

import requests

from .token import SOCKET_MODE_TOKEN_ENDPOINT, parse_socket_mode_token_response
from .._user_agent import USER_AGENT, _build_user_agent
from ..exceptions import DoorayRequestError

if TYPE_CHECKING:
    from .messenger import MessengerAPI


_MESSENGER_NEW_SURFACE = "client.messenger.<verb> (e.g. client.messenger.send_message)"


class WebClient:
    """
    A client for making HTTP requests to Dooray APIs.
    """

    def __init__(
        self,
        token: str,
        base_url: str = "https://api.dooray.com",
        timeout: int = 30,
        user_agent_prefix: Optional[str] = None,
        user_agent_suffix: Optional[str] = None,
        **kwargs
    ):
        """
        Initialize the WebClient.

        Args:
            token: Dooray API token
            base_url: Base URL for Dooray API (default: https://api.dooray.com)
            timeout: Request timeout in seconds (default: 30)
            user_agent_prefix: User-Agent 앞에 붙일 커스텀 문자열
            user_agent_suffix: User-Agent 뒤에 붙일 커스텀 문자열
            **kwargs: Additional arguments passed to requests.Session
        """
        self.token = token
        self.base_url = base_url.rstrip("/") + "/"
        self.timeout = timeout

        if user_agent_prefix or user_agent_suffix:
            user_agent = _build_user_agent(
                prefix=user_agent_prefix,
                suffix=user_agent_suffix
            )
        else:
            user_agent = USER_AGENT

        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"dooray-api {token}",
            "Content-Type": "application/json",
            "User-Agent": user_agent
        })

        # Apply any additional session configuration
        for key, value in kwargs.items():
            setattr(self.session, key, value)

        # ADR-005: 서비스별 네임스페이스. lazy 생성.
        self._messenger_api: Optional["MessengerAPI"] = None

    @property
    def messenger(self) -> "MessengerAPI":
        """메신저 서비스 API (ADR-005). 동사 진입점은 여기로 옮겨졌다."""
        if self._messenger_api is None:
            from .messenger import MessengerAPI
            self._messenger_api = MessengerAPI(self)
        return self._messenger_api

    def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the Dooray API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            endpoint: API endpoint (e.g., "/v1/messages")
            data: Request body data
            params: Query parameters
            **kwargs: Additional arguments passed to requests

        Returns:
            Dict[str, Any]: The parsed JSON response

        Raises:
            DoorayRequestError: If the HTTP request fails
            requests.RequestException: For network-level errors
        """
        url = urljoin(self.base_url, endpoint.lstrip("/"))

        request_kwargs = {
            "timeout": self.timeout,
            **kwargs
        }

        if data is not None:
            request_kwargs["json"] = data
        if params is not None:
            request_kwargs["params"] = params

        try:
            response = self.session.request(method, url, **request_kwargs)
            try:
                response.raise_for_status()
            except requests.HTTPError as e:
                error_code = "CLIENT_ERROR" if response.status_code < 500 else "SERVER_ERROR"
                raise DoorayRequestError(
                    f"HTTP {response.status_code}: {response.reason}",
                    status_code=response.status_code,
                    response_body=response.text,
                    error_code=error_code,
                    context={"url": url, "method": method},
                ) from e
            return response.json()
        except requests.RequestException as e:
            if isinstance(e, requests.HTTPError):
                raise  # Already wrapped above
            raise DoorayRequestError(
                f"Network error: {e}",
                error_code="NETWORK_ERROR",
                context={"url": url, "method": method},
            ) from e

    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """Make a GET request."""
        return self._request("GET", endpoint, params=params, **kwargs)

    def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """Make a POST request."""
        return self._request("POST", endpoint, data=data, **kwargs)

    def put(self, endpoint: str, data: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """Make a PUT request."""
        return self._request("PUT", endpoint, data=data, **kwargs)

    def delete(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make a DELETE request."""
        return self._request("DELETE", endpoint, **kwargs)

    # Dooray-specific API methods (ADR-004 deprecation aliases)
    def send_message(
        self,
        channel: str,
        text: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``client.messenger.send_message(...)`` instead (ADR-005).
        """
        warnings.warn(
            "WebClient.send_message is deprecated. "
            f"Use {_MESSENGER_NEW_SURFACE} instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.messenger.send_message(channel, text, **kwargs)

    def update_message(
        self,
        channel: str,
        message_id: str,
        text: str,
    ) -> Dict[str, Any]:
        """
        Update an existing message in a Dooray channel.

        Note: ADR-005의 3종 답장 동사와 별개이며 한 마이너 동안 본 위치에 유지.
        후속 ADR에서 ``messenger.update_message`` 로 흡수될 예정.
        """
        data = {"text": text}
        return self.put(f"/messenger/v1/channels/{channel}/logs/{message_id}", data=data)

    def get_channels(self, **kwargs) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``client.messenger.get_channels(...)`` once the slot is filled.
        """
        warnings.warn(
            "WebClient.get_channels is deprecated. "
            "It will move under client.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.get("/v1/channels", params=kwargs)

    def get_messages(
        self,
        channel: str,
        limit: Optional[int] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``client.messenger.get_messages(...)`` once the slot is filled.
        """
        warnings.warn(
            "WebClient.get_messages is deprecated. "
            "It will move under client.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        params = {"channel": channel, **kwargs}
        if limit is not None:
            params["limit"] = limit
        return self.get("/v1/messages", params=params)

    def get_user_info(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        .. deprecated::
            Use ``client.messenger.get_user_info(...)`` once the slot is filled.
        """
        warnings.warn(
            "WebClient.get_user_info is deprecated. "
            "It will move under client.messenger.* in a future ADR.",
            DeprecationWarning,
            stacklevel=2,
        )
        if user_id:
            return self.get(f"/v1/users/{user_id}")
        return self.get("/v1/users/me")

    def get_member(self, member_id: str) -> Dict[str, Any]:
        """
        Get organization member information by ID.

        Args:
            member_id: Organization member ID

        Returns:
            Dict[str, Any]: Member information containing:
                - id: Dooray Member ID
                - name: Member name
                - externalEmailAddress: Email address
                - nickname: Nickname
                - englishName: English name
                - nativeName: Native name
                - locale: Locale setting
                - timezoneName: Timezone
                - defaultOrganization: Default organization info

        Raises:
            DoorayRequestError: If API call fails (400, 401, 403, 404, 500)
        """
        response = self.get(f"/common/v1/members/{member_id}")
        return response.get("result", {})

    def fetch_socket_mode_token(self) -> Dict[str, Any]:
        """
        Fetch Socket Mode token from Open-Api-Gateway.

        This method calls POST /common/v1/socket-mode/tokens to get
        accessToken, tenantId, and organizationMemberId for WebSocket connection.

        Returns:
            Dict[str, Any]: Token info containing:
                - accessToken: JWT token for WebSocket authentication
                - tenantId: Tenant ID for WebSocket URL
                - organizationMemberId: Member ID for WebSocket URL

        Raises:
            ValueError: If required fields are missing from response
        """
        response = self.post(SOCKET_MODE_TOKEN_ENDPOINT)
        return parse_socket_mode_token_response(response)
