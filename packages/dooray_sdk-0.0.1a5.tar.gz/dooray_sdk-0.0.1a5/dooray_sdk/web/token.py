"""
Socket Mode Token utilities.

Common token parsing logic for both sync and async clients.
"""

from typing import Dict, Any

from ..exceptions import DoorayTokenError


# Socket Mode token API endpoint
SOCKET_MODE_TOKEN_ENDPOINT = "/common/v1/socket-mode/tokens"


def parse_socket_mode_token_response(response: Dict[str, Any]) -> Dict[str, Any]:
    """
    Parse Socket Mode token response from Open-Api-Gateway.

    Args:
        response: Raw API response containing result with token info

    Returns:
        Dict[str, Any]: Token info containing:
            - accessToken: JWT token for WebSocket authentication
            - tenantId: Tenant ID for WebSocket URL
            - organizationMemberId: Member ID for WebSocket URL

    Raises:
        DoorayTokenError: If required fields are missing from response
    """
    result = response.get("result", {})
    access_token = result.get("accessToken")
    tenant_id = result.get("tenantId")
    member_id = result.get("organizationMemberId")

    if not all([access_token, tenant_id, member_id]):
        raise DoorayTokenError(
            f"Invalid Socket Mode token response: missing required fields. "
            f"Got: accessToken={bool(access_token)}, "
            f"tenantId={bool(tenant_id)}, "
            f"organizationMemberId={bool(member_id)}",
            token_type="socket_mode",
            error_code="INVALID_TOKEN_RESPONSE",
        )

    return {
        "accessToken": access_token,
        "tenantId": tenant_id,
        "organizationMemberId": member_id,
    }
