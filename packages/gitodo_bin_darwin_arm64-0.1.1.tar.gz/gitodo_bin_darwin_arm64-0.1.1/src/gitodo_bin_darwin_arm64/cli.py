""" gitodo-bin-darwin-arm64 """


def main() -> None:
    print("  gitodo-bin-darwin-arm64  ")
