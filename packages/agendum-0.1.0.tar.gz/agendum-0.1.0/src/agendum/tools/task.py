"""Task management tools: CRUD (create, list, get)."""

from __future__ import annotations

from agendum.models import TaskStatus

_VALID_STATUSES = ", ".join(s.value for s in TaskStatus)


def register(mcp, stores, agents):
    """Register task CRUD tools on the MCP server."""

    @mcp.tool()
    def pm_task_create(
        project: str,
        title: str,
        description: str = "",
        priority: str = "medium",
        task_type: str = "dev",
        depends_on: list[str] | None = None,
        acceptance_criteria: list[str] | None = None,
        tags: list[str] | None = None,
    ) -> str:
        """Create a new task in a project.

        Tasks are stored as Markdown files. Use depends_on to set task ordering.
        Acceptance criteria are checked when completing a task.
        Valid priorities: critical, high, medium, low.
        Valid types: dev, docs, email, planning, personal, ops, research, review.
        """
        try:
            task = stores.task.create_task(
                project=project,
                title=title,
                context=description,
                priority=priority,
                type=task_type,
                depends_on=depends_on or [],
                acceptance_criteria=acceptance_criteria or [],
                tags=tags or [],
            )
        except ValueError as e:
            return f"Error: {e}"
        status_note = ""
        if task.depends_on:
            status_note = f" (blocked by: {', '.join(task.depends_on)})"
        return f"Created task {task.id}: {task.title}{status_note}"

    @mcp.tool()
    def pm_task_list(
        project: str,
        status: str | None = None,
        assigned: str | None = None,
        tag: str | None = None,
        task_type: str | None = None,
    ) -> str:
        """List tasks in a project with optional filters.

        Valid statuses: pending, in_progress, blocked, review, done, cancelled.
        Returns a formatted table with status, ID, title, priority, and assignee.
        """
        status_enum = None
        if status:
            try:
                status_enum = TaskStatus(status)
            except ValueError:
                return f"Invalid status '{status}'. Valid values: {_VALID_STATUSES}"
        try:
            tasks = stores.task.list_tasks(project, status=status_enum, assigned=assigned, tag=tag, task_type=task_type)
        except ValueError as e:
            return f"Error: {e}"

        if not tasks:
            return f"No tasks found in '{project}' with the given filters."

        lines = [f"Tasks in '{project}' ({len(tasks)}):"]
        for t in tasks:
            assigned_str = f" [{t.assigned}]" if t.assigned else ""
            deps_str = f" (depends: {','.join(t.depends_on)})" if t.depends_on else ""
            lines.append(f"  [{t.status.value:^11}] {t.id}: {t.title} ({t.priority.value}){assigned_str}{deps_str}")
        return "\n".join(lines)

    @mcp.tool()
    def pm_task_get(project: str, task_id: str) -> str:
        """Get full details of a specific task including progress log, decisions, and handoff context."""
        try:
            task = stores.task.get_task(project, task_id)
        except ValueError as e:
            return f"Error: {e}"
        if not task:
            return f"Task '{task_id}' not found in project '{project}'."

        lines = [
            f"# {task.title}",
            f"ID: {task.id} | Status: {task.status.value} | Priority: {task.priority.value}",
            f"Type: {task.type.value} | Assigned: {task.assigned or 'unassigned'}",
        ]
        if task.depends_on:
            lines.append(f"Depends on: {', '.join(task.depends_on)}")
        if task.blocks:
            lines.append(f"Blocks: {', '.join(task.blocks)}")
        if task.acceptance_criteria:
            lines.append("\n## Acceptance Criteria")
            for ac in task.acceptance_criteria:
                lines.append(f"  - [ ] {ac}")
        if task.context:
            lines.append(f"\n## Context\n{task.context}")
        if task.progress:
            lines.append("\n## Progress")
            for p in task.progress:
                lines.append(f"  - [{p.timestamp.strftime('%m-%d %H:%M')}] {p.agent} — {p.message}")
        if task.decisions:
            lines.append("\n## Decisions")
            for d in task.decisions:
                lines.append(f"  - {d}")

        # Structured handoff takes priority over legacy free text
        if task.structured_handoff:
            h = task.structured_handoff
            ts = h.timestamp.strftime("%Y-%m-%d %H:%M") if h.timestamp else "?"
            ctx_parts = [f"{h.agent_id}"]
            if h.device:
                ctx_parts.append(h.device)
            if h.git_branch:
                ctx_parts.append(f"branch: {h.git_branch}")
            lines.append(f"\n## Handoff  (from {', '.join(ctx_parts)} at {ts})")
            if h.completed:
                lines.append("  Done:")
                for item in h.completed:
                    lines.append(f"    [x] {item}")
            if h.remaining:
                lines.append("  Remaining:")
                for item in h.remaining:
                    lines.append(f"    [ ] {item}")
            if h.key_files:
                lines.append(f"  Key files: {', '.join(h.key_files)}")
            if h.decisions:
                lines.append("  Decisions:")
                for d in h.decisions:
                    lines.append(f"    - {d}")
            if h.gotchas:
                lines.append("  Gotchas:")
                for g in h.gotchas:
                    lines.append(f"    ⚠ {g}")
            if h.next_agent_hints:
                hints = ", ".join(f"{k}: {v}" for k, v in h.next_agent_hints.items())
                lines.append(f"  Next agent hints: {hints}")
        elif task.handoff:
            lines.append(f"\n## Handoff\n{task.handoff}")

        if task.agent_history:
            lines.append(f"\n## Agent History ({len(task.agent_history)} handoff(s))")
            for rec in task.agent_history:
                ts = rec.timestamp.strftime("%Y-%m-%d %H:%M") if rec.timestamp else "?"
                lines.append(f"  - {rec.agent_id} ({rec.agent_type or 'unknown'}) at {ts}")

        return "\n".join(lines)
