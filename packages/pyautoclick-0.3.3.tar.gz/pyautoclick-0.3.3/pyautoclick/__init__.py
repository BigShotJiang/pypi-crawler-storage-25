"""Auto-clicker with hold mode, auto mode, global hotkeys."""

__version__ = "0.3.3"
