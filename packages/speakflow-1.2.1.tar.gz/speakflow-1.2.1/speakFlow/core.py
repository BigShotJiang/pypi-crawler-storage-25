from .engine import SpeakFlow

_engine = None

def _get_engine():
    global _engine
    if _engine is None:
        _engine = SpeakFlow()
        _engine.warmup("ready")
    return _engine

def say(text):
    eng = _get_engine()
    eng.speak(text)

def wait():
    if _engine:
        _engine.wait()