import threading
import queue
import sounddevice as sd
from TTS.api import TTS
import re
import time
import os
import hashlib
import numpy as np

DEFAULT_MODEL = "tts_models/en/ljspeech/vits"
MAX_CACHE = 100
CACHE_REPEAT_THRESHOLD = 1
CACHE_DIR = "tts_cache"

os.makedirs(CACHE_DIR, exist_ok=True)

digit_map = {
    "0": "zero", "1": "one", "2": "two", "3": "three", "4": "four",
    "5": "five", "6": "six", "7": "seven", "8": "eight", "9": "nine"
}

def clean_text(text):
    text = text.lower()

    def replace_digits(match):
        return " ".join(digit_map[d] for d in match.group())

    text = re.sub(r"\d+", replace_digits, text)
    text = re.sub(r"[^a-zA-Z\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()

    return text


class SpeakFlow:
    def __init__(self, model_name=DEFAULT_MODEL, device=5):
        print("[TTS] Loading model...")
        self.tts = TTS(model_name=model_name)
        print("[TTS] Model loaded.")

        self.device = device
        sd.default.device = device  # 🔥 LOCK DEVICE ONCE

        self.queue = queue.Queue()
        self.memory_cache = {}
        self.usage_count = {}

        threading.Thread(target=self._worker, daemon=True).start()

    def _get_key(self, text):
        return hashlib.md5(text.encode()).hexdigest()

    def _get_disk_path(self, key):
        return os.path.join(CACHE_DIR, f"{key}.npy")

    def _add_to_memory(self, key, wav):
        if key not in self.memory_cache and len(self.memory_cache) >= MAX_CACHE:
            oldest = next(iter(self.memory_cache))
            del self.memory_cache[oldest]
        self.memory_cache[key] = wav

    def _save_disk(self, key, wav):
        np.save(self._get_disk_path(key), wav)

    def _load_disk(self, key):
        path = self._get_disk_path(key)
        if os.path.exists(path):
            return np.load(path)
        return None

    def _worker(self):
        while True:
            text = self.queue.get()

            if not text:
                self.queue.task_done()
                continue

            key = self._get_key(text)

            try:
                if key in self.memory_cache:
                    wav = self.memory_cache[key]
                    print(f"[MEM CACHE] {text}")

                elif (wav_disk := self._load_disk(key)) is not None:
                    wav = wav_disk
                    self._add_to_memory(key, wav)
                    print(f"[DISK CACHE] {text}")

                else:
                    start = time.time()
                    wav = self.tts.tts(text)
                    print(f"[GENERATED] {text} ({time.time() - start:.2f}s)")

                    self.usage_count[text] = self.usage_count.get(text, 0) + 1

                    if self.usage_count[text] >= CACHE_REPEAT_THRESHOLD:
                        self._add_to_memory(key, wav)
                        self._save_disk(key, wav)
                        print(f"[CACHED] {text}")

                # 🔥 FIX: stable playback
                wav = np.concatenate([np.zeros(5000), wav])
                sd.play(wav.copy(), samplerate=22050, device=self.device, blocking=True)

            except Exception as e:
                print("[TTS ERROR]", e)

            self.queue.task_done()

    def speak(self, text):
        cleaned = clean_text(text)
        if cleaned:
            self.queue.put(cleaned)

    def warmup(self, text="warming up"):
        print("[TTS] Warmup...")
        self.tts.tts(clean_text(text))
        print("[TTS] Warmed.")

    def precache(self, phrases):
        print("[TTS] Pre-caching...")
        for phrase in phrases:
            cleaned = clean_text(phrase)
            key = self._get_key(cleaned)

            wav = self.tts.tts(cleaned)
            self._add_to_memory(key, wav)
            self._save_disk(key, wav)

        print("[TTS] Pre-cache done.")

    def wait(self):
        self.queue.join()