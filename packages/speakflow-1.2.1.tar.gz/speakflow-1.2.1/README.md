# SpeakFlow

Turn `print()` into speech — without the pain.

```python
from speakflow import say

say("build complete")
say("error detected")
```

## Why SpeakFlow?

Raw TTS is painful:
- blocks execution
- overlaps audio
- no caching
- breaks with devices

SpeakFlow fixes it:
- queued speech (no overlap)
- async playback
- caching (fast repeated phrases)
- stable audio handling

## Install

```bash
pip install speakflow
```

## Example

```python
from speakflow import say, wait

say("hello")
say("done")
wait()
```
