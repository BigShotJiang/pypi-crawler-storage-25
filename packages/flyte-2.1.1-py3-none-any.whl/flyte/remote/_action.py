from __future__ import annotations

import asyncio
from collections import UserDict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from functools import cached_property
from typing import (
    Any,
    AsyncGenerator,
    AsyncIterator,
    Dict,
    Iterator,
    List,
    Literal,
    Tuple,
    Union,
    cast,
)

import rich.pretty
import rich.repr
from connectrpc.code import Code
from connectrpc.errors import ConnectError
from flyteidl2.common import identifier_pb2, list_pb2, phase_pb2
from flyteidl2.task import common_pb2
from flyteidl2.workflow import run_definition_pb2, run_service_pb2
from flyteidl2.workflow.run_service_pb2 import WatchActionDetailsResponse
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from flyte import types
from flyte._initialize import ensure_client, get_client, get_init_config
from flyte._interface import default_output_name
from flyte.models import ActionPhase
from flyte.remote._common import TimeFilter, ToJSONMixin, time_filtering
from flyte.remote._logs import Logs
from flyte.syncify import syncify

WaitFor = Literal["terminal", "running", "logs-ready"]


@rich.repr.auto
@dataclass
class PhaseTransitionInfo:
    """
    Information about a single phase transition in an action attempt.

    Attributes:
        phase: The action phase (e.g., QUEUED, INITIALIZING, RUNNING)
        start_time: When this phase started
        end_time: When this phase ended (None if still in this phase)
        duration: Duration spent in this phase
    """

    phase: ActionPhase
    start_time: datetime
    end_time: datetime | None

    @property
    def duration(self) -> timedelta:
        """Calculate the duration spent in this phase."""
        if self.end_time:
            return abs(self.end_time - self.start_time)
        return datetime.now(timezone.utc) - self.start_time


def _action_time_phase(
    action: run_definition_pb2.Action | run_definition_pb2.ActionDetails,
) -> rich.repr.Result:
    """
    Rich representation of the action time and phase.
    """
    start_time = action.status.start_time.ToDatetime().replace(tzinfo=timezone.utc)
    yield "start_time", start_time.isoformat()
    if action.status.phase in [
        phase_pb2.ACTION_PHASE_FAILED,
        phase_pb2.ACTION_PHASE_SUCCEEDED,
        phase_pb2.ACTION_PHASE_ABORTED,
        phase_pb2.ACTION_PHASE_TIMED_OUT,
    ]:
        end_time = action.status.end_time.ToDatetime().replace(tzinfo=timezone.utc)
        yield "end_time", end_time.isoformat()
        yield "run_time", f"{(end_time - start_time).seconds} secs"
    else:
        yield "end_time", None
        yield "run_time", f"{(datetime.now(timezone.utc) - start_time).seconds} secs"
    yield "phase", phase_pb2.ActionPhase.Name(action.status.phase)
    if isinstance(action, run_definition_pb2.ActionDetails):
        yield (
            "error",
            (f"{action.error_info.kind}: {action.error_info.message}" if action.HasField("error_info") else "NA"),
        )


def _action_rich_repr(action: run_definition_pb2.Action) -> rich.repr.Result:
    """
    Rich representation of the action.
    """
    yield "name", action.id.run.name
    if action.metadata.HasField("task"):
        yield "task name", action.metadata.task.id.name
        yield "type", action.metadata.task.task_type
    elif action.metadata.HasField("trace"):
        yield "trace", action.metadata.trace.name
        yield "type", "trace"
    yield "action name", action.id.name
    yield from _action_time_phase(action)
    yield "group", action.metadata.group
    yield "parent", action.metadata.parent
    yield "attempts", action.status.attempts


def _attempt_rich_repr(
    action: List[run_definition_pb2.ActionAttempt],
) -> rich.repr.Result:
    for attempt in action:
        yield "attempt", attempt.attempt
        yield "phase", phase_pb2.ActionPhase.Name(attempt.phase)
        yield "logs_available", attempt.logs_available


def _action_details_rich_repr(
    action: run_definition_pb2.ActionDetails,
) -> rich.repr.Result:
    """
    Rich representation of the action details.
    """
    yield "name", action.id.run.name
    yield from _action_time_phase(action)
    if action.HasField("task"):
        yield "task", action.task.task_template.id.name
        yield "task_type", action.task.task_template.type
        yield "task_version", action.task.task_template.id.version
    yield "attempts", action.attempts
    yield "error", (f"{action.error_info.kind}: {action.error_info.message}" if action.HasField("error_info") else "NA")
    yield "phase", phase_pb2.ActionPhase.Name(action.status.phase)
    yield "group", action.metadata.group
    yield "parent", action.metadata.parent


def _action_done_check(phase: phase_pb2.ActionPhase) -> bool:
    """
    Check if the action is done.
    """
    return phase in [
        phase_pb2.ACTION_PHASE_FAILED,
        phase_pb2.ACTION_PHASE_SUCCEEDED,
        phase_pb2.ACTION_PHASE_ABORTED,
        phase_pb2.ACTION_PHASE_TIMED_OUT,
    ]


@dataclass
class Action(ToJSONMixin):
    """
    A class representing an action. It is used to manage the "execution" of a task and its state on the remote API.

    From a datamodel perspective, a Run consists of actions. All actions are linearly nested under a parent action.
     Actions have unique auto-generated identifiers, that are unique within a parent action.

     <pre>
     run
      - a0
        - action1 under a0
        - action2 under a0
            - action1 under action2 under a0
            - action2 under action1 under action2 under a0
            - ...
        - ...
    </pre>
    """

    pb2: run_definition_pb2.Action
    _details: ActionDetails | None = None

    @syncify
    @classmethod
    async def listall(
        cls,
        for_run_name: str,
        in_phase: Tuple[ActionPhase | str, ...] | None = None,
        sort_by: Tuple[str, Literal["asc", "desc"]] | None = None,
        created_at: TimeFilter | None = None,
        updated_at: TimeFilter | None = None,
    ) -> Union[Iterator[Action], AsyncIterator[Action]]:
        """
        Get all actions for a given run.

        :param for_run_name: The name of the run.
        :param in_phase: Filter actions by one or more phases.
        :param filters: The filters to apply to the project list.
        :param sort_by: The sorting criteria for the project list, in the format (field, order).
        :param created_at: Filter actions by creation time range.
        :param updated_at: Filter actions by last-update time range.
        :return: An iterator of actions.
        """
        ensure_client()
        token = None
        sort_by = sort_by or ("created_at", "asc")
        sort_pb2 = list_pb2.Sort(
            key=sort_by[0],
            direction=(list_pb2.Sort.ASCENDING if sort_by[1] == "asc" else list_pb2.Sort.DESCENDING),
        )

        # Build filters for phase
        filter_list = []
        if in_phase:
            from flyteidl2.common import phase_pb2

            from flyte._logging import logger

            phases = [
                str(p.to_protobuf_value())
                if isinstance(p, ActionPhase)
                else str(phase_pb2.ActionPhase.Value(f"ACTION_PHASE_{p.upper()}"))
                for p in in_phase
            ]
            logger.debug(f"Fetching action phases: {phases}")
            if len(phases) > 1:
                filter_list.append(
                    list_pb2.Filter(
                        function=list_pb2.Filter.Function.VALUE_IN,
                        field="phase",
                        values=phases,
                    ),
                )
            else:
                filter_list.append(
                    list_pb2.Filter(
                        function=list_pb2.Filter.Function.EQUAL,
                        field="phase",
                        values=phases[0],
                    ),
                )

        if created_at:
            filter_list.extend(time_filtering("created_at", created_at))
        if updated_at:
            filter_list.extend(time_filtering("updated_at", updated_at))

        cfg = get_init_config()
        while True:
            req = list_pb2.ListRequest(
                limit=100,
                token=token,
                sort_by=sort_pb2,
                filters=filter_list or None,
            )
            resp = await get_client().run_service.list_actions(
                run_service_pb2.ListActionsRequest(
                    request=req,
                    run_id=identifier_pb2.RunIdentifier(
                        org=cfg.org,
                        project=cfg.project,
                        domain=cfg.domain,
                        name=for_run_name,
                    ),
                )
            )
            token = resp.token
            for r in resp.actions:
                yield cls(r)
            if not token:
                break

    @syncify
    @classmethod
    async def get(
        cls,
        uri: str | None = None,
        /,
        run_name: str | None = None,
        name: str | None = None,
    ) -> Action:
        """
        Get a run by its ID or name. If both are provided, the ID will take precedence.

        :param uri: The URI of the action.
        :param run_name: The name of the action.
        :param name: The name of the action.
        """
        ensure_client()
        cfg = get_init_config()
        details: ActionDetails = await ActionDetails.get_details.aio(
            identifier_pb2.ActionIdentifier(
                run=identifier_pb2.RunIdentifier(
                    org=cfg.org,
                    project=cfg.project,
                    domain=cfg.domain,
                    name=run_name,
                ),
                name=name,
            ),
        )
        return cls(
            pb2=run_definition_pb2.Action(
                id=details.action_id,
                metadata=details.pb2.metadata,
                status=details.pb2.status,
            ),
            _details=details,
        )

    @property
    def phase(self) -> ActionPhase:
        """
        Get the phase of the action.

        Returns:
            The current execution phase as an ActionPhase enum
        """
        return ActionPhase.from_protobuf(self.pb2.status.phase)

    @property
    def raw_phase(self) -> phase_pb2.ActionPhase:
        """
        Get the raw phase of the action.
        """
        return self.pb2.status.phase

    @property
    def name(self) -> str:
        """
        Get the name of the action.
        """
        return self.action_id.name

    @property
    def run_name(self) -> str:
        """
        Get the name of the run.
        """
        return self.action_id.run.name

    @property
    def task_name(self) -> str | None:
        """
        Get the name of the task.
        """
        if self.pb2.metadata.HasField("task") and self.pb2.metadata.task.HasField("id"):
            return self.pb2.metadata.task.id.name
        return None

    @property
    def action_id(self) -> identifier_pb2.ActionIdentifier:
        """
        Get the action ID.
        """
        return self.pb2.id

    @property
    def start_time(self) -> datetime:
        """
        Get the start time of the action.
        """
        return self.pb2.status.start_time.ToDatetime().replace(tzinfo=timezone.utc)

    @syncify
    async def abort(self, reason: str = "Manually aborted from the SDK."):
        """
        Aborts / Terminates the action.
        """
        try:
            await get_client().run_service.abort_action(
                run_service_pb2.AbortActionRequest(
                    action_id=self.pb2.id,
                    reason=reason,
                )
            )
        except ConnectError as e:
            if e.code == Code.NOT_FOUND:
                return
            raise

    @syncify
    async def show_logs(
        self,
        attempt: int | None = None,
        max_lines: int = 30,
        show_ts: bool = False,
        raw: bool = False,
        filter_system: bool = False,
    ):
        """
        Display logs for the action.

        :param attempt: The attempt number to show logs for (defaults to latest attempt).
        :param max_lines: Maximum number of log lines to display in the viewer.
        :param show_ts: Whether to show timestamps with each log line.
        :param raw: If True, print logs directly without the interactive viewer.
        :param filter_system: If True, filter out system-generated log lines.
        """
        details = await self.details()
        if not details.is_running and not details.done():
            # TODO we can short circuit here if the attempt is not the last one and it is done!
            await self.wait(wait_for="logs-ready")
            details = await self.details()
        if not attempt:
            attempt = details.attempts
        return await Logs.create_viewer(
            action_id=self.action_id,
            attempt=attempt,
            max_lines=max_lines,
            show_ts=show_ts,
            raw=raw,
            filter_system=filter_system,
        )

    @syncify
    async def get_logs(
        self,
        attempt: int | None = None,
        filter_system: bool = False,
        show_ts: bool = False,
    ) -> AsyncGenerator[str, None]:
        """
        Get logs for the action as an iterator of strings.

        Can be called synchronously (returns `Iterator[str]`) or asynchronously
        via `.aio()` (returns `AsyncIterator[str]`).

        :param attempt: The attempt number to retrieve logs for (defaults to latest attempt).
        :param filter_system: If True, filter out system-generated log lines.
        :param show_ts: If True, prefix each line with an ISO-8601 timestamp.
        """
        from flyte.remote._logs import _format_line

        details = await self.details()
        if not details.is_running and not details.done():
            await self.wait(wait_for="logs-ready")
            details = await self.details()
        if not attempt:
            attempt = details.attempts
        async for logline in Logs.tail.aio(action_id=self.action_id, attempt=attempt):
            formatted = _format_line(logline, show_ts=show_ts, filter_system=filter_system)
            if formatted is not None:
                yield formatted.plain

    async def details(self) -> ActionDetails:
        """
        Get the details of the action. This is a placeholder for getting the action details.
        """
        if not self._details:
            self._details = await ActionDetails.get_details.aio(self.action_id)
        return cast(ActionDetails, self._details)

    async def watch(
        self, cache_data_on_done: bool = False, wait_for: WaitFor = "terminal"
    ) -> AsyncGenerator[ActionDetails, None]:
        """
        Watch the action for updates, updating the internal Action state with latest details.

        This method updates both the cached details and the protobuf representation,
        ensuring that properties like `phase` reflect the current state.
        """
        ad = None
        async for ad in ActionDetails.watch.aio(self.action_id):
            if ad is None:
                return
            self._details = ad
            # Update the protobuf with the latest status and metadata
            self.pb2.status.CopyFrom(ad.pb2.status)
            self.pb2.metadata.CopyFrom(ad.pb2.metadata)
            yield ad
            if wait_for == "running" and ad.is_running:
                break
            elif wait_for == "logs-ready" and ad.logs_available():
                break
            if ad.done():
                break
        if cache_data_on_done and ad and ad.done():
            await cast(ActionDetails, self._details).outputs()

    async def wait(self, quiet: bool = False, wait_for: WaitFor = "terminal") -> None:
        """
        Wait for the run to complete, displaying a rich progress panel with status transitions,
        time elapsed, and error details in case of failure.
        """
        from flyte._status import get_output_mode, status

        if self.done():
            if not quiet:
                if get_output_mode() == "rich":
                    console = Console()
                    if self.pb2.status.phase == phase_pb2.ACTION_PHASE_SUCCEEDED:
                        console.print(
                            f"[bold green]Action '{self.name}' in Run '{self.run_name}'"
                            f" completed successfully.[/bold green]"
                        )
                    else:
                        details = await self.details()
                        error_message = details.error_info.message if details.error_info else ""
                        console.print(
                            f"[bold red]Action '{self.name}' in Run '{self.run_name}'"
                            f" exited unsuccessfully in state {self.phase} with error: {error_message}[/bold red]"
                        )
                else:
                    if self.pb2.status.phase == phase_pb2.ACTION_PHASE_SUCCEEDED:
                        status.success(f"Action '{self.name}' in Run '{self.run_name}' completed successfully")
                    else:
                        details = await self.details()
                        error_message = details.error_info.message if details.error_info else ""
                        status.warn(f"Action '{self.name}' in Run '{self.run_name}' failed: {error_message}")
            return

        try:
            if get_output_mode() == "rich":
                await self._wait_rich(quiet=quiet, wait_for=wait_for)
            else:
                await self._wait_plain(quiet=quiet, wait_for=wait_for)
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass

    async def _wait_rich(self, quiet: bool, wait_for: WaitFor) -> None:
        """Wait with Rich spinner (interactive/Jupyter)."""
        console = Console()
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=console,
            transient=True,
            disable=quiet,
        ) as progress:
            task_id = progress.add_task(f"Waiting for run '{self.name}'...", start=False)
            progress.start_task(task_id)

            async for ad in self.watch(cache_data_on_done=True, wait_for=wait_for):
                if ad is None:
                    progress.stop_task(task_id)
                    break

                if ad.is_running and wait_for == "running":
                    break

                if ad.logs_available() and wait_for == "logs-ready":
                    break

                progress.update(
                    task_id,
                    description=f"Run: {self.run_name} in {ad.phase}, Runtime: {ad.runtime} secs "
                    f"Attempts[{ad.attempts}]",
                )

                if ad.done():
                    progress.stop_task(task_id)
                    if not quiet:
                        self._report_done_rich(ad, console)
                    break

    async def _wait_plain(self, quiet: bool, wait_for: WaitFor) -> None:
        """Wait with plain status lines (CI/non-interactive)."""
        from flyte._status import status

        if not quiet:
            status.step(f"Waiting for run '{self.run_name}'...")

        last_phase = None
        async for ad in self.watch(cache_data_on_done=True, wait_for=wait_for):
            if ad is None:
                break

            if ad.is_running and wait_for == "running":
                if not quiet:
                    status.info(f"Run '{self.run_name}' is now running")
                break

            if ad.logs_available() and wait_for == "logs-ready":
                break

            if ad.phase != last_phase:
                last_phase = ad.phase
                if not quiet:
                    status.info(f"Run '{self.run_name}': {ad.phase} ({ad.runtime} secs, attempt {ad.attempts})")

            if ad.done():
                if not quiet:
                    self._report_done_plain(ad)
                break

    def _report_done_rich(self, ad: ActionDetails, console: Console) -> None:
        """Report terminal state with Rich formatting."""
        if ad.pb2.status.phase == phase_pb2.ACTION_PHASE_SUCCEEDED:
            console.print(f"[bold green]Run '{self.run_name}' completed successfully.[/bold green]")
        else:
            error_message = ad.error_info.message if ad.error_info else ""
            console.print(
                f"[bold red]Run '{self.run_name}' exited unsuccessfully in state {ad.phase}"
                f" with error: {error_message}[/bold red]"
            )

    def _report_done_plain(self, ad: ActionDetails) -> None:
        """Report terminal state with plain status lines."""
        from flyte._status import status

        if ad.pb2.status.phase == phase_pb2.ACTION_PHASE_SUCCEEDED:
            status.success(f"Run '{self.run_name}' completed successfully")
        else:
            error_message = ad.error_info.message if ad.error_info else ""
            status.warn(f"Run '{self.run_name}' failed in state {ad.phase}: {error_message}")

    def done(self) -> bool:
        """
        Check if the action is done.
        """
        return _action_done_check(self.raw_phase)

    async def sync(self) -> Action:
        """
        Sync the action with the remote server. This is a placeholder for syncing the action.
        """
        return self

    def __rich_repr__(self) -> rich.repr.Result:
        """
        Rich representation of the Action object.
        """
        yield from _action_rich_repr(self.pb2)
        if self._details:
            yield from self._details.__rich_repr__()

    def __repr__(self) -> str:
        """
        String representation of the Action object.
        """
        import rich.pretty

        return rich.pretty.pretty_repr(self)


@dataclass
class ActionDetails(ToJSONMixin):
    """
    A class representing an action. It is used to manage the run of a task and its state on the remote Union API.
    """

    pb2: run_definition_pb2.ActionDetails
    _inputs: ActionInputs | None = None
    _outputs: ActionOutputs | None = None
    _preserve_original_types: bool = False

    @syncify
    @classmethod
    async def get_details(cls, action_id: identifier_pb2.ActionIdentifier) -> ActionDetails:
        """
        Get the details of the action. This is a placeholder for getting the action details.
        """
        ensure_client()
        resp = await get_client().run_service.get_action_details(
            run_service_pb2.GetActionDetailsRequest(
                action_id=action_id,
            )
        )
        return ActionDetails(resp.details)

    @syncify
    @classmethod
    async def get(
        cls,
        uri: str | None = None,
        /,
        run_name: str | None = None,
        name: str | None = None,
    ) -> ActionDetails:
        """
        Get a run by its ID or name. If both are provided, the ID will take precedence.

        :param uri: The URI of the action.
        :param name: The name of the action.
        :param run_name: The name of the run.
        """
        ensure_client()
        if not uri:
            assert name is not None and run_name is not None, "Either uri or name and run_name must be provided"
        cfg = get_init_config()
        return await cls.get_details.aio(
            identifier_pb2.ActionIdentifier(
                run=identifier_pb2.RunIdentifier(
                    org=cfg.org,
                    project=cfg.project,
                    domain=cfg.domain,
                    name=run_name,
                ),
                name=name,
            ),
        )

    @syncify
    @classmethod
    async def watch(cls, action_id: identifier_pb2.ActionIdentifier) -> AsyncIterator[ActionDetails]:
        """
        Watch the action for updates. This is a placeholder for watching the action.
        """
        ensure_client()
        if not action_id:
            raise ValueError("Action ID is required")

        call = cast(
            AsyncIterator[WatchActionDetailsResponse],
            get_client().run_service.watch_action_details(
                request=run_service_pb2.WatchActionDetailsRequest(
                    action_id=action_id,
                )
            ),
        )
        try:
            async for resp in call:
                v = cls(resp.details)
                yield v
                if v.done():
                    return
        except ConnectError as e:
            if e.code == Code.CANCELED:
                pass
            else:
                raise e

    async def watch_updates(self, cache_data_on_done: bool = False) -> AsyncGenerator[ActionDetails, None]:
        """
        Watch for updates to the action details, yielding each update until the action is done.

        :param cache_data_on_done: If True, cache inputs and outputs when the action completes.
        """
        async for d in self.watch.aio(action_id=self.pb2.id):
            yield d
            if d.done():
                self.pb2 = d.pb2
                break

        if cache_data_on_done and self.done():
            await self._cache_data.aio()

    @property
    def phase(self) -> ActionPhase:
        """
        Get the phase of the action.

        Returns:
            The current execution phase as an ActionPhase enum
        """
        return ActionPhase.from_protobuf(self.status.phase)

    @property
    def raw_phase(self) -> phase_pb2.ActionPhase:
        """
        Get the raw phase of the action.
        """
        return self.status.phase

    @property
    def is_running(self) -> bool:
        """
        Check if the action is currently running.
        """
        return self.status.phase == phase_pb2.ACTION_PHASE_RUNNING

    @property
    def name(self) -> str:
        """
        Get the name of the action.
        """
        return self.action_id.name

    @property
    def run_name(self) -> str:
        """
        Get the name of the run.
        """
        return self.action_id.run.name

    @property
    def task_name(self) -> str | None:
        """
        Get the name of the task.
        """
        if self.pb2.metadata.HasField("task") and self.pb2.metadata.task.HasField("id"):
            return self.pb2.metadata.task.id.name
        return None

    @property
    def action_id(self) -> identifier_pb2.ActionIdentifier:
        """
        Get the action ID.
        """
        return self.pb2.id

    @property
    def metadata(self) -> run_definition_pb2.ActionMetadata:
        """
        Get the metadata of the action.
        """
        return self.pb2.metadata

    @property
    def status(self) -> run_definition_pb2.ActionStatus:
        """
        Get the status of the action.
        """
        return self.pb2.status

    @property
    def error_info(self) -> run_definition_pb2.ErrorInfo | None:
        """
        Get the error information if the action failed, otherwise returns None.
        """
        if self.pb2.HasField("error_info"):
            return self.pb2.error_info
        return None

    @property
    def abort_info(self) -> run_definition_pb2.AbortInfo | None:
        """
        Get the abort information if the action was aborted, otherwise returns None.
        """
        if self.pb2.HasField("abort_info"):
            return self.pb2.abort_info
        return None

    @property
    def runtime(self) -> timedelta:
        """
        Get the runtime of the action.
        """
        start_time = self.pb2.status.start_time.ToDatetime().replace(tzinfo=timezone.utc)
        if self.pb2.status.HasField("end_time"):
            end_time = self.pb2.status.end_time.ToDatetime().replace(tzinfo=timezone.utc)
            return end_time - start_time
        return datetime.now(timezone.utc) - start_time

    def get_phase_transitions(self, attempt: int | None = None) -> List[PhaseTransitionInfo]:
        """
        Get the phase transitions for a specific attempt, showing the granular breakdown
        of time spent in each phase (queued, initializing, running, etc.).

        Args:
            attempt: The attempt number (1-indexed). If None, uses the latest attempt.

        Returns:
            List of PhaseTransitionInfo objects, one for each phase the action went through.

        Example:
            >>> action = Action.get(run_name="my-run", name="my-action")
            >>> details = action.details()
            >>> transitions = details.get_phase_transitions()
            >>> for t in transitions:
            ...     print(f"{t.phase}: {t.duration.total_seconds()}s")
        """
        if attempt is None:
            attempt = self.pb2.status.attempts

        attempts = self.pb2.attempts
        if not attempts or len(attempts) < attempt:
            return []

        attempt_obj = attempts[attempt - 1]
        transitions = []

        for pt in attempt_obj.phase_transitions:
            start_time = pt.start_time.ToDatetime().replace(tzinfo=timezone.utc)
            end_time = pt.end_time.ToDatetime().replace(tzinfo=timezone.utc) if pt.HasField("end_time") else None

            transitions.append(
                PhaseTransitionInfo(
                    phase=ActionPhase.from_protobuf(pt.phase),
                    start_time=start_time,
                    end_time=end_time,
                )
            )

        return transitions

    @property
    def phase_durations(self) -> Dict[ActionPhase, timedelta]:
        """
        Get the duration spent in each phase as a dictionary.

        Returns a mapping of ActionPhase to timedelta for the latest attempt.
        This provides an easy way to see how long was spent queued, initializing, running, etc.

        Returns:
            Dictionary mapping ActionPhase enum values to timedelta durations.

        Example:
            >>> action = Action.get(run_name="my-run", name="my-action")
            >>> details = action.details()
            >>> durations = details.phase_durations
            >>> print(f"Queued: {durations.get(ActionPhase.QUEUED, timedelta(0)).total_seconds()}s")
            >>> print(f"Running: {durations.get(ActionPhase.RUNNING, timedelta(0)).total_seconds()}s")
        """
        transitions = self.get_phase_transitions()
        return {t.phase: t.duration for t in transitions}

    @property
    def queued_time(self) -> timedelta | None:
        """
        Get the time spent in the QUEUED phase for the latest attempt.

        Returns:
            timedelta if the action went through the QUEUED phase, None otherwise.
        """
        return self.phase_durations.get(ActionPhase.QUEUED)

    @property
    def waiting_for_resources_time(self) -> timedelta | None:
        """
        Get the time spent in the WAITING_FOR_RESOURCES phase for the latest attempt.

        Returns:
            timedelta if the action went through the WAITING_FOR_RESOURCES phase, None otherwise.
        """
        return self.phase_durations.get(ActionPhase.WAITING_FOR_RESOURCES)

    @property
    def initializing_time(self) -> timedelta | None:
        """
        Get the time spent in the INITIALIZING phase for the latest attempt.

        Returns:
            timedelta if the action went through the INITIALIZING phase, None otherwise.
        """
        return self.phase_durations.get(ActionPhase.INITIALIZING)

    @property
    def running_time(self) -> timedelta | None:
        """
        Get the time spent in the RUNNING phase for the latest attempt.

        Returns:
            timedelta if the action went through the RUNNING phase, None otherwise.
        """
        return self.phase_durations.get(ActionPhase.RUNNING)

    @property
    def attempts(self) -> int:
        """
        Get the number of attempts of the action.
        """
        return self.pb2.status.attempts

    def logs_available(self, attempt: int | None = None) -> bool:
        """
        Check if logs are available for the action, optionally for a specific attempt.
        If attempt is None, it checks for the latest attempt.
        """
        if attempt is None:
            attempt = self.pb2.status.attempts
        attempts = self.pb2.attempts
        if attempts and len(attempts) >= attempt:
            return attempts[attempt - 1].logs_available
        return False

    @syncify
    async def _cache_data(self) -> bool:
        """
        Cache the inputs and outputs of the action.
        :return: Returns True if Action is terminal and all data is cached else False.
        """
        from flyte._context import internal_ctx
        from flyte._internal.runtime import convert

        if self._inputs and self._outputs:
            return True
        if self._inputs and not self.done():
            return False
        resp = await get_client().run_service.get_action_data(
            request=run_service_pb2.GetActionDataRequest(
                action_id=self.pb2.id,
            )
        )

        with internal_ctx().new_preserve_original_types(self._preserve_original_types):
            native_iface = None
            if self.pb2.HasField("task"):
                iface = self.pb2.task.task_template.interface
                native_iface = types.guess_interface(iface)
            elif self.pb2.HasField("trace"):
                iface = self.pb2.trace.interface
                native_iface = types.guess_interface(iface)

            if resp.inputs:
                data_dict = (
                    await convert.convert_from_inputs_to_native(native_iface, convert.Inputs(resp.inputs))
                    if native_iface
                    else {}
                )
                self._inputs = ActionInputs(pb2=resp.inputs, data=data_dict)

            if resp.outputs:
                data_tuple = (
                    await convert.convert_outputs_to_native(native_iface, convert.Outputs(resp.outputs))
                    if native_iface
                    else ()
                )
                if not isinstance(data_tuple, tuple):
                    data_tuple = (data_tuple,)
                self._outputs = ActionOutputs(pb2=resp.outputs, data=data_tuple)

        return self._outputs is not None

    async def inputs(self) -> ActionInputs:
        """
        Return the inputs of the action.
        Will return instantly if inputs are available else will fetch and return.
        """
        if not self._inputs:
            await self._cache_data.aio()
        return cast(ActionInputs, self._inputs)

    async def outputs(self) -> ActionOutputs:
        """
        Returns the outputs of the action, returns instantly if outputs are already cached, else fetches them and
        returns. If Action is not in a terminal state, raise a RuntimeError.

        :return: ActionOutputs
        """
        if not self._outputs:
            if not await self._cache_data.aio():
                raise RuntimeError(
                    "Action is not in a terminal state, outputs are not available. "
                    "Please wait for the action to complete."
                )
        return cast(ActionOutputs, self._outputs)

    def done(self) -> bool:
        """
        Check if the action is in a terminal state (completed or failed). This is a placeholder for checking the
        action state.
        """
        return _action_done_check(self.raw_phase)

    def __rich_repr__(self) -> rich.repr.Result:
        """
        Rich representation of the Action object.
        """
        yield from _action_details_rich_repr(self.pb2)

        # Show phase breakdown if available
        transitions = self.get_phase_transitions()
        if transitions:
            phase_breakdown = {}
            for t in transitions:
                phase_breakdown[t.phase.value] = f"{t.duration.total_seconds():.2f}s"
            yield "phase_breakdown", phase_breakdown

    def __repr__(self) -> str:
        """
        String representation of the Action object.
        """
        import rich.pretty

        return rich.pretty.pretty_repr(self)


@dataclass
class ActionInputs(UserDict, ToJSONMixin):
    """
    A class representing the inputs of an action. It is used to manage the inputs of a task and its state on the
    remote Union API.

    ActionInputs extends from a `UserDict` and hence is accessible like a dictionary

    Example Usage:
    ```python
    action = Action.get(...)
    print(action.inputs())
    ```
    Output:
    ```bash
    {
      "x": ...,
      "y": ...,
    }
    ```
    """

    pb2: common_pb2.Inputs
    data: Dict[str, Any]

    def __repr__(self):
        import rich.pretty

        import flyte.types as types

        return rich.pretty.pretty_repr(types.literal_string_repr(self.pb2))


class ActionOutputs(tuple, ToJSONMixin):
    """
    A class representing the outputs of an action. The outputs are by default represented as a Tuple. To access them,
    you can simply read them as a tuple (assign to individual variables, use index to access) or you can use the
    property `named_outputs` to retrieve a dictionary of outputs with keys that represent output names
    which are usually auto-generated `o0, o1, o2, o3, ...`.

    Example Usage:
    ```python
    action = Action.get(...)
    print(action.outputs())
    ```
    Output:
    ```python
    ("val1", "val2", ...)
    ```
    OR
    ```python
    action = Action.get(...)
    print(action.outputs().named_outputs)
    ```
    Output:
    ```bash
    {"o0": "val1", "o1": "val2", ...}
    ```
    """

    pb2: common_pb2.Outputs
    _fields: list[str]

    def __new__(cls, pb2: common_pb2.Outputs, data: Tuple[Any, ...], fields: List[str] | None = None):
        # Create the tuple part
        obj = super().__new__(cls, data)
        # Store extra attributes on the tuple instance
        obj.pb2 = pb2
        obj._fields = fields or [default_output_name(i) for i in range(len(data))]
        for name, value in zip(obj._fields, obj):
            setattr(obj, name, value)
        return obj

    def __init__(self, pb2: common_pb2.Outputs, data: Tuple[Any, ...], fields: List[str] | None = None): ...

    @cached_property
    def named_outputs(self) -> dict[str, Any]:
        return dict(zip(self._fields, self))

    def __repr__(self) -> str:
        _repr = []
        for name, value in zip(self._fields, self):
            v = f'"{value}"' if isinstance(value, str) else f"{value}"
            _repr.append(f"{name}={v}")
        return f"ActionOutputs({', '.join(_repr)})"
