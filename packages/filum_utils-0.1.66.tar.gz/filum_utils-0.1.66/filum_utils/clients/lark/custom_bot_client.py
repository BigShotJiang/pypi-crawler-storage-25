import base64
import hashlib
import hmac
import logging
from json import JSONDecodeError

import requests

from filum_utils import DateTimeFormatter
from filum_utils.clients.lark.errors import LarkCustomBotError
from filum_utils.config import config
from filum_utils.errors import ErrorMessage


class LarkCustomBotClient:
    def __init__(self):
        self._base_url = config.LARK_CUSTOM_BOT_WEBHOOK_URL
        self._signature = config.LARK_CUSTOM_BOT_SIGNATURE

    def send_text_message(self, message_text):
        self._request(
            method="POST", data={"msg_type": "text", "content": {"text": message_text}}
        )

    def _request(self, method: str, data=None, params=None):
        current_timestamp = DateTimeFormatter.get_current_datetime().timestamp()
        current_timestamp = int(current_timestamp)
        signature = self._generate_signature(current_timestamp)
        request_data = {
            "timestamp": f"{current_timestamp}",
            "sign": signature,
        }

        if data:
            request_data.update(data)

        response = requests.request(
            method=method,
            url=self._base_url,
            json=request_data,
            params=params,
        )

        response_code = response.status_code
        response_data = {}
        try:
            response_data = response.json() if response_code != 204 else {}
        except JSONDecodeError:
            response_data = {}

        status_code = response_data.get("code")
        if status_code or response_code >= 300:
            error_message = (
                response_data.get("msg") or ErrorMessage.LARK_CUSTOM_BOT_SERVICE_ERROR
            )
            logging.error(
                f"{self.__class__} error: {response.status_code} - {response.content}"
            )
            raise LarkCustomBotError(
                error_message=error_message,
                error_code=status_code or response_code,
                data={
                    "method": method,
                    "params": params,
                    "status_code": status_code or response_code,
                    "content": str(response.content),
                },
            )

        return response_data

    def _generate_signature(self, current_timestamp: int) -> str:
        # Splicing timestamp and secret
        string_to_sign = "{}\n{}".format(current_timestamp, self._signature)
        hmac_code = hmac.new(
            string_to_sign.encode("utf-8"), digestmod=hashlib.sha256
        ).digest()
        # Perform base64 processing on the result
        return base64.b64encode(hmac_code).decode("utf-8")
