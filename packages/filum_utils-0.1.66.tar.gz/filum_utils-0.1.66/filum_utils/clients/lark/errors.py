from typing import Any, Dict

from filum_utils.errors import BaseError, ErrorType


class LarkCustomBotError(BaseError):
    def __init__(
        self,
        error_code: int,
        error_message: str,
        data: Dict[str, Any] = None,
    ):
        super().__init__(
            error_code=error_code,
            message=error_message,
            data=data,
            error_type=ErrorType.EXTERNAL,
        )
