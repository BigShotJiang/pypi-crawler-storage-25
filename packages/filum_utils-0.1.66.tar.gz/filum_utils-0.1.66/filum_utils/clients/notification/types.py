from typing import Dict, TypedDict


class Route(TypedDict):
    path: str
    params: Dict[str, str]
