from filum_utils.enums import BaseEnum


class PublisherType(BaseEnum):
    DATA_CONNECTION = "Data Connection"
    VoC = "Voice of the Customer"
    AUTOMATED_ACTION = "Automated Action"


class RoutePath(BaseEnum):
    CONNECTIONS_DETAIL = "connectionsDetail"
    AUTOMATED_ACTIONS_DETAIL = "automatedActionsDetail"
    CAMPAIGNS_DETAIL = "listeningCampaignDetails"
    ENGAGEMENT_CAMPAIGNS_DETAIL = "engagementCampaignDetails"


class ErrorType:
    INTERNAL = "internal"
    EXTERNAL = "external"


class NotificationErrorMessage:
    INTERNAL = "Internal system error, please contact Filum for support"
    EXTERNAL = "Partner error, please contact Filum for support"


class ToolLogTypeEnum:
    INFO = "info"


class ToolLogCodeEnum:
    EXECUTE = "execute"


class ToolLogActionEnum:
    EXECUTE = "execute"


NOTIFICATION_ERROR_MESSAGE_MAPPINGS = {
    ErrorType.INTERNAL: NotificationErrorMessage.INTERNAL,
    ErrorType.EXTERNAL: NotificationErrorMessage.EXTERNAL,
}
