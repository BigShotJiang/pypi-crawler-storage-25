PROPERTY_PLACEHOLDER_REGEX = r"\{{[^{}]*\}}"
TRANSLATION_FORMAT_REGEX = r"question.[\d].option.[\d]"


class BaseEnum:
    @classmethod
    def get_list(cls):
        return [getattr(cls, attr) for attr in dir(cls) if attr.isupper()]


class ObjectName(BaseEnum):
    SEGMENT = "Segment"
    EVENT = "Event"
    CAMPAIGN = "Campaign"
    USER = "User"
    SURVEY_RESPONSE = "Response"
    CONVERSATION = "Conversation"


class VariableProperty:
    ID = "ID"
    LINK = "Link"
    USER_PHONE = "Phone"
    USER_EMAIL = "Email"
    RATING = "Rating"
    TEXT = "Text"
    USER = "User"
    NAME = "Name"
    SIZE = "Size"
    METRIC_TYPE = "Metric_Type"


class UserProperty:
    ID = "User ID"
    NAME = "Name"
    EMAIL = "Email"
    PHONE = "Phone"


class SurveyAnsweredEventProperty:
    USER_EMAIL = "User Email"
    USER_PHONE = "User Phone"
    SURVEY_RESPONSE_ID = "Survey Response ID"
    RATING = "Rating"
    METRIC_TYPE = "Metric Type"
    TEXT = "Follow Up Text"
    SURVEY_ID = "Survey ID"
    EVENT_NAME = "Event Name"
    REVIEW_KEY = "_keys"
    LOCATION_ID = "Location ID"


class ConversationProperty:
    ID = "ID"


class SurveyResponseProperty:
    ID = "ID"


class CampaignProperty:
    ID = "ID"
    NAME = "Name"


class SegmentProperty:
    ID = "id"
    NAME = "name"
    TOTAL_USERS = "total_users"


class FilumTrackEventProperty:
    EVENT_NAME = "Event Name"
    TIMESTAMP = "Timestamp"
    USER_ID = "User ID"
    USER_NAME = "User Name"
    USER_PHONE = "User Phone"
    USER_EMAIL = "User Email"
    CAMPAIGN_ID = "Campaign ID"
    CAMPAIGN_NAME = "Campaign Name"
    SURVEY_RESPONSE_ID = "Survey Response ID"
    CONVERSATION_ID = "Conversation ID"
    SURVEY_ID = "Survey ID"
    FOLLOW_UP_TEXT = "Follow Up Text"


class FilumEventName:
    SURVEY_ANSWERED = "Survey Answered"
    CALL_CREATED = "Call Created"
    COMMENT_CREATED = "Comment Created"
    EMAIL_RECEIVED = "Email Received"

    @classmethod
    def get_conversation_event_names(cls) -> list:
        return [cls.CALL_CREATED, cls.COMMENT_CREATED, cls.EMAIL_RECEIVED]


EVENT_USER_PROPERTY_MAPPINGS = {
    FilumTrackEventProperty.USER_ID: UserProperty.ID,
    FilumTrackEventProperty.USER_NAME: UserProperty.NAME,
    FilumTrackEventProperty.USER_PHONE: UserProperty.PHONE,
    FilumTrackEventProperty.USER_EMAIL: UserProperty.EMAIL,
}

EVENT_CAMPAIGN_PROPERTY_MAPPINGS = {
    FilumTrackEventProperty.CAMPAIGN_ID: CampaignProperty.ID,
    FilumTrackEventProperty.CAMPAIGN_NAME: CampaignProperty.NAME,
}
