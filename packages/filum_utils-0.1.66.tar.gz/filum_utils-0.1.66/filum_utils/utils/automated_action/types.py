from typing import Any, Dict

from typing_extensions import TypedDict


class PopulateDataParams(TypedDict):
    event: Dict[str, Any]
    user: Dict[str, Any]
    campaign: Dict[str, Any]
    survey_response: Dict[str, Any]
    conversation: Dict[str, Any]
    platform_url: str
    action: Dict[str, Any]
