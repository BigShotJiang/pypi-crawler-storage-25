"""Tests for the `agentberlin workflow` CLI subcommand group.

Covers manifest-shape validation and URL routing. HTTP calls are stubbed via
the `responses` library so tests don't hit a real backend.
"""

import json
from pathlib import Path
from typing import Any

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _write_manifest(tmp_path: Path, data: dict[str, Any], name: str = "manifest.json") -> Path:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return path


def _read_manifest(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


# ---------------------------------------------------------------------------
# workflow create
# ---------------------------------------------------------------------------


class TestWorkflowCreate:
    @responses.activate
    def test_plan_only_create_writes_id_back(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "name": "Weekly Rank Tracking",
                "details": "Query GSC weekly and flag drops.",
                "schedule": {"type": "cron", "cron_expression": "0 9 * * 1", "timezone": "UTC"},
            },
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows",
            json={"success": True, "workflow_id": "wfl_123", "name": "Weekly Rank Tracking", "phase": "pre_planning"},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_123" in result.output
        assert _read_manifest(manifest)["id"] == "wfl_123"

        body = json.loads(responses.calls[0].request.body)
        assert body["details"] == "Query GSC weekly and flag drops."
        assert body["schedule"]["type"] == "cron"

    def test_rejects_manifest_with_id(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"name": "Existing", "id": "wfl_abc", "details": "irrelevant"}
        )
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "already has an 'id'" in result.output

    def test_rejects_manifest_without_name(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "name" in result.output.lower()


# ---------------------------------------------------------------------------
# workflow update
# ---------------------------------------------------------------------------


class TestWorkflowUpdate:
    @responses.activate
    def test_update_patches_metadata(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "id": "wfl_abc",
                "name": "Edited Name",
                "description": "new desc",
                "details": "revised spec",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/workflows/wfl_abc",
            json={"success": True, "workflow_id": "wfl_abc", "name": "Edited Name", "phase": "pre_planning"},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "update", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_abc" in result.output
        body = json.loads(responses.calls[0].request.body)
        assert body["name"] == "Edited Name"
        assert body["description"] == "new desc"
        assert body["details"] == "revised spec"

    def test_rejects_manifest_without_id(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"name": "X", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "update", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "id" in result.output.lower()
