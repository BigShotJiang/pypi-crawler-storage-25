"""Settings module."""
