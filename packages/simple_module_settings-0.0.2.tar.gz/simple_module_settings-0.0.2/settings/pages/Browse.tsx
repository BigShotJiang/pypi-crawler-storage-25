import { router } from '@inertiajs/react';
import { keys, useT } from '@simple-module-py/i18n';
import { AuthenticatedLayout } from '@simple-module-py/ui/layouts/AuthenticatedLayout';
import type React from 'react';
import type { ValueType } from './components/ValueInput';
import { ROUTES } from './routes';

type Scope = 'system' | 'tenant' | 'user';

type Setting = {
  id: number;
  scope: Scope;
  scope_id: string;
  key: string;
  value: string;
  value_type: ValueType;
  description: string | null;
};

type Props = { settings: Setting[] };

function Browse({ settings }: Props) {
  const { t } = useT();

  function handleDelete(setting: Setting) {
    if (!window.confirm(t(keys.settings.browse.delete_confirm, { key: setting.key }))) return;
    router.delete(ROUTES.byId(setting.id));
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">{t(keys.settings.browse.title)}</h1>
        <div className="flex items-center gap-3">
          <a href={ROUTES.modules} className="text-sm text-primary hover:underline">
            {t(keys.settings.modules.browse_link)}
          </a>
          <a
            href={ROUTES.create}
            className="rounded bg-primary px-3 py-1.5 text-primary-foreground"
          >
            {t(keys.settings.browse.new_button)}
          </a>
        </div>
      </div>
      {settings.length === 0 ? (
        <div className="py-12 text-center">
          <h2 className="text-lg font-medium">{t(keys.settings.browse.empty_title)}</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {t(keys.settings.browse.empty_description)}
          </p>
        </div>
      ) : (
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b">
              <th className="py-2 pr-4">{t(keys.settings.table.scope)}</th>
              <th className="py-2 pr-4">{t(keys.settings.table.scope_id)}</th>
              <th className="py-2 pr-4">{t(keys.settings.table.key)}</th>
              <th className="py-2 pr-4">{t(keys.settings.table.value_type)}</th>
              <th className="py-2 pr-4">{t(keys.settings.table.value)}</th>
              <th className="py-2 pr-4">{t(keys.settings.table.description)}</th>
              <th className="py-2">{t(keys.settings.table.actions)}</th>
            </tr>
          </thead>
          <tbody>
            {settings.map((setting) => (
              <tr key={setting.id} className="border-b">
                <td className="py-2 pr-4">{t(keys.settings.scopes[setting.scope])}</td>
                <td className="py-2 pr-4 font-mono text-sm text-muted-foreground">
                  {setting.scope_id || '—'}
                </td>
                <td className="py-2 pr-4 font-mono text-sm">{setting.key}</td>
                <td className="py-2 pr-4 text-xs uppercase text-muted-foreground">
                  {t(keys.settings.value_types[setting.value_type])}
                </td>
                <td className="py-2 pr-4 font-mono text-sm">{setting.value}</td>
                <td className="py-2 pr-4 text-muted-foreground">{setting.description ?? ''}</td>
                <td className="py-2">
                  <div className="flex gap-3">
                    <a href={ROUTES.edit(setting.id)} className="text-primary hover:underline">
                      {t(keys.settings.browse.edit_link)}
                    </a>
                    <button
                      type="button"
                      onClick={() => handleDelete(setting)}
                      className="text-destructive hover:underline"
                    >
                      {t(keys.settings.browse.delete_link)}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

Browse.layout = (page: React.ReactNode) => <AuthenticatedLayout>{page}</AuthenticatedLayout>;
export default Browse;
