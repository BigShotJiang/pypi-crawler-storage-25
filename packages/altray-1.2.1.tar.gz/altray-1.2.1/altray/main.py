from datetime import datetime as dt
import tkinter as tk
import random as rd
import time as t

# Basic Functions

def hello():
    print("Hello World!")

def greet(name):
    print(f"Hello {name}!")

def raw_print(text):
    print(text, end='')

class animal:

    def cat(self):
        print("Meow!")

    def dog(self):
        print("Arf!")

    def bird(self):
        print("Chirp!")

# Calendar Functions

def date():
    print(dt.now().strftime("%d-%m-%Y"))

def time():
    print(dt.now().strftime("%H:%M:%S"))

# Utility Functions

def bang():
    print("* ", end="")

def bar(length):
    print("=" * length)

def window(height, length, name):
    win = tk.Tk()
    win.geometry(f"{length}x{height}")
    win.title(name)
    win.resizable(False, False)
    win.mainloop()

def dice_roll():
    print(rd.randint(1, 6))

def coin_flip():
    print(rd.choice(["Heads", "Tails"]))

def timer(seconds):
    while seconds > 0:
        t.sleep(1)
        seconds -= 1

def reverse_text(text):
    return text[::-1]

def is_even(number):
    return number % 2 == 0

# Shape Functions

class shape:

    def triangle(self, height):
        n = height
        for i in range(1, n + 1):
            print(' ' * (n - i) + '* ' * i)
    
    def inverted_triangle(self, size):
        for i in range(size - 1, 0, -1):
            print(" " * (size - i) + "* " * i)
    
    def right_triangle(self, rows):
        for i in range(1, rows + 1):
            print("* " * i)

    def inverted_right_triangle(self, rows):
        for i in range(rows, 0, -1):
            print("* " * i)
    
    def left_triangle(self, num):
        for i in range(1, num + 1):
            print("  " * (num - i) + "* " * i)
    
    def inverted_left_triangle(self, num):
        for i in range(num, 0, -1):
            print("  " * (num - i) + "* " * i)
    
    def diamond(self, num):
        # Top half
        for i in range(1, num + 1):
            print(" " * (num - i) + "* " * i)

        # Bottom half
        for i in range(num - 1, 0, -1):
            print(" " * (num - i) + "* " * i)

    def square(self, num):
        for i in range(num):
            print("* " * num)

    def rectangle(self, height, length):
        for i in range(height):
            for j in range(length):
                print("* ", end='')
            print()
    
    def circle(self):
        print("O")

    def heart(self):
        print("<3")
