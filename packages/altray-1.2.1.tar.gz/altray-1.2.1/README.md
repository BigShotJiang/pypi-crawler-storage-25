# Altray Python Library

Altray is a simple Python utility library made for learning and building small projects. It includes basic tools for text, math, games, patterns, and simple GUI windows.

---

# Installation

**`pip install altray`**

---

# New Features

- Added clearer functions for the shapes.

---

# Notes

- Some functions print output directly  
- Some functions return values for reuse  
- Requires Python 3.8+  

---

All Rights Reserved 2026