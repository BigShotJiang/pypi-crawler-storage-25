from setuptools import setup, find_packages

with open("README.md", "r") as f:
    description = f.read()

setup(
    name="altray",
    version="1.2.1",
    author="Pizeltray Studios",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        # No Requirements
    ],
    entry_points={
        "console_scripts":[
            "altray-hello = altray:hello",
        ],
    },
    long_description=description,
    long_description_content_type="text/markdown",
)