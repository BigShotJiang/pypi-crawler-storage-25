# ARAHIN — AI Route Planning Agent

**Spatial-RAG + TSP + Interactive CLI**

ARAHIN is an AI agent that plans multi-stop routes from natural language descriptions. It uses a ReAct loop with dynamic spatial retrieval (Overpass + on-the-fly embeddings) and OR-Tools TSP optimization to find and order waypoints, rendered as an interactive Folium map.

## Install

```bash
pip install git+https://github.com/syawalqi/arahin.git
```

This installs the `arahin` command globally and all dependencies (openai, requests, ortools, folium, rich).

## Quick Start

```bash
export ARAHIN_API_KEY="sk-..."
arahin "dari Monas ke Taman Mini, mampir sate dekat Cawang"
```

```bash
# Interactive REPL
arahin

# One-shot
arahin "cari masjid terdekat dari UI Depok" --map

# With directions
arahin "jalan-jalan di Kota Tua" --map --directions
```

## Commands

| Command | Action |
|---------|--------|
| `/api [key]` | Set API key (session only) |
| `/model [n]` | Switch model |
| `/map` | Open route map in browser |
| `/dir` | Print turn-by-turn |
| `/config` | Show settings |
| `/help` | Show help |
| `/exit` | Quit |

## Project Structure

```
arahin/
├── cli.py              # Entry point + REPL + 7 commands
├── banner.py           # Splash screen
├── state.py            # Session state
├── agent/
│   ├── controller.py   # ReAct loop
│   └── prompts.py      # Tool schemas + system prompt
├── tools/
│   ├── geocode.py      # Nominatim
│   ├── poi_search.py   # Overpass by category
│   ├── spatial_rag.py  # Dynamic semantic search
│   ├── route.py        # OSRM driving
│   ├── optimizer.py    # TSP solver
│   └── render_map.py   # Folium map
└── evaluation/
    ├── metrics.py      # Precision/Recall/F1/Kendall Tau
    └── run_benchmark.py
```
