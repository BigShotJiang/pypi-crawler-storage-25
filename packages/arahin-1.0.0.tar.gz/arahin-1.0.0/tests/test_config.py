"""Tests for config/env var handling."""

import os

from arahin.state import SessionState


class TestEnvConfig:
    def test_env_var_api_key(self, monkeypatch):
        monkeypatch.setenv("ARAHIN_API_KEY", "sk-test-key")
        s = SessionState()
        if not s.api_key:
            s.api_key = os.environ.get("ARAHIN_API_KEY", "")
        assert s.api_key == "sk-test-key"

    def test_opencode_fallback(self, monkeypatch):
        monkeypatch.delenv("ARAHIN_API_KEY", raising=False)
        monkeypatch.setenv("OPENCODE_API_KEY", "sk-opencode")
        s = SessionState()
        if not s.api_key:
            s.api_key = os.environ.get("ARAHIN_API_KEY", "")
        if not s.api_key:
            s.api_key = os.environ.get("OPENCODE_API_KEY", "")
        assert s.api_key == "sk-opencode"

    def test_env_var_precedence(self, monkeypatch):
        monkeypatch.setenv("ARAHIN_API_KEY", "sk-primary")
        monkeypatch.setenv("OPENCODE_API_KEY", "sk-fallback")
        s = SessionState()
        if not s.api_key:
            s.api_key = os.environ.get("ARAHIN_API_KEY", "")
        assert s.api_key == "sk-primary"

    def test_empty_if_no_env(self, monkeypatch):
        monkeypatch.delenv("ARAHIN_API_KEY", raising=False)
        monkeypatch.delenv("OPENCODE_API_KEY", raising=False)
        s = SessionState()
        assert s.api_key == ""
