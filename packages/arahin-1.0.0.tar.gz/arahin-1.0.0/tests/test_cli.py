"""Tests for CLI argument parsing."""

from arahin.cli import parse_args


class TestArgParse:
    def test_no_args_repl_mode(self):
        args = parse_args([])
        assert args.query is None

    def test_query_arg_non_interactive(self):
        args = parse_args(["cari masjid dekat UI"])
        assert args.query == "cari masjid dekat UI"

    def test_map_flag(self):
        args = parse_args(["test", "--map"])
        assert args.map is True

    def test_directions_flag(self):
        args = parse_args(["test", "--directions"])
        assert args.directions is True

    def test_short_flags(self):
        args = parse_args(["test", "-m", "-d"])
        assert args.map is True
        assert args.directions is True
