"""Tests for SessionState singleton and helpers."""

from arahin.state import SessionState, get_state, reset_route_state


class TestSessionState:
    def test_defaults(self):
        s = SessionState()
        assert s.model == "deepseek-v4-flash"
        assert s.api_key == ""
        assert s.last_waypoints == []
        assert s.last_map_path is None

    def test_api_status_not_set(self):
        s = SessionState()
        assert "not set" in s.api_status

    def test_api_status_masked(self):
        s = SessionState()
        s.api_key = "sk-" + "a" * 40 + "-xxxx"
        assert "sk-a" in s.api_status
        assert "xxxx" in s.api_status

    def test_singleton(self):
        s1 = get_state()
        s2 = get_state()
        assert s1 is s2

    def test_reset_route_preserves_settings(self):
        s = get_state()
        s.last_waypoints = [{"name": "test"}]
        s.last_map_path = "/tmp/map.html"
        s.model = "gpt-4o"
        reset_route_state()
        assert s.last_waypoints == []
        assert s.last_map_path is None
        assert s.model == "gpt-4o"
