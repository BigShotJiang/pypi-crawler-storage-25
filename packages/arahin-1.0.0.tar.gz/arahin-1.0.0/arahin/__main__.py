"""python -m arahin entry point."""

from .cli import main

main()
