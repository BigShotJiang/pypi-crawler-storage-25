"""POI search — Overpass API by amenity category. Any city."""

from __future__ import annotations

import requests


def poi_search(category: str, lat: float, lng: float, radius: int = 3) -> list[dict]:
    """Search POIs by OSM amenity tag near coordinates.

    POST required — GET returns HTTP 406 from overpass-api.de.
    Works for any city with OSM data.
    """
    query = (
        f"[out:json][timeout:25];"
        f'node["amenity"="{category}"](around:{radius * 1000},{lat},{lng});'
        f"out 5;"
    )

    resp = requests.post(
        "https://overpass-api.de/api/interpreter",
        data={"data": query},
        headers={
            "User-Agent": "ARAHIN/1.0",
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
        },
        timeout=30,
    )

    if resp.status_code != 200:
        return []

    return [
        {
            "name": el.get("tags", {}).get("name", "unnamed"),
            "lat": el["lat"],
            "lng": el["lon"],
            "category": el.get("tags", {}).get("amenity", category),
        }
        for el in resp.json().get("elements", [])
    ]
