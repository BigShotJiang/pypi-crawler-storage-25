"""Spatial retrieval: Overpass query → return nearby POIs.

No embeddings. No ML. The LLM in the ReAct loop handles semantic matching
when it reads the tool results.
"""

from __future__ import annotations

from typing import Any

import requests


def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in km between two coordinates."""
    import math
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(math.radians(lat1))
        * math.cos(math.radians(lat2))
        * math.sin(dlon / 2) ** 2
    )
    return 6371 * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def spatial_rag(
    query: str,
    lat: float,
    lng: float,
    radius: float = 5,
    top_k: int = 10,
) -> list[dict[str, Any]]:
    """Return nearby POIs from Overpass within radius.

    Returns POI name, location, category, and distance. The LLM in the
    ReAct loop uses its own semantic understanding to pick relevant results.
    """
    overpass_query = (
        f'[out:json][timeout:25];'
        f'node["amenity"](around:{radius * 1000},{lat},{lng});'
        f"out body 50;"
    )

    try:
        resp = requests.post(
            "https://overpass-api.de/api/interpreter",
            data={"data": overpass_query},
            headers={
                "User-Agent": "ARAHIN/1.0",
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
            },
            timeout=30,
        )
    except requests.RequestException:
        return []

    if resp.status_code != 200:
        return []

    elements = resp.json().get("elements", [])
    if not elements:
        return []

    results: list[dict[str, Any]] = []
    for el in elements:
        tags = el.get("tags", {})
        name = tags.get("name", "")
        if not name:
            continue
        dist = _haversine(lat, lng, el["lat"], el["lon"])
        if dist > radius:
            continue
        results.append({
            "name": name,
            "lat": el["lat"],
            "lng": el["lon"],
            "category": tags.get("amenity", "unknown"),
            "dist_km": round(dist, 1),
        })

    results.sort(key=lambda x: x["dist_km"])
    return results[:top_k]
