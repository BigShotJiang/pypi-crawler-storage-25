"""Map visualization — Folium interactive Leaflet HTML map."""

from __future__ import annotations

import os
from typing import Any

import folium


def render_route_html(
    waypoints: list[dict[str, Any]],
    route_details: list[dict[str, Any]] | None = None,
    output_path: str = "route.html",
) -> str:
    """Generate interactive Leaflet map with markers and polylines.

    Returns absolute path to the generated HTML file.
    """
    if not waypoints:
        raise ValueError("At least one waypoint is required.")

    center = waypoints[0]
    m = folium.Map(
        location=[center["lat"], center["lng"]],
        zoom_start=13,
        tiles="OpenStreetMap",
    )

    # Numbered markers: green (start), blue (mid), red (end)
    for i, wp in enumerate(waypoints):
        if i == 0:
            color, icon = "green", "play"
        elif i == len(waypoints) - 1:
            color, icon = "red", "stop"
        else:
            color, icon = "blue", "info-sign"

        folium.Marker(
            [wp["lat"], wp["lng"]],
            popup=f"<b>{i + 1}. {wp['name']}</b>",
            icon=folium.Icon(color=color, icon=icon),
        ).add_to(m)

    # Road-following polylines + distance labels
    if route_details:
        for i, seg in enumerate(route_details):
            if not seg or "geometry" not in seg:
                continue

            coords = [(c[1], c[0]) for c in seg["geometry"]["coordinates"]]
            folium.PolyLine(
                coords,
                color="#2196F3",
                weight=5,
                popup=f"{seg['distance_km']} km · {seg['duration_min']} min",
            ).add_to(m)

            # Distance label at segment midpoint
            mid_lat = sum(c[0] for c in coords) / len(coords)
            mid_lng = sum(c[1] for c in coords) / len(coords)
            folium.Marker(
                [mid_lat, mid_lng],
                icon=folium.DivIcon(
                    html=(
                        f'<div style="background:white;padding:2px 6px;'
                        f'border-radius:4px;font-size:11px;border:1px solid #ccc">'
                        f'{seg["distance_km"]} km</div>'
                    )
                ),
            ).add_to(m)
    else:
        # Fallback: straight lines between waypoints
        coords = [(w["lat"], w["lng"]) for w in waypoints]
        folium.PolyLine(coords, color="#2196F3", weight=3).add_to(m)

    m.fit_bounds(
        [(w["lat"], w["lng"]) for w in waypoints],
        padding=(50, 50),
    )
    m.save(output_path)
    return os.path.abspath(output_path)


def render_turn_by_turn(route_details: list[dict[str, Any]]) -> str:
    """Format OSRM step instructions as readable text."""
    lines: list[str] = []
    for i, seg in enumerate(route_details):
        if not seg:
            continue
        lines.append(f"\n{'=' * 40}")
        lines.append(
            f"Segment {i + 1}: {seg['distance_km']} km · "
            f"~{seg['duration_min']} min"
        )
        lines.append("-" * 40)
        total_dist = 0
        for step in seg.get("steps", []):
            if step["distance_m"] > 50 and step["instruction"]:
                km = step["distance_m"] / 1000
                total_dist += step["distance_m"]
                lines.append(f"  {step['instruction']}  ({km:.1f} km)")
        lines.append(f"  → Total: {total_dist / 1000:.1f} km")

    return "\n".join(lines)
