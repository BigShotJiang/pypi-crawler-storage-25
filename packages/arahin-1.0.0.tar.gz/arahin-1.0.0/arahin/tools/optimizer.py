"""Route optimizer — TSP solver for open/closed paths."""

from __future__ import annotations

import itertools
from typing import Any

from .route import get_distance_matrix


def solve_tsp(
    distance_matrix: list[list[float]],
    start_idx: int = 0,
    end_idx: int | None = None,
) -> tuple[list[int] | None, int | None]:
    """TSP solver.

    - Closed tour by default (return to start).
    - If end_idx is set, finds optimal open path: start → ... → end.
    - Brute-force for n <= 10 (optimal, instant).
    - OR-Tools for n > 10.
    """
    n = len(distance_matrix)

    if n <= 2:
        return [start_idx] if start_idx < n else [0], 0

    # Open path
    if end_idx is not None:
        mid = [i for i in range(n) if i not in (start_idx, end_idx)]
        best_order: list[int] | None = None
        best_cost = float("inf")
        for perm in itertools.permutations(mid):
            order = [start_idx] + list(perm) + [end_idx]
            cost = sum(
                distance_matrix[order[i]][order[i + 1]]
                for i in range(n - 1)
            )
            if cost < best_cost:
                best_cost = cost
                best_order = order
        return best_order, int(best_cost)

    # Closed tour — brute force for n <= 10
    if n <= 10:
        mid = [i for i in range(n) if i != start_idx]
        best_order = None
        best_cost = float("inf")
        for perm in itertools.permutations(mid):
            order = [start_idx] + list(perm)
            cost = sum(
                distance_matrix[order[i]][order[i + 1]]
                for i in range(n - 1)
            )
            if cost < best_cost:
                best_cost = cost
                best_order = order
        return best_order, int(best_cost)

    # Closed tour — OR-Tools for n > 10
    from ortools.constraint_solver import (  # type: ignore[import-untyped]
        routing_enums_pb2,
        pywrapcp,
    )
    manager = pywrapcp.RoutingIndexManager(n, 1, start_idx)
    routing = pywrapcp.RoutingModel(manager)

    def callback(from_i: int, to_i: int) -> int:
        return int(
            distance_matrix[manager.IndexToNode(from_i)][
                manager.IndexToNode(to_i)
            ]
        )

    transit_cb = routing.RegisterTransitCallback(callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_cb)

    params = pywrapcp.DefaultRoutingSearchParameters()
    params.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    )
    solution = routing.SolveWithParameters(params)

    if not solution:
        return None, None

    order: list[int] = []
    total = 0
    idx = routing.Start(0)
    while not routing.IsEnd(idx):
        order.append(manager.IndexToNode(idx))
        prev = idx
        idx = solution.Value(routing.NextVar(idx))
        total += routing.GetArcCostForVehicle(prev, idx, 0)

    return order, int(total)


def optimize_route(
    waypoints: list[dict[str, Any]],
    start_name: str | None = None,
    end_name: str | None = None,
) -> tuple[list[dict[str, Any]], int]:
    """Get distance matrix → solve TSP → return ordered waypoints."""
    n = len(waypoints)
    if n <= 1:
        return waypoints, 0

    start_idx = 0
    end_idx: int | None = None

    if start_name:
        matched = [
            i for i, w in enumerate(waypoints)
            if w["name"].lower() == start_name.lower()
        ]
        if matched:
            start_idx = matched[0]

    if end_name:
        matched = [
            i for i, w in enumerate(waypoints)
            if w["name"].lower() == end_name.lower()
        ]
        if matched:
            end_idx = matched[0]

    matrix = get_distance_matrix(waypoints)
    if not matrix:
        return waypoints, 0

    order, total = solve_tsp(matrix["durations"], start_idx, end_idx)
    if order is None:
        return waypoints, 0

    return [waypoints[i] for i in order], total
