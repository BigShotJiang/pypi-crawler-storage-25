"""Route query — OSRM driving directions + distance matrix."""

from __future__ import annotations

import requests


def get_route(origin: dict, destination: dict) -> dict | None:
    """Get driving route between two waypoints.

    Returns distance, duration, road geometry (GeoJSON), and
    turn-by-turn steps.
    """
    src = f"{origin['lng']},{origin['lat']}"
    dst = f"{destination['lng']},{destination['lat']}"

    try:
        resp = requests.get(
            f"https://router.project-osrm.org/route/v1/driving/{src};{dst}",
            params={
                "overview": "full",
                "geometries": "geojson",
                "steps": "true",
                "alternatives": "false",
            },
            timeout=15,
        )
    except requests.RequestException:
        return None

    if resp.status_code != 200:
        return None

    data = resp.json()
    if data["code"] != "Ok":
        return None

    route = data["routes"][0]
    leg = route["legs"][0]

    return {
        "distance_km": round(route["distance"] / 1000, 1),
        "duration_min": round(route["duration"] / 60, 1),
        "geometry": route["geometry"],  # GeoJSON LineString
        "steps": [
            {"instruction": s.get("name", ""), "distance_m": s["distance"]}
            for s in leg["steps"]
            if s.get("name")
        ],
        "summary": leg.get("summary", ""),
    }


def get_distance_matrix(waypoints: list[dict]) -> dict | None:
    """Get OSRM distance/duration matrix for all waypoint pairs."""
    coords = ";".join(f"{w['lng']},{w['lat']}" for w in waypoints)

    try:
        resp = requests.get(
            f"https://router.project-osrm.org/table/v1/driving/{coords}",
            params={"annotations": "distance,duration"},
            timeout=30,
        )
    except requests.RequestException:
        return None

    if resp.status_code != 200:
        return None

    data = resp.json()
    if data["code"] != "Ok":
        return None

    return {
        "durations": data["durations"],  # seconds
        "distances": data["distances"],  # meters
    }
