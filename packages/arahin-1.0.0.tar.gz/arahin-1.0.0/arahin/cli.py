"""ARAHIN CLI — entry point, REPL, 7 commands, and route pipeline."""

from __future__ import annotations

import argparse
import os
import sys
import webbrowser
from typing import Any

from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from . import __version__
from .banner import show_splash
from .state import get_state, reset_route_state, SessionState

# Rich console
console = Console()

# Available OpenCode Go models
AVAILABLE_MODELS = [
    "deepseek-v4-flash",
    "deepseek-v4-pro",
    "glm-5",
    "glm-5.1",
    "kimi-k2.5",
    "kimi-k2.6",
    "mimo-v2.5",
    "mimo-v2.5-pro",
    "minimax-m2.5",
    "minimax-m2.7",
    "qwen3.5-plus",
    "qwen3.6-plus",
]

API_BASE = "https://opencode.ai/zen/go/v1"


# ── Command handlers ───────────────────────────────────────────────────────


def _cmd_api(args: str, state: SessionState) -> None:
    """Set API key for the session. No arg: show status."""
    if not args.strip():
        console.print(f"API key: {state.api_status}")
        return
    state.api_key = args.strip()
    console.print(f"[green]✓[/green] API key set ({state.api_status})")


def _cmd_model(args: str, state: SessionState) -> None:
    """Switch LLM model. No arg: show current + available."""
    if not args.strip():
        console.print(f"Current model: [bold cyan]{state.model}[/bold cyan]")
        console.print(f"Available: {', '.join(AVAILABLE_MODELS)}")
        console.print("Set with: [bold]/model <name>[/bold]")
        return
    name = args.strip()
    if name not in AVAILABLE_MODELS:
        console.print(
            f"[yellow]Unknown model '{name}'.[/yellow] "
            f"Available: {', '.join(AVAILABLE_MODELS)}"
        )
        return
    state.model = name
    console.print(f"[green]✓[/green] Model set to [bold]{name}[/bold]")


def _cmd_map(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Open last generated map in browser."""
    if not state.last_map_path:
        console.print("[yellow]No map generated yet. Run a route query first.[/yellow]")
        return
    console.print(f"🗺  Opening [bold]{state.last_map_path}[/bold]")
    webbrowser.open(f"file://{state.last_map_path}")


def _cmd_dir(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Show turn-by-turn directions from last route."""
    if not state.last_route_details:
        console.print(
            "[yellow]No route data available. Run a query first.[/yellow]"
        )
        return

    from .tools.render_map import render_turn_by_turn

    text = render_turn_by_turn(state.last_route_details)
    if not text.strip():
        console.print("[yellow]No turn-by-turn instructions available.[/yellow]")
        return

    console.print(text)


def _cmd_config(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Show all current settings."""
    table = Table(title="ARAHIN Settings", border_style="cyan")
    table.add_column("Setting", style="bold")
    table.add_column("Value")
    table.add_row("Model", state.model)
    table.add_row("API Key", state.api_status)
    table.add_row("API Base", API_BASE)
    console.print(table)


def _cmd_help(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Re-show the splash screen."""
    show_splash(console)


def _cmd_exit(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Exit the REPL."""
    console.print("[bold cyan]Goodbye! 🗺[/bold cyan]")
    sys.exit(0)


def _cmd_update(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Update ARAHIN to the latest version from GitHub."""
    import subprocess
    console.print("[bold]Checking for updates...[/bold]")

    pip_cmds = [
        [sys.executable, "-m", "pip", "install", "--upgrade",
         "git+https://github.com/syawalqi/arahin.git"],
        [sys.executable, "-m", "pip", "install", "--upgrade",
         "--break-system-packages",
         "git+https://github.com/syawalqi/arahin.git"],
    ]

    for cmd in pip_cmds:
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0:
                console.print("[green]✅ ARAHIN updated to latest version.[/green]")
                return
        except Exception:
            continue

    console.print(
        "[yellow]Could not auto-update.[/yellow] Try manually:\n"
        "  pip install --upgrade git+https://github.com/syawalqi/arahin.git\n"
        "Or if using pipx:\n"
        "  pipx upgrade arahin"
    )


# ── Command dispatch ───────────────────────────────────────────────────────

REPL_COMMANDS: dict[str, callable] = {
    "/api": _cmd_api,
    "/model": _cmd_model,
    "/map": _cmd_map,
    "/dir": _cmd_dir,
    "/config": _cmd_config,
    "/update": _cmd_update,
    "/help": _cmd_help,
    "/exit": _cmd_exit,
}


# ── Core route query pipeline ──────────────────────────────────────────────


def _print_route(
    ordered: list[dict], route_details: list[dict] | None = None
) -> None:
    """Print the route as a rich table."""
    if not ordered:
        return

    total_dist = 0.0
    total_dur = 0.0

    table = Table(
        title="ARAHIN ROUTE",
        border_style="cyan",
        header_style="bold",
    )
    table.add_column("#", style="dim")
    table.add_column("Waypoint")
    table.add_column("Distance", justify="right")
    table.add_column("Duration", justify="right")

    for i, wp in enumerate(ordered):
        label = wp["name"]
        if i == 0:
            label = f"🟢 {label} (START)"
        elif i == len(ordered) - 1:
            label = f"🔴 {label} (END)"

        dist = ""
        dur = ""
        if route_details and i < len(route_details):
            d = route_details[i]
            if d:
                dist = f"{d.get('distance_km', 0):.1f} km"
                dur = f"{d.get('duration_min', 0):.0f} min"
                total_dist += d.get("distance_km", 0)
                total_dur += d.get("duration_min", 0)

        table.add_row(str(i + 1), label, dist, dur)

    if route_details:
        table.add_row(
            "",
            "[bold]Total[/bold]",
            f"[bold]{total_dist:.1f} km[/bold]",
            f"[bold]{total_dur:.0f} min[/bold]",
        )

    console.print(table)


def _run_query(query: str, state: SessionState, show_map: bool = False) -> bool:
    """Execute full route pipeline: ReAct → optimize → render → print.

    Returns True on success, False on failure.
    """
    from .agent.controller import Agent
    from .agent.prompts import TOOLS_SCHEMA, SYSTEM_PROMPT
    from .tools.optimizer import optimize_route
    from .tools.render_map import render_route_html
    from .tools.route import get_route

    if not state.api_key:
        console.print(
            "[red]API key not set.[/red] "
            "Set it with [bold]/api <key>[/bold] "
            "or export $ARAHIN_API_KEY"
        )
        return False

    reset_route_state()

    # Step 1: ReAct loop — collect waypoints
    console.print("[bold]🧠 Extracting waypoints...[/bold]")
    agent = Agent(
        api_key=state.api_key,
        model=state.model,
        api_base=API_BASE,
    )
    try:
        waypoints = agent.run(
            query, TOOLS_SCHEMA, SYSTEM_PROMPT,
            print_cb=lambda msg: console.print(msg),
        )
    except Exception as e:
        console.print(f"[red]Agent error: {e}[/red]")
        return False

    if not waypoints:
        console.print("[red]✗ No waypoints could be identified.[/red]")
        return False

    console.print(f"📌 [bold]{len(waypoints)}[/bold] waypoints found.")

    # Step 2: Optimize route (TSP)
    ordered, _ = optimize_route(waypoints)
    state.last_waypoints = waypoints
    state.last_ordered = ordered

    # Step 3: Get per-leg OSRM data
    route_details: list[dict[str, Any]] = []
    for i in range(len(ordered) - 1):
        leg = get_route(ordered[i], ordered[i + 1])
        if leg:
            route_details.append(leg)
        else:
            route_details.append(
                {
                    "distance_km": 0,
                    "duration_min": 0,
                    "geometry": None,
                    "steps": [],
                }
            )
    state.last_route_details = route_details

    # Step 4: Print route table
    _print_route(ordered, route_details)

    # Step 5: Generate map (always — enables /map)
    try:
        path = render_route_html(ordered, route_details)
        state.last_map_path = path
        console.print(f"🗺  Map saved: [dim]{path}[/dim]")
        if show_map:
            webbrowser.open(f"file://{path}")
            console.print("🗺  Opened map in browser")
    except Exception as e:
        console.print(f"[yellow]Map render skipped: {e}[/yellow]")

    return True


# ── REPL loop ──────────────────────────────────────────────────────────────


def repl_loop(state: SessionState) -> None:
    """Run the interactive REPL."""
    show_splash(console)

    while True:
        try:
            raw = Prompt.ask("📍 Route Description")
        except (EOFError, KeyboardInterrupt):
            console.print()
            _cmd_exit("", state)
            break

        text = raw.strip()
        if not text:
            continue

        # Dispatch slash commands
        if text.startswith("/"):
            parts = text.split(maxsplit=1)
            cmd = parts[0].lower()
            args = parts[1] if len(parts) > 1 else ""

            handler = REPL_COMMANDS.get(cmd)
            if handler:
                handler(args, state)
            else:
                console.print(
                    f"[yellow]Unknown command: {cmd}[/yellow]\n"
                    f"Type [bold]/help[/bold] for available commands."
                )
            continue

        # Run route query
        _run_query(text, state)


# ── CLI entry point ────────────────────────────────────────────────────────


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse CLI arguments."""
    parser = argparse.ArgumentParser(
        prog="arahin",
        description="AI Route Planning Agent — Spatial-RAG + TSP",
    )
    parser.add_argument(
        "query",
        nargs="?",
        help="Route description (omit for interactive REPL mode)",
    )
    parser.add_argument(
        "--map",
        "-m",
        action="store_true",
        help="Open route map in browser",
    )
    parser.add_argument(
        "--directions",
        "-d",
        action="store_true",
        help="Print turn-by-turn directions",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"ARAHIN v{__version__}",
    )
    parser.add_argument(
        "--update",
        "-u",
        action="store_true",
        help="Update ARAHIN to the latest version",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    """Main entry point."""
    args = parse_args(argv)
    state = get_state()

    # Load API key from env vars (fallback if /api not used)
    if not state.api_key:
        state.api_key = os.environ.get("ARAHIN_API_KEY", "")
    if not state.api_key:
        state.api_key = os.environ.get("OPENCODE_API_KEY", "")

    # Non-interactive mode
    if args.query:
        success = _run_query(args.query, state, show_map=args.map)
        if args.directions and success:
            _cmd_dir("", state)
        sys.exit(0 if success else 1)

    # Update mode
    if args.update:
        _cmd_update("", state)
        sys.exit(0)

    # Interactive REPL mode
    try:
        repl_loop(state)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
