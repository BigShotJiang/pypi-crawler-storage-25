"""Splash screen — ASCII art logo + command reference."""

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

BANNER = r"""
      █████╗ ██████╗  █████╗ ██╗  ██╗██╗███╗   ██╗
     ██╔══██╗██╔══██╗██╔══██╗██║  ██║██║████╗  ██║
     ███████║██████╔╝███████║███████║██║██╔██╗ ██║
     ██╔══██║██╔══██╗██╔══██║██╔══██║██║██║╚██╗██║
     ██║  ██║██║  ██║██║  ██║██║  ██║██║██║ ╚████║
     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝
"""

HELP_TEXT = (
    "Type a route description in Indonesian or English.\n\n"
    "  [bold]Examples:[/bold]\n"
    '    "dari Monas ke Taman Mini, mampir sate dekat Cawang"\n'
    '    "cari masjid terdekat dari UI Depok"\n'
    '    "jalan-jalan di kawasan Kota Tua"\n\n'
    "  [bold]Commands:[/bold]\n"
    "    /api <key>       Set API key (session only)\n"
    "    /model <name>    Switch model\n"
    "    /map             Open route map in browser\n"
    "    /dir             Show turn-by-turn directions\n"
    "    /config          Show current settings\n"
    "    /update          Update ARAHIN to latest version\n"
    "    /help            Show this screen\n"
    "    /exit            Quit"
)


def show_splash(console: Console | None = None) -> None:
    """Print the splash screen: logo panel + help panel."""
    if console is None:
        console = Console()

    logo_text = Text(BANNER, style="bold cyan")
    logo_panel = Panel(
        logo_text,
        subtitle="[bold white]AI Route Planning Agent  ·  Spatial-RAG + TSP[/bold white]",
        border_style="cyan",
        padding=(0, 2),
    )

    help_panel = Panel(
        HELP_TEXT,
        title="[bold]Getting Started[/bold]",
        border_style="blue",
        padding=(1, 2),
    )

    console.print()
    console.print(logo_panel)
    console.print(help_panel)
    console.print()
