"""Session state — singleton holding route data + API settings."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SessionState:
    """Mutable state that persists across REPL prompts.

    Route data resets per query. API settings persist until changed
    via /api or /model commands.
    """

    # Route cache (reset per query)
    last_waypoints: list[dict] = field(default_factory=list)
    last_ordered: list[dict] = field(default_factory=list)
    last_route_details: list[dict] = field(default_factory=list)
    last_map_path: str | None = None

    # API settings (persist across session)
    api_key: str = ""
    model: str = "deepseek-v4-flash"

    @property
    def api_status(self) -> str:
        """Masked API key for display. Returns 'not set' if empty."""
        if not self.api_key:
            return "[red]not set[/red]"
        if len(self.api_key) > 8:
            masked = self.api_key[:4] + "****" + self.api_key[-4:]
        else:
            masked = "****"
        return f"[green]{masked}[/green]"


# Singleton
_state: SessionState | None = None


def get_state() -> SessionState:
    """Return the global session state singleton."""
    global _state  # noqa: PLW0603
    if _state is None:
        _state = SessionState()
    return _state


def reset_route_state() -> None:
    """Clear route data only — preserves API settings."""
    s = get_state()
    s.last_waypoints = []
    s.last_ordered = []
    s.last_route_details = []
    s.last_map_path = None
