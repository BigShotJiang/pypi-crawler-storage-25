"""System prompt + 3 tool schemas for the ReAct agent."""

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "geocode",
            "description": (
                "Convert a named place to coordinates. "
                "First call for every location mentioned: "
                "'Monas, Jakarta' or 'Tokyo Tower'"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "place_name": {
                        "type": "string",
                        "description": "Place name, e.g. 'Monas, Jakarta' or 'Tokyo Tower'",
                    }
                },
                "required": ["place_name"],
            },
        }
    },
    {
        "type": "function",
        "function": {
            "name": "spatial_rag",
            "description": (
                "Find places matching a natural-language description near coordinates. "
                "Use for vague queries: 'sate enak dekat Cawang', 'halal food near Central Park'"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "What to find, in natural language",
                    },
                    "lat": {
                        "type": "number",
                        "description": "Latitude of search center",
                    },
                    "lng": {
                        "type": "number",
                        "description": "Longitude of search center",
                    },
                    "radius": {
                        "type": "integer",
                        "default": 5,
                        "description": "Search radius in km",
                    },
                },
                "required": ["query", "lat", "lng"],
            },
        }
    },
    {
        "type": "function",
        "function": {
            "name": "poi_search",
            "description": (
                "Search POIs by OSM amenity category near coordinates. "
                "Use for structured queries: 'cari masjid', 'cari restoran', 'cari ATM'"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Amenity type: restaurant, cafe, mosque, atm, hospital, etc.",
                    },
                    "lat": {"type": "number"},
                    "lng": {"type": "number"},
                    "radius": {
                        "type": "integer",
                        "default": 3,
                        "description": "Search radius in km",
                    },
                },
                "required": ["category", "lat", "lng"],
            },
        }
    },
]

SYSTEM_PROMPT = (
    "You are ARAHIN, an AI route planning agent. "
    "Extract ALL waypoints from the user's natural language request.\n\n"
    "Extract every named location mentioned — start point, destination, "
    "and ALL intermediate stops (places to pass through, eat, rest, visit).\n\n"
    "Available tools:\n"
    "- geocode(place_name): Convert a named place to coordinates. "
    "Call for every named location.\n"
    "- spatial_rag(query, lat, lng, radius?): Find nearby POIs matching a "
    "description. Use for vague queries like 'makan bebek', 'sate enak'.\n"
    "- poi_search(category, lat, lng, radius?): Search POIs by OSM amenity "
    "type. Use for: 'cari masjid', 'cari restoran'.\n\n"
    "Think step by step. Call ONE tool at a time.\n"
    "When ALL waypoints are collected, respond with ONLY a JSON array:\n"
    '[{"name": "...", "lat": ..., "lng": ...}, ...]\n'
    "Do NOT call any more tools after outputting the JSON."
)
