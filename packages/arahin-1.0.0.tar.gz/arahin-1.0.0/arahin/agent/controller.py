"""ReAct loop — LLM calls tools until all waypoints are collected.

Prints each tool call and result in real-time so the user can
see the AI's reasoning process.
"""

from __future__ import annotations

import json
import re
from typing import Any, Callable

from openai import OpenAI

from ..tools.geocode import geocode
from ..tools.poi_search import poi_search
from ..tools.spatial_rag import spatial_rag

TOOLS_MAP: dict[str, Callable] = {
    "geocode": geocode,
    "poi_search": poi_search,
    "spatial_rag": spatial_rag,
}

# Maximum characters from a tool result to show in the log
MAX_RESULT_PREVIEW = 200


def _format_args(fn_name: str, fn_args: dict) -> str:
    """Format tool call arguments for display."""
    parts = []
    for k, v in fn_args.items():
        if isinstance(v, str):
            parts.append(f'{k}="{v}"')
        elif isinstance(v, float):
            parts.append(f"{k}={v:.4f}")
        else:
            parts.append(f"{k}={v}")
    return f"{fn_name}({', '.join(parts)})"


def _preview_result(result: Any) -> str:
    """Short summary of a tool result for display."""
    if isinstance(result, dict):
        if "error" in result:
            return f"❌ {result['error']}"
        name = result.get("name", "?")
        lat = result.get("lat", "?")
        lng = result.get("lng", "?")
        return f"found ({lat:.4f}, {lng:.4f}) → {name}"
    if isinstance(result, list):
        if not result:
            return "none found"
        names = [r.get("name", "?") for r in result[:3]]
        extra = f" (+{len(result) - 3} more)" if len(result) > 3 else ""
        return f"found {len(result)}: {', '.join(names)}{extra}"
    return str(result)[:MAX_RESULT_PREVIEW]


def _parse_waypoints(content: str | None) -> list[dict] | None:
    """Try to extract a JSON array from the LLM response."""
    if not content:
        return None

    try:
        data = json.loads(content)
        if isinstance(data, list):
            return data
    except json.JSONDecodeError:
        pass

    match = re.search(r"\[[\s\S]*\]", content)
    if match:
        try:
            data = json.loads(match.group())
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass

    return None


class Agent:
    """ReAct loop agent that collects waypoints via tool calls."""

    def __init__(
        self,
        api_key: str,
        model: str = "deepseek-v4-flash",
        api_base: str = "https://opencode.ai/zen/go/v1",
    ):
        self.client = OpenAI(api_key=api_key, base_url=api_base)
        self.model = model

    def run(
        self,
        prompt: str,
        tools_schema: list[dict],
        system_prompt: str,
        max_turns: int = 15,
        print_cb: Callable[[str], None] | None = None,
    ) -> list[dict]:
        """Execute the ReAct loop. Returns a list of waypoint dicts.

        If print_cb is provided, it is called with status messages
        showing each tool call and result as they happen.
        """
        if print_cb is None:
            print_cb = lambda _: None  # noqa: E731

        messages: list[dict] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ]

        for turn in range(max_turns):
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=tools_schema,
                tool_choice="auto",
            )
            msg = resp.choices[0].message

            # LLM says it's done — try to parse final JSON
            if not msg.tool_calls:
                waypoints = _parse_waypoints(msg.content)
                if waypoints:
                    names = [w.get("name", "?") for w in waypoints]
                    print_cb(
                        f"  [bold green]✅[/bold green] Waypoints: "
                        f"{' → '.join(names)}"
                    )
                    return waypoints

                # Show what the LLM said (for debugging)
                preview = (msg.content or "")[:120]
                print_cb(
                    f"  [yellow]🤔 LLM response (not JSON):[/yellow] "
                    f"{preview}..."
                )

                # Failed to parse — push and retry
                messages.append(
                    {"role": "assistant", "content": msg.content or ""}
                )
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            "Please respond with ONLY a JSON array: "
                            '[{"name": "...", "lat": ..., "lng": ...}, ...]'
                        ),
                    }
                )
                continue

            # LLM called one or more tools — show each
            for tc in msg.tool_calls:
                fn_name = tc.function.name
                fn_args: dict[str, Any] = json.loads(tc.function.arguments)
                call_str = _format_args(fn_name, fn_args)

                tool_fn = TOOLS_MAP.get(fn_name)
                if tool_fn:
                    result = tool_fn(**fn_args)
                else:
                    result = {"error": f"Unknown tool: {fn_name}"}

                preview = _preview_result(result)
                print_cb(f"  🤔 [bold]{call_str}[/bold] → {preview}")

                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": json.dumps(result, ensure_ascii=False),
                    }
                )

            # Append assistant message with tool_calls after all tools ran
            messages.append(msg)

        print_cb("  [red]✗ Exhausted turns — no waypoints identified.[/red]")
        return []
