# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] — 2026-04-18

### Added

- **`omd.skills`** — new package for agent skills loaded from
  `SKILL.md` files. Includes `Skill` Pydantic model, `SkillRegistry`
  (discovers built-in, env-path, and user-supplied skill directories),
  `SkillRouter` (LLM-driven selection), and `make_skill_tools` helper that
  exposes `list_skills` / `load_skill` as agent tools.
- **`omd.skills.builtin`** — three starter skills: `file-editor`,
  `code-reviewer`, `test-writer`.
- **`omd.tools.file_tools`** — line-precise file tools
  (`read_fragment`, `read_lines`, `insert_lines`, `delete_lines`) with an
  optional workspace-root sandbox via `make_file_tools(workspace_root=...)`.
- **`BaseAgent`** now accepts `skills`, `skill_router`,
  `auto_skill_routing`, and `expose_skill_tools` keyword arguments.
  Selected skills are appended to `intro_messages`; `list_skills` /
  `load_skill` tools are added automatically when a registry is provided.
- **`Model.from_env()`** classmethod reads `MODEL_NAME`, `MODEL_URL`, and
  `MODEL_API_TOKEN` from the environment on demand.

### Changed

- **`pyproject.toml`** — bumped to `0.2.0`, expanded the `[machinery]`
  extra with `Pillow`, added a custom `integration` pytest marker that is
  excluded from the default test run, and configured hatchling
  `force-include` for the built-in skills directory.
- **`README.md`** — new "Skills" and "File tools" sections; updated
  project structure and feature list.

### Removed

- **`omd.env`** — the module read `os.environ[...]` at import time, which
  broke `import omd.*` for users without the env vars set. Use
  `Model.from_env()` instead.
- **`omd.scripts`** — example scripts moved to a top-level `examples/`
  folder; they are no longer shipped in the wheel.

## [0.1.0] — 2026-04-15

Initial release. Consolidated from internal projects (akademik, nsi-app) into a
standalone reusable package.

### Added

- **`omd.clients`** — `BaseClient` abstract interface and `ApiBarClient`
  implementation for OpenAI-compatible HTTP APIs. `Model` Pydantic config.
- **`omd.agents`** — `BaseAgent` with ReAct-style agentic loop: iterative
  tool-calling with configurable `attempts_limit` and automatic final-answer
  forcing.
- **`omd.tools`** — `Tool` model with `from_callable()` class method for
  automatic OpenAI-compatible JSON schema generation from typed Python functions
  (uses type hints and Sphinx `:param:` docstrings).
- **`omd.prompts`** — `PromptBase` abstract class and `ListPrompt` for
  composable system prompt construction.
- **`omd.machinery.sd`** — Stability AI integration: `generate_image`
  (text-to-image and image-to-image) and `replace_background`.
- **`omd.machinery.gemini`** — Gemini reference-guided image generation via
  api-bar gateway.
- **`omd.machinery.veo`** — Veo video generation (text-to-video and
  image-to-video) with long-running operation polling and MinIO upload.
- **`omd.utils`** — `truncate_text` and `serialize_for_log` logging helpers.
