"""omd/__init__.py.

OMD — One More Dimension.

Lightweight Python framework for building LLM agents with tool-calling.
"""
