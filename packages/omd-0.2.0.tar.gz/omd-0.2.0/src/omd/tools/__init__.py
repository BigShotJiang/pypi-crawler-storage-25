"""omd/tools/__init__.py.

Tool definitions and utilities for OpenAI-compatible function calling.
"""

from omd.tools.data_models import Tool, ToolArgumentsValidator, ToolValidationError
from omd.tools.file_tools import (
    delete_lines,
    insert_lines,
    make_file_tools,
    read_fragment,
    read_lines,
)

__all__ = [
    "Tool",
    "ToolArgumentsValidator",
    "ToolValidationError",
    "delete_lines",
    "insert_lines",
    "make_file_tools",
    "read_fragment",
    "read_lines",
]
