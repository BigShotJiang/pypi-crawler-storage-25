"""omd/agents/__init__.py.

Agent implementations for OMD.
"""

from omd.agents.base import BaseAgent

__all__ = ["BaseAgent"]
