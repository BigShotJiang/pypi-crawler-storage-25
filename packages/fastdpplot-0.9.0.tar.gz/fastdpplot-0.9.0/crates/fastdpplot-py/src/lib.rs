use fastdpplot_core::binmat::matrix_to_dotpoints;
use fastdpplot_core::binning::bin_points;
use fastdpplot_core::dp_input::load_dp_input as core_load_dp_input;
use fastdpplot_core::fasta::{format_axis_label, parse_fasta};
use fastdpplot_core::io::{load_parquet as core_load_parquet, load_txt as core_load_txt};
use fastdpplot_core::sparse::to_coo as core_to_coo;
use fastdpplot_core::types::{DotPoint, TileRequest};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------

fn map_err<E: std::fmt::Display>(e: E) -> PyErr {
    PyValueError::new_err(e.to_string())
}

// ---------------------------------------------------------------------------
// load_parquet
// ---------------------------------------------------------------------------

/// Load a Parquet file and return a list of `(x, y, value)` tuples.
#[pyfunction]
fn load_parquet(path: &str) -> PyResult<Vec<(f64, f64, f32)>> {
    let points = core_load_parquet(path).map_err(map_err)?;
    Ok(points.into_iter().map(|p| (p.x, p.y, p.value)).collect())
}

// ---------------------------------------------------------------------------
// load_txt
// ---------------------------------------------------------------------------

/// Parse a delimited text file and return a list of `(x, y, value)` tuples.
///
/// `sep` must be a single-character string (e.g. `"\t"` or `" "`).
#[pyfunction]
#[pyo3(signature = (path, sep="\t", x_col=0, y_col=1, val_col=None))]
fn load_txt(
    path: &str,
    sep: &str,
    x_col: usize,
    y_col: usize,
    val_col: Option<usize>,
) -> PyResult<Vec<(f64, f64, f32)>> {
    let mut sep_chars = sep.chars();
    let sep_char = match (sep_chars.next(), sep_chars.next()) {
        (None, _) => return Err(PyValueError::new_err("sep must be a non-empty string")),
        (Some(_), Some(_)) => return Err(PyValueError::new_err("sep must be a single-character string")),
        (Some(c), None) => c,
    };
    let points = core_load_txt(path, sep_char, x_col, y_col, val_col).map_err(map_err)?;
    Ok(points.into_iter().map(|p| (p.x, p.y, p.value)).collect())
}

// ---------------------------------------------------------------------------
// bin_points
// ---------------------------------------------------------------------------

/// Bin a set of points into a 2D histogram grid.
///
/// Parameters
/// ----------
/// xs, ys, values : flat lists of coordinates / scalar values.
/// x_min, x_max, y_min, y_max : viewport bounds.
/// width, height : grid resolution in pixels.
///
/// Returns
/// -------
/// (counts_flat, values_flat) : row-major flat arrays of length `width * height`.
#[pyfunction]
#[pyo3(signature = (xs, ys, values, x_min, x_max, y_min, y_max, width, height))]
#[allow(clippy::too_many_arguments)]
fn bin_points_py(
    xs: Vec<f64>,
    ys: Vec<f64>,
    values: Vec<f32>,
    x_min: f64,
    x_max: f64,
    y_min: f64,
    y_max: f64,
    width: usize,
    height: usize,
) -> PyResult<(Vec<u32>, Vec<f32>)> {
    if xs.len() != ys.len() || xs.len() != values.len() {
        return Err(PyValueError::new_err("xs, ys, and values must have the same length"));
    }
    let points: Vec<DotPoint> = xs
        .into_iter()
        .zip(ys)
        .zip(values)
        .map(|((x, y), v)| DotPoint { x, y, value: v })
        .collect();
    let request = TileRequest {
        zoom: 0,
        x_range: (x_min, x_max),
        y_range: (y_min, y_max),
        canvas_width: width,
        canvas_height: height,
    };
    let grid = bin_points(&points, &request);
    Ok((grid.counts, grid.values))
}

// ---------------------------------------------------------------------------
// to_coo
// ---------------------------------------------------------------------------

/// Convert flat counts / values arrays to COO sparse triplets.
///
/// Returns `(rows, cols, data)` — bins where `count == 0` are excluded.
#[pyfunction]
fn to_coo(
    counts: Vec<u32>,
    values: Vec<f32>,
    width: usize,
    height: usize,
) -> PyResult<(Vec<u32>, Vec<u32>, Vec<f32>)> {
    if counts.len() != width * height || values.len() != width * height {
        return Err(PyValueError::new_err(
            "counts and values must have length width * height",
        ));
    }
    use fastdpplot_core::types::BinGrid;
    let grid = BinGrid {
        width,
        height,
        x_min: 0.0,
        x_max: 1.0,
        y_min: 0.0,
        y_max: 1.0,
        counts,
        values,
    };
    let (rows, cols, data) = core_to_coo(&grid);
    Ok((rows, cols, data))
}

// ---------------------------------------------------------------------------
// Module
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// parse_fasta_first / parse_fasta_all / fasta_axis_label
// ---------------------------------------------------------------------------

/// Returns `(id, description, sequence, length)` for the **first** FASTA record.
#[pyfunction]
fn parse_fasta_first(path: &str) -> PyResult<(String, String, String, usize)> {
    let records = parse_fasta(path).map_err(map_err)?;
    let r = records.into_iter().next()
        .ok_or_else(|| PyValueError::new_err("No FASTA records found"))?;
    Ok((r.id, r.description, r.sequence, r.length))
}

/// Returns a list of `(id, description, sequence, length)` for **all** FASTA records.
#[pyfunction]
fn parse_fasta_all(path: &str) -> PyResult<Vec<(String, String, String, usize)>> {
    let records = parse_fasta(path).map_err(map_err)?;
    Ok(records.into_iter().map(|r| (r.id, r.description, r.sequence, r.length)).collect())
}

/// Return the axis label string for the first FASTA record, truncated to `max_len` characters.
#[pyfunction]
fn fasta_axis_label(path: &str, max_len: usize) -> PyResult<String> {
    let records = parse_fasta(path).map_err(map_err)?;
    let r = records.into_iter().next()
        .ok_or_else(|| PyValueError::new_err("No FASTA records found"))?;
    Ok(format_axis_label(&r, max_len))
}

// ---------------------------------------------------------------------------
// load_dp_input (one-shot)
// ---------------------------------------------------------------------------

/// One-shot loader: parse two FASTA files + `.bin` matrix, validate dimensions,
/// and return `(xs, ys, values, query_label, subject_label, query_len, subject_len)`.
///
/// `threshold` filters out points below the normalised value.
#[pyfunction]
#[allow(clippy::type_complexity)]
fn load_dp_input(
    matrix_path: &str,
    fasta_a_path: &str,
    fasta_b_path: &str,
    threshold: f32,
) -> PyResult<(Vec<f64>, Vec<f64>, Vec<f32>, String, String, usize, usize)> {
    let input = core_load_dp_input(matrix_path, fasta_a_path, fasta_b_path)
        .map_err(map_err)?;

    let query_len = input.matrix.seq_rows();
    let subject_len = input.matrix.seq_cols();
    let query_label = input.query_axis_label.clone();
    let subject_label = input.subject_axis_label.clone();

    let points = matrix_to_dotpoints(&input.matrix, threshold);
    let xs: Vec<f64> = points.iter().map(|p| p.x).collect();
    let ys: Vec<f64> = points.iter().map(|p| p.y).collect();
    let vs: Vec<f32> = points.iter().map(|p| p.value).collect();

    Ok((xs, ys, vs, query_label, subject_label, query_len, subject_len))
}

// ---------------------------------------------------------------------------
// Module registration
// ---------------------------------------------------------------------------

#[pymodule]
fn _rs(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(load_parquet, m)?)?;
    m.add_function(wrap_pyfunction!(load_txt, m)?)?;
    m.add_function(wrap_pyfunction!(bin_points_py, m)?)?;
    m.add_function(wrap_pyfunction!(to_coo, m)?)?;
    m.add_function(wrap_pyfunction!(parse_fasta_first, m)?)?;
    m.add_function(wrap_pyfunction!(parse_fasta_all, m)?)?;
    m.add_function(wrap_pyfunction!(fasta_axis_label, m)?)?;
    m.add_function(wrap_pyfunction!(load_dp_input, m)?)?;
    Ok(())
}
