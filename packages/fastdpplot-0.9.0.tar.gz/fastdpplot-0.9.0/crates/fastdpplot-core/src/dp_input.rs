//! High-level `.bin` + FASTA input pipeline.

use crate::binmat::{matrix_to_dotpoints, read_bin_matrix, BinMatrix};
use crate::error::FastDpError;
use crate::fasta::{format_axis_label, parse_fasta, FastaRecord};
use crate::types::DotPoint;

// ---------------------------------------------------------------------------
// Public data types
// ---------------------------------------------------------------------------

/// All data needed to render a DP dotplot from a `.bin` matrix + two FASTA files.
#[derive(Debug)]
pub struct DpInput {
    /// First record from `fasta_a` (rows of the matrix after any axis swap).
    pub query: FastaRecord,
    /// First record from `fasta_b` (columns of the matrix after any axis swap).
    pub subject: FastaRecord,
    /// Loaded binary matrix.
    pub matrix: BinMatrix,
    /// Formatted Y-axis label (query).
    pub query_axis_label: String,
    /// Formatted X-axis label (subject).
    pub subject_axis_label: String,
}

// ---------------------------------------------------------------------------
// load_dp_input
// ---------------------------------------------------------------------------

/// One-shot loader: parse both FASTA files and the `.bin` matrix, validate
/// dimensions, and return a [`DpInput`] ready for rendering.
///
/// The matrix header encodes `(cols, rows)` = `(subject_len+1, query_len+1)`.
/// If the dimensions appear transposed relative to the FASTA order a warning
/// is printed and the query/subject axes are swapped automatically.
pub fn load_dp_input(
    matrix_path: &str,
    fasta_a_path: &str, // query   → rows
    fasta_b_path: &str, // subject → cols
) -> Result<DpInput, FastDpError> {
    let query_records = parse_fasta(fasta_a_path)?;
    let subject_records = parse_fasta(fasta_b_path)?;

    let query = query_records
        .into_iter()
        .next()
        .ok_or_else(|| FastDpError::NoRecords { path: fasta_a_path.into() })?;
    let subject = subject_records
        .into_iter()
        .next()
        .ok_or_else(|| FastDpError::NoRecords { path: fasta_b_path.into() })?;

    let matrix = read_bin_matrix(matrix_path)?;

    // Validate: matrix dims must be (query.length+1) × (subject.length+1).
    // Also handle the transposed case.
    let (query, subject) = if matrix.rows == query.length + 1
        && matrix.cols == subject.length + 1
    {
        (query, subject)
    } else if matrix.rows == subject.length + 1 && matrix.cols == query.length + 1 {
        eprintln!(
            "Warning: matrix is transposed relative to FASTA order; swapping axes."
        );
        (subject, query)
    } else {
        return Err(FastDpError::DimMismatch {
            mat_rows: matrix.rows,
            mat_cols: matrix.cols,
            query_len: query.length,
            subject_len: subject.length,
        });
    };

    let query_axis_label = format_axis_label(&query, 80);
    let subject_axis_label = format_axis_label(&subject, 80);

    Ok(DpInput { query, subject, matrix, query_axis_label, subject_axis_label })
}

/// Convert a loaded [`DpInput`] to `Vec<DotPoint>` with min-max normalised values.
///
/// Points with `normalized_value < threshold` are excluded.
pub fn dp_input_to_dotpoints(input: &DpInput, threshold: f32) -> Vec<DotPoint> {
    matrix_to_dotpoints(&input.matrix, threshold)
}
