use crate::types::BinGrid;

/// Convert a `BinGrid` to CSR format `(indptr, indices, data)`.
///
/// Only bins where `count > 0` are included. The result can be passed directly
/// to `scipy.sparse.csr_matrix((data, indices, indptr), shape=(height, width))`.
pub fn to_csr(grid: &BinGrid) -> (Vec<u32>, Vec<u32>, Vec<f32>) {
    let w = grid.width;
    let h = grid.height;

    let mut indptr = Vec::with_capacity(h + 1);
    let mut indices = Vec::new();
    let mut data = Vec::new();

    indptr.push(0u32);
    for row in 0..h {
        for col in 0..w {
            let idx = row * w + col;
            if grid.counts[idx] > 0 {
                indices.push(col as u32);
                data.push(grid.values[idx]);
            }
        }
        indptr.push(indices.len() as u32);
    }

    (indptr, indices, data)
}

/// Convert a `BinGrid` to COO format `(row, col, data)`.
///
/// Only bins where `count > 0` are included. Suitable for conversion to
/// PyArrow / pandas or `scipy.sparse.coo_matrix`.
pub fn to_coo(grid: &BinGrid) -> (Vec<u32>, Vec<u32>, Vec<f32>) {
    let w = grid.width;
    let h = grid.height;

    let nnz = grid.counts.iter().filter(|&&c| c > 0).count();
    let mut rows = Vec::with_capacity(nnz);
    let mut cols = Vec::with_capacity(nnz);
    let mut data = Vec::with_capacity(nnz);

    for row in 0..h {
        for col in 0..w {
            let idx = row * w + col;
            if grid.counts[idx] > 0 {
                rows.push(row as u32);
                cols.push(col as u32);
                data.push(grid.values[idx]);
            }
        }
    }

    (rows, cols, data)
}
