use std::fs::File;
use std::io::{BufRead, BufReader};

use arrow::array::{Array, Float32Array, Float64Array};
use arrow::datatypes::DataType;
use parquet::arrow::arrow_reader::ParquetRecordBatchReaderBuilder;
use rayon::prelude::*;

use crate::error::FastDpError;
use crate::types::DotPoint;

// ---------------------------------------------------------------------------
// Parquet loader
// ---------------------------------------------------------------------------

/// Load `x`, `y`, and optionally `value`/`identity` columns from a Parquet file.
///
/// Streams record batches one at a time — the whole file is never resident in RAM.
pub fn load_parquet(path: &str) -> Result<Vec<DotPoint>, FastDpError> {
    let file = File::open(path)?;
    let builder = ParquetRecordBatchReaderBuilder::try_new(file)?;

    // Identify column indices by name in the schema.
    let schema = builder.schema().clone();
    let col_x = find_field(schema.fields(), &["x", "X"])?;
    let col_y = find_field(schema.fields(), &["y", "Y"])?;
    let col_v = find_field_opt(schema.fields(), &["value", "identity", "score"]);

    // Build a projection mask: only read the columns we actually need.
    let mut proj: Vec<usize> = vec![col_x, col_y];
    if let Some(v) = col_v {
        proj.push(v);
    }
    proj.sort_unstable();
    proj.dedup();

    // Remap original schema indices into projected positions.
    let px = proj.iter().position(|&i| i == col_x).unwrap();
    let py = proj.iter().position(|&i| i == col_y).unwrap();
    let pv = col_v.map(|v| proj.iter().position(|&i| i == v).unwrap());

    // Extract the parquet schema before the builder is consumed.
    let parquet_schema = builder.parquet_schema();
    let mask = parquet::arrow::ProjectionMask::roots(parquet_schema, proj);
    let reader = builder.with_projection(mask).build()?;

    let mut points = Vec::new();
    for batch in reader {
        let batch = batch?;
        let len = batch.num_rows();
        let xs = cast_to_f64(batch.column(px))?;
        let ys = cast_to_f64(batch.column(py))?;
        let vs: Option<Vec<f32>> = pv.map(|v| cast_to_f32(batch.column(v))).transpose()?;

        points.reserve(len);
        for i in 0..len {
            points.push(DotPoint {
                x: xs[i],
                y: ys[i],
                value: vs.as_ref().map(|v| v[i]).unwrap_or(1.0),
            });
        }
    }

    Ok(points)
}

fn find_field(
    fields: &arrow::datatypes::Fields,
    names: &[&str],
) -> Result<usize, FastDpError> {
    for name in names {
        if let Some(pos) = fields.iter().position(|f| f.name().eq_ignore_ascii_case(name)) {
            return Ok(pos);
        }
    }
    Err(FastDpError::ColumnNotFound(names.join(" / ")))
}

fn find_field_opt(fields: &arrow::datatypes::Fields, names: &[&str]) -> Option<usize> {
    for name in names {
        if let Some(pos) = fields.iter().position(|f| f.name().eq_ignore_ascii_case(name)) {
            return Some(pos);
        }
    }
    None
}

fn cast_to_f64(col: &dyn Array) -> Result<Vec<f64>, FastDpError> {
    match col.data_type() {
        DataType::Float64 => {
            let arr = col.as_any().downcast_ref::<Float64Array>().unwrap();
            Ok((0..arr.len())
                .map(|i| if arr.is_null(i) { f64::NAN } else { arr.value(i) })
                .collect())
        }
        DataType::Float32 => {
            let arr = col.as_any().downcast_ref::<Float32Array>().unwrap();
            Ok((0..arr.len())
                .map(|i| if arr.is_null(i) { f64::NAN } else { arr.value(i) as f64 })
                .collect())
        }
        other => Err(FastDpError::UnsupportedType(format!(
            "column type {:?} cannot be used as x/y coordinate",
            other
        ))),
    }
}

fn cast_to_f32(col: &dyn Array) -> Result<Vec<f32>, FastDpError> {
    match col.data_type() {
        DataType::Float32 => {
            let arr = col.as_any().downcast_ref::<Float32Array>().unwrap();
            Ok((0..arr.len())
                .map(|i| if arr.is_null(i) { f32::NAN } else { arr.value(i) })
                .collect())
        }
        DataType::Float64 => {
            let arr = col.as_any().downcast_ref::<Float64Array>().unwrap();
            Ok((0..arr.len())
                .map(|i| if arr.is_null(i) { f32::NAN } else { arr.value(i) as f32 })
                .collect())
        }
        other => Err(FastDpError::UnsupportedType(format!(
            "column type {:?} cannot be used as value column",
            other
        ))),
    }
}

// ---------------------------------------------------------------------------
// TXT / tabular loader
// ---------------------------------------------------------------------------

/// Parse a tab- or space-separated alignment table.
///
/// - Lines starting with `#` are skipped.
/// - If the first non-comment line cannot be parsed as numbers it is treated as
///   a header and skipped.
/// - Parsing is parallelised with `rayon`.
pub fn load_txt(
    path: &str,
    sep: char,
    x_col: usize,
    y_col: usize,
    val_col: Option<usize>,
) -> Result<Vec<DotPoint>, FastDpError> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);

    // Collect all non-comment lines with their original 1-based line numbers.
    let raw_lines: Vec<(usize, String)> = reader
        .lines()
        .enumerate()
        .filter_map(|(i, line)| {
            let line = line.ok()?;
            let trimmed = line.trim();
            if trimmed.starts_with('#') || trimmed.is_empty() {
                None
            } else {
                Some((i + 1, line))
            }
        })
        .collect();

    if raw_lines.is_empty() {
        return Ok(Vec::new());
    }

    // Detect and skip a header row: the field at x_col (and y_col when
    // different) must be numeric for the row to be treated as data.
    let start = {
        let first_row_fields: Vec<&str> = raw_lines[0].1.split(sep).collect();
        let x_field = first_row_fields.get(x_col).map(|s| s.trim()).unwrap_or("");
        let y_field = first_row_fields.get(y_col).map(|s| s.trim()).unwrap_or("");
        if x_field.parse::<f64>().is_err() || y_field.parse::<f64>().is_err() {
            1
        } else {
            0
        }
    };

    // Parse in parallel with rayon.
    let results: Vec<Result<DotPoint, FastDpError>> = raw_lines[start..]
        .par_iter()
        .map(|(lineno, line)| parse_line(line, sep, x_col, y_col, val_col, *lineno))
        .collect();

    let mut points = Vec::with_capacity(results.len());
    for res in results {
        points.push(res?);
    }
    Ok(points)
}

fn parse_line(
    line: &str,
    sep: char,
    x_col: usize,
    y_col: usize,
    val_col: Option<usize>,
    lineno: usize,
) -> Result<DotPoint, FastDpError> {
    let fields: Vec<&str> = line.split(sep).collect();
    let max_needed = val_col
        .map(|v| v.max(x_col).max(y_col))
        .unwrap_or_else(|| x_col.max(y_col));

    if fields.len() <= max_needed {
        return Err(FastDpError::MissingColumn {
            col: max_needed,
            found: fields.len(),
        });
    }

    let x = fields[x_col].trim().parse::<f64>().map_err(|e| FastDpError::Parse {
        line: lineno,
        msg: format!("x column: {}", e),
    })?;
    let y = fields[y_col].trim().parse::<f64>().map_err(|e| FastDpError::Parse {
        line: lineno,
        msg: format!("y column: {}", e),
    })?;
    let value = if let Some(vc) = val_col {
        fields[vc].trim().parse::<f32>().map_err(|e| FastDpError::Parse {
            line: lineno,
            msg: format!("value column: {}", e),
        })?
    } else {
        1.0
    };

    Ok(DotPoint { x, y, value })
}
