use rayon::prelude::*;

use crate::types::{BinGrid, DotPoint, TileRequest};

/// Bin `points` into a `canvas_width × canvas_height` grid for the given viewport.
///
/// Uses a parallel chunked-reduce strategy: each rayon thread accumulates into
/// its own local arrays, then thread-local arrays are merged. This avoids
/// per-point mutex locks and keeps floating-point accumulation correct.
pub fn bin_points(points: &[DotPoint], request: &TileRequest) -> BinGrid {
    let w = request.canvas_width;
    let h = request.canvas_height;
    let x_min = request.x_range.0;
    let x_max = request.x_range.1;
    let y_min = request.y_range.0;
    let y_max = request.y_range.1;
    let x_span = x_max - x_min;
    let y_span = y_max - y_min;
    let n = w * h;

    // Guard against degenerate ranges.
    if x_span <= 0.0 || y_span <= 0.0 || w == 0 || h == 0 {
        return BinGrid {
            width: w,
            height: h,
            x_min,
            x_max,
            y_min,
            y_max,
            counts: vec![0u32; n],
            values: vec![0.0f32; n],
        };
    }

    // Parallel fold: each thread builds a local (counts, value_sums) pair,
    // then all pairs are reduced into one.
    let (counts, value_sums): (Vec<u32>, Vec<f64>) = points
        .par_iter()
        .fold(
            || (vec![0u32; n], vec![0.0f64; n]),
            |mut acc, p| {
                if p.x < x_min || p.x > x_max || p.y < y_min || p.y > y_max {
                    return acc;
                }
                let bx =
                    (((p.x - x_min) / x_span * w as f64) as usize).min(w - 1);
                let by =
                    (((p.y - y_min) / y_span * h as f64) as usize).min(h - 1);
                let idx = by * w + bx;
                // SAFETY: bx < w, by < h, so idx < w * h == n.
                unsafe {
                    *acc.0.get_unchecked_mut(idx) += 1;
                    *acc.1.get_unchecked_mut(idx) += p.value as f64;
                }
                acc
            },
        )
        .reduce(
            || (vec![0u32; n], vec![0.0f64; n]),
            |mut a, b| {
                for i in 0..n {
                    a.0[i] += b.0[i];
                    a.1[i] += b.1[i];
                }
                a
            },
        );

    // Compute mean values where count > 0.
    let values: Vec<f32> = counts
        .iter()
        .zip(value_sums.iter())
        .map(|(&c, &s)| {
            if c > 0 {
                (s / c as f64) as f32
            } else {
                0.0
            }
        })
        .collect();

    BinGrid {
        width: w,
        height: h,
        x_min,
        x_max,
        y_min,
        y_max,
        counts,
        values,
    }
}

/// Pre-compute a zoom pyramid: for each level `0..=max_zoom` produce a `BinGrid`
/// at resolution `tile_size * 2^level`.
pub fn compute_zoom_tiles(
    points: &[DotPoint],
    max_zoom: u32,
    tile_size: usize,
) -> Vec<(u32, BinGrid)> {
    // Determine overall bounding box.
    let (x_min, x_max, y_min, y_max) = bounding_box(points);

    (0..=max_zoom)
        .map(|zoom| {
            let res = tile_size * (1 << zoom as usize);
            let request = TileRequest {
                zoom,
                x_range: (x_min, x_max),
                y_range: (y_min, y_max),
                canvas_width: res,
                canvas_height: res,
            };
            let grid = bin_points(points, &request);
            (zoom, grid)
        })
        .collect()
}

fn bounding_box(points: &[DotPoint]) -> (f64, f64, f64, f64) {
    points.iter().fold(
        (f64::INFINITY, f64::NEG_INFINITY, f64::INFINITY, f64::NEG_INFINITY),
        |(x0, x1, y0, y1), p| {
            (x0.min(p.x), x1.max(p.x), y0.min(p.y), y1.max(p.y))
        },
    )
}
