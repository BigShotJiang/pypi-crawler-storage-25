//! Streaming FASTA parser.

use std::fs::File;
use std::io::{BufRead, BufReader};

use crate::error::FastDpError;

// ---------------------------------------------------------------------------
// Public data types
// ---------------------------------------------------------------------------

/// A single FASTA record.
#[derive(Debug, Clone)]
pub struct FastaRecord {
    /// Everything after `>` up to the first whitespace on the header line.
    pub id: String,
    /// Everything after the first whitespace on the header line (may be empty).
    pub description: String,
    /// Full sequence with newlines stripped and uppercased.
    pub sequence: String,
    /// `sequence.len()` — cached for convenience.
    pub length: usize,
}

// ---------------------------------------------------------------------------
// parse_fasta
// ---------------------------------------------------------------------------

/// Parse all records from a FASTA file via a streaming `BufReader`.
///
/// - Lines starting with `>` begin a new record.
/// - Lines starting with `;` are skipped (FASTA comments).
/// - All other non-empty lines are appended to the current record's sequence.
/// - Returns `Err(FastDpError::NoRecords)` for empty files.
/// - Returns `Err(FastDpError::EmptySequence)` if any record has zero sequence bases.
pub fn parse_fasta(path: &str) -> Result<Vec<FastaRecord>, FastDpError> {
    let file = File::open(path).map_err(FastDpError::Io)?;
    let reader = BufReader::new(file);

    let mut records: Vec<FastaRecord> = Vec::new();
    // Pending sequence buffer for the current record.
    let mut current_id: Option<String> = None;
    let mut current_desc = String::new();
    let mut seq_buf = String::new();

    for line in reader.lines() {
        let line = line.map_err(FastDpError::Io)?;
        let trimmed = line.trim();

        if trimmed.is_empty() {
            continue;
        }

        if trimmed.starts_with(';') {
            // FASTA comment line — skip.
            continue;
        }

        if let Some(header) = trimmed.strip_prefix('>') {
            // Flush the previous record if any.
            if let Some(id) = current_id.take() {
                let sequence = seq_buf.clone();
                let length = sequence.len();
                if length == 0 {
                    return Err(FastDpError::EmptySequence { id });
                }
                records.push(FastaRecord { id, description: current_desc.clone(), sequence, length });
                seq_buf.clear();
            }

            // Parse the new header.
            let mut parts = header.splitn(2, |c: char| c.is_ascii_whitespace());
            let id = parts.next().unwrap_or("").to_owned();
            let desc = parts.next().unwrap_or("").trim().to_owned();
            current_id = Some(id);
            current_desc = desc;
        } else {
            // Sequence line — uppercase and append (no newlines because `trim` already stripped them).
            seq_buf.push_str(&trimmed.to_ascii_uppercase());
        }
    }

    // Flush the last record.
    if let Some(id) = current_id {
        let sequence = seq_buf;
        let length = sequence.len();
        if length == 0 {
            return Err(FastDpError::EmptySequence { id });
        }
        records.push(FastaRecord { id, description: current_desc, sequence, length });
    }

    if records.is_empty() {
        return Err(FastDpError::NoRecords { path: path.to_owned() });
    }

    Ok(records)
}

// ---------------------------------------------------------------------------
// format_axis_label
// ---------------------------------------------------------------------------

/// Format a FASTA record as an axis label, truncated to `max_len` characters.
///
/// Returns `"{id} | {description}"` when the description is non-empty,
/// or just `"{id}"` otherwise.  A `…` suffix is appended if the string
/// exceeds `max_len` characters.
pub fn format_axis_label(record: &FastaRecord, max_len: usize) -> String {
    let full = if record.description.is_empty() {
        record.id.clone()
    } else {
        format!("{} | {}", record.id, record.description)
    };

    if full.chars().count() <= max_len {
        full
    } else {
        // Truncate at a character boundary and append the ellipsis.
        let truncated: String = full.chars().take(max_len.saturating_sub(1)).collect();
        format!("{}…", truncated)
    }
}
