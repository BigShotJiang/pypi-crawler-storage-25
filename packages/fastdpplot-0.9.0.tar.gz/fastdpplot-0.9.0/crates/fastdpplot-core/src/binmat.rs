//! Raw binary DP-matrix loader.
//!
//! The `.bin` format produced by the C++ aligner has an 8-byte header:
//! - Bytes 0–3: `int32` little-endian → `cols` (subject sequence length + 1)
//! - Bytes 4–7: `int32` little-endian → `rows` (query sequence length + 1)
//! - Bytes 8+:  `int32[]` little-endian, row-major, length = `rows × cols`
//!
//! Row 0 and column 0 are gap-initialisation penalties and are excluded from
//! the alignment region (see [`matrix_to_dotpoints`]).

use std::io::{BufReader, Read};

use rayon::prelude::*;

use crate::error::FastDpError;
use crate::types::DotPoint;

// ---------------------------------------------------------------------------
// BinMatrix
// ---------------------------------------------------------------------------

/// A loaded DP matrix, including the boundary row (row 0) and column (col 0).
#[derive(Debug)]
pub struct BinMatrix {
    /// Total rows including the boundary row 0 (= query sequence length + 1).
    pub rows: usize,
    /// Total columns including the boundary column 0 (= subject sequence length + 1).
    pub cols: usize,
    /// Flat row-major `i32` buffer, length = `rows × cols`.
    pub data: Vec<i32>,
}

impl BinMatrix {
    /// Number of alignment rows, excluding the DP boundary (row 0).
    pub fn seq_rows(&self) -> usize {
        self.rows - 1
    }

    /// Number of alignment columns, excluding the DP boundary (col 0).
    pub fn seq_cols(&self) -> usize {
        self.cols - 1
    }

    #[inline]
    pub fn get(&self, row: usize, col: usize) -> i32 {
        self.data[row * self.cols + col]
    }
}

// ---------------------------------------------------------------------------
// read_bin_matrix
// ---------------------------------------------------------------------------

/// Read a `.bin` DP matrix from `path`.
///
/// Reads the 8-byte header (`cols` then `rows`, both `i32` little-endian),
/// validates the file size, and parses the flat `i32` body.
///
/// No `unsafe` — all byte parsing is done via [`i32::from_le_bytes`].
pub fn read_bin_matrix(path: &str) -> Result<BinMatrix, FastDpError> {
    let f = std::fs::File::open(path).map_err(FastDpError::Io)?;
    let file_size = f.metadata().map_err(FastDpError::Io)?.len() as usize;
    let mut reader = BufReader::new(f);

    // Read 8-byte header: cols first, then rows.
    let mut hdr = [0u8; 8];
    reader.read_exact(&mut hdr).map_err(FastDpError::Io)?;
    let cols_i32 = i32::from_le_bytes(hdr[0..4].try_into().unwrap());
    let rows_i32 = i32::from_le_bytes(hdr[4..8].try_into().unwrap());

    // Both dimensions must be at least 1 (>= 1 row and 1 col including boundary).
    if cols_i32 < 1 || rows_i32 < 1 {
        return Err(FastDpError::SizeMismatch {
            expected: 0,
            actual: file_size,
        });
    }
    let cols = cols_i32 as usize;
    let rows = rows_i32 as usize;

    // Compute expected total file size: 8-byte header + rows × cols × 4 bytes.
    // Use checked arithmetic to guard against overflow on malformed headers.
    let cell_count = rows.checked_mul(cols).ok_or(FastDpError::SizeMismatch {
        expected: 0,
        actual: file_size,
    })?;
    let body_bytes = cell_count.checked_mul(4).ok_or(FastDpError::SizeMismatch {
        expected: 0,
        actual: file_size,
    })?;
    let expected_file_size = 8usize.checked_add(body_bytes).ok_or(FastDpError::SizeMismatch {
        expected: 0,
        actual: file_size,
    })?;

    // Report total file sizes (header + body) for an unambiguous diagnostic.
    if file_size != expected_file_size {
        return Err(FastDpError::SizeMismatch {
            expected: expected_file_size,
            actual: file_size,
        });
    }

    // Read the flat i32 body — no unsafe, parse via chunks of 4 bytes.
    let mut raw = vec![0u8; body_bytes];
    reader.read_exact(&mut raw).map_err(FastDpError::Io)?;
    let data: Vec<i32> = raw
        .chunks_exact(4)
        .map(|b| i32::from_le_bytes(b.try_into().unwrap()))
        .collect();

    Ok(BinMatrix { rows, cols, data })
}

// ---------------------------------------------------------------------------
// matrix_to_dotpoints
// ---------------------------------------------------------------------------

/// Convert a [`BinMatrix`] to a [`Vec<DotPoint>`], skipping the DP boundary
/// (row 0 and col 0 are gap-init penalties, not alignment data).
///
/// Scores are min-max normalised to `[0.0, 1.0]` across the alignment region
/// only.  Points with `normalized_value < threshold` are excluded.
///
/// Uses `rayon` for parallel min/max computation and point emission.
pub fn matrix_to_dotpoints(matrix: &BinMatrix, threshold: f32) -> Vec<DotPoint> {
    // Parallel min/max over the alignment region (rows 1.., cols 1..).
    let (min_val, max_val) = (1..matrix.rows)
        .into_par_iter()
        .map(|r| {
            (1..matrix.cols).fold((i32::MAX, i32::MIN), |(mn, mx), c| {
                let v = matrix.get(r, c);
                (mn.min(v), mx.max(v))
            })
        })
        .reduce(
            || (i32::MAX, i32::MIN),
            |(mn1, mx1), (mn2, mx2)| (mn1.min(mn2), mx1.max(mx2)),
        );

    // Use i64 to avoid overflow when max_val and min_val are at opposite extremes
    // of the i32 range (e.g. min=i32::MIN, max=i32::MAX).
    let range = (max_val as i64 - min_val as i64) as f32;
    if range == 0.0 {
        return vec![];
    }

    // Emit DotPoints — x/y are 0-based sequence coordinates (boundary stripped).
    // `flat_map_iter` uses a serial inner iterator per row, avoiding a Vec
    // allocation per row while still parallelising across rows.
    (1..matrix.rows)
        .into_par_iter()
        .flat_map_iter(|row| {
            (1..matrix.cols).filter_map(move |col| {
                let normalized =
                    (matrix.get(row, col) as i64 - min_val as i64) as f32 / range;
                if normalized >= threshold {
                    Some(DotPoint {
                        x: (col - 1) as f64, // 0-based subject coord
                        y: (row - 1) as f64, // 0-based query coord
                        value: normalized,
                    })
                } else {
                    None
                }
            })
        })
        .collect()
}
