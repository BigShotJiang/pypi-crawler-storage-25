use thiserror::Error;

#[derive(Debug, Error)]
pub enum FastDpError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Parquet error: {0}")]
    Parquet(#[from] parquet::errors::ParquetError),

    #[error("Arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),

    #[error("Parse error on line {line}: {msg}")]
    Parse { line: usize, msg: String },

    #[error("Missing column index {col} (line has {found} fields)")]
    MissingColumn { col: usize, found: usize },

    #[error("Required column not found: {0}")]
    ColumnNotFound(String),

    #[error("Unsupported column type: {0}")]
    UnsupportedType(String),

    #[error("Empty dataset")]
    Empty,

    // --- FASTA / binary-matrix errors ---

    #[error("No FASTA records found in '{path}'")]
    NoRecords { path: String },

    #[error("Empty sequence for record '{id}'")]
    EmptySequence { id: String },

    #[error("Matrix file size mismatch: expected {expected} bytes, got {actual}")]
    SizeMismatch { expected: usize, actual: usize },

    #[error("Matrix dimensions ({mat_rows}×{mat_cols}) do not match sequence lengths (query={query_len}, subject={subject_len})")]
    DimMismatch {
        mat_rows: usize,
        mat_cols: usize,
        query_len: usize,
        subject_len: usize,
    },
}
