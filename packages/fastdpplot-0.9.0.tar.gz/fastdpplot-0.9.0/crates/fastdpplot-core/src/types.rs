//! Core data structures shared across all modules.
/// A single point in 2D alignment space with an associated scalar value.
#[derive(Debug, Clone)]
pub struct DotPoint {
    pub x: f64,
    pub y: f64,
    /// Identity score, expression level, count, or any per-point scalar.
    pub value: f32,
}

/// A 2D histogram grid produced by binning a set of `DotPoint`s.
#[derive(Debug)]
pub struct BinGrid {
    pub width: usize,
    pub height: usize,
    pub x_min: f64,
    pub x_max: f64,
    pub y_min: f64,
    pub y_max: f64,
    /// Flat row-major count array of length `height × width`.
    pub counts: Vec<u32>,
    /// Mean `value` per bin (0.0 where count == 0).
    pub values: Vec<f32>,
}

/// Parameters for a single tile / viewport request.
#[derive(Debug)]
pub struct TileRequest {
    pub zoom: u32,
    pub x_range: (f64, f64),
    pub y_range: (f64, f64),
    pub canvas_width: usize,
    pub canvas_height: usize,
}
