use crate::binning::bin_points;
use crate::types::{BinGrid, DotPoint, TileRequest};

/// Entry point for interactive pan/zoom tile requests.
///
/// Called from Python (via PyO3) on every Holoviews `range_stream` event.
/// Delegates to `bin_points` which runs the hot parallel binning path.
pub fn get_tile(points: &[DotPoint], request: TileRequest) -> BinGrid {
    bin_points(points, &request)
}
