try:
    from fastdpplot._rs import load_parquet as _load_parquet, load_txt as _load_txt  # noqa: F401
    from fastdpplot._rs import load_dp_input as _load_dp_input  # noqa: F401
    _RUST_AVAILABLE = True
except ImportError:
    _RUST_AVAILABLE = False

import pandas as pd


def load(path: str, **kwargs) -> pd.DataFrame:
    """Auto-detect .parquet or .txt and call the Rust backend.

    Parameters
    ----------
    path:
        Path to a ``.parquet`` file or a delimited text file.
    sep:
        Field separator for text files (default ``"\\t"``).
    x_col:
        Zero-based column index for the x coordinate (text files, default 0).
    y_col:
        Zero-based column index for the y coordinate (text files, default 1).
    val_col:
        Zero-based column index for the value/identity score (text files,
        optional).  When omitted every point receives ``value=1.0``.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ``["x", "y", "value"]``.
    """
    if not _RUST_AVAILABLE:
        raise ImportError(
            "fastdpplot._rs is not available. "
            "Run `maturin develop` to build the Rust extension first."
        )

    if path.endswith(".parquet"):
        rows = _load_parquet(path)
    else:
        sep = kwargs.get("sep", "\t")
        x_col = kwargs.get("x_col", 0)
        y_col = kwargs.get("y_col", 1)
        val_col = kwargs.get("val_col", None)
        rows = _load_txt(path, sep, x_col, y_col, val_col)

    return pd.DataFrame(rows, columns=["x", "y", "value"])


def load_bin(
    matrix_path: str,
    fasta_a: str,
    fasta_b: str,
    threshold: float = 0.0,
) -> dict:
    """Load a DP binary matrix together with two FASTA sequence files.

    Parameters
    ----------
    matrix_path:
        Path to the raw binary ``.bin`` scoring/match matrix.
    fasta_a:
        Path to the query FASTA file (rows of the matrix).
    fasta_b:
        Path to the subject FASTA file (columns of the matrix).
    threshold:
        Minimum normalised value (0.0–1.0) to include as a dot-point.
        Default ``0.0`` keeps all points.

    Returns
    -------
    dict with keys:
        ``'df'``      — :class:`pandas.DataFrame` with columns ``['x', 'y', 'value']``
        ``'x_label'`` — subject sequence axis label (X axis)
        ``'y_label'`` — query sequence axis label (Y axis)
        ``'x_range'`` — ``(0, subject_length)``
        ``'y_range'`` — ``(0, query_length)``
    """
    if not _RUST_AVAILABLE:
        raise ImportError(
            "fastdpplot._rs is not available. "
            "Run `maturin develop` to build the Rust extension first."
        )

    xs, ys, vals, y_label, x_label, query_len, subject_len = _load_dp_input(
        matrix_path, fasta_a, fasta_b, threshold
    )
    df = pd.DataFrame({"x": xs, "y": ys, "value": vals})
    return {
        "df": df,
        "x_label": x_label,
        "y_label": y_label,
        "x_range": (0, subject_len),
        "y_range": (0, query_len),
    }
