"""Panel server entry point for interactive fastdpplot visualisation.

Usage::

    python -m fastdpplot.server --input data.parquet --port 5006

or from Python::

    from fastdpplot.server import run
    run("data.parquet", port=5006)
"""

from __future__ import annotations

import argparse

from fastdpplot.io import load, load_bin
from fastdpplot.plot import serve_interactive


def run(path: str, port: int = 5006, title: str = "fastdpplot", **load_kwargs) -> None:
    """Load *path* and start the Panel interactive server on *port*."""
    df = load(path, **load_kwargs)
    serve_interactive(df, port=port, title=title)


def run_bin(
    matrix_path: str,
    fasta_a: str,
    fasta_b: str,
    port: int = 5006,
    threshold: float = 0.0,
) -> None:
    """Load a binary DP matrix + FASTA files and start the Panel server.

    The Panel window title is derived from the FASTA sequence IDs.
    """
    result = load_bin(matrix_path, fasta_a, fasta_b, threshold=threshold)
    df = result["df"]
    x_label = result["x_label"]
    y_label = result["y_label"]
    x_range = result["x_range"]
    y_range = result["y_range"]

    # Use the short IDs (before " | ") as the window title.
    query_id = y_label.split(" | ")[0].strip()
    subject_id = x_label.split(" | ")[0].strip()
    title = f"{query_id} vs {subject_id}"

    serve_interactive(
        df,
        port=port,
        title=title,
        x_label=x_label,
        y_label=y_label,
        x_range=x_range,
        y_range=y_range,
    )


def _main() -> None:
    parser = argparse.ArgumentParser(
        description="Launch the fastdpplot interactive Panel server."
    )
    parser.add_argument("--input", required=True, help="Input .parquet or .txt file")
    parser.add_argument("--port", type=int, default=5006, help="Server port (default 5006)")
    parser.add_argument("--title", default="fastdpplot", help="Browser window title")
    parser.add_argument("--sep", default="\t", help="Field separator for text input")
    parser.add_argument("--x-col", type=int, default=0, dest="x_col")
    parser.add_argument("--y-col", type=int, default=1, dest="y_col")
    parser.add_argument("--val-col", type=int, default=None, dest="val_col")
    args = parser.parse_args()

    run(
        args.input,
        port=args.port,
        title=args.title,
        sep=args.sep,
        x_col=args.x_col,
        y_col=args.y_col,
        val_col=args.val_col,
    )


if __name__ == "__main__":
    _main()
