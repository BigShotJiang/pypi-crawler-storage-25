from fastdpplot.io import load
from fastdpplot.plot import render_static, serve_interactive
