"""Sparse-matrix conversion utilities backed by the Rust extension."""

from __future__ import annotations

import numpy as np

try:
    from fastdpplot._rs import to_coo as _to_coo  # type: ignore
    _RUST_AVAILABLE = True
except ImportError:
    _RUST_AVAILABLE = False


def to_scipy_sparse(
    counts: "np.ndarray",
    values: "np.ndarray",
    shape: tuple[int, int],
):
    """Convert flat binning output arrays to a ``scipy.sparse.csr_matrix``.

    Parameters
    ----------
    counts:
        1-D array of per-bin counts with length ``shape[0] * shape[1]``,
        as returned by ``fastdpplot._rs.bin_points``.
    values:
        1-D array of per-bin mean values (same length as *counts*).
    shape:
        ``(height, width)`` of the bin grid.

    Returns
    -------
    scipy.sparse.csr_matrix
        Sparse matrix of shape *shape* containing mean values for non-zero bins.
    """
    import scipy.sparse as sp

    if not _RUST_AVAILABLE:
        raise ImportError(
            "fastdpplot._rs is not available. "
            "Run `maturin develop` to build the Rust extension first."
        )

    height, width = shape
    counts_u32 = np.asarray(counts, dtype=np.uint32)
    values_f32 = np.asarray(values, dtype=np.float32)
    rows, cols, data = _to_coo(
        counts_u32.tolist(),
        values_f32.tolist(),
        width,
        height,
    )
    return sp.csr_matrix((data, (rows, cols)), shape=shape)
