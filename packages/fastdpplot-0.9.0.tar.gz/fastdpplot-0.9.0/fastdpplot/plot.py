"""Rendering module for fastdpplot.

Three rendering modes are provided:

1. ``render_static``  — high-res publication output (datashader → matplotlib → PNG/SVG).
2. ``serve_interactive`` — Panel server with live pan/zoom via Rust binning.
3. ``show``           — inline Jupyter display via datashader + Bokeh.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

# Try to import GPU-accelerated DataFrame; fall back to pandas silently.
try:
    import cudf  # type: ignore

    _DataFrame = cudf.DataFrame
except ImportError:
    cudf = None  # type: ignore
    _DataFrame = pd.DataFrame


def _to_fast_df(df: pd.DataFrame):
    """Return cuDF DataFrame if available, otherwise plain pandas."""
    if cudf is not None:
        return cudf.DataFrame.from_pandas(df)
    return df


# ---------------------------------------------------------------------------
# Colourmap helpers
# ---------------------------------------------------------------------------


def _dp_colormap():
    """Return a matplotlib colormap optimized for DP score matrices.

    Dark background → bright path: near-black → navy → teal → cyan → gold → white.
    This makes the DP alignment path "glow" against the low-score background.
    """
    import matplotlib.colors as mcolors

    colors = [
        "#0a0a0f",  # near-black  (score ≈ 0, background noise)
        "#0d1b4b",  # dark navy
        "#0b4f6c",  # deep teal-blue
        "#01baef",  # bright cyan  (mid-range scores)
        "#f4d03f",  # gold         (high scores, path begins to emerge)
        "#ffffff",  # white        (peak score, alignment path)
    ]
    return mcolors.LinearSegmentedColormap.from_list("dp_path", colors, N=512)


def _dp_colormap_hex(n: int = 256) -> list[str]:
    """Return *n* hex colour strings from the DP colormap.

    Used by datashader ``datashade(..., cmap=...)`` which requires a list of
    hex strings rather than a matplotlib colormap object.

    Parameters
    ----------
    n:
        Number of colour stops.  Must be ≥ 2.

    Raises
    ------
    ValueError
        If *n* is less than 2.
    """
    if n < 2:
        raise ValueError(f"n must be >= 2, got {n}")
    import matplotlib.colors as mcolors

    cmap = _dp_colormap()
    return [mcolors.to_hex(cmap(i / (n - 1))) for i in range(n)]


def _resolve_cmap(name: str | None, as_hex: bool = False):
    """Resolve a colormap name to either a matplotlib object or a hex list.

    ``None`` or ``"dp"`` → the DP path colormap.
    Any other string     → looked up via :func:`matplotlib.pyplot.get_cmap`.

    Parameters
    ----------
    name:
        Colormap name (or ``None`` / ``"dp"`` for the built-in DP scheme).
    as_hex:
        When *True* return a ``list[str]`` of hex colours (for datashader);
        when *False* return a matplotlib colormap object (for ``tf.shade``).
    """
    import matplotlib.colors as mcolors
    import matplotlib.pyplot as plt

    if name is None or name == "dp":
        return _dp_colormap_hex() if as_hex else _dp_colormap()
    cmap_obj = plt.get_cmap(name)
    if as_hex:
        return [mcolors.to_hex(cmap_obj(i / 255)) for i in range(256)]
    return cmap_obj


# ---------------------------------------------------------------------------
# 1. Static high-res rendering
# ---------------------------------------------------------------------------


def render_static(
    df: pd.DataFrame,
    output_path: str,
    width: int = 4000,
    height: int = 4000,
    dpi: int = 300,
    cmap: str | None = "dp",
    x_label: str | None = None,
    y_label: str | None = None,
    x_range: tuple | None = None,
    y_range: tuple | None = None,
) -> None:
    """Rasterize *df* with datashader and save to *output_path* (PNG or SVG).

    Parameters
    ----------
    df:
        DataFrame with columns ``x``, ``y``, ``value``.
    output_path:
        Destination file path.  The extension determines the format
        (``.png`` or ``.svg``).
    width, height:
        Canvas resolution in pixels.
    dpi:
        Output DPI (PNG only).
    cmap:
        Colourmap name.  ``None`` or ``"dp"`` selects the built-in DP path
        colormap.  Any other string is resolved via
        :func:`matplotlib.pyplot.get_cmap`.
    x_label:
        X-axis label (e.g. subject sequence ID from ``load_bin``).
    y_label:
        Y-axis label (e.g. query sequence ID from ``load_bin``).
    x_range:
        ``(x_min, x_max)`` axis limits — required; pass ``result['x_range']``
        (or the data-derived min/max for non-DP inputs).
    y_range:
        ``(y_min, y_max)`` axis limits — required; pass ``result['y_range']``
        (or the data-derived min/max for non-DP inputs).

    Raises
    ------
    ValueError
        If *x_range* or *y_range* is ``None``.
    """
    import datashader as ds
    import datashader.transfer_functions as tf
    import matplotlib.pyplot as plt

    if x_range is None or y_range is None:
        raise ValueError(
            "x_range and y_range are required — pass result['x_range'] and result['y_range']"
        )

    x_min, x_max = x_range  # (0, subject_len)
    y_min, y_max = y_range  # (0, query_len)

    fast_df = _to_fast_df(df)

    # Datashader canvas bounded exactly to sequence extents.
    cvs = ds.Canvas(
        plot_width=width,
        plot_height=height,
        x_range=(x_min, x_max),
        y_range=(y_min, y_max),
    )
    agg = cvs.points(fast_df, "x", "y", ds.mean("value"))
    cmap_obj = _resolve_cmap(cmap, as_hex=False)
    img = tf.shade(agg, cmap=cmap_obj, how="linear")

    # Convert datashader RGBA image to numpy array for matplotlib.
    rgba = np.array(img.to_pil())

    fig, ax = plt.subplots(figsize=(width / dpi, height / dpi), dpi=dpi)
    # extent maps pixel space back to sequence coordinates;
    # origin="lower" places row 0 of the array at the bottom (standard alignment
    # dotplot convention: origin at bottom-left, diagonal runs bottom-left → top-right).
    ax.imshow(
        rgba,
        origin="lower",                        # row 0 of array at bottom
        extent=[x_min, x_max, y_min, y_max],  # [left, right, bottom, top]
        aspect="equal",
        interpolation="nearest",
    )

    # Axis limits — hard-clamped to sequence length, zero-origin.
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)  # 0 at bottom, query_len at top

    # Ticks: ~10 evenly spaced positions across the full sequence range.
    x_ticks = np.round(np.linspace(x_min, x_max, 10)).astype(int)
    y_ticks = np.round(np.linspace(y_min, y_max, 10)).astype(int)
    ax.set_xticks(x_ticks)
    ax.set_xticklabels([str(v + 1) for v in x_ticks], fontsize=7, rotation=45)
    ax.set_yticks(y_ticks)
    ax.set_yticklabels([str(v + 1) for v in y_ticks], fontsize=7)

    if x_label:
        ax.set_xlabel(x_label, fontsize=10, labelpad=6)
    if y_label:
        ax.set_ylabel(y_label, fontsize=10, labelpad=6)

    title_parts = [p for p in (y_label, x_label) if p]
    if title_parts:
        ax.set_title("  vs  ".join(title_parts), fontsize=9, pad=8)

    plt.tight_layout()

    if output_path.endswith(".svg"):
        fig.savefig(output_path, format="svg", bbox_inches="tight")
    else:
        fig.savefig(output_path, format="png", dpi=dpi, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------------------
# 2. Interactive Panel server
# ---------------------------------------------------------------------------


def serve_interactive(
    df: pd.DataFrame,
    port: int = 5006,
    title: str = "fastdpplot",
    x_label: str | None = None,
    y_label: str | None = None,
    x_range: tuple | None = None,
    y_range: tuple | None = None,
) -> None:
    """Launch a Panel server with live pan/zoom backed by Rust binning.

    Each ``RangeXY`` event re-bins the visible viewport via
    ``fastdpplot._rs.bin_points``, reconstructs a small DataFrame, and
    re-renders with datashader.

    Parameters
    ----------
    df:
        DataFrame with columns ``x``, ``y``, ``value``.
    port:
        TCP port for the Panel server.
    title:
        Browser tab / window title.
    x_label:
        X-axis label (subject sequence).
    y_label:
        Y-axis label (query sequence).
    x_range:
        ``(x_min, x_max)`` viewport limits; defaults to data range.
    y_range:
        ``(y_min, y_max)`` viewport limits; defaults to data range.
    """
    import datashader as ds
    import holoviews as hv
    import panel as pn
    from bokeh.models import CustomJSHover, HoverTool
    from holoviews import streams
    from holoviews.operation.datashader import rasterize

    try:
        from fastdpplot._rs import bin_points_py as _bin_points  # type: ignore
        _rust_available = True
    except ImportError:
        _rust_available = False

    hv.extension("bokeh")
    pn.extension(sizing_mode="stretch_both")  # all components stretch to fill

    xs = df["x"].to_numpy(dtype=float)
    ys = df["y"].to_numpy(dtype=float)
    vs = df["value"].to_numpy(dtype="float32")

    x_min = float(x_range[0]) if x_range is not None else float(xs.min())
    x_max = float(x_range[1]) if x_range is not None else float(xs.max())
    y_min = float(y_range[0]) if y_range is not None else float(ys.min())
    y_max = float(y_range[1]) if y_range is not None else float(ys.max())

    canvas_w, canvas_h = 800, 800

    # Pre-compute lists once so every zoom event avoids an O(N) copy.
    if _rust_available:
        xs_list = xs.tolist()
        ys_list = ys.tolist()
        vs_list = vs.tolist()

    range_stream = streams.RangeXY(
        x_range=(x_min, x_max),
        y_range=(y_min, y_max),
    )

    def make_points(x_range, y_range):
        if x_range is None or y_range is None:
            x_range = (x_min, x_max)
            y_range = (y_min, y_max)

        if _rust_available:
            counts_flat, values_flat = _bin_points(
                xs_list,
                ys_list,
                vs_list,
                float(x_range[0]),
                float(x_range[1]),
                float(y_range[0]),
                float(y_range[1]),
                canvas_w,
                canvas_h,
            )
            # Reconstruct a small DataFrame from bin centres.
            bx = np.tile(
                np.linspace(x_range[0], x_range[1], canvas_w), canvas_h
            )
            by = np.repeat(
                np.linspace(y_range[0], y_range[1], canvas_h), canvas_w
            )
            mask = np.array(counts_flat) > 0
            small_df = pd.DataFrame(
                {"x": bx[mask], "y": by[mask], "value": np.array(values_flat)[mask]}
            )
        else:
            mask = (
                (df["x"] >= x_range[0])
                & (df["x"] <= x_range[1])
                & (df["y"] >= y_range[0])
                & (df["y"] <= y_range[1])
            )
            small_df = df[mask]

        return hv.Points(small_df, kdims=["x", "y"], vdims=["value"])

    dmap = hv.DynamicMap(make_points, streams=[range_stream])

    # Formatters: convert 0-based internal coords → 1-based display; score to 2dp.
    pos_formatter = CustomJSHover(code="return (Math.round(value) + 1).toString();")
    score_formatter = CustomJSHover(code="return value.toFixed(2);")

    hover = HoverTool(
        tooltips=[
            ("Seq A (query)",   "@y"),
            ("Seq B (subject)", "@x"),
            ("Score",           "@image"),
        ],
        formatters={
            "@y":     pos_formatter,
            "@x":     pos_formatter,
            "@image": score_formatter,
        },
        point_policy="snap_to_data",
    )

    opts = {
        "xlim":          (x_min, x_max),   # subject: 0 → subject_len, left to right
        "ylim":          (y_min, y_max),   # query:   0 → query_len,   BOTTOM to TOP
        "tools":         ["pan", "wheel_zoom", "box_zoom", "reset", "save", hover],
        "active_tools":  ["wheel_zoom"],
        "xaxis":         "bottom",
        "yaxis":         True,
        "fontsize":      {"labels": "11pt", "ticks": "9pt"},
        "responsive":    True,
        "invert_yaxis":  False,            # explicit — do NOT invert, 0 must stay at bottom
        "cmap":          _resolve_cmap("dp", as_hex=False),
        "clim":          (0.0, 1.0),
        "colorbar":      True,
        "colorbar_opts": {"title": "DP Score"},
    }
    if x_label:
        opts["xlabel"] = x_label
    if y_label:
        opts["ylabel"] = y_label
    title_parts = [p for p in (y_label, x_label) if p]
    if title_parts:
        opts["title"] = "  ·  ".join(title_parts)

    rasterized = rasterize(
        dmap,
        aggregator=ds.mean("value"),
        dynamic=True,
        width=canvas_w,
        height=canvas_h,
    )

    shaded = rasterized.opts(hv.opts.Image(**opts))

    fullscreen_css = """
    <style>
    html, body {
        margin: 0; padding: 0;
        width: 100vw; height: 100vh;
        overflow: hidden;
        background: #0a0a0f;
    }
    .bk-root {
        width: 100vw !important;
        height: 100vh !important;
    }
    .bk-canvas-events, canvas.bk-canvas {
        width: 100% !important;
        height: 100% !important;
    }
    </style>
    """

    layout = pn.Column(
        pn.pane.HTML(fullscreen_css),
        pn.pane.HoloViews(shaded, sizing_mode="stretch_both"),
        sizing_mode="stretch_both",
        margin=0,
        styles={"background": "#0a0a0f"},
    )

    pn.serve(
        layout,
        port=port,
        title=title,
        show=False,
    )


# ---------------------------------------------------------------------------
# 3. Jupyter inline display
# ---------------------------------------------------------------------------


def show(
    df: pd.DataFrame,
    width: int = 800,
    height: int = 800,
    cmap: str | None = "dp",
    x_label: str | None = None,
    y_label: str | None = None,
    x_range: tuple | None = None,
    y_range: tuple | None = None,
) -> object:
    """Display a datashaded dotplot inline in a Jupyter notebook.

    Parameters
    ----------
    df:
        DataFrame with columns ``x``, ``y``, ``value``.
    width, height:
        Canvas size in pixels.
    cmap:
        Colourmap name.  ``None`` or ``"dp"`` selects the built-in DP path
        colormap.  Any other string is resolved via
        :func:`matplotlib.pyplot.get_cmap`.
    x_label:
        X-axis label (subject sequence).
    y_label:
        Y-axis label (query sequence).
    x_range:
        ``(x_min, x_max)`` axis limits.
    y_range:
        ``(y_min, y_max)`` axis limits.

    Returns
    -------
    A renderable Holoviews object.
    """
    import holoviews as hv
    from holoviews.operation.datashader import datashade

    hv.extension("bokeh")

    fast_df = _to_fast_df(df)
    kdims = [
        hv.Dimension("x", label=x_label or "x"),
        hv.Dimension("y", label=y_label or "y"),
    ]
    points = hv.Points(fast_df, kdims=kdims, vdims=["value"])

    x_min = float(x_range[0]) if x_range is not None else float(df["x"].min())
    x_max = float(x_range[1]) if x_range is not None else float(df["x"].max())
    y_min = float(y_range[0]) if y_range is not None else float(df["y"].min())
    y_max = float(y_range[1]) if y_range is not None else float(df["y"].max())

    opts = {
        "width": width,
        "height": height,
        "xlim": (x_min, x_max),
        "ylim": (y_min, y_max),
    }
    shaded = datashade(points, cmap=_resolve_cmap(cmap, as_hex=True)).opts(**opts)
    return shaded
