"""CrewAI-specific Mubit control client."""

from __future__ import annotations

from typing import Any, Optional

from mubit_integration_base import MubitControlClient as _Base, normalize_metadata  # noqa: F401


class MubitControlClient(_Base):
    """Mubit control client with CrewAI defaults."""

    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:3000",
        api_key: str = "",
        sdk_client: Optional[Any] = None,
    ) -> None:
        super().__init__(
            endpoint=endpoint,
            api_key=api_key,
            sdk_client=sdk_client,
            default_agent_id="crewai",
            item_id_prefix="crew",
        )
