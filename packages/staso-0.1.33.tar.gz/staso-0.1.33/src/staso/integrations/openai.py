"""Zero-code-change instrumentation for the OpenAI Python SDK."""
from __future__ import annotations

import functools
import json
import logging
import time
from typing import Any

from ..client import get_client, get_tracer
from ..context import reset_current_span, set_current_span
from ..guard import GuardBlocked
from ..types import (
    META_FREQUENCY_PENALTY,
    META_MAX_TOKENS,
    META_PRESENCE_PENALTY,
    META_PROVIDER,
    META_REASONING_TOKENS,
    META_RESPONSE_FORMAT,
    META_RESPONSE_ID,
    META_SEED,
    META_SERVICE_TIER,
    META_STOP_REASON,
    META_STOP_SEQUENCES,
    META_TEMPERATURE,
    META_TOOL_CHOICE,
    META_TOP_P,
    OPENAI_KEY_CONTENT,
    OPENAI_KEY_MESSAGES,
    OPENAI_KEY_MODEL,
    OPENAI_KEY_ROLE,
    OPENAI_KEY_TOOL_CALLS,
    OPENAI_KEY_TOOLS,
    SpanKind,
    SpanStatus,
)
from ._guard_common import evaluate_and_enforce
from ._openai_streaming import AsyncOpenAIStreamProxy, OpenAIStreamProxy

logger = logging.getLogger("staso")

# Marker we stamp on the wrapped create() so _wrap_sync / _wrap_async can
# recognise an already-wrapped function and refuse to double-wrap. The
# module-level `_patched` flag below is kept for back-compat callers that
# still flip it, but the per-function marker is the authoritative signal.
_STASO_PATCH_MARKER = "_staso_patched"
_patched = False


def _parse_tool_args(args_raw: Any) -> dict[str, Any]:
    if isinstance(args_raw, str):
        try:
            parsed = json.loads(args_raw)
        except (json.JSONDecodeError, TypeError):
            return {"raw_arguments": args_raw}
        return parsed if isinstance(parsed, dict) else {"value": parsed}
    if isinstance(args_raw, dict):
        return args_raw
    return {}


def _build_tool_call_refs(
    response_tool_calls: Any,
    dumped_tool_calls: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Zip the live OpenAI tool_call objects with their dumped dict copies so
    the shared guard helper can both read names/inputs (from the dicts) and
    mutate the live objects for ``modify`` actions (via the refs)."""
    refs: list[dict[str, Any]] = []
    live = list(response_tool_calls) if response_tool_calls else []
    for idx, tc_dict in enumerate(dumped_tool_calls):
        if not isinstance(tc_dict, dict):
            continue
        func = tc_dict.get("function") or {}
        name = func.get("name", "unknown")
        inp = _parse_tool_args(func.get("arguments", "{}"))
        ref = live[idx] if idx < len(live) else None
        refs.append({"name": name, "input": inp, "ref": ref})
    return refs


def _apply_openai_modify(ref: Any, modified_input: dict[str, Any]) -> None:
    """Rewrite the live OpenAI ``ChatCompletionMessageToolCall`` in place so
    the caller's agent loop dispatches the modified arguments."""
    if ref is None:
        return
    try:
        ref.function.arguments = json.dumps(modified_input)
    except Exception:
        logger.debug("staso: openai tool_call mutation failed", exc_info=True)


def patch_openai() -> None:
    """Monkey-patch ``openai.resources.chat.Completions.create`` (sync and async)
    to automatically emit LLM spans with comprehensive data capture.

    Safe to call multiple times -- only patches once.
    """
    global _patched
    if _patched:
        return

    try:
        from openai.resources.chat import AsyncCompletions, Completions
    except ImportError:
        raise ImportError(
            "openai package is required for this integration. "
            "Install it with: pip install 'staso[openai]'"
        )

    _wrap_sync(Completions)
    _wrap_async(AsyncCompletions)
    _patched = True
    logger.debug("staso: openai SDK patched")


def _extract_model(args: tuple, kwargs: dict) -> str:
    return str(kwargs.get("model", args[0] if args else ""))


def _capture_input(model: str, kwargs: dict) -> dict:
    """Build the span input dict from request kwargs."""
    inp: dict[str, Any] = {
        OPENAI_KEY_MODEL: model,
    }

    tools = kwargs.get("tools")
    if tools:
        inp[OPENAI_KEY_TOOLS] = tools

    client = get_client()
    if client and client.config.capture_messages:
        messages = kwargs.get("messages")
        if messages:
            inp[OPENAI_KEY_MESSAGES] = messages

    return inp


def _capture_metadata(kwargs: dict) -> dict[str, Any]:
    """Extract request parameters into metadata dict."""
    meta: dict[str, Any] = {META_PROVIDER: "openai"}

    _optional_keys = [
        ("temperature", META_TEMPERATURE),
        ("max_tokens", META_MAX_TOKENS),
        ("max_completion_tokens", META_MAX_TOKENS),
        ("top_p", META_TOP_P),
        ("frequency_penalty", META_FREQUENCY_PENALTY),
        ("presence_penalty", META_PRESENCE_PENALTY),
        ("seed", META_SEED),
        ("stop", META_STOP_SEQUENCES),
        ("tool_choice", META_TOOL_CHOICE),
        ("response_format", META_RESPONSE_FORMAT),
        ("service_tier", META_SERVICE_TIER),
    ]
    for kwarg_key, meta_key in _optional_keys:
        val = kwargs.get(kwarg_key)
        if val is not None:
            meta[meta_key] = val

    return meta


def _capture_response(span: Any, response: Any) -> None:
    """Extract response data onto span fields, then evaluate guard rules.

    Tool name extraction: tool names come from tool_call.function.name
    within response.choices[0].message.tool_calls. They are serialized
    via model_dump() into the span output dict under OPENAI_KEY_TOOL_CALLS.

    Guard evaluation happens AFTER the span data is captured but BEFORE
    returning control to the caller. If an enforce-mode rule blocks a tool
    call, ``evaluate_and_enforce`` raises ``GuardBlocked`` which propagates
    out of this function — the patched ``create()`` never returns a
    blocked response to the caller's agent loop.
    """
    tc_list: list[dict[str, Any]] = []
    live_tool_calls: Any = None
    choices = getattr(response, "choices", None)
    if choices and len(choices) > 0:
        message = getattr(choices[0], "message", None)
        if message:
            content = getattr(message, "content", None) or ""
            role = getattr(message, "role", "assistant")
            live_tool_calls = getattr(message, "tool_calls", None)

            output: dict[str, Any] = {
                OPENAI_KEY_CONTENT: content,
                OPENAI_KEY_ROLE: role,
            }
            if live_tool_calls:
                for tc in live_tool_calls:
                    if hasattr(tc, "model_dump"):
                        tc_list.append(tc.model_dump())
                    elif isinstance(tc, dict):
                        tc_list.append(tc)
                    else:
                        tc_list.append(str(tc))
                output[OPENAI_KEY_TOOL_CALLS] = tc_list
            span.output = output

        finish_reason = getattr(choices[0], "finish_reason", None)
        if finish_reason:
            span.metadata[META_STOP_REASON] = finish_reason

    response_id = getattr(response, "id", None)
    if response_id:
        span.metadata[META_RESPONSE_ID] = response_id

    usage = getattr(response, "usage", None)
    if usage:
        span.input_tokens = getattr(usage, "prompt_tokens", 0) or 0
        span.output_tokens = getattr(usage, "completion_tokens", 0) or 0
        span.total_tokens = getattr(usage, "total_tokens", 0) or 0

        details = getattr(usage, "completion_tokens_details", None)
        if details:
            reasoning = getattr(details, "reasoning_tokens", None)
            if reasoning:
                span.metadata[META_REASONING_TOKENS] = reasoning

    # Guard enforcement — raises GuardBlocked on enforce-mode blocks. Must
    # propagate so the caller's tool dispatch loop never sees a blocked
    # response.
    if tc_list:
        refs = _build_tool_call_refs(live_tool_calls, tc_list)
        evaluate_and_enforce(refs, span, apply_modify=_apply_openai_modify)


def _wrap_sync(cls: type) -> None:
    original = cls.create
    # Idempotent: refuse to wrap an already-wrapped function. Without this
    # guard, tests that flip the module-level `_patched` flag and call
    # _wrap_sync again double-wrap the class — the outer wrapper then
    # emits a span around the inner wrapper's span, producing ghost traces.
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        if kwargs.get("stream"):
            span = tracer.start_span(
                "openai.chat.completions.create", kind=SpanKind.LLM
            )
            span.model = model
            span.input = _capture_input(model, kwargs)
            span.metadata.update(_capture_metadata(kwargs))
            token = set_current_span(span)
            start_time = time.time()
            try:
                stream = original(self, *args, **kwargs)
                return OpenAIStreamProxy(stream, span, start_time, token)
            except Exception as exc:
                span.record_exception(exc)
                span.end()
                reset_current_span(token)
                raise
        else:
            with tracer.start_as_current_span(
                "openai.chat.completions.create", kind=SpanKind.LLM
            ) as span:
                span.model = model
                span.input = _capture_input(model, kwargs)
                span.metadata.update(_capture_metadata(kwargs))
                try:
                    response = original(self, *args, **kwargs)
                    _capture_response(span, response)
                    span.status = SpanStatus.OK
                    return response
                except Exception as exc:
                    span.record_exception(exc)
                    raise

    # Stamp the wrapper + stash the original so tests can unwrap and so
    # re-patching after a reset is safe.
    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.create = _traced  # type: ignore[assignment]


def _wrap_async(cls: type) -> None:
    original = cls.create
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    async def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        if kwargs.get("stream"):
            span = tracer.start_span(
                "openai.chat.completions.create", kind=SpanKind.LLM
            )
            span.model = model
            span.input = _capture_input(model, kwargs)
            span.metadata.update(_capture_metadata(kwargs))
            token = set_current_span(span)
            start_time = time.time()
            try:
                stream = await original(self, *args, **kwargs)
                return AsyncOpenAIStreamProxy(stream, span, start_time, token)
            except Exception as exc:
                span.record_exception(exc)
                span.end()
                reset_current_span(token)
                raise
        else:
            with tracer.start_as_current_span(
                "openai.chat.completions.create", kind=SpanKind.LLM
            ) as span:
                span.model = model
                span.input = _capture_input(model, kwargs)
                span.metadata.update(_capture_metadata(kwargs))
                try:
                    response = await original(self, *args, **kwargs)
                    _capture_response(span, response)
                    span.status = SpanStatus.OK
                    return response
                except Exception as exc:
                    span.record_exception(exc)
                    raise

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.create = _traced  # type: ignore[assignment]
