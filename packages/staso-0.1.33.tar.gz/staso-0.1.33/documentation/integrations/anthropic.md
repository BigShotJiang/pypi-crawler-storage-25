---
title: Anthropic Integration
description: Auto-trace every Anthropic API call -- tokens, model, latency, errors.
---

# Anthropic Integration

Auto-trace every Anthropic API call. No code changes.

## Setup

```bash
pip install "staso[anthropic]"
```

```python
import staso as st

st.init(api_key="ak_...", agent_name="my-agent")
st.integrations.patch_anthropic()
```

Done. Every call through the Anthropic SDK is now traced automatically.

## What Shows Up on the Dashboard

| Field | Example |
|-------|---------|
| Span name | `anthropic.messages.create` |
| Model | `claude-sonnet-4-20250514` |
| Input tokens | `245` |
| Output tokens | `89` |
| Total tokens | `334` |
| Latency | `1,230 ms` |
| Status | `ok` / `error` |

## Example

```python
import anthropic
import staso as st

st.init(api_key="ak_...", agent_name="my-agent")
st.integrations.patch_anthropic()

client = anthropic.Anthropic()

@st.agent(name="chat-agent")
def chat(message: str) -> str:
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": message}],
    )
    return response.content[0].text

with st.conversation("demo"):
    chat("What is observability?")

st.shutdown()
```

Dashboard:

```
chat-agent (agent)
  anthropic.messages.create (llm) -- claude-sonnet-4-20250514, 334 tokens, 1.2s
```

## Streaming

Both `client.messages.stream()` and `client.messages.create(stream=True)` are fully supported. The SDK wraps the stream to capture tokens and latency as chunks arrive:

```python
@st.agent(name="streaming-agent")
def chat(message: str) -> str:
    with client.messages.stream(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": message}],
    ) as stream:
        return stream.get_final_text()
```

Captures the full response, token usage, and time-to-first-token.

## Async

Both sync and async clients are instrumented:

```python
client = anthropic.AsyncAnthropic()

@st.agent(name="async-agent")
async def chat(message: str) -> str:
    response = await client.messages.create(...)
    return response.content[0].text
```

## What Gets Captured

**Request parameters** (stored in span metadata):
- `temperature`, `max_tokens`, `top_p`, `top_k`
- `stop_sequences`, `tool_choice`, `thinking`

**Response data**:
- Content text, tool use blocks
- Stop reason, response ID
- Token usage: input, output, total
- Cache tokens: `cache_read_input_tokens`, `cache_creation_input_tokens`

**Streaming-specific**:
- `time_to_first_token` (captured in metadata for streamed responses)

**Messages** (the full messages array) are captured in the span input by default. To disable: `st.init(..., capture_messages=False)`.

## Guard Evaluation

When guards are enabled (default), every `tool_use` block in the response is automatically evaluated against your guard rules. Results are recorded on the span metadata.

```json
{
  "guard_evaluations": [
    {
      "tool_name": "process_refund",
      "action": "block",
      "reason": "Refund exceeds $500 limit",
      "latency_ms": 45.2,
      "rules_triggered": ["max_refund_limit"]
    }
  ]
}
```

Guard evaluation in the Anthropic integration is **observational** -- it records what your rules say, but doesn't block the response. To enforce blocking, call [`guard()`](/docs/guards/integration) before executing the tool in your agent code.

To disable auto-evaluation:

```bash
export STASO_GUARD_ENABLED=false
```

See [Guards](/docs/guards/overview) for the full guide.

## Without the Integration

If you want manual control:

```python
@st.trace(name="llm_call", kind="llm")
def call_llm(prompt: str) -> str:
    response = client.messages.create(...)
    return response.content[0].text
```

You get timing and error tracking, but no automatic token/model extraction.
