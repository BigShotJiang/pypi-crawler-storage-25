---
title: Claude Code Integration
description: Trace Claude Code CLI sessions -- every turn, tool call, LLM interaction, and subagent.
---

# Claude Code Integration

Trace your Claude Code CLI sessions. Every turn, tool call, LLM interaction, and subagent shows up on your Staso dashboard -- with tokens, latency, and errors.

No code changes. One setup command.

## Setup

```bash
pip install staso
```

**Interactive** -- the wizard guides you through each step:

```bash
staso setup
```

**Or with flags** for scripted/CI setup:

```bash
staso setup --target claude-code \
  --api-key ak_... \
  --workspace my-workspace \
  --environment default \
  --agent-name my-agent
```

Start a Claude Code session. Traces flow automatically.

## What Shows Up on the Dashboard

Each conversation turn becomes a trace:

| Span | Kind | What It Captures |
|------|------|-----------------|
| **Turn** (root) | `agent` | Total duration, prompt, model, final response, aggregated token usage |
| **LLM calls** | `llm` | Model, input/output/cache tokens, content, response ID, duration |
| **Tool calls** | `tool` | Tool name, input, output, exact execution duration |
| **Subagents** | `agent` | Agent type, duration, aggregated LLM token usage |

All turns from the same Claude Code session are grouped together.

### Semantic tool rendering

Most observability tools dump tool calls as raw JSON. Staso parses every Claude Code tool into a human-readable card on your dashboard. Every input and output is rendered semantically -- diffs show highlighted changes, terminal output shows exit codes, file reads show syntax-highlighted code.

| Category | Tools | What You See |
|----------|-------|-------------|
| **File operations** | Edit, Read, Write, Glob, Grep, NotebookEdit | Inline diffs with +/- lines, syntax-highlighted file content, file search results with match counts |
| **Terminal** | Bash, PowerShell, REPL | Command with `$` prompt, stdout/stderr split, exit code badges |
| **Agent orchestration** | Agent, SendMessage, AskUserQuestion | Agent status with token/duration stats, sender-to-target routing, Q&A formatting |
| **Task management** | TaskCreate, TaskGet, TaskList, TaskUpdate, TaskStop, TodoWrite | Task lists with status icons and transitions, todo diffs highlighting changes |
| **Workflow** | Skill, EnterPlanMode, ExitPlanMode, EnterWorktree, ExitWorktree, TeamCreate, TeamDelete | Skill execution status, plan mode indicators, worktree metadata |
| **Search & web** | WebFetch, WebSearch, ToolSearch | HTTP response codes with content preview, numbered search results, tool discovery results |
| **Scheduling** | CronCreate, CronList, CronDelete, RemoteTrigger | Schedule metadata, job listings |

39 tool types total. New tools are supported as Claude Code adds them.

## Setup Options

| Flag | Default | Description |
|------|---------|-------------|
| `--api-key KEY` | *required* | Staso API key (`ak_...`). Falls back to `STASO_API_KEY` env var |
| `--workspace SLUG` | `default` | Workspace identifier |
| `--environment ENV` | `default` | Environment tag |
| `--agent-name NAME` | | Agent ID shown on dashboard |
| `--scope` | `global` | `global` writes to `~/.claude/settings.json`, `project` writes to `.claude/settings.local.json` |
| `--auto-sync` | | Auto-sync hook config on each session start |

## Scope

**Global** (default) traces every Claude Code session on your machine:

```bash
staso setup --target claude-code --api-key ak_... --scope global
```

**Project** traces only sessions in the current directory:

```bash
staso setup --target claude-code --api-key ak_... --scope project
```

## Guard Protection

Guards evaluate every tool call **before it executes**. When a guard rule triggers, the tool is blocked or its input is modified in real-time.

| Guard Action | What Claude Code Does |
|-------------|----------------------|
| **block** | Tool is prevented from running. Claude Code sees "Blocked by guard: {reason}" |
| **modify** | Tool runs with sanitized input (e.g., dangerous flags removed) |
| **audit** | Tool runs normally. A `guard:would-block` span is recorded for review |

Guard decisions create dedicated spans on your dashboard:

- `guard:blocked:Write` -- a file write was prevented
- `guard:modified:Bash` -- a command ran with modified arguments
- `guard:would-block:Edit` -- an edit would have been blocked in enforce mode

Guards are enabled by default. To disable:

```bash
# Set in your hook environment
STASO_GUARD_ENABLED=false
```

Configure guard timeout (default 10s):

```bash
STASO_GUARD_TIMEOUT=5
```

See [Guards](/docs/guards/overview) for rule configuration and the full guard guide.

## Hook Events

Claude Code provides 10 hook events for comprehensive tracing:

| Event | What It Does |
|-------|-------------|
| `SessionStart` | Initialize session state, auto-sync hooks if enabled |
| `UserPromptSubmit` | Start a new turn, record prompt and transcript position |
| `PreToolUse` | Record tool start time for duration calculation |
| `PostToolUse` | Send tool span with input, output, and precise duration |
| `PostToolUseFailure` | Send tool span with error status and error message |
| `Stop` | Parse transcript for LLM spans, send turn span with aggregated data |
| `StopFailure` | Send turn span with error status when session stops with error |
| `SubagentStart` | Record subagent start time |
| `SubagentStop` | Send subagent span with LLM data from subagent transcript |
| `SessionEnd` | Clean up session state |

## LLM Span Extraction

Claude Code hooks parse the JSONL transcript file to extract individual LLM calls. Each LLM call becomes its own span with:

- Model name (e.g. `claude-sonnet-4-20250514`)
- Input tokens, output tokens, total tokens
- Cache read tokens, cache creation tokens
- Response content and response ID
- Duration (estimated from transcript timestamps)

## Status

Check your current configuration:

```bash
staso status --target claude-code
```

## Upgrading

```bash
staso update
```

This upgrades the staso package and syncs your hook configuration. Or manually:

```bash
pip install -U staso
staso sync
```

To enable automatic syncing on each session start:

```bash
staso sync --enable-auto-sync
```

## Uninstalling

Remove all Staso hooks from Claude Code and clean up state files:

```bash
staso uninstall --target claude-code
```

This removes hook entries and `STASO_*` env vars from `~/.claude/settings.json` (or `.claude/settings.local.json` for project scope) and deletes cached state files.
