---
title: Version Tracking
description: Tag every trace with the git commit and branch your agent ran on. Filter by version, compare behavior across releases, and give Staso the context it needs for code-aware diagnosis.
---

# Version Tracking

Every trace Staso records is tagged with the git commit and branch your agent was running on. This means you can filter your trace history by version, see exactly when a failure was introduced, and give Staso the source code context it needs to diagnose and fix failures.

## Zero Config in Most Environments

Staso detects your git context automatically — no configuration needed for local development or most CI platforms.

**Works out of the box on:**
- Local development (requires `git` installed)
- GitHub Actions
- GitLab CI
- CircleCI
- Bitbucket Pipelines
- Vercel, Netlify, Railway, Heroku, AWS CodeBuild, Azure DevOps

## Docker Containers

Git history is not available inside a running container. To bake version info at build time, add one line to your Dockerfile:

```dockerfile
RUN python -m staso.build_info
```

This writes a `.staso-build-info` file that the SDK reads at runtime. Run it after your code is copied in, before the container starts.

## Manual Override

If auto-detection does not pick up the right commit, set these environment variables:

```bash
STASO_VCS_COMMIT_SHA=<full 40-char sha>
STASO_VCS_BRANCH=<branch name>
STASO_VCS_REPO_URL=<repo url>        # optional
```

These take priority over all other detection methods.

## What You'll See

In the trace detail view, the root span shows a **Version** section with the branch and commit SHA. If there were uncommitted changes when the agent ran, the commit is marked with `*`.

In the traces table, you can filter by branch or commit SHA to narrow down exactly which version of your code a set of traces came from.

## Why It Matters for Self-Heal

When GitHub is connected, Staso uses the commit SHA on each trace to read your source code at the exact version the agent ran. This is what enables code-aware diagnosis — tracing failures across files and call chains, not just from the error message. See [Connect GitHub](/docs/heal/github).
