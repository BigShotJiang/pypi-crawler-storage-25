---
title: Guards
description: Evaluate agent actions before they execute. Block dangerous operations, modify risky inputs, escalate to humans.
---

# Guards

Your agent is about to refund $4,200. Or drop a database. Or email every customer in your CRM.

Guards evaluate tool calls **before they execute** and decide what happens next: allow, block, modify the input, or escalate to a human. Every decision is recorded as a span on your dashboard.

```python
from staso import guard

result = guard(tool_name="process_refund", tool_input={"amount": 4200, "customer_id": "cust-99"})

if result.action == "block":
    print(f"Blocked: {result.reason}")
elif result.action == "modify":
    # Guard sanitized the input
    tool_input = result.modified_input
```

## How It Works

1. Your agent decides to call a tool
2. `guard()` sends the tool name and input to Staso for evaluation
3. Staso runs your configured rules against the action
4. You get back a `GuardResult` with the decision

Rules are configured in your [Staso dashboard](https://staso.ai) -- no code changes needed to add, edit, or disable them.

## Four Actions

| Action | What Happens | When to Use |
|--------|-------------|-------------|
| **allow** | Tool executes normally | Action passes all rules |
| **block** | Tool is prevented from running | Dangerous or policy-violating action |
| **modify** | Tool runs with sanitized input | Input needs adjustment (PII redaction, limit capping) |
| **escalate** | Paused until a human approves or denies | High-value or ambiguous decisions |

## Where Guards Run

Guards work across every Staso integration:

| Integration | How Guards Run | What Happens on Block |
|-------------|---------------|----------------------|
| [Your own agents](/docs/guards/integration) | You call `guard()` explicitly | You decide -- raise an error, skip the tool, return a fallback |
| [Anthropic SDK](/docs/integrations/anthropic) | Auto-evaluated after each response | Guard results recorded on span metadata |
| [OpenAI SDK](/docs/integrations/openai) | Auto-evaluated after each response | Guard results recorded on span metadata |
| [Claude Code](/docs/integrations/claude-code) | Auto-evaluated before each tool | Tool blocked or input modified in real-time |
| [Codex](/docs/integrations/codex) | Auto-evaluated before each tool | Tool blocked or input modified in real-time |

## Fail-Open by Default

If the guard service is unreachable or returns an error, the tool **executes normally**. Your agent never crashes because of a guard timeout. Guard failures are logged as warnings.

## Evaluation Context Scope

Rules can evaluate at two levels:

| Scope | What It Evaluates | Best For |
|-------|-------------------|----------|
| **Tool-level** | Individual tool call — name, input, output | Granular control: block a specific action, redact PII from one call |
| **Trace-level** | Full agent execution — all spans, tool calls, and LLM responses | End-to-end validation: detect multi-step policy violations, cost escalation across a session |

Configure scope per rule in your dashboard. Tool-level is the default. Trace-level rules run after the full execution completes, giving them access to the entire conversation context.

## Audit Mode

Every rule can run in audit mode. Audit rules evaluate and record what _would_ have been blocked, but don't actually block anything. Use this to validate new rules before enforcing them.

On your dashboard, audit violations show up as `guard:would-block` spans -- so you can see exactly what would have triggered before you flip the switch.

## What's Next

- [Integration guide](/docs/guards/integration) -- add guards to your agent in 3 minutes
- [Rules and actions](/docs/guards/rules-and-actions) -- how rules work, action types, severity levels
- [Escalation](/docs/guards/escalation) -- human-in-the-loop approval workflows
