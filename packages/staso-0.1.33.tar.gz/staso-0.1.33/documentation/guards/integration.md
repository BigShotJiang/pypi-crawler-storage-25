---
title: Guard Integration
description: Add guards to your AI agent -- explicit checks, auto-evaluation with LLM integrations, and CLI agent hooks.
---

# Guard Integration

Three ways to add guards, depending on how your agent runs.

## 1. Explicit Guard Calls (Your Own Agents)

Call `guard()` before executing any tool. You control what happens with the result.

### Install

```bash
pip install staso
```

### Basic Usage

```python
import staso as st
from staso import guard

st.init(api_key="ak_...", agent_name="my-agent")

@st.tool(name="process_refund")
def process_refund(customer_id: str, amount: float) -> str:
    # Check with guard before executing
    result = guard(
        tool_name="process_refund",
        tool_input={"customer_id": customer_id, "amount": amount},
    )

    if result.action == "block":
        return f"Refund blocked: {result.reason}"

    if result.action == "modify":
        amount = result.modified_input.get("amount", amount)

    # Execute the refund
    return do_refund(customer_id, amount)

st.shutdown()
```

### With Context

Pass extra context to help rules make better decisions:

```python
result = guard(
    tool_name="send_email",
    tool_input={"to": "user@example.com", "body": body},
    context={
        "session_id": "session-abc",
        "agent_name": "outreach-agent",
        "trace_id": current_trace_id,
        "environment": "production",
    },
)
```

### Handling Every Action

```python
from staso import guard, GuardResult

result = guard(tool_name="delete_records", tool_input={"table": "users", "filter": "all"})

match result.action:
    case "allow":
        execute_tool()
    case "block":
        log.warning(f"Blocked by rule '{result.rule_name}': {result.reason}")
        return fallback_response()
    case "modify":
        execute_tool(**result.modified_input)
    case "escalate":
        notify_human(result.escalation_id)
        return "Waiting for approval"
```

### With Escalation Polling

Block execution until a human approves or denies:

```python
result = guard(
    tool_name="wire_transfer",
    tool_input={"amount": 50000, "destination": "external-account"},
    wait_for_escalation=True,           # block until human responds
    escalation_poll_interval=3.0,       # check every 3 seconds
    escalation_timeout=300.0,           # give up after 5 minutes
)

# result.action is now "allow" (approved) or "block" (denied/timeout)
```

See [Escalation](/docs/guards/escalation) for the full workflow.

### Fail-Open vs Fail-Closed

By default, `guard()` **fails open** — if the Staso backend is unreachable
(network timeout, DNS failure, 5xx storm), the call returns `action="allow"`
so a broken observability plane doesn't brick your agent.

Security-sensitive workloads can opt into **fail-closed** behaviour per
call or process-wide:

```python
# Per call — this specific check blocks on transport failure.
result = guard(
    tool_name="wire_transfer",
    tool_input={"amount": 50000},
    fail_closed=True,
)

# Process-wide — every guard() call becomes fail-closed.
# Set this before st.init(), typically in your deployment config.
# STASO_GUARD_FAIL_CLOSED=true
```

When fail-closed is active and the backend is unreachable, `guard()`
returns `GuardResult(action="block", reason="Guard unavailable (fail-closed): ...", severity="high")`
so downstream `action == "block"` branches fire normally.

**Pick the right default for your workload:**
- **Fail-open (default)**: observability first — prefer degraded
  visibility over blocked agents. Appropriate for marketing outreach,
  content generation, chatbots where a false block is worse than a
  missed audit.
- **Fail-closed**: safety first — prefer a stuck agent over an
  unchecked dangerous action. Appropriate for payments, deletions,
  production DB writes, or any tool your CFO cares about.

## 2. Automatic with LLM Integrations (Anthropic, OpenAI)

When you use `patch_anthropic()` or `patch_openai()`, guards evaluate tool calls in LLM responses automatically. No extra code.

```python
import staso as st

st.init(api_key="ak_...", agent_name="my-agent")
st.integrations.patch_anthropic()

import anthropic
client = anthropic.Anthropic()

# When the model returns a tool_use block, Staso evaluates it against your guard rules.
# Results are recorded on the span metadata as guard_evaluations.
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Process a refund for $4,200"}],
    tools=[...],
)
```

Guard evaluations show up in span metadata:

```json
{
  "guard_evaluations": [
    {
      "tool_name": "process_refund",
      "action": "block",
      "reason": "Refund exceeds $500 limit",
      "latency_ms": 45.2,
      "rules_triggered": ["max_refund_limit"]
    }
  ]
}
```

**Enforce-mode rules actually block the tool call.** When an enforce-mode
rule fires inside a `patch_openai` / `patch_anthropic` call, the SDK
raises `staso.GuardBlocked` so the agent's tool-dispatch loop cannot
execute the blocked tool. Catch it to fall back gracefully:

```python
import staso as st
from staso import GuardBlocked

try:
    response = client.messages.create(...)
except GuardBlocked as e:
    # e.blocked_tools is the full list when the LLM returned multiple
    # tool_use blocks and several were blocked at once.
    for blocked in e.blocked_tools:
        log.warning(
            "guard blocked %s: %s (rules: %s)",
            blocked.tool_name,
            blocked.result.reason,
            blocked.result.rules_triggered,
        )
    return polite_fallback()
```

The legacy "observational" behaviour — log only, never raise — was
dropped because it silently executed dangerous tools alongside a
misleading `guard:blocked:*` span.

### Disabling Auto-Evaluation

```bash
export STASO_GUARD_ENABLED=false
```

Or set `STASO_GUARD_ENABLED=false` in your environment. Guards are enabled by default.

## 3. CLI Agent Hooks (Claude Code, Codex)

Claude Code and Codex integrations evaluate guards **before every tool execution** -- and can block or modify tools in real-time.

### Setup

Guards are enabled automatically when you set up a CLI agent integration:

```bash
staso setup --target claude-code --api-key ak_...
staso setup --target codex --api-key ak_...
```

Or use the interactive wizard:

```bash
staso setup
```

No code changes. Guards run on every tool call during your CLI sessions.

### What Happens

When Claude Code or Codex is about to execute a tool:

1. Staso evaluates the tool name and input against your rules
2. **Block**: The tool is prevented from running. The agent sees a "Blocked by guard" message.
3. **Modify**: The tool runs with sanitized input (e.g., dangerous flags removed).
4. **Audit violations**: The tool runs normally, but a `guard:would-block` span is recorded.

### Dashboard Spans

Every guard decision creates a dedicated span:

| Span Name | Status | Meaning |
|-----------|--------|---------|
| `guard:blocked:Write` | `error` | Tool was prevented from running |
| `guard:modified:exec_command` | `ok` | Tool ran with modified input |
| `guard:would-block:apply_patch` | `ok` | Audit rule flagged this, but tool ran normally |

Each span includes the guard action, triggered rules, and the original tool input.

#### Codex tool names

Codex emits every hook invocation with `tool_name="Bash"` regardless of
whether the agent is actually running `apply_patch`, `update_plan`, or a
raw shell command. The SDK infers the real tool name from `tool_input`
at PreToolUse time so your guard rules can scope on specific tools —
the same way Claude Code rules already work:

| Inferred name | Triggered when `tool_input` contains… |
|---|---|
| `apply_patch` | a `patch` key, or a `command` string containing `*** Begin Patch` markers, or a `command` whose first token is `apply_patch` |
| `update_plan` | a `plan` key, or a `command` starting with `update_plan` |
| `write_file` | both `path` and `content` keys |
| `read_file` | both `path` and `mode` keys |
| `exec_command` | any other `command` string (shell fallback) |

**Migration note for existing Codex customers**: rules scoped to
`"Bash"` will stop matching once the SDK ships this inference. Re-scope
your Codex rules to the specific tool names above — the same mental
model you use for Claude Code. Staso will not silently keep matching
"Bash" just because a rule was written that way; that would preserve a
footgun for everyone else.

### Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `STASO_GUARD_ENABLED` | `true` | Set to `false` to disable guard evaluation |
| `STASO_GUARD_TIMEOUT` | `10` | Guard evaluation timeout in seconds |
| `STASO_GUARD_FAIL_CLOSED` | `false` | When `true`, transport failures return `block` instead of `allow`. See [Fail-Open vs Fail-Closed](#fail-open-vs-fail-closed). |

These are set automatically during `staso setup`. To change them, edit your hook configuration or re-run setup.

## Full Example

An agent that processes customer requests with guard protection:

```python
import staso as st
from staso import guard

st.init(api_key="ak_...", agent_name="customer-service")
st.integrations.patch_anthropic()

import anthropic

client = anthropic.Anthropic()

@st.tool(name="process_refund")
def process_refund(customer_id: str, amount: float) -> str:
    result = guard(
        tool_name="process_refund",
        tool_input={"customer_id": customer_id, "amount": amount},
        context={"environment": "production"},
    )

    if result.action == "block":
        return f"Cannot process refund: {result.reason}"

    if result.action == "escalate":
        return f"Refund of ${amount} requires manager approval (escalation: {result.escalation_id})"

    if result.action == "modify":
        amount = result.modified_input.get("amount", amount)

    return f"Refund of ${amount} processed for {customer_id}"

@st.agent(name="customer-service")
def handle_request(message: str) -> str:
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": message}],
        tools=[{
            "name": "process_refund",
            "description": "Process a customer refund",
            "input_schema": {
                "type": "object",
                "properties": {
                    "customer_id": {"type": "string"},
                    "amount": {"type": "number"},
                },
                "required": ["customer_id", "amount"],
            },
        }],
    )
    # Handle tool use in response...
    return response.content[0].text

with st.conversation("customer-jane"):
    handle_request("I want a refund of $4,200 for order #789")

st.shutdown()
```

## Next

- [Rules and actions](/docs/guards/rules-and-actions) -- how rules evaluate, action types, severity
- [Escalation](/docs/guards/escalation) -- human approval workflows
- [Configuration](/docs/configuration/options) -- all environment variables
