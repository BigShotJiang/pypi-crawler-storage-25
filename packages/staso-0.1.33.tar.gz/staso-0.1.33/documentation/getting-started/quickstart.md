---
title: Quickstart
description: Get traces flowing to Staso in under 5 minutes.
---

# Quickstart

## Install

```bash
pip install staso
```

Python 3.11+ required.

## For CLI Agents (Claude Code, Codex)

Run `staso setup` for an interactive wizard that walks you through everything:

```bash
staso setup
```

You pick your agent, enter your API key, and configure optional settings -- all with arrow-key navigation and input validation.

Or pass flags directly:

```bash
staso setup --target claude-code --api-key ak_...
```

Start a session. Traces flow automatically. No code changes needed.

## For Your Own Agents (SDK)

Three steps: initialize, decorate, shut down.

```python
import staso as st

st.init(api_key="ak_...", agent_name="my-agent")

@st.agent(name="support-agent")
def handle_request(user_message: str) -> str:
    context = search_faq(user_message)
    return generate_response(context, user_message)

@st.tool(name="search_faq")
def search_faq(query: str) -> str:
    return db.search(query)

with st.conversation("conversation-123"):
    handle_request("How do I reset my password?")

st.shutdown()
```

Every call to `handle_request` shows up on your dashboard -- which tools ran, what they returned, how long each step took, and any errors.

## Auto-Instrument LLM Calls

Trace every Anthropic or OpenAI call with one line:

```bash
pip install "staso[anthropic]"  # or "staso[openai]" or "staso[all]"
```

```python
st.integrations.patch_anthropic()  # call BEFORE creating your client
st.integrations.patch_openai()
```

Model, tokens, latency, errors -- captured automatically. Both sync and async. Streaming fully supported.

## Group by Conversation

Tie multiple agent runs together:

```python
with st.conversation("conversation-123"):
    handle_request("How do I reset my password?")
    handle_request("That didn't work")
```

## Guard Agent Actions

Evaluate tool calls before they execute. Block dangerous operations, modify risky inputs, or escalate to a human.

```python
from staso import guard

result = guard(tool_name="process_refund", tool_input={"amount": 4200})

if result.action == "block":
    print(f"Blocked: {result.reason}")
elif result.action == "modify":
    tool_input = result.modified_input
```

Guards also run automatically in CLI agent integrations (Claude Code, Codex) -- no code changes needed. See [Guards](/docs/guards/overview) for the full guide.

## Shut Down

Flush remaining traces before your process exits:

```python
st.shutdown()
```

An `atexit` hook runs as a fallback, but explicit is better.

## Full Example

```python
import staso as st

st.init(api_key="ak_...", agent_name="support-agent")
st.integrations.patch_anthropic()  # auto-trace every Anthropic call

import anthropic

@st.tool(name="search_faq")
def search_faq(query: str) -> str:
    return "To reset your password, go to Settings > Security > Reset Password."

@st.agent(name="support-agent")
def run_agent(user_message: str) -> str:
    faq = search_faq(user_message)
    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": f"Context: {faq}\n\nQuestion: {user_message}"}],
    )
    return response.content[0].text

with st.conversation("customer-jane-001"):
    print(run_agent("How do I reset my password?"))

st.shutdown()
```

On the dashboard you'll see:

```
support-agent (agent) -- total duration, status
  search_faq (tool) -- input query, returned result
  anthropic.messages.create (llm) -- model, token usage, latency
```

## CLI Commands

```bash
staso setup                                              # interactive setup wizard
staso setup     --target claude-code --api-key ak_...    # scripted setup
staso status                                             # show what's configured
staso sync                                               # sync hooks after upgrade
staso update                                             # upgrade package + sync
staso uninstall --target codex                           # remove hooks, clean up
staso version                                            # show version info
```

## Next

- [Guards](/docs/guards/overview) -- evaluate, block, and modify tool calls before execution
- [Tracing your code](/docs/guides/tracing) -- `@agent`, `@tool`, `@trace`, `st.span()`
- [Conversations](/docs/guides/conversations) -- group traces by conversation
- [Datasets](/docs/guides/datasets) -- curate traces into test data, run evals, version your benchmarks
- [LLM integrations](/docs/integrations/overview) -- auto-instrument Anthropic, OpenAI, Claude Code, Codex
- [Configuration](/docs/configuration/options) -- all options and environment variables
- [Troubleshooting](/docs/troubleshooting) -- common issues
