"""Provider abstraction for persona-based integration tests.

Thin wrapper around OpenAI and Anthropic clients. Normalises call/response
shapes across providers so persona agents stay provider-agnostic.

Adding a new provider: implement the relevant branches in get_llm_client,
llm_chat, append_to_history, and tools_for_provider, then add its default
model to _DEFAULT_MODELS.

Usage:
    from personas.common.provider import (
        get_llm_client, llm_chat, execute_tools, append_to_history,
        ToolCall, LLMResponse,
    )
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Callable

from personas.common import TokenUsage


# ---------------------------------------------------------------------------
# Provider-agnostic data structures
# ---------------------------------------------------------------------------

@dataclass
class ToolCall:
    """Provider-agnostic representation of a single tool call."""
    id: str
    name: str
    arguments: dict


@dataclass
class LLMResponse:
    """Provider-agnostic representation of an LLM response."""
    text: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)
    # raw holds the original provider response for building message history
    raw: Any = None
    usage: TokenUsage = field(default_factory=TokenUsage)


# ---------------------------------------------------------------------------
# Default models per provider
# ---------------------------------------------------------------------------

_DEFAULT_MODELS: dict[str, str] = {
    "openai": "gpt-4o-mini",
    "anthropic": "claude-haiku-4-5",
}


def default_model(provider: str) -> str:
    return _DEFAULT_MODELS.get(provider.lower(), "gpt-4o-mini")


# ---------------------------------------------------------------------------
# Client factory
# ---------------------------------------------------------------------------

def get_llm_client(provider: str) -> Any:
    """Return an initialized LLM client for the given provider.

    Also patches staso integrations so spans are captured automatically.
    """
    import staso as st

    provider = provider.lower()
    if provider == "openai":
        from openai import OpenAI
        st.integrations.patch_openai()
        return OpenAI()
    elif provider == "anthropic":
        from anthropic import Anthropic
        st.integrations.patch_anthropic()
        return Anthropic()
    else:
        raise ValueError(f"Unsupported provider: {provider!r}. Use 'openai' or 'anthropic'.")


# ---------------------------------------------------------------------------
# LLM call
# ---------------------------------------------------------------------------

def llm_chat(
    client: Any,
    provider: str,
    messages: list[dict],
    system: str,
    tools: list[dict],
    model: str | None = None,
    max_tokens: int = 1024,
    temperature: float = 0.0,
) -> LLMResponse:
    """Call the LLM and return a normalised LLMResponse.

    tools must already be in the correct provider format (use tools_for_provider).
    """
    provider = provider.lower()
    model = model or default_model(provider)

    if provider == "openai":
        oai_messages = [{"role": "system", "content": system}] + messages
        kwargs: dict[str, Any] = {
            "model": model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": oai_messages,
        }
        if tools:
            kwargs["tools"] = tools
        response = client.chat.completions.create(**kwargs)
        choice = response.choices[0]
        text = choice.message.content
        tool_calls: list[ToolCall] = []
        if choice.message.tool_calls:
            for tc in choice.message.tool_calls:
                tool_calls.append(ToolCall(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=json.loads(tc.function.arguments),
                ))
        u = response.usage
        usage = TokenUsage(input_tokens=u.prompt_tokens, output_tokens=u.completion_tokens)
        return LLMResponse(text=text, tool_calls=tool_calls, raw=response, usage=usage)

    elif provider == "anthropic":
        kwargs = {
            "model": model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": messages,
        }
        if tools:
            kwargs["tools"] = tools
        response = client.messages.create(**kwargs)
        text = None
        tool_calls = []
        for block in response.content:
            if hasattr(block, "text"):
                text = (text or "") + block.text
            if getattr(block, "type", None) == "tool_use":
                tool_calls.append(ToolCall(
                    id=block.id,
                    name=block.name,
                    arguments=block.input,
                ))
        u = response.usage
        usage = TokenUsage(input_tokens=u.input_tokens, output_tokens=u.output_tokens)
        return LLMResponse(text=text, tool_calls=tool_calls, raw=response, usage=usage)

    else:
        raise ValueError(f"Unsupported provider: {provider!r}")


# ---------------------------------------------------------------------------
# Tool execution
# ---------------------------------------------------------------------------

def execute_tools(tool_calls: list[ToolCall], tool_map: dict[str, Callable]) -> list[dict]:
    """Execute tool calls against tool_map. Returns raw result dicts.

    Results are provider-format-agnostic at this stage. Use append_to_history
    to insert them into the message list in the correct format.
    """
    results = []
    for tc in tool_calls:
        tool_fn = tool_map.get(tc.name)
        if tool_fn is None:
            results.append({
                "tool_call_id": tc.id,
                "name": tc.name,
                "content": f"Error: unknown tool '{tc.name}'",
                "is_error": True,
            })
            continue
        try:
            result = tool_fn(**tc.arguments)
            content = json.dumps(result) if isinstance(result, (dict, list)) else str(result)
            results.append({
                "tool_call_id": tc.id,
                "name": tc.name,
                "content": content,
                "is_error": False,
            })
        except Exception as exc:
            results.append({
                "tool_call_id": tc.id,
                "name": tc.name,
                "content": f"Error: {exc}",
                "is_error": True,
            })
    return results


# ---------------------------------------------------------------------------
# Message history helpers
# ---------------------------------------------------------------------------

def append_to_history(
    messages: list[dict],
    provider: str,
    response: LLMResponse,
    tool_results: list[dict],
) -> None:
    """Append assistant turn + tool results to messages in-place.

    tool_results must come from execute_tools (provider-agnostic format).
    This function handles the per-provider serialization difference.
    """
    provider = provider.lower()

    if provider == "openai":
        raw_choice = response.raw.choices[0]
        assistant_msg: dict[str, Any] = {
            "role": "assistant",
            "content": raw_choice.message.content,
        }
        if raw_choice.message.tool_calls:
            assistant_msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in raw_choice.message.tool_calls
            ]
        messages.append(assistant_msg)
        for tr in tool_results:
            messages.append({
                "role": "tool",
                "tool_call_id": tr["tool_call_id"],
                "content": tr["content"],
            })

    elif provider == "anthropic":
        messages.append({"role": "assistant", "content": response.raw.content})
        tool_result_blocks = []
        for tr in tool_results:
            block: dict[str, Any] = {
                "type": "tool_result",
                "tool_use_id": tr["tool_call_id"],
                "content": tr["content"],
            }
            if tr.get("is_error"):
                block["is_error"] = True
            tool_result_blocks.append(block)
        messages.append({"role": "user", "content": tool_result_blocks})

    else:
        raise ValueError(f"Unsupported provider: {provider!r}")


# ---------------------------------------------------------------------------
# Tool definition helpers
# ---------------------------------------------------------------------------

def tools_for_provider(canonical_tools: list[dict], provider: str) -> list[dict]:
    """Convert canonical tool definitions to the provider's expected format.

    Canonical format:
        {"name": ..., "description": ..., "parameters": {json schema}}

    OpenAI format:
        {"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}

    Anthropic format:
        {"name": ..., "description": ..., "input_schema": {json schema}}
    """
    provider = provider.lower()
    if provider == "openai":
        return [
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t["description"],
                    "parameters": t["parameters"],
                },
            }
            for t in canonical_tools
        ]
    elif provider == "anthropic":
        return [
            {
                "name": t["name"],
                "description": t["description"],
                "input_schema": t["parameters"],
            }
            for t in canonical_tools
        ]
    else:
        raise ValueError(f"Unsupported provider: {provider!r}")
