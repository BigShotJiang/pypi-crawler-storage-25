import json
from pathlib import Path
from typing import Any, Optional

from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.markdown import Markdown

from agency.core.compact import CompactState, persist_large_output
from agency.core.config import LLM_API_KEY, LLM_BASE_URL, LLM_PROVIDER, MODEL
from agency.core.hooks import HookManager
from agency.core.managers import TodoManager
from agency.core.permissions import CapabilityPermissionGate
from agency.core.prompt import SystemPromptBuilder
from agency.core.recovery import create_response_with_recovery
from agency.connectors.llm import create_llm_provider
from agency.connectors.mcp import MCPClient, MCPToolRouter, PluginLoader

from agency.capabilities.background.service import BackgroundService
from agency.capabilities.memory.service import MemoryService
from agency.capabilities.scheduler.service import SchedulerService
from agency.capabilities.skills.service import SkillService
from agency.capabilities.tasks.service import TaskService
from agency.capabilities.team.service import TeamProtocolManager, TeamService
from agency.capabilities.worktree.service import WorktreeService

from agency.tools.dispatcher import dispatch_tool_call
from agency.tools.registry import get_tool_registry
from agency.ui.progress import ProgressManager
from agency.ui.completer import AgencyCompleter
from agency.ui.pager import Pager
from agency.ui.input import create_key_bindings
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML


class AgentLoop:
    MAX_AUTONOMOUS_TURNS = 12

    def __init__(self, workdir: Path, model: Optional[str] = None, permission_mode: str = "default"):
        self.workdir = workdir.resolve()
        self.model = model or MODEL
        self.llm_provider = create_llm_provider(
            LLM_PROVIDER,
            api_key=LLM_API_KEY or None,
            base_url=LLM_BASE_URL or None,
        )
        self.permission_gate = CapabilityPermissionGate(permission_mode, confirm_handler=self._confirm_permission)

        self.todo = TodoManager()
        self.skills = SkillService(self.workdir / "skills")
        self.memory = MemoryService(self.workdir / ".memory")
        self.memory.dream.mode = permission_mode
        self.prompt_builder = SystemPromptBuilder(self.workdir)
        self.compact_state = CompactState()
        self.compact_state.workspace = self.workdir
        self.event_log_path = self.workdir / ".runtime" / "events.jsonl"
        self.event_log_path.parent.mkdir(parents=True, exist_ok=True)

        self.task_manager = TaskService(self.workdir / ".tasks")
        self.background = BackgroundService(self.workdir / ".runtime-tasks")
        self.scheduler = SchedulerService(self.workdir / ".claude" / "scheduled_tasks.json")
        self.teammates = TeamService(self.workdir / ".team")
        self.protocols = TeamProtocolManager(self.workdir / ".team" / "requests", self.workdir / ".team" / "inbox")
        self.worktrees = WorktreeService(
            self.workdir / ".worktrees",
            self.workdir / ".worktrees" / "index.json",
            task_service=self.task_manager,
        )

        self.mcp_router = MCPToolRouter()
        self.plugin_loader = PluginLoader([self.workdir])
        self.hooks = HookManager(self.workdir / ".hooks.json")

        self.console = Console(highlight=False, soft_wrap=True)
        self.history = []

        # Stream buffer for markdown rendering
        self._stream_buffer = ""

        # Initialize UI enhancements
        self.progress = ProgressManager(self.console)
        self.pager = Pager(self.console)
        self.key_bindings = create_key_bindings(self)

    def _emit_event(self, event: str, payload: dict):
        try:
            with self.event_log_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps({"event": event, "payload": payload}, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def connect_plugins(self):
        found = self.plugin_loader.scan()
        if found:
            self._print_status("system", f"plugins loaded · {', '.join(found)}")
        for server_name, config in self.plugin_loader.get_mcp_servers().items():
            mcp_client = MCPClient(
                server_name,
                config.get("command", ""),
                config.get("args", []),
                config.get("env", {}),
            )
            if mcp_client.connect():
                mcp_client.list_tools()
                self.mcp_router.register_client(mcp_client)
                self._emit_event("mcp.connected", {"server": server_name})
                self._print_status("system", f"MCP connected · {server_name}")
            else:
                self._emit_event("mcp.connect_failed", {"server": server_name})
        self.scheduler.start()
        self.hooks.run_hooks("SessionStart", {"tool_name": "session"})

    def close(self):
        self.memory.maybe_consolidate()
        for c in self.mcp_router.clients.values():
            c.disconnect()
        self.scheduler.stop()

    def build_tool_pool(self) -> list:
        native = get_tool_registry()
        native_names = {t["name"] for t in native}
        all_tools = list(native)
        for tool in self.mcp_router.get_all_tools():
            if tool["name"] not in native_names:
                all_tools.append(tool)
        return all_tools

    def normalize_tool_result(self, tool_name: str, output: str, tool_use_id: str, intent: Optional[dict] = None) -> str:
        intent = intent or self.permission_gate.normalize(tool_name, {})
        output = persist_large_output(tool_use_id, output, self.workdir)
        status = "error" if "Error:" in output or "MCP Error:" in output else "ok"
        payload = {
            "source": intent["source"],
            "server": intent.get("server"),
            "tool": intent["tool"],
            "risk": intent["risk"],
            "status": status,
            "preview": output[:500],
        }
        return json.dumps(payload, indent=2, ensure_ascii=False)

    def _inject_notifications(self):
        notifications = []
        notifications.extend(self.background.drain_notifications())
        notifications.extend(self.scheduler.drain_notifications())
        if notifications:
            self.history.append({"role": "user", "content": "\n".join(notifications)})

    @staticmethod
    def _preview_text(value: Any, limit: int = 120) -> str:
        text = str(value).replace("\n", " ").strip()
        return text if len(text) <= limit else f"{text[:limit].rstrip()}..."

    def _banner(self, tool_count: int, mcp_count: int):
        body = Text()
        body.append("workspace ", style="dim")
        body.append(str(self.workdir), style="white")
        body.append("\nmodel ", style="dim")
        body.append(str(self.model), style="cyan")
        body.append("\ntools ", style="dim")
        body.append(f"{tool_count} ({mcp_count} MCP)", style="green")
        body.append("\n\n/tools", style="bold cyan")
        body.append(" list tools    ", style="dim")
        body.append("/mcp", style="bold cyan")
        body.append(" MCP status    ", style="dim")
        body.append("/plan", style="bold cyan")
        body.append(" current plan    ", style="dim")
        body.append("exit", style="bold cyan")
        body.append(" quit", style="dim")

        self.console.print(Rule(style="grey35"))
        self.console.print(
            Panel(
                body,
                title="[bold cyan]Agency CLI[/bold cyan]",
                subtitle="[dim]autonomous coding shell[/dim]",
                border_style="grey35",
                padding=(1, 2),
            )
        )
        self.console.print(Rule(style="grey35"))

    def _print_status(self, label: str, detail: str = ""):
        style_map = {
            "assistant": "bold cyan",
            "tool": "bold yellow",
            "system": "bold blue",
            "error": "bold red",
            "success": "bold green",
        }
        style = style_map.get(label, "bold magenta")
        text = Text()
        text.append(label.upper(), style=style)
        if detail:
            text.append("  ")
            text.append(detail, style="dim")
        self.console.print(text)

    def _print_stream_text(self, text: str):
        # Accumulate text for markdown rendering
        self._stream_buffer += text
        self.console.print(text, end="")

    def _render_markdown(self, text: str):
        """Render text as markdown if it contains markdown syntax."""
        # Check for markdown syntax
        markdown_indicators = ["```", "**", "__", "# ", "## ", "### ", "- ", "* ", "> ", "|"]
        is_markdown = any(indicator in text for indicator in markdown_indicators)

        if is_markdown:
            # Print a separator before markdown
            self.console.print()
            md = Markdown(text)
            self.console.print(md)
            self.console.print()
        else:
            # Already printed via stream, just add newline
            self.console.print()

    def _print_user_prompt(self) -> str:
        # Use HTML for colored prompt
        session = PromptSession(
            message=HTML("<green>❯</green> "),
            completer=AgencyCompleter(self),
            key_bindings=self.key_bindings,
            enable_history_search=False,
            refresh_interval=0.05,
        )
        try:
            return session.prompt()
        except KeyboardInterrupt:
            return ""

    def _print_tool_catalog(self):
        self._print_status("system", "tool catalog")
        table = Table(show_header=True, header_style="bold cyan", box=None, pad_edge=False)
        table.add_column("Source", style="dim", width=8)
        table.add_column("Tool", style="white")
        table.add_column("Description", style="dim")
        for tool in self.build_tool_pool():
            source = "MCP" if tool["name"].startswith("mcp__") else "Core"
            table.add_row(source, tool["name"], str(tool.get("description", ""))[:80])
        self.pager.display_table(table, title="Tool Catalog")
        self.console.print()

    def _print_mcp_status(self):
        self._print_status("system", "MCP servers")
        if self.mcp_router.clients:
            table = Table(show_header=True, header_style="bold cyan", box=None, pad_edge=False)
            table.add_column("Server", style="bold white")
            table.add_column("Tools", style="green", justify="right")
            for name, client in self.mcp_router.clients.items():
                table.add_row(name, str(len(client.get_agent_tools())))
            self.console.print(table)
        else:
            self.console.print("[dim](no MCP servers connected)[/dim]")
        self.console.print()

    def _print_plan(self):
        self._print_status("system", "current plan")
        self.console.print(Panel(self.todo.render(), border_style="grey35", padding=(0, 1)))
        self.console.print()

    def _confirm_permission(self, intent: dict, tool_input: dict) -> bool:
        source = (
            f"{intent['source']}:{intent['server']}/{intent['tool']}"
            if intent.get("server")
            else f"{intent['source']}:{intent['tool']}"
        )
        risk = str(intent.get("risk", "unknown"))
        risk_style = "bold red" if risk == "high" else "bold yellow"
        border_style = "red" if risk == "high" else "yellow"
        title = "[bold red]High-risk permission required[/bold red]" if risk == "high" else "[bold yellow]Permission required[/bold yellow]"

        summary = Text()
        summary.append("Source ", style="dim")
        summary.append(source, style="bold white")
        summary.append("\nRisk ", style="dim")
        summary.append(risk, style=risk_style)

        content_parts = [summary, Text("\n")]
        if intent.get("tool") == "bash" and tool_input.get("command"):
            content_parts.append(Text("\nCommand\n", style="dim"))
            content_parts.append(Panel(str(tool_input.get("command", "")), border_style="grey35", padding=(0, 1)))
        else:
            preview = json.dumps(tool_input, ensure_ascii=False, indent=2)[:1000]
            content_parts.append(Text("\nInput\n", style="dim"))
            content_parts.append(Panel(preview, border_style="grey35", padding=(0, 1)))

        footer = Text()
        footer.append("y", style="bold green")
        footer.append(" allow once    ", style="dim")
        footer.append("a", style="bold cyan")
        footer.append(" allow for this session    ", style="dim")
        footer.append("n", style="bold red")
        footer.append(" deny", style="dim")
        content_parts.extend([Text("\n"), footer])

        self.console.print(
            Panel(
                Group(*content_parts),
                title=title,
                border_style=border_style,
                padding=(1, 2),
            )
        )

        answer = Prompt.ask(
            "[bold yellow]Allow this action?[/bold yellow]",
            choices=["y", "n", "a"],
            default="n",
            console=self.console,
        )
        if answer == "a":
            self.permission_gate.allow_for_session(intent)
            self._print_status("system", f"allowed for this session · {source}")
            return True
        return answer == "y"

    @staticmethod
    def _terminal_status(turn_result: dict[str, Any]) -> str:
        stop_reason = str(turn_result.get("stop_reason", "end_turn") or "end_turn")
        if stop_reason == "max_tokens":
            return "paused at token limit"
        if stop_reason == "tool_use":
            return "paused after tool use"
        return "completed"

    def run_turn(self) -> dict[str, Any]:
        self._inject_notifications()
        tools = self.build_tool_pool()
        reminder = self.todo.reminder()
        system = self.prompt_builder.build(tools, self.skills, self.memory)
        if reminder:
            system += "\n\n" + reminder

        streamed_text = False

        def _on_text_delta(text: str):
            nonlocal streamed_text
            if not text:
                return
            self._print_stream_text(text)
            streamed_text = True

        response = create_response_with_recovery(
            llm_provider=self.llm_provider,
            compact_provider=self.llm_provider,
            model=self.model,
            system=system,
            messages=self.history,
            tools=tools,
            compact_state=self.compact_state,
            on_event=self._emit_event,
            on_text_delta=_on_text_delta,
        )
        self.history.append({"role": "assistant", "content": response.content})

        if response.stop_reason != "tool_use":
            if streamed_text:
                # Clear the streamed text and render as markdown
                self._render_markdown(self._stream_buffer)
                self._stream_buffer = ""  # Clear buffer
            self.todo.note_round_without_update()
            return {
                "streamed_text": streamed_text,
                "stop_reason": response.stop_reason,
                "continued": False,
            }

        if streamed_text:
            self._render_markdown(self._stream_buffer)
            self._stream_buffer = ""  # Clear buffer
            self._print_status("assistant", "calling tools")

        results = []
        plan_updated = False
        for block in response.content:
            if block.type != "tool_use":
                continue

            tool_detail = self._preview_text(block.name)
            if block.input:
                tool_detail = f"{tool_detail} {self._preview_text(block.input, 80)}"
            self._print_status("tool", tool_detail)

            pre = self.hooks.run_hooks("PreToolUse", {"tool_name": block.name, "tool_input": block.input or {}})
            if pre["blocked"]:
                output = "Permission denied by hook"
            else:
                decision = self.permission_gate.check(block.name, block.input or {})
                try:
                    if decision["behavior"] == "deny":
                        output = f"Permission denied: {decision['reason']}"
                    elif decision["behavior"] == "ask" and not self.permission_gate.ask_user(
                        decision["intent"], block.input or {}
                    ):
                        output = f"Permission denied by user: {decision['reason']}"
                    else:
                        output = dispatch_tool_call(
                            workdir=self.workdir,
                            tool_name=block.name,
                            tool_input=block.input or {},
                            mcp_router=self.mcp_router,
                            todo=self.todo,
                            memory=self.memory,
                            skills=self.skills,
                            task_manager=self.task_manager,
                            background=self.background,
                            scheduler=self.scheduler,
                            teammates=self.teammates,
                            protocols=self.protocols,
                            worktrees=self.worktrees,
                            progress=self.progress,
                        )
                except Exception as e:
                    output = f"Error: {e}"
                post = self.hooks.run_hooks(
                    "PostToolUse",
                    {"tool_name": block.name, "tool_input": block.input or {}, "tool_output": output},
                )
                if post["messages"]:
                    output += "\n" + "\n".join(post["messages"])

            if block.name == "todo_write":
                plan_updated = True

            preview = self._preview_text(output, 200)
            result_label = "success"
            if isinstance(output, str) and ("Error:" in output or "Permission denied" in output or "MCP Error:" in output):
                result_label = "error"
            self._print_status(result_label, f"{block.name} · {preview}")
            self._emit_event("tool.executed", {"tool": block.name, "preview": str(output)[:200]})
            results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": self.normalize_tool_result(
                        block.name,
                        str(output),
                        block.id,
                        self.permission_gate.normalize(block.name, block.input or {}),
                    ),
                }
            )

        if plan_updated:
            self.todo.rounds_since_update = 0
        else:
            self.todo.note_round_without_update()
        self.history.append({"role": "user", "content": results})
        if streamed_text:
            self._print_status("assistant", "continuing after tool results")
        return {
            "streamed_text": streamed_text,
            "stop_reason": response.stop_reason,
            "continued": True,
        }

    def repl(self):
        tool_count = len(self.build_tool_pool())
        mcp_count = len(self.mcp_router.get_all_tools())
        self._banner(tool_count, mcp_count)

        while True:
            try:
                query = self._print_user_prompt()
            except (EOFError, KeyboardInterrupt):
                self.console.print()
                self._print_status("system", "session closed")
                break

            command = query.strip().lower()

            if command in {"/exit", "/quit", ":q"}:
                self._print_status("system", "bye")
                break

            if not command:
                continue

            if command == "/tools":
                self._print_tool_catalog()
                continue

            if command == "/mcp":
                self._print_mcp_status()
                continue

            if command == "/plan":
                self._print_plan()
                continue

            self.history.append({"role": "user", "content": query})
            autonomous_turns = 0

            while True:
                if autonomous_turns >= self.MAX_AUTONOMOUS_TURNS:
                    self._print_status(
                        "assistant",
                        f"stopped after {self.MAX_AUTONOMOUS_TURNS} autonomous turns; send another instruction to continue",
                    )
                    break

                autonomous_turns += 1
                turn_result = self.run_turn()
                response_content = self.history[-1]["content"]
                if isinstance(response_content, list) and not turn_result.get("streamed_text"):
                    for block in response_content:
                        if hasattr(block, "text"):
                            self.console.print(block.text)
                if not turn_result.get("continued"):
                    self._print_status("assistant", self._terminal_status(turn_result))
                    break

            self.console.print()
