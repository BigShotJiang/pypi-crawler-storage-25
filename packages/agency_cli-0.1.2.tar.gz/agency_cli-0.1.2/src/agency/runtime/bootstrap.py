from pathlib import Path

from .agent_loop import AgentLoop


def create_agent(workspace: Path, model: str, permission_mode: str) -> AgentLoop:
    return AgentLoop(workspace, model=model, permission_mode=permission_mode)
