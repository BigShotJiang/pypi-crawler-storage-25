from dataclasses import dataclass, field

from agency.core.compact import CompactState


@dataclass
class RuntimeSession:
    history: list = field(default_factory=list)
    compact_state: CompactState = field(default_factory=CompactState)
    metadata: dict = field(default_factory=dict)
