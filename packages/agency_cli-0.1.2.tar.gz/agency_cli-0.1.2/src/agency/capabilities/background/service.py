import json
import threading
import uuid
from pathlib import Path
from queue import Empty, Queue

from agency.core.config import RUNTIME_DIR


class BackgroundService:
    def __init__(self, runtime_dir: Path = RUNTIME_DIR):
        self.dir = runtime_dir
        self.dir.mkdir(parents=True, exist_ok=True)
        self.tasks = {}
        self.notifications = Queue()

    def _record_path(self, task_id: str) -> Path:
        return self.dir / f"{task_id}.json"

    def _output_path(self, task_id: str) -> Path:
        return self.dir / f"{task_id}.log"

    def _persist(self, task_id: str):
        self._record_path(task_id).write_text(
            json.dumps(self.tasks[task_id], indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def run(self, command: str, cwd: Path) -> str:
        task_id = str(uuid.uuid4())[:8]
        output_file = self._output_path(task_id)
        self.tasks[task_id] = {
            "id": task_id,
            "status": "running",
            "command": command,
            "result_preview": "",
            "output_file": str(output_file),
        }
        self._persist(task_id)
        th = threading.Thread(target=self._execute, args=(task_id, command, cwd), daemon=True)
        th.start()
        return f"Background task {task_id} started: {command[:80]}"

    def _execute(self, task_id: str, command: str, cwd: Path):
        import subprocess
        import time

        try:
            r = subprocess.run(
                command,
                shell=True,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=300,
            )
            output = (r.stdout + r.stderr).strip()[:50000]
            status = "completed" if r.returncode == 0 else "error"
        except subprocess.TimeoutExpired:
            output = "Error: Timeout (300s)"
            status = "timeout"
        except Exception as e:
            output = f"Error: {e}"
            status = "error"

        output_file = self._output_path(task_id)
        output_file.write_text(output, encoding="utf-8")
        task = self.tasks[task_id]
        task["status"] = status
        task["finished_at"] = time.time()
        task["result_preview"] = " ".join(output.split())[:500]
        self._persist(task_id)
        self.notifications.put({"task_id": task_id, "status": status, "preview": task["result_preview"]})

    def list_all(self) -> str:
        return json.dumps(list(self.tasks.values()), indent=2)

    def get(self, task_id: str) -> str:
        if task_id in self.tasks:
            return json.dumps(self.tasks[task_id], indent=2)
        rec = self._record_path(task_id)
        if rec.exists():
            return rec.read_text(encoding="utf-8")
        return f"Error: background task {task_id} not found"

    def drain_notifications(self) -> list:
        out = []
        while True:
            try:
                item = self.notifications.get_nowait()
                out.append(
                    f"[Background complete] {item['task_id']} status={item['status']} preview={item['preview']}"
                )
            except Empty:
                break
        return out
