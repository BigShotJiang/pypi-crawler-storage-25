import json
import os
import time
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from queue import Empty, Queue

from agency.core.config import AUTO_EXPIRY_DAYS, JITTER_OFFSET_MAX, SCHEDULED_TASKS_FILE


class CronLock:
    def __init__(self, lock_path: Path):
        self._lock_path = lock_path

    def acquire(self) -> bool:
        if self._lock_path.exists():
            try:
                stored_pid = int(self._lock_path.read_text().strip())
                os.kill(stored_pid, 0)
                return False
            except Exception:
                pass
        self._lock_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock_path.write_text(str(os.getpid()), encoding="utf-8")
        return True

    def release(self):
        try:
            if self._lock_path.exists():
                self._lock_path.unlink()
        except Exception:
            pass


def _field_matches(field: str, value: int) -> bool:
    if field == "*":
        return True
    for part in field.split(","):
        if part.startswith("*/"):
            step = int(part[2:])
            if step > 0 and value % step == 0:
                return True
        elif "-" in part:
            a, b = part.split("-", 1)
            if int(a) <= value <= int(b):
                return True
        else:
            try:
                if int(part) == value:
                    return True
            except ValueError:
                pass
    return False


def cron_matches(expr: str, dt: datetime) -> bool:
    fields = expr.strip().split()
    if len(fields) != 5:
        return False
    cron_dow = (dt.weekday() + 1) % 7
    values = [dt.minute, dt.hour, dt.day, dt.month, cron_dow]
    for field, value in zip(fields, values):
        if not _field_matches(field, value):
            return False
    return True


class SchedulerService:
    def __init__(self, tasks_file: Path = SCHEDULED_TASKS_FILE):
        self.tasks_file = tasks_file
        self.tasks_file.parent.mkdir(parents=True, exist_ok=True)
        self.notifications = Queue()
        self.lock = CronLock(self.tasks_file.parent / "cron.lock")
        self.tasks = self._load()
        self._stop = False
        self._thread = None

    def _load(self) -> list:
        if not self.tasks_file.exists():
            return []
        try:
            return json.loads(self.tasks_file.read_text(encoding="utf-8"))
        except Exception:
            return []

    def _save(self):
        self.tasks_file.write_text(json.dumps(self.tasks, indent=2), encoding="utf-8")

    def create(self, cron: str, prompt: str, one_shot: bool = False, durable: bool = True) -> str:
        task = {
            "id": str(uuid.uuid4())[:8],
            "cron": cron,
            "prompt": prompt,
            "one_shot": bool(one_shot),
            "durable": bool(durable),
            "status": "active",
            "created_at": time.time(),
            "last_run": None,
            "jitter": int(uuid.uuid4().int % (JITTER_OFFSET_MAX + 1)),
        }
        self.tasks.append(task)
        self._save()
        return json.dumps(task, indent=2)

    def list_all(self) -> str:
        return json.dumps(self.tasks, indent=2)

    def delete(self, schedule_id: str) -> str:
        before = len(self.tasks)
        self.tasks = [t for t in self.tasks if t["id"] != schedule_id]
        self._save()
        return f"Deleted {before - len(self.tasks)} schedule(s)"

    def start(self):
        import threading

        if self._thread and self._thread.is_alive():
            return
        if not self.lock.acquire():
            return
        self._stop = False
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop = True
        if self._thread:
            self._thread.join(timeout=1)
        self.lock.release()

    def _loop(self):
        while not self._stop:
            now = datetime.now()
            changed = False
            for task in self.tasks:
                if task.get("status") != "active":
                    continue
                created = datetime.fromtimestamp(task.get("created_at", time.time()))
                if now - created > timedelta(days=AUTO_EXPIRY_DAYS):
                    task["status"] = "expired"
                    changed = True
                    continue
                check_dt = now - timedelta(minutes=task.get("jitter", 0))
                if cron_matches(task["cron"], check_dt):
                    last = task.get("last_run")
                    if last and time.time() - last < 50:
                        continue
                    task["last_run"] = time.time()
                    self.notifications.put(
                        f"[Scheduled task trigger] id={task['id']} prompt={task['prompt']}"
                    )
                    if task.get("one_shot"):
                        task["status"] = "completed"
                    changed = True
            if changed:
                self._save()
            time.sleep(1)

    def drain_notifications(self) -> list:
        out = []
        while True:
            try:
                out.append(self.notifications.get_nowait())
            except Empty:
                break
        return out
