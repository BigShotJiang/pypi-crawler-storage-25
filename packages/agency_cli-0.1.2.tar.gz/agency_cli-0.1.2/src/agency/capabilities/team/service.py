import json
import threading
import time
import uuid
from pathlib import Path
from typing import Optional

from agency.core.config import IDLE_TIMEOUT, INBOX_DIR, POLL_INTERVAL, REQUESTS_DIR, TEAM_DIR
from agency.capabilities.tasks.service import TaskService
from .storage import RequestStore


class MessageBus:
    VALID_TYPES = {
        "message",
        "broadcast",
        "shutdown_request",
        "shutdown_response",
        "plan_approval",
        "plan_approval_response",
    }

    def __init__(self, inbox_dir: Path = INBOX_DIR):
        self.dir = inbox_dir
        self.dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def send(self, sender: str, to: str, content: str, msg_type: str = "message", extra: dict = None) -> str:
        if msg_type not in self.VALID_TYPES:
            return f"Error: invalid message type: {msg_type}"
        msg = {
            "type": msg_type,
            "from": sender,
            "to": to,
            "content": content,
            "timestamp": time.time(),
        }
        if extra:
            msg.update(extra)
        path = self.dir / f"{to}.jsonl"
        with self._lock:
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(msg, ensure_ascii=False) + "\n")
        return f"Sent {msg_type} to {to}"

    def read_inbox(self, name: str) -> list:
        path = self.dir / f"{name}.jsonl"
        if not path.exists():
            return []
        with self._lock:
            lines = [l for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
            path.write_text("", encoding="utf-8")
        out = []
        for line in lines:
            try:
                out.append(json.loads(line))
            except Exception:
                continue
        out.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
        return out

    def broadcast(self, sender: str, content: str, teammates: list) -> str:
        count = 0
        for name in teammates:
            if name == sender:
                continue
            self.send(sender, name, content, "broadcast")
            count += 1
        return f"Broadcast to {count} teammates"


class TeamService:
    def __init__(self, team_dir: Path = TEAM_DIR):
        self.dir = team_dir
        self.dir.mkdir(parents=True, exist_ok=True)
        self.config_path = self.dir / "config.json"
        self.config = self._load_config()
        self.threads = {}
        self.shutdown_flags = {}
        self.bus = MessageBus(self.dir / "inbox")
        self.histories = {}

    def _load_config(self) -> dict:
        if self.config_path.exists():
            return json.loads(self.config_path.read_text(encoding="utf-8"))
        return {"team_name": "default", "members": []}

    def _save_config(self):
        self.config_path.write_text(json.dumps(self.config, indent=2), encoding="utf-8")

    def _member(self, name: str) -> Optional[dict]:
        for m in self.config.get("members", []):
            if m.get("name") == name:
                return m
        return None

    def _identity_block(self, name: str, role: str, team_name: str) -> dict:
        return {
            "role": "user",
            "content": f"<identity>You are '{name}', role: {role}, team: {team_name}. Continue your work.</identity>",
        }

    def _ensure_identity_context(self, name: str):
        member = self._member(name) or {}
        role = member.get("role", "teammate")
        team_name = self.config.get("team_name", "default")
        history = self.histories.setdefault(name, [])
        if history and "<identity>" in str(history[0].get("content", "")):
            return
        history.insert(0, self._identity_block(name, role, team_name))
        history.insert(1, {"role": "assistant", "content": f"I am {name}. Continuing."})

    def spawn(self, name: str, role: str, system_prompt: str = "") -> str:
        members = {m["name"]: m for m in self.config.get("members", [])}
        members[name] = {
            "name": name,
            "role": role,
            "status": "idle",
            "system": system_prompt,
            "spawned_at": time.time(),
        }
        self.config["members"] = list(members.values())
        self._save_config()
        self.shutdown_flags[name] = False
        self.histories.setdefault(name, [])
        self._ensure_identity_context(name)

        if name not in self.threads or not self.threads[name].is_alive():
            t = threading.Thread(target=self._loop, args=(name,), daemon=True)
            self.threads[name] = t
            t.start()
        return f"Spawned teammate {name} ({role})"

    def list_members(self) -> str:
        return json.dumps(self.config.get("members", []), indent=2)

    def _set_status(self, name: str, status: str):
        member = self._member(name)
        if member is not None:
            member["status"] = status
            member["status_at"] = time.time()
            self._save_config()

    def _loop(self, name: str):
        tasks = TaskService(self.dir.parent / ".tasks")
        idle_since = time.time()
        self._ensure_identity_context(name)

        while not self.shutdown_flags.get(name, False):
            member = self._member(name) or {}
            role = member.get("role", "")

            inbox = self.bus.read_inbox(name)
            if inbox:
                idle_since = time.time()
                self._set_status(name, "working")
                self._ensure_identity_context(name)
                history = self.histories.setdefault(name, [])
                for msg in inbox:
                    history.append({"role": "user", "content": f"[inbox:{msg.get('type','message')}] {msg.get('content','')}"})
                self._set_status(name, "idle")
                continue

            claimed = tasks.claim_next_available(name, role=role, source="autonomous")
            if claimed:
                idle_since = time.time()
                self._set_status(name, "working")
                self._ensure_identity_context(name)
                tasks.update(claimed["id"], status="completed")
                self._set_status(name, "idle")
                continue

            if time.time() - idle_since > IDLE_TIMEOUT:
                break
            self._set_status(name, "idle")
            time.sleep(POLL_INTERVAL)

        self._set_status(name, "shutdown")


class TeamProtocolManager:
    def __init__(self, requests_dir: Path = REQUESTS_DIR, inbox_dir: Path = INBOX_DIR):
        self.bus = MessageBus(inbox_dir)
        self.requests = RequestStore(requests_dir)

    def request_shutdown(self, sender: str, target: str, reason: str = "") -> str:
        request_id = str(uuid.uuid4())[:8]
        record = {
            "request_id": request_id,
            "type": "shutdown",
            "from": sender,
            "to": target,
            "reason": reason,
            "status": "pending",
            "timestamp": time.time(),
        }
        rec = self.requests.create(record)
        self.bus.send(sender, target, reason or "Shutdown requested", "shutdown_request", {"request_id": request_id})
        return json.dumps(rec, indent=2)

    def respond_shutdown(self, responder: str, request_id: str, approve: bool, note: str = "") -> str:
        rec = self.requests.update(
            request_id,
            {
                "status": "approved" if approve else "rejected",
                "responded_by": responder,
                "response_note": note,
                "responded_at": time.time(),
            },
        )
        self.bus.send(
            responder,
            rec["from"],
            note or "shutdown response",
            "shutdown_response",
            {"request_id": request_id, "approve": approve},
        )
        return json.dumps(rec, indent=2)

    def request_plan_approval(self, sender: str, approver: str, plan_text: str) -> str:
        request_id = str(uuid.uuid4())[:8]
        record = {
            "request_id": request_id,
            "type": "plan_approval",
            "from": sender,
            "to": approver,
            "plan": plan_text,
            "status": "pending",
            "timestamp": time.time(),
        }
        rec = self.requests.create(record)
        self.bus.send(sender, approver, plan_text, "plan_approval", {"request_id": request_id})
        return json.dumps(rec, indent=2)

    def respond_plan_approval(self, responder: str, request_id: str, approve: bool, note: str = "") -> str:
        rec = self.requests.update(
            request_id,
            {
                "status": "approved" if approve else "rejected",
                "responded_by": responder,
                "response_note": note,
                "responded_at": time.time(),
            },
        )
        self.bus.send(
            responder,
            rec["from"],
            note or "plan approval response",
            "plan_approval_response",
            {"request_id": request_id, "approve": approve},
        )
        return json.dumps(rec, indent=2)
