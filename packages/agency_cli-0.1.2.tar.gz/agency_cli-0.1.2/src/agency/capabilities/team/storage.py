import json
import threading
import time
from pathlib import Path
from typing import Optional

from agency.core.config import REQUESTS_DIR


class RequestStore:
    def __init__(self, base_dir: Path = REQUESTS_DIR):
        self.dir = base_dir
        self.dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _path(self, request_id: str) -> Path:
        return self.dir / f"{request_id}.json"

    def create(self, record: dict) -> dict:
        rid = record["request_id"]
        rec = {**record, "created_at": time.time(), "updated_at": time.time()}
        with self._lock:
            self._path(rid).write_text(json.dumps(rec, indent=2), encoding="utf-8")
        return rec

    def get(self, request_id: str) -> Optional[dict]:
        path = self._path(request_id)
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def update(self, request_id: str, patch: dict) -> dict:
        with self._lock:
            rec = self.get(request_id)
            if rec is None:
                raise ValueError(f"Request {request_id} not found")
            rec.update(patch)
            rec["updated_at"] = time.time()
            self._path(request_id).write_text(json.dumps(rec, indent=2), encoding="utf-8")
            return rec
