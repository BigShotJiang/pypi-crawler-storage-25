import json
import threading
import time
from pathlib import Path
from typing import Optional

from agency.core.config import CLAIM_EVENTS_PATH, TASKS_DIR


_claim_lock = threading.Lock()


class TaskService:
    def __init__(self, tasks_dir: Path = TASKS_DIR, claim_events_path: Path = None):
        self.dir = tasks_dir
        self.dir.mkdir(parents=True, exist_ok=True)
        self.claim_events_path = claim_events_path or (self.dir / CLAIM_EVENTS_PATH.name)
        self._next_id = self._max_id() + 1

    def _max_id(self) -> int:
        ids = []
        for f in self.dir.glob("task_*.json"):
            try:
                ids.append(int(f.stem.split("_")[1]))
            except Exception:
                pass
        return max(ids) if ids else 0

    def _path(self, task_id: int) -> Path:
        return self.dir / f"task_{task_id}.json"

    def _load(self, task_id: int) -> dict:
        path = self._path(task_id)
        if not path.exists():
            raise ValueError(f"Task {task_id} not found")
        return json.loads(path.read_text(encoding="utf-8"))

    def _save(self, task: dict):
        task["updated_at"] = time.time()
        self._path(task["id"]).write_text(json.dumps(task, indent=2), encoding="utf-8")

    def create(self, subject: str, description: str = "", required_role: str = "") -> str:
        with _claim_lock:
            task = {
                "id": self._next_id,
                "subject": subject,
                "description": description,
                "status": "pending",
                "blockedBy": [],
                "blocks": [],
                "owner": "",
                "worktree": "",
                "worktree_state": "unbound",
                "last_worktree": "",
                "closeout": None,
                "required_role": required_role,
                "created_at": time.time(),
                "updated_at": time.time(),
            }
            self._save(task)
            self._next_id += 1
        return json.dumps(task, indent=2)

    def get(self, task_id: int) -> str:
        return json.dumps(self._load(task_id), indent=2)

    def update(
        self,
        task_id: int,
        status: str = None,
        owner: str = None,
        add_blocked_by: list = None,
        add_blocks: list = None,
        worktree: str = None,
        worktree_state: str = None,
        last_worktree: str = None,
        closeout: dict = None,
    ) -> str:
        task = self._load(task_id)
        if owner is not None:
            task["owner"] = owner
        if worktree is not None:
            task["worktree"] = worktree
        if worktree_state is not None:
            task["worktree_state"] = worktree_state
        if last_worktree is not None:
            task["last_worktree"] = last_worktree
        if closeout is not None:
            task["closeout"] = closeout
        if status:
            if status not in ("pending", "in_progress", "completed", "deleted"):
                raise ValueError(f"Invalid status: {status}")
            task["status"] = status
            if status == "completed":
                self._clear_dependency(task_id)
        if add_blocked_by:
            task["blockedBy"] = list(set(task["blockedBy"] + add_blocked_by))
        if add_blocks:
            task["blocks"] = list(set(task["blocks"] + add_blocks))
            for blocked_id in add_blocks:
                try:
                    blocked = self._load(blocked_id)
                    if task_id not in blocked["blockedBy"]:
                        blocked["blockedBy"].append(task_id)
                        self._save(blocked)
                except ValueError:
                    pass
        self._save(task)
        return json.dumps(task, indent=2)

    def _clear_dependency(self, completed_id: int):
        for f in self.dir.glob("task_*.json"):
            task = json.loads(f.read_text(encoding="utf-8"))
            if completed_id in task.get("blockedBy", []):
                task["blockedBy"].remove(completed_id)
                self._save(task)

    def list_all(self) -> str:
        tasks = []
        for f in sorted(self.dir.glob("task_*.json")):
            tasks.append(json.loads(f.read_text(encoding="utf-8")))
        return json.dumps(tasks, indent=2)

    @staticmethod
    def _role_allowed(task: dict, role: Optional[str]) -> bool:
        required = task.get("required_role") or task.get("claim_role") or ""
        if not required:
            return True
        return bool(role) and role == required

    def claim_next_available(self, owner: str, role: Optional[str] = None, source: str = "autonomous") -> Optional[dict]:
        with _claim_lock:
            tasks = []
            for f in sorted(self.dir.glob("task_*.json")):
                task = json.loads(f.read_text(encoding="utf-8"))
                tasks.append(task)
            completed_ids = {t["id"] for t in tasks if t.get("status") == "completed"}
            for task in tasks:
                if task.get("status") != "pending" or task.get("owner"):
                    continue
                blocked = set(task.get("blockedBy", [])) - completed_ids
                if blocked:
                    continue
                if not self._role_allowed(task, role):
                    continue
                task["owner"] = owner
                task["status"] = "in_progress"
                task["claimed_at"] = time.time()
                task["claim_source"] = source
                self._save(task)
                self.claim_events_path.parent.mkdir(parents=True, exist_ok=True)
                with self.claim_events_path.open("a", encoding="utf-8") as fh:
                    fh.write(
                        json.dumps(
                            {
                                "event": "task.claimed",
                                "task_id": task["id"],
                                "owner": owner,
                                "role": role,
                                "source": source,
                                "ts": time.time(),
                            }
                        )
                        + "\n"
                    )
                return task
        return None
