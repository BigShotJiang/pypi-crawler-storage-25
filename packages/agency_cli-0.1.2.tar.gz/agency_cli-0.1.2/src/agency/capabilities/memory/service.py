import os
import re
import time
from pathlib import Path
from typing import Optional


class DreamConsolidator:
    COOLDOWN_SECONDS = 86400
    SCAN_THROTTLE_SECONDS = 600
    MIN_SESSION_COUNT = 5
    LOCK_STALE_SECONDS = 3600
    PHASES = [
        "Orient: scan MEMORY.md index for structure and categories",
        "Gather: read individual memory files for full content",
        "Consolidate: merge related memories, remove stale entries",
        "Prune: enforce 200-line limit on MEMORY.md index",
    ]

    def __init__(self, memory_dir: Path):
        self.memory_dir = memory_dir
        self.lock_file = self.memory_dir / ".dream_lock"
        self.enabled = True
        self.mode = "default"
        self.last_consolidation_time = 0.0
        self.last_scan_time = 0.0
        self.session_count = 0

    def should_consolidate(self) -> tuple:
        now = time.time()

        if not self.enabled:
            return False, "Gate 1: consolidation is disabled"
        if not self.memory_dir.exists():
            return False, "Gate 2: memory directory does not exist"

        memory_files = [f for f in self.memory_dir.glob("*.md") if f.name != "MEMORY.md"]
        if not memory_files:
            return False, "Gate 2: no memory files found"

        if self.mode == "plan":
            return False, "Gate 3: plan mode does not allow consolidation"

        time_since_last = now - self.last_consolidation_time
        if time_since_last < self.COOLDOWN_SECONDS:
            remaining = int(self.COOLDOWN_SECONDS - time_since_last)
            return False, f"Gate 4: cooldown active, {remaining}s remaining"

        time_since_scan = now - self.last_scan_time
        if time_since_scan < self.SCAN_THROTTLE_SECONDS:
            remaining = int(self.SCAN_THROTTLE_SECONDS - time_since_scan)
            return False, f"Gate 5: scan throttle active, {remaining}s remaining"

        if self.session_count < self.MIN_SESSION_COUNT:
            return False, f"Gate 6: only {self.session_count} sessions, need {self.MIN_SESSION_COUNT}"

        if not self._acquire_lock():
            return False, "Gate 7: lock held by another process"

        return True, "All 7 gates passed"

    def consolidate(self) -> list:
        can_run, _ = self.should_consolidate()
        if not can_run:
            return []

        self.last_scan_time = time.time()
        completed_phases = []
        for phase in self.PHASES:
            completed_phases.append(phase)

        self.last_consolidation_time = time.time()
        self._release_lock()
        return completed_phases

    def _acquire_lock(self) -> bool:
        now = time.time()

        if self.lock_file.exists():
            try:
                lock_data = self.lock_file.read_text(encoding="utf-8").strip()
                pid_str, timestamp_str = lock_data.split(":", 1)
                pid = int(pid_str)
                lock_time = float(timestamp_str)

                if (now - lock_time) > self.LOCK_STALE_SECONDS:
                    self.lock_file.unlink(missing_ok=True)
                else:
                    try:
                        os.kill(pid, 0)
                        return False
                    except OSError:
                        self.lock_file.unlink(missing_ok=True)
            except Exception:
                self.lock_file.unlink(missing_ok=True)

        try:
            self.memory_dir.mkdir(parents=True, exist_ok=True)
            self.lock_file.write_text(f"{os.getpid()}:{now}", encoding="utf-8")
            return True
        except OSError:
            return False

    def _release_lock(self):
        try:
            if not self.lock_file.exists():
                return
            lock_data = self.lock_file.read_text(encoding="utf-8").strip()
            pid_str = lock_data.split(":", 1)[0]
            if int(pid_str) == os.getpid():
                self.lock_file.unlink()
        except Exception:
            pass


class MemoryService:
    MEMORY_TYPES = ("user", "feedback", "project", "reference")
    MAX_INDEX_LINES = 200
    MEMORY_GUIDANCE = """
When to save memories:
- User states a preference -> type: user
- Repeated user corrections -> type: feedback
- Non-obvious project facts/constraints -> type: project
- External resource pointers -> type: reference
When NOT to save:
- Anything easy to re-derive from current code
- Temporary task state
- Secrets or credentials
""".strip()

    def __init__(self, memory_dir: Path):
        self.memory_dir = memory_dir
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.memories = {}
        self.dream = DreamConsolidator(self.memory_dir)
        self.load_all()

    def load_all(self):
        self.memories = {}
        if not self.memory_dir.exists():
            return
        for md in sorted(self.memory_dir.glob("*.md")):
            if md.name == "MEMORY.md":
                continue
            parsed = self._parse_frontmatter(md.read_text(encoding="utf-8"))
            if not parsed:
                continue
            name = parsed.get("name", md.stem)
            self.memories[name] = {
                "description": parsed.get("description", ""),
                "type": parsed.get("type", "project"),
                "content": parsed.get("content", ""),
                "file": md.name,
            }

    def load_memory_prompt(self) -> str:
        return self.load_prompt()

    def load_prompt(self) -> str:
        if not self.memories:
            return ""

        sections = ["# Memories (persistent across sessions)", ""]
        for mem_type in self.MEMORY_TYPES:
            typed = {k: v for k, v in self.memories.items() if v.get("type") == mem_type}
            if not typed:
                continue
            sections.append(f"## [{mem_type}]")
            for name, mem in typed.items():
                sections.append(f"### {name}: {mem.get('description', '')}")
                body = str(mem.get("content", "")).strip()
                if body:
                    sections.append(body)
                sections.append("")
        return "\n".join(sections).strip()

    def memory_guidance(self) -> str:
        return self.MEMORY_GUIDANCE

    def save_memory(self, name: str, description: str, mem_type: str, content: str) -> str:
        return self.save(name, description, mem_type, content)

    def save(self, name: str, description: str, mem_type: str, content: str) -> str:
        if mem_type not in self.MEMORY_TYPES:
            return f"Error: type must be one of {self.MEMORY_TYPES}"

        safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", name.lower())
        if not safe_name:
            return "Error: invalid memory name"

        path = self.memory_dir / f"{safe_name}.md"
        payload = (
            f"---\n"
            f"name: {name}\n"
            f"description: {description}\n"
            f"type: {mem_type}\n"
            f"---\n"
            f"{content}\n"
        )
        path.write_text(payload, encoding="utf-8")

        self.memories[name] = {
            "description": description,
            "type": mem_type,
            "content": content,
            "file": path.name,
        }
        self.rebuild_index()
        return f"Saved memory '{name}'"

    def rebuild_index(self):
        lines = ["# Memory Index", ""]
        for name, mem in self.memories.items():
            lines.append(f"- {name}: {mem.get('description', '')} [{mem.get('type', 'project')}]")
            if len(lines) >= self.MAX_INDEX_LINES:
                lines.append(f"... (truncated at {self.MAX_INDEX_LINES} lines)")
                break
        (self.memory_dir / "MEMORY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    def maybe_consolidate(self) -> str:
        self.dream.session_count += 1
        phases = self.dream.consolidate()
        if not phases:
            return "Dream consolidation skipped"
        self.rebuild_index()
        return f"Dream consolidation complete ({len(phases)} phases)"

    def _parse_frontmatter(self, text: str) -> Optional[dict]:
        match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", text, re.DOTALL)
        if not match:
            return None
        header, body = match.group(1), match.group(2)
        result = {"content": body.strip()}
        for line in header.splitlines():
            if ":" in line:
                key, _, value = line.partition(":")
                result[key.strip()] = value.strip()
        return result
