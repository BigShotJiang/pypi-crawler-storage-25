import json
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional, Tuple

from agency.core.config import WORKTREE_DIR, WORKTREE_INDEX_FILE


class WorktreeService:
    def __init__(
        self,
        root: Path = WORKTREE_DIR,
        index_path: Path = WORKTREE_INDEX_FILE,
        task_service=None,
        events_path: Path = None,
    ):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.index_path = index_path
        self.events_path = events_path or (self.root / "events.jsonl")
        self.events_path.parent.mkdir(parents=True, exist_ok=True)
        self.task_service = task_service
        self.repo_root = self._detect_repo_root(self.root.parent)
        self.git_available = self.repo_root is not None
        if not self.index_path.exists():
            self.index_path.write_text(json.dumps({"worktrees": []}, indent=2), encoding="utf-8")

    @staticmethod
    def _detect_repo_root(cwd: Path) -> Optional[Path]:
        try:
            r = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode != 0:
                return None
            root = Path(r.stdout.strip())
            return root if root.exists() else None
        except Exception:
            return None

    def _emit(self, event: str, **payload):
        record = {"event": event, "ts": time.time(), **payload}
        with self.events_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")

    def _index(self) -> dict:
        return json.loads(self.index_path.read_text(encoding="utf-8"))

    def _save(self, index: dict):
        self.index_path.write_text(json.dumps(index, indent=2), encoding="utf-8")

    def _find(self, index: dict, name: str):
        for wt in index["worktrees"]:
            if wt["name"] == name:
                return wt
        return None

    def _git_add_worktree(self, path: Path, branch: str) -> Tuple[bool, str]:
        if not self.repo_root:
            return False, "git repo root not found"
        cmd = ["git", "-C", str(self.repo_root), "worktree", "add", "-b", branch, str(path), "HEAD"]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if r.returncode == 0:
            return True, ""
        fallback = ["git", "-C", str(self.repo_root), "worktree", "add", str(path), branch]
        r2 = subprocess.run(fallback, capture_output=True, text=True, timeout=60)
        if r2.returncode == 0:
            return True, ""
        stderr = ((r.stderr or "") + "\n" + (r2.stderr or "")).strip().lower()
        if "already exists" in stderr or "already checked out" in stderr:
            msg = "branch or worktree already exists"
        elif "not a git repository" in stderr:
            msg = "current directory is not a git repository"
        elif "permission denied" in stderr:
            msg = "permission denied while creating git worktree"
        else:
            msg = ((r.stderr or "") + "\n" + (r2.stderr or "")).strip()[:600]
        return False, msg

    def create(self, name: str, branch: str = "") -> str:
        index = self._index()
        if self._find(index, name):
            self._emit("worktree.create.error", name=name, reason="already_exists")
            return f"Error: worktree '{name}' already exists"

        path = self.root / name
        branch_name = branch or f"wt/{name}"
        mode = "dir"

        if self.git_available:
            ok, err = self._git_add_worktree(path, branch_name)
            if ok:
                mode = "git"
            else:
                path.mkdir(parents=True, exist_ok=True)
                self._emit("worktree.create.fallback", name=name, branch=branch_name, error=err[:400])
        else:
            path.mkdir(parents=True, exist_ok=True)

        wt = {
            "name": name,
            "path": str(path),
            "branch": branch_name,
            "task_id": None,
            "status": "active",
            "mode": mode,
            "repo_root": str(self.repo_root) if self.repo_root else "",
            "created_at": time.time(),
            "closeout": None,
        }
        index["worktrees"].append(wt)
        self._save(index)
        self._emit("worktree.created", name=name, branch=branch_name, mode=mode, path=str(path))
        return json.dumps(wt, indent=2)

    def list_all(self) -> str:
        return json.dumps(self._index()["worktrees"], indent=2)

    def list_events(self, limit: int = 20) -> str:
        n = max(1, min(int(limit or 20), 200))
        if not self.events_path.exists():
            return "[]"
        lines = self.events_path.read_text(encoding="utf-8").splitlines()[-n:]
        events = []
        for line in lines:
            try:
                events.append(json.loads(line))
            except Exception:
                events.append({"event": "parse_error", "raw": line})
        return json.dumps(events, indent=2, ensure_ascii=False)

    def bind_task(self, name: str, task_id: int) -> str:
        index = self._index()
        wt = self._find(index, name)
        if not wt:
            self._emit("worktree.bind.error", name=name, task_id=task_id, reason="not_found")
            return f"Error: worktree '{name}' not found"
        wt["task_id"] = task_id
        wt["status"] = "active"
        self._save(index)

        if self.task_service:
            try:
                self.task_service.update(
                    task_id,
                    status="in_progress",
                    worktree=name,
                    worktree_state="active",
                    last_worktree=name,
                )
            except Exception as e:
                self._emit("worktree.bind.task_sync_error", name=name, task_id=task_id, error=str(e)[:300])

        self._emit("worktree.bound", name=name, task_id=task_id)
        return json.dumps(wt, indent=2)

    def closeout(self, name: str, action: str = "keep") -> str:
        index = self._index()
        wt = self._find(index, name)
        if not wt:
            self._emit("worktree.closeout.error", name=name, reason="not_found")
            return f"Error: worktree '{name}' not found"

        path = Path(wt["path"])
        task_id = wt.get("task_id")
        result_status = "closed"
        error = ""

        if action == "remove":
            try:
                if wt.get("mode") == "git" and self.repo_root:
                    r = subprocess.run(
                        ["git", "-C", str(self.repo_root), "worktree", "remove", "--force", str(path)],
                        capture_output=True,
                        text=True,
                        timeout=60,
                    )
                    if r.returncode != 0:
                        raise RuntimeError((r.stderr or r.stdout or "git worktree remove failed").strip())
                else:
                    if path.exists() and path.is_dir():
                        shutil.rmtree(path, ignore_errors=False)
                result_status = "removed"
            except Exception as e:
                error = str(e)
                result_status = "closeout_error"

        wt["status"] = result_status
        wt["closeout"] = {"action": action, "at": time.time(), "error": error}
        self._save(index)

        if self.task_service and task_id is not None:
            try:
                self.task_service.update(
                    int(task_id),
                    worktree="" if action == "remove" else name,
                    worktree_state=result_status,
                    last_worktree=name,
                    closeout={"action": action, "at": time.time(), "error": error},
                )
            except Exception as e:
                self._emit("worktree.closeout.task_sync_error", name=name, task_id=task_id, error=str(e)[:300])

        if error:
            self._emit("worktree.closeout.error", name=name, action=action, error=error[:400])
            return f"Error: worktree closeout failed for '{name}': {error}"

        self._emit("worktree.closed", name=name, action=action, status=result_status)
        return json.dumps(wt, indent=2)
