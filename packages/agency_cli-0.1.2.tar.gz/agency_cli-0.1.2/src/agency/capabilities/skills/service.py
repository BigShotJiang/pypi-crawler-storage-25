import re
from pathlib import Path


class SkillService:
    def __init__(self, skills_dir: Path):
        self.skills_dir = skills_dir
        self.documents = {}
        self.refresh()

    def refresh(self):
        self.documents = {}
        if not self.skills_dir.exists():
            return
        for path in sorted(self.skills_dir.rglob("SKILL.md")):
            text = path.read_text(encoding="utf-8")
            match = re.match(r"^---\n(.*?)\n---\n(.*)", text, re.DOTALL)
            if not match:
                continue
            meta = {}
            for line in match.group(1).strip().splitlines():
                if ":" in line:
                    key, value = line.split(":", 1)
                    meta[key.strip()] = value.strip()
            name = meta.get("name", path.parent.name)
            self.documents[name] = {
                "description": meta.get("description", "No description"),
                "body": match.group(2).strip(),
            }

    def describe_available(self) -> str:
        if not self.documents:
            return "(no skills available)"
        return "\n".join(
            f"- {name}: {doc['description']}" for name, doc in sorted(self.documents.items())
        )

    def load_full_text(self, name: str) -> str:
        doc = self.documents.get(name)
        if not doc:
            known = ", ".join(sorted(self.documents.keys())) or "(none)"
            return f"Error: Unknown skill '{name}'. Available skills: {known}"
        return f"<skill name=\"{name}\">\n{doc['body']}\n</skill>"
