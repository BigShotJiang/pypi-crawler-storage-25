"""
Command completion module using prompt_toolkit.
"""

from typing import List
from prompt_toolkit.completion import Completer, Completion, PathCompleter, WordCompleter


class AgencyCompleter(Completer):
    """Handles command completion for Agency CLI."""

    COMMANDS = ["/tools", "/mcp", "/plan", "/exit", "/quit"]

    def __init__(self, agent_loop):
        self.agent = agent_loop
        self.path_completer = PathCompleter()
        self.command_completer = WordCompleter(self.COMMANDS, ignore_case=True)

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor.lower().strip()

        if not text:
            return

        # Command completion
        if text.startswith("/"):
            for cmd in self.COMMANDS:
                if cmd.startswith(text):
                    yield Completion(cmd, start_position=-len(text))
            return

        # File path completion for relevant commands
        path_keywords = ["read", "write", "edit", "path", "file"]
        if any(keyword in text for keyword in path_keywords):
            yield from self.path_completer.get_completions(document, complete_event)
