"""
Keyboard shortcuts module using prompt_toolkit.
"""

import sys
from prompt_toolkit.key_binding import KeyBindings


def create_key_bindings(agent_loop) -> KeyBindings:
    """Create key bindings for the Agency CLI."""
    kb = KeyBindings()

    @kb.add("c-c", eager=True)
    def interrupt(event):
        """Ctrl+C: Interrupt current operation."""
        event.app.exit(exception=KeyboardInterrupt, style="bg:red")

    @kb.add("c-l")
    def clear_screen(event):
        """Ctrl+L: Clear screen."""
        agent_loop.console.clear()

    @kb.add("c-u")
    def clear_line(event):
        """Ctrl+U: Clear current input line."""
        buffer = event.app.current_buffer
        buffer.text = ""
        buffer.cursor_position = 0

    # Ctrl+Z only on Unix
    if sys.platform != "win32":
        @kb.add("c-z")
        def suspend(event):
            """Ctrl+Z: Suspend process (Unix only)."""
            import signal

            signal.signal(signal.SIGTSTP, signal.SIG_DFL)

    return kb
