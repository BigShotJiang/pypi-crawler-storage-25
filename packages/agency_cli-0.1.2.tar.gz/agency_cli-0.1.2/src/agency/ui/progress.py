"""
Progress display module for long-running operations.
Uses blessed library for cross-platform terminal animations.
"""

import sys
import time
import threading
from typing import Optional
from blessed import Terminal


class ProgressManager:
    """Manages progress display for long-running operations using blessed."""

    SPINNER_CHARS = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, base_console):
        self.term = Terminal()
        self.tasks: dict = {}
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._spinner_index = 0
        self._start_y = 0

    def start_task(self, task_id: str, description: str, total: Optional[int] = None):
        """Start a progress task with spinner animation."""
        with self._lock:
            if not self.tasks:  # First task, get starting position
                # Move to a new line first
                print()
                self._start_y = self.term.get_location()[1]

            self.tasks[task_id] = {
                "description": description,
                "total": total,
                "current": 0,
                "started": time.time(),
            }

            if not self._running:
                self._running = True
                self._thread = threading.Thread(target=self._animate, daemon=True)
                self._thread.start()

    def _animate(self):
        """Run the spinner animation in a separate thread."""
        try:
            while True:
                with self._lock:
                    if not self._running or not self.tasks:
                        break

                    # Build display strings
                    lines = []
                    for task_id, task in self.tasks.items():
                        spinner_char = self.SPINNER_CHARS[self._spinner_index % len(self.SPINNER_CHARS)]
                        desc = task["description"]
                        elapsed = time.time() - task["started"]

                        if task["total"]:
                            percent = min(100, int(task["current"] / task["total"] * 100))
                            bar_len = 15
                            filled = int(bar_len * task["current"] / task["total"]) if task["total"] > 0 else 0
                            bar = "█" * filled + "░" * (bar_len - filled)
                            line = f"  {spinner_char} {desc} |{bar}| {percent}% {elapsed:.0f}s"
                        else:
                            line = f"  {spinner_char} {desc} {elapsed:.0f}s"
                        lines.append(line)

                    self._spinner_index += 1

                    # Position cursor and print
                    for i, line in enumerate(lines):
                        with self.term.location(0, self._start_y + i):
                            print(line + " ", end="", flush=True)

                time.sleep(0.1)

            # Clear progress lines when done
            with self._lock:
                if self.tasks:
                    for i in range(len(self.tasks)):
                        with self.term.location(0, self._start_y + i):
                            print(" " * 60, end="", flush=True)
                else:
                    # Clear the line we added at start
                    with self.term.location(0, self._start_y):
                        print(" " * 60, end="", flush=True)

        except Exception:
            pass

    def update(self, task_id: str, advance: int = 1):
        """Update progress."""
        with self._lock:
            if task_id in self.tasks:
                self.tasks[task_id]["current"] += advance

    def stop_task(self, task_id: str):
        """Stop a task and show completion."""
        with self._lock:
            if task_id in self.tasks:
                desc = self.tasks[task_id]["description"]
                elapsed = time.time() - self.tasks[task_id]["started"]
                del self.tasks[task_id]

                # Check if this was the last task
                if not self.tasks:
                    self._running = False
                    # Clear progress line
                    with self.term.location(0, self._start_y):
                        print(" " * 60, end="", flush=True)
                        # Print completion message on same line

                    # Format elapsed time nicely
                    if elapsed < 0.1:
                        time_str = "<1s"
                    elif elapsed < 60:
                        time_str = f"{elapsed:.1f}s"
                    else:
                        mins = int(elapsed // 60)
                        secs = elapsed % 60
                        time_str = f"{mins}m {secs:.0f}s"

                    print(f"  ✓ {desc} ({time_str})")

                self._thread = None

    def stop_all(self):
        """Stop all tasks."""
        with self._lock:
            self._running = False
            self.tasks = {}
            self._thread = None
