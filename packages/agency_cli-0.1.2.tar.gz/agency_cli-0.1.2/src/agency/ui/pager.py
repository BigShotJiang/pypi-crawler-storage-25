"""
Paged display module for large outputs.
"""

from typing import List, Any
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text


class Pager:
    """Handles paged display for large outputs."""

    def __init__(self, console: Console, page_size: int = None):
        self.console = console
        self.page_size = page_size or (console.height // 2)

    def display_table(self, table: Table, title: str = None):
        """Display a table with pagination if needed."""
        # Count rows (excluding header)
        row_count = len(table.rows)

        if row_count <= self.page_size:
            self.console.print(table)
            return

        # Paginate
        rows = list(table.rows)
        start = 0
        page_num = 1
        total_pages = (row_count + self.page_size - 1) // self.page_size

        while start < row_count:
            end = min(start + self.page_size, row_count)

            # Create page table
            page_table = Table(
                show_header=table.show_header,
                header_style=table.header_style,
                box=table.box,
                pad_edge=table.pad_edge,
            )
            for col in table.columns:
                page_table.add_column(col.header, style=col.style, justify=col.justify)

            for row in rows[start:end]:
                page_table.add_row(*row.cells)

            self.console.print()
            if title:
                self.console.print(f"[bold cyan]{title}[/bold cyan]")
            self.console.print(page_table)

            page_num += 1
            if start + self.page_size < row_count:
                self.console.print(
                    f"[dim]Page {page_num}/{total_pages} | "
                    f"Showing {start + 1}-{end} of {row_count} | "
                    f"Press Enter to continue, 'q' to quit[/dim]"
                )
                try:
                    response = input().strip().lower()
                    if response == "q":
                        break
                except (EOFError, KeyboardInterrupt):
                    break

            start += self.page_size

    def display_list(self, items: List[str], title: str = None):
        """Display a list with pagination if needed."""
        if len(items) <= self.page_size:
            if title:
                self.console.print(f"[bold cyan]{title}[/bold cyan]")
            for item in items:
                self.console.print(f"  {item}")
            return

        # Paginate
        for i in range(0, len(items), self.page_size):
            page = items[i:i + self.page_size]
            self.console.print()
            if title:
                self.console.print(f"[bold cyan]{title} (page {i // self.page_size + 1})[/bold cyan]")
            for item in page:
                self.console.print(f"  {item}")

            if i + self.page_size < len(items):
                self.console.print(
                    f"[dim]Press Enter to continue, 'q' to quit[/dim]"
                )
                try:
                    response = input().strip().lower()
                    if response == "q":
                        break
                except (EOFError, KeyboardInterrupt):
                    break
