#!/usr/bin/env python3
import argparse
import os
import sys
from getpass import getpass
from pathlib import Path

from dotenv import dotenv_values, load_dotenv, set_key, unset_key


PERMISSION_MODES = ("default", "plan", "auto")


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Agency CLI")
    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="Start interactive agent")
    run_parser.add_argument("--permission-mode", choices=PERMISSION_MODES, default="default")
    run_parser.add_argument("--model", default=None)
    run_parser.add_argument("--workspace", default=str(Path.cwd()))

    config_parser = subparsers.add_parser("config", help="Manage LLM API configuration")
    config_subparsers = config_parser.add_subparsers(dest="config_action", required=True)

    config_set = config_subparsers.add_parser("set", help="Write settings into .env")
    config_set.add_argument("--workspace", default=str(Path.cwd()))
    config_set.add_argument("--provider", choices=("litellm", "anthropic"))
    config_set.add_argument("--model")
    config_set.add_argument("--api-key")
    config_set.add_argument("--base-url")

    config_show = config_subparsers.add_parser("show", help="Show current settings")
    config_show.add_argument("--workspace", default=str(Path.cwd()))

    config_unset = config_subparsers.add_parser("unset", help="Remove settings from .env")
    config_unset.add_argument("--workspace", default=str(Path.cwd()))
    config_unset.add_argument("--provider", action="store_true")
    config_unset.add_argument("--model", action="store_true")
    config_unset.add_argument("--api-key", action="store_true")
    config_unset.add_argument("--base-url", action="store_true")
    config_unset.add_argument("--all", action="store_true")

    config_init = config_subparsers.add_parser("init", help="Interactively configure LLM API settings")
    config_init.add_argument("--workspace", default=str(Path.cwd()))

    raw_argv = list(sys.argv[1:] if argv is None else argv)
    if raw_argv and raw_argv[0] in {"-h", "--help"}:
        return parser.parse_args(raw_argv)
    if not raw_argv or raw_argv[0] not in {"run", "config"}:
        raw_argv = ["run", *raw_argv]

    return parser.parse_args(raw_argv)


def _mask_secret(value: str) -> str:
    if not value:
        return "(empty)"
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"


def _resolve_env_file(workspace: Path) -> Path:
    return workspace / ".env"


def _run_config_set(args):
    workspace = Path(args.workspace)
    if not workspace.exists() or not workspace.is_dir():
        print(f"Error: invalid workspace path: {workspace}", file=sys.stderr)
        sys.exit(2)

    updates = {
        "AGENCY_LLM_PROVIDER": args.provider,
        "AGENCY_LLM_MODEL": args.model,
        "AGENCY_LLM_API_KEY": args.api_key,
        "AGENCY_LLM_BASE_URL": args.base_url,
    }
    updates = {k: v for k, v in updates.items() if v is not None}

    if not updates:
        print("Nothing to set. Use at least one of --provider/--model/--api-key/--base-url.")
        return

    env_file = _resolve_env_file(workspace)
    env_file.parent.mkdir(parents=True, exist_ok=True)
    if not env_file.exists():
        env_file.write_text("", encoding="utf-8")

    for key, value in updates.items():
        set_key(str(env_file), key, str(value), quote_mode="never")

    print(f"Updated: {env_file}")
    for key in updates:
        if key == "AGENCY_LLM_API_KEY":
            print(f"  {key}={_mask_secret(updates[key])}")
        else:
            print(f"  {key}={updates[key]}")


def _run_config_show(args):
    workspace = Path(args.workspace)
    if not workspace.exists() or not workspace.is_dir():
        print(f"Error: invalid workspace path: {workspace}", file=sys.stderr)
        sys.exit(2)

    env_file = _resolve_env_file(workspace)
    file_values = dotenv_values(str(env_file)) if env_file.exists() else {}

    provider = os.getenv("AGENCY_LLM_PROVIDER") or file_values.get("AGENCY_LLM_PROVIDER") or "litellm"
    model = os.getenv("AGENCY_LLM_MODEL") or file_values.get("AGENCY_LLM_MODEL") or "(unset)"
    api_key = os.getenv("AGENCY_LLM_API_KEY") or file_values.get("AGENCY_LLM_API_KEY") or ""
    base_url = os.getenv("AGENCY_LLM_BASE_URL") or file_values.get("AGENCY_LLM_BASE_URL") or ""

    print(f"Workspace: {workspace}")
    print(f".env file: {env_file} ({'exists' if env_file.exists() else 'missing'})")
    print(f"AGENCY_LLM_PROVIDER={provider}")
    print(f"AGENCY_LLM_MODEL={model}")
    print(f"AGENCY_LLM_API_KEY={_mask_secret(str(api_key))}")
    print(f"AGENCY_LLM_BASE_URL={base_url or '(empty)'}")


def _run_config_unset(args):
    workspace = Path(args.workspace)
    if not workspace.exists() or not workspace.is_dir():
        print(f"Error: invalid workspace path: {workspace}", file=sys.stderr)
        sys.exit(2)

    env_file = _resolve_env_file(workspace)
    if not env_file.exists():
        print(f"No .env file found at: {env_file}")
        return

    key_map = {
        "provider": "AGENCY_LLM_PROVIDER",
        "model": "AGENCY_LLM_MODEL",
        "api_key": "AGENCY_LLM_API_KEY",
        "base_url": "AGENCY_LLM_BASE_URL",
    }

    selected = []
    if args.all:
        selected = list(key_map.values())
    else:
        if args.provider:
            selected.append(key_map["provider"])
        if args.model:
            selected.append(key_map["model"])
        if args.api_key:
            selected.append(key_map["api_key"])
        if args.base_url:
            selected.append(key_map["base_url"])

    if not selected:
        print("Nothing to unset. Use --provider/--model/--api-key/--base-url or --all.")
        return

    for key in selected:
        unset_key(str(env_file), key, quote_mode="never")

    print(f"Updated: {env_file}")
    for key in selected:
        print(f"  removed {key}")


def _prompt_value(label: str, default: str = "", secret: bool = False) -> str:
    suffix = f" [{default}]" if default else ""
    prompt = f"{label}{suffix}: "
    value = getpass(prompt) if secret else input(prompt)
    value = value.strip()
    return value or default


def _run_config_init(args):
    workspace = Path(args.workspace)
    if not workspace.exists() or not workspace.is_dir():
        print(f"Error: invalid workspace path: {workspace}", file=sys.stderr)
        sys.exit(2)

    env_file = _resolve_env_file(workspace)
    file_values = dotenv_values(str(env_file)) if env_file.exists() else {}

    current_provider = str(file_values.get("AGENCY_LLM_PROVIDER") or os.getenv("AGENCY_LLM_PROVIDER") or "litellm")
    current_model = str(file_values.get("AGENCY_LLM_MODEL") or os.getenv("AGENCY_LLM_MODEL") or "")
    current_api_key = str(file_values.get("AGENCY_LLM_API_KEY") or os.getenv("AGENCY_LLM_API_KEY") or "")
    current_base_url = str(file_values.get("AGENCY_LLM_BASE_URL") or os.getenv("AGENCY_LLM_BASE_URL") or "")

    provider = _prompt_value("Provider (litellm/anthropic)", current_provider)
    while provider not in {"litellm", "anthropic"}:
        print("Please enter 'litellm' or 'anthropic'.")
        provider = _prompt_value("Provider (litellm/anthropic)", current_provider)

    model = _prompt_value("Model", current_model)
    api_key = _prompt_value("API Key", current_api_key, secret=True)
    base_url = _prompt_value("Base URL", current_base_url)

    class _Args:
        pass

    set_args = _Args()
    set_args.workspace = str(workspace)
    set_args.provider = provider
    set_args.model = model
    set_args.api_key = api_key
    set_args.base_url = base_url
    _run_config_set(set_args)


def main():
    from agency.runtime.bootstrap import create_agent

    args = parse_args()

    if args.command == "config":
        if args.config_action == "set":
            _run_config_set(args)
            return
        if args.config_action == "show":
            _run_config_show(args)
            return
        if args.config_action == "unset":
            _run_config_unset(args)
            return
        if args.config_action == "init":
            _run_config_init(args)
            return

    load_dotenv(override=True)

    workspace = Path(args.workspace)
    if not workspace.exists() or not workspace.is_dir():
        print(f"Error: invalid workspace path: {workspace}", file=sys.stderr)
        sys.exit(2)

    agent = create_agent(workspace, model=args.model, permission_mode=args.permission_mode)
    agent.connect_plugins()
    try:
        agent.repl()
    finally:
        agent.close()


if __name__ == "__main__":
    main()
