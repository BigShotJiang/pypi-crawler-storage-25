import os
from pathlib import Path

from dotenv import load_dotenv


load_dotenv(override=True)


def _read_env(primary: str, legacy: list[str], default: str = "") -> str:
    raw = os.getenv(primary)
    if raw is not None and str(raw).strip() != "":
        return str(raw)
    for key in legacy:
        v = os.getenv(key)
        if v is not None and str(v).strip() != "":
            return str(v)
    return default


def _sanitize_url_value(value: str) -> str:
    return (value or "").replace("\r", "").replace("\n", "").strip()


def _set_if_value(name: str, value: str):
    if value:
        os.environ[name] = value


LLM_PROVIDER = _read_env("AGENCY_LLM_PROVIDER", ["LLM_PROVIDER"], "litellm").strip().lower()
MODEL = _read_env("AGENCY_LLM_MODEL", ["MODEL_ID"], "claude-3-5-sonnet-20241022").strip()
LLM_API_KEY = _read_env("AGENCY_LLM_API_KEY", ["LLM_API_KEY", "ANTHROPIC_API_KEY"], "").strip()
LLM_BASE_URL = _sanitize_url_value(_read_env("AGENCY_LLM_BASE_URL", ["LLM_BASE_URL", "ANTHROPIC_BASE_URL"], ""))

# Canonical runtime env for shared adapter layer.
_set_if_value("LLM_API_KEY", LLM_API_KEY)
_set_if_value("LLM_BASE_URL", LLM_BASE_URL)

# Keep SDK compatibility for Anthropic branch while remaining source-of-truth unified.
if LLM_PROVIDER == "anthropic":
    _set_if_value("ANTHROPIC_API_KEY", LLM_API_KEY)
    _set_if_value("ANTHROPIC_BASE_URL", LLM_BASE_URL)
    if LLM_BASE_URL:
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)

WORKDIR = Path.cwd()
PERMISSION_MODES = ("default", "plan", "auto")
PLAN_REMINDER_INTERVAL = 3
TOKEN_THRESHOLD = 50000
MAX_RECOVERY_ATTEMPTS = 3
BACKOFF_BASE_DELAY = 1.0
BACKOFF_MAX_DELAY = 30.0
CONTINUATION_MESSAGE = (
    "Output limit hit. Continue directly from where you stopped -- "
    "no recap, no repetition. Pick up mid-sentence if needed."
)

CONTEXT_LIMIT = 50000
KEEP_RECENT_TOOL_RESULTS = 3
PERSIST_THRESHOLD = 30000
PREVIEW_CHARS = 2000
TRANSCRIPT_DIR = WORKDIR / ".transcripts"
TOOL_RESULTS_DIR = WORKDIR / ".task_outputs" / "tool-results"

HOOK_EVENTS = ("PreToolUse", "PostToolUse", "SessionStart")
HOOK_TIMEOUT = 30
TRUST_MARKER = WORKDIR / ".claude" / ".claude_trusted"

TASKS_DIR = WORKDIR / ".tasks"
RUNTIME_DIR = WORKDIR / ".runtime-tasks"
SCHEDULED_TASKS_FILE = WORKDIR / ".claude" / "scheduled_tasks.json"
CRON_LOCK_FILE = WORKDIR / ".claude" / "cron.lock"
AUTO_EXPIRY_DAYS = 7
JITTER_OFFSET_MAX = 4

TEAM_DIR = WORKDIR / ".team"
INBOX_DIR = TEAM_DIR / "inbox"
REQUESTS_DIR = TEAM_DIR / "requests"
CLAIM_EVENTS_PATH = TASKS_DIR / "claim_events.jsonl"
POLL_INTERVAL = 5
IDLE_TIMEOUT = 60

WORKTREE_DIR = WORKDIR / ".worktrees"
WORKTREE_INDEX_FILE = WORKTREE_DIR / "index.json"
EVENTS_LOG_FILE = WORKTREE_DIR / "events.jsonl"
