import json
import re
from fnmatch import fnmatch
from typing import Callable, Optional

from agency.core.config import PERMISSION_MODES, TRUST_MARKER


class BashSecurityValidator:
    VALIDATORS = [
        ("shell_metachar", r"[;&|`$]"),
        ("sudo", r"\bsudo\b"),
        ("rm_recursive", r"\brm\s+(-[a-zA-Z]*)?r"),
        ("cmd_substitution", r"\$\("),
        ("ifs_injection", r"\bIFS\s*="),
    ]

    def validate(self, command: str) -> list:
        failures = []
        for name, pattern in self.VALIDATORS:
            if re.search(pattern, command):
                failures.append((name, pattern))
        return failures


class CapabilityPermissionGate:
    READ_PREFIXES = ("read", "list", "get", "show", "search", "query", "inspect")
    HIGH_RISK_PREFIXES = ("delete", "remove", "drop", "shutdown")
    DEFAULT_RULES = [
        {"tool": "bash", "content": "rm -rf /", "behavior": "deny"},
        {"tool": "bash", "content": "sudo *", "behavior": "deny"},
        {"tool": "read_file", "path": "*", "behavior": "allow"},
    ]

    def __init__(
        self,
        mode: str = "default",
        rules: Optional[list] = None,
        confirm_handler: Optional[Callable[[dict, dict], bool]] = None,
    ):
        self.mode = mode if mode in PERMISSION_MODES else "default"
        self.rules = rules or list(self.DEFAULT_RULES)
        self.validator = BashSecurityValidator()
        self.confirm_handler = confirm_handler
        self.session_allow_patterns = set()

    def is_workspace_trusted(self) -> bool:
        return TRUST_MARKER.exists()

    def normalize(self, tool_name: str, tool_input: dict) -> dict:
        if tool_name.startswith("mcp__"):
            _, server_name, actual_tool = tool_name.split("__", 2)
            source = "mcp"
        else:
            server_name = None
            actual_tool = tool_name
            source = "native"

        lowered = actual_tool.lower()
        if actual_tool == "read_file" or lowered.startswith(self.READ_PREFIXES):
            risk = "read"
        elif actual_tool == "bash":
            command = tool_input.get("command", "")
            risk = (
                "high"
                if any(token in command for token in ("rm -rf", "sudo", "shutdown", "reboot"))
                else "write"
            )
        elif lowered.startswith(self.HIGH_RISK_PREFIXES):
            risk = "high"
        else:
            risk = "write"

        return {
            "source": source,
            "server": server_name,
            "tool": actual_tool,
            "risk": risk,
        }

    def _rule_matches(self, rule: dict, tool_name: str, tool_input: dict) -> bool:
        if rule.get("tool", "*") not in ("*", tool_name):
            return False

        if "path" in rule:
            path = tool_input.get("path", "")
            if not fnmatch(path, rule["path"]):
                return False

        if "content" in rule:
            content = tool_input.get("command", "")
            if not fnmatch(content, rule["content"]):
                return False

        return True

    def _check_rules(self, tool_name: str, tool_input: dict, behavior: str) -> Optional[dict]:
        for rule in self.rules:
            if rule.get("behavior") != behavior:
                continue
            if self._rule_matches(rule, tool_name, tool_input):
                return {
                    "behavior": behavior,
                    "reason": f"Rule matched: {rule}",
                }
        return None

    def _session_allow_key(self, intent: dict) -> str:
        server = intent.get("server") or "native"
        return f"{intent['source']}::{server}::{intent['tool']}::{intent['risk']}"

    def allow_for_session(self, intent: dict):
        self.session_allow_patterns.add(self._session_allow_key(intent))

    def check(self, tool_name: str, tool_input: dict) -> dict:
        intent = self.normalize(tool_name, tool_input)

        if self._session_allow_key(intent) in self.session_allow_patterns:
            return {
                "behavior": "allow",
                "reason": "Allowed for this session",
                "intent": intent,
            }

        if tool_name == "bash":
            failures = self.validator.validate(tool_input.get("command", ""))
            if failures:
                return {
                    "behavior": "deny",
                    "reason": f"bash security flags: {failures}",
                    "intent": intent,
                }

        deny = self._check_rules(tool_name, tool_input, "deny")
        if deny:
            deny["intent"] = intent
            return deny

        if self.mode == "plan" and intent["risk"] != "read":
            return {
                "behavior": "deny",
                "reason": "Plan mode: write operations are blocked",
                "intent": intent,
            }

        allow = self._check_rules(tool_name, tool_input, "allow")
        if allow:
            allow["intent"] = intent
            return allow

        if intent["risk"] == "read":
            return {"behavior": "allow", "reason": "Read capability", "intent": intent}
        if self.mode == "auto" and intent["risk"] != "high":
            return {
                "behavior": "allow",
                "reason": "Auto mode for non-high-risk capability",
                "intent": intent,
            }
        if intent["risk"] == "high":
            return {
                "behavior": "ask",
                "reason": "High-risk capability requires confirmation",
                "intent": intent,
            }
        return {
            "behavior": "ask",
            "reason": "State-changing capability requires confirmation",
            "intent": intent,
        }

    def ask_user(self, intent: dict, tool_input: dict) -> bool:
        if self.confirm_handler is not None:
            return bool(self.confirm_handler(intent, tool_input))

        preview = json.dumps(tool_input, ensure_ascii=False)[:200]
        source = (
            f"{intent['source']}:{intent['server']}/{intent['tool']}"
            if intent.get("server")
            else f"{intent['source']}:{intent['tool']}"
        )
        print(f"\n  [Permission] {source} risk={intent['risk']}: {preview}")
        try:
            answer = input("  Allow? (y/n): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return False
        return answer in ("y", "yes")
