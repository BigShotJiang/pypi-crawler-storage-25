import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional, Tuple

from .config import (
    CONTEXT_LIMIT,
    KEEP_RECENT_TOOL_RESULTS,
    PERSIST_THRESHOLD,
    PREVIEW_CHARS,
    TRANSCRIPT_DIR,
)


@dataclass
class CompactState:
    has_compacted: bool = False
    last_summary: str = ""
    recent_files: list = field(default_factory=list)
    last_plan_snapshot: str = ""
    recent_tool_previews: list = field(default_factory=list)
    workspace: Optional[Path] = None


def estimate_context_size(messages: list) -> int:
    return len(str(messages))


def track_recent_file(state: CompactState, path: str) -> None:
    if path in state.recent_files:
        state.recent_files.remove(path)
    state.recent_files.append(path)
    if len(state.recent_files) > 5:
        state.recent_files[:] = state.recent_files[-5:]


def persist_large_output(tool_use_id: str, output: str, workdir: Path) -> str:
    if len(output) <= PERSIST_THRESHOLD:
        return output

    output_dir = workdir / ".task_outputs" / "tool-results"
    output_dir.mkdir(parents=True, exist_ok=True)
    stored_path = output_dir / f"{tool_use_id}.txt"
    if not stored_path.exists():
        stored_path.write_text(output, encoding="utf-8")

    preview = output[:PREVIEW_CHARS]
    rel_path = stored_path.relative_to(workdir)
    return (
        "<persisted-output>\n"
        f"Full output saved to: {rel_path}\n"
        "Preview:\n"
        f"{preview}\n"
        "</persisted-output>"
    )


def collect_tool_result_blocks(messages: list) -> List[Tuple[int, int, dict]]:
    blocks = []
    for message_index, message in enumerate(messages):
        content = message.get("content")
        if message.get("role") != "user" or not isinstance(content, list):
            continue
        for block_index, block in enumerate(content):
            if isinstance(block, dict) and block.get("type") == "tool_result":
                blocks.append((message_index, block_index, block))
    return blocks


def micro_compact(messages: list) -> list:
    tool_results = collect_tool_result_blocks(messages)
    if len(tool_results) <= KEEP_RECENT_TOOL_RESULTS:
        return messages
    for _, _, block in tool_results[:-KEEP_RECENT_TOOL_RESULTS]:
        content = block.get("content", "")
        if not isinstance(content, str) or len(content) <= 120:
            continue
        block["content"] = "[Earlier tool result compacted. Re-run the tool if you need full detail.]"
    return messages


def _extract_recent_tool_previews(messages: list) -> list:
    previews = []
    tool_results = collect_tool_result_blocks(messages)
    for _, _, block in tool_results[-KEEP_RECENT_TOOL_RESULTS:]:
        content = block.get("content", "")
        if not isinstance(content, str):
            continue
        try:
            payload = json.loads(content)
        except Exception:
            payload = None
        if isinstance(payload, dict):
            tool_name = payload.get("tool", "unknown")
            status = payload.get("status", "unknown")
            preview = str(payload.get("preview", ""))[:160]
            previews.append(f"- {tool_name} [{status}]: {preview}")
        else:
            previews.append(f"- raw: {content[:180]}")
    return previews


def _extract_latest_plan(messages: list) -> str:
    tool_results = collect_tool_result_blocks(messages)
    for _, _, block in reversed(tool_results):
        content = block.get("content", "")
        if not isinstance(content, str):
            continue
        try:
            payload = json.loads(content)
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        if payload.get("tool") != "todo_write":
            continue
        preview = str(payload.get("preview", "")).strip()
        if preview:
            return preview[:800]
    return ""


def write_transcript(messages: list, workspace: Optional[Path] = None) -> Path:
    transcript_dir = (workspace / ".transcripts") if workspace else TRANSCRIPT_DIR
    transcript_dir.mkdir(parents=True, exist_ok=True)
    path = transcript_dir / f"transcript_{int(time.time())}.jsonl"
    with path.open("w", encoding="utf-8") as handle:
        for message in messages:
            handle.write(json.dumps(message, default=str) + "\n")
    return path


def _extract_text_from_response(response: Any) -> str:
    chunks = []
    for block in getattr(response, "content", []) or []:
        if isinstance(block, dict):
            if block.get("type") == "text" and block.get("text"):
                chunks.append(str(block.get("text")))
            continue
        if getattr(block, "type", "") == "text" and getattr(block, "text", ""):
            chunks.append(str(getattr(block, "text", "")))
    return "\n".join(chunks).strip()


def summarize_history(compact_provider: Any, model: str, messages: list) -> str:
    conversation = json.dumps(messages, default=str)[:80000]
    if compact_provider is None:
        return "Context compacted without LLM summary (no compact provider configured)."

    prompt = (
        "Summarize this coding-agent conversation so work can continue.\n"
        "Preserve: task goals, files touched, key decisions, remaining work.\n\n"
        + conversation
    )

    if hasattr(compact_provider, "create_message"):
        response = compact_provider.create_message(
            model=model,
            system="",
            messages=[{"role": "user", "content": prompt}],
            tools=[],
            max_tokens=2000,
        )
        text = _extract_text_from_response(response)
        return text or "Context compacted without detailed summary text."

    return "Context compacted without provider summary support."


def auto_compact(compact_provider: Any, model: str, messages: list, state: CompactState) -> Tuple[list, str]:
    transcript_path = write_transcript(messages, state.workspace)
    summary = summarize_history(compact_provider, model, messages)

    latest_plan = _extract_latest_plan(messages)
    recent_tool_previews = _extract_recent_tool_previews(messages)

    if latest_plan:
        state.last_plan_snapshot = latest_plan
    if recent_tool_previews:
        state.recent_tool_previews = recent_tool_previews

    addon_sections = []
    if state.last_plan_snapshot:
        addon_sections.append("# Latest Plan Snapshot\n" + state.last_plan_snapshot)
    if state.recent_tool_previews:
        addon_sections.append("# Recent Tool Results\n" + "\n".join(state.recent_tool_previews))

    addon = "\n\n".join(addon_sections)

    compacted = [
        {
            "role": "user",
            "content": (
                "Conversation compacted for continuity.\n"
                f"Previous transcript saved to: {transcript_path}\n\n"
                f"{summary}"
                + ("\n\n" + addon if addon else "")
            ),
        }
    ]
    return compacted, summary


def maybe_compact_if_needed(
    compact_provider: Any,
    model: str,
    messages: list,
    state: CompactState,
) -> list:
    messages = micro_compact(messages)
    if estimate_context_size(messages) <= CONTEXT_LIMIT:
        return messages
    compacted, summary = auto_compact(compact_provider, model, messages, state)
    state.has_compacted = True
    state.last_summary = summary
    return compacted
