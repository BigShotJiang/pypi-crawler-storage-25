import time
from pathlib import Path

from agency.core.config import WORKDIR

DYNAMIC_BOUNDARY = "=== DYNAMIC_BOUNDARY ==="


class SystemPromptBuilder:
    def __init__(self, workdir: Path):
        self.workdir = workdir

    def _build_core(self) -> str:
        return (
            f"You are a coding agent operating in {self.workdir}.\n"
            "Use tools to inspect and change workspace files safely.\n"
            "Always verify before assuming. Prefer reading files over guessing."
        )

    def _build_tool_listing(self, tools: list) -> str:
        if not tools:
            return ""
        lines = ["# Available tools"]
        for tool in tools:
            props = tool.get("input_schema", {}).get("properties", {})
            params = ", ".join(props.keys())
            lines.append(f"- {tool['name']}({params}): {tool.get('description', '')}")
        return "\n".join(lines)

    def _load_claude_chain(self) -> str:
        candidates = [
            self.workdir / "CLAUDE.md",
            self.workdir / ".claude" / "CLAUDE.md",
            WORKDIR / "CLAUDE.md",
        ]
        chunks = []
        for p in candidates:
            if p.exists():
                chunks.append(f"# CLAUDE.md from {p}\n" + p.read_text(encoding="utf-8"))
        return "\n\n".join(chunks)

    def _dynamic_context(self) -> str:
        return (
            f"Current working directory: {self.workdir}\n"
            f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}"
        )

    def build(self, tools: list, skill_registry, memory_manager) -> str:
        static_sections = [
            self._build_core(),
            self._build_tool_listing(tools),
            "# Available skills\n" + skill_registry.describe_available(),
        ]

        memory_prompt = memory_manager.load_prompt()
        if memory_prompt:
            static_sections.append(memory_prompt)

        if hasattr(memory_manager, "memory_guidance"):
            guidance = memory_manager.memory_guidance()
            if guidance:
                static_sections.append(guidance)

        claude_chain = self._load_claude_chain()
        if claude_chain:
            static_sections.append(claude_chain)

        dynamic_sections = [self._dynamic_context()]
        return (
            "\n\n".join([x for x in static_sections if x])
            + "\n\n"
            + DYNAMIC_BOUNDARY
            + "\n\n"
            + "\n\n".join([x for x in dynamic_sections if x])
        )
