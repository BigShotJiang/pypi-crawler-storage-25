from typing import Optional

from agency.core.config import PLAN_REMINDER_INTERVAL


class TodoManager:
    def __init__(self):
        self.items = []
        self.rounds_since_update = 0

    def update(self, items: list) -> str:
        if len(items) > 12:
            raise ValueError("Keep the session plan short (max 12 items)")
        normalized = []
        in_progress = 0
        for i, item in enumerate(items):
            content = str(item.get("content", "")).strip()
            status = str(item.get("status", "pending")).strip().lower()
            active_form = str(item.get("activeForm", "")).strip()
            if not content:
                raise ValueError(f"Item {i}: content required")
            if status not in {"pending", "in_progress", "completed"}:
                raise ValueError(f"Item {i}: invalid status '{status}'")
            if status == "in_progress":
                in_progress += 1
            normalized.append({"content": content, "status": status, "activeForm": active_form})
        if in_progress > 1:
            raise ValueError("Only one plan item can be in_progress")
        self.items = normalized
        self.rounds_since_update = 0
        return self.render()

    def note_round_without_update(self):
        self.rounds_since_update += 1

    def reminder(self) -> Optional[str]:
        if not self.items:
            return None
        if self.rounds_since_update < PLAN_REMINDER_INTERVAL:
            return None
        return "<reminder>Refresh your current plan before continuing.</reminder>"

    def render(self) -> str:
        if not self.items:
            return "No session plan yet."
        marker = {"pending": "[ ]", "in_progress": "[>]", "completed": "[x]"}
        lines = []
        for item in self.items:
            line = f"{marker[item['status']]} {item['content']}"
            if item["status"] == "in_progress" and item.get("activeForm"):
                line += f" ({item['activeForm']})"
            lines.append(line)
        completed = sum(1 for x in self.items if x["status"] == "completed")
        lines.append(f"({completed}/{len(self.items)} completed)")
        return "\n".join(lines)
