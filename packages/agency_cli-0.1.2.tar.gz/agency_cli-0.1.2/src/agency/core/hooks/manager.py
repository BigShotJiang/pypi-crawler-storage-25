import json
import os
import subprocess
from pathlib import Path

from agency.core.config import HOOK_EVENTS, HOOK_TIMEOUT, TRUST_MARKER, WORKDIR


class HookManager:
    def __init__(self, config_path: Path = None, sdk_mode: bool = False):
        self.hooks = {"PreToolUse": [], "PostToolUse": [], "SessionStart": []}
        self._sdk_mode = sdk_mode
        self.config_path = config_path or (WORKDIR / ".hooks.json")
        self.workdir = self.config_path.parent

        trust_marker = self.workdir / ".claude" / ".claude_trusted"
        self.trust_marker = trust_marker if trust_marker.exists() else TRUST_MARKER

        if self.config_path.exists():
            try:
                config = json.loads(self.config_path.read_text(encoding="utf-8"))
                for event in HOOK_EVENTS:
                    self.hooks[event] = config.get("hooks", {}).get(event, [])
            except Exception as e:
                print(f"[Hook config error: {e}]")

    def _check_workspace_trust(self) -> bool:
        if self._sdk_mode:
            return True
        return self.trust_marker.exists()

    def run_hooks(self, event: str, context: dict = None) -> dict:
        result = {"blocked": False, "messages": []}
        if not self._check_workspace_trust():
            return result
        hooks = self.hooks.get(event, [])
        for hook_def in hooks:
            matcher = hook_def.get("matcher")
            if matcher and context:
                tool_name = context.get("tool_name", "")
                if matcher != "*" and matcher != tool_name:
                    continue
            command = hook_def.get("command", "")
            if not command:
                continue
            env = dict(os.environ)
            if context:
                env["HOOK_EVENT"] = event
                env["HOOK_TOOL_NAME"] = context.get("tool_name", "")
                env["HOOK_TOOL_INPUT"] = json.dumps(context.get("tool_input", {}), ensure_ascii=False)[:10000]
                if "tool_output" in context:
                    env["HOOK_TOOL_OUTPUT"] = str(context["tool_output"])[:10000]
            try:
                r = subprocess.run(
                    command,
                    shell=True,
                    cwd=self.workdir,
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=HOOK_TIMEOUT,
                )
                if r.returncode == 1:
                    result["blocked"] = True
                if r.returncode in (1, 2) and r.stderr.strip():
                    result["messages"].append(r.stderr.strip())
            except subprocess.TimeoutExpired:
                result["messages"].append(f"[Hook {event}] timed out after {HOOK_TIMEOUT}s")
            except Exception as e:
                result["messages"].append(f"[Hook {event}] error: {e}")
        return result
