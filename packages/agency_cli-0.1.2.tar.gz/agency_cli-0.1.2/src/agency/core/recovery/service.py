import json
import random
import time
from typing import Callable, Optional

from agency.core.compact import maybe_compact_if_needed
from agency.core.config import (
    BACKOFF_BASE_DELAY,
    BACKOFF_MAX_DELAY,
    CONTINUATION_MESSAGE,
    MAX_RECOVERY_ATTEMPTS,
    TOKEN_THRESHOLD,
)


def estimate_tokens(messages: list) -> int:
    return len(json.dumps(messages, default=str)) // 4


def backoff_delay(attempt: int) -> float:
    delay = min(BACKOFF_BASE_DELAY * (2**attempt), BACKOFF_MAX_DELAY)
    return delay + random.uniform(0, 1)


def _classify_error(err_text: str) -> str:
    text = err_text.lower()
    if "max_tokens" in text or "output" in text and "limit" in text:
        return "max_tokens"
    if "prompt" in text and "long" in text:
        return "prompt_too_long"
    if any(k in text for k in ("connection", "timeout", "rate", "overload", "temporarily")):
        return "transient"
    return "unknown"


def create_response_with_recovery(
    llm_provider,
    model: str,
    system: str,
    messages: list,
    tools: list,
    compact_state,
    compact_provider=None,
    on_event: Optional[Callable[[str, dict], None]] = None,
    on_text_delta: Optional[Callable[[str], None]] = None,
):
    continuation_attempts = 0
    compact_attempts = 0
    transient_attempts = 0

    while True:
        try:
            messages[:] = maybe_compact_if_needed(compact_provider, model, messages, compact_state)
            response = llm_provider.create_message_stream(
                model=model,
                system=system,
                messages=messages,
                tools=tools,
                max_tokens=8000,
                on_text_delta=on_text_delta,
            )

            if response.stop_reason == "max_tokens" and continuation_attempts < MAX_RECOVERY_ATTEMPTS:
                continuation_attempts += 1
                if on_event:
                    on_event("recovery.continuation", {"attempt": continuation_attempts})
                messages.append({"role": "assistant", "content": response.content})
                messages.append({"role": "user", "content": CONTINUATION_MESSAGE})
                continue

            return response

        except Exception as e:
            err_text = str(e)
            cls = _classify_error(err_text)

            if cls == "prompt_too_long" or estimate_tokens(messages) > TOKEN_THRESHOLD:
                if compact_attempts >= MAX_RECOVERY_ATTEMPTS:
                    raise
                compact_attempts += 1
                if on_event:
                    on_event("recovery.compact", {"attempt": compact_attempts, "reason": cls})
                messages[:] = maybe_compact_if_needed(compact_provider, model, messages, compact_state)
                continue

            if cls == "transient":
                if transient_attempts >= MAX_RECOVERY_ATTEMPTS:
                    raise
                delay = backoff_delay(transient_attempts)
                if on_event:
                    on_event("recovery.backoff", {"attempt": transient_attempts + 1, "delay": delay})
                time.sleep(delay)
                transient_attempts += 1
                continue

            raise
