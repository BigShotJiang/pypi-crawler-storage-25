import json
import os
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class TextBlock:
    type: str
    text: str


@dataclass
class ToolUseBlock:
    type: str
    id: str
    name: str
    input: dict


@dataclass
class LLMResponse:
    content: list[Any] = field(default_factory=list)
    stop_reason: str = "end_turn"


class LLMProvider:
    def create_message(self, model: str, system: str, messages: list, tools: list, max_tokens: int) -> LLMResponse:
        raise NotImplementedError

    def create_message_stream(
        self,
        model: str,
        system: str,
        messages: list,
        tools: list,
        max_tokens: int,
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> LLMResponse:
        response = self.create_message(model=model, system=system, messages=messages, tools=tools, max_tokens=max_tokens)
        if on_text_delta:
            for block in getattr(response, "content", []) or []:
                if getattr(block, "type", "") == "text" and getattr(block, "text", ""):
                    on_text_delta(str(block.text))
        return response


class AnthropicProvider(LLMProvider):
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        from anthropic import Anthropic

        kwargs = {}
        if api_key:
            kwargs["api_key"] = api_key
        if base_url:
            kwargs["base_url"] = base_url
        self.client = Anthropic(**kwargs)

    @staticmethod
    def _get_attr(obj: Any, name: str, default: Any = None) -> Any:
        if isinstance(obj, dict):
            return obj.get(name, default)
        return getattr(obj, name, default)

    @staticmethod
    def _normalize_stop_reason(reason: str) -> str:
        if reason == "tool_use":
            return "tool_use"
        if reason in {"max_tokens", "length"}:
            return "max_tokens"
        return "end_turn"

    @staticmethod
    def _parse_tool_input(raw_input: Any) -> dict:
        if isinstance(raw_input, dict):
            return raw_input
        if isinstance(raw_input, str):
            try:
                parsed = json.loads(raw_input)
            except Exception:
                return {}
            return parsed if isinstance(parsed, dict) else {}
        return {}

    def _response_from_anthropic_message(self, resp: Any) -> LLMResponse:
        blocks = []
        for block in self._get_attr(resp, "content", []) or []:
            block_type = self._get_attr(block, "type", "")
            if block_type == "text":
                text = self._get_attr(block, "text", "")
                if text:
                    blocks.append(TextBlock(type="text", text=str(text)))
                continue
            if block_type == "tool_use":
                blocks.append(
                    ToolUseBlock(
                        type="tool_use",
                        id=self._get_attr(block, "id", "") or f"call_{uuid.uuid4().hex[:8]}",
                        name=self._get_attr(block, "name", ""),
                        input=self._parse_tool_input(self._get_attr(block, "input", {})),
                    )
                )

        stop_reason = self._normalize_stop_reason(str(self._get_attr(resp, "stop_reason", "end_turn") or "end_turn"))
        return LLMResponse(content=blocks, stop_reason=stop_reason)

    def create_message(self, model: str, system: str, messages: list, tools: list, max_tokens: int) -> LLMResponse:
        resp = self.client.messages.create(
            model=model,
            system=system,
            messages=messages,
            tools=tools,
            max_tokens=max_tokens,
        )
        return self._response_from_anthropic_message(resp)

    def create_message_stream(
        self,
        model: str,
        system: str,
        messages: list,
        tools: list,
        max_tokens: int,
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> LLMResponse:
        stream = self.client.messages.create(
            model=model,
            system=system,
            messages=messages,
            tools=tools,
            max_tokens=max_tokens,
            stream=True,
        )

        text_parts: list[str] = []
        tool_blocks: dict[int, dict] = {}
        stop_reason = "end_turn"

        for event in stream:
            event_type = str(self._get_attr(event, "type", "") or "")

            if event_type == "content_block_start":
                index = int(self._get_attr(event, "index", len(tool_blocks)) or 0)
                content_block = self._get_attr(event, "content_block", None)
                block_type = self._get_attr(content_block, "type", "")
                if block_type == "tool_use":
                    tool_blocks[index] = {
                        "id": self._get_attr(content_block, "id", "") or f"call_{uuid.uuid4().hex[:8]}",
                        "name": self._get_attr(content_block, "name", ""),
                        "input_json": "",
                        "input": self._get_attr(content_block, "input", {}) or {},
                    }
                continue

            if event_type == "content_block_delta":
                index = int(self._get_attr(event, "index", len(tool_blocks)) or 0)
                delta = self._get_attr(event, "delta", None)
                delta_type = self._get_attr(delta, "type", "")

                if delta_type == "text_delta":
                    text = str(self._get_attr(delta, "text", "") or "")
                    if text:
                        text_parts.append(text)
                        if on_text_delta:
                            on_text_delta(text)
                    continue

                if delta_type == "input_json_delta":
                    part = tool_blocks.setdefault(
                        index,
                        {"id": f"call_{uuid.uuid4().hex[:8]}", "name": "", "input_json": "", "input": {}},
                    )
                    partial_json = str(self._get_attr(delta, "partial_json", "") or "")
                    if partial_json:
                        part["input_json"] += partial_json
                    continue

            if event_type == "message_delta":
                delta = self._get_attr(event, "delta", None)
                stop_reason = str(self._get_attr(delta, "stop_reason", stop_reason) or stop_reason)
                continue

            if event_type == "message_stop":
                break

        blocks = []
        text = "".join(text_parts)
        if text:
            blocks.append(TextBlock(type="text", text=text))

        for index in sorted(tool_blocks):
            part = tool_blocks[index]
            tool_input = part.get("input", {})
            if part.get("input_json"):
                tool_input = self._parse_tool_input(part["input_json"])
            blocks.append(
                ToolUseBlock(
                    type="tool_use",
                    id=part.get("id", "") or f"call_{uuid.uuid4().hex[:8]}",
                    name=part.get("name", ""),
                    input=tool_input if isinstance(tool_input, dict) else {},
                )
            )

        return LLMResponse(content=blocks, stop_reason=self._normalize_stop_reason(stop_reason))


class LiteLLMProvider(LLMProvider):
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        from litellm import completion

        self._completion = completion
        self.api_base = (base_url or os.getenv("LLM_BASE_URL") or "").strip() or None
        self.api_key = (api_key or os.getenv("LLM_API_KEY") or "").strip() or None

    @staticmethod
    def _tool_schema(tools: list) -> list:
        out = []
        for t in tools or []:
            out.append(
                {
                    "type": "function",
                    "function": {
                        "name": t.get("name", ""),
                        "description": t.get("description", ""),
                        "parameters": t.get("input_schema", {"type": "object", "properties": {}}),
                    },
                }
            )
        return out

    @staticmethod
    def _normalize_stop_reason(reason: str, has_tool_calls: bool) -> str:
        if has_tool_calls or reason == "tool_calls":
            return "tool_use"
        if reason == "length":
            return "max_tokens"
        return "end_turn"

    @staticmethod
    def _as_dict(block: Any) -> dict:
        if isinstance(block, dict):
            return block
        return {
            "type": getattr(block, "type", ""),
            "id": getattr(block, "id", ""),
            "name": getattr(block, "name", ""),
            "input": getattr(block, "input", {}),
            "text": getattr(block, "text", ""),
        }

    @staticmethod
    def _normalize_model(model: str) -> str:
        name = (model or "").strip()
        if not name:
            return name
        if "/" in name:
            return name
        if name.startswith("claude"):
            return f"anthropic/{name}"
        if name.startswith("gpt") or name.startswith("o"):
            return f"openai/{name}"
        if name.startswith("gemini"):
            return f"gemini/{name}"
        if name.startswith("deepseek"):
            return f"deepseek/{name}"
        return name

    def _model_candidates(self, model: str) -> list[str]:
        normalized = self._normalize_model(model)
        candidates: list[str] = []
        seen = set()

        def _add(name: str):
            value = self._normalize_model(name)
            if value and value not in seen:
                seen.add(value)
                candidates.append(value)

        _add(normalized)

        fallback_env = os.getenv("AGENCY_LLM_FALLBACK_MODELS", "")
        for item in fallback_env.split(","):
            _add(item.strip())

        if normalized == "anthropic/claude-3-5-sonnet-latest":
            _add("anthropic/claude-3-5-sonnet-20241022")

        return candidates

    def _to_openai_messages(self, system: str, messages: list) -> list:
        out = [{"role": "system", "content": system}]

        for m in messages:
            role = m.get("role")
            content = m.get("content")

            if role == "user" and isinstance(content, str):
                out.append({"role": "user", "content": content})
                continue

            if role == "assistant":
                if isinstance(content, str):
                    out.append({"role": "assistant", "content": content})
                    continue
                if isinstance(content, list):
                    text_parts = []
                    tool_calls = []
                    for block in content:
                        b = self._as_dict(block)
                        if b.get("type") == "text" and b.get("text"):
                            text_parts.append(str(b.get("text")))
                        elif b.get("type") == "tool_use":
                            call_id = b.get("id") or f"call_{uuid.uuid4().hex[:8]}"
                            args = b.get("input") if isinstance(b.get("input"), dict) else {}
                            tool_calls.append(
                                {
                                    "id": call_id,
                                    "type": "function",
                                    "function": {
                                        "name": b.get("name", ""),
                                        "arguments": json.dumps(args, ensure_ascii=False),
                                    },
                                }
                            )
                    if text_parts or tool_calls:
                        msg = {"role": "assistant", "content": "\n".join(text_parts) if text_parts else ""}
                        if tool_calls:
                            msg["tool_calls"] = tool_calls
                        out.append(msg)
                    continue

            if role == "user" and isinstance(content, list):
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    if block.get("type") != "tool_result":
                        continue
                    out.append(
                        {
                            "role": "tool",
                            "tool_call_id": block.get("tool_use_id", ""),
                            "content": str(block.get("content", "")),
                        }
                    )

        return out

    @staticmethod
    def _get_attr(obj: Any, name: str, default: Any = None) -> Any:
        if isinstance(obj, dict):
            return obj.get(name, default)
        return getattr(obj, name, default)

    def _base_kwargs(self, system: str, messages: list, tools: list, max_tokens: int) -> dict:
        base_kwargs = {
            "messages": self._to_openai_messages(system, messages),
            "max_tokens": max_tokens,
        }
        tool_schema = self._tool_schema(tools)
        if tool_schema:
            base_kwargs["tools"] = tool_schema
            base_kwargs["tool_choice"] = "auto"
        if self.api_base:
            base_kwargs["api_base"] = self.api_base
        if self.api_key:
            base_kwargs["api_key"] = self.api_key
        return base_kwargs

    @staticmethod
    def _should_try_next_model(err: Exception) -> bool:
        msg = str(err).lower()
        return ("model_not_found" in msg) or ("no available channel for model" in msg)

    @staticmethod
    def _parse_tool_args(args_raw: Any) -> dict:
        try:
            args = json.loads(args_raw) if isinstance(args_raw, str) else (args_raw or {})
        except Exception:
            args = {}
        return args if isinstance(args, dict) else {}

    def _response_from_choice(self, choice: Any) -> LLMResponse:
        msg = self._get_attr(choice, "message", None)
        finish_reason = str(self._get_attr(choice, "finish_reason", "stop") or "stop")

        blocks = []
        text = self._get_attr(msg, "content", None) if msg is not None else None
        if text:
            blocks.append(TextBlock(type="text", text=str(text)))

        raw_tool_calls = self._get_attr(msg, "tool_calls", None) if msg is not None else None
        for tc in raw_tool_calls or []:
            fn = self._get_attr(tc, "function", None)
            name = self._get_attr(fn, "name", "") if fn else ""
            args_raw = self._get_attr(fn, "arguments", "{}") if fn else "{}"
            blocks.append(
                ToolUseBlock(
                    type="tool_use",
                    id=self._get_attr(tc, "id", "") or f"call_{uuid.uuid4().hex[:8]}",
                    name=name,
                    input=self._parse_tool_args(args_raw),
                )
            )

        return LLMResponse(
            content=blocks,
            stop_reason=self._normalize_stop_reason(finish_reason, bool(raw_tool_calls)),
        )

    def create_message(self, model: str, system: str, messages: list, tools: list, max_tokens: int) -> LLMResponse:
        base_kwargs = self._base_kwargs(system, messages, tools, max_tokens)
        last_error: Optional[Exception] = None

        for candidate in self._model_candidates(model):
            try:
                resp: Any = self._completion(**{**base_kwargs, "model": candidate})
                choices = self._get_attr(resp, "choices", []) or []
                if not choices:
                    return LLMResponse(content=[], stop_reason="end_turn")
                return self._response_from_choice(choices[0])
            except Exception as e:
                last_error = e
                if not self._should_try_next_model(e):
                    raise
                continue

        if last_error is not None:
            raise last_error
        return LLMResponse(content=[], stop_reason="end_turn")

    def create_message_stream(
        self,
        model: str,
        system: str,
        messages: list,
        tools: list,
        max_tokens: int,
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> LLMResponse:
        base_kwargs = {**self._base_kwargs(system, messages, tools, max_tokens), "stream": True}
        last_error: Optional[Exception] = None

        for candidate in self._model_candidates(model):
            try:
                stream = self._completion(**{**base_kwargs, "model": candidate})
                text_parts: list[str] = []
                tool_call_parts: dict[int, dict] = {}
                finish_reason = "stop"

                for chunk in stream:
                    choices = self._get_attr(chunk, "choices", []) or []
                    if not choices:
                        continue

                    choice = choices[0]
                    finish_reason = str(self._get_attr(choice, "finish_reason", None) or finish_reason)
                    delta = self._get_attr(choice, "delta", None)
                    if delta is None:
                        continue

                    text_delta = self._get_attr(delta, "content", None)
                    if text_delta:
                        text = str(text_delta)
                        text_parts.append(text)
                        if on_text_delta:
                            on_text_delta(text)

                    for tc in self._get_attr(delta, "tool_calls", []) or []:
                        raw_index = self._get_attr(tc, "index", len(tool_call_parts))
                        try:
                            index = int(raw_index)
                        except (TypeError, ValueError):
                            index = len(tool_call_parts)

                        part = tool_call_parts.setdefault(index, {"id": "", "name": "", "arguments": ""})
                        call_id = self._get_attr(tc, "id", "")
                        if call_id:
                            part["id"] = str(call_id)

                        fn = self._get_attr(tc, "function", None)
                        if not fn:
                            continue
                        name_delta = self._get_attr(fn, "name", "")
                        args_delta = self._get_attr(fn, "arguments", "")
                        if name_delta:
                            part["name"] += str(name_delta)
                        if args_delta:
                            part["arguments"] += str(args_delta)

                blocks = []
                text = "".join(text_parts)
                if text:
                    blocks.append(TextBlock(type="text", text=text))

                for index in sorted(tool_call_parts):
                    part = tool_call_parts[index]
                    blocks.append(
                        ToolUseBlock(
                            type="tool_use",
                            id=part["id"] or f"call_{uuid.uuid4().hex[:8]}",
                            name=part["name"],
                            input=self._parse_tool_args(part["arguments"] or "{}"),
                        )
                    )

                return LLMResponse(
                    content=blocks,
                    stop_reason=self._normalize_stop_reason(finish_reason, bool(tool_call_parts)),
                )
            except Exception as e:
                last_error = e
                if not self._should_try_next_model(e):
                    raise
                continue

        if last_error is not None:
            raise last_error
        return LLMResponse(content=[], stop_reason="end_turn")
