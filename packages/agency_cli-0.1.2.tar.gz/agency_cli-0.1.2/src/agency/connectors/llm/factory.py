from typing import Optional

from .provider import AnthropicProvider, LiteLLMProvider


_SUPPORTED_PROVIDERS = {"anthropic", "litellm"}


def create_llm_provider(provider_name: str, api_key: Optional[str] = None, base_url: Optional[str] = None):
    name = (provider_name or "litellm").strip().lower()
    if name not in _SUPPORTED_PROVIDERS:
        raise ValueError(
            f"Unsupported LLM provider: {name}. Supported: {', '.join(sorted(_SUPPORTED_PROVIDERS))}"
        )

    if name == "litellm":
        return LiteLLMProvider(api_key=api_key, base_url=base_url)

    if not api_key:
        raise ValueError("AGENCY_LLM_API_KEY is required when AGENCY_LLM_PROVIDER=anthropic.")
    return AnthropicProvider(api_key=api_key, base_url=base_url)
