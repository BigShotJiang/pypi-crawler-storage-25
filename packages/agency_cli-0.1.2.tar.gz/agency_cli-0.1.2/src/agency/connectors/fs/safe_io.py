from pathlib import Path


def safe_path(workdir: Path, p: str) -> Path:
    path = (workdir / p).resolve()
    if not path.is_relative_to(workdir):
        raise ValueError(f"Path escapes workspace: {p}")
    return path


def read_text(workdir: Path, path: str, limit: int = 50000) -> str:
    try:
        safe_limit = max(1, min(int(limit), 200000))
        return safe_path(workdir, path).read_text(encoding="utf-8")[:safe_limit]
    except Exception as e:
        return f"Error: {e}"


def write_text(workdir: Path, path: str, content: str) -> str:
    try:
        fp = safe_path(workdir, path)
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content, encoding="utf-8")
        return f"Wrote {len(content)} bytes"
    except Exception as e:
        return f"Error: {e}"


def edit_text(workdir: Path, path: str, old_text: str, new_text: str) -> str:
    try:
        fp = safe_path(workdir, path)
        content = fp.read_text(encoding="utf-8")
        if old_text not in content:
            return f"Error: Text not found in {path}"
        fp.write_text(content.replace(old_text, new_text, 1), encoding="utf-8")
        return f"Edited {path}"
    except Exception as e:
        return f"Error: {e}"
