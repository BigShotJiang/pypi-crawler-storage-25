import json
from pathlib import Path


class PluginLoader:
    def __init__(self, search_dirs: list = None):
        self.search_dirs = search_dirs or [Path.cwd()]
        self.plugins = {}

    def scan(self) -> list:
        self.plugins = {}
        found = []
        for search_dir in self.search_dirs:
            root = Path(search_dir)
            candidates = [
                root / ".claude-plugin" / "plugin.json",
                root / ".claude" / "plugins" / "plugin.json",
            ]
            for manifest_path in candidates:
                if not manifest_path.exists():
                    continue
                try:
                    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                    name = manifest.get("name", manifest_path.parent.parent.name)
                    self.plugins[name] = manifest
                    found.append(name)
                except (json.JSONDecodeError, OSError) as e:
                    print(f"[Plugin] Failed to load {manifest_path}: {e}")
        return sorted(set(found))

    def get_mcp_servers(self) -> dict:
        servers = {}
        for plugin_name, manifest in self.plugins.items():
            for server_name, config in manifest.get("mcpServers", {}).items():
                servers[f"{plugin_name}__{server_name}"] = config
        return servers
