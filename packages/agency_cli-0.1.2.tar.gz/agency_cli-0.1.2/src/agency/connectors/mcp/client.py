import json
import os
import queue
import subprocess
import threading
import time
from typing import Optional


class MCPClient:
    def __init__(self, server_name: str, command: str, args: list = None, env: dict = None):
        self.server_name = server_name
        self.command = command
        self.args = args or []
        self.env = {**os.environ, **(env or {})}
        self.process = None
        self._request_id = 0
        self._tools = []
        self._responses = queue.Queue()
        self._stderr = queue.Queue()
        self._stdout_thread = None
        self._stderr_thread = None

    def connect(self):
        try:
            self.process = subprocess.Popen(
                [self.command] + self.args,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=self.env,
                text=True,
                bufsize=1,
            )
            self._start_readers()
            req_id = self._send(
                {
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {"name": "agency", "version": "1.0"},
                    },
                }
            )
            response = self._recv(req_id=req_id, timeout=15)
            if response and "result" in response:
                self._send({"method": "notifications/initialized"})
                return True
            err = self._drain_stderr()
            if err:
                print(f"[MCP] Initialize failed: {err[:400]}")
        except FileNotFoundError:
            print(f"[MCP] Server command not found: {self.command}")
        except Exception as e:
            print(f"[MCP] Connection failed: {e}")
        return False

    def list_tools(self) -> list:
        req_id = self._send({"method": "tools/list", "params": {}})
        response = self._recv(req_id=req_id, timeout=15)
        if response and "result" in response:
            self._tools = response["result"].get("tools", [])
        return self._tools

    def call_tool(self, tool_name: str, arguments: dict) -> str:
        if not self._ensure_alive():
            return "MCP Error: server unavailable"
        req_id = self._send({"method": "tools/call", "params": {"name": tool_name, "arguments": arguments}})
        response = self._recv(req_id=req_id, timeout=30)
        if response and "result" in response:
            content = response["result"].get("content", [])
            return "\n".join(c.get("text", str(c)) for c in content)
        if response and "error" in response:
            return f"MCP Error: {response['error'].get('message', 'unknown')}"
        err = self._drain_stderr()
        if err:
            return f"MCP Error: no response (stderr: {err[:300]})"
        return "MCP Error: no response"

    def get_agent_tools(self) -> list:
        tools = []
        for tool in self._tools:
            tools.append(
                {
                    "name": f"mcp__{self.server_name}__{tool['name']}",
                    "description": tool.get("description", ""),
                    "input_schema": tool.get("inputSchema", {"type": "object", "properties": {}}),
                }
            )
        return tools

    def disconnect(self):
        if self.process:
            try:
                self._send({"method": "shutdown"})
                self.process.terminate()
                self.process.wait(timeout=5)
            except Exception:
                self.process.kill()
            self.process = None

    def _ensure_alive(self) -> bool:
        if self.process and self.process.poll() is None:
            return True
        self.disconnect()
        return self.connect()

    def _start_readers(self):
        def read_stdout():
            while self.process and self.process.poll() is None:
                try:
                    line = self.process.stdout.readline()
                    if not line:
                        time.sleep(0.02)
                        continue
                    msg = json.loads(line)
                    self._responses.put(msg)
                except Exception:
                    continue

        def read_stderr():
            while self.process and self.process.poll() is None:
                try:
                    line = self.process.stderr.readline()
                    if line:
                        self._stderr.put(line.strip())
                    else:
                        time.sleep(0.05)
                except Exception:
                    continue

        self._stdout_thread = threading.Thread(target=read_stdout, daemon=True)
        self._stderr_thread = threading.Thread(target=read_stderr, daemon=True)
        self._stdout_thread.start()
        self._stderr_thread.start()

    def _drain_stderr(self) -> str:
        parts = []
        for _ in range(20):
            try:
                parts.append(self._stderr.get_nowait())
            except queue.Empty:
                break
        return "\n".join(parts)

    def _send(self, message: dict) -> int:
        if not self.process or self.process.poll() is not None:
            return -1
        self._request_id += 1
        envelope = {"jsonrpc": "2.0", "id": self._request_id, **message}
        line = json.dumps(envelope) + "\n"
        try:
            self.process.stdin.write(line)
            self.process.stdin.flush()
        except (BrokenPipeError, OSError):
            return -1
        return self._request_id

    def _recv(self, req_id: int, timeout: int = 15) -> Optional[dict]:
        if req_id < 0:
            return None
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                msg = self._responses.get(timeout=0.2)
            except queue.Empty:
                continue
            if msg.get("id") == req_id:
                return msg
        return None
