import json

from .client import MCPClient


class MCPToolRouter:
    def __init__(self):
        self.clients = {}

    def register_client(self, client: MCPClient):
        self.clients[client.server_name] = client

    def is_mcp_tool(self, tool_name: str) -> bool:
        return tool_name.startswith("mcp__")

    def call(self, tool_name: str, arguments: dict) -> str:
        parts = tool_name.split("__", 2)
        if len(parts) != 3:
            return json.dumps({"error": "Invalid MCP tool name", "tool": tool_name}, ensure_ascii=False)
        _, server_name, actual_tool = parts
        client = self.clients.get(server_name)
        if not client:
            return json.dumps({"error": "MCP server not found", "server": server_name}, ensure_ascii=False)

        result = client.call_tool(actual_tool, arguments)
        if result.startswith("MCP Error:"):
            return json.dumps(
                {
                    "error": "MCP tool call failed",
                    "server": server_name,
                    "tool": actual_tool,
                    "detail": result,
                },
                ensure_ascii=False,
            )
        return result

    def get_all_tools(self) -> list:
        tools = []
        for client in self.clients.values():
            tools.extend(client.get_agent_tools())
        return tools
