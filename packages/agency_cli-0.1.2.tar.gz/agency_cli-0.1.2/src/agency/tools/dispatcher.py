from pathlib import Path

from agency.connectors.fs.safe_io import edit_text, read_text, write_text
from agency.connectors.shell.exec import run_command


def dispatch_tool_call(
    workdir: Path,
    tool_name: str,
    tool_input: dict,
    *,
    mcp_router,
    todo,
    memory,
    skills,
    task_manager,
    background,
    scheduler,
    teammates,
    protocols,
    worktrees,
    progress=None,
) -> str:
    # Long-running tools that should show progress
    progress_tools = {"bash", "background_run", "read_file", "write_file"}
    show_progress = progress is not None and tool_name in progress_tools

    if show_progress:
        progress.start_task(f"tool_{tool_name}", f"Running {tool_name}...")

    try:
        result = _execute_tool_call(
            workdir, tool_name, tool_input,
            mcp_router, todo, memory, skills, task_manager,
            background, scheduler, teammates, protocols, worktrees
        )
    finally:
        if show_progress:
            progress.stop_task(f"tool_{tool_name}")

    return result


def _execute_tool_call(
    workdir: Path,
    tool_name: str,
    tool_input: dict,
    mcp_router,
    todo,
    memory,
    skills,
    task_manager,
    background,
    scheduler,
    teammates,
    protocols,
    worktrees,
) -> str:
    if mcp_router.is_mcp_tool(tool_name):
        return mcp_router.call(tool_name, tool_input)

    if tool_name == "bash":
        return run_command(workdir, tool_input["command"])
    if tool_name == "read_file":
        return read_text(workdir, tool_input["path"], tool_input.get("limit", 50000))
    if tool_name == "write_file":
        return write_text(workdir, tool_input["path"], tool_input["content"])
    if tool_name == "edit_file":
        return edit_text(workdir, tool_input["path"], tool_input["old_text"], tool_input["new_text"])
    if tool_name == "todo_write":
        return todo.update(tool_input["items"])
    if tool_name == "save_memory":
        return memory.save(tool_input["name"], tool_input["description"], tool_input["type"], tool_input["content"])
    if tool_name == "load_skill":
        return skills.load_full_text(tool_input["name"])

    if tool_name == "task_create":
        return task_manager.create(
            tool_input["subject"],
            tool_input.get("description", ""),
            tool_input.get("required_role", ""),
        )
    if tool_name == "task_get":
        return task_manager.get(int(tool_input["task_id"]))
    if tool_name == "task_update":
        return task_manager.update(
            int(tool_input["task_id"]),
            status=tool_input.get("status"),
            owner=tool_input.get("owner"),
            add_blocked_by=tool_input.get("add_blocked_by"),
            add_blocks=tool_input.get("add_blocks"),
            worktree=tool_input.get("worktree"),
            worktree_state=tool_input.get("worktree_state"),
            last_worktree=tool_input.get("last_worktree"),
            closeout=tool_input.get("closeout"),
        )
    if tool_name == "task_list":
        return task_manager.list_all()

    if tool_name == "background_run":
        return background.run(tool_input["command"], workdir)
    if tool_name == "background_list":
        return background.list_all()
    if tool_name == "background_get":
        return background.get(tool_input["task_id"])

    if tool_name == "schedule_create":
        return scheduler.create(
            tool_input["cron"],
            tool_input["prompt"],
            bool(tool_input.get("one_shot", False)),
            bool(tool_input.get("durable", True)),
        )
    if tool_name == "schedule_list":
        return scheduler.list_all()
    if tool_name == "schedule_delete":
        return scheduler.delete(tool_input["schedule_id"])

    if tool_name == "teammate_spawn":
        return teammates.spawn(tool_input["name"], tool_input["role"], tool_input.get("system_prompt", ""))
    if tool_name == "teammate_list":
        return teammates.list_members()
    if tool_name == "message_send":
        return teammates.bus.send(tool_input["sender"], tool_input["to"], tool_input["content"], tool_input.get("type", "message"))
    if tool_name == "inbox_read":
        return str(teammates.bus.read_inbox(tool_input["name"]))
    if tool_name == "broadcast":
        return teammates.bus.broadcast(tool_input["sender"], tool_input["content"], tool_input["teammates"])

    if tool_name == "shutdown_request":
        return protocols.request_shutdown(tool_input["sender"], tool_input["target"], tool_input.get("reason", ""))
    if tool_name == "shutdown_respond":
        return protocols.respond_shutdown(
            tool_input["responder"],
            tool_input["request_id"],
            bool(tool_input["approve"]),
            tool_input.get("note", ""),
        )
    if tool_name == "plan_approval_request":
        return protocols.request_plan_approval(tool_input["sender"], tool_input["approver"], tool_input["plan_text"])
    if tool_name == "plan_approval_respond":
        return protocols.respond_plan_approval(
            tool_input["responder"],
            tool_input["request_id"],
            bool(tool_input["approve"]),
            tool_input.get("note", ""),
        )

    if tool_name == "worktree_create":
        return worktrees.create(tool_input["name"], tool_input.get("branch", ""))
    if tool_name == "worktree_list":
        return worktrees.list_all()
    if tool_name == "worktree_events":
        return worktrees.list_events(int(tool_input.get("limit", 20)))
    if tool_name == "worktree_bind":
        return worktrees.bind_task(tool_input["name"], int(tool_input["task_id"]))
    if tool_name == "worktree_closeout":
        return worktrees.closeout(tool_input["name"], tool_input.get("action", "keep"))

    return f"Unknown tool: {tool_name}"
