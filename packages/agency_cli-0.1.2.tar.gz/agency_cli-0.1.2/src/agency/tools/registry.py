def _schema(properties=None, required=None):
    return {
        "type": "object",
        "properties": properties or {},
        "required": required or [],
    }


def get_tool_registry() -> list:
    tools = [
        {
            "name": "bash",
            "description": "Run shell command",
            "input_schema": _schema(
                {"command": {"type": "string", "description": "Shell command"}},
                ["command"],
            ),
        },
        {
            "name": "read_file",
            "description": "Read file",
            "input_schema": _schema(
                {
                    "path": {"type": "string", "description": "File path"},
                    "limit": {"type": "integer", "description": "Optional line limit"},
                },
                ["path"],
            ),
        },
        {
            "name": "write_file",
            "description": "Write file",
            "input_schema": _schema(
                {
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                },
                ["path", "content"],
            ),
        },
        {
            "name": "edit_file",
            "description": "Edit file",
            "input_schema": _schema(
                {
                    "path": {"type": "string"},
                    "old_text": {"type": "string"},
                    "new_text": {"type": "string"},
                },
                ["path", "old_text", "new_text"],
            ),
        },
        {
            "name": "todo_write",
            "description": "Update session plan",
            "input_schema": _schema(
                {
                    "items": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "content": {"type": "string"},
                                "status": {"type": "string"},
                                "activeForm": {"type": "string"},
                            },
                        },
                    }
                },
                ["items"],
            ),
        },
        {
            "name": "save_memory",
            "description": "Save persistent memory",
            "input_schema": _schema(
                {
                    "name": {"type": "string"},
                    "description": {"type": "string"},
                    "type": {"type": "string"},
                    "content": {"type": "string"},
                },
                ["name", "description", "type", "content"],
            ),
        },
        {
            "name": "load_skill",
            "description": "Load skill",
            "input_schema": _schema({"name": {"type": "string"}}, ["name"]),
        },
        {
            "name": "task_create",
            "description": "Create task",
            "input_schema": _schema(
                {
                    "subject": {"type": "string"},
                    "description": {"type": "string"},
                    "required_role": {"type": "string"},
                },
                ["subject"],
            ),
        },
        {
            "name": "task_get",
            "description": "Get task",
            "input_schema": _schema({"task_id": {"type": "integer"}}, ["task_id"]),
        },
        {
            "name": "task_update",
            "description": "Update task",
            "input_schema": _schema(
                {
                    "task_id": {"type": "integer"},
                    "status": {"type": "string"},
                    "owner": {"type": "string"},
                    "add_blocked_by": {"type": "array", "items": {"type": "integer"}},
                    "add_blocks": {"type": "array", "items": {"type": "integer"}},
                    "worktree": {"type": "string"},
                    "worktree_state": {"type": "string"},
                    "last_worktree": {"type": "string"},
                    "closeout": {"type": "object"},
                },
                ["task_id"],
            ),
        },
        {"name": "task_list", "description": "List tasks", "input_schema": _schema()},
        {
            "name": "background_run",
            "description": "Run background command",
            "input_schema": _schema({"command": {"type": "string"}}, ["command"]),
        },
        {"name": "background_list", "description": "List background", "input_schema": _schema()},
        {
            "name": "background_get",
            "description": "Get background task",
            "input_schema": _schema({"task_id": {"type": "string"}}, ["task_id"]),
        },
        {
            "name": "schedule_create",
            "description": "Create schedule",
            "input_schema": _schema(
                {
                    "cron": {"type": "string"},
                    "prompt": {"type": "string"},
                    "one_shot": {"type": "boolean"},
                    "durable": {"type": "boolean"},
                },
                ["cron", "prompt"],
            ),
        },
        {"name": "schedule_list", "description": "List schedules", "input_schema": _schema()},
        {
            "name": "schedule_delete",
            "description": "Delete schedule",
            "input_schema": _schema({"schedule_id": {"type": "string"}}, ["schedule_id"]),
        },
        {
            "name": "teammate_spawn",
            "description": "Spawn teammate",
            "input_schema": _schema(
                {
                    "name": {"type": "string"},
                    "role": {"type": "string"},
                    "system_prompt": {"type": "string"},
                },
                ["name", "role"],
            ),
        },
        {"name": "teammate_list", "description": "List teammates", "input_schema": _schema()},
        {
            "name": "message_send",
            "description": "Send message",
            "input_schema": _schema(
                {
                    "sender": {"type": "string"},
                    "to": {"type": "string"},
                    "content": {"type": "string"},
                    "type": {"type": "string"},
                },
                ["sender", "to", "content"],
            ),
        },
        {
            "name": "inbox_read",
            "description": "Read inbox",
            "input_schema": _schema({"name": {"type": "string"}}, ["name"]),
        },
        {
            "name": "broadcast",
            "description": "Broadcast",
            "input_schema": _schema(
                {
                    "sender": {"type": "string"},
                    "content": {"type": "string"},
                    "teammates": {"type": "array", "items": {"type": "string"}},
                },
                ["sender", "content", "teammates"],
            ),
        },
        {
            "name": "shutdown_request",
            "description": "Shutdown request",
            "input_schema": _schema(
                {
                    "sender": {"type": "string"},
                    "target": {"type": "string"},
                    "reason": {"type": "string"},
                },
                ["sender", "target"],
            ),
        },
        {
            "name": "shutdown_respond",
            "description": "Shutdown response",
            "input_schema": _schema(
                {
                    "responder": {"type": "string"},
                    "request_id": {"type": "string"},
                    "approve": {"type": "boolean"},
                    "note": {"type": "string"},
                },
                ["responder", "request_id", "approve"],
            ),
        },
        {
            "name": "plan_approval_request",
            "description": "Plan approval request",
            "input_schema": _schema(
                {
                    "sender": {"type": "string"},
                    "approver": {"type": "string"},
                    "plan_text": {"type": "string"},
                },
                ["sender", "approver", "plan_text"],
            ),
        },
        {
            "name": "plan_approval_respond",
            "description": "Plan approval response",
            "input_schema": _schema(
                {
                    "responder": {"type": "string"},
                    "request_id": {"type": "string"},
                    "approve": {"type": "boolean"},
                    "note": {"type": "string"},
                },
                ["responder", "request_id", "approve"],
            ),
        },
        {
            "name": "worktree_create",
            "description": "Create worktree",
            "input_schema": _schema(
                {"name": {"type": "string"}, "branch": {"type": "string"}},
                ["name"],
            ),
        },
        {"name": "worktree_list", "description": "List worktrees", "input_schema": _schema()},
        {
            "name": "worktree_events",
            "description": "List worktree events",
            "input_schema": _schema({"limit": {"type": "integer"}}, []),
        },
        {
            "name": "worktree_bind",
            "description": "Bind worktree",
            "input_schema": _schema(
                {"name": {"type": "string"}, "task_id": {"type": "integer"}},
                ["name", "task_id"],
            ),
        },
        {
            "name": "worktree_closeout",
            "description": "Closeout worktree",
            "input_schema": _schema(
                {"name": {"type": "string"}, "action": {"type": "string"}},
                ["name"],
            ),
        },
    ]
    return tools
