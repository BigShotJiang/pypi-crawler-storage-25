# Trustcafe API Wrapper

Intended use (not working yet but testing.py does)

```python
import trustcafeapiwrapper, os


API = trustcafeapiwrapper.APIClient(
    client_id=os.getenv("client_id"),
    client_secret=os.getenv("client_secret")
)

profile = API.run_job('userprofile.get', "simon-little")
```

## Debates

1. Not sure about the name `jobs` and `run_job`.  Requests is an 
existing package dependency though.  `tasks` seems to broard.  I'm sure 
there's probably an already existing name that I can't articulate how
to find.
2. Should these `job` be called with dot notation? Or with slashes? Or 
something else?  Is it okay to have these as strings?  
3. Should we do validation in the `jobs` or let the server do that all? 
4. `wrapped` is an awkward name. What's more proper? But also obvious?

## ToDo:

1. Make more jobs
2. Make wrappers to make it less cumbersome when posting etc
3. Publish to PyPi or whatever