"""Utility functions for Aird."""
