"""Domain contracts and models."""
