import json
import urllib.request
import urllib.error

from . import config
from . import tools as tool_module

SYSTEM_PROMPT = """\
You are Aurex, an elite AI coding agent running in the developer's terminal.
You have tools to read/write files, run shell commands, search code, search the web, and more.
When asked to do something, DO IT — use tools, don't just describe.
Be concise. No filler. No disclaimers.
"""


def _stream_request(messages: list, tools: list):
    payload = json.dumps({
        "model":      config.get_real_model(),
        "messages":   messages,
        "tools":      tools,
        "stream":     True,
        "max_tokens": 4096,
    }).encode()

    req = urllib.request.Request(
        f"{config.BASE_URL}/chat/completions",
        data=payload,
        headers={
            "Authorization": f"Bearer {config.API_KEY}",
            "Content-Type":  "application/json",
            "Accept":        "text/event-stream",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        for raw in resp:
            line = raw.decode("utf-8").strip()
            if line:
                yield line


def _parse_sse(line: str):
    if line.startswith("data:"):
        data = line[5:].strip()
        if data == "[DONE]":
            return None
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            return None
    return None


class AurexAgent:
    def __init__(self):
        self.history: list[dict] = []

    def clear_history(self) -> None:
        self.history = []

    def chat(self, user_message: str):
        self.history.append({"role": "user", "content": user_message})
        # Keep last 10 turns to avoid context length errors
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self.history[-20:]

        for _ in range(10):
            full_text, tool_calls, error = yield from self._call(messages)

            if error:
                yield ("error", error)
                return

            if tool_calls:
                messages.append({
                    "role":    "assistant",
                    "content": full_text or None,
                    "tool_calls": [
                        {"id": tc["id"], "type": "function",
                         "function": {"name": tc["name"], "arguments": tc["arguments"]}}
                        for tc in tool_calls
                    ],
                })
                tool_msgs = []
                for tc in tool_calls:
                    try:
                        args = json.loads(tc["arguments"] or "{}")
                    except json.JSONDecodeError:
                        args = {}
                    yield ("tool_use", {"name": tc["name"], "args": args})
                    result = tool_module.execute_tool(tc["name"], args)
                    yield ("tool_res", {"name": tc["name"], "result": result})
                    tool_msgs.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": result,
                    })
                messages.extend(tool_msgs)
            else:
                if full_text:
                    self.history.append({"role": "assistant", "content": full_text})
                return

    def _call(self, messages: list):
        full_text = ""
        tcs: dict[int, dict] = {}
        error = None

        try:
            for line in _stream_request(messages, tool_module.TOOL_DEFINITIONS):
                chunk = _parse_sse(line)
                if not chunk or not chunk.get("choices"):
                    continue
                delta = chunk["choices"][0].get("delta", {})

                content = delta.get("content")
                if content:
                    full_text += content
                    yield ("text", content)

                for tc in delta.get("tool_calls", []):
                    i = tc.get("index", 0)
                    if i not in tcs:
                        tcs[i] = {"id": "", "name": "", "arguments": ""}
                    if tc.get("id"):
                        tcs[i]["id"] = tc["id"]
                    fn = tc.get("function", {})
                    tcs[i]["name"]      += fn.get("name", "")
                    tcs[i]["arguments"] += fn.get("arguments", "")

        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            if e.code == 400 and "context" in body.lower():
                error = "Conversation too long — type 'clear' to start fresh."
            else:
                error = f"HTTP {e.code}: {body[:200]}"
        except Exception as exc:
            error = str(exc)

        return full_text, list(tcs.values()), error
