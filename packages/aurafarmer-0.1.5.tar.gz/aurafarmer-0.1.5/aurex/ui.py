import re
import time
import textwrap
from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner
from rich.rule import Rule
from rich.syntax import Syntax

console = Console(force_terminal=True, highlight=False)

BANNER = """\
 █████╗ ██╗   ██╗██████╗ ███████╗██╗  ██╗
██╔══██╗██║   ██║██╔══██╗██╔════╝╚██╗██╔╝
███████║██║   ██║██████╔╝█████╗   ╚███╔╝ 
██╔══██║██║   ██║██╔══██╗██╔══╝   ██╔██╗ 
██║  ██║╚██████╔╝██║  ██║███████╗██╔╝ ██╗
╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝"""

TOOL_ICONS = {
    "read_file":    "📖",
    "write_file":   "✏️ ",
    "run_command":  "⚡",
    "list_files":   "📁",
    "search_files": "🔍",
    "delete_file":  "🗑️ ",
    "web_search":   "🌐",
}

def _wrap(text: str) -> str:
    w = max(console.width - 6, 40)
    lines = []
    for line in text.splitlines():
        if len(line) > w:
            lines.extend(textwrap.wrap(line, width=w, break_long_words=True, break_on_hyphens=True))
        else:
            lines.append(line)
    return "\n".join(lines)

# ── Banner ─────────────────────────────────────────────────────────────────────
def print_banner() -> None:
    console.print(BANNER, style="bold red", justify="center")
    console.print("[dim]        AI Coding Agent[/dim]\n", justify="center")

def print_separator() -> None:
    console.print(Rule(style="dim red"))

# ── Spinner ────────────────────────────────────────────────────────────────────
def make_spinner(msg: str = "generating..."):
    return Spinner("dots2", text=f"[bold red]  ✦ Aurex[/bold red]  [dim]{msg}[/dim]")

def show_thinking() -> None:
    with Live(Spinner("dots2", text="[bold red]  deep thinking...[/bold red]"),
              console=console, transient=True, refresh_per_second=15):
        time.sleep(2.5)

# ── AI response — red text, code blocks syntax-highlighted ─────────────────────
def print_ai_response(text: str) -> None:
    console.print()
    console.print(Rule("[bold red] ✦ Aurex [/bold red]", style="red"))
    console.print()

    parts = re.split(r"(```[\s\S]*?```)", text)
    for part in parts:
        if part.startswith("```"):
            lines = part.split("\n")
            lang  = lines[0][3:].strip() or "text"
            code  = "\n".join(lines[1:]).rstrip("`").strip()
            console.print(Syntax(code, lang, theme="monokai",
                                 line_numbers=False, word_wrap=True,
                                 background_color="default"))
        else:
            stripped = part.strip()
            if stripped:
                for line in _wrap(stripped).splitlines():
                    console.print(line, style="red", highlight=False)

    console.print()
    console.print(Rule(style="dim red"))
    console.print()

# ── Tool events — blue header, green result ────────────────────────────────────
def print_tool_use(live, name: str, args: dict) -> None:
    icon = TOOL_ICONS.get(name, "🔧")
    live.console.print(f"\n  [bold blue]{icon}  {name}[/bold blue]")
    live.console.print(Rule(style="dim blue"))
    for k, v in args.items():
        val = str(v)
        if len(val) > 70:
            val = val[:70] + "…"
        live.console.print(f"  [blue]{k}:[/blue] {val}", soft_wrap=True, highlight=False)

def print_tool_result(live, name: str, result: str) -> None:
    MAX = 350
    raw = result[:MAX] + (f"\n  …{len(result)-MAX} more chars" if len(result) > MAX else "")
    live.console.print(Rule(style="dim green"))
    for line in _wrap(raw).splitlines():
        live.console.print(f"  {line}", style="green", soft_wrap=True, highlight=False)
    live.console.print()

# ── Misc ───────────────────────────────────────────────────────────────────────
def print_error(msg: str) -> None:
    console.print(f"\n  [bold red]✗[/bold red]  {msg}\n", soft_wrap=True)

def print_info(msg: str) -> None:
    console.print(f"  [dim red]ℹ[/dim red]  {msg}")

# ── Help ───────────────────────────────────────────────────────────────────────
def print_help() -> None:
    console.print()
    console.print(Rule("[bold red] Help [/bold red]", style="red"))
    console.print()

    console.print("  [bold white]Commands[/bold white]")
    console.print(Rule(style="dim red"))
    for cmd, desc in [
        ("help",        "Show this screen"),
        ("model",       "View and switch the active AI model"),
        ("clear",       "Wipe conversation history"),
        ("files",       "List files in current directory"),
        ("exit",        "Quit Aurex"),
    ]:
        console.print(f"  [red]{cmd:<14}[/red] [white]{desc}[/white]")

    console.print()
    console.print("  [bold white]Stop AI mid-response[/bold white]")
    console.print(Rule(style="dim red"))
    console.print("  Press [red]Ctrl+C[/red] while the AI is responding.")

    console.print()
    console.print("  [bold white]Thinking mode[/bold white]")
    console.print(Rule(style="dim red"))
    console.print("  Add [red]<think>[/red] to the end of your prompt.")
    console.print("  [dim]Example:[/dim]  [white]explain quicksort<think>[/white]")
    console.print("  The AI will reason step by step before answering.")

    console.print()
    console.print("  [bold white]Switch model[/bold white]")
    console.print(Rule(style="dim red"))
    console.print("  Type [red]model[/red] — then pick by number.")
    console.print("  Type [red]C[/red] to enter a fully custom model name.")

    console.print()
    console.print("  [bold white]Web search[/bold white]")
    console.print(Rule(style="dim red"))
    console.print("  Aurex can search the web automatically.")
    console.print("  Just ask something like: [white]search what is the latest python version[/white]")

    console.print()
    console.print(Rule(style="dim red"))
    console.print()

# ── Model UI ───────────────────────────────────────────────────────────────────
def print_current_model(display: str) -> None:
    console.print(f"\n  [dim]Active[/dim]  [bold red]aurex/{display}[/bold red]\n")

def print_model_list(models: list, current: str) -> None:
    console.print(Rule("[bold red] Models [/bold red]", style="red"))
    console.print()
    for i, (fake, _) in enumerate(models, 1):
        active = "  [green]◀ active[/green]" if fake == current else ""
        console.print(f"  [dim red]{i:>2}[/dim red]  [white]aurex/{fake}[/white]{active}")
    console.print()
    console.print("  [dim]number  ·  C for custom  ·  Enter to keep[/dim]\n")
