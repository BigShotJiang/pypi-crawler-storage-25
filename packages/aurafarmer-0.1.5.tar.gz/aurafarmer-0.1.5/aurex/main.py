import os
import sys
from rich.console import Console
from rich.live import Live

from . import config, ui
from .agent import AurexAgent
from . import tools as tool_module

console = ui.console

THINK_TAG    = "<think>"
THINK_INJECT = "\n\nThink carefully step by step before giving your final answer."

# ── Model command ──────────────────────────────────────────────────────────────
def handle_model_command(agent: AurexAgent) -> None:
    models  = config.MODELS
    current = config.get_model()
    ui.print_current_model(current)
    ui.print_model_list(models, current)

    try:
        choice = console.input("  [bold red]❯[/bold red] ").strip()
    except (KeyboardInterrupt, EOFError):
        return

    if not choice:
        ui.print_info(f"Keeping  aurex/{current}")
        return

    if choice.upper() == "C":
        try:
            custom = console.input("  [dim]Custom model name →[/dim] ").strip()
        except (KeyboardInterrupt, EOFError):
            return
        if custom:
            config.set_model(custom)
            ui.print_info(f"Model → aurex/{custom}")
    else:
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                fake, _ = models[idx]
                config.set_model(fake)
                console.print(f"\n  [dim]Model →[/dim] [bold red]aurex/{fake}[/bold red]\n")
            else:
                ui.print_error(f"Enter 1–{len(models)} or C.")
        except ValueError:
            ui.print_error("Invalid — number or C.")

# ── Agent runner ───────────────────────────────────────────────────────────────
def run_agent(agent: AurexAgent, user_input: str) -> None:
    think = THINK_TAG in user_input.lower()
    if think:
        idx = user_input.lower().find(THINK_TAG)
        api_input = user_input[:idx].strip() + THINK_INJECT
        ui.show_thinking()
    else:
        api_input = user_input

    full_text = ""
    stopped   = False

    try:
        with Live(ui.make_spinner(), console=console,
                  transient=True, refresh_per_second=15) as live:
            for event_type, data in agent.chat(api_input):

                if event_type == "text":
                    full_text += data
                    live.update(ui.make_spinner("writing..."))

                elif event_type == "tool_use":
                    live.update(ui.make_spinner(f"{data['name']}..."))
                    ui.print_tool_use(live, data["name"], data["args"])

                elif event_type == "tool_res":
                    ui.print_tool_result(live, data["name"], data["result"])
                    live.update(ui.make_spinner())

                elif event_type == "error":
                    live.console.print(f"\n  [bold red]✗[/bold red]  {data}\n",
                                       soft_wrap=True)

    except KeyboardInterrupt:
        stopped = True
        console.print("\n  [dim red]⊘ stopped[/dim red]\n")

    if full_text:
        ui.print_ai_response(full_text)

# ── Main REPL ──────────────────────────────────────────────────────────────────
def main() -> None:
    os.system("clear" if os.name == "posix" else "cls")
    ui.print_banner()

    model = config.get_model()
    console.print(f"  [dim]Model  [bold red]aurex/{model}[/bold red][/dim]")
    console.print(f"  [dim]CWD    [bold red]{os.getcwd()}[/bold red][/dim]")
    console.print(f"  [dim]Type   [bold red]help[/bold red]  for commands[/dim]")
    ui.print_separator()
    console.print()

    agent = AurexAgent()

    while True:
        try:
            user_input = console.input("[bold red]❯ [/bold red]").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold red]Goodbye.[/bold red]\n")
            sys.exit(0)

        if not user_input:
            continue

        cmd = user_input.lower().strip()

        if cmd in ("exit", "quit", "q"):
            console.print("\n[bold red]Goodbye.[/bold red]\n")
            sys.exit(0)
        elif cmd == "help":
            ui.print_help()
        elif cmd == "model":
            handle_model_command(agent)
        elif cmd == "clear":
            agent.clear_history()
            os.system("clear" if os.name == "posix" else "cls")
            ui.print_banner()
            ui.print_info("Conversation cleared.")
        elif cmd in ("files", "ls"):
            result = tool_module.list_files(".")
            console.print(f"\n  [dim red]{os.getcwd()}[/dim red]")
            console.print(result, style="white")
            console.print()
        else:
            run_agent(agent, user_input)

if __name__ == "__main__":
    main()
