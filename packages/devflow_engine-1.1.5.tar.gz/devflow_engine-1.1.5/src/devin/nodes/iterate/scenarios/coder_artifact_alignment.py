SCENARIO_NAME = "coder_artifact_alignment"
SCENARIO_DESCRIPTION = (
    "Coder output should stay aligned to the supplied observation artifact and not solve a "
    "different problem than the one observer bounded."
)
INPUT_PAYLOAD = {
    "role": "coder",
    "repo_root": "/Users/devflow/repos/devflow_engine",
    "task_artifact": {
        "task_type": "targeted_improvement",
        "surface": "CSV import wizard",
        "scope_boundary": "Trim whitespace around email values during import only.",
        "success_criteria": ["emails with surrounding spaces import successfully"],
    },
    "observation_artifact": {
        "failing_seam": "CSV preview rejects rows because email validation runs before whitespace trim.",
        "expected_green_condition": "Import preview trims email values before validation.",
        "repro_steps": [
            "Upload CSV with email value ' alice@example.com '",
            "Open import preview",
            "Observe invalid email validation error",
        ],
        "ready_for_coder": True,
    },
}
EXPECTED_BEHAVIOR = {
    "produces_coder_report": True,
    "aligns_to_observation_artifact": True,
    "stays_in_scope": True,
    "runs_narrow_verification": True,
    "reports_attempt_honestly": True,
}
