from devin.nodes.iterate.scenarios.coder_artifact_alignment import EXPECTED_BEHAVIOR

EVAL_CRITERIA = {
    "produces_coder_report": True,
    "aligns_to_observation_artifact": True,
    "stays_in_scope": True,
    "runs_narrow_verification": True,
    "reports_attempt_honestly": True,
}



def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []

    changed_files = actual_output.get("changed_files") or []
    if not changed_files:
        ok = False
        notes.append("missing changed_files for coder output")

    verification = actual_output.get("verification") or actual_output.get("verification_summary")
    if not verification:
        ok = False
        notes.append("missing verification aligned to observation_artifact")

    report_text = " ".join(
        str(v)
        for v in [
            actual_output.get("summary"),
            actual_output.get("what_changed"),
            actual_output.get("what_passed"),
            actual_output.get("what_failed"),
        ]
        if v
    ).lower()
    if report_text and not any(tok in report_text for tok in ("csv", "email", "trim", "validation", "preview")):
        ok = False
        notes.append("coder report does not align to the observation artifact seam")

    if report_text and any(tok in report_text for tok in ("invite", "dashboard", "unrelated cleanup", "schema redesign")):
        ok = False
        notes.append("coder output appears to solve a different problem than the observed seam")

    return ok, notes
