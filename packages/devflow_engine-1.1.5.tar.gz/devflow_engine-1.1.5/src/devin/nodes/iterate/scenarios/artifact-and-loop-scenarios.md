# Iterate artifact and loop scenarios

## Framing scenarios

### messy_error_report_with_partial_location
Expected checks:
- Framer derives `task_type=error_fix`
- captures partial surface or route hints
- separates facts from assumptions
- records blocking unknowns if needed
- uses the shared base `task_artifact` shape with `task_details.error_fix`

### tiny_copy_or_behavior_tweak
Expected checks:
- Framer keeps scope small
- success criteria stay observable
- no inflation into broader planning
- uses `task_details.quick_change` rather than inventing a separate task schema

### underspecified_but_repairable_request
Expected checks:
- Framer recommends `investigate_first`
- task artifact stays honest about unknowns
- Iterator does not move to `ready_for_coder` until observation truth exists

## Observation scenarios

### error_confirmed_by_logs
Expected checks:
- Observer records log evidence
- minimal repro exists or repeatability is confirmed
- verdict is `ready_for_coder`
- observation artifact names a green condition that later verifier summaries can cite

### user_reported_error_not_confirmed
Expected checks:
- Observer reports `not_confirmed` or `inconclusive`
- no fake repro claim
- verdict is `needs_more_context`
- iterator run stays in a pre-coding state or blocks honestly

### targeted_improvement_red_seam
Expected checks:
- Observer creates a bounded failing seam
- expected green condition is explicit
- seam remains narrow enough for attempt-scoped verifier artifacts
- later verifier records can state `green_condition_alignment` against one explicit seam without inventing verifier-specific top-level schemas

## Iterator loop scenarios

### coder_near_miss_then_repair_success
Expected checks:
- Iterator rejects premature success
- respawn reason is explicit
- first attempt stores summary in `iterator_run` and normalized verifier artifacts under `attempts/<attempt_id>/`
- first attempt uses `attempt-001`, second uses `attempt-002`
- second attempt converges on the scoped green condition
- `run_state` moves through `needs_respawn` to `completed`

### missing_truth_blocks_safe_implementation
Expected checks:
- Iterator does not spawn blindly or does not claim completion
- readiness is recorded as not ready or blocked, not buried in attempt notes
- terminal state is blocked with a concrete reason

### request_outgrows_iterate_during_loop
Expected checks:
- Iterator promotes or escalates instead of hiding broader planning inside iterate
- run record lands in `promoted`
- promotion is visible in the durable iterate record rather than implied only in chat output
- `promotion_handoff.json` exists and points back to the exact task and observation revisions that justified the promotion

### reroute_to_insight_after_observation
Expected checks:
- Observer discovers the user actually needed diagnosis or investigation, not implementation
- Iterator reroutes to `insight` instead of spawning Coder
- `promotion_handoff.json` records `target_lane=insight`
- downstream refs may be null, but the iterate-owned handoff record is present and auditable

## Coder attempt scenarios

### scoped_fix_succeeds_first_pass
Expected checks:
- Coder stays in scoped files or surfaces
- verification seam is relevant and narrow
- Iterator can validate completion without ambiguity
- run record references attempt-scoped verifier artifacts instead of inlining raw output
- verifier artifacts expose shared fields like `overall_result` and `green_condition_alignment` even if the underlying verifier payload differs

### first_pass_fails_but_report_is_honest
Expected checks:
- Coder reports what failed and what remains blocked
- Iterator has enough signal to craft a repair-specific retry
- attempt summary stays concise while preserving a pointer to fuller verifier output
- fuller verifier output still keeps the shared normalization envelope, with tool-specific detail nested under `native_payload`

### revised_task_before_coding
Expected checks:
- Framer can amend the task without creating a second task root
- `task_artifact.json` revision increases monotonically
- Iterator readiness cites the exact task and observation revisions it relied on
