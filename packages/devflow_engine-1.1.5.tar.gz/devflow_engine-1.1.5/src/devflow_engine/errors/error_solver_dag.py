from __future__ import annotations

import json
import subprocess
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from pydantic import BaseModel

from ..stores.execution_store import ExecutionStore
from ..vendor.datalumina_genai.core.nodes.base import Node
from ..vendor.datalumina_genai.core.nodes.router import BaseRouter, RouterNode
from ..vendor.datalumina_genai.core.schema import NodeConfig, WorkflowSchema
from ..vendor.datalumina_genai.core.task import TaskContext
from ..vendor.datalumina_genai.core.workflow import Workflow


class ErrorSolverEvent(BaseModel):
    repo_root: str
    error_task_id: str
    runtime_context: dict[str, Any] | None = None


_CURRENT_STORE: ExecutionStore | None = None
_CURRENT_FUNCS: dict[str, Any] | None = None


def configure_runtime(*, store: ExecutionStore, funcs: dict[str, Any]) -> None:
    global _CURRENT_STORE, _CURRENT_FUNCS
    _CURRENT_STORE = store
    _CURRENT_FUNCS = funcs


def _runtime() -> tuple[ExecutionStore, dict[str, Any]]:
    if _CURRENT_STORE is None or _CURRENT_FUNCS is None:
        raise RuntimeError("Error solver DAG missing runtime store/functions")
    return _CURRENT_STORE, _CURRENT_FUNCS


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _tail_text(path: Path, *, max_chars: int = 4000) -> str:
    try:
        data = path.read_text(encoding="utf-8")
    except Exception:
        return ""
    return data[-max_chars:]


def _append_error_solver_journal(
    *,
    repo_root: Path,
    error_task_id: str,
    outcome: str,
    title: str | None,
    fingerprint: str | None,
    verification: dict[str, Any] | None,
    reason: str | None,
    context_path: Path,
    runtime_context: dict[str, Any] | None,
    prior_runs: dict[str, Any] | None,
) -> Path:
    d = repo_root / ".devflow" / "journal"
    d.mkdir(parents=True, exist_ok=True)
    day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    md = d / f"{day}.md"

    current_record = runtime_context.get("currentRecord") if isinstance(runtime_context, dict) and isinstance(runtime_context.get("currentRecord"), dict) else {}
    latest_resolved = prior_runs.get("latestResolved") if isinstance(prior_runs, dict) and isinstance(prior_runs.get("latestResolved"), dict) else None

    lines = [
        f"## Error solver conclusion {uuid.uuid4().hex[:8]}",
        f"- time (UTC): {_utc_now_iso()}",
        f"- repo: `{repo_root}`",
        f"- error_task_id: `{error_task_id}`",
        f"- title: `{title or ''}`",
        f"- fingerprint: `{fingerprint or ''}`",
        f"- outcome: `{outcome}`",
        f"- reason: `{reason or ''}`",
        f"- context: `{context_path}`",
        f"- current_triage_status: `{current_record.get('triage_status') or ''}`",
        f"- previous_resolved_error_task_id: `{(latest_resolved or {}).get('errorTaskId') or ''}`",
        "",
        "Summary:",
        "```",
        json.dumps(
            {
                "verification": verification,
                "current_record": current_record,
                "latest_resolved": latest_resolved,
            },
            indent=2,
            sort_keys=True,
        )[:8000],
        "```",
        "",
    ]

    if md.exists():
        existing = md.read_text(encoding="utf-8")
        if not existing.endswith("\n"):
            existing += "\n"
        md.write_text(existing + "\n".join(lines), encoding="utf-8")
    else:
        md.write_text("# LLM Journal\n\n" + "\n".join(lines), encoding="utf-8")

    return md


def _read_recent_journal(repo_root: Path, *, limit_files: int = 3, max_chars: int = 6000) -> dict[str, Any]:
    journal_dir = repo_root / ".devflow" / "journal"
    if not journal_dir.exists():
        return {"entries": [], "summary": ""}

    files = sorted(journal_dir.glob("*.md"))[-limit_files:]
    entries: list[dict[str, Any]] = []
    chunks: list[str] = []
    for path in files:
        tail = _tail_text(path, max_chars=max_chars // max(1, len(files)))
        entries.append({"path": str(path), "excerpt": tail})
        if tail:
            chunks.append(f"# {path.name}\n{tail}")
    summary = "\n\n".join(chunks)
    return {"entries": entries, "summary": summary[-max_chars:]}


def _git_changes_since(repo_root: Path, *, unix_ts: int | None) -> dict[str, Any]:
    if not unix_ts:
        return {"summary": "", "commits": []}
    cmd = [
        "git",
        "-C",
        str(repo_root),
        "log",
        f"--since=@{int(unix_ts)}",
        "--date=iso",
        "--pretty=format:%H%x09%ad%x09%s",
        "--name-only",
        "--no-merges",
        "-n",
        "20",
    ]
    cp = subprocess.run(cmd, text=True, capture_output=True, check=False)
    if cp.returncode != 0:
        return {"summary": "", "commits": [], "error": (cp.stderr or cp.stdout)[-2000:]}
    text = (cp.stdout or "").strip()
    return {"summary": text[-8000:], "commits": []}


def _load_prior_runs(*, store: ExecutionStore, repo_root: Path, error_task_id: str, fingerprint: str | None) -> dict[str, Any]:
    if not fingerprint:
        return {"resolvedSiblings": [], "latestResolved": None, "gitChangesSinceLatestResolved": {"summary": "", "commits": []}, "devJournal": _read_recent_journal(repo_root)}

    resolved_rows: list[dict[str, Any]] = []
    with store._connect() as conn:
        rows = conn.execute(
            "SELECT error_task_id, title, message, updated_at, created_at, status FROM error_tasks WHERE fingerprint=? AND error_task_id<>? AND status='resolved' ORDER BY updated_at DESC LIMIT 5",
            (fingerprint, error_task_id),
        ).fetchall()
        for row in rows:
            sibling_id = row["error_task_id"]
            context_path = repo_root / ".devflow" / "errors" / "logs" / sibling_id / "context.json"
            sibling_context = None
            fix_summary = None
            if context_path.exists():
                try:
                    sibling_context = json.loads(context_path.read_text(encoding="utf-8"))
                except Exception:
                    sibling_context = None
            if isinstance(sibling_context, dict):
                first_pass = ((sibling_context.get("FirstPassFix") or {}).get("output")) or {}
                iterative = ((sibling_context.get("IterativeFix") or {}).get("output")) or {}
                verification = ((sibling_context.get("Resolve") or {}).get("output")) or {}
                fix_summary = {
                    "firstPass": first_pass,
                    "iterative": iterative,
                    "resolve": verification,
                }
            resolved_rows.append(
                {
                    "errorTaskId": sibling_id,
                    "title": row["title"],
                    "message": row["message"],
                    "updatedAt": row["updated_at"],
                    "createdAt": row["created_at"],
                    "status": row["status"],
                    "contextPath": str(context_path),
                    "fixSummary": fix_summary,
                }
            )

    latest = resolved_rows[0] if resolved_rows else None
    latest_ts = int(latest["updatedAt"]) if latest and latest.get("updatedAt") else None
    return {
        "resolvedSiblings": resolved_rows,
        "latestResolved": latest,
        "gitChangesSinceLatestResolved": _git_changes_since(repo_root, unix_ts=latest_ts),
        "devJournal": _read_recent_journal(repo_root),
    }


@dataclass
class ContextPersistor:
    repo_root: Path
    error_task_id: str

    def __post_init__(self) -> None:
        self.repo_root = Path(self.repo_root)
        self.logs_dir = self.repo_root / ".devflow" / "errors" / "logs" / self.error_task_id
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.context_path = self.logs_dir / "context.json"

    def init(
        self,
        *,
        title: str | None = None,
        error_type: str | None = None,
        runtime_context: dict[str, Any] | None = None,
        prior_runs: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        now = int(time.time())
        ctx: dict[str, Any] = {
            "metadata": {
                "workflowStarted": now,
                "errorId": self.error_task_id,
                "projectPath": str(self.repo_root),
                "errorType": error_type,
                "priority": None,
                "sessionId": None,
                "title": title,
                "node_order": [],
            }
        }
        if runtime_context is not None:
            ctx["runtimeContext"] = runtime_context
        if prior_runs is not None:
            ctx["priorRuns"] = prior_runs
        self.context_path.write_text(json.dumps(ctx, sort_keys=True, indent=2) + "\n")
        return ctx

    def persist(self, *, context: dict[str, Any], node_name: str, output: dict[str, Any]) -> None:
        context.setdefault("metadata", {})
        context["metadata"]["lastUpdated"] = int(time.time())
        context["metadata"].setdefault("node_order", []).append(node_name)
        context[node_name] = {"timestamp": int(time.time()), "output": output}
        self.context_path.write_text(json.dumps(context, sort_keys=True, indent=2) + "\n")


class BuildObservabilityNode(Node):
    class OutputType(BaseModel):
        observable: bool = True
        details: dict[str, Any] = {}

    async def process(self, task_context: TaskContext) -> TaskContext:
        store, funcs = _runtime()
        repo_root = Path(task_context.event.repo_root)
        error_task_id = task_context.event.error_task_id

        # Ensure we have a persistor + base context
        persistor: ContextPersistor = task_context.metadata.setdefault(
            "context_persistor", ContextPersistor(repo_root=repo_root, error_task_id=error_task_id)
        )
        context: dict[str, Any] = task_context.metadata.get("context_json")
        if context is None:
            db_fingerprint = None
            with store._connect() as conn:  # best-effort read
                row = conn.execute(
                    "SELECT title, error_type, fingerprint FROM error_tasks WHERE error_task_id=?",
                    (error_task_id,),
                ).fetchone()
            title = None
            error_type = None
            if row is not None:
                title = row[0]
                error_type = row[1]
                db_fingerprint = row[2]
            runtime_context = task_context.event.runtime_context if isinstance(task_context.event.runtime_context, dict) else None
            prior_runs = _load_prior_runs(
                store=store,
                repo_root=repo_root,
                error_task_id=error_task_id,
                fingerprint=str(db_fingerprint) if isinstance(db_fingerprint, str) and db_fingerprint else None,
            )
            context = persistor.init(
                title=title,
                error_type=error_type,
                runtime_context=runtime_context,
                prior_runs=prior_runs,
            )
            task_context.metadata["context_json"] = context

        fn: Callable[[dict[str, Any]], dict[str, Any]] = funcs["build_observability_fn"]
        out = fn(context)
        persistor.persist(context=context, node_name="BuildObservability", output=out)
        self.save_output(BuildObservabilityNode.OutputType(**{"observable": bool(out.get("observable", True)), "details": out}))
        return task_context


class FirstPassFixNode(Node):
    class OutputType(BaseModel):
        fixed: bool = False
        verification: dict[str, Any] | None = None

    async def process(self, task_context: TaskContext) -> TaskContext:
        _, funcs = _runtime()
        persistor: ContextPersistor = task_context.metadata["context_persistor"]
        context: dict[str, Any] = task_context.metadata["context_json"]

        fn: Callable[[dict[str, Any]], dict[str, Any]] = funcs["first_pass_fix_fn"]
        out = fn(context)
        persistor.persist(context=context, node_name="FirstPassFix", output=out)
        self.save_output(
            FirstPassFixNode.OutputType(
                fixed=bool(out.get("fixed")),
                verification=out.get("verification"),
            )
        )

        task_context.metadata["fixed"] = bool(out.get("fixed"))
        task_context.metadata["verification"] = out.get("verification")
        return task_context


class IterativeFixNode(Node):
    class OutputType(BaseModel):
        fixed: bool = False
        details: dict[str, Any] = {}

    async def process(self, task_context: TaskContext) -> TaskContext:
        _, funcs = _runtime()
        persistor: ContextPersistor = task_context.metadata["context_persistor"]
        context: dict[str, Any] = task_context.metadata["context_json"]

        # Only run if not already fixed.
        if task_context.metadata.get("fixed"):
            self.save_output(IterativeFixNode.OutputType(fixed=True, details={"skipped": True}))
            return task_context

        fn: Callable[[dict[str, Any]], dict[str, Any]] = funcs["iterative_fix_fn"]
        out = fn(context)
        persistor.persist(context=context, node_name="IterativeFix", output=out)
        self.save_output(IterativeFixNode.OutputType(fixed=bool(out.get("fixed")), details=out))

        task_context.metadata["fixed"] = bool(out.get("fixed"))
        if out.get("verification") is not None:
            task_context.metadata["verification"] = out.get("verification")
        return task_context


class FinalOutcomeRouteNode(Node):
    class OutputType(BaseModel):
        fixed: bool
        outcome: str

    async def process(self, task_context: TaskContext) -> TaskContext:
        _, funcs = _runtime()
        persistor: ContextPersistor = task_context.metadata["context_persistor"]
        context: dict[str, Any] = task_context.metadata["context_json"]

        fixed = bool(task_context.metadata.get("fixed"))
        needs_user_input_fn: Callable[[dict[str, Any]], bool] = funcs["needs_user_input_fn"]
        needs_user_input = bool(needs_user_input_fn(context))

        outcome = "resolved" if fixed else ("blocked" if needs_user_input else "blocked")
        out = {"fixed": fixed, "needs_user_input": needs_user_input, "outcome": outcome}
        persistor.persist(context=context, node_name="FinalOutcomeRoute", output=out)
        self.save_output(FinalOutcomeRouteNode.OutputType(fixed=fixed, outcome=outcome))
        return task_context


class ResolveNode(Node):
    class OutputType(BaseModel):
        verified: bool
        verification: dict[str, Any] | None = None

    async def process(self, task_context: TaskContext) -> TaskContext:
        store, _ = _runtime()
        persistor: ContextPersistor = task_context.metadata["context_persistor"]
        context: dict[str, Any] = task_context.metadata["context_json"]
        error_task_id = task_context.event.error_task_id

        verification = task_context.metadata.get("verification")
        verified = bool((verification or {}).get("green_gate"))
        runtime_context = context.get("runtimeContext") if isinstance(context.get("runtimeContext"), dict) else None
        prior_runs = context.get("priorRuns") if isinstance(context.get("priorRuns"), dict) else None
        fingerprint = None
        if isinstance(runtime_context, dict):
            current_record = runtime_context.get("currentRecord") if isinstance(runtime_context.get("currentRecord"), dict) else {}
            fingerprint = runtime_context.get("fingerprint") or current_record.get("fingerprint")
        title = context.get("metadata", {}).get("title") if isinstance(context.get("metadata"), dict) else None

        persistor.persist(context=context, node_name="Resolve", output={"verification": verification, "verified": verified})
        self.save_output(ResolveNode.OutputType(verified=verified, verification=verification))

        if verified:
            with store._connect() as conn:
                conn.execute(
                    "UPDATE error_tasks SET status='resolved', updated_at=? WHERE error_task_id=?",
                    (int(time.time()), error_task_id),
                )
            task_context.metadata["outcome"] = "resolved"
            task_context.metadata["reason"] = None
        else:
            # verification failure: do NOT resolve.
            with store._connect() as conn:
                conn.execute(
                    "UPDATE error_tasks SET status='in_progress', updated_at=? WHERE error_task_id=?",
                    (int(time.time()), error_task_id),
                )
            task_context.metadata["outcome"] = "in_progress"
            task_context.metadata["reason"] = "verification_failed"

        _append_error_solver_journal(
            repo_root=persistor.repo_root,
            error_task_id=error_task_id,
            outcome=str(task_context.metadata.get("outcome") or "in_progress"),
            title=str(title) if title is not None else None,
            fingerprint=str(fingerprint) if fingerprint is not None else None,
            verification=verification,
            reason=str(task_context.metadata.get("reason")) if task_context.metadata.get("reason") else None,
            context_path=persistor.context_path,
            runtime_context=runtime_context,
            prior_runs=prior_runs,
        )

        task_context.stop_workflow()
        return task_context


class BlockNode(Node):
    class OutputType(BaseModel):
        reason: str

    async def process(self, task_context: TaskContext) -> TaskContext:
        store, funcs = _runtime()
        persistor: ContextPersistor = task_context.metadata["context_persistor"]
        context: dict[str, Any] = task_context.metadata["context_json"]
        error_task_id = task_context.event.error_task_id

        needs_user_input_fn: Callable[[dict[str, Any]], bool] = funcs["needs_user_input_fn"]
        needs_user_input = bool(needs_user_input_fn(context))
        reason = "user_input_required" if needs_user_input else "attempts_exhausted"
        runtime_context = context.get("runtimeContext") if isinstance(context.get("runtimeContext"), dict) else None
        prior_runs = context.get("priorRuns") if isinstance(context.get("priorRuns"), dict) else None
        fingerprint = None
        if isinstance(runtime_context, dict):
            current_record = runtime_context.get("currentRecord") if isinstance(runtime_context.get("currentRecord"), dict) else {}
            fingerprint = runtime_context.get("fingerprint") or current_record.get("fingerprint")
        title = context.get("metadata", {}).get("title") if isinstance(context.get("metadata"), dict) else None

        persistor.persist(context=context, node_name="Block", output={"reason": reason})
        self.save_output(BlockNode.OutputType(reason=reason))

        with store._connect() as conn:
            conn.execute(
                "UPDATE error_tasks SET status='blocked', updated_at=? WHERE error_task_id=?",
                (int(time.time()), error_task_id),
            )

        task_context.metadata["outcome"] = "blocked"
        _append_error_solver_journal(
            repo_root=persistor.repo_root,
            error_task_id=error_task_id,
            outcome="blocked",
            title=str(title) if title is not None else None,
            fingerprint=str(fingerprint) if fingerprint is not None else None,
            verification=task_context.metadata.get("verification"),
            reason=reason,
            context_path=persistor.context_path,
            runtime_context=runtime_context,
            prior_runs=prior_runs,
        )
        task_context.stop_workflow()
        return task_context


class _RouteToResolve(RouterNode):
    def determine_next_node(self, task_context: TaskContext) -> Optional[Node]:
        route = task_context.nodes.get(FinalOutcomeRouteNode.__name__)
        fixed = bool(getattr(route, "fixed", None)) if route is not None else bool(task_context.metadata.get("fixed"))
        if fixed:
            return ResolveNode(task_context=task_context)
        return None


class _RouteToBlock(RouterNode):
    def determine_next_node(self, task_context: TaskContext) -> Optional[Node]:
        route = task_context.nodes.get(FinalOutcomeRouteNode.__name__)
        fixed = bool(getattr(route, "fixed", None)) if route is not None else bool(task_context.metadata.get("fixed"))
        if not fixed:
            return BlockNode(task_context=task_context)
        return None


class FinalOutcomeRouter(BaseRouter):
    def __init__(self) -> None:
        # Router reads from task_context via RouterNode wrappers.
        self.routes = [_RouteToResolve(), _RouteToBlock()]
        self.fallback = BlockNode()


class ErrorSolverWorkflow(Workflow):
    workflow_schema: WorkflowSchema = WorkflowSchema(
        description="US-8.5 error solver DAG (Electron parity)",
        event_schema=ErrorSolverEvent,
        start=BuildObservabilityNode,
        nodes=[
            NodeConfig(node=BuildObservabilityNode, connections=[FirstPassFixNode]),
            NodeConfig(node=FirstPassFixNode, connections=[IterativeFixNode]),
            NodeConfig(node=IterativeFixNode, connections=[FinalOutcomeRouteNode]),
            NodeConfig(node=FinalOutcomeRouteNode, connections=[FinalOutcomeRouter]),
            NodeConfig(node=FinalOutcomeRouter, connections=[ResolveNode, BlockNode], is_router=True),
            NodeConfig(node=ResolveNode, connections=[]),
            NodeConfig(node=BlockNode, connections=[]),
        ],
    )
