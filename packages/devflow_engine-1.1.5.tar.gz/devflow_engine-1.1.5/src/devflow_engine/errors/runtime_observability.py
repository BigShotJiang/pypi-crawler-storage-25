"""Runtime observability bundle builder for the error-solver DAG."""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any


def build_runtime_observability(
    *,
    repo_root: Path,
    runtime_context: dict[str, Any] | None = None,
    repro_command: str | None = None,
    project_id: str | None = None,
    store: Any = None,
    error_task_id: str | None = None,
) -> dict[str, Any]:
    """Gather observable runtime context for the error-solver DAG.

    Returns a structured evidence bundle that the error-solver DAG passes to
    its build_observability_fn hook so diagnose/fix nodes have environment
    context (git status, recent logs, runtime_context payload, etc.).
    """
    git_status: str = ""
    git_log: str = ""
    try:
        r = subprocess.run(["git", "status", "--short"], cwd=str(repo_root), capture_output=True, text=True, check=False)
        git_status = r.stdout.strip()
    except Exception:
        pass
    try:
        r = subprocess.run(["git", "log", "--oneline", "-10"], cwd=str(repo_root), capture_output=True, text=True, check=False)
        git_log = r.stdout.strip()
    except Exception:
        pass

    return {
        "artifactVersion": "runtime_evidence_bundle/v1",
        "observable": True,
        "repo_root": str(repo_root),
        "project_id": project_id,
        "error_task_id": error_task_id,
        "runtime_context": runtime_context or {},
        "repro_command": repro_command,
        "git_status": git_status,
        "git_log": git_log,
    }


def collect_runtime_evidence_bundle(
    *,
    repo_root: Path,
    runtime_context: dict[str, Any] | None = None,
    repro_command: str | None = None,
    project_id: str | None = None,
    store: Any = None,
    error_task_id: str | None = None,
) -> dict[str, Any]:
    """Compatibility wrapper for the error-solver DAG import path."""
    return build_runtime_observability(
        repo_root=repo_root,
        runtime_context=runtime_context,
        repro_command=repro_command,
        project_id=project_id,
        store=store,
        error_task_id=error_task_id,
    )
