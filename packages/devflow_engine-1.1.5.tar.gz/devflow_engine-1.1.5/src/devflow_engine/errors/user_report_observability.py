"""LLM-driven first-pass analyzer for user-reported errors.

User reports don't ship with a stacktrace or a repro command, so the
existing build_observability_fn (which shells out to a repro command)
returns `{observable: False, reason: "missing_repro_command"}` for them.
This module does what makes sense for that intake instead: read the
report + the repo and produce a structured analysis that points at
likely files, suggests a repro test, and surfaces follow-up questions
the user needs to answer before we can act.

Output is persisted in two places:
- `<repo>/.devflow/errors/logs/<error_task_id>/context.json` under the
  `BuildObservability` key (matches the DAG's existing convention so a
  later worker can pick up where we left off).
- `error_tasks.observability_json` column (so the dashboard list view
  can render without N file reads).

Status: open → observed on success. On failure, status stays open and
the error gets logged under `context.ObservabilityError` so the user
can re-trigger later.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field

from ..llm.invoke import LlmInvocationRequest, invoke_llm

logger = logging.getLogger(__name__)

ARTIFACT_VERSION = "user_report_observability/v1"
_MAX_REPO_TREE_ENTRIES = 60
_MAX_FILE_READ_LINES = 200
_MAX_FILES_FROM_HINTS = 3
_LLM_TIMEOUT_SECONDS = 90


# ---------------------------------------------------------------------------
# Output schema — what the LLM is asked to emit.
# ---------------------------------------------------------------------------


class FileHit(BaseModel):
    path: str = Field(description="Workspace-relative path.")
    reason: str = Field(description="Why this file is likely involved.")


class ReproTest(BaseModel):
    name: str = Field(description="Short test name (e.g. test_save_button_persists).")
    file: str = Field(description="Suggested path where the test should live.")
    rationale: str = Field(description="What this test would assert to reproduce the bug.")
    language: Literal["python", "javascript", "typescript", "go", "rust", "other"] = "other"


class ObservabilityOutput(BaseModel):
    summary: str = Field(description="One-paragraph plain-English overview of the bug + likely cause.")
    affected_files: list[FileHit] = Field(default_factory=list)
    likely_location: str | None = Field(
        default=None,
        description="One-line pointer at the most-suspect spot (e.g. 'SaveButton handler in admin/Profile.tsx:42-68').",
    )
    repro_tests: list[ReproTest] = Field(default_factory=list)
    open_questions: list[str] = Field(
        default_factory=list,
        description="Specific questions that, if answered, would let the next pass act with confidence.",
    )
    confidence: Literal["low", "medium", "high"] = "low"


# ---------------------------------------------------------------------------
# Repo context loaders — bounded so token usage stays predictable.
# ---------------------------------------------------------------------------


_EXCLUDE_DIRS = {
    ".git", ".github", ".devflow", ".venv", "venv", ".tox",
    "node_modules", "__pycache__", "dist", "build", "target",
    ".next", ".cache", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "vendor", "coverage",
}


def _read_repo_knowledge(repo_root: Path, *, max_chars: int = 6000) -> str | None:
    md = repo_root / ".devflow" / "llm" / "repo_knowledge.md"
    if not md.is_file():
        return None
    try:
        text = md.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    return text[:max_chars]


def _shallow_tree(repo_root: Path, *, max_entries: int = _MAX_REPO_TREE_ENTRIES) -> list[str]:
    out: list[str] = []
    try:
        children = sorted(repo_root.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
    except OSError:
        return out
    for child in children:
        if child.name in _EXCLUDE_DIRS or child.name.startswith("."):
            continue
        suffix = "/" if child.is_dir() else ""
        out.append(child.name + suffix)
        if len(out) >= max_entries:
            break
    return out


def _resolve_hint_paths(repo_root: Path, hints: list[str], *, max_files: int = _MAX_FILES_FROM_HINTS) -> list[Path]:
    """Pull plausible workspace-relative file paths out of free-text hints
    (whereInApp / page_url / message). Best-effort — anything that doesn't
    resolve to a real file under the workspace is dropped."""
    seen: list[Path] = []
    for hint in hints:
        if not hint:
            continue
        # Strip leading slashes, query/fragment, common URL prefix patterns.
        candidate = hint.strip()
        if "://" in candidate:
            candidate = candidate.split("://", 1)[1]
            if "/" in candidate:
                candidate = candidate.split("/", 1)[1]
        candidate = candidate.split("?", 1)[0].split("#", 1)[0].lstrip("/").strip()
        if not candidate or candidate in {".", ".."}:
            continue
        target = (repo_root / candidate).resolve()
        try:
            target.relative_to(repo_root.resolve())
        except ValueError:
            continue
        if target.is_file() and target not in seen:
            seen.append(target)
        if len(seen) >= max_files:
            break
    return seen


def _read_file_head(path: Path, *, max_lines: int = _MAX_FILE_READ_LINES) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    lines = text.splitlines()[:max_lines]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Storage helpers — mirror the DAG's ContextPersistor convention.
# ---------------------------------------------------------------------------


def _error_logs_dir(repo_root: Path, error_task_id: str) -> Path:
    d = repo_root / ".devflow" / "errors" / "logs" / error_task_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def _persist_context_section(repo_root: Path, error_task_id: str, *, section: str, output: dict[str, Any]) -> Path:
    """Write/extend `context.json` under the per-error log dir, same shape
    as DAG's ContextPersistor.persist(): top-level `metadata.node_order`
    list plus a section per node-name with `{timestamp, output}`."""
    ctx_path = _error_logs_dir(repo_root, error_task_id) / "context.json"
    context: dict[str, Any] = {}
    if ctx_path.exists():
        try:
            context = json.loads(ctx_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            context = {}
    meta = context.setdefault("metadata", {})
    meta["lastUpdated"] = int(time.time())
    meta.setdefault("node_order", []).append(section)
    context[section] = {"timestamp": int(time.time()), "output": output}
    ctx_path.write_text(json.dumps(context, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return ctx_path


_OBS_ROW_UNCHANGED = object()


def _update_error_task_row(
    *,
    store: Any,
    error_task_id: str,
    observability_output: dict[str, Any] | None = _OBS_ROW_UNCHANGED,  # type: ignore[assignment]
    new_status: str | None = None,
    observability_error: str | None = _OBS_ROW_UNCHANGED,  # type: ignore[assignment]
) -> None:
    """Direct SQL because there isn't an existing helper on ExecutionStore
    for these fields. Same connection pattern the DAG nodes use.

    Sentinel ``_OBS_ROW_UNCHANGED`` means "don't touch this column";
    passing ``None`` explicitly means "set this column to NULL." That
    distinction matters for clearing observability_error on success.
    """
    fields: list[str] = []
    args: list[Any] = []
    if observability_output is not _OBS_ROW_UNCHANGED:
        fields.append("observability_json=?")
        args.append(
            json.dumps(observability_output, ensure_ascii=False, sort_keys=True)
            if observability_output is not None else None
        )
    if observability_error is not _OBS_ROW_UNCHANGED:
        fields.append("observability_error=?")
        args.append(observability_error)
    if new_status is not None:
        fields.append("status=?")
        args.append(new_status)
    if not fields:
        return
    fields.append("updated_at=?")
    args.append(int(time.time()))
    args.append(error_task_id)
    with store._connect() as conn:
        store._ensure_error_tasks_schema(conn)
        conn.execute(
            f"UPDATE error_tasks SET {', '.join(fields)} WHERE error_task_id=?",
            tuple(args),
        )


# ---------------------------------------------------------------------------
# LLM prompt assembly + invocation.
# ---------------------------------------------------------------------------


def _load_error_task(store: Any, error_task_id: str) -> dict[str, Any] | None:
    with store._connect() as conn:
        store._ensure_error_tasks_schema(conn)
        row = conn.execute(
            "SELECT error_task_id, project_id, source_app, source_kind, title, message, "
            "expected_behavior, steps_to_reproduce_json, report_context_json, severity, "
            "reporter_username, reporter_email "
            "FROM error_tasks WHERE error_task_id=?",
            (error_task_id,),
        ).fetchone()
    if row is None:
        return None
    try:
        steps = json.loads(row["steps_to_reproduce_json"] or "[]")
    except (TypeError, ValueError):
        steps = []
    try:
        ctx = json.loads(row["report_context_json"] or "{}")
    except (TypeError, ValueError):
        ctx = {}
    return {
        "error_task_id": row["error_task_id"],
        "project_id": row["project_id"],
        "source_app": row["source_app"],
        "source_kind": row["source_kind"],
        "title": row["title"],
        "message": row["message"],
        "expected_behavior": row["expected_behavior"],
        "steps_to_reproduce": steps,
        "report_context": ctx,
        "severity": row["severity"],
        "reporter": {
            "username": row["reporter_username"],
            "email": row["reporter_email"],
        },
    }


def _build_prompt_payload(
    *,
    error: dict[str, Any],
    repo_root: Path,
) -> dict[str, Any]:
    ctx = error.get("report_context") or {}
    hints = [
        str(ctx.get("page_url") or ""),
        str(ctx.get("where_in_app") or ""),
        str(ctx.get("path") or ""),
    ]
    hint_files = _resolve_hint_paths(repo_root, hints)
    file_excerpts = [
        {
            "path": str(p.relative_to(repo_root)),
            "head": _read_file_head(p),
        }
        for p in hint_files
    ]

    return {
        "task": "user_report_observability",
        "instruction": (
            "You are the first-pass observability analyzer for a user-reported bug in "
            "a real codebase. Read the report and the supplied repository context, then "
            "emit a SINGLE JSON OBJECT matching the supplied output_schema. The response "
            "MUST be one top-level object with these keys: summary (string), "
            "affected_files (list), likely_location (string|null), repro_tests (list), "
            "open_questions (list), confidence ('low'|'medium'|'high'). Do NOT return a "
            "bare list of file hits — that's the affected_files VALUE, not the whole "
            "response. Be concrete: every affected_files entry needs a workspace-relative "
            "path + reason; every repro_test needs a plausible filename and language. "
            "Use 'open_questions' for anything you can't answer from the supplied "
            "context — do NOT guess. Confidence is your honest signal: 'high' only when "
            "you can name the function and reproduction steps, 'low' when open_questions "
            "has multiple items."
        ),
        "error_report": {
            "title": error.get("title"),
            "message": error.get("message"),
            "expected_behavior": error.get("expected_behavior"),
            "steps_to_reproduce": error.get("steps_to_reproduce"),
            "severity": error.get("severity"),
            "report_context": ctx,
            "reporter": error.get("reporter"),
        },
        "repo_context": {
            "tree_top_level": _shallow_tree(repo_root),
            "repo_knowledge_md": _read_repo_knowledge(repo_root),
            "file_excerpts_from_hints": file_excerpts,
        },
        "output_schema": ObservabilityOutput.model_json_schema(),
        "return_format": "json_only",
    }


def _looks_like_file_hit(item: Any) -> bool:
    """Heuristic: a dict with both 'path' and 'reason' string fields is a
    FileHit-shaped record. Used to recognize the model's frequent
    bare-list-of-affected-files near-miss against ObservabilityOutput."""
    return (
        isinstance(item, dict)
        and isinstance(item.get("path"), str)
        and isinstance(item.get("reason"), str)
    )


def _normalize_llm_payload(parsed: Any) -> tuple[Any, bool]:
    """Return ``(payload, was_wrapped)``. If `parsed` is already a dict
    we pass it through unchanged. If it's a list of FileHit-shaped
    dicts (the most common near-miss MiniMax emits), we wrap it as
    `affected_files` with low confidence and an explicit open_question
    saying so — the tolerance is visible in the output, not hidden."""
    if isinstance(parsed, dict):
        return parsed, False
    if isinstance(parsed, list) and parsed and all(_looks_like_file_hit(it) for it in parsed):
        return (
            {
                "summary": (
                    "Model returned a bare list of affected files without the "
                    "ObservabilityOutput envelope; wrapped client-side. "
                    "Re-run for a full analysis."
                ),
                "affected_files": parsed,
                "likely_location": None,
                "repro_tests": [],
                "open_questions": [
                    "Model response was a bare list and missed the response "
                    "envelope — re-run, or tighten the prompt's wrapper "
                    "requirement, to get summary / likely_location / repro_tests.",
                ],
                "confidence": "low",
            },
            True,
        )
    return parsed, False


def _call_llm(*, repo_root: Path, prompt_payload: dict[str, Any]) -> ObservabilityOutput | str:
    """Returns ObservabilityOutput on success or a string error reason on failure."""
    try:
        # transport="api" + provider="minimax" — the engine container has
        # MINIMAX_API_KEY injected from clarity tenant secrets at compose
        # render time, but no `codex`/`claude` CLI is installed, so the
        # invoke_llm default (CLI mode) fails with "LLM not configured for
        # CLI mode". Hard-wiring API + minimax matches the project-wide
        # "medium tier is MiniMax" policy.
        result = invoke_llm(
            LlmInvocationRequest(
                purpose="user_report_observability",
                repo_root=repo_root,
                prompt="",
                prompt_payload=prompt_payload,
                delivery_model="final_only",
                interaction_model="request_response",
                response_contract="json_only",
                timeout_seconds=_LLM_TIMEOUT_SECONDS,
                strength="medium",
                transport="api",
                provider="minimax",
            )
        )
    except Exception as exc:
        return f"llm_invoke_raised: {exc}"
    if not result.ok:
        return f"llm_not_ok: rc={result.returncode} stderr={(result.stderr or '')[:300]}"
    if not result.contract_ok or result.parsed_json is None:
        return f"llm_contract_failed: {(result.contract_error or result.stdout or '')[:300]}"
    normalized, _ = _normalize_llm_payload(result.parsed_json)
    try:
        return ObservabilityOutput.model_validate(normalized)
    except Exception as exc:
        return f"output_schema_validation_failed: {exc}"


# ---------------------------------------------------------------------------
# Public entry point.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ObservabilityRunResult:
    error_task_id: str
    status: str                    # 'observed' on success, 'open' on failure
    output: dict[str, Any] | None  # Observability dict on success
    error_reason: str | None       # Non-None on failure
    artifact_version: str = ARTIFACT_VERSION


def build_user_report_observability(
    *,
    store: Any,
    repo_root: Path,
    error_task_id: str,
) -> ObservabilityRunResult:
    """Run the observability pass for one user-reported error task.

    Idempotent in the loose sense: re-running overwrites the previous
    BuildObservability section + observability_json + status. Callers that
    want strict idempotency should check `status` first.
    """
    error = _load_error_task(store, error_task_id)
    if error is None:
        reason = f"error_task_not_found: {error_task_id}"
        logger.warning(reason)
        return ObservabilityRunResult(
            error_task_id=error_task_id, status="open", output=None, error_reason=reason
        )

    if (error.get("source_kind") or "") != "user_report":
        # Defensive: this analyzer is only sensible for user-reported rows.
        reason = f"unsupported_source_kind: {error.get('source_kind')!r}"
        return ObservabilityRunResult(
            error_task_id=error_task_id, status="open", output=None, error_reason=reason
        )

    prompt_payload = _build_prompt_payload(error=error, repo_root=repo_root)
    outcome = _call_llm(repo_root=repo_root, prompt_payload=prompt_payload)

    if isinstance(outcome, str):
        # LLM failure path: persist the reason under ObservabilityError in
        # the per-error context.json AND in error_tasks.observability_error
        # so the dashboard can render an honest "analysis failed: <reason>"
        # without parsing a file on disk. Status stays 'open' so the caller
        # (or a retry job) can re-trigger.
        _persist_context_section(
            repo_root, error_task_id,
            section="ObservabilityError",
            output={"reason": outcome, "artifactVersion": ARTIFACT_VERSION},
        )
        _update_error_task_row(
            store=store,
            error_task_id=error_task_id,
            observability_error=outcome,
            # status untouched; observability_json untouched (may hold a
            # prior success that we don't want to wipe).
        )
        return ObservabilityRunResult(
            error_task_id=error_task_id, status="open", output=None, error_reason=outcome
        )

    output_dict = outcome.model_dump()
    output_dict["artifactVersion"] = ARTIFACT_VERSION
    _persist_context_section(
        repo_root, error_task_id,
        section="BuildObservability",
        output=output_dict,
    )
    # Success clears any prior failure reason — the dashboard should stop
    # showing the stale failure now that we have real data.
    _update_error_task_row(
        store=store,
        error_task_id=error_task_id,
        observability_output=output_dict,
        observability_error=None,
        new_status="observed",
    )
    return ObservabilityRunResult(
        error_task_id=error_task_id, status="observed", output=output_dict, error_reason=None
    )
