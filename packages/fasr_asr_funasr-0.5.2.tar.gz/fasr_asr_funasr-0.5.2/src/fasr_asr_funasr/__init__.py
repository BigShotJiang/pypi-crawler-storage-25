from fasr_asr_funasr.funasr import FunASRNano

__all__ = ["FunASRNano"]
