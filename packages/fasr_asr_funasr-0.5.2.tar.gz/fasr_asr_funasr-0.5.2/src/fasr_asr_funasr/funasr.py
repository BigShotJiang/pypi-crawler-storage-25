from __future__ import annotations

from pathlib import Path
from typing import Any, List

from funasr import AutoModel
import numpy as np
from pydantic import ConfigDict, Field
import torch
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioSpan
from fasr.model import ASRModel


def _result_to_text(item: Any) -> str:
    if isinstance(item, str):
        return item.strip()
    if isinstance(item, dict):
        text = item.get("text")
        return "" if text is None else str(text).strip()
    text_attr = getattr(item, "text", None)
    if text_attr is not None:
        return str(text_attr).strip()
    return str(item).strip()


class FunASRNano(ASRModel):
    """Fun-ASR-Nano wrapper (no timestamps)."""

    checkpoint: str = "FunAudioLLM/Fun-ASR-Nano-2512"
    endpoint: str = "modelscope"

    fun_model: AutoModel | None = Field(
        default=None,
        exclude=True,
        description="Underlying funasr AutoModel handle populated by `load_checkpoint`.",
    )
    language: str = Field(
        default="中文",
        description="Recognition language label forwarded to the underlying model.",
    )
    itn: bool = Field(
        default=True,
        description="Whether to run inverse text normalization (digits / dates / etc.).",
    )
    batch_size: int = Field(
        default=1, ge=1, description="Generation batch size used by the backend."
    )
    device: str = Field(
        default="cuda:0",
        description="Execution device string passed to `funasr.AutoModel`.",
    )
    trust_remote_code: bool = Field(
        default=True,
        description="Whether to allow loading custom model code from the checkpoint directory.",
    )

    model_config = ConfigDict(arbitrary_types_allowed=True, validate_assignment=True)

    def transcribe(
        self,
        batch: List[AudioSpan],
        **kwargs,
    ) -> List[AudioSpan]:
        if self.fun_model is None:
            raise RuntimeError(
                "Model is not initialized, call load_checkpoint() first."
            )
        if not batch:
            return batch
        hotwords = kwargs.get("hotwords", None)
        language = kwargs.get("language", self.language)
        itn = kwargs.get("itn", self.itn)
        batch_size = int(kwargs.get("batch_size", self.batch_size))

        inputs: list[tuple[np.ndarray, int]] = []
        for span in batch:
            wf = span.waveform
            data = wf.data
            if isinstance(data, torch.Tensor):
                wav = data.detach().cpu().float().numpy()
            else:
                wav = np.asarray(data)
            wav = wav.squeeze()
            inputs.append((wav, int(wf.sample_rate)))

        results = self.fun_model.generate(
            input=inputs,
            cache={},
            batch_size=batch_size,
            hotwords=hotwords,
            language=language,
            itn=itn,
        )
        # Fun-ASR-Nano returns whole-utterance text without token-level timing.
        for span, item in zip(batch, results):
            span.raw_text = _result_to_text(item)
        return batch

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the Fun-ASR model from a local checkpoint directory.

        Falls back to ``self.checkpoint`` (auto-download) when ``checkpoint_dir``
        is ``None``. Runtime knobs (``device``, ``trust_remote_code``) come from
        the corresponding instance fields.
        """

        if checkpoint_dir is None:
            if self.checkpoint is None:
                raise ValueError(
                    "Either `checkpoint_dir` or `self.checkpoint` must be set."
                )
            self.download_checkpoint()
            checkpoint_dir = self.checkpoint_dir

        checkpoint_dir = Path(checkpoint_dir)
        if not checkpoint_dir.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_dir}")

        self.fun_model = AutoModel(
            model=str(checkpoint_dir),
            trust_remote_code=self.trust_remote_code,
            device=self.device,
        )
        return self

    def get_config(self) -> Config:
        return Config(
            data={
                "asr_model": {
                    "@asr_models": "fun_asr_nano",
                    "checkpoint": self.checkpoint,
                    "endpoint": self.endpoint,
                    "device": self.device,
                    "trust_remote_code": self.trust_remote_code,
                    "language": self.language,
                    "itn": self.itn,
                    "batch_size": self.batch_size,
                }
            }
        )


@registry.asr_models.register("fun_asr_nano")
def fun_asr_nano_entrypoint(
    language: str = "中文",
    itn: bool = True,
    batch_size: int = 1,
    device: str = "cuda:0",
    trust_remote_code: bool = True,
    **kwargs,
) -> FunASRNano:
    return FunASRNano(
        language=language,
        itn=itn,
        batch_size=batch_size,
        device=device,
        trust_remote_code=trust_remote_code,
        **kwargs,
    )
