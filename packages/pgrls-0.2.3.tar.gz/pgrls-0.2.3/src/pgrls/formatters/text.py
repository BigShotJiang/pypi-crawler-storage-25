"""Human-readable text output."""
from __future__ import annotations

from collections import Counter

from pgrls.violations import ALL_SEVERITIES, Severity, Violation

_SEVERITY_LABEL: dict[Severity, str] = {
    "error": "ERROR",
    "warning": "WARN ",
    "info": "INFO ",
}


def format_text(violations: list[Violation]) -> str:
    if not violations:
        return "pgrls: no issues found.\n"

    lines: list[str] = []
    for v in violations:
        # Sentinel matches the SARIF formatter's
        # `(schema-wide)` for cross-format consistency. Real
        # qualified names never contain parentheses, so the
        # placeholder is unambiguous.
        loc = v.location or "(schema-wide)"
        lines.append(
            f"  {_SEVERITY_LABEL[v.severity]}  {v.rule_id}  {loc}\n"
            f"         {v.message}"
        )

    counts: Counter[Severity] = Counter(v.severity for v in violations)
    parts: list[str] = []
    for sev in ALL_SEVERITIES:
        n = counts.get(sev, 0)
        if n:
            parts.append(f"{n} {sev}{'s' if n != 1 else ''}")
    summary = ", ".join(parts) or "0 issues"

    body = "\n\n".join(lines)
    return f"{body}\n\npgrls: {summary}.\n"
