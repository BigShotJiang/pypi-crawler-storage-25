"""CLI flag definitions for the filter engine.

This module is intentionally thin — the filter engine reads flags directly
from ``sys.argv`` and environment variables (see :mod:`verbosity`).  No
extra typer integration is required because the existing CLI framework
does not support arbitrary third-party flags and the filter engine needs
to be available even when plugins are loaded late in startup.
"""


# The canonical flags recognised by the filter engine:
#   -u, --ultra-compact   -> VerbosityLevel.ULTRA_COMPACT
#   -v                   -> VerbosityLevel.VERBOSE
#   -vv                  -> VerbosityLevel.VERY_VERBOSE
#   -vvv                 -> VerbosityLevel.RAW
#
# These are parsed at import time by :func:`verbosity.get_verbosity`.
