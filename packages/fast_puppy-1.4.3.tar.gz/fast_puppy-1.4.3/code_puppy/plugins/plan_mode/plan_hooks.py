"""Plan mode enforcement hook.

Registers a ``pre_tool_call`` callback that blocks destructive tools
when the agent is in :attr:`PlanModeState.PLAN`.
"""

import logging
from typing import Any

from code_puppy.plugins.plan_mode.plan_mode_tools import PlanModeState, get_current_mode

logger = logging.getLogger(__name__)

# Tools that are allowed during plan mode (research / read-only / meta)
_ALLOWED_TOOLS: set[str] = {
    "read_file",
    "list_files",
    "grep",
    "ask_user_question",
    "list_or_search_skills",
    "enter_plan_mode",
    "exit_plan_mode",
    "get_plan_mode",
}

# Tools that are explicitly blocked during plan mode
_BLOCKED_TOOLS: set[str] = {
    "create_file",
    "write_file",
    "replace_in_file",
    "delete_file",
    "delete_snippet",
    "agent_run_shell_command",
    "run_shell_command",
}


async def plan_mode_pre_tool_call_hook(
    tool_name: str, tool_args: dict, context: Any = None
) -> dict[str, Any | None]:
    """Block destructive tools when plan mode is active.

    Returns:
        ``{"blocked": True, "error_message": "..."}`` if the tool is
        blocked in plan mode, otherwise ``None``.
    """
    if get_current_mode() != PlanModeState.PLAN:
        return None

    if tool_name in _ALLOWED_TOOLS:
        return None

    if tool_name in _BLOCKED_TOOLS:
        logger.info("Blocked tool '%s' during plan mode", tool_name)
        return {
            "blocked": True,
            "error_message": (
                "🚫 Plan mode is active. This tool is blocked during planning. "
                "Use exit_plan_mode to return to normal mode."
            ),
        }

    # Unknown tools: allow by default (conservative — better to let new
    # research tools work than to accidentally block something harmless).
    return None
