"""Sample eval: memory fidelity — assert that important info triggers save."""

from code_puppy.evals.eval_helpers import assert_tool_called
from code_puppy.evals.eval_runner import EvalResult, run_eval


def eval_memory_fidelity() -> EvalResult:
    return run_eval(
        name="memory_fidelity_save",
        prompt="Save this important fact: the project uses Python 3.12",
        setup_files=None,
        assert_fn=lambda rig: assert_tool_called(rig, "save_memory"),
    )
