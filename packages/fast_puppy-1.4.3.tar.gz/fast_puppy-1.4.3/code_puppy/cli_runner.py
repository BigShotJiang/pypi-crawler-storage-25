"""CLI runner for Code Puppy.

Contains the main application logic, interactive mode, and entry point.
"""

# Apply pydantic-ai patches BEFORE any pydantic-ai imports
from code_puppy.pydantic_patches import apply_all_patches

apply_all_patches()

import argparse
import asyncio
import os
import sys
import traceback
from pathlib import Path

from rich.console import Console

from code_puppy import __version__, callbacks, plugins
from code_puppy.agents import get_current_agent
from code_puppy.command_line.attachments import parse_prompt_attachments
from code_puppy.command_line.clipboard import get_clipboard_manager
from code_puppy.config import (
    AUTOSAVE_DIR,
    COMMAND_HISTORY_FILE,
    ensure_config_exists,
    finalize_autosave_session,
    initialize_command_history_file,
    save_command_to_history,
)
from code_puppy.http_utils import find_available_port
from code_puppy.keymap import (
    KeymapError,
    get_cancel_agent_display_name,
    validate_cancel_agent_key,
)
from code_puppy.messaging import (
    emit_error,
    emit_info,
    emit_success,
    emit_system_message,
    emit_warning,
)
from code_puppy.terminal_utils import (
    print_truecolor_warning,
    reset_unix_terminal,
    reset_windows_terminal_ansi,
    reset_windows_terminal_full,
)
from code_puppy.version_checker import default_version_mismatch_behavior

plugins.load_plugin_callbacks()


def _resume_session_from_path(raw_path: str, *, allow_legacy: bool = False) -> None:
    """Restore agent message history from a saved session file.

    Accepts any path (autosaves, contexts, somewhere weird on disk). We don't
    care where it lives — we just decompose into (parent_dir, stem) and reuse
    ``session_storage.load_session`` so we stay DRY.
    """
    from code_puppy.agents.agent_manager import get_current_agent
    from code_puppy.session_storage import load_session

    session_path = Path(raw_path).expanduser().resolve()

    if not session_path.exists():
        emit_error(f"--resume: session file not found: {session_path}")
        sys.exit(1)

    if session_path.suffix == ".json":
        pass  # preferred format
    elif session_path.suffix == ".pkl":
        if not allow_legacy:
            emit_error(
                f"--resume: legacy pickle sessions are blocked by default. "
                f"Use --import-legacy-pickle-session if you "
                f"really need to load {session_path}"
            )
            sys.exit(1)
        emit_warning(
            "DANGER: loading legacy pickle session — this can execute arbitrary code!"
        )
    else:
        emit_error(
            f"--resume: expected a .json session file, "
            f"got '{session_path.suffix}': {session_path}"
        )
        sys.exit(1)

    try:
        history = load_session(
            session_path.stem, session_path.parent, allow_legacy=allow_legacy
        )
    except Exception as exc:
        emit_error(f"--resume: failed to load session: {exc}")
        sys.exit(1)

    try:
        agent = get_current_agent()
        agent.set_message_history(history)
    except Exception as exc:
        emit_error(f"--resume: failed to attach history to agent: {exc}")
        sys.exit(1)

    # Rotate autosave id so we don't clobber the original file we just resumed.
    try:
        from code_puppy.config import rotate_autosave_id

        rotate_autosave_id()
    except Exception:
        pass  # autosave rotation is best-effort

    total_tokens = sum(agent.estimate_tokens_for_message(m) for m in history)
    emit_success(
        f"✅ Resumed session: {len(history)} messages ({total_tokens} tokens)\n"
        f"📁 From: {session_path}"
    )


async def main():
    """Main async entry point for Code Puppy CLI."""
    parser = argparse.ArgumentParser(description="Code Puppy - A code generation agent")
    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version=f"{__version__}",
        help="Show version and exit",
    )
    parser.add_argument(
        "--interactive",
        "-i",
        action="store_true",
        help="Run in interactive mode",
    )
    parser.add_argument(
        "--prompt",
        "-p",
        type=str,
        help="Execute a single prompt and exit (no interactive mode)",
    )
    parser.add_argument(
        "--agent",
        "-a",
        type=str,
        help="Specify which agent to use (e.g., --agent code-puppy)",
    )
    parser.add_argument(
        "--model",
        "-m",
        type=str,
        help="Specify which model to use (e.g., --model gpt-5)",
    )
    parser.add_argument(
        "--resume",
        "-r",
        type=str,
        metavar="PATH",
        help=(
            "Resume a saved session from a .json file "
            "(e.g. ~/.code_puppy/contexts/foo.json)"
        ),
    )
    parser.add_argument(
        "--import-legacy-pickle-session",
        action="store_true",
        help=(
            "DANGER: allow loading a legacy .pkl session file "
            "(pickle can execute arbitrary code)"
        ),
    )
    parser.add_argument(
        "command", nargs="*", help="Run a single command (deprecated, use -p instead)"
    )
    args = parser.parse_args()

    from code_puppy.messaging import (
        RichConsoleRenderer,
        SynchronousInteractiveRenderer,
        get_global_queue,
        get_message_bus,
    )

    # Create a shared console for both renderers
    display_console = Console()

    # Legacy renderer for backward compatibility (emits via get_global_queue)
    message_queue = get_global_queue()
    message_renderer = SynchronousInteractiveRenderer(message_queue, display_console)
    message_renderer.start()

    # New MessageBus renderer for structured messages (tools emit here)
    message_bus = get_message_bus()
    bus_renderer = RichConsoleRenderer(message_bus, display_console)
    bus_renderer.start()

    initialize_command_history_file()

    # Show the awesome Code Puppy logo when entering interactive mode
    # This happens when: no -p flag (prompt-only mode) is used
    # The logo should appear for both `code-puppy` and `code-puppy -i`
    if not args.prompt:
        try:
            import pyfiglet

            intro_lines = pyfiglet.figlet_format(
                "FAST PUPPY", font="ansi_shadow"
            ).split("\n")

            # Simple blue to green gradient (top to bottom)
            gradient_colors = ["bright_blue", "bright_cyan", "bright_green"]
            display_console.print("\n")

            lines = []
            # Apply gradient line by line
            for line_num, line in enumerate(intro_lines):
                if line.strip():
                    # Use line position to determine color
                    # (top blue, middle cyan, bottom green)
                    color_idx = min(line_num // 2, len(gradient_colors) - 1)
                    color = gradient_colors[color_idx]
                    lines.append(f"[{color}]{line}[/{color}]")
                else:
                    lines.append("")
            # Print directly to console to avoid
            # the 'dim' style from emit_system_message
            display_console.print("\n".join(lines))
        except ImportError:
            emit_system_message("Loading...")

        # Truecolor warning moved to interactive_mode() so it prints LAST
        # after all the help stuff - max visibility for the ugly red box!

    available_port = await asyncio.to_thread(find_available_port)
    if available_port is None:
        emit_error("No available ports in range 8090-9010!")
        return

    # Early model setting if specified via command line
    # This happens before ensure_config_exists() to ensure config is set up correctly
    early_model = None
    if args.model:
        early_model = args.model.strip()
        from code_puppy.config import set_model_name

        set_model_name(early_model)

    ensure_config_exists()

    # Validate cancel_agent_key configuration early
    try:
        validate_cancel_agent_key()
    except KeymapError as e:
        emit_error(str(e))
        sys.exit(1)

    # Show uvx detection notice if we're on Windows + uvx
    # Also disable Ctrl+C at the console level to prevent terminal bricking
    try:
        from code_puppy.uvx_detection import should_use_alternate_cancel_key

        if should_use_alternate_cancel_key():
            from code_puppy.terminal_utils import (
                disable_windows_ctrl_c,
                set_keep_ctrl_c_disabled,
            )

            # Disable Ctrl+C at the console input level
            # This prevents Ctrl+C from being processed as a signal at all
            disable_windows_ctrl_c()

            # Set flag to keep it disabled (prompt_toolkit may re-enable it)
            set_keep_ctrl_c_disabled(True)

            # Use print directly - emit_system_message can get cleared by ANSI codes
            print(
                "🔧 Detected uvx launch on Windows - using Ctrl+K for cancellation "
                "(Ctrl+C is disabled to prevent terminal issues)"
            )

            # Also install a SIGINT handler as backup
            import signal

            from code_puppy.terminal_utils import reset_windows_terminal_full

            def _uvx_protective_sigint_handler(_sig, _frame):
                """Protective SIGINT handler for Windows+uvx."""
                reset_windows_terminal_full()
                # Re-disable Ctrl+C in case something re-enabled it
                disable_windows_ctrl_c()

            signal.signal(signal.SIGINT, _uvx_protective_sigint_handler)
    except ImportError:
        pass  # uvx_detection module not available, ignore

    # Load API keys from puppy.cfg into environment variables
    from code_puppy.config import load_api_keys_to_environment

    load_api_keys_to_environment()

    # Handle model validation from command line
    # (validation happens here, setting was earlier)
    if args.model:
        from code_puppy.config import _validate_model_exists

        model_name = args.model.strip()
        try:
            # Validate that the model exists in models.json
            if not _validate_model_exists(model_name):
                from code_puppy.model_factory import ModelFactory

                models_config = ModelFactory.load_config()
                available_models = list(models_config.keys()) if models_config else []

                emit_error(f"Model '{model_name}' not found")
                emit_system_message(f"Available models: {', '.join(available_models)}")
                sys.exit(1)

            # Model is valid, show confirmation (already set earlier)
            emit_system_message(f"🎯 Using model: {model_name}")
        except Exception as e:
            emit_error(f"Error validating model: {str(e)}")
            sys.exit(1)

    # Handle agent selection from command line
    if args.agent:
        from code_puppy.agents.agent_manager import (
            get_available_agents,
            set_current_agent,
        )

        agent_name = args.agent.lower()
        try:
            # First check if the agent exists by getting available agents
            available_agents = get_available_agents()
            if agent_name not in available_agents:
                emit_error(f"Agent '{agent_name}' not found")
                emit_system_message(
                    f"Available agents: {', '.join(available_agents.keys())}"
                )
                sys.exit(1)

            # Agent exists, set it
            set_current_agent(agent_name)
            emit_system_message(f"🤖 Using agent: {agent_name}")
        except Exception as e:
            emit_error(f"Error setting agent: {str(e)}")
            sys.exit(1)

    current_version = __version__

    no_version_update = os.getenv("NO_VERSION_UPDATE", "").lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    if no_version_update:
        version_msg = f"Current version: {current_version}"
        update_disabled_msg = (
            "Update phase disabled because NO_VERSION_UPDATE is set to 1 or true"
        )
        emit_system_message(version_msg)
        emit_system_message(update_disabled_msg)
    else:
        if len(callbacks.get_callbacks("version_check")):
            await callbacks.on_version_check(current_version)
        else:
            default_version_mismatch_behavior(current_version)

    await callbacks.on_startup()

    if args.resume:
        _resume_session_from_path(
            args.resume, allow_legacy=args.import_legacy_pickle_session
        )

    global shutdown_flag
    shutdown_flag = False
    try:
        initial_command = None
        prompt_only_mode = False

        if args.prompt:
            initial_command = args.prompt
            prompt_only_mode = True
        elif args.command:
            initial_command = " ".join(args.command)
            prompt_only_mode = False

        if prompt_only_mode:
            await execute_single_prompt(initial_command, message_renderer)
        else:
            # Default to interactive mode (no args = same as -i)
            await interactive_mode(message_renderer, initial_command=initial_command)
    finally:
        if message_renderer:
            message_renderer.stop()
        if bus_renderer:
            bus_renderer.stop()
        await callbacks.on_shutdown()


def _show_startup_info(display_console) -> None:
    """Display startup messages and terminal capability warnings."""
    emit_system_message(
        "Type '/exit', '/quit', or press Ctrl+D to exit the interactive mode."
    )
    emit_system_message("Type 'clear' to reset the conversation history.")
    emit_system_message("Type /help to view all commands")
    emit_system_message(
        "Type @ for path completion, or /model to pick a model. "
        "Toggle multiline with Alt+M or F2; newline: Ctrl+J."
    )
    emit_system_message("Paste images: Ctrl+V (even on Mac!), F3, or /paste command.")
    import platform

    if platform.system() == "Darwin":
        emit_system_message(
            "💡 macOS tip: Use Ctrl+V (not Cmd+V) to paste images in terminal."
        )
    cancel_key = get_cancel_agent_display_name()
    emit_system_message(
        f"Press {cancel_key} during processing to cancel the current task "
        f"or inference. Use Ctrl+X to interrupt running shell commands."
    )
    emit_system_message(
        "Use /autosave_load to manually load a previous autosave session."
    )
    emit_system_message(
        "Use /diff to configure diff highlighting colors for file changes."
    )
    emit_system_message("To re-run the tutorial, use /tutorial.")
    emit_system_message(
        "!<command> to run shell commands directly (e.g., !git status)",
    )
    # Print truecolor warning LAST so it's the most visible thing on startup
    # Big ugly red box should be impossible to miss! 🔴
    print_truecolor_warning(display_console)


async def _handle_initial_command(initial_command: str, display_console) -> None:
    """Process an initial command passed on the CLI before entering the main loop."""
    from code_puppy.command_line.shell_passthrough import (
        execute_shell_passthrough,
        is_shell_passthrough,
    )

    if is_shell_passthrough(initial_command):
        execute_shell_passthrough(initial_command)
        return

    from code_puppy.agents import get_current_agent

    agent = get_current_agent()
    emit_info(f"Processing initial command: {initial_command}")

    try:
        # Check if any tool is waiting for user input before showing spinner
        try:
            from code_puppy.tools.command_runner import is_awaiting_user_input

            awaiting_input = is_awaiting_user_input()
        except ImportError:
            awaiting_input = False

        # Run with or without spinner based on whether we're awaiting input
        response, agent_task = await run_prompt_with_attachments(
            agent,
            initial_command,
            spinner_console=display_console,
            use_spinner=not awaiting_input,
        )
        if response is not None:
            agent_response = response.output

            # Update the agent's message history with the complete conversation
            # including the final assistant response
            if hasattr(response, "all_messages"):
                agent.set_message_history(list(response.all_messages()))

            # Emit structured message for proper markdown rendering
            from code_puppy.messaging import get_message_bus
            from code_puppy.messaging.messages import AgentResponseMessage

            response_msg = AgentResponseMessage(
                content=agent_response,
                is_markdown=True,
            )
            get_message_bus().emit(response_msg)

            emit_success("Continuing in Interactive Mode")
            emit_system_message(
                "Your command and response are preserved in the conversation history."
            )

    except Exception as e:
        emit_error(f"Error processing initial command: {str(e)}")


def _ensure_prompt_toolkit() -> None:
    """Ensure prompt_toolkit is installed, installing it if missing."""
    try:
        from code_puppy.command_line.prompt_toolkit_completion import (
            get_input_with_combined_completion,  # noqa: F401
            get_prompt_with_active_model,  # noqa: F401
        )
    except ImportError:
        emit_warning("Warning: prompt_toolkit not installed. Installing now...")
        try:
            import subprocess

            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "--quiet", "prompt_toolkit"]
            )

            emit_success("Successfully installed prompt_toolkit")
        except Exception as e:
            emit_error(f"Error installing prompt_toolkit: {e}")
            emit_warning("Falling back to basic input without tab completion")


def _maybe_run_onboarding() -> None:
    """Run the onboarding tutorial on first startup if needed."""
    try:
        from code_puppy.command_line.onboarding_wizard import should_show_onboarding

        if should_show_onboarding():
            import concurrent.futures

            from code_puppy.command_line.onboarding_wizard import run_onboarding_wizard
            from code_puppy.config import set_model_name

            # FREE-THREADED: ThreadPoolExecutor works with free-threaded Python 3.14.
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(lambda: asyncio.run(run_onboarding_wizard()))
                result = future.result(timeout=300)

            if result == "chatgpt":
                emit_info("🔐 Starting ChatGPT OAuth flow...")
                from code_puppy.plugins.chatgpt_oauth.oauth_flow import run_oauth_flow

                run_oauth_flow()
                set_model_name("chatgpt-gpt-5.4")
            elif result == "claude":
                emit_info("🔐 Starting Claude Code OAuth flow...")
                from code_puppy.plugins.claude_code_oauth.register_callbacks import (
                    _perform_authentication,
                )

                _perform_authentication()
                set_model_name("claude-code-claude-opus-4-7")
            elif result == "completed":
                emit_info("🎉 Tutorial complete! Happy coding!")
            elif result == "skipped":
                emit_info("⏭️ Tutorial skipped. Run /tutorial anytime!")
    except Exception as e:
        emit_warning(f"Tutorial auto-start failed: {e}")


async def _read_user_input(message_renderer, display_console) -> str:
    """Read user input via prompt_toolkit or fallback to basic input."""
    try:
        from code_puppy.command_line.prompt_toolkit_completion import (
            get_input_with_combined_completion,
            get_prompt_with_active_model,
        )

        reset_windows_terminal_ansi()
        task = await get_input_with_combined_completion(
            get_prompt_with_active_model(), history_file=COMMAND_HISTORY_FILE
        )
        try:
            from code_puppy.terminal_utils import ensure_ctrl_c_disabled

            ensure_ctrl_c_disabled()
        except ImportError:
            pass
        return task
    except ImportError:
        return input(">>> ")


def _handle_keyboard_interrupt(display_console) -> None:
    """Handle Ctrl+C during input by resetting terminal and stopping wiggum."""
    reset_windows_terminal_full()
    from code_puppy.command_line.wiggum_state import is_wiggum_active, stop_wiggum

    if is_wiggum_active():
        stop_wiggum()
        emit_warning("\n🍩 Wiggum loop stopped!")
    else:
        emit_warning("\nInput cancelled")


async def _cancel_agent_task_if_running(current_agent_task) -> None:
    """Cancel a running agent task and await its completion."""
    if current_agent_task and not current_agent_task.done():
        emit_info("Cancelling running agent task...")
        current_agent_task.cancel()
        try:  # noqa: SIM105
            await current_agent_task
        except asyncio.CancelledError:
            pass


async def _handle_eof(current_agent_task) -> None:
    """Handle Ctrl+D by cancelling any running agent task and printing goodbye."""
    emit_success("\nGoodbye! (Ctrl+D)")
    await _cancel_agent_task_if_running(current_agent_task)


def _is_shell_passthrough_and_execute(task: str) -> bool:
    """If the task is a shell passthrough, execute it and return True."""
    from code_puppy.command_line.shell_passthrough import (
        execute_shell_passthrough,
        is_shell_passthrough,
    )

    if is_shell_passthrough(task):
        execute_shell_passthrough(task)
        return True
    return False


async def _is_exit_command(task: str, current_agent_task) -> bool:
    """Check for exit commands, cancel running tasks, and return True if exiting."""
    if task.strip().lower() in ["exit", "quit"] or task.strip().lower() in [
        "/exit",
        "/quit",
    ]:
        emit_success("Goodbye!")
        await _cancel_agent_task_if_running(current_agent_task)
        return True
    return False


def _is_clear_command(task: str) -> bool:
    """Check for clear commands, rotate session and clear history if matched."""
    if task.strip().lower() in ("clear", "/clear"):
        from code_puppy.command_line.clipboard import get_clipboard_manager

        agent = get_current_agent()
        new_session_id = finalize_autosave_session()
        agent.clear_message_history()
        emit_warning("Conversation history cleared!")
        emit_system_message("The agent will not remember previous interactions.")
        emit_info(f"Auto-save session rotated to: {new_session_id}")
        clipboard_manager = get_clipboard_manager()
        clipboard_count = clipboard_manager.get_pending_count()
        clipboard_manager.clear_pending()
        if clipboard_count > 0:
            emit_info(f"Cleared {clipboard_count} pending clipboard image(s)")
        return True
    return False


async def _handle_slash_command(cleaned: str):
    """Route a slash command and return a sentinel or the prompt to execute."""
    from code_puppy.command_line.command_handler import handle_command

    try:
        command_result = handle_command(cleaned)
    except Exception as e:
        emit_error(f"Command error: {e}")
        return "__CONTINUE__"
    if command_result is True:
        return "__CONTINUE__"
    elif isinstance(command_result, str):
        if command_result == "__AUTOSAVE_LOAD__":
            try:
                use_interactive_picker = sys.stdin.isatty() and sys.stdout.isatty()
                if os.getenv("CODE_PUPPY_NO_TUI") == "1":
                    use_interactive_picker = False
                if use_interactive_picker:
                    from code_puppy.agents.agent_manager import get_current_agent
                    from code_puppy.command_line.autosave_menu import (
                        interactive_autosave_picker,
                    )
                    from code_puppy.config import set_current_autosave_from_session_name
                    from code_puppy.session_storage import (
                        load_session,
                        restore_autosave_interactively,
                    )

                    chosen_session = await interactive_autosave_picker()
                    if not chosen_session:
                        emit_warning("Autosave load cancelled")
                        return "__CONTINUE__"
                    base_dir = Path(AUTOSAVE_DIR)
                    history = load_session(chosen_session, base_dir)
                    agent = get_current_agent()
                    agent.set_message_history(history)
                    set_current_autosave_from_session_name(chosen_session)
                    total_tokens = sum(
                        agent.estimate_tokens_for_message(msg) for msg in history
                    )
                    session_path = base_dir / f"{chosen_session}.json"
                    emit_success(
                        f"✅ Autosave loaded: {len(history)} messages "
                        f"({total_tokens} tokens)\n📁 From: {session_path}"
                    )
                    from code_puppy.command_line.autosave_menu import (
                        display_resumed_history,
                    )

                    display_resumed_history(history)
                else:
                    await restore_autosave_interactively(Path(AUTOSAVE_DIR))
            except Exception as e:
                emit_error(f"Failed to load autosave: {e}")
            return "__CONTINUE__"
        else:
            return command_result
    elif command_result is False:
        return None
    return None


async def _run_main_input_loop(
    message_renderer, display_console, current_agent, current_agent_task
):
    """Gather and process user input until a non-command task is ready."""
    while True:
        user_prompt = current_agent.get_user_prompt() or "Enter your coding task:"
        emit_info(f"{user_prompt}\n")

        try:
            task = await _read_user_input(message_renderer, display_console)
        except KeyboardInterrupt, asyncio.CancelledError:
            _handle_keyboard_interrupt(display_console)
            continue
        except EOFError:
            await _handle_eof(current_agent_task)
            return None

        if _is_shell_passthrough_and_execute(task):
            continue
        if await _is_exit_command(task, current_agent_task):
            return None
        if _is_clear_command(task):
            continue

        processed = parse_prompt_attachments(task)
        cleaned = (processed.prompt or "").strip()
        if cleaned.startswith("/"):
            action = await _handle_slash_command(cleaned)
            if action == "__CONTINUE__":
                continue
            if isinstance(action, str):
                task = action

        if task.strip():
            save_command_to_history(task)
            return task


def _render_response(result, agent, display_console) -> None:
    """Render an agent response, update history, and flush the console."""
    from code_puppy.messaging import get_message_bus
    from code_puppy.messaging.messages import AgentResponseMessage

    agent_response = result.output
    response_msg = AgentResponseMessage(
        content=agent_response,
        is_markdown=True,
    )
    get_message_bus().emit(response_msg)
    if hasattr(result, "all_messages"):
        agent.set_message_history(list(result.all_messages()))
    if hasattr(display_console.file, "flush"):
        display_console.file.flush()


def _handle_agent_cancellation(display_console) -> None:
    """Reset terminal state after an agent task is cancelled."""
    reset_windows_terminal_ansi()
    try:
        from code_puppy.terminal_utils import ensure_ctrl_c_disabled

        ensure_ctrl_c_disabled()
    except ImportError:
        pass
    from code_puppy.command_line.wiggum_state import is_wiggum_active, stop_wiggum

    if is_wiggum_active():
        stop_wiggum()
        emit_warning("🍩 Wiggum loop stopped due to cancellation")


async def _wiggum_loop(
    current_agent, message_renderer, display_console, current_agent_task
):
    """Run the wiggum re-loop until it completes or is cancelled."""
    from code_puppy.command_line.wiggum_state import (
        get_wiggum_prompt,
        increment_wiggum_count,
        is_wiggum_active,
        stop_wiggum,
    )
    from code_puppy.config import auto_save_session_if_enabled

    while is_wiggum_active():
        wiggum_prompt = get_wiggum_prompt()
        if not wiggum_prompt:
            stop_wiggum()
            break

        loop_num = increment_wiggum_count()
        emit_warning(f"\n🍩 WIGGUM RELOOPING! (Loop #{loop_num})")
        emit_system_message(f"Re-running prompt: {wiggum_prompt}")

        new_session_id = finalize_autosave_session()
        current_agent.clear_message_history()
        emit_system_message(f"Context cleared. Session rotated to: {new_session_id}")

        await asyncio.sleep(0.5)

        try:
            result, current_agent_task = await run_prompt_with_attachments(
                current_agent,
                wiggum_prompt,
                spinner_console=message_renderer.console,
            )

            if result is None:
                emit_warning("Wiggum loop cancelled by user")
                stop_wiggum()
                break

            _render_response(result, current_agent, display_console)
            if hasattr(display_console.file, "flush"):
                display_console.file.flush()
            await asyncio.sleep(0.1)

            auto_save_session_if_enabled()

        except KeyboardInterrupt:
            emit_warning("\n🍩 Wiggum loop interrupted by Ctrl+C")
            stop_wiggum()
            break
        except Exception as e:
            emit_error(f"Wiggum loop error: {e}")
            stop_wiggum()
            break

    return current_agent_task


async def interactive_mode(message_renderer, initial_command: str = None) -> None:
    """Run the agent in interactive mode."""

    display_console = message_renderer.console

    _show_startup_info(display_console)

    if initial_command:
        await _handle_initial_command(initial_command, display_console)

    _ensure_prompt_toolkit()

    # Autosave loading is now manual - use /autosave_load command

    _maybe_run_onboarding()

    # Track the current agent task for cancellation on quit
    current_agent_task = None

    while True:
        from code_puppy.agents.agent_manager import get_current_agent

        current_agent = get_current_agent()
        task = await _run_main_input_loop(
            message_renderer, display_console, current_agent, current_agent_task
        )
        if task is None:
            break

        try:
            result, current_agent_task = await run_prompt_with_attachments(
                current_agent,
                task,
                spinner_console=message_renderer.console,
            )
            if result is None:
                _handle_agent_cancellation(display_console)
                continue
            _render_response(result, current_agent, display_console)
            await asyncio.sleep(0.1)
        except Exception:
            from code_puppy.messaging.queue_console import get_queue_console

            get_queue_console().print_exception()

        from code_puppy.config import auto_save_session_if_enabled

        auto_save_session_if_enabled()

        current_agent_task = await _wiggum_loop(
            current_agent, message_renderer, display_console, current_agent_task
        )

        # Re-disable Ctrl+C if needed (uvx mode) - must be done after
        # each iteration as various operations may restore console mode
        try:
            from code_puppy.terminal_utils import ensure_ctrl_c_disabled

            ensure_ctrl_c_disabled()
        except ImportError:
            pass


async def run_prompt_with_attachments(
    agent,
    raw_prompt: str,
    *,
    spinner_console=None,
    use_spinner: bool = True,
):
    """Run the agent after parsing CLI attachments for image/document support.

    Returns:
        tuple: (result, task) where result is the agent response
        and task is the asyncio task
    """
    import asyncio
    import re

    processed_prompt = parse_prompt_attachments(raw_prompt)

    for warning in processed_prompt.warnings:
        emit_warning(warning)

    # Get clipboard images and merge with file attachments
    clipboard_manager = get_clipboard_manager()
    clipboard_images = clipboard_manager.get_pending_images()

    # Clear pending clipboard images after retrieval
    clipboard_manager.clear_pending()

    # Build summary of all attachments
    summary_parts = []
    if processed_prompt.attachments:
        summary_parts.append(f"files: {len(processed_prompt.attachments)}")
    if clipboard_images:
        summary_parts.append(f"clipboard images: {len(clipboard_images)}")
    if processed_prompt.link_attachments:
        summary_parts.append(f"urls: {len(processed_prompt.link_attachments)}")
    if summary_parts:
        emit_system_message("Attachments detected -> " + ", ".join(summary_parts))

    # Clean up clipboard placeholders from the prompt text
    cleaned_prompt = processed_prompt.prompt
    if clipboard_images and cleaned_prompt:
        cleaned_prompt = re.sub(
            r"\[📋 clipboard image \d+\]\s*", "", cleaned_prompt
        ).strip()

    if not cleaned_prompt:
        emit_warning(
            "Prompt is empty after removing attachments; add instructions and retry."
        )
        return None, None

    # Combine file attachments with clipboard images
    attachments = [attachment.content for attachment in processed_prompt.attachments]
    attachments.extend(clipboard_images)  # Add clipboard images

    link_attachments = [link.url_part for link in processed_prompt.link_attachments]

    # IMPORTANT: Set the shared console for streaming output so it
    # uses the same console as the spinner. This prevents Live display conflicts
    # that cause line duplication during markdown streaming.
    from code_puppy.agents.event_stream_handler import set_streaming_console

    set_streaming_console(spinner_console)

    # Create the agent task first so we can track and cancel it
    agent_task = asyncio.create_task(
        agent.run(
            cleaned_prompt,  # Use cleaned prompt (clipboard placeholders removed)
            attachments=attachments,
            link_attachments=link_attachments,
        )
    )

    if use_spinner and spinner_console is not None:
        from code_puppy.messaging.spinner import ConsoleSpinner

        with ConsoleSpinner(console=spinner_console):
            try:
                result = await agent_task
                return result, agent_task
            except asyncio.CancelledError:
                emit_info("Agent task cancelled")
                return None, agent_task
    else:
        try:
            result = await agent_task
            return result, agent_task
        except asyncio.CancelledError:
            emit_info("Agent task cancelled")
            return None, agent_task


async def execute_single_prompt(prompt: str, message_renderer) -> None:
    """Execute a single prompt and exit (for -p flag)."""
    # Shell pass-through: !<cmd> bypasses the agent even in -p mode
    from code_puppy.command_line.shell_passthrough import (
        execute_shell_passthrough,
        is_shell_passthrough,
    )

    if is_shell_passthrough(prompt):
        execute_shell_passthrough(prompt)
        return

    emit_info(f"Executing prompt: {prompt}")

    try:
        # Get agent through runtime manager and use helper for attachments
        agent = get_current_agent()
        result, _agent_task = await run_prompt_with_attachments(
            agent,
            prompt,
            spinner_console=message_renderer.console,
        )
        if result is None:
            return

        agent_response = result.output

        # Emit structured message for proper markdown rendering
        from code_puppy.messaging import get_message_bus
        from code_puppy.messaging.messages import AgentResponseMessage

        response_msg = AgentResponseMessage(
            content=agent_response,
            is_markdown=True,
        )
        get_message_bus().emit(response_msg)

    except asyncio.CancelledError:
        emit_warning("Execution cancelled by user")
    except Exception as e:
        emit_error(f"Error executing prompt: {str(e)}")


def main_entry():
    """Entry point for the installed CLI tool."""
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        # Note: Using sys.stderr for crash output -
        # messaging system may not be available
        sys.stderr.write(traceback.format_exc())
        return 0
    finally:
        # Reset terminal on Unix-like systems (not Windows)
        reset_unix_terminal()
