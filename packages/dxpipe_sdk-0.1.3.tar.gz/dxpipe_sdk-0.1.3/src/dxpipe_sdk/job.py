from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Iterator
from urllib.parse import urlencode, urlparse, urlunparse

from websocket import WebSocketTimeoutException, create_connection

from .exceptions import ValidationError
from .result import ResultStream, normalize_messages
from .types import JobStatus

if TYPE_CHECKING:
    from .client import DxPipeClient


def _unwrap(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


class Job:
    TERMINAL_STATES = {"success", "fault", "stopped"}

    def __init__(
        self,
        *,
        client: "DxPipeClient",
        job_id: str,
        status: JobStatus = "pending",
        progress: float = 0.0,
        msg_num: int | None = None,
        finished_at: str | None = None,
        raw: dict[str, Any] | None = None,
    ) -> None:
        self.client = client
        self.id = job_id
        self.status = status
        self.progress = float(progress or 0.0)
        self.msg_num = msg_num
        self.finished_at = finished_at
        self.raw = raw or {}
        self.result_stream = ResultStream()

    @classmethod
    def from_payload(cls, client: "DxPipeClient", payload: dict[str, Any]) -> "Job":
        return cls(
            client=client,
            job_id=str(payload.get("id", "")),
            status=payload.get("status", "pending"),
            progress=float(payload.get("progress", 0.0) or 0.0),
            msg_num=payload.get("msg_num"),
            finished_at=payload.get("finished_at"),
            raw=payload,
        )

    @classmethod
    def get(cls, client: "DxPipeClient", job_id: str) -> "Job":
        payload = _unwrap(client.http.get(f"/api/jobs/{job_id}/"))
        if not isinstance(payload, dict):
            raise TypeError("Job payload must be a JSON object.")
        return cls.from_payload(client, payload)

    @classmethod
    def list(cls, client: "DxPipeClient", **params: Any) -> list["Job"]:
        payload = _unwrap(client.http.get("/api/jobs/", params=params or None))
        items = payload if isinstance(payload, list) else payload.get("results", []) if isinstance(payload, dict) else []
        return [cls.from_payload(client, item) for item in items if isinstance(item, dict)]

    @property
    def is_terminal(self) -> bool:
        return self.status in self.TERMINAL_STATES

    def refresh(self) -> "Job":
        payload = _unwrap(
            self.client.http.get(
                f"/api/jobs/{self.id}/",
                params={"fields": "id,status,progress,msg_num,finished_at"},
            )
        )
        if isinstance(payload, dict):
            self.status = payload.get("status", self.status)
            self.progress = float(payload.get("progress", self.progress) or 0.0)
            self.msg_num = payload.get("msg_num", self.msg_num)
            self.finished_at = payload.get("finished_at", self.finished_at)
            self.raw.update(payload)
        return self

    @property
    def workspace_type(self) -> str:
        return str(self.raw.get("workspace_type", "lps_online"))

    @property
    def model_id(self) -> str | None:
        value = self.raw.get("model")
        return None if value is None else str(value)

    @property
    def task_id(self) -> str | None:
        value = self.raw.get("task_id")
        return None if value is None else str(value)

    def wait(self, *, timeout: float | None = None, poll_interval: float = 0.5) -> "Job":
        import time

        started = time.monotonic()
        while True:
            self.refresh()
            if self.is_terminal:
                return self
            if timeout is not None and time.monotonic() - started > timeout:
                raise TimeoutError(f"Job {self.id} did not finish within {timeout} seconds.")
            time.sleep(poll_interval)

    def stream_results(
        self,
        *,
        offset: int = 0,
        callback: Any | None = None,
        timeout: float = 5.0,
    ) -> Iterator[dict[str, Any]]:
        ws = create_connection(
            self._websocket_url(offset),
            timeout=timeout,
            header=self._websocket_headers(),
        )
        try:
            while True:
                try:
                    frame = ws.recv()
                except WebSocketTimeoutException:
                    self.refresh()
                    if self.is_terminal:
                        break
                    continue
                if frame is None:
                    break
                for message in normalize_messages(frame):
                    self._apply_status_side_effect(message)
                    normalized = self.result_stream.apply_message(message)
                    if normalized is None:
                        continue
                    if callback is not None:
                        callback(normalized, self.result_stream)
                    yield normalized
        finally:
            ws.close()

    def get_results(self, *, timeout: float = 5.0) -> ResultStream:
        for _ in self.stream_results(timeout=timeout):
            pass
        return self.result_stream

    def pause(self) -> None:
        self._send_control("pause")

    def resume(self) -> None:
        self._send_control("resume")

    def stop(self) -> None:
        self._send_control("stop")

    def send_command(self, component_id: str, cmd_key: str, **params: Any) -> None:
        payload = {
            "type": "JOB_CMD",
            "payload": {
                "cmd": {
                    component_id: [
                        {
                            "cmdKey": cmd_key,
                            "data": params,
                        }
                    ]
                }
            },
        }
        self._send_ws_payload(payload)

    def _send_control(self, command: str) -> None:
        if command not in {"pause", "resume", "stop"}:
            raise ValidationError(f"Unsupported control command: {command}")
        self._send_ws_payload({"type": "JOB_CONTROL", "payload": {"cmd": command}})

    def _send_ws_payload(self, payload: dict[str, Any]) -> None:
        ws = create_connection(
            self._websocket_url(0),
            timeout=self.client.timeout,
            header=self._websocket_headers(),
        )
        try:
            ws.send(json.dumps(payload, ensure_ascii=True))
        finally:
            ws.close()

    def _websocket_headers(self) -> list[str]:
        headers: list[str] = []
        access_token = self.client.auth.access_token if self.client.auth else None
        if access_token:
            headers.append(f"Authorization: Bearer {access_token}")
        return headers

    def _websocket_url(self, offset: int) -> str:
        parsed = urlparse(self.client.base_url)
        scheme = "wss" if parsed.scheme == "https" else "ws"
        query = urlencode({"offset": offset})
        return urlunparse((scheme, parsed.netloc, f"/ws/{self.id}", "", query, ""))

    def _apply_status_side_effect(self, message: dict[str, Any]) -> None:
        if message.get("key") != "__status__":
            return
        data = message.get("data")
        if not isinstance(data, str) or not data.startswith("status:"):
            return
        try:
            text = data.split(":", 1)[1]
            status_text, progress_text = text.split(";", 1)
            self.status = status_text.strip() or self.status
            self.progress = float(progress_text)
        except Exception:
            return
