from __future__ import annotations

from typing import Any
from urllib.parse import urljoin

import requests

from .auth import TokenAuth
from .exceptions import APIError, NotFoundError


class HttpClient:
    def __init__(
        self,
        *,
        base_url: str,
        auth: TokenAuth | None = None,
        timeout: float = 30.0,
        session: requests.Session | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/") + "/"
        self.timeout = timeout
        self.session = session or requests.Session()
        self.auth = auth

    def get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        return self.request("GET", path, params=params)

    def post(self, path: str, *, json: Any | None = None, params: dict[str, Any] | None = None) -> Any:
        return self.request("POST", path, json=json, params=params)

    def put(self, path: str, *, json: Any | None = None, params: dict[str, Any] | None = None) -> Any:
        return self.request("PUT", path, json=json, params=params)

    def patch(self, path: str, *, json: Any | None = None, params: dict[str, Any] | None = None) -> Any:
        return self.request("PATCH", path, json=json, params=params)

    def delete(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        return self.request("DELETE", path, params=params)

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        _retry: bool = True,
    ) -> Any:
        if self.auth:
            self.auth.ensure_login()
        request_headers = dict(headers or {})
        if self.auth:
            request_headers.update(self.auth.authorization_header)
        response = self.session.request(
            method,
            urljoin(self.base_url, path.lstrip("/")),
            params=params,
            json=json,
            headers=request_headers,
            timeout=self.timeout,
        )
        if response.status_code == 401 and self.auth and _retry and self.auth.can_refresh:
            self.auth.refresh()
            return self.request(method, path, params=params, json=json, headers=headers, _retry=False)
        return self._handle_response(response)

    @staticmethod
    def unwrap_data(payload: Any) -> Any:
        if isinstance(payload, dict) and "data" in payload and len(payload) == 1:
            return payload["data"]
        return payload

    def _handle_response(self, response: requests.Response) -> Any:
        if response.status_code == 204:
            return None
        try:
            payload = response.json()
        except ValueError:
            payload = response.text
        if response.status_code >= 400:
            message = self._extract_error_message(payload, response.reason)
            error_cls = NotFoundError if response.status_code == 404 else APIError
            raise error_cls(message, status_code=response.status_code, payload=payload)
        return payload

    @staticmethod
    def _extract_error_message(payload: Any, fallback: str) -> str:
        if isinstance(payload, dict):
            for key in ("detail", "message", "error", "msg"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    return value
        if isinstance(payload, str) and payload.strip():
            return payload
        return fallback or "Request failed."
