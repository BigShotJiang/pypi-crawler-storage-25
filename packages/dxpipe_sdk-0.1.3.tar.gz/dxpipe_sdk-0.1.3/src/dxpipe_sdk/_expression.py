from __future__ import annotations

import re
from types import SimpleNamespace
from typing import Any, Mapping


_NOT_PATTERN = re.compile(r"(?<![=!<>])!(?!=)")


def _to_namespace(value: Any) -> Any:
    if isinstance(value, Mapping):
        return SimpleNamespace(**{key: _to_namespace(item) for key, item in value.items()})
    if isinstance(value, list):
        return [_to_namespace(item) for item in value]
    return value


def _equal_text(left: Any, right: Any) -> bool:
    return str(left) == str(right)


def _transform(expr: str) -> str:
    transformed = expr.strip()
    transformed = transformed.replace("&&", " and ")
    transformed = transformed.replace("||", " or ")
    transformed = re.sub(r"\btrue\b", "True", transformed, flags=re.IGNORECASE)
    transformed = re.sub(r"\bfalse\b", "False", transformed, flags=re.IGNORECASE)
    transformed = re.sub(r"\bnull\b", "None", transformed, flags=re.IGNORECASE)
    transformed = _NOT_PATTERN.sub(" not ", transformed)
    return transformed


def evaluate_condition(expr: str | None, scope: Mapping[str, Any] | None = None) -> bool:
    if expr is None:
        return False
    text = expr.strip()
    if not text:
        return False
    transformed = _transform(text)
    locals_scope = {key: _to_namespace(value) for key, value in (scope or {}).items()}
    try:
        result = eval(
            transformed,
            {"__builtins__": {}, "equalText": _equal_text, "min": min, "max": max, "abs": abs, "len": len},
            locals_scope,
        )
    except Exception:
        return False
    return bool(result)
