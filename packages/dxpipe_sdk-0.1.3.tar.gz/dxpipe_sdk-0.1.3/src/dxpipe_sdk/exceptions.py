from __future__ import annotations

from typing import Any


class DxPipeError(Exception):
    """Base exception for the SDK."""


class AuthError(DxPipeError):
    """Authentication or token refresh failure."""


class ValidationError(DxPipeError):
    """Local model validation failure."""


class APIError(DxPipeError):
    """HTTP API error."""

    def __init__(self, message: str, *, status_code: int | None = None, payload: Any = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


class NotFoundError(APIError):
    """Resource was not found."""
