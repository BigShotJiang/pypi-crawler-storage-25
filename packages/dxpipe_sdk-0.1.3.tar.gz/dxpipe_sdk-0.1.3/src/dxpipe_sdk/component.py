from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Iterable

from ._expression import evaluate_condition
from .exceptions import ValidationError
from .types import NodeData, NodeViewStatus, PortType

if TYPE_CHECKING:
    from .model import Model


def default_view_status(position: tuple[float, float] | None = None) -> NodeViewStatus:
    x, y = position or (0.0, 0.0)
    return {
        "flip": False,
        "angle": 0.0,
        "size": {"width": 120.0, "height": 80.0},
        "position": {"x": float(x), "y": float(y)},
        "zIndex": 0,
    }


def iter_arg_definitions(args_group: Any) -> Iterable[dict[str, Any]]:
    if not isinstance(args_group, list):
        return []
    definitions: list[dict[str, Any]] = []
    for group in args_group:
        if not isinstance(group, dict):
            continue
        for item in group.get("argsDefinition", []) or []:
            if isinstance(item, dict):
                definitions.append(item)
    return definitions


def build_default_params(component_definition: dict[str, Any]) -> dict[str, Any]:
    defaults: dict[str, Any] = {}
    for arg_def in iter_arg_definitions(component_definition.get("argsGroup", [])):
        key = arg_def.get("key")
        if not key:
            continue
        if "defaultValue" in arg_def:
            defaults[key] = arg_def.get("defaultValue")
        elif "default" in arg_def:
            defaults[key] = arg_def.get("default")
        elif arg_def.get("type") == "table":
            defaults[key] = []
        else:
            defaults[key] = ""
    return defaults


@dataclass(slots=True)
class PortRef:
    component: "Component"
    key: str
    name: str
    type: PortType
    condition: str

    @property
    def is_active(self) -> bool:
        return evaluate_condition(self.condition or "true", {**self.component.params, "context": {}})


class Component:
    def __init__(
        self,
        *,
        model: "Model",
        component_id: str,
        class_id: str,
        label: str,
        params: dict[str, Any] | None = None,
        pins_label: dict[str, str] | None = None,
        view_status: NodeViewStatus | None = None,
    ) -> None:
        self.model = model
        self.id = component_id
        self.class_id = class_id
        self.label = label
        self.params = dict(params or {})
        self.pins_label = dict(pins_label or {})
        self.view_status = view_status or default_view_status()

    @property
    def definition(self) -> dict[str, Any]:
        return self.model.client.meta.get_component_definition(self.model.workspace_type, self.class_id)

    @property
    def commands(self) -> Any:
        return self.definition.get("commands", [])

    @property
    def ports(self) -> list[PortRef]:
        ports: list[PortRef] = []
        for port in self.definition.get("portsDefinition", []) or []:
            if not isinstance(port, dict):
                continue
            ports.append(
                PortRef(
                    component=self,
                    key=str(port.get("key", "")),
                    name=str(port.get("name", port.get("label", port.get("key", "")))),
                    type=port.get("type", "FLUID"),
                    condition=str(port.get("condition", "true")),
                )
            )
        return ports

    @property
    def active_ports(self) -> list[PortRef]:
        return [port for port in self.ports if port.is_active]

    def port(self, key: str) -> PortRef:
        for port in self.ports:
            if port.key == key:
                return port
        raise ValidationError(f"Component {self.id} does not have port {key!r}.")

    def set_param(self, key: str, value: Any) -> "Component":
        self.params[key] = value
        return self

    def set_params(self, **kwargs: Any) -> "Component":
        self.params.update(kwargs)
        return self

    def get_param(self, key: str, default: Any = None) -> Any:
        return self.params.get(key, default)

    def set_pin_label(self, port_key: str, label: str) -> "Component":
        self.port(port_key)
        self.pins_label[port_key] = label
        return self

    def get_pin_label(self, port_key: str, default: str = "") -> str:
        return str(self.pins_label.get(port_key, default))

    def signal_values(self) -> dict[str, str]:
        values: dict[str, str] = {}
        for arg_def in iter_arg_definitions(self.definition.get("argsGroup", [])):
            if arg_def.get("type") != "signal":
                continue
            key = arg_def.get("key")
            if not key:
                continue
            if not evaluate_condition(arg_def.get("condition", "true"), {**self.params, "context": {}}):
                continue
            value = str(self.params.get(key, "")).strip()
            if value:
                values[key] = value
        return values

    def validate(self) -> list[str]:
        issues: list[str] = []
        for arg_def in iter_arg_definitions(self.definition.get("argsGroup", [])):
            key = arg_def.get("key")
            if not key:
                continue
            if not evaluate_condition(arg_def.get("condition", "true"), {**self.params, "context": {}}):
                continue
            value = self.params.get(key)
            label = arg_def.get("label", key)
            arg_type = arg_def.get("type")
            if arg_type == "real":
                try:
                    numeric = float(value)
                except (TypeError, ValueError):
                    issues.append(f"property {label} must be numeric")
                    continue
                minimum = arg_def.get("min")
                maximum = arg_def.get("max")
                range_type = str(arg_def.get("rangeType", "CLOSE")).upper()
                if minimum is not None:
                    if range_type in {"LEFT_OPEN", "OPEN"} and not numeric > float(minimum):
                        issues.append(f"property {label} must be > {minimum}")
                    if range_type not in {"LEFT_OPEN", "OPEN"} and not numeric >= float(minimum):
                        issues.append(f"property {label} must be >= {minimum}")
                if maximum is not None:
                    if range_type in {"RIGHT_OPEN", "OPEN"} and not numeric < float(maximum):
                        issues.append(f"property {label} must be < {maximum}")
                    if range_type not in {"RIGHT_OPEN", "OPEN"} and not numeric <= float(maximum):
                        issues.append(f"property {label} must be <= {maximum}")
            elif arg_type == "choice":
                choices = arg_def.get("choices", []) or []
                allowed = {item.get("key") for item in choices if isinstance(item, dict) and "key" in item}
                if allowed and value not in allowed:
                    issues.append(f"property {label} must be one of {sorted(allowed)!r}")
            elif arg_type == "table":
                if not isinstance(value, list):
                    issues.append(f"property {label} must be a list")
                else:
                    min_row = arg_def.get("minRow")
                    max_row = arg_def.get("maxRow")
                    if min_row is not None and len(value) < int(min_row):
                        issues.append(f"property {label} must contain at least {min_row} rows")
                    if max_row is not None and len(value) > int(max_row):
                        issues.append(f"property {label} must contain no more than {max_row} rows")
            elif arg_type in {"text", "datetime", "signal", "color"}:
                if value is None:
                    issues.append(f"property {label} cannot be null")
        return issues

    def to_node_data(self) -> NodeData:
        return {
            "id": self.id,
            "label": self.label,
            "nodeClassID": self.class_id,
            "viewStatus": self.view_status,
            "data": self.params,
            "pinsLabel": self.pins_label,
        }
