from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests

from .exceptions import AuthError


@dataclass(slots=True)
class TokenPair:
    access_token: str
    refresh_token: str | None = None


class TokenAuth:
    def __init__(
        self,
        *,
        base_url: str,
        session: requests.Session,
        access_token: str | None = None,
        refresh_token: str | None = None,
        username: str | None = None,
        password: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._session = session
        self._timeout = timeout
        self._username = username
        self._password = password
        self._tokens = TokenPair(access_token or "", refresh_token)

    @property
    def access_token(self) -> str | None:
        return self._tokens.access_token or None

    @property
    def refresh_token(self) -> str | None:
        return self._tokens.refresh_token

    @property
    def authorization_header(self) -> dict[str, str]:
        if not self.access_token:
            return {}
        return {"Authorization": f"Bearer {self.access_token}"}

    @property
    def can_refresh(self) -> bool:
        return bool(self.refresh_token or (self._username and self._password))

    def ensure_login(self) -> None:
        if self.access_token:
            return
        if not (self._username and self._password):
            raise AuthError("No access token or username/password was provided.")
        self.login(self._username, self._password)

    def login(self, username: str, password: str) -> TokenPair:
        response = self._session.post(
            f"{self._base_url}/api/token/",
            json={"username": username, "password": password},
            timeout=self._timeout,
        )
        payload = _parse_json(response)
        if response.status_code >= 400:
            raise AuthError(_extract_error_message(payload, response.text))

        access = payload.get("access") or payload.get("access_token")
        refresh = payload.get("refresh") or payload.get("refresh_token")
        if not access:
            raise AuthError("Token endpoint did not return an access token.")
        self._username = username
        self._password = password
        self._tokens = TokenPair(access, refresh)
        return self._tokens

    def refresh(self) -> TokenPair:
        if self.refresh_token:
            response = self._session.post(
                f"{self._base_url}/api/token/refresh/",
                json={"refresh": self.refresh_token},
                timeout=self._timeout,
            )
            payload = _parse_json(response)
            if response.status_code < 400:
                access = payload.get("access") or payload.get("access_token")
                refresh = payload.get("refresh") or payload.get("refresh_token") or self.refresh_token
                if access:
                    self._tokens = TokenPair(access, refresh)
                    return self._tokens

        if self._username and self._password:
            return self.login(self._username, self._password)
        raise AuthError("Unable to refresh access token.")


def _parse_json(response: requests.Response) -> dict[str, Any]:
    try:
        payload = response.json()
    except ValueError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _extract_error_message(payload: dict[str, Any], fallback: str) -> str:
    for key in ("detail", "message", "error", "msg"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return fallback or "Authentication failed."
