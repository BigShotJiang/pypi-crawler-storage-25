from __future__ import annotations

from typing import Any

import requests

from .auth import TokenAuth
from .http import HttpClient
from .job import Job
from .meta import MetaService
from .model import Model


class DxPipeClient:
    def __init__(
        self,
        *,
        base_url: str,
        token: str | None = None,
        refresh_token: str | None = None,
        username: str | None = None,
        password: str | None = None,
        timeout: float = 30.0,
        session: requests.Session | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = session or requests.Session()
        self.auth = TokenAuth(
            base_url=self.base_url,
            session=self.session,
            access_token=token,
            refresh_token=refresh_token,
            username=username,
            password=password,
            timeout=timeout,
        )
        self.http = HttpClient(base_url=self.base_url, auth=self.auth, timeout=timeout, session=self.session)
        self.meta = MetaService(self.http)

    def __enter__(self) -> "DxPipeClient":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        self.session.close()

    def login(self, username: str, password: str) -> None:
        self.auth.login(username, password)

    def list_models(self, **params: Any) -> list[Model]:
        return Model.list(self, **params)

    def get_model(self, model_id: str) -> Model:
        return Model.get(self, model_id)

    def create_model(
        self,
        *,
        name: str,
        workspace_type: str,
        description: str = "",
        publicity: str = "private",
        global_params: dict[str, Any] | None = None,
    ) -> Model:
        return Model.create(
            self,
            name=name,
            workspace_type=workspace_type,
            description=description,
            publicity=publicity,
            global_params=global_params,
        )

    def list_jobs(self, **params: Any) -> list[Job]:
        return Job.list(self, **params)

    def get_job(self, job_id: str) -> Job:
        return Job.get(self, job_id)
