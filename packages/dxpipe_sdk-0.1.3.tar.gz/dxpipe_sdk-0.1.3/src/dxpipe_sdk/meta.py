from __future__ import annotations

from typing import Any

from .component import build_default_params
from .http import HttpClient


def _unwrap(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


class MetaService:
    def __init__(self, http_client: HttpClient) -> None:
        self._http = http_client
        self._workspace_cache: dict[str, dict[str, Any]] = {}
        self._component_cache: dict[tuple[str, str], dict[str, Any]] = {}

    def list_workspace_types(self, *, scope: str | None = None) -> list[dict[str, Any]]:
        params = {"scope": scope} if scope else None
        payload = _unwrap(self._http.get("/api/meta/", params=params))
        if isinstance(payload, list):
            return payload
        if isinstance(payload, dict) and "results" in payload:
            return payload["results"]
        return []

    def get_workspace_definition(self, workspace_type: str, *, refresh: bool = False) -> dict[str, Any]:
        if not refresh and workspace_type in self._workspace_cache:
            return self._workspace_cache[workspace_type]
        payload = _unwrap(self._http.get(f"/api/meta/{workspace_type}/"))
        if not isinstance(payload, dict):
            raise TypeError("Workspace definition response must be a JSON object.")
        self._workspace_cache[workspace_type] = payload
        components = payload.get("components", {})
        if isinstance(components, dict):
            for key, value in components.items():
                if isinstance(value, dict):
                    self._component_cache[(workspace_type, key)] = value
        return payload

    def list_components(self, workspace_type: str, *, refresh: bool = False) -> dict[str, dict[str, Any]]:
        definition = self.get_workspace_definition(workspace_type, refresh=refresh)
        components = definition.get("components", {})
        return components if isinstance(components, dict) else {}

    def get_component_definition(
        self,
        workspace_type: str,
        component_id: str,
        *,
        refresh: bool = False,
    ) -> dict[str, Any]:
        cache_key = (workspace_type, component_id)
        if not refresh and cache_key in self._component_cache:
            return self._component_cache[cache_key]
        components = self.list_components(workspace_type, refresh=refresh)
        if component_id in components:
            return components[component_id]
        payload = _unwrap(self._http.get(f"/api/meta/{workspace_type}/components/{component_id}/"))
        if not isinstance(payload, dict):
            raise TypeError("Component definition response must be a JSON object.")
        self._component_cache[cache_key] = payload
        return payload

    def get_global_definition(self, workspace_type: str, *, refresh: bool = False) -> Any:
        definition = self.get_workspace_definition(workspace_type, refresh=refresh)
        return definition.get("global", {})

    def get_default_global_params(self, workspace_type: str, *, refresh: bool = False) -> dict[str, Any]:
        global_definition = self.get_global_definition(workspace_type, refresh=refresh)
        if isinstance(global_definition, list):
            return build_default_params({"argsGroup": global_definition})
        return {}
