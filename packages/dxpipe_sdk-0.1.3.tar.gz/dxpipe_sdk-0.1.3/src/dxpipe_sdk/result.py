from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
import json
from typing import Any

from .types import JobMessagePayload, MessageType, Verb


def _deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged


def normalize_message(payload: Any) -> JobMessagePayload | None:
    if isinstance(payload, str):
        text = payload.strip()
        if not text:
            return None
        if text.startswith("status:"):
            return {"type": "container", "verb": "update", "key": "__status__", "data": text}
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            return None
        return normalize_message(parsed)

    if not isinstance(payload, dict):
        return None

    if "data" in payload and isinstance(payload.get("data"), str) and "type" not in payload:
        try:
            nested = json.loads(payload["data"])
        except json.JSONDecodeError:
            nested = None
        if isinstance(nested, dict):
            normalized = normalize_message(nested)
            if normalized is not None and "id" in payload:
                normalized["id"] = payload["id"]
            return normalized

    if {"key", "verb", "type"}.issubset(payload.keys()):
        message: JobMessagePayload = {
            "key": str(payload["key"]),
            "verb": payload["verb"],
            "type": payload["type"],
            "data": payload.get("data"),
        }
        if "id" in payload:
            message["id"] = payload["id"]
        return message
    return None


def normalize_messages(payload: Any) -> list[JobMessagePayload]:
    if isinstance(payload, str):
        text = payload.strip()
        if not text:
            return []
        if text.startswith("status:"):
            single = normalize_message(text)
            return [single] if single is not None else []
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            single = normalize_message(text)
            return [single] if single is not None else []
        return normalize_messages(parsed)

    if isinstance(payload, list):
        messages: list[JobMessagePayload] = []
        for item in payload:
            messages.extend(normalize_messages(item))
        return messages

    single = normalize_message(payload)
    return [single] if single is not None else []


@dataclass(slots=True)
class LogMessage:
    key: str
    verb: Verb
    level: str
    timestamp: Any
    message: str
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PlotMessage:
    key: str
    config: dict[str, Any]

    def apply(self, verb: Verb, payload: dict[str, Any]) -> None:
        if verb == "append":
            current_dataset = self.config.get("dataset")
            incoming_dataset = payload.get("dataset") if isinstance(payload, dict) else None

            if isinstance(current_dataset, dict) and isinstance(incoming_dataset, dict):
                current_source = current_dataset.setdefault("source", [])
                new_source = incoming_dataset.get("source") or []
                if isinstance(current_source, list) and isinstance(new_source, list):
                    current_source.extend(deepcopy(new_source))
                else:
                    self.config["dataset"] = _deep_merge(current_dataset, incoming_dataset)
            elif isinstance(current_dataset, list) and isinstance(incoming_dataset, list):
                current_dataset.extend(deepcopy(incoming_dataset))
            elif incoming_dataset is not None:
                self.config["dataset"] = deepcopy(incoming_dataset)

            incoming_options = payload.get("options") if isinstance(payload, dict) else None
            current_options = self.config.get("options")
            if isinstance(current_options, list) and isinstance(incoming_options, list):
                current_options.extend(deepcopy(incoming_options))
                payload = {k: v for k, v in payload.items() if k != "options"}

            self.config = _deep_merge(
                self.config,
                {k: v for k, v in payload.items() if k not in {"dataset", "options"}},
            )
            return
        self.config = _deep_merge(self.config, payload)


@dataclass(slots=True)
class InspectMessage:
    key: str
    entries: list[dict[str, Any]] = field(default_factory=list)

    def apply(self, verb: Verb, payload: dict[str, Any]) -> None:
        if verb == "append":
            entries = payload.get("data", payload)
            if isinstance(entries, list):
                self.entries.extend(deepcopy(entries))
            elif isinstance(entries, dict):
                self.entries.append(deepcopy(entries))
            return
        if verb == "update":
            entries = payload.get("data", payload)
            if isinstance(entries, list):
                self.entries = deepcopy(entries)
            elif isinstance(entries, dict):
                self.entries = [deepcopy(entries)]

    def latest(self) -> dict[str, Any] | None:
        return self.entries[-1] if self.entries else None


@dataclass(slots=True)
class TableMessage:
    key: str
    label: str
    columns: list[dict[str, Any]]

    def apply(self, verb: Verb, payload: dict[str, Any]) -> None:
        if verb == "append":
            new_columns = payload.get("column", [])
            if len(new_columns) != len(self.columns):
                self.columns = deepcopy(new_columns)
                self.label = str(payload.get("label", self.label))
                return
            for current, incoming in zip(self.columns, new_columns):
                current.setdefault("data", [])
                current["data"].extend(deepcopy(incoming.get("data", [])))
            return
        self.label = str(payload.get("label", self.label))
        self.columns = deepcopy(payload.get("column", []))


@dataclass(slots=True)
class ContainerMessage:
    key: str
    content: Any

    def apply(self, verb: Verb, payload: Any) -> None:
        if verb in {"append", "update"}:
            self.content = deepcopy(payload)


class ResultStream:
    def __init__(self) -> None:
        self.messages: list[JobMessagePayload] = []
        self._logs: dict[str, list[LogMessage]] = {}
        self._plots: dict[str, PlotMessage] = {}
        self._inspects: dict[str, InspectMessage] = {}
        self._tables: dict[str, TableMessage] = {}
        self._containers: dict[str, ContainerMessage] = {}

    def apply_message(self, payload: Any) -> JobMessagePayload | None:
        message = normalize_message(payload)
        if message is None:
            return None
        self.messages.append(message)
        message_type = message["type"]
        verb = message["verb"]
        key = message["key"]
        data = message.get("data")
        if message_type == "log":
            self._apply_log(key, verb, data)
        elif message_type == "plot":
            self._apply_plot(key, verb, data)
        elif message_type == "inspect":
            self._apply_inspect(key, verb, data)
        elif message_type == "table":
            self._apply_table(key, verb, data)
        elif message_type == "container":
            self._apply_container(key, verb, data)
        return message

    def filter(
        self,
        *,
        type: MessageType | None = None,
        key: str | None = None,
        verb: Verb | None = None,
    ) -> list[JobMessagePayload]:
        messages = self.messages
        if type is not None:
            messages = [message for message in messages if message.get("type") == type]
        if key is not None:
            messages = [message for message in messages if message.get("key") == key]
        if verb is not None:
            messages = [message for message in messages if message.get("verb") == verb]
        return messages

    def logs(self) -> list[LogMessage]:
        output: list[LogMessage] = []
        for bucket in self._logs.values():
            output.extend(bucket)
        return output

    def plots(self, key: str | None = None) -> dict[str, PlotMessage]:
        if key is None:
            return dict(self._plots)
        return {key: self._plots[key]} if key in self._plots else {}

    def inspects(self, key: str | None = None) -> dict[str, InspectMessage]:
        if key is None:
            return dict(self._inspects)
        return {key: self._inspects[key]} if key in self._inspects else {}

    def tables(self, key: str | None = None) -> dict[str, TableMessage]:
        if key is None:
            return dict(self._tables)
        return {key: self._tables[key]} if key in self._tables else {}

    def containers(self, key: str | None = None) -> dict[str, ContainerMessage]:
        if key is None:
            return dict(self._containers)
        return {key: self._containers[key]} if key in self._containers else {}

    def _apply_log(self, key: str, verb: Verb, payload: Any) -> None:
        if verb == "delete":
            self._logs.pop(key, None)
            return
        items = payload if isinstance(payload, list) else [payload]
        bucket = [] if verb == "update" or key not in self._logs else self._logs[key]
        for item in items:
            if not isinstance(item, dict):
                continue
            bucket.append(
                LogMessage(
                    key=key,
                    verb=verb,
                    level=str(item.get("level", "info")),
                    timestamp=item.get("timeStamp"),
                    message=str(item.get("message", "")),
                    raw=deepcopy(item),
                )
            )
        self._logs[key] = bucket

    def _apply_plot(self, key: str, verb: Verb, payload: Any) -> None:
        if verb == "delete":
            self._plots.pop(key, None)
            return
        data = payload if isinstance(payload, dict) else {}
        plot = self._plots.get(key)
        if plot is None or verb == "update":
            self._plots[key] = PlotMessage(key=key, config=deepcopy(data))
            return
        plot.apply(verb, data)

    def _apply_inspect(self, key: str, verb: Verb, payload: Any) -> None:
        if verb == "delete":
            self._inspects.pop(key, None)
            return
        data = payload if isinstance(payload, dict) else {"data": payload}
        inspect = self._inspects.get(key)
        if inspect is None or verb == "update":
            inspect = InspectMessage(key=key)
            self._inspects[key] = inspect
        inspect.apply(verb, data)

    def _apply_table(self, key: str, verb: Verb, payload: Any) -> None:
        if verb == "delete":
            self._tables.pop(key, None)
            return
        data = payload if isinstance(payload, dict) else {}
        table = self._tables.get(key)
        if table is None or verb == "update":
            self._tables[key] = TableMessage(
                key=key,
                label=str(data.get("label", key)),
                columns=deepcopy(data.get("column", [])),
            )
            return
        table.apply(verb, data)

    def _apply_container(self, key: str, verb: Verb, payload: Any) -> None:
        if verb == "delete":
            self._containers.pop(key, None)
            return
        container = self._containers.get(key)
        if container is None:
            self._containers[key] = ContainerMessage(key=key, content=deepcopy(payload))
            return
        container.apply(verb, payload)
