from __future__ import annotations

import sys
from pathlib import Path
import unittest


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from dxpipe_sdk.result import ResultStream
from dxpipe_sdk.result import normalize_messages


class ResultStreamTests(unittest.TestCase):
    def test_log_messages_are_collected(self) -> None:
        stream = ResultStream()
        stream.apply_message(
            {
                "key": "system-log",
                "verb": "append",
                "type": "log",
                "data": {"level": "info", "timeStamp": 1, "message": "ok"},
            }
        )

        logs = stream.logs()

        self.assertEqual(len(logs), 1)
        self.assertEqual(logs[0].message, "ok")
        self.assertEqual(logs[0].level, "info")

    def test_plot_append_merges_dataset_source(self) -> None:
        stream = ResultStream()
        stream.apply_message(
            {
                "key": "plot-1",
                "verb": "update",
                "type": "plot",
                "data": {
                    "dataset": {"source": [[1, 2]]},
                    "series": [{"type": "line"}],
                },
            }
        )
        stream.apply_message(
            {
                "key": "plot-1",
                "verb": "append",
                "type": "plot",
                "data": {
                    "dataset": {"source": [[2, 3]]},
                },
            }
        )

        plot = stream.plots("plot-1")["plot-1"]

        self.assertEqual(plot.config["dataset"]["source"], [[1, 2], [2, 3]])

    def test_plot_append_handles_list_dataset_and_options(self) -> None:
        stream = ResultStream()
        stream.apply_message(
            {
                "key": "plot-2",
                "verb": "update",
                "type": "plot",
                "data": {
                    "dataset": [{"source": [[1, 2]]}],
                    "options": [{"title": {"text": "t1"}}],
                },
            }
        )
        stream.apply_message(
            {
                "key": "plot-2",
                "verb": "append",
                "type": "plot",
                "data": {
                    "dataset": [{"source": [[2, 3]]}],
                    "options": [{"title": {"text": "t2"}}],
                },
            }
        )

        plot = stream.plots("plot-2")["plot-2"]

        self.assertEqual(len(plot.config["dataset"]), 2)
        self.assertEqual(len(plot.config["options"]), 2)

    def test_normalize_messages_handles_batched_frames(self) -> None:
        messages = normalize_messages(
            '[{"id":1,"data":"{\\"key\\":\\"p1\\",\\"verb\\":\\"update\\",\\"type\\":\\"plot\\",\\"data\\":{\\"dataset\\":{\\"source\\":[[1,2]]}}}"},'
            '{"id":2,"data":"{\\"key\\":\\"l1\\",\\"verb\\":\\"append\\",\\"type\\":\\"log\\",\\"data\\":{\\"level\\":\\"info\\",\\"timeStamp\\":1,\\"message\\":\\"ok\\"}}"}]'
        )

        self.assertEqual(len(messages), 2)
        self.assertEqual(messages[0]["type"], "plot")
        self.assertEqual(messages[1]["type"], "log")


if __name__ == "__main__":
    unittest.main()
