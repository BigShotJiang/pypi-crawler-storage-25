from __future__ import annotations

import sys
from pathlib import Path
import unittest


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from dxpipe_sdk.meta import MetaService
from dxpipe_sdk.model import Model


class _FakeHttpClient:
    def __init__(self):
        self.last_post = None

    def get(self, path, params=None):
        raise AssertionError(f"unexpected GET {path} {params}")

    def post(self, path, json=None, params=None):
        self.last_post = {"path": path, "json": json, "params": params}
        if path == "/api/jobs/":
            return {
                "data": {
                    "id": "created-job-id",
                    "status": "pending",
                    "progress": 0,
                    "workspace_type": json["workspace_type"],
                    "model": json["model_id"],
                }
            }
        return {
            "data": {
                "id": "created-model-id",
                "name": json["name"],
                "description": json["description"],
                "publicity": json["publicity"],
                "type": json["type"],
                "current_snapshot": json["snapshot_data"],
            }
        }


class _FakeMetaService:
    def __init__(self):
        self.workspace_definition = {
            "global": [
                {
                    "groupName": "全局参数",
                    "groupCondition": "true",
                    "argsDefinition": [
                        {"key": "simuType", "type": "choice", "defaultValue": "steady"},
                        {"key": "startTime", "type": "datetime", "defaultValue": "2025-01-01 00:00:00"},
                    ],
                }
            ],
            "components": {
                "Source": {
                    "label": "源点",
                    "argsGroup": [
                        {
                            "argsDefinition": [
                                {
                                    "key": "Pressure",
                                    "label": "压力",
                                    "type": "real",
                                    "defaultValue": 1.0,
                                    "min": 0,
                                }
                            ]
                        }
                    ],
                    "commands": [],
                    "portsDefinition": [
                        {"key": "0", "name": "出口", "type": "FLUID", "condition": "true"}
                    ],
                },
                "Sink": {
                    "label": "汇点",
                    "argsGroup": [
                        {
                            "argsDefinition": [
                                {
                                    "key": "Demand",
                                    "label": "需求",
                                    "type": "real",
                                    "defaultValue": 1.0,
                                    "min": 0,
                                }
                            ]
                        }
                    ],
                    "commands": [],
                    "portsDefinition": [
                        {"key": "0", "name": "入口", "type": "FLUID", "condition": "true"}
                    ],
                },
                "Battery": {
                    "label": "电源",
                    "argsGroup": [],
                    "commands": [],
                    "portsDefinition": [
                        {"key": "p", "name": "正极", "type": "ELECTRICAL", "condition": "true"}
                    ],
                },
                "Load": {
                    "label": "负载",
                    "argsGroup": [],
                    "commands": [],
                    "portsDefinition": [
                        {"key": "p", "name": "正极", "type": "ELECTRICAL", "condition": "true"}
                    ],
                },
            }
        }

    def get_workspace_definition(self, workspace_type, refresh=False):
        return self.workspace_definition

    def get_component_definition(self, workspace_type, component_id, refresh=False):
        return self.workspace_definition["components"][component_id]

    def get_default_global_params(self, workspace_type, refresh=False):
        return {"simuType": "steady", "startTime": "2025-01-01 00:00:00"}


class _FakeClient:
    def __init__(self):
        self.http = _FakeHttpClient()
        self.meta = _FakeMetaService()


class ModelTests(unittest.TestCase):
    def test_create_populates_default_global_parameters(self) -> None:
        client = _FakeClient()

        model = Model.create(client, name="demo", workspace_type="lps")

        self.assertEqual(model.global_params["simuType"], "steady")
        self.assertEqual(model.global_params["startTime"], "2025-01-01 00:00:00")
        self.assertEqual(
            client.http.last_post["json"]["snapshot_data"]["global"]["simuType"],
            "steady",
        )

    def test_component_and_connection_are_serialized(self) -> None:
        client = _FakeClient()
        model = Model(
            client=client,
            model_id="model-1",
            name="demo",
            workspace_type="lps",
            snapshot={"global": {}, "nodes": [], "edges": []},
        )

        source = model.add_component("Source")
        sink = model.add_component("Sink")
        model.connect(source, "0", sink, "0")

        snapshot = model.to_snapshot_data()

        self.assertEqual(len(snapshot["nodes"]), 2)
        self.assertEqual(len(snapshot["edges"]), 1)
        self.assertEqual(snapshot["edges"][0]["type"], "fluid-edge")

    def test_electrical_ports_create_electrical_edges(self) -> None:
        client = _FakeClient()
        model = Model(
            client=client,
            model_id="model-1",
            name="demo",
            workspace_type="lps",
            snapshot={"global": {}, "nodes": [], "edges": []},
        )

        battery = model.add_component("Battery")
        load = model.add_component("Load")
        model.connect(battery, "p", load, "p")

        snapshot = model.to_snapshot_data()

        self.assertEqual(snapshot["edges"][0]["type"], "electrical-edge")
        self.assertEqual(
            snapshot["edges"][0]["attrs"]["line"]["stroke"],
            "#0b5d3b",
        )

    def test_validate_reports_unconnected_active_port(self) -> None:
        client = _FakeClient()
        model = Model(
            client=client,
            model_id="model-1",
            name="demo",
            workspace_type="lps",
            snapshot={"global": {}, "nodes": [], "edges": []},
        )

        model.add_component("Source")

        issues = model.validate()

        self.assertEqual(len(issues), 1)
        self.assertIn("not connected", issues[0])

    def test_run_includes_workspace_type_and_model_id(self) -> None:
        client = _FakeClient()
        model = Model(
            client=client,
            model_id="model-1",
            name="demo",
            workspace_type="lps_online",
            snapshot={"global": {}, "nodes": [], "edges": []},
        )

        job = model.run()

        self.assertEqual(client.http.last_post["path"], "/api/jobs/")
        self.assertEqual(client.http.last_post["json"]["workspace_type"], "lps_online")
        self.assertEqual(client.http.last_post["json"]["model_id"], "model-1")
        self.assertEqual(job.workspace_type, "lps_online")
        self.assertEqual(job.model_id, "model-1")


if __name__ == "__main__":
    unittest.main()
