from __future__ import annotations

import sys
from pathlib import Path
import unittest


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


class PublicApiSmokeTests(unittest.TestCase):
    def test_package_public_exports_are_importable(self) -> None:
        from dxpipe_sdk import APIError
        from dxpipe_sdk import AuthError
        from dxpipe_sdk import Component
        from dxpipe_sdk import Connection
        from dxpipe_sdk import ContainerMessage
        from dxpipe_sdk import DxPipeClient
        from dxpipe_sdk import DxPipeError
        from dxpipe_sdk import InspectMessage
        from dxpipe_sdk import Job
        from dxpipe_sdk import LogMessage
        from dxpipe_sdk import MetaService
        from dxpipe_sdk import Model
        from dxpipe_sdk import NotFoundError
        from dxpipe_sdk import PlotMessage
        from dxpipe_sdk import PortRef
        from dxpipe_sdk import ResultStream
        from dxpipe_sdk import TableMessage
        from dxpipe_sdk import ValidationError

        exported = {
            APIError,
            AuthError,
            Component,
            Connection,
            ContainerMessage,
            DxPipeClient,
            DxPipeError,
            InspectMessage,
            Job,
            LogMessage,
            MetaService,
            Model,
            NotFoundError,
            PlotMessage,
            PortRef,
            ResultStream,
            TableMessage,
            ValidationError,
        }

        self.assertEqual(len(exported), 18)


if __name__ == "__main__":
    unittest.main()