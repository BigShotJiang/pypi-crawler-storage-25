from __future__ import annotations

from aicd.tools.html_dom_extract import extract_main_text_from_html


def test_extract_main_text_strips_overlay_and_script() -> None:
    html = """<!DOCTYPE html><html><head><title>T</title></head><body>
    <div role="dialog">modal noise</div>
    <main><p>Hello  world</p><p>Second line</p></main>
    <script>evil()</script>
    </body></html>"""
    r = extract_main_text_from_html(html, max_chars=10_000)
    assert r["ok"] is True
    text = r["text"]
    assert "Hello" in text
    assert "Second line" in text
    assert "evil" not in text
    assert "modal noise" not in text


def test_extract_truncates() -> None:
    long_body = "<html><body><main>" + ("x" * 5000) + "</main></body></html>"
    r = extract_main_text_from_html(long_body, max_chars=100)
    assert r["ok"] is True
    assert r["truncated"] is True
    assert len(r["text"]) == 100
