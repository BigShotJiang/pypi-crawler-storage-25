"""可选搜索 API：配置门闸与状态载荷。"""

from __future__ import annotations

from aicd.config import AppConfig
from aicd.config_settings import apply_nested_settings_patch
from aicd.tools.search_api_tools import (
    search_integrations_status_payload,
)


def _cfg() -> AppConfig:
    return AppConfig.from_dict({})


def test_search_status_all_disabled_by_default() -> None:
    cfg = _cfg()
    st = search_integrations_status_payload(cfg)
    assert st["google_cse_search"]["enabled"] is False
    assert st["google_cse_search"]["ready"] is False
    assert st["bing_web_search"]["enabled"] is False
    assert st["github_search"]["enabled"] is False
    assert st["gitlab_search"]["enabled"] is False


def test_agent_settings_patch_toggles_google_cse() -> None:
    cfg = _cfg()
    ok, _ = apply_nested_settings_patch(
        cfg,
        {
            "integrations": {
                "googleCseSearch": {
                    "enabled": True,
                    "apiKey": "k",
                    "cx": "cx123",
                }
            }
        },
    )
    assert ok is True
    assert cfg.integrations.google_cse_search.enabled is True
    assert cfg.integrations.google_cse_search.api_key == "k"


def test_search_status_google_ready_when_enabled_and_keys() -> None:
    d = {
        "integrations": {
            "googleCseSearch": {"enabled": True, "apiKey": "k", "cx": "cx123"},
        }
    }
    cfg = AppConfig.from_dict(d)
    st = search_integrations_status_payload(cfg)
    assert st["google_cse_search"]["ready"] is True


def test_google_cse_disabled_returns_hint() -> None:
    import asyncio

    from aicd.tools.search_api_tools import run_search_google_cse

    cfg = _cfg()
    r = asyncio.run(run_search_google_cse(cfg, q="test", num=5, timeout_sec=5.0))
    assert r.get("ok") is False
    assert r.get("error") == "search_google_cse_disabled"
    assert "search_integrations_status" in r
