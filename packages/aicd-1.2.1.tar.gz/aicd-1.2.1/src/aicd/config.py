from __future__ import annotations

import copy as copy_mod
from copy import copy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from aicd.config_migration import CURRENT_CONFIG_VERSION, migrate_config_dict

PROTO_OPENAI = "openai"
PROTO_DASHSCOPE = "dashscope"
PROTO_OLLAMA = "ollama"
VALID_PROTOS = frozenset({PROTO_OPENAI, PROTO_DASHSCOPE, PROTO_OLLAMA})


def parse_supports_vision_bool(raw: object | None, *, default: bool = True) -> bool:
    """解析 ``supportsVision`` / ``supports_vision``（避免 ``bool('false') is True``）。"""
    if raw is None:
        return default
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, (int, float)):
        return raw != 0
    if isinstance(raw, str):
        s = raw.strip().lower()
        if s in ("", "0", "false", "no", "off", "n"):
            return False
        if s in ("1", "true", "yes", "on", "y"):
            return True
    return bool(raw)


_DEFAULT_OPENAI_BASE = "https://api.openai.com/v1"
_DEFAULT_DASHSCOPE_BASE = "https://dashscope.aliyuncs.com/compatible-mode/v1"
_DEFAULT_OLLAMA_BASE = "http://127.0.0.1:11434/v1"

# 主对话与子 Agent 单次用户消息内工具循环次数上限（配置、/agent、agent_settings_update）
MAX_AGENT_TOOL_ROUNDS = 500


@dataclass
class LLMConfig:
    """LLM 源与采样参数（``None`` 表示不显式传参，由接口默认值决定）。"""

    proto: str = PROTO_OPENAI
    base_url: str = ""
    api_key: str = ""
    model: str = "gpt-4o-mini"
    vision_model: str | None = None  # 多模态专用；None 时用 model
    timeout_sec: float = 120.0
    temperature: float | None = None
    top_p: float | None = None
    frequency_penalty: float | None = None
    presence_penalty: float | None = None
    max_output_tokens: int | None = None
    repetition_penalty: float | None = None
    extra_body: dict[str, Any] = field(default_factory=dict)
    max_retries: int = 3  # 失败后额外重试次数；0 表示不重试
    retry_base_delay_sec: float = 1.0  # 退避基数秒（×2^attempt + 抖动）
    # 模型 id → 上下文总窗（tokens）；**显式表项优先于** HTTP 探测。键 **default** / ***** 为兜底。
    model_context_tokens: dict[str, int] = field(default_factory=dict)
    #: 是否支持 **image_url** 多模态（**vision_analyze_image**）；纯文本端点设为 **False**。
    supports_vision: bool = True


# 新建非 Ollama 配置且未指定上下文时写入 profile 的默认值（仍可被服务端探测压收缩小）
DEFAULT_PROFILE_CONTEXT_TOKENS = 128_000


@dataclass
class LLMProfile:
    """具名 LLM 连接配置（多模型切换）；采样参数仍用全局 ``LLMConfig``。"""

    name: str
    proto: str
    base_url: str
    api_key: str
    model: str
    #: ``None`` 表示不在此 profile 固化窗口，交给探测/表项；非 ``None`` 则写入 ``model_context_tokens``
    context_window_tokens: int | None = None
    vision_model: str | None = None
    #: 与 **LLMConfig.supports_vision** 同源：是否可将图片送入该 profile 对应模型。
    supports_vision: bool = True

    @classmethod
    def from_mapping(cls, raw: dict[str, Any]) -> LLMProfile:
        name = str(raw.get("name") or "default").strip() or "default"
        proto = _normalize_proto(
            str(raw.get("proto") or ""),
            str(raw.get("provider") or ""),
        )
        base_url = str(
            raw.get("baseUrl") or raw.get("base_url") or raw.get("url") or ""
        ).strip()
        api_key = str(
            raw.get("apiKey") or raw.get("api_key") or raw.get("key") or ""
        ).strip()
        model = str(
            raw.get("modelId") or raw.get("model_id") or raw.get("model") or ""
        ).strip() or "gpt-4o-mini"
        vm = raw.get("visionModel") or raw.get("vision_model")
        vision_model = str(vm).strip() if vm not in (None, "") else None
        if "supportsVision" in raw:
            sv = raw.get("supportsVision")
        elif "supports_vision" in raw:
            sv = raw.get("supports_vision")
        else:
            sv = None
        supports_vision = parse_supports_vision_bool(sv, default=True)
        cwt = raw.get("contextWindowTokens") or raw.get("context_window_tokens")
        ctx: int | None = None
        if cwt is not None and str(cwt).strip().lower() not in ("", "null", "none", "auto"):
            try:
                iv = int(cwt)
                ctx = iv if iv > 0 else None
            except (TypeError, ValueError):
                ctx = None
        return cls(
            name=name,
            proto=proto,
            base_url=base_url,
            api_key=api_key,
            model=model,
            context_window_tokens=ctx,
            vision_model=vision_model,
            supports_vision=supports_vision,
        )

    def to_mapping(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "proto": self.proto,
            "baseUrl": self.base_url,
            "apiKey": self.api_key,
            "modelId": self.model,
            "supportsVision": self.supports_vision,
        }
        if self.vision_model:
            d["visionModel"] = self.vision_model
        if self.context_window_tokens is not None:
            d["contextWindowTokens"] = int(self.context_window_tokens)
        return d


def _profiles_from_dict_list(raw: Any) -> list[LLMProfile]:
    if not isinstance(raw, list):
        return []
    out: list[LLMProfile] = []
    for x in raw:
        if isinstance(x, dict):
            out.append(LLMProfile.from_mapping(x))
    return out


def _synth_profile_from_llm_fields(lf: dict[str, Any], name: str = "default") -> LLMProfile:
    mct = lf.get("model_context_tokens") or {}
    mid = str(lf.get("model") or "")
    ctx: int | None = None
    if isinstance(mct, dict) and mid:
        for k, v in mct.items():
            if str(k).strip() == mid or str(k).strip().lower() == mid.lower():
                try:
                    ctx = int(v)
                    if ctx <= 0:
                        ctx = None
                except (TypeError, ValueError):
                    ctx = None
                break
        if ctx is None:
            for sk in ("default", "*"):
                if sk in mct:
                    try:
                        ctx = int(mct[sk])
                        if ctx <= 0:
                            ctx = None
                    except (TypeError, ValueError):
                        ctx = None
                    break
    return LLMProfile(
        name=name,
        proto=str(lf.get("proto") or PROTO_OPENAI),
        base_url=str(lf.get("base_url") or ""),
        api_key=str(lf.get("api_key") or ""),
        model=mid or "gpt-4o-mini",
        context_window_tokens=ctx,
        vision_model=lf.get("vision_model"),
        supports_vision=bool(lf.get("supports_vision", True)),
    )


def apply_active_profile_to_llm(cfg: "AppConfig") -> None:
    """将当前激活 profile 的连接字段与上下文表写入 ``cfg.llm``。"""
    name = (cfg.active_llm_profile or "").strip() or "default"
    prof: LLMProfile | None = None
    for p in cfg.llm_profiles:
        if p.name == name:
            prof = p
            break
    if prof is None and cfg.llm_profiles:
        prof = cfg.llm_profiles[0]
        cfg.active_llm_profile = prof.name
    if prof is None:
        return
    cfg.llm.proto = prof.proto
    cfg.llm.base_url = prof.base_url
    cfg.llm.api_key = prof.api_key
    cfg.llm.model = prof.model
    cfg.llm.vision_model = prof.vision_model
    cfg.llm.supports_vision = prof.supports_vision
    mct = dict(cfg.llm.model_context_tokens or {})
    mid = prof.model
    if prof.context_window_tokens is not None:
        n = int(prof.context_window_tokens)
        mct[mid] = n
        mct["default"] = n
        cfg.llm.model_context_tokens = normalize_model_context_tokens_map(mct)
    else:
        mct = {
            k: v
            for k, v in mct.items()
            if str(k).strip().lower() not in (mid.lower(),)
        }
        cfg.llm.model_context_tokens = normalize_model_context_tokens_map(mct)


def sync_active_profile_from_llm(cfg: "AppConfig") -> None:
    """在持久化前把当前 ``cfg.llm`` 连接信息写回激活的 profile。"""
    name = (cfg.active_llm_profile or "").strip() or "default"
    ctx: int | None = None
    mid = cfg.llm.model
    mct = cfg.llm.model_context_tokens or {}
    if mid in mct:
        try:
            ctx = int(mct[mid])
            if ctx <= 0:
                ctx = None
        except (TypeError, ValueError):
            ctx = None
    if ctx is None:
        for sk in ("default", "*"):
            if sk in mct:
                try:
                    ctx = int(mct[sk])
                    if ctx <= 0:
                        ctx = None
                except (TypeError, ValueError):
                    ctx = None
                break
    new_p = LLMProfile(
        name=name,
        proto=cfg.llm.proto,
        base_url=cfg.llm.base_url,
        api_key=cfg.llm.api_key,
        model=cfg.llm.model,
        context_window_tokens=ctx,
        vision_model=cfg.llm.vision_model,
        supports_vision=cfg.llm.supports_vision,
    )
    for i, p in enumerate(cfg.llm_profiles):
        if p.name == name:
            cfg.llm_profiles[i] = new_p
            return
    cfg.llm_profiles.append(new_p)


@dataclass
class AgentConfig:
    """主对话与子 Agent 的工具调用最大轮次。"""

    max_tool_rounds: int = 100
    sub_agent_max_tool_rounds: int = 80
    # 载入内存历史的粗算 token 上限（与 chat_serialize 估计、多模态图 8k/张 对齐）；硬上限见 from_dict 2_000_000
    context_budget_tokens: int = 1_000_000
    chat_history_max_messages: int = 800
    # 从 SQLite 尾部恢复时：尽量保留最近若干 **条 DB 行** 为完整 OpenAI 消息链；更早行压成单条 user 摘要（见 build_hydrated_messages）
    chat_history_recent_full_rows: int = 48
    # 0=关闭。主对话：TUI 在空闲时注入「定时心跳」；顶层子任务结束也会注入「子任务终态」尽快接续（秒，夹紧 5–3600）。默认 60 便于后台 task_ai 完成后主对话自动检查主收件箱。
    idle_heartbeat_sec: int = 60
    # 子 Agent：仍有 running/pending 子任务且收件箱为空时睡眠再协调（秒；0=立即退出）。默认 30 便于嵌套子任务收尾。
    sub_agent_idle_heartbeat_sec: int = 30
    # 顶层 lifecycle 多条连续到达时合并延迟（秒，夹紧 0–3；0=立即入队）。默认 0.35。
    lifecycle_coalesce_sec: float = 0.35
    # 为 True 时：除 LLM 请求外，Aicd **工具**不得访问非本机回环的外网；默认关。启动可加 --block-external-network 或 AICD_BLOCK_EXTERNAL_NETWORK=1。
    block_external_network: bool = False
    # interactive_process：自上次 start/write/read 起无活动则自动 terminate（秒）。0=关闭。最大 86400。每 ToolRouter 一份（子 Agent 独立）。
    interactive_process_idle_sec: float = 0.0
    vision_image_token_budget_per_image: int | None = None
    #: 交互 TUI 启动时（未使用 ``--work`` / ``--work-here``）是否直接以**进程当前目录**为 AI 工作区（不新建 ``workspace_*``）。
    startup_workspace_from_cwd: bool = False
    #: 默认工作模式（``general``/``dev``/``script``/``pentest``/``ops``）。启动时与 ``tui_prefs.json`` 合并：
    #: 若用户曾用 ``/workmode`` 持久化（``work_mode_user_override: true``），以 prefs 为准；否则以本项为准；
    #: 旧版 prefs 仅有 ``work_mode: general`` 而本项为非 general 时，以本项为准（避免陈旧 general 覆盖配置）。
    default_work_mode: str = "general"


def normalize_model_context_tokens_map(raw: Any) -> dict[str, int]:
    """解析 ``llm.modelContextTokens`` / ``model_context_tokens``：仅保留正整数；键为模型 id 或 **default** / *****。"""
    if not isinstance(raw, dict):
        return {}
    out: dict[str, int] = {}
    for k, v in raw.items():
        key = str(k).strip()
        if not key:
            continue
        try:
            iv = int(v)
        except (TypeError, ValueError):
            continue
        if iv > 0:
            out[key] = iv
    return out


def resolve_llm_model_context_window_tokens(
    llm: LLMConfig, model_id: str
) -> int | None:
    """按配置表解析某模型 id 的上下文窗；无表项时返回 ``None``。"""
    m = (model_id or "").strip()
    if not m:
        return None
    table = llm.model_context_tokens or {}
    if not table:
        return None
    if m in table:
        v = table[m]
        return int(v) if v > 0 else None
    ml = m.lower()
    for tk, tv in table.items():
        if str(tk).strip().lower() == ml:
            return int(tv) if tv > 0 else None
    fallback = table.get("default")
    if fallback is None:
        fallback = table.get("*")
    if fallback is not None and str(fallback).strip() != "":
        iv = int(fallback)
        return iv if iv > 0 else None
    return None


def _normalize_proto(raw: str, legacy_provider: str) -> str:
    p = (raw or "").strip().lower()
    if p in VALID_PROTOS:
        return p
    leg = (legacy_provider or "").strip().lower()
    if "dashscope" in leg or "dash_scope" in leg:
        return PROTO_DASHSCOPE
    if "ollama" in leg:
        return PROTO_OLLAMA
    return PROTO_OPENAI


def _llm_fields_from_mapping(llm_raw: dict[str, Any]) -> dict[str, Any]:
    base_url = str(
        llm_raw.get("baseUrl")
        or llm_raw.get("base_url")
        or llm_raw.get("url")
        or ""
    ).strip()
    api_key = str(
        llm_raw.get("apiKey") or llm_raw.get("api_key") or llm_raw.get("key") or ""
    ).strip()
    model = str(
        llm_raw.get("modelId")
        or llm_raw.get("model_id")
        or llm_raw.get("model")
        or "gpt-4o-mini"
    ).strip()
    vm = llm_raw.get("visionModel") or llm_raw.get("vision_model")
    vision_model = str(vm).strip() if vm not in (None, "") else None
    if "supportsVision" in llm_raw:
        sv = llm_raw.get("supportsVision")
    elif "supports_vision" in llm_raw:
        sv = llm_raw.get("supports_vision")
    else:
        sv = None
    supports_vision = parse_supports_vision_bool(sv, default=True)
    proto = _normalize_proto(
        str(llm_raw.get("proto") or llm_raw.get("PROTO") or ""),
        str(llm_raw.get("provider") or ""),
    )
    timeout = llm_raw.get("timeoutSec")
    if timeout is None:
        timeout = llm_raw.get("timeout_sec")
    timeout_sec = float(timeout if timeout is not None else 120.0)

    def _f(name_camel: str, name_snake: str) -> float | None:
        v = llm_raw.get(name_camel)
        if v is None:
            v = llm_raw.get(name_snake)
        if v is None or v == "":
            return None
        return float(v)

    def _i(name_camel: str, name_snake: str) -> int | None:
        v = llm_raw.get(name_camel)
        if v is None:
            v = llm_raw.get(name_snake)
        if v is None or v == "":
            return None
        return int(v)

    extra = llm_raw.get("extraBody") or llm_raw.get("extra_body")
    extra_body = dict(extra) if isinstance(extra, dict) else {}

    mr = llm_raw.get("maxRetries") if llm_raw.get("maxRetries") is not None else llm_raw.get("max_retries")
    max_retries = int(mr) if mr is not None and str(mr).strip() != "" else 3
    max_retries = max(0, min(20, max_retries))

    rbd = (
        llm_raw.get("retryBaseDelaySec")
        if llm_raw.get("retryBaseDelaySec") is not None
        else llm_raw.get("retry_base_delay_sec")
    )
    retry_base_delay_sec = (
        float(rbd) if rbd is not None and str(rbd).strip() != "" else 1.0
    )
    if retry_base_delay_sec <= 0:
        retry_base_delay_sec = 0.1

    mct_raw = llm_raw.get("modelContextTokens") or llm_raw.get(
        "model_context_tokens"
    )
    model_context_tokens = normalize_model_context_tokens_map(mct_raw)

    return {
        "proto": proto,
        "base_url": base_url,
        "api_key": api_key,
        "model": model,
        "timeout_sec": timeout_sec,
        "temperature": _f("temperature", "temperature"),
        "top_p": _f("topP", "top_p"),
        "frequency_penalty": _f("frequencyPenalty", "frequency_penalty"),
        "presence_penalty": _f("presencePenalty", "presence_penalty"),
        "max_output_tokens": _i("maxOutputTokens", "max_output_tokens"),
        "repetition_penalty": _f("repetitionPenalty", "repetition_penalty"),
        "extra_body": extra_body,
        "vision_model": vision_model,
        "supports_vision": supports_vision,
        "max_retries": max_retries,
        "retry_base_delay_sec": retry_base_delay_sec,
        "model_context_tokens": model_context_tokens,
    }


def _normalize_boot_plugin_mode(raw: str) -> str:
    m = (raw or "full").strip().lower()
    if m in ("full", "safe", "inherit"):
        return m
    return "full"


def _plugins_fields_from_mapping(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    out: dict[str, Any] = {}
    aph = raw.get("allowPythonHandlers")
    if aph is None:
        aph = raw.get("allow_python_handlers")
    if aph is not None:
        out["allow_python_handlers"] = bool(aph)
    mx = raw.get("maxPlugins")
    if mx is None:
        mx = raw.get("max_plugins")
    if mx is not None:
        out["max_plugins"] = int(mx)
    bk = raw.get("backupKeep")
    if bk is None:
        bk = raw.get("backup_keep")
    if bk is not None:
        out["backup_keep"] = int(bk)
    lr = raw.get("logRetentionDays")
    if lr is None:
        lr = raw.get("log_retention_days")
    if lr is not None:
        out["log_retention_days"] = int(lr)
    return out




def _parse_vision_token_budget_override(raw: Any) -> int | None:
    if raw is None or str(raw).strip().lower() in ("", "null", "none"):
        return None
    try:
        v = int(raw)
    except (TypeError, ValueError):
        return None
    if v <= 0:
        return None
    return max(2000, min(32_000, v))


def _normalize_agent_default_work_mode(raw: Any) -> str:
    """``agent.default_work_mode``：须为内置工作模式键，非法时回退 ``general``。"""
    from aicd.tui_prefs import WORK_MODE_CANONICAL_MODES

    m = (str(raw or "general").strip().lower()) or "general"
    return m if m in WORK_MODE_CANONICAL_MODES else "general"


def _agent_fields_from_mapping(agent_raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(agent_raw, dict):
        return {}
    mr = agent_raw.get("maxToolRounds")
    if mr is None:
        mr = agent_raw.get("max_tool_rounds")
    sr = agent_raw.get("subAgentMaxToolRounds")
    if sr is None:
        sr = agent_raw.get("sub_agent_max_tool_rounds")
    out: dict[str, Any] = {}
    if mr is not None:
        out["max_tool_rounds"] = int(mr)
    if sr is not None:
        out["sub_agent_max_tool_rounds"] = int(sr)
    cb = agent_raw.get("contextBudgetTokens")
    if cb is None:
        cb = agent_raw.get("context_budget_tokens")
    if cb is not None:
        out["context_budget_tokens"] = int(cb)
    hm = agent_raw.get("chatHistoryMaxMessages")
    if hm is None:
        hm = agent_raw.get("chat_history_max_messages")
    if hm is not None:
        out["chat_history_max_messages"] = int(hm)
    hr = agent_raw.get("chatHistoryRecentFullRows")
    if hr is None:
        hr = agent_raw.get("chat_history_recent_full_rows")
    if hr is not None:
        out["chat_history_recent_full_rows"] = int(hr)
    ih = agent_raw.get("idleHeartbeatSec")
    if ih is None:
        ih = agent_raw.get("idle_heartbeat_sec")
    if ih is not None:
        out["idle_heartbeat_sec"] = int(ih)
    sah = agent_raw.get("subAgentIdleHeartbeatSec")
    if sah is None:
        sah = agent_raw.get("sub_agent_idle_heartbeat_sec")
    if sah is not None:
        out["sub_agent_idle_heartbeat_sec"] = int(sah)
    lc = agent_raw.get("lifecycleCoalesceSec")
    if lc is None:
        lc = agent_raw.get("lifecycle_coalesce_sec")
    if lc is not None and str(lc).strip() != "":
        out["lifecycle_coalesce_sec"] = float(lc)
    ben = agent_raw.get("blockExternalNetwork")
    if ben is None:
        ben = agent_raw.get("block_external_network")
    if ben is not None and str(ben).strip() != "":
        out["block_external_network"] = bool(ben)
    ipi = agent_raw.get("interactiveProcessIdleSec")
    if ipi is None:
        ipi = agent_raw.get("interactive_process_idle_sec")
    if ipi is not None and str(ipi).strip() != "":
        out["interactive_process_idle_sec"] = float(ipi)
    vit = agent_raw.get("visionImageTokenBudgetPerImage")
    if vit is None:
        vit = agent_raw.get("vision_image_token_budget_per_image")
    vb = _parse_vision_token_budget_override(vit)
    if vb is not None:
        out["vision_image_token_budget_per_image"] = vb
    swc = agent_raw.get("startupWorkspaceFromCwd")
    if swc is None:
        swc = agent_raw.get("startup_workspace_from_cwd")
    if swc is not None and str(swc).strip() != "":
        out["startup_workspace_from_cwd"] = bool(swc)
    dwm = agent_raw.get("defaultWorkMode")
    if dwm is None:
        dwm = agent_raw.get("default_work_mode")
    if dwm is not None and str(dwm).strip() != "":
        out["default_work_mode"] = str(dwm).strip().lower()
    return out


def effective_llm_config(cfg: LLMConfig) -> LLMConfig:
    """按 proto 补全默认 base_url / 占位 api_key，供 OpenAI 兼容客户端使用。"""
    out = copy(cfg)
    proto = out.proto.strip().lower()
    if proto not in VALID_PROTOS:
        proto = PROTO_OPENAI
    out.proto = proto
    base = (out.base_url or "").strip().rstrip("/")
    key = out.api_key or ""
    if proto == PROTO_OPENAI:
        if not base:
            base = _DEFAULT_OPENAI_BASE
    elif proto == PROTO_DASHSCOPE:
        if not base:
            base = _DEFAULT_DASHSCOPE_BASE
    elif proto == PROTO_OLLAMA:
        if not base:
            base = _DEFAULT_OLLAMA_BASE
        if not key:
            key = "ollama"
    out.base_url = base
    out.api_key = key
    return out


def _default_allowed_roots() -> list[str]:
    return [str(Path.home()), "."]


@dataclass
class PathPolicyConfig:
    full_disk: bool = True
    allowed_roots: list[str] = field(default_factory=_default_allowed_roots)
    max_read_bytes: int = 2_000_000
    max_search_file_bytes: int = 5_000_000


@dataclass
class PluginsConfig:
    """HOME/plugins 扩展：可选 Python 处理器、数量与备份保留策略。"""

    allow_python_handlers: bool = False
    max_plugins: int = 64
    backup_keep: int = 20
    # 各插件目录下 logs/*.log 保留天数（按 UTC 日期分文件）
    log_retention_days: int = 7
    # 启动时是否加载插件：full=常规；safe=永不自动加载；inherit=看 AICD_PLUGIN_POLICY 与嵌套
    boot_plugin_mode: str = "full"
    # 嵌套调用深度告警上限（超过仍允许启动，但 session_log 记录；spawn/host 可据此拒绝）
    max_invocation_depth: int = 8
    # 是否允许插件文档中描述的「再启动 Aicd 子进程」能力（具体 spawn 由工具或 Host 实现检查）
    allow_nested_aicd_from_plugins: bool = False


@dataclass
class WebFetchIntegrationConfig:
    """联网抓取默认值（**web_fetch** 工具）；正文抽取依赖可选包 trafilatura。"""

    # 空串则由运行时拼 ``AICD/<version>``
    user_agent: str = ""
    max_response_bytes: int = 1_500_000
    default_timeout_sec: float = 45.0


@dataclass
class GitHubIntegrationConfig:
    """GitHub REST（**github_api**）；``token`` 可用环境变量 GITHUB_TOKEN / GH_TOKEN 覆盖。"""

    api_base_url: str = "https://api.github.com"
    token: str = ""
    accept: str = "application/vnd.github+json"


@dataclass
class GoogleCseSearchConfig:
    """Google Programmable Search Engine（Custom Search JSON API）；需 **apiKey** + **cx**。"""

    enabled: bool = False
    api_key: str = ""
    cx: str = ""


@dataclass
class BingWebSearchConfig:
    """Azure Bing Web Search API v7。"""

    enabled: bool = False
    subscription_key: str = ""
    endpoint: str = "https://api.bing.microsoft.com/v7.0/search"


@dataclass
class GitHubSearchConfig:
    """专用 **search_github** 工具开关；凭据沿用 **integrations.github**（或 **GITHUB_TOKEN**）。"""

    enabled: bool = False


@dataclass
class GitLabSearchConfig:
    """GitLab **GET /api/v4/search**；自建实例可改 **baseUrl**。"""

    enabled: bool = False
    base_url: str = "https://gitlab.com"
    private_token: str = ""


@dataclass
class IntegrationsConfig:
    web_fetch: WebFetchIntegrationConfig = field(
        default_factory=WebFetchIntegrationConfig
    )
    github: GitHubIntegrationConfig = field(default_factory=GitHubIntegrationConfig)
    google_cse_search: GoogleCseSearchConfig = field(
        default_factory=GoogleCseSearchConfig
    )
    bing_web_search: BingWebSearchConfig = field(
        default_factory=BingWebSearchConfig
    )
    github_search: GitHubSearchConfig = field(default_factory=GitHubSearchConfig)
    gitlab_search: GitLabSearchConfig = field(default_factory=GitLabSearchConfig)


def _integrations_fields_from_mapping(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    wf_raw = raw.get("webFetch") or raw.get("web_fetch") or {}
    gh_raw = raw.get("github") or {}
    out: dict[str, Any] = {}
    if isinstance(wf_raw, dict):
        ua = wf_raw.get("userAgent") or wf_raw.get("user_agent")
        if ua is not None:
            out["web_user_agent"] = str(ua).strip()
        mrb = wf_raw.get("maxResponseBytes")
        if mrb is None:
            mrb = wf_raw.get("max_response_bytes")
        if mrb is not None:
            out["web_max_response_bytes"] = int(mrb)
        dts = wf_raw.get("defaultTimeoutSec")
        if dts is None:
            dts = wf_raw.get("default_timeout_sec")
        if dts is not None:
            out["web_default_timeout_sec"] = float(dts)
    if isinstance(gh_raw, dict):
        bu = gh_raw.get("apiBaseUrl") or gh_raw.get("api_base_url")
        if bu is not None:
            out["gh_api_base_url"] = str(bu).strip().rstrip("/")
        tok = gh_raw.get("token") or gh_raw.get("apiToken") or gh_raw.get("api_token")
        if tok is not None:
            out["gh_token"] = str(tok).strip()
        acc = gh_raw.get("accept")
        if acc is not None:
            out["gh_accept"] = str(acc).strip()
    return out


def _search_integration_configs_from_dict(
    integrations_raw: dict[str, Any],
) -> tuple[
    GoogleCseSearchConfig,
    BingWebSearchConfig,
    GitHubSearchConfig,
    GitLabSearchConfig,
]:
    """解析 ``integrations`` 下的可选搜索 API 小节（camelCase / snake_case）。"""

    def _sub(*keys: str) -> dict[str, Any]:
        for k in keys:
            v = integrations_raw.get(k)
            if isinstance(v, dict):
                return v
        return {}

    g = _sub("googleCseSearch", "google_cse_search")
    google_cse = GoogleCseSearchConfig(
        enabled=bool(g.get("enabled")),
        api_key=str(g.get("apiKey") or g.get("api_key") or "").strip(),
        cx=str(g.get("cx") or g.get("searchEngineId") or "").strip(),
    )
    b = _sub("bingWebSearch", "bing_web_search")
    b_ep = str(
        b.get("endpoint")
        or b.get("endpointUrl")
        or "https://api.bing.microsoft.com/v7.0/search"
    ).strip()
    if not b_ep.startswith("http"):
        b_ep = "https://api.bing.microsoft.com/v7.0/search"
    bing = BingWebSearchConfig(
        enabled=bool(b.get("enabled")),
        subscription_key=str(
            b.get("subscriptionKey") or b.get("subscription_key") or ""
        ).strip(),
        endpoint=b_ep.rstrip("/"),
    )
    gh = _sub("githubSearch", "github_search")
    github_search = GitHubSearchConfig(enabled=bool(gh.get("enabled")))
    gl = _sub("gitlabSearch", "gitlab_search")
    gl_base = str(gl.get("baseUrl") or gl.get("base_url") or "https://gitlab.com").strip().rstrip(
        "/"
    )
    if not gl_base.startswith("http"):
        gl_base = "https://gitlab.com"
    gitlab_search = GitLabSearchConfig(
        enabled=bool(gl.get("enabled")),
        base_url=gl_base,
        private_token=str(
            gl.get("privateToken") or gl.get("private_token") or ""
        ).strip(),
    )
    return google_cse, bing, github_search, gitlab_search


@dataclass
class AppConfig:
    llm: LLMConfig = field(default_factory=LLMConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    paths: PathPolicyConfig = field(default_factory=PathPolicyConfig)
    plugins: PluginsConfig = field(default_factory=PluginsConfig)
    integrations: IntegrationsConfig = field(default_factory=IntegrationsConfig)
    config_version: int = CURRENT_CONFIG_VERSION
    llm_profiles: list[LLMProfile] = field(default_factory=list)
    active_llm_profile: str = "default"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AppConfig:
        llm_raw = data.get("llm") or {}
        profiles_in = _profiles_from_dict_list(
            data.get("llmProfiles") or data.get("llm_profiles")
        )
        active_name = str(
            data.get("activeLlmProfile") or data.get("active_llm_profile") or "default"
        ).strip() or "default"
        cv = int(
            data.get("configVersion") or data.get("config_version") or CURRENT_CONFIG_VERSION
        )
        agent_raw = data.get("agent") or {}
        paths_raw = data.get("paths") or {}
        plugins_raw = data.get("plugins") or {}
        integrations_raw = data.get("integrations") or {}
        integ_raw = integrations_raw if isinstance(integrations_raw, dict) else {}
        gcse_cfg, bing_cfg, gh_search_cfg, gl_search_cfg = (
            _search_integration_configs_from_dict(integ_raw)
        )
        default_paths = PathPolicyConfig()
        default_agent = AgentConfig()
        default_plugins = PluginsConfig()
        default_web = WebFetchIntegrationConfig()
        default_gh = GitHubIntegrationConfig()
        roots = paths_raw.get("allowed_roots")
        if not roots:
            roots = default_paths.allowed_roots
        lf = _llm_fields_from_mapping(llm_raw if isinstance(llm_raw, dict) else {})
        profiles = profiles_in
        if not profiles:
            profiles = [_synth_profile_from_llm_fields(lf, "default")]
            active_name = "default"
        af = _agent_fields_from_mapping(
            agent_raw if isinstance(agent_raw, dict) else {}
        )
        pf = _plugins_fields_from_mapping(
            plugins_raw if isinstance(plugins_raw, dict) else {}
        )
        intf = _integrations_fields_from_mapping(
            integrations_raw if isinstance(integrations_raw, dict) else {}
        )
        cfg = cls(
            llm=LLMConfig(
                proto=str(lf["proto"]),
                base_url=str(lf["base_url"]),
                api_key=str(lf["api_key"]),
                model=str(lf["model"]),
                vision_model=lf.get("vision_model"),
                supports_vision=bool(lf.get("supports_vision", True)),
                timeout_sec=float(lf["timeout_sec"]),
                temperature=lf.get("temperature"),
                top_p=lf.get("top_p"),
                frequency_penalty=lf.get("frequency_penalty"),
                presence_penalty=lf.get("presence_penalty"),
                max_output_tokens=lf.get("max_output_tokens"),
                repetition_penalty=lf.get("repetition_penalty"),
                extra_body=dict(lf.get("extra_body") or {}),
                max_retries=max(
                    0,
                    min(20, int(lf.get("max_retries", 3))),
                ),
                retry_base_delay_sec=max(
                    0.1,
                    float(lf.get("retry_base_delay_sec", 1.0)),
                ),
                model_context_tokens=dict(
                    lf.get("model_context_tokens") or {}
                ),
            ),
            agent=AgentConfig(
                max_tool_rounds=max(
                    1,
                    min(
                        MAX_AGENT_TOOL_ROUNDS,
                        int(af.get("max_tool_rounds", default_agent.max_tool_rounds)),
                    ),
                ),
                sub_agent_max_tool_rounds=max(
                    1,
                    min(
                        MAX_AGENT_TOOL_ROUNDS,
                        int(
                            af.get(
                                "sub_agent_max_tool_rounds",
                                default_agent.sub_agent_max_tool_rounds,
                            )
                        ),
                    ),
                ),
                context_budget_tokens=max(
                    4096,
                    min(
                        2_000_000,
                        int(
                            af.get(
                                "context_budget_tokens",
                                default_agent.context_budget_tokens,
                            )
                        ),
                    ),
                ),
                chat_history_max_messages=max(
                    10,
                    min(
                        20_000,
                        int(
                            af.get(
                                "chat_history_max_messages",
                                default_agent.chat_history_max_messages,
                            )
                        ),
                    ),
                ),
                chat_history_recent_full_rows=max(
                    4,
                    min(
                        2000,
                        int(
                            af.get(
                                "chat_history_recent_full_rows",
                                default_agent.chat_history_recent_full_rows,
                            )
                        ),
                    ),
                ),
                idle_heartbeat_sec=max(
                    0,
                    min(
                        3600,
                        int(af.get("idle_heartbeat_sec", default_agent.idle_heartbeat_sec)),
                    ),
                ),
                sub_agent_idle_heartbeat_sec=max(
                    0,
                    min(
                        3600,
                        int(
                            af.get(
                                "sub_agent_idle_heartbeat_sec",
                                default_agent.sub_agent_idle_heartbeat_sec,
                            )
                        ),
                    ),
                ),
                lifecycle_coalesce_sec=max(
                    0.0,
                    min(
                        3.0,
                        float(
                            af.get(
                                "lifecycle_coalesce_sec",
                                default_agent.lifecycle_coalesce_sec,
                            )
                        ),
                    ),
                ),
                block_external_network=bool(
                    af.get(
                        "block_external_network",
                        default_agent.block_external_network,
                    )
                ),
                interactive_process_idle_sec=max(
                    0.0,
                    min(
                        86_400.0,
                        float(
                            af.get(
                                "interactive_process_idle_sec",
                                default_agent.interactive_process_idle_sec,
                            )
                        ),
                    ),
                ),
                vision_image_token_budget_per_image=(
                    int(af["vision_image_token_budget_per_image"])
                    if "vision_image_token_budget_per_image" in af
                    else default_agent.vision_image_token_budget_per_image
                ),
                startup_workspace_from_cwd=bool(
                    af.get(
                        "startup_workspace_from_cwd",
                        default_agent.startup_workspace_from_cwd,
                    )
                ),
                default_work_mode=_normalize_agent_default_work_mode(
                    af.get("default_work_mode", default_agent.default_work_mode)
                ),
            ),
            paths=PathPolicyConfig(
                full_disk=bool(paths_raw.get("full_disk", True)),
                allowed_roots=list(roots),
                max_read_bytes=int(
                    paths_raw.get("max_read_bytes", default_paths.max_read_bytes)
                ),
                max_search_file_bytes=int(
                    paths_raw.get(
                        "max_search_file_bytes", default_paths.max_search_file_bytes
                    )
                ),
            ),
            plugins=PluginsConfig(
                allow_python_handlers=bool(
                    pf.get("allow_python_handlers", default_plugins.allow_python_handlers)
                ),
                max_plugins=max(
                    1,
                    min(500, int(pf.get("max_plugins", default_plugins.max_plugins))),
                ),
                backup_keep=max(
                    1,
                    min(500, int(pf.get("backup_keep", default_plugins.backup_keep))),
                ),
                log_retention_days=max(
                    1,
                    min(
                        90,
                        int(
                            pf.get(
                                "log_retention_days",
                                default_plugins.log_retention_days,
                            )
                        ),
                    ),
                ),
                boot_plugin_mode=_normalize_boot_plugin_mode(
                    str(
                        pf.get("boot_plugin_mode", default_plugins.boot_plugin_mode)
                        or "full"
                    )
                ),
                max_invocation_depth=max(
                    0,
                    min(
                        100,
                        int(
                            pf.get(
                                "max_invocation_depth",
                                default_plugins.max_invocation_depth,
                            )
                        ),
                    ),
                ),
                allow_nested_aicd_from_plugins=bool(
                    pf.get(
                        "allow_nested_aicd_from_plugins",
                        default_plugins.allow_nested_aicd_from_plugins,
                    )
                ),
            ),
            config_version=cv,
            llm_profiles=profiles,
            active_llm_profile=active_name,
            integrations=IntegrationsConfig(
                web_fetch=WebFetchIntegrationConfig(
                    user_agent=str(
                        intf.get("web_user_agent", default_web.user_agent) or ""
                    ),
                    max_response_bytes=max(
                        4096,
                        min(
                            8_000_000,
                            int(
                                intf.get(
                                    "web_max_response_bytes",
                                    default_web.max_response_bytes,
                                )
                            ),
                        ),
                    ),
                    default_timeout_sec=max(
                        5.0,
                        min(
                            600.0,
                            float(
                                intf.get(
                                    "web_default_timeout_sec",
                                    default_web.default_timeout_sec,
                                )
                            ),
                        ),
                    ),
                ),
                github=GitHubIntegrationConfig(
                    api_base_url=str(
                        intf.get("gh_api_base_url", default_gh.api_base_url)
                        or default_gh.api_base_url
                    ).rstrip("/"),
                    token=str(intf.get("gh_token", default_gh.token) or ""),
                    accept=str(intf.get("gh_accept", default_gh.accept) or default_gh.accept),
                ),
                google_cse_search=gcse_cfg,
                bing_web_search=bing_cfg,
                github_search=gh_search_cfg,
                gitlab_search=gl_search_cfg,
            ),
        )
        apply_active_profile_to_llm(cfg)
        return cfg

    def to_dict(self) -> dict[str, Any]:
        llm_d: dict[str, Any] = {
            "proto": self.llm.proto,
            "baseUrl": self.llm.base_url,
            "apiKey": self.llm.api_key,
            "modelId": self.llm.model,
            "timeoutSec": self.llm.timeout_sec,
        }
        if self.llm.temperature is not None:
            llm_d["temperature"] = self.llm.temperature
        if self.llm.top_p is not None:
            llm_d["topP"] = self.llm.top_p
        if self.llm.frequency_penalty is not None:
            llm_d["frequencyPenalty"] = self.llm.frequency_penalty
        if self.llm.presence_penalty is not None:
            llm_d["presencePenalty"] = self.llm.presence_penalty
        if self.llm.max_output_tokens is not None:
            llm_d["maxOutputTokens"] = self.llm.max_output_tokens
        if self.llm.repetition_penalty is not None:
            llm_d["repetitionPenalty"] = self.llm.repetition_penalty
        if self.llm.extra_body:
            llm_d["extraBody"] = dict(self.llm.extra_body)
        if self.llm.vision_model:
            llm_d["visionModel"] = self.llm.vision_model
        if not self.llm.supports_vision:
            llm_d["supportsVision"] = False
        if self.llm.max_retries != 3:
            llm_d["maxRetries"] = self.llm.max_retries
        if self.llm.retry_base_delay_sec != 1.0:
            llm_d["retryBaseDelaySec"] = self.llm.retry_base_delay_sec
        if self.llm.model_context_tokens:
            llm_d["modelContextTokens"] = dict(self.llm.model_context_tokens)
        agent_d: dict[str, Any] = {
            "maxToolRounds": self.agent.max_tool_rounds,
            "subAgentMaxToolRounds": self.agent.sub_agent_max_tool_rounds,
            "contextBudgetTokens": self.agent.context_budget_tokens,
            "chatHistoryMaxMessages": self.agent.chat_history_max_messages,
            "chatHistoryRecentFullRows": self.agent.chat_history_recent_full_rows,
            "idleHeartbeatSec": self.agent.idle_heartbeat_sec,
            "subAgentIdleHeartbeatSec": self.agent.sub_agent_idle_heartbeat_sec,
            "lifecycleCoalesceSec": self.agent.lifecycle_coalesce_sec,
        }
        if self.agent.block_external_network:
            agent_d["blockExternalNetwork"] = True
        if self.agent.interactive_process_idle_sec > 0:
            agent_d["interactiveProcessIdleSec"] = float(
                self.agent.interactive_process_idle_sec
            )
        if self.agent.vision_image_token_budget_per_image is not None:
            agent_d["visionImageTokenBudgetPerImage"] = int(
                self.agent.vision_image_token_budget_per_image
            )
        if self.agent.startup_workspace_from_cwd:
            agent_d["startupWorkspaceFromCwd"] = True
        if self.agent.default_work_mode != "general":
            agent_d["defaultWorkMode"] = self.agent.default_work_mode
        profs = [p.to_mapping() for p in self.llm_profiles]
        return {
            "configVersion": CURRENT_CONFIG_VERSION,
            "activeLlmProfile": self.active_llm_profile,
            "llmProfiles": profs,
            "llm": llm_d,
            "agent": agent_d,
            "paths": {
                "full_disk": self.paths.full_disk,
                "allowed_roots": self.paths.allowed_roots,
                "max_read_bytes": self.paths.max_read_bytes,
                "max_search_file_bytes": self.paths.max_search_file_bytes,
            },
            "plugins": {
                "allowPythonHandlers": self.plugins.allow_python_handlers,
                "maxPlugins": self.plugins.max_plugins,
                "backupKeep": self.plugins.backup_keep,
                "logRetentionDays": self.plugins.log_retention_days,
                "bootPluginMode": self.plugins.boot_plugin_mode,
                "maxInvocationDepth": self.plugins.max_invocation_depth,
                "allowNestedAicdFromPlugins": self.plugins.allow_nested_aicd_from_plugins,
            },
            "integrations": {
                "webFetch": {
                    "userAgent": self.integrations.web_fetch.user_agent,
                    "maxResponseBytes": self.integrations.web_fetch.max_response_bytes,
                    "defaultTimeoutSec": self.integrations.web_fetch.default_timeout_sec,
                },
                "github": {
                    "apiBaseUrl": self.integrations.github.api_base_url,
                    "token": self.integrations.github.token,
                    "accept": self.integrations.github.accept,
                },
                "googleCseSearch": {
                    "enabled": self.integrations.google_cse_search.enabled,
                    "apiKey": self.integrations.google_cse_search.api_key,
                    "cx": self.integrations.google_cse_search.cx,
                },
                "bingWebSearch": {
                    "enabled": self.integrations.bing_web_search.enabled,
                    "subscriptionKey": self.integrations.bing_web_search.subscription_key,
                    "endpoint": self.integrations.bing_web_search.endpoint,
                },
                "githubSearch": {
                    "enabled": self.integrations.github_search.enabled,
                },
                "gitlabSearch": {
                    "enabled": self.integrations.gitlab_search.enabled,
                    "baseUrl": self.integrations.gitlab_search.base_url,
                    "privateToken": self.integrations.gitlab_search.private_token,
                },
            },
        }


def load_config(path: Path) -> AppConfig:
    if not path.is_file():
        return AppConfig.from_dict(migrate_config_dict({}))
    with path.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    if not isinstance(raw, dict):
        raw = {}
    raw = migrate_config_dict(raw)
    return AppConfig.from_dict(raw)


def deep_merge_missing_keys(dst: dict[str, Any], defaults: dict[str, Any]) -> bool:
    """仅补缺失键；已有键（含显式 ``0``、空串）不覆盖。嵌套 dict 递归补子键。"""
    changed = False
    for k, v in defaults.items():
        if k not in dst:
            dst[k] = copy_mod.deepcopy(v)
            changed = True
        elif isinstance(v, dict) and isinstance(dst.get(k), dict):
            if deep_merge_missing_keys(dst[k], v):
                changed = True
        elif isinstance(v, dict) and not isinstance(dst.get(k), dict):
            dst[k] = copy_mod.deepcopy(v)
            changed = True
    return changed


def apply_missing_config_defaults_to_file(path: Path) -> AppConfig:
    """
    将当前代码向量的默认 ``AppConfig.to_dict()`` 与磁盘 YAML 合并后写回。
    用于旧配置自动获得新增节（如 **integrations**）及嵌套默认值。
    """
    fresh = AppConfig()
    if not path.is_file():
        save_config(path, fresh)
        return fresh
    with path.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    if not isinstance(raw, dict):
        raw = {}
    raw = migrate_config_dict(raw)
    default_dict = fresh.to_dict()
    if deep_merge_missing_keys(raw, default_dict):
        merged = AppConfig.from_dict(raw)
        save_config(path, merged)
        return merged
    return AppConfig.from_dict(raw)


def apply_agent_heartbeat_defaults_to_config_file(path: Path, cfg: AppConfig) -> AppConfig:
    """若 ``config.yaml`` 缺字段则补默认。现与 ``apply_missing_config_defaults_to_file`` 统一（全量模式）。"""
    _ = cfg
    return apply_missing_config_defaults_to_file(path)


def save_config(path: Path, cfg: AppConfig) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    sync_active_profile_from_llm(cfg)
    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(cfg.to_dict(), f, allow_unicode=True, sort_keys=False)
