"""从页面 HTML 提取主文（BeautifulSoup；可选 lxml 解析器）。"""

from __future__ import annotations

import re
from typing import Any

# 与 dismiss_overlays 的 JS 对齐，在静态 HTML 上再剥一层常见遮罩/弹窗根节点
_OVERLAY_SELECTORS = (
    '[role="dialog"]',
    '[role="alertdialog"]',
    ".modal",
    ".modal-backdrop",
    '[class*="cookie-banner"]',
    '[id*="cookie-banner"]',
    '[class*="consent-banner"]',
    '[class*="popup-overlay"]',
    ".ReactModal__Overlay",
)


def _parse_soup(html: str):
    from bs4 import BeautifulSoup

    try:
        return BeautifulSoup(html, "lxml")
    except Exception:
        return BeautifulSoup(html, "html.parser")


def _strip_boilerplate(soup: Any) -> None:
    for tag in soup(["script", "style", "noscript", "template", "svg"]):
        tag.decompose()
    for sel in _OVERLAY_SELECTORS:
        try:
            for node in soup.select(sel):
                node.decompose()
        except Exception:
            continue
    for tag in soup(["nav", "footer", "aside"]):
        tag.decompose()


def _pick_main_root(soup: Any) -> Any:
    for sel in (
        "main",
        "article",
        '[role="main"]',
        "#content",
        "#main",
        ".main-content",
        ".article-body",
        ".post-content",
    ):
        found = soup.select_one(sel)
        if found:
            return found
    return soup.body or soup


def _normalize_text(text: str) -> str:
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_main_text_from_html(
    html: str,
    *,
    max_chars: int = 200_000,
) -> dict[str, Any]:
    """
    从整页 HTML 提取可读主文（非截图 OCR）。

    依赖 **beautifulsoup4**；若已安装 **lxml** 则优先用作解析器。
    """
    if not (html or "").strip():
        return {"ok": False, "error": "empty html"}
    try:
        soup = _parse_soup(html)
    except ImportError as e:
        return {
            "ok": False,
            "error": f"beautifulsoup4 required: {e}",
            "hint": "pip install beautifulsoup4",
        }
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"parse failed: {e}"}

    _strip_boilerplate(soup)
    root = _pick_main_root(soup)
    if root is None:
        text = soup.get_text("\n", strip=True)
    else:
        text = root.get_text("\n", strip=True)
    text = _normalize_text(text)
    raw_len = len(text)
    truncated = raw_len > max_chars
    if truncated:
        text = text[:max_chars]
    return {
        "ok": True,
        "text": text,
        "chars": raw_len,
        "truncated": truncated,
    }
