"""Playwright 多步 UI 自动化：导航、点击、输入、截图等（单次浏览器会话）。"""

from __future__ import annotations

import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import unquote, urlparse

from aicd.network_policy import outbound_tool_url_blocked_reason
from aicd.tools.html_dom_extract import extract_main_text_from_html

_DISMISS_OVERLAYS_JS = """() => {
  const selectors = [
    '[role="dialog"]', '[role="alertdialog"]',
    '.modal', '.modal-backdrop',
    '[class*="cookie-banner"]', '[id*="cookie"]',
    '[class*="consent-banner"]', '[class*="consent"]',
    '[class*="popup-overlay"]',
    '.ReactModal__Overlay',
    'iframe[src*="consent"]', 'iframe[src*="cookie"]'
  ];
  selectors.forEach((sel) => {
    try {
      document.querySelectorAll(sel).forEach((el) => {
        try { el.remove(); } catch (e) {}
      });
    } catch (e) {}
  });
}"""

MAX_AUTOMATION_STEPS = 40
MAX_TEXT_FIELD_CHARS = 32_000
_WAIT_UNTIL = frozenset({"commit", "domcontentloaded", "load", "networkidle"})
_LOC_STATES = frozenset({"attached", "detached", "hidden", "visible"})

_KNOWN_BROWSER_CHANNELS = frozenset(
    {
        "chrome",
        "chrome-beta",
        "chrome-dev",
        "chrome-canary",
        "msedge",
        "msedge-beta",
        "msedge-dev",
        "msedge-canary",
    }
)


def build_chromium_launch_kwargs(
    *,
    headless: bool,
    slow_mo_ms: int | None,
    browser_channel: str | None = None,
    executable_path: str | None = None,
) -> dict[str, Any]:
    """
    组装 ``chromium.launch`` 参数：默认使用 Playwright 自带 Chromium；
    ``browser_channel`` 使用本机 Chrome/Edge；``executable_path`` 优先。
    """
    kw: dict[str, Any] = {"headless": bool(headless)}
    if slow_mo_ms:
        kw["slow_mo"] = int(slow_mo_ms)
    ex = (executable_path or "").strip()
    if ex:
        kw["executable_path"] = ex
        return kw
    ch = (browser_channel or "").strip().lower()
    if ch in ("", "chromium", "bundled", "playwright", "default"):
        return kw
    if ch not in _KNOWN_BROWSER_CHANNELS:
        raise ValueError(
            f"browser_channel {ch!r} is not in the supported set "
            f"{sorted(_KNOWN_BROWSER_CHANNELS)}; use executable_path for custom browsers"
        )
    kw["channel"] = ch
    return kw


def playwright_chromium_launch_hint(error_message: str) -> str:
    """After ``chromium.launch`` fails: bundled Chromium install vs system browser."""
    msg = error_message.lower()
    if "executable doesn't exist" in msg or "browsertype.launch" in msg:
        return (
            "未找到浏览器：默认 Chromium 请执行 python -m playwright install chromium；"
            "使用 browser_channel=chrome / msedge 时请在本机安装对应浏览器。"
        )
    return "python -m playwright install chromium"


def _blocked_scheme(url: str) -> str | None:
    s = url.strip().lower()
    for bad in ("javascript:", "data:", "vbscript:"):
        if s.startswith(bad):
            return f"blocked URL scheme (not allowed: {bad})"
    return None


def _file_url_to_path(url: str) -> Path:
    pu = urlparse(url.strip())
    if pu.scheme.lower() != "file":
        raise ValueError("not a file: URL")
    path = unquote(pu.path or "")
    if sys.platform == "win32" and path.startswith("/") and len(path) >= 3 and path[2] == ":":
        path = path[1:]
    return Path(path).resolve()


def _check_nav_url(
    url: str,
    policy_check: Callable[[Path], None],
    *,
    block_external_network: bool = False,
) -> str | None:
    bad = _blocked_scheme(url)
    if bad:
        return bad
    u = url.strip()
    low = u.lower()
    if low.startswith("http://") or low.startswith("https://"):
        if block_external_network:
            return outbound_tool_url_blocked_reason(u, block_external=True)
        return None
    if low.startswith("file:"):
        try:
            p = _file_url_to_path(u)
            policy_check(p)
        except Exception as e:  # noqa: BLE001
            return f"file: URL not allowed or invalid: {e}"
        return None
    return None


def _normalize_cdp_endpoint(raw: str) -> str:
    t = (raw or "").strip()
    if not t:
        return ""
    if not t.startswith(("http://", "https://")):
        return "http://" + t
    return t


def default_cdp_endpoint_from_env() -> str:
    """
    工具参数未传 ``cdp_endpoint`` 时，用于连接**用户本机已启动**的 Chrome/Edge（``connect_over_cdp``）。

    读取顺序：**AICD_BROWSER_CDP_ENDPOINT**、**AICD_CHROME_CDP_URL**（兼容别名）。
    设置 **AICD_BROWSER_NO_CDP=1**（或 true/yes/on）则禁用，强制走 Playwright ``launch``。
    """
    v = (os.environ.get("AICD_BROWSER_NO_CDP") or "").strip().lower()
    if v in ("1", "true", "yes", "on"):
        return ""
    for key in ("AICD_BROWSER_CDP_ENDPOINT", "AICD_CHROME_CDP_URL"):
        raw = (os.environ.get(key) or "").strip()
        if raw:
            return _normalize_cdp_endpoint(raw)
    return ""


def _resolve_user_data_dir_path(
    uds: str, cwd: Path, policy_check: Callable[[Path], None]
) -> Path:
    p = Path(uds).expanduser()
    if not p.is_absolute():
        p = (cwd / p).resolve()
    else:
        p = p.resolve()
    policy_check(p.parent)
    return p


async def _execute_browser_steps(
    page: Any,
    *,
    steps: list[dict[str, Any]],
    policy_check: Callable[[Path], None],
    cwd: Path,
    timeout: int,
    block_external_network: bool,
    _resolve_out: Callable[[str], Path],
) -> dict[str, Any]:
    step_results: list[dict[str, Any]] = []
    last_title = ""
    last_url = ""
    page.set_default_timeout(timeout)

    for i, raw in enumerate(steps):
        if not isinstance(raw, dict):
            return {
                "ok": False,
                "error": f"steps[{i}] must be object",
                "step_results": step_results,
                "failed_step_index": i,
            }
        op = str(raw.get("op", "")).strip().lower()
        rec: dict[str, Any] = {"index": i, "op": op}

        try:
            if op == "goto":
                url = str(raw.get("url", "")).strip()
                if not url:
                    raise ValueError("goto requires url")
                err = _check_nav_url(
                    url,
                    policy_check,
                    block_external_network=block_external_network,
                )
                if err:
                    raise ValueError(err)
                wu = str(raw.get("wait_until", "load")).strip().lower()
                if wu not in _WAIT_UNTIL:
                    wu = "load"
                to = int(raw.get("timeout_ms", timeout))
                await page.goto(url, wait_until=wu, timeout=min(to, 600_000))
                last_title = await page.title()
                last_url = page.url
                rec["ok"] = True
                rec["title"] = last_title
                rec["url"] = last_url

            elif op == "wait_for_selector":
                sel = str(raw.get("selector", "")).strip()
                if not sel:
                    raise ValueError("wait_for_selector requires selector")
                st = str(raw.get("state", "visible")).strip().lower()
                if st not in _LOC_STATES:
                    st = "visible"
                to = int(raw.get("timeout_ms", timeout))
                await page.wait_for_selector(sel, state=st, timeout=min(to, 600_000))
                rec["ok"] = True

            elif op in ("click", "dblclick"):
                sel = str(raw.get("selector", "")).strip()
                if not sel:
                    raise ValueError(f"{op} requires selector")
                loc = page.locator(sel).first
                await loc.wait_for(state="visible", timeout=timeout)
                if op == "dblclick":
                    await loc.dblclick(timeout=timeout)
                else:
                    await loc.click(timeout=timeout)
                rec["ok"] = True

            elif op == "hover":
                sel = str(raw.get("selector", "")).strip()
                if not sel:
                    raise ValueError("hover requires selector")
                await page.locator(sel).first.hover(timeout=timeout)
                rec["ok"] = True

            elif op == "fill":
                sel = str(raw.get("selector", "")).strip()
                if not sel:
                    raise ValueError("fill requires selector")
                text = str(raw.get("text", ""))
                if len(text) > MAX_TEXT_FIELD_CHARS:
                    raise ValueError(
                        f"text too long (max {MAX_TEXT_FIELD_CHARS} chars)"
                    )
                await page.locator(sel).first.fill(text, timeout=timeout)
                rec["ok"] = True

            elif op == "type":
                sel = str(raw.get("selector", "")).strip()
                if not sel:
                    raise ValueError("type requires selector")
                text = str(raw.get("text", ""))
                if len(text) > MAX_TEXT_FIELD_CHARS:
                    raise ValueError(
                        f"text too long (max {MAX_TEXT_FIELD_CHARS} chars)"
                    )
                delay = raw.get("delay_ms")
                d = int(delay) if delay is not None else 0
                d = max(0, min(200, d))
                await page.locator(sel).first.type(text, delay=d, timeout=timeout)
                rec["ok"] = True

            elif op == "press":
                key = str(raw.get("key", "")).strip()
                if not key:
                    raise ValueError("press requires key (e.g. Enter, Tab)")
                sel = str(raw.get("selector", "")).strip()
                if sel:
                    await page.locator(sel).first.press(key, timeout=timeout)
                else:
                    await page.keyboard.press(key)
                rec["ok"] = True

            elif op == "wait_ms":
                ms = int(raw.get("ms", 0))
                ms = max(0, min(120_000, ms))
                await page.wait_for_timeout(ms)
                rec["ok"] = True

            elif op == "scroll_into_view":
                sel = str(raw.get("selector", "")).strip()
                if not sel:
                    raise ValueError("scroll_into_view requires selector")
                await page.locator(sel).first.scroll_into_view_if_needed(
                    timeout=timeout
                )
                rec["ok"] = True

            elif op == "screenshot":
                out_s = str(raw.get("path", "")).strip()
                if not out_s:
                    raise ValueError("screenshot requires path (.png)")
                outp = _resolve_out(out_s)
                if outp.suffix.lower() != ".png":
                    raise ValueError("screenshot path must end with .png")
                outp.parent.mkdir(parents=True, exist_ok=True)
                full = bool(raw.get("full_page", False))
                sel = str(raw.get("selector", "")).strip()
                if sel:
                    loc = page.locator(sel).first
                    await loc.wait_for(state="visible", timeout=timeout)
                    await loc.screenshot(path=str(outp), type="png")
                else:
                    await page.screenshot(
                        path=str(outp), full_page=full, type="png"
                    )
                rec["ok"] = True
                rec["png_path"] = str(outp)

            elif op == "get_text":
                sel = str(raw.get("selector", "")).strip()
                if not sel:
                    raise ValueError("get_text requires selector")
                txt = await page.locator(sel).first.inner_text(timeout=timeout)
                rec["ok"] = True
                rec["text"] = (txt or "")[:8000]
                if len(txt or "") > 8000:
                    rec["truncated"] = True

            elif op == "get_attribute":
                sel = str(raw.get("selector", "")).strip()
                name = str(raw.get("name", "")).strip()
                if not sel or not name:
                    raise ValueError("get_attribute requires selector and name")
                v = await page.locator(sel).first.get_attribute(
                    name, timeout=timeout
                )
                rec["ok"] = True
                rec["value"] = v

            elif op == "content_snippet":
                lim = int(raw.get("max_chars", 8000))
                lim = max(500, min(24_000, lim))
                html = await page.content()
                rec["ok"] = True
                rec["html_snippet"] = html[:lim] + (
                    "..." if len(html) > lim else ""
                )

            elif op == "dismiss_overlays":
                await page.evaluate(_DISMISS_OVERLAYS_JS)
                rec["ok"] = True
                rec["note"] = (
                    "已尝试移除常见弹窗/遮罩/cookie 条（启发式，可能误伤）；"
                    "可再使用 press Escape 或 click 关闭特定关闭按钮。"
                )

            elif op == "save_page_html":
                out_s = str(raw.get("path", "")).strip()
                if not out_s:
                    raise ValueError("save_page_html requires path (.html/.htm)")
                outp = _resolve_out(out_s)
                if outp.suffix.lower() not in (".html", ".htm"):
                    raise ValueError("save_page_html path must end with .html or .htm")
                html = await page.content()
                outp.parent.mkdir(parents=True, exist_ok=True)
                outp.write_text(html, encoding="utf-8", newline="\n")
                rec["ok"] = True
                rec["html_path"] = str(outp)
                rec["html_chars"] = len(html)

            elif op == "extract_dom_main":
                html = await page.content()
                max_c = int(raw.get("max_chars", 200_000))
                max_c = max(2_000, min(500_000, max_c))
                ex = extract_main_text_from_html(html, max_chars=max_c)
                if not ex.get("ok"):
                    raise ValueError(ex.get("error", "extract_dom_main failed"))
                text = str(ex.get("text") or "")
                out_s = str(raw.get("path", "")).strip()
                if not out_s:
                    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
                    out_s = str(Path("aicd") / "tmp" / f"browser_dom_{ts}.txt")
                outp = _resolve_out(out_s)
                if outp.suffix.lower() not in (".txt", ".md"):
                    raise ValueError(
                        "extract_dom_main path should end with .txt or .md (or omit path for auto)"
                    )
                outp.parent.mkdir(parents=True, exist_ok=True)
                outp.write_text(text, encoding="utf-8", newline="\n")
                pv = int(raw.get("preview_chars", 6000))
                pv = max(200, min(24_000, pv))
                rec["ok"] = True
                rec["text_path"] = str(outp)
                rec["text_preview"] = text[:pv] + ("..." if len(text) > pv else "")
                rec["chars"] = int(ex.get("chars") or len(text))
                rec["truncated"] = bool(ex.get("truncated"))
                rec["note"] = (
                    "主文已落盘；完整内容见 text_path。长文可交 **task_ai** 摘要后再把要点回主会话。"
                )

            else:
                raise ValueError(
                    f"unknown op {op!r}; use goto, wait_for_selector, click, "
                    "dblclick, hover, fill, type, press, wait_ms, scroll_into_view, "
                    "screenshot, get_text, get_attribute, content_snippet, "
                    "dismiss_overlays, save_page_html, extract_dom_main"
                )

        except Exception as e:  # noqa: BLE001
            rec["ok"] = False
            rec["error"] = str(e)
            step_results.append(rec)
            return {
                "ok": False,
                "error": f"step {i} ({op}): {e}",
                "failed_step_index": i,
                "step_results": step_results,
                "last_title": last_title,
                "last_url": last_url,
            }

        step_results.append(rec)

    last_title = await page.title()
    last_url = page.url
    return {
        "ok": True,
        "step_results": step_results,
        "last_title": last_title,
        "last_url": last_url,
        "note": (
            "网页分析：优先 **extract_dom_main**（BeautifulSoup 主文落盘）与 **save_page_html**，"
            "辅以 **dismiss_overlays** 减少弹窗遮挡；截图仅作辅助。"
            "长文用 **task_ai** 读路径摘要，主会话只接收要点。"
        ),
    }


async def run_browser_automation(
    *,
    steps: list[dict[str, Any]],
    policy_check: Callable[[Path], None],
    cwd: Path,
    default_timeout_ms: int = 60_000,
    headless: bool = True,
    viewport: dict[str, Any] | None = None,
    slow_mo_ms: int | None = None,
    block_external_network: bool = False,
    browser_channel: str | None = None,
    executable_path: str | None = None,
    cdp_endpoint: str | None = None,
    user_data_dir: str | None = None,
    keep_browser_open: bool = False,
) -> dict[str, Any]:
    """
    在同一浏览器会话中顺序执行 ``steps``（Playwright）。

    每步为对象，必填 ``op``（``goto`` / ``click`` / …）。

    * **keep_browser_open**：用户是否希望**任务结束后仍保留窗口**（由对话里说明，经 Agent 传入）。对 **launch** / **persistent**：为真时不调用 ``close()``；为假（默认）则关闭 Playwright 启动的实例。对 **cdp**：仅影响返回 **note**（本机已启动的浏览器无法由工具代关，只能自行关掉或改用 launch）。
    * **默认**：``chromium.launch`` + 新上下文（无痕；易被站点风控）。
    * **cdp_endpoint**：连接已用 ``--remote-debugging-port`` + 独立 ``--user-data-dir`` 启动的本机浏览器，复用 Cookie/登录态；步骤结束后仅断开 CDP，**不会关闭您已打开的浏览器窗口**（Win / macOS / Linux 命令行示例见工具返回的 **hint**）。未传本参数时，若环境变量 **AICD_BROWSER_CDP_ENDPOINT**（或 **AICD_CHROME_CDP_URL**）已设置，将自动使用该地址；设 **AICD_BROWSER_NO_CDP=1** 可禁用此项以强制 ``launch``。
    * **user_data_dir**：``launch_persistent_context``，独立持久目录（须符合 path_policy）。

    ``cdp_endpoint`` 与 ``user_data_dir`` 互斥。
    """
    if not isinstance(steps, list) or not steps:
        return {"ok": False, "error": "steps must be a non-empty list"}
    if len(steps) > MAX_AUTOMATION_STEPS:
        return {"ok": False, "error": f"max {MAX_AUTOMATION_STEPS} steps"}

    try:
        from playwright.async_api import async_playwright
    except ImportError as e:
        return {
            "ok": False,
            "error": f"playwright not available: {e}",
            "hint": "pip install playwright && python -m playwright install chromium",
        }

    def _resolve_out(path_str: str) -> Path:
        p = Path(path_str).expanduser()
        if not p.is_absolute():
            p = (cwd / p).resolve()
        else:
            p = p.resolve()
        policy_check(p)
        return p

    cdp = (cdp_endpoint or "").strip()
    if not cdp:
        cdp = default_cdp_endpoint_from_env()
    uds = (user_data_dir or "").strip()
    if cdp and uds:
        return {
            "ok": False,
            "error": "cdp_endpoint and user_data_dir are mutually exclusive",
        }

    step_results: list[dict[str, Any]] = []
    timeout = max(1000, min(600_000, int(default_timeout_ms)))
    sm = slow_mo_ms
    if sm is not None:
        sm = max(0, min(2000, int(sm)))

    vw = viewport or {}
    vp_w = int(vw.get("width", 1280)) if isinstance(vw, dict) else 1280
    vp_h = int(vw.get("height", 720)) if isinstance(vw, dict) else 720
    vp_w = max(320, min(3840, vp_w))
    vp_h = max(240, min(2160, vp_h))

    try:
        launch_kw = build_chromium_launch_kwargs(
            headless=bool(headless),
            slow_mo_ms=sm if sm else None,
            browser_channel=browser_channel,
            executable_path=executable_path,
        )
    except ValueError as e:
        return {"ok": False, "error": str(e), "step_results": step_results}

    cdp_url = _normalize_cdp_endpoint(cdp) if cdp else ""

    try:
        async with async_playwright() as p:
            if cdp_url:
                br = await p.chromium.connect_over_cdp(cdp_url)
                try:
                    if not br.contexts:
                        await br.close()
                        return {
                            "ok": False,
                            "error": "CDP connected but no browser contexts",
                            "hint": (
                                "先启动 Chrome/Edge（勿关窗口），需带 --remote-debugging-port=9222 与独立 "
                                "--user-data-dir；再在工具中传 cdp_endpoint=http://127.0.0.1:9222 "
                                "或设置环境变量 AICD_BROWSER_CDP_ENDPOINT。断开后浏览器会保留。示例: "
                                "Win: chrome.exe --remote-debugging-port=9222 "
                                "--user-data-dir=%TEMP%\\\\aicd-cdp ; "
                                "macOS: /Applications/Google\\ Chrome.app/Contents/MacOS/Google\\ Chrome "
                                "--remote-debugging-port=9222 --user-data-dir=/tmp/aicd-cdp ; "
                                "Linux: google-chrome --remote-debugging-port=9222 "
                                "--user-data-dir=/tmp/aicd-cdp"
                            ),
                        }
                    ctx0 = br.contexts[0]
                    page = ctx0.pages[0] if ctx0.pages else await ctx0.new_page()
                    out = await _execute_browser_steps(
                        page,
                        steps=steps,
                        policy_check=policy_check,
                        cwd=cwd,
                        timeout=timeout,
                        block_external_network=block_external_network,
                        _resolve_out=_resolve_out,
                    )
                    if out.get("ok"):
                        out["browser_mode"] = "cdp"
                        out["cdp_endpoint"] = cdp_url
                        out["user_browser_keeps_running"] = True
                        out["keep_browser_open"] = bool(keep_browser_open)
                        if keep_browser_open:
                            out["note"] = (
                                "已断开 Playwright CDP；按您的要求保留本机浏览器中的当前页，可直接查看。"
                            )
                        else:
                            out["note"] = (
                                "已断开 Playwright CDP。您手动启动的浏览器不会被本工具自动关闭；"
                                "若希望自动化结束后由工具结束 Playwright 启动的窗口，请改用 launch（不传 cdp），"
                                "或在本机手动关闭浏览器。"
                            )
                    return out
                finally:
                    await br.close()

            if uds:
                pp = _resolve_user_data_dir_path(uds, cwd, policy_check)
                pp.mkdir(parents=True, exist_ok=True)
                head = launch_kw.get("headless", True)
                sm_val = launch_kw.get("slow_mo")
                ch = launch_kw.get("channel")
                ex = launch_kw.get("executable_path")
                pc_kw: dict[str, Any] = {
                    "headless": bool(head),
                    "viewport": {"width": vp_w, "height": vp_h},
                }
                if sm_val is not None:
                    pc_kw["slow_mo"] = sm_val
                if ch:
                    pc_kw["channel"] = ch
                if ex:
                    pc_kw["executable_path"] = ex
                pctx = await p.chromium.launch_persistent_context(str(pp), **pc_kw)
                try:
                    page = pctx.pages[0] if pctx.pages else await pctx.new_page()
                    out = await _execute_browser_steps(
                        page,
                        steps=steps,
                        policy_check=policy_check,
                        cwd=cwd,
                        timeout=timeout,
                        block_external_network=block_external_network,
                        _resolve_out=_resolve_out,
                    )
                    if out.get("ok"):
                        out["browser_mode"] = "persistent"
                        out["user_data_dir"] = str(pp)
                    if keep_browser_open:
                        out["keep_browser_open"] = True
                        out["note"] = (
                            "已按「保持窗口打开」未关闭持久化浏览器上下文，窗口应仍可见；"
                            "查看完毕后请自行关闭。再次使用同一 user_data_dir 前须先关掉该窗口，"
                            "否则可能因配置目录锁导致启动失败。"
                        )
                    return out
                finally:
                    if not keep_browser_open:
                        await pctx.close()

            browser = await p.chromium.launch(**launch_kw)
            try:
                context = await browser.new_context(
                    viewport={"width": vp_w, "height": vp_h}
                )
                page = await context.new_page()
                out = await _execute_browser_steps(
                    page,
                    steps=steps,
                    policy_check=policy_check,
                    cwd=cwd,
                    timeout=timeout,
                    block_external_network=block_external_network,
                    _resolve_out=_resolve_out,
                )
                if out.get("ok"):
                    out["browser_mode"] = "launch"
                if keep_browser_open:
                    out["keep_browser_open"] = True
                    out["note"] = (
                        "已按「保持窗口打开」未关闭由 Playwright 启动的浏览器，请在查看完毕后自行关闭。"
                        "若窗口仍随进程退出而消失，请改用 cdp_endpoint 连接本机已启动的 Chrome/Edge。"
                    )
                return out
            finally:
                if not keep_browser_open:
                    await browser.close()
    except Exception as e:
        return {
            "ok": False,
            "error": str(e),
            "hint": playwright_chromium_launch_hint(str(e)),
            "step_results": step_results,
        }
