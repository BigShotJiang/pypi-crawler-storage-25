"""Extraction engine for orchestrating LLM-based content extraction.

Coordinates template selection, provider selection, caching, and result parsing.
"""

import hashlib
import json
import logging
import os
import re
import time
import warnings
from typing import TYPE_CHECKING, Any

from ..config.precedence import resolve_config_value
from ..config.schema import ExtractionConfig

# Import from specific submodules to avoid circular import with inkwell.plugins.__init__
# (which imports ExtractionPlugin from .types.extraction, which imports BaseExtractor
# from inkwell.extraction.extractors.base, which triggers inkwell.extraction.__init__)
from ..plugins.discovery import discover_plugins, get_entry_point_group
from ..plugins.registry import PluginRegistry
from ..plugins.types.extraction import ExtractionPlugin
from ..utils.errors import ValidationError
from ..utils.json_utils import JSONParsingError, safe_json_loads
from .cache import ExtractionCache
from .extractors import BaseExtractor
from .models import (
    ExtractedContent,
    ExtractionAttempt,
    ExtractionResult,
    ExtractionStatus,
    ExtractionSummary,
    ExtractionTemplate,
)

if TYPE_CHECKING:
    from ..utils.costs import CostTracker

logger = logging.getLogger(__name__)


def _sanitize_error_message(message: str) -> str:
    """Remove potential API keys from error messages.

    Sanitizes error messages to prevent API key leakage in logs and exception traces.
    Redacts both Gemini and Claude API keys using regex patterns.

    Args:
        message: Error message that may contain API keys

    Returns:
        Sanitized message with API keys redacted

    Example:
        >>> _sanitize_error_message("Error with key AIzaSyDabcdefg123")
        'Error with key [REDACTED_GEMINI_KEY]'
    """
    # Redact Gemini keys (AIza...)
    message = re.sub(r"AIza[A-Za-z0-9_-]+", "[REDACTED_GEMINI_KEY]", message)
    # Redact Claude keys (sk-ant-...)
    message = re.sub(r"sk-ant-[A-Za-z0-9_-]+", "[REDACTED_CLAUDE_KEY]", message)
    return message


class ExtractionEngine:
    """Orchestrates content extraction from transcripts.

    Handles:
    - Provider selection (Claude vs Gemini)
    - Caching to avoid redundant API calls
    - Result parsing and validation
    - Cost tracking
    - Error handling

    Example:
        >>> engine = ExtractionEngine()
        >>> result = await engine.extract(
        ...     template=summary_template,
        ...     transcript="...",
        ...     metadata={"podcast_name": "..."}
        ... )
        >>> print(result.content.data)
    """

    def __init__(
        self,
        config: ExtractionConfig | None = None,
        claude_api_key: str | None = None,
        gemini_api_key: str | None = None,
        cache: ExtractionCache | None = None,
        default_provider: str = "gemini",
        cost_tracker: "CostTracker | None" = None,
        use_plugin_registry: bool = True,
        extractor_override: str | None = None,
    ) -> None:
        """Initialize extraction engine.

        Args:
            config: Extraction configuration (recommended, new approach)
            claude_api_key: Anthropic API key (defaults to env var) [deprecated, use config]
            gemini_api_key: Google AI API key (defaults to env var) [deprecated, use config]
            cache: Cache instance (defaults to new ExtractionCache)
            default_provider: Default provider ("claude" or "gemini") [deprecated]
            cost_tracker: Cost tracker for recording API usage (optional, for DI)
            use_plugin_registry: Whether to load extractors from plugin registry (default: True)
            extractor_override: Force a specific extractor plugin (e.g., "claude", "gemini").
                               Takes precedence over INKWELL_EXTRACTOR env var.

        Note:
            Prefer passing `config` over individual parameters. Individual parameters
            are maintained for backward compatibility but will be deprecated in v2.0.

            Plugin Selection:
            - extractor_override parameter (explicit override, takes precedence)
            - INKWELL_EXTRACTOR env var (environment override)
            - Otherwise, the highest priority available extractor is used
        """
        deprecated_params = []
        if claude_api_key is not None:
            deprecated_params.append("claude_api_key")
        if gemini_api_key is not None:
            deprecated_params.append("gemini_api_key")
        if default_provider != "gemini":  # Non-default value
            deprecated_params.append("default_provider")

        if config is None and deprecated_params:
            warnings.warn(
                f"Individual parameters ({', '.join(deprecated_params)}) are deprecated. "
                f"Use ExtractionConfig instead. "
                f"These parameters will be removed in v2.0.",
                DeprecationWarning,
                stacklevel=2,
            )

        # Extract config values with standardized precedence
        effective_claude_key = resolve_config_value(
            config.claude_api_key if config else None, claude_api_key, None
        )
        effective_gemini_key = resolve_config_value(
            config.gemini_api_key if config else None, gemini_api_key, None
        )
        effective_provider = resolve_config_value(
            config.default_provider if config else None, default_provider, "gemini"
        )

        self._claude_api_key = effective_claude_key
        self._gemini_api_key = effective_gemini_key

        self.cache = cache or ExtractionCache()
        self.default_provider = effective_provider
        self.cost_tracker = cost_tracker

        self._registry: PluginRegistry[ExtractionPlugin] = PluginRegistry(
            ExtractionPlugin  # type: ignore[type-abstract]
        )
        self._use_plugin_registry = use_plugin_registry
        self._plugins_loaded = False

        self._extractor_override = extractor_override

    def _load_extraction_plugins(self) -> None:
        """Load extraction plugins from entry points into registry.

        This is called lazily when plugins are first needed. Plugins are
        configured with any available API keys and cost tracker.
        """
        if self._plugins_loaded:
            return

        group = get_entry_point_group("extraction")
        discovered_names: set[str] = set()

        for result in discover_plugins(group):
            discovered_names.add(result.name)
            if result.success and isinstance(result.plugin, ExtractionPlugin):
                self._register_extraction_plugin(result.name, result.plugin, result.source)
            else:
                # Register broken plugin for visibility
                error = result.error
                if result.success and result.plugin is not None:
                    error = (
                        f"Entry point did not load an ExtractionPlugin: "
                        f"{type(result.plugin).__name__}"
                    )
                self._registry.register(
                    name=result.name,
                    plugin=None,
                    priority=0,
                    source=result.source,
                    error=error,
                    recovery_hint=result.recovery_hint,
                )

        self._register_builtin_extraction_plugins(discovered_names)
        self._plugins_loaded = True

    def _register_builtin_extraction_plugins(self, discovered_names: set[str]) -> None:
        """Register built-in extractors when package entry points are unavailable."""

        builtin_extractors = {
            "claude": "inkwell.extraction.extractors.claude:ClaudeExtractor",
            "gemini": "inkwell.extraction.extractors.gemini:GeminiExtractor",
        }

        for name, source in builtin_extractors.items():
            if name in discovered_names:
                continue

            module_name, class_name = source.split(":", 1)
            try:
                module = __import__(module_name, fromlist=[class_name])
                plugin_class = getattr(module, class_name)
                try:
                    plugin = plugin_class(lazy_init=True)
                except TypeError:
                    plugin = plugin_class()
            except Exception as e:
                self._registry.register(
                    name=name,
                    plugin=None,
                    priority=0,
                    source=f"builtin:{source}",
                    error=str(e),
                )
                continue

            self._register_extraction_plugin(name, plugin, f"builtin:{source}")

    def _register_extraction_plugin(
        self,
        name: str,
        plugin: ExtractionPlugin,
        source: str,
    ) -> None:
        """Configure, validate, and register one extraction plugin."""

        plugin_config: dict[str, Any] = {}

        if name == "claude" and self._claude_api_key:
            plugin_config["api_key"] = self._claude_api_key
        elif name == "gemini" and self._gemini_api_key:
            plugin_config["api_key"] = self._gemini_api_key

        try:
            plugin.configure(plugin_config, self.cost_tracker)
            plugin.validate()
            self._registry.register(
                name=name,
                plugin=plugin,
                priority=PluginRegistry.PRIORITY_BUILTIN,
                source=source,
            )
            logger.debug(f"Registered extraction plugin: {name}")
        except Exception as e:
            self._registry.register(
                name=name,
                plugin=None,
                priority=0,
                source=source,
                error=str(e),
            )
            if name == self.default_provider:
                logger.warning(f"Failed to configure extraction plugin {name}: {e}")
            else:
                logger.debug(f"Extraction plugin {name} not configured: {e}")

    @property
    def extraction_registry(self) -> PluginRegistry[ExtractionPlugin]:
        """Get the extraction plugin registry.

        Lazily loads plugins on first access.
        """
        if self._use_plugin_registry and not self._plugins_loaded:
            self._load_extraction_plugins()
        return self._registry

    def _cache_key_options(
        self,
        template: ExtractionTemplate,
        extractor: BaseExtractor | None = None,
    ) -> dict[str, str]:
        """Build stable extraction cache-key metadata for a template."""
        provider = (
            self._provider_name_for_extractor(extractor)
            if extractor is not None
            else self._cache_provider_for_template(template)
        )
        return {
            "provider": provider,
            "model": (
                self._model_name_for_extractor(extractor)
                if extractor is not None
                else self._cache_model_for_provider(provider)
            ),
            "prompt_hash": self._template_prompt_hash(template),
            "output_schema_version": self._output_schema_version(template),
        }

    def _provider_name_for_extractor(self, extractor: BaseExtractor) -> str:
        """Return a provider identity for cache keys and result metadata."""
        plugin_name = getattr(extractor, "NAME", None)
        if isinstance(plugin_name, str) and plugin_name:
            return plugin_name

        class_name = extractor.__class__.__name__
        if class_name == "ClaudeExtractor":
            return "claude"
        if class_name == "GeminiExtractor":
            return "gemini"
        return class_name.removesuffix("Extractor").lower() or "unknown"

    def _model_name_for_extractor(self, extractor: BaseExtractor) -> str:
        """Return a model identity for cache keys."""
        model = getattr(extractor, "model", None) or getattr(extractor, "MODEL", None)
        if isinstance(model, str) and model:
            return model
        return "unknown"

    def _cache_provider_for_template(self, template: ExtractionTemplate) -> str:
        """Mirror provider selection inputs without requiring plugin initialization."""
        override = self._extractor_override or os.environ.get("INKWELL_EXTRACTOR")
        if override:
            return override

        if template.model_preference:
            return template.model_preference

        if "quote" in template.name.lower():
            return "claude"

        if template.expected_format == "json" and template.output_schema:
            required_fields = template.output_schema.get("required", [])
            if len(required_fields) > 5:
                return "claude"

        return self.default_provider

    def _cache_model_for_provider(self, provider: str) -> str:
        """Return the default model identity used for cache-key metadata."""
        default_models = {
            "claude": "claude-3-5-sonnet-20241022",
            "gemini": "gemini-3-pro-preview",
        }
        return default_models.get(provider, "unknown")

    def _template_prompt_hash(self, template: ExtractionTemplate) -> str:
        """Hash prompt/template inputs that affect extraction output."""
        payload = {
            "name": template.name,
            "version": template.version,
            "system_prompt": template.system_prompt,
            "user_prompt_template": template.user_prompt_template,
            "expected_format": template.expected_format,
            "output_schema": template.output_schema,
            "model_preference": template.model_preference,
            "max_tokens": template.max_tokens,
            "temperature": template.temperature,
            "variables": [variable.model_dump(mode="json") for variable in template.variables],
            "few_shot_examples": template.few_shot_examples,
        }
        content = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def _output_schema_version(self, template: ExtractionTemplate) -> str:
        """Build an output schema identity for cache-key metadata."""
        schema_payload = {
            "expected_format": template.expected_format,
            "output_schema": template.output_schema or {},
        }
        content = json.dumps(schema_payload, sort_keys=True, separators=(",", ":"), default=str)
        schema_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        return f"{template.expected_format}:{schema_hash}"

    async def extract(
        self,
        template: ExtractionTemplate,
        transcript: str,
        metadata: dict[str, Any],
        use_cache: bool = True,
    ) -> ExtractionResult:
        """Extract content from transcript using template.

        Args:
            template: Extraction template
            transcript: Full transcript text
            metadata: Episode metadata
            use_cache: Whether to use cache (default: True)

        Returns:
            ExtractionResult with parsed content and metadata

        Raises:
            ExtractionError: If extraction fails
        """
        episode_url = metadata.get("episode_url", "")
        policy_cache_key_options = self._cache_key_options(template)

        if use_cache:
            cached = await self.cache.get(
                template.name,
                template.version,
                transcript,
                **policy_cache_key_options,
            )
            if cached:
                content = self._parse_output(cached, template)
                return ExtractionResult(
                    episode_url=episode_url,
                    template_name=template.name,
                    template_version=template.version,
                    success=True,
                    extracted_content=content,
                    cost_usd=0.0,  # Cached, no cost
                    provider="cache",
                    from_cache=True,
                )

        extractor = self._select_extractor(template)
        provider_name = self._provider_name_for_extractor(extractor)
        cache_key_options = self._cache_key_options(template, extractor)

        if use_cache and cache_key_options != policy_cache_key_options:
            cached = await self.cache.get(
                template.name,
                template.version,
                transcript,
                **cache_key_options,
            )
            if cached:
                content = self._parse_output(cached, template)
                return ExtractionResult(
                    episode_url=episode_url,
                    template_name=template.name,
                    template_version=template.version,
                    success=True,
                    extracted_content=content,
                    cost_usd=0.0,
                    provider="cache",
                    from_cache=True,
                )

        # Estimate cost
        estimated_cost = extractor.estimate_cost(template, len(transcript))

        try:
            # Extract
            raw_output = await extractor.extract(template, transcript, metadata)

            content = self._parse_output(raw_output, template)

            if use_cache:
                await self.cache.set(
                    template.name,
                    template.version,
                    transcript,
                    raw_output,
                    **cache_key_options,
                )

            if self.cost_tracker:
                # Estimate token counts based on transcript length
                # This is an approximation; real token counts would come from API response
                input_tokens = len(transcript) // 4  # Rough approximation
                output_tokens = len(raw_output) // 4

                self.cost_tracker.add_cost(
                    provider=provider_name,
                    model=extractor.model if hasattr(extractor, "model") else "unknown",
                    operation="extraction",
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    episode_title=metadata.get("episode_title"),
                    template_name=template.name,
                )

            return ExtractionResult(
                episode_url=episode_url,
                template_name=template.name,
                template_version=template.version,
                success=True,
                extracted_content=content,
                cost_usd=estimated_cost,
                provider=provider_name,
            )

        except Exception as e:
            # Sanitize error message to prevent API key leakage
            error_msg = _sanitize_error_message(str(e))
            return ExtractionResult(
                episode_url=episode_url,
                template_name=template.name,
                template_version=template.version,
                success=False,
                extracted_content=None,
                error=error_msg,
                cost_usd=0.0,
                provider=provider_name,
            )

    async def extract_all(
        self,
        templates: list[ExtractionTemplate],
        transcript: str,
        metadata: dict[str, Any],
        use_cache: bool = True,
    ) -> tuple[list[ExtractionResult], ExtractionSummary]:
        """Extract content using multiple templates.

        Processes templates concurrently for better performance.
        Returns both successful results and a detailed summary of all attempts.

        Args:
            templates: List of extraction templates
            transcript: Full transcript text
            metadata: Episode metadata
            use_cache: Whether to use cache (default: True)

        Returns:
            Tuple of (successful results, extraction summary)
        """
        import asyncio

        start_times = {}

        async def extract_with_tracking(template: ExtractionTemplate) -> ExtractionResult:
            """Extract and track timing."""
            start_times[template.name] = time.time()
            return await self.extract(template, transcript, metadata, use_cache)

        # Extract concurrently
        tasks = [extract_with_tracking(template) for template in templates]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        attempts = []
        successful_results = []

        for template, result in zip(templates, results, strict=False):
            duration = time.time() - start_times.get(template.name, time.time())

            if isinstance(result, ExtractionResult):
                if result.success:
                    # Determine if from cache
                    status = (
                        ExtractionStatus.CACHED if result.from_cache else ExtractionStatus.SUCCESS
                    )

                    attempts.append(
                        ExtractionAttempt(
                            template_name=template.name,
                            status=status,
                            result=result,
                            duration_seconds=duration,
                        )
                    )
                    successful_results.append(result)
                else:
                    # ExtractionResult with success=False
                    attempts.append(
                        ExtractionAttempt(
                            template_name=template.name,
                            status=ExtractionStatus.FAILED,
                            error_message=result.error,
                            duration_seconds=duration,
                        )
                    )
                    logger.warning(
                        f"Extraction failed for template '{template.name}': {result.error}"
                    )

            elif isinstance(result, Exception):
                # Exception during extraction
                # Sanitize error message to prevent API key leakage
                sanitized_error_msg = _sanitize_error_message(str(result))
                attempts.append(
                    ExtractionAttempt(
                        template_name=template.name,
                        status=ExtractionStatus.FAILED,
                        error=result,
                        error_message=sanitized_error_msg,
                        duration_seconds=duration,
                    )
                )
                # Log with sanitized message to prevent key leakage in logs
                logger.error(
                    f"Extraction failed for template '{template.name}': {sanitized_error_msg}",
                    exc_info=result,
                )

        summary = ExtractionSummary(
            total=len(templates),
            successful=sum(1 for a in attempts if a.status == ExtractionStatus.SUCCESS),
            failed=sum(1 for a in attempts if a.status == ExtractionStatus.FAILED),
            cached=sum(1 for a in attempts if a.status == ExtractionStatus.CACHED),
            attempts=attempts,
        )

        logger.info(
            f"Extraction complete: {summary.successful}/{summary.total} successful, "
            f"{summary.failed} failed, {summary.cached} cached"
        )

        return successful_results, summary

    async def _batch_cache_lookup(
        self,
        templates: list[ExtractionTemplate],
        transcript: str,
        episode_url: str,
    ) -> dict[str, ExtractionResult]:
        """Lookup multiple templates in cache concurrently.

        Args:
            templates: List of templates to check
            transcript: Episode transcript for cache key
            episode_url: Episode URL for results

        Returns:
            Dict mapping template name to ExtractionResult (only cache hits)
        """
        import asyncio

        async def lookup_one(
            template: ExtractionTemplate,
        ) -> tuple[ExtractionTemplate, str | None]:
            """Lookup single template in cache."""
            policy_cache_key_options = self._cache_key_options(template)
            result = await self.cache.get(
                template.name,
                template.version,
                transcript,
                **policy_cache_key_options,
            )
            if result is not None:
                return (template, result)

            extractor = self._select_extractor(template)
            cache_key_options = self._cache_key_options(template, extractor)
            if cache_key_options != policy_cache_key_options:
                result = await self.cache.get(
                    template.name,
                    template.version,
                    transcript,
                    **cache_key_options,
                )
            return (template, result)

        results = await asyncio.gather(*[lookup_one(t) for t in templates])

        cached_results = {}
        for template, cached_raw in results:
            if cached_raw is not None:
                content = self._parse_output(cached_raw, template)
                cached_results[template.name] = ExtractionResult(
                    episode_url=episode_url,
                    template_name=template.name,
                    template_version=template.version,
                    success=True,
                    extracted_content=content,
                    cost_usd=0.0,
                    provider="cache",
                    from_cache=True,
                )

        return cached_results

    async def extract_all_batched(
        self,
        templates: list[ExtractionTemplate],
        transcript: str,
        metadata: dict[str, Any],
        use_cache: bool = True,
    ) -> tuple[list[ExtractionResult], ExtractionSummary]:
        """Extract all templates in a single batched API call.

        Batches multiple template extractions into one API call to reduce
        network overhead by 75% and improve processing speed by 30-40%.

        Args:
            templates: List of extraction templates
            transcript: Full transcript text
            metadata: Episode metadata
            use_cache: Whether to use cache (default: True)

        Returns:
            Tuple of (extraction results, extraction summary)

        Example:
            >>> results, summary = await engine.extract_all_batched(
            ...     [summary_template, quotes_template, concepts_template],
            ...     transcript,
            ...     metadata
            ... )
        """

        if not templates:
            # Empty summary for no templates
            empty_summary = ExtractionSummary(
                total=0, successful=0, failed=0, cached=0, attempts=[]
            )
            return [], empty_summary

        batch_start_time = time.time()

        episode_url = metadata.get("episode_url", "")

        cached_results = {}
        uncached_templates = []

        if use_cache:
            # Batch lookup all templates at once
            cache_start = time.time()
            cached_results = await self._batch_cache_lookup(templates, transcript, episode_url)
            cache_duration = time.time() - cache_start

            logger.debug(
                f"Cache lookup took {cache_duration:.3f}s for {len(templates)} templates "
                f"({len(cached_results)} hits, {len(templates) - len(cached_results)} misses)"
            )

            # Separate cached from uncached
            for template in templates:
                if template.name not in cached_results:
                    uncached_templates.append(template)
        else:
            uncached_templates = templates

        # If all cached, return early with summary
        if not uncached_templates:
            logger.info("All templates found in cache, returning cached results")
            results_list = [cached_results[t.name] for t in templates]

            attempts = [
                ExtractionAttempt(
                    template_name=t.name,
                    status=ExtractionStatus.CACHED,
                    result=cached_results[t.name],
                    duration_seconds=0.0,
                )
                for t in templates
            ]
            summary = ExtractionSummary(
                total=len(templates),
                successful=0,
                failed=0,
                cached=len(templates),
                attempts=attempts,
            )
            return results_list, summary

        # Extract each template individually for focused, reliable results
        logger.info(f"Extracting {len(uncached_templates)} templates individually")
        batch_results = await self._extract_individually(
            uncached_templates, transcript, metadata, episode_url
        )

        if use_cache:
            for template in uncached_templates:
                result = batch_results.get(template.name)
                if result and result.success and result.extracted_content:
                    raw_output = self._serialize_extracted_content(result.extracted_content)
                    extractor = self._select_extractor(template)
                    await self.cache.set(
                        template.name,
                        template.version,
                        transcript,
                        raw_output,
                        **self._cache_key_options(template, extractor),
                    )

        # Combine cached and new results in original order and build summary
        all_results = []
        attempts = []
        batch_duration = time.time() - batch_start_time

        for template in templates:
            if template.name in cached_results:
                result = cached_results[template.name]
                all_results.append(result)
                attempts.append(
                    ExtractionAttempt(
                        template_name=template.name,
                        status=ExtractionStatus.CACHED,
                        result=result,
                        duration_seconds=0.0,
                    )
                )
            elif template.name in batch_results:
                result = batch_results[template.name]
                all_results.append(result)

                # Determine status based on result success
                if result.success:
                    status = ExtractionStatus.SUCCESS
                else:
                    status = ExtractionStatus.FAILED

                attempts.append(
                    ExtractionAttempt(
                        template_name=template.name,
                        status=status,
                        result=result if result.success else None,
                        error_message=result.error if not result.success else None,
                        duration_seconds=batch_duration / len(uncached_templates),
                    )
                )
            else:
                # Template failed, create error result
                error_result = ExtractionResult(
                    episode_url=episode_url,
                    template_name=template.name,
                    template_version=template.version,
                    success=False,
                    error="Template not found in batch results",
                    cost_usd=0.0,
                    provider="gemini",  # Default to gemini for batched extraction
                )
                all_results.append(error_result)
                attempts.append(
                    ExtractionAttempt(
                        template_name=template.name,
                        status=ExtractionStatus.FAILED,
                        error_message="Template not found in batch results",
                        duration_seconds=batch_duration / len(templates),
                    )
                )

        summary = ExtractionSummary(
            total=len(templates),
            successful=sum(1 for a in attempts if a.status == ExtractionStatus.SUCCESS),
            failed=sum(1 for a in attempts if a.status == ExtractionStatus.FAILED),
            cached=sum(1 for a in attempts if a.status == ExtractionStatus.CACHED),
            attempts=attempts,
        )

        logger.info(
            f"Batch extraction complete: {summary.successful}/{summary.total} successful, "
            f"{summary.failed} failed, {summary.cached} cached"
        )

        return all_results, summary

    def estimate_total_cost(
        self,
        templates: list[ExtractionTemplate],
        transcript: str,
    ) -> float:
        """Estimate total cost for extracting all templates.

        Args:
            templates: List of extraction templates
            transcript: Full transcript text

        Returns:
            Estimated total cost in USD
        """
        total = 0.0
        for template in templates:
            extractor = self._select_extractor(template)
            cost = extractor.estimate_cost(template, len(transcript))
            total += cost
        return total

    def _select_extractor(self, template: ExtractionTemplate) -> BaseExtractor:
        """Select appropriate extractor for template.

        Selection priority:
        1. extractor_override parameter (explicit override)
        2. INKWELL_EXTRACTOR environment variable (environment override)
        3. Template's model_preference if specified
        4. Heuristics based on template type
        5. Default provider
        6. Highest priority plugin from registry

        Args:
            template: Extraction template

        Returns:
            Extractor instance (Claude, Gemini, or plugin)

        Raises:
            ValueError: If no extractor is available
        """
        override = self._extractor_override or os.environ.get("INKWELL_EXTRACTOR")
        if override:
            plugin = self.extraction_registry.get(override)
            if plugin:
                return plugin
            raise ValueError(
                f"Extractor '{override}' not found. "
                f"Available: {', '.join(n for n, _ in self.extraction_registry.get_enabled())}"
            )

        return self._select_extractor_from_registry(template)

    def _select_extractor_from_registry(self, template: ExtractionTemplate) -> BaseExtractor:
        """Select extractor using plugin registry.

        Args:
            template: Extraction template

        Returns:
            Extractor instance from registry

        Raises:
            ValueError: If no extractor plugins are available
        """
        # Template's explicit preference
        if template.model_preference:
            plugin = self.extraction_registry.get(template.model_preference)
            if plugin:
                return plugin

        enabled_plugins = self.extraction_registry.get_enabled()

        if not enabled_plugins:
            raise ValueError(
                "No extraction plugins available. "
                "Set GOOGLE_API_KEY or ANTHROPIC_API_KEY environment variable."
            )

        # Heuristics for auto-selection
        # Use Claude for quote extraction (precision critical)
        if "quote" in template.name.lower():
            claude_plugin = self.extraction_registry.get("claude")
            if claude_plugin:
                return claude_plugin

        if template.expected_format == "json" and template.output_schema:
            required_fields = template.output_schema.get("required", [])
            if len(required_fields) > 5:
                claude_plugin = self.extraction_registry.get("claude")
                if claude_plugin:
                    return claude_plugin

        # Default provider preference
        default_plugin = self.extraction_registry.get(self.default_provider)
        if default_plugin:
            return default_plugin

        return enabled_plugins[0][1]

    def _parse_output(self, raw_output: str, template: ExtractionTemplate) -> ExtractedContent:
        """Parse raw LLM output into ExtractedContent.

        Args:
            raw_output: Raw string from LLM
            template: Template used for extraction

        Returns:
            ExtractedContent with parsed data

        Raises:
            ValidationError: If parsing fails
        """
        if template.expected_format == "json":
            try:
                # 5MB for extraction results, depth of 10 for structured data
                data = safe_json_loads(raw_output, max_size=5_000_000, max_depth=10)
                return ExtractedContent(
                    template_name=template.name,
                    content=data,
                )
            except JSONParsingError as e:
                raise ValidationError(f"Invalid JSON output: {str(e)}") from e

        elif template.expected_format == "markdown":
            return ExtractedContent(
                template_name=template.name,
                content=raw_output,
            )

        elif template.expected_format == "yaml":
            import yaml

            try:
                data = yaml.safe_load(raw_output)
                return ExtractedContent(
                    template_name=template.name,
                    content=data,
                )
            except yaml.YAMLError as e:
                raise ValidationError(f"Invalid YAML output: {str(e)}") from e

        else:  # text
            return ExtractedContent(
                template_name=template.name,
                content=raw_output,
            )

    def get_total_cost(self) -> float:
        """Get total cost accumulated so far.

        Returns:
            Total cost in USD
        """
        if self.cost_tracker:
            return self.cost_tracker.get_session_cost()
        return 0.0

    def reset_cost_tracking(self) -> None:
        """Reset cost tracking to zero."""
        if self.cost_tracker:
            self.cost_tracker.reset_session_cost()

    def _create_batch_prompt(
        self,
        templates: list[ExtractionTemplate],
        transcript: str,
        metadata: dict[str, Any],
    ) -> str:
        """Create combined prompt for multiple templates.

        Args:
            templates: Templates to extract
            transcript: Episode transcript
            metadata: Episode metadata

        Returns:
            Combined prompt string

        Example:
            Prompt format:
            '''
            Analyze this podcast transcript and provide multiple extractions:

            1. SUMMARY:
            [template instructions]

            2. QUOTES:
            [template instructions]

            3. KEY CONCEPTS:
            [template instructions]

            TRANSCRIPT:
            [full transcript]

            Provide your response as JSON:
            {
                "summary": "...",
                "quotes": [...],
                "key-concepts": [...]
            }
            '''
        """
        import json

        instructions = []
        for i, template in enumerate(templates, 1):
            task_name = template.name.upper().replace("-", " ").replace("_", " ")
            instructions.append(f"{i}. {task_name}:")
            instructions.append(f"   Description: {template.description}")

            user_prompt = self._select_extractor(template).build_prompt(
                template, "{{transcript}}", metadata
            )
            instructions.append(f"   Instructions: {user_prompt}")

            if template.expected_format == "json" and template.output_schema:
                schema_str = json.dumps(template.output_schema, indent=2)
                instructions.append(f"   Expected format: {schema_str}")
            else:
                instructions.append(f"   Expected format: {template.expected_format}")

            instructions.append("")

        schema = {template.name: f"<{template.expected_format} content>" for template in templates}

        prompt = f"""
Analyze this podcast transcript and provide multiple extractions.

PODCAST INFORMATION:
- Title: {metadata.get("episode_title", "Unknown")}
- Podcast: {metadata.get("podcast_name", "Unknown")}
- URL: {metadata.get("episode_url", "Unknown")}

EXTRACTION TASKS:
{chr(10).join(instructions)}

TRANSCRIPT:
{transcript}

IMPORTANT: Provide your response as a single JSON object with the following structure:
{json.dumps(schema, indent=2)}

Each field should contain the extracted information for that task.
Use the exact template names as JSON keys.
""".strip()

        return prompt

    def _parse_batch_response(
        self,
        response: str,
        templates: list[ExtractionTemplate],
        episode_url: str,
        provider_name: str,
        estimated_cost: float,
    ) -> dict[str, ExtractionResult]:
        """Parse batched LLM response into individual results.

        Args:
            response: LLM response text
            templates: Templates that were batched
            episode_url: Episode URL for results
            provider_name: Provider used for extraction
            estimated_cost: Total estimated cost for batch

        Returns:
            Dict mapping template name to ExtractionResult

        Raises:
            ValueError: If response cannot be parsed
        """
        import json

        try:
            # Extract JSON from response
            json_start = response.find("{")
            json_end = response.rfind("}") + 1

            if json_start == -1 or json_end == 0:
                raise ValueError("No JSON object found in response")

            json_str = response[json_start:json_end]
            data = safe_json_loads(json_str, max_size=5_000_000, max_depth=10)

            results = {}
            cost_per_template = estimated_cost / len(templates)

            for template in templates:
                template_data = data.get(template.name)

                if template_data is None:
                    # Template not in response
                    results[template.name] = ExtractionResult(
                        episode_url=episode_url,
                        template_name=template.name,
                        template_version=template.version,
                        success=False,
                        error=f"Missing '{template.name}' in batch response",
                        cost_usd=0.0,
                        provider=provider_name,
                    )
                else:
                    if template.expected_format == "json":
                        # Data is already parsed, but ensure it's str or dict
                        if isinstance(template_data, (str, dict)):
                            content_data = template_data
                        elif isinstance(template_data, list):
                            # Wrap list in dict with template name as key
                            content_data = {template.name: template_data}
                        else:
                            content_data = {"data": template_data}

                        content = ExtractedContent(
                            template_name=template.name,
                            content=content_data,
                        )
                    else:
                        # For text/markdown/yaml, data should be string
                        if not isinstance(template_data, str):
                            template_data = json.dumps(template_data)

                        content = ExtractedContent(
                            template_name=template.name,
                            content=template_data,
                        )

                    results[template.name] = ExtractionResult(
                        episode_url=episode_url,
                        template_name=template.name,
                        template_version=template.version,
                        success=True,
                        extracted_content=content,
                        cost_usd=cost_per_template,
                        provider=provider_name,
                    )

            return results

        except (json.JSONDecodeError, ValueError) as e:
            logger.error(f"Failed to parse batch response: {e}")
            raise ValueError(f"Invalid batch response format: {e}") from e

    async def _extract_individually(
        self,
        templates: list[ExtractionTemplate],
        transcript: str,
        metadata: dict[str, Any],
        episode_url: str,
    ) -> dict[str, ExtractionResult]:
        """Extract templates individually in parallel.

        Each template gets its own focused LLM call for better reliability.

        Args:
            templates: Templates to extract
            transcript: Episode transcript
            metadata: Episode metadata
            episode_url: Episode URL for results

        Returns:
            Dict mapping template name to ExtractionResult
        """
        import asyncio

        tasks = [
            self.extract(template, transcript, metadata, use_cache=False) for template in templates
        ]

        results_list = await asyncio.gather(*tasks, return_exceptions=True)

        results = {}
        for template, result in zip(templates, results_list, strict=False):
            if isinstance(result, ExtractionResult):
                results[template.name] = result
            elif isinstance(result, Exception):
                results[template.name] = ExtractionResult(
                    episode_url=episode_url,
                    template_name=template.name,
                    template_version=template.version,
                    success=False,
                    error=str(result),
                    cost_usd=0.0,
                    provider="unknown",
                )

        return results

    def _serialize_extracted_content(self, content: ExtractedContent) -> str:
        """Serialize ExtractedContent for caching.

        Args:
            content: Extracted content to serialize

        Returns:
            String representation suitable for caching
        """
        import json

        if isinstance(content.content, dict):
            return json.dumps(content.content)
        elif isinstance(content.content, str):
            return content.content
        else:
            return str(content.content)
