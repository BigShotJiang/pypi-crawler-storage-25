import json
import mimetypes
import os

from tensorboard import errors
from tensorboard.backend import http_util
from tensorboard.backend.event_processing import event_accumulator, event_multiplexer
from tensorboard.plugins import base_plugin
from werkzeug import wrappers

from tensorboard_plugin_hydrograph.metadata import PLUGIN_NAME


class HydrographPlugin(base_plugin.TBPlugin):
    plugin_name = PLUGIN_NAME

    def __init__(self, context):
        self._logdir = context.logdir
        # Build our own multiplexer that actually works
        self._mux = event_multiplexer.EventMultiplexer(
            size_guidance={event_accumulator.TENSORS: 500},
        )
        self._mux.AddRunsFromDirectory(self._logdir)
        self._mux.Reload()

    def data_plugin_names(self):
        return (PLUGIN_NAME,)

    def is_active(self):
        mapping = self._mux.PluginRunToTagToContent(PLUGIN_NAME)
        return bool(mapping)

    def frontend_metadata(self):
        return base_plugin.FrontendMetadata(es_module_path="/index.js")

    def get_plugin_apps(self):
        return {
            "/index.js": self._serve_static,
            "/index.html": self._serve_static,
            "/plotly.min.js": self._serve_static,
            "/tags": self._serve_tags,
            "/data": self._serve_data,
        }

    @wrappers.Request.application
    def _serve_tags(self, request):
        self._mux.Reload()  # pick up new events
        mapping = self._mux.PluginRunToTagToContent(PLUGIN_NAME)
        print(f"[hydrograph] mapping: {mapping}")
        result = {run: list(tags.keys()) for run, tags in mapping.items()}
        return http_util.Respond(request, result, "application/json")

    @wrappers.Request.application
    def _serve_data(self, request):
        run = request.args.get("run")
        tag = request.args.get("tag")
        step = request.args.get("step")
        if run is None or tag is None:
            raise errors.InvalidArgumentError("run and tag are required")

        self._mux.Reload()
        events = self._mux.Tensors(run, tag)

        if step is None:
            steps = [int(e.step) for e in events]
            return http_util.Respond(request, {"steps": steps}, "application/json")

        step = int(step)
        match = next((e for e in events if int(e.step) == step), None)
        if match is None:
            raise errors.NotFoundError(f"step {step} not found")

        raw = match.tensor_proto.string_val[0]
        payload = json.loads(raw.decode("utf-8"))
        return http_util.Respond(request, payload, "application/json")

    @wrappers.Request.application
    def _serve_static(self, request):
        filename = os.path.basename(request.path)
        static_dir = os.path.join(os.path.dirname(__file__), "static")
        filepath = os.path.join(static_dir, filename)
        if not os.path.isfile(filepath):
            raise errors.NotFoundError(filename)
        with open(filepath, "rb") as f:
            contents = f.read()
        mimetype = mimetypes.guess_type(filepath)[0] or "application/octet-stream"
        if filename.endswith(".js"):
            mimetype = "application/javascript"
        return wrappers.Response(contents, content_type=mimetype)
