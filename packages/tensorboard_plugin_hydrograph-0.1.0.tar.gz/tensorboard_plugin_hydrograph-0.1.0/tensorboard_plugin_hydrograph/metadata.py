"""Shared metadata for the hydrograph plugin."""

from tensorboard.compat.proto import summary_pb2

PLUGIN_NAME = "hydrograph"


def create_summary_metadata(display_name="", description=""):
    return summary_pb2.SummaryMetadata(
        display_name=display_name,
        summary_description=description,
        plugin_data=summary_pb2.SummaryMetadata.PluginData(plugin_name=PLUGIN_NAME, content=b""),
    )
