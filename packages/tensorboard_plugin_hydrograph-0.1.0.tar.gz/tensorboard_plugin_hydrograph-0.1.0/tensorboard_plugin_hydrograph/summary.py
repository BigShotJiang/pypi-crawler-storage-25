"""Public API for logging hydrographs."""

import json

import numpy as np

from tensorboard_plugin_hydrograph.metadata import PLUGIN_NAME


def _to_list(x):
    if hasattr(x, "tolist"):
        return x.tolist()
    return list(x)


def _dates_to_iso(dates):
    out = []
    for d in dates:
        if hasattr(d, "isoformat"):
            out.append(d.isoformat())
        else:
            out.append(str(d))
    return out


def _get_proto_modules(writer):
    """Return (summary_pb2, tensor_pb2, tensor_shape_pb2) matching the writer."""
    try:
        mod_name = writer.file_writer.__class__.__module__
        if "tensorboardX" in mod_name:
            from tensorboardX.proto import summary_pb2, tensor_pb2, tensor_shape_pb2

            return summary_pb2, tensor_pb2, tensor_shape_pb2
    except Exception:
        pass
    from tensorboard.compat.proto import summary_pb2, tensor_pb2, tensor_shape_pb2

    return summary_pb2, tensor_pb2, tensor_shape_pb2


def add_hydrograph(writer, tag, dates, observed, simulated, step, metrics=None):
    """Log a hydrograph (observed vs simulated timeseries) to TensorBoard.

    Args:
        writer: a tensorboardX or torch.utils SummaryWriter.
        tag: string tag (e.g. "Hydrographs/Comparison").
        dates: iterable of datetime-like values, length N.
        observed: array-like of length N.
        simulated: array-like of length N.
        step: iteration number.
        metrics: optional dict of {name: float} to show in the title.
    """
    payload = {
        "dates": _dates_to_iso(dates),
        "observed": _to_list(np.asarray(observed, dtype=float)),
        "simulated": _to_list(np.asarray(simulated, dtype=float)),
        "metrics": metrics or {},
        "step": int(step),
    }
    encoded = json.dumps(payload).encode("utf-8")

    summary_pb2, tensor_pb2, tensor_shape_pb2 = _get_proto_modules(writer)

    metadata = summary_pb2.SummaryMetadata(
        plugin_data=summary_pb2.SummaryMetadata.PluginData(plugin_name=PLUGIN_NAME, content=b"")
    )
    tensor_proto = tensor_pb2.TensorProto(
        dtype=7,  # DT_STRING
        string_val=[encoded],
        tensor_shape=tensor_shape_pb2.TensorShapeProto(),
    )
    summary = summary_pb2.Summary(
        value=[
            summary_pb2.Summary.Value(
                tag=tag,
                metadata=metadata,
                tensor=tensor_proto,
            )
        ]
    )
    writer.file_writer.add_summary(summary, global_step=step)
