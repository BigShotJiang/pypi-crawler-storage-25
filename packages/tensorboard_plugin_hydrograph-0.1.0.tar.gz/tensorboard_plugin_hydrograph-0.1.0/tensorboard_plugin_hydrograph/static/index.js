// ES module loaded by TensorBoard into the plugin's iframe.

export async function render() {
  const root = document.body;
  root.innerHTML = `
    <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      margin: 16px; color: #111827;
    }
    .controls {
      display: flex; gap: 20px; flex-wrap: wrap; align-items: flex-end;
      margin-bottom: 20px; padding: 12px 16px;
      background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px;
    }
    .controls label {
      display: flex; flex-direction: column; font-size: 12px;
      color: #6b7280; font-weight: 500; text-transform: uppercase; letter-spacing: 0.03em;
    }
    .controls select, .controls input[type=range] {
      margin-top: 6px; padding: 4px 8px;
      border: 1px solid #d1d5db; border-radius: 6px; background: white;
      font-size: 13px; color: #111827;
    }
    .controls input[type=range] { padding: 0; min-width: 200px; }
    #step-display {
      font-family: ui-monospace, monospace; font-size: 13px;
      color: #374151; padding: 6px 10px;
      background: white; border: 1px solid #e5e7eb; border-radius: 6px;
    }
    #chart { width: 100%; height: 600px; }
    #status { color: #9ca3af; font-size: 12px; margin-top: 8px; }}
    </style>
    <div class="controls">
      <label>Run <select id="run"></select></label>
      <label>Tag <select id="tag"></select></label>
      <label>Iteration <input type="range" id="step" min="0" max="0" value="0"></label>
      <span id="step-display">—</span>
    </div>
    <div id="chart"></div>
    <div id="status">Loading…</div>
  `;

  await loadPlotly();

  const runSel = document.getElementById("run");
  const tagSel = document.getElementById("tag");
  const stepSlider = document.getElementById("step");
  const stepDisplay = document.getElementById("step-display");
  const status = document.getElementById("status");

  let currentSteps = [];

  const tagsByRun = await fetchJSON("./tags");
  const runs = Object.keys(tagsByRun).sort();
  if (runs.length === 0) {
    status.textContent =
      "No hydrograph data found. Log some with add_hydrograph().";
    return;
  }
  runSel.innerHTML = runs
    .map((r) => `<option value="${r}">${r}</option>`)
    .join("");

  async function refreshTags() {
    const run = runSel.value;
    const tags = tagsByRun[run] || [];
    tagSel.innerHTML = tags
      .map((t) => `<option value="${t}">${t}</option>`)
      .join("");
    await refreshSteps();
  }

  async function refreshSteps() {
    const run = runSel.value;
    const tag = tagSel.value;
    if (!run || !tag) return;
    const { steps } = await fetchJSON(
      `./data?run=${encodeURIComponent(run)}&tag=${encodeURIComponent(tag)}`,
    );
    currentSteps = steps.slice().sort((a, b) => a - b);
    stepSlider.min = 0;
    stepSlider.max = Math.max(0, currentSteps.length - 1);
    stepSlider.value = currentSteps.length - 1;
    await refreshChart();
  }

  async function refreshChart() {
    const run = runSel.value;
    const tag = tagSel.value;
    const idx = parseInt(stepSlider.value, 10);
    const step = currentSteps[idx];
    if (step === undefined) return;
    stepDisplay.textContent = `step ${step}`;
    status.textContent = "Loading…";
    const data = await fetchJSON(
      `./data?run=${encodeURIComponent(run)}&tag=${encodeURIComponent(tag)}&step=${step}`,
    );
    const dates = data.dates.map((d) => new Date(d));

    const traces = [
      {
        x: dates,
        y: data.observed,
        name: "Observed",
        mode: "lines",
        type: "scatter",
        line: { color: "#1f2937", width: 2, shape: "spline", smoothing: 0.3 },
        hovertemplate:
          "<b>Observed</b><br>%{x|%Y-%m-%d %H:%M}<br>%{y:.2f} m³/s<extra></extra>",
      },
      {
        x: dates,
        y: data.simulated,
        name: "Simulated",
        mode: "lines",
        type: "scatter",
        line: { color: "#ea580c", width: 2, shape: "spline", smoothing: 0.3 },
        hovertemplate:
          "<b>Simulated</b><br>%{x|%Y-%m-%d %H:%M}<br>%{y:.2f} m³/s<extra></extra>",
      },
    ];

    const layout = {
      title: {
        text: buildTitle(data),
        font: {
          family: "system-ui, -apple-system, sans-serif",
          size: 18,
          color: "#111827",
        },
        x: 0.02,
        xanchor: "left",
      },
      xaxis: {
        title: { text: "Date", font: { size: 13, color: "#6b7280" } },
        gridcolor: "#f3f4f6",
        linecolor: "#e5e7eb",
        tickfont: { color: "#6b7280" },
        showspikes: true,
        spikemode: "across",
        spikesnap: "cursor",
        spikecolor: "#9ca3af",
        spikethickness: 1,
        spikedash: "dot",
      },
      yaxis: {
        title: {
          text: "Streamflow (m³/s)",
          font: { size: 13, color: "#6b7280" },
        },
        gridcolor: "#f3f4f6",
        linecolor: "#e5e7eb",
        tickfont: { color: "#6b7280" },
        rangemode: "tozero",
      },
      hovermode: "x unified",
      hoverlabel: {
        bgcolor: "white",
        bordercolor: "#e5e7eb",
        font: { family: "system-ui, sans-serif", size: 12, color: "#111827" },
      },
      legend: {
        orientation: "h",
        yanchor: "bottom",
        y: 1.02,
        xanchor: "right",
        x: 1,
        font: { size: 12, color: "#374151" },
        bgcolor: "rgba(255,255,255,0)",
      },
      plot_bgcolor: "white",
      paper_bgcolor: "white",
      margin: { l: 70, r: 30, t: 70, b: 60 },
    };

    const config = {
      responsive: true,
      displaylogo: false,
      modeBarButtonsToRemove: ["lasso2d", "select2d", "autoScale2d"],
      toImageButtonOptions: {
        format: "png",
        filename: `hydrograph_step_${step}`,
        scale: 2,
      },
    };

    window.Plotly.react("chart", traces, layout, config);
    status.textContent = "";
  }

  function buildTitle(data) {
    const bits = [`Iteration ${data.step}`];
    for (const [k, v] of Object.entries(data.metrics || {})) {
      bits.push(`${k}: ${Number(v).toFixed(4)}`);
    }
    return bits.join(" — ");
  }

  runSel.addEventListener("change", refreshTags);
  tagSel.addEventListener("change", refreshSteps);
  stepSlider.addEventListener("input", refreshChart);

  await refreshTags();
}

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json();
}

function loadPlotly() {
  if (window.Plotly) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "./plotly.min.js";
    s.onload = resolve;
    s.onerror = reject;
    document.head.appendChild(s);
  });
}
