# tb_hydrograph

A TensorBoard plugin for interactive hydrograph visualization. Log observed vs.
simulated time series with per-step metrics and browse them as an interactive
Plotly chart inside TensorBoard.

## Install

From PyPI-style wheel (once built):

```bash
uv pip install tensorboard_plugin_hydrograph
```

From source:

```bash
uv pip install .
```

Editable install for development:

```bash
uv pip install -e .
```

## Build

This project uses [uv](https://docs.astral.sh/uv/) with the `hatchling` build
backend declared in `pyproject.toml`.

```bash
uv build
```

This produces both an sdist and a wheel under `dist/`. The plugin's static
assets (`tensorboard_plugin_hydrograph/static/*`) are bundled into the wheel.

## Usage

Log a hydrograph from your training loop:

```python
from torch.utils.tensorboard import SummaryWriter
from tensorboard_plugin_hydrograph import add_hydrograph

writer = SummaryWriter("runs/exp1")
add_hydrograph(
    writer,
    tag="Hydrographs/Comparison",
    dates=dates,           # iterable of datetime-like values
    observed=observed,     # array-like
    simulated=simulated,   # array-like
    step=epoch,
    metrics={"NSE": 0.81}, # optional
)
```

Then launch TensorBoard against the same log directory:

```bash
tensorboard --logdir runs/
```

The **Hydrograph** tab will appear once the plugin detects logged summaries.

## Development

```bash
uv venv
uv pip install -e .
```
