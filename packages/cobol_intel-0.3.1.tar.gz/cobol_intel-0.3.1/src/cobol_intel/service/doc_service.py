"""Documentation generation service — reads artifacts from a completed run."""

from __future__ import annotations

import json
from pathlib import Path

from cobol_intel.contracts.ast_output import ASTOutput
from cobol_intel.contracts.data_flow_output import DataFlowGraph
from cobol_intel.contracts.dead_code_output import DeadCodeReport
from cobol_intel.contracts.explanation_output import ExplanationOutput
from cobol_intel.contracts.graph_output import CallGraphOutput
from cobol_intel.contracts.manifest import Manifest
from cobol_intel.contracts.rules_output import RulesOutput
from cobol_intel.outputs import write_text_artifact
from cobol_intel.outputs.doc_generator import (
    ProgramDocumentation,
    generate_program_doc,
    generate_project_report,
)
from cobol_intel.outputs.html_report import render_html_report


def generate_docs(run_dir: Path, fmt: str = "markdown") -> list[Path]:
    """Read artifacts from a completed run and generate documentation.

    Returns list of generated doc file paths.
    """
    manifest_path = run_dir / "manifest.json"
    manifest = Manifest(**json.loads(manifest_path.read_text(encoding="utf-8")))

    # Load call graph
    call_graph = None
    for graph_rel in manifest.artifacts.graphs:
        if "call_graph.json" in graph_rel:
            graph_path = run_dir / graph_rel
            if graph_path.exists():
                call_graph = CallGraphOutput(**json.loads(graph_path.read_text(encoding="utf-8")))
                break

    # Load ASTs, rules, and explanations per program
    asts: dict[str, ASTOutput] = {}
    for ast_rel in manifest.artifacts.ast:
        ast_path = run_dir / ast_rel
        if ast_path.exists():
            ast = ASTOutput(**json.loads(ast_path.read_text(encoding="utf-8")))
            key = ast.program_id or Path(ast.file_path).stem
            asts[key] = ast

    rules_map: dict[str, RulesOutput] = {}
    for rules_rel in manifest.artifacts.rules:
        rules_path = run_dir / rules_rel
        if rules_path.exists():
            ro = RulesOutput(**json.loads(rules_path.read_text(encoding="utf-8")))
            key = ro.program_id or Path(ro.file_path).stem
            rules_map[key] = ro

    explanations: dict[str, ExplanationOutput] = {}
    for doc_rel in manifest.artifacts.docs:
        if doc_rel.endswith("_explanation.json"):
            doc_path = run_dir / doc_rel
            if doc_path.exists():
                eo = ExplanationOutput(**json.loads(doc_path.read_text(encoding="utf-8")))
                key = eo.program_id or Path(eo.file_path).stem
                explanations[key] = eo

    # Load analysis artifacts (data flow, dead code)
    data_flows: dict[str, DataFlowGraph] = {}
    dead_codes: dict[str, DeadCodeReport] = {}
    for analysis_rel in manifest.artifacts.analysis:
        if not analysis_rel.endswith(".json"):
            continue
        analysis_path = run_dir / analysis_rel
        if not analysis_path.exists():
            continue
        data = json.loads(analysis_path.read_text(encoding="utf-8"))
        if analysis_rel.endswith("_dataflow.json"):
            df = DataFlowGraph(**data)
            key = df.program_id or Path(df.file_path).stem
            data_flows[key] = df
        elif analysis_rel.endswith("_deadcode.json"):
            dc = DeadCodeReport(**data)
            key = dc.program_id or Path(dc.file_path).stem
            dead_codes[key] = dc

    # Generate per-program docs
    program_docs: list[ProgramDocumentation] = []
    generated_paths: list[Path] = []

    for key, ast in sorted(asts.items()):
        doc = generate_program_doc(
            ast=ast,
            rules=rules_map.get(key),
            call_graph=call_graph,
            explanation=explanations.get(key),
            data_flow=data_flows.get(key),
            dead_code=dead_codes.get(key),
        )
        program_docs.append(doc)

        doc_path = run_dir / "docs" / f"{_slugify(key)}_doc.md"
        write_text_artifact(doc_path, doc.markdown)
        generated_paths.append(doc_path)

    # Generate project report
    report = generate_project_report(manifest, program_docs, call_graph)
    report_path = run_dir / "docs" / "project_report.md"
    write_text_artifact(report_path, report)
    generated_paths.append(report_path)

    # Generate HTML report if requested
    if fmt == "html":
        html = render_html_report(manifest, program_docs, call_graph)
        html_path = run_dir / "docs" / "project_report.html"
        write_text_artifact(html_path, html)
        generated_paths.append(html_path)

    return generated_paths


def _slugify(value: str) -> str:
    chars = [c.lower() if c.isalnum() else "_" for c in value.strip()]
    collapsed = "".join(chars)
    while "__" in collapsed:
        collapsed = collapsed.replace("__", "_")
    return collapsed.strip("_") or "unknown"
