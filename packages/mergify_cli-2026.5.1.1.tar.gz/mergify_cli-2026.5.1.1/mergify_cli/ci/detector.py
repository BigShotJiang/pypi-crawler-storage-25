from __future__ import annotations

import os
import pathlib
import re
import typing
from urllib import parse

from mergify_cli import utils


GIT_BRANCH_PREFIXES = ("origin/", "refs/heads/")

CIProviderT = typing.Literal["github_actions", "circleci", "jenkins", "buildkite"]


def get_ci_provider() -> CIProviderT | None:
    if os.getenv("JENKINS_URL"):
        return "jenkins"
    if os.getenv("GITHUB_ACTIONS") == "true":
        return "github_actions"
    if os.getenv("CIRCLECI") == "true":
        return "circleci"
    if os.getenv("BUILDKITE") == "true":
        return "buildkite"
    return None


def get_pipeline_name() -> str | None:
    match get_ci_provider():
        case "github_actions":
            return os.getenv("GITHUB_WORKFLOW")
        case "jenkins":
            return os.getenv("JOB_NAME")
        case "buildkite":
            return os.getenv("BUILDKITE_PIPELINE_SLUG")

    return None


def get_job_name() -> str | None:
    match get_ci_provider():
        case "github_actions":
            return os.getenv("GITHUB_JOB")
        case "circleci":
            return os.getenv("CIRCLE_JOB")
        case "jenkins":
            return os.getenv("JOB_NAME")
        case "buildkite":
            return os.getenv("BUILDKITE_LABEL") or os.getenv("BUILDKITE_STEP_KEY")
        case _:
            return None


def get_github_actions_head_ref_name() -> str | None:
    """Get the branch name for GitHub Actions.

    `GITHUB_HEAD_REF` contains the actual branch name for PRs, while
    `GITHUB_REF_NAME` contains `<pr_number>/merge`. However, `GITHUB_HEAD_REF`
    is only set for PR events, so we fall back to `GITHUB_REF_NAME`.
    """
    return os.getenv("GITHUB_HEAD_REF") or os.getenv("GITHUB_REF_NAME")


def get_jenkins_head_ref_name() -> str | None:
    branch = os.getenv("GIT_BRANCH")
    if branch:
        # NOTE(sileht): it's not 100% bullet proof but since it's very complicated
        # and unlikely to change/add a remote with Jenkins Git/GitHub plugins,
        # we just handle the most common cases.
        for prefix in GIT_BRANCH_PREFIXES:
            if branch.startswith(prefix):
                return branch[len(prefix) :]
        return branch
    return None


def get_head_ref_name() -> str | None:
    match get_ci_provider():
        case "github_actions":
            return get_github_actions_head_ref_name()
        case "circleci":
            return os.getenv("CIRCLE_BRANCH")
        case "jenkins":
            return get_jenkins_head_ref_name()
        case "buildkite":
            return os.getenv("BUILDKITE_BRANCH")
        case _:
            return None


def get_github_actions_head_sha() -> str | None:
    if os.getenv("GITHUB_EVENT_NAME") == "pull_request":
        try:
            _, event = utils.get_github_event()
        except utils.GitHubEventNotFoundError:
            pass
        else:
            if event.pull_request and event.pull_request.head:
                return event.pull_request.head.sha
    return os.getenv("GITHUB_SHA")


async def get_circle_ci_head_sha() -> str | None:
    if (pull_url := os.getenv("CIRCLE_PULL_REQUESTS")) and len(
        pull_url.split(","),
    ) == 1:
        if not (token := os.getenv("GITHUB_TOKEN")):
            msg = (
                "Failed to detect the head sha of the pull request associated"
                " to this run. Please make sure to set a token in the env "
                "variable 'GITHUB_TOKEN' for this purpose."
            )
            raise RuntimeError(msg)

        parsed_url = parse.urlparse(pull_url)
        if parsed_url.netloc == "github.com":
            github_server = "https://api.github.com"
        else:
            github_server = f"{parsed_url.scheme}://{parsed_url.netloc}/api/v3"

        async with utils.get_github_http_client(github_server, token) as client:
            resp = await client.get(f"/repos{parsed_url.path}")

        return str(resp.json()["head"]["sha"])

    return os.getenv("CIRCLE_SHA1")


async def get_head_sha() -> str | None:
    match get_ci_provider():
        case "github_actions":
            return get_github_actions_head_sha()
        case "circleci":
            return await get_circle_ci_head_sha()
        case "jenkins":
            return os.getenv("GIT_COMMIT")
        case "buildkite":
            return os.getenv("BUILDKITE_COMMIT")
        case _:
            return None


def get_cicd_pipeline_runner_name() -> str | None:
    match get_ci_provider():
        case "github_actions":
            return os.getenv("RUNNER_NAME")
        case "jenkins":
            return os.getenv("NODE_NAME")
        case "buildkite":
            return os.getenv("BUILDKITE_AGENT_NAME")
        case _:
            return None


def get_cicd_pipeline_run_id() -> int | str | None:
    match get_ci_provider():
        case "github_actions":
            if "GITHUB_RUN_ID" in os.environ:
                return int(os.environ["GITHUB_RUN_ID"])
        case "circleci":
            if "CIRCLE_WORKFLOW_ID" in os.environ:
                return int(os.environ["CIRCLE_WORKFLOW_ID"])
        case "jenkins":
            return os.getenv("BUILD_ID")
        case "buildkite":
            return os.getenv("BUILDKITE_BUILD_ID")

    return None


def get_cicd_pipeline_run_attempt() -> int | None:
    if get_ci_provider() == "github_actions" and "GITHUB_RUN_ATTEMPT" in os.environ:
        return int(os.environ["GITHUB_RUN_ATTEMPT"])
    if get_ci_provider() == "circleci" and "CIRCLE_BUILD_NUM" in os.environ:
        return int(os.environ["CIRCLE_BUILD_NUM"])
    if get_ci_provider() == "buildkite" and "BUILDKITE_RETRY_COUNT" in os.environ:
        return int(os.environ["BUILDKITE_RETRY_COUNT"])

    return None


def _get_github_repository_from_env(env: str) -> str | None:
    repository_url = os.getenv(env)
    if repository_url is None:
        return None

    # Handle SSH Git URLs like git@github.com:owner/repo.git
    if match := re.match(
        r"git@[\w.-]+:(?P<full_name>[\w.-]+/[\w.-]+)(?:\.git)?/?$",
        repository_url,
    ):
        full_name = match.group("full_name")
        return full_name.removesuffix(".git")

    # Handle HTTPS/HTTP URLs like https://github.com/owner/repo (with optional port)
    if match := re.match(
        r"(https?://[\w.-]+(?::\d+)?/)?(?P<full_name>[\w.-]+/[\w.-]+)/?$",
        repository_url,
    ):
        return match.group("full_name").removesuffix(".git")

    return None


def get_github_pull_request_number() -> int | None:
    match get_ci_provider():
        case "github_actions":
            try:
                _, event = utils.get_github_event()
            except utils.GitHubEventNotFoundError:
                return None
            if event.pull_request is None:
                return None
            return event.pull_request.number

        case "buildkite":
            pr = os.getenv("BUILDKITE_PULL_REQUEST")
            if pr and pr != "false":
                return int(pr)
            return None

        case _:
            return None


def get_github_repository() -> str | None:
    match get_ci_provider():
        case "github_actions":
            return os.getenv("GITHUB_REPOSITORY")
        case "circleci":
            return _get_github_repository_from_env("CIRCLE_REPOSITORY_URL")
        case "jenkins":
            return _get_github_repository_from_env("GIT_URL")
        case "buildkite":
            return _get_github_repository_from_env("BUILDKITE_REPO")
        case _:
            return None


def get_tests_target_branch() -> str | None:
    match get_ci_provider():
        case "github_actions":
            return (
                os.getenv("GITHUB_BASE_REF")
                or os.getenv("GITHUB_HEAD_REF")
                or os.getenv("GITHUB_REF_NAME")
                or os.getenv("GITHUB_REF")
            )
        case "buildkite":
            return os.getenv("BUILDKITE_PULL_REQUEST_BASE_BRANCH") or os.getenv(
                "BUILDKITE_BRANCH",
            )
        case "circleci":
            return os.getenv("CIRCLE_BRANCH")
        case "jenkins":
            return os.getenv("CHANGE_TARGET") or get_jenkins_head_ref_name()
        case _:
            return None


MERGIFY_CONFIG_PATHS = (
    ".mergify.yml",
    ".mergify/config.yml",
    ".github/mergify.yml",
)


def get_mergify_config_path() -> str | None:
    """Detect the Mergify configuration file path.

    Looks for the config file in these locations in order:
    - .mergify.yml
    - .mergify/config.yml
    - .github/mergify.yml

    Returns None if no config file is found.
    """
    for config_path in MERGIFY_CONFIG_PATHS:
        if pathlib.Path(config_path).is_file():
            return config_path
    return None
