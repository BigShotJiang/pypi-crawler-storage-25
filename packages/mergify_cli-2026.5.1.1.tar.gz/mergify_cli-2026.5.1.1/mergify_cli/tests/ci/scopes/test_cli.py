from __future__ import annotations

import json
from typing import TYPE_CHECKING
from unittest import mock

import pytest
import respx
import yaml

from mergify_cli.ci.git_refs import detector as git_refs_detector
from mergify_cli.ci.scopes import cli
from mergify_cli.ci.scopes import config
from mergify_cli.ci.scopes import exceptions


if TYPE_CHECKING:
    import pathlib


def test_from_yaml_with_extras_ignored(tmp_path: pathlib.Path) -> None:
    config_file = tmp_path / "config.yml"
    config_file.write_text(
        yaml.dump(
            {
                "defaults": {},
                "queue_rules": [],
                "pull_request_rules": [],
                "partitions_rules": [],
                "scopes": {
                    "source": {
                        "files": {
                            "backend": {"include": ["api/**/*.py", "backend/**/*.py"]},
                            "frontend": {"include": ["ui/**/*.js", "ui/**/*.tsx"]},
                            "docs": {"include": ["*.md", "docs/**/*"]},
                        },
                    },
                },
            },
        ),
    )

    cfg = config.Config.from_yaml(str(config_file))
    assert cfg.model_dump() == {
        "scopes": {
            "source": {
                "files": {
                    "backend": {
                        "include": ("api/**/*.py", "backend/**/*.py"),
                        "exclude": (),
                    },
                    "frontend": {
                        "include": ("ui/**/*.js", "ui/**/*.tsx"),
                        "exclude": (),
                    },
                    "docs": {"include": ("*.md", "docs/**/*"), "exclude": ()},
                },
            },
            "merge_queue_scope": "merge-queue",
        },
    }


def test_from_yaml_valid(tmp_path: pathlib.Path) -> None:
    config_file = tmp_path / "config.yml"
    config_file.write_text(
        yaml.dump(
            {
                "scopes": {
                    "source": {
                        "files": {
                            "backend": {"include": ["api/**/*.py", "backend/**/*.py"]},
                            "frontend": {"include": ["ui/**/*.js", "ui/**/*.tsx"]},
                            "docs": {"include": ["*.md", "docs/**/*"]},
                        },
                    },
                },
            },
        ),
    )

    cfg = config.Config.from_yaml(str(config_file))
    assert cfg.model_dump() == {
        "scopes": {
            "merge_queue_scope": "merge-queue",
            "source": {
                "files": {
                    "backend": {
                        "include": ("api/**/*.py", "backend/**/*.py"),
                        "exclude": (),
                    },
                    "frontend": {
                        "include": ("ui/**/*.js", "ui/**/*.tsx"),
                        "exclude": (),
                    },
                    "docs": {"include": ("*.md", "docs/**/*"), "exclude": ()},
                },
            },
        },
    }


def test_from_yaml_invalid_config(tmp_path: pathlib.Path) -> None:
    config_file = tmp_path / "config.yml"
    config_file.write_text(
        yaml.dump({"scopes": {"source": {"files": {"Back#end-API": ["api/**/*.py"]}}}}),
    )

    # Bad name and missing dict
    with pytest.raises(config.ConfigInvalidError, match="4 validation errors"):
        config.Config.from_yaml(str(config_file))


def test_match_scopes_basic() -> None:
    cfg = config.Config.from_dict(
        {
            "scopes": {
                "source": {
                    "files": {
                        "backend": {"include": ("api/**/*.py", "backend/**/*.py")},
                        "frontend": {"include": ("ui/**/*.js", "ui/**/*.tsx")},
                        "docs": {"include": ("*.md", "docs/**/*")},
                    },
                },
            },
        },
    )
    files = ["api/models.py", "ui/components/Button.tsx", "README.md", "other.txt"]

    assert cfg.scopes.source is not None
    assert isinstance(cfg.scopes.source, config.SourceFiles)
    scopes_hit, per_scope = cli.match_scopes(files, cfg.scopes.source.files)

    assert scopes_hit == {"backend", "frontend", "docs"}
    assert per_scope == {
        "backend": ["api/models.py"],
        "frontend": ["ui/components/Button.tsx"],
        "docs": ["README.md"],
    }


def test_match_scopes_no_matches() -> None:
    cfg = config.Config.from_dict(
        {
            "scopes": {
                "source": {
                    "files": {
                        "backend": {"include": ("api/**/*.py",)},
                        "frontend": {"include": ("ui/**/*.js",)},
                    },
                },
            },
        },
    )
    files = ["other.txt", "unrelated.cpp"]

    assert cfg.scopes.source is not None
    assert isinstance(cfg.scopes.source, config.SourceFiles)
    scopes_hit, per_scope = cli.match_scopes(files, cfg.scopes.source.files)

    assert scopes_hit == set()
    assert per_scope == {}


def test_match_scopes_multiple_include_single_scope() -> None:
    cfg = config.Config.from_dict(
        {
            "scopes": {
                "source": {
                    "files": {
                        "backend": {"include": ("api/**/*.py", "backend/**/*.py")},
                    },
                },
            },
        },
    )
    files = ["api/models.py", "backend/services.py"]

    assert cfg.scopes.source is not None
    assert isinstance(cfg.scopes.source, config.SourceFiles)
    scopes_hit, per_scope = cli.match_scopes(files, cfg.scopes.source.files)

    assert scopes_hit == {"backend"}
    assert per_scope == {
        "backend": ["api/models.py", "backend/services.py"],
    }


def test_match_scopes_with_negation_include() -> None:
    cfg = config.Config.from_dict(
        {
            "scopes": {
                "source": {
                    "files": {
                        "backend": {
                            "include": ("api/**/*.py",),
                            "exclude": ("api/**/test_*.py",),
                        },
                        "frontend": {
                            "include": ("ui/**/*.js",),
                            "exclude": ("ui/**/*.spec.js",),
                        },
                    },
                },
            },
        },
    )
    files = [
        "api/models.py",
        "api/test_models.py",
        "ui/components.js",
        "ui/components.spec.js",
    ]

    assert cfg.scopes.source is not None
    assert isinstance(cfg.scopes.source, config.SourceFiles)
    scopes_hit, per_scope = cli.match_scopes(files, cfg.scopes.source.files)

    assert scopes_hit == {"backend", "frontend"}
    assert per_scope == {
        "backend": ["api/models.py"],  # test_models.py excluded by negation
        "frontend": ["ui/components.js"],  # components.spec.js excluded by negation
    }


def test_match_scopes_negation_only() -> None:
    cfg = config.Config.from_dict(
        {
            "scopes": {
                "source": {
                    "files": {
                        "exclude_images": {
                            "include": ("**/*",),
                            "exclude": ("**/*.jpeg", "**/*.png"),
                        },
                    },
                },
            },
        },
    )
    files = ["image.jpeg", "document.txt", "photo.png", "readme.md"]

    assert cfg.scopes.source is not None
    assert isinstance(cfg.scopes.source, config.SourceFiles)
    scopes_hit, per_scope = cli.match_scopes(files, cfg.scopes.source.files)

    assert scopes_hit == {"exclude_images"}
    assert per_scope == {
        "exclude_images": ["document.txt", "readme.md"],  # images excluded
    }


def test_match_scopes_mixed_with_complex_negation() -> None:
    cfg = config.Config.from_dict(
        {
            "scopes": {
                "source": {
                    "files": {
                        "backend": {
                            "include": ("**/*.py",),
                            "exclude": ("**/test_*.py", "**/*_test.py"),
                        },
                    },
                },
            },
        },
    )
    files = [
        "src/models.py",
        "src/test_models.py",
        "src/models_test.py",
        "tests/integration_test.py",
        "main.py",
    ]

    assert cfg.scopes.source is not None
    assert isinstance(cfg.scopes.source, config.SourceFiles)
    scopes_hit, per_scope = cli.match_scopes(files, cfg.scopes.source.files)

    assert scopes_hit == {"backend"}
    assert per_scope == {
        "backend": ["src/models.py", "main.py"],  # test files excluded
    }


def test_maybe_write_github_outputs(
    tmp_path: pathlib.Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output_file = tmp_path / "github_output"
    monkeypatch.setenv("GITHUB_OUTPUT", str(output_file))

    all_scopes = ["backend", "frontend", "docs"]
    scopes_hit = {"backend", "docs"}

    with mock.patch("uuid.uuid4", return_value="fixed-uuid"):
        cli.maybe_write_github_outputs(all_scopes, scopes_hit)

    content = output_file.read_text()
    expected = """scopes<<ghadelimiter_fixed-uuid
{"backend": "true", "docs": "true", "frontend": "false"}
ghadelimiter_fixed-uuid
"""
    assert content == expected


def test_maybe_write_github_step_summary(
    tmp_path: pathlib.Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output_file = tmp_path / "github_step_summary"
    monkeypatch.setenv("GITHUB_STEP_SUMMARY", str(output_file))

    all_scopes = ["backend", "frontend", "docs"]
    scopes_hit = {"backend", "docs"}

    cli.maybe_write_github_step_summary(
        git_refs_detector.References(
            "da26838azertyuiopqsdfghjkxcvbn",
            "HEAD",
            "github_event_pull_request",
        ),
        all_scopes,
        scopes_hit,
    )

    content = output_file.read_text()
    expected = """## Mergify CI Scope Matching Results for `da26838...HEAD` (source: `github_event_pull_request`)

| 🎯 Scope | ✅ Match |
|:--|:--|
| `backend` | ✅ |
| `docs` | ✅ |
| `frontend` | ❌ |
"""
    assert content == expected


def test_maybe_write_github_outputs_no_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("GITHUB_OUTPUT", raising=False)

    # Should not raise any exception
    cli.maybe_write_github_outputs(["backend"], {"backend"})


def test_maybe_write_buildkite_metadata(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("BUILDKITE", "true")

    with mock.patch("subprocess.check_call") as mock_check_call:
        cli.maybe_write_buildkite_metadata(
            ["backend", "frontend", "docs"],
            {"backend", "docs"},
        )

    mock_check_call.assert_called_once_with(
        [
            "buildkite-agent",
            "meta-data",
            "set",
            "mergify-ci.scopes",
            '{"backend": "true", "docs": "true", "frontend": "false"}',
        ],
    )


def test_maybe_write_buildkite_metadata_not_buildkite(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("BUILDKITE", raising=False)

    with mock.patch("subprocess.check_call") as mock_check_call:
        cli.maybe_write_buildkite_metadata(["backend"], {"backend"})

    mock_check_call.assert_not_called()


def test_maybe_write_buildkite_annotation_no_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("BUILDKITE", raising=False)

    with mock.patch("subprocess.run") as mock_run:
        cli.maybe_write_buildkite_annotation(
            git_refs_detector.References("old", "new", "github_event_pull_request"),
            ["backend"],
            {"backend"},
        )

    mock_run.assert_not_called()


def test_maybe_write_buildkite_annotation_runs_both_scopes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("BUILDKITE", "true")

    with mock.patch("subprocess.run") as mock_run:
        cli.maybe_write_buildkite_annotation(
            git_refs_detector.References(
                "da26838azertyuiopqsdfghjkxcvbn",
                "HEAD",
                "github_event_pull_request",
            ),
            ["backend", "frontend", "docs"],
            {"backend", "docs"},
        )

    expected_markdown = """## Mergify CI Scope Matching Results for `da26838...HEAD` (source: `github_event_pull_request`)

| 🎯 Scope | ✅ Match |
|:--|:--|
| `backend` | ✅ |
| `docs` | ✅ |
| `frontend` | ❌ |
"""

    assert mock_run.call_count == 2

    job_call, build_call = mock_run.call_args_list
    assert job_call.args[0] == [
        "buildkite-agent",
        "annotate",
        "--style",
        "info",
        "--context",
        "mergify-ci-scopes",
        "--scope=job",
    ]
    assert job_call.kwargs["input"] == expected_markdown
    assert job_call.kwargs["check"] is True
    assert job_call.kwargs["text"] is True

    assert build_call.args[0] == [
        "buildkite-agent",
        "annotate",
        "--style",
        "info",
        "--context",
        "mergify-ci-scopes",
    ]
    assert build_call.kwargs["input"] == expected_markdown


def test_maybe_write_buildkite_annotation_warns_on_failure(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    import subprocess

    monkeypatch.setenv("BUILDKITE", "true")

    def boom(
        cmd: list[str],
        **_: object,
    ) -> None:
        raise subprocess.CalledProcessError(
            returncode=1,
            cmd=cmd,
            stderr="buildkite-agent: boom\n",
        )

    with mock.patch("subprocess.run", side_effect=boom):
        # Must not raise
        cli.maybe_write_buildkite_annotation(
            git_refs_detector.References("old", "new", "github_event_pull_request"),
            ["backend"],
            {"backend"},
        )

    captured = capsys.readouterr()
    assert (
        "warning: failed to write Buildkite annotation (job scope): buildkite-agent: boom"
        in captured.err
    )
    assert (
        "warning: failed to write Buildkite annotation (build scope): buildkite-agent: boom"
        in captured.err
    )


def test_maybe_write_buildkite_annotation_warns_on_missing_binary(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("BUILDKITE", "true")

    with mock.patch("subprocess.run", side_effect=FileNotFoundError("no such binary")):
        cli.maybe_write_buildkite_annotation(
            git_refs_detector.References("old", "new", "github_event_pull_request"),
            ["backend"],
            {"backend"},
        )

    captured = capsys.readouterr()
    assert (
        "warning: failed to write Buildkite annotation (job scope): no such binary"
        in captured.err
    )
    assert (
        "warning: failed to write Buildkite annotation (build scope): no such binary"
        in captured.err
    )


@mock.patch("mergify_cli.ci.scopes.changed_files.git_changed_files")
@mock.patch("mergify_cli.ci.scopes.cli.maybe_write_github_outputs")
def test_detect_with_matches(
    mock_github_outputs: mock.Mock,
    mock_git_changed: mock.Mock,
    tmp_path: pathlib.Path,
) -> None:
    # Setup config file
    config_data = {
        "scopes": {
            "source": {
                "files": {
                    "backend": {"include": ["api/**/*.py"]},
                    "frontend": {"include": ["api/**/*.js"]},
                },
            },
        },
    }
    config_file = tmp_path / "mergify-ci.yml"
    config_file.write_text(yaml.dump(config_data))

    # Setup mocks
    mock_git_changed.return_value = ["api/models.py", "other.txt"]

    # Capture output
    with mock.patch("click.echo") as mock_echo:
        result = cli.detect(
            str(config_file),
            references=git_refs_detector.References("old", "new", "merge_queue"),
        )

    # Verify calls
    mock_git_changed.assert_called_once_with("old", "new")
    mock_github_outputs.assert_called_once()

    # Verify output
    calls = [call.args[0] for call in mock_echo.call_args_list]
    assert "Base: old" in calls
    assert "Head: new" in calls
    assert "Scopes touched:" in calls
    assert "- backend" in calls
    assert "- merge-queue" in calls

    assert result.scopes == {"backend", "merge-queue"}


@mock.patch("mergify_cli.ci.scopes.cli.maybe_write_github_outputs")
def test_detect_manual(
    _: mock.Mock,
    tmp_path: pathlib.Path,
) -> None:
    # Setup config file
    config_data = {
        "scopes": {"source": {"manual": None}},
    }
    config_file = tmp_path / ".mergify-ci.yml"
    config_file.write_text(yaml.dump(config_data))

    # Capture output
    with pytest.raises(
        exceptions.ScopesError,
        match="source `manual` has been set, scopes must be sent with `scopes-send` or API",
    ):
        cli.detect(
            str(config_file),
            references=git_refs_detector.References(
                "old",
                "new",
                "github_event_pull_request",
            ),
        )


@mock.patch("mergify_cli.ci.scopes.cli.maybe_write_github_outputs")
def test_detect_no_base(
    _: mock.Mock,
    tmp_path: pathlib.Path,
) -> None:
    # Setup config file
    config_data = {
        "scopes": {
            "source": {
                "files": {
                    "backend": {"include": ["api/**/*.py"]},
                    "frontend": {"include": ["web/**/*.js"]},
                },
            },
        },
    }
    config_file = tmp_path / ".mergify-ci.yml"
    config_file.write_text(yaml.dump(config_data))

    # Capture output
    with mock.patch("click.echo") as mock_echo:
        result = cli.detect(
            str(config_file),
            references=git_refs_detector.References(
                None,
                "HEAD",
                "fallback_last_commit",
            ),
        )

    # Verify output
    calls = [call.args[0] for call in mock_echo.call_args_list]
    assert "Head: HEAD" in calls
    assert "Source: fallback_last_commit" in calls
    assert "Scopes touched:" in calls
    assert "- backend" in calls
    assert "- frontend" in calls
    assert "No base provided, selecting all scopes" in calls
    assert result.scopes == {"backend", "frontend"}


@mock.patch("mergify_cli.ci.scopes.changed_files.git_changed_files")
@mock.patch("mergify_cli.ci.scopes.cli.maybe_write_github_outputs")
def test_detect_no_matches(
    _: mock.Mock,
    mock_git_changed: mock.Mock,
    tmp_path: pathlib.Path,
) -> None:
    # Setup config file
    config_data = {
        "scopes": {"source": {"files": {"backend": {"include": ["api/**/*.py"]}}}},
    }
    config_file = tmp_path / ".mergify-ci.yml"
    config_file.write_text(yaml.dump(config_data))

    # Setup mocks
    mock_git_changed.return_value = ["other.txt"]

    # Capture output
    with mock.patch("click.echo") as mock_echo:
        result = cli.detect(
            str(config_file),
            references=git_refs_detector.References(
                "old",
                "new",
                "github_event_pull_request",
            ),
        )

    # Verify output
    calls = [call.args[0] for call in mock_echo.call_args_list]
    assert "Base: old" in calls
    assert "Head: new" in calls
    assert "No scopes matched." in calls
    assert result.scopes == set()


def test_match_scopes_invalid() -> None:
    with pytest.raises(config.ConfigInvalidError, match="4 validation errors"):
        config.Config.from_dict(
            {
                "scopes": {
                    "source": {
                        "files": {
                            "backend": {"includes": ("api/**/*.py",)},
                            "frontend": {"includes": ("ui/**/*.js",)},
                        },
                    },
                },
            },
        )


@mock.patch("mergify_cli.ci.scopes.changed_files.git_changed_files")
def test_detect_debug_output(
    mock_git_changed: mock.Mock,
    tmp_path: pathlib.Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Setup debug environment
    monkeypatch.setenv("ACTIONS_STEP_DEBUG", "true")

    # Setup config file
    config_data = {
        "scopes": {"source": {"files": {"backend": {"include": ["api/**/*.py"]}}}},
    }
    config_file = tmp_path / ".mergify-ci.yml"
    config_file.write_text(yaml.dump(config_data))

    # Setup mocks
    mock_git_changed.return_value = ["api/models.py", "api/views.py"]

    # Capture output
    with mock.patch("click.echo") as mock_echo:
        result = cli.detect(
            str(config_file),
            references=git_refs_detector.References(
                "old",
                "new",
                "github_event_pull_request",
            ),
        )
    # Verify debug output includes file details
    calls = [call.args[0] for call in mock_echo.call_args_list]
    assert any("    api/models.py" in call for call in calls)
    assert any("    api/views.py" in call for call in calls)

    assert result.scopes == {"backend"}


async def test_upload_scopes(respx_mock: respx.MockRouter) -> None:
    api_url = "https://api.mergify.test"
    token = "test-token"
    repository = "owner/repo"
    pull_request = 123

    # Mock the HTTP request
    route = respx_mock.post(
        f"{api_url}/v1/repos/{repository}/pulls/{pull_request}/scopes",
    ).mock(
        return_value=respx.MockResponse(200, json={"status": "ok"}),
    )

    # Call the upload function
    await cli.send_scopes(
        api_url,
        token,
        repository,
        pull_request,
        ["backend", "frontend"],
    )

    # Verify the request was made
    assert route.called
    assert route.call_count == 1

    # Verify the request body
    request = route.calls[0].request
    assert request.headers["Authorization"] == "Bearer test-token"
    assert request.headers["Accept"] == "application/json"

    # Verify the JSON payload
    payload = json.loads(request.content)
    assert payload == {"scopes": ["backend", "frontend"]}


def test_dump(tmp_path: pathlib.Path) -> None:
    config_file = tmp_path / "scopes.json"
    saved = cli.DetectedScope(
        scopes={"backend", "merge-queue"},
    )
    saved.save_to_file(str(config_file))

    loaded = cli.DetectedScope.load_from_file(str(config_file))
    assert loaded.scopes == saved.scopes
