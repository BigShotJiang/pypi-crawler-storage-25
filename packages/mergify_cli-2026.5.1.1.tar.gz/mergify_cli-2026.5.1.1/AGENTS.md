# Agent Instructions

## CLI Output Style

Use compact Unicode symbols for terminal output, not emoji. This keeps new and
updated terminal output consistent and avoids rendering issues across terminals.

**Preferred symbols:**
- `✓` success, approved, merged
- `✗` failure, conflict, changes requested
- `●` active, pending, in progress
- `○` inactive, skipped, none
- `—` unknown, not applicable

**Avoid in terminal output:** `✅`, `❌`, `🟢`, `🔴`, `📝`, `⚠️`, `🔄`, `📦`, `🤖`, `🔗`
and other emoji. They can render at inconsistent widths across terminals and
break column alignment.

**Exceptions — emoji are acceptable in:**
- Markdown output destined for GitHub (PR comments, CI summaries)
- CI log output (`ci junit-process`, `ci scopes`) — these are read in CI
  runners (GitHub Actions, CircleCI, etc.) where emoji render consistently
  and improve log scanability

## Error Messages

Use `console_error(message)` from `mergify_cli` for all user-facing error
messages. It prints `error: {message}` in red with `markup=False` (safe for
user data containing `[`/`]`). Keep the message
lowercase after `error:` (the function adds the prefix).

```python
from mergify_cli import console_error

console_error("commit not found")          # -> "error: commit not found"
console_error(f"failed to fetch: {e}")     # -> "error: failed to fetch: ..."
```

For follow-up hints after an error, use plain `console.print()`:
```python
console_error("rebase failed — there may be conflicts")
console.print("Resolve conflicts then run: git rebase --continue")
```

Do **not** use `console.print(..., style="red")` or `[red]...[/]` markup
for error messages — use `console_error()` instead.

## Success Messages

End success messages with a period:
```python
console.print("[green]Freeze created successfully.[/]")
console.print("Stack reordered successfully.", style="green")
```

## JSON Output

Commands with `--json` flags must write JSON to **stdout** using
`click.echo()`, not `console.print()` (which may add Rich formatting).
This ensures clean output pipeable to `jq` and other tools.

```python
if output_json:
    click.echo(json.dumps(data, indent=2))
```

## Command Groups

All top-level command groups must use `DYMGroup` (from `mergify_cli.dym`)
with `invoke_without_command=True` for consistent "did you mean?"
suggestions. Add an explicit `click.echo(ctx.get_help())` in the group
callback when `ctx.invoked_subcommand is None` for help display.

## Documentation

When adding or changing a CLI feature, always update the documentation:

1. **README.md** — keep the Features and Usage sections current with all
   top-level commands and a brief description of what each does.
2. **Skills** (`skills/` directory) — if the feature is something an AI agent
   should know how to use, ensure a corresponding SKILL.md exists and covers it.
   Update existing skills when command signatures or workflows change.

Documentation updates should be part of the same commit/PR as the feature
change, not a follow-up.
