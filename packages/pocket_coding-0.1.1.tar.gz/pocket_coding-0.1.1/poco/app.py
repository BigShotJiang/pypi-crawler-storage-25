#!/usr/bin/env python3
import argparse
import json
import logging
import os
import sys
import threading
import time
from collections import deque
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Optional

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Vertical, VerticalScroll
from textual.widgets import Checkbox, ContentSwitcher, Input, Label, Log, Static

from .bridge import AppConfig, BridgeApp


LOG = logging.getLogger("poco")
CONFIG_DIR = Path.home() / ".config" / "poco"
CONFIG_PATH = CONFIG_DIR / "config.json"
STATE_DIR = Path.home() / ".local" / "state" / "poco"
THREAD_STATE_PATH = STATE_DIR / "threads.json"
WORKER_STATE_PATH = STATE_DIR / "workers.json"

DEFAULT_CONFIG: Dict[str, Any] = {
    "feishu": {
        "app_id": "",
        "app_secret": "",
        "encrypt_key": "",
        "verification_token": "",
        "allowed_open_ids": [],
        "allow_all_users": True,
    },
    "codex": {
        "bin": "codex",
        "app_server_args": "",
        "model": "",
        "approval_policy": "never",
        "sandbox": "danger-full-access",
    },
    "bridge": {
        "message_limit": 1400,
        "live_update_initial_seconds": 1,
        "live_update_max_seconds": 8,
        "max_message_edits": 18,
    },
}

INPUT_IDS = {
    "feishu.app_id": "feishu_app_id",
    "feishu.app_secret": "feishu_app_secret",
    "feishu.encrypt_key": "feishu_encrypt_key",
    "feishu.verification_token": "feishu_verification_token",
    "feishu.allowed_open_ids": "feishu_allowed_open_ids",
    "codex.bin": "codex_bin",
    "codex.app_server_args": "codex_app_server_args",
    "codex.model": "codex_model",
    "codex.approval_policy": "codex_approval_policy",
    "codex.sandbox": "codex_sandbox",
    "bridge.message_limit": "bridge_message_limit",
    "bridge.live_update_initial_seconds": "bridge_live_update_initial_seconds",
    "bridge.live_update_max_seconds": "bridge_live_update_max_seconds",
    "bridge.max_message_edits": "bridge_max_message_edits",
}

CONFIG_KEY_ALIASES = {
    "app_id": "feishu.app_id",
    "app_secret": "feishu.app_secret",
    "encrypt_key": "feishu.encrypt_key",
    "verification_token": "feishu.verification_token",
    "allowed_open_ids": "feishu.allowed_open_ids",
    "allow_all_users": "feishu.allow_all_users",
    "codex_bin": "codex.bin",
    "app_server_args": "codex.app_server_args",
    "model": "codex.model",
    "approval_policy": "codex.approval_policy",
    "sandbox": "codex.sandbox",
    "message_limit": "bridge.message_limit",
    "live_update_initial_seconds": "bridge.live_update_initial_seconds",
    "live_update_max_seconds": "bridge.live_update_max_seconds",
    "max_message_edits": "bridge.max_message_edits",
}


def deep_merge(base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
    merged = deepcopy(base)
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def mask_secret(value: str) -> str:
    if len(value) <= 6:
        return "*" * len(value)
    return value[:3] + "*" * (len(value) - 6) + value[-3:]


def config_ready(config: Dict[str, Any]) -> bool:
    feishu = config["feishu"]
    return bool(feishu["app_id"] and feishu["app_secret"])


def ensure_dirs() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    STATE_DIR.mkdir(parents=True, exist_ok=True)


def set_nested(config: Dict[str, Any], path: str, value: Any) -> Dict[str, Any]:
    parts = path.split(".")
    current = config
    for part in parts[:-1]:
        current = current.setdefault(part, {})
    current[parts[-1]] = value
    return config


def get_nested(config: Dict[str, Any], path: str) -> Any:
    value: Any = config
    for part in path.split("."):
        value = value[part]
    return value


def normalize_config_key(key: str) -> str:
    normalized = key.strip()
    if not normalized:
        raise ValueError("配置项不能为空。")
    return CONFIG_KEY_ALIASES.get(normalized, normalized)


def parse_config_value(path: str, raw: str) -> Any:
    value = raw.strip()
    if path == "feishu.allowed_open_ids":
        return [item.strip() for item in value.split(",") if item.strip()]
    if path == "feishu.allow_all_users":
        lowered = value.lower()
        if lowered in {"1", "true", "yes", "on"}:
            return True
        if lowered in {"0", "false", "no", "off"}:
            return False
        raise ValueError(f"{path} 必须是 true/false。")
    if path.startswith("bridge."):
        try:
            return int(value)
        except ValueError as exc:
            raise ValueError(f"{path} 必须是整数。") from exc
    return value


class ConfigStore:
    def __init__(self, path: Path) -> None:
        self._path = path
        self._lock = threading.Lock()

    def load(self) -> Dict[str, Any]:
        with self._lock:
            if not self._path.exists():
                return deepcopy(DEFAULT_CONFIG)
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            return deep_merge(DEFAULT_CONFIG, raw)

    def save(self, config: Dict[str, Any]) -> None:
        with self._lock:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._path.write_text(
                json.dumps(config, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            try:
                os.chmod(self._path, 0o600)
            except Exception:
                LOG.exception("Failed to chmod config file")

    def masked(self) -> Dict[str, Any]:
        config = self.load()
        masked = deepcopy(config)
        if masked["feishu"]["app_secret"]:
            masked["feishu"]["app_secret"] = mask_secret(masked["feishu"]["app_secret"])
        return masked


class RingLogHandler(logging.Handler):
    def __init__(self, limit: int = 500) -> None:
        super().__init__()
        self._records = deque(maxlen=limit)
        self._lock = threading.Lock()

    def emit(self, record: logging.LogRecord) -> None:
        message = self.format(record)
        payload = {
            "time": int(record.created),
            "level": record.levelname,
            "logger": record.name,
            "message": message,
        }
        with self._lock:
            self._records.append(payload)

    def snapshot(self, limit: int = 500) -> list[dict]:
        with self._lock:
            return list(self._records)[-limit:]


class BridgeRunner:
    def __init__(self) -> None:
        self._thread: Optional[threading.Thread] = None
        self._last_error: str = ""
        self._started_at: Optional[float] = None
        self._lock = threading.Lock()

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "running": self._thread is not None and self._thread.is_alive(),
                "started_at": self._started_at,
                "last_error": self._last_error,
            }

    def start(self, config: Dict[str, Any]) -> bool:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return False
            self._last_error = ""
            app_config = build_app_config(config)
            thread = threading.Thread(
                target=self._run_bridge,
                args=(app_config,),
                daemon=True,
                name="poco-bridge",
            )
            self._thread = thread
            self._started_at = time.time()
            thread.start()
            return True

    def _run_bridge(self, config: AppConfig) -> None:
        try:
            bridge = BridgeApp(config)
            bridge.run()
        except Exception as exc:
            with self._lock:
                self._last_error = str(exc)
            LOG.exception("Bridge runtime crashed")


def build_app_config(config: Dict[str, Any]) -> AppConfig:
    feishu = config["feishu"]
    codex = config["codex"]
    bridge = config["bridge"]
    return AppConfig(
        feishu_app_id=feishu["app_id"],
        feishu_app_secret=feishu["app_secret"],
        feishu_encrypt_key=feishu["encrypt_key"],
        feishu_verification_token=feishu["verification_token"],
        codex_bin=codex["bin"],
        codex_app_server_args=codex["app_server_args"],
        codex_model=codex["model"],
        codex_approval_policy=codex["approval_policy"],
        codex_sandbox=codex["sandbox"],
        message_limit=int(bridge["message_limit"]),
        live_update_initial_seconds=int(bridge["live_update_initial_seconds"]),
        live_update_max_seconds=int(bridge["live_update_max_seconds"]),
        max_message_edits=int(bridge["max_message_edits"]),
        allowed_open_ids=set(feishu["allowed_open_ids"]),
        allow_all_users=bool(feishu["allow_all_users"]),
        thread_state_path=str(THREAD_STATE_PATH),
        worker_state_path=str(WORKER_STATE_PATH),
    )


class PoCoService:
    def __init__(self, store: ConfigStore, logs: RingLogHandler) -> None:
        self.store = store
        self.logs = logs
        self.bridge = BridgeRunner()

    def load_config(self) -> Dict[str, Any]:
        return self.store.load()

    def save_config(self, config: Dict[str, Any]) -> None:
        self.store.save(config)

    def masked_config(self) -> Dict[str, Any]:
        return self.store.masked()

    def bridge_status(self) -> Dict[str, Any]:
        return self.bridge.status()

    def set_config_value(self, key: str, raw_value: str) -> tuple[str, Any]:
        path = normalize_config_key(key)
        if path not in INPUT_IDS and path not in {"feishu.allow_all_users"}:
            raise ValueError(f"未知配置项：{key}")
        config = self.load_config()
        value = parse_config_value(path, raw_value)
        set_nested(config, path, value)
        self.save_config(config)
        return path, value

    def start_bridge(self) -> bool:
        config = self.load_config()
        if not config_ready(config):
            raise ValueError("配置还不完整，至少需要 Feishu App ID 和 App Secret。")
        return self.bridge.start(config)


class PoCoTui(App[None]):
    CSS = """
    Screen {
        layout: vertical;
    }

    #topbar {
        height: auto;
        padding: 0 1;
    }

    #main {
        height: 1fr;
    }

    .panel {
        height: auto;
        padding: 0 1 1 1;
    }

    .field {
        height: auto;
        margin: 0 0 1 0;
    }

    .field Label {
        padding-bottom: 0;
    }

    .section-title {
        padding: 1 0 0 0;
        text-style: bold;
    }

    #config-scroll {
        padding: 0 1 1 1;
    }

    #logs {
        height: 1fr;
    }

    #page_name {
        text-style: bold;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("ctrl+s", "save_config", "Save"),
        Binding("ctrl+r", "save_and_restart", "Save & Restart"),
        Binding("1", "show_dashboard", "Dashboard"),
        Binding("2", "show_config", "Config"),
        Binding("3", "show_logs", "Logs"),
        Binding("f2", "show_dashboard", "Dashboard"),
        Binding("f3", "show_config", "Config"),
        Binding("f4", "show_logs", "Logs"),
    ]

    def __init__(self, service: PoCoService, *, focus_config: bool = False) -> None:
        super().__init__()
        self._service = service
        self._focus_config = focus_config
        self._log_cursor = 0
        self._current_page = "dashboard"

    def compose(self) -> ComposeResult:
        with Container(id="topbar"):
            yield Static("PoCo", id="title")
            yield Static("", id="page_name")
            yield Static(
                "1 Dashboard  2 Config  3 Logs  |  Ctrl+S Save  Ctrl+R Save&Restart  q Quit",
                id="top_hint",
            )
        with ContentSwitcher(initial="dashboard", id="main"):
            with Vertical(id="dashboard"):
                with Container(classes="panel"):
                    yield Static("", id="status_summary")
                with Container(classes="panel"):
                    yield Static("", id="status_hint")
                with Container(classes="panel"):
                    yield Static("", id="status_paths")
            with Vertical(id="config"):
                with VerticalScroll(id="config-scroll"):
                    yield self._section_label("Feishu")
                    yield self._field("App ID", Input(id=INPUT_IDS["feishu.app_id"], placeholder="cli_xxx"))
                    yield self._field(
                        "App Secret",
                        Input(id=INPUT_IDS["feishu.app_secret"], password=True, placeholder="app secret"),
                    )
                    yield self._field("Encrypt Key", Input(id=INPUT_IDS["feishu.encrypt_key"]))
                    yield self._field("Verification Token", Input(id=INPUT_IDS["feishu.verification_token"]))
                    yield self._field(
                        "Allow all users",
                        Checkbox("", id="feishu_allow_all_users"),
                    )
                    yield self._field(
                        "Allowed open_ids",
                        Input(id=INPUT_IDS["feishu.allowed_open_ids"], placeholder="ou_xxx,ou_yyy"),
                    )

                    yield self._section_label("Codex")
                    yield self._field("Codex binary", Input(id=INPUT_IDS["codex.bin"], placeholder="codex"))
                    yield self._field("Model", Input(id=INPUT_IDS["codex.model"], placeholder="optional"))
                    yield self._field("App server args", Input(id=INPUT_IDS["codex.app_server_args"]))
                    yield self._field("Approval policy", Input(id=INPUT_IDS["codex.approval_policy"]))
                    yield self._field("Sandbox", Input(id=INPUT_IDS["codex.sandbox"]))

                    yield self._section_label("Bridge")
                    yield self._field("Message limit", Input(id=INPUT_IDS["bridge.message_limit"]))
                    yield self._field(
                        "Live update initial seconds",
                        Input(id=INPUT_IDS["bridge.live_update_initial_seconds"]),
                    )
                    yield self._field(
                        "Live update max seconds",
                        Input(id=INPUT_IDS["bridge.live_update_max_seconds"]),
                    )
                    yield self._field("Max message edits", Input(id=INPUT_IDS["bridge.max_message_edits"]))
            with Vertical(id="logs-tab"):
                yield Log(id="logs", auto_scroll=True, highlight=True)

    def _section_label(self, text: str) -> Static:
        return Static(text, classes="section-title")

    def _field(self, label: str, widget: Input | Checkbox) -> Vertical:
        return Vertical(Label(label), widget, classes="field")

    def on_mount(self) -> None:
        self.title = "PoCo"
        self.sub_title = "Pocket Coding for Feishu"
        self._load_form_from_config()
        self._set_page_name(self._current_page)
        self._refresh_runtime()
        self.set_interval(1.0, self._refresh_runtime)
        self.call_after_refresh(self._boot)

    def _boot(self) -> None:
        config = self._service.load_config()
        if self._focus_config or not config_ready(config):
            self._activate_tab("config")
            self.notify("需要先完成配置，再启动 bridge。", severity="warning")
            self._focus_first_missing_required_field(config)
            return
        self._service.start_bridge()
        self.notify("PoCo bridge 已启动。", severity="information")

    def _refresh_runtime(self) -> None:
        self._refresh_status()
        self._refresh_logs()

    def _refresh_status(self) -> None:
        config = self._service.load_config()
        bridge = self._service.bridge_status()
        started_at = bridge["started_at"]
        started_display = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(started_at)) if started_at else "-"
        summary = (
            f"config_ready: {config_ready(config)}\n"
            f"bridge_running: {bridge['running']}\n"
            f"bridge_started_at: {started_display}\n"
            f"bridge_last_error: {bridge['last_error'] or '-'}"
        )
        hint = (
            "F2 Dashboard  F3 Config  F4 Logs\n"
            "Ctrl+S 保存配置  Ctrl+R 保存并重启\n"
            "Save & Restart 会重启 PoCo 本身，并按新配置重新启动 bridge。"
        )
        paths = (
            f"config_path: {CONFIG_PATH}\n"
            f"thread_state_path: {THREAD_STATE_PATH}\n"
            f"worker_state_path: {WORKER_STATE_PATH}"
        )
        self.query_one("#status_summary", Static).update(summary)
        self.query_one("#status_hint", Static).update(hint)
        self.query_one("#status_paths", Static).update(paths)

    def _refresh_logs(self) -> None:
        items = self._service.logs.snapshot(limit=500)
        log_widget = self.query_one("#logs", Log)
        if len(items) < self._log_cursor:
            self._log_cursor = 0
            log_widget.clear()
        for item in items[self._log_cursor:]:
            log_widget.write_line(item["message"])
        self._log_cursor = len(items)

    def _load_form_from_config(self) -> None:
        config = self._service.load_config()
        for path, widget_id in INPUT_IDS.items():
            value = self._get_config_value(config, path)
            text = ",".join(value) if isinstance(value, list) else str(value)
            self.query_one(f"#{widget_id}", Input).value = text
        allow_all = bool(config["feishu"]["allow_all_users"])
        self.query_one("#feishu_allow_all_users", Checkbox).value = allow_all
        self.query_one(f"#{INPUT_IDS['feishu.allowed_open_ids']}", Input).disabled = allow_all

    def _config_from_form(self) -> Dict[str, Any]:
        config = deepcopy(DEFAULT_CONFIG)
        for path, widget_id in INPUT_IDS.items():
            raw = self.query_one(f"#{widget_id}", Input).value.strip()
            if path == "feishu.allowed_open_ids":
                value = [item.strip() for item in raw.split(",") if item.strip()]
            elif path.startswith("bridge."):
                try:
                    value = int(raw)
                except ValueError as exc:
                    raise ValueError(f"{path} 必须是整数。") from exc
            else:
                value = raw
            set_nested(config, path, value)
        config["feishu"]["allow_all_users"] = self.query_one("#feishu_allow_all_users", Checkbox).value
        return deep_merge(self._service.load_config(), config)

    def _get_config_value(self, config: Dict[str, Any], path: str) -> Any:
        value: Any = config
        for part in path.split("."):
            value = value[part]
        return value

    def _focus_first_missing_required_field(self, config: Dict[str, Any]) -> None:
        if not config["feishu"]["app_id"]:
            self.query_one(f"#{INPUT_IDS['feishu.app_id']}", Input).focus()
            return
        if not config["feishu"]["app_secret"]:
            self.query_one(f"#{INPUT_IDS['feishu.app_secret']}", Input).focus()
            return
        self.query_one(f"#{INPUT_IDS['codex.bin']}", Input).focus()

    def _activate_tab(self, tab_id: str) -> None:
        self.query_one(ContentSwitcher).current = tab_id
        self._current_page = tab_id
        self._set_page_name(tab_id)

    def _set_page_name(self, tab_id: str) -> None:
        names = {
            "dashboard": "Dashboard",
            "config": "Config",
            "logs-tab": "Logs",
        }
        self.query_one("#page_name", Static).update(names.get(tab_id, tab_id))

    def action_save_config(self) -> None:
        self._save_config()

    def action_save_and_restart(self) -> None:
        self._save_and_restart()

    def action_show_dashboard(self) -> None:
        self._activate_tab("dashboard")

    def action_show_config(self) -> None:
        self._activate_tab("config")

    def action_show_logs(self) -> None:
        self._activate_tab("logs-tab")

    def on_checkbox_changed(self, event: Checkbox.Changed) -> None:
        if event.checkbox.id != "feishu_allow_all_users":
            return
        allowed = self.query_one(f"#{INPUT_IDS['feishu.allowed_open_ids']}", Input)
        allowed.disabled = event.value

    def _save_config(self) -> None:
        try:
            config = self._config_from_form()
        except ValueError as exc:
            self.notify(str(exc), severity="error")
            return
        self._service.save_config(config)
        self._refresh_status()
        self.notify("配置已保存。", severity="information")

    def _save_and_restart(self) -> None:
        try:
            config = self._config_from_form()
        except ValueError as exc:
            self.notify(str(exc), severity="error")
            return
        self._service.save_config(config)
        self.exit("restart")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="PoCo")
    parser.add_argument("--log-level", default="INFO")
    sub = parser.add_subparsers(dest="command")
    config_cmd = sub.add_parser("config", help="open PoCo and focus config tab")
    config_cmd.add_argument("--show", action="store_true", help="show masked config and exit")
    config_cmd.add_argument("key", nargs="?", help="config key, e.g. app_id or feishu.app_id")
    config_cmd.add_argument("value", nargs="?", help="config value")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logging.basicConfig(
        level=getattr(logging, str(getattr(args, "log_level", "INFO")).upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    ensure_dirs()
    root_logger = logging.getLogger()
    ring = RingLogHandler()
    ring.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root_logger.addHandler(ring)

    store = ConfigStore(CONFIG_PATH)
    service = PoCoService(store, ring)

    if args.command == "config" and args.show:
        print(json.dumps(service.masked_config(), ensure_ascii=False, indent=2))
        return
    if args.command == "config" and args.key:
        if args.value is None:
            raise SystemExit("usage: poco config <key> <value>")
        path, _ = service.set_config_value(args.key, args.value)
        current = get_nested(service.masked_config(), path)
        print(json.dumps({path: current}, ensure_ascii=False, indent=2))
        return

    app = PoCoTui(service, focus_config=args.command == "config")
    result = app.run()
    if result == "restart":
        os.execv(sys.executable, [sys.executable, *sys.argv])


if __name__ == "__main__":
    main()
