"""python -m ews_scoreboard init [--force] [--target .]
   python -m ews_scoreboard version"""

import sys


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        from ews_scoreboard import __version__
        print(f"EWS Scoreboard Pipeline v{__version__}")
        print()
        print("Kullanım:")
        print("  python -m ews_scoreboard init [--force] [--target DIR]")
        print("  python -m ews_scoreboard version")
        print()
        print("Komutlar:")
        print("  init       Güncel notebook'ları çalışma dizinine kopyalar.")
        print("             Eski notebook varsa _arsiv/ altına taşır.")
        print("             --force: hash kontrolü yapmadan üzerine yazar.")
        print("             --target DIR: hedef dizin (varsayılan: mevcut dizin)")
        print()
        print("  version    Paket ve notebook versiyonlarını gösterir.")
        print("             Tutarsızlık varsa uyarı verir.")
        print()
        print("Prod güncelleme:")
        print("  pip install --upgrade ews-scoreboard --break-system-packages")
        print("  python -m ews_scoreboard init")
        return

    cmd = args[0]

    if cmd == "version":
        from ews_scoreboard import __version__
        print(f"Paket versiyonu: {__version__}")

        # Notebook versiyonu (varsa)
        from pathlib import Path
        nb_ver_file = Path("db/.nb_version")
        if nb_ver_file.exists():
            nb_ver = nb_ver_file.read_text(encoding="utf-8").strip()
            match = "✓" if nb_ver == __version__ else f"✗ UYUMSUZ (notebook: {nb_ver})"
            print(f"Notebook versiyonu: {nb_ver}  {match}")
        else:
            print("Notebook versiyonu: (init çalışmamış)")

        # tutarlilik_kontrol
        try:
            from ews_scoreboard.motor import tutarlilik_kontrol
            hatalar = tutarlilik_kontrol()
            if hatalar:
                print(f"\nTutarsızlık ({len(hatalar)}):")
                for h in hatalar:
                    print(f"  {h}")
            else:
                print("Tutarlılık: ✓")
        except Exception:
            pass

    elif cmd == "init":
        force = "--force" in args
        target = "."
        if "--target" in args:
            idx = args.index("--target")
            if idx + 1 < len(args):
                target = args[idx + 1]

        from ews_scoreboard import init_workspace
        init_workspace(target_dir=target, force=force)

    elif cmd == "verify":
        from ews_scoreboard.verify_install import verify_all
        db = args[1] if len(args) > 1 else "db/ews.duckdb"
        verify_all(db)

    else:
        print(f"Bilinmeyen komut: {cmd}")
        print("Kullanım: python -m ews_scoreboard [init|version|verify]")
        sys.exit(1)


if __name__ == "__main__":
    main()
