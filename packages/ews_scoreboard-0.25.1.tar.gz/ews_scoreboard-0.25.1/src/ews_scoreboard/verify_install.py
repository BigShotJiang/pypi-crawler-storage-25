"""EWS Scoreboard — Kurulum ve Kaynak Kod Doğrulama.

Kullanım: python -m ews_scoreboard verify [db_path]

Kontroller:
  GRUP 1: Paket bütünlüğü (import, dosya varlığı)
  GRUP 2: Kaynak kod pattern (fix'ler uygulanmış mı)
  GRUP 3: Runtime doğrulama (DB varsa)
  GRUP 4: Ortam uyumluluğu

Hassas veri çıktıya YAZILMAZ.
"""

import sys
import re
import inspect
from pathlib import Path


class Verifier:
    def __init__(self, db_path="db/ews.duckdb"):
        self.db_path = Path(db_path)
        self.fails = []
        self.warns = []
        self.skips = []

    def check(self, name, condition, detail_ok="", detail_fail=""):
        if condition:
            print(f"  ✓ {name}" + (f" — {detail_ok}" if detail_ok else ""))
        else:
            print(f"  ✗ {name}" + (f" — {detail_fail}" if detail_fail else ""))
            self.fails.append(name)

    def warn(self, name, detail=""):
        print(f"  ⚠ {name}" + (f" — {detail}" if detail else ""))
        self.warns.append(name)

    def skip(self, name, detail=""):
        print(f"  ○ {name}" + (f" — {detail}" if detail else ""))
        self.skips.append(name)

    # ═══ GRUP 1: Paket bütünlüğü ═══

    def grup1_paket(self):
        print("\n[GRUP 1] Paket Bütünlüğü")
        modules = [
            ("ews_scoreboard", None),
            ("ews_scoreboard.pipeline.transform", "run_transforms"),
            ("ews_scoreboard.pipeline.marts", "_build_scoreboard"),
            ("ews_scoreboard.pipeline.html_render", "render_html"),
            ("ews_scoreboard.motor", "Motor"),
        ]
        for mod_name, func_name in modules:
            try:
                mod = __import__(mod_name, fromlist=[func_name] if func_name else [])
                if func_name:
                    getattr(mod, func_name)
                self.check(f"import {mod_name.split('.')[-1]}", True)
            except Exception as e:
                self.check(f"import {mod_name.split('.')[-1]}", False,
                           detail_fail=type(e).__name__)

        try:
            import ews_scoreboard
            self.check("versiyon", True, detail_ok=ews_scoreboard.__version__)
        except Exception:
            self.skip("versiyon")

    # ═══ GRUP 2: Kaynak Kod Pattern ═══

    def grup2_kaynak(self):
        print("\n[GRUP 2] Kaynak Kod Kontrolleri")
        try:
            from ews_scoreboard.pipeline import transform
            src_t = inspect.getsource(transform.run_transforms)

            bad_cast = len(re.findall(r'CAST\(muta AS BIGINT\) NOT IN', src_t))
            self.check("transform: VARCHAR CAST", bad_cast == 0,
                        detail_fail=f"{bad_cast} BIGINT CAST")

            self.check("transform: son_12 parse",
                        "son_12" in src_t and "literal_eval" in src_t)

            from ews_scoreboard.pipeline import marts
            src_m = inspect.getsource(marts._build_scoreboard)

            has_normalize = ('astype(str)' in src_m)
            self.check("marts: entity_id normalize", has_normalize)

            chained = re.findall(r'\.fetchdf\(\)\.\w+\[', src_m)
            self.check("marts: fetchdf zincirsiz", len(chained) == 0,
                        detail_fail=f"{len(chained)} zincir")

            from ews_scoreboard.pipeline import html_render
            src_r = inspect.getsource(html_render.render_html)
            self.check("render_html: dict kabul",
                        'isinstance' in src_r and 'dict' in src_r)

        except Exception as e:
            self.check("kaynak kod", False, detail_fail=str(e)[:80])

    # ═══ GRUP 3: Runtime (DB gerekli) ═══

    def grup3_runtime(self):
        print("\n[GRUP 3] Runtime Kontrolleri")
        if not self.db_path.exists():
            self.skip("runtime", "DB yok")
            return

        try:
            import duckdb
            con = duckdb.connect(str(self.db_path), read_only=True)

            tip_map = {}
            for t in ["dim_entity", "fact_periodic", "map_identity"]:
                try:
                    for r in con.execute(f"DESCRIBE {t}").fetchall():
                        if r[0] == "entity_id":
                            tip_map[t] = r[1]
                except Exception:
                    pass

            if tip_map:
                tip_str = ", ".join(f"{t}={v}" for t, v in tip_map.items())
                self.check("entity_id tipler", True, detail_ok=tip_str)

                try:
                    con.execute("""
                        SELECT COUNT(*) FROM dim_entity de
                        JOIN fact_periodic fp ON de.entity_id = fp.entity_id
                        LIMIT 1
                    """).fetchone()
                    self.check("entity_id JOIN", True)
                except Exception as e:
                    self.check("entity_id JOIN", False, detail_fail=type(e).__name__)

            try:
                n_donem = con.execute(
                    "SELECT COUNT(DISTINCT donem) FROM fact_periodic"
                ).fetchone()[0]
                n_firma = con.execute(
                    "SELECT COUNT(DISTINCT entity_id) FROM fact_periodic"
                ).fetchone()[0]
                firma_range = (
                    "<1K" if n_firma < 1000 else
                    "1K-10K" if n_firma < 10000 else
                    "10K-100K" if n_firma < 100000 else
                    "100K-1M" if n_firma < 1000000 else "1M+"
                )
                self.check("fact_periodic", True,
                            detail_ok=f"{n_donem} dönem, {firma_range} firma")
            except Exception:
                self.skip("fact_periodic")

            try:
                from ews_scoreboard.feature_info import FI
                n_kik = len(FI.kik_ciss_cols)
                n_rkd = len(FI.rkd_codes)
                if n_kik > 0 and n_rkd > 0:
                    self.check("feature_info", True, detail_ok=f"{n_kik} kik, {n_rkd} rkd")
                else:
                    self.warn("feature_info", "boş — fallback")
            except Exception:
                self.warn("feature_info", "yüklenemedi")

            con.close()
        except Exception as e:
            self.check("DB bağlantı", False, detail_fail=type(e).__name__)

    # ═══ GRUP 4: Ortam ═══

    def grup4_ortam(self):
        print("\n[GRUP 4] Ortam Uyumluluğu")
        for mod_name in ["numpy", "pandas", "duckdb"]:
            try:
                mod = __import__(mod_name)
                self.check(mod_name, True, detail_ok=getattr(mod, "__version__", "?"))
            except ImportError:
                self.check(mod_name, False, detail_fail="kurulu değil")

        for mod_name in ["lightgbm", "shap"]:
            try:
                mod = __import__(mod_name)
                self.check(mod_name, True, detail_ok=getattr(mod, "__version__", "?"))
            except ImportError:
                self.warn(mod_name, "opsiyonel — kurulu değil")

    # ═══ ÇALIŞTIR ═══

    def run(self):
        import ews_scoreboard
        print(f"EWS SCOREBOARD DOĞRULAMA — v{ews_scoreboard.__version__}")
        print("=" * 60)

        self.grup1_paket()
        self.grup2_kaynak()
        self.grup3_runtime()
        self.grup4_ortam()

        print("\n" + "=" * 60)
        if self.fails:
            print(f"  ✗ {len(self.fails)} FAIL — pipeline çalıştırmayın")
            sys.exit(1)
        elif self.warns:
            print(f"  ⚠ {len(self.warns)} uyarı")
            print(f"  ✓ Kritik hata yok — pipeline çalıştırılabilir")
        else:
            print(f"  ✓ Tüm kontroller geçti")


def verify_all(db_path="db/ews.duckdb"):
    """Backward compat wrapper."""
    v = Verifier(db_path)
    v.run()
    return v
