"""
EWS Scoreboard CLI.

Usage:
    ews-scoreboard init              Çalışma dizinini hazırla
    ews-scoreboard status            Durum kontrolü
    ews-scoreboard version           Versiyon bilgisi

Pipeline ews_pipeline.ipynb üzerinden çalıştırılır.
"""

import argparse
import hashlib
import sys
from pathlib import Path

from ews_scoreboard import __version__
from ews_scoreboard.license import require_license
from ews_scoreboard.paths import (
    get_source_dir, get_db_path, get_output_dir, get_work_dir, get_data_readme, get_notebooks_dir,
)


def _file_hash(path: Path) -> str:
    """SHA-256 hash of file contents (first 16 hex chars)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


EXTERNAL_DATA_SUBDIRS = [
    "kik_data_ham_csv",
    "kredi_db",
    "yis_tahmin_data",
    "eus_tahmin_data",
    "eus_hedef_muta",
    "eus_sql_kapsam_muta",
    "statik_db",
    "yis_train_data",
    "rkd_donem_data",
    "memzuc_data_donem",
]


def cmd_activate(args):
    """Activate license."""
    from ews_scoreboard.license import activate
    key = args.key
    if activate(key):
        print("Lisans aktive edildi.")
    else:
        print("Geçersiz anahtar.")
        sys.exit(1)


def cmd_init(args):
    """Scaffold the working directory structure."""
    require_license()
    force = getattr(args, "force", False)
    base = get_work_dir(args.dir)
    print(f"EWS Scoreboard v{__version__} — init")
    print(f"Çalışma dizini: {base}\n")

    # Create directories
    dirs = [
        base / "db",
        base / "outputs" / "json",
        base / "outputs" / "html",
        base / "outputs" / "validation",
        base / "ml_models",
        base / "seasons",
    ]
    for subdir in EXTERNAL_DATA_SUBDIRS:
        dirs.append(base / "external_data" / subdir)

    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        print(f"  [OK] {d.relative_to(base)}/")

    # Copy data readme
    readme_src = get_data_readme()
    readme_dst = base / "external_data" / "VERI_KOPYALA.txt"
    readme_dst.write_text(readme_src.read_text(encoding="utf-8"), encoding="utf-8")
    print(f"  [OK] external_data/VERI_KOPYALA.txt")

    # Copy all pipeline notebooks with hash check (skip old monolithic nb_01_ingest)
    import shutil
    nb_dir = get_notebooks_dir()
    created = []
    updated = []
    skipped = 0

    for nb_file in sorted(nb_dir.glob("*.ipynb")):
        if nb_file.name == "nb_01_ingest.ipynb":
            continue  # replaced by nb_01a..nb_01h
        nb_dst = base / nb_file.name

        if force:
            shutil.copy2(nb_file, nb_dst)
            updated.append(nb_file.name)
        elif not nb_dst.exists():
            shutil.copy2(nb_file, nb_dst)
            created.append(nb_file.name)
        elif _file_hash(nb_file) != _file_hash(nb_dst):
            shutil.copy2(nb_file, nb_dst)
            updated.append(nb_file.name)
        else:
            skipped += 1

    # Write version marker + sync meta hashes
    version_file = base / "db" / ".nb_version"
    old_version = version_file.read_text(encoding="utf-8").strip() if version_file.exists() else None
    version_file.write_text(__version__, encoding="utf-8")

    if old_version and old_version != __version__:
        all_nb = [nb.name for nb in sorted(nb_dir.glob("*.ipynb")) if nb.name != "nb_01_ingest.ipynb"]
        _update_meta_hashes(base, all_nb)

    # Summary
    print(f"\n{'='*50}")
    print(f"  AYNI         : {skipped} dosya")
    if created:
        print(f"  YENİ         : {len(created)} dosya")
        for f in created:
            print(f"    + {f}")
    if updated:
        print(f"  GÜNCELLENDİ : {len(updated)} dosya")
        for f in updated:
            print(f"    \u21bb {f}")
    print(f"{'='*50}")

    if updated or created:
        print("\n\u26a0 VS Code'da açık notebook'lar varsa:")
        print("  Ctrl+Shift+P \u2192 'Revert File' ile yenileyin.")
        print("  Veya tüm notebook'ları kapatıp tekrar açın.")

    print(f"""
{'='*60}
  KURULUM TAMAM
{'='*60}

  Ham veriyi external_data altına kopyalayın:

    {base / 'external_data'}/
    ├── kik_data_ham_csv/        ← KIK izleme CSV
    ├── kredi_db/                ← Kredi risk parquet
    ├── yis_tahmin_data/         ← YIS tahmin CSV
    ├── eus_tahmin_data/         ← EUS tahmin CSV
    ├── eus_hedef_muta/          ← EUS hedef MUTA
    ├── eus_sql_kapsam_muta/     ← EUS kapsam MUTA
    ├── statik_db/               ← Statik bilgiler TXT
    ├── yis_train_data/          ← YIS training parquet
    ├── rkd_donem_data/          ← RKD kriter parquet
    └── memzuc_data_donem/       ← Memzuc parquet

  Veri kopyalandıktan sonra ews_pipeline.ipynb ile çalıştırın:
    ews_pipeline.ipynb              # Orchestrator (Motor class)
    nb_01a_ingest_ddl.ipynb         # Her ingest kaynağı ayrı
    nb_01b_ingest_kik.ipynb
    ...
    nb_02_transform.ipynb           # Bronze → Silver
    nb_03_marts.ipynb               # Scoreboard + Trending + HTML
    nb_04_ml.ipynb                  # ML train + predict
    nb_05a_backtest_eus.ipynb       # EUS backtest
    nb_05b_backtest_yis.ipynb       # YIS backtest
    nb_05c_backtest_ml.ipynb        # ML backtest
""")


def _update_meta_hashes(base: Path, updated_notebooks: list):
    """Sync sonrası meta hash'lerini güncelle — Motor gereksiz yere tekrar çalıştırmasın."""
    import json as _json
    from ews_scoreboard.motor import ADIM_REGISTRY

    # notebook adı → adım kodları eşlemesi
    nb_to_codes = {}
    for kod, info in ADIM_REGISTRY.items():
        nb_to_codes.setdefault(info["nb"], []).append(kod)

    seasons_dir = base / "seasons"
    if not seasons_dir.exists():
        return

    guncellenen = 0
    for nb_name in updated_notebooks:
        nb_path = base / nb_name
        if not nb_path.exists():
            continue
        new_hash = _file_hash(nb_path)

        for kod in nb_to_codes.get(nb_name, []):
            # En güncel season meta'sını bul ve güncelle
            for sdir in sorted(seasons_dir.iterdir(), reverse=True):
                meta_path = sdir / "meta" / f"adim_{kod}.json"
                if meta_path.exists():
                    try:
                        meta = _json.loads(meta_path.read_text(encoding="utf-8"))
                        if meta.get("nb_hash") != new_hash:
                            meta["nb_hash"] = new_hash
                            meta_path.write_text(
                                _json.dumps(meta, ensure_ascii=False, indent=2),
                                encoding="utf-8",
                            )
                            guncellenen += 1
                    except Exception:
                        pass
                    break  # sadece en güncel season yeterli
    if guncellenen:
        print(f"  [SYNC] {guncellenen} meta hash güncellendi (gereksiz re-run önlendi)")


def _sync_notebooks(base: Path):
    """Auto-update notebooks if package version changed since last sync."""
    import shutil
    version_file = base / "db" / ".nb_version"
    version_file.parent.mkdir(parents=True, exist_ok=True)

    current = version_file.read_text(encoding="utf-8").strip() if version_file.exists() else ""
    if current == __version__:
        return

    nb_dir = get_notebooks_dir()
    updated = []
    for nb_file in sorted(nb_dir.glob("*.ipynb")):
        if nb_file.name == "nb_01_ingest.ipynb":
            continue
        nb_dst = base / nb_file.name
        shutil.copy2(nb_file, nb_dst)
        updated.append(nb_file.name)

    version_file.write_text(__version__, encoding="utf-8")

    # Meta hash'lerini güncelle (notebook sync → hash farkı → gereksiz re-run önlenir)
    _update_meta_hashes(base, updated)

    # Versiyon değiştiğinde eski error_report'ları temizle
    silinen = 0
    seasons_dir = base / "seasons"
    if seasons_dir.exists():
        for er in seasons_dir.rglob("error_report.txt"):
            er.unlink()
            silinen += 1
    for loc in [base / "outputs" / "json" / "error_report.txt",
                base / "outputs" / "error_report.txt"]:
        if loc.exists():
            loc.unlink()
            silinen += 1

    if current:
        print(f"  [SYNC] Notebook'lar güncellendi: v{current} → v{__version__} ({len(updated)} dosya)")
    else:
        print(f"  [SYNC] Notebook'lar kopyalandı: v{__version__} ({len(updated)} dosya)")
    if silinen:
        print(f"  [SYNC] {silinen} eski error_report temizlendi")


def cmd_status(args):
    """Check the current state."""
    base = get_work_dir(args.dir)
    source_dir = get_source_dir(args.dir)
    db_path = get_db_path(args.dir)
    output_dir = get_output_dir(args.dir)

    print(f"EWS Scoreboard v{__version__} — status")
    print(f"Çalışma dizini: {base}\n")

    # external_data check
    print("  [external_data]")
    if source_dir.exists():
        for subdir in EXTERNAL_DATA_SUBDIRS:
            p = source_dir / subdir
            if p.exists():
                n_files = len(list(p.iterdir()))
                status = f"{n_files} dosya" if n_files > 0 else "BOŞ"
                print(f"    {subdir}: {status}")
            else:
                print(f"    {subdir}: YOK")
    else:
        print("    BULUNAMADI — 'ews-scoreboard init' çalıştırın")

    # DB check
    print("\n  [db]")
    if db_path.exists():
        size_mb = db_path.stat().st_size / (1024 * 1024)
        print(f"    ews.duckdb: {size_mb:.2f} MB")
        try:
            import duckdb
            con = duckdb.connect(str(db_path), read_only=True)
            tables = con.execute("SHOW TABLES").fetchall()
            for (t,) in tables:
                cnt = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                if cnt > 0:
                    print(f"      {t}: {cnt} rows")
            con.close()
        except Exception as e:
            print(f"      Okuma hatası: {e}")
    else:
        print("    ews.duckdb: YOK — pipeline henüz çalışmamış")

    # Output check
    print("\n  [outputs]")
    for fname in ["json/sample_scoreboard.json", "json/sample_trending_lists.json"]:
        fpath = output_dir / fname
        if fpath.exists():
            print(f"    {fname}: {fpath.stat().st_size / 1024:.1f} KB")
        else:
            print(f"    {fname}: YOK")


def cmd_version(args):
    print(f"ews_scoreboard {__version__}")


def main():
    parser = argparse.ArgumentParser(
        prog="ews-scoreboard",
        description="EWS Early Warning Scoreboard Pipeline",
    )
    parser.add_argument("--dir", type=Path, default=None,
                        help="Çalışma dizini (varsayılan: bulunduğunuz dizin)")

    sub = parser.add_subparsers(dest="command")

    act_p = sub.add_parser("activate", help="Lisans aktive et")
    act_p.add_argument("key", help="Lisans anahtarı (XXXX-XXXX-XXXX-XXXX)")

    init_p = sub.add_parser("init", help="Çalışma dizinini hazırla")
    init_p.add_argument("--force", action="store_true", help="Hash kontrolü yapma, tüm dosyaları üzerine yaz")
    sub.add_parser("status", help="Durum kontrolü")
    sub.add_parser("version", help="Versiyon bilgisi")
    verify_p = sub.add_parser("verify", help="Kurulum doğrulama")
    verify_p.add_argument("--db", type=str, default="db/ews.duckdb", help="DB yolu")

    args = parser.parse_args()

    if args.command == "activate":
        cmd_activate(args)
    elif args.command == "init":
        cmd_init(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "version":
        cmd_version(args)
    elif args.command == "verify":
        from ews_scoreboard.verify_install import verify_all
        verify_all(args.db)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
