"""Değişiklik öncesi etki analizi.

Kullanım:
    from ews_scoreboard.dev_tools.impact_scanner import scan_impact
    scan_impact("entity_id")
"""

import re
from pathlib import Path


def scan_impact(concept: str, root: str = "src", extensions=(".py", ".ipynb", ".sql")):
    """Bir konseptin repo'daki tüm kullanımlarını bul."""
    hits = []
    for ext in extensions:
        for f in Path(root).rglob(f"*{ext}"):
            if "__pycache__" in str(f) or ".so" in str(f):
                continue
            try:
                content = f.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            for i, line in enumerate(content.split("\n"), 1):
                if re.search(concept, line, re.IGNORECASE):
                    hits.append({"file": str(f), "line": i, "content": line.strip()})

    print(f"\n'{concept}' ETKİ ANALİZİ: {len(hits)} kullanım")
    by_file = {}
    for h in hits:
        by_file.setdefault(h["file"], []).append(h)
    for f, lines in sorted(by_file.items()):
        print(f"\n  {f} ({len(lines)} satır):")
        for l in lines[:5]:
            print(f"    {l['line']:>4}: {l['content'][:80]}")
        if len(lines) > 5:
            print(f"    ... +{len(lines)-5} satır")

    return hits
