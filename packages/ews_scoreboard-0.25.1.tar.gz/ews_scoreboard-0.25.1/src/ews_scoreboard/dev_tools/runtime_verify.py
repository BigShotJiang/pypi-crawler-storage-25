"""Değişiklik sonrası runtime doğrulama.

Kullanım:
    from ews_scoreboard.dev_tools.runtime_verify import verify_function, verify_sql_types
    verify_function("ews_scoreboard.pipeline.transform", "run_transforms")
    verify_sql_types("db/ews.duckdb")
"""

import importlib


def verify_function(module_path: str, func_name: str, test_args=None):
    """Bir fonksiyonu import et ve opsiyonel olarak çağır."""
    try:
        mod = importlib.import_module(module_path)
        func = getattr(mod, func_name)
        print(f"  ✓ {module_path}.{func_name} import edildi")
    except Exception as e:
        print(f"  ✗ Import FAIL: {e}")
        return False

    if test_args is not None:
        try:
            result = func(*test_args)
            print(f"  ✓ Çağrı başarılı, sonuç tipi: {type(result).__name__}")
            return result
        except Exception as e:
            print(f"  ✗ Runtime FAIL: {e}")
            return False

    return True


def verify_sql_types(db_path="db/ews.duckdb"):
    """Tüm tablolardaki entity_id tiplerini kontrol et."""
    import duckdb
    from pathlib import Path

    if not Path(db_path).exists():
        print("  ○ DB yok — SKIP")
        return {}

    con = duckdb.connect(db_path, read_only=True)
    tables = ["dim_entity", "fact_periodic", "map_identity"]
    types = {}
    for t in tables:
        try:
            for r in con.execute(f"DESCRIBE {t}").fetchall():
                if r[0] == "entity_id":
                    types[t] = r[1]
        except Exception:
            pass
    con.close()

    print(f"\n  entity_id TİP HARİTASI:")
    for t, typ in types.items():
        print(f"    {t:20s} → {typ}")

    unique = set(types.values())
    if len(unique) > 1:
        print(f"  ⚠ TUTARSIZ: {unique}")
    elif unique:
        print(f"  ✓ Tutarlı: {unique}")

    return types
