"""Dev araçları — etki analizi + runtime doğrulama."""
