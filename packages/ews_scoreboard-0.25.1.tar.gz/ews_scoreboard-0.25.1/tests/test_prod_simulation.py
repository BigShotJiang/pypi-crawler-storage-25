"""Prod ortamı simülasyon testleri.

Dev'de geçip prod'da patlayan sorunları yakalamak için.
Geçici DB oluşturup gerçek fonksiyonları çağırır.

Çalıştır: python -m pytest tests/test_prod_simulation.py -v
"""
import pytest
import duckdb
import tempfile
import shutil
from pathlib import Path


@pytest.fixture
def test_db():
    """Geçici DB oluştur, test sonunda sil."""
    tmp = tempfile.mkdtemp()
    db_path = Path(tmp) / "test.duckdb"
    con = duckdb.connect(str(db_path))
    yield con, db_path
    con.close()
    shutil.rmtree(tmp)


class TestEntityIdTypeMismatch:
    """Prod'daki entity_id VARCHAR/BIGINT karışıklığını simüle et."""

    def _setup_mixed_types(self, con):
        con.execute("""
            CREATE TABLE dim_entity (entity_id VARCHAR, segment VARCHAR,
                bolge_kodu INTEGER, sube_kodu INTEGER,
                must_tip_kodu VARCHAR, grup_kodu VARCHAR, grup_tanimi VARCHAR,
                firma_otorize_kodu VARCHAR, aksiyon_sahibi VARCHAR, kri_bolum VARCHAR,
                son_izleme_kodu VARCHAR, risk_grup_kodu VARCHAR, pgy VARCHAR,
                finansman_konu VARCHAR, tahsis_onay_birimi VARCHAR)
        """)
        con.execute("INSERT INTO dim_entity (entity_id, segment, bolge_kodu, sube_kodu) VALUES ('12345','KOBI',1,100),('67890','KUR-TIC',2,200)")

        con.execute("""
            CREATE TABLE fact_periodic (entity_id VARCHAR, donem VARCHAR,
                ews_skor VARCHAR, ews_kaynak VARCHAR, kombine_risk BIGINT,
                kredi_risk BIGINT, kik_risk BIGINT, depo_risk BIGINT,
                nakit_risk BIGINT, gnakit_risk BIGINT, risk_degisim BIGINT,
                ykn_izl_flag INTEGER, yis_skor INTEGER, yis_ihtimal DOUBLE,
                yis_label INTEGER, eus_skor DOUBLE, eus_ihtimal DOUBLE,
                eus_tahmin_label INTEGER, eus_kapsam INTEGER, eus_hedef INTEGER,
                tfrs_rating VARCHAR, rating_tarihi VARCHAR)
        """)
        con.execute("""INSERT INTO fact_periodic (entity_id,donem,ews_skor,ews_kaynak,kombine_risk) VALUES
            ('12345','2601','350','eus',5000000),('12345','2602','400','eus',5100000),
            ('67890','2601','YI','yi',20000000),('67890','2602','YI','yi',20000000)""")

        con.execute("CREATE TABLE map_identity (entity_id VARCHAR, muta VARCHAR, unvan VARCHAR)")
        con.execute("INSERT INTO map_identity VALUES ('12345','12345','Firma A'),('67890','67890','Firma B')")

        con.execute("CREATE TABLE ref_sube_bolge (sube_kodu INTEGER, sube_adi VARCHAR, bolge_kodu INTEGER, bolge_adi VARCHAR)")
        con.execute("INSERT INTO ref_sube_bolge VALUES (100,'Şube 1',1,'Bölge 1'),(200,'Şube 2',2,'Bölge 2')")

    def test_build_scoreboard_mixed_types(self, test_db):
        """_build_scoreboard VARCHAR/BIGINT karışık tipler ile çalışmalı."""
        con, db_path = test_db
        self._setup_mixed_types(con)

        from ews_scoreboard.pipeline.marts import _build_scoreboard
        scoreboard = _build_scoreboard(con)

        rows = scoreboard.get("rows", [])
        assert len(rows) > 0, "Scoreboard boş — entity_id type mismatch"

        ews_var = [r for r in rows if any(
            r.get(f"ews{d}") is not None
            for d in scoreboard["meta"]["donemler"]
        )]
        assert len(ews_var) > 0, "Tüm EWS skorları None — merge başarısız"


class TestSon12Filter:
    """27 dönemlik veriyle son_12 filtresini test et."""

    def _setup_27_donem(self, con):
        donemler = [f"{y:02d}{m:02d}" for y in range(23, 27) for m in range(1, 13)][:27]

        con.execute("CREATE TABLE brz_yis_tahmin (muta VARCHAR, donem VARCHAR, yis_skor INTEGER, yis_ihtimal DOUBLE, yis_label INTEGER)")
        con.execute("CREATE TABLE brz_eus_tahmin (muta VARCHAR, donem VARCHAR, eus_skor DOUBLE, eus_ihtimal DOUBLE)")
        for d in donemler:
            con.execute(f"INSERT INTO brz_eus_tahmin VALUES ('12345','{d}',500.0,0.5)")

        con.execute("CREATE TABLE brz_kredi_risk (muta VARCHAR, donem VARCHAR, kredi_risk BIGINT)")
        for d in donemler:
            con.execute(f"INSERT INTO brz_kredi_risk VALUES ('12345','{d}',1000000)")

        con.execute("CREATE TABLE brz_kik_izleme (muta VARCHAR, donem VARCHAR, kik_risk BIGINT, ykn_izl_flag VARCHAR, unvan VARCHAR, tfrs_rating VARCHAR, rating_tarihi VARCHAR, gckm_gun_say INTEGER, erkn_izlm_kod VARCHAR, ciss_flag INTEGER)")
        con.execute("CREATE TABLE brz_eus_kapsam (muta VARCHAR, donem VARCHAR)")
        con.execute("CREATE TABLE brz_eus_hedef (muta VARCHAR, donem VARCHAR)")
        con.execute("CREATE TABLE brz_statik (muta VARCHAR, bolge_kodu INTEGER, bolge_adi VARCHAR, sube_kodu INTEGER, sube_adi VARCHAR, must_tip_kodu VARCHAR, grup_kodu VARCHAR, grup_tanimi VARCHAR, firma_otorize_kodu VARCHAR, aksiyon_sahibi VARCHAR, kri_bolum VARCHAR)")
        con.execute("INSERT INTO brz_statik VALUES ('12345',1,'Bölge',100,'Şube','1',NULL,NULL,NULL,NULL,NULL)")
        con.execute("CREATE TABLE brz_train_features (muta VARCHAR, donem VARCHAR, segment VARCHAR)")

        # Silver tablolar (DDL)
        con.execute("CREATE TABLE dim_entity (entity_id VARCHAR PRIMARY KEY, segment VARCHAR, bolge_kodu INTEGER, sube_kodu INTEGER, must_tip_kodu VARCHAR, grup_kodu VARCHAR, grup_tanimi VARCHAR, firma_otorize_kodu VARCHAR, aksiyon_sahibi VARCHAR, kri_bolum VARCHAR, son_izleme_kodu VARCHAR, risk_grup_kodu VARCHAR, pgy VARCHAR, finansman_konu VARCHAR, tahsis_onay_birimi VARCHAR)")
        con.execute("CREATE TABLE map_identity (entity_id VARCHAR PRIMARY KEY, muta VARCHAR, unvan VARCHAR)")
        con.execute("CREATE TABLE fact_periodic (entity_id VARCHAR, donem VARCHAR, yis_skor INTEGER, yis_ihtimal DOUBLE, yis_label INTEGER, eus_skor DOUBLE, eus_ihtimal DOUBLE, eus_tahmin_label INTEGER, eus_kapsam INTEGER, eus_hedef INTEGER, ews_skor VARCHAR, ews_kaynak VARCHAR, ykn_izl_flag INTEGER, kombine_risk BIGINT, kredi_risk BIGINT, kik_risk BIGINT, depo_risk BIGINT, nakit_risk BIGINT, gnakit_risk BIGINT, risk_degisim BIGINT, tfrs_rating VARCHAR, rating_tarihi VARCHAR, PRIMARY KEY (entity_id, donem))")
        con.execute("CREATE TABLE ref_sube_bolge (sube_kodu INTEGER PRIMARY KEY, sube_adi VARCHAR, bolge_kodu INTEGER, bolge_adi VARCHAR)")
        con.execute("INSERT INTO ref_sube_bolge VALUES (100,'Şube',1,'Bölge')")

        return donemler

    def test_son_12_filters_correctly(self, test_db):
        """27 dönemlik veriyle run_transforms('son_12') sadece 12 dönem üretmeli."""
        con, db_path = test_db
        donemler = self._setup_27_donem(con)
        con.close()

        from ews_scoreboard.pipeline.transform import run_transforms
        run_transforms(db_path, referans_tarih_list="son_12")

        con2 = duckdb.connect(str(db_path), read_only=True)
        fp_donemler = [r[0] for r in con2.execute(
            "SELECT DISTINCT donem FROM fact_periodic ORDER BY donem"
        ).fetchall()]
        con2.close()

        assert len(fp_donemler) <= 12, f"son_12 çalışmadı: {len(fp_donemler)} dönem"
        assert len(fp_donemler) > 0, "fact_periodic boş"


class TestWheelRuntime:
    """Wheel'daki kodun kaynak kodla aynı olduğunu kontrol et."""

    def test_wheel_content_matches_source(self):
        import zipfile
        import hashlib

        wheels = list(Path("dist").glob("*.whl"))
        if not wheels:
            pytest.skip("dist/ altında wheel yok")

        whl = wheels[-1]
        mismatches = []

        with zipfile.ZipFile(whl) as z:
            for name in z.namelist():
                if not name.endswith(".py"):
                    continue
                whl_hash = hashlib.md5(z.read(name)).hexdigest()
                parts = name.split("/")
                if len(parts) >= 2:
                    src_path = Path("src") / "/".join(parts)
                    if src_path.exists():
                        src_hash = hashlib.md5(src_path.read_bytes()).hexdigest()
                        if whl_hash != src_hash:
                            mismatches.append(parts[-1])

        assert not mismatches, f"Wheel uyuşmuyor: {mismatches}"
