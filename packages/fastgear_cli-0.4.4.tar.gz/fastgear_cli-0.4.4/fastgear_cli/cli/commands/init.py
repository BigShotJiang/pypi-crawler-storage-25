import subprocess
from pathlib import Path

import questionary
import typer

from fastgear_cli.cli.prompts.init_project import (
    ask_agent_tools,
    ask_ci_provider,
    ask_database_provider,
    ask_project_name,
    confirm_project_title,
)
from fastgear_cli.core.exceptions import TemplateConflictError
from fastgear_cli.core.filesystem import create_template
from fastgear_cli.core.models import ProjectInitConfig
from fastgear_cli.core.utils.file_tree_utils import FileTreeUtils

init_app = typer.Typer(help="Project initialization command")


@init_app.command()
def init(
    path: Path = typer.Argument(
        None,
        help="Path where the project should be created (defaults to current path)",
        exists=False,
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Show what files would be created without actually creating them",
    ),
):
    try:
        base_dir = path or Path.cwd()

        config = _collect_project_info(base_dir)
        files = _generate_project(config, dry_run=dry_run)

        if dry_run:
            FileTreeUtils.display_dry_run_output(files, base_dir)
            return

        _run_uv_lock(config.project_dir)

        typer.secho(
            f"\n🎉  Project '{config.project_name}' created successfully!",
            fg=typer.colors.GREEN,
        )
    except TemplateConflictError as error:
        typer.secho(str(error), fg=typer.colors.RED)
        raise typer.Exit(code=1) from error


def _collect_project_info(base_dir: Path) -> ProjectInitConfig:
    project_name = ask_project_name()
    project_title = confirm_project_title(project_name)
    use_docker = questionary.confirm("Use Docker?", default=True).ask()
    agent_tools = ask_agent_tools()
    ci_provider = ask_ci_provider()
    database_provider = ask_database_provider()
    use_database = database_provider is not None

    return ProjectInitConfig(
        base_dir=base_dir,
        project_name=project_name,
        project_title=project_title,
        use_docker=use_docker,
        agent_tools=agent_tools,
        ci_provider=ci_provider,
        use_database=use_database,
        database_provider=database_provider,
    )


def _generate_project(config: ProjectInitConfig, *, dry_run: bool) -> list[Path]:
    if config.project_dir.exists() and any(config.project_dir.iterdir()):
        raise TemplateConflictError(f"Directory '{config.project_dir}' already exists.")

    try:
        return create_template(
            "new_project",
            config.base_dir,
            config.context,
            config.conditional_files,
            config.conditional_dirs,
            dry_run=dry_run,
        )
    except FileExistsError as error:
        raise TemplateConflictError(f"Directory '{config.project_dir}' already exists.") from error


def _run_uv_lock(project_dir: Path) -> None:
    typer.secho("📦 Generating uv.lock...", fg=typer.colors.CYAN)
    try:
        subprocess.run(
            ["uv", "lock"],
            cwd=project_dir,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as error:
        typer.secho(
            f"Failed to generate uv.lock: {error.stderr}",
            fg=typer.colors.YELLOW,
        )
    except FileNotFoundError:
        typer.secho(
            "uv not found. Please install uv to generate the lock file.",
            fg=typer.colors.YELLOW,
        )
