---
description: Generate code to explore available entities and features in the tdfs4ds feature store, select specific feature versions, and build a denormalised snapshot view ready for model development. Invoke when the user wants to build or refresh a dataset view.
argument-hint: [entity-name] [feature-list] [dataset-view-name]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code to explore the `tdfs4ds` feature store, select feature versions, and build a denormalised snapshot dataset view.

User context: $ARGUMENTS

Ask for any missing values before generating code:
- **Entity name** — the entity whose features go into the dataset (e.g. `'CustomerID'`).
- **Feature list** — names of the features to include.
- **Dataset view name** — name for the output Teradata view (e.g. `'DATASET_CUSTOMER'`).
- **Comment** — optional description stored in the dataset catalog.
- **Point-in-time** — timestamp for historical snapshots, or `None` for current state.

Emit the following pattern, substituting real values for every `<PLACEHOLDER>`:

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_*). TDFS4DS_* settings (DATA_DOMAIN,
# SCHEMA, etc.) are auto-loaded from the same .env by `import tdfs4ds`.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

import tdfs4ds
tdfs4ds.connect(database=Param['database'])
tdfs4ds.DATA_DOMAIN = '<DATA_DOMAIN>'   # or set TDFS4DS_DATA_DOMAIN in .env

# Optional: point-in-time query (None = latest values)
# tdfs4ds.FEATURE_STORE_TIME = '2024-06-01 00:00:00'

# ---------------------------------------------------------------------------
# 1. Discover available entities and features
# ---------------------------------------------------------------------------
from tdfs4ds.feature_store.feature_query_retrieval import (
    get_list_entity,
    get_available_features,
    get_feature_versions,
)

get_list_entity()

entity = '<ENTITY_NAME>'
get_available_features(entity_id=entity)

# ---------------------------------------------------------------------------
# 2. Resolve feature versions
#    Returns {feature_name: process_uuid} — pass directly to build_dataset.
#    Never construct this dict manually.
# ---------------------------------------------------------------------------
feature_selection = get_feature_versions(
    entity_name=entity,
    features=['<FEATURE_1>', '<FEATURE_2>', '<FEATURE_3>'],
)

# ---------------------------------------------------------------------------
# 3. Build the dataset view
# ---------------------------------------------------------------------------
from tdfs4ds import build_dataset

dataset = build_dataset(
    entity_id=entity,
    selected_features=feature_selection,
    view_name='<DATASET_VIEW_NAME>',
    comment='<DESCRIPTION>',
)

dataset
dataset.shape

# Reuse in future sessions without rebuild:
# dataset = tdml.DataFrame(tdml.in_schema(Param['database'], '<DATASET_VIEW_NAME>'))

tdml.remove_context()
```

## Rules

- `selected_features` must come from `get_feature_versions()` — never construct the dict manually.
- `build_dataset` creates a **view**, not a table; it always reflects the state at `FEATURE_STORE_TIME`.
- Set `tdfs4ds.FEATURE_STORE_TIME` **before** calling `build_dataset` for historical snapshots.
- Multiple entities cannot be combined in one `build_dataset` call — join the resulting views manually.
- All catalog queries are scoped to `DATA_DOMAIN` — always set it before querying.
