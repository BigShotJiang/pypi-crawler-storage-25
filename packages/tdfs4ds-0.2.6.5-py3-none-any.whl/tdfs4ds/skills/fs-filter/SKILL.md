---
description: Generate code for segmented feature ingestion using FilterManager — standard (partition only), hybrid (time × partition), or cloned. Invoke when the dataset is too large for a single pass or when processing must iterate over categories, regions, or other partitions.
argument-hint: [filter-column] [mode: standard|hybrid|clone]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code for segmented / partitioned feature ingestion using `FilterManager`.

User context: $ARGUMENTS

Choose the mode that matches the use-case:

| Mode | When to use |
|------|-------------|
| **Standard** | Partition by a categorical column (e.g. one `Category` at a time). No time dimension. |
| **Hybrid** | All (date × category) combinations pre-computed in one manager. No separate `TimeManager` needed during roll-out. |
| **Clone** | Copy an existing filter sequence into a new manager for reuse across processes. |

Ask for any missing values before generating code:
- **Filter table name** — Teradata table that will hold the filter values.
- **Filter column(s)** — column(s) to partition on (e.g. `'Category'`, or `['Category', 'Date_transaction']` for hybrid).
- **Mode** — standard, hybrid, or clone.

---

### Standard FilterManager

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_*). TDFS4DS_* settings (DATA_DOMAIN,
# SCHEMA, etc.) are auto-loaded from the same .env by `import tdfs4ds`.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

import tdfs4ds
tdfs4ds.connect(database=Param['database'])
tdfs4ds.DATA_DOMAIN = '<DATA_DOMAIN>'   # or set TDFS4DS_DATA_DOMAIN in .env

source_database = '<SOURCE_DATABASE>'
source_data = tdml.DataFrame(tdml.in_schema(source_database, '<SOURCE_TABLE>'))

# ---------------------------------------------------------------------------
# 1. Create and populate FilterManager
# ---------------------------------------------------------------------------
from tdfs4ds.utils.filter_management import FilterManager

filtermanager = FilterManager(
    table_name='<FILTER_TABLE_NAME>',
    schema_name=Param['database'],
)
# Start with 5 partitions for validation; remove the QUALIFY limit before full roll-out.
filtermanager.load_filter(
    tdml.DataFrame.from_query(f"""
        SELECT <FILTER_COLUMN>
        FROM (
            SELECT DISTINCT <FILTER_COLUMN>
            FROM {source_database}.<SOURCE_TABLE>
            QUALIFY ROW_NUMBER() OVER (ORDER BY <FILTER_COLUMN>) <= 5
        ) t
    """)
)

print('Iterations:', filtermanager.nb_filters)
filtermanager.display()

# ---------------------------------------------------------------------------
# 2. Build the feature engineering view — scalar subquery on the filter view.
#    The filter view always exposes exactly one row (the current partition).
#    A scalar subquery lets the optimizer resolve the value first and prune
#    partitions in the source table before any row processing.
# ---------------------------------------------------------------------------
from tdfs4ds.utils.lineage import crystallize_view

df_features_raw = tdml.DataFrame.from_query(f"""
    SELECT A.*
    FROM {source_database}.<SOURCE_TABLE> A
    WHERE A.<FILTER_COLUMN> = (SELECT <FILTER_COLUMN> FROM {filtermanager.schema_name}.{filtermanager.view_name})
""")

df_features = df_features_raw.groupby('<ENTITY_COLUMN>').agg(
    {'<VALUE_COLUMN>': ['sum', 'mean']}
)
df_features_proc = crystallize_view(
    df_features,
    view_name='<VIEW_NAME>',
    schema_name=Param['database'],
)

# ---------------------------------------------------------------------------
# 3. Register with the FilterManager attached
# ---------------------------------------------------------------------------
from tdfs4ds import upload_features

upload_features(
    df_features_proc,
    entity_id='<ENTITY_COLUMN>',
    feature_names=['sum_<VALUE_COLUMN>', 'mean_<VALUE_COLUMN>'],
    metadata={'project': '<PROJECT_NAME>'},
    filtermanager=filtermanager,
)

tdml.remove_context()
```

---

### Hybrid FilterManager (time × partition)

```python
filtermanager = FilterManager(
    table_name='<HYBRID_FILTER_TABLE>',
    schema_name=Param['database'],
)

# Load the 5 most recent (date × category) combinations.
# Latest dates are prioritised; remove the QUALIFY limit before full roll-out.
filtermanager.load_filter(
    tdml.DataFrame.from_query(f"""
        SELECT <FILTER_COLUMN>, <DATE_COLUMN>
        FROM (
            SELECT DISTINCT <FILTER_COLUMN>, <DATE_COLUMN>
            FROM {source_database}.<SOURCE_TABLE>
            QUALIFY ROW_NUMBER() OVER (ORDER BY <DATE_COLUMN> DESC, <FILTER_COLUMN>) <= 5
        ) t
    """),
    time_column='<DATE_COLUMN>',
)

print('Hybrid combinations:', filtermanager.nb_filters)
filtermanager.display()  # shows BUSINESS_DATE + <FILTER_COLUMN>

# Source query uses scalar subqueries on both date and category
df_features_raw = tdml.DataFrame.from_query(f"""
    SELECT A.*
    FROM {source_database}.<SOURCE_TABLE> A
    WHERE A.<DATE_COLUMN>   = (SELECT BUSINESS_DATE   FROM {filtermanager.schema_name}.{filtermanager.view_name})
      AND A.<FILTER_COLUMN> = (SELECT <FILTER_COLUMN> FROM {filtermanager.schema_name}.{filtermanager.view_name})
""")

# ... crystallize and upload_features as above, passing filtermanager=filtermanager
```

---

### Clone a FilterManager

```python
filtermanager_source = FilterManager(table_name='<EXISTING_TABLE>', schema_name=Param['database'])
filtermanager_new    = FilterManager(table_name='<NEW_TABLE>',      schema_name=Param['database'])
filtermanager_new.clone_filter(filtermanager_source)
```

## Rules

- **Load 3–5 partitions initially** — seed `load_filter` with a small subset using `QUALIFY ROW_NUMBER() OVER (...) <= 5`. Expand to all partitions before a full roll-out.
- **Latest dates first** — when a date column is present, order by `<DATE_COLUMN> DESC` in the `QUALIFY` clause so the first ingestion run reflects the most recent data.
- The source query must use **scalar subqueries** on `filtermanager.schema_name`.`filtermanager.view_name` — never hard-code partition values, and prefer scalar subqueries over JOINs so the optimizer resolves the value before scanning the source table.
- For hybrid managers, the filter view column for the time dimension is always named `BUSINESS_DATE`. Filter on both `BUSINESS_DATE` and the partition column via scalar subqueries.
- Always pass `filtermanager=filtermanager` to `upload_features`; omitting it means `roll_out` will not iterate filters.
- `filtermanager.update(filter_id=N)` manually moves to position N (1-based) — useful for testing a single partition.
