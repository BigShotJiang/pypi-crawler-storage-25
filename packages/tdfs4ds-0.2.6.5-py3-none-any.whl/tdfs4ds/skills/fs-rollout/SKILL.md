---
description: Generate code to backfill features across a date range using TimeManager and roll_out. Invoke when the user wants to simulate historical ingestion or re-compute features over past periods.
argument-hint: [process-view-name] [date-column] [start-id] [end-id]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code to step through time with `TimeManager` and execute registered feature engineering processes over a date range with `roll_out`.

User context: $ARGUMENTS

Ask for any missing values before generating code:
- **Process view name(s)** — the crystallized view name(s) used to look up process IDs (e.g. `'FEAT_ENG_CUST'`).
- **Time table name** — Teradata table holding the business date sequence (e.g. `'BUSINESS_DATE'`).
- **Date column** — column in the source table that provides time steps (e.g. `'Date_transaction'`).
- **Start / end time IDs** — integer positions in the time sequence defining the roll-out range.

Emit the following pattern, substituting real values for every `<PLACEHOLDER>`:

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_*). TDFS4DS_* settings (DATA_DOMAIN,
# SCHEMA, etc.) are auto-loaded from the same .env by `import tdfs4ds`.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

import tdfs4ds
tdfs4ds.connect(database=Param['database'])
tdfs4ds.DATA_DOMAIN = '<DATA_DOMAIN>'   # or set TDFS4DS_DATA_DOMAIN in .env

source_database = '<SOURCE_DATABASE>'
source_data = tdml.DataFrame(tdml.in_schema(source_database, '<SOURCE_TABLE>'))

# ---------------------------------------------------------------------------
# 1. Set up TimeManager
#    Creates (or reconnects to) the Teradata table + view holding the ordered
#    list of business dates. The view always exposes the current date position.
# ---------------------------------------------------------------------------
from tdfs4ds.utils.time_management import TimeManager

business_time = TimeManager(
    table_name='<TIME_TABLE_NAME>',
    schema_name=Param['database'],
)

# First time only: populate from a date column in the source data.
business_time.load_time_steps(
    source_data.groupby('<DATE_COLUMN>').count(),
    '<DATE_COLUMN>',
)

print(business_time.get_current_step())

# Synchronise the feature store with the current time position
tdfs4ds.FEATURE_STORE_TIME = business_time.get_date_in_the_past()

# ---------------------------------------------------------------------------
# 2. Retrieve process IDs by view name
# ---------------------------------------------------------------------------
from tdfs4ds.process_store.process_query_administration import get_process_id

list_process_views = (
    tdfs4ds.process_catalog()[['VIEW_NAME']].to_pandas().VIEW_NAME.values
)

view_1 = [v for v in list_process_views if '<VIEW_SUBSTRING_1>' in v][0]
view_2 = [v for v in list_process_views if '<VIEW_SUBSTRING_2>' in v][0]

process_id_1 = get_process_id(view_name=view_1)
process_id_2 = get_process_id(view_name=view_2)

# ---------------------------------------------------------------------------
# 3. Roll out over a date range
#    Advances TimeManager step by step, updates FEATURE_STORE_TIME, and calls
#    run(process_id) for every step and every process in process_list.
# ---------------------------------------------------------------------------
from tdfs4ds import roll_out

roll_out(
    process_list=[process_id_1, process_id_2],
    time_manager=business_time,
    time_id_start=<START_ID>,
    time_id_end=<END_ID>,
    force_display_logs=False,
)

# ---------------------------------------------------------------------------
# Manual single-step alternative
# ---------------------------------------------------------------------------
# business_time.update(time_id=10)
# tdfs4ds.FEATURE_STORE_TIME = business_time.get_date_in_the_past()
# tdfs4ds.run(process_id=process_id_1)

tdml.remove_context()
```

## Rules

- Call `load_time_steps()` at least once before using `roll_out`; after that `TimeManager` reconnects to the existing table.
- `time_id_start` and `time_id_end` are **1-based integer positions** in the ordered time sequence, not timestamps.
- Processes must already be registered via `upload_features`; `roll_out` does not register new processes.
- Keep `tdfs4ds.FEATURE_STORE_TIME` in sync with the time manager when manually stepping: `tdfs4ds.FEATURE_STORE_TIME = business_time.get_date_in_the_past()`.
- Monitor execution with `tdfs4ds.process_store.process_followup.follow_up_report().sort('START_DATETIME', ascending=False)`.
