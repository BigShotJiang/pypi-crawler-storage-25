# Provenize

**Audit-grade memory infrastructure for AI agents in regulated industries.**

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/)
[![Status](https://img.shields.io/badge/status-pre--alpha-orange.svg)](#status)

## Status

🚧 **Currently under active development.** This package is a name
reservation placeholder. The full Provenize SDK will be published in
late 2026.

This placeholder exists to:
- Reserve the `provenize` name on PyPI
- Provide a stable installation target for early documentation
- Signal active development to the open-source community

## What is Provenize?

Provenize is an open-source Python SDK that provides audit-grade memory
infrastructure for AI agents operating in regulated industries. It is
designed specifically for:

- **Pentest firms** — engagement-scoped memory with cryptographic audit
  trails for security work
- **Law firms** — matter-scoped memory with full citation chains for
  legal AI use cases
- **Banking compliance teams** — TIBER-EU compatible AI memory layer
  with regulatory reporting
- **Regulated industries generally** — GDPR Article 17 erasure, hash-
  chained audit logs, local-first deployment

## Planned Features (v1.0)

Coming in late 2026:

- **Hash-chained audit logs** — cryptographically verifiable trail of
  every AI memory operation
- **GDPR Article 17 erasure** — HMAC-with-key-deletion implementation
  that proves erasure occurred
- **Local-first deployment** — no client data leaves operator infrastructure
- **MCP server integration** — works with Claude Code, Hermes-Agent, and
  other MCP-compatible AI platforms
- **Domain profiles** — pre-configured for security, legal, medical,
  and financial verticals
- **Multi-user PostgreSQL backend** — for team and enterprise tiers

## Why Apache 2.0?

The Apache 2.0 license provides:

- Patent protection that MIT and BSD do not
- Enterprise-friendly terms for procurement
- Compatibility with most open-source ecosystems
- The standard license for cybersecurity open-source tooling

## Project Status

| | |
|---|---|
| **Current version** | 0.0.1 (name reservation placeholder) |
| **Target v1.0** | Q4 2026 |
| **Current phase** | Internal development (Phase 4) |
| **License** | Apache 2.0 |
| **Python support** | 3.10+ |

## Links

- **Homepage:** https://provenize.ai
- **Documentation:** Coming with v1.0
- **Source code:** Coming with v1.0
- **Contact:** info@provenize.ai

## Installation (Placeholder)

```bash
pip install provenize
```

The current version (0.0.1) provides no functional API. It exists for
name reservation only. Installation is safe but does nothing useful yet.

```python
import provenize
provenize.info()
# Prints development status and links to provenize.ai
```

## License

Apache License 2.0 — see [LICENSE](LICENSE) when released.

Copyright © 2026 Provenize. All rights reserved.

---

*This placeholder package was created on 2026-05-14 to reserve the
"provenize" name on PyPI ahead of the v1.0 release.*
