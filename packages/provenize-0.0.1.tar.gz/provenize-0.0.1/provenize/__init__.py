"""
Provenize — Audit-grade memory infrastructure for AI agents.

This package is a name reservation placeholder. The full Provenize SDK
will be published in late 2026.

For updates, visit https://provenize.ai
"""

__version__ = "0.0.1"
__author__ = "Provenize"
__license__ = "Apache-2.0"


def info() -> None:
    """Print information about Provenize and its development status."""
    print("=" * 60)
    print("Provenize")
    print("Audit-grade memory infrastructure for AI agents")
    print("=" * 60)
    print()
    print(f"  Current version:  {__version__} (name reservation placeholder)")
    print(f"  Target release:   v1.0 in Q4 2026")
    print(f"  License:          {__license__}")
    print()
    print("  Status:")
    print("    This is a placeholder package. The full SDK is under")
    print("    active development. Install will succeed but no")
    print("    functional API is currently exported.")
    print()
    print("  Visit https://provenize.ai for updates and roadmap.")
    print("  Contact: info@provenize.ai")
    print("=" * 60)


def __getattr__(name: str):
    """
    Inform users that real API is not yet available.

    This catches attempts to import or use real SDK features before
    v1.0 ships, providing a clear error message instead of cryptic
    AttributeError.
    """
    raise AttributeError(
        f"'{name}' is not available in placeholder version {__version__}. "
        f"The full Provenize SDK will be released in Q4 2026. "
        f"See https://provenize.ai for current development status."
    )


# Public API (placeholder version exports only):
__all__ = ["info", "__version__", "__author__", "__license__"]
