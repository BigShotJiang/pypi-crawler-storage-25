# Ocote
 <img src="ocote.png" alt="Ocote Logo" />

Ocote is a library built on flask allowing for a socket like connection with encryption to a flask sever.

## Installation

```sh
pip install ocote
```

## Usage

You need to setup a client side and a server side for example:

**Client side:**
```python
import ocote.ocote as ocote

conn = ocote.connect("localhost:8000", "API_KEY")

conn.ping()                        # health check -> True/False
print(conn.func("add", 3, 4).value())     # call with args -> 7
print(conn.variable("my_data").value())   # fetch variable -> {"x": 42}
conn.object("cfg")                 # fetch via pickle -> RemoteResult
add = conn.lazy_func("add")        # get a local callable proxy
print(add(10, 20).value())                # -> 30
```

**Server side:**
```python
import ocote.ocote as ocote

def add(a, b):
    return a + b

my_data = {"x": 42}

class Config:
    debug = True

srv = ocote.server()
srv.expose(
    funcs={"add": add},
    vars={"my_data": my_data},
    objects={"cfg": Config()}
)
srv.post("localhost:8000", api_key="API_KEY")
```
