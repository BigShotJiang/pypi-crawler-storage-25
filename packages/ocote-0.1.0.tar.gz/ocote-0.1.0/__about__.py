__title__ = 'ocote'
__description__ = 'A library built on flask allowing for a socket like connection with encryption to a flask sever.'
__url__ = 'https://github.com/Okerew/ocote'
__version__ = '0.1.0'
__author__ = 'Okerew'
__author_email__ = 'okerewgroup@proton.me'
__license__ = 'MIT'
__keywords__ = 'keyword1, keyword2, keyword3'
__classifiers__ = [
    'Development Status :: 4 - Beta',
    'Intended Audience :: Developers',
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 3.7',
    'Programming Language :: Python :: 3.8',
    'Programming Language :: Python :: 3.9',
    'Programming Language :: Python :: 3.10',
    'Programming Language :: Python :: 3.11',
    'Programming Language :: Python :: 3.12',
]
