import ocote.ocote as ocote

conn = ocote.connect("localhost:8000", "API_KEY")

conn.ping()                        # health check -> True/False
print(conn.func("add", 3, 4).value())     # call with args -> 7
print(conn.variable("my_data").value())   # fetch variable -> {"x": 42}
conn.object("cfg")                 # fetch via pickle -> RemoteResult
add = conn.lazy_func("add")        # get a local callable proxy
print(add(10, 20).value())                # -> 30
