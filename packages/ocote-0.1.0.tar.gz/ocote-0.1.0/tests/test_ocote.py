import ocote.ocote as ocote

def add(a, b):
    return a + b

my_data = {"x": 42}

class Config:
    debug = True

srv = ocote.server()
srv.expose(
    funcs={"add": add},
    vars={"my_data": my_data},
    objects={"cfg": Config()}
)
srv.post("localhost:8000", api_key="API_KEY")
