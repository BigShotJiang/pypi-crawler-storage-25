import time
import hmac
import hashlib
import base64
import os
import json
import datetime
import ipaddress
import tempfile

import requests
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.fernet import Fernet
from flask import Flask, request, jsonify
import urllib3

urllib3.disable_warnings()


_FUNC_ROUTE        = "/ocote/func/<n>"
_VAR_ROUTE         = "/ocote/var/<n>"
_OBJ_ROUTE         = "/ocote/obj/<n>"
_HEALTH_ROUTE      = "/ocote/health"
_CERT_ROUTE        = "/ocote/cert"
_REPLAY_WINDOW     = 30


class OcoteError(Exception):
    pass


class OcoteAuthError(OcoteError):
    pass


class OcoteRemoteError(OcoteError):
    pass


def _derive_fernet_key(api_key: str) -> bytes:
    raw = hashlib.sha256(api_key.encode()).digest()
    return base64.urlsafe_b64encode(raw)


def _make_fernet(api_key: str) -> Fernet:
    return Fernet(_derive_fernet_key(api_key))


def _sign(api_key: str, timestamp: str, body: bytes) -> str:
    msg = timestamp.encode() + b"." + body
    return hmac.new(
        api_key.encode(), msg, hashlib.sha256
    ).hexdigest()


def _verify_signature(
    api_key: str,
    timestamp: str,
    body: bytes,
    signature: str,
) -> bool:
    expected = _sign(api_key, timestamp, body)
    return hmac.compare_digest(expected, signature)


def _check_request(api_key: str):
    ts  = request.headers.get("X-Ocote-Timestamp", "")
    sig = request.headers.get("X-Ocote-Signature", "")

    if not ts or not sig:
        return jsonify({"error": "missing auth headers"}), 401

    try:
        req_time = float(ts)
    except ValueError:
        return jsonify({"error": "invalid timestamp"}), 401

    if abs(time.time() - req_time) > _REPLAY_WINDOW:
        return jsonify({"error": "request expired"}), 401

    body = request.get_data()
    if not _verify_signature(api_key, ts, body, sig):
        return jsonify({"error": "invalid signature"}), 401

    return None


def _encrypt_payload(fernet: Fernet, data: dict) -> bytes:
    return fernet.encrypt(json.dumps(data).encode())


def _decrypt_payload(fernet: Fernet, token: bytes) -> dict:
    return json.loads(fernet.decrypt(token).decode())


def _encrypted_response(fernet: Fernet, data: dict):
    token = _encrypt_payload(fernet, data)
    return jsonify({"payload": token.decode()})


def _generate_self_signed_cert(host: str):
    key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )

    try:
        san = x509.IPAddress(ipaddress.ip_address(host))
    except ValueError:
        san = x509.DNSName(host)

    now  = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, host),
        ]))
        .issuer_name(x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, host),
        ]))
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(
            x509.SubjectAlternativeName([san]),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )

    cert_pem = cert.public_bytes(serialization.Encoding.PEM)
    key_pem  = key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption(),
    )
    return cert_pem, key_pem


class RemoteObject:
    def __init__(self, payload):
        self.__dict__.update(payload.get("attrs", {}))
        self._class_name = payload.get("class", "object")

    def __repr__(self):
        attrs = {
            k: v for k, v in self.__dict__.items()
            if not k.startswith("_")
        }
        return f"RemoteObject({self._class_name}, {attrs!r})"


class RemoteResult:
    def __init__(self, raw):
        self._raw = raw

    def value(self):
        return self._raw

    def __repr__(self):
        return f"RemoteResult({self._raw!r})"


class ServerConnection:
    def __init__(self):
        self._funcs    = {}
        self._vars     = {}
        self._objects  = {}
        self._api_key  = None
        self._fernet   = None
        self._app      = None
        self._cert_pem = None

    def expose(self, funcs=None, vars=None, objects=None):
        if funcs:
            for name, fn in funcs.items():
                if not callable(fn):
                    raise OcoteError(
                        f"'{name}' is not callable"
                    )
                self._funcs[name] = fn
        if vars:
            self._vars.update(vars)
        if objects:
            self._objects.update(objects)
        return self

    def post(self, address, api_key):
        self._api_key = api_key
        self._fernet  = _make_fernet(api_key)
        self._app     = Flask(__name__)

        host, port     = _parse_address(address)
        cert_pem, key_pem = _generate_self_signed_cert(
            host if host != "0.0.0.0" else "127.0.0.1"
        )
        self._cert_pem = cert_pem

        self._register_routes()

        cert_f = tempfile.NamedTemporaryFile(
            delete=False, suffix=".crt"
        )
        key_f  = tempfile.NamedTemporaryFile(
            delete=False, suffix=".key"
        )
        cert_f.write(cert_pem)
        key_f.write(key_pem)
        cert_f.close()
        key_f.close()

        try:
            self._app.run(
                host=host,
                port=port,
                ssl_context=(cert_f.name, key_f.name),
            )
        finally:
            os.unlink(cert_f.name)
            os.unlink(key_f.name)

    def _register_routes(self):
        key    = self._api_key
        fernet = self._fernet
        app    = self._app

        @app.get(_HEALTH_ROUTE)
        def health():
            return jsonify({"status": "ok"})

        @app.get(_CERT_ROUTE)
        def serve_cert():
            return (
                self._cert_pem,
                200,
                {"Content-Type": "application/x-pem-file"},
            )

        @app.post(_FUNC_ROUTE)
        def call_func(n):
            err = _check_request(key)
            if err:
                return err
            if n not in self._funcs:
                return jsonify(
                    {"error": f"function '{n}' not exposed"}
                ), 404
            raw = request.get_data()
            try:
                body   = _decrypt_payload(fernet, raw)
                args   = body.get("args", [])
                kwargs = body.get("kwargs", {})
            except Exception:
                return jsonify(
                    {"error": "decryption failed"}
                ), 400
            try:
                result = self._funcs[n](*args, **kwargs)
                return _encrypted_response(
                    fernet, {"result": result}
                )
            except Exception as e:
                return jsonify({"error": str(e)}), 500

        @app.get(_VAR_ROUTE)
        def get_var(n):
            err = _check_request(key)
            if err:
                return err
            if n not in self._vars:
                return jsonify(
                    {"error": f"variable '{n}' not exposed"}
                ), 404
            return _encrypted_response(
                fernet, {"result": self._vars[n]}
            )

        @app.get(_OBJ_ROUTE)
        def get_obj(n):
            err = _check_request(key)
            if err:
                return err
            if n not in self._objects:
                return jsonify(
                    {"error": f"object '{n}' not exposed"}
                ), 404
            obj     = self._objects[n]
            payload = {
                "class": type(obj).__name__,
                "attrs": obj.__dict__,
            }
            return _encrypted_response(
                fernet, {"result": payload}
            )


class ClientConnection:
    def __init__(self, address, api_key):
        host, port    = _parse_address(address)
        self._base    = f"https://{host}:{port}/ocote"
        self._api_key = api_key
        self._fernet  = _make_fernet(api_key)
        self._ca      = self._fetch_and_pin_cert(host, port)

    def _fetch_and_pin_cert(
        self, host: str, port: int
    ) -> str:
        url = f"https://{host}:{port}/ocote/cert"
        r   = requests.get(url, verify=False)  # noqa: S501
        r.raise_for_status()

        tmp = tempfile.NamedTemporaryFile(
            delete=False, suffix=".crt"
        )
        tmp.write(r.content)
        tmp.close()
        return tmp.name

    def _signed_headers(self, body: bytes) -> dict:
        ts  = str(time.time())
        sig = _sign(self._api_key, ts, body)
        return {
            "X-Ocote-Timestamp": ts,
            "X-Ocote-Signature": sig,
            "Content-Type":      "application/octet-stream",
        }

    def _get(self, path):
        body = b""
        r = requests.get(
            f"{self._base}{path}",
            headers=self._signed_headers(body),
            verify=self._ca,
        )
        return self._unwrap(r)

    def _post(self, path, payload: dict):
        body = _encrypt_payload(self._fernet, payload)
        r = requests.post(
            f"{self._base}{path}",
            data=body,
            headers=self._signed_headers(body),
            verify=self._ca,
        )
        return self._unwrap(r)

    def _unwrap(self, response):
        if response.status_code == 401:
            raise OcoteAuthError(
                "invalid api key or signature"
            )
        data = None
        try:
            data = response.json()
        except Exception:
            pass
        if response.status_code == 404:
            msg = (data or {}).get("error", "not found")
            raise OcoteError(msg)
        if response.status_code != 200:
            msg = (data or {}).get(
                "error",
                f"remote error (http {response.status_code})"
            )
            raise OcoteRemoteError(msg)
        return response

    def _decrypt_response(self, response) -> dict:
        token = response.json()["payload"].encode()
        return _decrypt_payload(self._fernet, token)

    def func(self, name, *args, **kwargs):
        r = self._post(
            f"/func/{name}",
            {"args": list(args), "kwargs": kwargs},
        )
        return RemoteResult(
            self._decrypt_response(r)["result"]
        )

    def variable(self, name):
        r = self._get(f"/var/{name}")
        return RemoteResult(
            self._decrypt_response(r)["result"]
        )

    def object(self, name):
        r = self._get(f"/obj/{name}")
        payload = self._decrypt_response(r)["result"]
        return RemoteResult(RemoteObject(payload))

    def lazy_func(self, name):
        def _caller(*args, **kwargs):
            return self.func(name, *args, **kwargs)
        return _caller

    def ping(self):
        try:
            r = requests.get(
                f"{self._base}/health",
                verify=self._ca,
                timeout=3,
            )
            return r.status_code == 200
        except requests.ConnectionError:
            return False

    def close(self):
        if self._ca and os.path.exists(self._ca):
            os.unlink(self._ca)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def connect(address, api_key):
    return ClientConnection(address, api_key)

def server():
    return ServerConnection()


def _parse_address(address):
    address = str(address)
    if ":" in address:
        host, port = address.rsplit(":", 1)
        host = host or "0.0.0.0"
        return host, int(port)
    return "0.0.0.0", int(address)
