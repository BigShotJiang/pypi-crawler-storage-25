# Next Focus: Dev Example Workflow North Star

Date: 2026-04-06
Status: active

## Summary

The async orchestration sequence that fed this effort is now effectively complete: `#1311` through `#1317` are closed, and `#1315` plus `#1316` are merged. If the north star is "run any issue through the dev example workflow," the remaining work is no longer new async primitives. It is reliability hardening of the local issue-delivery path, plus one docs/tracker cleanup pass.

## Why

- The async execution foundation is in place: background shell tasks, durable output inspection, foreground/background queue separation, detached subagents, structured async results, completion notifications, and routing guidance are all landed.
- The highest-risk remaining gap is still inside the local issue-delivery workflow itself, especially the `existing_work_loop` path and prepare-time worktree correctness.
- The local workflow already models the full end-to-end path we care about: prepare, assess existing work, plan/review, implement, checks, sync, PR open, PR review, and merge readiness.
- The broad backlog still contains many workflow and mission items, but most are not blockers for this north star.
- The async roadmap tracker is stale and should be updated so it reflects that `#1317` is already closed.

## Next Actions

1. Drive `#1301` first. Narrow `review_existing_work`, stop broad timeout-prone repo wandering, and make timeout reporting accurate. This is the clearest direct blocker to rerunning the example workflow on issues with existing work already present.
2. Finish `#1197` and close PR `#1198`. The `prepare_issue` path must reliably start from the current default-branch baseline rather than a stale worktree base.
3. Land `#1199` so `local_cli_issue_flow` has real `git worktree` integration coverage instead of depending only on mocked Git behavior.
4. Land `#1200` so workflow-control and Git-integration changes require explicit real-behavior validation in the example workflow and its review loop.
5. After the reliability items above, close `#1320` to make the product story legible: Anteroom as a governed orchestration layer above agents.
6. Update or close `#1323` so the roadmap reflects the true state of the async sequence and points at the actual remaining work.

## References

- [Developer Workflow](../advanced/developer-workflow.md)
- [Planning and Execution](../planning-and-execution.md)
- [Local Claude/Codex Issue Delivery Workflow](../workflows/local-cli-issue-flow.md)
- [examples/workflows/local_claude_codex_issue_delivery.yaml](../../examples/workflows/local_claude_codex_issue_delivery.yaml)
- [#1301](https://github.com/troylar/anteroom/issues/1301)
- [#1197](https://github.com/troylar/anteroom/issues/1197)
- [#1198](https://github.com/troylar/anteroom/pull/1198)
- [#1199](https://github.com/troylar/anteroom/issues/1199)
- [#1200](https://github.com/troylar/anteroom/issues/1200)
- [#1320](https://github.com/troylar/anteroom/issues/1320)
- [#1323](https://github.com/troylar/anteroom/issues/1323)
