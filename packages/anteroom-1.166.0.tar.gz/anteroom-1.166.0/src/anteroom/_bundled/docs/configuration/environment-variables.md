# Environment Variables

Every AI config option has an environment variable override with the `AI_CHAT_` prefix.

## Reference

| Variable | Default | Description |
|---|---|---|
| `AI_CHAT_BASE_URL` | --- | AI API endpoint (required) |
| `AI_CHAT_API_KEY` | --- | API key (required) |
| `AI_CHAT_MODEL` | `gpt-4` | Model name |
| `AI_CHAT_SYSTEM_PROMPT` | `You are a helpful assistant.` | System prompt |
| `AI_CHAT_VERIFY_SSL` | `true` | SSL certificate verification |
| `AI_CHAT_REQUEST_TIMEOUT` | `120` | Overall stream timeout in seconds (clamped 10–600) |
| `AI_CHAT_CONNECT_TIMEOUT` | `5` | TCP connect timeout in seconds (clamped 1–30) |
| `AI_CHAT_FIRST_TOKEN_TIMEOUT` | `30` | Max seconds to wait for first token after connect (clamped 5–120) |
| `AI_CHAT_RETRY_MAX_ATTEMPTS` | `3` | Retries on transient errors; 0 disables (clamped 0–10) |
| `AI_CHAT_RETRY_BACKOFF_BASE` | `1.0` | Exponential backoff base delay in seconds (clamped 0.1–30.0) |
| `AI_CHAT_TEMPERATURE` | --- | Model temperature for response randomness (0.0–2.0) |
| `AI_CHAT_TOP_P` | --- | Nucleus sampling parameter (0.0–1.0) |
| `AI_CHAT_SEED` | --- | Random seed for deterministic output (integer) |
| `AI_CHAT_PORT` | `8080` | Port for the web server |
| `AI_CHAT_USER_ID` | --- | Override user identity UUID |
| `AI_CHAT_DISPLAY_NAME` | --- | Override user display name |
| `AI_CHAT_PUBLIC_KEY` | --- | Override user public key (PEM) |
| `AI_CHAT_PRIVATE_KEY` | --- | Override user private key (PEM) |
| `AI_CHAT_SAFETY_ENABLED` | `true` | Enable/disable the tool safety gate |
| `AI_CHAT_SAFETY_APPROVAL_MODE` | `ask_for_writes` | Approval mode: `auto`, `ask_for_dangerous`, `ask_for_writes`, `ask` |
| `AI_CHAT_LOG_LEVEL` | `WARNING` | Log level: `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`. Overridden by `--debug` flag |
| `AI_CHAT_TEAM_CONFIG` | --- | Path to team configuration file (YAML). See [Team Config](../configuration/team-config.md) |
| `AI_CHAT_BACKGROUND_SUGGEST_SECONDS` | `30` | Advisory threshold for background shell tasks (0 = disabled) |
| `AI_CHAT_DETACH_SUGGEST_SECONDS` | `120` | Advisory threshold for detached subagents (0 = disabled) |
| `AI_CHAT_MEMORY_PROMOTION_DEFAULT_REVIEW_STATE` | `candidate` | Landing status for new candidates: `candidate` or `pending_review` |
| `AI_CHAT_MEMORY_PROMOTION_LOCAL_AUTO_APPROVE` | `false` | When true, proposals skip review and land in `active` with an `auto_approved` lineage entry |
| `AI_CHAT_MEMORY_PROMOTION_AGENT_PROPOSALS_ENABLED` | `true` | When false, proposer=`agent` is rejected with HTTP 403 |
| `AI_CHAT_MEMORY_PROMOTION_MAX_LINEAGE_ENTRIES` | `50` | FIFO cap on decision-history entries per memory |
| `AI_CHAT_MEMORY_PROMOTION_MAX_CANDIDATES_PER_CONVERSATION` | `10` | Per-conversation proposal cap; overflow returns HTTP 429 with cap / current / retry_hint |
| `AI_CHAT_MEMORY_PROMOTION_MAX_REJECT_REASON_CHARS` | `500` | Server-side bound on rejection reason; router also enforces Pydantic `max_length=2000` |
| `AI_CHAT_MEMORY_RETENTION_ENABLED` | `false` | Master switch for memory-artifact eviction. When false the retention worker touches zero memories regardless of other fields |
| `AI_CHAT_MEMORY_RETENTION_MAX_AGE_DAYS` | _(unset)_ | Purge memories older than N days (by `created_at`). Unset or `0` disables the rule |
| `AI_CHAT_MEMORY_RETENTION_IDLE_DAYS` | _(unset)_ | Purge memories not recalled in N days (by `metadata.last_recalled_at`, falling back to `created_at`). Unset or `0` disables |
| `AI_CHAT_MEMORY_RETENTION_MIN_AGE_DAYS` | `1` | Grace floor against `idle_days`; memories younger than this survive the idle rule |
| `AI_CHAT_MEMORY_RETENTION_PURGE_STATUSES` | `rejected` | Comma-separated list of statuses eligible for status-based eviction. Invalid statuses are filtered out |
| `AI_CHAT_MEMORY_RETENTION_RESPECT_PINS` | `true` | When true, memories with `metadata.pinned == true` are always skipped. Set to `false` as an explicit escape hatch |
| `AI_CHAT_SHOW_ATTRIBUTION_FOOTER` | `true` | CLI `[ctx] …` footer after each assistant turn. Set to `false`/`0`/`no` to suppress. The full snapshot is persisted regardless; `/attribution` continues to work. See [Context Attribution](../knowledge/attribution.md) |

## Usage

Environment variables override config file values. This is useful for:

- CI/CD environments where you can't write config files
- Switching between API endpoints without editing config
- Keeping secrets out of config files

```bash
$ export AI_CHAT_BASE_URL="https://api.openai.com/v1"
$ export AI_CHAT_API_KEY="sk-..."
$ export AI_CHAT_MODEL="gpt-4-turbo"
$ aroom chat
```

## Precedence

Configuration is resolved in this order (highest wins):

1. Defaults (lowest)
2. Team config file (if present)
3. Personal config file (`~/.anteroom/config.yaml`)
4. Environment variables
5. CLI flags (highest)

**Exception**: Fields listed in the team config's `enforce` section override all other sources, including environment variables and CLI flags. See [Team Config](../configuration/team-config.md).
