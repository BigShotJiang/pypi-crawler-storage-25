# Local Documentation Server

Anteroom bundles a local documentation server so you can browse the full docs site on your own machine without depending on an external hosting service.

## Prerequisites

Install the docs-serving dependencies:

```bash
pip install anteroom[docs-serve]
```

This pulls in MkDocs and the Material theme (~50 MB).

## Serving Docs Locally

Start the docs server:

```bash
aroom docs
```

This serves the documentation at `http://127.0.0.1:8400`. Open that URL in your browser to browse the full site with the same navigation and content as the hosted version.

### Custom Port

Override the default port:

```bash
aroom docs --port 8088
```

### Custom Host

Bind to a different address (for example, to expose on a local network):

```bash
aroom docs --host 0.0.0.0
```

## Validating the Docs Build

Run a strict build to catch broken links, missing pages, and config errors:

```bash
aroom docs --build
```

This runs `mkdocs build --strict` under the hood and exits with a non-zero code on any warning or error. Useful for:

- **CI pipelines**: add `aroom docs --build` as a build step
- **Pre-push checks**: run locally before pushing docs changes
- **Contribution workflow**: verify your docs edits build cleanly

## How It Works

The `aroom docs` command is a thin wrapper around MkDocs. It:

1. Checks that MkDocs is installed (via the `docs-serve` extra)
2. Locates the `mkdocs.yml` config file (from the repo root or the bundled package data)
3. Runs `mkdocs serve` (or `mkdocs build --strict` with `--build`)

No Anteroom configuration, database, or API keys are needed.

## Troubleshooting

**"MkDocs is not installed"**

Run `pip install anteroom[docs-serve]` to install the required dependencies.

**"Cannot find mkdocs.yml"**

This can happen if you installed Anteroom from a wheel that does not include bundled docs. Try installing in development mode (`pip install -e ".[docs-serve]"`) from a git clone.
