# Skills

Skills are reusable prompt templates invoked with `/name` in the REPL. They let you define common workflows as single commands — commit helpers, code reviewers, deploy scripts, or any task you run repeatedly.

## Built-in Skills

Twelve skills ship by default:

| Skill | What it does |
|---|---|
| `/commit` | Runs `git diff`, stages relevant files, creates a conventional commit |
| `/review` | Reviews `git diff` for bugs, security issues, performance, error handling, missing tests |
| `/explain` | Reads referenced code and explains architecture, data flow, components, design patterns |
| `/a-help` | Answer questions about Anteroom — config, CLI, tools, skills, architecture. Can inspect installed source code for implementation questions |
| `/create-eval` | Create a promptfoo eval, shell test script, or VHS demo recording |
| `/new-skill` | Interactive guide to create a new custom skill with best practices |
| `/new-pack` | Scaffold a new pack with manifest and artifact files |
| `/artifact-check` | Run artifact health check for quality, conflicts, and optimization |
| `/pack-lint` | Validate a pack directory before install — catch errors early |
| `/pack-publish` | Guide sharing a pack via git for team consumption |
| `/pack-doctor` | Diagnose pack ecosystem issues with guided remediation |
| `/pack-update` | Check for and pull latest pack versions from configured sources |

Built-in skills are bundled in the package at `cli/default_skills/`. They can be overridden by user-defined skills with the same name.

## Using Skills

Type the skill name at the prompt:

```
you> /commit
you> /review just the auth changes
you> /explain @src/services/agent_loop.py focus on the event system
```

Anything after the skill name is passed as arguments. By default, arguments are appended to the skill's prompt as `Additional context: <args>`. If the skill prompt contains `{args}`, the arguments replace the placeholder inline instead (see [Template Variables](#template-variables)).

Use `/skills` to list all available skills with their source. This also reloads skill files from disk, so newly added skills appear immediately:

```
you> /skills
```

Use `/reload-skills` to explicitly reload skill files without listing them.

## Custom Skills

Create `SKILL.md` files to define your own skills. Each skill is a directory containing a `SKILL.md` file with YAML frontmatter for metadata and a Markdown body for the prompt. Skills are loaded from three locations:

### Skill Directories

| Location | Scope | Priority |
|---|---|---|
| Built-in (`cli/default_skills/`) | All users | Lowest — overridden by any user skill |
| `~/.anteroom/skills/` | Global — all projects | Overrides built-in skills |
| `.anteroom/skills/` or `.claude/skills/` (project) | Project-specific | Highest — overrides global and built-in |

### Directory Equivalence

The `.anteroom` and `.claude` directories are interchangeable for skills. Anteroom checks both when walking up from the working directory:

- `.anteroom/skills/` — Anteroom's native directory
- `.claude/skills/` — Claude Code compatible directory

If both exist at the same directory level, `.anteroom/skills/` takes precedence (first match wins). The legacy `.parlor/skills/` directory is also supported for backward compatibility.

!!! note "Anteroom skills use the same frontmatter-based Markdown format as Claude Code commands"
    Both Anteroom skills and Claude Code commands use Markdown with YAML frontmatter. The main differences are directory location (`.anteroom/skills/` vs `.claude/commands/`) and frontmatter fields. See [Porting from Claude Code](porting-from-claude-code.md) for details.

### Discovery

Project-level skills use **walk-up discovery**: Anteroom starts at the current working directory and walks up the directory tree, checking each level for a skills directory. The first match wins — it does not merge skills from multiple directory levels.

```
my-monorepo/
├── .anteroom/
│   └── skills/
│       └── deploy/
│           └── SKILL.md      ← Found for all subdirectories
├── service-a/
│   └── .anteroom/
│       └── skills/
│           └── test/
│               └── SKILL.md  ← Found when working in service-a/
└── service-b/
    └── src/                  ← Walk-up finds ../../.anteroom/skills/
```

Global skills at `~/.anteroom/skills/` are always loaded regardless of project skills.

### SKILL.md Format

Each skill is a directory containing a `SKILL.md` file. The YAML frontmatter carries metadata; the Markdown body is the prompt:

```markdown title="~/.anteroom/skills/test/SKILL.md"
---
name: test
description: Run tests and fix failures
---

Run the test suite. If any tests fail, read the failing test
and the relevant source code, then fix the issue.
```

| Field | Location | Required | Description |
|---|---|---|---|
| `name` | Frontmatter | No | Skill name (used as the `/command`). Defaults to the directory name if omitted. Must match `[a-z0-9][a-z0-9_-]*`. |
| `description` | Frontmatter | No | Short description shown in `/skills` list. Defaults to empty string. |
| `resources` | Frontmatter | No | List of colocated files to bundle with the skill (see [Bundled Skills](#bundled-skills)). |
| `allowed-tools` | Frontmatter | No | Tool allowlist enforced at runtime (see [Tool Policy](porting-from-claude-code.md)). |
| `denied-tools` | Frontmatter | No | Tool denylist enforced at runtime. |
| `license` | Frontmatter | No | Optional license identifier (e.g. `MIT`). Preserved in metadata, displayed in `/skills`. |
| `compatibility` | Frontmatter | No | Optional compatibility hint (e.g. `claude`, `anteroom`). Preserved in metadata. |
| Prompt | Markdown body | Yes | Everything after the closing `---` is the prompt sent to the AI. |

Any frontmatter fields not listed above are preserved in the skill's `metadata` dict and displayed in `/skills` output.

### Spec Compliance

Anteroom's SKILL.md format is aligned with the Agent Skills specification. Advisory warnings are logged at debug level for:

- **Consecutive hyphens** in skill names (spec prefers single hyphens)
- **Underscores** in skill names (spec prefers hyphens; underscores are accepted but warned)
- **Directory name mismatch** when the `name` field doesn't match the parent directory name

These are advisory only — skills still load regardless. Use `--log-level debug` to see them.

### Resource Directories

The Agent Skills spec defines optional `scripts/`, `references/`, and `assets/` directories alongside `SKILL.md`. Anteroom recognizes these directories and logs their presence at debug level, but does not load them at runtime yet. Runtime loading is planned for a future release.

### Bundled Skills

Skills can declare colocated resource files that are inlined into the prompt at load time. This lets you distribute reference material, checklists, or examples alongside a skill without bloating the prompt text itself.

```markdown title="~/.anteroom/skills/deploy/SKILL.md"
---
name: deploy
description: Build and deploy to staging
resources:
  - checklist.md
  - examples/staging.md
---

Follow the deployment checklist and use the staging examples as reference.
```

The resource files live in the skill's directory:

```
skills/
  deploy/
    SKILL.md
    checklist.md
    examples/
      staging.md
```

**Rules:**

- Only files listed in `resources:` are included (no auto-discovery)
- Allowed extensions: `.md`, `.txt`, `.yaml`, `.yml`, `.json`, `.xml`, `.csv`, `.py`, `.js`, `.ts`, `.sh`
- Combined content (SKILL.md prompt + all resources) must fit within 50KB
- Resource paths are relative to the skill directory
- No symlinks or path traversal allowed
- Bundled skills show `[bundle: N resources]` in `/skills` output

For pack skills, the manifest `resources` field takes priority over frontmatter `resources:`:

```yaml
artifacts:
  - type: skill
    name: deploy
    resources:
      - checklist.md
      - examples/staging.md
```

### Skill Name Rules

Skill names must:
- Start with a lowercase letter or digit
- Contain only lowercase letters, digits, hyphens, and underscores
- Match the pattern `[a-z0-9][a-z0-9_-]*`
- **Not shadow built-in commands**: skill names cannot be `quit`, `exit`, `new`, `append`, `tools`, `conventions`, `upload`, `usage`, `help`, `compact`, `last`, `list`, `delete`, `rename`, `slug`, `search`, `skills`, `reload-skills`, `spaces`, `space`, `mcp`, `model`, `plan`, `verbose`, `detail`, `resume`, or `rewind`

Invalid names are rejected with a warning. If a skill name matches a built-in command, it is skipped with a warning to prevent `/invocation` from behaving inconsistently. If `name` is omitted from the frontmatter, the directory name is used (e.g., `deploy/SKILL.md` becomes `/deploy`).

### Template Variables

Use `{args}` in your prompt to control where user arguments are inserted:

```markdown title="~/.anteroom/skills/start-work/SKILL.md"
---
name: start-work
description: Start work on a Jira story
---

You are working on Jira story {args}.
Fetch the story details, create a branch, and begin implementation.
```

When invoked as `/start-work ABC-123`, the prompt becomes:

```
You are working on Jira story ABC-123.
Fetch the story details, create a branch, and begin implementation.
```

If `{args}` is not present in the prompt, arguments are appended as `Additional context: <args>` at the end.

**Note:** `{args}` in the Markdown body works naturally — no special escaping is needed.

### Tool Policy

Skills can restrict which tools the AI is allowed to use during execution. This is useful for imported Claude Code commands that specify `allowed-tools`, or for Anteroom skills where you want to limit the tool surface for safety.

Add `allowed-tools` or `denied-tools` (or both) to the frontmatter:

```markdown title=".anteroom/skills/safe-review/SKILL.md"
---
name: safe-review
description: Review code without modifying anything
denied-tools:
  - write_file
  - edit_file
  - bash
---

Review the git diff for issues. Report findings but do not modify any files.
```

```markdown title=".anteroom/skills/deploy-check/SKILL.md"
---
name: deploy-check
description: Verify deploy readiness
allowed-tools:
  - bash
  - read_file
  - grep
---

Run the test suite and lint checks. Report any failures.
```

| Field | Format | Description |
|---|---|---|
| `allowed-tools` | List of tool names | Only these tools can be used. All others are blocked. |
| `denied-tools` | List of tool names | These tools are blocked. All others are allowed. |

**Enforcement rules:**

- **Deny wins over allow**: if a tool appears in both lists, it is denied.
- **Default**: no restrictions. Skills without policy fields behave exactly as they do today.
- **Runtime enforcement**: the policy is checked at tool dispatch time, not as prompt guidance. A denied tool returns an error to the AI with the reason.
- **Turn-scoped**: the policy applies only during the skill's execution turn. It does not leak into subsequent messages or concurrent requests.

**Claude compatibility:** Both hyphenated (`allowed-tools`, `denied-tools`) and underscored (`allowed_tools`, `denied_tools`) formats are supported. The hyphenated format matches Claude Code's frontmatter convention; the underscored format is Anteroom's native format.

The `/skills` command shows policy summaries for skills that have restrictions:

```
- /safe-review — Review code without modifying anything [deny=bash,edit_file,write_file] (project)
- /deploy-check — Verify deploy readiness [allow=bash,grep,read_file] (project)
- /commit — Commit changes (default)
```

### More Examples

```markdown title=".anteroom/skills/deploy/SKILL.md"
---
name: deploy
description: Build and deploy to staging
---

1. Run the full test suite
2. Build the production bundle
3. Deploy to the staging environment
4. Verify the deployment is healthy
```

```markdown title="~/.anteroom/skills/security-review/SKILL.md"
---
name: security-review
description: OWASP security review of recent changes
---

Review the git diff for security issues against OWASP ASVS Level 2:
- SQL injection (string concatenation in queries)
- Command injection (shell=True with user input)
- Path traversal (unsanitized file paths)
- XSS (innerHTML with user input)
- Hardcoded secrets
- Missing input validation
Report each finding with file, line, severity, and fix.
```

## Precedence

When multiple skills share the same name, the highest-priority source wins:

```
Built-in → Global (~/.anteroom/skills/) → Project (.anteroom/skills/ or .claude/skills/)
  lowest              middle                     highest
```

This means:
- A project skill named `commit` overrides the built-in `/commit`
- A global skill named `commit` also overrides the built-in
- A project skill overrides a global skill of the same name

When a user skill overrides a built-in, a warning is shown in the `/skills` output.

### Referenced Skills

Skills can also be loaded via explicit `references.skills` paths in your config file:

```yaml
references:
  skills:
    - skills/deploy          # directory containing SKILL.md
    - skills/review/SKILL.md  # or explicit path to SKILL.md
```

Referenced skills have the **highest precedence** — they override same-name skills from any other source (built-in, directory-discovered, or pack/artifact). Paths are resolved relative to the config file that declares them.

The full precedence order is:

```
Built-in → Global → Project → Pack/Artifact → Referenced
  lowest                                        highest
```

### Updating Skills

The correct way to update a skill depends on where it came from. Anteroom shows this information in `/skills` and includes it in the model-facing skill catalog so the AI agent knows the right approach.

| Source | How to update |
|---|---|
| **Built-in** | Cannot be edited directly. Create a local override with `/new-skill <name>` — local skills take precedence over built-ins. |
| **Local** (global or project directory) | Edit the SKILL.md file directly at the path shown in `/skills`. |
| **Reference** (config `references.skills` path) | Edit the file at the referenced path. |
| **Pack-installed** (with editable source) | Edit the pack source and run `/pack update`, or create a local override with `/new-skill <name>`. |
| **Pack-installed** (no local source) | Create a local override with `/new-skill <name>` — the local version takes precedence. |

The `/skills` command shows update guidance for each skill. The model-facing catalog also includes this guidance, so when you ask the AI to "update the deploy skill," it knows whether to edit a file, create an override, or explain that the skill comes from a pack.

### Load Warnings

If a skill file has errors (invalid frontmatter, empty prompt body, invalid name), Anteroom skips it and records a warning. Warnings are shown:

- At REPL startup (printed in yellow)
- In `/skills` and `/reload-skills` output (listed after the skill table)

Common mistakes and their fixes:

| Error | Cause | Fix |
|---|---|---|
| "mapping values not allowed here" | Unquoted colons in values, or `{args}` in prompt | Use block scalar `prompt: \|` for multi-line prompts |
| "missing YAML frontmatter" | File does not start with `---` | Add frontmatter block at the top |
| "no closing ---" | Missing closing `---` delimiter | Ensure frontmatter ends with `---` on its own line |
| Skill silently missing | Invalid name (uppercase, special chars) | Use lowercase alphanumeric with hyphens/underscores |

## Hot Reload

Skills are reloaded from disk every time you run `/skills` or `/reload-skills`. You do not need to restart the REPL to pick up new or modified skill files.

## How Skills Work Internally

When you type `/commit fix the auth bug`:

1. The REPL checks if `commit` is a registered skill name
2. If found, the skill's `prompt` is used as the message
3. If the prompt contains `{args}`, `fix the auth bug` replaces it inline; otherwise it's appended as `Additional context: fix the auth bug`
4. The expanded prompt is sent to the AI as a normal message
5. The AI processes it like any other message — it can use tools, write files, run commands

Skills are purely prompt templates — they don't have special permissions or capabilities beyond what you'd get by typing the same text manually.

## Skills from Packs

Skills can also be distributed as pack artifacts. When a pack containing skill artifacts is installed, those skills are registered in the artifact registry and become available as `/skill-name` commands, just like file-based skills.

Pack skills participate in the same precedence system. A pack skill installed at the `project` layer overrides a built-in skill with the same name. A local skill file overrides a pack skill.

### Namespace-Qualified Skill Names

When two attached packs define a skill with the same name, the bare name becomes **ambiguous**. Anteroom resolves this with namespace-qualified names:

```
/deploy               → ambiguous (two packs define it)
/team-alpha/deploy    → resolves to team-alpha's version
/team-beta/deploy     → resolves to team-beta's version
```

When you try to use an ambiguous bare name, Anteroom shows a warning with the qualified options:

```
Ambiguous skill 'deploy' -- qualify with namespace: /team-alpha/deploy, /team-beta/deploy
```

If a skill name is unique across all attached packs, the bare name works as usual — no qualification needed.

The AI's `invoke_skill` tool uses only unambiguous and qualified names in its enum, so it always resolves correctly.

To see which skills come from packs:

```bash
$ aroom artifact list --type skill
```

See [Packs & Artifacts](../packs/index.md) for details on creating and installing packs with skills. See [How Packs Work: Skill Resolution](../packs/how-packs-work.md#skill-resolution-namespace-aware) for the full disambiguation logic.

## Compatibility

The `.anteroom` and `.claude` directories are fully interchangeable for skills:

- A project using `.claude/skills/` works with Anteroom automatically
- A project using `.anteroom/skills/` follows the same behavior
- Walk-up discovery checks both `.anteroom/skills/` and `.claude/skills/` at each directory level
- `.anteroom/skills/` takes precedence over `.claude/skills/` if both exist at the same level

## See Also

- [Porting from Claude Code](porting-from-claude-code.md) — converting Claude Code command files to Anteroom skills
- [Skill Examples](skill-examples.md) — complete example skills with sub-agents, bash workflows, and more
- [Built-in Tools: run_agent](tools.md#run_agent) — sub-agent tool reference for advanced skills
