# Skill

A reusable prompt template that users invoke with `/skill-name` or the AI invokes via the `invoke_skill` tool.

**Content format**: A directory named `skills/<name>/` containing a `SKILL.md` file with YAML frontmatter (the `name` and `description` fields) and a Markdown body (the prompt text).

**How Anteroom uses it**: Skills are registered in the `SkillRegistry` and exposed as tab-completable slash commands. When invoked, the Markdown body is expanded (with `{args}` template substitution) and sent as the user message.

**Example**:

```markdown title="skills/review/SKILL.md"
---
name: review
description: Review code changes for quality and security
---
Review the following code changes for:
- Security vulnerabilities (OWASP Top 10)
- Code quality and maintainability
- Test coverage gaps

{args}
```

**Directory**: `skills/<name>/SKILL.md`

**Common mistakes**:

- Forgetting the `name` field in the frontmatter (required, must match the artifact name)
- Using `{args}` inside a fenced code block (substitution only happens outside code fences)
- Exceeding the 50KB prompt size limit
