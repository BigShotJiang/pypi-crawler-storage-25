"""Contract tests for the /new-skill built-in skill.

These tests pin the structural requirements of new-skill/SKILL.md so that
if someone edits the instructions and removes safeguards, CI catches
it immediately.  Follows the test_excalidraw_skill.py pattern.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from anteroom.cli.skills import SkillRegistry


def _parse_frontmatter(path):
    """Parse a SKILL.md file, returning a dict with name, description, prompt."""
    import yaml as _yaml

    raw = path.read_text(encoding="utf-8")
    assert raw.startswith("---\n"), f"{path} missing frontmatter"
    end = raw.index("\n---", 4)
    fm = _yaml.safe_load(raw[4:end])
    fm["prompt"] = raw[end + 4 :].strip()
    return fm


_SKILL_PATH = (
    Path(__file__).resolve().parents[2] / "src" / "anteroom" / "cli" / "default_skills" / "new-skill" / "SKILL.md"
)


def _load_prompt() -> str:
    data = _parse_frontmatter(_SKILL_PATH)
    return data["prompt"]


class TestNewSkillContract:
    """Pin /new-skill prompt requirements so regressions are caught by CI."""

    def test_yaml_file_exists(self) -> None:
        assert _SKILL_PATH.exists(), f"new-skill/SKILL.md not found at {_SKILL_PATH}"

    def test_yaml_parses_correctly(self) -> None:
        data = _parse_frontmatter(_SKILL_PATH)
        assert isinstance(data, dict)

    def test_has_required_fields(self) -> None:
        data = _parse_frontmatter(_SKILL_PATH)
        assert data.get("name") == "new-skill"
        assert "description" in data
        assert "prompt" in data
        assert isinstance(data["prompt"], str)
        assert len(data["prompt"]) > 100

    def test_forbids_content_field(self) -> None:
        """Prompt must explicitly tell the model NOT to use 'content:' for local CLI skills."""
        prompt = _load_prompt()
        assert "Do NOT use `content:`" in prompt, (
            "Prompt must contain the explicit prohibition 'Do NOT use `content:`' "
            "to guard against the common content-vs-prompt mistake"
        )

    def test_uses_skillmd_format(self) -> None:
        """Prompt must describe SKILL.md directory-based format, not legacy YAML."""
        prompt = _load_prompt()
        prompt_lower = prompt.lower()
        assert "skill.md" in prompt_lower, "Prompt must reference SKILL.md format"
        assert "frontmatter" in prompt_lower, "Prompt must mention YAML frontmatter"

    def test_requires_post_write_validation(self) -> None:
        """Prompt must require reading the file back and validating structure."""
        prompt = _load_prompt()
        prompt_lower = prompt.lower()
        assert "read" in prompt_lower and ("back" in prompt_lower or "file" in prompt_lower), (
            "Prompt must instruct to read the file back after writing"
        )
        assert "---" in prompt and "frontmatter" in prompt_lower, (
            "Prompt must instruct to verify valid frontmatter delimiters"
        )
        assert "non-empty" in prompt_lower or "non empty" in prompt_lower, (
            "Prompt must instruct to verify the prompt content is non-empty"
        )

    def test_loaded_by_skill_registry(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            reg = SkillRegistry()
            reg.load(tmpdir)
            assert reg.has_skill("new-skill")
            skill = reg.get("new-skill")
            assert skill is not None
            assert skill.source == "default"
