import math
from pathlib import Path
from functools import partial
from collections import namedtuple
from multiprocessing import cpu_count

import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.optim import SGD
import torchvision.models as tvm
from torchvision import transforms as T

from einops import rearrange, repeat
from einops.layers.torch import Rearrange

from tqdm.auto import tqdm
from accelerate import Accelerator

# ──────────────────────────────────────────────
# constants
# ──────────────────────────────────────────────

EmpSSLOutput = namedtuple('EmpSSLOutput', ['loss', 'tcr_loss', 'inv_loss'])

# ──────────────────────────────────────────────
# helpers
# ──────────────────────────────────────────────

def exists(x):
    return x is not None

def default(val, d):
    if exists(val):
        return val
    return d() if callable(d) else d

def cycle(dl):
    while True:
        for data in dl:
            yield data

def divisible_by(numer, denom):
    return (numer % denom) == 0

def cast_tuple(t, length = 1):
    if isinstance(t, tuple):
        return t
    return ((t,) * length)

# ──────────────────────────────────────────────
# augmentation
# ──────────────────────────────────────────────

def build_patch_augmentation(image_size, patch_size):
    """
    Augmentation pipeline identical to VICReg (Bardes et al. 2022).
    Crops a patch of `patch_size`, resizes to `image_size`, then applies
    color jitter, grayscale, gaussian blur, and solarization.
    """
    kernel = max(int(0.1 * image_size), 1)
    kernel = kernel if kernel % 2 == 1 else kernel + 1

    return T.Compose([
        T.RandomCrop(patch_size, padding=patch_size // 4),
        T.Resize(image_size),
        T.RandomHorizontalFlip(p = 0.5),
        T.RandomApply([
            T.ColorJitter(brightness = 0.4, contrast = 0.4,
                          saturation = 0.2, hue = 0.1)
        ], p = 0.8),
        T.RandomGrayscale(p = 0.2),
        T.RandomApply([T.GaussianBlur(kernel_size = kernel)], p = 0.1),
        T.RandomSolarize(threshold = 128, p = 0.2),
        T.ToTensor(),
        T.Normalize(mean = [0.485, 0.456, 0.406],
                    std  = [0.229, 0.224, 0.225]),
    ])

# ──────────────────────────────────────────────
# dataset
# ──────────────────────────────────────────────

class MultiPatchDataset(Dataset):
    """
    Wraps any torchvision-style dataset that returns (PIL Image, label).
    For each image, samples `num_patches` independently augmented crops.

    Args:
        base_dataset : torchvision dataset with transform=None
        image_size   : final resolution fed to the encoder (e.g. 32 for CIFAR)
        patch_size   : initial crop size before upsampling (e.g. 16 for CIFAR)
        num_patches  : number of patches per image (paper uses 200, 20 is fast)
    """
    def __init__(
        self,
        base_dataset,
        *,
        image_size,
        patch_size,
        num_patches = 200,
    ):
        self.dataset = base_dataset
        self.num_patches = num_patches
        self.augment = build_patch_augmentation(image_size, patch_size)

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        img, label = self.dataset[idx]
        # img is a PIL Image — apply augmentation n times independently
        patches = torch.stack([self.augment(img) for _ in range(self.num_patches)])
        return patches, label  # (n, c, h, w), int

# ──────────────────────────────────────────────
# losses
# ──────────────────────────────────────────────

def total_coding_rate(Z, eps = 0.2):
    """
    R(Z) = 0.5 * log det( I_b + d / (b² · ε) · Z Zᵀ )

    Z   : (b, d) — normalized patch projections for one view across batch
    eps : distortion parameter ε from the paper (default 0.2)
    """
    b, d = Z.shape
    I = torch.eye(b, device = Z.device, dtype = Z.dtype)
    M = I + (d / (b ** 2 * eps)) * (Z @ Z.T)
    sign, logdet = torch.linalg.slogdet(M)
    return 0.5 * logdet

# ──────────────────────────────────────────────
# network modules
# ──────────────────────────────────────────────

def build_resnet18_encoder():
    """ResNet-18 backbone with identity FC. Returns (encoder, feat_dim=512)."""
    enc = tvm.resnet18(weights = None)
    enc.fc = nn.Identity()
    return enc, 512

class Projector(nn.Module):
    """2-layer MLP projector: in_dim → hidden_dim → out_dim (L2-normalised)."""
    def __init__(self, in_dim, hidden_dim = 4096, out_dim = 512):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace = True),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, x):
        return F.normalize(self.net(x), dim = -1)

# ──────────────────────────────────────────────
# main model
# ──────────────────────────────────────────────

class EMPSSL(nn.Module):
    """
    Extreme Multi-Patch Self-Supervised Learning (EMP-SSL).
    Tong et al. 2023 — https://arxiv.org/abs/2304.03977

    Instead of 2 views, generates n patches per image and maximises the
    Total Coding Rate (TCR) + cosine invariance objective jointly.

    Args:
        image_size      : spatial resolution of encoder input (e.g. 32)
        encoder         : backbone nn.Module; defaults to ResNet-18
        encoder_dim     : output dim of the encoder (512 for ResNet-18)
        num_patches     : n in the paper (200 for full, 20 for fast mode)
        proj_hidden_dim : projector hidden size (paper: 4096)
        proj_out_dim    : projector output size (paper: 512)
        inv_weight      : λ weighting the invariance term (paper: 200.0)
        tcr_eps         : ε distortion parameter in TCR (paper: 0.2)
    """
    def __init__(
        self,
        *,
        image_size,
        encoder = None,
        encoder_dim = 512,
        num_patches = 200,
        proj_hidden_dim = 4096,
        proj_out_dim = 512,
        inv_weight = 200.0,
        tcr_eps = 0.2,
    ):
        super().__init__()

        if exists(encoder):
            self.encoder = encoder
        else:
            self.encoder, encoder_dim = build_resnet18_encoder()

        self.num_patches = num_patches
        self.inv_weight  = inv_weight
        self.tcr_eps     = tcr_eps

        self.projector = Projector(encoder_dim, proj_hidden_dim, proj_out_dim)

    def forward(self, patches):
        """
        patches : (b, n, c, h, w)  — output of MultiPatchDataset
        returns : EmpSSLOutput(loss, tcr_loss, inv_loss)

        Objective (maximised, so we minimise the negation):
            1/n · Σᵢ [ R(Zᵢ) + λ · D(Zᵢ, Z̄) ]
        where D is cosine similarity and Z̄ is the mean projection.
        """
        b, n, c, h, w = patches.shape

        # ── encode all n patches for all b images in one batched call ──
        imgs_flat = rearrange(patches, 'b n c h w -> (b n) c h w')
        feats     = self.encoder(imgs_flat)                          # (b·n, d_enc)
        feats     = rearrange(feats, '(b n) d -> b n d', b = b, n = n)

        # ── project & L2-normalise ──
        Z = self.projector(rearrange(feats, 'b n d -> (b n) d'))    # (b·n, d_proj)
        Z = rearrange(Z, '(b n) d -> b n d', b = b, n = n)         # (b, n, d_proj)

        # ── TCR loss: average R(Zᵢ) over all n patch views ──
        tcr_loss = torch.stack([
            total_coding_rate(Z[:, i, :], eps = self.tcr_eps)
            for i in range(n)
        ]).mean()

        # ── Invariance loss: cosine sim between each Zᵢ and mean Z̄ ──
        Z_bar    = Z.mean(dim = 1, keepdim = True)                  # (b, 1, d_proj)
        inv_loss = F.cosine_similarity(
            rearrange(Z,     'b n d -> (b n) d'),
            repeat(Z_bar, 'b 1 d -> (b n) d', n = n),
            dim = -1,
        ).mean()

        # maximise → negate for gradient descent
        loss = -(tcr_loss + self.inv_weight * inv_loss)

        return EmpSSLOutput(loss, tcr_loss, inv_loss)

    @torch.no_grad()
    def encode(self, patches):
        """
        Bag-of-features representation for linear probing.

        patches : (b, n, c, h, w)
        returns : (b, encoder_dim)  — mean of n patch embeddings
        """
        self.eval()
        b, n, c, h, w = patches.shape
        imgs_flat = rearrange(patches, 'b n c h w -> (b n) c h w')
        feats     = self.encoder(imgs_flat)
        feats     = rearrange(feats, '(b n) d -> b n d', b = b, n = n)
        return feats.mean(dim = 1)

# ──────────────────────────────────────────────
# linear prober (for evaluation)
# ──────────────────────────────────────────────

class LinearProber(nn.Module):
    """Frozen-encoder linear classifier for representation evaluation."""
    def __init__(self, in_dim, num_classes):
        super().__init__()
        self.fc = nn.Linear(in_dim, num_classes)

    def forward(self, x):
        return self.fc(x)

# ──────────────────────────────────────────────
# trainer
# ──────────────────────────────────────────────

class Trainer:
    """
    Accelerate-backed trainer for EMPSSL.

    Uses SGD + cosine LR decay as an approximation to the LARS optimizer
    described in the paper (Eq. settings: lr=0.3, wd=1e-4, momentum=0.9).

    Args:
        model           : EMPSSL instance
        dataset         : MultiPatchDataset instance
        batch_size      : images per step (paper: 100)
        num_train_steps : total gradient steps (500 steps/epoch × epochs)
        lr              : base learning rate (paper: 0.3)
        weight_decay    : L2 penalty (paper: 1e-4)
        results_folder  : where checkpoints are saved
        save_every      : checkpoint every N steps
        log_every       : tqdm update frequency
    """
    def __init__(
        self,
        model,
        dataset,
        *,
        batch_size = 100,
        num_train_steps = 15000,
        lr = 0.3,
        weight_decay = 1e-4,
        results_folder = './results',
        save_every = 1000,
        log_every = 50,
    ):
        self.accelerator = Accelerator(mixed_precision = 'fp16')

        self.dl = DataLoader(
            dataset,
            batch_size  = batch_size,
            shuffle     = True,
            num_workers = min(4, cpu_count()),
            pin_memory  = True,
            drop_last   = True,
        )

        self.opt = SGD(
            model.parameters(),
            lr           = lr,
            momentum     = 0.9,
            weight_decay = weight_decay,
        )

        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.opt, T_max = num_train_steps, eta_min = 0.
        )

        (
            self.model,
            self.opt,
            self.dl,
            self.scheduler,
        ) = self.accelerator.prepare(model, self.opt, self.dl, self.scheduler)

        self.num_train_steps = num_train_steps
        self.save_every      = save_every
        self.log_every       = log_every
        self.results_folder  = Path(results_folder)
        self.results_folder.mkdir(parents = True, exist_ok = True)
        self.step = 0

    def save(self, milestone):
        data = {
            'step':  self.step,
            'model': self.accelerator.get_state_dict(self.model),
        }
        torch.save(data, str(self.results_folder / f'checkpoint-{milestone}.pt'))

    def load(self, milestone):
        data = torch.load(
            str(self.results_folder / f'checkpoint-{milestone}.pt'),
            map_location = 'cpu',
        )
        self.step = data['step']
        self.accelerator.unwrap_model(self.model).load_state_dict(data['model'])

    def train(self):
        dl = cycle(self.dl)

        with tqdm(
            total   = self.num_train_steps,
            disable = not self.accelerator.is_main_process,
        ) as pbar:
            while self.step < self.num_train_steps:
                patches, _ = next(dl)

                with self.accelerator.autocast():
                    out  = self.model(patches)
                    loss = out.loss

                self.accelerator.backward(loss)
                self.opt.step()
                self.scheduler.step()
                self.opt.zero_grad()

                if self.accelerator.is_main_process and self.step % self.log_every == 0:
                    pbar.set_description(
                        f'step {self.step} | '
                        f'loss {loss.item():.3f} | '
                        f'tcr {out.tcr_loss.item():.3f} | '
                        f'inv {out.inv_loss.item():.3f}'
                    )

                if self.step % self.save_every == 0:
                    self.save(self.step)

                self.step += 1
                pbar.update(1)

        self.accelerator.print('training complete')
