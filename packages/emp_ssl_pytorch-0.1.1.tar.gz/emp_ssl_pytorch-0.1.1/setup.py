from setuptools import setup, find_packages

exec(open('emp_ssl_pytorch/version.py').read())

setup(
    name = 'emp-ssl-pytorch',
    packages = find_packages(),
    version = __version__,
    license = 'MIT',
    description = 'EMP-SSL: Extreme Multi-Patch Self-Supervised Learning - Pytorch',
    author = 'Mohamedibrahim',
    author_email = 'mibrahi2@uni-bonn.de',
    url = 'https://github.com/MohamedFarag21/emp-ssl-pytorch',
    long_description_content_type = 'text/markdown',
    keywords = [
        'artificial intelligence',
        'deep learning',
        'self-supervised learning',
        'contrastive learning',
        'representation learning',
    ],
    install_requires = [
        'accelerate',
        'einops>=0.7',
        'torch>=2.0',
        'torchvision>=0.15',
        'tqdm',
    ],
    classifiers = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.8',
    ],
)
