# EMP-SSL — Extreme Multi-Patch Self-Supervised Learning, in Pytorch

Implementation of [EMP-SSL: Towards Self-Supervised Learning in One Training Epoch](https://arxiv.org/abs/2304.03977) (Tong et al., 2023) in Pytorch.

Instead of using just 2 augmented views per image, EMP-SSL generates **n=200 random patch crops** per image and jointly maximises the Total Coding Rate (TCR) and cosine invariance across all patches — achieving SOTA self-supervised performance in **under 10 epochs** instead of 1000.

## Install

```bash
$ pip install emp-ssl-pytorch
```

## Real Training Example

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/MohamedFarag21/emp-ssl-pytorch/blob/main/real_test.ipynb)

Train on CIFAR-10 for 30 epochs with 20 patches — reproducing Table 2 of the paper.

## Usage

```python
import torch
from emp_ssl_pytorch import EMPSSL, MultiPatchDataset, Trainer
from torchvision.datasets import CIFAR10

# dataset — must return PIL images (transform=None)
base = CIFAR10(root = './data', train = True, download = True, transform = None)

dataset = MultiPatchDataset(
    base,
    image_size  = 32,    # encoder input resolution
    patch_size  = 16,    # random crop size before upsampling
    num_patches = 200,   # n in the paper (use 20 for fast mode)
)

model = EMPSSL(
    image_size      = 32,
    num_patches     = 200,
    proj_hidden_dim = 4096,
    proj_out_dim    = 512,
    inv_weight      = 200.0,
    tcr_eps         = 0.2,
)

trainer = Trainer(
    model,
    dataset,
    batch_size      = 100,
    num_train_steps = 15000,   # 30 epochs on CIFAR-10 (500 steps/epoch)
    lr              = 0.3,
    results_folder  = './results',
)

trainer.train()
```

## Linear Probing

After training, extract bag-of-features representations and train a linear head:

```python
import torch
from torch.utils.data import DataLoader
from emp_ssl_pytorch import EMPSSL, MultiPatchDataset, LinearProber

# ── extract features ──────────────────────────────────────────
model.eval()
features, labels = [], []

eval_dataset = MultiPatchDataset(
    CIFAR10(root = './data', train = False, download = True, transform = None),
    image_size  = 32,
    patch_size  = 16,
    num_patches = 20,   # fewer patches is fine at eval time
)

for patches, label in DataLoader(eval_dataset, batch_size = 64):
    with torch.no_grad():
        feat = model.encode(patches)
    features.append(feat)
    labels.append(label)

features = torch.cat(features)  # (N, 512)
labels   = torch.cat(labels)

# ── linear head ───────────────────────────────────────────────
from emp_ssl_pytorch import LinearProber
from torch.optim import SGD

prober = LinearProber(in_dim = 512, num_classes = 10)
opt    = SGD(prober.parameters(), lr = 0.03, momentum = 0.9, weight_decay = 0.)

for epoch in range(100):
    logits = prober(features)
    loss   = torch.nn.functional.cross_entropy(logits, labels)
    loss.backward()
    opt.step()
    opt.zero_grad()

acc = (prober(features).argmax(dim = -1) == labels).float().mean()
print(f'Linear probing accuracy: {acc:.4f}')
```

## Multi-GPU

```bash
$ accelerate config
$ accelerate launch train.py
```

## Method Summary

For each image **x** in a batch:
1. Generate **n** random augmented crops x₁, …, xₙ
2. Encode each with ResNet-18 → embed **hᵢ** → project **zᵢ** (L2-normalised)
3. Maximise: `1/n Σᵢ [ R(Zᵢ) + λ · D(Zᵢ, Z̄) ]`

where:
- **R(Z)** = Total Coding Rate = `0.5 · log det(I + d/(b²ε) · ZZᵀ)`
- **D(Z₁, Z₂)** = `Tr(Z₁ᵀ Z₂)` (cosine similarity across batch)
- **Z̄** = mean projection across all n views

## Results (from paper, ResNet-18 backbone)

| Dataset       | 1 Epoch | 10 Epochs | 30 Epochs |
|:-------------|--------:|----------:|----------:|
| CIFAR-10      | 85.1%   | 91.5%     | 93.4%     |
| CIFAR-100     | 58.5%   | 70.1%     | 73.3%     |
| Tiny ImageNet | 38.1%   | 51.5%     | —         |

*Linear probing accuracy, n=200 patches*

## Citations

```bibtex
@article{Tong2023EMPSSL,
    title   = {EMP-SSL: Towards Self-Supervised Learning in One Training Epoch},
    author  = {Shengbang Tong and Yubei Chen and Yi Ma and Yann LeCun},
    journal = {arXiv},
    year    = {2023},
    url     = {https://arxiv.org/abs/2304.03977}
}
```
