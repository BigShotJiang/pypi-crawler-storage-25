# Changelog

All notable changes to `dtpyfw` are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## Versions

| Version | Date | Highlights |
|---|---|---|
| [1.8](docs/changelogs/1.8.md) | 2026-05-21 | Drop default brotli compression (fragile codec coupling from 1.0); remove the autodiscover boot diagnostics |
| [1.6](docs/changelogs/1.6.md) | 2026-05-21 | `Worker.create()` uses lazy `autodiscover_tasks(..., related_name=None)` — fixes 1.5's circular-import regression |
| [1.5](docs/changelogs/1.5.md) | 2026-05-21 | `Worker.create()` eagerly imports task modules — fixes silent `NotRegistered` on Celery 5.6 (regressed: circular import; superseded by 1.6) |
| [1.4](docs/changelogs/1.4.md) | 2026-05-21 | `LoggerHandler` ships logs synchronously — fixes silent drop from forked Celery/gunicorn children |
| [1.3](docs/changelogs/1.3.md) | 2026-04-26 | `emit_startup_report` dedupes per parent process (Gunicorn/Celery siblings) |
| [1.2](docs/changelogs/1.2.md) | 2026-04-26 | New `dtpyfw.diagnostics` subpackage; `FTPClient.check_connection()` |
| [1.1](docs/changelogs/1.1.md) | 2026-04-24 | `OpenSearchConfig.from_env()` reads multi-node + SSL env vars |
| [1.0](docs/changelogs/1.0.md) | 2026-04-24 | Python 3.13, full audit pass, production-stable — first stable release |
