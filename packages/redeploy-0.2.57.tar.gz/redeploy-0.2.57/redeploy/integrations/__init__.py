"""Redeploy integrations."""
