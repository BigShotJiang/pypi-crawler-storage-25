#!/usr/bin/env python3
import argparse
import os
import subprocess
import sys
import time
import signal
import httpx
import yaml
import json
from pathlib import Path

def load_config():
    cfg_path = os.environ.get("PROXY_CONFIG", "config.yaml")
    path = Path(cfg_path)
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}

def get_proxy_url(config):
    server = config.get("server", {})
    host = os.environ.get("PROXY_HOST") or server.get("host", "127.0.0.1")
    port = int(os.environ.get("PROXY_PORT") or server.get("port", 8787))
    return f"http://{host}:{port}"

def get_default_model(config):
    nvidia = config.get("nvidia", {})
    return os.environ.get("DEFAULT_NVIDIA_MODEL") or nvidia.get("default_model", "nvidia/llama-3.3-nemotron-super-49b-v1.5")

def wait_for_proxy(url, timeout=30):
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            with httpx.Client() as client:
                resp = client.get(f"{url}/healthz")
                if resp.status_code == 200:
                    return True
        except Exception:
            pass
        time.sleep(0.5)
    return False

def run_proxy():
    proxy_path = Path(__file__).parent / "proxy.py"
    import tempfile
    log_file = tempfile.NamedTemporaryFile(delete=False, prefix="nim-proxy-", suffix=".log")
    
    process = subprocess.Popen(
        [sys.executable, str(proxy_path)],
        stdout=log_file,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1
    )
    return process, log_file.name

def run_claude(proxy_url, model):
    env = os.environ.copy()
    env["ANTHROPIC_BASE_URL"] = proxy_url
    env["ANTHROPIC_API_KEY"] = env.get("ANTHROPIC_API_KEY", "not-used")
    env["ANTHROPIC_CUSTOM_MODEL_OPTION"] = model
    env["ANTHROPIC_DEFAULT_HAIKU_MODEL"] = model
    env["ANTHROPIC_DEFAULT_OPUS_MODEL"] = model
    env["ANTHROPIC_DEFAULT_SONNET_MODEL"] = model
    env["CLAUDE_CODE_SUBAGENT_MODEL"] = model
    env["CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS"] = "1"
    
    print("\n" + "="*60)
    print(f"🚀 NIM PROXY ACTIVE → {proxy_url}")
    print(f"🤖 MODEL            → {model}")
    print("="*60 + "\n")
    
    try:
        subprocess.run(["claude"], env=env, check=True)
    except FileNotFoundError:
        print("❌ Error: 'claude' command not found. Please install Claude Code first.")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"⚠️ Claude Code exited with code {e.returncode}")

def cmd_status(args):
    config = load_config()
    url = get_proxy_url(config)
    print(f"🔍 Checking NIM Proxy status at {url}...")
    
    # Check if NVIDIA_API_KEY is set
    if not os.environ.get("NVIDIA_API_KEY"):
        print("⚠️ Warning: NVIDIA_API_KEY environment variable is NOT set.")
    else:
        print("✅ NVIDIA_API_KEY is set.")

    try:
        with httpx.Client() as client:
            resp = client.get(f"{url}/healthz", timeout=2.0)
            if resp.status_code == 200:
                print(f"✅ Proxy is UP and healthy.")
                try:
                    m_resp = client.get(f"{url}/v1/models", timeout=2.0)
                    if m_resp.status_code == 200:
                        models = m_resp.json().get("data", [])
                        print(f"📊 Active models: {len(models)}")
                except Exception:
                    pass
            else:
                print(f"⚠️ Proxy returned unexpected status {resp.status_code}")
    except Exception:
        print(f"❌ Proxy is DOWN.")
        sys.exit(1)

def cmd_models(args):
    config = load_config()
    url = get_proxy_url(config)
    print(f"🔍 Fetching models from {url}...")
    try:
        with httpx.Client() as client:
            resp = client.get(f"{url}/v1/models", timeout=5.0)
            if resp.status_code == 200:
                models = resp.json().get("data", [])
                print("\nAvailable NVIDIA NIM Models:")
                print("-" * 60)
                for m in sorted(models, key=lambda x: x["id"]):
                    print(f"• {m['id']}")
                print("-" * 60)
            else:
                print(f"❌ Error: Proxy returned {resp.status_code}")
    except Exception as e:
        print(f"❌ Error: Could not connect to proxy. Is it running? ({e})")
        sys.exit(1)

def cmd_test(args):
    config = load_config()
    url = get_proxy_url(config)
    model = args.model or get_default_model(config)
    prompt = args.prompt or "Say 'proxy OK' in exactly 3 words."
    
    print(f"🧪 Sending test message to {url} (model: {model})...")
    payload = {
        "model": model,
        "max_tokens": 64,
        "messages": [{"role": "user", "content": prompt}]
    }
    
    try:
        with httpx.Client() as client:
            resp = client.post(f"{url}/v1/messages", json=payload, timeout=30.0)
            if resp.status_code == 200:
                data = resp.json()
                text = ""
                for block in data.get("content", []):
                    if block.get("type") == "text":
                        text = block["text"]
                        break
                print("\n" + "─"*60)
                print(f"Result: {text}")
                print(f"Status: ✓ 200 OK")
                print(f"Usage: {data.get('usage', {})}")
                print("─"*60 + "\n")
            else:
                print(f"❌ Error {resp.status_code}: {resp.text}")
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

def cmd_init(args):
    print("\n" + "="*60)
    print("🛠️  NVIDIA NIM Proxy Configuration Wizard")
    print("="*60 + "\n")
    
    print("Get a FREE NVIDIA API key at: https://build.nvidia.com")
    api_key = input("\n🔑 Enter your NVIDIA_API_KEY: ").strip()
    if not api_key:
        print("❌ Error: API key is required.")
        return

    port = input("🔌 Proxy port [8787]: ").strip() or "8787"
    
    env_content = f"NVIDIA_API_KEY={api_key}\nPROXY_PORT={port}\n"
    
    # Save to .env
    with open(".env", "w") as f:
        f.write(env_content)
    
    print(f"\n✅ Configuration saved to .env")
    print("\nNext steps:")
    print(f"1. export NVIDIA_API_KEY={api_key[:8]}...")
    print("2. nim code")
    print("\nTip: You can also use a 'config.yaml' for advanced model aliasing.")

def load_env():
    env_path = Path(".env")
    if env_path.exists():
        with env_path.open("r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                os.environ[key.strip()] = val.strip()

def main():
    load_env()
    parser = argparse.ArgumentParser(description="NIM Proxy CLI")
    subparsers = parser.add_subparsers(dest="command")
    
    # nim code
    code_parser = subparsers.add_parser("code", help="Start proxy and Claude Code")
    code_parser.add_argument("--model", help="Override the default NVIDIA model")
    
    # nim proxy
    proxy_parser = subparsers.add_parser("proxy", help="Start proxy only")
    
    # nim status
    status_parser = subparsers.add_parser("status", help="Check proxy status")
    
    # nim models
    models_parser = subparsers.add_parser("models", help="List available NVIDIA models")
    
    # nim test
    test_parser = subparsers.add_parser("test", help="Send a test message to the proxy")
    test_parser.add_argument("prompt", nargs="?", help="Optional test prompt")
    test_parser.add_argument("--model", help="Override the default NVIDIA model")

    # nim init
    init_parser = subparsers.add_parser("init", help="Interactive configuration wizard")
    
    args = parser.parse_args()
    
    if args.command == "code":
        config = load_config()
        proxy_url = get_proxy_url(config)
        model = args.model or get_default_model(config)
        
        if wait_for_proxy(proxy_url, timeout=1.0):
            print(f"📡 Reusing existing NIM Proxy on {proxy_url}")
            run_claude(proxy_url, model)
            return

        print("📡 Starting background NIM Proxy...")
        proxy_proc, log_path = run_proxy()
        
        try:
            if wait_for_proxy(proxy_url):
                run_claude(proxy_url, model)
            else:
                print("❌ Error: Proxy failed to start in time.")
                if os.path.exists(log_path):
                    with open(log_path, 'r') as f:
                        print("".join(f.readlines()[-10:]))
                sys.exit(1)
        finally:
            print("🛑 Shutting down background proxy...")
            proxy_proc.terminate()
            try:
                proxy_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proxy_proc.kill()
            if os.path.exists(log_path):
                try:
                    os.unlink(log_path)
                except Exception:
                    pass
    
    elif args.command == "proxy":
        from proxy import main as proxy_main
        proxy_main()
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "models":
        cmd_models(args)
    elif args.command == "test":
        cmd_test(args)
    elif args.command == "init":
        cmd_init(args)
    elif args.command == "version":
        print("nvd-claude-nim CLI v0.1.2")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
