import pytest
import respx
import httpx
import json
from fastapi.testclient import TestClient
from proxy import app

@pytest.fixture
def client():
    # Ensure NVIDIA_API_KEY is set for lifespan to succeed
    import os
    os.environ["NVIDIA_API_KEY"] = "test-key"
    with TestClient(app) as c:
        yield c

def test_e2e_non_streaming(client, respx_mock):
    # Setup mock
    respx_mock.post("https://integrate.api.nvidia.com/v1/chat/completions").mock(
        return_value=httpx.Response(200, json={
            "id": "chat-123",
            "choices": [{
                "message": {"role": "assistant", "content": "Hello! I am a mock AI."},
                "finish_reason": "stop"
            }],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5}
        })
    )
    
    response = client.post(
        "/v1/messages",
        json={
            "model": "claude-3-5-sonnet-20241022",
            "max_tokens": 100,
            "messages": [{"role": "user", "content": "Hi"}]
        }
    )
    
    assert response.status_code == 200
    data = response.json()
    assert data["type"] == "message"
    assert data["content"][0]["text"] == "Hello! I am a mock AI."
    assert data["model"] == "claude-3-5-sonnet-20241022"

def test_e2e_streaming(client, respx_mock):
    # Setup mock stream
    stream_content = [
        "data: " + json.dumps({"choices": [{"delta": {"role": "assistant", "content": "Hello"}}]}) + "\n\n",
        "data: " + json.dumps({"choices": [{"delta": {"content": " world!"}}]}) + "\n\n",
        "data: " + json.dumps({"choices": [{"finish_reason": "stop"}], "usage": {"prompt_tokens": 5, "completion_tokens": 2}}) + "\n\n",
        "data: [DONE]\n\n"
    ]
    respx_mock.post("https://integrate.api.nvidia.com/v1/chat/completions").mock(
        return_value=httpx.Response(200, content="".join(stream_content))
    )
    
    with client.stream(
        "POST",
        "/v1/messages",
        json={
            "model": "claude-3-5-sonnet-20241022",
            "max_tokens": 100,
            "stream": True,
            "messages": [{"role": "user", "content": "Hi"}]
        }
    ) as response:
        assert response.status_code == 200
        events = []
        for line in response.iter_lines():
            if line.startswith("data: "):
                events.append(json.loads(line[6:]))
        
        assert any(e["type"] == "message_start" for e in events)
        
        # Verify the accumulated text content
        text_deltas = [e["delta"]["text"] for e in events if e["type"] == "content_block_delta" and e["delta"]["type"] == "text_delta"]
        full_text = "".join(text_deltas)
        assert full_text == "Hello world!"
        
        assert any(e["type"] == "message_stop" for e in events)

def test_e2e_error_propagation(client, respx_mock):
    respx_mock.post("https://integrate.api.nvidia.com/v1/chat/completions").mock(
        return_value=httpx.Response(429, json={"detail": "Too many requests"})
    )
    
    response = client.post(
        "/v1/messages",
        json={
            "model": "claude-3-5-sonnet-20241022",
            "max_tokens": 100,
            "messages": [{"role": "user", "content": "Hi"}]
        }
    )
    
    assert response.status_code == 429
    data = response.json()
    assert data["type"] == "error"
    assert data["error"]["type"] == "rate_limit_error"
