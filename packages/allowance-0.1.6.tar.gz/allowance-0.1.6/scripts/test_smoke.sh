#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="${TMP_DIR:-/tmp/allowance-cli-smoke-$RANDOM-$$}"
FAKE_OPENCLAW_DIR="$TMP_DIR/bin"
FAKE_OPENCLAW_STATE="$TMP_DIR/openclaw-state"
SMOKE_HOME="$TMP_DIR/home"
STUB_API_SCRIPT="$TMP_DIR/stub_api.py"

API_HOST="${API_HOST:-127.0.0.1}"
API_PORT="${API_PORT:-$(/usr/bin/python3 - <<'PY'
import socket

sock = socket.socket()
sock.bind(('127.0.0.1', 0))
print(sock.getsockname()[1])
sock.close()
PY
)}"
BASE_URL="${BASE_URL:-http://$API_HOST:$API_PORT}"
MANAGE_API="${MANAGE_API:-1}"
SMOKE_EMAIL="${SMOKE_EMAIL:-allowance-cli-smoke@example.com}"
API_LOG="${API_LOG:-/tmp/allowance-cli-api-smoke.log}"

cleanup() {
  if [[ -n "${API_PID:-}" ]]; then
    kill "$API_PID" >/dev/null 2>&1 || true
    wait "$API_PID" >/dev/null 2>&1 || true
  fi
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

if [[ "$MANAGE_API" == "1" ]]; then
  mkdir -p "$TMP_DIR"
  cat >"$STUB_API_SCRIPT" <<'EOF'
from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import os

HOST = os.environ.get('STUB_API_HOST', '127.0.0.1')
PORT = int(os.environ.get('STUB_API_PORT', '8010'))
JWT_TOKEN = "jwt_smoke_123"
AK_TOKEN = "ak_smoke_1234567890"


class Handler(BaseHTTPRequestHandler):
    def _read_json(self) -> dict[str, object]:
        length = int(self.headers.get('Content-Length', '0'))
        raw = self.rfile.read(length) if length else b'{}'
        return json.loads(raw or b'{}')

    def _write(self, status_code: int, payload: dict[str, object] | None = None) -> None:
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        if payload is not None:
            self.wfile.write(json.dumps(payload).encode())

    def do_GET(self) -> None:  # noqa: N802
        if self.path == '/health':
            self._write(200, {'ok': True})
            return
        if self.path == '/auth/checkout-identity':
            if self.headers.get('Authorization') != f'Bearer {AK_TOKEN}':
                self._write(401, {'detail': 'unauthorized'})
                return
            self._write(
                200,
                {
                    'first_name': 'Smoke',
                    'last_name': 'Tester',
                    'email': 'allowance-cli-smoke@example.com',
                    'phone': '+14155550123',
                },
            )
            return
        if self.path == '/mcp':
            self.send_response(405)
            self.end_headers()
            return
        self._write(404, {'detail': 'not found'})

    def do_POST(self) -> None:  # noqa: N802
        body = self._read_json()
        if self.path == '/auth/send-code':
            self._write(200, {'ok': True, 'dev_code': '654321'})
            return
        if self.path == '/auth/verify':
            self._write(
                200,
                {
                    'token': JWT_TOKEN,
                    'user_id': 'user_smoke',
                    'config': {'mcp_url': f'http://{HOST}:{PORT}/mcp'},
                },
            )
            return
        if self.path == '/connection-tokens':
            if self.headers.get('Authorization') != f'Bearer {JWT_TOKEN}':
                self._write(401, {'detail': 'unauthorized'})
                return
            if body.get('agent') != 'openclaw':
                self._write(422, {'detail': 'unsupported agent'})
                return
            self._write(
                201,
                {
                    'id': 'tok_smoke',
                    'secret_key': AK_TOKEN,
                    'key_prefix': 'ak_smoke_1234',
                },
            )
            return
        if self.path == '/oauth/revoke':
            self._write(200, {'ok': True})
            return
        self._write(404, {'detail': 'not found'})

    def log_message(self, format: str, *args: object) -> None:  # noqa: A003
        return


if __name__ == '__main__':
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
EOF

  (
    cd "$ROOT_DIR"
    : >"$API_LOG"
    STUB_API_HOST="$API_HOST" STUB_API_PORT="$API_PORT" \
      uv run python "$STUB_API_SCRIPT" >"$API_LOG" 2>&1
  ) &
  API_PID=$!

  for i in {1..40}; do
    status="$(curl -s -o /dev/null -w '%{http_code}' "$BASE_URL/health" || true)"
    if [[ "$status" == "200" ]]; then
      break
    fi
    sleep 1
    if [[ "$i" == "40" ]]; then
      echo "ERROR: API failed to start." >&2
      tail -n 80 "$API_LOG" >&2 || true
      exit 1
    fi
  done
fi

cd "$ROOT_DIR"
uv sync --dev

mkdir -p "$FAKE_OPENCLAW_DIR" "$SMOKE_HOME"
cat >"$FAKE_OPENCLAW_DIR/openclaw" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

STATE_DIR="${FAKE_OPENCLAW_STATE:?}"
CONFIG_PATH="$STATE_DIR/allowance.json"

if [[ "${1:-}" != "mcp" ]]; then
  echo "unsupported command" >&2
  exit 1
fi

case "${2:-}" in
  set)
    if [[ "${3:-}" != "allowance" || -z "${4:-}" ]]; then
      echo "usage: openclaw mcp set allowance <json>" >&2
      exit 1
    fi
    mkdir -p "$STATE_DIR"
    printf '%s' "$4" >"$CONFIG_PATH"
    ;;
  show)
    if [[ "${3:-}" != "allowance" || "${4:-}" != "--json" ]]; then
      echo "usage: openclaw mcp show allowance --json" >&2
      exit 1
    fi
    if [[ ! -f "$CONFIG_PATH" ]]; then
      echo "not configured" >&2
      exit 1
    fi
    cat "$CONFIG_PATH"
    ;;
  unset)
    if [[ "${3:-}" != "allowance" ]]; then
      echo "usage: openclaw mcp unset allowance" >&2
      exit 1
    fi
    rm -f "$CONFIG_PATH"
    ;;
  *)
    echo "unsupported subcommand" >&2
    exit 1
    ;;
esac
EOF
chmod +x "$FAKE_OPENCLAW_DIR/openclaw"

allowance_cmd() {
  HOME="$SMOKE_HOME" \
  PATH="$FAKE_OPENCLAW_DIR:$PATH" \
  ALLOWANCE_CONNECTION_TOKEN="ak_smoke_1234567890" \
  FAKE_OPENCLAW_STATE="$FAKE_OPENCLAW_STATE" \
    uv run allowance --api-base-url "$BASE_URL" "$@"
}

echo "==> OpenClaw setup"
SETUP_OUTPUT="$(allowance_cmd setup --for openclaw)"
if ! grep -q 'Configured OpenClaw' <<<"$SETUP_OUTPUT"; then
  echo "ERROR: expected OpenClaw setup confirmation" >&2
  echo "$SETUP_OUTPUT" >&2
  exit 1
fi
if [[ ! -f "$SMOKE_HOME/.openclaw/skills/allowance/SKILL.md" ]]; then
  echo "ERROR: expected OpenClaw skill file to be written" >&2
  exit 1
fi
if grep -q 'ak_smoke' "$SMOKE_HOME/.openclaw/skills/allowance/SKILL.md"; then
  echo "ERROR: OpenClaw skill file must not contain the connection token" >&2
  exit 1
fi

echo "PASS: allowance-cli smoke completed."
