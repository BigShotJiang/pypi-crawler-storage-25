'use strict';

const packageJson = require('../package.json');
const { ensureRuntime } = require('../lib/runtime');

function main() {
  const pypiPackage = process.env.ALLOWANCE_PYPI_PACKAGE || 'allowance';
  ensureRuntime({
    version: packageJson.version,
    pypiPackage,
    skipInstall: false,
  });
}

try {
  main();
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  console.warn(`[allowance] Postinstall bootstrap skipped: ${message}`);
  console.warn('[allowance] The runtime will bootstrap on first command execution.');
}
