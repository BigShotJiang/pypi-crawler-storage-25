---
name: allowance
description: Allowance agent purchase wallet. Use when the user asks to buy something, make a purchase, order an item, or spend money on their behalf.
---

# allowance — Agent Purchase Wallet

Use Allowance to request spending approval from the user and complete purchases on their behalf.

## Setup

```bash
npx @allowance/cli setup
```

Handles OTP login, token minting, and agent skill installation for Claude Desktop, Codex, and OpenClaw.

## Local Browser Requirement

Allowance CLI purchases are local-browser-only.

Before running `allowance request`, verify this current agent session has a tool that can open and control a local browser checkout page.

This means the session can:
- open the merchant website
- navigate pages
- click buttons and links
- type into checkout forms
- read page state enough to complete checkout

This passes if the current session has one of:
- a dedicated browser automation tool
- a computer-use tool that can operate a browser
- a Chrome extension or browser relay controlled by the agent
- another explicit browser-control tool

This does not pass if you only have:
- web search
- HTTP fetch, curl, or static page retrieval
- screenshots without click/type control
- a browser visible to the user but not controllable by you
- browser access from a previous or different session
- uncertainty about whether browser tools are available

If this check does not pass, do not run `allowance request` and do not create an approval request.

Tell the user:

"Allowance is the right payment flow, but this agent session cannot complete local checkout yet. Please switch to or connect a browser-capable agent session, such as Codex with Browser/Computer Use, Claude with Computer Use or a browser-control extension, or OpenClaw with browser enabled. Then I can create the Allowance approval request and complete checkout."

If this check passes, continue.

## Browser Tool Values

Use `--local-browser-tool <value>` only when this current session can control a local browser.

Accepted values:
- `browser-tool`: dedicated browser automation tool, such as Codex Browser or OpenClaw Browser
- `computer-use`: a computer-use tool that can operate a browser, such as Codex Computer Use or Claude Computer Use
- `chrome-extension`: a Chrome extension or browser relay controlled by the agent
- `other-browser-control`: another explicit browser-control tool that can navigate, click, type, and inspect checkout pages

If unsure which value applies, do not create the request.

## Purchase flow

1. **Gather purchase details**

Gather only the minimum required purchase details:
- merchant
- item intent
- high-risk variants like size/color
- all-in spend cap
- shipping requirement

2. **Verify local browser control**

Verify local browser control using the checklist above.

3. **Request approval** (`--amount` is in cents — include estimated tax + shipping)
```bash
allowance request \
  --merchant "Zara" \
  --url "https://www.zara.com/us/" \
  --amount 5000 \
  --reason "buy a black men's medium tee" \
  --local-browser-tool computer-use
```
Blocks until approved or denied (up to 10 min). Prints `allowance_id` on approval.
Add `--no-shipping` for digital goods, services, pickup, or any non-shipped item.

Do not run `allowance request` without `--local-browser-tool`.

4. **After approval, open the merchant site in the local browser and complete checkout**

5. **Issue a virtual card** (only once the merchant payment form is visible and ready)
```bash
allowance card issue --allowance-id <allowance_id> --amount <cents> --merchant "<name>"
```
Returns a one-time card number, expiry, and CVV.
**Never paste, summarize, or reveal card number, CVV, expiry, or last four in chat.**
Type them directly into the merchant checkout form only.

6. **Fetch checkout details only when the merchant form asks for them**
```bash
allowance identity                                          # name, email, phone
allowance address shipping --allowance-id <allowance_id>   # shipping address
allowance address billing  --allowance-id <allowance_id>   # billing address
```

7. **Report the outcome** (required — unreported purchases block future requests)
```bash
allowance purchase success --allowance-id <id> --attempt-id <attempt_id> --charged <cents>
allowance purchase failure --allowance-id <id> --attempt-id <attempt_id> --error-code <code>
```
Valid error codes: `card_declined`, `card_declined_avs`, `card_declined_cvv`,
`checkout_abandoned`, `checkout_error`, `checkout_timeout`, `item_unavailable`,
`merchant_rejected`, `price_mismatch`, `unsupported_card`

If the card is declined: report failure immediately. Do not retry or issue another card
unless the user explicitly asks and a new allowance approval is obtained.
