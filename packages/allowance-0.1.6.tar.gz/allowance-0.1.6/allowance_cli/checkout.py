"""Checkout commands for the Allowance CLI.

These commands implement the full agent checkout flow:
  allowance request   — create & wait for an allowance request
  allowance identity  — fetch contact details
  allowance address   — fetch shipping or billing address
  allowance card      — issue a virtual card
  allowance purchase  — report purchase success or failure
"""
from __future__ import annotations

import json
import time
from typing import Any

import typer

from allowance_cli.api import AllowanceAPIClient, APIError, APITransportError
from allowance_cli.config import (
    APP_BASE_URL,
    CHECKOUT_POLL_INTERVAL_SECONDS,
    CHECKOUT_WAIT_TIMEOUT_SECONDS,
    PURCHASE_AUTH_POLL_INTERVAL_SECONDS,
    PURCHASE_AUTH_WAIT_TIMEOUT_SECONDS,
    load_connection_token,
)

# ---------------------------------------------------------------------------
# Sub-apps
# ---------------------------------------------------------------------------

HELP_OPTION_NAMES = ['-h', '--help', '-help']
COMMON_CONTEXT_SETTINGS = {'help_option_names': HELP_OPTION_NAMES}

request_app = typer.Typer(
    help='Create and wait for an allowance request.',
    context_settings=COMMON_CONTEXT_SETTINGS,
    no_args_is_help=False,
    invoke_without_command=True,
)
address_app = typer.Typer(
    help='Fetch shipping or billing address.',
    context_settings=COMMON_CONTEXT_SETTINGS,
    no_args_is_help=True,
)
card_app = typer.Typer(
    help='Issue a virtual card for a purchase.',
    context_settings=COMMON_CONTEXT_SETTINGS,
    no_args_is_help=True,
)
purchase_app = typer.Typer(
    help='Report a purchase result.',
    context_settings=COMMON_CONTEXT_SETTINGS,
    no_args_is_help=True,
)

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

_TERMINAL_STATUSES: frozenset[str] = frozenset({
    'approved', 'denied', 'canceled', 'expired', 'failed',
})

_FAILURE_ERROR_CODES: frozenset[str] = frozenset({
    'card_declined', 'card_declined_avs', 'card_declined_cvv',
    'checkout_abandoned', 'checkout_error', 'checkout_timeout',
    'item_unavailable', 'price_mismatch', 'merchant_rejected', 'unsupported_card',
})

_LOCAL_BROWSER_TOOL_OPTIONS = (
    'browser-tool',
    'computer-use',
    'chrome-extension',
    'other-browser-control',
)
_LOCAL_BROWSER_TOOL_VALUES: frozenset[str] = frozenset(_LOCAL_BROWSER_TOOL_OPTIONS)
_LOCAL_BROWSER_TOOL_LIST = ', '.join(_LOCAL_BROWSER_TOOL_OPTIONS)


def _require_token() -> str:
    """Load the connection token or exit with a clear error."""
    token = load_connection_token()
    if not token:
        typer.echo(
            'Error: No connection token found. Run `allowance setup` to configure your agent, '
            'or set the ALLOWANCE_CONNECTION_TOKEN environment variable.',
            err=True,
        )
        raise typer.Exit(code=1)
    return token


def _require_local_browser_tool(local_browser_tool: str | None, *, as_json: bool) -> str:
    value = (local_browser_tool or '').strip()
    if not value:
        message = (
            'Allowance CLI purchases require active local browser control.\n\n'
            'Before creating an approval request, verify this agent session can open and '
            'control a merchant checkout page: navigate, click, type, and read page state.\n\n'
            'Use one of:\n'
            '  --local-browser-tool browser-tool\n'
            '  --local-browser-tool computer-use\n'
            '  --local-browser-tool chrome-extension\n'
            '  --local-browser-tool other-browser-control\n\n'
            'If this session does not have browser control, ask the user to switch to or '
            'connect a browser-capable agent session, then try again.'
        )
        if as_json:
            typer.echo(
                json.dumps(
                    {
                        'ok': False,
                        'error': 'local_browser_tool_required',
                        'message': message,
                        'valid_values': list(_LOCAL_BROWSER_TOOL_OPTIONS),
                    },
                    separators=(',', ':'),
                    sort_keys=True,
                ),
                err=True,
            )
        else:
            typer.echo(message, err=True)
        raise typer.Exit(code=1)
    if value not in _LOCAL_BROWSER_TOOL_VALUES:
        message = (
            f'Invalid --local-browser-tool value: {value}\n\n'
            f'Valid values are: {_LOCAL_BROWSER_TOOL_LIST}.\n'
            'Use this only when the current agent session can control a local browser.'
        )
        if as_json:
            typer.echo(
                json.dumps(
                    {
                        'ok': False,
                        'error': 'invalid_local_browser_tool',
                        'message': message,
                        'valid_values': list(_LOCAL_BROWSER_TOOL_OPTIONS),
                    },
                    separators=(',', ':'),
                    sort_keys=True,
                ),
                err=True,
            )
        else:
            typer.echo(message, err=True)
        raise typer.Exit(code=1)
    return value


def _build_checkout_client(*, base_url: str, token: str) -> AllowanceAPIClient:
    return AllowanceAPIClient(base_url=base_url, bearer_token=token)


def _emit(data: Any, *, as_json: bool, pretty: bool = False) -> None:
    """Print data either as formatted human-readable text or JSON."""
    if as_json:
        if pretty:
            typer.echo(json.dumps(data, indent=2, sort_keys=True))
        else:
            typer.echo(json.dumps(data, separators=(',', ':'), sort_keys=True))
    else:
        typer.echo(data)


def _handle_api_error(exc: APIError, *, as_json: bool) -> None:
    msg = f'API error {exc.status_code}: {exc.body}'
    if as_json:
        # Always write to stderr in --json mode so stdout remains a single JSON object.
        typer.echo(
            json.dumps({'ok': False, 'status_code': exc.status_code, 'error': exc.body},
                       separators=(',', ':'), sort_keys=True),
            err=True,
        )
    else:
        typer.echo(f'Error: {msg}', err=True)
    raise typer.Exit(code=1)


def _handle_transport_error(exc: APITransportError, *, as_json: bool) -> None:
    msg = str(exc)
    if as_json:
        # Always write to stderr in --json mode so stdout remains a single JSON object.
        typer.echo(
            json.dumps({'ok': False, 'error': 'network_error', 'message': msg},
                       separators=(',', ':'), sort_keys=True),
            err=True,
        )
    else:
        typer.echo(f'Network error: {msg}', err=True)
    raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# allowance request
# ---------------------------------------------------------------------------

@request_app.callback(invoke_without_command=True)
def request_create(
    ctx: typer.Context,
    merchant: str = typer.Option(..., '--merchant', help='Merchant name.'),
    amount: int = typer.Option(..., '--amount', help='Amount in cents.'),
    reason: str = typer.Option(..., '--reason', help='Reason for the purchase.'),
    url: str | None = typer.Option(None, '--url', help='Merchant URL (optional).'),
    local_browser_tool: str | None = typer.Option(
        None,
        '--local-browser-tool',
        help=(
            'Required for CLI purchases. One of: browser-tool, computer-use, '
            'chrome-extension, other-browser-control.'
        ),
    ),
    no_shipping: bool = typer.Option(False, '--no-shipping', help='No shipping required.'),
    as_json: bool = typer.Option(False, '--json', help='Output as JSON.'),
    api_base_url: str | None = typer.Option(
        None, '--api-base-url', envvar='ALLOWANCE_API_BASE_URL',
        help='Override API base URL.',
    ),
) -> None:
    """Create an allowance request and wait for approval."""
    # Only run when invoked directly (not as a parent for sub-commands).
    if ctx.invoked_subcommand is not None:
        return

    local_browser_tool_value = _require_local_browser_tool(
        local_browser_tool,
        as_json=as_json,
    )
    token = _require_token()
    base_url = (api_base_url.rstrip('/') if api_base_url else None) or _default_api_base_url()
    client = _build_checkout_client(base_url=base_url, token=token)

    payload: dict[str, Any] = {
        'cents': amount,
        'currency': 'USD',
        'merchant': merchant,
        'reason': reason,
        'requires_shipping': not no_shipping,
        'checkout_execution': 'local_browser',
        'local_browser_available': True,
        'local_browser_tool': local_browser_tool_value,
    }
    if url:
        payload['merchant_url'] = url

    try:
        create_body = client.post('/allowance-requests', json_body=payload)
    except APIError as exc:
        _handle_api_error(exc, as_json=as_json)
    except APITransportError as exc:
        _handle_transport_error(exc, as_json=as_json)

    request_id = create_body.get('id') if isinstance(create_body, dict) else None
    if not isinstance(request_id, str):
        if as_json:
            typer.echo(json.dumps({'ok': False, 'error': 'missing request id', 'body': create_body},
                                  separators=(',', ':'), sort_keys=True))
        else:
            typer.echo('Error: API response missing request id.', err=True)
        raise typer.Exit(code=1)

    # Immediately print the approval link.
    approval_link = f'{APP_BASE_URL}/allowance-requests/{request_id}'
    if not as_json:
        typer.echo(f'Approval link: {approval_link}')
        typer.echo('Waiting for approval...')
    else:
        # In --json mode, send the intermediate "created" info to stderr so
        # stdout remains a single parseable JSON object for the final result.
        typer.echo(
            json.dumps({'ok': True, 'phase': 'created',
                        'request_id': request_id,
                        'approval_link': approval_link},
                       separators=(',', ':'), sort_keys=True),
            err=True,
        )

    # Poll until terminal state or timeout.
    deadline = time.monotonic() + CHECKOUT_WAIT_TIMEOUT_SECONDS
    last_result: dict[str, Any] | None = None

    while True:
        try:
            poll_body = client.get(f'/allowance-requests/{request_id}/poll')
        except APIError as exc:
            _handle_api_error(exc, as_json=as_json)
        except APITransportError as exc:
            _handle_transport_error(exc, as_json=as_json)

        status = poll_body.get('status') if isinstance(poll_body, dict) else None
        last_result = poll_body if isinstance(poll_body, dict) else last_result

        if isinstance(status, str) and status in _TERMINAL_STATUSES:
            break

        now = time.monotonic()
        if now >= deadline:
            if as_json:
                typer.echo(json.dumps({
                    'ok': False, 'phase': 'timed_out', 'request_id': request_id,
                    'approval_link': approval_link,
                    'message': 'Timed out waiting for approval. Re-run to wait again.',
                }, separators=(',', ':'), sort_keys=True))
            else:
                typer.echo(
                    f'\nTimed out after {int(CHECKOUT_WAIT_TIMEOUT_SECONDS)}s waiting for approval.'
                    f'\nApproval link: {approval_link}'
                    f'\nRe-run this command to wait again.',
                    err=True,
                )
            raise typer.Exit(code=1)

        sleep_secs = min(CHECKOUT_POLL_INTERVAL_SECONDS, max(0.0, deadline - time.monotonic()))
        if sleep_secs > 0:
            time.sleep(sleep_secs)

    # Terminal state reached.
    if last_result is None:
        typer.echo("Error: unexpected response from server during polling.", err=True)
        raise typer.Exit(code=1)
    allowance_id = last_result.get('allowance_id') if isinstance(last_result, dict) else None

    if status == 'approved':
        aid = allowance_id or '<allowance_id>'
        # Format amount as dollars for display (amount is in cents).
        dollars = f'${amount / 100:,.2f}'
        # Print next-step hints to stderr first so that in --json mode the JSON
        # line is the last line written to stdout (keeps stdout parseable).
        typer.echo(
            f'\n✓ Approved — {dollars} at {merchant} (allowance_id: {aid})\n',
            err=True,
        )
        typer.echo('Next steps:', err=True)
        typer.echo(
            f'  Issue a card:    allowance card issue --allowance-id {aid}'
            f' --amount {amount} --merchant "{merchant}"',
            err=True,
        )
        typer.echo('When the checkout form asks for:', err=True)
        typer.echo('  Contact info:    allowance identity', err=True)
        requires_shipping = (
            last_result.get('requires_shipping', True) if isinstance(last_result, dict) else True
        )
        if requires_shipping:
            typer.echo(
                f'  Shipping addr:   allowance address shipping --allowance-id {aid}', err=True
            )
        typer.echo(
            f'  Billing addr:    allowance address billing --allowance-id {aid}', err=True
        )
        typer.echo(
            f'  Report success:  allowance purchase success --allowance-id {aid}'
            f' --attempt-id <attempt-id> --charged <cents>',
            err=True,
        )
        typer.echo(
            f'  Report failure:  allowance purchase failure --allowance-id {aid}'
            f' --attempt-id <attempt-id> --error-code <error-code>',
            err=True,
        )
        if as_json:
            # Emit the machine-readable result to stdout after all stderr hints.
            typer.echo(json.dumps({
                'ok': True, 'phase': 'approved', 'status': 'approved',
                'request_id': request_id, 'allowance_id': allowance_id,
            }, separators=(',', ':'), sort_keys=True))
    else:
        if as_json:
            typer.echo(json.dumps({
                'ok': False, 'phase': 'terminal', 'status': status,
                'request_id': request_id, 'allowance_id': allowance_id,
            }, separators=(',', ':'), sort_keys=True))
        else:
            typer.echo(f'\nRequest {status}. No card will be issued.', err=True)
        raise typer.Exit(code=1)


def _default_api_base_url() -> str:
    from allowance_cli.config import DEFAULT_API_BASE_URL
    return DEFAULT_API_BASE_URL


# ---------------------------------------------------------------------------
# allowance identity
# ---------------------------------------------------------------------------

def identity_command(
    as_json: bool = typer.Option(False, '--json', help='Output as JSON.'),
    api_base_url: str | None = typer.Option(
        None, '--api-base-url', envvar='ALLOWANCE_API_BASE_URL',
        help='Override API base URL.',
    ),
) -> None:
    """Fetch contact details (name, email, phone) for the current user."""
    token = _require_token()
    base_url = (api_base_url.rstrip('/') if api_base_url else None) or _default_api_base_url()
    client = _build_checkout_client(base_url=base_url, token=token)

    try:
        body = client.get('/auth/checkout-identity')
    except APIError as exc:
        _handle_api_error(exc, as_json=as_json)
    except APITransportError as exc:
        _handle_transport_error(exc, as_json=as_json)

    if as_json:
        typer.echo(json.dumps(body, separators=(',', ':'), sort_keys=True))
    else:
        if isinstance(body, dict):
            typer.echo(f"First name:  {body.get('first_name', '')}")
            typer.echo(f"Last name:   {body.get('last_name', '')}")
            typer.echo(f"Email:       {body.get('email', '')}")
            typer.echo(f"Phone:       {body.get('phone', '')}")
        else:
            typer.echo(str(body))


# ---------------------------------------------------------------------------
# allowance address shipping / billing
# ---------------------------------------------------------------------------

def _print_address(body: Any) -> None:
    if not isinstance(body, dict):
        typer.echo(str(body))
        return
    for field in ('name', 'line1', 'line2', 'city', 'state', 'postal_code', 'country'):
        value = body.get(field)
        if value:
            typer.echo(f'{field.replace("_", " ").title():14}{value}')


@address_app.command('shipping')
def address_shipping(
    allowance_id: str = typer.Option(..., '--allowance-id', help='Allowance ID.'),
    as_json: bool = typer.Option(False, '--json', help='Output as JSON.'),
    api_base_url: str | None = typer.Option(
        None, '--api-base-url', envvar='ALLOWANCE_API_BASE_URL',
        help='Override API base URL.',
    ),
) -> None:
    """Fetch the shipping address for an allowance."""
    token = _require_token()
    base_url = (api_base_url.rstrip('/') if api_base_url else None) or _default_api_base_url()
    client = _build_checkout_client(base_url=base_url, token=token)

    try:
        body = client.get(f'/allowances/{allowance_id}/shipping-address')
    except APIError as exc:
        _handle_api_error(exc, as_json=as_json)
    except APITransportError as exc:
        _handle_transport_error(exc, as_json=as_json)

    if as_json:
        typer.echo(json.dumps(body, separators=(',', ':'), sort_keys=True))
    else:
        typer.echo('Shipping address:')
        _print_address(body)


@address_app.command('billing')
def address_billing(
    allowance_id: str = typer.Option(..., '--allowance-id', help='Allowance ID.'),
    as_json: bool = typer.Option(False, '--json', help='Output as JSON.'),
    api_base_url: str | None = typer.Option(
        None, '--api-base-url', envvar='ALLOWANCE_API_BASE_URL',
        help='Override API base URL.',
    ),
) -> None:
    """Fetch the billing address for an allowance."""
    token = _require_token()
    base_url = (api_base_url.rstrip('/') if api_base_url else None) or _default_api_base_url()
    client = _build_checkout_client(base_url=base_url, token=token)

    try:
        body = client.get(f'/allowances/{allowance_id}/billing-address')
    except APIError as exc:
        _handle_api_error(exc, as_json=as_json)
    except APITransportError as exc:
        _handle_transport_error(exc, as_json=as_json)

    if as_json:
        typer.echo(json.dumps(body, separators=(',', ':'), sort_keys=True))
    else:
        typer.echo('Billing address:')
        _print_address(body)


# ---------------------------------------------------------------------------
# allowance card issue
# ---------------------------------------------------------------------------

def _poll_purchase_auth(
    client: AllowanceAPIClient,
    *,
    allowance_id: str,
    attempt_id: str,
    as_json: bool,
) -> dict[str, Any]:
    """Poll complete-auth until success/failure or timeout. Returns the final body."""
    deadline = time.monotonic() + PURCHASE_AUTH_WAIT_TIMEOUT_SECONDS
    if not as_json:
        typer.echo('Waiting for phone authorization... check your phone')

    while True:
        try:
            body = client.post(
                f'/allowances/{allowance_id}/purchase-attempts/{attempt_id}/complete-auth'
            )
        except APIError as exc:
            _handle_api_error(exc, as_json=as_json)
        except APITransportError as exc:
            _handle_transport_error(exc, as_json=as_json)

        status = body.get('status') if isinstance(body, dict) else None
        if status != 'pending_auth':
            return body  # type: ignore[no-any-return]

        now = time.monotonic()
        if now >= deadline:
            if as_json:
                typer.echo(json.dumps({'ok': False, 'error': 'timed_out_waiting_for_phone_auth'},
                                      separators=(',', ':'), sort_keys=True))
            else:
                typer.echo('Error: Timed out waiting for phone authorization.', err=True)
            raise typer.Exit(code=1)

        sleep_secs = min(PURCHASE_AUTH_POLL_INTERVAL_SECONDS, max(0.0, deadline - time.monotonic()))
        if sleep_secs > 0:
            time.sleep(sleep_secs)


@card_app.command('issue')
def card_issue(
    allowance_id: str = typer.Option(..., '--allowance-id', help='Allowance ID.'),
    amount: int = typer.Option(..., '--amount', help='Expected amount in cents.'),
    merchant: str = typer.Option(..., '--merchant', help='Checkout merchant name.'),
    checkout_url: str | None = typer.Option(None, '--url', help='Checkout URL (optional).'),
    as_json: bool = typer.Option(False, '--json', help='Output as JSON.'),
    api_base_url: str | None = typer.Option(
        None, '--api-base-url', envvar='ALLOWANCE_API_BASE_URL',
        help='Override API base URL.',
    ),
) -> None:
    """Issue a virtual card for checkout."""
    token = _require_token()
    base_url = (api_base_url.rstrip('/') if api_base_url else None) or _default_api_base_url()
    client = _build_checkout_client(base_url=base_url, token=token)

    issue_payload: dict[str, Any] = {
        'expected_cents': amount,
        'checkout_merchant': merchant,
    }
    if checkout_url:
        issue_payload['checkout_url'] = checkout_url

    try:
        body = client.post(
            f'/allowances/{allowance_id}/purchase-attempts/issue-card',
            json_body=issue_payload,
        )
    except APIError as exc:
        _handle_api_error(exc, as_json=as_json)
    except APITransportError as exc:
        _handle_transport_error(exc, as_json=as_json)

    # Pending phone auth — poll until resolved.
    if isinstance(body, dict) and body.get('status') == 'pending_auth':
        attempt_id = body.get('id') or body.get('attempt_id')
        if not isinstance(attempt_id, str):
            if as_json:
                typer.echo(json.dumps(
                    {
                        'ok': False,
                        'error': 'missing attempt_id in pending_auth response',
                        'body': body,
                    },
                    separators=(',', ':'), sort_keys=True,
                ))
            else:
                typer.echo('Error: Missing attempt_id in pending_auth response.', err=True)
            raise typer.Exit(code=1)

        body = _poll_purchase_auth(
            client, allowance_id=allowance_id, attempt_id=attempt_id, as_json=as_json
        )

    # Extract card details.
    card = body.get('card') if isinstance(body, dict) else None
    attempt_id = (body.get('id') or body.get('attempt_id')) if isinstance(body, dict) else None

    if as_json:
        typer.echo(json.dumps(body, separators=(',', ':'), sort_keys=True))
        return

    if not isinstance(card, dict):
        typer.echo('Error: No card details in response.', err=True)
        typer.echo(str(body), err=True)
        raise typer.Exit(code=1)

    number = card.get('number', '')
    expiry = card.get('expiry') or f"{card.get('exp_month', '')}/{card.get('exp_year', '')}"
    cvv = card.get('cvv') or card.get('cvc') or card.get('security_code', '')

    # Format card number with spaces for readability.
    formatted_number = ' '.join(number[i:i+4] for i in range(0, len(number), 4)) if number else ''

    typer.echo('')
    typer.echo(
        '⚠  SENSITIVE — Never paste, summarize, or reveal card number, CVV, expiry,'
        ' or last four in chat. Type them directly into the merchant checkout form only.'
    )
    typer.echo('')
    typer.echo(f'Card number: {formatted_number}')
    typer.echo(f'Expiry: {expiry}')
    typer.echo(f'CVV: {cvv}')
    typer.echo('')
    typer.echo(f'Attempt ID: {attempt_id}  ← you\'ll need this to report the result')

    typer.echo(
        '\nNext: report the outcome when done'
        ' (required — unreported purchases block future requests)',
        err=True,
    )
    typer.echo(
        f'  allowance purchase success --allowance-id {allowance_id}'
        f' --attempt-id {attempt_id} --charged <cents>',
        err=True,
    )
    typer.echo(
        f'  allowance purchase failure --allowance-id {allowance_id}'
        f' --attempt-id {attempt_id} --error-code <error-code>',
        err=True,
    )


# ---------------------------------------------------------------------------
# allowance purchase success / failure
# ---------------------------------------------------------------------------

@purchase_app.command('success')
def purchase_success(
    allowance_id: str = typer.Option(..., '--allowance-id', help='Allowance ID.'),
    attempt_id: str = typer.Option(..., '--attempt-id', help='Purchase attempt ID.'),
    charged: int = typer.Option(..., '--charged', help='Actual charged amount in cents.'),
    as_json: bool = typer.Option(False, '--json', help='Output as JSON.'),
    api_base_url: str | None = typer.Option(
        None, '--api-base-url', envvar='ALLOWANCE_API_BASE_URL',
        help='Override API base URL.',
    ),
) -> None:
    """Report a successful purchase."""
    token = _require_token()
    base_url = (api_base_url.rstrip('/') if api_base_url else None) or _default_api_base_url()
    client = _build_checkout_client(base_url=base_url, token=token)

    try:
        body = client.post(
            f'/allowances/{allowance_id}/purchase-attempts/{attempt_id}/result',
            json_body={'status': 'success', 'charged_cents': charged},
        )
    except APIError as exc:
        _handle_api_error(exc, as_json=as_json)
    except APITransportError as exc:
        _handle_transport_error(exc, as_json=as_json)

    if as_json:
        typer.echo(json.dumps(body, separators=(',', ':'), sort_keys=True))
    else:
        typer.echo(f'✓ Purchase reported as successful (charged: ${charged / 100:,.2f})')


@purchase_app.command('failure')
def purchase_failure(
    allowance_id: str = typer.Option(..., '--allowance-id', help='Allowance ID.'),
    attempt_id: str = typer.Option(..., '--attempt-id', help='Purchase attempt ID.'),
    error_code: str = typer.Option(
        ...,
        '--error-code',
        help=(
            'Failure reason. Valid codes: '
            + ', '.join(sorted(_FAILURE_ERROR_CODES))
        ),
    ),
    as_json: bool = typer.Option(False, '--json', help='Output as JSON.'),
    api_base_url: str | None = typer.Option(
        None, '--api-base-url', envvar='ALLOWANCE_API_BASE_URL',
        help='Override API base URL.',
    ),
) -> None:
    """Report a failed purchase."""
    if error_code not in _FAILURE_ERROR_CODES:
        valid = ', '.join(sorted(_FAILURE_ERROR_CODES))
        if as_json:
            typer.echo(json.dumps({'ok': False, 'error': f'invalid error_code; valid: {valid}'},
                                  separators=(',', ':'), sort_keys=True))
        else:
            typer.echo(f'Error: Invalid error code {error_code!r}.\nValid codes: {valid}', err=True)
        raise typer.Exit(code=1)

    token = _require_token()
    base_url = (api_base_url.rstrip('/') if api_base_url else None) or _default_api_base_url()
    client = _build_checkout_client(base_url=base_url, token=token)

    try:
        body = client.post(
            f'/allowances/{allowance_id}/purchase-attempts/{attempt_id}/result',
            json_body={'status': 'failed', 'error_code': error_code},
        )
    except APIError as exc:
        _handle_api_error(exc, as_json=as_json)
    except APITransportError as exc:
        _handle_transport_error(exc, as_json=as_json)

    if as_json:
        typer.echo(json.dumps(body, separators=(',', ':'), sort_keys=True))
    else:
        typer.echo(f'✓ Purchase reported as failed (error_code: {error_code})')
