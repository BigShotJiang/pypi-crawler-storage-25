from __future__ import annotations

import json
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as package_version
from typing import Any

import typer

from allowance_cli.checkout import (
    address_app,
    card_app,
    identity_command,
    purchase_app,
    request_app,
)
from allowance_cli.setup_cmd import run_setup

HELP_OPTION_NAMES = ['-h', '--help', '-help']
COMMON_CONTEXT_SETTINGS = {'help_option_names': HELP_OPTION_NAMES}

app = typer.Typer(
    help='Allowance CLI — agent purchase wallet.',
    context_settings=COMMON_CONTEXT_SETTINGS,
    no_args_is_help=True,
)
app.add_typer(request_app, name='request')
app.add_typer(address_app, name='address')
app.add_typer(card_app, name='card')
app.add_typer(purchase_app, name='purchase')
app.command('identity')(identity_command)


@dataclass
class RuntimeContext:
    pretty: bool
    api_base_url_override: str | None


def _cli_version() -> str:
    try:
        return package_version('allowance')
    except PackageNotFoundError:
        return 'dev'


def _version_callback(value: bool) -> None:
    if not value:
        return
    typer.echo(f'allowance {_cli_version()}')
    raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    pretty: bool = typer.Option(False, '--pretty', help='Pretty-print JSON output.'),
    version: bool = typer.Option(
        False,
        '-v',
        '--version',
        callback=_version_callback,
        is_eager=True,
        help='Show CLI version and exit.',
    ),
    api_base_url: str | None = typer.Option(
        None,
        '--api-base-url',
        envvar='ALLOWANCE_API_BASE_URL',
        help='Override Allowance API base URL for this invocation.',
    ),
) -> None:
    del version
    ctx.obj = RuntimeContext(
        pretty=pretty,
        api_base_url_override=api_base_url.rstrip('/') if api_base_url else None,
    )


def _runtime(ctx: typer.Context) -> RuntimeContext:
    runtime = ctx.obj
    if not isinstance(runtime, RuntimeContext):
        raise RuntimeError('runtime context is missing')
    return runtime


def _emit_json(*, runtime: RuntimeContext, payload: Any) -> None:
    if runtime.pretty:
        typer.echo(json.dumps(payload, indent=2, sort_keys=True))
    else:
        typer.echo(json.dumps(payload, separators=(',', ':'), sort_keys=True))


@app.command('setup')
def setup(
    ctx: typer.Context,
    for_agent: str | None = typer.Option(
        None,
        '--for',
        help=(
            'Agent to configure: claude-code, codex, openclaw, generic. '
            'Auto-detected when not provided.'
        ),
    ),
) -> None:
    """Authenticate and configure Allowance for your agent (universal setup)."""
    runtime = _runtime(ctx)
    run_setup(
        api_base_url=runtime.api_base_url_override,
        for_agent=for_agent,
    )
