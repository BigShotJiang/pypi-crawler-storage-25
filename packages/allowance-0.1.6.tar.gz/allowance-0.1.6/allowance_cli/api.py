from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from allowance_cli.config import HTTP_TIMEOUT_SECONDS


@dataclass
class APIError(Exception):
    status_code: int
    body: Any


class APITransportError(Exception):
    pass


class AllowanceAPIClient:
    def __init__(
        self,
        *,
        base_url: str,
        bearer_token: str | None = None,
        timeout: float = HTTP_TIMEOUT_SECONDS,
    ) -> None:
        self.base_url = base_url.rstrip('/')
        self.bearer_token = bearer_token
        self.timeout = timeout

    def get(self, path: str, *, bearer_token: str | None = None) -> Any:
        return self._request('GET', path, bearer_token=bearer_token)

    def post(
        self,
        path: str,
        *,
        json_body: dict[str, object] | None = None,
        bearer_token: str | None = None,
    ) -> Any:
        return self._request('POST', path, json_body=json_body, bearer_token=bearer_token)

    def patch(
        self,
        path: str,
        *,
        json_body: dict[str, object] | None = None,
        bearer_token: str | None = None,
    ) -> Any:
        return self._request('PATCH', path, json_body=json_body, bearer_token=bearer_token)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, object] | None = None,
        bearer_token: str | None = None,
    ) -> Any:
        token = bearer_token if bearer_token is not None else self.bearer_token
        headers: dict[str, str] = {}
        if token:
            headers['Authorization'] = f'Bearer {token}'

        url = f'{self.base_url}{path}'
        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.request(method, url, headers=headers, json=json_body)
        except httpx.HTTPError as exc:
            raise APITransportError(str(exc)) from exc

        try:
            parsed: Any = response.json()
        except ValueError:
            parsed = {'raw': response.text}

        if response.status_code < 200 or response.status_code >= 300:
            raise APIError(status_code=response.status_code, body=parsed)

        return parsed
