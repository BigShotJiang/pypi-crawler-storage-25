from __future__ import annotations

from typing import Any

SERVICE_NAME = 'Allowance CLI'
ACCOUNT_PREFIX = 'connection-token:'


class CredentialStoreError(RuntimeError):
    """Raised when OS credential storage is unavailable or rejects an operation."""


def _account_name(token_id: str) -> str:
    return f'{ACCOUNT_PREFIX}{token_id}'


def _keyring() -> Any:
    try:
        import keyring
    except Exception as exc:  # pragma: no cover - depends on local install state
        raise CredentialStoreError('OS credential storage is unavailable.') from exc
    return keyring


def store_connection_token(*, token_id: str, token: str) -> None:
    """Store a connection token in the platform credential store."""
    normalized_token_id = token_id.strip()
    normalized_token = token.strip()
    if not normalized_token_id:
        raise CredentialStoreError('Cannot store connection token without token_id.')
    if not normalized_token:
        raise CredentialStoreError('Cannot store empty connection token.')
    account_name = _account_name(normalized_token_id)
    try:
        keyring = _keyring()
        keyring.set_password(SERVICE_NAME, account_name, normalized_token)
        stored_token = keyring.get_password(SERVICE_NAME, account_name)
    except Exception as exc:
        raise CredentialStoreError(
            f'Could not write connection token to OS credential storage: {exc}'
        ) from exc
    if stored_token != normalized_token:
        raise CredentialStoreError('OS credential storage did not persist the connection token.')


def load_stored_connection_token(*, token_id: str) -> str | None:
    """Load a connection token from the platform credential store."""
    if not token_id.strip():
        return None
    try:
        token = _keyring().get_password(SERVICE_NAME, _account_name(token_id.strip()))
    except Exception as exc:
        raise CredentialStoreError(
            f'Could not read connection token from OS credential storage: {exc}'
        ) from exc
    return token.strip() if isinstance(token, str) and token.strip() else None
