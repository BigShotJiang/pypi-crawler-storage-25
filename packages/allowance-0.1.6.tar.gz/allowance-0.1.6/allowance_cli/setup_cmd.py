"""Universal `allowance setup` command (PROD-35/36/37/47)."""

from __future__ import annotations

import json
import os
import pathlib
import re  # noqa: E402
import shutil
import socket
from typing import Any

import typer

from allowance_cli.api import AllowanceAPIClient, APIError, APITransportError
from allowance_cli.config import (
    DEFAULT_API_BASE_URL,
    HTTP_TIMEOUT_SECONDS,
    load_connection_token,
    save_connection_config,
)
from allowance_cli.credential_store import CredentialStoreError

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_CONFIG_DIR = pathlib.Path.home() / '.allowance'
_CONFIG_FILE = _CONFIG_DIR / 'config.json'

# Global instruction file paths (one per supported agent)
_CLAUDE_CODE_SKILL = pathlib.Path.home() / '.claude' / 'skills' / 'allowance' / 'SKILL.md'
_CODEX_AGENTS_MD = pathlib.Path.home() / '.codex' / 'AGENTS.md'
_CODEX_SKILL = pathlib.Path.home() / '.agents' / 'skills' / 'allowance' / 'SKILL.md'
_OPENCLAW_SKILL = pathlib.Path.home() / '.openclaw' / 'skills' / 'allowance' / 'SKILL.md'

SKILL_TEXT = """\
Allowance is ready.

When your agent needs to make a purchase, you'll get a push notification on your
iPhone to approve it.

Purchase flow:

  1. Verify this agent session can control a local browser checkout page.

  2. Request approval  (--amount is in cents; include tax + shipping estimate)
       allowance request --merchant "Amazon" --amount 2500 \
         --reason "buy a Python book" --local-browser-tool computer-use
     Blocks until approved or denied (up to 10 min). Prints the allowance_id on approval.
     Use --no-shipping for digital goods, services, pickup, or any non-shipped item.

  3. Issue a virtual card  (only once the merchant payment form is visible and ready)
       allowance card issue --allowance-id <allowance_id> --amount <cents> --merchant "<name>"
     Returns a one-time card number, expiry, and CVV.
     NEVER paste, summarize, or reveal card number, CVV, or expiry in chat.
     Type them directly into the merchant checkout form only.

  4. Complete checkout using the local browser. For form fields:
       Contact details:  allowance identity
       Shipping address: allowance address shipping --allowance-id <allowance_id>
       Billing address:  allowance address billing --allowance-id <allowance_id>

  5. Report the outcome (required — closes the transaction)
       Success: allowance purchase success --allowance-id <allowance_id>
                --attempt-id <attempt_id> --charged <cents>
       Failure: allowance purchase failure --allowance-id <allowance_id>
                --attempt-id <attempt_id> --error-code <error_code>
         Valid error codes: card_declined, card_declined_avs, card_declined_cvv,
           checkout_abandoned, checkout_error, checkout_timeout, item_unavailable,
           merchant_rejected, price_mismatch, unsupported_card
     If the card is declined: report failure immediately with the appropriate error code.
     Do not retry or issue another card unless the user explicitly asks and a new
     allowance approval is obtained.

Run 'allowance --help' for full usage.\
"""

_CLAUDE_MD_BLOCK = """\

## Allowance — Agent Purchase Wallet

Use Allowance to request spending approval from the user and complete purchases on their behalf.

### Local browser requirement

Allowance CLI purchases require this agent session to control a local browser.
If browser control is unavailable, ask the user to switch to or connect a browser-capable
session rather than abandoning Allowance.

### Purchase flow

1. **Request approval** (`--amount` is in cents — include estimated tax + shipping)
   ```
   allowance request --merchant "Amazon" --amount 2500 \
     --reason "buy a Python book" --local-browser-tool computer-use
   ```
   Sends a push notification to the user's phone. Blocks until approved or denied (up to 10 min).
   On approval, prints the `allowance_id` you'll need for subsequent commands.
   Add `--no-shipping` for digital goods, services, pickup, or any non-shipped item.

2. **Issue a virtual card** (only once the merchant payment form is visible and ready)
   ```
   allowance card issue --allowance-id <allowance_id> --amount <cents> --merchant "<name>"
   ```
   Returns a one-time virtual card number, expiry, and CVV — it expires after the purchase.
   **Never paste, summarize, or reveal card number, CVV, expiry, or last four in chat.**
   Type them directly into the merchant checkout form only.

3. **Complete checkout** using the card. For form fields:
   - Contact details: `allowance identity`
   - Shipping address: `allowance address shipping --allowance-id <allowance_id>`
   - Billing address:  `allowance address billing --allowance-id <allowance_id>`

4. **Report the outcome** (required — closes the transaction)
   - Success: `allowance purchase success --allowance-id <allowance_id>
     --attempt-id <attempt_id> --charged <cents>`
   - Failure: `allowance purchase failure --allowance-id <allowance_id>
     --attempt-id <attempt_id> --error-code <error_code>`
     Valid error codes: `card_declined`, `card_declined_avs`, `card_declined_cvv`,
     `checkout_abandoned`, `checkout_error`, `checkout_timeout`, `item_unavailable`,
     `price_mismatch`, `merchant_rejected`, `unsupported_card`
   - If the card is declined: report failure immediately with the appropriate error code.
     Do not retry or issue another card unless the user explicitly asks and a new
     allowance approval is obtained.

### Notes
- The user approves from their iPhone — make sure they have the Allowance app installed
- The virtual card is single-use and tied to the approved amount
- Always report success or failure — unreported purchases block future requests
"""

# Claude Code skill file content — written to ~/.claude/skills/allowance/SKILL.md
_CLAUDE_CODE_SKILL_CONTENT = """\
---
description: Allowance agent purchase wallet. Use when the user asks to buy something,
  make a purchase, order an item, or spend money on their behalf.
when_to_use: Use whenever a purchase needs to be made or the user wants to buy something.
  Provides the full CLI-based checkout flow including requesting approval, issuing a
  virtual card, and reporting the outcome.
---

## Allowance — Agent Purchase Wallet

Use Allowance to request spending approval from the user and complete purchases on their behalf.

### Local Browser Requirement

Allowance CLI purchases are local-browser-only.

Before running `allowance request`, verify this current agent session has a tool that can open
and control a local browser checkout page.

This means the session can:
- open the merchant website
- navigate pages
- click buttons and links
- type into checkout forms
- read page state enough to complete checkout

This passes if the current session has one of:
- a dedicated browser automation tool
- a computer-use tool that can operate a browser
- a Chrome extension or browser relay controlled by the agent
- another explicit browser-control tool

This does not pass if you only have:
- web search
- HTTP fetch, curl, or static page retrieval
- screenshots without click/type control
- a browser visible to the user but not controllable by you
- browser access from a previous or different session
- uncertainty about whether browser tools are available

If this check does not pass, do not run `allowance request` and do not create an approval request.

Tell the user:

"Allowance is the right payment flow, but this agent session cannot complete local
checkout yet. Please switch to or connect a browser-capable agent session, such
as Codex with Browser/Computer Use, Claude with Computer Use or a browser-control
extension, or OpenClaw with browser enabled. Then I can create the Allowance
approval request and complete checkout."

If this check passes, continue.

### Browser Tool Values

Use `--local-browser-tool <value>` only when this current session can control a local browser.

Accepted values:
- `browser-tool`: dedicated browser automation tool, such as Codex Browser or OpenClaw Browser
- `computer-use`: a computer-use tool that can operate a browser, such as Codex
  Computer Use or Claude Computer Use
- `chrome-extension`: a Chrome extension or browser relay controlled by the agent
- `other-browser-control`: another explicit browser-control tool that can navigate,
  click, type, and inspect checkout pages

If unsure which value applies, do not create the request.

### Purchase flow

1. **Gather purchase details**

Gather only the minimum required purchase details:
- merchant
- item intent
- high-risk variants like size/color
- all-in spend cap
- shipping requirement

2. **Verify local browser control**

Verify local browser control using the checklist above.

3. **Request approval** (`--amount` is in cents — include estimated tax + shipping)
   ```
   allowance request --merchant "Zara" --url "https://www.zara.com/us/" \
     --amount 5000 --reason "buy a black men's medium tee" \
     --local-browser-tool computer-use
   ```
   Sends a push notification to the user's phone. Blocks until approved or denied (up to 10 min).
   On approval, prints the `allowance_id` needed for subsequent commands.
   Add `--no-shipping` for digital goods, services, pickup, or any non-shipped item.

Do not run `allowance request` without `--local-browser-tool`.

4. **After approval, open the merchant site in the local browser and complete checkout**

5. **Issue a virtual card** (only once the merchant payment form is visible and ready)
   ```
   allowance card issue --allowance-id <allowance_id> --amount <cents> --merchant "<name>"
   ```
   Returns a one-time virtual card number, expiry, and CVV — it expires after the purchase.
   **Never paste, summarize, or reveal card number, CVV, expiry, or last four in chat.**
   Type them directly into the merchant checkout form only.

6. **Fetch checkout details only when the merchant form asks for them**
   - Contact info (name/email/phone): `allowance identity`
   - Shipping address (only if item requires shipping):
     `allowance address shipping --allowance-id <allowance_id>`
   - Billing address: `allowance address billing --allowance-id <allowance_id>`

7. **Report the outcome** (required — unreported purchases block future requests)
   - Success: `allowance purchase success --allowance-id <id>
     --attempt-id <attempt-id> --charged <cents>`
   - Failure: `allowance purchase failure --allowance-id <id>
     --attempt-id <attempt-id> --error-code <error-code>`
     Valid error codes: `card_declined`, `card_declined_avs`, `card_declined_cvv`,
     `checkout_abandoned`, `checkout_error`, `checkout_timeout`, `item_unavailable`,
     `merchant_rejected`, `price_mismatch`, `unsupported_card`
   - If the card is declined: report failure immediately. Do not retry or issue another
     card unless the user explicitly asks and a new allowance approval is obtained.
"""

_SKILL_BODY = _CLAUDE_CODE_SKILL_CONTENT.split('---', 2)[-1]  # reuse workflow body

# Codex skill — auto-invocation on by default, no extra frontmatter needed
_CODEX_SKILL_CONTENT = f"""\
---
name: allowance
description: Allowance agent purchase wallet. Use when the user asks to buy something,
  make a purchase, order an item, or spend money on their behalf.
---
{_SKILL_BODY}"""

# OpenClaw skill — auto-invocable by description match, also available as /allowance slash command
_OPENCLAW_SKILL_CONTENT = f"""\
---
name: allowance
description: Allowance agent purchase wallet. Use when the user asks to buy something,
  make a purchase, order an item, or spend money on their behalf.
---
{_SKILL_BODY}"""

# Sentinel used to detect if Allowance instructions are already present
_ALLOWANCE_BLOCK_SENTINEL = '## Allowance'


# ---------------------------------------------------------------------------
# Helpers — config file
# ---------------------------------------------------------------------------


def _read_config() -> dict[str, Any]:
    try:
        return json.loads(_CONFIG_FILE.read_text())  # type: ignore[no-any-return]
    except (OSError, json.JSONDecodeError):
        return {}


def _write_config(data: dict[str, Any]) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(_CONFIG_FILE), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(json.dumps(data, indent=2))
    except Exception:
        # os.fdopen may not have taken ownership of fd yet (e.g. if it raised),
        # so attempt to close it; ignore errors if it was already closed.
        try:
            os.close(fd)
        except OSError:
            pass
        raise
    # O_CREAT mode only applies when creating; chmod explicitly to fix pre-existing files.
    os.chmod(str(_CONFIG_FILE), 0o600)


# ---------------------------------------------------------------------------
# Helpers — phone normalisation (re-uses logic from cli.py, kept local)
# ---------------------------------------------------------------------------

_E164_RE = re.compile(r'^\+[1-9]\d{6,14}$')


def _normalize_phone(raw: str) -> str:
    digits = re.sub(r'\D', '', raw)
    if raw.lstrip().startswith('+'):
        return '+' + digits
    if len(digits) == 10:
        return '+1' + digits
    if len(digits) == 11 and digits.startswith('1'):
        return '+' + digits
    return raw.strip()


_SUPPORTED_AGENTS = frozenset({'claude-code', 'codex', 'openclaw', 'generic'})

# ---------------------------------------------------------------------------
# Helpers — agent detection
# ---------------------------------------------------------------------------


def _codex_agents_md_path() -> pathlib.Path:
    """Return the Codex global instructions path, honoring CODEX_HOME."""
    codex_home = os.environ.get('CODEX_HOME')
    if codex_home:
        return pathlib.Path(codex_home).expanduser() / 'AGENTS.md'
    return _CODEX_AGENTS_MD


def _codex_agents_md_display_path(path: pathlib.Path) -> str:
    """Return a compact user-facing path for Codex global instructions."""
    if os.environ.get('CODEX_HOME'):
        return str(path)
    return '~/.codex/AGENTS.md'


def _detect_agents(for_agent: str | None) -> list[str]:
    """Return the list of agent slugs to configure.

    If --for <agent> is given, returns exactly that slug.
    Otherwise detects all installed agents and returns them all.
    Falls back to ['generic'] when nothing is detected.

    Supported slugs: 'claude-code', 'codex', 'openclaw', 'generic'
    """
    if for_agent:
        slug = for_agent.lower().strip()
        if slug not in _SUPPORTED_AGENTS:
            valid = ', '.join(sorted(_SUPPORTED_AGENTS))
            typer.echo(f"Error: unknown agent '{slug}'. Valid values: {valid}", err=True)
            raise typer.Exit(code=1)
        return [slug]

    detected: list[str] = []

    # Claude Code / Claude Desktop: env var set by the CLI runtime, or ~/.claude/ dir exists
    if os.environ.get('CLAUDE_CODE_ENTRYPOINT') or _CLAUDE_CODE_SKILL.parents[2].exists():
        detected.append('claude-code')

    # Codex: env var, ~/.codex/ dir, or ~/.agents/ dir (skill home) exists
    if (
        os.environ.get('CODEX_HOME')
        or _codex_agents_md_path().parent.exists()
        or _CODEX_SKILL.parents[2].exists()
    ):
        detected.append('codex')

    # OpenClaw: CLI on PATH or ~/.openclaw/ directory exists
    if shutil.which('openclaw') is not None or _OPENCLAW_SKILL.parents[2].exists():
        detected.append('openclaw')

    return detected or ['generic']


# ---------------------------------------------------------------------------
# Helpers — write global agent instruction files
# ---------------------------------------------------------------------------


def _append_block_idempotent(
    path: pathlib.Path, block: str, *, sentinel: str = _ALLOWANCE_BLOCK_SENTINEL
) -> bool:
    """Append *block* to *path* if *sentinel* is not already present.

    Creates the parent directory if needed.  Returns True if the block was
    written, False if it was already present.
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    existing = ''
    if path.exists():
        try:
            existing = path.read_text()
        except OSError:
            existing = ''

    if sentinel in existing:
        return False

    path.write_text(existing + block)
    return True


_CLAUDE_CODE_MD = pathlib.Path.home() / '.claude' / 'CLAUDE.md'
_CLAUDE_CODE_MD_HINT = (
    '\nWhen asked to buy something, use the `allowance` CLI to request approval and '
    'complete checkout. Start with `allowance request ... --local-browser-tool '
    '<browser-tool|computer-use|chrome-extension|other-browser-control>`. '
    'The Allowance CLI purchase flow requires a local '
    'browser-capable agent session; if browser control is unavailable, ask the user '
    'to switch to or connect a browser-capable session rather than abandoning '
    'Allowance.\n'
)


def _write_claude_code_instructions() -> str:
    """Write Allowance skill + one-liner hint to ~/.claude/CLAUDE.md."""
    _CLAUDE_CODE_SKILL.parent.mkdir(parents=True, exist_ok=True)
    _CLAUDE_CODE_SKILL.write_text(_CLAUDE_CODE_SKILL_CONTENT)
    appended = _append_block_idempotent(
        _CLAUDE_CODE_MD,
        _CLAUDE_CODE_MD_HINT,
        sentinel='local-browser-tool',
    )
    lines = ['  ✓ ~/.claude/skills/allowance/SKILL.md']
    if appended:
        lines.append('  ✓ ~/.claude/CLAUDE.md  (added purchase hint)')
    return 'Configured Claude Desktop:\n' + '\n'.join(lines)


_CODEX_AGENTS_MD_HINT = (
    '\nWhen asked to buy something, use the `allowance` CLI to request approval and '
    'complete checkout. Start with `allowance request ... --local-browser-tool '
    '<browser-tool|computer-use|chrome-extension|other-browser-control>`. '
    'The Allowance CLI purchase flow requires a local '
    'browser-capable agent session; if browser control is unavailable, ask the user '
    'to switch to or connect a browser-capable session rather than abandoning '
    'Allowance.\n'
)


def _write_codex_instructions() -> str:
    """Write Allowance skill to ~/.agents/... and hint to CODEX_HOME/AGENTS.md."""
    _CODEX_SKILL.parent.mkdir(parents=True, exist_ok=True)
    _CODEX_SKILL.write_text(_CODEX_SKILL_CONTENT)
    agents_md_path = _codex_agents_md_path()
    appended = _append_block_idempotent(
        agents_md_path,
        _CODEX_AGENTS_MD_HINT,
        sentinel='local-browser-tool',
    )
    lines = ['  ✓ ~/.agents/skills/allowance/SKILL.md']
    if appended:
        display_path = _codex_agents_md_display_path(agents_md_path)
        lines.append(f'  ✓ {display_path}  (added purchase hint)')
    return 'Configured Codex:\n' + '\n'.join(lines)


def _write_openclaw_instructions() -> str:
    """Write Allowance skill to ~/.openclaw/skills/allowance/SKILL.md."""
    _OPENCLAW_SKILL.parent.mkdir(parents=True, exist_ok=True)
    _OPENCLAW_SKILL.write_text(_OPENCLAW_SKILL_CONTENT)
    return 'Configured OpenClaw:\n  ✓ ~/.openclaw/skills/allowance/SKILL.md'


def _write_generic_instructions() -> str:
    """Return Allowance instructions for the caller to print (no known agent detected)."""
    divider = '─' * 60
    return (
        '\nAdd the following to your agent\'s global instruction file:\n'
        + divider + '\n'
        + _CLAUDE_MD_BLOCK.strip() + '\n'
        + divider
    )


def _write_agent_instructions(agent: str) -> str:
    """Write global agent instruction file. Returns a human-readable status string."""
    if agent == 'claude-code':
        return _write_claude_code_instructions()
    if agent == 'codex':
        return _write_codex_instructions()
    if agent == 'openclaw':
        return _write_openclaw_instructions()
    # generic fallback — print to stdout
    return _write_generic_instructions()


# ---------------------------------------------------------------------------
# Helpers — token validation
# ---------------------------------------------------------------------------


def _verify_existing_token(
    *,
    token: str,
    api_base_url: str,
) -> dict[str, Any] | None:
    """Call /auth/checkout-identity with the connection token if it is still valid."""
    client = AllowanceAPIClient(
        base_url=api_base_url, bearer_token=token, timeout=HTTP_TIMEOUT_SECONDS
    )
    try:
        result = client.get('/auth/checkout-identity')
        if isinstance(result, dict):
            return result
        return None
    except (APIError, APITransportError):
        return None


# ---------------------------------------------------------------------------
# Core setup flow helpers
# ---------------------------------------------------------------------------


def _prompt_phone() -> str:
    """Prompt for phone, return E.164-normalised value."""
    while True:
        raw = typer.prompt('Phone number').strip()
        normalized = _normalize_phone(raw)
        if _E164_RE.match(normalized):
            return normalized
        typer.echo(
            f"  '{raw}' doesn't look like a valid US phone number. "
            'Try formats like 415-555-1234 or +14155551234.',
            err=True,
        )


def _do_send_code(client: AllowanceAPIClient, phone: str) -> str | None:
    """Send OTP. Returns dev_code if present (test mode), else None."""
    result = client.post('/auth/send-code', json_body={'phone': phone})
    if isinstance(result, dict):
        dev = result.get('dev_code')
        if isinstance(dev, str) and dev:
            return dev
    return None


def _do_verify(client: AllowanceAPIClient, phone: str, code: str) -> dict[str, Any]:
    """Verify OTP. Returns the verify response dict."""
    result = client.post('/auth/verify', json_body={'phone': phone, 'code': code})
    if not isinstance(result, dict) or not isinstance(result.get('token'), str):
        typer.echo('Unexpected response from /auth/verify.', err=True)
        raise typer.Exit(code=1)
    return result


def _do_mint_connection_token(
    client: AllowanceAPIClient,
    jwt_token: str,
    api_base_url: str,
) -> tuple[str, str]:
    """Mint a CLI connection token. Returns (token_id, ak_token)."""
    try:
        label: str | None = socket.gethostname() or None
    except Exception:
        label = None
    result = client.post(
        '/connection-tokens',
        json_body={'agent': 'cli', 'label': label},
        bearer_token=jwt_token,
    )
    if not isinstance(result, dict):
        typer.echo('Unexpected response from /connection-tokens.', err=True)
        raise typer.Exit(code=1)
    token_id = result.get('id')
    ak_token = result.get('secret_key')
    if not isinstance(token_id, str) or not isinstance(ak_token, str):
        typer.echo('Missing token fields from /connection-tokens response.', err=True)
        raise typer.Exit(code=1)
    return token_id, ak_token


def _do_save_profile(
    client: AllowanceAPIClient,
    jwt_token: str,
    profile_fields: dict[str, str],
) -> None:
    """Save missing user profile fields."""
    if not profile_fields:
        return
    json_body: dict[str, object] = dict(profile_fields)
    try:
        client.patch(
            '/auth/profile',
            json_body=json_body,
            bearer_token=jwt_token,
        )
    except APIError as exc:
        # Non-fatal: warn but continue
        typer.echo(
            f'Warning: could not save profile: status {exc.status_code}: {exc.body}',
            err=True,
        )
    except APITransportError as exc:
        # Non-fatal: warn but continue
        typer.echo(f'Warning: could not save profile: {exc}', err=True)


def _fetch_user_profile(client: AllowanceAPIClient, jwt_token: str) -> dict[str, Any]:
    """Fetch /auth/profile to get user profile. Returns user dict, or {} on error."""
    try:
        result = client.get('/auth/profile', bearer_token=jwt_token)
        if isinstance(result, dict):
            return result
    except (APIError, APITransportError):
        pass
    return {}


def _profile_str(profile: dict[str, Any], field: str) -> str:
    value = profile.get(field)
    return value.strip() if isinstance(value, str) else ''


def _prompt_missing_profile_fields(user_profile: dict[str, Any]) -> dict[str, str]:
    """Prompt only for missing required profile fields."""
    values = {
        'first_name': _profile_str(user_profile, 'first_name'),
        'last_name': _profile_str(user_profile, 'last_name'),
        'email': _profile_str(user_profile, 'email'),
    }
    prompts = {
        'first_name': 'First name',
        'last_name': 'Last name',
        'email': 'Email',
    }
    missing: dict[str, str] = {}
    for field, prompt in prompts.items():
        if values[field]:
            continue
        missing[field] = typer.prompt(prompt).strip()
    return missing


# ---------------------------------------------------------------------------
# Public command entry point
# ---------------------------------------------------------------------------


def run_setup(
    *,
    api_base_url: str | None,
    for_agent: str | None,
) -> None:
    """Main logic for `allowance setup`."""
    base_url = (api_base_url.rstrip('/') if api_base_url else None) or DEFAULT_API_BASE_URL

    # -----------------------------------------------------------------------
    # PROD-47: check for existing valid token
    # -----------------------------------------------------------------------
    # Use load_connection_token() so the env var (ALLOWANCE_CONNECTION_TOKEN) takes
    # precedence over the config file.  This avoids a split-brain where the env var
    # token is used for auth but the config-file token is written to the agent
    # config on re-run.
    existing_token: str | None = load_connection_token()

    if isinstance(existing_token, str) and existing_token:
        user = _verify_existing_token(token=existing_token, api_base_url=base_url)
        if user is not None:
            first_name = user.get('first_name') or ''
            display = first_name or 'your account'
            typer.echo(f'Found your account ({display}). Re-configuring agent... ', nl=False)
            agents = _detect_agents(for_agent)
            msgs: list[str] = []
            for agent in agents:
                try:
                    msgs.append(_write_agent_instructions(agent))
                except RuntimeError as exc:
                    typer.echo(f'\nAgent config failed: {exc}', err=True)
                    raise typer.Exit(code=1) from exc
            typer.echo('done.')
            for msg in msgs:
                typer.echo(msg)
            typer.echo('')
            typer.echo(SKILL_TEXT)
            return

    # -----------------------------------------------------------------------
    # PROD-35: phone OTP auth flow
    # -----------------------------------------------------------------------
    client = AllowanceAPIClient(base_url=base_url, timeout=HTTP_TIMEOUT_SECONDS)

    phone = _prompt_phone()

    try:
        dev_code = _do_send_code(client, phone)
    except APIError as exc:
        typer.echo(f'Error sending code: {exc.body}', err=True)
        raise typer.Exit(code=1) from exc
    except APITransportError as exc:
        typer.echo(f'Network error: {exc}', err=True)
        raise typer.Exit(code=1) from exc

    _MAX_OTP_ATTEMPTS = 3
    verify_result: dict[str, Any] | None = None

    if dev_code:
        # Dev/test mode: code returned directly, no retry needed
        try:
            verify_result = _do_verify(client, phone, dev_code)
        except APIError as exc:
            typer.echo(f'Error verifying code: {exc.body}', err=True)
            raise typer.Exit(code=1) from exc
        except APITransportError as exc:
            typer.echo(f'Network error: {exc}', err=True)
            raise typer.Exit(code=1) from exc
    else:
        for attempt in range(1, _MAX_OTP_ATTEMPTS + 1):
            code = typer.prompt('Enter the code we sent you').strip()
            try:
                verify_result = _do_verify(client, phone, code)
                break
            except APIError as exc:
                if attempt < _MAX_OTP_ATTEMPTS:
                    typer.echo('Incorrect code, please try again.', err=True)
                else:
                    typer.echo(
                        "Too many incorrect codes. Run `allowance setup` to try again.",
                        err=True,
                    )
                    raise typer.Exit(code=1) from exc
            except APITransportError as exc:
                typer.echo(f'Network error: {exc}', err=True)
                raise typer.Exit(code=1) from exc

    assert verify_result is not None
    jwt_token: str = verify_result['token']

    # Fetch user profile to reliably detect new vs existing users.
    # The /auth/verify response does not include profile fields; /auth/profile does.
    user_profile = _fetch_user_profile(client, jwt_token)
    existing_first_name = _profile_str(user_profile, 'first_name')
    missing_profile_fields = _prompt_missing_profile_fields(user_profile)

    if missing_profile_fields:
        _do_save_profile(client, jwt_token, missing_profile_fields)
        typer.echo('Setting up... ', nl=False)
    elif existing_first_name:
        typer.echo(f'Found your account ({existing_first_name}). Setting up... ', nl=False)
    else:
        typer.echo('Setting up... ', nl=False)

    # -----------------------------------------------------------------------
    # Mint connection token
    # -----------------------------------------------------------------------
    try:
        token_id, ak_token = _do_mint_connection_token(client, jwt_token, base_url)
    except APIError as exc:
        typer.echo(f'\nError minting connection token: {exc.body}', err=True)
        raise typer.Exit(code=1) from exc
    except APITransportError as exc:
        typer.echo(f'\nNetwork error: {exc}', err=True)
        raise typer.Exit(code=1) from exc

    # -----------------------------------------------------------------------
    # Store token in OS credential storage and write non-secret config metadata.
    # -----------------------------------------------------------------------
    try:
        save_connection_config(
            token_id=token_id,
            token=ak_token,
            api_base_url=base_url,
            path=_CONFIG_FILE,
        )
    except CredentialStoreError as exc:
        typer.echo(
            '\nError storing connection token securely. '
            'No connection token was saved. '
            f'Fix OS credential storage and try again. Detail: {exc}',
            err=True,
        )
        raise typer.Exit(code=1) from exc

    # -----------------------------------------------------------------------
    # PROD-37: write global agent instruction files
    # -----------------------------------------------------------------------
    agents = _detect_agents(for_agent)
    msgs = []
    for agent in agents:
        try:
            msgs.append(_write_agent_instructions(agent))
        except RuntimeError as exc:
            typer.echo(f'\nAgent config failed: {exc}', err=True)
            raise typer.Exit(code=1) from exc

    typer.echo('done.')
    for msg in msgs:
        typer.echo(msg)

    # -----------------------------------------------------------------------
    # PROD-36: print SKILL content
    # -----------------------------------------------------------------------
    typer.echo('')
    typer.echo(SKILL_TEXT)
