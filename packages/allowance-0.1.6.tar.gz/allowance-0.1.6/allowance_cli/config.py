from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from allowance_cli.credential_store import (
    CredentialStoreError,
    load_stored_connection_token,
    store_connection_token,
)

DEFAULT_API_BASE_URL = os.getenv('ALLOWANCE_API_BASE_URL', 'https://api.useallowance.com').rstrip('/')
HTTP_TIMEOUT_SECONDS = float(os.getenv('ALLOWANCE_HTTP_TIMEOUT_SECONDS', '20'))

CONFIG_PATH = Path.home() / '.allowance' / 'config.json'
APP_BASE_URL = 'https://app.useallowance.com'
_LEGACY_TOKEN_KEYS = ('token', 'connection_token', 'ak_token')

# Seconds between each poll when waiting for allowance request approval.
CHECKOUT_POLL_INTERVAL_SECONDS = 5.0
# Total seconds before the CLI gives up waiting for approval.
CHECKOUT_WAIT_TIMEOUT_SECONDS = 600.0
# Seconds between each poll when waiting for purchase auth (phone 2FA).
PURCHASE_AUTH_POLL_INTERVAL_SECONDS = 2.0
# Total seconds to wait for phone auth before giving up.
PURCHASE_AUTH_WAIT_TIMEOUT_SECONDS = 300.0


def _warn(message: str) -> None:
    print(f'Warning: {message}', file=sys.stderr)


def _read_config(path: Path = CONFIG_PATH) -> dict[str, object]:
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def _write_config(data: dict[str, object], path: Path = CONFIG_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(json.dumps(data, indent=2))
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        raise
    os.chmod(str(path), 0o600)


def _token_id_from_config(data: dict[str, object]) -> str | None:
    value = data.get('token_id')
    return value.strip() if isinstance(value, str) and value.strip() else None


def _remove_legacy_token_keys(
    data: dict[str, object],
    path: Path = CONFIG_PATH,
) -> dict[str, object]:
    cleaned = {key: value for key, value in data.items() if key not in _LEGACY_TOKEN_KEYS}
    if cleaned == data:
        return data
    try:
        _write_config(cleaned, path)
    except OSError as exc:
        _warn(f'could not remove legacy plaintext token from config: {exc}')
    return cleaned


def save_connection_config(
    *,
    token_id: str,
    token: str,
    api_base_url: str,
    path: Path = CONFIG_PATH,
) -> None:
    """Persist connection metadata and store the token secret securely."""
    data: dict[str, object] = {
        'token_id': token_id,
        'api_base_url': api_base_url,
    }
    store_connection_token(token_id=token_id, token=token)
    _write_config(data, path)


def load_connection_token() -> str | None:
    """Return the connection token from env/configured credential storage, if available."""
    env_token = os.getenv('ALLOWANCE_CONNECTION_TOKEN', '').strip()
    if env_token:
        return env_token
    if not CONFIG_PATH.exists():
        return None
    data = _remove_legacy_token_keys(_read_config(CONFIG_PATH), CONFIG_PATH)
    token_id = _token_id_from_config(data)
    if not token_id:
        return None
    try:
        return load_stored_connection_token(token_id=token_id)
    except CredentialStoreError as exc:
        _warn(str(exc))
    return None
