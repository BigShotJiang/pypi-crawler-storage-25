# AGENTS

## Purpose

`allowance-cli` is the agent purchase wallet CLI. It has two roles:

1. **Setup** (`allowance setup`) — OTP auth, connection token mint, agent skill file installation for Claude Desktop, Codex, and OpenClaw.
2. **Runtime checkout** — `allowance request`, `allowance card issue`, `allowance identity`, `allowance address`, `allowance purchase success/failure`. Agents use these commands to complete purchases at runtime.

## Stack

- Python 3.12+
- `uv` (env + command runner)
- `typer` (CLI)
- `httpx` (HTTP client)
- `ruff` (lint/import ordering)
- `mypy` (type checks)
- `pytest` (tests)

## Repo Layout

```text
allowance_cli/
  cli.py          — app entry point; setup + runtime checkout commands
  api.py          — AllowanceAPIClient (httpx wrapper)
  config.py       — env-var config, connection token loader
  checkout.py     — request/card/identity/address/purchase subcommands
  setup_cmd.py    — allowance setup logic (OTP, token mint, skill file writes)
tests/
  test_setup_cmd.py
  test_checkout_commands.py
scripts/
  test_unit.sh
  test_smoke.sh
  test_all.sh
.github/workflows/tests.yml
```

## Setup behavior (`allowance setup`)

- Checks for an existing valid connection token first; if found, skips auth and re-writes skill files only.
- New users: prompts for phone → OTP → first name, last name, email → mints connection token → writes skill files.
- Existing users: phone → OTP → mints connection token → writes skill files (no profile prompts).
- Connection token secret is stored in OS credential storage via `keyring`; `~/.allowance/config.json` stores non-secret metadata like `token_id` and `api_base_url` (mode 0600).
- Skill files written per detected agent:
  - Claude Desktop → `~/.claude/CLAUDE.md` (purchase hint) + `~/.claude/skills/allowance/SKILL.md`
  - Codex → `~/.codex/AGENTS.md` (purchase hint) + `~/.agents/skills/allowance/SKILL.md`
  - OpenClaw → `~/.openclaw/skills/allowance/SKILL.md`
- `--for <agent>` overrides auto-detection. Valid values: `claude-code`, `codex`, `openclaw`, `generic`.
- Auto-detection checks: `CLAUDE_CODE_ENTRYPOINT` env var (Claude Desktop), `CODEX_HOME` env var or `~/.codex/` or `~/.agents/` (Codex), `openclaw` on PATH or `~/.openclaw/` (OpenClaw).

## Runtime checkout behavior

Checkout commands output human-readable text by default. Pass `--json` for machine-parseable output (useful for scripting or agent use).

- `allowance request --merchant <name> --amount <cents> --reason <text> --local-browser-tool <type>` — requires current-session local browser control, then polls until approved/denied (up to 10 min). Add `--no-shipping` for digital goods or pickup.
- `allowance card issue --allowance-id <id> --amount <cents> --merchant <name>` — issues a one-time virtual card. Call only once the merchant payment form is visible.
- `allowance identity` — returns name, email, phone for checkout forms.
- `allowance address shipping --allowance-id <id>` — returns shipping address.
- `allowance address billing --allowance-id <id>` — returns billing address.
- `allowance purchase success --allowance-id <id> --attempt-id <id> --charged <cents>`
- `allowance purchase failure --allowance-id <id> --attempt-id <id> --error-code <code>`

## Configuration

- `ALLOWANCE_API_BASE_URL` (default `https://api.useallowance.com`)
- `ALLOWANCE_HTTP_TIMEOUT_SECONDS` (default `20`)
- `ALLOWANCE_CONNECTION_TOKEN` overrides configured credential storage for CI/debugging.

## Local Commands

```bash
uv sync --dev
uv run allowance --help
./scripts/test_unit.sh
./scripts/test_smoke.sh
./scripts/test_all.sh
```

## Engineering Rules

- Keep command payloads aligned to API auth/bootstrap contracts.
- CLI purchases are local-browser-only. `allowance request` must include `--local-browser-tool browser-tool|computer-use|chrome-extension|other-browser-control`.
- Do not print full connection tokens in command output.
- `--amount` is always in cents throughout the codebase — never dollars.
- `allowance card issue` is the one intentional exception for payment credentials: it prints card number, expiry, and CVV so the agent can type them directly into the merchant checkout form. This is correct and expected behavior.
- Agents must never paste, summarize, log, or reveal card number, CVV, expiry, or last four in chat. Use the credentials only for the merchant payment form.

## Ops Reminder

- If npm publish fails with auth errors (401/403), rotate the `NPM_TOKEN` GitHub secret:
  1. Create a new npm automation token for `@allowance/cli`.
  2. Update GitHub repo secret `NPM_TOKEN`.
  3. Re-run publish by pushing a new `npm-v*` tag.
