"""Tests for allowance_cli/setup_cmd.py (PROD-35/36/37/47)."""

from __future__ import annotations

import json
import pathlib
import stat
from typing import Any

import pytest
from typer.testing import CliRunner

from allowance_cli.api import APIError
from allowance_cli.cli import app

# ---------------------------------------------------------------------------
# Minimal stub client that mirrors AllowanceAPIClient's interface
# ---------------------------------------------------------------------------


class StubSetupClient:
    """Stub for AllowanceAPIClient used in setup_cmd tests."""

    def __init__(
        self,
        *,
        base_url: str,
        bearer_token: str | None = None,
        timeout: float = 20.0,
        responses: dict[tuple[str, str, str | None], object],
        calls: list[dict[str, object]],
    ) -> None:
        self.base_url = base_url
        self.bearer_token = bearer_token
        self.timeout = timeout
        self.responses = responses
        self.calls = calls

    def _record(self, method: str, path: str, token: str | None, json_body: Any) -> Any:
        self.calls.append({'method': method, 'path': path, 'token': token, 'json_body': json_body})
        key = (method, path, token)
        result = self.responses[key]
        if isinstance(result, Exception):
            raise result
        return result

    def get(self, path: str, *, bearer_token: str | None = None) -> Any:
        token = bearer_token if bearer_token is not None else self.bearer_token
        return self._record('GET', path, token, None)

    def post(
        self,
        path: str,
        *,
        json_body: dict[str, object] | None = None,
        bearer_token: str | None = None,
    ) -> Any:
        token = bearer_token if bearer_token is not None else self.bearer_token
        return self._record('POST', path, token, json_body)

    def patch(
        self,
        path: str,
        *,
        json_body: dict[str, object] | None = None,
        bearer_token: str | None = None,
    ) -> Any:
        token = bearer_token if bearer_token is not None else self.bearer_token
        return self._record('PATCH', path, token, json_body)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_client_factory(
    responses: dict[tuple[str, str, str | None], object],
    calls: list[dict[str, object]],
) -> Any:
    """Return a factory that produces StubSetupClient instances."""

    def factory(
        *, base_url: str, bearer_token: str | None = None, timeout: float = 20.0
    ) -> StubSetupClient:
        return StubSetupClient(
            base_url=base_url,
            bearer_token=bearer_token,
            timeout=timeout,
            responses=responses,
            calls=calls,
        )

    return factory


@pytest.fixture(autouse=True)
def _isolate_real_connection_token(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """Prevent setup tests from reading the developer machine's real Allowance token."""
    monkeypatch.delenv('ALLOWANCE_CONNECTION_TOKEN', raising=False)
    monkeypatch.setattr(
        'allowance_cli.config.CONFIG_PATH',
        tmp_path / 'no-real-allowance-config.json',
    )
    stored_tokens: dict[str, str] = {}
    monkeypatch.setattr(
        'allowance_cli.config.store_connection_token',
        lambda *, token_id, token: stored_tokens.__setitem__(token_id, token),
    )
    monkeypatch.setattr(
        'allowance_cli.config.load_stored_connection_token',
        lambda *, token_id: stored_tokens.get(token_id),
    )


def _standard_responses(
    *,
    dev_code: str = '123456',
    jwt_token: str = 'jwt_test',
    first_name: str | None = None,  # None → new user
    last_name: str | None = None,
    email: str | None = 'test@example.com',
    token_id: str = 'tok_abc',
    ak_token: str = 'ak_live_testtoken',
    mcp_url: str = 'https://mcp.useallowance.com',
) -> dict[tuple[str, str, str | None], object]:
    """Build a typical set of response fixtures."""
    return {
        ('POST', '/auth/send-code', None): {'ok': True, 'dev_code': dev_code},
        ('POST', '/auth/verify', None): {
            'token': jwt_token,
            'user_id': 'user_xyz',
            'config': {'mcp_url': mcp_url},
        },
        ('GET', '/auth/profile', jwt_token): {
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
        },
        ('POST', '/connection-tokens', jwt_token): {
            'id': token_id,
            'secret_key': ak_token,
            'key_prefix': ak_token[:12],
        },
        ('PATCH', '/auth/profile', jwt_token): {'ok': True},
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_happy_path_new_user_saves_config_with_0600(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """New user: OTP → verify → profile prompts → saves config with 0600 perms."""
    calls: list[dict[str, object]] = []
    responses = _standard_responses(first_name=None)

    # Redirect config directory to tmp_path
    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    # Stub out client and agent-instruction writing
    monkeypatch.setattr(
        'allowance_cli.setup_cmd.AllowanceAPIClient',
        _make_client_factory(responses, calls),
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions',
        lambda agent: f'stubbed {agent}',
    )

    # dev_code is returned → no OTP prompt, but profile prompts are needed
    result = CliRunner().invoke(
        app,
        ['setup'],
        input='4155551234\nAlice\nSmith\nalice@example.com\n',
    )

    assert result.exit_code == 0, result.output
    assert 'Allowance is ready' in result.output

    # Config file must exist and have mode 0600
    assert config_file.exists()
    mode = stat.S_IMODE(config_file.stat().st_mode)
    assert mode == 0o600, f'Expected 0600, got {oct(mode)}'

    data = json.loads(config_file.read_text())
    assert 'token' not in data
    assert data['token_id'] == 'tok_abc'
    assert 'mcp_url' not in data


def test_happy_path_existing_complete_user_skips_profile(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """Existing complete user skips all profile-collection prompts."""
    calls: list[dict[str, object]] = []
    responses = _standard_responses(first_name='Bob', last_name='Jones')

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    monkeypatch.setattr(
        'allowance_cli.setup_cmd.AllowanceAPIClient',
        _make_client_factory(responses, calls),
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions',
        lambda agent: 'stubbed',
    )

    # Only phone input — no name/email prompts expected
    result = CliRunner().invoke(app, ['setup'], input='4155551234\n')

    assert result.exit_code == 0, result.output
    assert 'Found your account (Bob)' in result.output
    # Ensure no PATCH /auth/profile was called (profile not re-saved)
    patch_calls = [c for c in calls if c['method'] == 'PATCH' and c['path'] == '/auth/profile']
    assert patch_calls == [], 'Should not save profile for existing user'


def test_incomplete_profile_prompts_only_for_missing_fields(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """Existing partial profile prompts only for missing fields and patches /auth/profile."""
    calls: list[dict[str, object]] = []
    responses = _standard_responses(first_name='Bob', last_name='Jones', email=None)

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    monkeypatch.setattr(
        'allowance_cli.setup_cmd.AllowanceAPIClient',
        _make_client_factory(responses, calls),
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions',
        lambda agent: 'stubbed',
    )

    result = CliRunner().invoke(app, ['setup'], input='4155551234\nbob@example.com\n')

    assert result.exit_code == 0, result.output
    patch_calls = [c for c in calls if c['method'] == 'PATCH' and c['path'] == '/auth/profile']
    assert len(patch_calls) == 1
    assert patch_calls[0]['json_body'] == {'email': 'bob@example.com'}


def test_profile_patch_error_prints_status_and_body(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """Profile save failures include enough API detail to diagnose stale route contracts."""
    calls: list[dict[str, object]] = []
    responses = _standard_responses(first_name=None)
    responses[('PATCH', '/auth/profile', 'jwt_test')] = APIError(
        status_code=422,
        body={'detail': 'invalid email'},
    )

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    monkeypatch.setattr(
        'allowance_cli.setup_cmd.AllowanceAPIClient',
        _make_client_factory(responses, calls),
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions',
        lambda agent: 'stubbed',
    )

    result = CliRunner().invoke(
        app,
        ['setup'],
        input='4155551234\nAlice\nSmith\nalice@example.com\n',
    )

    assert result.exit_code == 0, result.output
    assert "Warning: could not save profile: status 422: {'detail': 'invalid email'}" in (
        result.output + result.stderr
    )
    assert 'Allowance is ready' in result.output


def test_setup_exits_without_plaintext_when_secure_store_fails(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """Setup does not silently write plaintext tokens when credential storage fails."""
    calls: list[dict[str, object]] = []
    responses = _standard_responses(first_name='Bob', last_name='Jones')

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    monkeypatch.setattr(
        'allowance_cli.setup_cmd.AllowanceAPIClient',
        _make_client_factory(responses, calls),
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions',
        lambda agent: 'stubbed',
    )

    def _raise(*, token_id: str, token: str) -> None:
        from allowance_cli.credential_store import CredentialStoreError

        raise CredentialStoreError('no backend')

    monkeypatch.setattr('allowance_cli.config.store_connection_token', _raise)

    result = CliRunner().invoke(app, ['setup'], input='4155551234\n')

    assert result.exit_code != 0
    assert 'Error storing connection token securely' in result.output
    assert not config_file.exists()


def test_wrong_otp_retried_second_attempt_succeeds(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """First OTP attempt fails with APIError; second succeeds."""
    calls: list[dict[str, object]] = []

    verify_attempt = [0]

    def verify_side_effect(
        path: str, *, json_body: Any = None, bearer_token: str | None = None
    ) -> Any:
        if path == '/auth/send-code':
            calls.append({'method': 'POST', 'path': path, 'token': None, 'json_body': json_body})
            # No dev_code → force manual prompt
            return {'ok': True}
        if path == '/auth/verify':
            calls.append({'method': 'POST', 'path': path, 'token': None, 'json_body': json_body})
            verify_attempt[0] += 1
            if verify_attempt[0] == 1:
                raise APIError(status_code=400, body={'detail': 'invalid or expired code'})
            return {
                'token': 'jwt_retry',
                'user_id': 'user_retry',
                'config': {'mcp_url': 'https://mcp.useallowance.com'},
            }
        if path == '/connection-tokens':
            calls.append(
                {'method': 'POST', 'path': path, 'token': bearer_token, 'json_body': json_body}
            )
            return {'id': 'tok_retry', 'secret_key': 'ak_retry_token', 'key_prefix': 'ak_retry_t'}
        raise KeyError(f'Unexpected POST to {path}')

    class RetryStubClient:
        def __init__(
            self, *, base_url: str, bearer_token: str | None = None, timeout: float = 20.0
        ) -> None:
            self.base_url = base_url
            self.bearer_token = bearer_token

        def get(self, path: str, *, bearer_token: str | None = None) -> Any:
            # /auth/profile after successful verify
            token = bearer_token if bearer_token is not None else self.bearer_token
            calls.append({'method': 'GET', 'path': path, 'token': token, 'json_body': None})
            return {'first_name': None, 'last_name': None}

        def post(
            self, path: str, *, json_body: Any = None, bearer_token: str | None = None
        ) -> Any:
            return verify_side_effect(path, json_body=json_body, bearer_token=bearer_token)

        def patch(
            self, path: str, *, json_body: Any = None, bearer_token: str | None = None
        ) -> Any:
            calls.append(
                {'method': 'PATCH', 'path': path, 'token': bearer_token, 'json_body': json_body}
            )
            return {'ok': True}

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    monkeypatch.setattr('allowance_cli.setup_cmd.AllowanceAPIClient', RetryStubClient)
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions',
        lambda agent: 'stubbed',
    )

    # Provide: phone, wrong code, correct code, then profile
    result = CliRunner().invoke(
        app,
        ['setup'],
        input='4155551234\n000000\n123456\nCarol\nTaylor\ncarol@example.com\n',
    )

    assert result.exit_code == 0, result.output
    assert verify_attempt[0] == 2


def test_max_otp_retries_exceeded_exits_nonzero(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """After 3 wrong OTP attempts, exits with non-zero and shows clear message."""
    calls: list[dict[str, object]] = []

    class AlwaysWrongOTPClient:
        def __init__(
            self, *, base_url: str, bearer_token: str | None = None, timeout: float = 20.0
        ) -> None:
            self.base_url = base_url

        def get(self, path: str, *, bearer_token: str | None = None) -> Any:
            raise AssertionError(f'Unexpected GET {path}')

        def post(
            self, path: str, *, json_body: Any = None, bearer_token: str | None = None
        ) -> Any:
            calls.append(
                {'method': 'POST', 'path': path, 'token': bearer_token, 'json_body': json_body}
            )
            if path == '/auth/send-code':
                # No dev_code so manual prompt is triggered
                return {'ok': True}
            if path == '/auth/verify':
                raise APIError(status_code=400, body={'detail': 'invalid or expired code'})
            raise AssertionError(f'Unexpected POST {path}')

        def patch(
            self, path: str, *, json_body: Any = None, bearer_token: str | None = None
        ) -> Any:
            raise AssertionError(f'Unexpected PATCH {path}')

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    monkeypatch.setattr('allowance_cli.setup_cmd.AllowanceAPIClient', AlwaysWrongOTPClient)
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions',
        lambda agent: 'stubbed',
    )

    # 3 wrong codes
    result = CliRunner().invoke(
        app,
        ['setup'],
        input='4155551234\n000000\n111111\n222222\n',
    )

    assert result.exit_code != 0
    combined = result.output + (result.stderr if hasattr(result, 'stderr') else '')
    assert 'Too many incorrect codes' in combined
    # Config must NOT have been written
    assert not config_file.exists()


def test_config_file_permissions_are_0600(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """Standalone permission check: config file is always written 0600."""
    calls: list[dict[str, object]] = []
    responses = _standard_responses(first_name='Dan', last_name='Wu')

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    monkeypatch.setattr(
        'allowance_cli.setup_cmd.AllowanceAPIClient',
        _make_client_factory(responses, calls),
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions',
        lambda agent: 'stubbed',
    )

    result = CliRunner().invoke(app, ['setup'], input='4155551234\n')
    assert result.exit_code == 0, result.output

    assert config_file.exists()
    mode = stat.S_IMODE(config_file.stat().st_mode)
    assert mode == 0o600, f'Expected 0600, got {oct(mode)}'


def test_config_file_permissions_repaired_if_preexisting_insecure(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """If config.json already exists with 0644, _write_config must chmod it to 0600."""
    config_dir = tmp_path / '.allowance'
    config_dir.mkdir(parents=True)
    config_file = config_dir / 'config.json'
    # Pre-create the file with insecure permissions.
    config_file.write_text('{}')
    config_file.chmod(0o644)

    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    from allowance_cli.setup_cmd import _write_config
    _write_config({'token': 'ak_test'})

    mode = stat.S_IMODE(config_file.stat().st_mode)
    assert mode == 0o600, f'Expected 0600 after repair, got {oct(mode)}'


def test_rerun_skips_auth_and_updates_agent_instructions(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """Re-run with a valid existing token: auth is skipped; agent instructions are updated.

    Asserts:
    - /auth/send-code and /auth/verify are NOT called on second run
    - _write_agent_instructions is called exactly once per run (not duplicated)
    - The token used for agent config on second run is the one returned by load_connection_token()
    """
    existing_token = 'ak_live_existing_token'
    mcp_url = 'https://mcp.useallowance.com'

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file.write_text(json.dumps({'token_id': 'tok_existing', 'mcp_url': mcp_url}))

    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)

    # load_connection_token returns the existing token, normally via env or credential storage.
    monkeypatch.setattr(
        'allowance_cli.setup_cmd.load_connection_token',
        lambda: existing_token,
    )

    verify_calls: list[str] = []

    class RerunStubClient:
        """Records calls; returns valid /auth/checkout-identity for the existing token."""

        def __init__(
            self, *, base_url: str, bearer_token: str | None = None, timeout: float = 20.0
        ) -> None:
            self.bearer_token = bearer_token

        def get(self, path: str, *, bearer_token: str | None = None) -> Any:
            token = bearer_token if bearer_token is not None else self.bearer_token
            verify_calls.append(f'GET {path} token={token}')
            if path == '/auth/checkout-identity':
                return {'first_name': 'Eve', 'last_name': 'Adams', 'email': 'eve@example.com'}
            raise AssertionError(f'Unexpected GET {path}')

        def post(
            self, path: str, *, json_body: Any = None, bearer_token: str | None = None
        ) -> Any:
            verify_calls.append(f'POST {path}')
            raise AssertionError(f'Unexpected POST {path} — auth should be skipped on re-run')

        def patch(
            self, path: str, *, json_body: Any = None, bearer_token: str | None = None
        ) -> Any:
            raise AssertionError(f'Unexpected PATCH {path}')

    monkeypatch.setattr('allowance_cli.setup_cmd.AllowanceAPIClient', RerunStubClient)

    agent_instruction_calls: list[str] = []

    def _stub_write_agent_instructions(agent: str) -> str:
        agent_instruction_calls.append(agent)
        return f'stubbed {agent}'

    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions', _stub_write_agent_instructions
    )

    # ---- First run (with existing token) ----
    result1 = CliRunner().invoke(app, ['setup'])
    assert result1.exit_code == 0, result1.output
    assert 'Found your account (Eve)' in result1.output

    # Auth endpoints must NOT have been called.
    auth_calls = [c for c in verify_calls if 'send-code' in c or '/auth/verify' in c]
    assert auth_calls == [], f'Expected no auth calls on re-run, got: {auth_calls}'

    # _write_agent_instructions called at least once (once per detected agent).
    assert len(agent_instruction_calls) >= 1, (
        f'Expected at least 1 agent instruction call, got {len(agent_instruction_calls)}'
    )
    first_run_count = len(agent_instruction_calls)

    # ---- Second run (idempotent) ----
    verify_calls.clear()
    agent_instruction_calls.clear()

    result2 = CliRunner().invoke(app, ['setup'])
    assert result2.exit_code == 0, result2.output
    assert 'Found your account (Eve)' in result2.output

    # Still no auth calls on second run.
    auth_calls2 = [c for c in verify_calls if 'send-code' in c or '/auth/verify' in c]
    assert auth_calls2 == [], f'Expected no auth calls on second re-run, got: {auth_calls2}'

    # Same number of calls on second run (consistent, no duplication within a run).
    assert len(agent_instruction_calls) == first_run_count, (
        f'Expected {first_run_count} agent instruction calls on second run,'
        f' got {len(agent_instruction_calls)}'
    )


def test_detect_agents_claude_code(monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path) -> None:
    """_detect_agents includes 'claude-code' when CLAUDE_CODE_ENTRYPOINT env var is set."""
    from allowance_cli.setup_cmd import _detect_agents

    monkeypatch.setenv('CLAUDE_CODE_ENTRYPOINT', 'claude-desktop')
    monkeypatch.delenv('CODEX_HOME', raising=False)
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._CLAUDE_CODE_SKILL',
        tmp_path / 'no_claude' / 'skills' / 'allowance' / 'SKILL.md',
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._CODEX_AGENTS_MD', tmp_path / 'no_codex' / 'AGENTS.md'
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._CODEX_SKILL',
        tmp_path / 'no_agents' / 'skills' / 'allowance' / 'SKILL.md',
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._OPENCLAW_SKILL',
        tmp_path / 'no_openclaw' / 'skills' / 'allowance' / 'SKILL.md',
    )
    monkeypatch.setattr('allowance_cli.setup_cmd.shutil.which', lambda name: None)
    assert _detect_agents(None) == ['claude-code']


def test_detect_agents_multiple(monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path) -> None:
    """_detect_agents returns all detected agents when multiple are present."""
    from allowance_cli.setup_cmd import _detect_agents

    monkeypatch.setenv('CLAUDE_CODE_ENTRYPOINT', 'claude-desktop')
    monkeypatch.setenv('CODEX_HOME', '/tmp/fake-codex')
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._CLAUDE_CODE_SKILL',
        tmp_path / 'no_claude' / 'skills' / 'allowance' / 'SKILL.md',
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._CODEX_AGENTS_MD', tmp_path / 'no_codex' / 'AGENTS.md'
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._OPENCLAW_SKILL',
        tmp_path / 'no_openclaw' / 'skills' / 'allowance' / 'SKILL.md',
    )
    monkeypatch.setattr('allowance_cli.setup_cmd.shutil.which', lambda name: None)
    assert _detect_agents(None) == ['claude-code', 'codex']


def test_detect_agents_generic_fallback(
    monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path
) -> None:
    """_detect_agents returns ['generic'] when no agent signals are present."""
    from allowance_cli.setup_cmd import _detect_agents

    monkeypatch.delenv('CLAUDE_CODE_ENTRYPOINT', raising=False)
    monkeypatch.delenv('CODEX_HOME', raising=False)
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._CLAUDE_CODE_SKILL',
        tmp_path / 'no_claude' / 'skills' / 'allowance' / 'SKILL.md',
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._CODEX_AGENTS_MD', tmp_path / 'no_codex' / 'AGENTS.md'
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._CODEX_SKILL',
        tmp_path / 'no_agents' / 'skills' / 'allowance' / 'SKILL.md',
    )
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._OPENCLAW_SKILL',
        tmp_path / 'no_openclaw' / 'skills' / 'allowance' / 'SKILL.md',
    )
    monkeypatch.setattr('allowance_cli.setup_cmd.shutil.which', lambda name: None)
    assert _detect_agents(None) == ['generic']


def test_detect_agents_explicit_override(monkeypatch: pytest.MonkeyPatch) -> None:
    """_detect_agents honours --for flag and returns exactly that agent."""
    from allowance_cli.setup_cmd import _detect_agents

    monkeypatch.setenv('CLAUDE_CODE_ENTRYPOINT', 'claude-desktop')
    assert _detect_agents('codex') == ['codex']
    assert _detect_agents('openclaw') == ['openclaw']
    assert _detect_agents('generic') == ['generic']


def test_write_claude_code_instructions_writes_skill(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """_write_claude_code_instructions writes SKILL.md to ~/.claude/skills/allowance/."""
    from allowance_cli.setup_cmd import (
        _CLAUDE_CODE_SKILL_CONTENT,
        _write_claude_code_instructions,
    )

    target = tmp_path / '.claude' / 'skills' / 'allowance' / 'SKILL.md'
    monkeypatch.setattr('allowance_cli.setup_cmd._CLAUDE_CODE_SKILL', target)

    # First call — directory does not exist yet
    msg = _write_claude_code_instructions()
    assert 'Configured Claude Desktop' in msg
    assert '~/.claude/skills/allowance/SKILL.md' in msg
    assert target.exists()
    content = target.read_text()
    assert 'description:' in content
    assert '## Allowance' in content
    assert '## Allowance' in content

    # Second call — idempotent overwrite, no error
    msg2 = _write_claude_code_instructions()
    assert 'Configured Claude Desktop' in msg2
    # Content is always the canonical version
    assert target.read_text() == _CLAUDE_CODE_SKILL_CONTENT


def test_write_codex_instructions_creates_dir(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """_write_codex_instructions writes skill to ~/.agents/skills/allowance/."""
    from allowance_cli.setup_cmd import _CODEX_SKILL_CONTENT, _write_codex_instructions

    skill_target = tmp_path / '.agents' / 'skills' / 'allowance' / 'SKILL.md'
    agents_target = tmp_path / '.codex' / 'AGENTS.md'
    monkeypatch.setattr('allowance_cli.setup_cmd._CODEX_SKILL', skill_target)
    monkeypatch.setattr('allowance_cli.setup_cmd._CODEX_AGENTS_MD', agents_target)

    msg = _write_codex_instructions()
    assert 'Configured Codex' in msg
    assert skill_target.exists()
    assert skill_target.read_text() == _CODEX_SKILL_CONTENT
    assert 'allowance request' in agents_target.read_text()
    assert '--local-browser-tool' in agents_target.read_text()


def test_write_codex_instructions_upgrades_legacy_global_hint(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Existing old hints contain `allowance request` but not the required browser flag."""
    from allowance_cli.setup_cmd import _write_codex_instructions

    skill_target = tmp_path / '.agents' / 'skills' / 'allowance' / 'SKILL.md'
    agents_target = tmp_path / '.codex' / 'AGENTS.md'
    agents_target.parent.mkdir(parents=True)
    agents_target.write_text(
        '\nWhen asked to buy something, use the `allowance` CLI — run `allowance request`'
        ' to get the user approval.\n'
    )
    monkeypatch.setattr('allowance_cli.setup_cmd._CODEX_SKILL', skill_target)
    monkeypatch.setattr('allowance_cli.setup_cmd._CODEX_AGENTS_MD', agents_target)

    msg = _write_codex_instructions()

    content = agents_target.read_text()
    assert 'Configured Codex' in msg
    assert 'added purchase hint' in msg
    assert content.count('allowance request') == 2
    assert '--local-browser-tool' in content

    msg2 = _write_codex_instructions()
    assert 'added purchase hint' not in msg2
    assert agents_target.read_text() == content


def test_write_codex_instructions_honors_codex_home(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """_write_codex_instructions writes AGENTS.md under CODEX_HOME when set."""
    from allowance_cli.setup_cmd import _write_codex_instructions

    skill_target = tmp_path / '.agents' / 'skills' / 'allowance' / 'SKILL.md'
    default_agents_target = tmp_path / '.codex' / 'AGENTS.md'
    custom_codex_home = tmp_path / 'custom-codex'
    custom_agents_target = custom_codex_home / 'AGENTS.md'

    monkeypatch.setenv('CODEX_HOME', str(custom_codex_home))
    monkeypatch.setattr('allowance_cli.setup_cmd._CODEX_SKILL', skill_target)
    monkeypatch.setattr('allowance_cli.setup_cmd._CODEX_AGENTS_MD', default_agents_target)

    msg = _write_codex_instructions()

    assert 'Configured Codex' in msg
    assert str(custom_agents_target) in msg
    assert custom_agents_target.exists()
    assert 'allowance request' in custom_agents_target.read_text()
    assert '--local-browser-tool' in custom_agents_target.read_text()
    assert not default_agents_target.exists()


def test_write_openclaw_instructions_writes_skill(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """_write_openclaw_instructions writes skill to ~/.openclaw/skills/allowance/."""
    from allowance_cli.setup_cmd import _OPENCLAW_SKILL_CONTENT, _write_openclaw_instructions

    skill_target = tmp_path / '.openclaw' / 'skills' / 'allowance' / 'SKILL.md'
    monkeypatch.setattr('allowance_cli.setup_cmd._OPENCLAW_SKILL', skill_target)

    msg = _write_openclaw_instructions()
    assert 'Configured OpenClaw' in msg
    assert skill_target.exists()
    content = skill_target.read_text()
    assert content == _OPENCLAW_SKILL_CONTENT
    assert '## Allowance' in content
    assert '## Allowance' in content


def test_mint_connection_token_sends_agent_cli_and_hostname(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """POST /connection-tokens is called with agent='cli' and label=<hostname>."""
    calls: list[dict[str, object]] = []
    hostname = 'test-machine.local'
    responses = _standard_responses(first_name='Alice', last_name='Smith')

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)
    client_factory = _make_client_factory(responses, calls)
    monkeypatch.setattr('allowance_cli.setup_cmd.AllowanceAPIClient', client_factory)
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions', lambda agent: 'stubbed'
    )
    monkeypatch.setattr('allowance_cli.setup_cmd.socket.gethostname', lambda: hostname)

    result = CliRunner().invoke(app, ['setup'], input='4155551234\n')
    assert result.exit_code == 0, result.output

    token_calls = [
        c for c in calls if c['method'] == 'POST' and c['path'] == '/connection-tokens'
    ]
    assert len(token_calls) == 1, f'Expected 1 POST /connection-tokens call, got: {token_calls}'
    body = token_calls[0]['json_body']
    assert isinstance(body, dict)
    assert body.get('agent') == 'cli', f"Expected agent='cli', got: {body}"
    assert body.get('label') == hostname, f"Expected label='{hostname}', got: {body}"


def test_mint_connection_token_label_none_on_hostname_error(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    """When socket.gethostname() raises, label is sent as None (not omitted)."""
    calls: list[dict[str, object]] = []
    responses = _standard_responses(first_name='Bob', last_name='Jones')

    config_dir = tmp_path / '.allowance'
    config_file = config_dir / 'config.json'
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_DIR', config_dir)
    monkeypatch.setattr('allowance_cli.setup_cmd._CONFIG_FILE', config_file)
    client_factory = _make_client_factory(responses, calls)
    monkeypatch.setattr('allowance_cli.setup_cmd.AllowanceAPIClient', client_factory)
    monkeypatch.setattr(
        'allowance_cli.setup_cmd._write_agent_instructions', lambda agent: 'stubbed'
    )
    def _raise_os_error() -> str:
        raise OSError('hostname lookup failed')

    monkeypatch.setattr('allowance_cli.setup_cmd.socket.gethostname', _raise_os_error)

    result = CliRunner().invoke(app, ['setup'], input='4155551234\n')
    assert result.exit_code == 0, result.output

    token_calls = [c for c in calls if c['method'] == 'POST' and c['path'] == '/connection-tokens']
    assert len(token_calls) == 1
    body = token_calls[0]['json_body']
    assert isinstance(body, dict)
    assert body.get('agent') == 'cli'
    assert body.get('label') is None


def test_installed_skill_documents_local_browser_preflight() -> None:
    from allowance_cli.setup_cmd import _CLAUDE_CODE_MD_HINT, _CLAUDE_CODE_SKILL_CONTENT

    assert '## Allowance — Agent Purchase Wallet' in _CLAUDE_CODE_SKILL_CONTENT
    assert '### Local Browser Requirement' in _CLAUDE_CODE_SKILL_CONTENT
    assert 'Before running `allowance request`' in _CLAUDE_CODE_SKILL_CONTENT
    assert 'web search' in _CLAUDE_CODE_SKILL_CONTENT
    assert 'Allowance is the right payment flow' in _CLAUDE_CODE_SKILL_CONTENT
    assert '--local-browser-tool computer-use' in _CLAUDE_CODE_SKILL_CONTENT
    assert 'local browser-capable agent session' in _CLAUDE_CODE_MD_HINT
    assert '--local-browser-tool' in _CLAUDE_CODE_MD_HINT
    assert 'web search' not in _CLAUDE_CODE_MD_HINT
