from __future__ import annotations

import pytest

from allowance_cli.credential_store import (
    SERVICE_NAME,
    CredentialStoreError,
    load_stored_connection_token,
    store_connection_token,
)


class FakeKeyring:
    def __init__(self) -> None:
        self.values: dict[tuple[str, str], str] = {}

    def set_password(self, service_name: str, username: str, password: str) -> None:
        self.values[(service_name, username)] = password

    def get_password(self, service_name: str, username: str) -> str | None:
        return self.values.get((service_name, username))


def test_credential_store_uses_service_and_token_id_account(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = FakeKeyring()
    monkeypatch.setattr('allowance_cli.credential_store._keyring', lambda: fake)

    store_connection_token(token_id='tok_abc', token='ak_secret')

    assert fake.values == {
        (SERVICE_NAME, 'connection-token:tok_abc'): 'ak_secret',
    }
    assert load_stored_connection_token(token_id='tok_abc') == 'ak_secret'


def test_credential_store_wraps_backend_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class BrokenKeyring:
        def set_password(self, service_name: str, username: str, password: str) -> None:
            raise RuntimeError('backend unavailable')

    monkeypatch.setattr('allowance_cli.credential_store._keyring', lambda: BrokenKeyring())

    with pytest.raises(CredentialStoreError, match='OS credential storage'):
        store_connection_token(token_id='tok_abc', token='ak_secret')


def test_credential_store_rejects_successful_noop_backend(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class NoopKeyring:
        def set_password(self, service_name: str, username: str, password: str) -> None:
            return None

        def get_password(self, service_name: str, username: str) -> str | None:
            return None

    monkeypatch.setattr('allowance_cli.credential_store._keyring', lambda: NoopKeyring())

    with pytest.raises(CredentialStoreError, match='did not persist'):
        store_connection_token(token_id='tok_abc', token='ak_secret')
