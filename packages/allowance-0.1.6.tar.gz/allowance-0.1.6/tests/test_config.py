from __future__ import annotations

import json
import pathlib

import pytest

from allowance_cli.credential_store import CredentialStoreError


def test_load_connection_token_env_precedence(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    config_path = tmp_path / '.allowance' / 'config.json'
    config_path.parent.mkdir()
    config_path.write_text(json.dumps({'token_id': 'tok_file'}))
    monkeypatch.setattr('allowance_cli.config.CONFIG_PATH', config_path)
    monkeypatch.setenv('ALLOWANCE_CONNECTION_TOKEN', 'ak_env')
    monkeypatch.setattr(
        'allowance_cli.config.load_stored_connection_token',
        lambda *, token_id: pytest.fail('credential store should not be read'),
    )

    from allowance_cli.config import load_connection_token

    assert load_connection_token() == 'ak_env'


def test_load_connection_token_reads_credential_store(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    config_path = tmp_path / '.allowance' / 'config.json'
    config_path.parent.mkdir()
    config_path.write_text(json.dumps({'token_id': 'tok_abc'}))
    monkeypatch.setattr('allowance_cli.config.CONFIG_PATH', config_path)
    monkeypatch.delenv('ALLOWANCE_CONNECTION_TOKEN', raising=False)
    monkeypatch.setattr(
        'allowance_cli.config.load_stored_connection_token',
        lambda *, token_id: 'ak_secure' if token_id == 'tok_abc' else None,
    )

    from allowance_cli.config import load_connection_token

    assert load_connection_token() == 'ak_secure'


def test_plaintext_config_is_scrubbed_and_ignored(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    config_path = tmp_path / '.allowance' / 'config.json'
    config_path.parent.mkdir()
    config_path.write_text(
        json.dumps(
            {
                'token': 'ak_plaintext',
                'token_id': 'tok_abc',
                'api_base_url': 'https://api-staging.useallowance.com',
            }
        )
    )
    monkeypatch.setattr('allowance_cli.config.CONFIG_PATH', config_path)
    monkeypatch.delenv('ALLOWANCE_CONNECTION_TOKEN', raising=False)
    monkeypatch.setattr(
        'allowance_cli.config.store_connection_token',
        lambda *, token_id, token: pytest.fail('plaintext tokens must not be migrated'),
    )
    monkeypatch.setattr(
        'allowance_cli.config.load_stored_connection_token',
        lambda *, token_id: None,
    )

    from allowance_cli.config import load_connection_token

    assert load_connection_token() is None
    assert json.loads(config_path.read_text()) == {
        'token_id': 'tok_abc',
        'api_base_url': 'https://api-staging.useallowance.com',
    }


def test_save_connection_config_writes_metadata_only(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    config_path = tmp_path / '.allowance' / 'config.json'
    stored: dict[str, str] = {}
    monkeypatch.setattr(
        'allowance_cli.config.store_connection_token',
        lambda *, token_id, token: stored.__setitem__(token_id, token),
    )

    from allowance_cli.config import save_connection_config

    save_connection_config(
        token_id='tok_new',
        token='ak_new',
        api_base_url='https://api.useallowance.com',
        path=config_path,
    )

    assert stored == {'tok_new': 'ak_new'}
    assert json.loads(config_path.read_text()) == {
        'token_id': 'tok_new',
        'api_base_url': 'https://api.useallowance.com',
    }


def test_save_connection_config_failure_does_not_silently_write_plaintext(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: pathlib.Path,
) -> None:
    config_path = tmp_path / '.allowance' / 'config.json'

    def _raise(*, token_id: str, token: str) -> None:
        raise CredentialStoreError('no backend')

    monkeypatch.setattr('allowance_cli.config.store_connection_token', _raise)

    from allowance_cli.config import save_connection_config

    with pytest.raises(CredentialStoreError):
        save_connection_config(
            token_id='tok_new',
            token='ak_new',
            api_base_url='https://api.useallowance.com',
            path=config_path,
        )

    assert not config_path.exists()
