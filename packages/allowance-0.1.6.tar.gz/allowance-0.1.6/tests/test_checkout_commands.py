"""Unit tests for allowance checkout commands (request, identity, address, card, purchase)."""
from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from allowance_cli.api import APIError, APITransportError
from allowance_cli.cli import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _json_output(stdout: str) -> dict[str, Any]:
    lines = [line.strip() for line in stdout.splitlines() if line.strip()]
    assert lines, f'No output found. stdout={stdout!r}'
    return json.loads(lines[-1])  # type: ignore[no-any-return]


def _patch_token(token: str = 'ak_test_checkout_token') -> Any:
    return patch('allowance_cli.checkout.load_connection_token', return_value=token)


def _patch_client(responses: dict[tuple[str, str], Any]) -> Any:
    """Patch AllowanceAPIClient so that GET/POST return canned responses."""

    class FakeClient:
        def __init__(self, *, base_url: str, bearer_token: str | None = None, **_: Any) -> None:
            self.base_url = base_url
            self.bearer_token = bearer_token

        def get(self, path: str, **_: Any) -> Any:
            key = ('GET', path)
            result = responses.get(key)
            if isinstance(result, Exception):
                raise result
            if result is None:
                raise AssertionError(f'Unexpected GET {path}')
            return result

        def post(self, path: str, *, json_body: dict[str, Any] | None = None, **_: Any) -> Any:
            key = ('POST', path)
            result = responses.get(key)
            if isinstance(result, Exception):
                raise result
            if result is None:
                raise AssertionError(f'Unexpected POST {path}')
            return result

    return patch('allowance_cli.checkout._build_checkout_client', side_effect=FakeClient)


# ---------------------------------------------------------------------------
# allowance identity
# ---------------------------------------------------------------------------

def test_identity_human_readable() -> None:
    identity_body = {
        'first_name': 'Ada',
        'last_name': 'Lovelace',
        'email': 'ada@example.com',
        'phone': '+14155551234',
    }
    responses: dict[tuple[str, str], Any] = {
        ('GET', '/auth/checkout-identity'): identity_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, ['identity'])

    assert result.exit_code == 0, result.output
    assert 'Ada' in result.output
    assert 'Lovelace' in result.output
    assert 'ada@example.com' in result.output
    assert '+14155551234' in result.output


def test_identity_json_flag() -> None:
    identity_body = {
        'first_name': 'Ada',
        'last_name': 'Lovelace',
        'email': 'ada@example.com',
        'phone': '+14155551234',
    }
    responses: dict[tuple[str, str], Any] = {
        ('GET', '/auth/checkout-identity'): identity_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, ['identity', '--json'])

    assert result.exit_code == 0, result.output
    payload = _json_output(result.output)
    assert payload['email'] == 'ada@example.com'


def test_identity_no_token() -> None:
    with patch('allowance_cli.checkout.load_connection_token', return_value=None):
        result = runner.invoke(app, ['identity'])

    assert result.exit_code != 0


def test_identity_api_error() -> None:
    responses: dict[tuple[str, str], Any] = {
        ('GET', '/auth/checkout-identity'): APIError(
            status_code=401, body={'detail': 'Unauthorized'}
        ),
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, ['identity'])

    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# allowance address
# ---------------------------------------------------------------------------

def test_address_shipping_human_readable() -> None:
    address_body = {
        'name': 'Ada Lovelace',
        'line1': '123 Main St',
        'city': 'San Francisco',
        'state': 'CA',
        'postal_code': '94105',
        'country': 'US',
    }
    responses: dict[tuple[str, str], Any] = {
        ('GET', '/allowances/allow_123/shipping-address'): address_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, ['address', 'shipping', '--allowance-id', 'allow_123'])

    assert result.exit_code == 0, result.output
    assert 'Shipping address' in result.output
    assert '123 Main St' in result.output
    assert 'San Francisco' in result.output


def test_address_billing_json() -> None:
    address_body = {'line1': '456 Oak Ave', 'city': 'Portland', 'state': 'OR', 'country': 'US'}
    responses: dict[tuple[str, str], Any] = {
        ('GET', '/allowances/allow_456/billing-address'): address_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(
            app, ['address', 'billing', '--allowance-id', 'allow_456', '--json']
        )

    assert result.exit_code == 0, result.output
    payload = _json_output(result.output)
    assert payload['city'] == 'Portland'


def test_address_transport_error() -> None:
    responses: dict[tuple[str, str], Any] = {
        ('GET', '/allowances/allow_789/shipping-address'): APITransportError('timeout'),
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, ['address', 'shipping', '--allowance-id', 'allow_789'])

    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# allowance request
# ---------------------------------------------------------------------------

def test_request_approved_human_readable(monkeypatch: pytest.MonkeyPatch) -> None:
    create_body = {'id': 'req_abc', 'status': 'pending'}
    poll_body = {'status': 'approved', 'allowance_id': 'allow_xyz'}
    call_count = {'n': 0}
    create_payloads: list[dict[str, Any]] = []

    class FakeClient:
        def __init__(self, **_: Any) -> None:
            pass

        def post(self, path: str, *, json_body: dict[str, Any] | None = None, **_: Any) -> Any:
            if path == '/allowance-requests':
                assert json_body is not None
                create_payloads.append(json_body)
                return create_body
            raise AssertionError(f'Unexpected POST {path}')

        def get(self, path: str, **_: Any) -> Any:
            if path == '/allowance-requests/req_abc/poll':
                call_count['n'] += 1
                return poll_body
            raise AssertionError(f'Unexpected GET {path}')

    monkeypatch.setattr('allowance_cli.checkout.load_connection_token',
                        lambda: 'ak_test')
    monkeypatch.setattr('allowance_cli.checkout._build_checkout_client',
                        lambda **_: FakeClient())
    # Speed up tests by making sleep a no-op.
    monkeypatch.setattr('allowance_cli.checkout.time.sleep', lambda _: None)

    result = runner.invoke(app, [
        'request',
        '--merchant', 'Acme',
        '--amount', '1999',
        '--reason', 'office supplies',
        '--url', 'https://www.zara.com/us/',
        '--local-browser-tool', 'computer-use',
        '--no-shipping',
    ])

    assert result.exit_code == 0, result.output
    assert create_payloads == [
        {
            'cents': 1999,
            'currency': 'USD',
            'merchant': 'Acme',
            'reason': 'office supplies',
            'requires_shipping': False,
            'checkout_execution': 'local_browser',
            'local_browser_available': True,
            'local_browser_tool': 'computer-use',
            'merchant_url': 'https://www.zara.com/us/',
        }
    ]
    assert 'Approval link: https://app.useallowance.com/allowance-requests/req_abc' in result.output
    assert 'approved' in result.output.lower()
    assert 'allow_xyz' in result.output


def test_request_requires_local_browser_tool_before_token_or_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        'allowance_cli.checkout.load_connection_token',
        lambda: pytest.fail('token should not be loaded before browser preflight'),
    )
    monkeypatch.setattr(
        'allowance_cli.checkout._build_checkout_client',
        lambda **_: pytest.fail('API client should not be created'),
    )

    result = runner.invoke(app, [
        'request', '--merchant', 'Acme', '--amount', '500', '--reason', 'test',
    ])

    assert result.exit_code != 0
    assert 'Allowance CLI purchases require active local browser control.' in result.output
    assert '--local-browser-tool computer-use' in result.output


def test_request_rejects_invalid_local_browser_tool_before_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        'allowance_cli.checkout.load_connection_token',
        lambda: pytest.fail('token should not be loaded before browser preflight'),
    )
    monkeypatch.setattr(
        'allowance_cli.checkout._build_checkout_client',
        lambda **_: pytest.fail('API client should not be created'),
    )

    result = runner.invoke(app, [
        'request',
        '--merchant', 'Acme',
        '--amount', '500',
        '--reason', 'test',
        '--local-browser-tool', 'web-search',
    ])

    assert result.exit_code != 0
    assert 'Invalid --local-browser-tool value: web-search' in result.output
    assert 'browser-tool' in result.output
    assert 'computer-use' in result.output
    assert 'chrome-extension' in result.output
    assert 'other-browser-control' in result.output


def test_request_missing_local_browser_tool_json_error_before_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        'allowance_cli.checkout.load_connection_token',
        lambda: pytest.fail('token should not be loaded before browser preflight'),
    )
    monkeypatch.setattr(
        'allowance_cli.checkout._build_checkout_client',
        lambda **_: pytest.fail('API client should not be created'),
    )

    result = runner.invoke(app, [
        'request', '--merchant', 'Acme', '--amount', '500', '--reason', 'test', '--json',
    ])

    assert result.exit_code != 0
    payload = json.loads(result.stderr)
    assert payload["ok"] is False
    assert payload["error"] == "local_browser_tool_required"
    assert payload["valid_values"] == [
        "browser-tool",
        "computer-use",
        "chrome-extension",
        "other-browser-control",
    ]


def test_request_invalid_local_browser_tool_json_error_before_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        'allowance_cli.checkout.load_connection_token',
        lambda: pytest.fail('token should not be loaded before browser preflight'),
    )
    monkeypatch.setattr(
        'allowance_cli.checkout._build_checkout_client',
        lambda **_: pytest.fail('API client should not be created'),
    )

    result = runner.invoke(app, [
        'request',
        '--merchant', 'Acme',
        '--amount', '500',
        '--reason', 'test',
        '--local-browser-tool', 'web-search',
        '--json',
    ])

    assert result.exit_code != 0
    payload = json.loads(result.stderr)
    assert payload["ok"] is False
    assert payload["error"] == "invalid_local_browser_tool"
    assert "web-search" in payload["message"]


def test_request_denied_exits_nonzero(monkeypatch: pytest.MonkeyPatch) -> None:
    create_body = {'id': 'req_denied', 'status': 'pending'}
    poll_body = {'status': 'denied', 'allowance_id': None}

    class FakeClient:
        def __init__(self, **_: Any) -> None:
            pass

        def post(self, path: str, **_: Any) -> Any:
            if path == '/allowance-requests':
                return create_body
            raise AssertionError(f'Unexpected POST {path}')

        def get(self, path: str, **_: Any) -> Any:
            if '/poll' in path:
                return poll_body
            raise AssertionError(f'Unexpected GET {path}')

    monkeypatch.setattr('allowance_cli.checkout.load_connection_token', lambda: 'ak_test')
    monkeypatch.setattr('allowance_cli.checkout._build_checkout_client', lambda **_: FakeClient())
    monkeypatch.setattr('allowance_cli.checkout.time.sleep', lambda _: None)

    result = runner.invoke(app, [
        'request',
        '--merchant', 'Acme',
        '--amount', '500',
        '--reason', 'test',
        '--local-browser-tool', 'browser-tool',
        '--no-shipping',
    ])

    assert result.exit_code != 0
    assert 'denied' in result.output.lower()


def test_request_timeout_exits_nonzero(monkeypatch: pytest.MonkeyPatch) -> None:
    create_body = {'id': 'req_timeout', 'status': 'pending'}
    poll_body = {'status': 'pending'}

    # Return a large value immediately so deadline is always exceeded.
    call_count: dict[str, int] = {'n': 0}

    def fake_monotonic() -> float:
        call_count['n'] += 1
        # First call sets deadline (start=0), subsequent calls are past it.
        return 0.0 if call_count['n'] == 1 else 9999.0

    class FakeClient:
        def __init__(self, **_: Any) -> None:
            pass

        def post(self, path: str, **_: Any) -> Any:
            if path == '/allowance-requests':
                return create_body
            raise AssertionError(f'Unexpected POST {path}')

        def get(self, path: str, **_: Any) -> Any:
            if '/poll' in path:
                return poll_body
            raise AssertionError(f'Unexpected GET {path}')

    monkeypatch.setattr('allowance_cli.checkout.load_connection_token', lambda: 'ak_test')
    monkeypatch.setattr('allowance_cli.checkout._build_checkout_client', lambda **_: FakeClient())
    monkeypatch.setattr('allowance_cli.checkout.time.monotonic', fake_monotonic)
    monkeypatch.setattr('allowance_cli.checkout.time.sleep', lambda _: None)

    result = runner.invoke(app, [
        'request',
        '--merchant', 'Acme',
        '--amount', '500',
        '--reason', 'test',
        '--local-browser-tool', 'browser-tool',
        '--no-shipping',
    ])

    assert result.exit_code != 0


def test_request_json_output_on_approval(monkeypatch: pytest.MonkeyPatch) -> None:
    create_body = {'id': 'req_json', 'status': 'pending'}
    poll_body = {'status': 'approved', 'allowance_id': 'allow_json'}

    class FakeClient:
        def __init__(self, **_: Any) -> None:
            pass

        def post(self, path: str, **_: Any) -> Any:
            if path == '/allowance-requests':
                return create_body
            raise AssertionError(f'Unexpected POST {path}')

        def get(self, path: str, **_: Any) -> Any:
            if '/poll' in path:
                return poll_body
            raise AssertionError(f'Unexpected GET {path}')

    monkeypatch.setattr('allowance_cli.checkout.load_connection_token', lambda: 'ak_test')
    monkeypatch.setattr('allowance_cli.checkout._build_checkout_client', lambda **_: FakeClient())
    monkeypatch.setattr('allowance_cli.checkout.time.sleep', lambda _: None)

    result = runner.invoke(app, [
        'request', '--merchant', 'Acme', '--amount', '100', '--reason', 'test',
        '--local-browser-tool', 'browser-tool', '--no-shipping', '--json',
    ])

    assert result.exit_code == 0, result.output
    # In --json mode stdout must be a single parseable JSON object (the final approved state).
    # The intermediate "created" phase is emitted to stderr, not stdout.
    payload = _json_output(result.output)
    assert payload.get('status') == 'approved'
    assert payload.get('allowance_id') == 'allow_json'


# ---------------------------------------------------------------------------
# allowance card issue
# ---------------------------------------------------------------------------

def test_card_issue_prints_card_details(monkeypatch: pytest.MonkeyPatch) -> None:
    card_body = {
        'id': 'attempt_001',
        'status': 'active',
        'card': {
            'number': '4111111111111111',
            'expiry': '12/26',
            'cvv': '123',
        },
    }
    responses: dict[tuple[str, str], Any] = {
        ('POST', '/allowances/allow_abc/purchase-attempts/issue-card'): card_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, [
            'card', 'issue',
            '--allowance-id', 'allow_abc',
            '--amount', '1999',
            '--merchant', 'Acme Store',
        ])

    assert result.exit_code == 0, result.output
    assert 'SENSITIVE' in result.output
    assert '4111' in result.output
    assert '12/26' in result.output
    assert '123' in result.output
    assert 'attempt_001' in result.output


def test_card_issue_json_flag(monkeypatch: pytest.MonkeyPatch) -> None:
    card_body = {
        'id': 'attempt_json',
        'status': 'active',
        'card': {'number': '4222222222222222', 'expiry': '06/27', 'cvv': '456'},
    }
    responses: dict[tuple[str, str], Any] = {
        ('POST', '/allowances/allow_json/purchase-attempts/issue-card'): card_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, [
            'card', 'issue',
            '--allowance-id', 'allow_json',
            '--amount', '500',
            '--merchant', 'JSON Store',
            '--json',
        ])

    assert result.exit_code == 0, result.output
    payload = _json_output(result.output)
    assert payload['id'] == 'attempt_json'


def test_card_issue_pending_auth_polls(monkeypatch: pytest.MonkeyPatch) -> None:
    """When issue-card returns pending_auth, the CLI should poll complete-auth."""
    pending_body = {'id': 'attempt_auth', 'status': 'pending_auth'}
    auth_complete_body = {
        'id': 'attempt_auth',
        'status': 'active',
        'card': {'number': '4333333333333333', 'expiry': '01/28', 'cvv': '789'},
    }
    poll_count = {'n': 0}

    class FakeClient:
        def __init__(self, **_: Any) -> None:
            pass

        def post(self, path: str, **_: Any) -> Any:
            if 'issue-card' in path:
                return pending_body
            if 'complete-auth' in path:
                poll_count['n'] += 1
                if poll_count['n'] >= 2:
                    return auth_complete_body
                return {'id': 'attempt_auth', 'status': 'pending_auth'}
            raise AssertionError(f'Unexpected POST {path}')

    monkeypatch.setattr('allowance_cli.checkout.load_connection_token', lambda: 'ak_test')
    monkeypatch.setattr('allowance_cli.checkout._build_checkout_client', lambda **_: FakeClient())
    monkeypatch.setattr('allowance_cli.checkout.time.sleep', lambda _: None)

    result = runner.invoke(app, [
        'card', 'issue',
        '--allowance-id', 'allow_auth',
        '--amount', '2500',
        '--merchant', 'Auth Store',
    ])

    assert result.exit_code == 0, result.output
    assert 'SENSITIVE' in result.output
    assert '4333' in result.output
    assert poll_count['n'] >= 2


# ---------------------------------------------------------------------------
# allowance purchase success
# ---------------------------------------------------------------------------

def test_purchase_success_human_readable() -> None:
    result_body = {'ok': True, 'status': 'success'}
    responses: dict[tuple[str, str], Any] = {
        ('POST', '/allowances/allow_s/purchase-attempts/att_s/result'): result_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, [
            'purchase', 'success',
            '--allowance-id', 'allow_s',
            '--attempt-id', 'att_s',
            '--charged', '1999',
        ])

    assert result.exit_code == 0, result.output
    assert 'successful' in result.output.lower() or '✓' in result.output


def test_purchase_success_json() -> None:
    result_body = {'ok': True, 'status': 'success'}
    responses: dict[tuple[str, str], Any] = {
        ('POST', '/allowances/allow_sj/purchase-attempts/att_sj/result'): result_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, [
            'purchase', 'success',
            '--allowance-id', 'allow_sj',
            '--attempt-id', 'att_sj',
            '--charged', '500',
            '--json',
        ])

    assert result.exit_code == 0, result.output
    payload = _json_output(result.output)
    assert payload.get('ok') is True


# ---------------------------------------------------------------------------
# allowance purchase failure
# ---------------------------------------------------------------------------

def test_purchase_failure_valid_error_code() -> None:
    result_body = {'ok': True}
    responses: dict[tuple[str, str], Any] = {
        ('POST', '/allowances/allow_f/purchase-attempts/att_f/result'): result_body,
    }

    with _patch_token(), _patch_client(responses):
        result = runner.invoke(app, [
            'purchase', 'failure',
            '--allowance-id', 'allow_f',
            '--attempt-id', 'att_f',
            '--error-code', 'card_declined',
        ])

    assert result.exit_code == 0, result.output
    assert 'card_declined' in result.output


def test_purchase_failure_invalid_error_code() -> None:
    with _patch_token():
        result = runner.invoke(app, [
            'purchase', 'failure',
            '--allowance-id', 'allow_f',
            '--attempt-id', 'att_f',
            '--error-code', 'totally_invalid_code',
        ])

    assert result.exit_code != 0


def test_purchase_failure_all_valid_codes() -> None:
    valid_codes = [
        'card_declined', 'card_declined_avs', 'card_declined_cvv',
        'checkout_abandoned', 'checkout_error', 'checkout_timeout',
        'item_unavailable', 'price_mismatch', 'merchant_rejected', 'unsupported_card',
    ]
    for code in valid_codes:
        result_body = {'ok': True}
        responses: dict[tuple[str, str], Any] = {
            ('POST', '/allowances/a/purchase-attempts/b/result'): result_body,
        }
        with _patch_token(), _patch_client(responses):
            result = runner.invoke(app, [
                'purchase', 'failure',
                '--allowance-id', 'a',
                '--attempt-id', 'b',
                '--error-code', code,
            ])
        assert result.exit_code == 0, (
            f'Expected 0 for code {code!r}, got {result.exit_code}. '
            f'Output: {result.output}'
        )
