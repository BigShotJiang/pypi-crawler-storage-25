"""Trend line support for Tableau worksheets.

Writes <trendline> XML elements inside each <pane> of the worksheet's
<panes> element, per the Tableau XSD schema (PaneSpecification-Trendline-G).
Supports linear, polynomial, logarithmic, exponential, and power fits.
"""

from __future__ import annotations

from lxml import etree

_VALID_FIT_TYPES = {"linear", "polynomial", "log", "exp", "power"}


class TrendLineMixin:
    """Mixin providing trend line capabilities to TWBEditor."""

    def add_trend_line(
        self,
        worksheet_name: str,
        fit: str = "linear",
        degree: int = 2,
        show_confidence_bands: bool = False,
        exclude_color: bool = False,
    ) -> str:
        """Add a trend line to a worksheet.

        Args:
            worksheet_name: Target worksheet name.
            fit: Fit type: "linear", "polynomial", "log", "exp", "power".
            degree: Polynomial degree (only used when fit="polynomial").
            show_confidence_bands: Show confidence bands around the trend.
            exclude_color: If True, don't split trend by color encoding.

        Returns:
            Confirmation message.
        """
        if fit not in _VALID_FIT_TYPES:
            raise ValueError(
                f"Unknown fit type '{fit}'. Valid: {', '.join(sorted(_VALID_FIT_TYPES))}"
            )

        ws = self._find_worksheet(worksheet_name)
        table = ws.find("table")
        if table is None:
            raise ValueError(f"Worksheet '{worksheet_name}' has no <table> element")

        panes = table.find("panes")
        if panes is None:
            raise ValueError(f"Worksheet '{worksheet_name}' has no <panes> element")

        pane_list = panes.findall("pane")
        if not pane_list:
            raise ValueError(f"Worksheet '{worksheet_name}' has no <pane> elements")

        count = 0
        for pane in pane_list:
            # Remove existing trendline in this pane
            for old in pane.findall("trendline"):
                pane.remove(old)

            tl = etree.Element("trendline")
            tl.set("enabled", "true")
            tl.set("fit", fit)
            tl.set("exclude-intercept", "false")
            tl.set("enable-confidence-bands", str(show_confidence_bands).lower())
            tl.set("exclude-color", str(exclude_color).lower())
            tl.set("enable-instant-analytics", "true")
            tl.set("enable-tooltips", "true")

            if fit == "polynomial":
                tl.set("degree", str(degree))

            # Insert trendline after style/encodings but before reference-line
            # per XSD ordering: ...DropLine → Trendline → ReferenceLine...
            insert_idx = len(pane)
            for i, child in enumerate(pane):
                if child.tag in ("reference-line", "customized-tooltip",
                                 "customized-label", "style-rule"):
                    insert_idx = i
                    break
            pane.insert(insert_idx, tl)

            count += 1

        return f"Added {fit} trend line to '{worksheet_name}' ({count} pane(s))"

    def remove_trend_line(self, worksheet_name: str) -> str:
        """Remove trend lines from a worksheet."""
        ws = self._find_worksheet(worksheet_name)
        table = ws.find("table")
        if table is None:
            return f"No table in worksheet '{worksheet_name}'"

        panes = table.find("panes")
        if panes is None:
            return f"No panes in worksheet '{worksheet_name}'"

        removed = 0
        for pane in panes.findall("pane"):
            for tl in pane.findall("trendline"):
                pane.remove(tl)
                removed += 1

        if removed == 0:
            return f"No trend line found in '{worksheet_name}'"
        return f"Removed {removed} trend line(s) from '{worksheet_name}'"
