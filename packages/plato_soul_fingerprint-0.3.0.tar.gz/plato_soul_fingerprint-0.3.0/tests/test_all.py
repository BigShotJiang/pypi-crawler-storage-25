"""Tests for plato-soul-fingerprint."""

import os
import sys
import json
import tempfile
import subprocess
import unittest
import shutil

import numpy as np

# Ensure package is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from plato_soul_fingerprint.reduction import StandardScaler, PCA, scree_report
from plato_soul_fingerprint.analysis import cosine_distance, soul_cluster, soul_report, soul_compare
from plato_soul_fingerprint.extractor import SoulExtractor
from plato_soul_fingerprint.features.temporal import extract_temporal_features
from plato_soul_fingerprint.features.stylistic import extract_stylistic_features
from plato_soul_fingerprint.features.structural import extract_structural_features
from plato_soul_fingerprint.features.dependency import extract_dependency_features
from plato_soul_fingerprint.features.communication import extract_communication_features
from plato_soul_fingerprint.features.philosophical import extract_philosophical_features


class _RepoMixin:
    """Helper to create a fake git repo."""

    def make_repo(self, name="testrepo") -> str:
        tmp = tempfile.mkdtemp(prefix=name + "_")
        subprocess.run(["git", "init"], cwd=tmp, check=True, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp, check=True, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test User"], cwd=tmp, check=True, capture_output=True)
        # Create a Python file and commit
        with open(os.path.join(tmp, "main.py"), "w") as f:
            f.write("def hello_world():\n    pass\n")
        subprocess.run(["git", "add", "."], cwd=tmp, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "feat: initial commit"], cwd=tmp, check=True, capture_output=True)
        # Second commit
        with open(os.path.join(tmp, "utils.py"), "w") as f:
            f.write("def helper(x: int) -> int:\n    return x + 1\n")
        subprocess.run(["git", "add", "."], cwd=tmp, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "add utils module"], cwd=tmp, check=True, capture_output=True)
        return tmp


class TestReduction(unittest.TestCase):
    def test_standard_scaler(self):
        X = np.array([[1, 2], [3, 4], [5, 6]], dtype=float)
        scaler = StandardScaler()
        Z = scaler.fit_transform(X)
        self.assertAlmostEqual(np.mean(Z[:, 0]), 0.0, places=6)
        self.assertAlmostEqual(np.std(Z[:, 0]), 1.0, places=6)

    def test_pca_variance(self):
        rng = np.random.RandomState(42)
        X = rng.randn(100, 5)
        pca = PCA(variance_threshold=0.95)
        Z = pca.fit_transform(X)
        self.assertGreaterEqual(pca.n_components_, 1)
        self.assertLessEqual(pca.n_components_, 5)
        cumsum = np.cumsum(pca.explained_variance_ratio_)
        self.assertGreaterEqual(cumsum[pca.n_components_ - 1], 0.95)

    def test_scree_report(self):
        rng = np.random.RandomState(0)
        X = rng.randn(50, 4)
        pca = PCA(variance_threshold=0.95)
        pca.fit(X)
        report = scree_report(pca)
        self.assertIn("Scree Plot", report)


class TestAnalysis(unittest.TestCase):
    def test_cosine_distance_identical(self):
        a = {"pca_vector": [1.0, 2.0, 3.0]}
        b = {"pca_vector": [1.0, 2.0, 3.0]}
        self.assertAlmostEqual(cosine_distance(a, b), 0.0, places=6)

    def test_cosine_distance_orthogonal(self):
        a = {"pca_vector": [1.0, 0.0, 0.0]}
        b = {"pca_vector": [0.0, 1.0, 0.0]}
        self.assertAlmostEqual(cosine_distance(a, b), 1.0, places=6)

    def test_soul_cluster(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            for i, vec in enumerate([[1, 0], [0.9, 0.1], [0, 1]]):
                path = os.path.join(tmpdir, f"repo{i}.soul.json")
                with open(path, "w") as f:
                    json.dump({
                        "metadata": {"repo_name": f"repo{i}"},
                        "pca_vector": vec,
                        "raw_features": {"a": vec[0], "b": vec[1]},
                    }, f)
            paths = [os.path.join(tmpdir, f"repo{i}.soul.json") for i in range(3)]
            result = soul_cluster(paths)
            self.assertEqual(result["n_repos"], 3)
            self.assertTrue(len(result["linkage"]) > 0)

    def test_soul_report_and_compare(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            a_path = os.path.join(tmpdir, "a.soul.json")
            b_path = os.path.join(tmpdir, "b.soul.json")
            with open(a_path, "w") as f:
                json.dump({
                    "metadata": {"repo_name": "A", "primary_language": "python", "commit_count": 10},
                    "raw_features": {"x": 1.0, "y": 2.0},
                    "pca_vector": [1.0, 0.0],
                }, f)
            with open(b_path, "w") as f:
                json.dump({
                    "metadata": {"repo_name": "B", "primary_language": "rust", "commit_count": 5},
                    "raw_features": {"x": 3.0, "y": 0.5},
                    "pca_vector": [0.0, 1.0],
                }, f)
            report = soul_report(a_path)
            self.assertIn("SOUL REPORT", report)
            comp = soul_compare(a_path, b_path)
            self.assertIn("SOUL COMPARISON", comp)


class TestFeatures(_RepoMixin, unittest.TestCase):
    def test_temporal(self):
        repo = self.make_repo()
        try:
            f = extract_temporal_features(repo)
            self.assertIn("commit_frequency", f)
            self.assertIn("commit_burstiness", f)
            self.assertGreaterEqual(f["commit_frequency"], 0.0)
        finally:
            shutil.rmtree(repo)

    def test_stylistic(self):
        repo = self.make_repo()
        try:
            f = extract_stylistic_features(repo)
            self.assertIn("function_length_mean", f)
            self.assertIn("doc_comment_frequency", f)
            self.assertGreaterEqual(f["doc_comment_frequency"], 0.0)
        finally:
            shutil.rmtree(repo)

    def test_structural(self):
        repo = self.make_repo()
        try:
            f = extract_structural_features(repo)
            self.assertIn("test_ratio", f)
            self.assertIn("directory_depth_mean", f)
        finally:
            shutil.rmtree(repo)

    def test_dependency(self):
        repo = self.make_repo()
        try:
            f = extract_dependency_features(repo)
            self.assertIn("dep_count", f)
            self.assertIn("dep_overlap", f)
        finally:
            shutil.rmtree(repo)

    def test_communication(self):
        repo = self.make_repo()
        try:
            f = extract_communication_features(repo)
            self.assertIn("msg_length_mean", f)
            self.assertIn("conventional_commit_score", f)
            self.assertIn("imperative_verb_frequency", f)
        finally:
            shutil.rmtree(repo)

    def test_philosophical(self):
        repo = self.make_repo()
        try:
            f = extract_philosophical_features(repo)
            self.assertIn("vocabulary_richness", f)
            self.assertIn("metaphor_density", f)
        finally:
            shutil.rmtree(repo)


class TestExtractor(_RepoMixin, unittest.TestCase):
    def test_extract_raw(self):
        repo = self.make_repo()
        try:
            ex = SoulExtractor()
            data = ex.extract(repo)
            self.assertIn("metadata", data)
            self.assertIn("raw_features", data)
            self.assertEqual(data["metadata"]["repo_name"], os.path.basename(repo))
        finally:
            shutil.rmtree(repo)

    def test_fit_transform_and_write(self):
        repo = self.make_repo()
        try:
            ex = SoulExtractor()
            ex.fit([repo])
            raw = ex.extract(repo)
            reduced = ex.transform(raw)
            self.assertIn("pca_vector", reduced)
            with tempfile.TemporaryDirectory() as outdir:
                json_path, txt_path = ex.write(reduced, output_dir=outdir)
                self.assertTrue(os.path.exists(json_path))
                self.assertTrue(os.path.exists(txt_path))
                with open(json_path) as f:
                    loaded = json.load(f)
                self.assertIn("pca_vector", loaded)
        finally:
            shutil.rmtree(repo)


class TestCLI(_RepoMixin, unittest.TestCase):
    def test_cli_extract(self):
        repo = self.make_repo()
        try:
            from plato_soul_fingerprint.cli import main
            import io
            from contextlib import redirect_stdout

            out = io.StringIO()
            with redirect_stdout(out):
                sys.argv = ["plato-soul-fingerprint", "extract", repo]
                main()
            stdout = out.getvalue()
            self.assertIn("Wrote", stdout)
        finally:
            shutil.rmtree(repo)


if __name__ == "__main__":
    unittest.main()
