from setuptools import setup, find_packages

setup(
    name="plato-soul-fingerprint",
    version="0.1.0",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=["numpy>=1.20.0"],
    entry_points={
        "console_scripts": [
            "plato-soul-fingerprint=plato_soul_fingerprint.cli:main",
        ],
    },
    python_requires=">=3.8",
)
