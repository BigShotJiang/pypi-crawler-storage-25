import asyncio
import fnmatch
import os
from pathlib import Path


import signal
import sys

from pydantic import BaseModel,Field
from tiaga.tools_manager.base import Tool, Tool_kind, ToolInvocation, ToolResult


BLOCKED_PATTERNS = {
    # File destruction
    "rm -rf",
    "rm -r /",
    "unlink",
    "shred",
    "wipe",
    
    # Disk / filesystem damage
    "dd ",
    "mkfs",
    "fsck",
    "fdisk",
    "parted",
    "mount",
    "umount",
    
    # Permission abuse
    "chmod 777",
    "chmod -R 777",
    "chown",
    
    # System control
    "shutdown",
    "reboot",
    "halt",
    "poweroff",
    "init 0",
    "init 6",
    
    # Fork bomb
    ":(){",
    
    # Privilege escalation
    "sudo",
    "su ",
    
    # Network abuse / remote execution
    "curl ",
    "wget ",
    "nc ",
    "netcat",
    "ssh ",
    
    # Process killing
    "kill -9",
    "pkill",
    "killall",
    
    # Dangerous writes
    "> /dev/sda",
    "> /dev/null",
    
    # Environment damage
    "export PATH=",
    "rm -rf /", "rm -rf ~", "rm -rf /*", "dd if=/dev/zero", "dd if=/dev/random", "mkfs", "fdisk", "parted", ":(){ :|:& };:",   "chmod 777 /", "chmod -R 777", "shutdown", "reboot", "halt", "poweroff", "init 0", "init 6",
}


class ShellParams(BaseModel):
    command:str = Field(...,description="The shell command to execute")
    timeout:int = Field(120,ge=1,le=600,description="Timeout in second(default is 120)")
    cwd:str|None = Field(None,description="working directory for the command")

class ShellTool(Tool):
    name = "shell"
    tool_kind = Tool_kind.SHELL
    description = "Execute a shell command. Use this for running system commands, scripts and CLI tools."
    MAX_DISPLAY_OUTPUT_BYTES = 100 * 1024

    schema = ShellParams

    def _build_environment(self)->dict[str,str]:
        env = os.environ.copy()

        shell_environment =  self.config.shell_environment

        if not shell_environment.ignore_default_excludes:
            for pattern in shell_environment.excludes_patterns:
                keys_to_remove = [key for key in env.keys() if fnmatch.fnmatch(key.upper(),pattern.upper())]
                
                for k in keys_to_remove :
                    del env[k]

        if shell_environment.set_vars:
            env.update(shell_environment.set_vars)

        return env

    async def execute(self, invocation:ToolInvocation)->ToolResult:
        params = ShellParams(**invocation.params)


        command = params.command.lower().strip()
        for blocked in BLOCKED_PATTERNS:
            if blocked in command:
                return ToolResult.error_result(
                    f"Command blocked for the safty :{params.command}",
                    metadata={
                        "blocked":True
                    }
                )
        if params.cwd:
            cwd = Path(params.cwd)
            if not cwd.is_absolute():
                cwd = invocation.cwd/cwd
        else:
            cwd = invocation.cwd
        if not cwd.exists() :
            return ToolResult.error_result(f"Working directory does not exits: {cwd}")
        
        env = self._build_environment()

        if sys.platform == "win32":
            shell_cmd = ['cmd.exe','/c',params.command]
        else :
            shell_cmd = ['/bin/bash',"-c",params.command]

        process = await asyncio.create_subprocess_exec(*shell_cmd,
                                                       stdout=asyncio.subprocess.PIPE,
                                                       stderr=asyncio.subprocess.PIPE,
                                                       cwd=cwd,
                                                       env=env,
                                                       start_new_session=True)
        try:
            stdout_data,stderr_data = await asyncio.wait_for(process.communicate(),timeout=params.timeout)
        except asyncio.TimeoutError as e :
            if sys.platform != "win32":
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                except (ProcessLookupError, OSError):
                    pass  # Process already terminated
            else :
                process.kill()
            await process.wait()
            return ToolResult.error_result(f"Command timed out after {params.timeout}s")
        
        except asyncio.CancelledError:       
            if sys.platform != "win32":
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            else:
                process.kill()
                await process.wait()
                raise      
        stdout = stdout_data.decode("utf-8",errors="replace")
        stderr = stderr_data.decode("utf-8",errors="replace")
        exit_code  = process.returncode
        output = ""
        if stdout.strip():
            output += stdout.rstrip()

        if stderr.strip():
            output += "\n-----stderror-----\n"
            output += stderr.rstrip()

        if exit_code != 0:
            output +=f"\nexit code  {exit_code}"

        display_output = None
        is_truncated = False
        if len(output) > self.MAX_DISPLAY_OUTPUT_BYTES:
            display_output = (
                output[: self.MAX_DISPLAY_OUTPUT_BYTES] + "\n... [output truncated for display]"
            )
            is_truncated = True

        return ToolResult(success=exit_code == 0,
            output=output,
            error=stderr if exit_code != 0 else None,
            display_output=display_output,
            truncated=is_truncated,
            exit_code=exit_code,
        )


        
