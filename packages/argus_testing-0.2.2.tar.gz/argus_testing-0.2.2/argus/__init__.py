"""Argus — AI-powered exploratory QA agent."""

__version__ = "0.2.2"
