from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    README = f.read()

setup(
    name="wewlott",
    version="1.0",
    packages=find_packages(),
    install_requiresk=[
        "kivy>=2.1.0",
        "requests",
        "certifi",
        "urllib3"
    ],
    description="wewlot: İşlevsel ve kolaylaştırılmış Python Database kütüphanesi",
    long_description=README,
    long_description_content_type="text/markdown",
    author="Bedirhan",
    author_email="bedirhan.oytpass@gmail.com",
    license="MIT",
    keywords=["Kolay kod", "files", "basitleştirilmiş"],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10"
    ],
)
