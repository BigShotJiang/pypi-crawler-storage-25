import socket
import http.server
import socketserver
import os
import base64
import requests  # Yeni eklendi
from kivy.app import App

# --- DOSYA YOLU YARDIMCISI ---

def _get_secure_path():
    """Uygulamanın özel veri dizininde gizli bir klasör yolu döndürür."""
    try:
        base_path = App.get_running_app().user_data_dir
    except:
        base_path = os.getcwd()

    folder_name = ".wew_data_storage"
    full_path = os.path.join(base_path, folder_name)

    if not os.path.exists(full_path):
        os.makedirs(full_path, exist_ok=True)
    
    return full_path

# --- ŞİFRELEME YARDIMCILARI ---

def _sifrele(metin):
    """Metni Base64 ile okunamaz hale getirir."""
    return base64.b64encode(metin.encode('utf-8')).decode('utf-8')

def _sifre_coz(sifreli_metin):
    """Şifrelenmiş metni orijinal haline döndürür."""
    try:
        if not sifreli_metin: return ""
        return base64.b64decode(sifreli_metin.encode('utf-8')).decode('utf-8')
    except:
        return ""

def _update_control(control_list, result):
    """İşlem sonucunu (True/False) belirtilen listeye ekler."""
    if control_list is not None and isinstance(control_list, list):
        control_list.append(result)

# --- GOOGLE DRIVE YEDEKLEME SİSTEMİ (Wlot) ---

class Wlot:
    @staticmethod
    def Go(dosya_adi, control=None):
        """Dosyayı belirtilen Google Drive hesabına yedekler."""
        try:
            # Apps Script'ten aldığın URL'yi buraya yapıştır
            SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzE31_btscdh25m85fa7qulIl2DIq0ZayT_ecw4ofSkIB2wZY3SPV2aquwNtN9XqKc0qg/exec"
            
            path = _get_secure_path()
            # Senin sistemin .txt kullandığı için uzantıyı otomatik ekliyoruz
            tam_dosya_yolu = os.path.join(path, f"{dosya_adi}.txt")
            
            if not os.path.exists(tam_dosya_yolu):
                _update_control(control, False)
                return

            # Dosyayı oku ve gönderime hazırla
            with open(tam_dosya_yolu, "rb") as f:
                dosya_icerigi = f.read()
                # Güvenli transfer için base64 (zaten şifreli ama paketleme için gerekli)
                encoded_content = base64.b64encode(dosya_icerigi).decode('utf-8')

            payload = {
                "filename": f"{dosya_adi}_backup.txt",
                "content": encoded_content
            }

            # Veriyi gönder
            response = requests.post(SCRIPT_URL, json=payload, timeout=15)

            if response.status_code == 200:
                _update_control(control, True)
            else:
                _update_control(control, False)

        except Exception as e:
            print(f"Wlot Hatası: {e}")
            _update_control(control, False)

# --- VERİTABANI FONKSİYONLARI ---

def wewlot_database(dosya_adi, control=None):
    """Veritabanı dosyasını gizli klasörde şifreli bir yapıyla oluşturur."""
    try:
        path = _get_secure_path()
        tam_dosya_adi = os.path.join(path, f"{dosya_adi}.txt")
        
        if not os.path.exists(tam_dosya_adi):
            baslangic_icerik = "[\n]\n"
            with open(tam_dosya_adi, "w", encoding="utf-8") as dosya:
                dosya.write(_sifrele(baslangic_icerik))
        _update_control(control, True)
    except:
        _update_control(control, False)

def wew_data_give(dosya_adi, veri_sozlugu, control=None):
    """Ana ID kaydını oluşturur ve dosyayı şifreleyerek kaydeder."""
    try:
        path = _get_secure_path()
        tam_dosya_adi = os.path.join(path, f"{dosya_adi}.txt")
        
        aranan_id = str(veri_sozlugu['data_id'])
        yeni_satir = f"-{veri_sozlugu['data']} = {aranan_id}\n"
        
        with open(tam_dosya_adi, "r", encoding="utf-8") as f:
            mevcut_icerik = _sifre_coz(f.read())
        
        if f"= {aranan_id}" in mevcut_icerik:
            _update_control(control, False)
            return

        satirlar = mevcut_icerik.splitlines(keepends=True)
        for i in range(len(satirlar)-1, -1, -1):
            if satirlar[i].strip() == "]":
                satirlar.insert(i, yeni_satir)
                break
        
        with open(tam_dosya_adi, "w", encoding="utf-8") as f:
            f.write(_sifrele("".join(satirlar)))
        _update_control(control, True)
    except:
        _update_control(control, False)

def wew_data_add(dosya_adi, hedef_id, ek_veri, control=None):
    """Belirtilen ID altına yeni veri ekler."""
    try:
        path = _get_secure_path()
        tam_dosya_adi = os.path.join(path, f"{dosya_adi}.txt")
        
        aranan_name = f"{ek_veri['name']} ="
        yeni_bilgi = f"{ek_veri['name']} = {ek_veri['data']}\n"
        
        with open(tam_dosya_adi, "r", encoding="utf-8") as f:
            mevcut_icerik = _sifre_coz(f.read())
        
        satirlar = mevcut_icerik.splitlines(keepends=True)
        yeni_icerik_listesi = []
        id_bulundu = False
        veri_eklendi = False

        for i in range(len(satirlar)):
            yeni_icerik_listesi.append(satirlar[i])
            if f"= {hedef_id}" in satirlar[i]:
                id_bulundu = True
                var_mi = False
                for j in range(i + 1, len(satirlar)):
                    if satirlar[j].startswith("-") or satirlar[j].strip() == "]": break
                    if aranan_name in satirlar[j]:
                        var_mi = True; break
                if not var_mi: 
                    yeni_icerik_listesi.append(yeni_bilgi)
                    veri_eklendi = True

        if id_bulundu and veri_eklendi:
            with open(tam_dosya_adi, "w", encoding="utf-8") as f:
                f.write(_sifrele("".join(yeni_icerik_listesi)))
            _update_control(control, True)
        else:
            _update_control(control, False)
    except:
        _update_control(control, False)

def wew_data_update(dosya_adi, hedef_id, guncel_veri, control=None):
    """Şifreli dosya içindeki veriyi günceller."""
    try:
        path = _get_secure_path()
        tam_dosya_adi = os.path.join(path, f"{dosya_adi}.txt")
        
        aranan_name = f"{guncel_veri['name']} ="
        yeni_satir = f"{guncel_veri['name']} = {guncel_veri['data']}\n"
        
        with open(tam_dosya_adi, "r", encoding="utf-8") as f:
            mevcut_icerik = _sifre_coz(f.read())
        
        satirlar = mevcut_icerik.splitlines(keepends=True)
        yeni_liste = []
        hedef_bolge = False
        guncellendi = False

        for satir in satirlar:
            if f"= {hedef_id}" in satir:
                hedef_bolge = True
                yeni_liste.append(satir)
                continue
            if hedef_bolge and aranan_name in satir:
                yeni_liste.append(yeni_satir)
                guncellendi = True
                hedef_bolge = False
                continue
            if hedef_bolge and (satir.startswith("-") or satir.strip() == "]"):
                hedef_bolge = False
            yeni_liste.append(satir)

        if guncellendi:
            with open(tam_dosya_adi, "w", encoding="utf-8") as f:
                f.write(_sifrele("".join(yeni_liste)))
            _update_control(control, True)
        else:
            _update_control(control, False)
    except:
        _update_control(control, False)

def wew_data_get(dosya_adi, hedef_id, sorgu_sozlugu, control=None):
    """Şifreli dosyayı çözer ve istenen veriyi döndürür."""
    try:
        path = _get_secure_path()
        tam_dosya_adi = os.path.join(path, f"{dosya_adi}.txt")
        
        aranan_name = f"{sorgu_sozlugu['name']} ="
        
        with open(tam_dosya_adi, "r", encoding="utf-8") as f:
            mevcut_icerik = _sifre_coz(f.read())
            
        satirlar = mevcut_icerik.splitlines(keepends=True)
        for i in range(len(satirlar)):
            if f"= {hedef_id}" in satirlar[i]:
                for j in range(i + 1, len(satirlar)):
                    if satirlar[j].startswith("-") or satirlar[j].strip() == "]": break
                    if aranan_name in satirlar[j]:
                        _update_control(control, True)
                        return satirlar[j].split("=")[1].strip()
        _update_control(control, False)
        return None
    except:
        _update_control(control, False)
        return None

# --- SUNUCU FONKSİYONU ---

def wewlot_server(status, control=None):
    """Sunucuyu başlatır."""
    if status != "True":
        _update_control(control, False)
        return
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', 0))
            port = s.getsockname()[1]
        
        Handler = http.server.SimpleHTTPRequestHandler
        with socketserver.TCPServer(("", port), Handler) as httpd:
            print(f"Sunucu aktif: http://localhost:{port}")
            _update_control(control, True)
            httpd.serve_forever()
    except Exception as e:
        print(f"Sunucu hatası: {e}")
        _update_control(control, False)
