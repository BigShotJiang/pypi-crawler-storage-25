"""SorcGCS Local Server — game preview, file management, and AI agent support."""

__version__ = "0.5.12"
