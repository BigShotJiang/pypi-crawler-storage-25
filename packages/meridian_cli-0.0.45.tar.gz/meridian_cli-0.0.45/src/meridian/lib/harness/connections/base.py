"""Core data contracts for bidirectional harness connections."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Final, Generic, Literal

from meridian.lib.core.types import SpawnId
from meridian.lib.harness.ids import HarnessId
from meridian.lib.launch.launch_types import SpecT

if TYPE_CHECKING:
    from meridian.lib.observability.debug_tracer import DebugTracer

# Uniform transport message cap across harness adapters.
MAX_HARNESS_MESSAGE_BYTES: Final[int] = 10 * 1024 * 1024

# Uniform initial-prompt cap across adapters; fail loudly if the prompt is too large.
MAX_INITIAL_PROMPT_BYTES: Final[int] = 10 * 1024 * 1024


class PromptTooLargeError(RuntimeError):
    """Raised when the initial prompt exceeds the harness adapter byte limit."""

    def __init__(self, actual_bytes: int, max_bytes: int, harness: str) -> None:
        super().__init__(
            f"{harness}: initial prompt is {actual_bytes} bytes, exceeds limit of {max_bytes} bytes"
        )
        self.actual_bytes = actual_bytes
        self.max_bytes = max_bytes
        self.harness = harness


@dataclass(frozen=True)
class ConnectionCapabilities:
    """Feature flags describing one bidirectional connection implementation."""

    mid_turn_injection: Literal["queue", "interrupt_restart", "http_post"]
    supports_steer: bool
    supports_cancel: bool
    runtime_model_switch: bool
    structured_reasoning: bool
    supports_primary_observer: bool = False


@dataclass(frozen=True)
class ObserverEndpoint:
    """Attach endpoint exposed by a managed primary backend."""

    transport: Literal["ws", "http"]
    url: str
    host: str | None = None
    port: int | None = None


ConnectionState = Literal["created", "starting", "connected", "stopping", "stopped", "failed"]
StartupTelemetryHook = Callable[[str], None]


class ConnectionNotReady(RuntimeError):
    """Raised when send operations are attempted before connection readiness."""


@dataclass(frozen=True)
class HarnessEvent:
    """One parsed event from a running harness connection."""

    event_type: str
    payload: dict[str, object]
    harness_id: str
    raw_text: str | None = None


@dataclass(frozen=True)
class ConnectionConfig:
    """Configuration inputs for starting one harness connection."""

    spawn_id: SpawnId
    harness_id: HarnessId
    prompt: str
    project_root: Path
    env_overrides: dict[str, str]
    system: str | None = None
    timeout_seconds: float | None = None
    ws_bind_host: str = "127.0.0.1"
    ws_port: int = 0
    debug_tracer: DebugTracer | None = None
    startup_telemetry_hook: StartupTelemetryHook | None = None


def validate_prompt_size(config: ConnectionConfig) -> None:
    """Validate initial prompt size before contacting harness transport endpoints."""

    prompt_bytes = len(config.prompt.encode("utf-8"))
    if prompt_bytes > MAX_INITIAL_PROMPT_BYTES:
        raise PromptTooLargeError(
            actual_bytes=prompt_bytes,
            max_bytes=MAX_INITIAL_PROMPT_BYTES,
            harness=config.harness_id.value,
        )


class HarnessConnection(Generic[SpecT], ABC):
    """Single full-duplex connection contract for all harness transports."""

    @property
    @abstractmethod
    def state(self) -> ConnectionState: ...

    @property
    @abstractmethod
    def harness_id(self) -> HarnessId: ...

    @property
    @abstractmethod
    def spawn_id(self) -> SpawnId: ...

    @property
    @abstractmethod
    def capabilities(self) -> ConnectionCapabilities: ...

    @property
    @abstractmethod
    def session_id(self) -> str | None: ...

    @property
    @abstractmethod
    def subprocess_pid(self) -> int | None: ...

    @abstractmethod
    async def start(self, config: ConnectionConfig, spec: SpecT) -> None: ...

    @property
    def observer_endpoint(self) -> ObserverEndpoint | None:
        """Attach endpoint for primary observer mode. None if not in observer mode."""
        return None

    async def start_observer(self, config: ConnectionConfig, spec: SpecT) -> None:
        """Start connection in primary observer mode.

        Subclasses that support observer mode must override this method
        to set their internal observer flag and then call start().
        """

        if not self.capabilities.supports_primary_observer:
            raise RuntimeError(
                f"{self.harness_id} does not support primary observer mode"
            )
        await self.start(config, spec)

    @abstractmethod
    async def stop(self) -> None: ...

    @abstractmethod
    def health(self) -> bool: ...

    @abstractmethod
    async def send_user_message(self, text: str) -> None: ...

    @abstractmethod
    async def send_cancel(self) -> None: ...

    @abstractmethod
    def events(self) -> AsyncIterator[HarnessEvent]: ...


__all__ = [
    "MAX_HARNESS_MESSAGE_BYTES",
    "MAX_INITIAL_PROMPT_BYTES",
    "ConnectionCapabilities",
    "ConnectionConfig",
    "ConnectionNotReady",
    "ConnectionState",
    "HarnessConnection",
    "HarnessEvent",
    "ObserverEndpoint",
    "PromptTooLargeError",
    "StartupTelemetryHook",
    "validate_prompt_size",
]
