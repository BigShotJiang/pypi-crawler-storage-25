#!/bin/bash
# vssh - AI-native remote execution daemon
# Install: curl -fsSL https://raw.githubusercontent.com/meshpop/vssh/main/install.sh | bash

set -e

REPO="meshpop/vssh"
BINARY="vssh"
INSTALL_DIR="${INSTALL_DIR:-$HOME/bin}"

OS=$(uname -s | tr '[:upper:]' '[:lower:]')
ARCH=$(uname -m)

case "$ARCH" in
    x86_64)  ARCH="amd64" ;;
    aarch64) ARCH="arm64" ;;
    arm64)   ARCH="arm64" ;;
    *)       echo "Unsupported architecture: $ARCH"; exit 1 ;;
esac

case "$OS" in
    linux)  PLATFORM="linux" ;;
    darwin) PLATFORM="darwin" ;;
    *)      echo "Unsupported OS: $OS"; exit 1 ;;
esac

echo "Installing vssh..."
mkdir -p "$INSTALL_DIR"

RELEASE_URL="https://github.com/$REPO/releases/latest/download/${BINARY}-${PLATFORM}-${ARCH}"
TMP_FILE="$(mktemp)"
if ! curl -fsSL "$RELEASE_URL" -o "$TMP_FILE"; then
    echo "Failed to download release asset: $RELEASE_URL" >&2
    echo "Build locally with: GOOS=$PLATFORM GOARCH=$ARCH go build -o $INSTALL_DIR/$BINARY ./cmd/vssh" >&2
    rm -f "$TMP_FILE"
    exit 1
fi
mv "$TMP_FILE" "$INSTALL_DIR/$BINARY"
chmod +x "$INSTALL_DIR/$BINARY"

if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
    echo "Add to PATH: export PATH=\"\$PATH:$INSTALL_DIR\""
fi

echo ""
echo "vssh installed!"
echo ""
echo "Usage:"
echo "  vssh server         # Native server (set VSSH_SECRET)"
echo "  vssh status         # Dashboard"
echo "  vssh <node>         # Native daemon shell"
