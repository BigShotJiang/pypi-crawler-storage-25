# Security

## Reporting a vulnerability

Use [GitHub Security Advisories](https://github.com/meshpop/vssh/security/advisories/new) for private reports.

## Operational notes

- **WireGuard** (when you use Wire) encrypts **VPN tunnel** traffic between peers. That is **separate** from `vssh server`: the native TCP port still requires a **strong secret** (`VSSH_SECRET`, or a value derived from `WIRE_SERVER_URL` / Wire `server_url` when `VSSH_SECRET` is unset) and sensible **firewall** placement. Do not treat the VPN as a substitute for vssh authentication.
- **Empty native secret** is refused by default; use `VSSH_INSECURE_ALLOW_EMPTY_SECRET=1` only in isolated labs.
- **Native protocol** grants authenticated peers the ability to run commands and transfer files as designed; treat the secret like root-equivalent access.
- VSSH does not expose an OpenSSH wrapper command. For sshd-backed access, use OpenSSH directly and rely on its own security model.

## Scope

Covers the `vssh` binary and `vssh server` from this repository.
