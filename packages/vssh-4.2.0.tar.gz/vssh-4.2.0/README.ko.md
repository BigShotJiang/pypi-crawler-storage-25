# vssh

Tailscale/private network 위에서 동작하는 AI-native 원격 실행 daemon/protocol입니다.

VSSH는 두 사용자를 염두에 둡니다.

- sshd 없이 private node에서 실행권한을 열고 싶은 운영자
- 구조화 실행, 장기 작업, 정책, evidence가 필요한 Codex/LLM/Runtime 오케스트레이터

## 제품 범위

**vssh**는 단독 **원격 실행 agent** 제품입니다. 핵심 가치는
**`vssh server`** daemon 경로입니다. Tailscale 같은 private network 위에서
명령 실행, 파일, 작업, 정책, evidence를 sshd 없이 제공합니다.

vssh는 OpenSSH wrapper가 아닙니다. Tailscale + sshd는 이미 일반 remote
shell을 해결하므로, 제품 표면은 native daemon 경로에 집중합니다.

## 왜 vssh를 쓰는가

운영 주체가 터미널에 직접 입력하는 사람이 아니라 AI agent나 자동화 runtime일
때 vssh를 씁니다.

plain SSH보다 vssh가 좋은 경우:

- private node에서 sshd 없이 실행해야 할 때
- stdout/stderr/exit/duration evidence가 구조화되어 필요할 때
- 위험 작업 전에 policy check가 필요할 때
- 장기 job, log, cancel, artifact collection이 필요할 때
- facts, services, logs, GPU/model state, health를 typed API로 다뤄야 할 때

단지 "SSH인데 명령어가 짧다" 수준이면 vssh에 넣지 않습니다. 자세한 기준은
[왜 vssh인가](docs/WHY_VSSH.ko.md)를 보세요.

**이 레포에서 다루지 않는 것:** VPN 메시 자체 운용, 전체 플릿 모니터링 대시보드는 범위 밖입니다. 각각 [Wire](https://github.com/meshpop/wire), [mpop](https://github.com/meshpop/mpop)를 사용하세요.

**구현 참고:** `internal/adapter`는 **탐색용**(`Probe`)입니다. 제품 방향은
`internal/server`를 first-class 실행 경로로 두고, `internal/ssh`는 명시적
discovery 보조와 legacy internal 용도로만 유지하는 것입니다.

## 문서

- [**전체 스택 스냅샷 (Wire + mpop + vssh)**](https://github.com/meshpop/wire/blob/main/docs/CURRENT_STATE.md) — 버전, PyPI, 아키텍처, MCP, 보류 항목  
- [왜 vssh인가](docs/WHY_VSSH.ko.md)
- [AI-native 기능 조사](docs/AI_NATIVE_CAPABILITIES.ko.md)
- [Network traversal 기능 위치 조사](docs/NETWORK_TRAVERSAL_AUDIT.ko.md)
- [Performance 방향](docs/PERFORMANCE.ko.md)
- [배포 방향](docs/DISTRIBUTION.ko.md)
- [Python SDK](docs/PYTHON_SDK.ko.md)
- [Codex 오케스트레이션 노트](docs/CODEX_ORCHESTRATION.ko.md)  
- [공개 저장소 점검 기록](docs/PUBLISHING_AUDIT.ko.md)  
- [English README](README.md)  
- [CHANGELOG.md](CHANGELOG.md)  
- [SECURITY.md](SECURITY.md)  
- [HELP.md](HELP.md)  

## 특징

- **네이티브 프로토콜** - `vssh server`로 sshd 없이 실행
- **AI 지향 실행** - stdout/stderr/exit/duration/evidence 구조화
- **작업 semantics** - 장기 작업, 취소, 로그 API를 향한 daemon 구조
- **파일/artifact API** - shell UX에 기대지 않는 전송/수집
- **정책 hook** - 실행 전 위험도 분류와 gate
- **이름 기반 접근** - raw address 대신 node name으로 route
- **자동 검색** - Tailscale, 설정, legacy source로 노드 검색
- **Runtime 지향 결과** - MCP 경로에서 Codex/LLM 오케스트레이션용 구조화 evidence 반환

## 빠른 시작

```bash
# 설치
curl -fsSL https://raw.githubusercontent.com/meshpop/vssh/main/install.sh | bash

# 서버 노드에서 native daemon 실행
VSSH_SECRET=change-me vssh server

# 같은 private network의 client에서 실행
VSSH_SECRET=change-me vssh run web1 "df -h"

# 상태 확인
vssh                 # 대시보드
vssh list            # 모든 노드 목록
```

## 명령어

```
vssh                    대시보드 표시 (기본)
vssh server             native daemon 실행
vssh <node>             native shell 열기
vssh run <node> <cmd>   native daemon으로 명령 실행
vssh run-many <nodes> <cmd>  쉼표로 구분한 여러 node에 병렬 실행
vssh rpc <node> <method> [json]  typed daemon RPC 호출
vssh rpc-many <nodes> <method> [json]  여러 node에 RPC 병렬 호출
vssh facts <node>       typed daemon facts 반환
vssh facts-many <nodes> 여러 node의 facts 병렬 반환
vssh job-start <node> <cmd>  장기 daemon job 시작
vssh job-status <node> <id>  job 상태 반환
vssh job-logs <node> <id>    job 로그 반환
vssh job-cancel <node> <id>  job 취소
vssh shell <node>       native shell 열기
vssh put <src> <dst>    native upload
vssh get <src> <dst>    native download
vssh exec <node> <cmd>  native run alias
vssh bench <node> [n]   native 실행 latency 측정
vssh list               모든 노드 목록
vssh status             대시보드 표시
vssh version            버전 표시
vssh help               도움말
```

## 대시보드

```
  vssh dashboard

    SERVER   IP               LOAD   MEM  DISK  UPTIME
  --------------------------------------------------------
  ● web1     192.0.2.10       0.15    8%   40%  48 days
  ● web2     192.0.2.11       0.77    6%   63%  100 days
  ● db1      192.0.2.20       1.53    9%   30%  78 days
  ...
  
  16/16 online
```

## 실행 흐름

제품의 기본 실행 흐름:

```text
vssh client
  -> Tailscale IP / MagicDNS
  -> vssh daemon
  -> typed exec/file/job/service APIs
  -> structured evidence
```

OpenSSH wrapper 명령은 의도적으로 제공하지 않습니다. 노드에 이미 sshd가
있고 필요한 것이 shell뿐이면 `ssh`를 직접 쓰면 됩니다.

## 연결 흐름

vssh는 순서대로 여러 엔드포인트를 시도:

1. **VPN IP** - VPN이 켜져 있으면 가장 안정적
2. **LAN IP** - 같은 로컬 네트워크
3. **공인 IP** - 원격 접속용 폴백

## 데이터 소스

노드 검색:

1. **Wire daemon** - Wire VPN이 실행 중인 경우
2. **Wire coordinator** - coordinator URL이 설정된 경우
3. **Tailscale** - Tailscale이 실행 중인 경우
4. **설정 파일** - 수동 서버 목록 (~/.vssh/servers.json)
5. **캐시** - 이전에 검색된 노드

## 설정

서버 설정: `~/.vssh/servers.json`

```json
{
  "web1": {
    "ip": "192.0.2.10",
    "user": "deploy",
    "tags": ["linux", "web"],
    "capabilities": ["docker"]
  },
  "gpu1": {
    "ip": "192.0.2.20",
    "user": "ubuntu",
    "tags": ["linux", "gpu", "ollama"],
    "capabilities": ["cuda", "ollama"],
    "monitor_port": 8721
  },
  "mac1": {
    "ip": "192.0.2.30",
    "user": "admin",
    "os": "darwin",
    "tags": ["mac", "browser"],
    "capabilities": ["browser"]
  }
}
```

실제 `~/.vssh/servers.json`, Wire 설정, 호스트명, VPN IP, 비밀값은 커밋하지 마세요. 로컬 인벤토리 파일은 repo 밖에 두고 문서에는 예시 값만 사용합니다.

`vssh.hosts.list`는 이 값을 agent 라우팅 metadata로 반환하고, 추론된 capability와 health 객체도 함께 제공합니다.

VSSH는 모니터링 데몬을 내장하지 않습니다. `meshclaw monitor`나 `mpop agent`
같은 별도 모니터를 실행한다면 host마다 `monitor_port` 또는 `monitor_url`을
넣으면 됩니다. agent tool은 `include_health: true`를 요청해서 라우팅 전에
`/api/node/status` live health를 host record에 병합할 수 있습니다.

사용자 매핑: `~/.wire/users.json`

```json
{
  "web1": "deploy",
  "db1": "root",
  "v1": "deploy"
}
```

## 네이티브 프로토콜

vssh는 sshd 없이 네이티브 프로토콜로 동작 가능:

```bash
# 서버에서
vssh server           # :48291에서 vssh 서버 시작

# 클라이언트에서
vssh shell web1         # 네이티브 쉘
vssh run web1 "df -h"   # 네이티브 실행
vssh put file web1:/tmp # 네이티브 업로드
vssh get web1:/tmp/x .  # 네이티브 다운로드
```

네이티브 서버를 노출하기 전에 client/server 양쪽에 `VSSH_SECRET`을 설정하세요. 자세한 내용은 [SECURITY.md](SECURITY.md)를 보세요.

## Codex / Runtime 사용

VSSH는 AI-native Runtime의 실행 substrate로 사용할 수 있습니다.

- 이름 기반으로 노드에 작업 라우팅
- 따옴표, 파이프, 여러 줄 명령 보존
- `stdout`, `stderr`, `exit_code`, duration, transport, endpoint attempts 반환
- Matrix event, task ledger, audit log에 evidence 기록

MCP 서버 실행:

```bash
vssh mcp
```

Python SDK:

```bash
python -m pip install vssh
```

```python
from vssh import VSSH

client = VSSH(secret="change-me")
facts = client.facts("web1")
fleet = client.facts_many(["web1", "db1"])
results = client.exec_many(["web1", "db1"], "uptime")
job = client.job_start("web1", "long-running-command")
```

Python SDK는 AI agent와 자동화 script가 쓰는 client layer입니다. daemon
protocol을 Python으로 다시 구현하지 않고 설치된 Go `vssh` binary를 호출합니다.

agent용 MCP 도구:

| Tool | 용도 |
|------|------|
| `vssh.hosts.list` | 라우팅용 host 목록 조회 |
| `vssh.exec.safe` | 읽기/진단 명령 실행, 위험 명령은 policy로 차단 |
| `vssh.exec` | policy 검사 후 실행, 승인된 경우 `allow_dangerous` 사용 |
| `vssh.route.select` | capability, tag, health 기준으로 최적 host 선택 |
| `vssh.exec.routed` | 먼저 route를 고른 뒤 policy/evidence 포함 실행 |
| `vssh.policy.check` | 실행 전에 명령 위험도 분류 |
| `vssh_exec`, `vssh_list`, `vssh_status` | 기존 호환 tool 이름 |

`rm -rf`, `shutdown`, `reboot`, `docker rm`, `kubectl delete`,
`systemctl restart`처럼 파괴적이거나 서비스에 영향을 주는 명령은 기본
차단됩니다. 명시적 사람 승인이 있을 때만 `allow_dangerous: true`로 실행할
수 있습니다. 모든 실행 응답은 timestamp, policy decision, target, command,
timeout, structured execution result를 포함하는 evidence envelope입니다.

`vssh.hosts.list`는 agent가 바로 판단할 수 있는 record를 반환합니다.

```json
{
  "name": "gpu1",
  "addresses": {"vpn": "192.0.2.20"},
  "user": "ubuntu",
  "tags": ["gpu", "linux", "ollama"],
  "capabilities": ["cuda", "gpu", "linux", "ollama"],
  "health": {"status": "unknown", "reason": "no live health signal"}
}
```

Routed execution을 쓰면 agent가 host 이름을 직접 고정하지 않고 capability로 요청할 수 있습니다.

```json
{
  "required_capabilities": ["cuda", "ollama"],
  "preferred_tags": ["gpu"],
  "avoid_health": ["offline", "degraded"],
  "include_health": true,
  "command": "ollama list",
  "timeout_seconds": 20
}
```

VSSH는 candidate를 평가하고, route decision을 기록한 뒤, command policy를 확인하고, 선택된 host에서 실행합니다.

자세한 내용은 [docs/CODEX_ORCHESTRATION.ko.md](docs/CODEX_ORCHESTRATION.ko.md)를 보세요.

## 공개 저장소 위생

이 repo에는 소스 코드와 공개 가능한 예시만 들어가야 합니다. 릴리스 바이너리는 Git에 커밋하지 않고 GitHub Release asset으로 배포합니다. 자세한 내용은 [docs/PUBLISHING_AUDIT.ko.md](docs/PUBLISHING_AUDIT.ko.md)를 보세요.

## 빌드

```bash
make build      # vssh 빌드
make install    # /usr/local/bin에 설치
make release    # 모든 플랫폼용 빌드
```

## 요구사항

- Go 1.21+ (빌드용)
- native daemon 모드에는 SSH 클라이언트 불필요

## 라이선스

MIT
