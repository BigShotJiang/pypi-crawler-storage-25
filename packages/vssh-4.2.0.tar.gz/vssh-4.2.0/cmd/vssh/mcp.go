package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"sort"
	"strings"
	"time"

	"github.com/meshpop/vssh/internal/config"
	"github.com/meshpop/vssh/internal/server"
	"github.com/meshpop/vssh/internal/ssh"
)

const mcpVersion = "1.0.0"

// MCP Protocol structures
type MCPRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
	ID      interface{}     `json:"id"`
}

type MCPResponse struct {
	JSONRPC string      `json:"jsonrpc"`
	Result  interface{} `json:"result,omitempty"`
	Error   *MCPError   `json:"error,omitempty"`
	ID      interface{} `json:"id"`
}

type MCPError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type Tool struct {
	Name        string      `json:"name"`
	Description string      `json:"description"`
	InputSchema InputSchema `json:"inputSchema"`
}

type InputSchema struct {
	Type       string              `json:"type"`
	Properties map[string]Property `json:"properties"`
	Required   []string            `json:"required,omitempty"`
}

type Property struct {
	Type        string      `json:"type"`
	Description string      `json:"description"`
	Default     interface{} `json:"default,omitempty"`
}

type PolicyDecision struct {
	Allowed          bool     `json:"allowed"`
	Risk             string   `json:"risk"`
	Reason           string   `json:"reason"`
	MatchedPatterns  []string `json:"matched_patterns,omitempty"`
	RequiresApproval bool     `json:"requires_approval"`
}

type RouteRequest struct {
	RequiredCapabilities []string `json:"required_capabilities"`
	PreferredTags        []string `json:"preferred_tags"`
	AvoidHealth          []string `json:"avoid_health"`
	Target               string   `json:"target,omitempty"`
	IncludeHealth        bool     `json:"include_health"`
	HealthTimeoutSeconds float64  `json:"health_timeout_seconds,omitempty"`
}

type RouteCandidate struct {
	Name         string                 `json:"name"`
	Score        int                    `json:"score"`
	Selected     bool                   `json:"selected"`
	Reasons      []string               `json:"reasons"`
	Missing      []string               `json:"missing_capabilities,omitempty"`
	Health       string                 `json:"health"`
	Tags         []string               `json:"tags"`
	Capabilities []string               `json:"capabilities"`
	Host         map[string]interface{} `json:"host"`
}

type RouteDecision struct {
	Success    bool             `json:"success"`
	Selected   string           `json:"selected,omitempty"`
	Reason     string           `json:"reason"`
	Request    RouteRequest     `json:"request"`
	Candidates []RouteCandidate `json:"candidates"`
	Error      interface{}      `json:"error,omitempty"`
}

func cmdMcp() {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}

		var req MCPRequest
		if err := json.Unmarshal([]byte(line), &req); err != nil {
			continue
		}

		// Skip notifications (requests without ID)
		if req.ID == nil {
			continue
		}

		resp := handleMCPRequest(req)
		// Skip empty responses (notifications)
		if resp.ID == nil && resp.Result == nil && resp.Error == nil {
			continue
		}
		output, _ := json.Marshal(resp)
		fmt.Println(string(output))
	}
}

func handleMCPRequest(req MCPRequest) MCPResponse {
	switch req.Method {
	case "notifications/initialized", "notifications/cancelled":
		// These are notifications, return empty (will be skipped)
		return MCPResponse{}

	case "initialize":
		return MCPResponse{
			JSONRPC: "2.0",
			Result: map[string]interface{}{
				"protocolVersion": "2024-11-05",
				"capabilities":    map[string]interface{}{"tools": map[string]interface{}{}},
				"serverInfo":      map[string]string{"name": "vssh-mcp", "version": mcpVersion},
			},
			ID: req.ID,
		}

	case "tools/list":
		return MCPResponse{
			JSONRPC: "2.0",
			Result:  map[string]interface{}{"tools": getMCPTools()},
			ID:      req.ID,
		}

	case "tools/call":
		var params struct {
			Name      string                 `json:"name"`
			Arguments map[string]interface{} `json:"arguments"`
		}
		json.Unmarshal(req.Params, &params)

		result := callMCPTool(params.Name, params.Arguments)
		resultJSON, _ := json.MarshalIndent(result, "", "  ")

		return MCPResponse{
			JSONRPC: "2.0",
			Result: map[string]interface{}{
				"content": []map[string]string{
					{"type": "text", "text": string(resultJSON)},
				},
			},
			ID: req.ID,
		}

	default:
		return MCPResponse{
			JSONRPC: "2.0",
			Error:   &MCPError{Code: -32601, Message: "Unknown method: " + req.Method},
			ID:      req.ID,
		}
	}
}

func getMCPTools() []Tool {
	return []Tool{
		{
			Name:        "vssh_status",
			Description: "Show connection status for all peers",
			InputSchema: InputSchema{
				Type:       "object",
				Properties: map[string]Property{},
			},
		},
		{
			Name:        "vssh_list",
			Description: "List all peers",
			InputSchema: InputSchema{
				Type:       "object",
				Properties: hostListProperties(),
			},
		},
		{
			Name:        "vssh.hosts.list",
			Description: "List configured/discovered hosts with metadata, capabilities, tags, and health for AI agent routing",
			InputSchema: InputSchema{
				Type:       "object",
				Properties: hostListProperties(),
			},
		},
		{
			Name:        "vssh_exec",
			Description: "Execute a shell command on a remote server and return structured stdout/stderr/exit code evidence",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target":          {Type: "string", Description: "Target peer name or IP"},
					"command":         {Type: "string", Description: "Shell command to execute as one script; quotes and pipes are preserved"},
					"timeout_seconds": {Type: "number", Description: "Execution timeout in seconds", Default: 30},
					"allow_dangerous": {Type: "boolean", Description: "Allow commands blocked by the safety policy; use only after explicit human approval", Default: false},
				},
				Required: []string{"target", "command"},
			},
		},
		{
			Name:        "vssh.exec",
			Description: "Execute a shell command with policy checks and return an evidence envelope",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target":          {Type: "string", Description: "Target peer name or IP"},
					"command":         {Type: "string", Description: "Shell command to execute as one script; quotes and pipes are preserved"},
					"timeout_seconds": {Type: "number", Description: "Execution timeout in seconds", Default: 30},
					"allow_dangerous": {Type: "boolean", Description: "Allow commands blocked by the safety policy; use only after explicit human approval", Default: false},
				},
				Required: []string{"target", "command"},
			},
		},
		{
			Name:        "vssh.exec.safe",
			Description: "Execute only commands allowed by the built-in read/diagnostic safety policy",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target":          {Type: "string", Description: "Target peer name or IP"},
					"command":         {Type: "string", Description: "Shell command to execute as one script; dangerous write/destructive operations are blocked"},
					"timeout_seconds": {Type: "number", Description: "Execution timeout in seconds", Default: 30},
				},
				Required: []string{"target", "command"},
			},
		},
		{
			Name:        "vssh.policy.check",
			Description: "Classify a shell command before execution and report whether approval is required",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"command": {Type: "string", Description: "Shell command to classify"},
				},
				Required: []string{"command"},
			},
		},
		{
			Name:        "vssh.route.select",
			Description: "Select the best host for required capabilities, preferred tags, and health constraints",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"required_capabilities":  {Type: "array", Description: "Capabilities that must be present, e.g. cuda, ollama, browser"},
					"preferred_tags":         {Type: "array", Description: "Tags that improve route score but are not required"},
					"avoid_health":           {Type: "array", Description: "Health statuses to avoid", Default: []string{"offline", "degraded"}},
					"target":                 {Type: "string", Description: "Optional explicit target host to validate against routing constraints"},
					"include_health":         {Type: "boolean", Description: "Fetch live monitor health from configured monitor_url or monitor_port before routing", Default: false},
					"health_timeout_seconds": {Type: "number", Description: "Per-host live health HTTP timeout in seconds", Default: 1},
				},
			},
		},
		{
			Name:        "vssh_route_select",
			Description: "Compatibility alias for vssh.route.select",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"required_capabilities":  {Type: "array", Description: "Capabilities that must be present, e.g. cuda, ollama, browser"},
					"preferred_tags":         {Type: "array", Description: "Tags that improve route score but are not required"},
					"avoid_health":           {Type: "array", Description: "Health statuses to avoid", Default: []string{"offline", "degraded"}},
					"target":                 {Type: "string", Description: "Optional explicit target host to validate against routing constraints"},
					"include_health":         {Type: "boolean", Description: "Fetch live monitor health from configured monitor_url or monitor_port before routing", Default: false},
					"health_timeout_seconds": {Type: "number", Description: "Per-host live health HTTP timeout in seconds", Default: 1},
				},
			},
		},
		{
			Name:        "vssh.exec.routed",
			Description: "Route by capability/tag/health, then execute a command with policy and evidence",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"required_capabilities":  {Type: "array", Description: "Capabilities that must be present"},
					"preferred_tags":         {Type: "array", Description: "Tags that improve route score"},
					"avoid_health":           {Type: "array", Description: "Health statuses to avoid", Default: []string{"offline", "degraded"}},
					"target":                 {Type: "string", Description: "Optional explicit target host"},
					"include_health":         {Type: "boolean", Description: "Fetch live monitor health from configured monitor_url or monitor_port before routing", Default: false},
					"health_timeout_seconds": {Type: "number", Description: "Per-host live health HTTP timeout in seconds", Default: 1},
					"command":                {Type: "string", Description: "Shell command to execute on the selected host"},
					"timeout_seconds":        {Type: "number", Description: "Execution timeout in seconds", Default: 30},
					"allow_dangerous":        {Type: "boolean", Description: "Allow commands blocked by policy; use only after explicit human approval", Default: false},
				},
				Required: []string{"command"},
			},
		},
		{
			Name:        "vssh.rpc.call",
			Description: "Call a typed native daemon RPC method on one target and return JSON data",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target":          {Type: "string", Description: "Target peer name or IP"},
					"method":          {Type: "string", Description: "RPC method such as get_disk, get_memory, get_gpu, service_status"},
					"params":          {Type: "object", Description: "RPC parameters"},
					"timeout_seconds": {Type: "number", Description: "Execution timeout in seconds", Default: 30},
				},
				Required: []string{"target", "method"},
			},
		},
		{
			Name:        "vssh.exec.many",
			Description: "Execute one command across many native daemon targets in parallel",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"targets":         {Type: "array", Description: "Target peer names or IPs"},
					"command":         {Type: "string", Description: "Shell command to execute on every target"},
					"timeout_seconds": {Type: "number", Description: "Per-target timeout in seconds", Default: 30},
					"allow_dangerous": {Type: "boolean", Description: "Allow commands blocked by policy; use only after explicit human approval", Default: false},
					"max_parallelism": {Type: "number", Description: "Maximum concurrent target executions", Default: 16},
					"allow_partial":   {Type: "boolean", Description: "Return partial results when some targets fail", Default: true},
				},
				Required: []string{"targets", "command"},
			},
		},
		{
			Name:        "vssh.rpc.many",
			Description: "Call one typed native daemon RPC method across many targets in parallel",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"targets":         {Type: "array", Description: "Target peer names or IPs"},
					"method":          {Type: "string", Description: "RPC method such as get_disk, get_memory, get_gpu, service_status"},
					"params":          {Type: "object", Description: "RPC parameters"},
					"timeout_seconds": {Type: "number", Description: "Per-target timeout in seconds", Default: 30},
					"max_parallelism": {Type: "number", Description: "Maximum concurrent target RPC calls", Default: 16},
				},
				Required: []string{"targets", "method"},
			},
		},
		{
			Name:        "vssh.facts",
			Description: "Return typed daemon facts for one target using INFO",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target":          {Type: "string", Description: "Target peer name or IP"},
					"timeout_seconds": {Type: "number", Description: "Execution timeout in seconds", Default: 30},
				},
				Required: []string{"target"},
			},
		},
		{
			Name:        "vssh.facts.many",
			Description: "Return typed daemon facts for many targets in parallel using INFO",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"targets":         {Type: "array", Description: "Target peer names or IPs"},
					"timeout_seconds": {Type: "number", Description: "Per-target timeout in seconds", Default: 30},
					"max_parallelism": {Type: "number", Description: "Maximum concurrent target fact probes", Default: 16},
				},
				Required: []string{"targets"},
			},
		},
		{
			Name:        "vssh.job.start",
			Description: "Start a long-running command as a daemon-side job and return its job id",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target":          {Type: "string", Description: "Target peer name or IP"},
					"command":         {Type: "string", Description: "Command to run asynchronously"},
					"allow_dangerous": {Type: "boolean", Description: "Allow commands blocked by safety policy after approval", Default: false},
				},
				Required: []string{"target", "command"},
			},
		},
		{
			Name:        "vssh.job.status",
			Description: "Return daemon-side job status",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target": {Type: "string", Description: "Target peer name or IP"},
					"id":     {Type: "string", Description: "Job id"},
				},
				Required: []string{"target", "id"},
			},
		},
		{
			Name:        "vssh.job.logs",
			Description: "Return daemon-side job stdout/stderr logs",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target":     {Type: "string", Description: "Target peer name or IP"},
					"id":         {Type: "string", Description: "Job id"},
					"tail_bytes": {Type: "number", Description: "Return only the last N bytes of stdout/stderr", Default: 0},
				},
				Required: []string{"target", "id"},
			},
		},
		{
			Name:        "vssh.job.cancel",
			Description: "Cancel a running daemon-side job",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target": {Type: "string", Description: "Target peer name or IP"},
					"id":     {Type: "string", Description: "Job id"},
				},
				Required: []string{"target", "id"},
			},
		},
		{
			Name:        "vssh.artifact.collect",
			Description: "Collect remote artifact metadata; files return bounded base64 content, directories return shallow entries",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"target":    {Type: "string", Description: "Target peer name or IP"},
					"path":      {Type: "string", Description: "Remote file or directory path"},
					"max_bytes": {Type: "number", Description: "Maximum file bytes to return before base64 encoding", Default: 1048576},
				},
				Required: []string{"target", "path"},
			},
		},
		{
			Name:        "vssh_exec_routed",
			Description: "Compatibility alias for vssh.exec.routed",
			InputSchema: InputSchema{
				Type: "object",
				Properties: map[string]Property{
					"required_capabilities":  {Type: "array", Description: "Capabilities that must be present"},
					"preferred_tags":         {Type: "array", Description: "Tags that improve route score"},
					"avoid_health":           {Type: "array", Description: "Health statuses to avoid", Default: []string{"offline", "degraded"}},
					"target":                 {Type: "string", Description: "Optional explicit target host"},
					"include_health":         {Type: "boolean", Description: "Fetch live monitor health from configured monitor_url or monitor_port before routing", Default: false},
					"health_timeout_seconds": {Type: "number", Description: "Per-host live health HTTP timeout in seconds", Default: 1},
					"command":                {Type: "string", Description: "Shell command to execute on the selected host"},
					"timeout_seconds":        {Type: "number", Description: "Execution timeout in seconds", Default: 30},
					"allow_dangerous":        {Type: "boolean", Description: "Allow commands blocked by policy; use only after explicit human approval", Default: false},
				},
				Required: []string{"command"},
			},
		},
	}
}

func callMCPTool(name string, args map[string]interface{}) interface{} {
	switch name {
	case "vssh_status":
		return toolStatus()
	case "vssh_list", "vssh.hosts.list":
		return toolList(args)
	case "vssh_exec", "vssh.exec":
		return toolExec(getString(args, "target"), getString(args, "command"), getFloat(args, "timeout_seconds", 30), getBool(args, "allow_dangerous", false))
	case "vssh.exec.safe":
		return toolExec(getString(args, "target"), getString(args, "command"), getFloat(args, "timeout_seconds", 30), false)
	case "vssh.policy.check":
		command := getString(args, "command")
		if command == "" {
			return map[string]interface{}{
				"success": false,
				"error": map[string]interface{}{
					"code":    "missing_argument",
					"message": "command is required",
				},
			}
		}
		return map[string]interface{}{
			"success": true,
			"command": command,
			"policy":  classifyCommand(command),
		}
	case "vssh.route.select", "vssh_route_select":
		return toolRouteSelect(args)
	case "vssh.exec.routed", "vssh_exec_routed":
		return toolExecRouted(args)
	case "vssh.rpc.call":
		return toolRPCCall(args)
	case "vssh.exec.many":
		return toolExecMany(args)
	case "vssh.rpc.many":
		return toolRPCMany(args)
	case "vssh.facts":
		return toolFacts(args)
	case "vssh.facts.many":
		return toolFactsMany(args)
	case "vssh.job.start":
		return toolJobStart(args)
	case "vssh.job.status":
		return toolJobRPC(args, "vssh.job.status", "job_status")
	case "vssh.job.logs":
		return toolJobRPC(args, "vssh.job.logs", "job_logs")
	case "vssh.job.cancel":
		return toolJobRPC(args, "vssh.job.cancel", "job_cancel")
	case "vssh.artifact.collect":
		return toolArtifactCollect(args)
	default:
		return map[string]string{"error": "Unknown tool: " + name}
	}
}

// Helper functions
func getString(args map[string]interface{}, key string) string {
	if v, ok := args[key]; ok {
		if s, ok := v.(string); ok {
			return s
		}
	}
	return ""
}

func getFloat(args map[string]interface{}, key string, fallback float64) float64 {
	if v, ok := args[key]; ok {
		switch n := v.(type) {
		case float64:
			return n
		case int:
			return float64(n)
		}
	}
	return fallback
}

func getBool(args map[string]interface{}, key string, fallback bool) bool {
	if v, ok := args[key]; ok {
		if b, ok := v.(bool); ok {
			return b
		}
	}
	return fallback
}

func getStringList(args map[string]interface{}, key string, fallback []string) []string {
	value, ok := args[key]
	if !ok {
		return fallback
	}
	switch v := value.(type) {
	case []string:
		return normalizeList(v)
	case []interface{}:
		values := []string{}
		for _, item := range v {
			if s, ok := item.(string); ok {
				values = append(values, s)
			}
		}
		return normalizeList(values)
	case string:
		if strings.TrimSpace(v) == "" {
			return fallback
		}
		return normalizeList(strings.Split(v, ","))
	default:
		return fallback
	}
}

func getRouteRequest(args map[string]interface{}) RouteRequest {
	return RouteRequest{
		RequiredCapabilities: getStringList(args, "required_capabilities", nil),
		PreferredTags:        getStringList(args, "preferred_tags", nil),
		AvoidHealth:          getStringList(args, "avoid_health", []string{"offline", "degraded"}),
		Target:               getString(args, "target"),
		IncludeHealth:        getBool(args, "include_health", false),
		HealthTimeoutSeconds: getFloat(args, "health_timeout_seconds", 1),
	}
}

func hostListProperties() map[string]Property {
	return map[string]Property{
		"include_health":         {Type: "boolean", Description: "Fetch live monitor health from configured monitor_url or monitor_port", Default: false},
		"health_timeout_seconds": {Type: "number", Description: "Per-host live health HTTP timeout in seconds", Default: 1},
	}
}

func classifyCommand(command string) PolicyDecision {
	normalized := strings.ToLower(strings.Join(strings.Fields(command), " "))
	if normalized == "" {
		return PolicyDecision{
			Allowed:          false,
			Risk:             "invalid",
			Reason:           "empty command",
			RequiresApproval: false,
		}
	}

	dangerous := []string{
		"rm -rf",
		"rm -fr",
		"shutdown",
		"reboot",
		"poweroff",
		"halt",
		"mkfs",
		"dd if=",
		"dd of=",
		"docker rm",
		"docker rmi",
		"docker system prune",
		"kubectl delete",
		"helm uninstall",
		"terraform destroy",
		"systemctl stop",
		"systemctl restart",
		"systemctl disable",
		"iptables -f",
		"nft flush",
	}

	matches := []string{}
	for _, pattern := range dangerous {
		if strings.Contains(normalized, pattern) {
			matches = append(matches, pattern)
		}
	}
	if len(matches) > 0 {
		return PolicyDecision{
			Allowed:          false,
			Risk:             "dangerous",
			Reason:           "command matches a destructive or service-impacting pattern",
			MatchedPatterns:  matches,
			RequiresApproval: true,
		}
	}

	return PolicyDecision{
		Allowed:          true,
		Risk:             "low",
		Reason:           "no dangerous pattern matched",
		RequiresApproval: false,
	}
}

func toolRouteSelect(args map[string]interface{}) map[string]interface{} {
	request := getRouteRequest(args)
	decision := selectRoute(request)
	return routeDecisionMap(decision)
}

func toolExecRouted(args map[string]interface{}) map[string]interface{} {
	startedAt := time.Now().UTC()
	command := getString(args, "command")
	if command == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.exec.routed",
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "command is required",
			},
		}
	}

	request := getRouteRequest(args)
	decision := selectRoute(request)
	if !decision.Success || decision.Selected == "" {
		endedAt := time.Now().UTC()
		return map[string]interface{}{
			"success":     false,
			"tool":        "vssh.exec.routed",
			"command":     command,
			"started_at":  startedAt.Format(time.RFC3339Nano),
			"ended_at":    endedAt.Format(time.RFC3339Nano),
			"duration_ms": endedAt.Sub(startedAt).Milliseconds(),
			"route":       decision,
			"error": map[string]interface{}{
				"code":      "route_not_found",
				"message":   decision.Reason,
				"retryable": true,
			},
		}
	}

	execResult := toolExec(decision.Selected, command, getFloat(args, "timeout_seconds", 30), getBool(args, "allow_dangerous", false))
	execResult["tool"] = "vssh.exec.routed"
	execResult["route"] = decision
	execResult["routed_target"] = decision.Selected
	return execResult
}

func toolRPCCall(args map[string]interface{}) map[string]interface{} {
	target := getString(args, "target")
	method := getString(args, "method")
	if target == "" || method == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.rpc.call",
			"target":  target,
			"method":  method,
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "target and method are required",
			},
		}
	}

	startedAt := time.Now().UTC()
	timeout := time.Duration(getFloat(args, "timeout_seconds", 30) * float64(time.Second))
	resp, err := callRPCNative(target, method, getParamsMap(args, "params"), timeout)
	endedAt := time.Now().UTC()
	payload := map[string]interface{}{
		"success":     err == nil && resp != nil && resp.Success,
		"tool":        "vssh.rpc.call",
		"target":      target,
		"method":      method,
		"started_at":  startedAt.Format(time.RFC3339Nano),
		"ended_at":    endedAt.Format(time.RFC3339Nano),
		"duration_ms": endedAt.Sub(startedAt).Milliseconds(),
		"result":      resp,
	}
	if err != nil {
		payload["error"] = map[string]interface{}{
			"code":      "rpc_failed",
			"message":   err.Error(),
			"retryable": true,
		}
	} else if resp != nil && !resp.Success {
		payload["error"] = map[string]interface{}{
			"code":      "rpc_error",
			"message":   resp.Error,
			"retryable": false,
		}
	}
	return payload
}

func toolExecMany(args map[string]interface{}) map[string]interface{} {
	targets := getStringList(args, "targets", nil)
	command := getString(args, "command")
	if len(targets) == 0 || command == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.exec.many",
			"targets": targets,
			"command": command,
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "targets and command are required",
			},
		}
	}

	policy := classifyCommand(command)
	allowDangerous := getBool(args, "allow_dangerous", false)
	if !policy.Allowed && !allowDangerous {
		return map[string]interface{}{
			"success":       false,
			"tool":          "vssh.exec.many",
			"targets":       targets,
			"command":       command,
			"policy":        policy,
			"blocked":       true,
			"evidence_type": "policy_decision",
			"error": map[string]interface{}{
				"code":      "policy_blocked",
				"message":   policy.Reason,
				"retryable": false,
			},
		}
	}
	if allowDangerous && !policy.Allowed {
		policy.Allowed = true
		policy.Reason = "dangerous command allowed by explicit allow_dangerous flag"
	}

	startedAt := time.Now().UTC()
	maxParallelism := int(getFloat(args, "max_parallelism", float64(defaultMaxParallelism())))
	results := runMany(targets, command, time.Duration(getFloat(args, "timeout_seconds", 30)*float64(time.Second)), maxParallelism)
	endedAt := time.Now().UTC()
	ok, failed := countExecMany(results)
	return map[string]interface{}{
		"success":         failed == 0,
		"tool":            "vssh.exec.many",
		"targets":         targets,
		"command":         command,
		"started_at":      startedAt.Format(time.RFC3339Nano),
		"ended_at":        endedAt.Format(time.RFC3339Nano),
		"duration_ms":     endedAt.Sub(startedAt).Milliseconds(),
		"policy":          policy,
		"approved":        allowDangerous,
		"max_parallelism": normalizedMaxParallelism(maxParallelism, len(targets)),
		"evidence_type":   "execution_result_many",
		"summary": map[string]interface{}{
			"total":  len(targets),
			"ok":     ok,
			"failed": failed,
		},
		"results": results,
	}
}

func toolRPCMany(args map[string]interface{}) map[string]interface{} {
	targets := getStringList(args, "targets", nil)
	method := getString(args, "method")
	if len(targets) == 0 || method == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.rpc.many",
			"targets": targets,
			"method":  method,
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "targets and method are required",
			},
		}
	}

	startedAt := time.Now().UTC()
	maxParallelism := int(getFloat(args, "max_parallelism", float64(defaultMaxParallelism())))
	results := rpcMany(targets, method, getParamsMap(args, "params"), time.Duration(getFloat(args, "timeout_seconds", 30)*float64(time.Second)), maxParallelism)
	endedAt := time.Now().UTC()
	ok, failed := countRPCMany(results)
	return map[string]interface{}{
		"success":         failed == 0,
		"tool":            "vssh.rpc.many",
		"targets":         targets,
		"method":          method,
		"max_parallelism": normalizedMaxParallelism(maxParallelism, len(targets)),
		"started_at":      startedAt.Format(time.RFC3339Nano),
		"ended_at":        endedAt.Format(time.RFC3339Nano),
		"duration_ms":     endedAt.Sub(startedAt).Milliseconds(),
		"summary": map[string]interface{}{
			"total":  len(targets),
			"ok":     ok,
			"failed": failed,
		},
		"results": results,
	}
}

func toolFacts(args map[string]interface{}) map[string]interface{} {
	target := getString(args, "target")
	if target == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.facts",
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "target is required",
			},
		}
	}
	startedAt := time.Now().UTC()
	host, port := parseHostPort(target)
	host = resolveNativeHost(host)
	info, err := server.GetInfo(host, port, getSecret(), time.Duration(getFloat(args, "timeout_seconds", 30)*float64(time.Second)))
	endedAt := time.Now().UTC()
	payload := map[string]interface{}{
		"success":     err == nil,
		"tool":        "vssh.facts",
		"target":      target,
		"endpoint":    host,
		"started_at":  startedAt.Format(time.RFC3339Nano),
		"ended_at":    endedAt.Format(time.RFC3339Nano),
		"duration_ms": endedAt.Sub(startedAt).Milliseconds(),
		"facts":       info,
	}
	if err != nil {
		payload["error"] = map[string]interface{}{
			"code":      "facts_failed",
			"message":   err.Error(),
			"retryable": true,
		}
	}
	return payload
}

func toolFactsMany(args map[string]interface{}) map[string]interface{} {
	targets := getStringList(args, "targets", nil)
	if len(targets) == 0 {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.facts.many",
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "targets is required",
			},
		}
	}
	startedAt := time.Now().UTC()
	maxParallelism := int(getFloat(args, "max_parallelism", float64(defaultMaxParallelism())))
	results := factsMany(targets, time.Duration(getFloat(args, "timeout_seconds", 30)*float64(time.Second)), maxParallelism)
	endedAt := time.Now().UTC()
	ok, failed := countFactsMany(results)
	return map[string]interface{}{
		"success":         failed == 0,
		"tool":            "vssh.facts.many",
		"targets":         targets,
		"max_parallelism": normalizedMaxParallelism(maxParallelism, len(targets)),
		"started_at":      startedAt.Format(time.RFC3339Nano),
		"ended_at":        endedAt.Format(time.RFC3339Nano),
		"duration_ms":     endedAt.Sub(startedAt).Milliseconds(),
		"summary": map[string]interface{}{
			"total":  len(targets),
			"ok":     ok,
			"failed": failed,
		},
		"results": results,
	}
}

func countFactsMany(results []multiFactsResult) (ok int, failed int) {
	for _, result := range results {
		if result.Error != "" || result.Result == nil {
			failed++
			continue
		}
		ok++
	}
	return ok, failed
}

func toolJobStart(args map[string]interface{}) map[string]interface{} {
	target := getString(args, "target")
	command := getString(args, "command")
	if target == "" || command == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.job.start",
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "target and command are required",
			},
		}
	}
	policy := classifyCommand(command)
	allowDangerous := getBool(args, "allow_dangerous", false)
	if !policy.Allowed && !allowDangerous {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.job.start",
			"target":  target,
			"command": command,
			"policy":  policy,
			"blocked": true,
			"error": map[string]interface{}{
				"code":      "policy_blocked",
				"message":   policy.Reason,
				"retryable": false,
			},
		}
	}
	return toolRPCJobCall("vssh.job.start", target, "job_start", map[string]interface{}{"command": command})
}

func toolJobRPC(args map[string]interface{}, tool, method string) map[string]interface{} {
	target := getString(args, "target")
	id := getString(args, "id")
	if target == "" || id == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    tool,
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "target and id are required",
			},
		}
	}
	params := map[string]interface{}{"id": id}
	if method == "job_logs" {
		params["tail_bytes"] = getFloat(args, "tail_bytes", 0)
	}
	return toolRPCJobCall(tool, target, method, params)
}

func toolRPCJobCall(tool, target, method string, params map[string]interface{}) map[string]interface{} {
	startedAt := time.Now().UTC()
	resp, err := callRPCNative(target, method, params, 30*time.Second)
	endedAt := time.Now().UTC()
	payload := map[string]interface{}{
		"success":     err == nil && resp != nil && resp.Success,
		"tool":        tool,
		"target":      target,
		"method":      method,
		"started_at":  startedAt.Format(time.RFC3339Nano),
		"ended_at":    endedAt.Format(time.RFC3339Nano),
		"duration_ms": endedAt.Sub(startedAt).Milliseconds(),
		"response":    resp,
	}
	if err != nil {
		payload["error"] = map[string]interface{}{"code": "job_rpc_failed", "message": err.Error(), "retryable": true}
	} else if resp != nil && !resp.Success {
		payload["error"] = map[string]interface{}{"code": "job_rpc_error", "message": resp.Error, "retryable": false}
	}
	return payload
}

func toolArtifactCollect(args map[string]interface{}) map[string]interface{} {
	target := getString(args, "target")
	path := getString(args, "path")
	if target == "" || path == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.artifact.collect",
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "target and path are required",
			},
		}
	}
	return toolRPCJobCall("vssh.artifact.collect", target, "artifact_collect", map[string]interface{}{
		"path":      path,
		"max_bytes": getFloat(args, "max_bytes", 1024*1024),
	})
}

func getParamsMap(args map[string]interface{}, key string) map[string]interface{} {
	value, ok := args[key]
	if !ok || value == nil {
		return map[string]interface{}{}
	}
	if params, ok := value.(map[string]interface{}); ok {
		return params
	}
	return map[string]interface{}{}
}

func countExecMany(results []multiExecResult) (int, int) {
	ok, failed := 0, 0
	for _, result := range results {
		if result.Error != "" || result.Result == nil || !result.Result.Success {
			failed++
		} else {
			ok++
		}
	}
	return ok, failed
}

func countRPCMany(results []multiRPCResult) (int, int) {
	ok, failed := 0, 0
	for _, result := range results {
		if result.Error != "" || result.Result == nil || !result.Result.Success {
			failed++
		} else {
			ok++
		}
	}
	return ok, failed
}

// Tool implementations
func toolStatus() map[string]interface{} {
	connector, err := ssh.NewConnector("default")
	if err != nil {
		return map[string]interface{}{
			"error": fmt.Sprintf("Failed to create connector: %v", err),
		}
	}

	return map[string]interface{}{
		"status": connector.Status(),
	}
}

func toolList(args map[string]interface{}) map[string]interface{} {
	opts := hostRecordOptions{
		IncludeHealth: getBool(args, "include_health", false),
		HealthTimeout: time.Duration(getFloat(args, "health_timeout_seconds", 1) * float64(time.Second)),
	}
	connector, err := ssh.NewConnector("default")
	if err != nil {
		return map[string]interface{}{
			"error": fmt.Sprintf("Failed to create connector: %v", err),
		}
	}

	peers := connector.ListPeers()
	hostList := []map[string]interface{}{}

	for _, p := range peers {
		if p.NodeName == "" {
			continue
		}
		hostList = append(hostList, buildHostRecordWithOptions(p, opts))
	}
	sort.Slice(hostList, func(i, j int) bool {
		return fmt.Sprint(hostList[i]["name"]) < fmt.Sprint(hostList[j]["name"])
	})

	return map[string]interface{}{
		"success": true,
		"count":   len(hostList),
		"hosts":   hostList,
		"peers":   hostList,
		"health": map[string]interface{}{
			"included": opts.IncludeHealth,
			"source":   "meshclaw_monitor",
		},
	}
}

type hostRecordOptions struct {
	IncludeHealth bool
	HealthTimeout time.Duration
}

func listHostRecords(opts hostRecordOptions) ([]map[string]interface{}, error) {
	connector, err := ssh.NewConnector("default")
	if err != nil {
		return nil, err
	}

	peers := connector.ListPeers()
	hostList := []map[string]interface{}{}
	for _, p := range peers {
		if p.NodeName == "" {
			continue
		}
		hostList = append(hostList, buildHostRecordWithOptions(p, opts))
	}
	sort.Slice(hostList, func(i, j int) bool {
		return fmt.Sprint(hostList[i]["name"]) < fmt.Sprint(hostList[j]["name"])
	})
	return hostList, nil
}

func selectRoute(request RouteRequest) RouteDecision {
	hosts, err := listHostRecords(hostRecordOptions{
		IncludeHealth: request.IncludeHealth,
		HealthTimeout: time.Duration(request.HealthTimeoutSeconds * float64(time.Second)),
	})
	if err != nil {
		return RouteDecision{
			Success: false,
			Reason:  fmt.Sprintf("failed to list hosts: %v", err),
			Request: request,
			Error: map[string]interface{}{
				"code":    "connector_error",
				"message": fmt.Sprintf("%v", err),
			},
		}
	}

	candidates := make([]RouteCandidate, 0, len(hosts))
	for _, host := range hosts {
		candidate := scoreRouteCandidate(host, request)
		if request.Target != "" && !strings.EqualFold(candidate.Name, request.Target) {
			candidate.Score -= 10000
			candidate.Reasons = append(candidate.Reasons, "not explicit target")
		}
		candidates = append(candidates, candidate)
	}
	sort.SliceStable(candidates, func(i, j int) bool {
		if candidates[i].Score == candidates[j].Score {
			return candidates[i].Name < candidates[j].Name
		}
		return candidates[i].Score > candidates[j].Score
	})

	if len(candidates) == 0 {
		return RouteDecision{
			Success:    false,
			Reason:     "no hosts available",
			Request:    request,
			Candidates: candidates,
		}
	}
	best := candidates[0]
	if len(best.Missing) > 0 || best.Score < 0 {
		return RouteDecision{
			Success:    false,
			Reason:     "no host satisfies route constraints",
			Request:    request,
			Candidates: candidates,
		}
	}

	candidates[0].Selected = true
	return RouteDecision{
		Success:    true,
		Selected:   best.Name,
		Reason:     strings.Join(best.Reasons, "; "),
		Request:    request,
		Candidates: candidates,
	}
}

func scoreRouteCandidate(host map[string]interface{}, request RouteRequest) RouteCandidate {
	name := fmt.Sprint(host["name"])
	caps := getStringSliceFromHost(host, "capabilities")
	tags := getStringSliceFromHost(host, "tags")
	health := getHealthStatus(host)
	score := 0
	reasons := []string{}
	missing := []string{}

	for _, capability := range request.RequiredCapabilities {
		if containsNormalized(caps, capability) {
			score += 100
			reasons = append(reasons, "has capability "+capability)
		} else {
			score -= 1000
			missing = append(missing, capability)
			reasons = append(reasons, "missing capability "+capability)
		}
	}

	for _, tag := range request.PreferredTags {
		if containsNormalized(tags, tag) {
			score += 10
			reasons = append(reasons, "has preferred tag "+tag)
		}
	}

	switch health {
	case "online":
		score += 20
		reasons = append(reasons, "health online")
	case "unknown":
		reasons = append(reasons, "health unknown")
	case "stale":
		score -= 10
		reasons = append(reasons, "health stale")
	case "degraded":
		score -= 50
		reasons = append(reasons, "health degraded")
	case "offline":
		score -= 1000
		reasons = append(reasons, "health offline")
	}

	for _, avoid := range request.AvoidHealth {
		if strings.EqualFold(health, avoid) {
			score -= 1000
			reasons = append(reasons, "avoids health "+avoid)
		}
	}

	return RouteCandidate{
		Name:         name,
		Score:        score,
		Reasons:      reasons,
		Missing:      missing,
		Health:       health,
		Tags:         tags,
		Capabilities: caps,
		Host:         host,
	}
}

func routeDecisionMap(decision RouteDecision) map[string]interface{} {
	payload := map[string]interface{}{
		"success":    decision.Success,
		"selected":   decision.Selected,
		"reason":     decision.Reason,
		"request":    decision.Request,
		"candidates": decision.Candidates,
	}
	if decision.Error != nil {
		payload["error"] = decision.Error
	}
	return payload
}

func getStringSliceFromHost(host map[string]interface{}, key string) []string {
	raw, ok := host[key]
	if !ok || raw == nil {
		return []string{}
	}
	switch values := raw.(type) {
	case []string:
		return normalizeList(values)
	case []interface{}:
		out := []string{}
		for _, value := range values {
			if s, ok := value.(string); ok {
				out = append(out, s)
			}
		}
		return normalizeList(out)
	default:
		return []string{}
	}
}

func getHealthStatus(host map[string]interface{}) string {
	raw, ok := host["health"].(map[string]interface{})
	if !ok {
		return "unknown"
	}
	status, ok := raw["status"].(string)
	if !ok || strings.TrimSpace(status) == "" {
		return "unknown"
	}
	return strings.ToLower(status)
}

func containsNormalized(values []string, want string) bool {
	want = strings.ToLower(strings.TrimSpace(want))
	for _, value := range values {
		if strings.ToLower(strings.TrimSpace(value)) == want {
			return true
		}
	}
	return false
}

func buildHostRecord(p config.Peer) map[string]interface{} {
	return buildHostRecordWithOptions(p, hostRecordOptions{})
}

func buildHostRecordWithOptions(p config.Peer, opts hostRecordOptions) map[string]interface{} {
	tags := normalizeList(append(append([]string{}, p.Tags...), p.Roles...))
	capabilities := normalizeList(p.Capabilities)
	capabilities = mergeLists(capabilities, inferCapabilities(p, tags))
	osName := strings.ToLower(strings.TrimSpace(p.OS))
	if osName != "" {
		tags = mergeLists(tags, []string{osName})
	}

	record := map[string]interface{}{
		"name":         p.NodeName,
		"node_id":      p.NodeID,
		"addresses":    buildAddressRecord(p),
		"vpn_ip":       p.VpnIP,
		"public_ip":    p.PublicIP,
		"lan_ip":       p.LanIP,
		"port":         p.Port,
		"user":         p.User,
		"os":           p.OS,
		"arch":         p.Arch,
		"tags":         tags,
		"capabilities": capabilities,
		"health":       buildHealthRecord(p),
		"stats":        p.Stats,
		"metadata":     p.Metadata,
	}
	if endpoint := monitorEndpoint(p); endpoint != "" {
		record["monitor"] = map[string]interface{}{
			"url": endpoint,
		}
	}
	if opts.IncludeHealth {
		record["health"] = mergeLiveHealth(record["health"].(map[string]interface{}), fetchLiveMonitorHealth(p, opts.HealthTimeout))
	}
	return record
}

func buildAddressRecord(p config.Peer) map[string]interface{} {
	addresses := map[string]interface{}{}
	if p.VpnIP != "" {
		addresses["vpn"] = p.VpnIP
	}
	if p.LanIP != "" {
		addresses["lan"] = p.LanIP
	}
	if p.PublicIP != "" {
		addresses["public"] = p.PublicIP
	}
	return addresses
}

func buildHealthRecord(p config.Peer) map[string]interface{} {
	now := time.Now().Unix()
	status := "unknown"
	reason := "no live health signal"
	var lastSeenUnix int64
	var lastSeen string

	if p.Online != nil {
		if *p.Online {
			status = "online"
			reason = "provider reported online"
		} else {
			status = "offline"
			reason = "provider reported offline"
		}
	}

	if p.LastSeen != nil {
		switch v := p.LastSeen.(type) {
		case float64:
			lastSeenUnix = int64(v)
		case int64:
			lastSeenUnix = v
		case int:
			lastSeenUnix = int64(v)
		case string:
			if t, err := time.Parse(time.RFC3339, v); err == nil {
				lastSeenUnix = t.Unix()
				lastSeen = t.UTC().Format(time.RFC3339)
			}
		}
		if lastSeenUnix > 0 {
			age := now - lastSeenUnix
			if age < 0 {
				age = 0
			}
			if lastSeen == "" {
				lastSeen = time.Unix(lastSeenUnix, 0).UTC().Format(time.RFC3339)
			}
			if age < 60 {
				status = "online"
				reason = "last_seen is fresh"
			} else if status == "unknown" {
				status = "stale"
				reason = "last_seen is stale"
			}
		}
	}

	if p.Stats != nil && (p.Stats.DiskPct >= 90 || p.Stats.MemPct >= 95) && status == "online" {
		status = "degraded"
		reason = "resource pressure detected"
	}

	record := map[string]interface{}{
		"status": status,
		"reason": reason,
	}
	if lastSeen != "" {
		record["last_seen"] = lastSeen
		record["last_seen_age_sec"] = now - lastSeenUnix
	}
	if p.Online != nil {
		record["provider_online"] = *p.Online
	}
	return record
}

func monitorEndpoint(p config.Peer) string {
	if p.MonitorURL != "" {
		return strings.TrimRight(p.MonitorURL, "/")
	}
	port := p.MonitorPort
	if port == 0 {
		return ""
	}
	host := p.VpnIP
	if host == "" {
		host = p.LanIP
	}
	if host == "" {
		host = p.PublicIP
	}
	if host == "" {
		return ""
	}
	return fmt.Sprintf("http://%s:%d", host, port)
}

func fetchLiveMonitorHealth(p config.Peer, timeout time.Duration) map[string]interface{} {
	endpoint := monitorEndpoint(p)
	if endpoint == "" {
		return map[string]interface{}{
			"live_checked": false,
			"source":       "meshclaw_monitor",
			"error": map[string]interface{}{
				"code":    "monitor_not_configured",
				"message": "monitor_url or monitor_port is not configured",
			},
		}
	}
	if timeout <= 0 {
		timeout = time.Second
	}
	client := &http.Client{Timeout: timeout}
	url := endpoint + "/api/node/status"
	started := time.Now()
	resp, err := client.Get(url)
	duration := time.Since(started).Milliseconds()
	if err != nil {
		return map[string]interface{}{
			"live_checked": true,
			"source":       "meshclaw_monitor",
			"endpoint":     url,
			"duration_ms":  duration,
			"status":       "offline",
			"reason":       "monitor endpoint unreachable",
			"error": map[string]interface{}{
				"code":      "monitor_unreachable",
				"message":   err.Error(),
				"retryable": true,
			},
		}
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return map[string]interface{}{
			"live_checked": true,
			"source":       "meshclaw_monitor",
			"endpoint":     url,
			"duration_ms":  duration,
			"status":       "degraded",
			"reason":       fmt.Sprintf("monitor endpoint returned HTTP %d", resp.StatusCode),
			"http_status":  resp.StatusCode,
		}
	}

	var payload map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&payload); err != nil {
		return map[string]interface{}{
			"live_checked": true,
			"source":       "meshclaw_monitor",
			"endpoint":     url,
			"duration_ms":  duration,
			"status":       "degraded",
			"reason":       "monitor payload is not valid JSON",
			"error": map[string]interface{}{
				"code":      "monitor_invalid_json",
				"message":   err.Error(),
				"retryable": true,
			},
		}
	}

	status := "online"
	reason := "meshclaw monitor responded"
	cpuPct := numberFromMap(payload, "cpu_pct")
	memPct := numberFromMap(payload, "mem_pct")
	diskPct := numberFromMap(payload, "disk_pct")
	if cpuPct >= 95 || memPct >= 95 || diskPct >= 95 {
		status = "degraded"
		reason = "critical resource pressure from meshclaw monitor"
	} else if cpuPct >= 85 || memPct >= 90 || diskPct >= 90 {
		status = "degraded"
		reason = "resource pressure from meshclaw monitor"
	}

	result := map[string]interface{}{
		"live_checked": true,
		"source":       "meshclaw_monitor",
		"endpoint":     url,
		"duration_ms":  duration,
		"status":       status,
		"reason":       reason,
		"node":         payload["node"],
		"ip":           payload["ip"],
		"os":           payload["os"],
		"arch":         payload["arch"],
		"cpu_pct":      cpuPct,
		"mem_pct":      memPct,
		"disk_pct":     diskPct,
		"load":         payload["load"],
		"uptime":       payload["uptime"],
		"ts":           payload["ts"],
	}
	if gpu, ok := payload["gpu"]; ok {
		result["gpu"] = gpu
	}
	if docker, ok := payload["docker"]; ok {
		result["docker"] = docker
	}
	if alerts, ok := payload["alerts"]; ok {
		result["alerts"] = alerts
	}
	return result
}

func mergeLiveHealth(base map[string]interface{}, live map[string]interface{}) map[string]interface{} {
	out := map[string]interface{}{}
	for key, value := range base {
		out[key] = value
	}
	for key, value := range live {
		out[key] = value
	}
	return out
}

func numberFromMap(payload map[string]interface{}, key string) float64 {
	switch value := payload[key].(type) {
	case float64:
		return value
	case float32:
		return float64(value)
	case int:
		return float64(value)
	case int64:
		return float64(value)
	case json.Number:
		n, _ := value.Float64()
		return n
	default:
		return 0
	}
}

func inferCapabilities(p config.Peer, tags []string) []string {
	values := append([]string{}, tags...)
	name := strings.ToLower(p.NodeName)
	osName := strings.ToLower(p.OS)
	if name != "" {
		values = append(values, name)
	}
	if osName != "" {
		values = append(values, osName)
	}

	var caps []string
	for _, value := range values {
		switch {
		case value == "gpu" || value == "cuda" || value == "nvidia" || strings.Contains(value, "rtx"):
			caps = append(caps, "gpu", "cuda")
		case value == "ollama" || strings.Contains(value, "llm"):
			caps = append(caps, "ollama")
		case value == "browser" || value == "chrome" || value == "safari":
			caps = append(caps, "browser")
		case value == "controller":
			caps = append(caps, "controller")
		case value == "mail" || value == "smtp" || value == "mox":
			caps = append(caps, "mail")
		case value == "docker":
			caps = append(caps, "docker")
		case value == "darwin" || value == "mac" || strings.Contains(value, "mac"):
			caps = append(caps, "macos")
		case value == "linux" || value == "ubuntu" || value == "debian":
			caps = append(caps, "linux")
		}
	}
	return normalizeList(caps)
}

func normalizeList(values []string) []string {
	seen := map[string]bool{}
	out := []string{}
	for _, value := range values {
		value = strings.ToLower(strings.TrimSpace(value))
		if value == "" || seen[value] {
			continue
		}
		seen[value] = true
		out = append(out, value)
	}
	sort.Strings(out)
	return out
}

func mergeLists(a, b []string) []string {
	return normalizeList(append(append([]string{}, a...), b...))
}

func toolExec(target, command string, timeoutSeconds float64, allowDangerous bool) map[string]interface{} {
	startedAt := time.Now().UTC()
	if target == "" || command == "" {
		return map[string]interface{}{
			"success": false,
			"tool":    "vssh.exec",
			"target":  target,
			"command": command,
			"error": map[string]interface{}{
				"code":    "missing_argument",
				"message": "target and command are required",
			},
		}
	}
	if timeoutSeconds <= 0 {
		timeoutSeconds = 30
	}

	policy := classifyCommand(command)
	if !policy.Allowed && !allowDangerous {
		endedAt := time.Now().UTC()
		return map[string]interface{}{
			"success":       false,
			"tool":          "vssh.exec",
			"target":        target,
			"command":       command,
			"started_at":    startedAt.Format(time.RFC3339Nano),
			"ended_at":      endedAt.Format(time.RFC3339Nano),
			"duration_ms":   endedAt.Sub(startedAt).Milliseconds(),
			"timeout_sec":   timeoutSeconds,
			"policy":        policy,
			"approved":      false,
			"blocked":       true,
			"evidence_type": "policy_decision",
			"error": map[string]interface{}{
				"code":      "policy_blocked",
				"message":   policy.Reason,
				"retryable": false,
			},
		}
	}
	if allowDangerous && !policy.Allowed {
		policy.Allowed = true
		policy.Reason = "dangerous command allowed by explicit allow_dangerous flag"
	}

	result, err := execNativeCapture(target, command)
	if result == nil {
		result = &ssh.ExecResult{
			Success:   false,
			Host:      target,
			Target:    target,
			Command:   command,
			ExitCode:  -1,
			Transport: "vssh-native",
			Error: &ssh.ExecError{
				Code:      "execution_failed",
				Message:   "execution failed without result",
				Retryable: true,
			},
		}
	}
	endedAt := time.Now().UTC()
	payload := map[string]interface{}{
		"success":       err == nil,
		"tool":          "vssh.exec",
		"target":        target,
		"command":       command,
		"started_at":    startedAt.Format(time.RFC3339Nano),
		"ended_at":      endedAt.Format(time.RFC3339Nano),
		"duration_ms":   endedAt.Sub(startedAt).Milliseconds(),
		"timeout_sec":   timeoutSeconds,
		"policy":        policy,
		"approved":      allowDangerous,
		"blocked":       false,
		"evidence_type": "execution_result",
		"result":        result,
	}
	if err != nil {
		if result.Error != nil {
			payload["error"] = result.Error
		} else {
			payload["error"] = map[string]interface{}{
				"code":      "execution_failed",
				"message":   err.Error(),
				"retryable": true,
			}
		}
	}
	return payload
}

func execNativeCapture(target, command string) (*ssh.ExecResult, error) {
	start := time.Now()
	result := &ssh.ExecResult{
		Host:      target,
		Target:    target,
		Command:   command,
		ExitCode:  -1,
		Transport: "vssh-native",
	}

	host := target
	if connector, err := ssh.NewConnector("default"); err == nil {
		if resolved, err := connector.ResolveHost(target); err == nil && resolved != "" {
			host = resolved
		}
	}
	result.Endpoint = host
	result.Attempts = append(result.Attempts, ssh.ExecAttempt{
		Endpoint:  host,
		Path:      "native daemon",
		Transport: "vssh-native",
	})

	nativeResult, err := server.ExecCommandStructured(host, getPort(), getSecret(), command)
	result.DurationMs = time.Since(start).Milliseconds()
	result.Stdout = nativeResult.Stdout
	result.Stderr = nativeResult.Stderr
	result.ExitCode = nativeResult.ExitCode
	if nativeResult.DurationMs > 0 {
		result.DurationMs = nativeResult.DurationMs
	}
	if err != nil {
		result.Error = &ssh.ExecError{
			Code:      "native_execution_failed",
			Message:   err.Error(),
			Retryable: true,
		}
		return result, err
	}
	result.Success = nativeResult.Success
	if !nativeResult.Success {
		result.Error = &ssh.ExecError{
			Code:      "remote_exit_nonzero",
			Message:   nativeResult.Error,
			Retryable: false,
		}
		if result.Error.Message == "" {
			result.Error.Message = fmt.Sprintf("remote command exited with code %d", nativeResult.ExitCode)
		}
		return result, fmt.Errorf("%s", result.Error.Message)
	}
	return result, nil
}
