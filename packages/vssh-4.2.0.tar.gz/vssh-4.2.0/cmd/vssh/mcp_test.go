package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/meshpop/vssh/internal/config"
	"github.com/meshpop/vssh/internal/ssh"
)

func TestVSSHExecToolSchemaIsLLMFriendly(t *testing.T) {
	var execTool *Tool
	for _, tool := range getMCPTools() {
		if tool.Name == "vssh.exec" {
			tool := tool
			execTool = &tool
			break
		}
	}
	if execTool == nil {
		t.Fatal("vssh_exec tool not found")
	}

	props := execTool.InputSchema.Properties
	if props["command"].Description == "" {
		t.Fatal("command description must explain shell command behavior")
	}
	if props["timeout_seconds"].Type != "number" {
		t.Fatalf("timeout_seconds type = %q, want number", props["timeout_seconds"].Type)
	}
	if props["timeout_seconds"].Default != 30 {
		t.Fatalf("timeout_seconds default = %#v, want 30", props["timeout_seconds"].Default)
	}
	if props["allow_dangerous"].Type != "boolean" {
		t.Fatalf("allow_dangerous type = %q, want boolean", props["allow_dangerous"].Type)
	}
}

func TestToolExecMissingArgumentsReturnsStructuredError(t *testing.T) {
	got := toolExec("", "", 30, false)
	if got["success"] != false {
		t.Fatalf("success = %#v, want false", got["success"])
	}
	errPayload, ok := got["error"].(map[string]interface{})
	if !ok {
		t.Fatalf("error payload type = %T, want map", got["error"])
	}
	if errPayload["code"] != "missing_argument" {
		t.Fatalf("error code = %#v, want missing_argument", errPayload["code"])
	}
}

func TestMCPIncludesAgentFriendlyToolNames(t *testing.T) {
	names := map[string]bool{}
	for _, tool := range getMCPTools() {
		names[tool.Name] = true
	}
	for _, want := range []string{"vssh.hosts.list", "vssh.exec", "vssh.exec.safe", "vssh.policy.check", "vssh.route.select", "vssh.exec.routed", "vssh.rpc.call", "vssh.exec.many", "vssh.rpc.many", "vssh.facts"} {
		if !names[want] {
			t.Fatalf("tool %q not found in MCP tool list", want)
		}
	}
}

func TestExecManyPolicyBlockReturnsEvidence(t *testing.T) {
	got := toolExecMany(map[string]interface{}{
		"targets": []interface{}{"web1", "web2"},
		"command": "reboot",
	})
	if got["success"] != false {
		t.Fatalf("success = %#v, want false", got["success"])
	}
	if got["evidence_type"] != "policy_decision" {
		t.Fatalf("evidence_type = %#v, want policy_decision", got["evidence_type"])
	}
	errPayload, ok := got["error"].(map[string]interface{})
	if !ok {
		t.Fatalf("error payload type = %T, want map", got["error"])
	}
	if errPayload["code"] != "policy_blocked" {
		t.Fatalf("error code = %#v, want policy_blocked", errPayload["code"])
	}
}

func TestPolicyBlocksDangerousCommands(t *testing.T) {
	got := classifyCommand("rm -rf /tmp/example")
	if got.Allowed {
		t.Fatalf("dangerous command allowed: %#v", got)
	}
	if !got.RequiresApproval {
		t.Fatalf("dangerous command should require approval: %#v", got)
	}
	if len(got.MatchedPatterns) == 0 {
		t.Fatalf("missing matched patterns: %#v", got)
	}
}

func TestPolicyAllowsReadOnlyDiagnostics(t *testing.T) {
	got := classifyCommand("df -h | tail -n 3")
	if !got.Allowed {
		t.Fatalf("read-only diagnostic blocked: %#v", got)
	}
	if got.RequiresApproval {
		t.Fatalf("read-only diagnostic should not require approval: %#v", got)
	}
}

func TestToolExecPolicyBlockReturnsEvidenceEnvelope(t *testing.T) {
	got := toolExec("web1", "kubectl delete pod x", 30, false)
	if got["success"] != false {
		t.Fatalf("success = %#v, want false", got["success"])
	}
	if got["blocked"] != true {
		t.Fatalf("blocked = %#v, want true", got["blocked"])
	}
	if got["evidence_type"] != "policy_decision" {
		t.Fatalf("evidence_type = %#v, want policy_decision", got["evidence_type"])
	}
	errPayload, ok := got["error"].(map[string]interface{})
	if !ok {
		t.Fatalf("error payload type = %T, want map", got["error"])
	}
	if errPayload["code"] != "policy_blocked" {
		t.Fatalf("error code = %#v, want policy_blocked", errPayload["code"])
	}
}

func TestExecResultSchemaHasRuntimeFields(t *testing.T) {
	result := ssh.ExecResult{
		Success:      false,
		Host:         "g1",
		Target:       "g1",
		Command:      "false",
		ExitCode:     1,
		Transport:    "ssh",
		FallbackUsed: false,
		Error: &ssh.ExecError{
			Code:      "remote_exit_nonzero",
			Message:   "exit status 1",
			Retryable: false,
		},
	}

	if result.Host == "" || result.Transport == "" {
		t.Fatalf("missing runtime fields: %#v", result)
	}
	if result.Error == nil || result.Error.Code == "" {
		t.Fatalf("missing structured error: %#v", result.Error)
	}
}

func TestGetFloatFallbackAndNumber(t *testing.T) {
	if got := getFloat(map[string]interface{}{}, "timeout_seconds", 30); got != 30 {
		t.Fatalf("fallback = %v, want 30", got)
	}
	if got := getFloat(map[string]interface{}{"timeout_seconds": float64(12)}, "timeout_seconds", 30); got != 12 {
		t.Fatalf("number = %v, want 12", got)
	}
}

func TestGetBoolFallbackAndValue(t *testing.T) {
	if got := getBool(map[string]interface{}{}, "allow_dangerous", false); got {
		t.Fatalf("fallback = %v, want false", got)
	}
	if got := getBool(map[string]interface{}{"allow_dangerous": true}, "allow_dangerous", false); !got {
		t.Fatalf("bool = %v, want true", got)
	}
}

func TestBuildHostRecordIncludesRoutingMetadata(t *testing.T) {
	online := true
	record := buildHostRecord(config.Peer{
		NodeName:     "gpu1",
		VpnIP:        "192.0.2.10",
		User:         "deploy",
		Tags:         []string{"GPU", "Ollama"},
		Capabilities: []string{"docker"},
		OS:           "linux",
		Online:       &online,
		LastSeen:     time.Now().Unix(),
		Stats:        &config.PeerStats{MemPct: 42, DiskPct: 51},
	})

	if record["name"] != "gpu1" {
		t.Fatalf("name = %#v, want gpu1", record["name"])
	}
	caps, ok := record["capabilities"].([]string)
	if !ok {
		t.Fatalf("capabilities type = %T, want []string", record["capabilities"])
	}
	for _, want := range []string{"cuda", "docker", "gpu", "linux", "ollama"} {
		if !containsString(caps, want) {
			t.Fatalf("capabilities = %#v, missing %q", caps, want)
		}
	}
	health, ok := record["health"].(map[string]interface{})
	if !ok {
		t.Fatalf("health type = %T, want map", record["health"])
	}
	if health["status"] != "online" {
		t.Fatalf("health status = %#v, want online", health["status"])
	}
}

func TestBuildHostRecordDetectsDegradedHealth(t *testing.T) {
	record := buildHostRecord(config.Peer{
		NodeName: "db1",
		LastSeen: time.Now().Unix(),
		Stats:    &config.PeerStats{MemPct: 96, DiskPct: 50},
	})
	health := record["health"].(map[string]interface{})
	if health["status"] != "degraded" {
		t.Fatalf("health status = %#v, want degraded", health["status"])
	}
}

func TestBuildHostRecordCanMergeMeshclawMonitorHealth(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/node/status" {
			t.Fatalf("path = %q, want /api/node/status", r.URL.Path)
		}
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"node":     "gpu1",
			"ip":       "192.0.2.10",
			"os":       "linux",
			"arch":     "amd64",
			"cpu_pct":  12.5,
			"mem_pct":  40.0,
			"disk_pct": 50.0,
			"load":     "0.1 0.2 0.3",
			"uptime":   "up 1 day",
			"gpu": map[string]interface{}{
				"available": true,
			},
		})
	}))
	defer server.Close()

	record := buildHostRecordWithOptions(config.Peer{
		NodeName:   "gpu1",
		MonitorURL: server.URL,
	}, hostRecordOptions{
		IncludeHealth: true,
		HealthTimeout: time.Second,
	})

	health := record["health"].(map[string]interface{})
	if health["status"] != "online" {
		t.Fatalf("health status = %#v, want online; health=%#v", health["status"], health)
	}
	if health["source"] != "meshclaw_monitor" {
		t.Fatalf("health source = %#v, want meshclaw_monitor", health["source"])
	}
	if health["cpu_pct"] != 12.5 {
		t.Fatalf("cpu_pct = %#v, want 12.5", health["cpu_pct"])
	}
	if _, ok := health["gpu"]; !ok {
		t.Fatalf("missing gpu health: %#v", health)
	}
}

func TestLiveMeshclawMonitorPressureMarksDegraded(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"node":     "db1",
			"cpu_pct":  20,
			"mem_pct":  97,
			"disk_pct": 30,
		})
	}))
	defer server.Close()

	record := buildHostRecordWithOptions(config.Peer{
		NodeName:   "db1",
		MonitorURL: server.URL,
	}, hostRecordOptions{
		IncludeHealth: true,
		HealthTimeout: time.Second,
	})

	health := record["health"].(map[string]interface{})
	if health["status"] != "degraded" {
		t.Fatalf("health status = %#v, want degraded; health=%#v", health["status"], health)
	}
}

func TestScoreRouteCandidatePrefersCapabilitiesAndHealth(t *testing.T) {
	online := true
	host := buildHostRecord(config.Peer{
		NodeName:     "gpu1",
		Tags:         []string{"gpu", "ollama"},
		Capabilities: []string{"cuda"},
		Online:       &online,
		LastSeen:     time.Now().Unix(),
	})
	candidate := scoreRouteCandidate(host, RouteRequest{
		RequiredCapabilities: []string{"cuda", "ollama"},
		PreferredTags:        []string{"gpu"},
		AvoidHealth:          []string{"offline", "degraded"},
	})
	if candidate.Score < 200 {
		t.Fatalf("score = %d, want >= 200; candidate=%#v", candidate.Score, candidate)
	}
	if len(candidate.Missing) != 0 {
		t.Fatalf("missing = %#v, want none", candidate.Missing)
	}
}

func TestScoreRouteCandidatePenalizesMissingCapability(t *testing.T) {
	host := buildHostRecord(config.Peer{
		NodeName:     "web1",
		Capabilities: []string{"docker"},
	})
	candidate := scoreRouteCandidate(host, RouteRequest{
		RequiredCapabilities: []string{"cuda"},
	})
	if len(candidate.Missing) != 1 || candidate.Missing[0] != "cuda" {
		t.Fatalf("missing = %#v, want cuda", candidate.Missing)
	}
	if candidate.Score >= 0 {
		t.Fatalf("score = %d, want negative", candidate.Score)
	}
}

func containsString(values []string, want string) bool {
	for _, value := range values {
		if value == want {
			return true
		}
	}
	return false
}
