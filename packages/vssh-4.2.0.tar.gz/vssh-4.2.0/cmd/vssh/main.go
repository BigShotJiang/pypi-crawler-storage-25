package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/signal"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/meshpop/vssh/internal/agent"
	"github.com/meshpop/vssh/internal/server"
	"github.com/meshpop/vssh/internal/ssh"
)

var (
	version   = "0.7.4"
	buildTime = ""
)

func main() {
	if len(os.Args) < 2 {
		// Default to status
		cmdStatus()
		return
	}

	cmd := os.Args[1]

	switch cmd {
	case "server", "daemon", "vsshd":
		cmdServer(os.Args[2:])
	case "shell":
		cmdShell(os.Args[2:])
	case "put":
		cmdPut(os.Args[2:])
	case "get":
		cmdGet(os.Args[2:])
	case "run":
		cmdRun(os.Args[2:])
	case "run-many", "exec-many":
		cmdRunMany(os.Args[2:])
	case "rpc":
		cmdRPC(os.Args[2:])
	case "rpc-many":
		cmdRPCMany(os.Args[2:])
	case "facts":
		cmdFacts(os.Args[2:])
	case "facts-many":
		cmdFactsMany(os.Args[2:])
	case "job-start":
		cmdJobStart(os.Args[2:])
	case "job-status":
		cmdJobStatus(os.Args[2:])
	case "job-logs":
		cmdJobLogs(os.Args[2:])
	case "job-cancel":
		cmdJobCancel(os.Args[2:])
	case "artifact-collect":
		cmdArtifactCollect(os.Args[2:])
	case "setup":
		cmdSetup()
	case "status":
		cmdStatus()
	case "list", "ls":
		cmdList()
	case "exec":
		cmdRun(os.Args[2:])
	case "bench":
		cmdBench(os.Args[2:])
	case "mcp":
		cmdMcp()
	case "agent":
		cmdAgent(os.Args[2:])
	case "version", "-v", "--version":
		if buildTime != "" {
			fmt.Printf("vssh %s (built %s)\n", version, buildTime)
		} else {
			fmt.Printf("vssh %s\n", version)
		}
	case "help", "-h", "--help":
		printUsage()
	default:
		// Assume it is a native vssh daemon target.
		cmdShell(os.Args[1:])
	}
}

func printUsage() {
	fmt.Print(`vssh - AI-native remote execution daemon (no sshd required)

Usage:
  vssh server [-p port]       Run vssh server daemon
  vssh shell <host[:port]>    Interactive shell (native protocol)
  vssh run <host> <cmd>       Execute command (native protocol)
  vssh run-many <hosts> <cmd> Execute command on comma-separated hosts
  vssh rpc <host> <method> [json]  Call native typed RPC
  vssh rpc-many <hosts> <method> [json]  Call RPC on comma-separated hosts
  vssh facts <host>           Return typed daemon facts as JSON
  vssh facts-many <hosts>     Return facts for comma-separated hosts
  vssh job-start <host> <cmd> Start a long-running daemon job
  vssh job-status <host> <id> Return job status
  vssh job-logs <host> <id>   Return job logs
  vssh job-cancel <host> <id> Cancel a running job
  vssh artifact-collect <host> <path> [max-bytes] Collect file/dir artifact metadata
  vssh put <file> <host:path> Upload file (native protocol)
  vssh get <host:path> <file> Download file (native protocol)
  vssh <host[:port]>          Interactive shell (native protocol)
  vssh exec <host> <cmd>      Alias for native run
  vssh bench <host> [count]   Measure native exec latency

  vssh status                 Show connection status
  vssh list                   List all peers
  vssh agent                  Run monitoring agent
  vssh mcp                    Run MCP JSON-RPC server

Examples:
  vssh server                    # Start server on :48291
  vssh shell web1                # Interactive shell to web1
	vssh run db1 "df -h"           # Run command on db1
  vssh run-many d1,v3 "uptime"    # Run in parallel
  vssh rpc d1 get_disk            # Typed disk facts
  vssh facts d1                   # Typed node facts
  vssh facts-many d1,v3           # Parallel typed node facts
  vssh job-start d1 "sleep 30"    # Start async job
  vssh bench db1 20              # Measure native exec latency
	vssh put file.tar web1:/tmp/   # Upload file
  vssh get web1:/var/log/x .     # Download file

Environment:
  VSSH_SECRET              Shared secret for native protocol (required unless derived; see below)
  VSSH_PORT                Server port (default: 48291)
  WIRE_SERVER_URL          If set (and VSSH_SECRET empty), secret is derived for mesh-style deploys
  VSSH_INSECURE_ALLOW_EMPTY_SECRET=1   Lab only: allow empty native secret (unsafe)

`)
}

const defaultPort = 48291

func getSecret() string {
	if s := strings.TrimSpace(os.Getenv("VSSH_SECRET")); s != "" {
		return s
	}
	// Standalone: derive from WIRE_SERVER_URL or ~/.wire/config.json server_url (no wire binary dependency).
	return server.GetSecret()
}

func getPort() int {
	if p := os.Getenv("VSSH_PORT"); p != "" {
		if port, err := strconv.Atoi(p); err == nil {
			return port
		}
	}
	return defaultPort
}

func cmdServer(args []string) {
	port := getPort()
	for i := 0; i < len(args); i++ {
		if args[i] == "-p" && i+1 < len(args) {
			if p, err := strconv.Atoi(args[i+1]); err == nil {
				port = p
			}
			i++
		}
	}

	secret := getSecret()
	if secret == "" {
		if os.Getenv("VSSH_INSECURE_ALLOW_EMPTY_SECRET") == "1" {
			fmt.Fprintln(os.Stderr, "WARNING: VSSH_INSECURE_ALLOW_EMPTY_SECRET=1 — native server auth is disabled; lab use only.")
		} else {
			fmt.Fprintln(os.Stderr, "vssh server: refusing to start without an authentication secret.")
			fmt.Fprintln(os.Stderr, "  Set VSSH_SECRET to a long random value, or set WIRE_SERVER_URL / ~/.wire config server_url for derived secret.")
			fmt.Fprintln(os.Stderr, "  WireGuard only protects the VPN overlay; the vssh native TCP port must still be authenticated and firewalled.")
			fmt.Fprintln(os.Stderr, "  Lab override: VSSH_INSECURE_ALLOW_EMPTY_SECRET=1")
			os.Exit(1)
		}
	}

	srv := server.NewServer(port, secret)
	fmt.Printf("vsshd starting on :%d\n", port)
	if err := srv.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "Server error: %v\n", err)
		os.Exit(1)
	}
}

func cmdShell(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "Usage: vssh shell <host[:port]>")
		os.Exit(1)
	}

	host, port := parseHostPort(args[0])
	secret := getSecret()
	host = resolveNativeHost(host)

	if err := server.Connect(host, port, secret); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}

func cmdRun(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh run <host[:port]> <command>")
		os.Exit(1)
	}

	host, port := parseHostPort(args[0])
	command := strings.Join(args[1:], " ")
	secret := getSecret()
	host = resolveNativeHost(host)

	result, err := server.ExecCommandStructured(host, port, secret, command)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	fmt.Print(result.Stdout)
	fmt.Fprint(os.Stderr, result.Stderr)
	if !result.Success {
		if result.Error != "" {
			fmt.Fprintln(os.Stderr, result.Error)
		}
		if result.ExitCode > 0 {
			os.Exit(result.ExitCode)
		}
		os.Exit(1)
	}
}

type multiExecResult struct {
	Target string                    `json:"target"`
	Result *server.ExecCommandResult `json:"result,omitempty"`
	Error  string                    `json:"error,omitempty"`
}

type multiRPCResult struct {
	Target string              `json:"target"`
	Result *server.RPCResponse `json:"result,omitempty"`
	Error  string              `json:"error,omitempty"`
}

type multiFactsResult struct {
	Target string             `json:"target"`
	Result *server.ServerInfo `json:"result,omitempty"`
	Error  string             `json:"error,omitempty"`
}

func cmdRunMany(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh run-many <host1,host2> <command>")
		os.Exit(1)
	}
	targets := splitTargets(args[0])
	command := strings.Join(args[1:], " ")
	results := runMany(targets, command, 30*time.Second, defaultMaxParallelism())
	writeJSON(results)
}

func cmdRPC(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh rpc <host[:port]> <method> [json-params]")
		os.Exit(1)
	}
	target := args[0]
	method := args[1]
	params := parseJSONParams(args[2:])
	resp, err := callRPCNative(target, method, params, 30*time.Second)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	writeJSON(resp)
}

func cmdRPCMany(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh rpc-many <host1,host2> <method> [json-params]")
		os.Exit(1)
	}
	targets := splitTargets(args[0])
	method := args[1]
	params := parseJSONParams(args[2:])
	results := rpcMany(targets, method, params, 30*time.Second, defaultMaxParallelism())
	writeJSON(results)
}

func cmdFacts(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "Usage: vssh facts <host[:port]>")
		os.Exit(1)
	}
	host, port := parseHostPort(args[0])
	resolved := resolveNativeHost(host)
	info, err := server.GetInfo(resolved, port, getSecret(), 30*time.Second)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	writeJSON(info)
}

func cmdFactsMany(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "Usage: vssh facts-many <host1,host2>")
		os.Exit(1)
	}
	results := factsMany(splitTargets(args[0]), 30*time.Second, defaultMaxParallelism())
	writeJSON(results)
}

func cmdJobStart(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh job-start <host[:port]> <command>")
		os.Exit(1)
	}
	resp, err := callRPCNative(args[0], "job_start", map[string]interface{}{"command": strings.Join(args[1:], " ")}, 30*time.Second)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	writeJSON(resp)
}

func cmdJobStatus(args []string) {
	if len(args) != 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh job-status <host[:port]> <id>")
		os.Exit(1)
	}
	writeJobRPC(args[0], "job_status", args[1])
}

func cmdJobLogs(args []string) {
	if len(args) < 2 || len(args) > 3 {
		fmt.Fprintln(os.Stderr, "Usage: vssh job-logs <host[:port]> <id> [tail-bytes]")
		os.Exit(1)
	}
	params := map[string]interface{}{"id": args[1]}
	if len(args) == 3 {
		if n, err := strconv.Atoi(args[2]); err == nil {
			params["tail_bytes"] = n
		}
	}
	resp, err := callRPCNative(args[0], "job_logs", params, 30*time.Second)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	writeJSON(resp)
}

func cmdJobCancel(args []string) {
	if len(args) != 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh job-cancel <host[:port]> <id>")
		os.Exit(1)
	}
	writeJobRPC(args[0], "job_cancel", args[1])
}

func cmdArtifactCollect(args []string) {
	if len(args) < 2 || len(args) > 3 {
		fmt.Fprintln(os.Stderr, "Usage: vssh artifact-collect <host[:port]> <path> [max-bytes]")
		os.Exit(1)
	}
	params := map[string]interface{}{"path": args[1]}
	if len(args) == 3 {
		if n, err := strconv.Atoi(args[2]); err == nil {
			params["max_bytes"] = n
		}
	}
	resp, err := callRPCNative(args[0], "artifact_collect", params, 30*time.Second)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	writeJSON(resp)
}

func writeJobRPC(target, method, id string) {
	resp, err := callRPCNative(target, method, map[string]interface{}{"id": id}, 30*time.Second)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	writeJSON(resp)
}

func splitTargets(s string) []string {
	parts := strings.Split(s, ",")
	targets := make([]string, 0, len(parts))
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part != "" {
			targets = append(targets, part)
		}
	}
	return targets
}

func parseJSONParams(parts []string) map[string]interface{} {
	if len(parts) == 0 {
		return map[string]interface{}{}
	}
	raw := strings.Join(parts, " ")
	var params map[string]interface{}
	if err := json.Unmarshal([]byte(raw), &params); err != nil {
		fmt.Fprintf(os.Stderr, "Invalid JSON params: %v\n", err)
		os.Exit(1)
	}
	return params
}

func callRPCNative(target, method string, params map[string]interface{}, timeout time.Duration) (*server.RPCResponse, error) {
	host, port := parseHostPort(target)
	host = resolveNativeHost(host)
	resp, err := server.CallRPC(host, port, getSecret(), method, params, timeout)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

func runMany(targets []string, command string, timeout time.Duration, maxParallelism int) []multiExecResult {
	results := make([]multiExecResult, len(targets))
	sem := make(chan struct{}, normalizedMaxParallelism(maxParallelism, len(targets)))
	var wg sync.WaitGroup
	for i, target := range targets {
		i, target := i, target
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			host, port := parseHostPort(target)
			host = resolveNativeHost(host)
			result, err := server.ExecCommandStructuredTimeout(host, port, getSecret(), command, timeout)
			results[i].Target = target
			if err != nil {
				results[i].Error = err.Error()
				return
			}
			results[i].Result = &result
		}()
	}
	wg.Wait()
	return results
}

func rpcMany(targets []string, method string, params map[string]interface{}, timeout time.Duration, maxParallelism int) []multiRPCResult {
	results := make([]multiRPCResult, len(targets))
	sem := make(chan struct{}, normalizedMaxParallelism(maxParallelism, len(targets)))
	var wg sync.WaitGroup
	for i, target := range targets {
		i, target := i, target
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			resp, err := callRPCNative(target, method, params, timeout)
			results[i].Target = target
			if err != nil {
				results[i].Error = err.Error()
				return
			}
			results[i].Result = resp
		}()
	}
	wg.Wait()
	return results
}

func factsMany(targets []string, timeout time.Duration, maxParallelism int) []multiFactsResult {
	results := make([]multiFactsResult, len(targets))
	sem := make(chan struct{}, normalizedMaxParallelism(maxParallelism, len(targets)))
	var wg sync.WaitGroup
	for i, target := range targets {
		i, target := i, target
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			host, port := parseHostPort(target)
			host = resolveNativeHost(host)
			info, err := server.GetInfo(host, port, getSecret(), timeout)
			results[i].Target = target
			if err != nil {
				results[i].Error = err.Error()
				return
			}
			results[i].Result = info
		}()
	}
	wg.Wait()
	return results
}

func defaultMaxParallelism() int {
	if value := strings.TrimSpace(os.Getenv("VSSH_MAX_PARALLELISM")); value != "" {
		if parsed, err := strconv.Atoi(value); err == nil {
			return parsed
		}
	}
	return 16
}

func normalizedMaxParallelism(maxParallelism, total int) int {
	if total <= 0 {
		return 1
	}
	if maxParallelism <= 0 {
		return total
	}
	if maxParallelism > total {
		return total
	}
	return maxParallelism
}

func writeJSON(value interface{}) {
	data, _ := json.MarshalIndent(value, "", "  ")
	fmt.Println(string(data))
}

func cmdPut(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh put <local-file> <host[:port]:remote-path>")
		os.Exit(1)
	}

	localPath := args[0]
	remote := args[1]

	// Parse host:path
	idx := strings.LastIndex(remote, ":")
	if idx == -1 {
		fmt.Fprintln(os.Stderr, "Error: remote path must be host:path format")
		os.Exit(1)
	}

	hostPart := remote[:idx]
	remotePath := remote[idx+1:]
	host, port := parseHostPort(hostPart)
	secret := getSecret()
	host = resolveNativeHost(host)

	if err := server.SendFile(host, port, secret, localPath, remotePath); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}

func cmdGet(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh get <host[:port]:remote-path> <local-file>")
		os.Exit(1)
	}

	remote := args[0]
	localPath := args[1]

	// Parse host:path
	idx := strings.LastIndex(remote, ":")
	if idx == -1 {
		fmt.Fprintln(os.Stderr, "Error: remote path must be host:path format")
		os.Exit(1)
	}

	hostPart := remote[:idx]
	remotePath := remote[idx+1:]
	host, port := parseHostPort(hostPart)
	secret := getSecret()
	host = resolveNativeHost(host)

	if err := server.RecvFile(host, port, secret, remotePath, localPath); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}

func parseHostPort(s string) (string, int) {
	if idx := strings.LastIndex(s, ":"); idx != -1 {
		host := s[:idx]
		if port, err := strconv.Atoi(s[idx+1:]); err == nil {
			return host, port
		}
	}
	return s, getPort()
}

func resolveNativeHost(target string) string {
	connector, err := ssh.NewConnector("default")
	if err != nil {
		return target
	}
	host, err := connector.ResolveHost(target)
	if err != nil || host == "" {
		return target
	}
	return host
}

func cmdStatus() {
	connector, err := ssh.NewConnector("default")
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}

	fmt.Print(connector.Status())
}

func cmdList() {
	connector, err := ssh.NewConnector("default")
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}

	peers := connector.ListPeers()
	if len(peers) == 0 {
		fmt.Println("No peers found")
		return
	}

	fmt.Println("Peers:")
	fmt.Println("───────────────────────────────────────────")
	fmt.Printf("%-12s %-15s %-15s %s\n", "NAME", "VPN IP", "PUBLIC IP", "LAN IP")
	fmt.Println("───────────────────────────────────────────")
	for _, p := range peers {
		fmt.Printf("%-12s %-15s %-15s %s\n", p.NodeName, p.VpnIP, p.PublicIP, p.LanIP)
	}
}

func cmdExec(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: vssh exec <host[:port]> <command...>")
		os.Exit(1)
	}
	cmdRun(args)
}

func cmdBench(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "Usage: vssh bench <host[:port]> [count]")
		os.Exit(1)
	}

	host, port := parseHostPort(args[0])
	count := 20
	if len(args) >= 2 {
		if n, err := strconv.Atoi(args[1]); err == nil && n > 0 {
			count = n
		}
	}
	if count > 500 {
		count = 500
	}

	secret := getSecret()
	resolved := resolveNativeHost(host)
	latencies := make([]time.Duration, 0, count)
	failures := 0

	for i := 0; i < count; i++ {
		start := time.Now()
		result, err := server.ExecCommandStructuredTimeout(resolved, port, secret, ":", 5*time.Second)
		elapsed := time.Since(start)
		if err != nil || !result.Success {
			failures++
			continue
		}
		latencies = append(latencies, elapsed)
	}

	if len(latencies) == 0 {
		fmt.Printf("vssh bench %s (%s:%d): all %d attempts failed\n", host, resolved, port, count)
		os.Exit(1)
	}

	sort.Slice(latencies, func(i, j int) bool { return latencies[i] < latencies[j] })
	var total time.Duration
	for _, latency := range latencies {
		total += latency
	}
	avg := total / time.Duration(len(latencies))
	p50 := percentileLatency(latencies, 50)
	p95 := percentileLatency(latencies, 95)

	fmt.Printf("vssh bench %s (%s:%d)\n", host, resolved, port)
	fmt.Printf("  attempts: %d ok, %d failed\n", len(latencies), failures)
	fmt.Printf("  min:      %s\n", latencies[0].Round(time.Microsecond))
	fmt.Printf("  p50:      %s\n", p50.Round(time.Microsecond))
	fmt.Printf("  avg:      %s\n", avg.Round(time.Microsecond))
	fmt.Printf("  p95:      %s\n", p95.Round(time.Microsecond))
	fmt.Printf("  max:      %s\n", latencies[len(latencies)-1].Round(time.Microsecond))
}

func percentileLatency(values []time.Duration, percentile int) time.Duration {
	if len(values) == 0 {
		return 0
	}
	if percentile <= 0 {
		return values[0]
	}
	if percentile >= 100 {
		return values[len(values)-1]
	}
	idx := (len(values)*percentile + 99) / 100
	if idx <= 0 {
		idx = 1
	}
	if idx > len(values) {
		idx = len(values)
	}
	return values[idx-1]
}

func cmdAgent(args []string) {
	cfg := agent.DefaultConfig()

	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-l", "--log":
			if i+1 < len(args) {
				cfg.EventLogPath = args[i+1]
				i++
			}
		}
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sigCh
		fmt.Println("\nShutting down agent...")
		cancel()
	}()

	a := agent.New(cfg)
	if err := a.Run(ctx); err != nil && err != context.Canceled {
		fmt.Fprintf(os.Stderr, "Agent error: %v\n", err)
		os.Exit(1)
	}
}

func cmdSetup() {
	fmt.Println("vssh Setup")
	fmt.Println("──────────────────────────────────")

	home, _ := os.UserHomeDir()
	configDir := home + "/.vssh"

	// Create config directory
	if err := os.MkdirAll(configDir, 0755); err != nil {
		fmt.Fprintf(os.Stderr, "Error creating config dir: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("✓ Config directory: %s\n", configDir)

	// Check SSH key
	sshKey := home + "/.ssh/id_ed25519"
	if _, err := os.Stat(sshKey); err == nil {
		fmt.Println("✓ SSH key found")
	} else {
		fmt.Println("○ No SSH key (will use password auth)")
	}

	fmt.Println()
	fmt.Println("Setup complete!")
	fmt.Println()
	fmt.Println("Usage:")
	fmt.Println("  vssh server          # Start native daemon")
	fmt.Println("  vssh <hostname>      # Connect to native daemon")
	fmt.Println("  vssh list            # Show all peers")
}
