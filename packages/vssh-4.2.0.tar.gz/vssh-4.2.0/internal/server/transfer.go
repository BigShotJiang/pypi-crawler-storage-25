package server

import (
	"bufio"
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// SendFile sends a file to remote host
func SendFile(host string, port int, secret, localPath, remotePath string) error {
	// Open local file
	f, err := os.Open(localPath)
	if err != nil {
		return err
	}
	defer f.Close()

	stat, err := f.Stat()
	if err != nil {
		return err
	}

	// Connect
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 5*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()

	// Auth
	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, err := reader.ReadString('\n')
	if err != nil || resp[:7] != "AUTH_OK" {
		return fmt.Errorf("auth failed")
	}

	// Send transfer command: PUT <size> <path>
	if remotePath == "" {
		remotePath = filepath.Base(localPath)
	}
	cmd := fmt.Sprintf("PUT %d %s\n", stat.Size(), remotePath)
	conn.Write([]byte(cmd))

	// Read ready
	resp, err = reader.ReadString('\n')
	if err != nil || resp[:5] != "READY" {
		return fmt.Errorf("server not ready: %s", resp)
	}

	// Send file data
	n, err := io.Copy(conn, f)
	if err != nil {
		return err
	}

	// Read confirmation
	resp, err = reader.ReadString('\n')
	if err != nil {
		return fmt.Errorf("no confirmation")
	}
	if resp[:2] != "OK" {
		return fmt.Errorf("transfer failed: %s", resp)
	}

	fmt.Printf("Sent %d bytes\n", n)
	return nil
}

// RecvFile receives a file from remote host
func RecvFile(host string, port int, secret, remotePath, localPath string) error {
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 5*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()

	// Auth
	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, err := reader.ReadString('\n')
	if err != nil || resp[:7] != "AUTH_OK" {
		return fmt.Errorf("auth failed")
	}

	// Send GET command
	cmd := fmt.Sprintf("GET %s\n", remotePath)
	conn.Write([]byte(cmd))

	// Read size
	resp, err = reader.ReadString('\n')
	if err != nil {
		return err
	}
	var size int64
	if _, err := fmt.Sscanf(resp, "SIZE %d", &size); err != nil {
		return fmt.Errorf("invalid response: %s", resp)
	}

	// Create local file
	if localPath == "" {
		localPath = filepath.Base(remotePath)
	}
	f, err := os.Create(localPath)
	if err != nil {
		return err
	}
	defer f.Close()

	// Receive data (use reader to handle buffered data)
	n, err := io.CopyN(f, reader, size)
	if err != nil {
		return err
	}

	fmt.Printf("Received %d bytes\n", n)
	return nil
}

// HandleTransfer handles file transfer on server side
func HandleTransfer(conn net.Conn, cmd string) {
	if len(cmd) < 4 {
		conn.Write([]byte("ERROR invalid command\n"))
		return
	}

	if strings.HasPrefix(cmd, "EXEJ ") {
		encoded := strings.TrimSpace(strings.TrimPrefix(cmd, "EXEJ "))
		raw, err := base64.StdEncoding.DecodeString(encoded)
		if err != nil {
			writeExecJSON(conn, ExecCommandResult{
				Success:  false,
				ExitCode: -1,
				Error:    "invalid base64 command",
			})
			return
		}
		result := ExecLocalStructured(string(raw))
		writeExecJSON(conn, result)
		return
	}

	switch cmd[:3] {
	case "PUT":
		var size int64
		var path string
		fmt.Sscanf(cmd, "PUT %d %s", &size, &path)
		transferUser := effectiveTransferUser()

		// Expand ~ to the effective transfer user. When vsshd runs as root,
		// this keeps Runtime staging files usable by the same non-root user
		// that command execution selects.
		path = expandTransferPath(path, transferUser)

		// Create directory if needed
		dir := filepath.Dir(path)
		os.MkdirAll(dir, 0755)
		chownToTransferUser(dir, transferUser)

		f, err := os.Create(path)
		if err != nil {
			conn.Write([]byte(fmt.Sprintf("ERROR %v\n", err)))
			return
		}
		defer f.Close()

		conn.Write([]byte("READY\n"))

		n, err := io.CopyN(f, conn, size)
		if err != nil {
			conn.Write([]byte(fmt.Sprintf("ERROR %v\n", err)))
			return
		}
		_ = f.Chmod(0644)
		chownToTransferUser(path, transferUser)
		conn.Write([]byte(fmt.Sprintf("OK %d\n", n)))

	case "GET":
		path := cmd[4:]
		path = path[:len(path)-1] // remove newline
		transferUser := effectiveTransferUser()

		// Expand ~ consistently with PUT.
		path = expandTransferPath(path, transferUser)

		f, err := os.Open(path)
		if err != nil {
			conn.Write([]byte(fmt.Sprintf("ERROR %v\n", err)))
			return
		}
		defer f.Close()

		stat, _ := f.Stat()
		conn.Write([]byte(fmt.Sprintf("SIZE %d\n", stat.Size())))
		io.Copy(conn, f)

	case "EXE": // EXEC
		cmdStr := cmd[5:]
		if len(cmdStr) > 0 && cmdStr[len(cmdStr)-1] == '\n' {
			cmdStr = cmdStr[:len(cmdStr)-1]
		}

		// Execute command
		out, err := execShell(cmdStr)
		if err != nil {
			conn.Write([]byte(fmt.Sprintf("ERROR: %v\n%s", err, out)))
		} else {
			conn.Write(out)
		}
	}
}

func effectiveTransferUser() *user.User {
	if os.Getuid() != 0 {
		return nil
	}
	defaultUser := getDefaultUser()
	if defaultUser == "" || defaultUser == "root" {
		return nil
	}
	u, err := user.Lookup(defaultUser)
	if err != nil {
		return nil
	}
	return u
}

func expandTransferPath(path string, transferUser *user.User) string {
	if len(path) == 0 || path[0] != '~' {
		return path
	}
	if transferUser != nil && transferUser.HomeDir != "" {
		return transferUser.HomeDir + path[1:]
	}
	home, _ := os.UserHomeDir()
	return home + path[1:]
}

func chownToTransferUser(path string, transferUser *user.User) {
	if transferUser == nil {
		return
	}
	uid, uidErr := strconv.Atoi(transferUser.Uid)
	gid, gidErr := strconv.Atoi(transferUser.Gid)
	if uidErr != nil || gidErr != nil {
		return
	}
	_ = os.Chown(path, uid, gid)
}

func execShell(cmdStr string) ([]byte, error) {
	shell := "/bin/bash"
	if _, err := os.Stat("/bin/zsh"); err == nil {
		shell = "/bin/zsh"
	}

	// If running as root, switch to default user
	if os.Getuid() == 0 {
		defaultUser := getDefaultUser()
		if defaultUser != "" && defaultUser != "root" {
			// Use sudo -u to run as the default user (works without password when root)
			cmd := exec.Command("sudo", "-u", defaultUser, "-i", shell, "-c", cmdStr)
			out, err := cmd.CombinedOutput()
			// Prepend user info for debugging
			prefix := []byte(fmt.Sprintf("[wire-user:%s] ", defaultUser))
			return append(prefix, out...), err
		}
	}

	cmd := exec.Command(shell, "-c", cmdStr)
	return cmd.CombinedOutput()
}

// ExecCommandResult is the AI/runtime-oriented native execution envelope.
type ExecCommandResult struct {
	Success    bool   `json:"success"`
	Command    string `json:"command,omitempty"`
	Stdout     string `json:"stdout"`
	Stderr     string `json:"stderr"`
	ExitCode   int    `json:"exit_code"`
	DurationMs int64  `json:"duration_ms"`
	Error      string `json:"error,omitempty"`
}

func writeExecJSON(conn net.Conn, result ExecCommandResult) {
	data, _ := json.Marshal(result)
	conn.Write(data)
	conn.Write([]byte("\n"))
}

func execShellStructured(cmdStr string) ExecCommandResult {
	start := time.Now()
	result := ExecCommandResult{
		Command:  cmdStr,
		ExitCode: -1,
	}

	shell := "/bin/bash"
	if _, err := os.Stat("/bin/zsh"); err == nil {
		shell = "/bin/zsh"
	}

	var cmd *exec.Cmd
	if os.Getuid() == 0 {
		defaultUser := getDefaultUser()
		if defaultUser != "" && defaultUser != "root" {
			cmd = exec.Command("sudo", "-u", defaultUser, "-i", shell, "-c", cmdStr)
		}
	}
	if cmd == nil {
		cmd = exec.Command(shell, "-c", cmdStr)
	}

	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()

	result.DurationMs = time.Since(start).Milliseconds()
	result.Stdout = stdout.String()
	result.Stderr = stderr.String()
	if err == nil {
		result.Success = true
		result.ExitCode = 0
		return result
	}
	if exitErr, ok := err.(*exec.ExitError); ok {
		result.ExitCode = exitErr.ExitCode()
	} else {
		result.Error = err.Error()
	}
	return result
}

// getDefaultUser returns the primary non-root user
func getDefaultUser() string {
	// Check environment variable first
	if u := os.Getenv("WIRE_DEFAULT_USER"); u != "" {
		return u
	}

	// Try to find first valid user in /home
	entries, err := os.ReadDir("/home")
	if err == nil {
		for _, e := range entries {
			if e.IsDir() {
				name := e.Name()
				// Skip common system directories
				if name == "lost+found" {
					continue
				}
				// Verify user exists in system
				if _, err := user.Lookup(name); err == nil {
					return name
				}
			}
		}
	}

	// Synology: check /volume1/homes
	entries, err = os.ReadDir("/volume1/homes")
	if err == nil {
		for _, e := range entries {
			if e.IsDir() && e.Name() != "admin" {
				name := e.Name()
				if _, err := user.Lookup(name); err == nil {
					return name
				}
			}
		}
	}

	return ""
}

// ExecLocal executes command locally
func ExecLocal(command string) (string, error) {
	out, err := execShell(command)
	return string(out), err
}

// ExecLocalStructured executes command locally and returns stdout/stderr/exit.
func ExecLocalStructured(command string) ExecCommandResult {
	return execShellStructured(command)
}

// ExecCommand executes a command on remote host
func ExecCommand(host string, port int, secret, command string) (string, error) {
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 30*time.Second)
	if err != nil {
		return "", err
	}
	defer conn.Close()

	// Auth - use raw reads to avoid buffering issues
	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	// Read AUTH response
	conn.SetReadDeadline(time.Now().Add(5 * time.Second))
	authBuf := make([]byte, 64)
	n, err := conn.Read(authBuf)
	if err != nil || n < 7 || string(authBuf[:7]) != "AUTH_OK" {
		return "", fmt.Errorf("auth failed")
	}

	// Send EXEC command
	conn.Write([]byte(fmt.Sprintf("EXEC %s\n", command)))

	// Read output with timeout
	conn.SetReadDeadline(time.Now().Add(30 * time.Second))
	var output []byte
	buf := make([]byte, 4096)
	for {
		n, err := conn.Read(buf)
		if err != nil {
			break
		}
		output = append(output, buf[:n]...)
		// Reset deadline on successful read
		conn.SetReadDeadline(time.Now().Add(5 * time.Second))
	}

	return string(output), nil
}

// ExecCommandStructured executes a command through the native daemon and returns
// a machine-readable execution envelope.
func ExecCommandStructured(host string, port int, secret, command string) (ExecCommandResult, error) {
	return ExecCommandStructuredTimeout(host, port, secret, command, 30*time.Second)
}

// ExecCommandStructuredTimeout executes a command with a caller-supplied network
// deadline. Short deadlines are useful for latency probes and fleet fan-out.
func ExecCommandStructuredTimeout(host string, port int, secret, command string, deadline time.Duration) (ExecCommandResult, error) {
	if deadline <= 0 {
		deadline = 30 * time.Second
	}

	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), deadline)
	if err != nil {
		return ExecCommandResult{Success: false, Command: command, ExitCode: -1, Error: err.Error()}, err
	}
	defer conn.Close()

	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	authDeadline := deadline
	if authDeadline > 5*time.Second {
		authDeadline = 5 * time.Second
	}
	conn.SetReadDeadline(time.Now().Add(authDeadline))
	authBuf := make([]byte, 64)
	n, err := conn.Read(authBuf)
	if err != nil || n < 7 || string(authBuf[:7]) != "AUTH_OK" {
		authErr := fmt.Errorf("auth failed")
		return ExecCommandResult{Success: false, Command: command, ExitCode: -1, Error: authErr.Error()}, authErr
	}

	encoded := base64.StdEncoding.EncodeToString([]byte(command))
	conn.Write([]byte(fmt.Sprintf("EXEJ %s\n", encoded)))

	conn.SetReadDeadline(time.Now().Add(deadline))
	reader := bufio.NewReader(conn)
	line, err := reader.ReadBytes('\n')
	if err != nil {
		return ExecCommandResult{Success: false, Command: command, ExitCode: -1, Error: err.Error()}, err
	}

	var result ExecCommandResult
	if err := json.Unmarshal(line, &result); err != nil {
		return ExecCommandResult{Success: false, Command: command, ExitCode: -1, Error: err.Error()}, err
	}
	if result.Command == "" {
		result.Command = command
	}
	return result, nil
}

// CallRPC invokes a typed RPC method through the native daemon.
func CallRPC(host string, port int, secret, method string, params map[string]interface{}, deadline time.Duration) (RPCResponse, error) {
	if deadline <= 0 {
		deadline = 30 * time.Second
	}
	var zero RPCResponse

	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), deadline)
	if err != nil {
		return zero, err
	}
	defer conn.Close()

	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	authDeadline := deadline
	if authDeadline > 5*time.Second {
		authDeadline = 5 * time.Second
	}
	conn.SetReadDeadline(time.Now().Add(authDeadline))
	authBuf := make([]byte, 64)
	n, err := conn.Read(authBuf)
	if err != nil || n < 7 || string(authBuf[:7]) != "AUTH_OK" {
		return zero, fmt.Errorf("auth failed")
	}

	paramsJSON, _ := json.Marshal(params)
	conn.Write([]byte(fmt.Sprintf("RPC %s %d\n", method, len(paramsJSON))))
	if len(paramsJSON) > 0 {
		conn.Write(paramsJSON)
	}

	conn.SetReadDeadline(time.Now().Add(deadline))
	reader := bufio.NewReader(conn)
	line, err := reader.ReadBytes('\n')
	if err != nil {
		return zero, err
	}

	var resp RPCResponse
	if err := json.Unmarshal(line, &resp); err != nil {
		return zero, err
	}
	return resp, nil
}

// GetInfo returns native daemon facts through the INFO command.
func GetInfo(host string, port int, secret string, deadline time.Duration) (*ServerInfo, error) {
	if deadline <= 0 {
		deadline = 30 * time.Second
	}

	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), deadline)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	authDeadline := deadline
	if authDeadline > 5*time.Second {
		authDeadline = 5 * time.Second
	}
	conn.SetReadDeadline(time.Now().Add(authDeadline))
	authBuf := make([]byte, 64)
	n, err := conn.Read(authBuf)
	if err != nil || n < 7 || string(authBuf[:7]) != "AUTH_OK" {
		return nil, fmt.Errorf("auth failed")
	}

	conn.Write([]byte("INFO\n"))
	conn.SetReadDeadline(time.Now().Add(deadline))
	data, err := io.ReadAll(conn)
	if err != nil {
		return nil, err
	}

	var info ServerInfo
	if err := json.Unmarshal(bytes.TrimSpace(data), &info); err != nil {
		return nil, err
	}
	return &info, nil
}
