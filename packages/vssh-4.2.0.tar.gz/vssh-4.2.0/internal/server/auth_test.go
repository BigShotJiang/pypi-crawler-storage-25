package server

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"testing"
)

func TestValidateAuthToken_roundTrip(t *testing.T) {
	secret := "test-secret-value-for-hmac"
	tok := GenerateAuthToken(secret)
	if !ValidateAuthToken(tok, secret) {
		t.Fatal("expected token to validate")
	}
}

func TestValidateAuthToken_wrongSecret(t *testing.T) {
	tok := GenerateAuthToken("secret-a")
	if ValidateAuthToken(tok, "secret-b") {
		t.Fatal("expected wrong secret to fail")
	}
}

func TestValidateAuthToken_expired(t *testing.T) {
	secret := "s"
	ts := int64(1)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(fmt.Sprintf("%d", ts)))
	sig := hex.EncodeToString(mac.Sum(nil))
	tok := fmt.Sprintf("%d:%s", ts, sig)
	if ValidateAuthToken(tok, secret) {
		t.Fatal("expected expired ts to fail")
	}
}

func TestValidateAuthToken_malformed(t *testing.T) {
	if ValidateAuthToken("not-a-token", "s") {
		t.Fatal("expected malformed to fail")
	}
	if ValidateAuthToken("abc:def", "s") {
		t.Fatal("expected bad ts to fail")
	}
}

func TestGetSecret_fromEnvWireURL(t *testing.T) {
	t.Setenv("WIRE_SERVER_URL", "https://coord.example:8790")
	t.Setenv("VSSH_SECRET", "")
	got := GetSecret()
	if got == "" {
		t.Fatal("expected derived non-empty secret")
	}
	if got2 := GetSecret(); got != got2 {
		t.Fatalf("expected stable secret, %q vs %q", got, got2)
	}
}
