package server

import (
	"bufio"
	"bytes"
	"compress/zlib"
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const (
	ChunkSizeSlow      = 256 * 1024      // 256KB for <10MB/s
	ChunkSizeMedium    = 1024 * 1024     // 1MB for 10-50MB/s
	ChunkSizeFast      = 4 * 1024 * 1024 // 4MB for >50MB/s
	ParallelStreams    = 8
	LargeFileThreshold = 100 * 1024 * 1024 // 100MB
)

// Compressible file extensions
var compressibleExts = map[string]bool{
	".txt": true, ".log": true, ".py": true, ".js": true,
	".json": true, ".md": true, ".xml": true, ".html": true,
	".css": true, ".go": true, ".rs": true, ".java": true,
	".c": true, ".h": true, ".cpp": true, ".hpp": true,
	".yaml": true, ".yml": true, ".toml": true, ".ini": true,
	".sh": true, ".bash": true, ".zsh": true, ".sql": true,
}

// TransferOptions configures transfer behavior
type TransferOptions struct {
	Compress       bool
	Resume         bool
	Parallel       int
	BandwidthLimit int64 // bytes per second, 0 = unlimited
	ChunkSize      int
}

// DefaultTransferOptions returns default options
func DefaultTransferOptions() *TransferOptions {
	return &TransferOptions{
		Compress:  true,
		Resume:    true,
		Parallel:  ParallelStreams,
		ChunkSize: ChunkSizeMedium,
	}
}

// ========== zlib Compression ==========

// shouldCompress checks if file should be compressed
func shouldCompress(path string) bool {
	ext := strings.ToLower(filepath.Ext(path))
	return compressibleExts[ext]
}

// compressData compresses data using zlib
func compressData(data []byte) ([]byte, error) {
	var buf bytes.Buffer
	w := zlib.NewWriter(&buf)
	_, err := w.Write(data)
	if err != nil {
		return nil, err
	}
	w.Close()
	return buf.Bytes(), nil
}

// decompressData decompresses zlib data
func decompressData(data []byte) ([]byte, error) {
	r, err := zlib.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer r.Close()
	return io.ReadAll(r)
}

// SendFileCompressed sends file with optional compression
func SendFileCompressed(host string, port int, secret, localPath, remotePath string, opts *TransferOptions) error {
	if opts == nil {
		opts = DefaultTransferOptions()
	}

	f, err := os.Open(localPath)
	if err != nil {
		return err
	}
	defer f.Close()

	stat, _ := f.Stat()
	size := stat.Size()

	// Read file content
	data, err := io.ReadAll(f)
	if err != nil {
		return err
	}

	// Check if should compress
	compress := opts.Compress && shouldCompress(localPath) && size > 1024
	var sendData []byte
	var compressedSize int64

	if compress {
		compressed, err := compressData(data)
		if err == nil && len(compressed) < int(float64(len(data))*0.9) {
			// Only use compression if >10% savings
			sendData = compressed
			compressedSize = int64(len(compressed))
		} else {
			compress = false
			sendData = data
		}
	} else {
		sendData = data
	}

	// Calculate MD5
	hash := md5.Sum(data)
	md5sum := hex.EncodeToString(hash[:])

	// Connect
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 10*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()

	// Auth
	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, _ := reader.ReadString('\n')
	if !strings.HasPrefix(resp, "AUTH_OK") {
		return fmt.Errorf("auth failed")
	}

	// Send command
	if remotePath == "" {
		remotePath = filepath.Base(localPath)
	}

	var cmd string
	if compress {
		cmd = fmt.Sprintf("PUTZ %d %d %s %s\n", compressedSize, size, md5sum, remotePath)
	} else {
		cmd = fmt.Sprintf("PUT %d %s\n", size, remotePath)
	}
	conn.Write([]byte(cmd))

	resp, _ = reader.ReadString('\n')
	if strings.HasPrefix(resp, "SKIP") {
		fmt.Println("File already exists with same content, skipping")
		return nil
	}
	if !strings.HasPrefix(resp, "READY") {
		return fmt.Errorf("server not ready: %s", resp)
	}

	// Send data with bandwidth limiting
	sent := 0
	chunkSize := opts.ChunkSize
	startTime := time.Now()

	for sent < len(sendData) {
		end := sent + chunkSize
		if end > len(sendData) {
			end = len(sendData)
		}

		n, err := conn.Write(sendData[sent:end])
		if err != nil {
			return err
		}
		sent += n

		// Bandwidth limiting
		if opts.BandwidthLimit > 0 {
			elapsed := time.Since(startTime).Seconds()
			expectedTime := float64(sent) / float64(opts.BandwidthLimit)
			if elapsed < expectedTime {
				time.Sleep(time.Duration((expectedTime - elapsed) * float64(time.Second)))
			}
		}
	}

	// Read confirmation
	resp, _ = reader.ReadString('\n')
	if !strings.HasPrefix(resp, "OK") {
		return fmt.Errorf("transfer failed: %s", resp)
	}

	elapsed := time.Since(startTime).Seconds()
	speed := float64(size) / elapsed / 1024 / 1024
	if compress {
		ratio := float64(compressedSize) / float64(size) * 100
		fmt.Printf("Sent %d bytes (compressed %.1f%%) at %.1f MB/s\n", size, ratio, speed)
	} else {
		fmt.Printf("Sent %d bytes at %.1f MB/s\n", size, speed)
	}
	return nil
}

// ========== Resume (Large File Transfer) ==========

// partialHash calculates MD5 of first N bytes
func partialHash(path string, n int64) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	hash := md5.New()
	io.CopyN(hash, f, n)
	return hex.EncodeToString(hash.Sum(nil)), nil
}

// SendFileResume sends file with resume support
func SendFileResume(host string, port int, secret, localPath, remotePath string) error {
	f, err := os.Open(localPath)
	if err != nil {
		return err
	}
	defer f.Close()

	stat, _ := f.Stat()
	size := stat.Size()

	// Calculate full MD5
	hash := md5.New()
	io.Copy(hash, f)
	fullMD5 := hex.EncodeToString(hash.Sum(nil))
	f.Seek(0, 0)

	// Connect
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 10*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()

	// Auth
	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, _ := reader.ReadString('\n')
	if !strings.HasPrefix(resp, "AUTH_OK") {
		return fmt.Errorf("auth failed")
	}

	if remotePath == "" {
		remotePath = filepath.Base(localPath)
	}

	// Check for existing partial transfer
	cmd := fmt.Sprintf("RESUME %s %d %s\n", remotePath, size, fullMD5)
	conn.Write([]byte(cmd))

	resp, _ = reader.ReadString('\n')
	resp = strings.TrimSpace(resp)

	var offset int64 = 0
	if strings.HasPrefix(resp, "SKIP") {
		fmt.Println("File already complete")
		return nil
	} else if strings.HasPrefix(resp, "CONTINUE") {
		fmt.Sscanf(resp, "CONTINUE %d", &offset)
		fmt.Printf("Resuming from %d bytes\n", offset)
		f.Seek(offset, 0)
	} else if strings.HasPrefix(resp, "RESTART") {
		offset = 0
	} else {
		return fmt.Errorf("unexpected response: %s", resp)
	}

	// Send remaining data
	remaining := size - offset
	buf := make([]byte, ChunkSizeMedium)
	sent := int64(0)
	startTime := time.Now()

	for sent < remaining {
		n, err := f.Read(buf)
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}

		written, err := conn.Write(buf[:n])
		if err != nil {
			return err
		}
		sent += int64(written)

		// Progress
		pct := float64(offset+sent) / float64(size) * 100
		fmt.Printf("\r  %.1f%% (%d/%d MB)", pct, (offset+sent)/1024/1024, size/1024/1024)
	}

	fmt.Println()

	// Confirm
	resp, _ = reader.ReadString('\n')
	if !strings.HasPrefix(resp, "OK") {
		return fmt.Errorf("transfer failed: %s", resp)
	}

	elapsed := time.Since(startTime).Seconds()
	speed := float64(sent) / elapsed / 1024 / 1024
	fmt.Printf("Transferred %d bytes at %.1f MB/s\n", sent, speed)
	return nil
}

// ========== Parallel Transfer ==========

// ParallelDownload downloads file using multiple connections
func ParallelDownload(host string, port int, secret, remotePath, localPath string, numConns int) error {
	if numConns <= 1 {
		return RecvFile(host, port, secret, remotePath, localPath)
	}

	// First, get file info
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 10*time.Second)
	if err != nil {
		return err
	}

	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, _ := reader.ReadString('\n')
	if !strings.HasPrefix(resp, "AUTH_OK") {
		conn.Close()
		return fmt.Errorf("auth failed")
	}

	// Request parallel download
	cmd := fmt.Sprintf("GETM %s %d\n", remotePath, numConns)
	conn.Write([]byte(cmd))

	resp, _ = reader.ReadString('\n')
	var sessionID string
	var size int64
	var hash string
	var actualConns int

	if _, err := fmt.Sscanf(resp, "OK %s %d %s %d", &sessionID, &size, &hash, &actualConns); err != nil {
		conn.Close()
		return fmt.Errorf("parallel download not supported: %s", resp)
	}
	conn.Close()

	// Create temp files for each chunk
	chunkSize := size / int64(actualConns)
	chunks := make([]string, actualConns)
	var wg sync.WaitGroup
	var mu sync.Mutex
	var downloadErr error

	for i := 0; i < actualConns; i++ {
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()

			offset := int64(idx) * chunkSize
			length := chunkSize
			if idx == actualConns-1 {
				length = size - offset // Last chunk gets remainder
			}

			chunkPath := fmt.Sprintf("%s.part%d", localPath, idx)
			chunks[idx] = chunkPath

			err := downloadChunk(host, port, secret, sessionID, idx, offset, length, chunkPath)
			if err != nil {
				mu.Lock()
				downloadErr = err
				mu.Unlock()
			}
		}(i)
	}

	wg.Wait()

	if downloadErr != nil {
		// Cleanup
		for _, chunk := range chunks {
			os.Remove(chunk)
		}
		return downloadErr
	}

	// Merge chunks
	out, err := os.Create(localPath)
	if err != nil {
		return err
	}
	defer out.Close()

	for _, chunk := range chunks {
		f, err := os.Open(chunk)
		if err != nil {
			return err
		}
		io.Copy(out, f)
		f.Close()
		os.Remove(chunk)
	}

	// Verify hash
	out.Seek(0, 0)
	h := md5.New()
	io.Copy(h, out)
	gotHash := hex.EncodeToString(h.Sum(nil))
	if gotHash != hash {
		return fmt.Errorf("hash mismatch: expected %s, got %s", hash, gotHash)
	}

	fmt.Printf("Downloaded %d bytes in %d parallel streams\n", size, actualConns)
	return nil
}

func downloadChunk(host string, port int, secret, sessionID string, idx int, offset, length int64, outPath string) error {
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 10*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()

	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, _ := reader.ReadString('\n')
	if !strings.HasPrefix(resp, "AUTH_OK") {
		return fmt.Errorf("auth failed")
	}

	cmd := fmt.Sprintf("GETC %s %d\n", sessionID, idx)
	conn.Write([]byte(cmd))

	resp, _ = reader.ReadString('\n')
	var respOffset, respLength int64
	if _, err := fmt.Sscanf(resp, "OK %d %d", &respOffset, &respLength); err != nil {
		return fmt.Errorf("chunk request failed: %s", resp)
	}

	f, err := os.Create(outPath)
	if err != nil {
		return err
	}
	defer f.Close()

	_, err = io.CopyN(f, reader, respLength)
	return err
}

// ========== Adaptive Chunking ==========

// measureSpeed measures transfer speed and returns optimal chunk size
func measureSpeed(conn net.Conn, testSize int) int {
	testData := make([]byte, testSize)
	start := time.Now()
	conn.Write(testData)
	elapsed := time.Since(start).Seconds()

	speedMBps := float64(testSize) / elapsed / 1024 / 1024

	if speedMBps < 10 {
		return ChunkSizeSlow
	} else if speedMBps < 50 {
		return ChunkSizeMedium
	}
	return ChunkSizeFast
}

// ========== Pipeline Mode ==========

// PipeUp sends stdin to remote file
func PipeUp(host string, port int, secret, remotePath string, r io.Reader) error {
	// Read all data first (for size)
	data, err := io.ReadAll(r)
	if err != nil {
		return err
	}

	hash := md5.Sum(data)
	md5sum := hex.EncodeToString(hash[:])

	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 10*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()

	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, _ := reader.ReadString('\n')
	if !strings.HasPrefix(resp, "AUTH_OK") {
		return fmt.Errorf("auth failed")
	}

	cmd := fmt.Sprintf("PIPE_UP %s %d %s\n", remotePath, len(data), md5sum)
	conn.Write([]byte(cmd))

	resp, _ = reader.ReadString('\n')
	if !strings.HasPrefix(resp, "READY") {
		return fmt.Errorf("server not ready: %s", resp)
	}

	conn.Write(data)

	resp, _ = reader.ReadString('\n')
	if !strings.HasPrefix(resp, "OK") {
		return fmt.Errorf("transfer failed: %s", resp)
	}

	return nil
}

// PipeDown receives remote command output to stdout
func PipeDown(host string, port int, secret, command string, w io.Writer) error {
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 10*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()

	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, _ := reader.ReadString('\n')
	if !strings.HasPrefix(resp, "AUTH_OK") {
		return fmt.Errorf("auth failed")
	}

	cmd := fmt.Sprintf("PIPE_DOWN %s\n", command)
	conn.Write([]byte(cmd))

	io.Copy(w, reader)
	return nil
}

// ========== Multiplexed Put (mput) ==========

// MultiPut sends multiple files over single connection
func MultiPut(host string, port int, secret string, localPaths []string, remoteDir string) error {
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 30*time.Second)
	if err != nil {
		return err
	}
	defer conn.Close()

	token := GenerateAuthToken(secret)
	conn.Write([]byte(token + "\n"))

	reader := bufio.NewReader(conn)
	resp, _ := reader.ReadString('\n')
	if !strings.HasPrefix(resp, "AUTH_OK") {
		return fmt.Errorf("auth failed")
	}

	cmd := fmt.Sprintf("MPUT %d\n", len(localPaths))
	conn.Write([]byte(cmd))

	resp, _ = reader.ReadString('\n')
	if !strings.HasPrefix(resp, "READY") {
		return fmt.Errorf("server not ready: %s", resp)
	}

	for _, localPath := range localPaths {
		f, err := os.Open(localPath)
		if err != nil {
			fmt.Printf("Skip %s: %v\n", localPath, err)
			continue
		}

		stat, _ := f.Stat()
		data, _ := io.ReadAll(f)
		f.Close()

		hash := md5.Sum(data)
		md5sum := hex.EncodeToString(hash[:])

		remotePath := filepath.Join(remoteDir, filepath.Base(localPath))
		fileCmd := fmt.Sprintf("FILE %s %d %s\n", remotePath, stat.Size(), md5sum)
		conn.Write([]byte(fileCmd))
		conn.Write(data)

		resp, _ := reader.ReadString('\n')
		if strings.HasPrefix(resp, "OK") {
			fmt.Printf("  %s -> %s\n", localPath, remotePath)
		} else {
			fmt.Printf("  %s: FAILED\n", localPath)
		}
	}

	conn.Write([]byte("DONE\n"))
	return nil
}

// ========== Server Handlers for Advanced Features ==========

// HandlePutZ handles compressed PUT
func HandlePutZ(conn net.Conn, cmd string) {
	var compressedSize, originalSize int64
	var md5sum, path string
	fmt.Sscanf(cmd, "PUTZ %d %d %s %s", &compressedSize, &originalSize, &md5sum, &path)
	transferUser := effectiveTransferUser()

	// Expand ~ consistently with basic PUT.
	path = expandTransferPath(path, transferUser)

	// Check existing file
	if existing, err := os.Open(path); err == nil {
		h := md5.New()
		io.Copy(h, existing)
		existing.Close()
		if hex.EncodeToString(h.Sum(nil)) == md5sum {
			conn.Write([]byte("SKIP\n"))
			return
		}
	}

	dir := filepath.Dir(path)
	os.MkdirAll(dir, 0755)
	chownToTransferUser(dir, transferUser)

	conn.Write([]byte("READY\n"))

	// Receive compressed data
	compressed := make([]byte, compressedSize)
	io.ReadFull(conn, compressed)

	// Decompress
	data, err := decompressData(compressed)
	if err != nil {
		conn.Write([]byte(fmt.Sprintf("ERROR decompress: %v\n", err)))
		return
	}

	// Verify MD5
	h := md5.Sum(data)
	if hex.EncodeToString(h[:]) != md5sum {
		conn.Write([]byte("ERROR md5 mismatch\n"))
		return
	}

	// Write file
	if err := os.WriteFile(path, data, 0644); err != nil {
		conn.Write([]byte(fmt.Sprintf("ERROR write: %v\n", err)))
		return
	}
	chownToTransferUser(path, transferUser)

	conn.Write([]byte(fmt.Sprintf("OK %d\n", originalSize)))
}

// HandleResume handles resume request
func HandleResume(conn net.Conn, cmd string) {
	var path string
	var size int64
	var md5sum string
	fmt.Sscanf(cmd, "RESUME %s %d %s", &path, &size, &md5sum)
	transferUser := effectiveTransferUser()

	// Expand ~ consistently with basic PUT.
	path = expandTransferPath(path, transferUser)

	tmpPath := path + ".tmp"

	// Check if complete file exists with matching hash
	if existing, err := os.Open(path); err == nil {
		h := md5.New()
		io.Copy(h, existing)
		existing.Close()
		if hex.EncodeToString(h.Sum(nil)) == md5sum {
			conn.Write([]byte("SKIP\n"))
			return
		}
	}

	// Check for partial file
	if stat, err := os.Stat(tmpPath); err == nil {
		offset := stat.Size()
		// Verify partial hash matches
		conn.Write([]byte(fmt.Sprintf("CONTINUE %d\n", offset)))

		// Append to temp file
		f, _ := os.OpenFile(tmpPath, os.O_APPEND|os.O_WRONLY, 0644)
		remaining := size - offset
		io.CopyN(f, conn, remaining)
		f.Close()
	} else {
		// Start fresh
		conn.Write([]byte("RESTART\n"))
		f, _ := os.Create(tmpPath)
		io.CopyN(f, conn, size)
		f.Close()
	}
	chownToTransferUser(tmpPath, transferUser)

	// Verify and rename
	data, _ := os.ReadFile(tmpPath)
	h := md5.Sum(data)
	if hex.EncodeToString(h[:]) == md5sum {
		os.Rename(tmpPath, path)
		chownToTransferUser(path, transferUser)
		conn.Write([]byte(fmt.Sprintf("OK %d\n", size)))
	} else {
		os.Remove(tmpPath)
		conn.Write([]byte("ERROR md5 mismatch\n"))
	}
}

// HandleMPut handles multiplexed put
func HandleMPut(conn net.Conn, cmd string) {
	var count int
	fmt.Sscanf(cmd, "MPUT %d", &count)

	conn.Write([]byte("READY\n"))

	reader := bufio.NewReader(conn)
	for i := 0; i < count; i++ {
		line, _ := reader.ReadString('\n')
		if strings.HasPrefix(line, "DONE") {
			break
		}

		var path string
		var size int64
		var md5sum string
		fmt.Sscanf(line, "FILE %s %d %s", &path, &size, &md5sum)
		transferUser := effectiveTransferUser()

		// Expand ~ consistently with basic PUT.
		path = expandTransferPath(path, transferUser)

		dir := filepath.Dir(path)
		os.MkdirAll(dir, 0755)
		chownToTransferUser(dir, transferUser)

		data := make([]byte, size)
		io.ReadFull(reader, data)

		h := md5.Sum(data)
		if hex.EncodeToString(h[:]) == md5sum {
			os.WriteFile(path, data, 0644)
			chownToTransferUser(path, transferUser)
			conn.Write([]byte("OK\n"))
		} else {
			conn.Write([]byte("ERROR md5 mismatch\n"))
		}
	}
}

// HandlePipeDown handles pipe download command
func HandlePipeDown(conn net.Conn, cmd string) {
	command := strings.TrimPrefix(cmd, "PIPE_DOWN ")
	command = strings.TrimSpace(command)

	out, _ := execShell(command)
	conn.Write(out)
}

// ========== Parallel Download Server Handlers ==========

var parallelSessions = make(map[string]*ParallelSession)
var sessionMu sync.Mutex

type ParallelSession struct {
	Path     string
	Size     int64
	Hash     string
	NumConns int
	Created  time.Time
}

// HandleGetM handles parallel download initialization
func HandleGetM(conn net.Conn, cmd string) {
	var path string
	var numConns int
	fmt.Sscanf(cmd, "GETM %s %d", &path, &numConns)

	// Expand ~
	if len(path) > 0 && path[0] == '~' {
		home, _ := os.UserHomeDir()
		path = home + path[1:]
	}

	f, err := os.Open(path)
	if err != nil {
		conn.Write([]byte(fmt.Sprintf("ERROR %v\n", err)))
		return
	}
	defer f.Close()

	stat, _ := f.Stat()
	size := stat.Size()

	// Calculate hash
	h := md5.New()
	io.Copy(h, f)
	hash := hex.EncodeToString(h.Sum(nil))

	// Limit connections
	if numConns > 8 {
		numConns = 8
	}
	if size < int64(numConns)*1024*1024 {
		numConns = 1 // Don't parallelize small files
	}

	// Create session
	sessionID := fmt.Sprintf("%x", time.Now().UnixNano())
	sessionMu.Lock()
	parallelSessions[sessionID] = &ParallelSession{
		Path:     path,
		Size:     size,
		Hash:     hash,
		NumConns: numConns,
		Created:  time.Now(),
	}
	sessionMu.Unlock()

	conn.Write([]byte(fmt.Sprintf("OK %s %d %s %d\n", sessionID, size, hash, numConns)))
}

// HandleGetC handles parallel download chunk request
func HandleGetC(conn net.Conn, cmd string) {
	var sessionID string
	var chunkIdx int
	fmt.Sscanf(cmd, "GETC %s %d", &sessionID, &chunkIdx)

	sessionMu.Lock()
	session, ok := parallelSessions[sessionID]
	sessionMu.Unlock()

	if !ok {
		conn.Write([]byte("ERROR session not found\n"))
		return
	}

	chunkSize := session.Size / int64(session.NumConns)
	offset := int64(chunkIdx) * chunkSize
	length := chunkSize
	if chunkIdx == session.NumConns-1 {
		length = session.Size - offset
	}

	f, err := os.Open(session.Path)
	if err != nil {
		conn.Write([]byte(fmt.Sprintf("ERROR %v\n", err)))
		return
	}
	defer f.Close()

	f.Seek(offset, 0)
	conn.Write([]byte(fmt.Sprintf("OK %d %d\n", offset, length)))
	io.CopyN(conn, f, length)
}

// HandlePipeUp handles pipe upload
func HandlePipeUp(conn net.Conn, cmd string, reader *bufio.Reader) {
	var path string
	var size int64
	var md5sum string
	fmt.Sscanf(cmd, "PIPE_UP %s %d %s", &path, &size, &md5sum)
	transferUser := effectiveTransferUser()

	// Expand ~ consistently with basic PUT.
	path = expandTransferPath(path, transferUser)

	dir := filepath.Dir(path)
	os.MkdirAll(dir, 0755)
	chownToTransferUser(dir, transferUser)

	conn.Write([]byte("READY\n"))

	data := make([]byte, size)
	io.ReadFull(reader, data)

	// Verify
	h := md5.Sum(data)
	if hex.EncodeToString(h[:]) != md5sum {
		conn.Write([]byte("ERROR md5 mismatch\n"))
		return
	}

	if err := os.WriteFile(path, data, 0644); err != nil {
		conn.Write([]byte(fmt.Sprintf("ERROR %v\n", err)))
		return
	}
	chownToTransferUser(path, transferUser)

	conn.Write([]byte("OK\n"))
}

// HandleRPCCommand handles RPC requests
func HandleRPCCommand(conn net.Conn, cmd string, reader *bufio.Reader) {
	// Format: RPC <method> <params_len>\n<params_json>
	var method string
	var paramsLen int
	fmt.Sscanf(cmd, "RPC %s %d", &method, &paramsLen)

	var params []byte
	if paramsLen > 0 {
		params = make([]byte, paramsLen)
		io.ReadFull(reader, params)
	}

	result := HandleRPC(method, params)
	conn.Write(result)
	conn.Write([]byte("\n"))
}

// Cleanup old sessions periodically
func init() {
	go func() {
		for {
			time.Sleep(5 * time.Minute)
			sessionMu.Lock()
			now := time.Now()
			for id, s := range parallelSessions {
				if now.Sub(s.Created) > 10*time.Minute {
					delete(parallelSessions, id)
				}
			}
			sessionMu.Unlock()
		}
	}()
}
