package ssh

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"sort"
	"strings"
	"time"

	"github.com/meshpop/vssh/internal/config"
)

// Connector handles SSH connections to peers
type Connector struct {
	config  *config.WireConfig
	peers   []config.Peer
	network string
}

type localServerConfig struct {
	IP           string                 `json:"ip"`
	VpnIP        string                 `json:"vpn_ip,omitempty"`
	PublicIP     string                 `json:"public_ip,omitempty"`
	LanIP        string                 `json:"lan_ip,omitempty"`
	Port         int                    `json:"port,omitempty"`
	User         string                 `json:"user,omitempty"`
	MonitorURL   string                 `json:"monitor_url,omitempty"`
	MonitorPort  int                    `json:"monitor_port,omitempty"`
	Tags         []string               `json:"tags,omitempty"`
	Capabilities []string               `json:"capabilities,omitempty"`
	Roles        []string               `json:"roles,omitempty"`
	OS           string                 `json:"os,omitempty"`
	Arch         string                 `json:"arch,omitempty"`
	Metadata     map[string]interface{} `json:"metadata,omitempty"`
}

// ExecAttempt records one endpoint attempt for machine-readable audit output.
type ExecAttempt struct {
	Endpoint  string `json:"endpoint"`
	User      string `json:"user,omitempty"`
	Path      string `json:"path"`
	Transport string `json:"transport"`
	Error     string `json:"error,omitempty"`
}

// ExecError is a stable machine-readable execution failure.
type ExecError struct {
	Code      string `json:"code"`
	Message   string `json:"message"`
	Retryable bool   `json:"retryable"`
}

// ExecResult captures remote command execution for MCP/LLM orchestration.
type ExecResult struct {
	Success      bool          `json:"success"`
	Host         string        `json:"host"`
	Target       string        `json:"target"`
	Command      string        `json:"command"`
	Endpoint     string        `json:"endpoint,omitempty"`
	Stdout       string        `json:"stdout"`
	Stderr       string        `json:"stderr"`
	ExitCode     int           `json:"exit_code"`
	DurationMs   int64         `json:"duration_ms"`
	Attempts     []ExecAttempt `json:"attempts"`
	Transport    string        `json:"transport"`
	FallbackUsed bool          `json:"fallback_used"`
	Error        *ExecError    `json:"error,omitempty"`
}

// NewConnector creates a new SSH connector
func NewConnector(network string) (*Connector, error) {
	cfg, err := config.LoadWireConfig()
	if err != nil {
		// Try to work without config (use coordinator directly)
		cfg = &config.WireConfig{}
	}

	c := &Connector{
		config:  cfg,
		network: network,
	}

	// Try to get peers
	c.loadPeers()

	return c, nil
}

func (c *Connector) loadPeers() {
	// 1. Try wire daemon first
	if config.IsDaemonRunning() {
		if peers := c.peersFromDaemon(); peers != nil {
			c.peers = c.enrichPeersFromConfig(peers)
			return
		}
	}

	// 2. Try coordinator
	if peers := c.peersFromCoordinators(); peers != nil {
		c.peers = c.enrichPeersFromConfig(peers)
		return
	}

	// 3. Try Tailscale
	if peers := c.peersFromTailscale(); peers != nil {
		c.peers = c.enrichPeersFromConfig(peers)
		return
	}

	// 4. Try config-based servers
	if peers := c.peersFromConfig(); peers != nil {
		c.peers = peers
		return
	}

	// 5. Fallback to cache
	c.peers = c.enrichPeersFromConfig(c.peersFromCache())
}

func (c *Connector) peersFromCoordinators() []config.Peer {
	urls := c.getCoordinatorURLs()

	for _, url := range urls {
		baseURL := strings.TrimSuffix(url, "/")
		client := &http.Client{Timeout: 5 * time.Second}

		resp, err := client.Get(baseURL + "/peers")
		if err != nil {
			continue
		}

		var result struct {
			Peers []config.Peer `json:"peers"`
		}
		if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
			resp.Body.Close()
			continue
		}
		resp.Body.Close()

		if len(result.Peers) > 0 {
			c.savePeersCache(result.Peers)
			return result.Peers
		}
	}

	return nil
}

func (c *Connector) getCoordinatorURLs() []string {
	var urls []string

	// From wire config
	if c.config.ServerURL != "" {
		urls = append(urls, c.config.ServerURL)
	}

	// Default fallback
	if len(urls) == 0 {
		urls = nil
	}

	return urls
}

func (c *Connector) peersFromTailscale() []config.Peer {
	cmd := exec.Command("tailscale", "status", "--json")
	output, err := cmd.Output()
	if err != nil {
		return nil
	}

	var data struct {
		Self struct {
			HostName     string   `json:"HostName"`
			TailscaleIPs []string `json:"TailscaleIPs"`
		} `json:"Self"`
		Peer map[string]struct {
			HostName     string   `json:"HostName"`
			TailscaleIPs []string `json:"TailscaleIPs"`
			Online       bool     `json:"Online"`
		} `json:"Peer"`
	}

	if err := json.Unmarshal(output, &data); err != nil {
		return nil
	}

	var peers []config.Peer

	// Add self
	if len(data.Self.TailscaleIPs) > 0 && data.Self.HostName != "" {
		peers = append(peers, config.Peer{
			NodeName: data.Self.HostName,
			VpnIP:    data.Self.TailscaleIPs[0],
		})
	}

	// Add peers
	for _, p := range data.Peer {
		if len(p.TailscaleIPs) > 0 && p.HostName != "" {
			online := p.Online
			var lastSeen interface{}
			if online {
				lastSeen = time.Now().Unix()
			}
			peers = append(peers, config.Peer{
				NodeName: p.HostName,
				VpnIP:    p.TailscaleIPs[0],
				Online:   &online,
				LastSeen: lastSeen,
			})
		}
	}

	return peers
}

func (c *Connector) peersFromConfig() []config.Peer {
	servers := loadLocalServers()
	if len(servers) == 0 {
		return nil
	}

	var peers []config.Peer
	for name, srv := range servers {
		vpnIP := srv.VpnIP
		if vpnIP == "" {
			vpnIP = srv.IP
		}
		peers = append(peers, config.Peer{
			NodeName:     name,
			VpnIP:        vpnIP,
			PublicIP:     srv.PublicIP,
			LanIP:        srv.LanIP,
			Port:         srv.Port,
			User:         srv.User,
			MonitorURL:   srv.MonitorURL,
			MonitorPort:  srv.MonitorPort,
			Tags:         srv.Tags,
			Capabilities: srv.Capabilities,
			Roles:        srv.Roles,
			OS:           srv.OS,
			Arch:         srv.Arch,
			Metadata:     srv.Metadata,
		})
	}

	return peers
}

func loadLocalServers() map[string]localServerConfig {
	home, _ := os.UserHomeDir()
	if home == "" {
		return nil
	}
	configPath := home + "/.vssh/servers.json"

	data, err := os.ReadFile(configPath)
	if err != nil {
		return nil
	}

	var servers map[string]localServerConfig
	if err := json.Unmarshal(data, &servers); err != nil {
		return nil
	}
	return servers
}

func (c *Connector) enrichPeersFromConfig(peers []config.Peer) []config.Peer {
	if len(peers) == 0 {
		return peers
	}
	servers := loadLocalServers()
	if len(servers) == 0 {
		return peers
	}

	for i := range peers {
		name := peers[i].NodeName
		srv, ok := servers[name]
		if !ok {
			for candidate, value := range servers {
				if strings.EqualFold(candidate, name) {
					srv = value
					ok = true
					break
				}
			}
		}
		if !ok {
			continue
		}
		applyLocalServerConfig(&peers[i], srv)
	}
	return peers
}

func applyLocalServerConfig(peer *config.Peer, srv localServerConfig) {
	if peer.VpnIP == "" {
		if srv.VpnIP != "" {
			peer.VpnIP = srv.VpnIP
		} else {
			peer.VpnIP = srv.IP
		}
	}
	if peer.PublicIP == "" {
		peer.PublicIP = srv.PublicIP
	}
	if peer.LanIP == "" {
		peer.LanIP = srv.LanIP
	}
	if peer.Port == 0 {
		peer.Port = srv.Port
	}
	if peer.User == "" {
		peer.User = srv.User
	}
	if peer.MonitorURL == "" {
		peer.MonitorURL = srv.MonitorURL
	}
	if peer.MonitorPort == 0 {
		peer.MonitorPort = srv.MonitorPort
	}
	if peer.OS == "" {
		peer.OS = srv.OS
	}
	if peer.Arch == "" {
		peer.Arch = srv.Arch
	}
	peer.Tags = mergeStringLists(peer.Tags, srv.Tags)
	peer.Capabilities = mergeStringLists(peer.Capabilities, srv.Capabilities)
	peer.Roles = mergeStringLists(peer.Roles, srv.Roles)
	if peer.Metadata == nil {
		peer.Metadata = srv.Metadata
	} else {
		for key, value := range srv.Metadata {
			if _, exists := peer.Metadata[key]; !exists {
				peer.Metadata[key] = value
			}
		}
	}
}

func mergeStringLists(a, b []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, value := range append(append([]string{}, a...), b...) {
		value = strings.TrimSpace(value)
		key := strings.ToLower(value)
		if key == "" || seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, value)
	}
	return out
}

func (c *Connector) peersFromDaemon() []config.Peer {
	conn, err := net.Dial("unix", config.SocketPath())
	if err != nil {
		return nil
	}
	defer conn.Close()

	// Send peers request
	req := map[string]interface{}{
		"cmd":  "peers",
		"args": c.network,
	}
	data, _ := json.Marshal(req)
	conn.Write(append(data, '\n'))

	// Read response
	reader := bufio.NewReader(conn)
	line, err := reader.ReadBytes('\n')
	if err != nil {
		return nil
	}

	var resp struct {
		Success bool          `json:"success"`
		Data    []config.Peer `json:"data"`
	}
	if err := json.Unmarshal(line, &resp); err != nil {
		return nil
	}
	if !resp.Success {
		return nil
	}

	return resp.Data
}

func (c *Connector) peersFromCache() []config.Peer {
	cachePath := config.WireDir() + "/peers_cache.json"
	data, err := os.ReadFile(cachePath)
	if err != nil {
		return nil
	}

	var peers []config.Peer
	json.Unmarshal(data, &peers)
	return peers
}

func (c *Connector) savePeersCache(peers []config.Peer) {
	cachePath := config.WireDir() + "/peers_cache.json"
	data, _ := json.MarshalIndent(peers, "", "  ")
	os.WriteFile(cachePath, data, 0600)
}

// Connect connects to a peer by name or VPN IP
func (c *Connector) Connect(target string, extraArgs []string) error {
	peer := c.findPeer(target)
	if peer == nil {
		return fmt.Errorf("peer not found: %s", target)
	}

	// Try connection methods in order
	endpoints := c.getEndpoints(peer)

	for _, ep := range endpoints {
		fmt.Printf("Trying %s...\n", ep.desc)
		if c.trySSH(ep.host, ep.user, extraArgs) {
			return nil
		}
	}

	return fmt.Errorf("failed to connect to %s", target)
}

type endpoint struct {
	host string
	user string
	desc string
}

func (c *Connector) getEndpoints(peer *config.Peer) []endpoint {
	var eps []endpoint

	// Get user from peer or users.json mapping
	users := config.LoadNodeUsers()
	user := lookupNodeUser(users, peer.NodeName)
	if user == "" {
		user = peer.User
	}

	// 1. Tailscale IP. In day-to-day AI operator workflows this is usually
	// the most reliable route because device identity, ACLs, and mobile/desktop
	// reachability are already handled by Tailscale. Keep Wire/VPN metadata for
	// status, but prefer Tailscale for SSH execution when available.
	if tsIP := tailscaleIPForHost(peer.NodeName); tsIP != "" {
		eps = append(eps, endpoint{
			host: tsIP,
			user: user,
			desc: fmt.Sprintf("Tailscale (%s)", tsIP),
		})
	}

	// 2. VPN IP (Wire/custom mesh)
	if peer.VpnIP != "" {
		eps = append(eps, endpoint{
			host: peer.VpnIP,
			user: user,
			desc: fmt.Sprintf("VPN (%s)", peer.VpnIP),
		})
	}

	// 3. LAN IP (same network)
	if peer.LanIP != "" && !strings.HasPrefix(peer.LanIP, "127.") {
		eps = append(eps, endpoint{
			host: peer.LanIP,
			user: user,
			desc: fmt.Sprintf("LAN (%s)", peer.LanIP),
		})
	}

	// 4. Public IP
	if peer.PublicIP != "" {
		eps = append(eps, endpoint{
			host: peer.PublicIP,
			user: user,
			desc: fmt.Sprintf("Public (%s)", peer.PublicIP),
		})
	}

	return eps
}

// ResolveHost maps a configured/discovered node name to the best private
// address for the native vssh daemon. It intentionally returns only the host;
// native daemon port selection stays with the vssh client.
func (c *Connector) ResolveHost(target string) (string, error) {
	peer := c.findPeer(target)
	if peer == nil {
		return "", fmt.Errorf("peer not found: %s", target)
	}
	endpoints := c.getEndpoints(peer)
	if len(endpoints) == 0 {
		return "", fmt.Errorf("no reachable address for peer: %s", target)
	}
	return endpoints[0].host, nil
}

func lookupNodeUser(users map[string]string, nodeName string) string {
	candidates := []string{
		nodeName,
		strings.ToLower(nodeName),
		strings.Split(strings.ToLower(nodeName), ".")[0],
	}
	for _, candidate := range candidates {
		if user := users[candidate]; user != "" {
			return user
		}
	}
	for key, user := range users {
		if strings.EqualFold(key, nodeName) || strings.EqualFold(key, strings.Split(nodeName, ".")[0]) {
			return user
		}
	}
	return ""
}

func tailscaleIPForHost(hostname string) string {
	hostname = strings.ToLower(strings.TrimSpace(hostname))
	if hostname == "" {
		return ""
	}

	cmd := exec.Command("tailscale", "status", "--json")
	output, err := cmd.Output()
	if err != nil {
		return ""
	}

	var data struct {
		Self struct {
			HostName     string   `json:"HostName"`
			TailscaleIPs []string `json:"TailscaleIPs"`
		} `json:"Self"`
		Peer map[string]struct {
			HostName     string   `json:"HostName"`
			TailscaleIPs []string `json:"TailscaleIPs"`
		} `json:"Peer"`
	}
	if err := json.Unmarshal(output, &data); err != nil {
		return ""
	}

	matches := func(candidate string) bool {
		candidate = strings.ToLower(strings.TrimSpace(candidate))
		return candidate == hostname || strings.Split(candidate, ".")[0] == hostname
	}
	if matches(data.Self.HostName) && len(data.Self.TailscaleIPs) > 0 {
		return data.Self.TailscaleIPs[0]
	}
	for _, peer := range data.Peer {
		if matches(peer.HostName) && len(peer.TailscaleIPs) > 0 {
			return peer.TailscaleIPs[0]
		}
	}
	return ""
}

func (c *Connector) trySSH(host, user string, extraArgs []string) bool {
	args := []string{
		"-o", "ConnectTimeout=10",
		"-o", "StrictHostKeyChecking=no",
		"-o", "UserKnownHostsFile=/dev/null",
		"-o", "LogLevel=ERROR",
	}

	target := host
	if user != "" {
		target = user + "@" + host
	}
	args = append(args, target)
	args = append(args, extraArgs...)

	cmd := exec.Command("ssh", args...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	err := cmd.Run()
	return err == nil
}

func (c *Connector) findPeer(target string) *config.Peer {
	target = strings.ToLower(target)

	for i := range c.peers {
		p := &c.peers[i]
		// Match by name
		if strings.ToLower(p.NodeName) == target {
			return p
		}
		// Match by partial name
		if strings.Contains(strings.ToLower(p.NodeName), target) {
			return p
		}
		// Match by VPN IP
		if p.VpnIP == target {
			return p
		}
		// Match by node ID
		if strings.HasPrefix(strings.ToLower(p.NodeID), target) {
			return p
		}
	}

	return nil
}

// ListPeers lists all known peers
func (c *Connector) ListPeers() []config.Peer {
	return c.peers
}

// Status returns connection status
func (c *Connector) Status() string {
	var sb strings.Builder

	Reset := "\033[0m"
	Bold := "\033[1m"
	Dim := "\033[2m"
	Green := "\033[92m"
	Red := "\033[91m"
	Cyan := "\033[96m"

	sb.WriteString("\n")
	sb.WriteString(fmt.Sprintf("  %s%svssh dashboard%s\n", Bold, Cyan, Reset))
	sb.WriteString("\n")

	// Header
	sb.WriteString(fmt.Sprintf("  %s  %-8s %-15s  %5s  %4s  %4s  %s%s\n",
		Dim, "SERVER", "IP", "LOAD", "MEM", "DISK", "UPTIME", Reset))
	sb.WriteString(fmt.Sprintf("  %s%s%s\n", Dim, strings.Repeat("-", 56), Reset))

	// Sort peers by name
	sortedPeers := make([]config.Peer, len(c.peers))
	copy(sortedPeers, c.peers)
	sort.Slice(sortedPeers, func(i, j int) bool {
		return sortedPeers[i].NodeName < sortedPeers[j].NodeName
	})

	onlineCount := 0
	now := time.Now().Unix()

	for _, p := range sortedPeers {
		if p.NodeName == "" {
			continue
		}

		name := p.NodeName
		if len(name) > 8 {
			name = name[:8]
		}

		// Check if peer is online based on last_seen (within 60 seconds)
		online := false
		if p.LastSeen != nil {
			switch v := p.LastSeen.(type) {
			case float64:
				online = (now - int64(v)) < 60
			case int64:
				online = (now - v) < 60
			case string:
				if t, err := time.Parse(time.RFC3339, v); err == nil {
					online = time.Since(t) < 60*time.Second
				}
			}
		}

		var dot string
		if online {
			dot = Green + "●" + Reset
			onlineCount++
		} else {
			dot = Red + "○" + Reset
		}

		// Format stats
		load, mem, disk, uptime := "-", "-", "-", "-"
		if p.Stats != nil {
			if p.Stats.LoadValue > 0 {
				load = fmt.Sprintf("%.2f", p.Stats.LoadValue)
			} else if p.Stats.Load != "" {
				load = p.Stats.Load
			}
			if p.Stats.MemPct > 0 {
				mem = fmt.Sprintf("%d%%", p.Stats.MemPct)
			}
			if p.Stats.DiskPct > 0 {
				disk = fmt.Sprintf("%d%%", p.Stats.DiskPct)
			}
			if p.Stats.Uptime != "" {
				uptime = p.Stats.Uptime
			}
		}

		sb.WriteString(fmt.Sprintf("  %s %-8s %-15s  %5s  %4s  %4s  %s\n",
			dot, name, p.VpnIP, load, mem, disk, uptime))
	}

	sb.WriteString("\n")
	sb.WriteString(fmt.Sprintf("  %s%d/%d online%s\n", Green, onlineCount, len(c.peers)-1, Reset))
	sb.WriteString("\n")

	return sb.String()
}

// Exec executes a command on a peer
func (c *Connector) Exec(target string, command []string) error {
	peer := c.findPeer(target)
	if peer == nil {
		return fmt.Errorf("peer not found: %s", target)
	}

	endpoints := c.getEndpoints(peer)

	for _, ep := range endpoints {
		target := ep.host
		if ep.user != "" {
			target = ep.user + "@" + ep.host
		}
		args := []string{
			"-o", "ConnectTimeout=10",
			"-o", "StrictHostKeyChecking=no",
			"-o", "UserKnownHostsFile=/dev/null",
			"-o", "LogLevel=ERROR",
			target,
		}
		args = append(args, command...)

		cmd := exec.Command("ssh", args...)
		cmd.Stdin = os.Stdin
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr

		if err := cmd.Run(); err == nil {
			return nil
		}
	}

	return fmt.Errorf("failed to execute on %s", target)
}

// ExecCapture executes a shell command on a peer and returns structured output.
//
// The command is sent to the remote node on stdin and executed with "sh -s".
// This avoids local shell parsing and preserves quotes, pipes, JSON, and other
// command text that LLM/MCP callers commonly pass as a single string.
func (c *Connector) ExecCapture(target string, command string, timeout time.Duration) (*ExecResult, error) {
	if timeout <= 0 {
		timeout = 30 * time.Second
	}

	result := &ExecResult{
		Host:      target,
		Target:    target,
		Command:   command,
		ExitCode:  -1,
		Transport: "ssh",
	}
	peer := c.findPeer(target)
	if peer == nil {
		result.Error = &ExecError{
			Code:      "peer_not_found",
			Message:   fmt.Sprintf("peer not found: %s", target),
			Retryable: false,
		}
		return result, fmt.Errorf("%s", result.Error.Message)
	}

	start := time.Now()
	endpoints := c.getEndpoints(peer)

	for _, ep := range endpoints {
		attempt := ExecAttempt{Endpoint: ep.host, User: ep.user, Path: ep.desc, Transport: "ssh"}
		args := []string{
			"-o", "ConnectTimeout=10",
			"-o", "StrictHostKeyChecking=no",
			"-o", "UserKnownHostsFile=/dev/null",
			"-o", "LogLevel=ERROR",
			ep.host,
			"sh", "-s",
		}
		if ep.user != "" {
			args[8] = ep.user + "@" + ep.host
		}

		ctx, cancel := context.WithTimeout(context.Background(), timeout)
		cmd := exec.CommandContext(ctx, "ssh", args...)
		cmd.Stdin = strings.NewReader(command)
		var stdout, stderr bytes.Buffer
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr

		err := cmd.Run()
		cancel()

		result.DurationMs = time.Since(start).Milliseconds()
		result.Endpoint = ep.host
		result.Stdout = stdout.String()
		result.Stderr = stderr.String()
		result.FallbackUsed = len(result.Attempts) > 0

		if ctx.Err() == context.DeadlineExceeded {
			attempt.Error = "timeout"
			result.Attempts = append(result.Attempts, attempt)
			result.ExitCode = 124
			result.Error = &ExecError{
				Code:      "timeout",
				Message:   fmt.Sprintf("command timed out after %s", timeout),
				Retryable: true,
			}
			return result, fmt.Errorf("command timed out after %s", timeout)
		}

		if err == nil {
			result.Success = true
			result.ExitCode = 0
			result.Attempts = append(result.Attempts, attempt)
			return result, nil
		}

		if exitErr, ok := err.(*exec.ExitError); ok {
			result.ExitCode = exitErr.ExitCode()
			attempt.Error = err.Error()
			result.Attempts = append(result.Attempts, attempt)
			result.Error = &ExecError{
				Code:      "remote_exit_nonzero",
				Message:   err.Error(),
				Retryable: false,
			}
			return result, err
		}

		attempt.Error = err.Error()
		result.Attempts = append(result.Attempts, attempt)
	}

	result.DurationMs = time.Since(start).Milliseconds()
	result.FallbackUsed = len(result.Attempts) > 1
	result.Error = &ExecError{
		Code:      "endpoint_unreachable",
		Message:   fmt.Sprintf("failed to execute on %s", target),
		Retryable: true,
	}
	return result, fmt.Errorf("failed to execute on %s", target)
}

// Copy copies files to/from a peer using scp
func (c *Connector) Copy(src, dst string) error {
	// Parse src and dst to determine direction
	// Format: peer:path or path
	srcPeer, srcPath := parsePath(src)
	dstPeer, dstPath := parsePath(dst)

	var peer *config.Peer
	var localPath, remotePath string
	var toRemote bool

	if srcPeer != "" {
		peer = c.findPeer(srcPeer)
		remotePath = srcPath
		localPath = dst
		toRemote = false
	} else if dstPeer != "" {
		peer = c.findPeer(dstPeer)
		remotePath = dstPath
		localPath = src
		toRemote = true
	} else {
		return fmt.Errorf("either source or destination must be a remote peer")
	}

	if peer == nil {
		return fmt.Errorf("peer not found")
	}

	endpoints := c.getEndpoints(peer)

	for _, ep := range endpoints {
		var src, dst string
		if toRemote {
			src = localPath
			dst = ep.host + ":" + remotePath
		} else {
			src = ep.host + ":" + remotePath
			dst = localPath
		}

		args := []string{
			"-o", "ConnectTimeout=10",
			"-o", "StrictHostKeyChecking=no",
			"-o", "UserKnownHostsFile=/dev/null",
			"-r",
			src, dst,
		}

		cmd := exec.Command("scp", args...)
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr

		if err := cmd.Run(); err == nil {
			return nil
		}
	}

	return fmt.Errorf("failed to copy")
}

func parsePath(path string) (peer, filepath string) {
	if idx := strings.Index(path, ":"); idx > 0 {
		return path[:idx], path[idx+1:]
	}
	return "", path
}

// StreamOutput streams command output from a peer
func (c *Connector) StreamOutput(target string, command []string, stdout, stderr io.Writer) error {
	peer := c.findPeer(target)
	if peer == nil {
		return fmt.Errorf("peer not found: %s", target)
	}

	endpoints := c.getEndpoints(peer)

	for _, ep := range endpoints {
		args := []string{
			"-o", "ConnectTimeout=10",
			"-o", "StrictHostKeyChecking=no",
			"-o", "UserKnownHostsFile=/dev/null",
			"-o", "LogLevel=ERROR",
			ep.host,
		}
		args = append(args, command...)

		cmd := exec.Command("ssh", args...)
		cmd.Stdout = stdout
		cmd.Stderr = stderr

		if err := cmd.Run(); err == nil {
			return nil
		}
	}

	return fmt.Errorf("failed to execute on %s", target)
}
