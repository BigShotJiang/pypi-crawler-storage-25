# vssh 배포 방향

서버마다 아키텍처에 맞춰 직접 빌드하는 번거로움은 없애야 합니다.

## 결론

하나의 바이너리로 모든 OS/CPU를 커버하는 것은 현실적으로 어렵습니다.

대신 사용자가 아키텍처를 신경 쓰지 않게 만들 수 있습니다.

```bash
curl -fsSL https://raw.githubusercontent.com/meshpop/vssh/main/install.sh | bash
```

설치 스크립트가 자동으로 감지합니다.

- OS: `linux`, `darwin`
- CPU: `amd64`, `arm64`
- 다운로드 파일:
  - `vssh-linux-amd64`
  - `vssh-linux-arm64`
  - `vssh-darwin-amd64`
  - `vssh-darwin-arm64`

## 릴리스 자동화

Git tag를 push하면 GitHub Actions가 모든 플랫폼 바이너리를 자동으로 빌드하고
Release asset으로 올립니다.

```bash
git tag v0.8.0
git push origin v0.8.0
```

생성되는 asset:

- `vssh-linux-amd64`
- `vssh-linux-arm64`
- `vssh-darwin-amd64`
- `vssh-darwin-arm64`
- `checksums.txt`

## 로컬 릴리스 빌드

```bash
make release
```

결과는 `dist/`에 생성됩니다.

## 제품 원칙

운영자는 "이 서버가 amd64인지 arm64인지" 고민하면 안 됩니다.

사용자는 한 줄 설치만 실행합니다.

```bash
curl -fsSL .../install.sh | bash
```

빌드와 아키텍처 매칭은 release pipeline과 install script가 처리합니다.

## Python과의 관계

Python 패키지를 만든다면 그것은 daemon 대체가 아니라 AI-facing client/SDK가
되어야 합니다.

```text
Go release binary
  -> server daemon
  -> native exec/RPC/file/job runtime

pip install vssh
  -> Python SDK
  -> MCP/client helpers
  -> orchestration integration
```

이 구조면 서버 배포는 단일 바이너리 장점을 유지하고, AI 쪽 개발은 Python의
속도를 활용할 수 있습니다.
