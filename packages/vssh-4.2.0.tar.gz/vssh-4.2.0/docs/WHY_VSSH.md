# Why vssh

vssh is worth using when the caller is an AI agent, automation runtime, or
server-operations control plane that needs more than a human terminal.

If all you need is an interactive shell on a machine that already runs sshd,
use OpenSSH directly. vssh exists for the cases where SSH is the wrong product
abstraction.

## The Short Answer

Use vssh because it turns a private node into an AI-operable execution endpoint:
typed actions in, structured evidence out, with policy and long-running work as
first-class concepts.

## Where OpenSSH Is Already Enough

OpenSSH is excellent for:

- a human opening a terminal
- ad hoc remote shell work
- copying a file to a known host
- machines that already have sshd, users, keys, and host policy configured

vssh should not compete there. Wrapping `ssh user@tailscale-ip` is not enough
value and creates product confusion.

## Where vssh Is Better

vssh is better when the operator is an agent, not a human:

- **No sshd requirement**: a node only needs Tailscale/private reachability and
  the vssh daemon.
- **Structured execution results**: command output is returned as stdout,
  stderr, exit code, duration, endpoint, and transport rather than terminal
  text that an LLM has to guess about.
- **Evidence by default**: every action can become an audit record for
  MeshClaw, Codex, Claude, or a local LLM runtime.
- **Policy hooks**: risky actions can be classified and gated before execution.
- **Job semantics**: long-running work can move from fragile terminal sessions
  to job ids, logs, status, cancellation, and result collection.
- **Typed node APIs**: facts, logs, services, files, artifacts, GPU/model state,
  and health can be exposed as APIs instead of shell conventions.
- **Narrower operational surface**: a node can expose only the daemon actions
  the runtime needs rather than broad shell access.

## Product Rule

Every vssh feature should pass at least one of these tests:

- It works without sshd.
- It produces structured evidence an agent can trust.
- It gives policy/control that plain SSH does not provide.
- It improves long-running or multi-step automation.
- It exposes node state as typed data instead of terminal text.
- It reduces the amount of shell knowledge an AI runtime needs.

If a feature is only "SSH, but with a shorter command", it does not belong in
the product surface.

## Development Direction

Prioritize these surfaces:

1. `exec`: structured stdout/stderr/exit/duration/evidence.
2. `job_start`, `job_status`, `job_logs`, `job_cancel`: durable long-running
   work.
3. `artifact_collect`, `file_put`, `file_get`: explicit file and result
   handling.
4. `facts`: OS, CPU, memory, disk, GPU, models, services, listeners.
5. `service_status`, `service_logs`, `service_restart`: server operations APIs
   with policy gates.
6. `policy_check`: classify action risk before execution.
7. `evidence`: append-only records for external control planes.

This makes vssh the daemon layer for AI server operations, not a shell alias.
