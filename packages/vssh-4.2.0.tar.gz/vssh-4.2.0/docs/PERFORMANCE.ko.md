# vssh Performance 방향

vssh는 SSH wrapper가 아니므로 성능 목표도 달라야 합니다.

## 목표

vssh native daemon 실행은 OpenSSH 기반 원격 실행보다 낮은 startup latency를
목표로 합니다.

이유:

- OpenSSH는 매 실행마다 SSH handshake, user/session setup, sshd 처리, shell 실행이 들어간다.
- vssh native daemon은 이미 떠 있는 프로세스가 HMAC 인증 후 command/RPC를 처리한다.
- AI agent는 작은 진단 명령을 여러 번, 여러 서버에 반복 실행하므로 startup latency가 중요하다.

## 성능상 vssh가 유리해야 하는 영역

- 짧은 read/diagnostic command 반복 실행
- 여러 서버 fan-out 실행
- RPC 기반 상태 조회
- service/log/facts 조회
- artifact collection 전후의 작은 control command

## 현재 측정 도구

```bash
VSSH_SECRET=... vssh bench d1 20
```

출력:

```text
vssh bench d1 (100.x.y.z:48291)
  attempts: 20 ok, 0 failed
  min:      6.2ms
  p50:      8.1ms
  avg:      8.7ms
  p95:      13.4ms
  max:      15.0ms
```

## 개발 기준

vssh는 다음 방향으로 빨라져야 합니다.

1. **No sshd path**: OpenSSH/sshd를 실행 경로에서 제거한다.
2. **Persistent daemon**: 이미 떠 있는 daemon이 명령/RPC를 처리한다.
3. **Structured RPC first**: `df`, `free`, `systemctl` text parsing보다 typed RPC를 우선한다.
4. **Fan-out parallelism**: 여러 서버 실행은 client에서 goroutine fan-out으로 병렬 처리한다.
5. **Short deadlines**: health/probe/diagnostic에는 짧은 timeout을 기본으로 둔다.
6. **Future persistent sessions**: 반복 실행은 connection pool 또는 multiplexed session으로 더 줄인다.

## 다음 최적화

- `vssh.exec.many`: 여러 서버 병렬 native exec
- `vssh.rpc.call`: shell command 대신 typed RPC 호출
- `vssh.rpc.many`: 여러 서버 병렬 RPC
- persistent connection/session protocol
- streaming exec for long-running commands

성능상 가장 큰 차이는 `exec.many`와 `rpc.many`에서 나온다. SSH로도 병렬 스크립트는
가능하지만, vssh는 per-node result, timeout, error, evidence summary를 구조화해서
반환해야 한다.
