# vssh Direction

vssh should not be positioned as an SSH wrapper.

Tailscale already gives private reachability, and OpenSSH already gives remote
shell execution. Wrapping `ssh user@tailscale-ip` is convenient, but it is not
enough product value and it creates confusion.

## Product Claim

vssh is an AI-native remote execution daemon and protocol for Tailscale/private
networks.

Use vssh because it turns a private node into an AI-operable execution endpoint:
typed actions in, structured evidence out, with policy and long-running work as
first-class concepts.

It should become useful when SSH is not the right abstraction:

- nodes where `sshd` is unavailable or intentionally disabled
- execution that needs structured evidence by default
- machine-facing APIs for Codex, Claude, local LLMs, and automation
- policy-aware command/file/service operations
- long-running jobs with handles, logs, cancellation, and result collection
- file transfer and artifact collection without exposing broad shell access
- node-local facts and health exposed as typed APIs

## Network Model

Tailscale is the transport network.

```text
client
  -> Tailscale IP / MagicDNS
  -> vssh daemon
  -> typed exec/file/job/service APIs
```

Tailscale handles private reachability. vssh handles agent execution,
authorization, evidence, and runtime semantics.

## Non-Goal

The core product is not:

```text
vssh exec node cmd -> ssh user@tailscale-ip cmd
```

That path is just OpenSSH with name resolution. vssh should not expose it as a
product feature. If sshd is available and a normal shell is enough, use `ssh`
directly.

## Native Agent Capabilities

First-class vssh daemon mode should provide:

- `exec`: run a command and return structured stdout/stderr/exit/duration
- `job_start`: start a long-running job and return a job id
- `job_status`: inspect running/completed jobs
- `job_cancel`: cancel a job
- `file_put`, `file_get`, `artifact_collect`
- `service_status`, `service_logs`, `service_restart` with policy hooks
- `facts`: OS, CPU, memory, disk, GPU, services, listening ports
- `policy_check`: classify an action before execution
- `evidence`: append-only execution records

See also: [AI-native capability map](AI_NATIVE_CAPABILITIES.ko.md).

## Parallel Fleet Operations

The most important next differentiator is fleet fan-out:

- `exec.many`: run one command across many targets in parallel
- `rpc.many`: call one typed RPC across many targets in parallel
- partial success reporting
- per-target timeout/error/evidence
- aggregate summary for AI planning

This is where vssh becomes clearly better than shelling out to SSH. A human can
write ad hoc parallel SSH scripts, but an AI runtime needs a stable JSON result
with per-node success, failure, duration, stdout, stderr, and policy state.

## Performance Rule

vssh native execution must be faster than OpenSSH-style one-shot execution for
small diagnostic commands.

Reasons:

- no sshd requirement
- no OpenSSH process startup on the client path
- daemon is already resident
- results are structured without terminal parsing
- future `exec.many` and `rpc.many` can fan out concurrently with per-node
  deadlines and evidence

Use `vssh bench <host> [count]` to measure native startup latency.

## Feature Gate

Every new feature must answer why vssh is better than direct SSH.

Accept features that:

- work without sshd
- produce structured evidence
- add policy/control
- support durable long-running jobs
- expose typed node state
- reduce shell knowledge required from the AI runtime

Reject features that are only a shorter spelling for `ssh`, `scp`, or remote
shell conventions.

## Relationship With MeshClaw

MeshClaw should use direct SSH for its MVP because that already works with
Tailscale + sshd.

vssh becomes valuable as an optional backend when a node runs the vssh daemon:

```text
MeshClaw
  -> direct SSH backend for normal servers
  -> vssh daemon backend for sshd-free / agent-rich nodes
```

This keeps MeshClaw simple while giving vssh its own differentiated product
surface.
