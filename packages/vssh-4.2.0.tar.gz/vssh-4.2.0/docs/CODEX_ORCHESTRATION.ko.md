# Codex 오케스트레이션용 VSSH MCP 노트

VSSH는 Runtime에서 Codex와 LLM 오케스트레이터가 원격 노드를 조작할 때 쓰는 실행 capability 레이어입니다. 목표는 사람이 터미널 출력을 읽는 UX가 아니라, 모델이 안정적으로 판단할 수 있는 구조화된 실행 결과와 증거를 제공하는 것입니다.

## Agent용 tool 이름

새 연동에는 dotted tool 이름을 사용합니다.

- `vssh.hosts.list`: 라우팅용 host 목록 조회
- `vssh.policy.check`: 실행 전 명령 분류
- `vssh.exec.safe`: 내장 policy가 허용한 명령만 실행
- `vssh.exec`: policy 검사 후 실행, 필요 시 `allow_dangerous` 사용
- `vssh.route.select`: capability/tag/health 조건으로 host 선택
- `vssh.exec.routed`: host를 선택한 뒤 policy/evidence 포함 실행

기존 이름인 `vssh_list`, `vssh_status`, `vssh_exec`도 호환성을 위해 유지합니다.

## Host registry 형태

`vssh.hosts.list`는 단순 표시용 목록이 아니라 라우팅 판단용 host record를 반환합니다.

```json
{
  "success": true,
  "count": 1,
  "hosts": [
    {
      "name": "gpu1",
      "addresses": {"vpn": "192.0.2.20"},
      "user": "ubuntu",
      "tags": ["gpu", "linux", "ollama"],
      "capabilities": ["cuda", "gpu", "linux", "ollama"],
      "health": {
        "status": "unknown",
        "reason": "no live health signal"
      },
      "stats": null,
      "metadata": null
    }
  ]
}
```

Agent는 config의 명시적 `capabilities`, tags/roles/OS에서 추론한 capability,
live health 순서로 라우팅 판단에 사용하면 됩니다. Health status는 `online`,
`offline`, `stale`, `degraded`, `unknown` 중 하나입니다.

## Monitor 연동

VSSH는 실행 계층에 집중합니다. 모니터링 데몬을 내장하지 않고, 외부 monitor의
live health를 읽어서 라우팅 판단에 사용할 수 있습니다.

host 설정 예시:

```json
{
  "gpu1": {
    "ip": "192.0.2.20",
    "user": "ubuntu",
    "tags": ["gpu", "ollama"],
    "capabilities": ["cuda", "ollama"],
    "monitor_port": 8721
  },
  "gpu2": {
    "ip": "192.0.2.21",
    "monitor_url": "http://192.0.2.21:8721"
  }
}
```

agent는 필요할 때만 live health를 요청합니다.

```json
{
  "include_health": true,
  "health_timeout_seconds": 1
}
```

VSSH는 `{monitor_url}/api/node/status`를 읽고 CPU, memory, disk, GPU, Docker,
alerts를 추출해서 node를 `online`, `degraded`, `offline`으로 라우팅에 반영합니다.
monitor가 없거나 닿지 않아도 실행 기능은 유지되고, health 객체에 구조화된
monitor error가 들어갑니다.

## Routed execution

`vssh.exec.routed`는 다음 순서로 실행됩니다.

1. `vssh.hosts.list`
2. `vssh.route.select`
3. `vssh.policy.check`
4. `vssh.exec`

요청 예시:

```json
{
  "required_capabilities": ["cuda", "ollama"],
  "preferred_tags": ["gpu"],
  "avoid_health": ["offline", "degraded"],
  "include_health": true,
  "command": "ollama list",
  "timeout_seconds": 20
}
```

응답에는 `route.selected`, candidate score, reason, missing capabilities,
policy decision, execution result가 포함됩니다.

## 핵심 방향

- 명령 문자열은 하나의 셸 스크립트로 취급합니다.
- 따옴표, 파이프, JSON 문자열, 여러 줄 명령이 깨지지 않아야 합니다.
- 모든 실행 경로는 가능한 한 같은 JSON 형태를 반환해야 합니다.
- 실패 원인은 `stderr` 문장 파싱이 아니라 `error.code`, `retryable`, `exit_code`, `attempts` 같은 필드로 판단해야 합니다.

## 구조화된 실행 결과 예시

```json
{
  "success": true,
  "target": "web1",
  "command": "printf 'alpha beta\\n' | wc -c",
  "timeout_sec": 15,
  "result": {
    "success": true,
    "host": "web1",
    "target": "web1",
    "command": "printf 'alpha beta\\n' | wc -c",
    "endpoint": "192.0.2.10",
    "stdout": "11\n",
    "stderr": "",
    "exit_code": 0,
    "duration_ms": 532,
    "attempts": [
      {
        "endpoint": "192.0.2.10",
        "user": "deploy",
        "path": "VPN (192.0.2.10)",
        "transport": "ssh"
      }
    ],
    "transport": "ssh",
    "fallback_used": false
  },
  "tool": "vssh.exec",
  "started_at": "2026-05-16T00:00:00Z",
  "ended_at": "2026-05-16T00:00:00.532Z",
  "duration_ms": 532,
  "policy": {
    "allowed": true,
    "risk": "low",
    "reason": "no dangerous pattern matched",
    "requires_approval": false
  },
  "evidence_type": "execution_result",
  "blocked": false,
  "approved": false
}
```

실패도 같은 형태를 유지해야 합니다. `success: false`, 안정적인 `error.code`, `retryable`, 가능한 경우 `exit_code`, 그리고 시도한 endpoint 목록을 포함합니다.

## Policy 의미

`vssh.exec.safe`와 `vssh.exec`는 SSH 프로세스를 만들기 전에 명령 policy를 검사합니다. 내장 policy는 다음처럼 파괴적이거나 서비스에 영향을 주는 명령 패턴을 차단합니다.

- `rm -rf`, `rm -fr`
- `shutdown`, `reboot`, `poweroff`, `halt`
- `mkfs`, `dd of=`
- `docker rm`, `docker rmi`, `docker system prune`
- `kubectl delete`, `helm uninstall`, `terraform destroy`
- `systemctl stop`, `systemctl restart`, `systemctl disable`

차단 응답은 `success: false`, `blocked: true`, `error.code:
policy_blocked`, `evidence_type: policy_decision` 형태를 사용합니다. 명시적 사람
승인이 있는 경우에만 `vssh.exec`에서 `allow_dangerous: true`로 차단된 명령을
실행할 수 있습니다. `vssh.exec.safe`는 이 override를 제공하지 않습니다.

## Runtime 사용 지침

- Codex가 결과를 판단해야 하는 명령은 구조화된 MCP 실행 경로를 우선 사용합니다.
- 시간이 걸리는 명령에는 `timeout_seconds`를 명시합니다.
- 쓰기/관리 작업 전에 읽기 전용 진단 명령을 먼저 실행합니다.
- Matrix나 작업 ledger에는 `stdout`, `stderr`, `exit_code`, `duration_ms`, `attempts`를 증거로 저장합니다.
- 모델에게 SSH 따옴표를 직접 맞추게 하지 말고 의도한 셸 스크립트를 하나의 문자열로 전달합니다.

## 공개 문서 위생

공개 repo의 예시는 항상 익명화해야 합니다. 실제 노드 이름, VPN IP, 사용자명, Tailscale 호스트명, 개인 배포 메모를 커밋하지 마세요. 예시 IP는 `192.0.2.0/24`, `198.51.100.0/24`, `203.0.113.0/24` 같은 문서용 대역을 사용합니다.

## 다음 패치 후보

1. 대화형 SSH 세션 없이 endpoint 시도 결과만 반환하는 `vssh_probe` MCP 도구 추가
2. `vssh_put`의 소유권/권한/atomic install 동작 정리
3. 노드별 성공/실패 schema를 갖는 `vssh_exec_fleet` 출력 추가
4. `timeout_seconds`, `max_attempts`, `preferred_path` 같은 재시도 정책 필드 노출
5. `tool`, `target`, `started_at`, `ended_at`, `result`를 포함하는 Matrix-ready evidence envelope 추가
