# 왜 vssh인가

vssh는 사람이 터미널을 여는 도구라기보다, AI 에이전트/자동화 런타임/서버
운영 control plane이 원격 노드를 다루기 위한 실행 daemon입니다.

이미 sshd가 있고 사람이 shell만 열면 되는 상황이라면 OpenSSH를 직접 쓰면
됩니다. vssh는 SSH가 제품 추상화로 부족한 경우를 위해 존재합니다.

## 짧은 답

vssh를 쓰는 이유는 private node를 AI가 다룰 수 있는 실행 endpoint로 바꾸기
때문입니다. typed action을 넣고, structured evidence를 받으며, 정책과 장기
작업을 first-class로 다룹니다.

## OpenSSH로 충분한 경우

OpenSSH는 다음에 이미 훌륭합니다.

- 사람이 터미널을 여는 일
- 임시 원격 shell 작업
- 알고 있는 host에 파일 하나 복사
- sshd, user, key, host policy가 이미 설정된 서버

vssh는 이 영역에서 경쟁하지 않습니다. `ssh user@tailscale-ip`를 감싸는 것은
제품 가치가 약하고 오해를 만듭니다.

## vssh가 더 좋은 경우

운영 주체가 사람이 아니라 agent일 때 vssh가 더 좋습니다.

- **sshd 불필요**: Tailscale/private reachability와 vssh daemon만 있으면 됩니다.
- **구조화 실행 결과**: stdout, stderr, exit code, duration, endpoint,
  transport를 반환합니다. LLM이 terminal text를 추측하지 않아도 됩니다.
- **evidence 기본 제공**: 모든 action을 MeshClaw, Codex, Claude, local LLM
  runtime의 감사 기록으로 남길 수 있습니다.
- **정책 hook**: 위험한 작업을 실행 전에 분류하고 gate할 수 있습니다.
- **job semantics**: 장기 작업을 터미널 세션에 묶지 않고 job id, log, status,
  cancel, result collection으로 다룰 수 있습니다.
- **typed node API**: facts, logs, services, files, artifacts, GPU/model state,
  health를 shell 관습이 아니라 API로 제공합니다.
- **좁은 운영 표면**: 전체 shell을 넓게 열지 않고 runtime에 필요한 daemon
  action만 노출할 수 있습니다.

## 제품 규칙

vssh 기능은 최소 하나를 만족해야 합니다.

- sshd 없이 동작한다.
- agent가 신뢰할 수 있는 structured evidence를 만든다.
- plain SSH에 없는 policy/control을 제공한다.
- 장기 작업 또는 여러 단계 자동화를 개선한다.
- node 상태를 terminal text가 아니라 typed data로 노출한다.
- AI runtime이 알아야 하는 shell 지식을 줄인다.

단지 "SSH인데 명령어가 짧다" 수준의 기능은 제품 표면에 들어가지 않습니다.

## 개발 방향

우선순위는 다음입니다.

1. `exec`: structured stdout/stderr/exit/duration/evidence.
2. `job_start`, `job_status`, `job_logs`, `job_cancel`: 지속 가능한 장기 작업.
3. `artifact_collect`, `file_put`, `file_get`: 명시적 파일/결과 처리.
4. `facts`: OS, CPU, memory, disk, GPU, models, services, listeners.
5. `service_status`, `service_logs`, `service_restart`: policy gate가 붙은 서버 운영 API.
6. `policy_check`: 실행 전 action risk 분류.
7. `evidence`: 외부 control plane을 위한 append-only 기록.

이 방향이면 vssh는 shell alias가 아니라 AI 서버 운영을 위한 daemon layer가 됩니다.
