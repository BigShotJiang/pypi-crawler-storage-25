# vssh AI-native 기능 조사

이 문서는 vssh가 단순 SSH wrapper가 아니라 AI 에이전트/서버 운영 자동화에 더
좋은 이유를 기능 단위로 정리합니다.

## 핵심 주장

vssh의 가치는 "원격 shell 접속"이 아닙니다.

vssh의 가치는 AI가 쓰기 좋은 원격 실행 substrate입니다.

- 입력은 typed action/RPC로 받는다.
- 결과는 structured result/evidence로 돌려준다.
- 여러 노드에 대한 실행/조회/정책 판단을 기계가 안전하게 조합할 수 있게 한다.
- 장기 작업, 로그, artifact, service, health를 shell text가 아니라 API로 다룬다.

## 1. 구조화 실행 결과

현재 구현됨:

- native daemon 실행 경로: `vssh server`
- structured exec protocol: `EXEJ`
- CLI/MCP 실행 결과 필드:
  - `success`
  - `stdout`
  - `stderr`
  - `exit_code`
  - `duration_ms`
  - `target`
  - `endpoint`
  - `transport`
  - `attempts`
  - `error`

왜 좋은가:

- SSH는 terminal stream을 반환한다. AI는 stderr인지 stdout인지, 실패인지 성공인지,
  timeout인지 exit code인지 추측해야 한다.
- vssh는 결과를 구조화해서 반환하므로 Codex/Claude/local LLM이 바로 분기할 수 있다.
- evidence envelope에 넣기 좋다.

예시 결과:

```json
{
  "success": false,
  "target": "d1",
  "command": "systemctl status kobolt",
  "stdout": "",
  "stderr": "Unit kobolt.service could not be found.",
  "exit_code": 4,
  "duration_ms": 37,
  "transport": "vssh-native",
  "error": {
    "code": "remote_exit_nonzero",
    "message": "remote command exited with code 4",
    "retryable": false
  }
}
```

## 2. Policy-aware 실행

현재 MCP에 있음:

- `vssh.policy.check`
- `vssh.exec.safe`
- `vssh.exec`
- `allow_dangerous`
- `policy_decision` evidence

현재 차단/승인 모델:

- 읽기/진단 명령은 허용
- 파괴적 명령, 재부팅, 삭제, service restart류는 기본 차단
- 명시적 승인 플래그가 있을 때만 위험 명령 실행

왜 좋은가:

- SSH는 실행 전에 command risk를 모른다.
- AI는 실수로 `rm`, `reboot`, `systemctl restart`, `kubectl delete` 같은 명령을
  만들 수 있다.
- vssh는 실행 전에 위험도를 구조화해서 돌려주고, 필요하면 사람/상위 policy gate를
  거치게 할 수 있다.

## 3. Routing: target을 직접 고르지 않는 실행

현재 MCP에 있음:

- `vssh.hosts.list`
- `vssh.route.select`
- `vssh.exec.routed`

라우팅 기준:

- required capabilities
- preferred tags
- health 상태
- explicit target 검증
- live monitor 연동

왜 좋은가:

- SSH는 "어느 서버에 접속할지"를 사람이 이미 알아야 한다.
- AI 작업에서는 "CUDA와 ollama가 있는 건강한 서버에서 실행"처럼 조건으로 라우팅하는
  편이 낫다.
- vssh는 host inventory, capabilities, health를 보고 target 선택 근거를 함께 남긴다.

예시 요청:

```json
{
  "required_capabilities": ["cuda", "ollama"],
  "preferred_tags": ["gpu"],
  "avoid_health": ["offline", "degraded"],
  "include_health": true,
  "command": "ollama list"
}
```

## 4. RPC: shell text 대신 typed node API

현재 daemon RPC 코드에 있음:

- `get_gpu`
- `get_disk`
- `get_memory`
- `get_load`
- `get_processes`
- `get_logs`
- `service_status`
- `list_services`
- `docker_containers`
- `file_read`
- `file_write`
- `restart_service`
- `INFO`

왜 좋은가:

- SSH에서는 `df`, `free`, `ps`, `journalctl`, `systemctl`, `docker ps` 출력 형식을
  매번 parsing해야 한다.
- vssh RPC는 이미 구조화된 JSON으로 node state를 반환할 수 있다.
- AI는 "문자열 파싱" 대신 "typed field 판단"을 한다.

예시:

```json
{
  "method": "get_gpu",
  "data": [
    {
      "index": 0,
      "name": "NVIDIA RTX 4090",
      "memory_total_mb": 24564,
      "memory_used_mb": 12031,
      "memory_free_mb": 12533,
      "utilization_percent": 71,
      "temperature_c": 63
    }
  ]
}
```

현재 상태:

- RPC는 daemon 내부와 MCP/CLI 표면에 노출되었다.
- CLI:
  - `vssh rpc <host> <method> [json]`
  - `vssh rpc-many <hosts> <method> [json]`
  - `vssh facts <host>`
- MCP:
  - `vssh.rpc.call`
  - `vssh.rpc.many`
  - `vssh.facts`
- 다음 구현에서는 `vssh.service.status`, `vssh.service.logs` 같은 더 구체적인
  운영 도구를 얹으면 된다.

## 5. 여러 서버 병렬 실행

제품 방향으로 반드시 필요함.

현재 상태:

- 단일 target 실행: 있음
- routed 단일 target 실행: 있음
- 여러 서버 fan-out command 실행: 있음
  - CLI: `vssh run-many <host1,host2> <command>`
  - MCP: `vssh.exec.many`
- 파일 전송 쪽에는 parallel download/multiplexed put 기반 코드가 있음
  - `GETM`
  - `GETC`
  - `MPUT`
  - `PIPE_UP`
  - `PIPE_DOWN`

제공 API:

- `vssh.exec.many`
- `vssh.rpc.many`
- `vssh.facts.many`
- `vssh.service.status.many`

현재 구현된 것은 `vssh.exec.many`, `vssh.rpc.many`이며, `facts.many`와
`service.status.many`는 `rpc.many` 기반으로 다음에 얹을 수 있다.

예상 입력:

```json
{
  "targets": ["d1", "v3", "macmini"],
  "command": "df -h /",
  "parallelism": 8,
  "timeout_seconds": 20,
  "allow_partial": true
}
```

예상 출력:

```json
{
  "success": true,
  "summary": {
    "total": 3,
    "ok": 2,
    "failed": 1,
    "duration_ms": 612
  },
  "results": [
    {"target": "d1", "success": true, "exit_code": 0, "stdout": "..."},
    {"target": "v3", "success": true, "exit_code": 0, "stdout": "..."},
    {"target": "macmini", "success": false, "error": {"code": "timeout"}}
  ]
}
```

왜 좋은가:

- SSH로도 `for host in ...; ssh ... &`는 가능하지만, 실패/timeout/부분 성공/요약/evidence
  처리가 모두 ad hoc script가 된다.
- vssh는 병렬 실행을 제품 기능으로 제공해서 AI가 fleet 작업을 안전하게 판단할 수 있다.
- 서버 운영에서는 "전체 노드 disk 확인", "전체 노드 특정 프로세스 확인", "GPU 노드만
  모델 상태 확인" 같은 작업이 기본이다.

## 6. Evidence envelope

현재 MCP 실행 응답에 있음:

- `tool`
- `target`
- `command`
- `started_at`
- `ended_at`
- `duration_ms`
- `timeout_sec`
- `policy`
- `approved`
- `blocked`
- `evidence_type`
- `result`

왜 좋은가:

- AI 작업은 나중에 "무슨 명령을 어디서 왜 실행했는지" 추적 가능해야 한다.
- 서버 운영 자동화는 감사 가능성이 제품 가치다.
- MeshClaw/Matrix/task ledger에 그대로 저장 가능하다.

## 7. Health-aware 자동화

현재 MCP에 있음:

- host record health
- live monitor 연동
- `monitor_url`
- `monitor_port`
- `include_health`
- health status:
  - `online`
  - `degraded`
  - `critical`
  - `offline`
  - `unknown`
  - `stale`

왜 좋은가:

- SSH는 연결 성공/실패만 알려준다.
- AI는 "실행 가능한가"뿐 아니라 "지금 이 서버에 작업을 맡겨도 되는가"를 알아야 한다.
- CPU/memory/disk/GPU pressure를 route decision에 반영할 수 있다.

## 8. File/artifact API

현재 daemon 코드에 있음:

- `PUT`
- `GET`
- `SYNC`
- `MPUT`
- `GETM`
- `GETC`
- `PIPE_UP`
- `PIPE_DOWN`

왜 좋은가:

- SSH/SCP는 파일 복사는 잘하지만 artifact 의미를 모른다.
- AI 작업에서는 "작업 결과물", "로그 묶음", "모델 checkpoint", "분석 리포트"를 명시적
  artifact로 수집해야 한다.
- vssh는 artifact collect를 first-class API로 만들 수 있다.

필요한 다음 API:

- `artifact_collect`
- `artifact_list`
- `artifact_get`
- `workspace_sync`

## 9. Service operations API

현재 RPC에 일부 있음:

- `service_status`
- `list_services`
- `restart_service` with whitelist
- `get_logs`
- `docker_containers`

왜 좋은가:

- SSH에서는 `systemctl`, `journalctl`, `docker` 출력 parsing이 필요하다.
- vssh는 service 상태/로그/재시작을 policy gate가 붙은 API로 제공할 수 있다.
- AI가 운영 자동화를 할 때 "상태 확인 -> 로그 분석 -> 안전 재시작 -> evidence 기록"을
  하나의 안정된 흐름으로 처리할 수 있다.

## 10. Security posture

vssh가 지향해야 하는 보안 방향:

- daemon auth는 `VSSH_SECRET` 또는 더 강한 node identity로 처리
- Tailscale ACL과 함께 사용
- action-level policy
- risky action approval
- append-only evidence
- capability-based exposure
- allowlist 기반 service operation

중요:

- vssh가 SSH보다 항상 더 안전하다는 뜻은 아니다.
- vssh는 "AI/automation이 쓰기 좋은 좁고 구조화된 실행 표면"을 제공해야 한다.

## 현재 구현/미구현 요약

| 영역 | 현재 상태 | 다음 작업 |
|---|---|---|
| Native daemon exec | 있음 | timeout/streaming 강화 |
| Structured stdout/stderr/exit | 있음 | MCP schema 테스트 강화 |
| Policy check | 있음 | policy 파일/role 연동 |
| Evidence envelope | 있음 | append-only store 연동 |
| Route select | 있음 | multi-route/fan-out |
| RPC methods | daemon/MCP/CLI 있음 | service/log 전용 tool 추가 |
| Multi-server parallel exec | 있음 | bounded parallelism/summary 강화 |
| Multi-server RPC | 있음 | facts/service 전용 many tool 추가 |
| Jobs | 문서 방향만 있음 | job store/worker 구현 |
| Artifact collect | 파일 전송 기반 있음 | artifact API 구현 |
| Service ops | 일부 RPC 있음 | policy-gated MCP tool |
| Health-aware routing | 있음 | vssh daemon native health 강화 |

## 개발 우선순위

1. `vssh.service.status`, `vssh.service.logs`: service 운영 API 노출.
2. `vssh.facts.many`: 여러 node facts 병렬 수집.
3. `artifact_collect`: 작업 결과 수집 API.
4. `job_start/job_status/job_logs/job_cancel`: 장기 작업 API.
5. bounded parallelism, retry policy, per-node evidence store 강화.

이 순서가 vssh의 차별점을 가장 빠르게 만든다.
