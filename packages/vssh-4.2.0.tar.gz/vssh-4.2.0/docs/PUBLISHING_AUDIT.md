# Public Repository Audit

This document records the public-release hygiene checks for this repository.

## Current Policy

- Source code is tracked in Git.
- Built binaries are not tracked in Git. Release binaries belong in GitHub Releases or package artifacts.
- Local node inventories, VPN addresses, hostnames, credentials, and personal deployment notes must not be committed.
- Example IP addresses should use documentation-only ranges: `192.0.2.0/24`, `198.51.100.0/24`, or `203.0.113.0/24`.
- Secrets belong in environment variables or local config files ignored by Git.

## Checks Performed

- Searched the current tree for common secret patterns:
  - private key headers
  - GitHub tokens
  - AWS access keys
  - OpenAI-style API keys
  - bearer tokens
  - obvious `password`, `secret`, `token`, and `api_key` assignments
- Searched the current tree and Git history for personal/internal-looking values:
  - personal usernames
  - private VPN IP examples
  - personal domains and email domains
  - Tailscale-style hostnames
- Removed tracked build binaries from the repository.
- Added `.gitignore` rules for local build outputs, environment files, and key material.
- Replaced public orchestration examples with generic node names and documentation IP ranges.

## Findings

- No real private keys or API tokens were found in the current tree.
- No committed production password was found.
- The repository did include tracked build binaries. They were removed from Git tracking.
- A Codex orchestration document contained environment-specific deployment examples. They were replaced with generic examples.
- Historical commits contain old documentation examples with private-address-looking values. These are not active secrets, but a history rewrite can remove them if the project requires stricter public hygiene.

## Before Each Public Release

Run:

```bash
git status --short
rg -n --hidden -S "(BEGIN (RSA|OPENSSH|PRIVATE) KEY|PRIVATE KEY|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]+|xox[baprs]-|sk-[A-Za-z0-9]{20,}|password\\s*[:=]|passwd\\s*[:=]|secret\\s*[:=]|token\\s*[:=]|api[_-]?key\\s*[:=]|Authorization:|Bearer\\s+[A-Za-z0-9._-]+)" .
rg -n --hidden -S "(tail[0-9a-z]+\\.ts\\.net|100\\.[0-9]+\\.[0-9]+\\.[0-9]+|10\\.[0-9]+\\.[0-9]+\\.[0-9]+|192\\.168\\.|172\\.(1[6-9]|2[0-9]|3[0-1])\\.)" .
go test ./...
```

