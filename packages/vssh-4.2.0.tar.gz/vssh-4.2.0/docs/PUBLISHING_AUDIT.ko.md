# 공개 저장소 점검 기록

이 문서는 VSSH 공개 repo에 개인 정보나 민감한 값이 들어가지 않도록 확인한 내용을 기록합니다.

## 현재 정책

- Git에는 소스 코드만 추적합니다.
- 빌드된 바이너리는 Git에 넣지 않습니다. 바이너리는 GitHub Releases나 패키지 산출물로 배포합니다.
- 실제 노드 목록, VPN 주소, 호스트명, 계정명, 개인 배포 메모는 커밋하지 않습니다.
- 예시 IP는 `192.0.2.0/24`, `198.51.100.0/24`, `203.0.113.0/24` 같은 문서용 대역만 사용합니다.
- 비밀값은 환경 변수나 Git에서 무시되는 로컬 설정 파일에 둡니다.

## 수행한 점검

- 현재 트리에서 일반적인 비밀값 패턴을 검색했습니다.
  - private key 헤더
  - GitHub token
  - AWS access key
  - OpenAI 형식 API key
  - bearer token
  - `password`, `secret`, `token`, `api_key` 형태의 명백한 할당
- 현재 트리와 Git 히스토리에서 개인/내부 값처럼 보이는 항목을 검색했습니다.
  - 개인 사용자명
  - private VPN IP 예시
  - 개인 도메인/이메일 도메인
  - Tailscale 형태 호스트명
- Git이 추적하던 빌드 바이너리를 제거했습니다.
- `.gitignore`에 빌드 산출물, 환경 파일, key 파일 규칙을 추가했습니다.
- Codex 오케스트레이션 문서의 실제 환경 예시를 일반 예시로 바꿨습니다.

## 발견 사항

- 현재 트리에서 실제 private key나 API token은 발견되지 않았습니다.
- 커밋된 운영 password는 발견되지 않았습니다.
- repo 루트에 빌드 바이너리가 Git 추적 상태로 들어가 있었습니다. Git 추적에서 제거했습니다.
- Codex 오케스트레이션 문서에 특정 환경을 떠올리게 하는 배포 예시가 있었습니다. 일반 예시로 교체했습니다.
- 과거 커밋에는 private-address처럼 보이는 문서 예시가 남아 있습니다. 활성 비밀값은 아니지만, 더 엄격한 공개 위생이 필요하면 history rewrite로 제거할 수 있습니다.

## 공개 릴리스 전 체크리스트

```bash
git status --short
rg -n --hidden -S "(BEGIN (RSA|OPENSSH|PRIVATE) KEY|PRIVATE KEY|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]+|xox[baprs]-|sk-[A-Za-z0-9]{20,}|password\\s*[:=]|passwd\\s*[:=]|secret\\s*[:=]|token\\s*[:=]|api[_-]?key\\s*[:=]|Authorization:|Bearer\\s+[A-Za-z0-9._-]+)" .
rg -n --hidden -S "(tail[0-9a-z]+\\.ts\\.net|100\\.[0-9]+\\.[0-9]+\\.[0-9]+|10\\.[0-9]+\\.[0-9]+\\.[0-9]+|192\\.168\\.|172\\.(1[6-9]|2[0-9]|3[0-1])\\.)" .
go test ./...
```

