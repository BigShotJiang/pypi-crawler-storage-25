# Network Traversal 기능 위치 조사

vssh, wire, p2pvpn-archive에 남아 있는 NAT traversal, relay, hole punching
관련 기능을 조사한 결과입니다.

## 결론

현재 vssh에는 NAT traversal/hole punching 본체가 없습니다.

vssh에 남아 있는 것은:

- native TCP daemon
- TCP relay fallback 조각
- Wire/Tailscale/config 기반 peer discovery
- 오래된 NAT traversal 문구 일부

NAT traversal의 본체는 wire에 남아 있습니다.

더 오래된 완전한 P2P 실험 구조는 p2pvpn-archive에 남아 있습니다.

## vssh에 남아 있는 것

파일:

- `internal/server/relay.go`

내용:

- `RELAY <ip:port>` 명령을 받아 TCP bidirectional proxy 수행
- 주석상 "Wire-level relay가 선호되고, 이것은 fallback TCP relay"라고 되어 있음

의미:

- NAT traversal 시스템이 아니라 단순 TCP relay handler입니다.
- STUN, endpoint discovery, hole punching coordination, NAT type detection은 없습니다.
- 현재 제품 방향에서는 core feature로 보기 어렵고, 향후 daemon-to-daemon relay가 필요할 때
  재설계해서 써야 합니다.

기타:

- `internal/ssh/ssh.go`는 coordinator/Tailscale/config/cache에서 peer 목록과 endpoint를 찾습니다.
- 이것은 discovery helper이지 NAT traversal 구현이 아닙니다.

## wire에 남아 있는 것

파일:

- `internal/nat/manager.go`
- `internal/nat/stun.go`
- `internal/vpn/manager.go`

구현/흔적:

- NAT manager
- STUN server/client
- external IP:port discovery
- relay mode
  - distributed
  - central
- HTTP relay server/client
- UDP relay server/client
- hole punching attempt path
- relay fallback
- WireGuard peer endpoint selection
- NAT-NAT 상황에서 relay AllowedIPs 구성
- WireGuard handshake failure 후 UDP relay fallback

중요 코드 흐름:

- `nat.Manager.Connect`: direct -> holepunch -> relay
- `vpn.Manager.selectEndpoint`: LAN -> public -> NAT hole punch 후보 -> fallback
- `vpn.Manager.checkAndFallbackToRelay`: handshake 실패가 일정 시간 지속되면 relay endpoint로 변경
- coordinator register payload에 NAT/relay 정보 포함:
  - `is_relay`
  - `relay_port`
  - `stun_port`
  - `ext_port`

의미:

- Wire는 "네트워크 경로를 만드는 계층"입니다.
- vssh는 이 계층을 다시 구현하지 않는 편이 맞습니다.
- 현재 방향에서는 Tailscale을 기본 transport로 쓰고, Wire의 NAT traversal은 legacy/custom mesh 옵션으로 남기는 것이 맞습니다.

## p2pvpn-archive에 남아 있는 것

파일:

- `src/nat/mod.rs`
- `src/nat/stun.rs`
- `src/nat/hole_punch.rs`
- `src/nat/relay.rs`
- `src/rendezvous.rs`
- `src/bootstrap/mod.rs`

구현/흔적:

- NAT type:
  - none
  - full cone
  - restricted
  - port restricted
  - symmetric
  - unknown
- STUN public address discovery
- NAT type detection
- UPnP port mapping
- hole punching
- simultaneous open
- rendezvous token/seed 기반 endpoint exchange
- relay fallback
- DHT/bootstrap discovery

의미:

- 가장 오래된 "직접 P2P VPN" 실험 구조가 여기 남아 있습니다.
- 제품화하기엔 범위가 크고, 현재 vssh 제품 방향에는 과합니다.
- 알고리즘 참고용 archive로 보는 것이 맞습니다.

## 제품 판단

vssh에 NAT traversal을 다시 넣는 것은 현재 방향과 맞지 않습니다.

이유:

- Tailscale이 이미 NAT traversal, relay/DERP, identity, ACL을 해결합니다.
- vssh의 차별점은 network traversal이 아니라 AI-native execution/RPC/evidence입니다.
- NAT traversal까지 vssh에 넣으면 "네트워크 제품"과 "실행 제품" 경계가 흐려집니다.

따라서 역할은 이렇게 나누는 것이 맞습니다.

```text
Tailscale / Wire
  -> reachability, NAT traversal, relay, identity/mesh path

vssh
  -> daemon exec, RPC, policy, evidence, jobs, artifacts, multi-node fan-out

MeshClaw
  -> fleet state, policy, orchestration, audit, auto-heal
```

## vssh에서 해야 할 일

남길 것:

- endpoint discovery
- native daemon TCP transport
- structured connection/evidence error
- optional relay awareness as metadata

하지 말 것:

- STUN 재구현
- hole punching 재구현
- WireGuard relay 재구현
- Tailscale DERP 대체

나중에 필요하면:

- `vssh` 자체 relay가 아니라 `transport` abstraction으로 분리
- `tailscale` backend
- `wire` backend
- `direct` backend

이렇게 두면 vssh는 실행 계층으로 선명하게 남습니다.
