# Changelog

## [Unreleased]

## [v0.7.4] - 2026-05-16

### Runtime

- Add `vssh.route.select` / `vssh_route_select` for capability, tag, and health-aware host routing.
- Add `vssh.exec.routed` / `vssh_exec_routed` to route first, then execute with policy and evidence.
- Return route decisions with selected host, score, reasons, missing capabilities, health, tags, and candidate host records.
- Keep monitoring separate: `vssh.hosts.list`, `vssh.route.select`, and `vssh.exec.routed` can optionally merge live health from an external MeshClaw/mpop-style monitor endpoint using `monitor_url` or `monitor_port`.

## [v0.7.3] - 2026-05-16

### Runtime

- Enrich `vssh.hosts.list` output with `addresses`, `tags`, `capabilities`, `health`, `stats`, `os`, `arch`, and metadata fields for agent routing.
- Extend `~/.vssh/servers.json` support with optional `tags`, `capabilities`, `roles`, `os`, `arch`, `public_ip`, `lan_ip`, `port`, and `metadata`.
- Infer basic capabilities from tags/roles/OS names, including `gpu`, `cuda`, `ollama`, `browser`, `controller`, `mail`, `docker`, `linux`, and `macos`.
- Add health summaries based on provider online state, `last_seen`, and resource pressure.

## [v0.7.2] - 2026-05-16

### Runtime

- Add agent-facing MCP tool aliases: `vssh.hosts.list`, `vssh.exec`, `vssh.exec.safe`, and `vssh.policy.check`.
- Add a built-in safety policy that blocks destructive/service-impacting command patterns unless `allow_dangerous` is explicitly set.
- Wrap MCP execution responses in evidence envelopes with timestamps, policy decision, target, command, timeout, and structured execution result.

### Documentation

- README / README.ko: link to canonical stack snapshot [`meshpop/wire` **docs/CURRENT_STATE.md**](https://github.com/meshpop/wire/blob/main/docs/CURRENT_STATE.md).
- Document Codex/Runtime MCP usage in English and Korean.

## [v0.7.1] - 2026-05-16

### Runtime

- Preserve MCP `vssh_exec` shell commands as one script instead of splitting with `strings.Fields`.
- Return structured execution evidence with stdout, stderr, exit code, duration, attempts, transport, fallback, and typed retryable errors.
- Fix root-run `vsshd` transfer ownership so PUT/PUTZ/RESUME/MPUT/PIPE_UP outputs are usable by the default non-root runtime user.

## [v0.7.0] - 2026-05-14

### Changed

- Remove `mesh-event` dependency; standalone `go build`.
- Document `internal/adapter` as **discovery-only**; `VSSHAdapter.Exec` remains unimplemented by design until explicitly specified.

### Fixed

- `go vet` cleanups (IPv6 literals) where applicable.

## Earlier releases

See Git tags and GitHub Releases.
