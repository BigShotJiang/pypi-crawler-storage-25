# VSSH

## What is VSSH

VSSH is an AI-native remote execution daemon/protocol for private networks.

- No sshd required on target
- Built-in PTY, RPC, file transfer, and execution evidence
- HMAC authentication
- Node-name routing over Tailscale, VPN, LAN, or configured addresses

## Components

| Binary | Description |
|--------|-------------|
| `vssh server` | Server daemon (port 48291) |
| `vssh` | CLI client |

## Quick Start

```bash
# Server side
export VSSH_SECRET=your-secret
vssh server

# Client side
export VSSH_SECRET=your-secret
vssh shell hostname      # Interactive shell
vssh run hostname "cmd"  # Execute command
```

## CLI Commands

### Native Protocol

```bash
vssh <host>                 # Interactive PTY shell
vssh shell <host>           # Interactive PTY shell
vssh run <host> <command>   # Execute command
vssh exec <host> <command>  # Alias for native run
vssh put <local> <host:path>  # Upload
vssh get <host:path> <local>  # Download
```

### Status

```bash
vssh status        # Show dashboard
vssh list          # List all peers
vssh version       # Show version
```

## Data Sources

VSSH discovers peers from multiple sources:

1. Wire VPN coordinator
2. Tailscale
3. Config file (~/.vssh/servers.json)
4. Cache

## Configuration

### Server Config

`~/.vssh/servers.json`:

```json
{
  "web1": {"ip": "192.0.2.10", "user": "deploy"},
  "db1": {"ip": "192.0.2.20", "user": "postgres"}
}
```

### User Mapping

Per-host SSH user overrides are read from Wire’s config directory (same as the Wire CLI), not under `~/.vssh/`:

- Non-root: `~/.wire/users.json`
- Root: `/etc/wire/users.json`

Example (`~/.wire/users.json`):

```json
{
  "web1": "deploy",
  "db1": "postgres"
}
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `VSSH_SECRET` | Primary shared secret for native protocol (set on client and server). |
| `VSSH_PORT` | Native server listen port (default: **48291**). |
| `WIRE_SERVER_URL` | If `VSSH_SECRET` is empty, a derived secret can be computed from this URL (and from `server_url` in Wire JSON config). |
| `VSSH_INSECURE_ALLOW_EMPTY_SECRET` | Set to `1` **only in isolated labs** to allow a native server with no secret (unsafe). |

## Security

- **Native `vssh server`** uses **HMAC** on a shared secret over **plain TCP**. **WireGuard** only encrypts traffic **inside the VPN**; it does **not** replace vssh authentication. Always set a strong secret (or derived secret) and firewall the listen port.
- VSSH does not expose an OpenSSH wrapper command. Use `ssh` directly for normal sshd-backed shell access.
- **`internal/adapter`**: discovery / `Probe` only; `Exec` is not implemented. Use native server commands for product execution.

## Architecture

| Package | Purpose |
|---------|---------|
| `internal/server` | Native protocol server and client |
| `internal/ssh` | Discovery helper and legacy internal connector |
| `internal/adapter` | Config-based node discovery and probing (Exec not implemented) |
| `internal/agent` | Monitoring agent with event logging |
