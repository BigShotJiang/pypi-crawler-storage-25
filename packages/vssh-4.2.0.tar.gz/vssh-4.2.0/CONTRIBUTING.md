# Contributing

- **Branches:** PRs to `main`; describe behavior changes (especially auth / `vssh server`).
- **Build:** `go vet ./...`, `go build ./...`, `go test ./...` (CI matches).
- **Shell:** `bash -n install.sh` when editing installers.
- **Security:** [Security advisories](https://github.com/meshpop/vssh/security/advisories/new) for private reports.
