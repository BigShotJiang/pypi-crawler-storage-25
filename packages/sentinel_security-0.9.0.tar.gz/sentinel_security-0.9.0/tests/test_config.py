"""Tests for sentinel_security.config module."""

import importlib
import json
import os
import pytest


def _reload_config(monkeypatch, env_vars=None):  # type: ignore[assignment]
    """Reload config module with optional env var overrides.

    Clears all SENTINEL_* env vars first, then applies any provided ones.
    """
    sentinel_keys = [k for k in os.environ if k.startswith("SENTINEL_")]
    for key in sentinel_keys:
        monkeypatch.delenv(key, raising=False)

    if env_vars:
        for key, val in env_vars.items():
            monkeypatch.setenv(key, val)

    import sentinel_security.config as cfg
    importlib.reload(cfg)
    return cfg


class TestDefaults:
    def test_default_risk_weights_type(self, monkeypatch):
        cfg = _reload_config(monkeypatch)
        assert isinstance(cfg.RISK_WEIGHTS, dict)

    def test_default_risk_weights_has_injection_pattern(self, monkeypatch):
        cfg = _reload_config(monkeypatch)
        assert 'injection_pattern' in cfg.RISK_WEIGHTS
        assert cfg.RISK_WEIGHTS['injection_pattern'] == 4

    def test_default_http_timeout(self, monkeypatch):
        cfg = _reload_config(monkeypatch)
        assert cfg.HTTP_TIMEOUT == 30

    def test_default_ms_credentials_empty(self, monkeypatch):
        cfg = _reload_config(monkeypatch)
        assert cfg.MS_TENANT_ID == ""
        assert cfg.MS_CLIENT_ID == ""
        assert cfg.MS_CLIENT_SECRET == ""

    def test_graph_base_url(self, monkeypatch):
        cfg = _reload_config(monkeypatch)
        assert cfg.GRAPH_BASE_URL == "https://graph.microsoft.com/v1.0"


class TestRiskWeightsOverride:
    def test_partial_override_merges(self, monkeypatch):
        override = json.dumps({"injection_pattern": 10, "homoglyph": 7})
        cfg = _reload_config(monkeypatch, {"SENTINEL_RISK_WEIGHTS": override})
        assert cfg.RISK_WEIGHTS['injection_pattern'] == 10
        assert cfg.RISK_WEIGHTS['homoglyph'] == 7
        # Other defaults preserved
        assert cfg.RISK_WEIGHTS['hidden_html'] == 3

    def test_full_override(self, monkeypatch):
        custom = {"custom_key": 99}
        cfg = _reload_config(monkeypatch, {"SENTINEL_RISK_WEIGHTS": json.dumps(custom)})
        # Custom key present
        assert cfg.RISK_WEIGHTS['custom_key'] == 99
        # Defaults still present (merged)
        assert 'injection_pattern' in cfg.RISK_WEIGHTS

    def test_malformed_json_falls_back_to_defaults(self, monkeypatch):
        cfg = _reload_config(monkeypatch, {"SENTINEL_RISK_WEIGHTS": "not-valid-json"})
        assert cfg.RISK_WEIGHTS['injection_pattern'] == 4

    def test_empty_string_uses_defaults(self, monkeypatch):
        cfg = _reload_config(monkeypatch, {"SENTINEL_RISK_WEIGHTS": ""})
        assert cfg.RISK_WEIGHTS['injection_pattern'] == 4


class TestHttpTimeout:
    def test_custom_timeout(self, monkeypatch):
        cfg = _reload_config(monkeypatch, {"SENTINEL_HTTP_TIMEOUT": "60"})
        assert cfg.HTTP_TIMEOUT == 60


class TestMsCredentials:
    def test_custom_credentials(self, monkeypatch):
        cfg = _reload_config(monkeypatch, {
            "SENTINEL_MS_TENANT_ID": "tenant-123",
            "SENTINEL_MS_CLIENT_ID": "client-456",
            "SENTINEL_MS_CLIENT_SECRET": "secret-789",
        })
        assert cfg.MS_TENANT_ID == "tenant-123"
        assert cfg.MS_CLIENT_ID == "client-456"
        assert cfg.MS_CLIENT_SECRET == "secret-789"
