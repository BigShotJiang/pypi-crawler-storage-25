"""Tests for ARCH-4: Thread safety for configure().

Verifies:
- Concurrent configure() calls don't corrupt config
- configure() during engine creation produces consistent config
- RLock allows reentrant calls without deadlock
- _reset_global_config is thread-safe
"""

from __future__ import annotations

import threading
import time

import pytest

from sentinel_security.configure import (
    _config_lock,
    _reset_global_config,
    configure,
)
from sentinel_security.middleware.engine import DetectionEngine


class TestConfigureLock:
    """Verify _config_lock is an RLock and is used correctly."""

    def setup_method(self):
        _reset_global_config()

    def teardown_method(self):
        _reset_global_config()

    def test_config_lock_is_rlock(self):
        """Lock must be RLock (reentrant) not Lock."""
        assert isinstance(_config_lock, type(threading.RLock()))

    def test_rlock_allows_reentrant_acquisition(self):
        """RLock can be acquired twice from the same thread without deadlocking."""
        with _config_lock:
            with _config_lock:
                pass  # Should not deadlock


class TestConcurrentConfigure:
    """Concurrent configure() calls must not corrupt config."""

    def setup_method(self):
        _reset_global_config()

    def teardown_method(self):
        _reset_global_config()

    def test_concurrent_configure_no_corruption(self):
        """Multiple threads calling configure() simultaneously produce valid configs."""
        errors = []
        results = []

        def configure_thread(policy, threshold):
            try:
                result = configure(policy=policy, risk_threshold=threshold)
                results.append(result)
            except Exception as e:
                errors.append(e)

        threads = []
        for i in range(10):
            policy = "block" if i % 2 == 0 else "warn"
            threshold = i + 1
            t = threading.Thread(target=configure_thread, args=(policy, threshold))
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        assert not errors, f"Errors in threads: {errors}"
        assert len(results) == 10

        # Each result should be a valid config dict
        for r in results:
            assert "policy" in r
            assert "risk_threshold" in r
            assert r["policy"] in ("block", "warn")

    def test_configure_during_engine_creation(self):
        """Engine created while configure() is running gets a consistent config."""
        errors = []
        engines = []

        def configure_loop():
            for _ in range(20):
                try:
                    configure(policy="block", risk_threshold=8)
                except Exception as e:
                    errors.append(e)

        def engine_loop():
            for _ in range(20):
                try:
                    engine = DetectionEngine()
                    engines.append(engine)
                except Exception as e:
                    errors.append(e)

        t1 = threading.Thread(target=configure_loop)
        t2 = threading.Thread(target=engine_loop)
        t1.start()
        t2.start()
        t1.join(timeout=5)
        t2.join(timeout=5)

        assert not errors, f"Errors in threads: {errors}"
        # Each engine should have a valid policy
        for engine in engines:
            assert engine.policy in ("warn", "block", "log")

    def test_concurrent_reset_and_configure(self):
        """Concurrent reset and configure don't corrupt state."""
        errors = []

        def configure_loop():
            for _ in range(20):
                try:
                    configure(policy="block", risk_threshold=3)
                except Exception as e:
                    errors.append(e)

        def reset_loop():
            for _ in range(20):
                try:
                    _reset_global_config()
                except Exception as e:
                    errors.append(e)

        t1 = threading.Thread(target=configure_loop)
        t2 = threading.Thread(target=reset_loop)
        t1.start()
        t2.start()
        t1.join(timeout=5)
        t2.join(timeout=5)

        assert not errors, f"Errors in threads: {errors}"

    def test_engine_reads_complete_config(self):
        """Engine always reads a complete (non-partial) config snapshot."""
        configure(policy="block", risk_threshold=7)
        engines = []
        errors = []

        def create_engines():
            for _ in range(50):
                try:
                    engine = DetectionEngine()
                    # Config must be consistent: if policy=block, threshold
                    # should be a valid int
                    assert isinstance(engine.risk_threshold, int)
                    engines.append(engine)
                except Exception as e:
                    errors.append(e)

        threads = [threading.Thread(target=create_engines) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert not errors
        assert len(engines) == 200
