"""Tests for ARCH-1/ARCH-2: Shared helpers in _utils.py.

Verifies:
- content_hash() produces stable SHA-256 hashes
- extract_message_content() handles string, list, and missing content
- Dedup adapters (crewai, autogen) use the shared helper
- LangChain adapters use the shared extract_message_content helper
"""

from __future__ import annotations

import hashlib

import pytest

from sentinel_security.middleware._utils import content_hash, extract_message_content


# ══════════════════════════════════════════════════════════════════════
# content_hash tests
# ══════════════════════════════════════════════════════════════════════


class TestContentHash:
    """content_hash() returns stable SHA-256 hex digests."""

    def test_returns_hex_string(self):
        result = content_hash("hello")
        assert isinstance(result, str)
        assert len(result) == 64  # SHA-256 hex digest length

    def test_matches_hashlib_directly(self):
        text = "test content for hashing"
        expected = hashlib.sha256(text.encode("utf-8")).hexdigest()
        assert content_hash(text) == expected

    def test_same_input_same_hash(self):
        assert content_hash("identical") == content_hash("identical")

    def test_different_input_different_hash(self):
        assert content_hash("one") != content_hash("two")

    def test_empty_string(self):
        result = content_hash("")
        expected = hashlib.sha256(b"").hexdigest()
        assert result == expected

    def test_unicode_content(self):
        result = content_hash("Hello, \u4e16\u754c!")
        expected = hashlib.sha256("Hello, \u4e16\u754c!".encode("utf-8")).hexdigest()
        assert result == expected

    def test_long_content(self):
        text = "x" * 100_000
        result = content_hash(text)
        assert len(result) == 64


# ══════════════════════════════════════════════════════════════════════
# extract_message_content tests
# ══════════════════════════════════════════════════════════════════════


class _FakeMessage:
    """Mock of a LangChain message with .content attribute."""
    def __init__(self, content):
        self.content = content


class TestExtractMessageContent:
    """extract_message_content() handles various message formats."""

    def test_string_content(self):
        msg = _FakeMessage("hello world")
        assert extract_message_content(msg) == "hello world"

    def test_list_of_strings(self):
        msg = _FakeMessage(["hello", "world"])
        assert extract_message_content(msg) == "hello\nworld"

    def test_list_of_text_dicts(self):
        msg = _FakeMessage([
            {"type": "text", "text": "Hello"},
            {"type": "text", "text": "World"},
        ])
        assert extract_message_content(msg) == "Hello\nWorld"

    def test_mixed_list(self):
        msg = _FakeMessage([
            "plain text",
            {"type": "text", "text": "dict text"},
            {"type": "image", "url": "http://example.com/img.png"},
        ])
        result = extract_message_content(msg)
        assert "plain text" in result
        assert "dict text" in result

    def test_no_content_attribute(self):
        msg = object()
        assert extract_message_content(msg) == ""

    def test_none_content(self):
        msg = _FakeMessage(None)
        assert extract_message_content(msg) == ""

    def test_empty_string_content(self):
        msg = _FakeMessage("")
        assert extract_message_content(msg) == ""

    def test_empty_list_content(self):
        msg = _FakeMessage([])
        assert extract_message_content(msg) == ""


# ══════════════════════════════════════════════════════════════════════
# Integration: adapters import from _utils
# ══════════════════════════════════════════════════════════════════════


class TestAdaptersUseSharedHelpers:
    """Verify adapters import helpers from _utils instead of defining locally."""

    def test_crewai_uses_shared_content_hash(self):
        """crewai module's _content_hash is the shared one."""
        import sys
        import types
        sys.modules.setdefault("crewai", types.ModuleType("crewai"))
        from sentinel_security.middleware.crewai import _content_hash
        assert _content_hash is content_hash

    def test_autogen_uses_shared_content_hash(self):
        """autogen module's _content_hash is the shared one."""
        import sys
        import types
        sys.modules.setdefault("ag2", types.ModuleType("ag2"))
        from sentinel_security.middleware.autogen import _content_hash
        assert _content_hash is content_hash

    def test_langchain_uses_shared_extract_content(self):
        """langchain module's _extract_content is the shared one."""
        import sys
        import types
        if "langchain" not in sys.modules:
            middleware_types = types.ModuleType("langchain.agents.middleware.types")
            class AgentMiddleware:
                pass
            middleware_types.AgentMiddleware = AgentMiddleware
            middleware_pkg = types.ModuleType("langchain.agents.middleware")
            middleware_pkg.types = middleware_types
            agents_pkg = types.ModuleType("langchain.agents")
            agents_pkg.middleware = middleware_pkg
            langchain_pkg = types.ModuleType("langchain")
            langchain_pkg.agents = agents_pkg
            sys.modules.setdefault("langchain", langchain_pkg)
            sys.modules.setdefault("langchain.agents", agents_pkg)
            sys.modules.setdefault("langchain.agents.middleware", middleware_pkg)
            sys.modules.setdefault("langchain.agents.middleware.types", middleware_types)
        from sentinel_security.middleware.langchain import _extract_content
        assert _extract_content is extract_message_content

    def test_langchain_callback_uses_shared_extract_content(self):
        """langchain_callback module's _extract_content is the shared one."""
        import sys
        import types
        if "langchain_core" not in sys.modules:
            callbacks_mod = types.ModuleType("langchain_core.callbacks")
            class BaseCallbackHandler:
                pass
            callbacks_mod.BaseCallbackHandler = BaseCallbackHandler
            outputs_mod = types.ModuleType("langchain_core.outputs")
            class LLMResult:
                pass
            outputs_mod.LLMResult = LLMResult
            langchain_core_pkg = types.ModuleType("langchain_core")
            langchain_core_pkg.callbacks = callbacks_mod
            langchain_core_pkg.outputs = outputs_mod
            sys.modules.setdefault("langchain_core", langchain_core_pkg)
            sys.modules.setdefault("langchain_core.callbacks", callbacks_mod)
            sys.modules.setdefault("langchain_core.outputs", outputs_mod)
        from sentinel_security.middleware.langchain_callback import _extract_content
        assert _extract_content is extract_message_content
