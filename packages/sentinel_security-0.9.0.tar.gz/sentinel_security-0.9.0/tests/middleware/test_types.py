"""Tests for sentinel_security.middleware._types."""

from __future__ import annotations

import pytest

from sentinel_security.middleware._types import (
    ScanContext,
    ScanEvent,
    ScanResult,
    SentinelBlockedError,
)


# ── ScanResult immutability ──────────────────────────────────────────

class TestScanResultFrozen:
    def test_cannot_mutate_risk_level(self):
        result = ScanResult(risk_level="HIGH")
        with pytest.raises(AttributeError):
            result.risk_level = "LOW"  # type: ignore[misc]

    def test_cannot_mutate_risk_score(self):
        result = ScanResult(risk_score=7)
        with pytest.raises(AttributeError):
            result.risk_score = 0  # type: ignore[misc]

    def test_cannot_mutate_action_taken(self):
        result = ScanResult(action_taken="block")
        with pytest.raises(AttributeError):
            result.action_taken = "allow"  # type: ignore[misc]

    def test_cannot_mutate_source(self):
        result = ScanResult(source="input")
        with pytest.raises(AttributeError):
            result.source = "output"  # type: ignore[misc]


class TestScanResultDefaults:
    def test_default_values(self):
        result = ScanResult()
        assert result.risk_level == "CLEAN"
        assert result.risk_score == 0
        assert result.threats == []
        assert result.action_taken == "allow"
        assert result.source == ""
        assert result.content_length == 0
        assert result.scan_duration_ms == 0.0
        assert result.clean_text == ""

    def test_scan_id_generated(self):
        r1 = ScanResult()
        r2 = ScanResult()
        assert r1.scan_id != r2.scan_id
        assert len(r1.scan_id) == 36  # UUID format

    def test_timestamp_generated(self):
        result = ScanResult()
        assert result.timestamp.endswith("Z")


class TestScanResultSerialisation:
    def test_to_dict(self):
        result = ScanResult(
            risk_level="HIGH",
            risk_score=7,
            threats=[{"type": "injection_pattern", "name": "test"}],
            action_taken="block",
            source="input",
            content_length=100,
        )
        d = result.to_dict()
        assert isinstance(d, dict)
        assert d["risk_level"] == "HIGH"
        assert d["risk_score"] == 7
        assert d["action_taken"] == "block"
        assert d["source"] == "input"
        assert d["content_length"] == 100
        assert isinstance(d["threats"], list)


# ── ScanEvent immutability & serialisation ───────────────────────────

class TestScanEventFrozen:
    def test_cannot_mutate_event_type(self):
        event = ScanEvent(event_type="blocked")
        with pytest.raises(AttributeError):
            event.event_type = "scan_complete"  # type: ignore[misc]

    def test_cannot_mutate_content(self):
        event = ScanEvent(content="secret")
        with pytest.raises(AttributeError):
            event.content = None  # type: ignore[misc]


class TestScanEventSerialisation:
    def test_to_dict(self):
        event = ScanEvent(
            scan_id="abc-123",
            event_type="threat_detected",
            framework="langchain",
            source="before_model",
            risk_score=6,
            risk_level="HIGH",
            threats=[{"type": "injection_pattern", "name": "ignore previous"}],
            action="flag",
            scan_duration_ms=2.5,
            content_length=500,
            policy_applied="warn",
            risk_threshold_applied=5,
            engine_version=1,
        )
        d = event.to_dict()
        assert isinstance(d, dict)
        assert d["scan_id"] == "abc-123"
        assert d["framework"] == "langchain"
        assert d["engine_version"] == 1
        assert d["content"] is None

    def test_to_dict_with_content(self):
        event = ScanEvent(content="some text for debugging")
        d = event.to_dict()
        assert d["content"] == "some text for debugging"

    def test_default_content_is_none(self):
        event = ScanEvent()
        assert event.content is None


# ── ScanContext ──────────────────────────────────────────────────────

class TestScanContext:
    def test_frozen(self):
        ctx = ScanContext(framework="langchain", hook_point="before_model")
        with pytest.raises(AttributeError):
            ctx.framework = "crewai"  # type: ignore[misc]

    def test_session_id_for_dedup(self):
        ctx1 = ScanContext(session_id="sess-001")
        ctx2 = ScanContext(session_id="sess-001")
        assert ctx1.session_id == ctx2.session_id
        assert ctx1 == ctx2

    def test_different_session_ids_not_equal(self):
        ctx1 = ScanContext(session_id="sess-001")
        ctx2 = ScanContext(session_id="sess-002")
        assert ctx1 != ctx2

    def test_defaults(self):
        ctx = ScanContext()
        assert ctx.framework == ""
        assert ctx.hook_point == ""
        assert ctx.agent_id is None
        assert ctx.session_id is None
        assert ctx.metadata == {}


# ── SentinelBlockedError ─────────────────────────────────────────────

class TestSentinelBlockedError:
    def test_carries_scan_result(self):
        result = ScanResult(
            risk_level="CRITICAL",
            risk_score=9,
            action_taken="block",
            scan_id="test-id-123",
        )
        error = SentinelBlockedError(result)
        assert error.result is result
        assert error.result.risk_level == "CRITICAL"
        assert error.result.risk_score == 9

    def test_error_message(self):
        result = ScanResult(
            risk_level="HIGH",
            risk_score=7,
            scan_id="test-id-456",
        )
        error = SentinelBlockedError(result)
        msg = str(error)
        assert "HIGH" in msg
        assert "7" in msg
        assert "test-id-456" in msg

    def test_is_exception(self):
        result = ScanResult()
        error = SentinelBlockedError(result)
        assert isinstance(error, Exception)

    def test_can_be_raised_and_caught(self):
        result = ScanResult(risk_level="CRITICAL", risk_score=10)
        with pytest.raises(SentinelBlockedError) as exc_info:
            raise SentinelBlockedError(result)
        assert exc_info.value.result.risk_score == 10
