"""
Tests for sentinel_security.licence — Python-only licence validation (US-6).

All HTTP calls are mocked. No real Supabase calls are ever made.
"""

from __future__ import annotations

import hashlib
import json
import urllib.error
from unittest import mock

import pytest

from sentinel_security.licence import (
    DEFAULT_VERIFY_URL,
    LicenceResult,
    _hash_key,
    clear_cache,
    validate_licence,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_urlopen_response(data: dict, status: int = 200):
    """Create a mock urllib response that returns JSON data."""
    body = json.dumps(data).encode("utf-8")
    resp = mock.MagicMock()
    resp.read.return_value = body
    resp.__enter__ = mock.MagicMock(return_value=resp)
    resp.__exit__ = mock.MagicMock(return_value=False)
    resp.status = status
    return resp


VALID_KEY = "sk-sent-test1234567890abcdef"
VALID_KEY_HASH = hashlib.sha256(VALID_KEY.encode("utf-8")).hexdigest()

VALID_RESPONSE = {
    "valid": True,
    "email": "user@example.com",
    "scope": "individual",
    "expires_at": "2027-01-01T00:00:00Z",
}

INVALID_RESPONSE = {
    "valid": False,
    "reason": "invalid_key",
}

EXPIRED_RESPONSE = {
    "valid": False,
    "reason": "expired",
    "expires_at": "2025-01-01T00:00:00Z",
}

TEAM_RESPONSE = {
    "valid": True,
    "email": "admin@company.com",
    "scope": "team",
    "expires_at": "2027-06-01T00:00:00Z",
}

ORG_RESPONSE = {
    "valid": True,
    "email": "admin@enterprise.com",
    "scope": "org",
    "expires_at": "2027-12-31T00:00:00Z",
}


@pytest.fixture(autouse=True)
def _clear_cache():
    """Clear the licence cache before each test."""
    clear_cache()
    yield
    clear_cache()


# ---------------------------------------------------------------------------
# LicenceResult dataclass
# ---------------------------------------------------------------------------


class TestLicenceResult:
    def test_valid_result(self):
        r = LicenceResult(valid=True, email="a@b.com", scope="individual")
        assert r.valid is True
        assert r.email == "a@b.com"
        assert r.scope == "individual"

    def test_invalid_result_defaults(self):
        r = LicenceResult(valid=False)
        assert r.valid is False
        assert r.email is None
        assert r.scope is None
        assert r.expires_at is None
        assert r.reason is None

    def test_frozen(self):
        r = LicenceResult(valid=True)
        with pytest.raises(AttributeError):
            r.valid = False  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Key hashing
# ---------------------------------------------------------------------------


class TestKeyHashing:
    def test_hash_is_sha256(self):
        h = _hash_key("my-secret-key")
        assert h == hashlib.sha256(b"my-secret-key").hexdigest()
        assert len(h) == 64

    def test_hash_deterministic(self):
        assert _hash_key("abc") == _hash_key("abc")

    def test_hash_differs_for_different_keys(self):
        assert _hash_key("key-a") != _hash_key("key-b")


# ---------------------------------------------------------------------------
# Valid key
# ---------------------------------------------------------------------------


class TestValidKey:
    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_valid_key_returns_valid_result(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        result = validate_licence(VALID_KEY)
        assert result.valid is True
        assert result.email == "user@example.com"
        assert result.scope == "individual"
        assert result.expires_at == "2027-01-01T00:00:00Z"

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_key_sent_as_hash_not_plaintext(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        validate_licence(VALID_KEY)

        # Inspect the request body
        call_args = mock_urlopen.call_args
        request_obj = call_args[0][0]
        body = json.loads(request_obj.data.decode("utf-8"))
        assert "key_hash" in body
        assert body["key_hash"] == VALID_KEY_HASH
        # Plaintext key must NOT appear in the request
        assert VALID_KEY not in request_obj.data.decode("utf-8")

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_team_scope(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(TEAM_RESPONSE)
        result = validate_licence("sk-sent-team-key")
        assert result.valid is True
        assert result.scope == "team"

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_org_scope(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(ORG_RESPONSE)
        result = validate_licence("sk-sent-org-key")
        assert result.valid is True
        assert result.scope == "org"


# ---------------------------------------------------------------------------
# Invalid / expired key
# ---------------------------------------------------------------------------


class TestInvalidKey:
    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_invalid_key_returns_invalid(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(INVALID_RESPONSE)
        result = validate_licence("bad-key")
        assert result.valid is False
        assert result.reason == "invalid_key"

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_expired_key(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(EXPIRED_RESPONSE)
        result = validate_licence("expired-key")
        assert result.valid is False
        assert result.reason == "expired"
        assert result.expires_at == "2025-01-01T00:00:00Z"


# ---------------------------------------------------------------------------
# No key provided
# ---------------------------------------------------------------------------


class TestNoKey:
    def test_no_key_returns_no_key_reason(self):
        result = validate_licence(None)
        assert result.valid is False
        assert result.reason == "no_key"

    def test_empty_string_key_returns_no_key(self):
        result = validate_licence("")
        assert result.valid is False
        assert result.reason == "no_key"


# ---------------------------------------------------------------------------
# Offline / network error fallback
# ---------------------------------------------------------------------------


class TestOfflineFallback:
    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_network_error_returns_offline(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
        result = validate_licence(VALID_KEY)
        assert result.valid is False
        assert result.reason == "offline"

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_timeout_returns_offline(self, mock_urlopen):
        mock_urlopen.side_effect = OSError("timed out")
        result = validate_licence(VALID_KEY)
        assert result.valid is False
        assert result.reason == "offline"

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_offline_result_not_cached(self, mock_urlopen):
        """Offline results should NOT be cached so retry works on next call."""
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
        validate_licence(VALID_KEY)
        assert mock_urlopen.call_count == 1

        # Second call should hit the network again (not return cached offline)
        mock_urlopen.side_effect = None
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        result = validate_licence(VALID_KEY)
        assert result.valid is True
        assert mock_urlopen.call_count == 2


# ---------------------------------------------------------------------------
# Caching
# ---------------------------------------------------------------------------


class TestCaching:
    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_valid_cached_second_call_no_network(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        t = 1000.0
        result1 = validate_licence(VALID_KEY, _time_fn=lambda: t)
        assert result1.valid is True
        assert mock_urlopen.call_count == 1

        # Second call within 24h — should use cache
        result2 = validate_licence(VALID_KEY, _time_fn=lambda: t + 3600)
        assert result2.valid is True
        assert mock_urlopen.call_count == 1  # no additional network call

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_valid_cache_expires_after_24h(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        t = 1000.0
        validate_licence(VALID_KEY, _time_fn=lambda: t)
        assert mock_urlopen.call_count == 1

        # After 24h + 1s — cache expired, should hit network
        validate_licence(VALID_KEY, _time_fn=lambda: t + 86401)
        assert mock_urlopen.call_count == 2

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_invalid_cache_expires_after_5min(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(INVALID_RESPONSE)
        t = 1000.0
        validate_licence("bad-key", _time_fn=lambda: t)
        assert mock_urlopen.call_count == 1

        # Within 5min — cached
        validate_licence("bad-key", _time_fn=lambda: t + 200)
        assert mock_urlopen.call_count == 1

        # After 5min + 1s — expired, should hit network
        validate_licence("bad-key", _time_fn=lambda: t + 301)
        assert mock_urlopen.call_count == 2


# ---------------------------------------------------------------------------
# Environment variable loading
# ---------------------------------------------------------------------------


class TestEnvVarLoading:
    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    @mock.patch.dict("os.environ", {"SENTINEL_LICENCE_KEY": VALID_KEY})
    def test_loads_key_from_env_var(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        result = validate_licence()  # no key arg
        assert result.valid is True
        assert mock_urlopen.call_count == 1

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    @mock.patch.dict("os.environ", {"SENTINEL_LICENCE_KEY": VALID_KEY})
    def test_explicit_key_overrides_env(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(INVALID_RESPONSE)
        result = validate_licence("different-key")
        assert result.valid is False
        # Should have used "different-key", not env var
        call_args = mock_urlopen.call_args
        request_obj = call_args[0][0]
        body = json.loads(request_obj.data.decode("utf-8"))
        different_hash = hashlib.sha256(b"different-key").hexdigest()
        assert body["key_hash"] == different_hash


# ---------------------------------------------------------------------------
# HTTPS enforcement
# ---------------------------------------------------------------------------


class TestHTTPSEnforcement:
    def test_http_url_rejected(self):
        with pytest.raises(ValueError, match="HTTPS"):
            validate_licence(VALID_KEY, verify_url="http://evil.com/api/verify")

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_https_url_accepted(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        result = validate_licence(
            VALID_KEY, verify_url="https://custom-endpoint.com/verify"
        )
        assert result.valid is True

    def test_ftp_url_rejected(self):
        with pytest.raises(ValueError, match="HTTPS"):
            validate_licence(VALID_KEY, verify_url="ftp://files.com/licence")


# ---------------------------------------------------------------------------
# Request format
# ---------------------------------------------------------------------------


class TestRequestFormat:
    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_request_is_post(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        validate_licence(VALID_KEY)
        call_args = mock_urlopen.call_args
        request_obj = call_args[0][0]
        assert request_obj.method == "POST"

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_content_type_json(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        validate_licence(VALID_KEY)
        call_args = mock_urlopen.call_args
        request_obj = call_args[0][0]
        assert request_obj.get_header("Content-type") == "application/json"

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_default_url(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        validate_licence(VALID_KEY)
        call_args = mock_urlopen.call_args
        request_obj = call_args[0][0]
        assert request_obj.full_url == DEFAULT_VERIFY_URL

    @mock.patch("sentinel_security.licence.urllib.request.urlopen")
    def test_timeout_is_10s(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(VALID_RESPONSE)
        validate_licence(VALID_KEY)
        call_args = mock_urlopen.call_args
        assert call_args[1].get("timeout") == 10


# ---------------------------------------------------------------------------
# Top-level import
# ---------------------------------------------------------------------------


class TestTopLevelImport:
    def test_importable_from_package(self):
        from sentinel_security import validate_licence as vl

        assert callable(vl)
