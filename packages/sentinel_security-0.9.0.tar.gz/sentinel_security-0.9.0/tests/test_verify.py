"""Tests for sentinel-scan --verify flag."""
import os
import subprocess
import sys
import pytest


def test_verify_no_key(monkeypatch):
    """--verify with no SENTINEL_LICENCE_KEY should exit 1 with guidance."""
    monkeypatch.delenv("SENTINEL_LICENCE_KEY", raising=False)
    result = subprocess.run(
        [sys.executable, "-m", "sentinel_security.cli", "--verify"],
        capture_output=True, text=True, env={**os.environ, "SENTINEL_LICENCE_KEY": ""}
    )
    # Should fail and show help text
    assert result.returncode == 1
    assert "No licence key found" in result.stdout or "No licence key found" in result.stderr


def test_verify_flag_exists():
    """--verify should be a recognised argument (not 'unrecognized')."""
    result = subprocess.run(
        [sys.executable, "-m", "sentinel_security.cli", "--verify"],
        capture_output=True, text=True,
        env={k: v for k, v in os.environ.items() if k != "SENTINEL_LICENCE_KEY"}
    )
    assert "unrecognized arguments" not in result.stderr
