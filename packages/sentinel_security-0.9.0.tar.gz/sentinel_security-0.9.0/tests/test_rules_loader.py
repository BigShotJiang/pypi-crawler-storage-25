"""Tests for the encrypted rules loader (EncryptedRulesLoader).

Tests cover:
  - Key derivation golden-value test
  - AES-256-GCM encrypt/decrypt round-trip
  - Cache TTL state machine transitions
  - Ed25519 signature verification
  - HTTP 402 responses (licence errors)
  - Corrupted cache → re-fetch
  - Offline + expired cache → degraded safe default
  - Feature flag behaviour
  - Plaintext fallback (existing Phase 1 loader)
"""

import base64
import hashlib
import json
import os
import tempfile
import time
import warnings

import pytest

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from sentinel_security.rules_loader import (
    EncryptedRulesLoader,
    SentinelBundleTamperError,
    SentinelDegradedWarning,
    PBKDF2_ITERATIONS,
    KEY_LENGTH,
    STATIC_SALT,
    HKDF_INFO,
    PBKDF2_SALT_DOMAIN,
    DEFAULT_TTL_SECONDS,
    GRACE_WINDOW_SECONDS,
    _use_encrypted_rules,
    load_rules,
    get_rules_data,
    get_patterns,
)


# ---------- Fixtures ----------

TEST_LICENCE_KEY = 'test-licence-key-sentinel-2026'
TEST_BUNDLE_ID = 'test-bundle-id-001'
TEST_BUNDLE_VERSION = '1.0.0'

# Sample rules payload
SAMPLE_RULES = {
    'patterns': {
        'INJECTION_PATTERNS': ['ignore\\s+previous'],
        'INVISIBLE_CHARS': {'\u200b': 'ZERO WIDTH SPACE'},
        'RTL_OVERRIDE_CHARS': {},
        'HIDDEN_HTML_PATTERNS': [],
        'CONTENT_INJECTION_PATTERNS': [],
        'SUSPICIOUS_DOMAINS': ['evil.com'],
        'SUSPICIOUS_TLDS': ['.xyz'],
        'SENSITIVE_FILE_PATTERNS': ['.env'],
        'CREDENTIAL_READ_FUNCTIONS': ['readFile'],
    },
    'code_detector_patterns': {},
    'code_detector_keywords': {},
    'detector_patterns': {},
    'scorer_patterns': {},
    'risk_weights': {},
}


@pytest.fixture
def signing_keypair():
    """Generate a fresh Ed25519 keypair for testing."""
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    pub_bytes = public_key.public_bytes(encoding=Encoding.Raw, format=PublicFormat.Raw)
    return private_key, public_key, pub_bytes


@pytest.fixture
def master_key():
    """Generate a test master key."""
    return os.urandom(32)


def make_key_hash(licence_key):
    return hashlib.sha256(licence_key.encode('utf-8')).hexdigest()


def derive_server_component(master_key_bytes, key_hash, bundle_id):
    """Replicate the Worker's HMAC-SHA256 key component generation."""
    import hmac
    return hmac.new(master_key_bytes, (key_hash + bundle_id).encode('utf-8'), 'sha256').digest()


def encrypt_bundle(rules_payload, licence_key, server_component, bundle_id, signing_key):
    """Build a full encrypted bundle (same as compile-rules.py + server key component)."""
    # Canonical JSON
    plaintext = json.dumps(rules_payload, sort_keys=True, separators=(',', ':')).encode('utf-8')

    # Derive decryption key
    key_hash = make_key_hash(licence_key)
    pbkdf2_salt = hashlib.sha256(key_hash.encode('utf-8') + PBKDF2_SALT_DOMAIN).digest()
    client_km = PBKDF2HMAC(
        algorithm=hashes.SHA256(), length=KEY_LENGTH,
        salt=pbkdf2_salt, iterations=PBKDF2_ITERATIONS,
    ).derive(licence_key.encode('utf-8'))

    ikm = bytes(a ^ b for a, b in zip(client_km, server_component))

    decryption_key = HKDF(
        algorithm=hashes.SHA256(), length=KEY_LENGTH,
        salt=bundle_id.encode('utf-8'), info=HKDF_INFO,
    ).derive(ikm)

    # Encrypt
    iv = os.urandom(12)
    aesgcm = AESGCM(decryption_key)
    encrypted = aesgcm.encrypt(iv, plaintext, None)
    ciphertext = encrypted[:-16]
    auth_tag = encrypted[-16:]

    # Sign: ciphertext + iv
    signing_input = ciphertext + iv
    signature = signing_key.sign(signing_input)
    pub_bytes = signing_key.public_key().public_bytes(encoding=Encoding.Raw, format=PublicFormat.Raw)

    bundle = {
        'format': 'sentinel-bundle-v1',
        'version': TEST_BUNDLE_VERSION,
        'bundle_id': bundle_id,
        'encryption': {
            'algorithm': 'AES-256-GCM',
            'iv': base64.b64encode(iv).decode('ascii'),
            'tag': base64.b64encode(auth_tag).decode('ascii'),
            'ciphertext': base64.b64encode(ciphertext).decode('ascii'),
        },
        'signature': {
            'algorithm': 'Ed25519',
            'public_key': base64.b64encode(pub_bytes).decode('ascii'),
            'signature': base64.b64encode(signature).decode('ascii'),
        },
    }

    return bundle, decryption_key


def build_server_response(bundle, server_component, bundle_id):
    """Build the response that the Worker would send."""
    bundle_json = json.dumps(bundle)
    return {
        'bundle': base64.b64encode(bundle_json.encode('utf-8')).decode('ascii'),
        'key_component': base64.b64encode(server_component).decode('ascii'),
        'bundle_version': TEST_BUNDLE_VERSION,
        'bundle_id': bundle_id,
        'ttl_seconds': DEFAULT_TTL_SECONDS,
        'tier': 'individual',
    }


# ---------- Key Derivation Tests ----------

class TestKeyDerivation:
    """Golden-value tests for the key derivation chain."""

    def test_pbkdf2_produces_deterministic_output(self):
        salt = hashlib.sha256(
            make_key_hash(TEST_LICENCE_KEY).encode('utf-8') + PBKDF2_SALT_DOMAIN
        ).digest()
        km1 = PBKDF2HMAC(
            algorithm=hashes.SHA256(), length=KEY_LENGTH,
            salt=salt, iterations=PBKDF2_ITERATIONS,
        ).derive(TEST_LICENCE_KEY.encode('utf-8'))
        km2 = PBKDF2HMAC(
            algorithm=hashes.SHA256(), length=KEY_LENGTH,
            salt=salt, iterations=PBKDF2_ITERATIONS,
        ).derive(TEST_LICENCE_KEY.encode('utf-8'))
        assert km1 == km2

    def test_different_licence_keys_produce_different_km(self):
        def derive(key):
            salt = hashlib.sha256(
                make_key_hash(key).encode('utf-8') + PBKDF2_SALT_DOMAIN
            ).digest()
            return PBKDF2HMAC(
                algorithm=hashes.SHA256(), length=KEY_LENGTH,
                salt=salt, iterations=PBKDF2_ITERATIONS,
            ).derive(key.encode('utf-8'))
        assert derive('key-alpha') != derive('key-beta')

    def test_xor_combination(self):
        a = bytes(range(32))
        b = bytes([0xff] * 32)
        result = bytes(x ^ y for x, y in zip(a, b))
        assert len(result) == 32
        assert result != a
        assert result != b

    def test_full_key_derivation_roundtrip(self, signing_keypair, master_key):
        """Encrypt with derived key, decrypt with same derivation → roundtrip."""
        priv, _, pub_bytes = signing_keypair
        key_hash = make_key_hash(TEST_LICENCE_KEY)
        server_component = derive_server_component(master_key, key_hash, TEST_BUNDLE_ID)

        bundle, decryption_key = encrypt_bundle(
            SAMPLE_RULES, TEST_LICENCE_KEY, server_component, TEST_BUNDLE_ID, priv,
        )

        # Re-derive decryption key independently
        pbkdf2_salt = hashlib.sha256(key_hash.encode('utf-8') + PBKDF2_SALT_DOMAIN).digest()
        client_km = PBKDF2HMAC(
            algorithm=hashes.SHA256(), length=KEY_LENGTH,
            salt=pbkdf2_salt, iterations=PBKDF2_ITERATIONS,
        ).derive(TEST_LICENCE_KEY.encode('utf-8'))
        ikm = bytes(a ^ b for a, b in zip(client_km, server_component))
        rekey = HKDF(
            algorithm=hashes.SHA256(), length=KEY_LENGTH,
            salt=TEST_BUNDLE_ID.encode('utf-8'), info=HKDF_INFO,
        ).derive(ikm)

        assert rekey == decryption_key


# ---------- AES-256-GCM Tests ----------

class TestAESGCM:
    def test_encrypt_decrypt_roundtrip(self):
        key = os.urandom(32)
        iv = os.urandom(12)
        plaintext = b'Hello Sentinel rules!'
        aesgcm = AESGCM(key)
        ct = aesgcm.encrypt(iv, plaintext, None)
        pt = aesgcm.decrypt(iv, ct, None)
        assert pt == plaintext

    def test_tampered_ciphertext_fails(self):
        key = os.urandom(32)
        iv = os.urandom(12)
        plaintext = b'Sensitive rules data'
        aesgcm = AESGCM(key)
        ct = aesgcm.encrypt(iv, plaintext, None)
        tampered = bytearray(ct)
        tampered[0] ^= 0xff
        with pytest.raises(Exception):
            aesgcm.decrypt(iv, bytes(tampered), None)

    def test_wrong_key_fails(self):
        key1 = os.urandom(32)
        key2 = os.urandom(32)
        iv = os.urandom(12)
        ct = AESGCM(key1).encrypt(iv, b'data', None)
        with pytest.raises(Exception):
            AESGCM(key2).decrypt(iv, ct, None)


# ---------- Ed25519 Signature Tests ----------

class TestSignatureVerification:
    def test_valid_signature_passes(self, signing_keypair):
        priv, pub, _ = signing_keypair
        data = b'test data to sign'
        sig = priv.sign(data)
        pub.verify(sig, data)  # Should not raise

    def test_tampered_data_fails(self, signing_keypair):
        priv, pub, _ = signing_keypair
        data = b'original data'
        sig = priv.sign(data)
        with pytest.raises(Exception):
            pub.verify(sig, b'tampered data')

    def test_wrong_key_fails(self, signing_keypair):
        priv, _, _ = signing_keypair
        other_priv = Ed25519PrivateKey.generate()
        other_pub = other_priv.public_key()
        data = b'signed data'
        sig = priv.sign(data)
        with pytest.raises(Exception):
            other_pub.verify(sig, data)


# ---------- Cache TTL State Machine ----------

class TestCacheTTL:
    def test_empty_when_no_cache(self, tmp_path, monkeypatch):
        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))
        assert loader._check_cache() == 'EMPTY'

    def test_valid_when_fresh(self, tmp_path, monkeypatch):
        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))
        meta = {
            'fetched_at': int(time.time()),
            'ttl_seconds': DEFAULT_TTL_SECONDS,
            'bundle_id': TEST_BUNDLE_ID,
        }
        meta_path = os.path.join(str(tmp_path), f'cache-meta-{loader._key_hash_prefix()}.json')
        with open(meta_path, 'w') as f:
            json.dump(meta, f)
        assert loader._check_cache() == 'VALID'

    def test_refreshing_when_near_expiry(self, tmp_path, monkeypatch):
        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))
        # Set fetched_at to be within 24h of TTL expiry
        fetched_at = int(time.time()) - (DEFAULT_TTL_SECONDS - GRACE_WINDOW_SECONDS + 100)
        meta = {'fetched_at': fetched_at, 'ttl_seconds': DEFAULT_TTL_SECONDS}
        meta_path = os.path.join(str(tmp_path), f'cache-meta-{loader._key_hash_prefix()}.json')
        with open(meta_path, 'w') as f:
            json.dump(meta, f)
        assert loader._check_cache() == 'REFRESHING'

    def test_grace_when_recently_expired(self, tmp_path, monkeypatch):
        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))
        fetched_at = int(time.time()) - DEFAULT_TTL_SECONDS - 100
        meta = {'fetched_at': fetched_at, 'ttl_seconds': DEFAULT_TTL_SECONDS}
        meta_path = os.path.join(str(tmp_path), f'cache-meta-{loader._key_hash_prefix()}.json')
        with open(meta_path, 'w') as f:
            json.dump(meta, f)
        assert loader._check_cache() == 'GRACE'

    def test_expired_when_beyond_grace(self, tmp_path, monkeypatch):
        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))
        fetched_at = int(time.time()) - DEFAULT_TTL_SECONDS - GRACE_WINDOW_SECONDS - 100
        meta = {'fetched_at': fetched_at, 'ttl_seconds': DEFAULT_TTL_SECONDS}
        meta_path = os.path.join(str(tmp_path), f'cache-meta-{loader._key_hash_prefix()}.json')
        with open(meta_path, 'w') as f:
            json.dump(meta, f)
        assert loader._check_cache() == 'EXPIRED'

    def test_ttl_override_env(self, tmp_path, monkeypatch):
        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))
        monkeypatch.setenv('SENTINEL_RULES_TTL_DAYS', '1')
        # Fetched 2 days ago, default TTL would say VALID but 1-day override says EXPIRED
        fetched_at = int(time.time()) - 2 * 86400 - 100
        meta = {'fetched_at': fetched_at, 'ttl_seconds': DEFAULT_TTL_SECONDS}
        meta_path = os.path.join(str(tmp_path), f'cache-meta-{loader._key_hash_prefix()}.json')
        with open(meta_path, 'w') as f:
            json.dump(meta, f)
        result = loader._check_cache()
        assert result in ('EXPIRED', 'GRACE')


# ---------- EncryptedRulesLoader Integration ----------

class TestEncryptedRulesLoader:
    def test_no_licence_key_returns_none_with_warning(self, monkeypatch):
        monkeypatch.delenv('SENTINEL_LICENCE_KEY', raising=False)
        loader = EncryptedRulesLoader(licence_key=None)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            result = loader.get_rules()
            assert result is None
            assert loader.degraded is True
            assert any(issubclass(x.category, SentinelDegradedWarning) for x in w)

    def test_thread_safe_singleton(self):
        loader = EncryptedRulesLoader(licence_key=None)
        results = []
        def get():
            results.append(loader.get_rules())
        import threading
        threads = [threading.Thread(target=get) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        # All should return None (no licence key)
        assert all(r is None for r in results)

    def test_process_server_response_decrypts(self, signing_keypair, master_key, tmp_path, monkeypatch):
        priv, pub, pub_bytes = signing_keypair
        pub_b64 = base64.b64encode(pub_bytes).decode('ascii')
        monkeypatch.setattr(
            'sentinel_security.rules_loader.SIGNING_PUBLIC_KEY_B64', pub_b64,
        )

        key_hash = make_key_hash(TEST_LICENCE_KEY)
        server_component = derive_server_component(master_key, key_hash, TEST_BUNDLE_ID)
        bundle, _ = encrypt_bundle(SAMPLE_RULES, TEST_LICENCE_KEY, server_component, TEST_BUNDLE_ID, priv)
        response = build_server_response(bundle, server_component, TEST_BUNDLE_ID)

        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))

        rules = loader._process_server_response(response)
        assert rules is not None
        assert rules['patterns']['INJECTION_PATTERNS'] == SAMPLE_RULES['patterns']['INJECTION_PATTERNS']
        assert rules['patterns']['SUSPICIOUS_DOMAINS'] == SAMPLE_RULES['patterns']['SUSPICIOUS_DOMAINS']

    def test_tampered_signature_raises(self, signing_keypair, master_key, tmp_path, monkeypatch):
        priv, pub, pub_bytes = signing_keypair
        pub_b64 = base64.b64encode(pub_bytes).decode('ascii')
        monkeypatch.setattr(
            'sentinel_security.rules_loader.SIGNING_PUBLIC_KEY_B64', pub_b64,
        )

        key_hash = make_key_hash(TEST_LICENCE_KEY)
        server_component = derive_server_component(master_key, key_hash, TEST_BUNDLE_ID)
        bundle, _ = encrypt_bundle(SAMPLE_RULES, TEST_LICENCE_KEY, server_component, TEST_BUNDLE_ID, priv)

        # Tamper the signature
        sig = base64.b64decode(bundle['signature']['signature'])
        tampered_sig = bytes([b ^ 0xff for b in sig])
        bundle['signature']['signature'] = base64.b64encode(tampered_sig).decode('ascii')

        response = build_server_response(bundle, server_component, TEST_BUNDLE_ID)
        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))

        with pytest.raises(SentinelBundleTamperError):
            loader._process_server_response(response)

    def test_cache_write_and_read_roundtrip(self, signing_keypair, master_key, tmp_path, monkeypatch):
        priv, pub, pub_bytes = signing_keypair
        pub_b64 = base64.b64encode(pub_bytes).decode('ascii')
        monkeypatch.setattr(
            'sentinel_security.rules_loader.SIGNING_PUBLIC_KEY_B64', pub_b64,
        )

        key_hash = make_key_hash(TEST_LICENCE_KEY)
        server_component = derive_server_component(master_key, key_hash, TEST_BUNDLE_ID)
        bundle, _ = encrypt_bundle(SAMPLE_RULES, TEST_LICENCE_KEY, server_component, TEST_BUNDLE_ID, priv)
        response = build_server_response(bundle, server_component, TEST_BUNDLE_ID)

        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))

        # Write via process_server_response
        rules = loader._process_server_response(response)
        assert rules is not None

        # Read back from cache
        cached_rules = loader._decrypt_cached_bundle()
        assert cached_rules is not None
        assert cached_rules == rules

    def test_corrupted_cache_returns_none_and_clears(self, tmp_path, monkeypatch):
        loader = EncryptedRulesLoader(licence_key=TEST_LICENCE_KEY)
        monkeypatch.setattr(loader, '_cache_dir', lambda: str(tmp_path))

        # Write garbage to cache files
        prefix = loader._key_hash_prefix()
        os.makedirs(str(tmp_path), exist_ok=True)
        with open(os.path.join(str(tmp_path), f'bundle-{prefix}.enc'), 'wb') as f:
            f.write(b'garbage data')
        with open(os.path.join(str(tmp_path), f'key-material-{prefix}.enc'), 'wb') as f:
            f.write(b'garbage key material')
        with open(os.path.join(str(tmp_path), f'cache-meta-{prefix}.json'), 'w') as f:
            json.dump({'fetched_at': int(time.time()), 'ttl_seconds': DEFAULT_TTL_SECONDS, 'bundle_id': 'x'}, f)

        result = loader._decrypt_cached_bundle()
        assert result is None


# ---------- Feature Flag ----------

class TestFeatureFlag:
    def test_off_by_default(self, monkeypatch):
        monkeypatch.delenv('SENTINEL_USE_ENCRYPTED_RULES', raising=False)
        assert _use_encrypted_rules() is False

    def test_on_when_true(self, monkeypatch):
        monkeypatch.setenv('SENTINEL_USE_ENCRYPTED_RULES', 'true')
        assert _use_encrypted_rules() is True

    def test_on_when_1(self, monkeypatch):
        monkeypatch.setenv('SENTINEL_USE_ENCRYPTED_RULES', '1')
        assert _use_encrypted_rules() is True

    def test_on_when_yes(self, monkeypatch):
        monkeypatch.setenv('SENTINEL_USE_ENCRYPTED_RULES', 'yes')
        assert _use_encrypted_rules() is True

    def test_off_when_false(self, monkeypatch):
        monkeypatch.setenv('SENTINEL_USE_ENCRYPTED_RULES', 'false')
        assert _use_encrypted_rules() is False


# ---------- Plaintext Fallback ----------

class TestPlaintextLoader:
    """Ensure the existing Phase 1 plaintext loader still works."""

    def test_load_rules_from_default_path(self):
        load_rules()
        data = get_rules_data()
        assert 'patterns' in data
        assert 'INJECTION_PATTERNS' in data['patterns']

    def test_get_patterns(self):
        p = get_patterns()
        assert 'INJECTION_PATTERNS' in p
        assert isinstance(p['INJECTION_PATTERNS'], list)
        assert len(p['INJECTION_PATTERNS']) > 0

    def test_load_rules_from_dict(self):
        test_data = {'patterns': {'INJECTION_PATTERNS': ['test']}}
        load_rules(data=test_data)
        assert get_patterns()['INJECTION_PATTERNS'] == ['test']
        # Reset to defaults
        load_rules()
