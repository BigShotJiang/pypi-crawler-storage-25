# Sentinel Middleware Guide

Runtime security middleware for Python AI agent frameworks. Sentinel scans every LLM call, tool output, and agent response for prompt injection attacks -- automatically, with a single line of code.

## Table of Contents

- [Installation](#installation)
- [How the DetectionEngine Works](#how-the-detectionengine-works)
- [Blocking Behaviour](#blocking-behaviour)
- [LangChain Integration](#langchain-integration)
- [OpenAI SDK Integration](#openai-sdk-integration)
- [Anthropic SDK Integration](#anthropic-sdk-integration)
- [Global Configuration](#global-configuration)
- [Configuration Reference](#configuration-reference)
- [Event Schema](#event-schema)
- [Licence Activation](#licence-activation)
- [Troubleshooting](#troubleshooting)
- [Performance](#performance)
- [FAQ](#faq)

---

## Installation

Core package (includes `sanitise_content`, CLI, file scanners):

```bash
pip install sentinel-security
```

With LangChain support:

```bash
pip install sentinel-security[langchain]
```

With all current framework extras:

```bash
pip install sentinel-security[frameworks]
```

The OpenAI and Anthropic SDK wrappers have **no extra dependencies** -- if you already have `openai` or `anthropic` installed, `sentinel_wrap()` works immediately.

### Python Version

Requires Python 3.9+.

---

## How the DetectionEngine Works

All framework integrations share a single `DetectionEngine` that wraps Sentinel's existing `sanitise_content()` function. The engine does **not** duplicate detection logic -- it adds lifecycle awareness, policy enforcement, and structured audit logging on top of the core scanner.

### Scan Flow

1. **Input arrives** (LLM messages, tool output, agent response)
2. **DetectionEngine** calls `sanitise_content()` to scan the text
3. **Risk score** (0-10) and **threats** are returned
4. **Policy check**: if the score exceeds `risk_threshold`, the configured policy fires:
   - `log` -- allow the content, log at DEBUG level
   - `warn` -- allow the content, log at WARNING level
   - `block` -- raise `SentinelBlockedError` (or replace content with a blocked message)
5. **ScanEvent** is emitted to Python's `logging` module and any custom `event_handler`

### What Gets Scanned

The engine scans for everything `sanitise_content()` detects:

- Prompt injection patterns (30+ variants)
- System prompt overrides
- Action hijacking instructions
- Hidden content (HTML, CSS, invisible elements)
- Unicode attacks (zero-width chars, RTL overrides, homoglyphs)
- Encoding tricks (base64-encoded instructions)

### Scan Methods

```python
from sentinel_security.middleware import DetectionEngine

engine = DetectionEngine({"policy": "warn", "risk_threshold": 5})

# Scan LLM input messages
result = engine.scan_input([
    {"role": "user", "content": "Tell me about Python"},
])

# Scan LLM output or tool results
result = engine.scan_output(response_text, source="llm")

# Scan a batch of documents (RAG pipelines)
results = engine.scan_documents(documents)
```

Each method returns a `ScanResult`:

```python
result.risk_level      # "CLEAN" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
result.risk_score      # 0-10
result.threats         # list of threat dicts
result.clean_text      # sanitised content
result.action_taken    # "allow" | "flag" | "block"
result.scan_duration_ms
result.scan_id         # UUID for correlation
```

---

## Blocking Behaviour

When `policy="block"` and the risk score exceeds `risk_threshold`, each adapter handles blocking differently. This is intentional — each framework has different hook contracts, and the blocking mechanism follows the framework's design patterns.

### Blocking Behaviour by Adapter

| Adapter | Block Behaviour | Reason |
|---------|----------------|--------|
| **SentinelMiddleware** (LangChain) | Raises `SentinelBlockedError` | AgentMiddleware API supports exceptions |
| **SentinelCallbackHandler** (LangChain) | Logs at ERROR level, no block | Callbacks are observation-only by design |
| **sentinel_wrap** — input scan (OpenAI/Anthropic) | Raises `SentinelBlockedError` | Pre-request, can halt before API call |
| **sentinel_wrap** — output scan (OpenAI/Anthropic) | Replaces content with blocked message | Can't un-send already-received response |
| **sentinel_wrap** — stream scan (OpenAI/Anthropic) | Yields single blocked-message chunk | Can't un-send already-streamed chunks |
| **SentinelCrewAI** (CrewAI) | Raises `SentinelBlockedError` | Callback can halt agent execution |
| **SentinelGuard** (Haystack) | Routes to `blocked` output port | Pipeline component pattern, no exceptions |
| **SentinelAutoGen** (AutoGen/AG2) | Returns replacement message | Hook API requires returning a value |

### Handling Blocks in Your Code

#### LangChain (SentinelMiddleware)

```python
from sentinel_security.middleware import SentinelMiddleware, SentinelBlockedError

agent = create_agent(
    model=ChatOpenAI(),
    tools=[...],
    middleware=[SentinelMiddleware(policy="block")],
)

try:
    result = agent.invoke({"messages": [("user", user_input)]})
except SentinelBlockedError as e:
    print(f"Blocked: {e.result.risk_level} (score {e.result.risk_score})")
```

#### OpenAI / Anthropic SDK

```python
from sentinel_security.middleware import sentinel_wrap, SentinelBlockedError

client = sentinel_wrap(OpenAI(), policy="block")

try:
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": user_input}],
    )
except SentinelBlockedError as e:
    print(f"Input blocked: {e.result.risk_level}")
```

For output blocks (non-streaming), check the response content:

```python
if response.choices[0].message.content == "[SENTINEL BLOCKED: content blocked due to security risk]":
    print("Output was blocked by Sentinel")
```

#### CrewAI

```python
from sentinel_security.middleware import SentinelBlockedError
from sentinel_security.middleware.crewai import SentinelCrewAI

crew = SentinelCrewAI.protect(crew, policy="block")

try:
    result = crew.kickoff()
except SentinelBlockedError as e:
    print(f"Agent blocked: {e.result.risk_level}")
```

#### Haystack

```python
result = pipeline.run({"sentinel": {"documents": docs}})

blocked_docs = result["sentinel"]["blocked"]
passed_docs = result["sentinel"]["documents"]

for doc in blocked_docs:
    print(f"Blocked: {doc.meta['sentinel_risk_score']}")
```

#### AutoGen/AG2

```python
from sentinel_security.middleware.autogen import SentinelAutoGen

agent = SentinelAutoGen.protect(agent, policy="block")
# Blocked messages are automatically replaced with:
# "This message was blocked by Sentinel security scanning."
```

---

## LangChain Integration

Sentinel provides two adapters for LangChain, covering different API surfaces.

### SentinelMiddleware (LangChain v1+ AgentMiddleware)

For agents created with `create_agent()`. Scans messages before the LLM call (`before_model`) and the response after (`after_model`). Supports blocking.

```python
from langchain_openai import ChatOpenAI
from sentinel_security.middleware import SentinelMiddleware

agent = create_agent(
    model=ChatOpenAI(),
    tools=[...],
    middleware=[SentinelMiddleware()],
)

# With custom policy:
agent = create_agent(
    model=ChatOpenAI(),
    tools=[...],
    middleware=[SentinelMiddleware(
        policy="block",
        risk_threshold=7,
    )],
)
```

**Requires**: `langchain >= 1.0.0`
**Install**: `pip install sentinel-security[langchain]`

#### Hook Points

| Hook | What It Scans | Can Block? |
|------|--------------|------------|
| `before_model` | All messages in the agent state before they reach the LLM | Yes |
| `after_model` | The last message (LLM response) in the agent state | Yes |

When `policy="block"` and the risk score exceeds the threshold, `SentinelBlockedError` is raised.

### SentinelCallbackHandler (LangChain Legacy / LangGraph)

For `create_react_agent`, raw `BaseChatModel`, or any component accepting LangChain callbacks. Observation-only -- logs and emits events but **cannot block** requests.

```python
from sentinel_security.middleware import SentinelCallbackHandler

handler = SentinelCallbackHandler(policy="warn")

# With LangGraph create_react_agent:
agent.invoke(
    {"messages": [("user", "Hello")]},
    config={"callbacks": [handler]},
)

# With a raw chat model:
from langchain_openai import ChatOpenAI

model = ChatOpenAI(callbacks=[SentinelCallbackHandler()])
response = model.invoke("Tell me about Python")
```

**Requires**: `langchain-core >= 0.3.0`
**Install**: `pip install sentinel-security[langchain]`

#### Hook Points

| Hook | What It Scans |
|------|--------------|
| `on_llm_start` | String prompts sent to non-chat LLMs |
| `on_chat_model_start` | Chat messages sent to the model |
| `on_llm_end` | LLM response generations |
| `on_tool_end` | Tool output strings |

The `last_result` attribute holds the most recent `ScanResult`:

```python
handler = SentinelCallbackHandler()
model.invoke("some input", config={"callbacks": [handler]})
print(handler.last_result.risk_level)
```

---

## OpenAI SDK Integration

`sentinel_wrap()` patches `client.chat.completions.create` to scan inputs before sending and outputs after receiving.

### Sync Client

```python
from openai import OpenAI
from sentinel_security.middleware import sentinel_wrap

client = sentinel_wrap(OpenAI())

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": user_input}],
)
```

### Async Client

```python
from openai import AsyncOpenAI
from sentinel_security.middleware import sentinel_wrap

client = sentinel_wrap(AsyncOpenAI())

response = await client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": user_input}],
)
```

### Streaming

Streaming is fully supported. Sentinel buffers all chunks, scans the complete response, then yields chunks to your code. If the response is blocked, a single chunk with `[SENTINEL BLOCKED: content blocked due to security risk]` is yielded instead.

```python
client = sentinel_wrap(OpenAI(), policy="block", risk_threshold=7)

stream = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": user_input}],
    stream=True,
)
for chunk in stream:
    print(chunk.choices[0].delta.content or "", end="")
```

### Hook Points

| Phase | What It Scans | Can Block? |
|-------|--------------|------------|
| Pre-request | Input messages before the API call | Yes (raises `SentinelBlockedError`) |
| Post-response | Response content after the API call | Yes (replaces content with blocked message) |
| Post-stream | Buffered stream content after completion | Yes (yields blocked message chunk) |

### Idempotent Wrapping

Calling `sentinel_wrap()` multiple times on the same client is safe -- it detects an already-wrapped client and returns it unchanged.

---

## Anthropic SDK Integration

Same API as OpenAI -- `sentinel_wrap()` patches `client.messages.create`.

### Sync Client

```python
from anthropic import Anthropic
from sentinel_security.middleware import sentinel_wrap

client = sentinel_wrap(Anthropic())

response = client.messages.create(
    model="claude-sonnet-4-5-20250929",
    max_tokens=1024,
    messages=[{"role": "user", "content": user_input}],
)
```

### Async Client

```python
from anthropic import AsyncAnthropic
from sentinel_security.middleware import sentinel_wrap

client = sentinel_wrap(AsyncAnthropic())

response = await client.messages.create(
    model="claude-sonnet-4-5-20250929",
    max_tokens=1024,
    messages=[{"role": "user", "content": user_input}],
)
```

### Streaming

Anthropic streaming works identically to OpenAI streaming -- events are buffered, scanned, then yielded.

### Supported Client Types

`sentinel_wrap()` auto-detects and supports:

| Client Type | Patches |
|-------------|---------|
| `openai.OpenAI` | `client.chat.completions.create` |
| `openai.AsyncOpenAI` | `client.chat.completions.create` (async) |
| `anthropic.Anthropic` | `client.messages.create` |
| `anthropic.AsyncAnthropic` | `client.messages.create` (async) |

Passing an unsupported client type raises `TypeError` with a clear message.

---

## Global Configuration

### configure()

Set defaults that apply to all middleware instances:

```python
import sentinel_security

sentinel_security.configure(
    policy="warn",                     # "log" | "warn" | "block"
    risk_threshold=5,                  # 0-10, score above which policy fires
    log_level="WARNING",               # Python logging level for sentinel_security
    event_handler=my_handler,          # callable receiving ScanEvent instances
    licence_key="sk-sent-...",         # licence key for paid features
    middleware_enabled=True,           # set False to globally disable middleware
    log_content=False,                 # WARNING: logs scanned content if True
    telemetry=False,                   # opt-in anonymous telemetry
)
```

`configure()` returns the resolved configuration dict.

### Environment Variables

| Variable | Config Key | Type | Default |
|----------|-----------|------|---------|
| `SENTINEL_POLICY` | `policy` | `str` | `"warn"` |
| `SENTINEL_RISK_THRESHOLD` | `risk_threshold` | `int` | `5` |
| `SENTINEL_LOG_CONTENT` | `log_content` | `bool` | `False` |
| `SENTINEL_LICENCE_KEY` | `licence_key` | `str` | `None` |
| `SENTINEL_TELEMETRY` | `telemetry` | `bool` | `False` |

### Precedence

Configuration is resolved in this order (highest priority first):

1. **Per-adapter kwargs** -- e.g., `SentinelMiddleware(policy="block")`
2. **`sentinel_security.configure()` call**
3. **Environment variables**
4. **Package defaults**

---

## Configuration Reference

### policy

Controls what happens when a threat is detected above `risk_threshold`.

| Value | Behaviour | Log Level |
|-------|-----------|-----------|
| `"log"` | Allow content through. Log scan result. | DEBUG |
| `"warn"` | Allow content through. Flag with warning. | WARNING |
| `"block"` | Reject content. Raise error or replace with blocked message. | ERROR |

Default: `"warn"`

### risk_threshold

Integer from 0 to 10. The policy action only fires when `risk_score >= risk_threshold`.

Default: `5`

### event_handler

An optional callable that receives a `ScanEvent` on every scan. Called **in addition to** the standard Python logging output.

```python
def my_handler(event):
    # event is a ScanEvent dataclass
    print(event.scan_id, event.risk_score, event.action)

sentinel_security.configure(event_handler=my_handler)
```

If the handler raises an exception, it is caught and logged -- it will not break the middleware.

### log_content

When `True`, the actual scanned text is included in `ScanEvent.content`. **Disabled by default** for SOC2 compliance. A warning is logged when this is enabled.

### middleware_enabled

Set to `False` to globally disable all middleware scanning without removing `SentinelMiddleware` or `sentinel_wrap()` from your code. Useful for emergency disable in production.

### scan_id_prefix

Optional string prefix for scan IDs. Useful for correlating scans across services.

```python
engine = DetectionEngine({"scan_id_prefix": "prod-svc-a-"})
# Generates scan IDs like: prod-svc-a-550e8400-e29b-41d4-a716-446655440000
```

---

## Event Schema

Every scan emits a `ScanEvent` dataclass. These are logged via Python's `logging` module and optionally dispatched to a custom `event_handler`.

### ScanEvent Fields

| Field | Type | Description |
|-------|------|-------------|
| `scan_id` | `str` | Unique UUID for this scan |
| `timestamp` | `str` | ISO 8601 UTC timestamp (e.g., `"2026-03-19T10:30:00Z"`) |
| `event_type` | `str` | `"scan_complete"`, `"threat_detected"`, or `"blocked"` |
| `framework` | `str` | `"langchain"`, `"openai"`, `"anthropic"`, etc. |
| `source` | `str` | Hook point (e.g., `"langchain-input"`, `"openai-response"`) |
| `risk_score` | `int` | 0-10 risk score from the scanner |
| `risk_level` | `str` | `"CLEAN"`, `"LOW"`, `"MEDIUM"`, `"HIGH"`, `"CRITICAL"` |
| `threats` | `list` | List of `{"type": str, "name": str}` dicts (content-free) |
| `action` | `str` | `"allow"`, `"flag"`, or `"block"` |
| `scan_duration_ms` | `float` | Time taken for the scan in milliseconds |
| `content_length` | `int` | Length of the scanned text in characters |
| `policy_applied` | `str` | The policy that was in effect |
| `risk_threshold_applied` | `int` | The threshold that was in effect |
| `engine_version` | `int` | DetectionEngine API version (currently `1`) |
| `content` | `str \| None` | Scanned text -- **only present if `log_content=True`** |

### SOC2 Note

By default, `ScanEvent` does **not** contain the scanned content or raw threat matches. The `threats` list includes only the threat type and mechanism name. Set `log_content=True` to include content (not recommended for production/SOC2 environments).

### Log Levels

| Scan Outcome | Log Level |
|-------------|-----------|
| Clean / allowed | DEBUG |
| Flagged (policy=warn) | WARNING |
| Blocked (policy=block) | ERROR |

### Serialisation

```python
event_dict = event.to_dict()  # returns a plain dict suitable for JSON/SIEM export
```

---

## Licence Activation

Python-only users (not using the OpenClaw plugin) can activate their licence via:

```python
import sentinel_security

sentinel_security.configure(licence_key="sk-sent-...")
```

Or via environment variable:

```bash
export SENTINEL_LICENCE_KEY="sk-sent-..."
```

### How Validation Works

1. The key is hashed with SHA-256 -- the plaintext is **never** sent over the network
2. The hash is sent via HTTPS POST to the Sentinel licence endpoint
3. Valid results are cached for 24 hours; invalid results for 5 minutes
4. Only HTTPS URLs are accepted -- HTTP is rejected

### Programmatic Validation

```python
from sentinel_security import validate_licence

result = validate_licence()  # reads key from configure() or env var
# or explicitly:
result = validate_licence("sk-sent-your-key-here")

print(result.valid)       # True/False
print(result.scope)       # "individual" | "team" | "org"
print(result.expires_at)  # ISO 8601 or None
print(result.reason)      # None if valid, else "no_key" | "offline" | "invalid" | ...
```

### Offline / Air-Gapped Environments

If the licence endpoint is unreachable, `validate_licence()` returns `LicenceResult(valid=False, reason="offline")`. All core detection and middleware features continue to work. Offline results are **not** cached so the next call will retry.

---

## Troubleshooting

### ImportError: SentinelMiddleware requires langchain >= 1.0.0

You're importing `SentinelMiddleware` but don't have LangChain installed, or have an older version.

```bash
pip install sentinel-security[langchain]
```

### ImportError: SentinelCallbackHandler requires langchain-core >= 0.3.0

```bash
pip install sentinel-security[langchain]
```

### TypeError: Unsupported client type

`sentinel_wrap()` was called with a client that isn't `openai.OpenAI`, `openai.AsyncOpenAI`, `anthropic.Anthropic`, or `anthropic.AsyncAnthropic`. Check that you're passing the client instance, not the class.

```python
# Wrong:
sentinel_wrap(OpenAI)

# Right:
sentinel_wrap(OpenAI())
```

### SentinelBlockedError raised unexpectedly

Your `policy` is set to `"block"` and the risk score exceeded `risk_threshold`. To investigate:

1. Set `policy="warn"` temporarily to let content through while logging threats
2. Check the `ScanResult.threats` list for what was detected
3. Raise `risk_threshold` if the threshold is too sensitive for your use case

### Events not appearing in logs

Sentinel logs to the `sentinel_security.audit` logger. Make sure your Python logging is configured:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

Or set the level via configure:

```python
sentinel_security.configure(log_level="DEBUG")
```

### Middleware seems to have no effect

Check that `middleware_enabled` is not set to `False`:

```python
sentinel_security.configure(middleware_enabled=True)
```

---

## Performance

The DetectionEngine wraps `sanitise_content()` which is a rule-based scanner running entirely in-process. There are no network calls during scanning.

### Expected Latency

| Input Size | Expected p99 |
|-----------|-------------|
| Small message (500 chars) | < 2ms |
| Medium message (5KB) | < 5ms |
| Large tool output (50KB) | < 20ms |
| Batch scan (100 docs, 1KB each) | < 200ms |

### Streaming Overhead

For streaming responses (`stream=True`), Sentinel buffers all chunks before scanning. This means the complete response must be received before chunks are yielded to your code. For latency-sensitive streaming use cases, consider using `policy="log"` to scan without blocking.

---

## FAQ

**Does Sentinel make network calls during scanning?**
No. All detection runs locally in-process using the rule-based `sanitise_content()` engine. The only network call is optional licence validation (cached for 24 hours).

**Can I use SentinelMiddleware and SentinelCallbackHandler together?**
You can, but it's redundant. Use `SentinelMiddleware` if your LangChain setup supports it (v1+ `create_agent()`). Use `SentinelCallbackHandler` for legacy chains, LangGraph, or raw model calls.

**What happens if I wrap a client that's already wrapped?**
Nothing. `sentinel_wrap()` is idempotent -- it checks for a `_sentinel_wrapped` flag and returns the client unchanged.

**Does sentinel_wrap affect other methods on the client?**
No. Only `client.chat.completions.create` (OpenAI) or `client.messages.create` (Anthropic) is patched. All other client methods work unchanged.

**Can I disable middleware in production without removing code?**
Yes. Set `SENTINEL_POLICY=log` to keep scanning without blocking, or set `middleware_enabled=False` via `configure()` to disable all scanning entirely.

**Is there a performance impact on streaming?**
Yes -- Sentinel buffers the complete stream before yielding chunks. For most use cases (sub-second LLM responses), this is imperceptible. For very long streaming responses, consider using `policy="log"`.

**What Python versions are supported?**
Python 3.9 through 3.13.
