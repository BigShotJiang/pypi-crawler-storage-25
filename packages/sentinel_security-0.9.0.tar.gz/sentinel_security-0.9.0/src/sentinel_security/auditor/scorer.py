"""
Score calculator for prompt audit results.

Port of the JavaScript scorer from prompt-auditor/scorer.js.
"""

import json
import math
from pathlib import Path


def _load_rules():
    """Load rules from rules.json file."""
    rules_path = Path(__file__).parent / "rules.json"
    with open(rules_path, 'r', encoding='utf-8') as f:
        return json.load(f)


RULES = _load_rules()

# Build a lookup of rule points by id
POINTS_BY_RULE = {rule['id']: rule['points'] for rule in RULES}

# Severity category groupings
SEVERITY_CATEGORIES = {
    'critical': {'label': 'critical', 'max_points': 0},
    'high': {'label': 'high', 'max_points': 0},
    'medium': {'label': 'medium', 'max_points': 0},
    'low': {'label': 'low', 'max_points': 0},
}

for rule in RULES:
    SEVERITY_CATEGORIES[rule['severity']]['max_points'] += rule['points']


def _get_grade(score: int) -> str:
    """Convert numeric score to letter grade."""
    if score >= 90:
        return 'A'
    if score >= 75:
        return 'B'
    if score >= 60:
        return 'C'
    if score >= 40:
        return 'D'
    return 'F'


def compute_score(scan_results):
    """
    Compute a score and grade from scan results.

    PASS = full points, PARTIAL = half points (rounded down), FAIL = 0.
    Grades: A (90-100), B (75-89), C (60-74), D (40-59), F (<40).

    Args:
        scan_results: Results from scanner.scan().

    Returns:
        Score report dictionary.
    """
    breakdown = {
        'critical': 0,
        'high': 0,
        'medium': 0,
        'low': 0,
    }

    total_score = 0

    for result in scan_results:
        max_points = POINTS_BY_RULE.get(result['rule_id'])
        if max_points is None:
            continue

        earned = 0
        if result['status'] == 'pass':
            earned = max_points
        elif result['status'] == 'partial':
            earned = math.floor(max_points / 2)
        # fail = 0

        total_score += earned
        breakdown[result['severity']] += earned

    grade = _get_grade(total_score)

    return {
        'score': total_score,
        'grade': grade,
        'max_score': 100,
        'breakdown': {
            'critical': f"{breakdown['critical']}/{SEVERITY_CATEGORIES['critical']['max_points']}",
            'high': f"{breakdown['high']}/{SEVERITY_CATEGORIES['high']['max_points']}",
            'medium': f"{breakdown['medium']}/{SEVERITY_CATEGORIES['medium']['max_points']}",
            'low': f"{breakdown['low']}/{SEVERITY_CATEGORIES['low']['max_points']}",
        },
    }
