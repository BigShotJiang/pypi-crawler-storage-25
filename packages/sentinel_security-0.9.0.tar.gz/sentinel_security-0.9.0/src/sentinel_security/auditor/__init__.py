"""
Prompt auditor module for scanning, scoring, and patching system prompts.

Port of the JavaScript prompt-auditor to Python.
"""

from .scanner import scan
from .scorer import compute_score
from .patcher import generate_patches


def audit(prompt_text: str) -> dict:
    """
    Complete audit of a system prompt.

    Args:
        prompt_text: The system prompt to audit.

    Returns:
        Complete audit report with scan results, score, and patches.
    """
    scan_results = scan(prompt_text)
    score = compute_score(scan_results)
    patches = generate_patches(scan_results)
    
    import datetime
    # Use timezone-aware UTC datetime
    utc_now = datetime.datetime.now(datetime.timezone.utc)
    return {
        'scan_results': scan_results,
        'score': score,
        'patches': patches,
        'audited_at': utc_now.isoformat().replace('+00:00', 'Z')
    }
