"""
CLI entry point for sentinel-audit.

Usage:
    sentinel-audit <file>              # audit a system prompt file
    sentinel-audit --stdin             # read prompt from stdin
    sentinel-audit <file> --output json  # output as JSON
    sentinel-audit <file> --output text  # human-readable output (default)
"""

import argparse
import json
import sys


def _print_text_report(result):
    """Print a human-readable audit report."""
    score = result['score']
    print(f"\n  Sentinel Prompt Audit")
    print(f"  {'=' * 40}")
    print(f"  Score: {score['score']}/100 (Grade: {score['grade']})")
    print(f"  Breakdown: {json.dumps(score['breakdown'])}")
    print()

    for r in result['scan_results']:
        icon = '  PASS' if r['status'] == 'pass' else ('  PART' if r['status'] == 'partial' else '  FAIL')
        print(f"  [{icon}] {r['severity']:8s} | {r['name']}")
        if r['matched_patterns']:
            print(f"         patterns: {len(r['matched_patterns'])} matched")
        if r['matched_keywords']:
            print(f"         keywords: {', '.join(r['matched_keywords'])}")
    print()

    if result['patches']:
        print(f"  Suggested fixes ({len(result['patches'])} rules need attention):")
        print(f"  {'-' * 40}")
        for p in result['patches']:
            print(f"\n  [{p['severity']:8s}] {p['rule_id']}")
            print(f"  Hint: {p['insertion_hint']}")
            print(f"  Add:")
            for line in p['suggested_text'].split('\n'):
                print(f"    {line}")
        print()


def main():
    parser = argparse.ArgumentParser(
        prog='sentinel-audit',
        description='Audit a system prompt for security hardening',
    )
    parser.add_argument(
        'file',
        nargs='?',
        help='File containing the system prompt to audit',
    )
    parser.add_argument(
        '--stdin',
        action='store_true',
        help='Read prompt from stdin',
    )
    parser.add_argument(
        '--output',
        choices=['json', 'text'],
        default='text',
        help='Output format (default: text)',
    )
    args = parser.parse_args()

    if args.stdin:
        prompt_text = sys.stdin.read()
    elif args.file:
        import os
        if not os.path.exists(args.file):
            print(f"Error: file not found: {args.file}", file=sys.stderr)
            sys.exit(2)
        with open(args.file, 'r', encoding='utf-8') as f:
            prompt_text = f.read()
    else:
        parser.error('Provide a file path or use --stdin')

    if not prompt_text.strip():
        print("Error: empty prompt", file=sys.stderr)
        sys.exit(2)

    from .auditor import audit
    result = audit(prompt_text)

    if args.output == 'json':
        json.dump(result, sys.stdout, indent=2, ensure_ascii=False, default=str)
        print()
    else:
        _print_text_report(result)

    # Exit code: 0 if grade A/B, 1 if C/D/F
    grade = result['score']['grade']
    sys.exit(0 if grade in ('A', 'B') else 1)


if __name__ == '__main__':
    main()
