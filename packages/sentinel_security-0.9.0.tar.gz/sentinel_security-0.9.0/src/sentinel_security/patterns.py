"""Detection patterns for prompt injection and content hiding.

Phase 1: Loads from rule_bundle_data.json via rules_loader.
All public names preserved for backwards compatibility.
"""

import re
import unicodedata
from .rules_loader import get_patterns as _get_patterns

# Load patterns eagerly at import time and cache as module globals.
# This preserves the existing public API: callers can do
#   from sentinel_security.patterns import INJECTION_PATTERNS
# and get a plain list/dict, just as before.

_p = _get_patterns()

INJECTION_PATTERNS = _p['INJECTION_PATTERNS']
INVISIBLE_CHARS = _p['INVISIBLE_CHARS']
RTL_OVERRIDE_CHARS = _p['RTL_OVERRIDE_CHARS']
HIDDEN_HTML_PATTERNS = [tuple(item) for item in _p['HIDDEN_HTML_PATTERNS']]
CONTENT_INJECTION_PATTERNS = _p['CONTENT_INJECTION_PATTERNS']
SUSPICIOUS_DOMAINS = _p['SUSPICIOUS_DOMAINS']
SUSPICIOUS_TLDS = _p['SUSPICIOUS_TLDS']
SENSITIVE_FILE_PATTERNS = _p['SENSITIVE_FILE_PATTERNS']
CREDENTIAL_READ_FUNCTIONS = _p['CREDENTIAL_READ_FUNCTIONS']

# Backwards-compatible alias
SHEET_INJECTION_PATTERNS = CONTENT_INJECTION_PATTERNS
