"""
sentinel-security: Detect and neutralise prompt injection attacks.

Quick start:
    from sentinel_security import sanitise_content

    result = sanitise_content("some untrusted text")
    print(result['risk_level'])  # CLEAN / LOW / MEDIUM / HIGH / CRITICAL
    print(result['clean_text'])  # sanitised output

For file scanning:
    from sentinel_security import scan_file

    result = scan_file("document.xlsx")

For prompt auditing:
    from sentinel_security import audit_prompt, scan_prompt

    result = audit_prompt("your system prompt")
"""

# Core imports (eager)
from .sanitiser import sanitise, sanitise_content
from .auditor import audit as audit_prompt, scan as scan_prompt
from .configure import configure as configure

try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("sentinel-security")
except Exception:
    __version__ = "0.5.0"  # fallback for editable installs

# Lazy-loaded scanner mapping
_LAZY_IMPORTS = {
    "validate_licence": (".licence", "validate_licence"),
    "scan_csv": (".csv_scanner", "scan_csv"),
    "scan_eml": (".email_scanner", "scan_eml"),
    "scan_excel_online": (".excel_online", "scan_excel_online"),
    "scan_google_doc": (".gdocs", "scan_google_doc"),
    "scan_google_drive_file": (".gdrive", "scan_google_drive_file"),
    "scan_google_slides": (".gslides", "scan_google_slides"),
    "scan_ics": (".ics_scanner", "scan_ics"),
    "scan_image_metadata": (".image_metadata", "scan_image_metadata"),
    "scan_ms_drive_item": (".ms_drive", "scan_ms_drive_item"),
    "scan_msg": (".msg_scanner", "scan_msg"),
    "scan_pdf": (".pdf", "scan_pdf"),
    "scan_pptx_online": (".pptx_online", "scan_pptx_online"),
    "scan_file": (".scanner", "scan_file"),
    "scan_sheets": (".sheets", "scan_sheets"),
    "scan_json": (".structured_scanner", "scan_json"),
    "scan_xml": (".structured_scanner", "scan_xml"),
    "scan_yaml": (".structured_scanner", "scan_yaml"),
    "scan_word_online": (".word_online", "scan_word_online"),
}


def __getattr__(name):
    if name in _LAZY_IMPORTS:
        module_path, attr = _LAZY_IMPORTS[name]
        import importlib
        mod = importlib.import_module(module_path, __name__)
        val = getattr(mod, attr)
        globals()[name] = val
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "sanitise_content", "sanitise",
    "audit_prompt", "scan_prompt",
    "__version__",
    "scan_sheets", "scan_file",
    "scan_google_doc", "scan_google_slides", "scan_google_drive_file",
    "scan_excel_online", "scan_word_online", "scan_pptx_online",
    "scan_ms_drive_item",
    "scan_pdf", "scan_eml", "scan_msg", "scan_ics",
    "scan_csv", "scan_json", "scan_yaml", "scan_xml",
    "scan_image_metadata",
    "configure",
    "validate_licence",
]
