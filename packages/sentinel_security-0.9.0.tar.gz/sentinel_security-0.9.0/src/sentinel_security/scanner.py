"""Unified file scanner -- auto-detects file type by extension."""

import logging
import os

logger = logging.getLogger(__name__)
from typing import Optional

SUPPORTED_EXTENSIONS = {
    '.xlsx': 'excel',
    '.xls': 'excel',
    '.docx': 'word',
    '.pptx': 'pptx',
    '.pdf': 'pdf',
    '.eml': 'eml',
    '.msg': 'msg',
    '.ics': 'ics',
    '.txt': 'text',
    '.html': 'html',
    '.htm': 'html',
    '.md': 'markdown',
    '.csv': 'csv',
    '.tsv': 'tsv',
    '.json': 'json',
    '.yaml': 'yaml',
    '.yml': 'yaml',
    '.xml': 'xml',
    '.jpg': 'image',
    '.jpeg': 'image',
    '.png': 'image',
    '.tiff': 'image',
    '.webp': 'image',
}


def scan_file(file_path: str, format: Optional[str] = None) -> dict:
    """
    Scan any supported file for hidden content and prompt injection.

    Auto-detects type by extension unless format is specified.
    """
    logger.debug("scan_file: start file=%s format=%s", file_path, format)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    if format is None:
        ext = os.path.splitext(file_path)[1].lower()
        format = SUPPORTED_EXTENSIONS.get(ext, 'text')

    if format == 'excel':
        from .excel import scan_excel
        return scan_excel(file_path)
    elif format == 'word':
        from .word import scan_word
        return scan_word(file_path)
    elif format == 'pptx':
        from .pptx_scanner import scan_pptx
        return scan_pptx(file_path)
    elif format == 'pdf':
        from .pdf import scan_pdf
        return scan_pdf(file_path)
    elif format == 'eml':
        from .email_scanner import scan_eml
        return scan_eml(file_path)
    elif format == 'msg':
        from .msg_scanner import scan_msg
        return scan_msg(file_path)
    elif format == 'ics':
        from .ics_scanner import scan_ics
        return scan_ics(file_path)
    elif format == 'csv':
        from .csv_scanner import scan_csv
        return scan_csv(file_path)
    elif format == 'tsv':
        from .csv_scanner import scan_csv
        return scan_csv(file_path, delimiter='\t')
    elif format == 'json':
        from .structured_scanner import scan_json
        return scan_json(file_path, is_file=True)
    elif format == 'yaml':
        from .structured_scanner import scan_yaml
        return scan_yaml(file_path, is_file=True)
    elif format == 'xml':
        from .structured_scanner import scan_xml
        return scan_xml(file_path, is_file=True)
    elif format == 'image':
        from .image_metadata import scan_image_metadata
        return scan_image_metadata(file_path)
    elif format == 'html':
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
        from .sanitiser import sanitise_content
        return sanitise_content(content, format='html')
    elif format == 'markdown':
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
        from .sanitiser import sanitise_content
        return sanitise_content(content, format='markdown')
    else:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
        from .sanitiser import sanitise_content
        return sanitise_content(content, format='text')
