"""
Sentinel Security configuration module.

All configurable values are read from environment variables with sensible
defaults. Import from here rather than hardcoding values in individual modules.

Environment variables:
    SENTINEL_MS_TENANT_ID       - Azure AD tenant ID for Microsoft Graph
    SENTINEL_MS_CLIENT_ID       - Azure AD application (client) ID
    SENTINEL_MS_CLIENT_SECRET   - Client secret for confidential app flow
    SENTINEL_RISK_WEIGHTS       - JSON string overriding the default threat
                                  risk weights used by the scorer, e.g.
                                  '{"injection_pattern": 6, "homoglyph": 3}'
                                  Partial overrides are merged with defaults.
"""

import json
import os

# Microsoft Graph API
GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"
GRAPH_DEFAULT_SCOPES = ["https://graph.microsoft.com/.default"]
MS_LOGIN_BASE_URL = "https://login.microsoftonline.com"

# Microsoft credentials from environment (fallback values)
MS_TENANT_ID = os.environ.get("SENTINEL_MS_TENANT_ID", "")
MS_CLIENT_ID = os.environ.get("SENTINEL_MS_CLIENT_ID", "")
MS_CLIENT_SECRET = os.environ.get("SENTINEL_MS_CLIENT_SECRET", "")

# HTTP timeouts (seconds)
HTTP_TIMEOUT = int(os.environ.get("SENTINEL_HTTP_TIMEOUT", "30"))

# Risk weights for threat scoring (used by sentinel_security.sanitiser.scorer).
# Each key is a threat type; the value is added to the cumulative risk score.
_DEFAULT_RISK_WEIGHTS = {
    'injection_pattern': 4,
    'post_strip_injection': 5,
    'pdf_javascript': 5,
    'invisible_text': 4,
    'formula_injection': 4,
    'hidden_html': 3,
    'css_class_hiding': 3,
    'attribute_injection': 3,
    'markdown_injection': 3,
    'repo_metadata_injection': 3,
    'text_injection': 3,
    'comment_injection': 3,
    'cdata_injection': 3,
    'processing_instruction_injection': 3,
    'base64_block': 2,
    'base64_shard_exfil': 7,
    'rtl_override': 2,
    'homoglyph': 2,
    'invisible_unicode': 1,
    # Batch 4: Code-level behavioural detection (autoresearch merge)
    'env_harvest_exfil': 6,
    'credential_exfil': 6,
    'reverse_shell': 8,
    'supply_chain_hook': 6,
    'resource_abuse': 5,
    'privilege_escalation': 5,
    'persistence_mechanism': 5,
    'network_attack': 5,
    'c2_beacon': 6,
    'code_steganography': 4,
    'encoded_prompt_injection': 4,
    'advanced_prompt_override': 4,
    'container_escape': 6,
}

def _build_risk_weights() -> dict:
    """Build the effective RISK_WEIGHTS, preferring the rule bundle over inline defaults.

    Priority order (highest to lowest):
    1. SENTINEL_RISK_WEIGHTS env var (partial override merged on top)
    2. rule_bundle_data.json risk_weights section
    3. _DEFAULT_RISK_WEIGHTS (inline fallback for backwards compat)
    """
    try:
        from .rules_loader import get_risk_weights as _get_risk_weights
        bundle_weights = _get_risk_weights()
        base = bundle_weights if bundle_weights else _DEFAULT_RISK_WEIGHTS
    except Exception:
        base = _DEFAULT_RISK_WEIGHTS

    env_raw = os.environ.get("SENTINEL_RISK_WEIGHTS")
    if env_raw:
        try:
            env_override = json.loads(env_raw)
            return {**base, **env_override}
        except (json.JSONDecodeError, TypeError):
            pass
    return base


RISK_WEIGHTS = _build_risk_weights()
