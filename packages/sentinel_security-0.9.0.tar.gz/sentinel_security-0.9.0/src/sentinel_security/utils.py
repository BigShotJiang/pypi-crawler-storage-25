"""Shared utility functions for sentinel-security scanners."""


def calculate_threat_risk_score(threats: list) -> int:
    """Calculate risk score from a list of threat dicts with 'severity' key."""
    score = 0
    for t in threats:
        s = t.get('severity', 'LOW')
        if s == 'CRITICAL':
            score += 5
        elif s == 'HIGH':
            score += 3
        elif s == 'MEDIUM':
            score += 1
    return min(10, score)
