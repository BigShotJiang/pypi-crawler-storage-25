"""
Haystack pipeline component adapter for Sentinel security scanning.

Requires: haystack-ai >= 2.0
Install:  pip install sentinel-security[haystack]

Usage:
    from sentinel_security.middleware.haystack import SentinelGuard

    pipeline.add_component("sentinel", SentinelGuard(policy="block"))
    pipeline.connect("retriever.documents", "sentinel.documents")
    pipeline.connect("sentinel.documents", "prompt_builder.documents")
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

try:
    from haystack import Document, component  # noqa: F401
except ImportError:
    raise ImportError(
        "SentinelGuard requires haystack-ai >= 2.0. "
        "Install with: pip install sentinel-security[haystack]"
    )

from sentinel_security.middleware._types import ScanContext, ScanResult
from sentinel_security.middleware.engine import DetectionEngine

logger = logging.getLogger("sentinel_security.middleware.haystack")


@component
class SentinelGuard:
    """
    Haystack pipeline component that scans documents for prompt injection.

    Splits incoming documents into two outputs:

    - ``documents``: clean or flagged documents that passed scanning.
    - ``blocked``: documents that were blocked by the detection policy.

    Each document's ``meta`` dict is annotated with:
    ``sentinel_risk_score``, ``sentinel_threats``, ``sentinel_action``,
    ``sentinel_scan_id``.

    Blocking behaviour:
        Routes blocked documents to the ``blocked`` output port.
        Does **not** raise exceptions — follows the Haystack pipeline
        component pattern.

    Args:
        policy: Detection policy -- "log", "warn", or "block".
        risk_threshold: Risk score (0-10) above which the policy action fires.
        event_handler: Optional callback receiving ``ScanEvent`` instances.
        **engine_kwargs: Additional kwargs forwarded to ``DetectionEngine``.
    """

    def __init__(
        self,
        *,
        policy: Optional[str] = None,
        risk_threshold: Optional[int] = None,
        event_handler: Optional[Callable[..., Any]] = None,
        **engine_kwargs: Any,
    ) -> None:
        config: Dict[str, Any] = {}
        if policy is not None:
            config["policy"] = policy
        if risk_threshold is not None:
            config["risk_threshold"] = risk_threshold
        if event_handler is not None:
            config["event_handler"] = event_handler
        config.update(engine_kwargs)

        self.engine = DetectionEngine(config if config else None)

    @component.output_types(documents=List[Document], blocked=List[Document])
    def run(self, documents: List[Document]) -> Dict[str, List[Document]]:
        """
        Scan a batch of documents and split into passed / blocked.

        Args:
            documents: List of Haystack Document objects to scan.

        Returns:
            Dict with ``documents`` (passed) and ``blocked`` (blocked) lists.
        """
        try:
            ctx = ScanContext(framework="haystack", hook_point="pipeline-component")
            results: List[ScanResult] = self.engine.scan_documents(
                documents, context=ctx
            )
        except Exception:
            logger.exception("sentinel.haystack: run() scan error, failing open")
            return {"documents": documents, "blocked": []}

        passed: List[Document] = []
        blocked: List[Document] = []

        for doc, result in zip(documents, results):
            # Annotate document metadata (non-destructive, additive)
            doc.meta["sentinel_risk_score"] = result.risk_score
            doc.meta["sentinel_threats"] = [
                t.get("type", "unknown") for t in result.threats
            ]
            doc.meta["sentinel_action"] = result.action_taken
            doc.meta["sentinel_scan_id"] = result.scan_id

            if result.action_taken == "block":
                blocked.append(doc)
            else:
                passed.append(doc)

        return {"documents": passed, "blocked": blocked}
