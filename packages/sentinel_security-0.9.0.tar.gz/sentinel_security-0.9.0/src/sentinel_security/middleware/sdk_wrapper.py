"""
SDK wrapper: sentinel_wrap() for OpenAI and Anthropic clients.

Monkey-patches client.chat.completions.create (OpenAI) or
client.messages.create (Anthropic) to scan inputs and outputs
via DetectionEngine.

No hard dependency on openai or anthropic -- both are optional.
"""

from __future__ import annotations

import asyncio
import functools
import logging
from typing import Any, Dict, Iterator, List, Optional

from sentinel_security.middleware._types import (
    ScanContext,
    ScanResult,
    SentinelBlockedError,
)
from sentinel_security.middleware.engine import DetectionEngine

logger = logging.getLogger("sentinel_security.middleware.sdk_wrapper")

_SENTINEL_BLOCKED_MSG = "[SENTINEL BLOCKED: content blocked due to security risk]"


# ── Public API ────────────────────────────────────────────────────────


def sentinel_wrap(client: Any, **config: Any) -> Any:
    """Wrap an OpenAI or Anthropic client with Sentinel scanning.

    Supports: openai.OpenAI, openai.AsyncOpenAI,
              anthropic.Anthropic, anthropic.AsyncAnthropic

    Multiple wraps are idempotent (no double-patching).

    Returns the same client instance, now instrumented.

    Blocking behaviour:
        - Input scan: raises ``SentinelBlockedError`` when policy="block"
          and risk exceeds threshold.
        - Output scan (non-streaming): replaces response content with a
          blocked message.
        - Output scan (streaming): yields a single chunk with the blocked
          message instead of the original stream.
    """
    if getattr(client, "_sentinel_wrapped", False):
        return client

    engine = DetectionEngine(config if config else None)

    if _is_openai_sync(client):
        _wrap_openai_sync(client, engine)
    elif _is_openai_async(client):
        _wrap_openai_async(client, engine)
    elif _is_anthropic_sync(client):
        _wrap_anthropic_sync(client, engine)
    elif _is_anthropic_async(client):
        _wrap_anthropic_async(client, engine)
    else:
        raise TypeError(
            f"Unsupported client type: {type(client).__module__}.{type(client).__name__}. "
            f"sentinel_wrap() supports openai.OpenAI, openai.AsyncOpenAI, "
            f"anthropic.Anthropic, and anthropic.AsyncAnthropic."
        )

    client._sentinel_wrapped = True
    return client


# ── Client type detection ─────────────────────────────────────────────


def _is_openai_sync(client: Any) -> bool:
    try:
        import openai  # type: ignore[import-untyped]
        return isinstance(client, openai.OpenAI)
    except ImportError:
        return False


def _is_openai_async(client: Any) -> bool:
    try:
        import openai  # type: ignore[import-untyped]
        return isinstance(client, openai.AsyncOpenAI)
    except ImportError:
        return False


def _is_anthropic_sync(client: Any) -> bool:
    try:
        import anthropic  # type: ignore[import-untyped]
        return isinstance(client, anthropic.Anthropic)
    except ImportError:
        return False


def _is_anthropic_async(client: Any) -> bool:
    try:
        import anthropic  # type: ignore[import-untyped]
        return isinstance(client, anthropic.AsyncAnthropic)
    except ImportError:
        return False


# ── OpenAI wrappers ───────────────────────────────────────────────────


def _extract_openai_messages(args: tuple, kwargs: dict) -> List[Dict[str, str]]:
    """Extract messages list from OpenAI create() call."""
    return kwargs.get("messages", args[0] if args else [])


def _extract_openai_response_content(response: Any) -> str:
    """Extract text content from an OpenAI ChatCompletion response."""
    try:
        return response.choices[0].message.content or ""
    except (IndexError, AttributeError):
        return ""


def _wrap_openai_sync(client: Any, engine: DetectionEngine) -> None:
    """Patch client.chat.completions.create (sync)."""
    original_create = client.chat.completions.create

    @functools.wraps(original_create)
    def wrapped_create(*args: Any, **kwargs: Any) -> Any:
        # Pre-scan: inspect messages
        try:
            messages = _extract_openai_messages(args, kwargs)
            ctx = ScanContext(framework="openai", hook_point="pre-request")
            pre_result = engine.scan_input(messages, context=ctx)
            if pre_result.action_taken == "block":
                raise SentinelBlockedError(pre_result)
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.sdk_wrapper: pre-scan error, failing open")

        # Check for streaming
        if kwargs.get("stream", False):
            response = original_create(*args, **kwargs)
            return _wrap_openai_stream_sync(response, engine)

        # Non-streaming: call original then post-scan
        response = original_create(*args, **kwargs)
        try:
            content = _extract_openai_response_content(response)
            ctx_out = ScanContext(framework="openai", hook_point="post-response")
            post_result = engine.scan_output(content, source="openai-response", context=ctx_out)
            if post_result.action_taken == "block":
                response.choices[0].message.content = _SENTINEL_BLOCKED_MSG
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.sdk_wrapper: post-scan error, failing open")

        return response

    client.chat.completions.create = wrapped_create


def _wrap_openai_async(client: Any, engine: DetectionEngine) -> None:
    """Patch client.chat.completions.create (async)."""
    original_create = client.chat.completions.create

    @functools.wraps(original_create)
    async def wrapped_create(*args: Any, **kwargs: Any) -> Any:
        # Pre-scan
        try:
            messages = _extract_openai_messages(args, kwargs)
            ctx = ScanContext(framework="openai", hook_point="pre-request")
            pre_result = engine.scan_input(messages, context=ctx)
            if pre_result.action_taken == "block":
                raise SentinelBlockedError(pre_result)
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.sdk_wrapper: pre-scan error, failing open")

        # Check for streaming
        if kwargs.get("stream", False):
            response = await original_create(*args, **kwargs)
            return _wrap_openai_stream_async(response, engine)

        # Non-streaming
        response = await original_create(*args, **kwargs)
        try:
            content = _extract_openai_response_content(response)
            ctx_out = ScanContext(framework="openai", hook_point="post-response")
            post_result = engine.scan_output(content, source="openai-response", context=ctx_out)
            if post_result.action_taken == "block":
                response.choices[0].message.content = _SENTINEL_BLOCKED_MSG
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.sdk_wrapper: post-scan error, failing open")

        return response

    client.chat.completions.create = wrapped_create


# ── OpenAI stream wrappers ────────────────────────────────────────────


def _extract_openai_chunk_content(chunk: Any) -> str:
    """Extract delta content from an OpenAI stream chunk."""
    try:
        delta = chunk.choices[0].delta
        return delta.content or ""
    except (IndexError, AttributeError):
        return ""


def _wrap_openai_stream_sync(stream: Any, engine: DetectionEngine) -> Iterator:
    """Buffer OpenAI stream chunks, scan complete text, yield chunks."""
    chunks = []
    full_text_parts: List[str] = []

    try:
        for chunk in stream:
            chunks.append(chunk)
            full_text_parts.append(_extract_openai_chunk_content(chunk))
    except Exception:
        logger.exception("sentinel.sdk_wrapper: stream buffer error, yielding buffered chunks")
        for chunk in chunks:
            yield chunk
        return

    try:
        full_text = "".join(full_text_parts)
        ctx = ScanContext(framework="openai", hook_point="post-stream")
        result = engine.scan_output(full_text, source="openai-stream", context=ctx)
    except Exception:
        logger.exception("sentinel.sdk_wrapper: stream scan error, failing open")
        for chunk in chunks:
            yield chunk
        return

    if result.action_taken == "block":
        # Yield a single chunk with the blocked message
        blocked_chunk = chunks[0] if chunks else None
        if blocked_chunk is not None:
            try:
                blocked_chunk.choices[0].delta.content = _SENTINEL_BLOCKED_MSG
            except (IndexError, AttributeError):
                pass
            yield blocked_chunk
        return

    # Yield all original chunks
    for chunk in chunks:
        yield chunk


async def _wrap_openai_stream_async(stream: Any, engine: DetectionEngine):
    """Buffer async OpenAI stream chunks, scan complete text, yield chunks."""
    chunks = []
    full_text_parts: List[str] = []

    try:
        async for chunk in stream:
            chunks.append(chunk)
            full_text_parts.append(_extract_openai_chunk_content(chunk))
    except Exception:
        logger.exception("sentinel.sdk_wrapper: async stream buffer error, yielding buffered chunks")
        for chunk in chunks:
            yield chunk
        return

    try:
        full_text = "".join(full_text_parts)
        ctx = ScanContext(framework="openai", hook_point="post-stream")
        result = engine.scan_output(full_text, source="openai-stream", context=ctx)
    except Exception:
        logger.exception("sentinel.sdk_wrapper: async stream scan error, failing open")
        for chunk in chunks:
            yield chunk
        return

    if result.action_taken == "block":
        blocked_chunk = chunks[0] if chunks else None
        if blocked_chunk is not None:
            try:
                blocked_chunk.choices[0].delta.content = _SENTINEL_BLOCKED_MSG
            except (IndexError, AttributeError):
                pass
            yield blocked_chunk
        return

    for chunk in chunks:
        yield chunk


# ── Anthropic wrappers ────────────────────────────────────────────────


def _extract_anthropic_messages(args: tuple, kwargs: dict) -> List[Dict[str, str]]:
    """Extract messages list from Anthropic create() call."""
    return kwargs.get("messages", args[0] if args else [])


def _extract_anthropic_response_content(response: Any) -> str:
    """Extract text content from an Anthropic Message response.

    Concatenates ALL text blocks to ensure multi-block responses are fully scanned.
    """
    try:
        texts = []
        for block in response.content:
            if hasattr(block, "text"):
                texts.append(block.text)
        return "\n".join(texts) if texts else ""
    except (IndexError, AttributeError, TypeError):
        return ""


def _wrap_anthropic_sync(client: Any, engine: DetectionEngine) -> None:
    """Patch client.messages.create (sync)."""
    original_create = client.messages.create

    @functools.wraps(original_create)
    def wrapped_create(*args: Any, **kwargs: Any) -> Any:
        # Pre-scan
        try:
            messages = _extract_anthropic_messages(args, kwargs)
            ctx = ScanContext(framework="anthropic", hook_point="pre-request")
            pre_result = engine.scan_input(messages, context=ctx)
            if pre_result.action_taken == "block":
                raise SentinelBlockedError(pre_result)
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.sdk_wrapper: pre-scan error, failing open")

        # Streaming
        if kwargs.get("stream", False):
            response = original_create(*args, **kwargs)
            return _wrap_anthropic_stream_sync(response, engine)

        # Non-streaming
        response = original_create(*args, **kwargs)
        try:
            content = _extract_anthropic_response_content(response)
            ctx_out = ScanContext(framework="anthropic", hook_point="post-response")
            post_result = engine.scan_output(content, source="anthropic-response", context=ctx_out)
            if post_result.action_taken == "block":
                response.content[0].text = _SENTINEL_BLOCKED_MSG
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.sdk_wrapper: post-scan error, failing open")

        return response

    client.messages.create = wrapped_create


def _wrap_anthropic_async(client: Any, engine: DetectionEngine) -> None:
    """Patch client.messages.create (async)."""
    original_create = client.messages.create

    @functools.wraps(original_create)
    async def wrapped_create(*args: Any, **kwargs: Any) -> Any:
        # Pre-scan
        try:
            messages = _extract_anthropic_messages(args, kwargs)
            ctx = ScanContext(framework="anthropic", hook_point="pre-request")
            pre_result = engine.scan_input(messages, context=ctx)
            if pre_result.action_taken == "block":
                raise SentinelBlockedError(pre_result)
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.sdk_wrapper: pre-scan error, failing open")

        # Streaming
        if kwargs.get("stream", False):
            response = await original_create(*args, **kwargs)
            return _wrap_anthropic_stream_async(response, engine)

        # Non-streaming
        response = await original_create(*args, **kwargs)
        try:
            content = _extract_anthropic_response_content(response)
            ctx_out = ScanContext(framework="anthropic", hook_point="post-response")
            post_result = engine.scan_output(content, source="anthropic-response", context=ctx_out)
            if post_result.action_taken == "block":
                response.content[0].text = _SENTINEL_BLOCKED_MSG
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.sdk_wrapper: post-scan error, failing open")

        return response

    client.messages.create = wrapped_create


# ── Anthropic stream wrappers ────────────────────────────────────────


def _extract_anthropic_stream_text(event: Any) -> str:
    """Extract text delta from an Anthropic stream event."""
    # Anthropic streaming emits events with type "content_block_delta"
    # and a delta.text attribute
    try:
        if hasattr(event, "delta") and hasattr(event.delta, "text"):
            return event.delta.text or ""
    except AttributeError:
        pass
    return ""


def _wrap_anthropic_stream_sync(stream: Any, engine: DetectionEngine) -> Iterator:
    """Buffer Anthropic stream events, scan complete text, yield events."""
    events = []
    full_text_parts: List[str] = []

    try:
        for event in stream:
            events.append(event)
            full_text_parts.append(_extract_anthropic_stream_text(event))
    except Exception:
        logger.exception("sentinel.sdk_wrapper: anthropic stream buffer error, yielding buffered events")
        for event in events:
            yield event
        return

    try:
        full_text = "".join(full_text_parts)
        ctx = ScanContext(framework="anthropic", hook_point="post-stream")
        result = engine.scan_output(full_text, source="anthropic-stream", context=ctx)
    except Exception:
        logger.exception("sentinel.sdk_wrapper: anthropic stream scan error, failing open")
        for event in events:
            yield event
        return

    if result.action_taken == "block":
        blocked_event = events[0] if events else None
        if blocked_event is not None:
            try:
                blocked_event.delta.text = _SENTINEL_BLOCKED_MSG
            except AttributeError:
                pass
            yield blocked_event
        return

    for event in events:
        yield event


async def _wrap_anthropic_stream_async(stream: Any, engine: DetectionEngine):
    """Buffer async Anthropic stream events, scan complete text, yield events."""
    events = []
    full_text_parts: List[str] = []

    try:
        async for event in stream:
            events.append(event)
            full_text_parts.append(_extract_anthropic_stream_text(event))
    except Exception:
        logger.exception("sentinel.sdk_wrapper: async anthropic stream buffer error, yielding buffered events")
        for event in events:
            yield event
        return

    try:
        full_text = "".join(full_text_parts)
        ctx = ScanContext(framework="anthropic", hook_point="post-stream")
        result = engine.scan_output(full_text, source="anthropic-stream", context=ctx)
    except Exception:
        logger.exception("sentinel.sdk_wrapper: async anthropic stream scan error, failing open")
        for event in events:
            yield event
        return

    if result.action_taken == "block":
        blocked_event = events[0] if events else None
        if blocked_event is not None:
            try:
                blocked_event.delta.text = _SENTINEL_BLOCKED_MSG
            except AttributeError:
                pass
            yield blocked_event
        return

    for event in events:
        yield event
