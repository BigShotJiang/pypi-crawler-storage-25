"""
Sentinel middleware package.

Core types and DetectionEngine are always available (no framework deps).
Framework-specific adapters are lazy-loaded to avoid importing unused
framework libraries.
"""

from __future__ import annotations

from sentinel_security.middleware._types import (
    ScanEvent,
    ScanResult,
    SentinelBlockedError,
)
from sentinel_security.middleware.engine import DetectionEngine

__all__ = [
    "DetectionEngine",
    "ScanEvent",
    "ScanResult",
    "SentinelBlockedError",
    "sentinel_wrap",
]

# Framework-specific adapters: lazy import with clear error on missing dep
_LAZY_ADAPTERS = {
    "SentinelMiddleware": (
        "sentinel_security.middleware.langchain",
        "SentinelMiddleware",
        "langchain",
        "langchain",
    ),
    "SentinelCallbackHandler": (
        "sentinel_security.middleware.langchain_callback",
        "SentinelCallbackHandler",
        "langchain-core",
        "langchain",
    ),
    "SentinelCrewAI": (
        "sentinel_security.middleware.crewai",
        "SentinelCrewAI",
        "crewai",
        "crewai",
    ),
    "SentinelGuard": (
        "sentinel_security.middleware.haystack",
        "SentinelGuard",
        "haystack-ai",
        "haystack",
    ),
    "SentinelAutoGen": (
        "sentinel_security.middleware.autogen",
        "SentinelAutoGen",
        "ag2",
        "autogen",
    ),
    "sentinel_wrap": (
        "sentinel_security.middleware.sdk_wrapper",
        "sentinel_wrap",
        None,
        None,
    ),
}


def __getattr__(name: str):  # type: ignore[override]
    if name in _LAZY_ADAPTERS:
        module_path, attr, pip_pkg, extra = _LAZY_ADAPTERS[name]
        try:
            import importlib

            mod = importlib.import_module(module_path)
            val = getattr(mod, attr)
            globals()[name] = val
            return val
        except ImportError:
            if pip_pkg is not None:
                raise ImportError(
                    f"{attr} requires {pip_pkg}. "
                    f"Install with: pip install sentinel-security[{extra}]"
                )
            raise
    raise AttributeError(
        f"module 'sentinel_security.middleware' has no attribute {name!r}"
    )
