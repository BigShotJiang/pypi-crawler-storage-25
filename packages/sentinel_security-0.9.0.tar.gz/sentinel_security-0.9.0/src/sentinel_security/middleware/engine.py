"""
DetectionEngine v1: Unified detection interface for all framework middleware.

API VERSION: 1
STABILITY: Stable. Breaking changes require major version bump.
CONSUMERS: langchain.py, sdk_wrapper.py, crewai.py, haystack.py, autogen.py
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

from sentinel_security.sanitiser import sanitise_content
from sentinel_security.middleware._types import (
    ScanContext,
    ScanEvent,
    ScanResult,
    SentinelBlockedError,
)

logger = logging.getLogger("sentinel_security.audit")


def _get_global_config() -> Dict[str, Any]:
    """Lazy import of global config to avoid circular imports."""
    try:
        from sentinel_security.configure import _global_config, _config_lock
        with _config_lock:
            return dict(_global_config)
    except (ImportError, AttributeError):
        return {}


class DetectionEngine:
    """
    Unified detection interface for all framework middleware.

    Wraps existing sanitise_content() — does NOT duplicate detection logic.
    """

    VERSION: int = 1

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        merged = _get_global_config()
        if config:
            merged.update(config)

        self.policy: str = merged.get("policy", "warn")
        self.risk_threshold: int = int(merged.get("risk_threshold", 5))
        self.event_handler: Optional[Callable[..., Any]] = merged.get(
            "event_handler", None
        )
        self.log_content: bool = bool(merged.get("log_content", False))
        self.enabled: bool = bool(merged.get("middleware_enabled", True))
        self.scan_id_prefix: str = merged.get("scan_id_prefix", "")

        if self.log_content:
            logging.getLogger("sentinel_security.config").warning(
                "Sentinel content logging is ENABLED. Scanned content will "
                "appear in audit logs. Disable for production/SOC2 environments."
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan_input(
        self,
        messages: List[Dict[str, str]],
        *,
        context: Optional[ScanContext] = None,
    ) -> ScanResult:
        """Scan messages before they reach the LLM."""
        text = self._concat_messages(messages)
        framework = context.framework if context else ""
        source = context.hook_point if context else "input"
        return self._scan(text, framework=framework, source=source, context=context)

    def scan_output(
        self,
        content: str,
        *,
        source: str = "llm",
        context: Optional[ScanContext] = None,
    ) -> ScanResult:
        """Scan LLM responses, tool outputs, or inter-agent messages."""
        framework = context.framework if context else ""
        return self._scan(content, framework=framework, source=source, context=context)

    def scan_documents(
        self,
        documents: List[Any],
        *,
        content_extractor: Optional[Callable[..., str]] = None,
        context: Optional[ScanContext] = None,
    ) -> List[ScanResult]:
        """Scan a batch of documents (for RAG pipelines)."""
        results: List[ScanResult] = []
        for doc in documents:
            if content_extractor is not None:
                text = content_extractor(doc)
            elif hasattr(doc, "content"):
                text = str(doc.content)
            else:
                text = str(doc)
            framework = context.framework if context else ""
            source = context.hook_point if context else "document"
            results.append(
                self._scan(text, framework=framework, source=source, context=context)
            )
        return results

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _concat_messages(messages: List[Dict[str, str]]) -> str:
        parts: List[str] = []
        for msg in messages:
            content = msg.get("content", "")
            if content:
                parts.append(content)
        return "\n".join(parts)

    def _scan(
        self,
        text: str,
        *,
        framework: str,
        source: str,
        context: Optional[ScanContext],
    ) -> ScanResult:
        if not self.enabled:
            return ScanResult(
                action_taken="allow",
                source=source,
                content_length=len(text),
            )

        start = time.monotonic()
        try:
            sanitise_result = sanitise_content(text)
            elapsed_ms = (time.monotonic() - start) * 1000

            risk_score: int = sanitise_result["risk_score"]
            risk_level: str = sanitise_result["risk_level"]
            threats: List[Dict[str, Any]] = sanitise_result["threats"]
            clean_text: str = sanitise_result["clean_text"]

            action = self._determine_action(risk_score)

            scan_id = (
                f"{self.scan_id_prefix}{uuid.uuid4()}"
                if self.scan_id_prefix
                else str(uuid.uuid4())
            )

            result = ScanResult(
                scan_id=scan_id,
                risk_level=risk_level,
                risk_score=risk_score,
                threats=threats,
                clean_text=clean_text,
                action_taken=action,
                scan_duration_ms=round(elapsed_ms, 2),
                source=source,
                content_length=len(text),
            )

            self._emit_event(result, framework=framework, source=source, text=text)

            return result
        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            logger.error(
                "sentinel.scan.error framework=%s source=%s error=%s",
                framework, source, exc,
            )
            result = ScanResult(
                action_taken="allow",
                source=source,
                content_length=len(text),
                scan_duration_ms=round(elapsed_ms, 2),
            )
            self._emit_error_event(
                result, framework=framework, source=source, error=exc,
            )
            return result

    def _determine_action(self, risk_score: int) -> str:
        if risk_score < self.risk_threshold:
            return "allow"
        if self.policy == "log":
            return "allow"
        if self.policy == "warn":
            return "flag"
        if self.policy == "block":
            return "block"
        return "allow"

    def _emit_event(
        self,
        result: ScanResult,
        *,
        framework: str,
        source: str,
        text: str,
    ) -> None:
        # Determine event type
        if result.action_taken == "block":
            event_type = "blocked"
        elif result.threats:
            event_type = "threat_detected"
        else:
            event_type = "scan_complete"

        # Strip matched content from threat dicts for the event (SOC2)
        safe_threats: List[Dict[str, str]] = []
        for t in result.threats:
            safe_threats.append({
                "type": t.get("type", "unknown"),
                "name": t.get("mechanism", t.get("type", "unknown")),
            })

        event = ScanEvent(
            scan_id=result.scan_id,
            timestamp=result.timestamp,
            event_type=event_type,
            framework=framework,
            source=source,
            risk_score=result.risk_score,
            risk_level=result.risk_level,
            threats=safe_threats,
            action=result.action_taken,
            scan_duration_ms=result.scan_duration_ms,
            content_length=result.content_length,
            policy_applied=self.policy,
            risk_threshold_applied=self.risk_threshold,
            engine_version=self.VERSION,
            content=text if self.log_content else None,
        )

        # Python logging at appropriate level
        log_data = event.to_dict()
        if result.action_taken == "block":
            logger.error("sentinel.scan %s", log_data)
        elif result.action_taken == "flag":
            logger.warning("sentinel.scan %s", log_data)
        else:
            logger.debug("sentinel.scan %s", log_data)

        # Custom event handler
        if self.event_handler is not None:
            try:
                self.event_handler(event)
            except Exception:
                logger.exception("Error in custom event handler")

    def _emit_error_event(
        self,
        result: ScanResult,
        *,
        framework: str,
        source: str,
        error: Exception,
    ) -> None:
        """Emit a scan_error event for audit trail when scanning fails."""
        event = ScanEvent(
            scan_id=result.scan_id,
            timestamp=result.timestamp,
            event_type="scan_error",
            framework=framework,
            source=source,
            risk_score=0,
            risk_level="CLEAN",
            threats=[],
            action="allow",
            scan_duration_ms=result.scan_duration_ms,
            content_length=result.content_length,
            policy_applied=self.policy,
            risk_threshold_applied=self.risk_threshold,
            engine_version=self.VERSION,
        )

        logger.error("sentinel.scan.error %s", event.to_dict())

        if self.event_handler is not None:
            try:
                self.event_handler(event)
            except Exception:
                logger.exception("Error in custom event handler")
