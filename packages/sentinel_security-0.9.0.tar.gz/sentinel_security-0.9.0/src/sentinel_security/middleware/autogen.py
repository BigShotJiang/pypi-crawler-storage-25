"""
AutoGen/AG2 adapter for Sentinel security scanning.

Requires: ag2 >= 0.4
Install:  pip install sentinel-security[autogen]

Usage:
    from sentinel_security.middleware.autogen import SentinelAutoGen

    agent = SentinelAutoGen.protect(agent, policy="block")
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

try:
    import ag2  # noqa: F401
except ImportError:
    try:
        import autogen  # noqa: F401
    except ImportError:
        raise ImportError(
            "SentinelAutoGen requires ag2 >= 0.4. "
            "Install with: pip install sentinel-security[autogen]"
        )

from sentinel_security.middleware._types import ScanContext, ScanResult
from sentinel_security.middleware.engine import DetectionEngine
from sentinel_security.middleware._utils import content_hash as _content_hash

logger = logging.getLogger("sentinel_security.middleware.autogen")

_DEFAULT_BLOCKED_MESSAGE = "This message was blocked by Sentinel security scanning."

# Source tags used in ScanContext for audit trail
_SOURCE_INBOUND = "inbound"
_SOURCE_OUTBOUND = "outbound"


class SentinelAutoGen:
    """
    Runtime security adapter for AutoGen/AG2 agents.

    Registers ``process_last_received_message`` and
    ``process_message_before_send`` hooks on the agent to scan inbound
    and outbound messages using the DetectionEngine.

    Deduplication: Tracks content hashes per adapter instance and skips
    re-scans of identical content.

    Blocking behaviour:
        Returns a replacement message with blocked text when policy="block"
        and risk exceeds threshold. Does **not** raise exceptions — follows
        the AutoGen hook API which requires returning a value.

    Args:
        policy: Detection policy -- "log", "warn", or "block".
        risk_threshold: Risk score (0-10) above which the policy action fires.
        event_handler: Optional callback receiving ``ScanEvent`` instances.
        blocked_message: Replacement text returned when a message is blocked.
        **engine_kwargs: Additional kwargs forwarded to ``DetectionEngine``.
    """

    def __init__(
        self,
        *,
        policy: Optional[str] = None,
        risk_threshold: Optional[int] = None,
        event_handler: Optional[Callable[..., Any]] = None,
        blocked_message: Optional[str] = None,
        **engine_kwargs: Any,
    ) -> None:
        config: Dict[str, Any] = {}
        if policy is not None:
            config["policy"] = policy
        if risk_threshold is not None:
            config["risk_threshold"] = risk_threshold
        if event_handler is not None:
            config["event_handler"] = event_handler
        config.update(engine_kwargs)

        self.engine = DetectionEngine(config if config else None)
        self.blocked_message = blocked_message or _DEFAULT_BLOCKED_MESSAGE
        # Dedup: cache scan results by content hash to avoid re-scanning
        # and to preserve block decisions on repeated content
        self._scan_cache: Dict[str, ScanResult] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @classmethod
    def protect(cls, agent: Any, **kwargs: Any) -> Any:
        """
        Register Sentinel security hooks on an AutoGen/AG2 agent.

        Installs ``process_last_received_message`` (inbound) and
        ``process_message_before_send`` (outbound) hooks.

        Args:
            agent: An AG2 ``ConversableAgent`` (or subclass) instance.
            **kwargs: Forwarded to ``SentinelAutoGen`` constructor.

        Returns:
            The same agent instance (mutated in place) for chaining.
        """
        adapter = cls(**kwargs)

        def inbound_hook(message: Any) -> Any:
            """Sentinel inbound hook: scans received messages."""
            try:
                content = _extract_content(message)
                if not content:
                    return message
                result = adapter._scan_with_dedup(
                    content, hook_point=_SOURCE_INBOUND
                )
                if result is not None and result.action_taken == "block":
                    return _replace_content(message, adapter.blocked_message)
            except Exception:
                logger.exception("sentinel.autogen: inbound_hook error, failing open")
            return message

        def outbound_hook(message: Any) -> Any:
            """Sentinel outbound hook: scans messages before sending."""
            try:
                content = _extract_content(message)
                if not content:
                    return message
                result = adapter._scan_with_dedup(
                    content, hook_point=_SOURCE_OUTBOUND
                )
                if result is not None and result.action_taken == "block":
                    return _replace_content(message, adapter.blocked_message)
            except Exception:
                logger.exception("sentinel.autogen: outbound_hook error, failing open")
            return message

        agent.register_hook("process_last_received_message", inbound_hook)
        agent.register_hook("process_message_before_send", outbound_hook)

        return agent

    # ------------------------------------------------------------------
    # Internal: scanning with dedup
    # ------------------------------------------------------------------

    def _scan_with_dedup(
        self, content: str, *, hook_point: str
    ) -> Optional[ScanResult]:
        """Scan content, returning cached result if already scanned."""
        content_h = _content_hash(content)
        if content_h in self._scan_cache:
            logger.debug(
                "Sentinel dedup: returning cached result for content hash %s",
                content_h[:12],
            )
            return self._scan_cache[content_h]

        ctx = ScanContext(framework="autogen", hook_point=hook_point)
        result = self.engine.scan_output(
            content, source=hook_point, context=ctx
        )
        self._scan_cache[content_h] = result

        return result

    def clear_dedup_cache(self) -> None:
        """Clear the dedup cache. Useful between sessions."""
        self._scan_cache.clear()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _extract_content(message: Any) -> str:
    """Extract string content from an AutoGen message.

    Messages can be plain strings or dicts with a ``content`` key.
    """
    if isinstance(message, str):
        return message
    if isinstance(message, dict):
        content = message.get("content", "")
        if isinstance(content, str):
            return content
    # Object with .content attribute
    content = getattr(message, "content", None)
    if isinstance(content, str):
        return content
    return ""


def _replace_content(message: Any, replacement: str) -> Any:
    """Return message with content replaced by the blocked text.

    Preserves the original message type (str or dict).
    """
    if isinstance(message, str):
        return replacement
    if isinstance(message, dict):
        replaced = dict(message)
        replaced["content"] = replacement
        return replaced
    return replacement
