"""
CrewAI adapter for Sentinel security scanning.

Requires: crewai >= 0.80
Install:  pip install sentinel-security[crewai]

Usage:
    from sentinel_security.middleware.crewai import SentinelCrewAI

    # Protect all agents in a crew
    crew = SentinelCrewAI.protect(crew, policy="block")

    # Or protect a single agent
    agent = SentinelCrewAI.protect_agent(agent, policy="warn")
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

try:
    import crewai  # noqa: F401
except ImportError:
    raise ImportError(
        "SentinelCrewAI requires crewai >= 0.80. "
        "Install with: pip install sentinel-security[crewai]"
    )

from sentinel_security.middleware._types import (
    ScanContext,
    ScanResult,
    SentinelBlockedError,
)
from sentinel_security.middleware.engine import DetectionEngine
from sentinel_security.middleware._utils import content_hash as _content_hash

logger = logging.getLogger("sentinel_security.middleware.crewai")

# Source tags used in ScanContext for audit trail
_SOURCE_STEP = "crewai-step"
_SOURCE_TASK = "crewai-task"


class SentinelCrewAI:
    """
    Runtime security adapter for CrewAI crews and agents.

    Wraps agent ``step_callback`` and ``task_callback`` hooks to scan
    agent step outputs and inter-agent task outputs using the DetectionEngine.

    Deduplication: When LangChain SentinelMiddleware is also active (CrewAI
    uses LangChain internally), the same content may be scanned twice. This
    adapter tracks content hashes per session_id and skips re-scans of
    identical content within the same session.

    Blocking behaviour:
        Raises ``SentinelBlockedError`` when policy="block" and risk
        exceeds threshold. This halts agent execution.

    Args:
        policy: Detection policy -- "log", "warn", or "block".
        risk_threshold: Risk score (0-10) above which the policy action fires.
        event_handler: Optional callback receiving ``ScanEvent`` instances.
        **engine_kwargs: Additional kwargs forwarded to ``DetectionEngine``.
    """

    def __init__(
        self,
        *,
        policy: Optional[str] = None,
        risk_threshold: Optional[int] = None,
        event_handler: Optional[Callable[..., Any]] = None,
        **engine_kwargs: Any,
    ) -> None:
        config: Dict[str, Any] = {}
        if policy is not None:
            config["policy"] = policy
        if risk_threshold is not None:
            config["risk_threshold"] = risk_threshold
        if event_handler is not None:
            config["event_handler"] = event_handler
        config.update(engine_kwargs)

        self.engine = DetectionEngine(config if config else None)
        # Dedup: cache scan results by content hash to avoid re-scanning
        # and to preserve block decisions on repeated content
        self._scan_cache: Dict[str, ScanResult] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @classmethod
    def protect(cls, crew: Any, **kwargs: Any) -> Any:
        """
        Wrap all agents in a Crew with Sentinel security scanning.

        Installs ``step_callback`` and ``task_callback`` on each agent
        in ``crew.agents``.

        Args:
            crew: A ``crewai.Crew`` instance.
            **kwargs: Forwarded to ``SentinelCrewAI`` constructor.

        Returns:
            The same crew instance (mutated in place) for chaining.
        """
        adapter = cls(**kwargs)
        agents = getattr(crew, "agents", None) or []
        for agent in agents:
            adapter._wrap_agent(agent)
        return crew

    @classmethod
    def protect_agent(cls, agent: Any, **kwargs: Any) -> Any:
        """
        Wrap a single CrewAI Agent with Sentinel security scanning.

        Args:
            agent: A ``crewai.Agent`` instance.
            **kwargs: Forwarded to ``SentinelCrewAI`` constructor.

        Returns:
            The same agent instance (mutated in place) for chaining.
        """
        adapter = cls(**kwargs)
        adapter._wrap_agent(agent)
        return agent

    # ------------------------------------------------------------------
    # Internal: wrapping
    # ------------------------------------------------------------------

    def _wrap_agent(self, agent: Any) -> None:
        """Install step_callback and task_callback on an agent."""
        original_step_cb = getattr(agent, "step_callback", None)
        original_task_cb = getattr(agent, "task_callback", None)

        def step_callback(step_output: Any) -> Any:
            """Sentinel step_callback: scans agent step output."""
            try:
                content = self._extract_step_content(step_output)
                if content:
                    self._scan_with_dedup(
                        content, source=_SOURCE_STEP, hook_point=_SOURCE_STEP
                    )
            except SentinelBlockedError:
                raise
            except Exception:
                logger.exception("sentinel.crewai: step_callback error, failing open")
            if original_step_cb is not None:
                return original_step_cb(step_output)
            return None

        def task_callback(task_output: Any) -> Any:
            """Sentinel task_callback: scans inter-agent task output."""
            try:
                content = self._extract_task_content(task_output)
                if content:
                    self._scan_with_dedup(
                        content, source=_SOURCE_TASK, hook_point=_SOURCE_TASK
                    )
            except SentinelBlockedError:
                raise
            except Exception:
                logger.exception("sentinel.crewai: task_callback error, failing open")
            if original_task_cb is not None:
                return original_task_cb(task_output)
            return None

        agent.step_callback = step_callback
        agent.task_callback = task_callback

    # ------------------------------------------------------------------
    # Internal: scanning with dedup
    # ------------------------------------------------------------------

    def _scan_with_dedup(
        self, content: str, *, source: str, hook_point: str
    ) -> Optional[ScanResult]:
        """Scan content, returning cached result if already scanned."""
        content_h = _content_hash(content)
        if content_h in self._scan_cache:
            logger.debug(
                "Sentinel dedup: returning cached result for content hash %s",
                content_h[:12],
            )
            cached = self._scan_cache[content_h]
            if cached.action_taken == "block":
                raise SentinelBlockedError(cached)
            return cached

        ctx = ScanContext(framework="crewai", hook_point=hook_point)
        result = self.engine.scan_output(content, source=source, context=ctx)
        self._scan_cache[content_h] = result

        if result.action_taken == "block":
            raise SentinelBlockedError(result)

        return result

    # ------------------------------------------------------------------
    # Internal: content extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_step_content(step_output: Any) -> str:
        """Extract text content from a CrewAI agent step output."""
        # CrewAI AgentAction / step output can have various shapes
        if isinstance(step_output, str):
            return step_output
        # AgentAction-like object with .text or .output
        text = getattr(step_output, "text", None)
        if isinstance(text, str) and text:
            return text
        output = getattr(step_output, "output", None)
        if isinstance(output, str) and output:
            return output
        # Try .result for newer CrewAI versions
        result = getattr(step_output, "result", None)
        if isinstance(result, str) and result:
            return result
        return ""

    @staticmethod
    def _extract_task_content(task_output: Any) -> str:
        """Extract text content from a CrewAI task output."""
        if isinstance(task_output, str):
            return task_output
        # TaskOutput has .raw, .description, .summary
        raw = getattr(task_output, "raw", None)
        if isinstance(raw, str) and raw:
            return raw
        output = getattr(task_output, "output", None)
        if isinstance(output, str) and output:
            return output
        description = getattr(task_output, "description", None)
        if isinstance(description, str) and description:
            return description
        return ""

    def clear_dedup_cache(self) -> None:
        """Clear the dedup cache. Useful between sessions."""
        self._scan_cache.clear()
