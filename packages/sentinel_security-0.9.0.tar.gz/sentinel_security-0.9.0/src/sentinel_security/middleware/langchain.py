"""
LangChain AgentMiddleware adapter for Sentinel security scanning.

Requires: langchain >= 1.0.0 (for AgentMiddleware API)
Install:  pip install sentinel-security[langchain]

Usage:
    from sentinel_security.middleware import SentinelMiddleware

    agent = create_agent(
        model=ChatOpenAI(),
        tools=[...],
        middleware=[SentinelMiddleware()],
    )
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

try:
    from langchain.agents.middleware.types import AgentMiddleware
except ImportError:
    raise ImportError(
        "SentinelMiddleware requires langchain >= 1.0.0. "
        "Install with: pip install sentinel-security[langchain]"
    )

from sentinel_security.middleware._types import (
    ScanContext,
    ScanResult,
    SentinelBlockedError,
)
from sentinel_security.middleware.engine import DetectionEngine
from sentinel_security.middleware._utils import extract_message_content as _extract_content

logger = logging.getLogger("sentinel_security.middleware.langchain")

# Source tags used in ScanContext for audit trail
_SOURCE_INPUT = "langchain-input"
_SOURCE_RESPONSE = "langchain-response"


class SentinelMiddleware(AgentMiddleware):
    """
    Runtime security middleware for LangChain agents.

    Scans input messages (before_model) and LLM responses (after_model)
    using the DetectionEngine. Configurable via constructor kwargs or
    global ``sentinel_security.configure()``.

    Blocking behaviour:
        Raises ``SentinelBlockedError`` when policy="block" and risk
        exceeds threshold. Catch this exception in the calling code to
        handle blocked content gracefully.

    Args:
        policy: Detection policy -- "log", "warn", or "block".
        risk_threshold: Risk score (0-10) above which the policy action fires.
        event_handler: Optional callback receiving ``ScanEvent`` instances.
        **engine_kwargs: Additional kwargs forwarded to ``DetectionEngine``.
    """

    def __init__(
        self,
        *,
        policy: Optional[str] = None,
        risk_threshold: Optional[int] = None,
        event_handler: Optional[Callable[..., Any]] = None,
        **engine_kwargs: Any,
    ) -> None:
        config: Dict[str, Any] = {}
        if policy is not None:
            config["policy"] = policy
        if risk_threshold is not None:
            config["risk_threshold"] = risk_threshold
        if event_handler is not None:
            config["event_handler"] = event_handler
        config.update(engine_kwargs)

        self.engine = DetectionEngine(config if config else None)

    # ------------------------------------------------------------------
    # AgentMiddleware hooks
    # ------------------------------------------------------------------

    def before_model(self, state: Any, runtime: Any) -> Optional[Dict[str, Any]]:
        """Scan input messages before they reach the LLM."""
        try:
            messages = getattr(state, "messages", None)
            if messages is None:
                return None

            msg_dicts = _extract_messages(messages)
            if not msg_dicts:
                return None

            ctx = ScanContext(framework="langchain", hook_point=_SOURCE_INPUT)
            result = self.engine.scan_input(msg_dicts, context=ctx)

            if result.action_taken == "block":
                raise SentinelBlockedError(result)
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.langchain: before_model error, failing open")

        return None

    def after_model(self, state: Any, runtime: Any) -> Optional[Dict[str, Any]]:
        """Scan LLM response (and any tool output) after the model call."""
        try:
            messages = getattr(state, "messages", None)
            if not messages:
                return None

            last_msg = messages[-1]
            content = _extract_content(last_msg)
            if not content:
                return None

            ctx = ScanContext(framework="langchain", hook_point=_SOURCE_RESPONSE)
            result = self.engine.scan_output(
                content, source=_SOURCE_RESPONSE, context=ctx
            )

            if result.action_taken == "block":
                raise SentinelBlockedError(result)
        except SentinelBlockedError:
            raise
        except Exception:
            logger.exception("sentinel.langchain: after_model error, failing open")

        return None


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _extract_messages(messages: Any) -> list:
    """Convert LangChain message objects to dicts for the engine."""
    result = []
    for msg in messages:
        content = _extract_content(msg)
        if content:
            role = getattr(msg, "type", "unknown")
            result.append({"role": role, "content": content})
    return result



# _extract_content imported from sentinel_security.middleware._utils
