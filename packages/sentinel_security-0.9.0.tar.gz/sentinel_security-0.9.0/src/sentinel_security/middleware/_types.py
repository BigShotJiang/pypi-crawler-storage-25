"""
Shared data types for Sentinel middleware.

All types are frozen dataclasses for thread-safety and immutability.
SOC2 CRITICAL: ScanEvent MUST NOT contain content by default.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass(frozen=True)
class ScanResult:
    """Immutable result of a single scan operation."""

    scan_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    risk_level: str = "CLEAN"
    risk_score: int = 0
    threats: List[Dict[str, Any]] = field(default_factory=list)
    clean_text: str = ""
    action_taken: str = "allow"  # "allow" | "flag" | "block"
    scan_duration_ms: float = 0.0
    source: str = ""
    content_length: int = 0
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc)
        .isoformat()
        .replace("+00:00", "Z")
    )

    def to_dict(self, include_content: bool = False) -> Dict[str, Any]:
        """Serialise to dict for SIEM export.

        Excludes clean_text by default to prevent content leakage (SOC2).
        Pass include_content=True to include it explicitly.
        """
        d = asdict(self)
        if not include_content:
            d.pop("clean_text", None)
        return d


@dataclass(frozen=True)
class ScanContext:
    """Optional correlation context passed by adapters."""

    framework: str = ""
    hook_point: str = ""
    agent_id: Optional[str] = None
    session_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ScanEvent:
    """
    Structured audit event emitted for every scan.

    SOC2 CRITICAL: This is the audit trail record.
    - MUST contain: who (framework + source), what (action + risk), when (timestamp)
    - MUST NOT contain: actual message content (unless log_content=True)
    """

    scan_id: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc)
        .isoformat()
        .replace("+00:00", "Z")
    )
    event_type: str = "scan_complete"  # "scan_complete" | "threat_detected" | "blocked"
    framework: str = ""
    source: str = ""
    risk_score: int = 0
    risk_level: str = "CLEAN"
    threats: List[Dict[str, str]] = field(default_factory=list)
    action: str = "allow"  # "allow" | "flag" | "block"
    scan_duration_ms: float = 0.0
    content_length: int = 0
    policy_applied: str = "warn"
    risk_threshold_applied: int = 5
    engine_version: int = 1
    content: Optional[str] = None  # ONLY populated if log_content=True

    def to_dict(self) -> Dict[str, Any]:
        """Serialise to dict for SIEM export."""
        return asdict(self)


class SentinelBlockedError(Exception):
    """Raised when policy is 'block' and risk exceeds threshold."""

    def __init__(self, result: ScanResult):
        self.result = result
        super().__init__(
            f"Sentinel blocked content: {result.risk_level} risk "
            f"(score {result.risk_score}, threshold exceeded). "
            f"Scan ID: {result.scan_id}"
        )
