"""
LangChain BaseCallbackHandler adapter for Sentinel security scanning.

For legacy LangChain (< 1.0), LangGraph create_react_agent, and raw
BaseChatModel users. Observation-only: logs and emits events but cannot
block requests (use SentinelMiddleware for blocking).

Requires: langchain-core >= 0.3.0
Install:  pip install sentinel-security[langchain]

Usage:
    from sentinel_security.middleware import SentinelCallbackHandler

    # With create_react_agent:
    agent.invoke(
        {"messages": [...]},
        config={"callbacks": [SentinelCallbackHandler()]},
    )

    # With raw BaseChatModel:
    model = ChatOpenAI(callbacks=[SentinelCallbackHandler()])
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional, Sequence, Union
from uuid import UUID

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
except ImportError:
    raise ImportError(
        "SentinelCallbackHandler requires langchain-core >= 0.3.0. "
        "Install with: pip install sentinel-security[langchain]"
    )

from sentinel_security.middleware._types import (
    ScanContext,
    ScanResult,
    SentinelBlockedError,
)
from sentinel_security.middleware.engine import DetectionEngine
from sentinel_security.middleware._utils import extract_message_content as _extract_content

logger = logging.getLogger("sentinel_security.middleware.langchain_callback")

_SOURCE_INPUT = "langchain-input"
_SOURCE_RESPONSE = "langchain-response"
_SOURCE_TOOL = "langchain-tool"


class SentinelCallbackHandler(BaseCallbackHandler):
    """
    Observational security callback for LangChain.

    Scans LLM inputs, outputs, and tool results via the DetectionEngine.
    Cannot block -- use ``SentinelMiddleware`` with ``create_agent()``
    for blocking support.

    Blocking behaviour:
        Observation-only. Logs threats at ERROR level but does **not**
        raise exceptions or block content. Use ``SentinelMiddleware``
        for blocking support.

    Args:
        policy: Detection policy -- "log", "warn", or "block".
        risk_threshold: Risk score (0-10) above which the policy action fires.
        event_handler: Optional callback receiving ``ScanEvent`` instances.
        **engine_kwargs: Additional kwargs forwarded to ``DetectionEngine``.
    """

    def __init__(
        self,
        *,
        policy: Optional[str] = None,
        risk_threshold: Optional[int] = None,
        event_handler: Optional[Callable[..., Any]] = None,
        **engine_kwargs: Any,
    ) -> None:
        config: Dict[str, Any] = {}
        if policy is not None:
            config["policy"] = policy
        if risk_threshold is not None:
            config["risk_threshold"] = risk_threshold
        if event_handler is not None:
            config["event_handler"] = event_handler
        config.update(engine_kwargs)

        self.engine = DetectionEngine(config if config else None)
        self.last_result: Optional[ScanResult] = None

    # ------------------------------------------------------------------
    # LLM hooks
    # ------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Scan string prompts sent to a non-chat LLM."""
        try:
            text = "\n".join(prompts)
            ctx = ScanContext(framework="langchain", hook_point=_SOURCE_INPUT)
            self.last_result = self.engine.scan_output(
                text, source=_SOURCE_INPUT, context=ctx
            )
        except Exception:
            logger.exception("sentinel.langchain_callback: on_llm_start error, failing open")

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Scan chat messages sent to the model."""
        try:
            for batch in messages:
                msg_dicts = []
                if isinstance(batch, list):
                    for msg in batch:
                        content = _extract_content(msg)
                        if content:
                            role = getattr(msg, "type", "unknown")
                            msg_dicts.append({"role": role, "content": content})
                if msg_dicts:
                    ctx = ScanContext(
                        framework="langchain", hook_point=_SOURCE_INPUT
                    )
                    self.last_result = self.engine.scan_input(
                        msg_dicts, context=ctx
                    )
        except Exception:
            logger.exception("sentinel.langchain_callback: on_chat_model_start error, failing open")

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Scan LLM response generations."""
        try:
            for gen_list in response.generations:
                for gen in gen_list:
                    text = ""
                    if getattr(gen, "message", None) is not None:
                        text = _extract_content(gen.message)
                    elif getattr(gen, "text", None):
                        text = gen.text
                    if text:
                        ctx = ScanContext(
                            framework="langchain", hook_point=_SOURCE_RESPONSE
                        )
                        self.last_result = self.engine.scan_output(
                            text, source=_SOURCE_RESPONSE, context=ctx
                        )
        except Exception:
            logger.exception("sentinel.langchain_callback: on_llm_end error, failing open")

    # ------------------------------------------------------------------
    # Tool hooks
    # ------------------------------------------------------------------

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Scan tool output for injection and exfiltration."""
        try:
            text = str(output) if output is not None else ""
            if text:
                ctx = ScanContext(framework="langchain", hook_point=_SOURCE_TOOL)
                self.last_result = self.engine.scan_output(
                    text, source=_SOURCE_TOOL, context=ctx
                )
        except Exception:
            logger.exception("sentinel.langchain_callback: on_tool_end error, failing open")



# _extract_content imported from sentinel_security.middleware._utils
