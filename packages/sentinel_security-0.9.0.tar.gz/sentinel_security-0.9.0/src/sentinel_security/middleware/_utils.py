"""Shared utility functions for Sentinel middleware adapters."""

from __future__ import annotations

import hashlib
from typing import Any


def content_hash(text: str) -> str:
    """SHA-256 hash of text content for dedup purposes."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def extract_message_content(msg: Any) -> str:
    """Pull string content from a LangChain message.

    Handles plain string content and multi-part messages (list of str/dict).
    """
    content = getattr(msg, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for part in content:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict) and part.get("type") == "text":
                parts.append(part.get("text", ""))
        return "\n".join(parts)
    return ""
