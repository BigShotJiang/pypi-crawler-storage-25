"""
Sanitiser package.

Re-exports the full public API so existing imports continue to work.
"""

from .core import sanitise_content, sanitise
from .scorer import calculate_risk_score, risk_level
from .detectors import (
    detect_injection_patterns,
    detect_invisible_chars,
    detect_base64_blocks,
    detect_rtl_override,
    detect_homoglyphs,
    detect_repo_metadata_injection,
    detect_css_class_hiding,
    detect_html_attributes,
    detect_markdown_injection,
    detect_hidden_html,
    normalise_unicode,
    # Batch 3
    detect_shell_injection,
    detect_diagram_exfil,
    detect_dns_exfil,
    detect_cicd_injection,
    detect_system_prompt_extraction,
)
from .transformers import strip_invisible_chars, strip_html_tags

__all__ = [
    'sanitise_content',
    'sanitise',
    'calculate_risk_score', 'risk_level',
    'detect_injection_patterns',
    'detect_invisible_chars',
    'detect_base64_blocks',
    'detect_rtl_override',
    'detect_homoglyphs',
    'detect_repo_metadata_injection',
    'detect_css_class_hiding',
    'detect_html_attributes',
    'detect_markdown_injection',
    'detect_hidden_html',
    'normalise_unicode',
    'strip_invisible_chars',
    'strip_html_tags',
    # Batch 3
    'detect_shell_injection',
    'detect_diagram_exfil',
    'detect_dns_exfil',
    'detect_cicd_injection',
    'detect_system_prompt_extraction',
]
