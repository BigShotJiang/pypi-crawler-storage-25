"""Main sanitisation pipeline."""

import logging

from ..patterns import RTL_OVERRIDE_CHARS
from ..rules_loader import _use_encrypted_rules, is_degraded

logger = logging.getLogger(__name__)
from .detectors import (
    detect_base64_blocks,
    detect_hidden_html,
    detect_homoglyphs,
    detect_html_attributes,
    detect_injection_patterns,
    detect_invisible_chars,
    detect_markdown_injection,
    detect_repo_metadata_injection,
    detect_rtl_override,
    # Batch 2
    detect_authority_escalation,
    detect_base64_injection,
    detect_context_invalidation,
    detect_external_authority,
    detect_fake_protocol,
    detect_fake_system_delimiters,
    detect_image_exfil,
    detect_markdown_exfil,
    detect_meta_instruction,
    detect_persona_constraint_removal,
    detect_prompt_extraction,
    detect_url_data_smuggling,
    detect_url_execution_directive,
    # Batch 3
    detect_shell_injection,
    detect_diagram_exfil,
    detect_dns_exfil,
    detect_cicd_injection,
    detect_system_prompt_extraction,
)
from .code_detectors import run_code_detectors
from .proximity import detect_proximity_injection
from .scorer import calculate_risk_score, risk_level
from .transformers import strip_html_tags, strip_invisible_chars


def sanitise_content(content: str, format: str = 'text') -> dict:
    """
    Main sanitisation pipeline.

    Scans content for prompt injection patterns, hidden text, invisible
    characters, and other attack vectors. Returns clean text plus a
    structured threat report.

    Args:
        content: The text or HTML content to sanitise.
        format: 'text', 'html', or 'markdown'. HTML mode additionally checks for
                hidden elements, comments, and CSS-based hiding. Markdown mode
                checks for markdown-specific injection patterns.

    Returns:
        dict with keys:
            clean_text (str): Sanitised content with dangerous chars removed.
            threats (list): Detected threats with type, position, context.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
    """
    if not isinstance(content, str):
        raise TypeError(f"content must be a string, got {type(content).__name__}")

    # When encrypted rules are active and the loader is degraded (offline, no
    # licence, etc.), return a safe default instead of crashing.
    if _use_encrypted_rules() and is_degraded():
        logger.warning("sanitise_content: degraded mode — returning safe default")
        return {
            'clean_text': content,
            'threats': [],
            'threat_count': 0,
            'risk_score': 0,
            'risk_level': 'UNKNOWN',
            'degraded': True,
            'degraded_reason': 'rules_unavailable',
        }

    logger.debug("sanitise_content: start format=%s len=%d", format, len(content))
    threats = []

    threats.extend(detect_invisible_chars(content))
    threats.extend(detect_injection_patterns(content))
    # Proximity-based filler word detection (dedup against regex matches)
    regex_matched_texts = {t['matched'] for t in threats if t.get('type') == 'injection_pattern'}
    for pt in detect_proximity_injection(content):
        if pt['matched'] not in regex_matched_texts:
            threats.append(pt)
    threats.extend(detect_base64_blocks(content))
    threats.extend(detect_rtl_override(content))
    threats.extend(detect_homoglyphs(content))
    threats.extend(detect_repo_metadata_injection(content))

    # Always check for markdown injection patterns
    threats.extend(detect_markdown_injection(content))

    # Batch 2: Structural and contextual detection
    threats.extend(detect_context_invalidation(content))
    threats.extend(detect_meta_instruction(content))
    threats.extend(detect_url_execution_directive(content))
    threats.extend(detect_external_authority(content))
    threats.extend(detect_authority_escalation(content))
    threats.extend(detect_fake_protocol(content))
    threats.extend(detect_persona_constraint_removal(content))
    threats.extend(detect_markdown_exfil(content))
    threats.extend(detect_image_exfil(content))
    threats.extend(detect_url_data_smuggling(content))
    threats.extend(detect_fake_system_delimiters(content))
    threats.extend(detect_base64_injection(content))
    threats.extend(detect_prompt_extraction(content))

    # Batch 3: Advanced threat detection
    threats.extend(detect_shell_injection(content))
    threats.extend(detect_diagram_exfil(content))
    threats.extend(detect_dns_exfil(content))
    threats.extend(detect_cicd_injection(content))
    threats.extend(detect_system_prompt_extraction(content))

    # Batch 4: Code-level behavioural detection (autoresearch merge)
    threats.extend(run_code_detectors(content))

    if format in ('html', 'markdown'):
        threats.extend(detect_hidden_html(content))
        threats.extend(detect_html_attributes(content))

    if format == 'html':
        clean = strip_html_tags(content)
    else:
        clean = content

    clean = strip_invisible_chars(clean)
    for char in RTL_OVERRIDE_CHARS:
        clean = clean.replace(char, '')

    # Re-scan clean text for injection patterns that were hidden by
    # invisible characters or RTL overrides. Only add genuinely new
    # findings (compare matched text to avoid duplicates).
    existing_matches = {t['matched'] for t in threats if t.get('type') in ('injection_pattern',) and t.get('matched')}
    post_strip_threats = detect_injection_patterns(clean)
    for t in post_strip_threats:
        if t['matched'] not in existing_matches:
            t['type'] = 'post_strip_injection'
            threats.append(t)

    logger.debug("sanitise_content: end threats=%d", len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("sanitise_content: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_risk_score(threats, content)

    return {
        'clean_text': clean,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }


# Alias for convenience
sanitise = sanitise_content
