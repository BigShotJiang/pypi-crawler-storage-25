"""Text transformation utilities -- stripping invisible chars and HTML tags."""

import re

from ..patterns import INVISIBLE_CHARS, RTL_OVERRIDE_CHARS


def strip_invisible_chars(text: str) -> str:
    """Remove invisible Unicode characters."""
    for char in INVISIBLE_CHARS:
        text = text.replace(char, '')
    return text


def strip_html_tags(html: str) -> str:
    """Strip HTML tags, scripts, and styles. Returns plain text."""
    text = re.sub(r'<script[^>]*>[\s\S]*?</script>', '', html, flags=re.IGNORECASE)
    text = re.sub(r'<style[^>]*>[\s\S]*?</style>', '', text, flags=re.IGNORECASE)
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text
