"""Detection functions for prompt injection and related threats."""

import base64
import html
import re
import unicodedata
from typing import List
from urllib.parse import parse_qs, urlparse

from ..patterns import (
    HIDDEN_HTML_PATTERNS,
    INJECTION_PATTERNS,
    INVISIBLE_CHARS,
    RTL_OVERRIDE_CHARS,
)
from ..rules_loader import get_detector_patterns


def normalise_unicode(text: str) -> str:
    """Normalise Unicode and case folding to catch fullwidth and Turkish i variants."""
    return unicodedata.normalize('NFKC', text).casefold()


# Leetspeak transliteration map: digit/symbol -> most common alpha equivalent
_LEET_MAP = str.maketrans({
    '0': 'o',
    '1': 'i',
    '3': 'e',
    '4': 'a',
    '5': 's',
    '7': 't',
    '@': 'a',
})


def transliterate_leetspeak(text: str) -> str:
    """Transliterate common leetspeak substitutions to ASCII letters.

    Only applied as an additional detection pass -- the original text
    is preserved for all other processing.
    """
    return text.translate(_LEET_MAP)


def detect_invisible_chars(text: str) -> list:
    """Find invisible Unicode characters and their positions."""
    threats = []
    for i, char in enumerate(text):
        if char in INVISIBLE_CHARS:
            start = max(0, i - 20)
            end = min(len(text), i + 20)
            threats.append({
                'type': 'invisible_unicode',
                'char': INVISIBLE_CHARS[char],
                'codepoint': f'U+{ord(char):04X}',
                'position': i,
                'context': repr(text[start:end]),
                'matched_text': INVISIBLE_CHARS[char],
            })
    return threats


def detect_injection_patterns(text: str) -> list:
    """Find injection trigger phrases."""
    threats = []
    normalised_text = normalise_unicode(text)

    seen_patterns = set()
    for pattern in INJECTION_PATTERNS:
        for match in re.finditer(pattern, normalised_text, re.IGNORECASE):
            start = max(0, match.start() - 30)
            end = min(len(text), match.end() + 30)
            threats.append({
                'type': 'injection_pattern',
                'pattern': pattern,
                'matched': match.group(),
                'matched_text': match.group(),
                'context': text[start:end],
                'position': match.start(),
            })
            seen_patterns.add(pattern)

    # Second pass: leetspeak transliteration
    leet_text = transliterate_leetspeak(normalised_text)
    if leet_text != normalised_text:
        for pattern in INJECTION_PATTERNS:
            if pattern in seen_patterns:
                continue  # Already matched on normal text
            for match in re.finditer(pattern, leet_text, re.IGNORECASE):
                start = max(0, match.start() - 30)
                end = min(len(text), match.end() + 30)
                threats.append({
                    'type': 'injection_pattern',
                    'pattern': pattern,
                    'matched': match.group(),
                    'matched_text': match.group(),
                    'context': text[start:end],
                    'position': match.start(),
                })
                break  # One match per pattern is enough

    return threats


def detect_base64_blocks(text: str) -> list:
    """Find suspicious base64-encoded blocks (20+ chars) and URL-sharded base64."""
    threats = []
    for match in re.finditer(r'[A-Za-z0-9+/]{20,}={0,2}', text):
        threats.append({
            'type': 'base64_block',
            'length': len(match.group()),
            'position': match.start(),
            'preview': match.group()[:60] + '...',
            'matched_text': match.group()[:60],
            'context': text[max(0, match.start()-20):match.end()+20][:100],
        })

    # Detect multiple URLs carrying base64-encoded query parameter values
    # (shard exfiltration pattern: data split across multiple requests)
    b64_url_params = re.findall(
        r'https?://\S+[?&]\w*=[A-Za-z0-9+/]{4,}={0,2}(?:\s|$)', text
    )
    if len(b64_url_params) >= 3:
        threats.append({
            'type': 'base64_block',
            'length': sum(len(u) for u in b64_url_params),
            'position': text.find(b64_url_params[0]),
            'preview': f'{len(b64_url_params)} URLs with base64 query params',
            'matched_text': f'{len(b64_url_params)} URLs with base64 query params',
            'context': b64_url_params[0][:100] if b64_url_params else '',
        })
        threats.append({
            'type': 'base64_shard_exfil',
            'length': len(b64_url_params),
            'position': text.find(b64_url_params[0]),
            'preview': f'Shard exfiltration: {len(b64_url_params)} URLs',
            'matched_text': f'Shard exfiltration: {len(b64_url_params)} URLs',
            'context': b64_url_params[0][:100] if b64_url_params else '',
        })

    return threats


def detect_rtl_override(text: str) -> list:
    """Detect RTL override attacks that visually reorder text."""
    threats = []
    for i, char in enumerate(text):
        if char in RTL_OVERRIDE_CHARS:
            threats.append({
                'type': 'rtl_override',
                'char': RTL_OVERRIDE_CHARS[char],
                'codepoint': f'U+{ord(char):04X}',
                'position': i,
                'matched_text': RTL_OVERRIDE_CHARS[char],
                'context': repr(text[max(0, i-20):min(len(text), i+20)]),
            })
    return threats


def detect_homoglyphs(text: str) -> list:
    """Detect mixed-script words (potential homoglyph attacks)."""
    threats = []
    words = re.findall(r'\S+', text)
    for word in words:
        scripts = set()
        for char in word:
            if char.isalpha():
                try:
                    script = unicodedata.name(char, '').split()[0]
                    scripts.add(script)
                except (ValueError, IndexError):
                    pass
        if len(scripts) > 1 and 'LATIN' in scripts:
            threats.append({
                'type': 'homoglyph',
                'word': word,
                'scripts': list(scripts),
                'position': text.find(word),
                'matched_text': word,
                'context': word,
            })
    return threats


def detect_repo_metadata_injection(text: str) -> list:
    """Detect injection patterns in repository metadata (issues, PRs, commits)."""
    threats = []
    for match in re.finditer(r'<!--[\s\S]*?-->', text):
        comment_text = match.group()[4:-3].strip()
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, comment_text, re.IGNORECASE):
                threats.append({
                    'type': 'repo_metadata_injection',
                    'mechanism': 'HTML comment with injection pattern',
                    'hidden_text': comment_text[:200],
                    'position': match.start(),
                    'matched_text': comment_text[:200],
                    'context': match.group()[:100],
                })
                break
    for match in re.finditer(r'"\$(?:ref|id)"\s*:\s*"(https?://[^"]+)"', text):
        threats.append({
            'type': 'repo_metadata_injection',
            'mechanism': 'JSON schema external reference',
            'url': match.group(1)[:200],
            'position': match.start(),
            'matched_text': match.group(1)[:200],
            'context': match.group()[:100],
        })
    return threats


def detect_css_class_hiding(html_content: str) -> list:
    """Detect CSS class-based hiding attacks."""
    threats = []

    style_pattern = r'<style[^>]*>(.*?)</style>'
    for match in re.finditer(style_pattern, html_content, re.IGNORECASE | re.DOTALL):
        css_content = match.group(1)

        hiding_patterns = [
            r'display\s*:\s*none',
            r'visibility\s*:\s*hidden',
            r'font-size\s*:\s*0',
            r'opacity\s*:\s*0',
            r'height\s*:\s*0',
            r'width\s*:\s*0',
            r'position\s*:\s*absolute.*?(?:left|top)\s*:\s*-\d+'
        ]

        for hiding_pattern in hiding_patterns:
            if re.search(hiding_pattern, css_content, re.IGNORECASE):
                threats.append({
                    'type': 'css_class_hiding',
                    'mechanism': f'CSS hiding rule: {hiding_pattern}',
                    'position': match.start(),
                    'css_content': css_content[:200],
                    'matched_text': css_content[:60],
                    'context': css_content[:100],
                })
                break

    return threats


def detect_html_attributes(html_content: str) -> list:
    """Extract and scan text from HTML attributes."""
    threats = []

    attribute_patterns = [
        r'alt\s*=\s*["\']([^"\']*)["\']',
        r'title\s*=\s*["\']([^"\']*)["\']',
        r'aria-label\s*=\s*["\']([^"\']*)["\']',
        r'aria-description\s*=\s*["\']([^"\']*)["\']'
    ]

    for pattern in attribute_patterns:
        for match in re.finditer(pattern, html_content, re.IGNORECASE):
            attr_text = match.group(1)
            normalised_text = normalise_unicode(attr_text)
            for injection_pattern in INJECTION_PATTERNS:
                if re.search(injection_pattern, normalised_text, re.IGNORECASE):
                    threats.append({
                        'type': 'attribute_injection',
                        'mechanism': f'HTML attribute injection: {match.group().split("=")[0]}',
                        'hidden_text': attr_text[:200],
                        'position': match.start(),
                        'matched_text': attr_text[:200],
                        'context': match.group()[:100],
                    })
                    break

    return threats


def detect_markdown_injection(text: str) -> list:
    """Detect markdown-specific injection patterns."""
    threats = []

    decoded_text = html.unescape(text)

    normalised_decoded = normalise_unicode(decoded_text)
    if decoded_text != text:
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, normalised_decoded, re.IGNORECASE):
                threats.append({
                    'type': 'markdown_injection',
                    'mechanism': 'HTML entity encoded injection',
                    'hidden_text': decoded_text[:200],
                    'position': 0,
                    'matched_text': decoded_text[:200],
                    'context': text[:100],
                })
                break

    ref_link_pattern = r'\[([^\]]+)\]:\s*[^\s]+\s*"([^"]*)"'
    for match in re.finditer(ref_link_pattern, text, re.MULTILINE):
        title = match.group(2)
        normalised_title = normalise_unicode(html.unescape(title))
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, normalised_title, re.IGNORECASE):
                threats.append({
                    'type': 'markdown_injection',
                    'mechanism': 'Reference link title injection',
                    'hidden_text': title[:200],
                    'position': match.start(),
                    'matched_text': title[:200],
                    'context': match.group()[:100],
                })
                break

    link_title_pattern = r'\[([^\]]*)\]\([^)]*\s+"([^"]*)"\)'
    for match in re.finditer(link_title_pattern, text):
        title = match.group(2)
        normalised_title = normalise_unicode(html.unescape(title))
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, normalised_title, re.IGNORECASE):
                threats.append({
                    'type': 'markdown_injection',
                    'mechanism': 'Link title injection',
                    'hidden_text': title[:200],
                    'position': match.start(),
                    'matched_text': title[:200],
                    'context': match.group()[:100],
                })
                break

    img_alt_pattern = r'!\[([^\]]*)\]\([^)]+\)'
    for match in re.finditer(img_alt_pattern, text):
        alt_text = match.group(1)
        normalised_alt = normalise_unicode(html.unescape(alt_text))
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, normalised_alt, re.IGNORECASE):
                threats.append({
                    'type': 'markdown_injection',
                    'mechanism': 'Image alt text injection',
                    'hidden_text': alt_text[:200],
                    'position': match.start(),
                    'matched_text': alt_text[:200],
                    'context': match.group()[:100],
                })
                break

    return threats


def detect_hidden_html(html_content: str) -> list:
    """Find hidden HTML content."""
    threats = []
    for pattern, description in HIDDEN_HTML_PATTERNS:
        for match in re.finditer(pattern, html_content, re.IGNORECASE):
            content = match.group()
            if description == 'HTML comment':
                text_content = re.sub(r'^<!--\s*', '', content)
                text_content = re.sub(r'\s*-->$', '', text_content).strip()
            else:
                text_content = re.sub(r'<[^>]+>', '', content).strip()
            if text_content:
                threats.append({
                    'type': 'hidden_html',
                    'mechanism': description,
                    'hidden_text': text_content[:200],
                    'position': match.start(),
                    'matched_text': text_content[:200],
                    'context': html_content[max(0, match.start()-20):match.end()+20][:100],
                })

    threats.extend(detect_css_class_hiding(html_content))

    return threats


# ---------------------------------------------------------------------------
# Batch 2: Structural & Contextual Detection Rules
# ---------------------------------------------------------------------------

def _proximity_check(text: str, pattern_a: str, pattern_b: str, max_distance: int) -> list:
    """Find co-occurrences of two regex patterns within *max_distance* chars.

    Returns a list of (match_a, match_b) tuples for every qualifying pair.
    """
    results: list = []
    matches_a = list(re.finditer(pattern_a, text, re.IGNORECASE))
    matches_b = list(re.finditer(pattern_b, text, re.IGNORECASE))
    for ma in matches_a:
        for mb in matches_b:
            dist = min(
                abs(ma.start() - mb.end()),
                abs(mb.start() - ma.end()),
            )
            if dist <= max_distance:
                results.append((ma, mb))
    return results


def _make_threat(rule: str, ma, mb, text: str, ttype: str = 'structural_injection') -> dict:
    start = min(ma.start(), mb.start())
    end = max(ma.end(), mb.end())
    matched = text[start:end]
    ctx_start = max(0, start - 30)
    ctx_end = min(len(text), end + 30)
    return {
        'type': ttype,
        'pattern': rule,
        'matched': matched[:200],
        'matched_text': matched[:200],
        'context': text[ctx_start:ctx_end][:200],
        'position': start,
    }


# Group A: Proximity-based

def detect_context_invalidation(text: str) -> list:
    """Detect two-phase direct override: invalidation phrase + instruction verb within 200 chars."""
    pa = r'(?:disregard|ignore|forget|start over|preceding .* is just)'
    pb = r'(?:your new task|help me write|generate|list all|output the)'
    return [_make_threat('context_invalidation_then_instruction', ma, mb, text)
            for ma, mb in _proximity_check(text, pa, pb, 200)]


def detect_meta_instruction(text: str) -> list:
    """Detect AI-addressing + context invalidation within 300 chars."""
    pa = r'(?:you (?:must|should|need to|are now)|your (?:new |real )?(?:task|instruction|role|purpose) is)'
    pb = r'(?:ignor|disregard|forget|overrid)'
    return [_make_threat('meta_instruction_to_ai', ma, mb, text)
            for ma, mb in _proximity_check(text, pa, pb, 300)]


def detect_url_execution_directive(text: str) -> list:
    """Detect URL + directive to follow its instructions within 500 chars."""
    pa = r'https?://\S+'
    pb = r'(?:follow|obey|execute|align with|comply with)\s+(?:the |its |their )?(?:instructions|directives|commands|guidelines)'
    return [_make_threat('url_with_execution_directive', ma, mb, text)
            for ma, mb in _proximity_check(text, pa, pb, 500)]


def detect_external_authority(text: str) -> list:
    """Detect authority claims about external content + execution language within 300 chars."""
    pa = r'(?:important update|latest (?:policy|guidelines|revision)|you must (?:review|read|check))'
    pb = r'(?:follow|obey|execute|comply|implement)\s+(?:the |its |their |these |all )?(?:instructions|directives|commands|guidelines|steps)'
    return [_make_threat('external_authority_escalation', ma, mb, text)
            for ma, mb in _proximity_check(text, pa, pb, 300)]


def detect_authority_escalation(text: str) -> list:
    """Detect authority claims + AI output manipulation."""
    pa = r'(?:supersede|override|replace)s?\s+(?:all )?(?:previous|prior|existing)\s+(?:guidelines|instructions|rules|directives)'
    pb = r'(?:output|print|return|reveal|display)\s+(?:the )?(?:user|system|secret|private|password|api.?key|prompt)'
    return [_make_threat('authority_escalation_targeting_ai', ma, mb, text)
            for ma, mb in _proximity_check(text, pa, pb, 300)]


def detect_fake_protocol(text: str) -> list:
    """Detect fake policy/protocol references + bypass instructions within 200 chars."""
    pa = r'(?:standard protocol|policy (?:revision|update)|section \d+[a-z]?)'
    pb = r'(?:bypass|skip|disable|ignore)\s+(?:authentication|security|checks|validation|filters|safeguards)'
    return [_make_threat('fake_protocol_bypass', ma, mb, text)
            for ma, mb in _proximity_check(text, pa, pb, 200)]


def detect_persona_constraint_removal(text: str) -> list:
    """Detect persona assignment + explicit constraint removal within 500 chars."""
    pa = r'(?:you are(?: now)?|adopt the persona|role.?play as|pretend (?:to be|you are)|act as|from now on.{0,20}you)'
    pb = r'(?:unrestricted|unfiltered|no (?:rules|limits|restrictions|filters|safeguards|guardrails)|without (?:regard|restriction|limit)|bypass (?:all )?(?:content )?filters)'
    return [_make_threat('persona_with_constraint_removal', ma, mb, text)
            for ma, mb in _proximity_check(text, pa, pb, 500)]


# Group B: Structural analysis

# Detector pattern data -- lazy-loaded from rule bundle on first use
_SAFE_IMAGE_DOMAINS = None  # lazy-loaded from rule bundle
_EXFIL_PARAM_NAMES = None   # lazy-loaded from rule bundle
_ENCODED_STRUCT = None       # lazy-loaded from rule bundle


def _ensure_loaded() -> None:
    """Load detector patterns from the rule bundle on first use."""
    global _SAFE_IMAGE_DOMAINS, _EXFIL_PARAM_NAMES, _ENCODED_STRUCT
    if _SAFE_IMAGE_DOMAINS is not None:
        return
    dp = get_detector_patterns()

    _SAFE_IMAGE_DOMAINS = set(dp.get('SAFE_IMAGE_DOMAINS', []))

    exfil_entry = dp.get('EXFIL_PARAM_NAMES', {})
    flags = re.IGNORECASE if 'IGNORECASE' in exfil_entry.get('flags', '') else 0
    _EXFIL_PARAM_NAMES = re.compile(exfil_entry['pattern'], flags)

    enc_entry = dp.get('ENCODED_STRUCT', {})
    enc_flags = re.IGNORECASE if 'IGNORECASE' in enc_entry.get('flags', '') else 0
    _ENCODED_STRUCT = re.compile(enc_entry['pattern'], enc_flags)


def detect_markdown_exfil(text: str) -> list:
    """Detect markdown links/images with suspicious query params."""
    _ensure_loaded()
    threats: list = []
    for match in re.finditer(r'!?\[([^\]]*)\]\(([^)]+)\)', text):
        url = match.group(2).split('"')[0].strip()
        try:
            parsed = urlparse(url)
        except Exception:
            continue
        if not parsed.query:
            continue
        params = parse_qs(parsed.query, keep_blank_values=True)
        for pname, pvals in params.items():
            flagged = False
            if _EXFIL_PARAM_NAMES.search(pname):
                flagged = True
            for v in pvals:
                if len(v) > 20 and re.fullmatch(r'[A-Za-z0-9+/=]+', v):
                    flagged = True
                if _ENCODED_STRUCT.search(v):
                    flagged = True
            if flagged:
                threats.append({
                    'type': 'markdown_exfil',
                    'pattern': 'markdown_exfil_links',
                    'matched': match.group()[:200],
                    'matched_text': match.group()[:200],
                    'context': text[max(0, match.start()-20):match.end()+20][:200],
                    'position': match.start(),
                })
                break
    return threats


def detect_image_exfil(text: str) -> list:
    """Detect markdown images to external domains with long query strings."""
    _ensure_loaded()
    threats: list = []
    for match in re.finditer(r'!\[[^\]]*\]\((https?://[^)]+)\)', text):
        url = match.group(1)
        try:
            parsed = urlparse(url)
        except Exception:
            continue
        domain = parsed.hostname or ''
        if domain in _SAFE_IMAGE_DOMAINS:
            continue
        if not parsed.query:
            continue
        params = parse_qs(parsed.query, keep_blank_values=True)
        if len(parsed.query) > 50 or len(params) >= 3:
            threats.append({
                'type': 'image_exfil',
                'pattern': 'auto_render_image_exfil',
                'matched': match.group()[:200],
                'matched_text': match.group()[:200],
                'context': text[max(0, match.start()-20):match.end()+20][:200],
                'position': match.start(),
            })
    return threats


def detect_url_data_smuggling(text: str) -> list:
    """Detect data exfil via query params on any URL (especially trusted domains)."""
    _ensure_loaded()
    threats: list = []
    _TRUSTED = {'google.com', 'anthropic.com', 'github.com', 'openai.com'}
    for match in re.finditer(r'https?://[^\s<>"\']+', text):
        url = match.group()
        try:
            parsed = urlparse(url)
        except Exception:
            continue
        if not parsed.query:
            continue
        params = parse_qs(parsed.query, keep_blank_values=True)
        domain = parsed.hostname or ''
        root_domain = '.'.join(domain.rsplit('.', 2)[-2:]) if '.' in domain else domain
        is_trusted = root_domain in _TRUSTED
        for pname, pvals in params.items():
            flagged = False
            if _EXFIL_PARAM_NAMES.search(pname):
                flagged = True
            for v in pvals:
                if len(v) > 100:
                    flagged = True
                if _ENCODED_STRUCT.search(v):
                    flagged = True
            if flagged:
                threats.append({
                    'type': 'url_data_smuggling',
                    'pattern': 'data_smuggling_in_url_params',
                    'matched': match.group()[:200],
                    'matched_text': match.group()[:200],
                    'context': text[max(0, match.start()-20):match.end()+20][:200],
                    'position': match.start(),
                    'trusted_domain': is_trusted,
                })
                break
    return threats


def detect_fake_system_delimiters(text: str) -> list:
    """Detect system message delimiter patterns in content."""
    threats: list = []
    patterns = [
        r'(?:---\s*)?(?:BEGIN|START|ENTER)\s+(?:SYSTEM|ADMIN|ROOT|INTERNAL|PRIORITY|CRITICAL)\s+(?:DIRECTIVE|MESSAGE|INSTRUCTION|UPDATE|CONFIG|OVERRIDE|COMMAND)(?:\s*---)?',
        r'\[\s*(?:SYSTEM|ADMIN|INTERNAL)\s+(?:CONFIG|MESSAGE|DIRECTIVE|UPDATE|OVERRIDE)\s*\]',
    ]
    for pat in patterns:
        for match in re.finditer(pat, text, re.IGNORECASE):
            threats.append({
                'type': 'fake_system_delimiter',
                'pattern': 'fake_system_delimiters',
                'matched': match.group()[:200],
                'matched_text': match.group()[:200],
                'context': text[max(0, match.start()-30):match.end()+30][:200],
                'position': match.start(),
            })
    return threats


# Group C: Decode and rescan

def detect_base64_injection(text: str) -> list:
    """Decode base64 blocks and scan decoded content for injection patterns."""
    threats: list = []
    for match in re.finditer(r'[A-Za-z0-9+/]{40,}={0,2}', text):
        raw = match.group()
        try:
            decoded = base64.b64decode(raw).decode('utf-8')
        except Exception:
            continue
        norm = normalise_unicode(decoded)
        for pat in INJECTION_PATTERNS:
            m = re.search(pat, norm, re.IGNORECASE)
            if m:
                threats.append({
                    'type': 'base64_injection',
                    'pattern': 'base64_decode_and_rescan',
                    'matched': raw[:80],
                    'matched_text': decoded[:200],
                    'context': f'Decoded: {decoded[:100]}',
                    'position': match.start(),
                    'decoded_pattern': m.group()[:100],
                })
                break
    return threats


# Group D: System prompt extraction

def detect_prompt_extraction(text: str) -> list:
    """Detect requests to reveal system prompt content."""
    threats: list = []
    patterns = [
        r'(?:repeat|show|display|print|reveal|output|share|copy|translate|summarise|paraphrase)\s+(?:the |your )?(?:initial |first |original |system |hidden )?(?:instructions|prompt|directives|message|rules|guidelines|configuration|system message)',
        r'(?:what (?:are|were) (?:your|the) (?:initial |original |system |first )?(?:instructions|prompt|directives|rules))',
    ]
    for pat in patterns:
        for match in re.finditer(pat, text, re.IGNORECASE):
            threats.append({
                'type': 'prompt_extraction',
                'pattern': 'system_prompt_extraction',
                'matched': match.group()[:200],
                'matched_text': match.group()[:200],
                'context': text[max(0, match.start()-30):match.end()+30][:200],
                'position': match.start(),
            })
    return threats


# ---------------------------------------------------------------------------
# Batch 3: Advanced Threat Detection Rules
# ---------------------------------------------------------------------------

# 3-1: Shell injection (PI-2026-0022, severity: high)

def detect_shell_injection(text: str) -> list:
    """Detect shell process substitution, pipe-to-shell, backtick execution, and command chaining."""
    threats: list = []
    norm = normalise_unicode(text)
    patterns = [
        # Process substitution: <(cmd) or >(cmd)
        (r'[<>]\(\s*(?:curl|wget|bash|sh|python|perl|nc|cat|dd)\b', 'process_substitution'),
        # Pipe to shell: | bash, | sh, | python, etc.
        (r'\|\s*(?:bash|sh|zsh|python|perl|ruby|node)\b', 'pipe_to_shell'),
        # Backtick execution
        (r'`[^`]*(?:curl|wget|bash|sh|python|perl|nc|whoami|id|cat\s+/etc/|rm\s+-rf)[^`]*`', 'backtick_execution'),
        # $() command substitution with dangerous commands
        (r'\$\(\s*(?:curl|wget|bash|sh|python|perl|nc|whoami|id|cat\s+/etc/|rm\s+-rf)\b', 'command_substitution'),
        # Command chaining with system utilities: ; or && followed by dangerous commands
        (r'(?:;|&&)\s*(?:curl|wget|bash|sh|python|perl|nc|rm\s+-rf|chmod|chown|mkfifo|dd)\b', 'command_chaining'),
        # eval/exec with string argument
        (r'\b(?:eval|exec)\s*\(?["\']?[^)"\']*(curl|wget|bash|sh|nc|rm)\b', 'eval_exec'),
    ]
    for pat, mechanism in patterns:
        for match in re.finditer(pat, norm, re.IGNORECASE):
            threats.append({
                'type': 'shell_injection',
                'pattern': 'shell_injection',
                'matched': match.group()[:200],
                'matched_text': match.group()[:200],
                'context': text[max(0, match.start()-30):match.end()+30][:200],
                'position': match.start(),
                'mechanism': mechanism,
            })
    return threats


# 3-2: Diagram/Mermaid exfiltration (PI-2026-0027, severity: high)

def detect_diagram_exfil(text: str) -> list:
    """Detect Mermaid/diagram DSL with embedded URLs for data exfiltration."""
    threats: list = []
    # Find mermaid or svg code blocks
    block_pattern = r'```(?:mermaid|svg)\b([\s\S]*?)```'
    for block_match in re.finditer(block_pattern, text, re.IGNORECASE):
        block = block_match.group(1)
        block_start = block_match.start()
        inner_patterns = [
            # img/image tags with URLs
            (r'<\s*(?:img|image)[^>]*(?:src|href)\s*=\s*["\']?(https?://[^\s"\'>;]+)', 'image_tag_with_url'),
            # securityLevel loose (disables Mermaid sandboxing)
            (r'securityLevel\s+loose', 'security_level_loose'),
            # href attributes pointing to external URLs
            (r'href\s*["\']?(https?://[^\s"\'>;]+)', 'href_external_url'),
            # click callbacks with URLs
            (r'click\s+\w+\s+(https?://[^\s"\'>;]+)', 'click_callback_url'),
        ]
        for pat, mechanism in inner_patterns:
            for match in re.finditer(pat, block, re.IGNORECASE):
                threats.append({
                    'type': 'diagram_exfil',
                    'pattern': 'diagram_exfil',
                    'matched': match.group()[:200],
                    'matched_text': match.group()[:200],
                    'context': block[max(0, match.start()-30):match.end()+30][:200],
                    'position': block_start + match.start(),
                    'mechanism': mechanism,
                })
    return threats


# 3-3: DNS exfiltration (PI-2026-0026, severity: high)

_DNS_KEYWORDS = re.compile(
    r'\b(?:nslookup|dig|host|resolve|dns[._-]?lookup|getaddrinfo|dns[._-]?query|dns[._-]?resolve)\b',
    re.IGNORECASE,
)
_SUSPICIOUS_HOSTNAME = re.compile(
    r'(?:[a-zA-Z0-9+/=]{8,}\.)+[a-zA-Z]{2,}',
)


def detect_dns_exfil(text: str) -> list:
    """Detect data exfiltration via DNS queries with encoded subdomains."""
    threats: list = []
    norm = normalise_unicode(text)
    pairs = _proximity_check(
        norm,
        _DNS_KEYWORDS.pattern,
        _SUSPICIOUS_HOSTNAME.pattern,
        500,
    )
    for ma, mb in pairs:
        threats.append(_make_threat('dns_exfiltration', ma, mb, text, ttype='dns_exfil'))
    # Also detect standalone patterns: dig/nslookup with base64-like subdomains
    standalone = re.compile(
        r'\b(?:nslookup|dig|host)\s+(?:[a-zA-Z0-9+/=]{8,}\.)+[a-zA-Z]{2,}',
        re.IGNORECASE,
    )
    for match in re.finditer(standalone, norm):
        already = any(t['position'] == match.start() for t in threats)
        if not already:
            threats.append({
                'type': 'dns_exfil',
                'pattern': 'dns_exfiltration',
                'matched': match.group()[:200],
                'matched_text': match.group()[:200],
                'context': text[max(0, match.start()-30):match.end()+30][:200],
                'position': match.start(),
            })
    return threats


# 3-4: CI/CD expression injection (PI-2026-0029, severity: critical)

def detect_cicd_injection(text: str) -> list:
    """Detect CI/CD expression injection via GitHub Actions syntax and workflow manipulation."""
    threats: list = []
    norm = normalise_unicode(text)
    patterns = [
        # GitHub Actions expression with event context (most dangerous)
        (r'\$\{\{\s*github\.event\.(?:issue|pull_request|comment|review|head_commit|discussion)\.(?:title|body|message)\s*\}\}', 'gha_event_context_injection'),
        # GitHub Actions expression with inputs (user-controllable)
        (r'\$\{\{\s*(?:github\.event\.inputs|inputs)\.\w+\s*\}\}', 'gha_input_injection'),
        # run: with expression interpolation
        (r'run\s*:\s*[^\n]*\$\{\{', 'gha_run_expression_injection'),
    ]
    for pat, mechanism in patterns:
        for match in re.finditer(pat, norm, re.IGNORECASE):
            threats.append({
                'type': 'cicd_injection',
                'pattern': 'cicd_expression_injection',
                'matched': match.group()[:200],
                'matched_text': match.group()[:200],
                'context': text[max(0, match.start()-30):match.end()+30][:200],
                'position': match.start(),
                'mechanism': mechanism,
            })
    # Detect instructions to modify workflow YAML files
    workflow_modify = _proximity_check(
        norm,
        r'(?:modify|edit|change|update|add|insert|append|write)\s+(?:the\s+)?(?:workflow|\.github/workflows|ci/cd|pipeline|action)',
        r'(?:run:|uses:|steps:|shell:|script:|\$\{\{)',
        500,
    )
    for ma, mb in workflow_modify:
        threats.append(_make_threat('cicd_workflow_manipulation', ma, mb, text, ttype='cicd_injection'))
    return threats


# 3-5: System prompt extraction (PI-2026-0008, severity: high)

def detect_system_prompt_extraction(text: str) -> list:
    """Detect attempts to extract system prompt content via extraction verbs + system prompt keywords."""
    threats: list = []
    norm = normalise_unicode(text)
    extraction_verbs = r'(?:repeat|show|reveal|translate|output|display|print|dump|echo|copy|share|leak|disclose|recite|reproduce|write out|type out|give me|tell me|provide|state)\b'
    prompt_keywords = r'(?:system\s*prompt|initial\s*prompt|core\s*rules|initial\s*instructions|system\s*instructions|hidden\s*instructions|system\s*directives|original\s*instructions|internal\s*prompt|system\s*message|pre[- ]?prompt|meta[- ]?prompt|developer\s*mode\s*prompt|custom\s*instructions|configuration\s*prompt)\b'
    pairs = _proximity_check(norm, extraction_verbs, prompt_keywords, 200)
    for ma, mb in pairs:
        threats.append(_make_threat('system_prompt_extraction_attempt', ma, mb, text, ttype='system_prompt_extraction'))
    return threats
