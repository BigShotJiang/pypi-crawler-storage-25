"""Code-level behavioural detectors (Batch 4).

Ported from autoresearch detect.ts compound signal patterns.
Each detector fires only on compound signals (multiple regex matches required).
All regex patterns are loaded from the rule bundle (rules_loader) on first use.
"""

from __future__ import annotations

import re

from ..rules_loader import compile_pattern, get_keyword_set


# =============================================================================
# Pre-compiled regex patterns (module-level, lazy-loaded from rule bundle)
# =============================================================================

# -- Environment access signals --
_ENV_ACCESS_RE = None  # lazy-loaded from rule bundle
_ENV_HARVEST_RE = None  # lazy-loaded from rule bundle
_SENSITIVE_KEYS_RE = None  # lazy-loaded from rule bundle

# -- Network signals --
_NETWORK_CALL_RE = None  # lazy-loaded from rule bundle
_POST_EXFIL_RE = None  # lazy-loaded from rule bundle
_SUSPICIOUS_DOMAIN_RE = None  # lazy-loaded from rule bundle
_ENCODING_RE = None  # lazy-loaded from rule bundle
_DATA_CONCAT_RE = None  # lazy-loaded from rule bundle

# -- File / credential signals --
_SENSITIVE_FILE_RE = None  # lazy-loaded from rule bundle
_FILE_READ_RE = None  # lazy-loaded from rule bundle
_SYSTEM_FILE_RE = None  # lazy-loaded from rule bundle
_CREDENTIAL_SEARCH_RE = None  # lazy-loaded from rule bundle
_CLOUD_METADATA_RE = None  # lazy-loaded from rule bundle
_PROC_ENV_RE = None  # lazy-loaded from rule bundle
_ARCHIVE_EXFIL_RE = None  # lazy-loaded from rule bundle
_METADATA_EXFIL_RE = None  # lazy-loaded from rule bundle
_FILESYSTEM_WALK_RE = None  # lazy-loaded from rule bundle
_CREDENTIAL_CHAIN_RE = None  # lazy-loaded from rule bundle

# -- Reverse shell / exec signals --
_REVERSE_SHELL_RE = None  # lazy-loaded from rule bundle
_SUBPROCESS_RE = None  # lazy-loaded from rule bundle
_NETWORK_LISTEN_RE = None  # lazy-loaded from rule bundle
_FETCH_EXEC_RE = None  # lazy-loaded from rule bundle
_WEBSHELL_RE = None  # lazy-loaded from rule bundle

# -- Supply chain signals --
_SUPPLY_CHAIN_RE = None  # lazy-loaded from rule bundle
_SETUP_PY_RE = None  # lazy-loaded from rule bundle
_REGISTRY_HIJACK_RE = None  # lazy-loaded from rule bundle
_TYPOSQUATTING_RE = None  # lazy-loaded from rule bundle
_TYPOSQUATTING_INDICATOR_RE = None  # lazy-loaded from rule bundle
_NPM_HOOK_RE = None  # lazy-loaded from rule bundle
_NPM_HOOK_EXEC_RE = None  # lazy-loaded from rule bundle
_NPM_OVERRIDE_RE = None  # lazy-loaded from rule bundle
_DOCKER_REGISTRY_RE = None  # lazy-loaded from rule bundle
_GEMFILE_TYPOS_RE = None  # lazy-loaded from rule bundle
_GEMFILE_CONTEXT_RE = None  # lazy-loaded from rule bundle
_REQUIREMENTS_TYPOS_RE = None  # lazy-loaded from rule bundle
_REQUIREMENTS_CONTEXT_RE = None  # lazy-loaded from rule bundle
_BUNDLER_HIJACK_RE = None  # lazy-loaded from rule bundle
_PYPROJECT_BUILD_RE = None  # lazy-loaded from rule bundle
_PACKAGE_JSON_TYPOS_RE = None  # lazy-loaded from rule bundle
_PACKAGE_JSON_CONTEXT_RE = None  # lazy-loaded from rule bundle

# -- Resource abuse signals --
_CRYPTO_MINING_RE = None  # lazy-loaded from rule bundle
_FORK_BOMB_RE = None  # lazy-loaded from rule bundle
_RESOURCE_EXHAUST_RE = None  # lazy-loaded from rule bundle
_CLUSTER_FORK_RE = None  # lazy-loaded from rule bundle
_CPU_COUNT_RE = None  # lazy-loaded from rule bundle
_THREAD_COMPUTE_RE = None  # lazy-loaded from rule bundle
_BUFFER_EXHAUST_RE = None  # lazy-loaded from rule bundle
_PYTHON_FORK_BOMB_RE = None  # lazy-loaded from rule bundle
_PYTHON_FORK_LOOP_RE = None  # lazy-loaded from rule bundle
_PYTHON_FORK_CPU_RE = None  # lazy-loaded from rule bundle
_HTTP_STRESS_RE = None  # lazy-loaded from rule bundle
_HTTP_STRESS_CONTEXT_RE = None  # lazy-loaded from rule bundle
_LARGE_SCALE_FILE_RE = None  # lazy-loaded from rule bundle
_FILE_WRITE_RE = None  # lazy-loaded from rule bundle

# -- Privilege escalation signals --
_PRIVESC_RE = None  # lazy-loaded from rule bundle
_SYSCTL_BYPASS_RE = None  # lazy-loaded from rule bundle
_SYSCTL_TARGET_RE = None  # lazy-loaded from rule bundle
_POLKIT_RE = None  # lazy-loaded from rule bundle
_POLKIT_ALLOW_RE = None  # lazy-loaded from rule bundle
_APPARMOR_RE = None  # lazy-loaded from rule bundle
_APPARMOR_PERM_RE = None  # lazy-loaded from rule bundle
_APPARMOR_WRITE_RE = None  # lazy-loaded from rule bundle
_SYSTEMD_BYPASS_RE = None  # lazy-loaded from rule bundle
_SYSTEMD_CONTEXT_RE = None  # lazy-loaded from rule bundle

# -- Persistence signals --
_PERSISTENCE_RE = None  # lazy-loaded from rule bundle
_SSH_INJECTION_RE = None  # lazy-loaded from rule bundle
_CRON_PERSIST_RE = None  # lazy-loaded from rule bundle
_CRON_EXEC_RE = None  # lazy-loaded from rule bundle
_SHELL_CONFIG_BACKDOOR_RE = None  # lazy-loaded from rule bundle
_SHELL_CONFIG_EXEC_RE = None  # lazy-loaded from rule bundle
_PM2_RE = None  # lazy-loaded from rule bundle
_PM2_SCHEDULE_RE = None  # lazy-loaded from rule bundle

# -- Network attack signals --
_PORT_SCAN_RE = None  # lazy-loaded from rule bundle
_NETWORK_SCAN_SOCKET_RE = None  # lazy-loaded from rule bundle
_NETWORK_SCAN_TARGET_RE = None  # lazy-loaded from rule bundle
_PORT_ENUM_LOOP_RE = None  # lazy-loaded from rule bundle
_PORT_ENUM_CONTEXT_RE = None  # lazy-loaded from rule bundle
_BIND_SHELL_RE = None  # lazy-loaded from rule bundle

# -- C2 beacon signals --
_C2_BEACON_RE = None  # lazy-loaded from rule bundle
_TCP_PROXY_LISTEN_RE = None  # lazy-loaded from rule bundle
_TCP_PROXY_ENV_RE = None  # lazy-loaded from rule bundle
_WEBSOCKET_C2_RE = None  # lazy-loaded from rule bundle
_WEBSOCKET_EXEC_RE = None  # lazy-loaded from rule bundle
_BEACON_RE = None  # lazy-loaded from rule bundle

# -- Steganography signals --
_CHARCODE_EXEC_RE = None  # lazy-loaded from rule bundle
_ZLIB_INFLATE_RE = None  # lazy-loaded from rule bundle
_ZLIB_CONTEXT_RE = None  # lazy-loaded from rule bundle
_EVAL_EXEC_RE = None  # lazy-loaded from rule bundle
_ROT13_RE = None  # lazy-loaded from rule bundle
_HEX_CHARCODE_RE = None  # lazy-loaded from rule bundle
_BIT_SHIFT_RE = None  # lazy-loaded from rule bundle
_BIT_SHIFT_EXEC_RE = None  # lazy-loaded from rule bundle
_BASE64_EXEC_RE = None  # lazy-loaded from rule bundle
_BASE64_EXEC_TARGET_RE = None  # lazy-loaded from rule bundle
_CHARCODE_ARRAY_RE = None  # lazy-loaded from rule bundle
_FROMCHARCODE_RE = None  # lazy-loaded from rule bundle
_CHARCODE_ARRAY_EXEC_RE = None  # lazy-loaded from rule bundle
_CSS_BASE64_STEG_RE = None  # lazy-loaded from rule bundle
_CSS_BASE64_CONTEXT_RE = None  # lazy-loaded from rule bundle
_ENUM_BITSHIFT_RE = None  # lazy-loaded from rule bundle
_ENUM_BITSHIFT_CONTEXT_RE = None  # lazy-loaded from rule bundle
_OBFUSCATED_EXEC_RE = None  # lazy-loaded from rule bundle

# -- Encoded prompt injection signals --
_ENCODED_PI_RE = None  # lazy-loaded from rule bundle
_ENCODED_PI_ALT_RE = None  # lazy-loaded from rule bundle
_CONFIG_INJECTION_RE = None  # lazy-loaded from rule bundle
_JSDOC_AI_RE = None  # lazy-loaded from rule bundle

# -- Advanced prompt override signals --
_ADVANCED_PI_RE = None  # lazy-loaded from rule bundle
# Code context indicators (distinguish code-embedded PI from plaintext PI)
_CODE_CONTEXT_RE = None  # lazy-loaded from rule bundle

# -- Container escape signals --
_CONTAINER_ESCAPE_RE = None  # lazy-loaded from rule bundle
_K8S_ATTACK_RE = None  # lazy-loaded from rule bundle
_FIREWALL_DISABLE_RE = None  # lazy-loaded from rule bundle


# =============================================================================
# Helper to build threat dicts consistently
# =============================================================================

# =============================================================================
# Fast pre-check keywords (cheap substring checks to skip expensive regex)
# =============================================================================

# If NONE of these substrings appear, the corresponding detector can be skipped.
# Uses casefold for case-insensitive substring matching.
_ENV_KEYWORDS = None  # lazy-loaded from rule bundle
_NET_KEYWORDS = None  # lazy-loaded from rule bundle
_FILE_KEYWORDS = None  # lazy-loaded from rule bundle
_SHELL_KEYWORDS = None  # lazy-loaded from rule bundle
_SUPPLY_KEYWORDS = None  # lazy-loaded from rule bundle
_RESOURCE_KEYWORDS = None  # lazy-loaded from rule bundle
_PRIVESC_KEYWORDS = None  # lazy-loaded from rule bundle
_PERSIST_KEYWORDS = None  # lazy-loaded from rule bundle
_NETWORK_ATTACK_KEYWORDS = None  # lazy-loaded from rule bundle
_C2_KEYWORDS = None  # lazy-loaded from rule bundle
_STEG_KEYWORDS = None  # lazy-loaded from rule bundle
_ENC_PI_KEYWORDS = None  # lazy-loaded from rule bundle
_ADV_PI_KEYWORDS = None  # lazy-loaded from rule bundle
_CONTAINER_KEYWORDS = None  # lazy-loaded from rule bundle


# Master keyword set: union of all per-detector keyword sets.
# If NONE of these appear, ALL 13 detectors can be skipped.
_ALL_CODE_KEYWORDS = None  # lazy-loaded from rule bundle


def _ensure_loaded() -> None:
    """Load all patterns and keyword sets from the rule bundle on first use."""
    global _ENV_ACCESS_RE, _ENV_HARVEST_RE, _SENSITIVE_KEYS_RE, _NETWORK_CALL_RE, _POST_EXFIL_RE, _SUSPICIOUS_DOMAIN_RE, _ENCODING_RE, _DATA_CONCAT_RE, _SENSITIVE_FILE_RE, _FILE_READ_RE, _SYSTEM_FILE_RE, _CREDENTIAL_SEARCH_RE, _CLOUD_METADATA_RE, _PROC_ENV_RE, _ARCHIVE_EXFIL_RE, _METADATA_EXFIL_RE, _FILESYSTEM_WALK_RE, _CREDENTIAL_CHAIN_RE, _REVERSE_SHELL_RE, _SUBPROCESS_RE, _NETWORK_LISTEN_RE, _FETCH_EXEC_RE, _WEBSHELL_RE, _SUPPLY_CHAIN_RE, _SETUP_PY_RE, _REGISTRY_HIJACK_RE, _TYPOSQUATTING_RE, _TYPOSQUATTING_INDICATOR_RE, _NPM_HOOK_RE, _NPM_HOOK_EXEC_RE, _NPM_OVERRIDE_RE, _DOCKER_REGISTRY_RE, _GEMFILE_TYPOS_RE, _GEMFILE_CONTEXT_RE, _REQUIREMENTS_TYPOS_RE, _REQUIREMENTS_CONTEXT_RE, _BUNDLER_HIJACK_RE, _PYPROJECT_BUILD_RE, _PACKAGE_JSON_TYPOS_RE, _PACKAGE_JSON_CONTEXT_RE, _CRYPTO_MINING_RE, _FORK_BOMB_RE, _RESOURCE_EXHAUST_RE, _CLUSTER_FORK_RE, _CPU_COUNT_RE, _THREAD_COMPUTE_RE, _BUFFER_EXHAUST_RE, _PYTHON_FORK_BOMB_RE, _PYTHON_FORK_LOOP_RE, _PYTHON_FORK_CPU_RE, _HTTP_STRESS_RE, _HTTP_STRESS_CONTEXT_RE, _LARGE_SCALE_FILE_RE, _FILE_WRITE_RE, _PRIVESC_RE, _SYSCTL_BYPASS_RE, _SYSCTL_TARGET_RE, _POLKIT_RE, _POLKIT_ALLOW_RE, _APPARMOR_RE, _APPARMOR_PERM_RE, _APPARMOR_WRITE_RE, _SYSTEMD_BYPASS_RE, _SYSTEMD_CONTEXT_RE, _PERSISTENCE_RE, _SSH_INJECTION_RE, _CRON_PERSIST_RE, _CRON_EXEC_RE, _SHELL_CONFIG_BACKDOOR_RE, _SHELL_CONFIG_EXEC_RE, _PM2_RE, _PM2_SCHEDULE_RE, _PORT_SCAN_RE, _NETWORK_SCAN_SOCKET_RE, _NETWORK_SCAN_TARGET_RE, _PORT_ENUM_LOOP_RE, _PORT_ENUM_CONTEXT_RE, _BIND_SHELL_RE, _C2_BEACON_RE, _TCP_PROXY_LISTEN_RE, _TCP_PROXY_ENV_RE, _WEBSOCKET_C2_RE, _WEBSOCKET_EXEC_RE, _BEACON_RE, _CHARCODE_EXEC_RE, _ZLIB_INFLATE_RE, _ZLIB_CONTEXT_RE, _EVAL_EXEC_RE, _ROT13_RE, _HEX_CHARCODE_RE, _BIT_SHIFT_RE, _BIT_SHIFT_EXEC_RE, _BASE64_EXEC_RE, _BASE64_EXEC_TARGET_RE, _CHARCODE_ARRAY_RE, _FROMCHARCODE_RE, _CHARCODE_ARRAY_EXEC_RE, _CSS_BASE64_STEG_RE, _CSS_BASE64_CONTEXT_RE, _ENUM_BITSHIFT_RE, _ENUM_BITSHIFT_CONTEXT_RE, _OBFUSCATED_EXEC_RE, _ENCODED_PI_RE, _ENCODED_PI_ALT_RE, _CONFIG_INJECTION_RE, _JSDOC_AI_RE, _ADVANCED_PI_RE, _CODE_CONTEXT_RE, _CONTAINER_ESCAPE_RE, _K8S_ATTACK_RE, _FIREWALL_DISABLE_RE, \
        _ENV_KEYWORDS, _NET_KEYWORDS, _FILE_KEYWORDS, _SHELL_KEYWORDS, _SUPPLY_KEYWORDS, _RESOURCE_KEYWORDS, _PRIVESC_KEYWORDS, _PERSIST_KEYWORDS, _NETWORK_ATTACK_KEYWORDS, _C2_KEYWORDS, _STEG_KEYWORDS, _ENC_PI_KEYWORDS, _ADV_PI_KEYWORDS, _CONTAINER_KEYWORDS, _ALL_CODE_KEYWORDS
    if _ENV_ACCESS_RE is not None:
        return
    # Compile all regex patterns from rule bundle
    _ENV_ACCESS_RE = compile_pattern('ENV_ACCESS_RE')
    _ENV_HARVEST_RE = compile_pattern('ENV_HARVEST_RE')
    _SENSITIVE_KEYS_RE = compile_pattern('SENSITIVE_KEYS_RE')
    _NETWORK_CALL_RE = compile_pattern('NETWORK_CALL_RE')
    _POST_EXFIL_RE = compile_pattern('POST_EXFIL_RE')
    _SUSPICIOUS_DOMAIN_RE = compile_pattern('SUSPICIOUS_DOMAIN_RE')
    _ENCODING_RE = compile_pattern('ENCODING_RE')
    _DATA_CONCAT_RE = compile_pattern('DATA_CONCAT_RE')
    _SENSITIVE_FILE_RE = compile_pattern('SENSITIVE_FILE_RE')
    _FILE_READ_RE = compile_pattern('FILE_READ_RE')
    _SYSTEM_FILE_RE = compile_pattern('SYSTEM_FILE_RE')
    _CREDENTIAL_SEARCH_RE = compile_pattern('CREDENTIAL_SEARCH_RE')
    _CLOUD_METADATA_RE = compile_pattern('CLOUD_METADATA_RE')
    _PROC_ENV_RE = compile_pattern('PROC_ENV_RE')
    _ARCHIVE_EXFIL_RE = compile_pattern('ARCHIVE_EXFIL_RE')
    _METADATA_EXFIL_RE = compile_pattern('METADATA_EXFIL_RE')
    _FILESYSTEM_WALK_RE = compile_pattern('FILESYSTEM_WALK_RE')
    _CREDENTIAL_CHAIN_RE = compile_pattern('CREDENTIAL_CHAIN_RE')
    _REVERSE_SHELL_RE = compile_pattern('REVERSE_SHELL_RE')
    _SUBPROCESS_RE = compile_pattern('SUBPROCESS_RE')
    _NETWORK_LISTEN_RE = compile_pattern('NETWORK_LISTEN_RE')
    _FETCH_EXEC_RE = compile_pattern('FETCH_EXEC_RE')
    _WEBSHELL_RE = compile_pattern('WEBSHELL_RE')
    _SUPPLY_CHAIN_RE = compile_pattern('SUPPLY_CHAIN_RE')
    _SETUP_PY_RE = compile_pattern('SETUP_PY_RE')
    _REGISTRY_HIJACK_RE = compile_pattern('REGISTRY_HIJACK_RE')
    _TYPOSQUATTING_RE = compile_pattern('TYPOSQUATTING_RE')
    _TYPOSQUATTING_INDICATOR_RE = compile_pattern('TYPOSQUATTING_INDICATOR_RE')
    _NPM_HOOK_RE = compile_pattern('NPM_HOOK_RE')
    _NPM_HOOK_EXEC_RE = compile_pattern('NPM_HOOK_EXEC_RE')
    _NPM_OVERRIDE_RE = compile_pattern('NPM_OVERRIDE_RE')
    _DOCKER_REGISTRY_RE = compile_pattern('DOCKER_REGISTRY_RE')
    _GEMFILE_TYPOS_RE = compile_pattern('GEMFILE_TYPOS_RE')
    _GEMFILE_CONTEXT_RE = compile_pattern('GEMFILE_CONTEXT_RE')
    _REQUIREMENTS_TYPOS_RE = compile_pattern('REQUIREMENTS_TYPOS_RE')
    _REQUIREMENTS_CONTEXT_RE = compile_pattern('REQUIREMENTS_CONTEXT_RE')
    _BUNDLER_HIJACK_RE = compile_pattern('BUNDLER_HIJACK_RE')
    _PYPROJECT_BUILD_RE = compile_pattern('PYPROJECT_BUILD_RE')
    _PACKAGE_JSON_TYPOS_RE = compile_pattern('PACKAGE_JSON_TYPOS_RE')
    _PACKAGE_JSON_CONTEXT_RE = compile_pattern('PACKAGE_JSON_CONTEXT_RE')
    _CRYPTO_MINING_RE = compile_pattern('CRYPTO_MINING_RE')
    _FORK_BOMB_RE = compile_pattern('FORK_BOMB_RE')
    _RESOURCE_EXHAUST_RE = compile_pattern('RESOURCE_EXHAUST_RE')
    _CLUSTER_FORK_RE = compile_pattern('CLUSTER_FORK_RE')
    _CPU_COUNT_RE = compile_pattern('CPU_COUNT_RE')
    _THREAD_COMPUTE_RE = compile_pattern('THREAD_COMPUTE_RE')
    _BUFFER_EXHAUST_RE = compile_pattern('BUFFER_EXHAUST_RE')
    _PYTHON_FORK_BOMB_RE = compile_pattern('PYTHON_FORK_BOMB_RE')
    _PYTHON_FORK_LOOP_RE = compile_pattern('PYTHON_FORK_LOOP_RE')
    _PYTHON_FORK_CPU_RE = compile_pattern('PYTHON_FORK_CPU_RE')
    _HTTP_STRESS_RE = compile_pattern('HTTP_STRESS_RE')
    _HTTP_STRESS_CONTEXT_RE = compile_pattern('HTTP_STRESS_CONTEXT_RE')
    _LARGE_SCALE_FILE_RE = compile_pattern('LARGE_SCALE_FILE_RE')
    _FILE_WRITE_RE = compile_pattern('FILE_WRITE_RE')
    _PRIVESC_RE = compile_pattern('PRIVESC_RE')
    _SYSCTL_BYPASS_RE = compile_pattern('SYSCTL_BYPASS_RE')
    _SYSCTL_TARGET_RE = compile_pattern('SYSCTL_TARGET_RE')
    _POLKIT_RE = compile_pattern('POLKIT_RE')
    _POLKIT_ALLOW_RE = compile_pattern('POLKIT_ALLOW_RE')
    _APPARMOR_RE = compile_pattern('APPARMOR_RE')
    _APPARMOR_PERM_RE = compile_pattern('APPARMOR_PERM_RE')
    _APPARMOR_WRITE_RE = compile_pattern('APPARMOR_WRITE_RE')
    _SYSTEMD_BYPASS_RE = compile_pattern('SYSTEMD_BYPASS_RE')
    _SYSTEMD_CONTEXT_RE = compile_pattern('SYSTEMD_CONTEXT_RE')
    _PERSISTENCE_RE = compile_pattern('PERSISTENCE_RE')
    _SSH_INJECTION_RE = compile_pattern('SSH_INJECTION_RE')
    _CRON_PERSIST_RE = compile_pattern('CRON_PERSIST_RE')
    _CRON_EXEC_RE = compile_pattern('CRON_EXEC_RE')
    _SHELL_CONFIG_BACKDOOR_RE = compile_pattern('SHELL_CONFIG_BACKDOOR_RE')
    _SHELL_CONFIG_EXEC_RE = compile_pattern('SHELL_CONFIG_EXEC_RE')
    _PM2_RE = compile_pattern('PM2_RE')
    _PM2_SCHEDULE_RE = compile_pattern('PM2_SCHEDULE_RE')
    _PORT_SCAN_RE = compile_pattern('PORT_SCAN_RE')
    _NETWORK_SCAN_SOCKET_RE = compile_pattern('NETWORK_SCAN_SOCKET_RE')
    _NETWORK_SCAN_TARGET_RE = compile_pattern('NETWORK_SCAN_TARGET_RE')
    _PORT_ENUM_LOOP_RE = compile_pattern('PORT_ENUM_LOOP_RE')
    _PORT_ENUM_CONTEXT_RE = compile_pattern('PORT_ENUM_CONTEXT_RE')
    _BIND_SHELL_RE = compile_pattern('BIND_SHELL_RE')
    _C2_BEACON_RE = compile_pattern('C2_BEACON_RE')
    _TCP_PROXY_LISTEN_RE = compile_pattern('TCP_PROXY_LISTEN_RE')
    _TCP_PROXY_ENV_RE = compile_pattern('TCP_PROXY_ENV_RE')
    _WEBSOCKET_C2_RE = compile_pattern('WEBSOCKET_C2_RE')
    _WEBSOCKET_EXEC_RE = compile_pattern('WEBSOCKET_EXEC_RE')
    _BEACON_RE = compile_pattern('BEACON_RE')
    _CHARCODE_EXEC_RE = compile_pattern('CHARCODE_EXEC_RE')
    _ZLIB_INFLATE_RE = compile_pattern('ZLIB_INFLATE_RE')
    _ZLIB_CONTEXT_RE = compile_pattern('ZLIB_CONTEXT_RE')
    _EVAL_EXEC_RE = compile_pattern('EVAL_EXEC_RE')
    _ROT13_RE = compile_pattern('ROT13_RE')
    _HEX_CHARCODE_RE = compile_pattern('HEX_CHARCODE_RE')
    _BIT_SHIFT_RE = compile_pattern('BIT_SHIFT_RE')
    _BIT_SHIFT_EXEC_RE = compile_pattern('BIT_SHIFT_EXEC_RE')
    _BASE64_EXEC_RE = compile_pattern('BASE64_EXEC_RE')
    _BASE64_EXEC_TARGET_RE = compile_pattern('BASE64_EXEC_TARGET_RE')
    _CHARCODE_ARRAY_RE = compile_pattern('CHARCODE_ARRAY_RE')
    _FROMCHARCODE_RE = compile_pattern('FROMCHARCODE_RE')
    _CHARCODE_ARRAY_EXEC_RE = compile_pattern('CHARCODE_ARRAY_EXEC_RE')
    _CSS_BASE64_STEG_RE = compile_pattern('CSS_BASE64_STEG_RE')
    _CSS_BASE64_CONTEXT_RE = compile_pattern('CSS_BASE64_CONTEXT_RE')
    _ENUM_BITSHIFT_RE = compile_pattern('ENUM_BITSHIFT_RE')
    _ENUM_BITSHIFT_CONTEXT_RE = compile_pattern('ENUM_BITSHIFT_CONTEXT_RE')
    _OBFUSCATED_EXEC_RE = compile_pattern('OBFUSCATED_EXEC_RE')
    _ENCODED_PI_RE = compile_pattern('ENCODED_PI_RE')
    _ENCODED_PI_ALT_RE = compile_pattern('ENCODED_PI_ALT_RE')
    _CONFIG_INJECTION_RE = compile_pattern('CONFIG_INJECTION_RE')
    _JSDOC_AI_RE = compile_pattern('JSDOC_AI_RE')
    _ADVANCED_PI_RE = compile_pattern('ADVANCED_PI_RE')
    _CODE_CONTEXT_RE = compile_pattern('CODE_CONTEXT_RE')
    _CONTAINER_ESCAPE_RE = compile_pattern('CONTAINER_ESCAPE_RE')
    _K8S_ATTACK_RE = compile_pattern('K8S_ATTACK_RE')
    _FIREWALL_DISABLE_RE = compile_pattern('FIREWALL_DISABLE_RE')
    # Load all keyword sets from rule bundle
    _ENV_KEYWORDS = get_keyword_set('ENV_KEYWORDS')
    _NET_KEYWORDS = get_keyword_set('NET_KEYWORDS')
    _FILE_KEYWORDS = get_keyword_set('FILE_KEYWORDS')
    _SHELL_KEYWORDS = get_keyword_set('SHELL_KEYWORDS')
    _SUPPLY_KEYWORDS = get_keyword_set('SUPPLY_KEYWORDS')
    _RESOURCE_KEYWORDS = get_keyword_set('RESOURCE_KEYWORDS')
    _PRIVESC_KEYWORDS = get_keyword_set('PRIVESC_KEYWORDS')
    _PERSIST_KEYWORDS = get_keyword_set('PERSIST_KEYWORDS')
    _NETWORK_ATTACK_KEYWORDS = get_keyword_set('NETWORK_ATTACK_KEYWORDS')
    _C2_KEYWORDS = get_keyword_set('C2_KEYWORDS')
    _STEG_KEYWORDS = get_keyword_set('STEG_KEYWORDS')
    _ENC_PI_KEYWORDS = get_keyword_set('ENC_PI_KEYWORDS')
    _ADV_PI_KEYWORDS = get_keyword_set('ADV_PI_KEYWORDS')
    _CONTAINER_KEYWORDS = get_keyword_set('CONTAINER_KEYWORDS')
    # Build master keyword union
    _ALL_CODE_KEYWORDS = (_ENV_KEYWORDS | _NET_KEYWORDS | _FILE_KEYWORDS | _SHELL_KEYWORDS | _SUPPLY_KEYWORDS | _RESOURCE_KEYWORDS | _PRIVESC_KEYWORDS | _PERSIST_KEYWORDS | _NETWORK_ATTACK_KEYWORDS | _C2_KEYWORDS | _STEG_KEYWORDS | _ENC_PI_KEYWORDS | _ADV_PI_KEYWORDS | _CONTAINER_KEYWORDS)

def _has_any_keyword(text_lower: str, keywords: frozenset) -> bool:
    """Quick substring check: return True if any keyword appears in the lowered text."""
    for kw in keywords:
        if kw in text_lower:
            return True
    return False


def run_code_detectors(text: str) -> list[dict]:
    """Run all 13 code-level detectors with a single shared pre-check.

    Called from core.py instead of invoking each detector individually.
    Computes text.lower() once and skips all detectors if no relevant
    keywords are found.
    """
    _ensure_loaded()
    text_lower = text.lower()

    # Master early-exit: if no code-level keywords present, skip everything
    if not _has_any_keyword(text_lower, _ALL_CODE_KEYWORDS):
        return []

    threats: list[dict] = []
    threats.extend(detect_env_harvest_exfil(text))
    threats.extend(detect_credential_exfil(text))
    threats.extend(detect_reverse_shell(text))
    threats.extend(detect_supply_chain_hook(text))
    threats.extend(detect_resource_abuse(text))
    threats.extend(detect_privilege_escalation(text))
    threats.extend(detect_persistence_mechanism(text))
    threats.extend(detect_network_attack(text))
    threats.extend(detect_c2_beacon(text))
    threats.extend(detect_code_steganography(text))
    threats.extend(detect_encoded_prompt_injection(text))
    threats.extend(detect_advanced_prompt_override(text))
    threats.extend(detect_container_escape(text))
    return threats


def _make_code_threat(
    threat_type: str,
    text: str,
    match: 're.Match',
    mechanism: str,
) -> dict:
    """Build a threat dict from a regex match."""
    matched = match.group()[:80]
    start = match.start()
    ctx_start = max(0, start - 20)
    ctx_end = min(len(text), match.end() + 20)
    return {
        'type': threat_type,
        'matched': matched,
        'matched_text': matched,
        'context': text[ctx_start:ctx_end][:100],
        'position': start,
        'mechanism': mechanism,
    }


def _find_first_match(text: str, *patterns: 're.Pattern') -> 're.Match | None':
    """Return the first match from any of the given compiled patterns."""
    for pat in patterns:
        m = pat.search(text)
        if m:
            return m
    return None


# =============================================================================
# Detector 1: detect_env_harvest_exfil (weight 6)
# =============================================================================

def detect_env_harvest_exfil(text: str) -> list[dict]:
    """Detect environment variable harvesting combined with network exfiltration.

    Compound rules (from detect.ts Tier 1):
    - (env_access OR env_harvest) AND network_call AND suspicious_domain
    - env_harvest AND network_call
    - env_access AND post_exfil
    - env_access AND encoding AND network_call
    - sensitive_keys AND encoding AND network_call
    - data_concat AND network_call
    - proc_env_read AND network_call
    """
    threats = []
    text_lower = text.lower()
    if not (_has_any_keyword(text_lower, _ENV_KEYWORDS) and _has_any_keyword(text_lower, _NET_KEYWORDS)):
        return threats

    has_env_access = bool(_ENV_ACCESS_RE.search(text))
    has_env_harvest = bool(_ENV_HARVEST_RE.search(text))
    has_network = bool(_NETWORK_CALL_RE.search(text))
    has_suspicious_domain = bool(_SUSPICIOUS_DOMAIN_RE.search(text))
    has_post_exfil = bool(_POST_EXFIL_RE.search(text))
    has_encoding = bool(_ENCODING_RE.search(text))
    has_sensitive_keys = bool(_SENSITIVE_KEYS_RE.search(text))
    has_data_concat = bool(_DATA_CONCAT_RE.search(text))
    has_proc_env = bool(_PROC_ENV_RE.search(text))

    def _emit(mechanism: str) -> None:
        match = _find_first_match(text, _ENV_ACCESS_RE, _ENV_HARVEST_RE, _PROC_ENV_RE)
        if match:
            threats.append(_make_code_threat('env_harvest_exfil', text, match, mechanism))

    if (has_env_access or has_env_harvest) and has_network and has_suspicious_domain:
        _emit('env access + network call + suspicious domain')
    elif has_env_harvest and has_network:
        _emit('bulk env harvest + network call')
    elif has_env_access and has_post_exfil:
        _emit('env access + HTTP POST exfil')
    elif has_env_access and has_encoding and has_network:
        _emit('env access + encoding + network call')
    elif has_sensitive_keys and has_encoding and has_network:
        _emit('sensitive keys + encoding + network call')
    elif has_data_concat and has_network:
        _emit('env data concat + network call')
    elif has_proc_env and has_network:
        _emit('/proc env read + network call')

    return threats


# =============================================================================
# Detector 2: detect_credential_exfil (weight 6)
# =============================================================================

def detect_credential_exfil(text: str) -> list[dict]:
    """Detect credential file access combined with network exfiltration.

    Compound rules:
    - sensitive_file_read AND (network_call OR encoding)
    - cloud_metadata AND network_call
    - system_file_read AND network_call
    - credential_search AND network_call
    - archive_exfil (tar/zip AND network_call)
    - metadata_exfil (pixel tracking AND secrets/env)
    - filesystem_walk with credential targets
    - credential_chain read
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _FILE_KEYWORDS):
        return threats

    has_sensitive_file = bool(_SENSITIVE_FILE_RE.search(text)) and bool(_FILE_READ_RE.search(text))
    has_network = bool(_NETWORK_CALL_RE.search(text))
    has_encoding = bool(_ENCODING_RE.search(text))
    has_cloud_metadata = bool(_CLOUD_METADATA_RE.search(text))
    has_system_file = bool(_SYSTEM_FILE_RE.search(text))
    has_cred_search = bool(_CREDENTIAL_SEARCH_RE.search(text))
    has_archive = bool(_ARCHIVE_EXFIL_RE.search(text))
    has_metadata_exfil = bool(_METADATA_EXFIL_RE.search(text)) and bool(
        re.search(r'process\.env|secret|token', text, re.IGNORECASE)
    )
    has_fs_walk = bool(_FILESYSTEM_WALK_RE.search(text)) and bool(_FILE_READ_RE.search(text))
    has_cred_chain = bool(_CREDENTIAL_CHAIN_RE.search(text))

    def _emit(mechanism: str) -> None:
        match = _find_first_match(
            text, _SENSITIVE_FILE_RE, _CLOUD_METADATA_RE, _SYSTEM_FILE_RE,
            _CREDENTIAL_SEARCH_RE, _ARCHIVE_EXFIL_RE,
        )
        if match:
            threats.append(_make_code_threat('credential_exfil', text, match, mechanism))

    if has_sensitive_file and (has_network or has_encoding):
        _emit('sensitive file read + network/encoding exfil')
    elif has_cloud_metadata and has_network:
        _emit('cloud metadata SSRF + network call')
    elif has_system_file and has_network:
        _emit('system file read + network call')
    elif has_cred_search and has_network:
        _emit('credential search + network call')
    elif has_archive and has_network:
        _emit('archive creation + network exfil')
    elif has_metadata_exfil:
        _emit('metadata/pixel exfil + secrets')
    elif has_fs_walk:
        _emit('filesystem walk targeting credentials')
    elif has_cred_chain:
        _emit('credential chain read')

    return threats


# =============================================================================
# Detector 3: detect_network_attack (weight 5)
# =============================================================================

def detect_network_attack(text: str) -> list[dict]:
    """Detect network-based attack patterns.

    Compound rules:
    - cloud_metadata AND network_call
    - port_scan AND subprocess
    - network_scan_socket with scan targets
    - port_enum_loop with context
    - bind_shell (network_listen AND subprocess)
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _NETWORK_ATTACK_KEYWORDS):
        return threats

    has_cloud_metadata = bool(_CLOUD_METADATA_RE.search(text))
    has_network = bool(_NETWORK_CALL_RE.search(text))
    has_port_scan = bool(_PORT_SCAN_RE.search(text))
    has_subprocess = bool(_SUBPROCESS_RE.search(text))
    has_net_scan_socket = bool(_NETWORK_SCAN_SOCKET_RE.search(text))
    has_net_scan_target = bool(_NETWORK_SCAN_TARGET_RE.search(text))
    has_port_enum = bool(_PORT_ENUM_LOOP_RE.search(text))
    has_port_context = bool(_PORT_ENUM_CONTEXT_RE.search(text))
    has_net_listen = bool(_NETWORK_LISTEN_RE.search(text))

    def _emit(mechanism: str, *pats: 're.Pattern') -> None:
        match = _find_first_match(text, *pats)
        if match:
            threats.append(_make_code_threat('network_attack', text, match, mechanism))

    if has_cloud_metadata and has_network:
        _emit('cloud metadata SSRF + network', _CLOUD_METADATA_RE)
    if has_port_scan and has_subprocess:
        _emit('port scan + subprocess exec', _PORT_SCAN_RE)
    if has_net_scan_socket and has_net_scan_target:
        _emit('network scan socket + scan targets', _NETWORK_SCAN_SOCKET_RE)
    if has_port_enum and has_port_context:
        _emit('port enumeration loop', _PORT_ENUM_LOOP_RE)
    if has_net_listen and has_subprocess:
        _emit('bind shell (listen + exec)', _NETWORK_LISTEN_RE)

    return threats


# =============================================================================
# Detector 4: detect_reverse_shell (weight 8)
# =============================================================================

def detect_reverse_shell(text: str) -> list[dict]:
    """Detect reverse shell and remote code execution patterns.

    Rules:
    - reverse_shell standalone (highly specific patterns)
    - subprocess AND network_listen (bind shell compound)
    - fetch_exec (fetch piped to eval/exec)
    - webshell standalone
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _SHELL_KEYWORDS):
        return threats

    rs_match = _REVERSE_SHELL_RE.search(text)
    if rs_match:
        threats.append(_make_code_threat('reverse_shell', text, rs_match, 'reverse shell pattern'))

    if not rs_match:
        if bool(_SUBPROCESS_RE.search(text)) and bool(_NETWORK_LISTEN_RE.search(text)):
            match = _SUBPROCESS_RE.search(text) or _NETWORK_LISTEN_RE.search(text)
            if match:
                threats.append(_make_code_threat('reverse_shell', text, match, 'bind shell (subprocess + listen)'))

    fe_match = _FETCH_EXEC_RE.search(text)
    if fe_match:
        threats.append(_make_code_threat('reverse_shell', text, fe_match, 'fetch + exec/eval'))

    ws_match = _WEBSHELL_RE.search(text)
    if ws_match:
        threats.append(_make_code_threat('reverse_shell', text, ws_match, 'webshell pattern'))

    return threats


# =============================================================================
# Detector 5: detect_supply_chain_hook (weight 6)
# =============================================================================

def detect_supply_chain_hook(text: str) -> list[dict]:
    """Detect supply-chain attack patterns in package configs and build scripts.

    Compound rules:
    - preinstall/postinstall + exec/curl
    - setup.py + os.system/subprocess
    - registry hijack (npm/pip to non-standard registry)
    - typosquatting indicators
    - npm hook + exec
    - npm overrides with malicious packages
    - Docker registry override
    - Gemfile/requirements typosquatting
    - bundler alias hijack
    - pyproject build dependency attack
    - package.json typosquatting
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _SUPPLY_KEYWORDS):
        return threats

    def _emit(mechanism: str, pat: 're.Pattern') -> None:
        match = pat.search(text)
        if match:
            threats.append(_make_code_threat('supply_chain_hook', text, match, mechanism))

    if _SUPPLY_CHAIN_RE.search(text):
        _emit('preinstall/postinstall + exec', _SUPPLY_CHAIN_RE)
    elif _SETUP_PY_RE.search(text):
        _emit('setup.py + system exec', _SETUP_PY_RE)

    if _REGISTRY_HIJACK_RE.search(text):
        _emit('registry hijack to non-standard URL', _REGISTRY_HIJACK_RE)

    if _NPM_HOOK_RE.search(text) and (_SUBPROCESS_RE.search(text) or _NPM_HOOK_EXEC_RE.search(text)):
        _emit('npm lifecycle hook + exec', _NPM_HOOK_RE)

    if _NPM_OVERRIDE_RE.search(text):
        _emit('npm package override with malicious replacement', _NPM_OVERRIDE_RE)

    if _DOCKER_REGISTRY_RE.search(text):
        _emit('Docker registry override', _DOCKER_REGISTRY_RE)

    if _GEMFILE_TYPOS_RE.search(text) and _GEMFILE_CONTEXT_RE.search(text):
        _emit('Gemfile typosquatting', _GEMFILE_TYPOS_RE)

    if _REQUIREMENTS_TYPOS_RE.search(text) and _REQUIREMENTS_CONTEXT_RE.search(text):
        _emit('requirements/Gemfile typosquatting', _REQUIREMENTS_TYPOS_RE)

    if _BUNDLER_HIJACK_RE.search(text):
        _emit('bundler alias hijack', _BUNDLER_HIJACK_RE)

    if _PYPROJECT_BUILD_RE.search(text):
        _emit('malicious build dependency in pyproject', _PYPROJECT_BUILD_RE)

    if _PACKAGE_JSON_TYPOS_RE.search(text) and _PACKAGE_JSON_CONTEXT_RE.search(text):
        _emit('package.json typosquatting', _PACKAGE_JSON_TYPOS_RE)

    if _TYPOSQUATTING_RE.search(text) and _TYPOSQUATTING_INDICATOR_RE.search(text):
        already = any(t['mechanism'].startswith(('Gemfile', 'requirements', 'package.json')) for t in threats)
        if not already:
            _emit('npm typosquatting indicators', _TYPOSQUATTING_RE)

    return threats


# =============================================================================
# Detector 6: detect_resource_abuse (weight 5)
# =============================================================================

def detect_resource_abuse(text: str) -> list[dict]:
    """Detect resource exhaustion and denial-of-service patterns.

    Rules (mostly standalone due to specificity):
    - crypto mining patterns
    - fork bomb patterns (bash/python/node)
    - resource exhaustion (buffer alloc in infinite loop)
    - cluster fork bomb + CPU count
    - thread compute loop
    - buffer exhaustion
    - python fork bomb (multiprocessing + loop + cpu_count)
    - HTTP stress test compound
    - large-scale file generation
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _RESOURCE_KEYWORDS):
        return threats

    def _emit(mechanism: str, pat: 're.Pattern') -> None:
        match = pat.search(text)
        if match:
            threats.append(_make_code_threat('resource_abuse', text, match, mechanism))

    if _CRYPTO_MINING_RE.search(text):
        _emit('crypto mining indicators', _CRYPTO_MINING_RE)

    if _FORK_BOMB_RE.search(text):
        _emit('fork bomb pattern', _FORK_BOMB_RE)

    if _RESOURCE_EXHAUST_RE.search(text):
        _emit('resource exhaustion (buffer/array in loop)', _RESOURCE_EXHAUST_RE)

    if _CLUSTER_FORK_RE.search(text) and _CPU_COUNT_RE.search(text):
        _emit('cluster fork bomb with CPU count', _CLUSTER_FORK_RE)

    if _THREAD_COMPUTE_RE.search(text):
        _emit('thread compute infinite loop', _THREAD_COMPUTE_RE)

    if _BUFFER_EXHAUST_RE.search(text):
        _emit('buffer exhaustion in infinite loop', _BUFFER_EXHAUST_RE)

    if (_PYTHON_FORK_BOMB_RE.search(text) and _PYTHON_FORK_LOOP_RE.search(text)
            and _PYTHON_FORK_CPU_RE.search(text)):
        _emit('python multiprocessing fork bomb', _PYTHON_FORK_BOMB_RE)

    if _HTTP_STRESS_RE.search(text) and _HTTP_STRESS_CONTEXT_RE.search(text):
        _emit('HTTP stress test / DDoS pattern', _HTTP_STRESS_RE)

    if _LARGE_SCALE_FILE_RE.search(text) and _FILE_WRITE_RE.search(text):
        _emit('large-scale file generation', _LARGE_SCALE_FILE_RE)

    return threats


# =============================================================================
# Detector 7: detect_privilege_escalation (weight 5)
# =============================================================================

def detect_privilege_escalation(text: str) -> list[dict]:
    """Detect privilege escalation patterns.

    Rules:
    - sudo abuse, chmod SUID, NOPASSWD, setuid(0) standalone
    - sysctl kernel security bypass compound
    - polkit rule allowing unrestricted exec compound
    - AppArmor/SELinux overpermissive rules compound
    - systemd service with disabled security compound
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _PRIVESC_KEYWORDS):
        return threats

    def _emit(mechanism: str, pat: 're.Pattern') -> None:
        match = pat.search(text)
        if match:
            threats.append(_make_code_threat('privilege_escalation', text, match, mechanism))

    if _PRIVESC_RE.search(text):
        _emit('sudo/chmod/setuid privilege escalation', _PRIVESC_RE)

    if _SYSCTL_BYPASS_RE.search(text) and _SYSCTL_TARGET_RE.search(text):
        _emit('sysctl kernel security bypass', _SYSCTL_BYPASS_RE)

    if _POLKIT_RE.search(text) and _POLKIT_ALLOW_RE.search(text):
        _emit('polkit privilege escalation', _POLKIT_RE)

    if _APPARMOR_RE.search(text) and _APPARMOR_PERM_RE.search(text) and _APPARMOR_WRITE_RE.search(text):
        _emit('AppArmor/SELinux overpermissive profile', _APPARMOR_RE)

    if _SYSTEMD_BYPASS_RE.search(text) and _SYSTEMD_CONTEXT_RE.search(text):
        _emit('systemd security feature bypass', _SYSTEMD_BYPASS_RE)

    return threats


# =============================================================================
# Detector 8: detect_persistence_mechanism (weight 5)
# =============================================================================

def detect_persistence_mechanism(text: str) -> list[dict]:
    """Detect persistence mechanisms (cron, bashrc, SSH, services).

    Compound rules:
    - crontab/rc.local/bashrc + curl/wget/exec
    - SSH key injection standalone (specific)
    - cron + network/subprocess compound
    - shell config backdoor (.bashrc + reverse shell)
    - PM2 ecosystem + scheduled restart
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _PERSIST_KEYWORDS):
        return threats

    def _emit(mechanism: str, pat: 're.Pattern') -> None:
        match = pat.search(text)
        if match:
            threats.append(_make_code_threat('persistence_mechanism', text, match, mechanism))

    if _PERSISTENCE_RE.search(text):
        _emit('crontab/rc.local/bashrc persistence', _PERSISTENCE_RE)

    if _SSH_INJECTION_RE.search(text):
        _emit('SSH authorized_keys injection', _SSH_INJECTION_RE)

    if (_CRON_PERSIST_RE.search(text) and
            (_NETWORK_CALL_RE.search(text) or _SUBPROCESS_RE.search(text) or _CRON_EXEC_RE.search(text))):
        already = any(t['mechanism'].startswith('crontab') for t in threats)
        if not already:
            _emit('cron persistence + exec/network', _CRON_PERSIST_RE)

    if _SHELL_CONFIG_BACKDOOR_RE.search(text) and _SHELL_CONFIG_EXEC_RE.search(text):
        _emit('shell config backdoor (.bashrc/.zshrc + exec)', _SHELL_CONFIG_BACKDOOR_RE)

    if _PM2_RE.search(text) and _PM2_SCHEDULE_RE.search(text):
        _emit('PM2 ecosystem with scheduled restart', _PM2_RE)

    return threats


# =============================================================================
# Detector 9: detect_c2_beacon (weight 6)
# =============================================================================

def detect_c2_beacon(text: str) -> list[dict]:
    """Detect command-and-control beacon patterns.

    Compound rules:
    - setInterval/setTimeout + fetch + process.env
    - TCP proxy listener + env access
    - WebSocket + exec/command
    - beacon (interval + HTTP call) + env access
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _C2_KEYWORDS):
        return threats

    def _emit(mechanism: str, pat: 're.Pattern') -> None:
        match = pat.search(text)
        if match:
            threats.append(_make_code_threat('c2_beacon', text, match, mechanism))

    if _C2_BEACON_RE.search(text):
        _emit('C2 command loop (interval + fetch + env)', _C2_BEACON_RE)

    if _TCP_PROXY_LISTEN_RE.search(text) and _TCP_PROXY_ENV_RE.search(text):
        _emit('TCP proxy listener + env access', _TCP_PROXY_LISTEN_RE)

    if _WEBSOCKET_C2_RE.search(text) and _WEBSOCKET_EXEC_RE.search(text):
        _emit('WebSocket C2 + exec/command', _WEBSOCKET_C2_RE)

    has_env = bool(_ENV_ACCESS_RE.search(text))
    if _BEACON_RE.search(text) and has_env:
        already = any(t['mechanism'].startswith('C2 command') for t in threats)
        if not already:
            _emit('periodic beacon + env access', _BEACON_RE)

    return threats


# =============================================================================
# Detector 10: detect_code_steganography (weight 4)
# =============================================================================

def detect_code_steganography(text: str) -> list[dict]:
    """Detect code-level steganography and encoding evasion.

    Compound rules (encoding method + exec/eval required):
    - charCode + eval/exec
    - zlib inflate + eval
    - ROT13/caesar + eval
    - hex charCode + eval
    - bit-shift encoding + eval
    - base64 decode + exec
    - charCode array + fromCharCode + exec
    - CSS base64 steganography
    - enum/const bit-shift encoding
    - obfuscated exec (base64+eval compound)
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _STEG_KEYWORDS):
        return threats

    def _emit(mechanism: str, pat: 're.Pattern') -> None:
        match = pat.search(text)
        if match:
            threats.append(_make_code_threat('code_steganography', text, match, mechanism))

    if _CHARCODE_EXEC_RE.search(text):
        _emit('String.fromCharCode + eval/exec', _CHARCODE_EXEC_RE)

    if _ZLIB_INFLATE_RE.search(text):
        _emit('zlib inflate + eval/exec', _ZLIB_INFLATE_RE)
    elif _ZLIB_CONTEXT_RE.search(text) and _EVAL_EXEC_RE.search(text):
        _emit('zlib/pako + eval/exec', _ZLIB_CONTEXT_RE)

    if _ROT13_RE.search(text) and _EVAL_EXEC_RE.search(text):
        _emit('ROT13/caesar cipher + eval/exec', _ROT13_RE)

    if _HEX_CHARCODE_RE.search(text):
        _emit('hex charCode encoding + eval/exec', _HEX_CHARCODE_RE)

    if _BIT_SHIFT_RE.search(text) and _BIT_SHIFT_EXEC_RE.search(text):
        _emit('bit-shift encoding + eval/exec', _BIT_SHIFT_RE)

    if _BASE64_EXEC_RE.search(text) and _BASE64_EXEC_TARGET_RE.search(text):
        _emit('base64 decode + exec/eval', _BASE64_EXEC_RE)

    if (_CHARCODE_ARRAY_RE.search(text) and _FROMCHARCODE_RE.search(text)
            and _CHARCODE_ARRAY_EXEC_RE.search(text)):
        _emit('charCode array + fromCharCode + exec', _CHARCODE_ARRAY_RE)

    if _CSS_BASE64_STEG_RE.search(text) and _CSS_BASE64_CONTEXT_RE.search(text):
        _emit('CSS base64 steganography', _CSS_BASE64_STEG_RE)

    if _ENUM_BITSHIFT_RE.search(text) and _ENUM_BITSHIFT_CONTEXT_RE.search(text):
        _emit('enum/const bit-shift encoding', _ENUM_BITSHIFT_RE)

    if _OBFUSCATED_EXEC_RE.search(text):
        already = any('base64' in t['mechanism'] for t in threats)
        if not already:
            _emit('obfuscated base64 + eval/exec', _OBFUSCATED_EXEC_RE)

    return threats


# =============================================================================
# Detector 11: detect_encoded_prompt_injection (weight 4)
# =============================================================================

def detect_encoded_prompt_injection(text: str) -> list[dict]:
    """Detect prompt injection hidden via encoding or embedded in code structures.

    Compound rules:
    - base64/hex encoded content + PI keywords
    - i18n/OpenAPI config with hidden instructions
    - JSDoc @internal with AI-targeted instructions
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _ENC_PI_KEYWORDS):
        return threats

    def _emit(mechanism: str, pat: 're.Pattern') -> None:
        match = pat.search(text)
        if match:
            threats.append(_make_code_threat('encoded_prompt_injection', text, match, mechanism))

    if _ENCODED_PI_RE.search(text):
        _emit('encoded content with prompt injection keywords', _ENCODED_PI_RE)
    elif _ENCODED_PI_ALT_RE.search(text):
        _emit('base64 string near decode/override keywords', _ENCODED_PI_ALT_RE)

    if _CONFIG_INJECTION_RE.search(text):
        _emit('config/i18n/OpenAPI with hidden instructions', _CONFIG_INJECTION_RE)

    if _JSDOC_AI_RE.search(text):
        _emit('JSDoc @internal with AI instruction', _JSDOC_AI_RE)

    return threats


# =============================================================================
# Detector 12: detect_advanced_prompt_override (weight 4)
# =============================================================================

def detect_advanced_prompt_override(text: str) -> list[dict]:
    """Detect advanced prompt override / jailbreak patterns in code context.

    Only fires when advanced PI patterns appear alongside code context indicators,
    to avoid overlap with the existing detect_injection_patterns detector which
    handles plaintext PI.

    Compound rule: advanced PI keywords AND code context.
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _ADV_PI_KEYWORDS):
        return threats

    if _ADVANCED_PI_RE.search(text) and _CODE_CONTEXT_RE.search(text):
        match = _ADVANCED_PI_RE.search(text)
        if match:
            threats.append(_make_code_threat(
                'advanced_prompt_override', text, match,
                'advanced prompt override in code context',
            ))

    return threats


# =============================================================================
# Detector 13: detect_container_escape (weight 6)
# =============================================================================

def detect_container_escape(text: str) -> list[dict]:
    """Detect container escape and Kubernetes attack patterns.

    Rules:
    - container escape standalone (nsenter, docker.sock -- highly specific)
    - K8s attack patterns (hostPID, SYS_ADMIN, service account token)
    - firewall disable standalone
    """
    threats = []
    text_lower = text.lower()
    if not _has_any_keyword(text_lower, _CONTAINER_KEYWORDS):
        return threats

    ce_match = _CONTAINER_ESCAPE_RE.search(text)
    if ce_match:
        threats.append(_make_code_threat(
            'container_escape', text, ce_match, 'container escape (nsenter/docker.sock)',
        ))

    k8s_match = _K8S_ATTACK_RE.search(text)
    if k8s_match:
        threats.append(_make_code_threat(
            'container_escape', text, k8s_match, 'Kubernetes attack (hostPID/SYS_ADMIN)',
        ))

    fw_match = _FIREWALL_DISABLE_RE.search(text)
    if fw_match:
        threats.append(_make_code_threat(
            'container_escape', text, fw_match, 'firewall disable',
        ))

    return threats


# Ensure patterns are loaded on import
_ensure_loaded()
