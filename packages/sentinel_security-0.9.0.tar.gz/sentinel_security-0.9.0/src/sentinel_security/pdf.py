"""
PDF scanner for hidden content and prompt injection.

Uses PyMuPDF (fitz) to detect:
- Injection patterns in page text
- Suspicious annotations (comments, sticky notes)
- Metadata field injection
- Form field (AcroForm) injection
- Embedded JavaScript actions (always HIGH risk)
- Invisible text (rendering mode 3, white-on-white)
- Bookmark/outline title injection
"""

import logging
import re
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

try:
    import fitz  # PyMuPDF
except ImportError:  # pragma: no cover
    fitz = None

from .patterns import INJECTION_PATTERNS
from .sanitiser import calculate_risk_score, sanitise_content


def scan_pdf(file_path: str) -> dict:
    """
    Scan a PDF file for hidden content and prompt injection.

    Args:
        file_path: Path to the PDF file.

    Returns:
        dict with keys:
            file (str): File path.
            pages (int): Page count.
            threats (list): Detected threats with type, severity, detail, source.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
            scanned_surfaces (dict): Count of each surface type scanned.
    """
    if fitz is None:
        raise ImportError(
            "PyMuPDF required for PDF scanning. "
            "Install with: pip install sentinel-security[pdf]"
        )

    logger.debug("scan_pdf: start file=%s", file_path)
    threats: List[Dict[str, Any]] = []
    scanned_surfaces = {
        "pages": 0,
        "annotations": 0,
        "metadata_fields": 0,
        "form_fields": 0,
        "bookmarks": 0,
        "javascript_actions": 0,
    }

    try:
        doc = fitz.open(file_path)
    except Exception as e:
        raise ValueError(f"Failed to open PDF file: {e}")

    page_count = len(doc)
    scanned_surfaces["pages"] = page_count

    # --- 1. Page text ---
    for page_num in range(page_count):
        page = doc[page_num]
        text = page.get_text("text")
        if text and text.strip():
            result = sanitise_content(text, format="text")
            for t in result["threats"]:
                t["source"] = f"page_{page_num + 1}_text"
                threats.append(t)

    # --- 2. Annotations ---
    for page_num in range(page_count):
        page = doc[page_num]
        annots = page.annots()
        if not annots:
            continue
        for annot in annots:
            scanned_surfaces["annotations"] += 1
            content = annot.info.get("content", "")
            if content and content.strip():
                result = sanitise_content(content, format="text")
                for t in result["threats"]:
                    t["source"] = f"annotation_page_{page_num + 1}"
                    threats.append(t)

    # --- 3. Metadata ---
    metadata = doc.metadata or {}
    metadata_keys = ["title", "author", "subject", "keywords", "producer", "creator"]
    for key in metadata_keys:
        value = metadata.get(key, "")
        if value and value.strip():
            scanned_surfaces["metadata_fields"] += 1
            result = sanitise_content(value, format="text")
            for t in result["threats"]:
                t["source"] = f"metadata_{key}"
                threats.append(t)

    # --- 4. Form fields (AcroForm) ---
    try:
        for page_num in range(page_count):
            page = doc[page_num]
            widgets = page.widgets()
            if widgets:
                for widget in widgets:
                    scanned_surfaces["form_fields"] += 1
                    field_name = widget.field_name or "unnamed"
                    field_value = widget.field_value or ""
                    if field_value and str(field_value).strip():
                        result = sanitise_content(str(field_value), format="text")
                        for t in result["threats"]:
                            t["source"] = f"form_field_{field_name}"
                            threats.append(t)
    except Exception as e:
        logger.warning("Failed to scan PDF form fields: %s", e)

    # --- 5. Embedded JavaScript ---
    # Document-level JavaScript
    try:
        js = doc.get_page_labels()  # noqa: just checking doc is valid
    except Exception as e:
        logger.warning("Failed to validate PDF doc via get_page_labels: %s", e)

    # Check for JavaScript in page actions and annotation actions
    for page_num in range(page_count):
        page = doc[page_num]
        # Page-level JS actions
        _check_page_js(page, page_num, threats, scanned_surfaces)
        # Annotation-level JS actions
        annots = page.annots()
        if not annots:
            continue
        for annot in annots:
            _check_annot_js(annot, page_num, threats, scanned_surfaces)

    # Document-level JS via catalog
    _check_document_js(doc, threats, scanned_surfaces)

    # --- 6. Invisible text ---
    for page_num in range(page_count):
        page = doc[page_num]
        _check_invisible_text(page, page_num, threats)

    # --- 7. Bookmark/outline titles ---
    toc = doc.get_toc()
    for i, entry in enumerate(toc):
        scanned_surfaces["bookmarks"] += 1
        title = entry[1] if len(entry) > 1 else ""
        if title and title.strip():
            result = sanitise_content(title, format="text")
            for t in result["threats"]:
                t["source"] = f"bookmark_{i + 1}"
                threats.append(t)

    doc.close()

    logger.debug("scan_pdf: end file=%s pages=%d threats=%d", file_path, page_count, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_pdf: threats detected count=%d types=%s file=%s", len(threats), types, file_path)
    risk_score = calculate_risk_score(threats)
    return {
        "file": file_path,
        "pages": page_count,
        "threats": threats,
        "threat_count": len(threats),
        "risk_score": risk_score,
        "risk_level": (
            "CLEAN" if risk_score == 0 else
            "LOW" if risk_score <= 2 else
            "MEDIUM" if risk_score <= 5 else
            "HIGH" if risk_score <= 8 else
            "CRITICAL"
        ),
        "scanned_surfaces": scanned_surfaces,
    }


def _check_page_js(page, page_num, threats, scanned_surfaces):
    """Check a page for JavaScript actions."""
    try:
        # Access the page's /AA (additional actions) dictionary
        page_obj = page.xref
        doc = page.parent
        xref_str = doc.xref_object(page_obj)
        if "/JS" in xref_str or "/JavaScript" in xref_str:
            scanned_surfaces["javascript_actions"] += 1
            threats.append({
                "type": "pdf_javascript",
                "severity": "HIGH",
                "detail": f"JavaScript action found on page {page_num + 1}.",
                "source": f"javascript_page_{page_num + 1}",
            })
    except Exception as e:
        logger.warning("Failed to check page JS actions: %s", e)


def _check_annot_js(annot, page_num, threats, scanned_surfaces):
    """Check an annotation for JavaScript actions."""
    try:
        doc = annot.parent.parent
        xref = annot.xref
        xref_str = doc.xref_object(xref)
        if "/JS" in xref_str or "/JavaScript" in xref_str:
            scanned_surfaces["javascript_actions"] += 1
            threats.append({
                "type": "pdf_javascript",
                "severity": "HIGH",
                "detail": f"JavaScript action found in annotation on page {page_num + 1}.",
                "source": f"javascript_annotation_page_{page_num + 1}",
            })
    except Exception as e:
        logger.warning("Failed to check annotation JS actions: %s", e)


def _check_document_js(doc, threats, scanned_surfaces):
    """Check for document-level JavaScript."""
    try:
        # Check the catalog for /Names -> /JavaScript
        cat = doc.pdf_catalog()
        cat_str = doc.xref_object(cat)
        if "/JavaScript" in cat_str or "/JS" in cat_str:
            scanned_surfaces["javascript_actions"] += 1
            threats.append({
                "type": "pdf_javascript",
                "severity": "HIGH",
                "detail": "Document-level JavaScript detected.",
                "source": "javascript_document",
            })
    except Exception as e:
        logger.warning("Failed to check document-level JavaScript: %s", e)

    # Also check OpenAction
    try:
        cat = doc.pdf_catalog()
        cat_str = doc.xref_object(cat)
        if "/OpenAction" in cat_str:
            # Resolve the OpenAction reference to check for JS
            # Look for /JS in the referenced object
            for xref in range(1, doc.xref_length()):
                try:
                    obj_str = doc.xref_object(xref)
                    if "/S /JavaScript" in obj_str or "/S/JavaScript" in obj_str:
                        scanned_surfaces["javascript_actions"] += 1
                        threats.append({
                            "type": "pdf_javascript",
                            "severity": "HIGH",
                            "detail": "JavaScript in OpenAction detected.",
                            "source": "javascript_openaction",
                        })
                        break
                except Exception as e:
                    logger.warning("Failed to check xref object for JavaScript: %s", e)
    except Exception as e:
        logger.warning("Failed to check OpenAction JavaScript: %s", e)


def _check_invisible_text(page, page_num, threats):
    """Detect invisible text on a page (render mode 3 or white-on-white)."""
    try:
        blocks = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)["blocks"]
        for block in blocks:
            if block.get("type") != 0:  # Only text blocks
                continue
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    text = span.get("text", "").strip()
                    if not text:
                        continue

                    # Check rendering mode (flags field, bits 0-1 indicate
                    # rendering mode but PyMuPDF doesn't directly expose mode 3).
                    # Instead, check for white-on-white or near-invisible colors.
                    color = span.get("color", 0)
                    # color is an integer: 0xRRGGBB
                    r = (color >> 16) & 0xFF
                    g = (color >> 8) & 0xFF
                    b = color & 0xFF

                    # White or near-white text on what we assume is a white page
                    if r >= 250 and g >= 250 and b >= 250:
                        threats.append({
                            "type": "invisible_text",
                            "severity": "HIGH",
                            "detail": f"Near-invisible (white) text on page {page_num + 1}.",
                            "source": f"page_{page_num + 1}_invisible",
                            "text_preview": text[:100],
                        })

                    # Very small font (less than 1pt)
                    size = span.get("size", 12)
                    if size < 1.0:
                        threats.append({
                            "type": "invisible_text",
                            "severity": "HIGH",
                            "detail": f"Extremely small text ({size}pt) on page {page_num + 1}.",
                            "source": f"page_{page_num + 1}_invisible",
                            "text_preview": text[:100],
                        })
    except Exception as e:
        logger.warning("Failed to check for invisible text: %s", e)


