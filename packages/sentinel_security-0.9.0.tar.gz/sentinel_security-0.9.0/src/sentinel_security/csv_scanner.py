"""
CSV/TSV scanner for formula injection and prompt injection attacks.

Detects:
- Formula injection attacks (cells starting with =, +, -, @, \t, \r)
- Text injection in cell values using sanitise_content()
- Injection in header rows
"""

import csv
import logging
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

from .sanitiser import calculate_risk_score, sanitise_content

from .sanitiser.scorer import risk_level

def scan_csv(file_path: str, delimiter: Optional[str] = None) -> dict:
    """
    Scan a CSV/TSV file for formula injection and prompt injection attacks.

    Args:
        file_path: Path to the CSV/TSV file.
        delimiter: CSV delimiter character. If None, auto-detect using csv.Sniffer.

    Returns:
        dict with keys:
            file (str): File path.
            rows (int): Total number of rows.
            columns (int): Total number of columns.
            threats (list): Detected threats with row/col/cell coordinates.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
            scanned_cells (int): Total number of cells scanned.

    Raises:
        FileNotFoundError: If file doesn't exist.
        ValueError: If file is not a valid CSV/TSV file.
    """
    logger.debug("scan_csv: start file=%s", file_path)
    threats: List[Dict[str, Any]] = []
    scanned_cells = 0
    
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    try:
        with open(file_path, 'r', newline='', encoding='utf-8') as f:
            # Read sample for delimiter detection
            sample = f.read(1024)
            f.seek(0)
            
            if delimiter is None:
                try:
                    sniffer = csv.Sniffer()
                    dialect = sniffer.sniff(sample)
                    delimiter = dialect.delimiter
                except csv.Error:
                    # Default to comma if detection fails
                    delimiter = ','
            
            reader = csv.reader(f, delimiter=delimiter)
            rows = list(reader)
            
    except Exception as e:
        raise ValueError(f"Failed to read CSV file: {e}")
    
    if not rows:
        return {
            'file': file_path,
            'rows': 0,
            'columns': 0,
            'threats': [],
            'threat_count': 0,
            'risk_score': 0,
            'risk_level': 'CLEAN',
            'scanned_cells': 0
        }
    
    total_rows = len(rows)
    total_cols = max(len(row) for row in rows) if rows else 0
    
    # Scan header row (first row)
    if rows:
        header_row = rows[0]
        for col_idx, cell_value in enumerate(header_row):
            scanned_cells += 1
            if cell_value:
                # Check for formula injection in header
                formula_threat = _check_formula_injection(cell_value, 0, col_idx)
                if formula_threat:
                    threats.append(formula_threat)
                
                # Check for text injection in header
                text_threats = _check_text_injection(cell_value, 0, col_idx)
                threats.extend(text_threats)
    
    # Scan data rows (skip header if present)
    start_row = 1 if rows else 0
    for row_idx in range(start_row, total_rows):
        row = rows[row_idx]
        for col_idx, cell_value in enumerate(row):
            scanned_cells += 1
            if cell_value:
                # Check for formula injection
                formula_threat = _check_formula_injection(cell_value, row_idx, col_idx)
                if formula_threat:
                    threats.append(formula_threat)
                
                # Check for text injection
                text_threats = _check_text_injection(cell_value, row_idx, col_idx)
                threats.extend(text_threats)
    
    risk_score = calculate_risk_score(threats)
    logger.debug("scan_csv: end file=%s cells=%d threats=%d", file_path, scanned_cells, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_csv: threats detected count=%d types=%s file=%s", len(threats), types, file_path)
    
    return {
        'file': file_path,
        'rows': total_rows,
        'columns': total_cols,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
        'scanned_cells': scanned_cells
    }


def _check_formula_injection(cell_value: str, row_idx: int, col_idx: int) -> Optional[Dict[str, Any]]:
    """
    Check if a cell contains formula injection.
    
    Formula injection attacks start with =, +, -, @, \t, \r (DDE attacks).
    """
    if not cell_value:
        return None
    
    # Check for DDE attacks (tab or carriage return at start) - check before stripping
    if cell_value.startswith('\t') or cell_value.startswith('\r'):
        return {
            'type': 'formula_injection',
            'row': row_idx,
            'col': col_idx,
            'cell': _get_cell_reference(row_idx, col_idx),
            'value': cell_value[:100],
            'prefix': '\\t' if cell_value.startswith('\t') else '\\r',
            'description': 'DDE attack detected (tab or carriage return at start)'
        }
    
    # Strip leading whitespace for detection (but not \t or \r since we already checked)
    stripped = cell_value.lstrip(' \n')
    if not stripped:
        return None
    
    first_char = stripped[0]
    
    # Check for formula injection prefixes
    if first_char in ('=', '+', '-', '@'):
        return {
            'type': 'formula_injection',
            'row': row_idx,
            'col': col_idx,
            'cell': _get_cell_reference(row_idx, col_idx),
            'value': cell_value[:100],  # Truncate for display
            'prefix': first_char,
            'description': f'Formula injection detected with prefix "{first_char}"'
        }
    
    return None


def _check_text_injection(cell_value: str, row_idx: int, col_idx: int) -> List[Dict[str, Any]]:
    """
    Check if a cell contains text injection using sanitise_content().
    """
    threats = []
    
    if not cell_value:
        return threats
    
    # Use sanitise_content to detect injection patterns
    result = sanitise_content(cell_value, format='text')
    
    if result['threat_count'] > 0:
        for threat in result['threats']:
            threats.append({
                'type': 'text_injection',
                'row': row_idx,
                'col': col_idx,
                'cell': _get_cell_reference(row_idx, col_idx),
                'value': cell_value[:100],
                'injection_type': threat['type'],
                'matched': threat.get('matched', ''),
                'description': f'Text injection detected: {threat.get("type", "unknown")}'
            })
    
    return threats


def _get_cell_reference(row_idx: int, col_idx: int) -> str:
    """
    Convert row/column indices to Excel-style cell reference (e.g., A1, B3).
    
    Args:
        row_idx: Zero-based row index.
        col_idx: Zero-based column index.
    
    Returns:
        Excel-style cell reference.
    """
    # Convert column index to letters (A, B, ..., Z, AA, AB, ...)
    col_letters = ''
    col = col_idx + 1  # Convert to 1-based
    
    while col > 0:
        col, remainder = divmod(col - 1, 26)
        col_letters = chr(65 + remainder) + col_letters
    
    # Convert row index to 1-based
    row = row_idx + 1
    
    return f'{col_letters}{row}'