"""
Image metadata scanner for prompt injection detection.

Extracts text from image metadata fields (EXIF, IPTC, XMP) and scans for
injection patterns using the core sanitisation engine.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)
from typing import Any, Dict, List, Optional
from .sanitiser.scorer import risk_level

try:
    from PIL import Image, ExifTags, ImageFile  # type: ignore

    # Enable loading truncated images
    ImageFile.LOAD_TRUNCATED_IMAGES = True
except ImportError:  # pragma: no cover
    Image = None
    ExifTags = None
    ImageFile = None

from .sanitiser import sanitise_content


def _get_exif_text_fields(img: Image.Image) -> Dict[str, str]:
    """Extract text fields from EXIF metadata."""
    fields = {}
    
    try:
        exif_data = img._getexif()
        if not exif_data:
            return fields
        
        # Map of EXIF tag IDs to field names
        exif_text_tags = {
            270: "ImageDescription",      # 0x010E
            315: "Artist",                # 0x013B
            33432: "Copyright",           # 0x8298
            37510: "UserComment",         # 0x9286
            40091: "XPTitle",             # Windows XP Title
            40092: "XPComment",           # Windows XP Comment
            40093: "XPSubject",           # Windows XP Subject
            40094: "XPKeywords",          # Windows XP Keywords
        }
        
        for tag_id, field_name in exif_text_tags.items():
            if tag_id in exif_data:
                value = exif_data[tag_id]
                if isinstance(value, (str, bytes)):
                    if isinstance(value, bytes):
                        try:
                            # Try to decode as UTF-8, fall back to latin-1
                            value = value.decode('utf-8', errors='replace')
                        except Exception as e:
                            logger.debug("EXIF extraction failed: %s", e)
                            value = value.decode('latin-1', errors='replace')
                    if value and value.strip():
                        fields[f"exif_{field_name}"] = value.strip()
    
    except Exception as e:
        logger.warning("_get_exif_text_fields: failed: %s", e)
    
    return fields


def _get_iptc_text_fields(img: Image.Image) -> Dict[str, str]:
    """Extract text fields from IPTC metadata."""
    fields = {}
    
    try:
        # IPTC tags are accessed via img.info.get('iptc')
        iptc_data = img.info.get('iptc')
        if not iptc_data:
            return fields
        
        # IPTC tags are tuples (dataset, record)
        iptc_text_tags = {
            (2, 120): "Caption",           # Caption/Abstract
            (2, 105): "Headline",          # Headline
            (2, 40): "SpecialInstructions", # Special Instructions
            (2, 80): "Byline",             # By-line
        }
        
        # iptc_data is a dict with byte keys
        for (dataset, record), field_name in iptc_text_tags.items():
            key = bytes([dataset, record])
            if key in iptc_data:
                value = iptc_data[key]
                if isinstance(value, bytes):
                    try:
                        value = value.decode('utf-8', errors='replace')
                    except Exception as e:
                        logger.debug("EXIF extraction failed: %s", e)
                        value = value.decode('latin-1', errors='replace')
                if value and value.strip():
                    fields[f"iptc_{field_name}"] = value.strip()
    
    except Exception as e:
        logger.warning("_get_iptc_text_fields: failed: %s", e)
    
    return fields


def _get_xmp_text_fields(img: Image.Image) -> Dict[str, str]:
    """Extract text fields from XMP metadata."""
    fields = {}
    
    try:
        # XMP is stored in img.info.get('xml')
        xmp_data = img.info.get('xml')
        if not xmp_data:
            return fields
        
        # Parse XMP XML for common text fields
        import xml.etree.ElementTree as ET
        from xml.etree.ElementTree import ParseError
        
        try:
            # XMP is XML with namespaces
            root = ET.fromstring(xmp_data)
            
            # Common XMP namespaces
            ns = {
                'dc': 'http://purl.org/dc/elements/1.1/',
                'xmp': 'http://ns.adobe.com/xap/1.0/',
                'rdf': 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
            }
            
            # Look for dc:description, dc:title, dc:subject
            xmp_fields = [
                ('dc:description', 'description'),
                ('dc:title', 'title'),
                ('dc:subject', 'subject'),
            ]
            
            for xpath, field_name in xmp_fields:
                # Try to find the element
                elements = root.findall(f'.//{{{ns["dc"]}}}{field_name}', ns)
                if not elements:
                    # Try alternative path
                    elements = root.findall(f'.//{xpath}')
                
                for elem in elements:
                    if elem.text and elem.text.strip():
                        fields[f"xmp_{xpath}"] = elem.text.strip()
        
        except (ParseError, KeyError, AttributeError):
            # Fallback: search for text in XMP XML
            import re
            xmp_text_patterns = [
                (r'<dc:description[^>]*>([^<]+)</dc:description>', 'xmp_dc:description'),
                (r'<dc:title[^>]*>([^<]+)</dc:title>', 'xmp_dc:title'),
                (r'<dc:subject[^>]*>([^<]+)</dc:subject>', 'xmp_dc:subject'),
            ]
            
            for pattern, field_name in xmp_text_patterns:
                match = re.search(pattern, xmp_data, re.IGNORECASE)
                if match:
                    text = match.group(1).strip()
                    if text:
                        fields[field_name] = text
    
    except Exception as e:
        logger.warning("_get_xmp_text_fields: failed: %s", e)
    
    return fields


def _get_png_text_chunks(img: Image.Image) -> Dict[str, str]:
    """Extract text chunks from PNG metadata."""
    fields = {}
    
    try:
        # PNG text chunks are stored in img.info as key-value pairs
        if img.format == 'PNG':
            for key, value in img.info.items():
                # PNG text chunks can be strings or bytes
                if isinstance(value, (str, bytes)):
                    if isinstance(value, bytes):
                        try:
                            value = value.decode('utf-8', errors='replace')
                        except Exception as e:
                            logger.debug("EXIF extraction failed: %s", e)
                            value = value.decode('latin-1', errors='replace')
                    if value and value.strip():
                        fields[f"png_{key}"] = value.strip()
    
    except Exception as e:
        logger.warning("_get_png_text_chunks: failed: %s", e)
    
    return fields


def scan_image_metadata(file_path: str) -> dict:
    """
    Scan image metadata for prompt injection threats.
    
    Extracts text from EXIF, IPTC, XMP, and PNG text chunks, then runs
    each field through the sanitisation engine.
    
    Args:
        file_path: Path to image file (JPEG, PNG, TIFF, WebP)
        
    Returns:
        dict with keys:
            file: Original file path
            format: Image format (jpeg, png, tiff, webp)
            threats: List of detected threats with source field
            threat_count: Total number of threats found
            risk_score: 0-10 severity score
            risk_level: CLEAN / LOW / MEDIUM / HIGH / CRITICAL
            metadata_fields_scanned: Number of metadata fields scanned
            scanned_surfaces: Dict with counts per metadata type
            
    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If file is not a supported image format
        IOError: If image is corrupted or cannot be read
    """
    if Image is None:
        raise ImportError(
            "Pillow required for image metadata scanning. "
            "Install with: pip install sentinel-security[image]"
        )

    logger.debug("scan_image_metadata: start file=%s", file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Image file not found: {file_path}")
    
    try:
        img = Image.open(file_path)
        img.verify()  # Verify image integrity
        img = Image.open(file_path)  # Re-open after verify
        
        # Get image format
        img_format = img.format.lower() if img.format else 'unknown'
        
        # Extract metadata from all sources
        all_fields = {}
        
        # EXIF fields
        exif_fields = _get_exif_text_fields(img)
        all_fields.update(exif_fields)
        
        # IPTC fields
        iptc_fields = _get_iptc_text_fields(img)
        all_fields.update(iptc_fields)
        
        # XMP fields
        xmp_fields = _get_xmp_text_fields(img)
        all_fields.update(xmp_fields)
        
        # PNG text chunks (if applicable)
        png_fields = _get_png_text_chunks(img)
        all_fields.update(png_fields)
        
        # Scan each field for threats
        all_threats = []
        for source, text in all_fields.items():
            result = sanitise_content(text, format='text')
            for threat in result['threats']:
                # Add source field to threat for tracking
                threat['source'] = source
                all_threats.append(threat)
        
        logger.debug("scan_image_metadata: end file=%s fields=%d threats=%d", file_path, len(all_fields), len(all_threats))
        if all_threats:
            types = list({t.get("type") for t in all_threats})
            logger.info("scan_image_metadata: threats detected count=%d types=%s file=%s", len(all_threats), types, file_path)
        # Calculate overall risk
        from .sanitiser import calculate_risk_score
        risk_score = calculate_risk_score(all_threats)
        
        # Count scanned surfaces
        scanned_surfaces = {
            'exif': len(exif_fields),
            'iptc': len(iptc_fields),
            'xmp': len(xmp_fields),
            'png': len(png_fields),
        }
        
        return {
            'file': file_path,
            'format': img_format,
            'threats': all_threats,
            'threat_count': len(all_threats),
            'risk_score': risk_score,
            'risk_level': risk_level(risk_score),
            'metadata_fields_scanned': len(all_fields),
            'scanned_surfaces': scanned_surfaces,
        }
        
    except Exception as e:
        # Re-raise as ValueError for unsupported/corrupted images
        raise ValueError(f"Cannot read image file {file_path}: {str(e)}")
