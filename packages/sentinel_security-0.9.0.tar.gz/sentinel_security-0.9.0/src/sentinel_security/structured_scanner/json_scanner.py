"""JSON scanner -- detects prompt injection in JSON string values."""

import json
import logging
import os
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

from ..sanitiser import calculate_risk_score, sanitise_content

from ..sanitiser.scorer import risk_level

def scan_json(file_path_or_text: str, is_file: bool = True) -> dict:
    """
    Scan JSON content for prompt injection attacks.

    Args:
        file_path_or_text: Path to JSON file or JSON text content.
        is_file: True if first argument is a file path, False if it's JSON text.

    Returns:
        dict with keys:
            file (str or None): File path if is_file=True, else None.
            format (str): "json"
            threats (list): Detected threats with JSON path/location.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
            strings_scanned (int): Total number of string values scanned.

    Raises:
        FileNotFoundError: If file doesn't exist (when is_file=True).
        ValueError: If content is not valid JSON.
    """
    logger.debug("scan_json: start source=%s is_file=%s", file_path_or_text[:80] if not is_file else file_path_or_text, is_file)
    threats: List[Dict[str, Any]] = []
    strings_scanned = 0

    if is_file:
        if not os.path.exists(file_path_or_text):
            raise FileNotFoundError(f"File not found: {file_path_or_text}")

        with open(file_path_or_text, 'r', encoding='utf-8') as f:
            content = f.read()
        file_info = file_path_or_text
    else:
        content = file_path_or_text
        file_info = None

    try:
        data = json.loads(content)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}")

    def scan_value(value, path: str):
        nonlocal strings_scanned, threats

        if isinstance(value, str):
            strings_scanned += 1
            result = sanitise_content(value, format='text')
            if result['threat_count'] > 0:
                for threat in result['threats']:
                    threats.append({
                        'type': 'text_injection',
                        'path': path,
                        'value': value[:100],
                        'injection_type': threat['type'],
                        'matched': threat.get('matched', ''),
                        'description': f'Text injection detected at {path}: {threat.get("type", "unknown")}'
                    })
        elif isinstance(value, dict):
            for key, val in value.items():
                if not isinstance(key, str):
                    key = str(key)
                escaped_key = key.replace('~', '~0').replace('/', '~1')
                scan_value(val, f'{path}.{escaped_key}' if path else f'$.{escaped_key}')
        elif isinstance(value, list):
            for i, val in enumerate(value):
                scan_value(val, f'{path}[{i}]' if path else f'$[{i}]')

    scan_value(data, '')

    logger.debug("scan_json: end strings=%d threats=%d", strings_scanned, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_json: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_risk_score(threats)

    return {
        'file': file_info,
        'format': 'json',
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
        'strings_scanned': strings_scanned
    }
